import bpy
from bpy.app.handlers import persistent
from . import camera,lighting,settings_store
from .common import TAG,OWNER,settings

_busy=False


@persistent
def frame_changed(scene,*unused):
    global _busy
    if _busy:return
    _busy=True
    try:
        s=settings(scene)
        if s.live_marker_camera_switch:camera.marker_camera(scene)
        cam=scene.camera
        if cam:
            p=cam.data.smart_camlight_settings
            if s.live_per_camera_sync and p.enable_custom_settings:
                camera.configure(scene,cam)
                if p.motion_blur_enable:camera.motion(scene,p)
            if s.live_motion_blur_sync and p.motion_blur_enable:camera.motion(scene,p)
    finally:_busy=False


@persistent
def scene_changed(scene,*unused):
    global _busy
    if _busy:return
    _busy=True
    try:
        s=settings(scene)
        if s.auto_active_camera:
            active=bpy.context.active_object
            if active and active.type=="CAMERA" and scene.objects.get(active.name)==active and scene.camera!=active:
                scene.camera=active
        if s.live_light_link_monitor and s.active_linked_object_name and s.active_linked_object_name not in scene.objects:
            s.active_linked_object_name=""
        if s.live_proxy_maintenance:
            live={o.smart_camlight_object.persistent_uuid for o in scene.objects if o.type in {"CAMERA","LIGHT"}}
            for obj in list(scene.objects):
                if obj.get(TAG) in {"dolly","camera_target","path","guides","light_target","softbox"} and obj.get(OWNER) not in live:
                    if len(obj.users_scene)==1:
                        from .common import remove
                        remove(scene,obj)
    finally:_busy=False


def setting_changed(group,ctx,key):
    if _busy or not ctx or not ctx.scene:return
    s=settings(ctx.scene)
    if key in {"sky_strength","sky_turbidity","sky_sun_energy","live_dynamic_sky_monitor"} and s.live_dynamic_sky_monitor:
        lighting.sync_sky(ctx.scene)
    if key=="rig_target_size" or key=="target_size":
        from .common import owned
        for o in ctx.scene.objects:
            if o.data==group.id_data:
                for target in owned(ctx.scene,o,{"camera_target","light_target"}):target.empty_display_size=getattr(group,key)
    if key=="max_bounces":
        cycles=getattr(group.id_data,"cycles",None)
        if cycles and hasattr(cycles,"max_bounces"):cycles.max_bounces=group.max_bounces


@persistent
def before_io(*unused):settings_store.flush_deferred_settings()


@persistent
def after_load(*unused):settings_store.apply_saved_settings_to_all_scenes()


def hooks():
    h=bpy.app.handlers
    return [(h.frame_change_post,frame_changed),(h.depsgraph_update_post,scene_changed),
            (h.save_pre,before_io),(h.load_pre,before_io),(h.load_post,after_load)]


def register():
    for group,fn in hooks():
        if fn not in group:group.append(fn)
    if not bpy.app.timers.is_registered(after_load):bpy.app.timers.register(after_load,first_interval=0.0)


def unregister():
    if bpy.app.timers.is_registered(after_load):bpy.app.timers.unregister(after_load)
    for group,fn in hooks():
        if fn in group:group.remove(fn)
