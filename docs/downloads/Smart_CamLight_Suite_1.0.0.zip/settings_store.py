"""Read and update schema-6 documents using their public identities and checksum."""
from contextlib import contextmanager
from hashlib import sha256
from pathlib import Path
from uuid import uuid4
import json
import os
import tempfile
import bpy
from .common import API

_root=None
_busy=False
_pending={}
_issue=""
KINDS={"SCLSSceneSettings":("SCENE","scenes","smart_camlight_suite","persistent_scene_uuid"),
       "SCLSCameraSettings":("CAMERA","cameras","smart_camlight_settings","persistent_uuid"),
       "SCLSLightSettings":("LIGHT","lights","smart_camlight_light","persistent_uuid"),
       "SCLSObjectSettings":("OBJECT","objects","smart_camlight_object","persistent_uuid")}
NAMES={"active_camera_name","active_light_name","active_linked_object_name"}
SKIP={"persistent_uuid","persistent_scene_uuid","persistent_blend_uuid","name",
      "dynamic_sky_previous_world","dynamic_sky_owned_world","dynamic_sky_owned_sun"}
SKIP.update(p.rsplit(".",1)[-1] for p in API["contract"]["EXCLUDED_TRANSIENT_PATHS"])


def _set_config_root_for_tests(path):
    global _root
    _root=Path(path)


def config_path(*,create=True):
    base=_root or Path(bpy.utils.user_resource("CONFIG",create=create))
    folder=base/"Smart_CamLight_Suite"
    if create:folder.mkdir(parents=True,exist_ok=True)
    return folder/"Smart_CamLight_Suite.json"


def backup_path():return config_path().with_suffix(".json.bak")
def is_applying():return _busy


def stable(value):
    return sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(",",":")).encode()).hexdigest()


def checked(path):
    doc=json.loads(path.read_text(encoding="utf-8-sig"))
    keys={k:v for k,v in doc.items() if k!="checksum"}
    if doc.get("document_kind")!="smart_camlight_suite.settings" or doc.get("schema_version")!=6 or stable(keys)!=doc.get("checksum"):
        raise ValueError("The Smart CamLight settings document failed validation")
    return doc


def fresh():
    return dict(document_kind="smart_camlight_suite.settings",schema_version=6,document_uuid=str(uuid4()),
                revision=0,checksum_algorithm="sha256",portable_defaults={"scene":{}},blends={})


def load_payload(*,force=False):
    path=config_path(create=False)
    if not path.exists():return fresh()
    try:return checked(path)
    except (ValueError,OSError):
        return checked(path.with_suffix(".json.bak"))


def blend_identity(scene=None):
    scene=scene or bpy.context.scene
    s=scene.smart_camlight_suite
    token=s.persistent_blend_uuid
    if not token:
        token=next((x.smart_camlight_suite.persistent_blend_uuid for x in bpy.data.scenes if x.smart_camlight_suite.persistent_blend_uuid),"")
        token=token or str(uuid4());s.persistent_blend_uuid=token
    filename=os.path.normcase(os.path.abspath(bpy.data.filepath)) if bpy.data.filepath else "UNSAVED:"+token
    return {"persistent_uuid":token,"file_identity":filename}


def key(*parts):return sha256("|".join(parts).encode()).hexdigest()


def record_id(group,blend):
    kind,container,attr,uid=KINDS[group.bl_rna.identifier]
    token=getattr(group,uid)
    if not token:
        token=str(uuid4());setattr(group,uid,token)
    lib=group.id_data.library
    return dict(blend_uuid=blend["persistent_uuid"],blend_file_identity=blend["file_identity"],kind=kind,
                persistent_uuid=token,library_identity=os.path.normcase(bpy.path.abspath(lib.filepath)) if lib else "")


def data_key(ref):
    return key(*(ref[k] for k in ("blend_uuid","blend_file_identity","kind","persistent_uuid","library_identity")))


def encode(group,name,scene,blend):
    value=getattr(group,name)
    if name in NAMES:
        obj=scene.objects.get(value) if value else None
        return {"__idref__":record_id(obj.smart_camlight_object,blend)} if obj else None
    if hasattr(value,"as_pointer"):
        for kind,container,attr,uid in KINDS.values():
            if hasattr(value,attr):return {"__idref__":record_id(getattr(value,attr),blend)}
        return None
    if isinstance(value,(bool,int,float,str)) or value is None:return value
    return list(value)


def decode(value,group,name,scene):
    if isinstance(value,dict) and "__idref__" in value:
        ref=value["__idref__"]
        for kind,data,attr,ident in KINDS.values():
            if kind!=ref.get("kind"):continue
            pool=scene.objects if kind=="OBJECT" else getattr(bpy.data,data)
            for obj in pool:
                if getattr(getattr(obj,attr),ident)==ref.get("persistent_uuid"):
                    return obj.name if name in NAMES else obj
        return "" if name in NAMES else None
    return "" if name in NAMES and value is None else value


@contextmanager
def locked(path):
    # Shared settings can be updated by several open Blender processes.
    lockpath=path.with_suffix(".lock")
    with lockpath.open("a+b") as stream:
        if not stream.tell():stream.write(b"0");stream.flush()
        stream.seek(0)
        if os.name=="nt":
            import msvcrt
            msvcrt.locking(stream.fileno(),msvcrt.LK_NBLCK,1)
            try:yield
            finally:stream.seek(0);msvcrt.locking(stream.fileno(),msvcrt.LK_UNLCK,1)
        else:
            import fcntl
            fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB)
            try:yield
            finally:fcntl.flock(stream,fcntl.LOCK_UN)


def atomic(path,raw):
    temp=None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent,delete=False,prefix=path.name+".") as f:
            temp=Path(f.name);f.write(raw);f.flush();os.fsync(f.fileno())
        os.replace(temp,path)
    finally:
        if temp:temp.unlink(missing_ok=True)


def flush_deferred_settings(*args):
    global _issue
    if not _pending:return True
    path=config_path()
    try:
        with locked(path):
            doc=load_payload()
            for (blend_key,container,rid,name),(blend,ref,title,value,portable) in _pending.items():
                bucket=doc["blends"].setdefault(blend_key,dict(blend_identity=blend,scenes={},objects={},lights={},cameras={}))
                record=bucket[container].setdefault(rid,dict(identity=ref,name_metadata=title,values={}))
                record["name_metadata"]=title
                record["values"][name]=value
                if portable:doc["portable_defaults"].setdefault("scene",{})[name]=value
            doc.pop("checksum",None);doc["revision"]+=1;doc["checksum"]=stable(doc)
            if path.exists():
                try:checked(path)
                except ValueError:pass
                else:atomic(backup_path(),path.read_bytes())
            atomic(path,(json.dumps(doc,sort_keys=True,ensure_ascii=False,indent=2)+"\n").encode())
            _pending.clear();_issue=""
        return True
    except (ValueError,OSError,KeyError) as exc:
        _issue=str(exc)
        return False


def record_property_change(group,context,property_name):
    global _busy
    name=property_name
    if _busy or name in SKIP or not context or not context.scene:return
    scene=context.scene
    _busy=True
    try:
        blend=blend_identity(scene)
        ref=record_id(group,blend)
        kind,container,attr,uid=KINDS[group.bl_rna.identifier]
        value=encode(group,name,scene,blend)
        portable=kind=="SCENE" and name not in NAMES and API["groups"][group.bl_rna.identifier][name]["type"]!="POINTER"
        index=(key("BLEND",blend["persistent_uuid"],blend["file_identity"]),container,data_key(ref),name)
        _pending[index]=(blend,ref,group.id_data.name,value,portable)
    finally:_busy=False
    if scene.smart_camlight_suite.n_panel_state_save:flush_deferred_settings()


def apply_saved_settings(scene=None,*,force=False):
    global _busy,_issue
    if _busy:return
    scene=scene or bpy.context.scene
    if scene is None:return
    try:doc=load_payload()
    except (ValueError,OSError) as exc:_issue=str(exc);return
    _busy=True
    try:
        s=scene.smart_camlight_suite
        for name,value in doc.get("portable_defaults",{}).get("scene",{}).items():
            if name in API["groups"]["SCLSSceneSettings"] and name not in SKIP and not s.is_property_set(name):
                setattr(s,name,value)
        ident=blend_identity(scene)
        bucket=doc["blends"].get(key("BLEND",ident["persistent_uuid"],ident["file_identity"]),{})
        for klass,(kind,container,attr,uid) in KINDS.items():
            entries=bucket.get(container,{})
            if not entries:continue
            owners=[scene] if kind=="SCENE" else scene.objects if kind=="OBJECT" else {obj.data for obj in scene.objects if obj.type==kind}
            for owner in owners:
                group=getattr(owner,attr)
                if not getattr(group,uid):continue
                row=entries.get(data_key(record_id(group,ident)),{})
                for name,val in row.get("values",{}).items():
                    if name in API["groups"][klass] and name not in SKIP:
                        setattr(group,name,decode(val,group,name,scene))
    finally:_busy=False


def save_settings(settings=None,*,context=None,force=False):return flush_deferred_settings()
def apply_saved_settings_to_all_scenes(*unused,force=False):
    for scene in bpy.data.scenes:apply_saved_settings(scene,force=force)


def audit_snapshot():return {"pending":len(_pending),"last_error":_issue}
