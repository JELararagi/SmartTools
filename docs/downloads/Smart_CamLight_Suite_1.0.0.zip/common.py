from pathlib import Path
from uuid import uuid4
import json
import bpy
from mathutils import Vector

API = json.loads((Path(__file__).with_name("api.json")).read_text(encoding="utf8"))
TAG = "scls_compatible_role"
OWNER = "scls_compatible_owner"


def settings(scene):
    return scene.smart_camlight_suite


def identity(obj):
    record = obj.smart_camlight_object
    if not record.persistent_uuid:
        record.persistent_uuid = uuid4().hex
    return record.persistent_uuid


def selected(context, kind, name=""):
    scene = context.scene
    stored = settings(scene).active_camera_name if kind=="CAMERA" else settings(scene).active_light_name
    for obj in (scene.objects.get(name) if name else None, context.active_object, scene.objects.get(stored),
                scene.camera if kind=="CAMERA" else None):
        if obj is not None and obj.type==kind and scene.objects.get(obj.name)==obj:
            return obj
    raise ValueError(f"Select a {kind.lower()} in the scene")


def activate(context, obj):
    context.view_layer.update()
    if context.view_layer.objects.get(obj.name) != obj:
        raise ValueError("Object is outside the current view layer")
    for previously in context.selected_objects:
        previously.select_set(False)
    obj.select_set(True)
    context.view_layer.objects.active = obj
    if obj.type=="CAMERA":
        settings(context.scene).active_camera_name = obj.name
    if obj.type=="LIGHT":
        settings(context.scene).active_light_name = obj.name


def new_object(context, name, data, role="", owner=None):
    obj = bpy.data.objects.new(name, data)
    try:
        (context.collection or context.scene.collection).objects.link(obj)
        if role:
            obj[TAG] = role
        if owner:
            obj[OWNER] = identity(owner)
    except Exception:
        bpy.data.objects.remove(obj, do_unlink=True)
        raise
    return obj


def owned(scene, owner, roles):
    stamp = owner.smart_camlight_object.persistent_uuid
    legacy={"camera_guide":"guides","camera_rig_target":"camera_target","camera_rig_dolly":"dolly","camera_path":"path",
            "light_target":"light_target","softbox_plane":"softbox"}
    family=owner.get("_scls_owner_uuid")
    return [o for o in scene.objects if stamp and
            ((o.get(OWNER)==stamp and o.get(TAG) in roles) or
             (family and o.get("_scls_owner_uuid")==family and o.get("_scls_source_uuid")==stamp and legacy.get(o.get("_scls_role")) in roles))]


def remove(scene, obj):
    if len(obj.users_scene)>1:
        raise ValueError(f"Object is shared by several scenes: {obj.name}")
    data = obj.data
    materials = [m for m in getattr(data,"materials",()) if m and m.get(TAG) in {"guide_material","softbox_material"}]
    bpy.data.objects.remove(obj, do_unlink=True)
    if data and not data.users:
        bpy.data.batch_remove([data])
    for material in materials:
        if not material.users:bpy.data.materials.remove(material)


def point_toward(obj, target):
    direction = Vector(target) - obj.location
    if direction.length_squared:
        obj.rotation_euler = direction.to_track_quat("-Z","Y").to_euler()


def track(obj, target, label):
    con = obj.constraints.new("TRACK_TO")
    con.name = label
    con.target = target
    con.track_axis = "TRACK_NEGATIVE_Z"
    con.up_axis = "UP_Y"
    return con
