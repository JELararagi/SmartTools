"""Publish established setting and panel identities for integration consumers."""
from .common import API
for _key,_val in API["contract"].items():
    globals()[_key]=tuple(_val) if isinstance(_val,list) else _val
