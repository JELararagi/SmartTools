# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart CamLight integration of Codex's camera-frame and tracked-light operations."""
import bpy
from bpy.props import StringProperty
from mathutils import Vector

from . import transactions, translation as tr

STUDIO = (('Key', (1.5, -2.0, 2.0), 340, 1.2),
          ('Fill', (-2.0, -1.3, 0.8), 140, 1.8),
          ('Rim', (0.3, 2.0, 1.8), 260, 0.85))

FRAME_FIELDS = ('resolution_x', 'resolution_y', 'resolution_percentage', 'pixel_aspect_x', 'pixel_aspect_y')


def _camera_settings(context, name):
    scene = context.scene
    camera = scene.objects.get(name) if name else scene.camera
    if camera is None or camera.type != 'CAMERA':
        return None, None
    settings = camera.data.smart_camlight_settings
    return camera, settings if settings.enable_custom_settings else None


def _set_frame(scene, settings, tx):
    for name in FRAME_FIELDS:
        if not tx.set_attr(scene.render, name, getattr(settings, name)):
            raise ValueError(tr.t('Could not set camera resolution.', 'カメラの解像度を設定できませんでした。'))


class SCLS_OT_apply_frame_only(bpy.types.Operator):
    bl_idname = 'smart_camlight_suite.apply_frame_only'
    bl_label = tr.add('Apply Resolution Only', '解像度だけを適用')
    bl_description = tr.add('Apply this camera’s size, scale and pixel aspect to the scene',
                            'このカメラの幅、高さ、スケール、ピクセル比率をシーンに適用します')
    bl_options = {'REGISTER', 'UNDO'}
    camera_name: StringProperty(options={'SKIP_SAVE'})

    def execute(self, context):
        _, settings = _camera_settings(context, self.camera_name)
        if settings is None:
            self.report({'WARNING'}, tr.t('Enable custom settings for this camera.', '対象カメラのカスタム設定を有効にしてください。', context))
            return {'CANCELLED'}
        tx = transactions.DataTransaction('Apply Camera Resolution')
        try:
            _set_frame(context.scene, settings, tx)
            tx.commit()
        except (ValueError, RuntimeError) as exc:
            tx.rollback()
            self.report({'WARNING'}, str(exc))
            return {'CANCELLED'}
        return {'FINISHED'}


class SCLS_OT_render_frame_only(bpy.types.Operator):
    bl_idname = 'smart_camlight_suite.render_frame_only'
    bl_label = tr.add('Test Render at Camera Resolution', 'カメラの解像度で試しレンダー')
    bl_description = tr.add('Render this camera, then restore the scene camera and resolution',
                            'このカメラでレンダーし、元のシーンカメラと解像度に戻します')
    camera_name: StringProperty(options={'SKIP_SAVE'})

    def execute(self, context):
        camera, settings = _camera_settings(context, self.camera_name)
        if settings is None:
            self.report({'WARNING'}, tr.t('Enable custom settings for this camera.', '対象カメラのカスタム設定を有効にしてください。', context))
            return {'CANCELLED'}
        scene = context.scene
        tx = transactions.DataTransaction('Temporary Camera Resolution')
        try:
            if not tx.set_attr(scene, 'camera', camera):
                raise ValueError(tr.t('Could not set the render camera.', 'レンダーカメラを設定できませんでした。'))
            _set_frame(scene, settings, tx)
            return bpy.ops.render.render('EXEC_DEFAULT', scene=scene.name, write_still=False)
        except (ValueError, RuntimeError) as exc:
            self.report({'WARNING'}, str(exc))
            return {'CANCELLED'}
        finally:
            tx.rollback()


class SCLS_OT_three_point_subject(bpy.types.Operator):
    bl_idname = 'smart_camlight_suite.three_point_subject'
    bl_label = tr.add('Three Lights for Selected Subject', '選択物に3灯を配置')
    bl_description = tr.add('Create three area lights aimed at the active selected subject',
                            '選択中のアクティブ被写体を追う3つのエリアライトを作成します')
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        from .operators import _create_light, _notify_scene_structure_changed
        subject = context.active_object
        if subject is None or subject.type in {'CAMERA', 'LIGHT'} or not subject.select_get():
            self.report({'WARNING'}, tr.t('Select a subject for the lights.', '照らす被写体を選択してください。', context))
            return {'CANCELLED'}
        owner = context.collection
        if owner is None or not owner.is_editable:
            self.report({'WARNING'}, tr.t('Choose an editable collection.', '編集可能なコレクションを選択してください。', context))
            return {'CANCELLED'}
        origin = subject.matrix_world.translation
        radius = max(0.25, max(subject.dimensions) / 2)
        tx = transactions.DataTransaction('Three Lights for Selected Subject')
        try:
            for role, offset, power, size in STUDIO:
                obj = _create_light(context, 'Studio ' + role, 'AREA', origin + radius * Vector(offset),
                                    power * radius * radius, transaction=tx, collection=owner)
                obj.data.shape, obj.data.size = 'DISK', size * radius
                aim = obj.constraints.new('TRACK_TO')
                aim.target, aim.track_axis, aim.up_axis = subject, 'TRACK_NEGATIVE_Z', 'UP_Y'
            tx.commit()
        except Exception as exc:
            tx.rollback()
            self.report({'WARNING'}, str(exc))
            return {'CANCELLED'}
        _notify_scene_structure_changed(context.scene)
        return {'FINISHED'}


CLASSES = (SCLS_OT_apply_frame_only, SCLS_OT_render_frame_only, SCLS_OT_three_point_subject)
