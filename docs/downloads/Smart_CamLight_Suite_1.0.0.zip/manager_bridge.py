"""Query the enabled Smart Tools Manager through its public placement API."""
import sys
import bpy

TOOL_KEY="SMART_CAMLIGHT"
SPACES={"VIEW_3D":"VIEW_3D","IMAGE_EDITOR":"IMAGE_EDITOR","UV_EDITOR":"IMAGE_EDITOR","SHADER_EDITOR":"NODE_EDITOR",
        "COMPOSITOR":"NODE_EDITOR","GEOMETRY_NODE_EDITOR":"NODE_EDITOR","TEXTURE_NODE_EDITOR":"NODE_EDITOR",
        "VIDEO_SEQUENCER":"SEQUENCE_EDITOR","MOVIE_CLIP_EDITOR":"CLIP_EDITOR","DOPE_SHEET":"DOPESHEET_EDITOR",
        "GRAPH_EDITOR":"GRAPH_EDITOR","DRIVERS":"GRAPH_EDITOR","NLA_EDITOR":"NLA_EDITOR","TEXT_EDITOR":"TEXT_EDITOR",
        "ASSET_BROWSER":"FILE_BROWSER","FILE_BROWSER":"FILE_BROWSER","SPREADSHEET":"SPREADSHEET"}


def provider():
    for entry in bpy.context.preferences.addons:
        if entry.module.rsplit(".",1)[-1]=="smart_tools_manager":
            module=sys.modules.get(entry.module+".manager")
            if module is not None:return module
    return None


def physical_space_for_context(context):
    return getattr(getattr(context,"area",None),"type","")


def logical_editor_for_context(context):
    manager=provider()
    if manager:return manager.logical_editor_key_from_context(context)
    area=getattr(context,"area",None)
    if not area:return ""
    variants={"ShaderNodeTree":"SHADER_EDITOR","GeometryNodeTree":"GEOMETRY_NODE_EDITOR","CompositorNodeTree":"COMPOSITOR",
              "TextureNodeTree":"TEXTURE_NODE_EDITOR","UV":"UV_EDITOR","DRIVERS":"DRIVERS","ASSETS":"ASSET_BROWSER"}
    return variants.get(area.ui_type,next((k for k,v in SPACES.items() if v==area.type),area.type))


def context_matches(logical_editor,context):return logical_editor_for_context(context)==logical_editor


def placement_allowed(context,logical_editor=None):
    manager=provider()
    if manager:return bool(manager.panel_rule_allows_context(TOOL_KEY,context,logical_editor or logical_editor_for_context(context)))
    return physical_space_for_context(context)=="VIEW_3D"


def refresh_public_api():return provider() is not None
def audit_snapshot():return {"tool":TOOL_KEY,"manager_present":provider() is not None}
