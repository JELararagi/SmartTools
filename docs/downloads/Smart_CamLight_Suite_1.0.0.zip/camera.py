from contextlib import contextmanager
from fractions import Fraction
from pathlib import Path
import json
import math
import bpy
from mathutils import Vector
from .common import TAG, OWNER, activate, identity, new_object, owned, point_toward, remove, selected, settings, track

ASPECTS={"HD_16_9":(1920,1080),"VERTICAL_9_16":(1080,1920),"SQUARE_1_1":(1080,1080),
         "CINEMA_239":(2048,858),"FOUR_THREE":(1440,1080)}


def cam(op, ctx):
    return selected(ctx,"CAMERA",getattr(op,"camera_name",""))


def size(profile,w,h):
    if profile.overscan_mode=="SPECIFIC":
        return profile.overscan_specific_x, profile.overscan_specific_y
    if profile.overscan_mode=="PIXELS":
        return w+2*profile.overscan_extra_pixels,h+2*profile.overscan_extra_pixels
    scale=1+profile.overscan_percentage/100
    return round(w*scale),round(h*scale)


def overscan(scene, camera):
    r=scene.render
    p=camera.data.smart_camlight_settings
    s=settings(scene)
    if "scls_compatible_overscan" in scene:
        revert(scene)
    base_x,base_y=(p.resolution_x,p.resolution_y) if p.enable_custom_settings else (r.resolution_x,r.resolution_y)
    w,h=size(p,base_x,base_y)
    scene["scls_compatible_overscan"]=json.dumps([camera.name,r.resolution_x,r.resolution_y,r.resolution_percentage,
                                                 camera.data.lens,camera.data.ortho_scale])
    s.overscan_original_x,s.overscan_original_y,s.overscan_original_percentage=r.resolution_x,r.resolution_y,r.resolution_percentage
    s.overscan_applied_x,s.overscan_applied_y=w,h
    vertical=camera.data.sensor_fit=="VERTICAL"
    if camera.data.sensor_fit=="AUTO":
        vertical=base_y*r.pixel_aspect_y>base_x*r.pixel_aspect_x
    ratio=h/base_y if vertical else w/base_x
    if camera.data.type=="PERSP":
        camera.data.lens/=ratio
    elif camera.data.type=="ORTHO":
        camera.data.ortho_scale*=ratio
    r.resolution_x,r.resolution_y=w,h


def revert(scene):
    key="scls_compatible_overscan"
    if key not in scene:
        return
    name,x,y,percentage,lens,scale=json.loads(scene[key])
    r=scene.render
    r.resolution_x,r.resolution_y,r.resolution_percentage=x,y,percentage
    camera=scene.objects.get(name)
    if camera and camera.type=="CAMERA":
        camera.data.lens,camera.data.ortho_scale=lens,scale
    del scene[key]
    s=settings(scene)
    s.overscan_original_x=s.overscan_original_y=s.overscan_original_percentage=s.overscan_applied_x=s.overscan_applied_y=0


def motion(scene,p):
    scene.render.use_motion_blur=p.motion_blur_enable
    if p.motion_blur_mode=="SHUTTER_ANGLE":
        shutter=p.shutter_angle/360
    else:
        shutter=float(Fraction(p.shutter_speed))*scene.render.fps/scene.render.fps_base
    scene.render.motion_blur_shutter=max(0,shutter)


def stamps(scene,p):
    r=scene.render
    r.use_stamp=p.review_use_stamp
    r.use_stamp_camera,r.use_stamp_frame,r.use_stamp_scene=p.review_stamp_camera,p.review_stamp_frame,p.review_stamp_scene


def marker_camera(scene):
    effective=[m for m in scene.timeline_markers if m.camera and m.frame<=scene.frame_current]
    if effective:
        scene.camera=max(effective,key=lambda m:m.frame).camera


def frame_range(scene,camera):
    p=camera.data.smart_camlight_settings
    start,end=p.frame_start,p.frame_end
    if p.frame_range_mode=="TIMELINE_MARKERS":
        markers=sorted((m for m in scene.timeline_markers if m.camera),key=lambda m:m.frame)
        for i,m in enumerate(markers):
            if m.camera==camera:
                start=m.frame
                end=markers[i+1].frame-1 if i+1<len(markers) else max(start,scene.frame_end)
                break
    return start,max(start,end),max(1,p.frame_step)


def frames(scene,camera):
    p=camera.data.smart_camlight_settings
    if not p.sync_frame_range:return
    start,end,step=frame_range(scene,camera)
    scene.frame_end=max(start,end)
    scene.frame_start=start
    scene.frame_step=step


def configure(scene,camera,use_overscan=True):
    p=camera.data.smart_camlight_settings
    scene.camera=camera
    if not p.enable_custom_settings:
        return
    revert(scene)
    r=scene.render
    r.resolution_x,r.resolution_y,r.resolution_percentage=p.resolution_x,p.resolution_y,p.resolution_percentage
    r.pixel_aspect_x,r.pixel_aspect_y=p.pixel_aspect_x,p.pixel_aspect_y
    r.use_overwrite,r.film_transparent,r.use_stamp=p.overwrite_existing,p.film_transparent,p.burn_metadata
    parts=[p.output_path,p.output_subfolder, bpy.path.clean_name(camera.name) if p.include_camera_name else "",p.output_filename]
    prefix="//" if p.output_path.startswith("//") else ""
    first=p.output_path[2:] if prefix else p.output_path
    import os
    r.filepath=prefix+os.path.join(first,*(x for x in parts[1:] if x))
    image=r.image_settings
    if p.output_format in {"PNG","JPEG","OPEN_EXR"}:
        image.media_type="IMAGE"
        image.file_format=p.output_format
        if p.output_format=="PNG":
            image.color_depth=p.png_color_depth
            image.compression=p.png_compression
        elif p.output_format=="JPEG":
            image.quality=p.jpeg_quality
        else:
            image.color_depth,image.exr_codec=p.exr_color_depth,p.exr_codec
            image.use_preview=p.exr_preview
    else:
        image.media_type="VIDEO"
        image.file_format="FFMPEG"
        stream=r.ffmpeg
        stream.format={"H264_MP4":"MPEG4","H264_MKV":"MKV","PRORES_MOV":"QUICKTIME"}[p.output_format]
        stream.codec="PRORES" if p.output_format=="PRORES_MOV" else "H264"
        stream.constant_rate_factor=p.video_quality
        stream.video_bitrate,stream.gopsize=p.video_bitrate,p.video_gopsize
        stream.audio_codec=p.audio_codec if p.use_audio else "NONE"
        stream.audio_bitrate=p.audio_bitrate
    frames(scene,camera)
    if p.motion_blur_enable:
        motion(scene,p)
    if use_overscan and p.overscan_enable:
        overscan(scene,camera)


def saved_fields(owner,keys):
    return owner,[(name,getattr(owner,name)) for name in keys.split()]


@contextmanager
def temporary(scene,camera):
    render=scene.render
    image=render.image_settings
    previous=scene.camera
    camera_records=[saved_fields(camera.data,"lens ortho_scale")]
    values=[saved_fields(render,"resolution_x resolution_y resolution_percentage pixel_aspect_x pixel_aspect_y filepath film_transparent use_overwrite use_stamp use_stamp_camera use_stamp_frame use_stamp_scene use_motion_blur motion_blur_shutter"),
            saved_fields(image,"media_type file_format color_mode color_depth compression quality exr_codec use_preview"),
            saved_fields(render.ffmpeg,"format codec constant_rate_factor video_bitrate gopsize audio_codec audio_bitrate"),
            saved_fields(scene,"frame_end frame_start frame_step"),
            saved_fields(settings(scene),"overscan_original_x overscan_original_y overscan_original_percentage overscan_applied_x overscan_applied_y")]
    key="scls_compatible_overscan"
    prior=scene.get(key)
    if prior:
        old_camera=scene.objects.get(json.loads(prior)[0])
        if old_camera and old_camera!=camera:
            camera_records.append(saved_fields(old_camera.data,"lens ortho_scale"))
    frame=scene.frame_current,scene.frame_subframe
    try:
        yield
    finally:
        for owner,values_for_owner in [*values,*camera_records]:
            for name,value in values_for_owner:
                if getattr(owner,name)!=value:
                    setattr(owner,name,value)
        if prior is None and key in scene:
            del scene[key]
        elif prior is not None:
            scene[key]=prior
        scene.camera=previous
        if (scene.frame_current,scene.frame_subframe)!=frame:
            scene.frame_set(frame[0],subframe=frame[1])


def render_one(scene,obj,mode,animation):
    with temporary(scene,obj):
        configure(scene,obj)
        p=obj.data.smart_camlight_settings
        movie=scene.render.image_settings.media_type=="VIDEO"
        animation=animation or movie
        if mode=="VIEWPORT" and animation:
            scene.render.resolution_percentage=p.review_resolution_percentage
        args=dict(animation=animation,write_still=not animation)
        status=bpy.ops.render.opengl(view_context=True,**args) if mode=="VIEWPORT" else bpy.ops.render.render(**args)
        if "FINISHED" not in status:
            raise ValueError("Render cancelled")


def add_camera(op,ctx):
    c=new_object(ctx,"Smart Camera",bpy.data.cameras.new("Smart Camera"))
    c.location=ctx.scene.cursor.location+Vector((0,-7,3))
    point_toward(c,ctx.scene.cursor.location)
    c.data.smart_camlight_settings.enable_custom_settings=True
    ctx.scene.camera=c
    activate(ctx,c)


def select_camera(op,ctx):
    c=cam(op,ctx)
    c.hide_viewport=False
    if ctx.view_layer.objects.get(c.name)==c:c.hide_set(False)
    activate(ctx,c)
    if op.make_scene_camera:ctx.scene.camera=c
    if op.apply_settings:configure(ctx.scene,c)


def apply_camera_settings(op,ctx):
    c=cam(op,ctx)
    if not c.data.smart_camlight_settings.enable_custom_settings:
        raise ValueError("Enable settings for this camera")
    configure(ctx.scene,c,op.apply_overscan)


def apply_all_camera_settings(op,ctx):
    cameras=[o for o in ctx.scene.objects if o.type=="CAMERA" and o.data.smart_camlight_settings.enable_custom_settings]
    if not cameras:raise ValueError("No cameras with custom settings")
    for c in cameras:configure(ctx.scene,c)


def swap_resolution(op,ctx):
    p=cam(op,ctx).data.smart_camlight_settings
    p.resolution_x,p.resolution_y=p.resolution_y,p.resolution_x


def apply_aspect_preset(op,ctx):
    p=cam(op,ctx).data.smart_camlight_settings
    p.resolution_x,p.resolution_y=ASPECTS[op.preset]


def add_marker_bind_camera(op,ctx):
    scene=ctx.scene
    c=cam(op,ctx)
    marker=next((m for m in scene.timeline_markers if m.frame==scene.frame_current),None)
    if marker is None:marker=scene.timeline_markers.new(c.name,frame=scene.frame_current)
    marker.camera=c


def refresh_marker_camera(op,ctx):marker_camera(ctx.scene)
def apply_overscan(op,ctx):overscan(ctx.scene,cam(op,ctx))
def revert_overscan(op,ctx):revert(ctx.scene)
def refresh_motion_blur(op,ctx):motion(ctx.scene,cam(op,ctx).data.smart_camlight_settings)
def prepare_review_stamps(op,ctx):stamps(ctx.scene,cam(op,ctx).data.smart_camlight_settings)
def render_camera(op,ctx):render_one(ctx.scene,cam(op,ctx),op.mode,op.animation)


def render_all_cameras(op,ctx):
    cameras=[o for o in ctx.scene.objects if o.type=="CAMERA" and (not op.custom_only or o.data.smart_camlight_settings.enable_custom_settings)]
    if not cameras:raise ValueError("No matching cameras")
    for c in sorted(cameras,key=lambda o:o.name.casefold()):render_one(ctx.scene,c,op.mode,op.animation)


def remove_camera_guides(op,ctx):
    for o in owned(ctx.scene,cam(op,ctx),{"guides"}):remove(ctx.scene,o)


def create_camera_guides(op,ctx):
    c=cam(op,ctx)
    p=c.data.smart_camlight_settings
    # Derive each corner from Blender's lens and frame aspect. Normalized
    # segments do not need different constructions for orthographic cameras.
    corners=c.data.view_frame(scene=ctx.scene)
    axis_x=[v.x for v in corners];axis_y=[v.y for v in corners]
    left,right=min(axis_x),max(axis_x)
    bottom,top=min(axis_y),max(axis_y)
    depth=corners[0].z
    segments=[]
    if p.guide_thirds:
        for t in (1/3,2/3):segments.extend([((t,0),(t,1)),((0,t),(1,t))])
    if p.guide_center:segments.extend([((0,.5),(1,.5)),((.5,0),(.5,1))])
    if p.guide_safe_area:
        inset=(1-p.guide_safe_percentage/100)*.5
        edge=1-inset
        vertices=((inset,inset),(edge,inset),(edge,edge),(inset,edge))
        segments.extend(zip(vertices,(*vertices[1:],vertices[0])))
    remove_camera_guides(op,ctx)
    if not segments:return
    data=bpy.data.curves.new(c.name+" Guides","CURVE")
    data.dimensions="3D"
    data.bevel_depth=p.guide_line_width*min(right-left,top-bottom)
    guide=new_object(ctx,c.name+" Guides",data,"guides",c)
    guide.parent=c
    guide.hide_render=not p.guide_render_enabled
    guide.color=tuple(p.guide_color[:3])+(1.0,)
    for start,end in segments:
        repeats=14 if p.guide_line_style=="DASHED" else 1
        for i in range(repeats):
            line=data.splines.new("POLY");line.points.add(1)
            for pt,t in zip(line.points,(i/repeats,(i+(.58 if repeats>1 else 1))/repeats)):
                x=start[0]+(end[0]-start[0])*t;y=start[1]+(end[1]-start[1])*t
                pt.co=(left+x*(right-left),bottom+y*(top-bottom),depth,1)
    material=bpy.data.materials.new(c.name+" Guide Color")
    material[TAG]="guide_material"
    material.diffuse_color=guide.color
    material.use_nodes=True
    shader=material.node_tree.nodes.new("ShaderNodeEmission")
    shader.inputs["Color"].default_value=guide.color
    material.node_tree.links.new(shader.outputs[0],material.node_tree.nodes.get("Material Output").inputs["Surface"])
    data.materials.append(material)


def clear_rig_for(scene,c):
    helpers=owned(scene,c,{"camera_target","dolly"})
    for con in list(c.constraints):
        if con.type=="TRACK_TO" and con.target in helpers:
            c.constraints.remove(con)
    if c.data.dof.focus_object in helpers:c.data.dof.focus_object=None
    if c.parent in helpers:
        world=c.matrix_world.copy();c.parent=None;c.matrix_world=world
    for o in helpers:remove(scene,o)


def clear_camera_rigs(op,ctx):
    for item in [o for o in ctx.scene.objects if o.type=="CAMERA"]:
        clear_rig_for(ctx.scene,item)


def create_camera_rig(op,ctx):
    c=cam(op,ctx);p=c.data.smart_camlight_settings
    clear_rig_for(ctx.scene,c)
    ctx.view_layer.update()
    world=c.matrix_world.copy()
    target=new_object(ctx,c.name+" Aim",None,"camera_target",c)
    target.location=world.translation+world.to_quaternion()@Vector((0,0,-p.rig_target_distance))
    target.empty_display_size=p.rig_target_size
    if p.rig_type=="DOLLY_TARGET":
        dolly=new_object(ctx,c.name+" Dolly",None,"dolly",c)
        dolly.location=world.translation
        dolly.empty_display_type="CUBE"
        ctx.view_layer.update()
        c.parent=dolly;c.matrix_world=world
    track(c,target,"Smart Camera Aim")
    if p.rig_create_dof:c.data.dof.use_dof=True;c.data.dof.focus_object=target


def set_dof_to_selected(op,ctx):
    c=cam(op,ctx)
    target=ctx.active_object
    if target is None or target==c:target=next((o for o in ctx.selected_objects if o!=c),None)
    if not target:raise ValueError("Select a focus object")
    c.data.dof.focus_object=target
    c.data.dof.use_dof=True


def insert_camera_key(op,ctx):
    c=cam(op,ctx)
    for path in ("location","rotation_quaternion" if c.rotation_mode=="QUATERNION" else "rotation_euler"):
        c.keyframe_insert(data_path=path,frame=ctx.scene.frame_current)
    for path in ("lens","dof.focus_distance"):c.data.keyframe_insert(data_path=path,frame=ctx.scene.frame_current)


def create_path_from_camera_keys(op,ctx):
    c=cam(op,ctx);scene=ctx.scene
    start,end,step=frame_range(scene,c)
    original=scene.frame_current,scene.frame_subframe
    positions=[]
    try:
        for t in range(start,end+1,step):
            scene.frame_set(t);positions.append(c.matrix_world.translation.copy())
    finally:scene.frame_set(original[0],subframe=original[1])
    for o in owned(scene,c,{"path"}):remove(scene,o)
    data=bpy.data.curves.new(c.name+" Motion Path","CURVE")
    data.dimensions="3D"
    points=data.splines.new("POLY").points
    points.add(len(positions)-1)
    for pt,co in zip(points,positions):pt.co=(*co,1)
    path=new_object(ctx,c.name+" Motion Path",data,"path",c)
    path.hide_render=True


def bake_camera_transform(op,ctx):
    c=cam(op,ctx);scene=ctx.scene
    before=scene.frame_current,scene.frame_subframe
    keyed=[]
    try:
        start,end,step=frame_range(scene,c)
        for frame in range(start,end+1,step):
            scene.frame_set(frame)
            keyed.append((frame,c.matrix_world.copy()))
        c.parent=None
        for frame,world in keyed:
            scene.frame_set(frame);c.matrix_world=world
            for field in ("location","rotation_quaternion" if c.rotation_mode=="QUATERNION" else "rotation_euler"):
                c.keyframe_insert(data_path=field,frame=frame)
    finally:scene.frame_set(before[0],subframe=before[1])


def create_pov_camera_text(op,ctx):
    c=cam(op,ctx);p=c.data.smart_camlight_settings
    stamp=identity(c)
    text=next((t for t in bpy.data.texts if t.get(OWNER)==stamp and t.get(TAG)=="pov"),None)
    if text is None:text=bpy.data.texts.new(c.name+" Camera.pov")
    text[TAG]="pov";text[OWNER]=stamp
    ctx.view_layer.update()
    origin=c.matrix_world.translation
    target=origin+c.matrix_world.to_quaternion()@Vector((0,0,-1))
    def pov(v):return f"<{v.x:.7g},{v.z:.7g},{v.y:.7g}>"
    text.clear()
    text.write("// "+p.pov_note.replace("\n"," ")+"\ncamera {\n")
    if c.data.type=="ORTHO":text.write("  orthographic\n")
    text.write(f"  location {pov(origin)}\n  look_at {pov(target)}\n  angle {math.degrees(c.data.angle):.7g}\n")
    if p.pov_export_depth and c.data.dof.use_dof:
        focal=c.data.dof.focus_object
        fpos=focal.matrix_world.translation if focal else origin+(target-origin)*c.data.dof.focus_distance
        text.write(f"  focal_point {pov(fpos)}\n  aperture {c.data.lens/(1000*c.data.dof.aperture_fstop):.7g}\n  blur_samples 16\n")
    text.write("}\n")


def delete_camera(op,ctx):
    c=cam(op,ctx)
    if len(c.users_scene)>1:raise ValueError("Cannot remove a shared camera from several scenes")
    stamp=identity(c);clear_rig_for(ctx.scene,c)
    for o in owned(ctx.scene,c,{"guides","path"}):remove(ctx.scene,o)
    for text in list(bpy.data.texts):
        old_family=c.get("_scls_owner_uuid")
        old=(old_family and text.get("_scls_owner_uuid")==old_family and text.get("_scls_source_uuid")==stamp and text.get("_scls_role")=="pov_text")
        if old or (text.get(OWNER)==stamp and text.get(TAG)=="pov"):bpy.data.texts.remove(text)
    remove(ctx.scene,c)


def camera_fly_view(op,ctx):
    c=cam(op,ctx)
    if not ctx.area or ctx.area.type!="VIEW_3D":raise ValueError("Open a 3D view to navigate the camera")
    ctx.scene.camera=c;ctx.space_data.region_3d.view_perspective="CAMERA";ctx.space_data.lock_camera=True
    region=next(r for r in ctx.area.regions if r.type=="WINDOW")
    with ctx.temp_override(region=region):
        bpy.ops.view3d.walk("INVOKE_DEFAULT")
