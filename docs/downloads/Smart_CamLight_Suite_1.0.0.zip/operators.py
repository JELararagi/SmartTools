"""Bind the public operator signatures to independently written implementations."""
import bpy
from . import camera, lighting, studio_frame, help
from .common import API, TAG, settings


def property_from(metadata,label,update=None):
    kind=metadata["type"]
    options={"name":label.replace("_"," ").title()}
    if update:options["update"]=update
    if kind=="POINTER":
        return bpy.props.PointerProperty(type=getattr(bpy.types,metadata["ref"]),**options)
    if "subtype" in metadata:options["subtype"]=metadata["subtype"]
    options["default"]=metadata["default"]
    if kind=="ENUM":
        options["items"]=[(key,key.replace("_"," ").title(),"") for key in metadata["items"]]
    if kind in {"INT","FLOAT"}:
        options.update(min=metadata["min"],max=metadata["max"])
    if isinstance(options["default"],list):
        options["size"]=len(options["default"])
        return bpy.props.FloatVectorProperty(**options)
    constructor={"INT":bpy.props.IntProperty,"FLOAT":bpy.props.FloatProperty,"ENUM":bpy.props.EnumProperty,
                 "STRING":bpy.props.StringProperty,"BOOLEAN":bpy.props.BoolProperty}[kind]
    return constructor(**options)


def _create_light(context,name,kind,position,energy,size,transaction,collection):
    data=bpy.data.lights.new(name,kind)
    transaction.track_datablock(bpy.data.lights,data)
    obj=bpy.data.objects.new(name,data)
    transaction.track_datablock(bpy.data.objects,obj)
    collection.objects.link(obj)
    obj.location=position;data.energy=energy
    if kind=="AREA":data.size=size
    obj[TAG]="generated";obj.smart_camlight_object.is_generated_light=True
    return obj


def _notify_scene_structure_changed(scene):scene.update_tag()


def toggle_ui_section(op,ctx):
    allowed={"always_on":"ui_section_always_on","camera":"ui_section_camera","light":"ui_section_light"}
    key=allowed.get(op.section_key,op.section_key)
    if key not in allowed.values():raise ValueError("Unknown panel section")
    s=settings(ctx.scene)
    setattr(s,key,not getattr(s,key))


def open_help(op,ctx):
    if op.topic=="shots":
        help.show_shots(ctx)
        return {"FINISHED"}
    return bpy.ops.wm.url_open(url=help.manual_url(op.topic))



def run_operation(implementation):
    def execute(self,ctx):
        try:
            status=implementation(self,ctx)
            return status if isinstance(status,set) else {"FINISHED"}
        except (ValueError,KeyError,TypeError,RuntimeError,ReferenceError,OSError,ZeroDivisionError) as err:
            self.report({"WARNING"},str(err))
            return {"CANCELLED"}
    return execute


class SCLS_OT_add_camera(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.add_camera"
    bl_label = "Add Camera"
    bl_options = {"REGISTER","UNDO"}
    execute = run_operation(camera.add_camera)


class SCLS_OT_add_light(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.add_light"
    bl_label = "Add Light"
    bl_options = {"REGISTER","UNDO"}
    execute = run_operation(lighting.add_light)


class SCLS_OT_add_marker_bind_camera(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.add_marker_bind_camera"
    bl_label = "Add Marker Bind Camera"
    bl_options = {"REGISTER","UNDO"}
    camera_name: property_from(API["operators"]["add_marker_bind_camera"]["camera_name"], "camera_name")
    execute = run_operation(camera.add_marker_bind_camera)


class SCLS_OT_add_selected_to_linking(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.add_selected_to_linking"
    bl_label = "Add Selected To Linking"
    bl_options = {"REGISTER","UNDO"}
    light_name: property_from(API["operators"]["add_selected_to_linking"]["light_name"], "light_name")
    kind: property_from(API["operators"]["add_selected_to_linking"]["kind"], "kind")
    execute = run_operation(lighting.add_selected_to_linking)


class SCLS_OT_all_light_visibility(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.all_light_visibility"
    bl_label = "All Light Visibility"
    bl_options = {"REGISTER","UNDO"}
    visible: property_from(API["operators"]["all_light_visibility"]["visible"], "visible")
    execute = run_operation(lighting.all_light_visibility)


class SCLS_OT_apply_all_camera_settings(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.apply_all_camera_settings"
    bl_label = "Apply All Camera Settings"
    bl_options = {"REGISTER","UNDO"}
    execute = run_operation(camera.apply_all_camera_settings)


class SCLS_OT_apply_aspect_preset(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.apply_aspect_preset"
    bl_label = "Apply Aspect Preset"
    bl_options = {"REGISTER","UNDO"}
    camera_name: property_from(API["operators"]["apply_aspect_preset"]["camera_name"], "camera_name")
    preset: property_from(API["operators"]["apply_aspect_preset"]["preset"], "preset")
    execute = run_operation(camera.apply_aspect_preset)


class SCLS_OT_apply_camera_settings(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.apply_camera_settings"
    bl_label = "Apply Camera Settings"
    bl_options = {"REGISTER","UNDO"}
    camera_name: property_from(API["operators"]["apply_camera_settings"]["camera_name"], "camera_name")
    apply_overscan: property_from(API["operators"]["apply_camera_settings"]["apply_overscan"], "apply_overscan")
    execute = run_operation(camera.apply_camera_settings)


class SCLS_OT_apply_overscan(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.apply_overscan"
    bl_label = "Apply Overscan"
    bl_options = {"REGISTER","UNDO"}
    camera_name: property_from(API["operators"]["apply_overscan"]["camera_name"], "camera_name")
    execute = run_operation(camera.apply_overscan)


class SCLS_OT_apply_studio_preset(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.apply_studio_preset"
    bl_label = "Apply Studio Preset"
    bl_options = {"REGISTER","UNDO"}
    execute = run_operation(lighting.apply_studio_preset)


class SCLS_OT_bake_camera_transform(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.bake_camera_transform"
    bl_label = "Bake Camera Transform"
    bl_options = {"REGISTER","UNDO"}
    camera_name: property_from(API["operators"]["bake_camera_transform"]["camera_name"], "camera_name")
    execute = run_operation(camera.bake_camera_transform)


class SCLS_OT_camera_fly_view(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.camera_fly_view"
    bl_label = "Camera Fly View"
    bl_options = {"REGISTER","UNDO"}
    camera_name: property_from(API["operators"]["camera_fly_view"]["camera_name"], "camera_name")
    execute = run_operation(camera.camera_fly_view)


class SCLS_OT_clean_linking_collections(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.clean_linking_collections"
    bl_label = "Clean Linking Collections"
    bl_options = {"REGISTER","UNDO"}
    execute = run_operation(lighting.clean_linking_collections)


class SCLS_OT_clear_camera_rigs(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.clear_camera_rigs"
    bl_label = "Clear Camera Rigs"
    bl_options = {"REGISTER","UNDO"}
    execute = run_operation(camera.clear_camera_rigs)


class SCLS_OT_clear_generated_lights(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.clear_generated_lights"
    bl_label = "Clear Generated Lights"
    bl_options = {"REGISTER","UNDO"}
    execute = run_operation(lighting.clear_generated_lights)


class SCLS_OT_clear_light_linking(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.clear_light_linking"
    bl_label = "Clear Light Linking"
    bl_options = {"REGISTER","UNDO"}
    light_name: property_from(API["operators"]["clear_light_linking"]["light_name"], "light_name")
    kind: property_from(API["operators"]["clear_light_linking"]["kind"], "kind")
    execute = run_operation(lighting.clear_light_linking)


class SCLS_OT_create_camera_guides(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.create_camera_guides"
    bl_label = "Create Camera Guides"
    bl_options = {"REGISTER","UNDO"}
    camera_name: property_from(API["operators"]["create_camera_guides"]["camera_name"], "camera_name")
    execute = run_operation(camera.create_camera_guides)


class SCLS_OT_create_camera_rig(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.create_camera_rig"
    bl_label = "Create Camera Rig"
    bl_options = {"REGISTER","UNDO"}
    camera_name: property_from(API["operators"]["create_camera_rig"]["camera_name"], "camera_name")
    execute = run_operation(camera.create_camera_rig)


class SCLS_OT_create_dynamic_sky(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.create_dynamic_sky"
    bl_label = "Create Dynamic Sky"
    bl_options = {"REGISTER","UNDO"}
    execute = run_operation(lighting.create_dynamic_sky)


class SCLS_OT_create_light_target(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.create_light_target"
    bl_label = "Create Light Target"
    bl_options = {"REGISTER","UNDO"}
    light_name: property_from(API["operators"]["create_light_target"]["light_name"], "light_name")
    execute = run_operation(lighting.create_light_target)


class SCLS_OT_create_path_from_camera_keys(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.create_path_from_camera_keys"
    bl_label = "Create Path From Camera Keys"
    bl_options = {"REGISTER","UNDO"}
    camera_name: property_from(API["operators"]["create_path_from_camera_keys"]["camera_name"], "camera_name")
    execute = run_operation(camera.create_path_from_camera_keys)


class SCLS_OT_create_pov_camera_text(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.create_pov_camera_text"
    bl_label = "Create Pov Camera Text"
    bl_options = {"REGISTER","UNDO"}
    camera_name: property_from(API["operators"]["create_pov_camera_text"]["camera_name"], "camera_name")
    execute = run_operation(camera.create_pov_camera_text)


class SCLS_OT_create_softbox(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.create_softbox"
    bl_label = "Create Softbox"
    bl_options = {"REGISTER","UNDO"}
    execute = run_operation(lighting.create_softbox)


class SCLS_OT_delete_camera(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.delete_camera"
    bl_label = "Delete Camera"
    bl_options = {"REGISTER","UNDO"}
    camera_name: property_from(API["operators"]["delete_camera"]["camera_name"], "camera_name")
    execute = run_operation(camera.delete_camera)


class SCLS_OT_delete_light(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.delete_light"
    bl_label = "Delete Light"
    bl_options = {"REGISTER","UNDO"}
    light_name: property_from(API["operators"]["delete_light"]["light_name"], "light_name")
    execute = run_operation(lighting.delete_light)


class SCLS_OT_generate_lights(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.generate_lights"
    bl_label = "Generate Lights"
    bl_options = {"REGISTER","UNDO"}
    execute = run_operation(lighting.generate_lights)


class SCLS_OT_init_light_linking(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.init_light_linking"
    bl_label = "Init Light Linking"
    bl_options = {"REGISTER","UNDO"}
    light_name: property_from(API["operators"]["init_light_linking"]["light_name"], "light_name")
    execute = run_operation(lighting.init_light_linking)


class SCLS_OT_insert_camera_key(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.insert_camera_key"
    bl_label = "Insert Camera Key"
    bl_options = {"REGISTER","UNDO"}
    camera_name: property_from(API["operators"]["insert_camera_key"]["camera_name"], "camera_name")
    execute = run_operation(camera.insert_camera_key)


class SCLS_OT_isolate_light(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.isolate_light"
    bl_label = "Isolate Light"
    bl_options = {"REGISTER","UNDO"}
    light_name: property_from(API["operators"]["isolate_light"]["light_name"], "light_name")
    execute = run_operation(lighting.isolate_light)


class SCLS_OT_mirror_light(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.mirror_light"
    bl_label = "Mirror Light"
    bl_options = {"REGISTER","UNDO"}
    light_name: property_from(API["operators"]["mirror_light"]["light_name"], "light_name")
    axis: property_from(API["operators"]["mirror_light"]["axis"], "axis")
    execute = run_operation(lighting.mirror_light)


class SCLS_OT_open_help(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.open_help"
    bl_label = "Open Help"
    bl_options = {"REGISTER","UNDO"}
    topic: property_from(API["operators"]["open_help"]["topic"], "topic")
    execute = run_operation(open_help)


class SCLS_OT_prepare_review_stamps(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.prepare_review_stamps"
    bl_label = "Prepare Review Stamps"
    bl_options = {"REGISTER","UNDO"}
    camera_name: property_from(API["operators"]["prepare_review_stamps"]["camera_name"], "camera_name")
    execute = run_operation(camera.prepare_review_stamps)


class SCLS_OT_refresh_marker_camera(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.refresh_marker_camera"
    bl_label = "Refresh Marker Camera"
    bl_options = {"REGISTER","UNDO"}
    execute = run_operation(camera.refresh_marker_camera)


class SCLS_OT_refresh_motion_blur(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.refresh_motion_blur"
    bl_label = "Refresh Motion Blur"
    bl_options = {"REGISTER","UNDO"}
    camera_name: property_from(API["operators"]["refresh_motion_blur"]["camera_name"], "camera_name")
    execute = run_operation(camera.refresh_motion_blur)


class SCLS_OT_remove_camera_guides(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.remove_camera_guides"
    bl_label = "Remove Camera Guides"
    bl_options = {"REGISTER","UNDO"}
    camera_name: property_from(API["operators"]["remove_camera_guides"]["camera_name"], "camera_name")
    execute = run_operation(camera.remove_camera_guides)


class SCLS_OT_remove_dynamic_sky(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.remove_dynamic_sky"
    bl_label = "Remove Dynamic Sky"
    bl_options = {"REGISTER","UNDO"}
    execute = run_operation(lighting.remove_dynamic_sky)


class SCLS_OT_remove_linked_object(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.remove_linked_object"
    bl_label = "Remove Linked Object"
    bl_options = {"REGISTER","UNDO"}
    light_name: property_from(API["operators"]["remove_linked_object"]["light_name"], "light_name")
    object_name: property_from(API["operators"]["remove_linked_object"]["object_name"], "object_name")
    kind: property_from(API["operators"]["remove_linked_object"]["kind"], "kind")
    execute = run_operation(lighting.remove_linked_object)


class SCLS_OT_render_all_cameras(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.render_all_cameras"
    bl_label = "Render All Cameras"
    bl_options = {"REGISTER","UNDO"}
    custom_only: property_from(API["operators"]["render_all_cameras"]["custom_only"], "custom_only")
    animation: property_from(API["operators"]["render_all_cameras"]["animation"], "animation")
    mode: property_from(API["operators"]["render_all_cameras"]["mode"], "mode")
    execute = run_operation(camera.render_all_cameras)


class SCLS_OT_render_camera(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.render_camera"
    bl_label = "Render Camera"
    bl_options = {"REGISTER","UNDO"}
    camera_name: property_from(API["operators"]["render_camera"]["camera_name"], "camera_name")
    mode: property_from(API["operators"]["render_camera"]["mode"], "mode")
    animation: property_from(API["operators"]["render_camera"]["animation"], "animation")
    execute = run_operation(camera.render_camera)


class SCLS_OT_revert_overscan(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.revert_overscan"
    bl_label = "Revert Overscan"
    bl_options = {"REGISTER","UNDO"}
    execute = run_operation(camera.revert_overscan)


class SCLS_OT_select_camera(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.select_camera"
    bl_label = "Select Camera"
    bl_options = {"REGISTER","UNDO"}
    camera_name: property_from(API["operators"]["select_camera"]["camera_name"], "camera_name")
    make_scene_camera: property_from(API["operators"]["select_camera"]["make_scene_camera"], "make_scene_camera")
    apply_settings: property_from(API["operators"]["select_camera"]["apply_settings"], "apply_settings")
    execute = run_operation(camera.select_camera)


class SCLS_OT_select_light(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.select_light"
    bl_label = "Select Light"
    bl_options = {"REGISTER","UNDO"}
    light_name: property_from(API["operators"]["select_light"]["light_name"], "light_name")
    execute = run_operation(lighting.select_light)


class SCLS_OT_select_linked_object(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.select_linked_object"
    bl_label = "Select Linked Object"
    bl_options = {"REGISTER","UNDO"}
    object_name: property_from(API["operators"]["select_linked_object"]["object_name"], "object_name")
    execute = run_operation(lighting.select_linked_object)


class SCLS_OT_set_dof_to_selected(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.set_dof_to_selected"
    bl_label = "Set Dof To Selected"
    bl_options = {"REGISTER","UNDO"}
    camera_name: property_from(API["operators"]["set_dof_to_selected"]["camera_name"], "camera_name")
    execute = run_operation(camera.set_dof_to_selected)


class SCLS_OT_set_emission_strength(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.set_emission_strength"
    bl_label = "Set Emission Strength"
    bl_options = {"REGISTER","UNDO"}
    strength: property_from(API["operators"]["set_emission_strength"]["strength"], "strength")
    execute = run_operation(lighting.set_emission_strength)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


class SCLS_OT_set_link_state(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.set_link_state"
    bl_label = "Set Link State"
    bl_options = {"REGISTER","UNDO"}
    light_name: property_from(API["operators"]["set_link_state"]["light_name"], "light_name")
    object_name: property_from(API["operators"]["set_link_state"]["object_name"], "object_name")
    kind: property_from(API["operators"]["set_link_state"]["kind"], "kind")
    state: property_from(API["operators"]["set_link_state"]["state"], "state")
    execute = run_operation(lighting.set_link_state)


class SCLS_OT_swap_resolution(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.swap_resolution"
    bl_label = "Swap Resolution"
    bl_options = {"REGISTER","UNDO"}
    camera_name: property_from(API["operators"]["swap_resolution"]["camera_name"], "camera_name")
    execute = run_operation(camera.swap_resolution)


class SCLS_OT_toggle_light_lock(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.toggle_light_lock"
    bl_label = "Toggle Light Lock"
    bl_options = {"REGISTER","UNDO"}
    light_name: property_from(API["operators"]["toggle_light_lock"]["light_name"], "light_name")
    execute = run_operation(lighting.toggle_light_lock)


class SCLS_OT_toggle_light_visibility(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.toggle_light_visibility"
    bl_label = "Toggle Light Visibility"
    bl_options = {"REGISTER","UNDO"}
    light_name: property_from(API["operators"]["toggle_light_visibility"]["light_name"], "light_name")
    execute = run_operation(lighting.toggle_light_visibility)


class SCLS_OT_toggle_ui_section(bpy.types.Operator):
    bl_idname = "smart_camlight_suite.toggle_ui_section"
    bl_label = "Toggle Ui Section"
    bl_options = {"REGISTER","UNDO"}
    section_key: property_from(API["operators"]["toggle_ui_section"]["section_key"], "section_key")
    execute = run_operation(toggle_ui_section)


CLASSES = (
    SCLS_OT_add_camera,
    SCLS_OT_add_light,
    SCLS_OT_add_marker_bind_camera,
    SCLS_OT_add_selected_to_linking,
    SCLS_OT_all_light_visibility,
    SCLS_OT_apply_all_camera_settings,
    SCLS_OT_apply_aspect_preset,
    SCLS_OT_apply_camera_settings,
    studio_frame.SCLS_OT_apply_frame_only,
    SCLS_OT_apply_overscan,
    SCLS_OT_apply_studio_preset,
    SCLS_OT_bake_camera_transform,
    SCLS_OT_camera_fly_view,
    SCLS_OT_clean_linking_collections,
    SCLS_OT_clear_camera_rigs,
    SCLS_OT_clear_generated_lights,
    SCLS_OT_clear_light_linking,
    SCLS_OT_create_camera_guides,
    SCLS_OT_create_camera_rig,
    SCLS_OT_create_dynamic_sky,
    SCLS_OT_create_light_target,
    SCLS_OT_create_path_from_camera_keys,
    SCLS_OT_create_pov_camera_text,
    SCLS_OT_create_softbox,
    SCLS_OT_delete_camera,
    SCLS_OT_delete_light,
    SCLS_OT_generate_lights,
    SCLS_OT_init_light_linking,
    SCLS_OT_insert_camera_key,
    SCLS_OT_isolate_light,
    SCLS_OT_mirror_light,
    SCLS_OT_open_help,
    SCLS_OT_prepare_review_stamps,
    SCLS_OT_refresh_marker_camera,
    SCLS_OT_refresh_motion_blur,
    SCLS_OT_remove_camera_guides,
    SCLS_OT_remove_dynamic_sky,
    SCLS_OT_remove_linked_object,
    SCLS_OT_render_all_cameras,
    SCLS_OT_render_camera,
    studio_frame.SCLS_OT_render_frame_only,
    SCLS_OT_revert_overscan,
    SCLS_OT_select_camera,
    SCLS_OT_select_light,
    SCLS_OT_select_linked_object,
    SCLS_OT_set_dof_to_selected,
    SCLS_OT_set_emission_strength,
    SCLS_OT_set_link_state,
    SCLS_OT_swap_resolution,
    studio_frame.SCLS_OT_three_point_subject,
    SCLS_OT_toggle_light_lock,
    SCLS_OT_toggle_light_visibility,
    SCLS_OT_toggle_ui_section,
)
