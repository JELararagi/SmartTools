"""Compensating actions used by SmartCamLight camera and lighting commands."""
from contextlib import suppress
from functools import partial
from uuid import uuid4

import bpy


_MARKER = "_scls_transaction_uuid"
_MISSING = object()


def _snapshot_value(value):
    # RNA references refer to a particular Blender entity. Calling ID.copy() here
    # would create a real datablock just to remember a property.
    if isinstance(value, bpy.types.bpy_struct):
        return value
    clone = getattr(value, "copy", None)
    if callable(clone):
        return clone()
    if isinstance(value, bpy.types.bpy_prop_array):
        return tuple(value)
    return value


def _restore_item(owner, key, previous):
    if previous is _MISSING:
        if key in owner:
            del owner[key]
    else:
        owner[key] = previous


class DataTransaction:
    def __init__(self, label="Smart CamLight"):
        self.label = label
        self.uuid = str(uuid4())
        self.commit_failures = []
        self._done = False
        self._undo_actions = []
        self._values = {}
        self._creations = []
        self._success_actions = []

    def _remember(self, owner, name, is_item):
        key = (id(owner), name, is_item)
        if key in self._values:
            return True
        try:
            if is_item:
                val = owner[name] if name in owner else _MISSING
                restore = partial(_restore_item, owner, name, _snapshot_value(val))
            else:
                restore = partial(setattr, owner, name, _snapshot_value(getattr(owner, name)))
        except (AttributeError, IndexError, KeyError, ReferenceError, RuntimeError, TypeError, ValueError):
            return False
        self._values[key] = restore
        return True

    def snapshot_attr(self, owner, attr):
        return self._remember(owner, attr, False)

    def set_attr(self, owner, attr, value):
        if not self.snapshot_attr(owner, attr):
            return False
        try:
            setattr(owner, attr, value)
        except (AttributeError, IndexError, ReferenceError, RuntimeError, TypeError, ValueError):
            return False
        return True

    def snapshot_item(self, owner, key):
        return self._remember(owner, key, True)

    def set_item(self, owner, key, value):
        if not self.snapshot_item(owner, key):
            return False
        try:
            owner[key] = value
        except (AttributeError, IndexError, KeyError, ReferenceError, RuntimeError, TypeError, ValueError):
            return False
        return True

    def track_collection_link(self, collection, obj):
        self.add_rollback(lambda: collection.objects.unlink(obj))

    def add_rollback(self, action):
        if callable(action):
            self._undo_actions.append(action)

    def defer_commit(self, action):
        if callable(action):
            self._success_actions.append(action)

    def track_created(self, value, remover):
        if value is None or not callable(remover):
            return value
        stamped = False
        try:
            value[_MARKER] = self.uuid
            stamped = True
        except (AttributeError, KeyError, ReferenceError, RuntimeError, TypeError):
            pass
        self._creations.append((value, remover, stamped))
        return value

    def track_object(self, obj):
        def discard(owned):
            bpy.data.objects.remove(owned, do_unlink=True)
        return self.track_created(obj, discard)

    def track_datablock(self, collection, value):
        def discard(owned):
            # A new datablock can acquire an unrelated real or fake user between
            # creation and failure. Once borrowed, it must outlive this operation.
            if owned.users == 0:
                collection.remove(owned)
        return self.track_created(value, discard)

    def track_constraint(self, owner, constraint):
        return self.track_created(constraint, lambda item: owner.constraints.remove(item))

    def _finish_creations(self, undo):
        for value, discard, stamped in reversed(self._creations):
            with suppress(Exception):
                if stamped:
                    if value.get(_MARKER) != self.uuid:
                        continue
                    del value[_MARKER]
                if undo:
                    discard(value)

    def _clear_journal(self):
        self._undo_actions.clear()
        self._values.clear()
        self._creations.clear()
        self._success_actions.clear()

    def commit(self):
        if self._done:
            return False
        self._done = True
        for action in self._success_actions:
            try:
                action()
            except Exception as exc:
                self.commit_failures.append(str(exc))
        self._finish_creations(False)
        self._clear_journal()
        return True

    def rollback(self):
        if self._done:
            return False
        self._done = True
        for undo in reversed(self._undo_actions):
            with suppress(Exception):
                undo()
        for restore in reversed(self._values.values()):
            with suppress(Exception):
                restore()
        self._finish_creations(True)
        self._clear_journal()
        return True

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, _traceback):
        self.rollback()
        return False
