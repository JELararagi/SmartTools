"""Context help for the public manual and the additional shot workflow."""
import bpy


SECTIONS = {
    "overview": "f1", "ui_section_always_on": "f2", "ui_section_camera": "f3",
    "show_camera_data": "f5", "show_resolution_settings": "f6", "show_frame_range": "f7",
    "show_file_output": "f8", "show_format_settings": "f9", "show_guides": "f10",
    "show_rig": "f11", "show_review": "f12", "show_overscan": "f13",
    "show_motion_blur": "f14", "show_pov": "f15", "ui_section_light": "f16",
    "show_light_data": "f18", "show_linking": "f19", "show_light_utilities": "f20",
    "show_dynamic_sky": "f21", "sequential": "hl1",
}

SHOT_GUIDE = {
    "en": (
        "CamLight Shots",
        ("Choose a scene camera. Set the lights and render output.",
         "Enter a shot name and choose Save New Shot.",
         "Select its list entry and choose Restore Shot to recall it.",
         "Render Shot uses that saved setup, then restores the scene.",
         "For Render Batch, check the shots and choose a batch folder."),
        "Manual · Camera settings and sequential rendering",
    ),
    "ja": (
        "ショット保存の使い方",
        ("シーンのカメラを選び、ライトとレンダーの出力先を設定します。",
         "ショット名を入力し、「新規ショットを保存」を押します。",
         "一覧でショットを選び、「ショットを復元」で保存時の設定に戻します。",
         "「ショットをレンダー」で書き出すと、シーンは実行前の設定に戻ります。",
         "一括レンダーでは、書き出すショットにチェックを入れ、保存先を選びます。"),
        "解説書 · カメラ別設定と順番のレンダー",
    ),
}


def language():
    return "ja" if bpy.app.translations.locale.startswith("ja") else "en"


def manual_url(topic):
    prefix = "" if language() == "ja" else "en/"
    anchor = SECTIONS.get(topic, SECTIONS["overview"])
    return f"https://jelararagi.github.io/SmartTools/{prefix}manuals/SmartCamLight/#{anchor}"


def show_shots(context):
    title, lines, link = SHOT_GUIDE[language()]
    def draw(menu, ctx):
        for line in lines:
            menu.layout.label(text=line, translate=False)
        menu.layout.separator()
        op = menu.layout.operator("smart_camlight_suite.open_help", text=link, translate=False, icon="URL")
        op.topic = "sequential"
    context.window_manager.popup_menu(draw, title=title, icon="QUESTION")

