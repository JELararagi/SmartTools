import bpy
from . import foundation, manager_bridge, operators, runtime, ui, unified_contract, translation, settings_store, japanese
from .common import API

__version__="1.0.0"
GROUPS={}


def update_for(key):
    def update(group,ctx):
        if settings_store.is_applying():return
        settings_store.record_property_change(group,ctx,key)
        runtime.setting_changed(group,ctx,key)
    return update


for name,fields in API["groups"].items():
    annotations={key:operators.property_from(meta,key, None if key in settings_store.SKIP else update_for(key))
                 for key,meta in fields.items()}
    GROUPS[name]=type(name,(bpy.types.PropertyGroup,),dict(__module__=__name__,__annotations__=annotations))
CLASSES=tuple(GROUPS.values())+tuple(operators.CLASSES)+tuple(ui.CLASSES)
JA={"Show All Lights":"全ライトを表示","Hide All Lights":"全ライトを隠す","Cameras":"カメラ","Lights":"ライト","Camera":"カメラ","Live Settings":"常時機能","Composition Guides":"構図ガイド",
    "Resolution":"解像度","Camera Rig":"カメラリグ","Animation Review":"アニメーションレビュー","Light Generator":"ライト生成",
    "Dynamic Sky":"ダイナミックスカイ","Light Linking":"ライトリンク","Light Data":"ライトデータ","Render Viewport Animation":"ビューポート動画",
    "Add Camera":"カメラを追加","Add Light":"ライトを追加","Apply Camera Settings":"カメラ設定を適用","Generate Lights":"ライトを生成",
    "Render All Cameras":"全カメラをレンダー","Apply All Camera Settings":"全カスタムカメラを適用","Render Camera":"カメラをレンダー",
    "Create Camera Guides":"構図ガイドを作成","Remove Camera Guides":"構図ガイドを削除","Apply Overscan":"オーバースキャンを適用",
    "Revert Overscan":"オーバースキャンを戻す","Create Camera Rig":"カメラリグを作成","Create Dynamic Sky":"空を作成","Remove Dynamic Sky":"空を取り除く"}


def register():
    for cls in CLASSES:bpy.utils.register_class(cls)
    for path,group in API["owners"].items():
        owner,key=path.split(".")
        setattr(getattr(bpy.types,owner),key,bpy.props.PointerProperty(type=GROUPS[group]))
    foundation.register()
    pairs={**translation.ENTRIES,**JA,**japanese.labels()}
    bpy.app.translations.register(__package__,{"ja_JP":{(c,k):v for k,v in pairs.items() for c in ("*","Operator")}})
    runtime.register()


def unregister():
    runtime.unregister()
    settings_store.flush_deferred_settings()
    bpy.app.translations.unregister(__package__)
    foundation.unregister()
    for path in reversed(API["owners"]):
        owner,key=path.split(".")
        delattr(getattr(bpy.types,owner),key)
    for cls in reversed(CLASSES):bpy.utils.unregister_class(cls)
