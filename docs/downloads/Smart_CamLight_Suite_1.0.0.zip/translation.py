import bpy

ENTRIES={}


def add(english,japanese):
    ENTRIES[english]=japanese
    return english


def t(english,japanese,context=None):
    return japanese if bpy.app.translations.locale.startswith("ja") else english
