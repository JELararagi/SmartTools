import math
import random
import bpy
from mathutils import Vector
from .common import TAG, OWNER, activate, identity, new_object, owned, point_toward, remove, selected, settings, track


def lamp(op,ctx):return selected(ctx,"LIGHT",getattr(op,"light_name",""))


def scene_lamps(scene):return [o for o in scene.objects if o.type=="LIGHT"]


def center(ctx):
    s=settings(ctx.scene)
    if s.use_target_object and s.target_object:return s.target_object.matrix_world.translation.copy()
    active=ctx.active_object
    return active.matrix_world.translation.copy() if active and active.type not in {"LIGHT","CAMERA"} else Vector((0,0,0))


def build_lamp(ctx,name,kind,offset,power,target=None):
    s=settings(ctx.scene)
    data=bpy.data.lights.new(name,kind)
    obj=new_object(ctx,name,data,"generated")
    obj.smart_camlight_object.is_generated_light=True
    target=center(ctx) if target is None else target
    obj.location=target+Vector(offset)
    point_toward(obj,target)
    data.energy=power
    if kind=="AREA":
        data.shape=s.area_shape
        data.size=s.area_size_x if data.shape in {"ELLIPSE","RECTANGLE"} else s.light_size
        if data.shape in {"ELLIPSE","RECTANGLE"}:data.size_y=s.area_size_y
    if kind=="SPOT":
        data.spot_size=s.spot_size;data.spot_blend=s.spot_blend
    return obj


def select_light(op,ctx):activate(ctx,lamp(op,ctx))


def add_light(op,ctx):
    s=settings(ctx.scene)
    created=build_lamp(ctx,"Smart "+s.light_type.title(),s.light_type,(0,-s.light_distance,s.light_z_offset),s.power_max)
    activate(ctx,created)


def delete_light(op,ctx):
    light=lamp(op,ctx)
    if light.smart_camlight_object.locked_light:raise ValueError("Unlock the light first")
    if len(light.users_scene)>1:raise ValueError("Cannot delete a light shared between scenes")
    for obj in owned(ctx.scene,light,{"light_target","softbox"}):remove(ctx.scene,obj)
    remove(ctx.scene,light)


def toggle_light_lock(op,ctx):
    flags=lamp(op,ctx).smart_camlight_object
    flags.locked_light=not flags.locked_light


def visibility(ctx,obj,visible):
    obj.hide_viewport=not visible
    obj.hide_render=not visible
    if ctx.view_layer.objects.get(obj.name)==obj:obj.hide_set(not visible,view_layer=ctx.view_layer)


def toggle_light_visibility(op,ctx):
    target=lamp(op,ctx)
    visibility(ctx,target,target.hide_render or target.hide_viewport or target.hide_get())


def all_light_visibility(op,ctx):
    for target in scene_lamps(ctx.scene):visibility(ctx,target,op.visible)


def isolate_light(op,ctx):
    target=lamp(op,ctx)
    for obj in scene_lamps(ctx.scene):visibility(ctx,obj,obj==target)


def mirror_light(op,ctx):
    original=lamp(op,ctx)
    duplicate=original.copy();duplicate.data=original.data.copy()
    (ctx.collection or ctx.scene.collection).objects.link(duplicate)
    duplicate.smart_camlight_object.persistent_uuid=""
    duplicate.smart_camlight_object.is_generated_light=True
    duplicate[TAG]="generated"
    world=original.matrix_world.copy()
    world.translation=original.location.copy() if not original.parent else world.translation
    pos=world.translation.copy();pos["XYZ".index(op.axis)]*=-1
    world.translation=pos;duplicate.matrix_world=world
    if not duplicate.constraints:point_toward(duplicate,center(ctx))
    activate(ctx,duplicate)


def create_light_target(op,ctx):
    light=lamp(op,ctx)
    old=owned(ctx.scene,light,{"light_target"})
    for c in list(light.constraints):
        if c.type=="TRACK_TO" and c.target in old:light.constraints.remove(c)
    for o in old:remove(ctx.scene,o)
    obj=new_object(ctx,light.name+" Aim",None,"light_target",light)
    obj.location=center(ctx);obj.empty_display_size=light.data.smart_camlight_light.target_size
    track(light,obj,"Smart Light Aim")
    activate(ctx,obj)


def generate_lights(op,ctx):
    s=settings(ctx.scene);rng=random.Random(s.light_seed)
    d=s.light_distance;count=s.light_count
    side=math.ceil(math.sqrt(count));z=s.light_z_offset
    for i in range(count):
        t=math.tau*i/count
        if s.distribution=="RANDOM":t=rng.uniform(0,math.tau)
        if s.distribution=="LINE":
            offset=((-1+2*i/max(1,count-1))*d,-d/2,z)
        elif s.distribution=="GRID":
            spacing=2*d/max(1,side-1)
            offset=((i%side)*spacing-d,(i//side)*spacing-d,z)
        else:
            radius=d*(1+rng.uniform(-s.light_randomness,s.light_randomness))
            offset=(radius*math.cos(t),radius*math.sin(t),z)
        intensity=rng.uniform(s.power_min,s.power_max) if s.randomize_power else s.power_max
        build_lamp(ctx,f"Studio {i+1}",s.light_type,offset,intensity)


def clear_generated_lights(op,ctx):
    scene=ctx.scene
    for obj in scene_lamps(scene):
        if obj.smart_camlight_object.is_generated_light and len(obj.users_scene)==1:
            for child in owned(scene,obj,{"light_target","softbox"}):remove(scene,child)
            remove(scene,obj)


def apply_studio_preset(op,ctx):
    s=settings(ctx.scene)
    presets={"THREE_POINT":("AREA","AREA","SPOT"),"SOFT_STUDIO":("AREA",)*3,
             "RIM_CIRCLE":("SPOT",)*6,"PRODUCT_STRIP":("AREA",)*3,"SKY_FILL":("AREA",)}
    kinds=presets[s.studio_preset]
    for i,kind in enumerate(kinds):
        theta=math.tau*i/len(kinds)-math.pi*.65
        offset=(s.light_distance*math.cos(theta),s.light_distance*math.sin(theta),s.light_z_offset+(i%2))
        o=build_lamp(ctx,f"{s.studio_preset.title()} {i+1}",kind,offset,s.power_max if not i else s.power_min)
        if s.studio_preset=="PRODUCT_STRIP":o.data.shape="RECTANGLE";o.data.size_y=max(.1,o.data.size*.22)
    if s.studio_preset=="SKY_FILL":create_dynamic_sky(op,ctx)


def create_softbox(op,ctx):
    s=settings(ctx.scene)
    o=build_lamp(ctx,"Softbox Light","AREA",(0,-s.light_distance,s.light_z_offset),s.power_max)
    w=h=max(.01,s.light_size)/2
    mesh=bpy.data.meshes.new("Softbox Diffuser")
    mesh.from_pydata([(-w,-h,0),(w,-h,0),(w,h,0),(-w,h,0)],[],[(0,1,2,3)])
    board=new_object(ctx,"Softbox Diffuser",mesh,"softbox",o)
    board.parent=o;board.location.z=.01
    mat=bpy.data.materials.new("Softbox Emission");mat[TAG]="softbox_material";mat.use_nodes=True
    shader=mat.node_tree.nodes.new("ShaderNodeEmission")
    shader.inputs["Strength"].default_value=s.power_max
    mat.node_tree.links.new(shader.outputs[0],mat.node_tree.nodes.get("Material Output").inputs[0])
    mesh.materials.append(mat)


def sync_sky(scene):
    s=settings(scene)
    world=s.dynamic_sky_owned_world
    if world and world.node_tree and world.get(TAG)=="sky":
        for n in world.node_tree.nodes:
            if n.type=="BACKGROUND":n.inputs["Strength"].default_value=s.sky_strength
            if n.type=="TEX_SKY" and hasattr(n,"turbidity"):n.turbidity=s.sky_turbidity
    if s.dynamic_sky_owned_sun and s.dynamic_sky_owned_sun.data:s.dynamic_sky_owned_sun.data.energy=s.sky_sun_energy


def create_dynamic_sky(op,ctx):
    scene=ctx.scene;s=settings(scene)
    if not s.dynamic_sky_owned_world:
        prior=scene.world
        world=bpy.data.worlds.new("CamLight Sky");world[TAG]="sky";world.use_nodes=True
        node=world.node_tree.nodes.new("ShaderNodeTexSky")
        world.node_tree.links.new(node.outputs[0],world.node_tree.nodes.get("Background").inputs["Color"])
        s.dynamic_sky_previous_world=prior;s.dynamic_sky_owned_world=world
    elif scene.world!=s.dynamic_sky_owned_world:
        s.dynamic_sky_previous_world=scene.world
    scene.world=s.dynamic_sky_owned_world
    if s.sky_create_sun and not s.dynamic_sky_owned_sun:
        sun=new_object(ctx,"CamLight Sun",bpy.data.lights.new("CamLight Sun","SUN"),"sky_sun")
        sun.rotation_euler=(.45,-.25,.1);s.dynamic_sky_owned_sun=sun
    sync_sky(scene)


def remove_dynamic_sky(op,ctx):
    scene=ctx.scene;s=settings(scene)
    sun=s.dynamic_sky_owned_sun;world=s.dynamic_sky_owned_world
    if scene.world==world and world:scene.world=s.dynamic_sky_previous_world
    s.dynamic_sky_owned_sun=None;s.dynamic_sky_owned_world=None;s.dynamic_sky_previous_world=None
    if sun and sun.get(TAG)=="sky_sun" and len(sun.users_scene)==1:remove(scene,sun)
    if world and not world.users and world.get(TAG)=="sky":bpy.data.worlds.remove(world)


ATTRS={"RECEIVER":"receiver_collection","BLOCKER":"blocker_collection"}


def link_collection(light,kind,create=False):
    key=ATTRS[kind];coll=getattr(light.light_linking,key)
    if coll is None and create:
        coll=bpy.data.collections.new(light.name+" "+kind.title())
        coll[TAG]="link";coll[OWNER]=identity(light)
        setattr(light.light_linking,key,coll)
    return coll


def init_light_linking(op,ctx):
    light=lamp(op,ctx)
    for kind in ATTRS:link_collection(light,kind,True)


def add_selected_to_linking(op,ctx):
    light=lamp(op,ctx)
    targets=[obj for obj in ctx.selected_objects if obj!=light]
    if not targets:raise ValueError("Select at least one object to link")
    coll=link_collection(light,op.kind,True)
    for obj in targets:
        if not coll.objects.get(obj.name):coll.objects.link(obj)


def remove_linked_object(op,ctx):
    coll=link_collection(lamp(op,ctx),op.kind)
    obj=coll.objects.get(op.object_name) if coll else None
    if obj is None:raise ValueError("Linked object not found")
    coll.objects.unlink(obj)


def select_linked_object(op,ctx):
    obj=ctx.scene.objects.get(op.object_name)
    if obj is None:raise ValueError("Object is outside this scene")
    activate(ctx,obj)


def set_link_state(op,ctx):
    coll=link_collection(lamp(op,ctx),op.kind)
    if coll:
        for obj,row in zip(coll.objects,coll.collection_objects):
            if obj.name==op.object_name:
                row.light_linking.link_state=op.state;return
    raise ValueError("Add the object to the list first")


def clear_light_linking(op,ctx):
    light=lamp(op,ctx)
    for kind in ATTRS if op.kind=="BOTH" else [op.kind]:setattr(light.light_linking,ATTRS[kind],None)


def clean_linking_collections(op,ctx):
    for coll in list(bpy.data.collections):
        if coll.get(TAG)=="link" and not coll.users:bpy.data.collections.remove(coll)


def set_emission_strength(op,ctx):
    count=0
    for obj in ctx.selected_objects:
        for slot in obj.material_slots:
            mat=slot.material
            if mat and mat.node_tree:
                for node in mat.node_tree.nodes:
                    if node.type=="BSDF_PRINCIPLED":
                        node.inputs["Emission Strength"].default_value=op.strength;count+=1
    if not count:raise ValueError("Select a material with a Principled BSDF")
