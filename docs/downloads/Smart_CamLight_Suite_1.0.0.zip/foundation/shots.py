"""Capture supported Blender state, then validate and apply it as a unit."""
import json

OUTPUT_FIELDS = ("resolution_x", "resolution_y", "resolution_percentage", "pixel_aspect_x",
                 "pixel_aspect_y", "filepath", "use_file_extension", "film_transparent")
FRAME_FIELDS = ("frame_start", "frame_end", "frame_step")
IMAGE_FIELDS = {"PNG": ("color_mode", "color_depth", "compression"),
                "JPEG": ("color_mode", "quality"),
                "OPEN_EXR": ("color_mode", "color_depth", "exr_codec")}
LIGHT_FIELDS = {"POINT": ("shadow_soft_size",), "SUN": ("angle",),
                "SPOT": ("shadow_soft_size", "spot_size", "spot_blend"),
                "AREA": ("shape", "size", "size_y")}
OPTICS = ("type", "lens", "ortho_scale", "shift_x", "shift_y", "clip_start", "clip_end")
FOCUS = ("use_dof", "focus_distance", "aperture_fstop")


def fields(owner, names):
    return {name: getattr(owner, name) for name in names}


def output_values(scene):
    render = scene.render
    image = render.image_settings
    if image.file_format not in IMAGE_FIELDS:
        raise ValueError("Choose PNG, JPEG or OpenEXR before storing or restoring a shot")
    return dict(render=fields(render, OUTPUT_FIELDS), frames=fields(scene, FRAME_FIELDS),
                frame=scene.frame_current, subframe=scene.frame_subframe, format=image.file_format,
                image=fields(image, IMAGE_FIELDS[image.file_format]))


def assign(owner, values, names):
    for name in names:
        value = values[name]
        if getattr(owner, name) != value:
            setattr(owner, name, value)


def apply_output(scene, values):
    render = scene.render
    assign(render, values["render"], OUTPUT_FIELDS)
    # Move the upper bound first when a range shifts forward, to avoid clamping.
    limits = values["frames"]
    if limits["frame_start"] > scene.frame_end:
        scene.frame_end = limits["frame_end"]
    assign(scene, limits, FRAME_FIELDS)
    if (scene.frame_current, scene.frame_subframe) != (values["frame"], values["subframe"]):
        scene.frame_set(values["frame"], subframe=values["subframe"])
    image = render.image_settings
    image_fields = IMAGE_FIELDS[values["format"]]
    image.file_format = values["format"]
    assign(image, values["image"], image_fields)


def includes(scene, obj):
    return obj is not None and scene.objects.get(obj.name) == obj


def light_values(obj):
    data = obj.data
    if data.type not in LIGHT_FIELDS:
        raise ValueError(f"Unsupported light type on {obj.name}")
    # Photometric settings and visibility form the lighting look. Transforms
    # stay under the control of parenting, animation and constraints.
    return dict(type=data.type, energy=data.energy, color=list(data.color),
                hide_render=obj.hide_render, shape=fields(data, LIGHT_FIELDS[data.type]))


def apply_light(obj, values):
    data = obj.data
    if data.type != values["type"]:
        raise ValueError(f"Light type has changed on {obj.name}")
    assign(data, values, ("energy",))
    if list(data.color) != values["color"]:
        data.color = values["color"]
    assign(data, values["shape"], LIGHT_FIELDS[data.type])
    assign(obj, values, ("hide_render",))


def optics(camera):
    return dict(optics=fields(camera.data, OPTICS), dof=fields(camera.data.dof, FOCUS))


def current(scene, lights, optical_target=None):
    camera = optical_target or scene.camera
    lens_record = (camera, optics(camera)) if camera else None
    lamps = [(obj, light_values(obj), obj.light_linking.receiver_collection, obj.light_linking.blocker_collection)
             for obj in lights]
    return scene.camera, output_values(scene), lamps, lens_record


def store(shot, snapshot):
    camera, output, lamps, lens_record = snapshot
    shot.camera = camera
    shot.output_json = json.dumps(output)
    shot.lens_json = json.dumps(lens_record[1])
    for obj, values, receiver, blocker in lamps:
        entry = shot.lamps.add()
        entry.light = obj
        entry.values_json = json.dumps(values)
        entry.receiver = receiver
        entry.blocker = blocker
        entry.had_receiver = receiver is not None
        entry.had_blocker = blocker is not None


def read(scene, shot):
    if not includes(scene, shot.camera) or shot.camera.type != "CAMERA":
        raise ValueError("The stored camera is missing from this scene")
    lamps = []
    for entry in shot.lamps:
        obj = entry.light
        if not includes(scene, obj) or obj.type != "LIGHT":
            raise ValueError("A stored light is missing from this scene")
        values = json.loads(entry.values_json)
        if obj.data.type != values["type"]:
            raise ValueError(f"Light type has changed on {obj.name}")
        if values != light_values(obj):
            if not obj.is_editable or not obj.data.is_editable:
                raise ValueError(f"Linked lighting is read-only on {obj.name}")
            if len(obj.users_scene) > 1 or obj.data.users > 1:
                raise ValueError(f"Make the light single-user before changing shared settings on {obj.name}")
        if (entry.had_receiver and not entry.receiver) or (entry.had_blocker and not entry.blocker):
            raise ValueError(f"A stored light-link collection is missing for {obj.name}")
        link_changed = (obj.light_linking.receiver_collection, obj.light_linking.blocker_collection) != (entry.receiver, entry.blocker)
        if link_changed and (not obj.is_editable or len(obj.users_scene) > 1):
            raise ValueError(f"Make the light object editable in a single scene before changing links on {obj.name}")
        lamps.append((obj, values, entry.receiver, entry.blocker))
    camera = shot.camera
    lens = json.loads(shot.lens_json)
    if lens != optics(camera) and (not camera.data.is_editable or len(camera.users_scene) > 1 or camera.data.users > 1):
        raise ValueError(f"Make camera data editable and single-user before changing optics on {camera.name}")
    return camera, json.loads(shot.output_json), lamps, (camera, lens)


def apply(scene, snapshot):
    camera, output, lamps, lens_record = snapshot
    apply_output(scene, output)
    scene.camera = camera
    if lens_record:
        obj, lens = lens_record
        assign(obj.data, lens["optics"], OPTICS)
        assign(obj.data.dof, lens["dof"], FOCUS)
    for obj, values, receiver, blocker in lamps:
        apply_light(obj, values)
        assign(obj.light_linking, {"receiver_collection": receiver, "blocker_collection": blocker},
               ("receiver_collection", "blocker_collection"))
