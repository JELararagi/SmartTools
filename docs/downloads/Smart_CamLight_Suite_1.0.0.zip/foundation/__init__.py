"""CamLight Shots, a standalone camera and lighting workflow for Blender."""
from pathlib import Path

import bpy
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, IntProperty, PointerProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup
from mathutils import Vector

from . import shots
from ..manager_bridge import placement_allowed


class SCLS_SHOTS_LightRecord(PropertyGroup):
    light: PointerProperty(type=bpy.types.Object)
    values_json: StringProperty()
    receiver: PointerProperty(type=bpy.types.Collection)
    blocker: PointerProperty(type=bpy.types.Collection)
    had_receiver: BoolProperty()
    had_blocker: BoolProperty()


class SCLS_SHOTS_Visibility(PropertyGroup):
    light: PointerProperty(type=bpy.types.Object)
    hidden: BoolProperty()
    render_hidden: BoolProperty()


class SCLS_SHOTS_Shot(PropertyGroup):
    camera: PointerProperty(type=bpy.types.Object)
    output_json: StringProperty()
    lens_json: StringProperty()
    lamps: CollectionProperty(type=SCLS_SHOTS_LightRecord)
    in_batch: BoolProperty(name="Include in Batch", default=True)


class SCLS_SHOTS_Book(PropertyGroup):
    entries: CollectionProperty(type=SCLS_SHOTS_Shot)
    index: IntProperty(default=0, min=0)
    label: StringProperty(name="Shot Name", default="Shot")
    directory: StringProperty(name="Batch Folder", subtype="DIR_PATH", default="//shots/")
    light: PointerProperty(name="Light", type=bpy.types.Object, poll=lambda self, obj: obj.type == "LIGHT")
    animation: BoolProperty(name="Frame Range")
    viewport: BoolProperty(name="Use Viewport")
    receivers: PointerProperty(name="Link Collection", type=bpy.types.Collection)
    saved_visibility: CollectionProperty(type=SCLS_SHOTS_Visibility)
    isolated_layer: StringProperty()


def selected(scene):
    book = scene.smart_camlight_shots
    if not 0 <= book.index < len(book.entries):
        raise ValueError("Select a saved shot")
    return book.entries[book.index]


def create_object(context, data, offset):
    point = context.scene.cursor.location
    obj = bpy.data.objects.new(data.name, data)
    collection = context.collection or context.scene.collection
    try:
        collection.objects.link(obj)
        obj.location = point + Vector(offset)
        obj.rotation_euler = (-Vector(offset)).to_track_quat("-Z", "Y").to_euler()
    except Exception:
        bpy.data.objects.remove(obj, do_unlink=True)
        raise
    return obj


class SCLS_SHOTS_OT_camera(Operator):
    bl_idname = "smart_camlight_shots.create_camera"
    bl_label = "Add Camera"
    bl_description = "Aim a new camera at the 3D cursor and make it the scene camera"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        data = bpy.data.cameras.new("Shot Camera")
        try:
            context.scene.camera = create_object(context, data, (0, -7, 3))
        except RuntimeError as exc:
            if not data.users:
                bpy.data.cameras.remove(data)
            self.report({"WARNING"}, str(exc))
            return {"CANCELLED"}
        return {"FINISHED"}


class SCLS_SHOTS_OT_switch(Operator):
    bl_idname = "smart_camlight_shots.switch_camera"
    bl_label = "Use Selected Camera"
    bl_options = {"REGISTER", "UNDO"}
    camera_name: StringProperty(name="Camera")

    def execute(self, context):
        camera = context.scene.objects.get(self.camera_name) if self.camera_name else context.active_object
        if camera is None or camera.type != "CAMERA" or not shots.includes(context.scene, camera):
            self.report({"WARNING"}, "Select a camera in this scene")
            return {"CANCELLED"}
        context.scene.camera = camera
        return {"FINISHED"}


class SCLS_SHOTS_OT_lights(Operator):
    bl_idname = "smart_camlight_shots.add_lights"
    bl_label = "Add Lights"
    bl_description = "Aim lighting at the 3D cursor"
    bl_options = {"REGISTER", "UNDO"}
    kind: EnumProperty(name="Setup", items=[(v, t, "") for v, t in
        (("THREE", "Three-Point Rig"), ("AREA", "Area"), ("POINT", "Point"), ("SPOT", "Spot"), ("SUN", "Sun"))])

    def execute(self, context):
        if self.kind == "THREE":
            layout = [("Key", "AREA", (-3, -4, 4), 650, 3.0),
                      ("Fill", "AREA", (3, -2, 2), 240, 4.0),
                      ("Rim", "AREA", (1, 3, 4), 500, 2.0)]
        else:
            layout = [(self.kind.title(), self.kind, (0, -3, 4), 3 if self.kind == "SUN" else 450, 3)]
        objects, blocks = [], []
        try:
            for name, kind, offset, energy, size in layout:
                data = bpy.data.lights.new(name, kind)
                blocks.append(data)
                data.energy = energy
                if kind == "AREA":
                    data.size = size
                objects.append(create_object(context, data, offset))
        except RuntimeError as exc:
            for obj in objects:
                bpy.data.objects.remove(obj, do_unlink=True)
            for data in blocks:
                if not data.users:
                    bpy.data.lights.remove(data)
            self.report({"WARNING"}, str(exc))
            return {"CANCELLED"}
        return {"FINISHED"}


class SCLS_SHOTS_OT_save(Operator):
    bl_idname = "smart_camlight_shots.save"
    bl_label = "Save New Shot"
    bl_description = "Store the active camera, current scene lights, frame range and output settings in this file"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = context.scene
        book = scene.smart_camlight_shots
        name = book.label.strip()
        if not scene.camera or not name or book.entries.get(name) is not None:
            self.report({"WARNING"}, "Choose a camera and an unused shot name")
            return {"CANCELLED"}
        try:
            saved = shots.current(scene, [obj for obj in scene.objects if obj.type == "LIGHT"])
        except ValueError as exc:
            self.report({"WARNING"}, str(exc))
            return {"CANCELLED"}
        index = len(book.entries)
        entry = book.entries.add()
        try:
            entry.name = name
            shots.store(entry, saved)
        except Exception:
            book.entries.remove(index)
            raise
        book.index = index
        return {"FINISHED"}


ERRORS = (ValueError, TypeError, RuntimeError, OSError, ReferenceError, KeyError)


def use_shot(scene, entry, action=None):
    stored = shots.read(scene, entry)
    previous = shots.current(scene, [record[0] for record in stored[2]], optical_target=stored[0])
    try:
        shots.apply(scene, stored)
        if action is not None:
            action()
    except Exception:
        shots.apply(scene, previous)
        raise
    if action is not None:
        shots.apply(scene, previous)


class SCLS_SHOTS_OT_recall(Operator):
    bl_idname = "smart_camlight_shots.recall"
    bl_label = "Restore Shot"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        try:
            use_shot(context.scene, selected(context.scene))
        except ERRORS as exc:
            self.report({"WARNING"}, str(exc))
            return {"CANCELLED"}
        return {"FINISHED"}


class SCLS_SHOTS_OT_remove(Operator):
    bl_idname = "smart_camlight_shots.remove"
    bl_label = "Remove Shot"
    bl_description = "Remove the selected saved settings from this file"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        book = context.scene.smart_camlight_shots
        if not 0 <= book.index < len(book.entries):
            return {"CANCELLED"}
        book.entries.remove(book.index)
        book.index = min(book.index, max(0, len(book.entries) - 1))
        return {"FINISHED"}


def render_shot(scene, entry, destination, viewport, animation):
    def submit():
        if destination:
            scene.render.filepath = destination
        elif not scene.render.filepath.strip():
            raise ValueError("Choose an output path before rendering")
        if scene.render.filepath.startswith("//") and not bpy.data.filepath:
            raise ValueError("Save the blend file or choose an absolute output path")
        options = dict(animation=animation, write_still=not animation)
        result = bpy.ops.render.opengl(view_context=True, **options) if viewport else bpy.ops.render.render(**options)
        if "FINISHED" not in result:
            raise RuntimeError(f"Render cancelled for {entry.name}")
    use_shot(scene, entry, submit)


class SCLS_SHOTS_OT_render(Operator):
    bl_idname = "smart_camlight_shots.render"
    bl_label = "Render Shot"
    batch: BoolProperty(name="Render Batch")
    animation: BoolProperty(name="Render Frame Range")
    viewport: BoolProperty(name="Viewport Render")

    def execute(self, context):
        scene = context.scene
        book = scene.smart_camlight_shots
        try:
            if self.batch:
                if not book.directory.strip():
                    raise ValueError("Choose a batch folder")
                if book.directory.startswith("//") and not bpy.data.filepath:
                    raise ValueError("Save the blend file or choose an absolute batch folder")
                path = Path(bpy.path.abspath(book.directory))
                queue = [(entry, str(path / f"{index+1:03d}-{bpy.path.clean_name(entry.name)}" / "image"))
                         for index, entry in enumerate(book.entries) if entry.in_batch]
                if not queue:
                    raise ValueError("Include at least one shot in the batch")
            else:
                queue = [(selected(scene), None)]
            for entry, _ in queue:
                shots.read(scene, entry)
            for entry, destination in queue:
                render_shot(scene, entry, destination, self.viewport, self.animation)
        except ERRORS as exc:
            self.report({"WARNING"}, str(exc))
            return {"CANCELLED"}
        return {"FINISHED"}


class SCLS_SHOTS_PT_shots(Panel):
    bl_label = "CamLight Shots"
    bl_idname = "SCLS_SHOTS_PT_shots"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Smart CamLight"

    def draw_header_preset(self, context):
        self.layout.operator("smart_camlight_suite.open_help", text="", icon="QUESTION", emboss=False).topic = "shots"

    @classmethod
    def poll(cls, context):
        return placement_allowed(context)

    def draw(self, context):
        ui = self.layout
        scene = context.scene
        book = scene.smart_camlight_shots
        ui.prop(scene, "camera", text="Camera")
        row = ui.row(align=True)
        row.operator("smart_camlight_shots.create_camera")
        row.operator("smart_camlight_shots.switch_camera", text="Use Selected")
        if scene.camera:
            camera = scene.camera.data
            ui.prop(camera, "type")
            if camera.type == "PERSP":
                ui.prop(camera, "lens")
            elif camera.type == "ORTHO":
                ui.prop(camera, "ortho_scale")
        ui.separator()
        row = ui.row(align=True)
        row.operator("smart_camlight_shots.add_lights", text="Three-Point Rig").kind = "THREE"
        row.operator_menu_enum("smart_camlight_shots.add_lights", "kind", text="Add Light")
        ui.prop(book, "light")
        if shots.includes(scene, book.light):
            ui.prop(book.light.data, "energy")
            ui.prop(book.light.data, "color")
            ui.prop(book, "receivers", text="Targets")
            row = ui.row(align=True)
            row.operator("smart_camlight_shots.link", text="Set Receivers").shadow = False
            row.operator("smart_camlight_shots.link", text="Set Blockers").shadow = True
        if book.saved_visibility:
            ui.operator("smart_camlight_shots.isolate", text="Restore Light Visibility")
        elif shots.includes(scene, book.light):
            ui.operator("smart_camlight_shots.isolate")
        ui.separator()
        r = scene.render
        row = ui.row(align=True)
        row.prop(r, "resolution_x", text="X")
        row.prop(r, "resolution_y", text="Y")
        row.prop(r, "resolution_percentage", text="%")
        row = ui.row(align=True)
        row.prop(scene, "frame_start")
        row.prop(scene, "frame_end")
        ui.prop(r.image_settings, "file_format", text="Format")
        ui.prop(r, "filepath", text="Path")
        ui.separator()
        ui.prop(book, "label", text="Name")
        ui.operator("smart_camlight_shots.save")
        if not book.entries:
            return
        ui.template_list("UI_UL_list", "shots", book, "entries", book, "index", rows=3)
        row = ui.row(align=True)
        row.operator("smart_camlight_shots.recall")
        row.operator("smart_camlight_shots.remove")
        if 0 <= book.index < len(book.entries):
            ui.prop(book.entries[book.index], "in_batch")
        ui.prop(book, "directory", text="Folder")
        row = ui.row(align=True)
        row.prop(book, "animation")
        row.prop(book, "viewport")
        row = ui.row(align=True)
        for batch, title in ((False, "Render Shot"), (True, "Render Batch")):
            op = row.operator("smart_camlight_shots.render", text=title)
            op.batch = batch
            op.animation = book.animation
            op.viewport = book.viewport


class SCLS_SHOTS_OT_link(Operator):
    bl_idname = "smart_camlight_shots.link"
    bl_label = "Set Light Link"
    bl_description = "Use the chosen collection for the light. An empty collection field clears the link"
    bl_options = {"REGISTER", "UNDO"}
    shadow: BoolProperty(name="Shadow Blockers")

    def execute(self, context):
        scene = context.scene
        book = scene.smart_camlight_shots
        light = book.light
        if not shots.includes(scene, light) or light.type != "LIGHT" or not light.is_editable or len(light.users_scene) > 1:
            self.report({"WARNING"}, "Choose an editable light belonging to this scene only")
            return {"CANCELLED"}
        attribute = "blocker_collection" if self.shadow else "receiver_collection"
        try:
            setattr(light.light_linking, attribute, book.receivers)
        except RuntimeError as exc:
            self.report({"WARNING"}, str(exc))
            return {"CANCELLED"}
        return {"FINISHED"}


def restore_visibility(scene):
    book = scene.smart_camlight_shots
    layer = scene.view_layers.get(book.isolated_layer)
    for entry in book.saved_visibility:
        light = entry.light
        if not shots.includes(scene, light) or not light.is_editable:
            continue
        if light.hide_render != entry.render_hidden and len(light.users_scene) == 1:
            light.hide_render = entry.render_hidden
        if layer is not None and layer.objects.get(light.name) == light:
            light.hide_set(entry.hidden, view_layer=layer)
    book.saved_visibility.clear()
    book.isolated_layer = ""


class SCLS_SHOTS_OT_isolate(Operator):
    bl_idname = "smart_camlight_shots.isolate"
    bl_label = "Isolate Light"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene, layer = context.scene, context.view_layer
        book = scene.smart_camlight_shots
        if book.saved_visibility:
            restore_visibility(scene)
            return {"FINISHED"}
        lamps = [obj for obj in layer.objects if obj.type == "LIGHT"]
        if book.light not in lamps or any(not o.is_editable or len(o.users_scene) > 1 for o in lamps):
            self.report({"WARNING"}, "Choose an editable light and use scene-local lights in this view layer")
            return {"CANCELLED"}
        book.isolated_layer = layer.name
        try:
            for light in lamps:
                row = book.saved_visibility.add()
                row.light, row.hidden, row.render_hidden = light, light.hide_get(view_layer=layer), light.hide_render
                hide = light != book.light
                light.hide_set(hide, view_layer=layer)
                light.hide_render = hide
        except RuntimeError as exc:
            restore_visibility(scene)
            self.report({"WARNING"}, str(exc))
            return {"CANCELLED"}
        return {"FINISHED"}


CLASSES = (SCLS_SHOTS_LightRecord, SCLS_SHOTS_Visibility, SCLS_SHOTS_Shot, SCLS_SHOTS_Book, SCLS_SHOTS_OT_camera, SCLS_SHOTS_OT_switch,
           SCLS_SHOTS_OT_lights, SCLS_SHOTS_OT_save, SCLS_SHOTS_OT_recall, SCLS_SHOTS_OT_remove, SCLS_SHOTS_OT_render,
           SCLS_SHOTS_OT_link, SCLS_SHOTS_OT_isolate, SCLS_SHOTS_PT_shots)
JA = {"CamLight Shots": "カメラと照明のショット", "Shot Name": "ショット名",
      "Use Selected": "選択を使う", "Targets": "対象",
      "Add Camera": "カメラを作成", "Use Selected Camera": "選択カメラに切替",
      "Three-Point Rig": "三点照明", "Add Lights": "ライトを作成", "Add Light": "ライトを追加",
      "Include in Batch": "一括出力の対象", "Batch Folder": "一括出力先", "Save New Shot": "新規ショットを保存",
      "Restore Shot": "ショットを復元", "Remove Shot": "ショットを削除",
      "Frame Range": "フレーム範囲", "Use Viewport": "ビューポートを使用",
      "Link Collection": "リンク用コレクション", "Set Receivers": "照射対象に設定", "Set Blockers": "遮蔽物に設定",
      "Isolate Light": "ライトを分離", "Restore Light Visibility": "ライトの表示を復元",
      "Render Shot": "ショットをレンダー", "Render Batch": "一括レンダー"}


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.smart_camlight_shots = PointerProperty(type=SCLS_SHOTS_Book)
    translations = {(context, text): target for context in ("*", "Operator") for text, target in JA.items()}
    bpy.app.translations.register(__package__, {"ja_JP": translations})


def unregister():
    for scene in bpy.data.scenes:
        if scene.get("smart_camlight_shots") is not None and scene.smart_camlight_shots.saved_visibility:
            restore_visibility(scene)
    bpy.app.translations.unregister(__package__)
    del bpy.types.Scene.smart_camlight_shots
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
