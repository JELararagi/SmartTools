import bpy
from .common import API,settings
from .manager_bridge import placement_allowed

CAMERA_GROUPS={
    "show_camera_data":("Camera",(),("select_camera","add_marker_bind_camera","insert_camera_key","camera_fly_view","set_dof_to_selected")),
    "show_resolution_settings":("Resolution",("resolution_x","resolution_y","resolution_percentage","pixel_aspect_x","pixel_aspect_y"),("swap_resolution","apply_aspect_preset","apply_frame_only","render_frame_only")),
    "show_frame_range":("Frame Range",("frame_range_mode","sync_frame_range","frame_start","frame_end","frame_step"),("refresh_marker_camera",)),
    "show_file_output":("Output",("output_path","output_subfolder","output_filename","include_camera_name","overwrite_existing","film_transparent","burn_metadata"),()),
    "show_format_settings":("Format",("output_format","png_color_depth","png_compression","jpeg_quality","exr_color_depth","exr_codec","exr_preview","video_quality","video_bitrate","video_gopsize","use_audio","audio_codec","audio_bitrate"),()),
    "show_guides":("Composition Guides",("guide_thirds","guide_center","guide_safe_area","guide_safe_percentage","guide_color","guide_line_width","guide_line_style","guide_render_enabled"),("create_camera_guides","remove_camera_guides")),
    "show_rig":("Camera Rig",("rig_type","rig_target_distance","rig_target_size","rig_create_dof"),("create_camera_rig","clear_camera_rigs","create_path_from_camera_keys","bake_camera_transform")),
    "show_review":("Animation Review",("review_use_stamp","review_stamp_camera","review_stamp_frame","review_stamp_scene","review_resolution_percentage"),("prepare_review_stamps",)),
    "show_overscan":("Overscan",("overscan_enable","overscan_mode","overscan_view_factor","overscan_percentage","overscan_extra_pixels","overscan_specific_x","overscan_specific_y"),("apply_overscan","revert_overscan")),
    "show_motion_blur":("Motion Blur",("motion_blur_enable","motion_blur_mode","shutter_speed","shutter_angle"),("refresh_motion_blur",)),
    "show_pov":("POV-Ray",("pov_export_depth","pov_note"),("create_pov_camera_text",))}


def button(layout,name,**values):
    op=layout.operator("smart_camlight_suite."+name)
    for key,value in values.items():setattr(op,key,value)
    return op


def props(layout,group,keys):
    for key in keys:layout.prop(group,key)


def section(layout,group,key,title):
    visible=getattr(group,key)
    row=layout.row(align=True)
    row.prop(group,key,text=title,icon="TRIA_DOWN" if visible else "TRIA_RIGHT",emboss=False)
    row.operator("smart_camlight_suite.open_help",text="",icon="QUESTION",emboss=False).topic=key
    return visible


def camera_ui(ui,ctx):
    scene=ctx.scene;s=settings(scene)
    ui.prop(s,"show_custom_cameras_only")
    button(ui,"add_camera")
    for c in sorted((o for o in scene.objects if o.type=="CAMERA"),key=lambda o:o.name):
        p=c.data.smart_camlight_settings
        if s.show_custom_cameras_only and not p.enable_custom_settings:continue
        row=ui.row(align=True)
        op=row.operator("smart_camlight_suite.select_camera",text=c.name,icon="CAMERA_DATA",depress=c==scene.camera);op.camera_name=c.name
        row.prop(p,"enable_custom_settings",text="")
        row.operator("smart_camlight_suite.apply_camera_settings",text="",icon="CHECKMARK").camera_name=c.name
        op=row.operator("smart_camlight_suite.delete_camera",text="",icon="X");op.camera_name=c.name
    c=scene.objects.get(s.active_camera_name) or scene.camera
    if not c or c.type!="CAMERA":return
    p=c.data.smart_camlight_settings
    button(ui,"apply_camera_settings",camera_name=c.name)
    row=ui.row(align=True);button(row,"render_camera",camera_name=c.name)
    op=row.operator("smart_camlight_suite.render_camera",text="Viewport");op.mode="VIEWPORT";op.camera_name=c.name
    button(ui,"render_all_cameras");button(ui,"apply_all_camera_settings")
    for key,(title,properties,actions) in CAMERA_GROUPS.items():
        if section(ui,p,key,title):
            box=ui.box();props(box,p,properties)
            if key=="show_camera_data":
                props(box,c,("name","location","rotation_quaternion" if c.rotation_mode=="QUATERNION" else "rotation_euler","scale"))
                props(box,c.data,("type","ortho_scale" if c.data.type=="ORTHO" else "lens","angle","sensor_width","sensor_height",
                                  "sensor_fit","shift_x","shift_y","clip_start","clip_end","display_size"))
                props(box,c.data.dof,("use_dof","focus_object","focus_distance","aperture_fstop","aperture_blades"))
            for name in actions:
                args={"camera_name":c.name} if "camera_name" in API["operators"][name] else {}
                if name=="apply_aspect_preset":
                    box.operator_menu_enum("smart_camlight_suite."+name,"preset")
                else:button(box,name,**args)
            if key=="show_review":
                op=box.operator("smart_camlight_suite.render_camera",text="Render Viewport Animation")
                op.camera_name=c.name;op.mode="VIEWPORT";op.animation=True


def light_ui(ui,ctx):
    scene=ctx.scene;s=settings(scene)
    ui.prop(s,"show_generated_lights_only");button(ui,"add_light")
    row=ui.row(align=True)
    for visible,label in ((True,"Show All Lights"),(False,"Hide All Lights")):
        row.operator("smart_camlight_suite.all_light_visibility",text=label).visible=visible
    for obj in sorted(scene.objects,key=lambda o:o.name.casefold()):
        if obj.type!="LIGHT" or (s.show_generated_lights_only and not obj.smart_camlight_object.is_generated_light):continue
        row=ui.row(align=True)
        op=row.operator("smart_camlight_suite.select_light",text=obj.name);op.light_name=obj.name
        for action,icon in (("toggle_light_lock","LOCKED" if obj.smart_camlight_object.locked_light else "UNLOCKED"),
                            ("toggle_light_visibility","HIDE_ON" if obj.hide_render else "HIDE_OFF"),("delete_light","X")):
            row.operator("smart_camlight_suite."+action,text="",icon=icon).light_name=obj.name
    light=scene.objects.get(s.active_light_name)
    if light and light.type=="LIGHT":
        p=light.data.smart_camlight_light
        if section(ui,p,"show_light_data","Light Data"):
            box=ui.box();box.enabled=not light.smart_camlight_object.locked_light
            props(box,light,("name","location","rotation_quaternion" if light.rotation_mode=="QUATERNION" else "rotation_euler"))
            props(box,light.data,("type","energy","color","use_shadow"))
            specific={"AREA":("shape","size","size_y"),"POINT":("shadow_soft_size",),"SPOT":("shadow_soft_size","spot_size","spot_blend"),"SUN":("angle",)}
            props(box,light.data,specific.get(light.data.type,()));props(box,p,("target_size","max_bounces"))
            button(box,"create_light_target",light_name=light.name);button(box,"isolate_light",light_name=light.name)
            box.operator_menu_enum("smart_camlight_suite.mirror_light","axis")
        if section(ui,p,"show_linking","Light Linking"):
            button(ui,"init_light_linking",light_name=light.name)
            for kind,attr in (("RECEIVER","receiver_collection"),("BLOCKER","blocker_collection")):
                ui.label(text=kind.title())
                button(ui,"add_selected_to_linking",light_name=light.name,kind=kind)
                coll=getattr(light.light_linking,attr)
                if coll:
                    for obj,row in zip(coll.objects,coll.collection_objects):
                        line=ui.row(align=True);line.label(text=obj.name)
                        line.prop(row.light_linking,"link_state",text="")
                        unlink=line.operator("smart_camlight_suite.remove_linked_object",text="",icon="X")
                        unlink.object_name=obj.name;unlink.kind=kind;unlink.light_name=light.name
                        op=line.operator("smart_camlight_suite.select_linked_object",text="",icon="RESTRICT_SELECT_OFF");op.object_name=obj.name
            button(ui,"clear_light_linking",light_name=light.name);button(ui,"clean_linking_collections")
    if section(ui,s,"show_light_utilities","Light Generator"):
        box=ui.box();props(box,s,("light_count","light_type","light_distance","light_randomness","light_z_offset","light_seed",
                "area_shape","area_size_x","area_size_y","light_size","randomize_power","power_min","power_max","distribution",
                "spot_size","spot_blend","use_target_object","target_object","studio_preset"))
        for name in ("generate_lights","apply_studio_preset","three_point_subject","create_softbox","clear_generated_lights","set_emission_strength"):
            button(box,name)
    if section(ui,s,"show_dynamic_sky","Dynamic Sky"):
        box=ui.box();props(box,s,("sky_strength","sky_turbidity","sky_sun_energy","sky_create_sun"))
        button(box,"create_dynamic_sky");button(box,"remove_dynamic_sky")


def draw(self,ctx):
    ui=self.layout;s=settings(ctx.scene)
    if section(ui,s,"ui_section_always_on","Live Settings"):
        props(ui,s,("n_panel_state_save",*list(k.rsplit(".",1)[-1] for k in API["contract"]["RUNTIME_TOGGLE_PATHS"])))
    if section(ui,s,"ui_section_camera","Cameras"):camera_ui(ui,ctx)
    if section(ui,s,"ui_section_light","Lights"):light_ui(ui,ctx)
    button(ui,"open_help")


def poll(cls,ctx):return ctx.scene is not None and placement_allowed(ctx)


def draw_header_preset(self,ctx):
    self.layout.operator("smart_camlight_suite.open_help",text="",icon="QUESTION",emboss=False).topic="overview"


AREAS=("VIEW_3D","IMAGE_EDITOR","NODE_EDITOR","SEQUENCE_EDITOR","CLIP_EDITOR","DOPESHEET_EDITOR","GRAPH_EDITOR",
       "NLA_EDITOR","TEXT_EDITOR","FILE_BROWSER","FILE_BROWSER","SPREADSHEET")
CLASSES=[]
for panel,area in zip(API["contract"]["ROOT_PANEL_IDS"],AREAS):
    options=dict(__module__=__name__,bl_label="Smart CamLight",bl_idname=panel,bl_space_type=area,
                 bl_region_type="UI",bl_category="Smart CamLight",draw=draw,draw_header_preset=draw_header_preset,poll=classmethod(poll))
    if panel=="FILEBROWSER_PT_scls_assets_root":options["bl_region_type"]="TOOL_PROPS";options.pop("bl_category")
    CLASSES.append(type(panel,(bpy.types.Panel,),options))
