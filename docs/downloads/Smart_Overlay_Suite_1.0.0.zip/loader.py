# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import importlib.util
import platform
import sys
import traceback
from pathlib import Path
from typing import Any

import bpy
from . import feature_toggle as _feature_toggle

from . import registry
from . import icons as sos_icons

_RECORDS: list[dict[str, Any]] = []
_HIDDEN_PANEL_POLLS: dict[type, object] = {}
_MISSING_POLL = object()


def _SICON(name: str = '', fallback: str = 'NONE') -> int:
    try:
        return int(sos_icons.icon_value(name, fallback) or 0)
    except Exception:
        return 0


def _label_with_icon(layout, text: str = '', custom: str = '', fallback: str = 'NONE'):
    try:
        return layout.label(text=text, **sos_icons.icon_kwargs(custom or fallback, fallback))
    except Exception:
        return layout.label(text=text, icon=fallback)


def _embedded_context_safe(context) -> bool:
    try:
        if context is None or getattr(context, 'scene', None) is None:
            return False
        area = getattr(context, 'area', None)
        if area is not None and getattr(area, 'type', None) != 'VIEW_3D':
            return False
        obj = getattr(context, 'object', None) or getattr(context, 'active_object', None)
        if obj is None:
            return False
        try:
            _ = obj.name
            _ = obj.type
        except Exception:
            return False
        mode = str(getattr(context, 'mode', 'OBJECT') or 'OBJECT')
        if mode != 'OBJECT' and obj is None:
            return False
        return True
    except Exception:
        return False


def clear_records() -> None:
    _RECORDS.clear()


def get_records() -> list[dict[str, Any]]:
    return list(_RECORDS)


def _new_record(spec: dict[str, Any]) -> dict[str, Any]:
    return {
        'spec': spec,
        'status': 'not_loaded',
        'module': None,
        'registered_classes': [],
        'proxy_panels': [],
        'panels': [],
        'skipped_panel_classes': [],
        'operators': [],
        'menus': [],
        'preferences': [],
        'error': '',
    }


def find_record(addon_alias: str) -> dict[str, Any] | None:
    alias = str(addon_alias or '').strip()
    if not alias:
        return None
    for record in _RECORDS:
        spec = record.get('spec') or {}
        if str(spec.get('alias') or '').strip() == alias:
            return record
    return None


def _root_module_prefix() -> str:
    package = str(__package__ or '').strip()
    return package or 'smart_overlay_suite'


def _platform_supported(outer_zip: str) -> bool:
    text = str(outer_zip or '').lower()
    system = platform.system().lower()
    machine = platform.machine().lower()
    if 'windows-x64' in text:
        return system == 'windows' and machine in {'amd64', 'x86_64'}
    if 'linux-x64' in text:
        return system == 'linux' and machine in {'amd64', 'x86_64'}
    if 'macos-arm64' in text:
        return system == 'darwin' and machine in {'arm64', 'aarch64'}
    if 'macos-x64' in text:
        return system == 'darwin' and machine in {'amd64', 'x86_64'}
    return True


def _module_name_for_spec(spec: dict[str, Any]) -> str:
    prefix = _root_module_prefix()
    alias = str(spec.get('alias') or 'addon').strip()
    return f'{prefix}.{alias}'


def _purge_module_tree(module_name: str) -> None:
    prefix = f"{str(module_name or '').strip()}."
    for key in list(sys.modules.keys()):
        if key == module_name or key.startswith(prefix):
            try:
                sys.modules.pop(key, None)
            except Exception:
                pass


def _spec_import_paths(spec: dict[str, Any]) -> tuple[str, str, Path]:
    src_dir = Path(str(spec.get('src_dir') or ''))
    init_relpath = Path(str(spec.get('init_relpath') or ''))
    init_path = (src_dir / init_relpath).resolve() if src_dir and init_relpath else Path()
    module_name = _module_name_for_spec(spec)
    package_dir = init_path.parent if init_path.name == '__init__.py' else src_dir
    return module_name, str(init_path), package_dir


def _load_module_from_spec(spec: dict[str, Any]):
    module_name, init_path_str, package_dir = _spec_import_paths(spec)
    if not init_path_str:
        raise FileNotFoundError('init_relpath is empty')
    init_path = Path(init_path_str)
    if not init_path.exists():
        raise FileNotFoundError(f'Missing init file: {init_path}')

    _purge_module_tree(module_name)
    original_module_name = str(spec.get('original_module_name') or '').strip()
    if original_module_name and original_module_name != module_name:
        try:
            _purge_module_tree(original_module_name)
        except Exception:
            pass
    spec_obj = importlib.util.spec_from_file_location(
        module_name,
        str(init_path),
        submodule_search_locations=[str(package_dir)],
    )
    if spec_obj is None or spec_obj.loader is None:
        raise ImportError(f'Failed to create module spec for {init_path}')
    module = importlib.util.module_from_spec(spec_obj)
    sys.modules[module_name] = module

    # Do not register top-level compatibility aliases such as ``smart_measure``
    # or ``image_dimensions_viewer``.  Blender 5.1 extension policy requires all
    # bundled modules to remain below the active add-on package namespace.

    spec_obj.loader.exec_module(module)
    return module


def _wrap_panel_draw_safely(cls):
    try:
        panel_base = getattr(bpy.types, 'Panel', None)
        if panel_base is None or not isinstance(cls, type) or not issubclass(cls, panel_base):
            return cls
    except Exception:
        return cls
    def _draw_signature_is_exact(draw_func):
        try:
            code = getattr(draw_func, '__code__', None)
            if code is None or int(getattr(code, 'co_argcount', -1)) != 2:
                return False
            if getattr(draw_func, '__defaults__', None):
                return False
            if getattr(draw_func, '__kwdefaults__', None):
                return False
            return True
        except Exception:
            return False

    try:
        if getattr(cls, '_sos_safe_draw_wrapped', False) and _draw_signature_is_exact(getattr(cls, 'draw', None)):
            return cls
    except Exception:
        pass
    original_draw = getattr(cls, 'draw', None)
    if not callable(original_draw):
        return cls
    class_name = str(getattr(cls, '__name__', 'Panel'))

    def _make_safe_draw(_orig_draw, _cls_name):
        # Blender validates Panel.draw with the exact public signature
        # ``draw(self, context)``.  Captured values must live in a closure,
        # not in default arguments, otherwise Blender 5.1 reports extra args.
        def _safe_draw(self, context):
            try:
                if not _embedded_context_safe(context):
                    return None
                _orig_draw(self, context)
                return None
            except Exception as exc:
                try:
                    layout = getattr(self, 'layout', None)
                    if layout is not None:
                        box = layout.box()
                        _label_with_icon(box, text=registry.localized('Integrated panel draw was skipped safely.', '統合パネルの描画を安全にスキップしました。', context), custom='error', fallback='ERROR')
                        box.label(text=str(_cls_name))
                        detail = str(exc or '')[:180]
                        if detail:
                            box.label(text=detail)
                except Exception:
                    pass
                return None
        return _safe_draw

    try:
        cls.draw = _make_safe_draw(original_draw, class_name)
        cls._sos_safe_draw_wrapped = True
    except Exception:
        pass
    return cls


def _capture_registered_classes(callable_obj):
    captured: list[type] = []
    original_register_class = bpy.utils.register_class
    original_unregister_class = bpy.utils.unregister_class

    def _wrapped_register_class(cls):
        cls = _wrap_panel_draw_safely(cls)
        try:
            from . import undo_support
            undo_support.prepare_operator_class(cls)
        except Exception:
            pass
        class_name = str(getattr(cls, '__name__', '') or '').strip()

        if _capture_panel_without_sidebar_registration(cls):
            # Capture the draw implementation for Smart Overlay embedding, but
            # do not register this class with Blender's N-panel.  This fully
            # removes the standalone bundled-tool panels rather than hiding them
            # after registration.  A stale class from an older build is removed
            # first so in-place updates cannot leave duplicate panels behind.
            _unregister_existing_panel_by_name(class_name)
            if cls not in captured:
                captured.append(cls)
            return

        existing = getattr(bpy.types, class_name, None) if class_name else None
        if existing is cls:
            if cls not in captured:
                captured.append(cls)
            return
        if isinstance(existing, type):
            try:
                original_unregister_class(existing)
            except Exception:
                pass
        try:
            original_register_class(cls)
        except RuntimeError as exc:
            if 'already registered' not in str(exc):
                raise
            existing = getattr(bpy.types, class_name, None) if class_name else None
            if isinstance(existing, type) and existing is not cls:
                try:
                    original_unregister_class(existing)
                except Exception:
                    pass
            original_register_class(cls)
        if cls not in captured:
            captured.append(cls)

    bpy.utils.register_class = _wrapped_register_class
    try:
        callable_obj()
    finally:
        bpy.utils.register_class = original_register_class
    return captured


def _embedded_panel_classes_from_module(module) -> list[type]:
    panels: list[type] = []
    for attr_name in ('EMBEDDED_PANEL_CLASSES', 'PANEL_CLASSES'):
        try:
            values = getattr(module, attr_name, ())
        except Exception:
            values = ()
        for cls in list(values or ()):
            if not isinstance(cls, type):
                continue
            cls = _wrap_panel_draw_safely(cls)
            if not _is_panel_class(cls):
                continue
            try:
                _unregister_existing_panel_by_name(str(getattr(cls, '__name__', '') or ''))
            except Exception:
                pass
            if cls not in panels:
                panels.append(cls)
    return panels


def _categorize_classes(classes: list[type]) -> tuple[list[type], list[type], list[type], list[type]]:
    panels: list[type] = []
    operators: list[type] = []
    menus: list[type] = []
    prefs: list[type] = []
    panel_base = getattr(bpy.types, 'Panel', None)
    operator_base = getattr(bpy.types, 'Operator', None)
    menu_base = getattr(bpy.types, 'Menu', None)
    prefs_base = getattr(bpy.types, 'AddonPreferences', None)
    for cls in classes:
        try:
            if panel_base is not None and isinstance(cls, type) and issubclass(cls, panel_base):
                panels.append(cls)
                continue
        except Exception:
            pass
        try:
            if operator_base is not None and isinstance(cls, type) and issubclass(cls, operator_base):
                operators.append(cls)
                continue
        except Exception:
            pass
        try:
            if menu_base is not None and isinstance(cls, type) and issubclass(cls, menu_base):
                menus.append(cls)
                continue
        except Exception:
            pass
        try:
            if prefs_base is not None and isinstance(cls, type) and issubclass(cls, prefs_base):
                prefs.append(cls)
                continue
        except Exception:
            pass
    return panels, operators, menus, prefs


def _is_panel_class(cls: type) -> bool:
    try:
        panel_base = getattr(bpy.types, 'Panel', None)
        return panel_base is not None and isinstance(cls, type) and issubclass(cls, panel_base)
    except Exception:
        return False


def _panel_is_bundled_tool_sidebar(cls: type) -> bool:
    """Return True for bundled tool panels that must never appear standalone.

    The integrated tools are drawn only inside VIEW3D_PT_sos_root. Their Panel
    classes are captured as ordinary Python classes, but they are not registered
    with Blender's sidebar registry. This removes the separate "Grid
    Dimensions", "Image Dimensions Viewer", "Smart Measure", and "Silhouette
    Mode" N-panel entries entirely instead of only hiding them with poll().
    """
    if not _is_panel_class(cls):
        return False
    try:
        return (
            str(getattr(cls, 'bl_space_type', '') or '') == 'VIEW_3D'
            and str(getattr(cls, 'bl_region_type', '') or '') == 'UI'
        )
    except Exception:
        return False


def _unregister_existing_panel_by_name(class_name: str) -> None:
    """Remove a stale registered sidebar Panel left by older builds."""
    text = str(class_name or '').strip()
    if not text:
        return
    try:
        existing = getattr(bpy.types, text, None)
    except Exception:
        existing = None
    if not isinstance(existing, type) or not _is_panel_class(existing):
        return
    try:
        bpy.utils.unregister_class(existing)
    except Exception:
        pass


def _capture_panel_without_sidebar_registration(cls: type) -> bool:
    return _panel_is_bundled_tool_sidebar(cls)


def _call_module_unregister_tolerant(module, panels: list[type] | tuple[type, ...] | None) -> None:
    """Run an integrated tool unregister() after sidebar panels were skipped.

    Bundled modules still call bpy.utils.unregister_class() for their Panel
    classes. Because those panels are intentionally not registered as standalone
    N-panel entries, unregister_class would otherwise raise and abort the rest
    of the module cleanup. This wrapper ignores only those known embedded Panel
    classes and lets normal operator/property cleanup continue.
    """
    unregister_fn = getattr(module, 'unregister', None)
    if not callable(unregister_fn):
        return
    panel_set = {cls for cls in list(panels or ()) if isinstance(cls, type)}
    original_unregister_class = bpy.utils.unregister_class

    def _wrapped_unregister_class(cls):
        if cls in panel_set or _capture_panel_without_sidebar_registration(cls):
            try:
                original_unregister_class(cls)
            except Exception:
                pass
            return None
        return original_unregister_class(cls)

    bpy.utils.unregister_class = _wrapped_unregister_class
    try:
        unregister_fn()
    finally:
        bpy.utils.unregister_class = original_unregister_class


def _hide_original_panels(panels: list[type]) -> None:
    """Remove stale standalone bundled-tool panels left by older builds.

    Current integrated-tool panels are embedding-only and are not registered with
    Blender's sidebar registry.  This function only cleans up classes that may
    already exist in bpy.types after an in-place update; it no longer changes
    Panel.poll to hide a registered panel.
    """
    for cls in panels:
        try:
            _unregister_existing_panel_by_name(str(getattr(cls, '__name__', '') or ''))
        except Exception:
            pass

def _drop_hidden_panels(panels: list[type] | tuple[type, ...] | None) -> None:
    for cls in list(panels or ()):
        _HIDDEN_PANEL_POLLS.pop(cls, None)


def _panel_identifier(cls: type) -> str:
    value = str(getattr(cls, 'bl_idname', '') or '').strip()
    return value or str(getattr(cls, '__name__', '') or '').strip()


def _prepend_inline_feature_toggles(panels: list[type], alias: str) -> None:
    """Legacy no-op.

    Registered Panel.draw callbacks are not replaced anymore. Bundled sidebar
    Panel classes are captured without standalone registration, so no inline
    proxy toggle injection is needed.
    """
    del panels, alias
    return None


def _restore_hidden_panels() -> None:
    for cls, raw_poll in list(_HIDDEN_PANEL_POLLS.items()):
        try:
            if raw_poll is _MISSING_POLL:
                if hasattr(cls, 'poll'):
                    delattr(cls, 'poll')
            else:
                setattr(cls, 'poll', raw_poll)
        except Exception:
            pass
    _HIDDEN_PANEL_POLLS.clear()



def _panel_is_view3d_sidebar(cls: type) -> bool:
    try:
        return (
            str(getattr(cls, 'bl_space_type', '') or '') == 'VIEW_3D'
            and str(getattr(cls, 'bl_region_type', '') or '') == 'UI'
        )
    except Exception:
        return False


def _panel_order(cls: type) -> int:
    try:
        return int(getattr(cls, 'bl_order', 10_000) or 10_000)
    except Exception:
        return 10_000


def _panel_original_poll_allows(cls: type, context=None) -> bool:
    """Evaluate a Panel's pre-hide poll for root-panel embedding."""
    if not _embedded_context_safe(context):
        return False
    if cls in _HIDDEN_PANEL_POLLS:
        raw_poll = _HIDDEN_PANEL_POLLS.get(cls, _MISSING_POLL)
        if raw_poll is _MISSING_POLL:
            return True
    else:
        raw_poll = cls.__dict__.get('poll', _MISSING_POLL)
        if raw_poll is _MISSING_POLL:
            return True
    try:
        poll_func = raw_poll.__get__(cls, cls) if hasattr(raw_poll, '__get__') else raw_poll
        if callable(poll_func):
            return bool(poll_func(context))
    except Exception:
        return False
    return True


def panel_poll_allows(cls: type, context=None) -> bool:
    return _panel_original_poll_allows(cls, context)


_PANEL_LABELS: dict[str, tuple[str, str]] = {
    'VIEW3D_PT_smart_measure_grid_overlay': ('Grid Scale Overlay', 'グリッドスケール表示'),
    'VIEW3D_PT_idv_settings': ('Image Dimensions Viewer', '画像サイズビューアー'),
    'SMART_MEASURE_PT_Main': ('Smart Measure Tools', 'スマート メジャー ツール'),
    'SMART_MEASURE_PT_Edit': ('Items', '項目'),
    'SMART_MEASURE_PT_Conf': ('Configuration', '設定'),
    'SMART_MEASURE_PT_Render': ('Render', 'レンダー'),
    'VIEW3D_PT_silhouette': ('Silhouette Mode', 'シルエットモード'),
}


def _embedded_panel_label(cls: type, context=None) -> str:
    ident = _panel_identifier(cls)
    mapped = _PANEL_LABELS.get(ident) or _PANEL_LABELS.get(str(getattr(cls, '__name__', '') or ''))
    if mapped:
        return registry.localized(mapped[0], mapped[1], context)
    raw = str(getattr(cls, 'bl_label', '') or getattr(cls, '__name__', '') or '').strip()
    return registry.localized(raw, raw, context)


class _FlatEmbeddedLayoutProxy:
    __slots__ = ('_layout',)

    def __init__(self, layout):
        object.__setattr__(self, '_layout', layout)

    def __getattr__(self, name):
        return getattr(object.__getattribute__(self, '_layout'), name)

    def __setattr__(self, name, value):
        if name == '_layout':
            object.__setattr__(self, name, value)
        else:
            setattr(object.__getattribute__(self, '_layout'), name, value)

    def _wrap(self, value):
        try:
            if all(hasattr(value, attr) for attr in ('row', 'column', 'prop', 'label')):
                return _FlatEmbeddedLayoutProxy(value)
        except Exception:
            pass
        return value

    def box(self):
        # Preserve Blender's real box background.  Returning the same layout
        # removed the opaque section surfaces that standard N-panels show.
        return self._wrap(object.__getattribute__(self, '_layout').box())

    def column(self, *args, **kwargs):
        return self._wrap(object.__getattribute__(self, '_layout').column(*args, **kwargs))

    def row(self, *args, **kwargs):
        return self._wrap(object.__getattribute__(self, '_layout').row(*args, **kwargs))

    def split(self, *args, **kwargs):
        return self._wrap(object.__getattribute__(self, '_layout').split(*args, **kwargs))

    def grid_flow(self, *args, **kwargs):
        return self._wrap(object.__getattribute__(self, '_layout').grid_flow(*args, **kwargs))

    def column_flow(self, *args, **kwargs):
        return self._wrap(object.__getattribute__(self, '_layout').column_flow(*args, **kwargs))


class _EmbeddedPanelSelf:
    __slots__ = ('layout',)

    def __init__(self, layout):
        self.layout = _FlatEmbeddedLayoutProxy(layout)


def _draw_embedded_panel(cls: type, layout, context=None) -> bool:
    if not _embedded_context_safe(context):
        return False
    draw_func = getattr(cls, 'draw_embedded', None) or getattr(cls, 'draw', None)
    if not callable(draw_func):
        return False
    try:
        draw_func(_EmbeddedPanelSelf(layout), context)
        return True
    except Exception as exc:
        try:
            box = layout.box()
            _label_with_icon(box, text=registry.localized('Tool UI draw was skipped safely.', 'ツールUIの描画を安全にスキップしました。', context), custom='error', fallback='ERROR')
            box.label(text=_embedded_panel_label(cls, context))
            detail = str(exc or '')[:180]
            if detail:
                box.label(text=detail)
        except Exception:
            pass
    return False


def draw_integrated_tool_panels(layout, context=None) -> bool:
    """Draw all loaded bundled tool panels inside the single root panel.

    The original Panel classes are captured without sidebar registration. This
    function reuses their draw() implementations with a lightweight layout
    proxy so all tool UI remains available under VIEW3D_PT_sos_root instead of
    appearing as separate N-panel panels.
    """
    if layout is None:
        return False
    drew_any = False
    for record in get_records():
        if str(record.get('status') or '') != 'loaded':
            continue
        panels = [cls for cls in (record.get('panels') or ()) if _panel_is_view3d_sidebar(cls)]
        if not panels:
            continue
        panels.sort(key=lambda cls: (_panel_order(cls), _panel_identifier(cls)))
        drawable = []
        for cls in panels:
            try:
                if _panel_original_poll_allows(cls, context):
                    drawable.append(cls)
            except Exception:
                pass
        if not drawable:
            continue

        spec = record.get('spec') or {}
        alias = str(spec.get('alias') or '').strip()
        tool_title = registry.tool_label(alias, context) if alias else ''
        if not tool_title:
            tool_title = registry.localized(str(spec.get('display_name') or alias or 'Integrated Tool'), str(spec.get('display_name') or alias or '統合ツール'), context)

        tool_box = layout.box()
        try:
            tool_box.use_property_split = False
            tool_box.use_property_decorate = False
        except Exception:
            pass
        _label_with_icon(tool_box, text=tool_title, custom=alias or 'integrated', fallback='PLUGIN')

        if len(drawable) == 1:
            _draw_embedded_panel(drawable[0], tool_box, context)
        else:
            for cls in drawable:
                section = tool_box.box()
                try:
                    section.use_property_split = False
                    section.use_property_decorate = False
                except Exception:
                    pass
                _label_with_icon(section, text=_embedded_panel_label(cls, context), custom=alias or 'integrated', fallback='DOT')
                _draw_embedded_panel(cls, section, context)
        drew_any = True
    return drew_any

def _status_for_spec(spec: dict[str, Any], *, context=None, prefs=None) -> str:
    if not bool(spec.get('load', True)):
        return 'disabled'
    if not _platform_supported(str(spec.get('outer_zip') or '')):
        return 'unsupported_platform'
    return 'not_loaded'

def scan_all(*, force: bool = False, context=None, prefs=None) -> list[dict[str, Any]]:
    clear_records()
    specs = registry.build_specs(force=force)
    for spec in specs:
        record = _new_record(spec)
        record['status'] = _status_for_spec(spec, context=context, prefs=prefs)
        _RECORDS.append(record)
    return get_records()


def unload(addon_alias: str, *, context=None, prefs=None) -> dict[str, Any] | None:
    record = find_record(addon_alias)
    if record is None:
        return None

    module = record.get('module')
    if module is not None:
        try:
            _call_module_unregister_tolerant(module, record.get('panels', ()))
        except Exception:
            pass

    spec = record.get('spec') or {}
    module_name = _module_name_for_spec(spec)
    try:
        _purge_module_tree(module_name)
    except Exception:
        pass

    _drop_hidden_panels(record.get('panels', ()))
    record.update({
        'module': None,
        'registered_classes': [],
        'proxy_panels': [],
        'panels': [],
        'skipped_panel_classes': [],
        'operators': [],
        'menus': [],
        'preferences': [],
        'error': '',
        'status': _status_for_spec(spec, context=context, prefs=prefs),
    })
    return record


def refresh_enabled_states(*, context=None, prefs=None) -> list[dict[str, Any]]:
    if not _RECORDS:
        scan_all(force=False, context=context, prefs=prefs)
    for record in _RECORDS:
        spec = record.get('spec') or {}
        desired = _status_for_spec(spec, context=context, prefs=prefs)
        current = str(record.get('status') or '')
        if desired in {'disabled', 'unsupported_platform'}:
            if current == 'loaded':
                unload(str(spec.get('alias') or ''), context=context, prefs=prefs)
            record['status'] = desired
        elif current in {'not_loaded', 'available', 'ready'}:
            record['status'] = 'not_loaded'
    return get_records()

def ensure_loaded(addon_alias: str) -> dict[str, Any] | None:
    record = find_record(addon_alias)
    if record is None:
        return None

    status = str(record.get('status') or '')
    if status in {'disabled', 'unsupported_platform', 'loaded'}:
        return record

    spec = record.get('spec') or {}
    record.update({
        'module': None,
        'registered_classes': [],
        'proxy_panels': [],
        'panels': [],
        'skipped_panel_classes': [],
        'operators': [],
        'menus': [],
        'preferences': [],
        'error': '',
    })

    try:
        audit = None
        try:
            from . import tooltip_audit as audit
            audit.begin_addon_runtime_audit()
        except Exception:
            audit = None

        module = _load_module_from_spec(spec)
        record['module'] = module
        register_fn = getattr(module, 'register', None)
        _ft_alias = str((spec.get('alias') if isinstance(spec, dict) else '') or globals().get('alias', '') or 'integrated_tool').strip()
        _ft_label = str((spec.get('display_name') if isinstance(spec, dict) else '') or _ft_alias or 'Integrated Tool').strip()
        captured: list[type] = []
        with _feature_toggle.capture_addon_runtime(_ft_alias, _ft_label):
            if callable(register_fn):
                captured = _capture_registered_classes(register_fn)
        for panel_cls in _embedded_panel_classes_from_module(module):
            if panel_cls not in captured:
                captured.append(panel_cls)
        panels, operators, menus, prefs = _categorize_classes(captured)
        record['registered_classes'] = captured
        record['panels'] = panels
        record['skipped_panel_classes'] = list(panels)
        record['operators'] = operators
        record['menus'] = menus
        record['preferences'] = prefs
        # The Smart Overlay N-panel must expose a single visible Panel.
        # Integrated tool operators, menus, property groups, handlers, and RNA
        # remain registered, but their Panel classes are captured without
        # sidebar registration and drawn only inside VIEW3D_PT_sos_root.
        for panel_cls in panels:
            try:
                _unregister_existing_panel_by_name(str(getattr(panel_cls, '__name__', '') or ''))
            except Exception:
                pass
        _drop_hidden_panels(panels)
        record['status'] = 'loaded'
        if audit is not None:
            try:
                audit.finish_addon_runtime_audit()
            except Exception:
                pass
    except Exception as exc:
        try:
            if audit is not None:
                audit.abort_addon_runtime_audit()
        except Exception:
            pass
        record['status'] = 'failed'
        record['error'] = f'{exc}\n{traceback.format_exc()}'
    return record




def _purge_known_bundled_tool_sidebar_panels() -> None:
    for class_name in (
        'VIEW3D_PT_smart_measure_grid_overlay',
        'VIEW3D_PT_idv_settings',
        'SMART_MEASURE_PT_Edit',
        'SMART_MEASURE_PT_Conf',
        'SMART_MEASURE_PT_Render',
        'SMART_MEASURE_PT_Main',
        'VIEW3D_PT_silhouette',
    ):
        _unregister_existing_panel_by_name(class_name)

def register_all(*, context=None, prefs=None) -> list[dict[str, Any]]:
    try:
        _restore_hidden_panels()
    except Exception:
        pass
    try:
        _purge_known_bundled_tool_sidebar_panels()
    except Exception:
        pass
    try:
        _feature_toggle.register_ui()
    except Exception:
        pass
    scan_all(force=False, context=context, prefs=prefs)
    for record in list(_RECORDS):
        alias = str((record.get('spec') or {}).get('alias') or '')
        if alias:
            ensure_loaded(alias)
    return get_records()

def unregister_all() -> None:
    try:
        _feature_toggle.unregister_all()
    except Exception:
        pass
    for record in reversed(_RECORDS):
        try:
            unload(str((record.get('spec') or {}).get('alias') or ''))
        except Exception:
            pass
    _restore_hidden_panels()
    clear_records()
    registry.clear_cache()
