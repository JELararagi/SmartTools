# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import json
import re
import time
from contextlib import AbstractContextManager
from pathlib import Path
from typing import Any, Callable

import bpy

from . import storage
from . import icons as sos_icons

_SUITE_KEY = ''
_SUITE_LABEL = ''
_CATEGORY = ''
_OPERATOR_ID = ''
_REGISTERED_CLASSES: list[type] = []
_FEATURES: dict[str, dict[str, dict[str, Any]]] = {}
_STATE_CACHE: dict[str, dict[str, bool]] | None = None
_PREFS_STORAGE_PROP = 'sos_persistent_feature_toggles_json'
_MIGRATION_DONE = False
_CAPTURE_STACK: list['_RuntimeCapture'] = []
_PATCH_DEPTH = 0
_ORIGINALS: dict[str, Any] = {}
_ORIGINAL_DRAW_ADDS: dict[str, Any] = {}
_ORIGINAL_DRAW_REMOVES: dict[str, Any] = {}
_DUMMY_COUNTER = 0


def _SICON(name: str = '', fallback: str = 'NONE') -> int:
    try:
        return int(sos_icons.icon_value(name, fallback) or 0)
    except Exception:
        return 0


def _icon_kwargs(name: str = '', fallback: str = 'NONE') -> dict:
    try:
        return sos_icons.icon_kwargs(name, fallback)
    except Exception:
        return {'icon': str(fallback or 'NONE')}


def _tool_icon(alias: str = '', feature_key: str = '') -> str:
    text = f'{alias} {feature_key}'.lower()
    # Feature runtime type has priority because the row toggles a specific
    # background mechanism, not merely the parent tool.
    if 'draw_handler' in text or 'draw handler' in text or 'draw' in text:
        return 'eye'
    if 'timer' in text:
        return 'always_on'
    if 'keymap' in text:
        return 'settings'
    if 'msgbus' in text or 'message' in text:
        return 'link'
    if 'handler' in text:
        return 'script'
    if 'grid' in text:
        return 'grid'
    if 'image' in text and 'node' in text:
        return 'image_node'
    if 'image' in text:
        return 'image_editor'
    if 'measure' in text:
        return 'measure'
    if 'silhouette' in text:
        return 'silhouette'
    return 'integrated'

_KIND_ORDER = ('handlers', 'timers', 'msgbus', 'draw_handlers')
_KIND_INFO = {
    'handlers': {
        'label_en': 'Automatic Event Processing',
        'label_ja': '自動イベント処理',
        'description_en': 'Enables processing that Blender runs automatically on file loading, saving, frame changes, scene updates, undo, redo, or rendering. Use this only when this feature must react in the background. The setting is saved immediately and remains after Blender restarts and scene changes.',
        'description_ja': 'ファイルの読込・保存、フレーム変更、シーンの更新、元に戻す・やり直し、レンダーなどで自動的に動く処理を有効化します。この機能をバックグラウンドで反応させたい場合だけ有効にしてください。設定は即時保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    },
    'timers': {
        'label_en': 'Background Timers',
        'label_ja': 'バックグラウンドタイマー',
        'description_en': 'Enables timer callbacks that run after a delay or repeatedly without pressing a button. Use this only when this feature must keep checking or updating data automatically. The setting is saved immediately and remains after Blender restarts and scene changes.',
        'description_ja': 'ボタン操作なしで、一定時間後または一定間隔で実行されるタイマー処理を有効化します。この機能で自動チェックや自動更新が必要な場合だけ有効にしてください。設定は即時保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    },
    'msgbus': {
        'label_en': 'Data Change Watchers',
        'label_ja': 'データ変更の監視',
        'description_en': 'Watches Blender data and runs this feature automatically when the watched values change. Use this only when this feature must monitor Blender data in real time. The setting is saved immediately and remains after Blender restarts and scene changes.',
        'description_ja': 'Blender のデータを監視し、値が変わった時にこの機能を自動で動かします。リアルタイムの監視が必要な場合だけ有効にしてください。設定は即時保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    },
    'keymaps': {
        'label_en': 'Hotkeys',
        'label_ja': 'ホットキー',
        'description_en': 'Enables keymap items and shortcuts for this feature. Use this when you want the feature to respond to keyboard or mouse shortcuts. The setting is saved immediately and remains after Blender restarts and scene changes.',
        'description_ja': 'この機能用のキーマップ項目・ショートカットを有効化します。キーボードやマウスのショートカットで機能を操作したい場合に有効にしてください。設定は即時保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    },
    'draw_handlers': {
        'label_en': 'Viewport / Editor Draw',
        'label_ja': 'ビューポート・エディター描画',
        'description_en': 'Keeps drawing overlays or helper graphics in the viewport or editors. Use this only when this feature must show live guides or overlays automatically. The setting is saved immediately and remains after Blender restarts and scene changes.',
        'description_ja': 'ビューポートや各エディターにオーバーレイ・補助表示を描き続けます。この機能のライブガイドやオーバーレイ表示が必要な場合だけ有効にしてください。設定は即時保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    },
}

_SPACE_CLASS_NAMES = (
    'SpaceView3D', 'SpaceImageEditor', 'SpaceNodeEditor', 'SpaceSequenceEditor',
    'SpaceClipEditor', 'SpaceDopeSheetEditor', 'SpaceGraphEditor', 'SpaceNLA',
    'SpaceTextEditor', 'SpaceConsole', 'SpaceInfo', 'SpaceProperties',
    'SpaceFileBrowser', 'SpaceSpreadsheet', 'SpaceOutliner', 'SpacePreferences',
)


def _clean_identifier(value: str, fallback: str = 'smart_overlay_suite') -> str:
    text = str(value or '').strip().split('.')[-1]
    text = re.sub(r'[^0-9A-Za-z_]+', '_', text)
    text = re.sub(r'_+', '_', text).strip('_').lower()
    return text or fallback


def _title_from_key(value: str) -> str:
    text = str(value or '').strip().split('.')[-1]
    text = text.replace('_suite', '').replace('_', ' ').strip()
    if not text:
        return 'Smart Overlay N-panel'
    return ' '.join(part[:1].upper() + part[1:] for part in text.split())


def _infer_suite_key() -> str:
    package = str(__package__ or '').strip('.')
    if package:
        parts = [p for p in package.split('.') if p]
        if 'user_default' in parts:
            idx = parts.index('user_default')
            if idx + 1 < len(parts):
                return _clean_identifier(parts[idx + 1])
        # Any other repository: bl_ext.<repo>.<id> (1101 fix; parts[0] was 'bl_ext' and every suite collided).
        if len(parts) >= 3 and parts[0] == 'bl_ext':
            return _clean_identifier(parts[2])
        if parts:
            return _clean_identifier(parts[0])
    return 'smart_overlay_suite'


def _infer_category(suite_key: str) -> str:
    title = _title_from_key(suite_key)
    return title if title.lower().startswith('smart ') else f'Smart {title}'


def configure(*, suite_key: str | None = None, suite_label: str | None = None, category: str | None = None) -> None:
    global _SUITE_KEY, _SUITE_LABEL, _CATEGORY, _OPERATOR_ID
    if not _SUITE_KEY:
        _SUITE_KEY = _clean_identifier(suite_key or _infer_suite_key())
    if suite_key:
        _SUITE_KEY = _clean_identifier(suite_key)
    if suite_label:
        _SUITE_LABEL = str(suite_label).strip()
    if not _SUITE_LABEL:
        _SUITE_LABEL = _title_from_key(_SUITE_KEY)
    if category:
        _CATEGORY = str(category).strip()
    if not _CATEGORY:
        _CATEGORY = _infer_category(_SUITE_KEY)
    _OPERATOR_ID = f'{_SUITE_KEY}.toggle_persistent_feature'


def _is_ja(context=None) -> bool:
    try:
        prefs = getattr(getattr(context, 'preferences', None), 'view', None) if context is not None else getattr(getattr(bpy.context, 'preferences', None), 'view', None)
        lang = str(getattr(prefs, 'language', '') or '').lower()
    except Exception:
        lang = ''
    try:
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '').lower()
    except Exception:
        locale = ''
    return lang.startswith('ja') or locale.startswith('ja') or 'japanese' in lang


def _t(context, en: str, ja: str) -> str:
    return str(ja if _is_ja(context) else en)


def _static_t(en: str, ja: str) -> str:
    return str(ja if _is_ja(None) else en)


def _addon_preferences(context=None):
    ctx = context or getattr(bpy, 'context', None)
    try:
        from . import registry
        prefs = registry.resolve_addon_preferences(ctx)
        if prefs is not None:
            return prefs
    except Exception:
        pass
    try:
        addons = getattr(getattr(ctx, 'preferences', None), 'addons', None)
        if addons is None:
            return None
        for key in (__package__, 'smart_overlay', 'smart_overlay_suite'):
            try:
                return addons[str(key)].preferences
            except Exception:
                pass
    except Exception:
        pass
    return None


def _state_payload_from_text(text: str | None) -> tuple[dict[str, dict[str, bool]], float]:
    data: dict[str, dict[str, bool]] = {}
    saved_at = 0.0
    if not text:
        return data, saved_at
    try:
        raw = json.loads(str(text))
        if not isinstance(raw, dict):
            return data, saved_at
        if isinstance(raw.get('state'), dict):
            try:
                saved_at = float(raw.get('saved_at') or raw.get('_saved_at') or 0.0)
            except Exception:
                saved_at = 0.0
            raw_state = raw.get('state')
        else:
            raw_state = raw
        if isinstance(raw_state, dict):
            for alias, values in raw_state.items():
                alias_text = str(alias or '').strip()
                if not alias_text or alias_text.startswith('__'):
                    continue
                if isinstance(values, dict):
                    data[alias_text] = {str(k): bool(v) for k, v in values.items() if not str(k).startswith('__')}
    except Exception:
        data = {}
        saved_at = 0.0
    return data, saved_at


def _state_from_text(text: str | None) -> dict[str, dict[str, bool]]:
    data, _saved_at = _state_payload_from_text(text)
    return data


def _state_payload_text(state: dict[str, dict[str, bool]] | None = None, *, saved_at: float | None = None) -> str:
    stamp = time.time() if saved_at is None else float(saved_at)
    return json.dumps({
        'version': 2,
        'saved_at': stamp,
        'state': state if isinstance(state, dict) else _load_state(),
    }, ensure_ascii=False, indent=2, sort_keys=True)


def _state_from_preferences(context=None) -> dict[str, dict[str, bool]]:
    prefs = _addon_preferences(context)
    if prefs is None or not hasattr(prefs, _PREFS_STORAGE_PROP):
        return {}
    try:
        return _state_from_text(getattr(prefs, _PREFS_STORAGE_PROP, ''))
    except Exception:
        return {}


def _save_state_to_preferences(context=None, *, state: dict[str, dict[str, bool]] | None = None, saved_at: float | None = None) -> bool:
    prefs = _addon_preferences(context)
    if prefs is None or not hasattr(prefs, _PREFS_STORAGE_PROP):
        return False
    try:
        text = _state_payload_text(state if state is not None else _load_state(), saved_at=saved_at)
        if str(getattr(prefs, _PREFS_STORAGE_PROP, '') or '') != text:
            setattr(prefs, _PREFS_STORAGE_PROP, text)
        return True
    except Exception:
        return False


def _legacy_state_paths(target_path: Path | None) -> tuple[Path, ...]:
    paths: list[Path] = []
    try:
        filename = target_path.name if target_path is not None else f'{_SUITE_KEY}_persistent_feature_toggles.json'
    except Exception:
        filename = f'{_SUITE_KEY}_persistent_feature_toggles.json'
    user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
    if callable(user_resource):
        for directory in ('SmartOverlayToolset', ''.join(('Smart Overlay_', 'Smart', 'Tools'))):
            try:
                paths.append(Path(user_resource('CONFIG', path=directory, create=False)) / filename)
            except Exception:
                pass
    return tuple(paths)


def _migrate_legacy_state_files(target_path: Path | None) -> None:
    global _MIGRATION_DONE
    if _MIGRATION_DONE:
        return
    _MIGRATION_DONE = True
    for legacy_path in _legacy_state_paths(target_path):
        try:
            if storage.migrate_legacy_file(legacy_path, target_path, remove_legacy=True):
                break
        except Exception:
            pass


def _legacy_settings_path() -> Path | None:
    configure()
    try:
        base = storage.addon_storage_dir('settings', create=False)
        path = base / f'{_SUITE_KEY}_persistent_feature_toggles.json'
        _migrate_legacy_state_files(path)
        return path
    except Exception:
        return None


def _load_state() -> dict[str, dict[str, bool]]:
    global _STATE_CACHE
    if _STATE_CACHE is not None:
        return _STATE_CACHE
    prefs_state: dict[str, dict[str, bool]] = {}
    prefs_stamp = 0.0
    file_state: dict[str, dict[str, bool]] = {}
    file_stamp = 0.0
    prefs = _addon_preferences(getattr(bpy, 'context', None))
    try:
        prefs_state, prefs_stamp = _state_payload_from_text(getattr(prefs, _PREFS_STORAGE_PROP, ''))
    except Exception:
        prefs_state, prefs_stamp = {}, 0.0
    path = _legacy_settings_path()
    if path is not None and path.exists():
        try:
            file_state, file_stamp = _state_payload_from_text(path.read_text(encoding='utf-8'))
        except Exception:
            file_state, file_stamp = {}, 0.0
    if prefs_state and (not file_state or prefs_stamp > file_stamp):
        _STATE_CACHE = prefs_state
    elif file_state:
        _STATE_CACHE = file_state
    else:
        _STATE_CACHE = prefs_state
    return _STATE_CACHE


def _save_state(context=None, *, force: bool = False) -> None:
    """Compatibility hook for older per-feature persistence.

    Feature toggle state is now persisted by settings.py through the single
    Smart_Overlay_Suite.json file in Blender's config directory.  The in-memory
    state is already updated before this function is called, so no sidecar JSON
    is written here.  Legacy sidecar files are still read by _load_state() for
    backward compatibility.
    """
    del context, force
    return None


def get_state_snapshot() -> dict[str, dict[str, bool]]:
    """Return a copy of the persistent feature-toggle state for the main Smart Overlay JSON."""
    state = _load_state()
    return {str(alias): {str(key): bool(value) for key, value in dict(features or {}).items()} for alias, features in dict(state or {}).items()}


def apply_state_snapshot(data) -> None:
    """Apply a feature-toggle snapshot loaded from Smart_Overlay_Suite.json."""
    global _STATE_CACHE
    if not isinstance(data, dict):
        return
    restored: dict[str, dict[str, bool]] = {}
    for alias, features in data.items():
        if not isinstance(features, dict):
            continue
        alias_key = str(alias or '').strip()
        if not alias_key:
            continue
        restored[alias_key] = {str(key): bool(value) for key, value in features.items() if str(key or '').strip()}
    if not restored:
        return
    _STATE_CACHE = restored
    for alias, features in restored.items():
        for feature_key, enabled in features.items():
            feature = _FEATURES.get(alias, {}).get(feature_key)
            if feature is not None:
                try:
                    _set_feature_active(feature, bool(enabled))
                except Exception:
                    pass


def is_feature_enabled(alias: str, feature_key: str) -> bool:
    alias = str(alias or '').strip()
    feature_key = str(feature_key or '').strip()
    return bool(_load_state().get(alias, {}).get(feature_key, False))


def set_feature_enabled(alias: str, feature_key: str, enabled: bool) -> bool:
    alias = str(alias or '').strip()
    feature_key = str(feature_key or '').strip()
    if not alias or not feature_key:
        return False
    _load_state().setdefault(alias, {})[feature_key] = bool(enabled)
    _save_state(getattr(bpy, 'context', None))
    try:
        from . import settings as _sos_settings
        _sos_settings.queue_save(getattr(bpy, 'context', None), reason='feature_toggle')
    except Exception:
        pass
    feature = _FEATURES.get(alias, {}).get(feature_key)
    if feature is not None:
        _set_feature_active(feature, bool(enabled))
    _tag_redraw()
    return True


def _feature_record(alias: str, tool_label: str, feature_key: str) -> dict[str, Any]:
    alias = str(alias or '').strip()
    tool_label = str(tool_label or alias or 'Integrated Tool').strip()
    feature_key = str(feature_key or '').strip()
    info = _KIND_INFO.get(feature_key, {})
    features = _FEATURES.setdefault(alias, {})
    feature = features.get(feature_key)
    if feature is None:
        feature = {
            'alias': alias,
            'tool_label': tool_label,
            'key': feature_key,
            'label_en': str(info.get('label_en') or feature_key),
            'label_ja': str(info.get('label_ja') or feature_key),
            'description_en': str(info.get('description_en') or ''),
            'description_ja': str(info.get('description_ja') or ''),
            'actions': [],
        }
        features[feature_key] = feature
    else:
        feature['tool_label'] = tool_label
    return feature


def _add_action(alias: str, tool_label: str, feature_key: str, action: dict[str, Any]) -> None:
    feature = _feature_record(alias, tool_label, feature_key)
    feature.setdefault('actions', []).append(action)


def feature_entries(alias: str | None = None) -> list[dict[str, Any]]:
    aliases = [str(alias).strip()] if alias else sorted(_FEATURES.keys())
    out: list[dict[str, Any]] = []
    for alias_key in aliases:
        feature_map = _FEATURES.get(alias_key, {})
        for key in _KIND_ORDER:
            feature = feature_map.get(key)
            if not feature or not feature.get('actions'):
                continue
            item = dict(feature)
            item['enabled'] = is_feature_enabled(alias_key, key)
            item['action_count'] = len(feature.get('actions') or [])
            out.append(item)
    return out


def all_feature_aliases() -> tuple[str, ...]:
    return tuple(sorted(alias for alias, items in _FEATURES.items() if any((f.get('actions') for f in items.values()))))


def _snapshot_handlers() -> dict[str, set[int]]:
    result: dict[str, set[int]] = {}
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    if handlers is None:
        return result
    for name in dir(handlers):
        if name.startswith('_') or name == 'persistent':
            continue
        try:
            seq = getattr(handlers, name)
        except Exception:
            continue
        if not hasattr(seq, 'append') or not hasattr(seq, 'remove'):
            continue
        try:
            result[name] = {id(item) for item in list(seq)}
        except Exception:
            continue
    return result


def _collect_new_handlers(before: dict[str, set[int]]) -> list[dict[str, Any]]:
    actions: list[dict[str, Any]] = []
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    if handlers is None:
        return actions
    for name, before_ids in before.items():
        try:
            seq = getattr(handlers, name)
            current = list(seq)
        except Exception:
            continue
        for fn in current:
            if id(fn) not in before_ids:
                actions.append({'kind': 'handlers', 'list_name': name, 'fn': fn, 'active': True})
    return actions


def _keymap_item_identity(kmi) -> int:
    try:
        ptr = int(getattr(kmi, 'as_pointer', lambda: 0)() or 0)
        if ptr:
            return ptr
    except Exception:
        pass
    return id(kmi)


def _snapshot_keymaps() -> set[int]:
    ids: set[int] = set()
    try:
        kc = bpy.context.window_manager.keyconfigs.addon
        for km in kc.keymaps:
            try:
                items = list(km.keymap_items)
            except Exception:
                items = []
            for kmi in items:
                ids.add(_keymap_item_identity(kmi))
    except Exception:
        pass
    return ids


def _copy_keymap_properties(kmi) -> dict[str, Any]:
    # Do not touch KeyMapItem.properties during startup capture.
    # In Blender 5.1 this RNA getter can dereference an invalid native pointer
    # for some keymap items and crash Blender before Python can raise/catch an
    # exception. The runtime stores and toggles the live KeyMapItem instead of
    # rebuilding it from copied operator properties.
    return {}


def _is_invalid_tool_set_keymap_action(action: dict[str, Any]) -> bool:
    try:
        idname = str(action.get('idname') or '').strip()
    except Exception:
        idname = ''
    if idname != 'wm.tool_set_by_id':
        return False
    # KeyMapItem.properties is intentionally not inspected on Blender 5.1
    # startup, because that getter is the confirmed crash point. Only treat a
    # tool_set keymap as invalid when another safe code path explicitly supplied
    # known properties and proved that the tool id/name is blank.
    if not bool(action.get('properties_known', False)):
        return False
    props = action.get('properties') or {}
    for prop_name in ('name', 'idname', 'tool_id'):
        try:
            if str(props.get(prop_name) or '').strip():
                return False
        except Exception:
            pass
    return True


def _describe_keymap_item(km, kmi) -> dict[str, Any]:
    def _get(obj, name: str, default=None):
        try:
            return getattr(obj, name)
        except Exception:
            return default
    return {
        'kind': 'keymaps',
        'km_name': str(_get(km, 'name', '') or ''),
        'space_type': str(_get(km, 'space_type', 'EMPTY') or 'EMPTY'),
        'region_type': str(_get(km, 'region_type', 'WINDOW') or 'WINDOW'),
        'modal': bool(_get(km, 'is_modal', False)),
        'idname': str(_get(kmi, 'idname', '') or ''),
        'type': str(_get(kmi, 'type', 'NONE') or 'NONE'),
        'value': str(_get(kmi, 'value', 'PRESS') or 'PRESS'),
        'any': bool(_get(kmi, 'any', False)),
        'shift': bool(_get(kmi, 'shift', False)),
        'ctrl': bool(_get(kmi, 'ctrl', False)),
        'alt': bool(_get(kmi, 'alt', False)),
        'oskey': bool(_get(kmi, 'oskey', False)),
        'key_modifier': str(_get(kmi, 'key_modifier', 'NONE') or 'NONE'),
        'direction': str(_get(kmi, 'direction', 'ANY') or 'ANY'),
        'repeat': bool(_get(kmi, 'repeat', False)),
        'properties': _copy_keymap_properties(kmi),
        'properties_known': False,
        'km': km,
        'kmi': kmi,
        'active_km': km,
        'active_kmi': kmi,
        'active': True,
    }


def _collect_new_keymaps(before: set[int]) -> list[dict[str, Any]]:
    actions: list[dict[str, Any]] = []
    try:
        kc = bpy.context.window_manager.keyconfigs.addon
        for km in kc.keymaps:
            try:
                items = list(km.keymap_items)
            except Exception:
                items = []
            for kmi in items:
                if _keymap_item_identity(kmi) not in before:
                    action = _describe_keymap_item(km, kmi)
                    if _is_invalid_tool_set_keymap_action(action):
                        _remove_action(action)
                        continue
                    actions.append(action)
    except Exception:
        pass
    return actions


def _delete_keymap_action(action: dict[str, Any]) -> None:
    """Remove a just-created captured KeyMapItem and never persist it.

    Smart Overlay no longer manages Preferences > Keymap entries automatically.
    Integrated tools that create shortcut items during registration are cleaned up
    immediately; public shortcuts are shown as manual operator IDs in their own UI
    sections instead.
    """
    try:
        km = action.get('active_km') or action.get('km')
        kmi = action.get('active_kmi') or action.get('kmi')
        if km is not None and kmi is not None:
            try:
                km.keymap_items.remove(kmi)
            except Exception:
                try:
                    kmi.active = False
                except Exception:
                    pass
    except Exception:
        pass
    action['active_km'] = None
    action['active_kmi'] = None
    action['active'] = False


def _remove_action(action: dict[str, Any]) -> None:
    kind = str(action.get('kind') or '')
    if not bool(action.get('active', False)):
        return
    try:
        if kind == 'handlers':
            handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
            seq = getattr(handlers, str(action.get('list_name') or ''), None) if handlers is not None else None
            fn = action.get('fn')
            if seq is not None and fn in seq:
                seq.remove(fn)
        elif kind == 'timers':
            timers = getattr(getattr(bpy, 'app', None), 'timers', None)
            fn = action.get('fn')
            if timers is not None and callable(fn):
                try:
                    if hasattr(timers, 'is_registered') and timers.is_registered(fn):
                        timers.unregister(fn)
                except Exception:
                    try:
                        timers.unregister(fn)
                    except Exception:
                        pass
        elif kind == 'msgbus':
            owner = action.get('owner')
            if owner is not None:
                try:
                    bpy.msgbus.clear_by_owner(owner)
                except Exception:
                    pass
        elif kind == 'draw_handlers':
            handle = action.get('handle')
            space_cls = action.get('space_cls')
            region_type = action.get('region_type')
            if handle is not None and space_cls is not None:
                try:
                    remove = _ORIGINAL_DRAW_REMOVES.get(str(action.get('space_name') or '')) or getattr(space_cls, 'draw_handler_remove', None)
                    if callable(remove):
                        remove(handle, region_type)
                except Exception:
                    pass
                action['handle'] = None
        elif kind == 'keymaps':
            km = action.get('active_km') or action.get('km')
            kmi = action.get('active_kmi') or action.get('kmi')
            if km is not None and kmi is not None:
                # Blender 5.1 can crash in rna_KeyMap_item_remove() when a
                # stale KeyMapItem is removed during application shutdown.
                # Disabling the item provides the same user-facing inactive
                # state without calling the unsafe native remove path.
                try:
                    kmi.active = False
                except Exception:
                    pass
            action['active_km'] = None
            action['active_kmi'] = None
    finally:
        action['active'] = False


def _apply_keymap_action(action: dict[str, Any]) -> None:
    """No-op: Smart Overlay must never auto-create Preferences > Keymap items."""
    action['active'] = False
    action['active_km'] = None
    action['active_kmi'] = None
    return None


def _apply_action(action: dict[str, Any]) -> None:
    if bool(action.get('active', False)):
        return
    kind = str(action.get('kind') or '')
    try:
        if kind == 'handlers':
            handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
            seq = getattr(handlers, str(action.get('list_name') or ''), None) if handlers is not None else None
            fn = action.get('fn')
            if seq is not None and callable(fn) and fn not in seq:
                seq.append(fn)
                action['active'] = True
        elif kind == 'timers':
            timers = getattr(getattr(bpy, 'app', None), 'timers', None)
            fn = action.get('fn')
            if timers is not None and callable(fn):
                register = _ORIGINALS.get('timer_register') or timers.register
                try:
                    if hasattr(timers, 'is_registered') and timers.is_registered(fn):
                        action['active'] = True
                        return
                except Exception:
                    pass
                register(fn, *tuple(action.get('args') or ()), **dict(action.get('kwargs') or {}))
                action['active'] = True
        elif kind == 'msgbus':
            subscribe = _ORIGINALS.get('msgbus_subscribe') or getattr(bpy.msgbus, 'subscribe_rna', None)
            if callable(subscribe):
                subscribe(*tuple(action.get('args') or ()), **dict(action.get('kwargs') or {}))
                action['active'] = True
        elif kind == 'draw_handlers':
            space_cls = action.get('space_cls')
            add = _ORIGINAL_DRAW_ADDS.get(str(action.get('space_name') or '')) or getattr(space_cls, 'draw_handler_add', None)
            if callable(add):
                action['handle'] = add(*tuple(action.get('args') or ()), **dict(action.get('kwargs') or {}))
                action['active'] = True
        elif kind == 'keymaps':
            _apply_keymap_action(action)
    except Exception:
        action['active'] = False


def _set_feature_active(feature: dict[str, Any], enabled: bool) -> None:
    actions = list(feature.get('actions') or [])
    if enabled:
        for action in actions:
            _apply_action(action)
    else:
        for action in reversed(actions):
            _remove_action(action)


def deactivate_alias(alias: str) -> None:
    for feature in list(_FEATURES.get(str(alias or '').strip(), {}).values()):
        _set_feature_active(feature, False)


def clear_alias(alias: str) -> None:
    alias = str(alias or '').strip()
    deactivate_alias(alias)
    _FEATURES.pop(alias, None)


def _current_capture() -> '_RuntimeCapture | None':
    return _CAPTURE_STACK[-1] if _CAPTURE_STACK else None


class _DummyDrawHandle:
    def __init__(self, label: str):
        self.label = label


def _next_dummy_handle() -> _DummyDrawHandle:
    global _DUMMY_COUNTER
    _DUMMY_COUNTER += 1
    return _DummyDrawHandle(f'disabled_draw_handler_{_DUMMY_COUNTER}')


def _timer_register_proxy(function, *args, **kwargs):
    cap = _current_capture()
    if cap is None:
        return _ORIGINALS['timer_register'](function, *args, **kwargs)
    action = {'kind': 'timers', 'fn': function, 'args': tuple(args), 'kwargs': dict(kwargs), 'active': False}
    cap.record_action('timers', action)
    if cap.kind_enabled('timers'):
        result = _ORIGINALS['timer_register'](function, *args, **kwargs)
        action['active'] = True
        return result
    return None


def _msgbus_subscribe_proxy(*args, **kwargs):
    cap = _current_capture()
    if cap is None:
        return _ORIGINALS['msgbus_subscribe'](*args, **kwargs)
    owner = kwargs.get('owner')
    if owner is None and len(args) >= 2:
        owner = args[1]
    action = {'kind': 'msgbus', 'args': tuple(args), 'kwargs': dict(kwargs), 'owner': owner, 'active': False}
    cap.record_action('msgbus', action)
    if cap.kind_enabled('msgbus'):
        result = _ORIGINALS['msgbus_subscribe'](*args, **kwargs)
        action['active'] = True
        return result
    return None


def _make_draw_add_proxy(space_name: str, space_cls, original_add):
    def _proxy(*args, **kwargs):
        cap = _current_capture()
        if cap is None:
            return original_add(*args, **kwargs)
        region_type = args[2] if len(args) >= 3 else kwargs.get('region_type')
        action = {
            'kind': 'draw_handlers',
            'space_name': space_name,
            'space_cls': space_cls,
            'args': tuple(args),
            'kwargs': dict(kwargs),
            'region_type': region_type,
            'handle': None,
            'active': False,
        }
        cap.record_action('draw_handlers', action)
        if cap.kind_enabled('draw_handlers'):
            action['handle'] = original_add(*args, **kwargs)
            action['active'] = True
            return action['handle']
        return _next_dummy_handle()
    return _proxy


def _install_patches() -> None:
    global _PATCH_DEPTH
    _PATCH_DEPTH += 1
    if _PATCH_DEPTH > 1:
        return
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and 'timer_register' not in _ORIGINALS:
            _ORIGINALS['timer_register'] = timers.register
            timers.register = _timer_register_proxy
    except Exception:
        pass
    try:
        msgbus = getattr(bpy, 'msgbus', None)
        if msgbus is not None and 'msgbus_subscribe' not in _ORIGINALS:
            _ORIGINALS['msgbus_subscribe'] = msgbus.subscribe_rna
            msgbus.subscribe_rna = _msgbus_subscribe_proxy
    except Exception:
        pass
    for space_name in _SPACE_CLASS_NAMES:
        try:
            space_cls = getattr(bpy.types, space_name, None)
            if space_cls is None:
                continue
            add = getattr(space_cls, 'draw_handler_add', None)
            remove = getattr(space_cls, 'draw_handler_remove', None)
            if not callable(add) or space_name in _ORIGINAL_DRAW_ADDS:
                continue
            _ORIGINAL_DRAW_ADDS[space_name] = add
            if callable(remove):
                _ORIGINAL_DRAW_REMOVES[space_name] = remove
            setattr(space_cls, 'draw_handler_add', staticmethod(_make_draw_add_proxy(space_name, space_cls, add)))
        except Exception:
            continue


def _uninstall_patches() -> None:
    global _PATCH_DEPTH
    _PATCH_DEPTH = max(0, _PATCH_DEPTH - 1)
    if _PATCH_DEPTH > 0:
        return
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        original = _ORIGINALS.pop('timer_register', None)
        if timers is not None and original is not None:
            timers.register = original
    except Exception:
        pass
    try:
        msgbus = getattr(bpy, 'msgbus', None)
        original = _ORIGINALS.pop('msgbus_subscribe', None)
        if msgbus is not None and original is not None:
            msgbus.subscribe_rna = original
    except Exception:
        pass
    for space_name, add in list(_ORIGINAL_DRAW_ADDS.items()):
        try:
            space_cls = getattr(bpy.types, space_name, None)
            if space_cls is not None:
                setattr(space_cls, 'draw_handler_add', add)
        except Exception:
            pass
    _ORIGINAL_DRAW_ADDS.clear()


class _CaptureSuspend(AbstractContextManager):
    def __enter__(self):
        self._saved_stack = list(_CAPTURE_STACK)
        _CAPTURE_STACK.clear()
        return self

    def __exit__(self, exc_type, exc, tb):
        _CAPTURE_STACK[:] = getattr(self, '_saved_stack', [])
        return False


def suspend_capture() -> _CaptureSuspend:
    """Temporarily bypass addon_runtime capture while keeping installed proxies safe."""
    return _CaptureSuspend()


class _RuntimeCapture(AbstractContextManager):
    def __init__(self, alias: str, tool_label: str | None = None):
        configure()
        self.alias = str(alias or '').strip()
        self.tool_label = str(tool_label or self.alias or 'Integrated Tool').strip()
        self._before_handlers: dict[str, set[int]] = {}
        self._before_keymaps: set[int] = set()

    def __enter__(self):
        self._before_handlers = _snapshot_handlers()
        self._before_keymaps = _snapshot_keymaps()
        _CAPTURE_STACK.append(self)
        _install_patches()
        return self

    def __exit__(self, exc_type, exc, tb):
        try:
            for action in _collect_new_handlers(self._before_handlers):
                self.record_action('handlers', action)
                if not self.kind_enabled('handlers'):
                    _remove_action(action)
            for action in _collect_new_keymaps(self._before_keymaps):
                _delete_keymap_action(action)
        finally:
            if self in _CAPTURE_STACK:
                _CAPTURE_STACK.remove(self)
            _uninstall_patches()
            _tag_redraw()
        return False

    def kind_enabled(self, feature_key: str) -> bool:
        return is_feature_enabled(self.alias, feature_key)

    def record_action(self, feature_key: str, action: dict[str, Any]) -> None:
        if self.alias and feature_key:
            _add_action(self.alias, self.tool_label, feature_key, action)


def capture_addon_runtime(alias: str, tool_label: str | None = None) -> _RuntimeCapture:
    return _RuntimeCapture(alias, tool_label)


def capture_call(alias: str, tool_label: str | None, callback: Callable[[], Any]) -> Any:
    with capture_addon_runtime(alias, tool_label):
        return callback()


def _tag_redraw() -> None:
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                if getattr(area, 'type', None) in {'VIEW_3D', 'IMAGE_EDITOR'}:
                    area.tag_redraw()
    except Exception:
        pass


def _operator_description(context, properties) -> str:
    alias = str(getattr(properties, 'alias', '') or '')
    feature_key = str(getattr(properties, 'feature_key', '') or '')
    feature = _FEATURES.get(alias, {}).get(feature_key)
    if feature:
        label = _t(context, feature.get('label_en', ''), feature.get('label_ja', ''))
        desc = _t(context, feature.get('description_en', ''), feature.get('description_ja', ''))
        state = _t(context, 'Click to switch this feature between enabled and disabled.', 'クリックすると、この機能の有効・無効を切り替えます。')
        return f'{label}: {desc} {state}'
    return _t(context, 'Toggle an always-on Smart Overlay N-panel feature. The setting is saved immediately.', 'Smart Overlay Nパネルの常時機能を切り替えます。設定は即時保存されます。')


def register_ui(*, suite_key: str | None = None, suite_label: str | None = None, category: str | None = None) -> None:
    configure(suite_key=suite_key, suite_label=suite_label, category=category)
    if _REGISTERED_CLASSES:
        return
    operator_id = _OPERATOR_ID

    class SMART_OVERLAY_OT_toggle_persistent_feature(bpy.types.Operator):
        bl_idname = operator_id
        bl_options = {'UNDO'}
        bl_undo_group = 'Smart Overlay Suite'
        bl_label = 'Toggle Feature'
        bl_description = 'Switch an always-on feature on or off and save the setting immediately.'

        alias: bpy.props.StringProperty(
            name='Tool Alias',
            description='Internal identifier of the integrated Smart Overlay tool whose always-on feature will be toggled.',
            default='',
            options={'HIDDEN', 'SKIP_SAVE'},
        )
        feature_key: bpy.props.StringProperty(
            name='Feature Key',
            description='Internal identifier of the captured handler, timer, keymap, message-bus watcher, or draw handler to switch on or off.',
            default='',
            options={'HIDDEN', 'SKIP_SAVE'},
        )
        enabled: bpy.props.BoolProperty(
            name='Enabled',
            description='Target state for this saved always-on feature toggle. ON keeps the feature active; OFF stops its background processing where possible.',
            default=True,
            options={'HIDDEN', 'SKIP_SAVE'},
        )

        @classmethod
        def description(cls, context, properties):
            return _operator_description(context, properties)

        def execute(self, context):
            alias = str(getattr(self, 'alias', '') or '')
            feature_key = str(getattr(self, 'feature_key', '') or '')
            desired = bool(getattr(self, 'enabled', True))
            if not set_feature_enabled(alias, feature_key, desired):
                self.report({'WARNING'}, _t(context, 'The selected feature could not be changed.', '選択した機能を変更できませんでした。'))
                return {'CANCELLED'}
            self.report({'INFO'}, _t(context, 'Feature setting saved.', '機能設定を保存しました。'))
            return {'FINISHED'}

    SMART_OVERLAY_OT_toggle_persistent_feature.__name__ = f"SMART_OVERLAY_OT_{_SUITE_KEY.upper()}_TOGGLE_PERSISTENT_FEATURE"
    SMART_OVERLAY_OT_toggle_persistent_feature.__qualname__ = SMART_OVERLAY_OT_toggle_persistent_feature.__name__
    SMART_OVERLAY_OT_toggle_persistent_feature.__module__ = __name__
    try:
        existing = getattr(bpy.types, SMART_OVERLAY_OT_toggle_persistent_feature.__name__, None)
        if isinstance(existing, type) and existing is not SMART_OVERLAY_OT_toggle_persistent_feature:
            try:
                bpy.utils.unregister_class(existing)
            except Exception:
                pass
    except Exception:
        pass
    try:
        try:
            from . import undo_support
            undo_support.prepare_operator_class(SMART_OVERLAY_OT_toggle_persistent_feature)
        except Exception:
            pass
        bpy.utils.register_class(SMART_OVERLAY_OT_toggle_persistent_feature)
    except RuntimeError as exc:
        # A stale class with the same RNA name or operator id can remain after a
        # failed reload.  Remove the same-name class once and retry so the
        # always-on toggle buttons do not point at an unregistered operator.
        if 'already registered' not in str(exc):
            raise
        try:
            existing = getattr(bpy.types, SMART_OVERLAY_OT_toggle_persistent_feature.__name__, None)
            if isinstance(existing, type):
                bpy.utils.unregister_class(existing)
        except Exception:
            pass
        bpy.utils.register_class(SMART_OVERLAY_OT_toggle_persistent_feature)
    _REGISTERED_CLASSES.append(SMART_OVERLAY_OT_toggle_persistent_feature)



def _tool_display_label(alias: str, context=None) -> str:
    alias = str(alias or '').strip()
    tool_label = ''
    try:
        feature_map = _FEATURES.get(alias, {})
        for feature in feature_map.values():
            value = str(feature.get('tool_label') or '').strip()
            if value:
                tool_label = value
                break
    except Exception:
        tool_label = ''
    if not tool_label:
        tool_label = _title_from_key(alias or 'Integrated Tool')
    try:
        from . import registry  # type: ignore
        meta_label = registry.tool_label(alias, context) if alias else ''
        if meta_label:
            return str(meta_label)
        return registry.localized(tool_label, tool_label, context)
    except Exception:
        return tool_label


def draw_all_toggles(layout, context, *, header_text: str | None = None, compact: bool = True) -> bool:
    """Draw every captured resident/background feature in one central group.

    Panel.draw only creates UI rows here. It does not register classes, create
    RNA properties, or load tools. The operator performs the actual toggle.
    """
    del compact
    configure()
    if layout is None or not _REGISTERED_CLASSES:
        return False
    entries = feature_entries(None)
    if not entries:
        return False
    try:
        if header_text:
            layout.label(text=str(header_text), **_icon_kwargs('always_on', 'TIME'))
        grouped: dict[str, list[dict[str, Any]]] = {}
        for item in entries:
            alias = str(item.get('alias') or '').strip()
            feature_key = str(item.get('key') or '').strip()
            if alias and feature_key:
                grouped.setdefault(alias, []).append(item)
        if not grouped:
            return False
        for alias in sorted(grouped.keys(), key=lambda key: _tool_display_label(key, context).lower()):
            tool_label = _tool_display_label(alias, context)
            for item in grouped.get(alias, ()):  # one row per real background action group
                enabled = bool(item.get('enabled'))
                feature_key = str(item.get('key') or '')
                feature_label = _t(context, str(item.get('label_en') or feature_key), str(item.get('label_ja') or feature_key))
                row = layout.row(align=True)
                try:
                    row.use_property_split = False
                    row.use_property_decorate = False
                except Exception:
                    pass
                split = row.split(factor=0.68, align=True)
                left = split.row(align=True)
                left.label(text=f'{tool_label}: {feature_label}', **_icon_kwargs(_tool_icon(alias, feature_key), 'PLUGIN'))
                right = split.row(align=True)
                try:
                    right.alignment = 'RIGHT'
                except Exception:
                    pass
                op = right.operator(
                    _OPERATOR_ID,
                    text=_t(context, 'Enabled' if enabled else 'Disabled', '有効' if enabled else '無効'),
                    **_icon_kwargs('switch_on' if enabled else 'switch_off', 'CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT'),
                    depress=enabled,
                )
                op.alias = alias
                op.feature_key = feature_key
        return True
    except Exception:
        return False

def draw_inline_toggles(layout, context, alias: str, *, compact: bool = True) -> bool:
    """Draw feature toggles using the standardized Smart toolset layout."""
    configure()
    try:
        register_ui()
    except Exception:
        pass
    alias = str(alias or '').strip()
    entries = feature_entries(alias)
    if not entries:
        return False
    try:
        col = layout.column(align=True)
        for item in entries:
            enabled = bool(item.get('enabled'))
            feature_key = str(item.get('key') or '')
            label = _t(context, str(item.get('label_en') or feature_key), str(item.get('label_ja') or feature_key))
            row = col.row(align=True)
            row.label(text=label)
            op = row.operator(_OPERATOR_ID, text=_t(context, 'Enabled', '有効'), depress=enabled)
            op.alias = alias
            op.feature_key = feature_key
            try:
                op.enabled = True
            except Exception:
                pass
            op = row.operator(_OPERATOR_ID, text=_t(context, 'Disabled', '無効'), depress=not enabled)
            op.alias = alias
            op.feature_key = feature_key
            try:
                op.enabled = False
            except Exception:
                pass
            if not compact:
                desc = _t(context, str(item.get('description_en') or ''), str(item.get('description_ja') or ''))
                if desc:
                    col.label(text=desc[:240])
        return True
    except Exception:
        return False


def unregister_ui() -> None:
    for cls in reversed(_REGISTERED_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED_CLASSES.clear()


def unregister_all() -> None:
    for alias in list(_FEATURES.keys()):
        deactivate_alias(alias)
    unregister_ui()
    _FEATURES.clear()


def _safe_safe_set_kmi_property_v60(kmi, prop_name, value) -> bool:
    # Intentionally disabled for Blender 5.1 startup safety. Accessing
    # KeyMapItem.properties is a confirmed native crash source in this add-on's
    # registration capture path. Captured keymap actions are removed immediately;
    # Smart Overlay no longer rebuilds automatic shortcut payloads.
    return False
