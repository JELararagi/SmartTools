# SPDX-License-Identifier: GPL-3.0-or-later
# Blender Extension / user_default compatible package
# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi
#  Official Contact: 
#  Video Tutorials: 
#
#  This file is part of the Smart Overlay Suite package.
#  Licensed under the GNU General Public License v3.0 or later
#  (GPL-3.0-or-later).
# ------------------------------------------------------------------------------

import bpy
import bmesh
import gpu
import math
import time
import sys
from bpy.app.handlers import persistent
from gpu_extras.batch import batch_for_shader as _gpu_batch_for_shader

from . import mesh

# UV hover GPU resources are built by finite event-side snapshot jobs.  The
# draw handler only replays completed commands and never reads edit BMesh or
# constructs shaders/batches.  These wrappers are module-local and do not
# replace Blender's shared GPU API.
_uv_capture_commands = None
_uv_draw_snapshots = {}
_uv_snapshot_generation = 0
_uv_snapshot_request_serial = 0
_uv_snapshot_timer_pending = False
_uv_snapshot_rebuild_active = False
_uv_snapshot_timer_attempts = 0
_uv_snapshot_due = 0.0
_uv_snapshot_reasons = set()
_uv_interaction_dirty = False
# 世代カウンタ。_uv_sel_epoch は depsgraph 更新のたび（選択の変化を含む）、
# _uv_geom_epoch は形状・UV 座標・非表示が変わる更新（is_updated_geometry /
# is_updated_transform）と undo / redo / load のたびに進む。選択だけの変更では geom が動かない。
_uv_sel_epoch = 0
_uv_geom_epoch = 0
_uv_interaction_suppression_requested = False
_uv_interaction_suppression_until = 0.0
_uv_edit_update_guard_active_flag = False
_uv_edit_update_guard_generation = 0
_uv_edit_update_guard_release_pending_generation = 0
_UV_DRAW_SNAPSHOT_MAX = 32
_UV_SNAPSHOT_MAX_ATTEMPTS = 4
_UV_SNAPSHOT_MIN_INTERVAL = 0.05
# One normal coalescing interval is enough to bridge event ordering.  If a real
# Blender UV operator is still active after it expires, the live operator guard
# below extends the latch; a consumed RELEASE therefore never adds a fixed
# user-visible delay to an already completed click.
_UV_INTERACTION_SUPPRESSION_GRACE = 0.15
_uv_snapshot_handlers_registered = False


class _UVShaderProxy:
    __slots__ = ('shader', 'builtin_name', 'uniforms')

    def __init__(self, shader, builtin_name):
        self.shader = shader
        self.builtin_name = str(builtin_name or '')
        self.uniforms = {}

    def bind(self):
        return self.shader.bind()

    def uniform_float(self, name, value):
        try:
            frozen = tuple(value) if isinstance(value, (tuple, list)) else value
        except Exception:
            frozen = value
        self.uniforms[str(name)] = frozen
        return self.shader.uniform_float(name, value)

    def __getattr__(self, name):
        return getattr(self.shader, name)


def _uv_freeze_batch_content(content):
    frozen = {}
    try:
        items = dict(content or {}).items()
    except Exception:
        items = ()
    for key, values in items:
        try:
            frozen[str(key)] = tuple(
                tuple(float(part) for part in value)
                if isinstance(value, (tuple, list)) else value
                for value in tuple(values or ())
            )
        except Exception:
            frozen[str(key)] = tuple(values or ())
    return frozen


class _UVCapturedBatch:
    __slots__ = ('primitive', 'content', 'indices')

    def __init__(self, primitive, content, indices=None):
        self.primitive = str(primitive or '')
        self.content = _uv_freeze_batch_content(content)
        self.indices = tuple(tuple(int(part) for part in row) for row in tuple(indices or ())) if indices is not None else None

    def draw(self, shader):
        if _uv_capture_commands is None:
            target = shader.shader if isinstance(shader, _UVShaderProxy) else shader
            batch = batch_for_shader(target, self.primitive, self.content, indices=self.indices)
            return batch.draw(target)
        uniforms = dict(shader.uniforms) if isinstance(shader, _UVShaderProxy) else {}
        _uv_capture_commands.append({
            'shader_builtin': getattr(shader, 'builtin_name', 'UNIFORM_COLOR') if isinstance(shader, _UVShaderProxy) else 'UNIFORM_COLOR',
            'primitive': self.primitive,
            'content': self.content,
            'indices': self.indices,
            'uniforms': uniforms,
            'state': {'blend': ('ALPHA',)},
        })
        return None

    def __getattr__(self, name):
        raise AttributeError(name)


def batch_for_shader(shader, primitive, content, *, indices=None):
    target = shader.shader if isinstance(shader, _UVShaderProxy) else shader
    if _uv_capture_commands is not None:
        return _UVCapturedBatch(primitive, content, indices=indices)
    if indices is None:
        batch = _gpu_batch_for_shader(target, primitive, content)
    else:
        batch = _gpu_batch_for_shader(target, primitive, content, indices=indices)
    return batch


def _uv_shader_from_builtin(name):
    shader = gpu.shader.from_builtin(name)
    if _uv_capture_commands is None:
        return shader
    return _UVShaderProxy(shader, name)


# =============================================================================
# UV Hover Overlay (Daemon) - based on Smart UV Overlay algorithm
# =============================================================================

class _UVHoverState:
    is_running = False
    operator_ref = None  # compatibility alias for the first live probe
    operator_refs = {}   # exact Window pointer -> live pass-through probe
    is_clicking = False  # suppress hover overlay during click-drag/selection
    clicking_until = 0.0
    hover_type = 'NONE'   # 'VERTEX' | 'EDGE' | 'FACE' | 'NONE'
    hover_uvs = []        # list[(u, v)] in UV space
    mouse_px = (-100, -100)
    draw_handle = None
    runtime_registered = False
    runtime_started_at = 0.0
    last_draw_time = 0.0
    last_rehook_time = 0.0
    draw_exception_count = 0
    target_window_ptr = 0
    target_region_ptr = 0
    hover_obj_name = ""
    hover_obj_key = 0
    hover_sources = []
    hover_data_key = 0
    hover_vert_indices = []
    hover_edge_indices = []
    hover_face_indices = []
    raw_hover_type = 'NONE'
    raw_hover_uvs = []
    raw_hover_vert_indices = []
    raw_hover_edge_indices = []
    raw_hover_face_indices = []
    raw_hover_obj_key = 0
    raw_hover_obj_name = ""
    last_modal_event_time = 0.0
    modal_exception_count = 0
    # Lightweight UV hover cache.  It is rebuilt only when the UV view,
    # selection mode, view, or detected UV/mesh operations change; mouse
    # moves query this cache instead of walking every BMesh face.
    uv_hover_cache = None
    uv_hover_cache_sig = None
    uv_hover_cache_time = 0.0
    # 選択だけが変わった時にホバーキャッシュを作り直さず差分で直すための記録
    # （_build_uv_hover_cache が頂点モードで残し、_uv_hover_cache_try_patch が使う）。
    uv_hover_patch = None
    uv_sel_count_cache = None
    last_mouse_process_time = 0.0
    last_mouse_region_px = (-100000, -100000, 0)
    same_mesh_cache = None
    same_mesh_cache_sig = None
    same_mesh_cache_time = 0.0
    same_mesh_draw_points = []
    same_mesh_draw_edges = []
    same_mesh_draw_sig = None
    same_mesh_draw_time = 0.0
    last_operator_signature = None
    last_operator_dirty_time = 0.0
    last_interaction_operator_name = ''
    last_input_guard_time = 0.0
    last_uv_context_signature = None
    # Absolute window-space mouse cache supplied by the internal Image Editor
    # event probe.  The draw handler uses this to re-prime the UV overlay after
    # cache invalidation, editor redraw re-hooking, workspace changes, or missed
    # release events.
    last_window_mouse_px = (-100000, -100000)
    last_window_mouse_time = 0.0
    last_image_event_time = 0.0
    # Window-local mouse ownership. Blender's Image Editor draw handlers and
    # app timers can run with a different or empty bpy.context. Never reuse a
    # coordinate captured in one Blender Window for another Window's UV Editor.
    window_mouse_px_by_ptr = {}
    window_mouse_time_by_ptr = {}
    window_image_event_time_by_ptr = {}
    last_force_process_time = 0.0
    # Modal event probe generation.  Old probes self-finish when a newer
    # generation starts, so a stale operator_ref can never leave UV hover dead.
    modal_generation = 0
    modal_started_at = 0.0
    deferred_refresh_pending = False
    deferred_refresh_mouse_px = (-100000, -100000)
    deferred_refresh_window_ptr = 0
    uv_hover_stale_cache = None
    uv_hover_stale_cache_time = 0.0
    last_successful_draw_time = 0.0
    last_draw_region_ptr = 0
    interaction_guard_until = 0.0
    last_transform_operator_signature = None
    last_guard_operator_signature = None
    last_guard_mouse_px = (-100000, -100000)
    last_transform_guard_name = ''
    last_transform_guard_ptr = 0
    last_transform_guard_reason = ''
    last_modal_operator_names = ()
    bmesh_read_block_count = 0
    last_interaction_operator_name = ''
    last_input_guard_time = 0.0
    last_timer_mouse_px = (-100000, -100000)
    last_timer_mouse_redraw_time = 0.0
    last_timer_mouse_region_ptr = 0
    last_modal_redraw_px = (-100000, -100000, 0)
    last_modal_redraw_time = 0.0
    external_uv_runtime_guard_started = 0.0
    last_external_uv_runtime_keys = ()
    last_external_change_check_time = 0.0
    last_external_change_result = False
    last_fast_query_sig = None
    last_fast_query_result = None
    last_fast_query_time = 0.0
    last_draw_same_mesh_key = None
    last_draw_same_mesh_points = []
    last_draw_same_mesh_edges = []
    last_draw_same_mesh_time = 0.0
    last_os_mouse_probe_time = 0.0
    last_os_mouse_probe_coords = None
    same_mesh_gpu_batch_sig = None
    same_mesh_gpu_batches = None
    hover_gpu_batch_sig = None
    hover_gpu_batches = None

_state = _UVHoverState()

_UV_RUNTIME_WATCHDOG_INTERVAL = 0.12
_UV_RUNTIME_IDLE_INTERVAL = 0.35
_UV_RUNTIME_ACTIVE_INTERVAL = 0.30
_UV_DRAW_STALE_REHOOK_SECONDS = 4.0
_UV_HOVER_CACHE_FRESH_SECONDS = 30.0
_UV_HOVER_CACHE_VALIDATE_SECONDS = 120.0
_UV_HOVER_MOUSE_MIN_INTERVAL = 1.0 / 60.0
_UV_HOVER_GRID_CELL_PX = 48.0
_UV_SAME_MESH_CACHE_FRESH_SECONDS = 30.0
_UV_MODAL_MOUSE_PROBE_AUTO = True
_UV_MODAL_MOUSE_PROBE_REDRAW_INTERVAL = 1.0 / 60.0
_UV_MODAL_MOUSE_PROBE_MIN_PIXEL_DELTA = 1
_UV_DEFERRED_REFRESH_DELAY = 0.035
_UV_MODAL_STALE_RESTART_SECONDS = 6.0
# Keep BMesh read suppression strictly tied to actual interaction.  Long
# operator-history based blocks made the UV overlay disappear after ordinary
# UV operations even though no transform was running.
_UV_INTERACTION_GUARD_SECONDS = 0.16
_UV_TRANSFORM_GUARD_SECONDS = 0.24
_UV_EXTERNAL_RUNTIME_STUCK_TIMEOUT = 0.75
_UV_PASSIVE_MOUSE_FALLBACK_INTERVAL = 0.18
_UV_EXTERNAL_CHANGE_CHECK_INTERVAL = 0.18
_UV_OS_MOUSE_PROBE_MIN_INTERVAL = 1.0 / 30.0

# 1.2.141: UV Overlay remains display-only, but the non-interference guard is
# limited to real interactive/modal state.  Completed UV operations invalidate
# caches and redraw immediately instead of leaving the overlay hidden behind a
# long safety block.
_UV_ENABLE_VIEW3D_BRIDGE = False
_UV_POST_OPERATOR_SAFE_DELAY = 0.10
# Only active interaction tokens are used for transient read guards. Ordinary
# completed UV operators invalidate caches but must not keep UV Overlay hidden.
_UV_LAST_INTERACTION_NAMES = ('transform', 'translate', 'rotate', 'resize', 'scale', 'drag', 'tweak', 'instant_select_drag_move')

# Sentinel used by Blender View2D when the region is not initialized yet.
_UV_INVALID_REGION_COORD_LIMIT = 1.0e8



# Cached UV-selection -> mesh-vertex bridge for View3D hover overlay
_selected_split_vert_indices = set()
_selected_split_vert_obj_name = ""
_selected_split_vert_obj_ptr = 0

# Anti-regression cheat path for the special "clicked split UV -> View3D vertex hover" case.
# We snapshot the exact UV-hover-derived mesh verts on click press and keep that bridge
# alive independently from the UV hover overlay suppression. This intentionally favors
# stability over purity, because some Blender UV selection states become inconsistent for
# a frame (or for specific topo cases) right after click-hide.
_clicked_bridge_vert_indices = set()
_clicked_bridge_obj_name = ""
_clicked_bridge_obj_ptr = 0
_clicked_bridge_keep_until = 0.0

# Windows fallback cheat: on some Win11 setups Blender modal PRESS/RELEASE delivery
# can be a frame late or get skipped. Query the real button state so click-hide and
# the persistent View3D bridge stay in sync even when Blender events wobble.
def _win_any_mouse_button_down():
    if not sys.platform.startswith("win"):
        return None
    try:
        import ctypes
        user32 = ctypes.windll.user32
        return bool((user32.GetAsyncKeyState(0x01) & 0x8000) or
                    (user32.GetAsyncKeyState(0x02) & 0x8000) or
                    (user32.GetAsyncKeyState(0x04) & 0x8000))
    except Exception:
        return False

def _uv_object_identity(obj):
    """Return stable per-object identity used by multi-object UV overlay caches."""
    try:
        obj_key = int(obj.as_pointer()) if obj is not None else 0
    except Exception:
        obj_key = 0
    try:
        data = getattr(obj, 'data', None)
        data_key = int(data.as_pointer()) if data is not None else 0
    except Exception:
        data_key = 0
    try:
        name = str(getattr(obj, 'name', '') or '')
    except Exception:
        name = ''
    return obj_key, data_key, name




def _uv_object_key(obj):
    try:
        return int(_uv_object_identity(obj)[0])
    except Exception:
        return 0


def _uv_object_data_key(obj):
    try:
        return int(_uv_object_identity(obj)[1])
    except Exception:
        return 0


def _uv_mesh_ref(obj_key, element_index):
    try:
        return (int(obj_key or 0), int(element_index))
    except Exception:
        return (0, int(element_index) if element_index is not None else -1)


def _uv_overlay_obj_point_key(obj_key, uv, vert_index):
    return _uv_overlay_point_key(uv, vert_index, obj_key)


def _uv_overlay_obj_edge_key(obj_key, edge_index, uv_a, uv_b):
    return _uv_overlay_edge_key(edge_index, uv_a, uv_b, obj_key)


def _uv_edit_mesh_objects(context=None, *, include_data_fallback=True, include_view_layer_scan=False):
    """Return all visible edit-mode mesh objects for UV Editor multi-object editing."""
    try:
        ctx = context or bpy.context
    except Exception:
        ctx = bpy.context
    result = []
    seen = set()

    def _add(candidate):
        try:
            if candidate is None or getattr(candidate, 'type', None) != 'MESH':
                return
            mode = str(getattr(candidate, 'mode', '') or '')
            if mode not in {'EDIT', 'EDIT_MESH'}:
                return
            try:
                key = int(candidate.as_pointer())
            except Exception:
                key = id(candidate)
            if key in seen:
                return
            seen.add(key)
            result.append(candidate)
        except Exception:
            return

    try:
        _add(getattr(ctx, 'edit_object', None))
        _add(getattr(ctx, 'object', None))
        _add(getattr(ctx, 'active_object', None))
    except Exception:
        pass
    try:
        view_layer = getattr(ctx, 'view_layer', None) or getattr(bpy.context, 'view_layer', None)
        _add(getattr(getattr(view_layer, 'objects', None), 'active', None))
    except Exception:
        pass

    for attr in ('objects_in_mode', 'objects_in_mode_unique_data', 'selected_objects'):
        try:
            for candidate in getattr(ctx, attr, ()) or ():
                _add(candidate)
        except Exception:
            continue

    # Snapshot rebuilds can run under an Image Editor temp_override where
    # objects_in_mode is temporarily absent even though Blender is still in
    # multi-object Edit Mode.  In that case, or when the caller explicitly asks
    # for full authority, collect every edit-mesh object from the current view
    # layer.  This is the source of truth for UVs shown by multi-object editing.
    if include_view_layer_scan or not result:
        try:
            objs = getattr(getattr(ctx, 'view_layer', None), 'objects', None) or getattr(getattr(bpy.context, 'view_layer', None), 'objects', ())
            for candidate in objs or ():
                _add(candidate)
        except Exception:
            pass

    if include_data_fallback and not result:
        try:
            for candidate in getattr(bpy.data, 'objects', ()) or ():
                _add(candidate)
        except Exception:
            pass
    return tuple(result)


def _uv_edit_mesh_object(context=None):
    """Return the first edit-mode mesh object, preserving legacy callers."""
    try:
        objects = _uv_edit_mesh_objects(context)
        return objects[0] if objects else None
    except Exception:
        return None


def _uv_close2(a, b, eps=1.0e-6):
    return (abs(float(a[0]) - float(b[0])) <= eps) and (abs(float(a[1]) - float(b[1])) <= eps)

def _loop_uv_vert_selected(loop, uv_layer) -> bool:
    """Return UV-vertex selection robustly across Blender 5.1 and legacy APIs.

    Blender 5.1 exposes uv_select_vert on BMLoop.  Older builds stored the
    value on BMLoopUV.select.  The previous fallback accidentally referenced an
    undefined variable and therefore made UV hover / same-mesh helpers silently
    miss selected state in some contexts.
    """
    try:
        getter = getattr(loop, 'uv_select_vert', None)
        if callable(getter):
            return bool(getter())
        if getter is not None:
            return bool(getter)
    except Exception:
        pass
    try:
        luv = loop[uv_layer]
        for attr in ('select', 'select_vert', 'uv_select_vert'):
            try:
                value = getattr(luv, attr)
                if callable(value):
                    return bool(value())
                return bool(value)
            except Exception:
                continue
    except Exception:
        pass
    return False


def _loop_uv_edge_selected(loop, uv_layer) -> bool:
    """Return UV-edge selection robustly across Blender 5.1 and legacy APIs."""
    try:
        getter = getattr(loop, 'uv_select_edge', None)
        if callable(getter):
            return bool(getter())
        if getter is not None:
            return bool(getter)
    except Exception:
        pass
    try:
        luv = loop[uv_layer]
        for attr in ('select_edge', 'edge_select', 'uv_select_edge'):
            try:
                value = getattr(luv, attr)
                if callable(value):
                    return bool(value())
                return bool(value)
            except Exception:
                continue
    except Exception:
        pass
    return False


def _face_uv_selected(face, loops, uv_layer) -> bool:
    # Blender 5.1's BMFace.uv_select can report True when only a member UV
    # vertex/edge is selected.  For overlay exclusion we need the selected UV
    # side precisely, so a UV face is considered selected only when all of its
    # UV corner vertices are selected.
    try:
        return bool(loops) and all(_loop_uv_vert_selected(loop, uv_layer) for loop in loops)
    except Exception:
        return False


def _uv_overlay_point_key(uv, vert_index, obj_key=None):
    try:
        prefix = int(obj_key) if obj_key is not None else 0
        return (prefix, int(vert_index), round(float(uv[0]), 6), round(float(uv[1]), 6))
    except Exception:
        return None


def _uv_overlay_edge_key(edge_index, uv_a, uv_b, obj_key=None):
    try:
        prefix = int(obj_key) if obj_key is not None else 0
        a = (round(float(uv_a[0]), 6), round(float(uv_a[1]), 6))
        b = (round(float(uv_b[0]), 6), round(float(uv_b[1]), 6))
        if b < a:
            a, b = b, a
        return (prefix, int(edge_index), a, b)
    except Exception:
        return None


def _uv_coord_key(uv):
    try:
        return (round(float(uv[0]), 6), round(float(uv[1]), 6))
    except Exception:
        return None


def _uv_segment_coord_key(uv_a, uv_b):
    try:
        a = _uv_coord_key(uv_a)
        b = _uv_coord_key(uv_b)
        if a is None or b is None:
            return None
        if b < a:
            a, b = b, a
        return (a, b)
    except Exception:
        return None


def _uv_polygon_key(uvs):
    try:
        coords = [_uv_coord_key(uv) for uv in (uvs or ())]
        coords = [co for co in coords if co is not None]
        if not coords:
            return None
        return tuple(sorted(coords))
    except Exception:
        return None


def _uv_grid_cell_range(min_x, min_y, max_x, max_y, cell, width, height, pad=0.0):
    try:
        c = max(1.0, float(cell or _UV_HOVER_GRID_CELL_PX))
        p = max(0.0, float(pad or 0.0))
        w = max(1.0, float(width or 1.0))
        h = max(1.0, float(height or 1.0))
        x0 = int(math.floor(max(float(min_x) - p, -p) / c))
        x1 = int(math.floor(min(float(max_x) + p, w + p) / c))
        y0 = int(math.floor(max(float(min_y) - p, -p) / c))
        y1 = int(math.floor(min(float(max_y) + p, h + p) / c))
        if x1 < x0:
            x0, x1 = x1, x0
        if y1 < y0:
            y0, y1 = y1, y0
        return range(x0, x1 + 1), range(y0, y1 + 1)
    except Exception:
        return (), ()


def _uv_grid_add_bbox(grid, entry_index, min_x, min_y, max_x, max_y, cell, width, height, pad=0.0):
    try:
        xs, ys = _uv_grid_cell_range(min_x, min_y, max_x, max_y, cell, width, height, pad)
        for cx in xs:
            for cy in ys:
                grid.setdefault((cx, cy), []).append(int(entry_index))
    except Exception:
        pass


def _uv_grid_add_point_fast(grid, entry_index, x, y, cell, width, height, pad=15.0):
    """Hot-path point-grid insertion without per-point helper allocations."""
    try:
        c = cell if cell and cell > 0.0 else float(_UV_HOVER_GRID_CELL_PX)
        p = pad if pad and pad > 0.0 else 0.0
        w = float(width if width and width > 0 else 1)
        h = float(height if height and height > 0 else 1)
        x = float(x); y = float(y)
        x0 = int(math.floor(max(x - p, -p) / c))
        x1 = int(math.floor(min(x + p, w + p) / c))
        y0 = int(math.floor(max(y - p, -p) / c))
        y1 = int(math.floor(min(y + p, h + p) / c))
        idx = int(entry_index)
        for cx in range(x0, x1 + 1):
            for cy in range(y0, y1 + 1):
                grid.setdefault((cx, cy), []).append(idx)
    except Exception:
        pass


def _uv_entry_candidate_ids(cache, grid_name, entries_name, rx, ry):
    try:
        cell = float(cache.get('cell') or _UV_HOVER_GRID_CELL_PX)
        cx = int(math.floor(float(rx) / cell))
        cy = int(math.floor(float(ry) / cell))
        grid = cache.get(grid_name) or {}
        candidates = set()
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                candidates.update(grid.get((cx + dx, cy + dy), ()) or ())
        entries = cache.get(entries_name) or ()
        if not candidates and len(entries) <= 4096:
            return tuple(range(len(entries)))
        return tuple(candidates)
    except Exception:
        return ()


def _uv_same_coord(a, b, eps=1.0e-6):
    try:
        return abs(float(a[0]) - float(b[0])) <= eps and abs(float(a[1]) - float(b[1])) <= eps
    except Exception:
        return False


def _iter_radial_loops(loop_on_edge):
    try:
        cur = loop_on_edge.link_loop_radial_next
    except Exception:
        return
    seen = {id(loop_on_edge)}
    while cur is not None and id(cur) not in seen:
        seen.add(id(cur))
        yield cur
        try:
            cur = cur.link_loop_radial_next
        except Exception:
            break

def _same_vert_loop_on_other_face(loop_on_edge, other_base, target_vert):
    try:
        if other_base.vert == target_vert:
            return other_base
    except Exception:
        pass
    try:
        ln = other_base.link_loop_next
        if ln and ln.vert == target_vert:
            return ln
    except Exception:
        pass
    return None

def _uv_edge_is_contiguous(loop_on_edge, other_base, uv_layer):
    try:
        ca = tuple(loop_on_edge[uv_layer].uv)
        cb = tuple(loop_on_edge.link_loop_next[uv_layer].uv)
        oa = tuple(other_base[uv_layer].uv)
        ob = tuple(other_base.link_loop_next[uv_layer].uv)
        return (_uv_close2(ca, oa) and _uv_close2(cb, ob)) or (_uv_close2(ca, ob) and _uv_close2(cb, oa))
    except Exception:
        return False

def _is_uv_split_vert(v, uv_layer):
    try:
        loops = [l for l in v.link_loops if l and (not getattr(l.face, 'hide', False))]
    except Exception:
        return False
    if len(loops) <= 1:
        return False

    idx_of = {id(l): i for i, l in enumerate(loops)}
    adj = [set() for _ in loops]

    def connect_via_edge(seed_loop_on_edge, target_loop):
        i = idx_of.get(id(target_loop))
        if i is None:
            return
        for other_base in _iter_radial_loops(seed_loop_on_edge):
            if getattr(other_base, 'face', None) == getattr(seed_loop_on_edge, 'face', None):
                continue
            if not _uv_edge_is_contiguous(seed_loop_on_edge, other_base, uv_layer):
                continue
            other_same_vert = _same_vert_loop_on_other_face(seed_loop_on_edge, other_base, target_loop.vert)
            if other_same_vert is None:
                continue
            j = idx_of.get(id(other_same_vert))
            if j is None or j == i:
                continue
            adj[i].add(j)
            adj[j].add(i)

    for l in loops:
        try:
            connect_via_edge(l, l)
        except Exception:
            pass
        try:
            connect_via_edge(l.link_loop_prev, l)
        except Exception:
            pass

    seen = set()
    comps = 0
    for i in range(len(loops)):
        if i in seen:
            continue
        comps += 1
        if comps > 1:
            return True
        stack = [i]
        seen.add(i)
        while stack:
            cur = stack.pop()
            for nb in adj[cur]:
                if nb not in seen:
                    seen.add(nb)
                    stack.append(nb)
    return False

def _collect_selected_force_bridge_vert_indices(context):
    if not _UV_ENABLE_VIEW3D_BRIDGE or not _uv_may_read_edit_bmesh(context):
        return set(), "", 0
    """Aggressive fallback used only for the View3D split-bridge.

    Goal: keep the special UV-split -> 3D hover bridge alive even when the
    strict split detector or partial-loop detector misses some vertices after
    click-hide suppression. This intentionally biases toward showing a few more
    candidates rather than dropping true split vertices.
    """
    if not _uv_can_read_edit_bmesh(context):
        return set(), "", 0
    obj = _uv_edit_mesh_object(context)
    if not obj or obj.type != 'MESH':
        return set(), "", 0

    try:
        bm = bmesh.from_edit_mesh(obj.data)
    except Exception:
        return set(), obj.name, getattr(obj, 'as_pointer', lambda: 0)()

    uv_layer = bm.loops.layers.uv.active
    if not uv_layer:
        return set(), obj.name, getattr(obj, 'as_pointer', lambda: 0)()

    ts = context.scene.tool_settings
    is_sync = bool(getattr(ts, 'use_uv_select_sync', False))

    if is_sync:
        check_v, check_e, _check_f = getattr(ts, 'mesh_select_mode', (True, False, False))
    else:
        uv_mode = getattr(ts, 'uv_select_mode', 'VERTEX')
        uv_mode_flags = uv_mode if isinstance(uv_mode, str) else set(uv_mode)
        check_v = ('VERTEX' in uv_mode_flags)
        check_e = ('EDGE' in uv_mode_flags)
    if not (check_v or check_e):
        return set(), obj.name, getattr(obj, 'as_pointer', lambda: 0)()

    try:
        bm.faces.ensure_lookup_table()
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
    except Exception:
        pass

    selected_candidates = set()
    selected_loop_count = {}
    total_loop_count = {}
    uv_coords_by_vert = {}

    if is_sync:
        if check_v:
            for v in bm.verts:
                if (not v.hide) and v.select:
                    selected_candidates.add(int(v.index))
        if check_e:
            for e in bm.edges:
                if (not e.hide) and e.select:
                    try:
                        selected_candidates.add(int(e.verts[0].index))
                        selected_candidates.add(int(e.verts[1].index))
                    except Exception:
                        pass
    else:
        for f in bm.faces:
            if f.hide:
                continue
            for l in f.loops:
                try:
                    luv = l[uv_layer]
                except Exception:
                    continue
                vidx = int(l.vert.index)
                total_loop_count[vidx] = total_loop_count.get(vidx, 0) + 1
                try:
                    uv_coords_by_vert.setdefault(vidx, set()).add((round(float(luv.uv.x), 6), round(float(luv.uv.y), 6)))
                except Exception:
                    pass
                try:
                    sel_v = _loop_uv_vert_selected(l, uv_layer)
                except Exception:
                    sel_v = False
                try:
                    sel_e = _loop_uv_edge_selected(l, uv_layer)
                except Exception:
                    sel_e = False
                if (check_v and sel_v) or (check_e and sel_e):
                    selected_candidates.add(vidx)
                    selected_loop_count[vidx] = selected_loop_count.get(vidx, 0) + 1
                    if check_e and sel_e:
                        try:
                            nvidx = int(l.link_loop_next.vert.index)
                            selected_candidates.add(nvidx)
                        except Exception:
                            pass

    if not selected_candidates:
        return set(), obj.name, getattr(obj, 'as_pointer', lambda: 0)()

    forced = set()
    for vidx in selected_candidates:
        try:
            v = bm.verts[int(vidx)]
        except Exception:
            continue
        if getattr(v, 'hide', False):
            continue

        visible_loops = [l for l in getattr(v, 'link_loops', []) if l and not getattr(l.face, 'hide', False)]
        loop_count = len(visible_loops)
        if loop_count <= 1:
            continue

        # 1) strict detector wins immediately when available.
        try:
            if _is_uv_split_vert(v, uv_layer):
                forced.add(int(v.index))
                continue
        except Exception:
            pass

        # 2) Partial UV selection across loops is the most reliable post click-hide fallback.
        sel_count = int(selected_loop_count.get(int(vidx), 0))
        total_count = int(total_loop_count.get(int(vidx), loop_count))
        if sel_count > 0 and total_count > sel_count:
            forced.add(int(v.index))
            continue

        # 3) Distinct UV coordinates across loops strongly suggest a split/stacked split.
        if len(uv_coords_by_vert.get(int(vidx), set())) > 1:
            forced.add(int(v.index))
            continue

        # 4) Last-resort cheat path requested by the user:
        #    if the mesh vertex is represented by multiple visible UV loops and it is
        #    currently part of the UV selection, bridge it to 3D rather than dropping it.
        forced.add(int(v.index))

    return forced, obj.name, getattr(obj, 'as_pointer', lambda: 0)()

def _collect_selected_partial_vert_indices(context):
    if not _UV_ENABLE_VIEW3D_BRIDGE or not _uv_may_read_edit_bmesh(context):
        return set(), "", 0
    """Looser fallback for split-UV bridge.

    Returns selected mesh verts for which the current UV selection only covers a
    subset of the visible loops using that mesh vert. This catches cases where
    the strict split detector misses a true split because of connectivity/order,
    while avoiding blindly returning every selected vertex.
    """
    if not _uv_can_read_edit_bmesh(context):
        return set(), "", 0
    obj = _uv_edit_mesh_object(context)
    if not obj or obj.type != 'MESH':
        return set(), "", 0

    try:
        bm = bmesh.from_edit_mesh(obj.data)
    except Exception:
        return set(), obj.name, getattr(obj, 'as_pointer', lambda: 0)()

    uv_layer = bm.loops.layers.uv.active
    if not uv_layer:
        return set(), obj.name, getattr(obj, 'as_pointer', lambda: 0)()

    ts = context.scene.tool_settings
    is_sync = bool(getattr(ts, 'use_uv_select_sync', False))

    # This fallback is only meaningful for UV-driven selection. In sync mode the
    # strict split collector already works from mesh selection, and broadening it
    # here would reintroduce click-hide regressions for ordinary mesh selection.
    if is_sync:
        return set(), obj.name, getattr(obj, 'as_pointer', lambda: 0)()

    uv_mode = getattr(ts, 'uv_select_mode', 'VERTEX')
    uv_mode_flags = uv_mode if isinstance(uv_mode, str) else set(uv_mode)
    check_v = ('VERTEX' in uv_mode_flags)
    check_e = ('EDGE' in uv_mode_flags)
    if not (check_v or check_e):
        return set(), obj.name, getattr(obj, 'as_pointer', lambda: 0)()

    selected_candidates = set()
    selected_by_vert = {}
    total_by_vert = {}

    try:
        bm.verts.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
    except Exception:
        pass

    for f in bm.faces:
        if f.hide:
            continue
        for l in f.loops:
            try:
                luv = l[uv_layer]
            except Exception:
                continue
            vidx = int(l.vert.index)
            total_by_vert[vidx] = total_by_vert.get(vidx, 0) + 1
            is_selected = False
            try:
                if check_v and _loop_uv_vert_selected(l, uv_layer):
                    is_selected = True
                elif check_e and _loop_uv_edge_selected(l, uv_layer):
                    is_selected = True
            except Exception:
                is_selected = False
            if is_selected:
                selected_candidates.add(vidx)
                selected_by_vert[vidx] = selected_by_vert.get(vidx, 0) + 1

    if not selected_candidates:
        return set(), obj.name, getattr(obj, 'as_pointer', lambda: 0)()

    partial_selected = set()
    for vidx in selected_candidates:
        sel_count = int(selected_by_vert.get(vidx, 0))
        total_count = int(total_by_vert.get(vidx, 0))
        if sel_count > 0 and total_count > sel_count:
            partial_selected.add(vidx)

    return partial_selected, obj.name, getattr(obj, 'as_pointer', lambda: 0)()

def _collect_selected_multiloop_vert_indices(context):
    if not _UV_ENABLE_VIEW3D_BRIDGE or not _uv_may_read_edit_bmesh(context):
        return set(), "", 0
    """Broad but stable View3D bridge fallback.

    Returns selected mesh verts that are represented by multiple visible UV loops.
    This is intentionally broader than the strict split detector and is only used
    as a last-resort bridge so split-like vertices do not disappear after click-hide.
    """
    if not _uv_can_read_edit_bmesh(context):
        return set(), "", 0
    obj = _uv_edit_mesh_object(context)
    if not obj or obj.type != 'MESH':
        return set(), "", 0

    try:
        bm = bmesh.from_edit_mesh(obj.data)
    except Exception:
        return set(), obj.name, getattr(obj, 'as_pointer', lambda: 0)()

    uv_layer = bm.loops.layers.uv.active
    if not uv_layer:
        return set(), obj.name, getattr(obj, 'as_pointer', lambda: 0)()

    ts = context.scene.tool_settings
    is_sync = bool(getattr(ts, 'use_uv_select_sync', False))

    selected_candidates = set()
    try:
        bm.faces.ensure_lookup_table()
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
    except Exception:
        pass

    if is_sync:
        sel_mode = tuple(bool(v) for v in getattr(ts, 'mesh_select_mode', (True, False, False)))
        if sel_mode[0]:
            for v in bm.verts:
                if (not v.hide) and v.select:
                    selected_candidates.add(int(v.index))
        if sel_mode[1]:
            for e in bm.edges:
                if (not e.hide) and e.select:
                    try:
                        selected_candidates.add(int(e.verts[0].index))
                        selected_candidates.add(int(e.verts[1].index))
                    except Exception:
                        pass
        if sel_mode[2]:
            for f in bm.faces:
                if (not f.hide) and f.select:
                    for v in f.verts:
                        selected_candidates.add(int(v.index))
    else:
        uv_mode = getattr(ts, 'uv_select_mode', 'VERTEX')
        uv_mode_flags = uv_mode if isinstance(uv_mode, str) else set(uv_mode)
        check_v = ('VERTEX' in uv_mode_flags)
        check_e = ('EDGE' in uv_mode_flags)
        check_f = ('FACE' in uv_mode_flags) or ('ISLAND' in uv_mode_flags)
        for f in bm.faces:
            if f.hide:
                continue
            loops = list(f.loops)
            face_selected = False
            if check_f:
                try:
                    face_selected = loops and all(_loop_uv_vert_selected(l, uv_layer) for l in loops)
                except Exception:
                    face_selected = False
            if face_selected:
                for v in f.verts:
                    selected_candidates.add(int(v.index))
            for l in loops:
                try:
                    if check_v and _loop_uv_vert_selected(l, uv_layer):
                        selected_candidates.add(int(l.vert.index))
                except Exception:
                    pass
                try:
                    if check_e and _loop_uv_edge_selected(l, uv_layer):
                        selected_candidates.add(int(l.edge.verts[0].index))
                        selected_candidates.add(int(l.edge.verts[1].index))
                except Exception:
                    pass

    if not selected_candidates:
        return set(), obj.name, getattr(obj, 'as_pointer', lambda: 0)()

    result = set()
    for vidx in selected_candidates:
        try:
            v = bm.verts[int(vidx)]
        except Exception:
            continue
        if getattr(v, 'hide', False):
            continue
        visible_loops = [l for l in getattr(v, 'link_loops', []) if l and not getattr(l.face, 'hide', False)]
        if len(visible_loops) > 1:
            result.add(int(v.index))

    return result, obj.name, getattr(obj, 'as_pointer', lambda: 0)()

def _collect_selected_any_multiloop_vert_indices(context):
    if not _UV_ENABLE_VIEW3D_BRIDGE or not _uv_may_read_edit_bmesh(context):
        return set(), "", 0
    """Broad stability-first fallback for the special View3D bridge.

    Ignore current UV select mode details and collect any mesh vertex that is
    touched by the current UV/mesh selection signal and has multiple visible UV
    loops. This intentionally favors robustness over purity and is only used for
    the View3D bridge, not for UV overlay drawing itself.
    """
    if not _uv_can_read_edit_bmesh(context):
        return set(), "", 0
    obj = _uv_edit_mesh_object(context)
    if not obj or obj.type != 'MESH':
        return set(), "", 0

    try:
        bm = bmesh.from_edit_mesh(obj.data)
    except Exception:
        return set(), obj.name, getattr(obj, 'as_pointer', lambda: 0)()

    uv_layer = bm.loops.layers.uv.active
    if not uv_layer:
        return set(), obj.name, getattr(obj, 'as_pointer', lambda: 0)()

    try:
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
    except Exception:
        pass

    candidates = set()
    ts = context.scene.tool_settings
    is_sync = bool(getattr(ts, 'use_uv_select_sync', False))

    if is_sync:
        try:
            for v in bm.verts:
                if (not v.hide) and v.select:
                    candidates.add(int(v.index))
            for e in bm.edges:
                if (not e.hide) and e.select:
                    candidates.add(int(e.verts[0].index))
                    candidates.add(int(e.verts[1].index))
            for f in bm.faces:
                if (not f.hide) and f.select:
                    for v in f.verts:
                        candidates.add(int(v.index))
        except Exception:
            pass

    for f in bm.faces:
        if f.hide:
            continue
        loops = list(f.loops)
        face_sel = False
        try:
            face_sel = bool(loops) and all(_loop_uv_vert_selected(l, uv_layer) for l in loops)
        except Exception:
            face_sel = False
        if face_sel:
            for v in f.verts:
                candidates.add(int(v.index))
        for l in loops:
            try:
                luv = l[uv_layer]
            except Exception:
                continue
            try:
                if _loop_uv_vert_selected(l, uv_layer):
                    candidates.add(int(l.vert.index))
            except Exception:
                pass
            try:
                if _loop_uv_edge_selected(l, uv_layer):
                    candidates.add(int(l.edge.verts[0].index))
                    candidates.add(int(l.edge.verts[1].index))
            except Exception:
                pass

    out = set()
    for vidx in candidates:
        try:
            v = bm.verts[int(vidx)]
        except Exception:
            continue
        if getattr(v, 'hide', False):
            continue
        try:
            visible_loops = [l for l in getattr(v, 'link_loops', []) if l and not getattr(l.face, 'hide', False)]
        except Exception:
            visible_loops = []
        if len(visible_loops) > 1:
            out.add(int(v.index))
    return out, obj.name, getattr(obj, 'as_pointer', lambda: 0)()

def _collect_selected_split_vert_indices(context):
    if not _UV_ENABLE_VIEW3D_BRIDGE or not _uv_may_read_edit_bmesh(context):
        return set(), "", 0
    if not _uv_can_read_edit_bmesh(context):
        return set(), "", 0
    obj = _uv_edit_mesh_object(context)
    if not obj or obj.type != 'MESH':
        return set(), "", 0

    try:
        bm = bmesh.from_edit_mesh(obj.data)
    except Exception:
        return set(), obj.name, getattr(obj, 'as_pointer', lambda: 0)()

    uv_layer = bm.loops.layers.uv.active
    if not uv_layer:
        return set(), obj.name, getattr(obj, 'as_pointer', lambda: 0)()

    ts = context.scene.tool_settings
    is_sync = bool(getattr(ts, 'use_uv_select_sync', False))

    if is_sync:
        check_v, check_e, _check_f = ts.mesh_select_mode
    else:
        uv_mode = ts.uv_select_mode
        if isinstance(uv_mode, str):
            check_v = ('VERTEX' in uv_mode)
            check_e = ('EDGE' in uv_mode)
        else:
            check_v = ('VERTEX' in uv_mode)
            check_e = ('EDGE' in uv_mode)

    selected_candidates = set()
    try:
        bm.faces.ensure_lookup_table()
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
    except Exception:
        pass

    if is_sync:
        if check_v:
            for v in bm.verts:
                if not v.hide and v.select:
                    selected_candidates.add(v.index)
        if check_e:
            for e in bm.edges:
                if not e.hide and e.select:
                    try:
                        selected_candidates.add(e.verts[0].index)
                        selected_candidates.add(e.verts[1].index)
                    except Exception:
                        pass
    else:
        for f in bm.faces:
            if f.hide:
                continue
            for l in f.loops:
                try:
                    luv = l[uv_layer]
                except Exception:
                    continue
                if check_v and _loop_uv_vert_selected(l, uv_layer):
                    selected_candidates.add(l.vert.index)
                if check_e and _loop_uv_edge_selected(l, uv_layer):
                    try:
                        selected_candidates.add(l.vert.index)
                        selected_candidates.add(l.link_loop_next.vert.index)
                    except Exception:
                        pass

    if not selected_candidates:
        return set(), obj.name, getattr(obj, 'as_pointer', lambda: 0)()

    split_selected = set()
    for vidx in selected_candidates:
        try:
            v = bm.verts[vidx]
        except Exception:
            continue
        if getattr(v, 'hide', False):
            continue
        if _is_uv_split_vert(v, uv_layer):
            split_selected.add(v.index)

    return split_selected, obj.name, getattr(obj, 'as_pointer', lambda: 0)()

def _refresh_selected_split_vert_indices(context):
    global _selected_split_vert_indices, _selected_split_vert_obj_name, _selected_split_vert_obj_ptr
    _selected_split_vert_indices = set()
    _selected_split_vert_obj_name = ''
    _selected_split_vert_obj_ptr = 0
    return None

def get_selected_split_mesh_vert_indices(obj=None, context=None):
    return set()

def _set_clicked_bridge_from_current_hover(context=None, accumulate=False):
    _clear_clicked_bridge(context)
    return None

def _clear_clicked_bridge(context=None):
    global _clicked_bridge_vert_indices, _clicked_bridge_obj_name, _clicked_bridge_obj_ptr, _clicked_bridge_keep_until
    _clicked_bridge_vert_indices = set()
    _clicked_bridge_obj_name = ''
    _clicked_bridge_obj_ptr = 0
    _clicked_bridge_keep_until = 0.0


def _set_clicked_bridge_from_current_selection(context=None, accumulate=False):
    _clear_clicked_bridge(context)
    return None

def get_clicked_bridge_vert_indices(obj=None, context=None):
    return set()

def _clear_hover_state(context=None, redraw=True):
    changed = (
        getattr(_state, 'hover_type', 'NONE') != 'NONE' or
        bool(getattr(_state, 'hover_uvs', [])) or
        bool(getattr(_state, 'hover_vert_indices', [])) or
        bool(getattr(_state, 'hover_edge_indices', [])) or
        bool(getattr(_state, 'hover_face_indices', [])) or
        bool(getattr(_state, 'hover_obj_name', '')) or
        getattr(_state, 'raw_hover_type', 'NONE') != 'NONE' or
        bool(getattr(_state, 'raw_hover_uvs', [])) or
        bool(getattr(_state, 'raw_hover_vert_indices', [])) or
        bool(getattr(_state, 'raw_hover_edge_indices', [])) or
        bool(getattr(_state, 'raw_hover_face_indices', []))
    )
    _state.hover_type = 'NONE'
    _state.hover_uvs = []
    _state.hover_obj_name = ''
    _state.hover_obj_key = 0
    _state.hover_sources = []
    _state.raw_hover_obj_key = 0
    _state.raw_hover_obj_name = ''
    _state.hover_vert_indices = []
    _state.hover_edge_indices = []
    _state.hover_face_indices = []
    _state.raw_hover_type = 'NONE'
    _state.raw_hover_uvs = []
    _state.raw_hover_vert_indices = []
    _state.raw_hover_edge_indices = []
    _state.raw_hover_face_indices = []
    _state.hover_gpu_batch_sig = None
    _state.hover_gpu_batches = None
    # Do not refresh UV selection bridge here.  Clearing a visual hover state must
    # never read or synchronize UV selection while the user is interacting.
    if redraw and changed:
        try:
            ctx = context or bpy.context
            if getattr(ctx, 'window', None) and getattr(ctx.window, 'screen', None):
                ctx.window.screen.tag_redraw()
        except Exception:
            pass
        _tag_view3d_redraw(context)
        try:
            _tag_uv_image_redraw(context)
        except Exception:
            pass
        try:
            request_uv_snapshot_rebuild('hover_clear', context=context or getattr(bpy, 'context', None), immediate=False)
        except Exception:
            pass


# -----------------------------------------------------------------------------
# View3D bridge helpers
# -----------------------------------------------------------------------------
def _uv_rna_pointer(value) -> int:
    try:
        return int(value.as_pointer()) if value is not None else 0
    except Exception:
        return 0


def _uv_iter_window_managers(context=None):
    """Yield every live WindowManager, independent of the current timer context."""
    seen = set()
    candidates = []
    for ctx in (context, getattr(bpy, 'context', None)):
        try:
            wm = getattr(ctx, 'window_manager', None)
            if wm is not None:
                candidates.append(wm)
        except Exception:
            pass
    try:
        candidates.extend(tuple(getattr(bpy.data, 'window_managers', ()) or ()))
    except Exception:
        pass
    for wm in candidates:
        ptr = _uv_rna_pointer(wm)
        if not ptr or ptr in seen:
            continue
        seen.add(ptr)
        yield wm


def _uv_iter_windows(context=None):
    """Yield all live Blender Windows, preferring the caller's exact Window."""
    ctx = context or getattr(bpy, 'context', None)
    preferred = getattr(ctx, 'window', None) if ctx is not None else None
    seen = set()
    if preferred is not None:
        ptr = _uv_rna_pointer(preferred)
        if ptr:
            seen.add(ptr)
            yield preferred
    for wm in _uv_iter_window_managers(ctx):
        for window in tuple(getattr(wm, 'windows', ()) or ()):
            ptr = _uv_rna_pointer(window)
            if not ptr or ptr in seen:
                continue
            seen.add(ptr)
            yield window


def _uv_window_by_pointer(window_ptr, context=None):
    try:
        wanted = int(window_ptr or 0)
    except Exception:
        wanted = 0
    if not wanted:
        return None
    for window in _uv_iter_windows(context):
        if _uv_rna_pointer(window) == wanted:
            return window
    return None


def _tag_view3d_redraw(context=None):
    for win in _uv_iter_windows(context):
        screen = getattr(win, 'screen', None)
        if screen is None:
            continue
        for area in tuple(getattr(screen, 'areas', ()) or ()):
            if getattr(area, 'type', None) == 'VIEW_3D':
                try:
                    area.tag_redraw()
                except Exception:
                    pass


def _tag_uv_image_redraw(context=None):
    try:
        for target in tuple(_uv_iter_live_editor_targets(context) or ()):
            area = target.get('area')
            if area is not None:
                try:
                    area.tag_redraw()
                except Exception:
                    pass
    except Exception:
        pass




def _uv_manager_editor_cell_allows(context=None) -> bool:
    try:
        from . import common as _sos_common
        fn = getattr(_sos_common, 'manager_editor_cell_allows_runtime', None)
        if callable(fn):
            return bool(fn(context))
    except Exception:
        pass
    return True


def _uv_workspace_filter_allows_addon(context=None) -> bool:
    try:
        from . import common as _sos_common
        fn = getattr(_sos_common, 'workspace_filter_allows_addon_runtime', None)
        if callable(fn):
            # UV Overlay is configured from the 3D View N-panel but draws in the
            # Image/UV Editor.  Use workspace-level Smart Tools Manager enablement
            # for this cross-editor runtime so an editor-specific Image Editor
            # filter does not silently suppress drawing.
            return bool(fn(context, cross_editor=True))
        fn = getattr(_sos_common, 'workspace_filter_allows_addon', None)
        if callable(fn):
            return bool(fn(context))
    except Exception:
        pass
    return True

def _uv_runtime_requested(context=None) -> bool:
    """Return the explicit UV Overlay runtime toggle across live managers.

    UV drawing is validated against the actual SpaceImageEditor owner later.
    Do not reject the resident handler because the current Python context points
    at a 3D View, a different window, or a transient Manager cell.
    """
    try:
        ctx = context or getattr(bpy, 'context', None)
        return any(
            bool(getattr(wm, 'sos_uv_overlay_enabled', False))
            for wm in _uv_iter_window_managers(ctx)
        )
    except Exception:
        return False


def _uv_editor_space_for_area(area):
    """Return the SpaceImageEditor that actually owns UV editing in *area*."""
    try:
        if getattr(area, 'type', None) != 'IMAGE_EDITOR':
            return None
        spaces_rna = getattr(area, 'spaces', None)
        active = getattr(spaces_rna, 'active', None)
        spaces = tuple(spaces_rna or ())
        ordered = ((active,) if active is not None else ()) + tuple(sp for sp in spaces if sp is not active)
        area_ui_type = str(getattr(area, 'ui_type', '') or '').upper()
        fallback = None
        for sp in ordered:
            if getattr(sp, 'type', None) != 'IMAGE_EDITOR':
                continue
            if fallback is None:
                fallback = sp
            ui_type = str(getattr(sp, 'ui_type', '') or '').upper()
            mode = str(getattr(sp, 'mode', '') or '').upper()
            show_uvedit = bool(getattr(sp, 'show_uvedit', False))
            if ui_type == 'UV' or mode == 'UV' or show_uvedit:
                return sp
        # During a one-frame area subtype transition Blender can update
        # Area.ui_type before SpaceImageEditor.mode.  Keep the real active image
        # space as the owner rather than dropping the UV editor for that frame.
        if area_ui_type == 'UV':
            return fallback
    except Exception:
        pass
    return None


def _area_is_uv_editor(area) -> bool:
    """Return True only for Image Editor areas currently used as the UV Editor."""
    return _uv_editor_space_for_area(area) is not None


def _uv_iter_live_editor_targets(context=None):
    """Yield every live UV Editor WINDOW region across all Blender windows.

    This deliberately does not trust context.window_manager: app timers, load
    handlers, and shared SpaceImageEditor callbacks can have an empty or foreign
    context while the real UV Editor is open in another Window.
    """
    seen = set()
    for window in _uv_iter_windows(context):
        try:
            window_ptr = _uv_rna_pointer(window)
            screen = getattr(window, 'screen', None)
            if screen is None:
                continue
            for area in tuple(getattr(screen, 'areas', ()) or ()):
                if not _area_is_uv_editor(area):
                    continue
                space = _uv_editor_space_for_area(area)
                if space is None:
                    continue
                for region in tuple(getattr(area, 'regions', ()) or ()):
                    if getattr(region, 'type', None) != 'WINDOW':
                        continue
                    key = (window_ptr, _uv_rna_pointer(area), _uv_rna_pointer(region))
                    if key in seen:
                        continue
                    seen.add(key)
                    yield {
                        'window': window,
                        'screen': screen,
                        'area': area,
                        'region': region,
                        'space_data': space,
                    }
        except Exception:
            continue


def _uv_editor_target_for_region(context=None, region=None, area=None):
    """Resolve the exact live UV editor that owns *region* or *area*."""
    ctx = context or getattr(bpy, 'context', None)
    area = area if area is not None else getattr(ctx, 'area', None)
    region = region if region is not None else getattr(ctx, 'region', None)
    area_ptr = _uv_snapshot_pointer(area)
    region_ptr = _uv_snapshot_pointer(region)

    # Fast path only when the current Window/Screen actually owns the area.
    # An RNA Area from another Blender window can be passed to a timer context;
    # pairing it with ctx.window would publish the snapshot under the wrong owner.
    context_area_ptr = _uv_snapshot_pointer(getattr(ctx, 'area', None))
    context_region_ptr = _uv_snapshot_pointer(getattr(ctx, 'region', None))
    context_owns_area = bool(
        area_ptr
        and context_area_ptr == area_ptr
        and (not region_ptr or context_region_ptr == region_ptr)
    )
    if _area_is_uv_editor(area) and context_owns_area:
        if not region_ptr:
            for candidate_region in tuple(getattr(area, 'regions', ()) or ()):
                if getattr(candidate_region, 'type', None) == 'WINDOW':
                    region = candidate_region
                    region_ptr = _uv_snapshot_pointer(candidate_region)
                    break
        if region_ptr:
            try:
                if any(_uv_snapshot_pointer(item) == region_ptr for item in tuple(getattr(area, 'regions', ()) or ())):
                    return {
                        'window': getattr(ctx, 'window', None),
                        'screen': getattr(ctx, 'screen', None) or getattr(getattr(ctx, 'window', None), 'screen', None),
                        'area': area,
                        'region': region,
                        'space_data': _uv_editor_space_for_area(area),
                    }
            except Exception:
                pass

    for target in tuple(_uv_iter_live_editor_targets(ctx) or ()):
        if region_ptr and _uv_snapshot_pointer(target.get('region')) == region_ptr:
            return target
        if (not region_ptr) and area_ptr and _uv_snapshot_pointer(target.get('area')) == area_ptr:
            return target
    return None


def _uv_editor_area_for_region(context=None, region=None):
    target = _uv_editor_target_for_region(context, region=region)
    return target.get('area') if isinstance(target, dict) else None


def _uv_has_image_editor(context=None) -> bool:
    try:
        return next(iter(_uv_iter_live_editor_targets(context) or ()), None) is not None
    except Exception:
        return False



def _first_image_editor_context(context=None):
    """Return the first live UV Editor WINDOW owner tuple."""
    try:
        ctx = context or bpy.context
        target = next(iter(_uv_iter_live_editor_targets(ctx) or ()), None)
        if isinstance(target, dict):
            return (
                ctx,
                target.get('window'),
                target.get('screen'),
                target.get('area'),
                target.get('region'),
            )
    except Exception:
        pass
    return None


def _store_last_window_mouse(context, mx, my, *, image_event: bool = False):
    try:
        now = time.time()
        coords = (int(mx), int(my))
        _state.last_window_mouse_px = coords
        _state.last_window_mouse_time = now
        window_ptr = _uv_rna_pointer(getattr(context, 'window', None))
        if window_ptr:
            _state.window_mouse_px_by_ptr[int(window_ptr)] = coords
            _state.window_mouse_time_by_ptr[int(window_ptr)] = now
        if image_event:
            _state.last_image_event_time = now
            if window_ptr:
                _state.window_image_event_time_by_ptr[int(window_ptr)] = now
    except Exception:
        pass


def _last_window_mouse_valid(max_age=30.0, context=None, window=None):
    try:
        target_window = window if window is not None else getattr(context, 'window', None)
        window_ptr = _uv_rna_pointer(target_window)
        if window_ptr:
            coords = _state.window_mouse_px_by_ptr.get(int(window_ptr))
            stamp = float(_state.window_mouse_time_by_ptr.get(int(window_ptr), 0.0) or 0.0)
            if coords is not None and (time.time() - stamp) <= float(max_age):
                return int(coords[0]), int(coords[1])
            # Never borrow another Window's coordinates when an exact Window was
            # requested; identical region coordinates in two windows are common.
            return None
        mx, my = getattr(_state, 'last_window_mouse_px', (-100000, -100000))
        if int(mx) < -9999 or int(my) < -9999:
            return None
        age = time.time() - float(getattr(_state, 'last_window_mouse_time', 0.0) or 0.0)
        if age > float(max_age):
            return None
        return int(mx), int(my)
    except Exception:
        return None


def _uv_region_point_is_valid(pt) -> bool:
    try:
        if pt is None or len(pt) < 2:
            return False
        x = float(pt[0])
        y = float(pt[1])
        if not (math.isfinite(x) and math.isfinite(y)):
            return False
        if abs(x) >= _UV_INVALID_REGION_COORD_LIMIT or abs(y) >= _UV_INVALID_REGION_COORD_LIMIT:
            return False
        return True
    except Exception:
        return False


def _window_coords_in_image_editor(context, coords) -> bool:
    try:
        if coords is None:
            return False
        area, region = _window_region_under_mouse(context or bpy.context, int(coords[0]), int(coords[1]), {'IMAGE_EDITOR'})
        return region is not None and _area_is_uv_editor(area)
    except Exception:
        return False


def _uv_probe_should_tag_redraw(region, mx: int, my: int) -> bool:
    """Return True when the coordinate-only UV mouse probe should redraw.

    The modal probe exists only to make current mouse coordinates available in
    Blender builds where passive Window.event_mouse_x/y is stale.  It must not
    cause heavy redraw storms.  Store every coordinate, but request redraw at a
    bounded rate or immediately when the UV editor region changes.
    """
    try:
        now = time.time()
        reg_ptr = int(region.as_pointer()) if region is not None else 0
        prev = getattr(_state, 'last_modal_redraw_px', (-100000, -100000, 0)) or (-100000, -100000, 0)
        try:
            px, py, preg = int(prev[0]), int(prev[1]), int(prev[2])
        except Exception:
            px, py, preg = -100000, -100000, 0
        moved = (abs(int(mx) - px) >= int(_UV_MODAL_MOUSE_PROBE_MIN_PIXEL_DELTA) or
                 abs(int(my) - py) >= int(_UV_MODAL_MOUSE_PROBE_MIN_PIXEL_DELTA))
        region_changed = (reg_ptr != preg)
        elapsed = now - float(getattr(_state, 'last_modal_redraw_time', 0.0) or 0.0)
        if region_changed or elapsed >= float(_UV_MODAL_MOUSE_PROBE_REDRAW_INTERVAL):
            if region_changed or moved or elapsed >= 0.25:
                _state.last_modal_redraw_px = (int(mx), int(my), int(reg_ptr))
                _state.last_modal_redraw_time = now
                return True
        return False
    except Exception:
        return True


def _windows_foreground_client_mouse_coords(context=None):
    """Return Blender-style client mouse coords for the foreground window.

    Blender's Window.event_mouse_x/y is not available or not reliably updated on
    some Blender 5.1 Windows builds.  The old fallback used GetWindowRect(), which
    includes the title bar and border, so the coordinate was vertically offset and
    UV hover hits missed every element.  Use client coordinates instead and flip Y
    to match Blender's lower-left window origin.
    """
    if not sys.platform.startswith('win'):
        return None
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return None
        pt = wintypes.POINT()
        if not user32.GetCursorPos(ctypes.byref(pt)):
            return None
        client_origin = wintypes.POINT(0, 0)
        if not user32.ClientToScreen(hwnd, ctypes.byref(client_origin)):
            return None
        rect = wintypes.RECT()
        if not user32.GetClientRect(hwnd, ctypes.byref(rect)):
            return None
        width = int(rect.right - rect.left)
        height = int(rect.bottom - rect.top)
        if width <= 0 or height <= 0:
            return None
        x = int(pt.x - client_origin.x)
        y_top = int(pt.y - client_origin.y)
        # Blender window coordinates are bottom-left based; Win32 client coords are
        # top-left based.
        y = int(height - y_top)

        # Windows per-monitor DPI scaling can make Win32 client pixels differ
        # from Blender's logical window/region pixels.  Convert to Blender's
        # coordinate space when the dimensions are available; otherwise keep the
        # raw client value.  This keeps UV hover hit testing aligned on 100%,
        # 125%, 150%, and mixed-DPI monitor setups without touching any keymap or
        # selection event.
        try:
            ctx = context or bpy.context
            win = getattr(ctx, 'window', None)
            bw = int(getattr(win, 'width', 0) or 0)
            bh = int(getattr(win, 'height', 0) or 0)
            if bw > 0 and bh > 0 and width > 0 and height > 0:
                sx = float(bw) / float(width)
                sy = float(bh) / float(height)
                if 0.25 <= sx <= 4.0 and 0.25 <= sy <= 4.0:
                    x = int(round(float(x) * sx))
                    y = int(round(float(y) * sy))
                    width = bw
                    height = bh
        except Exception:
            pass

        if x < -64 or y < -64 or x > width + 64 or y > height + 64:
            return None
        return x, y
    except Exception:
        return None



def _x11_active_client_mouse_coords():
    """Return Blender-style client mouse coords on X11 without Blender events.

    Blender's Xlib error handling can terminate the process when the focused X11
    drawable disappears during redraw.  Do not query X11 from the draw/timer path;
    Blender event coordinates and the explicit test hook are sufficient on Linux.
    Windows keeps its Win32 client-coordinate fallback above.
    """
    return None
    try:
        import ctypes
        from ctypes import c_char_p, c_int, c_uint, c_ulong, c_void_p, byref
        lib = ctypes.cdll.LoadLibrary('libX11.so.6')
        lib.XOpenDisplay.argtypes = [c_char_p]
        lib.XOpenDisplay.restype = c_void_p
        dpy = lib.XOpenDisplay(None)
        if not dpy:
            return None
        try:
            lib.XDefaultRootWindow.argtypes = [c_void_p]
            lib.XDefaultRootWindow.restype = c_ulong
            root = lib.XDefaultRootWindow(dpy)
            root_ret = c_ulong(0); child_ret = c_ulong(0)
            root_x = c_int(0); root_y = c_int(0); win_x = c_int(0); win_y = c_int(0); mask = c_uint(0)
            lib.XQueryPointer.argtypes = [c_void_p, c_ulong, ctypes.POINTER(c_ulong), ctypes.POINTER(c_ulong), ctypes.POINTER(c_int), ctypes.POINTER(c_int), ctypes.POINTER(c_int), ctypes.POINTER(c_int), ctypes.POINTER(c_uint)]
            lib.XQueryPointer.restype = c_int
            if not lib.XQueryPointer(dpy, root, byref(root_ret), byref(child_ret), byref(root_x), byref(root_y), byref(win_x), byref(win_y), byref(mask)):
                return None
            focus = c_ulong(0); revert = c_int(0)
            try:
                lib.XGetInputFocus.argtypes = [c_void_p, ctypes.POINTER(c_ulong), ctypes.POINTER(c_int)]
                lib.XGetInputFocus(dpy, byref(focus), byref(revert))
            except Exception:
                focus.value = 0
            target = focus.value or child_ret.value
            if not target:
                return int(root_x.value), int(root_y.value)
            x = c_int(0); y = c_int(0); w = c_uint(0); h = c_uint(0); border = c_uint(0); depth = c_uint(0); root2 = c_ulong(0)
            try:
                lib.XGetGeometry.argtypes = [c_void_p, c_ulong, ctypes.POINTER(c_ulong), ctypes.POINTER(c_int), ctypes.POINTER(c_int), ctypes.POINTER(c_uint), ctypes.POINTER(c_uint), ctypes.POINTER(c_uint), ctypes.POINTER(c_uint)]
                if not lib.XGetGeometry(dpy, target, byref(root2), byref(x), byref(y), byref(w), byref(h), byref(border), byref(depth)):
                    return None
                dst_x = c_int(0); dst_y = c_int(0); child2 = c_ulong(0)
                lib.XTranslateCoordinates.argtypes = [c_void_p, c_ulong, c_ulong, c_int, c_int, ctypes.POINTER(c_int), ctypes.POINTER(c_int), ctypes.POINTER(c_ulong)]
                if not lib.XTranslateCoordinates(dpy, root, target, root_x.value, root_y.value, byref(dst_x), byref(dst_y), byref(child2)):
                    return None
                return int(dst_x.value), int(int(h.value) - int(dst_y.value))
            except Exception:
                return int(root_x.value), int(root_y.value)
        finally:
            try:
                lib.XCloseDisplay(dpy)
            except Exception:
                pass
    except Exception:
        return None

def _window_event_mouse_coords(context=None):
    """Return absolute Blender window mouse coords without changing keymaps/events.

    The UV overlay is visual-only: no automatic keymap and no event-consuming
    modal operator.  Mouse coordinates are gathered passively.  On Windows, where
    Blender 5.1 may not expose reliable Window.event_mouse_x/y, a corrected Win32
    client-coordinate fallback is used.
    """
    ctx = context or bpy.context
    # Explicit test hook used by automated visual/runtime tests.  Keep this before
    # passive/OS probing so tests are deterministic on Linux/Xvfb.
    try:
        test = bpy.app.driver_namespace.get('SOS_UV_TEST_MOUSE', None)
        if test is not None:
            return int(test[0]), int(test[1])
    except Exception:
        pass

    passive = None
    try:
        win = getattr(ctx, 'window', None)
        if win is not None:
            mx = getattr(win, 'event_mouse_x', None)
            my = getattr(win, 'event_mouse_y', None)
            if mx is not None and my is not None:
                passive = (int(mx), int(my))
                # If Blender says the mouse is actually over a UV/Image Editor
                # window region, this is the most accurate source.
                if _window_coords_in_image_editor(ctx, passive):
                    return passive
    except Exception:
        passive = None

    # The event-only probe stores coordinates per Blender Window. Prefer that
    # exact owner before any OS/global fallback so a UV Editor in another Window
    # can never consume foreign mouse coordinates.
    try:
        event_cached = _last_window_mouse_valid(max_age=0.75, context=ctx)
        if event_cached is not None and _window_coords_in_image_editor(ctx, event_cached):
            return event_cached
    except Exception:
        pass

    # OS-level mouse queries are reliable but can be expensive on some Linux/X11
    # and remote-desktop setups.  Cache them briefly so a fast redraw loop does not
    # repeatedly cross the OS boundary while the visual result remains identical.
    try:
        now = time.time()
        last_os = float(getattr(_state, 'last_os_mouse_probe_time', 0.0) or 0.0)
        cached_os = getattr(_state, 'last_os_mouse_probe_coords', None)
        if cached_os is not None and (now - last_os) < _UV_OS_MOUSE_PROBE_MIN_INTERVAL:
            return int(cached_os[0]), int(cached_os[1])
    except Exception:
        now = time.time()
    os_coords = _windows_foreground_client_mouse_coords(ctx)
    if os_coords is None:
        # Avoid X11 pointer queries in normal draw/timer paths.  They are
        # disproportionately expensive on Linux/Xvfb/remote desktops and were a
        # major source of UV Overlay slowness.  Windows keeps the Win32 client
        # coordinate fallback above; Linux uses Blender's event fields or the
        # deterministic test hook unless diagnostics explicitly enable X11.
        try:
            allow_x11 = bool(getattr(bpy.app, 'driver_namespace', {}).get('SOS_UV_ALLOW_X11_MOUSE_PROBE', False))
        except Exception:
            allow_x11 = False
        if allow_x11:
            os_coords = _x11_active_client_mouse_coords()
    if os_coords is not None:
        try:
            _state.last_os_mouse_probe_time = now
            _state.last_os_mouse_probe_coords = (int(os_coords[0]), int(os_coords[1]))
        except Exception:
            pass
        return os_coords

    # Prefer the last event-probe coordinate for a short time when Blender's
    # passive Window.event_mouse_* value is stale or belongs to another editor.
    # This makes hover tracking reliable on systems where passive window mouse
    # fields do not update every redraw.  Plain Image Editor coordinates are not
    # treated as UV-editor coordinates by _window_coords_in_image_editor().
    try:
        last = _last_window_mouse_valid(max_age=0.75, context=ctx)
        if last is not None and _window_coords_in_image_editor(ctx, last):
            return last
    except Exception:
        pass

    # Returning a passive coordinate outside the UV editor lets the caller clear a
    # stale hover state.  If no coordinate exists at all, the last valid hover will
    # only be reused for a short draw-side refresh path.
    return passive

def _uv_mouse_buttons_down() -> bool:
    """Return True while the user is pressing mouse buttons, without events."""
    try:
        if sys.platform.startswith('win'):
            down = _win_any_mouse_button_down()
            return bool(down)
    except Exception:
        pass
    try:
        return bool(bpy.app.driver_namespace.get('SOS_UV_TEST_MOUSE_DOWN', False))
    except Exception:
        return False


def _uv_mouse_button_should_guard(context=None) -> bool:
    """Deprecated guard helper kept for compatibility.

    UV Overlay must not hide/rebuild solely because the mouse is pressed.  Active
    transforms and external UV tools are detected by modal/operator state.
    """
    return False


def _uv_latest_operator_name(context=None) -> str:
    try:
        wm = getattr(context or bpy.context, 'window_manager', None)
        ops = getattr(wm, 'operators', None)
        if not ops or len(ops) <= 0:
            return ''
        op = ops[-1]
        return str(getattr(op, 'bl_idname', '') or getattr(op, 'name', '') or '').lower()
    except Exception:
        return ''


def _uv_note_recent_interaction_operator(context=None) -> bool:
    """Return True when the most recent operator can affect UV interaction.

    This is deliberately conservative.  Reading edit BMesh from a draw/timer
    callback while Blender is selecting or transforming UVs can race Blender's
    own UV tools.  For a display-only overlay, a short no-read window is safer
    than keeping a transient hover visible.
    """
    try:
        name = _uv_latest_operator_name(context)
        if not name:
            return False
        if any(tok in name for tok in _UV_LAST_INTERACTION_NAMES):
            now = time.time()
            prev_name = str(getattr(_state, 'last_interaction_operator_name', '') or '')
            if name != prev_name:
                _state.last_interaction_operator_name = name
                _state.last_input_guard_time = now
                return True
            age = now - float(getattr(_state, 'last_input_guard_time', 0.0) or 0.0)
            return age <= float(_UV_POST_OPERATOR_SAFE_DELAY)
    except Exception:
        return False
    return False


def _uv_external_uv_runtime_active(context=None) -> bool:
    """Return True only while an external UV tool is actively interacting.

    Static Smart UV Suite options and stale driver-namespace flags must not keep
    UV Overlay hidden.  A runtime flag is trusted only while a live modal/transform
    operator is present, while the mouse is actively down inside the UV editor, or
    for a short freshness window after the flag first appears.
    """
    try:
        ns = bpy.app.driver_namespace
        keys = tuple(key for key in (
            'STS_UV_MODAL_ACTIVE', 'STS_UV_STRICT_LOCAL_PICK_ACTIVE',
            'SUV_MODAL_ACTIVE', 'SUV_TRANSFORM_ACTIVE', 'SUV_DRAG_ACTIVE',
            'SMART_UV_MODAL_ACTIVE', 'SMART_UV_TRANSFORM_ACTIVE',
        ) if bool(ns.get(key, False)))
        if not keys:
            _state.external_uv_runtime_guard_started = 0.0
            _state.last_external_uv_runtime_keys = ()
            return False
        now = time.time()
        if tuple(getattr(_state, 'last_external_uv_runtime_keys', ()) or ()) != keys:
            _state.last_external_uv_runtime_keys = keys
            _state.external_uv_runtime_guard_started = now
        if _uv_modal_interaction_active(context):
            return True
        if _uv_mouse_button_should_guard(context):
            return True
        age = now - float(getattr(_state, 'external_uv_runtime_guard_started', now) or now)
        if age <= float(_UV_EXTERNAL_RUNTIME_STUCK_TIMEOUT):
            return True
        return False
    except Exception:
        return False


def _uv_operator_name_from_signature(signature) -> str:
    try:
        if not signature:
            return ''
        return str(signature[1] or '').lower()
    except Exception:
        return ''


def _uv_normalize_modal_operator_name(name: str) -> str:
    """Return a stable lowercase operator id for live-modal classification.

    ``Window.modal_operators`` can expose either Blender class names
    (``TRANSFORM_OT_translate``) or RNA id names (``transform.translate``).
    Normalizing only separators lets the classifier use exact operator families
    instead of unsafe substring tests such as ``"modal" in name``.
    """
    try:
        text = str(name or '').strip().lower()
        if not text:
            return ''
        for token in ('.', ':', '-', ' ', '/', '\\'):
            text = text.replace(token, '_')
        while '__' in text:
            text = text.replace('__', '_')
        return text.strip('_')
    except Exception:
        return ''


def _uv_name_has_word(normalized_name: str, token: str) -> bool:
    """Whole-word (underscore-bounded) token test on a normalized operator id.

    Substring matching classified resident pass-through watchers as UV edits:
    ``'rip' in 'uv_gizmo_grip_fix_sentinel'`` is True as a substring but False
    as a word.  Multi-word tokens (``shrink_fatten``) match as underscore-
    bounded phrases.  Leading/trailing underscores on the token are ignored so
    legacy prefix markers (``suv_``) keep matching their word form.
    """
    try:
        token = str(token or '').strip('_')
        if not normalized_name or not token:
            return False
        return ('_' + token + '_') in ('_' + str(normalized_name) + '_')
    except Exception:
        return False


# Passive resident modals (pass-through watchers, hover daemons, sentinels)
# must never be classified as live UV interactions.  smart_transform_suite's
# permanently-resident 'wm.sts_crossing_select_watch' and smart_uv_suite's
# 'wm.smart_uv_crossing_watch' / 'uv_gizmo_grip_fix_sentinel' latched the
# interaction guard forever and made every UV-editor feature inert.
_UV_PASSIVE_MODAL_TOKENS = (
    'daemon', 'watchdog', 'watcher', 'watch', 'sentinel', 'tracker',
    'probe', 'listener', 'monitor', 'observer', 'hover', 'redraw', 'timer',
)


def _uv_operator_is_transform_like_name(name: str) -> bool:
    """True only for a live operator that can mutate UV/edit coordinates.

    A resident pass-through operator is not a transform merely because its class
    name contains ``modal``.  The previous broad test permanently disabled every
    UV draw path whenever another Smart Tools add-on kept such an operator alive.
    """
    n = _uv_normalize_modal_operator_name(name)
    if not n:
        return False

    # Blender's native transform operators use one of these exact namespaces.
    if n.startswith(('transform_ot_', 'transform_')):
        return True

    # Known drag-move helpers used by the Smart tool family are genuine live
    # coordinate mutations, not passive mouse trackers.
    if 'instant_select_drag_move' in n or n.endswith('_drag_move'):
        return True

    if any(_uv_name_has_word(n, token) for token in _UV_PASSIVE_MODAL_TOKENS):
        return False

    external_markers = (
        'smartuvsuite', 'smart_uv_suite', 'smartuv', 'smart_uv',
        'suv_', 'sts_',
    )
    transform_tokens = (
        'transform', 'translate', 'rotate', 'resize', 'scale', 'grab',
        'move', 'slide', 'shear', 'bend', 'shrink_fatten', 'push_pull',
    )
    return bool(
        any(_uv_name_has_word(n, marker) for marker in external_markers)
        and any(_uv_name_has_word(n, token) for token in transform_tokens)
    )


def _uv_operator_is_uv_edit_like_name(name: str) -> bool:
    """True only for live modal operators that can mutate UV/edit data.

    Do not classify every ``UV_OT_*``, ``MESH_OT_*``, ``OBJECT_OT_*`` or every
    name containing ``select`` as dangerous.  Add-ons commonly keep passive modal
    trackers resident under those namespaces; treating those as edits makes the
    UV overlay and UV proportional overlay remain blank indefinitely.
    """
    n = _uv_normalize_modal_operator_name(name)
    if not n:
        return False

    if any(_uv_name_has_word(n, token) for token in _UV_PASSIVE_MODAL_TOKENS):
        return False

    if n.startswith('uv_ot_'):
        uv_mutation_tokens = (
            'select', 'stitch', 'rip', 'unwrap', 'pack', 'minimize_stretch',
            'sculpt', 'pin', 'weld', 'merge', 'split', 'delete', 'dissolve',
            'seam', 'align', 'average_islands_scale', 'follow_active_quads',
            'project', 'reset', 'snap_selected',
        )
        return any(_uv_name_has_word(n, token) for token in uv_mutation_tokens)

    if n.startswith('mesh_ot_'):
        mesh_modal_tokens = (
            'bevel', 'inset', 'knife', 'loopcut', 'edge_slide', 'vert_slide',
            'bisect', 'spin', 'rip', 'extrude', 'polybuild',
            'offset_edge_loops',
        )
        return any(_uv_name_has_word(n, token) for token in mesh_modal_tokens)

    external_markers = (
        'smartuvsuite', 'smart_uv_suite', 'smartuv', 'smart_uv',
        'suv_', 'sts_',
    )
    external_mutation_tokens = (
        'transform', 'translate', 'rotate', 'resize', 'scale', 'move', 'drag',
        'select', 'crossing', 'gesture', 'lasso', 'box', 'circle', 'unwrap',
        'pack', 'stitch', 'rip', 'pin', 'merge', 'split', 'delete',
        'dissolve', 'seam',
    )
    return bool(
        any(_uv_name_has_word(n, marker) for marker in external_markers)
        and any(_uv_name_has_word(n, token) for token in external_mutation_tokens)
    )


def _uv_mark_interaction_guard(seconds: float = _UV_INTERACTION_GUARD_SECONDS) -> None:
    try:
        until = time.time() + max(0.02, float(seconds))
        if until > float(getattr(_state, 'interaction_guard_until', 0.0) or 0.0):
            _state.interaction_guard_until = until
    except Exception:
        pass


def _uv_interaction_guard_active(context=None) -> bool:
    """True while UV Overlay must not read live edit BMesh/UV data.

    The guard is intentionally narrow: active modal transforms or explicit
    external runtime flags.  Completed operator history is
    used only for cache invalidation elsewhere, not for hiding the overlay.
    """
    now = time.time()
    try:
        if bool(bpy.app.driver_namespace.get('SOS_UV_TEST_TRANSFORM_ACTIVE', False)):
            return True
    except Exception:
        pass
    try:
        if _uv_external_uv_runtime_active(context):
            _uv_mark_interaction_guard(_UV_TRANSFORM_GUARD_SECONDS)
            return True
    except Exception:
        pass
    try:
        if _uv_modal_interaction_active(context):
            return True
    except Exception:
        pass
    # Mouse-button state alone is intentionally ignored; it can be stale and
    # must not make the overlay disappear outside real modal transforms.
    try:
        return now < float(getattr(_state, 'interaction_guard_until', 0.0) or 0.0)
    except Exception:
        return False


def _uv_input_or_transform_active(context=None) -> bool:
    try:
        return bool(_uv_interaction_guard_active(context))
    except Exception:
        return False


def _uv_can_read_edit_bmesh(context=None) -> bool:
    """Return True only when live edit-BMesh reads are safe for UV Overlay.

    UV Overlay is strictly display-only.  Its draw/timer callbacks must never
    read the live edit BMesh while Blender or another UV tool is likely to be
    selecting, transforming, unwrapping, packing, or dragging UV/edit data.  This
    is stronger than merely avoiding writes: it prevents read callbacks from
    participating in Blender 5.1's live UV selection/transform flush timing.
    """
    try:
        if _uv_external_uv_runtime_active(context):
            _uv_mark_interaction_guard(_UV_TRANSFORM_GUARD_SECONDS)
            return False
    except Exception:
        pass
    try:
        if _uv_interaction_guard_active(context):
            _state.bmesh_read_block_count = int(getattr(_state, 'bmesh_read_block_count', 0) or 0) + 1
            return False
    except Exception:
        return False
    return True


def _uv_active_modal_operator_names(context=None):
    """Return unique live modal operator names across every Blender window.

    App timers can run with no current WindowManager.  Enumerating the same live
    windows used by the UV-editor resolver keeps native transform protection
    working without letting a foreign timer context hide the UV overlay.
    """
    names = []
    seen = set()
    try:
        for win in _uv_iter_windows(context or getattr(bpy, 'context', None)):
            for op in tuple(getattr(win, 'modal_operators', ()) or ()):
                try:
                    raw_name = str(getattr(op, 'bl_idname', '') or getattr(op, 'name', '') or '')
                except Exception:
                    raw_name = ''
                name = _uv_normalize_modal_operator_name(raw_name)
                if not name:
                    continue
                # Own pass-through coordinate collectors never edit UV data.
                if (
                    'sos_ot_uv_hover_daemon' in name
                    or 'sos_uv_hover_daemon' in name
                    or 'uv_hover_mouse_probe' in name
                ):
                    continue
                if name in seen:
                    continue
                seen.add(name)
                names.append(name)
    except Exception:
        pass
    return tuple(names)


# A real interactive transform/drag lasts seconds.  A modal operator that stays
# continuously alive longer than this is a resident watcher (pass-through mouse
# tracker kept alive by an ensure-timer) and must never latch the interaction
# guard, regardless of how its name classifies.  Freshness-window precedent:
# _uv_external_uv_runtime_active / _UV_EXTERNAL_RUNTIME_STUCK_TIMEOUT.
_UV_RESIDENT_MODAL_TIMEOUT = 5.0


def _uv_modal_interaction_active(context=None) -> bool:
    """True while Blender or another tool owns interactive UV/transform input."""
    try:
        now = time.time()
        first_seen = getattr(_state, 'modal_operator_first_seen', None)
        if not isinstance(first_seen, dict):
            first_seen = {}
        live_first_seen = {}
        interaction = False
        for name in _uv_active_modal_operator_names(context):
            started = float(first_seen.get(name, now))
            live_first_seen[name] = started
            if not (_uv_operator_is_transform_like_name(name) or _uv_operator_is_uv_edit_like_name(name)):
                continue
            if (now - started) > float(_UV_RESIDENT_MODAL_TIMEOUT):
                # Continuously alive far longer than any real transform/drag:
                # a resident modal must not keep the UV overlay suppressed.
                continue
            interaction = True
        _state.modal_operator_first_seen = live_first_seen
        if interaction:
            _uv_mark_interaction_guard(_UV_TRANSFORM_GUARD_SECONDS)
            return True
    except Exception:
        pass
    return False


def _uv_may_read_edit_bmesh(context=None) -> bool:
    """Return True only when UV Overlay may safely read edit BMesh.

    This is the hard display-only gate for UV Overlay.  It blocks every edit-BMesh
    read while Blender or another UV tool is transforming, dragging, selecting,
    unwrapping, packing, or otherwise mutating UV/edit data.  The draw handler
    stays installed, but collectors never touch live edit data during interaction.
    """
    try:
        if _uv_external_uv_runtime_active(context):
            _uv_mark_interaction_guard(_UV_INTERACTION_GUARD_SECONDS)
            return False
    except Exception:
        pass
    try:
        return not _uv_interaction_guard_active(context)
    except Exception:
        return False


def _uv_cache_signature_without_generation(sig):
    try:
        return tuple(sig or ())
    except Exception:
        return tuple()


def _uv_stale_cache_compatible(context, region, prefs, cache) -> bool:
    try:
        if not isinstance(cache, dict):
            return False
        light = _uv_cache_light_signature(context, region, prefs)
        cached = cache.get('light_sig') or cache.get('sig')
        if light is None or cached is None:
            return False
        return _uv_cache_signature_without_generation(light) == _uv_cache_signature_without_generation(cached)
    except Exception:
        return False


def _remember_uv_hover_cache_as_stale() -> None:
    try:
        cache = getattr(_state, 'uv_hover_cache', None)
        if isinstance(cache, dict):
            _state.uv_hover_stale_cache = cache
            _state.uv_hover_stale_cache_time = time.time()
    except Exception:
        pass


def _get_compatible_stale_uv_hover_cache(context, region, prefs, *, max_age: float = 2.50):
    try:
        stale = getattr(_state, 'uv_hover_stale_cache', None)
        age = time.time() - float(getattr(_state, 'uv_hover_stale_cache_time', 0.0) or 0.0)
        if age <= float(max_age) and _uv_stale_cache_compatible(context, region, prefs, stale):
            return stale
    except Exception:
        pass
    return None


def _window_region_under_mouse(context, mx, my, area_types):
    """Return (area, region) for absolute window coordinates without stealing events."""
    try:
        if isinstance(area_types, str):
            area_types = {area_types}
        else:
            area_types = set(area_types or ())
        screen = getattr(context, 'screen', None)
        if screen is None:
            screen = getattr(getattr(context, 'window', None), 'screen', None)
        if screen is None:
            return None, None
        x = int(mx)
        y = int(my)
        for area in getattr(screen, 'areas', ()) or ():
            if getattr(area, 'type', None) not in area_types:
                continue
            for region in getattr(area, 'regions', ()) or ():
                if getattr(region, 'type', None) != 'WINDOW':
                    continue
                if region.x <= x <= region.x + region.width and region.y <= y <= region.y + region.height:
                    return area, region
    except Exception:
        pass
    return None, None


def _event_in_image_editor(context, event) -> bool:
    try:
        _area, region = _window_region_under_mouse(context, getattr(event, 'mouse_x', -100000), getattr(event, 'mouse_y', -100000), {'IMAGE_EDITOR'})
        return region is not None
    except Exception:
        return False


def _event_image_editor_area_region(context, event):
    try:
        return _window_region_under_mouse(
            context,
            getattr(event, 'mouse_x', -100000),
            getattr(event, 'mouse_y', -100000),
            {'IMAGE_EDITOR'},
        )
    except Exception:
        return None, None


def _event_in_uv_editor(context, event) -> bool:
    try:
        area, region = _event_image_editor_area_region(context, event)
        return region is not None and _area_is_uv_editor(area)
    except Exception:
        return False


def _event_in_view3d(context, event) -> bool:
    try:
        _area, region = _window_region_under_mouse(context, getattr(event, 'mouse_x', -100000), getattr(event, 'mouse_y', -100000), {'VIEW_3D'})
        return region is not None
    except Exception:
        return False


def _uv_modal_tracker_alive(window_ptr=None) -> bool:
    try:
        refs = getattr(_state, 'operator_refs', None)
        if not isinstance(refs, dict):
            refs = {}
            _state.operator_refs = refs
        current_generation = int(getattr(_state, 'modal_generation', 0) or 0)
        live = False
        for key, op in tuple(refs.items()):
            try:
                if op is None or int(getattr(op, '_sos_uv_generation', 0) or 0) != current_generation:
                    refs.pop(key, None)
                    continue
                if window_ptr is None or int(key) == int(window_ptr):
                    live = True
            except Exception:
                refs.pop(key, None)
        return bool(live)
    except Exception:
        return False


def _uv_start_modal_tracker_if_needed(context=None, *, force: bool = False) -> None:
    """Start one event-only UV mouse probe per Window that contains a UV editor."""
    try:
        ctx = context or bpy.context
        if not _uv_runtime_requested(ctx):
            return None
        try:
            ns = getattr(bpy.app, 'driver_namespace', {})
            explicit_allow = bool(ns.get('SOS_UV_ALLOW_MODAL_MOUSE_PROBE', False))
        except Exception:
            explicit_allow = False
        # Older diagnostic builds could leave SOS_UV_DISABLE_MODAL_MOUSE_PROBE
        # in driver_namespace across an install-over-active.  It is not a user
        # preference and must never disable the production UV coordinate probe.
        allow_modal_probe = bool(_UV_MODAL_MOUSE_PROBE_AUTO) or explicit_allow
        if not allow_modal_probe:
            _state.is_running = bool(getattr(_state, 'runtime_registered', False))
            return None
        refs = getattr(_state, 'operator_refs', None)
        if not isinstance(refs, dict):
            refs = {}
            _state.operator_refs = refs
        seen_windows = set()
        for override in tuple(_uv_iter_editor_overrides(ctx) or ()):
            window = override.get('window')
            window_ptr = _uv_snapshot_pointer(window)
            if not window_ptr or window_ptr in seen_windows:
                continue
            seen_windows.add(window_ptr)
            if not force and _uv_modal_tracker_alive(window_ptr):
                continue
            try:
                with ctx.temp_override(**override):
                    bpy.ops.sos.uv_hover_daemon('INVOKE_DEFAULT')
            except Exception:
                refs.pop(window_ptr, None)
                continue
        _state.is_running = bool(getattr(_state, 'runtime_registered', False))
    except Exception:
        pass
    return None



def _kill_legacy_uv_modal_runtime() -> None:
    """Stop modal UV event probes left alive by older Smart Overlay builds.

    Older 1.2.13x versions could leave a pass-through modal instance alive when
    the extension was reinstalled over itself.  That instance still received UV
    editor events and could read BMesh during transforms.  New builds are
    display-only, so we explicitly disable any old module state and timers.
    """
    try:
        current_mod = sys.modules.get(__name__)
        for name, mod in list(sys.modules.items()):
            if mod is None or mod is current_mod:
                continue
            if 'smart_overlay_suite' not in str(name) or not str(name).endswith('.uv'):
                continue
            st = getattr(mod, '_state', None)
            if st is not None:
                try:
                    setattr(st, 'runtime_registered', False)
                    setattr(st, 'is_running', False)
                    setattr(st, 'is_clicking', False)
                    setattr(st, 'clicking_until', 0.0)
                    setattr(st, 'operator_ref', None)
                    setattr(st, 'modal_generation', int(getattr(st, 'modal_generation', 0) or 0) + 1000000)
                except Exception:
                    pass
            timer_fn = getattr(mod, '_ensure_uv_daemon_running', None)
            if timer_fn is not None:
                try:
                    if bpy.app.timers.is_registered(timer_fn):
                        bpy.app.timers.unregister(timer_fn)
                except Exception:
                    pass
            # Install-over-active can leave the old SpaceImageEditor callback and
            # snapshot handlers alive even after its modal state was fenced.  The
            # old callback can clear hover state in the same UV frame as the new
            # callback.  Remove only resources owned by the older UV module.
            if st is not None:
                old_handle = getattr(st, 'draw_handle', None)
                if old_handle is not None:
                    try:
                        bpy.types.SpaceImageEditor.draw_handler_remove(old_handle, 'WINDOW')
                    except Exception:
                        pass
                    try:
                        setattr(st, 'draw_handle', None)
                    except Exception:
                        pass
            try:
                unregister_handlers = getattr(mod, '_unregister_uv_snapshot_handlers', None)
                if callable(unregister_handlers):
                    unregister_handlers()
            except Exception:
                pass
            for timer_name in ('_uv_snapshot_rebuild_timer', '_uv_runtime_watchdog_timer'):
                old_timer = getattr(mod, timer_name, None)
                if old_timer is not None:
                    try:
                        if bpy.app.timers.is_registered(old_timer):
                            bpy.app.timers.unregister(old_timer)
                    except Exception:
                        pass
    except Exception:
        pass


def _uv_install_draw_handler_if_needed(*, force: bool = False) -> None:
    if force and _state.draw_handle is not None:
        try:
            bpy.types.SpaceImageEditor.draw_handler_remove(_state.draw_handle, 'WINDOW')
        except Exception:
            pass
        _state.draw_handle = None
        _state.last_rehook_time = time.time()
    if _state.draw_handle is None:
        try:
            _state.draw_handle = bpy.types.SpaceImageEditor.draw_handler_add(
                _draw_uv_hover, (), 'WINDOW', 'POST_PIXEL'
            )
        except Exception:
            _state.draw_handle = None


def _uv_reactivate_runtime_state() -> None:
    # Keep the UV runtime logical state alive across editor switches and scene changes.
    _state.is_running = True
    try:
        if _scene_daemon_prop_exists():
            for scene in getattr(bpy.data, 'scenes', ()) or ():
                try:
                    setattr(scene, _SCENE_DAEMON_PROP, True)
                except Exception:
                    continue
    except Exception:
        pass



def _sts_uv_interop_guard_active():
    try:
        ns = bpy.app.driver_namespace
        return bool(ns.get('STS_UV_MODAL_ACTIVE', False) or ns.get('STS_UV_STRICT_LOCAL_PICK_ACTIVE', False))
    except Exception:
        return False


def _empty_bridge_payload():
    return {"verts": set(), "edges": set(), "faces": set()}

def _bridge_payload_from_lists(verts=None, edges=None, faces=None):
    return {
        "verts": set(int(v) for v in (verts or [])),
        "edges": set(int(e) for e in (edges or [])),
        "faces": set(int(f) for f in (faces or [])),
    }

def get_hover_bridge_indices(context=None, obj=None):
    return _empty_bridge_payload()

def get_selected_bridge_indices(context=None, obj=None):
    return _empty_bridge_payload()

# -----------------------------------------------------------------------------
# Math utilities (same algorithm)
# -----------------------------------------------------------------------------
def _point_in_polygon_2d(px, py, poly):
    inside = False
    n = len(poly)
    if n < 3:
        return False
    p1x, p1y = poly[0]
    for i in range(1, n + 1):
        p2x, p2y = poly[i % n]
        if py > min(p1y, p2y):
            if py <= max(p1y, p2y):
                if px <= max(p1x, p2x):
                    if p1y != p2y:
                        xints = (py - p1y) * (p2x - p1x) / ((p2y - p1y) if (p2y - p1y) != 0 else 1e-20) + p1x
                    if p1x == p2x or px <= xints:
                        inside = not inside
        p1x, p1y = p2x, p2y
    return inside

def _dist_to_segment_2d(px, py, ax, ay, bx, by):
    ab_x, ab_y = bx - ax, by - ay
    ap_x, ap_y = px - ax, py - ay
    ab_len_sq = ab_x**2 + ab_y**2
    if ab_len_sq == 0:
        return math.hypot(ap_x, ap_y)
    t = (ap_x * ab_x + ap_y * ab_y) / ab_len_sq
    if t < 0.0:
        t = 0.0
    elif t > 1.0:
        t = 1.0
    return math.hypot(px - (ax + t * ab_x), py - (ay + t * ab_y))

def _edge_to_quad(p1, p2, thickness):
    dx, dy = p2[0] - p1[0], p2[1] - p1[1]
    length = math.hypot(dx, dy)
    if length == 0:
        return []
    nx, ny = -dy / length * thickness, dx / length * thickness
    return [
        (p1[0] + nx, p1[1] + ny),
        (p1[0] - nx, p1[1] - ny),
        (p2[0] - nx, p2[1] - ny),
        (p2[0] + nx, p2[1] + ny),
    ]



# ----------------------------------------------------------------------------- 
# Lightweight UV hover cache
# ----------------------------------------------------------------------------- 
def _uv_select_flags_from_context(context, prefs):
    try:
        ts = context.scene.tool_settings
        is_sync = bool(getattr(ts, "use_uv_select_sync", False))
        if is_sync:
            mode = tuple(bool(v) for v in getattr(ts, 'mesh_select_mode', (True, False, False)))
            check_v, check_e, check_f = mode[0], mode[1], mode[2]
            mode_key = ('SYNC', mode)
        else:
            uv_mode = getattr(ts, 'uv_select_mode', 'VERTEX')
            if isinstance(uv_mode, str):
                mode_values = {uv_mode}
            else:
                mode_values = set(uv_mode or ())
            check_v = 'VERTEX' in mode_values
            check_e = 'EDGE' in mode_values
            check_f = ('FACE' in mode_values) or ('ISLAND' in mode_values)
            mode_key = ('UV', tuple(sorted(str(v) for v in mode_values)))
        check_v = bool(check_v) and bool(getattr(prefs, "show_hov_uv_verts", True))
        check_e = bool(check_e) and bool(getattr(prefs, "show_hov_uv_edges", True))
        check_f = bool(check_f) and bool(getattr(prefs, "show_hov_uv_faces", True))
        return is_sync, check_v, check_e, check_f, mode_key
    except Exception:
        return False, False, False, False, ('INVALID',)


def _uv_view2d_signature(region):
    try:
        w = int(getattr(region, 'width', 0) or 0)
        h = int(getattr(region, 'height', 0) or 0)
        if w <= 0 or h <= 0:
            return None
        v2d = getattr(region, 'view2d', None)
        if v2d is None:
            return ('FALLBACK_UV01', w, h)
        a = v2d.region_to_view(0, 0)
        b = v2d.region_to_view(w, h)
        if not (_uv_region_point_is_valid(a) and _uv_region_point_is_valid(b)):
            return ('FALLBACK_UV01', w, h)
        return (w, h, round(float(a[0]), 7), round(float(a[1]), 7), round(float(b[0]), 7), round(float(b[1]), 7))
    except Exception:
        return None


def _uv_fallback_view_to_region(region, u, v):
    try:
        w = max(1, int(getattr(region, 'width', 0) or 0))
        h = max(1, int(getattr(region, 'height', 0) or 0))
        margin = 8.0
        usable_w = max(1.0, float(w) - margin * 2.0)
        usable_h = max(1.0, float(h) - margin * 2.0)
        return (margin + float(u) * usable_w, margin + float(v) * usable_h)
    except Exception:
        return None



def _uv_region_affine_transform(region):
    """Return a fast affine UV-view to region-pixel transform for View2D.

    Some Blender 5.1 Image/UV Editor draw contexts report View2D as NaN for
    the first few frames or under headless/window-manager combinations.  The old
    code returned None in that case, so every UV loop called the slow View2D API
    fallback again.  Return the exact same UV0-1 fallback as an affine transform
    instead, keeping the visible behavior while making cache rebuilds cheap.
    """
    try:
        w = int(getattr(region, 'width', 0) or 0)
        h = int(getattr(region, 'height', 0) or 0)
        if w <= 0 or h <= 0:
            return None

        def _fallback_affine():
            margin = 8.0
            usable_w = max(1.0, float(w) - margin * 2.0)
            usable_h = max(1.0, float(h) - margin * 2.0)
            # x = (u - x0) * sx == margin + u * usable_w
            return (-margin / usable_w, -margin / usable_h, usable_w, usable_h, int(w), int(h))

        v2d = getattr(region, 'view2d', None)
        if v2d is None:
            return _fallback_affine()
        a = v2d.region_to_view(0, 0)
        b = v2d.region_to_view(w, h)
        if not (_uv_region_point_is_valid(a) and _uv_region_point_is_valid(b)):
            return _fallback_affine()
        dx = float(b[0]) - float(a[0])
        dy = float(b[1]) - float(a[1])
        if abs(dx) <= 1.0e-20 or abs(dy) <= 1.0e-20:
            return _fallback_affine()
        return (float(a[0]), float(a[1]), float(w) / dx, float(h) / dy, int(w), int(h))
    except Exception:
        try:
            w = int(getattr(region, 'width', 0) or 0)
            h = int(getattr(region, 'height', 0) or 0)
            margin = 8.0
            usable_w = max(1.0, float(w) - margin * 2.0)
            usable_h = max(1.0, float(h) - margin * 2.0)
            return (-margin / usable_w, -margin / usable_h, usable_w, usable_h, int(w), int(h))
        except Exception:
            return None


def _uv_to_region_px_fast(region, transform, u, v):
    """Fast path for bulk UV -> pixel projection, falling back to View2D API."""
    try:
        if transform is not None:
            x0, y0, sx, sy, _w, _h = transform
            return ((float(u) - x0) * sx, (float(v) - y0) * sy)
    except Exception:
        pass
    return _uv_to_region_px(region, u, v)


def _uv_to_region_px(region, u, v):
    try:
        v2d = getattr(region, 'view2d', None)
        if v2d is not None:
            px = v2d.view_to_region(float(u), float(v), clip=False)
            if _uv_region_point_is_valid(px):
                return (float(px[0]), float(px[1]))
        return _uv_fallback_view_to_region(region, u, v)
    except Exception:
        return _uv_fallback_view_to_region(region, u, v)


def _uv_same_mesh_cache_flags(prefs):
    """Return display flags that change same-mesh cache topology/content."""
    return (
        bool(getattr(prefs, 'show_uv_same_mesh_selection_overlay', True)),
        bool(getattr(prefs, 'show_uv_same_mesh_selection_verts', True)),
        bool(getattr(prefs, 'show_uv_same_mesh_selection_edges', True)),
    )


def _uv_cache_light_signature(context, region, prefs):
    """Cheap multi-object signature that does not touch BMesh."""
    if not _uv_may_read_edit_bmesh(context):
        return None
    try:
        objects = _uv_edit_mesh_objects(context, include_data_fallback=False, include_view_layer_scan=True)
        if not objects:
            return None
        obj_sigs = []
        for obj in objects:
            obj_key, data_key, name = _uv_object_identity(obj)
            obj_sigs.append((obj_key, data_key, name))
        try:
            reg_ptr = int(region.as_pointer())
        except Exception:
            reg_ptr = 0
        view_sig = _uv_view2d_signature(region)
        if view_sig is None:
            return None
        is_sync, check_v, check_e, check_f, mode_key = _uv_select_flags_from_context(context, prefs)
        return (
            tuple(obj_sigs), reg_ptr, view_sig,
            bool(is_sync), bool(check_v), bool(check_e), bool(check_f), mode_key,
            *_uv_same_mesh_cache_flags(prefs),
            round(float(getattr(prefs, 'vertex_size', 4.0) or 4.0), 3),
            round(float(getattr(prefs, 'edge_size', 2.0) or 2.0), 3),
        )
    except Exception:
        return None


def _uv_cache_base_signature(context, region, prefs, bm=None, uv_layer=None):
    try:
        objects = _uv_edit_mesh_objects(context, include_data_fallback=False, include_view_layer_scan=True)
        if not objects:
            return None
        if not _uv_can_read_edit_bmesh(context):
            return None
        is_sync, check_v, check_e, check_f, mode_key = _uv_select_flags_from_context(context, prefs)
        view_sig = _uv_view2d_signature(region)
        if view_sig is None:
            return None
        try:
            reg_ptr = int(region.as_pointer())
        except Exception:
            reg_ptr = 0
        obj_sigs = []
        for idx, obj in enumerate(objects):
            try:
                bm_i = bm if (idx == 0 and bm is not None and len(objects) == 1) else bmesh.from_edit_mesh(obj.data)
                uv_i = uv_layer if (idx == 0 and uv_layer is not None and len(objects) == 1) else bm_i.loops.layers.uv.active
                if uv_i is None:
                    continue
                try:
                    uv_name = str(getattr(uv_i, 'name', '') or '')
                except Exception:
                    uv_name = ''
                try:
                    counts = (len(bm_i.verts), len(bm_i.edges), len(bm_i.faces))
                except Exception:
                    counts = (0, 0, 0)
                obj_key, data_key, name = _uv_object_identity(obj)
                obj_sigs.append((obj_key, data_key, name, uv_name, counts))
            except Exception:
                continue
        if not obj_sigs:
            return None
        return (
            tuple(obj_sigs), reg_ptr, view_sig,
            bool(is_sync), bool(check_v), bool(check_e), bool(check_f), mode_key,
            *_uv_same_mesh_cache_flags(prefs),
            round(float(getattr(prefs, 'vertex_size', 4.0) or 4.0), 3),
            round(float(getattr(prefs, 'edge_size', 2.0) or 2.0), 3),
        )
    except Exception:
        return None


def _uv_loop_record(loop, uv_layer, is_sync, face_selected=False, obj_key=0, data_key=0, obj_name=""):
    try:
        luv = loop[uv_layer]
        nxt = loop.link_loop_next
        nuv = nxt[uv_layer]
        uv = (float(luv.uv.x), float(luv.uv.y))
        uv_next = (float(nuv.uv.x), float(nuv.uv.y))
        if is_sync:
            v_selected = bool(getattr(loop.vert, 'select', False))
            e_selected = bool(getattr(loop.edge, 'select', False))
        else:
            v_selected = _loop_uv_vert_selected(loop, uv_layer)
            e_selected = _loop_uv_edge_selected(loop, uv_layer)
        next_vert_index = int(nxt.vert.index)
        return {
            'uv': uv,
            'uv_next': uv_next,
            'obj_key': int(obj_key or 0),
            'data_key': int(data_key or 0),
            'obj_name': str(obj_name or ''),
            'vert_index': int(loop.vert.index),
            'next_vert_index': int(next_vert_index),
            'edge_index': int(loop.edge.index),
            'edge_vert_indices': (int(loop.edge.verts[0].index), int(loop.edge.verts[1].index)),
            'v_selected': bool(face_selected or v_selected),
            'e_selected': bool(face_selected or e_selected),
        }
    except Exception:
        return None


def _uv_patch_read_raw(bms, st):
    """Read the selection flags the cache depends on.

    Synchronised UV selection reads element flags (vertices / edges / faces, cheap
    and independent of the loop count).  Non-sync selection reads per-loop flags in
    the exact order of the build pass.  Returns a dict or None."""
    need_v = st['read_v']
    need_e = st['read_e']
    if st['is_sync']:
        face_mode = bool(st['face_mode'])
        return {
            'elem': True,
            'ev': [[v.select for v in bm.verts] for bm in bms] if need_v else None,
            'ee': [[e.select for e in bm.edges] for bm in bms] if need_e else None,
            'ef': [[f.select for f in bm.faces] for bm in bms] if face_mode else None,
            'hid': [[f.hide for f in bm.faces] for bm in bms],
        }
    rv = [] if need_v else None
    re_ = [] if need_e else None
    for bm in bms:
        faces = [f for f in bm.faces if not f.hide]
        if need_v:
            rv.extend([l.uv_select_vert for f in faces for l in f.loops])
        if need_e:
            re_.extend([l.uv_select_edge for f in faces for l in f.loops])
    return {'elem': False, 'rv': rv, 're': re_}


def _uv_patch_raw_matches_plan(st, raw, n_plan):
    if not raw.get('elem'):
        lst = raw['rv'] if raw['rv'] is not None else raw['re']
        return lst is not None and len(lst) == n_plan
    return True


def _uv_patch_build_maps(st):
    plan = st['plan']
    raw = st['raw']
    st['vloops'] = st['eloops'] = st['floops'] = None
    if not raw.get('elem'):
        return
    okidx = st['okidx']
    vl = {} if raw['ev'] is not None else None
    el = {} if raw['ee'] is not None else None
    fl = {} if raw['ef'] is not None else None
    for i, P in enumerate(plan):
        pv = P[2]
        if pv is None:
            continue
        oi = okidx[pv[0]]
        if vl is not None:
            vl.setdefault((oi, pv[1]), []).append(i)
        if el is not None and P[6] is not None:
            el.setdefault((oi, P[6][1]), []).append(i)
        if fl is not None:
            fl.setdefault((oi, P[10]), []).append(i)
    st['vloops'], st['eloops'], st['floops'] = vl, el, fl


def _uv_patch_flags(st, raw, i):
    """(face, vertex, edge) selection flags of loop i from a raw read."""
    if not raw.get('elem'):
        rv = raw['rv']
        re_ = raw['re']
        return False, bool(rv[i]) if rv is not None else False, bool(re_[i]) if re_ is not None else False
    P = st['plan'][i]
    pv = P[2]
    if pv is None:
        return False, False, False
    oi = st['okidx'][pv[0]]
    ef, ev, ee = raw['ef'], raw['ev'], raw['ee']
    fs = bool(ef[oi][P[10]]) if ef is not None else False
    vs = bool(ev[oi][pv[1]]) if ev is not None else False
    es = bool(ee[oi][P[6][1]]) if (ee is not None and P[6] is not None) else False
    return fs, vs, es


def _uv_patch_derive(st, fs, vs, es):
    v = bool(fs or (vs and st['read_v']))
    e = bool(fs or (es and st['read_e']))
    side = bool(st['side_en'] and ((st['same_sel_e'] and e) or (st['same_sel_f'] and fs)))
    return v, e, side


def _uv_patch_active_indices(st):
    raw = st['raw']
    if not raw.get('elem'):
        rv, re_ = raw['rv'], raw['re']
        lists = [x for x in (rv, re_) if x is not None]
        if not lists:
            return []
        if len(lists) == 1:
            return [i for i, a in enumerate(lists[0]) if a]
        return [i for i, (a, b) in enumerate(zip(*lists)) if a or b]
    out = set()
    for key, maps in (('ev', st['vloops']), ('ee', st['eloops']), ('ef', st['floops'])):
        lists = raw[key]
        if lists is None or maps is None:
            continue
        for oi, lst in enumerate(lists):
            for k, on in enumerate(lst):
                if on:
                    out.update(maps.get((oi, k), ()))
    return sorted(out)


def _uv_patch_selected_loop_count(st, kind):
    """Number of visible loops whose vertex ('v') or edge ('e') flag is set."""
    raw = st['raw']
    if not raw.get('elem'):
        lst = raw['rv'] if kind == 'v' else raw['re']
        return None if lst is None else int(sum(lst))
    lists = raw['ev'] if kind == 'v' else raw['ee']
    maps = st['vloops'] if kind == 'v' else st['eloops']
    if lists is None or maps is None:
        return None
    n = 0
    for oi, lst in enumerate(lists):
        for k, on in enumerate(lst):
            if on:
                n += len(maps.get((oi, k), ()))
    return int(n)


def _uv_patch_init_counts(st):
    plan = st['plan']
    raw = st['raw']
    cnt_p = {}
    cnt_v = {}
    cnt_ee = {}
    cnt_sm = {}
    cnt_sk = {}
    for i in _uv_patch_active_indices(st):
        fs, vs, es = _uv_patch_flags(st, raw, i)
        v, e, side = _uv_patch_derive(st, fs, vs, es)
        P = plan[i]
        if v and P[0] is not None:
            cnt_p[P[0]] = cnt_p.get(P[0], 0) + 1
            cnt_v[P[2]] = cnt_v.get(P[2], 0) + 1
        if P[6] is not None:
            if e and P[5] >= 0 and P[4] is not None:
                cnt_ee[P[4]] = cnt_ee.get(P[4], 0) + 1
            if side:
                cnt_sm[P[6]] = cnt_sm.get(P[6], 0) + 1
                if P[4] is not None:
                    cnt_sk[P[4]] = cnt_sk.get(P[4], 0) + 1
    st['cnt_p'] = cnt_p
    st['cnt_v'] = cnt_v
    st['cnt_ee'] = cnt_ee
    st['cnt_sm'] = cnt_sm
    st['cnt_sk'] = cnt_sk


def _uv_patch_changed_loops(st, old, new):
    """Sorted loop indices whose raw flags differ, or None when the layout changed."""
    if not new.get('elem'):
        diff = set()
        for a, b in ((old['rv'], new['rv']), (old['re'], new['re'])):
            if a is not None and b is not None:
                if len(a) != len(b):
                    return None
                if a != b:
                    diff.update([i for i, (x, y) in enumerate(zip(a, b)) if x != y])
        return sorted(diff)
    if old['hid'] != new['hid']:
        return None
    diff = set()
    for key, maps in (('ev', st['vloops']), ('ee', st['eloops']), ('ef', st['floops'])):
        a_l, b_l = old[key], new[key]
        if a_l is None or b_l is None or maps is None:
            continue
        for oi, (a, b) in enumerate(zip(a_l, b_l)):
            if len(a) != len(b):
                return None
            if a != b:
                for k, (x, y) in enumerate(zip(a, b)):
                    if x != y:
                        diff.update(maps.get((oi, k), ()))
    return sorted(diff)


def _uv_hover_cache_try_patch(context, region, prefs):
    """Selection-only change: update the selection layer of the last hover cache.

    The expensive part of _build_uv_hover_cache is the per-loop geometry index
    (UV coordinates, screen positions, grids).  A click or box select changes only
    which elements are selected.  When nothing but the selection changed (same
    objects / counts / view / options, no geometry or transform update since the
    cache was built, same hidden faces), the previous cache is reused and only the
    loops whose selection flipped are patched, giving exactly the cache a full
    rebuild would produce (vertex, edge and face selection; non-sync face
    selection is rebuilt in full).  Returns the new cache or None (-> full rebuild).
    """
    st = getattr(_state, 'uv_hover_patch', None)
    if not isinstance(st, dict):
        return None
    sel_epoch_now = _uv_sel_epoch
    try:
        if st['geom_epoch'] != _uv_geom_epoch:
            _state.uv_hover_patch = None
            return None
        base = getattr(_state, 'uv_hover_cache', None)
        if not isinstance(base, dict):
            base = getattr(_state, 'uv_hover_stale_cache', None)
        if not isinstance(base, dict) or base is not st['cache']:
            return None
        sig_now = _uv_cache_base_signature(context, region, prefs)
        if sig_now is None or sig_now != base.get('sig') or sig_now != st['sig']:
            return None
        objects = _uv_edit_mesh_objects(context, include_data_fallback=False, include_view_layer_scan=True)
        if not objects:
            return None
        bms = []
        keys = []
        for obj in objects:
            obj_key, _data_key, _obj_name = _uv_object_identity(obj)
            bm = bmesh.from_edit_mesh(obj.data)
            if bm.loops.layers.uv.active is None:
                continue
            bms.append(bm)
            keys.append(int(obj_key))
        if tuple(keys) != st['obj_keys']:
            return None
        oraw = st['raw']
        nraw = _uv_patch_read_raw(bms, st)
        if nraw is None or bool(nraw.get('elem')) != bool(oraw.get('elem')):
            _state.uv_hover_patch = None
            return None
        if not nraw.get('elem') and not _uv_patch_raw_matches_plan(st, nraw, len(st['plan'])):
            _state.uv_hover_patch = None
            return None
        changed = _uv_patch_changed_loops(st, oraw, nraw)
        if changed is None:
            _state.uv_hover_patch = None
            return None
    except Exception:
        return None
    try:
        now = time.time()
        if not changed:
            new = base
        else:
            plan = st['plan']
            cnt_p = st['cnt_p']
            cnt_v = st['cnt_v']
            cnt_ee = st['cnt_ee']
            cnt_sm = st['cnt_sm']
            cnt_sk = st['cnt_sk']
            vmap_lists = st['vmap_lists']
            emap_lists = st['emap_lists']
            gate_sv = st['gate_sv']
            pe = list(base['point_entries'])
            ee = list(base['edge_entries'])
            vmap = dict(base['same_mesh_vert_map'])
            emap = dict(base['same_mesh_edge_map'])
            sel_verts = set(base['selected_mesh_verts'])
            sel_pts = set(base['selected_uv_point_keys'])
            sel_edges = set(base['selected_mesh_edges'])
            sel_ekeys = set(base['selected_uv_edge_keys'])
            records = base['records']
            records_new = None
            dirty_vk = set()
            dirty_ek = set()
            dirty_pid = {}
            dirty_eid = {}
            dirty_rec = {}
            for i in changed:
                P = plan[i]
                ofs, ovs, oes = _uv_patch_flags(st, oraw, i)
                nfs, nvs, nes = _uv_patch_flags(st, nraw, i)
                ov, oe, os_ = _uv_patch_derive(st, ofs, ovs, oes)
                nv, ne, ns = _uv_patch_derive(st, nfs, nvs, nes)
                if ov != nv and P[0] is not None:
                    d = 1 if nv else -1
                    pkey = P[0]
                    vkey = P[2]
                    cp = cnt_p.get(pkey, 0) + d
                    cnt_p[pkey] = cp
                    cv = cnt_v.get(vkey, 0) + d
                    cnt_v[vkey] = cv
                    if P[1] >= 0:
                        dirty_pid[P[1]] = pkey
                    if gate_sv:
                        if cp > 0:
                            sel_pts.add(pkey)
                        else:
                            sel_pts.discard(pkey)
                        if cv > 0:
                            sel_verts.add(vkey)
                        else:
                            sel_verts.discard(vkey)
                    if P[3] >= 0:
                        lst = vmap_lists[vkey]
                        uv_cur, vi, _o = lst[P[3]]
                        lst[P[3]] = (uv_cur, vi, nv)
                        dirty_vk.add(vkey)
                if P[6] is not None:
                    mkey = P[6]
                    if oe != ne:
                        d = 1 if ne else -1
                        if P[7] >= 0:
                            lst = emap_lists[mkey]
                            a0, a1, a2, _o = lst[P[7]]
                            lst[P[7]] = (a0, a1, a2, ne)
                            dirty_ek.add(mkey)
                        if P[5] >= 0 and P[4] is not None:
                            cnt_ee[P[4]] = cnt_ee.get(P[4], 0) + d
                            dirty_eid[P[5]] = P[4]
                    if os_ != ns:
                        d = 1 if ns else -1
                        cm = cnt_sm.get(mkey, 0) + d
                        cnt_sm[mkey] = cm
                        if cm > 0:
                            sel_edges.add(mkey)
                        else:
                            sel_edges.discard(mkey)
                        if P[4] is not None:
                            ck = cnt_sk.get(P[4], 0) + d
                            cnt_sk[P[4]] = ck
                            if ck > 0:
                                sel_ekeys.add(P[4])
                            else:
                                sel_ekeys.discard(P[4])
                if P[8] >= 0:
                    dirty_rec.setdefault(P[8], {})[P[9]] = (nv, ne, nfs)
            for vk in dirty_vk:
                vmap[vk] = tuple(vmap_lists[vk])
            for mk in dirty_ek:
                emap[mk] = tuple(emap_lists[mk])
            for pid, pkey in dirty_pid.items():
                entry = dict(pe[pid])
                entry['v_selected'] = bool(cnt_p.get(pkey, 0) > 0)
                pe[pid] = entry
            for eid, ekey in dirty_eid.items():
                entry = dict(ee[eid])
                entry['e_selected'] = bool(cnt_ee.get(ekey, 0) > 0)
                ee[eid] = entry
            if dirty_rec:
                records_new = list(records)
                for ri, lis in dirty_rec.items():
                    rec = dict(records_new[ri])
                    loops_t = list(rec['loops'])
                    nf_val = rec['face_selected']
                    for li, (rv_, re2, nf2) in lis.items():
                        ld = dict(loops_t[li])
                        ld['v_selected'] = bool(rv_)
                        ld['e_selected'] = bool(re2)
                        loops_t[li] = ld
                        nf_val = bool(nf2)
                    rec['loops'] = tuple(loops_t)
                    rec['face_selected'] = nf_val
                    records_new[ri] = rec
            new = dict(base)
            new['point_entries'] = tuple(pe)
            new['edge_entries'] = tuple(ee)
            new['same_mesh_vert_map'] = vmap
            new['same_mesh_edge_map'] = emap
            new['selected_mesh_verts'] = sel_verts
            new['selected_uv_point_keys'] = sel_pts
            new['selected_mesh_edges'] = sel_edges
            new['selected_uv_edge_keys'] = sel_ekeys
            if records_new is not None:
                new['records'] = records_new
            new['created'] = now
        st['cache'] = new
        st['raw'] = nraw
        st['sel_epoch'] = sel_epoch_now
        _state.uv_hover_cache = new
        _state.uv_hover_cache_sig = new['sig']
        _state.uv_hover_cache_time = new['created'] if new is not base else now
        if new is base:
            base['created'] = now
        try:
            _state.last_bmesh_read_time = time.time()
        except Exception:
            pass
        return new
    except Exception:
        _state.uv_hover_patch = None
        return None


def _build_uv_hover_cache(context, region, prefs):
    if not _uv_may_read_edit_bmesh(context):
        return None
    patched = _uv_hover_cache_try_patch(context, region, prefs)
    if patched is not None:
        return patched
    _geom_epoch_at_start = _uv_geom_epoch
    _sel_epoch_at_start = _uv_sel_epoch
    try:
        # Build the UV hover cache in one BMesh pass.  Older 1.2.178 code first
        # calculated a full base signature, then walked the same edit meshes again
        # to build records.  On dense multi-object UV layouts that doubled the most
        # expensive work.  The signature and records are now produced from the same
        # object_info list so the visible behavior is unchanged while rebuilds are
        # noticeably lighter.
        objects = _uv_edit_mesh_objects(context, include_data_fallback=False, include_view_layer_scan=True)
        if not objects:
            return None
        if not _uv_may_read_edit_bmesh(context):
            return None
        is_sync, check_v, check_e, check_f, _mode_key = _uv_select_flags_from_context(context, prefs)
        same_is_sync, same_sel_v, same_sel_e, same_sel_f, same_mode_key = _uv_same_mesh_selection_mode(context)
        view_sig = _uv_view2d_signature(region)
        if view_sig is None:
            return None
        try:
            reg_ptr = int(region.as_pointer())
        except Exception:
            reg_ptr = 0
        # Same-mesh UV helper selection must follow the actual UV Editor select
        # mode, not the hover visibility toggles.  Most importantly, UV Edge mode
        # must not treat the edge endpoint UV vertices as independent vertex
        # selections; otherwise a normal edge click looks like loop selection and
        # a loop selection looks like ring-direction selection.
        face_selection_mode = bool(same_sel_f)
        v2d = getattr(region, 'view2d', None)
        if v2d is None:
            return None
        width = int(getattr(region, 'width', 0) or 0)
        height = int(getattr(region, 'height', 0) or 0)
        cell = float(_UV_HOVER_GRID_CELL_PX)
        pad = 18.0
        records = []
        grid = {}
        point_entries = []
        edge_entries = []
        point_grid = {}
        edge_grid = {}
        point_uv_index = {}
        edge_uv_index = {}
        face_uv_index = {}
        same_mesh_vert_map = {}
        same_mesh_edge_map = {}
        selected_mesh_verts = set()
        selected_mesh_edges = set()
        selected_uv_point_keys = set()
        selected_uv_edge_keys = set()
        same_loop_records = []  # compatibility placeholder; maps replace the old per-frame scan
        object_count = 0
        skipped_objects = []
        object_record_counts = {}
        object_infos = []
        obj_sigs = []
        light_obj_sigs = []
        # Build compact point/edge spatial indexes in the same face pass.  The
        # 1.2.185 face-grid-only path removed these indexes to reduce rebuild cost,
        # but dense UV layouts then had to rescan every nearby face on every mouse
        # sample and could fail to refresh hover after cache invalidation.  Use
        # per-object/per-UV/per-mesh-element keys so each visible UV point/edge is
        # inserted once, preserving the existing hover result while making queries
        # stable and cheap.
        build_fine_hover_index = True
        point_entry_by_key = {}
        edge_entry_by_key = {}
        same_enabled = bool(getattr(prefs, 'show_uv_same_mesh_selection_overlay', True))
        same_show_v = bool(getattr(prefs, 'show_uv_same_mesh_selection_verts', True))
        same_show_e = bool(getattr(prefs, 'show_uv_same_mesh_selection_edges', True))
        need_point_index = bool(check_v)
        need_edge_index = bool(check_e)
        need_face_records = bool(check_f)
        need_same_vert_map = bool(same_enabled and same_show_v and (same_sel_v or check_v))
        need_same_edge_map = bool(same_enabled and same_show_e and (same_sel_e or same_sel_f or check_e or check_f))
        # 選択だけの変更を差分で直せるのは、面の記録が要らず、辺側を見ず、面選択でない頂点モードだけ。
        _need_edge_side_any = bool(need_edge_index or need_same_edge_map or (same_enabled and (same_sel_e or same_sel_f)))
        _need_v_sel_any = bool(same_sel_v or need_same_vert_map or need_point_index)
        # 差分更新の対象：同期モードなら全モード、非同期なら頂点・辺（面選択と面記録は全再構築）。
        patch_ok = bool(is_sync or not (face_selection_mode or need_face_records))
        patch_plan = []
        patch_invalid = False
        _read_v_a = bool(same_sel_v or need_same_vert_map or need_point_index)
        _read_e_a = bool(same_sel_e or need_same_edge_map or need_edge_index)

        for obj in objects:
            try:
                obj_key, data_key, obj_name = _uv_object_identity(obj)
                bm = bmesh.from_edit_mesh(obj.data)
                try:
                    _state.last_bmesh_read_time = time.time()
                except Exception:
                    pass
                uv_layer = bm.loops.layers.uv.active
                if uv_layer is None:
                    skipped_objects.append(obj_name)
                    continue
                try:
                    uv_name = str(getattr(uv_layer, 'name', '') or '')
                except Exception:
                    uv_name = ''
                try:
                    counts = (len(bm.verts), len(bm.edges), len(bm.faces))
                except Exception:
                    counts = (0, 0, 0)
                obj_sigs.append((int(obj_key), int(data_key), str(obj_name or ''), uv_name, counts))
                light_obj_sigs.append((int(obj_key), int(data_key), str(obj_name or '')))
                object_infos.append((obj, bm, uv_layer, int(obj_key), int(data_key), str(obj_name or '')))
            except Exception:
                try:
                    skipped_objects.append(str(getattr(obj, 'name', '') or '<object>'))
                except Exception:
                    pass
                continue
        if not object_infos:
            return None

        size_v = round(float(getattr(prefs, 'vertex_size', 4.0) or 4.0), 3)
        size_e = round(float(getattr(prefs, 'edge_size', 2.0) or 2.0), 3)
        sig = (
            tuple(obj_sigs), reg_ptr, view_sig,
            bool(is_sync), bool(check_v), bool(check_e), bool(check_f), _mode_key,
            *_uv_same_mesh_cache_flags(prefs),
            size_v, size_e,
        )
        light_sig = (
            tuple(light_obj_sigs), reg_ptr, view_sig,
            bool(is_sync), bool(check_v), bool(check_e), bool(check_f), _mode_key,
            *_uv_same_mesh_cache_flags(prefs),
            size_v, size_e,
        )

        uv_xform = _uv_region_affine_transform(region)
        for _obj, bm, uv_layer, obj_key, data_key, obj_name in object_infos:
            try:
                try:
                    bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
                except Exception:
                    pass
                object_count += 1
                object_record_counts.setdefault(str(obj_name or ''), 0)
                for face in bm.faces:
                    try:
                        if face.hide:
                            continue
                    except Exception:
                        continue
                    loops = list(face.loops)
                    if len(loops) < 1:
                        continue
                    try:
                        if is_sync:
                            face_selected = bool(face_selection_mode and face.select)
                        else:
                            face_selected = bool(face_selection_mode and _face_uv_selected(face, loops, uv_layer))
                    except Exception:
                        face_selected = False
                    if not need_face_records:
                        # Vertex/Edge UV hover does not need per-face polygons. Build
                        # only the point/edge indexes and same-mesh maps required by
                        # the active UV mode. This keeps the visible result but avoids
                        # the heavy generic loop-record path for dense UV maps.
                        for loop in loops:
                            _P = None
                            if patch_ok:
                                _P = [None, -1, None, -1, None, -1, None, -1, -1, -1, int(face.index)]
                                patch_plan.append(_P)
                            try:
                                luv = loop[uv_layer]
                                uv_cur = (float(luv.uv.x), float(luv.uv.y))
                                obj_key_i = int(obj_key)
                                vi = int(loop.vert.index)
                                ru = round(uv_cur[0], 6); rv = round(uv_cur[1], 6)
                                p_key_fast = (obj_key_i, vi, ru, rv)

                                need_v_selected = bool(same_sel_v or need_same_vert_map or need_point_index)
                                if face_selected:
                                    v_selected_eff = True
                                elif need_v_selected:
                                    if is_sync:
                                        v_selected_eff = bool(getattr(loop.vert, 'select', False))
                                    else:
                                        v_selected_eff = bool(_loop_uv_vert_selected(loop, uv_layer))
                                else:
                                    v_selected_eff = False

                                _vpos = -1
                                if need_same_vert_map:
                                    _vlist = same_mesh_vert_map.setdefault((obj_key_i, vi), [])
                                    _vpos = len(_vlist)
                                    _vlist.append((uv_cur, vi, bool(v_selected_eff)))
                                if _P is not None:
                                    _P[0] = p_key_fast
                                    _P[2] = (obj_key_i, vi)
                                    _P[3] = _vpos
                                if same_enabled:
                                    if (not face_selected) and same_sel_v and v_selected_eff:
                                        selected_mesh_verts.add((obj_key_i, vi))
                                        selected_uv_point_keys.add(p_key_fast)
                                    if face_selected and same_sel_v:
                                        selected_mesh_verts.add((obj_key_i, vi))
                                        selected_uv_point_keys.add(p_key_fast)

                                p_cur = None
                                if need_point_index:
                                    p_cur = _uv_to_region_px_fast(region, uv_xform, uv_cur[0], uv_cur[1])
                                    try:
                                        px0 = float(p_cur[0]); py0 = float(p_cur[1])
                                        if (not math.isfinite(px0)) or (not math.isfinite(py0)) or abs(px0) >= _UV_INVALID_REGION_COORD_LIMIT or abs(py0) >= _UV_INVALID_REGION_COORD_LIMIT:
                                            continue
                                    except Exception:
                                        continue
                                    p_cur = (px0, py0)
                                    p_key = p_key_fast
                                    point_id = point_entry_by_key.get(p_key)
                                    if point_id is None:
                                        point_id = len(point_entries)
                                        point_entry_by_key[p_key] = point_id
                                        point_entries.append({
                                            'obj_key': obj_key_i, 'obj_name': str(obj_name or ''),
                                            'uv': uv_cur, 'px': p_cur, 'vert_index': vi,
                                            'v_selected': bool(v_selected_eff), 'point_key': p_key,
                                        })
                                        _uv_grid_add_point_fast(point_grid, point_id, px0, py0, cell, width, height, 15.0)
                                        point_uv_index.setdefault((ru, rv), []).append(point_id)
                                    elif bool(v_selected_eff):
                                        try:
                                            point_entries[int(point_id)]['v_selected'] = True
                                        except Exception:
                                            pass
                                    if _P is not None:
                                        _P[1] = int(point_id)

                                need_edge_side = bool(need_edge_index or need_same_edge_map or (same_enabled and (same_sel_e or same_sel_f)))
                                if need_edge_side:
                                    nxt = loop.link_loop_next
                                    nuv = nxt[uv_layer]
                                    uv_next = (float(nuv.uv.x), float(nuv.uv.y))
                                    ei = int(loop.edge.index)
                                    if _P is not None:
                                        _P[6] = (obj_key_i, ei)
                                        _P[4] = _uv_overlay_edge_key(ei, uv_cur, uv_next, obj_key_i)
                                    if face_selected:
                                        e_selected_eff = True
                                    elif same_sel_e or need_same_edge_map or need_edge_index:
                                        if is_sync:
                                            e_selected_eff = bool(getattr(loop.edge, 'select', False))
                                        else:
                                            e_selected_eff = bool(_loop_uv_edge_selected(loop, uv_layer))
                                    else:
                                        e_selected_eff = False

                                    if need_same_edge_map:
                                        _elist = same_mesh_edge_map.setdefault((obj_key_i, ei), [])
                                        if _P is not None:
                                            _P[7] = len(_elist)
                                        _elist.append((uv_cur, uv_next, ei, bool(e_selected_eff)))
                                    if same_enabled:
                                        edge_side_selected = bool((same_sel_e and e_selected_eff) or (same_sel_f and face_selected))
                                        if edge_side_selected:
                                            selected_mesh_edges.add((obj_key_i, ei))
                                            edge_key = _uv_overlay_edge_key(ei, uv_cur, uv_next, obj_key_i)
                                            if edge_key is not None:
                                                selected_uv_edge_keys.add(edge_key)
                                    if need_edge_index:
                                        if p_cur is None:
                                            p_cur = _uv_to_region_px_fast(region, uv_xform, uv_cur[0], uv_cur[1])
                                            if not _uv_region_point_is_valid(p_cur):
                                                patch_invalid = True
                                                continue
                                            p_cur = (float(p_cur[0]), float(p_cur[1]))
                                        p_next = _uv_to_region_px_fast(region, uv_xform, uv_next[0], uv_next[1])
                                        if not _uv_region_point_is_valid(p_next):
                                            patch_invalid = True
                                            continue
                                        p_next = (float(p_next[0]), float(p_next[1]))
                                        e_key = _uv_overlay_edge_key(ei, uv_cur, uv_next, obj_key_i)
                                        if e_key is not None:
                                            edge_id = edge_entry_by_key.get(e_key)
                                            if edge_id is None:
                                                edge_id = len(edge_entries)
                                                edge_entry_by_key[e_key] = edge_id
                                                ex0 = min(float(p_cur[0]), float(p_next[0])); ex1 = max(float(p_cur[0]), float(p_next[0]))
                                                ey0 = min(float(p_cur[1]), float(p_next[1])); ey1 = max(float(p_cur[1]), float(p_next[1]))
                                                edge_entries.append({
                                                    'obj_key': obj_key_i, 'obj_name': str(obj_name or ''),
                                                    'uv': uv_cur, 'uv_next': uv_next, 'p1': p_cur, 'p2': p_next,
                                                    'edge_index': ei, 'edge_vert_indices': (int(loop.edge.verts[0].index), int(loop.edge.verts[1].index)),
                                                    'e_selected': bool(e_selected_eff), 'edge_key': e_key,
                                                })
                                                _uv_grid_add_bbox(edge_grid, edge_id, ex0, ey0, ex1, ey1, cell, width, height, 15.0)
                                                seg_key = _uv_segment_coord_key(uv_cur, uv_next)
                                                if seg_key is not None:
                                                    edge_uv_index.setdefault(seg_key, []).append(edge_id)
                                            elif bool(e_selected_eff):
                                                try:
                                                    edge_entries[int(edge_id)]['e_selected'] = True
                                                except Exception:
                                                    pass
                                            if _P is not None:
                                                _P[5] = int(edge_id)
                            except Exception:
                                patch_invalid = True
                                continue
                        object_record_counts[str(obj_name or '')] = int(object_record_counts.get(str(obj_name or ''), 0) or 0) + 1
                        continue

                    f_uvs = []
                    f_pxs = []
                    loop_records = []
                    valid = True
                    for loop in loops:
                        rec = _uv_loop_record(loop, uv_layer, is_sync, face_selected=face_selected, obj_key=obj_key, data_key=data_key, obj_name=obj_name)
                        if rec is None:
                            valid = False
                            patch_invalid = True
                            break
                        px = _uv_to_region_px_fast(region, uv_xform, rec['uv'][0], rec['uv'][1])
                        if not _uv_region_point_is_valid(px):
                            valid = False
                            patch_invalid = True
                            break
                        p = (float(px[0]), float(px[1]))
                        rec['px'] = p
                        f_uvs.append(rec['uv'])
                        f_pxs.append(p)
                        loop_records.append(rec)
                        cur_point_key = None
                        next_point_key = None
                        edge_key = None
                        if (not face_selected) and same_sel_v and rec['v_selected']:
                            selected_mesh_verts.add((int(obj_key), int(rec['vert_index'])))
                            cur_point_key = _uv_overlay_point_key(rec.get('uv'), rec.get('vert_index'), obj_key)
                            if cur_point_key is not None:
                                selected_uv_point_keys.add(cur_point_key)
                        edge_side_selected = bool((same_sel_e and rec['e_selected']) or (same_sel_f and face_selected))
                        if edge_side_selected:
                            selected_mesh_edges.add((int(obj_key), int(rec['edge_index'])))
                            edge_key = _uv_overlay_edge_key(rec.get('edge_index'), rec.get('uv'), rec.get('uv_next'), obj_key)
                            if edge_key is not None:
                                selected_uv_edge_keys.add(edge_key)
                        if face_selected and same_sel_v:
                            selected_mesh_verts.add((int(obj_key), int(rec['vert_index'])))
                            cur_point_key = _uv_overlay_point_key(rec.get('uv'), rec.get('vert_index'), obj_key)
                            if cur_point_key is not None:
                                selected_uv_point_keys.add(cur_point_key)
                        # same_loop_records used to duplicate every loop for a fallback scan.
                        # same_mesh_*_map now covers the same behavior without a draw-time scan.
                    if (not valid) or len(f_pxs) < 1:
                        continue
                    min_x = min(p[0] for p in f_pxs)
                    max_x = max(p[0] for p in f_pxs)
                    min_y = min(p[1] for p in f_pxs)
                    max_y = max(p[1] for p in f_pxs)
                    face_vert_indices = []
                    face_edge_indices = []
                    try:
                        face_vert_indices = [int(v.index) for v in face.verts]
                        face_edge_indices = [int(e.index) for e in face.edges]
                    except Exception:
                        pass
                    idx = len(records)
                    records.append({
                        'obj_key': int(obj_key),
                        'data_key': int(data_key),
                        'obj_name': str(obj_name or ''),
                        'face_index': int(face.index),
                        'f_uvs': tuple(f_uvs),
                        'f_pxs': tuple(f_pxs),
                        'bbox': (min_x, min_y, max_x, max_y),
                        'loops': tuple(loop_records),
                        'face_selected': bool(face_selected),
                        'face_vert_indices': tuple(face_vert_indices),
                        'face_edge_indices': tuple(face_edge_indices),
                    })
                    face_key = _uv_polygon_key(f_uvs)
                    if face_key is not None:
                        face_uv_index.setdefault(face_key, []).append(idx)
                    for li, rec_i in enumerate(loop_records):
                        try:
                            p_cur = f_pxs[li]
                            p_next = f_pxs[(li + 1) % len(f_pxs)]
                            uv_cur = rec_i.get('uv')
                            uv_next = rec_i.get('uv_next')
                            obj_key_i = int(rec_i.get('obj_key', obj_key) or 0)
                            vi = int(rec_i.get('vert_index'))
                            ei = int(rec_i.get('edge_index'))
                            _P = None
                            if patch_ok:
                                _P = [_uv_overlay_point_key(uv_cur, vi, obj_key_i), -1, (obj_key_i, vi), -1,
                                      _uv_overlay_edge_key(ei, uv_cur, uv_next, obj_key_i), -1, (obj_key_i, ei), -1, idx, li, int(face.index)]
                                patch_plan.append(_P)
                            _vlist = same_mesh_vert_map.setdefault((obj_key_i, vi), [])
                            _elist = same_mesh_edge_map.setdefault((obj_key_i, ei), [])
                            if _P is not None:
                                _P[3] = len(_vlist)
                                _P[7] = len(_elist)
                            _vlist.append((uv_cur, vi, bool(rec_i.get('v_selected'))))
                            _elist.append((uv_cur, uv_next, ei, bool(rec_i.get('e_selected'))))
                            if build_fine_hover_index and need_point_index:
                                p_key = _uv_overlay_point_key(uv_cur, vi, obj_key_i)
                                if p_key is not None:
                                    point_id = point_entry_by_key.get(p_key)
                                    if point_id is None:
                                        point_id = len(point_entries)
                                        point_entry_by_key[p_key] = point_id
                                        point_entries.append({
                                            'obj_key': obj_key_i, 'obj_name': str(rec_i.get('obj_name', obj_name) or ''),
                                            'uv': uv_cur, 'px': p_cur, 'vert_index': vi,
                                            'v_selected': bool(rec_i.get('v_selected')), 'point_key': p_key,
                                        })
                                        _uv_grid_add_bbox(point_grid, point_id, p_cur[0], p_cur[1], p_cur[0], p_cur[1], cell, width, height, 15.0)
                                        coord_key = _uv_coord_key(uv_cur)
                                        if coord_key is not None:
                                            point_uv_index.setdefault(coord_key, []).append(point_id)
                                    else:
                                        try:
                                            if bool(rec_i.get('v_selected')):
                                                point_entries[int(point_id)]['v_selected'] = True
                                        except Exception:
                                            pass
                                    if _P is not None:
                                        _P[1] = int(point_id)
                            if build_fine_hover_index and need_edge_index:
                                e_key = _uv_overlay_edge_key(ei, uv_cur, uv_next, obj_key_i)
                                if e_key is not None:
                                    edge_id = edge_entry_by_key.get(e_key)
                                    if edge_id is None:
                                        edge_id = len(edge_entries)
                                        edge_entry_by_key[e_key] = edge_id
                                        ex0 = min(float(p_cur[0]), float(p_next[0])); ex1 = max(float(p_cur[0]), float(p_next[0]))
                                        ey0 = min(float(p_cur[1]), float(p_next[1])); ey1 = max(float(p_cur[1]), float(p_next[1]))
                                        edge_entries.append({
                                            'obj_key': obj_key_i, 'obj_name': str(rec_i.get('obj_name', obj_name) or ''),
                                            'uv': uv_cur, 'uv_next': uv_next, 'p1': p_cur, 'p2': p_next,
                                            'edge_index': ei, 'edge_vert_indices': tuple(rec_i.get('edge_vert_indices') or ()),
                                            'e_selected': bool(rec_i.get('e_selected')), 'edge_key': e_key,
                                        })
                                        _uv_grid_add_bbox(edge_grid, edge_id, ex0, ey0, ex1, ey1, cell, width, height, 15.0)
                                        seg_key = _uv_segment_coord_key(uv_cur, uv_next)
                                        if seg_key is not None:
                                            edge_uv_index.setdefault(seg_key, []).append(edge_id)
                                    else:
                                        try:
                                            if bool(rec_i.get('e_selected')):
                                                edge_entries[int(edge_id)]['e_selected'] = True
                                        except Exception:
                                            pass
                                    if _P is not None:
                                        _P[5] = int(edge_id)
                        except Exception:
                            patch_invalid = True
                            continue
                    object_record_counts[str(obj_name or '')] = int(object_record_counts.get(str(obj_name or ''), 0) or 0) + 1
                    if max_x < -pad or min_x > width + pad or max_y < -pad or min_y > height + pad:
                        continue
                    cx0 = int(math.floor(max(min_x - pad, -pad) / cell))
                    cx1 = int(math.floor(min(max_x + pad, width + pad) / cell))
                    cy0 = int(math.floor(max(min_y - pad, -pad) / cell))
                    cy1 = int(math.floor(min(max_y + pad, height + pad) / cell))
                    for cx in range(cx0, cx1 + 1):
                        for cy in range(cy0, cy1 + 1):
                            grid.setdefault((cx, cy), []).append(idx)
            except Exception:
                try:
                    skipped_objects.append(str(obj_name or '<object>'))
                except Exception:
                    pass
                continue
        if object_count <= 0:
            return None
        cache = {
            'sig': sig,
            'light_sig': light_sig,
            'records': records,
            'grid': grid,
            'point_entries': tuple(point_entries),
            'edge_entries': tuple(edge_entries),
            'point_grid': point_grid,
            'edge_grid': edge_grid,
            'point_uv_index': {k: tuple(v) for k, v in point_uv_index.items()},
            'edge_uv_index': {k: tuple(v) for k, v in edge_uv_index.items()},
            'face_uv_index': {k: tuple(v) for k, v in face_uv_index.items()},
            'same_mesh_vert_map': {k: tuple(v) for k, v in same_mesh_vert_map.items()},
            'same_mesh_edge_map': {k: tuple(v) for k, v in same_mesh_edge_map.items()},
            'cell': cell,
            'created': time.time(),
            'check_v': bool(check_v),
            'check_e': bool(check_e),
            'check_f': bool(check_f),
            'same_loop_records': (),
            'selected_mesh_verts': selected_mesh_verts,
            'selected_mesh_edges': selected_mesh_edges,
            'selected_uv_point_keys': selected_uv_point_keys,
            'selected_uv_edge_keys': selected_uv_edge_keys,
            'objects': tuple((int(obj_key), str(obj_name or '')) for _obj, _bm, _uv_layer, obj_key, _data_key, obj_name in object_infos),
            'object_count': int(object_count),
            'skipped_objects': tuple(skipped_objects),
            'object_record_counts': dict(object_record_counts),
        }
        _state.uv_hover_cache = cache
        _state.uv_hover_cache_sig = sig
        _state.uv_hover_cache_time = cache['created']
        _state.uv_hover_patch = None
        if patch_ok and (not patch_invalid) and patch_plan:
            try:
                _bms = [info[1] for info in object_infos]
                _read_v = True if need_face_records else _read_v_a
                _read_e = True if need_face_records else _read_e_a
                _st = {
                    'cache': cache, 'sig': sig, 'geom_epoch': _geom_epoch_at_start,
                    'sel_epoch': _sel_epoch_at_start,
                    'obj_keys': tuple(int(info[3]) for info in object_infos),
                    'is_sync': bool(is_sync), 'face_mode': bool(face_selection_mode),
                    'read_v': bool(_read_v), 'read_e': bool(_read_e),
                    'side_en': bool(True if need_face_records else same_enabled),
                    'gate_sv': bool(same_sel_v if need_face_records else (same_enabled and same_sel_v)),
                    'same_sel_e': bool(same_sel_e), 'same_sel_f': bool(same_sel_f),
                    'plan': patch_plan,
                    'vmap_lists': same_mesh_vert_map, 'emap_lists': same_mesh_edge_map,
                }
                _st['okidx'] = {int(info[3]): n for n, info in enumerate(object_infos)}
                _raw = _uv_patch_read_raw(_bms, _st)
                if _raw is not None and _uv_patch_raw_matches_plan(_st, _raw, len(patch_plan)):
                    _st['raw'] = _raw
                    _uv_patch_build_maps(_st)
                    _uv_patch_init_counts(_st)
                    _state.uv_hover_patch = _st
            except Exception:
                _state.uv_hover_patch = None
        return cache
    except Exception:
        return None



def _uv_cache_fast_tail(context, region, prefs):
    """Cheap cache tail: region/view/options only, without scanning edit objects."""
    try:
        try:
            reg_ptr = int(region.as_pointer())
        except Exception:
            reg_ptr = 0
        view_sig = _uv_view2d_signature(region)
        if view_sig is None:
            return None
        is_sync, check_v, check_e, check_f, mode_key = _uv_select_flags_from_context(context, prefs)
        return (
            reg_ptr, view_sig,
            bool(is_sync), bool(check_v), bool(check_e), bool(check_f), mode_key,
            *_uv_same_mesh_cache_flags(prefs),
            round(float(getattr(prefs, 'vertex_size', 4.0) or 4.0), 3),
            round(float(getattr(prefs, 'edge_size', 2.0) or 2.0), 3),
        )
    except Exception:
        return None


def _get_uv_hover_cache(context, region, prefs, *, force: bool = False):
    try:
        now = time.time()
        cache = getattr(_state, 'uv_hover_cache', None)
        fast_tail = _uv_cache_fast_tail(context, region, prefs)
        if not force and isinstance(cache, dict) and fast_tail is not None:
            cached_sig = tuple(cache.get('sig') or ())
            # sig = (object_info, reg_ptr, view_sig, select flags, same-mesh flags, sizes)
            if len(cached_sig) >= 10:
                cached_tail = tuple(cached_sig[1:])
                age = now - float(getattr(_state, 'uv_hover_cache_time', 0.0) or 0.0)
                if cached_tail == tuple(fast_tail) and age <= _UV_HOVER_CACHE_VALIDATE_SECONDS:
                    return cache
                # Region pointer or UV pan/zoom changed, but objects/options/selection-mode
                # are the same.  Reproject cached UV coordinates instead of reading BMesh.
                if tuple(cached_sig[3:]) == tuple(fast_tail[2:]):
                    reproject_sig = (cached_sig[0], fast_tail[0], fast_tail[1]) + tuple(fast_tail[2:])
                    if _uv_reproject_hover_cache_for_region(cache, region, reproject_sig):
                        return cache
        if not force and isinstance(cache, dict):
            # Slow validation path is needed only after the cheap tail failed, so
            # normal mouse movement does not repeatedly scan the view layer.
            light_sig = _uv_cache_light_signature(context, region, prefs)
            cached_light = cache.get('light_sig')
            if light_sig is not None and light_sig == cached_light:
                age = now - float(getattr(_state, 'uv_hover_cache_time', 0.0) or 0.0)
                if age <= _UV_HOVER_CACHE_VALIDATE_SECONDS:
                    return cache
                if not _uv_can_read_edit_bmesh(context):
                    return _get_compatible_stale_uv_hover_cache(context, region, prefs)
                sig_now = _uv_cache_base_signature(context, region, prefs)
                if sig_now is not None and sig_now == getattr(_state, 'uv_hover_cache_sig', None):
                    cache['light_sig'] = light_sig
                    _state.uv_hover_cache_time = now
                    cache['created'] = now
                    return cache
            elif (light_sig is not None and cached_light is not None and
                    _uv_cache_light_static_key(light_sig) == _uv_cache_light_static_key(cached_light)):
                if _uv_reproject_hover_cache_for_region(cache, region, light_sig):
                    return cache
        rebuilt = _build_uv_hover_cache(context, region, prefs)
        if rebuilt is not None:
            return rebuilt
        return _get_compatible_stale_uv_hover_cache(context, region, prefs)
    except Exception:
        try:
            return _get_compatible_stale_uv_hover_cache(context, region, prefs)
        except Exception:
            return None

def _uv_hover_candidate_ids(cache, rx, ry):
    try:
        cell = float(cache.get('cell') or _UV_HOVER_GRID_CELL_PX)
        cx = int(math.floor(float(rx) / cell))
        cy = int(math.floor(float(ry) / cell))
        candidate_ids = set()
        grid = cache.get('grid') or {}
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                candidate_ids.update(grid.get((cx + dx, cy + dy), ()) or ())
        records = cache.get('records') or ()
        if not candidate_ids and len(records) <= 4096:
            return tuple(range(len(records)))
        return tuple(candidate_ids)
    except Exception:
        return ()


def _uv_cache_light_static_key(sig):
    """Return the cache part that is independent from UV pan/zoom and region ptr."""
    try:
        seq = tuple(sig or ())
        if len(seq) < 4:
            return None
        return (seq[0],) + tuple(seq[3:])
    except Exception:
        return None


def _uv_reproject_hover_cache_for_region(cache, region, light_sig=None) -> bool:
    """Update cached UV records to the current UV Editor View2D without BMesh reads.

    Dense UV maps must not rebuild edit BMesh caches merely because the user pans
    or zooms the UV editor.  Records already contain UV coordinates and element
    identities, so only the screen-space grids need to be regenerated.
    """
    try:
        if not isinstance(cache, dict) or region is None:
            return False
        records = cache.get('records') or ()
        width = int(getattr(region, 'width', 0) or 0)
        height = int(getattr(region, 'height', 0) or 0)
        if width <= 0 or height <= 0:
            return False
        cell = float(cache.get('cell') or _UV_HOVER_GRID_CELL_PX)
        pad = 18.0
        grid = {}
        point_entries = []
        edge_entries = []
        point_grid = {}
        edge_grid = {}
        point_uv_index = {}
        edge_uv_index = {}
        face_uv_index = {}
        point_entry_by_key = {}
        edge_entry_by_key = {}
        need_point_index = bool(cache.get('check_v'))
        need_edge_index = bool(cache.get('check_e'))

        uv_xform = _uv_region_affine_transform(region)
        if not records:
            base_points = tuple(cache.get('point_entries') or ())
            base_edges = tuple(cache.get('edge_entries') or ())
            if not base_points and not base_edges:
                return False
            point_entries = []
            edge_entries = []
            for pid, ent0 in enumerate(base_points):
                try:
                    ent = dict(ent0)
                    uv_val = ent.get('uv')
                    px = _uv_to_region_px_fast(region, uv_xform, uv_val[0], uv_val[1])
                    if not _uv_region_point_is_valid(px):
                        continue
                    px = (float(px[0]), float(px[1]))
                    ent['px'] = px
                    new_id = len(point_entries)
                    point_entries.append(ent)
                    _uv_grid_add_bbox(point_grid, new_id, px[0], px[1], px[0], px[1], cell, width, height, 15.0)
                    coord_key = _uv_coord_key(uv_val)
                    if coord_key is not None:
                        point_uv_index.setdefault(coord_key, []).append(new_id)
                except Exception:
                    continue
            for eid, ent0 in enumerate(base_edges):
                try:
                    ent = dict(ent0)
                    uv_a = ent.get('uv')
                    uv_b = ent.get('uv_next')
                    p1 = _uv_to_region_px_fast(region, uv_xform, uv_a[0], uv_a[1])
                    p2 = _uv_to_region_px_fast(region, uv_xform, uv_b[0], uv_b[1])
                    if not (_uv_region_point_is_valid(p1) and _uv_region_point_is_valid(p2)):
                        continue
                    p1 = (float(p1[0]), float(p1[1])); p2 = (float(p2[0]), float(p2[1]))
                    ent['p1'] = p1; ent['p2'] = p2
                    new_id = len(edge_entries)
                    edge_entries.append(ent)
                    ex0 = min(float(p1[0]), float(p2[0])); ex1 = max(float(p1[0]), float(p2[0]))
                    ey0 = min(float(p1[1]), float(p2[1])); ey1 = max(float(p1[1]), float(p2[1]))
                    _uv_grid_add_bbox(edge_grid, new_id, ex0, ey0, ex1, ey1, cell, width, height, 15.0)
                    seg_key = _uv_segment_coord_key(uv_a, uv_b)
                    if seg_key is not None:
                        edge_uv_index.setdefault(seg_key, []).append(new_id)
                except Exception:
                    continue
            cache['grid'] = {}
            cache['point_entries'] = tuple(point_entries)
            cache['edge_entries'] = tuple(edge_entries)
            cache['point_grid'] = point_grid
            cache['edge_grid'] = edge_grid
            cache['point_uv_index'] = {k: tuple(v) for k, v in point_uv_index.items()}
            cache['edge_uv_index'] = {k: tuple(v) for k, v in edge_uv_index.items()}
            cache['face_uv_index'] = {}
            if light_sig is not None:
                cache['light_sig'] = light_sig
                try:
                    old_sig = tuple(cache.get('sig') or ())
                    if len(old_sig) >= 3 and len(tuple(light_sig)) >= 3:
                        cache['sig'] = (old_sig[0], tuple(light_sig)[1], tuple(light_sig)[2]) + tuple(old_sig[3:])
                        _state.uv_hover_cache_sig = cache['sig']
                except Exception:
                    pass
            cache['created'] = time.time()
            _state.uv_hover_cache_time = cache['created']
            return True

        for rec_index, rec in enumerate(records):
            try:
                f_uvs = tuple(rec.get('f_uvs') or ())
                loops = tuple(rec.get('loops') or ())
                if not f_uvs or not loops:
                    rec['f_pxs'] = tuple()
                    rec['bbox'] = (0.0, 0.0, 0.0, 0.0)
                    continue
                f_pxs = []
                valid = True
                for uv in f_uvs:
                    px = _uv_to_region_px_fast(region, uv_xform, uv[0], uv[1])
                    if not _uv_region_point_is_valid(px):
                        valid = False
                        break
                    f_pxs.append((float(px[0]), float(px[1])))
                if not valid or len(f_pxs) < 1:
                    rec['f_pxs'] = tuple()
                    rec['bbox'] = (0.0, 0.0, 0.0, 0.0)
                    continue
                min_x = min(p[0] for p in f_pxs); max_x = max(p[0] for p in f_pxs)
                min_y = min(p[1] for p in f_pxs); max_y = max(p[1] for p in f_pxs)
                rec['f_pxs'] = tuple(f_pxs)
                rec['bbox'] = (min_x, min_y, max_x, max_y)
                face_key = _uv_polygon_key(f_uvs)
                if face_key is not None:
                    face_uv_index.setdefault(face_key, []).append(int(rec_index))
                for li, rec_i in enumerate(loops):
                    try:
                        p_cur = f_pxs[li]
                        p_next = f_pxs[(li + 1) % len(f_pxs)]
                        rec_i['px'] = p_cur
                        uv_cur = rec_i.get('uv')
                        uv_next = rec_i.get('uv_next')
                        obj_key_i = int(rec_i.get('obj_key', rec.get('obj_key', 0)) or 0)
                        vi = int(rec_i.get('vert_index'))
                        ei = int(rec_i.get('edge_index'))
                        p_key = _uv_overlay_point_key(uv_cur, vi, obj_key_i) if need_point_index else None
                        if p_key is not None:
                            point_id = point_entry_by_key.get(p_key)
                            if point_id is None:
                                point_id = len(point_entries)
                                point_entry_by_key[p_key] = point_id
                                point_entries.append({
                                    'obj_key': obj_key_i,
                                    'obj_name': str(rec_i.get('obj_name', rec.get('obj_name', '')) or ''),
                                    'uv': uv_cur,
                                    'px': p_cur,
                                    'vert_index': vi,
                                    'v_selected': bool(rec_i.get('v_selected')),
                                    'point_key': p_key,
                                })
                                _uv_grid_add_bbox(point_grid, point_id, p_cur[0], p_cur[1], p_cur[0], p_cur[1], cell, width, height, 15.0)
                                coord_key = _uv_coord_key(uv_cur)
                                if coord_key is not None:
                                    point_uv_index.setdefault(coord_key, []).append(point_id)
                            elif bool(rec_i.get('v_selected')):
                                try:
                                    point_entries[int(point_id)]['v_selected'] = True
                                except Exception:
                                    pass
                        e_key = _uv_overlay_edge_key(ei, uv_cur, uv_next, obj_key_i) if need_edge_index else None
                        if e_key is not None:
                            edge_id = edge_entry_by_key.get(e_key)
                            if edge_id is None:
                                edge_id = len(edge_entries)
                                edge_entry_by_key[e_key] = edge_id
                                ex0 = min(float(p_cur[0]), float(p_next[0])); ex1 = max(float(p_cur[0]), float(p_next[0]))
                                ey0 = min(float(p_cur[1]), float(p_next[1])); ey1 = max(float(p_cur[1]), float(p_next[1]))
                                edge_entries.append({
                                    'obj_key': obj_key_i,
                                    'obj_name': str(rec_i.get('obj_name', rec.get('obj_name', '')) or ''),
                                    'uv': uv_cur,
                                    'uv_next': uv_next,
                                    'p1': p_cur,
                                    'p2': p_next,
                                    'edge_index': ei,
                                    'edge_vert_indices': tuple(rec_i.get('edge_vert_indices') or ()),
                                    'e_selected': bool(rec_i.get('e_selected')),
                                    'edge_key': e_key,
                                })
                                _uv_grid_add_bbox(edge_grid, edge_id, ex0, ey0, ex1, ey1, cell, width, height, 15.0)
                                seg_key = _uv_segment_coord_key(uv_cur, uv_next)
                                if seg_key is not None:
                                    edge_uv_index.setdefault(seg_key, []).append(edge_id)
                            else:
                                try:
                                    ent = edge_entries[int(edge_id)]
                                    ent['p1'] = ent.get('p1') or p_cur
                                    ent['p2'] = ent.get('p2') or p_next
                                    if bool(rec_i.get('e_selected')):
                                        ent['e_selected'] = True
                                except Exception:
                                    pass
                    except Exception:
                        continue
                if max_x < -pad or min_x > width + pad or max_y < -pad or min_y > height + pad:
                    continue
                _uv_grid_add_bbox(grid, int(rec_index), min_x, min_y, max_x, max_y, cell, width, height, pad)
            except Exception:
                continue

        cache['grid'] = grid
        cache['point_entries'] = tuple(point_entries)
        cache['edge_entries'] = tuple(edge_entries)
        cache['point_grid'] = point_grid
        cache['edge_grid'] = edge_grid
        cache['point_uv_index'] = {k: tuple(v) for k, v in point_uv_index.items()}
        cache['edge_uv_index'] = {k: tuple(v) for k, v in edge_uv_index.items()}
        cache['face_uv_index'] = {k: tuple(v) for k, v in face_uv_index.items()}
        if light_sig is not None:
            cache['light_sig'] = light_sig
            try:
                old_sig = tuple(cache.get('sig') or ())
                if len(old_sig) >= 3 and len(tuple(light_sig)) >= 3:
                    cache['sig'] = (old_sig[0], tuple(light_sig)[1], tuple(light_sig)[2]) + tuple(old_sig[3:])
                    _state.uv_hover_cache_sig = cache['sig']
            except Exception:
                pass
        cache['created'] = time.time()
        _state.uv_hover_cache_time = cache['created']
        return True
    except Exception:
        return False


def _query_uv_hover_cache_face_scan(cache, rx, ry):
    try:
        check_v = bool(cache.get('check_v'))
        check_e = bool(cache.get('check_e'))
        check_f = bool(cache.get('check_f'))
        if not (check_v or check_e or check_f):
            return None
        records = cache.get('records') or ()
        candidate_ids = _uv_hover_candidate_ids(cache, rx, ry)
        if not candidate_ids:
            return None
        best_type = 'NONE'
        best_uvs = []
        best_hover_vert_indices = []
        best_hover_edge_indices = []
        best_hover_face_indices = []
        best_obj_key = None
        best_obj_name = ''
        best_raw_type = 'NONE'
        best_raw_uvs = []
        best_raw_hover_vert_indices = []
        best_raw_hover_edge_indices = []
        best_raw_hover_face_indices = []
        best_raw_obj_key = None
        best_raw_obj_name = ''
        min_dist = 15.0
        min_dist_raw = 15.0
        min_dist_selected_edge = 15.0
        best_selected_edge = None
        for idx in candidate_ids:
            try:
                rec = records[int(idx)]
            except Exception:
                continue
            try:
                min_x, min_y, max_x, max_y = rec['bbox']
                if rx < min_x - 15.0 or rx > max_x + 15.0 or ry < min_y - 15.0 or ry > max_y + 15.0:
                    continue
            except Exception:
                pass
            rec_obj_key = rec.get('obj_key')
            rec_obj_name = str(rec.get('obj_name', '') or '')
            f_pxs = rec.get('f_pxs') or ()
            f_uvs = rec.get('f_uvs') or ()
            loops = rec.get('loops') or ()
            if len(f_pxs) < 1 or len(loops) < 1:
                continue
            if check_f and len(f_pxs) >= 3 and best_raw_type not in {'VERTEX', 'EDGE'}:
                if _point_in_polygon_2d(rx, ry, f_pxs):
                    best_raw_type = 'FACE'
                    best_raw_uvs = list(f_uvs)
                    best_raw_hover_vert_indices = list(rec.get('face_vert_indices') or ())
                    best_raw_hover_edge_indices = list(rec.get('face_edge_indices') or ())
                    best_raw_hover_face_indices = [int(rec.get('face_index', -1))]
                    best_raw_obj_key = rec_obj_key
                    best_raw_obj_name = rec_obj_name
            if check_f and len(f_pxs) >= 3 and best_type not in {'VERTEX', 'EDGE'}:
                if _point_in_polygon_2d(rx, ry, f_pxs):
                    best_type = 'FACE'
                    best_uvs = list(f_uvs)
                    best_hover_vert_indices = list(rec.get('face_vert_indices') or ())
                    best_hover_edge_indices = list(rec.get('face_edge_indices') or ())
                    best_hover_face_indices = [int(rec.get('face_index', -1))]
                    best_obj_key = rec_obj_key
                    best_obj_name = rec_obj_name
            if check_e:
                for i, loop_rec in enumerate(loops):
                    p1 = f_pxs[i]
                    p2 = f_pxs[(i + 1) % len(f_pxs)]
                    d = _dist_to_segment_2d(rx, ry, p1[0], p1[1], p2[0], p2[1])
                    loop_obj_key = loop_rec.get('obj_key', rec_obj_key)
                    loop_obj_name = str(loop_rec.get('obj_name', rec_obj_name) or rec_obj_name)
                    edge_selected = bool(loop_rec.get('e_selected'))
                    if d < min_dist_raw and best_raw_type != 'VERTEX':
                        min_dist_raw = d
                        best_raw_type = 'EDGE'
                        best_raw_uvs = [loop_rec.get('uv'), loop_rec.get('uv_next')]
                        best_raw_hover_vert_indices = list(loop_rec.get('edge_vert_indices') or ())
                        best_raw_hover_edge_indices = [int(loop_rec.get('edge_index'))]
                        best_raw_hover_face_indices = []
                        best_raw_obj_key = loop_obj_key
                        best_raw_obj_name = loop_obj_name
                    # UV Edge mode: selected edge sides have priority at shared
                    # vertices.  Otherwise a selected edge endpoint can be tied
                    # with adjacent loop/ring edges and the red hover overlay
                    # appears on edges that are not the selected side.
                    if edge_selected and d < min_dist_selected_edge and best_type != 'VERTEX':
                        min_dist_selected_edge = d
                        best_selected_edge = {
                            'hover_type': 'EDGE',
                            'hover_uvs': [loop_rec.get('uv'), loop_rec.get('uv_next')],
                            'hover_vert_indices': list(loop_rec.get('edge_vert_indices') or ()),
                            'hover_edge_indices': [int(loop_rec.get('edge_index'))],
                            'hover_face_indices': [],
                            'hover_obj_key': loop_obj_key,
                            'hover_obj_name': loop_obj_name,
                            'hover_selected': True,
                        }
                    if d < min_dist and best_type != 'VERTEX' and not edge_selected:
                        min_dist = d
                        best_type = 'EDGE'
                        best_uvs = [loop_rec.get('uv'), loop_rec.get('uv_next')]
                        best_hover_vert_indices = list(loop_rec.get('edge_vert_indices') or ())
                        best_hover_edge_indices = [int(loop_rec.get('edge_index'))]
                        best_hover_face_indices = []
                        best_obj_key = loop_obj_key
                        best_obj_name = loop_obj_name
            if check_v:
                for i, loop_rec in enumerate(loops):
                    px_c, py_c = loop_rec.get('px', f_pxs[i])
                    d = math.hypot(rx - px_c, ry - py_c)
                    loop_obj_key = loop_rec.get('obj_key', rec_obj_key)
                    loop_obj_name = str(loop_rec.get('obj_name', rec_obj_name) or rec_obj_name)
                    if d < min_dist_raw:
                        min_dist_raw = d
                        best_raw_type = 'VERTEX'
                        best_raw_uvs = [loop_rec.get('uv')]
                        best_raw_hover_vert_indices = [int(loop_rec.get('vert_index'))]
                        best_raw_hover_edge_indices = []
                        best_raw_hover_face_indices = []
                        best_raw_obj_key = loop_obj_key
                        best_raw_obj_name = loop_obj_name
                    if d < min_dist:
                        min_dist = d
                        best_type = 'VERTEX'
                        best_uvs = [loop_rec.get('uv')]
                        best_hover_vert_indices = [int(loop_rec.get('vert_index'))]
                        best_hover_edge_indices = []
                        best_hover_face_indices = []
                        best_obj_key = loop_obj_key
                        best_obj_name = loop_obj_name
        hover_selected = False
        if best_selected_edge is not None and best_raw_type != 'VERTEX':
            try:
                reference_dist = min(float(min_dist_raw), float(min_dist))
            except Exception:
                reference_dist = float(min_dist_selected_edge)
            # Prefer the selected edge only when it is the same hit cluster as the
            # nearest edge.  This fixes endpoint ties without stealing hover from
            # a clearly different unselected edge elsewhere in the UV layout.
            if float(min_dist_selected_edge) <= reference_dist + 1.0:
                best_type = 'EDGE'
                best_uvs = list(best_selected_edge.get('hover_uvs') or [])
                best_hover_vert_indices = list(best_selected_edge.get('hover_vert_indices') or [])
                best_hover_edge_indices = list(best_selected_edge.get('hover_edge_indices') or [])
                best_hover_face_indices = []
                best_obj_key = best_selected_edge.get('hover_obj_key')
                best_obj_name = str(best_selected_edge.get('hover_obj_name') or '')
                hover_selected = True

        # When the cursor is over an already-selected UV element, the old path
        # filtered it out and produced no visible UV Hover Overlay at all.  Keep
        # the selection-aware result when available, but fall back to the raw hit
        # so the hover overlay is still drawn over selected UVs.
        if best_type == 'NONE' and best_raw_type != 'NONE':
            best_type = best_raw_type
            best_uvs = list(best_raw_uvs)
            best_hover_vert_indices = list(best_raw_hover_vert_indices)
            best_hover_edge_indices = list(best_raw_hover_edge_indices)
            best_hover_face_indices = list(best_raw_hover_face_indices)
            best_obj_key = best_raw_obj_key
            best_obj_name = best_raw_obj_name
            hover_selected = False
        result = {
            'hover_type': best_type,
            'hover_uvs': [uv for uv in best_uvs if uv is not None],
            'hover_vert_indices': best_hover_vert_indices,
            'hover_edge_indices': best_hover_edge_indices,
            'hover_face_indices': best_hover_face_indices,
            'hover_obj_key': int(best_obj_key or 0),
            'hover_obj_name': str(best_obj_name or ''),
            'hover_selected': bool(hover_selected),
            'raw_hover_type': best_raw_type,
            'raw_hover_uvs': [uv for uv in best_raw_uvs if uv is not None],
            'raw_hover_vert_indices': best_raw_hover_vert_indices,
            'raw_hover_edge_indices': best_raw_hover_edge_indices,
            'raw_hover_face_indices': best_raw_hover_face_indices,
            'raw_hover_obj_key': int(best_raw_obj_key or 0),
            'raw_hover_obj_name': str(best_raw_obj_name or ''),
        }
        result['hover_sources'] = _query_uv_hover_sources(cache, rx, ry, result, candidate_ids=candidate_ids)
        return result

    except Exception:
        return None




def _query_uv_hover_cache_cached(cache, rx, ry, region=None):
    """Cached wrapper for repeated draw-time UV hover hit tests.

    UV editors often redraw several times with the same mouse coordinate and the
    same UV cache. Reusing the last hit result avoids repeated spatial-grid set
    construction and distance tests while preserving the visible result.
    """
    try:
        if not isinstance(cache, dict):
            return None
        try:
            reg_ptr = int(region.as_pointer()) if region is not None else 0
        except Exception:
            reg_ptr = 0
        key = (
            id(cache), cache.get('sig'), reg_ptr,
            _uv_view2d_signature(region) if region is not None else None,
            int(rx), int(ry),
            bool(cache.get('check_v')), bool(cache.get('check_e')), bool(cache.get('check_f')),
        )
        if key == getattr(_state, 'last_fast_query_sig', None):
            result = getattr(_state, 'last_fast_query_result', None)
            if isinstance(result, dict):
                return result
        result = _query_uv_hover_cache(cache, rx, ry)
        _state.last_fast_query_sig = key
        _state.last_fast_query_result = result
        _state.last_fast_query_time = time.time()
        return result
    except Exception:
        try:
            return _query_uv_hover_cache(cache, rx, ry)
        except Exception:
            return None


def _query_uv_hover_cache(cache, rx, ry):
    try:
        check_v = bool(cache.get('check_v'))
        check_e = bool(cache.get('check_e'))
        check_f = bool(cache.get('check_f'))
        if not (check_v or check_e or check_f):
            return None
        records = cache.get('records') or ()
        point_entries = cache.get('point_entries') or ()
        edge_entries = cache.get('edge_entries') or ()
        if not point_entries and not edge_entries:
            return _query_uv_hover_cache_face_scan(cache, rx, ry)
        candidate_face_ids = _uv_hover_candidate_ids(cache, rx, ry)
        candidate_point_ids = _uv_entry_candidate_ids(cache, 'point_grid', 'point_entries', rx, ry) if point_entries else ()
        candidate_edge_ids = _uv_entry_candidate_ids(cache, 'edge_grid', 'edge_entries', rx, ry) if edge_entries else ()
        if not (candidate_face_ids or candidate_point_ids or candidate_edge_ids):
            return None
        best_type = 'NONE'; best_uvs = []
        best_hover_vert_indices = []; best_hover_edge_indices = []; best_hover_face_indices = []
        best_obj_key = None; best_obj_name = ''
        best_raw_type = 'NONE'; best_raw_uvs = []
        best_raw_hover_vert_indices = []; best_raw_hover_edge_indices = []; best_raw_hover_face_indices = []
        best_raw_obj_key = None; best_raw_obj_name = ''
        min_dist = 15.0; min_dist_raw = 15.0
        min_dist_selected_edge = 15.0; best_selected_edge = None
        if check_f and records:
            for idx in candidate_face_ids:
                try:
                    rec = records[int(idx)]
                    f_pxs = rec.get('f_pxs') or ()
                    if len(f_pxs) < 3:
                        continue
                    min_x, min_y, max_x, max_y = rec.get('bbox', (0, 0, 0, 0))
                    if rx < min_x - 15.0 or rx > max_x + 15.0 or ry < min_y - 15.0 or ry > max_y + 15.0:
                        continue
                    if not _point_in_polygon_2d(rx, ry, f_pxs):
                        continue
                    rec_obj_key = rec.get('obj_key')
                    rec_obj_name = str(rec.get('obj_name', '') or '')
                    if best_raw_type not in {'VERTEX', 'EDGE'}:
                        best_raw_type = 'FACE'
                        best_raw_uvs = list(rec.get('f_uvs') or ())
                        best_raw_hover_vert_indices = list(rec.get('face_vert_indices') or ())
                        best_raw_hover_edge_indices = list(rec.get('face_edge_indices') or ())
                        best_raw_hover_face_indices = [int(rec.get('face_index', -1))]
                        best_raw_obj_key = rec_obj_key; best_raw_obj_name = rec_obj_name
                    if best_type not in {'VERTEX', 'EDGE'}:
                        best_type = 'FACE'
                        best_uvs = list(rec.get('f_uvs') or ())
                        best_hover_vert_indices = list(rec.get('face_vert_indices') or ())
                        best_hover_edge_indices = list(rec.get('face_edge_indices') or ())
                        best_hover_face_indices = [int(rec.get('face_index', -1))]
                        best_obj_key = rec_obj_key; best_obj_name = rec_obj_name
                except Exception:
                    continue
        if check_e and edge_entries:
            for eid in candidate_edge_ids:
                try:
                    ent = edge_entries[int(eid)]
                    p1 = ent.get('p1'); p2 = ent.get('p2')
                    # 線分までの距離は外接箱までの距離以上。15px 以上離れた箱は距離を計算するまでもなく除外（結果は同じ）。
                    _x1 = p1[0]; _x2 = p2[0]; _y1 = p1[1]; _y2 = p2[1]
                    if (rx < (_x1 if _x1 < _x2 else _x2) - 15.0 or rx > (_x1 if _x1 > _x2 else _x2) + 15.0
                            or ry < (_y1 if _y1 < _y2 else _y2) - 15.0 or ry > (_y1 if _y1 > _y2 else _y2) + 15.0):
                        continue
                    d = _dist_to_segment_2d(rx, ry, p1[0], p1[1], p2[0], p2[1])
                    if d >= 15.0:
                        continue
                    loop_obj_key = ent.get('obj_key')
                    loop_obj_name = str(ent.get('obj_name', '') or '')
                    edge_selected = bool(ent.get('e_selected'))
                    uv_a = ent.get('uv'); uv_b = ent.get('uv_next')
                    edge_indices = [int(ent.get('edge_index'))]
                    vert_indices = list(ent.get('edge_vert_indices') or ())
                    if d < min_dist_raw and best_raw_type != 'VERTEX':
                        min_dist_raw = d
                        best_raw_type = 'EDGE'; best_raw_uvs = [uv_a, uv_b]
                        best_raw_hover_vert_indices = vert_indices
                        best_raw_hover_edge_indices = edge_indices
                        best_raw_hover_face_indices = []
                        best_raw_obj_key = loop_obj_key; best_raw_obj_name = loop_obj_name
                    if edge_selected and d < min_dist_selected_edge and best_type != 'VERTEX':
                        min_dist_selected_edge = d
                        best_selected_edge = {
                            'hover_type': 'EDGE', 'hover_uvs': [uv_a, uv_b],
                            'hover_vert_indices': vert_indices,
                            'hover_edge_indices': edge_indices,
                            'hover_face_indices': [], 'hover_obj_key': loop_obj_key,
                            'hover_obj_name': loop_obj_name, 'hover_selected': True,
                        }
                    if d < min_dist and best_type != 'VERTEX' and not edge_selected:
                        min_dist = d
                        best_type = 'EDGE'; best_uvs = [uv_a, uv_b]
                        best_hover_vert_indices = vert_indices
                        best_hover_edge_indices = edge_indices
                        best_hover_face_indices = []
                        best_obj_key = loop_obj_key; best_obj_name = loop_obj_name
                except Exception:
                    continue
        if check_v and point_entries:
            for pid in candidate_point_ids:
                try:
                    ent = point_entries[int(pid)]
                    px_c, py_c = ent.get('px')
                    d = math.hypot(float(rx) - float(px_c), float(ry) - float(py_c))
                    if d >= 15.0:
                        continue
                    loop_obj_key = ent.get('obj_key')
                    loop_obj_name = str(ent.get('obj_name', '') or '')
                    uv_val = ent.get('uv')
                    vert_index = int(ent.get('vert_index'))
                    if d < min_dist_raw:
                        min_dist_raw = d
                        best_raw_type = 'VERTEX'; best_raw_uvs = [uv_val]
                        best_raw_hover_vert_indices = [vert_index]
                        best_raw_hover_edge_indices = []
                        best_raw_hover_face_indices = []
                        best_raw_obj_key = loop_obj_key; best_raw_obj_name = loop_obj_name
                    if d < min_dist:
                        min_dist = d
                        best_type = 'VERTEX'; best_uvs = [uv_val]
                        best_hover_vert_indices = [vert_index]
                        best_hover_edge_indices = []
                        best_hover_face_indices = []
                        best_obj_key = loop_obj_key; best_obj_name = loop_obj_name
                except Exception:
                    continue
        hover_selected = False
        if best_selected_edge is not None and best_raw_type != 'VERTEX':
            try:
                reference_dist = min(float(min_dist_raw), float(min_dist))
            except Exception:
                reference_dist = float(min_dist_selected_edge)
            if float(min_dist_selected_edge) <= reference_dist + 1.0:
                best_type = 'EDGE'
                best_uvs = list(best_selected_edge.get('hover_uvs') or [])
                best_hover_vert_indices = list(best_selected_edge.get('hover_vert_indices') or [])
                best_hover_edge_indices = list(best_selected_edge.get('hover_edge_indices') or [])
                best_hover_face_indices = []
                best_obj_key = best_selected_edge.get('hover_obj_key')
                best_obj_name = str(best_selected_edge.get('hover_obj_name') or '')
                hover_selected = True
        if best_type == 'NONE' and best_raw_type != 'NONE':
            best_type = best_raw_type
            best_uvs = list(best_raw_uvs)
            best_hover_vert_indices = list(best_raw_hover_vert_indices)
            best_hover_edge_indices = list(best_raw_hover_edge_indices)
            best_hover_face_indices = list(best_raw_hover_face_indices)
            best_obj_key = best_raw_obj_key; best_obj_name = best_raw_obj_name
            hover_selected = False
        result = {
            'hover_type': best_type,
            'hover_uvs': [uv for uv in best_uvs if uv is not None],
            'hover_vert_indices': best_hover_vert_indices,
            'hover_edge_indices': best_hover_edge_indices,
            'hover_face_indices': best_hover_face_indices,
            'hover_obj_key': int(best_obj_key or 0), 'hover_obj_name': str(best_obj_name or ''),
            'hover_selected': bool(hover_selected),
            'raw_hover_type': best_raw_type,
            'raw_hover_uvs': [uv for uv in best_raw_uvs if uv is not None],
            'raw_hover_vert_indices': best_raw_hover_vert_indices,
            'raw_hover_edge_indices': best_raw_hover_edge_indices,
            'raw_hover_face_indices': best_raw_hover_face_indices,
            'raw_hover_obj_key': int(best_raw_obj_key or 0),
            'raw_hover_obj_name': str(best_raw_obj_name or ''),
        }
        result['hover_sources'] = _query_uv_hover_sources(cache, rx, ry, result, candidate_ids=candidate_face_ids)
        return result
    except Exception:
        return None


def _uv_pair_match_unordered(a0, a1, b0, b1, eps=1.0e-6):
    try:
        au0 = (float(a0[0]), float(a0[1]))
        au1 = (float(a1[0]), float(a1[1]))
        bu0 = (float(b0[0]), float(b0[1]))
        bu1 = (float(b1[0]), float(b1[1]))
        return (_uv_close2(au0, bu0, eps) and _uv_close2(au1, bu1, eps)) or (_uv_close2(au0, bu1, eps) and _uv_close2(au1, bu0, eps))
    except Exception:
        return False


def _uv_face_match_uvs(face_uvs, primary_uvs, eps=1.0e-6):
    try:
        a = [(round(float(u), 6), round(float(v), 6)) for u, v in (face_uvs or ())]
        b = [(round(float(u), 6), round(float(v), 6)) for u, v in (primary_uvs or ())]
        if len(a) != len(b):
            return False
        # Rotation / winding independent match for stacked coincident UV faces.
        if not a and not b:
            return True
        used = [False] * len(b)
        for uv in a:
            found = False
            for i, other in enumerate(b):
                if used[i]:
                    continue
                if abs(uv[0] - other[0]) <= eps and abs(uv[1] - other[1]) <= eps:
                    used[i] = True
                    found = True
                    break
            if not found:
                return False
        return True
    except Exception:
        return False

def _query_uv_hover_sources_face_scan(cache, rx, ry, primary=None, candidate_ids=None):
    """Return coincident UV hover sources that exactly match the primary hit.

    Multi-object Edit Mode needs all stacked objects at the same UV target, but
    UV Edge/Face editing must never broaden the red hover mark through endpoint
    ties, loop-adjacent sides, or ring-adjacent sides.  Therefore sources are
    filtered by the primary UV point/segment/polygon, not by equal mouse
    distance alone.  The yellow same-mesh helper handles related UVs separately.
    """
    sources = []
    try:
        if not isinstance(cache, dict):
            return sources
        p = primary if isinstance(primary, dict) else {}
        ptype = str(p.get('hover_type', 'NONE') or 'NONE')
        if ptype not in {'VERTEX', 'EDGE', 'FACE'}:
            return sources
        primary_uvs = list(p.get('hover_uvs') or [])
        if not primary_uvs:
            return sources
        records = cache.get('records') or ()
        if not records:
            return sources
        if candidate_ids is None:
            candidate_ids = _uv_hover_candidate_ids(cache, rx, ry)
        if not candidate_ids:
            return sources

        primary_point_key = _uv_coord_key(primary_uvs[0]) if ptype == 'VERTEX' else None
        primary_edge_key = _uv_segment_coord_key(primary_uvs[0], primary_uvs[1]) if ptype == 'EDGE' and len(primary_uvs) >= 2 else None
        primary_face_key = _uv_polygon_key(primary_uvs) if ptype == 'FACE' else None

        if ptype == 'VERTEX':
            if primary_point_key is None:
                return sources
            seen = set()
            for idx in candidate_ids:
                try:
                    rec = records[int(idx)]
                    loops = rec.get('loops') or ()
                    for loop_rec in loops:
                        uv_val = loop_rec.get('uv')
                        if _uv_coord_key(uv_val) != primary_point_key:
                            continue
                        obj_key = int(loop_rec.get('obj_key', 0) or 0)
                        vi = int(loop_rec.get('vert_index'))
                        key = _uv_overlay_point_key(uv_val, vi, obj_key)
                        if key is None or key in seen:
                            continue
                        seen.add(key)
                        sources.append({
                            'hover_type': 'VERTEX',
                            'hover_obj_key': obj_key,
                            'hover_obj_name': str(loop_rec.get('obj_name', '') or ''),
                            'hover_uvs': [uv_val],
                            'hover_vert_indices': [vi],
                            'hover_edge_indices': [],
                            'hover_face_indices': [],
                        })
                except Exception:
                    continue
        elif ptype == 'EDGE':
            if primary_edge_key is None:
                return sources
            seen = set()
            for idx in candidate_ids:
                try:
                    rec = records[int(idx)]
                    f_pxs = rec.get('f_pxs') or ()
                    loops = rec.get('loops') or ()
                    for i, loop_rec in enumerate(loops):
                        uv_a = loop_rec.get('uv')
                        uv_b = loop_rec.get('uv_next')
                        if _uv_segment_coord_key(uv_a, uv_b) != primary_edge_key:
                            continue
                        # Keep the ordinary hit radius as a safety check, but do
                        # not let equal distance alone add adjacent loop/ring edges.
                        try:
                            p1 = f_pxs[i]
                            p2 = f_pxs[(i + 1) % len(f_pxs)]
                            if _dist_to_segment_2d(rx, ry, p1[0], p1[1], p2[0], p2[1]) > 15.0:
                                continue
                        except Exception:
                            pass
                        obj_key = int(loop_rec.get('obj_key', 0) or 0)
                        ei = int(loop_rec.get('edge_index'))
                        key = _uv_overlay_edge_key(ei, uv_a, uv_b, obj_key)
                        if key is None or key in seen:
                            continue
                        seen.add(key)
                        sources.append({
                            'hover_type': 'EDGE',
                            'hover_obj_key': obj_key,
                            'hover_obj_name': str(loop_rec.get('obj_name', '') or ''),
                            'hover_uvs': [uv_a, uv_b],
                            'hover_vert_indices': list(loop_rec.get('edge_vert_indices') or ()),
                            'hover_edge_indices': [ei],
                            'hover_face_indices': [],
                        })
                except Exception:
                    continue
        elif ptype == 'FACE':
            if primary_face_key is None:
                return sources
            seen = set()
            for idx in candidate_ids:
                try:
                    rec = records[int(idx)]
                    f_uvs = list(rec.get('f_uvs') or ())
                    if _uv_polygon_key(f_uvs) != primary_face_key:
                        continue
                    f_pxs = rec.get('f_pxs') or ()
                    if len(f_pxs) < 3 or not _point_in_polygon_2d(rx, ry, f_pxs):
                        continue
                    obj_key = int(rec.get('obj_key', 0) or 0)
                    fi = int(rec.get('face_index', -1))
                    key = (obj_key, fi)
                    if key in seen:
                        continue
                    seen.add(key)
                    sources.append({
                        'hover_type': 'FACE',
                        'hover_obj_key': obj_key,
                        'hover_obj_name': str(rec.get('obj_name', '') or ''),
                        'hover_uvs': f_uvs,
                        'hover_vert_indices': list(rec.get('face_vert_indices') or ()),
                        'hover_edge_indices': list(rec.get('face_edge_indices') or ()),
                        'hover_face_indices': [fi],
                    })
                except Exception:
                    continue
    except Exception:
        return []
    return sources



def _query_uv_hover_sources(cache, rx, ry, primary=None, candidate_ids=None):
    """Return coincident UV hover sources that exactly match the primary hit."""
    sources = []
    try:
        if not isinstance(cache, dict):
            return sources
        p = primary if isinstance(primary, dict) else {}
        ptype = str(p.get('hover_type', 'NONE') or 'NONE')
        if ptype not in {'VERTEX', 'EDGE', 'FACE'}:
            return sources
        primary_uvs = list(p.get('hover_uvs') or [])
        if not primary_uvs:
            return sources
        if ((ptype == 'VERTEX' and not cache.get('point_uv_index')) or
                (ptype == 'EDGE' and not cache.get('edge_uv_index')) or
                (ptype == 'FACE' and not cache.get('face_uv_index'))):
            return _query_uv_hover_sources_face_scan(cache, rx, ry, primary, candidate_ids=candidate_ids)
        seen = set()
        if ptype == 'VERTEX':

            primary_point_key = _uv_coord_key(primary_uvs[0])
            if primary_point_key is None:
                return sources
            entries = cache.get('point_entries') or ()
            for pid in (cache.get('point_uv_index') or {}).get(primary_point_key, ()) or ():
                try:
                    ent = entries[int(pid)]
                    obj_key = int(ent.get('obj_key', 0) or 0)
                    vi = int(ent.get('vert_index'))
                    uv_val = ent.get('uv')
                    key = _uv_overlay_point_key(uv_val, vi, obj_key)
                    if key is None or key in seen:
                        continue
                    seen.add(key)
                    sources.append({'hover_type': 'VERTEX', 'hover_obj_key': obj_key, 'hover_obj_name': str(ent.get('obj_name', '') or ''), 'hover_uvs': [uv_val], 'hover_vert_indices': [vi], 'hover_edge_indices': [], 'hover_face_indices': []})
                except Exception:
                    continue
        elif ptype == 'EDGE':
            if len(primary_uvs) < 2:
                return sources
            primary_edge_key = _uv_segment_coord_key(primary_uvs[0], primary_uvs[1])
            if primary_edge_key is None:
                return sources
            entries = cache.get('edge_entries') or ()
            for eid in (cache.get('edge_uv_index') or {}).get(primary_edge_key, ()) or ():
                try:
                    ent = entries[int(eid)]
                    p1 = ent.get('p1'); p2 = ent.get('p2')
                    if _dist_to_segment_2d(rx, ry, p1[0], p1[1], p2[0], p2[1]) > 15.0:
                        continue
                    obj_key = int(ent.get('obj_key', 0) or 0)
                    ei = int(ent.get('edge_index'))
                    uv_a = ent.get('uv'); uv_b = ent.get('uv_next')
                    key = _uv_overlay_edge_key(ei, uv_a, uv_b, obj_key)
                    if key is None or key in seen:
                        continue
                    seen.add(key)
                    sources.append({'hover_type': 'EDGE', 'hover_obj_key': obj_key, 'hover_obj_name': str(ent.get('obj_name', '') or ''), 'hover_uvs': [uv_a, uv_b], 'hover_vert_indices': list(ent.get('edge_vert_indices') or ()), 'hover_edge_indices': [ei], 'hover_face_indices': []})
                except Exception:
                    continue
        elif ptype == 'FACE':
            primary_face_key = _uv_polygon_key(primary_uvs)
            if primary_face_key is None:
                return sources
            records = cache.get('records') or ()
            for idx in (cache.get('face_uv_index') or {}).get(primary_face_key, ()) or ():
                try:
                    rec = records[int(idx)]
                    f_pxs = rec.get('f_pxs') or ()
                    if len(f_pxs) < 3 or not _point_in_polygon_2d(rx, ry, f_pxs):
                        continue
                    obj_key = int(rec.get('obj_key', 0) or 0)
                    face_index = int(rec.get('face_index', -1))
                    key = (obj_key, face_index, primary_face_key)
                    if key in seen:
                        continue
                    seen.add(key)
                    sources.append({'hover_type': 'FACE', 'hover_obj_key': obj_key, 'hover_obj_name': str(rec.get('obj_name', '') or ''), 'hover_uvs': list(rec.get('f_uvs') or ()), 'hover_vert_indices': list(rec.get('face_vert_indices') or ()), 'hover_edge_indices': list(rec.get('face_edge_indices') or ()), 'hover_face_indices': [face_index]})
                except Exception:
                    continue
    except Exception:
        return sources
    return sources


def _invalidate_uv_hover_cache():
    try:
        _remember_uv_hover_cache_as_stale()
        _state.uv_hover_cache = None
        _state.uv_hover_cache_sig = None
        _state.uv_hover_cache_time = 0.0
        _state.same_mesh_cache = None
        _state.same_mesh_cache_sig = None
        _state.same_mesh_cache_time = 0.0
        _state.same_mesh_gpu_batch_sig = None
        _state.same_mesh_gpu_batches = None
        _state.hover_gpu_batch_sig = None
        _state.hover_gpu_batches = None
    except Exception:
        pass


# ----------------------------------------------------------------------------- 
# Mouse processing (refactored)
# ----------------------------------------------------------------------------- 

def _uv_latest_operator_signature(context=None):
    """Return a cheap signature for the most recent Blender operator.

    This avoids timer-based BMesh rescans while still invalidating UV hover
    caches after UV, mesh, transform, selection, undo, redo, and mode changes.
    """
    try:
        wm = getattr(context or bpy.context, 'window_manager', None)
        ops = getattr(wm, 'operators', None)
        if ops is None:
            return None
        count = int(len(ops))
        if count <= 0:
            return (0, '', 0)
        op = ops[-1]
        name = str(getattr(op, 'bl_idname', '') or getattr(op, 'name', '') or '')
        try:
            ptr = int(op.as_pointer())
        except Exception:
            ptr = 0
        return (count, name, ptr)
    except Exception:
        return None


def _uv_operator_may_change_overlay(signature) -> bool:
    try:
        if not signature:
            return False
        name = str(signature[1] or '').lower()
        if not name:
            return True
        prefixes = (
            'uv_ot_', 'mesh_ot_', 'transform_ot_', 'object_ot_',
            'ed_ot_undo', 'ed_ot_redo',
        )
        if name.startswith(prefixes):
            return True
        # View2D/Image navigation changes only the UV Editor projection.  The
        # hover cache can be reprojected from stored UV coordinates and must not
        # be invalidated into a full BMesh rebuild during pan/zoom.
        if name.startswith(('view2d_ot_', 'image_ot_view_', 'image_ot_pan', 'image_ot_zoom')):
            return False
        tokens = (
            'uv', 'mesh', 'select', 'seam', 'unwrap', 'pack', 'transform',
            'translate', 'rotate', 'resize', 'scale', 'delete', 'merge', 'split',
            'dissolve', 'extrude', 'subdivide', 'duplicate', 'mode', 'undo', 'redo',
        )
        return any(tok in name for tok in tokens)
    except Exception:
        return True


def _uv_context_signature(context=None):
    try:
        ctx = context or bpy.context
        objects = _uv_edit_mesh_objects(ctx, include_data_fallback=False, include_view_layer_scan=False)
        if not objects:
            objects = _uv_edit_mesh_objects(ctx, include_data_fallback=False, include_view_layer_scan=True)
        ts = getattr(getattr(ctx, 'scene', None), 'tool_settings', None)
        obj_sig = tuple(_uv_object_identity(obj) for obj in objects)
        return (
            obj_sig,
            bool(getattr(ts, 'use_uv_select_sync', False)) if ts is not None else False,
            str(getattr(ts, 'uv_select_mode', '')) if ts is not None else '',
            tuple(bool(v) for v in getattr(ts, 'mesh_select_mode', (True, False, False))) if ts is not None else (),
        )
    except Exception:
        return None


def _uv_invalidate_hover_caches_for_external_change(context=None, *, force: bool = False) -> bool:
    """Invalidate cache only when Blender state actually changes.

    Returns True when invalidation happened so slow bridge refreshes can be
    gated to real changes instead of running from a periodic timer.
    """
    changed = False
    try:
        now = time.time()
        if not force:
            last = float(getattr(_state, 'last_external_change_check_time', 0.0) or 0.0)
            if (now - last) < _UV_EXTERNAL_CHANGE_CHECK_INTERVAL:
                return False
        _state.last_external_change_check_time = now
        sig = _uv_latest_operator_signature(context)
        prev = getattr(_state, 'last_operator_signature', None)
        if sig is not None:
            if prev is None:
                _state.last_operator_signature = sig
                if _uv_operator_may_change_overlay(sig):
                    changed = True
            elif sig != prev:
                _state.last_operator_signature = sig
                if _uv_operator_may_change_overlay(sig):
                    changed = True
        ctx_sig = _uv_context_signature(context)
        prev_ctx = getattr(_state, 'last_uv_context_signature', None)
        if prev_ctx is None:
            _state.last_uv_context_signature = ctx_sig
        elif ctx_sig != prev_ctx:
            _state.last_uv_context_signature = ctx_sig
            changed = True
        if changed:
            _remember_uv_hover_cache_as_stale()
            _state.uv_hover_cache = None
            _state.uv_hover_cache_sig = None
            _state.uv_hover_cache_time = 0.0
            _state.same_mesh_cache = None
            _state.same_mesh_cache_sig = None
            _state.same_mesh_cache_time = 0.0
            _state.last_operator_dirty_time = now
    except Exception:
        return False
    return bool(changed)

def _process_mouse_move(context, mx, my, *, force: bool = False, tag_redraw: bool = True):
    """Update UV hover state from absolute window mouse coordinates.

    The expensive BMesh/UV walk is cached and spatially indexed.  Mouse move
    events only update coordinates and query nearby cached UV records, which
    keeps UV Hover Overlay responsive without making dense UV editing heavy.
    """
    try:
        now = time.time()
        _store_last_window_mouse(context, mx, my)
        if getattr(_state, 'is_clicking', False) and now > getattr(_state, 'clicking_until', 0.0):
            _state.is_clicking = False

        screen = getattr(context, 'screen', None)
        target_region = None
        if not screen:
            try:
                override = _first_image_editor_context(context)
                if override is not None:
                    _ctx, _win, screen, _area, _reg = override
                else:
                    screen = None
            except Exception:
                screen = None
        if screen is None:
            return False
        for area in getattr(screen, 'areas', ()) or ():
            if not _area_is_uv_editor(area):
                continue
            for region in getattr(area, 'regions', ()) or ():
                if getattr(region, 'type', None) != 'WINDOW':
                    continue
                if region.x <= mx <= region.x + region.width and region.y <= my <= region.y + region.height:
                    target_region = region
                    break
            if target_region is not None:
                break

        if target_region is None:
            try:
                override = _first_image_editor_context(context)
                if override is not None:
                    _ctx, _win, _screen, _area, candidate = override
                    if candidate is not None and candidate.x <= mx <= candidate.x + candidate.width and candidate.y <= my <= candidate.y + candidate.height:
                        target_region = candidate
            except Exception:
                pass
        if target_region is None:
            _state.mouse_px = (-100, -100)
            _state.target_region_ptr = 0
            _clear_hover_state(context)
            return False

        rx = int(mx - target_region.x)
        ry = int(my - target_region.y)
        try:
            reg_ptr = int(target_region.as_pointer())
        except Exception:
            reg_ptr = 0
        if _uv_input_or_transform_active(context):
            _state.is_clicking = True
            _state.clicking_until = time.time() + 0.18
            return False
        if not _uv_may_read_edit_bmesh(context):
            _state.is_clicking = True
            _state.clicking_until = time.time() + 0.18
            return False
        external_changed = _uv_invalidate_hover_caches_for_external_change(context)
        cache_missing = not isinstance(getattr(_state, 'uv_hover_cache', None), dict)

        # Do not process duplicate mouse samples unless the UV cache was just
        # invalidated or the draw handler explicitly asks for a refresh.  This
        # prevents stale NONE/old-hover states after UV unwrap, selection, mode,
        # view, or operator changes made without mouse movement.
        mouse_sig = (rx, ry, reg_ptr)
        if (not force and not external_changed and not cache_missing and
                mouse_sig == getattr(_state, 'last_mouse_region_px', None) and
                (now - float(getattr(_state, 'last_mouse_process_time', 0.0) or 0.0)) < _UV_HOVER_MOUSE_MIN_INTERVAL):
            return False
        _state.last_mouse_region_px = mouse_sig
        _state.last_mouse_process_time = now
        _state.mouse_px = (rx, ry)
        try:
            _state.target_window_ptr = context.window.as_pointer()
        except Exception:
            _state.target_window_ptr = 0
        _state.target_region_ptr = reg_ptr

        prefs = mesh._prefs(context)
        if not prefs:
            return False
        edit_objects = _uv_edit_mesh_objects(context, include_data_fallback=False, include_view_layer_scan=True)
        if not edit_objects:
            _clear_hover_state(context)
            return False

        cache = _get_uv_hover_cache(context, target_region, prefs)
        result = _query_uv_hover_cache(cache, rx, ry) if cache else None
        if not result and cache is None and not force:
            return False
        if not result:
            result = {
                'hover_type': 'NONE', 'hover_uvs': [], 'hover_vert_indices': [], 'hover_edge_indices': [], 'hover_face_indices': [],
                'raw_hover_type': 'NONE', 'raw_hover_uvs': [], 'raw_hover_vert_indices': [], 'raw_hover_edge_indices': [], 'raw_hover_face_indices': [],
                'hover_obj_key': 0, 'hover_obj_name': '', 'raw_hover_obj_key': 0, 'raw_hover_obj_name': '', 'hover_sources': [],
            }

        changed = (
            _state.hover_type != result['hover_type'] or _state.hover_uvs != result['hover_uvs'] or
            getattr(_state, 'hover_vert_indices', []) != result['hover_vert_indices'] or
            getattr(_state, 'hover_edge_indices', []) != result['hover_edge_indices'] or
            getattr(_state, 'hover_face_indices', []) != result['hover_face_indices'] or
            int(getattr(_state, 'hover_obj_key', 0) or 0) != int(result.get('hover_obj_key', 0) or 0) or
            getattr(_state, 'hover_obj_name', '') != str(result.get('hover_obj_name', '') or '') or
            getattr(_state, 'raw_hover_type', 'NONE') != result['raw_hover_type'] or
            getattr(_state, 'raw_hover_uvs', []) != result['raw_hover_uvs'] or
            getattr(_state, 'raw_hover_vert_indices', []) != result['raw_hover_vert_indices'] or
            getattr(_state, 'raw_hover_edge_indices', []) != result['raw_hover_edge_indices'] or
            getattr(_state, 'raw_hover_face_indices', []) != result['raw_hover_face_indices'] or
            int(getattr(_state, 'raw_hover_obj_key', 0) or 0) != int(result.get('raw_hover_obj_key', 0) or 0) or
            getattr(_state, 'raw_hover_obj_name', '') != str(result.get('raw_hover_obj_name', '') or '') or
            list(getattr(_state, 'hover_sources', []) or []) != list(result.get('hover_sources') or [])
        )
        if changed:
            _state.hover_type = result['hover_type']
            _state.hover_uvs = list(result['hover_uvs'])
            _state.hover_obj_key = int(result.get('hover_obj_key', 0) or 0)
            _state.hover_obj_name = str(result.get('hover_obj_name', '') or '')
            _state.hover_vert_indices = list(result['hover_vert_indices'])
            _state.hover_edge_indices = list(result['hover_edge_indices'])
            _state.hover_face_indices = list(result['hover_face_indices'])
            _state.raw_hover_type = result['raw_hover_type']
            _state.raw_hover_uvs = list(result['raw_hover_uvs'])
            _state.raw_hover_vert_indices = list(result['raw_hover_vert_indices'])
            _state.raw_hover_edge_indices = list(result['raw_hover_edge_indices'])
            _state.raw_hover_face_indices = list(result['raw_hover_face_indices'])
            _state.raw_hover_obj_key = int(result.get('raw_hover_obj_key', 0) or 0)
            _state.raw_hover_obj_name = str(result.get('raw_hover_obj_name', '') or '')
            _state.hover_sources = list(result.get('hover_sources') or [])
            if tag_redraw:
                try:
                    target_region.tag_redraw()
                except Exception:
                    pass
        # A cache invalidation or first cache construction can change the draw
        # snapshot even when the resolved hover element itself stays the same.
        # Report that as dirty so the finite event-side snapshot job is not
        # skipped.
        return bool(changed or external_changed or cache_missing)
    except Exception:
        # Never let UV hover processing break Blender's event loop.
        try:
            _state.modal_exception_count = int(getattr(_state, 'modal_exception_count', 0) or 0) + 1
        except Exception:
            pass
        return False


# ----------------------------------------------------------------------------- 
# 3D mouse state update (keeps View3D hover responsive even if keymaps are blocked)
# ----------------------------------------------------------------------------- 
def _update_view3d_mouse_state(context, mx, my):
    try:
        win = getattr(context, "window", None)
        scr = getattr(context, "screen", None)
        wm = getattr(context, "window_manager", None)
        if not win or not scr or not wm:
            return

        # Update stored mouse position (window coords)
        try:
            wm.sos_mouse_x = int(mx)
            wm.sos_mouse_y = int(my)
        except Exception:
            pass

        win_ptr = getattr(win, "as_pointer", lambda: 0)()
        region_ptr = 0

        # Find View3D window region under the mouse
        try:
            for area in scr.areas:
                if area.type != 'VIEW_3D':
                    continue
                for region in area.regions:
                    if region.type != 'WINDOW':
                        continue
                    if region.x <= mx <= region.x + region.width and region.y <= my <= region.y + region.height:
                        region_ptr = region.as_pointer()
                        raise StopIteration
        except StopIteration:
            pass
        except Exception:
            region_ptr = 0

        # Update mesh module pointers used by "Active View Only"
        try:
            mesh._sos_mouse_window_ptr = win_ptr
            mesh._sos_active_region_ptr = region_ptr
        except Exception:
            pass

        # Redraw the View3D to keep hover responsive
        try:
            if getattr(wm, "sos_enabled", False) or getattr(wm, "sos_proportional_overlay_enabled", False):
                mesh.tag_view3d_redraw()
        except Exception:
            pass
    except Exception:
        pass


def _uv_force_refresh_from_last_mouse(context=None, *, force_cache: bool = False, tag_redraw: bool = False) -> bool:
    try:
        coords = _last_window_mouse_valid(max_age=45.0, context=context or getattr(bpy, 'context', None))
        if coords is None:
            return False
        now = time.time()
        if _uv_interaction_guard_active(context or bpy.context):
            return False
        if (not force_cache) and (now - float(getattr(_state, 'last_force_process_time', 0.0) or 0.0)) < 0.025:
            return False
        _state.last_force_process_time = now
        _process_mouse_move(context or bpy.context, coords[0], coords[1], force=bool(force_cache), tag_redraw=bool(tag_redraw))
        return True
    except Exception:
        return False


def _uv_deferred_refresh_timer():
    try:
        _state.deferred_refresh_pending = False
        coords = getattr(_state, 'deferred_refresh_mouse_px', None) or _last_window_mouse_valid(max_age=2.0, context=getattr(bpy, 'context', None))
        if coords is None:
            return None
        if _uv_interaction_guard_active(bpy.context):
            _state.deferred_refresh_pending = True
            bpy.app.timers.register(_uv_deferred_refresh_timer, first_interval=max(0.08, _UV_DEFERRED_REFRESH_DELAY))
            return None
        try:
            _invalidate_uv_hover_cache()
        except Exception:
            pass
        # Display-only refresh. Resolve the exact Window that supplied the
        # coordinate; app-timer bpy.context is frequently empty.
        processed = False
        wanted_window_ptr = int(getattr(_state, 'deferred_refresh_window_ptr', 0) or 0)
        target_window = _uv_window_by_pointer(wanted_window_ptr, getattr(bpy, 'context', None))
        if target_window is not None:
            target_screen = getattr(target_window, 'screen', None)
            if target_screen is not None:
                try:
                    with bpy.context.temp_override(window=target_window, screen=target_screen):
                        _process_mouse_move(bpy.context, int(coords[0]), int(coords[1]), force=True, tag_redraw=True)
                        processed = True
                except Exception:
                    processed = False
        if not processed:
            _process_mouse_move(bpy.context, int(coords[0]), int(coords[1]), force=True, tag_redraw=True)
        try:
            _tag_uv_image_redraw()
        except Exception:
            pass
    except Exception:
        pass
    return None


def _schedule_uv_deferred_refresh(context=None, mx=None, my=None, *, delay: float = _UV_DEFERRED_REFRESH_DELAY):
    try:
        if mx is None or my is None:
            coords = _last_window_mouse_valid(max_age=2.0, context=context or getattr(bpy, 'context', None))
            if coords is None:
                return
            mx, my = coords
        _state.deferred_refresh_mouse_px = (int(mx), int(my))
        _state.deferred_refresh_window_ptr = _uv_rna_pointer(getattr(context, 'window', None))
        if not bool(getattr(_state, 'deferred_refresh_pending', False)):
            _state.deferred_refresh_pending = True
            bpy.app.timers.register(_uv_deferred_refresh_timer, first_interval=max(0.01, float(delay)))
    except Exception:
        try:
            _state.deferred_refresh_pending = False
        except Exception:
            pass


# -----------------------------------------------------------------------------
# Same-mesh UV selection overlay
# -----------------------------------------------------------------------------
def _uv_loop_vert_selected(loop, face, uv_layer, is_sync: bool) -> bool:
    try:
        if is_sync:
            return bool(loop.vert.select)
        return _loop_uv_vert_selected(loop, uv_layer)
    except Exception:
        return False


def _uv_loop_edge_selected(loop, face, uv_layer, is_sync: bool) -> bool:
    try:
        if is_sync:
            return bool(loop.edge.select)
        return _loop_uv_edge_selected(loop, uv_layer)
    except Exception:
        return False


def _uv_face_selected_for_same_mesh(face, loops, uv_layer, is_sync: bool) -> bool:
    try:
        if is_sync:
            return bool(face.select)
        return bool(loops) and all(_loop_uv_vert_selected(loop, uv_layer) for loop in loops)
    except Exception:
        return False


def _uv_same_mesh_selection_mode(context):
    """Return UV/mesh selection mode without depending on UV hover visibility toggles."""
    try:
        ts = getattr(getattr(context, 'scene', None), 'tool_settings', None)
        if ts is None:
            return False, False, False, False, ('INVALID',)
        is_sync = bool(getattr(ts, 'use_uv_select_sync', False))
        if is_sync:
            mode = tuple(bool(v) for v in getattr(ts, 'mesh_select_mode', (True, False, False)))
            if len(mode) < 3:
                mode = tuple(list(mode) + [False] * (3 - len(mode)))
            return True, bool(mode[0]), bool(mode[1]), bool(mode[2]), ('SYNC', mode[:3])
        uv_mode = getattr(ts, 'uv_select_mode', 'VERTEX')
        if isinstance(uv_mode, str):
            values = {uv_mode}
        else:
            values = set(uv_mode or ())
        values = {str(v) for v in values}
        return False, ('VERTEX' in values), ('EDGE' in values), bool({'FACE', 'ISLAND'} & values), ('UV', tuple(sorted(values)))
    except Exception:
        return False, False, False, False, ('INVALID',)


def _same_mesh_face_selected_live(face, loops, uv_layer, is_sync: bool, face_selection_mode: bool) -> bool:
    """Return whether this exact UV face side is selected for same-mesh helpers."""
    try:
        if not face_selection_mode:
            return False
        if is_sync:
            return bool(getattr(face, 'select', False))
        # In non-sync UV mode, BMFace.select and BMFace.uv_select can be true for
        # adjacent or partially selected faces in Blender 5.1.  The only stable
        # selected-side definition for this helper is the exact UV loop state.
        return bool(loops) and all(_loop_uv_vert_selected(loop, uv_layer) for loop in loops)
    except Exception:
        return False


def _store_same_mesh_draw_snapshot(points, edges, sig=None):
    try:
        _state.same_mesh_draw_points = [tuple(map(float, p)) for p in (points or [])]
        _state.same_mesh_draw_edges = [(tuple(map(float, a)), tuple(map(float, b))) for a, b in (edges or [])]
        _state.same_mesh_draw_sig = sig
        _state.same_mesh_draw_time = time.time()
    except Exception:
        try:
            _state.same_mesh_draw_points = []
            _state.same_mesh_draw_edges = []
            _state.same_mesh_draw_sig = None
            _state.same_mesh_draw_time = 0.0
        except Exception:
            pass


def _get_same_mesh_draw_snapshot(max_age: float = 0.75):
    try:
        age = time.time() - float(getattr(_state, 'same_mesh_draw_time', 0.0) or 0.0)
        if age < 0.0 or age > float(max_age):
            return [], []
        return list(getattr(_state, 'same_mesh_draw_points', []) or []), list(getattr(_state, 'same_mesh_draw_edges', []) or [])
    except Exception:
        return [], []


def _collect_same_mesh_uv_selection_overlay(context, prefs, cache=None, *, allow_live: bool = True, use_cached_on_fail: bool = True, hover_payload=None):
    """Collect same-3D-element UV helper marks from a guarded cache snapshot.

    This display helper never reads live edit BMesh directly.  It consumes the
    snapshot produced by _build_uv_hover_cache(), whose BMesh read is blocked
    during UV transforms, Smart UV modal tools, mouse drags, and selection flushes.
    The selected UV side itself is excluded by exact UV+mesh keys, so yellow marks
    are drawn only on unselected UV vertices/edges sharing the same 3D mesh
    vertex/edge.  When live collection is unsafe, a short-lived draw snapshot is
    returned so the overlay does not flicker while still remaining read-only.
    """
    points = []
    edges = []
    try:
        if not allow_live:
            return _get_same_mesh_draw_snapshot() if use_cached_on_fail else (points, edges)
        if not isinstance(cache, dict):
            return _get_same_mesh_draw_snapshot() if use_cached_on_fail else (points, edges)
        if not bool(getattr(prefs, 'show_uv_same_mesh_selection_overlay', True)):
            return points, edges
        show_v = bool(getattr(prefs, 'show_uv_same_mesh_selection_verts', True))
        show_e = bool(getattr(prefs, 'show_uv_same_mesh_selection_edges', True))
        if not (show_v or show_e):
            return points, edges
        def _set_view(value):
            return value if isinstance(value, set) else set(value or ())
        selected_mesh_verts = _set_view(cache.get('selected_mesh_verts'))
        selected_mesh_edges = _set_view(cache.get('selected_mesh_edges'))
        selected_uv_point_keys = _set_view(cache.get('selected_uv_point_keys'))
        selected_uv_edge_keys = _set_view(cache.get('selected_uv_edge_keys'))
        hover_mesh_verts = set()
        hover_mesh_edges = set()
        hover_exclude_uv_point_keys = set()
        hover_exclude_uv_edge_keys = set()
        # In addition to explicit UV selection, use the current UV hover target as
        # a source for the yellow same-mesh helper.  In multi-object Edit Mode,
        # stacked UVs can represent several edited objects at the same screen
        # position; process every coincident hover source so no object is skipped.
        hover_source_active = False
        try:
            hp = hover_payload if isinstance(hover_payload, dict) else {}
            sources = list(hp.get('hover_sources') or [])
            if not sources:
                sources = [hp]
            for src in sources:
                if not isinstance(src, dict):
                    continue
                h_type = str(src.get('hover_type', 'NONE') or 'NONE')
                h_uvs = [tuple(map(float, uv)) for uv in (src.get('hover_uvs') or ()) if uv is not None]
                h_verts = [int(v) for v in (src.get('hover_vert_indices') or ())]
                h_edges = [int(e) for e in (src.get('hover_edge_indices') or ())]
                h_obj_key = int(src.get('hover_obj_key', getattr(_state, 'hover_obj_key', 0)) or 0)
                if h_type not in {'VERTEX', 'EDGE', 'FACE'} or not h_obj_key:
                    continue
                hover_source_active = True
                if h_type == 'VERTEX':
                    for vi in h_verts:
                        hover_mesh_verts.add((h_obj_key, int(vi)))
                    if h_uvs and h_verts:
                        key = _uv_overlay_point_key(h_uvs[0], h_verts[0], h_obj_key)
                        if key is not None:
                            hover_exclude_uv_point_keys.add(key)
                elif h_type == 'EDGE':
                    for ei in h_edges:
                        hover_mesh_edges.add((h_obj_key, int(ei)))
                    if len(h_uvs) >= 2 and h_edges:
                        key = _uv_overlay_edge_key(h_edges[0], h_uvs[0], h_uvs[1], h_obj_key)
                        if key is not None:
                            hover_exclude_uv_edge_keys.add(key)
                elif h_type == 'FACE':
                    for ei in h_edges:
                        hover_mesh_edges.add((h_obj_key, int(ei)))
                    if h_edges and len(h_uvs) >= 2:
                        for i, ei in enumerate(h_edges):
                            try:
                                uv_a = h_uvs[i % len(h_uvs)]
                                uv_b = h_uvs[(i + 1) % len(h_uvs)]
                                key = _uv_overlay_edge_key(ei, uv_a, uv_b, h_obj_key)
                                if key is not None:
                                    hover_exclude_uv_edge_keys.add(key)
                            except Exception:
                                continue
            if hover_source_active:
                selected_mesh_verts = set(hover_mesh_verts)
                selected_mesh_edges = set(hover_mesh_edges)
                selected_uv_point_keys = set(hover_exclude_uv_point_keys)
                selected_uv_edge_keys = set(hover_exclude_uv_edge_keys)
        except Exception:
            pass
        if not (selected_mesh_verts or selected_mesh_edges):
            return _get_same_mesh_draw_snapshot() if use_cached_on_fail else (points, edges)
        seen_points = set(); seen_edges = set()
        vert_map = cache.get('same_mesh_vert_map') if isinstance(cache.get('same_mesh_vert_map'), dict) else None
        edge_map = cache.get('same_mesh_edge_map') if isinstance(cache.get('same_mesh_edge_map'), dict) else None
        if show_v and selected_mesh_verts and vert_map is not None:
            for vkey in selected_mesh_verts:
                try:
                    obj_key_for_map, _vi_for_map = vkey
                except Exception:
                    obj_key_for_map, _vi_for_map = 0, -1
                for uv, vi, was_selected in vert_map.get(vkey, ()) or ():
                    try:
                        key = _uv_overlay_point_key(uv, vi, obj_key_for_map)
                        if key is None or key in selected_uv_point_keys or key in seen_points:
                            continue
                        if (not hover_source_active) and bool(was_selected):
                            continue
                        if uv is not None:
                            seen_points.add(key); points.append(tuple(map(float, uv)))
                    except Exception:
                        continue
        if show_e and selected_mesh_edges and edge_map is not None:
            for ekey in selected_mesh_edges:
                try:
                    obj_key_for_map, _ei_for_map = ekey
                except Exception:
                    obj_key_for_map, _ei_for_map = 0, -1
                for uv, uv_next, ei, was_selected in edge_map.get(ekey, ()) or ():
                    try:
                        key = _uv_overlay_edge_key(ei, uv, uv_next, obj_key_for_map)
                        if key is None or key in selected_uv_edge_keys or key in seen_edges:
                            continue
                        if (not hover_source_active) and bool(was_selected):
                            continue
                        if uv is not None and uv_next is not None:
                            seen_edges.add(key); edges.append((tuple(map(float, uv)), tuple(map(float, uv_next))))
                    except Exception:
                        continue
        if (vert_map is None or edge_map is None) and not (points or edges):
            records = tuple(cache.get('same_loop_records') or ())
            if not records:
                return _get_same_mesh_draw_snapshot() if use_cached_on_fail else (points, edges)
            if show_v and selected_mesh_verts:
                for rec in records:
                    try:
                        vi = int(rec.get('vert_index'))
                        obj_key = int(rec.get('obj_key', 0) or 0)
                        vkey = (obj_key, vi)
                        key = _uv_overlay_point_key(rec.get('uv'), vi, obj_key)
                        if vkey not in selected_mesh_verts or key is None or key in selected_uv_point_keys or key in seen_points:
                            continue
                        if (not hover_source_active) and bool(rec.get('v_selected')):
                            continue
                        uv = rec.get('uv')
                        if uv is not None:
                            seen_points.add(key); points.append(tuple(map(float, uv)))
                    except Exception:
                        continue
            if show_e and selected_mesh_edges:
                for rec in records:
                    try:
                        ei = int(rec.get('edge_index'))
                        obj_key = int(rec.get('obj_key', 0) or 0)
                        ekey = (obj_key, ei)
                        key = _uv_overlay_edge_key(ei, rec.get('uv'), rec.get('uv_next'), obj_key)
                        if ekey not in selected_mesh_edges or key is None or key in selected_uv_edge_keys or key in seen_edges:
                            continue
                        if (not hover_source_active) and bool(rec.get('e_selected')):
                            continue
                        uv = rec.get('uv'); uv_next = rec.get('uv_next')
                        if uv is not None and uv_next is not None:
                            seen_edges.add(key); edges.append((tuple(map(float, uv)), tuple(map(float, uv_next))))
                    except Exception:
                        continue
        if points or edges:
            _store_same_mesh_draw_snapshot(points, edges, sig=cache.get('sig'))
        return points, edges
    except Exception:
        return _get_same_mesh_draw_snapshot() if use_cached_on_fail else ([], [])

def _draw_uv_same_mesh_selection_overlay(context, reg, prefs, shader, draw_quad_func, draw_line_quad_func, draw_square_func, cache=None, *, allow_live: bool = True, hover_payload=None, draw_quads_func=None) -> bool:
    try:
        if cache is None and allow_live and _uv_may_read_edit_bmesh(context):
            cache = _get_uv_hover_cache(context, reg, prefs, force=False)

        # Reuse same-mesh source collection across identical redraws.  The key
        # includes the cache signature, view transform, visibility toggles, and
        # complete hover payload, so UV edits, selection changes, pan/zoom, or a
        # different hovered element still rebuild immediately.
        try:
            payload_key = None
            if isinstance(hover_payload, dict):
                payload_key = (
                    str(hover_payload.get('hover_type', 'NONE') or 'NONE'),
                    tuple((round(float(u), 7), round(float(v), 7)) for u, v in (hover_payload.get('hover_uvs') or ()) if u is not None and v is not None),
                    tuple(int(v) for v in (hover_payload.get('hover_vert_indices') or ())),
                    tuple(int(e) for e in (hover_payload.get('hover_edge_indices') or ())),
                    tuple(int(f) for f in (hover_payload.get('hover_face_indices') or ())),
                    int(hover_payload.get('hover_obj_key', 0) or 0),
                    tuple((
                        int(src.get('hover_obj_key', 0) or 0),
                        str(src.get('hover_type', '') or ''),
                        tuple((round(float(u), 7), round(float(v), 7)) for u, v in (src.get('hover_uvs') or ()) if u is not None and v is not None),
                        tuple(int(v) for v in (src.get('hover_vert_indices') or ())),
                        tuple(int(e) for e in (src.get('hover_edge_indices') or ())),
                        tuple(int(f) for f in (src.get('hover_face_indices') or ())),
                    ) for src in (hover_payload.get('hover_sources') or ()) if isinstance(src, dict)),
                )
            try:
                reg_ptr = int(reg.as_pointer()) if reg is not None else 0
            except Exception:
                reg_ptr = 0
            coll_key = (
                id(cache) if isinstance(cache, dict) else 0,
                cache.get('sig') if isinstance(cache, dict) else None,
                reg_ptr, _uv_view2d_signature(reg), bool(allow_live),
                bool(getattr(prefs, 'show_uv_same_mesh_selection_overlay', True)),
                bool(getattr(prefs, 'show_uv_same_mesh_selection_verts', True)),
                bool(getattr(prefs, 'show_uv_same_mesh_selection_edges', True)),
                payload_key,
            )
            if coll_key == getattr(_state, 'last_draw_same_mesh_key', None):
                points = list(getattr(_state, 'last_draw_same_mesh_points', []) or [])
                edges = list(getattr(_state, 'last_draw_same_mesh_edges', []) or [])
            else:
                points, edges = _collect_same_mesh_uv_selection_overlay(context, prefs, cache, allow_live=allow_live, hover_payload=hover_payload)
                _state.last_draw_same_mesh_key = coll_key
                _state.last_draw_same_mesh_points = list(points or [])
                _state.last_draw_same_mesh_edges = list(edges or [])
                _state.last_draw_same_mesh_time = time.time()
        except Exception:
            points, edges = _collect_same_mesh_uv_selection_overlay(context, prefs, cache, allow_live=allow_live, hover_payload=hover_payload)

        if not points and not edges:
            return False
        v2d = getattr(reg, 'view2d', None)
        if v2d is None:
            return False

        def _clamp_alpha(value, fallback=1.0):
            try:
                f = float(value)
            except Exception:
                f = float(fallback)
            return 0.0 if f < 0.0 else (1.0 if f > 1.0 else f)

        alpha = _clamp_alpha(getattr(prefs, 'uv_same_mesh_selection_opacity', 1.0), 1.0)
        color3 = tuple(getattr(prefs, 'uv_same_mesh_selection_color', (1.0, 1.0, 0.0)))
        color = (float(color3[0]), float(color3[1]), float(color3[2]), alpha)
        v_size = float(getattr(prefs, 'vertex_size', 4.0))
        e_size = float(getattr(prefs, 'edge_size', 2.0))
        v_half = max(1.0, v_size * 0.5)
        e_half = max(0.5, e_size * 0.5)
        aa_mode = getattr(prefs, 'edge_aa_mode', 'AA_2PASS') or 'AA_2PASS'
        use_2pass = (aa_mode == 'AA_2PASS')
        outer = (color[0], color[1], color[2], color[3] * 0.35)
        uv_xform = _uv_region_affine_transform(reg)
        drawn = False

        if _uv_capture_commands is not None:
            try:
                for uv1, uv2 in edges:
                    p1 = _uv_to_region_px_fast(reg, uv_xform, uv1[0], uv1[1])
                    p2 = _uv_to_region_px_fast(reg, uv_xform, uv2[0], uv2[1])
                    if not (_uv_region_point_is_valid(p1) and _uv_region_point_is_valid(p2)):
                        continue
                    p1 = (float(p1[0]), float(p1[1]))
                    p2 = (float(p2[0]), float(p2[1]))
                    if use_2pass:
                        draw_line_quad_func(shader, p1, p2, e_half + 1.0, outer)
                    draw_line_quad_func(shader, p1, p2, e_half, color)
                    drawn = True
                for uvp in points:
                    px = _uv_to_region_px_fast(reg, uv_xform, uvp[0], uvp[1])
                    if not _uv_region_point_is_valid(px):
                        continue
                    x, y = float(px[0]), float(px[1])
                    if use_2pass:
                        draw_square_func(shader, x, y, v_half + 1.0, outer)
                    draw_square_func(shader, x, y, v_half, color)
                    drawn = True
                return drawn
            except Exception:
                return False

        if callable(draw_quads_func) and _uv_capture_commands is None:
            try:
                def _round_color(c):
                    return tuple(round(float(v), 5) for v in c)

                batch_sig = (
                    coll_key,
                    tuple((round(float(u), 7), round(float(v), 7)) for u, v in points),
                    tuple(((round(float(a[0]), 7), round(float(a[1]), 7)), (round(float(b[0]), 7), round(float(b[1]), 7))) for a, b in edges),
                    _round_color(color), _round_color(outer),
                    round(float(v_half), 4), round(float(e_half), 4), bool(use_2pass),
                )
                batches = getattr(_state, 'same_mesh_gpu_batches', None)
                if batch_sig != getattr(_state, 'same_mesh_gpu_batch_sig', None) or not isinstance(batches, tuple):
                    edge_inner = []; edge_outer = []; point_inner = []; point_outer = []
                    for uv1, uv2 in edges:
                        p1 = _uv_to_region_px_fast(reg, uv_xform, uv1[0], uv1[1])
                        p2 = _uv_to_region_px_fast(reg, uv_xform, uv2[0], uv2[1])
                        if not (_uv_region_point_is_valid(p1) and _uv_region_point_is_valid(p2)):
                            continue
                        p1 = (float(p1[0]), float(p1[1])); p2 = (float(p2[0]), float(p2[1]))
                        q = _edge_to_quad(p1, p2, e_half)
                        if q:
                            edge_inner.append(q)
                        if use_2pass:
                            q = _edge_to_quad(p1, p2, e_half + 1.0)
                            if q:
                                edge_outer.append(q)
                    for uvp in points:
                        px = _uv_to_region_px_fast(reg, uv_xform, uvp[0], uvp[1])
                        if not _uv_region_point_is_valid(px):
                            continue
                        x, y = float(px[0]), float(px[1])
                        point_inner.append([(x - v_half, y - v_half), (x + v_half, y - v_half), (x - v_half, y + v_half), (x + v_half, y + v_half)])
                        if use_2pass:
                            h = v_half + 1.0
                            point_outer.append([(x - h, y - h), (x + h, y - h), (x - h, y + h), (x + h, y + h)])

                    def _quads_batch(quads):
                        positions = []
                        indices = []
                        for q in quads or ():
                            if not q or len(q) < 4:
                                continue
                            base = len(positions)
                            positions.extend(q[:4])
                            indices.append((base, base + 1, base + 2))
                            indices.append((base + 1, base + 3, base + 2))
                        if not positions:
                            return None
                        return batch_for_shader(shader, 'TRIS', {"pos": positions}, indices=indices)

                    built = []
                    for quads, c in ((edge_outer, outer), (point_outer, outer), (edge_inner, color), (point_inner, color)):
                        b = _quads_batch(quads)
                        if b is not None:
                            built.append((b, tuple(c)))
                    batches = tuple(built)
                    _state.same_mesh_gpu_batch_sig = batch_sig
                    _state.same_mesh_gpu_batches = batches
                drawn = False
                for batch, c in batches or ():
                    try:
                        shader.bind()
                        shader.uniform_float("color", c)
                        batch.draw(shader)
                        drawn = True
                    except Exception:
                        continue
                return drawn
            except Exception:
                drawn = False

        for uv1, uv2 in edges:
            p1 = _uv_to_region_px_fast(reg, uv_xform, uv1[0], uv1[1])
            p2 = _uv_to_region_px_fast(reg, uv_xform, uv2[0], uv2[1])
            if not (_uv_region_point_is_valid(p1) and _uv_region_point_is_valid(p2)):
                continue
            p1 = (float(p1[0]), float(p1[1]))
            p2 = (float(p2[0]), float(p2[1]))
            if use_2pass:
                draw_line_quad_func(shader, p1, p2, e_half + 1.0, outer)
            draw_line_quad_func(shader, p1, p2, e_half, color)
            drawn = True
        for uvp in points:
            px = _uv_to_region_px_fast(reg, uv_xform, uvp[0], uvp[1])
            if not _uv_region_point_is_valid(px):
                continue
            x, y = float(px[0]), float(px[1])
            if use_2pass:
                draw_square_func(shader, x, y, v_half + 1.0, outer)
            draw_square_func(shader, x, y, v_half, color)
            drawn = True
        return drawn
    except Exception:
        return False


def _uv_snapshot_pointer(value):
    try:
        return int(value.as_pointer()) if value is not None else 0
    except Exception:
        return 0


def _uv_snapshot_key(context=None):
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return None
    target = _uv_editor_target_for_region(
        ctx,
        region=getattr(ctx, 'region', None),
        area=getattr(ctx, 'area', None),
    )
    if not isinstance(target, dict):
        return None
    return (
        _uv_snapshot_pointer(target.get('window') or getattr(ctx, 'window', None)),
        _uv_snapshot_pointer(target.get('area')),
        _uv_snapshot_pointer(target.get('region')),
        _uv_snapshot_pointer(getattr(ctx, 'scene', None)),
    )


def _uv_snapshot_style_signature(context=None):
    prefs = mesh._prefs(context or getattr(bpy, 'context', None))
    if prefs is None:
        return None
    def _tuple(name, fallback):
        try:
            return tuple(round(float(v), 6) for v in tuple(getattr(prefs, name, fallback)))
        except Exception:
            return tuple(fallback)
    def _float(name, fallback):
        try:
            return round(float(getattr(prefs, name, fallback)), 6)
        except Exception:
            return round(float(fallback), 6)
    def _bool(name, fallback=True):
        try:
            return bool(getattr(prefs, name, fallback))
        except Exception:
            return bool(fallback)
    return (
        _tuple('hover_uv_vertex_color', (1.0, 0.78, 0.02)),
        _tuple('hover_uv_edge_color', (1.0, 0.78, 0.02)),
        _tuple('hover_uv_face_color', (1.0, 0.78, 0.02)),
        _float('hover_uv_vertex_edge_opacity', 1.0),
        _float('hover_uv_face_opacity', 0.25),
        _float('vertex_size', 4.0),
        _float('edge_size', 2.0),
        str(getattr(prefs, 'edge_aa_mode', 'AA_2PASS') or 'AA_2PASS'),
        _bool('show_hov_uv_verts'), _bool('show_hov_uv_edges'), _bool('show_hov_uv_faces'),
        _bool('show_uv_same_mesh_selection_overlay'),
        _bool('show_uv_same_mesh_selection_verts'),
        _bool('show_uv_same_mesh_selection_edges'),
        _tuple('uv_same_mesh_selection_color', (1.0, 1.0, 0.0)),
        _float('uv_same_mesh_selection_opacity', 1.0),
    )


def _uv_snapshot_mouse_signature(context=None):
    """Return the current mouse authority for one UV WINDOW region.

    The signature is used only to recover missing/blank snapshots.  Normal
    mouse movement still uses the coalesced event-side rebuild path, so moving
    inside the same hovered element does not force a GPU rebuild every pixel.
    """
    ctx = context or getattr(bpy, 'context', None)
    region = getattr(ctx, 'region', None) if ctx is not None else None
    if region is None or getattr(region, 'type', None) != 'WINDOW':
        return None
    win_ptr = _uv_snapshot_pointer(getattr(ctx, 'window', None))
    reg_ptr = _uv_snapshot_pointer(region)
    coords = _window_event_mouse_coords(ctx) or _last_window_mouse_valid(max_age=60.0, context=ctx)
    if coords is None:
        return (win_ptr, reg_ptr, False, None, None)
    try:
        rx = int(coords[0]) - int(getattr(region, 'x', 0) or 0)
        ry = int(coords[1]) - int(getattr(region, 'y', 0) or 0)
        inside = (
            0 <= rx < int(getattr(region, 'width', 0) or 0)
            and 0 <= ry < int(getattr(region, 'height', 0) or 0)
        )
        return (win_ptr, reg_ptr, bool(inside), rx if inside else None, ry if inside else None)
    except Exception:
        return (win_ptr, reg_ptr, False, None, None)


def _uv_snapshot_hover_signature(context=None):
    """Freeze the exact hover payload owned by the current UV region."""
    ctx = context or getattr(bpy, 'context', None)
    region = getattr(ctx, 'region', None) if ctx is not None else None
    try:
        if (
            _uv_snapshot_pointer(getattr(ctx, 'window', None))
            != int(getattr(_state, 'target_window_ptr', 0) or 0)
            or _uv_snapshot_pointer(region)
            != int(getattr(_state, 'target_region_ptr', 0) or 0)
        ):
            return ('NONE',)
    except Exception:
        return ('NONE',)
    hover_type = str(getattr(_state, 'hover_type', 'NONE') or 'NONE')
    if hover_type == 'NONE':
        return ('NONE',)
    try:
        uvs = tuple(
            (round(float(uv[0]), 7), round(float(uv[1]), 7))
            for uv in tuple(getattr(_state, 'hover_uvs', ()) or ())
        )
    except Exception:
        uvs = ()
    sources = []
    for source in tuple(getattr(_state, 'hover_sources', ()) or ()):
        if not isinstance(source, dict):
            continue
        try:
            src_uvs = tuple(
                (round(float(uv[0]), 7), round(float(uv[1]), 7))
                for uv in tuple(source.get('hover_uvs') or ())
            )
            sources.append((
                int(source.get('hover_obj_key', 0) or 0),
                str(source.get('hover_type', '') or ''),
                src_uvs,
            ))
        except Exception:
            continue
    return (
        hover_type,
        int(getattr(_state, 'hover_obj_key', 0) or 0),
        uvs,
        tuple(sorted(sources)),
    )


def _uv_snapshot_hover_expected(context, hover_signature=None):
    signature = hover_signature if hover_signature is not None else _uv_snapshot_hover_signature(context)
    if not signature or signature[0] == 'NONE':
        return False
    prefs = mesh._prefs(context)
    if prefs is None:
        return False
    hover_type = str(signature[0])
    if hover_type == 'VERTEX':
        return bool(getattr(prefs, 'show_hov_uv_verts', True))
    if hover_type == 'EDGE':
        return bool(getattr(prefs, 'show_hov_uv_edges', True))
    if hover_type == 'FACE':
        return bool(getattr(prefs, 'show_hov_uv_faces', True))
    return False


def _uv_snapshot_same_mesh_was_drawn(context=None):
    try:
        info = bpy.app.driver_namespace.get('SOS_UV_OVERLAY_LAST_DRAW')
        if not isinstance(info, dict):
            return False
        ctx = context or getattr(bpy, 'context', None)
        region = getattr(ctx, 'region', None) if ctx is not None else None
        if int(info.get('window_ptr', 0) or 0) != _uv_snapshot_pointer(getattr(ctx, 'window', None)):
            return False
        if int(info.get('region_ptr', 0) or 0) != _uv_snapshot_pointer(region):
            return False
        return bool(info.get('same_mesh', False))
    except Exception:
        return False


def _uv_snapshot_record_unusable(record):
    if not isinstance(record, dict):
        return True
    return bool(not tuple(record.get('commands') or ()) and record.get('content_expected', False))


def _uv_try_build_snapshot_for_draw(context, reason='draw_sync_recovery'):
    """Build one finite snapshot in the actual UV draw context when recovery is needed."""
    global _uv_snapshot_generation, _uv_snapshot_rebuild_active
    if _uv_snapshot_rebuild_active:
        return None
    if _uv_input_or_transform_active(context) or _uv_interaction_suppression_active(context):
        return None
    if not _uv_may_read_edit_bmesh(context):
        return None
    _uv_snapshot_rebuild_active = True
    try:
        _uv_snapshot_generation += 1
        record = _uv_build_draw_snapshot_for_context(context, int(_uv_snapshot_generation))
        if record is not None and _uv_publish_draw_snapshot(record):
            return record
    except Exception:
        return None
    finally:
        _uv_snapshot_rebuild_active = False
    return None


def _uv_iter_editor_overrides(context=None):
    ctx = context or getattr(bpy, 'context', None)
    for target in tuple(_uv_iter_live_editor_targets(ctx) or ()):
        override = dict(target)
        try:
            window = target.get('window')
            # Image Editor temp_override contexts can lose edit-mesh authority
            # even while the real UV Editor and Edit Mesh selection are valid.
            # Carry an explicit live ViewLayer into the override so snapshot
            # builders see the same edit objects as the product draw path.
            view_layer = (
                getattr(ctx, 'view_layer', None)
                or getattr(getattr(bpy, 'context', None), 'view_layer', None)
            )
            obj = getattr(getattr(view_layer, 'objects', None), 'active', None)
            edit_meshes = []
            seen = set()

            def _add(candidate):
                try:
                    if candidate is None or getattr(candidate, 'type', None) != 'MESH':
                        return
                    if str(getattr(candidate, 'mode', '') or '') not in {'EDIT', 'EDIT_MESH'}:
                        return
                    ptr = _uv_snapshot_pointer(candidate)
                    if ptr in seen:
                        return
                    seen.add(ptr)
                    edit_meshes.append(candidate)
                except Exception:
                    return

            for source_ctx in (ctx, getattr(bpy, 'context', None)):
                try:
                    for attr in ('objects_in_mode_unique_data', 'objects_in_mode', 'selected_editable_objects', 'selected_objects'):
                        for candidate in tuple(getattr(source_ctx, attr, ()) or ()):
                            _add(candidate)
                except Exception:
                    pass
            for candidate in tuple(getattr(view_layer, 'objects', ()) or ()):
                _add(candidate)
            if obj is not None and getattr(obj, 'type', None) == 'MESH':
                override.update(active_object=obj, object=obj)
                if str(getattr(obj, 'mode', '') or '') in {'EDIT', 'EDIT_MESH'}:
                    override['edit_object'] = obj
                    _add(obj)
            if edit_meshes:
                override['selected_objects'] = edit_meshes
                override['selected_editable_objects'] = edit_meshes
                override.setdefault('edit_object', edit_meshes[0])
                override.setdefault('active_object', edit_meshes[0])
                override.setdefault('object', edit_meshes[0])
        except Exception:
            pass
        yield override


def _uv_build_draw_snapshot_for_context(context, generation):
    global _uv_capture_commands
    key = _uv_snapshot_key(context)
    if key is None:
        return None
    region = getattr(context, 'region', None)
    commands = []
    _uv_capture_commands = commands
    gpu_snapshot = None
    try:
        gpu_snapshot = mesh._sos_push_gpu_state_restore()
        _draw_uv_hover_impl()
    except Exception:
        return None
    finally:
        _uv_capture_commands = None
        try:
            mesh._sos_pop_gpu_state_restore(gpu_snapshot, ui_safe=True)
        except Exception:
            pass
    try:
        region_size = (int(region.width), int(region.height))
    except Exception:
        region_size = (0, 0)
    selected_count = _uv_selected_count_for_snapshot(context)
    hover_signature = _uv_snapshot_hover_signature(context)
    mouse_signature = _uv_snapshot_mouse_signature(context)
    same_mesh_drawn = _uv_snapshot_same_mesh_was_drawn(context)
    content_expected = bool(
        _uv_snapshot_hover_expected(context, hover_signature)
        or same_mesh_drawn
    )
    return {
        'key': key,
        'generation': int(generation),
        'mode': str(getattr(context, 'mode', '') or ''),
        'view_signature': _uv_view2d_signature(region),
        'region_size': region_size,
        'style_signature': _uv_snapshot_style_signature(context),
        'selected_count': selected_count,
        'hover_signature': hover_signature,
        'mouse_signature': mouse_signature,
        'same_mesh_drawn': bool(same_mesh_drawn),
        'content_expected': bool(content_expected),
        'commands': tuple(commands),
        'created_monotonic': float(time.monotonic()),
    }


def _uv_selected_count_slow(objects, is_sync, select_v, select_e, select_f):
    """Original per-loop counter (kept for face-select mode and as the fallback)."""
    selected_count = 0
    for obj in objects:
        if obj is None or getattr(obj, 'type', None) != 'MESH':
            continue
        data = getattr(obj, 'data', None)
        if data is None:
            continue
        bm = bmesh.from_edit_mesh(data)
        uv_layer = bm.loops.layers.uv.active
        if uv_layer is None:
            continue
        for face in bm.faces:
            if getattr(face, 'hide', False):
                continue
            loops = tuple(face.loops)
            if select_f and _uv_face_selected_for_same_mesh(face, loops, uv_layer, is_sync):
                selected_count += 1
                continue
            for loop in loops:
                if select_v and _uv_loop_vert_selected(loop, face, uv_layer, is_sync):
                    selected_count += 1
                if select_e and _uv_loop_edge_selected(loop, face, uv_layer, is_sync):
                    selected_count += 1
    return int(selected_count)


def _uv_selected_count_for_snapshot(context):
    prefs = mesh._prefs(context)
    if prefs is None:
        return None
    if not bool(getattr(prefs, 'show_uv_same_mesh_selection_overlay', True)):
        return 0
    if not (
        bool(getattr(prefs, 'show_uv_same_mesh_selection_verts', True))
        or bool(getattr(prefs, 'show_uv_same_mesh_selection_edges', True))
    ):
        return 0
    try:
        objects = _uv_edit_mesh_objects(
            context,
            include_data_fallback=False,
            include_view_layer_scan=True,
        )
        is_sync, select_v, select_e, select_f, mode_key = _uv_same_mesh_selection_mode(context)
        # The count only changes when the selection (or the mesh) changes, and every
        # such change passes through a depsgraph update that advances _uv_sel_epoch.
        # Recounting 360k loops for every snapshot pass was ~0.4 s each.
        ident = []
        for obj in objects:
            if obj is None or getattr(obj, 'type', None) != 'MESH':
                continue
            data = getattr(obj, 'data', None)
            if data is None:
                continue
            ident.append((int(obj.as_pointer()), int(data.as_pointer())))
        key = (_uv_sel_epoch, _uv_geom_epoch, tuple(ident), mode_key,
               bool(is_sync), bool(select_v), bool(select_e), bool(select_f))
        cached = getattr(_state, 'uv_sel_count_cache', None)
        if cached is not None and cached[0] == key:
            return cached[1]
        count = None
        # The hover-cache patch / build has just read exactly these per-loop flags.
        patch = getattr(_state, 'uv_hover_patch', None)
        if (isinstance(patch, dict) and not select_f and (select_v or select_e)
                and patch.get('sel_epoch') == _uv_sel_epoch and patch.get('geom_epoch') == _uv_geom_epoch
                and bool(patch.get('is_sync')) == bool(is_sync)
                and isinstance(patch.get('raw'), dict)):
            try:
                keys = tuple(int(_uv_object_identity(o)[0]) for o in objects
                             if o is not None and getattr(o, 'type', None) == 'MESH' and getattr(o, 'data', None) is not None)
                if keys == patch.get('obj_keys'):
                    count = 0
                    for _kind, _on in (('v', select_v), ('e', select_e)):
                        if _on:
                            _c = _uv_patch_selected_loop_count(patch, _kind)
                            if _c is None:
                                count = None
                                break
                            count += _c
            except Exception:
                count = None
        if count is None and select_f and is_sync and not select_v and not select_e:
            try:
                count = 0
                for obj in objects:
                    if obj is None or getattr(obj, 'type', None) != 'MESH':
                        continue
                    data = getattr(obj, 'data', None)
                    if data is None:
                        continue
                    bm = bmesh.from_edit_mesh(data)
                    if bm.loops.layers.uv.active is None:
                        continue
                    count += sum(1 for f in bm.faces if (not f.hide) and f.select)
                count = int(count)
            except Exception:
                count = None
        if count is None and not select_f:
            try:
                count = 0
                for obj in objects:
                    if obj is None or getattr(obj, 'type', None) != 'MESH':
                        continue
                    data = getattr(obj, 'data', None)
                    if data is None:
                        continue
                    bm = bmesh.from_edit_mesh(data)
                    if bm.loops.layers.uv.active is None:
                        continue
                    faces = bm.faces
                    if is_sync:
                        if select_v:
                            count += sum(1 for f in faces if not f.hide for l in f.loops if l.vert.select)
                        if select_e:
                            count += sum(1 for f in faces if not f.hide for l in f.loops if l.edge.select)
                    else:
                        if select_v:
                            count += sum(1 for f in faces if not f.hide for l in f.loops if l.uv_select_vert)
                        if select_e:
                            count += sum(1 for f in faces if not f.hide for l in f.loops if l.uv_select_edge)
                count = int(count)
            except Exception:
                count = None
        if count is None:
            count = _uv_selected_count_slow(objects, is_sync, select_v, select_e, select_f)
        _state.uv_sel_count_cache = (key, count)
        return count
    except Exception:
        return None


def _uv_publish_draw_snapshot(record):
    if not isinstance(record, dict) or not record.get('key'):
        return False
    commands = tuple(record.get('commands') or ())
    if not commands and bool(record.get('content_expected', False)):
        return False
    _uv_draw_snapshots[record['key']] = record
    overflow = len(_uv_draw_snapshots) - _UV_DRAW_SNAPSHOT_MAX
    if overflow > 0:
        ordered = sorted(_uv_draw_snapshots.items(), key=lambda item: float(item[1].get('created_monotonic', 0.0)))
        for old_key, _record in ordered[:overflow]:
            _uv_draw_snapshots.pop(old_key, None)
    return True


def _uv_rebuild_draw_snapshots():
    global _uv_snapshot_generation
    if not bool(getattr(_state, 'runtime_registered', False)) or not _uv_runtime_requested():
        _uv_draw_snapshots.clear()
        return 0
    try:
        _uv_start_modal_tracker_if_needed(getattr(bpy, 'context', None), force=False)
    except Exception:
        pass
    _uv_snapshot_generation += 1
    generation = int(_uv_snapshot_generation)
    live_keys = set()
    built = 0
    for override in tuple(_uv_iter_editor_overrides(getattr(bpy, 'context', None)) or ()):
        try:
            with bpy.context.temp_override(**override):
                key = _uv_snapshot_key(bpy.context)
                if key is not None:
                    live_keys.add(key)
                record = _uv_build_draw_snapshot_for_context(bpy.context, generation)
                if record is not None and _uv_publish_draw_snapshot(record):
                    built += 1
        except Exception:
            continue
    return int(built)


def _uv_arm_interaction_suppression(seconds=_UV_INTERACTION_SUPPRESSION_GRACE):
    global _uv_interaction_suppression_requested, _uv_interaction_suppression_until
    _uv_interaction_suppression_requested = True
    _uv_interaction_suppression_until = max(
        float(_uv_interaction_suppression_until or 0.0),
        float(time.monotonic()) + max(_UV_SNAPSHOT_MIN_INTERVAL, float(seconds)),
    )


def _uv_clear_interaction_suppression():
    global _uv_interaction_suppression_requested, _uv_interaction_suppression_until
    _uv_interaction_suppression_requested = False
    _uv_interaction_suppression_until = 0.0


def _uv_interaction_suppression_active(context=None):
    """Return a finite interaction latch even when native input consumes RELEASE."""
    global _uv_interaction_suppression_requested, _uv_interaction_suppression_until
    if not _uv_interaction_suppression_requested:
        return False
    now = float(time.monotonic())
    if now < float(_uv_interaction_suppression_until or 0.0):
        return True
    try:
        still_active = bool(_uv_input_or_transform_active(context))
    except Exception:
        still_active = True
    if still_active:
        _uv_interaction_suppression_until = now + _UV_INTERACTION_SUPPRESSION_GRACE
        return True
    _uv_clear_interaction_suppression()
    _uv_snapshot_reasons.add('interaction_suppression_expired')
    return False


def _uv_edit_update_guard_active() -> bool:
    return bool(_uv_edit_update_guard_active_flag)


def _uv_clear_edit_update_guard() -> None:
    global _uv_edit_update_guard_active_flag, _uv_edit_update_guard_release_pending_generation
    _uv_edit_update_guard_active_flag = False
    _uv_edit_update_guard_release_pending_generation = 0


def _uv_snapshot_rebuild_timer():
    global _uv_snapshot_timer_pending, _uv_snapshot_rebuild_active
    global _uv_snapshot_timer_attempts, _uv_snapshot_due
    global _uv_interaction_dirty
    global _uv_edit_update_guard_active_flag, _uv_edit_update_guard_release_pending_generation
    if not bool(getattr(_state, 'runtime_registered', False)) or not _uv_runtime_requested():
        _uv_snapshot_timer_pending = False
        _uv_snapshot_timer_attempts = 0
        _uv_snapshot_due = 0.0
        _uv_snapshot_reasons.clear()
        return None
    now = float(time.monotonic())
    if now < float(_uv_snapshot_due or 0.0):
        return max(0.001, float(_uv_snapshot_due) - now)
    if _uv_edit_update_guard_active() and int(_uv_edit_update_guard_release_pending_generation or 0) == int(_uv_edit_update_guard_generation or 0):
        _uv_edit_update_guard_active_flag = False
        _uv_edit_update_guard_release_pending_generation = 0
        _uv_snapshot_reasons.add('edit_update_guard_timer_release')
        _uv_snapshot_due = now + _UV_SNAPSHOT_MIN_INTERVAL
        return _UV_SNAPSHOT_MIN_INTERVAL
    if _uv_edit_update_guard_active():
        _uv_snapshot_reasons.add('edit_update_guard_timer_defer')
        _uv_snapshot_due = now + _UV_SNAPSHOT_MIN_INTERVAL
        return _UV_SNAPSHOT_MIN_INTERVAL
    # A PRESS arms this finite timer so the complete gesture is coalesced, but
    # it must never publish an empty/stale snapshot while Blender still owns a
    # UV selection, transform, or navigation operation.  Keep the last completed
    # snapshot passive and wait for the same interaction's RELEASE/guard expiry;
    # this performs no BMesh read, cache rebuild, GPU upload, or redraw.
    context = getattr(bpy, 'context', None)
    if (_uv_interaction_suppression_active(context)
            or _uv_input_or_transform_active(context)):
        _uv_snapshot_due = now + _UV_SNAPSHOT_MIN_INTERVAL
        return _UV_SNAPSHOT_MIN_INTERVAL
    # A completed EXEC operator can mark the interaction dirty through the
    # depsgraph while no matching RELEASE event exists.  Once Blender's finite
    # interaction guard has settled, consume that marker here exactly once so
    # the next snapshot cannot reuse pre-edit selection/UV cache contents.
    if _uv_interaction_dirty:
        _invalidate_uv_hover_cache()
        _uv_interaction_dirty = False
    start_serial = int(_uv_snapshot_request_serial)
    _uv_snapshot_timer_attempts += 1
    built = 0
    _uv_snapshot_rebuild_active = True
    try:
        built = int(_uv_rebuild_draw_snapshots())
    except Exception:
        built = 0
    finally:
        _uv_snapshot_rebuild_active = False
    changed = int(_uv_snapshot_request_serial) != start_serial
    if (changed or built <= 0) and _uv_snapshot_timer_attempts < _UV_SNAPSHOT_MAX_ATTEMPTS:
        _uv_snapshot_due = float(time.monotonic()) + _UV_SNAPSHOT_MIN_INTERVAL
        return _UV_SNAPSHOT_MIN_INTERVAL
    _uv_snapshot_timer_pending = False
    _uv_snapshot_timer_attempts = 0
    _uv_snapshot_due = 0.0
    _uv_snapshot_reasons.clear()
    try:
        _tag_uv_image_redraw()
    except Exception:
        pass
    return None


def request_uv_snapshot_rebuild(reason='', context=None, immediate=False):
    global _uv_snapshot_request_serial, _uv_snapshot_timer_pending
    global _uv_snapshot_timer_attempts, _uv_snapshot_due
    if not bool(getattr(_state, 'runtime_registered', False)) or not _uv_runtime_requested(context):
        return False
    reason_text = str(reason or '')
    if reason_text:
        _uv_snapshot_reasons.add(reason_text)
    now = float(time.monotonic())
    requested_due = now if immediate else now + _UV_SNAPSHOT_MIN_INTERVAL
    if _uv_snapshot_timer_pending:
        # Requests arriving before the finite timer starts belong to one event
        # burst and need one build only.  A request that arrives while a build is
        # actually reading state advances the serial and earns exactly one
        # follow-up so no mid-build edit can be lost.
        if _uv_snapshot_rebuild_active and not reason_text.startswith('draw_'):
            _uv_snapshot_request_serial += 1
        _uv_snapshot_due = min(float(_uv_snapshot_due or requested_due), requested_due)
        return True
    _uv_snapshot_request_serial += 1
    _uv_snapshot_timer_pending = True
    _uv_snapshot_timer_attempts = 0
    _uv_snapshot_due = requested_due
    try:
        if bool(getattr(_state, 'runtime_registered', False)):  # 常駐が有効な時だけ時計を入れる
            bpy.app.timers.register(_uv_snapshot_rebuild_timer, first_interval=max(0.0, requested_due - now))
            return True
        _uv_snapshot_timer_pending = False
        return False
    except Exception:
        _uv_snapshot_timer_pending = False
        _uv_snapshot_timer_attempts = 0
        _uv_snapshot_due = 0.0
        return False


def clear_uv_draw_snapshots():
    global _uv_snapshot_timer_pending, _uv_snapshot_rebuild_active
    global _uv_snapshot_timer_attempts, _uv_snapshot_due
    global _uv_interaction_dirty
    try:
        if bpy.app.timers.is_registered(_uv_snapshot_rebuild_timer):
            bpy.app.timers.unregister(_uv_snapshot_rebuild_timer)
    except Exception:
        pass
    _uv_snapshot_timer_pending = False
    _uv_snapshot_rebuild_active = False
    _uv_snapshot_timer_attempts = 0
    _uv_snapshot_due = 0.0
    _uv_snapshot_reasons.clear()
    _uv_draw_snapshots.clear()
    _uv_interaction_dirty = False
    _uv_clear_interaction_suppression()
    _uv_clear_edit_update_guard()


def _uv_snapshot_for_draw(context=None):
    ctx = context or getattr(bpy, 'context', None)
    key = _uv_snapshot_key(ctx)
    record = _uv_draw_snapshots.get(key) if key is not None else None
    region = getattr(ctx, 'region', None)
    try:
        size = (int(region.width), int(region.height))
    except Exception:
        size = (0, 0)
    stale = (
        not isinstance(record, dict)
        or record.get('mode') != str(getattr(ctx, 'mode', '') or '')
        or tuple(record.get('region_size') or ()) != size
        or record.get('view_signature') != _uv_view2d_signature(region)
        or record.get('style_signature') != _uv_snapshot_style_signature(ctx)
    )
    unusable = _uv_snapshot_record_unusable(record)
    current_hover_signature = _uv_snapshot_hover_signature(ctx)
    hover_changed = bool(
        isinstance(record, dict)
        and record.get('hover_signature') != current_hover_signature
    )
    current_mouse_signature = _uv_snapshot_mouse_signature(ctx)
    blank_mouse_changed = bool(
        isinstance(record, dict)
        and not tuple(record.get('commands') or ())
        and record.get('mouse_signature') != current_mouse_signature
    )
    if stale or unusable or hover_changed or blank_mouse_changed:
        reason = (
            'draw_missing_or_stale' if stale
            else 'draw_zero_command_expected' if unusable
            else 'draw_hover_changed' if hover_changed
            else 'draw_blank_mouse_changed'
        )
        request_uv_snapshot_rebuild(reason, context=ctx, immediate=False)
        if stale or unusable or hover_changed:
            return None
    return record


def _uv_replay_draw_snapshot(context=None):
    record = _uv_snapshot_for_draw(context)
    if not isinstance(record, dict):
        return None
    for command in tuple(record.get('commands') or ()):
        primitive = str(command.get('primitive') or '')
        content = dict(command.get('content') or {})
        shader_name = str(command.get('shader_builtin') or 'UNIFORM_COLOR')
        if not primitive or not content:
            raise RuntimeError('Invalid UV snapshot command')
        for state_name, values in dict(command.get('state') or {}).items():
            setter = getattr(gpu.state, f'{state_name}_set', None)
            if callable(setter):
                setter(*tuple(values or ()))
        shader = gpu.shader.from_builtin(shader_name)
        indices = command.get('indices')
        batch = _gpu_batch_for_shader(shader, primitive, content, indices=indices) if indices is not None else _gpu_batch_for_shader(shader, primitive, content)
        shader.bind()
        for uniform_name, value in dict(command.get('uniforms') or {}).items():
            shader.uniform_float(uniform_name, value)
        batch.draw(shader)
    return None


@persistent
def _uv_snapshot_load_pre(_dummy):
    global _uv_sel_epoch, _uv_geom_epoch
    _uv_sel_epoch += 1
    _uv_geom_epoch += 1
    clear_uv_draw_snapshots()
    _state.uv_hover_patch = None
    _invalidate_uv_hover_cache()


@persistent
def _uv_snapshot_load_post(_dummy):
    if not bool(getattr(_state, 'runtime_registered', False)):
        return
    context = getattr(bpy, 'context', None)
    try:
        _uv_install_draw_handler_if_needed(force=True)
        _register_uv_snapshot_handlers()
        _uv_start_modal_tracker_if_needed(context, force=True)
    except Exception:
        pass
    finally:
        _uv_start_runtime_watchdog()
        request_uv_snapshot_rebuild('load_post', context=context, immediate=True)


@persistent
def _uv_snapshot_undo_post(_dummy):
    global _uv_sel_epoch, _uv_geom_epoch
    _uv_sel_epoch += 1
    _uv_geom_epoch += 1
    _invalidate_uv_hover_cache()
    if bool(getattr(_state, 'runtime_registered', False)) and _uv_runtime_requested():
        request_uv_snapshot_rebuild('undo_post', context=getattr(bpy, 'context', None), immediate=True)


@persistent
def _uv_snapshot_redo_post(_dummy):
    _uv_snapshot_undo_post(_dummy)


@persistent
def _uv_snapshot_depsgraph_update_pre(_scene, _depsgraph):
    global _uv_edit_update_guard_active_flag, _uv_edit_update_guard_generation
    global _uv_edit_update_guard_release_pending_generation
    if not bool(getattr(_state, 'runtime_registered', False)) or not _uv_runtime_requested():
        return
    _uv_edit_update_guard_active_flag = True
    _uv_edit_update_guard_generation = int(_uv_edit_update_guard_generation) + 1
    _uv_edit_update_guard_release_pending_generation = 0
    _uv_snapshot_reasons.add('depsgraph_edit_update_guard_pre')


@persistent
def _uv_snapshot_depsgraph_update(_scene, depsgraph):
    global _uv_interaction_dirty, _uv_sel_epoch, _uv_geom_epoch
    _uv_sel_epoch += 1
    try:
        for _upd in depsgraph.updates:
            if _upd.is_updated_geometry or _upd.is_updated_transform:
                _uv_geom_epoch += 1
                break
    except Exception:
        _uv_geom_epoch += 1
    global _uv_edit_update_guard_active_flag, _uv_edit_update_guard_release_pending_generation
    if not bool(getattr(_state, 'runtime_registered', False)) or not _uv_runtime_requested():
        _uv_clear_edit_update_guard()
        return
    if _uv_edit_update_guard_active():
        _uv_edit_update_guard_release_pending_generation = int(_uv_edit_update_guard_generation or 0)
        _uv_interaction_dirty = True
        _uv_snapshot_reasons.add('depsgraph_edit_update_guard_post')
        request_uv_snapshot_rebuild('depsgraph_edit_update_guard_post', context=getattr(bpy, 'context', None), immediate=False)
        return
    relevant = False
    for update in tuple(getattr(depsgraph, 'updates', ()) or ()):
        try:
            ident = str(getattr(getattr(getattr(update, 'id', None), 'bl_rna', None), 'identifier', '') or '')
        except Exception:
            ident = ''
        if ident in {'Object', 'Mesh', 'Scene'}:
            relevant = True
            break
    if relevant:
        # Blender can emit a dense depsgraph burst for one UV select/box-select
        # gesture.  Keep the last completed snapshot passive during the owned
        # interaction and fold all selection notifications into the one RELEASE
        # refresh below.  Outside an interaction the existing finite refresh is
        # unchanged.
        if (_uv_input_or_transform_active(getattr(bpy, 'context', None))
                or _uv_interaction_suppression_active(getattr(bpy, 'context', None))):
            _uv_interaction_dirty = True
            _uv_snapshot_reasons.add('depsgraph_interaction_dirty')
            # A real button PRESS already owns a pending interaction_begin job
            # that RELEASE will complete.  External/EXEC UV operators may have
            # no daemon PRESS/RELEASE pair, so arm one finite settle job without
            # reading BMesh or publishing during the active guard.
            if _uv_interaction_suppression_requested:
                _uv_arm_interaction_suppression()
            else:
                request_uv_snapshot_rebuild(
                    'depsgraph_interaction_settle',
                    context=getattr(bpy, 'context', None),
                    immediate=False,
                )
            return
        _invalidate_uv_hover_cache()
        request_uv_snapshot_rebuild('depsgraph', context=getattr(bpy, 'context', None), immediate=False)


def _register_uv_snapshot_handlers():
    global _uv_snapshot_handlers_registered
    for collection, callback in (
        (bpy.app.handlers.load_pre, _uv_snapshot_load_pre),
        (bpy.app.handlers.load_post, _uv_snapshot_load_post),
        (bpy.app.handlers.undo_post, _uv_snapshot_undo_post),
        (bpy.app.handlers.redo_post, _uv_snapshot_redo_post),
        (bpy.app.handlers.depsgraph_update_pre, _uv_snapshot_depsgraph_update_pre),
        (bpy.app.handlers.depsgraph_update_post, _uv_snapshot_depsgraph_update),
    ):
        if callback not in collection:
            collection.append(callback)
    _uv_snapshot_handlers_registered = True


def _unregister_uv_snapshot_handlers():
    global _uv_snapshot_handlers_registered
    for collection, callback in (
        (bpy.app.handlers.load_pre, _uv_snapshot_load_pre),
        (bpy.app.handlers.load_post, _uv_snapshot_load_post),
        (bpy.app.handlers.undo_post, _uv_snapshot_undo_post),
        (bpy.app.handlers.redo_post, _uv_snapshot_redo_post),
        (bpy.app.handlers.depsgraph_update_pre, _uv_snapshot_depsgraph_update_pre),
        (bpy.app.handlers.depsgraph_update_post, _uv_snapshot_depsgraph_update),
    ):
        try:
            while callback in collection:
                collection.remove(callback)
        except Exception:
            pass
    _uv_snapshot_handlers_registered = False


# -----------------------------------------------------------------------------
# Draw handler (POST_PIXEL)
# -----------------------------------------------------------------------------
def _draw_uv_hover_impl():
    context = bpy.context
    if not _uv_runtime_requested(context):
        return
    if not _state.is_running:
        _uv_reactivate_runtime_state()
    # During mouse-driven UV selection/transform the overlay is strictly passive:
    # it must not rebuild BMesh-driven caches or draw helper elements from stale
    # pre-transform data.  The draw handler stays installed, but live UV helpers
    # are hidden until the user releases the drag.
    suppress_live_helpers = bool(
        _uv_input_or_transform_active(context)
        or _uv_interaction_suppression_active(context)
    )
    suppress_hover = bool(suppress_live_helpers)
    if suppress_live_helpers:
        # Absolute non-interference rule: while Blender is selecting/dragging/
        # transforming UVs, do not touch edit BMesh.  Keep the draw handler alive
        # and skip live helper drawing for this frame only.
        pass

    reg = getattr(context, "region", None)
    if not reg or getattr(reg, "type", "") != 'WINDOW':
        try:
            override = _first_image_editor_context(context)
            if override is not None:
                _ctx, _window, _screen, _area, reg = override
        except Exception:
            reg = None
    if not reg or getattr(reg, "type", "") != 'WINDOW':
        return

    # SpaceImageEditor POST_PIXEL handlers are shared by the UV Editor and the
    # ordinary Image Editor.  Draw only for actual UV Editor areas, otherwise a
    # normal Image Editor can consume/clear the hover state before the UV Editor
    # receives its pass.
    if _uv_editor_area_for_region(context, reg) is None:
        return

    prefs = mesh._prefs(context)
    if not prefs:
        return
    coords = None
    if suppress_live_helpers:
        draw_cache = getattr(_state, 'uv_hover_cache', None) if isinstance(getattr(_state, 'uv_hover_cache', None), dict) else None
    else:
        coords = _window_event_mouse_coords(context) or _last_window_mouse_valid(max_age=60.0, context=context)
        if coords is not None:
            _store_last_window_mouse(context, int(coords[0]), int(coords[1]), image_event=True)
        # One draw pass must do at most one cache validation and one hover query.
        # 1.2.186 routed draw-time refresh through _process_mouse_move() and then
        # queried the same cache again, effectively doubling object scans, cache
        # checks, and hit tests on dense UV editors.  The draw handler now performs
        # the read-only query directly from the cached spatial index.
        external_changed = _uv_invalidate_hover_caches_for_external_change(context)
        draw_cache = _get_uv_hover_cache(context, reg, prefs, force=bool(external_changed)) if coords is not None else getattr(_state, 'uv_hover_cache', None)
        if not isinstance(draw_cache, dict):
            draw_cache = None

    local_hover_type = str(getattr(_state, 'hover_type', 'NONE') or 'NONE')
    local_hover_uvs = list(getattr(_state, 'hover_uvs', []) or [])
    local_hover_vert_indices = list(getattr(_state, 'hover_vert_indices', []) or [])
    local_hover_edge_indices = list(getattr(_state, 'hover_edge_indices', []) or [])
    local_hover_face_indices = list(getattr(_state, 'hover_face_indices', []) or [])
    local_hover_obj_key = int(getattr(_state, 'hover_obj_key', 0) or 0)
    local_hover_obj_name = str(getattr(_state, 'hover_obj_name', '') or '')
    local_hover_sources = list(getattr(_state, 'hover_sources', []) or [])
    coords_inside_region = False
    try:
        if coords is not None:
            rx_now = int(coords[0]) - int(getattr(reg, 'x', 0) or 0)
            ry_now = int(coords[1]) - int(getattr(reg, 'y', 0) or 0)
            coords_inside_region = (
                0 <= rx_now < int(getattr(reg, 'width', 0) or 0)
                and 0 <= ry_now < int(getattr(reg, 'height', 0) or 0)
            )
        region_is_hover_target = bool(coords_inside_region or (
            _uv_snapshot_pointer(getattr(context, 'window', None)) == int(getattr(_state, 'target_window_ptr', 0) or 0)
            and _uv_snapshot_pointer(reg) == int(getattr(_state, 'target_region_ptr', 0) or 0)
        ))
        if coords_inside_region:
            _state.target_window_ptr = _uv_snapshot_pointer(getattr(context, 'window', None))
            _state.target_region_ptr = _uv_snapshot_pointer(reg)
    except Exception:
        region_is_hover_target = False
    if not region_is_hover_target:
        coords = None
        local_hover_type = 'NONE'
        local_hover_uvs = []
        local_hover_vert_indices = []
        local_hover_edge_indices = []
        local_hover_face_indices = []
        local_hover_obj_key = 0
        local_hover_obj_name = ''
        local_hover_sources = []

    # Draw-time hit test: relying only on the stored hover state is fragile in the
    # UV Editor because SpaceImageEditor redraws can arrive without a matching
    # modal mouse event, and another Image Editor pass can clear the state.  Query
    # the already-built UV cache against this exact UV Editor WINDOW region and
    # use that result for the current frame.  This is read-only and uses the same
    # cache as normal hover processing.
    if not suppress_hover and isinstance(draw_cache, dict) and coords is not None:
        try:
            rx = int(coords[0]) - int(getattr(reg, 'x', 0) or 0)
            ry = int(coords[1]) - int(getattr(reg, 'y', 0) or 0)
            if 0 <= rx <= int(getattr(reg, 'width', 0) or 0) and 0 <= ry <= int(getattr(reg, 'height', 0) or 0):
                direct = _query_uv_hover_cache_cached(draw_cache, rx, ry, reg)
                if isinstance(direct, dict) and str(direct.get('hover_type', 'NONE') or 'NONE') != 'NONE' and bool(direct.get('hover_uvs')):
                    local_hover_type = str(direct.get('hover_type', 'NONE') or 'NONE')
                    local_hover_uvs = list(direct.get('hover_uvs') or [])
                    try:
                        _state.hover_type = local_hover_type
                        _state.hover_uvs = list(local_hover_uvs)
                        _state.hover_obj_key = int(direct.get('hover_obj_key', 0) or 0)
                        _state.hover_obj_name = str(direct.get('hover_obj_name', '') or '')
                        _state.hover_vert_indices = list(direct.get('hover_vert_indices') or [])
                        _state.hover_edge_indices = list(direct.get('hover_edge_indices') or [])
                        _state.hover_face_indices = list(direct.get('hover_face_indices') or [])
                        _state.hover_sources = list(direct.get('hover_sources') or [])
                        _state.raw_hover_type = str(direct.get('raw_hover_type', local_hover_type) or local_hover_type)
                        _state.raw_hover_uvs = list(direct.get('raw_hover_uvs') or local_hover_uvs)
                        _state.raw_hover_vert_indices = list(direct.get('raw_hover_vert_indices') or [])
                        _state.raw_hover_edge_indices = list(direct.get('raw_hover_edge_indices') or [])
                        _state.raw_hover_face_indices = list(direct.get('raw_hover_face_indices') or [])
                        _state.raw_hover_obj_key = int(direct.get('raw_hover_obj_key', 0) or 0)
                        _state.raw_hover_obj_name = str(direct.get('raw_hover_obj_name', '') or '')
                        local_hover_obj_key = int(direct.get('hover_obj_key', 0) or 0)
                        local_hover_obj_name = str(direct.get('hover_obj_name', '') or '')
                        local_hover_vert_indices = list(direct.get('hover_vert_indices') or [])
                        local_hover_edge_indices = list(direct.get('hover_edge_indices') or [])
                        local_hover_face_indices = list(direct.get('hover_face_indices') or [])
                        local_hover_sources = list(direct.get('hover_sources') or [])
                        _state.mouse_px = (rx, ry)
                        _state.target_region_ptr = int(reg.as_pointer())
                    except Exception:
                        pass
                elif isinstance(direct, dict):
                    local_hover_type = 'NONE'
                    local_hover_uvs = []
                    local_hover_vert_indices = []
                    local_hover_edge_indices = []
                    local_hover_face_indices = []
                    local_hover_obj_key = 0
                    local_hover_obj_name = ''
                    local_hover_sources = []
                    try:
                        _state.hover_type = 'NONE'
                        _state.hover_uvs = []
                        _state.hover_vert_indices = []
                        _state.hover_edge_indices = []
                        _state.hover_face_indices = []
                        _state.hover_obj_key = 0
                        _state.hover_obj_name = ''
                        _state.hover_sources = []
                        _state.raw_hover_type = 'NONE'
                        _state.raw_hover_uvs = []
                        _state.raw_hover_vert_indices = []
                        _state.raw_hover_edge_indices = []
                        _state.raw_hover_face_indices = []
                    except Exception:
                        pass
        except Exception:
            pass

    has_hover = (not suppress_hover and local_hover_type != 'NONE' and bool(local_hover_uvs))

    # Respect prefs toggles for the hover target.  The same-mesh UV helper can
    # still draw even when no element is currently hovered.
    if has_hover and local_hover_type == 'VERTEX' and not getattr(prefs, "show_hov_uv_verts", True):
        has_hover = False
    if has_hover and local_hover_type == 'EDGE' and not getattr(prefs, "show_hov_uv_edges", True):
        has_hover = False
    if has_hover and local_hover_type == 'FACE' and not getattr(prefs, "show_hov_uv_faces", True):
        has_hover = False

    # Convert UV -> region pixels at current zoom/pan.
    draw_pxs = []
    v2d = getattr(reg, "view2d", None)
    if not v2d:
        return

    if has_hover:
        for uv in local_hover_uvs:
            px = _uv_to_region_px(reg, uv[0], uv[1])
            if px is None:
                has_hover = False
                draw_pxs = []
                break
            draw_pxs.append((float(px[0]), float(px[1])))


    # Colors + sizes from 3D overlay prefs (synced).  UV hover opacity is
    # intentionally independent from Mesh and Curve Overlay Face Opacity.  Vertex/edge
    # lines keep their own alpha control, while the face fill uses the UV face
    # opacity control so changing Mesh and Curve Overlay opacity never changes UV hover.
    def _clamp_alpha(value, fallback=1.0):
        try:
            f = float(value)
        except Exception:
            f = float(fallback)
        return 0.0 if f < 0.0 else (1.0 if f > 1.0 else f)

    uv_ve_alpha = _clamp_alpha(getattr(prefs, "hover_uv_vertex_edge_opacity", 1.0), 1.0)
    face_a = _clamp_alpha(getattr(prefs, "hover_uv_face_opacity", getattr(prefs, "opacity", 0.25)), getattr(prefs, "opacity", 0.25))
    col_v = tuple(getattr(prefs, "hover_uv_vertex_color", (1.0, 0.78, 0.02))) + (uv_ve_alpha,)
    col_e = tuple(getattr(prefs, "hover_uv_edge_color", (1.0, 0.78, 0.02))) + (uv_ve_alpha,)
    col_f_outline = tuple(getattr(prefs, "hover_uv_face_color", (1.0, 0.78, 0.02))) + (uv_ve_alpha,)

    # Fill uses UV face hover color too (requested).
    col_f_fill = tuple(getattr(prefs, "hover_uv_face_color", (1.0, 0.78, 0.02))) + (face_a,)

    # Match 3D overlay sizes (3D uses pixel-ish sizes; we convert to half-width for quad math)
    v_size = float(getattr(prefs, "vertex_size", 4.0))
    e_size = float(getattr(prefs, "edge_size", 2.0))
    v_half = max(1.0, v_size * 0.5)
    e_half = max(0.5, e_size * 0.5)
    outline_half = max(0.5, e_half * 0.75)

    aa_mode = getattr(prefs, "edge_aa_mode", "AA_2PASS") or "AA_2PASS"
    use_2pass = (aa_mode == "AA_2PASS")

    def _get_shader():
        for nm in ("UNIFORM_COLOR", "2D_UNIFORM_COLOR"):
            try:
                return _uv_shader_from_builtin(nm)
            except Exception:
                pass
        return None

    def _draw_quad(shader, quad_pts, color):
        batch = batch_for_shader(shader, 'TRIS', {"pos": quad_pts}, indices=[(0, 1, 2), (1, 3, 2)])
        shader.bind()
        shader.uniform_float("color", color)
        batch.draw(shader)

    def _draw_quads(shader, quads, color):
        try:
            if not quads:
                return False
            positions = []
            indices = []
            for q in quads:
                if not q or len(q) < 4:
                    continue
                base = len(positions)
                positions.extend(q[:4])
                indices.append((base, base + 1, base + 2))
                indices.append((base + 1, base + 3, base + 2))
            if not positions:
                return False
            batch = batch_for_shader(shader, 'TRIS', {"pos": positions}, indices=indices)
            shader.bind()
            shader.uniform_float("color", color)
            batch.draw(shader)
            return True
        except Exception:
            return False

    def _draw_line_quad(shader, p1, p2, half_thickness, color):
        quad = _edge_to_quad(p1, p2, half_thickness)
        if quad:
            _draw_quad(shader, quad, color)

    def _draw_square(shader, cx, cy, half_size, color):
        quad = [(cx - half_size, cy - half_size), (cx + half_size, cy - half_size),
                (cx - half_size, cy + half_size), (cx + half_size, cy + half_size)]
        _draw_quad(shader, quad, color)

    gpu.state.blend_set('ALPHA')
    try:
        shader = _get_shader()
        if shader is None:
            return

        # Draw same-mesh unselected UV helper first; the actual hover target stays
        # on top when both are present. During active drags/transforms it uses
        # only the short-lived draw snapshot, never live BMesh.
        hover_payload = {
            'hover_type': local_hover_type,
            'hover_uvs': local_hover_uvs,
            'hover_vert_indices': local_hover_vert_indices,
            'hover_edge_indices': local_hover_edge_indices,
            'hover_face_indices': local_hover_face_indices,
            'hover_obj_key': int(local_hover_obj_key or 0),
            'hover_obj_name': str(local_hover_obj_name or ''),
            'hover_sources': list(local_hover_sources or []),
        }
        same_drawn = _draw_uv_same_mesh_selection_overlay(
            context, reg, prefs, shader, _draw_quad, _draw_line_quad, _draw_square,
            draw_cache, allow_live=not suppress_live_helpers, hover_payload=hover_payload,
            draw_quads_func=_draw_quads,
        )
        try:
            bpy.app.driver_namespace['SOS_UV_OVERLAY_LAST_DRAW'] = {
                'time': time.time(),
                'same_mesh': bool(same_drawn),
                'hover_type': str(local_hover_type),
                'hover_count': len(local_hover_uvs),
                'hover_source_count': len(local_hover_sources or []),
                'hover_sources': [(int(src.get('hover_obj_key', 0) or 0), str(src.get('hover_obj_name', '') or ''), str(src.get('hover_type', '') or '')) for src in (local_hover_sources or []) if isinstance(src, dict)],
                'hover_obj_key': int(local_hover_obj_key or 0),
                'hover_obj_name': str(local_hover_obj_name or ''),
                'object_count': int(draw_cache.get('object_count', 0) if isinstance(draw_cache, dict) else 0),
                'objects': tuple(draw_cache.get('objects') or ()) if isinstance(draw_cache, dict) else (),
                'window_ptr': _uv_snapshot_pointer(getattr(context, 'window', None)),
                'region_ptr': _uv_snapshot_pointer(reg),
                'region': (int(getattr(reg, 'x', 0) or 0), int(getattr(reg, 'y', 0) or 0), int(getattr(reg, 'width', 0) or 0), int(getattr(reg, 'height', 0) or 0)),
            }
        except Exception:
            pass

        if not has_hover:
            return

        fast_uv_transform = _uv_region_affine_transform(reg)

        def _source_to_pixels(src_type, src_uvs):
            pts = []
            try:
                for uv in src_uvs or ():
                    px = _uv_to_region_px_fast(reg, fast_uv_transform, uv[0], uv[1])
                    if px is None or not _uv_region_point_is_valid(px):
                        return []
                    pts.append((float(px[0]), float(px[1])))
            except Exception:
                return []
            return pts

        def _draw_hover_source(src_type, src_uvs):
            pts = _source_to_pixels(src_type, src_uvs)
            if not pts:
                return False
            if src_type == 'VERTEX':
                vx, vy = pts[0]
                if use_2pass:
                    outer = (col_v[0], col_v[1], col_v[2], col_v[3] * 0.35)
                    _draw_square(shader, vx, vy, v_half + 1.0, outer)
                _draw_square(shader, vx, vy, v_half, col_v)
                return True
            if src_type == 'EDGE' and len(pts) >= 2:
                p1, p2 = pts[0], pts[1]
                if use_2pass:
                    outer = (col_e[0], col_e[1], col_e[2], col_e[3] * 0.35)
                    _draw_line_quad(shader, p1, p2, e_half + 1.0, outer)
                _draw_line_quad(shader, p1, p2, e_half, col_e)
                return True
            if src_type == 'FACE' and len(pts) >= 3:
                indices = [(0, i, i + 1) for i in range(1, len(pts) - 1)]
                batch_fill = batch_for_shader(shader, 'TRIS', {"pos": pts}, indices=indices)
                shader.bind()
                shader.uniform_float("color", col_f_fill)
                batch_fill.draw(shader)
                for i in range(len(pts)):
                    p1, p2 = pts[i], pts[(i + 1) % len(pts)]
                    if use_2pass:
                        outer = (col_f_outline[0], col_f_outline[1], col_f_outline[2], col_f_outline[3] * 0.35)
                        _draw_line_quad(shader, p1, p2, outline_half + 1.0, outer)
                    _draw_line_quad(shader, p1, p2, outline_half, col_f_outline)
                return True
            return False

        # Draw the primary hover and every coincident multi-object hover source.
        # This is needed when multiple edit objects have stacked UVs: drawing only
        # the active/first result makes the hover overlay appear missing on one of
        # the edited objects even though both are visible in the UV Editor.
        hover_sources = [src for src in (local_hover_sources or []) if isinstance(src, dict)]
        if not hover_sources:
            hover_sources = [{
                'hover_type': local_hover_type,
                'hover_uvs': local_hover_uvs,
                'hover_obj_key': int(local_hover_obj_key or 0),
                'hover_obj_name': str(local_hover_obj_name or ''),
            }]
        seen_drawn = set()
        for src in hover_sources:
            src_type = str(src.get('hover_type', local_hover_type) or local_hover_type)
            if src_type == 'VERTEX' and not getattr(prefs, "show_hov_uv_verts", True):
                continue
            if src_type == 'EDGE' and not getattr(prefs, "show_hov_uv_edges", True):
                continue
            if src_type == 'FACE' and not getattr(prefs, "show_hov_uv_faces", True):
                continue
            src_uvs = list(src.get('hover_uvs') or [])
            src_key = (int(src.get('hover_obj_key', 0) or 0), src_type, tuple((round(float(u), 6), round(float(v), 6)) for u, v in src_uvs if u is not None and v is not None))
            if src_key in seen_drawn:
                continue
            seen_drawn.add(src_key)
            _draw_hover_source(src_type, src_uvs)
    finally:
        try:
            _state.last_successful_draw_time = time.time()
            _state.last_draw_region_ptr = int(reg.as_pointer()) if reg is not None else 0
        except Exception:
            pass
        try:
            mesh._sos_reset_gpu_state_after_draw()
        except Exception:
            pass


def _draw_uv_hover():
    """Replay the latest immutable UV snapshot in the owning UV Editor context."""
    if _uv_edit_update_guard_active():
        return None
    _state.last_draw_time = time.time()
    ctx = getattr(bpy, 'context', None)
    if ctx is None:
        return None

    area = getattr(ctx, 'area', None)
    region = getattr(ctx, 'region', None)

    # A SpaceImageEditor callback may arrive with a foreign/empty Python context.
    # Resolve the exact live UV editor owner.  Do not redirect an actual ordinary
    # Image Editor pass into a different UV area, because SpaceImageEditor handlers
    # are shared by both editor subtypes.
    target = _uv_editor_target_for_region(ctx, region=region, area=area)
    if not isinstance(target, dict):
        if getattr(area, 'type', None) == 'IMAGE_EDITOR':
            return None
        target = next(iter(_uv_iter_live_editor_targets(ctx) or ()), None)
    if not isinstance(target, dict):
        return None

    target_region = target.get('region')
    target_area = target.get('area')
    if getattr(target_region, 'type', None) != 'WINDOW' or not _area_is_uv_editor(target_area):
        return None

    override = {
        'window': target.get('window'),
        'screen': target.get('screen'),
        'area': target_area,
        'region': target_region,
        'space_data': target.get('space_data') or _uv_editor_space_for_area(target_area),
    }
    try:
        view_layer = (
            getattr(ctx, 'view_layer', None)
            or getattr(getattr(bpy, 'context', None), 'view_layer', None)
        )
        if view_layer is not None:
            override['view_layer'] = view_layer
    except Exception:
        pass
    override = {key: value for key, value in override.items() if value is not None}
    try:
        obj = _uv_edit_mesh_object(ctx)
        if obj is not None and getattr(obj, 'type', None) == 'MESH':
            override.update(active_object=obj, object=obj, edit_object=obj)
    except Exception:
        pass

    _sos_gpu_snapshot = None
    _sos_clip_token = None
    try:
        with ctx.temp_override(**override):
            draw_ctx = bpy.context
            # The Smart Tools Manager cell of this UV Editor silences the overlay
            # here; an OFF cell used to hide only the tab while drawing went on.
            if not _uv_manager_editor_cell_allows(draw_ctx):
                return None
            try:
                _sos_gpu_snapshot = mesh._sos_push_gpu_state_restore()
            except Exception:
                _sos_gpu_snapshot = None
            try:
                _sos_clip_token = mesh._sos_begin_post_pixel_ui_region_clip(draw_ctx)
            except Exception:
                _sos_clip_token = None
            return _uv_replay_draw_snapshot(draw_ctx)
    except Exception as ex:
        _state.draw_exception_count = int(getattr(_state, 'draw_exception_count', 0) or 0) + 1
        try:
            _state.last_draw_exception = repr(ex)
        except Exception:
            pass
        try:
            request_uv_snapshot_rebuild('direct_draw_exception', context=ctx, immediate=True)
        except Exception:
            pass
        return None
    finally:
        try:
            mesh._sos_end_post_pixel_ui_region_clip(_sos_clip_token)
        except Exception:
            pass
        try:
            mesh._sos_pop_gpu_state_restore(_sos_gpu_snapshot, ui_safe=True)
        except Exception:
            try:
                mesh._sos_reset_gpu_state_after_draw()
            except Exception:
                pass


# -----------------------------------------------------------------------------
# Modal safety guards
# -----------------------------------------------------------------------------

def _uv_request_prop_snapshot_rebuild(reason, context=None, immediate=False):
    try:
        from . import properties as _sos_properties
        return bool(_sos_properties.request_prop_uv_snapshot_rebuild(
            reason,
            context=context,
            immediate=immediate,
        ))
    except Exception:
        return False


def _sos_uv_modal_context_is_safe(context) -> bool:
    """Return True only when passive UV overlay polling may read UI context."""
    try:
        if context is None or getattr(context, 'window', None) is None:
            return False
        scene = getattr(context, 'scene', None)
        if scene is None:
            return False
        obj = getattr(context, 'object', None)
        if obj is not None:
            mode = str(getattr(obj, 'mode', '') or '')
            if mode not in {'OBJECT', 'EDIT', 'EDIT_MESH', 'SCULPT', 'PAINT_TEXTURE', 'PAINT_VERTEX', 'PAINT_WEIGHT'}:
                return False
            if mode in {'EDIT', 'EDIT_MESH'} and getattr(obj, 'type', None) != 'MESH':
                return False
    except Exception:
        return False
    return True


class SOS_OT_uv_hover_daemon(bpy.types.Operator):
    bl_idname = "sos.uv_hover_daemon"
    bl_label = "Smart Overlay UV Hover Mouse Probe"
    bl_description = "Internal lightweight UV hover mouse probe. It stores mouse coordinates for UV overlay drawing and passes all events through."
    bl_options = {'INTERNAL'}

    @classmethod
    def poll(cls, context):
        try:
            return bool(_uv_runtime_requested(context) and _first_image_editor_context(context) is not None)
        except Exception:
            return False

    def execute(self, context):
        # Some Blender builds route internal operator starts through EXEC when no
        # explicit event object is available.  Start the same coordinate-only
        # pass-through modal path so UV hover still has mouse coordinates.
        return self.invoke(context, None)

    def invoke(self, context, event):
        try:
            self._sos_uv_generation = int(getattr(_state, 'modal_generation', 0) or 0)
            self._sos_uv_started_at = time.time()
            self._sos_uv_window_ptr = _uv_snapshot_pointer(getattr(context, 'window', None))
            refs = getattr(_state, 'operator_refs', None)
            if not isinstance(refs, dict):
                refs = {}
                _state.operator_refs = refs
            refs[int(self._sos_uv_window_ptr)] = self
            if getattr(_state, 'operator_ref', None) is None:
                _state.operator_ref = self
            _state.is_running = True
            if event is not None and hasattr(event, 'mouse_x') and hasattr(event, 'mouse_y'):
                self._store_event_mouse(context, event)
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        except Exception:
            try:
                refs = getattr(_state, 'operator_refs', {})
                if isinstance(refs, dict):
                    refs.pop(int(getattr(self, '_sos_uv_window_ptr', 0) or 0), None)
                if getattr(_state, 'operator_ref', None) is self:
                    _state.operator_ref = None
            except Exception:
                pass
            return {'CANCELLED'}

    def _finish(self):
        try:
            refs = getattr(_state, 'operator_refs', None)
            if isinstance(refs, dict):
                key = int(getattr(self, '_sos_uv_window_ptr', 0) or 0)
                if refs.get(key) is self:
                    refs.pop(key, None)
            if getattr(_state, 'operator_ref', None) is self:
                replacement = next(iter(refs.values()), None) if isinstance(refs, dict) else None
                _state.operator_ref = replacement
        except Exception:
            pass
        return {'FINISHED'}

    def _store_event_mouse(self, context, event):
        global _uv_interaction_dirty
        try:
            mx = int(getattr(event, 'mouse_x', -100000))
            my = int(getattr(event, 'mouse_y', -100000))
        except Exception:
            return False
        try:
            previous_mouse = tuple(getattr(_state, 'last_timer_mouse_px', (-100000, -100000)) or (-100000, -100000))
            previous_region_ptr = int(getattr(_state, 'last_timer_mouse_region_ptr', 0) or 0)
            area, region = _event_image_editor_area_region(context, event)
            is_uv = bool(region is not None and _area_is_uv_editor(area))
            if is_uv:
                _store_last_window_mouse(context, mx, my, image_event=True)
                try:
                    reg_ptr = int(region.as_pointer())
                except Exception:
                    reg_ptr = 0
                _state.last_timer_mouse_px = (mx, my)
                _state.last_timer_mouse_region_ptr = reg_ptr
                target_changed = bool(previous_region_ptr != reg_ptr)
                mouse_changed = bool(previous_mouse != (mx, my))
                try:
                    setattr(getattr(context, 'window_manager', None), 'sos_uv_mouse_x', mx)
                    setattr(getattr(context, 'window_manager', None), 'sos_uv_mouse_y', my)
                except Exception:
                    pass
                # BMesh/cache work is event-side.  The draw handler only replays the
                # completed GPU snapshot produced by the finite coalesced job.
                hover_changed = False
                interaction_active = bool(
                    _uv_input_or_transform_active(context)
                    or _uv_interaction_suppression_active(context)
                )
                if interaction_active:
                    _uv_interaction_dirty = True
                    _uv_snapshot_reasons.add('mouse_interaction_dirty')
                    # Only a real button PRESS owns the suppression latch.  A
                    # short post-operator safety guard can also make
                    # _uv_input_or_transform_active() true, but there may be no
                    # later RELEASE event for that already-finished operator.
                    # Arm one finite settle job without converting that guard
                    # into a permanent input latch.
                    if _uv_interaction_suppression_requested:
                        _uv_arm_interaction_suppression()
                    else:
                        request_uv_snapshot_rebuild('interaction_guard_settle', context=context, immediate=False)
                else:
                    try:
                        hover_changed = bool(_process_mouse_move(context, mx, my, force=False, tag_redraw=False))
                    except Exception:
                        hover_changed = False
                    if hover_changed or target_changed:
                        request_uv_snapshot_rebuild('mouse_move_changed', context=context, immediate=False)
                if (hover_changed or target_changed or mouse_changed) and _uv_probe_should_tag_redraw(region, mx, my):
                    try:
                        region.tag_redraw()
                    except Exception:
                        pass
                return True
            _store_last_window_mouse(context, mx, my, image_event=False)
            if region is not None or getattr(_state, 'hover_type', 'NONE') != 'NONE' or getattr(_state, 'hover_uvs', ()):
                _clear_hover_state(context, redraw=True)
            return False
        except Exception:
            return False

    def modal(self, context, event):
        global _uv_interaction_dirty
        try:
            if int(getattr(self, '_sos_uv_generation', 0) or 0) != int(getattr(_state, 'modal_generation', 0) or 0):
                return self._finish()
            if not _uv_runtime_requested(context):
                return self._finish()
            etype = str(getattr(event, 'type', '') or '')
            value = str(getattr(event, 'value', '') or '')
            if etype in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
                self._store_event_mouse(context, event)
                _uv_request_prop_snapshot_rebuild('uv_modal_move', context=context, immediate=True)
            elif etype in {'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'TRACKPADPAN', 'TRACKPADZOOM', 'NDOF_MOTION'}:
                request_uv_snapshot_rebuild('view_navigation', context=context, immediate=False)
                _uv_request_prop_snapshot_rebuild('uv_modal_wheel', context=context, immediate=True)
            elif etype in {'G', 'R', 'S'} and value == 'PRESS':
                _uv_request_prop_snapshot_rebuild('uv_transform_begin', context=context, immediate=True)
            elif etype in {'ESC', 'RET', 'NUMPAD_ENTER', 'SPACE'} and value == 'PRESS':
                _uv_clear_interaction_suppression()
                request_uv_snapshot_rebuild('interaction_terminal', context=context, immediate=False)
                _uv_request_prop_snapshot_rebuild('uv_transform_terminal', context=context, immediate=False)
            elif etype in {'MIDDLEMOUSE', 'LEFTMOUSE', 'RIGHTMOUSE'} and value == 'PRESS':
                if not _uv_interaction_suppression_requested:
                    _uv_arm_interaction_suppression()
                    request_uv_snapshot_rebuild('interaction_begin', context=context, immediate=False)
                _uv_request_prop_snapshot_rebuild('uv_button_press', context=context, immediate=False)
            elif etype in {'MIDDLEMOUSE', 'LEFTMOUSE', 'RIGHTMOUSE'} and value in {'RELEASE', 'CLICK'}:
                _uv_clear_interaction_suppression()
                request_uv_snapshot_rebuild('interaction_release', context=context, immediate=False)
                _uv_request_prop_snapshot_rebuild('uv_button_terminal', context=context, immediate=True)
            elif etype == 'WINDOW_DEACTIVATE':
                _uv_clear_interaction_suppression()
                _clear_hover_state(context, redraw=True)
                request_uv_snapshot_rebuild('window_deactivate', context=context, immediate=False)
                _uv_request_prop_snapshot_rebuild('uv_window_deactivate', context=context, immediate=False)
            return {'PASS_THROUGH'}
        except Exception:
            try:
                _state.modal_exception_count = int(getattr(_state, 'modal_exception_count', 0) or 0) + 1
            except Exception:
                pass
            return {'PASS_THROUGH'}





def _uv_passive_mouse_redraw_tick(context=None) -> bool:
    """Poll mouse position and tag UV editor redraw without reading or writing UV data.

    Without an automatic keymap or modal event probe Blender may not redraw the UV
    editor on every mouse move.  This lightweight tick only stores coordinates and
    tags the Image Editor WINDOW region.  The actual BMesh hit test remains inside
    the draw handler and is still blocked during UV transforms/drags.
    """
    try:
        ctx = context or bpy.context
        if not _uv_runtime_requested(ctx):
            return False
        now = time.time()
        coords = _window_event_mouse_coords(ctx)
        if coords is None:
            # No mouse coordinate source means there is no reliable hover target.
            # Do not wake every Image/UV editor just to rediscover that state.
            return False
        mx, my = int(coords[0]), int(coords[1])
        area, region = _window_region_under_mouse(ctx, mx, my, {'IMAGE_EDITOR'})
        if region is None or not _area_is_uv_editor(area):
            # Mouse left the UV editor, or is over a plain Image Editor.  Clearing
            # visual state is safe because it does not access edit data; tag once so
            # stale hover color disappears.
            had_hover = bool(getattr(_state, 'hover_type', 'NONE') != 'NONE' or getattr(_state, 'hover_uvs', ()))
            if had_hover:
                _clear_hover_state(ctx, redraw=True)
            _state.last_timer_mouse_region_ptr = 0
            _state.last_timer_mouse_px = (mx, my)
            return False
        try:
            reg_ptr = int(region.as_pointer())
        except Exception:
            reg_ptr = 0
        prev = getattr(_state, 'last_timer_mouse_px', (-100000, -100000))
        prev_reg = int(getattr(_state, 'last_timer_mouse_region_ptr', 0) or 0)
        changed = (int(prev[0]) != mx or int(prev[1]) != my or prev_reg != reg_ptr)
        _store_last_window_mouse(ctx, mx, my, image_event=True)
        _state.last_timer_mouse_px = (mx, my)
        _state.last_timer_mouse_region_ptr = reg_ptr
        # Keep redraws throttled.  This does not rebuild caches from the timer; it
        # only lets POST_PIXEL run so hover can update visually.
        if changed or (now - float(getattr(_state, 'last_timer_mouse_redraw_time', 0.0) or 0.0)) > 0.35:
            _state.last_timer_mouse_redraw_time = now
            if changed:
                request_uv_snapshot_rebuild('passive_mouse_move', context=ctx, immediate=False)
            try:
                region.tag_redraw()
            except Exception:
                try:
                    area.tag_redraw()
                except Exception:
                    pass
            return True
    except Exception:
        pass
    return False


# -----------------------------------------------------------------------------
# Self-respawn timer (same idea)
# -----------------------------------------------------------------------------
def _ensure_uv_daemon_running():
    """Finite compatibility repair used only from explicit events."""
    _kill_legacy_uv_modal_runtime()
    if not bool(getattr(_state, 'runtime_registered', False)):
        return None
    _uv_reactivate_runtime_state()
    _uv_install_draw_handler_if_needed(force=False)
    _uv_start_modal_tracker_if_needed(getattr(bpy, 'context', None), force=False)
    request_uv_snapshot_rebuild('runtime_repair', context=getattr(bpy, 'context', None), immediate=True)
    return None


def _uv_runtime_watchdog_timer():
    if not bool(getattr(_state, 'runtime_registered', False)):
        return None
    try:
        context = getattr(bpy, 'context', None)
        _uv_install_draw_handler_if_needed(force=False)
        _register_uv_snapshot_handlers()
        _uv_start_modal_tracker_if_needed(context, force=False)
        _uv_passive_mouse_redraw_tick(context)
        needs_rebuild = False
        for override in tuple(_uv_iter_editor_overrides(context) or ()):
            try:
                with bpy.context.temp_override(**override):
                    key = _uv_snapshot_key(bpy.context)
                    if key is None:
                        continue
                    record = _uv_draw_snapshots.get(key)
                    if not isinstance(record, dict):
                        needs_rebuild = True
                        break
                    if _uv_snapshot_record_unusable(record):
                        needs_rebuild = True
                        break
            except Exception:
                needs_rebuild = True
                break
        if needs_rebuild:
            request_uv_snapshot_rebuild('runtime_watchdog', context=context, immediate=True)
    except Exception:
        pass
    return 0.25


def _uv_start_runtime_watchdog():
    try:
        if bpy.app.timers.is_registered(_uv_runtime_watchdog_timer):
            return
    except Exception:
        pass
    try:
        if bool(getattr(_state, 'runtime_registered', False)):  # 常駐が有効な時だけ見張りの時計を入れる
            bpy.app.timers.register(_uv_runtime_watchdog_timer, first_interval=0.1, persistent=True)
    except TypeError:
        try:
            bpy.app.timers.register(_uv_runtime_watchdog_timer, first_interval=0.1)
        except Exception:
            pass
    except Exception:
        pass

# -----------------------------------------------------------------------------
# Register
# -----------------------------------------------------------------------------
# Register only the lightweight coordinate probe.  It is required for reliable
# UV hover display on systems where passive window mouse coordinates are stale.
# The operator itself ignores every non-mousemove event and always PASS_THROUGHs.
_classes = (SOS_OT_uv_hover_daemon,)
CLASSES = _classes
_SCENE_DAEMON_PROP = "sos_uv_daemon_active"


def _scene_daemon_prop_exists() -> bool:
    return hasattr(bpy.types.Scene, _SCENE_DAEMON_PROP)


def register_scene_properties():
    if _scene_daemon_prop_exists():
        return
    bpy.types.Scene.sos_uv_daemon_active = bpy.props.BoolProperty(
        name="UV Hover Daemon Active",
        description="Internal: keeps UV hover overlay alive",
        default=False,
    )


def _set_daemon_active_for_all_scenes(value: bool):
    if not _scene_daemon_prop_exists():
        return
    for scene in getattr(bpy.data, 'scenes', ()):
        try:
            setattr(scene, _SCENE_DAEMON_PROP, bool(value))
        except Exception:
            continue


def unregister_scene_properties():
    if not _scene_daemon_prop_exists():
        return
    try:
        delattr(bpy.types.Scene, _SCENE_DAEMON_PROP)
    except Exception:
        pass


def register_classes():
    _kill_legacy_uv_modal_runtime()
    # Remove stale class objects from older installed versions before registering
    # the current lightweight mouse-coordinate probe.
    try:
        legacy = getattr(bpy.types, 'SOS_OT_uv_hover_daemon', None)
        if isinstance(legacy, type):
            bpy.utils.unregister_class(legacy)
    except Exception:
        pass
    for c in _classes:
        existing = getattr(bpy.types, getattr(c, '__name__', ''), None)
        if existing is c:
            continue
        if isinstance(existing, type):
            try:
                bpy.utils.unregister_class(existing)
            except Exception:
                pass
        bpy.utils.register_class(c)


def unregister_classes():
    for c in reversed(_classes):
        try:
            bpy.utils.unregister_class(c)
        except Exception:
            pass


def _clear_addon_runtime_state():
    _state.is_running = False
    _state.operator_ref = None
    _state.operator_refs = {}
    _state.is_clicking = False
    _state.clicking_until = 0.0
    _state.hover_type = 'NONE'
    _state.hover_uvs = []
    _state.mouse_px = (-100, -100)
    _state.target_window_ptr = 0
    _state.target_region_ptr = 0
    _state.hover_obj_name = ""
    _state.hover_obj_key = 0
    _state.hover_sources = []
    _state.raw_hover_obj_key = 0
    _state.raw_hover_obj_name = ''
    _state.hover_vert_indices = []
    _state.hover_edge_indices = []
    _state.hover_face_indices = []
    _state.raw_hover_type = 'NONE'
    _state.raw_hover_uvs = []
    _state.raw_hover_vert_indices = []
    _state.raw_hover_edge_indices = []
    _state.raw_hover_face_indices = []
    _state.last_window_mouse_px = (-100000, -100000)
    _state.last_window_mouse_time = 0.0
    _state.last_image_event_time = 0.0
    _state.window_mouse_px_by_ptr = {}
    _state.window_mouse_time_by_ptr = {}
    _state.window_image_event_time_by_ptr = {}
    _state.deferred_refresh_window_ptr = 0
    _state.last_force_process_time = 0.0
    _state.last_mouse_region_px = (-100000, -100000, 0)
    _state.last_mouse_process_time = 0.0
    _state.last_operator_signature = None
    _state.last_interaction_operator_name = ''
    _state.last_input_guard_time = 0.0
    _state.last_uv_context_signature = None
    _state.deferred_refresh_pending = False
    _state.deferred_refresh_mouse_px = (-100000, -100000)
    _state.uv_hover_stale_cache = None
    _state.uv_hover_stale_cache_time = 0.0
    _state.last_successful_draw_time = 0.0
    _state.last_draw_region_ptr = 0
    _state.interaction_guard_until = 0.0
    _state.last_transform_operator_signature = None
    _state.last_guard_operator_signature = None
    _state.last_guard_mouse_px = (-100000, -100000)
    _state.last_transform_guard_name = ''
    _state.last_transform_guard_ptr = 0
    _state.last_transform_guard_reason = ''
    _state.last_modal_operator_names = ()
    _state.bmesh_read_block_count = 0
    _state.last_interaction_operator_name = ''
    _state.last_input_guard_time = 0.0
    _state.last_timer_mouse_px = (-100000, -100000)
    _state.last_timer_mouse_redraw_time = 0.0
    _state.last_timer_mouse_region_ptr = 0
    _state.last_modal_mouse_px = (-100000, -100000)
    _state.last_modal_mouse_redraw_time = 0.0
    _state.last_modal_mouse_region_ptr = 0
    _state.last_external_change_check_time = 0.0
    _state.last_external_change_result = False
    _state.last_fast_query_sig = None
    _state.last_fast_query_result = None
    _state.last_fast_query_time = 0.0
    _state.last_draw_same_mesh_key = None
    _state.last_draw_same_mesh_points = []
    _state.last_draw_same_mesh_edges = []
    _state.last_draw_same_mesh_time = 0.0
    _state.last_os_mouse_probe_time = 0.0
    _state.last_os_mouse_probe_coords = None
    _state.same_mesh_gpu_batch_sig = None
    _state.same_mesh_gpu_batches = None
    _state.hover_gpu_batch_sig = None
    _state.hover_gpu_batches = None
    globals()['_selected_split_vert_indices'].clear()
    globals()['_selected_split_vert_obj_name'] = ""
    globals()['_selected_split_vert_obj_ptr'] = 0
    globals()['_clicked_bridge_vert_indices'].clear()
    globals()['_clicked_bridge_obj_name'] = ""
    globals()['_clicked_bridge_obj_ptr'] = 0
    globals()['_clicked_bridge_keep_until'] = 0.0
    _invalidate_uv_hover_cache()


def register_addon_runtime():
    _kill_legacy_uv_modal_runtime()
    try:
        ns = getattr(bpy.app, 'driver_namespace', None)
        if isinstance(ns, dict):
            ns.pop('SOS_UV_DISABLE_MODAL_MOUSE_PROBE', None)
    except Exception:
        pass
    _state.runtime_registered = True
    _state.runtime_started_at = time.time()
    _invalidate_uv_hover_cache()
    clear_uv_draw_snapshots()
    try:
        _state.draw_exception_count = 0
        _state.modal_generation = int(getattr(_state, 'modal_generation', 0) or 0) + 1
        _state.operator_refs = {}
        _state.operator_ref = None
    except Exception:
        pass
    _set_daemon_active_for_all_scenes(True)
    _uv_reactivate_runtime_state()
    _uv_install_draw_handler_if_needed(force=True)
    _register_uv_snapshot_handlers()
    _uv_start_modal_tracker_if_needed(getattr(bpy, 'context', None), force=True)
    try:
        _tag_uv_image_redraw(getattr(bpy, 'context', None))
    except Exception:
        pass
    request_uv_snapshot_rebuild('runtime_register', context=getattr(bpy, 'context', None), immediate=True)
    _uv_start_runtime_watchdog()


def unregister_addon_runtime():
    _state.runtime_registered = False
    try:
        _state.modal_generation = int(getattr(_state, 'modal_generation', 0) or 0) + 1
        _state.operator_ref = None
        _state.operator_refs = {}
    except Exception:
        pass
    try:
        if bpy.app.timers.is_registered(_ensure_uv_daemon_running):
            bpy.app.timers.unregister(_ensure_uv_daemon_running)
    except Exception:
        pass
    try:
        if bpy.app.timers.is_registered(_uv_runtime_watchdog_timer):
            bpy.app.timers.unregister(_uv_runtime_watchdog_timer)
    except Exception:
        pass
    _unregister_uv_snapshot_handlers()
    clear_uv_draw_snapshots()
    _set_daemon_active_for_all_scenes(False)
    _clear_addon_runtime_state()
    if _state.draw_handle is not None:
        try:
            bpy.types.SpaceImageEditor.draw_handler_remove(_state.draw_handle, 'WINDOW')
        except Exception:
            pass
        _state.draw_handle = None


def register():
    register_scene_properties()
    register_classes()
    register_addon_runtime()


def unregister():
    unregister_addon_runtime()
    unregister_classes()
    unregister_scene_properties()
