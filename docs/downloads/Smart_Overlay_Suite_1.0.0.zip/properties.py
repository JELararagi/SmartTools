# SPDX-License-Identifier: GPL-3.0-or-later
# Blender Extension / user_default compatible package
# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi
#  Official Contact: 
#  Video Tutorials: 
#
#  This file is part of the Smart Overlay Suite package.
#  Licensed under the GNU General Public License v3.0 or later
#  (GPL-3.0-or-later).
# ------------------------------------------------------------------------------

import bpy
import bmesh
import math
import time
import heapq
import gpu
from gpu_extras.batch import batch_for_shader as _gpu_batch_for_shader
from mathutils.kdtree import KDTree
from mathutils import Vector, Matrix
from bpy_extras import view3d_utils

from . import mesh
from bpy.app.handlers import persistent

# View3D proportional-overlay commands are built from explicit events, never in
# a draw callback.  The local wrappers below affect only this module; Blender's
# shared GPU APIs are not monkeypatched.
_prop_capture_commands = None
_prop_capture_state = {}
_prop_capture_uniforms = {}
_prop_view3d_snapshots = {}
_prop_view3d_snapshot_timer_pending = False
_prop_view3d_snapshot_generation = 0
_PROP_VIEW3D_SNAPSHOT_MIN_INTERVAL = 0.02
_prop_uv_snapshots = {}
_PROP_VIEW3D_SNAPSHOT_MAX = 24
_PROP_UV_SNAPSHOT_MAX = 32
_prop_uv_snapshot_generation = 0
_prop_uv_snapshot_request_serial = 0
_prop_uv_snapshot_timer_pending = False
_prop_uv_snapshot_timer_attempts = 0
_prop_uv_snapshot_due = 0.0
_prop_uv_snapshot_reasons = set()
_PROP_UV_SNAPSHOT_MAX_ATTEMPTS = 4
_PROP_UV_SNAPSHOT_MIN_INTERVAL = 0.05
_prop_uv_boundary_handlers_registered = False


def _prop_state_set(name, *values):
    global _prop_capture_state
    if _prop_capture_commands is not None:
        _prop_capture_state[str(name)] = tuple(values)
    setter = getattr(gpu.state, f'{name}_set', None)
    if callable(setter):
        return setter(*values)
    return None


class _PropCapturedBatch:
    __slots__ = ('batch', 'primitive')
    def __init__(self, batch, primitive):
        self.batch = batch
        self.primitive = str(primitive or '')
    def draw(self, shader):
        if _prop_capture_commands is None:
            return self.batch.draw(shader)
        _prop_capture_commands.append({
            'batch': self.batch,
            'shader': shader,
            'primitive': self.primitive,
            'state': dict(_prop_capture_state),
            'uniforms': dict(_prop_capture_uniforms),
        })
        return None
    def __getattr__(self, name):
        return getattr(self.batch, name)


def batch_for_shader(shader, primitive, content, *, indices=None):
    if indices is None:
        batch = _gpu_batch_for_shader(shader, primitive, content)
    else:
        batch = _gpu_batch_for_shader(shader, primitive, content, indices=indices)
    if _prop_capture_commands is None:
        return batch
    return _PropCapturedBatch(batch, primitive)


def _prop_uniform_float(shader, name, value):
    if _prop_capture_commands is not None:
        try:
            frozen = tuple(value) if isinstance(value, (tuple, list)) else value
        except Exception:
            frozen = value
        _prop_capture_uniforms[str(name)] = frozen
    return shader.uniform_float(name, value)


def _prop_uv_native_transform_active(context=None) -> bool:
    """Return True only for Blender's native UV G/S/R modal operators.

    The general UV overlay deliberately blocks every live edit-BMesh read while
    input is owned by a modal tool.  The proportional heatmap has a narrower
    requirement: while Blender itself is flushing a UV translate/rotate/resize,
    it must read the already-flushed coordinates so the display follows the
    transform.  Do not broaden this to selection, unwrap, SmartUV, or arbitrary
    modal operators.
    """
    try:
        from . import uv as _sos_uv
        names = tuple(_sos_uv._uv_active_modal_operator_names(context or bpy.context) or ())
    except Exception:
        return False
    exact = {
        'transform_ot_translate', 'transform_ot_rotate', 'transform_ot_resize',
        'transform.translate', 'transform.rotate', 'transform.resize',
    }
    for name in names:
        text = str(name or '').strip().lower()
        if text in exact:
            return True
    return False


def _prop_uv_may_read_edit_bmesh(context=None) -> bool:
    """Share UV Overlay's display-only safety gate for UV proportional drawing.

    Proportional UV heatmap normally shares the UV overlay safety gate.  The
    only exception is Blender's own native UV G/S/R modal transform, where the
    transform has already flushed current coordinates and the heatmap needs a
    read-only, dirty-driven refresh.  Selection and third-party modals remain
    blocked.
    """
    if _prop_uv_native_transform_active(context):
        return True
    try:
        from . import uv as _sos_uv
        return bool(_sos_uv._uv_may_read_edit_bmesh(context or bpy.context))
    except Exception:
        try:
            if bool(bpy.app.driver_namespace.get('SOS_UV_TEST_TRANSFORM_ACTIVE', False)):
                return False
        except Exception:
            pass
        return True

def _prefs(context=None):
    ctx = context or bpy.context
    try:
        return mesh.get_effective_settings(ctx)
    except Exception:
        return None

# =============================================================================
# Proportional Logic & Cache
# =============================================================================
def get_falloff_intensity(dist: float, radius: float, falloff_type: str) -> float:
    if radius <= 0 or dist > radius: return 0.0
    t = dist / radius
    if t >= 1.0: return 0.0
    if falloff_type == 'SMOOTH': return (1.0 - t**2)**3
    elif falloff_type == 'SPHERE': return math.sqrt(max(0.0, 1.0 - t**2))
    elif falloff_type == 'ROOT': return 1.0 - math.sqrt(t)
    elif falloff_type == 'SHARP': return (1.0 - t)**2
    elif falloff_type == 'LINEAR': return 1.0 - t
    elif falloff_type == 'INVERSE_SQUARE': return (1.0 - t**3)
    elif falloff_type == 'CONSTANT': return 1.0
    return (1.0 - t)**2

_DEFAULT_GRADIENT_STOPS = (
    (0.0, (0.0, 0.0, 1.0)),
    (0.25, (0.0, 1.0, 1.0)),
    (0.5, (0.0, 1.0, 0.0)),
    (0.75, (1.0, 1.0, 0.0)),
    (1.0, (1.0, 0.0, 0.0)),
)

# Machine-generated grayscale palettes that can only be manufactured by the
# preview ColorRamp machinery, never by a user typing five colors:
# - stop creation on a virgin black->white ramp inherits evaluated grays
#   (0 / 0.5 / 0.75 / 1 / 1),
# - ColorRamp.evaluate() on the same virgin two-stop ramp yields
#   (0 / 0.25 / 0.5 / 0.75 / 1).
# preferences.py shares this exact-tuple set; keep both files in lockstep so a
# repaired palette can never disagree between the render and preview layers.
_PROP_HEATMAP_MACHINE_GRAYSCALE_FINGERPRINTS = (
    (
        (0.0, 0.0, 0.0),
        (0.5, 0.5, 0.5),
        (0.75, 0.75, 0.75),
        (1.0, 1.0, 1.0),
        (1.0, 1.0, 1.0),
    ),
    (
        (0.0, 0.0, 0.0),
        (0.25, 0.25, 0.25),
        (0.5, 0.5, 0.5),
        (0.75, 0.75, 0.75),
        (1.0, 1.0, 1.0),
    ),
)

def _lerp(a: float, b: float, t: float) -> float: 
    return a + (b - a) * t

def _prepare_gradient_stops(stops=None) -> tuple:
    if not stops or len(stops) < 2:
        return _DEFAULT_GRADIENT_STOPS
    try:
        return tuple(sorted(stops, key=lambda s: float(s[0])))
    except Exception:
        return _DEFAULT_GRADIENT_STOPS

def _prop_gradient_stops_from_prefs(prefs) -> tuple:
    """Return the persisted heatmap palette, repairing only known machine tuples.

    Several older builds could save the preview ramp's grayscale fallback back
    into the five source color properties and then mark the migration complete.
    Rendering must never depend on the order in which settings replay and the
    migration callback happen.  Detect that one frozen tuple at the final style
    boundary and use the original blue-cyan-green-yellow-red palette immediately;
    every other user-defined palette, including intentional grayscale palettes,
    is preserved.
    """
    if prefs is None:
        return _DEFAULT_GRADIENT_STOPS
    try:
        colors = (
            tuple(getattr(prefs, 'prop_grad_color_0', (0.0, 0.0, 1.0))),
            tuple(getattr(prefs, 'prop_grad_color_25', (0.0, 1.0, 1.0))),
            tuple(getattr(prefs, 'prop_grad_color_50', (0.0, 1.0, 0.0))),
            tuple(getattr(prefs, 'prop_grad_color_75', (1.0, 1.0, 0.0))),
            tuple(getattr(prefs, 'prop_grad_color_100', (1.0, 0.0, 0.0))),
        )
        normalized = tuple(
            tuple(round(float(channel), 6) for channel in color[:3])
            for color in colors
        )
        if normalized in _PROP_HEATMAP_MACHINE_GRAYSCALE_FINGERPRINTS:
            return _DEFAULT_GRADIENT_STOPS
        return _prepare_gradient_stops(tuple(zip((0.0, 0.25, 0.5, 0.75, 1.0), colors)))
    except Exception:
        return _DEFAULT_GRADIENT_STOPS


def get_heatmap_color(influence: float, stops=None, *, prepared: bool = False) -> tuple:
    if influence <= 0.0: return (0.0, 0.0, 0.0, 0.0)
    x = max(0.0, min(1.0, float(influence)))
    stops = stops if prepared else _prepare_gradient_stops(stops)

    if x <= float(stops[0][0]):
        c = stops[0][1]; return (float(c[0]), float(c[1]), float(c[2]), 1.0)
    if x >= float(stops[-1][0]):
        c = stops[-1][1]; return (float(c[0]), float(c[1]), float(c[2]), 1.0)

    for i in range(len(stops) - 1):
        p0, c0 = stops[i]; p1, c1 = stops[i + 1]
        if x <= float(p1):
            denom = (float(p1) - float(p0)) or 1.0
            t = (x - float(p0)) / denom
            r = _lerp(float(c0[0]), float(c1[0]), t)
            g = _lerp(float(c0[1]), float(c1[1]), t)
            b = _lerp(float(c0[2]), float(c1[2]), t)
            return (r, g, b, 1.0)
    c = stops[-1][1]; return (float(c[0]), float(c[1]), float(c[2]), 1.0)

def calc_geodesic_distances(bm, selected_indices, max_dist, coords):
    try:
        _ensure_bmesh_indices(bm)
    except Exception:
        try:
            bm.verts.ensure_lookup_table()
        except Exception:
            pass

    dists = {}
    heap = []
    max_dist = max(0.0, float(max_dist))
    for i in selected_indices:
        if i < 0 or i >= len(coords):
            continue
        if coords[i] is None:
            continue
        try:
            if not _visible_vert(bm.verts[i]):
                continue
        except Exception:
            continue
        dists[i] = 0.0
        heapq.heappush(heap, (0.0, i))

    while heap:
        d, u_idx = heapq.heappop(heap)
        if d > max_dist:
            continue
        if d > dists.get(u_idx, float('inf')):
            continue

        try:
            u = bm.verts[u_idx]
        except Exception:
            continue
        if not _visible_vert(u):
            continue
        u_co = coords[u_idx]
        if u_co is None:
            continue

        for e in u.link_edges:
            if not _visible_edge(e):
                continue
            v = e.other_vert(u)
            v_idx = v.index
            if v_idx < 0 or v_idx >= len(coords):
                continue
            if not _visible_vert(v):
                continue
            v_co = coords[v_idx]
            if v_co is None:
                continue

            edge_len = (u_co - v_co).length
            new_dist = d + edge_len
            if new_dist <= max_dist:
                if new_dist < dists.get(v_idx, float('inf')):
                    dists[v_idx] = new_dist
                    heapq.heappush(heap, (new_dist, v_idx))

        try:
            linked_faces = u.link_faces
        except Exception:
            linked_faces = ()
        for f in linked_faces:
            if not _visible_face(f):
                continue
            try:
                face_verts = f.verts
            except Exception:
                continue
            for v in face_verts:
                if v is u:
                    continue
                v_idx = v.index
                if v_idx < 0 or v_idx >= len(coords):
                    continue
                if not _visible_vert(v):
                    continue
                v_co = coords[v_idx]
                if v_co is None:
                    continue

                face_len = (u_co - v_co).length
                new_dist = d + face_len
                if new_dist <= max_dist:
                    if new_dist < dists.get(v_idx, float('inf')):
                        dists[v_idx] = new_dist
                        heapq.heappush(heap, (new_dist, v_idx))
    return dists


class SignalContextMonitor:
    def __init__(self):
        self.last_signal_time = 0.0
        self.is_active = False
        self.start_prop_size = -1.0
        self.SIGNAL_LIFESPAN = 0.5

    def on_signal_received(self): 
        self.last_signal_time = time.time()
        
    def check_status(self, current_prop_size):
        now = time.time()
        elapsed = now - self.last_signal_time
        is_now_active = (elapsed < self.SIGNAL_LIFESPAN)
        if is_now_active and not self.is_active: 
            self.start_prop_size = float(current_prop_size)
        elif not is_now_active and self.is_active: 
            self.start_prop_size = -1.0
        self.is_active = is_now_active

_SIGNAL_MONITOR = SignalContextMonitor()
_OVERLAY_CACHE = {}

def _ensure_bmesh_indices(bm: bmesh.types.BMesh) -> None:
    try:
        bm.verts.ensure_lookup_table()
    except Exception:
        pass
    try:
        bm.edges.ensure_lookup_table()
    except Exception:
        pass
    try:
        bm.faces.ensure_lookup_table()
    except Exception:
        pass
    try:
        bm.verts.index_update()
    except Exception:
        pass
    try:
        bm.edges.index_update()
    except Exception:
        pass
    try:
        bm.faces.index_update()
    except Exception:
        pass

def _elem_hidden(elem) -> bool:
    try:
        return bool(getattr(elem, "hide", False))
    except Exception:
        return False

def _visible_vert(v) -> bool:
    return (v is not None) and (not _elem_hidden(v))

def _visible_edge(e) -> bool:
    try:
        return (not _elem_hidden(e)) and all(_visible_vert(v) for v in e.verts)
    except Exception:
        return False

def _visible_face(f) -> bool:
    return (f is not None) and (not _elem_hidden(f))

def _get_selection_signature(bm: bmesh.types.BMesh) -> tuple:
    _ensure_bmesh_indices(bm)
    selected = set()
    try:
        for v in bm.verts:
            if _visible_vert(v) and bool(getattr(v, "select", False)) and v.index >= 0:
                selected.add(int(v.index))
    except Exception:
        pass
    try:
        for e in bm.edges:
            if _visible_edge(e) and bool(getattr(e, "select", False)):
                for v in e.verts:
                    if _visible_vert(v) and v.index >= 0:
                        selected.add(int(v.index))
    except Exception:
        pass
    try:
        for f in bm.faces:
            if (not _elem_hidden(f)) and bool(getattr(f, "select", False)):
                for v in f.verts:
                    if _visible_vert(v) and v.index >= 0:
                        selected.add(int(v.index))
    except Exception:
        pass
    return tuple(sorted(selected))

def _get_connected_visibility_signature(bm: bmesh.types.BMesh) -> tuple:
    _ensure_bmesh_indices(bm)
    hidden_verts = []
    hidden_edges = []
    hidden_faces = []
    try:
        hidden_verts = [int(v.index) for v in bm.verts if (v.index >= 0 and _elem_hidden(v))]
    except Exception:
        hidden_verts = []
    try:
        hidden_edges = [int(e.index) for e in bm.edges if (e.index >= 0 and (not _visible_edge(e)))]
    except Exception:
        hidden_edges = []
    try:
        hidden_faces = [int(f.index) for f in bm.faces if (f.index >= 0 and _elem_hidden(f))]
    except Exception:
        hidden_faces = []
    return (tuple(hidden_verts), tuple(hidden_edges), tuple(hidden_faces))

def _build_base_world_coords(obj, bm):
    mw = obj.matrix_world
    coords = []
    for v in bm.verts:
        if _visible_vert(v):
            try:
                coords.append(mw @ v.co.copy())
            except Exception:
                coords.append(None)
        else:
            coords.append(None)
    return coords

def _ensure_snapshot(context, obj, bm, is_transforming, is_connected_mode, radius, allow_geodesic: bool = True) -> dict:
    obj_key = obj.as_pointer()
    _ensure_bmesh_indices(bm)
    current_verts_len = len(bm.verts)
    current_edges_len = len(bm.edges)
    current_faces_len = len(bm.faces)
    current_sel_sig = _get_selection_signature(bm)
    current_visibility_sig = _get_connected_visibility_signature(bm)

    cache = _OVERLAY_CACHE.get(obj_key)
    if cache is None:
        cache = {
            "verts_len": -1,
            "edges_len": -1,
            "faces_len": -1,
            "sel_sig": None,
            "visibility_sig": None,
            "in_transform": False,
            "base_world_coords": None,
            "kd_tree": None,
            "last_connected_mode": None,
            "geodesic_cache": {"radius": -1.0, "dists": {}},
        }
        _OVERLAY_CACHE[obj_key] = cache

    if is_transforming and not cache["in_transform"]:
        cache["in_transform"] = True
        if cache["base_world_coords"] is None:
            cache["verts_len"] = -1
    elif (not is_transforming) and cache["in_transform"]:
        cache["in_transform"] = False
        cache["verts_len"] = -1

    mesh_changed = (
        (cache.get("verts_len") != current_verts_len)
        or (cache.get("edges_len") != current_edges_len)
        or (cache.get("faces_len") != current_faces_len)
    )
    sel_changed = (cache.get("sel_sig") != current_sel_sig)
    visibility_changed = (cache.get("visibility_sig") != current_visibility_sig)

    if mesh_changed or sel_changed or visibility_changed or (cache.get("base_world_coords") is None):
        base_world_coords = _build_base_world_coords(obj, bm)
        kd = None
        valid_sel = [idx for idx in current_sel_sig if 0 <= idx < len(base_world_coords) and base_world_coords[idx] is not None]
        if valid_sel:
            kd = KDTree(len(valid_sel))
            for idx in valid_sel:
                try:
                    kd.insert(base_world_coords[idx], idx)
                except Exception:
                    pass
            kd.balance()

        cache.update({
            "verts_len": current_verts_len,
            "edges_len": current_edges_len,
            "faces_len": current_faces_len,
            "sel_sig": tuple(valid_sel),
            "visibility_sig": current_visibility_sig,
            "base_world_coords": base_world_coords,
            "kd_tree": kd,
            "geodesic_cache": {"radius": -1.0, "dists": {}},
        })

    if cache.get("last_connected_mode") != is_connected_mode:
        cache["last_connected_mode"] = is_connected_mode
        cache["geodesic_cache"] = {"radius": -1.0, "dists": {}}

    if allow_geodesic and is_connected_mode and cache.get("sel_sig"):
        geo_cache = cache["geodesic_cache"]
        target_radius = max(0.0, float(radius))
        if geo_cache.get("radius", -1.0) < target_radius:
            dists = calc_geodesic_distances(bm, cache.get("sel_sig") or (), target_radius, cache["base_world_coords"])
            geo_cache["radius"] = target_radius
            geo_cache["dists"] = dists
    return cache

def _psc_is_projected_from_view(tool_settings) -> bool:
    for attr in ("use_proportional_projected", "use_proportional_projected_from_view", "use_proportional_edit_projected", "use_proportional_edit_projected_from_view"):
        try:
            if hasattr(tool_settings, attr): return bool(getattr(tool_settings, attr))
        except Exception: continue
    return False

def _psc_get_view_region_and_rv3d(context):
    for ctx in (getattr(bpy, "context", None), context):
        try:
            if ctx is None: continue
            region, rv3d = getattr(ctx, "region", None), getattr(ctx, "region_data", None)
            if region is not None and rv3d is not None: return region, rv3d
        except Exception: continue
    return None, None

def _psc_calc_projected_radius_px(region, rv3d, center_world: Vector, radius_world: float) -> float:
    try:
        c2d = view3d_utils.location_3d_to_region_2d(region, rv3d, center_world)
        if c2d is None: return -1.0
        view_right = rv3d.view_rotation @ Vector((1.0, 0.0, 0.0))
        p_world = center_world + view_right * float(radius_world)
        p2d = view3d_utils.location_3d_to_region_2d(region, rv3d, p_world)
        if p2d is None: return -1.0
        return (p2d - c2d).length
    except Exception: return -1.0

def _psc_project_world_list_to_screen(region, rv3d, world_coords):
    out = []
    for co in world_coords:
        try: p = view3d_utils.location_3d_to_region_2d(region, rv3d, co)
        except Exception: p = None
        if p is None: out.append(None)
        else: out.append(Vector((p.x, p.y, 0.0)))
    return out


def _iter_lattice_edge_pairs(edges):
    try:
        edge_iter = edges.tolist() if hasattr(edges, 'tolist') else edges
    except Exception:
        return
    for edge in edge_iter or ():
        try:
            a, b = int(edge[0]), int(edge[1])
        except Exception:
            continue
        if a >= 0 and b >= 0:
            yield a, b


def _lattice_world_coords(obj, local_coords) -> list:
    try:
        mw = getattr(obj, 'matrix_world', None)
    except Exception:
        mw = None
    if mw is None or local_coords is None:
        return []
    coords = []
    for co in local_coords:
        try:
            coords.append(mw @ Vector((float(co[0]), float(co[1]), float(co[2]))))
        except Exception:
            coords.append(None)
    return coords


def _lattice_selected_indices(selected, coords) -> tuple:
    out = []
    try:
        selected_iter = list(selected)
    except Exception:
        selected_iter = []
    for i, flag in enumerate(selected_iter):
        try:
            if bool(flag) and 0 <= i < len(coords) and coords[i] is not None:
                out.append(int(i))
        except Exception:
            continue
    return tuple(out)


def _calc_lattice_connected_distances(edges, selected_indices, max_dist: float, coords) -> dict:
    try:
        n = len(coords)
    except Exception:
        return {}
    if n <= 0:
        return {}
    max_dist = max(0.0, float(max_dist))
    adjacency = [[] for _ in range(n)]
    for a, b in _iter_lattice_edge_pairs(edges):
        if a >= n or b >= n:
            continue
        ca = coords[a]
        cb = coords[b]
        if ca is None or cb is None:
            continue
        try:
            length = float((ca - cb).length)
        except Exception:
            continue
        adjacency[a].append((b, length))
        adjacency[b].append((a, length))

    dists = {}
    heap = []
    for idx in selected_indices or ():
        try:
            i = int(idx)
        except Exception:
            continue
        if i < 0 or i >= n or coords[i] is None:
            continue
        dists[i] = 0.0
        heapq.heappush(heap, (0.0, i))

    while heap:
        d, u = heapq.heappop(heap)
        if d > max_dist:
            continue
        if d > dists.get(u, float('inf')):
            continue
        for v, edge_len in adjacency[u]:
            new_dist = d + edge_len
            if new_dist <= max_dist and new_dist < dists.get(v, float('inf')):
                dists[v] = new_dist
                heapq.heappush(heap, (new_dist, v))
    return dists


def _draw_prop_heatmap_batches(shader, edge_coords, edge_colors, point_coords, point_colors, overlay_line_width: float, overlay_point_size: float, aa_mode: str) -> None:
    if edge_coords:
        if aa_mode == "AA_2PASS":
            try:
                _prop_state_set('line_width', float(overlay_line_width) + 1.0)
                edge_colors_aa = [(c[0], c[1], c[2], c[3] * 0.18) for c in edge_colors]
                batch_edges_aa = batch_for_shader(shader, 'LINES', {"pos": edge_coords, "color": edge_colors_aa})
                batch_edges_aa.draw(shader)
            except Exception:
                pass
        _prop_state_set('line_width', float(overlay_line_width))
        batch_edges = batch_for_shader(shader, 'LINES', {"pos": edge_coords, "color": edge_colors})
        batch_edges.draw(shader)
    if point_coords:
        _prop_state_set('point_size', float(overlay_point_size))
        batch_points = batch_for_shader(shader, 'POINTS', {"pos": point_coords, "color": point_colors})
        batch_points.draw(shader)




def _prop_style_from_prefs(context):
    try:
        prefs = _prefs(context)
    except Exception:
        prefs = None
    try:
        overlay_point_size = float(getattr(prefs, 'prop_overlay_vertex_size', 4.0)) if prefs else 4.0
        overlay_line_width = float(getattr(prefs, 'prop_overlay_edge_size', 2.0)) if prefs else 2.0
        overlay_point_size = max(0.1, overlay_point_size)
        overlay_line_width = max(0.1, overlay_line_width)
    except Exception:
        overlay_point_size, overlay_line_width = 4.0, 2.0
    try:
        heatmap_alpha = float(getattr(prefs, 'prop_heatmap_alpha', 1.0)) if prefs else 1.0
        heatmap_alpha = max(0.05, min(1.0, heatmap_alpha))
    except Exception:
        heatmap_alpha = 1.0
    try:
        heatmap_xray = bool(getattr(prefs, 'prop_heatmap_xray', True)) if prefs else True
    except Exception:
        heatmap_xray = True
    gradient_stops = _prop_gradient_stops_from_prefs(prefs)
    try:
        aa_mode = getattr(prefs, 'edge_aa_mode', 'AA_2PASS') if prefs else 'AA_2PASS'
    except Exception:
        aa_mode = 'AA_2PASS'
    return prefs, overlay_point_size, overlay_line_width, heatmap_alpha, heatmap_xray, gradient_stops, aa_mode


def _prop_alpha_mul_factory(heatmap_alpha: float):
    def _alpha_mul(color):
        try:
            return (float(color[0]), float(color[1]), float(color[2]), max(0.0, min(1.0, float(color[3]) * float(heatmap_alpha))))
        except Exception:
            return (0.0, 0.0, 0.0, 0.0)
    return _alpha_mul


def _draw_callback_prop_object(context, tool_settings) -> None:
    """Object-mode proportional-edit overlay for object origins.

    Blender's Object Mode proportional editing operates on object transforms, so
    the stable visual target is the object origin rather than the object's mesh
    topology.  This keeps the overlay useful for mesh, curve, lattice, camera,
    light, empty, and other transformable objects without forcing evaluated data
    access.
    """
    try:
        if not bool(getattr(tool_settings, 'use_proportional_edit_objects', False)):
            return
    except Exception:
        return

    prefs, overlay_point_size, _overlay_line_width, heatmap_alpha, heatmap_xray, gradient_stops, _aa_mode = _prop_style_from_prefs(context)

    try:
        if prefs and not mesh.is_active_view_draw_context(context, prefs):
            return
    except Exception:
        pass

    try:
        radius = float(getattr(tool_settings, 'proportional_size', 0.0) or 0.0)
    except Exception:
        radius = 0.0
    if radius <= 0.0:
        return
    falloff_type = str(getattr(tool_settings, 'proportional_edit_falloff', 'SMOOTH') or 'SMOOTH')
    alpha_mul = _prop_alpha_mul_factory(heatmap_alpha)

    try:
        selected_objects = [o for o in (getattr(context, 'selected_objects', ()) or ()) if o and bool(o.select_get())]
    except Exception:
        selected_objects = []
    if not selected_objects:
        return
    source_coords = []
    for obj in selected_objects:
        try:
            if bool(getattr(obj, 'hide_viewport', False)) or bool(obj.hide_get()):
                continue
            source_coords.append(getattr(obj, 'matrix_world').translation.copy())
        except Exception:
            continue
    if not source_coords:
        return

    try:
        visible_objects = tuple(getattr(context, 'visible_objects', ()) or ())
    except Exception:
        visible_objects = ()
    if not visible_objects:
        try:
            visible_objects = tuple(getattr(getattr(context, 'scene', None), 'objects', ()) or ())
        except Exception:
            visible_objects = ()
    target_coords = []
    for obj in visible_objects:
        try:
            if bool(getattr(obj, 'hide_viewport', False)) or bool(obj.hide_get()):
                continue
            target_coords.append(getattr(obj, 'matrix_world').translation.copy())
        except Exception:
            continue
    if not target_coords:
        return

    kd = KDTree(len(source_coords))
    for i, co in enumerate(source_coords):
        try:
            kd.insert(co, int(i))
        except Exception:
            pass
    try:
        kd.balance()
    except Exception:
        return

    point_coords = []
    point_colors = []
    for co in target_coords:
        try:
            _found, _idx, dist = kd.find(co)
        except Exception:
            continue
        influence = get_falloff_intensity(float(dist), radius, falloff_type)
        if influence <= 0.0:
            continue
        point_coords.append(co)
        point_colors.append(alpha_mul(get_heatmap_color(influence, gradient_stops, prepared=True)))
    if not point_coords:
        return

    try:
        try:
            shader = gpu.shader.from_builtin('3D_SMOOTH_COLOR')
        except Exception:
            shader = gpu.shader.from_builtin('SMOOTH_COLOR')
        shader.bind()
        _prop_state_set('blend', 'ALPHA')
        if heatmap_xray:
            try:
                _prop_state_set('depth_test', 'NONE')
            except Exception:
                _prop_state_set('depth_test', 'ALWAYS')
        else:
            try:
                _prop_state_set('depth_test', 'LESS_EQUAL')
            except Exception:
                _prop_state_set('depth_test', 'LESS')
        _prop_state_set('point_size', float(overlay_point_size))
        batch = batch_for_shader(shader, 'POINTS', {'pos': point_coords, 'color': point_colors})
        batch.draw(shader)
    except Exception:
        pass
    finally:
        try:
            mesh._sos_reset_gpu_state_after_draw()
        except Exception:
            pass
        try:
            _prop_state_set('point_size', 1.0)
        except Exception:
            pass


def _draw_callback_prop_lattice(context, tool_settings) -> None:
    try:
        prefs = _prefs(context)
    except Exception:
        prefs = None

    try:
        if prefs and not bool(getattr(prefs, 'include_lattice_objects', True)):
            return
    except Exception:
        pass

    try:
        if prefs and not mesh.is_active_view_draw_context(context, prefs):
            return
    except Exception:
        pass

    try:
        _SIGNAL_MONITOR.check_status(getattr(tool_settings, 'proportional_size', 0.0))
    except Exception:
        pass

    try:
        draw_size = float(getattr(tool_settings, 'proportional_size', 0.0) or 0.0)
    except Exception:
        draw_size = 0.0
    if draw_size <= 0.0:
        return

    falloff_type = str(getattr(tool_settings, 'proportional_edit_falloff', 'SMOOTH') or 'SMOOTH')
    use_connected = bool(getattr(tool_settings, 'use_proportional_connected', False))
    use_projected = _psc_is_projected_from_view(tool_settings) and (not use_connected)

    try:
        objs_in_mode = getattr(context, 'objects_in_mode', None)
    except Exception:
        objs_in_mode = None
    if objs_in_mode:
        edit_objs = [o for o in objs_in_mode if o and getattr(o, 'type', None) == 'LATTICE']
    else:
        try:
            selected_objects = getattr(context, 'selected_objects', ()) or ()
        except Exception:
            selected_objects = ()
        edit_objs = [o for o in selected_objects if o and getattr(o, 'type', None) == 'LATTICE' and getattr(o, 'mode', None) == 'EDIT']
    if not edit_objs:
        obj = getattr(context, 'active_object', None)
        if obj and getattr(obj, 'type', None) == 'LATTICE':
            edit_objs = [obj]
    if not edit_objs:
        return

    try:
        overlay_point_size = float(getattr(prefs, 'prop_overlay_vertex_size', 4.0)) if prefs else 4.0
        overlay_line_width = float(getattr(prefs, 'prop_overlay_edge_size', 2.0)) if prefs else 2.0
        overlay_point_size = max(0.1, overlay_point_size)
        overlay_line_width = max(0.1, overlay_line_width)
    except Exception:
        overlay_point_size, overlay_line_width = 4.0, 2.0

    try:
        heatmap_alpha = float(getattr(prefs, 'prop_heatmap_alpha', 1.0)) if prefs else 1.0
        heatmap_alpha = max(0.05, min(1.0, heatmap_alpha))
    except Exception:
        heatmap_alpha = 1.0
    try:
        heatmap_xray = bool(getattr(prefs, 'prop_heatmap_xray', True)) if prefs else True
    except Exception:
        heatmap_xray = True

    gradient_stops = _prop_gradient_stops_from_prefs(prefs)

    def _alpha_mul(color):
        return (float(color[0]), float(color[1]), float(color[2]), max(0.0, min(1.0, float(color[3]) * heatmap_alpha)))

    lattice_geom_fn = getattr(mesh, '_lattice_geometry_arrays', None)
    if not callable(lattice_geom_fn):
        return

    prepared = []
    global_sel_coords = []
    for obj in edit_objs:
        try:
            arrays = lattice_geom_fn(obj)
            if not arrays:
                continue
            local_verts, edges, _tris, selected = arrays
            world_coords = _lattice_world_coords(obj, local_verts)
            if not world_coords:
                continue
            sel_indices = _lattice_selected_indices(selected, world_coords)
            for idx in sel_indices:
                global_sel_coords.append(world_coords[idx])
            prepared.append((obj, edges, sel_indices, world_coords))
        except Exception:
            continue

    if not prepared or not global_sel_coords:
        return

    region, rv3d = None, None
    influence_radius = draw_size
    if use_projected:
        region, rv3d = _psc_get_view_region_and_rv3d(context)
        if region is None or rv3d is None:
            return
        try:
            sel_center = Vector((0.0, 0.0, 0.0))
            for co in global_sel_coords:
                sel_center += co
            sel_center /= max(1, len(global_sel_coords))
        except Exception:
            sel_center = global_sel_coords[0].copy()
        influence_radius = _psc_calc_projected_radius_px(region, rv3d, sel_center, draw_size)
        if influence_radius <= 0.0:
            return
        global_sel_coords_2d = []
        for co in global_sel_coords:
            try:
                p = view3d_utils.location_3d_to_region_2d(region, rv3d, co)
            except Exception:
                p = None
            if p is not None:
                global_sel_coords_2d.append(Vector((p.x, p.y, 0.0)))
        if not global_sel_coords_2d:
            return
        kd_global = KDTree(len(global_sel_coords_2d))
        for i, co in enumerate(global_sel_coords_2d):
            try:
                kd_global.insert(co, i)
            except Exception:
                pass
        kd_global.balance()
    else:
        kd_global = KDTree(len(global_sel_coords))
        for i, co in enumerate(global_sel_coords):
            try:
                kd_global.insert(co, i)
            except Exception:
                pass
        kd_global.balance()

    try:
        try:
            shader = gpu.shader.from_builtin('3D_SMOOTH_COLOR')
        except Exception:
            try:
                shader = gpu.shader.from_builtin('SMOOTH_COLOR')
            except Exception:
                return
        shader.bind()
        _prop_state_set('blend', 'ALPHA')
        if heatmap_xray:
            try:
                _prop_state_set('depth_test', 'NONE')
            except Exception:
                _prop_state_set('depth_test', 'ALWAYS')
        else:
            try:
                _prop_state_set('depth_test', 'LESS_EQUAL')
            except Exception:
                _prop_state_set('depth_test', 'LESS')

        aa_mode = getattr(prefs, 'edge_aa_mode', 'AA_2PASS') if prefs else 'AA_2PASS'
        aa_enabled = (aa_mode != 'AA_OFF')
        for fn, val in (("multisample_set", aa_enabled), ("line_smooth_set", aa_enabled), ("alpha_to_coverage_set", aa_enabled)):
            try:
                getattr(gpu.state, fn)(val)
            except Exception:
                pass

        for _obj, edges, sel_indices, world_coords in prepared:
            try:
                if not world_coords:
                    continue
                colored_points = []
                if use_connected:
                    if not sel_indices:
                        continue
                    geo_dists = _calc_lattice_connected_distances(edges, sel_indices, float(influence_radius), world_coords)
                    for idx, dist in geo_dists.items():
                        influence = get_falloff_intensity(dist, influence_radius, falloff_type)
                        if influence > 0:
                            colored_points.append((idx, _alpha_mul(get_heatmap_color(influence, gradient_stops, prepared=True))))
                else:
                    screen_coords = None
                    if use_projected:
                        if region is None or rv3d is None:
                            continue
                        try:
                            screen_coords = _psc_project_world_list_to_screen(region, rv3d, world_coords)
                        except Exception:
                            screen_coords = None
                    sel_lookup = set(sel_indices) if len(sel_indices) > 8 else sel_indices
                    for i, co in enumerate(world_coords):
                        if co is None:
                            continue
                        try:
                            if i in sel_lookup:
                                dist = 0.0
                            elif use_projected:
                                if not screen_coords:
                                    continue
                                sc = screen_coords[i]
                                if sc is None:
                                    continue
                                _, _, dist = kd_global.find(sc)
                            else:
                                _, _, dist = kd_global.find(co)
                        except Exception:
                            continue
                        influence = get_falloff_intensity(dist, influence_radius, falloff_type)
                        if influence > 0:
                            colored_points.append((i, _alpha_mul(get_heatmap_color(influence, gradient_stops, prepared=True))))

                if not colored_points:
                    continue

                point_coords, point_colors, edge_coords, edge_colors = [], [], [], []
                valid_indices, color_map = set(), {}
                for idx, color in colored_points:
                    if idx < 0 or idx >= len(world_coords):
                        continue
                    co = world_coords[idx]
                    if co is None:
                        continue
                    point_coords.append(co)
                    point_colors.append(color)
                    valid_indices.add(idx)
                    color_map[idx] = color

                if not point_coords:
                    continue

                for a, b in _iter_lattice_edge_pairs(edges):
                    if a in valid_indices and b in valid_indices and a < len(world_coords) and b < len(world_coords):
                        ca = world_coords[a]
                        cb = world_coords[b]
                        if ca is None or cb is None:
                            continue
                        edge_coords.append(ca)
                        edge_coords.append(cb)
                        edge_colors.append(color_map[a])
                        edge_colors.append(color_map[b])

                _draw_prop_heatmap_batches(shader, edge_coords, edge_colors, point_coords, point_colors, overlay_line_width, overlay_point_size, aa_mode)
            except Exception:
                continue
    except Exception:
        pass
    finally:
        for fn, val in (("multisample_set", False), ("line_smooth_set", False), ("alpha_to_coverage_set", False)):
            try:
                getattr(gpu.state, fn)(val)
            except Exception:
                pass
        try:
            mesh._sos_reset_gpu_state_after_draw()
        except Exception:
            pass
        try:
            _prop_state_set('line_width', 1.0)
        except Exception:
            pass
        try:
            _prop_state_set('point_size', 1.0)
        except Exception:
            pass



# -----------------------------------------------------------------------------
# Curve proportional overlay support
# -----------------------------------------------------------------------------
def _curve_prop_world_coords(obj, local_coords) -> list:
    try:
        mw = getattr(obj, 'matrix_world', None)
    except Exception:
        mw = None
    if mw is None or local_coords is None:
        return []
    coords = []
    for co in local_coords:
        try:
            coords.append(mw @ Vector((float(co[0]), float(co[1]), float(co[2]))))
        except Exception:
            coords.append(None)
    return coords


def _curve_prop_selected_indices(selected, coords) -> tuple:
    out = []
    try:
        selected_iter = list(selected)
    except Exception:
        selected_iter = []
    for i, flag in enumerate(selected_iter):
        try:
            if bool(flag) and 0 <= i < len(coords) and coords[i] is not None:
                out.append(int(i))
        except Exception:
            continue
    return tuple(out)


def _curve_prop_has_render_mesh(mesh_data) -> bool:
    if not isinstance(mesh_data, dict):
        return False
    try:
        verts = mesh_data.get('verts')
        tris = mesh_data.get('tris')
        return bool(mesh_data.get('has_render_mesh') and verts is not None and len(verts) > 0 and tris is not None and len(tris) > 0)
    except Exception:
        return False


def _curve_prop_kdtree(coords):
    valid = []
    for i, co in enumerate(coords or ()): 
        if co is not None:
            valid.append((i, co))
    if not valid:
        return None, ()
    kd = KDTree(len(valid))
    for i, co in valid:
        try:
            kd.insert(co, int(i))
        except Exception:
            pass
    try:
        kd.balance()
    except Exception:
        return None, ()
    return kd, tuple(i for i, _co in valid)


def _curve_prop_nearest_target_indices(target_coords, source_coords) -> tuple:
    kd, _valid = _curve_prop_kdtree(target_coords)
    if kd is None:
        return ()
    out = []
    seen = set()
    for co in source_coords or ():
        if co is None:
            continue
        try:
            _found, idx, _dist = kd.find(co)
            idx = int(idx)
        except Exception:
            continue
        if idx not in seen:
            seen.add(idx)
            out.append(idx)
    return tuple(out)


def _curve_prop_colorized_geometry(
    target_coords,
    target_edges,
    source_world_coords,
    kd_global,
    influence_radius: float,
    falloff_type: str,
    gradient_stops,
    alpha_mul,
    *,
    use_connected: bool = False,
    use_projected: bool = False,
    region=None,
    rv3d=None,
):
    """Build colored point/edge arrays for curve proportional overlay.

    Selected curve control points remain the proportional-edit source.  The
    target can be control points, sampled curve shape vertices, or the evaluated
    render mesh.  For Connected mode the selected controls are mapped to the
    nearest target vertices, then distances travel along target edges; otherwise
    the standard world/screen-space nearest-source distance is used.
    """
    if not target_coords:
        return [], [], [], []
    try:
        radius = max(0.0, float(influence_radius))
    except Exception:
        radius = 0.0
    if radius <= 0.0:
        return [], [], [], []

    colored_points = []
    if use_connected:
        seed_indices = _curve_prop_nearest_target_indices(target_coords, source_world_coords)
        if seed_indices:
            try:
                geo_dists = _calc_lattice_connected_distances(target_edges if target_edges is not None else (), seed_indices, radius, target_coords)
            except Exception:
                geo_dists = {}
            for idx, dist in geo_dists.items():
                try:
                    influence = get_falloff_intensity(float(dist), radius, falloff_type)
                except Exception:
                    influence = 0.0
                if influence > 0.0:
                    colored_points.append((int(idx), alpha_mul(get_heatmap_color(influence, gradient_stops, prepared=True))))
    else:
        screen_coords = None
        if use_projected:
            if region is None or rv3d is None:
                return [], [], [], []
            try:
                screen_coords = _psc_project_world_list_to_screen(region, rv3d, target_coords)
            except Exception:
                screen_coords = None
            if not screen_coords:
                return [], [], [], []
        for i, co in enumerate(target_coords):
            if co is None:
                continue
            try:
                if use_projected:
                    sc = screen_coords[i]
                    if sc is None:
                        continue
                    _found, _idx, dist = kd_global.find(sc)
                else:
                    _found, _idx, dist = kd_global.find(co)
            except Exception:
                continue
            influence = get_falloff_intensity(float(dist), radius, falloff_type)
            if influence > 0.0:
                colored_points.append((int(i), alpha_mul(get_heatmap_color(influence, gradient_stops, prepared=True))))

    if not colored_points:
        return [], [], [], []

    point_coords, point_colors, edge_coords, edge_colors = [], [], [], []
    valid_indices, color_map = set(), {}
    for idx, color in colored_points:
        if idx < 0 or idx >= len(target_coords):
            continue
        co = target_coords[idx]
        if co is None:
            continue
        point_coords.append(co)
        point_colors.append(color)
        valid_indices.add(idx)
        color_map[idx] = color

    for a, b in _iter_lattice_edge_pairs(target_edges if target_edges is not None else ()): 
        if a in valid_indices and b in valid_indices and a < len(target_coords) and b < len(target_coords):
            ca = target_coords[a]
            cb = target_coords[b]
            if ca is None or cb is None:
                continue
            edge_coords.append(ca)
            edge_coords.append(cb)
            edge_colors.append(color_map[a])
            edge_colors.append(color_map[b])

    return point_coords, point_colors, edge_coords, edge_colors


def _draw_callback_prop_curve(context, tool_settings) -> None:
    try:
        prefs = _prefs(context)
    except Exception:
        prefs = None

    try:
        include_shape = bool(getattr(prefs, 'include_curve_shape_overlay', True)) if prefs else True
    except Exception:
        include_shape = True

    try:
        if prefs and not mesh.is_active_view_draw_context(context, prefs):
            return
    except Exception:
        pass

    try:
        _SIGNAL_MONITOR.check_status(getattr(tool_settings, 'proportional_size', 0.0))
    except Exception:
        pass

    try:
        draw_size = float(getattr(tool_settings, 'proportional_size', 0.0) or 0.0)
    except Exception:
        draw_size = 0.0
    if draw_size <= 0.0:
        return

    falloff_type = str(getattr(tool_settings, 'proportional_edit_falloff', 'SMOOTH') or 'SMOOTH')
    use_connected = bool(getattr(tool_settings, 'use_proportional_connected', False))
    use_projected = _psc_is_projected_from_view(tool_settings) and (not use_connected)

    try:
        overlay_point_size = float(getattr(prefs, 'prop_overlay_vertex_size', 4.0)) if prefs else 4.0
        overlay_line_width = float(getattr(prefs, 'prop_overlay_edge_size', 2.0)) if prefs else 2.0
        overlay_point_size = max(0.1, overlay_point_size)
        overlay_line_width = max(0.1, overlay_line_width)
    except Exception:
        overlay_point_size, overlay_line_width = 4.0, 2.0

    try:
        heatmap_alpha = float(getattr(prefs, 'prop_heatmap_alpha', 1.0)) if prefs else 1.0
        heatmap_alpha = max(0.05, min(1.0, heatmap_alpha))
    except Exception:
        heatmap_alpha = 1.0
    try:
        heatmap_xray = bool(getattr(prefs, 'prop_heatmap_xray', True)) if prefs else True
    except Exception:
        heatmap_xray = True

    gradient_stops = _prop_gradient_stops_from_prefs(prefs)

    def _alpha_mul(color):
        return (float(color[0]), float(color[1]), float(color[2]), max(0.0, min(1.0, float(color[3]) * heatmap_alpha)))

    curve_types = {'CURVE', 'SURFACE', 'CURVES'}
    try:
        curve_objects = [o for o in (getattr(context, 'objects_in_mode', ()) or ()) if getattr(o, 'type', None) in curve_types]
    except Exception:
        curve_objects = []
    if not curve_objects:
        obj = getattr(context, 'object', None) or getattr(context, 'active_object', None)
        if getattr(obj, 'type', None) in curve_types:
            curve_objects = [obj]
    if not curve_objects:
        return

    depsgraph = None
    try:
        depsgraph = context.evaluated_depsgraph_get()
    except Exception:
        depsgraph = None

    prepared = []
    global_sel_coords = []
    for obj in curve_objects:
        try:
            upd = getattr(obj, 'update_from_editmode', None)
            if callable(upd):
                try:
                    upd()
                except Exception:
                    pass
            ctrl_va = []
            ctrl_selected = []
            shape_va = []
            shape_ei = []
            obj_type = getattr(obj, 'type', None)
            if obj_type == 'CURVES':
                arrays = _curves_prop_control_and_shape_arrays(obj) if include_shape else None
            else:
                arrays = mesh._curve_control_and_shape_arrays(obj) if include_shape and hasattr(mesh, '_curve_control_and_shape_arrays') else None
            if arrays:
                ctrl_va, ctrl_selected, shape_va, shape_ei = arrays
            ctrl_world = _curve_prop_world_coords(obj, ctrl_va)
            sel_indices = _curve_prop_selected_indices(ctrl_selected, ctrl_world)
            selected_world = [ctrl_world[i] for i in sel_indices if 0 <= i < len(ctrl_world) and ctrl_world[i] is not None]
            if not selected_world:
                continue
            global_sel_coords.extend(selected_world)

            shape_world = _curve_prop_world_coords(obj, shape_va) if include_shape else []
            mesh_world = []
            mesh_edges = []
            mesh_data = None
            has_render_mesh = False
            try:
                if getattr(obj, 'type', None) == 'SURFACE':
                    has_render_settings = True
                elif getattr(obj, 'type', None) == 'CURVES':
                    has_render_settings = False
                else:
                    has_render_settings = bool(mesh._sos_curve_has_render_mesh_settings(obj)) if hasattr(mesh, '_sos_curve_has_render_mesh_settings') else False
            except Exception:
                has_render_settings = False
            if has_render_settings and hasattr(mesh, '_curve_evaluated_mesh_arrays'):
                mesh_data = mesh._curve_evaluated_mesh_arrays(obj, depsgraph)
                has_render_mesh = _curve_prop_has_render_mesh(mesh_data)
                if has_render_mesh:
                    mesh_world = _curve_prop_world_coords(obj, mesh_data.get('verts'))
                    mesh_edges = mesh_data.get('edges')
                    if mesh_edges is None:
                        mesh_edges = ()

            prepared.append({
                'obj': obj,
                'selected_world': selected_world,
                'ctrl_world': ctrl_world if include_shape else [],
                'shape_world': shape_world,
                'shape_edges': shape_ei if include_shape else (),
                'mesh_world': mesh_world,
                'mesh_edges': mesh_edges,
                'has_render_mesh': bool(has_render_mesh),
            })
        except Exception:
            continue

    if not prepared or not global_sel_coords:
        return

    region, rv3d = None, None
    influence_radius = draw_size
    if use_projected:
        region, rv3d = _psc_get_view_region_and_rv3d(context)
        if region is None or rv3d is None:
            return
        try:
            sel_center = Vector((0.0, 0.0, 0.0))
            for co in global_sel_coords:
                sel_center += co
            sel_center /= max(1, len(global_sel_coords))
        except Exception:
            sel_center = global_sel_coords[0].copy()
        influence_radius = _psc_calc_projected_radius_px(region, rv3d, sel_center, draw_size)
        if influence_radius <= 0.0:
            return
        global_sel_coords_2d = []
        for co in global_sel_coords:
            try:
                p = view3d_utils.location_3d_to_region_2d(region, rv3d, co)
            except Exception:
                p = None
            if p is not None:
                global_sel_coords_2d.append(Vector((p.x, p.y, 0.0)))
        if not global_sel_coords_2d:
            return
        kd_global = KDTree(len(global_sel_coords_2d))
        for i, co in enumerate(global_sel_coords_2d):
            try:
                kd_global.insert(co, i)
            except Exception:
                pass
        kd_global.balance()
    else:
        kd_global = KDTree(len(global_sel_coords))
        for i, co in enumerate(global_sel_coords):
            try:
                kd_global.insert(co, i)
            except Exception:
                pass
        kd_global.balance()

    try:
        try:
            shader = gpu.shader.from_builtin('3D_SMOOTH_COLOR')
        except Exception:
            try:
                shader = gpu.shader.from_builtin('SMOOTH_COLOR')
            except Exception:
                return
        shader.bind()
        _prop_state_set('blend', 'ALPHA')
        if heatmap_xray:
            try:
                _prop_state_set('depth_test', 'NONE')
            except Exception:
                _prop_state_set('depth_test', 'ALWAYS')
        else:
            try:
                _prop_state_set('depth_test', 'LESS_EQUAL')
            except Exception:
                _prop_state_set('depth_test', 'LESS')

        aa_mode = getattr(prefs, 'edge_aa_mode', 'AA_2PASS') if prefs else 'AA_2PASS'
        aa_enabled = (aa_mode != 'AA_OFF')
        for fn, val in (("multisample_set", aa_enabled), ("line_smooth_set", aa_enabled), ("alpha_to_coverage_set", aa_enabled)):
            try:
                getattr(gpu.state, fn)(val)
            except Exception:
                pass

        for entry in prepared:
            try:
                # First draw the evaluated render mesh when bevel/extrude/fill creates
                # a polygonal result.  It makes the proportional heatmap sit on the
                # same visible curve surface used by Mesh and Curve Overlay.
                if entry.get('has_render_mesh') and entry.get('mesh_world'):
                    point_coords, point_colors, edge_coords, edge_colors = _curve_prop_colorized_geometry(
                        entry.get('mesh_world') or (), entry.get('mesh_edges') if entry.get('mesh_edges') is not None else (), entry.get('selected_world') or (),
                        kd_global, influence_radius, falloff_type, gradient_stops, _alpha_mul,
                        use_connected=use_connected, use_projected=use_projected, region=region, rv3d=rv3d,
                    )
                    _draw_prop_heatmap_batches(shader, edge_coords, edge_colors, point_coords, point_colors, overlay_line_width, overlay_point_size, aa_mode)

                # Draw the sampled curve shape for non-render-mesh curves and also
                # keep it visible on bevelled curves as a readable centerline.
                if include_shape and entry.get('shape_world'):
                    point_coords, point_colors, edge_coords, edge_colors = _curve_prop_colorized_geometry(
                        entry.get('shape_world') or (), entry.get('shape_edges') if entry.get('shape_edges') is not None else (), entry.get('selected_world') or (),
                        kd_global, influence_radius, falloff_type, gradient_stops, _alpha_mul,
                        use_connected=use_connected, use_projected=use_projected, region=region, rv3d=rv3d,
                    )
                    _draw_prop_heatmap_batches(shader, edge_coords, edge_colors, [], [], overlay_line_width, overlay_point_size, aa_mode)

                # Control points are drawn last so selected handles/control points do
                # not disappear under the sampled shape or render-mesh edge heatmap.
                if include_shape and entry.get('ctrl_world'):
                    point_coords, point_colors, _edge_coords, _edge_colors = _curve_prop_colorized_geometry(
                        entry.get('ctrl_world') or (), (), entry.get('selected_world') or (),
                        kd_global, influence_radius, falloff_type, gradient_stops, _alpha_mul,
                        use_connected=False, use_projected=use_projected, region=region, rv3d=rv3d,
                    )
                    _draw_prop_heatmap_batches(shader, [], [], point_coords, point_colors, overlay_line_width, overlay_point_size, aa_mode)
            except Exception:
                continue
    except Exception:
        pass
    finally:
        for fn, val in (("multisample_set", False), ("line_smooth_set", False), ("alpha_to_coverage_set", False)):
            try:
                getattr(gpu.state, fn)(val)
            except Exception:
                pass
        try:
            mesh._sos_reset_gpu_state_after_draw()
        except Exception:
            pass
        try:
            _prop_state_set('line_width', 1.0)
        except Exception:
            pass
        try:
            _prop_state_set('point_size', 1.0)
        except Exception:
            pass



# -----------------------------------------------------------------------------
# Curves data-block proportional overlay support (Object.type == 'CURVES')
# -----------------------------------------------------------------------------
def _curves_prop_attr_bool_values(attr, count: int) -> list:
    values = [False] * max(0, int(count))
    if attr is None or count <= 0:
        return values
    try:
        data = getattr(attr, 'data', None)
        if data is None:
            return values
        n = min(int(count), len(data))
        for i in range(n):
            try:
                values[i] = bool(getattr(data[i], 'value', False))
            except Exception:
                values[i] = False
    except Exception:
        pass
    return values


def _curves_prop_control_and_shape_arrays(obj):
    """Return point/edge arrays for the modern Curves object type.

    The standard Curve object uses splines; the newer Curves datablock stores
    editable points in the POINT-domain ``position`` attribute and curve offsets.
    This reader uses only data-block attributes during draw, not depsgraph update
    callbacks, so it preserves the previous crash-safe callback policy.
    """
    data = getattr(obj, 'data', None)
    if data is None:
        return None
    try:
        upd = getattr(obj, 'update_from_editmode', None)
        if callable(upd):
            try:
                upd()
            except Exception:
                pass
    except Exception:
        pass

    coords = []
    try:
        pos_data = getattr(data, 'position_data', None)
        if pos_data is not None and len(pos_data) > 0:
            for item in pos_data:
                try:
                    v = getattr(item, 'vector', None)
                    coords.append((float(v[0]), float(v[1]), float(v[2])))
                except Exception:
                    try:
                        p = getattr(item, 'position', None)
                        coords.append((float(p[0]), float(p[1]), float(p[2])))
                    except Exception:
                        coords.append((0.0, 0.0, 0.0))
    except Exception:
        coords = []
    if not coords:
        try:
            attr = getattr(data, 'attributes', {}).get('position')
            attr_data = getattr(attr, 'data', None)
            if attr_data is not None:
                for item in attr_data:
                    v = getattr(item, 'vector', None)
                    coords.append((float(v[0]), float(v[1]), float(v[2])))
        except Exception:
            coords = []
    if not coords:
        return None
    point_count = len(coords)

    edges = []
    curve_ranges = []
    try:
        curves = tuple(getattr(data, 'curves', ()) or ())
    except Exception:
        curves = ()
    for curve in curves:
        try:
            start = int(getattr(curve, 'first_point_index', 0) or 0)
            length = int(getattr(curve, 'points_length', 0) or 0)
        except Exception:
            continue
        if length <= 0:
            continue
        start = max(0, min(point_count, start))
        end = max(start, min(point_count, start + length))
        if end <= start:
            continue
        curve_ranges.append((start, end))
        for i in range(start, end - 1):
            edges.append((i, i + 1))
    if not curve_ranges:
        try:
            offsets = [int(getattr(x, 'value', int(x))) for x in getattr(data, 'curve_offset_data', ()) or ()]
        except Exception:
            offsets = []
        if len(offsets) >= 2:
            for a, b in zip(offsets[:-1], offsets[1:]):
                start = max(0, min(point_count, int(a)))
                end = max(start, min(point_count, int(b)))
                if end <= start:
                    continue
                curve_ranges.append((start, end))
                for i in range(start, end - 1):
                    edges.append((i, i + 1))
    if not curve_ranges and point_count > 1:
        curve_ranges.append((0, point_count))
        for i in range(point_count - 1):
            edges.append((i, i + 1))

    selected = [False] * point_count
    attr = None
    try:
        attrs = getattr(data, 'attributes', None)
        if attrs is not None:
            attr = attrs.get('.selection') or attrs.get('selection') or attrs.get('select')
    except Exception:
        attr = None
    try:
        domain = str(getattr(attr, 'domain', '') or '')
    except Exception:
        domain = ''
    if attr is not None and domain == 'CURVE':
        curve_sel = _curves_prop_attr_bool_values(attr, len(curve_ranges))
        for ci, flag in enumerate(curve_sel):
            if not flag or ci >= len(curve_ranges):
                continue
            start, end = curve_ranges[ci]
            for i in range(start, end):
                selected[i] = True
    elif attr is not None:
        vals = _curves_prop_attr_bool_values(attr, point_count)
        for i, flag in enumerate(vals):
            if i < point_count:
                selected[i] = bool(flag)

    try:
        import numpy as np
        ctrl_va = np.asarray(coords, dtype=np.float32)
        selected_va = np.asarray(selected, dtype=np.bool_)
        shape_va = np.asarray(coords, dtype=np.float32)
        shape_ei = np.asarray(edges, dtype=np.int32) if edges else np.empty((0, 2), dtype=np.int32)
    except Exception:
        ctrl_va = coords
        selected_va = selected
        shape_va = coords
        shape_ei = edges
    return ctrl_va, selected_va, shape_va, shape_ei


# -----------------------------------------------------------------------------
# UV proportional overlay support (SpaceImageEditor POST_PIXEL)
# -----------------------------------------------------------------------------
def _uv_prop_is_uv_editor_area(area) -> bool:
    try:
        from . import uv as _sos_uv
        detector = getattr(_sos_uv, '_area_is_uv_editor', None)
        if callable(detector):
            return bool(detector(area))
    except Exception:
        pass
    try:
        if area is None or getattr(area, 'type', None) != 'IMAGE_EDITOR':
            return False
        if str(getattr(area, 'ui_type', '') or '').upper() == 'UV':
            return True
        spaces = tuple(getattr(area, 'spaces', ()) or ())
        active = getattr(getattr(area, 'spaces', None), 'active', None)
        ordered = ((active,) if active is not None else ()) + tuple(item for item in spaces if item is not active)
        for space in ordered:
            if getattr(space, 'type', None) != 'IMAGE_EDITOR':
                continue
            if str(getattr(space, 'ui_type', '') or '').upper() == 'UV':
                return True
            if str(getattr(space, 'mode', '') or '').upper() == 'UV':
                return True
            if bool(getattr(space, 'show_uvedit', False)):
                return True
    except Exception:
        pass
    return False


def _uv_prop_first_uv_editor_context(context=None):
    try:
        ctx = context or getattr(bpy, 'context', None)
        from . import uv as _sos_uv
        target = next(iter(_sos_uv._uv_iter_live_editor_targets(ctx) or ()), None)
        if isinstance(target, dict):
            return (
                ctx,
                target.get('window'),
                target.get('screen'),
                target.get('area'),
                target.get('region'),
            )
    except Exception:
        pass
    return None


def _uv_prop_primary_edit_mesh_object(context=None):
    try:
        objs = _uv_prop_edit_mesh_objects(context or bpy.context)
        if objs:
            return objs[0]
    except Exception:
        pass
    return None


def _uv_prop_mode_flags(tool_settings):
    try:
        is_sync = bool(getattr(tool_settings, 'use_uv_select_sync', False))
    except Exception:
        is_sync = False
    if is_sync:
        try:
            flags = tuple(getattr(tool_settings, 'mesh_select_mode', (True, False, False)))
            return is_sync, bool(flags[0]), bool(flags[1]), bool(flags[2])
        except Exception:
            return is_sync, True, False, False
    try:
        mode = getattr(tool_settings, 'uv_select_mode', 'VERTEX')
        if isinstance(mode, str):
            text = mode.upper()
            return is_sync, ('VERTEX' in text), ('EDGE' in text), ('FACE' in text or 'ISLAND' in text)
        values = {str(v).upper() for v in mode}
        return is_sync, ('VERTEX' in values), ('EDGE' in values), ('FACE' in values or 'ISLAND' in values)
    except Exception:
        return is_sync, True, False, False


# Blender's native UV G/S/R keeps raw pointers into the loop custom data of the
# edit BMesh for the whole modal (TransData2D.loc2d).  Wrapping a BMesh element
# from Python adds a CD_BM_ELEM_PYPTR layer to that element type when none
# exists, and releasing the last BMesh wrapper removes it again; both reallocate
# the custom-data block of every element.  Reading loops that way while the
# transform runs left it writing UVs into freed memory: Cancel no longer
# restored the UVs and the heap was corrupted (EXCEPTION_ACCESS_VIOLATION in
# tbbmalloc / 0xC0000374, measured on 5.1.2 with no add-on installed).  The
# heatmap therefore keeps one wrapper per edit mesh alive ("pinned"), created
# while no transform runs, so the element layers already exist when a transform
# starts and are never removed while it runs.  A live read during a native
# transform is allowed only through such a pin.
_uv_prop_bm_pins = {}


def _uv_prop_pin_bmesh(obj, bm) -> None:
    """Pin ``bm`` for ``obj`` while no native UV transform runs."""
    try:
        for key in [k for k, v in _uv_prop_bm_pins.items() if not bool(getattr(v, 'is_valid', False))]:
            _uv_prop_bm_pins.pop(key, None)
    except Exception:
        pass
    try:
        key = int(obj.data.as_pointer())
        if _uv_prop_bm_pins.get(key) is bm:
            return
        # One wrapper of each element type creates every element layer now.
        next(iter(bm.verts), None)
        next(iter(bm.edges), None)
        face = next(iter(bm.faces), None)
        if face is not None:
            next(iter(face.loops), None)
        _uv_prop_bm_pins[key] = bm
    except Exception:
        pass


def _uv_prop_pinned_bmesh(obj):
    """Return the pinned edit BMesh of ``obj``, or None when no pin is current."""
    try:
        pinned = _uv_prop_bm_pins.get(int(obj.data.as_pointer()))
        if pinned is None or not bool(pinned.is_valid):
            return None
        if bmesh.from_edit_mesh(obj.data) is not pinned:
            return None
        return pinned
    except Exception:
        return None


def _uv_prop_release_bmesh_pins() -> None:
    try:
        _uv_prop_bm_pins.clear()
    except Exception:
        pass


def _uv_prop_collect_object_geometry(obj, tool_settings, context=None, connected_mode=False):
    if not _prop_uv_may_read_edit_bmesh(context):
        return None
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return None
    if _prop_uv_native_transform_active(context):
        bm = _uv_prop_pinned_bmesh(obj)
        if bm is None:
            return None
    else:
        try:
            bm = bmesh.from_edit_mesh(obj.data)
        except Exception:
            return None
        _uv_prop_pin_bmesh(obj, bm)
    try:
        bm.faces.ensure_lookup_table()
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
    except Exception:
        pass
    try:
        uv_layer = bm.loops.layers.uv.active
    except Exception:
        uv_layer = None
    if uv_layer is None:
        return None

    _is_sync, check_v, check_e, check_f = _uv_prop_mode_flags(tool_settings)
    # Blender 5.x keeps a per-corner UV selection beside the mesh selection.
    # With UV Sync Select it is honoured only while BMesh.uv_select_sync_valid
    # is True.  A selection change made on the mesh side (a click, select all,
    # select linked/more/less in the 3D View) clears that flag, and the UV
    # Editor, UV transform and proportional editing then follow the mesh
    # selection (uvedit_uv_select_test_ex / uvedit_edge_select_test_ex /
    # uvedit_face_select_test_ex).  Reading the stale per-corner flags in that
    # state kept the heatmap on the previously selected UVs.
    use_mesh_selection = False
    if _is_sync:
        try:
            use_mesh_selection = not bool(bm.uv_select_sync_valid)
        except Exception:
            use_mesh_selection = False
    # True while every UV selection state consulted for the active select modes
    # resolved to a definite answer.  The probe cascades below fall back through
    # several RNA spellings and can end in _MISSING, which means "could not be
    # determined", not "not selected".  Collapsing that to False is correct for
    # building `selected` -- an undeterminable element is not drawn -- but it is
    # not sound evidence that the user cleared the selection, so the flag is
    # reported separately and the draw path refuses to invalidate caches on it.
    selection_state_complete = True
    coords = []
    coord_loop_refs = []
    loop_face_refs = []
    loop_vertex_indices = []
    loop_selected_states = []
    face_loop_indices = []
    face_connected_visible = []
    edges = []
    selected = set()
    # UV proportional editing must be driven by UV Editor selection only.  Do not
    # use BMesh vertex/edge/face .select flags here: those can be changed from the
    # 3D View and would make the UV heatmap follow unrelated 3D mesh selection.
    uv_vertex_groups = {}

    try:
        mesh_data = getattr(obj, 'data', None)
        attrs = getattr(mesh_data, 'attributes', None)
    except Exception:
        attrs = None

    _MISSING = object()

    def _attr_bool_or_missing(name: str, index: int):
        if index is None or int(index) < 0:
            return _MISSING
        try:
            attr = attrs.get(name) if attrs is not None else None
            data = getattr(attr, 'data', None)
            if data is None:
                return _MISSING
            # In edit mode Blender 5.1 may expose the attribute shell with a
            # zero-length data array while live UV selection is stored in the
            # edit BMesh selection flags.  Treat that as unavailable rather than
            # as a hard False, otherwise the UV proportional overlay never sees
            # real UV Editor selections.
            if int(index) >= len(data):
                return _MISSING
            return bool(getattr(data[int(index)], 'value', False))
        except Exception:
            return _MISSING

    def _bool_member_or_missing(owner, names):
        for name in names:
            try:
                value = getattr(owner, name)
            except Exception:
                continue
            try:
                if callable(value):
                    value = value()
            except Exception:
                continue
            return bool(value)
        return _MISSING

    def _loop_uv_selected_state(loop, luv):
        if use_mesh_selection:
            try:
                if check_f:
                    return bool(loop.face.select)
                return bool(loop.vert.select)
            except Exception:
                return _MISSING
        state = _bool_member_or_missing(loop, ('uv_select_vert', 'select_vert'))
        if state is not _MISSING and bool(state):
            return True
        luv_state = _bool_member_or_missing(luv, ('select', 'select_vert', 'uv_select_vert')) if luv is not None else _MISSING
        if luv_state is not _MISSING and bool(luv_state):
            return True
        attr_state = _attr_bool_or_missing('.uv_select_vert', int(getattr(loop, 'index', -1)))
        if attr_state is not _MISSING:
            return bool(attr_state)
        if luv_state is not _MISSING:
            return bool(luv_state)
        if state is not _MISSING:
            return bool(state)
        return _MISSING

    def _loop_uv_edge_selected_state(loop, luv):
        if use_mesh_selection:
            try:
                if check_f:
                    return bool(loop.face.select)
                if check_e:
                    return bool(loop.edge.select)
                return bool(loop.vert.select) and bool(loop.link_loop_next.vert.select)
            except Exception:
                return _MISSING
        state = _bool_member_or_missing(loop, ('uv_select_edge', 'select_edge'))
        if state is not _MISSING and bool(state):
            return True
        luv_state = _bool_member_or_missing(luv, ('select_edge', 'edge_select', 'uv_select_edge')) if luv is not None else _MISSING
        if luv_state is not _MISSING and bool(luv_state):
            return True
        attr_state = _attr_bool_or_missing('.uv_select_edge', int(getattr(loop, 'index', -1)))
        if attr_state is not _MISSING:
            return bool(attr_state)
        if luv_state is not _MISSING:
            return bool(luv_state)
        if state is not _MISSING:
            return bool(state)
        return _MISSING

    def _face_uv_selected_state(face, loop_states) -> object:
        # Blender 5.1 exposes UV face selection on BMFace.uv_select.  Prefer it
        # over mesh face .select so 3D View face selection never becomes a UV
        # proportional source -- except with UV Sync while the UV selection is
        # not synchronized, where Blender itself uses the mesh face selection.
        if use_mesh_selection:
            try:
                return bool(face.select)
            except Exception:
                return _MISSING
        state = _bool_member_or_missing(face, ('uv_select',))
        if state is not _MISSING and bool(state):
            return True
        attr_state = _attr_bool_or_missing('.uv_select_face', int(getattr(face, 'index', -1)))
        if attr_state is not _MISSING:
            return bool(attr_state)
        if state is not _MISSING:
            return bool(state)
        available = [bool(v) for v in loop_states if v is not _MISSING]
        if available:
            return bool(available) and all(available)
        return _MISSING

    def _connected_loop_selected_state(loop, face, uv_vert_state):
        if _is_sync:
            try:
                if check_f:
                    return bool(getattr(face, 'select', False))
                return bool(getattr(loop.vert, 'select', False))
            except Exception:
                return _MISSING
        return uv_vert_state

    for face in bm.faces:
        try:
            if bool(getattr(face, 'hide', False)):
                continue
            # Without UV Sync the UV Editor shows, selects and transforms only
            # faces selected in the mesh (uvedit_face_visible_test_ex).  UV
            # selection left on faces that are no longer shown must neither
            # seed the heatmap nor be drawn.
            if not _is_sync and not bool(getattr(face, 'select', False)):
                continue
            loops = list(getattr(face, 'loops', ()) or ())
        except Exception:
            # The face could not be read at all, so whatever selection it
            # carried is unknown for this frame.
            selection_state_complete = False
            continue
        if not loops:
            continue
        loop_indices = []
        uv_vert_states = []
        for local_i, loop in enumerate(loops):
            try:
                luv = loop[uv_layer]
                uv = getattr(luv, 'uv', None)
                coords.append(Vector((float(uv[0]), float(uv[1]), 0.0)))
                coord_loop_refs.append((loop, face))
                loop_face_refs.append((int(getattr(face, 'index', -1)), int(local_i)))
                loop_vertex_indices.append(int(getattr(loop.vert, 'index', -1)))
                coord_index = len(coords) - 1
                loop_indices.append(coord_index)
                try:
                    key = (
                        int(getattr(loop.vert, 'index', -1)),
                        round(float(uv[0]), 7),
                        round(float(uv[1]), 7),
                    )
                    uv_vertex_groups.setdefault(key, []).append(coord_index)
                except Exception:
                    pass
                uv_vert_states.append(_loop_uv_selected_state(loop, luv))
            except Exception:
                loop_indices.append(-1)
                uv_vert_states.append(_MISSING)
                selection_state_complete = False
        face_uv_state = _face_uv_selected_state(face, uv_vert_states)
        for local_i, loop in enumerate(loops):
            idx = loop_indices[local_i]
            if idx < 0:
                continue
            try:
                uv_v = uv_vert_states[local_i]
                connected_selected = _connected_loop_selected_state(loop, face, uv_v)
                loop_selected_states.append(bool(connected_selected) if connected_selected is not _MISSING else False)
                # `selected` is built exactly as before: an indeterminate state
                # never adds an element.  The only addition is that the same
                # indeterminacy is recorded, so an empty `selected` tuple can be
                # told apart from a tuple that is empty because nothing could be
                # read.
                if connected_mode:
                    if connected_selected is _MISSING:
                        selection_state_complete = False
                    elif bool(connected_selected):
                        selected.add(idx)
                else:
                    if check_v:
                        if uv_v is _MISSING:
                            selection_state_complete = False
                        elif bool(uv_v):
                            selected.add(idx)
                    if check_f:
                        if face_uv_state is _MISSING:
                            selection_state_complete = False
                        elif bool(face_uv_state):
                            selected.add(idx)
            except Exception:
                loop_selected_states.append(False)
                selection_state_complete = False
        count = len(loop_indices)
        face_loop_indices.append(tuple(int(i) for i in loop_indices if int(i) >= 0))
        # Blender's uvedit_face_visible_test_ex() exposes every non-hidden face
        # with UV Sync, but only mesh-selected faces without Sync.  Keep all
        # accepted Euclidean coordinates, while recording the Connected Only
        # visibility authority separately.
        face_connected_visible.append(bool(_is_sync or getattr(face, 'select', False)))
        if count >= 2:
            for local_i, idx_a in enumerate(loop_indices):
                idx_b = loop_indices[(local_i + 1) % count]
                if idx_a < 0 or idx_b < 0:
                    continue
                edges.append((idx_a, idx_b))
                try:
                    loop = loops[local_i]
                    luv = loop[uv_layer]
                    uv_e = _loop_uv_edge_selected_state(loop, luv)
                    if (not connected_mode) and check_e:
                        if uv_e is _MISSING:
                            selection_state_complete = False
                        elif bool(uv_e):
                            selected.add(idx_a)
                            selected.add(idx_b)
                except Exception:
                    if (not connected_mode) and check_e:
                        selection_state_complete = False
    for group in uv_vertex_groups.values():
        try:
            if len(group) <= 1:
                continue
            base = int(group[0])
            for other in group[1:]:
                other = int(other)
                if base != other:
                    edges.append((base, other))
        except Exception:
            continue
    if not coords:
        return None
    return {
        'obj': obj,
        'object_ptr': int(obj.as_pointer()),
        'data_ptr': int(obj.data.as_pointer()),
        'coords': coords,
        'edges': tuple(edges),
        'selected': tuple(sorted(selected)),
        # Whether this frame could determine the UV selection state of every
        # element it returned.  Only a complete read may be used as evidence
        # that no selection exists (see _draw_callback_prop_uv_impl).
        'selection_state_complete': bool(selection_state_complete),
        'face_loop_indices': tuple(face_loop_indices),
        'face_connected_visible': tuple(face_connected_visible),
        'loop_face_refs': tuple(loop_face_refs),
        'loop_vertex_indices': tuple(loop_vertex_indices),
        'loop_selected_states': tuple(loop_selected_states),
    }


def _uv_prop_edit_mesh_objects(context):
    """Return edit-mode mesh objects for UV Editor draw callbacks.

    SpaceImageEditor POST_PIXEL callbacks can run with an Image Editor context
    whose edit_object / objects_in_mode slots are empty even though an edit mesh
    is active in the workspace.  The UV proportional overlay must use a broader,
    read-only lookup so the displayed UV heatmap does not disappear depending on
    which editor currently owns bpy.context.
    """
    seen = set()
    result = []

    def _add(candidate, *, force_edit=False, probe_edit_bmesh=False) -> None:
        try:
            if candidate is None or getattr(candidate, 'type', None) != 'MESH':
                return
            if probe_edit_bmesh:
                try:
                    bmesh.from_edit_mesh(candidate.data)
                    force_edit = True
                except Exception:
                    return
            mode = str(getattr(candidate, 'mode', '') or '')
            if not force_edit and mode not in {'EDIT', 'EDIT_MESH'}:
                try:
                    if not bool(candidate.select_get()):
                        return
                    bmesh.from_edit_mesh(candidate.data)
                except Exception:
                    return
            ptr = int(candidate.as_pointer())
            if ptr in seen:
                return
            seen.add(ptr)
            result.append(candidate)
        except Exception:
            return

    try:
        known_edit_ptrs = set()
        for attr in ('objects_in_mode_unique_data', 'objects_in_mode', 'selected_objects'):
            try:
                for candidate in getattr(context, attr, ()) or ():
                    force = attr in {'objects_in_mode_unique_data', 'objects_in_mode'}
                    if force:
                        try:
                            known_edit_ptrs.add(int(candidate.as_pointer()))
                        except Exception:
                            pass
                    _add(candidate, force_edit=force)
            except Exception:
                continue
        try:
            live_context = getattr(bpy, 'context', None)
        except Exception:
            live_context = None
        if live_context is not None and live_context is not context:
            for attr in ('objects_in_mode_unique_data', 'objects_in_mode', 'selected_objects'):
                try:
                    for candidate in getattr(live_context, attr, ()) or ():
                        force = attr in {'objects_in_mode_unique_data', 'objects_in_mode'}
                        if force:
                            try:
                                known_edit_ptrs.add(int(candidate.as_pointer()))
                            except Exception:
                                pass
                        _add(candidate, force_edit=force)
                except Exception:
                    continue
        for attr in ('edit_object', 'object', 'active_object'):
            try:
                _add(getattr(context, attr, None))
            except Exception:
                pass
        try:
            view_layer = getattr(context, 'view_layer', None) or getattr(bpy.context, 'view_layer', None)
            _add(getattr(getattr(view_layer, 'objects', None), 'active', None))
            for candidate in getattr(view_layer, 'objects', ()) or ():
                try:
                    force = int(candidate.as_pointer()) in known_edit_ptrs
                except Exception:
                    force = False
                _add(candidate, force_edit=force)
        except Exception:
            pass
        if not result:
            try:
                objs = getattr(getattr(context, 'view_layer', None), 'objects', None) or getattr(getattr(bpy.context, 'view_layer', None), 'objects', ())
                for candidate in objs or ():
                    _add(candidate)
            except Exception:
                pass
        # Last fallback after the context/view-layer lookups fail, or when an
        # Image Editor draw context found only the active edit mesh while Blender
        # still has additional selected edit meshes in multi-object edit mode.
        # The cheap selected/EDIT candidate count gates the broader bpy.data scan
        # so the accepted single-object UV path does not pay an unconditional
        # per-draw BMesh probing cost.
        needs_data_fallback = not result
        if not needs_data_fallback:
            try:
                if _uv_prop_is_uv_editor_area(getattr(context, 'area', None)) and len(result) < 2:
                    mesh_data_candidates = 0
                    for candidate in getattr(bpy.data, 'objects', ()) or ():
                        try:
                            if getattr(candidate, 'type', None) != 'MESH':
                                continue
                            mesh_data_candidates += 1
                            if mesh_data_candidates > len(result):
                                needs_data_fallback = True
                                break
                        except Exception:
                            continue
            except Exception:
                needs_data_fallback = False
        if needs_data_fallback:
            try:
                for candidate in getattr(bpy.data, 'objects', ()) or ():
                    _add(candidate, probe_edit_bmesh=True)
            except Exception:
                pass
    except Exception:
        pass
    return result

def _uv_prop_edge_to_quad(p1, p2, half_thickness: float):
    try:
        dx = float(p2[0]) - float(p1[0])
        dy = float(p2[1]) - float(p1[1])
        length = math.hypot(dx, dy)
        if length <= 1.0e-8:
            return ()
        nx = -dy / length * float(half_thickness)
        ny = dx / length * float(half_thickness)
        return (
            (float(p1[0]) + nx, float(p1[1]) + ny),
            (float(p1[0]) - nx, float(p1[1]) - ny),
            (float(p2[0]) - nx, float(p2[1]) - ny),
            (float(p2[0]) + nx, float(p2[1]) + ny),
        )
    except Exception:
        return ()


def _prop_view3d_pref_enabled(context=None) -> bool:
    try:
        prefs = _prefs(context or bpy.context)
        if prefs is None:
            return True
        return bool(getattr(prefs, 'prop_show_3d_view', True))
    except Exception:
        return True


def _uv_prop_pref_enabled(context=None) -> bool:
    try:
        prefs = _prefs(context or bpy.context)
        if prefs is None:
            return True
        return bool(getattr(prefs, 'prop_show_uv_editor', True))
    except Exception:
        return True


def _uv_prop_tool_enabled(tool_settings) -> bool:
    """Return True when Blender proportional editing is enabled for UV/edit use."""
    if tool_settings is None:
        return False
    for name in ('use_proportional_edit', 'use_proportional_edit_mask'):
        try:
            if bool(getattr(tool_settings, name, False)):
                return True
        except Exception:
            pass
    return False


def _uv_prop_tool_radius(tool_settings) -> float:
    """Use Blender's UV/editor radius when available, then fall back to mesh radius."""
    if tool_settings is None:
        return 0.0
    for name in ('proportional_size', 'proportional_distance'):
        try:
            value = float(getattr(tool_settings, name, 0.0) or 0.0)
            if value > 0.0:
                return value
        except Exception:
            pass
    return 0.0


def _uv_prop_region_size_for_pixel_projection(context=None):
    try:
        region = getattr(context or bpy.context, 'region', None)
        width = int(getattr(region, 'width', 0) or 0)
        height = int(getattr(region, 'height', 0) or 0)
        if width > 1 and height > 1:
            return width, height
    except Exception:
        pass
    try:
        viewport = tuple(gpu.state.viewport_get())
        if len(viewport) >= 4:
            width = int(viewport[2])
            height = int(viewport[3])
            if width > 1 and height > 1:
                return width, height
    except Exception:
        pass
    return 0, 0


def _uv_prop_push_region_pixel_projection(context=None):
    """Make POST_PIXEL UV coordinates deterministic on Blender 5.1+.

    Blender 5.1 no longer exposes the old 2D_* built-in color shaders.  The
    replacement SMOOTH_COLOR shader uses the current GPU matrix stack, so make
    the mapping explicit: (0, 0) is the bottom-left of the drawn Image Editor
    WINDOW region and (region.width, region.height) is the top-right.  The
    matrix is restored immediately after the UV proportional overlay pass so
    Blender's own UI and other panels keep their theme-defined alpha/appearance.
    """
    try:
        width, height = _uv_prop_region_size_for_pixel_projection(context)
        if width <= 1 or height <= 1:
            return False
        gpu.matrix.push()
        gpu.matrix.load_matrix(Matrix.Identity(4))
        gpu.matrix.load_projection_matrix(Matrix((
            (2.0 / float(width), 0.0, 0.0, -1.0),
            (0.0, 2.0 / float(height), 0.0, -1.0),
            (0.0, 0.0, 1.0, 0.0),
            (0.0, 0.0, 0.0, 1.0),
        )))
        return True
    except Exception:
        try:
            gpu.matrix.pop()
        except Exception:
            pass
        return False


def _uv_prop_region_point_is_valid(point, context=None) -> bool:
    try:
        x = float(point[0])
        y = float(point[1])
        if not math.isfinite(x) or not math.isfinite(y):
            return False
        # Blender returns INT_MIN-like sentinels before the Image Editor View2D is
        # initialized.  Do not upload those vertices; a later redraw will receive
        # valid region coordinates.
        if abs(x) > 10000000.0 or abs(y) > 10000000.0:
            return False
        width, height = _uv_prop_region_size_for_pixel_projection(context)
        margin = 4096.0
        if width > 1 and height > 1:
            return (-margin <= x <= float(width) + margin) and (-margin <= y <= float(height) + margin)
        return True
    except Exception:
        return False


def _uv_prop_draw_2d(edge_px, edge_colors, point_px, point_colors, overlay_line_width: float, overlay_point_size: float, aa_mode: str) -> None:
    """Draw UV proportional heatmap in the Image/UV Editor POST_PIXEL pass.

    Use the same current-pixel-coordinate path as the UV hover overlay.  The
    earlier smooth-color matrix override was valid for direct test calls, but on
    some Blender 5.1 UV Editor draw sequences it could be combined with an
    already-prepared POST_PIXEL matrix and leave the overlay outside the visible
    UV region.  Uniform-color batched quads are more conservative and match the
    editor's native 2D overlay pipeline.
    """
    try:
        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    except Exception:
        return

    def _color_tuple(color, alpha_mul: float = 1.0):
        try:
            return (
                max(0.0, min(1.0, float(color[0]))),
                max(0.0, min(1.0, float(color[1]))),
                max(0.0, min(1.0, float(color[2]))),
                max(0.0, min(1.0, float(color[3]) * float(alpha_mul))),
            )
        except Exception:
            return (1.0, 1.0, 1.0, max(0.0, min(1.0, float(alpha_mul))))

    def _mix_color(c1, c2, alpha_mul: float = 1.0):
        try:
            a = _color_tuple(c1, alpha_mul)
            b = _color_tuple(c2, alpha_mul)
            return ((a[0] + b[0]) * 0.5, (a[1] + b[1]) * 0.5, (a[2] + b[2]) * 0.5, max(a[3], b[3]))
        except Exception:
            return _color_tuple(c1, alpha_mul)

    def _key(color):
        c = _color_tuple(color, 1.0)
        return tuple(round(v, 3) for v in c)

    _draw_context = bpy.context
    try:
        _region_width, _region_height = _uv_prop_region_size_for_pixel_projection(_draw_context)
    except Exception:
        _region_width, _region_height = 0, 0
    _region_margin = 4096.0
    _region_has_bounds = _region_width > 1 and _region_height > 1
    _region_min_x = -_region_margin
    _region_min_y = -_region_margin
    _region_max_x = float(_region_width) + _region_margin
    _region_max_y = float(_region_height) + _region_margin

    def _point_valid(point) -> bool:
        try:
            x = float(point[0])
            y = float(point[1])
            if not math.isfinite(x) or not math.isfinite(y):
                return False
            if abs(x) > 10000000.0 or abs(y) > 10000000.0:
                return False
            if _region_has_bounds:
                return (_region_min_x <= x <= _region_max_x) and (_region_min_y <= y <= _region_max_y)
            return True
        except Exception:
            return False

    def _append_quad(groups, quad, color):
        if not quad:
            return
        try:
            for pt in quad:
                if not _point_valid(pt):
                    return
            k = _key(color)
            verts, indices = groups.setdefault(k, ([], []))
            base = len(verts)
            verts.extend((float(pt[0]), float(pt[1])) for pt in quad)
            indices.extend(((base, base + 1, base + 2), (base, base + 2, base + 3)))
        except Exception:
            return

    def _draw_groups(groups):
        for color, payload in groups.items():
            try:
                verts, indices = payload
                if not verts or not indices:
                    continue
                batch = batch_for_shader(shader, 'TRIS', {'pos': verts}, indices=indices)
                shader.bind()
                _prop_uniform_float(shader, 'color', color)
                batch.draw(shader)
            except Exception:
                continue

    edge_groups = {}
    point_groups = {}
    _sos_uv_projection_pushed = False
    try:
        # Blender 5.1 can call SpaceImageEditor POST_PIXEL handlers with a GPU
        # matrix that is not pixel-space for Python batches.  Constrain only this
        # UV proportional pass to the current Image Editor WINDOW region, then pop
        # the matrix before returning control to Blender UI/theme drawing.
        try:
            _sos_uv_projection_pushed = bool(_uv_prop_push_region_pixel_projection(_draw_context))
        except Exception:
            _sos_uv_projection_pushed = False
        _prop_state_set('blend', 'ALPHA')
        try:
            _prop_state_set('depth_test', 'NONE')
        except Exception:
            pass
        try:
            _prop_state_set('depth_mask', False)
        except Exception:
            pass

        def _edge_pass(width_mul: float, alpha_mul: float):
            half = max(0.5, float(overlay_line_width) * float(width_mul) * 0.5)
            target = {}
            for i in range(0, len(edge_px), 2):
                try:
                    p1 = edge_px[i]
                    p2 = edge_px[i + 1]
                    if not (_point_valid(p1) and _point_valid(p2)):
                        continue
                    color = _mix_color(edge_colors[i], edge_colors[i + 1], alpha_mul)
                    _append_quad(target, _uv_prop_edge_to_quad(p1, p2, half), color)
                except Exception:
                    continue
            _draw_groups(target)

        def _point_pass(size_mul: float, alpha_mul: float):
            half = max(1.0, float(overlay_point_size) * float(size_mul) * 0.5)
            target = {}
            for p, c in zip(point_px, point_colors):
                try:
                    if not _point_valid(p):
                        continue
                    x = float(p[0])
                    y = float(p[1])
                    quad = ((x - half, y - half), (x + half, y - half), (x + half, y + half), (x - half, y + half))
                    _append_quad(target, quad, _color_tuple(c, alpha_mul))
                except Exception:
                    continue
            _draw_groups(target)

        if aa_mode == 'AA_2PASS':
            _edge_pass(1.0 + (1.0 / max(1.0, float(overlay_line_width))), 0.18)
        _edge_pass(1.0, 1.0)
        if aa_mode == 'AA_2PASS':
            _point_pass(1.0 + (2.0 / max(1.0, float(overlay_point_size))), 0.22)
        _point_pass(1.0, 1.0)
    except Exception:
        pass
    finally:
        if _sos_uv_projection_pushed:
            try:
                gpu.matrix.pop()
            except Exception:
                pass
        try:
            mesh._sos_reset_gpu_state_after_draw()
        except Exception:
            pass


def _uv_prop_coord_tuple(co):
    try:
        return (float(co.x), float(co.y))
    except Exception:
        try:
            return (float(co[0]), float(co[1]))
        except Exception:
            return None


def _uv_prop_coord_vector(co):
    try:
        return Vector((float(co[0]), float(co[1]), 0.0))
    except Exception:
        try:
            return Vector((float(co.x), float(co.y), 0.0))
        except Exception:
            return None


def _uv_prop_transform_aspect(context=None):
    """Mirror Blender's ED_space_image_get_uv_aspect normalization."""
    try:
        ctx = context or bpy.context
        space = getattr(ctx, 'space_data', None)
        image = getattr(space, 'image', None)
        size = tuple(getattr(image, 'size', ()) or ()) if image is not None else ()
        width = max(1.0, float(size[0])) if len(size) >= 2 else 1.0
        height = max(1.0, float(size[1])) if len(size) >= 2 else 1.0
        display_aspect = tuple(getattr(image, 'display_aspect', ()) or ()) if image is not None else ()
        aspect_x = float(display_aspect[0]) if len(display_aspect) >= 2 else 1.0
        aspect_y = float(display_aspect[1]) if len(display_aspect) >= 2 else 1.0
        aspect_x = max(1.0e-12, aspect_x * width)
        aspect_y = max(1.0e-12, aspect_y * height)
        if aspect_x < aspect_y:
            return (1.0, float(aspect_y / aspect_x))
        return (float(aspect_x / aspect_y), 1.0)
    except Exception:
        return (1.0, 1.0)


def _uv_prop_connected_distances(entry, radius: float, aspect=(1.0, 1.0)):
    """Reproduce Blender's uv_set_connectivity_distance() graph.

    Every visible face is a complete UV-distance graph.  Loops at the same mesh
    vertex connect at zero cost only when their UV coordinates and UV selection
    states match.  The latter is Blender's ripped/split boundary rule.
    """
    coords = tuple(entry.get('coord_vectors') or entry.get('coords') or ())
    selected = tuple(int(i) for i in (entry.get('selected') or ()))
    face_loops = tuple(entry.get('face_loop_indices') or ())
    face_visible = tuple(entry.get('face_connected_visible') or ())
    vert_indices = tuple(entry.get('loop_vertex_indices') or ())
    selected_states = tuple(bool(v) for v in (entry.get('loop_selected_states') or ()))
    count = len(coords)
    if not count or not selected:
        return {}
    if len(vert_indices) != count or len(selected_states) != count:
        return {}

    loop_face = [None] * count
    visible_indices = set()
    for face_index, indices in enumerate(face_loops):
        if face_index < len(face_visible) and not bool(face_visible[face_index]):
            continue
        frozen = tuple(int(i) for i in indices if 0 <= int(i) < count)
        for index in frozen:
            loop_face[index] = frozen
            visible_indices.add(index)

    zero_groups = {}
    for index in visible_indices:
        co = _uv_prop_coord_tuple(coords[index])
        if co is None:
            continue
        key = (int(vert_indices[index]), float(co[0]), float(co[1]), bool(selected_states[index]))
        zero_groups.setdefault(key, []).append(index)

    limit = max(0.0, float(radius))
    aspect_x = float(aspect[0]) if aspect else 1.0
    aspect_y = float(aspect[1]) if aspect else 1.0
    distances = {}
    queue = []
    for index in selected:
        if index in visible_indices and 0 <= index < count:
            distances[index] = 0.0
            heapq.heappush(queue, (0.0, index))

    while queue:
        dist, index = heapq.heappop(queue)
        if dist != distances.get(index):
            continue
        if dist > limit:
            continue
        co = _uv_prop_coord_tuple(coords[index])
        if co is None:
            continue
        face = loop_face[index]
        if face:
            for other in face:
                if other == index:
                    continue
                other_co = _uv_prop_coord_tuple(coords[other])
                if other_co is None:
                    continue
                dx = (float(other_co[0]) - float(co[0])) * aspect_x
                dy = (float(other_co[1]) - float(co[1])) * aspect_y
                candidate = float(dist) + math.hypot(dx, dy)
                if candidate <= limit and candidate < distances.get(other, float('inf')):
                    distances[other] = candidate
                    heapq.heappush(queue, (candidate, other))
        key = (int(vert_indices[index]), float(co[0]), float(co[1]), bool(selected_states[index]))
        for other in zero_groups.get(key, ()):
            if dist < distances.get(other, float('inf')):
                distances[other] = float(dist)
                heapq.heappush(queue, (float(dist), other))
    return distances


def _uv_prop_connected_distances_cached(entry, radius: float, aspect=(1.0, 1.0)):
    try:
        key = (
            round(float(radius), 7),
            tuple(round(float(v), 7) for v in (aspect or (1.0, 1.0))),
        )
    except Exception:
        key = (float(radius or 0.0), (1.0, 1.0))
    try:
        cache = entry.get('_connected_distance_cache')
        if not isinstance(cache, dict):
            cache = {}
            entry['_connected_distance_cache'] = cache
        cached = cache.get(key)
        if cached is not None:
            return cached
    except Exception:
        cache = None
    distances = _uv_prop_connected_distances(entry, radius, aspect)
    try:
        if cache is not None:
            cache[key] = distances
    except Exception:
        pass
    return distances


def _uv_prop_connected_cache_signature(entry):
    try:
        coords = tuple(_uv_prop_coord_tuple(co) for co in (entry.get('coords') or ()))
        if any(co is None for co in coords):
            return None
        return (
            tuple((round(x, 7), round(y, 7)) for x, y in coords),
            tuple(int(i) for i in (entry.get('selected') or ())),
            tuple(tuple(int(i) for i in face) for face in (entry.get('face_loop_indices') or ())),
            tuple(bool(v) for v in (entry.get('face_connected_visible') or ())),
            tuple(int(i) for i in (entry.get('loop_vertex_indices') or ())),
            tuple(bool(v) for v in (entry.get('loop_selected_states') or ())),
            tuple(round(float(v), 7) for v in (entry.get('aspect') or (1.0, 1.0))),
        )
    except Exception:
        return None


def _uv_prop_adopt_connected_distance_cache(entry, cached_entry) -> None:
    try:
        if not isinstance(entry, dict) or not isinstance(cached_entry, dict):
            return
        cache = cached_entry.get('_connected_distance_cache')
        if not isinstance(cache, dict) or not cache:
            return
        signature = _uv_prop_connected_cache_signature(entry)
        if signature is None or signature != _uv_prop_connected_cache_signature(cached_entry):
            return
        entry['_connected_distance_cache'] = dict(cache)
    except Exception:
        pass


def _uv_prop_store_geometry_cache(cache_key, prepared) -> None:
    if cache_key is None:
        return
    try:
        frozen = []
        for entry in prepared or ():
            coords = []
            for co in entry.get('coords') or ():
                item = _uv_prop_coord_tuple(co)
                if item is not None:
                    coords.append(item)
            selected = tuple(int(i) for i in (entry.get('selected') or ()) if 0 <= int(i) < len(coords))
            edges = tuple((int(a), int(b)) for a, b in _iter_lattice_edge_pairs(entry.get('edges') or ()))
            if coords and selected:
                coord_vectors = tuple(Vector((float(co[0]), float(co[1]), 0.0)) for co in coords)
                frozen_entry = {
                    'object_ptr': int(entry.get('object_ptr', 0) or 0),
                    'data_ptr': int(entry.get('data_ptr', 0) or 0),
                    'coords': tuple(coords),
                    'coord_vectors': coord_vectors,
                    'edges': edges,
                    'selected': selected,
                    'selected_vectors': tuple(coord_vectors[int(i)] for i in selected),
                    'face_loop_indices': tuple(tuple(int(i) for i in face) for face in (entry.get('face_loop_indices') or ())),
                    'face_connected_visible': tuple(bool(v) for v in (entry.get('face_connected_visible') or ())),
                    'loop_face_refs': tuple((int(a), int(b)) for a, b in (entry.get('loop_face_refs') or ())),
                    'loop_vertex_indices': tuple(int(i) for i in (entry.get('loop_vertex_indices') or ())),
                    'loop_selected_states': tuple(bool(v) for v in (entry.get('loop_selected_states') or ())),
                    'aspect': tuple(float(v) for v in (entry.get('aspect') or (1.0, 1.0))),
                }
                try:
                    distance_cache = entry.get('_connected_distance_cache')
                    if isinstance(distance_cache, dict) and distance_cache:
                        frozen_entry['_connected_distance_cache'] = dict(distance_cache)
                except Exception:
                    pass
                frozen.append(frozen_entry)
        if frozen:
            _uv_prop_geometry_cache[cache_key] = {
                'time': time.time(),
                'prepared': tuple(frozen),
            }
    except Exception:
        pass


def _uv_prop_initial_geometry_for_live_transform(cache_key, live_prepared):
    """Return pre-transform geometry matched to live objects, or None."""
    try:
        cached = _uv_prop_geometry_cache.get(cache_key) if cache_key is not None else None
        frozen = tuple((cached or {}).get('prepared') or ())
        if not frozen or len(frozen) != len(tuple(live_prepared or ())):
            return None
        by_object = {
            (int(entry.get('object_ptr', 0)), int(entry.get('data_ptr', 0))): entry
            for entry in frozen
        }
        matched = []
        for live in live_prepared or ():
            key = (int(live.get('object_ptr', 0)), int(live.get('data_ptr', 0)))
            initial = by_object.get(key)
            if not initial:
                return None
            if len(tuple(initial.get('coords') or ())) != len(tuple(live.get('coords') or ())):
                return None
            if tuple(initial.get('selected') or ()) != tuple(live.get('selected') or ()):
                return None
            if tuple(initial.get('loop_vertex_indices') or ()) != tuple(live.get('loop_vertex_indices') or ()):
                return None
            matched.append(initial)
        return tuple(matched)
    except Exception:
        return None


def _uv_prop_collect_live_transform_geometry(obj, cached_entry, context=None):
    """Read only current UV coordinates using cached face/loop topology."""
    if not _prop_uv_native_transform_active(context):
        return None
    try:
        if int(obj.as_pointer()) != int(cached_entry.get('object_ptr', 0)):
            return None
        if int(obj.data.as_pointer()) != int(cached_entry.get('data_ptr', 0)):
            return None
        refs = tuple(cached_entry.get('loop_face_refs') or ())
        if not refs or len(refs) != len(tuple(cached_entry.get('coords') or ())):
            return None
        bm = _uv_prop_pinned_bmesh(obj)
        if bm is None:
            return None
        bm.faces.ensure_lookup_table()
        uv_layer = bm.loops.layers.uv.active
        if uv_layer is None:
            return None
        coords = []
        for face_index, local_index in refs:
            face = bm.faces[int(face_index)]
            loops = tuple(getattr(face, 'loops', ()) or ())
            loop = loops[int(local_index)]
            uv = loop[uv_layer].uv
            coords.append(Vector((float(uv[0]), float(uv[1]), 0.0)))
        live = dict(cached_entry)
        live.pop('coord_vectors', None)
        live.pop('selected_vectors', None)
        live['obj'] = obj
        live['coords'] = coords
        return live
    except Exception:
        return None


def _uv_prop_collect_live_transform_coord_map(obj, cached_entry, indices):
    """Read current UV coordinates only for influenced cached loop indices."""
    if not _prop_uv_native_transform_active(context=None):
        return None
    try:
        if int(obj.as_pointer()) != int(cached_entry.get('object_ptr', 0)):
            return None
        if int(obj.data.as_pointer()) != int(cached_entry.get('data_ptr', 0)):
            return None
        refs = tuple(cached_entry.get('loop_face_refs') or ())
        coords = tuple(cached_entry.get('coords') or ())
        if not refs or len(refs) != len(coords):
            return None
        wanted = tuple(sorted({int(i) for i in (indices or ()) if 0 <= int(i) < len(refs)}))
        if not wanted:
            return {}
        bm = _uv_prop_pinned_bmesh(obj)
        if bm is None:
            return None
        bm.faces.ensure_lookup_table()
        uv_layer = bm.loops.layers.uv.active
        if uv_layer is None:
            return None
        out = {}
        for index in wanted:
            face_index, local_index = refs[int(index)]
            face = bm.faces[int(face_index)]
            loops = tuple(getattr(face, 'loops', ()) or ())
            loop = loops[int(local_index)]
            uv = loop[uv_layer].uv
            out[int(index)] = Vector((float(uv[0]), float(uv[1]), 0.0))
        return out
    except Exception:
        return None


def _uv_prop_clear_draw_caches() -> None:
    """Drop every cached UV proportional draw product.

    Called only when the draw path has read the edit BMesh and found no UV
    element selected.  Both caches describe a selection that no longer exists,
    so keeping them lets a later frame replay geometry for a selection the user
    has already cleared.  They are cleared whole rather than per region because
    UV selection belongs to the edit mesh, not to a region: when it is empty no
    region's cached product is valid.
    """
    try:
        _uv_prop_stale_draw_cache.clear()
    except Exception:
        pass
    try:
        _uv_prop_geometry_cache.clear()
    except Exception:
        pass


def _uv_prop_draw_budget_plan(prepared) -> dict:
    """Decide how one draw may spend its budget, before any per-element work.

    The decision is taken from element counts alone, so a draw never computes
    part of a distance field and then abandons it: either the whole field fits
    in the budget and the output is exactly what an unbudgeted draw produced, or
    the draw falls back to the selected elements alone.  Selected elements carry
    proportional influence 1.0 by definition, so the reduced output is a
    correctly coloured subset -- never stale, never mislabelled, and non-empty
    whenever a UV selection exists.
    """
    elements = 0
    selected_total = 0
    edge_pairs = 0
    for entry in prepared or ():
        try:
            elements += len(entry.get('coords') or ())
            selected_total += len(entry.get('selected') or ())
            edge_pairs += len(entry.get('edges') or ())
        except Exception:
            continue
    if elements <= _UV_PROP_DRAW_BUDGET_ELEMENTS:
        # allow_edges is a defence-in-depth assertion that cannot fire for
        # collector-produced geometry: see _UV_PROP_DRAW_BUDGET_EDGE_PAIRS for
        # the counting argument that bounds edge pairs at 2 * elements - n.
        return {
            'mode': 'EXACT',
            'allow_edges': edge_pairs <= _UV_PROP_DRAW_BUDGET_EDGE_PAIRS,
            'elements': elements,
            'selected': selected_total,
            'edge_pairs': edge_pairs,
        }
    return {
        'mode': 'REDUCED',
        'allow_edges': False,
        'elements': elements,
        'selected': selected_total,
        'edge_pairs': edge_pairs,
    }


def _uv_prop_draw_selected_core(prepared, context, v2d, gradient_stops, alpha_mul, overlay_line_width: float, overlay_point_size: float, aa_mode: str, cache_key=None) -> bool:
    """Emit the selected UV elements alone, bounded by the draw budget.

    Reached only when the element total already exceeds the budget.  Every point
    emitted here is a genuinely selected element drawn at full influence, so the
    frame is a strict subset of the exact overlay rather than an approximation
    of it.  Edges are not walked, because the lattice edge list is proportional
    to the element total this path exists to avoid.

    When a cache key is supplied the bounded pixel product is stored in the
    stale draw cache, so the overlay stays visible for its usual short window
    while the edit BMesh is unreadable.  The geometry cache is deliberately not
    written: freezing it costs work proportional to the element total, and a
    reduced frame must never be able to masquerade as a complete one.

    The budget is *filled*, not strided.  A per-entry quota is handed out by a
    running integer floor, so the quotas sum to exactly the cap and the frame
    always shows as many selected elements as it is allowed -- selecting four
    more loops can no longer halve the overlay.  All arithmetic is integer, so
    the chosen indices depend only on the prepared list and are identical on
    every machine; nothing here consults a clock, a hash, or a float rounding
    mode.  Within an entry the positions are spread evenly across that entry's
    own selection and are strictly increasing, so the emitted set is always a
    stable, order-preserving subset of the selected elements -- the same
    property the strided version had, at the density the budget allows.
    """
    point_px = []
    point_colors = []
    try:
        color = alpha_mul(get_heatmap_color(1.0, gradient_stops, prepared=True))
    except Exception:
        return False
    cap = int(_UV_PROP_DRAW_BUDGET_SELECTED)
    if cap <= 0:
        return False
    # Derive the total from the entries this draw will actually use rather than
    # from a separately computed figure: an entry counted in one place and
    # skipped in the other would silently under-fill the budget.
    usable = []
    total = 0
    for entry in prepared or ():
        coords = entry.get('coords') or ()
        selected = tuple(entry.get('selected') or ())
        if not coords or not selected:
            continue
        usable.append((coords, selected))
        total += len(selected)
    if total <= 0:
        return False
    emitted = 0
    consumed = 0
    allocated = 0
    for coords, selected in usable:
        count = len(selected)
        consumed += count
        if total <= cap:
            quota = count
        else:
            # Running-floor proportional allocation.  `allocated` is always
            # floor(previous consumed * cap / total), so this difference of
            # floors sums to exactly `cap` across all entries.  quota <= count
            # holds because cap < total on this branch, which makes
            # floor(count * cap / total) <= count - 1.
            quota = ((consumed * cap) // total) - allocated
        allocated += quota
        if quota <= 0:
            continue
        for i in range(quota):
            # Defence in depth: the quotas already sum to at most the cap, so
            # this can only fire if that invariant is ever broken.
            if emitted >= cap:
                break
            position = (i * count) // quota
            try:
                index = int(selected[position])
            except Exception:
                continue
            if index < 0 or index >= len(coords):
                continue
            co = coords[index]
            if co is None:
                continue
            try:
                px = v2d.view_to_region(float(co[0]), float(co[1]), clip=False)
                if px is None:
                    continue
                p = (float(px[0]), float(px[1]))
                if not _uv_prop_region_point_is_valid(p, context):
                    continue
            except Exception:
                continue
            point_px.append(p)
            point_colors.append(color)
            emitted += 1
    if not point_px:
        return False
    if cache_key is not None:
        try:
            _uv_prop_stale_draw_cache[cache_key] = {
                'time': time.time(),
                'edge_px': (),
                'edge_colors': (),
                'point_px': tuple(point_px),
                'point_colors': tuple(point_colors),
                'line_width': float(overlay_line_width),
                'point_size': float(overlay_point_size),
                'aa_mode': str(aa_mode),
            }
        except Exception:
            pass
    _uv_prop_draw_2d((), (), point_px, point_colors, overlay_line_width, overlay_point_size, aa_mode)
    return True


def _uv_prop_draw_cached_geometry(cache_key, context, radius: float, falloff_type: str, gradient_stops, alpha_mul, overlay_line_width: float, overlay_point_size: float, aa_mode: str) -> bool:
    try:
        if cache_key is None:
            return False
        cached = _uv_prop_geometry_cache.get(cache_key)
        if not cached:
            return False
        if (time.time() - float(cached.get('time', 0.0) or 0.0)) > _UV_PROP_GEOMETRY_CACHE_SECONDS:
            return False
        prepared = cached.get('prepared') or ()
        if not prepared:
            return False
        region = getattr(context, 'region', None)
        v2d = getattr(region, 'view2d', None)
        if v2d is None:
            return False

        plan = _uv_prop_draw_budget_plan(prepared)
        if plan['mode'] == 'REDUCED':
            return _uv_prop_draw_selected_core(
                prepared, context, v2d, gradient_stops, alpha_mul,
                overlay_line_width, overlay_point_size, aa_mode)

        global_sel_coords = []
        for entry in prepared:
            coords = entry.get('coords') or ()
            selected_vectors = entry.get('selected_vectors') or ()
            if selected_vectors:
                global_sel_coords.extend(vec for vec in selected_vectors if vec is not None)
            else:
                for idx in entry.get('selected') or ():
                    if 0 <= int(idx) < len(coords):
                        vec = _uv_prop_coord_vector(coords[int(idx)])
                        if vec is not None:
                            global_sel_coords.append(vec)
        if not global_sel_coords:
            return False

        kd_global = KDTree(len(global_sel_coords))
        for i, co in enumerate(global_sel_coords):
            kd_global.insert(co, int(i))
        kd_global.balance()

        all_point_px, all_point_colors = [], []
        all_edge_px, all_edge_colors = [], []
        for entry in prepared:
            coords = entry.get('coords') or ()
            coord_vectors = entry.get('coord_vectors') or ()
            selected = tuple(int(i) for i in (entry.get('selected') or ()))
            if not coords or not selected:
                continue
            sel_lookup = set(selected) if len(selected) > 8 else selected
            valid_indices = set()
            color_map = {}
            uv_to_px = {}
            for i, co in enumerate(coords):
                try:
                    vec = coord_vectors[i] if i < len(coord_vectors) else _uv_prop_coord_vector(co)
                except Exception:
                    vec = _uv_prop_coord_vector(co)
                if vec is None:
                    continue
                try:
                    if i in sel_lookup:
                        dist = 0.0
                    else:
                        _found, _idx, dist = kd_global.find(vec)
                except Exception:
                    continue
                influence = get_falloff_intensity(float(dist), radius, falloff_type)
                if influence <= 0.0:
                    continue
                color = alpha_mul(get_heatmap_color(influence, gradient_stops, prepared=True))
                try:
                    px = v2d.view_to_region(float(co[0]), float(co[1]), clip=False)
                    if px is None:
                        continue
                    p = (float(px[0]), float(px[1]))
                    if not _uv_prop_region_point_is_valid(p, context):
                        continue
                except Exception:
                    continue
                all_point_px.append(p)
                all_point_colors.append(color)
                valid_indices.add(int(i))
                color_map[int(i)] = color
                uv_to_px[int(i)] = p
            if not valid_indices:
                continue
            seen_edges = set()
            for a, b in (_iter_lattice_edge_pairs(entry.get('edges') or ()) if plan['allow_edges'] else ()):
                if a not in valid_indices or b not in valid_indices:
                    continue
                key = (min(a, b), max(a, b))
                if key in seen_edges:
                    continue
                seen_edges.add(key)
                pa = uv_to_px.get(a)
                pb = uv_to_px.get(b)
                if pa is None or pb is None:
                    continue
                all_edge_px.extend((pa, pb))
                all_edge_colors.extend((color_map[a], color_map[b]))

        if not all_point_px and not all_edge_px:
            return False
        _uv_prop_draw_2d(all_edge_px, all_edge_colors, all_point_px, all_point_colors, overlay_line_width, overlay_point_size, aa_mode)
        return True
    except Exception:
        return False

def _draw_callback_prop_uv_impl():
    try:
        if mesh._sos_should_skip_custom_draw_for_selection():
            try:
                mesh._sos_reset_gpu_state_after_draw()
            except Exception:
                pass
            return
    except Exception:
        pass
    context = bpy.context
    wm = getattr(context, 'window_manager', None)
    if wm is None or not bool(getattr(wm, 'sos_proportional_overlay_enabled', False)):
        return
    if not _uv_prop_pref_enabled(context):
        return
    try:
        area = getattr(context, 'area', None)
        region = getattr(context, 'region', None)
        if not _uv_prop_is_uv_editor_area(area):
            return
        if region is None or getattr(region, 'type', '') != 'WINDOW':
            return
        v2d = getattr(region, 'view2d', None)
        if v2d is None:
            return
    except Exception:
        return
    try:
        _uv_prop_cache_key = (int(area.as_pointer()), int(region.as_pointer()))
    except Exception:
        _uv_prop_cache_key = None

    edit_objs_for_uv = _uv_prop_edit_mesh_objects(context)
    if not edit_objs_for_uv:
        return
    tool_settings = getattr(context, 'tool_settings', None)
    if tool_settings is None:
        return
    if not _uv_prop_tool_enabled(tool_settings):
        return
    if _prop_native_transform_running(context):
        return

    prefs, overlay_point_size, overlay_line_width, heatmap_alpha, _heatmap_xray, gradient_stops, aa_mode = _prop_style_from_prefs(context)
    alpha_mul = _prop_alpha_mul_factory(heatmap_alpha)
    radius = _uv_prop_tool_radius(tool_settings)
    if radius <= 0.0:
        return
    falloff_type = str(getattr(tool_settings, 'proportional_edit_falloff', 'SMOOTH') or 'SMOOTH')
    if not _prop_uv_may_read_edit_bmesh(context):
        if _uv_prop_draw_cached_geometry(_uv_prop_cache_key, context, radius, falloff_type, gradient_stops, alpha_mul, overlay_line_width, overlay_point_size, aa_mode):
            return
        try:
            stale = _uv_prop_stale_draw_cache.get(_uv_prop_cache_key) if _uv_prop_cache_key is not None else None
            if stale and (time.time() - float(stale.get('time', 0.0) or 0.0)) <= _UV_PROP_STALE_CACHE_SECONDS:
                _uv_prop_draw_2d(stale.get('edge_px') or (), stale.get('edge_colors') or (), stale.get('point_px') or (), stale.get('point_colors') or (), float(stale.get('line_width', 2.0) or 2.0), float(stale.get('point_size', 4.0) or 4.0), str(stale.get('aa_mode') or 'AA_2PASS'))
        except Exception:
            pass
        return
    # Connected Only follows Blender's UV transform graph.  The accepted OFF
    # path remains the existing global Euclidean distance field.
    use_connected = bool(getattr(tool_settings, 'use_proportional_connected', False))
    live_transform = bool(_prop_uv_native_transform_active(context))
    transform_aspect = _uv_prop_transform_aspect(context)

    prepared = []
    cached_by_object = {}
    try:
        cached_record = _uv_prop_geometry_cache.get(_uv_prop_cache_key) or {}
        cached_by_object = {
            (int(item.get('object_ptr', 0)), int(item.get('data_ptr', 0))): item
            for item in tuple(cached_record.get('prepared') or ())
        }
    except Exception:
        cached_by_object = {}
    # Clearing the caches asserts a global fact -- that no UV selection exists
    # anywhere in this edit session -- so the evidence for it must be global
    # too.  Conclusiveness is therefore an AND over the edit objects, never an
    # OR: one object's successful read must not authorise discarding another
    # object's live selection.  `probed` counts objects that were freshly read
    # from the edit BMesh this frame, that returned geometry, and whose UV
    # selection state was fully determinate; `failed` latches if any object
    # returned None, raised, had no usable coordinates, or could not have its
    # selection state determined.  A None return already covers the missing UV
    # layer, unreadable BMesh and hidden-only-geometry cases, because the
    # collector returns None for each of them.  Anything short of a complete
    # reading of every edit object leaves both caches untouched, which is what
    # keeps the <= 2 second stale-overlay bridge alive across a transient
    # collector failure.  The transform and cache-replay paths reuse a stored
    # selection and can never prove one is absent, so they never contribute.
    selection_probe_objects = 0
    selection_probe_failed = False
    try:
        selection_probe_required = len(edit_objs_for_uv)
    except Exception:
        selection_probe_required = -1
    for obj in edit_objs_for_uv:
        try:
            entry = None
            fresh_read = False
            cached_entry = cached_by_object.get((int(obj.as_pointer()), int(obj.data.as_pointer())))
            if live_transform:
                if use_connected and cached_entry is not None:
                    entry = dict(cached_entry)
                    entry['obj'] = obj
                    entry['_live_connected_transform'] = True
                elif cached_entry is not None:
                    entry = _uv_prop_collect_live_transform_geometry(obj, cached_entry, context)
            if entry is None:
                entry = _uv_prop_collect_object_geometry(
                    obj, tool_settings, context, connected_mode=use_connected)
                fresh_read = bool(entry)
                if use_connected and not live_transform and cached_entry is not None:
                    _uv_prop_adopt_connected_distance_cache(entry, cached_entry)
            if not entry:
                selection_probe_failed = True
                continue
            coords = entry.get('coords') or ()
            selected = entry.get('selected') or ()
            if not live_transform:
                if (fresh_read and coords
                        and bool(entry.get('selection_state_complete', False))):
                    selection_probe_objects += 1
                else:
                    selection_probe_failed = True
            if not coords or not selected:
                continue
            entry['aspect'] = tuple(transform_aspect)
            prepared.append(entry)
        except Exception:
            selection_probe_failed = True
            continue
    if not prepared:
        if (not live_transform
                and not selection_probe_failed
                and selection_probe_required > 0
                and selection_probe_objects == selection_probe_required):
            # Every edit object was freshly read this frame, every read
            # succeeded, and every UV selection state was determinate, so the
            # absence of a selection is established rather than assumed.  Only
            # now may both caches be dropped, so no later frame can replay the
            # heatmap of a selection the user has cleared.
            _uv_prop_clear_draw_caches()
        return

    # Bound this draw before any per-element work begins.  Over the budget the
    # frame emits the selected elements alone and stores only that bounded
    # pixel product: the unbounded geometry freeze is skipped, so a reduced
    # frame can never be promoted into the geometry cache and replayed as if it
    # were complete.
    plan = _uv_prop_draw_budget_plan(prepared)
    if plan['mode'] == 'REDUCED':
        drew = _uv_prop_draw_selected_core(
            prepared, context, v2d, gradient_stops, alpha_mul,
            overlay_line_width, overlay_point_size, aa_mode,
            cache_key=_uv_prop_cache_key)
        if not drew:
            try:
                _tag_prop_overlay_redraw(context)
            except Exception:
                pass
        return

    # Blender computes proportional distances from coordinates captured at the
    # start of the transform.  During G/S/R, draw live positions but retain the
    # cached pre-transform distance field so heatmap colors stay identical to
    # Blender's actual weights.
    distance_prepared = tuple(prepared)
    if live_transform:
        initial = _uv_prop_initial_geometry_for_live_transform(_uv_prop_cache_key, prepared)
        if initial:
            distance_prepared = initial
    else:
        pass

    global_sel_coords = []
    for entry in distance_prepared:
        coords = entry.get('coord_vectors') or entry.get('coords') or ()
        for idx in entry.get('selected') or ():
            if 0 <= int(idx) < len(coords):
                global_sel_coords.append(coords[int(idx)])
    if not global_sel_coords:
        return

    kd_global = None
    if not use_connected:
        try:
            kd_global = KDTree(len(global_sel_coords))
            for i, co in enumerate(global_sel_coords):
                kd_global.insert(co, int(i))
            kd_global.balance()
        except Exception:
            kd_global = None
        if kd_global is None:
            return

    all_point_px, all_point_colors = [], []
    all_edge_px, all_edge_colors = [], []
    invalid_region_coordinate_seen = False

    def _append_uv_heat_point(idx, co, influence, valid_indices, color_map, uv_to_px):
        nonlocal invalid_region_coordinate_seen
        try:
            idx = int(idx)
            if float(influence) <= 0.0 or co is None:
                return
            px = v2d.view_to_region(float(co.x), float(co.y), clip=False)
            if px is None:
                return
            p = (float(px[0]), float(px[1]))
            if not _uv_prop_region_point_is_valid(p, context):
                invalid_region_coordinate_seen = True
                return
        except Exception:
            return
        color = alpha_mul(get_heatmap_color(float(influence), gradient_stops, prepared=True))
        all_point_px.append(p)
        all_point_colors.append(color)
        valid_indices.add(idx)
        color_map[idx] = color
        uv_to_px[idx] = p

    for entry, distance_entry in zip(prepared, distance_prepared):
        try:
            coords = entry.get('coords') or ()
            edges = entry.get('edges') or ()
            selected = distance_entry.get('selected') or ()
            if not coords:
                continue
            valid_indices = set()
            color_map = {}
            uv_to_px = {}
            if use_connected:
                geo_dists = _uv_prop_connected_distances_cached(
                    distance_entry,
                    radius,
                    distance_entry.get('aspect') or transform_aspect,
                )
                live_coord_map = None
                if live_transform:
                    live_obj = entry.get('obj')
                    live_coord_map = _uv_prop_collect_live_transform_coord_map(live_obj, distance_entry, geo_dists.keys()) if live_obj is not None else None
                    if live_coord_map is None:
                        fallback = _uv_prop_collect_live_transform_geometry(live_obj, distance_entry, context) if live_obj is not None else None
                        if fallback:
                            coords = fallback.get('coords') or coords
                for idx, dist in geo_dists.items():
                    idx = int(idx)
                    if idx < 0 or idx >= len(coords):
                        continue
                    influence = get_falloff_intensity(float(dist), radius, falloff_type)
                    live_co = live_coord_map.get(idx) if isinstance(live_coord_map, dict) else None
                    _append_uv_heat_point(idx, live_co if live_co is not None else coords[idx], influence, valid_indices, color_map, uv_to_px)
            else:
                sel_lookup = set(int(i) for i in selected) if len(selected) > 8 else tuple(int(i) for i in selected)
                distance_coords = distance_entry.get('coord_vectors') or distance_entry.get('coords') or ()
                for i, co in enumerate(coords):
                    try:
                        if i in sel_lookup:
                            dist = 0.0
                        else:
                            distance_co = distance_coords[i] if i < len(distance_coords) else co
                            _found, _idx, dist = kd_global.find(distance_co)
                    except Exception:
                        continue
                    influence = get_falloff_intensity(float(dist), radius, falloff_type)
                    _append_uv_heat_point(int(i), co, influence, valid_indices, color_map, uv_to_px)
            if not valid_indices:
                continue
            seen_edges = set()
            for a, b in (_iter_lattice_edge_pairs(edges) if plan['allow_edges'] else ()):
                if a not in valid_indices or b not in valid_indices:
                    continue
                key = (min(a, b), max(a, b))
                if key in seen_edges:
                    continue
                seen_edges.add(key)
                pa = uv_to_px.get(a)
                pb = uv_to_px.get(b)
                if pa is None or pb is None:
                    continue
                all_edge_px.extend((pa, pb))
                all_edge_colors.extend((color_map[a], color_map[b]))
        except Exception:
            continue

    if all_point_px or all_edge_px:
        if not live_transform:
            try:
                _uv_prop_store_geometry_cache(_uv_prop_cache_key, prepared)
            except Exception:
                pass
        try:
            if _uv_prop_cache_key is not None:
                _uv_prop_stale_draw_cache[_uv_prop_cache_key] = {
                    'time': time.time(),
                    'edge_px': tuple(all_edge_px),
                    'edge_colors': tuple(all_edge_colors),
                    'point_px': tuple(all_point_px),
                    'point_colors': tuple(all_point_colors),
                    'line_width': float(overlay_line_width),
                    'point_size': float(overlay_point_size),
                    'aa_mode': str(aa_mode),
                }
        except Exception:
            pass
        _uv_prop_draw_2d(all_edge_px, all_edge_colors, all_point_px, all_point_colors, overlay_line_width, overlay_point_size, aa_mode)
    elif invalid_region_coordinate_seen:
        try:
            _tag_prop_overlay_redraw(context)
        except Exception:
            pass


def _prop_uv_snapshot_pointer(value):
    try:
        return int(value.as_pointer()) if value is not None else 0
    except Exception:
        return 0


def _prop_uv_snapshot_key(context=None):
    ctx = context or getattr(bpy, 'context', None)
    area = getattr(ctx, 'area', None)
    region = getattr(ctx, 'region', None)
    try:
        from . import uv as _sos_uv
        target = _sos_uv._uv_editor_target_for_region(ctx, region=region, area=area)
    except Exception:
        target = None
    if not isinstance(target, dict) or getattr(target.get('region'), 'type', None) != 'WINDOW':
        return None
    return (
        _prop_uv_snapshot_pointer(target.get('window') or getattr(ctx, 'window', None)),
        _prop_uv_snapshot_pointer(target.get('area')),
        _prop_uv_snapshot_pointer(target.get('region')),
        _prop_uv_snapshot_pointer(getattr(ctx, 'scene', None)),
        str(getattr(ctx, 'mode', '') or ''),
    )


def _prop_uv_view_signature(region):
    try:
        v2d = getattr(region, 'view2d', None)
        if v2d is None:
            return None
        samples = []
        for x, y in ((0, 0), (1, 0), (0, 1), (int(region.width), int(region.height))):
            vx, vy = v2d.region_to_view(int(x), int(y))
            samples.extend((round(float(vx), 7), round(float(vy), 7)))
        return tuple(samples)
    except Exception:
        return None


def _prop_uv_style_signature(context=None):
    ctx = context or getattr(bpy, 'context', None)
    tool_settings = getattr(ctx, 'tool_settings', None)
    prefs = _prefs(ctx)
    try:
        gradient = tuple(
            (round(float(pos), 6), tuple(round(float(v), 6) for v in color))
            for pos, color in _prepare_gradient_stops(getattr(prefs, 'gradient_stops', None))
        )
    except Exception:
        gradient = _DEFAULT_GRADIENT_STOPS
    try:
        radius = round(float(_uv_prop_tool_radius(tool_settings)), 6) if tool_settings is not None else 0.0
    except Exception:
        radius = 0.0
    return (
        bool(_uv_prop_pref_enabled(ctx)),
        bool(_uv_prop_tool_enabled(tool_settings)) if tool_settings is not None else False,
        radius,
        str(getattr(tool_settings, 'proportional_edit_falloff', '') or '') if tool_settings is not None else '',
        str(getattr(tool_settings, 'uv_select_mode', '') or '') if tool_settings is not None else '',
        round(float(getattr(prefs, 'overlay_point_size', getattr(prefs, 'vertex_size', 4.0)) or 4.0), 6) if prefs is not None else 4.0,
        round(float(getattr(prefs, 'overlay_line_width', getattr(prefs, 'edge_size', 2.0)) or 2.0), 6) if prefs is not None else 2.0,
        round(float(getattr(prefs, 'heatmap_alpha', 1.0) or 1.0), 6) if prefs is not None else 1.0,
        str(getattr(prefs, 'edge_aa_mode', 'AA_2PASS') or 'AA_2PASS') if prefs is not None else 'AA_2PASS',
        gradient,
    )


def _prop_iter_uv_editor_overrides(context=None):
    ctx = context or getattr(bpy, 'context', None)
    try:
        from . import uv as _sos_uv
        targets = tuple(_sos_uv._uv_iter_live_editor_targets(ctx) or ())
    except Exception:
        targets = ()

    for target in targets:
        window = target.get('window')
        override = dict(target)
        try:
            view_layer = getattr(window, 'view_layer', None)
            obj = getattr(getattr(view_layer, 'objects', None), 'active', None)
            selected_edit_meshes = []
            seen_selected_edit = set()

            def _add_selected_edit(candidate) -> None:
                try:
                    if candidate is None or getattr(candidate, 'type', None) != 'MESH':
                        return
                    if str(getattr(candidate, 'mode', '') or '') not in {'EDIT', 'EDIT_MESH'}:
                        return
                    ptr = int(candidate.as_pointer())
                    if ptr in seen_selected_edit:
                        return
                    selected_edit_meshes.append(candidate)
                    seen_selected_edit.add(ptr)
                except Exception:
                    return

            for source_ctx in (ctx, getattr(bpy, 'context', None)):
                try:
                    for attr in ('objects_in_mode_unique_data', 'objects_in_mode', 'selected_editable_objects', 'selected_objects'):
                        for candidate in tuple(getattr(source_ctx, attr, ()) or ()):
                            _add_selected_edit(candidate)
                except Exception:
                    pass
            for candidate in tuple(getattr(view_layer, 'objects', ()) or ()):
                _add_selected_edit(candidate)
            if selected_edit_meshes:
                override['selected_objects'] = selected_edit_meshes
                override['selected_editable_objects'] = selected_edit_meshes
                override.setdefault('edit_object', selected_edit_meshes[0])
            if obj is not None and getattr(obj, 'type', None) == 'MESH':
                override.update(active_object=obj, object=obj)
                if str(getattr(obj, 'mode', '') or '') in {'EDIT', 'EDIT_MESH'}:
                    override['edit_object'] = obj
        except Exception:
            pass
        yield override


def build_uv_snapshot_for_context(context, generation):
    global _prop_capture_commands, _prop_capture_state, _prop_capture_uniforms
    key = _prop_uv_snapshot_key(context)
    if key is None:
        return None
    commands = []
    _prop_capture_commands = commands
    _prop_capture_state = {}
    _prop_capture_uniforms = {}
    gpu_snapshot = None
    try:
        gpu_snapshot = mesh._sos_push_gpu_state_restore()
        _draw_callback_prop_uv_impl()
    except Exception:
        return None
    finally:
        _prop_capture_commands = None
        _prop_capture_state = {}
        _prop_capture_uniforms = {}
        try:
            mesh._sos_pop_gpu_state_restore(gpu_snapshot, ui_safe=True)
        except Exception:
            pass
    region = getattr(context, 'region', None)
    try:
        region_size = (int(region.width), int(region.height))
    except Exception:
        region_size = (0, 0)
    return {
        'key': key,
        'generation': int(generation),
        'mode': str(getattr(context, 'mode', '') or ''),
        'view_signature': _prop_uv_view_signature(region),
        'region_size': region_size,
        'style_signature': _prop_uv_style_signature(context),
        'commands': tuple(commands),
        'created_monotonic': float(time.monotonic()),
    }


def _prop_publish_uv_snapshot(record):
    if not isinstance(record, dict) or not record.get('key'):
        return False
    _prop_uv_snapshots[record['key']] = record
    overflow = len(_prop_uv_snapshots) - _PROP_UV_SNAPSHOT_MAX
    if overflow > 0:
        ordered = sorted(_prop_uv_snapshots.items(), key=lambda item: float(item[1].get('created_monotonic', 0.0)))
        for old_key, _record in ordered[:overflow]:
            _prop_uv_snapshots.pop(old_key, None)
    return True


def _prop_rebuild_uv_snapshots():
    global _prop_uv_snapshot_generation
    if not _prop_runtime_registered or not _prop_overlay_requested():
        _prop_uv_snapshots.clear()
        return 0
    _prop_uv_snapshot_generation += 1
    generation = int(_prop_uv_snapshot_generation)
    live_keys = set()
    built = 0
    for override in tuple(_prop_iter_uv_editor_overrides(getattr(bpy, 'context', None)) or ()):
        try:
            with bpy.context.temp_override(**override):
                key = _prop_uv_snapshot_key(bpy.context)
                if key is not None:
                    live_keys.add(key)
                record = build_uv_snapshot_for_context(bpy.context, generation)
                if record is not None and _prop_publish_uv_snapshot(record):
                    built += 1
        except Exception:
            continue
    for key in tuple(_prop_uv_snapshots):
        if key not in live_keys:
            _prop_uv_snapshots.pop(key, None)
    return int(built)


def _prop_uv_snapshot_rebuild_timer():
    global _prop_uv_snapshot_timer_pending, _prop_uv_snapshot_timer_attempts, _prop_uv_snapshot_due
    if not _prop_runtime_registered or not _prop_overlay_requested():
        _prop_uv_snapshot_timer_pending = False
        _prop_uv_snapshot_timer_attempts = 0
        _prop_uv_snapshot_due = 0.0
        _prop_uv_snapshot_reasons.clear()
        return None
    now = float(time.monotonic())
    if now < float(_prop_uv_snapshot_due or 0.0):
        return max(0.001, float(_prop_uv_snapshot_due) - now)
    start_serial = int(_prop_uv_snapshot_request_serial)
    _prop_uv_snapshot_timer_attempts += 1
    built = 0
    try:
        built = int(_prop_rebuild_uv_snapshots())
    except Exception:
        built = 0
    changed = int(_prop_uv_snapshot_request_serial) != start_serial
    if (changed or built <= 0) and _prop_uv_snapshot_timer_attempts < _PROP_UV_SNAPSHOT_MAX_ATTEMPTS:
        _prop_uv_snapshot_due = float(time.monotonic()) + _PROP_UV_SNAPSHOT_MIN_INTERVAL
        return _PROP_UV_SNAPSHOT_MIN_INTERVAL
    _prop_uv_snapshot_timer_pending = False
    _prop_uv_snapshot_timer_attempts = 0
    _prop_uv_snapshot_due = 0.0
    _prop_uv_snapshot_reasons.clear()
    try:
        _prop_tag_uv_editors_redraw()
    except Exception:
        pass
    return None


def request_prop_uv_snapshot_rebuild(reason='', context=None, immediate=False):
    global _prop_uv_snapshot_request_serial, _prop_uv_snapshot_timer_pending
    global _prop_uv_snapshot_timer_attempts, _prop_uv_snapshot_due
    if not _prop_runtime_registered or not _prop_overlay_requested(context):
        return False
    reason_text = str(reason or '')
    if reason_text:
        _prop_uv_snapshot_reasons.add(reason_text)
    now = float(time.monotonic())
    requested_due = now if immediate else now + _PROP_UV_SNAPSHOT_MIN_INTERVAL
    if _prop_uv_snapshot_timer_pending:
        if not reason_text.startswith('draw_'):
            _prop_uv_snapshot_request_serial += 1
        _prop_uv_snapshot_due = min(float(_prop_uv_snapshot_due or requested_due), requested_due)
        return True
    _prop_uv_snapshot_request_serial += 1
    _prop_uv_snapshot_timer_pending = True
    _prop_uv_snapshot_timer_attempts = 0
    _prop_uv_snapshot_due = requested_due
    try:
        if _prop_runtime_registered:  # 常駐が有効な時だけ時計を入れる
            bpy.app.timers.register(_prop_uv_snapshot_rebuild_timer, first_interval=max(0.0, requested_due - now))
            return True
        _prop_uv_snapshot_timer_pending = False
        return False
    except Exception:
        _prop_uv_snapshot_timer_pending = False
        _prop_uv_snapshot_timer_attempts = 0
        _prop_uv_snapshot_due = 0.0
        return False


def clear_uv_snapshots():
    global _prop_uv_snapshot_timer_pending, _prop_uv_snapshot_timer_attempts, _prop_uv_snapshot_due
    try:
        if bpy.app.timers.is_registered(_prop_uv_snapshot_rebuild_timer):
            bpy.app.timers.unregister(_prop_uv_snapshot_rebuild_timer)
    except Exception:
        pass
    _prop_uv_snapshot_timer_pending = False
    _prop_uv_snapshot_timer_attempts = 0
    _prop_uv_snapshot_due = 0.0
    _prop_uv_snapshot_reasons.clear()
    _prop_uv_snapshots.clear()


def _prop_uv_snapshot_for_draw(context=None):
    ctx = context or getattr(bpy, 'context', None)
    key = _prop_uv_snapshot_key(ctx)
    record = _prop_uv_snapshots.get(key) if key is not None else None
    region = getattr(ctx, 'region', None)
    try:
        size = (int(region.width), int(region.height))
    except Exception:
        size = (0, 0)
    stale = (
        not isinstance(record, dict)
        or int(record.get('generation', -1)) != int(_prop_uv_snapshot_generation)
        or record.get('mode') != str(getattr(ctx, 'mode', '') or '')
        or tuple(record.get('region_size') or ()) != size
        or record.get('view_signature') != _prop_uv_view_signature(region)
        or record.get('style_signature') != _prop_uv_style_signature(ctx)
    )
    if stale:
        request_prop_uv_snapshot_rebuild('draw_missing_or_stale', context=ctx, immediate=True)
        return None
    return record


def _replay_uv_snapshot(context=None):
    if _prop_native_transform_running(context):
        return None
    record = _prop_uv_snapshot_for_draw(context)
    if not isinstance(record, dict):
        return None
    for command in tuple(record.get('commands') or ()):
        batch = command.get('batch')
        shader = command.get('shader')
        if batch is None or shader is None:
            raise RuntimeError('Invalid UV proportional snapshot command')
        for name, values in dict(command.get('state') or {}).items():
            setter = getattr(gpu.state, f'{name}_set', None)
            if callable(setter):
                setter(*tuple(values or ()))
        shader.bind()
        for uniform_name, value in dict(command.get('uniforms') or {}).items():
            shader.uniform_float(uniform_name, value)
        batch.draw(shader)
    return None


@persistent
def _prop_uv_load_pre(_dummy):
    clear_uv_snapshots()


@persistent
def _prop_uv_load_post(_dummy):
    if _prop_runtime_registered and _prop_overlay_requested():
        request_prop_uv_snapshot_rebuild('load_post', context=getattr(bpy, 'context', None), immediate=True)


@persistent
def _prop_uv_undo_post(_dummy):
    if _prop_runtime_registered and _prop_overlay_requested():
        request_prop_uv_snapshot_rebuild('undo_post', context=getattr(bpy, 'context', None), immediate=True)


@persistent
def _prop_uv_redo_post(_dummy):
    _prop_uv_undo_post(_dummy)


def _register_prop_uv_boundary_handlers():
    global _prop_uv_boundary_handlers_registered
    if _prop_uv_boundary_handlers_registered:
        return
    for collection, callback in (
        (bpy.app.handlers.load_pre, _prop_uv_load_pre),
        (bpy.app.handlers.load_post, _prop_uv_load_post),
        (bpy.app.handlers.undo_post, _prop_uv_undo_post),
        (bpy.app.handlers.redo_post, _prop_uv_redo_post),
    ):
        if callback not in collection:
            collection.append(callback)
    _prop_uv_boundary_handlers_registered = True


def _unregister_prop_uv_boundary_handlers():
    global _prop_uv_boundary_handlers_registered
    for collection, callback in (
        (bpy.app.handlers.load_pre, _prop_uv_load_pre),
        (bpy.app.handlers.load_post, _prop_uv_load_post),
        (bpy.app.handlers.undo_post, _prop_uv_undo_post),
        (bpy.app.handlers.redo_post, _prop_uv_redo_post),
    ):
        try:
            while callback in collection:
                collection.remove(callback)
        except Exception:
            pass
    _prop_uv_boundary_handlers_registered = False



def _prop_view3d_size_signature(context=None):
    """Return the live View3D proportional radius without starting any work."""
    try:
        ctx = context or getattr(bpy, 'context', None)
        tool_settings = getattr(ctx, 'tool_settings', None)
        if tool_settings is None:
            return None
        return float(getattr(tool_settings, 'proportional_size', 0.0) or 0.0)
    except Exception:
        return None


def build_view3d_snapshot_for_context(context, generation: int) -> bool:
    """Build and atomically publish proportional GPU commands outside draw."""
    global _prop_capture_commands, _prop_capture_state, _prop_capture_uniforms
    key = mesh._sos_snapshot_key(context)
    if key is None:
        return False
    commands = []
    _prop_capture_commands = commands
    _prop_capture_state = {}
    _prop_capture_uniforms = {}
    gpu_snapshot = None
    try:
        gpu_snapshot = mesh._sos_push_gpu_state_restore()
        _draw_callback_prop_impl()
    except Exception:
        return False
    finally:
        _prop_capture_commands = None
        _prop_capture_state = {}
        _prop_capture_uniforms = {}
        try:
            mesh._sos_pop_gpu_state_restore(gpu_snapshot, ui_safe=True)
        except Exception:
            pass
    record = {
        'key': key,
        'mode': str(getattr(context, 'mode', '') or ''),
        'generation': int(generation),
        'proportional_size': _prop_view3d_size_signature(context),
        'commands': tuple(commands),
        'created_monotonic': float(time.monotonic()),
    }
    _prop_view3d_snapshots[key] = record
    try:
        overflow = len(_prop_view3d_snapshots) - _PROP_VIEW3D_SNAPSHOT_MAX
        if overflow > 0:
            ordered = sorted(_prop_view3d_snapshots.items(), key=lambda item: item[1].get('created_monotonic', 0.0))
            for old_key, _record in ordered[:overflow]:
                _prop_view3d_snapshots.pop(old_key, None)
    except Exception:
        pass
    return True


def _prop_view3d_snapshot_rebuild_timer():
    """Build the View3D records while the Mesh/Curve runtime is not running."""
    global _prop_view3d_snapshot_timer_pending, _prop_view3d_snapshot_generation
    _prop_view3d_snapshot_timer_pending = False
    if not _prop_runtime_registered or not _prop_overlay_requested():
        return None
    _prop_view3d_snapshot_generation += 1
    built = 0
    for override in tuple(mesh._sos_iter_view3d_modal_overrides(getattr(bpy, 'context', None))):
        try:
            with bpy.context.temp_override(**override):
                if build_view3d_snapshot_for_context(bpy.context, _prop_view3d_snapshot_generation):
                    built += 1
        except Exception:
            continue
    if built:
        try:
            mesh.tag_view3d_redraw()
        except Exception:
            pass
    return None


def request_prop_view3d_snapshot_rebuild(reason='', context=None, immediate=False) -> bool:
    """The Mesh/Curve builder owns these records while it runs; otherwise use a one-shot timer."""
    global _prop_view3d_snapshot_timer_pending
    if mesh.request_overlay_snapshot_rebuild(reason, context=context, immediate=immediate):
        return True
    if _prop_view3d_snapshot_timer_pending or not _prop_runtime_registered or not _prop_overlay_requested(context):
        return False
    try:
        bpy.app.timers.register(_prop_view3d_snapshot_rebuild_timer, first_interval=0.0 if immediate else _PROP_VIEW3D_SNAPSHOT_MIN_INTERVAL)
        _prop_view3d_snapshot_timer_pending = True
        return True
    except Exception:
        return False


def _replay_view3d_snapshot(context=None):
    ctx = context or getattr(bpy, 'context', None)
    if not mesh.is_active_view_draw_context(ctx, _prefs(ctx)):
        return None
    if _prop_native_transform_running(ctx):
        return None
    key = mesh._sos_snapshot_key(ctx)
    record = _prop_view3d_snapshots.get(key) if key is not None else None
    if not isinstance(record, dict) or record.get('mode') != str(getattr(ctx, 'mode', '') or ''):
        request_prop_view3d_snapshot_rebuild('prop_draw_missing', context=ctx, immediate=True)
        return None
    current_size = _prop_view3d_size_signature(ctx)
    stored_size = record.get('proportional_size')
    try:
        size_changed = (
            current_size is not None
            and (
                stored_size is None
                or not math.isclose(
                    float(stored_size), float(current_size), rel_tol=1.0e-9, abs_tol=1.0e-9
                )
            )
        )
    except Exception:
        size_changed = False
    if size_changed:
        try:
            _SIGNAL_MONITOR.on_signal_received()
        except Exception:
            pass
        request_prop_view3d_snapshot_rebuild('draw_prop_size_changed', context=ctx, immediate=True)
    commands = tuple(record.get('commands') or ())
    for command in commands:
        batch = command.get('batch')
        shader = command.get('shader')
        if batch is None or shader is None:
            continue
        state = dict(command.get('state') or {})
        try:
            for name, values in state.items():
                setter = getattr(gpu.state, f'{name}_set', None)
                if callable(setter):
                    setter(*tuple(values or ()))
            shader.bind()
            for uniform_name, value in dict(command.get('uniforms') or {}).items():
                shader.uniform_float(uniform_name, value)
            batch.draw(shader)
        except Exception:
            continue
    return None


def clear_view3d_snapshots() -> None:
    global _prop_view3d_snapshot_timer_pending
    _prop_view3d_snapshots.clear()
    try:
        if bpy.app.timers.is_registered(_prop_view3d_snapshot_rebuild_timer):
            bpy.app.timers.unregister(_prop_view3d_snapshot_rebuild_timer)
    except Exception:
        pass
    _prop_view3d_snapshot_timer_pending = False


# =============================================================================
# Draw Callbacks
# =============================================================================
def _prop_native_transform_running(context=None) -> bool:
    """True while one of Blender's own transform modals (G / R / S, shrink-fatten, to-sphere ...) runs in this window.

    Blender writes tool_settings.proportional_size only when the transform ends: a
    PAGE_UP / wheel resize during the drag changes only the transform's internal
    copy, and the running operator's properties stay at the start value too (measured
    in 5.1.2, 3D view and UV editor).  Whatever this add-on draws from that value is
    therefore the radius of the moment the drag started and disagrees with Blender's
    own proportional circle, which follows the live radius.  So the add-on draws
    nothing while a transform modal runs and leaves the screen to Blender; at confirm
    the value is written and the normal size-change path rebuilds the overlay.
    """
    try:
        window = getattr(context or bpy.context, 'window', None)
        if window is None:
            return False
        for op in tuple(getattr(window, 'modal_operators', ()) or ()):
            ident = str(getattr(op, 'bl_idname', '') or '').strip().lower()
            if ident.startswith('transform_ot_') or ident.startswith('transform.'):
                return True
    except Exception:
        return False
    return False


_draw_handler_prop = None
_draw_handler_prop_uv = None
_prop_runtime_registered = False
_prop_runtime_started_at = 0.0
_prop_last_view3d_draw_time = 0.0
_prop_last_uv_draw_time = 0.0
_prop_last_rehook_time = 0.0
_prop_draw_exception_count = 0
_uv_prop_stale_draw_cache = {}
_uv_prop_geometry_cache = {}
_UV_PROP_STALE_CACHE_SECONDS = 2.0
_UV_PROP_GEOMETRY_CACHE_SECONDS = 10.0
# Explicit per-draw work budget for the UV proportional overlay.  One unit is
# one UV loop considered by a single draw callback.  The budget is a count, not
# a deadline, so the same input always produces the same output on any machine.
# Below the budget the overlay is computed exactly as before; at or above it the
# draw refuses to start a distance field it cannot finish (see
# _uv_prop_draw_budget_plan).
_UV_PROP_DRAW_BUDGET_ELEMENTS = 120000
# Upper bound on selected UV elements emitted by one reduced draw.  A reduced
# draw fills this budget exactly (see _uv_prop_draw_selected_core); it does not
# stride, so the emitted count is min(cap, selected) rather than a quantised
# fraction of it.
_UV_PROP_DRAW_BUDGET_SELECTED = 20000
# Upper bound on lattice edge pairs walked by one exact draw.
#
# This is a defence-in-depth assertion, not a path that fires.  For geometry
# produced by _uv_prop_collect_object_geometry the edge list is bounded at
# 2 * coords - 1 per object: the face walk contributes exactly one perimeter
# edge per loop (coords edges in total), and the UV weld pass contributes
# len(group) - 1 edges per coincident-UV group, which sums to at most
# coords - 1.  Summed over n objects the bound is 2 * elements - n, so at the
# _UV_PROP_DRAW_BUDGET_ELEMENTS ceiling of 120000 the largest reachable edge
# count is 239999 -- exactly one below this threshold.  The guard is therefore
# unreachable for collector geometry by construction, and is kept only so that
# a future collector which changes the edge-to-loop ratio cannot silently make
# an exact draw unbounded.  EDGE-1 in the gate measures the real ratio from the
# product's own collector and asserts the 2 * coords - 1 invariant rather than
# restating it.
_UV_PROP_DRAW_BUDGET_EDGE_PAIRS = 240000
_PROP_WATCHDOG_INTERVAL = 0.75
_PROP_REALTIME_UV_WATCHDOG_INTERVAL = 0.12
_PROP_STALE_REHOOK_SECONDS = 5.0
_prop_uv_realtime_last_signature = None
_PROP_TOOL_SETTINGS_MSGBUS_OWNER = object()
_PROP_TOOL_SETTINGS_MSGBUS_PROPS = (
    'proportional_size',
    'proportional_distance',
    'proportional_edit_falloff',
    'use_proportional_edit',
    'use_proportional_edit_mask',
    'use_proportional_connected',
    'use_proportional_projected',
    'uv_select_mode',
)
_prop_tool_settings_msgbus_notify_count = 0



def _prop_workspace_filter_allows_addon(context=None) -> bool:
    try:
        from . import common as _sos_common
        fn = getattr(_sos_common, 'workspace_filter_allows_addon', None)
        if callable(fn):
            return bool(fn(context))
    except Exception:
        pass
    return True


def _prop_workspace_filter_allows_cross_editor_runtime(context=None) -> bool:
    try:
        from . import common as _sos_common
        fn = getattr(_sos_common, 'workspace_filter_allows_addon_runtime', None)
        if callable(fn):
            return bool(fn(context, cross_editor=True))
    except Exception:
        pass
    return _prop_workspace_filter_allows_addon(context)

def _prop_overlay_requested(context=None) -> bool:
    try:
        ctx = context or getattr(bpy, 'context', None)
        from . import uv as _sos_uv
        return any(
            bool(getattr(wm, 'sos_proportional_overlay_enabled', False))
            for wm in _sos_uv._uv_iter_window_managers(ctx)
        )
    except Exception:
        return False


def _prop_has_area(area_type: str, context=None) -> bool:
    try:
        ctx = context or getattr(bpy, 'context', None)
        from . import uv as _sos_uv
        if str(area_type) == 'IMAGE_EDITOR':
            return next(iter(_sos_uv._uv_iter_live_editor_targets(ctx) or ()), None) is not None
        for window in _sos_uv._uv_iter_windows(ctx):
            screen = getattr(window, 'screen', None)
            for area in tuple(getattr(screen, 'areas', ()) or ()):
                if getattr(area, 'type', None) == area_type:
                    return True
    except Exception:
        pass
    return False


def _prop_tag_uv_editors_redraw(context=None) -> bool:
    tagged = False
    try:
        from . import uv as _sos_uv
        for target in tuple(_sos_uv._uv_iter_live_editor_targets(context) or ()):
            area = target.get('area')
            if area is not None:
                try:
                    area.tag_redraw()
                    tagged = True
                except Exception:
                    pass
    except Exception:
        pass
    return tagged


def _prop_uv_realtime_signature(context=None):
    try:
        ctx = context or bpy.context
        tool_settings = getattr(ctx, 'tool_settings', None)
        if tool_settings is None:
            return None
        radius = _uv_prop_tool_radius(tool_settings)
        if radius <= 0.0 or not _uv_prop_tool_enabled(tool_settings):
            return None
        coordinate_signature = []
        try:
            import bmesh
            objects = tuple(getattr(ctx, 'objects_in_mode_unique_data', ()) or ())
            if not objects:
                edit_object = getattr(ctx, 'edit_object', None)
                objects = (edit_object,) if edit_object is not None else ()
            for obj in sorted(
                objects,
                key=lambda item: int(item.as_pointer()) if item is not None else 0,
            ):
                if obj is None or getattr(obj, 'type', None) != 'MESH':
                    continue
                data = getattr(obj, 'data', None)
                if data is None:
                    continue
                bm = bmesh.from_edit_mesh(data)
                uv_layer = bm.loops.layers.uv.active
                if uv_layer is None:
                    continue
                digest = 1469598103934665603
                loop_count = 0
                for face in bm.faces:
                    for loop in face.loops:
                        uv = loop[uv_layer].uv
                        for component in (
                            int(round(float(uv.x) * 1000000.0)),
                            int(round(float(uv.y) * 1000000.0)),
                        ):
                            digest ^= int(component) & 0xFFFFFFFFFFFFFFFF
                            digest = (digest * 1099511628211) & 0xFFFFFFFFFFFFFFFF
                        loop_count += 1
                coordinate_signature.append((
                    int(obj.as_pointer()),
                    int(loop_count),
                    int(digest),
                ))
        except Exception:
            coordinate_signature = [('UNAVAILABLE',)]
        return (
            round(float(radius), 6),
            str(getattr(tool_settings, 'proportional_edit_falloff', '') or ''),
            bool(getattr(tool_settings, 'use_proportional_connected', False)),
            bool(getattr(tool_settings, 'use_proportional_projected', False)),
            str(getattr(tool_settings, 'uv_select_mode', '') or ''),
            bool(getattr(tool_settings, 'use_uv_select_sync', False)),
            tuple(coordinate_signature),
        )
    except Exception:
        return None


def _prop_uv_realtime_requested(context=None) -> bool:
    try:
        ctx = context or bpy.context
        if not _prop_overlay_requested(ctx):
            return False
        if not _uv_prop_pref_enabled(ctx):
            return False
        if _prop_uv_realtime_signature(ctx) is None:
            return False
        return _prop_has_area('IMAGE_EDITOR', ctx)
    except Exception:
        return False


def _prop_tool_settings_msgbus_notify():
    global _prop_tool_settings_msgbus_notify_count
    try:
        _prop_tool_settings_msgbus_notify_count += 1
    except Exception:
        pass
    try:
        _SIGNAL_MONITOR.on_signal_received()
    except Exception:
        pass
    try:
        _tag_prop_overlay_redraw(bpy.context)
    except Exception:
        try:
            _prop_tag_uv_editors_redraw(bpy.context)
        except Exception:
            pass


def _prop_subscribe_tool_settings_msgbus() -> None:
    try:
        msgbus = getattr(bpy, 'msgbus', None)
        if msgbus is None:
            return
        msgbus.clear_by_owner(_PROP_TOOL_SETTINGS_MSGBUS_OWNER)
        keys = []
        tool_settings_type = getattr(bpy.types, 'ToolSettings', None)
        if tool_settings_type is not None:
            keys.extend((tool_settings_type, prop_name) for prop_name in _PROP_TOOL_SETTINGS_MSGBUS_PROPS)
        try:
            for scene in getattr(bpy.data, 'scenes', ()) or ():
                tool_settings = getattr(scene, 'tool_settings', None)
                if tool_settings is not None:
                    keys.extend((tool_settings, prop_name) for prop_name in _PROP_TOOL_SETTINGS_MSGBUS_PROPS)
        except Exception:
            pass
        seen = set()
        for key in keys:
            try:
                key_sig = (id(key[0]), str(key[1]))
                if key_sig in seen:
                    continue
                seen.add(key_sig)
            except Exception:
                pass
            try:
                msgbus.subscribe_rna(
                    key=key,
                    owner=_PROP_TOOL_SETTINGS_MSGBUS_OWNER,
                    args=(),
                    notify=_prop_tool_settings_msgbus_notify,
                    options={'PERSISTENT'},
                )
            except Exception:
                continue
    except Exception:
        pass


def _prop_unsubscribe_tool_settings_msgbus() -> None:
    try:
        msgbus = getattr(bpy, 'msgbus', None)
        if msgbus is not None:
            msgbus.clear_by_owner(_PROP_TOOL_SETTINGS_MSGBUS_OWNER)
    except Exception:
        pass


def _prop_remove_handlers_for_rehook() -> None:
    global _draw_handler_prop, _draw_handler_prop_uv
    if _draw_handler_prop is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_draw_handler_prop, 'WINDOW')
        except Exception:
            pass
        _draw_handler_prop = None
    if _draw_handler_prop_uv is not None:
        try:
            bpy.types.SpaceImageEditor.draw_handler_remove(_draw_handler_prop_uv, 'WINDOW')
        except Exception:
            pass
        _draw_handler_prop_uv = None


def _prop_runtime_watchdog_timer():
    if not _prop_runtime_registered:
        return None
    try:
        _add_prop_draw_handler()
        handlers = getattr(bpy.app.handlers, 'depsgraph_update_post', None)
        if handlers is not None and prop_depsgraph_update_handler not in handlers:
            handlers.append(prop_depsgraph_update_handler)
        request_prop_view3d_snapshot_rebuild('prop_runtime_repair', context=getattr(bpy, 'context', None), immediate=True)
        request_prop_uv_snapshot_rebuild('prop_runtime_repair', context=getattr(bpy, 'context', None), immediate=True)
    except Exception:
        pass
    return 1.0


def _prop_start_runtime_watchdog() -> None:
    try:
        if bpy.app.timers.is_registered(_prop_runtime_watchdog_timer):
            return
    except Exception:
        pass
    try:
        if _prop_runtime_registered:  # 常駐が有効な時だけ見張りの時計を入れる
            bpy.app.timers.register(_prop_runtime_watchdog_timer, first_interval=0.0, persistent=True)
    except TypeError:
        try:
            bpy.app.timers.register(_prop_runtime_watchdog_timer, first_interval=0.0)
        except Exception:
            _prop_runtime_watchdog_timer()
    except Exception:
        _prop_runtime_watchdog_timer()

def _prop_stop_runtime_watchdog() -> None:
    try:
        if bpy.app.timers.is_registered(_prop_runtime_watchdog_timer):
            bpy.app.timers.unregister(_prop_runtime_watchdog_timer)
    except Exception:
        pass


def _prop_other_selected_meshes(context, edit_objs, use_connected):
    """Return non-edit selected meshes only when their draw pass is reachable."""
    if use_connected:
        return []
    selected_mesh = [o for o in getattr(context, "selected_objects", []) if o and o.type == "MESH"]
    edit_set = set(edit_objs)
    return [o for o in selected_mesh if o not in edit_set]


def _draw_callback_prop_impl():
    try:
        if mesh._sos_should_skip_custom_draw_for_selection():
            try:
                mesh._sos_reset_gpu_state_after_draw()
            except Exception:
                pass
            return
    except Exception:
        pass
    context = bpy.context
    if not getattr(context.window_manager, "sos_proportional_overlay_enabled", False): return
    if not _prop_view3d_pref_enabled(context): return
    mode = getattr(context, "mode", "")
    if mode not in {'OBJECT', 'EDIT_MESH', 'EDIT_LATTICE', 'EDIT_CURVE', 'EDIT_CURVES'}: return
    if _prop_native_transform_running(context): return
    tool_settings = context.tool_settings
    if mode == 'OBJECT':
        if not bool(getattr(tool_settings, 'use_proportional_edit_objects', False)):
            return
        _draw_callback_prop_object(context, tool_settings)
        return
    if not bool(getattr(tool_settings, 'use_proportional_edit', False)): return
    if mode == 'EDIT_LATTICE':
        _draw_callback_prop_lattice(context, tool_settings)
        return
    if mode in {'EDIT_CURVE', 'EDIT_CURVES'}:
        _draw_callback_prop_curve(context, tool_settings)
        return

    falloff_type = tool_settings.proportional_edit_falloff
    use_connected = tool_settings.use_proportional_connected
    use_projected = _psc_is_projected_from_view(tool_settings) and (not use_connected)

    objs_in_mode = getattr(context, "objects_in_mode", None)
    if objs_in_mode: edit_objs = [o for o in objs_in_mode if o and o.type == "MESH"]
    else: edit_objs = [o for o in getattr(context, "selected_objects", []) if o and o.type == "MESH" and getattr(o, "mode", None) == 'EDIT']

    other_selected_objs = _prop_other_selected_meshes(context, edit_objs, use_connected)

    if not edit_objs and not other_selected_objs: return

    try:
        _SIGNAL_MONITOR.check_status(tool_settings.proportional_size)
        is_active = _SIGNAL_MONITOR.is_active
    except Exception: is_active = False

    draw_size = float(tool_settings.proportional_size)
    region, rv3d = None, None
    influence_radius = draw_size

    try: prefs = _prefs(context)
    except Exception: prefs = None

    # Active View Only (match smart_overlay_suite)
    try:
        if prefs and not mesh.is_active_view_draw_context(context, prefs):
            return
    except Exception:
        pass

    try:
        overlay_point_size = float(getattr(prefs, "prop_overlay_vertex_size", 4.0)) if prefs else 4.0
        overlay_line_width = float(getattr(prefs, "prop_overlay_edge_size", 2.0)) if prefs else 2.0
        overlay_point_size = max(0.1, overlay_point_size)
        overlay_line_width = max(0.1, overlay_line_width)
    except Exception: overlay_point_size, overlay_line_width = 4.0, 2.0

    try:
        heatmap_alpha = float(getattr(prefs, "prop_heatmap_alpha", 1.0)) if prefs else 1.0
        heatmap_alpha = max(0.05, min(1.0, heatmap_alpha))
    except Exception:
        heatmap_alpha = 1.0
    try:
        heatmap_xray = bool(getattr(prefs, "prop_heatmap_xray", True)) if prefs else True
    except Exception:
        heatmap_xray = True

    gradient_stops = _prop_gradient_stops_from_prefs(prefs)

    def _alpha_mul(color):
        return (float(color[0]), float(color[1]), float(color[2]), max(0.0, min(1.0, float(color[3]) * heatmap_alpha)))

    prepared_edit = []; global_sel_coords = []
    for obj in edit_objs:
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            _ensure_bmesh_indices(bm)
            cache = _ensure_snapshot(context, obj, bm, is_active, use_connected, draw_size, allow_geodesic=(not use_projected))
            base_coords = cache.get("base_world_coords")
            if base_coords is None: continue

            sel_sig = cache.get("sel_sig") or ()
            for idx in sel_sig:
                if 0 <= idx < len(base_coords): global_sel_coords.append(base_coords[idx])
            prepared_edit.append((obj, bm, cache, base_coords))
        except Exception: continue

    if not global_sel_coords: return

    if use_projected:
        region, rv3d = _psc_get_view_region_and_rv3d(context)
        if region is None or rv3d is None: return
        try:
            sel_center = Vector((0.0, 0.0, 0.0))
            for co in global_sel_coords: sel_center += co
            sel_center /= max(1, len(global_sel_coords))
        except Exception: sel_center = global_sel_coords[0].copy()

        influence_radius = _psc_calc_projected_radius_px(region, rv3d, sel_center, draw_size)
        if influence_radius <= 0.0: return

        global_sel_coords_2d = []
        for co in global_sel_coords:
            try: p = view3d_utils.location_3d_to_region_2d(region, rv3d, co)
            except Exception: p = None
            if p is not None: global_sel_coords_2d.append(Vector((p.x, p.y, 0.0)))

        if not global_sel_coords_2d: return
        kd_global = KDTree(len(global_sel_coords_2d))
        for i, co in enumerate(global_sel_coords_2d):
            try: kd_global.insert(co, i)
            except Exception: pass
        kd_global.balance()
    else:
        kd_global = KDTree(len(global_sel_coords))
        for i, co in enumerate(global_sel_coords):
            try: kd_global.insert(co, i)
            except Exception: pass
        kd_global.balance()

    try:
        try: shader = gpu.shader.from_builtin('3D_SMOOTH_COLOR')
        except Exception:
            try: shader = gpu.shader.from_builtin('SMOOTH_COLOR')
            except Exception: return
        shader.bind()
        _prop_state_set('blend', 'ALPHA')
        if heatmap_xray:
            try:
                _prop_state_set('depth_test', 'NONE')
            except Exception:
                _prop_state_set('depth_test', 'ALWAYS')
        else:
            try:
                _prop_state_set('depth_test', 'LESS_EQUAL')
            except Exception:
                _prop_state_set('depth_test', 'LESS')

        # Edge AA mode (shared with Mesh and Curve Overlay edge AA setting)
        aa_mode = getattr(prefs, "edge_aa_mode", "AA_2PASS") if prefs else "AA_2PASS"
        aa_enabled = (aa_mode != "AA_OFF")
        for fn, val in (("multisample_set", aa_enabled), ("line_smooth_set", aa_enabled), ("alpha_to_coverage_set", aa_enabled)):
            try:
                getattr(gpu.state, fn)(val)
            except Exception:
                pass

        for obj, bm, cache, base_coords in prepared_edit:
            try:
                if not base_coords: continue
                matrix_world = obj.matrix_world
                draw_world_coords = [(matrix_world @ v.co) if _visible_vert(v) else None for v in bm.verts]
                colored_points = []
                sel_sig = cache.get("sel_sig") or ()
                sel_lookup = set(sel_sig) if len(sel_sig) > 8 else sel_sig
                has_local_sel = bool(sel_sig)
                if use_connected:
                    if has_local_sel:
                        geo_dists = {}
                        if use_projected:
                            if region is None or rv3d is None: geo_dists = {}
                            else:
                                try:
                                    screen_coords = _psc_project_world_list_to_screen(region, rv3d, draw_world_coords)
                                    geo_dists = calc_geodesic_distances(bm, sel_sig, float(influence_radius), screen_coords)
                                except Exception: geo_dists = {}
                        else: geo_dists = cache.get("geodesic_cache", {}).get("dists", {})

                        if geo_dists:
                            for idx, dist in geo_dists.items():
                                influence = get_falloff_intensity(dist, influence_radius, falloff_type)
                                if influence > 0: colored_points.append((idx, _alpha_mul(get_heatmap_color(influence, gradient_stops, prepared=True))))
                else:
                    screen_coords = None
                    if use_projected:
                        if region is None or rv3d is None: continue
                        try: screen_coords = _psc_project_world_list_to_screen(region, rv3d, draw_world_coords)
                        except Exception: screen_coords = None

                    for i, co in enumerate(base_coords):
                        if co is None:
                            continue
                        try:
                            if i in sel_lookup: dist = 0.0
                            else:
                                if use_projected:
                                    if not screen_coords: continue
                                    sc = screen_coords[i]
                                    if sc is None: continue
                                    _, _, dist = kd_global.find(sc)
                                else: _, _, dist = kd_global.find(co)
                        except Exception: continue
                        influence = get_falloff_intensity(dist, influence_radius, falloff_type)
                        if influence > 0: colored_points.append((i, _alpha_mul(get_heatmap_color(influence, gradient_stops, prepared=True))))

                if not colored_points: continue

                point_coords, point_colors, edge_coords, edge_colors = [], [], [], []
                valid_indices, color_map = set(), {}

                for idx, color in colored_points:
                    if idx < 0 or idx >= len(draw_world_coords): continue
                    if draw_world_coords[idx] is None: continue
                    point_coords.append(draw_world_coords[idx]); point_colors.append(color)
                    valid_indices.add(idx); color_map[idx] = color

                if not point_coords: continue

                processed_edges = set()
                for idx in valid_indices:
                    v = bm.verts[idx]
                    for e in v.link_edges:
                        if not _visible_edge(e): continue
                        other = e.other_vert(v); j = other.index
                        if j in valid_indices:
                            key = (min(idx, j), max(idx, j))
                            if key in processed_edges: continue
                            processed_edges.add(key)
                            if draw_world_coords[idx] is None or draw_world_coords[j] is None: continue
                            edge_coords.append(draw_world_coords[idx]); edge_coords.append(draw_world_coords[j])
                            edge_colors.append(color_map[idx]); edge_colors.append(color_map[j])

                if edge_coords:
                    # Edge overlay AA (mode-controlled)
                    if aa_mode == "AA_2PASS":
                        try:
                            aa_outer_w = overlay_line_width + 1.0
                            _prop_state_set('line_width', aa_outer_w)
                            edge_colors_aa = [(c[0], c[1], c[2], c[3] * 0.18) for c in edge_colors]
                            batch_edges_aa = batch_for_shader(shader, 'LINES', {"pos": edge_coords, "color": edge_colors_aa})
                            batch_edges_aa.draw(shader)
                        except Exception:
                            pass
                    _prop_state_set('line_width', overlay_line_width)
                    batch_edges = batch_for_shader(shader, 'LINES', {"pos": edge_coords, "color": edge_colors})
                    batch_edges.draw(shader)
                if point_coords:
                    _prop_state_set('point_size', overlay_point_size)
                    batch_points = batch_for_shader(shader, 'POINTS', {"pos": point_coords, "color": point_colors})
                    batch_points.draw(shader)
            except Exception: continue

        for obj in other_selected_objs:
            try:
                if use_connected: continue
                mesh_data = getattr(obj, "data", None)
                if mesh_data is None or getattr(mesh_data, "vertices", None) is None: continue
                if len(mesh_data.vertices) == 0: continue

                matrix_world = obj.matrix_world
                draw_world_coords = [matrix_world @ v.co for v in mesh_data.vertices]
                base_coords = draw_world_coords
                colored_points = []
                screen_coords = None
                if use_projected:
                    if region is None or rv3d is None: continue
                    try: screen_coords = _psc_project_world_list_to_screen(region, rv3d, base_coords)
                    except Exception: screen_coords = None

                for i, co in enumerate(base_coords):
                    try:
                        if use_projected:
                            if not screen_coords: continue
                            sc = screen_coords[i]
                            if sc is None: continue
                            _, _, dist = kd_global.find(sc)
                        else: _, _, dist = kd_global.find(co)
                    except Exception: continue
                    influence = get_falloff_intensity(dist, influence_radius, falloff_type)
                    if influence > 0: colored_points.append((i, _alpha_mul(get_heatmap_color(influence, gradient_stops, prepared=True))))

                if not colored_points: continue

                point_coords, point_colors, edge_coords, edge_colors = [], [], [], []
                valid_indices, color_map = set(), {}

                for idx, color in colored_points:
                    if idx < 0 or idx >= len(draw_world_coords): continue
                    if draw_world_coords[idx] is None: continue
                    point_coords.append(draw_world_coords[idx]); point_colors.append(color)
                    valid_indices.add(idx); color_map[idx] = color

                if not point_coords: continue

                for e in mesh_data.edges:
                    v1, v2 = e.vertices
                    if v1 in valid_indices and v2 in valid_indices:
                        edge_coords.append(draw_world_coords[v1]); edge_coords.append(draw_world_coords[v2])
                        edge_colors.append(color_map[v1]); edge_colors.append(color_map[v2])

                if edge_coords:
                    # Edge overlay AA (mode-controlled)
                    if aa_mode == "AA_2PASS":
                        try:
                            aa_outer_w = overlay_line_width + 1.0
                            _prop_state_set('line_width', aa_outer_w)
                            edge_colors_aa = [(c[0], c[1], c[2], c[3] * 0.18) for c in edge_colors]
                            batch_edges_aa = batch_for_shader(shader, 'LINES', {"pos": edge_coords, "color": edge_colors_aa})
                            batch_edges_aa.draw(shader)
                        except Exception:
                            pass
                    _prop_state_set('line_width', overlay_line_width)
                    batch_edges = batch_for_shader(shader, 'LINES', {"pos": edge_coords, "color": edge_colors})
                    batch_edges.draw(shader)
                if point_coords:
                    _prop_state_set('point_size', overlay_point_size)
                    batch_points = batch_for_shader(shader, 'POINTS', {"pos": point_coords, "color": point_colors})
                    batch_points.draw(shader)
            except Exception: continue

    except Exception: pass
    finally:
        for fn, val in (("multisample_set", False), ("line_smooth_set", False), ("alpha_to_coverage_set", False)):
            try: getattr(gpu.state, fn)(val)
            except Exception: pass
        # Restore the draw-handler snapshot instead of forcing a blend/depth mode.
        # Forcing NONE or a fixed depth state here can leak into the next Sidebar
        # UI pass when this callback is re-entered or directly called during handler
        # recovery.
        try: mesh._sos_reset_gpu_state_after_draw()
        except Exception: pass
        try: _prop_state_set('line_width', 1.0)
        except Exception: pass
        try: _prop_state_set('point_size', 1.0)
        except Exception: pass

# =============================================================================
# Handlers
# =============================================================================

def _tag_prop_overlay_redraw(context=None):
    try:
        request_prop_view3d_snapshot_rebuild('proportional_event', context=context or getattr(bpy, 'context', None), immediate=False)
    except Exception:
        pass
    try:
        request_prop_uv_snapshot_rebuild('proportional_event', context=context or getattr(bpy, 'context', None), immediate=False)
    except Exception:
        pass
    try:
        mesh.tag_view3d_redraw(context)
    except Exception:
        pass
    try:
        ctx = context or getattr(bpy, 'context', None)
        from . import uv as _sos_uv
        for win in _sos_uv._uv_iter_windows(ctx):
            screen = getattr(win, 'screen', None)
            for area in tuple(getattr(screen, 'areas', ()) or ()):
                try:
                    if getattr(area, 'type', '') == 'VIEW_3D' or _uv_prop_is_uv_editor_area(area):
                        area.tag_redraw()
                except Exception:
                    pass
    except Exception:
        pass




def _prop_mesh_runtime_will_draw_final_pass(context=None) -> bool:
    """Return True when the View3D proportional overlay is delegated to mesh.py.

    SpaceView3D POST_VIEW handler ordering is not a stable contract during add-on
    recovery, mode switches, or watchdog re-hooks.  When the Mesh/Curve overlay
    runtime owns the active View3D draw callback, let that callback draw the
    proportional heatmap as its final pass.  This makes the visual stack explicit:
    Mesh/Curve overlay first, Proportional overlay last.
    """
    try:
        ctx = context or bpy.context
        wm = getattr(ctx, 'window_manager', None)
        if wm is None or not bool(getattr(wm, 'sos_proportional_overlay_enabled', False)):
            return False
        if not _prop_view3d_pref_enabled(ctx):
            return False
        if getattr(mesh, '_draw_handler', None) is None:
            return False
        mode = str(getattr(ctx, 'mode', '') or '')
        mesh_overlay_enabled = bool(getattr(wm, 'sos_enabled', False))
        object_hover_enabled = bool(getattr(wm, 'sos_object_hover_overlay_enabled', False))
        if mode in {'EDIT_MESH', 'EDIT_LATTICE', 'EDIT_CURVE', 'EDIT_CURVES'}:
            return bool(mesh_overlay_enabled)
        if mode in {'OBJECT', 'SCULPT'}:
            return bool(mesh_overlay_enabled or object_hover_enabled)
    except Exception:
        return False
    return False


def draw_callback_prop_mesh_front_pass(context=None):
    """Draw the proportional overlay from mesh.py after every mesh overlay pass.

    This is intentionally separate from ``draw_callback_prop``.  The standalone
    handler skips itself when this mesh-owned front pass is available, preventing
    double alpha blending while keeping the proportional heatmap above all Mesh,
    Curve, Hover, topology, face-center-dot, native edge, edge-cover, and
    vertex-cover overlay passes.
    """
    global _prop_last_view3d_draw_time, _prop_draw_exception_count
    _prop_last_view3d_draw_time = time.time()
    _sos_gpu_snapshot = mesh._sos_push_gpu_state_restore()
    _sos_clip_token = mesh._sos_begin_sidebar_safe_overlay_clip(context or bpy.context)
    try:
        # The mesh passes leave shader-controlled point size on; these points use point_size_set.
        gpu.state.program_point_size_set(False)
        return _replay_view3d_snapshot(context or bpy.context)
    except Exception:
        _prop_draw_exception_count += 1
        try:
            _prop_start_runtime_watchdog()
        except Exception:
            pass
        try:
            mesh.tag_view3d_redraw(context)
        except Exception:
            pass
        return None
    finally:
        try:
            mesh._sos_reset_gpu_state_after_draw()
        except Exception:
            pass
        try:
            mesh._sos_end_sidebar_safe_overlay_clip(_sos_clip_token)
        except Exception:
            pass
        try:
            mesh._sos_pop_gpu_state_restore(_sos_gpu_snapshot)
        except Exception:
            pass

def draw_callback_prop_uv():
    """Draw the UV proportional overlay in the actual UV Editor owner context.

    Blender 5.1 can invoke a shared SpaceImageEditor callback while the Python
    context points at another editor or has no edit-object slots.  The previous
    snapshot-only callback returned before resolving the live UV WINDOW region,
    making every UV-side proportional feature appear inactive.  Restore the
    known-good direct, normalized draw route while retaining the existing guarded
    geometry caches inside ``_draw_callback_prop_uv_impl``.
    """
    global _prop_last_uv_draw_time, _prop_draw_exception_count
    _prop_last_uv_draw_time = time.time()
    ctx = getattr(bpy, 'context', None)
    if ctx is None:
        return None

    area = getattr(ctx, 'area', None)
    region = getattr(ctx, 'region', None)
    target = None
    try:
        from . import uv as _sos_uv
        target = _sos_uv._uv_editor_target_for_region(ctx, region=region, area=area)
        if not isinstance(target, dict):
            if getattr(area, 'type', None) == 'IMAGE_EDITOR':
                return None
            target = next(iter(_sos_uv._uv_iter_live_editor_targets(ctx) or ()), None)
    except Exception:
        target = None
    if not isinstance(target, dict):
        return None

    uv_area = target.get('area')
    uv_region = target.get('region')
    if not _uv_prop_is_uv_editor_area(uv_area) or getattr(uv_region, 'type', None) != 'WINDOW':
        return None

    override = {
        'window': target.get('window'),
        'screen': target.get('screen'),
        'area': uv_area,
        'region': uv_region,
        'space_data': target.get('space_data') or getattr(getattr(uv_area, 'spaces', None), 'active', None),
    }
    override = {key: value for key, value in override.items() if value is not None}
    try:
        obj = _uv_prop_primary_edit_mesh_object(ctx)
        if obj is not None and getattr(obj, 'type', None) == 'MESH':
            override.update(active_object=obj, object=obj, edit_object=obj)
    except Exception:
        pass

    _sos_gpu_snapshot = None
    _sos_clip_token = None
    try:
        with ctx.temp_override(**override):
            draw_ctx = bpy.context
            # The Smart Tools Manager cell of this UV Editor silences the display
            # here; an OFF cell used to hide only the tab while drawing went on.
            try:
                from . import common as _sos_common
                if not _sos_common.manager_editor_cell_allows_runtime(draw_ctx):
                    return None
            except Exception:
                pass
            _sos_gpu_snapshot = mesh._sos_push_gpu_state_restore()
            _sos_clip_token = mesh._sos_begin_post_pixel_ui_region_clip(draw_ctx)
            return _draw_callback_prop_uv_impl()
    except Exception:
        _prop_draw_exception_count += 1
        try:
            request_prop_uv_snapshot_rebuild('direct_draw_exception', context=ctx, immediate=True)
        except Exception:
            pass
        try:
            _prop_start_runtime_watchdog()
        except Exception:
            pass
        return None
    finally:
        try:
            mesh._sos_end_post_pixel_ui_region_clip(_sos_clip_token)
        except Exception:
            pass
        try:
            mesh._sos_pop_gpu_state_restore(_sos_gpu_snapshot, ui_safe=True)
        except Exception:
            pass


def draw_callback_prop():
    global _prop_last_view3d_draw_time, _prop_draw_exception_count
    _prop_last_view3d_draw_time = time.time()
    _sos_gpu_snapshot = mesh._sos_push_gpu_state_restore()
    _sos_clip_token = mesh._sos_begin_sidebar_safe_overlay_clip(bpy.context)
    try:
        # If the Mesh/Curve overlay runtime is active, it draws the proportional
        # overlay as the final View3D pass.  Skipping this standalone handler
        # prevents duplicate heatmap blending and removes all dependence on
        # Blender's draw-handler registration order.
        if _prop_mesh_runtime_will_draw_final_pass(bpy.context):
            return None
        return _replay_view3d_snapshot(bpy.context)
    except Exception:
        _prop_draw_exception_count += 1
        try:
            _prop_start_runtime_watchdog()
        except Exception:
            pass
        try:
            mesh.tag_view3d_redraw()
        except Exception:
            pass
        return None
    finally:
        try:
            mesh._sos_reset_gpu_state_after_draw()
        except Exception:
            pass
        try:
            mesh._sos_end_sidebar_safe_overlay_clip(_sos_clip_token)
        except Exception:
            pass
        try:
            mesh._sos_pop_gpu_state_restore(_sos_gpu_snapshot, ui_safe=True)
        except Exception:
            pass


@persistent
def prop_depsgraph_update_handler(scene, depsgraph):
    ctx = getattr(bpy, 'context', None)
    try:
        from . import uv as _sos_uv
        managers = tuple(_sos_uv._uv_iter_window_managers(ctx))
    except Exception:
        managers = ()
    if not any(bool(getattr(wm, 'sos_proportional_overlay_enabled', False)) for wm in managers):
        return
    mode = getattr(ctx, "mode", None)
    if mode == 'EDIT_MESH':
        target_types = {'MESH'}
        target_data_id_names = {'Mesh'}
    elif mode == 'EDIT_LATTICE':
        target_types = {'LATTICE'}
        target_data_id_names = {'Lattice'}
    elif mode == 'EDIT_CURVE':
        target_types = {'CURVE', 'SURFACE'}
        target_data_id_names = {'Curve', 'SurfaceCurve'}
    elif mode == 'EDIT_CURVES':
        target_types = {'CURVES'}
        target_data_id_names = {'Curves'}
    else:
        return

    targets = []
    try:
        objs = getattr(ctx, "objects_in_mode", None)
        if objs:
            targets = [o for o in objs if o and getattr(o, 'type', None) in target_types]
    except Exception:
        targets = []
    if not targets:
        obj = getattr(ctx, "active_object", None)
        if obj and getattr(obj, 'type', None) in target_types:
            targets = [obj]
    if not targets:
        return

    targets_set = set(targets)
    for update in getattr(depsgraph, 'updates', ()):
        try:
            upd_id = getattr(update, 'id', None)
            orig = getattr(upd_id, "original", upd_id)
        except Exception:
            continue

        try:
            if orig in targets_set:
                _SIGNAL_MONITOR.on_signal_received()
                _tag_prop_overlay_redraw(ctx)
                return
        except Exception:
            pass

        # Do not resolve Object.data inside depsgraph callbacks.  On Blender 5.1
        # this can force evaluated mesh/subdivision wrapper construction during
        # ID updates and may crash in C before Python can catch it.  A broad data
        # ID check is enough here because the handler only schedules redraws.
        try:
            id_rna = getattr(getattr(orig, 'bl_rna', None), 'identifier', '')
            if id_rna in target_data_id_names:
                _SIGNAL_MONITOR.on_signal_received()
                _tag_prop_overlay_redraw(ctx)
                return
        except Exception:
            continue


def _add_prop_draw_handler() -> None:
    global _draw_handler_prop, _draw_handler_prop_uv
    if _draw_handler_prop is None:
        _draw_handler_prop = bpy.types.SpaceView3D.draw_handler_add(draw_callback_prop, (), 'WINDOW', 'POST_VIEW')
    if _draw_handler_prop_uv is None:
        try:
            _draw_handler_prop_uv = bpy.types.SpaceImageEditor.draw_handler_add(draw_callback_prop_uv, (), 'WINDOW', 'POST_PIXEL')
        except Exception:
            _draw_handler_prop_uv = None


def _remove_prop_draw_handler() -> None:
    global _draw_handler_prop, _draw_handler_prop_uv
    if _draw_handler_prop is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_draw_handler_prop, 'WINDOW')
        except Exception:
            pass
        _draw_handler_prop = None
    if _draw_handler_prop_uv is not None:
        try:
            bpy.types.SpaceImageEditor.draw_handler_remove(_draw_handler_prop_uv, 'WINDOW')
        except Exception:
            pass
        _draw_handler_prop_uv = None


def ensure_draw_handler_draws_after_mesh() -> None:
    _remove_prop_draw_handler()
    _add_prop_draw_handler()
    handlers = getattr(bpy.app.handlers, 'depsgraph_update_post', None)
    if handlers is not None and prop_depsgraph_update_handler not in handlers:
        handlers.append(prop_depsgraph_update_handler)


def register():
    global _prop_runtime_registered, _prop_runtime_started_at
    _prop_runtime_registered = True
    _prop_runtime_started_at = time.time()
    globals()['_prop_draw_exception_count'] = 0
    if _draw_handler_prop is None or _draw_handler_prop_uv is None:
        _add_prop_draw_handler()
    _prop_start_runtime_watchdog()
    _prop_subscribe_tool_settings_msgbus()
    _register_prop_uv_boundary_handlers()
    try:
        request_prop_view3d_snapshot_rebuild('proportional_register', context=getattr(bpy, 'context', None), immediate=True)
    except Exception:
        pass
    try:
        request_prop_uv_snapshot_rebuild('proportional_register', context=getattr(bpy, 'context', None), immediate=True)
    except Exception:
        pass
    handlers = getattr(bpy.app.handlers, 'depsgraph_update_post', None)
    if handlers is not None and prop_depsgraph_update_handler not in handlers:
        handlers.append(prop_depsgraph_update_handler)


def unregister():
    global _prop_runtime_registered, _prop_uv_realtime_last_signature
    _prop_runtime_registered = False
    _prop_uv_realtime_last_signature = None
    _prop_unsubscribe_tool_settings_msgbus()
    _unregister_prop_uv_boundary_handlers()
    clear_uv_snapshots()
    _prop_stop_runtime_watchdog()
    _remove_prop_draw_handler()
    handlers = getattr(bpy.app.handlers, 'depsgraph_update_post', None)
    if handlers is not None:
        try:
            while prop_depsgraph_update_handler in handlers:
                handlers.remove(prop_depsgraph_update_handler)
        except Exception:
            pass
    _OVERLAY_CACHE.clear()
    clear_view3d_snapshots()
    try:
        _uv_prop_stale_draw_cache.clear()
    except Exception:
        pass
    try:
        _uv_prop_geometry_cache.clear()
    except Exception:
        pass
    _uv_prop_release_bmesh_pins()
