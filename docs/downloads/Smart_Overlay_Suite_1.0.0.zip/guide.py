# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
"""Adapt the current catalog to older help buttons."""

from . import help_content


_ALIAS_ROWS = (
    ("smart_measure_grid", "VIEW3D_PT_smart_measure_grid_overlay"),
    ("image_dimensions", "VIEW3D_PT_idv_settings"),
    ("smart_measure_items", "SMART_MEASURE_PT_Edit"),
    ("smart_measure_tools", "SMART_MEASURE_PT_Main"),
    ("smart_measure_configuration", "SMART_MEASURE_PT_Conf"),
    ("smart_measure_render", "SMART_MEASURE_PT_Render"),
    ("silhouette", "VIEW3D_PT_silhouette"),
    ("overview", "VIEW3D_PT_sos_root", "operator_index"),
)
ALIASES = {name: row[0] for row in _ALIAS_ROWS for name in row[1:]}
TITLE = ("Smart Overlay Help", "スマートオーバーレイ ヘルプ")
UNAVAILABLE = ("Help content could not be loaded.", "ヘルプ本文を読み込めませんでした。")


def _translated(value, default=("", "")):
    if isinstance(value, (tuple, list)) and len(value) >= 2:
        return tuple(str(value[index] or fallback) for index, fallback in enumerate(default))
    text = str(value or next((part for part in default if part), ""))
    return text, text


def _settings(entries):
    for item in entries:
        if isinstance(item, (list, tuple)) and len(item) >= 2:
            labels, descriptions = item[:2]
        else:
            labels, descriptions = str(item or ""), ""
        en, ja = _translated(labels)
        en_description, ja_description = _translated(descriptions)
        yield {"key": en, "name_en": en, "name_ja": ja,
               "description_en": en_description, "description_ja": ja_description}


def _legacy_group(topic):
    result = {"icon": str(topic.get("icon") or "HELP"), "operators": [],
              "settings": list(_settings(topic.get("settings") or ()))}
    for field in ("title", "overview", "usage"):
        default = TITLE if field == "title" else ("", "")
        for language, text in zip(("en", "ja"), _translated(topic.get(field), default), strict=True):
            result[f"{field}_{language}"] = text if field == "title" else ([text] if text else [])
    return result


def get_group(topic=None):
    name = str(topic or "overview")
    try:
        catalog = help_content._topics()
        target = catalog.get(ALIASES.get(name, name)) or catalog.get("overview")
        if isinstance(target, dict):
            return _legacy_group(target)
    except Exception:
        pass  # Keep the legacy popup usable when a catalog cannot be loaded.
    return _legacy_group({"title": TITLE, "overview": UNAVAILABLE})


def all_topics():
    try:
        available = set(help_content._topics())
    except Exception:
        available = {"overview"}
    return sorted(available.union(ALIASES))
