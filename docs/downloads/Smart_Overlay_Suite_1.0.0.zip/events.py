# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""読み込み・保存・終了の handler を製品で 1 つにまとめる。

各機能は handler を直接 bpy.app.handlers へ入れず、add_hook() で登録する。
Blender の list に入るのは load_pre・load_post・save_pre・exit_pre の各 1 関数だけで、
中で登録順に呼ぶ（Blender が list の順に呼ぶのと同じ順）。呼ぶ物が無くなれば list から外す。
"""

from __future__ import annotations

import bpy
from bpy.app.handlers import persistent

_EVENTS = ('load_pre', 'load_post', 'save_pre', 'exit_pre')
_HOOKS: dict[str, list] = {name: [] for name in _EVENTS}
_FAILED: set = set()


def _warn_once(key, exc) -> None:
    if key not in _FAILED:
        _FAILED.add(key)
        print(f'[Smart Overlay] {key}: {exc}')


def _run(event: str, dummy) -> None:
    for fn in tuple(_HOOKS.get(event, ())):
        try:
            fn(dummy)
        except Exception as exc:
            _warn_once(f'{event}:{getattr(fn, "__name__", "?")}', exc)


@persistent
def _on_load_pre(dummy=None):
    _run('load_pre', dummy)


@persistent
def _on_load_post(dummy=None):
    _run('load_post', dummy)


@persistent
def _on_save_pre(dummy=None):
    _run('save_pre', dummy)


@persistent
def _on_exit_pre(dummy=None):
    _run('exit_pre', dummy)


_DISPATCH = {
    'load_pre': _on_load_pre,
    'load_post': _on_load_post,
    'save_pre': _on_save_pre,
    'exit_pre': _on_exit_pre,
}


def _sync(event: str) -> None:
    try:
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        lst = getattr(handlers, event, None)
        fn = _DISPATCH[event]
        if lst is None:
            return
        if _HOOKS[event]:
            if fn not in lst:
                lst.append(fn)
        else:
            while fn in lst:
                lst.remove(fn)
    except Exception as exc:
        _warn_once(f'sync:{event}', exc)


def add_hook(event: str, fn) -> None:
    hooks = _HOOKS.get(event)
    if hooks is None:
        return
    if fn not in hooks:
        hooks.append(fn)
    _sync(event)


def remove_hook(event: str, fn) -> None:
    hooks = _HOOKS.get(event)
    if hooks is None:
        return
    while fn in hooks:
        hooks.remove(fn)
    _sync(event)


def clear_all() -> None:
    for name in _EVENTS:
        _HOOKS[name].clear()
        _sync(name)
