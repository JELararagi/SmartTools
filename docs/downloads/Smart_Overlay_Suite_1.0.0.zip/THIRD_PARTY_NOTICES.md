# Third-party notices / 第三者のソフトウェアの表示

This add-on is licensed under GPL-3.0-or-later. Parts of it are derived from the software listed below; their copyright holders and licenses are kept here.
このアドオンは GPL-3.0-or-later です。一部は次のソフトウェアに由来します。元の著作権者とライセンスをここに残します。

## Cross_Select
- Origin / 出どころ: extensions.blender.org: Cross_Select — https://vrm-addon-for-blender.info
- Copyright / 著作権者: RARA, CYX, Witty.Ming, Shuimeng
- License / ライセンス: GPL-3.0-or-later
- Derived files in this add-on / 由来の部品:
  - smart_measure/smart_measure_sum_edge_lengths.py

## io_mesh_uv_layout
- Origin / 出どころ: Blender 5.1 bundled add-on (scripts/addons_core/io_mesh_uv_layout)
- Copyright / 著作権者: Blender Foundation / Blender Authors
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - smart_measure/smart_measure_render.py
