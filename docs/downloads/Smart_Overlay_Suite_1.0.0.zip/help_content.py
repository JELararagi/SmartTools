# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Lazy-loaded Smart Overlay help content.

This module is intentionally imported only from the help popup operator after a
user clicks a Help button.  The normal N-panel draw path does not import this
module, does not build the topic table, and does not allocate the long help
strings during Blender startup or ordinary panel use.
"""

from __future__ import annotations

import ast
import unicodedata
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Iterable, Sequence

try:
    from . import icons as sos_icons
except Exception:  # pragma: no cover - safe outside package import
    sos_icons = None

try:
    import bpy
except Exception:  # pragma: no cover - Blender-only module
    bpy = None

try:
    from .translation import TI as _TI, TT as _TT
except Exception:  # pragma: no cover - safe outside Blender
    def _TI(text):
        return str(text or '')

    def _TT(text):
        return str(text or '')

Pair = tuple[str, str]
Setting = tuple[Pair, Pair]
Topic = dict[str, object]

def _SICON(name: str = '', fallback: str = 'NONE') -> int:
    try:
        if sos_icons is None:
            return 0
        return int(sos_icons.icon_value(name, fallback) or 0)
    except Exception:
        return 0

def _label_icon(layout, text: str = '', icon: str = 'NONE'):
    try:
        return layout.label(text=text, **sos_icons.icon_kwargs(icon, icon))
    except Exception:
        return layout.label(text=text, icon=icon)

_TOPIC_CACHE: dict[str, Topic] | None = None


def _is_japanese(context=None) -> bool:
    candidates: list[str] = []
    for source in (
        lambda: getattr(getattr(getattr(context, 'preferences', None), 'view', None), 'language', ''),
        lambda: getattr(getattr(getattr(bpy, 'context', None), 'preferences', None).view, 'language', '') if bpy is not None else '',
        lambda: getattr(getattr(bpy, 'app', None).translations, 'locale', '') if bpy is not None else '',
    ):
        try:
            value = str(source() or '')
        except Exception:
            value = ''
        if value:
            candidates.append(value.upper())
    joined = ' '.join(candidates)
    return any(token in joined for token in ('JA', 'JA_JP', 'JAPANESE', 'JP'))


def L(context, en: str, ja: str) -> str:
    return str(ja if _is_japanese(context) else en)


def _p(en: str, ja: str) -> Pair:
    return (str(en), str(ja))


def _s(name_en: str, name_ja: str, desc_en: str, desc_ja: str) -> Setting:
    return (_p(name_en, name_ja), _p(desc_en, desc_ja))


def has_topic(topic_id: str) -> bool:
    return str(topic_id or '') in _topics()


def topic_label(topic_id: str, context=None) -> str:
    topic = _topics().get(str(topic_id or ''))
    if not topic:
        return L(context, 'Help', 'ヘルプ')
    title = topic.get('title', _p('Help', 'ヘルプ'))
    return _loc_pair(title, context)


def _loc_pair(pair, context=None) -> str:
    if isinstance(pair, (tuple, list)) and len(pair) >= 2:
        return L(context, str(pair[0]), str(pair[1]))
    return str(pair or '')


_HELP_POPUP_WIDTH_PX = 860
_TEXT_WIDTH_CACHE: dict[tuple[str, int], float] = {}


def _char_units(char: str) -> int:
    """Return fallback visual width units when Blender font measurement is unavailable."""
    if not char:
        return 0
    if char == '\t':
        return 4
    try:
        return 2 if unicodedata.east_asian_width(char) in {'F', 'W'} else 1
    except Exception:
        return 1


def _visual_units(text: str) -> int:
    return sum(_char_units(ch) for ch in str(text or ''))


def _ui_font_size_px(context=None) -> int:
    """Best-effort UI label font size used only for popup-width text measurement."""
    points = 11.0
    scale = 1.0
    try:
        prefs = getattr(context, 'preferences', None) or getattr(getattr(bpy, 'context', None), 'preferences', None)
    except Exception:
        prefs = None
    try:
        styles = getattr(prefs, 'ui_styles', None)
        if styles:
            style = styles[0]
            widget_label = getattr(style, 'widget_label', None)
            value = getattr(widget_label, 'points', None)
            if value:
                points = float(value)
    except Exception:
        pass
    for source in (
        lambda: getattr(getattr(prefs, 'system', None), 'ui_scale', None),
        lambda: getattr(getattr(prefs, 'view', None), 'ui_scale', None),
    ):
        try:
            value = source()
            if value:
                scale = float(value)
                break
        except Exception:
            pass
    return max(8, int(round(points * max(0.5, min(scale, 4.0)))))


def _measure_text_px(text: str, context=None) -> float:
    """Measure label text in pixels; fall back conservatively outside Blender."""
    text = str(text or '')
    if not text:
        return 0.0
    font_size = _ui_font_size_px(context)
    key = (text, font_size)
    cached = _TEXT_WIDTH_CACHE.get(key)
    if cached is not None:
        return cached
    try:
        import blf  # type: ignore
        try:
            blf.size(0, font_size)
        except TypeError:
            blf.size(0, font_size, 72)
        dims = blf.dimensions(0, text)
        width_px = float(dims[0])
        if width_px <= 0.0:
            raise ValueError('empty blf dimensions')
    except Exception:
        width_px = float(_visual_units(text) * max(6.0, font_size * 0.58))
    _TEXT_WIDTH_CACHE[key] = width_px
    if len(_TEXT_WIDTH_CACHE) > 4096:
        _TEXT_WIDTH_CACHE.clear()
    return width_px


def _popup_width_px(context=None, fallback: int = _HELP_POPUP_WIDTH_PX) -> int:
    """Return the declared help-popup width in pixels.

    Popup draw callbacks can expose the caller's N-panel region instead of the
    temporary popup region, so the operator's invoke width is the reliable base.
    """
    del context
    return max(360, int(fallback or _HELP_POPUP_WIDTH_PX))


def _available_text_px(
    context=None,
    *,
    popup_width_px: int = _HELP_POPUP_WIDTH_PX,
    indent: int = 0,
    icon: str = 'NONE',
    nested_level: int = 1,
) -> int:
    """Compute the label text width from the popup width, not a fixed character count."""
    popup_width = _popup_width_px(context, popup_width_px)
    ui_size = _ui_font_size_px(context)
    outer_padding = int(round(ui_size * 5.4))
    nested_padding = max(0, int(nested_level)) * int(round(ui_size * 1.7))
    icon_padding = int(round(ui_size * 2.2)) if str(icon or 'NONE') != 'NONE' else 0
    indent_padding = max(0, int(indent)) * int(round(ui_size * 0.55))
    usable = popup_width - outer_padding - nested_padding - icon_padding - indent_padding
    return max(160, int(usable))


def _split_token_by_px(token: str, max_width_px: float, context=None) -> list[str]:
    token = str(token or '')
    if not token:
        return ['']
    if _measure_text_px(token, context) <= max_width_px:
        return [token]
    result: list[str] = []
    current = ''
    for ch in token:
        candidate = current + ch
        if current and _measure_text_px(candidate, context) > max_width_px:
            result.append(current)
            current = ch
        else:
            current = candidate
    if current:
        result.append(current)
    return result or ['']


def _wrap_paragraph_px(raw: str, max_width_px: float, context=None) -> list[str]:
    raw = str(raw or '').strip()
    if not raw:
        return ['']
    if _measure_text_px(raw, context) <= max_width_px:
        return [raw]

    if any(ch.isspace() for ch in raw):
        pieces = [piece for piece in raw.split() if piece]
        lines: list[str] = []
        current = ''
        for piece in pieces:
            tokens = _split_token_by_px(piece, max_width_px, context)
            for token in tokens:
                candidate = f'{current} {token}' if current else token
                if current and _measure_text_px(candidate, context) > max_width_px:
                    lines.append(current)
                    current = token
                else:
                    current = candidate
        if current:
            lines.append(current)
        return lines or ['']

    return _split_token_by_px(raw, max_width_px, context)


def _wrap_to_popup_width(text: str, max_width_px: float, context=None) -> list[str]:
    text = str(text or '').replace('\r\n', '\n').replace('\r', '\n')
    lines: list[str] = []
    for raw in text.split('\n'):
        lines.extend(_wrap_paragraph_px(raw, max_width_px, context))
    return lines or ['']


def _draw_wrapped(
    layout,
    text: str,
    *,
    context=None,
    icon: str = 'NONE',
    popup_width_px: int = _HELP_POPUP_WIDTH_PX,
    indent: int = 0,
    nested_level: int = 1,
) -> None:
    if layout is None:
        return
    first = True
    indent = max(0, int(indent))
    pad = ' ' * indent
    max_width_px = _available_text_px(
        context,
        popup_width_px=popup_width_px,
        indent=indent,
        icon=icon,
        nested_level=nested_level,
    )
    for line in _wrap_to_popup_width(text, max_width_px=max_width_px, context=context):
        if line:
            _label_icon(layout, text=pad + line, icon=icon if first else 'NONE')
        else:
            layout.separator(factor=0.4)
        first = False

def _draw_section(
    layout,
    context,
    heading_en: str,
    heading_ja: str,
    body_pair: Pair,
    *,
    icon='NONE',
    popup_width_px: int = _HELP_POPUP_WIDTH_PX,
) -> None:
    box = layout.box()
    _label_icon(box, text=L(context, heading_en, heading_ja), icon=icon)
    col = box.column(align=True)
    _draw_wrapped(
        col,
        _loc_pair(body_pair, context),
        context=context,
        popup_width_px=popup_width_px,
        nested_level=2,
    )


def _draw_settings(
    layout,
    context,
    settings: Sequence[Setting],
    *,
    popup_width_px: int = _HELP_POPUP_WIDTH_PX,
) -> None:
    box = layout.box()
    _label_icon(box, text=L(context, '3. Settings', '3. 設定項目'), icon='PREFERENCES')
    col = box.column(align=True)
    for name_pair, desc_pair in settings:
        name = _loc_pair(name_pair, context)
        desc = _loc_pair(desc_pair, context)
        _draw_wrapped(
            col,
            name,
            context=context,
            icon='DOT',
            popup_width_px=popup_width_px,
            nested_level=2,
        )
        sub = col.column(align=True)
        _draw_wrapped(
            sub,
            desc,
            context=context,
            popup_width_px=popup_width_px,
            indent=2,
            nested_level=3,
        )
        col.separator(factor=0.35)




@dataclass(frozen=True)
class SourceSetting:
    module: str
    identifier: str
    property_type: str
    name: str
    description: str
    default: str


_SOURCE_TOPIC_PATHS = {
    'smart_measure': ('smart_measure',),
    'smart_measure_grid': ('smart_measure',),
    'smart_measure_tools': ('smart_measure',),
    'smart_measure_items': ('smart_measure',),
    'smart_measure_configuration': ('smart_measure',),
    'smart_measure_render': ('smart_measure',),
    'image_dimensions_viewer': ('image_dimensions_viewer',),
    'image_dimensions_node_editor': ('image_dimensions_viewer',),
    'image_dimensions_image_editor': ('image_dimensions_viewer',),
    'silhouette': ('silhouette',),
}

_SOURCE_TOPIC_CLASS_HINTS = {
    'smart_measure_grid': ('VIEW3D_PT_smart_measure_grid_overlay', 'smart_measure_grid', 'SmartMeasureGrid'),
    'smart_measure_tools': ('SMART_MEASURE_PT_Main', 'SMART_MEASURE_OT_Add', 'smart_measure_gl_', 'smart_measure_debug'),
    'smart_measure_items': ('SmartMeasureProperties', 'SmartMeasureGenerator', 'gl'),
    'smart_measure_configuration': ('SMART_MEASURE_PT_Conf', 'smart_measure_font_', 'smart_measure_glarrow', 'smart_measure_default', 'smart_measure_hint'),
    'smart_measure_render': ('SMART_MEASURE_PT_Render', 'smart_measure_render', 'smart_measure_rf'),
    'image_dimensions_node_editor': ('idv_node_show', 'node_'),
    'image_dimensions_image_editor': ('idv_image_show', 'ie_'),
}


def _package_root() -> Path:
    return Path(__file__).resolve().parent


def _call_name(node: ast.AST | None) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        parent = _call_name(node.value)
        return f'{parent}.{node.attr}' if parent else node.attr
    return ''


def _literal(node: ast.AST | None) -> str:
    if node is None:
        return ''
    if isinstance(node, ast.Call):
        call_name = _call_name(getattr(node, 'func', None)).split('.')[-1]
        if call_name in {'T', 'TI', 'TT', '_', 'pgettext_iface', 'pgettext_tip'}:
            args = list(getattr(node, 'args', ()) or ())
            if args:
                return _literal(args[0])
    try:
        value = ast.literal_eval(node)
    except Exception:
        try:
            return ast.unparse(node)
        except Exception:
            return ''
    if isinstance(value, (str, int, float, bool)) or value is None:
        return '' if value is None else str(value)
    if isinstance(value, (tuple, list)):
        return ', '.join(str(v) for v in value[:8])
    return str(value)


def _is_property_call(node: ast.AST | None) -> bool:
    return isinstance(node, ast.Call) and _call_name(node.func).endswith('Property')


def _target_name(node: ast.AST | None) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        base = _target_name(node.value)
        return f'{base}.{node.attr}' if base else node.attr
    if isinstance(node, ast.Subscript):
        return _target_name(node.value)
    return ''


def _property_call_from_node(node: ast.AST) -> tuple[str, ast.Call] | None:
    if isinstance(node, ast.AnnAssign):
        target = _target_name(node.target)
        if _is_property_call(node.value):
            return target, node.value  # type: ignore[return-value]
        if _is_property_call(node.annotation):
            return target, node.annotation  # type: ignore[return-value]
    if isinstance(node, ast.Assign):
        target = _target_name(node.targets[0]) if getattr(node, 'targets', None) else ''
        if _is_property_call(node.value):
            return target, node.value  # type: ignore[return-value]
    return None


def _keyword(call: ast.Call, name: str) -> str:
    for kw in getattr(call, 'keywords', ()) or ():
        if kw.arg == name:
            return _literal(kw.value)
    return ''


def _source_path_matches(topic_id: str, rel: str) -> bool:
    filters = tuple(_SOURCE_TOPIC_PATHS.get(topic_id, ()) or ())
    if not filters:
        return False
    return any(rel == item or rel.startswith(f'{item}/') for item in filters)


def _source_setting_matches_topic(topic_id: str, item: SourceSetting) -> bool:
    hints = tuple(_SOURCE_TOPIC_CLASS_HINTS.get(topic_id, ()) or ())
    if not hints:
        return True
    haystack = f'{item.module} {item.identifier} {item.name} {item.description}'
    return any(str(hint or '') in haystack for hint in hints)


@lru_cache(maxsize=32)
def _source_settings(topic_id: str) -> tuple[SourceSetting, ...]:
    root = _package_root()
    records: list[SourceSetting] = []
    for path in sorted(root.rglob('*.py')):
        try:
            rel = path.relative_to(root).as_posix()
        except Exception:
            continue
        if rel in {'help.py', 'help_content.py'}:
            continue
        if not _source_path_matches(topic_id, rel):
            continue
        try:
            source_text = path.read_text(encoding='utf-8', errors='ignore')
        except Exception:
            continue
        if 'Property(' not in source_text:
            continue
        try:
            tree = ast.parse(source_text)
        except Exception:
            continue
        for node in ast.walk(tree):
            found = _property_call_from_node(node)
            if not found:
                continue
            identifier, call = found
            if not identifier:
                continue
            prop_type = _call_name(call.func).split('.')[-1]
            name = _keyword(call, 'name') or identifier.rsplit('.', 1)[-1].replace('_', ' ').title()
            desc = _keyword(call, 'description')
            default = _keyword(call, 'default')
            item = SourceSetting(rel, identifier, prop_type, name, desc, default)
            if _source_setting_matches_topic(topic_id, item):
                records.append(item)
    seen: set[tuple[str, str, str]] = set()
    unique: list[SourceSetting] = []
    for item in records:
        key = (item.module, item.identifier, item.property_type)
        if key in seen:
            continue
        seen.add(key)
        unique.append(item)
    return tuple(unique)


def _localized_source_text(text: str, context=None, *, tooltip: bool = False) -> str:
    raw = str(text or '')
    if not raw:
        return ''
    if _is_japanese(context):
        try:
            return str((_TT if tooltip else _TI)(raw) or raw)
        except Exception:
            return raw
    return raw


def draw_help(
    layout,
    context,
    topic_id: str,
    *,
    popup_width_px: int = _HELP_POPUP_WIDTH_PX,
) -> None:
    topic = _topics().get(str(topic_id or ''))
    if topic is None:
        box = layout.box()
        _label_icon(box, text=L(context, 'Help topic was not found.', 'ヘルプ項目が見つかりません。'), icon='ERROR')
        return

    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass

    title = _loc_pair(topic.get('title'), context)
    icon = str(topic.get('icon') or 'HELP')
    header = layout.box()
    _draw_wrapped(
        header,
        title,
        context=context,
        icon=icon,
        popup_width_px=popup_width_px,
        nested_level=1,
    )

    overview = topic.get('overview')
    usage = topic.get('usage')
    settings = topic.get('settings') or ()
    if overview:
        _draw_section(
            layout,
            context,
            '1. Feature Overview',
            '1. 機能概要',
            overview,
            icon='NONE',
            popup_width_px=popup_width_px,
        )
    if usage:
        _draw_section(
            layout,
            context,
            '2. Usage',
            '2. 使用方法',
            usage,
            icon='QUESTION',
            popup_width_px=popup_width_px,
        )
    if settings:
        _draw_settings(layout, context, settings, popup_width_px=popup_width_px)


def _topics() -> dict[str, Topic]:
    global _TOPIC_CACHE
    if _TOPIC_CACHE is not None:
        return _TOPIC_CACHE

    _TOPIC_CACHE = {
        'overview': {
            'title': _p('Smart Overlay Suite', 'スマート オーバーレイ スイート'),
            'icon': 'HELP',
            'overview': _p(
                'Adds mesh, UV, measurement, and other overlays to Blender editors.',
                'Blender の各エディターにメッシュ、UV、計測などのオーバーレイを追加します。',
            ),
            'usage': _p(
                'Open Smart Overlay in the editor sidebar and expand the group you want to use. Open the help button in that group for its controls.',
                'エディターのサイドバーで Smart Overlay を開き、使いたいグループを展開します。操作項目の説明は、各グループのヘルプボタンから開けます。',
            ),
        },
        'always_on': {
            'title': _p('Always-on Toggle', '常時機能切り替え'),
            'icon': 'TIME',
            'overview': _p(
                'Switches the features that keep running in the background, not only when a button is pressed.',
                'ボタンを押した時だけでなく、裏で動き続ける機能をまとめて切り替えます。',
            ),
            'usage': _p(
                "Open the clock-icon Always-on Toggle group, then set N-panel State Save first. When it is enabled, every Smart Overlay N-panel setting change is saved to the settings file in Blender's config folder and loaded again on startup and scene changes. When it is disabled, the state at that moment is saved once, and later changes are not written; they are lost when Blender restarts. Then enable only the always-on features you currently need.",
                '時計アイコン付きの常時機能切り替えグループを開き、最初にNパネル状態保存を設定します。有効の場合は、Smart Overlay Nパネルで変更したすべての設定をBlenderのconfigフォルダ内の設定ファイルへ保存し、起動時とシーン切り替え時に再読み込みします。無効にすると、その時点の状態を一度だけ保存し、それ以降の変更は書き込みません（Blenderを起動し直すと元に戻ります）。その後、現在必要な常時機能だけを有効にします。',
            ),
            'settings': (
                _s('N-panel State Save', 'Nパネル状態保存', "Controls when Smart Overlay writes its settings file in Blender's config folder. ON saves every N-panel change immediately; OFF saves the state once at that moment and does not write later changes.", 'Blenderのconfigフォルダ内の設定ファイルへ書き込むタイミングを制御します。ONではNパネル変更を即時保存し、OFFにするとその時点の状態を一度だけ保存して、それ以降の変更は書き込みません。'),
                _s('Mesh and Curve Overlay', 'メッシュ・カーブ表示', 'Starts or stops the mesh and curve overlay in the 3D View.', '3Dビュー上のメッシュ・カーブ表示本体の常駐処理を開始・停止します。'),
                _s('Proportional Overlay', 'プロポーション表示', 'Starts or stops the proportional editing influence overlay.', 'プロポーショナル編集の影響範囲オーバーレイを開始・停止します。'),
                _s('Object / Sculpt Hover', 'オブジェクトホバー', 'Enables hover detection and hover drawing for Object Mode and Sculpt Mode.', 'オブジェクトモードとスカルプトモードのホバー検出・ホバー描画を有効化します。'),
                _s('UV Hover Overlay', 'UVホバーオーバーレイ', 'Enables hover feedback in the UV Editor only when required.', '必要な場合だけUVエディターのホバー表示を有効化します。'),
                _s('Smart Measure', 'スマート メジャー', 'Starts or stops Smart Measure grid-scale labels and measurement drawing.', 'スマート メジャーのグリッドスケール表示と計測描画の常駐処理を開始・停止します。'),
                _s('Image Size: Node', '画像サイズ: ノード', 'Shows texture resolution labels on Image Texture nodes.', 'Image Textureノード上に画像解像度ラベルを表示します。'),
                _s('Image Size: Image', '画像サイズ: 画像', 'Shows the active image resolution in the Image Editor.', '画像エディター内にアクティブ画像の解像度を表示します。'),
                _s('Silhouette Mode', 'シルエットモード', 'Switches the viewport into or out of the silhouette preview state.', 'ビューポートをシルエット確認状態へ切り替え、または解除します。'),
            ),
        },
        'feature_optimization': {
            'title': _p('Feature Optimization', '機能の最適化'),
            'icon': 'PREFERENCES',
            'overview': _p('Centralizes Mesh and Curve Overlay display targets, live-update behavior, draw/load controls, and heavy-scene limits in one section.', 'メッシュ・カーブ表示の表示対象、ライブ更新、描画負荷制御、高負荷制限を1つのセクションに整理します。'),
            'usage': _p('Choose an Optimization Preset first. Highest Quality prioritizes visual fidelity and live transform following. Standard and Lightweight reduce cache, redraw, and evaluated-face cost; they draw only on the active object, skip mesh hover and topology checks, and hide occluded colors while X-Ray is off. Lightest also skips the occluded pass, curves, lattices, and modifier results for maximum viewport response. Editing any individual item switches the preset to Custom. Every switch can still be changed by hand on any preset, and no item is hidden. Live transform following is protected internally.', '最初に最適化プリセットを選びます。最高品質は見た目とライブトランスフォーム追従を優先します。標準と軽量はキャッシュ、再描画、評価済み面の負荷を下げ、アクティブオブジェクトだけに描き、メッシュホバーとトポロジーチェックを省き、X-Ray がオフの間は遮蔽カラーを隠します。最軽量はさらに遮蔽パス、カーブ、ラティス、モディファイア後の形状を省いてビューの反応を最優先にします。個別項目を編集するとプリセットはカスタムになります。どのプリセットでもすべての項目を手で切り替えられ、隠れる項目はありません。トランスフォーム追従は内部で保護します。'),
            'settings': (
                _s('Optimization Preset', '最適化プリセット', 'Applies a set of mesh and curve display-scope values and optimization switches.', 'メッシュ・カーブ表示の表示範囲値と実行時最適化スイッチを、再精査済みの組み合わせとして適用します。'),
                _s('Display Scope and Quality', '表示対象・品質', 'Controls active-view drawing, evaluated objects, curve and lattice targets, double-sided face drawing, edit-mode evaluated faces, the optional still-view edit-cage vertex/edge pass, face center points, occluded-color visibility, hidden visible-color clipping, and scene occluders.', 'アクティブビュー描画限定、評価済みオブジェクト、カーブ／ラティス対象、両面描画、編集モード評価済み面、停止中の編集ケージ頂点・辺パス、面中央点、遮蔽カラー表示、背面可視カラー抑止、シーン遮蔽物を制御します。'),
                _s('Occlusion Off: Hide Hidden Parts', '遮蔽OFF時は裏側を隠す', 'When the occluded-color pass or the matching Vertex, Edge, or Face Occluded toggle is disabled, clips base visible-color drawing against the original stable depth so hidden parts do not appear in visible colors.', '遮蔽カラーパス、または対応する頂点・辺・面の「遮蔽」トグルが無効な時、通常の可視カラー描画を元の安定深度でクリップし、背面部分が可視カラーとして表示されないようにします。'),
                _s('Use Other Objects for Occlusion', '他オブジェクトも遮蔽に使用', 'When enabled, visible objects that are not selected and are not currently being edited are drawn into the depth pre-pass only, so Mesh and Curve Overlay and Hover Overlay vertices, edges, and faces become occluded when those other objects are in front of them.', 'ONの時、選択中ではなく編集中でもない表示中オブジェクトを、色は描かず深度プリパス専用の遮蔽物として追加します。これにより、他オブジェクトが手前にある場合は、メッシュ・カーブ表示／ホバーのオーバーレイの頂点・辺・面が遮蔽判定されます。'),
                _s('Include Curve Shapes', 'カーブ形状を含める', 'Draws curve edit control points and curve-shape edge overlays. Bevelled, extruded, or filled curves still use their evaluated render mesh for face overlay and mesh-like hover; line-only curves use the curve shape as the edge overlay target.', 'カーブ編集モードのコントロールポイントとカーブシェイプ辺にもオーバーレイを描画します。ベベル、押し出し、塗りつぶしのあるカーブでは面オーバーレイとメッシュ同等のホバーを評価済みレンダリングメッシュへ描画し、レンダリングメッシュがないカーブではカーブシェイプを辺オーバーレイ対象として使います。'),
                _s('Occlusion and Selection Cleanup', '遮蔽・Blender選択表示整理', 'Controls Smart Overlay adjacent-edge gradient suppression and Blender linked selection overlay suppression per select mode.', 'Smart Overlayの隣接辺グラデーション抑制と、選択モードごとのBlenderリンク選択オーバーレイ抑制を制御します。'),
                _s('Live Update and Cache', 'ライブ更新・キャッシュ', 'Controls dirty-generation cache checks, timed live-sync flushing, evaluated-face cache splitting, asynchronous rebuilds, stale-cache reuse, rebuild throttling, targeted modifier invalidation, and active-view redraw requests.', '変更世代キャッシュ判定、時間ベース同期破棄、評価済み面キャッシュ分離、非同期再構築、更新中キャッシュ再利用、再構築頻度制限、モディファイア依存の対象限定無効化、アクティブビュー再描画を制御します。'),
                _s('Draw Load and Hover', '描画負荷・ホバー', 'Controls the depth pass that runs only when needed, indexed edit batches, skipping inactive or zero-opacity batch work, hover-event-only updates, and separated topology diagnostic caching.', '必要な時だけ実行する深度パス、編集メッシュバッチのインデックス方式、無効または透明パスのバッチ処理スキップ、ホバーイベント起点更新、トポロジー診断キャッシュ分離を制御します。'),
                _s('Switches for Heavy Scenes', '重いシーン向けの項目', 'Controls navigation-time batch freezing, active-object-only drawing, occluded-pass disabling, topology disabling, and dense-mesh LOD as individually editable heavy-scene switches.', 'ビュー操作中のバッチ固定、アクティブオブジェクト限定描画、遮蔽パス無効化、トポロジー無効化、高密度メッシュLODを、個別に編集できる高負荷シーン用項目として制御します。'),
                _s('Reset', 'リセット', 'Restores Feature Optimization to default values.', '機能の最適化を既定値へ戻します。'),
            ),
        },
        'presets': {
            'title': _p('Presets', 'プリセット'),
            'icon': 'PRESET',
            'overview': _p('Stores and recalls visual overlay configurations so common display styles can be switched quickly.', '表示スタイルを保存・呼び出しして、よく使うオーバーレイ設定を素早く切り替えます。'),
            'usage': _p('Choose a preset, apply it, or save the current settings as a user preset. Built-in presets can be applied but user presets are the ones intended for deletion.', 'プリセットを選択して適用するか、現在の設定をユーザープリセットとして保存します。削除対象は主にユーザープリセットです。'),
            'settings': (
                _s('Preset', 'プリセット', 'Selects the preset slot to apply or manage.', '適用または管理するプリセットを選択します。'),
                _s('Apply Preset', 'プリセットを適用', 'Applies the selected preset to the current Smart Overlay settings.', '選択したプリセットを現在のSmart Overlay設定へ反映します。'),
                _s('Save Current as Preset', '現在状態をプリセットとして保存', 'Creates a user preset from the current settings.', '現在の設定からユーザープリセットを作成します。'),
                _s('Delete Preset', 'プリセットを削除', 'Deletes the selected user preset when deletion is allowed.', '削除可能なユーザープリセットを削除します。'),
                _s('Reset', 'リセット', 'Restores the preset section to its default state.', 'プリセット関連項目を既定状態へ戻します。'),
            ),
        },
        'mesh_overlay': {
            'title': _p('Mesh and Curve Overlay', 'メッシュ・カーブ表示'),
            'icon': 'MESH_DATA',
            'overview': _p('Draws vertex, edge, face, selection, occlusion, and hover information over mesh targets, and vertex/edge cage overlays over lattice targets in the 3D View.', '3Dビュー上のメッシュ対象には頂点・辺・面・選択・遮蔽・ホバー情報を、ラティス対象には制御点とケージ辺のオーバーレイを重ねて表示します。'),
            'usage': _p('Enable Mesh and Curve Overlay in Always-on Toggle, then tune the Vertex, Edge, Face, Occluded Display, Edge Anti-Aliasing, and Presets / I/O sections. Display scope and overlay cleanup items are under Feature Optimization.', '「常時機能切り替え」でメッシュ・カーブ表示を有効化し、頂点・辺・面・遮蔽表示・辺のアンチエイリアス・プリセット／入出力セクションを調整します。表示範囲やオーバーレイ整理の項目は「機能の最適化」にあります。'),
            'settings': (
                _s('Vertex Settings', '頂点設定', 'Controls edit/object vertex drawing, visible/occluded/selected/hover states, colors, size, and vertex depth offset.', '編集／オブジェクトの頂点描画、可視／遮蔽／選択／ホバー状態、色、サイズ、頂点深度オフセットを制御します。'),
                _s('Edge Settings', '辺設定', 'Controls edit/object edge drawing, visible/occluded/selected/hover states, colors, size, and edge depth offset.', '編集／オブジェクトの辺描画、可視／遮蔽／選択／ホバー状態、色、サイズ、辺深度オフセットを制御します。'),
                _s('Face Settings', '面設定', 'Controls edit/object face fill drawing, visible/occluded/selected/hover states, colors, opacity, and face depth offset.', '編集／オブジェクトの面塗り描画、可視／遮蔽／選択／ホバー状態、色、不透明度、面深度オフセットを制御します。'),
                _s('Occluded Display Mode', '遮蔽表示モード', 'Controls when hidden-behind-surface overlay elements are drawn and how their alpha, thickness, and point size are scaled.', 'サーフェス裏に隠れたオーバーレイ要素をいつ描画するか、透明度・線幅・ポイントサイズをどの倍率で扱うかを制御します。'),
                _s('Edge Anti-Aliasing', '辺のアンチエイリアス', 'Controls anti-aliasing behavior for edge overlay lines.', '辺オーバーレイラインのアンチエイリアス挙動を制御します。'),
                _s('Presets / I/O', 'プリセット・入出力', 'Applies visual presets, saves user presets, and manages scene-specific override storage.', '表示プリセットの適用、ユーザープリセット保存、シーン単位の上書き保存を管理します。'),
                _s('Feature Optimization', '機能の最適化', 'Contains display scope, evaluated object inclusion, edit-mode evaluation, and overlay cleanup controls.', '表示範囲、評価済みオブジェクト取り込み、編集モード評価、オーバーレイ整理を制御します。'),
            ),
        },
        'occluded_display': {
            'title': _p('Occluded Display Mode', '遮蔽表示モード'),
            'icon': 'XRAY',
            'overview': _p('Controls how elements hidden behind visible geometry are drawn.', '手前のジオメトリに隠れている要素をどのように表示するかを制御します。'),
            'usage': _p('Choose whether occluded overlays are visible only with X-Ray, always visible, or never visible. Then adjust the occluded style multipliers.', '遮蔽オーバーレイをX-Ray時のみ、常時、または非表示にするか選び、遮蔽スタイルの倍率を調整します。'),
            'settings': (
                _s('Hide When X-Ray Off', 'X-Ray OFF時に遮蔽を隠す', 'Quickly switches between X-Ray-only and always-visible occluded display behavior.', '遮蔽表示をX-Ray時のみ表示と常時表示の間で素早く切り替えます。'),
                _s('Display Mode', '表示モード', 'Selects X-Ray Only, Always, or Never for occluded elements.', '遮蔽要素を「X-Ray時のみ」「常に表示」「表示しない」から選択します。'),
                _s('Occluded Style', '遮蔽スタイル', 'Controls the visual treatment for occluded vertices, edges, and faces.', '遮蔽された頂点・辺・面の見た目を制御します。'),
                _s('Occluded Alpha Multiplier', '遮蔽アルファ倍率', 'Scales the transparency of occluded elements.', '遮蔽要素の透明度を倍率で調整します。'),
                _s('Occluded Line Width', '遮蔽線幅倍率', 'Scales occluded edge line width.', '遮蔽辺の線幅を倍率で調整します。'),
                _s('Occluded Point Multiplier', '遮蔽ポイント倍率', 'Scales occluded vertex point size.', '遮蔽頂点のポイントサイズを倍率で調整します。'),
                _s('Registration ID', '登録ID', 'Identifier used to assign a shortcut for the quick occlusion toggle.', '遮蔽表示のクイック切替にショートカットを割り当てるための識別子です。'),
            ),
        },
        'vertex_overlay': {
            'title': _p('Vertex Settings', '頂点設定'),
            'icon': 'VERTEXSEL',
            'overview': _p('Controls visible, occluded, selected, and hovered vertex drawing.', '可視・遮蔽・選択・ホバー状態の頂点描画を制御します。'),
            'usage': _p('Enable the vertex overlay in Edit and/or Object/Sculpt contexts, then choose which vertex states and colors are shown.', '編集モードまたはオブジェクト・スカルプトモードで頂点表示を有効化し、表示する頂点状態と色を選びます。'),
            'settings': (
                _s('Edit', '編集', 'Shows vertices in Edit Mode.', '編集モードで頂点を表示します。'),
                _s('Object / Sculpt', 'オブジェクト・スカルプト', 'Shows vertices in Object Mode and Sculpt Mode.', 'オブジェクトモードとスカルプトモードで頂点を表示します。'),
                _s('Visible Color (checkbox)', '可視カラー（チェック）', 'Draws vertices visible from the current view.', '現在の視点から見える頂点を描画します。'),
                _s('Occluded Color (checkbox)', '遮蔽カラー（チェック）', 'Draws vertices hidden behind geometry according to Occluded Display Mode.', '遮蔽表示モードに従い、ジオメトリの裏側の頂点を描画します。'),
                _s('Selected Color (checkbox)', '選択カラー（チェック）', 'Highlights selected vertices using the selected color.', '選択中の頂点を選択カラーで強調します。'),
                _s('Hover Color (checkbox)', 'ホバーカラー（チェック）', 'Highlights the vertex under the mouse in Edit Mode.', '編集モードでマウス下の頂点を強調します。'),
                _s('Object Hover', 'オブジェクトホバー', 'Highlights vertices on the hovered object in Object/Sculpt modes.', 'オブジェクト・スカルプトモードでホバー中オブジェクトの頂点を強調します。'),
                _s('Visible Color', '可視カラー', 'Color for visible vertices.', '可視頂点の色です。'),
                _s('Occluded Color', '遮蔽カラー', 'Color for occluded vertices.', '遮蔽頂点の色です。'),
                _s('Selected Color', '選択カラー', 'Color for selected vertices.', '選択頂点の色です。'),
                _s('Hover Color', 'ホバーカラー', 'Color for the hovered Edit Mode vertex.', '編集モードのホバー頂点の色です。'),
                _s('Object Hover Color', 'オブジェクトホバーカラー', 'Color for vertices on the hovered object.', 'ホバー中オブジェクト上の頂点色です。'),
                _s('Vertex Size(px)', '頂点サイズ(px)', 'Pixel size of overlay vertex points.', 'オーバーレイ頂点ポイントのピクセルサイズです。'),
                _s('Vertex Z-Offset', '頂点 深度オフセット強度', 'Depth offset used to reduce z-fighting with the mesh. The current 0.001 internal unit is displayed as 1.00: 3.00 applies 0.003, 0.01 applies 0.00001, and 0.00 disables the offset completely.', 'メッシュとのZファイトを抑えるための深度オフセットです。現在の内部単位0.001をUIでは1.00として表示します。3.00は0.003、0.01は0.00001として反映され、0.00で完全に無効化します。'),
            ),
        },
        'edge_overlay': {
            'title': _p('Edge Settings', '辺設定'),
            'icon': 'EDGESEL',
            'overview': _p('Controls visible, occluded, selected, and hovered edge drawing.', '可視・遮蔽・選択・ホバー状態の辺描画を制御します。'),
            'usage': _p('Enable edge drawing in the required modes, then tune visible, occluded, selected, hover, size, and depth settings.', '必要なモードで辺描画を有効化し、可視・遮蔽・選択・ホバー・サイズ・深度設定を調整します。'),
            'settings': (
                _s('Edit', '編集', 'Shows edges in Edit Mode.', '編集モードで辺を表示します。'),
                _s('Object / Sculpt', 'オブジェクト・スカルプト', 'Shows edges in Object Mode and Sculpt Mode.', 'オブジェクトモードとスカルプトモードで辺を表示します。'),
                _s('Visible Color (checkbox)', '可視カラー（チェック）', 'Draws edges visible from the current view.', '現在の視点から見える辺を描画します。'),
                _s('Occluded Color (checkbox)', '遮蔽カラー（チェック）', 'Draws edges behind geometry according to Occluded Display Mode.', '遮蔽表示モードに従い、ジオメトリの裏側の辺を描画します。'),
                _s('Selected Color (checkbox)', '選択カラー（チェック）', 'Highlights selected edges.', '選択中の辺を強調します。'),
                _s('Hover Color (checkbox)', 'ホバーカラー（チェック）', 'Highlights the edge under the mouse in Edit Mode.', '編集モードでマウス下の辺を強調します。'),
                _s('Object Hover', 'オブジェクトホバー', 'Highlights edges on the hovered object in Object/Sculpt modes.', 'オブジェクト・スカルプトモードでホバー中オブジェクトの辺を強調します。'),
                _s('Visible Color', '可視カラー', 'Color for visible edges.', '可視辺の色です。'),
                _s('Occluded Color', '遮蔽カラー', 'Color for occluded edges.', '遮蔽辺の色です。'),
                _s('Selected Color', '選択カラー', 'Color for selected edges.', '選択辺の色です。'),
                _s('Hover Color', 'ホバーカラー', 'Color for the hovered Edit Mode edge.', '編集モードのホバー辺の色です。'),
                _s('Object Hover Color', 'オブジェクトホバーカラー', 'Color for edges on the hovered object.', 'ホバー中オブジェクト上の辺色です。'),
                _s('Edge Size(px)', '辺サイズ(px)', 'Pixel line width of overlay edges.', 'オーバーレイ辺のピクセル線幅です。'),
                _s('Edge Z-Offset', '辺 深度オフセット強度', 'Depth offset used to reduce z-fighting with the mesh. The current 0.001 internal unit is displayed as 1.00: 2.00 applies 0.002, 0.01 applies 0.00001, and 0.00 disables the offset completely.', 'メッシュとのZファイトを抑えるための深度オフセットです。現在の内部単位0.001をUIでは1.00として表示します。2.00は0.002、0.01は0.00001として反映され、0.00で完全に無効化します。'),
            ),
        },
        'face_overlay': {
            'title': _p('Face Settings', '面設定'),
            'icon': 'FACESEL',
            'overview': _p('Controls filled face overlay drawing, including visible, occluded, selected, and hovered faces.', '可視・遮蔽・選択・ホバー状態を含む、塗りつぶし面オーバーレイを制御します。'),
            'usage': _p('Enable face drawing in the required modes, tune opacity carefully, and use Selected Color to control the Face Select overlay fill. Disable face drawing when only vertices or edges are needed.', '必要なモードで面描画を有効化し、不透明度を調整します。面選択オーバーレイの色は「選択カラー」で制御します。頂点や辺だけが必要な場合は面描画をOFFにします。'),
            'settings': (
                _s('Edit', '編集', 'Shows face overlays in Edit Mode.', '編集モードで面オーバーレイを表示します。'),
                _s('Object / Sculpt', 'オブジェクト・スカルプト', 'Shows face overlays in Object Mode and Sculpt Mode.', 'オブジェクトモードとスカルプトモードで面オーバーレイを表示します。'),
                _s('Visible Color (checkbox)', '可視カラー（チェック）', 'Draws visible faces.', '見えている面を描画します。'),
                _s('Occluded Color (checkbox)', '遮蔽カラー（チェック）', 'Draws faces hidden behind geometry according to Occluded Display Mode.', '遮蔽表示モードに従い、ジオメトリの裏側の面を描画します。'),
                _s('Selected Color (checkbox)', '選択カラー（チェック）', 'Highlights selected faces using the selected color. Alpha uses Face Opacity.', '選択中の面を選択カラーで強調表示します。アルファは面の不透明度を使用します。'),
                _s('Hover Color (checkbox)', 'ホバーカラー（チェック）', 'Highlights the face under the mouse in Edit Mode.', '編集モードでマウス下の面を強調します。'),
                _s('Object Hover', 'オブジェクトホバー', 'Highlights faces on the hovered object in Object/Sculpt modes.', 'オブジェクト・スカルプトモードでホバー中オブジェクトの面を強調します。'),
                _s('Visible Color', '可視カラー', 'Color for visible faces.', '可視面の色です。'),
                _s('Occluded Color', '遮蔽カラー', 'Color for occluded faces.', '遮蔽面の色です。'),
                _s('Selected Color', '選択カラー', 'Color for selected faces. Alpha uses Face Opacity.', '選択面の色です。アルファは面の不透明度を使用します。'),
                _s('Hover Color', 'ホバーカラー', 'Color for the hovered Edit Mode face.', '編集モードのホバー面の色です。'),
                _s('Object Hover Color', 'オブジェクトホバーカラー', 'Color for faces on the hovered object.', 'ホバー中オブジェクト上の面色です。'),
                _s('Face Opacity', '不透明度', 'Alpha amount for the filled face overlay.', '塗りつぶし面オーバーレイのアルファ量です。'),
                _s('Face Z-Offset', '面 深度オフセット強度', 'Depth offset used to reduce z-fighting with the mesh. The current 0.001 internal unit is displayed as 1.00: 1.00 applies 0.001, 0.01 applies 0.00001, and 0.00 disables the offset completely.', 'メッシュとのZファイトを抑えるための深度オフセットです。現在の内部単位0.001をUIでは1.00として表示します。1.00は0.001、0.01は0.00001として反映され、0.00で完全に無効化します。'),
            ),
        },
        'hover_overlay': {
            'title': _p('Hover Overlay', 'ホバーオーバーレイ'),
            'icon': 'TRACKER',
            'overview': _p('Controls how Smart Overlay detects and colors elements under the mouse cursor.', 'マウスカーソル下の要素をどのように検出し、色付けするかを制御します。'),
            'usage': _p('Use Auto for a balanced hover picker. Reduce hover element types or increase the threshold only when dense meshes need tuning.', '通常は「自動」を使用します。高密度メッシュで調整が必要な場合のみ、ホバー対象や閾値を調整してください。'),
            'settings': (
                _s('Hover LOD Mode', 'ホバーLODモード', 'Chooses the hover picking method: full scan, automatic switching, or face-local only.', 'ホバー判定方式を、全走査・自動切替・面ローカルのみから選択します。'),
                _s('Auto Switch Verts', '自動切替の頂点数閾値', 'Vertex-count threshold used by Auto mode.', '「自動」で判定方式を切り替える頂点数しきい値です。'),
                _s('Vertex', '頂点', 'Enables vertex hover drawing and sets its color.', '頂点ホバー描画と色を設定します。'),
                _s('Edge', '辺', 'Enables edge hover drawing and sets its color.', '辺ホバー描画と色を設定します。'),
                _s('Face', '面', 'Enables face hover drawing and sets its color.', '面ホバー描画と色を設定します。'),
            ),
        },
        'object_sculpt_hover': {
            'title': _p('Object / Sculpt Hover', 'オブジェクトホバーカラー'),
            'icon': 'OBJECT_DATAMODE',
            'overview': _p('Shows hover feedback for the object under the cursor in Object Mode and Sculpt Mode.', 'オブジェクトモードとスカルプトモードで、カーソル下オブジェクトのホバー表示を行います。'),
            'usage': _p('Enable it only when object-level hover feedback is needed, then choose vertex, edge, and face colors.', 'オブジェクト単位のホバー確認が必要な時だけ常駐を有効化し、頂点・辺・面の色を調整します。'),
            'settings': (
                _s('Always-on Toggle', '常時機能切り替え', 'Enables or disables Object/Sculpt hover detection and drawing.', 'オブジェクト・スカルプトのホバー検出と描画を有効・無効にします。'),
                _s('Vertex', '頂点', 'Shows vertices on the hovered object and sets the color.', 'ホバー中オブジェクトの頂点表示と色を設定します。'),
                _s('Edge', '辺', 'Shows edges on the hovered object and sets the color.', 'ホバー中オブジェクトの辺表示と色を設定します。'),
                _s('Face', '面', 'Shows faces on the hovered object and sets the color.', 'ホバー中オブジェクトの面表示と色を設定します。'),
                _s('Selection Delay (sec)', '選択後のホバー遅延 (秒)', 'Delay before hover detection resumes after selection changes.', '選択変更後にホバー検出を再開するまでの遅延時間です。'),
            ),
        },
        'uv_hover': {
            'title': _p('UV Hover', 'UVホバー'),
            'icon': 'GROUP_UVS',
            'overview': _p('Draws hover highlights for UV vertices, edges, and faces in the UV Editor.', 'UVエディターでUV頂点・辺・面のホバー強調表示を行います。'),
            'usage': _p('Enable UV Hover Overlay only while working in the UV Editor, then choose which UV element types should highlight. UV hover vertex/edge opacity and face opacity are independent from Mesh and Curve Overlay Face Opacity.', 'UVエディター作業中だけUVホバーオーバーレイを有効化し、強調するUV要素タイプを選びます。UVホバーの頂点・辺の不透明度と面の不透明度は、メッシュ・カーブ表示の面の不透明度とは独立しています。'),
            'settings': (
                _s('Always-on Toggle', '常時機能切り替え', 'Starts or stops the UV hover display.', 'UVホバーの表示を開始・停止します。'),
                _s('Vertex (checkbox)', '頂点（チェック）', 'Highlights UV vertices when UV select mode is Vertex.', 'UV選択モードが頂点のとき、UV頂点を強調します。'),
                _s('Vertex: (color)', '頂点:（色）', 'Color used for the hovered UV vertex.', 'ホバー中UV頂点の色です。'),
                _s('Edge (checkbox)', '辺（チェック）', 'Highlights UV edges when UV select mode is Edge.', 'UV選択モードが辺のとき、UV辺を強調します。'),
                _s('Edge: (color)', '辺:（色）', 'Color used for the hovered UV edge.', 'ホバー中UV辺の色です。'),
                _s('Face (checkbox)', '面（チェック）', 'Highlights UV faces when UV select mode is Face.', 'UV選択モードが面のとき、UV面を強調します。'),
                _s('Face: (color)', '面:（色）', 'Color used for the hovered UV face. Face opacity uses the face overlay opacity.', 'ホバー中UV面の色です。面の透明度は面オーバーレイの不透明度を使用します。'),
                _s('Show Same Mesh Element UVs', '同一メッシュ要素のUVを表示', 'Highlights unselected UV vertices and edges that share the same 3D mesh vertex or edge as the current UV selection.', '現在のUV選択と同じ3Dメッシュ頂点または辺を共有する未選択UV頂点・UV辺を強調表示します。'),
                _s('Same Vertex', '同一頂点', 'Enables the same-mesh-vertex helper overlay.', '同一メッシュ頂点の補助オーバーレイを有効にします。'),
                _s('Same Edge', '同一辺', 'Enables the same-mesh-edge helper overlay.', '同一メッシュ辺の補助オーバーレイを有効にします。'),
                _s('Same Mesh Element Color', '同一メッシュ要素カラー', 'Color for the same-mesh helper overlay. The default is yellow.', '同一メッシュ補助オーバーレイの色です。デフォルトは黄色です。'),
            ),
        },
        'high_precision_outline': {
            'title': _p('High-Precision Outline', '高精度アウトライン'),
            'icon': 'MOD_WIREFRAME',
            'overview': _p('Draws a precise outline around supported mesh elements in the 3D View.', '3Dビューで対応するメッシュ要素の輪郭を高精度に描画します。'),
            'usage': _p('Enable the feature, then adjust its color and thickness. Disable it to remove the outline. The outline follows frame changes and playback; for scenes too heavy to redo during playback, the standard Outline shows while the timeline or the object moves and the outline returns when it stops.', '機能を有効化してから色と太さを調整します。無効にすると輪郭は表示されません。輪郭はフレーム移動と再生に追従します。再生中に作り直すと遅くなる重い場面では、タイムラインや物が動いている間は標準のアウトラインを出し、止まると輪郭に戻します。'),
            'settings': (
                _s('Enable', '有効化', 'Turns High-Precision Outline drawing on or off.', '高精度アウトラインの描画をオンまたはオフにします。'),
                _s('Outline Color', '輪郭カラー', 'Sets the outline color.', '輪郭の色を設定します。'),
                _s('Outline Thickness', 'アウトラインの太さ', 'Sets the outline thickness.', '輪郭の太さを設定します。'),
            ),
        },
        'proportional_overlay': {
            'title': _p('Proportional Overlay', 'プロポーション表示'),
            'icon': 'MOD_VERTEX_WEIGHT',
            'overview': _p('Visualizes Blender proportional editing influence as a heatmap for Mesh, Curve, Lattice, Object Mode origins, and UV editing.', 'Blenderのプロポーショナル編集の影響範囲を、メッシュ・カーブ・ラティス・オブジェクトモードの原点・UV編集のヒートマップとして表示します。'),
            'usage': _p('Enable it in Always-on Toggle, turn on proportional editing in Tool Settings, then use Mesh, Curve, Lattice, Object Mode, or UV editing and adjust size, opacity, X-Ray, gradient colors, falloff, and radius.', '常駐を有効化し、ツール設定側のプロポーショナル編集をONにしてから、メッシュ・カーブ・ラティス・オブジェクトモード・UV編集で、サイズ、不透明度、X-Ray、グラデーション、フォールオフ、半径を調整します。'),
            'settings': (
                _s('Overlay Vertex Size(px)', '頂点サイズ(px)', 'Pixel size of proportional influence points, including mesh vertices, curve control points, lattice points, UV points, and object origins.', 'メッシュ頂点、カーブのコントロールポイント、ラティスポイント、UVポイント、オブジェクト原点を含む、プロポーショナル影響ポイントのピクセルサイズです。'),
                _s('Overlay Edge Size(px)', '辺サイズ(px)', 'Pixel line width of proportional influence mesh edges, curve shape lines, lattice cage edges, and UV edges.', 'メッシュ辺、カーブシェイプ線、ラティスケージ辺、UV辺を含む、プロポーショナル影響辺のピクセル線幅です。'),
                _s('Heatmap X-Ray', 'ヒートマップX-Ray', 'Draws the 3D heatmap through visible geometry instead of hiding occluded parts; the UV editor overlay remains 2D.', '隠れた部分を消さず、3Dジオメトリ越しにヒートマップを描画します。UVエディターの表示は2Dのままです。'),
                _s('Heatmap Opacity', 'ヒートマップ不透明度', 'Opacity multiplier for the proportional heatmap.', 'プロポーショナルヒートマップの不透明度倍率です。'),
                _s('Gradient Colors 0/25/50/75/100%', 'グラデーションカラー 0/25/50/75/100%', 'Defines the color ramp used by the influence heatmap.', '影響度ヒートマップで使用するカラーランプを設定します。'),
                _s('Enable', '有効化', 'Turns Blender proportional editing on or off.', 'Blenderのプロポーショナル編集をON/OFFします。'),
                _s('Connected', '接続のみ', 'Limits proportional editing to connected geometry when Blender exposes this option.', 'Blender側に項目がある場合、接続したジオメトリのみに影響を限定します。'),
                _s('Projected from View', 'ビューから投影', 'Uses the viewport-projected proportional editing mode when available.', '利用可能な場合、ビュー投影型のプロポーショナル編集を使用します。'),
                _s('Falloff Type', '減衰タイプ', 'Selects the proportional editing falloff curve.', 'プロポーショナル編集のフォールオフカーブを選択します。'),
                _s('Radius', '半径', 'Controls proportional editing influence radius.', 'プロポーショナル編集の影響半径を調整します。'),
                _s('Use in 3D View', '3Dビューで使用', 'Draws the proportional heatmap in the 3D View. Turn this off when you want the proportional overlay only in the UV Editor.', 'プロポーショナルヒートマップを3Dビューに描画します。UVエディターだけで使いたい場合はOFFにします。'),
                _s('Use in UV Editor', 'UVエディターで使用', 'Draws the proportional heatmap in the UV Editor while editing mesh UVs. The source selection is only UV Editor UV selection, not unrelated 3D View mesh selection.', 'メッシュUV編集中に、プロポーショナルヒートマップをUVエディターに描画します。影響元はUVエディター上のUV選択のみで、3Dビュー側のメッシュ選択は使用しません。'),
                _s('Proportional Display Toggle: Registration ID', 'プロポーション表示全体切り替え：登録ID', 'Identifier used to assign a shortcut to the proportional display toggle.', 'プロポーション表示全体切り替えへショートカットを割り当てるための識別子です。'),
                _s('Use in 3D View: Registration ID', '3Dビューで使用：登録ID', 'Identifier used to assign a shortcut to the 3D View use toggle.', '3Dビューで使用するかを切り替えるショートカット登録用の識別子です。'),
                _s('Use in UV Editor: Registration ID', 'UVエディターで使用：登録ID', 'Identifier used to assign a shortcut to the UV Editor use toggle.', 'UVエディターで使用するかを切り替えるショートカット登録用の識別子です。'),
            ),
        },
        'edge_aa': {
            'title': _p('Edge Anti-Aliasing', '辺のアンチエイリアス'),
            'icon': 'MOD_SMOOTH',
            'overview': _p('Changes the smoothing method used for mesh and proportional overlay edges.', 'メッシュ・カーブ表示およびプロポーショナルオーバーレイの辺の滑らかさを変更します。'),
            'usage': _p('Use No AA for maximum speed, Built-in AA for a balanced single-pass result, or Smooth (2-pass) when visual quality is more important than cost.', '速度優先ならAAなし、バランス重視なら内蔵AA、見た目優先なら滑らか（2パス）を使用します。'),
            'settings': (
                _s('Edge Anti-Aliasing', '辺のアンチエイリアス', 'Selects the edge smoothing mode.', '辺の滑らかさの方式を選択します。'),
                _s('No AA', 'AAなし', 'Draws edges as-is with the lowest cost.', '最小負荷で辺をそのまま描画します。'),
                _s('Built-in AA', '内蔵AA', 'Uses Blender/GPU line smoothing where available.', '利用可能な場合、Blender/GPUの線スムージングを使用します。'),
                _s('Smooth (2-pass)', '滑らか（2パス）', 'Draws an additional soft line under the main edge for the best quality.', '最高品質向けに、本線の下へ柔らかい補助線を追加描画します。'),
            ),
        },
        'integrated_tools': {
            'title': _p('Other Tools', 'その他ツール'),
            'icon': 'TOOL_SETTINGS',
            'overview': _p(
                'Groups four supporting tools in one section: Topology Checks, Image Dimensions Viewer, Smart Measure, and Silhouette Mode. Each tool has its own sub-section with its settings and help.',
                '補助のツール4つ（トポロジーチェック、画像サイズビューアー、スマート メジャー、シルエットモード）を1つのセクションにまとめます。各ツールは、設定とヘルプを持つ小さなセクションに分かれています。',
            ),
            'usage': _p(
                'Expand Other Tools and open the sub-section of the tool you want to use. Topology Checks is turned on with Enable Topology Checks in its own sub-section. Smart Measure, Image Size: Node, Image Size: Image, and Silhouette Mode keep running in the background, so switch them in Always-on Toggles. Open the help button of each sub-section for its settings.',
                '「その他ツール」を展開し、使いたいツールの小さなセクションを開きます。トポロジーチェックは、そのセクションの「トポロジーチェックを有効化」でオンにします。スマート メジャー、画像サイズ: ノード、画像サイズ: 画像、シルエットモードは裏で動き続ける機能なので、「常時機能切り替え」で切り替えます。各設定の説明は、それぞれのセクションのヘルプボタンから開けます。',
            ),
            'settings': (
                _s('Topology Checks', 'トポロジーチェック', 'Highlights seams, sharp edges, non-manifold edges, creases, bevel weights, ngons, tiny faces, and backfaces for inspection. Turn it on with Enable Topology Checks.', 'シーム、シャープ辺、非多様体辺、クリース、ベベルウェイト、Nゴン、小面、裏面を診断用に強調表示します。「トポロジーチェックを有効化」でオンにします。'),
                _s('Image Dimensions Viewer', '画像サイズビューアー', 'Shows image resolution labels on Image Texture nodes in the Node Editor and on the image shown in the Image Editor. Turn it on with Image Size: Node and Image Size: Image in Always-on Toggles.', 'ノードエディターの Image Texture ノードと、画像エディターに表示中の画像に、解像度のラベルを表示します。「常時機能切り替え」の「画像サイズ: ノード」「画像サイズ: 画像」でオンにします。'),
                _s('Smart Measure', 'スマート メジャー', 'Shows live grid-scale labels and creates measurement annotations such as distance, angle, and area in the viewport. Turn it on with Smart Measure in Always-on Toggles.', 'ライブのグリッドスケール表示と、距離・角度・面積などのビューポート計測注釈を扱います。「常時機能切り替え」の「スマート メジャー」でオンにします。'),
                _s('Silhouette Mode', 'シルエットモード', 'Switches the 3D View to a high-contrast silhouette preview for shape checking. Choose the current selection or all visible objects in its sub-section, then switch it with Silhouette Mode in Always-on Toggles.', '形状確認用に3Dビューを高コントラストのシルエット表示へ切り替えます。小さなセクションで現在の選択か全表示オブジェクトかを選び、「常時機能切り替え」の「シルエットモード」で切り替えます。'),
            ),
        },
        'topology_checks': {
            'title': _p('Topology Checks', 'トポロジーチェック'),
            'icon': 'MOD_WIREFRAME',
            'overview': _p('Adds diagnostic overlays for seams, sharp edges, non-manifold edges, creases, bevel weights, ngons, tiny faces, and backfaces.', 'シーム、シャープ辺、非多様体辺、クリース、ベベルウェイト、Nゴン、小面、裏面を診断用に強調表示します。'),
            'usage': _p('Enable topology checks only while cleaning or inspecting geometry. Turn off categories you do not need to keep the display clear.', '形状の整理・検査時だけ有効化し、不要なカテゴリはOFFにして表示を見やすくします。'),
            'settings': (
                _s('Enable Topology Checks', 'トポロジーチェックを有効化', 'Master switch for topology diagnostic overlays.', 'トポロジー診断オーバーレイ全体の主スイッチです。'),
                _s('Selection Filter', '選択フィルタ', 'Chooses whether checks consider all, selected, or unselected elements.', '全要素、選択要素、未選択要素のどれを検査対象にするか選びます。'),
                _s('Edges', '辺', 'Enables edge diagnostic overlays.', '辺の診断オーバーレイを有効化します。'),
                _s('Show Seams', 'UVシーム表示', 'Highlights UV seam edges.', 'UVシーム辺を強調します。'),
                _s('Show Sharp', 'シャープ表示', 'Highlights sharp/non-smooth edges.', 'シャープまたは非スムーズ辺を強調します。'),
                _s('Show Non-Manifold', '非マニフォールド表示', 'Highlights boundary and non-manifold edges.', '境界辺と非多様体辺を強調します。'),
                _s('Show Crease / Crease Threshold', 'クリース表示 / クリース閾値', 'Highlights creases above the threshold.', '閾値以上のクリースを強調します。'),
                _s('Show Bevel Weight / Bevel Weight Threshold', 'ベベルウェイト表示 / ベベル閾値', 'Highlights bevel-weighted edges above the threshold.', '閾値以上のベベルウェイト辺を強調します。'),
                _s('Topology Edge Colors', 'トポロジー辺カラー', 'Colors for seam, sharp, non-manifold, crease, and bevel diagnostics.', 'シーム、シャープ、非マニフォールド、クリース、ベベル診断用の色です。'),
                _s('Topology Line Width', 'トポ線幅倍率', 'Scales diagnostic edge line width.', '診断用の辺の線幅を倍率で調整します。'),
                _s('Faces', '面', 'Enables face diagnostic overlays.', '面の診断オーバーレイを有効化します。'),
                _s('Show Ngons', 'Nゴン表示', 'Highlights faces with five or more sides.', '5辺以上の面を強調します。'),
                _s('Show Small Faces / Small Face Area', '小面表示 / 小面面積', 'Highlights faces smaller than the area threshold.', '面積しきい値より小さい面を強調します。'),
                _s('Show Backfaces', '裏面表示', 'Highlights backfaces for normal-direction inspection.', '法線方向の確認用に裏面を強調します。'),
                _s('Topology Face Colors', 'トポロジー面カラー', 'Colors for ngon, small-face, and backface diagnostics.', 'Nゴン、小面、裏面診断用の色です。'),
                _s('Topology Face Opacity', 'トポ面不透明度倍率', 'Scales diagnostic face opacity.', '診断用フェイスの不透明度を倍率で調整します。'),
            ),
        },
        'image_dimensions_viewer': {
            'title': _p('Image Size Viewer', '画像サイズビューアー'),
            'icon': 'IMAGE_DATA',
            'overview': _p(
                'Shows image resolution labels on Image Texture nodes in the Node Editor and on the image shown in the Image Editor, so you can check texture sizes without opening each node.',
                'ノードエディターの Image Texture ノードと、画像エディターに表示中の画像に、解像度のラベルを表示します。ノードを開かずにテクスチャの大きさを確かめられます。',
            ),
            'usage': _p(
                'Turn on Image Size: Node or Image Size: Image in Always-on Toggle, or use the enable switch of each overlay in this group. Then adjust appearance, position, and colors in the Node Editor Overlay and Image Editor Overlay sections.',
                '「常時機能切り替え」の「画像サイズ: ノード」「画像サイズ: 画像」、またはこのグループ内の各表示のスイッチでオンにします。見た目・位置・色は「ノードエディター」「画像エディター」の項目で調整します。',
            ),
            'settings': (
                _s('Node Editor Overlay', 'ノードエディター', 'Shows resolution labels on Image Texture nodes.', 'Image Texture ノードの上に解像度を表示します。'),
                _s('Image Editor Overlay', '画像エディター', 'Shows the resolution of the image displayed in the Image Editor.', '画像エディターに表示中の画像の解像度を表示します。'),
            ),
        },
        'image_dimensions_node_editor': {
            'title': _p('Image Size: Node Editor Overlay', '画像サイズ: ノードエディター'),
            'icon': 'NODETREE',
            'overview': _p(
                'Draws the resolution of each Image Texture node above the node in the Node Editor.',
                'ノードエディターで、Image Texture ノードごとに画像の解像度をノードの上に表示します。',
            ),
            'usage': _p(
                'Turn on the enable switch, open a material node tree, then adjust the label here.',
                'スイッチをオンにしてマテリアルのノードツリーを開き、ここでラベルの見た目を調整します。',
            ),
            'settings': (
                _s('Appearance', '見た目', 'Sets the font size, padding, and corner radius of the label.', 'ラベルの文字サイズ・余白・角丸を設定します。'),
                _s('Position', '位置', 'Sets where the label sits relative to the node, with an offset.', 'ノードに対するラベルの位置とずらし量を設定します。'),
                _s('Colors', '色', 'Sets the background and text colors of the label.', 'ラベルの背景色と文字色を設定します。'),
            ),
        },
        'image_dimensions_image_editor': {
            'title': _p('Image Size: Image Editor Overlay', '画像サイズ: 画像エディター'),
            'icon': 'IMAGE_DATA',
            'overview': _p(
                'Draws the resolution of the displayed image in the Image Editor.',
                '画像エディターに、表示中の画像の解像度を表示します。',
            ),
            'usage': _p(
                'Turn on the enable switch, show an image in the Image Editor, then adjust the label here.',
                'スイッチをオンにして画像エディターに画像を表示し、ここでラベルの見た目を調整します。',
            ),
            'settings': (
                _s('Appearance', '見た目', 'Sets the font size, padding, and corner radius of the label.', 'ラベルの文字サイズ・余白・角丸を設定します。'),
                _s('Position', '位置', 'Sets the display origin and offset of the label.', 'ラベルの表示位置とずらし量を設定します。'),
                _s('Colors', '色', 'Sets the background and text colors of the label.', 'ラベルの背景色と文字色を設定します。'),
            ),
        },
        'smart_measure': {
            'title': _p('Smart Measure', 'スマート メジャー'),
            'icon': 'DRIVER_DISTANCE',
            'overview': _p(
                'Combines live grid-scale labels and viewport measurement annotations into one Smart Overlay tool group.',
                'ライブのグリッドスケール表示とビューポート計測注釈を、Smart Overlay内の一つのツールグループにまとめます。',
            ),
            'usage': _p(
                'Enable Smart Measure from Always-on Toggle. Use Grid Scale Overlay for automatic spacing labels, then use Smart Measure Tools, Items, Configuration, and Render when you need explicit measurement annotations or output.',
                '「常時機能切り替え」でスマート メジャーを有効化します。自動的な間隔ラベルは「グリッドスケール表示」で調整し、明示的な計測注釈や出力が必要な場合は「スマート メジャー ツール」「項目」「設定」「レンダー」を使用します。',
            ),
            'settings': (
                _s('Smart Measure', 'スマート メジャー', 'Master toggle for grid-scale labels and measurement annotation drawing.', 'グリッドスケールラベルと計測注釈描画をまとめて切り替える常駐スイッチです。'),
                _s('Grid Scale Overlay', 'グリッドスケール表示', 'Displays live spacing labels in the active 3D View.', 'アクティブな3Dビューに間隔ラベルをライブ表示します。'),
                _s('Smart Measure Tools', 'スマート メジャー ツール', 'Creates distance, angle, arc, label, note, link, origin, area, and selected-edge total measurements.', '距離、角度、円弧、ラベル、注釈、リンク、原点、面積、選択辺の合計の計測を作成します。'),
                _s('Items', '項目', 'Lists and edits created measurement items.', '作成済み計測項目を一覧・編集します。'),
                _s('Configuration', '設定', 'Defines default appearance and behavior for created measurements.', '作成する計測の既定表示と挙動を設定します。'),
                _s('Render', 'レンダー', 'Includes measurement annotations in render output when required.', '必要に応じて計測注釈をレンダー出力に含めます。'),
            ),
        },
        'smart_measure_grid': {
            'title': _p('Grid Scale Overlay', 'グリッドスケール表示'),
            'icon': 'GRID',
            'overview': _p(
                'Displays live grid spacing and dimension labels in the 3D View as part of Smart Measure.',
                'スマート メジャーの一部として、3Dビュー上にグリッド間隔と寸法ラベルをリアルタイム表示します。',
            ),
            'usage': _p(
                'Enable Smart Measure from Always-on Toggle, then adjust units, axes, edge snapping, maximum annotation count, and optional manual origin in this subsection.',
                '「常時機能切り替え」でスマート メジャーを有効化し、このサブセクションで単位、表示軸、端スナップ、最大注釈数、任意の手動原点を調整します。',
            ),
            'settings': (
                _s('Font Size', 'フォントサイズ', 'Text size of spacing labels.', '間隔ラベルの文字サイズです。'),
                _s('Color', 'カラー', 'Custom label color when axis-color mixing is low.', '軸色ミックスが低い場合に使うカスタムラベル色です。'),
                _s('Axis Color', '軸カラー', 'Mixes between custom color and axis-based coloring.', 'カスタム色と軸ごとの色の混合率です。'),
                _s('Alpha', 'アルファ', 'Opacity of the labels.', 'ラベルの不透明度です。'),
                _s('Units', '単位', 'Automatically follows the scene unit system when enabled.', '有効時はシーンの単位系に自動追従します。'),
                _s('X / Y / Z Axis', 'X / Y / Z 軸', 'Chooses which grid axes display spacing labels.', '間隔ラベルを表示するグリッド軸を選択します。'),
                _s('Perspective / Orthographic', '透視 / 平行投影', 'Chooses whether labels appear in perspective and/or orthographic views.', '透視表示または平行投影表示でラベルを出すか選択します。'),
                _s('Display Unit', '表示単位', 'Forces a specific unit or uses automatic unit scaling.', '特定単位に固定するか、自動スケーリングを使用します。'),
                _s('Edge Snap', '端へスナップ', 'Snaps labels to screen edges when they would go off-screen in orthographic views.', '平行投影でラベルが画面外へ出る場合、画面端へ吸着します。'),
                _s('Always Snap', '常にスナップ', 'Keeps orthographic labels snapped to screen edges.', '平行投影のラベルを常に画面端へ吸着させます。'),
                _s('Text Shadow', 'テキスト影', 'Adds a shadow for readability.', '視認性向上のため文字に影を追加します。'),
                _s('Edge Snap Margins (px)', '端スナップ余白 (px)', 'Top, bottom, left, and right snap margins in pixels.', '上・下・左・右の端スナップ余白をピクセル単位で設定します。'),
                _s('Unit System', '単位系', 'Manual meter/feet choice when scene-unit following is disabled.', 'シーン単位追従がOFFの場合のメートル/フィート選択です。'),
                _s('Manual Origin', '手動原点', 'Uses a custom origin instead of world origin.', 'ワールド原点ではなく任意の原点を使用します。'),
                _s('Use Cursor', 'カーソルを使用', 'Copies the 3D Cursor location to the manual origin.', '3Dカーソル位置を手動原点へコピーします。'),
                _s('Origin', '原点', 'Manual origin location.', '手動原点の位置です。'),
                _s('Max Annotations', '最大注釈数', 'Limits the number of labels for performance.', '負荷対策として表示ラベル数を制限します。'),
                _s('Animation', 'アニメーション', 'Selects label transition style.', 'ラベル遷移の見た目を選択します。'),
            ),
        },
        'smart_measure_tools': {
            'title': _p('Smart Measure Tools', 'スマート メジャー ツール'),
            'icon': 'DRIVER_DISTANCE',
            'overview': _p(
                'Provides the main Smart Measure creation buttons and the global display/debug controls used before editing individual measurement items.',
                'スマート メジャーの主要な作成ボタンと、個別計測項目を編集する前に使う全体表示・デバッグ制御をまとめたセクションです。',
            ),
            'usage': _p(
                'Enable Smart Measure in Always-on Toggle, select mesh vertices or objects according to the measurement type, then press the required add button. Use Mesh Debug only while inspecting object, vertex, edge, face, or normal reference data.',
                '「常時機能切り替え」でスマート メジャーを有効化し、計測タイプに合わせてメッシュ頂点やオブジェクトを選択してから、必要な追加ボタンを押します。メッシュデバッグは、オブジェクト・頂点・辺・面・法線の参照データを確認する時だけ使用してください。',
            ),
            'settings': (
                _s('All / Ghost', '全て / ゴースト', 'Controls whether Smart Measure elements remain visible globally or use ghost-style display behavior.', 'スマート メジャー要素を全体的に表示するか、ゴースト系の表示挙動で扱うかを制御します。'),
                _s('Segment', 'セグメント', 'Adds a distance measurement between selected vertices or references.', '選択頂点または参照間に距離計測を追加します。'),
                _s('Sum', '合計', 'Groups compatible segment measurements and displays their summed distance.', '対応するセグメント計測をグループ化し、距離合計を表示します。'),
                _s('X / Y / Z Orthogonal', 'X / Y / Z 直交', 'Adds axis-constrained measurements relative to the chosen axis.', '指定軸に拘束した直交計測を追加します。'),
                _s('Angle', '角度', 'Adds an angle measurement from the selected vertex set.', '選択頂点から角度計測を追加します。'),
                _s('Arc', '円弧', 'Adds an arc measurement with radius, length, and angle display options.', '半径・長さ・角度表示を持つ円弧計測を追加します。'),
                _s('Label', 'ラベル', 'Adds a simple text label tied to the current selection.', '現在の選択に紐づくシンプルなテキストラベルを追加します。'),
                _s('Annotation', '注釈', 'Adds a note-style text annotation.', 'ノート形式のテキスト注釈を追加します。'),
                _s('Link', 'リンク', 'Adds a measurement link between supported object or vertex references.', '対応するオブジェクトまたは頂点参照の間にリンク計測を追加します。'),
                _s('Origin', '原点', 'Adds a measurement from a selected reference to the origin.', '選択した参照から原点への計測を追加します。'),
                _s('Area', '面積', 'Adds an area measurement from selected faces.', '選択面から面積計測を追加します。'),
                _s('Sum Selected Edges', '選択辺の合計', 'Calculates and displays the total length of the currently selected mesh edges.', '現在選択中のメッシュ辺の長さ合計を計算して表示します。'),
                _s('Mesh Debug', 'メッシュデバッグ', 'Shows optional object, vertex, edge, face, normal, selection, font, and precision debug overlays for inspection.', '検査用にオブジェクト、頂点、辺、面、法線、選択状態、フォント、精度のデバッグオーバーレイを表示します。'),
            ),
        },
        'smart_measure_items': {
            'title': _p('Smart Measure Items', 'スマート メジャー項目'),
            'icon': 'INFO',
            'overview': _p(
                'Lists existing Smart Measure elements and exposes per-item visibility, text, color, font, positioning, arrow, axis, orthogonal, arc, and deletion controls.',
                '作成済みスマート メジャー要素を一覧表示し、項目ごとの表示、テキスト、色、フォント、位置、矢印、軸、直交、円弧、削除を編集します。',
            ),
            'usage': _p(
                'Expand an item when you need advanced controls. Keep only the required item states visible to prevent the measurement list from becoming visually noisy on dense scenes.',
                '詳細制御が必要な項目だけ展開します。高密度シーンで計測一覧が見づらくならないよう、必要な項目状態だけを表示してください。',
            ),
            'settings': (
                _s('Visibility', '表示', 'Shows or hides the selected measurement item without deleting it.', '選択した計測項目を削除せずに表示・非表示します。'),
                _s('Advanced', '詳細', 'Expands item-specific controls such as font, distance offset, arrows, local axes, and arc options.', 'フォント、距離オフセット、矢印、ローカル軸、円弧オプションなどの項目別制御を展開します。'),
                _s('Color / Area Color', '色 / 面積色', 'Controls item line color and, for area measurements, the filled area color.', '項目の線色、および面積計測では塗りつぶし面の色を制御します。'),
                _s('Text', 'テキスト', 'Edits the label or annotation text stored on the item.', '項目に保存されたラベルまたは注釈テキストを編集します。'),
                _s('Delete', '削除', 'Deletes the selected Smart Measure item.', '選択したスマート メジャー項目を削除します。'),
                _s('Font / Rotate / Align', 'フォント / 回転 / 揃え', 'Controls the per-item font size, rotation, and text alignment where supported.', '対応する項目の文字サイズ、回転、文字揃えを制御します。'),
                _s('Distance / Line / Width', '距離 / 線 / 幅', 'Controls label spacing from the measured geometry and line thickness.', '計測対象ジオメトリからラベルまでの距離と線幅を制御します。'),
                _s('Automatic Position', '自動位置', 'Lets Smart Measure calculate the display position automatically.', 'スマート メジャーに表示位置を自動計算させます。'),
                _s('Axis X / Y / Z', '軸 X / Y / Z', 'Restricts or displays the local axis components used by the item.', '項目で使うローカル軸成分を制限または表示します。'),
                _s('Orthogonal / Warning', '直交 / 警告', 'Configures orthogonal segment behavior and warns when axis/location settings can make the display ambiguous.', '直交セグメント挙動を設定し、軸や位置設定により表示が曖昧になり得る場合に警告します。'),
                _s('Arc Radius / Length / Angle / Full Circle', '円弧の半径 / 長さ / 角度 / 完全な円', 'Controls which arc values are displayed and whether the arc is treated as a full circle.', '円弧で表示する値と、完全な円として扱うかを制御します。'),
                _s('Arrows / Arrow Size', '矢印 / 矢印サイズ', 'Controls start/end arrow style and size.', '始点・終点の矢印スタイルとサイズを制御します。'),
                _s('Delete all', '全て削除', 'Removes all compatible items from the current Smart Measure list or sum group.', '現在のスマート メジャー一覧または合計グループ内の対応項目をまとめて削除します。'),
            ),
        },
        'smart_measure_configuration': {
            'title': _p('Smart Measure Configuration', 'スマート メジャー設定'),
            'icon': 'PREFERENCES',
            'overview': _p(
                'Defines default text, color, spacing, arrows, font size, alignment, and rotation used when creating or displaying Smart Measure elements.',
                'スマート メジャー要素の作成・表示に使う既定テキスト、色、間隔、矢印、文字サイズ、揃え、回転を設定します。',
            ),
            'usage': _p(
                'Set these defaults before creating many measurements so new items share a consistent style. Use per-item overrides later only for exceptions.',
                '多数の計測を作成する前にここで既定値を設定すると、新規項目の見た目を統一できます。例外だけ項目ごとの上書きを使います。',
            ),
            'settings': (
                _s('Default Color', '既定色', 'Default color assigned to new Smart Measure items.', '新規スマート メジャー項目へ割り当てる既定色です。'),
                _s('Default Text', '既定テキスト', 'Default text inserted into new text-based measurements.', '新規テキスト系計測へ入れる既定テキストです。'),
                _s('Hint Space', 'ヒント間隔', 'Spacing used around generated hint labels.', '生成されるヒントラベル周辺の間隔です。'),
                _s('Font Align', '文字揃え', 'Default text alignment for Smart Measure labels.', 'スマート メジャーラベルの既定文字揃えです。'),
                _s('Arrow A / Arrow B', '矢印A / 矢印B', 'Default arrow style for the first and second end of new measurements.', '新規計測の始点・終点に使う既定矢印スタイルです。'),
                _s('Arrow Size', '矢印サイズ', 'Default arrow size when arrows are enabled.', '矢印が有効な場合の既定矢印サイズです。'),
                _s('Font Size', 'フォントサイズ', 'Default text size for new Smart Measure labels.', '新規スマート メジャーラベルの既定文字サイズです。'),
                _s('Rotate', '回転', 'Default text rotation when the chosen alignment mode supports rotation.', '選択した揃えモードが回転に対応する場合の既定文字回転です。'),
            ),
        },
        'smart_measure_render': {
            'title': _p('Smart Measure Render', 'スマート メジャーレンダー'),
            'icon': 'SCRIPT',
            'overview': _p(
                'Controls how Smart Measure annotations are drawn into a render or saved as an annotated render image.',
                'スマート メジャー注釈をレンダーへ含める方法、または注釈付きレンダー画像として保存する方法を制御します。',
            ),
            'usage': _p(
                'Choose the Type, press the render button when you need output, and enable Frame only when the final image needs a visible border or margin. When Blender render filepath is empty, Smart Measure images are saved in the Smart Overlay storage folder.',
                '「タイプ」を選び、出力が必要な時にレンダー実行ボタンを使います。最終画像に枠や余白が必要な場合だけ「フレーム」を有効化してください。Blenderのレンダーファイルパスが空の場合、スマート メジャーの画像はSmart Overlayの保存フォルダーへ保存します。',
            ),
            'settings': (
                _s('Type', 'タイプ', 'Chooses the Smart Measure render output method.', 'スマート メジャーのレンダー出力方式を選択します。'),
                _s('Render', 'レンダー', 'Runs the Smart Measure render output.', 'スマート メジャーのレンダー出力を実行します。'),
                _s('Save Render Image', 'レンダー画像を保存', 'Saves the rendered result with Smart Measure annotations. If no manual render filepath is set, the image is written to the Smart Overlay storage folder.', 'スマート メジャー注釈を含むレンダー結果を保存します。手動のレンダーファイルパスが未設定の場合、画像はSmart Overlayの保存フォルダーへ書き込まれます。'),
                _s('Frame', 'フレーム', 'Enables an optional frame around the render output.', 'レンダー出力の周囲に任意のフレームを追加します。'),
                _s('Frame Color', 'フレーム色', 'Color of the optional render frame.', '任意フレームの色です。'),
                _s('Space', '余白', 'Spacing between the render content and frame.', 'レンダー内容とフレームの間隔です。'),
                _s('Width', '幅', 'Line width of the optional frame.', '任意フレームの線幅です。'),
            ),
        },
        'silhouette': {
            'title': _p('Silhouette Mode', 'シルエットモード'),
            'icon': 'SHADING_SOLID',
            'overview': _p('Switches the 3D View to a high-contrast silhouette preview for shape checking.', '形状確認用に3Dビューを高コントラストのシルエット表示へ切り替えます。'),
            'usage': _p('Choose whether the mode affects only the current selection or all visible objects in this Smart Overlay section, then enable or disable it from Always-on Toggle. The standalone Silhouette Mode N-panel is not registered.', 'このSmart Overlay内セクションで現在の選択だけに適用するか全表示オブジェクトに適用するかを選び、「常時機能切り替え」で有効・無効を切り替えます。シルエットモード単独のNパネルは登録されません。'),
            'settings': (
                _s('Silhouette Mode', 'シルエットモード', 'Turns the silhouette viewport state on or off and restores the previous state when disabled.', 'シルエット用ビューポート状態をON/OFFし、無効時は以前の状態を復元します。'),
                _s('All Objects', '全オブジェクト', 'Applies silhouette mode to every visible object instead of only the current selection.', '現在の選択だけでなく、表示中の全オブジェクトへシルエット表示を適用します。'),
            ),
        },
        'scene_overrides': {
            'title': _p('Scene Overrides', 'シーン上書き'),
            'icon': 'FILE_BLEND',
            'overview': _p('Allows the current .blend scene to store and restore Smart Overlay-specific settings.', '現在の.blendシーンにSmart Overlay専用設定を保存・復元できるようにします。'),
            'usage': _p('Enable scene overrides only when a file needs its own overlay configuration. Save current settings to the scene, load them back, or clear them.', 'ファイルごとに独自のオーバーレイ設定が必要な場合のみ有効化します。現在設定をシーンへ保存し、読み戻し、またはクリアできます。'),
            'settings': (
                _s('Use Scene Overrides', 'シーン上書きを使用', 'Enables the per-.blend override layer.', '.blendごとの上書き設定レイヤーを有効化します。'),
                _s('Scene Overrides Enabled', 'シーン上書き 有効', 'Turns the stored scene override on or off for the current file.', '現在ファイルに保存されたシーン上書きをON/OFFします。'),
                _s('Save Current to Scene', '現在設定をシーンに保存', 'Writes the current settings into the scene override storage.', '現在の設定をシーン上書き保存領域へ書き込みます。'),
                _s('Load From Scene', 'シーンから読み込み', 'Loads stored scene override values into the add-on settings.', '保存されたシーン上書き値をアドオン設定へ読み込みます。'),
                _s('Clear Scene Overrides', 'シーン上書きをクリア', 'Removes stored scene override values.', '保存されたシーン上書き値を削除します。'),
            ),
        },
    }
    return _TOPIC_CACHE
