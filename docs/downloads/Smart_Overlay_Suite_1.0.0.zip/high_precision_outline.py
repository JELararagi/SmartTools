# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Topology-based high-precision viewport outline for Solid shading."""

from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass, field
import hashlib
import json
import math
import threading
import time

import bpy

from . import events
from bpy.app.handlers import persistent
import gpu
import numpy as np
from gpu_extras.batch import batch_for_shader
from mathutils import Matrix, Vector
from mathutils.bvhtree import BVHTree

_SUPPORTED_TYPES = frozenset({'MESH', 'CURVE', 'SURFACE', 'FONT', 'META'})
_MAX_GEOMETRY_CACHE = 256
_MAX_REGION_CACHE = 12
_MAX_FRONT_STATE_CACHE = 2048
_MAX_INSTANCE_INTERSECTION_CACHE = 256
_MAX_INTERSECTION_CACHE = 512
_MAX_INSTANCE_SNAPSHOT_CACHE = 16
_MAX_SCENE_INTERSECTION_CACHE = 64
_INTERSECTION_VECTOR_CHUNK = 65536
_PERSISTED_NATIVE_STATE_PROP = 'high_precision_outline_native_state_json'

_DRAW_HANDLE = None
_SHADER = None
_RUNTIME_REGISTERED = False
_SCENE_REVISION = 1
_INSTANCE_REVISION = 1
_GEOMETRY_GENERATION = 1
_GEOMETRY_BUILD_DEPTH = 0
_GEOMETRY_CACHE = OrderedDict()
_REGION_CACHE = OrderedDict()
_REGION_SLOT_CACHE = OrderedDict()
_INSTANCE_INTERSECTION_CACHE = OrderedDict()
_INTERSECTION_CACHE = OrderedDict()
_INSTANCE_SNAPSHOT_CACHE = OrderedDict()
_SCENE_INTERSECTION_CACHE = OrderedDict()
_INSTANCE_INTERSECTION_LATEST = {}
_DIRTY_OBJECTS = set()
_DIRTY_DATA = set()
_FRONT_STATE_CACHE = OrderedDict()
_STANDARD_OUTLINE_SNAPSHOT = {}
_LAST_STATS = {}
_LAST_ERROR = ''
_SNAPSHOT_REBUILD_PENDING = False
_SNAPSHOT_REBUILD_SERIAL = 0
_SNAPSHOT_REBUILD_ATTEMPTS = 0
_SNAPSHOT_REBUILD_DUE = 0.0
_SNAPSHOT_REBUILD_MAX_ATTEMPTS = 4
# View-dependent silhouette classification must follow viewport navigation.
# Cached geometry/intersection data keeps this bounded; 30 Hz removes the old
# 100 ms visual step without changing outline thickness or color.
_SNAPSHOT_REBUILD_MIN_INTERVAL = 1.0 / 30.0
_LAST_SNAPSHOT_BUILD = 0.0
_SNAPSHOT_FENCE_GENERATION = 1
_SNAPSHOT_REBUILD_FENCE = 0
_SNAPSHOT_SKIP_DIAGNOSTICS = set()
# Draw-originated invalidations own only their requesting View3D slots.  Scene,
# data, transform, mode, and lifecycle invalidations remain all-region work.
_DRAW_STALE_REGION_SLOTS = set()
_SNAPSHOT_REBUILD_ALL_REGIONS = False
_ACTIVE_VIEW_PRIME_PENDING = False
_ACTIVE_VIEW_PRIME_ATTEMPTS = 0
_ACTIVE_VIEW_PRIME_MAX_ATTEMPTS = 4
_EDIT_UPDATE_GUARD_ACTIVE = False
_EDIT_UPDATE_GUARD_GENERATION = 0
_EDIT_UPDATE_GUARD_RELEASE_PENDING_GENERATION = 0
# Timeline changes rebuild inline only while the rebuild fits in this share of a
# playback frame.  Costlier scenes fall back to the standard Outline until the
# timeline settles, so the outline never slows playback.
_FRAME_REBUILD_FRAME_SHARE = 1.0 / 3.0
_FRAME_STEP_REBUILD_BUDGET = 0.1
_FRAME_SETTLE_SECONDS = 0.2
_FRAME_REBUILD_DEFERRED = False
_FRAME_SETTLE_DUE = 0.0
_CONTENT_STALE_LIMIT = 0.2
_CONTENT_STALE_SINCE = 0.0
_CONTENT_REBUILD_COSTS = []
_INSTANCE_REBUILD_COSTS = []
_LAST_BUILT_REVISIONS = None


@dataclass
class GeometryCache:
    owner_ptr: int
    data_ptr: int
    vertices: np.ndarray
    edges: np.ndarray
    face_normals: np.ndarray
    face_centers: np.ndarray
    face_a: np.ndarray
    face_b: np.ndarray
    boundary_mask: np.ndarray
    loose_mask: np.ndarray
    nonmanifold_faces: dict[int, tuple[int, ...]] = field(default_factory=dict)
    # Lazily materialized immutable CSR view of nonmanifold_faces.  It belongs
    # to this geometry generation and is released with the GeometryCache.
    nonmanifold_edge_ids: object = None
    nonmanifold_face_flat: object = None
    nonmanifold_offsets: object = None
    nonmanifold_counts: object = None
    nonmanifold_empty_ids: object = None
    topology_signature: bytes = b''
    bbox_diag: float = 1.0
    build_seconds: float = 0.0
    bbox_min: np.ndarray = field(default_factory=lambda: np.zeros(3, dtype=np.float32))
    bbox_max: np.ndarray = field(default_factory=lambda: np.zeros(3, dtype=np.float32))
    generation: int = 0
    # Triangulation is generated lazily only for AABB-overlapping instances.
    # Ordinary silhouette-only objects never pay calc_loop_triangles/foreach_get.
    triangles: np.ndarray | None = None
    triangle_build_seconds: float = 0.0
    source_mesh: object = None


@dataclass
class RegionCache:
    key: object = None
    slot_key: object = None
    batch: object = None
    edge_count: int = 0
    object_count: int = 0
    build_seconds: float = 0.0
    intersection_count: int = 0
    intersection_pair_count: int = 0
    intersection_candidate_count: int = 0
    intersection_build_seconds: float = 0.0


@dataclass
class InstanceIntersectionGeometry:
    key: object
    world_vertices: np.ndarray
    triangles: np.ndarray
    bvh: object
    bbox_min: np.ndarray
    bbox_max: np.ndarray
    bbox_diag: float
    build_seconds: float = 0.0


@dataclass
class InstanceSnapshot:
    key: object
    instances: tuple
    signature: tuple
    build_seconds: float = 0.0


@dataclass
class SceneIntersectionCache:
    key: object = None
    points: np.ndarray = field(default_factory=lambda: np.zeros((0, 3), dtype=np.float32))
    segment_count: int = 0
    pair_count: int = 0
    candidate_pair_count: int = 0
    max_scale: float = 1.0
    build_seconds: float = 0.0


@dataclass
class IntersectionRecord:
    """Cheap per-instance broad-phase data.

    World-space vertices and BVHs are intentionally not created here.  They are
    built lazily only after the sweep-and-prune pass confirms that an instance
    can actually intersect another visible evaluated object.  This keeps the
    high-precision outline inexpensive in scenes containing many separated
    objects.
    """

    geometry: GeometryCache
    matrix_world: Matrix
    instance_key: object
    bbox_min: np.ndarray
    bbox_max: np.ndarray
    bbox_diag: float


@dataclass
class IntersectionCache:
    key: object = None
    segments: np.ndarray = field(default_factory=lambda: np.zeros((0, 2, 3), dtype=np.float32))
    segment_count: int = 0
    pair_count: int = 0
    candidate_pair_count: int = 0
    build_seconds: float = 0.0


def _prefs(context=None):
    try:
        from . import registry
        return registry.resolve_addon_preferences(context or bpy.context)
    except Exception:
        return None


def _enabled(context=None):
    p = _prefs(context)
    try:
        return bool(getattr(p, 'high_precision_outline_enabled', False))
    except Exception:
        return False


def _color(context=None, prefs=None):
    owner = prefs if prefs is not None else _prefs(context)
    try:
        rgb = tuple(float(v) for v in getattr(owner, 'high_precision_outline_color', (0.0, 0.0, 0.0))[:3])
    except Exception:
        rgb = (0.0, 0.0, 0.0)
    return tuple(max(0.0, min(1.0, v)) for v in rgb) + (1.0,)


def _tag_redraw(context=None):
    """Use the Mesh/Curve redraw authority so optimization scope stays identical."""
    try:
        from . import mesh as _sos_mesh
        _sos_mesh.tag_view3d_redraw(context or bpy.context)
        return
    except Exception:
        pass


def _reset_active_view_prime_state():
    global _ACTIVE_VIEW_PRIME_PENDING, _ACTIVE_VIEW_PRIME_ATTEMPTS
    _ACTIVE_VIEW_PRIME_PENDING = False
    _ACTIVE_VIEW_PRIME_ATTEMPTS = 0


def _active_view_prime_timer():
    """Recover an active View3D owner outside draw callbacks.

    High-Precision Outline can run while the heavier Mesh/Curve hover runtime is
    disabled.  In that configuration there may be no modal mouse tracker to seed
    Draw Active View Only after a window/layout change.  Use the current UI
    context from a bounded event-side timer instead of making a draw callback
    claim ownership.
    """
    global _ACTIVE_VIEW_PRIME_ATTEMPTS
    if not _RUNTIME_REGISTERED or not _enabled():
        _reset_active_view_prime_state()
        return None
    _ACTIVE_VIEW_PRIME_ATTEMPTS += 1
    primed = False
    try:
        from . import mesh as _sos_mesh
        primed = bool(_sos_mesh.prime_active_view_draw_context(
            getattr(bpy, 'context', None), force=True,
            source='high_precision_outline_runtime',
        ))
    except Exception:
        primed = False
    if primed:
        _reset_active_view_prime_state()
        _tag_redraw(getattr(bpy, 'context', None))
        return None
    if _ACTIVE_VIEW_PRIME_ATTEMPTS < _ACTIVE_VIEW_PRIME_MAX_ATTEMPTS:
        return 0.10
    _reset_active_view_prime_state()
    return None


def _schedule_active_view_prime() -> bool:
    global _ACTIVE_VIEW_PRIME_PENDING, _ACTIVE_VIEW_PRIME_ATTEMPTS
    if _ACTIVE_VIEW_PRIME_PENDING:
        return True
    _ACTIVE_VIEW_PRIME_PENDING = True
    _ACTIVE_VIEW_PRIME_ATTEMPTS = 0
    try:
        if not bpy.app.timers.is_registered(_active_view_prime_timer):
            bpy.app.timers.register(_active_view_prime_timer, first_interval=0.01)
        return True
    except Exception:
        _reset_active_view_prime_state()
        return False


def _cancel_active_view_prime():
    try:
        if bpy.app.timers.is_registered(_active_view_prime_timer):
            bpy.app.timers.unregister(_active_view_prime_timer)
    except Exception:
        pass
    _reset_active_view_prime_state()
    try:
        ctx = bpy.context
        wm = getattr(ctx, 'window_manager', None)
        for win in getattr(wm, 'windows', ()) or ():
            for area in getattr(getattr(win, 'screen', None), 'areas', ()) or ():
                if getattr(area, 'type', None) == 'VIEW_3D':
                    area.tag_redraw()
    except Exception:
        pass



def _iter_spaces(context=None):
    ctx = context or bpy.context
    wm = getattr(ctx, 'window_manager', None)
    for win in getattr(wm, 'windows', ()) or ():
        screen = getattr(win, 'screen', None)
        for area_index, area in enumerate(getattr(screen, 'areas', ()) or ()):
            if getattr(area, 'type', None) != 'VIEW_3D':
                continue
            space = getattr(getattr(area, 'spaces', None), 'active', None)
            if space is not None and getattr(space, 'type', None) == 'VIEW_3D':
                yield win, area, space, _space_identity(win, area_index)


def _space_identity(window, area_index):
    try:
        screen = getattr(window, 'screen', None)
        screen_name = str(getattr(screen, 'name_full', None) or getattr(screen, 'name', '') or '')
        workspace = getattr(window, 'workspace', None)
        workspace_name = str(getattr(workspace, 'name_full', None) or getattr(workspace, 'name', '') or '')
        return json.dumps((workspace_name, screen_name, int(area_index)), ensure_ascii=False, separators=(',', ':'))
    except Exception:
        return str(int(area_index))


def _decode_native_state(prefs=None):
    owner = prefs or _prefs()
    try:
        raw = str(getattr(owner, _PERSISTED_NATIVE_STATE_PROP, '') or '')
        data = json.loads(raw) if raw else {}
    except Exception:
        data = {}
    if not isinstance(data, dict):
        data = {}
    spaces = data.get('spaces')
    if not isinstance(spaces, dict):
        spaces = {}
    clean = {str(key): bool(value) for key, value in spaces.items()}
    default = data.get('default', None)
    if default is not None:
        default = bool(default)
    return {'version': 1, 'default': default, 'spaces': clean}


def _encode_native_state(data, prefs=None):
    owner = prefs or _prefs()
    if owner is None:
        return False
    try:
        text = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(',', ':')) if data else ''
        if str(getattr(owner, _PERSISTED_NATIVE_STATE_PROP, '') or '') != text:
            setattr(owner, _PERSISTED_NATIVE_STATE_PROP, text)
        return True
    except Exception:
        return False


def prepare_enable(context=None, prefs=None):
    """Persist each viewport's native Outline value before replacement starts."""
    state = {'version': 1, 'default': None, 'spaces': {}}
    for _win, _area, space, identity in _iter_spaces(context):
        try:
            value = bool(space.shading.show_object_outline)
        except Exception:
            continue
        if state['default'] is None:
            state['default'] = value
        state['spaces'][identity] = value
    if state['default'] is None:
        state['default'] = True
    _encode_native_state(state, prefs)
    return state


def _ptr(value):
    try:
        return int(value.as_pointer())
    except Exception:
        return id(value)


def _valid_rna_ptr(value):
    if value is None:
        return None
    try:
        pointer = int(value.as_pointer())
    except (ReferenceError, AttributeError):
        return None
    except Exception:
        return None
    return pointer if pointer > 0 else None


def _valid_original(obj):
    if _valid_rna_ptr(obj) is None:
        return None
    try:
        original = getattr(obj, 'original', None)
    except (ReferenceError, AttributeError):
        return None
    except Exception:
        original = None
    if original is None:
        return obj
    return original if _valid_rna_ptr(original) is not None else None


def _record_snapshot_skip_once(reason):
    key = str(reason or 'invalid_snapshot_reference')
    if key in _SNAPSHOT_SKIP_DIAGNOSTICS:
        return
    if len(_SNAPSHOT_SKIP_DIAGNOSTICS) >= 16:
        _SNAPSHOT_SKIP_DIAGNOSTICS.pop()
    _SNAPSHOT_SKIP_DIAGNOSTICS.add(key)


def _space_is_solid(space):
    try:
        return str(space.shading.type) == 'SOLID'
    except Exception:
        return False


def _restore_space(space, identity, state=None):
    try:
        key = _ptr(space)
        payload = _STANDARD_OUTLINE_SNAPSHOT.pop(key, None)
        data = state if state is not None else _decode_native_state()
        default = data.get('default', None)
        intended = data.get('spaces', {}).get(identity, default)
        if intended is None and payload is not None:
            intended = payload[1]
        if intended is not None:
            intended = bool(intended)
            if bool(space.shading.show_object_outline) != intended:
                space.shading.show_object_outline = intended
        return True
    except Exception:
        return False


def _suppress_space(space, identity, state):
    try:
        key = _ptr(space)
        current = bool(space.shading.show_object_outline)
        default = state.get('default', None)
        intended = state['spaces'].get(identity, default if default is not None else current)
        intended = bool(intended)
        if key not in _STANDARD_OUTLINE_SNAPSHOT:
            _STANDARD_OUTLINE_SNAPSHOT[key] = (identity, intended)
        changed = False
        if identity not in state['spaces']:
            state['spaces'][identity] = intended
            changed = True
        if state.get('default', None) is None:
            state['default'] = intended
            changed = True
        if current:
            space.shading.show_object_outline = False
        return changed
    except Exception:
        return False


def _context_space_identity(context):
    try:
        window = context.window
        screen = getattr(window, 'screen', None)
        area = context.area
        for area_index, candidate in enumerate(getattr(screen, 'areas', ()) or ()):
            if candidate == area:
                return _space_identity(window, area_index)
    except Exception:
        pass
    return ''



def _context_region_slot_key(context):
    """Return an RNA-free Window/Area/WINDOW-Region layout slot key."""
    try:
        wm = getattr(context, 'window_manager', None) or bpy.context.window_manager
        window = context.window
        area = context.area
        region = context.region
        window_index = next(i for i, candidate in enumerate(getattr(wm, 'windows', ()) or ()) if candidate == window)
        screen = getattr(window, 'screen', None)
        area_index = next(i for i, candidate in enumerate(getattr(screen, 'areas', ()) or ()) if candidate == area)
        window_regions = tuple(
            candidate for candidate in (getattr(area, 'regions', ()) or ())
            if getattr(candidate, 'type', None) == 'WINDOW'
        )
        region_index = next(i for i, candidate in enumerate(window_regions) if candidate == region)
        return int(window_index), int(area_index), int(region_index)
    except Exception:
        return None

def _suppress_native(context=None):
    state = _decode_native_state()
    changed = False
    for _win, _area, space, identity in _iter_spaces(context):
        if _space_is_solid(space):
            changed = _suppress_space(space, identity, state) or changed
        else:
            _restore_space(space, identity, state)
    if changed:
        _encode_native_state(state)


def _restore_native(context=None, *, clear_persisted=False):
    runtime_values = {
        str(identity): bool(value)
        for identity, value in tuple(_STANDARD_OUTLINE_SNAPSHOT.values())
    }

    # A restart may recreate SpaceView3D RNA objects before runtime snapshots
    # exist. Restore those viewports from the persistent identity map as well.
    state = _decode_native_state()
    default = state.get('default', None)
    for _win, _area, space, identity in _iter_spaces(context):
        try:
            value = state['spaces'].get(identity, default)
            if value is None:
                value = runtime_values.get(identity)
            if value is not None:
                space.shading.show_object_outline = bool(value)
        except Exception:
            pass
    _STANDARD_OUTLINE_SNAPSHOT.clear()
    if clear_persisted:
        _encode_native_state({})


def _shader():
    global _SHADER
    if _SHADER is None:
        try:
            _SHADER = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
        except Exception:
            _SHADER = None
    return _SHADER


def _matrix_sig(matrix, digits=7):
    try:
        return tuple(round(float(matrix[r][c]), digits) for r in range(4) for c in range(4))
    except Exception:
        return ()


def _exact_matrix_sig(matrix):
    """Return an unquantized matrix signature for pixel-exact GPU reuse."""
    try:
        return tuple(float(matrix[r][c]) for r in range(4) for c in range(4))
    except Exception:
        return ()


def _view_sig(region, rv3d):
    return (
        int(getattr(region, 'width', 0)), int(getattr(region, 'height', 0)),
        bool(getattr(rv3d, 'is_perspective', False)),
        _matrix_sig(getattr(rv3d, 'view_matrix', Matrix.Identity(4))),
        _matrix_sig(getattr(rv3d, 'window_matrix', Matrix.Identity(4))),
    )


def _exact_view_sig(region, rv3d):
    """Key only byte-for-byte equivalent projected silhouettes as reusable."""
    return (
        int(getattr(region, 'width', 0)), int(getattr(region, 'height', 0)),
        bool(getattr(rv3d, 'is_perspective', False)),
        _exact_matrix_sig(getattr(rv3d, 'view_matrix', Matrix.Identity(4))),
        _exact_matrix_sig(getattr(rv3d, 'window_matrix', Matrix.Identity(4))),
    )


def _owner_ptr(obj):
    original = _valid_original(obj)
    if original is None:
        _record_snapshot_skip_once('invalid_owner_reference')
        return None
    pointer = _valid_rna_ptr(original)
    if pointer is None:
        _record_snapshot_skip_once('invalid_owner_reference')
    return pointer


def _data_ptr(obj):
    original = _valid_original(obj)
    if original is None:
        return 0
    try:
        data = getattr(original, 'data', None)
    except (ReferenceError, AttributeError):
        return 0
    except Exception:
        return 0
    return int(_valid_rna_ptr(data) or 0)


def _geometry_cache_key(obj):
    """Share immutable base-mesh topology between linked duplicate objects."""
    original = _valid_original(obj)
    if original is None:
        return None
    try:
        data = getattr(original, 'data', None)
        if (str(getattr(original, 'type', '')) == 'MESH' and data is not None
                and len(getattr(original, 'modifiers', ()) or ()) == 0):
            data_ptr = _valid_rna_ptr(data)
            if data_ptr is not None:
                return ('MESH_DATA', data_ptr)
    except (ReferenceError, AttributeError):
        return None
    except Exception:
        pass
    owner = _owner_ptr(obj)
    return ('OBJECT', owner) if owner is not None else None


def _visible(obj, space):
    if obj is None or str(getattr(obj, 'type', '')) not in _SUPPORTED_TYPES:
        return False
    try:
        if bool(getattr(obj, 'hide_viewport', False)) or bool(obj.hide_get()):
            return False
    except Exception:
        pass
    try:
        if hasattr(obj, 'visible_in_viewport_get') and not obj.visible_in_viewport_get(space):
            return False
    except Exception:
        pass
    try:
        if getattr(space, 'local_view', None) is not None and hasattr(obj, 'local_view_get') and not obj.local_view_get(space):
            return False
    except Exception:
        pass
    try:
        if str(getattr(obj, 'display_type', 'TEXTURED')) in {'WIRE', 'BOUNDS'}:
            return False
    except Exception:
        pass
    return True


def _object_reference(obj):
    original = _valid_original(obj)
    if original is None:
        return None
    try:
        name = str(getattr(original, 'name_full', None) or getattr(original, 'name', '') or '')
        session_uid = int(getattr(original, 'session_uid', 0) or 0)
    except (ReferenceError, AttributeError):
        return None
    except Exception:
        return None
    if not name and session_uid <= 0:
        return None
    return (name, session_uid)


def _object_reference_matches(obj, reference):
    original = _valid_original(obj)
    if original is None:
        return False
    name, session_uid = reference
    try:
        candidate_name = str(getattr(original, 'name_full', None) or getattr(original, 'name', '') or '')
        candidate_uid = int(getattr(original, 'session_uid', 0) or 0)
    except (ReferenceError, AttributeError):
        return False
    except Exception:
        return False
    if session_uid > 0 and candidate_uid > 0:
        return candidate_uid == session_uid
    return bool(name) and candidate_name == name


def _resolve_object_reference(reference, context=None):
    name, session_uid = reference
    candidate = None
    try:
        candidate = bpy.data.objects.get(name) if name else None
    except Exception:
        candidate = None
    if candidate is not None and _object_reference_matches(candidate, reference):
        return candidate

    scene = getattr(context, 'scene', None) if context is not None else None
    try:
        for obj in getattr(scene, 'objects', ()) or ():
            if _object_reference_matches(obj, reference):
                return obj
    except Exception:
        pass

    if session_uid > 0:
        try:
            for obj in getattr(bpy.data, 'objects', ()) or ():
                if _object_reference_matches(obj, reference):
                    return obj
        except Exception:
            pass
    return None


def _resolve_instance_references(context, depsgraph, space, references):
    result = []
    seen = set()
    for reference, matrix_world, persistent_id in references:
        source = _resolve_object_reference(reference, context)
        if source is None:
            _record_snapshot_skip_once('unresolved_object_reference')
            continue
        try:
            eval_obj = source.evaluated_get(depsgraph)
        except (ReferenceError, AttributeError):
            _record_snapshot_skip_once('invalid_evaluated_object')
            continue
        except Exception:
            continue
        if not _visible(eval_obj, space):
            continue
        owner = _owner_ptr(eval_obj)
        if owner is None:
            continue
        try:
            mw = matrix_world.copy()
        except Exception:
            mw = Matrix(matrix_world)
        key = (owner, tuple(persistent_id), _matrix_sig(mw, 6))
        if key in seen:
            continue
        seen.add(key)
        result.append((eval_obj, mw, key))
    return result


def _collect_instances(context, depsgraph, space):
    result = []
    seen = set()
    try:
        iterable = depsgraph.object_instances
    except Exception:
        iterable = ()
    for inst in iterable:
        try:
            if not bool(getattr(inst, 'show_self', True)):
                continue
            obj = inst.object
            if not _visible(obj, space):
                continue
            reference = _object_reference(obj)
            if reference is None:
                continue
            mw = inst.matrix_world.copy()
            pid = tuple(int(v) for v in (getattr(inst, 'persistent_id', ()) or ()))
            key = (reference, pid, _matrix_sig(mw, 6))
            if key in seen:
                continue
            seen.add(key)
            result.append((reference, mw, pid))
        except Exception:
            continue
    if result:
        return result
    try:
        for obj in context.visible_objects:
            if not _visible(obj, space):
                continue
            reference = _object_reference(obj)
            if reference is None:
                continue
            mw = obj.matrix_world.copy()
            key = (reference, (), _matrix_sig(mw, 6))
            if key not in seen:
                seen.add(key); result.append((reference, mw, ()))
    except Exception:
        pass
    return result


def _instance_snapshot_key(context, depsgraph, space):
    """Key a visible-instance snapshot without inspecting every object per redraw.

    Blender's depsgraph handler increments _INSTANCE_REVISION for object,
    collection, visibility and transform changes.  View orbit/pan/zoom does not
    alter this key, so the expensive object_instances walk is shared by all
    redraws and all high-precision outline cache checks in the same viewport.
    """
    local_view = getattr(space, 'local_view', None)
    return (
        int(_INSTANCE_REVISION),
        _ptr(getattr(context, 'scene', None)),
        _ptr(getattr(context, 'view_layer', None)),
        _ptr(space),
        _ptr(local_view) if local_view is not None else 0,
        _ptr(depsgraph),
    )


def _collect_instances_cached(context, depsgraph, space):
    key = _instance_snapshot_key(context, depsgraph, space)
    cached = _INSTANCE_SNAPSHOT_CACHE.get(key)
    if cached is not None:
        _INSTANCE_SNAPSHOT_CACHE.move_to_end(key)
        return cached.instances, cached.signature, cached.build_seconds
    start = time.perf_counter()
    instances = tuple(_collect_instances(context, depsgraph, space))
    signature = tuple((item[0], tuple(item[2]), _matrix_sig(item[1], 6)) for item in instances)
    cached = InstanceSnapshot(
        key=key,
        instances=instances,
        signature=signature,
        build_seconds=time.perf_counter() - start,
    )
    _INSTANCE_SNAPSHOT_CACHE[key] = cached
    _INSTANCE_SNAPSHOT_CACHE.move_to_end(key)
    while len(_INSTANCE_SNAPSHOT_CACHE) > _MAX_INSTANCE_SNAPSHOT_CACHE:
        _INSTANCE_SNAPSHOT_CACHE.popitem(last=False)
    return cached.instances, cached.signature, cached.build_seconds


def _foreach(collection, prop, shape, dtype):
    arr = np.empty(int(math.prod(shape)), dtype=dtype)
    collection.foreach_get(prop, arr)
    return arr.reshape(shape)


def _next_geometry_generation():
    global _GEOMETRY_GENERATION
    _GEOMETRY_GENERATION += 1
    return int(_GEOMETRY_GENERATION)


def _mesh_for(eval_obj, depsgraph):
    """Return geometry that remains valid in both Object and Edit modes.

    Blender 5.1 can expose an evaluated edit-mode Mesh datablock whose
    ``vertices``/``edges``/``polygons`` collections are empty, even though
    ``Object.to_mesh()`` correctly returns the live edit geometry (and the
    modifier result when one is enabled in Edit Mode).  Returning that empty
    placeholder removed the edited object from silhouette and intersection
    calculations.  Use the zero-copy datablock whenever it contains usable
    geometry, and fall back to the evaluated temporary mesh only for the empty
    edit-mode placeholder.
    """
    if getattr(eval_obj, 'type', None) == 'MESH':
        try:
            mesh = eval_obj.data
            vertex_count = len(mesh.vertices)
            edge_count = len(mesh.edges)
            polygon_count = len(mesh.polygons)
            is_edit_mode = bool(
                getattr(mesh, 'is_editmode', False)
                or str(getattr(eval_obj, 'mode', '') or '') == 'EDIT'
            )
            # Object Mode and modifier-evaluated Edit Mode meshes normally have
            # populated collections and can be consumed without a temporary
            # allocation.  A completely empty edit-mode datablock is Blender's
            # evaluated placeholder, not an actually empty source mesh.
            if not is_edit_mode or vertex_count or edge_count or polygon_count:
                return mesh, False
        except Exception:
            pass
    try:
        return eval_obj.to_mesh(preserve_all_data_layers=False, depsgraph=depsgraph), True
    except TypeError:
        try:
            return eval_obj.to_mesh(), True
        except Exception:
            return None, False
    except Exception:
        return None, False


def _triangle_array(mesh):
    try:
        mesh.calc_loop_triangles()
        count = len(mesh.loop_triangles)
        if count:
            return _foreach(mesh.loop_triangles, 'vertices', (count, 3), np.int32)
    except Exception:
        pass
    return np.zeros((0, 3), dtype=np.int32)


def _ensure_triangles(g, eval_obj, depsgraph):
    """Build evaluated loop triangles only after broad-phase overlap succeeds."""
    if g.triangles is not None:
        return g.triangles
    start = time.perf_counter()
    mesh = getattr(g, 'source_mesh', None)
    clear = False
    try:
        if mesh is None:
            mesh, clear = _mesh_for(eval_obj, depsgraph)
        triangles = _triangle_array(mesh) if mesh is not None else np.zeros((0, 3), dtype=np.int32)
        g.triangles = triangles
        g.triangle_build_seconds = time.perf_counter() - start
        return triangles
    except Exception:
        g.triangles = np.zeros((0, 3), dtype=np.int32)
        g.triangle_build_seconds = time.perf_counter() - start
        return g.triangles
    finally:
        if clear:
            try:
                eval_obj.to_mesh_clear()
            except Exception:
                pass


def _topology_signature(edges, loop_edges, totals):
    digest = hashlib.blake2b(digest_size=16)
    for array in (edges, loop_edges, totals):
        contiguous = np.ascontiguousarray(array)
        digest.update(np.asarray(contiguous.shape, dtype=np.int64).tobytes())
        digest.update(memoryview(contiguous).cast('B'))
    return digest.digest()


def _face_geometry_arrays(mesh, face_count):
    if face_count:
        normals = _foreach(mesh.polygons, 'normal', (face_count, 3), np.float32)
        try:
            centers = _foreach(mesh.polygons, 'center', (face_count, 3), np.float32)
        except Exception:
            centers = np.zeros((face_count, 3), dtype=np.float32)
    else:
        normals = np.zeros((0, 3), dtype=np.float32)
        centers = np.zeros((0, 3), dtype=np.float32)
    return normals, centers


def _cache_from_arrays(
        owner, data_ptr, verts, edges, normals, centers, loop_edges, totals,
        topology_signature, start, source_mesh=None):
    face_count = len(normals)
    face_a = np.full(len(edges), -1, dtype=np.int32)
    face_b = np.full(len(edges), -1, dtype=np.int32)
    nonmanifold = {}
    if face_count and len(loop_edges):
        loop_faces = np.repeat(np.arange(face_count, dtype=np.int32), totals)
        usable = min(len(loop_edges), len(loop_faces))
        if usable:
            order = np.argsort(loop_edges[:usable], kind='stable')
            se = loop_edges[:usable][order]
            sf = loop_faces[:usable][order]
            unique, starts, counts = np.unique(se, return_index=True, return_counts=True)
            valid = (unique >= 0) & (unique < len(edges))
            unique, starts, counts = unique[valid], starts[valid], counts[valid]
            face_a[unique] = sf[starts]
            second = counts > 1
            face_b[unique[second]] = sf[starts[second] + 1]
            for ei, st, ct in zip(unique[counts > 2], starts[counts > 2], counts[counts > 2]):
                nonmanifold[int(ei)] = tuple(int(v) for v in sf[int(st):int(st + ct)])
    boundary = np.logical_xor(face_a >= 0, face_b >= 0)
    loose = np.logical_and(face_a < 0, face_b < 0)
    bbox_min = verts.min(axis=0).astype(np.float32, copy=False) if len(verts) else np.zeros(3, dtype=np.float32)
    bbox_max = verts.max(axis=0).astype(np.float32, copy=False) if len(verts) else np.zeros(3, dtype=np.float32)
    diag = float(np.linalg.norm(bbox_max - bbox_min)) if len(verts) else 1.0
    if not math.isfinite(diag) or diag <= 0.0:
        diag = 1.0
    generation = _next_geometry_generation()
    return GeometryCache(
        owner_ptr=owner,
        data_ptr=data_ptr,
        vertices=verts,
        edges=edges,
        face_normals=normals,
        face_centers=centers,
        face_a=face_a,
        face_b=face_b,
        boundary_mask=boundary,
        loose_mask=loose,
        nonmanifold_faces=nonmanifold,
        topology_signature=topology_signature,
        bbox_diag=diag,
        build_seconds=time.perf_counter() - start,
        bbox_min=bbox_min,
        bbox_max=bbox_max,
        generation=generation,
        triangles=None,
        source_mesh=None,
    )


def _build_geometry(eval_obj, depsgraph):
    global _GEOMETRY_BUILD_DEPTH
    start = time.perf_counter()
    owner = _owner_ptr(eval_obj)
    if owner is None:
        return None
    data_ptr = _data_ptr(eval_obj)
    mesh = None
    clear = False
    _GEOMETRY_BUILD_DEPTH += 1
    try:
        mesh, clear = _mesh_for(eval_obj, depsgraph)
        if mesh is None or len(mesh.vertices) == 0 or len(mesh.edges) == 0:
            return None
        verts = _foreach(mesh.vertices, 'co', (len(mesh.vertices), 3), np.float32)
        edges = _foreach(mesh.edges, 'vertices', (len(mesh.edges), 2), np.int32)
        face_count = len(mesh.polygons)
        loop_edges = _foreach(mesh.loops, 'edge_index', (len(mesh.loops),), np.int32) if len(mesh.loops) else np.zeros(0, dtype=np.int32)
        totals = _foreach(mesh.polygons, 'loop_total', (face_count,), np.int32) if face_count else np.zeros(0, dtype=np.int32)
        signature = _topology_signature(edges, loop_edges, totals)
        normals, centers = _face_geometry_arrays(mesh, face_count)
        return _cache_from_arrays(
            owner, data_ptr, verts, edges, normals, centers, loop_edges, totals,
            signature, start, mesh if not clear else None,
        )
    finally:
        if clear:
            try:
                eval_obj.to_mesh_clear()
            except Exception:
                pass
        _GEOMETRY_BUILD_DEPTH = max(0, _GEOMETRY_BUILD_DEPTH - 1)


def _refresh_geometry(eval_obj, depsgraph, cached):
    """Refresh a dirty cache without rebuilding topology when geometry is unchanged.

    Edit-mode selection updates are reported by Blender as geometry updates even
    though evaluated positions and topology are identical.  A compact topology
    digest and exact coordinate comparison avoid the expensive adjacency sort in
    that case.  Deformations with unchanged topology update only coordinates,
    face normals and centers.
    """
    global _GEOMETRY_BUILD_DEPTH
    start = time.perf_counter()
    owner = _owner_ptr(eval_obj)
    if owner is None:
        return None, True
    data_ptr = _data_ptr(eval_obj)
    mesh = None
    clear = False
    _GEOMETRY_BUILD_DEPTH += 1
    try:
        mesh, clear = _mesh_for(eval_obj, depsgraph)
        if mesh is None or len(mesh.vertices) == 0 or len(mesh.edges) == 0:
            return None, True
        face_count = len(mesh.polygons)
        same_counts = (
            len(mesh.vertices) == len(cached.vertices)
            and len(mesh.edges) == len(cached.edges)
            and face_count == len(cached.face_normals)
        )
        if not same_counts:
            return _build_geometry_from_existing_mesh(
                mesh, start, owner, data_ptr, mesh if not clear else None,
            )

        verts = _foreach(mesh.vertices, 'co', (len(mesh.vertices), 3), np.float32)
        edges = _foreach(mesh.edges, 'vertices', (len(mesh.edges), 2), np.int32)
        loop_edges = _foreach(mesh.loops, 'edge_index', (len(mesh.loops),), np.int32) if len(mesh.loops) else np.zeros(0, dtype=np.int32)
        totals = _foreach(mesh.polygons, 'loop_total', (face_count,), np.int32) if face_count else np.zeros(0, dtype=np.int32)
        signature = _topology_signature(edges, loop_edges, totals)
        topology_same = signature == cached.topology_signature
        vertices_same = topology_same and np.array_equal(verts, cached.vertices)
        if vertices_same:
            cached.build_seconds = time.perf_counter() - start
            return cached, False

        normals, centers = _face_geometry_arrays(mesh, face_count)
        if topology_same:
            generation = _next_geometry_generation()
            cached.owner_ptr = owner
            cached.data_ptr = data_ptr
            cached.vertices = verts
            cached.face_normals = normals
            cached.face_centers = centers
            # Tessellation of n-gons can change after a deformation even when
            # edge/loop topology is stable. Rebuild it lazily only if an actual
            # intersection candidate needs triangles.
            cached.triangles = None
            cached.triangle_build_seconds = 0.0
            cached.source_mesh = None
            cached.bbox_min = verts.min(axis=0).astype(np.float32, copy=False) if len(verts) else np.zeros(3, dtype=np.float32)
            cached.bbox_max = verts.max(axis=0).astype(np.float32, copy=False) if len(verts) else np.zeros(3, dtype=np.float32)
            diag = float(np.linalg.norm(cached.bbox_max - cached.bbox_min)) if len(verts) else 1.0
            cached.bbox_diag = diag if math.isfinite(diag) and diag > 0.0 else 1.0
            cached.build_seconds = time.perf_counter() - start
            cached.generation = generation
            return cached, True

        return _cache_from_arrays(
            owner, data_ptr, verts, edges, normals, centers, loop_edges, totals,
            signature, start, mesh if not clear else None,
        ), True
    finally:
        if clear:
            try:
                eval_obj.to_mesh_clear()
            except Exception:
                pass
        _GEOMETRY_BUILD_DEPTH = max(0, _GEOMETRY_BUILD_DEPTH - 1)


def _build_geometry_from_existing_mesh(mesh, start, owner, data_ptr, source_mesh=None):
    """Build a full cache from a mesh already acquired by _refresh_geometry."""
    verts = _foreach(mesh.vertices, 'co', (len(mesh.vertices), 3), np.float32)
    edges = _foreach(mesh.edges, 'vertices', (len(mesh.edges), 2), np.int32)
    face_count = len(mesh.polygons)
    loop_edges = _foreach(mesh.loops, 'edge_index', (len(mesh.loops),), np.int32) if len(mesh.loops) else np.zeros(0, dtype=np.int32)
    totals = _foreach(mesh.polygons, 'loop_total', (face_count,), np.int32) if face_count else np.zeros(0, dtype=np.int32)
    signature = _topology_signature(edges, loop_edges, totals)
    normals, centers = _face_geometry_arrays(mesh, face_count)
    return _cache_from_arrays(
        owner, data_ptr, verts, edges, normals, centers, loop_edges, totals,
        signature, start, source_mesh,
    ), True


def _geometry(eval_obj, depsgraph):
    owner = _owner_ptr(eval_obj)
    if owner is None:
        return None
    data_ptr = _data_ptr(eval_obj)
    cache_key = _geometry_cache_key(eval_obj)
    if cache_key is None:
        return None
    cached = _GEOMETRY_CACHE.get(cache_key)
    dirty = owner in _DIRTY_OBJECTS or (data_ptr and data_ptr in _DIRTY_DATA)
    if cached is not None and not dirty:
        _GEOMETRY_CACHE.move_to_end(cache_key)
        return cached
    if cached is not None:
        built, _changed = _refresh_geometry(eval_obj, depsgraph, cached)
    else:
        built = _build_geometry(eval_obj, depsgraph)
    _DIRTY_OBJECTS.discard(owner)
    if data_ptr:
        _DIRTY_DATA.discard(data_ptr)
    if built is None:
        _GEOMETRY_CACHE.pop(cache_key, None)
        return None
    _GEOMETRY_CACHE[cache_key] = built
    _GEOMETRY_CACHE.move_to_end(cache_key)
    while len(_GEOMETRY_CACHE) > _MAX_GEOMETRY_CACHE:
        _GEOMETRY_CACHE.popitem(last=False)
    return built


def _front_mask(g, mw, rv3d, previous=None):
    if len(g.face_normals) == 0:
        return np.zeros(0, dtype=np.bool_)
    inv = mw.inverted_safe()
    if bool(getattr(rv3d, 'is_perspective', False)):
        eye = inv @ rv3d.view_matrix.inverted_safe().translation
        e = np.asarray((eye.x, eye.y, eye.z), dtype=np.float64)
        vectors = e[None, :] - g.face_centers
        dots = np.einsum('ij,ij->i', g.face_normals, vectors, dtype=np.float64)
        eps = max(1.0e-10, float(g.bbox_diag) * 1.0e-11)
    else:
        d = rv3d.view_matrix.inverted_safe().to_3x3() @ Vector((0.0, 0.0, 1.0))
        d = inv.to_3x3() @ d
        a = np.asarray((d.x, d.y, d.z), dtype=np.float64)
        ln = float(np.linalg.norm(a))
        if ln > 1.0e-20:
            a /= ln
        dots = np.asarray(g.face_normals, dtype=np.float64) @ a
        eps = 1.0e-10
    front = dots > eps
    near = np.abs(dots) <= eps
    if previous is not None and len(previous) == len(front) and np.any(near):
        front[near] = previous[near]
    elif np.any(near):
        # Deterministic zero-angle classification. The exact sign is irrelevant
        # to ordinary manifold silhouette edges as long as every face uses the
        # same rule, while avoiding frame-to-frame noise at grazing angles.
        front[near] = True
    return front


def _nonmanifold_csr(g):
    """Return the GeometryCache-owned CSR view without changing dict ownership."""
    if g.nonmanifold_edge_ids is not None:
        return (
            g.nonmanifold_edge_ids, g.nonmanifold_face_flat,
            g.nonmanifold_offsets, g.nonmanifold_counts,
            g.nonmanifold_empty_ids,
        )
    items = tuple((int(edge_id), tuple(faces)) for edge_id, faces in g.nonmanifold_faces.items())
    nonempty = tuple((edge_id, faces) for edge_id, faces in items if faces)
    empty_ids = np.asarray(
        [edge_id for edge_id, faces in items if not faces], dtype=np.int32)
    if nonempty:
        edge_ids = np.asarray([edge_id for edge_id, _ in nonempty], dtype=np.int32)
        counts = np.asarray([len(faces) for _, faces in nonempty], dtype=np.int64)
        face_flat = np.asarray(
            [face for _, faces in nonempty for face in faces], dtype=np.int32)
        offsets = np.zeros(len(counts) + 1, dtype=np.int64)
        np.cumsum(counts, out=offsets[1:])
    else:
        edge_ids = np.zeros(0, dtype=np.int32)
        counts = np.zeros(0, dtype=np.int64)
        face_flat = np.zeros(0, dtype=np.int32)
        offsets = np.zeros(1, dtype=np.int64)
    g.nonmanifold_edge_ids = edge_ids
    g.nonmanifold_face_flat = face_flat
    g.nonmanifold_offsets = offsets
    g.nonmanifold_counts = counts
    g.nonmanifold_empty_ids = empty_ids
    return edge_ids, face_flat, offsets, counts, empty_ids


def _silhouette_indices(g, mw, rv3d, previous=None):
    front = _front_mask(g, mw, rv3d, previous)
    mask = np.logical_or(g.boundary_mask, g.loose_mask).copy()
    both = (g.face_a >= 0) & (g.face_b >= 0)
    if len(front) and np.any(both):
        ids = np.nonzero(both)[0]
        mask[ids] = front[g.face_a[ids]] != front[g.face_b[ids]]
    if len(front):
        edge_ids, face_flat, offsets, counts, empty_ids = _nonmanifold_csr(g)
        if len(edge_ids):
            sums = np.add.reduceat(
                front[face_flat].astype(np.int64, copy=False), offsets[:-1])
            mask[edge_ids] = (sums > 0) & (sums < counts)
        if len(empty_ids):
            mask[empty_ids] = False
    return np.nonzero(mask)[0].astype(np.int32, copy=False), front


def _world_points(points, mw):
    m = np.asarray(mw, dtype=np.float64)
    return (points.astype(np.float64, copy=False) @ m[:3, :3].T + m[:3, 3]).astype(np.float32, copy=False)


def _world_points64(points, mw):
    """Transform local coordinates without reducing intersection precision."""
    m = np.asarray(mw, dtype=np.float64)
    return points.astype(np.float64, copy=False) @ m[:3, :3].T + m[:3, 3]


def _world_bbox(g, mw):
    """Return a conservative world-space AABB without transforming every vertex."""
    lo = np.asarray(g.bbox_min, dtype=np.float64)
    hi = np.asarray(g.bbox_max, dtype=np.float64)
    corners = np.asarray((
        (lo[0], lo[1], lo[2]), (lo[0], lo[1], hi[2]),
        (lo[0], hi[1], lo[2]), (lo[0], hi[1], hi[2]),
        (hi[0], lo[1], lo[2]), (hi[0], lo[1], hi[2]),
        (hi[0], hi[1], lo[2]), (hi[0], hi[1], hi[2]),
    ), dtype=np.float64)
    world = _world_points64(corners, mw)
    return world.min(axis=0), world.max(axis=0)


def _intersection_record(g, mw, instance_key):
    """Create only the inexpensive AABB data used by the broad phase.

    Triangles remain lazy here.  Most visible objects never overlap another
    object's AABB and therefore never need tessellation or a BVH.
    """
    if len(g.vertices) == 0 or len(g.face_normals) == 0:
        return None
    bbox_min, bbox_max = _world_bbox(g, mw)
    diag = float(np.linalg.norm(bbox_max - bbox_min))
    if not math.isfinite(diag) or diag <= 0.0:
        diag = 1.0
    return IntersectionRecord(
        geometry=g,
        matrix_world=mw.copy(),
        instance_key=instance_key,
        bbox_min=bbox_min,
        bbox_max=bbox_max,
        bbox_diag=diag,
    )


def _prune_superseded_instance_intersection(instance_key, geometry_key):
    """Keep only the newest transform/geometry cache for one physical instance."""
    try:
        base_key = (instance_key[0], instance_key[1])
    except Exception:
        base_key = instance_key
    previous = _INSTANCE_INTERSECTION_LATEST.get(base_key)
    if previous is None or previous == geometry_key:
        _INSTANCE_INTERSECTION_LATEST[base_key] = geometry_key
        return
    _INSTANCE_INTERSECTION_CACHE.pop(previous, None)
    for pair_key in tuple(_INTERSECTION_CACHE.keys()):
        if previous in pair_key:
            _INTERSECTION_CACHE.pop(pair_key, None)
    for scene_key in tuple(_SCENE_INTERSECTION_CACHE.keys()):
        if previous in scene_key:
            _SCENE_INTERSECTION_CACHE.pop(scene_key, None)
    _INSTANCE_INTERSECTION_LATEST[base_key] = geometry_key


def _instance_intersection_geometry(record_or_geometry, mw=None, instance_key=None, depsgraph=None):
    """Return cached world-space triangles and a BVH for one evaluated instance.

    This cache is independent from the viewport, so orbiting, panning and
    zooming reuse the exact mesh-intersection acceleration structure.
    """
    if isinstance(record_or_geometry, IntersectionRecord):
        record = record_or_geometry
        g = record.geometry
        mw = record.matrix_world
        instance_key = record.instance_key
        record_bbox_min = record.bbox_min
        record_bbox_max = record.bbox_max
        record_diag = record.bbox_diag
    else:
        # Compatibility path for internal diagnostics written against 1.2.198.
        g = record_or_geometry
        if mw is None:
            return None
        record_bbox_min, record_bbox_max = _world_bbox(g, mw)
        record_diag = float(np.linalg.norm(record_bbox_max - record_bbox_min))
        if not math.isfinite(record_diag) or record_diag <= 0.0:
            record_diag = 1.0
    triangles = g.triangles
    if triangles is None or len(triangles) == 0 or len(g.vertices) == 0:
        return None
    key = (instance_key, int(g.generation))
    _prune_superseded_instance_intersection(instance_key, key)
    cached = _INSTANCE_INTERSECTION_CACHE.get(key)
    if cached is not None:
        _INSTANCE_INTERSECTION_CACHE.move_to_end(key)
        return cached

    start = time.perf_counter()
    world = _world_points64(g.vertices, mw)
    bbox_min = record_bbox_min
    bbox_max = record_bbox_max
    diag = record_diag
    epsilon = max(1.0e-9, diag * 1.0e-8)
    try:
        # Blender 5.1 accepts NumPy arrays directly and avoids Python tuple
        # allocation for every evaluated vertex and triangle.
        bvh = BVHTree.FromPolygons(world, triangles, all_triangles=True, epsilon=epsilon)
    except Exception:
        try:
            bvh = BVHTree.FromPolygons(
                world.tolist(), triangles.tolist(), all_triangles=True, epsilon=epsilon,
            )
        except Exception:
            return None
    cached = InstanceIntersectionGeometry(
        key=key,
        world_vertices=world,
        triangles=triangles,
        bvh=bvh,
        bbox_min=bbox_min,
        bbox_max=bbox_max,
        bbox_diag=diag,
        build_seconds=time.perf_counter() - start,
    )
    _INSTANCE_INTERSECTION_CACHE[key] = cached
    _INSTANCE_INTERSECTION_CACHE.move_to_end(key)
    while len(_INSTANCE_INTERSECTION_CACHE) > _MAX_INSTANCE_INTERSECTION_CACHE:
        _INSTANCE_INTERSECTION_CACHE.popitem(last=False)
    return cached


def _triangle_plane_points(triangle, signed_distances, epsilon):
    """Return unique points where a triangle intersects one plane."""
    points = []
    eps2 = float(epsilon) * float(epsilon)
    for index in range(3):
        if abs(float(signed_distances[index])) <= epsilon:
            points.append(np.asarray(triangle[index], dtype=np.float64))
    for index in range(3):
        next_index = (index + 1) % 3
        d0 = float(signed_distances[index])
        d1 = float(signed_distances[next_index])
        if d0 * d1 >= -eps2:
            continue
        denominator = d0 - d1
        if abs(denominator) <= 1.0e-30:
            continue
        factor = d0 / denominator
        points.append(np.asarray(
            triangle[index] + (triangle[next_index] - triangle[index]) * factor,
            dtype=np.float64,
        ))
    if not points:
        return np.zeros((0, 3), dtype=np.float64)
    unique = []
    tolerance2 = max(eps2 * 16.0, 1.0e-24)
    for point in points:
        if not any(float(np.dot(point - other, point - other)) <= tolerance2 for other in unique):
            unique.append(point)
    return np.asarray(unique, dtype=np.float64)


def _triangle_intersection_segment(triangle_a, triangle_b, scale):
    """Return the exact non-coplanar intersection segment of two triangles."""
    a = np.asarray(triangle_a, dtype=np.float64)
    b = np.asarray(triangle_b, dtype=np.float64)
    normal_a = np.cross(a[1] - a[0], a[2] - a[0])
    normal_b = np.cross(b[1] - b[0], b[2] - b[0])
    length_a = float(np.linalg.norm(normal_a))
    length_b = float(np.linalg.norm(normal_b))
    if length_a <= 1.0e-20 or length_b <= 1.0e-20:
        return None
    normal_a /= length_a
    normal_b /= length_b

    epsilon = max(1.0e-9, float(scale) * 1.0e-8)
    distance_a_to_b = (a - b[0]) @ normal_b
    distance_b_to_a = (b - a[0]) @ normal_a
    if (np.all(distance_a_to_b > epsilon) or np.all(distance_a_to_b < -epsilon)
            or np.all(distance_b_to_a > epsilon) or np.all(distance_b_to_a < -epsilon)):
        return None

    direction = np.cross(normal_a, normal_b)
    direction_length = float(np.linalg.norm(direction))
    if direction_length <= 1.0e-10:
        # Coincident/coplanar triangles have no unique physical crossing line.
        # Their external boundaries remain handled by the silhouette pass.
        return None
    direction /= direction_length

    points_a = _triangle_plane_points(a, distance_a_to_b, epsilon)
    points_b = _triangle_plane_points(b, distance_b_to_a, epsilon)
    if len(points_a) < 2 or len(points_b) < 2:
        return None
    projection_a = points_a @ direction
    projection_b = points_b @ direction
    lower = max(float(np.min(projection_a)), float(np.min(projection_b)))
    upper = min(float(np.max(projection_a)), float(np.max(projection_b)))
    if upper - lower <= epsilon * 2.0:
        return None
    origin = points_a[0]
    origin_projection = float(np.dot(origin, direction))
    point0 = origin + direction * (lower - origin_projection)
    point1 = origin + direction * (upper - origin_projection)
    if float(np.linalg.norm(point1 - point0)) <= epsilon * 2.0:
        return None
    return np.asarray((point0, point1), dtype=np.float64)


def _triangle_plane_intervals_vectorized(triangles, distances, directions, epsilon):
    """Project triangle/plane intersection intervals onto common line directions."""
    count = len(triangles)
    projections = np.full((count, 6), np.nan, dtype=np.float64)
    vertex_projection = np.einsum('nij,nj->ni', triangles, directions)
    on_plane = np.abs(distances) <= epsilon
    projections[:, :3] = np.where(on_plane, vertex_projection, np.nan)

    edge_pairs = ((0, 1), (1, 2), (2, 0))
    eps2 = float(epsilon) * float(epsilon)
    for slot, (first, second) in enumerate(edge_pairs, 3):
        d0 = distances[:, first]
        d1 = distances[:, second]
        denominator = d0 - d1
        safe = (d0 * d1 < -eps2) & (np.abs(denominator) > 1.0e-30)
        factor = np.zeros(count, dtype=np.float64)
        factor[safe] = d0[safe] / denominator[safe]
        point = triangles[:, first, :] + (
            triangles[:, second, :] - triangles[:, first, :]
        ) * factor[:, None]
        projection = np.einsum('ij,ij->i', point, directions)
        projections[:, slot] = np.where(safe, projection, np.nan)

    finite = np.isfinite(projections)
    valid_count = np.count_nonzero(finite, axis=1)
    low = np.min(np.where(finite, projections, np.inf), axis=1)
    high = np.max(np.where(finite, projections, -np.inf), axis=1)
    valid = (valid_count >= 2) & np.isfinite(low) & np.isfinite(high)
    return low, high, valid


def _triangle_intersection_segments_vectorized(first, second, overlaps, scale):
    """Compute exact non-coplanar triangle intersections in vectorized chunks."""
    if not overlaps:
        return np.zeros((0, 2, 3), dtype=np.float32)
    overlap_array = np.asarray(overlaps, dtype=np.int32).reshape((-1, 2))
    epsilon = max(1.0e-9, float(scale) * 1.0e-8)
    accepted = []
    for offset in range(0, len(overlap_array), _INTERSECTION_VECTOR_CHUNK):
        indices = overlap_array[offset:offset + _INTERSECTION_VECTOR_CHUNK]
        triangle_a = first.world_vertices[first.triangles[indices[:, 0]]]
        triangle_b = second.world_vertices[second.triangles[indices[:, 1]]]

        normal_a = np.cross(triangle_a[:, 1] - triangle_a[:, 0], triangle_a[:, 2] - triangle_a[:, 0])
        normal_b = np.cross(triangle_b[:, 1] - triangle_b[:, 0], triangle_b[:, 2] - triangle_b[:, 0])
        length_a = np.linalg.norm(normal_a, axis=1)
        length_b = np.linalg.norm(normal_b, axis=1)
        valid = (length_a > 1.0e-20) & (length_b > 1.0e-20)
        if not np.any(valid):
            continue
        normal_a[valid] /= length_a[valid, None]
        normal_b[valid] /= length_b[valid, None]

        distance_a_to_b = np.einsum(
            'nij,nj->ni', triangle_a - triangle_b[:, 0, None, :], normal_b,
        )
        distance_b_to_a = np.einsum(
            'nij,nj->ni', triangle_b - triangle_a[:, 0, None, :], normal_a,
        )
        separated = (
            np.all(distance_a_to_b > epsilon, axis=1)
            | np.all(distance_a_to_b < -epsilon, axis=1)
            | np.all(distance_b_to_a > epsilon, axis=1)
            | np.all(distance_b_to_a < -epsilon, axis=1)
        )

        direction_raw = np.cross(normal_a, normal_b)
        direction_length = np.linalg.norm(direction_raw, axis=1)
        valid &= ~separated & (direction_length > 1.0e-10)
        if not np.any(valid):
            continue
        direction = np.zeros_like(direction_raw)
        direction[valid] = direction_raw[valid] / direction_length[valid, None]

        low_a, high_a, valid_a = _triangle_plane_intervals_vectorized(
            triangle_a, distance_a_to_b, direction, epsilon,
        )
        low_b, high_b, valid_b = _triangle_plane_intervals_vectorized(
            triangle_b, distance_b_to_a, direction, epsilon,
        )
        lower = np.maximum(low_a, low_b)
        upper = np.minimum(high_a, high_b)
        valid &= valid_a & valid_b & ((upper - lower) > epsilon * 2.0)
        if not np.any(valid):
            continue

        selected_direction = direction[valid]
        selected_raw = direction_raw[valid]
        selected_normal_a = normal_a[valid]
        selected_normal_b = normal_b[valid]
        constant_a = np.einsum('ij,ij->i', selected_normal_a, triangle_a[valid, 0])
        constant_b = np.einsum('ij,ij->i', selected_normal_b, triangle_b[valid, 0])
        denominator = np.maximum(direction_length[valid] ** 2, 1.0e-30)
        selected_origin = (
            constant_a[:, None] * np.cross(selected_normal_b, selected_raw)
            + constant_b[:, None] * np.cross(selected_raw, selected_normal_a)
        ) / denominator[:, None]
        origin_projection = np.einsum('ij,ij->i', selected_origin, selected_direction)
        point0 = selected_origin + selected_direction * (lower[valid] - origin_projection)[:, None]
        point1 = selected_origin + selected_direction * (upper[valid] - origin_projection)[:, None]
        length = np.linalg.norm(point1 - point0, axis=1)
        keep = length > epsilon * 2.0
        if np.any(keep):
            accepted.append(np.stack((point0[keep], point1[keep]), axis=1))

    if not accepted:
        return np.zeros((0, 2, 3), dtype=np.float32)
    segments = accepted[0] if len(accepted) == 1 else np.concatenate(accepted, axis=0)

    # Match the existing quantized duplicate removal while keeping the costly
    # triangle math out of Python.  The number of surviving physical segments
    # is normally far smaller than the BVH overlap count.
    tolerance = max(1.0e-8, float(scale) * 2.0e-7)
    unique = []
    seen = set()
    for segment in segments:
        key = _segment_key(segment, tolerance)
        if key in seen:
            continue
        seen.add(key)
        unique.append(segment.astype(np.float32, copy=False))
    return np.asarray(unique, dtype=np.float32) if unique else np.zeros((0, 2, 3), dtype=np.float32)


def _segment_key(segment, tolerance):
    inverse = 1.0 / max(float(tolerance), 1.0e-12)
    first = tuple(int(round(float(value) * inverse)) for value in segment[0])
    second = tuple(int(round(float(value) * inverse)) for value in segment[1])
    return (first, second) if first <= second else (second, first)


def _pair_cache_key(first, second):
    # The physical intersection is independent from pair order. Instance keys
    # are homogeneous tuples, so direct comparison avoids repeatedly creating
    # large repr strings for every intersecting object pair.
    try:
        return (first.key, second.key) if first.key <= second.key else (second.key, first.key)
    except TypeError:
        return (first.key, second.key) if repr(first.key) <= repr(second.key) else (second.key, first.key)


def _pair_intersection_segments(first, second):
    """Return cached exact crossing segments for two evaluated instances."""
    key = _pair_cache_key(first, second)
    cached = _INTERSECTION_CACHE.get(key)
    if cached is not None:
        _INTERSECTION_CACHE.move_to_end(key)
        return cached

    start = time.perf_counter()
    try:
        overlaps = tuple(first.bvh.overlap(second.bvh))
    except Exception:
        overlaps = ()
    if not overlaps:
        cached = IntersectionCache(key=key, build_seconds=time.perf_counter() - start)
    else:
        scale = max(float(first.bbox_diag), float(second.bbox_diag), 1.0e-9)
        try:
            array = _triangle_intersection_segments_vectorized(first, second, overlaps, scale)
        except Exception:
            # Conservative compatibility fallback for uncommon malformed meshes.
            tolerance = max(1.0e-8, scale * 2.0e-7)
            segments = []
            seen = set()
            for triangle_index_a, triangle_index_b in overlaps:
                try:
                    triangle_a = first.world_vertices[first.triangles[int(triangle_index_a)]]
                    triangle_b = second.world_vertices[second.triangles[int(triangle_index_b)]]
                except Exception:
                    continue
                segment = _triangle_intersection_segment(triangle_a, triangle_b, scale)
                if segment is None:
                    continue
                quantized = _segment_key(segment, tolerance)
                if quantized in seen:
                    continue
                seen.add(quantized)
                segments.append(segment.astype(np.float32, copy=False))
            array = np.asarray(segments, dtype=np.float32) if segments else np.zeros((0, 2, 3), dtype=np.float32)
        cached = IntersectionCache(
            key=key,
            segments=array,
            segment_count=len(array),
            pair_count=1 if len(array) else 0,
            candidate_pair_count=len(overlaps),
            build_seconds=time.perf_counter() - start,
        )
    _INTERSECTION_CACHE[key] = cached
    _INTERSECTION_CACHE.move_to_end(key)
    while len(_INTERSECTION_CACHE) > _MAX_INTERSECTION_CACHE:
        _INTERSECTION_CACHE.popitem(last=False)
    return cached


def _aabb_candidate_pairs(records):
    """Sweep-and-prune broad phase over cached world-space instance AABBs."""
    if len(records) < 2:
        return ()
    order = sorted(range(len(records)), key=lambda index: float(records[index].bbox_min[0]))
    active = []
    result = []
    for index in order:
        current = records[index]
        current_min, current_max = current.bbox_min, current.bbox_max
        current_diag = float(np.linalg.norm(current_max - current_min))
        current_margin = max(1.0e-9, current_diag * 1.0e-8)
        active = [
            other for other in active
            if float(records[other].bbox_max[0]) >= float(current_min[0]) - current_margin
        ]
        for other in active:
            other_record = records[other]
            other_min, other_max = other_record.bbox_min, other_record.bbox_max
            other_diag = float(np.linalg.norm(other_max - other_min))
            margin = max(current_margin, 1.0e-9, other_diag * 1.0e-8)
            if (float(other_max[1]) < float(current_min[1]) - margin
                    or float(current_max[1]) < float(other_min[1]) - margin
                    or float(other_max[2]) < float(current_min[2]) - margin
                    or float(current_max[2]) < float(other_min[2]) - margin):
                continue
            result.append((other, index))
        active.append(index)
    return tuple(result)


def _offset_intersection_points(points, rv3d, scale):
    """Move intersection lines slightly toward the viewer to avoid z-fighting."""
    if len(points) == 0:
        return points
    values = np.asarray(points, dtype=np.float64).copy()
    base = max(1.0e-7, float(scale) * 2.0e-6)
    try:
        inverse_view = rv3d.view_matrix.inverted_safe()
        if bool(getattr(rv3d, 'is_perspective', False)):
            eye = np.asarray(tuple(float(v) for v in inverse_view.translation), dtype=np.float64)
            vectors = eye[None, :] - values
            lengths = np.linalg.norm(vectors, axis=1)
            valid = lengths > 1.0e-20
            directions = np.zeros_like(vectors)
            directions[valid] = vectors[valid] / lengths[valid, None]
            amounts = np.maximum(base, lengths * 1.0e-6)
            amounts = np.minimum(amounts, max(base, float(scale) * 2.0e-4))
            values += directions * amounts[:, None]
        else:
            direction = inverse_view.to_3x3() @ Vector((0.0, 0.0, 1.0))
            array = np.asarray(tuple(float(v) for v in direction), dtype=np.float64)
            length = float(np.linalg.norm(array))
            if length > 1.0e-20:
                values += (array / length)[None, :] * base
    except Exception:
        return np.asarray(points, dtype=np.float32)
    return values.astype(np.float32, copy=False)


def _scene_intersection_key(records):
    return tuple((record.instance_key, int(record.geometry.generation)) for record in records)


def _collect_intersection_points(records, rv3d, depsgraph=None):
    """Return view-offset crossing lines while caching all view-independent work."""
    start = time.perf_counter()
    key = _scene_intersection_key(records)
    cached_scene = _SCENE_INTERSECTION_CACHE.get(key)
    if cached_scene is None:
        chunks = []
        segment_count = 0
        pair_count = 0
        candidate_count = 0
        max_scale = 1.0
        built_instances = {}

        def resolved(index):
            instance = built_instances.get(index)
            if instance is None:
                instance = _instance_intersection_geometry(records[index], depsgraph=depsgraph)
                if instance is not None:
                    built_instances[index] = instance
            return instance

        for first_index, second_index in _aabb_candidate_pairs(records):
            first = resolved(first_index)
            second = resolved(second_index)
            if first is None or second is None:
                continue
            cached = _pair_intersection_segments(first, second)
            candidate_count += int(cached.candidate_pair_count)
            if cached.segment_count <= 0:
                continue
            chunks.append(cached.segments.reshape((-1, 3)))
            segment_count += int(cached.segment_count)
            pair_count += 1
            max_scale = max(max_scale, float(first.bbox_diag), float(second.bbox_diag))
        raw_points = (
            chunks[0] if len(chunks) == 1
            else np.concatenate(chunks, axis=0) if chunks
            else np.zeros((0, 3), dtype=np.float32)
        )
        cached_scene = SceneIntersectionCache(
            key=key,
            points=raw_points,
            segment_count=segment_count,
            pair_count=pair_count,
            candidate_pair_count=candidate_count,
            max_scale=max_scale,
            build_seconds=time.perf_counter() - start,
        )
        _SCENE_INTERSECTION_CACHE[key] = cached_scene
        _SCENE_INTERSECTION_CACHE.move_to_end(key)
        while len(_SCENE_INTERSECTION_CACHE) > _MAX_SCENE_INTERSECTION_CACHE:
            _SCENE_INTERSECTION_CACHE.popitem(last=False)
    else:
        _SCENE_INTERSECTION_CACHE.move_to_end(key)

    if len(cached_scene.points):
        points = _offset_intersection_points(cached_scene.points, rv3d, cached_scene.max_scale)
        chunks = [points]
    else:
        chunks = []
    return (
        chunks,
        int(cached_scene.segment_count),
        int(cached_scene.pair_count),
        int(cached_scene.candidate_pair_count),
        time.perf_counter() - start,
    )

def _build_batch(context, region_ptr, rv3d, depsgraph, instances):
    sh = _shader()
    if sh is None:
        return None, 0, 0, 0.0, 0, 0, 0, 0.0
    start = time.perf_counter()
    chunks = []
    edges_total = 0
    objects = 0
    prepared = []
    for obj, mw, instance_key in instances:
        g = _geometry(obj, depsgraph)
        if g is None:
            continue
        try:
            if g.triangles is None:
                _ensure_triangles(g, obj, depsgraph)
        except Exception:
            pass
        # GeometryCache retains only copied NumPy arrays across events.
        g.source_mesh = None
        intersection_record = _intersection_record(g, mw, instance_key)
        if intersection_record is not None:
            prepared.append(intersection_record)
        state_key = (int(region_ptr), instance_key[0], instance_key[1])
        previous = _FRONT_STATE_CACHE.get(state_key)
        ids, front = _silhouette_indices(g, mw, rv3d, previous)
        _FRONT_STATE_CACHE[state_key] = front
        _FRONT_STATE_CACHE.move_to_end(state_key)
        while len(_FRONT_STATE_CACHE) > _MAX_FRONT_STATE_CACHE:
            _FRONT_STATE_CACHE.popitem(last=False)
        if len(ids) == 0: continue
        local = g.vertices[g.edges[ids].reshape(-1)]
        chunks.append(_world_points(local, mw))
        edges_total += len(ids); objects += 1
    intersection_chunks, intersection_count, intersection_pairs, intersection_candidates, intersection_elapsed = _collect_intersection_points(prepared, rv3d, depsgraph)
    if intersection_chunks:
        chunks.extend(intersection_chunks)
        edges_total += intersection_count
    if not chunks:
        return (
            None, 0, objects, time.perf_counter() - start,
            intersection_count, intersection_pairs, intersection_candidates, intersection_elapsed,
        )
    pos = chunks[0] if len(chunks) == 1 else np.concatenate(chunks, axis=0)
    try:
        batch = batch_for_shader(sh, 'LINES', {'pos': pos})
    except Exception:
        batch = batch_for_shader(sh, 'LINES', {'pos': [tuple(float(v) for v in p) for p in pos]})
    return (
        batch, edges_total, objects, time.perf_counter() - start,
        intersection_count, intersection_pairs, intersection_candidates, intersection_elapsed,
    )


def _line_width(context, prefs=None):
    """Return the effective polyline width while preserving legacy defaults.

    A thickness of 1.00 exactly follows Blender's active theme Outline Width,
    which keeps existing files visually unchanged. The user multiplier affects
    only this add-on's shader uniform and never writes to the Blender theme.
    """
    try:
        theme_width = max(1.0, float(context.preferences.themes[0].view_3d.outline_width))
    except Exception:
        theme_width = 1.0
    owner = prefs if prefs is not None else _prefs(context)
    try:
        thickness = float(getattr(owner, 'high_precision_outline_thickness', 1.0))
    except Exception:
        thickness = 1.0
    if not math.isfinite(thickness):
        thickness = 1.0
    thickness = max(0.25, min(8.0, thickness))
    return max(0.25, min(64.0, theme_width * thickness))


def _draw_batch(context, region, batch):
    sh = _SHADER
    if sh is None or batch is None: return
    prefs = _prefs(context)
    snapshot = None
    try:
        from . import mesh
        snapshot = mesh._sos_capture_gpu_state_snapshot()
    except Exception:
        snapshot = None
    try:
        # Blender may use normal or reversed-Z projection.  A fixed LESS_EQUAL
        # comparison makes hidden outline fragments pass on reversed-Z views.
        # X-Ray OFF follows the live viewport depth every redraw; X-Ray ON keeps
        # the intended through-surface outline behavior.
        depth_test = 'LESS_EQUAL'
        try:
            space = getattr(context, 'space_data', None)
            shading = getattr(space, 'shading', None)
            if getattr(shading, 'type', None) == 'WIREFRAME':
                is_xray = bool(getattr(shading, 'show_xray_wireframe', False))
            else:
                is_xray = bool(getattr(shading, 'show_xray', False))
                if float(getattr(shading, 'xray_alpha', 1.0)) <= 0.0:
                    is_xray = False
            hide_occluded_in_xray = bool(getattr(
                prefs, 'high_precision_outline_hide_occluded_in_xray', False))
            if is_xray and not hide_occluded_in_xray:
                depth_test = 'ALWAYS'
            else:
                from . import mesh
                depth_test = mesh._sos_ndc_depth_direction(
                    getattr(context, 'region_data', None)
                )[0]
        except Exception:
            depth_test = 'LESS_EQUAL'
        gpu.state.blend_set('ALPHA'); gpu.state.depth_test_set(depth_test); gpu.state.depth_mask_set(False)
        sh.bind(); sh.uniform_float('viewportSize', (float(region.width), float(region.height)))
        sh.uniform_float('lineWidth', _line_width(context, prefs)); sh.uniform_float('color', _color(context, prefs))
        batch.draw(sh)
    finally:
        try:
            from . import mesh
            mesh._sos_restore_gpu_state_snapshot(snapshot)
        except Exception:
            pass


def _build_region_snapshot(context, generation: int):
    area, region, space, rv3d = context.area, context.region, context.space_data, context.region_data
    if area is None or region is None or space is None or rv3d is None:
        return None
    if area.type != 'VIEW_3D' or region.type != 'WINDOW' or not _space_is_solid(space):
        return None
    dg = context.evaluated_depsgraph_get()
    references, _cached_signature, instance_collect_seconds = _collect_instances_cached(context, dg, space)
    instances = _resolve_instance_references(context, dg, space, references)
    instance_signature = tuple(item[2] for item in instances)
    region_ptr = _ptr(region)
    slot_key = _context_region_slot_key(context)
    cache_key = (_SCENE_REVISION, _INSTANCE_REVISION, _exact_view_sig(region, rv3d), instance_signature)
    existing = _REGION_CACHE.get(region_ptr)
    if existing is not None and existing.key == cache_key:
        return region_ptr, slot_key, existing, float(instance_collect_seconds), int(generation)
    batch, ec, oc, elapsed, ic, ipc, icc, ielapsed = _build_batch(context, region_ptr, rv3d, dg, instances)
    return region_ptr, slot_key, RegionCache(
        key=cache_key,
        slot_key=slot_key,
        batch=batch,
        edge_count=ec,
        object_count=oc,
        build_seconds=elapsed,
        intersection_count=ic,
        intersection_pair_count=ipc,
        intersection_candidate_count=icc,
        intersection_build_seconds=ielapsed,
    ), float(instance_collect_seconds), int(generation)


def _rebuild_region_snapshots(draw_stale_slots=None) -> int:
    """Build privately and publish completed per-region records atomically.

    Existing GPU batches stay published until their replacement is complete.  A
    valid empty result replaces an old record; an exception leaves the previous
    completed record intact.
    """
    global _LAST_STATS, _LAST_ERROR, _LAST_SNAPSHOT_BUILD, _LAST_BUILT_REVISIONS
    global _CONTENT_STALE_SINCE
    try:
        from . import mesh as _sos_mesh
        overrides = tuple(_sos_mesh._sos_iter_view3d_modal_overrides(getattr(bpy, 'context', None)))
    except Exception:
        overrides = ()
    draw_stale_slots = frozenset(draw_stale_slots or ())
    staged_exact = OrderedDict()
    staged_slots = OrderedDict()
    staged_stats = None
    live_regions = set()
    live_slots = set()
    errors = []
    generation = int(_SCENE_REVISION)
    _shader()  # event-side shader creation
    build_start = time.perf_counter()
    revisions = (int(_SCENE_REVISION), int(_INSTANCE_REVISION))
    for override in overrides:
        try:
            with bpy.context.temp_override(**override):
                ctx = bpy.context
                region_ptr = _ptr(getattr(ctx, 'region', None))
                slot_key = _context_region_slot_key(ctx)
                if draw_stale_slots and slot_key not in draw_stale_slots:
                    continue
                if region_ptr:
                    live_regions.add(region_ptr)
                if slot_key is not None:
                    live_slots.add(slot_key)
                if not _enabled(ctx):
                    continue
                space = getattr(ctx, 'space_data', None)
                rv3d = getattr(ctx, 'region_data', None)
                if space is None or rv3d is None or not _space_is_solid(space):
                    continue
                try:
                    prefs = _sos_mesh.get_effective_settings(ctx)
                    scope_allowed, _active_allowed, _freeze_rebuild = _sos_mesh.mesh_curve_overlay_draw_policy(
                        ctx, prefs, rv3d
                    )
                except Exception:
                    continue
                # Match Mesh/Curve snapshot ownership: build every allowed live
                # View3D region.  Draw Active View Only is a draw-time gate, so a
                # later operation can switch panes without a blank rebuild gap.
                # High-precision silhouettes are view-dependent.  Geometry and
                # intersection caches remain frozen/reused, but the cheap front-
                # facing classification must rebuild during orbit/pan/zoom.
                if not scope_allowed:
                    continue
                result = _build_region_snapshot(ctx, generation)
                if result is None:
                    continue
                key, built_slot, record, collect_seconds, _generation = result
                staged_exact[key] = record
                if built_slot is not None:
                    staged_slots[built_slot] = record
                staged_stats = {
                    'edge_count': int(record.edge_count),
                    'object_count': int(record.object_count),
                    'intersection_count': int(record.intersection_count),
                    'intersection_pair_count': int(record.intersection_pair_count),
                    'intersection_candidate_count': int(record.intersection_candidate_count),
                    'intersection_build_ms': round(record.intersection_build_seconds * 1000.0, 3),
                    'build_ms': round(record.build_seconds * 1000.0, 3),
                    'geometry_cache': len(_GEOMETRY_CACHE),
                    'instance_intersection_cache': len(_INSTANCE_INTERSECTION_CACHE),
                    'intersection_cache': len(_INTERSECTION_CACHE),
                    'region_cache': len(_REGION_CACHE),
                    'region_slot_cache': len(_REGION_SLOT_CACHE),
                    'instance_snapshot_cache': len(_INSTANCE_SNAPSHOT_CACHE),
                    'scene_intersection_cache': len(_SCENE_INTERSECTION_CACHE),
                    'instance_collect_ms': round(collect_seconds * 1000.0, 3),
                    'scene_revision': _SCENE_REVISION,
                    'instance_revision': _INSTANCE_REVISION,
                }
        except Exception as exc:
            errors.append(f'{type(exc).__name__}: {exc}')

    # Blender executes this event job and draw callbacks on its main thread.  Both
    # cache maps therefore change at one publication boundary; no partial builder
    # state can be observed by draw.
    for key, record in staged_exact.items():
        _REGION_CACHE[key] = record
        _REGION_CACHE.move_to_end(key)
    for slot_key, record in staged_slots.items():
        _REGION_SLOT_CACHE[slot_key] = record
        _REGION_SLOT_CACHE.move_to_end(slot_key)

    # A file/screen transition can temporarily enumerate no View3D regions.
    # Treat that as an incomplete scan, not proof that every last-known GPU record
    # is dead; the next successful all-region build retires genuinely closed slots.
    if not draw_stale_slots and live_regions:
        for region_ptr in tuple(_REGION_CACHE.keys()):
            if region_ptr not in live_regions:
                _REGION_CACHE.pop(region_ptr, None)
    if not draw_stale_slots and live_slots:
        for slot_key in tuple(_REGION_SLOT_CACHE.keys()):
            if slot_key not in live_slots:
                _REGION_SLOT_CACHE.pop(slot_key, None)
    while len(_REGION_CACHE) > _MAX_REGION_CACHE:
        _REGION_CACHE.popitem(last=False)
    while len(_REGION_SLOT_CACHE) > _MAX_REGION_CACHE:
        _REGION_SLOT_CACHE.popitem(last=False)

    if staged_stats is not None:
        staged_stats['region_cache'] = len(_REGION_CACHE)
        staged_stats['region_slot_cache'] = len(_REGION_SLOT_CACHE)
        _LAST_STATS = staged_stats
    # Only rebuilds caused by changed content predict the cost of the next
    # timeline change; view-only rebuilds reuse the geometry caches.  Changes that
    # leave the geometry alone reuse them too, so they are measured separately.
    if staged_exact and revisions != _LAST_BUILT_REVISIONS:
        geometry_changed = _LAST_BUILT_REVISIONS is None or revisions[0] != _LAST_BUILT_REVISIONS[0]
        costs = _CONTENT_REBUILD_COSTS if geometry_changed else _INSTANCE_REBUILD_COSTS
        _LAST_BUILT_REVISIONS = revisions
        costs.append(time.perf_counter() - build_start)
        del costs[:-2]
    if staged_exact:
        _CONTENT_STALE_SINCE = 0.0
    _LAST_SNAPSHOT_BUILD = float(time.monotonic())
    _LAST_ERROR = errors[-1] if errors else ''
    return len(staged_exact)


def _reset_snapshot_rebuild_state():
    global _SNAPSHOT_REBUILD_PENDING, _SNAPSHOT_REBUILD_ATTEMPTS
    global _SNAPSHOT_REBUILD_DUE, _SNAPSHOT_REBUILD_FENCE, _SNAPSHOT_REBUILD_ALL_REGIONS
    _SNAPSHOT_REBUILD_PENDING = False
    _SNAPSHOT_REBUILD_ATTEMPTS = 0
    _SNAPSHOT_REBUILD_DUE = 0.0
    _SNAPSHOT_REBUILD_FENCE = 0
    _SNAPSHOT_REBUILD_ALL_REGIONS = False
    _DRAW_STALE_REGION_SLOTS.clear()


def _edit_update_guard_active() -> bool:
    return bool(_EDIT_UPDATE_GUARD_ACTIVE)


def _clear_edit_update_guard() -> None:
    global _EDIT_UPDATE_GUARD_ACTIVE, _EDIT_UPDATE_GUARD_RELEASE_PENDING_GENERATION
    _EDIT_UPDATE_GUARD_ACTIVE = False
    _EDIT_UPDATE_GUARD_RELEASE_PENDING_GENERATION = 0


def _cancel_snapshot_rebuild_timer():
    try:
        if bpy.app.timers.is_registered(_snapshot_rebuild_timer):
            bpy.app.timers.unregister(_snapshot_rebuild_timer)
    except Exception:
        pass
    _reset_snapshot_rebuild_state()


def _cancel_frame_settle_timer():
    global _FRAME_REBUILD_DEFERRED
    _FRAME_REBUILD_DEFERRED = False
    try:
        if bpy.app.timers.is_registered(_frame_settle_timer):
            bpy.app.timers.unregister(_frame_settle_timer)
    except Exception:
        pass


def _discard_snapshot_state(*, preserve_region_cache=False):
    """Release all RNA/CPU builder state, optionally retaining complete GPU output."""
    for cached in tuple(_GEOMETRY_CACHE.values()):
        try:
            cached.source_mesh = None
        except Exception:
            pass
    _GEOMETRY_CACHE.clear(); _FRONT_STATE_CACHE.clear()
    if not preserve_region_cache:
        _REGION_CACHE.clear()
        _REGION_SLOT_CACHE.clear()
    _INSTANCE_INTERSECTION_CACHE.clear(); _INTERSECTION_CACHE.clear()
    _INSTANCE_SNAPSHOT_CACHE.clear(); _SCENE_INTERSECTION_CACHE.clear()
    _INSTANCE_INTERSECTION_LATEST.clear()
    _DIRTY_OBJECTS.clear(); _DIRTY_DATA.clear()
    _STANDARD_OUTLINE_SNAPSHOT.clear()


def _fence_snapshot_boundary():
    global _SNAPSHOT_FENCE_GENERATION, _SCENE_REVISION, _INSTANCE_REVISION
    _SNAPSHOT_FENCE_GENERATION += 1
    _cancel_snapshot_rebuild_timer()
    _cancel_frame_settle_timer()
    # Fence every RNA/CPU reference immediately, but keep the last complete GPU
    # records published until post-boundary rebuilding has a replacement ready.
    _discard_snapshot_state(preserve_region_cache=True)
    _SCENE_REVISION += 1
    _INSTANCE_REVISION += 1


@persistent
def _snapshot_load_pre(_dummy):
    _fence_snapshot_boundary()


@persistent
def _snapshot_load_post(_dummy):
    if _RUNTIME_REGISTERED and _enabled():
        _schedule_active_view_prime()
        request_snapshot_rebuild('load_post', context=getattr(bpy, 'context', None), immediate=True)


@persistent
def _snapshot_undo_post(_dummy):
    _fence_snapshot_boundary()
    if _RUNTIME_REGISTERED and _enabled():
        request_snapshot_rebuild('undo_post', context=getattr(bpy, 'context', None), immediate=True)


@persistent
def _snapshot_redo_post(_dummy):
    _fence_snapshot_boundary()
    if _RUNTIME_REGISTERED and _enabled():
        request_snapshot_rebuild('redo_post', context=getattr(bpy, 'context', None), immediate=True)


def _register_snapshot_boundary_handlers():
    handlers = bpy.app.handlers
    for collection, callback in (
            (handlers.depsgraph_update_pre, depsgraph_update_pre),
            (handlers.frame_change_post, _snapshot_frame_change_post),
            (handlers.undo_post, _snapshot_undo_post),
            (handlers.redo_post, _snapshot_redo_post)):
        if callback not in collection:
            collection.append(callback)
    events.add_hook('load_pre', _snapshot_load_pre)
    events.add_hook('load_post', _snapshot_load_post)


def _unregister_snapshot_boundary_handlers():
    handlers = bpy.app.handlers
    events.remove_hook('load_pre', _snapshot_load_pre)
    events.remove_hook('load_post', _snapshot_load_post)
    for collection, callback in (
            (handlers.depsgraph_update_pre, depsgraph_update_pre),
            (handlers.frame_change_post, _snapshot_frame_change_post),
            (handlers.undo_post, _snapshot_undo_post),
            (handlers.redo_post, _snapshot_redo_post)):
        try:
            while callback in collection:
                collection.remove(callback)
        except Exception:
            pass


def _last_rebuild_cost(geometry_changed) -> float:
    # The cheaper of the last two rebuilds, so one hiccup does not drop the lines.
    costs = _CONTENT_REBUILD_COSTS if geometry_changed else _INSTANCE_REBUILD_COSTS
    return min(costs) if costs else 0.0


def _timeline_is_moving() -> bool:
    try:
        for window in bpy.context.window_manager.windows:
            screen = window.screen
            if screen is not None and (screen.is_animation_playing or screen.is_scrubbing):
                return True
    except Exception:
        pass
    return False


def _frame_settle_timer():
    global _FRAME_REBUILD_DEFERRED
    if not _RUNTIME_REGISTERED or not _enabled():
        _FRAME_REBUILD_DEFERRED = False
        return None
    if _timeline_is_moving():
        return _FRAME_SETTLE_SECONDS
    remaining = float(_FRAME_SETTLE_DUE) - float(time.monotonic())
    if remaining > 0.0:
        return max(0.001, remaining)
    _FRAME_REBUILD_DEFERRED = False
    request_snapshot_rebuild('frame_settled', immediate=True)
    _tag_redraw()
    return None


def _defer_frame_rebuild():
    global _FRAME_REBUILD_DEFERRED, _FRAME_SETTLE_DUE
    _FRAME_SETTLE_DUE = float(time.monotonic()) + _FRAME_SETTLE_SECONDS
    _FRAME_REBUILD_DEFERRED = True
    try:
        if not bpy.app.timers.is_registered(_frame_settle_timer):
            bpy.app.timers.register(_frame_settle_timer, first_interval=_FRAME_SETTLE_SECONDS)
    except Exception:
        _FRAME_REBUILD_DEFERRED = False
        return
    # A rebuild queued before the timeline moved would be out of date by the next
    # frame.  The settle timer requests a fresh one, which also releases the guard.
    _cancel_snapshot_rebuild_timer()


def _snapshot_rebuild_timer():
    global _SNAPSHOT_REBUILD_PENDING, _SNAPSHOT_REBUILD_ATTEMPTS, _SNAPSHOT_REBUILD_DUE
    global _SNAPSHOT_REBUILD_FENCE, _SNAPSHOT_REBUILD_ALL_REGIONS
    global _EDIT_UPDATE_GUARD_ACTIVE, _EDIT_UPDATE_GUARD_RELEASE_PENDING_GENERATION
    fence = int(_SNAPSHOT_REBUILD_FENCE)
    if fence <= 0 or fence != int(_SNAPSHOT_FENCE_GENERATION):
        _reset_snapshot_rebuild_state()
        return None
    if not _RUNTIME_REGISTERED or not _enabled():
        _reset_snapshot_rebuild_state()
        return None
    if (_edit_update_guard_active()
            and int(_EDIT_UPDATE_GUARD_RELEASE_PENDING_GENERATION or 0)
            == int(_EDIT_UPDATE_GUARD_GENERATION or 0)):
        _EDIT_UPDATE_GUARD_ACTIVE = False
        _EDIT_UPDATE_GUARD_RELEASE_PENDING_GENERATION = 0
        _SNAPSHOT_SKIP_DIAGNOSTICS.add('edit_update_guard_timer_release')
        return _SNAPSHOT_REBUILD_MIN_INTERVAL
    if _edit_update_guard_active():
        _SNAPSHOT_SKIP_DIAGNOSTICS.add('edit_update_guard_timer_defer')
        return _SNAPSHOT_REBUILD_MIN_INTERVAL
    now = float(time.monotonic())
    if now < float(_SNAPSHOT_REBUILD_DUE or 0.0):
        return max(0.001, float(_SNAPSHOT_REBUILD_DUE) - now)
    serial = int(_SNAPSHOT_REBUILD_SERIAL)
    _SNAPSHOT_REBUILD_ATTEMPTS += 1
    try:
        stale_slots = () if _SNAPSHOT_REBUILD_ALL_REGIONS else tuple(_DRAW_STALE_REGION_SLOTS)
        _SNAPSHOT_REBUILD_ALL_REGIONS = False
        _DRAW_STALE_REGION_SLOTS.clear()
        _rebuild_region_snapshots(stale_slots)
    except Exception:
        pass
    if fence != int(_SNAPSHOT_FENCE_GENERATION):
        _reset_snapshot_rebuild_state()
        return None
    if serial != int(_SNAPSHOT_REBUILD_SERIAL) and _SNAPSHOT_REBUILD_ATTEMPTS < _SNAPSHOT_REBUILD_MAX_ATTEMPTS:
        _SNAPSHOT_REBUILD_DUE = float(time.monotonic()) + _SNAPSHOT_REBUILD_MIN_INTERVAL
        return _SNAPSHOT_REBUILD_MIN_INTERVAL
    _reset_snapshot_rebuild_state()
    _tag_redraw()
    return None


def request_snapshot_rebuild(reason='', context=None, immediate=False) -> bool:
    global _SNAPSHOT_REBUILD_PENDING, _SNAPSHOT_REBUILD_SERIAL, _SNAPSHOT_REBUILD_DUE
    global _SNAPSHOT_REBUILD_FENCE, _SNAPSHOT_REBUILD_ALL_REGIONS
    if not _RUNTIME_REGISTERED or not _enabled(context):
        return False
    # The settle timer rebuilds everything once the timeline has stopped.
    if _FRAME_REBUILD_DEFERRED:
        return True
    if _SNAPSHOT_REBUILD_PENDING and _SNAPSHOT_REBUILD_FENCE != _SNAPSHOT_FENCE_GENERATION:
        _cancel_snapshot_rebuild_timer()
    reason_text = str(reason or '')
    if reason_text.startswith('draw_') and context is not None:
        try:
            slot_key = _context_region_slot_key(context)
            if slot_key is not None:
                _DRAW_STALE_REGION_SLOTS.add(slot_key)
        except Exception:
            pass
    elif not reason_text.startswith('draw_'):
        _SNAPSHOT_REBUILD_ALL_REGIONS = True
    # Repeated draw-stale requests merely confirm the pending view refresh.  Do
    # not keep advancing the serial on every redraw or the finite timer would
    # spend all of its attempts chasing duplicate requests during navigation.
    if not (_SNAPSHOT_REBUILD_PENDING and reason_text.startswith('draw_')):
        _SNAPSHOT_REBUILD_SERIAL += 1
    now = float(time.monotonic())
    due = now if immediate else max(now, float(_LAST_SNAPSHOT_BUILD or 0.0) + _SNAPSHOT_REBUILD_MIN_INTERVAL)
    if _SNAPSHOT_REBUILD_PENDING:
        _SNAPSHOT_REBUILD_DUE = min(float(_SNAPSHOT_REBUILD_DUE or due), due)
        return True
    _SNAPSHOT_REBUILD_PENDING = True
    _SNAPSHOT_REBUILD_DUE = due
    _SNAPSHOT_REBUILD_FENCE = int(_SNAPSHOT_FENCE_GENERATION)
    try:
        bpy.app.timers.register(_snapshot_rebuild_timer, first_interval=max(0.0, due - now))
        return True
    except Exception:
        _reset_snapshot_rebuild_state()
        return False


def draw():
    global _LAST_ERROR, _CONTENT_STALE_SINCE
    # While the guard is armed the rebuild is already queued on the timer.  Drawing
    # the published batch reads no scene data, so the outline stays on screen.
    guarded = _edit_update_guard_active()
    ctx = bpy.context
    if not _enabled(ctx):
        return
    area, region, space, rv3d = ctx.area, ctx.region, ctx.space_data, ctx.region_data
    if area is None or region is None or space is None or rv3d is None:
        return
    if area.type != 'VIEW_3D' or region.type != 'WINDOW':
        return

    identity = _context_space_identity(ctx)
    state = _decode_native_state()
    if not _space_is_solid(space):
        _restore_space(space, identity, state)
        return

    try:
        from . import mesh as _sos_mesh
        prefs = _sos_mesh.get_effective_settings(ctx)
        scope_allowed, active_allowed, freeze_rebuild = _sos_mesh.mesh_curve_overlay_draw_policy(
            ctx, prefs, rv3d
        )
    except Exception:
        return
    if not scope_allowed:
        _restore_space(space, identity, state)
        return
    if not active_allowed:
        # Draw Active View Only must never leave owned pixels in more than one
        # eligible view.  When no owner is currently live, kick the event-side
        # timer so ownership resolves to exactly one view, but suppress this
        # non-owning view's own draw immediately -- matching the Mesh/Curve
        # overlay's single-owner policy instead of temporarily drawing the
        # completed batch in every eligible Solid view during the ownerless
        # interval.
        try:
            if not bool(_sos_mesh._sos_active_draw_token_visible(ctx)):
                _schedule_active_view_prime()
        except Exception:
            pass
        _restore_space(space, identity, state)
        return

    region_ptr = _ptr(region)
    slot_key = _context_region_slot_key(ctx)
    rc = _REGION_CACHE.get(region_ptr)
    if rc is None and slot_key is not None:
        rc = _REGION_SLOT_CACHE.get(slot_key)
    expected_prefix = (_SCENE_REVISION, _INSTANCE_REVISION, _exact_view_sig(region, rv3d))
    if rc is None:
        # Keep Blender's original Outline visible until a complete replacement
        # batch exists.  This also removes the blank frame during startup/load.
        _restore_space(space, identity, state)
        if not guarded:
            request_snapshot_rebuild('draw_missing', context=ctx, immediate=True)
        return
    if _FRAME_REBUILD_DEFERRED and tuple(rc.key[:3]) != tuple(expected_prefix):
        # A batch from another frame would show lines where nothing is any more.
        _restore_space(space, identity, state)
        return
    if not guarded and tuple(rc.key[:3]) != tuple(expected_prefix):
        # The old batch remains depth-tested against the current frame while its
        # view-dependent silhouette replacement is built.  This prevents hidden
        # fragments from leaking through and avoids a blank outline during orbit.
        request_snapshot_rebuild('draw_stale', context=ctx, immediate=True)
    if tuple(rc.key[:2]) != tuple(expected_prefix[:2]):
        # The content has moved away from this batch.  Keep it only while its
        # replacement is close: a costly rebuild would hold it on screen, and steady
        # updates keep re-arming the guard so no rebuild runs until they stop.  A
        # view-only difference stays drawn.
        now = float(time.monotonic())
        if _CONTENT_STALE_SINCE <= 0.0:
            _CONTENT_STALE_SINCE = now
        if (now - _CONTENT_STALE_SINCE > _CONTENT_STALE_LIMIT
                or _last_rebuild_cost(rc.key[0] != expected_prefix[0]) > _FRAME_STEP_REBUILD_BUDGET):
            _restore_space(space, identity, state)
            return

    # Suppress Blender's standard Outline only in the active Solid viewport and
    # only after a completed high-precision record is available for drawing.
    if _suppress_space(space, identity, state):
        _encode_native_state(state)
    try:
        _draw_batch(ctx, region, rc.batch)
        _LAST_ERROR = ''
    except Exception as exc:
        _LAST_ERROR = f'{type(exc).__name__}: {exc}'
        request_snapshot_rebuild('draw_exception', context=ctx, immediate=False)


@persistent
def depsgraph_update_pre(_scene, _depsgraph):
    global _EDIT_UPDATE_GUARD_ACTIVE, _EDIT_UPDATE_GUARD_GENERATION
    global _EDIT_UPDATE_GUARD_RELEASE_PENDING_GENERATION
    if not _RUNTIME_REGISTERED or not _enabled():
        _clear_edit_update_guard()
        return
    _EDIT_UPDATE_GUARD_ACTIVE = True
    _EDIT_UPDATE_GUARD_GENERATION = int(_EDIT_UPDATE_GUARD_GENERATION) + 1
    _EDIT_UPDATE_GUARD_RELEASE_PENDING_GENERATION = 0
    _SNAPSHOT_SKIP_DIAGNOSTICS.add('depsgraph_edit_update_guard_pre')


def _record_depsgraph_updates(depsgraph):
    global _SCENE_REVISION, _INSTANCE_REVISION
    geometry_changed = False
    instance_changed = False
    try:
        updates = tuple(depsgraph.updates)
    except Exception:
        updates = ()
    for update in updates:
        try:
            datablock = update.id
            original = getattr(datablock, 'original', None) or datablock
            is_geometry = bool(getattr(update, 'is_updated_geometry', False))
            if isinstance(original, bpy.types.Object):
                # Object updates include transforms, visibility and collection
                # membership.  They invalidate only the cheap instance snapshot
                # unless evaluated geometry was also reported dirty.
                instance_changed = True
                if is_geometry:
                    _DIRTY_OBJECTS.add(_ptr(original))
                    try:
                        if (str(getattr(original, 'type', '')) == 'MESH'
                                and len(getattr(original, 'modifiers', ()) or ()) == 0
                                and getattr(original, 'data', None) is not None):
                            _DIRTY_DATA.add(_ptr(original.data))
                    except Exception:
                        pass
                    geometry_changed = True
            elif isinstance(original, (bpy.types.Mesh, bpy.types.Curve, bpy.types.MetaBall)):
                if is_geometry:
                    _DIRTY_DATA.add(_ptr(original))
                    geometry_changed = True
            elif isinstance(original, (bpy.types.Collection, bpy.types.Scene)):
                instance_changed = True
        except Exception:
            continue
    if geometry_changed:
        _SCENE_REVISION += 1
    if instance_changed:
        _INSTANCE_REVISION += 1
        _INSTANCE_SNAPSHOT_CACHE.clear()
    return geometry_changed, instance_changed


@persistent
def depsgraph_update(_scene, depsgraph):
    global _EDIT_UPDATE_GUARD_RELEASE_PENDING_GENERATION
    if not _enabled() or _GEOMETRY_BUILD_DEPTH > 0:
        return
    geometry_changed, instance_changed = _record_depsgraph_updates(depsgraph)
    # depsgraph_update_pre always arms the guard first, so the revisions above
    # must be recorded before the rebuild is deferred to the timer.
    if _edit_update_guard_active():
        _EDIT_UPDATE_GUARD_RELEASE_PENDING_GENERATION = int(_EDIT_UPDATE_GUARD_GENERATION or 0)
        _SNAPSHOT_SKIP_DIAGNOSTICS.add('depsgraph_edit_update_guard_post')
        request_snapshot_rebuild('depsgraph_edit_update_guard_post', context=getattr(bpy, 'context', None), immediate=False)
        return
    if geometry_changed or instance_changed:
        request_snapshot_rebuild('depsgraph_update', context=getattr(bpy, 'context', None), immediate=False)


@persistent
def _snapshot_frame_change_post(scene, depsgraph):
    """Frame changes never reach the depsgraph_update handlers."""
    # Render jobs run this handler on their own thread with their own depsgraph.
    if threading.current_thread() is not threading.main_thread():
        return
    if not _RUNTIME_REGISTERED or not _enabled() or _GEOMETRY_BUILD_DEPTH > 0:
        return
    geometry_changed, instance_changed = _record_depsgraph_updates(depsgraph)
    if not (geometry_changed or instance_changed):
        return
    moving = _timeline_is_moving()
    if moving:
        try:
            budget = _FRAME_REBUILD_FRAME_SHARE * float(scene.render.fps_base) / max(float(scene.render.fps), 1.0)
        except Exception:
            budget = _FRAME_REBUILD_FRAME_SHARE / 24.0
    else:
        budget = _FRAME_STEP_REBUILD_BUDGET
    if _FRAME_REBUILD_DEFERRED or _last_rebuild_cost(geometry_changed) > budget:
        _defer_frame_rebuild()
        return
    if moving and not _edit_update_guard_active():
        # A timer would fire after this frame's redraw and leave the lines a frame behind.
        try:
            _rebuild_region_snapshots()
            return
        except Exception:
            pass
    request_snapshot_rebuild('frame_change', context=getattr(bpy, 'context', None), immediate=False)


def clear_cache(context=None):
    global _SCENE_REVISION, _INSTANCE_REVISION
    _discard_snapshot_state(preserve_region_cache=True)
    _SCENE_REVISION += 1
    _INSTANCE_REVISION += 1
    request_snapshot_rebuild('clear_cache', context=context, immediate=True)
    _tag_redraw(context)


def tag_style_redraw(context=None):
    """Redraw color/width changes without invalidating geometry caches."""
    _tag_redraw(context)


def tag_redraw(context=None):
    request_snapshot_rebuild('tag_redraw', context=context, immediate=True)
    _tag_redraw(context)


def register_runtime(context=None):
    global _DRAW_HANDLE, _RUNTIME_REGISTERED
    if depsgraph_update not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(depsgraph_update)
    if _DRAW_HANDLE is None:
        _DRAW_HANDLE = bpy.types.SpaceView3D.draw_handler_add(draw, (), 'WINDOW', 'POST_VIEW')
    _RUNTIME_REGISTERED = _DRAW_HANDLE is not None
    if _RUNTIME_REGISTERED:
        _register_snapshot_boundary_handlers()
        primed = False
        try:
            from . import mesh as _sos_mesh
            primed = bool(_sos_mesh.prime_active_view_draw_context(
                context or getattr(bpy, 'context', None), force=True,
                source='high_precision_outline_enable',
            ))
        except Exception:
            primed = False
        if not primed:
            _schedule_active_view_prime()
        clear_cache(context)
        request_snapshot_rebuild('runtime_register', context=context, immediate=True)
    return _RUNTIME_REGISTERED


def unregister_runtime(context=None, *, clear_persisted=False):
    global _DRAW_HANDLE, _RUNTIME_REGISTERED, _SHADER, _LAST_BUILT_REVISIONS
    _LAST_BUILT_REVISIONS = None
    try:
        if _DRAW_HANDLE is not None: bpy.types.SpaceView3D.draw_handler_remove(_DRAW_HANDLE, 'WINDOW')
    except Exception: pass
    _DRAW_HANDLE = None; _RUNTIME_REGISTERED = False
    _cancel_active_view_prime()
    _cancel_snapshot_rebuild_timer()
    _cancel_frame_settle_timer()
    _CONTENT_REBUILD_COSTS.clear()
    _INSTANCE_REBUILD_COSTS.clear()
    _unregister_snapshot_boundary_handlers()
    try:
        while depsgraph_update in bpy.app.handlers.depsgraph_update_post:
            bpy.app.handlers.depsgraph_update_post.remove(depsgraph_update)
    except Exception: pass
    _restore_native(context, clear_persisted=clear_persisted)
    _discard_snapshot_state()
    _clear_edit_update_guard()
    _SNAPSHOT_SKIP_DIAGNOSTICS.clear()
    _SHADER = None; _tag_redraw(context)


def sync_runtime(context=None):
    if _enabled(context):
        return register_runtime(context)
    unregister_runtime(context, clear_persisted=True)
    return False


def runtime_registered(): return bool(_RUNTIME_REGISTERED and _DRAW_HANDLE is not None)

def debug_stats():
    d = dict(_LAST_STATS); d['runtime_registered'] = runtime_registered(); d['last_error'] = _LAST_ERROR
    d['active_view_prime_pending'] = bool(_ACTIVE_VIEW_PRIME_PENDING)
    d['active_view_prime_attempts'] = int(_ACTIVE_VIEW_PRIME_ATTEMPTS)
    d['snapshot_skip_diagnostics'] = tuple(sorted(_SNAPSHOT_SKIP_DIAGNOSTICS)); return d
