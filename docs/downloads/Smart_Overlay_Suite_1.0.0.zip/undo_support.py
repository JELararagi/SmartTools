# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import functools
import json
from contextlib import contextmanager
from typing import Any

import bpy
from bpy.app.handlers import persistent

_SCENE_SNAPSHOT_PROP = 'sos_undo_settings_json'
_SCENE_SNAPSHOT_SEQ_PROP = 'sos_undo_settings_seq'
_UNDO_GROUP_NAME = 'Smart Overlay Suite'
_REGISTERED = False
_APPLY_LOCK = 0
_GROUP_DEPTH = 0
_GROUP_DIRTY = False
_UNDO_PUSH_PENDING = False
_LAST_APPLIED_TEXT = ''

_SKIP_OPERATOR_IDS = {
    'smart_overlay.open_help',
    'sos.tool_help_popup',
    'view3d.sos_tool_help',
    'view3d.sos_mouse_tracker',
    'uv.sos_hover_daemon',
    'sos.uv_hover_daemon',
}
_SKIP_OPERATOR_NAMES = {
    'SMART_OVERLAY_OT_open_help',
    'SOS_OT_ToolHelpPopup',
    'SOS_OT_MouseTracker',
    'SOS_OT_uv_hover_daemon',
}


def scene_snapshot_property_name() -> str:
    return _SCENE_SNAPSHOT_PROP


def scene_sequence_property_name() -> str:
    return _SCENE_SNAPSHOT_SEQ_PROP


def is_applying() -> bool:
    return _APPLY_LOCK > 0


def _context(ctx=None):
    return ctx or getattr(bpy, 'context', None)


def _scene(ctx=None):
    try:
        return getattr(_context(ctx), 'scene', None)
    except Exception:
        return None


def _semantic_text_from_data(data: dict[str, Any] | None) -> str:
    try:
        from . import settings
        return settings._semantic_json_text(data if isinstance(data, dict) else {})
    except Exception:
        try:
            if not isinstance(data, dict):
                data = {}
            clean = {str(k): v for k, v in data.items() if str(k) not in {'saved_at', '_saved_at'}}
            return json.dumps(clean, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
        except Exception:
            return '{}'


def _read_text_as_data(text: str | None) -> dict[str, Any]:
    if not text:
        return {}
    try:
        data = json.loads(str(text))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _snapshot_text(data: dict[str, Any] | None) -> str:
    try:
        return json.dumps(data if isinstance(data, dict) else {}, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    except Exception:
        return '{}'


def _collect_snapshot_text(ctx=None) -> str:
    try:
        from . import settings
        data = settings.collect_settings(_context(ctx))
    except Exception:
        data = {}
    return _snapshot_text(data)


def _same_snapshot_text(a: str | None, b: str | None) -> bool:
    try:
        return _semantic_text_from_data(_read_text_as_data(a)) == _semantic_text_from_data(_read_text_as_data(b))
    except Exception:
        return str(a or '') == str(b or '')


def _set_scene_snapshot(scene, text: str) -> bool:
    if scene is None:
        return False
    try:
        if not hasattr(scene, _SCENE_SNAPSHOT_PROP):
            return False
    except Exception:
        return False
    try:
        setattr(scene, _SCENE_SNAPSHOT_PROP, str(text or '{}'))
        try:
            seq = int(getattr(scene, _SCENE_SNAPSHOT_SEQ_PROP, 0) or 0) + 1
            setattr(scene, _SCENE_SNAPSHOT_SEQ_PROP, seq)
        except Exception:
            pass
        return True
    except Exception:
        return False


def _write_scene_snapshot(ctx=None, *, force: bool = False) -> bool:
    global _LAST_APPLIED_TEXT
    scn = _scene(ctx)
    if scn is None:
        return False
    new_text = _collect_snapshot_text(ctx)
    try:
        old_text = str(getattr(scn, _SCENE_SNAPSHOT_PROP, '') or '')
    except Exception:
        old_text = ''
    if not force and old_text and _same_snapshot_text(old_text, new_text):
        _LAST_APPLIED_TEXT = old_text
        return False
    if _set_scene_snapshot(scn, new_text):
        _LAST_APPLIED_TEXT = new_text
        return True
    return False


def _undo_push_timer():
    global _UNDO_PUSH_PENDING
    _UNDO_PUSH_PENDING = False
    if not _REGISTERED:
        return None
    if is_applying():
        return None
    try:
        if getattr(getattr(bpy, 'context', None), 'window_manager', None) is None:
            return None
    except Exception:
        return None
    try:
        bpy.ops.ed.undo_push(message=_UNDO_GROUP_NAME)
    except Exception:
        pass
    return None


def _schedule_undo_push() -> None:
    global _UNDO_PUSH_PENDING
    if _UNDO_PUSH_PENDING or not _REGISTERED:
        return
    _UNDO_PUSH_PENDING = True
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is None:
            _undo_push_timer()
            return
        if not timers.is_registered(_undo_push_timer):
            timers.register(_undo_push_timer, first_interval=0.01)
    except Exception:
        _undo_push_timer()


def record_settings_change(context=None, *, push: bool = True, force: bool = False) -> bool:
    """Record the current Smart Overlay state in Blender's undo stack.

    AddonPreferences, module-level UI state, always-on runtime settings, and
    several integrated-tool states are not regular scene edit data.  This helper
    mirrors them into hidden Scene RNA so Blender Undo/Redo can restore them.
    """
    global _GROUP_DIRTY
    if not _REGISTERED or is_applying():
        return False
    try:
        from . import settings
        if settings.is_applying():
            return False
    except Exception:
        pass
    if _GROUP_DEPTH > 0:
        _GROUP_DIRTY = True
        return False
    changed = _write_scene_snapshot(context, force=force)
    if changed and push:
        _schedule_undo_push()
    return changed


@contextmanager
def grouped_settings_change(context=None):
    global _GROUP_DEPTH, _GROUP_DIRTY
    _GROUP_DEPTH += 1
    try:
        yield
    finally:
        _GROUP_DEPTH = max(0, _GROUP_DEPTH - 1)
        if _GROUP_DEPTH == 0:
            dirty = bool(_GROUP_DIRTY)
            _GROUP_DIRTY = False
            try:
                record_settings_change(context, push=False, force=dirty)
            except Exception:
                pass


def initialize_snapshot(context=None, *, force: bool = False) -> bool:
    return _write_scene_snapshot(context, force=force)


def _apply_snapshot_text(text: str | None, context=None) -> bool:
    global _APPLY_LOCK, _LAST_APPLIED_TEXT
    if not text:
        return False
    if _LAST_APPLIED_TEXT and _same_snapshot_text(_LAST_APPLIED_TEXT, text):
        return False
    data = _read_text_as_data(text)
    if not data:
        return False
    _APPLY_LOCK += 1
    try:
        try:
            from . import settings
            apply_fn = getattr(settings, 'apply_settings_data', None)
            if callable(apply_fn):
                apply_fn(data, context or getattr(bpy, 'context', None), update_last_saved=False)
            else:
                return False
        except Exception:
            return False
        _LAST_APPLIED_TEXT = str(text or '')
        return True
    finally:
        _APPLY_LOCK = max(0, _APPLY_LOCK - 1)


def _apply_current_scene_snapshot(context=None) -> bool:
    scn = _scene(context)
    if scn is None:
        return False
    try:
        text = str(getattr(scn, _SCENE_SNAPSHOT_PROP, '') or '')
    except Exception:
        text = ''
    return _apply_snapshot_text(text, context)


def _invalidate_prop_heatmap_sync_baseline() -> None:
    """Reset the preview-ramp sync signatures after Undo/Redo changed bpy.data.

    Undo can revert the preview ColorRamp datablock underneath the module-level
    signature baseline; without this reset the next two-way sync could import a
    stale (possibly machine-grayscale) ramp over the user's palette.
    """
    try:
        from . import preferences
        preferences.clear_prop_heatmap_preview_node()
    except Exception:
        pass


@persistent
def _undo_post_handler(_dummy=None):
    try:
        _invalidate_prop_heatmap_sync_baseline()
        _apply_current_scene_snapshot(getattr(bpy, 'context', None))
    except Exception:
        pass


@persistent
def _redo_post_handler(_dummy=None):
    try:
        _invalidate_prop_heatmap_sync_baseline()
        _apply_current_scene_snapshot(getattr(bpy, 'context', None))
    except Exception:
        pass


def _ensure_handler(collection, handler) -> None:
    try:
        if handler not in collection:
            collection.append(handler)
    except Exception:
        pass


def _remove_handler(collection, handler) -> None:
    try:
        while handler in collection:
            collection.remove(handler)
    except Exception:
        pass


def _operator_changes_state(cls) -> bool:
    try:
        ident = str(getattr(cls, 'bl_idname', '') or '')
        name = str(getattr(cls, '__name__', '') or '')
        if ident in _SKIP_OPERATOR_IDS or name in _SKIP_OPERATOR_NAMES:
            return False
        return callable(getattr(cls, 'execute', None)) or callable(getattr(cls, 'invoke', None))
    except Exception:
        return True


def prepare_operator_class(cls):
    """Attach undo grouping to state-changing Smart Overlay operators.

    Registration sites call this just before bpy.utils.register_class().  It is
    idempotent and intentionally keeps display-only popup/daemon operators out of
    the undo stack.
    """
    if not isinstance(cls, type):
        return cls
    try:
        if not issubclass(cls, bpy.types.Operator):
            return cls
    except Exception:
        return cls
    if not _operator_changes_state(cls):
        return cls
    try:
        options = set(getattr(cls, 'bl_options', set()) or set())
        options.add('UNDO')
        cls.bl_options = options
        if 'REGISTER' in options or 'INTERNAL' not in options:
            options.add('REGISTER')
            cls.bl_options = options
    except Exception:
        pass
    try:
        if not getattr(cls, 'bl_undo_group', ''):
            cls.bl_undo_group = _UNDO_GROUP_NAME
    except Exception:
        pass
    if bool(getattr(cls, '_sos_undo_execute_wrapped', False)):
        return cls
    original_execute = getattr(cls, 'execute', None)
    if callable(original_execute):
        @functools.wraps(original_execute)
        def _sos_execute_with_undo_group(self, context):
            with grouped_settings_change(context):
                return original_execute(self, context)
        try:
            cls.execute = _sos_execute_with_undo_group
            cls._sos_undo_execute_wrapped = True
        except Exception:
            pass
    return cls


def register(context=None) -> None:
    global _REGISTERED
    if _REGISTERED:
        initialize_snapshot(context, force=False)
        return
    try:
        if not hasattr(bpy.types.Scene, _SCENE_SNAPSHOT_PROP):
            setattr(bpy.types.Scene, _SCENE_SNAPSHOT_PROP, bpy.props.StringProperty(
                name='Smart Overlay Undo Snapshot',
                description='Internal Smart Overlay state snapshot used to restore N-panel and integrated tool settings through Blender Undo/Redo.',
                default='',
                options={'HIDDEN'},
            ))
    except Exception:
        pass
    try:
        if not hasattr(bpy.types.Scene, _SCENE_SNAPSHOT_SEQ_PROP):
            setattr(bpy.types.Scene, _SCENE_SNAPSHOT_SEQ_PROP, bpy.props.IntProperty(
                name='Smart Overlay Undo Snapshot Sequence',
                description='Internal Smart Overlay sequence counter for Undo/Redo snapshot updates.',
                default=0,
                options={'HIDDEN'},
            ))
    except Exception:
        pass
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    if handlers is not None:
        _ensure_handler(getattr(handlers, 'undo_post', []), _undo_post_handler)
        _ensure_handler(getattr(handlers, 'redo_post', []), _redo_post_handler)
    _REGISTERED = True
    initialize_snapshot(context, force=True)


def unregister(context=None) -> None:
    global _REGISTERED, _UNDO_PUSH_PENDING, _GROUP_DEPTH, _GROUP_DIRTY, _LAST_APPLIED_TEXT
    _REGISTERED = False
    _UNDO_PUSH_PENDING = False
    _GROUP_DEPTH = 0
    _GROUP_DIRTY = False
    _LAST_APPLIED_TEXT = ''
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    if handlers is not None:
        _remove_handler(getattr(handlers, 'undo_post', []), _undo_post_handler)
        _remove_handler(getattr(handlers, 'redo_post', []), _redo_post_handler)
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and timers.is_registered(_undo_push_timer):
            timers.unregister(_undo_push_timer)
    except Exception:
        pass
    for attr in (_SCENE_SNAPSHOT_PROP, _SCENE_SNAPSHOT_SEQ_PROP):
        try:
            delattr(bpy.types.Scene, attr)
        except Exception:
            pass
