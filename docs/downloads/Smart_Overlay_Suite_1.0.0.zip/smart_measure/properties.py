# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package


import bpy
import logging
from bpy.app.translations import pgettext_iface as _

from . import overlay


def _queue_suite_settings_save(context=None):
    try:
        from .. import settings
        settings.queue_save(context)
    except Exception:
        pass

logger = logging.getLogger(__name__)

# 全局存储每个场景的之前单位系统
previous_unit_system = {}

def update_overlay_wrapper(self, context):
    overlay.update_overlay()
    _queue_suite_settings_save(context)

def on_edge_snap_update_wrapper(self, context):
    _queue_suite_settings_save(context)
    # 如果无法直接导入，可以在这里实现简单的逻辑，但通常最好调用统一的处理器
    # 由于 properties 先被创建，可能需要延迟导入或将回调放在 properties 中
    # 这里我们假设 on_edge_snap_update 可以在 operators 中被访问，
    # 但更合理的是将 on_edge_snap_update 放在 properties.py 或 overlay.py 中
    
    # 将原先在 __init__.py 的 on_edge_snap_update 逻辑搬过来
    overlay.update_overlay()
    # 如果关闭edge_snap，则为所有激活的overlay触发解除吸附动画
    if (not self.edge_snap) and (not getattr(self, "edge_snap_always", False)):
        for ov in overlay.SmartMeasureGridOverlay.overlays.values():
            ov.trigger_unsnap_animation()

def on_edge_snap_always_update_wrapper(self, context):
    _queue_suite_settings_save(context)
    overlay.update_overlay()
    if (not self.edge_snap_always) and (not getattr(self, "edge_snap", False)):
        for ov in overlay.SmartMeasureGridOverlay.overlays.values():
            ov.trigger_unsnap_animation()

class SmartMeasureGridSettings(bpy.types.PropertyGroup):
    follow_scene_units: bpy.props.BoolProperty(
        name="Units",
        description="Automatically follow the scene's unit system for Smart Measure grid-scale labels.",
        default=True,
        update=update_overlay_wrapper
    )

    unit_system: bpy.props.EnumProperty(
        name="Unit System",
        description="Choose the unit system for Smart Measure grid-scale labels.",
        items=[
            ('m', "Meters", "Meters"),
            ('ft', "Feet", "Feet"),
        ],
        default='m',
        update=update_overlay_wrapper
    )

    color: bpy.props.FloatVectorProperty(
        name="Color",
        description="Set the Smart Measure spacing label color used in the 3D View overlay.",
        subtype='COLOR',
        default=(1.0, 1.0, 1.0),
        min=0.0,
        max=1.0,
        update=update_overlay_wrapper
    )
    alpha: bpy.props.FloatProperty(
        name="Alpha",
        description="Adjust the transparency of the Smart Measure spacing labels. Lower values make the overlay less intrusive.",
        default=0.75,
        min=0.0,
        max=1.0,
        subtype='FACTOR',  # 使用进度条样式显示
        update=update_overlay_wrapper
    )
    font_size: bpy.props.IntProperty(
        name="Font Size",
        description="Set the Smart Measure spacing label text size in pixels.",
        default=12,
        min=1,
        update=update_overlay_wrapper
    )
    
    show_x: bpy.props.BoolProperty(
        name="X-axis",
        description="Enable to display X axis Smart Measure grid-scale labels",
        default=True,
        update=update_overlay_wrapper
    )
    
    show_y: bpy.props.BoolProperty(
        name="Y-axis",
        description="Enable to display Y axis Smart Measure grid-scale labels",
        default=True,
        update=update_overlay_wrapper
    )
    
    show_z: bpy.props.BoolProperty(
        name="Z-axis",
        description="Enable to display Z axis Smart Measure grid-scale labels in perspective view.",
        default=False,
        update=update_overlay_wrapper
    )
    
    show_persp: bpy.props.BoolProperty(
        name="view-Pres",
        description="Enable to display Pres view.",
        default=True,
        update=update_overlay_wrapper
    )

    show_ortho: bpy.props.BoolProperty(
        name="view-Orth",
        description="Enable to display Orth view.",
        default=True,
        update=update_overlay_wrapper
    )
    
    edge_snap: bpy.props.BoolProperty(
        name="Edge Snap",
        description="In ortho views, snap annotations to the edge when off-screen",
        default=True,
        update=on_edge_snap_update_wrapper
    )

    edge_snap_always: bpy.props.BoolProperty(
        name="Always Snap To Edge",
        description="In ortho views, always snap annotations to the edge",
        default=False,
        update=on_edge_snap_always_update_wrapper
    )
    
    edge_snap_margin_top: bpy.props.IntProperty(
        name="Top",
        description="Top edge snap margin in pixels",
        default=90,
        min=0, max=1000,
        update=update_overlay_wrapper
    )
    edge_snap_margin_bottom: bpy.props.IntProperty(
        name="Bottom",
        description="Bottom edge snap margin in pixels",
        default=45,
        min=0, max=1000,
        update=update_overlay_wrapper
    )
    edge_snap_margin_left: bpy.props.IntProperty(
        name="Left",
        description="Left edge snap margin in pixels",
        default=45,
        min=0, max=1000,
        update=update_overlay_wrapper
    )
    edge_snap_margin_right: bpy.props.IntProperty(
        name="Right",
        description="Right edge snap margin in pixels",
        default=90,
        min=0, max=1000,
        update=update_overlay_wrapper
    )
    
    text_shadow: bpy.props.BoolProperty(
        name="Text Shadow",
        description="Add shadow to text for better readability on any background",
        default=True,
        update=update_overlay_wrapper
    )
    
    auto_color: bpy.props.FloatProperty(
        name="Axis Color",
        description="Mix between custom color (0.0) and axis color (1.0)",
        default=0.0,
        min=0.0,
        max=1.0,
        subtype='FACTOR',  # 使用进度条样式显示
        update=update_overlay_wrapper
    )
    
    max_annotations: bpy.props.IntProperty(
        name="Max Annotations",
        description="Maximum number of annotations to display (improves performance)",
        default=300,
        min=10,
        max=1000,
        update=update_overlay_wrapper
    )
    
    animation_style: bpy.props.EnumProperty(
        name="Animation",
        description="Select label transition style: 1=Fade, 2=Slide+Fade, 3=Scale+Fade",
        items=[
            ('1', "1", "Fade"),
            ('2', "2", "Slide+Fade"),
            ('3', "3", "Scale+Fade"),
        ],
        default='2',
        update=update_overlay_wrapper
    )

    unit_display_mode: bpy.props.EnumProperty(
        name="Display Unit",
        description="Force a specific unit or use auto-scaling",
        items=[
            ('AUTO', "Auto", "Automatic scaling"),
            ('MM', "Millimeters (mm)", "Force Millimeters"),
            ('CM', "Centimeters (cm)", "Force Centimeters"),
            ('M', "Meters (m)", "Force Meters"),
            ('KM', "Kilometers (km)", "Force Kilometers"),
            ('IN', "Inches", "Force Inches"),
            ('FT', "Feet (ft)", "Force Feet"),
        ],
        default='AUTO',
        update=update_overlay_wrapper
    )
    
    # 添加一个字符串属性来存储已激活的视口ID
    active_areas: bpy.props.StringProperty(
        name="Active Areas",
        description="Stores IDs of areas with active Smart Measure grid-scale overlays",
        default="",
        options={'HIDDEN'}  # 在UI中隐藏此属性
    )

    use_manual_origin: bpy.props.BoolProperty(
        name="Manual Origin",
        description="Use a manual origin point for Smart Measure grid-scale labels instead of (0,0,0)",
        default=False,
        update=update_overlay_wrapper
    )

    manual_origin_location: bpy.props.FloatVectorProperty(
        name="Origin",
        description="Manual origin location",
        subtype='TRANSLATION',
        default=(0.0, 0.0, 0.0),
        update=update_overlay_wrapper
    )

def unit_system_update_handler(scene):
    """
    处理场景单位系统变化的处理器。
    如果`follow_scene_units`启用，自动同步插件单位系统。
    """
    global previous_unit_system
    current_system = scene.unit_settings.system
    scene_pointer = scene.as_pointer()
    
    # 初始化之前的单位系统
    if scene_pointer not in previous_unit_system:
        previous_unit_system[scene_pointer] = current_system
    
    # 检查单位系统是否变化
    if previous_unit_system[scene_pointer] != current_system:
        previous_unit_system[scene_pointer] = current_system
        settings = getattr(scene, 'smart_measure_grid', None)
        if settings is None:
            return
        if settings.follow_scene_units:
            # 自动同步插件的单位系统
            if current_system == 'IMPERIAL':
                settings.unit_system = 'ft'
                logger.info(f"Switched to imperial units (feet)")
            else:
                settings.unit_system = 'm'
                logger.info(f"Switched to metric units (meters)")
            logger.info(f"Auto-synced smart_measure_grid_unit_system to '{settings.unit_system}' based on scene unit system '{current_system}'.")
            overlay.update_overlay()
