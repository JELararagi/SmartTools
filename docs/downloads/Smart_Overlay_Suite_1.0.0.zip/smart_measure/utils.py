# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Projection and label formatting for the viewport ruler."""

from itertools import product

import bpy
from bpy_extras.view3d_utils import region_2d_to_vector_3d
from mathutils import Vector

_METRIC_LENGTH = {
    "MILLIMETERS": "MM", "CENTIMETERS": "CM", "METERS": "M", "KILOMETERS": "KM",
}
_AXIS_NAMES = (("RIGHT", "LEFT"), ("BACK", "FRONT"), ("TOP", "BOTTOM"))


def get_stable_area_id(area):
    match = next(((screen.name, index) for screen in bpy.data.screens
                  for index, candidate in enumerate(screen.areas) if candidate == area), None)
    return f"{match[0]}:{area.type}:{match[1]}" if match else f"temp:{area.as_pointer()}"


def smooth_value(current, last, memory_factor):
    return current if last is None else current + memory_factor * (last - current)


def _clamp01(t):
    return min(1.0, max(t, 0.0))


def _ease_smootherstep(t):
    fraction = _clamp01(t)
    return fraction ** 3 * (10 + fraction * (-15 + 6 * fraction))


def _ease_in_back(t, overshoot=1.1):
    fraction = _clamp01(t)
    return fraction ** 3 - overshoot * fraction ** 2 * (1 - fraction)


def _ease_out_back(t, overshoot=1.1):
    return 1 - _ease_in_back(1 - t, overshoot)


def format_distance(val, unit_system="m", display_mode="AUTO", precision=2):
    mode = display_mode
    if mode == "AUTO":
        scene = bpy.context.scene
        units = getattr(scene, "unit_settings", None)
        mode = _METRIC_LENGTH.get(getattr(units, "length_unit", None), "AUTO")
    magnitude = abs(val)
    if unit_system != "m":
        inches = mode == "IN" or (mode != "FT" and magnitude < 0.3048)
        return f'{val * 39.3701:.1f}"' if inches else f"{val * 3.28084:.1f}'"
    if mode == "MM":
        return f"{1000 * val:.0f}mm"
    if mode == "CM":
        places = int(magnitude < 0.1)
        return f"{100 * val:.{places}f}cm"
    if mode == "KM":
        return f"{val / 1000:.{precision}f}km"
    if mode != "M":
        if magnitude == 0:
            return "0m"
        if magnitude < .01:
            return f"{1000 * val:.0f}mm"
        if magnitude < 1:
            return f"{100 * val:.0f}cm"
        if magnitude >= 1000:
            return f"{val / 1000:.1f}km"
    return f"{val:.{precision}f}m"


def _bounds(points):
    return {f"{bound}_{axis}": extract(point[index] for point in points)
            for index, axis in enumerate("xyz") for bound, extract in (("min", min), ("max", max))}


def get_view_bounds(region, rv3d):
    observer = rv3d.view_matrix.inverted().translation
    depth = rv3d.view_distance * 10
    screen_corners = product((0, region.width), (0, region.height))
    points = [observer]
    points.extend(observer + depth * region_2d_to_vector_3d(region, rv3d, corner)
                  for corner in screen_corners)
    return _bounds(points)


def get_ortho_view_bounds(region, rv3d):
    center = rv3d.view_matrix.inverted().translation
    aspect = region.width / region.height if region.height > 0 else 1
    height = rv3d.view_distance
    return _bounds([center + rv3d.view_rotation @ Vector((x * aspect * height, y * height, 0))
                    for x, y in product((-1, 1), repeat=2)])


def _get_orientation_from_rotation(rotation):
    normal = (rotation @ Vector((0, 0, -1))).normalized()
    axis = max(range(3), key=lambda i: abs(normal[i]))
    if abs(normal[axis]) > .9:
        return _AXIS_NAMES[axis][normal[axis] > 0]
    return "USER"


def get_view_orientation(rv3d):
    return _get_orientation_from_rotation(rv3d.view_rotation)
