# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import math as _math
import logging
import re

import bpy
# noinspection PyUnresolvedReferences
import blf
from blf import ROTATION
from math import fabs, degrees, radians, sqrt, cos, sin, pi
from mathutils import Vector, Matrix, Quaternion
from bmesh import from_edit_mesh
from bpy_extras import view3d_utils
from mathutils.geometry import tessellate_polygon
import bpy_extras.object_utils as object_utils
# GPU
import gpu
from gpu_extras.batch import batch_for_shader

_LOG = logging.getLogger(__name__)

shader = gpu.shader.from_builtin('UNIFORM_COLOR') if not bpy.app.background else None
shader_line = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR') if not bpy.app.background else None

imm_line_width = 1.0
imm_viewport = (0, 0)

def imm_set_line_width(width):
    global imm_line_width, imm_viewport
    imm_viewport = tuple(gpu.state.viewport_get()[2:])

    imm_line_width = width

def _vertex_at(obj, index, vertices=None):
    if vertices is None:
        vertices = get_mesh_vertices(obj)
    if not 0 <= index < len(vertices):
        raise IndexError(index)
    if hasattr(vertices, 'ensure_lookup_table'):
        vertices.ensure_lookup_table()
    return vertices[index].co


def _world_vertex(obj, index, vertices=None):
    return Vector(get_point(_vertex_at(obj, index, vertices), obj))


def _origin(obj):
    return Vector(get_location(obj))


def _measurement_pair(obj, item, vertices=None):
    kind = item.gltype
    if kind == 1:
        return (_world_vertex(obj, item.glpointa, vertices),
                _world_vertex(obj, item.glpointb, vertices))
    if kind == 2:
        anchor = _world_vertex(obj, item.glpointa, vertices)
        return anchor, anchor
    if kind in (12, 13, 14):
        local = _vertex_at(obj, item.glpointa, vertices)
        on_plane = local.copy()
        on_plane[kind - 12] = 0.0
        return Vector(get_point(local, obj)), Vector(get_point(on_plane, obj))
    if kind in (3, 4, 5, 8):
        linked = bpy.data.objects.get(item.gllink)
        if linked is None or (kind in (3, 5) and linked.type != 'MESH'):
            return None
        start = _world_vertex(obj, item.glpointa, vertices) if kind in (3, 4) else _origin(obj)
        end = _world_vertex(linked, item.glpointb) if kind in (3, 5) else _origin(linked)
        return start, end
    if kind in (6, 7):
        target = _world_vertex(obj, item.glpointa, vertices) if kind == 6 else _origin(obj)
        return Vector((0.0, 0.0, 0.0)), target
    if kind in (10, 20):
        origin = _origin(obj)
        return origin, origin
    return None


def _three_vertices(obj, item):
    vertices = get_mesh_vertices(obj)
    return tuple(_world_vertex(obj, index, vertices)
                 for index in (item.glpointa, item.glpointb, item.glpointc))


def _arc_construction(points):
    start, middle, last = points
    u, v = middle - start, last - start
    normal = u.cross(v)
    weight = 2.0 * normal.length_squared
    if not weight:
        return None
    # Solve equal squared distances to the three points in the plane of the arc.
    delta = (v.cross(normal) * u.length_squared + normal.cross(u) * v.length_squared) / weight
    center = start + delta
    angle, length = get_arc_data(start, center, middle, last)
    return center, normal.normalized(), angle, length


def _draw_arc_lines(item, region, rv3d, center, start, sweep, axis, color):
    angle = _math.tau if item.glarc_full else sweep
    ray = start - center
    if not axis.length_squared or not ray.length_squared:
        return

    radial = ray.normalized() * item.glspace
    partitions = 36
    world = []
    screen = []
    for step in range(partitions + 1):
        transform = Quaternion(axis, angle * step / partitions)
        world.append(center + transform @ ray)
        screen.append(get_2d_point(region, rv3d, center + transform @ (ray + radial)))

    for step, (before, after) in enumerate(zip(screen, screen[1:])):
        if step == 0:
            draw_arrow(before, after, color, item.glarc_s, item.glarc_a, '99')
        elif step == partitions - 1:
            draw_arrow(before, after, color, item.glarc_s, '99', item.glarc_b)
        else:
            draw_line(before, after, color)
    if not item.glarc_full:
        for index in (0, -1):
            draw_line(screen[index], get_2d_point(region, rv3d, world[index]), color)


class _MeasurePainter:
    def __init__(self, context, obj, region, rv3d):
        self.obj = obj
        self.scene = context.scene
        self.region = region
        self.view = rv3d
        self.units = self.scene.smart_measure_units
        self.format = f'%1.{self.scene.smart_measure_gl_precision}f'
        self.world_scale = self.scene.unit_settings.scale_length
        self.model_scale = self.scene.smart_measure_scale_factor if self.scene.smart_measure_scale else 1.0

    def project(self, point):
        return get_2d_point(self.region, self.view, point)

    def line(self, first, last):
        draw_line(self.project(first), self.project(last), self.color)

    def arrow(self, first, last):
        draw_arrow(self.project(first), self.project(last), self.color, *self.arrow_style)

    def style(self, item):
        scene = self.scene
        if scene.smart_measure_ovr:
            self.color = scene.smart_measure_ovr_color
            self.size = scene.smart_measure_ovr_font
            self.align = scene.smart_measure_ovr_font_align
            self.rotate = get_angle_in_rad(scene.smart_measure_ovr_font_rotation)
            width = scene.smart_measure_ovr_width
        else:
            self.color = item.glcolor
            self.size = item.glfont_size
            self.align = item.glfont_align
            self.rotate = get_angle_in_rad(item.glfont_rotat)
            width = item.glwidth
        self.arrow_style = (item.glarrow_s, item.glarrow_a, item.glarrow_b)
        imm_set_line_width(width)

    def show_distance(self, item):
        return self.scene.smart_measure_gl_show_d and item.gldist

    def combined_text(self, item, reading):
        name = item.gltxt if self.scene.smart_measure_gl_show_n and item.glnames else ''
        return (reading + ' ' if self.show_distance(item) else ' ') + name

    def show_any_text(self):
        return self.scene.smart_measure_gl_show_d or self.scene.smart_measure_gl_show_n

    def measurement(self, value, power=1):
        return format_distance(self.format, self.units, value, power)

    def angle_text(self, value):
        if self.scene.unit_settings.system_rotation == 'DEGREES':
            return (self.format % degrees(value)) + '°'
        return self.format % value

    def note(self, item, point, text, color=None):
        location = self.project(point)
        if location is not None:
            position = location[0] + item.glfontx, location[1] + item.glfonty
            draw_text(self.obj, position, text, self.color if color is None else color,
                      self.size, self.align, self.rotate)

    def scale_note(self, context):
        scene = self.scene
        translation = bpy.app.translations.pgettext_iface
        title = scene.smart_measure_gl_scaletxt or translation("Scale:")
        ratio = f'{scene.smart_measure_scale_factor:.{scene.smart_measure_scale_precision}f}'
        draw_text(self.obj, get_scale_txt_location(context), f'{title} 1:{ratio}',
                  scene.smart_measure_scale_color, scene.smart_measure_scale_font,
                  text_rot=get_angle_in_rad(scene.smart_measure_font_rotation))

    def draw_item(self, item):
        kind = item.gltype
        if kind == 20:
            self.face_area(item)
        elif kind in (9, 11):
            points = _three_vertices(self.obj, item)
            if kind == 9:
                self.vertex_angle(item, points)
            else:
                self.circular_arc(item, points)
        else:
            ends = _measurement_pair(self.obj, item)
            if ends is not None:
                if kind == 2:
                    self.vertex_label(item, ends[0])
                elif kind == 10:
                    self.note(item, ends[0], item.gltxt)
                else:
                    self.linear(item, *ends)

    def gaps(self, item, first, last):
        if item.gldefault:
            direction = (first + last) / 2 - _origin(self.obj)
        else:
            direction = Vector((item.glnormalx, item.glnormaly, item.glnormalz))
        direction.normalize()
        tick = .07 if item.glspace >= .07 else item.glspace / 5
        gap = direction * item.glspace
        tail = direction * (item.glspace + tick)
        return gap, tail, tick

    def linear(self, item, first, last):
        gap, tail, tick = self.gaps(item, first, last)
        anchors = (first + gap, last + gap)
        tick_ends = (first + tail, last + tail)
        masks = (item.glocx, item.glocy, item.glocz)
        full, shown = distance(first, last, *masks)
        is_dimension = item.gltype in (1, 12, 13, 14)
        if item.gltype == 1 and item.glorto in ('0', '1'):
            target = int(item.glorto)
            other = 1 - target
            for axis, locked in enumerate((item.glorto_x, item.glorto_y, item.glorto_z)):
                if locked:
                    anchors[target][axis] = anchors[other][axis]
                    tick_ends[target][axis] = tick_ends[other][axis]

        note_point = Vector(interpolate3d(*anchors, full / 2))
        note_point.z += tick / 2
        note_shown = self.project(note_point) is not None
        if note_shown and self.show_any_text():
            reading = self.measurement(shown * self.world_scale * self.model_scale)
            self.note(item, note_point, self.combined_text(item, reading))
        if note_shown and full != shown and item.glocwarning:
            axes = ''.join(name for name, enabled in zip('XYZ', masks) if enabled)
            draw_text(self.obj, self.project(anchors[1]), f'[{axes}]',
                      self.color, self.size - 1, text_rot=self.rotate)

        if is_dimension:
            self.line(first, tick_ends[0])
            self.line(last, tick_ends[1])
            self.arrow(*anchors)
        else:
            self.arrow(first, last)

    def vertex_label(self, item, anchor):
        _gap, tail, tick = self.gaps(item, anchor, anchor)
        end = anchor + tail
        upper = end + Vector((0, 0, tick / 30))
        lower = end - Vector((0, 0, tick / 40))
        self.note(item, upper, item.gltxt)
        self.line(upper, lower)
        self.arrow(anchor, end)

    def vertex_angle(self, item, points):
        first, apex, last = points
        ray_a, ray_b = first - apex, last - apex
        if ray_a.length_squared and ray_b.length_squared:
            name = ' ' + item.gltxt if self.scene.smart_measure_gl_show_n else ''
            self.note(item, apex, ' ' + self.angle_text(ray_a.angle(ray_b)) + name)
        a, b = apex + ray_a / 11, apex + ray_b / 11
        self.line(a, apex)
        self.line(apex, b)
        self.line(a, b)

    def circular_arc(self, item, points):
        arc = _arc_construction(points)
        if arc is None:
            return
        center, axis, sweep, arc_length = arc
        radial = points[1] - center
        outer = points[1] + radial.normalized() * item.glspace
        ratio = self.scene.smart_measure_scale_factor * self.world_scale
        if self.show_any_text():
            reading = item.glarc_txlen + self.measurement(arc_length * ratio) if item.glarc_len else ' '
            if item.glarc_ang:
                reading += ' ' + item.glarc_txang + self.angle_text(sweep)
            self.note(item, outer, self.combined_text(item, reading))
        if item.glarc_rad:
            if self.show_distance(item):
                radius = distance(center, points[1])[0]
                self.note(item, center, item.glarc_txradio + self.measurement(radius * ratio))
            self.arrow(center, outer if item.glarc_extrad else points[1])
        if not item.gldefault:
            axis = Vector((item.glnormalx, item.glnormaly, item.glnormalz)).normalized()
        _draw_arc_lines(item, self.region, self.view, center, points[0], sweep, axis, self.color)

    def face_area(self, item):
        if not item.smart_measure_faces:
            return
        vertices = get_mesh_vertices(self.obj)
        if hasattr(vertices, 'ensure_lookup_table'):
            vertices.ensure_lookup_table()
        area = 0.0
        center = None
        for face in item.smart_measure_faces:
            indices = tuple(point.glidx for point in face.smart_measure_index)
            if len(indices) < 3:
                continue
            if center is None:
                first = _world_vertex(self.obj, indices[0], vertices)
                diagonal = _world_vertex(self.obj, indices[2], vertices)
                center = (first + diagonal) / 2
            area += get_area_and_paint(indices, self.obj, vertices, self.region, self.view,
                                      self.color, self.model_scale)
        if center is not None and self.show_any_text():
            reading = self.measurement(area * self.world_scale, 2)
            self.note(item, center, self.combined_text(item, reading), item.glcolorarea)


def draw_segments(context, myobj, op, region, rv3d):
    """Draw saved measurement items without sharing endpoint state between them."""
    if op.smart_measure_num <= 0:
        return
    painter = _MeasurePainter(context, myobj, region, rv3d)
    if painter.scene.smart_measure_scale:
        painter.scale_note(context)
    for index, item in enumerate(op.smart_measure_segments):
        if index >= op.smart_measure_num:
            break
        if item.glfree or not item.glview:
            continue
        try:
            painter.style(item)
            gpu.state.blend_set('ALPHA')
            painter.draw_item(item)
        except IndexError:
            item.glfree = True
        except Exception:
            _LOG.exception("Unexpected error in Smart Measure geometry")


def get_area_and_paint(myvertices, myobj, obverts, region, rv3d, rgba, ms_scale):
    """Measure a face in scene units and paint its visible triangles."""
    if len(myvertices) < 3:
        return 0.0

    local = [Vector(obverts[index].co) for index in myvertices]
    triangles = ((0, 1, 2),) if len(local) == 3 else tessellate_polygon([local])
    world = [get_point(vertex, myobj) for vertex in local]
    pixels_by_vertex = [get_2d_point(region, rv3d, vertex) for vertex in world]
    area = 0.0
    for triangle in triangles:
        area += get_triangle_area(*(world[index] for index in triangle), scale=ms_scale)
        pixels = tuple(pixels_by_vertex[index] for index in triangle)
        if all(point is not None for point in pixels):
            draw_triangle(*pixels, rgba)
    return area * bpy.context.scene.unit_settings.scale_length


def _coordinate_delta(start, end):
    return tuple(end[axis] - start[axis] for axis in range(3))


def get_triangle_area(p1, p2, p3, scale=1.0):
    """Return the area of a 3D triangle after applying a uniform scale."""
    ax, ay, az = _coordinate_delta(p1, p2)
    bx, by, bz = _coordinate_delta(p1, p3)
    doubled_area = _math.hypot(ay * bz - az * by, az * bx - ax * bz, ax * by - ay * bx)
    return doubled_area * (0.5 * scale * scale)


def get_2d_point(region, rv3d, point3d):
    """Project into a viewport, or into the camera render when no viewport is supplied."""
    project = view3d_utils.location_3d_to_region_2d
    if region is None or rv3d is None:
        return get_render_location(point3d)
    return project(region, rv3d, point3d)


def _group_segment_length(obj, segment, vertices):
    try:
        start, end = _measurement_pair(obj, segment, vertices)
    except IndexError:
        return None
    return distance(start, end, segment.glocx, segment.glocy, segment.glocz)[1]


def collect_group_lengths(obj, container, scale):
    """Return existing subtotal groups, including groups with a measured zero length."""
    vertices = get_mesh_vertices(obj)
    totals = {}
    for index, segment in enumerate(container.smart_measure_segments):
        if index >= container.smart_measure_num:
            break
        if segment.glfree or segment.gltype not in (1, 12, 13, 14) or segment.gltot == '99':
            continue
        group = int(segment.gltot)
        if not 0 <= group < 26:
            continue
        length = _group_segment_length(obj, segment, vertices)
        if length is not None:
            label = chr(ord('A') + group)
            totals[label] = totals.get(label, 0.0) + scale * length
    return totals


def get_group_sum(myobj, tag):
    """Resolve the label token <#A> through <#Z> using the panel's subtotal calculation."""
    if not re.fullmatch(r'<#[A-Z]>', tag, re.IGNORECASE | re.ASCII):
        return ' '
    collection = myobj.SmartMeasureGenerator
    if not collection:
        return ' '
    scene = bpy.context.scene
    total = collect_group_lengths(myobj, collection[0], scene.unit_settings.scale_length).get(tag[2].upper())
    if total is None:
        return ' '
    return format_distance(f'%1.{scene.smart_measure_gl_precision}f', scene.smart_measure_units, total)


def _expand_group_labels(obj, label):
    values = {}

    def replace_group(match):
        tag = match.group().upper()
        if tag not in values:
            values[tag] = get_group_sum(obj, tag)
        return values[tag]

    return re.sub(r'<#[A-Z]>', replace_group, label, flags=re.IGNORECASE | re.ASCII)


def draw_text(myobj, pos2d, display_text, rgba, fsize, align='L', text_rot=0.0):
    """Draw an optionally rotating label with pipe-delimited lines and subtotal tokens."""
    if pos2d is None:
        return None
    font = 0
    scale = bpy.context.preferences.system.ui_scale
    blf.size(font, round(fsize * scale))
    blf.color(font, *rgba)
    line_height = blf.dimensions(font, 'Tp')[1]
    lines = _expand_group_labels(myobj, display_text).split('|')
    widths = [blf.dimensions(font, line)[0] for line in lines]
    rotate = align not in ('C', 'R')
    x, y = pos2d
    if rotate:
        blf.enable(font, ROTATION)
    try:
        if rotate:
            blf.rotation(font, text_rot)
        for row, (line, width) in enumerate(zip(lines, widths), start=1):
            shift = width / 2 if align == 'C' else width + 12 if align == 'R' else 0
            blf.position(font, x - shift, y + line_height * (len(lines) - row), 0)
            blf.draw(font, ' ' + line)
    finally:
        if rotate:
            blf.disable(font, ROTATION)
    return max(widths), len(lines) * line_height


def _stroke_lines(points, color, primitive='LINES'):
    if shader_line is None or any(point is None for point in points):
        return
    coords = [(point[0], point[1], 0.0) for point in points]
    batch = batch_for_shader(shader_line, primitive, {'pos': coords})
    shader_line.bind()
    shader_line.uniform_float('viewportSize', imm_viewport)
    shader_line.uniform_float('lineWidth', imm_line_width)
    shader_line.uniform_float('color', color)
    batch.draw(shader_line)


def draw_line(v1, v2, rgba):
    _stroke_lines((v1, v2), rgba)


def draw_triangle(v1, v2, v3, rgba):
    if shader is None or any(point is None for point in (v1, v2, v3)):
        return
    batch = batch_for_shader(shader, 'TRIS', {'pos': [tuple(point[:2]) for point in (v1, v2, v3)]})
    shader.bind()
    shader.uniform_float('color', rgba)
    batch.draw(shader)


def _draw_arrowhead(tip, ux, uy, style, size, color):
    if style not in ('1', '2', '3'):
        return
    if style == '3':
        back, span = 0.0, size
    else:
        back = span = size / _math.sqrt(2.0)
    x, y = tip[0] + back * ux, tip[1] + back * uy
    wing1 = x - span * uy, y + span * ux
    wing2 = x + span * uy, y - span * ux
    if style == '2':
        draw_triangle(tip, wing1, wing2, color)
    else:
        _stroke_lines((tip, wing1, tip, wing2), color)


def draw_arrow(v1, v2, rgba, size=20, a_typ='1', b_typ='1'):
    """Draw a shaft with independent open, solid, perpendicular, or absent endpoints."""
    if v1 is None or v2 is None:
        return
    dx, dy = v2[0] - v1[0], v2[1] - v1[1]
    length = _math.hypot(dx, dy)
    if length == 0.0:
        return
    ux, uy = dx / length, dy / length
    _draw_arrowhead(v1, ux, uy, a_typ, size, rgba)
    _draw_arrowhead(v2, -ux, -uy, b_typ, size, rgba)
    draw_line(v1, v2, rgba)


def draw_rectangle(v1, v2, rgba):
    if v1 is None or v2 is None:
        return
    x1, y1 = v1
    x2, y2 = v2
    _stroke_lines(((x1, y1), (x2, y1), (x2, y2), (x1, y2), (x1, y1)), rgba, 'LINE_STRIP')


# -------------------------------------------------------------
# format a point as (x, y, z) for display
#
# -------------------------------------------------------------
def format_point(mypoint, pr):
    coordinates = (format(mypoint[axis], f'.{pr}f') for axis in range(3))
    return ' (' + ', '.join(coordinates) + ')'


# -------------------------------------------------------------
# Draw object num for debug
#
# -------------------------------------------------------------
# noinspection PyUnresolvedReferences,PyUnboundLocalVariable,PyUnusedLocal
def draw_object(context, myobj, region, rv3d):
    scene = bpy.context.scene
    rgba = scene.smart_measure_debug_obj_color
    fsize = scene.smart_measure_debug_font
    precision = scene.smart_measure_debug_precision
    # --------------------
    # object Loop
    # --------------------
    objs = bpy.context.scene.objects
    obidxs = list(range(len(bpy.context.scene.objects)))
    for o in obidxs:
        # Display only selected
        if scene.smart_measure_debug_select is True:
            if objs[o].select_get() is False:
                continue
        a_p1 = Vector(get_location(objs[o]))
        # Text
        txt = ''
        if scene.smart_measure_debug_objects is True:
            txt += str(o)
        if scene.smart_measure_debug_object_loc is True:
            txt += format_point(a_p1, precision)
        # converting to screen coordinates
        txtpoint2d = get_2d_point(region, rv3d, a_p1)
        draw_text(myobj, txtpoint2d, txt, rgba, fsize)
    return


# -------------------------------------------------------------
# Draw vertex num for debug
#
# -------------------------------------------------------------
# noinspection PyUnresolvedReferences,PyUnboundLocalVariable,PyUnusedLocal
def draw_vertices(context, myobj, region, rv3d):
    # Only meshes
    if myobj.type != "MESH":
        return

    scene = bpy.context.scene
    rgba = scene.smart_measure_debug_vert_color
    fsize = scene.smart_measure_debug_font
    precision = scene.smart_measure_debug_precision
    # --------------------
    # vertex Loop
    # --------------------
    if scene.smart_measure_debug_vert_loc_toggle == '1':
        co_mult = lambda c: c
    else:  # if global, convert local c to global
        co_mult = lambda c: myobj.matrix_world @ c

    if myobj.mode == 'EDIT':
        bm = from_edit_mesh(myobj.data)
        obverts = bm.verts
    else:
        obverts = myobj.data.vertices

    for v in obverts:
        # Display only selected
        if scene.smart_measure_debug_select is True:
            if v.select is False:
                continue
        # noinspection PyBroadException
        # try:
        a_p1 = get_point(v.co, myobj)
        # converting to screen coordinates
        txtpoint2d = get_2d_point(region, rv3d, a_p1)
        # Text
        txt = ''
        if scene.smart_measure_debug_vertices is True:
            txt += str(v.index)
        if scene.smart_measure_debug_vert_loc is True:
            txt += format_point(co_mult(v.co), precision)
        draw_text(myobj, txtpoint2d, txt, rgba, fsize)
        #     _LOG.exception("Unexpected error in Smart Measure geometry")
        #     pass

    return


# -------------------------------------------------------------
# Draw edge num for debug
#
# -------------------------------------------------------------
# noinspection PyUnresolvedReferences,PyUnboundLocalVariable,PyUnusedLocal
def draw_edges(context, myobj, region, rv3d):
    # Only meshes
    if myobj.type != "MESH":
        return

    scene = bpy.context.scene
    rgba = scene.smart_measure_debug_edge_color
    fsize = scene.smart_measure_debug_font
    precision = scene.smart_measure_debug_precision
    # --------------------
    # edge Loop
    #
    # uses lambda for edge midpoint finder (midf) because edit mode
    # edge vert coordinate is not stored in same places as in obj mode
    # --------------------
    if myobj.mode == 'EDIT':
        bm = from_edit_mesh(myobj.data)
        obedges = bm.edges
        obverts = None  # dummy value to avoid duplicating for loop
        midf = lambda e, v: e.verts[0].co.lerp(e.verts[1].co, 0.5)
    else:
        obedges = myobj.data.edges
        obverts = myobj.data.vertices
        midf = lambda e, v: v[e.vertices[0]].co.lerp(v[e.vertices[1]].co, 0.5)

    for e in obedges:
        # Display only selected
        if scene.smart_measure_debug_select is True:
            if e.select is False:
                continue
        a_mp = midf(e, obverts)
        a_p1 = get_point(a_mp, myobj)
        # converting to screen coordinates
        txtpoint2d = get_2d_point(region, rv3d, a_p1)
        draw_text(myobj, txtpoint2d, str(e.index), rgba, fsize)
    return


# -------------------------------------------------------------
# Draw face num for debug
#
# -------------------------------------------------------------
# noinspection PyUnresolvedReferences,PyUnboundLocalVariable,PyUnusedLocal
def draw_faces(context, myobj, region, rv3d):
    # Only meshes
    if myobj.type != "MESH":
        return

    scene = bpy.context.scene
    rgba = scene.smart_measure_debug_face_color
    rgba2 = scene.smart_measure_debug_norm_color
    fsize = scene.smart_measure_debug_font
    ln = scene.smart_measure_debug_normal_size
    th = scene.smart_measure_debug_width
    precision = scene.smart_measure_debug_precision

    # --------------------
    # face Loop
    # --------------------
    if myobj.mode == 'EDIT':
        bm = from_edit_mesh(myobj.data)
        obverts = bm.verts
        myfaces = bm.faces
    else:
        obverts = myobj.data.vertices
        myfaces = myobj.data.polygons

    for f in myfaces:
        normal = f.normal
        # Display only selected
        if scene.smart_measure_debug_select is True:
            if f.select is False:
                continue
        # noinspection PyBroadException
        try:
            if myobj.mode == 'EDIT':
                a_p1 = get_point(f.calc_center_median(), myobj)
            else:
                a_p1 = get_point(f.center, myobj)

            a_p2 = (a_p1[0] + normal[0] * ln, a_p1[1] + normal[1] * ln, a_p1[2] + normal[2] * ln)
            # line setup
            gpu.state.blend_set('ALPHA')
            imm_set_line_width(th)
            # converting to screen coordinates
            txtpoint2d = get_2d_point(region, rv3d, a_p1)
            point2 = get_2d_point(region, rv3d, a_p2)
            # Text
            if scene.smart_measure_debug_faces is True:
                draw_text(myobj, txtpoint2d, str(f.index), rgba, fsize)
            # Draw Normal
            if scene.smart_measure_debug_normals is True:
                gpu.state.blend_set('ALPHA')
                draw_arrow(txtpoint2d, point2, rgba, 10, "99", "1")

                if len(obverts) > 2 and scene.smart_measure_debug_normal_details is True:
                    if myobj.mode == 'EDIT':
                        i1 = f.verts[0].index
                        i2 = f.verts[1].index
                        i3 = f.verts[2].index
                    else:
                        i1 = f.vertices[0]
                        i2 = f.vertices[1]
                        i3 = f.vertices[2]

                    a_p1 = get_point(obverts[i1].co, myobj)
                    a_p2 = get_point(obverts[i2].co, myobj)
                    a_p3 = get_point(obverts[i3].co, myobj)
                    # converting to screen coordinates
                    a2d = get_2d_point(region, rv3d, a_p1)
                    b2d = get_2d_point(region, rv3d, a_p2)
                    c2d = get_2d_point(region, rv3d, a_p3)
                    # draw vectors
                    draw_arrow(a2d, b2d, rgba, 10, "99", "1")
                    draw_arrow(b2d, c2d, rgba, 10, "99", "1")
                    # Normal vector data
                    txt = format_point(normal, precision)
                    draw_text(myobj, point2, txt, rgba2, fsize)

        except Exception:
            _LOG.exception("Unexpected error in Smart Measure geometry")

    return


# --------------------------------------------------------------------
# Distance between 2 points in 3D space
# v1: first point
# v2: second point
# locx/y/z: Use this axis
# return: distance
# --------------------------------------------------------------------
def distance(v1, v2, locx=True, locy=True, locz=True):
    """Return both the full separation and the separation on enabled axes."""
    offsets = _coordinate_delta(v1, v2)
    selected = (offset for offset, enabled in zip(offsets, (locx, locy, locz))
                if enabled is not False)
    return _math.hypot(*offsets), _math.hypot(*selected)


# --------------------------------------------------------------------
# Interpolate 2 points in 3D space
# v1: first point
# v2: second point
# d1: distance
# return: interpolate point
# --------------------------------------------------------------------
def interpolate3d(v1, v2, d1):
    """Move a signed distance from the first point along the line through both points."""
    direction = _coordinate_delta(v1, v2)
    separation = _math.hypot(*direction)
    if separation == 0:
        return tuple(v1[axis] for axis in range(3))
    proportion = d1 / separation
    return tuple(v1[axis] + component * proportion for axis, component in enumerate(direction))


# --------------------------------------------------------------------
# Get point rotated and relative to parent
# v1: point
# mainobject
# --------------------------------------------------------------------
def get_point(v1, mainobject):
    coordinates = Vector(v1[:3])
    world = mainobject.matrix_world
    return list(world.to_3x3() @ coordinates + world.translation)


# --------------------------------------------------------------------
# Get location in world space
# v1: point
# mainobject
# --------------------------------------------------------------------
def get_location(mainobject):
    return list(mainobject.matrix_world.translation)


# --------------------------------------------------------------------
# Get vertex data
# mainobject
# --------------------------------------------------------------------
def get_mesh_vertices(myobj):
    if getattr(myobj, 'type', None) != 'MESH':
        return None
    return from_edit_mesh(myobj.data).verts if myobj.mode == 'EDIT' else myobj.data.vertices


# --------------------------------------------------------------------
# Get position for scale text
#
# --------------------------------------------------------------------
def get_scale_txt_location(context):
    region = context.region
    x_percent = context.scene.smart_measure_scale_pos_x
    y_percent = context.scene.smart_measure_scale_pos_y
    return (int(region.width * x_percent / 100), int(region.height * y_percent / 100))


# --------------------------------------------------------------------
# Get position in final render image
# (Z < 0 out of camera)
# return 2d position
# --------------------------------------------------------------------
def get_render_location(mypoint):
    scene = bpy.context.scene
    render = scene.render
    projected = object_utils.world_to_camera_view(scene, scene.camera, Vector(mypoint))
    dimensions = (render.resolution_x, render.resolution_y)
    scale = render.resolution_percentage / 100
    return [round(fraction * int(pixels * scale)) for fraction, pixels in zip(projected.xy, dimensions)]


# ---------------------------------------------------------
# Get center of circle base on 3 points
#
# Point a: (x,y,z) arc start
# Point b: (x,y,z) center
# Point c: (x,y,z) midle point in the arc
# Point d: (x,y,z) arc end
# Return:
# ang: angle (radians)
# len: len of arc
#
# ---------------------------------------------------------
def get_arc_data(pointa, pointb, pointc, pointd):
    center = Vector(pointb)
    first, middle, last = (Vector(point) - center for point in (pointa, pointc, pointd))
    sweep = first.angle(middle) + middle.angle(last)
    return sweep, middle.length * sweep


# -------------------------------------------------------------
# Format a number to the right unit
#
# -------------------------------------------------------------
def format_distance(fmt, units, value, factor=1):
    """Format scene measurements in the requested or automatically selected unit."""
    scene = bpy.context.scene
    if units == '1':
        system = scene.unit_settings.system
        if system == 'IMPERIAL':
            units = '5' if round(value * 3.2808399 ** factor, 2) >= 1.0 else '6'
        elif system == 'METRIC':
            rounded = round(value, 2)
            units = '2' if rounded >= 1.0 else '3' if rounded >= 0.01 else '4'

    spec = {
        '2': (1.0, 'm'),
        '3': (100.0, 'cm'),
        '4': (1000.0, 'mm'),
        '5': (3.2808399, 'ft'),
        '6': (39.3700787, 'in'),
    }.get(units)
    if spec is None:
        return fmt % value
    multiplier, symbol = spec
    text = fmt % (value * multiplier ** factor)
    if not scene.smart_measure_hide_units:
        text += f' {symbol}'
    if factor == 2:
        text += '²'
    return text


def get_angle_in_rad(fangle):
    return radians(fangle)
