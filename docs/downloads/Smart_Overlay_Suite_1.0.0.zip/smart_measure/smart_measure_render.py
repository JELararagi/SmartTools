# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Build a transparent Smart Measure image from the active camera's overlays."""

from array import array
import logging
from pathlib import Path

import bpy
from bpy.app.translations import pgettext_iface as _
import gpu
from mathutils import Matrix

from .. import storage
from . import smart_measure_geometry as geometry


__all__ = ("render_main",)
_LOG = logging.getLogger(__name__)
_IMAGE_NAME = "smart_measure_output"


def _draw_debug(context):
    scene = context.scene
    for obj in context.selected_objects:
        if scene.smart_measure_debug_objects or scene.smart_measure_debug_object_loc:
            geometry.draw_object(context, obj, None, None)
        if scene.smart_measure_debug_vertices or scene.smart_measure_debug_vert_loc:
            geometry.draw_vertices(context, obj, None, None)
        if scene.smart_measure_debug_edges:
            geometry.draw_edges(context, obj, None, None)
        if scene.smart_measure_debug_faces or scene.smart_measure_debug_normals:
            geometry.draw_faces(context, obj, None, None)


def _measure_pixels(context, width, height):
    scene = context.scene
    to_clip = Matrix.Translation((-1.0, -1.0, 0.0)) @ Matrix.Diagonal(
        (2.0 / width, 2.0 / height, 1.0, 1.0)
    )
    previous_blend = gpu.state.blend_get()
    target = gpu.types.GPUOffScreen(width, height)
    try:
        with target.bind(), gpu.matrix.push_pop(), gpu.matrix.push_pop_projection():
            framebuffer = gpu.state.active_framebuffer_get()
            framebuffer.clear(color=(0.0, 0.0, 0.0, 0.0))
            gpu.matrix.load_matrix(to_clip)
            gpu.matrix.load_projection_matrix(Matrix.Identity(4))
            for obj in scene.objects:
                measures = getattr(obj, "SmartMeasureGenerator", ())
                if measures and obj.visible_get(view_layer=context.view_layer):
                    geometry.draw_segments(context, obj, measures[0], None, None)
            if scene.smart_measure_debug:
                _draw_debug(context)
            if scene.smart_measure_rf:
                left = scene.smart_measure_rf_border
                bottom = -(-left * height // width)
                geometry.imm_set_line_width(scene.smart_measure_rf_line)
                geometry.draw_rectangle(
                    (left, bottom), (width - left, height - bottom), scene.smart_measure_rf_color
                )
            pixels = framebuffer.read_color(0, 0, width, height, 4, 0, "UBYTE")
            pixels.dimensions = width * height * 4
            return array("f", (channel / 255.0 for channel in pixels))
    finally:
        target.free()
        gpu.state.blend_set(previous_blend)


def _frame_destination(scene):
    filepath = scene.render.filepath
    prefix = "mit_frame"
    folder = None
    if filepath:
        resolved = Path(bpy.path.abspath(filepath))
        if filepath.endswith(("/", "\\")):
            folder = resolved
        else:
            folder = resolved.parent
            prefix = resolved.name
    if folder is not None:
        try:
            folder.mkdir(parents=True, exist_ok=True)
        except OSError:
            folder = None
    if folder is None:
        folder = storage.user_data_dir("render", "smart_measure", create=True)
    return folder / f"{prefix}{scene.frame_current:04d}.png"


def _save_frame(image, scene):
    destination = _frame_destination(scene)
    settings = scene.render.image_settings
    saved_format, saved_mode, saved_depth = (
        settings.file_format, settings.color_mode, settings.color_depth
    )
    try:
        settings.file_format = "PNG"
        settings.color_mode = "RGBA"
        settings.color_depth = "8"
        image.save_render(str(destination), scene=scene)
    finally:
        settings.file_format = saved_format
        settings.color_mode = saved_mode
        settings.color_depth = saved_depth
    _LOG.info("Smart Measure image saved to %s", destination)


def render_main(operator, context, animation=False):
    scene = context.scene
    render = scene.render
    width = max(1, render.resolution_x * render.resolution_percentage // 100)
    height = max(1, render.resolution_y * render.resolution_percentage // 100)
    try:
        pixels = _measure_pixels(context, width, height)
        image = bpy.data.images.get(_IMAGE_NAME)
        if image is None:
            image = bpy.data.images.new(_IMAGE_NAME, width, height, alpha=True)
        elif tuple(image.size) != (width, height):
            image.scale(width, height)
        image.pixels.foreach_set(pixels)
        image.update()
        if animation or scene.smart_measure_render:
            _save_frame(image, scene)
    except (OSError, RuntimeError, ValueError):
        _LOG.exception("Unable to create or save Smart Measure image")
        operator.report({"ERROR"}, _("Smart Measure: Unable to save render image"))
        return False
    return True
