# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import bpy
from bpy.app.translations import pgettext_iface as _
from .. import icons as sos_icons


def _SICON(name: str = '', fallback: str = 'NONE') -> int:
    try:
        return int(sos_icons.icon_value(name, fallback) or 0)
    except Exception:
        return 0


def _icon_kwargs(name: str = '', fallback: str = 'NONE') -> dict:
    try:
        return sos_icons.icon_kwargs(name, fallback)
    except Exception:
        return {'icon': str(fallback or 'NONE')}


def _panel_context_safe(context) -> bool:
    try:
        if context is None or getattr(context, 'scene', None) is None:
            return False
        area = getattr(context, 'area', None)
        if area is not None and getattr(area, 'type', None) != 'VIEW_3D':
            return False
        obj = getattr(context, 'object', None) or getattr(context, 'active_object', None)
        mode = str(getattr(context, 'mode', 'OBJECT') or 'OBJECT')
        if mode != 'OBJECT' and obj is None:
            return False
        return obj is not None
    except Exception:
        return False


class VIEW3D_PT_smart_measure_grid_overlay(bpy.types.Panel):
    """Grid-scale display settings embedded inside the Smart Measure group."""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Overlay'
    bl_label = "Grid Scale Overlay"
    bl_idname = "VIEW3D_PT_smart_measure_grid_overlay"
    bl_order = 100

    @classmethod
    def poll(cls, context):
        return _panel_context_safe(context)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        scene = getattr(context, 'scene', None)
        if scene is None:
            return
        settings = getattr(scene, 'smart_measure_grid', None)
        if settings is None:
            return

        box = layout.box()

        # Font size and color.
        row = box.row()
        row.use_property_split = False
        row.alignment = 'EXPAND'
        split = row.split(factor=0.5)
        col = split.column()
        col.prop(settings, "font_size")
        col = split.column()
        col.prop(settings, "color", text="")

        # Axis color and alpha.
        row = box.row()
        row.use_property_split = False
        row.alignment = 'EXPAND'
        split = row.split(factor=0.5)
        col = split.column()
        col.prop(settings, "auto_color", slider=True)
        col = split.column()
        col.prop(settings, "alpha")

        # Unit and axis controls.
        row = box.row()
        row.use_property_split = False
        row.alignment = 'EXPAND'
        split = row.split(factor=0.25)
        col_left = split.column()
        col_left.prop(settings, "follow_scene_units")
        col_right = split.column()
        sub_row = col_right.row(align=True)
        sub_row.label(text=_("Axes:"))
        sub_row.prop(settings, "show_x", text="X", toggle=True)
        sub_row.prop(settings, "show_y", text="Y", toggle=True)
        sub_row.prop(settings, "show_z", text="Z", toggle=True)
        sub_row.prop(settings, "show_persp", text="", toggle=True, **_icon_kwargs('NONE', 'VIEW_PERSPECTIVE'))
        sub_row.prop(settings, "show_ortho", text="", toggle=True, **_icon_kwargs('grid', 'VIEW_ORTHO'))

        row = box.row()
        row.use_property_split = True
        row.alignment = 'EXPAND'
        row.prop(settings, "unit_display_mode")

        row = box.row()
        row.use_property_split = False
        row.alignment = 'EXPAND'
        split = row.split(factor=0.66)
        col_left = split.row(align=True)
        col_left.prop(settings, "edge_snap", toggle=True, **_icon_kwargs('NONE', 'PINNED'))
        col_left.prop(settings, "edge_snap_always", toggle=True, text=_("Always Snap"), **_icon_kwargs('NONE', 'PINNED'))
        col_right = split.column()
        col_right.prop(settings, "text_shadow", toggle=True, **_icon_kwargs('font', 'FONT_DATA'))

        if settings.edge_snap or settings.edge_snap_always:
            box_margins = box.box()
            box_margins.label(text=_("Edge Snap Margins (px):"))
            split = box_margins.split(factor=0.5, align=True)
            split.prop(settings, "edge_snap_margin_top")
            split.prop(settings, "edge_snap_margin_bottom")
            split = box_margins.split(factor=0.5, align=True)
            split.prop(settings, "edge_snap_margin_left")
            split.prop(settings, "edge_snap_margin_right")

        if not settings.follow_scene_units:
            row = box.row()
            row.prop(settings, "unit_system")

        row = box.row(align=True)
        row.use_property_split = False
        row.prop(settings, "use_manual_origin", toggle=True, text=_("Manual Origin"), **_icon_kwargs('NONE', 'CURSOR'))
        row.operator("view3d.smart_measure_grid_set_origin", text=_("Use Cursor"), **_icon_kwargs('NONE', 'CURSOR'))
        if settings.use_manual_origin:
            box.prop(settings, "manual_origin_location", text=_("Origin"))

        split = box.split(factor=0.7, align=True)
        left = split.row(align=True)
        left.use_property_split = False
        left.prop(settings, "max_annotations")
        right = split.row(align=True)
        right.alignment = 'RIGHT'
        right.scale_x = 0.9
        right.operator("view3d.smart_measure_grid_animation_prev", text="", emboss=True, **_icon_kwargs('trileft', 'TRIA_LEFT'))
        right.label(text=str(settings.animation_style))
        right.operator("view3d.smart_measure_grid_animation_next", text="", emboss=True, **_icon_kwargs('triright', 'TRIA_RIGHT'))
