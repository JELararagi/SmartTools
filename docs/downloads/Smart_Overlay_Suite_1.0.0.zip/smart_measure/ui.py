# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Controls for ruler labels, edge placement, and manual origins."""

from bpy.app.translations import pgettext_iface as translate
from bpy.types import Panel

from .. import icons


def _SICON(name="", fallback="NONE"):
    try:
        return int(icons.icon_value(name, fallback) or 0)
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return 0


def _icon_kwargs(name="", fallback="NONE"):
    try:
        return icons.icon_kwargs(name, fallback)
    except (AttributeError, ReferenceError, RuntimeError):
        return {"icon": fallback}


def _panel_context_safe(context):
    area = getattr(context, "area", None)
    target = getattr(context, "object", None) or getattr(context, "active_object", None)
    return bool(getattr(context, "scene", None) and target and
                (area is None or getattr(area, "type", None) == "VIEW_3D"))


class VIEW3D_PT_smart_measure_grid_overlay(Panel):
    bl_idname = "VIEW3D_PT_smart_measure_grid_overlay"
    bl_label = "Grid Scale Overlay"
    bl_category = "Smart Overlay"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_order = 100

    @classmethod
    def poll(cls, context):
        return _panel_context_safe(context)

    def draw(self, context):
        settings = getattr(getattr(context, "scene", None), "smart_measure_grid", None)
        if settings is None:
            return
        panel = self.layout.box()
        panel.use_property_decorate = False
        panel.use_property_split = True
        appearance = panel.column(align=True)
        appearance.prop(settings, "font_size")
        appearance.prop(settings, "color")
        appearance.prop(settings, "auto_color", slider=True)
        appearance.prop(settings, "alpha")

        panel.prop(settings, "follow_scene_units")
        panel.prop(settings, "unit_display_mode")
        if not settings.follow_scene_units:
            panel.prop(settings, "unit_system")

        axes = panel.row(align=True)
        axes.use_property_split = False
        axes.label(text=translate("Axes:"))
        for axis in "xyz":
            axes.prop(settings, "show_" + axis, text=axis.upper(), toggle=True)
        views = panel.row(align=True)
        views.prop(settings, "show_persp", toggle=True, **_icon_kwargs("NONE", "VIEW_PERSPECTIVE"))
        views.prop(settings, "show_ortho", toggle=True, **_icon_kwargs("grid", "VIEW_ORTHO"))

        edges = panel.column(align=True)
        edges.prop(settings, "edge_snap", toggle=True, **_icon_kwargs("NONE", "PINNED"))
        edges.prop(settings, "edge_snap_always", text=translate("Always Snap"), toggle=True)
        edges.prop(settings, "text_shadow", toggle=True, **_icon_kwargs("font", "FONT_DATA"))
        if settings.edge_snap or settings.edge_snap_always:
            margins = panel.box()
            margins.label(text=translate("Edge Snap Margins (px):"))
            for edge in ("top", "bottom", "left", "right"):
                margins.prop(settings, f"edge_snap_margin_{edge}")

        panel.prop(settings, "use_manual_origin", toggle=True, text=translate("Manual Origin"))
        panel.operator("view3d.smart_measure_grid_set_origin", text=translate("Use Cursor"), icon="CURSOR")
        if settings.use_manual_origin:
            panel.prop(settings, "manual_origin_location", text=translate("Origin"))
        panel.prop(settings, "max_annotations")
        animation = panel.row(align=True)
        animation.operator("view3d.smart_measure_grid_animation_prev", text="",
                           **_icon_kwargs("trileft", "TRIA_LEFT"))
        animation.label(text=str(settings.animation_style))
        animation.operator("view3d.smart_measure_grid_animation_next", text="",
                           **_icon_kwargs("triright", "TRIA_RIGHT"))
