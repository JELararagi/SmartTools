# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package


import bpy
import blf
import gpu
import logging
import math
import time
import re
from collections import OrderedDict
from functools import partial
from mathutils import Vector
from bpy_extras.view3d_utils import location_3d_to_region_2d

from . import utils
from .. import mesh as _sos_mesh_runtime

logger = logging.getLogger(__name__)

class SmartMeasureGridOverlay:
    overlays = {}
    
    def __init__(self, area):
        self.area = area
        self.handle = None
        self.last_positions = {'X': OrderedDict(), 'Y': OrderedDict(), 'Z': OrderedDict()}
        self.position_memory = 0.9
        self.last_view_rotation = None  # 存储上一次的视图旋转
        self.rotation_tolerance = 0.1  # 旋转宽容度（弧度）
        self.color = (1.0, 1.0, 1.0)
        self.alpha = 1.0
        self.font_size = 12
        self.grid_scale = 1.0
        self.active = False
        self.unit_system = 'm'  # 添加单位系统
        self.unit_display_mode = 'AUTO'
        self.use_manual_origin = False
        self.manual_origin_location = Vector((0, 0, 0))
        # 存储稳定的区域标识符
        self.area_id = utils.get_stable_area_id(area)
        
        # For view scale transitions (unified for ortho and persp)
        self.last_main_interval = None
        self.transition_info = {
            'start_time': 0,
            'from_interval': None,
            'active': False
        }
        self.transition_duration = 0.35  # seconds
        self.timer_callback_partial = None # 新增：用于存储定时器函数对象
        
        # For edge snapping transitions
        self.edge_snap_transitions = {}  # {axis: {'start_time', 'is_snapping'}}
        self.edge_snap_duration = 0.3  # seconds
        
    def _to_scene_length(self, value):
        scale = self.grid_scale if self.grid_scale > 0 else 1.0
        return value * scale

    def _from_scene_length(self, value):
        scale = self.grid_scale if self.grid_scale > 0 else 1.0
        return value / scale

    def register(self, report_func):
        if self.handle is None:
            if self.area.as_pointer() not in SmartMeasureGridOverlay.overlays:
                logger.info(f'Registering overlay for area: {self.area_id}')
                window_region = next((region for region in self.area.regions if region.type == 'WINDOW'), None)
                if window_region is None:
                    logger.error(f'WINDOW region not found for area: {self.area_id}')
                    report_func({'ERROR'}, "Failed to find WINDOW region, cannot register Smart Measure grid-scale.")
                    return
                try:
                    # 使用 functools.partial 绑定 self
                    draw_func = partial(self.draw_callback_px, self)
                    self.handle = bpy.types.SpaceView3D.draw_handler_add(
                        draw_func, 
                        (),  # 不传递额外参数
                        'WINDOW', 
                        'POST_PIXEL'
                    )
                    SmartMeasureGridOverlay.overlays[self.area.as_pointer()] = self
                    self.active = True
                    logger.info(f'Successfully registered overlay for area: {self.area_id}')
                    self.area.tag_redraw()  # 强制区域重绘
                except Exception as e:
                    logger.exception("Failed to add draw handler.")
                    report_func({'ERROR'}, "Error registering Smart Measure grid-scale.")
            else:
                logger.warning(f'Overlay already registered for area: {self.area_id}')
                report_func({'WARNING'}, "Overlay already registered for this area.")
    
    def unregister(self):
        if self.handle is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(self.handle, 'WINDOW')
                logger.info(f'Unregistered overlay for area: {self.area_id}')
                # 新增：注销时清理定时器
                if self.timer_callback_partial and bpy.app.timers.is_registered(self.timer_callback_partial):
                    bpy.app.timers.unregister(self.timer_callback_partial)
                    self.timer_callback_partial = None
                self.area.tag_redraw()  # 强制区域重绘
            except Exception as e:
                logger.exception("Failed to remove draw handler.")
            self.handle = None
            self.active = False
            SmartMeasureGridOverlay.overlays.pop(self.area.as_pointer(), None)
    
    @staticmethod
    def is_overlay_active(area):
        active = area.as_pointer() in SmartMeasureGridOverlay.overlays
        logger.debug(f'Checking if overlay is active for area: {area.as_pointer()}, Result: {active}')
        return active
    
    @classmethod
    def cleanup_invalid_overlays(cls):
        """Clean up overlays for areas that no longer exist."""
        invalid_pointers = []
        for ptr, overlay in cls.overlays.items():
            try:
                # Check if area is still valid
                # Accessing .type or any property of a removed area struct raises ReferenceError
                if overlay.area.type != 'VIEW_3D':
                    invalid_pointers.append(ptr)
            except (ReferenceError, AttributeError):
                invalid_pointers.append(ptr)
        
        for ptr in invalid_pointers:
            logger.info(f"Removing invalid overlay for area pointer: {ptr}")
            overlay = cls.overlays.pop(ptr, None)
            if overlay:
                # Remove the draw handler to stop it from running for other views
                if overlay.handle:
                    try:
                        bpy.types.SpaceView3D.draw_handler_remove(overlay.handle, 'WINDOW')
                    except Exception:
                        pass
                # Remove timer
                if overlay.timer_callback_partial and bpy.app.timers.is_registered(overlay.timer_callback_partial):
                    try:
                        bpy.app.timers.unregister(overlay.timer_callback_partial)
                    except Exception:
                        pass

    def update_settings(self, scene):
        """更新所有设置"""
        settings = getattr(scene, "smart_measure_grid", None)
        if settings is None:
            return
        self.color = settings.color
        self.alpha = settings.alpha
        self.font_size = settings.font_size
        self.grid_scale = scene.unit_settings.scale_length
        self.unit_display_mode = settings.unit_display_mode
        self.use_manual_origin = settings.use_manual_origin
        
        # 如果启用手动原点（实际上是跟随游标），则实时获取游标位置
        if self.use_manual_origin:
            self.manual_origin_location = scene.cursor.location.copy()
        else:
            self.manual_origin_location = Vector((0, 0, 0))
        
        # 更新单位系统
        if settings.follow_scene_units:
            self.unit_system = 'ft' if scene.unit_settings.system == 'IMPERIAL' else 'm'
        else:
            self.unit_system = settings.unit_system

    def draw_callback_px(self, overlay):
        """Safe POST_PIXEL wrapper for the Smart Measure grid-scale overlay."""
        _sos_gpu_snapshot = None
        try:
            _sos_gpu_snapshot = _sos_mesh_runtime._sos_push_gpu_state_restore()
        except Exception:
            _sos_gpu_snapshot = None
        try:
            _sos_clip_token = _sos_mesh_runtime._sos_begin_post_pixel_ui_region_clip(bpy.context)
        except Exception:
            _sos_clip_token = None
        try:
            # 如果全局overlays关闭，则不绘制任何内容
            if not bpy.context.space_data.overlay.show_overlays:
                return
                
            context = bpy.context
            scene = context.scene
            
            # 检查当前区域是否为目标区域
            current_area = bpy.context.area
            try:
                if current_area is None or current_area.as_pointer() != self.area.as_pointer():
                    return
            except ReferenceError:
                # 区域已被移除，自动清理
                logger.info(f"Area {self.area_id} detected as removed in draw callback, unregistering.")
                self.unregister()
                return

            settings = getattr(scene, 'smart_measure_grid', None)
            if settings is None:
                return
            self.update_settings(scene)

            # 获取WINDOW区域
            window_region = next((region for region in self.area.regions if region.type == 'WINDOW'), None)
            if window_region is None:
                logger.error(f'WINDOW region not found during draw for area: {self.area_id}')
                return

            region = window_region
            space = self.area.spaces[0]
            rv3d = space.region_3d
            
            # --- TRANSITION LOGIC ---
            current_main_interval = self.get_ortho_main_interval(rv3d.view_distance)
            
            # Detect if a new transition should start
            if self.last_main_interval is not None and current_main_interval != self.last_main_interval:
                self.transition_info = {
                    'start_time': time.time(),
                    'from_interval': self.last_main_interval,
                    'active': True,
                    'zooming_out': current_main_interval > self.last_main_interval
                }
                self.start_animation_timer() # 新增：启动动画定时器
            self.last_main_interval = current_main_interval
            
            # Check if we are currently in a transition
            time_since_transition = time.time() - self.transition_info['start_time']
            in_transition = self.transition_info['active'] and time_since_transition < self.transition_duration
            
            if not in_transition and self.transition_info['active']:
                self.transition_info['active'] = False # Deactivate after duration
            
            #根据视图透视/正交与用户选择决定是否继续执行
            settings = getattr(context.scene, 'smart_measure_grid', None)
            if settings is None:
                return
            if rv3d.view_perspective == 'ORTHO':
                if not settings.show_ortho:
                    return
            else:
                if not settings.show_persp:
                    return

            # 确定当前视图方向
            view_orientation = utils.get_view_orientation(rv3d)
            # logger.debug(f'Current view orientation: {view_orientation}')  # noisy per-frame

            # 根据用户设置决定显示哪些轴
            axes_to_show = set()  # 初始化为空集合
            
            # 根据用户设置添加轴
            if scene.smart_measure_grid.show_x:
                axes_to_show.add('X')
            if scene.smart_measure_grid.show_y:
                axes_to_show.add('Y')
            if scene.smart_measure_grid.show_z:
                axes_to_show.add('Z')
            
            # 如果没有选择任何轴，则不显示任何内容
            if not axes_to_show:
                return
            
            alpha_axes = {}
            axis_alignments = {}
            # 在正交视图下，根据视图方向过滤轴
            if rv3d.view_perspective == 'ORTHO':
                # 添加视角宽容度，允许轻微偏移
                view_tolerance = 0.2  # 约11.5度的宽容度
                
                # 计算视图向量与标准方向的点积
                view_vector = rv3d.view_rotation @ Vector((0, 0, -1))
                view_vector.normalize()
                
                #front_back = abs(abs(view_vector.y) - 1) < view_tolerance
                #left_right = abs(abs(view_vector.x) - 1) < view_tolerance
                #top_bottom = abs(abs(view_vector.z) - 1) < view_tolerance
                
                # 根据视图方向过滤轴，但保留用户选择的轴
                visible_axes = set()
                #if front_back:
                #    visible_axes = {'X', 'Z'}
                #elif left_right:
                #    visible_axes = {'Y', 'Z'}
                #elif top_bottom:
                #    visible_axes = {'X', 'Y'}
                #else:
                if 1:
                    # 用户视图下，显示所有可见轴
                    axis_visibility = {
                        'X': abs(view_vector.x),
                        'Y': abs(view_vector.y),
                        'Z': abs(view_vector.z)
                    }
                    
                    # 如果轴向量与视图方向夹角接近90度（即垂直），则不显示该轴
                    # 0.9对应约25度的夹角范围
                    #visible_axes = {axis for axis, vis in axis_visibility.items() if vis < 0.9}
                    #星月：不过滤测试
                    visible_axes = {'X', 'Y', 'Z'}
                    
                    #此处改为按夹角决定轴透明度
                    for axis,vis in axis_visibility.items():
                        if vis > 0.9:
                            alpha_axes[axis] = max((1 - vis) * 10, 0)
                        #else: alpha_axes[axis] = 1.0
                    
                    # 确保至少显示两个最垂直的轴
                    #if len(visible_axes) < 2:
                    #    sorted_axes = sorted(axis_visibility.items(), key=lambda x: x[1])
                    #    visible_axes = {sorted_axes[0][0], sorted_axes[1][0]}
                
                
                # 只显示用户选择的轴中在当前视图中可见的轴
                #axes_to_show = axes_to_show.intersection(visible_axes)
            
            # 新增：在透视视图下也应用正对轴淡出机制
            elif rv3d.view_perspective == 'PERSP':
                view_vector = rv3d.view_rotation @ Vector((0, 0, -1))
                view_vector.normalize()
                
                # 计算相机到原点的方向向量，用于检测相机是否在轴线上（解决堆叠问题）
                # 当相机位于轴线上时，该轴的标注会堆叠在一起，需要淡出
                # 星月注：在大场景下（远离世界原点），to_origin 会导致误判，因此移除此逻辑
                # 仅保留基于视线方向的判断
                
                axis_vectors = {
                    'X': Vector((1, 0, 0)),
                    'Y': Vector((0, 1, 0)),
                    'Z': Vector((0, 0, 1))
                }
                
                for axis, vec in axis_vectors.items():
                    # 1. 视线与轴平行（Looking along the axis）
                    vis_view = abs(view_vector.dot(vec))
                    
                    # 2. 相机位于轴线上（Camera on the axis line）
                    # 已移除：导致远距离（大坐标）下的标注异常消失
                    # vis_on_axis = abs(to_origin.dot(vec))
                    
                    # 仅使用视线角度
                    vis = vis_view
                    axis_alignments[axis] = vis
                    
                    # 提高整体淡出的阈值，让动态深度裁剪逻辑接管过渡区间 (0.6 ~ 0.98)
                    if vis > 0.98:
                        alpha_axes[axis] = max((1 - vis) * 50, 0)
            
            # 获取视距和相机位置
            view_distance = rv3d.view_distance
            camera_location = rv3d.view_matrix.inverted().translation

            # 定义轴向颜色
            axis_colors = {
                'X': (1.0, 0.0, 0.0),  # 红色
                'Y': (0.0, 1.0, 0.0),  # 绿色
                'Z': (0.0, 0.0, 1.0)   # 蓝色
            }

            # 批量绘制文本
            blf_batch = []
            origin_added = False  # 跟踪是否已添加原点

            # 首先检查是否应该显示原点
            if rv3d.view_perspective == 'ORTHO':
                bounds = utils.get_ortho_view_bounds(region, rv3d)
            else:
                bounds = utils.get_view_bounds(region, rv3d)
            # 新增：获取视口裁切距离与视图方向
            clip_end = None
            try:
                if context.area and context.area.type == 'VIEW_3D':
                    space = context.space_data
                    if hasattr(space, 'clip_end'):
                        clip_end = float(space.clip_end)
            except Exception:
                clip_end = None
            view_center_global = rv3d.view_matrix.inverted().translation
            view_dir_global = rv3d.view_rotation @ Vector((0, 0, -1))
            view_dir_global.normalize()
            
            # 显示原点 (透视和正交模式统一处理)
            # 检查原点是否在视图范围内
            current_origin = self.manual_origin_location if self.use_manual_origin else Vector((0, 0, 0))
            show_origin = False
            if bounds['min_x'] <= current_origin.x <= bounds['max_x'] and bounds['min_y'] <= current_origin.y <= bounds['max_y']:
                show_origin = True
            
            # 正交视图下，如果不受 bounds 限制 (比如自由正交)，我们也尝试显示
            if rv3d.view_perspective == 'ORTHO':
                show_origin = True

            if show_origin:
                # 超出裁切距离则不显示
                should_draw_origin = True
                if clip_end is not None:
                    depth_to_origin = abs((current_origin - view_center_global).dot(view_dir_global))
                    if depth_to_origin > clip_end:
                        should_draw_origin = False
                
                if should_draw_origin:
                    # 将3D坐标转换为2D屏幕坐标
                    origin_pos_2d = location_3d_to_region_2d(region, rv3d, current_origin)
                    if origin_pos_2d is not None:
                        # 检查是否在屏幕内 (带一点边距)
                        margin = 0 if rv3d.view_perspective == 'PERSP' else 50
                        if (-margin <= origin_pos_2d.x <= region.width + margin and 
                            -margin <= origin_pos_2d.y <= region.height + margin):
                            
                            origin_alpha = 0.8
                            
                            # 正交视图添加边缘淡出
                            if rv3d.view_perspective == 'ORTHO':
                                zero_edge_factor = min(
                                    origin_pos_2d.x / margin if margin > 0 else 1,
                                    (region.width - origin_pos_2d.x) / margin if margin > 0 else 1,
                                    origin_pos_2d.y / margin if margin > 0 else 1,
                                    (region.height - origin_pos_2d.y) / margin if margin > 0 else 1
                                )
                                # 使用 smootherstep
                                zero_edge_factor = utils._ease_smootherstep(max(0.0, min(1.0, zero_edge_factor)))
                                origin_alpha *= zero_edge_factor

                            if origin_alpha > 0.01:
                                blf_batch.append((
                                    origin_pos_2d.x,
                                    origin_pos_2d.y + 10,
                                    "0",
                                    origin_alpha,
                                    self.font_size * 1.0,
                                    (0.9, 0.9, 0.9),
                                    True
                                ))
                                origin_added = True

            # 预计算：正交吸附需要的屏幕轴与目标位置
            settings = getattr(context.scene, 'smart_measure_grid', None)
            if settings is None:
                return
            is_standard_ortho = rv3d.view_perspective == 'ORTHO' and view_orientation != 'USER'
            screen_axes = {'horizontal': None, 'vertical': None}
            origin_2d = None
            axis_snap_targets = {}
            
            # 重新获取当前原点（以防上面代码块未执行或变量作用域问题）
            current_origin = self.manual_origin_location if self.use_manual_origin else Vector((0, 0, 0))
            
            edge_snap_enabled = (settings.edge_snap or getattr(settings, "edge_snap_always", False)) and is_standard_ortho
            if edge_snap_enabled:
                origin_2d = location_3d_to_region_2d(region, rv3d, current_origin)
                if origin_2d:
                    x_end = location_3d_to_region_2d(region, rv3d, current_origin + Vector((1,0,0)))
                    y_end = location_3d_to_region_2d(region, rv3d, current_origin + Vector((0,1,0)))
                    z_end = location_3d_to_region_2d(region, rv3d, current_origin + Vector((0,0,1)))
                    vecs = {'X': x_end, 'Y': y_end, 'Z': z_end}
                    candidates = []
                    for axis_name, end_point in vecs.items():
                        if end_point:
                            vec_2d = end_point - origin_2d
                            if vec_2d.length > 0.1:
                                candidates.append((axis_name, vec_2d))
                    if len(candidates) == 2:
                        axis1_name, axis1_vec = candidates[0]
                        axis2_name, axis2_vec = candidates[1]
                        if abs(axis1_vec.x) > abs(axis1_vec.y):
                            screen_axes['horizontal'] = axis1_name
                            screen_axes['vertical'] = axis2_name
                        else:
                            screen_axes['horizontal'] = axis2_name
                            screen_axes['vertical'] = axis1_name

            # 处理每个轴的标注
            for axis in axes_to_show:
                # 生成该轴的所有网格点
                grid_points = []
                fading_points = []
                
                origin_offset = self.manual_origin_location if self.use_manual_origin else Vector((0, 0, 0))

                if rv3d.view_perspective == 'ORTHO':
                    grid_points = self.generate_ortho_grid_points(view_distance, axis, region, rv3d, view_orientation, origin_offset=origin_offset)
                    if in_transition and self.transition_info['from_interval']:
                        fading_points = self.generate_ortho_grid_points(view_distance, axis, region, rv3d, view_orientation, force_main_interval=self.transition_info['from_interval'], origin_offset=origin_offset)
                else:
                    grid_points = self.generate_grid_points(camera_location, view_distance, axis, region, rv3d, origin_offset=origin_offset)
                    if in_transition and self.transition_info['from_interval']:
                        fading_points = self.generate_grid_points(camera_location, view_distance, axis, region, rv3d, force_main_interval=self.transition_info['from_interval'], origin_offset=origin_offset)
                
                # If in transition, add fading points to the list
                if fading_points:
                    for p in fading_points:
                        p['is_fading_out'] = True
                    grid_points.extend(fading_points)
                
                # 预计算当前轴是否需要吸附以及目标坐标
                is_snapping_axis = False
                snap_target_x = None
                snap_target_y = None
                if edge_snap_enabled and origin_2d and screen_axes['horizontal']:
                    always_snap = getattr(settings, "edge_snap_always", False)

                    if axis == screen_axes['horizontal']:
                        if always_snap:
                            snap_target_y = settings.edge_snap_margin_bottom
                            is_snapping_axis = True
                        elif not (0 <= origin_2d.y <= region.height):
                            snap_target_y = settings.edge_snap_margin_bottom if origin_2d.y < 0 else region.height - settings.edge_snap_margin_top
                            is_snapping_axis = True

                    if axis == screen_axes['vertical']:
                        if always_snap:
                            snap_target_x = settings.edge_snap_margin_left
                            is_snapping_axis = True
                        elif not (0 <= origin_2d.x <= region.width):
                            snap_target_x = settings.edge_snap_margin_left if origin_2d.x < 0 else region.width - settings.edge_snap_margin_right
                            is_snapping_axis = True
                
                # 边缘吸附的过渡（按轴）
                transition_key = f"{view_orientation}_{axis}"
                prev_state = self.edge_snap_transitions.get(transition_key)
                if prev_state is None:
                    self.edge_snap_transitions[transition_key] = {
                        'start_time': time.time() - self.edge_snap_duration,
                        'is_snapping': is_snapping_axis,
                    }
                elif prev_state['is_snapping'] != is_snapping_axis:
                    self.edge_snap_transitions[transition_key] = {
                        'start_time': time.time(),
                        'is_snapping': is_snapping_axis,
                    }
                    self.start_animation_timer()
                transition_data = self.edge_snap_transitions[transition_key]

                for point in grid_points:
                    try:
                        # 跳过原点（因为我们已经单独处理了），除非开启了始终吸附且当前轴正在吸附（此时0也需要吸附到边缘）
                        if abs(point['value']) < 1e-6:
                             always_snap = getattr(settings, "edge_snap_always", False)
                             if not (always_snap and is_snapping_axis):
                                 continue
                        
                        # 基于视口裁切距离隐藏超远标注
                        if clip_end is not None:
                            depth_to_point = abs((point['position'] - view_center_global).dot(view_dir_global))
                            if depth_to_point > clip_end:
                                continue
                        
                        # 将3D坐标转换为2D屏幕坐标（正交：先投影到视图平面，避免深度裁剪导致的突然消失）
                        if rv3d.view_perspective == 'ORTHO':
                            view_center = rv3d.view_matrix.inverted().translation
                            view_dir = rv3d.view_rotation @ Vector((0, 0, -1))
                            view_dir.normalize()
                            to_point = point['position'] - view_center
                            pos_on_plane = point['position'] - view_dir * to_point.dot(view_dir)
                            pos_2d = location_3d_to_region_2d(region, rv3d, pos_on_plane)
                        else:
                            pos_2d = location_3d_to_region_2d(region, rv3d, point['position'])
                        if pos_2d is None:
                            continue

                        # ---- EDGESNAP START ----
                        original_pos_2d = pos_2d.copy()
                        if is_snapping_axis:
                            # 计算过渡插值
                            time_since_transition = time.time() - transition_data['start_time']
                            in_edge_transition = time_since_transition < self.edge_snap_duration
                            
                            # 如果开启了始终吸附且当前轴是吸附轴，则跳过动画过渡，直接吸附到位
                            always_snap = getattr(settings, "edge_snap_always", False)
                            if always_snap and transition_data['is_snapping']:
                                in_edge_transition = False
                                
                            edge_transition_progress = 1.0
                            if in_edge_transition:
                                t = time_since_transition / self.edge_snap_duration
                                t = min(1.0, max(0.0, t))
                                # smoother easing with slight overshoot on snap, gentle in-back on unsnap
                                if transition_data['is_snapping']:
                                    shaped_t = utils._ease_out_back(t, 1.1)
                                else:
                                    shaped_t = utils._ease_in_back(t, 1.1)
                                edge_transition_progress = shaped_t
                                target_x = pos_2d.x if snap_target_x is None else snap_target_x
                                target_y = pos_2d.y if snap_target_y is None else snap_target_y
                                if transition_data['is_snapping']:
                                    pos_2d.x = original_pos_2d.x + (target_x - original_pos_2d.x) * shaped_t
                                    pos_2d.y = original_pos_2d.y + (target_y - original_pos_2d.y) * shaped_t
                                else:
                                    pos_2d.x = original_pos_2d.x + (target_x - original_pos_2d.x) * (1.0 - shaped_t)
                                    pos_2d.y = original_pos_2d.y + (target_y - original_pos_2d.y) * (1.0 - shaped_t)
                            else:
                                if snap_target_x is not None:
                                    pos_2d.x = snap_target_x
                                if snap_target_y is not None:
                                    pos_2d.y = snap_target_y
                        
                        # ---- TRANSITION OFFSET (vertical slide) ----
                        if in_transition and settings.animation_style == '2':
                            t_slide = (time.time() - self.transition_info['start_time']) / self.transition_duration
                            t_slide = utils._clamp01(t_slide)
                            shaped_slide = utils._ease_smootherstep(t_slide)
                            max_offset_px = max(12, int(self.font_size * 1.25))
                            zooming_out = self.transition_info.get('zooming_out', False)
                            if point.get('is_fading_out', False):
                                # 旧标注：
                                if zooming_out:
                                    # 拉远：向上滚动淡出
                                    pos_2d.y += shaped_slide * max_offset_px
                                else:
                                    # 拉近：向下滚动淡出
                                    pos_2d.y -= shaped_slide * max_offset_px
                            else:
                                # 新标注：
                                if zooming_out:
                                    # 拉远：自下往上进入
                                    pos_2d.y -= (1.0 - shaped_slide) * max_offset_px
                                else:
                                    # 拉近：自上往下进入
                                    pos_2d.y += (1.0 - shaped_slide) * max_offset_px
                        
                        # 如果吸附后，点仍然在屏幕外，则跳过
                        if not (0 <= pos_2d.x <= region.width and 0 <= pos_2d.y <= region.height):
                            continue
                        # ---- EDGESNAP END ----

                        # ---- CORNER FADE START ----
                        corner_fade = 1.0
                        if is_snapping_axis:
                            corner_margin = 150 # 从角落开始淡出的像素距离
                            
                            # 判断当前标注对应的轴在屏幕上是水平还是垂直
                            axis_is_horizontal = (axis == screen_axes.get('horizontal'))

                            if axis_is_horizontal:
                                # 水平轴的标注（已吸附到顶部/底部），当靠近左右边缘时淡出
                                fade_dist = min(pos_2d.x, region.width - pos_2d.x)
                                if fade_dist < corner_margin:
                                    corner_fade = fade_dist / corner_margin
                            else: # 垂直轴
                                # 垂直轴的标注（已吸附到左侧/右侧），当靠近上下边缘时淡出
                                fade_dist = min(pos_2d.y, region.height - pos_2d.y)
                                if fade_dist < corner_margin:
                                    corner_fade = fade_dist / corner_margin
                            
                            # 使用 smootherstep 优化角落淡出效果
                            corner_fade = utils._ease_smootherstep(max(0.0, corner_fade))
                        # ---- CORNER FADE END ----

                        # 计算淡出因子
                        if rv3d.view_perspective == 'PERSP':
                            alignment = axis_alignments.get(axis, 0.0)
                            fade_factor = self.calculate_fade_factor(point, view_distance, alignment)
                        else:  # ORTHO
                            fade_factor = 1.0  # 正交视图的淡出已在 transition_factor 中处理
                        
                        if fade_factor < 0:
                            continue

                        
                        # 计算缩放因子
                        scale_factor = self.calculate_distance_scale(point['distance'], view_distance)
                        if point['is_sub']:
                            scale_factor *= 0.8  # 子刻度额外缩小20%

                        # 正交模式可基于生成策略隐藏部分标签
                        if 'show_label' in point and not point['show_label']:
                            continue

                        text = point['format'](point.get('value_display', point['value']))
                        
                        # In perspective view, remove units from sub-annotations for clarity.
                        if rv3d.view_perspective == 'PERSP' and point.get('is_sub', False):
                            text = re.sub(r'[a-zA-Z\'"]+$', '', text)
                        
                        axis_color = axis_colors[axis]
                        mix_factor = scene.smart_measure_grid.auto_color
                        if mix_factor < 1:  # 当不是完全使用轴颜色时
                            axis_color = (
                                self.color[0] * (1 - mix_factor) + axis_color[0] * mix_factor,
                                self.color[1] * (1 - mix_factor) + axis_color[1] * mix_factor,
                                self.color[2] * (1 - mix_factor) + axis_color[2] * mix_factor
                            )

                        # 使用当前字号作为基准进行缩放
                        base_size = self.font_size if not point['is_sub'] else int(self.font_size * 0.8)
                        # 移除量化，避免在临界值处抖动
                        final_size = max(int(base_size * 0.6), int(base_size * scale_factor))  # 确保不会缩得太小

                        # ---- TRANSITION SCALE (style 3) ----
                        if in_transition and settings.animation_style == '3':
                            t_scale = (time.time() - self.transition_info['start_time']) / self.transition_duration
                            t_scale = utils._clamp01(t_scale)
                            shaped = utils._ease_smootherstep(t_scale)
                            # 旧标注缩小并淡出，新标注由小到大
                            if point.get('is_fading_out', False):
                                scale_mul = 1.0 - 0.2 * shaped
                            else:
                                scale_mul = 0.8 + 0.2 * shaped
                            final_size = max(6, int(final_size * scale_mul))

                        # 计算边缘淡出
                        margin = 60  # 边缘淡出区域的像素宽度
                        edge_factor = min(
                            pos_2d.x / margin,
                            (region.width - pos_2d.x) / margin,
                            pos_2d.y / margin,
                            (region.height - pos_2d.y) / margin
                        )
                        # 使用 smootherstep 优化边缘淡出
                        edge_factor = utils._ease_smootherstep(max(0.0, min(1.0, edge_factor)))
                        
                        # 应用边缘淡出到过渡因子
                        # Use .get() for robustness, as new perspective points don't have this key.
                        transition_factor = point.get('transition_factor', 1.0)
                        final_alpha = self.alpha * edge_factor * fade_factor * transition_factor
                        
                        # 在正交视图下调整透明度
                        if rv3d.view_perspective == 'ORTHO' or rv3d.view_perspective == 'PERSP':
                            if point['is_sub']:
                                final_alpha *= 0.7  # 降低次标注的透明度
                            else:
                                final_alpha = min(1.0, final_alpha * 1.2)  # 增加主标注的透明度，但不超过1.0
                            if axis in alpha_axes:
                                final_alpha *= alpha_axes[axis]
                        
                        # 如果正在吸附，强制设置为不透明
                        if is_snapping_axis:
                            final_alpha = self.alpha * corner_fade # 应用角落淡出
                            if point['is_sub']:
                                final_alpha *= 0.4 # 次级标注在吸附时进一步降低透明度
                            
                            # Apply edge transition fade effect at axis level
                            if in_edge_transition:
                                if transition_data['is_snapping']:  # Transitioning to snapped state
                                    final_alpha *= edge_transition_progress
                                else:  # Transitioning away from snapped state
                                    final_alpha *= (1.0 - edge_transition_progress)
                        
                        # Apply transition fade
                        if in_transition:
                            progress = (time.time() - self.transition_info['start_time']) / self.transition_duration
                            transition_alpha = (1.0 - progress) if point.get('is_fading_out', False) else progress
                            transition_alpha = utils._clamp01(transition_alpha)
                            transition_alpha = utils._ease_smootherstep(transition_alpha)
                            final_alpha *= transition_alpha
                        
                        # 提前丢弃透明度过低的标注，避免进入批次
                        if final_alpha < 0.01:
                            continue
                        
                        # 添加到绘制批次，整体上移10个像素
                        blf_batch.append((
                            pos_2d.x, pos_2d.y + 10, text,
                            final_alpha, final_size, axis_color, False))

                    except Exception as e:
                        logger.exception(f'Error processing grid point: {e}')

            # 如果标注数量超过限制，进行裁剪
            max_annotations = scene.smart_measure_grid.max_annotations
            if len(blf_batch) > max_annotations:
                # 保留原点标注（如果有）
                origin_annotations = [item for item in blf_batch if item[6]]  # item[6]为True表示是原点
                non_origin_annotations = [item for item in blf_batch if not item[6]]
                
                # 优先保留远离视口边缘、可视性好的标注（从边缘向内收缩）
                def _edge_distance(item):
                    x, y = item[0], item[1]
                    return min(x, region.width - x, y, region.height - y)
                # 排序优先级：距边缘距离优先，其次透明度，再其次字号（均为降序）
                non_origin_annotations.sort(key=lambda item: (_edge_distance(item), item[3], item[4]), reverse=True)
                
                # 计算要保留的非原点标注数量
                keep_count = max_annotations - len(origin_annotations)
                if keep_count < 0:
                    keep_count = 0
                
                # 组合结果：保留原点与从中心向外优先的标注
                blf_batch = origin_annotations + non_origin_annotations[:keep_count]
            
            # 批量绘制文本
            last_font_size = -1
            last_color = (-1.0, -1.0, -1.0, -1.0)
            _dim_cache = {}
            for x, y, text, alpha, font_size, color, is_origin in blf_batch:
                try:
                    # 特殊处理原点标注
                    if is_origin:
                        # 原点使用稍大的字体和特殊颜色
                        target_size = int(font_size * 1.2)
                        if target_size != last_font_size:
                            blf.size(0, target_size)
                            last_font_size = target_size
                        origin_color = (0.9, 0.9, 0.9)  # 接近白色
                        if (origin_color[0], origin_color[1], origin_color[2], alpha) != last_color:
                            blf.color(0, origin_color[0], origin_color[1], origin_color[2], alpha)
                            last_color = (origin_color[0], origin_color[1], origin_color[2], alpha)
                    else:
                        if font_size != last_font_size:
                            blf.size(0, font_size)
                            last_font_size = font_size
                        if (color[0], color[1], color[2], alpha) != last_color:
                            blf.color(0, color[0], color[1], color[2], alpha)
                            last_color = (color[0], color[1], color[2], alpha)
                    
                    # 获取文本尺寸以进行居中对齐（带缓存，按文本+字号作为键）
                    _dim_key = (text, last_font_size)
                    if _dim_key in _dim_cache:
                        text_width, text_height = _dim_cache[_dim_key]
                    else:
                        text_width, text_height = blf.dimensions(0, text)
                        _dim_cache[_dim_key] = (text_width, text_height)
                    
                    # 调整位置使文本居中
                    x = x - text_width / 2
                    y = y + text_height / 2  # 向上偏移以给点标记留出空间
                    
                    # --- 1. 绘制文本 (使用 blf 原生阴影) ---
                    shadow_enabled = False
                    if is_origin or context.scene.smart_measure_grid.text_shadow:
                        shadow_enabled = True
                        outline_alpha = alpha * (0.8 if is_origin else 0.7)
                        # 设置阴影：级别3（软阴影），黑色，Alpha
                        blf.shadow(0, 3, 0.0, 0.0, 0.0, outline_alpha)
                        # 设置偏移：右下
                        blf.shadow_offset(0, 1, -1)
                        # 启用阴影
                        blf.enable(0, blf.SHADOW)
                    
                    # 设置文本主体颜色
                    if is_origin:
                        target_color = (origin_color[0], origin_color[1], origin_color[2], alpha)
                    else:
                        target_color = (color[0], color[1], color[2], alpha)
                    
                    if target_color != last_color:
                        blf.color(0, target_color[0], target_color[1], target_color[2], target_color[3])
                        last_color = target_color
                        
                    blf.position(0, x, y, 0)
                    blf.draw(0, text)
                    
                    # 关闭阴影，避免影响后续非阴影绘制（虽然目前逻辑下所有文本都可能带阴影，但保持状态清洁是好习惯）
                    if shadow_enabled:
                        blf.disable(0, blf.SHADOW)
                    
                    # --- 2. 绘制点标记 (使用 blf 原生阴影) ---
                    if not is_origin:  # 原点不需要点标记
                        dot_y = y - text_height - 2  # 点标记位置在文本下方
                        dot_size = max(6, int(font_size * 0.5))
                        if dot_size != last_font_size:
                            blf.size(0, dot_size)
                            last_font_size = dot_size
                            
                        # 点的尺寸与字号相关，按字号缓存
                        _dot_key = ('•', last_font_size)
                        if _dot_key in _dim_cache:
                            dot_width, _ = _dim_cache[_dot_key]
                        else:
                            dot_width, _ = blf.dimensions(0, "•")
                            _dim_cache[_dot_key] = (dot_width, 0)
                        
                        dot_x = x + text_width/2 - dot_width/2
                        
                        # 开启点的阴影
                        if context.scene.smart_measure_grid.text_shadow:
                            outline_alpha = alpha * 0.7
                            blf.shadow(0, 3, 0.0, 0.0, 0.0, outline_alpha)
                            blf.shadow_offset(0, 1, -1)
                            blf.enable(0, blf.SHADOW)
                        
                        # 恢复颜色绘制点主体（通常不需要重新设置颜色，除非中间改变了）
                        if target_color != last_color:
                            blf.color(0, target_color[0], target_color[1], target_color[2], target_color[3])
                            last_color = target_color
                            
                        blf.position(0, dot_x, dot_y, 0)
                        blf.draw(0, "•")
                        
                        # 关闭阴影
                        if context.scene.smart_measure_grid.text_shadow:
                            blf.disable(0, blf.SHADOW)
                        
                except Exception as e:
                    logger.exception(f'Error drawing text: {e}')

        except Exception as e:
            logger.exception(f'Error in draw_callback_px: {e}')
        finally:
            try:
                blf.disable(0, blf.SHADOW)
            except Exception:
                pass
            try:
                _sos_mesh_runtime._sos_end_post_pixel_ui_region_clip(_sos_clip_token)
            except Exception:
                pass
            try:
                _sos_mesh_runtime._sos_pop_gpu_state_restore(_sos_gpu_snapshot, ui_safe=True)
            except Exception:
                try:
                    _sos_mesh_runtime._sos_restore_gpu_state_snapshot(_sos_gpu_snapshot, ui_safe=True)
                except Exception:
                    try:
                        if isinstance(_sos_gpu_snapshot, dict):
                            for _key, _setter in (
                                ('blend', 'blend_set'),
                                ('depth_mask', 'depth_mask_set'),
                                ('depth_test', 'depth_test_set'),
                                ('line_width', 'line_width_set'),
                                ('scissor', 'scissor_set'),
                                ('scissor_test', 'scissor_test_set'),
                                ('viewport', 'viewport_set'),
                            ):
                                if _key not in _sos_gpu_snapshot:
                                    continue
                                _value = _sos_gpu_snapshot[_key]
                                if isinstance(_value, (tuple, list)):
                                    getattr(gpu.state, _setter)(*_value)
                                else:
                                    getattr(gpu.state, _setter)(_value)
                    except Exception:
                        pass
                    try:
                        blf.disable(0, blf.SHADOW)
                    except Exception:
                        pass
                    try:
                        blf.disable(0, blf.ROTATION)
                    except Exception:
                        pass

    def calculate_distance_scale(self, distance, view_distance):
        """计算基于距离的缩放因子"""
        # 使用平滑曲线代替阶跃函数，避免在临界距离处发生跳变
        # 当距离在 0 到 3 倍视距之间时，缩放因子从 1.0 平滑下降到 0.7
        # 超过 3 倍视距后，缩放因子维持在 0.7 左右（受 min/max 限制）
        
        ratio = distance / view_distance
        
        # 线性减少：每倍视距减少 0.1
        scale = 1.0 - (ratio * 0.1)
        
        return max(0.6, min(1.0, scale))  # 确保不会缩得太小

    def calculate_fade_factor(self, point, view_distance, alignment=0.0):
        """
        Calculates a fade factor based on the point's distance from the camera,
        relative to the overall view zoom.
        Includes dynamic depth culling based on axis alignment to prevent clutter.
        """
        distance = point['distance']
        
        # 基础淡出参数 - 大幅推迟淡出以满足用户需求
        # 当 view_distance 很大时（例如几千米），我们应该相应地扩大 fade_end
        # 以确保远处的标注仍然可见
        fade_start = view_distance * 2.0  # 从 1.5 增加到 2.0
        fade_end = view_distance * 12.0   # 从 8.0 增加到 12.0
        
        # 距离分级标志 (Distance-based LOD triggers) - 同样推迟
        is_far_L1 = distance > view_distance * 4.0  # 从 3.0 增加到 4.0
        is_far_L2 = distance > view_distance * 8.0  # 从 6.0 增加到 8.0
        
        # --- 基于对齐角度的动态优化 (Staged Fade) ---
        # 阶段1: alignment 0.6 ~ 0.75 -> 次级刻度淡出
        # 阶段2: alignment 0.75 ~ 0.95 -> 主刻度间隔淡出 (密度降低)
        # 阶段3: alignment > 0.98 -> 全局淡出 (由 draw_callback_px 处理)
        
        # 只要满足 高角度 OR 远距离，就进入分级处理逻辑
        if alignment > 0.6 or is_far_L1:
            # 1. 次级刻度优先淡出 (Sub-ticks fade first)
            if point.get('is_sub', False):
                # 计算基于角度的淡出
                fade_factor_align = 1.0
                if alignment > 0.6:
                    progress = (alignment - 0.6) / 0.15
                    fade_factor_align = 1.0 - utils._ease_smootherstep(min(1.0, max(0.0, progress)))
                
                # 计算基于距离的淡出 (次级刻度在稍远距离就开始消失)
                fade_factor_dist = 1.0
                if distance > view_distance * 2.0:
                    progress = (distance - view_distance * 2.0) / (view_distance * 1.0)
                    fade_factor_dist = 1.0 - utils._ease_smootherstep(min(1.0, max(0.0, progress)))
                
                # 取最小值 (任一条件满足即淡出)
                sub_fade_factor = min(fade_factor_align, fade_factor_dist)
                
                if sub_fade_factor < 0.01:
                    return 0.0
                return sub_fade_factor # sub 刻度独立控制

            # 2. 主刻度间隔淡出 (Major ticks interval fade)
            # 随着角度变大 OR 距离变远，保留的刻度越来越稀疏
            elif alignment > 0.75 or is_far_L1:
                # 获取该点对应的间隔信息
                interval = point.get('interval', 1.0)
                val = abs(point.get('value', 0.0))
                
                opacity_factor = 1.0
                
                # Level 1 Check (2x interval)
                if alignment > 0.75 or is_far_L1:
                    # 检查是否是 2 * interval 的倍数
                    is_even_step = (abs(val % (interval * 2)) < interval * 0.1) or \
                                   (abs(val % (interval * 2)) > interval * 1.9)
                    
                    if not is_even_step:
                        # 淡出这些点
                        progress_align = (alignment - 0.75) / 0.1 if alignment > 0.75 else 0.0
                        progress_dist = (distance - view_distance * 4.0) / (view_distance * 1.5) if is_far_L1 else 0.0
                        
                        progress = max(progress_align, progress_dist)
                        opacity_factor = 1.0 - utils._ease_smootherstep(min(1.0, max(0.0, progress)))
                        
                        if opacity_factor < 0.01:
                            return 0.0
                
                # Level 2 Check (10x interval)
                if alignment > 0.85 or is_far_L2:
                    # 检查是否是 10 * interval 的倍数
                    # 注意：此时剩下的已经是偶数倍了，我们进一步筛选
                    is_decade_step = (abs(val % (interval * 10)) < interval * 0.1) or \
                                     (abs(val % (interval * 10)) > interval * 9.9)
                    
                    if not is_decade_step:
                        # 淡出这些点
                        progress_align = (alignment - 0.85) / 0.1 if alignment > 0.85 else 0.0
                        progress_dist = (distance - view_distance * 8.0) / (view_distance * 3.0) if is_far_L2 else 0.0
                        
                        progress = max(progress_align, progress_dist)
                        factor_L2 = 1.0 - utils._ease_smootherstep(min(1.0, max(0.0, progress)))
                        
                        opacity_factor = min(opacity_factor, factor_L2)
                        if opacity_factor < 0.01:
                            return 0.0
                            
                # 同时应用动态距离裁剪 (Dynamic Depth Culling)
                # 仅当高角度对齐时，缩短可视距离以避免地平线拥挤
                if alignment > 0.8:
                    align_progress = (alignment - 0.8) / (0.98 - 0.8)
                    align_progress = min(1.0, max(0.0, align_progress))
                    # 减缓裁剪力度，避免过度裁剪
                    depth_scale = 1.0 - utils._ease_smootherstep(align_progress) * 0.5
                    fade_end *= depth_scale
                    fade_start *= depth_scale
                    if fade_start > fade_end: fade_start = fade_end * 0.8
                
                # 应用稀疏化透明度
                base_factor_dist = 1.0
                if distance > fade_start:
                    if distance > fade_end:
                        base_factor_dist = 0.0
                    else:
                        progress = (distance - fade_start) / (fade_end - fade_start)
                        base_factor_dist = 1.0 - utils._ease_smootherstep(progress)
                
                return base_factor_dist * opacity_factor

        # 距离判断 (标准情况)
        if distance < fade_start:
            return 1.0
        elif distance > fade_end:
            return 0.0
        else:
            progress = (distance - fade_start) / (fade_end - fade_start)
            return 1.0 - utils._ease_smootherstep(progress)

    def generate_grid_points(self, camera_location, view_distance, axis, region, rv3d, force_main_interval=None, origin_offset=Vector((0, 0, 0))):
        """Generates grid points for perspective view with a unified, ortho-like logic."""
        points = []
        view_distance_scene = self._to_scene_length(view_distance)
        
        # Determine main interval based on view_distance (zoom level)
        if force_main_interval:
            main_interval_scene = force_main_interval
        else:
            main_interval_scene = self.get_ortho_main_interval(view_distance)
        main_interval = self._from_scene_length(main_interval_scene)
            
        # --- NEW LOGIC START ---
        is_cm_scale = 0.01 <= main_interval_scene < 0.1 and self.unit_system == 'm'
        is_mm_scale = main_interval_scene < 0.01 and self.unit_system == 'm'
        
        format_func = self.get_format_func_for_interval(main_interval_scene)
        
        if is_cm_scale:
            # Special logic for Centimeter scale for clarity and meaningful subdivisions.
            sub_divisions = [0.5]  # Only show the half-cm mark for clarity.
        elif is_mm_scale:
            # Special logic for Millimeter scale: do not show any subdivisions.
            sub_divisions = []
        else:
            # Original logic for other scales (m, km, imperial)
            sub_divisions = []
            if main_interval_scene < 0.1: # Finer grids
                 if view_distance_scene < main_interval_scene * 15:
                    sub_divisions = [0.25, 0.5, 0.75]
                 else:
                    sub_divisions = [0.5]
            else: # Coarser grids
                 if view_distance_scene < main_interval_scene * 4:
                    sub_divisions = [0.25, 0.5, 0.75]
                 else:
                    sub_divisions = [0.5]
        # --- NEW LOGIC END ---
        
        # Get view bounds to determine the generation range
        bounds = utils.get_view_bounds(region, rv3d)
        if axis == 'X':
            min_bound, max_bound = bounds['min_x'], bounds['max_x']
            axis_index = 0
        elif axis == 'Y':
            min_bound, max_bound = bounds['min_y'], bounds['max_y']
            axis_index = 1
        else: # Z
            min_bound, max_bound = bounds['min_z'], bounds['max_z']
            axis_index = 2
        
        # Adjust bounds to be relative to origin
        min_bound -= origin_offset[axis_index]
        max_bound -= origin_offset[axis_index]
        
        # Expand bounds slightly to ensure we cover the whole view
        view_range = max_bound - min_bound
        min_bound -= view_range * 0.1
        max_bound += view_range * 0.1
        
        # Generate main points
        start = math.floor(min_bound / main_interval) * main_interval
        num_steps = int((max_bound - start) / main_interval) + 1
        
        # --- PERFORMANCE SAFEGUARD ---
        # At vast scales, num_steps can be huge, causing a freeze.
        # We cap the number of points and center them around the camera.
        MAX_STEPS = 1000
        if num_steps > MAX_STEPS:
            camera_coord_on_axis = getattr(camera_location, axis.lower())
            # Adjust camera coord to be relative
            camera_coord_on_axis -= origin_offset[axis_index]
            start = math.floor(camera_coord_on_axis / main_interval) * main_interval - (MAX_STEPS // 2) * main_interval
            num_steps = MAX_STEPS
        
        generated_points = []
        for i in range(int(num_steps)):
            coord = start + i * main_interval
            coord_display = self._to_scene_length(coord)
            pos = Vector((coord, 0, 0)) if axis == 'X' else Vector((0, coord, 0)) if axis == 'Y' else Vector((0, 0, coord))
            # Add origin offset to make pos absolute world coordinate
            pos += origin_offset
            generated_points.append({
                    'position': pos,
                    'is_sub': False,
                    'distance': (pos - camera_location).length,
                    'value': coord,
                'value_display': coord_display,
                'format': format_func,
                'interval': main_interval,
            })
            
        # Generate sub points
        for p in list(generated_points):
            if p['is_sub']: continue
            for ratio in sub_divisions:
                coord = p['value'] + main_interval * ratio
                coord_display = self._to_scene_length(coord)
                pos = Vector((coord, 0, 0)) if axis == 'X' else Vector((0, coord, 0)) if axis == 'Y' else Vector((0, 0, coord))
                # Add origin offset to make pos absolute world coordinate
                pos += origin_offset
                generated_points.append({
                        'position': pos,
                        'is_sub': True,
                        'distance': (pos - camera_location).length,
                        'value': coord,
                    'value_display': coord_display,
                    'format': format_func,
                    'interval': main_interval,
                })

        return generated_points

    def generate_ortho_grid_points(self, view_distance, axis, region, rv3d, view_orientation, force_main_interval=None, origin_offset=Vector((0, 0, 0))):
        """生成正交视图下的网格点"""
        points = []  # 初始化points列表
        current_view_distance_scene = self._to_scene_length(view_distance)
        # 获取视口边界
        bounds = utils.get_ortho_view_bounds(region, rv3d)
        
        # 根据轴选择对应的边界
        if axis == 'X':
            min_bound = bounds['min_x']
            max_bound = bounds['max_x']
            axis_index = 0
        elif axis == 'Y':
            min_bound = bounds['min_y']
            max_bound = bounds['max_y']
            axis_index = 1
        else:  # Z轴
            min_bound = bounds['min_z']
            max_bound = bounds['max_z']
            axis_index = 2

        # Adjust bounds to be relative to origin
        min_bound -= origin_offset[axis_index]
        max_bound -= origin_offset[axis_index]
        center_coord = (min_bound + max_bound) / 2
        
        # Adjust view distance for horizontal axis to account for aspect ratio, making density consistent
        is_axis_horizontal = (
            (view_orientation in ['TOP', 'BOTTOM', 'FRONT', 'BACK'] and axis == 'X') or
            (view_orientation in ['LEFT', 'RIGHT'] and axis == 'Y')
        )
        current_view_distance = view_distance
        if is_axis_horizontal and region.height > 0:
            current_view_distance = view_distance * (region.width / region.height)
        current_view_distance_scene = self._to_scene_length(current_view_distance)

        if force_main_interval:
            main_interval_scene = force_main_interval
        else:
            main_interval_scene = self.get_ortho_main_interval(view_distance)
        main_interval = self._from_scene_length(main_interval_scene)
        
        # 确定显示范围（半径，围绕中心）
        # 默认基于视距，扩大范围以支持远距离淡出
        display_range = current_view_distance * 4.0
        
        # 在自由正交视图下，基于轴在屏幕上的每单位像素长度，动态放大范围，
        # 以确保标注延伸到视口边缘并平滑淡出
        # 此时不再局限于 USER 视图，而是应用于所有正交视图，以解决标准视图旋转（如Top视图旋转Z轴）时的范围不足问题
        if True:
            try:
                view_center = rv3d.view_matrix.inverted().translation
                if axis == 'X':
                    axis_dir_world = Vector((1, 0, 0))
                elif axis == 'Y':
                    axis_dir_world = Vector((0, 1, 0))
                else:
                    axis_dir_world = Vector((0, 0, 1))
                p0_2d = location_3d_to_region_2d(region, rv3d, view_center)
                p1_2d = location_3d_to_region_2d(region, rv3d, view_center + axis_dir_world)
                if p0_2d is not None and p1_2d is not None:
                    pixels_per_unit = (p1_2d - p0_2d).length
                    if pixels_per_unit > 1e-4:
                        half_diag_px = math.hypot(region.width, region.height) * 0.5
                        projected_half_range = half_diag_px / pixels_per_unit
                        # 避免在几乎平行视轴时范围过大
                        projected_half_range = min(projected_half_range, current_view_distance * 6.0)
                        display_range = max(display_range, projected_half_range * 1.2)
            except Exception:
                pass
        
        # 在自由正交视图下，放宽基于世界坐标轴的 min/max 过滤，避免过早裁剪
        if True:
            min_bound = min(min_bound, center_coord - display_range)
            max_bound = max(max_bound, center_coord + display_range)
        
        # 计算轴对齐角度 (Alignment) 用于检测自由正交视图中的视角倾斜
        # 1.0 = 视线与轴平行 (轴是一个点，极度拥挤)
        # 0.0 = 视线与轴垂直 (轴是横跨屏幕的线，最清晰)
        alignment = 0.0
        try:
            view_dir = rv3d.view_rotation @ Vector((0, 0, -1))
            view_dir.normalize()
            if axis == 'X':
                axis_vec = Vector((1, 0, 0))
            elif axis == 'Y':
                axis_vec = Vector((0, 1, 0))
            else:
                axis_vec = Vector((0, 0, 1))
            alignment = abs(view_dir.dot(axis_vec))
        except Exception:
            pass
            
        # 根据间隔大小调整子刻度密度
        sub_divisions = []
        
        # 在毫米级别时禁用次级标注，因为它们在正交视图下不准确
        if main_interval_scene <= 0.001:  # 1mm或更小
            sub_divisions = []  # 禁用所有次级标注
        # 厘米级别的特殊处理
        elif main_interval_scene < 0.1:  # 厘米级别
            if current_view_distance_scene < 0.05:  # 非常近的距离
                sub_divisions = [0.2, 0.4, 0.6, 0.8]  # 显示所有子刻度
            elif current_view_distance_scene < 0.1:  # 较近的距离
                sub_divisions = [0.25, 0.5, 0.75]  # 减少子刻度
            elif current_view_distance_scene < 0.2:  # 中等距离
                sub_divisions = [0.5]  # 只显示中点
            else:  # 较远的距离
                sub_divisions = []  # 不显示子刻度
        # 毫米级别的特殊处理
        elif main_interval_scene < 0.01:  # 毫米级别（但大于1mm）
            if current_view_distance_scene < 0.01:  # 非常近的距离
                sub_divisions = [0.2, 0.4, 0.6, 0.8]  # 显示所有子刻度
            elif current_view_distance_scene < 0.015:  # 较近的距离
                sub_divisions = [0.25, 0.5, 0.75]  # 减少子刻度
            else:  # 较远的距离
                sub_divisions = [0.5]  # 只显示中点
        else:  # 其他级别
            sub_divisions = [0.5]  # 默认只显示中点
        
        # 定义标注层级
        levels = [
            {
                'interval': main_interval,
                'opacity': 1.0,
                'is_sub': False,
                'show_label': True,
                'label_interval': 1  # 每个刻度都显示标签
            }
        ]
        
        # 只有当有子刻度时才添加子刻度层级
        if sub_divisions:
            # 根据子刻度列表的第一个元素确定间隔比例
            # 例如: [0.2, 0.4, 0.6, 0.8] -> 0.2
            ratio = sub_divisions[0]
            sub_interval = main_interval * ratio
            
            # 计算每多少个子刻度对应一个主刻度
            steps = round(1.0 / ratio) if ratio > 0 else 2
            
            levels.append({
                'interval': sub_interval,
                'opacity': 0.6,
                'is_sub': True,
                'show_label': False,
                'label_interval': steps  # 实际上不显示标签，但这有助于逻辑一致性
            })
        
        # 选择合适的格式化函数
        format_func = self.get_format_func_for_interval(main_interval_scene)
        
        # 生成所有层级的刻度
        for level in levels:
            interval = level['interval']
            start = math.floor(center_coord / interval) * interval
            num_steps = int(display_range / interval)
            
            for i in range(-num_steps, num_steps + 1):
                coord = start + i * interval
                coord_display = self._to_scene_length(coord)
                
                # 跳过超出范围的点
                if coord < min_bound or coord > max_bound:
                    continue
                
                # 计算到视口中心的距离
                dist_to_center = abs(coord - center_coord)
                
                # --- 分级淡出与密度控制 (Staged Fade & Distance LOD) ---
                # 结合 距离(Distance) 和 角度(Alignment) 进行综合控制
                
                # 定义相对距离比例
                dist_ratio = dist_to_center / display_range
                
                # 0. 基础过滤：完全超出范围
                if dist_ratio > 1.0:
                    continue

                opacity_factor = 1.0
                
                # 1. 次级刻度优先淡出 (Sub-ticks fade)
                # 触发条件：距离远 OR 视角倾斜
                if level['is_sub']:
                    # 距离淡出 (0.6 -> 1.0)
                    progress_dist = (dist_ratio - 0.6) / 0.15 if dist_ratio > 0.6 else 0.0
                    
                    # 角度淡出 (alignment > 0.6 -> 1.0)
                    progress_align = (alignment - 0.6) / 0.15 if alignment > 0.6 else 0.0
                    
                    # 取两者最大进度
                    progress = max(progress_dist, progress_align)
                    
                    if progress > 0:
                        opacity_factor = 1.0 - utils._ease_smootherstep(min(1.0, progress))
                        if opacity_factor < 0.01:
                            continue # 直接跳过
                
                # 2. 主刻度间隔淡出 (Major ticks interval fade)
                else:
                    val = abs(coord)
                    
                    # Level 1 Check (2x interval)
                    # 触发条件：距离 > 0.75 OR 角度 > 0.75
                    if dist_ratio > 0.75 or alignment > 0.75:
                        # 检查是否是 2 * interval 的倍数
                        is_even_step = (abs(val % (interval * 2)) < interval * 0.1) or \
                                       (abs(val % (interval * 2)) > interval * 1.9)
                        
                        if not is_even_step:
                             progress_dist = (dist_ratio - 0.75) / 0.1 if dist_ratio > 0.75 else 0.0
                             progress_align = (alignment - 0.75) / 0.1 if alignment > 0.75 else 0.0
                             progress = max(progress_dist, progress_align)
                             
                             opacity_factor = 1.0 - utils._ease_smootherstep(min(1.0, progress))
                             if opacity_factor < 0.01:
                                 continue

                    # Level 2 Check (10x interval)
                    # 触发条件：距离 > 0.85 OR 角度 > 0.85
                    if dist_ratio > 0.85 or alignment > 0.85:
                        # 检查是否是 10 * interval 的倍数
                        is_decade_step = (abs(val % (interval * 10)) < interval * 0.1) or \
                                         (abs(val % (interval * 10)) > interval * 9.9)
                        
                        if not is_decade_step:
                            progress_dist = (dist_ratio - 0.85) / 0.1 if dist_ratio > 0.85 else 0.0
                            progress_align = (alignment - 0.85) / 0.1 if alignment > 0.85 else 0.0
                            progress = max(progress_dist, progress_align)
                            
                            factor_L2 = 1.0 - utils._ease_smootherstep(min(1.0, progress))
                            opacity_factor = min(opacity_factor, factor_L2)
                            if opacity_factor < 0.01:
                                continue

                # 3. 全局淡出 (Global Fade)
                # 推迟淡出：0.8 ~ 1.0 (仅基于距离，因为角度淡出已通过稀疏化处理)
                fade_start_ratio = 0.8
                fade_end_ratio = 1.0
                
                fade_factor = 1.0
                if dist_ratio > fade_start_ratio:
                    progress = (dist_ratio - fade_start_ratio) / (fade_end_ratio - fade_start_ratio)
                    fade_factor = 1.0 - utils._ease_smootherstep(progress)
                
                # 组合透明度
                final_fade = fade_factor * opacity_factor
                
                if final_fade < 0.01:
                    continue
                
                if level['is_sub']:
                    final_fade *= 0.8  # 次要标注基础透明度略低
                
                # 决定是否显示标签
                show_label = level['show_label'] and (i % level['label_interval'] == 0)
                
                # 避免重叠：检查附近是否有更高级别的标注
                skip = False
                if level['is_sub']:
                    for higher_level in levels[:levels.index(level)]:
                        higher_interval = higher_level['interval']
                        nearest_major = round(coord / higher_interval) * higher_interval
                        if abs(coord - nearest_major) < higher_interval * 0.1:  # 如果太靠近主刻度，跳过
                            skip = True
                            break
                
                if skip:
                    continue
                
                # 创建标注点
                pos = Vector((coord, 0, 0)) if axis == 'X' else \
                      Vector((0, coord, 0)) if axis == 'Y' else \
                      Vector((0, 0, coord))
                
                # Add origin offset to make pos absolute world coordinate
                pos += origin_offset
                
                # 在正交视图下过滤1mm内的次标注
                # 注意：我们不再在这里过滤0点，而是交给draw函数处理，以便支持edge_snap_always
                if level['is_sub'] and abs(coord_display) < 0.001:
                    continue
                
                points.append({
                    'position': pos,
                    'level': 'ortho',
                    'is_sub': level['is_sub'],
                    'distance': current_view_distance,
                    'value': coord,
                    'value_display': coord_display,
                    'format': format_func,
                    'interval': interval,
                    'transition_factor': level['opacity'] * final_fade,
                    'show_label': show_label
                })
        
        return points

    def get_ortho_main_interval(self, view_distance):
        """Determine the main grid interval for ortho view based on view distance."""
        # 基础间隔基于视距的 10%
        base_interval = self._to_scene_length(view_distance) * 0.1
        
        # --- 基于字号的密度自适应 (Font Size Density Adjustment) ---
        # 当字号增大时，单个标注占据的屏幕空间变大，需要更大的间隔来避免重叠
        # 基准字号设为 12 (或 self.font_size 的默认值)
        # 如果当前字号 > 12，则成比例放大 base_interval
        
        # 获取当前配置的字号
        current_font_size = self.font_size
        default_font_size = 12
        
        if current_font_size > default_font_size:
            # 计算放大倍率，例如 24px -> 2.0x
            scale_ratio = current_font_size / default_font_size
            # 应用倍率到基础间隔检测阈值
            # 这样 base_interval 变大，会倾向于选择更大的 standard_interval
            base_interval *= scale_ratio

        if self.unit_system == 'm':
            # 标准间隔序列
            standard_intervals = [
                0.001, 0.002, 0.005,  # mm级别
                0.01, 0.02, 0.05,     # cm级别
                0.1, 0.2, 0.5,        # dm级别
                1.0, 2.0, 5.0,        # m级别
                10.0, 20.0, 50.0,     # 10m级别
                100.0, 200.0, 500.0,  # 100m级别
                1000.0                 # km级别
            ]
        else:
            # 优化后的英制单位标准间隔序列
            standard_intervals = [
                0.00635, 0.0127,      # 1/4, 1/2 inch
                0.0254, 0.0508, 0.1524, # 1, 2, 6 inches
                0.3048, 0.6096, 1.524,  # 1, 2, 5 feet
                3.048, 6.096, 15.24,   # 10, 20, 50 feet
                30.48, 60.96, 152.4,  # 100, 200, 500 feet
                304.8, 609.6, 1524.0,  # 1k, 2k, 5k feet
                3048.0                 # 10k feet
            ]
        
        # 选择主间隔
        main_interval = standard_intervals[0]
        for interval in standard_intervals:
            if interval > base_interval:
                break
            main_interval = interval
            
        # --- Hysteresis (滞后处理) 防止视距抖动导致间隔频繁切换 ---
        # 如果我们已经有了一个激活的间隔，只有当新的计算结果显著偏离时才切换
        if self.last_main_interval is not None and main_interval != self.last_main_interval:
            # 计算切换方向
            if main_interval > self.last_main_interval:
                # 正在向上切换 (Zooming Out)
                # 要求 base_interval 必须显著大于触发阈值 (即 main_interval 本身)
                # 防止在临界点反复横跳
                if base_interval < main_interval * 1.05:
                    return self.last_main_interval
            else:
                # 正在向下切换 (Zooming In)
                # 我们选择 main_interval 是因为 standard_intervals 中的下一个值大于 base_interval
                # 也就是说 base_interval 已经降到了 self.last_main_interval 之下
                # 允许保持当前间隔，直到 base_interval 显著变小
                if base_interval > self.last_main_interval * 0.95:
                    return self.last_main_interval
                    
        return main_interval

    def get_stable_transform(self, pos_2d, text):
        key = f"{text}_{int(pos_2d.x/20)}_{int(pos_2d.y/20)}"
        
        # 根据轴类型决定存储在哪个缓存中
        axis = 'X' if 'x' in text.lower() else ('Y' if 'y' in text.lower() else 'Z')
        cache = self.last_positions[axis]
        
        if key in cache:
            try:
                last_pos = cache.pop(key)
                pos_2d = Vector((
                    utils.smooth_value(pos_2d.x, last_pos.x, self.position_memory),
                    utils.smooth_value(pos_2d.y, last_pos.y, self.position_memory)
                ))
            except Exception as e:
                logger.exception(f"Error smoothing position for key: {key}, Error: {e}")
        
        cache[key] = pos_2d.copy()
        if len(cache) > 800:
            removed_key, removed_value = cache.popitem(last=False)
            logger.debug(f'Removed {axis} axis cached position: {removed_key}')
            
        return pos_2d

    def get_format_func_for_interval(self, interval):
        """Gets a formatting function based on the interval size."""
        
        # 使用 utils.format_distance 处理所有格式化逻辑
        def formatter(x):
            return utils.format_distance(x, self.unit_system, self.unit_display_mode)
            
        return formatter

    def trigger_unsnap_animation(self):
        """
        当 "边线吸附" 被禁用时，为所有当前吸附的标注触发一个动画，
        让它们平滑地返回到其原始位置。
        """
        animation_triggered = False
        # 遍历所有被跟踪的过渡状态，并启动"解除吸附"动画
        for key, data in self.edge_snap_transitions.items():
            if data['is_snapping']:
                # 将状态设置为"非吸附"，并重置开始时间，
                # 以此触发从边缘移开的过渡动画。
                self.edge_snap_transitions[key] = {
                    'start_time': time.time(),
                    'is_snapping': False
                }
                animation_triggered = True
        
        if animation_triggered:
            self.start_animation_timer()

    def is_animating(self):
        """检查是否有任何动画正在进行"""
        # 检查视图缩放过渡
        if self.transition_info['active']:
            if time.time() - self.transition_info['start_time'] < self.transition_duration:
                return True
        
        # 检查边缘吸附过渡
        for data in self.edge_snap_transitions.values():
            if time.time() - data['start_time'] < self.edge_snap_duration:
                return True
        
        return False

    def animation_timer_callback(self, *args):
        """定时器回调，在动画期间强制重绘"""
        if not self.active or not self.area:
            if self.timer_callback_partial and bpy.app.timers.is_registered(self.timer_callback_partial):
                bpy.app.timers.unregister(self.timer_callback_partial)
            self.timer_callback_partial = None
            return None

        if self.is_animating():
            self.area.tag_redraw()
            return 0.016  # 大约 1/60s 后再次运行
        else:
            self.area.tag_redraw() # 最后一次重绘
            self.timer_callback_partial = None
            return None # 停止定时器
    
    def start_animation_timer(self):
        """如果尚无定时器在运行，则启动一个以处理动画重绘"""
        if self.timer_callback_partial is None:
            # 使用 functools.partial 来传递 self 实例
            self.timer_callback_partial = partial(self.animation_timer_callback, self)
            bpy.app.timers.register(self.timer_callback_partial, persistent=True)

def update_overlay():
    """
    更新所有激活的覆盖层设置。
    """
    # 首先清理无效的 overlay
    SmartMeasureGridOverlay.cleanup_invalid_overlays()
    
    for overlay in list(SmartMeasureGridOverlay.overlays.values()):
        overlay.update_settings(bpy.context.scene)
