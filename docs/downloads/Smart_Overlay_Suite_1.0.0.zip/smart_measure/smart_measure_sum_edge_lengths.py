# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import bpy
import bmesh
from bpy.app.translations import pgettext_iface as _

class Sum_Edge_Lengths(bpy.types.Operator):
    bl_idname = "mesh.smart_measure_sum_edge_lengths"
    bl_label = "Sum Edge Length"
    bl_description = "Measure the total length of the currently selected mesh edges in Edit Mode and report the result in the active scene units."
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    @classmethod
    def poll(cls, context):
        try:
            obj = getattr(context, 'object', None)
            return bool(obj is not None and getattr(obj, 'type', None) == 'MESH' and str(getattr(context, 'mode', '') or '') == 'EDIT_MESH')
        except Exception:
            return False

    def execute(self, context):
        obj = getattr(context, 'object', None)
        if obj is None or getattr(obj, 'type', None) != 'MESH':
            self.report({'WARNING'}, _("No mesh object selected"))
            return {'CANCELLED'}

        try:
            bm = bmesh.from_edit_mesh(obj.data)
        except Exception:
            self.report({'WARNING'}, _("No editable mesh data found"))
            return {'CANCELLED'}
        matrix = obj.matrix_world
        total_length = sum(((matrix @ e.verts[0].co) - (matrix @ e.verts[1].co)).length for e in bm.edges if e.select)
        
        # Adjust for unit scale
        unit_settings = context.scene.unit_settings
        unit_scale = unit_settings.scale_length
        total_length *= unit_scale
        
        # Convert to the appropriate unit
        if unit_settings.length_unit == 'METERS':
            unit_length = 'm'
        elif unit_settings.length_unit == 'CENTIMETERS':
            total_length *= 100
            unit_length = 'cm'
        elif unit_settings.length_unit == 'MILLIMETERS':
            total_length *= 1000
            unit_length = 'mm'
        elif unit_settings.length_unit == 'KILOMETERS':
            total_length /= 1000
            unit_length = 'km'
        elif unit_settings.length_unit == 'INCHES':
            total_length *= 39.3701
            unit_length = 'in'
        elif unit_settings.length_unit == 'FEET':
            total_length *= 3.28084
            unit_length = 'ft'
        elif unit_settings.length_unit == 'MILES':
            total_length /= 1609.34
            unit_length = 'mi'
        else:
            unit_length = 'm'  # Default to meters if unit is unknown
        
        label = _("Total Edge Length")
        context.workspace.status_text_set(f"{label}: {total_length:.3f} {unit_length}")
        self.report({'INFO'}, f"{label}: {total_length:.3f} {unit_length}")
        return {'FINISHED'}

def menu_func(self, context):
    self.layout.operator(Sum_Edge_Lengths.bl_idname)