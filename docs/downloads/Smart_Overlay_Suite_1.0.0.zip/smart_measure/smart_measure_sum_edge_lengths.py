"""Measure selected mesh edges in scene units using the live edit mesh."""

from math import fsum

import bmesh
import bpy
from bpy.app.translations import pgettext_iface as translate


_SCENE_UNITS = {
    'KILOMETERS': (0.001, 'km'),
    'METERS': (1.0, 'm'),
    'CENTIMETERS': (100.0, 'cm'),
    'MILLIMETERS': (1000.0, 'mm'),
    'MICROMETERS': (1000000.0, 'µm'),
    'INCHES': (1 / 0.0254, 'in'),
    'FEET': (1 / 0.3048, 'ft'),
    'MILES': (1 / 1609.344, 'mi'),
    'THOU': (1 / 0.0000254, 'thou'),
}


class Sum_Edge_Lengths(bpy.types.Operator):
    bl_idname = 'mesh.smart_measure_sum_edge_lengths'
    bl_label = 'Sum Edge Length'
    bl_description = 'Measure the total length of the currently selected mesh edges in Edit Mode and report the result in the active scene units.'
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    @classmethod
    def poll(cls, context):
        return context.edit_object is not None and context.mode == 'EDIT_MESH'

    def execute(self, context):
        edit_mesh = bmesh.from_edit_mesh(context.edit_object.data)
        transform = context.edit_object.matrix_world.to_3x3()
        meters = fsum(
            (transform @ (edge.verts[1].co - edge.verts[0].co)).length
            for edge in edit_mesh.edges
            if edge.select
        ) * context.scene.unit_settings.scale_length
        multiplier, symbol = _SCENE_UNITS.get(context.scene.unit_settings.length_unit, (1.0, 'm'))
        message = f'{translate("Total Edge Length")}: {meters * multiplier:.3f} {symbol}'
        if context.workspace is not None:
            context.workspace.status_text_set(message)
        self.report({'INFO'}, message)
        return {'FINISHED'}


def menu_func(self, _context):
    self.layout.operator(Sum_Edge_Lengths.bl_idname)
