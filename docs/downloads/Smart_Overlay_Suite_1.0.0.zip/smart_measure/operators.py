# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package


import bpy
import logging
from .utils import log_once as _log_once
from bpy.app.translations import pgettext_iface as _

from . import overlay
from . import utils

logger = logging.getLogger(__name__)

class SmartMeasureGridStartOperator(bpy.types.Operator):
    """启动网格尺寸标注"""
    bl_idname = "view3d.smart_measure_grid_start"
    bl_label = "Start Smart Measure"
    bl_description = "Show Smart Measure spacing annotations"
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    def execute(self, context):
        if context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, _("Current area is not a 3D View."))
            return {'CANCELLED'}
        if overlay.SmartMeasureGridOverlay.is_overlay_active(context.area):
            self.report({'INFO'}, _("Smart Measure overlay is already active."))
            return {'CANCELLED'}
        
        # 创建并注册覆盖层
        ov = overlay.SmartMeasureGridOverlay(context.area)
        ov.register(self.report)
        
        # 保存激活的视口ID到场景设置
        area_id = utils.get_stable_area_id(context.area)
        settings = getattr(context.scene, 'smart_measure_grid', None)
        if settings is not None:
            active_areas = settings.active_areas
            if active_areas:
                # 检查ID是否已存在
                area_ids = active_areas.split(',')
                if area_id not in area_ids:
                    area_ids.append(area_id)
                    settings.active_areas = ','.join(area_ids)
            else:
                settings.active_areas = area_id
        
        if settings is not None:
            logger.info(f'添加区域 {area_id} 到激活区域列表: {settings.active_areas}')
        return {'FINISHED'}

class SmartMeasureGridStopOperator(bpy.types.Operator):
    """停止网格尺寸标注"""
    bl_idname = "view3d.smart_measure_grid_stop"
    bl_label = "Stop Smart Measure"
    bl_description = "Hide Smart Measure spacing annotations"
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    def execute(self, context):
        if context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, _("Current area is not a 3D View."))
            return {'CANCELLED'}
        
        ov = overlay.SmartMeasureGridOverlay.overlays.get(context.area.as_pointer())
        if ov:
            ov.unregister()
            
            # 从激活列表中移除该视口ID
            area_id = utils.get_stable_area_id(context.area)
            settings = getattr(context.scene, 'smart_measure_grid', None)
            if settings is not None:
                active_areas = settings.active_areas
                if active_areas:
                    area_ids = active_areas.split(',')
                    if area_id in area_ids:
                        area_ids.remove(area_id)
                        settings.active_areas = ','.join(area_ids)
                        logger.info(f'从激活区域列表中移除区域 {area_id}: {settings.active_areas}')
            
            self.report({'INFO'}, _("Smart Measure overlay has been stopped."))
        else:
            self.report({'WARNING'}, _("Smart Measure overlay is not active."))
        return {'FINISHED'}

class SmartMeasureGridAnimationPrevOperator(bpy.types.Operator):
    bl_idname = "view3d.smart_measure_grid_animation_prev"
    bl_label = "Previous Animation Style"
    bl_description = "Switch to previous animation style"
    bl_options = {'INTERNAL', 'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    def execute(self, context):
        settings = getattr(context.scene, 'smart_measure_grid', None)
        if settings is None:
            return {'CANCELLED'}
        order = ['1', '2', '3']
        try:
            idx = order.index(settings.animation_style)
        except ValueError:
            idx = 0
        new_value = order[(idx - 1) % len(order)]
        settings.animation_style = new_value
        return {'FINISHED'}

class SmartMeasureGridAnimationNextOperator(bpy.types.Operator):
    bl_idname = "view3d.smart_measure_grid_animation_next"
    bl_label = "Next Animation Style"
    bl_description = "Switch to next animation style"
    bl_options = {'INTERNAL', 'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    def execute(self, context):
        settings = getattr(context.scene, 'smart_measure_grid', None)
        if settings is None:
            return {'CANCELLED'}
        order = ['1', '2', '3']
        try:
            idx = order.index(settings.animation_style)
        except ValueError:
            idx = 0
        new_value = order[(idx + 1) % len(order)]
        settings.animation_style = new_value
        return {'FINISHED'}

class SmartMeasureGridSetOriginOperator(bpy.types.Operator):
    """将网格原点设置为3D游标位置"""
    bl_idname = "view3d.smart_measure_grid_set_origin"
    bl_label = "Set Origin to 3D Cursor"
    bl_description = "Set the manual origin location to the 3D Cursor position"
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    def execute(self, context):
        settings = getattr(context.scene, 'smart_measure_grid', None)
        if settings:
            settings.manual_origin_location = context.scene.cursor.location
            settings.use_manual_origin = True
            self.report({'INFO'}, f"{_('Grid origin set to')} {settings.manual_origin_location}")
        return {'FINISHED'}

# 添加一个保存当前状态的函数，在插件卸载前调用
def save_overlay_states():
    """保存当前所有激活的覆盖层状态"""
    try:
        logger.info("保存当前覆盖层状态...")
        # 当前没有必要额外保存，因为状态已经在操作符中实时更新到scene.smart_measure_grid.active_areas
    except Exception as e:
        _log_once(logger, 'exception', f"保存覆盖层状态时出错: {e}")

# 添加一个函数来更新区域ID格式
def update_area_id_format(old_id, new_id):
    """
    在所有场景中更新区域ID的格式
    """
    try:
        for scene in bpy.data.scenes:
            settings = getattr(scene, 'smart_measure_grid', None)
            if not settings:
                continue
            active_areas = settings.active_areas
            if active_areas and old_id in active_areas:
                area_ids = active_areas.split(',')
                if old_id in area_ids:
                    area_ids.remove(old_id)
                    if new_id not in area_ids:
                        area_ids.append(new_id)
                    scene.smart_measure_grid.active_areas = ','.join(area_ids)
                    logger.info(f"更新区域ID格式: {old_id} -> {new_id}")
    except Exception as e:
        _log_once(logger, 'error', f"更新区域ID格式失败: {old_id} -> {new_id}, 错误: {e}")

# 清理区域ID列表，移除无效的ID
def clean_area_ids():
    """
    清理所有场景中的区域ID列表，移除无效的ID
    """
    # UI 可能尚未就绪或在后台模式下，避免访问 screens 导致 AttributeError
    if getattr(bpy.app, "background", False) or not hasattr(bpy.data, "screens"):
        return
    try:
        # 收集所有有效的区域ID
        valid_ids = set()
        for screen in bpy.data.screens:
            for i, area in enumerate(screen.areas):
                if area.type == 'VIEW_3D':
                    valid_ids.add(f"{screen.name}:{area.type}:{i}")
        
        # 更新所有场景的区域ID列表
        for scene in bpy.data.scenes:
            settings = getattr(scene, 'smart_measure_grid', None)
            if not settings:
                continue
            active_areas = settings.active_areas
            if active_areas:
                area_ids = active_areas.split(',')
                # 过滤出有效的ID和临时ID
                valid_area_ids = [id for id in area_ids if id in valid_ids or id.startswith('temp:')]
                if len(valid_area_ids) != len(area_ids):
                    settings.active_areas = ','.join(valid_area_ids)
                    logger.info(f"清理区域ID列表: {len(area_ids)} -> {len(valid_area_ids)}")
    except Exception as e:
        _log_once(logger, 'error', f"清理区域ID列表失败: {e}")

# 修改恢复函数以支持多种格式的区域ID
def restore_active_overlays():
    """在Blender启动时恢复之前激活的网格尺寸标注"""
    try:
        # 延迟执行以确保所有区域都已加载
        def delayed_restore():
            logger.info("开始恢复激活的网格尺寸标注...")
            
            # 收集所有需要激活的区域ID
            active_area_ids = []
            for scene in bpy.data.scenes:
                settings = getattr(scene, 'smart_measure_grid', None)
                if not settings:
                    continue
                active_areas = settings.active_areas
                if active_areas:
                    ids = active_areas.split(',')
                    active_area_ids.extend(ids)
                    logger.info(f"从场景 '{scene.name}' 中找到激活区域: {ids}")
            
            if not active_area_ids:
                logger.info("没有找到需要恢复的激活区域")
                return
            
            logger.info(f"需要恢复的区域总数: {len(active_area_ids)}")
            
            # 转换旧格式的区域ID为新格式
            converted_ids = []
            for area_id in active_area_ids:
                # 检查是否是旧格式 "屏幕名称:索引:类型"
                parts = area_id.split(':')
                if len(parts) == 3 and parts[2] == 'VIEW_3D' and parts[1].isdigit():
                    # 转换为新格式 "屏幕名称:类型:索引"
                    converted_id = f"{parts[0]}:VIEW_3D:{parts[1]}"
                    converted_ids.append(converted_id)
                    logger.info(f"转换区域ID格式: {area_id} -> {converted_id}")
                else:
                    converted_ids.append(area_id)
            
            # 合并原始ID和转换后的ID
            all_ids = set(active_area_ids + converted_ids)
            logger.info(f"合并后的区域ID: {all_ids}")
            
            # 遍历所有屏幕和区域，查找匹配的区域
            restored_count = 0
            for screen in bpy.data.screens:
                logger.info(f"检查屏幕: {screen.name}")
                for i, area in enumerate(screen.areas):
                    if area.type == 'VIEW_3D':
                        # 生成多种可能的ID格式
                        area_id_new = f"{screen.name}:{area.type}:{i}"
                        area_id_old = f"{screen.name}:{i}:{area.type}"
                        area_id_temp = f"temp:{area.as_pointer()}"
                        
                        logger.info(f"  检查区域: {area_id_new}")
                        
                        # 检查所有可能的ID格式
                        if area_id_new in all_ids or area_id_old in all_ids or area_id_temp in all_ids:
                            logger.info(f"  找到匹配的区域: {area_id_new}")
                            
                            if not overlay.SmartMeasureGridOverlay.is_overlay_active(area):
                                logger.info(f"  正在恢复覆盖层: {area_id_new}")
                                try:
                                    ov = overlay.SmartMeasureGridOverlay(area)
                                    ov.register(lambda x, y: None)  # 使用空报告函数
                                    restored_count += 1
                                    logger.info(f"  成功恢复覆盖层: {area_id_new}")
                                    
                                    # 更新区域ID为新格式
                                    update_area_id_format(area_id_old, area_id_new)
                                    update_area_id_format(area_id_temp, area_id_new)
                                except Exception as e:
                                    _log_once(logger, 'error', f"  恢复覆盖层失败: {area_id_new}, 错误: {e}")
                            else:
                                logger.info(f"  覆盖层已经激活: {area_id_new}")
            
            logger.info(f"恢复完成，成功恢复 {restored_count} 个覆盖层")
            
            # 如果没有成功恢复任何覆盖层，尝试再次延迟执行
            if restored_count == 0 and len(all_ids) > 0:
                logger.info("没有成功恢复任何覆盖层，将在1秒后再次尝试")
                return 1.0  # 返回1.0表示1秒后再次执行
            
            return None  # 返回None表示不再执行
        
        # 使用定时器延迟执行，增加延迟时间到1秒，确保Blender完全加载
        bpy.app.timers.register(delayed_restore, first_interval=1.0, persistent=True)
        logger.info("已注册恢复定时器")
    except Exception as e:
        _log_once(logger, 'exception', f"注册恢复定时器时出错: {e}")
