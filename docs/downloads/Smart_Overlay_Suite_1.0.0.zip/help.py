# SPDX-License-Identifier: GPL-3.0-or-later
"""Open the selected local help topic without initializing help on startup."""

import bpy


_HELP_POPUP_WIDTH_PX = 860


def _is_japanese(context=None):
    for scope in (context, bpy.context):
        view = getattr(getattr(scope, "preferences", None), "view", None)
        language = str(getattr(view, "language", "") or "").lower()
        if language.startswith("ja") or language == "jp":
            return True
    locale = getattr(bpy.app.translations, "locale", "")
    return locale.lower().startswith("ja")


def _L(context, en, ja):
    return str(ja if _is_japanese(context) else en)


class SOS_OT_ToolHelpPopup(bpy.types.Operator):
    bl_idname = "view3d.sos_tool_help"
    bl_label = "Smart Overlay Help"
    bl_description = "Open detailed help for this Smart Overlay tool."
    bl_options = {"INTERNAL"}

    topic: bpy.props.StringProperty(name="Help Topic", default="", options={"HIDDEN", "SKIP_SAVE"})

    @classmethod
    def description(cls, context, properties):
        return _L(
            context,
            "Open a popup with the feature overview, usage steps, and complete setting-item explanations for this tool.",
            "このツールの機能概要、使用方法、全設定項目の解説をポップアップで表示します。",
        )

    def invoke(self, context, event):
        try:
            from . import help_content
            if not help_content.has_topic(self.topic):
                self.report({"WARNING"}, _L(context, "Help topic was not found.", "ヘルプ項目が見つかりません。"))
                return {"CANCELLED"}
            type(self).bl_label = help_content.topic_label(self.topic, context)
        except Exception:
            self.report({"WARNING"}, _L(context, "Help could not be opened.", "ヘルプを開けませんでした。"))
            return {"CANCELLED"}
        self._sos_popup_width_px = _HELP_POPUP_WIDTH_PX
        window = context.window_manager
        try:
            return window.invoke_popup(self, width=self._sos_popup_width_px)
        except RuntimeError:
            return window.invoke_props_dialog(self, width=self._sos_popup_width_px)

    def draw(self, context):
        from . import help_content
        try:
            help_content.draw_help(self.layout, context, self.topic,
                                   popup_width_px=getattr(self, "_sos_popup_width_px", _HELP_POPUP_WIDTH_PX))
        except Exception:
            self.layout.box().label(text=_L(context, "Help could not be drawn.", "ヘルプを描画できませんでした。"),
                                    icon="ERROR")

    def execute(self, context):
        return {"FINISHED"}


CLASSES = (SOS_OT_ToolHelpPopup,)
