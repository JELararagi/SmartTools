# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Startup-light Help operator for Smart Overlay.

All help-popup text, layout, wrapping, and icon drawing are intentionally kept
in help_content.py.  This module registers only a small operator and imports the
heavy help catalog after a user clicks a Help icon.
"""

from __future__ import annotations

import bpy


def _is_japanese(context=None) -> bool:
    candidates = []
    for getter in (
        lambda: getattr(getattr(getattr(context, 'preferences', None), 'view', None), 'language', ''),
        lambda: getattr(getattr(getattr(bpy.context, 'preferences', None), 'view', None), 'language', ''),
        lambda: getattr(getattr(bpy.app, 'translations', None), 'locale', ''),
    ):
        try:
            value = str(getter() or '')
        except Exception:
            value = ''
        if value:
            candidates.append(value.upper())
    joined = ' '.join(candidates)
    return any(token in joined for token in ('JA', 'JA_JP', 'JAPANESE', 'JP'))


def _L(context, en: str, ja: str) -> str:
    return str(ja if _is_japanese(context) else en)


_HELP_POPUP_WIDTH_PX = 860


class SOS_OT_ToolHelpPopup(bpy.types.Operator):
    bl_idname = 'view3d.sos_tool_help'
    bl_label = 'Smart Overlay Help'
    bl_description = 'Open detailed help for this Smart Overlay tool.'
    bl_options = {'INTERNAL'}

    topic: bpy.props.StringProperty(
        name='Help Topic',
        description='Internal help topic key used to open the matching Smart Overlay help page.',
        default='',
        options={'HIDDEN', 'SKIP_SAVE'},
    )

    @classmethod
    def description(cls, context, properties):
        del cls, properties
        return _L(
            context,
            'Open a popup with the feature overview, usage steps, and complete setting-item explanations for this tool.',
            'このツールの機能概要、使用方法、全設定項目の解説をポップアップで表示します。',
        )

    def invoke(self, context, event):
        del event
        try:
            from . import help_content
            topic = str(getattr(self, 'topic', '') or '')
            if not help_content.has_topic(topic):
                self.report({'WARNING'}, _L(context, 'Help topic was not found.', 'ヘルプ項目が見つかりません。'))
                return {'CANCELLED'}
            type(self).bl_label = help_content.topic_label(topic, context)
        except Exception as exc:
            self.report({'WARNING'}, _L(context, 'Help could not be opened.', 'ヘルプを開けませんでした。'))
            return {'CANCELLED'}
        try:
            self._sos_popup_width_px = _HELP_POPUP_WIDTH_PX
            return context.window_manager.invoke_popup(self, width=_HELP_POPUP_WIDTH_PX)
        except Exception:
            return context.window_manager.invoke_props_dialog(self, width=_HELP_POPUP_WIDTH_PX)

    def draw(self, context):
        try:
            from . import help_content
            help_content.draw_help(
                self.layout,
                context,
                str(getattr(self, 'topic', '') or ''),
                popup_width_px=int(getattr(self, '_sos_popup_width_px', _HELP_POPUP_WIDTH_PX)),
            )
        except Exception as exc:
            box = self.layout.box()
            box.label(text=_L(context, 'Help could not be drawn.', 'ヘルプを描画できませんでした。'), icon='ERROR')

    def execute(self, context):
        del context
        return {'FINISHED'}


CLASSES = (SOS_OT_ToolHelpPopup,)
