# SPDX-License-Identifier: GPL-3.0-or-later
# Blender Extension / user_default compatible package
# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi
#  Official Contact: 
#  Video Tutorials: 
#
#  This file is part of the Smart Overlay Suite package.
#  Licensed under the GNU General Public License v3.0 or later
#  (GPL-3.0-or-later).
# ------------------------------------------------------------------------------

import bpy
import json

from .translation import TI, TT, T
from . import preferences as prefs_module
from . import registry
from . import feature_toggle
from . import icons as sos_icons

PANEL_TAB_NAME = "Smart Overlay"
# Use Blender's exact visible category text.  Zero-width category suffixes can
# leave Blender's Sidebar category cache with no matching tab after workspace or
# screen rebuilds.  Smart_Tools_Manager compatibility is handled by the poll and
# bridge-panel fallback below instead of by changing the category string.
PANEL_NATIVE_CATEGORY = PANEL_TAB_NAME


def _sos_current_panel_owner_id() -> str:
    try:
        from . import common as _sos_common
        fn = getattr(_sos_common, 'current_addon_owner_id', None)
        if callable(fn):
            value = str(fn() or '').strip()
            if value:
                return value
    except Exception:
        pass
    return str(__package__ or 'smart_overlay_suite').strip() or 'smart_overlay_suite'


PANEL_OWNER_ID = _sos_current_panel_owner_id()


def _sos_workspace_filter_allows(context=None) -> bool:
    try:
        from . import common as _sos_common
        fn = getattr(_sos_common, 'workspace_filter_allows_addon', None)
        if callable(fn):
            return bool(fn(context))
    except Exception:
        pass
    return True


def _sos_apply_panel_owner(cls) -> None:
    try:
        if isinstance(cls, type) and issubclass(cls, bpy.types.Panel):
            setattr(cls, 'bl_owner_id', _sos_current_panel_owner_id())
    except Exception:
        pass


def _sos_is_external_manager_panel(cls) -> bool:
    try:
        if bool(getattr(cls, '_smart_tools_manager_anchor', False)) or bool(getattr(cls, '_smart_tools_manager_proxy', False)):
            return True
        module_name = str(getattr(cls, '__module__', '') or '').lower()
        return 'smart_tools_manager' in module_name
    except Exception:
        return False


def _sos_class_is_suite_owned(cls) -> bool:
    if not isinstance(cls, type):
        return False
    try:
        receipts = bpy.app.driver_namespace.get('SMART_OVERLAY_SUITE_CLASS_RECEIPTS_V1', ())
        if isinstance(receipts, (list, tuple)) and any(item is cls for item in receipts):
            return True
        if any(item is cls for item in _MANAGER_BRIDGE_PANEL_CLASSES.values()):
            return True
    except Exception:
        return False
    return False


ADDON_ID = __package__ if __package__ else __name__
SMART_OVERLAY_NPANEL_SPACE_TYPES = (
    'VIEW_3D',
    'IMAGE_EDITOR',
    'NODE_EDITOR',
    'SEQUENCE_EDITOR',
    'CLIP_EDITOR',
    'DOPESHEET_EDITOR',
    'GRAPH_EDITOR',
    'NLA_EDITOR',
    'TEXT_EDITOR',
    'FILE_BROWSER',
    'SPREADSHEET',
)
SMART_OVERLAY_NPANEL_SPACE_SET = frozenset(SMART_OVERLAY_NPANEL_SPACE_TYPES)
OVERLAY_MENU_PANEL_NAMES = (
    "VIEW3D_PT_overlay_edit_mesh",
    "VIEW3D_PT_overlay_object",
    "VIEW3D_PT_overlay_sculpt",
)

_ALWAYS_ON_TOGGLES_OPEN = False
_ALWAYS_ON_TOGGLES_INTERNAL_PROP = '__sos_always_on_toggles_open__'

_NPANEL_GROUP_OPEN = {
    'always_on': False,
    'optimization_root': False,
    'mesh_overlay_root': True,
    'high_precision_outline_root': True,
    'uv_overlay_root': True,
    'proportional_overlay_root': True,
    'other_tools_root': True,
    'status_settings': True,
    'presets': True,
    'occluded': True,
    'vertex': True,
    'edge': True,
    'face': True,
    'hover_optimization': True,
    'object_hover': True,
    'uv_hover': True,
    'proportional': True,
    'edge_aa': True,
    'topology': True,
    'image_dimensions_viewer': True,
    'smart_measure': True,
    'silhouette': True,
    'integrated_tools': True,
    'scene_overrides': True,
}

_NPANEL_TOP_LEVEL_GROUP_KEYS = frozenset({'always_on', 'optimization_root', 'mesh_overlay_root', 'high_precision_outline_root', 'uv_overlay_root', 'proportional_overlay_root', 'other_tools_root'})
_NPANEL_CHILD_PANEL_PROP_PREFIX = 'sos_child_panel_'


def _sanitize_npanel_prop_key(key: str) -> str:
    text = str(key or '').strip().lower()
    out = ''.join(ch if (ch.isalnum() or ch == '_') else '_' for ch in text)
    while '__' in out:
        out = out.replace('__', '_')
    return out.strip('_') or 'section'


def npanel_child_panel_prop_name(key: str) -> str:
    return _NPANEL_CHILD_PANEL_PROP_PREFIX + _sanitize_npanel_prop_key(key)


def iter_npanel_child_panel_keys() -> tuple[str, ...]:
    return tuple(key for key in _NPANEL_GROUP_OPEN.keys() if key not in _NPANEL_TOP_LEVEL_GROUP_KEYS)


def iter_npanel_child_panel_properties() -> tuple[tuple[str, str, bool], ...]:
    return tuple((key, npanel_child_panel_prop_name(key), bool(_NPANEL_GROUP_OPEN.get(key, True))) for key in iter_npanel_child_panel_keys())


def _npanel_group_open(key: str, default: bool = True) -> bool:
    text = str(key or '').strip()
    if not text:
        return bool(default)
    return bool(_NPANEL_GROUP_OPEN.get(text, default))


def _set_npanel_group_open(key: str, value: bool, context=None) -> bool:
    text = str(key or '').strip()
    if not text:
        return False
    _NPANEL_GROUP_OPEN[text] = bool(value)
    try:
        from . import settings
        settings.queue_save(context, reason='npanel_group_open')
    except Exception:
        pass
    try:
        wm = getattr(context, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                if getattr(area, 'type', None) == 'VIEW_3D':
                    _tag_redraw_area(area)
    except Exception:
        pass
    return True


def sync_npanel_child_panel_props(context=None) -> None:
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None)
    if wm is None:
        return
    for key, prop_name, default in iter_npanel_child_panel_properties():
        try:
            if hasattr(wm, prop_name):
                desired = bool(_NPANEL_GROUP_OPEN.get(key, default))
                if bool(getattr(wm, prop_name)) != desired:
                    setattr(wm, prop_name, desired)
        except Exception:
            pass


def sync_npanel_child_group_state_from_props(context=None, *, queue: bool = False) -> bool:
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None)
    if wm is None:
        return False
    changed = False
    for key, prop_name, default in iter_npanel_child_panel_properties():
        try:
            if not hasattr(wm, prop_name):
                continue
            value = bool(getattr(wm, prop_name, default))
            if bool(_NPANEL_GROUP_OPEN.get(key, default)) != value:
                _NPANEL_GROUP_OPEN[key] = value
                changed = True
        except Exception:
            pass
    if changed and queue:
        try:
            from . import settings
            settings.queue_save(ctx, reason='npanel_child_panel_open')
        except Exception:
            pass
    return changed


def _is_always_on_toggles_open() -> bool:
    return bool(_ALWAYS_ON_TOGGLES_OPEN)


def set_always_on_toggles_open(value: bool, context=None) -> bool:
    """Set the Always-on group open state without touching Blender RNA."""
    global _ALWAYS_ON_TOGGLES_OPEN
    _ALWAYS_ON_TOGGLES_OPEN = bool(value)
    try:
        _NPANEL_GROUP_OPEN['always_on'] = bool(value)
    except Exception:
        pass
    try:
        from . import settings
        settings.queue_save(context, reason='always_on_group_open')
    except Exception:
        pass
    try:
        wm = getattr(context, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                if getattr(area, 'type', None) == 'VIEW_3D':
                    _tag_redraw_area(area)
    except Exception:
        try:
            area = getattr(context, 'area', None)
            if area is not None:
                area.tag_redraw()
        except Exception:
            pass
    return _ALWAYS_ON_TOGGLES_OPEN


def get_npanel_ui_state() -> dict:
    try:
        sync_npanel_child_group_state_from_props(getattr(bpy, 'context', None), queue=False)
    except Exception:
        pass
    return {
        'groups': dict(_NPANEL_GROUP_OPEN),
        'always_on_open': bool(_ALWAYS_ON_TOGGLES_OPEN),
    }


def apply_npanel_ui_state(data) -> None:
    global _ALWAYS_ON_TOGGLES_OPEN
    if not isinstance(data, dict):
        return
    groups = data.get('groups')
    if isinstance(groups, dict):
        for key, value in groups.items():
            text = str(key or '').strip()
            if text:
                _NPANEL_GROUP_OPEN[text] = bool(value)
    if 'always_on_open' in data:
        _ALWAYS_ON_TOGGLES_OPEN = bool(data.get('always_on_open'))
        _NPANEL_GROUP_OPEN['always_on'] = _ALWAYS_ON_TOGGLES_OPEN
    elif isinstance(groups, dict) and 'always_on' in groups:
        _ALWAYS_ON_TOGGLES_OPEN = bool(groups.get('always_on'))
    try:
        sync_npanel_child_panel_props(getattr(bpy, 'context', None))
    except Exception:
        pass


def _safe_context_object(context=None):
    try:
        obj = getattr(context, 'object', None)
    except Exception:
        obj = None
    if obj is None:
        try:
            obj = getattr(context, 'active_object', None)
        except Exception:
            obj = None
    if obj is None:
        return None
    try:
        _ = obj.name
        _ = obj.type
        if hasattr(obj, 'as_pointer') and int(obj.as_pointer()) == 0:
            return None
    except Exception:
        return None
    return obj


def _safe_context_scene(context=None):
    try:
        scene = getattr(context, 'scene', None)
        if scene is not None:
            _ = scene.name
        return scene
    except Exception:
        return None


def _safe_context_mode(context=None) -> str:
    try:
        return str(getattr(context, 'mode', '') or '')
    except Exception:
        return ''


def _is_supported_npanel_ui_context(context=None) -> bool:
    try:
        area = getattr(context, 'area', None)
        if area is not None:
            area_type = getattr(area, 'type', None)
            if area_type is not None and str(area_type) not in SMART_OVERLAY_NPANEL_SPACE_SET:
                return False
    except Exception:
        return False
    try:
        space = getattr(context, 'space_data', None)
        if space is not None:
            space_type = getattr(space, 'type', None)
            if space_type is not None and str(space_type) not in SMART_OVERLAY_NPANEL_SPACE_SET:
                return False
    except Exception:
        return False
    return True


def _is_view3d_ui_context(context=None) -> bool:
    return _is_supported_npanel_ui_context(context)


def _context_is_panel_draw_safe(context=None) -> bool:
    if context is None:
        return False
    if not _is_supported_npanel_ui_context(context):
        return False
    if _safe_context_scene(context) is None:
        return False
    try:
        if getattr(context, 'window_manager', None) is None:
            return False
    except Exception:
        return False
    return True


def _SICON(name: str = '', fallback: str = 'NONE') -> int:
    try:
        return int(sos_icons.icon_value(name, fallback) or 0)
    except Exception:
        return 0


def _icon_kwargs(name: str = '', fallback: str = 'NONE') -> dict:
    try:
        return sos_icons.icon_kwargs(name, fallback)
    except Exception:
        return {'icon': str(fallback or 'NONE')}


def _draw_icon_label(layout, text: str = '', icon: str = 'NONE', *, custom: str = ''):
    return layout.label(text=text, **_icon_kwargs(custom or icon, icon))


def _operator_icon_kwargs(custom: str = '', fallback: str = 'NONE') -> dict:
    return _icon_kwargs(custom or fallback, fallback)

# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _addon_preferences_candidates():
    names = []
    for value in (ADDON_ID, __package__, __name__.rpartition('.')[0]):
        text = str(value or '').strip().strip('.')
        if not text:
            continue
        if text not in names:
            names.append(text)
        leaf = text.rsplit('.', 1)[-1].strip()
        if leaf and leaf not in names:
            names.append(leaf)
    return tuple(names)


def _resolve_addon_preferences(context=None):
    return registry.resolve_addon_preferences(context)


def _prefs(context=None):
    # Draw paths must be read-only.  Blender 5.1 can crash in ui_handler_panel if
    # RNA properties are normalized while the panel tree is being rebuilt.  Depth
    # and preset migrations are handled during register/load/apply instead.
    return _resolve_addon_preferences(context)

def _standard_sidebar_host_context(context=None):
    """Return False for the standard 3D View N-panel implementation.

    Older builds routed this UI through a legacy proxy host and used
    this helper to switch to a compact proxy layout. The active UI is now a
    regular VIEW_3D > UI panel, so no proxy host mode is used.
    """
    del context
    return False


def _standard_sidebar_region_width(context=None) -> int:
    context = context or getattr(bpy, 'context', None)
    region = getattr(context, 'region', None)
    try:
        return int(getattr(region, 'width', 0) or 0)
    except Exception:
        return 0


def _standard_sidebar_use_wide_rows(context=None, *, min_width: int = 500) -> bool:
    return _standard_sidebar_region_width(context) >= max(320, int(min_width or 0))



def _tag_redraw_area(area):
    if area is None:
        return
    try:
        area.tag_redraw()
        return
    except Exception:
        pass
    for region in getattr(area, "regions", ()):
        try:
            region.tag_redraw()
        except Exception:
            pass


def _safe_context_attr(source, name: str, default=None):
    try:
        return getattr(source, name, default)
    except Exception:
        return default


def _ui_context_is_supported_npanel_sidebar(context) -> bool:
    if context is None:
        return False
    area = _safe_context_attr(context, 'area')
    region = _safe_context_attr(context, 'region')
    space = _safe_context_attr(context, 'space_data')
    if area is not None and str(_safe_context_attr(area, 'type')) not in SMART_OVERLAY_NPANEL_SPACE_SET:
        return False
    if area is None and space is not None and str(_safe_context_attr(space, 'type')) not in SMART_OVERLAY_NPANEL_SPACE_SET:
        return False
    region_type = _safe_context_attr(region, 'type')
    if region is not None and region_type not in {'UI', 'WINDOW'}:
        return (region_type == 'TOOL_PROPS'
                and _safe_context_attr(space, 'type') == 'FILE_BROWSER'
                and _safe_context_attr(space, 'browse_mode') == 'ASSETS')
    return True


def _ui_context_is_view3d_sidebar(context) -> bool:
    return _ui_context_is_supported_npanel_sidebar(context)


def _ui_context_has_valid_active_object(context) -> bool:
    obj = _safe_context_attr(context, 'object') or _safe_context_attr(context, 'active_object')
    if obj is None:
        return False
    try:
        name = str(getattr(obj, 'name', '') or '')
    except Exception:
        return False
    if not name:
        return False
    try:
        _ = getattr(obj, 'type', None)
    except ReferenceError:
        return False
    except Exception:
        return False
    return True


def _ui_context_is_mode_transition_unsafe(context) -> bool:
    """Return True while Blender is between object/mode states.

    Blender 5.1 can crash inside ui_handler_panel when a sidebar draw pass
    creates RNA buttons while the current mode says edit/sculpt but the active
    object pointer has already been cleared by a preceding select-all or mode
    switch.  Treat that state as transient and draw only a minimal safe panel.
    """
    if not _ui_context_is_view3d_sidebar(context):
        return True
    mode = str(_safe_context_attr(context, 'mode', 'OBJECT') or 'OBJECT')
    if mode != 'OBJECT' and not _ui_context_has_valid_active_object(context):
        return True
    try:
        view_layer = _safe_context_attr(context, 'view_layer')
        if view_layer is None:
            return True
        _ = _safe_context_attr(view_layer, 'objects')
    except Exception:
        return True
    return False


def _draw_transient_context_notice(layout, context) -> None:
    try:
        col = layout.column(align=True)
        _draw_icon_label(
            col,
            text=registry.localized(
                'Smart Overlay is waiting for the viewport context to stabilize.',
                'ビューポートの状態が安定するまでSmart Overlayの描画を待機しています。',
                context,
            ),
        )
    except Exception:
        pass


def _sos_context_space_type(context=None) -> str:
    try:
        area = getattr(context, 'area', None)
        if area is not None:
            text = str(getattr(area, 'type', '') or '')
            if text:
                return text
    except Exception:
        pass
    try:
        space = getattr(context, 'space_data', None)
        if space is not None:
            return str(getattr(space, 'type', '') or '')
    except Exception:
        pass
    return ''


def _sos_manager_bridge_ready_for_context(context=None) -> bool:
    """Return True only when a manager-owned Smart Overlay tab can draw now."""
    space_type = _sos_context_space_type(context)
    if not space_type:
        return False
    try:
        anchors_fn = globals().get('_sos_manager_anchor_classes_for_smart_overlay')
        if not callable(anchors_fn):
            return False
        anchors = tuple(anchors_fn() or ())
    except Exception:
        return False
    if not anchors:
        return False
    for anchor_cls in anchors:
        try:
            if str(getattr(anchor_cls, 'bl_space_type', '') or '') != space_type:
                continue
            anchor_id = str(getattr(anchor_cls, 'bl_idname', '') or getattr(anchor_cls, '__name__', '') or '')
            if not anchor_id or getattr(bpy.types, str(getattr(anchor_cls, '__name__', '') or ''), None) is not anchor_cls:
                continue
            bridge_cls = _MANAGER_BRIDGE_PANEL_CLASSES.get(anchor_id) if isinstance(globals().get('_MANAGER_BRIDGE_PANEL_CLASSES'), dict) else None
            if not isinstance(bridge_cls, type):
                return False
            if getattr(bpy.types, str(getattr(bridge_cls, '__name__', '') or ''), None) is not bridge_cls:
                return False
            try:
                anchor_poll = getattr(anchor_cls, 'poll', None)
                if callable(anchor_poll) and not bool(anchor_poll(context)):
                    continue
            except Exception:
                continue
            try:
                from . import common as _sos_common
                workspace_key_fn = getattr(_sos_common, '_manager_active_workspace_key', None)
                rule_fn = getattr(_sos_common, '_smart_tools_manager_workspace_rule', None)
                editor_key = str(getattr(anchor_cls, '_smart_tools_manager_editor_key', '') or '')
                if callable(workspace_key_fn) and callable(rule_fn):
                    if not bool(rule_fn(workspace_key_fn(context), editor_key)):
                        continue
            except Exception:
                continue
            return True
        except Exception:
            continue
    return False


def _smart_overlay_sidebar_panel_poll(context):
    # The Panel class' bl_space_type and Blender's Workspace.owner_ids filtering
    # already restrict where this root panel is allowed to exist.  However, do not
    # make the body panel depend on the current workspace owner list here: Smart
    # Tools Manager may temporarily keep only a legacy owner alias, which leaves
    # its hidden category anchor visible while the real Smart Overlay panel is
    # filtered out.  Poll only checks editor compatibility and the manager's
    # explicit rule value; owner-id repair is handled separately by common.py.
    try:
        if context is None:
            return True
        area = getattr(context, 'area', None)
        space = getattr(context, 'space_data', None)
        area_type = str(getattr(area, 'type', '') or '') if area is not None else ''
        space_type = str(getattr(space, 'type', '') or '') if space is not None else ''
        if area_type and area_type not in SMART_OVERLAY_NPANEL_SPACE_SET:
            return False
        if not area_type and space_type and space_type not in SMART_OVERLAY_NPANEL_SPACE_SET:
            return False
    except Exception:
        return True
    try:
        from . import common as _sos_common
        fn = getattr(_sos_common, 'smart_tools_manager_rule_allows_context', None)
        if callable(fn):
            rule = fn(context)
            if rule is False:
                return False
            if rule is True:
                # Prefer the native Smart Overlay root panel.  The manager bridge
                # remains registered as a fallback for owner-filter/wrapper edge
                # cases, but drawing the main UI as a child bridge adds an extra
                # Blender panel body and makes the whole N-panel look one opacity
                # level lighter than standard tabs.
                return True
    except Exception:
        pass
    return True


def _view3d_sidebar_panel_poll(context):
    return _smart_overlay_sidebar_panel_poll(context)


# ---------------------------------------------------------------------------
# Detached enum popup helpers
# ---------------------------------------------------------------------------

_SOS_ENUM_DIALOG_ITEMS_CACHE = {}
_TOOL_SETTINGS_PERSISTENCE_PROPS = (
    'use_proportional_edit',
    'use_proportional_connected',
    'use_proportional_projected',
    'use_proportional_projected_from_view',
    'use_proportional_edit_projected',
    'use_proportional_edit_projected_from_view',
    'proportional_edit_falloff',
    'proportional_size',
)
_TOOL_SETTINGS_PERSISTENCE_SNAPSHOT = ''


def _persist_tool_settings_if_changed(context, tool_settings) -> None:
    global _TOOL_SETTINGS_PERSISTENCE_SNAPSHOT
    if tool_settings is None:
        return
    data = {}
    for prop_name in _TOOL_SETTINGS_PERSISTENCE_PROPS:
        try:
            if hasattr(tool_settings, prop_name):
                value = getattr(tool_settings, prop_name)
                if isinstance(value, (bool, int, float, str)) or value is None:
                    data[prop_name] = value
                elif isinstance(value, (tuple, list)):
                    data[prop_name] = list(value)
        except Exception:
            pass
    try:
        snapshot = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    except Exception:
        snapshot = repr(sorted(data.items()))
    if snapshot == _TOOL_SETTINGS_PERSISTENCE_SNAPSHOT:
        return
    _TOOL_SETTINGS_PERSISTENCE_SNAPSHOT = snapshot
    try:
        from . import settings
        settings.queue_save(context, reason='tool_settings_draw_snapshot')
    except Exception:
        pass


def _ui_localized_status(context=None, enabled=False):
    return registry.localized('ON' if enabled else 'OFF', '有効' if enabled else '無効', context)


def _ui_context_mode_label(context=None, mode=None):
    value = str(mode or getattr(context, 'mode', '') or 'OBJECT').strip()
    labels = {
        'OBJECT': ('Object Mode', 'オブジェクトモード'),
        'EDIT': ('Edit Mode', '編集モード'),
        'EDIT_MESH': ('Edit Mesh Mode', 'メッシュ編集モード'),
        'EDIT_CURVE': ('Edit Curve Mode', 'カーブ編集モード'),
        'EDIT_SURFACE': ('Edit Surface Mode', 'サーフェス編集モード'),
        'EDIT_TEXT': ('Edit Text Mode', 'テキスト編集モード'),
        'EDIT_ARMATURE': ('Edit Armature Mode', 'アーマチュア編集モード'),
        'EDIT_METABALL': ('Edit Metaball Mode', 'メタボール編集モード'),
        'EDIT_LATTICE': ('Edit Lattice Mode', 'ラティス編集モード'),
        'POSE': ('Pose Mode', 'ポーズモード'),
        'SCULPT': ('Sculpt Mode', 'スカルプトモード'),
        'PAINT_WEIGHT': ('Weight Paint Mode', 'ウェイトペイントモード'),
        'PAINT_VERTEX': ('Vertex Paint Mode', '頂点ペイントモード'),
        'PAINT_TEXTURE': ('Texture Paint Mode', 'テクスチャペイントモード'),
        'PARTICLE': ('Particle Edit Mode', 'パーティクル編集モード'),
        'EDIT_GPENCIL': ('Grease Pencil Edit Mode', 'グリースペンシル編集モード'),
        'PAINT_GPENCIL': ('Grease Pencil Draw Mode', 'グリースペンシル描画モード'),
        'SCULPT_GPENCIL': ('Grease Pencil Sculpt Mode', 'グリースペンシルスカルプトモード'),
        'WEIGHT_GPENCIL': ('Grease Pencil Weight Paint Mode', 'グリースペンシルウェイトペイントモード'),
        'VERTEX_GPENCIL': ('Grease Pencil Vertex Paint Mode', 'グリースペンシル頂点ペイントモード'),
        'EDIT_GREASE_PENCIL': ('Grease Pencil Edit Mode', 'グリースペンシル編集モード'),
        'PAINT_GREASE_PENCIL': ('Grease Pencil Draw Mode', 'グリースペンシル描画モード'),
        'SCULPT_GREASE_PENCIL': ('Grease Pencil Sculpt Mode', 'グリースペンシルスカルプトモード'),
        'WEIGHT_GREASE_PENCIL': ('Grease Pencil Weight Paint Mode', 'グリースペンシルウェイトペイントモード'),
        'VERTEX_GREASE_PENCIL': ('Grease Pencil Vertex Paint Mode', 'グリースペンシル頂点ペイントモード'),
        'SCULPT_CURVES': ('Curves Sculpt Mode', 'カーブスカルプトモード'),
    }
    en, ja = labels.get(value, (value.replace('_', ' ').title(), value))
    return registry.localized(en, ja, context)


def _ui_overlay_toggle_label(context=None, enabled=False):
    return registry.localized(
        f"Overlay Toggle: {'ON' if enabled else 'OFF'}",
        f"オーバーレイ切替: {_ui_localized_status(context, enabled)}",
        context,
    )


def _ui_hide_occluded_label(context=None, enabled=False):
    return registry.localized(
        f"Hide When X-Ray Off: {'ON' if enabled else 'OFF'}",
        f"X-Ray OFF時に遮蔽を隠す: {_ui_localized_status(context, enabled)}",
        context,
    )


def _ui_is_japanese(context=None):
    candidates = []
    try:
        candidates.append(str(getattr(getattr(getattr(context, 'preferences', None), 'view', None), 'language', '') or ''))
    except Exception:
        pass
    try:
        candidates.append(str(getattr(getattr(getattr(bpy.context, 'preferences', None), 'view', None), 'language', '') or ''))
    except Exception:
        pass
    try:
        candidates.append(str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or ''))
    except Exception:
        pass
    joined = ' '.join(candidates).upper()
    return any(token in joined for token in ('JA', 'JA_JP', 'JAPANESE', 'JP'))


_ENUM_DIALOG_TEXT_EN = {
    'select_setting': 'Select Setting',
    'dialog_note': 'Purpose: Open a detached picker so long option lists stay fully visible even when the N-panel is narrow.\nHow to use: Click the current value button, choose the option you want from the list, then confirm with OK.\nBest for: Enum settings whose normal popup menu can be clipped inside the N-panel.',
}

_ENUM_DIALOG_TEXT_JA = {
    'select_setting': '設定を選択',
    'dialog_note': '機能: Nパネルが狭い場合でも、長い候補リストを切り取られずに表示できる独立ダイアログを開きます。\n使い方: 現在値ボタンを押し、一覧から目的の項目を選んで OK で確定します。\n向いている場面: Nパネル内で通常のポップアップメニューが見切れてしまう列挙設定。',
}


def _enum_dialog_text(key, context=None):
    table = _ENUM_DIALOG_TEXT_JA if _ui_is_japanese(context) else _ENUM_DIALOG_TEXT_EN
    return str(table.get(str(key), _ENUM_DIALOG_TEXT_EN.get(str(key), str(key))))



def _standard_sidebar_uses_detached_enum_dialog(context) -> bool:
    # Normal 3D View N-panel panels use Blender's regular enum UI.
    # Detached dialogs were only needed by the former compact proxy layout.
    del context
    return False


def _standard_sidebar_layout_is_narrow(context=None, threshold: int = 430) -> bool:
    region = getattr(context, 'region', None)
    if region is None:
        return False
    try:
        width = int(getattr(region, 'width', 0) or 0)
    except Exception:
        width = 0
    effective_threshold = 620 if _standard_sidebar_host_context(context) else threshold
    return 0 < width < max(280, int(effective_threshold))



def _enum_target_from_context(context, target_kind: str):
    key = str(target_kind or '').upper()
    if key == 'ADDON_PREFS':
        return _prefs(context)
    if key == 'TOOL_SETTINGS':
        return getattr(context, 'tool_settings', None)
    return None



def _enum_rna_property(target, prop_name: str):
    if target is None:
        return None
    prop_name = str(prop_name or '')
    if not prop_name:
        return None
    try:
        return target.bl_rna.properties.get(prop_name)
    except Exception:
        return None



def _enum_prop_label(target, prop_name: str, fallback: str = '') -> str:
    rna_prop = _enum_rna_property(target, prop_name)
    label = str(getattr(rna_prop, 'name', '') or fallback or prop_name)
    return TI(label)



def _enum_prop_description(target, prop_name: str, context=None) -> str:
    rna_prop = _enum_rna_property(target, prop_name)
    desc = str(getattr(rna_prop, 'description', '') or '')
    return TT(desc) if desc else ''



def _enum_prop_items(target, prop_name: str):
    rna_prop = _enum_rna_property(target, prop_name)
    if rna_prop is None:
        return ()
    try:
        return tuple(rna_prop.enum_items)
    except Exception:
        return ()



def _enum_value_label(target, prop_name: str) -> str:
    current_value = str(getattr(target, prop_name, '') or '')
    for item in _enum_prop_items(target, prop_name):
        identifier = str(getattr(item, 'identifier', '') or '')
        if identifier == current_value:
            return TI(str(getattr(item, 'name', identifier) or identifier))
    return current_value or _enum_prop_label(target, prop_name, fallback=prop_name)



def _enum_dialog_width(context=None) -> int:
    try:
        ui_scale = float(getattr(getattr(getattr(context, 'preferences', None), 'view', None), 'ui_scale', 1.0) or 1.0)
    except Exception:
        ui_scale = 1.0
    return max(360, int(round(420 * ui_scale)))



def _enum_dialog_operator_description(context, target, prop_name: str, fallback_label: str = '') -> str:
    label = fallback_label or _enum_prop_label(target, prop_name, fallback=prop_name)
    desc = _enum_prop_description(target, prop_name, context)
    note = _enum_dialog_text('dialog_note', context)
    parts = [part for part in (label, desc, note) if str(part or '').strip()]
    return '\n\n'.join(parts)



def _draw_popup_safe_enum_prop(layout, context, target_kind: str, target, prop_name: str, text=None):
    if target is None:
        return
    label_text = str(text) if text is not None else _enum_prop_label(target, prop_name, fallback=prop_name)
    if not _standard_sidebar_uses_detached_enum_dialog(context):
        if label_text and not getattr(layout, 'use_property_split', False):
            split = layout.split(factor=0.5, align=True)
            split.label(text=label_text)
            split.prop(target, prop_name, text='')
            return
        if text is None:
            layout.prop(target, prop_name)
        else:
            layout.prop(target, prop_name, text=text)
        return
    if _enum_rna_property(target, prop_name) is None:
        if text is None:
            layout.prop(target, prop_name)
        else:
            layout.prop(target, prop_name, text=text)
        return

    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass

    if _standard_sidebar_layout_is_narrow(context):
        col = layout.column(align=True)
        try:
            col.operator_context = 'INVOKE_DEFAULT'
        except Exception:
            pass
        if label_text:
            col.label(text=label_text)
        op = col.operator('wm.sos_enum_dialog_popup', text=_enum_value_label(target, prop_name), emboss=True, **_operator_icon_kwargs('tridown', 'TRIA_DOWN'))
    else:
        row = layout.row(align=True)
        try:
            row.use_property_split = False
            row.use_property_decorate = False
            row.operator_context = 'INVOKE_DEFAULT'
        except Exception:
            pass
        split = row.split(factor=0.42, align=True)
        split.label(text=label_text)
        op = split.operator('wm.sos_enum_dialog_popup', text=_enum_value_label(target, prop_name), emboss=True, **_operator_icon_kwargs('tridown', 'TRIA_DOWN'))

    op.target_kind = str(target_kind)
    op.prop_name = str(prop_name)
    op.label_text = label_text



def _draw_help_button(layout, context, topic: str, *, text: str | None = None):
    """Draw a Smart Transform style standard QUESTION help button.

    The button is drawn directly on the supplied header row.  It uses Blender's
    built-in QUESTION icon, empty text, no custom icon_value, and the same
    compact scale used by the reference Smart Transform UI.
    """
    del context, text
    if layout is None or not str(topic or '').strip():
        return None
    try:
        layout.separator(factor=0.35)
    except Exception:
        pass
    try:
        row = layout.row(align=True)
    except Exception:
        row = layout
    try:
        row.scale_x = 0.82
        row.scale_y = 1.0
        row.operator_context = 'INVOKE_DEFAULT'
    except Exception:
        pass
    try:
        op = row.operator('view3d.sos_tool_help', text='', icon='QUESTION', emboss=True)
    except TypeError:
        try:
            op = row.operator('view3d.sos_tool_help', text='', icon='QUESTION')
        except Exception:
            return None
    except Exception:
        return None
    try:
        op.topic = str(topic)
    except Exception:
        pass
    return op


def _draw_reset_header(layout, text: str = "", *, icon: str = 'NONE', reset_category: str = "", help_topic: str = "", context=None):
    if not text and not reset_category and not help_topic:
        return None

    if context is None:
        try:
            context = bpy.context
        except Exception:
            context = None

    last_row = None

    if text:
        row = layout.row(align=True)
        try:
            row.use_property_split = False
            row.use_property_decorate = False
        except Exception:
            pass
        _draw_icon_label(row, text=text, icon=icon)
        if help_topic:
            _draw_help_button(row, context, help_topic)
        last_row = row
    elif help_topic:
        row = layout.row(align=True)
        _draw_help_button(row, context, help_topic)
        last_row = row

    if reset_category:
        row = layout.row(align=True)
        try:
            row.use_property_split = False
            row.use_property_decorate = False
        except Exception:
            pass
        op = row.operator("view3d.sos_reset_settings", text=TI("Reset"), emboss=False, **_operator_icon_kwargs('reset', 'FILE_REFRESH'))
        op.category = str(reset_category)
        last_row = row

    return last_row



def _draw_presets_section(layout, context, prefs, *, show_section_header=True):
    if prefs is None:
        return
    layout.use_property_split = False
    layout.use_property_decorate = False

    target = layout
    if show_section_header:
        _draw_reset_header(target, TI("Presets"), icon='PRESET', reset_category='PRESETS', help_topic='presets', context=context)
    else:
        _draw_reset_header(target, reset_category='PRESETS')

    # Compact vertical rows.  The former selector + Apply button on one row was
    # one of the N-panel overflow sources when the sidebar was narrow.
    _draw_compact_preset_selector(target, context, prefs, text=TI("Preset"))
    op = target.operator("view3d.sos_apply_preset", text=TI("Apply Preset"), **_operator_icon_kwargs('apply', 'CHECKMARK'))
    op.preset_id = ""
    target.operator("view3d.sos_save_preset", text=TI("Save Current as Preset"), **_operator_icon_kwargs('save', 'ADD'))
    target.operator("view3d.sos_delete_preset", text=TI("Delete Preset"), **_operator_icon_kwargs('delete', 'TRASH'))



def _draw_scene_overrides_section(layout, context, prefs, *, show_section_header=True):
    if prefs is None:
        return
    layout.use_property_split = False
    layout.use_property_decorate = False

    target = layout.column(align=True) if show_section_header else layout
    if show_section_header:
        _draw_reset_header(target, TI("Scene Overrides"), icon='FILE_BLEND', reset_category='SCENE_OVERRIDES', help_topic='scene_overrides', context=context)
    else:
        _draw_reset_header(target, reset_category='SCENE_OVERRIDES')
    target.prop(prefs, "use_scene_overrides")
    try:
        scn = context.scene
        if prefs.use_scene_overrides and hasattr(scn, "sos_scene_overrides_enabled"):
            target.prop(scn, "sos_scene_overrides_enabled", text=TI("Scene Overrides Enabled"))
            target.operator("view3d.sos_scene_save", text=TI("Save Current to Scene"), **_operator_icon_kwargs('save', 'FILE_TICK'))
            target.operator("view3d.sos_scene_load", text=TI("Load From Scene"), **_operator_icon_kwargs('import', 'IMPORT'))
            target.operator("view3d.sos_scene_clear", text=TI("Clear Scene Overrides"), **_operator_icon_kwargs('delete', 'TRASH'))
    except Exception:
        pass


def _draw_occluded_section(layout, context, prefs, *, show_section_header=True):
    if prefs is None:
        return
    layout.use_property_split = False
    layout.use_property_decorate = False

    target = layout
    if show_section_header:
        _draw_reset_header(target, TI("Occluded Display Mode"), icon='XRAY', reset_category='OCCLUDED', help_topic='occluded_display', context=context)
    else:
        _draw_reset_header(target, reset_category='OCCLUDED')

    occ_xray_enabled = str(getattr(prefs, "occluded_display_mode", 'XRAY_ONLY') or 'XRAY_ONLY') == 'XRAY_ONLY'
    row_occ_toggle = target.row(align=True)
    row_occ_toggle.operator(
        "view3d.sos_toggle_occluded_xray_only",
        text=_ui_hide_occluded_label(context, occ_xray_enabled),
        **_operator_icon_kwargs('switch_on' if occ_xray_enabled else 'switch_off', 'CHECKBOX_HLT' if occ_xray_enabled else 'CHECKBOX_DEHLT'),
    )
    _draw_popup_safe_enum_prop(target, context, "ADDON_PREFS", prefs, "occluded_display_mode", text=registry.localized("Display Mode", "表示モード", context))
    _draw_popup_safe_enum_prop(target, context, "ADDON_PREFS", prefs, "occluded_style")
    col_occ = target.column(align=True)
    col_occ.prop(prefs, "occluded_alpha_mul")
    col_occ.prop(prefs, "occluded_thickness_mul")
    col_occ.prop(prefs, "occluded_point_mul")
    target.label(text=TI("How to add a shortcut"))
    _draw_manual_shortcut_registration(target, prefs, "occluded_xray_toggle_operator_identifier_display")



def _draw_color_triplet(layout, prefs, color_specs, *, horizontal=False):
    if horizontal:
        container = layout.row(align=True)
    else:
        container = layout.column(align=True)
    try:
        container.use_property_split = False
        container.use_property_decorate = False
    except Exception:
        pass

    if horizontal:
        for toggle_prop, color_prop, text_label in color_specs:
            elem = container.column(align=True)
            try:
                elem.use_property_split = False
                elem.use_property_decorate = False
            except Exception:
                pass
            try:
                elem.prop(prefs, toggle_prop, text=TI(text_label))
            except Exception:
                pass
            try:
                elem.prop(prefs, color_prop, text=TI(text_label))
            except Exception:
                pass
        return

    for toggle_prop, color_prop, text_label in color_specs:
        try:
            container.prop(prefs, toggle_prop, text=TI(text_label))
        except Exception:
            pass
        try:
            container.prop(prefs, color_prop, text=TI(text_label))
        except Exception:
            pass



def _draw_hover_optimization_section(layout, context, prefs, *, show_section_header=True):
    if prefs is None:
        return
    layout.use_property_split = False
    layout.use_property_decorate = False

    target = layout
    if show_section_header:
        _draw_reset_header(target, TI("Hover Optimization"), icon='HIDE_OFF', reset_category='HOVER_OPT', help_topic='hover_overlay', context=context)
    else:
        _draw_reset_header(target, reset_category='HOVER_OPT')
    _draw_popup_safe_enum_prop(target, context, "ADDON_PREFS", prefs, "hover_lod_mode")
    if prefs.hover_lod_mode == 'AUTO':
        target.prop(prefs, "hover_lod_threshold_verts")

    _draw_color_triplet(
        target,
        prefs,
        [
            ("show_hov_verts", "hover_vertex_color", "Vertex"),
            ("show_hov_edges", "hover_edge_color", "Edge"),
            ("show_hov_faces", "hover_face_color", "Face"),
        ],
        horizontal=True,
    )



def _draw_edge_aa_section(layout, context, prefs, *, show_section_header=True):
    if prefs is None:
        return
    layout.use_property_split = False
    layout.use_property_decorate = False

    if show_section_header:
        _draw_reset_header(layout, TI("Edge Anti-Aliasing"), icon='MOD_SMOOTH', reset_category='EDGE_AA', help_topic='edge_aa', context=context)
    else:
        _draw_reset_header(layout, reset_category='EDGE_AA')
    _draw_popup_safe_enum_prop(layout, context, "ADDON_PREFS", prefs, "edge_aa_mode", text="")



def _draw_topology_section(layout, context, prefs, *, show_section_header=True):
    if prefs is None:
        return
    layout.use_property_split = False
    layout.use_property_decorate = False

    if show_section_header:
        _draw_reset_header(layout, TI("Topology Checks"), icon='MOD_WIREFRAME', reset_category='TOPOLOGY', help_topic='topology_checks', context=context)
    else:
        _draw_reset_header(layout, reset_category='TOPOLOGY')
    layout.prop(prefs, "topology_checks_enabled", text=TI("Enable Topology Checks"))
    if prefs.topology_checks_enabled:
        _draw_popup_safe_enum_prop(layout, context, "ADDON_PREFS", prefs, "topo_selection_filter")
        layout.separator()
        layout.prop(prefs, "topo_edges_enabled")
        if prefs.topo_edges_enabled:
            col = layout.column(align=True)
            col.prop(prefs, "topo_show_seams")
            col.prop(prefs, "topo_show_sharp")
            col.prop(prefs, "topo_show_non_manifold")
            col.prop(prefs, "topo_show_crease")
            if prefs.topo_show_crease:
                col.prop(prefs, "topo_crease_threshold")
            col.prop(prefs, "topo_show_bevel_weight")
            if prefs.topo_show_bevel_weight:
                col.prop(prefs, "topo_bevel_weight_threshold")
            col.prop(prefs, "topo_edge_size_mul")
            col2 = layout.column(align=True)
            col2.prop(prefs, "topo_edge_color_seam")
            col2.prop(prefs, "topo_edge_color_sharp")
            col2.prop(prefs, "topo_edge_color_nonmanifold")
            if prefs.topo_show_crease:
                col2.prop(prefs, "topo_edge_color_crease")
            if prefs.topo_show_bevel_weight:
                col2.prop(prefs, "topo_edge_color_bevel")
        layout.separator()
        layout.prop(prefs, "topo_faces_enabled")
        if prefs.topo_faces_enabled:
            colf = layout.column(align=True)
            colf.prop(prefs, "topo_show_ngons")
            colf.prop(prefs, "topo_show_small_faces")
            if prefs.topo_show_small_faces:
                colf.prop(prefs, "topo_small_face_area")
            colf.prop(prefs, "topo_show_backfaces")
            colf.prop(prefs, "topo_face_opacity_mul")
            colf2 = layout.column(align=True)
            if prefs.topo_show_ngons:
                colf2.prop(prefs, "topo_face_color_ngon")
            if prefs.topo_show_small_faces:
                colf2.prop(prefs, "topo_face_color_small")
            if prefs.topo_show_backfaces:
                colf2.prop(prefs, "topo_face_color_backface")



def _draw_element_section(layout, prefs, label, icon, plural_key, base_key, *, context=None, show_section_header=True):
    if prefs is None:
        return
    layout.use_property_split = False
    layout.use_property_decorate = False

    _element_help_topics = {'vertex': 'vertex_overlay', 'edge': 'edge_overlay', 'face': 'face_overlay'}
    if show_section_header:
        _draw_reset_header(layout, TI(f"{label} Settings"), icon=icon, reset_category=label.upper(), help_topic=_element_help_topics.get(str(base_key), ''), context=context)
    else:
        _draw_reset_header(layout, reset_category=label.upper())

    layout.prop(prefs, f"show_{plural_key}_edit", text=TI("Edit"))
    layout.prop(prefs, f"show_{plural_key}_object", text=TI("Object / Sculpt"))

    def _draw_toggle_color_column(container, toggle_prop, color_prop, text_label):
        try:
            container.use_property_split = False
            container.use_property_decorate = False
        except Exception:
            pass
        try:
            container.prop(prefs, toggle_prop, text=str(text_label))
        except Exception:
            pass
        try:
            container.prop(prefs, color_prop, text=str(text_label))
        except Exception:
            pass

    def _paired_row(left_toggle, left_prop, left_label, right_toggle=None, right_prop=None, right_label=None):
        if right_toggle and right_prop:
            row = layout.row(align=True)
            try:
                row.use_property_split = False
                row.use_property_decorate = False
            except Exception:
                pass
            _draw_toggle_color_column(row.column(align=True), left_toggle, left_prop, left_label)
            _draw_toggle_color_column(row.column(align=True), right_toggle, right_prop, right_label)
            return
        _draw_toggle_color_column(layout.column(align=True), left_toggle, left_prop, left_label)


    _paired_row(
        f"show_vis_{plural_key}",
        f"{base_key}_color",
        TI("Visible Color"),
        f"show_occ_{plural_key}",
        f"{base_key}_occluded_color",
        TI("Occluded Color"),
    )

    if base_key != "face":
        _paired_row(
            f"show_sel_{plural_key}",
            f"selected_{base_key}_overlay_color",
            TI("Selected Color"),
            f"show_hov_{plural_key}",
            f"hover_{base_key}_color",
            TI("Hover Color"),
        )
        layout.prop(prefs, f"{base_key}_size", text=TI(f"{label} Size(px)"))
        layout.prop(prefs, f"{base_key}_depth_offset_ui", text=TI(f"{label} Z-Offset"))
    else:
        _paired_row(
            "show_sel_faces",
            "selected_face_overlay_color",
            TI("Selected Color"),
            "show_hov_faces",
            "hover_face_color",
            TI("Hover Color"),
        )
        layout.prop(prefs, "opacity", text=TI("Face Opacity"))
        layout.prop(prefs, "face_depth_offset_ui", text=TI("Face Z-Offset"))


def _draw_object_hover_section(layout, context, prefs, *, show_section_header=True):
    if prefs is None:
        return
    layout.use_property_split = False
    layout.use_property_decorate = False

    if show_section_header:
        _draw_reset_header(layout, TI("Object / Sculpt Hover Color"), icon='OBJECT_DATAMODE', reset_category='OBJECT_HOVER', help_topic='object_sculpt_hover', context=context)
    else:
        _draw_reset_header(layout, reset_category='OBJECT_HOVER')

    _draw_color_triplet(
        layout,
        prefs,
        [
            ("show_hov_obj_verts", "hover_obj_vertex_color", "Vertex"),
            ("show_hov_obj_edges", "hover_obj_edge_color", "Edge"),
            ("show_hov_obj_faces", "hover_obj_face_color", "Face"),
        ],
        horizontal=True,
    )

    row_opacity = layout.column(align=True)
    row_opacity.prop(prefs, "hover_obj_vertex_edge_opacity", text=TI("Vertex / Edge Opacity"), slider=True)
    row_opacity.prop(prefs, "hover_obj_face_opacity", text=TI("Hover Face Opacity"), slider=True)

    layout.prop(prefs, "hover_delay_sec", text=TI("Selection Delay (sec)"))

def _draw_uv_hover_section(layout, context, prefs, *, show_section_header=True, horizontal_colors=True):
    if prefs is None:
        return
    layout.use_property_split = False
    layout.use_property_decorate = False

    if show_section_header:
        _draw_reset_header(layout, TI("UV Hover Color"), icon='GROUP_UVS', reset_category='UV_HOVER', help_topic='uv_hover', context=context)
    else:
        _draw_reset_header(layout, reset_category='UV_HOVER')

    _draw_color_triplet(
        layout,
        prefs,
        [
            ("show_hov_uv_verts", "hover_uv_vertex_color", "Vertex"),
            ("show_hov_uv_edges", "hover_uv_edge_color", "Edge"),
            ("show_hov_uv_faces", "hover_uv_face_color", "Face"),
        ],
        horizontal=horizontal_colors,
    )

    row_opacity = layout.column(align=True)
    row_opacity.prop(prefs, "hover_uv_vertex_edge_opacity", text=TI("Vertex / Edge Opacity"), slider=True)
    row_opacity.prop(prefs, "hover_uv_face_opacity", text=TI("Hover Face Opacity"), slider=True)

    try:
        layout.separator()
    except Exception:
        pass
    layout.prop(prefs, "show_uv_same_mesh_selection_overlay", text=TI("Show Same Mesh Element UVs"))
    same_col = layout.column(align=True)
    try:
        same_col.enabled = bool(getattr(prefs, "show_uv_same_mesh_selection_overlay", True))
    except Exception:
        pass
    row_same_types = same_col.row(align=True)
    row_same_types.prop(prefs, "show_uv_same_mesh_selection_verts", text=TI("Same Vertex"))
    row_same_types.prop(prefs, "show_uv_same_mesh_selection_edges", text=TI("Same Edge"))
    row_same_color = same_col.column(align=True)
    row_same_color.prop(prefs, "uv_same_mesh_selection_color", text=TI("Same Mesh Element Color"))
    row_same_color.prop(prefs, "uv_same_mesh_selection_opacity", text=TI("Opacity"), slider=True)



def _draw_proportional_section(layout, context, prefs, *, show_section_header=True):
    if prefs is None:
        return layout
    layout.use_property_split = False
    layout.use_property_decorate = False

    box = layout
    if show_section_header:
        _draw_reset_header(box, TI("Proportional Overlay"), icon='MOD_VERTEX_WEIGHT', help_topic='proportional_overlay', context=context)
    bx_p_app = box
    _draw_reset_header(bx_p_app, TI("Overlay Appearance"), reset_category='PROP_APPEARANCE')
    bx_p_app.prop(prefs, "prop_overlay_vertex_size", text=TI("Overlay Vertex Size(px)"))
    bx_p_app.prop(prefs, "prop_overlay_edge_size", text=TI("Overlay Edge Size(px)"))

    bx_p_disp = box
    _draw_reset_header(bx_p_disp, TI("Display Settings"), reset_category='PROP_DISPLAY')
    bx_p_disp.prop(prefs, "prop_heatmap_xray", text=TI("Heatmap X-Ray"))
    bx_p_disp.prop(prefs, "prop_heatmap_alpha", text=TI("Heatmap Opacity"), slider=True)
    bx_p_disp.prop(prefs, "prop_show_3d_view", text=TI("Use in 3D View"))
    bx_p_disp.prop(prefs, "prop_show_uv_editor", text=TI("Use in UV Editor"))

    bx_p_col = box
    bx_p_col.use_property_split = False
    bx_p_col.use_property_decorate = False
    _draw_reset_header(bx_p_col, TI("Gradient Colors"), reset_category='PROP_COLOR')

    try:
        prefs_module.draw_prop_heatmap_preview_ramp(bx_p_col, prefs)
    except Exception:
        pass

    tool_settings = getattr(context, "tool_settings", None)
    if tool_settings is not None:
        box_mode = box
        _draw_reset_header(box_mode, TI("Settings"), icon='PREFERENCES', reset_category='PROP_TOOL_SETTINGS')

        proj_attr = None
        for attr in (
            "use_proportional_projected",
            "use_proportional_projected_from_view",
            "use_proportional_edit_projected",
            "use_proportional_edit_projected_from_view",
        ):
            if hasattr(tool_settings, attr):
                proj_attr = attr
                break

        if hasattr(tool_settings, "use_proportional_edit"):
            if not tool_settings.use_proportional_edit:
                prop_icon = 'PROP_OFF'
            elif getattr(tool_settings, "use_proportional_connected", False):
                prop_icon = 'PROP_CON'
            elif proj_attr and getattr(tool_settings, proj_attr):
                prop_icon = 'PROP_PROJECTED'
            else:
                prop_icon = 'PROP_ON'

            box_mode.prop(tool_settings, "use_proportional_edit", text=TI("Enable"), **_operator_icon_kwargs('proportional', prop_icon))

            if tool_settings.use_proportional_edit:
                if hasattr(tool_settings, "use_proportional_connected"):
                    box_mode.prop(tool_settings, "use_proportional_connected", text=TI("Connected"))
                if proj_attr:
                    r_proj = box_mode.row()
                    r_proj.active = True
                    r_proj.prop(tool_settings, proj_attr, text=TI("Projected (from View)"))
                if hasattr(tool_settings, "proportional_edit_falloff"):
                    _draw_popup_safe_enum_prop(box_mode, context, "TOOL_SETTINGS", tool_settings, "proportional_edit_falloff", text=TI("Falloff Type"))
                if hasattr(tool_settings, "proportional_size"):
                    box_mode.prop(tool_settings, "proportional_size", text=TI("Radius"))

            _persist_tool_settings_if_changed(context, tool_settings)

    box.label(text=TI("How to add a shortcut"))
    box.label(text=TI('Proportional Display Toggle'))
    _draw_manual_shortcut_registration(box, prefs, "prop_operator_identifier_display")
    box.label(text=TI("Use in 3D View"))
    _draw_manual_shortcut_registration(box, prefs, "prop_3d_view_operator_identifier_display", location='Preferences > Keymap > 3D View')
    box.label(text=TI("Use in UV Editor"))
    _draw_manual_shortcut_registration(box, prefs, "prop_uv_editor_operator_identifier_display", location='Preferences > Keymap > Image / UV Editor')
    return box


def _draw_compact_preset_selector(layout, context, prefs, *, text=None):
    if prefs is None:
        return
    label_text = str(text) if text is not None else TI('Preset')
    current_label = str(getattr(prefs_module, 'peek_current_preset_label', prefs_module.get_current_preset_label)(prefs) or '')
    col = layout.column(align=True)
    try:
        col.use_property_split = False
        col.use_property_decorate = False
    except Exception:
        pass
    col.label(text=label_text)
    col.menu('SOS_MT_preset_menu', text=current_label, translate=prefs_module.presets.preset_label_translatable(prefs_module.peek_current_preset_id(prefs)), **_operator_icon_kwargs('presets', 'PRESET'))



def _addon_runtime_status_label(context=None, enabled=False):
    return registry.localized('On' if enabled else 'Off', '有効' if enabled else '無効', context)


def _always_on_split_factor(context) -> float:
    """Shared always-on split: 0.72 at every sidebar width, the same as the other Smart suites."""
    del context
    return 0.72


def _toggle_custom_icon(prop_name: str = '', label_en: str = '') -> str:
    key = f'{prop_name} {label_en}'.lower()
    if 'grid' in key:
        return 'grid'
    if 'image dimensions: node' in key or 'node' in key:
        return 'image_node'
    if 'idv_image_show' in key or 'image editor' in key:
        return 'image_editor'
    if 'smart_measure' in key:
        return 'measure'
    if 'silhouette' in key:
        return 'silhouette'
    if 'proportional' in key:
        return 'proportional'
    if 'object' in key or 'sculpt' in key:
        return 'object_hover'
    if 'uv' in key:
        return 'uv_hover'
    if 'mesh' in key:
        return 'mesh_overlay'
    return 'always_on'


def _owner_scope_for_addon_runtime_toggle(context, owner) -> str:
    try:
        if owner is getattr(context, 'window_manager', None):
            return 'WINDOW_MANAGER'
    except Exception:
        pass
    try:
        if owner is getattr(context, 'scene', None):
            return 'SCENE'
    except Exception:
        pass
    try:
        prefs = _prefs(context)
        if owner is None or prefs is None:
            return ''
        if owner is prefs:
            return 'ADDON_PREFS'
        if type(owner) is not type(prefs):
            return ''
        owner_pointer = int(owner.as_pointer())
        prefs_pointer = int(prefs.as_pointer())
        if owner_pointer != 0 and owner_pointer == prefs_pointer:
            return 'ADDON_PREFS'
    except (AttributeError, KeyError, ReferenceError, RuntimeError, TypeError, ValueError):
        pass
    return ''


def _draw_persistent_bool_row(layout, context, owner, prop_name: str, label_en: str, label_ja: str, *, icon='NONE') -> bool:
    """Draw one resident-toggle row in the Smart Selector always-on format."""
    if owner is None or not str(prop_name or '').strip():
        return False
    try:
        getattr(owner, prop_name)
    except Exception:
        return False
    try:
        enabled = bool(getattr(owner, prop_name, False))
    except Exception:
        enabled = False

    row = layout.row(align=True)
    try:
        row.scale_y = 0.95
        row.use_property_split = False
        row.use_property_decorate = False
    except Exception:
        pass
    try:
        split = row.split(factor=_always_on_split_factor(context), align=True)
    except Exception:
        split = row

    try:
        left = split.row(align=True)
    except Exception:
        left = split
    left.label(text=registry.localized(label_en, label_ja, context))

    try:
        button = split.row(align=True)
    except Exception:
        button = split
    try:
        button.use_property_split = False
        button.use_property_decorate = False
        button.alignment = 'RIGHT'
    except Exception:
        pass

    try:
        op = button.row(align=True).operator(
            'view3d.sos_set_always_on_addon_runtime_toggle',
            text=_addon_runtime_status_label(context, enabled),
            icon='CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT',
            depress=bool(enabled),
        )
        op.owner_scope = _owner_scope_for_addon_runtime_toggle(context, owner)
        op.prop_name = str(prop_name)
        op.operator_id = ''
        op.target_value = not enabled
        op.label_en = str(label_en or prop_name)
        op.label_ja = str(label_ja or prop_name)
        return True
    except Exception:
        try:
            button.label(text=_addon_runtime_status_label(context, False), icon='CHECKBOX_DEHLT')
        except Exception:
            pass
        return False



def _draw_persistent_operator_state_row(layout, context, owner, prop_name: str, operator_id: str, label_en: str, label_ja: str, *, icon='NONE') -> bool:
    if owner is None or not str(prop_name or '').strip() or not str(operator_id or '').strip():
        return False
    try:
        enabled = bool(getattr(owner, prop_name, False))
    except Exception:
        return False
    owner_scope = _owner_scope_for_addon_runtime_toggle(context, owner)
    if not owner_scope:
        return False

    row = layout.row(align=True)
    try:
        row.scale_y = 0.95
        row.use_property_split = False
        row.use_property_decorate = False
    except Exception:
        pass
    try:
        split = row.split(factor=_always_on_split_factor(context), align=True)
    except Exception:
        split = row
    try:
        left = split.row(align=True)
    except Exception:
        left = split
    left.label(text=registry.localized(label_en, label_ja, context))
    try:
        button = split.row(align=True)
    except Exception:
        button = split
    try:
        button.use_property_split = False
        button.use_property_decorate = False
        button.alignment = 'RIGHT'
    except Exception:
        pass

    try:
        op = button.row(align=True).operator(
            'view3d.sos_set_always_on_addon_runtime_toggle',
            text=_addon_runtime_status_label(context, enabled),
            icon='CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT',
            depress=bool(enabled),
        )
        op.owner_scope = owner_scope
        op.prop_name = str(prop_name)
        op.operator_id = str(operator_id)
        op.target_value = not enabled
        op.label_en = str(label_en or prop_name)
        op.label_ja = str(label_ja or prop_name)
        return True
    except Exception:
        return _draw_persistent_operator_row(layout, context, operator_id, operator_id, enabled, label_en, label_ja, icon=icon)


def _draw_persistent_operator_row(layout, context, operator_on: str, operator_off: str, enabled: bool, label_en: str, label_ja: str, *, icon='NONE') -> bool:
    op_id = str(operator_off if enabled else operator_on or '').strip()
    if not op_id:
        return False
    row = layout.row(align=True)
    try:
        row.scale_y = 0.95
        row.use_property_split = False
        row.use_property_decorate = False
    except Exception:
        pass
    try:
        split = row.split(factor=_always_on_split_factor(context), align=True)
    except Exception:
        split = row
    try:
        left = split.row(align=True)
    except Exception:
        left = split
    left.label(text=registry.localized(label_en, label_ja, context))
    try:
        button = split.row(align=True)
    except Exception:
        button = split
    try:
        button.use_property_split = False
        button.use_property_decorate = False
        button.alignment = 'RIGHT'
    except Exception:
        pass
    try:
        button.row(align=True).operator(
            op_id,
            text=_addon_runtime_status_label(context, enabled),
            icon='CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT',
            depress=bool(enabled),
        )
        return True
    except Exception:
        try:
            _draw_icon_label(button, text=_addon_runtime_status_label(context, enabled), icon='ERROR', custom='error')
        except Exception:
            pass
    return False



def _draw_addon_runtime_bool_prop(layout, context, owner, prop_name: str, label_en: str, label_ja: str, *, icon_enabled='CHECKBOX_HLT', icon_disabled='CHECKBOX_DEHLT') -> bool:
    del icon_enabled, icon_disabled
    return _draw_persistent_bool_row(layout, context, owner, prop_name, label_en, label_ja)


def _draw_addon_runtime_operator_toggle(layout, context, operator_on: str, operator_off: str, enabled: bool, label_en: str, label_ja: str, *, icon_enabled='CHECKBOX_HLT', icon_disabled='CHECKBOX_DEHLT') -> bool:
    del icon_enabled, icon_disabled
    return _draw_persistent_operator_row(layout, context, operator_on, operator_off, enabled, label_en, label_ja)


def _draw_smart_measure_addon_runtime_toggle(layout, context) -> bool:
    wm = getattr(context, 'window_manager', None)
    return _draw_persistent_bool_row(
        layout,
        context,
        wm,
        'smart_measure_run_opengl',
        'Smart Measure',
        'スマート メジャー',
        icon='NONE',
    )


def _draw_silhouette_addon_runtime_toggle(layout, context) -> bool:
    scene = getattr(context, 'scene', None)
    return _draw_persistent_bool_row(
        layout,
        context,
        scene,
        'silhouette_enabled',
        'Silhouette Mode',
        'シルエットモード',
        icon='NONE',
    )


def _draw_always_on_toggles_body(layout, context):
    if layout is None:
        return False
    wm = getattr(context, 'window_manager', None)
    scene = getattr(context, 'scene', None)
    prefs = _prefs(context)
    col = layout.column(align=True)
    try:
        col.use_property_split = False
        col.use_property_decorate = False
    except Exception:
        pass
    if _draw_persistent_bool_row(col, context, wm, 'sos_npanel_state_save_enabled', 'N-panel State Save', 'Nパネル状態保存', icon='FILE_TICK'):
        col.separator(factor=0.5)
    _draw_persistent_bool_row(col, context, prefs, 'high_precision_outline_enabled', 'High-Precision Outline', '高精度アウトライン', icon='NONE')
    _draw_persistent_operator_state_row(col, context, wm, 'sos_enabled', 'view3d.sos_toggle_overlay', 'Mesh and Curve Overlay', 'メッシュ・カーブ表示', icon='NONE')
    _draw_persistent_bool_row(col, context, wm, 'sos_proportional_overlay_enabled', 'Proportional Overlay', 'プロポーション表示', icon='NONE')
    _draw_persistent_bool_row(col, context, wm, 'sos_object_hover_overlay_enabled', 'Object / Sculpt Hover', 'オブジェクトホバー', icon='NONE')
    _draw_persistent_bool_row(col, context, wm, 'sos_uv_overlay_enabled', 'UV Hover Overlay', 'UVホバーオーバーレイ', icon='NONE')
    _draw_smart_measure_addon_runtime_toggle(col, context)
    _draw_persistent_bool_row(col, context, scene, 'idv_node_show', 'Image Size: Node', '画像サイズ: ノード', icon='NONE')
    _draw_persistent_bool_row(col, context, scene, 'idv_image_show', 'Image Size: Image', '画像サイズ: 画像', icon='NONE')
    _draw_silhouette_addon_runtime_toggle(col, context)
    return True


def _draw_always_on_toggles_group(layout, context, *, show_header: bool = True):
    """Draw the centralized resident/addon_runtime switch group."""
    del show_header
    return _draw_npanel_disclosure_group(
        layout,
        context,
        'always_on',
        'Always-on Toggles',
        '常時機能切り替え',
        icon='TIME',
        help_topic='always_on',
        draw_body=lambda body: _draw_always_on_toggles_body(body, context),
    )




def _draw_optimization_section_body(layout, context, prefs) -> bool:
    if layout is None or prefs is None:
        return False
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass
    _draw_reset_header(layout, reset_category='OPTIMIZATION')
    _draw_popup_safe_enum_prop(layout, context, 'ADDON_PREFS', prefs, 'optimization_profile')

    groups = (
        ('Display Scope and Quality', '表示対象・品質', (
            'hide_blender_standard_edit_edges_vertices',
            'active_view_draw_only',
            'optimization_lightest_active_object_only',
            'include_geometry_nodes_objects',
            'include_curve_shape_overlay',
            'include_lattice_objects',
            'double_sided',
            'use_evaluated_edit_mode_face_overlay',
            'show_embedded_edit_cage_while_view_still_xray_off',
            'use_select_mode_vertex_center_overlay',
            'optimization_lightest_lod_skip_dense_vertices_edges',
            'optimization_lightest_lod_element_limit',
        )),
        ('Occlusion and Selection Cleanup', '遮蔽・Blender選択表示整理', (
            'hide_occluded_colors_when_xray_off',
            'hide_visible_occluded_when_occluded_off',
            'use_all_objects_as_occluders',
            'optimization_lightest_disable_occluded_pass',
            'high_precision_outline_hide_occluded_in_xray',
            'hide_blender_adjacent_edge_gradient',
            'hide_blender_vertex_mode_linked_edge_face_overlay',
            'hide_blender_edge_mode_linked_vertex_face_overlay',
            'hide_blender_face_mode_linked_vertex_edge_overlay',
            'optimization_lightest_disable_topology_diagnostics',
        )),
        ('Live Update and Cache', 'ライブ更新・キャッシュ', (
            'active_view_only',
            'optimization_dirty_generation_cache',
            'optimization_disable_timed_live_sync_flush',
            'optimization_split_evaluated_face_cache',
            'optimization_async_evaluated_face_rebuild',
            'optimization_reuse_stale_evaluated_faces',
            'optimization_throttle_evaluated_face_rebuild',
            'optimization_evaluated_face_rebuild_interval',
            'optimization_target_modifier_dependency_dirty',
            'optimization_indexed_edit_batches',
            'optimization_split_topology_cache',
        )),
        ('Draw Load and Hover', '描画負荷・ホバー', (
            'optimization_conditional_depth_prepass',
            'optimization_skip_inactive_batches',
            'optimization_hover_event_only',
            'optimization_navigation_light_mode',
            'optimization_lightest_freeze_batches_during_navigation',
            'optimization_lightest_disable_mesh_hover',
        )),
    )
    drawn_props = set()
    for label_en, label_ja, prop_names in groups:
        visible_props = tuple(prop_name for prop_name in prop_names if hasattr(prefs, prop_name) and prop_name not in drawn_props)
        if not visible_props:
            continue
        try:
            box = layout.box()
            _draw_icon_label(box, text=registry.localized(label_en, label_ja, context), icon='PREFERENCES', custom='optimize')
            col = box.column(align=True)
            col.use_property_split = False
            col.use_property_decorate = False
        except Exception:
            col = layout.column(align=True)
        for prop_name in visible_props:
            drawn_props.add(prop_name)
            try:
                row = col.row(align=True)
                row.scale_y = 0.92
                row.use_property_split = False
                row.use_property_decorate = False
                row.prop(prefs, prop_name)
            except Exception:
                try:
                    col.prop(prefs, prop_name)
                except Exception:
                    pass
        if label_en == 'Draw Load and Hover':
            wm = getattr(context, 'window_manager', None)
            if wm is not None and hasattr(wm, 'sos_object_hover_click_select_enabled'):
                try:
                    row = col.row(align=True)
                    row.scale_y = 0.92
                    row.use_property_split = False
                    row.use_property_decorate = False
                    row.prop(
                        wm,
                        'sos_object_hover_click_select_enabled',
                        text=registry.localized(
                            'Object Mode: Select Occluded',
                            'オブジェクトモードで遮蔽物を選択',
                            context,
                        ),
                    )
                except Exception:
                    pass

    # Safety net: if a future preset adds another optimization property, it must
    # remain manually switchable instead of silently becoming preset-only.
    try:
        from . import preferences as _sos_preferences
        all_props = tuple(getattr(_sos_preferences, '_OPTIMIZATION_PROP_NAMES', ()) or ())
    except Exception:
        all_props = ()
    remaining = tuple(prop_name for prop_name in all_props if hasattr(prefs, prop_name) and prop_name not in drawn_props)
    if remaining:
        try:
            box = layout.box()
            _draw_icon_label(box, text=registry.localized('Other Optimization Switches', 'その他の最適化切り替え', context), icon='PREFERENCES', custom='optimize')
            col = box.column(align=True)
            col.use_property_split = False
            col.use_property_decorate = False
        except Exception:
            col = layout.column(align=True)
        for prop_name in remaining:
            drawn_props.add(prop_name)
            try:
                col.prop(prefs, prop_name)
            except Exception:
                pass

    return True

def _draw_optimization_group(layout, context, prefs, *, show_header: bool = True):
    del show_header
    return _draw_npanel_disclosure_group(
        layout,
        context,
        'optimization_root',
        'Feature Optimization',
        '機能の最適化',
        icon='PREFERENCES',
        help_topic='feature_optimization',
        draw_body=lambda body: _draw_optimization_section_body(body, context, prefs),
    )

def _draw_current_status_section(layout, context, prefs):
    """Draw context/status rows without adding a second section title."""
    if layout is None:
        return False
    col = layout.column(align=True)
    try:
        col.use_property_split = False
        col.use_property_decorate = False
    except Exception:
        pass
    obj = _safe_context_object(context)
    mode_label = _ui_context_mode_label(context)
    if obj is not None:
        _draw_icon_label(col, text=f"{mode_label} | {obj.name}", icon='MESH_DATA' if obj.type == 'MESH' else 'OBJECT_DATA', custom='mesh_overlay' if obj.type == 'MESH' else 'object_hover')
    else:
        _draw_icon_label(col, text=mode_label, icon='OBJECT_DATA', custom='object_hover')

    if _safe_context_mode(context) == 'SCULPT':
        try:
            objs_in_mode = tuple(getattr(context, "objects_in_mode", ()) or ())
        except Exception:
            objs_in_mode = ()
        if len(objs_in_mode) > 1:
            _draw_icon_label(col, text=f"{mode_label} × {len(objs_in_mode)}", icon='SCULPTMODE_HLT', custom='object_hover')

    try:
        if prefs is not None and prefs.use_scene_overrides and getattr(context.scene, "sos_scene_overrides_enabled", False):
            _draw_icon_label(col, text=TI("Scene Overrides Enabled"), icon='FILE_BLEND', custom='scene')
    except Exception:
        pass
    try:
        if prefs is not None and getattr(prefs, "include_geometry_nodes_objects", False):
            _draw_icon_label(col, text=TI("Include Modifier Results"), icon='CHECKMARK', custom='apply')
    except Exception:
        pass
    try:
        if prefs is not None and getattr(prefs, "include_lattice_objects", True):
            _draw_icon_label(col, text=TI("Include Lattice Objects"), icon='CHECKMARK', custom='apply')
    except Exception:
        pass
    return True


def _draw_section_error(layout, context, label_en: str, label_ja: str = '', exc=None) -> None:
    """Show a small localized error block without aborting the rest of the root panel."""
    if layout is None:
        return
    try:
        col = layout.column(align=True)
        _draw_icon_label(col, text=registry.localized(label_en, label_ja or label_en, context), icon='ERROR', custom='error')
        col.label(
            text=registry.localized(
                'Could not draw this section.',
                'このセクションを描画できません。',
                context,
            )
        )
    except Exception:
        pass


def _draw_section_safely(layout, context, label_en: str, label_ja: str, draw_callable):
    """Draw one logical UI section; never let it hide following sections."""
    try:
        return draw_callable()
    except Exception as exc:
        _draw_section_error(layout, context, label_en, label_ja, exc)
    return None


_INTEGRATED_TOOLS_REPAIR_PENDING = False
_INTEGRATED_TOOLS_REPAIR_ATTEMPTS = 0


def _schedule_integrated_tools_repair(context=None) -> None:
    """Schedule a lightweight self-repair when embedded tool UI records are missing.

    Panel.draw must not perform class registration directly.  The timer runs
    immediately after the current draw pass, reloads the integrated tool records
    if necessary, and redraws all 3D View sidebars so the consolidated N-panel
    does not stay partially populated.
    """
    global _INTEGRATED_TOOLS_REPAIR_PENDING, _INTEGRATED_TOOLS_REPAIR_ATTEMPTS
    if _INTEGRATED_TOOLS_REPAIR_PENDING or _INTEGRATED_TOOLS_REPAIR_ATTEMPTS >= 3:
        return
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    if timers is None:
        return
    _INTEGRATED_TOOLS_REPAIR_PENDING = True

    def _repair_timer():
        global _INTEGRATED_TOOLS_REPAIR_PENDING, _INTEGRATED_TOOLS_REPAIR_ATTEMPTS
        try:
            try:
                from . import addon_runtime as integrated_addon_runtime
                integrated_addon_runtime.register()
            except Exception:
                pass
            try:
                ctx = getattr(bpy, 'context', None)
                wm = getattr(ctx, 'window_manager', None)
                seen = set()
                for window in getattr(wm, 'windows', ()) or ():
                    screen = getattr(window, 'screen', None)
                    for area in getattr(screen, 'areas', ()) or ():
                        if getattr(area, 'type', None) != 'VIEW_3D':
                            continue
                        key = int(getattr(area, 'as_pointer', lambda: id(area))())
                        if key in seen:
                            continue
                        seen.add(key)
                        try:
                            area.tag_redraw()
                        except Exception:
                            pass
            except Exception:
                pass
        finally:
            _INTEGRATED_TOOLS_REPAIR_ATTEMPTS += 1
            _INTEGRATED_TOOLS_REPAIR_PENDING = False
        return None

    try:
        timers.register(_repair_timer, first_interval=0.05)
    except Exception:
        _INTEGRATED_TOOLS_REPAIR_PENDING = False


def _integrated_tool_aliases_expected() -> tuple[str, ...]:
    try:
        aliases = tuple(getattr(registry, 'TOOL_FOLDERS', ()) or ())
    except Exception:
        aliases = ()
    aliases = tuple(alias for alias in aliases if str(alias) != 'image_dimensions_viewer')
    return aliases or ('smart_measure', 'silhouette')


def _known_integrated_panel_classes() -> list[tuple[str, type]]:
    """Return stale registered bundled Panel classes only as a legacy safety net."""
    names = (
        ('smart_measure', 'VIEW3D_PT_smart_measure_grid_overlay'),
        ('image_dimensions_viewer', 'VIEW3D_PT_idv_settings'),
        ('smart_measure', 'SMART_MEASURE_PT_Main'),
        ('smart_measure', 'SMART_MEASURE_PT_Edit'),
        ('smart_measure', 'SMART_MEASURE_PT_Conf'),
        ('smart_measure', 'SMART_MEASURE_PT_Render'),
        ('silhouette', 'VIEW3D_PT_silhouette'),
    )
    result: list[tuple[str, type]] = []
    for alias, class_name in names:
        try:
            cls = getattr(bpy.types, class_name, None)
        except Exception:
            cls = None
        if isinstance(cls, type):
            result.append((alias, cls))
    return result


_INTEGRATED_PANEL_ORDER = {
    'smart_measure': (
        'VIEW3D_PT_smart_measure_grid_overlay',
        'SMART_MEASURE_PT_Main',
        'SMART_MEASURE_PT_Edit',
        'SMART_MEASURE_PT_Conf',
        'SMART_MEASURE_PT_Render',
    ),
    'image_dimensions_viewer': (
        'VIEW3D_PT_idv_settings',
    ),
    'silhouette': (
        'VIEW3D_PT_silhouette',
    ),
}

_INTEGRATED_PANEL_LABEL_FALLBACKS = {
    'VIEW3D_PT_smart_measure_grid_overlay': ('Grid Scale Overlay', 'グリッドスケール表示'),
    'VIEW3D_PT_idv_settings': ('Image Dimensions Viewer', '画像サイズビューアー'),
    'SMART_MEASURE_PT_Main': ('Smart Measure Tools', 'スマート メジャー ツール'),
    'SMART_MEASURE_PT_Edit': ('Items', '項目'),
    'SMART_MEASURE_PT_Conf': ('Configuration', '設定'),
    'SMART_MEASURE_PT_Render': ('Render', 'レンダー'),
    'VIEW3D_PT_silhouette': ('Silhouette Mode', 'シルエットモード'),
}

_INTEGRATED_PANEL_HELP_TOPICS = {
    'VIEW3D_PT_smart_measure_grid_overlay': 'smart_measure_grid',
    'VIEW3D_PT_idv_settings': 'image_dimensions_viewer',
    'SMART_MEASURE_PT_Main': 'smart_measure_tools',
    'SMART_MEASURE_PT_Edit': 'smart_measure_items',
    'SMART_MEASURE_PT_Conf': 'smart_measure_configuration',
    'SMART_MEASURE_PT_Render': 'smart_measure_render',
    'VIEW3D_PT_silhouette': 'silhouette',
}


def _sos_unwrap_layout(layout):
    """Return the real UILayout behind the local flattening proxy."""
    try:
        if isinstance(layout, _SOSFlatLayoutProxy):
            return object.__getattribute__(layout, '_layout')
    except Exception:
        pass
    return layout


class _SOSFlatLayoutProxy:
    """UILayout proxy used only for embedded bundled-tool panels.

    Keep Blender's normal section boxes so Smart Overlay matches other N-panels.
    Only horizontal layout helpers are simplified below when old bundled panels
    would otherwise overflow the narrow sidebar.
    """

    __slots__ = ('_layout',)

    def __init__(self, layout):
        object.__setattr__(self, '_layout', layout)

    def __getattr__(self, name):
        return getattr(object.__getattribute__(self, '_layout'), name)

    def __setattr__(self, name, value):
        if name == '_layout':
            object.__setattr__(self, name, value)
        else:
            setattr(object.__getattribute__(self, '_layout'), name, value)

    def _wrap(self, value):
        try:
            if all(hasattr(value, attr) for attr in ('row', 'column', 'prop', 'label')):
                return _SOSFlatLayoutProxy(value)
        except Exception:
            pass
        return value

    def box(self):
        # Keep real UILayout.box() backgrounds.  Flattening boxes into columns
        # made embedded Smart Overlay sections look transparent compared with
        # other N-panels.
        return self._wrap(object.__getattribute__(self, '_layout').box())

    def column(self, *args, **kwargs):
        return self._wrap(object.__getattribute__(self, '_layout').column(*args, **kwargs))

    def row(self, *args, **kwargs):
        # Preserve actual rows.  Converting rows to columns made icon-only help
        # operators expand into full-width horizontal bars and caused the lower
        # integrated-tool area to look offset.  Nested boxes and split columns
        # are still flattened below, which is the part that creates cumulative
        # N-panel indentation.
        return self._wrap(object.__getattribute__(self, '_layout').row(*args, **kwargs))

    def split(self, *args, **kwargs):
        # Split layouts reserve horizontal columns and were a major source of
        # narrow N-panel overflow in embedded/legacy tool UIs.  In flattened
        # bodies they become vertical columns instead.
        return self._wrap(object.__getattribute__(self, '_layout').column(align=True))

    def grid_flow(self, *args, **kwargs):
        return self._wrap(object.__getattribute__(self, '_layout').column(align=True))

    def column_flow(self, *args, **kwargs):
        return self._wrap(object.__getattribute__(self, '_layout').column(align=True))


class _SOSInlinePanelProxy:
    """Minimal object used to call bundled Panel.draw() inside the root panel."""

    __slots__ = ('layout',)

    def __init__(self, layout):
        self.layout = _SOSFlatLayoutProxy(layout)


def _integrated_panel_label(cls, alias: str, context=None) -> str:
    class_name = str(getattr(cls, '__name__', '') or '').strip()
    en, ja = _INTEGRATED_PANEL_LABEL_FALLBACKS.get(class_name, ('', ''))
    if not en:
        en = str(getattr(cls, 'bl_label', '') or class_name or alias).strip()
        ja = ''
    if class_name in {'VIEW3D_PT_idv_settings', 'VIEW3D_PT_silhouette'}:
        try:
            return registry.tool_label(alias, context)
        except Exception:
            pass
    if ja:
        return registry.localized(en, ja, context)
    return TI(en)



def _integrated_panel_help_topic(cls, alias: str) -> str:
    class_name = str(getattr(cls, '__name__', '') or getattr(cls, 'bl_idname', '') or '').strip()
    topic = str(_INTEGRATED_PANEL_HELP_TOPICS.get(class_name, '') or '').strip()
    if topic:
        return topic
    return str(alias or '').strip()


def _integrated_panel_sort_key(cls, order_names: tuple[str, ...]) -> tuple[int, int, str]:
    class_name = str(getattr(cls, '__name__', '') or '').strip()
    try:
        index = order_names.index(class_name)
    except ValueError:
        index = 10_000
    try:
        order = int(getattr(cls, 'bl_order', 10_000) or 10_000)
    except Exception:
        order = 10_000
    return (index, order, class_name)


def _integrated_panel_is_allowed(cls, context) -> bool:
    if not _context_is_panel_draw_safe(context):
        return False
    class_name = str(getattr(cls, '__name__', '') or getattr(cls, 'bl_idname', '') or '').strip()
    # Respect bundled panels' own poll() again.  The previous forced-True path
    # could draw measurement item panels while no active object existed after
    # deselect/mode changes, which is unsafe for Blender's panel backend.
    try:
        from . import loader as integrated_loader
        checker = getattr(integrated_loader, 'panel_poll_allows', None)
        if not callable(checker):
            checker = getattr(integrated_loader, '_panel_original_poll_allows', None)
        if callable(checker) and not bool(checker(cls, context)):
            return False
    except Exception:
        return False if class_name == 'SMART_MEASURE_PT_Edit' else True
    try:
        poll = getattr(cls, 'poll', None)
        if callable(poll) and not bool(poll(context)):
            return False
    except Exception:
        return False
    return True


def _draw_integrated_panel_class(layout, context, cls, alias: str, *, show_label: bool = True) -> bool:
    try:
        draw = getattr(cls, 'draw', None)
    except Exception:
        draw = None
    if not callable(draw):
        return False
    if not _integrated_panel_is_allowed(cls, context):
        return False

    if show_label:
        section = layout.box()
        try:
            section.use_property_split = False
            section.use_property_decorate = False
        except Exception:
            pass
        header_row = section.row(align=True)
        _draw_icon_label(header_row, text=_integrated_panel_label(cls, alias, context), icon='PLUGIN', custom=alias)
        topic = _integrated_panel_help_topic(cls, alias)
        if topic:
            _draw_help_button(header_row, context, topic)
        body = section.column(align=False)
    else:
        body = layout.column(align=False)
    try:
        body.use_property_split = False
        body.use_property_decorate = False
    except Exception:
        pass
    try:
        proxy = _SOSInlinePanelProxy(body)
        embedded_draw = getattr(cls, 'draw_embedded', None)
        if callable(embedded_draw) and not show_label:
            embedded_draw(proxy, context)
        else:
            draw(proxy, context)
        return True
    except Exception as exc:
        try:
            warn = body.column(align=True)
            _draw_icon_label(warn, text=registry.localized('This tool UI was skipped safely.', 'このツールUIの描画を安全にスキップしました。', context), icon='ERROR', custom='error')
        except Exception:
            pass
    return False



def _draw_image_dimensions_viewer_settings_body(layout, context) -> bool:
    """Draw only the Image Dimensions Viewer settings body.

    This is used by the root N-panel top-level Image Dimensions Viewer group.
    It deliberately avoids the old embedded panel and avoids drawing a second
    nested Image Dimensions Viewer tool header, which was the source of the
    repeated right-shift pattern.
    """
    try:
        from . import image_dimensions_viewer as idv_module
        draw_body = getattr(idv_module, 'draw_smart_overlay_ui', None)
        if callable(draw_body):
            return bool(draw_body(layout, context))
        draw_compat = getattr(idv_module, 'draw_rebuilt_settings_ui', None)
        if callable(draw_compat):
            return bool(draw_compat(layout, context, include_tool_header=False))
    except Exception:
        pass
    return _draw_image_dimensions_viewer_direct_tool(layout, context)


def _draw_image_dimensions_viewer_direct_tool(layout, context) -> bool:
    """Draw Image Dimensions Viewer through its dedicated rebuilt UI path.

    The root panel no longer falls back to old embedded Panel.draw callbacks for
    this tool.  If the dedicated drawer cannot be imported, draw a visible error
    group instead of silently leaving the Image Dimensions Viewer section empty.
    """
    error_text = ''
    try:
        from . import image_dimensions_viewer as idv_module
        draw_tool = getattr(idv_module, 'draw_smart_overlay_tool_ui', None)
        if callable(draw_tool) and bool(draw_tool(layout, context)):
            return True
        error_text = registry.localized(
            'The Image Dimensions Viewer drawer returned no UI.',
            '画像サイズビューアーの描画関数がUIを返しませんでした。',
            context,
        )
    except Exception as exc:
        error_text = str(exc or '')[:180]

    try:
        box = layout.column(align=True)
        row = box.row(align=True)
        _draw_icon_label(
            row,
            text=registry.localized('Image Dimensions Viewer', '画像サイズビューアー', context),
            icon='IMAGE',
            custom='image_editor',
        )
        box.label(
            text=registry.localized(
                'Image Dimensions Viewer UI is unavailable.',
                '画像サイズビューアーUIを表示できません。',
                context,
            ),
            icon='ERROR',
        )
        return True
    except Exception:
        return False


def _draw_integrated_tool_panel_contents(layout, context) -> bool:
    """Draw every bundled tool UI inside the single Smart Overlay root panel."""
    global _INTEGRATED_TOOLS_REPAIR_ATTEMPTS
    if layout is None:
        return False

    grouped: dict[str, list[type]] = {}

    try:
        from . import loader as integrated_loader
        records = list(integrated_loader.get_records())
    except Exception:
        records = []

    for record in records:
        spec = record.get('spec') or {}
        alias = str(spec.get('alias') or '').strip()
        if not alias or str(record.get('status') or '') != 'loaded':
            continue
        if alias == 'image_dimensions_viewer':
            continue
        panels = [cls for cls in list(record.get('panels') or ()) if isinstance(cls, type)]
        if panels:
            grouped.setdefault(alias, []).extend(panels)

    # Merge in stale registered bundled Panel classes only as a legacy safety net.
    # Current builds capture embedded Panel classes without registering them, but
    # this still lets the root panel draw and self-repair after in-place updates.
    for alias, cls in _known_integrated_panel_classes():
        if alias == 'image_dimensions_viewer':
            continue
        existing_names = {str(getattr(item, '__name__', '') or '') for item in grouped.get(alias, ())}
        class_name = str(getattr(cls, '__name__', '') or '')
        if class_name and class_name not in existing_names:
            grouped.setdefault(alias, []).append(cls)

    expected_aliases = set(_integrated_tool_aliases_expected())
    if not grouped:
        _schedule_integrated_tools_repair(context)
        return _draw_image_dimensions_viewer_direct_tool(layout, context)
    if expected_aliases and any(alias not in grouped for alias in expected_aliases):
        _schedule_integrated_tools_repair(context)
    elif expected_aliases:
        _INTEGRATED_TOOLS_REPAIR_ATTEMPTS = 0

    drawn_any = False
    seen_global: set[type] = set()
    preferred_aliases = ('smart_measure', 'silhouette')
    draw_aliases = preferred_aliases + tuple(alias for alias in grouped.keys() if alias not in preferred_aliases)
    for alias in draw_aliases:
        panels = [cls for cls in grouped.get(alias, ()) if isinstance(cls, type) and cls not in seen_global]
        if not panels:
            continue
        for cls in panels:
            seen_global.add(cls)

        order_names = tuple(_INTEGRATED_PANEL_ORDER.get(alias, ()))
        if order_names:
            by_name = {str(getattr(cls, '__name__', '') or ''): cls for cls in panels}
            ordered = [by_name[name] for name in order_names if name in by_name]
            ordered.extend(cls for cls in panels if cls not in ordered)
            panels = ordered
        panels.sort(key=lambda cls: _integrated_panel_sort_key(cls, order_names))

        tool_box = layout.box()
        try:
            tool_box.use_property_split = False
            tool_box.use_property_decorate = False
        except Exception:
            pass
        header_row = tool_box.row(align=True)
        try:
            _draw_icon_label(header_row, text=registry.tool_label(alias, context), icon='PLUGIN', custom=alias)
        except Exception:
            _draw_icon_label(header_row, text=str(alias).replace('_', ' ').title(), icon='PLUGIN', custom='integrated')
        _draw_help_button(header_row, context, alias)

        if len(panels) == 1:
            if _draw_integrated_panel_class(tool_box, context, panels[0], alias, show_label=False):
                drawn_any = True
            continue

        for panel_index, cls in enumerate(panels):
            if panel_index > 0:
                try:
                    tool_box.separator()
                except Exception:
                    pass
            section = tool_box.box()
            try:
                section.use_property_split = False
                section.use_property_decorate = False
            except Exception:
                pass
            section_header = section.row(align=True)
            _draw_icon_label(section_header, text=_integrated_panel_label(cls, alias, context), icon='DOT', custom=alias)
            topic = _integrated_panel_help_topic(cls, alias)
            if topic:
                _draw_help_button(section_header, context, topic)
            if _draw_integrated_panel_class(section, context, cls, alias, show_label=False):
                drawn_any = True

    return drawn_any

def _draw_integrated_tool_alias_contents(layout, context, target_alias: str) -> bool:
    """Draw one bundled integrated tool as a top-level Smart Overlay section body."""
    alias = str(target_alias or '').strip()
    if not alias:
        return False
    try:
        from . import loader as integrated_loader
        records = list(integrated_loader.get_records())
    except Exception:
        records = []

    panels = []
    for record in records:
        spec = record.get('spec') or {}
        rec_alias = str(spec.get('alias') or '').strip()
        if rec_alias != alias or str(record.get('status') or '') != 'loaded':
            continue
        panels.extend(cls for cls in list(record.get('panels') or ()) if isinstance(cls, type))

    existing_names = {str(getattr(item, '__name__', '') or '') for item in panels}
    for rec_alias, cls in _known_integrated_panel_classes():
        if rec_alias != alias or not isinstance(cls, type):
            continue
        class_name = str(getattr(cls, '__name__', '') or '')
        if class_name and class_name not in existing_names:
            panels.append(cls)
            existing_names.add(class_name)

    if not panels:
        _schedule_integrated_tools_repair(context)
        try:
            layout.label(text=registry.localized('Loading tool settings.', 'ツール設定を読み込んでいます。', context), icon='TIME')
        except Exception:
            pass
        return False

    order_names = tuple(_INTEGRATED_PANEL_ORDER.get(alias, ()))
    if order_names:
        by_name = {str(getattr(cls, '__name__', '') or ''): cls for cls in panels}
        ordered = [by_name[name] for name in order_names if name in by_name]
        ordered.extend(cls for cls in panels if cls not in ordered)
        panels = ordered
    panels.sort(key=lambda cls: _integrated_panel_sort_key(cls, order_names))

    drawn_any = False
    if len(panels) == 1:
        return bool(_draw_integrated_panel_class(layout, context, panels[0], alias, show_label=False))

    seen = set()
    for panel_index, cls in enumerate(panels):
        if cls in seen:
            continue
        seen.add(cls)
        if panel_index > 0:
            try:
                layout.separator()
            except Exception:
                pass
        section = layout.box()
        try:
            section.use_property_split = False
            section.use_property_decorate = False
        except Exception:
            pass
        section_header = section.row(align=True)
        _draw_icon_label(section_header, text=_integrated_panel_label(cls, alias, context), icon='DOT', custom=alias)
        topic = _integrated_panel_help_topic(cls, alias)
        if topic:
            _draw_help_button(section_header, context, topic)
        if _draw_integrated_panel_class(section, context, cls, alias, show_label=False):
            drawn_any = True
    return drawn_any




def _draw_npanel_child_disclosure_group(layout, context, key: str, label_en: str, label_ja: str, *, icon: str = 'NONE', help_topic: str = '', draw_body=None) -> bool:
    """Draw one child section through Blender's native panel API only."""
    if layout is None:
        return False
    label = registry.localized(label_en, label_ja or label_en, context)
    panel_id = 'sos_child_' + ''.join(ch if (ch.isalnum() or ch == '_') else '_' for ch in str(key or '').strip())
    if panel_id == 'sos_child_':
        panel_id = 'sos_child_section'

    try:
        wm = getattr(context, 'window_manager', None)
        prop_name = npanel_child_panel_prop_name(key)
        if wm is not None and hasattr(wm, prop_name) and hasattr(layout, 'panel_prop'):
            header, body = layout.panel_prop(wm, prop_name)
        else:
            header, body = layout.panel(panel_id, default_closed=not _npanel_group_open(key, True))
    except Exception:
        return False

    try:
        header.use_property_split = False
        header.use_property_decorate = False
    except Exception:
        pass
    try:
        _draw_icon_label(header, text=label, icon=icon)
    except Exception:
        try:
            header.label(text=label, icon=str(icon or 'NONE') or 'NONE')
        except Exception:
            pass
    if help_topic:
        _draw_help_button(header, context, help_topic)
    if body is None:
        return True

    try:
        body.use_property_split = False
        body.use_property_decorate = False
    except Exception:
        pass
    if callable(draw_body):
        draw_body(body)
    return True

def _draw_presets_io_child(layout, context, prefs) -> bool:
    """Merged Presets and Scene Overrides child."""
    if layout is None or prefs is None:
        return False
    _draw_presets_section(layout, context, prefs, show_section_header=False)
    try:
        layout.separator()
    except Exception:
        pass
    _draw_scene_overrides_section(layout, context, prefs, show_section_header=False)
    return True




def _draw_manual_shortcut_registration(layout, prefs, prop_name: str, *, location: str = 'Preferences > Keymap > 3D View') -> None:
    """Draw a manual-only shortcut registration note and copyable operator ID."""
    try:
        layout.label(text=TI('Recommended Keymap Location'))
        location_text = TI(location)
        if 'Image' in location:
            head, _sep, tail = location_text.rpartition(' > ')
            layout.label(text=head + ' >')
            layout.label(text=tail)
        else:
            layout.label(text=location_text)
        row = layout.row(align=True)
        row.label(text=TI('Registration ID'))
        op = row.operator('sos.copy_shortcut_id', text=TI('Copy'), icon='COPYDOWN')
        op.text = str(getattr(prefs, prop_name, '') or '')
    except Exception:
        pass


def _draw_mesh_overlay_shortcut_toggle(layout, context, prefs) -> bool:
    if layout is None or prefs is None:
        return False
    try:
        layout.separator()
        box = layout.box()
        col = box.column(align=True)
        col.use_property_split = False
        col.use_property_decorate = False
        wm = getattr(context, 'window_manager', None)
        mesh_enabled = bool(getattr(wm, 'sos_enabled', False))
        row = col.row(align=True)
        op = row.operator(
            'view3d.sos_toggle_overlay',
            text=TI('Enable'),
            **_operator_icon_kwargs('switch_on' if mesh_enabled else 'switch_off', 'CHECKBOX_HLT' if mesh_enabled else 'CHECKBOX_DEHLT'),
            depress=mesh_enabled,
        )
        del op
        col.label(text=TI('How to add a shortcut'))
        _draw_manual_shortcut_registration(col, prefs, 'operator_identifier_display')
        return True
    except Exception as exc:
        _draw_section_error(layout, context, 'Mesh and Curve Overlay Shortcut', 'メッシュ・カーブ表示ショートカット', exc)
        return False

def _draw_mesh_overlay_group_body(layout, context, prefs) -> bool:
    if layout is None or prefs is None:
        return False
    child_sections = (
        ('vertex', 'Vertex Settings', '頂点設定', 'VERTEXSEL', 'vertex_overlay', lambda body: _draw_element_section(body, prefs, 'Vertex', 'VERTEXSEL', 'verts', 'vertex', context=context, show_section_header=False)),
        ('edge', 'Edge Settings', '辺設定', 'EDGESEL', 'edge_overlay', lambda body: _draw_element_section(body, prefs, 'Edge', 'EDGESEL', 'edges', 'edge', context=context, show_section_header=False)),
        ('face', 'Face Settings', '面設定', 'FACESEL', 'face_overlay', lambda body: _draw_element_section(body, prefs, 'Face', 'FACESEL', 'faces', 'face', context=context, show_section_header=False)),
        ('object_hover', 'Object / Sculpt Hover Color', 'オブジェクトホバーカラー', 'OBJECT_DATAMODE', 'object_sculpt_hover', lambda body: _draw_object_sculpt_hover_combined_child(body, context, prefs)),
        ('occluded', 'Occluded Display Mode', '遮蔽表示モード', 'XRAY', 'occluded_display', lambda body: _draw_occluded_section(body, context, prefs, show_section_header=False)),
        ('edge_aa', 'Edge Anti-Aliasing', '辺のアンチエイリアス', 'MOD_SMOOTH', 'edge_aa', lambda body: _draw_edge_aa_section(body, context, prefs, show_section_header=False)),
        ('presets', 'Presets / I/O', 'プリセット・入出力', 'PRESET', 'presets', lambda body: _draw_presets_io_child(body, context, prefs)),
    )
    for key, label_en, label_ja, icon, help_topic, draw_callable in child_sections:
        try:
            _draw_npanel_child_disclosure_group(
                layout,
                context,
                key,
                label_en,
                label_ja,
                icon=icon,
                help_topic=help_topic,
                draw_body=lambda body, _call=draw_callable, _le=label_en, _lj=label_ja: _draw_section_safely(body, context, _le, _lj, lambda: _call(body)),
            )
        except Exception as exc:
            _draw_section_error(layout, context, label_en, label_ja, exc)
    _draw_mesh_overlay_shortcut_toggle(layout, context, prefs)
    return True


def _draw_high_precision_outline_group_body(layout, context, prefs) -> bool:
    if layout is None or prefs is None:
        return False
    try:
        _draw_reset_header(layout, reset_category='HIGH_PRECISION_OUTLINE')
        layout.prop(prefs, 'high_precision_outline_enabled', text=TI('Enable'))
        row = layout.row(align=True)
        row.enabled = bool(getattr(prefs, 'high_precision_outline_enabled', False))
        row.prop(prefs, 'high_precision_outline_color', text=TI('Outline Color'))
        row = layout.row(align=True)
        row.enabled = bool(getattr(prefs, 'high_precision_outline_enabled', False))
        row.prop(prefs, 'high_precision_outline_thickness', text=TI('Outline Thickness'), slider=True)
        return True
    except Exception as exc:
        _draw_section_error(layout, context, 'High-Precision Outline', '高精度アウトライン', exc)
        return False


def _draw_object_sculpt_hover_combined_child(layout, context, prefs) -> bool:
    """Object/Sculpt hover color with Hover Optimization merged into it."""
    if layout is None or prefs is None:
        return False
    _draw_object_hover_section(layout, context, prefs, show_section_header=False)
    try:
        layout.separator()
    except Exception:
        pass
    # Former Hover Optimization section, moved here without its own section title.
    _draw_reset_header(layout, reset_category='HOVER_OPT')
    _draw_popup_safe_enum_prop(layout, context, 'ADDON_PREFS', prefs, 'hover_lod_mode')
    try:
        if prefs.hover_lod_mode == 'AUTO':
            layout.prop(prefs, 'hover_lod_threshold_verts')
    except Exception:
        pass
    _draw_color_triplet(
        layout,
        prefs,
        [
            ('show_hov_verts', 'hover_vertex_color', 'Vertex'),
            ('show_hov_edges', 'hover_edge_color', 'Edge'),
            ('show_hov_faces', 'hover_face_color', 'Face'),
        ],
        horizontal=True,
    )
    return True



def _draw_hover_overlay_shortcut_toggle(layout, context, prefs) -> bool:
    if layout is None or prefs is None:
        return False
    try:
        layout.separator()
        box = layout.box()
        col = box.column(align=True)
        col.use_property_split = False
        col.use_property_decorate = False
        wm = getattr(context, 'window_manager', None)
        hover_enabled = bool(getattr(wm, 'sos_object_hover_overlay_enabled', False)) or bool(getattr(wm, 'sos_uv_overlay_enabled', False))
        row = col.row(align=True)
        op = row.operator(
            'view3d.sos_toggle_hover_overlay',
            text=TI('Enable'),
            **_operator_icon_kwargs('switch_on' if hover_enabled else 'switch_off', 'CHECKBOX_HLT' if hover_enabled else 'CHECKBOX_DEHLT'),
            depress=hover_enabled,
        )
        del op
        col.label(text=TI('How to add a shortcut'))
        _draw_manual_shortcut_registration(col, prefs, 'hover_operator_identifier_display')
        return True
    except Exception as exc:
        _draw_section_error(layout, context, 'Hover Overlay Shortcut', 'ホバーオーバーレイショートカット', exc)
        return False

def _draw_hover_overlay_group_body(layout, context, prefs) -> bool:
    if layout is None or prefs is None:
        return False
    child_sections = (
        ('object_hover', 'Object / Sculpt Hover Color', 'オブジェクトホバーカラー', 'OBJECT_DATAMODE', 'object_sculpt_hover', lambda body: _draw_object_sculpt_hover_combined_child(body, context, prefs)),
        ('uv_hover', 'UV Hover Color', 'UVホバーカラー', 'GROUP_UVS', 'uv_hover', lambda body: _draw_uv_hover_section(body, context, prefs, show_section_header=False, horizontal_colors=True)),
    )
    for key, label_en, label_ja, icon, help_topic, draw_callable in child_sections:
        try:
            _draw_npanel_child_disclosure_group(
                layout,
                context,
                key,
                label_en,
                label_ja,
                icon=icon,
                help_topic=help_topic,
                draw_body=lambda body, _call=draw_callable, _le=label_en, _lj=label_ja: _draw_section_safely(body, context, _le, _lj, lambda: _call(body)),
            )
        except Exception as exc:
            _draw_section_error(layout, context, label_en, label_ja, exc)
    _draw_hover_overlay_shortcut_toggle(layout, context, prefs)
    return True


def _draw_uv_overlay_shortcut_toggle(layout, context, prefs) -> bool:
    if layout is None or prefs is None:
        return False
    try:
        box = layout.box()
        col = box.column(align=True)
        col.use_property_split = False
        col.use_property_decorate = False
        wm = getattr(context, 'window_manager', None)
        enabled = bool(getattr(wm, 'sos_uv_overlay_enabled', False))
        row = col.row(align=True)
        op = row.operator(
            'image.sos_toggle_uv_overlay',
            text=TI('Enable'),
            **_operator_icon_kwargs('switch_on' if enabled else 'switch_off', 'CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT'),
            depress=enabled,
        )
        del op
        col.label(text=TI('How to add a shortcut'))
        col.label(text=TI('UV Overlay Toggle'))
        _draw_manual_shortcut_registration(col, prefs, 'uv_overlay_operator_identifier_display', location='Preferences > Keymap > Image / UV Editor')
        return True
    except Exception as exc:
        _draw_section_error(layout, context, 'UV Overlay Shortcut', 'UVのオーバーレイショートカット', exc)
        return False


def _draw_uv_overlay_group_body(layout, context, prefs) -> bool:
    if layout is None or prefs is None:
        return False
    _draw_uv_overlay_shortcut_toggle(layout, context, prefs)
    child_sections = (
        ('uv_hover', 'UV Hover Color', 'UVホバーカラー', 'GROUP_UVS', 'uv_hover', lambda body: _draw_uv_hover_section(body, context, prefs, show_section_header=False, horizontal_colors=True)),
    )
    for key, label_en, label_ja, icon, help_topic, draw_callable in child_sections:
        try:
            _draw_npanel_child_disclosure_group(
                layout,
                context,
                key,
                label_en,
                label_ja,
                icon=icon,
                help_topic=help_topic,
                draw_body=lambda body, _call=draw_callable, _le=label_en, _lj=label_ja: _draw_section_safely(body, context, _le, _lj, lambda: _call(body)),
            )
        except Exception as exc:
            _draw_section_error(layout, context, label_en, label_ja, exc)
    return True


def _draw_other_tools_group_body(layout, context, prefs) -> bool:
    if layout is None:
        return False
    child_sections = (
        ('topology', 'Topology Checks', 'トポロジーチェック', 'MOD_WIREFRAME', 'topology_checks', lambda body: _draw_topology_section(body, context, prefs, show_section_header=False)),
        ('image_dimensions_viewer', 'Image Dimensions Viewer', '画像サイズビューアー', 'IMAGE', 'image_dimensions_viewer', lambda body: _draw_image_dimensions_viewer_settings_body(body, context)),
        ('smart_measure', 'Smart Measure', 'スマート メジャー', 'DRIVER_DISTANCE', 'smart_measure', lambda body: _draw_integrated_tool_alias_contents(body, context, 'smart_measure')),
        ('silhouette', 'Silhouette Mode', 'シルエットモード', 'SHADING_SOLID', 'silhouette', lambda body: _draw_integrated_tool_alias_contents(body, context, 'silhouette')),
    )
    for key, label_en, label_ja, icon, help_topic, draw_callable in child_sections:
        try:
            _draw_npanel_child_disclosure_group(
                layout,
                context,
                key,
                label_en,
                label_ja,
                icon=icon,
                help_topic=help_topic,
                draw_body=lambda body, _call=draw_callable, _le=label_en, _lj=label_ja: _draw_section_safely(body, context, _le, _lj, lambda: _call(body)),
            )
        except Exception as exc:
            _draw_section_error(layout, context, label_en, label_ja, exc)
    return True

def _draw_npanel_disclosure_group(layout, context, key: str, label_en: str, label_ja: str, *, icon: str = 'NONE', help_topic: str = '', draw_body=None) -> bool:
    """Draw one top-level section with Smart Tools' shared boxed header style."""
    if layout is None:
        return False
    label = registry.localized(label_en, label_ja or label_en, context)
    is_open = _npanel_group_open(key, True)
    try:
        box = layout.box()
        try:
            box.use_property_split = False
            box.use_property_decorate = False
        except Exception:
            pass
        header = box.row(align=True)
        try:
            header.use_property_split = False
            header.use_property_decorate = False
        except Exception:
            pass
        try:
            op = header.operator(
                'view3d.sos_toggle_npanel_group',
                text='',
                icon='TRIA_DOWN' if is_open else 'TRIA_RIGHT',
                emboss=True,
                depress=is_open,
            )
            op.group_key = str(key or '')
        except Exception:
            try:
                header.label(text='', icon='TRIA_DOWN' if is_open else 'TRIA_RIGHT')
            except Exception:
                pass
        # Shared Smart Tools section header: triangle, borderless icon+title,
        # small gap, compact help.  _draw_help_button adds the 0.35 gap and the
        # scale_x 0.82 help row itself, so the header row is passed directly.
        try:
            op = header.operator(
                'view3d.sos_toggle_npanel_group',
                text=label,
                emboss=False,
                depress=is_open,
                **_icon_kwargs(icon, icon),
            )
            op.group_key = str(key or '')
        except Exception:
            try:
                _draw_icon_label(header, text=label, icon=icon)
            except Exception:
                header.label(text=label)
        if help_topic:
            _draw_help_button(header, context, help_topic)
        if not is_open:
            return True
        # Keep the shared top-level Smart Tools box style, but draw the body
        # directly in a column so child content does not add an extra background
        # layer and reintroduce the previous opacity offset.
        body = box.column(align=True)
        body.use_property_split = False
        body.use_property_decorate = False
    except Exception:
        try:
            header = layout.row(align=True)
            _draw_icon_label(header, text=label, icon=icon)
            if help_topic:
                _draw_help_button(header, context, help_topic)
            if not is_open:
                return True
            body = layout.column(align=True)
        except Exception:
            body = layout

    try:
        if callable(draw_body):
            draw_body(body)
    except Exception:
        pass
    return True


def draw_view3d_sidebar_contents(layout, context):
    if not _context_is_panel_draw_safe(context):
        return False
    prefs = _prefs(context)
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
        layout.operator_context = 'EXEC_DEFAULT'
    except Exception:
        pass

    if _ui_context_is_mode_transition_unsafe(context):
        _draw_transient_context_notice(layout, context)
        return True

    root = layout
    try:
        root.use_property_split = False
        root.use_property_decorate = False
    except Exception:
        pass

    _draw_section_safely(
        root,
        context,
        'Always-on Toggles',
        '常時機能切り替え',
        lambda: _draw_always_on_toggles_group(root, context),
    )

    if prefs is not None:
        _draw_section_safely(
            root,
            context,
            'Feature Optimization',
            '機能の最適化',
            lambda: _draw_optimization_group(root, context, prefs),
        )

    if prefs is None:
        warn = root.box()
        _draw_icon_label(warn, text=TI('Smart Overlay preferences are unavailable.'), icon='ERROR', custom='error')
        return True

    top_sections = (
        ('mesh_overlay_root', 'Mesh and Curve Overlay', 'メッシュ・カーブ表示', 'MESH_DATA', 'mesh_overlay', lambda body: _draw_mesh_overlay_group_body(body, context, prefs)),
        ('high_precision_outline_root', 'High-Precision Outline', '高精度アウトライン', 'MOD_WIREFRAME', 'high_precision_outline', lambda body: _draw_high_precision_outline_group_body(body, context, prefs)),
        ('uv_overlay_root', 'UV Overlay', 'UVのオーバーレイ', 'GROUP_UVS', 'uv_hover', lambda body: _draw_uv_overlay_group_body(body, context, prefs)),
        ('proportional_overlay_root', 'Proportional Overlay', 'プロポーション表示', 'MOD_VERTEX_WEIGHT', 'proportional_overlay', lambda body: _draw_proportional_section(body, context, prefs, show_section_header=False)),
        ('other_tools_root', 'Other Tools', 'その他ツール', 'TOOL_SETTINGS', 'integrated_tools', lambda body: _draw_other_tools_group_body(body, context, prefs)),
    )
    for key, label_en, label_ja, icon, help_topic, draw_callable in top_sections:
        try:
            _draw_npanel_disclosure_group(
                root,
                context,
                key,
                label_en,
                label_ja,
                icon=icon,
                help_topic=help_topic,
                draw_body=lambda body, _call=draw_callable, _le=label_en, _lj=label_ja: _draw_section_safely(body, context, _le, _lj, lambda: _call(body)),
            )
        except Exception as exc:
            _draw_section_error(root, context, label_en, label_ja, exc)
    return True


# ---------------------------------------------------------------------------
# Legacy compatibility operator
# ---------------------------------------------------------------------------


def _sos_enum_dialog_items(self, context):
    target = _enum_target_from_context(context, getattr(self, 'target_kind', ''))
    prop_name = str(getattr(self, 'prop_name', '') or '')
    items = []
    for index, item in enumerate(_enum_prop_items(target, prop_name)):
        identifier = str(getattr(item, 'identifier', '') or '')
        if not identifier:
            continue
        items.append((
            identifier,
            TI(str(getattr(item, 'name', identifier) or identifier)),
            TT(str(getattr(item, 'description', '') or '')),
            str(getattr(item, 'icon', 'NONE') or 'NONE'),
            index,
        ))
    if not items:
        items.append(('__NONE__', _enum_dialog_text('select_setting', context), '', 0, 0))
    cache_key = (
        str(getattr(self, 'target_kind', '') or ''),
        prop_name,
        'JA' if _ui_is_japanese(context) else 'EN',
    )
    _SOS_ENUM_DIALOG_ITEMS_CACHE[cache_key] = items
    return _SOS_ENUM_DIALOG_ITEMS_CACHE[cache_key]


def _sos_enum_dialog_items_enum(self, context):
    return _sos_enum_dialog_items(self, context)


class SOS_OT_CopyShortcutId(bpy.types.Operator):
    bl_idname = 'sos.copy_shortcut_id'
    bl_label = 'Copy Registration ID'
    bl_description = 'Copy the ID used to register this command in Preferences > Keymap.'
    bl_options = {'INTERNAL'}

    text: bpy.props.StringProperty(options={'SKIP_SAVE', 'HIDDEN'})

    def execute(self, context):
        context.window_manager.clipboard = str(self.text or '')
        return {'FINISHED'}


class SOS_OT_ToggleNPanelGroup(bpy.types.Operator):
    bl_idname = 'view3d.sos_toggle_npanel_group'
    bl_label = 'Toggle Smart Overlay Group'
    bl_description = 'Open or close this Smart Overlay N-panel group.'
    bl_options = {'INTERNAL', 'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    group_key: bpy.props.StringProperty(
        name='Group Key',
        description='Internal Smart Overlay N-panel group key.',
        default='',
        options={'HIDDEN', 'SKIP_SAVE'},
    )

    def execute(self, context):
        key = str(getattr(self, 'group_key', '') or '').strip()
        if not key:
            return {'CANCELLED'}
        _set_npanel_group_open(key, not _npanel_group_open(key, True), context)
        return {'FINISHED'}


class SOS_OT_EnumDialogPopup(bpy.types.Operator):
    bl_idname = 'wm.sos_enum_dialog_popup'
    bl_label = 'Select Setting'
    bl_description = 'Open a detached enum picker dialog.'
    bl_options = {'INTERNAL', 'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    target_kind: bpy.props.StringProperty(name='Target Kind', description='Internal target owner used by the detached enum popup.', default='', options={'HIDDEN', 'SKIP_SAVE'})
    prop_name: bpy.props.StringProperty(name='Property Name', description='Internal RNA enum property name edited by the detached enum popup.', default='', options={'HIDDEN', 'SKIP_SAVE'})
    label_text: bpy.props.StringProperty(name='Label Text', description='Internal label shown at the top of the detached enum popup.', default='', options={'HIDDEN', 'SKIP_SAVE'})
    enum_value: bpy.props.EnumProperty(name='Enum Value', description='Choose the value to apply to the selected Smart Overlay enum setting.', items=_sos_enum_dialog_items_enum, options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        target = _enum_target_from_context(context, getattr(properties, 'target_kind', ''))
        prop_name = str(getattr(properties, 'prop_name', '') or '')
        label_text = str(getattr(properties, 'label_text', '') or '')
        return _enum_dialog_operator_description(context, target, prop_name, fallback_label=label_text)

    def invoke(self, context, event):
        target = _enum_target_from_context(context, getattr(self, 'target_kind', ''))
        prop_name = str(getattr(self, 'prop_name', '') or '')
        if target is None or _enum_rna_property(target, prop_name) is None:
            return {'CANCELLED'}
        current_value = str(getattr(target, prop_name, '') or '')
        identifiers = [str(getattr(item, 'identifier', '') or '') for item in _enum_prop_items(target, prop_name)]
        if current_value in identifiers:
            self.enum_value = current_value
        elif identifiers:
            self.enum_value = identifiers[0]
        try:
            type(self).bl_label = str(getattr(self, 'label_text', '') or _enum_dialog_text('select_setting', context))
        except Exception:
            pass
        return context.window_manager.invoke_props_dialog(self, width=_enum_dialog_width(context))

    def draw(self, context):
        layout = self.layout
        try:
            layout.use_property_split = False
            layout.use_property_decorate = False
        except Exception:
            pass
        target = _enum_target_from_context(context, getattr(self, 'target_kind', ''))
        prop_name = str(getattr(self, 'prop_name', '') or '')
        label_text = str(getattr(self, 'label_text', '') or _enum_prop_label(target, prop_name, fallback=prop_name))
        _draw_icon_label(layout, text=label_text, icon='DOWNARROW_HLT', custom='tridown')
        col = layout.column(align=True)
        for item in _enum_prop_items(target, prop_name):
            identifier = str(getattr(item, 'identifier', '') or '')
            if not identifier:
                continue
            col.prop_enum(self, 'enum_value', identifier, text=TI(str(getattr(item, 'name', identifier) or identifier)))

    def execute(self, context):
        target = _enum_target_from_context(context, getattr(self, 'target_kind', ''))
        prop_name = str(getattr(self, 'prop_name', '') or '')
        value = str(getattr(self, 'enum_value', '') or '')
        if target is None or _enum_rna_property(target, prop_name) is None or not value or value == '__NONE__':
            return {'CANCELLED'}
        try:
            setattr(target, prop_name, value)
        except Exception:
            return {'CANCELLED'}
        try:
            from . import settings
            settings.queue_save(context)
        except Exception:
            pass
        wm = getattr(context, 'window_manager', None)
        for window in getattr(wm, 'windows', ()):
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()):
                _tag_redraw_area(area)
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# 3D View N-panel panels
# ---------------------------------------------------------------------------



class _SOS_RootPanelMixin:
    bl_label = PANEL_TAB_NAME
    bl_region_type = 'UI'
    bl_category = PANEL_NATIVE_CATEGORY
    bl_owner_id = PANEL_OWNER_ID
    bl_order = 1
    _sos_suite_id = 'smart_overlay_suite'
    _sos_root_schema = 1
    _smart_suite_host_panel = True
    _smart_tools_manager_tool_key = 'SMART_OVERLAY'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_no_cross_editor_proxy = True

    @classmethod
    def poll(cls, context):
        return _smart_overlay_sidebar_panel_poll(context)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False

        if not _context_is_panel_draw_safe(context):
            # Keep the tab and a minimal body alive even when Blender calls draw()
            # from a partially rebuilt or nonstandard Sidebar context.  Returning
            # an entirely empty panel can make users think the category failed to
            # appear, while this placeholder avoids touching unstable RNA data.
            _draw_transient_context_notice(layout, context)
            return

        if _ui_context_is_mode_transition_unsafe(context):
            _draw_transient_context_notice(layout, context)
            return

        _draw_section_safely(
            layout,
            context,
            'Smart Overlay Settings',
            'スマートオーバーレイ設定',
            lambda: draw_view3d_sidebar_contents(layout, context),
        )


def _sos_root_panel_manager_safe_poll(cls, context):
    return _smart_overlay_sidebar_panel_poll(context)


def _sos_root_panel_manager_wrapper_active(callable_obj) -> bool:
    try:
        func = getattr(callable_obj, '__func__', callable_obj)
        return bool(getattr(func, '_smart_tools_manager_wrapper', False))
    except Exception:
        return False


def repair_smart_tools_manager_panel_wrappers() -> bool:
    """Keep Smart Overlay root panels visible under Smart_Tools_Manager.

    Smart_Tools_Manager wraps external panel poll/draw callbacks.  Its current
    JSON uses n_panel.rules as the live N-panel source, while an older top-level
    rules table can remain stale.  When the manager wrapper reads the stale table,
    the Smart Overlay category tab may be active but the real panel body is hidden.
    This function repairs only Smart Overlay's own root Panel callbacks, still
    respecting the manager ON/OFF rule through _smart_overlay_sidebar_panel_poll,
    and never edits Smart_Tools_Manager files or classes.
    """
    changed = False
    for cls in globals().get('_PANEL_CLASSES', ()) or ():
        if not isinstance(cls, type):
            continue
        try:
            poll_attr = getattr(cls, 'poll', None)
            if _sos_root_panel_manager_wrapper_active(poll_attr):
                cls.poll = classmethod(_sos_root_panel_manager_safe_poll)
                changed = True
        except Exception:
            pass
        try:
            draw_attr = getattr(cls, 'draw', None)
            if _sos_root_panel_manager_wrapper_active(draw_attr):
                cls.draw = _SOS_RootPanelMixin.draw
                changed = True
        except Exception:
            pass
        try:
            header_attr = getattr(cls, 'draw_header', None)
            if _sos_root_panel_manager_wrapper_active(header_attr):
                # Root panels intentionally have no custom header body.  Setting a
                # no-op prevents a manager wrapper from hiding the whole body when
                # its own readiness check is based on a stale rule cache.
                def _sos_root_header_noop(self, context):
                    return None
                cls.draw_header = _sos_root_header_noop
                changed = True
        except Exception:
            pass
    try:
        changed = bool(ensure_smart_tools_manager_bridge_panels()) or changed
    except Exception:
        pass
    return bool(changed)


_MANAGER_BRIDGE_PANEL_CLASSES = {}


def _sos_iter_panel_subclasses_recursive(base=None):
    try:
        base = base or bpy.types.Panel
        stack = list(base.__subclasses__())
    except Exception:
        return
    seen = set()
    while stack:
        cls = stack.pop()
        try:
            key = int(getattr(cls, 'as_pointer', lambda: id(cls))())
        except Exception:
            key = id(cls)
        if key in seen:
            continue
        seen.add(key)
        yield cls
        try:
            stack.extend(list(cls.__subclasses__()))
        except Exception:
            pass


def _sos_manager_anchor_classes_for_smart_overlay():
    anchors = []
    for cls in _sos_iter_panel_subclasses_recursive() or ():
        try:
            if not bool(getattr(cls, '_smart_tools_manager_anchor', False)):
                continue
            if str(getattr(cls, '_smart_tools_manager_tool_key', '') or '') != 'SMART_OVERLAY':
                continue
            if str(getattr(cls, 'bl_region_type', '') or '') != 'UI':
                continue
            if str(getattr(cls, 'bl_space_type', '') or '') not in SMART_OVERLAY_NPANEL_SPACE_SET:
                continue
            if not str(getattr(cls, 'bl_idname', '') or ''):
                continue
            anchors.append(cls)
        except Exception:
            continue
    return tuple(anchors)


def _sos_root_class_for_space_type(space_type: str):
    space_type = str(space_type or '')
    for cls in globals().get('_PANEL_CLASSES', ()) or ():
        try:
            if str(getattr(cls, 'bl_space_type', '') or '') == space_type:
                return cls
        except Exception:
            pass
    return None


def _sos_workspace_owner_filter_contains(context, owner_id: str) -> bool:
    owner_id = str(owner_id or '').strip()
    if not owner_id:
        return True
    try:
        workspace = getattr(context, 'workspace', None) or getattr(getattr(context, 'window', None), 'workspace', None)
        if workspace is None:
            return True
        if not bool(getattr(workspace, 'use_filter_by_owner', False)):
            return True
        owners = {str(getattr(item, 'name', '') or '').strip() for item in getattr(workspace, 'owner_ids', ()) or ()}
        if owner_id in owners:
            return True
        leaf = owner_id.rsplit('.', 1)[-1]
        return any(str(value or '').rsplit('.', 1)[-1] == leaf for value in owners)
    except Exception:
        return True


def _sos_root_panel_likely_visible_in_context(context, space_type: str) -> bool:
    root_cls = _sos_root_class_for_space_type(space_type)
    if not isinstance(root_cls, type):
        return False
    try:
        if getattr(bpy.types, str(getattr(root_cls, '__name__', '') or ''), None) is not root_cls:
            return False
    except Exception:
        return False
    try:
        if _sos_root_panel_manager_wrapper_active(getattr(root_cls, 'poll', None)):
            return False
        if _sos_root_panel_manager_wrapper_active(getattr(root_cls, 'draw', None)):
            return False
    except Exception:
        return False
    try:
        owner_id = str(getattr(root_cls, 'bl_owner_id', '') or '').strip()
        if not _sos_workspace_owner_filter_contains(context, owner_id):
            return False
    except Exception:
        return False
    try:
        return bool(root_cls.poll(context))
    except Exception:
        return False


def _sos_manager_bridge_panel_poll(cls, context):
    try:
        from . import common as _sos_common
        workspace_key_fn = getattr(_sos_common, '_manager_active_workspace_key', None)
        rule_fn = getattr(_sos_common, '_smart_tools_manager_workspace_rule', None)
        if not callable(workspace_key_fn) or not callable(rule_fn):
            return False
        workspace_key = workspace_key_fn(context)
        target_editor = str(getattr(cls, '_sos_manager_bridge_editor_key', '') or '')
        if not bool(rule_fn(workspace_key, target_editor)):
            return False
    except Exception:
        return False
    try:
        root_visible = _sos_root_panel_likely_visible_in_context(context, str(getattr(cls, 'bl_space_type', '') or ''))
        if root_visible:
            return False
    except Exception:
        pass
    return True


def _sos_manager_bridge_panel_draw(self, context):
    # Draw the exact same body as the native Smart Overlay root panel.  The
    # fallback is a normal top-level panel in the same category, not a child of
    # Smart Tools Manager's hidden anchor: nesting added an extra Blender panel
    # body and made the entire Smart Overlay UI look one opacity level lighter.
    return _SOS_RootPanelMixin.draw(self, context)


def _make_sos_manager_bridge_panel_class(anchor_cls):
    try:
        anchor_id = str(getattr(anchor_cls, 'bl_idname', '') or getattr(anchor_cls, '__name__', '') or '')
        space_type = str(getattr(anchor_cls, 'bl_space_type', '') or '')
        editor_key = str(getattr(anchor_cls, '_smart_tools_manager_editor_key', '') or '')
    except Exception:
        return None
    if not anchor_id or not space_type or not editor_key:
        return None
    import hashlib
    digest = hashlib.md5(anchor_id.encode('utf-8', errors='ignore')).hexdigest()[:12]
    prefix_by_space = {
        'VIEW_3D': 'VIEW3D',
        'IMAGE_EDITOR': 'IMAGE',
        'NODE_EDITOR': 'NODE',
        'SEQUENCE_EDITOR': 'SEQUENCER',
        'CLIP_EDITOR': 'CLIP',
        'DOPESHEET_EDITOR': 'DOPESHEET',
        'GRAPH_EDITOR': 'GRAPH',
        'NLA_EDITOR': 'NLA',
        'TEXT_EDITOR': 'TEXT',
        'FILE_BROWSER': 'FILEBROWSER',
        'SPREADSHEET': 'SPREADSHEET',
    }
    prefix = prefix_by_space.get(space_type, 'VIEW3D')
    class_name = f'{prefix}_PT_sos_manager_bridge_{digest}'
    attrs = {
        '__module__': 'sos_manager_bridge_panels',
        '_sos_suite_id': 'smart_overlay_suite',
        '_sos_manager_bridge_panel': True,
        '_sos_manager_bridge_anchor_id': anchor_id,
        '_sos_manager_bridge_editor_key': editor_key,
        '_smart_suite_host_panel': True,
        '_smart_tools_manager_native_npanel_root': True,
        '_smart_tools_manager_no_cross_editor_proxy': True,
        '_smart_tools_manager_no_active_object_required': True,
        '_smart_tools_manager_tool_key': 'SMART_OVERLAY',
        'bl_idname': class_name,
        'bl_label': PANEL_TAB_NAME,
        'bl_space_type': space_type,
        'bl_region_type': 'UI',
        'bl_category': PANEL_NATIVE_CATEGORY,
        'bl_owner_id': str(getattr(anchor_cls, 'bl_owner_id', '') or PANEL_OWNER_ID),
        'bl_order': 0,
        'poll': classmethod(_sos_manager_bridge_panel_poll),
        'draw': _sos_manager_bridge_panel_draw,
    }
    return type(class_name, (bpy.types.Panel,), attrs)


def ensure_smart_tools_manager_bridge_panels() -> bool:
    changed = False
    anchors = _sos_manager_anchor_classes_for_smart_overlay()
    desired = set()
    for anchor_cls in anchors:
        try:
            anchor_id = str(getattr(anchor_cls, 'bl_idname', '') or getattr(anchor_cls, '__name__', '') or '')
        except Exception:
            anchor_id = ''
        if not anchor_id:
            continue
        desired.add(anchor_id)
        cls = _MANAGER_BRIDGE_PANEL_CLASSES.get(anchor_id)
        if not isinstance(cls, type):
            cls = _make_sos_manager_bridge_panel_class(anchor_cls)
            if not isinstance(cls, type):
                continue
            _MANAGER_BRIDGE_PANEL_CLASSES[anchor_id] = cls
        try:
            existing = getattr(bpy.types, str(getattr(cls, '__name__', '') or ''), None)
        except Exception:
            existing = None
        if existing is not cls:
            if isinstance(existing, type):
                if not _sos_class_is_suite_owned(existing):
                    # Never replace a foreign class that happens to use the same
                    # generated identifier.
                    continue
                try:
                    bpy.utils.unregister_class(existing)
                except Exception:
                    pass
            try:
                bpy.utils.register_class(cls)
                changed = True
            except Exception:
                pass
    for anchor_id, cls in list(_MANAGER_BRIDGE_PANEL_CLASSES.items()):
        if anchor_id in desired:
            continue
        try:
            existing = getattr(bpy.types, str(getattr(cls, '__name__', '') or ''), None)
        except Exception:
            existing = None
        if existing is cls:
            try:
                bpy.utils.unregister_class(cls)
                changed = True
            except Exception:
                pass
        _MANAGER_BRIDGE_PANEL_CLASSES.pop(anchor_id, None)
    return bool(changed)


def unregister_smart_tools_manager_bridge_panels() -> None:
    for _anchor_id, cls in list(_MANAGER_BRIDGE_PANEL_CLASSES.items()):
        try:
            existing = getattr(bpy.types, str(getattr(cls, '__name__', '') or ''), None)
        except Exception:
            existing = None
        if existing is cls:
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass
    _MANAGER_BRIDGE_PANEL_CLASSES.clear()


class VIEW3D_PT_sos_root(_SOS_RootPanelMixin, bpy.types.Panel):
    bl_idname = "VIEW3D_PT_sos_root"
    bl_space_type = 'VIEW_3D'


class IMAGE_PT_sos_root(_SOS_RootPanelMixin, bpy.types.Panel):
    bl_idname = "IMAGE_PT_sos_root"
    bl_space_type = 'IMAGE_EDITOR'


class NODE_PT_sos_root(_SOS_RootPanelMixin, bpy.types.Panel):
    bl_idname = "NODE_PT_sos_root"
    bl_space_type = 'NODE_EDITOR'


class SEQUENCER_PT_sos_root(_SOS_RootPanelMixin, bpy.types.Panel):
    bl_idname = "SEQUENCER_PT_sos_root"
    bl_space_type = 'SEQUENCE_EDITOR'


class CLIP_PT_sos_root(_SOS_RootPanelMixin, bpy.types.Panel):
    bl_idname = "CLIP_PT_sos_root"
    bl_space_type = 'CLIP_EDITOR'


class DOPESHEET_PT_sos_root(_SOS_RootPanelMixin, bpy.types.Panel):
    bl_idname = "DOPESHEET_PT_sos_root"
    bl_space_type = 'DOPESHEET_EDITOR'


class GRAPH_PT_sos_root(_SOS_RootPanelMixin, bpy.types.Panel):
    bl_idname = "GRAPH_PT_sos_root"
    bl_space_type = 'GRAPH_EDITOR'


class NLA_PT_sos_root(_SOS_RootPanelMixin, bpy.types.Panel):
    bl_idname = "NLA_PT_sos_root"
    bl_space_type = 'NLA_EDITOR'


class TEXT_PT_sos_root(_SOS_RootPanelMixin, bpy.types.Panel):
    bl_idname = "TEXT_PT_sos_root"
    bl_space_type = 'TEXT_EDITOR'


class FILEBROWSER_PT_sos_root(_SOS_RootPanelMixin, bpy.types.Panel):
    bl_idname = "FILEBROWSER_PT_sos_root"
    bl_space_type = 'FILE_BROWSER'
    _smart_tools_manager_editor_keys = ('FILE_BROWSER',)

    @classmethod
    def poll(cls, context):
        return (getattr(context.space_data, 'browse_mode', None) == 'FILES'
                and _smart_overlay_sidebar_panel_poll(context))


class ASSETBROWSER_PT_sos_root(_SOS_RootPanelMixin, bpy.types.Panel):
    bl_idname = 'ASSETBROWSER_PT_sos_root'
    bl_space_type = 'FILE_BROWSER'
    bl_region_type = 'TOOL_PROPS'
    bl_options = {'DEFAULT_CLOSED'}
    _smart_tools_manager_editor_keys = ('ASSET_BROWSER',)

    @classmethod
    def poll(cls, context):
        return (getattr(context.space_data, 'browse_mode', None) == 'ASSETS'
                and _smart_overlay_sidebar_panel_poll(context))


class SPREADSHEET_PT_sos_root(_SOS_RootPanelMixin, bpy.types.Panel):
    bl_idname = "SPREADSHEET_PT_sos_root"
    bl_space_type = 'SPREADSHEET'


# Split Panel classes from older builds were intentionally removed from the
# registration path.  All core sections are drawn by the Smart Overlay root
# panel registered for each supported N-panel editor space.


# ---------------------------------------------------------------------------
# Viewport Overlay menu hook
# ---------------------------------------------------------------------------

def draw_menu(self, context):
    # The always-on switches are centralized in the root Smart Overlay panel.
    # Keep this hook as a no-op so older appended callbacks do not recreate
    # duplicate toggle buttons in the viewport overlay popover.
    del self, context
    return


_PANEL_CLASSES = [
    VIEW3D_PT_sos_root,
    IMAGE_PT_sos_root,
    NODE_PT_sos_root,
    SEQUENCER_PT_sos_root,
    CLIP_PT_sos_root,
    DOPESHEET_PT_sos_root,
    GRAPH_PT_sos_root,
    NLA_PT_sos_root,
    TEXT_PT_sos_root,
    FILEBROWSER_PT_sos_root,
    ASSETBROWSER_PT_sos_root,
    SPREADSHEET_PT_sos_root,
]
_PANEL_CLASS_NAME_SET = frozenset(cls.__name__ for cls in _PANEL_CLASSES)

for _sos_panel_cls in _PANEL_CLASSES:
    try:
        _sos_panel_cls.__module__ = 'sos_native_panels'
    except Exception:
        pass

for _sos_panel_cls in _PANEL_CLASSES:
    try:
        _sos_apply_panel_owner(_sos_panel_cls)
    except Exception:
        pass

_LEGACY_SIDE_PANEL_CLASS_NAMES = (
    # Core split panels from older Smart Overlay builds.  Children are listed
    # before parents so Blender can unregister stale parent/child panel trees.
    'VIEW3D_PT_sos_occluded_display_mode',
    'VIEW3D_PT_sos_vertex',
    'VIEW3D_PT_sos_edge',
    'VIEW3D_PT_sos_face',
    'VIEW3D_PT_sos_mesh_overlay',
    'VIEW3D_PT_sos_hover_optimization',
    'VIEW3D_PT_sos_object_hover',
    'VIEW3D_PT_sos_uv_hover',
    'VIEW3D_PT_sos_hover_overlay',
    'VIEW3D_PT_sos_edge_anti_aliasing',
    'VIEW3D_PT_sos_topology_checks',
    'VIEW3D_PT_sos_proportional_overlay',
    'VIEW3D_PT_sos_presets',
    'VIEW3D_PT_sos_scene_overrides',
    # Bundled tool panels from older direct-panel builds. Current builds do not
    # register these standalone panels; this cleanup removes stale leftovers.
    'SMART_MEASURE_PT_Edit',
    'SMART_MEASURE_PT_Conf',
    'SMART_MEASURE_PT_Render',
    'SMART_MEASURE_PT_Main',
    'VIEW3D_PT_smart_measure_grid_overlay',
    # Legacy names before Smart Measure consolidation.  These must be removed on
    # every register pass, because stale registered Panel classes can keep a
    # freed Python draw/poll callback alive and crash Blender's ui_handler_panel
    # during mode switches or outliner deselection.
    'MEASURE' + 'IT_PT_Edit',
    'MEASURE' + 'IT_PT_Conf',
    'MEASURE' + 'IT_PT_Render',
    'MEASURE' + 'IT_PT_Main',
    'VIEW3D_PT_' + 'grid' + '_' + 'dimension' + '_overlay',
    'VIEW3D_PT_idv_settings',
    'VIEW3D_PT_silhouette',
)


def _unregister_non_root_smart_overlay_panels() -> None:
    """Remove stale Smart Overlay category panels that are not current roots.

    Older builds registered many child panels and generated integrated-tool
    panels.  If one survives an in-place update, Blender draws it after the new
    root panel and the sidebar appears shifted/overflowing.  The current build
    owns one visible root panel per supported N-panel editor space, so every
    other Panel in the Smart Overlay category is stale and must be removed.
    """
    panel_base = getattr(bpy.types, 'Panel', None)
    for name in tuple(dir(bpy.types)):
        if name in _PANEL_CLASS_NAME_SET:
            continue
        try:
            cls = getattr(bpy.types, name, None)
        except Exception:
            continue
        if not isinstance(cls, type):
            continue
        try:
            if panel_base is None or not issubclass(cls, panel_base):
                continue
        except Exception:
            continue
        try:
            if str(getattr(cls, 'bl_region_type', '') or '') != 'UI':
                continue
            if str(getattr(cls, 'bl_category', '') or '') != PANEL_TAB_NAME:
                continue
            # Smart Tools Manager owns lightweight category anchors/proxies for
            # workspace Filter Add-ons. Smart Overlay must never unregister
            # those external manager panels; doing so can make the Smart Overlay
            # N-panel tab disappear even when the manager rule is ON.
            if _sos_is_external_manager_panel(cls):
                continue
            if not _sos_class_is_suite_owned(cls):
                continue
        except Exception:
            continue
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass


def unregister_legacy_side_panels() -> None:
    """Remove side panels left by older builds so only the root panel is visible."""
    # Run multiple passes: child panels must disappear before their parents, and
    # some stale classes fail once while Blender is rebuilding panel trees.
    for _pass in range(3):
        for class_name in _LEGACY_SIDE_PANEL_CLASS_NAMES:
            try:
                cls = getattr(bpy.types, class_name, None)
            except Exception:
                cls = None
            if isinstance(cls, type) and _sos_class_is_suite_owned(cls):
                try:
                    bpy.utils.unregister_class(cls)
                except Exception:
                    pass
        _unregister_non_root_smart_overlay_panels()

for _sos_panel_cls in _PANEL_CLASSES:
    try:
        _sos_panel_cls._sos_suite_id = 'smart_overlay_suite'
        _sos_panel_cls._sos_root_schema = 1
        _sos_panel_cls._smart_suite_host_panel = True
        _sos_panel_cls._smart_tools_manager_tool_key = 'SMART_OVERLAY'
        _sos_panel_cls._smart_tools_manager_native_npanel_root = True
        _sos_panel_cls._smart_tools_manager_no_cross_editor_proxy = True
    except Exception:
        pass
del _sos_panel_cls

CLASSES = (
    SOS_OT_CopyShortcutId,
    SOS_OT_ToggleNPanelGroup,
    SOS_OT_EnumDialogPopup,
    *_PANEL_CLASSES,
)
