# SPDX-License-Identifier: GPL-3.0-or-later
# Blender Extension / user_default compatible package
# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi
#  Official Contact: 
#  Video Tutorials: 
#
#  This file is part of the Smart Overlay Suite package.
#  Licensed under the GNU General Public License v3.0 or later
#  (GPL-3.0-or-later).
# ------------------------------------------------------------------------------

import json
import textwrap
import time

import bpy
from bpy.props import (
    FloatVectorProperty,
    FloatProperty,
    BoolProperty,
    StringProperty,
    IntProperty,
    EnumProperty,
    CollectionProperty,
)

from .translation import T, TI
from . import mesh
from . import presets
from . import registry
from . import settings
from . import icons as sos_icons


# =============================================================================
# Preset Items (User presets)
# =============================================================================
class SOS_PresetItem(bpy.types.PropertyGroup):
    name: StringProperty(name="Name", description="Preset name shown in the Smart Overlay N-panel preset menu.", default="")
    data: StringProperty(name="Data (JSON)", description="Internal JSON data for this Smart Overlay user preset. Edit presets from the N-panel instead of editing this storage text directly.", default="", options={'HIDDEN'})

# =============================================================================
# Callbacks
# =============================================================================
def _update_prefs(self, context):
    mesh.clear_cache_and_redraw(context)
    try:
        mesh.apply_blender_adjacent_edge_gradient_visibility(context, self)
    except Exception:
        pass
    try:
        settings.queue_save(context)
    except Exception:
        pass


def _update_uv_overlay_prefs(self, context):
    """Refresh the finite UV snapshot pipeline after a public UV style change."""
    try:
        settings.queue_save(context)
    except Exception:
        pass
    try:
        from . import uv
        ctx = context or bpy.context
        state = getattr(uv, '_state', None)
        wm = getattr(ctx, 'window_manager', None)
        if bool(getattr(state, 'runtime_registered', False)) and bool(
            getattr(wm, 'sos_uv_overlay_enabled', False)
        ):
            uv.request_uv_snapshot_rebuild(
                'public_uv_setting_changed',
                context=ctx,
                immediate=False,
            )
            uv._tag_uv_image_redraw(ctx)
    except Exception:
        pass


def _update_high_precision_outline_enabled(self, context):
    try:
        from . import high_precision_outline
        if bool(getattr(self, 'high_precision_outline_enabled', False)):
            high_precision_outline.prepare_enable(context, self)
        high_precision_outline.sync_runtime(context)
    except Exception:
        pass
    try:
        settings.queue_save(context)
    except Exception:
        pass


def _update_high_precision_outline_style(self, context):
    """Redraw a style-only change without rebuilding cached outline geometry."""
    try:
        from . import high_precision_outline
        high_precision_outline.tag_style_redraw(context)
    except Exception:
        pass
    try:
        settings.queue_save(context)
    except Exception:
        pass


# Backward-compatible callback name used by older internal code paths.
def _update_high_precision_outline_color(self, context):
    _update_high_precision_outline_style(self, context)


def _tag_uv_editor_redraw(context=None):
    try:
        ctx = context or bpy.context
        wm = getattr(ctx, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                try:
                    if getattr(area, 'type', None) == 'IMAGE_EDITOR':
                        area.tag_redraw()
                except Exception:
                    pass
    except Exception:
        pass


def _update_prop_uv_editor_display(self, context):
    _update_prefs(self, context)
    _tag_uv_editor_redraw(context)



_OPTIMIZATION_PRESET_GUARD = False
_OPTIMIZATION_AUTO_CUSTOM_GUARD = False
_OPTIMIZATION_CUSTOM_STORAGE_PROP = 'optimization_custom_settings_json'
_OPTIMIZATION_PREVIOUS_PROFILE_PROP = 'optimization_previous_profile'

_MESH_OPTIMIZATION_SETTING_PROP_NAMES = (
    'double_sided',
    'active_view_only',
    'active_view_draw_only',
    'hide_occluded_colors_when_xray_off',
    'hide_visible_occluded_when_occluded_off',
    'use_all_objects_as_occluders',
    'include_geometry_nodes_objects',
    'include_curve_shape_overlay',
    'include_lattice_objects',
    'use_evaluated_edit_mode_face_overlay',
    'use_select_mode_vertex_center_overlay',
    'hide_blender_standard_edit_edges_vertices',
    'hide_blender_adjacent_edge_gradient',
    'hide_blender_vertex_mode_linked_edge_face_overlay',
    'hide_blender_edge_mode_linked_vertex_face_overlay',
    'hide_blender_face_mode_linked_vertex_edge_overlay',
)

_OPTIMIZATION_RUNTIME_PROP_NAMES = (
    'optimization_dirty_generation_cache',
    'optimization_disable_timed_live_sync_flush',
    'optimization_split_evaluated_face_cache',
    'optimization_async_evaluated_face_rebuild',
    'optimization_reuse_stale_evaluated_faces',
    'optimization_throttle_evaluated_face_rebuild',
    'optimization_evaluated_face_rebuild_interval',
    'optimization_target_modifier_dependency_dirty',
    'optimization_conditional_depth_prepass',
    'optimization_indexed_edit_batches',
    'optimization_skip_inactive_batches',
    'optimization_hover_event_only',
    'optimization_split_topology_cache',
    'show_embedded_edit_cage_while_view_still_xray_off',
    'optimization_navigation_light_mode',
    'optimization_lightest_freeze_batches_during_navigation',
    'optimization_lightest_active_object_only',
    'optimization_lightest_disable_mesh_hover',
    'optimization_lightest_disable_occluded_pass',
    'high_precision_outline_hide_occluded_in_xray',
    'optimization_lightest_disable_topology_diagnostics',
    'optimization_lightest_lod_skip_dense_vertices_edges',
    'optimization_lightest_lod_element_limit',
)

_OPTIMIZATION_WINDOW_MANAGER_PROP_NAMES = ('sos_object_hover_click_select_enabled',)
_OPTIMIZATION_PROP_NAMES = _MESH_OPTIMIZATION_SETTING_PROP_NAMES + _OPTIMIZATION_RUNTIME_PROP_NAMES + _OPTIMIZATION_WINDOW_MANAGER_PROP_NAMES

_OPTIMIZATION_PRESET_VALUES = {
    # Load class recalculation for the current Feature Optimization items:
    # - Highest Quality: correctness/visual scope first; no optional shortcuts.
    # - Standard: low-risk cache and draw reductions only.
    # - Lightweight: heavy-scene operation; async evaluated faces and redraw throttling enabled without hiding vertex/edge overlays.
    # - Lightest: maximum responsiveness; intentionally simplifies expensive targets/passes.
    'HIGHEST_QUALITY': {
        'sos_object_hover_click_select_enabled': True,
        'double_sided': True,
        'active_view_only': False,
        'active_view_draw_only': False,
        'hide_occluded_colors_when_xray_off': False,
        'hide_visible_occluded_when_occluded_off': False,
        'use_all_objects_as_occluders': False,
        'include_geometry_nodes_objects': True,
        'include_curve_shape_overlay': True,
        'include_lattice_objects': True,
        'use_evaluated_edit_mode_face_overlay': True,
        'use_select_mode_vertex_center_overlay': True,
        'hide_blender_standard_edit_edges_vertices': True,
        'hide_blender_adjacent_edge_gradient': True,
        'hide_blender_vertex_mode_linked_edge_face_overlay': False,
        'hide_blender_edge_mode_linked_vertex_face_overlay': False,
        'hide_blender_face_mode_linked_vertex_edge_overlay': False,
        'optimization_dirty_generation_cache': False,
        'optimization_disable_timed_live_sync_flush': False,
        'optimization_split_evaluated_face_cache': False,
        'optimization_async_evaluated_face_rebuild': False,
        'optimization_reuse_stale_evaluated_faces': False,
        'optimization_throttle_evaluated_face_rebuild': False,
        'optimization_evaluated_face_rebuild_interval': 0.05,
        'optimization_target_modifier_dependency_dirty': False,
        'optimization_conditional_depth_prepass': False,
        'optimization_indexed_edit_batches': False,
        'optimization_skip_inactive_batches': False,
        'optimization_hover_event_only': False,
        'optimization_split_topology_cache': False,
        'show_embedded_edit_cage_while_view_still_xray_off': True,
        'optimization_navigation_light_mode': False,
        'optimization_lightest_freeze_batches_during_navigation': False,
        'optimization_lightest_active_object_only': False,
        'optimization_lightest_disable_mesh_hover': False,
        'optimization_lightest_disable_occluded_pass': False,
        'high_precision_outline_hide_occluded_in_xray': False,
        'optimization_lightest_disable_topology_diagnostics': False,
        'optimization_lightest_lod_skip_dense_vertices_edges': False,
        'optimization_lightest_lod_element_limit': 300000,
    },
    'STANDARD': {
        'sos_object_hover_click_select_enabled': True,
        'double_sided': True,
        'active_view_only': True,
        'active_view_draw_only': True,
        'hide_occluded_colors_when_xray_off': True,
        'hide_visible_occluded_when_occluded_off': True,
        'use_all_objects_as_occluders': True,
        'include_geometry_nodes_objects': True,
        'include_curve_shape_overlay': True,
        'include_lattice_objects': True,
        'use_evaluated_edit_mode_face_overlay': True,
        'use_select_mode_vertex_center_overlay': True,
        'hide_blender_standard_edit_edges_vertices': True,
        'hide_blender_adjacent_edge_gradient': True,
        'hide_blender_vertex_mode_linked_edge_face_overlay': False,
        'hide_blender_edge_mode_linked_vertex_face_overlay': True,
        'hide_blender_face_mode_linked_vertex_edge_overlay': True,
        'optimization_dirty_generation_cache': True,
        'optimization_disable_timed_live_sync_flush': True,
        'optimization_split_evaluated_face_cache': True,
        'optimization_async_evaluated_face_rebuild': True,
        'optimization_reuse_stale_evaluated_faces': True,
        'optimization_throttle_evaluated_face_rebuild': True,
        'optimization_evaluated_face_rebuild_interval': 0.20,
        'optimization_target_modifier_dependency_dirty': True,
        'optimization_conditional_depth_prepass': True,
        'optimization_indexed_edit_batches': True,
        'optimization_skip_inactive_batches': True,
        'optimization_hover_event_only': True,
        'optimization_split_topology_cache': True,
        'show_embedded_edit_cage_while_view_still_xray_off': False,
        'optimization_navigation_light_mode': True,
        'optimization_lightest_freeze_batches_during_navigation': True,
        'optimization_lightest_active_object_only': True,
        'optimization_lightest_disable_mesh_hover': True,
        'optimization_lightest_disable_occluded_pass': False,
        'high_precision_outline_hide_occluded_in_xray': False,
        'optimization_lightest_disable_topology_diagnostics': False,
        'optimization_lightest_lod_skip_dense_vertices_edges': False,
        'optimization_lightest_lod_element_limit': 100000,
    },
    'LIGHTWEIGHT': {
        'sos_object_hover_click_select_enabled': True,
        'double_sided': False,
        'active_view_only': True,
        'active_view_draw_only': False,
        'hide_occluded_colors_when_xray_off': True,
        'hide_visible_occluded_when_occluded_off': False,
        'use_all_objects_as_occluders': False,
        'include_geometry_nodes_objects': True,
        'include_curve_shape_overlay': True,
        'include_lattice_objects': True,
        'use_evaluated_edit_mode_face_overlay': True,
        'use_select_mode_vertex_center_overlay': True,
        'hide_blender_standard_edit_edges_vertices': True,
        'hide_blender_adjacent_edge_gradient': True,
        'hide_blender_vertex_mode_linked_edge_face_overlay': False,
        'hide_blender_edge_mode_linked_vertex_face_overlay': False,
        'hide_blender_face_mode_linked_vertex_edge_overlay': False,
        'optimization_dirty_generation_cache': True,
        'optimization_disable_timed_live_sync_flush': True,
        'optimization_split_evaluated_face_cache': True,
        'optimization_async_evaluated_face_rebuild': True,
        'optimization_reuse_stale_evaluated_faces': True,
        'optimization_throttle_evaluated_face_rebuild': True,
        'optimization_evaluated_face_rebuild_interval': 0.50,
        'optimization_target_modifier_dependency_dirty': True,
        'optimization_conditional_depth_prepass': True,
        'optimization_indexed_edit_batches': True,
        'optimization_skip_inactive_batches': True,
        'optimization_hover_event_only': True,
        'optimization_split_topology_cache': True,
        'show_embedded_edit_cage_while_view_still_xray_off': True,
        'optimization_navigation_light_mode': True,
        'optimization_lightest_freeze_batches_during_navigation': True,
        'optimization_lightest_active_object_only': False,
        'optimization_lightest_disable_mesh_hover': False,
        'optimization_lightest_disable_occluded_pass': False,
        'high_precision_outline_hide_occluded_in_xray': False,
        'optimization_lightest_disable_topology_diagnostics': False,
        'optimization_lightest_lod_skip_dense_vertices_edges': True,
        'optimization_lightest_lod_element_limit': 50000,
    },
    'LIGHTEST': {
        'sos_object_hover_click_select_enabled': True,
        'double_sided': False,
        'active_view_only': True,
        'active_view_draw_only': True,
        'hide_occluded_colors_when_xray_off': True,
        'hide_visible_occluded_when_occluded_off': True,
        'use_all_objects_as_occluders': False,
        'include_geometry_nodes_objects': False,
        'include_curve_shape_overlay': False,
        'include_lattice_objects': False,
        'use_evaluated_edit_mode_face_overlay': False,
        'use_select_mode_vertex_center_overlay': True,
        'hide_blender_standard_edit_edges_vertices': True,
        'hide_blender_adjacent_edge_gradient': True,
        'hide_blender_vertex_mode_linked_edge_face_overlay': True,
        'hide_blender_edge_mode_linked_vertex_face_overlay': True,
        'hide_blender_face_mode_linked_vertex_edge_overlay': True,
        'optimization_dirty_generation_cache': True,
        'optimization_disable_timed_live_sync_flush': True,
        'optimization_split_evaluated_face_cache': True,
        'optimization_async_evaluated_face_rebuild': True,
        'optimization_reuse_stale_evaluated_faces': True,
        'optimization_throttle_evaluated_face_rebuild': True,
        'optimization_evaluated_face_rebuild_interval': 1.00,
        'optimization_target_modifier_dependency_dirty': True,
        'optimization_conditional_depth_prepass': True,
        'optimization_indexed_edit_batches': True,
        'optimization_skip_inactive_batches': True,
        'optimization_hover_event_only': True,
        'optimization_split_topology_cache': True,
        'show_embedded_edit_cage_while_view_still_xray_off': True,
        'optimization_navigation_light_mode': True,
        'optimization_lightest_freeze_batches_during_navigation': True,
        'optimization_lightest_active_object_only': True,
        'optimization_lightest_disable_mesh_hover': True,
        'optimization_lightest_disable_occluded_pass': True,
        'high_precision_outline_hide_occluded_in_xray': False,
        'optimization_lightest_disable_topology_diagnostics': True,
        'optimization_lightest_lod_skip_dense_vertices_edges': True,
        'optimization_lightest_lod_element_limit': 20000,
    },
}

# Lighter profiles are derived from the exact STANDARD contract so a new
# Standard field cannot silently retain a stale value or become more expensive
# in Lightweight/Lightest.  Deltas below only reduce visual scope or defer work.
_lightweight_values = _OPTIMIZATION_PRESET_VALUES['STANDARD'].copy()
_lightweight_values.update({
    'double_sided': False,
    'optimization_evaluated_face_rebuild_interval': 0.50,
    'optimization_lightest_lod_skip_dense_vertices_edges': True,
    'optimization_lightest_lod_element_limit': 50000,
})
_OPTIMIZATION_PRESET_VALUES['LIGHTWEIGHT'] = _lightweight_values

_lightest_values = _OPTIMIZATION_PRESET_VALUES['STANDARD'].copy()
_lightest_values.update({
    'double_sided': False,
    'include_geometry_nodes_objects': False,
    'include_curve_shape_overlay': False,
    'include_lattice_objects': False,
    'use_evaluated_edit_mode_face_overlay': False,
    'hide_blender_vertex_mode_linked_edge_face_overlay': True,
    'optimization_evaluated_face_rebuild_interval': 1.00,
    'optimization_lightest_disable_occluded_pass': True,
    'optimization_lightest_disable_topology_diagnostics': True,
    'optimization_lightest_lod_skip_dense_vertices_edges': True,
    'optimization_lightest_lod_element_limit': 20000,
})
_OPTIMIZATION_PRESET_VALUES['LIGHTEST'] = _lightest_values

# Highest Quality keeps full visual scope but retains computational shortcuts
# whose invalidation contracts preserve the same output.
_OPTIMIZATION_PRESET_VALUES['HIGHEST_QUALITY'].update({
    'optimization_dirty_generation_cache': True,
    'optimization_disable_timed_live_sync_flush': True,
    'optimization_split_evaluated_face_cache': True,
    'optimization_target_modifier_dependency_dirty': True,
    'optimization_conditional_depth_prepass': True,
    'optimization_indexed_edit_batches': True,
    'optimization_skip_inactive_batches': True,
    'optimization_hover_event_only': True,
    'optimization_split_topology_cache': True,
})

def _optimization_simple_value(value):
    if isinstance(value, bool):
        return bool(value)
    if isinstance(value, int) and not isinstance(value, bool):
        return int(value)
    if isinstance(value, float):
        return float(value)
    if isinstance(value, str):
        return str(value)
    return value


def _optimization_property_owner(self, prop_name: str, context=None):
    if self is not None and hasattr(self, prop_name):
        return self
    if prop_name in _OPTIMIZATION_WINDOW_MANAGER_PROP_NAMES:
        try:
            return getattr(context or getattr(bpy, 'context', None), 'window_manager', None)
        except Exception:
            return None
    return None


def _optimization_snapshot_values(self, context=None) -> dict:
    values = {}
    if self is None:
        return values
    for prop_name in _OPTIMIZATION_PROP_NAMES:
        try:
            owner = _optimization_property_owner(self, prop_name, context)
            if owner is not None and hasattr(owner, prop_name):
                values[prop_name] = _optimization_simple_value(getattr(owner, prop_name))
        except Exception:
            pass
    return values


def _optimization_snapshot_payload_from_values(values: dict | None) -> dict:
    clean = {}
    if isinstance(values, dict):
        for prop_name in _OPTIMIZATION_PROP_NAMES:
            if prop_name in values:
                clean[prop_name] = _optimization_simple_value(values.get(prop_name))
    return {'version': 1, 'values': clean}


def _optimization_snapshot_text(values: dict | None) -> str:
    try:
        return json.dumps(_optimization_snapshot_payload_from_values(values), ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    except Exception:
        return '{"version":1,"values":{}}'


def _optimization_load_custom_snapshot(self) -> dict:
    if self is None:
        return {}
    try:
        text = str(getattr(self, _OPTIMIZATION_CUSTOM_STORAGE_PROP, '') or '')
    except Exception:
        text = ''
    data = {}
    if text:
        try:
            loaded = json.loads(text)
            data = loaded if isinstance(loaded, dict) else {}
        except Exception:
            data = {}
    if not data:
        # Smart_Overlay_Suite.json is the authoritative Custom-profile store.
        # Hidden AddonPreferences storage is only a mirror, so recover from the
        # external JSON whenever Blender has not populated the hidden text yet.
        try:
            loader = getattr(settings, 'load_optimization_custom_profile_now', None)
            if callable(loader):
                loaded = loader(getattr(bpy, 'context', None))
                data = loaded if isinstance(loaded, dict) else {}
                if data:
                    try:
                        setattr(self, _OPTIMIZATION_CUSTOM_STORAGE_PROP, _optimization_snapshot_text(data.get('values', data)))
                    except Exception:
                        pass
        except Exception:
            data = {}
    if isinstance(data, dict) and isinstance(data.get('values'), dict):
        raw = data.get('values')
    elif isinstance(data, dict):
        raw = data
    else:
        raw = {}
    values = {}
    for prop_name in _OPTIMIZATION_PROP_NAMES:
        if prop_name in raw:
            values[prop_name] = raw.get(prop_name)
    return values


def get_optimization_custom_profile_snapshot(prefs=None) -> dict:
    if prefs is None:
        try:
            prefs = registry.resolve_addon_preferences(getattr(bpy, 'context', None))
        except Exception:
            prefs = None
    values = _optimization_load_custom_snapshot(prefs)
    if not values:
        values = _optimization_snapshot_values(prefs)
    return _optimization_snapshot_payload_from_values(values)


def set_optimization_custom_profile_snapshot(prefs, snapshot) -> bool:
    if prefs is None:
        return False
    if isinstance(snapshot, dict) and isinstance(snapshot.get('values'), dict):
        values = snapshot.get('values')
    elif isinstance(snapshot, dict):
        values = snapshot
    else:
        values = {}
    text = _optimization_snapshot_text(values)
    try:
        if hasattr(prefs, _OPTIMIZATION_CUSTOM_STORAGE_PROP):
            setattr(prefs, _OPTIMIZATION_CUSTOM_STORAGE_PROP, text)
            return True
    except Exception:
        return False
    return False


def _optimization_set_previous_profile(self, profile: str) -> None:
    try:
        if hasattr(self, _OPTIMIZATION_PREVIOUS_PROFILE_PROP):
            setattr(self, _OPTIMIZATION_PREVIOUS_PROFILE_PROP, str(profile or ''))
    except Exception:
        pass


def _optimization_get_previous_profile(self) -> str:
    try:
        return str(getattr(self, _OPTIMIZATION_PREVIOUS_PROFILE_PROP, '') or '')
    except Exception:
        return ''


def _optimization_store_custom_snapshot(self, context=None, *, persist: bool = False) -> bool:
    if self is None:
        return False
    values = _optimization_snapshot_values(self, context)
    text = _optimization_snapshot_text(values)
    changed = False
    try:
        if hasattr(self, _OPTIMIZATION_CUSTOM_STORAGE_PROP) and str(getattr(self, _OPTIMIZATION_CUSTOM_STORAGE_PROP, '') or '') != text:
            setattr(self, _OPTIMIZATION_CUSTOM_STORAGE_PROP, text)
            changed = True
    except Exception:
        return False
    if persist:
        snapshot = _optimization_snapshot_payload_from_values(values)
        saved = False
        try:
            saver = getattr(settings, 'save_optimization_custom_profile_now', None)
            if callable(saver):
                saved = bool(saver(context, snapshot=snapshot))
        except Exception:
            saved = False
        if not saved:
            try:
                saved = bool(settings.save_now(context, force=True))
            except Exception:
                saved = False
        if not saved:
            try:
                settings.queue_save(context)
            except Exception:
                pass
    elif changed:
        try:
            settings.queue_save(context)
        except Exception:
            pass
    return True


def _optimization_values_match_preset(self, preset_id: str, context=None) -> bool:
    values = _OPTIMIZATION_PRESET_VALUES.get(str(preset_id or ''), None)
    if not values or self is None:
        return False
    for prop_name, preset_value in values.items():
        try:
            owner = _optimization_property_owner(self, prop_name, context)
            if owner is None or not hasattr(owner, prop_name):
                continue
            current = getattr(owner, prop_name)
            if isinstance(preset_value, float):
                if abs(float(current) - float(preset_value)) > 1e-7:
                    return False
            else:
                if current != preset_value:
                    return False
        except Exception:
            return False
    return True


def _optimization_values_match_any_builtin(self) -> bool:
    for preset_id in _OPTIMIZATION_PRESET_VALUES.keys():
        if _optimization_values_match_preset(self, preset_id):
            return True
    return False


def _apply_optimization_preset_values(self, preset_id: str, context=None) -> None:
    values = _OPTIMIZATION_PRESET_VALUES.get(str(preset_id or ''), None)
    if not values:
        return
    for prop_name, value in values.items():
        try:
            owner = _optimization_property_owner(self, prop_name, context)
            if owner is not None and hasattr(owner, prop_name):
                setattr(owner, prop_name, value)
        except Exception:
            pass


def _restore_optimization_custom_values(self, context=None, *, persist: bool = True) -> bool:
    global _OPTIMIZATION_PRESET_GUARD
    values = _optimization_load_custom_snapshot(self)
    if not values:
        _optimization_store_custom_snapshot(self, context, persist=persist)
        return False
    _OPTIMIZATION_PRESET_GUARD = True
    try:
        for prop_name, value in values.items():
            try:
                owner = _optimization_property_owner(self, prop_name, context)
                if owner is not None and hasattr(owner, prop_name):
                    setattr(owner, prop_name, value)
            except Exception:
                pass
    finally:
        _OPTIMIZATION_PRESET_GUARD = False
    if persist:
        _optimization_store_custom_snapshot(self, context, persist=True)
    return True


def restore_optimization_custom_profile(prefs=None, context=None) -> bool:
    if prefs is None:
        try:
            prefs = registry.resolve_addon_preferences(context or getattr(bpy, 'context', None))
        except Exception:
            prefs = None
    return _restore_optimization_custom_values(prefs, context, persist=False)


def _update_optimization_profile(self, context):
    global _OPTIMIZATION_PRESET_GUARD, _OPTIMIZATION_AUTO_CUSTOM_GUARD
    if _OPTIMIZATION_PRESET_GUARD:
        _update_prefs(self, context)
        return
    try:
        profile = str(getattr(self, 'optimization_profile', 'HIGHEST_QUALITY') or 'HIGHEST_QUALITY')
    except Exception:
        profile = 'HIGHEST_QUALITY'
    try:
        if settings.is_applying():
            _optimization_set_previous_profile(self, profile)
            _update_prefs(self, context)
            return
    except Exception:
        pass
    previous_profile = _optimization_get_previous_profile(self)
    if profile == 'CUSTOM':
        if _OPTIMIZATION_AUTO_CUSTOM_GUARD:
            _optimization_set_previous_profile(self, 'CUSTOM')
            _optimization_store_custom_snapshot(self, context, persist=True)
        else:
            _restore_optimization_custom_values(self, context, persist=True)
            _optimization_set_previous_profile(self, 'CUSTOM')
        _update_prefs(self, context)
        return
    if profile in _OPTIMIZATION_PRESET_VALUES:
        # Leaving Custom must never lose the user's Custom snapshot.  Persist it
        # immediately to Smart_Overlay_Suite.json before built-in preset values
        # overwrite the live RNA properties.
        if previous_profile == 'CUSTOM' or (not previous_profile and not _optimization_values_match_any_builtin(self)):
            _optimization_store_custom_snapshot(self, context, persist=True)
        _OPTIMIZATION_PRESET_GUARD = True
        try:
            _apply_optimization_preset_values(self, profile, context)
        finally:
            _OPTIMIZATION_PRESET_GUARD = False
        try:
            if bool(getattr(self, 'active_view_draw_only', False)):
                mesh.prime_active_view_draw_context(context, force=True, source='optimization_preset')
        except Exception:
            pass
        _optimization_set_previous_profile(self, profile)
        try:
            settings.save_now(context, force=True)
        except Exception:
            try:
                settings.queue_save(context)
            except Exception:
                pass
    _update_prefs(self, context)


def _update_optimization_property(self, context):
    global _OPTIMIZATION_AUTO_CUSTOM_GUARD
    if _OPTIMIZATION_PRESET_GUARD:
        _update_prefs(self, context)
        return
    try:
        if settings.is_applying():
            _update_prefs(self, context)
            return
    except Exception:
        pass
    try:
        profile = str(getattr(self, 'optimization_profile', 'HIGHEST_QUALITY') or 'HIGHEST_QUALITY')
    except Exception:
        profile = 'HIGHEST_QUALITY'
    if profile != 'CUSTOM':
        try:
            if hasattr(self, 'optimization_profile'):
                _OPTIMIZATION_AUTO_CUSTOM_GUARD = True
                try:
                    self.optimization_profile = 'CUSTOM'
                finally:
                    _OPTIMIZATION_AUTO_CUSTOM_GUARD = False
        except Exception:
            _OPTIMIZATION_AUTO_CUSTOM_GUARD = False
            pass
    # Always persist the Custom profile immediately after an optimization item
    # changes.  This bypasses the general N-panel live-save toggle on purpose:
    # Custom is a user-defined preset and must survive built-in preset switches
    # and Blender restarts without waiting for the debounced whole-settings save.
    _optimization_set_previous_profile(self, 'CUSTOM')
    _optimization_store_custom_snapshot(self, context, persist=True)
    try:
        # When Draw Active View Only is enabled from the sidebar, the context
        # region is usually the N-panel UI region rather than the 3D WINDOW.
        # Prime the corresponding View3D WINDOW immediately so the operated view
        # does not disappear until the next mouse move.
        if bool(getattr(self, 'active_view_draw_only', False)):
            mesh.prime_active_view_draw_context(context, force=True, source='optimization_update')
    except Exception:
        pass
    _update_prefs(self, context)

def _update_prop_heatmap_colors(self, context):
    global _PROP_HEATMAP_SYNC_GUARD
    if _PROP_HEATMAP_SYNC_GUARD:
        return
    sync_prop_heatmap_preview_node_from_source(self)
    _update_prefs(self, context)


def _preset_items(self, context=None):
    try:
        return presets.get_preset_items(self)
    except Exception:
        return [('CUSTOM', 'Custom', '')]


_PRESET_STORAGE_PROP = 'active_preset_id'
_LEGACY_PRESET_STORAGE_KEYS = ('preset_id', 'preset_choice')


def _prefs_idprop_get(source, key: str, default=''):
    getter = getattr(source, 'get', None)
    if not callable(getter):
        return default
    try:
        return getter(key, default)
    except TypeError:
        try:
            value = getter(key)
        except Exception:
            return default
        return default if value is None else value
    except Exception:
        return default


def _drop_legacy_preset_storage(source) -> None:
    for key in _LEGACY_PRESET_STORAGE_KEYS:
        try:
            if hasattr(source, 'keys') and key in source.keys():
                del source[key]
                continue
        except Exception:
            pass
        try:
            source.property_unset(key)
        except Exception:
            pass


def get_current_preset_id(prefs) -> str:
    if prefs is None:
        return presets.default_preset_id()

    candidates = []
    try:
        candidates.append(str(getattr(prefs, _PRESET_STORAGE_PROP, '') or '').strip())
    except Exception:
        pass

    for key in _LEGACY_PRESET_STORAGE_KEYS:
        try:
            legacy_value = str(_prefs_idprop_get(prefs, key, '') or '').strip()
        except Exception:
            legacy_value = ''
        if legacy_value:
            candidates.append(legacy_value)

    raw_value = next((value for value in candidates if value), '')
    resolved = presets.normalize_preset_id(prefs, raw_value)

    try:
        current = str(getattr(prefs, _PRESET_STORAGE_PROP, '') or '').strip()
    except Exception:
        current = ''
    if current != resolved:
        try:
            setattr(prefs, _PRESET_STORAGE_PROP, resolved)
        except Exception:
            pass

    _drop_legacy_preset_storage(prefs)
    return resolved


def peek_current_preset_id(prefs) -> str:
    """Return the current preset id without writing to AddonPreferences.

    UI draw functions use this read-only variant so Blender 5.1 never receives
    RNA writes while rebuilding the sidebar panel tree.
    """
    if prefs is None:
        return presets.default_preset_id()
    candidates = []
    try:
        candidates.append(str(getattr(prefs, _PRESET_STORAGE_PROP, '') or '').strip())
    except Exception:
        pass
    for key in _LEGACY_PRESET_STORAGE_KEYS:
        try:
            legacy_value = str(_prefs_idprop_get(prefs, key, '') or '').strip()
        except Exception:
            legacy_value = ''
        if legacy_value:
            candidates.append(legacy_value)
    raw_value = next((value for value in candidates if value), '')
    try:
        return presets.normalize_preset_id(prefs, raw_value)
    except Exception:
        return raw_value or presets.default_preset_id()


def peek_current_preset_label(prefs) -> str:
    return presets.get_preset_label(prefs, peek_current_preset_id(prefs))


def set_current_preset_id(prefs, preset_id: str, context=None, *, redraw: bool = True) -> str:
    if prefs is None:
        return presets.default_preset_id()
    resolved = presets.normalize_preset_id(prefs, preset_id)
    changed = False
    try:
        current = str(getattr(prefs, _PRESET_STORAGE_PROP, '') or '').strip()
    except Exception:
        current = ''
    if current != resolved:
        try:
            setattr(prefs, _PRESET_STORAGE_PROP, resolved)
            changed = True
        except Exception:
            pass
    _drop_legacy_preset_storage(prefs)
    if changed and redraw and context is not None:
        _update_prefs(prefs, context)
    return resolved


def get_current_preset_label(prefs) -> str:
    return presets.get_preset_label(prefs, get_current_preset_id(prefs))


def draw_preset_selector(layout, context, prefs, *, text=None):
    if prefs is None:
        return None
    label_text = str(text) if text is not None else TI('Preset')
    current_label = str(peek_current_preset_label(prefs) or presets.default_preset_id())
    row = layout.row(align=True)
    try:
        row.use_property_split = False
        row.use_property_decorate = False
    except Exception:
        pass
    split = row.split(factor=0.44, align=True)
    split.label(text=label_text)
    split.menu('SOS_MT_preset_menu', text=current_label, translate=presets.preset_label_translatable(peek_current_preset_id(prefs)), **_icon_kwargs('presets', 'PRESET'))
    return row

# =============================================================================
# Proportional heatmap preview ramp (fixed 5 stops, two-way sync)
# =============================================================================
_PROP_HEATMAP_PREVIEW_NG_NAME = "SOS_Proportional_Heatmap_Preview_NG"
_PROP_HEATMAP_PREVIEW_NODE_NAME = "SOS_Proportional_Heatmap_ColorRamp"
_PROP_HEATMAP_PREVIEW_POSITIONS = (0.0, 0.25, 0.5, 0.75, 1.0)
_PROP_HEATMAP_PREVIEW_PROP_NAMES = (
    'prop_grad_color_0',
    'prop_grad_color_25',
    'prop_grad_color_50',
    'prop_grad_color_75',
    'prop_grad_color_100',
)
_PROP_HEATMAP_PREVIEW_DEFAULTS = (
    (0.0, 0.0, 1.0),
    (0.0, 1.0, 1.0),
    (0.0, 1.0, 0.0),
    (1.0, 1.0, 0.0),
    (1.0, 0.0, 0.0),
)
_PROP_HEATMAP_FROZEN_GRAYSCALE = (
    (0.0, 0.0, 0.0),
    (0.5, 0.5, 0.5),
    (0.75, 0.75, 0.75),
    (1.0, 1.0, 1.0),
    (1.0, 1.0, 1.0),
)
# ColorRamp.evaluate() on a virgin black->white two-stop ramp yields this
# second machine-generated grayscale.  Both fingerprints are produced only by
# ramp-stop machinery (never by a user typing five colors), so exact-tuple
# repair keeps intentional artistic grayscale palettes untouched.
_PROP_HEATMAP_EVALUATED_GRAYSCALE = (
    (0.0, 0.0, 0.0),
    (0.25, 0.25, 0.25),
    (0.5, 0.5, 0.5),
    (0.75, 0.75, 0.75),
    (1.0, 1.0, 1.0),
)
# Tag written on the preview node when THIS session seeded its ramp colors.
# A ramp datablock without the current session's tag (loaded from a .blend,
# revived by undo, or half-built by an earlier failure) must never win a
# ramp->preferences sync against the user's persisted palette.
_PROP_HEATMAP_SEED_TAG = 'sos_seeded_session'
_PROP_HEATMAP_SESSION_TOKEN = '%s' % (time.time_ns() if hasattr(time, 'time_ns') else time.time(),)
_PROP_HEATMAP_SYNC_GUARD = False
_PROP_HEATMAP_PREVIEW_KEEPALIVE_UNTIL = 0.0
_PROP_HEATMAP_LAST_SOURCE_SIG = None
_PROP_HEATMAP_LAST_RAMP_SIG = None
_PROP_HEATMAP_PREVIEW_RUNTIME_ENABLED = False


def _SICON(name: str = '', fallback: str = 'NONE') -> int:
    try:
        return int(sos_icons.icon_value(name, fallback) or 0)
    except Exception:
        return 0


def _icon_kwargs(name: str = '', fallback: str = 'NONE') -> dict:
    try:
        return sos_icons.icon_kwargs(name, fallback)
    except Exception:
        return {'icon': str(fallback or 'NONE')}


def _label_icon(layout, text: str = '', custom: str = '', fallback: str = 'NONE'):
    return layout.label(text=text, **_icon_kwargs(custom or fallback, fallback))


def _prop_heatmap_clamp01(value):
    try:
        return max(0.0, min(1.0, float(value)))
    except Exception:
        return 0.0


def _prop_heatmap_normalize_color(value, default):
    try:
        seq = tuple(float(v) for v in value)
    except Exception:
        seq = tuple(float(v) for v in default)
    if len(seq) < 3:
        seq = tuple(float(v) for v in default)
    alpha = seq[3] if len(seq) > 3 else 1.0
    return (
        _prop_heatmap_clamp01(seq[0]),
        _prop_heatmap_clamp01(seq[1]),
        _prop_heatmap_clamp01(seq[2]),
        _prop_heatmap_clamp01(alpha),
    )


def _prop_heatmap_machine_grayscale_fingerprints():
    """Exact machine-generated grayscale tuples shared with properties.py."""
    fingerprints = [_PROP_HEATMAP_FROZEN_GRAYSCALE, _PROP_HEATMAP_EVALUATED_GRAYSCALE]
    try:
        from . import properties as _sos_properties
        shared = getattr(_sos_properties, '_PROP_HEATMAP_MACHINE_GRAYSCALE_FINGERPRINTS', ())
        for item in tuple(shared or ()):
            if item not in fingerprints:
                fingerprints.append(item)
    except Exception:
        pass
    return tuple(fingerprints)


def _prop_heatmap_frozen_grayscale_replacement(colors):
    """Return the original five-color palette only for the known bad tuples.

    Two machine fingerprints exist: the stop-creation grayscale
    (_PROP_HEATMAP_FROZEN_GRAYSCALE) and the evaluate() grayscale of a virgin
    two-stop ramp (_PROP_HEATMAP_EVALUATED_GRAYSCALE).  Everything else,
    including intentional user grayscale palettes, is preserved.
    """
    try:
        actual = tuple(
            tuple(round(float(v), 6) for v in color[:3]) for color in colors
        )
    except Exception:
        return None
    if actual not in _prop_heatmap_machine_grayscale_fingerprints():
        return None
    return _PROP_HEATMAP_PREVIEW_DEFAULTS


def _prop_heatmap_palette_channel_spread(color):
    try:
        rgb = tuple(float(channel) for channel in color[:3])
        return max(rgb) - min(rgb)
    except Exception:
        return 0.0


def _prop_heatmap_palette_is_chromatic(colors, threshold: float = 0.05) -> bool:
    try:
        return any(_prop_heatmap_palette_channel_spread(c) >= float(threshold) for c in colors)
    except Exception:
        return False


def _prop_heatmap_palette_is_achromatic(colors, epsilon: float = 1e-4) -> bool:
    try:
        seq = tuple(colors)
        if not seq:
            return False
        return all(_prop_heatmap_palette_channel_spread(c) < float(epsilon) for c in seq)
    except Exception:
        return False


def _prop_heatmap_mark_node_seeded(node) -> None:
    try:
        if node is not None:
            node[_PROP_HEATMAP_SEED_TAG] = _PROP_HEATMAP_SESSION_TOKEN
    except Exception:
        pass


def _prop_heatmap_node_seeded_this_session(node) -> bool:
    try:
        if node is None:
            return False
        return str(node.get(_PROP_HEATMAP_SEED_TAG, '')) == _PROP_HEATMAP_SESSION_TOKEN
    except Exception:
        return False


def _prop_heatmap_preview_colors(source):
    source = source if source is not None else None
    colors = []
    for name, default in zip(_PROP_HEATMAP_PREVIEW_PROP_NAMES, _PROP_HEATMAP_PREVIEW_DEFAULTS):
        try:
            value = getattr(source, name, default) if source is not None else default
        except Exception:
            value = default
        colors.append(_prop_heatmap_normalize_color(value, default))
    return tuple(colors)


def _prop_heatmap_colors_signature(colors):
    signature = []
    for color in colors:
        normalized = _prop_heatmap_normalize_color(color, (0.0, 0.0, 0.0))
        signature.extend(round(float(channel), 6) for channel in normalized[:3])
    return tuple(signature)


def _prop_heatmap_ramp_matches_expected(ramp):
    if ramp is None:
        return False
    try:
        return len(list(ramp.elements)) >= 2
    except Exception:
        return False



def _prop_heatmap_primary_elements(ramp, *, create_missing: bool = False, seed_colors=None):
    """Return five stable ColorRamp elements for 0/25/50/75/100%.

    Extra user-created ramp stops are deliberately left untouched. Removing
    ColorRamp elements while Blender is drawing the same template_color_ramp()
    UI can invalidate RNA pointers on Blender 5.x, so this function only adds
    missing stops and reuses existing ones.

    Every stop this function CREATES is immediately given a palette color.
    ColorRamp.elements.new() seeds new elements with the ramp's currently
    evaluated color, which on a virgin black->white ramp manufactures the
    frozen grayscale palette; stops must never be created without colors.
    """
    if ramp is None:
        return []
    try:
        elements = sorted(list(ramp.elements), key=lambda element: float(getattr(element, 'position', 0.0)))
    except Exception:
        elements = []

    if create_missing:
        try:
            palette = tuple(seed_colors) if seed_colors else _PROP_HEATMAP_PREVIEW_DEFAULTS
        except Exception:
            palette = _PROP_HEATMAP_PREVIEW_DEFAULTS
        safety = 0
        while len(elements) < len(_PROP_HEATMAP_PREVIEW_POSITIONS) and safety < 8:
            slot = min(len(elements), len(_PROP_HEATMAP_PREVIEW_POSITIONS) - 1)
            position = _PROP_HEATMAP_PREVIEW_POSITIONS[slot]
            try:
                created = ramp.elements.new(float(position))
            except Exception:
                break
            try:
                created.color = _prop_heatmap_normalize_color(
                    palette[slot] if slot < len(palette) else _PROP_HEATMAP_PREVIEW_DEFAULTS[slot],
                    _PROP_HEATMAP_PREVIEW_DEFAULTS[slot],
                )
            except Exception:
                pass
            try:
                elements = sorted(list(ramp.elements), key=lambda element: float(getattr(element, 'position', 0.0)))
            except Exception:
                elements = []
            safety += 1

    if not elements:
        return []

    remaining = list(elements)
    selected = []
    for position in _PROP_HEATMAP_PREVIEW_POSITIONS:
        match = None
        for element in remaining:
            try:
                if abs(float(getattr(element, 'position', 0.0)) - float(position)) <= 1e-5:
                    match = element
                    break
            except Exception:
                continue
        if match is None:
            try:
                match = min(remaining, key=lambda element: abs(float(getattr(element, 'position', 0.0)) - float(position)))
            except Exception:
                match = None
        if match is None:
            break
        selected.append(match)
        try:
            remaining.remove(match)
        except Exception:
            pass
        if not remaining and len(selected) < len(_PROP_HEATMAP_PREVIEW_POSITIONS):
            break
    return selected



def _prop_heatmap_ramp_colors(ramp):
    if ramp is None:
        return tuple(
            _prop_heatmap_normalize_color(default, default)
            for default in _PROP_HEATMAP_PREVIEW_DEFAULTS
        )

    evaluate = getattr(ramp, 'evaluate', None)
    primary = _prop_heatmap_primary_elements(ramp, create_missing=False)
    colors = []
    for index, (position, default) in enumerate(zip(_PROP_HEATMAP_PREVIEW_POSITIONS, _PROP_HEATMAP_PREVIEW_DEFAULTS)):
        color = None
        if callable(evaluate):
            try:
                color = tuple(evaluate(float(position)))
            except Exception:
                color = None
        if color is None and index < len(primary):
            try:
                color = tuple(primary[index].color)
            except Exception:
                color = None
        colors.append(_prop_heatmap_normalize_color(color, default))
    return tuple(colors)


def _prop_heatmap_preview_default_colors():
    return tuple(
        _prop_heatmap_normalize_color(default, default)
        for default in _PROP_HEATMAP_PREVIEW_DEFAULTS
    )



def _prop_heatmap_preview_node_tree(create=False):
    """Return the hidden node tree used only as ColorRamp UI storage.

    The tree is kept stable for the add-on session. Older builds rebuilt it by
    clearing nodes while the N-panel could still hold UI buttons pointing at the
    previous RNA objects; this can crash Blender in panel_draw. This function
    only creates the tree when missing and never clears it during UI drawing.
    """
    try:
        ng = bpy.data.node_groups.get(_PROP_HEATMAP_PREVIEW_NG_NAME)
    except Exception:
        ng = None
    if ng is None and create:
        try:
            ng = bpy.data.node_groups.new(_PROP_HEATMAP_PREVIEW_NG_NAME, 'ShaderNodeTree')
        except Exception:
            return None
    if ng is not None:
        try:
            ng.use_fake_user = False
        except Exception:
            pass
    return ng



def _prop_heatmap_node_is_usable(node) -> bool:
    if node is None:
        return False
    try:
        if str(getattr(node, 'bl_idname', '') or '') != 'ShaderNodeValToRGB':
            return False
        return getattr(node, 'color_ramp', None) is not None
    except Exception:
        return False



def _prop_heatmap_find_preview_node(ng):
    if ng is None:
        return None
    try:
        node = ng.nodes.get(_PROP_HEATMAP_PREVIEW_NODE_NAME)
    except Exception:
        node = None
    if _prop_heatmap_node_is_usable(node):
        return node
    try:
        nodes = tuple(ng.nodes)
    except Exception:
        nodes = ()
    for item in nodes:
        try:
            if not _prop_heatmap_node_is_usable(item):
                continue
            name = str(getattr(item, 'name', '') or '')
            label = str(getattr(item, 'label', '') or '')
            if name.startswith(_PROP_HEATMAP_PREVIEW_NODE_NAME) or label == _PROP_HEATMAP_PREVIEW_NODE_NAME:
                return item
        except Exception:
            continue
    for item in nodes:
        if _prop_heatmap_node_is_usable(item):
            return item
    return None



def _prop_heatmap_apply_fixed_positions(ramp, seed_colors=None) -> None:
    elements = _prop_heatmap_primary_elements(ramp, create_missing=True, seed_colors=seed_colors)
    if len(elements) < len(_PROP_HEATMAP_PREVIEW_POSITIONS):
        return
    for element, position in zip(elements[:len(_PROP_HEATMAP_PREVIEW_POSITIONS)], _PROP_HEATMAP_PREVIEW_POSITIONS):
        try:
            element.position = float(position)
        except Exception:
            pass



def _prop_heatmap_build_preview_node(ng, colors=None):
    """Create or repair the preview node without deleting live UI RNA data."""
    if ng is None:
        return None
    color_values = tuple(colors) if colors is not None else _prop_heatmap_preview_default_colors()
    node = _prop_heatmap_find_preview_node(ng)
    if node is None:
        try:
            legacy = ng.nodes.get(_PROP_HEATMAP_PREVIEW_NODE_NAME)
            if legacy is not None and not _prop_heatmap_node_is_usable(legacy):
                legacy.name = _PROP_HEATMAP_PREVIEW_NODE_NAME + "_Legacy"
        except Exception:
            pass
        try:
            node = ng.nodes.new(type='ShaderNodeValToRGB')
        except TypeError:
            try:
                node = ng.nodes.new('ShaderNodeValToRGB')
            except Exception:
                return None
        except Exception:
            return None
        try:
            node.name = _PROP_HEATMAP_PREVIEW_NODE_NAME
        except Exception:
            pass
        try:
            node.label = _PROP_HEATMAP_PREVIEW_NODE_NAME
        except Exception:
            pass
    ramp = getattr(node, 'color_ramp', None)
    if ramp is None:
        return None
    try:
        ramp.interpolation = 'LINEAR'
    except Exception:
        pass
    _prop_heatmap_apply_fixed_positions(ramp, seed_colors=color_values)
    elements = _prop_heatmap_primary_elements(ramp, create_missing=True, seed_colors=color_values)
    if len(elements) < len(_PROP_HEATMAP_PREVIEW_POSITIONS):
        return None
    for index, (element, position) in enumerate(zip(elements[:len(_PROP_HEATMAP_PREVIEW_POSITIONS)], _PROP_HEATMAP_PREVIEW_POSITIONS)):
        try:
            element.position = float(position)
        except Exception:
            pass
        try:
            element.color = _prop_heatmap_normalize_color(color_values[index], _PROP_HEATMAP_PREVIEW_DEFAULTS[index])
        except Exception:
            pass
    _prop_heatmap_mark_node_seeded(node)
    return node



def _ensure_prop_heatmap_preview_node(source=None):
    ng = _prop_heatmap_preview_node_tree(create=True)
    if ng is None:
        return None
    node = _prop_heatmap_find_preview_node(ng)
    if node is None:
        colors = _prop_heatmap_preview_colors(source) if source is not None else None
        return _prop_heatmap_build_preview_node(ng, colors)
    ramp = getattr(node, 'color_ramp', None)
    if ramp is None:
        return None
    try:
        element_count = len(list(ramp.elements))
    except Exception:
        element_count = 0
    if element_count < len(_PROP_HEATMAP_PREVIEW_POSITIONS) or not _prop_heatmap_node_seeded_this_session(node):
        # A partial or stale ramp (loaded .blend, undo-revived datablock, or a
        # previously failed construction) must be re-seeded from the source
        # palette; fixing positions alone would create stops that inherit the
        # ramp's evaluated grayscale and later poison the preferences.
        return _prop_heatmap_build_preview_node(ng, _prop_heatmap_preview_colors(source))
    try:
        ramp.interpolation = 'LINEAR'
    except Exception:
        pass
    _prop_heatmap_apply_fixed_positions(ramp, seed_colors=_prop_heatmap_preview_colors(source))
    return node



def _prop_heatmap_preview_node():
    ng = _prop_heatmap_preview_node_tree(create=False)
    if ng is None:
        return None
    node = _prop_heatmap_find_preview_node(ng)
    if not _prop_heatmap_node_is_usable(node):
        return None
    return node



def _apply_prop_heatmap_preview_colors(node, colors):
    if node is None:
        return None
    ramp = getattr(node, 'color_ramp', None)
    if ramp is None:
        return None
    try:
        ramp.interpolation = 'LINEAR'
    except Exception:
        pass
    elements = _prop_heatmap_primary_elements(ramp, create_missing=True, seed_colors=colors)
    if len(elements) < len(_PROP_HEATMAP_PREVIEW_POSITIONS):
        return node
    for index, (element, position) in enumerate(zip(elements[:len(_PROP_HEATMAP_PREVIEW_POSITIONS)], _PROP_HEATMAP_PREVIEW_POSITIONS)):
        try:
            element.position = float(position)
        except Exception:
            pass
        try:
            element.color = _prop_heatmap_normalize_color(colors[index], _PROP_HEATMAP_PREVIEW_DEFAULTS[index])
        except Exception:
            pass
    _prop_heatmap_mark_node_seeded(node)
    return node


def _remember_prop_heatmap_signatures(signature):
    global _PROP_HEATMAP_LAST_SOURCE_SIG, _PROP_HEATMAP_LAST_RAMP_SIG
    _PROP_HEATMAP_LAST_SOURCE_SIG = signature
    _PROP_HEATMAP_LAST_RAMP_SIG = signature



def _apply_prop_heatmap_preview_colors_to_source(source, colors, context=None):
    global _PROP_HEATMAP_SYNC_GUARD
    if source is None:
        return False
    changed = False
    _PROP_HEATMAP_SYNC_GUARD = True
    try:
        for name, color in zip(_PROP_HEATMAP_PREVIEW_PROP_NAMES, colors):
            target = tuple(float(channel) for channel in color[:3])
            try:
                current = tuple(round(float(v), 6) for v in getattr(source, name, target))
            except Exception:
                current = ()
            if current != tuple(round(float(v), 6) for v in target):
                setattr(source, name, target)
                changed = True
    finally:
        _PROP_HEATMAP_SYNC_GUARD = False

    if changed:
        _update_prefs(source, context if context is not None else getattr(bpy, 'context', None))
    return changed


def repair_frozen_grayscale_prop_heatmap_palette(source=None, context=None):
    """Restore only the known frozen grayscale palette; preserve custom colors."""
    if source is None:
        try:
            source = registry.resolve_addon_preferences(
                context or getattr(bpy, 'context', None))
        except Exception:
            source = None
    if source is None:
        return False
    replacement = _prop_heatmap_frozen_grayscale_replacement(
        _prop_heatmap_preview_colors(source))
    if replacement is None:
        return False
    changed = bool(_apply_prop_heatmap_preview_colors_to_source(
        source, replacement,
        context if context is not None else getattr(bpy, 'context', None),
    ))
    if changed:
        try:
            sync_prop_heatmap_preview_node_from_source(source)
        except Exception:
            pass
    return changed


def migrate_prop_heatmap_original_palette_v2(source=None, context=None):
    """Repair the known persisted grayscale regression once, then seal it."""
    if source is None:
        try:
            source = registry.resolve_addon_preferences(
                context or getattr(bpy, 'context', None))
        except Exception:
            source = None
    if source is None:
        return False
    if bool(getattr(source, 'prop_heatmap_original_palette_v2_migrated', False)):
        # The old marker could be written before a later settings replay restored
        # the known frozen grayscale tuple.  Recheck that exact tuple every load.
        return repair_frozen_grayscale_prop_heatmap_palette(source, context)
    ctx = context if context is not None else getattr(bpy, 'context', None)
    try:
        replacement = _prop_heatmap_frozen_grayscale_replacement(
            _prop_heatmap_preview_colors(source))
        if replacement is not None:
            _apply_prop_heatmap_preview_colors_to_source(source, replacement, ctx)
        source.prop_heatmap_original_palette_v2_migrated = True
        sync_prop_heatmap_preview_node_from_source(source)
        settings.queue_save(ctx)
        return True
    except Exception:
        return False



def sync_prop_heatmap_preview_node_from_source(source=None):
    try:
        node = _ensure_prop_heatmap_preview_node(source)
        colors = _prop_heatmap_preview_colors(source)
        node = _apply_prop_heatmap_preview_colors(node, colors)
        _remember_prop_heatmap_signatures(_prop_heatmap_colors_signature(colors))
        return node
    except Exception:
        return None



def sync_prop_heatmap_preview_node(source=None):
    global _PROP_HEATMAP_LAST_SOURCE_SIG, _PROP_HEATMAP_LAST_RAMP_SIG

    if _PROP_HEATMAP_SYNC_GUARD:
        return _prop_heatmap_preview_node()

    try:
        node = _ensure_prop_heatmap_preview_node(source)
        ramp = getattr(node, 'color_ramp', None)
        if ramp is None:
            return sync_prop_heatmap_preview_node_from_source(source)

        source_colors = _prop_heatmap_preview_colors(source)
        source_sig = _prop_heatmap_colors_signature(source_colors)
        ramp_colors = _prop_heatmap_ramp_colors(ramp)
        ramp_sig = _prop_heatmap_colors_signature(ramp_colors)

        if _PROP_HEATMAP_LAST_SOURCE_SIG is None or _PROP_HEATMAP_LAST_RAMP_SIG is None:
            return sync_prop_heatmap_preview_node_from_source(source)

        if ramp_sig != _PROP_HEATMAP_LAST_RAMP_SIG and source_sig == _PROP_HEATMAP_LAST_SOURCE_SIG:
            if not _prop_heatmap_node_seeded_this_session(node):
                # The ramp datablock is not the one this session seeded (stale
                # .blend node group, undo-revived datablock, or a half-built
                # node).  Stale ramps must never overwrite the user's palette.
                return sync_prop_heatmap_preview_node_from_source(source)
            if (
                _prop_heatmap_palette_is_achromatic(ramp_colors)
                and _prop_heatmap_palette_is_chromatic(source_colors)
            ):
                # Defense in depth: an all-achromatic ramp appearing over a
                # chromatic source palette is machine-generated (virgin ramp
                # evaluate/stop inheritance), not a user edit.  Re-seed it.
                return sync_prop_heatmap_preview_node_from_source(source)
            _apply_prop_heatmap_preview_colors_to_source(source, ramp_colors, getattr(bpy, 'context', None))
            node = _apply_prop_heatmap_preview_colors(node, ramp_colors)
            _remember_prop_heatmap_signatures(ramp_sig)
            return node

        if source_sig != _PROP_HEATMAP_LAST_SOURCE_SIG:
            return sync_prop_heatmap_preview_node_from_source(source)

        if not _prop_heatmap_ramp_matches_expected(ramp):
            node = _apply_prop_heatmap_preview_colors(node, ramp_colors)
            _remember_prop_heatmap_signatures(ramp_sig)
        return node
    except Exception:
        return sync_prop_heatmap_preview_node_from_source(source)



def draw_prop_heatmap_preview_ramp(layout, source=None):
    if layout is None:
        return False
    source = source if source is not None else _resolve_prop_heatmap_preview_source(getattr(bpy, 'context', None))
    preview_node = sync_prop_heatmap_preview_node(source)
    if preview_node is None:
        preview_node = _ensure_prop_heatmap_preview_node(source)
    if preview_node is None:
        preview_node = _ensure_prop_heatmap_preview_node(None)
    if preview_node is None:
        return False
    try:
        layout.template_color_ramp(preview_node, "color_ramp", expand=True)
    except Exception:
        return False
    try:
        _keep_prop_heatmap_preview_sync_alive(getattr(bpy, 'context', None))
    except Exception:
        pass
    return True



def _resolve_prop_heatmap_preview_source(context=None):
    ctx = context if context is not None else getattr(bpy, 'context', None)
    try:
        return registry.resolve_addon_preferences(ctx)
    except Exception:
        return None



def _prop_heatmap_preview_sync_timer():
    if not _PROP_HEATMAP_PREVIEW_RUNTIME_ENABLED:
        return None
    try:
        sync_prop_heatmap_preview_node(_resolve_prop_heatmap_preview_source())
    except Exception:
        pass
    try:
        if time.monotonic() < float(_PROP_HEATMAP_PREVIEW_KEEPALIVE_UNTIL or 0.0):
            return 0.35
    except Exception:
        pass
    return None


def _keep_prop_heatmap_preview_sync_alive(context=None) -> None:
    del context
    global _PROP_HEATMAP_PREVIEW_KEEPALIVE_UNTIL
    _PROP_HEATMAP_PREVIEW_KEEPALIVE_UNTIL = time.monotonic() + 2.0
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    if timers is None:
        return
    try:
        if not timers.is_registered(_prop_heatmap_preview_sync_timer):
            timers.register(_prop_heatmap_preview_sync_timer, first_interval=0.35)
    except TypeError:
        try:
            if not timers.is_registered(_prop_heatmap_preview_sync_timer):
                timers.register(_prop_heatmap_preview_sync_timer)
        except Exception:
            pass
    except Exception:
        pass



def register_prop_heatmap_preview_addon_runtime(context=None, source=None):
    global _PROP_HEATMAP_PREVIEW_RUNTIME_ENABLED
    _PROP_HEATMAP_PREVIEW_RUNTIME_ENABLED = True
    try:
        sync_prop_heatmap_preview_node_from_source(source if source is not None else _resolve_prop_heatmap_preview_source(context))
    except Exception:
        pass



def unregister_prop_heatmap_preview_addon_runtime():
    global _PROP_HEATMAP_PREVIEW_RUNTIME_ENABLED
    _PROP_HEATMAP_PREVIEW_RUNTIME_ENABLED = False
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    if timers is not None:
        try:
            if timers.is_registered(_prop_heatmap_preview_sync_timer):
                timers.unregister(_prop_heatmap_preview_sync_timer)
        except Exception:
            pass
    clear_prop_heatmap_preview_node()



def clear_prop_heatmap_preview_node():
    """Reset preview sync state without deleting the live ColorRamp data-block.

    template_color_ramp() creates UI controls that may still reference the
    ColorRamp RNA object until the current panel layout is discarded. Deleting
    the backing node group during unregister or script reload can therefore
    crash Blender in panel_draw on some 5.x builds. The node group has no fake
    user and is simply reused or left for Blender's normal orphan handling.
    """
    global _PROP_HEATMAP_LAST_SOURCE_SIG, _PROP_HEATMAP_LAST_RAMP_SIG

    _PROP_HEATMAP_LAST_SOURCE_SIG = None
    _PROP_HEATMAP_LAST_RAMP_SIG = None


# =============================================================================
# Depth offset UI/display scaling
#   - internal: *_depth_offset (float, effective view-space depth strength used by mesh.py)
#   - UI:       *_depth_offset_ui (display value) = internal * 1,000,000
#   - rule:     UI 1.00 = internal/effective 0.000001.
#               The former UI 1.00/internal 0.001 is now displayed as 1000.00.
# =============================================================================
_DEPTH_UI_SYNC = False
_DEPTH_OFFSET_UI_SCALE = 1000000.0
_DEPTH_OFFSET_INTERNAL_UNIT = 1.0 / _DEPTH_OFFSET_UI_SCALE
_DEPTH_OFFSET_FLOAT_MAX = 0.25
_DEPTH_OFFSET_UI_MAX = 250000.0
_DEPTH_OFFSET_UI_PRECISION = 2
_DEPTH_OFFSET_DEFAULTS_V2 = {
    'vertex': (0.003, 3000.00),
    'edge': (0.002, 2000.00),
    'face': (0.001, 1000.00),
}
_DEPTH_OFFSET_OLD_DEFAULT_TRIPLETS = (
    (3.0, 2.0, 1.0),
    (3.0, 2.0, 3.0),
    (0.3, 0.2, 0.1),
    (0.3, 0.2, 0.3),
    (0.003, 0.002, 0.003),
    (0.003, 0.002, 0.001),
    (300.0, 200.0, 100.0),
    (300.0, 200.0, 300.0),
)
_DEPTH_OFFSET_OLD_DEFAULT_UI_TRIPLETS = (
    (3000.0, 2000.0, 1000.0),
    (3000.0, 2000.0, 3000.0),
    (300.0, 200.0, 100.0),
    (300.0, 200.0, 300.0),
    (1000.0, 1000.0, 1000.0),
    (3.0, 2.0, 3.0),
    (3.0, 2.0, 1.0),
)


def _depth_float(value, default=0.0):
    try:
        return float(value)
    except Exception:
        return float(default)


def _depth_int(value, default=0):
    try:
        return int(round(float(value)))
    except Exception:
        return int(default)


def _depth_clamp_internal(value):
    return min(_DEPTH_OFFSET_FLOAT_MAX, max(0.0, _depth_float(value, 0.0)))


def _depth_clamp_ui(value):
    try:
        return round(min(_DEPTH_OFFSET_UI_MAX, max(0.0, _depth_float(value, 0.0))), _DEPTH_OFFSET_UI_PRECISION)
    except Exception:
        return 0.0


def _depth_internal_to_ui(value):
    return _depth_clamp_ui(_depth_clamp_internal(value) * _DEPTH_OFFSET_UI_SCALE)


def _depth_ui_to_internal(value):
    return _depth_clamp_internal(_depth_clamp_ui(value) / _DEPTH_OFFSET_UI_SCALE)


def _depth_nearly_equal(a, b, eps=1e-9):
    try:
        return abs(float(a) - float(b)) <= eps
    except Exception:
        return False


def _depth_triplet_matches(triplet, candidates, eps=1e-7):
    try:
        values = tuple(_depth_float(v, 0.0) for v in triplet)
    except Exception:
        return False
    for candidate in candidates:
        if len(values) == len(candidate) and all(_depth_nearly_equal(a, b, eps) for a, b in zip(values, candidate)):
            return True
    return False


def _depth_pairs_are_current_x1000000(prefs):
    if prefs is None:
        return False
    try:
        for internal_key, ui_key in (
            ('vertex_depth_offset', 'vertex_depth_offset_ui'),
            ('edge_depth_offset', 'edge_depth_offset_ui'),
            ('face_depth_offset', 'face_depth_offset_ui'),
        ):
            internal = _depth_float(getattr(prefs, internal_key, 0.0), 0.0)
            ui_value = _depth_float(getattr(prefs, ui_key, 0.0), 0.0)
            if internal <= 0.0 and ui_value <= 0.0:
                continue
            if not _depth_nearly_equal(internal, ui_value / _DEPTH_OFFSET_UI_SCALE, 1e-9):
                return False
        return True
    except Exception:
        return False


def _depth_looks_like_factory_default(prefs):
    try:
        triple = (
            _depth_float(getattr(prefs, 'vertex_depth_offset', 0.0)),
            _depth_float(getattr(prefs, 'edge_depth_offset', 0.0)),
            _depth_float(getattr(prefs, 'face_depth_offset', 0.0)),
        )
        ui_triple = (
            _depth_float(getattr(prefs, 'vertex_depth_offset_ui', 0.0)),
            _depth_float(getattr(prefs, 'edge_depth_offset_ui', 0.0)),
            _depth_float(getattr(prefs, 'face_depth_offset_ui', 0.0)),
        )
    except Exception:
        return False
    return _depth_triplet_matches(triple, _DEPTH_OFFSET_OLD_DEFAULT_TRIPLETS) or _depth_triplet_matches(ui_triple, _DEPTH_OFFSET_OLD_DEFAULT_UI_TRIPLETS)


def _set_depth_defaults_v2(prefs):
    prefs.vertex_depth_offset = _DEPTH_OFFSET_DEFAULTS_V2['vertex'][0]
    prefs.edge_depth_offset = _DEPTH_OFFSET_DEFAULTS_V2['edge'][0]
    prefs.face_depth_offset = _DEPTH_OFFSET_DEFAULTS_V2['face'][0]
    prefs.vertex_depth_offset_ui = _DEPTH_OFFSET_DEFAULTS_V2['vertex'][1]
    prefs.edge_depth_offset_ui = _DEPTH_OFFSET_DEFAULTS_V2['edge'][1]
    prefs.face_depth_offset_ui = _DEPTH_OFFSET_DEFAULTS_V2['face'][1]


def _mark_depth_defaults_migrated(prefs):
    for flag in (
        'depth_offset_defaults_v2_migrated',
        'depth_offset_defaults_v3_migrated',
        'depth_offset_defaults_v4_migrated',
        'depth_offset_defaults_v5_migrated',
    ):
        try:
            setattr(prefs, flag, True)
        except Exception:
            pass


def _apply_depth_offset_v2_defaults_if_needed(prefs):
    """Move known factory defaults to Vertex 3 / Edge 2 / Face 1.

    User-edited values are left alone.  Exact legacy/default triplets from the
    previous direct-unit build are rewritten so display value 1000 once again means
    the effective internal depth offset 0.001.
    """
    if prefs is None:
        return False
    if not _depth_looks_like_factory_default(prefs):
        _mark_depth_defaults_migrated(prefs)
        return False
    try:
        _set_depth_defaults_v2(prefs)
    except Exception:
        pass
    _mark_depth_defaults_migrated(prefs)
    return True


def _normalize_depth_offset_pair_to_x1000000(internal, ui_value):
    """Return (internal, ui) where UI 1.00 equals internal 0.000001.

    Current pairs such as internal 0.003 / UI 3000.00 are kept.  Direct-unit pairs
    produced by the previous build, such as internal 0.07 / UI 0.07, keep their
    drawing effect and become UI 70000.00.
    """
    internal = _depth_float(internal, 0.0)
    ui_value = _depth_float(ui_value, 0.0)

    if internal > 0.0 and ui_value > 0.0:
        if _depth_nearly_equal(internal, ui_value / _DEPTH_OFFSET_UI_SCALE, 1e-9):
            pass
        elif _depth_nearly_equal(internal, ui_value, 1e-9):
            # Previous direct-unit build. Preserve the effective depth amount.
            pass
        else:
            # Ambiguous mixed state. The internal value is the drawing source of
            # truth, so preserve the current visual effect and resync the UI.
            pass
    elif ui_value > 0.0:
        internal = ui_value / _DEPTH_OFFSET_UI_SCALE
    else:
        internal = max(0.0, internal)

    internal = _depth_clamp_internal(internal)
    ui_value = _depth_internal_to_ui(internal)
    return internal, ui_value


def _migrate_depth_offsets_to_x1000000_display(prefs):
    if prefs is None:
        return
    try:
        already_done = bool(getattr(prefs, 'depth_offset_display_x1000000_v8_migrated', False))
    except Exception:
        already_done = False
    if already_done and _depth_pairs_are_current_x1000000(prefs):
        return

    global _DEPTH_UI_SYNC
    previous_sync = _DEPTH_UI_SYNC
    _DEPTH_UI_SYNC = True
    try:
        if _apply_depth_offset_v2_defaults_if_needed(prefs):
            pass
        else:
            for internal_key, ui_key in (
                ('vertex_depth_offset', 'vertex_depth_offset_ui'),
                ('edge_depth_offset', 'edge_depth_offset_ui'),
                ('face_depth_offset', 'face_depth_offset_ui'),
            ):
                internal, ui_value = _normalize_depth_offset_pair_to_x1000000(
                    getattr(prefs, internal_key, 0.0),
                    getattr(prefs, ui_key, 0.0),
                )
                setattr(prefs, internal_key, internal)
                setattr(prefs, ui_key, ui_value)
        try:
            prefs.depth_offset_x1000_migrated = True
        except Exception:
            pass
        try:
            prefs.depth_offset_display_x1000_v7_migrated = True
        except Exception:
            pass
        try:
            prefs.depth_offset_x1000_display_v7_migrated = True
            prefs.depth_offset_display_x1000000_v8_migrated = True
        except Exception:
            pass
    finally:
        _DEPTH_UI_SYNC = previous_sync


def _sync_depth_ui_from_internal(prefs):
    """Keep UI display values in sync with internal float values (no redraw)."""
    global _DEPTH_UI_SYNC
    if _DEPTH_UI_SYNC:
        return
    _DEPTH_UI_SYNC = True
    try:
        _migrate_depth_offsets_to_x1000000_display(prefs)
        v = _depth_internal_to_ui(getattr(prefs, "vertex_depth_offset", 0.0))
        e = _depth_internal_to_ui(getattr(prefs, "edge_depth_offset", 0.0))
        f = _depth_internal_to_ui(getattr(prefs, "face_depth_offset", 0.0))
        if not _depth_nearly_equal(_depth_float(getattr(prefs, "vertex_depth_offset_ui", v), v), v, 1e-9):
            prefs.vertex_depth_offset_ui = v
        if not _depth_nearly_equal(_depth_float(getattr(prefs, "edge_depth_offset_ui", e), e), e, 1e-9):
            prefs.edge_depth_offset_ui = e
        if not _depth_nearly_equal(_depth_float(getattr(prefs, "face_depth_offset_ui", f), f), f, 1e-9):
            prefs.face_depth_offset_ui = f
    finally:
        _DEPTH_UI_SYNC = False


def _update_depth_internal_from_ui(prefs, context, which):
    global _DEPTH_UI_SYNC
    if _DEPTH_UI_SYNC:
        return
    _DEPTH_UI_SYNC = True
    try:
        try:
            prefs.depth_offset_x1000_migrated = True
            prefs.depth_offset_display_x1000_v7_migrated = True
            prefs.depth_offset_x1000_display_v7_migrated = True
            prefs.depth_offset_display_x1000000_v8_migrated = True
        except Exception:
            pass
        if which == "VERT":
            value = _depth_clamp_ui(getattr(prefs, 'vertex_depth_offset_ui', 0))
            prefs.vertex_depth_offset_ui = value
            prefs.vertex_depth_offset = value / _DEPTH_OFFSET_UI_SCALE
        elif which == "EDGE":
            value = _depth_clamp_ui(getattr(prefs, 'edge_depth_offset_ui', 0))
            prefs.edge_depth_offset_ui = value
            prefs.edge_depth_offset = value / _DEPTH_OFFSET_UI_SCALE
        elif which == "FACE":
            value = _depth_clamp_ui(getattr(prefs, 'face_depth_offset_ui', 0))
            prefs.face_depth_offset_ui = value
            prefs.face_depth_offset = value / _DEPTH_OFFSET_UI_SCALE
    finally:
        _DEPTH_UI_SYNC = False
    _update_prefs(prefs, context)


def _update_vertex_depth_ui(self, context):
    _update_depth_internal_from_ui(self, context, "VERT")


def _update_edge_depth_ui(self, context):
    _update_depth_internal_from_ui(self, context, "EDGE")


def _update_face_depth_ui(self, context):
    _update_depth_internal_from_ui(self, context, "FACE")


def _update_depth_float(self, context):
    # If the internal float is changed programmatically or from legacy prefs,
    # update the UI display values to match.
    global _DEPTH_UI_SYNC
    if _DEPTH_UI_SYNC:
        return
    _sync_depth_ui_from_internal(self)
    _update_prefs(self, context)



_INTEGRATED_TOOL_PREF_ORDER = (
    'smart_measure',
    'image_dimensions_viewer',
    'silhouette',
)


def _integrated_tool_localized(context, en: str, ja: str) -> str:
    return registry.localized(en, ja, context)


def _update_integrated_tool_enable(self, context):
    try:
        from . import loader as integrated_loader
        from . import ui_runtime as integrated_ui_runtime
        integrated_loader.refresh_enabled_states(context=context, prefs=self)
        purge = getattr(integrated_ui_runtime, 'purge_stale_dynamic_classes', None)
        if callable(purge):
            purge()
    except Exception:
        pass


def _draw_multiline_info(layout, text: str, *, width: int = 86, icon: str = 'NONE') -> None:
    cleaned = str(text or '').strip()
    if not cleaned:
        return
    lines = textwrap.wrap(cleaned, width=max(30, int(width))) or [cleaned]
    first = True
    for line in lines:
        if first:
            _label_icon(layout, text=line, custom=icon, fallback=icon)
            first = False
        else:
            layout.label(text=line)


def _draw_integrated_tool_preferences(self, context, layout) -> None:
    root = layout.box()
    head = root.row(align=True)
    _label_icon(head, text=_integrated_tool_localized(context, 'Integrated Tools', '統合ツール'), custom='integrated', fallback='PLUGIN')
    _label_icon(head, text=_integrated_tool_localized(context, 'Always Active', '常時有効'), custom='apply', fallback='CHECKMARK')
    _draw_multiline_info(
        root,
        _integrated_tool_localized(
            context,
            'Bundled tools are part of the Smart Overlay N-panel while Smart Overlay is enabled.',
            '同梱ツールはSmart Overlay が有効な間、単一のSmart Overlay Nパネル内に統合表示されます。単独の同梱ツールNパネルとツール単位の切替操作は削除されています。',
        ),
        width=88,
        icon='NONE',
    )
    for alias in _INTEGRATED_TOOL_PREF_ORDER:
        section = root.box()
        title = registry.tool_label(alias, context)
        header = section.row(align=True)
        _label_icon(header, text=title, custom=alias, fallback='PLUGIN')
        _label_icon(header, text=_integrated_tool_localized(context, 'Always Active', '常時有効'), custom='apply', fallback='CHECKMARK')
        overview = registry.tool_summary(alias, context)
        usage = registry.tool_usage(alias, context)
        if overview:
            box = section.box()
            _label_icon(box, text=_integrated_tool_localized(context, 'Overview', '概要'), custom='info', fallback='INFO')
            _draw_multiline_info(box, overview, width=84)
        if usage:
            box = section.box()
            _label_icon(box, text=_integrated_tool_localized(context, 'How to Use', '使い方'), custom='help', fallback='HELP')
            _draw_multiline_info(box, usage, width=84)

class SOS_MT_PresetMenu(bpy.types.Menu):
    bl_idname = 'SOS_MT_preset_menu'
    bl_label = 'Preset'

    def draw(self, context):
        layout = self.layout
        prefs = registry.resolve_addon_preferences(context)
        if prefs is None:
            return
        current_id = peek_current_preset_id(prefs)
        items = presets.get_preset_items(prefs)
        if not items:
            items = ((presets.default_preset_id(), 'Custom', ''),)
        for item in items:
            identifier = str(item[0] or '').strip() if item else ''
            label = str(item[1] or identifier)
            if not identifier:
                continue
            op = layout.operator(
                'view3d.sos_select_preset',
                text=label,
                translate=presets.preset_label_translatable(identifier),
                **_icon_kwargs('apply' if identifier == current_id else 'NONE', 'CHECKMARK' if identifier == current_id else 'NONE'),
            )
            op.preset_id = identifier



_UV_HOVER_OLD_YELLOW_DEFAULT = (1.0, 0.7835, 0.0137)
_UV_HOVER_RED_DEFAULT = (1.0, 0.0, 0.0)
_HPO_WORKING_GREEN_DEFAULT = (0.11310788244009018, 1.0, 0.0)


def _color_close_tuple(value, target, eps=0.004):
    try:
        vals = tuple(float(v) for v in value[:3])
        return len(vals) >= 3 and all(abs(vals[i] - float(target[i])) <= float(eps) for i in range(3))
    except Exception:
        return False


def migrate_uv_hover_red_defaults(prefs):
    """Migrate only untouched legacy UV hover default colors to red.

    Older builds used the same yellow for the hovered UV and the same-mesh helper,
    making the two overlays visually indistinguishable.  Preserve custom user
    colors, but update the legacy default yellow so the hovered UV is red and
    related same-mesh UVs remain yellow.
    """
    if prefs is None:
        return False
    try:
        if bool(getattr(prefs, 'uv_hover_red_defaults_v1_migrated', False)):
            return False
    except Exception:
        pass
    changed = False
    for attr in ('hover_uv_vertex_color', 'hover_uv_edge_color', 'hover_uv_face_color'):
        try:
            if _color_close_tuple(getattr(prefs, attr), _UV_HOVER_OLD_YELLOW_DEFAULT):
                setattr(prefs, attr, _UV_HOVER_RED_DEFAULT)
                changed = True
        except Exception:
            continue
    try:
        prefs.uv_hover_red_defaults_v1_migrated = True
    except Exception:
        pass
    return bool(changed)


def migrate_occluded_color_visible_default_v1(prefs=None, context=None):
    """Migrate only the unmarked legacy X-Ray-only visibility tuple once."""
    if prefs is None:
        try:
            prefs = registry.resolve_addon_preferences(
                context or getattr(bpy, 'context', None))
        except Exception:
            prefs = None
    if prefs is None:
        return False
    if bool(getattr(prefs, 'occluded_color_visible_default_v1_migrated', False)):
        return False
    changed = False
    try:
        if (str(getattr(prefs, 'occluded_display_mode', '') or '') == 'XRAY_ONLY'
                and bool(getattr(prefs, 'hide_occluded_colors_when_xray_off', False))):
            prefs.occluded_display_mode = 'ALWAYS'
            prefs.hide_occluded_colors_when_xray_off = False
            changed = True
        prefs.occluded_color_visible_default_v1_migrated = True
        settings.queue_save(context or getattr(bpy, 'context', None))
    except Exception:
        return False
    return changed


def migrate_occluded_color_working_defaults_v2(prefs=None, context=None):
    """Restore only the persisted kill-switch tuple reported by this install.

    The original working behavior draws V/E/F occluded colors in X-Ray and
    leaves them hidden while X-Ray is off. Other combinations remain untouched
    because they may be intentional custom policies.
    """
    if prefs is None:
        try:
            prefs = registry.resolve_addon_preferences(
                context or getattr(bpy, 'context', None))
        except Exception:
            prefs = None
    if prefs is None:
        return False
    if bool(getattr(prefs, 'occluded_color_working_defaults_v2_migrated', False)):
        return False
    ctx = context or getattr(bpy, 'context', None)
    try:
        broken_tuple = (
            str(getattr(prefs, 'occluded_display_mode', '') or '') == 'NEVER'
            and not bool(getattr(prefs, 'hide_occluded_colors_when_xray_off', False))
            and bool(getattr(prefs, 'hide_visible_occluded_when_occluded_off', False))
            and bool(getattr(prefs, 'optimization_lightest_disable_occluded_pass', False))
            and bool(getattr(prefs, 'show_occ_verts', True))
            and bool(getattr(prefs, 'show_occ_edges', True))
            and bool(getattr(prefs, 'show_occ_faces', True))
        )
        if broken_tuple:
            prefs.occluded_display_mode = 'XRAY_ONLY'
            prefs.hide_occluded_colors_when_xray_off = True
            prefs.hide_visible_occluded_when_occluded_off = False
            prefs.optimization_lightest_disable_occluded_pass = False
        prefs.occluded_color_working_defaults_v2_migrated = True
        settings.queue_save(ctx)
        return True
    except Exception:
        return False


def migrate_occluded_color_working_defaults_v3(prefs=None, context=None):
    """Repair the exact v2 false-marker tuple without changing custom policies.

    v2 marked the migration complete even when its predicate did not match.  The
    affected saved profile therefore retained both kill switches and NEVER.
    Restore only that reported CUSTOM tuple to the last known working policy:
    occluded colors in X-Ray, hidden while X-Ray is off.
    """
    if prefs is None:
        try:
            prefs = registry.resolve_addon_preferences(
                context or getattr(bpy, 'context', None))
        except Exception:
            prefs = None
    if prefs is None:
        return False
    if bool(getattr(prefs, 'occluded_color_working_defaults_v3_migrated', False)):
        return False
    ctx = context or getattr(bpy, 'context', None)
    try:
        broken_tuple = (
            bool(getattr(prefs, 'occluded_color_working_defaults_v2_migrated', False))
            and str(getattr(prefs, 'optimization_profile', '') or '') == 'CUSTOM'
            and str(getattr(prefs, 'occluded_display_mode', '') or '') == 'NEVER'
            and bool(getattr(prefs, 'hide_occluded_colors_when_xray_off', False))
            and bool(getattr(prefs, 'hide_visible_occluded_when_occluded_off', False))
            and bool(getattr(prefs, 'optimization_lightest_disable_occluded_pass', False))
            and bool(getattr(prefs, 'show_occ_verts', True))
            and bool(getattr(prefs, 'show_occ_edges', True))
            and bool(getattr(prefs, 'show_occ_faces', True))
        )
        if not broken_tuple:
            return False
        prefs.occluded_display_mode = 'XRAY_ONLY'
        prefs.hide_occluded_colors_when_xray_off = True
        prefs.hide_visible_occluded_when_occluded_off = False
        prefs.optimization_lightest_disable_occluded_pass = False
        prefs.occluded_color_working_defaults_v3_migrated = True
        if not bool(settings.save_now(ctx, force=True)):
            prefs.occluded_color_working_defaults_v3_migrated = False
            settings.queue_save(ctx)
            return False
        return True
    except Exception:
        try:
            prefs.occluded_color_working_defaults_v3_migrated = False
        except Exception:
            pass
        return False


def migrate_high_precision_outline_working_defaults_v1(prefs=None, context=None):
    """Restore the exact regressed black/1.0 HPO tuple once; keep custom styles."""
    if prefs is None:
        try:
            prefs = registry.resolve_addon_preferences(
                context or getattr(bpy, 'context', None))
        except Exception:
            prefs = None
    if prefs is None:
        return False
    if bool(getattr(prefs, 'high_precision_outline_working_defaults_v1_migrated', False)):
        return False
    changed = False
    try:
        legacy_style = (
            _color_close_tuple(
                getattr(prefs, 'high_precision_outline_color', ()),
                (0.0, 0.0, 0.0), eps=0.000001)
            and abs(float(getattr(
                prefs, 'high_precision_outline_thickness', 1.0)) - 1.0) <= 0.000001
        )
        if legacy_style:
            prefs.high_precision_outline_color = _HPO_WORKING_GREEN_DEFAULT
            prefs.high_precision_outline_thickness = 2.0
            changed = True
        prefs.high_precision_outline_working_defaults_v1_migrated = True
        settings.queue_save(context or getattr(bpy, 'context', None))
    except Exception:
        return False
    return changed


def migrate_high_precision_outline_working_defaults_v2(prefs=None, context=None):
    """Repair the persisted black/1.0 regression after the final settings replay."""
    if prefs is None:
        try:
            prefs = registry.resolve_addon_preferences(
                context or getattr(bpy, 'context', None))
        except Exception:
            prefs = None
    if prefs is None:
        return False
    if bool(getattr(prefs, 'high_precision_outline_working_defaults_v2_migrated', False)):
        return False
    ctx = context or getattr(bpy, 'context', None)
    try:
        legacy_style = (
            _color_close_tuple(
                getattr(prefs, 'high_precision_outline_color', ()),
                (0.0, 0.0, 0.0), eps=0.000001)
            and abs(float(getattr(
                prefs, 'high_precision_outline_thickness', 1.0)) - 1.0) <= 0.000001
        )
        if legacy_style:
            prefs.high_precision_outline_color = _HPO_WORKING_GREEN_DEFAULT
            prefs.high_precision_outline_thickness = 2.0
        prefs.high_precision_outline_working_defaults_v2_migrated = True
        settings.queue_save(ctx)
        return True
    except Exception:
        return False


def migrate_active_view_update_alias(prefs):
    """Move the removed redraw-only duplicate into Update Active View Only.

    Older builds exposed both "Update Active View Only" and "Redraw Update
    Active View Only".  The latter is now hidden and no longer appears in
    Feature Optimization; a saved True value is folded into active_view_only so
    the user can still control the behavior from the single visible switch.
    """
    if prefs is None:
        return False
    try:
        if not bool(getattr(prefs, 'optimization_active_redraw_only', False)):
            return False
    except Exception:
        return False
    global _OPTIMIZATION_PRESET_GUARD
    previous_guard = _OPTIMIZATION_PRESET_GUARD
    changed = False
    _OPTIMIZATION_PRESET_GUARD = True
    try:
        try:
            if hasattr(prefs, 'active_view_only') and not bool(getattr(prefs, 'active_view_only', False)):
                prefs.active_view_only = True
                changed = True
        except Exception:
            pass
        try:
            prefs.optimization_active_redraw_only = False
            changed = True
        except Exception:
            pass
    finally:
        _OPTIMIZATION_PRESET_GUARD = previous_guard
    return changed


# =============================================================================
# Addon Preferences
# =============================================================================
class SOS_AddonPreferences(bpy.types.PropertyGroup):
    # Internal WindowManager storage only.  This class intentionally does not
    # inherit from bpy.types.AddonPreferences, so Blender's Add-ons Preferences
    # panel does not display a Smart Overlay "Preferences" section.
    # -------------------------------------------------------------------------
    # Presets / Scene Overrides / Occluded / Hover / Topology (NEW)
    # -------------------------------------------------------------------------
    custom_presets: CollectionProperty(
        name='Smart Overlay User Presets',
        description='Internal collection of user presets created from the Smart Overlay N-panel.',
        type=SOS_PresetItem,
    )
    active_preset_id: StringProperty(name='Active Preset ID', description='Internal identifier of the preset currently selected in the Smart Overlay N-panel.', default='CUSTOM', options={'HIDDEN'})
    optimization_custom_settings_json: StringProperty(name='Optimization Custom Settings JSON', description='Hidden JSON snapshot for Feature Optimization Custom preset settings. Custom values are written here and mirrored to Smart_Overlay_Suite.json whenever a Custom optimization item changes.', default='', options={'HIDDEN'})
    optimization_previous_profile: StringProperty(name='Optimization Previous Profile', description='Hidden previous Feature Optimization preset id used to preserve Custom settings across preset switches.', default='', options={'HIDDEN'})
    sos_npanel_settings_json: StringProperty(name='N-panel Settings Snapshot', description='Hidden JSON snapshot used so Blender Save Preferences can preserve every Smart Overlay N-panel setting.', default='', options={'HIDDEN'})
    sos_persistent_feature_toggles_json: StringProperty(name='Persistent Feature Toggle Snapshot', description='Hidden JSON snapshot used so Blender Save Preferences can preserve the always-on feature toggles.', default='', options={'HIDDEN'})
    saved_mesh_overlay_addon_runtime_enabled: BoolProperty(name='Saved Mesh and Curve Overlay Runtime', description='Hidden saved ON/OFF state for the mesh and curve overlay runtime toggle.', default=False, options={'HIDDEN'})
    saved_proportional_overlay_addon_runtime_enabled: BoolProperty(name='Saved Proportional Overlay Runtime', description='Hidden saved ON/OFF state for the proportional overlay runtime toggle.', default=False, options={'HIDDEN'})
    saved_uv_hover_overlay_addon_runtime_enabled: BoolProperty(name='Saved UV Hover Overlay Runtime', description='Hidden saved ON/OFF state for the UV hover overlay runtime toggle.', default=False, options={'HIDDEN'})
    saved_object_hover_overlay_addon_runtime_enabled: BoolProperty(name='Saved Object Hover Overlay Runtime', description='Hidden saved ON/OFF state for the Object / Sculpt hover overlay runtime toggle.', default=False, options={'HIDDEN'})
    depth_offset_x1000_migrated: BoolProperty(name='Depth Offset x1000000 Migration Complete', description='Hidden migration flag for the depth-offset x1000000 UI scale.', default=False, options={'HIDDEN'})
    depth_offset_display_x1000_v7_migrated: BoolProperty(name='Depth Offset x1000000 Display v7 Migration Complete', description='Hidden migration flag for the depth-offset display scale where UI 1.00 equals internal 0.000001.', default=False, options={'HIDDEN'})
    depth_offset_x1000_display_v7_migrated: BoolProperty(name='Depth Offset x1000000 Display v7 Migration Alias', description='Hidden compatibility flag for earlier depth-offset x1000000 display migration builds.', default=False, options={'HIDDEN'})
    depth_offset_display_x1000000_v8_migrated: BoolProperty(name='Depth Offset x1000000 Display v8 Migration Complete', description='Hidden migration flag for the depth-offset display scale where UI 1.00 equals internal 0.000001.', default=False, options={'HIDDEN'})
    depth_offset_defaults_v2_migrated: BoolProperty(name='Depth Offset v2 Default Migration Complete', description='Hidden migration flag for legacy depth-offset defaults.', default=False, options={'HIDDEN'})
    depth_offset_defaults_v3_migrated: BoolProperty(name='Depth Offset v3 Default Migration Complete', description='Hidden migration flag for legacy depth-offset defaults.', default=False, options={'HIDDEN'})
    depth_offset_defaults_v4_migrated: BoolProperty(name='Depth Offset v4 Default Migration Complete', description='Hidden migration flag for legacy depth-offset defaults.', default=False, options={'HIDDEN'})
    depth_offset_defaults_v5_migrated: BoolProperty(name='Depth Offset v5 Default Migration Complete', description='Hidden migration flag for the enforced Vertex 3 / Edge 2 / Face 1 default depth-offset values.', default=False, options={'HIDDEN'})
    uv_hover_red_defaults_v1_migrated: BoolProperty(name='UV Hover Red Default Migration Complete', description='Hidden migration flag for the red UV hover default colors.', default=False, options={'HIDDEN'})
    occluded_color_visible_default_v1_migrated: BoolProperty(name='Occluded Color Visible Default v1 Migration Complete', description='Hidden one-time marker for the legacy occluded display tuple.', default=False, options={'HIDDEN'})
    occluded_color_working_defaults_v2_migrated: BoolProperty(name='Occluded Color Working Defaults v2 Migration Complete', description='Hidden one-time marker for restoring the known working X-Ray occluded-color policy.', default=False, options={'HIDDEN'})
    occluded_color_working_defaults_v3_migrated: BoolProperty(name='Occluded Color Working Defaults v3 Migration Complete', description='Hidden one-time marker for repairing the exact v2 false-marker occluded-color tuple.', default=False, options={'HIDDEN'})
    high_precision_outline_working_defaults_v1_migrated: BoolProperty(name='High-Precision Outline Working Defaults v1 Migration Complete', description='Hidden one-time marker for restoring the known working outline defaults.', default=False, options={'HIDDEN'})
    prop_heatmap_original_palette_v2_migrated: BoolProperty(name='Proportional Heatmap Original Palette v2 Migration Complete', description='Hidden one-time marker for restoring the original blue-to-red ColorRamp palette after the persisted grayscale regression.', default=False, options={'HIDDEN'})
    high_precision_outline_working_defaults_v2_migrated: BoolProperty(name='High-Precision Outline Working Defaults v2 Migration Complete', description='Hidden one-time marker for restoring the known working green outline defaults after final settings replay.', default=False, options={'HIDDEN'})
    optimization_profile: EnumProperty(
        name=T("Optimization Preset"),
        description=T("Choose a speed/quality preset. Presets only change the switches shown below; every switch remains editable."),
        items=[
            ('HIGHEST_QUALITY', T("Highest Quality"), T("Best quality. Keeps live updates and full overlay display.")),
            ('STANDARD', T("Standard"), T("Balanced mode. Reduces avoidable redraw and cache work.")),
            ('LIGHTWEIGHT', T("Lightweight"), T("Lighter mode for heavy scenes. Uses more cache and rebuild limits.")),
            ('LIGHTEST', T("Lightest"), T("Fastest mode. Defers rebuilds and simplifies expensive overlay parts while interacting.")),
            ('CUSTOM', T("Custom"), T("Manual settings. Your switch values are saved and restored.")),
        ],
        default='HIGHEST_QUALITY',
        update=_update_optimization_profile,
    )
    optimization_dirty_generation_cache: BoolProperty(
        name=T("Use Dirty Cache"),
        description=T('ON reuses overlay caches when the mesh has not changed. Active transforms still redraw live.'),
        default=False,
        update=_update_optimization_property,
    )
    optimization_disable_timed_live_sync_flush: BoolProperty(
        name=T("Reduce Live Cache Flushes"),
        description=T('ON reduces repeated short cache clears after edits. OFF updates more eagerly.'),
        default=False,
        update=_update_optimization_property,
    )
    optimization_split_evaluated_face_cache: BoolProperty(
        name=T("Separate Modified Face Cache"),
        description=T('ON caches modifier-applied edit-mode face fill separately from vertices and edges.'),
        default=False,
        update=_update_optimization_property,
    )
    optimization_async_evaluated_face_rebuild: BoolProperty(
        name=T("Rebuild Modified Faces by Timer"),
        description=T('ON rebuilds modifier-applied face data by timer when possible, instead of every draw.'),
        default=False,
        update=_update_optimization_property,
    )
    optimization_reuse_stale_evaluated_faces: BoolProperty(
        name=T("Keep Old Faces During Rebuild"),
        description=T('ON keeps the last modifier-applied face overlay visible until the new one is ready.'),
        default=False,
        update=_update_optimization_property,
    )
    optimization_throttle_evaluated_face_rebuild: BoolProperty(
        name=T("Limit Modified Face Rebuild Rate"),
        description=T('ON limits how often modifier-applied face data is rebuilt.'),
        default=False,
        update=_update_optimization_property,
    )
    optimization_evaluated_face_rebuild_interval: FloatProperty(
        name=T("Face Rebuild Interval"),
        description=T('Minimum time between limited face rebuilds. Lower follows edits more closely; higher is lighter.'),
        default=0.10,
        min=0.01,
        max=2.00,
        soft_min=0.03,
        soft_max=0.50,
        precision=2,
        step=1,
        update=_update_optimization_property,
    )
    optimization_target_modifier_dependency_dirty: BoolProperty(
        name=T("Limit Modifier Cache Invalidation"),
        description=T('ON clears only related modifier caches when possible, instead of clearing all.'),
        default=False,
        update=_update_optimization_property,
    )
    optimization_conditional_depth_prepass: BoolProperty(
        name=T("Depth Pass Only When Needed"),
        description=T('ON runs the hidden depth pass only when occlusion or X-Ray drawing needs it.'),
        default=False,
        update=_update_optimization_property,
    )
    optimization_indexed_edit_batches: BoolProperty(
        name=T("Use Indexed Edit Batches"),
        description=T('ON uses indexed GPU batches when possible to reduce upload size.'),
        default=False,
        update=_update_optimization_property,
    )
    optimization_skip_inactive_batches: BoolProperty(
        name=T("Skip Disabled / Transparent Passes"),
        description=T('ON skips overlay parts that are turned off or fully transparent.'),
        default=False,
        update=_update_optimization_property,
    )
    optimization_hover_event_only: BoolProperty(
        name=T("Update Hover Only When Needed"),
        description=T('ON recalculates hover only after mouse, edit, selection, or view changes.'),
        default=False,
        update=_update_optimization_property,
    )
    optimization_split_topology_cache: BoolProperty(
        name=T("Separate Topology Cache"),
        description=T('ON caches bevel, crease, seam, sharp, and similar topology overlays separately.'),
        default=False,
        update=_update_optimization_property,
    )
    show_embedded_edit_cage_while_view_still_xray_off: BoolProperty(
        name=T("Still View: Show Embedded Cage"),
        description=T('In Mesh Edit Mode with X-Ray OFF and a visible modifier such as Subdivision Surface, ON keeps the slightly darker vertices and edges visible while the view is still, even where the editable cage is embedded behind the modified surface; they are temporarily hidden during orbit, pan, or zoom and restored when navigation stops. OFF does not draw them even while the view is still, matching the state during navigation. Selection, hover, diagnostic colors, X-Ray ON, faces, and face-center points are not affected.'),
        default=True,
        update=_update_optimization_property,
    )
    optimization_navigation_light_mode: BoolProperty(
        name=T("Defer Updates While Navigating"),
        description=T('ON delays heavy rebuilds while orbiting, panning, or zooming.'),
        default=False,
        update=_update_optimization_property,
    )
    optimization_active_redraw_only: BoolProperty(
        name='Legacy Active View Update Alias',
        description='Hidden compatibility value from older versions. The visible setting is Update Active View Only.',
        default=False,
        options={'HIDDEN'},
        update=_update_prefs,
    )
    optimization_lightest_freeze_batches_during_navigation: BoolProperty(
        name=T("Freeze Batches While Navigating"),
        description=T('ON reuses existing mesh batches while orbiting, panning, or zooming instead of rebuilding them mid-navigation.'),
        default=False,
        update=_update_optimization_property,
    )
    optimization_lightest_active_object_only: BoolProperty(
        name=T("Active Object Only"),
        description=T('ON draws only the active mesh or curve for the mesh/curve overlay.'),
        default=False,
        update=_update_optimization_property,
    )
    optimization_lightest_disable_mesh_hover: BoolProperty(
        name=T("Disable Mesh Hover"),
        description=T('ON skips mesh/curve hover calculations for maximum responsiveness.'),
        default=False,
        update=_update_optimization_property,
    )
    optimization_lightest_disable_occluded_pass: BoolProperty(
        name=T("Disable Occluded Pass"),
        description=T('ON skips occluded-color drawing and its hidden depth pass.'),
        default=False,
        update=_update_optimization_property,
    )
    high_precision_outline_hide_occluded_in_xray: BoolProperty(
        name=T("X-Ray: Hide Occluded Outline"),
        description=T("ON makes High-Precision Outline use normal surface occlusion while viewport X-Ray is enabled, matching its X-Ray-off visibility. OFF keeps the through-surface outline in X-Ray."),
        default=False,
        update=_update_optimization_property,
    )
    optimization_lightest_disable_topology_diagnostics: BoolProperty(
        name=T("Disable Topology Diagnostics"),
        description=T('ON skips topology diagnostic overlays such as seam, sharp, crease, bevel-weight, and non-manifold helpers.'),
        default=False,
        update=_update_optimization_property,
    )
    optimization_lightest_lod_skip_dense_vertices_edges: BoolProperty(
        name=T("Dense Mesh LOD: Faces Only"),
        description=T('ON skips very dense vertex/edge drawing above the limit and keeps face fill.'),
        default=False,
        update=_update_optimization_property,
    )
    optimization_lightest_lod_element_limit: IntProperty(
        name=T("LOD Element Limit"),
        description=T('Vertex + edge + face count where dense overlay simplification starts.'),
        default=200000,
        min=1000,
        max=10000000,
        soft_min=10000,
        soft_max=1000000,
        update=_update_optimization_property,
    )

    use_scene_overrides: BoolProperty(name=T("Use Scene Overrides"), description=T("Enable a per-.blend override layer stored in the Scene. When enabled, turn Scene Overrides Enabled ON and use Save/Load/Clear to manage overrides for this file only."), default=True, update=_update_prefs)

    occluded_display_mode: EnumProperty(
        name=T("Occluded Display Mode"),
        description=T("Controls when the add-on draws occluded overlays (elements behind the visible surface). This works together with the Occluded toggles in the Vertex/Edge/Face sections."),
        items=[
            ('XRAY_ONLY', T("X-Ray Only"), T("Draw occluded overlays only when X-Ray is enabled in the viewport.")),
            ('ALWAYS',    T("Always"),    T("Always draw occluded overlays (independent of X-Ray).")),
            ('NEVER',     T("Never"),     T("Never draw occluded overlays.")),
        ],
        default='XRAY_ONLY',
        update=_update_prefs,
    )
    occluded_style: EnumProperty(
        name=T("Occluded Style"),
        description=T("Visual style for occluded overlays."),
        items=[
            ('NORMAL',    T("Normal"),      T("Use the same thickness/alpha as normal overlays.")),
            ('FADE',      T("Fade"),        T("Lower alpha for occluded overlays.")),
            ('THIN',      T("Thin"),        T("Use thinner lines/points for occluded overlays.")),
            ('FADE_THIN', T("Fade + Thin"), T("Fade and thin for occluded overlays.")),
            ('DASHED',    T("Dashed"),      T("Draw occluded edges as dashed lines.")),
        ],
        default='FADE_THIN',
        update=_update_prefs,
    )
    occluded_alpha_mul: FloatProperty(name=T("Occluded Alpha Multiplier"), description=T("Alpha multiplier when occluded style uses fading."), min=0.0, max=1.0, default=0.45, update=_update_prefs)
    occluded_thickness_mul: FloatProperty(name=T("Occluded Line Width"), description=T("Line width multiplier when occluded style uses thinning."), min=0.1, max=2.0, default=0.75, update=_update_prefs)
    occluded_point_mul: FloatProperty(name=T("Occluded Point Multiplier"), description=T("Point size multiplier when occluded style uses thinning."), min=0.1, max=2.0, default=0.85, update=_update_prefs)
    hide_occluded_colors_when_xray_off: BoolProperty(
        name=T("X-Ray Off: Hide Occluded Color"),
        description=T('ON hides occluded colors when X-Ray is off. Visible colors are unchanged.'),
        default=True,
        update=_update_optimization_property,
    )

    hide_visible_occluded_when_occluded_off: BoolProperty(
        name=T("Occlusion Off: Hide Hidden Parts"),
        description=T('ON hides overlay parts behind the mesh when occlusion display is off.'),
        default=False,
        update=_update_optimization_property,
    )

    use_all_objects_as_occluders: BoolProperty(
        name=T("Use Other Objects for Occlusion"),
        description=T('ON lets other visible objects hide this overlay. OFF uses only the target object.'),
        default=False,
        update=_update_optimization_property,
    )

    hover_lod_mode: EnumProperty(
        name=T("Hover LOD Mode"),
        description=T('Choose how hover picking searches the nearest element. Full Scan checks every element on screen (accurate but heavy). Auto switches to the fast method on heavy meshes. Face-local only always uses the fast method.'),
        items=[
            ('FULL', T('Full Scan'), T('Scan all vertices/edges in screen space.')),
            ('AUTO', T("Auto"), T('Use the fast method on heavy meshes.')),
            ('FACE_ONLY', T("Face-local only"), T('Always use the fast method, which checks only the face under the cursor and its neighbors.')),
        ],
        default='AUTO',
        update=_update_prefs,
    )
    hover_lod_threshold_verts: IntProperty(name=T("Auto Switch Verts"), description=T("When hover LOD is Auto, switch to face-local mode above this vertex count."), min=1000, max=5000000, default=200000, update=_update_prefs)

    high_precision_outline_enabled: BoolProperty(
        name=T("Enable High-Precision Outline"),
        description=T("Replace Blender's Solid viewport Outline with Smart Overlay's topology-based high-precision outline. It detects real silhouette edges and visible surface-intersection lines from evaluated meshes instead of relying on a loose screen-space depth threshold. This improves nearby front/back surface separation, adds outlines where evaluated objects cross, and reduces jagged edges through Blender's antialiased polyline shader. Intersection geometry is cached and is recalculated only when a participating evaluated mesh or object transform changes. While enabled, Blender's standard Outline is disabled only for affected 3D Views and each previous state is restored when this option is turned off. At Outline Thickness 1.00, the line width follows the active Blender theme Outline Width; adjust Outline Thickness to make only this high-precision outline thinner or thicker."),
        default=False,
        update=_update_high_precision_outline_enabled,
    )
    high_precision_outline_color: FloatVectorProperty(
        name=T("Outline Color"),
        description=T("Color of the high-precision outline drawn in Solid viewport shading. This is independent from Blender's standard Object Outline color."),
        subtype='COLOR', size=3, min=0.0, max=1.0,
        default=_HPO_WORKING_GREEN_DEFAULT,
        update=_update_high_precision_outline_color,
    )
    high_precision_outline_thickness: FloatProperty(
        name=T("Outline Thickness"),
        description=T("Thickness multiplier for the high-precision outline. 1.00 uses the active Blender theme Outline Width, 2.00 draws the line twice as thick, and 0.50 draws it half as thick. This setting applies equally to silhouettes, object boundaries, loose and non-manifold outline edges, and visible mesh-intersection lines. It changes only Smart Overlay's high-precision outline and does not modify the Blender theme or the standard Outline setting."),
        min=0.25, max=8.0, soft_min=0.5, soft_max=4.0,
        default=2.0, precision=2, step=5,
        update=_update_high_precision_outline_style,
    )
    high_precision_outline_native_state_json: StringProperty(
        name="High-Precision Outline Native State",
        description="Internal persistent snapshot used to restore Blender's native viewport Outline after restart.",
        default="",
        options={'HIDDEN'},
    )

    topology_checks_enabled: BoolProperty(name=T("Enable Topology Checks"), description=T("Draw diagnostic overlays on top of the normal overlay: seams, sharp edges, non-manifold/boundary, ngons, tiny faces, and more. Useful for cleanup; may add a small performance cost."), default=False, update=_update_prefs)
    topo_selection_filter: EnumProperty(
        name=T("Selection Filter"),
        description=T("Which elements to consider for topology checks."),
        items=[
            ('ALL', T("All"), T("Consider all elements.")),
            ('UNSELECTED', T("Unselected Only"), T("Only unselected elements.")),
            ('SELECTED', T("Selected Only"), T("Only selected elements.")),
        ],
        default='ALL',
        update=_update_prefs,
    )
    topo_edges_enabled: BoolProperty(name=T("Edges"), description=T("Enable topology edge overlays."), default=True, update=_update_prefs)
    topo_show_seams: BoolProperty(name=T("Show Seams"), description=T("Highlight UV seams."), default=True, update=_update_prefs)
    topo_show_sharp: BoolProperty(name=T("Show Sharp"), description=T("Highlight sharp (non-smooth) edges."), default=True, update=_update_prefs)
    topo_show_crease: BoolProperty(name=T("Show Crease"), description=T("Highlight crease edges above threshold."), default=False, update=_update_prefs)
    topo_crease_threshold: FloatProperty(name=T("Crease Threshold"), description=T("Minimum crease value to highlight."), min=0.0, max=1.0, default=0.25, update=_update_prefs)
    topo_show_bevel_weight: BoolProperty(name=T("Show Bevel Weight"), description=T("Highlight bevel-weighted edges above threshold."), default=False, update=_update_prefs)
    topo_bevel_weight_threshold: FloatProperty(name=T("Bevel Weight Threshold"), description=T("Minimum bevel weight value to highlight."), min=0.0, max=1.0, default=0.25, update=_update_prefs)
    topo_show_non_manifold: BoolProperty(name=T("Show Non-Manifold"), description=T("Highlight non-manifold / boundary edges."), default=True, update=_update_prefs)
    topo_edge_color_seam: FloatVectorProperty(name=T("Seam Color"), description=T("Color for seam edges."), subtype='COLOR', size=3, min=0.0, max=1.0, default=(0.05, 0.9, 1.0), update=_update_prefs)
    topo_edge_color_sharp: FloatVectorProperty(name=T("Sharp Color"), description=T("Color for sharp edges."), subtype='COLOR', size=3, min=0.0, max=1.0, default=(1.0, 0.6, 0.05), update=_update_prefs)
    topo_edge_color_crease: FloatVectorProperty(name=T("Crease Color"), description=T("Color for crease edges."), subtype='COLOR', size=3, min=0.0, max=1.0, default=(1.0, 0.2, 0.7), update=_update_prefs)
    topo_edge_color_bevel: FloatVectorProperty(name=T("Bevel Color"), description=T("Color for bevel weight edges."), subtype='COLOR', size=3, min=0.0, max=1.0, default=(0.2, 1.0, 0.3), update=_update_prefs)
    topo_edge_color_nonmanifold: FloatVectorProperty(name=T("Non-Manifold Color"), description=T("Color for non-manifold edges."), subtype='COLOR', size=3, min=0.0, max=1.0, default=(1.0, 0.05, 0.05), update=_update_prefs)
    topo_edge_size_mul: FloatProperty(name=T("Topology Line Width"), description=T("Line width multiplier for topology edge overlays."), min=0.25, max=4.0, default=1.4, update=_update_prefs)

    topo_faces_enabled: BoolProperty(name=T("Faces"), description=T("Enable topology face overlays."), default=True, update=_update_prefs)
    topo_show_ngons: BoolProperty(name=T("Show Ngons"), description=T("Highlight ngons (faces with 5+ sides)."), default=False, update=_update_prefs)
    topo_show_small_faces: BoolProperty(name=T("Show Small Faces"), description=T("Highlight very small faces by area."), default=False, update=_update_prefs)
    topo_small_face_area: FloatProperty(name=T("Small Face Area"), description=T("Area threshold for small face highlighting."), min=0.0, max=1000.0, default=0.00005, update=_update_prefs)
    topo_show_backfaces: BoolProperty(name=T("Show Backfaces"), description=T("Highlight backfaces (useful for flipped normals)."), default=False, update=_update_prefs)
    topo_face_color_ngon: FloatVectorProperty(name=T("Ngon Color"), description=T("Color for ngon faces."), subtype='COLOR', size=3, min=0.0, max=1.0, default=(1.0, 0.2, 0.2), update=_update_prefs)
    topo_face_color_small: FloatVectorProperty(name=T("Small Face Color"), description=T("Color for small faces."), subtype='COLOR', size=3, min=0.0, max=1.0, default=(1.0, 0.8, 0.15), update=_update_prefs)
    topo_face_color_backface: FloatVectorProperty(name=T("Backface Color"), description=T("Color for backfaces."), subtype='COLOR', size=3, min=0.0, max=1.0, default=(0.2, 0.6, 1.0), update=_update_prefs)
    topo_face_opacity_mul: FloatProperty(name=T("Topology Face Opacity"), description=T("Opacity multiplier for topology face overlays."), min=0.0, max=2.0, default=0.65, update=_update_prefs)

    
    show_verts_edit: BoolProperty(name=T("Edit"), description=T("Show the vertex overlay while you are in Edit Mode. Disable to reduce visual clutter and improve performance if you only need edges/faces."), default=True, update=_update_prefs)
    show_verts_object: BoolProperty(name=T("Object"), description=T("Show the vertex overlay while you are in Object Mode / Sculpt Mode. Useful for quick topology checks on evaluated results without entering Edit Mode."), default=False, update=_update_prefs)
    show_vis_verts: BoolProperty(name="", description=T("Draw vertices that are visible from the current view (not hidden behind geometry)."), default=True, update=_update_prefs)
    show_occ_verts: BoolProperty(name="", description=T("Draw vertices that are occluded (behind geometry). Visibility is controlled by Occluded Display Mode (X-Ray Only / Always / Never)."), default=True, update=_update_prefs)
    show_sel_verts: BoolProperty(name="", description=T("Highlight selected vertices using the Selected Color. (Edit Mode selection)"), default=True, update=_update_prefs)
    show_hov_verts: BoolProperty(name="", description=T("Highlight the vertex under the mouse cursor (hover) in Edit Mode."), default=True, update=_update_prefs)
    show_hov_obj_verts: BoolProperty(name="", description=T("In Object Mode / Sculpt Mode, highlight vertices of the object under the mouse cursor (object hover)."), default=False, update=_update_prefs)
    vertex_color: FloatVectorProperty(name=T("Visible Color"), description=T("Color used for visible vertices."), subtype='COLOR', size=3, default=(0.040, 0.000, 0.807), update=_update_prefs)
    vertex_occluded_color: FloatVectorProperty(name=T("Occluded Color"), description=T("Color used for occluded vertices (behind geometry) when occluded overlays are enabled by Occluded Display Mode."), subtype='COLOR', size=3, default=(0.076, 0.087, 0.503), update=_update_prefs)
    selected_vertex_overlay_color: FloatVectorProperty(name=T("Selected Color"), description=T("Color used for selected vertices."), subtype='COLOR', size=3, default=(1.0, 0.1221387722, 0.0), update=_update_prefs)
    hover_vertex_color: FloatVectorProperty(name=T("Hover Color"), description=T("Color used for the hovered vertex (under the mouse) in Edit Mode."), subtype='COLOR', size=3, default=(1.0, 0.7835, 0.0137), update=_update_prefs)
    hover_obj_vertex_color: FloatVectorProperty(name=T("Vertex Color"), description=T("Color used for vertex overlay when an object is hovered in Object Mode / Sculpt Mode."), subtype='COLOR', size=3, default=(1.0, 0.7835, 0.0137), update=_update_prefs)
    vertex_size: IntProperty(name=T("Vertex Size(px)"), description=T("Pixel size of the vertex overlay points. Larger values are heavier and may hide detail."), min=1, max=20, default=4, update=_update_prefs)
    # Internal value is float. UI displays the internal value multiplied by 1,000,000.
    vertex_depth_offset: FloatProperty(name=T("Vertex Z-Offset"), description=T("Internal depth offset value. The UI displays this value multiplied by 1,000,000; UI 1.00 equals internal 0.000001, and internal 0.001 is displayed as 1000.00."), min=0.0, max=_DEPTH_OFFSET_FLOAT_MAX, default=0.003, update=_update_depth_float)
    vertex_depth_offset_ui: FloatProperty(name=T("Vertex Z-Offset"), description=T("Depth offset strength for the vertex overlay. The display is scaled by 1,000,000: internal 0.001 is shown as 1000.00, and 1.00 applies 0.000001. The former 0.003 default is shown as 3000.00. Increase it only when vertices visually fight with the mesh surface; 0.00 disables the offset completely."), min=0.0, max=_DEPTH_OFFSET_UI_MAX, step=1, precision=_DEPTH_OFFSET_UI_PRECISION, default=3000.00, update=_update_vertex_depth_ui)
    
    show_edges_edit: BoolProperty(name=T("Edit"), description=T("Show the edge overlay while you are in Edit Mode."), default=True, update=_update_prefs)
    show_edges_object: BoolProperty(name=T("Object"), description=T("Show the edge overlay while you are in Object Mode / Sculpt Mode."), default=False, update=_update_prefs)
    show_vis_edges: BoolProperty(name="", description=T("Draw edges that are visible from the current view."), default=True, update=_update_prefs)
    show_occ_edges: BoolProperty(name="", description=T("Draw edges that are occluded (behind geometry). Visibility is controlled by Occluded Display Mode (X-Ray Only / Always / Never)."), default=True, update=_update_prefs)
    show_sel_edges: BoolProperty(name="", description=T("Highlight selected edges using the Selected Color."), default=True, update=_update_prefs)
    show_hov_edges: BoolProperty(name="", description=T("Highlight the edge under the mouse cursor (hover) in Edit Mode."), default=True, update=_update_prefs)
    show_hov_obj_edges: BoolProperty(name="", description=T("In Object Mode / Sculpt Mode, highlight edges of the object under the mouse cursor (object hover)."), default=False, update=_update_prefs)
    edge_color: FloatVectorProperty(name=T("Visible Color"), description=T("Color used for visible edges."), subtype='COLOR', size=3, default=(1.0, 1.0, 1.0), update=_update_prefs)
    edge_occluded_color: FloatVectorProperty(name=T("Occluded Color"), description=T("Color used for occluded edges (behind geometry) when occluded overlays are enabled by Occluded Display Mode."), subtype='COLOR', size=3, default=(0.445, 0.445, 0.445), update=_update_prefs)
    selected_edge_overlay_color: FloatVectorProperty(name=T("Selected Color"), description=T("Color used for selected edges."), subtype='COLOR', size=3, default=(1.0, 0.33, 0.0), update=_update_prefs)
    hover_edge_color: FloatVectorProperty(name=T("Hover Color"), description=T("Color used for the hovered edge (under the mouse) in Edit Mode."), subtype='COLOR', size=3, default=(1.0, 0.7835, 0.0137), update=_update_prefs)
    hover_obj_edge_color: FloatVectorProperty(name=T("Edge Color"), description=T("Color used for edge overlay when an object is hovered in Object Mode / Sculpt Mode."), subtype='COLOR', size=3, default=(1.0, 0.7835, 0.0137), update=_update_prefs)
    edge_size: IntProperty(name=T("Edge Size(px)"), description=T("Pixel width of the edge overlay lines. Larger values are heavier. (Integer pixel size)"), min=1, max=20, default=1, update=_update_prefs)
    # Internal value is float. UI displays the internal value multiplied by 1,000,000.
    edge_depth_offset: FloatProperty(name=T("Edge Z-Offset"), description=T("Internal depth offset value. The UI displays this value multiplied by 1,000,000; UI 1.00 equals internal 0.000001, and internal 0.001 is displayed as 1000.00."), min=0.0, max=_DEPTH_OFFSET_FLOAT_MAX, default=0.002, update=_update_depth_float)
    edge_depth_offset_ui: FloatProperty(name=T("Edge Z-Offset"), description=T("Depth offset strength for the edge overlay. The display is scaled by 1,000,000: internal 0.001 is shown as 1000.00, and 1.00 applies 0.000001. The former 0.002 default is shown as 2000.00. Increase it only when edges visually fight with the mesh surface; 0.00 disables the offset completely."), min=0.0, max=_DEPTH_OFFSET_UI_MAX, step=1, precision=_DEPTH_OFFSET_UI_PRECISION, default=2000.00, update=_update_edge_depth_ui)
    
    show_faces_edit: BoolProperty(name=T("Edit"), description=T("Show the face overlay (filled polygons) while you are in Edit Mode."), default=True, update=_update_prefs)
    show_faces_object: BoolProperty(name=T("Object"), description=T("Show the face overlay while you are in Object Mode / Sculpt Mode."), default=True, update=_update_prefs)
    show_vis_faces: BoolProperty(name="", description=T("Draw faces that are visible from the current view."), default=True, update=_update_prefs)
    show_occ_faces: BoolProperty(name="", description=T("Draw faces that are occluded (behind geometry). Visibility is controlled by Occluded Display Mode (X-Ray Only / Always / Never)."), default=True, update=_update_prefs)
    show_sel_faces: BoolProperty(name="", description=T("Highlight selected faces using the Selected Color. Alpha uses Face Opacity."), default=True, update=_update_prefs)
    show_hov_faces: BoolProperty(name="", description=T("Highlight faces under the mouse cursor (hover) in Edit Mode."), default=True, update=_update_prefs)
    show_hov_obj_faces: BoolProperty(name="", description=T("In Object Mode / Sculpt Mode, highlight faces of the object under the mouse cursor (object hover)."), default=True, update=_update_prefs)
    face_color: FloatVectorProperty(name=T("Visible Color"), description=T("Color used for visible faces."), subtype='COLOR', size=3, default=(0.0, 0.130, 0.807), update=_update_prefs)
    face_occluded_color: FloatVectorProperty(name=T("Occluded Color"), description=T("Color used for occluded faces (behind geometry) when occluded overlays are enabled by Occluded Display Mode."), subtype='COLOR', size=3, default=(0.347, 0.423, 1.0), update=_update_prefs)
    selected_face_overlay_color: FloatVectorProperty(name=T("Selected Color"), description=T("Color used for selected faces. Alpha uses Face Opacity."), subtype='COLOR', size=3, default=(1.0, 0.33, 0.0), update=_update_prefs)
    hover_face_color: FloatVectorProperty(name=T("Hover Color"), description=T("Color used for the hovered face (under the mouse) in Edit Mode."), subtype='COLOR', size=3, default=(1.0, 0.7835, 0.0137), update=_update_prefs)
    hover_obj_face_color: FloatVectorProperty(name=T("Face Color"), description=T("Color used for face overlay when an object is hovered in Object Mode / Sculpt Mode."), subtype='COLOR', size=3, default=(1.0, 0.7835, 0.0137), update=_update_prefs)
    hover_obj_vertex_edge_opacity: FloatProperty(name=T("Vertex / Edge Opacity"), description=T("Opacity used by Object / Sculpt hover vertices and edges. This is independent from Mesh and Curve Overlay Face Opacity, so changing Mesh and Curve Overlay opacity does not change object-hover points or lines. Use 1.00 for the previous fully opaque look; lower values make the hover outline softer."), min=0.0, max=1.0, default=1.0, precision=2, update=_update_prefs)
    hover_obj_face_opacity: FloatProperty(name=T("Object / Sculpt Hover Face Opacity"), description=T("Opacity used by the Object / Sculpt hover face fill. This is independent from Mesh and Curve Overlay Face Opacity, so changing Mesh and Curve Overlay opacity does not change object-hover face fill strength. The default 0.20 matches the previous default face-overlay opacity."), min=0.0, max=1.0, default=0.2, precision=2, update=_update_prefs)
    opacity: FloatProperty(name=T("Face Opacity"), description=T("Opacity (alpha) of the face overlay fill. 0 = fully transparent, 1 = fully opaque."), min=0.0, max=1.0, default=0.2, update=_update_prefs)
    # Internal value is float. UI displays the internal value multiplied by 1,000,000.
    face_depth_offset: FloatProperty(name=T("Face Z-Offset"), description=T("Internal depth offset value. The UI displays this value multiplied by 1,000,000; UI 1.00 equals internal 0.000001, and internal 0.001 is displayed as 1000.00."), min=0.0, max=_DEPTH_OFFSET_FLOAT_MAX, default=0.001, update=_update_depth_float)
    face_depth_offset_ui: FloatProperty(name=T("Face Z-Offset"), description=T("Depth offset strength for the face overlay. The display is scaled by 1,000,000: internal 0.001 is shown as 1000.00, and 1.00 applies 0.000001. The former 0.001 default is shown as 1000.00. Increase it only when faces visually fight with the mesh surface; 0.00 disables the offset completely."), min=0.0, max=_DEPTH_OFFSET_UI_MAX, step=1, precision=_DEPTH_OFFSET_UI_PRECISION, default=1000.00, update=_update_face_depth_ui)
    
    hover_delay_sec: FloatProperty(name=T("Selection Delay (sec)"), description=T("Delay (seconds) before hover detection becomes active after Object / Sculpt selection changes. Increase if hover flickers or feels unstable."), default=0.25, min=0.0, max=5.0, update=_update_prefs)
    
    # -------------------------------------------------------------------------
    # UV Editor Hover Color (NEW)
    # -------------------------------------------------------------------------
    show_hov_uv_verts: BoolProperty(
        name=T("Use UV Vertex Hover"),
        description=T("In the UV Editor, draw a hover highlight for UV vertices (points) when UV Select Mode is Vertex. Turn OFF for maximum performance on dense UVs."),
        default=True, update=_update_uv_overlay_prefs,
    )
    hover_uv_vertex_color: FloatVectorProperty(
        name=T("UV Vertex Hover Color"),
        description=T("Color used to highlight the hovered UV vertex (point) under the mouse in the UV Editor (Vertex select mode)."),
        subtype='COLOR', size=3, default=(1.0, 0.0, 0.0), update=_update_uv_overlay_prefs,
    )
    show_hov_uv_edges: BoolProperty(
        name=T("Use UV Edge Hover"),
        description=T("In the UV Editor, draw a hover highlight for UV edges when UV Select Mode is Edge. Turn OFF if you notice slowdown on very dense UVs."),
        default=True, update=_update_uv_overlay_prefs,
    )
    hover_uv_edge_color: FloatVectorProperty(
        name=T("UV Edge Hover Color"),
        description=T("Color used to highlight the hovered UV edge (segment) under the mouse in the UV Editor (Edge select mode)."),
        subtype='COLOR', size=3, default=(1.0, 0.0, 0.0), update=_update_uv_overlay_prefs,
    )
    show_hov_uv_faces: BoolProperty(
        name=T("Use UV Face Hover"),
        description=T("In the UV Editor, draw a hover highlight for UV faces when UV Select Mode is Face. This draws a filled polygon and can be heavier on dense meshes."),
        default=True, update=_update_uv_overlay_prefs,
    )
    hover_uv_face_color: FloatVectorProperty(
        name=T("UV Face Hover Color"),
        description=T("Color used to highlight the hovered UV face under the mouse in the UV Editor (Face select mode). Alpha uses UV Hover Face Opacity, independent from Mesh and Curve Overlay Face Opacity."),
        subtype='COLOR', size=3, default=(1.0, 0.0, 0.0), update=_update_uv_overlay_prefs,
    )
    hover_uv_vertex_edge_opacity: FloatProperty(
        name=T("UV Vertex / Edge Opacity"),
        description=T("Opacity used by UV hover vertices, edges, and face outlines in the UV Editor. This is independent from Mesh and Curve Overlay Face Opacity; use 1.00 for the previous fully opaque UV hover outline."),
        min=0.0, max=1.0, default=1.0, precision=2, update=_update_uv_overlay_prefs,
    )
    hover_uv_face_opacity: FloatProperty(
        name=T("UV Hover Face Opacity"),
        description=T("Opacity used by the filled UV hover face in the UV Editor. This is independent from Mesh and Curve Overlay Face Opacity, so mesh face opacity changes do not change UV hover face fill strength. The default 0.20 matches the previous default face-overlay opacity."),
        min=0.0, max=1.0, default=0.2, precision=2, update=_update_uv_overlay_prefs,
    )
    show_uv_same_mesh_selection_overlay: BoolProperty(
        name=T("Show Same Mesh Element UVs"),
        description=T("In the UV Editor, when a UV vertex, edge, or face is selected, highlight other unselected UV vertices and edges that refer to the same mesh vertices or mesh edges. This makes split UVs and shared 3D elements visible without selecting them."),
        default=True, update=_update_uv_overlay_prefs,
    )
    show_uv_same_mesh_selection_verts: BoolProperty(
        name=T("Same Mesh Vertex"),
        description=T("Highlight unselected UV vertices that use the same 3D mesh vertex as the selected UV element. Turn this OFF if you only want same-edge highlighting."),
        default=True, update=_update_uv_overlay_prefs,
    )
    show_uv_same_mesh_selection_edges: BoolProperty(
        name=T("Same Mesh Edge"),
        description=T("Highlight unselected UV edges that use the same 3D mesh edge as the selected UV element. Turn this OFF if you only want same-vertex highlighting."),
        default=True, update=_update_uv_overlay_prefs,
    )
    uv_same_mesh_selection_color: FloatVectorProperty(
        name=T("Same Mesh Element Color"),
        description=T("Color used for unselected UV vertices and edges that share the same 3D mesh vertices or edges as the current UV selection. The default is yellow."),
        subtype='COLOR', size=3, default=(1.0, 1.0, 0.0), update=_update_uv_overlay_prefs,
    )
    uv_same_mesh_selection_opacity: FloatProperty(
        name=T("Same Mesh Element Opacity"),
        description=T("Opacity for the same-mesh-element UV overlay. It only affects the yellow helper overlay and does not change the normal UV hover colors."),
        min=0.0, max=1.0, default=1.0, precision=2, update=_update_uv_overlay_prefs,
    )
    double_sided: BoolProperty(name=T("Draw Back Faces"), description=T('ON draws face fill on both sides. OFF draws front faces only and is lighter.'), default=True, update=_update_optimization_property)
    active_view_only: BoolProperty(name=T("Update Active View Only"), description=T('ON limits redraw requests to the 3D View that is being operated when possible. It does not hide overlays in other views; it only reduces unnecessary updates.'), default=False, update=_update_optimization_property)
    active_view_draw_only: BoolProperty(name=T("Draw Active View Only"), description=T('ON draws Smart Overlay only in the 3D View most recently clicked or navigated. Moving the cursor across views without an operation does not change the active view.'), default=False, update=_update_optimization_property)
    include_geometry_nodes_objects: BoolProperty(name=T("Include Modifier Results"), description=T('ON includes visible modifier and Geometry Nodes results. OFF skips them for speed.'), default=True, update=_update_optimization_property)
    include_curve_shape_overlay: BoolProperty(name=T("Include Curve Shapes"), description=T('ON draws curve control points and shape edges. OFF skips curve shapes.'), default=True, update=_update_optimization_property)
    include_lattice_objects: BoolProperty(name=T("Include Lattices"), description=T('ON draws lattice points and cage edges. OFF ignores lattices.'), default=True, update=_update_optimization_property)
    use_evaluated_edit_mode_face_overlay: BoolProperty(name=T("Edit Mode: Use Modified Faces"), description=T('ON draws edit-mode face fill on the modifier-applied mesh. OFF uses the edit cage.'), default=True, update=_update_optimization_property)
    use_select_mode_vertex_center_overlay: BoolProperty(name=T("Edge/Face Mode: Use Face Centers"), description=T('ON shows face center points in edge/face select modes. OFF shows real vertices.'), default=True, update=_update_optimization_property)
    hide_blender_standard_edit_edges_vertices: BoolProperty(
        name=T("Hide Blender Edit Edges/Verts"),
        description=T("When ON and Mesh and Curve Overlay is active in Mesh Edit Mode, Blender's neutral black edit edges and vertices are visually suppressed so they do not show through or form a dark halo under Smart Overlay's edge and vertex colors. Smart Overlay temporarily maps only the neutral base edge/vertex theme colors to the matching overlay colors and reduces the native base line/point size to one pixel. Selected, active, seam, sharp, crease, bevel, and other diagnostic colors remain unchanged. The original Blender theme colors and sizes are restored when this option is turned OFF, Edit Mode ends, the mesh overlay is disabled, or the add-on is unregistered."),
        default=True,
        update=_update_optimization_property,
    )
    hide_blender_adjacent_edge_gradient: BoolProperty(name=T("Hide Adjacent Edge Gradient"), description=T("ON hides Smart Overlay adjacent-edge gradient. Blender settings are unchanged."), default=True, update=_update_optimization_property)
    hide_blender_vertex_mode_linked_edge_face_overlay: BoolProperty(name=T("Vertex Mode: Hide Edge/Face"), description=T('ON hides linked edge/face selection colors in Vertex Select mode.'), default=False, update=_update_optimization_property)
    hide_blender_edge_mode_linked_vertex_face_overlay: BoolProperty(name=T("Edge Mode: Hide Vertex/Face"), description=T('ON hides linked vertex/face selection colors in Edge Select mode.'), default=False, update=_update_optimization_property)
    hide_blender_face_mode_linked_vertex_edge_overlay: BoolProperty(name=T("Face Mode: Hide Vertex/Edge"), description=T('ON hides linked vertex/edge selection colors in Face Select mode.'), default=False, update=_update_optimization_property)
    operator_identifier_display: StringProperty(name=T("Operator ID"), description=T("Manual shortcut operator ID for the Mesh and Curve Overlay toggle. Smart Overlay never registers this automatically; copy it into Preferences > Keymap > 3D View when you want a shortcut. (Do not modify the text)"), default="view3d.sos_toggle_overlay", update=_update_prefs)
    occluded_xray_toggle_operator_identifier_display: StringProperty(
        name=T("Occluded X-Ray Toggle Keymap ID"),
        description=T("Manual shortcut operator ID for the quick toggle that switches occluded overlays between \"X-Ray Only\" and \"Always\". Smart Overlay never registers this automatically; copy it into Preferences > Keymap > 3D View when you want a shortcut. Use Occluded Display Mode when you need \"Never\"."),
        default="view3d.sos_toggle_occluded_xray_only",
        update=_update_prefs,
    )


    # -------------------------------------------------------------------------
    # Edge anti-aliasing mode (applies to all edge overlays that currently use AA)
    # -------------------------------------------------------------------------
    edge_aa_mode: EnumProperty(
        name=T("Edge Anti-Aliasing"),
        description=T(
            "Switch anti-aliasing mode for edge overlays (Mesh and Curve Edge Overlay + Proportional Edge Overlay).\n"
            "Smooth (2-pass): best visual quality (draws edges twice).\n"
            "Built-in AA: uses GPU multisample/alpha-to-coverage when available (single draw).\n"
            "Off: disables add-on AA passes."
        ),
        items=[
            ('AA_2PASS', T("Smooth (2-pass)"), T("Best quality: draws an extra soft outer line under the main line (2 passes).")),
            ('AA_MSAA',  T("Built-in AA"),     T("Single pass: uses viewport MSAA / alpha-to-coverage if available. (No extra AA pass)")),
            ('AA_OFF',   T("No AA"),           T("No additional AA: draw edges as-is. (Fastest / sharpest)")),
        ],
        default='AA_2PASS',
        update=_update_prefs,
    )
    prop_overlay_vertex_size: IntProperty(name=T("Overlay Vertex Size(px)"), description=T("Pixel size of the proportional overlay points, including mesh vertices, curve control points, lattice points, UV points, and object origins."), default=4, min=1, max=50, update=_update_prefs)
    prop_overlay_edge_size: IntProperty(name=T("Overlay Edge Size(px)"), description=T("Pixel width of proportional overlay lines, including mesh edges, curve shape lines, lattice cage edges, and UV edges."), default=2, min=1, max=20, update=_update_prefs)
    prop_heatmap_xray: BoolProperty(name=T("Heatmap X-Ray"), description=T("Draw the proportional heatmap through 3D geometry instead of hiding parts that are behind the visible surface. This affects Mesh, Curve, Lattice, and Object Mode overlays; the UV editor overlay is drawn in 2D on top of the UV view."), default=True, update=_update_prefs)
    prop_heatmap_alpha: FloatProperty(name=T("Heatmap Opacity"), description=T("Opacity multiplier for the proportional heatmap points and lines. Lower values make the influence display softer; higher values keep the gradient easier to read on dense Mesh, Curve, Lattice, and UV layouts."), min=0.05, max=1.0, default=1.0, update=_update_prefs)
    prop_show_3d_view: BoolProperty(name=T("Use in 3D View"), description=T('When ON, the proportional editing heatmap is drawn in the 3D View for mesh, curve, lattice, and object proportional editing. Turn this OFF when you want to use it only in the UV Editor. Blender proportional editing and the Proportional Display toggle must also be enabled.'), default=True, update=_update_prefs)
    prop_show_uv_editor: BoolProperty(name=T("Use in UV Editor"), description=T('When ON, the proportional editing heatmap is drawn in the UV Editor while editing mesh UVs. The source selection is taken only from UV Editor UV selection, not from unrelated 3D View mesh selection. Turn this OFF when you want it only in the 3D View. Blender proportional editing and the Proportional Display toggle must also be enabled.'), default=True, update=_update_prop_uv_editor_display)
    prop_grad_color_0: FloatVectorProperty(name=T("Gradient Color 0%"), description=T("Heatmap color at 0% influence (outermost / weakest)."), subtype='COLOR', size=3, min=0.0, max=1.0, default=(0.0, 0.0, 1.0), update=_update_prop_heatmap_colors)
    prop_grad_color_25: FloatVectorProperty(name=T("Gradient Color 25%"), description=T("Heatmap color at 25% influence."), subtype='COLOR', size=3, min=0.0, max=1.0, default=(0.0, 1.0, 1.0), update=_update_prop_heatmap_colors)
    prop_grad_color_50: FloatVectorProperty(name=T("Gradient Color 50%"), description=T("Heatmap color at 50% influence (middle)."), subtype='COLOR', size=3, min=0.0, max=1.0, default=(0.0, 1.0, 0.0), update=_update_prop_heatmap_colors)
    prop_grad_color_75: FloatVectorProperty(name=T("Gradient Color 75%"), description=T("Heatmap color at 75% influence."), subtype='COLOR', size=3, min=0.0, max=1.0, default=(1.0, 1.0, 0.0), update=_update_prop_heatmap_colors)
    prop_grad_color_100: FloatVectorProperty(name=T("Gradient Color 100%"), description=T("Heatmap color at 100% influence (strongest / selected)."), subtype='COLOR', size=3, min=0.0, max=1.0, default=(1.0, 0.0, 0.0), update=_update_prop_heatmap_colors)
    prop_operator_identifier_display: StringProperty(name=T("Overlay Toggle Keymap ID"), description=T("Manual shortcut operator ID for the proportional overlay toggle. Smart Overlay never registers this automatically; copy it into Preferences > Keymap > 3D View when you want a shortcut."), default="view3d.sos_toggle_proportional_overlay", update=_update_prefs)
    prop_3d_view_operator_identifier_display: StringProperty(name=T("3D View Use Toggle Keymap ID"), description=T("Manual shortcut operator ID for toggling whether the proportional overlay is used in the 3D View. Copy this into Preferences > Keymap > 3D View when you want a shortcut."), default="view3d.sos_toggle_proportional_overlay_3d_view", update=_update_prefs)
    prop_uv_editor_operator_identifier_display: StringProperty(name=T("UV Editor Use Toggle Keymap ID"), description=T("Manual shortcut operator ID for toggling whether the proportional overlay is used in the UV Editor. Copy this into Preferences > Keymap > Image / UV Editor when you want a shortcut."), default="image.sos_toggle_proportional_overlay_uv_editor", update=_update_prefs)
    uv_overlay_operator_identifier_display: StringProperty(name=T("UV Overlay Toggle Keymap ID"), description=T("Manual shortcut operator ID for the UV overlay toggle. Smart Overlay never registers this automatically; copy it into Preferences > Keymap > Image / UV Editor when you want a shortcut."), default="image.sos_toggle_uv_overlay", update=_update_prefs)
    hover_operator_identifier_display: StringProperty(name=T("Hover Overlay Toggle Keymap ID"), description=T("Manual shortcut operator ID for the hover overlay toggle. Smart Overlay never registers this automatically; copy it into Preferences > Keymap > 3D View when you want a shortcut."), default="view3d.sos_toggle_hover_overlay", update=_update_prefs)
    integrated_tool_smart_measure_enabled: BoolProperty(
        name='Enabled',
        description=registry.tool_metadata('smart_measure').get('toggle_desc_en', ''),
        default=registry.tool_default_active('smart_measure'),
        update=_update_integrated_tool_enable,
    )
    integrated_tool_image_dimensions_viewer_enabled: BoolProperty(
        name='Enabled',
        description=registry.tool_metadata('image_dimensions_viewer').get('toggle_desc_en', ''),
        default=registry.tool_default_active('image_dimensions_viewer'),
        update=_update_integrated_tool_enable,
    )
    integrated_tool_silhouette_enabled: BoolProperty(
        name='Enabled',
        description=registry.tool_metadata('silhouette').get('toggle_desc_en', ''),
        default=registry.tool_default_active('silhouette'),
        update=_update_integrated_tool_enable,
    )

    def draw(self, context):
        return


_ORIGINAL_ADDON_PREFERENCES_DRAW = None


def _iter_addon_preferences_classes():
    yielded = set()
    for cls in (
        globals().get('SOS_AddonPreferences'),
        getattr(getattr(bpy, 'types', None), 'SOS_AddonPreferences', None),
    ):
        if not isinstance(cls, type):
            continue
        key = id(cls)
        if key in yielded:
            continue
        yielded.add(key)
        yield cls



def _empty_addon_preferences_draw(self, context):
    return None


def suppress_addon_preferences_ui():
    global _ORIGINAL_ADDON_PREFERENCES_DRAW
    for cls in _iter_addon_preferences_classes():
        try:
            draw_attr = getattr(cls, 'draw', None)
        except Exception:
            draw_attr = None
        if _ORIGINAL_ADDON_PREFERENCES_DRAW is None and callable(draw_attr):
            _ORIGINAL_ADDON_PREFERENCES_DRAW = draw_attr
        try:
            setattr(cls, 'draw', _empty_addon_preferences_draw)
        except Exception:
            pass



def restore_addon_preferences_ui():
    draw_attr = _ORIGINAL_ADDON_PREFERENCES_DRAW
    if draw_attr is None:
        return
    for cls in _iter_addon_preferences_classes():
        try:
            setattr(cls, 'draw', draw_attr)
        except Exception:
            pass


CLASSES = (
    SOS_PresetItem,
    SOS_MT_PresetMenu,
    SOS_AddonPreferences,
)
