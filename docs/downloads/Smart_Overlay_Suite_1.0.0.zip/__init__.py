# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

# Add-on bootstrap: Smart Overlay
# Format policy: metadata, ownership guard, runtime registration, runtime unregistration.

from __future__ import annotations

# Extension builds must not register top-level module aliases.  Blender 5.1
# validates that every imported add-on module stays under the extension package
# namespace (for example bl_ext.user_default.smart_overlay_suite).

import logging
import shutil
import sys
from pathlib import Path

import bpy


from bpy.app.handlers import persistent

_LOG = logging.getLogger(__name__)


def _purge_legacy_extension_namespace_and_folder() -> None:
    """Remove stale same-session modules/folders from obsolete temporary IDs.

    The extension ID is ``smart_overlay_suite`` so Blender creates the
    ``user_default/smart_overlay_suite`` folder.  Some temporary test builds used
    the shorter ID ``smart_overlay``.  If a failed install left that old folder
    or cached namespace package behind, Blender can abort with "module loaded
    with no associated file" when it tries to reload the old extension.  This
    cleanup removes only the obsolete temporary ID and never removes the active
    ``smart_overlay_suite`` package.
    """
    try:
        current = Path(__file__).resolve().parent
    except Exception:
        current = None

    active_package = str(__package__ or __name__ or '').strip().strip('.')
    protected_exact: set[str] = set()
    protected_prefix = active_package
    if active_package:
        parts = active_package.split('.')
        for index in range(1, len(parts)):
            protected_exact.add('.'.join(parts[:index]))
        protected_exact.add(active_package)

    stale_roots = (
        'bl_ext.user_default.smart_overlay',
        'smart_overlay',
        'smart_overlay_legacy',
        'smart_overlay_suite_legacy',
    )
    for mod_name in tuple(sys.modules):
        text = str(mod_name or '').strip()
        if not text:
            continue
        if text in protected_exact:
            continue
        if protected_prefix and text.startswith(protected_prefix + '.'):
            continue
        if any(text == root or text.startswith(root + '.') for root in stale_roots):
            try:
                sys.modules.pop(text, None)
            except Exception:
                pass

    try:
        if current is None:
            return
        obsolete = current.parent / 'smart_overlay'
        if not obsolete.exists() or obsolete.resolve() == current.resolve():
            return
        manifest = obsolete / 'blender_manifest.toml'
        manifest_text = ''
        try:
            manifest_text = manifest.read_text(encoding='utf-8', errors='ignore')
        except Exception:
            manifest_text = ''
        # Only touch the known temporary package id. Do not remove arbitrary folders.
        if manifest.exists() and 'id = "smart_overlay"' not in manifest_text:
            return
        try:
            old_data = obsolete / 'user_data'
            new_data = current / 'user_data'
            if old_data.exists() and not new_data.exists():
                shutil.copytree(old_data, new_data, dirs_exist_ok=True)
        except Exception:
            pass
        shutil.rmtree(obsolete, ignore_errors=True)
    except Exception:
        pass


try:
    _purge_legacy_extension_namespace_and_folder()
except Exception:
    pass


from . import addon_runtime as _addon_runtime
def _safe_boot_desired_enabled(default: bool = True) -> bool:
    return bool(default)


def _safe_boot_preflight_cleanup(addon_runtime_module, package_name, module_name, module_file):
    if addon_runtime_module is None:
        return None
    try:
        if not _safe_boot_desired_enabled(True):
            return None
    except Exception:
        pass
    try:
        return addon_runtime_module.preflight_cleanup(package_name, module_name, module_file)
    except TypeError:
        try:
            return addon_runtime_module.preflight_cleanup(package_name, module_name, module_file, force=False)
        except Exception:
            return None
    except Exception:
        return None


bl_info = {
    "name": 'Smart Overlay',
    "author": 'JELararagi',
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "location": "Supported editor Sidebar > Smart Overlay",
    "description": "Smart Overlay exposes its settings in supported Blender editor Sidebar N-panel categories named Smart Overlay.",
    "category": 'Smart Overlay',
}


# ------------------------------------------------------------------------------
# Duplicate-registration guard:
# If both an old wrapped package and this flattened package are installed,
# only the first one that registers becomes the active owner to avoid
# duplicate keymaps, handlers, and UI registrations.
# ------------------------------------------------------------------------------
def _sos_get_owner():
    try:
        return bpy.app.driver_namespace.get("SMART_OVERLAY_SUITE_OWNER")
    except Exception:
        return None


def _sos_owner_is_live(owner) -> bool:
    text = str(owner or '').strip()
    if not text:
        return False
    if text == __package__:
        return True
    module = sys.modules.get(text)
    if module is None:
        return False
    try:
        if not bool(getattr(module, '_REGISTERED', False)):
            return False
    except Exception:
        return False

    try:
        panel_classes = tuple(getattr(ui, 'CLASSES', ()) or ())
    except Exception:
        panel_classes = ()
    expected = []
    for cls in panel_classes:
        if isinstance(cls, type):
            try:
                if issubclass(cls, bpy.types.Panel) and str(getattr(cls, 'bl_category', '') or '') == 'Smart Overlay':
                    expected.append(cls)
            except Exception:
                pass
    if not expected:
        expected = [getattr(ui, 'VIEW3D_PT_sos_root', None)]

    for cls in expected:
        if not isinstance(cls, type):
            continue
        try:
            live = getattr(bpy.types, getattr(cls, '__name__', ''), None)
            if live is cls:
                return True
        except Exception:
            pass
    # Do not evaluate Panel.poll() here.  In Blender 5.1 the current context can
    # transiently contain no active object during deselect/mode-switch handling.
    # Treating that as an unregistered owner can trigger duplicate registration
    # while ui_handler_panel is still processing the old panel tree.
    return False


def _sos_set_owner(owner):
    try:
        bpy.app.driver_namespace["SMART_OVERLAY_SUITE_OWNER"] = owner
    except Exception:
        pass



def _sos_clear_owner(owner):
    try:
        ns = bpy.app.driver_namespace
        if ns.get("SMART_OVERLAY_SUITE_OWNER") == owner:
            ns.pop("SMART_OVERLAY_SUITE_OWNER", None)
    except Exception:
        pass


def _sos_current_panel_owner_id() -> str:
    try:
        from . import common as _sos_common
        fn = getattr(_sos_common, 'current_addon_owner_id', None)
        if callable(fn):
            value = str(fn() or '').strip()
            if value:
                return value
    except Exception:
        pass
    return str(__package__ or 'smart_overlay_suite').strip() or 'smart_overlay_suite'


def _sos_apply_panel_owner_id(cls) -> None:
    try:
        if isinstance(cls, type) and issubclass(cls, bpy.types.Panel):
            setattr(cls, 'bl_owner_id', _sos_current_panel_owner_id())
    except Exception:
        pass



def _sos_workspace_filter_allows_addon(context=None) -> bool:
    try:
        from . import common as _sos_common
        fn = getattr(_sos_common, 'workspace_filter_allows_addon', None)
        if callable(fn):
            return bool(fn(context))
    except Exception:
        pass
    return True


def _sos_workspace_filter_allows_cross_editor_runtime(context=None) -> bool:
    try:
        from . import common as _sos_common
        fn = getattr(_sos_common, 'workspace_filter_allows_addon_runtime', None)
        if callable(fn):
            return bool(fn(context, cross_editor=True))
    except Exception:
        pass
    return _sos_workspace_filter_allows_addon(context)


def _sos_sync_manager_workspace_filter(context=None) -> None:
    try:
        from . import common as _sos_common
        fn = getattr(_sos_common, 'sync_smart_tools_manager_workspace_owner_filter', None)
        if callable(fn):
            fn(context or getattr(bpy, 'context', None))
    except Exception:
        pass


def _sos_can_register():
    owner = _sos_get_owner()
    if owner and owner != __package__:
        if _sos_owner_is_live(owner):
            return False
        _sos_clear_owner(owner)
        owner = None
    if not owner:
        _sos_set_owner(__package__)
    return True


# Remove stale legacy files and previously-loaded legacy modules as early as
# possible. The flattened extension build must stay inside the package
# namespace only, so older top-level compatibility modules are removed instead
# of being reintroduced as aliases.
try:
    _safe_boot_preflight_cleanup(_addon_runtime, __package__, __name__, __file__)
except Exception:
    pass


def _purge_forbidden_top_level_modules() -> None:
    """Compatibility no-op.

    A Suite must not infer ownership from a top-level module name and remove a
    foreign module from ``sys.modules``.  Package-qualified loading is enforced
    by the Extension layout; exact-owned modules are released by their normal
    register/unregister paths.
    """
    return None


try:
    _purge_forbidden_top_level_modules()
except Exception:
    pass



def _prime_preferences_state(context=None):
    prefs = None
    try:
        getter = getattr(_addon_runtime, 'get_addon_preferences', None)
        if callable(getter):
            prefs = getter(context, __package__, __name__, __file__)
    except Exception:
        prefs = None
    if prefs is None:
        try:
            prefs = integrated_registry.resolve_addon_preferences(context)
        except Exception:
            prefs = None

    if prefs is None:
        return None

    for attr_name in (
        'active_preset_id',
        'saved_mesh_overlay_addon_runtime_enabled',
        'saved_proportional_overlay_addon_runtime_enabled',
        'saved_uv_hover_overlay_addon_runtime_enabled',
        'saved_object_hover_overlay_addon_runtime_enabled',
        'use_scene_overrides',
        'include_geometry_nodes_objects',
        'include_curve_shape_overlay',
        'include_lattice_objects',
        'use_evaluated_edit_mode_face_overlay',
        'use_select_mode_vertex_center_overlay',
    ):
        try:
            getattr(prefs, attr_name)
        except Exception:
            pass
    return prefs


_SOS_REPAIR_TIMER_ATTEMPTS = 0


def _sos_addon_runtime_repair_timer():
    global _SOS_REPAIR_TIMER_ATTEMPTS
    try:
        _sos_repair_addon_runtime(bpy.context)
    except Exception:
        pass

    _SOS_REPAIR_TIMER_ATTEMPTS -= 1
    if _SOS_REPAIR_TIMER_ATTEMPTS > 0:
        return 0.25
    return None



def _schedule_addon_runtime_repair(attempts: int = 1) -> None:
    global _SOS_REPAIR_TIMER_ATTEMPTS
    _SOS_REPAIR_TIMER_ATTEMPTS = max(int(attempts), int(_SOS_REPAIR_TIMER_ATTEMPTS), 0)
    try:
        if not bpy.app.timers.is_registered(_sos_addon_runtime_repair_timer):
            bpy.app.timers.register(_sos_addon_runtime_repair_timer, first_interval=0.05)
    except Exception:
        pass


# Safe import order to avoid circular imports.
import importlib as _safe_lazy_importlib


class _SUITE_LazyModuleProxy:
    __slots__ = ('_alias', '_relative_name')

    def __init__(self, alias: str, relative_name: str):
        self._alias = str(alias or '').strip()
        self._relative_name = str(relative_name or '').strip().strip('.')

    def _load(self):
        current = globals().get(self._alias)
        if not isinstance(current, _SUITE_LazyModuleProxy):
            return current
        module = _safe_lazy_importlib.import_module(f"{__package__}.{self._relative_name}")
        globals()[self._alias] = module
        return module

    def __getattr__(self, name):
        return getattr(self._load(), name)

    def __dir__(self):
        try:
            return dir(self._load())
        except Exception:
            return []


def _safe_lazy_module_proxy(alias: str, relative_name: str):
    return _SUITE_LazyModuleProxy(alias, relative_name)


translation = _safe_lazy_module_proxy('translation', 'translation')
preferences = _safe_lazy_module_proxy('preferences', 'preferences')
operators = _safe_lazy_module_proxy('operators', 'operators')
mesh = _safe_lazy_module_proxy('mesh', 'mesh')
properties = _safe_lazy_module_proxy('properties', 'properties')
uv = _safe_lazy_module_proxy('uv', 'uv')
high_precision_outline = _safe_lazy_module_proxy('high_precision_outline', 'high_precision_outline')
ui = _safe_lazy_module_proxy('ui', 'ui')
integrated_addon_runtime = _safe_lazy_module_proxy('integrated_addon_runtime', 'addon_runtime')
integrated_registry = _safe_lazy_module_proxy('integrated_registry', 'registry')
workspace_tool_safety = _safe_lazy_module_proxy('workspace_tool_safety', 'workspace_tool_safety')
settings = _safe_lazy_module_proxy('settings', 'settings')
help = _safe_lazy_module_proxy('help', 'help')
icons = _safe_lazy_module_proxy('icons', 'icons')


_ROOT_PACKAGE = (__package__ or __name__ or '').strip()

_CLASSES = None


def _sos_classes():
    global _CLASSES
    if isinstance(_CLASSES, tuple):
        return _CLASSES
    _CLASSES = (
        *getattr(preferences, 'CLASSES', (preferences.SOS_PresetItem, preferences.SOS_AddonPreferences)),
        operators.SOS_OT_SetAlwaysOnRuntimeToggle,
        operators.SOS_OT_ToggleProportionalOverlay,
        operators.SOS_OT_ToggleProportionalOverlay3DViewUse,
        operators.SOS_OT_ToggleProportionalOverlayUVEditorUse,
        operators.SOS_OT_ToggleHoverOverlay,
        operators.SOS_OT_ToggleOccludedXRayOnly,
        operators.SOS_OT_ToggleUVHoverOverlay,
        operators.SOS_OT_ToggleUVOverlayImageEditor,
        operators.SOS_OT_ToggleObjectHoverOverlay,
        operators.SOS_OT_ResetSettings,
        operators.SOS_OT_SelectPreset,
        operators.SOS_OT_ApplyPreset,
        operators.SOS_OT_SavePreset,
        operators.SOS_OT_DeletePreset,
        operators.SOS_OT_SceneSave,
        operators.SOS_OT_SceneLoad,
        operators.SOS_OT_SceneClear,
        *getattr(mesh, 'CLASSES', ()),
        *getattr(uv, 'CLASSES', ()),
        *getattr(help, 'CLASSES', ()),
        *getattr(ui, 'CLASSES', ()),
    )
    return _CLASSES

_REGISTERED = False
_REGISTER_WARNINGS: list[str] = []
_REFRESH_TIMERS: set[object] = set()
_REFRESH_GENERATION = 0
_CORE_RUNTIME_STATE = {
    'mesh': False,
    'prop': False,
    'uv': False,
}

# Event-driven UI/runtime repair.  The former root-panel, liveness and Manager
# wrapper watchdogs were periodic timers.  This state coalesces only real Blender
# events into one bounded one-shot repair and leaves stable idle sessions with no
# Smart Overlay timer callbacks.
_SOS_EVENT_REPAIR_MSGBUS_OWNER = object()
_SOS_EVENT_REPAIR_PENDING = False
_SOS_EVENT_REPAIR_SERIAL = 0
_SOS_EVENT_REPAIR_REASON = ''
_SOS_EVENT_REPAIR_MAX_ATTEMPTS = 4
_SOS_EVENT_HANDLERS_REGISTERED = False

_SOS_ADDON_KEY = 'smart_overlay_suite'



def _sos_wrap_panel_draw_safely(cls):
    """Wrap Panel.draw before registration so Python errors cannot break layout.

    This wrapper is installed before bpy.utils.register_class(). It does not
    change panel identity or theme/UI transparency and it avoids the unsafe
    pattern of replacing draw callbacks after registration.
    """
    try:
        panel_base = getattr(bpy.types, 'Panel', None)
        if panel_base is None or not isinstance(cls, type) or not issubclass(cls, panel_base):
            return cls
    except Exception:
        return cls
    def _draw_signature_is_exact(draw_func):
        try:
            code = getattr(draw_func, '__code__', None)
            if code is None or int(getattr(code, 'co_argcount', -1)) != 2:
                return False
            if getattr(draw_func, '__defaults__', None):
                return False
            if getattr(draw_func, '__kwdefaults__', None):
                return False
            return True
        except Exception:
            return False

    try:
        if getattr(cls, '_sos_safe_draw_wrapped', False) and _draw_signature_is_exact(getattr(cls, 'draw', None)):
            return cls
    except Exception:
        pass
    original_draw = getattr(cls, 'draw', None)
    if not callable(original_draw):
        return cls
    class_name = str(getattr(cls, '__name__', 'Panel'))

    def _make_sos_safe_draw(_orig_draw, _cls_name):
        # Blender validates Panel.draw with the exact public signature
        # ``draw(self, context)``.  Do not add closure data as default
        # arguments here; Blender 5.1 rejects those as extra args.
        def _sos_safe_draw(self, context):
            try:
                return _orig_draw(self, context)
            except Exception as exc:
                try:
                    layout = getattr(self, 'layout', None)
                    if layout is not None:
                        box = layout.box()
                        try:
                            msg = integrated_registry.localized(
                                'Smart Overlay panel draw was skipped safely.',
                                'Smart Overlay パネルの描画を安全にスキップしました。',
                                context,
                            )
                        except Exception:
                            msg = 'Smart Overlay panel draw was skipped safely.'
                        box.label(text=msg, icon='ERROR')
                        box.label(text=str(_cls_name))
                        detail = str(exc or '')[:180]
                        if detail:
                            box.label(text=detail)
                except Exception:
                    pass
                return None
        return _sos_safe_draw

    try:
        cls.draw = _make_sos_safe_draw(original_draw, class_name)
        cls._sos_safe_draw_wrapped = True
    except Exception:
        pass
    return cls


def _sos_class_receipts() -> list:
    key = 'SMART_OVERLAY_SUITE_CLASS_RECEIPTS_V1'
    try:
        ns = bpy.app.driver_namespace
        receipts = ns.get(key)
        if not isinstance(receipts, list):
            receipts = []
            ns[key] = receipts
        return receipts
    except Exception:
        return []


def _sos_record_class_receipt(cls) -> None:
    receipts = _sos_class_receipts()
    if receipts is not None and not any(item is cls for item in receipts):
        receipts.append(cls)


def _sos_drop_class_receipt(cls) -> None:
    key = 'SMART_OVERLAY_SUITE_CLASS_RECEIPTS_V1'
    try:
        ns = bpy.app.driver_namespace
        receipts = ns.get(key)
        if not isinstance(receipts, list):
            return
        receipts[:] = [item for item in receipts if item is not cls]
        if not receipts:
            ns.pop(key, None)
    except Exception:
        pass


def _sos_class_is_suite_owned_for_registration(cls) -> bool:
    if not isinstance(cls, type):
        return False
    try:
        return any(item is cls for item in _sos_class_receipts())
    except Exception:
        return False


def _safe_register_class(cls):
    cls = _sos_wrap_panel_draw_safely(cls)
    try:
        setattr(cls, '_sos_suite_id', 'smart_overlay_suite')
    except Exception:
        pass
    try:
        from . import undo_support
        undo_support.prepare_operator_class(cls)
    except Exception:
        pass
    try:
        if bool(getattr(cls, 'is_registered', False)):
            _sos_record_class_receipt(cls)
            return True
    except Exception:
        pass
    existing = getattr(bpy.types, getattr(cls, '__name__', ''), None)
    if existing is cls:
        _sos_record_class_receipt(cls)
        return True
    if isinstance(existing, type):
        if not _sos_class_is_suite_owned_for_registration(existing):
            return False
        try:
            bpy.utils.unregister_class(existing)
        except Exception:
            return False
    try:
        bpy.utils.register_class(cls)
        _sos_record_class_receipt(cls)
        return True
    except RuntimeError as exc:
        if 'already registered' not in str(exc):
            raise
        existing = getattr(bpy.types, getattr(cls, '__name__', ''), None)
        if existing is cls:
            return True
        if not _sos_class_is_suite_owned_for_registration(existing):
            return False
        try:
            bpy.utils.unregister_class(existing)
        except Exception:
            return False
        bpy.utils.register_class(cls)
        _sos_record_class_receipt(cls)
        return True



def _safe_unregister_class(cls):
    target = getattr(bpy.types, getattr(cls, '__name__', ''), None)
    if target is cls:
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            return False
        _sos_drop_class_receipt(cls)
        return True
    # A different class at the same public name is foreign or a newer
    # generation.  Never remove it by name.  If our exact native identity is
    # already absent, its receipt can be retired idempotently.
    if isinstance(target, type):
        _sos_drop_class_receipt(cls)
        return False
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass
    _sos_drop_class_receipt(cls)
    return True


def _record_register_warning(label: str, exc: BaseException) -> None:
    try:
        name = str(label or '').strip() or 'unknown'
        message = f'{name}: {type(exc).__name__}: {exc}'
    except Exception:
        message = 'unknown registration warning'
    try:
        _REGISTER_WARNINGS.append(message)
    except Exception:
        pass
    try:
        _LOG.warning('Smart Overlay registration warning: %s', message)
    except Exception:
        pass


def _register_class_nonfatal(cls, registered_classes=None) -> bool:
    try:
        if not bool(_safe_register_class(cls)):
            return False
    except Exception as exc:
        _record_register_warning(getattr(cls, '__name__', repr(cls)), exc)
        return False
    if registered_classes is not None and cls not in registered_classes:
        try:
            registered_classes.append(cls)
        except Exception:
            pass
    return True


def _register_smart_overlay_ui_classes(registered_classes=None) -> bool:
    """Register the visible Smart Overlay N-panel independently of heavy runtime setup."""
    ok = False
    for cls in _sos_ui_classes():
        if _register_class_nonfatal(cls, registered_classes):
            ok = True
    try:
        ok = _ensure_smart_overlay_root_panel_registered(getattr(bpy, 'context', None), force_refresh=False) or ok
    except Exception as exc:
        _record_register_warning('VIEW3D_PT_sos_root', exc)
    try:
        _tag_view3d_sidebar_redraw(getattr(bpy, 'context', None))
    except Exception:
        pass
    return bool(ok)



def _clear_refresh_timers() -> None:
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    for timer_fn in list(_REFRESH_TIMERS):
        try:
            if timers is not None and timers.is_registered(timer_fn):
                timers.unregister(timer_fn)
        except Exception:
            pass
        try:
            _REFRESH_TIMERS.discard(timer_fn)
        except Exception:
            pass



def _append_load_pre_handler_once(handler) -> None:
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    load_pre = getattr(handlers, 'load_pre', None)
    if load_pre is None:
        return
    if handler not in load_pre:
        load_pre.append(handler)


def _remove_load_pre_handler(handler) -> None:
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    load_pre = getattr(handlers, 'load_pre', None)
    if load_pre is None:
        return
    if handler in load_pre:
        try:
            load_pre.remove(handler)
        except Exception:
            pass


def _append_load_post_handler_once(handler) -> None:
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    load_post = getattr(handlers, 'load_post', None)
    if load_post is None:
        return
    if handler not in load_post:
        load_post.append(handler)



def _remove_load_post_handler(handler) -> None:
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    load_post = getattr(handlers, 'load_post', None)
    if load_post is None:
        return
    if handler in load_post:
        try:
            load_post.remove(handler)
        except Exception:
            pass





def _mesh_addon_runtime_needs_repair(context=None) -> bool:
    mesh_enabled, _prop_enabled, _uv_enabled = _desired_core_addon_runtime_states(context)
    handlers = getattr(getattr(getattr(bpy, 'app', None), 'handlers', None), 'depsgraph_update_post', None)
    handler_present = handlers is not None and getattr(mesh, '_sos_depsgraph_update', None) in handlers
    draw_handle = getattr(mesh, '_draw_handler', None)
    if mesh_enabled:
        try:
            unhealthy = bool(getattr(mesh, '_sos_mesh_curve_overlay_runtime_unhealthy', lambda _ctx=None: False)(context))
        except Exception:
            unhealthy = True
        try:
            runtime_registered = bool(getattr(mesh, '_sos_runtime_registered', False))
        except Exception:
            runtime_registered = False
        return (not runtime_registered) or draw_handle is None or not handler_present or unhealthy
    return draw_handle is not None or handler_present


def _prop_addon_runtime_needs_repair(context=None) -> bool:
    _mesh_enabled, prop_enabled, _uv_enabled = _desired_core_addon_runtime_states(context)
    handlers = getattr(getattr(getattr(bpy, 'app', None), 'handlers', None), 'depsgraph_update_post', None)
    handler_present = handlers is not None and getattr(properties, 'prop_depsgraph_update_handler', None) in handlers
    draw_handle = getattr(properties, '_draw_handler_prop', None)
    uv_draw_handle = getattr(properties, '_draw_handler_prop_uv', None)
    try:
        runtime_registered = bool(getattr(properties, '_prop_runtime_registered', False))
    except Exception:
        runtime_registered = False
    try:
        draw_errors = int(getattr(properties, '_prop_draw_exception_count', 0) or 0)
    except Exception:
        draw_errors = 0
    if prop_enabled:
        return (not runtime_registered) or draw_handle is None or uv_draw_handle is None or not handler_present or draw_errors > 0
    return draw_handle is not None or uv_draw_handle is not None or handler_present or runtime_registered


def _uv_addon_runtime_needs_repair(context=None) -> bool:
    _mesh_enabled, _prop_enabled, uv_enabled = _desired_core_addon_runtime_states(context)
    uv_state = getattr(uv, '_state', None)
    draw_handle = getattr(uv_state, 'draw_handle', None)
    try:
        runtime_registered = bool(getattr(uv_state, 'runtime_registered', False))
    except Exception:
        runtime_registered = False
    try:
        is_running = bool(getattr(uv_state, 'is_running', False))
    except Exception:
        is_running = False
    try:
        draw_errors = int(getattr(uv_state, 'draw_exception_count', 0) or 0)
    except Exception:
        draw_errors = 0
    if uv_enabled:
        return (not runtime_registered) or (not is_running) or draw_handle is None or draw_errors > 0
    return draw_handle is not None or runtime_registered


def _core_addon_runtime_needs_repair(context=None) -> bool:
    mesh_enabled, prop_enabled, uv_enabled = _desired_core_addon_runtime_states(context)
    if _CORE_RUNTIME_STATE.get('mesh') != mesh_enabled:
        return True
    if _CORE_RUNTIME_STATE.get('prop') != prop_enabled:
        return True
    if _CORE_RUNTIME_STATE.get('uv') != uv_enabled:
        return True
    return _mesh_addon_runtime_needs_repair(context) or _prop_addon_runtime_needs_repair(context) or _uv_addon_runtime_needs_repair(context)


def _sos_addon_runtime_refresh_needed(context=None) -> bool:
    del context
    return False


def _sos_addon_runtime_followup_needed(context=None) -> bool:
    return _core_addon_runtime_needs_repair(context)


_RUNTIME_PREF_LINKS = (
    ('sos_enabled', 'saved_mesh_overlay_addon_runtime_enabled', False),
    ('sos_proportional_overlay_enabled', 'saved_proportional_overlay_addon_runtime_enabled', False),
    ('sos_uv_overlay_enabled', 'saved_uv_hover_overlay_addon_runtime_enabled', False),
    ('sos_object_hover_overlay_enabled', 'saved_object_hover_overlay_addon_runtime_enabled', False),
)

_RUNTIME_PREF_SYNC_LOCK = 0


def _addon_runtime_pref_sync_active() -> bool:
    return bool(_RUNTIME_PREF_SYNC_LOCK > 0)


def _settings_applying() -> bool:
    try:
        return bool(settings.is_applying())
    except Exception:
        return False


def _queue_settings_save(context=None) -> None:
    try:
        settings.queue_save(context)
    except Exception:
        pass


def _clear_smart_measure_grid_active_areas() -> None:
    try:
        for scene in getattr(bpy.data, 'scenes', ()) or ():
            settings = getattr(scene, 'smart_measure_grid', None)
            if settings is not None and hasattr(settings, 'active_areas'):
                settings.active_areas = ''
    except Exception:
        pass


def _iter_view3d_screen_areas(context=None):
    ctx = context or getattr(bpy, 'context', None)
    seen = set()
    try:
        wm = getattr(ctx, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            scene = getattr(window, 'scene', None) or getattr(ctx, 'scene', None)
            for area in getattr(screen, 'areas', ()) or ():
                if getattr(area, 'type', None) == 'VIEW_3D':
                    key = int(getattr(area, 'as_pointer', lambda: id(area))())
                    if key not in seen:
                        seen.add(key)
                        yield scene, area
    except Exception:
        pass
    try:
        screen = getattr(ctx, 'screen', None)
        scene = getattr(ctx, 'scene', None)
        for area in getattr(screen, 'areas', ()) or ():
            if getattr(area, 'type', None) == 'VIEW_3D':
                key = int(getattr(area, 'as_pointer', lambda: id(area))())
                if key not in seen:
                    seen.add(key)
                    yield scene, area
    except Exception:
        pass



def _sync_smart_measure_addon_runtime(context=None) -> None:
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None)
    enabled = bool(getattr(wm, 'smart_measure_run_opengl', False)) if wm is not None else False
    try:
        from . import smart_measure as smart_measure_pkg
        from .smart_measure import smart_measure_main
    except Exception:
        return

    try:
        op_cls = getattr(smart_measure_main, 'SMART_MEASURE_OT_RunHintDisplay', None)
        handle = getattr(op_cls, '_handle', None) if op_cls is not None else None
        if enabled:
            try:
                smart_measure_main.register_addon_runtime_support()
            except Exception:
                pass
            if op_cls is not None and handle is None:
                area = getattr(ctx, 'area', None)
                if area is not None and getattr(area, 'type', None) == 'VIEW_3D':
                    op_cls.handle_add(None, ctx)
                else:
                    for _scene, view_area in _iter_view3d_screen_areas(ctx):
                        try:
                            region = next((r for r in getattr(view_area, 'regions', ()) if getattr(r, 'type', None) == 'WINDOW'), None)
                            if region is None:
                                continue
                            if hasattr(ctx, 'temp_override'):
                                with ctx.temp_override(area=view_area, region=region):
                                    op_cls.handle_add(None, ctx)
                            else:
                                op_cls.handle_add(None, ctx)
                            break
                        except Exception:
                            continue
        else:
            if op_cls is not None and handle is not None:
                op_cls.handle_remove(None, ctx)
            try:
                smart_measure_main.unregister_addon_runtime_support()
            except Exception:
                pass
    except Exception:
        pass

    try:
        sync_grid = getattr(smart_measure_pkg, 'sync_grid_runtime', None)
        if callable(sync_grid):
            sync_grid(ctx, enabled)
    except Exception:
        pass


def _sync_image_dimensions_addon_runtime(context=None) -> None:
    """Sync the already-loaded integrated Image Dimensions module only.

    The loader owns the registered module instance. Importing the package path
    again after an in-place loader refresh can create a second, unregistered
    module with separate draw handles and snapshot state.
    """
    try:
        from . import loader as integrated_loader
        record = integrated_loader.find_record('image_dimensions_viewer')
        module = record.get('module') if isinstance(record, dict) else None
        sync = getattr(module, '_sync_addon_runtime_handlers', None) if module is not None else None
        if callable(sync):
            sync()
    except Exception:
        pass


def _sync_silhouette_addon_runtime(context=None) -> None:
    ctx = context or getattr(bpy, 'context', None)
    scene = getattr(ctx, 'scene', None)
    if scene is None:
        return
    try:
        from . import silhouette
        if bool(getattr(scene, 'silhouette_enabled', False)):
            sid = scene.as_pointer()
            snap_map = getattr(silhouette, '_VIEW_SNAP', {})
            if isinstance(snap_map, dict) and sid not in snap_map:
                snapshot = getattr(silhouette, '_snapshot_viewport', None)
                if callable(snapshot):
                    snap_map[sid] = snapshot(ctx)
            apply_fn = getattr(silhouette, '_apply_silhouette', None)
            if callable(apply_fn):
                apply_fn(ctx)
    except Exception:
        pass


def _sync_explicit_addon_runtime_toggles(context=None) -> None:
    _sync_smart_measure_addon_runtime(context)
    _sync_image_dimensions_addon_runtime(context)
    _sync_silhouette_addon_runtime(context)
    try:
        high_precision_outline.sync_runtime(context or getattr(bpy, 'context', None))
    except Exception:
        pass


def _apply_requested_baseline_recovery(prefs=None, context=None) -> None:
    """Apply only the exact persisted regressions named by the user."""
    ctx = context or getattr(bpy, 'context', None)
    changed = False
    for name in (
        'migrate_occluded_color_visible_default_v1',
        'migrate_occluded_color_working_defaults_v2',
        'migrate_occluded_color_working_defaults_v3',
        'repair_frozen_grayscale_prop_heatmap_palette',
        'migrate_prop_heatmap_original_palette_v2',
        'migrate_high_precision_outline_working_defaults_v2',
    ):
        try:
            repair = getattr(preferences, name, None)
            if callable(repair):
                changed = bool(repair(prefs, ctx)) or changed
        except Exception:
            pass
    return changed


def _remember_addon_runtime_toggle_state(context=None, *, wm=None, only_attr: str | None = None) -> None:
    ctx = context or getattr(bpy, 'context', None)
    owner = wm or getattr(ctx, 'window_manager', None)
    if owner is None:
        return

    try:
        prefs = integrated_registry.resolve_addon_preferences(ctx)
    except Exception:
        prefs = None
    if prefs is None:
        return

    for wm_attr, pref_attr, default_value in _RUNTIME_PREF_LINKS:
        if only_attr and wm_attr != only_attr:
            continue
        if not hasattr(prefs, pref_attr):
            continue
        try:
            value = bool(getattr(owner, wm_attr, default_value))
        except Exception:
            value = bool(default_value)
        try:
            current = bool(getattr(prefs, pref_attr, default_value))
        except Exception:
            current = (not value)
        if current != value:
            try:
                setattr(prefs, pref_attr, value)
            except Exception:
                pass


def _restore_addon_runtime_toggle_state_from_prefs(context=None, *, prefs=None) -> None:
    global _RUNTIME_PREF_SYNC_LOCK

    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None)
    if wm is None:
        return

    pref_obj = prefs
    if pref_obj is None:
        try:
            pref_obj = integrated_registry.resolve_addon_preferences(ctx)
        except Exception:
            pref_obj = None
    if pref_obj is None:
        return

    _RUNTIME_PREF_SYNC_LOCK += 1
    try:
        for wm_attr, pref_attr, default_value in _RUNTIME_PREF_LINKS:
            if not hasattr(pref_obj, pref_attr):
                continue
            try:
                target_value = bool(getattr(pref_obj, pref_attr, default_value))
            except Exception:
                target_value = bool(default_value)
            try:
                keys = wm.keys() if hasattr(wm, 'keys') else ()
            except Exception:
                keys = ()
            try:
                current_value = bool(getattr(wm, wm_attr, default_value))
            except Exception:
                current_value = (not target_value)
            if (wm_attr not in keys) or current_value != target_value:
                try:
                    setattr(wm, wm_attr, target_value)
                except Exception:
                    pass
    finally:
        _RUNTIME_PREF_SYNC_LOCK = max(0, _RUNTIME_PREF_SYNC_LOCK - 1)


_RUNTIME_SYNC_TIMER_FORCE = False
_SMART_MEASURE_SYNC_TIMER_REGISTERED = False
_RUNTIME_SCHEDULERS_ENABLED = False
_RUNTIME_SYNC_CONTEXT_HINT = {
    'window_ptr': 0,
    'screen_ptr': 0,
    'area_ptr': 0,
    'region_ptr': 0,
}


def _sos_runtime_pointer(value) -> int:
    try:
        return int(value.as_pointer()) if value is not None else 0
    except Exception:
        return 0


def _sos_iter_live_window_managers(context=None):
    seen = set()
    candidates = []
    for ctx in (context, getattr(bpy, 'context', None)):
        try:
            wm = getattr(ctx, 'window_manager', None)
            if wm is not None:
                candidates.append(wm)
        except Exception:
            pass
    try:
        candidates.extend(tuple(getattr(bpy.data, 'window_managers', ()) or ()))
    except Exception:
        pass
    for wm in candidates:
        ptr = _sos_runtime_pointer(wm)
        if not ptr or ptr in seen:
            continue
        seen.add(ptr)
        yield wm


def _sos_iter_live_windows(context=None):
    ctx = context or getattr(bpy, 'context', None)
    preferred = getattr(ctx, 'window', None) if ctx is not None else None
    seen = set()
    if preferred is not None:
        ptr = _sos_runtime_pointer(preferred)
        if ptr:
            seen.add(ptr)
            yield preferred
    for wm in _sos_iter_live_window_managers(ctx):
        for window in tuple(getattr(wm, 'windows', ()) or ()):
            ptr = _sos_runtime_pointer(window)
            if not ptr or ptr in seen:
                continue
            seen.add(ptr)
            yield window


def _sos_capture_runtime_sync_context(context=None) -> None:
    global _RUNTIME_SYNC_CONTEXT_HINT
    ctx = context or getattr(bpy, 'context', None)
    try:
        _RUNTIME_SYNC_CONTEXT_HINT = {
            'window_ptr': _sos_runtime_pointer(getattr(ctx, 'window', None)),
            'screen_ptr': _sos_runtime_pointer(getattr(ctx, 'screen', None)),
            'area_ptr': _sos_runtime_pointer(getattr(ctx, 'area', None)),
            'region_ptr': _sos_runtime_pointer(getattr(ctx, 'region', None)),
        }
    except Exception:
        _RUNTIME_SYNC_CONTEXT_HINT = {'window_ptr': 0, 'screen_ptr': 0, 'area_ptr': 0, 'region_ptr': 0}


def _sos_runtime_sync_override():
    """Resolve the UI context that requested the deferred runtime change."""
    hint = dict(_RUNTIME_SYNC_CONTEXT_HINT or {})
    windows = tuple(_sos_iter_live_windows(getattr(bpy, 'context', None)))
    wanted_window = int(hint.get('window_ptr', 0) or 0)
    if wanted_window:
        windows = tuple(sorted(windows, key=lambda win: 0 if _sos_runtime_pointer(win) == wanted_window else 1))
    for window in windows:
        screen = getattr(window, 'screen', None)
        if screen is None:
            continue
        override = {'window': window, 'screen': screen}
        wanted_area = int(hint.get('area_ptr', 0) or 0)
        wanted_region = int(hint.get('region_ptr', 0) or 0)
        area = None
        if wanted_area:
            area = next((item for item in tuple(getattr(screen, 'areas', ()) or ()) if _sos_runtime_pointer(item) == wanted_area), None)
        if area is not None:
            override['area'] = area
            space = getattr(getattr(area, 'spaces', None), 'active', None)
            if space is not None:
                override['space_data'] = space
            region = None
            if wanted_region:
                region = next((item for item in tuple(getattr(area, 'regions', ()) or ()) if _sos_runtime_pointer(item) == wanted_region), None)
            if region is None:
                region = next((item for item in tuple(getattr(area, 'regions', ()) or ()) if getattr(item, 'type', None) == 'WINDOW'), None)
            if region is not None:
                override['region'] = region
        return override
    return None


def _cancel_deferred_runtime_sync_timers() -> None:
    """Cancel only Smart Overlay finite runtime-sync callbacks."""
    global _RUNTIME_SYNC_TIMER_FORCE, _SMART_MEASURE_SYNC_TIMER_REGISTERED
    _RUNTIME_SYNC_TIMER_FORCE = False
    _SMART_MEASURE_SYNC_TIMER_REGISTERED = False
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    if timers is None:
        return
    for callback in (_sos_deferred_runtime_sync_timer, _sos_deferred_smart_measure_sync_timer):
        try:
            if timers.is_registered(callback):
                timers.unregister(callback)
        except Exception:
            pass


def _sos_deferred_runtime_sync_timer():
    global _RUNTIME_SYNC_TIMER_FORCE
    force = bool(_RUNTIME_SYNC_TIMER_FORCE)
    _RUNTIME_SYNC_TIMER_FORCE = False
    if not _RUNTIME_SCHEDULERS_ENABLED:
        return None
    try:
        override = _sos_runtime_sync_override()
        if override is not None:
            with bpy.context.temp_override(**override):
                _sync_deferred_addon_runtime(bpy.context, force=force)
        else:
            _sync_deferred_addon_runtime(getattr(bpy, 'context', None), force=force)
    except Exception:
        try:
            _sync_deferred_addon_runtime(getattr(bpy, 'context', None), force=force)
        except Exception:
            pass
    return None


def _schedule_deferred_addon_runtime_sync(context=None, *, force: bool = False) -> None:
    """Defer draw/handler registration changes outside UI handlers.

    Blender 5.1 crash logs for this add-on point at ui_handler_panel with an
    empty Python backtrace.  Avoid mutating draw handlers, keymaps, or integrated
    runtime state synchronously from RNA update callbacks fired by panel buttons.
    The initiating Window/Area is retained by pointer so the timer never runs
    against an empty or unrelated bpy.context.
    """
    global _RUNTIME_SYNC_TIMER_FORCE
    _sos_capture_runtime_sync_context(context)
    if not _RUNTIME_SCHEDULERS_ENABLED:
        _RUNTIME_SYNC_TIMER_FORCE = False
        return
    _RUNTIME_SYNC_TIMER_FORCE = bool(_RUNTIME_SYNC_TIMER_FORCE or force)
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is None:
            _sos_deferred_runtime_sync_timer()
            return
        # Blender 5.1 can leave a timer registered but unscheduled when it was
        # first created during Extension registration inside another app-timer.
        # Runtime changes are finite and infrequent, so reset the one-shot every
        # time a new authoritative state is queued instead of trusting that stale
        # registration marker. This also coalesces repeated settings restores to
        # one execution 30 ms after the last request.
        if timers.is_registered(_sos_deferred_runtime_sync_timer):
            try:
                timers.unregister(_sos_deferred_runtime_sync_timer)
            except Exception:
                pass
        timers.register(_sos_deferred_runtime_sync_timer, first_interval=0.03)
    except Exception:
        try:
            _sos_deferred_runtime_sync_timer()
        except Exception:
            pass


def _sos_deferred_smart_measure_sync_timer():
    global _SMART_MEASURE_SYNC_TIMER_REGISTERED
    if not _RUNTIME_SCHEDULERS_ENABLED:
        _SMART_MEASURE_SYNC_TIMER_REGISTERED = False
        return None
    try:
        override = _sos_runtime_sync_override()
        if override is not None:
            with bpy.context.temp_override(**override):
                _sync_smart_measure_addon_runtime(bpy.context)
        else:
            _sync_smart_measure_addon_runtime(getattr(bpy, 'context', None))
    except Exception:
        pass
    finally:
        # Keep the finite timer marked active while Smart Measure synchronizes.
        # handle_add can assign the same WM value and re-enter the update callback;
        # clearing at entry let that callback strand a true pending flag without
        # registering another timer, suppressing the next real OFF event.
        _SMART_MEASURE_SYNC_TIMER_REGISTERED = False
    return None


def _schedule_deferred_smart_measure_runtime_sync(context=None) -> None:
    global _SMART_MEASURE_SYNC_TIMER_REGISTERED
    if not _RUNTIME_SCHEDULERS_ENABLED:
        _SMART_MEASURE_SYNC_TIMER_REGISTERED = False
        return
    if _SMART_MEASURE_SYNC_TIMER_REGISTERED:
        return
    _sos_capture_runtime_sync_context(context)
    _SMART_MEASURE_SYNC_TIMER_REGISTERED = True
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is None:
            _sos_deferred_smart_measure_sync_timer()
            return
        if not timers.is_registered(_sos_deferred_smart_measure_sync_timer):
            timers.register(_sos_deferred_smart_measure_sync_timer, first_interval=0.03)
    except Exception:
        try:
            _sos_deferred_smart_measure_sync_timer()
        except Exception:
            pass


def _clear_legacy_window_manager_id_properties(context=None) -> None:
    """Remove stale disclosure ID-properties that older builds saved on WinMan.

    The Blender 5.1 crash record shows ``sos_always_on_toggles_open`` being set
    immediately before a ui_handler_panel access violation.  The current build
    keeps disclosure state in Python memory only, so any persisted WinMan value is
    legacy data and must not remain addressable by old UI callbacks.
    """
    names = {
        'sos_always_on_toggles_open',
        '__sos_always_on_toggles_open__',
        'smart_overlay_suite_always_on_enabled',
    }
    managers = []
    try:
        managers.extend(list(getattr(bpy.data, 'window_managers', ()) or ()))
    except Exception:
        pass
    try:
        wm = getattr(context or getattr(bpy, 'context', None), 'window_manager', None)
        if wm is not None and wm not in managers:
            managers.append(wm)
    except Exception:
        pass
    for wm in managers:
        for name in names:
            try:
                if hasattr(wm, 'keys') and name in wm.keys():
                    del wm[name]
            except Exception:
                pass


def _register_window_manager_properties() -> None:
    def _addon_runtime_toggle_update(self, context):
        if _addon_runtime_pref_sync_active():
            return
        _remember_addon_runtime_toggle_state(context, wm=self)
        _schedule_deferred_addon_runtime_sync(context)
        try:
            mesh.tag_view3d_redraw(context)
        except Exception:
            pass
        try:
            tag_uv = getattr(properties, '_prop_tag_uv_editors_redraw', None)
            if callable(tag_uv):
                tag_uv(context)
        except Exception:
            pass
        _queue_settings_save(context)

    def _object_hover_overlay_toggle_update(self, context):
        if _addon_runtime_pref_sync_active():
            return
        _remember_addon_runtime_toggle_state(context, wm=self, only_attr='sos_object_hover_overlay_enabled')
        try:
            if not getattr(self, 'sos_object_hover_overlay_enabled', False):
                mesh.reset_object_hover_cache()
                mesh.clear_object_hover_click_input_authority()
        except Exception:
            pass
        _schedule_deferred_addon_runtime_sync(context)
        mesh.clear_cache_and_redraw(context)
        _queue_settings_save(context)

    def _smart_measure_addon_runtime_toggle_update(self, context):
        if not _settings_applying():
            _schedule_deferred_smart_measure_runtime_sync(context)
        _queue_settings_save(context)

    def _simple_persistent_setting_update(self, context):
        _queue_settings_save(context)

    def _npanel_state_save_toggle_update(self, context):
        try:
            settings.handle_live_save_toggle(context)
        except Exception:
            pass

    def _object_hover_click_select_update(self, context):
        try:
            mesh.reset_object_hover_cache()
            mesh.clear_object_hover_click_input_authority()
            mesh.clear_overlay_snapshots()
            mesh.request_overlay_snapshot_rebuild(
                'object_hover_click_select_changed', context=context, immediate=True,
            )
            mesh.tag_view3d_redraw(context)
        except Exception:
            pass
        _queue_settings_save(context)

    def _npanel_child_panel_open_update(self, context):
        try:
            syncer = getattr(ui, 'sync_npanel_child_group_state_from_props', None)
            if callable(syncer):
                syncer(context, queue=True)
        except Exception:
            pass

    for _wm_prop_name in (
        'sos_mouse_x',
        'sos_mouse_y',
        'sos_uv_mouse_x',
        'sos_uv_mouse_y',
        'sos_npanel_state_save_enabled',
        'sos_preferences',
        'sos_enabled',
        'sos_proportional_overlay_enabled',
        'sos_uv_overlay_enabled',
        'sos_object_hover_overlay_enabled',
        'sos_object_hover_click_select_enabled',
        'smart_measure_run_opengl',
        ('sos_' + 'always_on_toggles_open'),
    ):
        try:
            delattr(bpy.types.WindowManager, _wm_prop_name)
        except Exception:
            pass
    try:
        for _key, _prop_name, _default in getattr(ui, 'iter_npanel_child_panel_properties', lambda: ())():
            try:
                delattr(bpy.types.WindowManager, _prop_name)
            except Exception:
                pass
    except Exception:
        pass

    try:
        bpy.types.WindowManager.sos_preferences = bpy.props.PointerProperty(
            name='Smart Overlay Suite Settings',
            description='Internal Smart Overlay Suite settings storage used by the N-panel and persistent settings system. This is intentionally not displayed in Blender Add-on Preferences.',
            type=preferences.SOS_AddonPreferences,
        )
    except Exception:
        pass

    bpy.types.WindowManager.sos_mouse_x = bpy.props.IntProperty(
        name='Smart Overlay Mouse X',
        description='Internal screen-space X coordinate used by Smart Overlay hover drawing. This value is updated automatically and is not meant to be edited manually.',
        default=-1,
        options={'HIDDEN'},
    )
    bpy.types.WindowManager.sos_mouse_y = bpy.props.IntProperty(
        name='Smart Overlay Mouse Y',
        description='Internal screen-space Y coordinate used by Smart Overlay hover drawing. This value is updated automatically and is not meant to be edited manually.',
        default=-1,
        options={'HIDDEN'},
    )
    bpy.types.WindowManager.sos_uv_mouse_x = bpy.props.IntProperty(
        name='Smart Overlay UV Mouse X',
        description='Internal screen-space X coordinate used by the UV hover overlay. This value is updated automatically and is not meant to be edited manually.',
        default=-1,
        options={'HIDDEN'},
    )
    bpy.types.WindowManager.sos_uv_mouse_y = bpy.props.IntProperty(
        name='Smart Overlay UV Mouse Y',
        description='Internal screen-space Y coordinate used by the UV hover overlay. This value is updated automatically and is not meant to be edited manually.',
        default=-1,
        options={'HIDDEN'},
    )
    bpy.types.WindowManager.sos_npanel_state_save_enabled = bpy.props.BoolProperty(
        name=translation.T('N-panel State Save'),
        description=translation.T("When ON, every Smart Overlay N-panel setting change is saved to the settings file in Blender's config folder and restored at startup or scene changes. Turning this OFF saves the OFF state once, then stops all later settings writes until it is enabled again."),
        default=True,
        update=_npanel_state_save_toggle_update,
    )

    bpy.types.WindowManager.sos_enabled = bpy.props.BoolProperty(
        name='Mesh and Curve Display',
        description=translation.T('Enable the mesh and curve overlay. Turn this ON only when you need live vertex, edge, face, selection, hover, and occlusion drawing in the 3D View. OFF stops its background processing so the 3D View stays light.'),
        default=False,
        update=_addon_runtime_toggle_update,
    )
    bpy.types.WindowManager.sos_proportional_overlay_enabled = bpy.props.BoolProperty(
        name='Proportional Display',
        description=translation.T('Enable the proportional editing heatmap only while you are using it. OFF stops its background processing until you need it again.'),
        default=False,
        update=_addon_runtime_toggle_update,
    )
    bpy.types.WindowManager.sos_uv_overlay_enabled = bpy.props.BoolProperty(
        name='UV Hover',
        description=translation.T('Enable the UV hover overlay only while editing UVs. OFF stops its background processing so startup and idle performance stay lighter.'),
        default=False,
        update=_addon_runtime_toggle_update,
    )
    bpy.types.WindowManager.sos_object_hover_overlay_enabled = bpy.props.BoolProperty(
        name=translation.T('Object / Sculpt Hover'),
        description=translation.T('Enable only the Object Mode / Sculpt Mode hover. OFF stops mouse-under-object detection and hover drawing completely.'),
        default=False,
        update=_object_hover_overlay_toggle_update,
    )
    bpy.types.WindowManager.sos_object_hover_click_select_enabled = bpy.props.BoolProperty(
        name=translation.T('Object Mode: Select Occluded'),
        description=translation.T("When ON, SmartOverlay can show an object behind a selected foreground object and a viewport selection click selects that exact hover-colored object. Shift adds, Ctrl removes, and Ctrl+Shift follows the active Blender Object Mode keymap. When OFF, rear hover through a selected foreground object and click interception are both disabled."),
        default=True,
        update=_object_hover_click_select_update,
    )
    bpy.types.WindowManager.smart_measure_run_opengl = bpy.props.BoolProperty(
        name=translation.T('Smart Measure'),
        description=translation.T('Enable Smart Measure when you need grid-scale labels or measurement annotations. OFF stops its drawing in the 3D View so the tool stays idle.'),
        default=False,
        update=_smart_measure_addon_runtime_toggle_update,
    )

    try:
        for _key, _prop_name, _default in getattr(ui, 'iter_npanel_child_panel_properties', lambda: ())():
            setattr(bpy.types.WindowManager, _prop_name, bpy.props.BoolProperty(
                name='Smart Overlay Child Panel Open',
                description='Internal open state for Smart Overlay child sections.',
                default=bool(_default),
                options={'HIDDEN'},
                update=_npanel_child_panel_open_update,
            ))
    except Exception:
        pass
    try:
        sync_props = getattr(ui, 'sync_npanel_child_panel_props', None)
        if callable(sync_props):
            sync_props(getattr(bpy, 'context', None))
    except Exception:
        pass


def _unregister_window_manager_properties() -> None:
    try:
        for _key, _prop_name, _default in getattr(ui, 'iter_npanel_child_panel_properties', lambda: ())():
            try:
                delattr(bpy.types.WindowManager, _prop_name)
            except Exception:
                pass
    except Exception:
        pass
    for attr in (
        'sos_mouse_x',
        'sos_mouse_y',
        'sos_uv_mouse_x',
        'sos_uv_mouse_y',
        'sos_npanel_state_save_enabled',
        'sos_preferences',
        'sos_enabled',
        'sos_proportional_overlay_enabled',
        'sos_uv_overlay_enabled',
        'sos_object_hover_overlay_enabled',
        'sos_object_hover_click_select_enabled',
        'smart_measure_run_opengl',
        ('sos_' + 'always_on_toggles_open'),
    ):
        try:
            delattr(bpy.types.WindowManager, attr)
        except Exception:
            pass



def _prime_window_manager_addon_runtime_defaults(context=None) -> None:
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None)
    if wm is None:
        return

    for attr_name, _pref_attr, default_value in _RUNTIME_PREF_LINKS:
        try:
            keys = wm.keys() if hasattr(wm, 'keys') else ()
            if attr_name not in keys:
                setattr(wm, attr_name, default_value)
        except Exception:
            pass
    for attr_name, default_value in (
        ('smart_measure_run_opengl', False),
        ('sos_npanel_state_save_enabled', True),
        ('sos_object_hover_click_select_enabled', True),
    ):
        try:
            keys = wm.keys() if hasattr(wm, 'keys') else ()
            if attr_name not in keys:
                setattr(wm, attr_name, default_value)
        except Exception:
            pass



def _desired_core_addon_runtime_states(context=None) -> tuple[bool, bool, bool]:
    """Return independently gated resident runtime states.

    The Mesh runtime belongs to VIEW_3D, while UV Hover and the UV proportional
    pass are cross-editor runtimes.  Do not gate the UV/Image Editor handlers by
    whether a visible VIEW_3D cell is enabled: Smart Tools Manager can validly
    enable Smart Overlay only for the UV Editor cell in a workspace.  This is the
    same separation used by the last known-good UV runtime generation.
    """
    ctx = context or getattr(bpy, 'context', None)
    managers = tuple(_sos_iter_live_window_managers(ctx))
    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    if wm is None and managers:
        wm = managers[0]
    if wm is None:
        return False, False, False

    def _view3d_allowed(candidate_context) -> bool:
        try:
            from . import common as _sos_common
            return bool(_sos_common.visible_window_view3d_runtime_allowed(candidate_context))
        except Exception:
            return bool(_sos_workspace_filter_allows_addon(candidate_context))

    def _cross_editor_allowed(candidate_context) -> bool:
        return bool(_sos_workspace_filter_allows_cross_editor_runtime(candidate_context))

    view3d_runtime_allowed = False
    cross_editor_runtime_allowed = False
    saw_window = False

    try:
        if getattr(ctx, 'window', None) is not None:
            view3d_runtime_allowed = _view3d_allowed(ctx)
            cross_editor_runtime_allowed = _cross_editor_allowed(ctx)
    except Exception:
        pass

    for window in _sos_iter_live_windows(ctx):
        if view3d_runtime_allowed and cross_editor_runtime_allowed:
            break
        screen = getattr(window, 'screen', None)
        if screen is None:
            continue
        saw_window = True
        try:
            with bpy.context.temp_override(window=window, screen=screen):
                if not view3d_runtime_allowed:
                    view3d_runtime_allowed = _view3d_allowed(bpy.context)
                if not cross_editor_runtime_allowed:
                    cross_editor_runtime_allowed = _cross_editor_allowed(bpy.context)
        except Exception:
            continue

    if not saw_window and getattr(ctx, 'window', None) is None:
        # During startup/load there may be no Window yet.  Fail open until the
        # first finite runtime synchronization can inspect the real workspace.
        view3d_runtime_allowed = True
        cross_editor_runtime_allowed = True

    mesh_runtime_enabled = bool(view3d_runtime_allowed) and (
        bool(getattr(wm, 'sos_enabled', False))
        or bool(getattr(wm, 'sos_object_hover_overlay_enabled', False))
    )
    # UV/Image Editor runtimes are owned by their explicit feature toggles.
    # They must remain resident even when the current context is a foreign 3D
    # View cell or Smart Tools Manager is between workspace generations.  Each
    # draw callback still verifies that its actual owner is a live UV Editor.
    prop_runtime_enabled = any(
        bool(getattr(manager, 'sos_proportional_overlay_enabled', False))
        for manager in managers
    )
    uv_runtime_enabled = any(
        bool(getattr(manager, 'sos_uv_overlay_enabled', False))
        for manager in managers
    )
    return mesh_runtime_enabled, prop_runtime_enabled, uv_runtime_enabled



def _sync_deferred_addon_runtime(context=None, *, force: bool = False) -> None:
    mesh_enabled, prop_enabled, uv_enabled = _desired_core_addon_runtime_states(context)

    if force or _CORE_RUNTIME_STATE.get('mesh') != mesh_enabled:
        try:
            if mesh_enabled:
                mesh.register_addon_runtime()
            else:
                mesh.unregister_addon_runtime()
        except Exception:
            pass
        _CORE_RUNTIME_STATE['mesh'] = mesh_enabled

    if force or _CORE_RUNTIME_STATE.get('prop') != prop_enabled:
        try:
            if prop_enabled:
                properties.register()
            else:
                properties.unregister()
        except Exception:
            pass
        _CORE_RUNTIME_STATE['prop'] = prop_enabled

    if force or _CORE_RUNTIME_STATE.get('uv') != uv_enabled:
        try:
            if uv_enabled:
                uv.register_addon_runtime()
            else:
                uv.unregister_addon_runtime()
        except Exception:
            pass
        _CORE_RUNTIME_STATE['uv'] = uv_enabled

    # Proportional-only View3D still needs the shared native event observer.
    # Reconcile after Mesh runtime shutdown, which also stops that observer.
    if prop_enabled and not mesh_enabled:
        ctx = context or bpy.context
        if mesh._sos_modal_tracker_wanted(ctx):
            if not mesh._sos_active_draw_token_visible(ctx):
                mesh.prime_active_view_draw_context(ctx, source='proportional_runtime_start')
            mesh._sos_start_mouse_probe_timer()
    elif not prop_enabled and not mesh_enabled:
        if mesh._sos_mouse_tracker_modal_windows or mesh._sos_mouse_tracker_bootstrap_pending:
            mesh._sos_stop_mouse_tracker_modal()

    if mesh_enabled and prop_enabled:
        try:
            ensure_prop_order = getattr(properties, 'ensure_draw_handler_draws_after_mesh', None)
            if callable(ensure_prop_order):
                ensure_prop_order()
        except Exception:
            pass

    try:
        mesh.tag_view3d_redraw()
    except Exception:
        pass
    try:
        if prop_enabled or force:
            tag_uv = getattr(properties, '_prop_tag_uv_editors_redraw', None)
            if callable(tag_uv):
                tag_uv(context or getattr(bpy, 'context', None))
    except Exception:
        pass



def _scene_override_update(self, context):
    try:
        mesh.clear_cache_and_redraw(context)
    except Exception:
        pass
    _queue_settings_save(context)



def _register_scene_properties() -> None:
    bpy.types.Scene.sos_scene_overrides_enabled = bpy.props.BoolProperty(
        name='Scene Overrides Enabled',
        description='Enable the Scene override layer for this .blend file. When ON, the add-on uses settings stored in the Scene instead of the global Smart Overlay settings.',
        default=False,
        update=_scene_override_update,
    )
    bpy.types.Scene.sos_scene_overrides_json = bpy.props.StringProperty(
        name='SOS Scene Overrides JSON',
        description='Internal JSON snapshot used by Smart Overlay scene overrides. Use the Smart Overlay N-panel Save, Load, and Clear buttons instead of editing this text directly.',
        default='',
        options={'HIDDEN'},
    )
    uv.register_scene_properties()
    try:
        uv._set_daemon_active_for_all_scenes(False)
    except Exception:
        pass



def _unregister_scene_properties() -> None:
    try:
        uv.unregister_scene_properties()
    except Exception:
        pass
    for attr in (
        'sos_scene_overrides_enabled',
        'sos_scene_overrides_json',
    ):
        try:
            delattr(bpy.types.Scene, attr)
        except Exception:
            pass



def _register_translations() -> None:
    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass
    bpy.app.translations.register(__name__, translation.I18N_DICT)



def _unregister_translations() -> None:
    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass



def _install_overlay_menu_hooks() -> None:
    for panel_name in getattr(ui, 'OVERLAY_MENU_PANEL_NAMES', ('VIEW3D_PT_overlay_edit_mesh',)):
        panel_cls = getattr(bpy.types, panel_name, None)
        if panel_cls is None:
            continue
        try:
            panel_cls.remove(ui.draw_menu)
        except Exception:
            pass
        try:
            panel_cls.append(ui.draw_menu)
        except Exception:
            pass



def _uninstall_overlay_menu_hooks() -> None:
    for panel_name in getattr(ui, 'OVERLAY_MENU_PANEL_NAMES', ('VIEW3D_PT_overlay_edit_mesh',)):
        panel_cls = getattr(bpy.types, panel_name, None)
        if panel_cls is None:
            continue
        try:
            panel_cls.remove(ui.draw_menu)
        except Exception:
            pass



def _resolve_smart_overlay_root_panel_classes() -> tuple[type, ...]:
    classes = []
    try:
        raw = tuple(getattr(ui, 'CLASSES', ()) or ())
    except Exception:
        raw = ()
    for cls in raw:
        if not isinstance(cls, type):
            continue
        try:
            if not issubclass(cls, bpy.types.Panel):
                continue
        except Exception:
            continue
        try:
            if str(getattr(cls, 'bl_region_type', '') or '') != 'UI':
                continue
            is_root = bool(getattr(cls, '_smart_suite_host_panel', False))
            category = str(getattr(cls, 'bl_category', '') or '')
            if not is_root and category not in {'Smart Overlay', 'Smart Overlay\u2060'}:
                continue
        except Exception:
            continue
        classes.append(cls)
    if not classes:
        try:
            cls = getattr(ui, 'VIEW3D_PT_sos_root', None)
            if isinstance(cls, type):
                classes.append(cls)
        except Exception:
            pass
    return tuple(classes)


def _resolve_smart_overlay_root_panel_class():
    classes = _resolve_smart_overlay_root_panel_classes()
    return classes[0] if classes else None


def _sos_root_panel_class_is_suite_owned(cls) -> bool:
    """Return True only for an exact Smart Overlay class receipt."""
    if not isinstance(cls, type):
        return False
    current = _resolve_smart_overlay_root_panel_classes()
    if any(cls is owned for owned in current):
        return True
    return _sos_class_is_suite_owned_for_registration(cls)


def _smart_overlay_root_panel_is_registered(context=None) -> bool:
    try:
        _sos_sync_manager_workspace_filter(context or getattr(bpy, 'context', None))
    except Exception:
        pass
    classes = _resolve_smart_overlay_root_panel_classes()
    if not classes:
        return False
    for cls in classes:
        try:
            _sos_apply_panel_owner_id(cls)
        except Exception:
            pass
        class_name = str(getattr(cls, '__name__', '') or '').strip()
        if not class_name:
            return False
        try:
            if getattr(bpy.types, class_name, None) is not cls:
                return False
        except Exception:
            return False
        try:
            desired_category = str(getattr(ui, 'PANEL_NATIVE_CATEGORY', 'Smart Overlay') or 'Smart Overlay')
            if str(getattr(cls, 'bl_category', '') or '') != desired_category:
                return False
        except Exception:
            return False
        try:
            desired_owner = _sos_current_panel_owner_id()
            if str(getattr(cls, 'bl_owner_id', '') or '') != str(desired_owner or ''):
                return False
        except Exception:
            return False
    return True


def _ensure_smart_overlay_root_panel_registered(context=None, *, force_refresh: bool = False, redraw_if_unchanged: bool = True) -> bool:
    """Ensure every supported Smart Overlay N-panel root is visible and valid.

    Blender copies Panel metadata and callbacks into an internal PanelType during
    registration.  When Smart_Tools_Manager reloads or an existing blend file has
    a stale Workspace.owner_ids list, merely changing ``cls.bl_owner_id`` or
    ``cls.draw`` after registration can leave the visible N-panel category active
    while the actual Smart Overlay root body remains filtered or points at an old
    callback.  This routine repairs the owner filter first, then re-registers the
    root Panel classes only when the registered metadata/callbacks are suspect.
    """
    ctx = context or getattr(bpy, 'context', None)
    try:
        _sos_sync_manager_workspace_filter(ctx)
    except Exception:
        pass

    classes = _resolve_smart_overlay_root_panel_classes()
    if not classes:
        return False

    ok = False
    changed = False
    try:
        repair = getattr(ui, 'repair_smart_tools_manager_panel_wrappers', None)
        if callable(repair):
            if repair():
                force_refresh = True
                changed = True
    except Exception:
        pass

    preferred_owner = _sos_current_panel_owner_id()
    try:
        preferred_category = str(getattr(ui, 'PANEL_NATIVE_CATEGORY', 'Smart Overlay') or 'Smart Overlay')
    except Exception:
        preferred_category = 'Smart Overlay'

    for cls in classes:
        class_name = str(getattr(cls, '__name__', '') or '').strip()
        if not class_name:
            continue

        try:
            _sos_apply_panel_owner_id(cls)
        except Exception:
            pass

        try:
            # Keep the desired values explicit on the Python class before any
            # register call, because Blender snapshots these values into PanelType.
            setattr(cls, 'bl_owner_id', preferred_owner)
            setattr(cls, 'bl_category', preferred_category)
        except Exception:
            pass

        try:
            existing = getattr(bpy.types, class_name, None)
        except Exception:
            existing = None

        needs_register = existing is not cls
        needs_reregister = bool(force_refresh)

        if isinstance(existing, type) and existing is not cls:
            if _sos_root_panel_class_is_suite_owned(existing):
                try:
                    bpy.utils.unregister_class(existing)
                    changed = True
                except Exception:
                    pass
                existing = None
                needs_register = True
            else:
                # A same-name third-party Panel is not ours.  Preserve it and
                # fail this root closed without mutating foreign registration.
                needs_register = False
                needs_reregister = False
                continue

        if isinstance(existing, type) and existing is cls:
            try:
                current_owner = str(getattr(existing, 'bl_owner_id', '') or '')
                if current_owner != str(preferred_owner or ''):
                    setattr(existing, 'bl_owner_id', preferred_owner)
                    needs_reregister = True
            except Exception:
                needs_reregister = True

            try:
                current_category = str(getattr(existing, 'bl_category', '') or '')
                if current_category != str(preferred_category or ''):
                    setattr(existing, 'bl_category', preferred_category)
                    needs_reregister = True
            except Exception:
                needs_reregister = True

            try:
                poll_attr = getattr(existing, 'poll', None)
                poll_func = getattr(poll_attr, '__func__', poll_attr)
                if bool(getattr(poll_func, '_smart_tools_manager_wrapper', False)):
                    needs_reregister = True
            except Exception:
                pass
            try:
                draw_attr = getattr(existing, 'draw', None)
                if bool(getattr(draw_attr, '_smart_tools_manager_wrapper', False)):
                    needs_reregister = True
            except Exception:
                pass

        if isinstance(existing, type) and existing is cls and needs_reregister:
            try:
                bpy.utils.unregister_class(cls)
                changed = True
                existing = None
                needs_register = True
            except Exception:
                # If Blender is actively drawing the sidebar, avoid forcing a
                # risky unregister in this pass.  The next timer pass will retry.
                needs_register = False

        if needs_register:
            try:
                _safe_register_class(cls)
                changed = True
            except Exception:
                continue

        try:
            if getattr(bpy.types, class_name, None) is cls:
                ok = True
        except Exception:
            pass

    if changed or bool(redraw_if_unchanged):
        try:
            _tag_view3d_sidebar_redraw(ctx)
        except Exception:
            pass
    return bool(ok and _smart_overlay_root_panel_is_registered(ctx))

def _sos_event_repair_notify(*_args) -> None:
    _schedule_event_driven_repair('rna_event', attempts=3, first_interval=0.01)


def _run_event_driven_repair(reason: str = '') -> bool:
    """Repair Suite-owned UI/runtime resources from an explicit event only."""
    if not _REGISTERED:
        return True
    ctx = getattr(bpy, 'context', None)
    ok = True
    try:
        _sos_sync_manager_workspace_filter(ctx)
    except Exception:
        ok = False
    try:
        ok = bool(_ensure_smart_overlay_root_panel_registered(
            ctx, force_refresh=False, redraw_if_unchanged=False
        )) and ok
    except Exception:
        ok = False
    try:
        if _core_addon_runtime_needs_repair(ctx):
            _sync_deferred_addon_runtime(ctx, force=True)
        else:
            _sync_deferred_addon_runtime(ctx, force=False)
    except Exception:
        ok = False
    try:
        from . import mesh as _sos_mesh
        request = getattr(_sos_mesh, 'request_overlay_snapshot_rebuild', None)
        if callable(request):
            request(str(reason or 'event_repair'), context=ctx, immediate=True)
    except Exception:
        pass
    return bool(ok)


def _event_driven_repair_timer():
    global _SOS_EVENT_REPAIR_PENDING, _SOS_EVENT_REPAIR_REASON
    _SOS_EVENT_REPAIR_PENDING = False
    reason = str(_SOS_EVENT_REPAIR_REASON or 'event')
    _SOS_EVENT_REPAIR_REASON = ''
    try:
        _run_event_driven_repair(reason)
    except Exception:
        pass
    return None


def _schedule_event_driven_repair(reason: str = '', *, attempts: int = 3, first_interval: float = 0.01) -> None:
    """Coalesce an explicit Blender/Manager event into a finite repair sequence."""
    global _SOS_EVENT_REPAIR_PENDING, _SOS_EVENT_REPAIR_SERIAL, _SOS_EVENT_REPAIR_REASON
    _SOS_EVENT_REPAIR_SERIAL += 1
    serial = int(_SOS_EVENT_REPAIR_SERIAL)
    _SOS_EVENT_REPAIR_REASON = str(reason or _SOS_EVENT_REPAIR_REASON or 'event')
    if _SOS_EVENT_REPAIR_PENDING:
        return
    _SOS_EVENT_REPAIR_PENDING = True
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    if timers is None:
        _SOS_EVENT_REPAIR_PENDING = False
        _run_event_driven_repair(_SOS_EVENT_REPAIR_REASON)
        return
    state = {'attempt': 0}
    max_attempts = max(1, min(int(attempts or 1), _SOS_EVENT_REPAIR_MAX_ATTEMPTS))

    def _tick():
        global _SOS_EVENT_REPAIR_PENDING, _SOS_EVENT_REPAIR_REASON
        if not _REGISTERED:
            _SOS_EVENT_REPAIR_PENDING = False
            _SOS_EVENT_REPAIR_REASON = ''
            try:
                _REFRESH_TIMERS.discard(_tick)
            except Exception:
                pass
            return None
        current_serial = int(_SOS_EVENT_REPAIR_SERIAL)
        state['attempt'] += 1
        success = False
        try:
            success = bool(_run_event_driven_repair(_SOS_EVENT_REPAIR_REASON))
        except Exception:
            success = False
        changed_during_repair = current_serial != serial
        if changed_during_repair and state['attempt'] < max_attempts:
            return 0.05
        if (not success) and state['attempt'] < max_attempts:
            return 0.10 if state['attempt'] < 3 else 0.25
        tail_needed = bool(changed_during_repair)
        tail_reason = str(_SOS_EVENT_REPAIR_REASON or 'coalesced_event')
        _SOS_EVENT_REPAIR_PENDING = False
        _SOS_EVENT_REPAIR_REASON = ''
        try:
            _REFRESH_TIMERS.discard(_tick)
        except Exception:
            pass
        # If a new explicit event arrived during the final bounded attempt, start
        # exactly one fresh bounded sequence.  This avoids losing the last event
        # without turning the repair into a resident watchdog.
        if tail_needed and _REGISTERED:
            _schedule_event_driven_repair(tail_reason, attempts=max_attempts, first_interval=0.01)
        return None

    try:
        setattr(_tick, '_sos_event_driven_repair', True)
        _REFRESH_TIMERS.add(_tick)
        timers.register(_tick, first_interval=max(0.0, float(first_interval)))
    except Exception:
        _SOS_EVENT_REPAIR_PENDING = False
        try:
            _REFRESH_TIMERS.discard(_tick)
        except Exception:
            pass
        try:
            _run_event_driven_repair(_SOS_EVENT_REPAIR_REASON)
        except Exception:
            pass


def _register_event_repair_msgbus() -> None:
    """Subscribe only to real workspace/editor/Manager property changes."""
    owner = _SOS_EVENT_REPAIR_MSGBUS_OWNER
    try:
        bpy.msgbus.clear_by_owner(owner)
    except Exception:
        pass
    keys = []
    for type_name, prop_name in (
        ('Window', 'workspace'),
        ('Area', 'type'),
        ('WorkSpace', 'use_filter_by_owner'),
        ('WindowManager', 'sos_enabled'),
        ('WindowManager', 'sos_proportional_overlay_enabled'),
        ('WindowManager', 'sos_uv_overlay_enabled'),
    ):
        try:
            rna_type = getattr(bpy.types, type_name, None)
            if rna_type is not None and hasattr(rna_type, prop_name):
                keys.append((rna_type, prop_name))
        except Exception:
            pass
    # Smart Tools Manager 1.5.x exposes its live rule checkboxes as RNA on its
    # PropertyGroup.  Subscribe by exact registered class identity when present;
    # no module import or periodic scan is performed.
    try:
        manager_cls = getattr(bpy.types, 'SmartToolsManagerProperties', None)
        annotations = getattr(manager_cls, '__annotations__', {}) if manager_cls is not None else {}
        for prop_name in tuple(annotations or {}):
            if str(prop_name).startswith(('tool_', 'rule_', 'show_')):
                keys.append((manager_cls, str(prop_name)))
    except Exception:
        pass
    seen = set()
    for key in keys:
        try:
            token = (id(key[0]), key[1])
            if token in seen:
                continue
            seen.add(token)
            bpy.msgbus.subscribe_rna(
                key=key, owner=owner, args=(), notify=_sos_event_repair_notify,
                options={'PERSISTENT'},
            )
        except Exception:
            continue


def _unregister_event_repair_msgbus() -> None:
    global _SOS_EVENT_REPAIR_PENDING, _SOS_EVENT_REPAIR_REASON
    _SOS_EVENT_REPAIR_PENDING = False
    _SOS_EVENT_REPAIR_REASON = ''
    try:
        bpy.msgbus.clear_by_owner(_SOS_EVENT_REPAIR_MSGBUS_OWNER)
    except Exception:
        pass


def _schedule_root_panel_registration_refresh(*, attempts: int = 8, first_interval: float = 0.05, force_first: bool = True) -> None:
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    if timers is None:
        _ensure_smart_overlay_root_panel_registered(getattr(bpy, 'context', None), force_refresh=force_first)
        return

    state = {'step': 0}

    def _tick():
        try:
            if not _REGISTERED:
                return None
            force_refresh = bool(force_first and state['step'] == 0)
            _ensure_smart_overlay_root_panel_registered(getattr(bpy, 'context', None), force_refresh=force_refresh)
            state['step'] += 1
            if state['step'] < max(1, int(attempts)):
                return 0.15 if state['step'] < 4 else 0.50
            return None
        finally:
            if state['step'] >= max(1, int(attempts)) or not _REGISTERED:
                try:
                    _REFRESH_TIMERS.discard(_tick)
                except Exception:
                    pass

    try:
        _REFRESH_TIMERS.add(_tick)
    except Exception:
        pass
    try:
        timers.register(_tick, first_interval=max(0.01, float(first_interval)))
    except Exception:
        try:
            _REFRESH_TIMERS.discard(_tick)
        except Exception:
            pass


def _start_root_panel_registration_watchdog(*, interval: float = 2.0) -> None:
    """Compatibility entry point for bounded event-driven root repair.

    No resident watchdog is registered.  Registration/load/workspace/Manager
    events call this function, which coalesces a finite one-shot repair.
    """
    del interval
    _schedule_event_driven_repair('root_panel_event', attempts=3, first_interval=0.05)


def _refresh_view3d_sidebar_addon_runtime(context=None, *, force: bool = False) -> None:
    """Refresh the root Smart Overlay N-panel registration and redraw state."""
    try:
        _sos_sync_manager_workspace_filter(context or getattr(bpy, 'context', None))
    except Exception:
        pass
    _ensure_smart_overlay_root_panel_registered(context, force_refresh=force)
    return None


def _sos_repair_addon_runtime(context=None) -> None:
    ctx = context or getattr(bpy, 'context', None)

    prefs = _prime_preferences_state(ctx)
    if prefs is not None:
        try:
            migrate_preset = getattr(preferences, 'get_current_preset_id', None)
            if callable(migrate_preset):
                migrate_preset(prefs)
        except Exception:
            pass
        try:
            sync_depth = getattr(preferences, '_sync_depth_ui_from_internal', None)
            if callable(sync_depth):
                sync_depth(prefs)
        except Exception:
            pass
        try:
            migrate_uv_hover = getattr(preferences, 'migrate_uv_hover_red_defaults', None)
            if callable(migrate_uv_hover):
                migrate_uv_hover(prefs)
        except Exception:
            pass
        try:
            migrate_active_view = getattr(preferences, 'migrate_active_view_update_alias', None)
            if callable(migrate_active_view):
                migrate_active_view(prefs)
        except Exception:
            pass

    try:
        _sync_deferred_addon_runtime(ctx, force=_core_addon_runtime_needs_repair(ctx))
    except Exception:
        pass



def _sos_runtime_liveness_watchdog_timer():
    """Compatibility one-shot; periodic liveness polling is intentionally retired."""
    try:
        if _REGISTERED:
            _run_event_driven_repair('liveness_event')
    except Exception:
        pass
    return None


def _start_runtime_liveness_watchdog() -> None:
    _schedule_event_driven_repair('liveness_start', attempts=3, first_interval=0.05)


@persistent
def _smart_overlay_load_pre(_dummy) -> None:
    """Fence finite jobs and release file-bound GPU snapshots before ID teardown."""
    try:
        _clear_refresh_timers()
    except Exception:
        pass
    try:
        _cancel_deferred_runtime_sync_timers()
    except Exception:
        pass
    try:
        clear_mesh = getattr(mesh, 'clear_overlay_snapshots', None)
        if callable(clear_mesh):
            clear_mesh()
    except Exception:
        pass
    try:
        clear_prop = getattr(properties, 'clear_view3d_snapshots', None)
        if callable(clear_prop):
            clear_prop()
    except Exception:
        pass


@persistent
def _smart_overlay_load_post(_dummy) -> None:
    ctx = getattr(bpy, 'context', None)
    try:
        from . import transform_guard as _sos_transform_guard
        _sos_transform_snapshot = _sos_transform_guard.snapshot_scene_object_transforms(ctx)
    except Exception:
        _sos_transform_guard = None
        _sos_transform_snapshot = None
    try:
        _ensure_smart_overlay_root_panel_registered(ctx, force_refresh=False)
        _schedule_root_panel_registration_refresh(attempts=4, first_interval=0.10, force_first=True)
        _schedule_event_driven_repair('load_post', attempts=4, first_interval=0.01)
    except Exception:
        pass
    try:
        if _ensure_integrated_addon_runtime_loaded(ctx, force=False):
            _tag_view3d_sidebar_redraw(ctx)
    except Exception:
        pass
    try:
        settings.apply_settings(ctx)
        try:
            pref_after_settings = integrated_registry.resolve_addon_preferences(ctx)
            _apply_requested_baseline_recovery(pref_after_settings, ctx)
            migrate_uv_hover = getattr(preferences, 'migrate_uv_hover_red_defaults', None)
            if callable(migrate_uv_hover):
                migrate_uv_hover(pref_after_settings)
            migrate_active_view = getattr(preferences, 'migrate_active_view_update_alias', None)
            if callable(migrate_active_view):
                migrate_active_view(pref_after_settings)
        except Exception:
            pass
    except Exception:
        pass
    try:
        workspace_tool_safety.run_safety_pass(ctx)
        workspace_tool_safety.schedule_safety_pass(attempts=2, first_interval=0.10)
    except Exception:
        pass
    try:
        _restore_addon_runtime_toggle_state_from_prefs(ctx)
    except Exception:
        pass
    try:
        _sync_deferred_addon_runtime(ctx, force=True)
    except Exception:
        pass
    try:
        _sync_explicit_addon_runtime_toggles(ctx)
    except Exception:
        pass
    try:
        pref_obj = integrated_registry.resolve_addon_preferences(ctx)
        register_prop_ramp = getattr(preferences, 'register_prop_heatmap_preview_addon_runtime', None)
        if callable(register_prop_ramp):
            register_prop_ramp(ctx, pref_obj)
        else:
            sync_prop_ramp = getattr(preferences, 'sync_prop_heatmap_preview_node_from_source', None)
            if callable(sync_prop_ramp):
                sync_prop_ramp(pref_obj)
    except Exception:
        pass
    try:
        if _sos_addon_runtime_followup_needed(ctx):
            _schedule_addon_runtime_refresh(attempts=2, first_interval=0.10)
            if _core_addon_runtime_needs_repair(ctx):
                _schedule_addon_runtime_repair(attempts=1)
    except Exception:
        pass
    try:
        if _sos_transform_guard is not None:
            _sos_transform_guard.restore_scene_object_transforms(_sos_transform_snapshot, reason='smart_overlay_load_post')
    except Exception:
        pass



def _schedule_addon_runtime_refresh(*, attempts: int = 3, first_interval: float = 0.10) -> None:
    global _REFRESH_GENERATION
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    if timers is None:
        _refresh_view3d_sidebar_addon_runtime()
        return

    _REFRESH_GENERATION += 1
    generation = _REFRESH_GENERATION
    state = {'step': 0}

    def _tick():
        if generation != _REFRESH_GENERATION:
            try:
                _REFRESH_TIMERS.discard(_managed_tick)
            except Exception:
                pass
            return None
        try:
            _refresh_view3d_sidebar_addon_runtime()
        except Exception:
            pass
        state['step'] += 1
        if state['step'] < max(1, int(attempts)):
            return 0.20 if state['step'] < 4 else 0.60
        try:
            _REFRESH_TIMERS.discard(_managed_tick)
        except Exception:
            pass
        return None

    def _managed_tick():
        try:
            return _tick()
        finally:
            if generation != _REFRESH_GENERATION:
                try:
                    _REFRESH_TIMERS.discard(_managed_tick)
                except Exception:
                    pass

    try:
        _REFRESH_TIMERS.add(_managed_tick)
    except Exception:
        pass
    timers.register(_managed_tick, first_interval=max(0.01, float(first_interval)))



def _sos_ui_classes() -> tuple[type, ...]:
    try:
        classes = tuple(getattr(ui, 'CLASSES', ()) or ())
    except Exception:
        classes = ()
    return tuple(cls for cls in classes if isinstance(cls, type))


def _sos_non_ui_classes() -> tuple[type, ...]:
    ui_classes = set(_sos_ui_classes())
    return tuple(cls for cls in _sos_classes() if cls not in ui_classes)


def _integrated_tool_records_are_complete(context=None) -> bool:
    try:
        from . import loader as integrated_loader
    except Exception:
        return False
    try:
        expected = tuple(getattr(integrated_registry, 'TOOL_FOLDERS', ()) or ())
    except Exception:
        expected = ()
    if not expected:
        expected = ('smart_measure', 'image_dimensions_viewer', 'silhouette')
    try:
        records = list(integrated_loader.get_records())
    except Exception:
        records = []
    if not records:
        return False
    by_alias = {
        str((record.get('spec') or {}).get('alias') or '').strip(): record
        for record in records
        if isinstance(record, dict)
    }
    for alias in expected:
        record = by_alias.get(str(alias))
        if not record:
            return False
        if str(record.get('status') or '') != 'loaded':
            return False
        if str(alias) == 'image_dimensions_viewer':
            continue
        panels = tuple(record.get('panels') or ())
        if not any(isinstance(cls, type) for cls in panels):
            return False
    return True


def _ensure_integrated_addon_runtime_loaded(context=None, *, force: bool = False) -> bool:
    if (not force) and _integrated_tool_records_are_complete(context):
        return False
    try:
        integrated_addon_runtime.register()
        return True
    except Exception:
        try:
            _LOG.exception('Failed to register integrated add-ons runtime.')
        except Exception:
            pass
    return False


def _tag_view3d_sidebar_redraw(context=None) -> None:
    ctx = context or getattr(bpy, 'context', None)
    supported_spaces = set(getattr(ui, 'SMART_OVERLAY_NPANEL_SPACE_SET', {'VIEW_3D'}))
    seen = set()

    def _tag_area(area):
        if area is None:
            return
        try:
            if str(getattr(area, 'type', '') or '') not in supported_spaces:
                return
        except Exception:
            return
        try:
            key = int(getattr(area, 'as_pointer', lambda: id(area))())
        except Exception:
            key = id(area)
        if key in seen:
            return
        seen.add(key)
        try:
            area.tag_redraw()
            return
        except Exception:
            pass
        try:
            for region in getattr(area, 'regions', ()) or ():
                try:
                    region.tag_redraw()
                except Exception:
                    pass
        except Exception:
            pass

    try:
        wm = getattr(ctx, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                _tag_area(area)
    except Exception:
        pass
    try:
        screen = getattr(ctx, 'screen', None)
        for area in getattr(screen, 'areas', ()) or ():
            _tag_area(area)
    except Exception:
        pass



_SMART_TOOLS_PANEL_REPAIR_TIMER_ACTIVE = False


def _sos_smart_tools_panel_wrapper_repair_timer():
    """Compatibility one-shot for Manager panel wrapper changes."""
    global _SMART_TOOLS_PANEL_REPAIR_TIMER_ACTIVE
    _SMART_TOOLS_PANEL_REPAIR_TIMER_ACTIVE = False
    try:
        if _REGISTERED:
            _run_event_driven_repair('manager_wrapper_event')
    except Exception:
        pass
    return None


def _start_smart_tools_panel_wrapper_repair_timer() -> None:
    global _SMART_TOOLS_PANEL_REPAIR_TIMER_ACTIVE
    # Compatibility entry point only.  The actual work is a bounded one-shot,
    # therefore the legacy resident-timer flag must remain false.
    _SMART_TOOLS_PANEL_REPAIR_TIMER_ACTIVE = False
    _schedule_event_driven_repair('manager_wrapper_start', attempts=3, first_interval=0.05)

def _stop_smart_tools_panel_wrapper_repair_timer() -> None:
    global _SMART_TOOLS_PANEL_REPAIR_TIMER_ACTIVE
    _SMART_TOOLS_PANEL_REPAIR_TIMER_ACTIVE = False
    try:
        if bpy.app.timers.is_registered(_sos_smart_tools_panel_wrapper_repair_timer):
            bpy.app.timers.unregister(_sos_smart_tools_panel_wrapper_repair_timer)
    except Exception:
        pass


def register() -> None:
    global _REGISTERED, _RUNTIME_SCHEDULERS_ENABLED
    _RUNTIME_SCHEDULERS_ENABLED = True
    try:
        _REGISTER_WARNINGS.clear()
    except Exception:
        pass
    if _REGISTERED:
        try:
            _register_smart_overlay_ui_classes(None)
            _schedule_root_panel_registration_refresh(attempts=4, first_interval=0.05, force_first=True)
            _schedule_event_driven_repair('load_post', attempts=4, first_interval=0.01)
            _schedule_event_driven_repair('register_existing_runtime', attempts=3, first_interval=0.01)
        except Exception:
            pass
        return
    if not _sos_can_register():
        return

    try:
        _safe_boot_preflight_cleanup(_addon_runtime, __package__, __name__, __file__)
    except Exception:
        pass
    try:
        _purge_forbidden_top_level_modules()
    except Exception:
        pass
    try:
        workspace_tool_safety.run_safety_pass(getattr(bpy, 'context', None))
    except Exception:
        pass
    try:
        _sos_sync_manager_workspace_filter(getattr(bpy, 'context', None))
    except Exception:
        pass

    registered_classes = []
    wm_props_registered = False
    scene_props_registered = False
    translations_registered = False
    addon_runtime_registered = False
    ui_classes_registered = False
    undo_support_registered = False

    try:
        # Make the Smart Overlay N-panel tab available before any heavier
        # runtime/property registration. If a non-UI component needs recovery,
        # the visible panel can still be registered and redrawn.
        ui_classes_registered = _register_smart_overlay_ui_classes(registered_classes)

        try:
            non_ui_classes = _sos_non_ui_classes()
        except Exception as exc:
            _record_register_warning('Non-UI class discovery', exc)
            non_ui_classes = ()
        for cls in non_ui_classes:
            _register_class_nonfatal(cls, registered_classes)

        try:
            _clear_legacy_window_manager_id_properties(getattr(bpy, 'context', None))
        except Exception:
            pass

        try:
            _register_window_manager_properties()
            wm_props_registered = True
            _prime_window_manager_addon_runtime_defaults(getattr(bpy, 'context', None))
        except Exception as exc:
            _record_register_warning('WindowManager properties', exc)

        try:
            _register_scene_properties()
            scene_props_registered = True
            try:
                from . import undo_support
                undo_support.register(getattr(bpy, 'context', None))
                undo_support_registered = True
            except Exception as exc:
                _record_register_warning('Undo/Redo support', exc)
        except Exception as exc:
            _record_register_warning('Scene properties', exc)

        try:
            settings.apply_settings(getattr(bpy, 'context', None))
        except Exception:
            pass

        try:
            _register_translations()
            translations_registered = True
        except Exception as exc:
            _record_register_warning('Translations', exc)

        try:
            icons.register()
        except Exception:
            pass

        try:
            unregister_legacy_panels = getattr(ui, 'unregister_legacy_side_panels', None)
            if callable(unregister_legacy_panels):
                unregister_legacy_panels()
        except Exception:
            pass

        _ensure_smart_overlay_root_panel_registered(getattr(bpy, 'context', None), force_refresh=False)

        try:
            settings.apply_settings(getattr(bpy, 'context', None))
        except Exception:
            pass

        try:
            suppress_prefs_ui = getattr(preferences, 'suppress_addon_preferences_ui', None)
            if callable(suppress_prefs_ui):
                suppress_prefs_ui()
        except Exception:
            pass

        _ensure_smart_overlay_root_panel_registered(getattr(bpy, 'context', None), force_refresh=False)
        _tag_view3d_sidebar_redraw(getattr(bpy, 'context', None))

        _install_overlay_menu_hooks()

        pref_obj = None
        try:
            pref_obj = integrated_registry.resolve_addon_preferences(getattr(bpy, 'context', None))
            if pref_obj is not None:
                migrate_preset = getattr(preferences, 'get_current_preset_id', None)
                if callable(migrate_preset):
                    migrate_preset(pref_obj)
                sync_depth = getattr(preferences, '_sync_depth_ui_from_internal', None)
                if callable(sync_depth):
                    sync_depth(pref_obj)
                migrate_uv_hover = getattr(preferences, 'migrate_uv_hover_red_defaults', None)
                if callable(migrate_uv_hover):
                    migrate_uv_hover(pref_obj)
                migrate_active_view = getattr(preferences, 'migrate_active_view_update_alias', None)
                if callable(migrate_active_view):
                    migrate_active_view(pref_obj)
            register_prop_ramp = getattr(preferences, 'register_prop_heatmap_preview_addon_runtime', None)
            if callable(register_prop_ramp):
                register_prop_ramp(getattr(bpy, 'context', None), pref_obj)
            else:
                sync_prop_ramp = getattr(preferences, 'sync_prop_heatmap_preview_node_from_source', None)
                if callable(sync_prop_ramp):
                    sync_prop_ramp(pref_obj)
        except Exception:
            pass

        try:
            _restore_addon_runtime_toggle_state_from_prefs(getattr(bpy, 'context', None), prefs=pref_obj)
        except Exception:
            pass

        _CORE_RUNTIME_STATE.update({'mesh': False, 'prop': False, 'uv': False})
        _sync_deferred_addon_runtime(getattr(bpy, 'context', None), force=False)

        if _ensure_integrated_addon_runtime_loaded(getattr(bpy, 'context', None), force=True):
            addon_runtime_registered = True
        try:
            settings.apply_settings(getattr(bpy, 'context', None))
            try:
                pref_after_settings = integrated_registry.resolve_addon_preferences(getattr(bpy, 'context', None))
                _apply_requested_baseline_recovery(
                    pref_after_settings, getattr(bpy, 'context', None))
                migrate_uv_hover = getattr(preferences, 'migrate_uv_hover_red_defaults', None)
                if callable(migrate_uv_hover):
                    migrate_uv_hover(pref_after_settings)
                migrate_active_view = getattr(preferences, 'migrate_active_view_update_alias', None)
                if callable(migrate_active_view):
                    migrate_active_view(pref_after_settings)
            except Exception:
                pass
            _sync_explicit_addon_runtime_toggles(getattr(bpy, 'context', None))
            # settings.apply_settings() can restore the three WindowManager
            # runtime toggles after the earlier core-runtime sync. Reconcile the
            # restored values once more using the retained live UI authority;
            # otherwise a saved ON toggle can show in the panel while every UV
            # draw handler remains unregistered until the user toggles twice.
            _schedule_deferred_addon_runtime_sync(getattr(bpy, 'context', None), force=True)
        except Exception:
            pass

        if not ui_classes_registered:
            _register_smart_overlay_ui_classes(registered_classes)
            ui_classes_registered = True

        try:
            _ensure_smart_overlay_root_panel_registered(getattr(bpy, 'context', None), force_refresh=False)
            _tag_view3d_sidebar_redraw(getattr(bpy, 'context', None))
        except Exception:
            pass

        try:
            workspace_tool_safety.schedule_safety_pass(attempts=4, first_interval=0.05)
        except Exception:
            pass

        try:
            _append_load_pre_handler_once(_smart_overlay_load_pre)
            _append_load_post_handler_once(_smart_overlay_load_post)
            ctx = getattr(bpy, 'context', None)
            if _sos_addon_runtime_followup_needed(ctx):
                _schedule_addon_runtime_refresh(attempts=2, first_interval=0.20)
                if _core_addon_runtime_needs_repair(ctx):
                    _schedule_addon_runtime_repair(attempts=1)
        except Exception as exc:
            _record_register_warning('Runtime follow-up scheduling', exc)

        try:
            settings.register(getattr(bpy, 'context', None))
        except Exception:
            pass
        try:
            from . import undo_support
            undo_support.initialize_snapshot(getattr(bpy, 'context', None), force=True)
        except Exception:
            pass

        _REGISTERED = True
        # Registration/settings restore suppresses RNA callbacks by design.
        # Reconcile once more after the package is fully registered so saved UV
        # and proportional toggles can never remain ON with no Image Editor
        # draw handlers. The work stays deferred outside panel/RNA handlers.
        try:
            _schedule_deferred_addon_runtime_sync(getattr(bpy, 'context', None), force=True)
        except Exception:
            pass
        try:
            _register_event_repair_msgbus()
        except Exception:
            pass
        try:
            _schedule_root_panel_registration_refresh(attempts=8, first_interval=0.05, force_first=True)
            _schedule_event_driven_repair('load_post', attempts=4, first_interval=0.01)
            _schedule_event_driven_repair('register_existing_runtime', attempts=3, first_interval=0.01)
        except Exception:
            pass
    except Exception:
        _unregister_event_repair_msgbus()
        _clear_refresh_timers()
        _remove_load_pre_handler(_smart_overlay_load_pre)
        _remove_load_post_handler(_smart_overlay_load_post)

        try:
            if addon_runtime_registered:
                integrated_addon_runtime.unregister()
        except Exception:
            pass

        try:
            high_precision_outline.unregister_runtime(getattr(bpy, 'context', None))
        except Exception:
            pass
        try:
            uv.unregister_addon_runtime()
        except Exception:
            pass
        try:
            properties.unregister()
        except Exception:
            pass
        try:
            mesh.unregister_addon_runtime()
        except Exception:
            pass
        _CORE_RUNTIME_STATE.update({'mesh': False, 'prop': False, 'uv': False})

        _uninstall_overlay_menu_hooks()

        try:
            settings.unregister(getattr(bpy, 'context', None))
        except Exception:
            pass
        try:
            if undo_support_registered:
                from . import undo_support
                undo_support.unregister(getattr(bpy, 'context', None))
        except Exception:
            pass

        try:
            restore_prefs_ui = getattr(preferences, 'restore_addon_preferences_ui', None)
            if callable(restore_prefs_ui):
                restore_prefs_ui()
        except Exception:
            pass

        try:
            unregister_bridge_panels = getattr(ui, 'unregister_smart_tools_manager_bridge_panels', None)
            if callable(unregister_bridge_panels):
                unregister_bridge_panels()
        except Exception:
            pass

        for cls in reversed(registered_classes):
            _safe_unregister_class(cls)

        try:
            icons.unregister()
        except Exception:
            pass
        if translations_registered:
            _unregister_translations()
        if scene_props_registered:
            _unregister_scene_properties()
        if wm_props_registered:
            _unregister_window_manager_properties()
        try:
            _clear_legacy_window_manager_id_properties(getattr(bpy, 'context', None))
        except Exception:
            pass

        _RUNTIME_SCHEDULERS_ENABLED = False
        _cancel_deferred_runtime_sync_timers()
        _REGISTERED = False
        _sos_clear_owner(__package__)
        # Add-on enable/register must remain non-throwing.  The complete rollback
        # above leaves the package disabled and safe for a later explicit retry.
        return None



def unregister() -> None:
    global _REGISTERED, _RUNTIME_SCHEDULERS_ENABLED

    # Fence RNA update callbacks before property/class teardown can enqueue work.
    _RUNTIME_SCHEDULERS_ENABLED = False
    _cancel_deferred_runtime_sync_timers()

    # Only the owner should unregister shared handlers.
    if _sos_get_owner() not in (None, __package__):
        return

    try:
        try:
            _unregister_event_repair_msgbus()
        except Exception:
            pass
        try:
            if bpy.app.timers.is_registered(_sos_addon_runtime_repair_timer):
                bpy.app.timers.unregister(_sos_addon_runtime_repair_timer)
        except Exception:
            pass

        _stop_smart_tools_panel_wrapper_repair_timer()
        _remove_load_pre_handler(_smart_overlay_load_pre)
        _remove_load_post_handler(_smart_overlay_load_post)
        _clear_refresh_timers()
        try:
            settings.unregister(getattr(bpy, 'context', None))
        except Exception:
            pass
        try:
            from . import undo_support
            undo_support.unregister(getattr(bpy, 'context', None))
        except Exception:
            pass
        try:
            workspace_tool_safety.cancel_scheduled_safety_pass()
        except Exception:
            pass

        try:
            integrated_addon_runtime.unregister()
        except Exception:
            pass

        try:
            high_precision_outline.unregister_runtime(getattr(bpy, 'context', None))
        except Exception:
            pass
        try:
            uv.unregister_addon_runtime()
        except Exception:
            pass
        try:
            properties.unregister()
        except Exception:
            pass
        try:
            mesh.unregister_addon_runtime()
        except Exception:
            pass
        _CORE_RUNTIME_STATE.update({'mesh': False, 'prop': False, 'uv': False})

        _uninstall_overlay_menu_hooks()
        try:
            unregister_preview_addon_runtime = getattr(preferences, 'unregister_prop_heatmap_preview_addon_runtime', None)
            if callable(unregister_preview_addon_runtime):
                unregister_preview_addon_runtime()
            else:
                clear_preview = getattr(preferences, 'clear_prop_heatmap_preview_node', None)
                if callable(clear_preview):
                    clear_preview()
        except Exception:
            pass


        try:
            restore_prefs_ui = getattr(preferences, 'restore_addon_preferences_ui', None)
            if callable(restore_prefs_ui):
                restore_prefs_ui()
        except Exception:
            pass

        try:
            unregister_bridge_panels = getattr(ui, 'unregister_smart_tools_manager_bridge_panels', None)
            if callable(unregister_bridge_panels):
                unregister_bridge_panels()
        except Exception:
            pass

        for cls in reversed(_sos_classes()):
            _safe_unregister_class(cls)

        try:
            icons.unregister()
        except Exception:
            pass

        _unregister_translations()
        _unregister_scene_properties()
        _unregister_window_manager_properties()
        try:
            _clear_legacy_window_manager_id_properties(getattr(bpy, 'context', None))
        except Exception:
            pass
        _REGISTERED = False
        # Property deletion can fire update callbacks; cancel again after all
        # RNA/classes are gone so disable leaves no finite callback behind.
        _cancel_deferred_runtime_sync_timers()
    finally:
        _sos_clear_owner(__package__)


# SUITE_TOOLTIP_AUDIT_WRAPPER_START
from . import tooltip_audit as _tooltip_audit

try:
    _SUITE_TOOLTIP_AUDIT_ORIG_REGISTER = register
    _SUITE_TOOLTIP_AUDIT_ORIG_UNREGISTER = unregister
except Exception:
    pass
else:
    def register():
        _tooltip_audit.begin_addon_runtime_audit()
        try:
            result = _SUITE_TOOLTIP_AUDIT_ORIG_REGISTER()
        except Exception:
            _tooltip_audit.abort_addon_runtime_audit()
            raise
        _tooltip_audit.finish_addon_runtime_audit()
        return result

    def unregister():
        try:
            return _SUITE_TOOLTIP_AUDIT_ORIG_UNREGISTER()
        finally:
            _tooltip_audit.clear_addon_runtime_audit()
# SUITE_TOOLTIP_AUDIT_WRAPPER_END


if __name__ == "__main__":
    try:
        unregister()
    except Exception:
        pass
    register()

# --- Smart common extension patch START ---
try:
    from . import common as _SMART_COMMON
except Exception:
    _SMART_COMMON = None

_SMART_ORIGINAL_REGISTER = globals().get('register')
_SMART_ORIGINAL_UNREGISTER = globals().get('unregister')


def register():
    if _SMART_COMMON is not None:
        try:
            _SMART_COMMON.begin_register()
        except Exception:
            pass
    try:
        if callable(_SMART_ORIGINAL_REGISTER):
            _SMART_ORIGINAL_REGISTER()
        if not _REGISTERED:
            return None
        try:
            _register_smart_overlay_ui_classes(None)
            _register_event_repair_msgbus()
            _schedule_root_panel_registration_refresh(attempts=6, first_interval=0.05, force_first=False)
            _schedule_event_driven_repair('wrapper_register', attempts=3, first_interval=0.01)
        except Exception:
            pass
        try:
            from . import cleanup as _sos_cleanup
            _sos_cleanup.register(getattr(bpy, 'context', None))
        except Exception:
            pass
        if _SMART_COMMON is not None:
            try:
                _SMART_COMMON.register()
            except Exception:
                pass
    finally:
        if _REGISTERED:
            try:
                _ensure_smart_overlay_root_panel_registered(getattr(bpy, 'context', None), force_refresh=False)
                _tag_view3d_sidebar_redraw(getattr(bpy, 'context', None))
            except Exception:
                pass
        if _SMART_COMMON is not None:
            try:
                _SMART_COMMON.end_register()
            except Exception:
                pass
        if _REGISTERED:
            try:
                ctx = getattr(bpy, 'context', None)
                # ``_SMART_COMMON.register()`` may recreate WindowManager RNA
                # storage after the inner register path already restored the
                # authoritative JSON.  Reapply once at the outermost boundary
                # so those fresh defaults cannot replace persisted settings.
                settings.apply_settings(ctx)
                prefs_after_final_settings = integrated_registry.resolve_addon_preferences(ctx)
                if _apply_requested_baseline_recovery(prefs_after_final_settings, ctx):
                    preferences.sync_prop_heatmap_preview_node_from_source(
                        prefs_after_final_settings)
                    _sync_explicit_addon_runtime_toggles(ctx)
                    settings.save_now(ctx, force=True)
            except Exception:
                pass


def unregister():
    try:
        _unregister_event_repair_msgbus()
    except Exception:
        pass
    try:
        from . import cleanup as _sos_cleanup
        _sos_cleanup.unregister()
    except Exception:
        pass
    try:
        _stop_smart_tools_panel_wrapper_repair_timer()
    except Exception:
        pass
    if _SMART_COMMON is not None:
        try:
            _SMART_COMMON.unregister()
        except Exception:
            pass
    if callable(_SMART_ORIGINAL_UNREGISTER):
        _SMART_ORIGINAL_UNREGISTER()
# --- Smart common extension patch END ---

# SmartTools shared specification registration boundary.
from .smarttools_spec_guard import wrap as _smarttools_spec_wrap

register, unregister = _smarttools_spec_wrap(register, unregister)
