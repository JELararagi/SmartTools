# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
"""Keep proxy panel ownership separate from integrated tool registration."""

from contextlib import suppress

from . import loader, ui_runtime


def _cleanup(callback):
    with suppress(Exception):
        callback()


def register():
    _cleanup(ui_runtime.unregister)
    _cleanup(ui_runtime.purge_stale_dynamic_classes)
    loader.register_all()


def unregister():
    _cleanup(ui_runtime.unregister)
    loader.unregister_all()
    _cleanup(ui_runtime.purge_stale_dynamic_classes)
