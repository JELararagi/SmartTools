# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Non-invasive Smart Overlay transform rollback (Blender 5.1 / user_default).

The guard snapshots all objects in bpy.data.objects, including unlinked ones.
It does not adjust a parent, world matrix, basis matrix, geometry, constraints,
animation, or object visibility. It writes only actually modified transform RNA.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import isclose, isfinite
from typing import Any

_EPSILON = 1.0e-7
_VECTOR_SHAPES = {
    'location': 3,
    'scale': 3,
    'rotation_euler': 3,
    'rotation_quaternion': 4,
    'rotation_axis_angle': 4,
    'delta_location': 3,
    'delta_rotation_euler': 3,
    'delta_rotation_quaternion': 4,
    'delta_scale': 3,
}


@dataclass(frozen=True, slots=True)
class _TransformSnapshot:
    obj: Any
    name: str
    pointer: int
    parent_pointer: int
    matrix_basis: Any
    matrix_parent_inverse: Any
    location: tuple[float, ...]
    scale: tuple[float, ...]
    rotation_mode: str
    rotation_euler: tuple[float, ...]
    rotation_quaternion: tuple[float, ...]
    rotation_axis_angle: tuple[float, ...]
    delta_location: tuple[float, ...]
    delta_rotation_euler: tuple[float, ...]
    delta_rotation_quaternion: tuple[float, ...]
    delta_scale: tuple[float, ...]


def _pointer(obj: Any) -> int:
    if obj is None:
        return 0
    try:
        pointer = int(obj.as_pointer())
        return pointer if pointer > 0 else 0
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return 0


def _vector(value: Any, expected_length: int) -> tuple[float, ...]:
    result = tuple(float(component) for component in value)
    if len(result) != expected_length or not all(isfinite(x) for x in result):
        raise ValueError('Invalid transform vector')
    return result


def _matrix_copy(value: Any) -> Any:
    if value is None:
        return None
    copier = getattr(value, 'copy', None)
    if callable(copier):
        return copier()
    return tuple(tuple(float(x) for x in row) for row in value)


def _numbers_equal(a: Any, b: Any) -> bool:
    try:
        left = float(a)
        right = float(b)
        return isfinite(left) and isfinite(right) and isclose(
            left, right, rel_tol=0.0, abs_tol=_EPSILON,
        )
    except (TypeError, ValueError, OverflowError):
        return False


def _sequence_equal(current: Any, expected: tuple[float, ...]) -> bool:
    try:
        actual = tuple(current)
        return len(actual) == len(expected) and all(
            _numbers_equal(a, b) for a, b in zip(actual, expected)
        )
    except (TypeError, AttributeError, ReferenceError, RuntimeError, ValueError):
        return False


def _matrix_equal(current: Any, expected: Any) -> bool:
    if current is None or expected is None:
        return current is None and expected is None
    try:
        left = tuple(tuple(row) for row in current)
        right = tuple(tuple(row) for row in expected)
        return len(left) == len(right) and all(
            len(a) == len(b) and all(_numbers_equal(x, y) for x, y in zip(a, b))
            for a, b in zip(left, right)
        )
    except (TypeError, AttributeError, ReferenceError, RuntimeError, ValueError):
        return False


def _global_objects() -> tuple[Any, ...]:
    try:
        import bpy
        return tuple(bpy.data.objects)
    except (ImportError, AttributeError, ReferenceError, RuntimeError, TypeError):
        return ()


def snapshot_scene_object_transforms(context: Any = None) -> dict[int, _TransformSnapshot]:
    """Capture *all* Blender data objects, not just the active scene.

    The optional context parameter is retained for API compatibility. No
    settings, mesh, scene contents, parent relationship, or RNA is written.
    """
    del context
    snapshots: dict[int, _TransformSnapshot] = {}
    for obj in _global_objects():
        key = _pointer(obj)
        if not key or key in snapshots:
            continue
        try:
            properties = {
                name: _vector(getattr(obj, name), count)
                for name, count in _VECTOR_SHAPES.items()
            }
            record = _TransformSnapshot(
                obj=obj,
                name=str(obj.name),
                pointer=key,
                parent_pointer=_pointer(obj.parent),
                matrix_basis=_matrix_copy(obj.matrix_basis),
                matrix_parent_inverse=_matrix_copy(obj.matrix_parent_inverse),
                rotation_mode=str(obj.rotation_mode),
                **properties,
            )
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError,
                OverflowError):
            # A linked/read-only/expired object must not invalidate the batch.
            continue
        snapshots[key] = record
    return snapshots


def _parent_first(snapshots: list[_TransformSnapshot]) -> list[_TransformSnapshot]:
    """Stable parent-first ordering, even for very deep or malformed chains."""
    index = {snap.pointer: snap for snap in snapshots}
    cached: dict[int, int] = {}

    def depth(snap: _TransformSnapshot) -> int:
        chain: list[_TransformSnapshot] = []
        pending: set[int] = set()
        cursor: _TransformSnapshot | None = snap
        while cursor is not None and cursor.pointer not in cached:
            if cursor.pointer in pending:
                break
            pending.add(cursor.pointer)
            chain.append(cursor)
            cursor = index.get(cursor.parent_pointer)
        level = cached.get(cursor.pointer, -1) if cursor is not None else -1
        for member in reversed(chain):
            level += 1
            cached[member.pointer] = level
        return cached[snap.pointer]

    return sorted(snapshots, key=depth)


def _set_vector_if_changed(obj: Any, name: str, expected: tuple[float, ...]) -> bool:
    try:
        if _sequence_equal(getattr(obj, name), expected):
            return False
        setattr(obj, name, expected)
        return _sequence_equal(getattr(obj, name), expected)
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False


def _set_rotation_mode_if_changed(obj: Any, expected: str) -> bool:
    try:
        if str(obj.rotation_mode) == expected:
            return False
        obj.rotation_mode = expected
        return str(obj.rotation_mode) == expected
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False


def _restore_record(snap: _TransformSnapshot, current_objects: dict[int, Any]) -> bool:
    obj = current_objects.get(snap.pointer)
    if obj is None or _pointer(snap.obj) != snap.pointer or _pointer(obj) != snap.pointer:
        return False
    try:
        # A changed parent often represents an intentional user edit. Never
        # switch its identity or decompose world/local matrices to compensate.
        if _pointer(obj.parent) != snap.parent_pointer:
            return False
    except (AttributeError, ReferenceError, RuntimeError):
        return False

    written = False
    # An inverse-parent change is independent of local transform channels.
    # Assign only if it is really different; no obj.parent or matrix_world set.
    if snap.matrix_parent_inverse is not None:
        try:
            if not _matrix_equal(obj.matrix_parent_inverse, snap.matrix_parent_inverse):
                obj.matrix_parent_inverse = _matrix_copy(snap.matrix_parent_inverse)
                if _matrix_equal(obj.matrix_parent_inverse, snap.matrix_parent_inverse):
                    written = True
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            pass

    written |= _set_rotation_mode_if_changed(obj, snap.rotation_mode)
    # Set the active representation first; restore inactive channels afterward
    # so Euler/Quaternion/Axis-angle values are not lost to mode conversion.
    if snap.rotation_mode == 'QUATERNION':
        primary = 'rotation_quaternion'
    elif snap.rotation_mode == 'AXIS_ANGLE':
        primary = 'rotation_axis_angle'
    else:
        primary = 'rotation_euler'
    order = ('location', 'scale', primary,
             *[n for n in ('rotation_euler', 'rotation_quaternion',
                            'rotation_axis_angle') if n != primary],
             'delta_location', 'delta_rotation_euler',
             'delta_rotation_quaternion', 'delta_scale')
    for name in order:
        written |= _set_vector_if_changed(obj, name, getattr(snap, name))
    return written


def restore_scene_object_transforms(
    snapshot: dict[int, _TransformSnapshot] | None, *, reason: str = '',
) -> int:
    """Return count of restored objects (legacy int API, never a dictionary).

    Repeated calls become no-ops once original transform RNA is recovered.
    Invalid, removed, or reparented objects are skipped, and one RNA failure
    cannot abort recovery of independent fields/objects. Constraints, parent,
    matrix_basis, and matrix_world are deliberately never assigned.
    """
    del reason
    if not isinstance(snapshot, dict) or not snapshot:
        return 0
    live = {_pointer(obj): obj for obj in _global_objects() if _pointer(obj)}
    valid = [record for key, record in snapshot.items()
             if isinstance(record, _TransformSnapshot) and key == record.pointer]
    restored = 0
    for record in _parent_first(valid):
        try:
            if _restore_record(record, live):
                restored += 1
        except Exception:
            continue
    return restored


class ObjectTransformGuard:
    """Restore captured data objects on normal exit and while unwinding errors."""
    __slots__ = ('reason', 'snapshot', '_nested')

    def __init__(self, reason: str = ''):
        self.reason = str(reason or '')
        self.snapshot = None
        self._nested: list[dict[int, _TransformSnapshot]] = []

    def __enter__(self) -> 'ObjectTransformGuard':
        capture = snapshot_scene_object_transforms()
        self._nested.append(capture)
        self.snapshot = capture
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> bool:
        capture = self._nested.pop() if self._nested else self.snapshot
        try:
            restore_scene_object_transforms(capture, reason=self.reason)
        except Exception:
            # A rollback failure must never mask the original exception.
            pass
        finally:
            self.snapshot = self._nested[-1] if self._nested else None
        return False


def guarded_call(func: Any, *args: Any, reason: str = '', **kwargs: Any) -> Any:
    """Invoke function once with an automatic restore, preserving its result."""
    with ObjectTransformGuard(reason):
        return func(*args, **kwargs)