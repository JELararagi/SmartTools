# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import bpy

_EPS = 1.0e-7


@dataclass(slots=True)
class _TransformSnapshot:
    obj: Any
    name: str
    matrix_basis: Any
    matrix_parent_inverse: Any
    location: tuple[float, float, float]
    scale: tuple[float, float, float]
    rotation_mode: str
    rotation_euler: tuple[float, float, float]
    rotation_quaternion: tuple[float, float, float, float]
    rotation_axis_angle: tuple[float, float, float, float]


def _tuple(value, size: int) -> tuple[float, ...]:
    try:
        seq = tuple(float(v) for v in value)
    except Exception:
        seq = ()
    if len(seq) < size:
        seq = seq + (0.0,) * (size - len(seq))
    return seq[:size]


def _copy_matrix(value):
    try:
        return value.copy()
    except Exception:
        return None


def _valid_object(obj) -> bool:
    try:
        if obj is None:
            return False
        _ = obj.name
        if hasattr(obj, 'as_pointer') and int(obj.as_pointer()) == 0:
            return False
        return True
    except Exception:
        return False


def snapshot_scene_object_transforms(context=None) -> dict[int, _TransformSnapshot]:
    """Capture Blender object transforms without reading or writing geometry.

    The snapshot is intentionally limited to Object transform RNA.  It does not
    touch mesh data, modifiers, animation, constraints, or custom properties.
    """
    del context
    out: dict[int, _TransformSnapshot] = {}
    try:
        objects = tuple(getattr(bpy.data, 'objects', ()) or ())
    except Exception:
        objects = ()
    for obj in objects:
        if not _valid_object(obj):
            continue
        try:
            ptr = int(obj.as_pointer())
        except Exception:
            continue
        try:
            snap = _TransformSnapshot(
                obj=obj,
                name=str(getattr(obj, 'name', '') or ''),
                matrix_basis=_copy_matrix(getattr(obj, 'matrix_basis', None)),
                matrix_parent_inverse=_copy_matrix(getattr(obj, 'matrix_parent_inverse', None)),
                location=_tuple(getattr(obj, 'location', (0.0, 0.0, 0.0)), 3),
                scale=_tuple(getattr(obj, 'scale', (1.0, 1.0, 1.0)), 3),
                rotation_mode=str(getattr(obj, 'rotation_mode', 'XYZ') or 'XYZ'),
                rotation_euler=_tuple(getattr(obj, 'rotation_euler', (0.0, 0.0, 0.0)), 3),
                rotation_quaternion=_tuple(getattr(obj, 'rotation_quaternion', (1.0, 0.0, 0.0, 0.0)), 4),
                rotation_axis_angle=_tuple(getattr(obj, 'rotation_axis_angle', (0.0, 0.0, 1.0, 0.0)), 4),
            )
            out[ptr] = snap
        except Exception:
            continue
    return out


def _seq_changed(current, saved: tuple[float, ...]) -> bool:
    try:
        cur = tuple(float(v) for v in current)
    except Exception:
        return False
    if len(cur) != len(saved):
        return True
    return any(abs(a - b) > _EPS for a, b in zip(cur, saved))


def _matrix_changed(current, saved) -> bool:
    if saved is None:
        return False
    try:
        cur_rows = tuple(tuple(float(v) for v in row) for row in current)
        saved_rows = tuple(tuple(float(v) for v in row) for row in saved)
    except Exception:
        return False
    if len(cur_rows) != len(saved_rows):
        return True
    for row_a, row_b in zip(cur_rows, saved_rows):
        if len(row_a) != len(row_b):
            return True
        if any(abs(a - b) > _EPS for a, b in zip(row_a, row_b)):
            return True
    return False


def _object_transform_changed(obj, snap: _TransformSnapshot) -> bool:
    if not _valid_object(obj):
        return False
    try:
        if _matrix_changed(getattr(obj, 'matrix_basis', None), snap.matrix_basis):
            return True
    except Exception:
        pass
    try:
        if _matrix_changed(getattr(obj, 'matrix_parent_inverse', None), snap.matrix_parent_inverse):
            return True
    except Exception:
        pass
    try:
        if _seq_changed(getattr(obj, 'location', ()), snap.location):
            return True
        if _seq_changed(getattr(obj, 'scale', ()), snap.scale):
            return True
        mode = str(getattr(obj, 'rotation_mode', 'XYZ') or 'XYZ')
        if mode != snap.rotation_mode:
            return True
        if mode == 'QUATERNION':
            return _seq_changed(getattr(obj, 'rotation_quaternion', ()), snap.rotation_quaternion)
        if mode == 'AXIS_ANGLE':
            return _seq_changed(getattr(obj, 'rotation_axis_angle', ()), snap.rotation_axis_angle)
        return _seq_changed(getattr(obj, 'rotation_euler', ()), snap.rotation_euler)
    except Exception:
        return False


def _restore_one(snap: _TransformSnapshot) -> bool:
    obj = snap.obj
    if not _valid_object(obj):
        return False
    if not _object_transform_changed(obj, snap):
        return False
    restored = False
    try:
        if snap.matrix_parent_inverse is not None:
            obj.matrix_parent_inverse = snap.matrix_parent_inverse.copy()
            restored = True
    except Exception:
        pass
    try:
        obj.rotation_mode = snap.rotation_mode
    except Exception:
        pass
    try:
        obj.location = snap.location
        restored = True
    except Exception:
        pass
    try:
        obj.scale = snap.scale
        restored = True
    except Exception:
        pass
    try:
        if snap.rotation_mode == 'QUATERNION':
            obj.rotation_quaternion = snap.rotation_quaternion
        elif snap.rotation_mode == 'AXIS_ANGLE':
            obj.rotation_axis_angle = snap.rotation_axis_angle
        else:
            obj.rotation_euler = snap.rotation_euler
        restored = True
    except Exception:
        pass
    try:
        if snap.matrix_basis is not None:
            obj.matrix_basis = snap.matrix_basis.copy()
            restored = True
    except Exception:
        pass
    return restored


def restore_scene_object_transforms(snapshot: dict[int, _TransformSnapshot] | None, *, reason: str = '') -> int:
    """Restore object transforms captured before add-on load/save work.

    This is a defensive guard for file load/save handlers.  Smart Overlay's
    overlays are visual-only; they must never alter object transforms while a
    .blend file is being saved, loaded, or reopened.
    """
    del reason
    if not snapshot:
        return 0
    restored = 0
    for snap in tuple(snapshot.values()):
        try:
            if _restore_one(snap):
                restored += 1
        except Exception:
            continue
    return restored


class ObjectTransformGuard:
    __slots__ = ('reason', 'snapshot')

    def __init__(self, reason: str = ''):
        self.reason = str(reason or '')
        self.snapshot = None

    def __enter__(self):
        self.snapshot = snapshot_scene_object_transforms()
        return self

    def __exit__(self, exc_type, exc, tb):
        restore_scene_object_transforms(self.snapshot, reason=self.reason)
        self.snapshot = None
        return False


def guarded_call(func, *args, reason: str = '', **kwargs):
    with ObjectTransformGuard(reason):
        return func(*args, **kwargs)
