# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

import json
import os
import re
import sys
import time
from pathlib import Path

import bpy
from bpy.app.handlers import persistent
from bpy.props import BoolProperty, StringProperty

try:
    from . import storage as _sos_storage
except Exception:  # pragma: no cover - standalone analysis fallback
    _sos_storage = None

try:
    from . import transform_guard as _sos_transform_guard
except Exception:  # pragma: no cover - standalone analysis fallback
    _sos_transform_guard = None

PACKAGE_ID = 'smart_overlay_suite'
ADDON_NAME = 'Smart_Overlay_Suite'
TOOL_LABEL_EN = 'Smart Overlay'
TOOL_LABEL_JA = 'スマートオーバーレイ'
PANEL_CATEGORY = TOOL_LABEL_EN



def _base_addon_owner_id_candidates() -> tuple[str, ...]:
    """Return every owner id that may identify this extension in Blender 5.1.

    Blender's Workspace > Filter Add-ons system compares ``Panel.bl_owner_id``
    against ``Workspace.owner_ids`` using exact text.  Smart Tools Manager may
    discover this extension either as the full extension module
    (``bl_ext.user_default.smart_overlay_suite``) or as the historical leaf
    module name (``smart_overlay_suite``).  Keep all real aliases available, but
    never include the namespace root ``bl_ext`` by itself; that root is not an
    add-on owner and adding it to the workspace filter can make unrelated
    extension panels pass the owner filter.
    """
    values = []
    try:
        pkg = str(__package__ or '').strip()
    except Exception:
        pkg = ''
    try:
        module_name = str(__name__ or '').strip()
    except Exception:
        module_name = ''
    module_pkg = ''
    if module_name:
        parts = module_name.split('.')
        if len(parts) >= 3 and parts[0] == 'bl_ext':
            module_pkg = '.'.join(parts[:3])
        elif parts:
            module_pkg = parts[0]
    for value in (
        pkg,
        module_pkg,
        str(PACKAGE_ID or ''),
        'bl_ext.user_default.' + PACKAGE_ID,
        'bl_ext.system.' + PACKAGE_ID,
    ):
        text = str(value or '').strip()
        if not text or text == 'bl_ext':
            continue
        if text and text not in values:
            values.append(text)
    return tuple(values)


def _enabled_preference_owner_id() -> str:
    """Return the exact Preferences add-on key when Blender knows it."""
    candidates = set(_base_addon_owner_id_candidates())
    candidate_leafs = {value.rsplit('.', 1)[-1] for value in candidates if value}
    try:
        addons = getattr(getattr(bpy.context, 'preferences', None), 'addons', {})
        for key in getattr(addons, 'keys', lambda: ())():
            text = str(key or '').strip()
            if not text:
                continue
            if text in candidates or text.rsplit('.', 1)[-1] in candidate_leafs:
                return text
    except Exception:
        pass
    return ''


def _workspace_owner_id_match(context=None) -> str:
    """Return the exact current Workspace owner entry for this add-on if present."""
    try:
        ctx = context or getattr(bpy, 'context', None)
        workspace = getattr(ctx, 'workspace', None)
        if workspace is None:
            workspace = getattr(getattr(ctx, 'window', None), 'workspace', None)
        if workspace is None:
            return ''
        owners = []
        for item in getattr(workspace, 'owner_ids', ()) or ():
            try:
                text = str(getattr(item, 'name', '') or '').strip()
            except Exception:
                text = ''
            if text:
                owners.append(text)
        if not owners:
            return ''
        candidates = _base_addon_owner_id_candidates()
        candidate_set = set(candidates)
        for owner in owners:
            if owner in candidate_set:
                return owner
        candidate_leafs = {value.rsplit('.', 1)[-1] for value in candidates if value}
        for owner in owners:
            if owner.rsplit('.', 1)[-1] in candidate_leafs:
                return owner
    except Exception:
        pass
    return ''


def current_addon_owner_id() -> str:
    """Return the preferred stable owner id for Smart Overlay panels.

    Prefer Blender Preferences' exact enabled add-on key, then the currently
    imported extension package.  The imported package must outrank stale
    Workspace.owner_ids aliases; otherwise a user_default install can register
    panels with an obsolete bl_ext.system owner and Blender may hide the Sidebar
    category in owner-filtered workspaces.  All aliases are still synchronized
    into active workspaces by ``sync_smart_tools_manager_workspace_owner_filter``
    so legacy manager caches continue to work.
    """
    preferred_package = ''
    try:
        preferred_package = str(__package__ or '').strip()
    except Exception:
        preferred_package = ''
    if (not preferred_package or preferred_package == 'bl_ext'):
        try:
            module_name = str(__name__ or '').strip()
            parts = module_name.split('.')
            if len(parts) >= 3 and parts[0] == 'bl_ext':
                preferred_package = '.'.join(parts[:3])
        except Exception:
            preferred_package = ''

    pref_owner = _enabled_preference_owner_id()
    if pref_owner and pref_owner == preferred_package:
        return pref_owner
    if preferred_package and preferred_package != 'bl_ext' and preferred_package.startswith('bl_ext.') and preferred_package.endswith('.' + PACKAGE_ID):
        return preferred_package
    for value in (pref_owner, preferred_package, _workspace_owner_id_match()):
        text = str(value or '').strip()
        if text and text != 'bl_ext':
            return text
    return PACKAGE_ID


def current_addon_owner_id_candidates() -> tuple[str, ...]:
    """Owner-id candidates accepted by Blender/Smart Tools Manager filters."""
    values = []
    for value in (
        current_addon_owner_id(),
        *_base_addon_owner_id_candidates(),
        _enabled_preference_owner_id(),
    ):
        text = str(value or '').strip()
        if text and text not in values:
            values.append(text)
    return tuple(values)


_SMART_TOOLS_MANAGER_SETTINGS_CACHE = {
    'time': 0.0,
    'mtime': None,
    'data': None,
    'path': '',
}
_MANAGER_WORKSPACE_ALIASES = {
    'LAYOUT': ('Layout', 'レイアウト'),
    'MODELING': ('Modeling', 'モデリング'),
    'SCULPTING': ('Sculpting', 'スカルプト'),
    'UV_EDITING': ('UV Editing', 'UVエディティング', 'UV編集'),
    'TEXTURE_PAINT': ('Texture Paint', 'テクスチャペイント'),
    'SHADING': ('Shading', 'シェーディング'),
    'ANIMATION': ('Animation', 'アニメーション'),
    'RENDERING': ('Rendering', 'レンダリング'),
    'COMPOSITING': ('Compositing', 'コンポジティング'),
    'GEOMETRY_NODES': ('Geometry Nodes', 'Geometry Node', 'ジオメトリノード'),
    'SCRIPTING': ('Scripting', 'スクリプティング'),
    'ANIMATION_2D': ('2D Animation', '2Dアニメーション'),
    'FULL_CANVAS_2D': ('2D Full Canvas', '2Dフルキャンバス'),
    'MASKING': ('Masking', 'マスキング'),
    'MOTION_TRACKING': ('Motion Tracking', 'モーショントラッキング'),
    'VIDEO_EDITING': ('Video Editing', 'ビデオ編集'),
}
_EDITOR_BY_SPACE = {
    'VIEW_3D': 'VIEW_3D',
    'NODE_EDITOR': 'SHADER_EDITOR',
    'SEQUENCE_EDITOR': 'VIDEO_SEQUENCER',
    'CLIP_EDITOR': 'MOVIE_CLIP_EDITOR',
    'DOPESHEET_EDITOR': 'DOPE_SHEET',
    'GRAPH_EDITOR': 'GRAPH_EDITOR',
    'NLA_EDITOR': 'NLA_EDITOR',
    'TEXT_EDITOR': 'TEXT_EDITOR',
    'FILE_BROWSER': 'FILE_BROWSER',
    'SPREADSHEET': 'SPREADSHEET',
}
_SMART_TOOLS_MANAGER_RUNTIME_API_NAMESPACE_KEY = 'JELARARAGI_SMART_TOOLS_MANAGER_RUNTIME_API_V1'
_SMART_TOOLS_MANAGER_RUNTIME_API_SCHEMA = 1
_SMART_TOOLS_MANAGER_PLACEMENT_API_MIN_VERSION = 3
_SMART_OVERLAY_MANAGER_TOOL_KEY = 'SMART_OVERLAY'
_SMART_TOOLS_MANAGER_RUNTIME_API_CACHE = {
    'identity': None,
    'allowed_fn': None,
    'legacy_rule_fn': None,
    'legacy_editor_order': (),
}


def _smart_tools_manager_active() -> bool:
    names = ('Smart_Tools_Manager', 'smart_tools_manager', 'bl_ext.user_default.smart_tools_manager', 'bl_ext.system.smart_tools_manager')
    try:
        addons = getattr(getattr(bpy.context, 'preferences', None), 'addons', {})
        keys = {str(key or '') for key in getattr(addons, 'keys', lambda: ())()}
        if any(name in keys for name in names):
            return True
    except Exception:
        pass
    try:
        import addon_utils
        for name in names:
            try:
                _default, enabled = addon_utils.check(name)
                if enabled:
                    return True
            except Exception:
                continue
    except Exception:
        pass
    return False


def _smart_tools_manager_settings_path() -> Path | None:
    try:
        folder = bpy.utils.user_resource('CONFIG', path='Smart_Tools_Manager', create=False)
        if folder:
            return Path(folder) / 'Smart_Tools_Manager.json'
    except Exception:
        pass
    try:
        root = Path(bpy.utils.user_resource('CONFIG', create=False) or '')
        if root:
            return root / 'Smart_Tools_Manager' / 'Smart_Tools_Manager.json'
    except Exception:
        pass
    try:
        return Path(bpy.utils.resource_path('USER')) / 'config' / 'Smart_Tools_Manager' / 'Smart_Tools_Manager.json'
    except Exception:
        return None


def _load_smart_tools_manager_settings_cached() -> dict | None:
    try:
        for module_name in (
            'bl_ext.user_default.smart_tools_manager.manager',
            'smart_tools_manager.manager',
        ):
            manager_module = sys.modules.get(module_name)
            if manager_module is None:
                continue
            data = getattr(manager_module, '_settings_cache', None)
            if isinstance(data, dict):
                return data
    except Exception:
        pass

    path = _smart_tools_manager_settings_path()
    if path is None:
        return None
    try:
        path_text = str(path)
        stat = path.stat()
        mtime = float(stat.st_mtime)
    except Exception:
        return None
    now = time.monotonic()
    cache = _SMART_TOOLS_MANAGER_SETTINGS_CACHE
    if cache.get('path') == path_text and cache.get('mtime') == mtime and (now - float(cache.get('time') or 0.0)) < 0.35:
        data = cache.get('data')
        return data if isinstance(data, dict) else None
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        data = None
    cache.update({'time': now, 'mtime': mtime, 'data': data if isinstance(data, dict) else None, 'path': path_text})
    return data if isinstance(data, dict) else None


def _manager_workspace_key_from_name(name: str) -> str | None:
    text = str(name or '').strip()
    if not text:
        return None
    text_lower = text.lower()
    for key, aliases in _MANAGER_WORKSPACE_ALIASES.items():
        if text == key or any(text == alias or text_lower == str(alias).lower() for alias in aliases):
            return key
    return None


def _manager_active_workspace_key(context=None) -> str | None:
    try:
        ctx = context or getattr(bpy, 'context', None)
        for source in (getattr(ctx, 'workspace', None), getattr(getattr(ctx, 'window', None), 'workspace', None)):
            key = _manager_workspace_key_from_name(getattr(source, 'name', ''))
            if key:
                return key
    except Exception:
        pass
    return None


def _manager_workspace_key_for_workspace(workspace) -> str | None:
    try:
        return _manager_workspace_key_from_name(getattr(workspace, 'name', ''))
    except Exception:
        return None


def _manager_editor_key_from_context(context=None) -> str | None:
    try:
        ctx = context or getattr(bpy, 'context', None)
        area = getattr(ctx, 'area', None)
        space = getattr(ctx, 'space_data', None)
        area_type = str(getattr(area, 'type', '') or '')
        space_type = str(getattr(space, 'type', '') or area_type or '')
        if area_type == 'IMAGE_EDITOR' or space_type == 'IMAGE_EDITOR':
            ui_type = str(getattr(space, 'ui_type', '') or '').upper()
            return 'UV_EDITOR' if ui_type == 'UV' else 'IMAGE_EDITOR'
        if area_type == 'NODE_EDITOR' or space_type == 'NODE_EDITOR':
            ui_type = str(getattr(space, 'ui_type', '') or '').upper()
            tree_type = str(getattr(space, 'tree_type', '') or '').lower()
            if ui_type in {'GEOMETRY_NODES', 'GEOMETRY_NODE_EDITOR'} or 'geometry' in tree_type:
                return 'GEOMETRY_NODE_EDITOR'
            if ui_type in {'COMPOSITING', 'COMPOSITOR'} or 'compositor' in tree_type:
                return 'COMPOSITOR'
            if ui_type in {'TEXTURE_NODE_EDITOR', 'TEXTURE'} or 'texture' in tree_type:
                return 'TEXTURE_NODE_EDITOR'
            return 'SHADER_EDITOR'
        if area_type == 'FILE_BROWSER' or space_type == 'FILE_BROWSER':
            return 'ASSET_BROWSER' if getattr(space, 'browse_mode', None) == 'ASSETS' else 'FILE_BROWSER'
        return _EDITOR_BY_SPACE.get(area_type) or _EDITOR_BY_SPACE.get(space_type)
    except Exception:
        return None


def _smart_tools_manager_workspace_rule(workspace_key: str | None, editor_key: str | None = None) -> bool | None:
    if not workspace_key or not _smart_tools_manager_active():
        return None
    # The Manager's committed top-level rule table is the runtime source of
    # truth.  Ask the live Manager first so Smart Overlay does not disagree with
    # its category anchor when a settings file still contains an older or stale
    # ``n_panel.rules`` draft.  That disagreement left the native root panel's
    # poll False while the Manager rule/anchor was True, producing only the
    # translucent "waiting for Blender context" placeholder.
    for module_name in (
        'bl_ext.user_default.smart_tools_manager.manager',
        'bl_ext.system.smart_tools_manager.manager',
        'smart_tools_manager.manager',
    ):
        manager_module = sys.modules.get(module_name)
        rule_value = getattr(manager_module, '_rule_value', None) if manager_module is not None else None
        if not callable(rule_value):
            continue
        try:
            if editor_key:
                if bool(rule_value(workspace_key, editor_key, 'SMART_OVERLAY')):
                    return True
                if editor_key in {'IMAGE_EDITOR', 'UV_EDITOR'}:
                    for fallback in ('UV_EDITOR', 'IMAGE_EDITOR'):
                        if bool(rule_value(workspace_key, fallback, 'SMART_OVERLAY')):
                            return True
                return False
            editor_order = tuple(getattr(manager_module, '_EDITOR_ORDER', ()) or ())
            if editor_order:
                return any(
                    bool(rule_value(workspace_key, editor_name, 'SMART_OVERLAY'))
                    for editor_name in editor_order
                )
        except Exception:
            pass
        break
    data = _load_smart_tools_manager_settings_cached()
    if not isinstance(data, dict):
        return None
    # Current Manager builds evaluate the committed top-level rules at runtime.
    # Fall back to n_panel.rules only for older Manager files that do not have a
    # committed table yet.
    try:
        rules = data.get('rules') if isinstance(data, dict) else None
    except Exception:
        rules = None
    if not isinstance(rules, dict):
        n_panel = data.get('n_panel') if isinstance(data, dict) else None
        rules = n_panel.get('rules') if isinstance(n_panel, dict) else None
    if not isinstance(rules, dict):
        return False
    workspace_rules = rules.get(workspace_key)
    if not isinstance(workspace_rules, dict):
        return False
    if editor_key:
        editor_rules = workspace_rules.get(editor_key)
        if isinstance(editor_rules, dict) and 'SMART_OVERLAY' in editor_rules:
            return bool(editor_rules.get('SMART_OVERLAY'))
        # Image Editor and UV Editor share one Blender space type.  If Blender's
        # context cannot tell them apart during a temporary panel rebuild, accept
        # either explicit rule as enabled so the tab does not disappear.
        if editor_key in {'IMAGE_EDITOR', 'UV_EDITOR'}:
            for fallback in ('UV_EDITOR', 'IMAGE_EDITOR'):
                editor_rules = workspace_rules.get(fallback)
                if isinstance(editor_rules, dict) and bool(editor_rules.get('SMART_OVERLAY')):
                    return True
        return False
    for editor_rules in workspace_rules.values():
        if isinstance(editor_rules, dict) and bool(editor_rules.get('SMART_OVERLAY')):
            return True
    return False


def _manager_public_workspace_runtime_rule(context=None, workspace_key: str | None = None) -> bool | None:
    """Read Manager's pure workspace-OR runtime authority when available.

    Panel visibility remains an editor-cell decision.  This adapter is only for
    Suite runtime/draw/input.  It performs no file I/O, redraw, timer, handler or
    lifecycle mutation and accepts only Manager API v3+ contracts that explicitly
    reserve ``workspace_tool_allowed`` for owner/runtime retention.
    """
    cache = _SMART_TOOLS_MANAGER_RUNTIME_API_CACHE

    def _clear_cache():
        cache.update({
            'identity': None,
            'allowed_fn': None,
            'legacy_rule_fn': None,
            'legacy_editor_order': (),
        })

    def _resolve_public(identity, public_api):
        if cache.get('identity') == identity and callable(cache.get('allowed_fn')):
            return cache.get('allowed_fn')
        if not isinstance(public_api, dict):
            return None
        allowed_fn = public_api.get('workspace_tool_allowed')
        contract_fn = public_api.get('get_placement_contract')
        if not callable(allowed_fn) or not callable(contract_fn):
            return None
        try:
            contract = contract_fn()
            if int(contract.get('api_version', 0) or 0) < _SMART_TOOLS_MANAGER_PLACEMENT_API_MIN_VERSION:
                return None
            if contract.get('workspace_owner_filter_any_editor_on_only') is not True:
                return None
            cache.update({
                'identity': identity,
                'allowed_fn': allowed_fn,
                'legacy_rule_fn': None,
                'legacy_editor_order': (),
            })
            return allowed_fn
        except Exception:
            return None

    record = None
    try:
        namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        record = namespace.get(_SMART_TOOLS_MANAGER_RUNTIME_API_NAMESPACE_KEY) if isinstance(namespace, dict) else None
        if (
            isinstance(record, dict)
            and record.get('schema') == _SMART_TOOLS_MANAGER_RUNTIME_API_SCHEMA
            and record.get('package_id') == 'smart_tools_manager'
            and record.get('status') == 'ACTIVE'
            and isinstance(record.get('generation'), str)
            and bool(record.get('generation', '').strip())
            and type(record.get('revision')) is int
            and record.get('revision', -1) >= 0
        ):
            public_api = record.get('public_api')
            identity = (
                'record', id(record), str(record.get('generation') or ''),
                int(record.get('revision') or 0), id(public_api),
            )
            allowed_fn = _resolve_public(identity, public_api)
            if not callable(allowed_fn):
                _clear_cache()
                return None
            kwargs = {'workspace_key': workspace_key} if workspace_key else {}
            value = allowed_fn(_SMART_OVERLAY_MANAGER_TOOL_KEY, context, **kwargs)
            return value if type(value) is bool else None
    except Exception:
        _clear_cache()
        return None

    # A present but invalid record can contain a stale callable from a retired
    # generation.  Do not fall through to it; fail open until the next explicit
    # Manager/lifecycle event republishes a valid record.
    if record is not None:
        _clear_cache()
        return None

    # Compatibility for an exact already-loaded Manager module during the small
    # register/reload gap before driver_namespace publication.  This is a fixed
    # lookup only: no import, reload, sys.modules scan, disk read or area scan.
    for module_name in (
        'bl_ext.user_default.smart_tools_manager.manager',
        'bl_ext.system.smart_tools_manager.manager',
        'smart_tools_manager.manager',
    ):
        manager_module = sys.modules.get(module_name)
        if manager_module is None:
            continue
        if getattr(manager_module, '_manager_registered', None) is not True:
            _clear_cache()
            return None
        generation = str(getattr(manager_module, '_registration_token', '') or '')
        if not generation:
            _clear_cache()
            return None
        public_api = {
            'workspace_tool_allowed': getattr(manager_module, 'workspace_tool_allowed', None),
            'get_placement_contract': getattr(manager_module, 'get_placement_contract', None),
        }
        identity = ('module', id(manager_module), generation, id(public_api.get('workspace_tool_allowed')))
        allowed_fn = _resolve_public(identity, public_api)
        if callable(allowed_fn):
            try:
                kwargs = {'workspace_key': workspace_key} if workspace_key else {}
                value = allowed_fn(_SMART_OVERLAY_MANAGER_TOOL_KEY, context, **kwargs)
                return value if type(value) is bool else None
            except Exception:
                _clear_cache()
                return None

        # Pre-v3 loaded Manager compatibility uses only its in-memory matrix.
        rule_fn = getattr(manager_module, '_rule_value', None)
        editor_order = tuple(getattr(manager_module, '_EDITOR_ORDER', ()) or ())
        legacy_identity = ('legacy-module', id(manager_module), generation, id(rule_fn), editor_order)
        if callable(rule_fn) and editor_order:
            cache.update({
                'identity': legacy_identity,
                'allowed_fn': None,
                'legacy_rule_fn': rule_fn,
                'legacy_editor_order': editor_order,
            })
            if not workspace_key:
                return None
            try:
                return any(
                    bool(rule_fn(workspace_key, editor_name, _SMART_OVERLAY_MANAGER_TOOL_KEY))
                    for editor_name in editor_order
                )
            except Exception:
                _clear_cache()
                return None
        _clear_cache()
        return None

    _clear_cache()
    return None


def workspace_runtime_allows_addon(context=None, *, workspace_key: str | None = None) -> bool:
    """Return target-workspace Smart Overlay runtime authority.

    One enabled Manager editor cell enables every supported Overlay runtime in
    that workspace.  Explicit all-OFF disables that workspace only.  Manager
    absence, initialization, or a custom/unresolved workspace fails open to the
    add-on's own feature toggles.
    """
    ctx = context or getattr(bpy, 'context', None)
    resolved_workspace = workspace_key or _manager_active_workspace_key(ctx)
    decision = _manager_public_workspace_runtime_rule(ctx, resolved_workspace)
    return True if decision is None else bool(decision)


def smart_tools_manager_rule_allows_context(context=None) -> bool | None:
    workspace_key = _manager_active_workspace_key(context)
    editor_key = _manager_editor_key_from_context(context)
    return _smart_tools_manager_workspace_rule(workspace_key, editor_key)


def _workspace_owner_names(workspace) -> set[str]:
    try:
        return {str(getattr(item, 'name', '') or '').strip() for item in getattr(workspace, 'owner_ids', ()) or () if str(getattr(item, 'name', '') or '').strip()}
    except Exception:
        return set()


def _workspace_add_owner(workspace, owner_id: str) -> bool:
    owner_id = str(owner_id or '').strip()
    if not workspace or not owner_id:
        return False
    try:
        if owner_id in _workspace_owner_names(workspace):
            return False
        workspace.owner_ids.new(owner_id)
        return True
    except Exception:
        try:
            with bpy.context.temp_override(workspace=workspace):
                bpy.ops.wm.owner_enable(owner_id=owner_id)
            return True
        except Exception:
            return False


def _workspace_remove_owner(workspace, owner_id: str) -> bool:
    owner_id = str(owner_id or '').strip()
    if not workspace or not owner_id:
        return False
    try:
        owners = getattr(workspace, 'owner_ids', None)
        if owners is None:
            return False
        item = None
        try:
            item = owners.get(owner_id)
        except Exception:
            item = None
        if item is None:
            try:
                idx = owners.find(owner_id)
                item = owners[idx] if idx >= 0 else None
            except Exception:
                item = None
        if item is None:
            return False
        owners.remove(item)
        return True
    except Exception:
        try:
            with bpy.context.temp_override(workspace=workspace):
                bpy.ops.wm.owner_disable(owner_id=owner_id)
            return True
        except Exception:
            return False


def _smart_tools_manager_has_live_npanel_rules(data: dict | None) -> bool:
    """Return True only when Smart_Tools_Manager provided a usable routing table."""
    try:
        if not isinstance(data, dict):
            return False
        n_panel = data.get('n_panel')
        rules = n_panel.get('rules') if isinstance(n_panel, dict) else None
        if isinstance(rules, dict):
            return True
        return isinstance(data.get('rules'), dict)
    except Exception:
        return False


def _iter_context_visible_workspaces(context=None):
    """Yield workspaces that can currently contribute visible Sidebar panels."""
    seen = set()
    ctx = context or getattr(bpy, 'context', None)
    try:
        workspace = getattr(ctx, 'workspace', None)
        if workspace is not None:
            key = int(getattr(workspace, 'as_pointer', lambda: id(workspace))())
            seen.add(key)
            yield workspace
    except Exception:
        pass
    try:
        wm = getattr(ctx, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            workspace = getattr(window, 'workspace', None)
            if workspace is None:
                continue
            key = int(getattr(workspace, 'as_pointer', lambda: id(workspace))())
            if key in seen:
                continue
            seen.add(key)
            yield workspace
    except Exception:
        pass


def _live_smart_overlay_manager_anchor_owner_ids() -> set[str]:
    """Return owner IDs from currently registered Smart Overlay anchors only.

    Blender can retain unregistered Panel subclasses after an extension reload.
    Reusing metadata from those stale Python objects would reintroduce obsolete
    bare or ``bl_ext.system`` owners even when the live Manager uses the
    canonical user-default owner.
    """
    if not _smart_tools_manager_active():
        return set()
    try:
        stack = list(bpy.types.Panel.__subclasses__())
    except Exception:
        stack = []
    seen = set()
    owners = set()
    while stack:
        cls = stack.pop()
        ident = id(cls)
        if ident in seen:
            continue
        seen.add(ident)
        try:
            stack.extend(cls.__subclasses__())
        except Exception:
            pass
        try:
            if not bool(getattr(cls, '_smart_tools_manager_anchor', False)):
                continue
            if str(getattr(cls, '_smart_tools_manager_tool_key', '') or '') != 'SMART_OVERLAY':
                continue
            if str(getattr(cls, 'bl_region_type', '') or '') != 'UI':
                continue
            class_name = str(getattr(cls, '__name__', '') or '')
            if not class_name or getattr(bpy.types, class_name, None) is not cls:
                continue
            if not bool(getattr(cls, 'is_registered', False)):
                continue
            owner_id = str(getattr(cls, 'bl_owner_id', '') or '').strip()
            if not owner_id or owner_id == 'bl_ext':
                continue
            if owner_id.rsplit('.', 1)[-1].casefold() != PACKAGE_ID.casefold():
                continue
            owners.add(owner_id)
        except Exception:
            continue
    return owners


def sync_smart_tools_manager_workspace_owner_filter(context=None) -> bool:
    """Repair Smart Overlay's Workspace.owner_ids entry without editing manager data.

    Blender hides Panels whose ``bl_owner_id`` is absent from an enabled
    Workspace > Filter Add-ons list.  Smart_Tools_Manager can keep a category tab
    anchor visible while the real Smart Overlay root panel is filtered out,
    especially in existing blend files whose workspace owner list predates the
    current extension owner id.  This function updates only Smart Overlay owner
    entries inside Blender workspaces.  It never edits Smart_Tools_Manager files.

    Policy:
    * explicit Smart_Tools_Manager ON  -> keep the installed owner and any live
      Manager-anchor owner, then remove stale aliases
    * explicit Smart_Tools_Manager OFF -> remove every Smart Overlay owner
    * standalone with filtering ON     -> keep only the installed owner
    * standalone with filtering OFF    -> leave Blender's filter state/list alone
    """
    changed = False
    preferred = _enabled_preference_owner_id() or current_addon_owner_id()
    if not preferred or preferred == 'bl_ext':
        preferred = PACKAGE_ID
    live_anchor_owners = _live_smart_overlay_manager_anchor_owner_ids()

    manager_active = _smart_tools_manager_active()
    data = _load_smart_tools_manager_settings_cached() if manager_active else None
    has_rules = _smart_tools_manager_has_live_npanel_rules(data)

    if has_rules:
        try:
            workspaces = list(getattr(bpy.data, 'workspaces', ()) or [])
        except Exception:
            workspaces = []
    else:
        workspaces = list(_iter_context_visible_workspaces(context))
        if not workspaces:
            try:
                workspaces = list(getattr(bpy.data, 'workspaces', ()) or [])
            except Exception:
                workspaces = []

    for workspace in workspaces:
        workspace_key = _manager_workspace_key_for_workspace(workspace)
        if has_rules:
            # Manager itself skips user-created workspaces that do not map to a
            # catalog key.  Do the same here; absence of a key is not an explicit
            # Smart Overlay OFF rule and must not delete the workspace's owner.
            if not workspace_key:
                continue
            enabled = bool(_smart_tools_manager_workspace_rule(workspace_key, None))
        else:
            # No explicit Smart_Tools_Manager routing table exists.  If Smart
            # Overlay itself is enabled, make the current N-panel root visible in
            # owner-filtered workspaces instead of leaving only stale anchors.
            enabled = True

        try:
            filtering_enabled = bool(getattr(workspace, 'use_filter_by_owner', False))
        except Exception:
            filtering_enabled = False

        # An unfiltered standalone workspace already shows the native panel.
        # Do not enable Blender's global workspace add-on filter from this Suite;
        # doing so can hide unrelated third-party panels.
        if not has_rules and not filtering_enabled:
            continue

        owners = _workspace_owner_names(workspace)
        matched = {
            owner
            for owner in owners
            if owner.rsplit('.', 1)[-1].casefold() == PACKAGE_ID.casefold()
        }

        if enabled:
            desired = {
                owner_id
                for owner_id in ({preferred} | live_anchor_owners)
                if owner_id and owner_id != 'bl_ext'
                and owner_id.rsplit('.', 1)[-1].casefold() == PACKAGE_ID.casefold()
            }
            # Add desired owners before removing stale aliases so a filtered
            # workspace never has a frame with no visible Overlay owner.
            for owner_id in sorted(desired - owners):
                if owner_id:
                    changed |= _workspace_add_owner(workspace, owner_id)
                    owners.add(owner_id)
            for owner in sorted(matched - desired):
                changed |= _workspace_remove_owner(workspace, owner)
        else:
            for owner in sorted(matched):
                changed |= _workspace_remove_owner(workspace, owner)
    return bool(changed)


def workspace_filter_allows_addon(context=None) -> bool:
    """Return False only when Blender/Smart Tools Manager hides this add-on.

    Smart Tools Manager uses Blender's Workspace > Filter Add-ons owner list to
    route Smart Tool visibility without unregistering add-ons. Smart Overlay's
    draw/runtime code must obey that same owner list so a manager-side OFF state
    is truly silent, while an ON state keeps the N-panel tab and overlay runtime
    available. If owner filtering is disabled and Smart Tools Manager is not
    actively routing this workspace, the add-on is allowed as normal standalone
    Smart Overlay.
    """
    manager_rule = smart_tools_manager_rule_allows_context(context)
    if manager_rule is not None:
        return bool(manager_rule)
    try:
        ctx = context or getattr(bpy, 'context', None)
        workspace = getattr(ctx, 'workspace', None)
        if workspace is None:
            return True
        if not bool(getattr(workspace, 'use_filter_by_owner', False)):
            return True
        owners = _workspace_owner_names(workspace)
        candidates = {value for value in current_addon_owner_id_candidates() if value and value != 'bl_ext'}
        if owners and owners.intersection(candidates):
            return True
        owner_leafs = {value.rsplit('.', 1)[-1] for value in owners}
        candidate_leafs = {value.rsplit('.', 1)[-1] for value in candidates}
        if owner_leafs.intersection(candidate_leafs):
            return True
        # If there is no explicit manager rule, lack of owner id is a stale
        # workspace-filter state rather than an OFF command.  Return True so
        # runtime/panel code stays alive while the owner sync timer repairs the
        # actual Workspace.owner_ids list.
        return True
    except Exception:
        return True


def visible_window_view3d_runtime_allowed(context=None) -> bool:
    """Return the shared Mesh/Curve runtime residency decision.

    Manager panel rules are per cell, while Overlay handlers are process-shared.
    At explicit lifecycle/Manager events, keep those handlers resident whenever
    any visible window workspace has Smart Overlay ON in any supported editor.
    Target draw/input callbacks independently call
    :func:`workspace_runtime_allows_addon` for their own workspace.  This function
    is never a draw callback and performs no file I/O or registration mutation.
    """
    ctx = context or getattr(bpy, 'context', None)
    try:
        manager_active = bool(_smart_tools_manager_active())
    except Exception:
        manager_active = False
    if not manager_active:
        return bool(workspace_filter_allows_addon(ctx))

    explicit_seen = False
    seen = set()
    try:
        wm = getattr(ctx, 'window_manager', None)
        windows = tuple(getattr(wm, 'windows', ()) or ())
    except Exception:
        windows = ()
    for window in windows:
        try:
            workspace = getattr(window, 'workspace', None)
            if workspace is None:
                continue
            ptr = int(getattr(workspace, 'as_pointer', lambda: id(workspace))())
            if ptr in seen:
                continue
            seen.add(ptr)
            workspace_key = _manager_workspace_key_for_workspace(workspace)
            if not workspace_key:
                continue
            rule = _manager_public_workspace_runtime_rule(ctx, workspace_key)
            if rule is None:
                # Manager unavailable/not ready is not an explicit all-OFF rule.
                return True
            explicit_seen = True
            if bool(rule):
                return True
        except Exception:
            continue
    if explicit_seen:
        return False
    # During load/reload Manager can be active before its rule cache is ready.
    # Absence of an explicit rule is not an OFF command; preserve the prior
    # standalone/owner-filter behavior instead of tearing down live handlers.
    return bool(workspace_filter_allows_addon(ctx))


def workspace_filter_allows_addon_runtime(context=None, *, cross_editor: bool = False) -> bool:
    """Return whether Smart Overlay runtime may stay active in this workspace.

    Panel visibility is editor-specific when Smart Tools Manager routes tabs, but
    draw/runtime features can legitimately be configured from the 3D View N-panel
    and draw in another editor such as the UV Editor.  For cross-editor runtimes,
    treat Smart Overlay as enabled when the current workspace has SMART_OVERLAY
    enabled in any editor.  If the manager disables Smart Overlay everywhere in
    the workspace, or Blender owner filtering excludes this add-on, the runtime is
    fully disabled.
    """
    try:
        if cross_editor:
            return bool(workspace_runtime_allows_addon(context))
    except Exception:
        pass
    return workspace_filter_allows_addon(context)


def apply_panel_owner_id(cls) -> None:
    """Attach the current workspace Filter Add-ons owner id to a Panel class."""
    try:
        if isinstance(cls, type) and issubclass(cls, bpy.types.Panel):
            setattr(cls, 'bl_owner_id', current_addon_owner_id())
    except Exception:
        pass

_ALWAYS_ON_PROP = PACKAGE_ID + '_always_on_enabled'
_LEGACY_ALWAYS_ON_PANEL_IDNAME = 'SMART_OVERLAY_PT_always_on'
_STORAGE_DIRNAME = 'user_data'

_PREVIEW_COLLECTION = None
_REGISTERED_CLASSES = []
_PATCHED_PANELS = []
_PATCHED_PREFERENCES = []
_PATCHED_POLLS = []
_ORIGINAL_REGISTER_CLASS = None
_REGISTER_PATCH_DEPTH = 0
_AUTOSAVE_FINGERPRINT = ''
_LOADED_SETTINGS = {}
_TRANSFORM_RNA_NAMES = {'location', 'rotation', 'rotation_euler', 'rotation_quaternion', 'rotation_axis_angle', 'scale', 'matrix_world', 'matrix_local', 'matrix_basis', 'matrix_parent_inverse', 'dimensions'}

_TRANSLATIONS = {
    ('*', 'Help'): 'ヘルプ',
    ('*', 'Open Help'): 'ヘルプを開く',
    ('*', 'Feature Overview'): '機能概要',
    ('*', 'Usage'): '使用方法',
    ('*', 'Settings'): '設定',
    ('*', 'Commands'): 'コマンド',
    ('*', 'Always-on Toggle'): '常時機能切り替え',
    ('*', 'Enabled'): '有効',
    ('*', 'Disabled'): '無効',
    ('*', 'Save Preferences'): 'プリファレンスを保存',
    ('*', 'Settings are managed in the N-panel.'): '設定はNパネルで管理します。',
    ('*', 'Open the 3D View Sidebar and use this tool tab.'): '3Dビューのサイドバーを開き、このツールのタブを使用してください。',
    ('*', 'Help topic'): 'ヘルプ項目',
    ('*', 'Internal key that selects which Smart Overlay help page opens. This is set by the help button automatically and does not need manual editing.'): 'どのSmart Overlayヘルプページを開くかを指定する内部キーです。ヘルプボタンが自動設定するため、手動編集は不要です。',
    ('*', 'Tool alias'): 'ツール識別名',
    ('*', 'Internal tool group key used when saving an always-on toggle. This is assigned by the button that was clicked.'): '常時機能切り替えを保存する時に使用する内部ツールグループキーです。クリックしたボタンが自動設定します。',
    ('*', 'Feature key'): '機能キー',
    ('*', 'Internal feature key used when saving an always-on toggle. This identifies the exact runtime feature to enable or disable.'): '常時機能切り替えを保存する時に使用する内部機能キーです。有効または無効にする常駐機能を識別します。',
    ('*', 'Enabled state'): '有効状態',
    ('*', 'Target state to save for the selected always-on feature. On keeps the feature active; off stops its background processing.'): '選択した常時機能へ保存する状態です。オンは機能を動かし続け、オフは裏で動く処理を止めます。',
    ('*', TOOL_LABEL_EN): TOOL_LABEL_JA,
}


def _ui_is_japanese(context=None):
    try:
        ctx = context or bpy.context
        view = getattr(getattr(ctx, 'preferences', None), 'view', None)
        if view is not None and not bool(getattr(view, 'use_translate_interface', True)):
            return False
        language = str(getattr(view, 'language', '') or '') if view is not None else ''
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '')
        raw = (locale or language).lower()
        return raw.startswith('ja')
    except Exception:
        return False


def text(en, ja=None, context=None):
    return str(ja if (ja is not None and _ui_is_japanese(context)) else en)


def package_root():
    return Path(__file__).resolve().parent


def storage_root(create=True):
    # Prefer the shared storage resolver so every generated file created by this
    # compatibility layer stays under Blender's versioned extensions/user_default
    # repository, even when the source folder name differs from the manifest id.
    if _sos_storage is not None:
        try:
            return _sos_storage.user_data_dir(create=create)
        except Exception:
            pass
    root = package_root() / _STORAGE_DIRNAME
    if create:
        try:
            root.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return root


def storage_path(*parts, create_parent=True):
    clean_parts = []
    for part in parts:
        value = str(part or '').replace('\\', '/').strip('/')
        if not value or value in {'.', '..'}:
            continue
        for piece in value.split('/'):
            if piece and piece not in {'.', '..'}:
                clean_parts.append(piece)
    path = storage_root(True).joinpath(*clean_parts)
    if create_parent:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path


def settings_path():
    return storage_path('settings', 'n_panel_settings.json')


def _load_previews():
    global _PREVIEW_COLLECTION
    if _PREVIEW_COLLECTION is not None:
        return _PREVIEW_COLLECTION
    try:
        import bpy.utils.previews
        pcoll = bpy.utils.previews.new()
        icons_dir = package_root() / 'icon'
        preview_paths = {
            'header': 'text_header_font',
            'help': 'help_question',
        }
        for name, icon_name in preview_paths.items():
            path = icons_dir / (icon_name + '.png')
            if path.exists():
                try:
                    pcoll.load(name, str(path), 'IMAGE')
                except Exception:
                    pass
        _PREVIEW_COLLECTION = pcoll
    except Exception:
        _PREVIEW_COLLECTION = None
    return _PREVIEW_COLLECTION


def icon_value(name, fallback=0):
    try:
        from . import icons as _sos_icons
        value = int(_sos_icons.icon_value(str(name or ''), '') or 0)
        if value:
            return value
    except Exception:
        pass
    pcoll = _load_previews()
    try:
        item = pcoll.get(str(name)) if pcoll is not None else None
        return int(getattr(item, 'icon_id', fallback) or fallback)
    except Exception:
        return fallback


def _remove_previews():
    global _PREVIEW_COLLECTION
    if _PREVIEW_COLLECTION is None:
        return
    try:
        import bpy.utils.previews
        bpy.utils.previews.remove(_PREVIEW_COLLECTION)
    except Exception:
        pass
    _PREVIEW_COLLECTION = None


def _translation_payload():
    data = dict(_TRANSLATIONS)
    try:
        from . import language_extra
        extra = getattr(language_extra, 'EXTRA_TRANSLATIONS', {})
        if isinstance(extra, dict):
            data.update(extra)
    except Exception:
        pass
    return {'ja_JP': data}


def _wrap_lines(value, width_px):
    import textwrap
    text_value = str(value or '').replace('\r\n', '\n').replace('\r', '\n')
    # Approximate Blender UI label width.  This wraps only when the line would
    # exceed the popup width rather than at a fixed text width.
    chars = max(26, min(160, int(max(260, width_px) / 7)))
    lines = []
    for para in text_value.split('\n'):
        raw = para.strip()
        if not raw:
            lines.append('')
            continue
        wrapped = textwrap.wrap(raw, width=chars, break_long_words=False, break_on_hyphens=False)
        lines.extend(wrapped or [raw])
    return lines


def _draw_wrapped(layout, context, value, icon='NONE'):
    try:
        width = int(getattr(getattr(context, 'region', None), 'width', 620) or 620)
    except Exception:
        width = 620
    first = True
    for line in _wrap_lines(value, width):
        if not line:
            layout.separator(factor=0.35)
        elif first and icon != 'NONE':
            layout.label(text=line, icon=icon)
            first = False
        else:
            layout.label(text=line)
            first = False


def _group_text_list(group, key_en, key_ja, context=None):
    values = group.get(key_ja if _ui_is_japanese(context) else key_en) or []
    if isinstance(values, str):
        return [values]
    if isinstance(values, (list, tuple)):
        return [str(v) for v in values]
    return []


class SMART_OVERLAY_OT_open_help(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.open_help'
    bl_label = 'Open Help'
    bl_description = 'Open the detailed help popup for this tool group.'

    topic: StringProperty(
        name='Help topic',
        description='Internal key that selects which Smart Overlay help page opens. This is set by the help button automatically and does not need manual editing.',
        default='overview',
        options={'SKIP_SAVE'},
    )

    def invoke(self, context, event):
        try:
            return context.window_manager.invoke_popup(self, width=680)
        except Exception:
            return self.execute(context)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        topic = str(getattr(self, 'topic', '') or 'overview')
        topic_aliases = {
            'VIEW3D_PT_smart_measure_grid_overlay': 'smart_measure_grid',
            'VIEW3D_PT_idv_settings': 'image_dimensions',
            'SMART_MEASURE_PT_Edit': 'smart_measure_items',
            'SMART_MEASURE_PT_Main': 'smart_measure_tools',
            'SMART_MEASURE_PT_Conf': 'smart_measure_configuration',
            'SMART_MEASURE_PT_Render': 'smart_measure_render',
            'VIEW3D_PT_silhouette': 'silhouette',
            'VIEW3D_PT_sos_root': 'overview',
        }
        mapped_topic = topic_aliases.get(topic, topic)
        try:
            from . import help_content
            if help_content.has_topic(mapped_topic):
                help_content.draw_help(layout, context, mapped_topic, popup_width_px=680)
                return
        except Exception:
            pass
        try:
            from . import guide
            group = guide.get_group(topic)
        except Exception:
            group = {
                'title_en': TOOL_LABEL_EN + ' Help',
                'title_ja': TOOL_LABEL_JA + ' ヘルプ',
                'overview_en': ['The help catalog could not be loaded.'],
                'overview_ja': ['ヘルプカタログを読み込めませんでした。'],
                'usage_en': [],
                'usage_ja': [],
                'settings': [],
                'operators': [],
            }
        title = group.get('title_ja' if _ui_is_japanese(context) else 'title_en') or TOOL_LABEL_EN
        row = layout.row(align=True)
        row.label(text=str(title), icon='QUESTION')
        layout.separator()
        box = layout.box()
        box.label(text=text('Feature Overview', '機能概要', context), icon='NONE')
        for item in _group_text_list(group, 'overview_en', 'overview_ja', context):
            _draw_wrapped(box, context, item)
        box = layout.box()
        box.label(text=text('Usage', '使用方法', context), icon='PLAY')
        for item in _group_text_list(group, 'usage_en', 'usage_ja', context):
            _draw_wrapped(box, context, item)
        settings = group.get('settings') or []
        ops = group.get('operators') or []
        box = layout.box()
        box.label(text=text('Settings', '設定項目', context), icon='PREFERENCES')
        if not settings and not ops:
            _draw_wrapped(box, context, text(
                'No individual settings were detected for this group. Use the visible controls and their tooltips for short descriptions.',
                'このグループ専用の設定項目は検出されませんでした。表示されている各コントロールとツールチップを確認してください。',
                context,
            ))
        for item in settings[:240]:
            name = item.get('name_ja' if _ui_is_japanese(context) else 'name_en') or item.get('key') or ''
            desc = item.get('description_ja' if _ui_is_japanese(context) else 'description_en') or ''
            _draw_wrapped(box, context, '• ' + str(name) + ': ' + str(desc))
        if ops:
            cmd_box = layout.box()
            cmd_box.label(text=text('Commands', 'コマンド', context), icon='TOOL_SETTINGS')
            for item in ops[:240]:
                name = item.get('name_ja' if _ui_is_japanese(context) else 'name_en') or item.get('key') or ''
                desc = item.get('description_ja' if _ui_is_japanese(context) else 'description_en') or ''
                _draw_wrapped(cmd_box, context, '• ' + str(name) + ': ' + str(desc))


class SMART_OVERLAY_OT_set_always_on(bpy.types.Operator):
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'
    bl_idname = PACKAGE_ID + '.set_always_on'
    bl_label = 'Always-on Toggle'
    bl_description = 'Set an always-on feature to enabled or disabled and save the N-panel setting immediately.'

    alias: StringProperty(
        name='Tool alias',
        description='Internal tool group key used when saving an always-on toggle. This is assigned by the button that was clicked.',
        default='',
        options={'SKIP_SAVE'},
    )
    feature_key: StringProperty(
        name='Feature key',
        description='Internal feature key used when saving an always-on toggle. This identifies the exact runtime feature to enable or disable.',
        default='',
        options={'SKIP_SAVE'},
    )
    enabled: BoolProperty(
        name='Enabled state',
        description='Target state to save for the selected always-on feature. On keeps the feature active; off stops its background processing.',
        default=False,
        options={'SKIP_SAVE'},
    )

    def execute(self, context):
        done = False
        alias = str(getattr(self, 'alias', '') or '')
        feature_key = str(getattr(self, 'feature_key', '') or '')
        if alias and feature_key:
            try:
                from . import feature_toggle
                setter = getattr(feature_toggle, 'set_feature_enabled', None)
                if callable(setter):
                    done = bool(setter(alias, feature_key, bool(self.enabled)))
            except Exception as exc:
                self.report({'WARNING'}, text('Failed to change the setting.', '設定を変更できませんでした。', context))
        if not done:
            try:
                setattr(context.window_manager, _ALWAYS_ON_PROP, bool(self.enabled))
                done = True
            except Exception as exc:
                self.report({'WARNING'}, text('Failed to change the setting.', '設定を変更できませんでした。', context))
        try:
            save_persistent_settings(context, force=True)
        except Exception:
            pass
        return {'FINISHED'}


class SMART_OVERLAY_OT_save_preferences(bpy.types.Operator):
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'
    bl_idname = PACKAGE_ID + '.save_preferences'
    bl_label = 'Save Preferences'
    bl_description = 'Save the current N-panel settings and ask Blender to save user preferences.'

    def execute(self, context):
        save_persistent_settings(context, force=True)
        try:
            from . import settings as _sos_settings
            _sos_settings.save_now(context)
        except Exception:
            pass
        try:
            bpy.ops.wm.save_userpref()
        except Exception:
            pass
        try:
            from . import settings as _sos_settings
            _sos_settings.save_now(context)
        except Exception:
            pass
        self.report({'INFO'}, text('Preferences saved.', 'プリファレンスを保存しました。', context))
        return {'FINISHED'}


# Standalone Always-on Toggle panel intentionally removed. The visible
# Always-on Toggle UI is drawn only inside the root Smart Overlay N-panel.


def _feature_entries():
    try:
        from . import feature_toggle
        entries_fn = getattr(feature_toggle, 'feature_entries', None)
        aliases_fn = getattr(feature_toggle, 'all_feature_aliases', None)
        if callable(entries_fn):
            aliases = list(aliases_fn()) if callable(aliases_fn) else []
            if aliases:
                out = []
                for alias in aliases:
                    try:
                        out.extend(list(entries_fn(alias)))
                    except Exception:
                        pass
                return out
            return list(entries_fn())
    except Exception:
        pass
    return []


def _entry_text(entry, key_en, key_ja, fallback='', context=None):
    if _ui_is_japanese(context):
        value = entry.get(key_ja) or entry.get(key_en) or fallback
    else:
        value = entry.get(key_en) or entry.get(key_ja) or fallback
    return str(value or '').strip()


def draw_always_on_panel(layout, context):
    col = layout.column(align=True)
    entries = _feature_entries()
    if entries:
        for item in entries:
            alias = str(item.get('alias') or '')
            feature_key = str(item.get('key') or item.get('feature_key') or '')
            label = _entry_text(item, 'label_en', 'label_ja', feature_key or TOOL_LABEL_EN, context)
            enabled = bool(item.get('enabled'))
            row = col.row(align=True)
            row.label(text=label)
            op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
            op.alias = alias
            op.feature_key = feature_key
            op.enabled = True
            op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
            op.alias = alias
            op.feature_key = feature_key
            op.enabled = False
        return
    enabled = bool(getattr(context.window_manager, _ALWAYS_ON_PROP, False))
    row = col.row(align=True)
    row.label(text=TOOL_LABEL_EN)
    op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
    op.enabled = True
    op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
    op.enabled = False


def _module_prefix():
    package = str(__package__ or '').strip()
    return package or PACKAGE_ID


def _same_package_class(cls):
    module_name = str(getattr(cls, '__module__', '') or '')
    prefix = _module_prefix()
    return bool(prefix and (module_name == prefix or module_name.startswith(prefix + '.')))


def _clean_label(label):
    raw = str(label or '').strip()
    if not raw:
        return raw
    for token in (' Suite', '_Suite', ' Toolset'):
        raw = raw.replace(token, '')
    if raw == ADDON_NAME or raw.replace('_', ' ') == ADDON_NAME.replace('_', ' '):
        return TOOL_LABEL_EN
    return raw


def _old_generated_name(name):
    text_value = str(name or '')
    upper = text_value.upper()
    return (
        '_SUITE_OT_OPEN_HELP' in upper or
        '_SUITE_OT_SET_ALWAYS_ON' in upper or
        '_SUITE_PT_ROOT' in upper or
        '_SUITE_PT_ALWAYS_ON' in upper
    )


def _materialize_annotations(cls):
    if not isinstance(cls, type):
        return cls
    try:
        annotations = dict(getattr(cls, '__annotations__', {}) or {})
    except Exception:
        annotations = {}
    module = sys.modules.get(str(getattr(cls, '__module__', '') or ''))
    namespace = {}
    if module is not None:
        try:
            namespace.update(getattr(module, '__dict__', {}) or {})
        except Exception:
            pass
    namespace.setdefault('bpy', bpy)
    prop_names = (
        'BoolProperty', 'BoolVectorProperty', 'CollectionProperty', 'EnumProperty',
        'FloatProperty', 'FloatVectorProperty', 'IntProperty', 'IntVectorProperty',
        'PointerProperty', 'StringProperty',
    )
    for prop_name in prop_names:
        try:
            namespace[prop_name] = getattr(bpy.props, prop_name)
        except Exception:
            pass
    changed = False
    for name, value in list(annotations.items()):
        if isinstance(value, str) and 'Property' in value and '(' in value:
            expr = value.strip().replace('bpy.props.', '')
            try:
                annotations[name] = eval(expr, namespace, namespace)
                changed = True
            except Exception:
                pass
    try:
        is_operator = issubclass(cls, bpy.types.Operator)
    except Exception:
        is_operator = False
    if is_operator:
        # Blender UI code frequently assigns these operator properties from
        # buttons. If a legacy class forgot to declare them, adding harmless
        # saved-skipped string properties prevents "property not found" warnings.
        for prop_name in ('mode', 'action', 'topic'):
            if prop_name not in annotations:
                try:
                    annotations[prop_name] = bpy.props.StringProperty(default='', options={'SKIP_SAVE'})
                    changed = True
                except Exception:
                    pass
    if changed:
        try:
            setattr(cls, '__annotations__', annotations)
        except Exception:
            pass
    return cls


def _safe_unregister_class(cls):
    try:
        bpy.utils.unregister_class(cls)
        return True
    except Exception:
        return False


def _register_class_wrapper(cls):
    _materialize_annotations(cls)
    try:
        from . import undo_support
        undo_support.prepare_operator_class(cls)
    except Exception:
        pass
    try:
        existing = getattr(bpy.types, str(getattr(cls, '__name__', '') or ''), None)
        if isinstance(existing, type) and existing is not cls:
            if _same_package_class(existing) or _old_generated_name(getattr(existing, '__name__', '')):
                _safe_unregister_class(existing)
    except Exception:
        pass
    try:
        return _ORIGINAL_REGISTER_CLASS(cls)
    except ValueError:
        # Already registered: this normally means Blender kept a class from a
        # failed previous load. Try one clean unregister/register cycle.
        try:
            existing = getattr(bpy.types, str(getattr(cls, '__name__', '') or ''), None)
            if isinstance(existing, type):
                _safe_unregister_class(existing)
        except Exception:
            pass
        return _ORIGINAL_REGISTER_CLASS(cls)


def begin_register():
    global _ORIGINAL_REGISTER_CLASS, _REGISTER_PATCH_DEPTH
    _REGISTER_PATCH_DEPTH += 1
    if _ORIGINAL_REGISTER_CLASS is not None:
        return
    try:
        _ORIGINAL_REGISTER_CLASS = bpy.utils.register_class
        bpy.utils.register_class = _register_class_wrapper
    except Exception:
        _ORIGINAL_REGISTER_CLASS = None


def end_register():
    global _ORIGINAL_REGISTER_CLASS, _REGISTER_PATCH_DEPTH
    _REGISTER_PATCH_DEPTH = max(0, _REGISTER_PATCH_DEPTH - 1)
    if _REGISTER_PATCH_DEPTH > 0:
        return
    if _ORIGINAL_REGISTER_CLASS is not None:
        try:
            bpy.utils.register_class = _ORIGINAL_REGISTER_CLASS
        except Exception:
            pass
    _ORIGINAL_REGISTER_CLASS = None


def _iter_relevant_panels():
    prefix = _module_prefix()
    values = []
    try:
        for name in dir(bpy.types):
            try:
                values.append(getattr(bpy.types, name))
            except Exception:
                pass
    except Exception:
        values = []
    seen = set()
    for cls in values:
        if not isinstance(cls, type):
            continue
        ident = id(cls)
        if ident in seen:
            continue
        seen.add(ident)
        try:
            if not issubclass(cls, bpy.types.Panel):
                continue
        except Exception:
            continue
        module_name = str(getattr(cls, '__module__', '') or '')
        if prefix and not (module_name == prefix or module_name.startswith(prefix + '.')):
            continue
        yield cls


def _is_always_panel(cls):
    value = ' '.join((
        str(getattr(cls, '__name__', '') or ''),
        str(getattr(cls, 'bl_idname', '') or ''),
        str(getattr(cls, 'bl_label', '') or ''),
    )).lower()
    return ('always' in value or '常時' in value or 'persistent' in value) and 'catalog' not in value



def _unregister_legacy_always_on_panel():
    """Remove the old standalone Always-on Toggle N-panel if it is still registered."""
    legacy_cls = None
    try:
        legacy_cls = getattr(bpy.types, _LEGACY_ALWAYS_ON_PANEL_IDNAME, None)
    except Exception:
        legacy_cls = None
    if legacy_cls is None:
        return
    try:
        bpy.utils.unregister_class(legacy_cls)
        return
    except Exception:
        pass
    # If Blender refuses to unregister a stale class during live reload, hide it
    # so only the root Smart Overlay panel remains visible.
    try:
        legacy_cls.poll = classmethod(lambda _cls, context: False)
    except Exception:
        pass


def _patch_panel_headers():
    for cls in _iter_relevant_panels():
        try:
            cls.bl_category = PANEL_CATEGORY
        except Exception:
            pass
        try:
            apply_panel_owner_id(cls)
        except Exception:
            pass
        try:
            label = str(getattr(cls, 'bl_label', '') or '')
            clean = _clean_label(label)
            if clean and clean != label:
                cls.bl_label = clean
        except Exception:
            pass
        if _is_always_panel(cls):
            try:
                original_poll = getattr(cls, 'poll', None)
                cls.poll = classmethod(lambda _cls, context: False)
                _PATCHED_POLLS.append((cls, original_poll))
            except Exception:
                pass
            continue
        # Do not place a help icon in Blender's native N-panel title/header
        # for the main Smart Overlay panel. Section-level help buttons remain
        # available inside the panel body.
        try:
            if str(getattr(cls, 'bl_idname', '') or '') == 'VIEW3D_PT_sos_root':
                continue
        except Exception:
            pass
        if getattr(cls, '_smart_common_header_patched', False):
            continue
        original = getattr(cls, 'draw_header', None)
        topic = str(getattr(cls, '__name__', '') or 'overview')

        def _make_draw_header(_topic):
            # Blender 5.1 validates panel callbacks by signature.  Keep the
            # public draw_header signature exact; store the topic in a closure,
            # not as a default argument.
            def _draw_header(self, context):
                try:
                    area = getattr(context, 'area', None)
                    if area is not None and getattr(area, 'type', None) != 'VIEW_3D':
                        return None
                    layout = getattr(self, 'layout', None)
                    if layout is None:
                        return None
                    try:
                        layout.separator(factor=0.35)
                    except Exception:
                        pass
                    try:
                        row = layout.row(align=True)
                    except Exception:
                        row = layout
                    try:
                        row.scale_x = 0.82
                        row.scale_y = 1.0
                    except Exception:
                        pass
                    op = row.operator(PACKAGE_ID + '.open_help', text='', icon='QUESTION')
                    op.topic = _topic
                except Exception:
                    pass
                return None
            return _draw_header

        try:
            cls.draw_header = _make_draw_header(topic)
            cls._smart_common_header_patched = True
            _PATCHED_PANELS.append((cls, original))
        except Exception:
            pass


def _unpatch_panel_headers():
    for cls, original in reversed(_PATCHED_PANELS):
        try:
            if original is None:
                if hasattr(cls, 'draw_header'):
                    delattr(cls, 'draw_header')
            else:
                cls.draw_header = original
            if hasattr(cls, '_smart_common_header_patched'):
                delattr(cls, '_smart_common_header_patched')
        except Exception:
            pass
    _PATCHED_PANELS.clear()
    for cls, original in reversed(_PATCHED_POLLS):
        try:
            if original is None:
                if hasattr(cls, 'poll'):
                    delattr(cls, 'poll')
            else:
                cls.poll = original
        except Exception:
            pass
    _PATCHED_POLLS.clear()


def _iter_relevant_addon_preferences():
    prefix = _module_prefix()
    values = []
    try:
        for name in dir(bpy.types):
            try:
                values.append(getattr(bpy.types, name))
            except Exception:
                pass
    except Exception:
        values = []
    seen = set()
    for cls in values:
        if not isinstance(cls, type):
            continue
        ident = id(cls)
        if ident in seen:
            continue
        seen.add(ident)
        try:
            if not issubclass(cls, bpy.types.AddonPreferences):
                continue
        except Exception:
            continue
        module_name = str(getattr(cls, '__module__', '') or '')
        if prefix and not (module_name == prefix or module_name.startswith(prefix + '.')):
            continue
        yield cls


def _patch_addon_preferences():
    for cls in _iter_relevant_addon_preferences():
        if getattr(cls, '_smart_common_preferences_patched', False):
            continue
        original = getattr(cls, 'draw', None)

        def _draw_npanel_only(self, context):
            # Requirement: add-on preferences must not expose a settings UI.
            # Hidden AddonPreferences properties remain storage-only for Blender's
            # Save Preferences mechanism; all user-facing controls are in the N-panel.
            return None

        try:
            cls.draw = _draw_npanel_only
            cls._smart_common_preferences_patched = True
            _PATCHED_PREFERENCES.append((cls, original))
        except Exception:
            pass


def _unpatch_addon_preferences():
    for cls, original in reversed(_PATCHED_PREFERENCES):
        try:
            if original is None:
                if hasattr(cls, 'draw'):
                    delattr(cls, 'draw')
            else:
                cls.draw = original
            if hasattr(cls, '_smart_common_preferences_patched'):
                delattr(cls, '_smart_common_preferences_patched')
        except Exception:
            pass
    _PATCHED_PREFERENCES.clear()


def _simple_rna_value(value):
    if isinstance(value, (bool, int, float, str)) or value is None:
        return value
    return None


def _iter_setting_roots(context=None):
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return []
    roots = []
    for attr in ('window_manager', 'scene'):
        root = getattr(ctx, attr, None)
        if root is not None:
            roots.append((attr, root))
    return roots


def _prop_relevant(name, value, owner=None):
    lower = str(name or '').lower()
    if lower in _TRANSFORM_RNA_NAMES:
        return False
    if lower == _ALWAYS_ON_PROP.lower() or lower.startswith(PACKAGE_ID.lower()):
        return True
    prefixes = ('smart_', 'ui_', 'enable_', 'show_', 'use_', 'auto_', 'sfs_', 'sf_', 'sas_', 'scsmart_', 'scs_', 'sgn_', 'sms_', 'smod_', 'sps_', 'srs_', 'srig_', 'ssel_', 'suv_', 'uv_', 'sw_', 'st_', 'sk_', 'sss_')
    if any(lower.startswith(prefix) for prefix in prefixes):
        return True
    try:
        module_name = str(getattr(type(value), '__module__', '') or '').lower()
        prefix = _module_prefix().lower()
        if prefix and module_name.startswith(prefix):
            return True
    except Exception:
        pass
    return False


def _serialize_group(obj, depth=0):
    if depth > 2 or obj is None:
        return {}
    data = {}
    try:
        props = getattr(getattr(obj, 'rna_type', None), 'properties', [])
    except Exception:
        props = []
    for prop in props:
        try:
            identifier = str(getattr(prop, 'identifier', '') or '')
            if not identifier or identifier == 'rna_type' or getattr(prop, 'is_readonly', False):
                continue
            value = getattr(obj, identifier)
            simple = _simple_rna_value(value)
            if simple is not None:
                if _prop_relevant(identifier, value, obj):
                    data[identifier] = simple
            elif _prop_relevant(identifier, value, obj):
                nested = _serialize_group(value, depth + 1)
                if nested:
                    data[identifier] = nested
        except Exception:
            continue
    return data


def collect_persistent_settings(context=None):
    payload = {}
    for root_name, root in _iter_setting_roots(context):
        data = _serialize_group(root, 0)
        if data:
            payload[root_name] = data
    return payload


def _apply_group(obj, data, depth=0):
    if depth > 2 or not isinstance(data, dict):
        return
    for key, value in data.items():
        try:
            if str(key or '').lower() in _TRANSFORM_RNA_NAMES:
                continue
            if isinstance(value, dict):
                child = getattr(obj, key, None)
                if child is not None:
                    _apply_group(child, value, depth + 1)
            elif hasattr(obj, key):
                setattr(obj, key, value)
        except Exception:
            pass


def apply_persistent_settings(context=None):
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return
    snapshot = None
    try:
        if _sos_transform_guard is not None:
            snapshot = _sos_transform_guard.snapshot_scene_object_transforms(ctx)
    except Exception:
        snapshot = None
    try:
        data = _LOADED_SETTINGS or load_settings_file()
        for root_name, root in _iter_setting_roots(ctx):
            if root_name in data:
                _apply_group(root, data[root_name], 0)
    finally:
        try:
            if _sos_transform_guard is not None:
                _sos_transform_guard.restore_scene_object_transforms(snapshot, reason='common_apply_persistent_settings')
        except Exception:
            pass


def load_settings_file():
    """Legacy loader kept for compatibility.

    N-panel state is now stored only in
    config/Smart_Overlay_Suite/Smart_Overlay_Suite.json.  The old package-local settings file is no
    longer read so it cannot override the external JSON requested by the user.
    """
    global _LOADED_SETTINGS
    _LOADED_SETTINGS = {}
    return {}


def save_persistent_settings(context=None, force=False):
    """Write through to the external config/Smart_Overlay_Suite/Smart_Overlay_Suite.json store.

    The previous package-local autosave path intentionally remains disabled.
    Live/non-live timing is controlled by settings.is_live_save_enabled().
    """
    global _AUTOSAVE_FINGERPRINT
    try:
        from . import settings as _sos_settings
        if force or _sos_settings.is_live_save_enabled(context):
            _sos_settings.save_now(context)
            _AUTOSAVE_FINGERPRINT = 'external-json'
    except Exception:
        pass


def _autosave_timer():
    # settings.py owns the external JSON autosave timer.  Return None so this
    # legacy package-local autosave timer does not keep running.
    return None


@persistent
def _load_post_handler(dummy=None):
    try:
        from . import settings as _sos_settings
        _sos_settings.apply_settings(bpy.context)
    except Exception:
        pass


def _append_handler_once(collection, handler):
    try:
        if handler not in collection:
            collection.append(handler)
    except Exception:
        pass


def _remove_handler(collection, handler):
    try:
        while handler in collection:
            collection.remove(handler)
    except Exception:
        pass


def register():
    try:
        bpy.app.translations.unregister(PACKAGE_ID)
    except Exception:
        pass
    try:
        bpy.app.translations.register(PACKAGE_ID, _translation_payload())
    except Exception:
        pass
    _unregister_legacy_always_on_panel()

    try:
        if not hasattr(bpy.types.WindowManager, _ALWAYS_ON_PROP):
            setattr(bpy.types.WindowManager, _ALWAYS_ON_PROP, BoolProperty(
                name='Always-on',
                description='Saved always-on switch for this tool. Enable it only when you want persistent helper behavior; disable it for ordinary manual use.',
                default=False,
            ))
    except Exception:
        pass
    for cls in (SMART_OVERLAY_OT_open_help, SMART_OVERLAY_OT_set_always_on, SMART_OVERLAY_OT_save_preferences):
        try:
            _materialize_annotations(cls)
            try:
                from . import undo_support
                undo_support.prepare_operator_class(cls)
            except Exception:
                pass
            bpy.utils.register_class(cls)
            _REGISTERED_CLASSES.append(cls)
        except ValueError:
            _REGISTERED_CLASSES.append(cls)
        except Exception:
            pass
    load_settings_file()
    try:
        apply_persistent_settings(bpy.context)
    except Exception:
        pass
    # The external N-panel JSON is applied by settings.py.  Keeping this legacy
    # load_post bridge registered duplicates the same apply pass after every file
    # load, so the handler is left defined only for old in-place reload cleanup.
    try:
        timers = getattr(bpy.app, 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_autosave_timer):
            timers.unregister(_autosave_timer)
    except Exception:
        pass
    _patch_panel_headers()
    _patch_addon_preferences()


def unregister():
    try:
        save_persistent_settings(bpy.context, force=True)
    except Exception:
        pass
    _unpatch_panel_headers()
    _unpatch_addon_preferences()
    try:
        timers = getattr(bpy.app, 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_autosave_timer):
            timers.unregister(_autosave_timer)
    except Exception:
        pass
    _remove_handler(bpy.app.handlers.load_post, _load_post_handler)
    for cls in reversed(_REGISTERED_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED_CLASSES.clear()
    try:
        if hasattr(bpy.types.WindowManager, _ALWAYS_ON_PROP):
            delattr(bpy.types.WindowManager, _ALWAYS_ON_PROP)
    except Exception:
        pass
    _remove_previews()
    _unregister_legacy_always_on_panel()
    try:
        bpy.app.translations.unregister(PACKAGE_ID)
    except Exception:
        pass
    end_register()
