# SPDX-License-Identifier: GPL-3.0-or-later
# Blender Extension / user_default compatible package
# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi
#  Official Contact: 
#  Video Tutorials: 
#
#  This file is part of the Smart Overlay Suite package.
#  Licensed under the GNU General Public License v3.0 or later
#  (GPL-3.0-or-later).
# ------------------------------------------------------------------------------

import bpy
import gpu
import bmesh
import numpy as np
import time
import json
import zlib
import math
import sys
from operator import attrgetter as _sos_attrgetter
from gpu_extras.batch import batch_for_shader
from mathutils import Vector, Matrix
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.app.handlers import persistent

from .translation import T
from . import registry

# =============================================================================
# Globals & Cache (SMO)
# =============================================================================
_draw_handler = None
_pixel_draw_handler = None
_shader = None
_grad_shader = None
_dash_shader = None
_grad_dash_shader = None
_sos_overlay_shader_sources = None
_sos_gradient_shader_sources = None
_sos_current_dash_viewport = (1.0, 1.0)
_lattice_pixel_shader = None
_selected_element_pixel_shader = None
_post_pixel_polyline_shader = None
_sos_lattice_front_points_by_region = {}
_sos_lattice_pixel_snapshot_by_region = {}
_sos_lattice_region_size_by_region = {}
_sos_lattice_pixel_snapshot_timer_pending = False

# Event-side immutable GPU snapshot state. Geometry extraction and GPU batch
# creation happen only from explicit register/load/depsgraph/property events.
# The POST_VIEW callback only validates and replays the last completed record.
_sos_overlay_snapshots = {}
_sos_overlay_snapshot_generation = 0
_sos_overlay_snapshot_request_serial = 0
_sos_overlay_snapshot_timer_pending = False
_sos_overlay_snapshot_timer_attempts = 0
_sos_overlay_snapshot_due = 0.0
_sos_overlay_snapshot_reasons = set()
_sos_overlay_snapshot_last_build_time = 0.0
_sos_overlay_snapshot_last_error = ''
_SOS_OVERLAY_SNAPSHOT_MAX_RECORDS = 24
_SOS_OVERLAY_SNAPSHOT_MIN_INTERVAL = 0.10
_SOS_OVERLAY_SNAPSHOT_MAX_ATTEMPTS = 4
# A record built while the edit rebuild guard reused cached batches (budget
# circuit breaker, mutation guard, budget/exception fallback) can be partial.
# Nothing view- or data-related changes when that guard window ends, so a
# bounded follow-up build is queued for the end of the window.
_sos_edit_collect_degraded = False
_sos_overlay_snapshot_last_degraded = False
_sos_overlay_snapshot_degraded_followups = 0
_SOS_OVERLAY_SNAPSHOT_DEGRADED_FOLLOWUPS_MAX = 3
# Smart Overlay never creates automatic Preferences > Keymap entries.  Mouse
# coordinates are read natively on Windows.  Blender 5.1 does not expose current
# mouse coordinates through Window RNA on every platform, so one minimal
# PASS_THROUGH bridge per Blender window observes real input.  It copies pointer
# movement and, only when hover-click is enabled, latches the exact hover-colored
# object for one selection gesture.  All unrelated input stays PASS_THROUGH.
addon_keymaps = []
_sos_hover_click_select_keymaps = []
_sos_mouse_tracker_modal_windows = set()
_sos_mouse_tracker_modal_generation = 0
_sos_mouse_tracker_bootstrap_pending = False
_sos_mouse_tracker_bootstrap_attempts = 0
_SOS_MOUSE_TRACKER_BOOTSTRAP_MAX_ATTEMPTS = 4
_sos_mouse_probe_timer_active = False
_SOS_NATIVE_MOUSE_POLL_SUPPORTED = bool(sys.platform.startswith('win'))
_SOS_ALLOW_RESIDENT_MOUSE_TRACKER = True

_sos_last_selected_names = set()
_sos_selection_changed_time = 0.0
_sos_base_cache = {}
_sos_eval_face_cpu_cache = {}
_sos_eval_native_edge_cpu_cache = {}
_sos_eval_face_rebuild_queue = {}
_sos_topology_batch_cache = {}
_sos_occluder_batch_cache = {}
_sos_occluder_geometry_cache = {}
_sos_occluder_group_cache = {}
_sos_eval_face_rebuild_timer_active = False
_sos_eval_face_last_rebuild_time = {}
# Last measured forced evaluated-face build cost, per edit object.  Live edits
# use this to pace refreshes without ever switching the visible face overlay
# back to the pre-modifier edit cage.
_sos_eval_face_last_build_duration = {}
_sos_object_dirty_generations = {}
_SOS_BASE_CACHE_MAX_ENTRIES = 96
_SOS_OCCLUDER_CACHE_MAX_ENTRIES = 512
_SOS_OCCLUDER_GROUP_CACHE_MAX_ENTRIES = 16
_SOS_LATTICE_FRONT_CACHE_MAX_REGIONS = 16
_sos_gpu_state_restore_stack = []
# Per-draw view memo for _sos_set_depth_shader_matrices (set by
# _draw_callback_3d_impl, cleared by draw_callback_3d) and the Object-mode
# transform Live-signature reuse state (_sos_object_xform_signature_cache).
_sos_frame_view = None
_sos_xform_sig_epoch = 0
_sos_xform_sig_state = {'token': None, 'epoch': -1, 'cache': None}

_sos_cached_hover_obj = ""
_sos_last_mx = -1
_sos_last_my = -1
_sos_pending_hover_draw_obj = ""
_sos_pending_hover_draw_mx = -1
_sos_pending_hover_draw_my = -1
_sos_pending_hover_draw_region_ptr = 0
_sos_pending_hover_draw_view_sig = None
_sos_pending_hover_draw_until = 0.0

_sos_global_hover_obj = ""
_sos_drawn_hover_obj = ""
_sos_drawn_hover_mx = -1
_sos_drawn_hover_my = -1
_sos_drawn_hover_region_ptr = 0
_sos_drawn_hover_view_sig = None
_sos_drawn_hover_mode = ""
_sos_drawn_hover_time = 0.0
_sos_drawn_hover_by_region = {}
_SOS_DRAWN_HOVER_MAX_RECORDS = 24
_sos_last_hover_click_outcome = {}
_sos_selected_hover_suppression = {}
_sos_hover_provider_press_receipts = {}
_SOS_HOVER_PROVIDER_RECEIPT_MAX_RECORDS = 24
_SOS_HOVER_PROVIDER_RECEIPT_TTL_SECONDS = 1.25
_sos_mouse_window_ptr = 0
_sos_active_region_ptr = 0
_sos_mouse_window_x = -1
_sos_mouse_window_y = -1
_sos_last_hover_view_sig = None
_sos_hover_scene_revision = 0
_sos_edit_live_sync_until = 0.0
_sos_edit_transform_live_timer_active = False
_sos_last_modal_transform_signature = None
_sos_last_modal_transform_seen_time = 0.0
_sos_edit_transform_baseline_cache = {}
_sos_edit_geometry_motion_signature_cache = {}
_sos_edit_geometry_motion_until_cache = {}
_SOS_EDIT_TRANSFORM_BASELINE_CACHE_LIMIT = 32
_SOS_EDIT_TRANSFORM_MOUSE_FALLBACK_EPS = 1.25
_SOS_EDIT_GEOMETRY_MOTION_HOLD_SECONDS = 0.28
_sos_edit_eval_sync_signatures = {}
_SOS_EDIT_EVAL_SYNC_SIGNATURE_LIMIT = 128
# Dirty generation recorded right after the POST_PIXEL visibility pass flushed
# the edit mesh (update_from_editmode) for the evaluated element surface.
_sos_pixel_surface_sync_generations = {}
_SOS_PIXEL_SURFACE_SYNC_LIMIT = 64
_sos_last_runtime_mode = ""
_sos_last_mouse_redraw_time = 0.0
_sos_mouse_redraw_pending = False
_sos_pending_redraw_area = None
_sos_pending_redraw_region = None
_SOS_MOUSE_REDRAW_MIN_INTERVAL = 1.0 / 60.0
_SOS_MOUSE_PROBE_ACTIVE_INTERVAL = 1.0 / 30.0
_SOS_MOUSE_PROBE_IDLE_INTERVAL = 0.18
# Passive OS mouse fallback used by 3D edit/object hover.  This keeps hover
# visible without reinstalling the old resident modal tracker.  The value is
# short enough for pointer feedback but long enough to avoid expensive Win32/X11
# calls on every draw callback.
_SOS_OS_MOUSE_PROBE_MIN_INTERVAL = 1.0 / 45.0
_sos_last_os_mouse_probe_time = 0.0
_sos_last_os_mouse_probe_coords = None
_sos_last_os_mouse_probe_window_ptr = 0
_sos_windows_geometry_cache_time = 0.0
_sos_windows_geometry_cache = ()
_SOS_WINDOWS_GEOMETRY_CACHE_SECONDS = 0.50
# Active-view draw filtering must be driven by real operation signals, not by
# stale Window.event_mouse_x/y values from draw callbacks in other Blender
# windows.  These fields record the last confirmed operated View3D.
_sos_active_view_last_update_time = 0.0
_sos_active_view_update_source = ""
# Dedicated active-draw target.  Hover state can be refreshed from draw-time
# passive coordinates; active-view draw ownership cannot, because a secondary
# Blender window may redraw with stale event coordinates.
_sos_active_draw_window_ptr = 0
_sos_active_draw_area_ptr = 0
_sos_active_draw_region_ptr = 0
_sos_active_draw_rv3d_ptr = 0
_sos_active_draw_mouse_x = -1
_sos_active_draw_mouse_y = -1
_sos_active_draw_last_update_time = 0.0
_sos_window_event_coord_cache = {}
_sos_last_probe_context_window_ptr = 0
_sos_active_view_sig_by_region = {}
_SOS_ACTIVE_VIEW_SIG_CACHE_LIMIT = 96
_SOS_ACTIVE_VIEW_RECENT_SOURCE_SECONDS = 8.0
_SOS_EDIT_TRANSFORM_LIVE_ACTIVE_INTERVAL = 1.0 / 60.0
_SOS_EDIT_TRANSFORM_LIVE_IDLE_INTERVAL = 0.20
_sos_overlay_suppression_last_sig = None
_sos_selection_guard_signature = None
_sos_selection_guard_until = 0.0
_sos_last_manual_overlay_recovery_time = 0.0
_SOS_SELECTION_SUPPRESS_SECONDS = 0.45
_SOS_MANUAL_RECOVERY_DOUBLE_PRESS_SECONDS = 0.85
_sos_edit_mesh_rebuild_deferred_until = 0.0
_sos_deferred_edit_cache_invalidations = set()
_sos_deferred_edit_cache_global_invalidation = False
_sos_deferred_edit_redraw_timer_active = False
_sos_edit_mutation_guard_signature = None
_sos_edit_mutation_guard_until = 0.0
_SOS_EDIT_MESH_REBUILD_DEFER_SECONDS = 0.35
_SOS_EDIT_MUTATION_SUPPRESS_SECONDS = 0.30

# Draw-handler watchdog state.  Blender can leave a Python draw callback effectively
# silent after editor/context churn or after an exception escapes the callback.  Keep
# these timestamps and reinstall handlers from a timer so resident overlays recover
# without requiring the user to toggle the add-on off/on.
_sos_runtime_registered = False
_sos_runtime_started_at = 0.0
_sos_last_view3d_draw_time = 0.0
_sos_last_lattice_pixel_draw_time = 0.0
_sos_last_runtime_redraw_request_time = 0.0
_sos_last_runtime_rehook_time = 0.0
_sos_draw_exception_count = 0
_sos_runtime_recovery_timer_pending = False
_sos_runtime_recovery_timer_attempts = 0
_SOS_FRONT_POST_PIXEL_LAYER_POLICY_KEY = "JELARARAGI_VIEW3D_POST_PIXEL_LAYER_POLICY_V2"
_SOS_FRONT_POST_PIXEL_REPLAY_ACTIVE_KEY = "JELARARAGI_SMART_OVERLAY_FRONT_REPLAY_ACTIVE_V1"
_SOS_FRONT_POST_PIXEL_REPLAY_CONTEXT_KEY = "JELARARAGI_SMART_OVERLAY_FRONT_REPLAY_CONTEXT_V1"
_sos_front_post_pixel_adopt_pending = False
_SOS_RUNTIME_WATCHDOG_INTERVAL = 0.75
_SOS_RUNTIME_STALE_REHOOK_SECONDS = 3.0
_SOS_RUNTIME_RECOVERY_INTERVAL = 0.06

# Freeze-prevention circuit breaker.  3D View draw callbacks must never become a
# long-running edit-mesh rebuild path.  If Smart Overlay detects an expensive or
# unsafe edit redraw, it reuses the last known-good GPU batches for a short window
# and schedules a later redraw/recovery instead of blocking Blender's UI thread.
_sos_draw_callback_active = False
_sos_edit_batch_circuit_breaker_until = 0.0
_sos_last_edit_budget_overrun_time = 0.0
_sos_last_edit_budget_overrun_reason = ""
_sos_edit_budget_overrun_count = 0
_SOS_EDIT_BATCH_BUILD_BUDGET_SECONDS = 0.060
_SOS_EDIT_BATCH_SIGNATURE_BUDGET_SECONDS = 0.020
_SOS_EDIT_BATCH_BUDGET_CHECK_STRIDE = 2048
_SOS_EDIT_BATCH_HEAVY_ELEMENT_LIMIT = 180000
_SOS_EDIT_BATCH_NO_CACHE_HARD_LIMIT = 700000
_SOS_EVALUATED_EDIT_IMMEDIATE_ELEMENT_LIMIT = 120000
_SOS_EDIT_BATCH_EMERGENCY_SUPPRESS_SECONDS = 0.75
_SOS_DRAW_DURATION_WARN_SECONDS = 0.700

class _SOSOverlayBudgetExceeded(RuntimeError):
    pass

_sos_lightest_view_nav_signatures = {}
_sos_lightest_view_nav_until = {}
_sos_lightest_view_nav_timer_pending = False
_SOS_LIGHTEST_NAV_HOLD_SECONDS = 0.18
_SOS_LIGHTEST_NAV_CACHE_LIMIT = 64

_sos_adjacent_edge_wire_restore = {}
_sos_editmode_theme_overlay_restore = {}
_sos_editmode_base_theme_restore = {}
_sos_adjacent_edge_gradient_timer_enabled = False


# =============================================================================
# Scene Overrides (.blend local) + Effective Settings (NEW)
# =============================================================================
_SCENE_OV_CACHE = {"scene_ptr": 0, "json": "", "data": {}}

class _SettingsProxy:
    __slots__ = ("_base", "_ov")
    def __init__(self, base, ov):
        self._base = base
        self._ov = ov or {}
    def __getattr__(self, name):
        if name in self._ov:
            return self._ov[name]
        return getattr(self._base, name)

def scene_overrides_get(scene):
    if not scene or not hasattr(scene, "sos_scene_overrides_json"):
        return {}
    try:
        js = scene.sos_scene_overrides_json or ""
    except Exception:
        return {}
    if not js:
        return {}
    sptr = getattr(scene, "as_pointer", lambda: 0)()
    if _SCENE_OV_CACHE["scene_ptr"] == sptr and _SCENE_OV_CACHE["json"] == js:
        return _SCENE_OV_CACHE["data"] or {}
    try:
        data = json.loads(js)
        if not isinstance(data, dict):
            data = {}
    except Exception:
        data = {}
    _SCENE_OV_CACHE["scene_ptr"] = sptr
    _SCENE_OV_CACHE["json"] = js
    _SCENE_OV_CACHE["data"] = data
    return data

def scene_overrides_set(scene, data: dict, *, enable: bool=True):
    if not scene or not hasattr(scene, "sos_scene_overrides_json"):
        return
    try:
        scene.sos_scene_overrides_json = json.dumps(data or {}, ensure_ascii=False)
        if hasattr(scene, "sos_scene_overrides_enabled") and enable:
            scene.sos_scene_overrides_enabled = True
    except Exception:
        pass
    _SCENE_OV_CACHE["scene_ptr"] = 0
    _SCENE_OV_CACHE["json"] = ""
    _SCENE_OV_CACHE["data"] = {}

def scene_overrides_clear(scene):
    if not scene:
        return
    try:
        if hasattr(scene, "sos_scene_overrides_json"):
            scene.sos_scene_overrides_json = ""
        if hasattr(scene, "sos_scene_overrides_enabled"):
            scene.sos_scene_overrides_enabled = False
    except Exception:
        pass
    _SCENE_OV_CACHE["scene_ptr"] = 0
    _SCENE_OV_CACHE["json"] = ""
    _SCENE_OV_CACHE["data"] = {}

def get_effective_settings(context=None):
    ctx = context or bpy.context
    prefs = _prefs(ctx)
    if not prefs:
        return None
    try:
        if not getattr(prefs, "use_scene_overrides", False):
            return prefs
        scn = getattr(ctx, "scene", None)
        if not scn or not getattr(scn, "sos_scene_overrides_enabled", False):
            return prefs
        ov = scene_overrides_get(scn)
        if not ov:
            return prefs
        return _SettingsProxy(prefs, ov)
    except Exception:
        return prefs

def get_mutable_settings_target(context=None):
    ctx = context or bpy.context
    prefs = _prefs(ctx)
    if not prefs:
        return ("PREFS", None)
    try:
        if getattr(prefs, "use_scene_overrides", False):
            scn = getattr(ctx, "scene", None)
            if scn and hasattr(scn, "sos_scene_overrides_enabled") and getattr(scn, "sos_scene_overrides_enabled", False):
                return ("SCENE", scn)
    except Exception:
        pass
    return ("PREFS", prefs)

def get_mouse_active_pointers():
    return _sos_mouse_window_ptr, _sos_active_region_ptr


def is_active_view_draw_context(context=None, prefs=None) -> bool:
    """Read-only Draw Active View Only gate.

    The active token is changed only by explicit UI enable/profile actions or by
    real operation events (click, drag start, orbit, pan, zoom).  Plain cursor
    hover and draw callbacks never transfer active ownership.
    """
    try:
        if prefs is None:
            prefs = get_effective_settings(context or bpy.context)
        if not bool(getattr(prefs, 'active_view_draw_only', False)):
            return True
    except Exception:
        return True
    ctx = context or bpy.context
    try:
        multiple_candidates = bool(_sos_active_view_has_multiple_candidates(ctx))
    except Exception:
        multiple_candidates = False

    draw_window = None
    draw_area = None
    draw_region = None
    draw_rv3d = None
    if bool(_sos_draw_callback_active):
        try:
            draw_window, draw_area, draw_region, _viewport = _sos_find_draw_window_area_region(ctx)
            if draw_area is not None and draw_region is not None:
                draw_rv3d = _sos_region_3d_from_area(
                    ctx, draw_area, draw_region, window=draw_window
                )
        except Exception:
            draw_window = None
            draw_area = None
            draw_region = None
            draw_rv3d = None
    cur_win_ptr = _sos_pointer(draw_window) or _sos_pointer(getattr(ctx, 'window', None))
    cur_area_ptr = _sos_pointer(draw_area) or _sos_pointer(getattr(ctx, 'area', None))
    cur_reg_ptr = _sos_pointer(draw_region) or _sos_pointer(getattr(ctx, 'region', None))
    cur_rv3d_ptr = _sos_pointer(draw_rv3d) or _sos_pointer(getattr(ctx, 'region_data', None))

    try:
        active_win_ptr = int(_sos_active_draw_window_ptr or 0)
        active_area_ptr = int(_sos_active_draw_area_ptr or 0)
        active_reg_ptr = int(_sos_active_draw_region_ptr or 0)
        active_rv3d_ptr = int(_sos_active_draw_rv3d_ptr or 0)
    except Exception:
        active_win_ptr = 0
        active_area_ptr = 0
        active_reg_ptr = 0
        active_rv3d_ptr = 0
    if (active_win_ptr or active_reg_ptr) and not _sos_active_draw_token_visible(ctx):
        # Draw policy is read-only.  A stale token is ignored locally and is
        # replaced only by the next explicit UI/operation event or lifecycle
        # boundary; draw callbacks never mutate ownership state.
        active_win_ptr = 0
        active_area_ptr = 0
        active_reg_ptr = 0
        active_rv3d_ptr = 0

    if active_win_ptr and active_reg_ptr:
        return bool(
            cur_win_ptr == active_win_ptr
            and cur_reg_ptr == active_reg_ptr
            and (not active_area_ptr or cur_area_ptr == active_area_ptr)
            and (not active_rv3d_ptr or cur_rv3d_ptr == active_rv3d_ptr)
        )
    if active_reg_ptr:
        return bool(
            cur_reg_ptr == active_reg_ptr
            and (not active_rv3d_ptr or cur_rv3d_ptr == active_rv3d_ptr)
        )

    # A single visible View3D has no competing target, so it remains drawable
    # before an explicit operation seeds the token.  Multi-view layouts wait for
    # a click/navigation event or an explicit UI/preset prime.
    return not multiple_candidates


def mesh_curve_overlay_draw_policy(context=None, prefs=None, rv3d=None):
    """Return the shared Mesh/Curve/High-Precision draw policy.

    The three booleans are ``(scope_allowed, active_view_allowed,
    freeze_rebuild)``.  This is the single authority for workspace placement,
    temporary selection suppression, Draw Active View Only, and navigation
    batch-freeze settings.  It performs no registration, file I/O, or geometry
    work.
    """
    ctx = context or bpy.context
    try:
        if not _sos_workspace_filter_allows_addon(ctx):
            return False, False, False
    except Exception:
        return False, False, False
    try:
        if _sos_should_skip_custom_draw_for_selection(ctx):
            return False, False, False
    except Exception:
        return False, False, False
    try:
        owner = prefs if prefs is not None else get_effective_settings(ctx)
    except Exception:
        owner = prefs
    if owner is None:
        return False, False, False

    active_allowed = bool(is_active_view_draw_context(ctx, owner))
    freeze_rebuild = False
    if active_allowed:
        try:
            freeze_enabled = bool(
                _sos_opt_bool(owner, 'optimization_navigation_light_mode', False)
                or _sos_opt_bool(owner, 'optimization_lightest_freeze_batches_during_navigation', False)
            )
            if freeze_enabled:
                freeze_rebuild = bool(
                    _sos_lightest_mesh_overlay_navigation_active(
                        ctx, owner, rv3d or getattr(ctx, 'region_data', None)
                    )
                )
        except Exception:
            freeze_rebuild = False
    return True, active_allowed, freeze_rebuild


def mesh_curve_overlay_draw_context_allowed(context=None, prefs=None) -> bool:
    """Compatibility boolean wrapper for the shared draw policy."""
    return bool(mesh_curve_overlay_draw_policy(context, prefs)[1])


def _sos_obj_supported_objmode(obj, prefs):
    """Evaluated overlay target filter for Object / Sculpt style overlays.

    - Always allow mesh objects.
    - Allow curve objects when they have a renderable mesh result, when the
      curve-shape overlay is enabled, or when the existing evaluated-object
      option is allowed to convert visible modifiers.
    - Optionally allow other non-mesh objects that can be evaluated to mesh
      through Geometry Nodes / modifiers.
    """
    if not obj:
        return False
    try:
        obj_type = str(getattr(obj, 'type', '') or '')
    except Exception:
        obj_type = ''
    if obj_type == 'MESH':
        return True
    if obj_type == 'LATTICE':
        return bool(getattr(prefs, "include_lattice_objects", True))
    if obj_type == 'CURVE':
        try:
            if bool(getattr(prefs, 'include_curve_shape_overlay', True)):
                return True
        except Exception:
            pass
        try:
            if _sos_curve_has_render_mesh_settings(obj):
                return True
        except Exception:
            pass
        try:
            if bool(getattr(prefs, "include_geometry_nodes_objects", True)):
                mods = [m for m in getattr(obj, "modifiers", []) if getattr(m, "show_viewport", True)]
                return bool(mods)
        except Exception:
            return False
        return False
    if not getattr(prefs, "include_geometry_nodes_objects", True):
        return False
    if obj_type not in {'SURFACE', 'FONT', 'META', 'CURVES'}:
        return False
    try:
        mods = [m for m in getattr(obj, "modifiers", []) if getattr(m, "show_viewport", True)]
        return bool(mods)
    except Exception:
        return False

def _prefs(context=None):
    return registry.resolve_addon_preferences(context)


def _sos_opt_bool(prefs=None, prop_name: str = '', default: bool = False) -> bool:
    try:
        if prefs is None:
            prefs = get_effective_settings(getattr(bpy, 'context', None))
    except Exception:
        prefs = None
    try:
        return bool(getattr(prefs, str(prop_name or ''), bool(default)))
    except Exception:
        return bool(default)


def _sos_dirty_generation_for_object(obj) -> int:
    try:
        name = str(getattr(obj, 'name', '') or '')
    except Exception:
        name = ''
    if not name:
        return 0
    try:
        return int(_sos_object_dirty_generations.get(name, 0) or 0)
    except Exception:
        return 0


def _sos_bump_dirty_generation(obj_name: str) -> None:
    _sos_xform_sig_bump()
    try:
        name = str(obj_name or '')
    except Exception:
        name = ''
    if not name:
        return
    try:
        _sos_object_dirty_generations[name] = (int(_sos_object_dirty_generations.get(name, 0) or 0) + 1) & 0x7FFFFFFF
        if len(_sos_object_dirty_generations) > 512:
            for old_name in list(_sos_object_dirty_generations.keys())[:128]:
                _sos_object_dirty_generations.pop(old_name, None)
    except Exception:
        pass


def _sos_space_token(space):
    try:
        return int(space.as_pointer())
    except Exception:
        return id(space)


def _iter_view3d_spaces(context=None):
    """Yield every live View3D space, even from timer/foreign contexts."""
    ctx = context or getattr(bpy, "context", None)
    seen = set()
    seen_wm = set()
    managers = []

    def _ptr(value):
        try:
            return int(value.as_pointer()) if value is not None else 0
        except Exception:
            return 0

    def _from_screen(screen):
        if not screen:
            return
        for area in getattr(screen, "areas", ()):  # VIEW_3D areas only
            if getattr(area, "type", "") != 'VIEW_3D':
                continue
            for space in getattr(area, "spaces", ()):
                if getattr(space, "type", "") != 'VIEW_3D':
                    continue
                token = _sos_space_token(space)
                if token in seen:
                    continue
                seen.add(token)
                yield area, space

    for candidate_ctx in (ctx, getattr(bpy, 'context', None)):
        try:
            wm = getattr(candidate_ctx, 'window_manager', None)
            if wm is not None:
                managers.append(wm)
        except Exception:
            pass
    try:
        managers.extend(tuple(getattr(bpy.data, 'window_managers', ()) or ()))
    except Exception:
        pass

    for wm in managers:
        wm_ptr = _ptr(wm)
        if not wm_ptr or wm_ptr in seen_wm:
            continue
        seen_wm.add(wm_ptr)
        try:
            for window in tuple(getattr(wm, "windows", ()) or ()):
                yield from _from_screen(getattr(window, "screen", None))
        except Exception:
            pass

    try:
        yield from _from_screen(getattr(ctx, "screen", None))
    except Exception:
        pass


def _overlay_wire_property_name(overlay):
    # The standard Viewport Overlay > Geometry > Wireframe state is user-owned.
    # Smart Overlay must never read, cache, disable, or restore that toggle.
    del overlay
    return None


def _is_standard_wireframe_overlay_property(prop_name) -> bool:
    low = str(prop_name or '').lower()
    return low in {'show_wireframes', 'show_face_edges', 'show_face_edge_wires', 'wireframe_opacity'} or 'wire' in low



def _overlay_face_property_name(overlay):
    if overlay is None:
        return None
    for prop_name in ("show_faces",):
        if hasattr(overlay, prop_name):
            return prop_name
    return None


def _overlay_face_center_property_name(overlay):
    if overlay is None:
        return None
    for prop_name in ("show_face_center",):
        if hasattr(overlay, prop_name):
            return prop_name
    return None


def _overlay_vertex_property_name(overlay):
    if overlay is None:
        return None
    for prop_name in ("show_vertices", "show_verts", "show_vertex", "show_points"):
        if hasattr(overlay, prop_name):
            return prop_name
    try:
        props = getattr(getattr(overlay, 'bl_rna', None), 'properties', None)
        for prop in props or ():
            ident = str(getattr(prop, 'identifier', '') or '')
            low = ident.lower()
            if not low.startswith('show_'):
                continue
            if ('vert' not in low) and ('vertex' not in low) and ('point' not in low):
                continue
            if any(bad in low for bad in ('normal', 'weight', 'crease', 'bevel', 'index', 'stat', 'extra', 'viewer', 'bone', 'cursor', 'annotation')):
                continue
            if hasattr(overlay, ident):
                return ident
    except Exception:
        pass
    return None


def _overlay_value_snapshot(value):
    if isinstance(value, bool):
        return bool(value)
    if isinstance(value, int) and not isinstance(value, bool):
        return int(value)
    if isinstance(value, float):
        return float(value)
    try:
        return tuple(value)
    except Exception:
        return value


def _overlay_values_equal(a, b):
    try:
        if isinstance(a, float) or isinstance(b, float):
            return abs(float(a) - float(b)) <= 1.0e-6
    except Exception:
        pass
    return a == b


def _overlay_hidden_value(prop_name, kind, current_value):
    low = str(prop_name or '').lower()
    if isinstance(current_value, bool) or low.startswith('show_'):
        return False
    if isinstance(current_value, (int, float)) and not isinstance(current_value, bool):
        return 0.0
    if kind == 'WIRE':
        return False
    if kind == 'FACE':
        return False
    if kind == 'VERT':
        return 0.0
    return False


def _classify_overlay_property(prop_name):
    low = str(prop_name or '').lower()
    if not low:
        return None
    # Blender's standard wireframe overlay is user-owned.  Do not classify any
    # wireframe property as a suppression target; otherwise enabling Mesh and Curve Overlay
    # can disable Viewport Overlay > Geometry > Wireframe.
    if _is_standard_wireframe_overlay_property(low):
        return None
    if low in {'show_faces', 'show_face_center', 'show_face_centers'}:
        return 'FACE'
    if low in {'vertex_opacity', 'show_vertices', 'show_verts', 'show_vertex', 'show_points'}:
        return 'VERT'
    if low.startswith('show_'):
        if any(bad in low for bad in ('normal', 'weight', 'crease', 'bevel', 'index', 'stat', 'extra', 'viewer', 'bone', 'cursor', 'annotation', 'paint', 'freestyle', 'seam', 'sharp')):
            return None
        if 'face' in low and 'orientation' not in low:
            return 'FACE'
        if ('vert' in low or 'vertex' in low or 'point' in low):
            return 'VERT'
    if low.endswith('_opacity'):
        if 'vert' in low or 'vertex' in low:
            return 'VERT'
    return None


def _overlay_suppression_entries(overlay):
    """Return View3DOverlay properties that can hide native edit-mesh and curve overlays.

    Blender exposes selected-face and edit-vertex visibility through different
    kinds of properties depending on the version: booleans such as show_faces
    and numeric opacity values such as vertex_opacity. The
    standard Viewport Overlays wireframe controls are intentionally excluded.
    """
    if overlay is None:
        return ()
    result = []
    seen = set()

    def add(prop_name):
        if not prop_name or prop_name in seen:
            return
        try:
            if not hasattr(overlay, prop_name):
                return
        except Exception:
            return
        kind = _classify_overlay_property(prop_name)
        if not kind:
            return
        seen.add(prop_name)
        result.append((prop_name, kind))

    for prop_name in (
        _overlay_wire_property_name(overlay),
        _overlay_face_property_name(overlay),
        _overlay_face_center_property_name(overlay),
        _overlay_vertex_property_name(overlay),
        'vertex_opacity',
    ):
        add(prop_name)

    try:
        props = getattr(getattr(overlay, 'bl_rna', None), 'properties', None)
        for prop in props or ():
            ident = str(getattr(prop, 'identifier', '') or '')
            add(ident)
    except Exception:
        pass

    return tuple(result)


def _mesh_edit_selection_modes(context=None):
    ctx = context or getattr(bpy, 'context', None)
    try:
        if str(getattr(ctx, 'mode', '') or '') != 'EDIT_MESH':
            return set()
        sel_mode = tuple(bool(v) for v in getattr(getattr(ctx, 'tool_settings', None), 'mesh_select_mode', (False, False, False)))
    except Exception:
        return set()
    if len(sel_mode) < 3:
        return set()
    modes = set()
    if sel_mode[0]:
        modes.add('VERT')
    if sel_mode[1]:
        modes.add('EDGE')
    if sel_mode[2]:
        modes.add('FACE')
    return modes


def _mesh_edit_mode_kind(context=None):
    modes = _mesh_edit_selection_modes(context)
    if len(modes) != 1:
        return None
    return next(iter(modes))


def _sos_vertex_selection_edge_gradient_allowed(mode_kinds) -> bool:
    """Return True only when selected vertices may tint adjacent unselected edges.

    Selecting an edge also selects its endpoint vertices internally.  If the
    adjacent-edge gradient treats those endpoint vertices as an independent
    vertex selection, an ordinary edge click can look like a loop selection and
    an edge-loop can look like a ring-direction selection.  Keep this visual
    helper limited to pure vertex-select mode.
    """
    try:
        modes = set(mode_kinds or ())
    except Exception:
        return False
    return bool(modes == {'VERT'})


def _native_mesh_edit_edge_overlay_flags(context=None):
    """Return Blender native Mesh Edit Mode edge diagnostic overlay switches.

    The Viewport Overlay > Mesh Edit Mode switches for Seams, Sharp, Crease,
    and Bevel can draw their own diagnostic colors after custom add-on lines.
    Unselected diagnostic edges keep those colors, while selected edges remain
    in Smart Overlay's selected-edge batch so selection always has priority.
    """
    ctx = context or getattr(bpy, 'context', None)
    try:
        space = getattr(ctx, 'space_data', None)
    except Exception:
        space = None
    try:
        if getattr(space, 'type', None) != 'VIEW_3D':
            return {'seam': False, 'sharp': False, 'crease': False, 'bevel': False}
        overlay = getattr(space, 'overlay', None)
    except Exception:
        overlay = None
    if overlay is None:
        return {'seam': False, 'sharp': False, 'crease': False, 'bevel': False}

    def _flag(name):
        try:
            return bool(getattr(overlay, name, False))
        except Exception:
            return False

    return {
        'seam': _flag('show_edge_seams'),
        'sharp': _flag('show_edge_sharp'),
        'crease': _flag('show_edge_crease'),
        'bevel': _flag('show_edge_bevel_weight'),
    }

def _mesh_overlay_runtime_enabled(context=None):
    ctx = context or getattr(bpy, 'context', None)
    try:
        wm = getattr(ctx, 'window_manager', None)
        if wm is not None and hasattr(wm, 'sos_enabled'):
            return bool(getattr(wm, 'sos_enabled', False)) and _sos_workspace_filter_allows_addon(ctx)
    except Exception:
        return False
    # During very early registration the WindowManager property may not exist yet.
    # In that case keep the function harmless instead of assuming suppression is active.
    return False




def _sos_workspace_filter_allows_addon(context=None) -> bool:
    try:
        from . import common as _sos_common
        fn = getattr(_sos_common, 'workspace_filter_allows_addon_runtime', None)
        if callable(fn):
            # Mesh/Curve/HPO/hover are Suite runtime surfaces.  Manager panel
            # cells stay independent, while any Smart Overlay cell ON enables
            # these surfaces throughout the exact target workspace.
            return bool(fn(context, cross_editor=True))
    except Exception:
        pass
    return True

def _iter_theme_view3d(context=None):
    ctx = context or getattr(bpy, 'context', None)
    try:
        pref_root = getattr(ctx, 'preferences', None) or getattr(bpy.context, 'preferences', None)
    except Exception:
        pref_root = None
    if not pref_root:
        return
    seen = set()
    for theme in getattr(pref_root, 'themes', ()) or ():
        try:
            view3d = getattr(theme, 'view_3d', None)
        except Exception:
            view3d = None
        if view3d is None:
            continue
        try:
            token = int(view3d.as_pointer())
        except Exception:
            token = id(view3d)
        if token in seen:
            continue
        seen.add(token)
        yield token, view3d


def _theme_color_tuple(value):
    try:
        return tuple(float(v) for v in value)
    except Exception:
        return ()


def _theme_read_color(view3d, prop_name):
    if not prop_name or not hasattr(view3d, prop_name):
        return ()
    try:
        return _theme_color_tuple(getattr(view3d, prop_name))
    except Exception:
        return ()


def _theme_color_fit(color, length, *, alpha=None):
    vals = [float(v) for v in (color or ())]
    if not vals:
        vals = [0.0, 0.0, 0.0, 1.0]
    while len(vals) < length:
        vals.append(1.0 if len(vals) == 3 else 0.0)
    vals = vals[:length]
    if alpha is not None and length >= 4:
        vals[3] = float(alpha)
    return tuple(vals)


def _theme_base_color(view3d, prop_name, original):
    low = str(prop_name or '').lower()
    length = len(original) or 3
    candidates = ()
    alpha = None

    if 'face' in low and 'edge' not in low:
        # Face selection color includes alpha on current Blender builds.
        # Use a transparent face fill so linked selected faces stop showing the
        # native orange fill while actual face-mode selection remains untouched
        # because this branch is only active outside Face Select mode.
        candidates = ('face', 'face_back')
        alpha = 0.0 if length >= 4 else None
    elif 'vert' in low or 'vertex' in low or 'point' in low:
        candidates = ('vertex', 'wire_edit', 'wire')
    elif 'edge' in low or low in {'edge_facesel'}:
        candidates = ('wire_edit', 'wire', 'edge_facesel', 'vertex')
    else:
        candidates = ('wire', 'vertex')

    for candidate in candidates:
        col = _theme_read_color(view3d, candidate)
        if col:
            return _theme_color_fit(col, length, alpha=alpha)
    return _theme_color_fit(original, length, alpha=alpha)


def _theme_known_select_props(view3d, kind):
    known = {
        'VERT': ('vertex_select', 'vertex_active'),
        'EDGE': ('edge_select', 'edge_mode_select', 'edge_facesel'),
        'FACE': ('face_select', 'face_mode_select', 'face_dot'),
    }.get(kind, ())
    result = []
    for name in known:
        if hasattr(view3d, name):
            result.append(name)

    # Blender has renamed or added theme slots across versions. Scan the RNA
    # definitions and include only color array properties whose names clearly
    # refer to the selected edit-mesh element type.
    try:
        props = getattr(getattr(view3d, 'bl_rna', None), 'properties', None)
        for prop in props or ():
            ident = str(getattr(prop, 'identifier', '') or '')
            if not ident or ident in result:
                continue
            low = ident.lower()
            if 'select' not in low and low not in {'face_dot', 'edge_facesel'}:
                continue
            if any(bad in low for bad in ('object', 'bone', 'key', 'marker', 'strip', 'node', 'uv', 'paint', 'gpencil')):
                continue
            try:
                value = getattr(view3d, ident)
            except Exception:
                continue
            if len(_theme_color_tuple(value)) not in {3, 4}:
                continue
            if kind == 'VERT' and ('vert' in low or 'vertex' in low):
                result.append(ident)
            elif kind == 'EDGE' and ('edge' in low):
                result.append(ident)
            elif kind == 'FACE' and (('face' in low and 'edge' not in low) or low == 'face_dot'):
                result.append(ident)
    except Exception:
        pass
    return tuple(dict.fromkeys(result))


def _theme_suppression_kinds(context=None, prefs=None):
    ctx = context or getattr(bpy, 'context', None)
    if prefs is None:
        try:
            prefs = get_effective_settings(ctx)
        except Exception:
            prefs = _prefs(ctx)
    if prefs is None:
        return set()

    modes = _mesh_edit_selection_modes(ctx)
    result = set()
    if 'VERT' in modes and bool(getattr(prefs, 'hide_blender_vertex_mode_linked_edge_face_overlay', False)):
        result.update({'EDGE', 'FACE'})
    if 'EDGE' in modes and bool(getattr(prefs, 'hide_blender_edge_mode_linked_vertex_face_overlay', False)):
        result.update({'VERT', 'FACE'})
    if 'FACE' in modes and bool(getattr(prefs, 'hide_blender_face_mode_linked_vertex_edge_overlay', False)):
        result.update({'VERT', 'EDGE'})
    if 'FACE' in modes and bool(getattr(prefs, 'show_sel_faces', True)):
        # Face Select mode uses Smart Overlay's own selected-face fill so the
        # color chip and face opacity value control the result directly without
        # Blender's native orange fill bleeding through underneath.
        result.add('FACE')
    return result


def apply_blender_edit_mode_selection_theme_suppression(context=None, prefs=None):
    """Suppress Blender's native orange linked-element selection colors.

    The View3DOverlay API can hide wire/faces, but Blender's edit selection
    overlay still draws linked vertices/edges/faces with theme selection colors.
    The reliable public route is to temporarily remap only the selected theme
    colors for the non-current element types to their neutral edit-mesh colors.
    Original theme colors are restored as soon as the mode/setting no longer
    needs suppression or when the add-on is disabled.
    """
    global _sos_editmode_theme_overlay_restore
    target_kinds = _theme_suppression_kinds(context, prefs)
    changed_any = False

    for token, view3d in _iter_theme_view3d(context) or ():
        target_props = set()
        for kind in target_kinds:
            target_props.update(_theme_known_select_props(view3d, kind))
        restore_state = _sos_editmode_theme_overlay_restore.setdefault(token, {})

        for prop_name in tuple(set(restore_state.keys()) | target_props):
            if not hasattr(view3d, prop_name):
                restore_state.pop(prop_name, None)
                continue
            current_value = _theme_read_color(view3d, prop_name)
            if not current_value:
                continue
            if prop_name in target_props:
                if prop_name not in restore_state:
                    restore_state[prop_name] = current_value
                original = restore_state.get(prop_name) or current_value
                target_value = _theme_base_color(view3d, prop_name, original)
                if current_value != target_value:
                    try:
                        setattr(view3d, prop_name, target_value)
                        changed_any = True
                    except Exception:
                        pass
            else:
                original = restore_state.pop(prop_name, None)
                if original and current_value != tuple(original):
                    try:
                        setattr(view3d, prop_name, tuple(original))
                        changed_any = True
                    except Exception:
                        pass

        if not restore_state:
            _sos_editmode_theme_overlay_restore.pop(token, None)

    if not target_kinds and _sos_editmode_theme_overlay_restore:
        changed_any = restore_blender_edit_mode_selection_theme_suppression(context) or changed_any

    if changed_any:
        tag_view3d_redraw(context)
    return changed_any


def restore_blender_edit_mode_selection_theme_suppression(context=None):
    global _sos_editmode_theme_overlay_restore
    if not _sos_editmode_theme_overlay_restore:
        return False
    restored = False
    for token, view3d in _iter_theme_view3d(context) or ():
        restore_state = _sos_editmode_theme_overlay_restore.get(token)
        if not isinstance(restore_state, dict) or not restore_state:
            continue
        for prop_name, value in tuple(restore_state.items()):
            try:
                if hasattr(view3d, prop_name):
                    setattr(view3d, prop_name, tuple(value))
                    restored = True
            except Exception:
                pass
        _sos_editmode_theme_overlay_restore.pop(token, None)
    # If a theme disappeared or could not be restored, discard stale runtime data
    # rather than keeping a permanent restore loop.
    _sos_editmode_theme_overlay_restore.clear()
    if restored:
        tag_view3d_redraw(context)
    return restored

def _standard_edit_base_theme_targets(context=None, prefs=None):
    """Return temporary neutral edit-edge/vertex theme replacements.

    Blender 5.1 does not expose per-viewport switches for the ordinary black
    edit-cage edges and vertices.  When requested, keep the native draw as a
    minimal same-color underlay: remap only the neutral ``wire_edit`` /
    ``vertex`` colors to Smart Overlay's matching colors and reduce the native
    width/point size to one pixel.  Smart Overlay then draws its own AA line and
    point overlay over the top.  Selection and diagnostic theme colors are not
    changed.
    """
    ctx = context or getattr(bpy, 'context', None)
    if prefs is None:
        try:
            prefs = get_effective_settings(ctx)
        except Exception:
            prefs = _prefs(ctx)
    if prefs is None:
        return {}
    if str(getattr(ctx, 'mode', '') or '') != 'EDIT_MESH':
        return {}
    if not _mesh_overlay_runtime_enabled(ctx):
        return {}
    if not bool(getattr(prefs, 'hide_blender_standard_edit_edges_vertices', True)):
        return {}

    targets = {}
    try:
        edge_active = bool(getattr(prefs, 'show_edges_edit', False))
    except Exception:
        edge_active = False
    try:
        vertex_active = bool(getattr(prefs, 'show_verts_edit', False))
    except Exception:
        vertex_active = False

    if edge_active:
        try:
            edge_color = tuple(float(v) for v in getattr(prefs, 'edge_color', (1.0, 1.0, 1.0))[:3])
        except Exception:
            edge_color = (1.0, 1.0, 1.0)
        targets['wire_edit'] = edge_color
        targets['edge_width'] = 1

    if vertex_active:
        try:
            vertex_color = tuple(float(v) for v in getattr(prefs, 'vertex_color', (0.0, 0.0, 1.0))[:3])
        except Exception:
            vertex_color = (0.0, 0.0, 1.0)
        targets['vertex'] = vertex_color
        targets['vertex_unreferenced'] = vertex_color
        targets['vertex_size'] = 1
    return targets


def apply_blender_standard_edit_base_theme_suppression(context=None, prefs=None):
    """Visually suppress Blender's neutral black edit edges and vertices.

    Original theme values are stored exactly once and restored when the option,
    mesh runtime, or Edit Mode becomes inactive.  Only neutral base colors and
    their sizes are remapped; selected, active, seam, sharp, crease, bevel, and
    other diagnostic colors remain Blender-owned.
    """
    global _sos_editmode_base_theme_restore
    targets = _standard_edit_base_theme_targets(context, prefs)
    changed_any = False
    for token, view3d in _iter_theme_view3d(context) or ():
        restore_state = _sos_editmode_base_theme_restore.setdefault(token, {})
        for prop_name in tuple(set(restore_state.keys()) | set(targets.keys())):
            if not hasattr(view3d, prop_name):
                restore_state.pop(prop_name, None)
                continue
            try:
                current_value = getattr(view3d, prop_name)
            except Exception:
                continue
            if prop_name in targets:
                if prop_name not in restore_state:
                    restore_state[prop_name] = _overlay_value_snapshot(current_value)
                target_value = targets[prop_name]
                if isinstance(current_value, (int, float)) and not isinstance(current_value, bool):
                    try:
                        target_value = type(current_value)(target_value)
                    except Exception:
                        pass
                else:
                    try:
                        target_value = _theme_color_fit(target_value, len(current_value))
                    except Exception:
                        pass
                if not _overlay_values_equal(_overlay_value_snapshot(current_value), _overlay_value_snapshot(target_value)):
                    try:
                        setattr(view3d, prop_name, target_value)
                        changed_any = True
                    except Exception:
                        pass
            else:
                original = restore_state.pop(prop_name, None)
                if original is None:
                    continue
                if not _overlay_values_equal(_overlay_value_snapshot(current_value), _overlay_value_snapshot(original)):
                    try:
                        setattr(view3d, prop_name, original)
                        changed_any = True
                    except Exception:
                        pass
        if not restore_state:
            _sos_editmode_base_theme_restore.pop(token, None)

    if not targets and _sos_editmode_base_theme_restore:
        changed_any = restore_blender_standard_edit_base_theme_suppression(context) or changed_any
    if changed_any:
        tag_view3d_redraw(context)
    return changed_any


def restore_blender_standard_edit_base_theme_suppression(context=None):
    global _sos_editmode_base_theme_restore
    if not _sos_editmode_base_theme_restore:
        return False
    restored = False
    for token, view3d in _iter_theme_view3d(context) or ():
        restore_state = _sos_editmode_base_theme_restore.get(token)
        if not isinstance(restore_state, dict):
            continue
        for prop_name, value in tuple(restore_state.items()):
            try:
                if hasattr(view3d, prop_name):
                    setattr(view3d, prop_name, value)
                    restored = True
            except Exception:
                pass
        _sos_editmode_base_theme_restore.pop(token, None)
    _sos_editmode_base_theme_restore.clear()
    if restored:
        tag_view3d_redraw(context)
    return restored


def restore_legacy_smart_overlay_theme_contamination(context=None):
    """Repair only the exact Blender 5.1 theme fingerprint written by 1.2.228.

    Earlier builds attempted to hide Blender's native edit cage by changing the
    global theme.  Those temporary values could be saved into userpref.blend.
    The complete fingerprint below is deliberately strict so a normal custom
    theme is never reset merely because one color happens to match.
    """
    def close_tuple(actual, expected, tolerance=2.0e-4):
        try:
            values = tuple(float(v) for v in actual)
            return len(values) == len(expected) and all(
                abs(values[i] - float(expected[i])) <= tolerance for i in range(len(expected))
            )
        except Exception:
            return False

    repaired = False
    for _token, view3d in _iter_theme_view3d(context) or ():
        try:
            vertex = _theme_read_color(view3d, 'vertex')
            contaminated = bool(
                close_tuple(_theme_read_color(view3d, 'wire_edit'), (1.0, 1.0, 1.0))
                and close_tuple(vertex, (0.0392156877, 0.0, 0.8078432083))
                and close_tuple(_theme_read_color(view3d, 'vertex_unreferenced'), vertex)
                and close_tuple(_theme_read_color(view3d, 'vertex_select'), vertex)
                and close_tuple(_theme_read_color(view3d, 'edge_select'), (1.0, 1.0, 1.0))
                and close_tuple(_theme_read_color(view3d, 'edge_mode_select'), (1.0, 1.0, 1.0))
                and close_tuple(_theme_read_color(view3d, 'face_select'), (1.0, 1.0, 1.0, 0.0))
                and close_tuple(_theme_read_color(view3d, 'face_mode_select'), (1.0, 1.0, 1.0, 0.0))
                and int(getattr(view3d, 'vertex_size', 0) or 0) == 1
            )
        except Exception:
            contaminated = False
        if not contaminated:
            continue
        defaults = {
            'wire_edit': (0.0, 0.0, 0.0),
            'vertex': (0.0, 0.0, 0.0),
            'vertex_unreferenced': (0.0, 0.0, 0.0),
            'vertex_select': (1.0, 0.4784314036, 0.0),
            'edge_select': (1.0, 0.6000000238, 0.0),
            'edge_mode_select': (1.0, 0.8470588923, 0.0),
            'face_select': (1.0, 0.6392157078, 0.0, 0.2000000179),
            'face_mode_select': (1.0, 0.7176470757, 0.0, 0.2000000179),
            'edge_width': 1,
            'vertex_size': 3,
        }
        for prop_name, value in defaults.items():
            try:
                if hasattr(view3d, prop_name):
                    setattr(view3d, prop_name, value)
            except Exception:
                pass
        repaired = True
    if repaired:
        tag_view3d_redraw(context)
    return repaired


def _mesh_edit_overlay_suppression_flags(context=None, prefs=None):
    ctx = context or getattr(bpy, 'context', None)
    if prefs is None:
        try:
            prefs = get_effective_settings(ctx)
        except Exception:
            prefs = _prefs(ctx)

    flags = {
        'hide_wire_overlay': False,
        'hide_face_overlay': False,
        'hide_face_center_overlay': False,
        'hide_vertex_overlay': False,
        'force_vertex_cover': False,
        'force_edge_cover': False,
        'force_face_cover': False,
        'suppress_native_face_selection': False,
        'hide_standard_edges_vertices': False,
    }
    if prefs is None:
        return flags

    # Edit-mesh and curve overlay suppression must never touch Blender's global viewport
    # overlay display outside Edit Mode or while Smart Overlay itself is off.
    # Otherwise the add-on keeps overriding native overlay settings such as the
    # standard Wireframe viewport overlay even when the user is not using the
    # mesh-edit runtime.
    if str(getattr(ctx, 'mode', '') or '') != 'EDIT_MESH':
        return flags
    if not _mesh_overlay_runtime_enabled(ctx):
        return flags

    modes = _mesh_edit_selection_modes(ctx)
    if bool(getattr(prefs, 'hide_blender_standard_edit_edges_vertices', True)):
        flags['hide_standard_edges_vertices'] = True
        # Future Blender versions may expose a real edit-vertex visibility RNA
        # property. Hide it when available; current 5.1 builds use the temporary
        # theme remap above for both neutral edges and vertices.
        if bool(getattr(prefs, 'show_verts_edit', False)):
            flags['hide_vertex_overlay'] = True
    if bool(getattr(prefs, 'hide_blender_adjacent_edge_gradient', True)):
        flags['force_edge_cover'] = True
    if 'VERT' in modes and bool(getattr(prefs, 'hide_blender_vertex_mode_linked_edge_face_overlay', False)):
        flags['hide_face_overlay'] = True
        flags['force_edge_cover'] = True
        flags['force_face_cover'] = True
    if 'EDGE' in modes and bool(getattr(prefs, 'hide_blender_edge_mode_linked_vertex_face_overlay', False)):
        flags['hide_face_overlay'] = True
        flags['hide_vertex_overlay'] = True
        flags['force_vertex_cover'] = True
        flags['force_face_cover'] = True
    if 'FACE' in modes and bool(getattr(prefs, 'hide_blender_face_mode_linked_vertex_edge_overlay', False)):
        flags['hide_vertex_overlay'] = True
        flags['force_vertex_cover'] = True
        flags['force_edge_cover'] = True
    if 'FACE' in modes and bool(getattr(prefs, 'show_sel_faces', True)):
        flags['suppress_native_face_selection'] = True
    if (
        'FACE' in modes
        and bool(getattr(prefs, 'use_select_mode_vertex_center_overlay', True))
        and bool(getattr(prefs, 'show_verts_edit', False))
    ):
        # Smart Overlay owns both visible and occluded face-center dots. Leaving
        # Blender's native face dots enabled creates a second, independently
        # depth-tested point at the same location, which is the source of the
        # visible dot receiving an occluded color or disappearing in solid mode.
        flags['hide_face_center_overlay'] = True
    return flags


def _overlay_restore_state(token):
    state = _sos_adjacent_edge_wire_restore.get(token)
    if isinstance(state, dict):
        return state
    if state is None:
        state = {}
    else:
        # Older builds stored a bare bool for show_wireframes.  Drop that stale
        # wireframe restore data instead of writing Blender's user-owned setting.
        state = {}
    _sos_adjacent_edge_wire_restore[token] = state
    return state


def _overlay_should_hide(prop_name, flags, kind=None):
    kind = kind or _classify_overlay_property(prop_name)
    if str(prop_name or '').lower() in {'show_face_center', 'show_face_centers'}:
        return bool(flags.get('hide_face_center_overlay', False))
    if kind == 'WIRE':
        return False
    if kind == 'FACE':
        return bool(flags.get('hide_face_overlay', False))
    if kind == 'VERT':
        return bool(flags.get('hide_vertex_overlay', False))
    return False


def _sos_overlay_suppression_signature(context=None, prefs=None, flags=None):
    ctx = context or getattr(bpy, 'context', None)
    try:
        space_tokens = tuple(sorted(_sos_space_token(space) for _area, space in _iter_view3d_spaces(ctx)))
    except Exception:
        space_tokens = ()
    try:
        mode = str(getattr(ctx, 'mode', '') or '')
    except Exception:
        mode = ''
    try:
        selection_modes = tuple(sorted(_mesh_edit_selection_modes(ctx)))
    except Exception:
        selection_modes = ()
    flags = flags if isinstance(flags, dict) else _mesh_edit_overlay_suppression_flags(ctx, prefs)
    flag_sig = tuple(sorted((str(k), bool(v)) for k, v in flags.items()))
    pref_sig = ()
    if prefs is not None:
        names = (
            'hide_blender_standard_edit_edges_vertices',
            'show_edges_edit',
            'show_sel_edges',
            'show_verts_edit',
            'hide_blender_adjacent_edge_gradient',
            'hide_blender_vertex_mode_linked_edge_face_overlay',
            'hide_blender_edge_mode_linked_vertex_face_overlay',
            'hide_blender_face_mode_linked_vertex_edge_overlay',
            'show_sel_faces',
            'use_select_mode_vertex_center_overlay',
        )
        pref_sig = tuple((name, bool(getattr(prefs, name, False))) for name in names)
        try:
            pref_sig += (('edge_color', tuple(round(float(v), 6) for v in getattr(prefs, 'edge_color', ()))),)
            pref_sig += (('vertex_color', tuple(round(float(v), 6) for v in getattr(prefs, 'vertex_color', ()))),)
        except Exception:
            pass
    return (mode, selection_modes, flag_sig, pref_sig, space_tokens)


def _sos_enforce_native_face_center_suppression_for_context(context=None, prefs=None) -> bool:
    """Hide Blender's native face-center dot in the exact drawing SpaceView3D.

    Blender can restore show_face_center during mode/area transitions after the
    broader suppression pass ran. Enforce ownership immediately before the
    add-on's POST_PIXEL center pass, while retaining the original value for
    normal restoration when Smart Overlay no longer owns the dots.
    """
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return False
    flags = _mesh_edit_overlay_suppression_flags(ctx, prefs)
    if not bool(flags.get('hide_face_center_overlay', False)):
        return False
    space = getattr(ctx, 'space_data', None)
    if getattr(space, 'type', None) != 'VIEW_3D':
        return False
    overlay = getattr(space, 'overlay', None)
    prop_name = _overlay_face_center_property_name(overlay)
    if not prop_name:
        return False
    token = _sos_space_token(space)
    restore_state = _overlay_restore_state(token)
    try:
        current = bool(getattr(overlay, prop_name))
        if prop_name not in restore_state:
            restore_state[prop_name] = current
        if current:
            setattr(overlay, prop_name, False)
            try:
                area = getattr(ctx, 'area', None)
                if area is not None:
                    area.tag_redraw()
            except Exception:
                pass
            return True
    except Exception:
        return False
    return False


def _sos_overlay_suppression_requires_reapply(context=None, flags=None) -> bool:
    ctx = context or getattr(bpy, 'context', None)
    flags = flags if isinstance(flags, dict) else {}
    hide_face_center = bool(flags.get('hide_face_center_overlay', False))
    try:
        for _area, space in _iter_view3d_spaces(ctx):
            overlay = getattr(space, 'overlay', None)
            token = _sos_space_token(space)
            prop_name = _overlay_face_center_property_name(overlay)
            restore_state = _sos_adjacent_edge_wire_restore.get(token)
            restore_state = restore_state if isinstance(restore_state, dict) else {}
            if hide_face_center and prop_name:
                try:
                    if bool(getattr(overlay, prop_name, False)):
                        return True
                except Exception:
                    return True
            if (not hide_face_center) and prop_name in restore_state:
                return True
    except Exception:
        return True
    return False


def apply_blender_adjacent_edge_gradient_visibility(context=None, prefs=None):
    global _sos_adjacent_edge_wire_restore, _sos_overlay_suppression_last_sig
    ctx = context or getattr(bpy, 'context', None)
    # Theme values are global, persistent user preferences.  Never remap them
    # to suppress Blender's edit-cage colors: the temporary values can be saved
    # into userpref.blend when Blender exits.  Flush restore data left by an
    # older live module and keep all further suppression viewport-local.
    changed_any = False
    try:
        changed_any = restore_blender_standard_edit_base_theme_suppression(ctx) or changed_any
    except Exception:
        pass
    try:
        changed_any = restore_blender_edit_mode_selection_theme_suppression(ctx) or changed_any
    except Exception:
        pass
    try:
        changed_any = restore_legacy_smart_overlay_theme_contamination(ctx) or changed_any
    except Exception:
        pass
    if prefs is None:
        try:
            prefs = get_effective_settings(ctx)
        except Exception:
            prefs = _prefs(ctx)
    flags = _mesh_edit_overlay_suppression_flags(ctx, prefs)
    sig = _sos_overlay_suppression_signature(ctx, prefs, flags)
    if sig == _sos_overlay_suppression_last_sig and not _sos_overlay_suppression_requires_reapply(ctx, flags):
        return changed_any
    _sos_overlay_suppression_last_sig = sig
    if not any(flags.values()):
        return restore_blender_adjacent_edge_gradient_visibility(ctx) or changed_any

    for area, space in _iter_view3d_spaces(context):
        overlay = getattr(space, 'overlay', None)
        token = _sos_space_token(space)
        changed_space = False
        prop_entries = _overlay_suppression_entries(overlay)
        if not prop_entries:
            continue
        restore_state = _overlay_restore_state(token)
        handled_props = set()

        for prop_name, kind in prop_entries:
            if _is_standard_wireframe_overlay_property(prop_name):
                restore_state.pop(prop_name, None)
                continue
            handled_props.add(prop_name)
            try:
                current_value = getattr(overlay, prop_name)
            except Exception:
                continue
            should_hide = _overlay_should_hide(prop_name, flags, kind)
            if should_hide:
                if prop_name not in restore_state:
                    restore_state[prop_name] = _overlay_value_snapshot(current_value)
                target_value = _overlay_hidden_value(prop_name, kind, current_value)
                if not _overlay_values_equal(current_value, target_value):
                    try:
                        setattr(overlay, prop_name, target_value)
                        changed_space = True
                    except Exception:
                        pass
            else:
                if prop_name in restore_state:
                    target_value = restore_state.pop(prop_name)
                    if not _overlay_values_equal(current_value, target_value):
                        try:
                            setattr(overlay, prop_name, target_value)
                            changed_space = True
                        except Exception:
                            pass

        stale = [name for name in tuple(restore_state.keys()) if name not in handled_props]
        for name in stale:
            restore_state.pop(name, None)
        if not restore_state:
            _sos_adjacent_edge_wire_restore.pop(token, None)

        if changed_space:
            changed_any = True
            try:
                area.tag_redraw()
            except Exception:
                pass

    if not any(flags.values()) and _sos_adjacent_edge_wire_restore:
        # Closed viewports cannot be restored directly; clear stale entries after the user disables the option.
        _sos_adjacent_edge_wire_restore.clear()
    return changed_any


def restore_blender_adjacent_edge_gradient_visibility(context=None):
    global _sos_adjacent_edge_wire_restore
    restored = False
    try:
        restored = restore_blender_standard_edit_base_theme_suppression(context) or restored
    except Exception:
        pass
    try:
        restored = restore_blender_edit_mode_selection_theme_suppression(context) or restored
    except Exception:
        pass
    if not _sos_adjacent_edge_wire_restore:
        return restored
    for area, space in _iter_view3d_spaces(context):
        overlay = getattr(space, 'overlay', None)
        token = _sos_space_token(space)
        restore_state = _sos_adjacent_edge_wire_restore.get(token)
        if not isinstance(restore_state, dict) or not restore_state:
            continue
        for prop_name, value in tuple(restore_state.items()):
            if _is_standard_wireframe_overlay_property(prop_name):
                restore_state.pop(prop_name, None)
                continue
            try:
                if hasattr(overlay, prop_name):
                    setattr(overlay, prop_name, value)
                    restored = True
                    restore_state.pop(prop_name, None)
            except Exception:
                pass
        if not restore_state:
            _sos_adjacent_edge_wire_restore.pop(token, None)
        try:
            area.tag_redraw()
        except Exception:
            pass
    _sos_adjacent_edge_wire_restore.clear()
    return restored


def _sos_adjacent_edge_gradient_timer():
    # Deprecated persistent poller.  Overlay suppression is now applied from the
    # draw/depsgraph paths while the mesh runtime is enabled, and restored when
    # that runtime is disabled.
    return None


def clear_cache_and_redraw(context=None):
    global _sos_overlay_suppression_last_sig
    # During the short freeze-safety circuit breaker, keep the last known-good
    # edit GPU batches alive.  Clearing them in this window causes the viewport
    # to show no overlay until the suppress timer expires, which looks like a
    # random feature failure on dense meshes.
    if not _sos_edit_overlay_circuit_breaker_active():
        _sos_base_cache.clear()
    _sos_eval_face_cpu_cache.clear()
    _sos_eval_native_edge_cpu_cache.clear()
    _sos_eval_face_rebuild_queue.clear()
    _SOS_PIXEL_VIS_MEMO.clear()
    _sos_topology_batch_cache.clear()
    _sos_occluder_batch_cache.clear()
    _sos_occluder_geometry_cache.clear()
    _sos_occluder_group_cache.clear()
    _sos_overlay_suppression_last_sig = None
    try:
        if _sos_modal_tracker_wanted(context or bpy.context):
            _sos_start_mouse_probe_timer()
        elif _sos_mouse_tracker_modal_windows or _sos_mouse_tracker_bootstrap_pending:
            _sos_stop_mouse_tracker_modal()
    except Exception:
        pass
    request_overlay_snapshot_rebuild('cache_invalidated', context=context, immediate=True)
    tag_view3d_redraw(context)

def _sos_note_runtime_redraw_request() -> None:
    """Record that Smart Overlay asked the viewport to draw soon.

    A stale draw timestamp alone is not a failure: Blender may simply be idle.
    Staleness matters only after this add-on explicitly requested a redraw and
    the POST_VIEW callback still did not run.
    """
    global _sos_last_runtime_redraw_request_time
    try:
        _sos_last_runtime_redraw_request_time = time.time()
    except Exception:
        pass


def _sos_capture_gpu_state_snapshot() -> dict:
    snapshot = {}
    for _key, _getter in (
        ('blend', 'blend_get'),
        ('depth_test', 'depth_test_get'),
        ('depth_mask', 'depth_mask_get'),
        ('line_width', 'line_width_get'),
        ('scissor', 'scissor_get'),
        ('scissor_test', 'scissor_test_get'),
        ('viewport', 'viewport_get'),
    ):
        try:
            snapshot[_key] = getattr(gpu.state, _getter)()
        except Exception:
            pass
    try:
        snapshot['matrix_model_view'] = gpu.matrix.get_model_view_matrix().copy()
    except Exception:
        pass
    try:
        snapshot['matrix_projection'] = gpu.matrix.get_projection_matrix().copy()
    except Exception:
        pass
    return snapshot



def _sos_reset_blf_state_after_draw() -> None:
    """Reset sticky BLF flags without changing Blender theme alpha/color."""
    try:
        import blf
    except Exception:
        return
    for _font_id in (0,):
        for _flag_name in ('ROTATION', 'SHADOW', 'CLIPPING', 'WORD_WRAP', 'MONOCHROME'):
            try:
                _flag = getattr(blf, _flag_name, None)
                if _flag is not None:
                    blf.disable(_font_id, _flag)
            except Exception:
                pass
        for _name, _args in (
            ('rotation', (0.0,)),
            ('aspect', (1.0,)),
            ('shadow', (0, 0.0, 0.0, 0.0, 0.0)),
            ('shadow_offset', (0, 0)),
            ('word_wrap', (0,)),
        ):
            try:
                getattr(blf, _name)(_font_id, *_args)
            except Exception:
                pass


def _sos_restore_gpu_state_snapshot(snapshot=None, *, ui_safe: bool = False) -> None:
    """Restore GPU/BLF state after Smart Overlay drawing.

    Smart Overlay leaves Blender's editor UI in the draw state it received.
    Draw wrappers may pass ``ui_safe=True`` for compatibility with older call
    sites, but that flag must not impose a fixed blend mode on Blender's own UI:
    N-panel opacity is theme/UI owned, not add-on owned.
    """
    try:
        gpu.state.color_mask_set(True, True, True, True)
    except Exception:
        pass

    # These states have setters but no public getters in Blender 5.1.  They are
    # enabled only by Smart Overlay's custom draw paths, so return them to neutral
    # values without changing theme colors or alpha values.
    for _name, _args in (
        ('multisample_set', (False,)),
        ('line_smooth_set', (False,)),
        ('alpha_to_coverage_set', (False,)),
        ('face_culling_set', ('NONE',)),
        ('front_facing_set', (False,)),
        ('clip_distances_set', (0,)),
        ('program_point_size_set', (False,)),
        ('point_size_set', (1.0,)),
    ):
        try:
            getattr(gpu.state, _name)(*_args)
        except Exception:
            pass

    restored_blend = None
    if isinstance(snapshot, dict) and snapshot:
        for _key, _setter in (
            ('blend', 'blend_set'),
            ('depth_mask', 'depth_mask_set'),
            ('depth_test', 'depth_test_set'),
            ('line_width', 'line_width_set'),
            ('scissor', 'scissor_set'),
            ('scissor_test', 'scissor_test_set'),
            ('viewport', 'viewport_set'),
        ):
            if _key not in snapshot:
                continue
            try:
                value = snapshot[_key]
                if _key == 'blend':
                    restored_blend = str(value)
                if isinstance(value, (tuple, list)):
                    getattr(gpu.state, _setter)(*value)
                else:
                    getattr(gpu.state, _setter)(value)
            except Exception:
                pass
        try:
            if 'matrix_model_view' in snapshot:
                gpu.matrix.load_matrix(snapshot['matrix_model_view'])
        except Exception:
            pass
        try:
            if 'matrix_projection' in snapshot:
                gpu.matrix.load_projection_matrix(snapshot['matrix_projection'])
        except Exception:
            pass

    _sos_reset_blf_state_after_draw()
    try:
        _sos_reapply_sidebar_safe_overlay_clip()
    except Exception:
        pass

def _sos_sanitize_gpu_state_for_blender_ui(snapshot=None) -> None:
    """Restore Smart Overlay draw state without overriding theme transparency."""
    _sos_restore_gpu_state_snapshot(snapshot, ui_safe=True)


def _sos_force_ui_safe_gpu_state(snapshot=None) -> None:
    """Compatibility helper: restore captured draw state exactly."""
    if snapshot is None:
        try:
            if _sos_gpu_state_restore_stack:
                snapshot = _sos_gpu_state_restore_stack[-1]
        except Exception:
            snapshot = None
    _sos_restore_gpu_state_snapshot(snapshot, ui_safe=True)


def _sos_push_gpu_state_restore() -> dict:
    snapshot = _sos_capture_gpu_state_snapshot()
    try:
        _sos_gpu_state_restore_stack.append(snapshot)
    except Exception:
        pass
    return snapshot


def _sos_pop_gpu_state_restore(snapshot=None, *, ui_safe: bool = False) -> None:
    restore_snapshot = snapshot
    try:
        if _sos_gpu_state_restore_stack:
            restore_snapshot = _sos_gpu_state_restore_stack.pop()
    except Exception:
        restore_snapshot = snapshot
    _sos_restore_gpu_state_snapshot(restore_snapshot, ui_safe=ui_safe)


_sos_sidebar_clip_restore_stack = []


def _sos_current_viewport_tuple(region=None):
    try:
        viewport = tuple(gpu.state.viewport_get())
    except Exception:
        viewport = ()
    if len(viewport) >= 4:
        try:
            return (int(viewport[0]), int(viewport[1]), int(viewport[2]), int(viewport[3]))
        except Exception:
            pass
    try:
        return (
            0,
            0,
            int(getattr(region, 'width', 0) or 0),
            int(getattr(region, 'height', 0) or 0),
        )
    except Exception:
        return (0, 0, 0, 0)


def _sos_region_matches_viewport(region, viewport, *, strict_position: bool = False) -> bool:
    try:
        _vx, _vy, vw, vh = viewport
        rw = int(getattr(region, 'width', 0) or 0)
        rh = int(getattr(region, 'height', 0) or 0)
        if abs(rw - int(vw)) > 2 or abs(rh - int(vh)) > 2:
            return False
        if not strict_position:
            return True
        rx = int(getattr(region, 'x', 0) or 0)
        ry = int(getattr(region, 'y', 0) or 0)
        return abs(rx - int(viewport[0])) <= 2 and abs(ry - int(viewport[1])) <= 2
    except Exception:
        return False


def _sos_find_draw_window_area_region(context=None):
    """Resolve the Window, Area, and WINDOW Region currently being drawn.

    Region-only matching is not sufficient for ``active_view_draw_only`` in
    multi-window layouts.  Two Blender windows can have VIEW_3D regions with the
    same size and local coordinates; the draw gate must compare both the window
    pointer and the region pointer.
    """
    ctx = context or bpy.context
    context_window = getattr(ctx, 'window', None)
    context_area = getattr(ctx, 'area', None)
    context_region = getattr(ctx, 'region', None)
    context_window_ptr = _sos_pointer(context_window)
    context_area_ptr = _sos_pointer(context_area)
    context_region_ptr = _sos_pointer(context_region)
    viewport = _sos_current_viewport_tuple(context_region)
    vx, vy, vw, vh = viewport
    if vw <= 1 or vh <= 1:
        return None, None, None, viewport

    # GPU viewport coordinates are local to each WINDOW region. In quad view all
    # four callbacks report (0, 0) and the same dimensions, so validate and use
    # the live RNA draw context before falling back to a screen-wide scan.
    try:
        context_screen = getattr(context_window, 'screen', None)
        area_is_live = bool(
            context_window_ptr
            and context_area_ptr
            and context_region_ptr
            and getattr(context_area, 'type', None) == 'VIEW_3D'
            and getattr(context_region, 'type', None) == 'WINDOW'
            and any(
                _sos_pointer(candidate) == context_area_ptr
                for candidate in (getattr(context_screen, 'areas', ()) or ())
            )
        )
        region_is_live = bool(
            area_is_live
            and any(
                _sos_pointer(candidate) == context_region_ptr
                for candidate in (getattr(context_area, 'regions', ()) or ())
            )
        )
        if region_is_live and _sos_region_matches_viewport(context_region, viewport):
            return context_window, context_area, context_region, viewport
    except Exception:
        pass

    candidates = []
    try:
        wm = getattr(ctx, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                if getattr(area, 'type', None) != 'VIEW_3D':
                    continue
                for region in getattr(area, 'regions', ()) or ():
                    if getattr(region, 'type', None) != 'WINDOW':
                        continue
                    if not _sos_region_matches_viewport(region, viewport):
                        continue
                    score = 0
                    if context_window_ptr and _sos_pointer(window) == context_window_ptr:
                        score += 200
                    if context_area_ptr and _sos_pointer(area) == context_area_ptr:
                        score += 100
                    if context_region_ptr and _sos_pointer(region) == context_region_ptr:
                        score += 50
                    if _sos_region_matches_viewport(region, viewport, strict_position=True):
                        score += 25
                    try:
                        score -= abs(int(getattr(region, 'x', 0) or 0) - int(vx))
                        score -= abs(int(getattr(region, 'y', 0) or 0) - int(vy))
                    except Exception:
                        pass
                    candidates.append((score, window, area, region))
    except Exception:
        candidates = []

    if candidates:
        candidates.sort(key=lambda item: item[0], reverse=True)
        _score, window, area, region = candidates[0]
        return window, area, region, viewport

    if (
        context_window is not None
        and context_area is not None
        and getattr(context_area, 'type', None) == 'VIEW_3D'
        and context_region is not None
        and getattr(context_region, 'type', None) == 'WINDOW'
    ):
        return context_window, context_area, context_region, viewport
    return None, None, None, viewport


def _sos_find_draw_area_window_region(context=None):
    """Resolve the editor WINDOW region Blender is drawing now."""
    _window, area, region, viewport = _sos_find_draw_window_area_region(context)
    return area, region, viewport


def _sos_overlay_clip_rect_excluding_ui(context=None):
    area, region, viewport = _sos_find_draw_area_window_region(context)
    if area is None or region is None:
        return None
    vx, vy, vw, vh = viewport
    if vw <= 1 or vh <= 1:
        return None
    try:
        win_x = int(getattr(region, 'x', 0) or 0)
        win_y = int(getattr(region, 'y', 0) or 0)
        win_w = int(getattr(region, 'width', 0) or 0)
        win_h = int(getattr(region, 'height', 0) or 0)
    except Exception:
        return None
    if win_w <= 1 or win_h <= 1:
        return None

    clip_left = 0
    clip_right = min(int(vw), int(win_w))
    for other in getattr(area, 'regions', ()) or ():
        try:
            if getattr(other, 'type', None) != 'UI':
                continue
            other_w = int(getattr(other, 'width', 0) or 0)
            other_h = int(getattr(other, 'height', 0) or 0)
            if other_w <= 8 or other_h <= 8:
                continue
            other_x = int(getattr(other, 'x', 0) or 0)
            other_y = int(getattr(other, 'y', 0) or 0)
            if other_y >= win_y + win_h or other_y + other_h <= win_y:
                continue
            if win_x < other_x < win_x + win_w:
                clip_right = min(clip_right, max(0, other_x - win_x))
            elif other_x <= win_x < other_x + other_w:
                clip_left = max(clip_left, min(win_w - 1, (other_x + other_w) - win_x))
        except Exception:
            continue

    clip_left = max(0, min(int(vw) - 1, int(clip_left)))
    clip_right = max(clip_left + 1, min(int(vw), int(clip_right)))
    if clip_left <= 0 and clip_right >= int(vw) - 1:
        return None
    return (int(vx) + clip_left, int(vy), int(clip_right - clip_left), int(max(1, min(int(vh), int(win_h)))))


def _sos_begin_sidebar_safe_overlay_clip(context=None):
    """Compatibility no-op for View3D POST_VIEW drawing.

    Mesh, curve, and proportional View3D overlays are depth/viewport content and
    must draw across the entire WINDOW region, including the Region Overlap area
    behind the Sidebar.  Earlier builds clipped these POST_VIEW passes away from
    the N-panel to work around apparent Sidebar translucency, but that also made
    overlays disappear in the right-side viewport strip and in the area below the
    open Sidebar panels.  Sidebar opacity is Blender UI/theme owned; Smart
    Overlay only restores its GPU state after drawing and does not crop View3D
    geometry overlays.
    """
    return None

def _sos_reapply_sidebar_safe_overlay_clip() -> None:
    """Compatibility no-op: POST_VIEW overlays are no longer Sidebar-clipped."""
    return None

def _sos_end_sidebar_safe_overlay_clip(token=None) -> None:
    if token is None:
        return
    try:
        if _sos_sidebar_clip_restore_stack:
            _sos_sidebar_clip_restore_stack.pop()
    except Exception:
        pass
    try:
        if isinstance(token, dict) and bool(token.get('nested', False)):
            return
    except Exception:
        pass
    try:
        previous_scissor_test = bool(token.get('previous_scissor_test', False)) if isinstance(token, dict) else False
        gpu.state.scissor_test_set(previous_scissor_test)
    except Exception:
        pass
    try:
        previous_scissor = token.get('previous_scissor') if isinstance(token, dict) else None
        if previous_scissor is not None:
            gpu.state.scissor_set(*previous_scissor)
    except Exception:
        pass


_sos_post_pixel_ui_clip_stack = []


def _sos_begin_post_pixel_ui_region_clip(context=None):
    """Clip only screen-space POST_PIXEL overlays away from an open N-panel.

    Mesh/Curve POST_VIEW overlays remain un-clipped so Region Overlap viewport
    contents still cover the full editor WINDOW region.  This guard is only for
    add-on POST_PIXEL helper drawing; it prevents those screen-space batches from
    being composited over Blender's Sidebar/N-panel and making the whole panel
    look translucent.  It does not change theme colors, panel alpha, workspace
    settings, or any Blender UI region.
    """
    try:
        clip_scissor = _sos_overlay_clip_rect_excluding_ui(context)
        if clip_scissor is None:
            return None
        try:
            previous_scissor = tuple(gpu.state.scissor_get())
        except Exception:
            previous_scissor = None
        try:
            previous_scissor_test = bool(gpu.state.scissor_test_get())
        except Exception:
            previous_scissor_test = False
        token = {'previous_scissor': previous_scissor, 'previous_scissor_test': previous_scissor_test}
        _sos_post_pixel_ui_clip_stack.append(token)
        try:
            gpu.state.scissor_test_set(True)
        except Exception:
            pass
        try:
            gpu.state.scissor_set(*clip_scissor)
        except Exception:
            pass
        return token
    except Exception:
        return None


def _sos_end_post_pixel_ui_region_clip(token=None) -> None:
    if token is None:
        return
    try:
        if _sos_post_pixel_ui_clip_stack:
            _sos_post_pixel_ui_clip_stack.pop()
    except Exception:
        pass
    try:
        previous_scissor_test = bool(token.get('previous_scissor_test', False)) if isinstance(token, dict) else False
        gpu.state.scissor_test_set(previous_scissor_test)
    except Exception:
        pass
    try:
        previous_scissor = token.get('previous_scissor') if isinstance(token, dict) else None
        if previous_scissor is not None:
            gpu.state.scissor_set(*previous_scissor)
    except Exception:
        pass


def _sos_reset_gpu_state_after_draw() -> None:
    """Restore the current draw-handler snapshot without changing theme alpha."""
    snapshot = None
    try:
        if _sos_gpu_state_restore_stack:
            snapshot = _sos_gpu_state_restore_stack[-1]
    except Exception:
        snapshot = None
    _sos_restore_gpu_state_snapshot(snapshot)

def _sos_draw_context_has_view3d(context=None) -> bool:
    """Return True when at least one visible 3D View can execute POST_VIEW drawing."""
    try:
        ctx = context or bpy.context
        wm = getattr(ctx, 'window_manager', None)
        if wm is None:
            return False
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                if getattr(area, 'type', None) == 'VIEW_3D':
                    return True
    except Exception:
        pass
    return False


def _sos_core_overlay_runtime_requested(context=None) -> bool:
    """True when the process-shared View3D runtime should stay resident.

    This predicate is used only by the finite recovery timer, never by a draw
    or input callback.  Handler residency therefore follows the event-bound
    visible-workspace aggregate; each callback still applies its own target
    workspace gate before publishing, drawing, or consuming input.
    """
    try:
        ctx = context or bpy.context
        wm = getattr(ctx, 'window_manager', None)
        if wm is None:
            return False
        feature_requested = bool(getattr(wm, 'sos_enabled', False)) or bool(
            getattr(wm, 'sos_object_hover_overlay_enabled', False)
        )
        if not feature_requested:
            return False
        from . import common as _sos_common
        return bool(_sos_common.visible_window_view3d_runtime_allowed(ctx))
    except Exception:
        return False


def _sos_perf_counter() -> float:
    try:
        return time.perf_counter()
    except Exception:
        return time.time()


def _sos_edit_overlay_circuit_breaker_active() -> bool:
    try:
        return _sos_perf_counter() < float(_sos_edit_batch_circuit_breaker_until or 0.0)
    except Exception:
        return False


def _sos_note_edit_budget_overrun(reason: str = '', obj_name: str = '', duration: float = 0.0) -> None:
    """Enter a short cache-reuse window after an expensive edit overlay rebuild.

    This is deliberately non-destructive: it does not disable the add-on, does not
    unregister handlers, and does not touch Blender data.  It only asks subsequent
    draw calls to reuse cached overlay batches until Blender has returned control
    to the user and a safe redraw can rebuild from current BMesh data.
    """
    global _sos_edit_batch_circuit_breaker_until, _sos_last_edit_budget_overrun_time
    global _sos_last_edit_budget_overrun_reason, _sos_edit_budget_overrun_count
    try:
        now = _sos_perf_counter()
        _sos_edit_batch_circuit_breaker_until = max(
            float(_sos_edit_batch_circuit_breaker_until or 0.0),
            now + _SOS_EDIT_BATCH_EMERGENCY_SUPPRESS_SECONDS,
        )
        _sos_last_edit_budget_overrun_time = time.time()
        _sos_last_edit_budget_overrun_reason = str(reason or '')[:160]
        _sos_edit_budget_overrun_count = min(1000000000, int(_sos_edit_budget_overrun_count or 0) + 1)
    except Exception:
        pass
    try:
        _sos_schedule_deferred_edit_redraw_timer()
    except Exception:
        pass
    try:
        tag_view3d_redraw(getattr(bpy, 'context', None))
    except Exception:
        pass


def _sos_check_edit_budget(start: float, budget: float = None, reason: str = '') -> None:
    try:
        b = float(_SOS_EDIT_BATCH_BUILD_BUDGET_SECONDS if budget is None else budget)
        if b > 0.0 and (_sos_perf_counter() - float(start)) > b:
            raise _SOSOverlayBudgetExceeded(str(reason or 'edit overlay rebuild budget exceeded'))
    except _SOSOverlayBudgetExceeded:
        raise
    except Exception:
        return




def _sos_edit_build_budget_for_elements(total_elements: int, prefs=None) -> float:
    """Return draw-build budget for edit overlay collection.

    When Dense mesh/curve LOD is OFF, the user explicitly asked for full overlay
    output even on dense meshes. Give the first/live rebuild a larger bounded
    budget so the overlay appears instead of being skipped by the freeze guard.
    The budget is still capped so Blender can recover and the watchdog can reuse
    the last good cache if a scene is truly too heavy.
    """
    try:
        total = max(0, int(total_elements or 0))
    except Exception:
        total = 0
    try:
        lod_on = bool(_sos_opt_bool(prefs, 'optimization_lightest_lod_skip_dense_vertices_edges', False))
    except Exception:
        lod_on = False
    base = float(_SOS_EDIT_BATCH_BUILD_BUDGET_SECONDS)
    if lod_on:
        return base
    if total <= _SOS_EDIT_BATCH_HEAVY_ELEMENT_LIMIT:
        return max(base, 0.28)
    if total > 1200000:
        return 1.25
    if total > 700000:
        return 1.05
    if total > 350000:
        return 0.85
    return 0.65

def _sos_edit_signature_budget_for_elements(total_elements: int, prefs=None) -> float:
    """Return signature budget for edit overlay cache keys.

    Dense LOD OFF means the overlay must remain visible even on dense meshes.
    The signature phase happens before batch creation, so it needs the same
    bounded expansion as the build phase; otherwise the cache key over-budget
    can prevent the actual overlay batches from ever being generated.
    """
    try:
        total = max(0, int(total_elements or 0))
    except Exception:
        total = 0
    try:
        lod_on = bool(_sos_opt_bool(prefs, 'optimization_lightest_lod_skip_dense_vertices_edges', False))
    except Exception:
        lod_on = False
    base = float(_SOS_EDIT_BATCH_SIGNATURE_BUDGET_SECONDS)
    if lod_on:
        return base
    if total <= _SOS_EDIT_BATCH_HEAVY_ELEMENT_LIMIT:
        return max(base, 0.09)
    if total > 1200000:
        return 0.42
    if total > 700000:
        return 0.32
    if total > 350000:
        return 0.24
    return 0.16


def _sos_heavy_edit_mesh_fallback_required(total_elements: int, cache=None) -> bool:
    try:
        total = int(total_elements or 0)
    except Exception:
        total = 0
    if total <= 0:
        return False
    if cache is not None and total > _SOS_EDIT_BATCH_HEAVY_ELEMENT_LIMIT:
        try:
            # After one over-budget rebuild, keep using the last safe cache for a
            # short cooldown instead of retrying the same expensive work every
            # redraw.  When the cooldown expires, one rebuild attempt is allowed.
            if (time.time() - float(_sos_last_edit_budget_overrun_time or 0.0)) < 1.25:
                return True
        except Exception:
            return True
    return bool(cache is None and total > _SOS_EDIT_BATCH_NO_CACHE_HARD_LIMIT)


def _sos_sample_indices(count: int, limit: int = 512):
    try:
        count = int(count or 0)
        limit = max(1, int(limit or 1))
    except Exception:
        return ()
    if count <= 0:
        return ()
    if count <= limit:
        return range(count)
    step = max(1, count // limit)
    return range(0, count, step)


def _sos_remove_view3d_handlers_for_rehook() -> None:
    """Remove current handlers only from the watchdog path before a fresh install."""
    global _draw_handler, _pixel_draw_handler
    if _draw_handler is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_draw_handler, 'WINDOW')
        except Exception:
            pass
        _draw_handler = None
    if _pixel_draw_handler is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_pixel_draw_handler, 'WINDOW')
        except Exception:
            pass
        _pixel_draw_handler = None


def _sos_front_post_pixel_provider_records(callback_name: str):
    registry = bpy.app.driver_namespace.get(_SOS_FRONT_POST_PIXEL_LAYER_POLICY_KEY)
    if not isinstance(registry, dict):
        return ()
    providers = []
    for owner, record in tuple(registry.items()):
        if not isinstance(record, dict):
            continue
        if str(record.get('space') or '') != 'SpaceView3D':
            continue
        if str(record.get('region') or '') != 'WINDOW':
            continue
        if str(record.get('stage') or '') != 'POST_PIXEL':
            continue
        callback = record.get(callback_name)
        if not callable(callback):
            continue
        try:
            layer = int(record.get('layer') or 0)
        except Exception:
            layer = 0
        providers.append((layer, str(owner or ''), callback))
    return tuple(sorted(providers, key=lambda item: (item[0], item[1])))


def _sos_set_front_post_pixel_replay_active(active: bool) -> None:
    try:
        bpy.app.driver_namespace[_SOS_FRONT_POST_PIXEL_REPLAY_ACTIVE_KEY] = bool(active)
    except Exception:
        pass


def _sos_front_post_pixel_adopt_timer():
    """Move tool-owned HUD handlers behind no dependency on Overlay drawing.

    Providers keep their own POST_PIXEL handlers alive and only re-register
    them after Smart Overlay's handler.  This preserves Blender's normal draw
    lifecycle while deterministically placing tool HUDs in front.
    """
    global _sos_front_post_pixel_adopt_pending
    try:
        if _pixel_draw_handler is None:
            return None
        _sos_set_front_post_pixel_replay_active(True)
        for _layer, _owner, callback in _sos_front_post_pixel_provider_records('rehook_callback'):
            try:
                callback()
            except Exception:
                pass
        try:
            tag_view3d_redraw(getattr(bpy, 'context', None))
        except Exception:
            pass
    except Exception:
        pass
    finally:
        _sos_front_post_pixel_adopt_pending = False
    return None


def _sos_schedule_front_post_pixel_adopt() -> None:
    """Coalesce one event-side provider rehook after an Overlay install."""
    global _sos_front_post_pixel_adopt_pending
    if _sos_front_post_pixel_adopt_pending:
        return
    try:
        if bool(getattr(getattr(bpy, 'app', None), 'background', False)):
            return
    except Exception:
        pass
    _sos_front_post_pixel_adopt_pending = True
    try:
        bpy.app.timers.register(_sos_front_post_pixel_adopt_timer, first_interval=0.0, persistent=False)
    except Exception:
        _sos_front_post_pixel_adopt_pending = False


def _sos_release_front_post_pixel_providers() -> None:
    """Keep each tool HUD independent when Smart Overlay stops."""
    _sos_set_front_post_pixel_replay_active(False)
    for _layer, _owner, callback in _sos_front_post_pixel_provider_records('release_callback'):
        try:
            callback()
        except Exception:
            pass


def _sos_replay_front_post_pixel_providers() -> None:
    """Compatibility no-op; tool HUDs are never proxy-drawn by Smart Overlay."""
    return None


def _sos_install_view3d_handlers_if_needed(*, force: bool = False) -> None:
    """Install or reinstall Smart Overlay View3D draw handlers without touching UI state."""
    global _draw_handler, _pixel_draw_handler, _sos_last_runtime_rehook_time
    if force:
        _sos_remove_view3d_handlers_for_rehook()
        _sos_last_runtime_rehook_time = time.time()
    if _draw_handler is None:
        try:
            _draw_handler = bpy.types.SpaceView3D.draw_handler_add(draw_callback_3d, (), 'WINDOW', 'POST_VIEW')
        except Exception:
            _draw_handler = None
    if _pixel_draw_handler is None:
        try:
            _pixel_draw_handler = bpy.types.SpaceView3D.draw_handler_add(draw_callback_lattice_front_pixels, (), 'WINDOW', 'POST_PIXEL')
            _sos_set_front_post_pixel_replay_active(True)
            # Handler order is the z-order for SpaceView3D POST_PIXEL drawing.
            # Rehook providers immediately so a stale/pending timer can never
            # leave tool HUDs behind the newly installed Smart Overlay handler.
            _sos_front_post_pixel_adopt_timer()
        except Exception:
            _pixel_draw_handler = None


def _sos_runtime_watchdog_timer():
    """Compatibility one-shot; periodic runtime polling is retired."""
    try:
        if not _sos_runtime_registered:
            return None
        _sos_install_view3d_handlers_if_needed(force=False)
        handlers = getattr(bpy.app.handlers, 'depsgraph_update_post', None)
        if handlers is not None and _sos_depsgraph_update not in handlers:
            handlers.append(_sos_depsgraph_update)
        request_overlay_snapshot_rebuild('runtime_repair', context=getattr(bpy, 'context', None), immediate=True)
    except Exception:
        pass
    return None

def _sos_start_runtime_watchdog() -> None:
    # Registration/load/Manager events perform one bounded repair. Stable idle
    # sessions retain no watchdog timer.
    _sos_runtime_watchdog_timer()

def _sos_stop_runtime_watchdog() -> None:
    try:
        if bpy.app.timers.is_registered(_sos_runtime_watchdog_timer):
            bpy.app.timers.unregister(_sos_runtime_watchdog_timer)
    except Exception:
        pass





def _sos_tag_all_overlay_editors_redraw(context=None) -> None:
    """Redraw every editor used by Smart Overlay without assuming active area type."""
    try:
        _sos_note_runtime_redraw_request()
    except Exception:
        pass
    try:
        tag_view3d_redraw(context)
    except Exception:
        pass
    try:
        ctx = context or bpy.context
        wm = getattr(ctx, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                if getattr(area, 'type', None) in {'VIEW_3D', 'IMAGE_EDITOR'}:
                    try:
                        area.tag_redraw()
                    except Exception:
                        pass
    except Exception:
        pass


def _sos_reset_runtime_memory_state(*, preserve_evaluated_face_cache: bool = False) -> None:
    """Clear Python/GPU-side runtime state without touching Blender data blocks."""
    global _shader, _grad_shader, _dash_shader, _grad_dash_shader, _lattice_pixel_shader, _selected_element_pixel_shader, _post_pixel_polyline_shader, _sos_last_runtime_mode, _sos_draw_exception_count
    try:
        _sos_invalidate_all_overlay_geometry_caches(preserve_evaluated_face_cache=preserve_evaluated_face_cache)
    except Exception:
        pass
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and timers.is_registered(_sos_lattice_pixel_snapshot_timer):
            timers.unregister(_sos_lattice_pixel_snapshot_timer)
    except Exception:
        pass
    try:
        _sos_lattice_front_points_by_region.clear()
        _sos_lattice_pixel_snapshot_by_region.clear()
        _sos_lattice_region_size_by_region.clear()
    except Exception:
        pass
    try:
        reset_object_hover_cache()
        _sos_clear_hover_click_outcome()
        _sos_hover_provider_press_receipts.clear()
    except Exception:
        pass
    _shader = None
    _grad_shader = None
    _dash_shader = None
    _grad_dash_shader = None
    _lattice_pixel_shader = None
    _selected_element_pixel_shader = None
    _post_pixel_polyline_shader = None
    _sos_last_runtime_mode = ""
    _sos_draw_exception_count = 0
    # GPU state setters require an active draw context in Blender 5.1.2.
    # Runtime teardown/restart can execute from operators or app timers, where
    # calling gpu.state.* can crash Blender before Python can catch anything.
    # Every Smart Overlay draw callback already restores GPU state in its own
    # draw-context finally path, so memory teardown must remain CPU-only.


def _sos_runtime_recovery_timer():
    """Timer-side repair used after draw exceptions or a manual recovery toggle."""
    global _sos_runtime_recovery_timer_pending, _sos_runtime_recovery_timer_attempts
    try:
        if not _sos_runtime_registered:
            _sos_runtime_recovery_timer_pending = False
            _sos_runtime_recovery_timer_attempts = 0
            return None
        if _sos_core_overlay_runtime_requested():
            try:
                _sos_reset_runtime_memory_state(preserve_evaluated_face_cache=False)
            except Exception:
                pass
            try:
                _sos_install_view3d_handlers_if_needed(force=True)
            except Exception:
                pass
            try:
                handlers = getattr(bpy.app.handlers, 'depsgraph_update_post', None)
                if handlers is not None and _sos_depsgraph_update not in handlers:
                    handlers.append(_sos_depsgraph_update)
            except Exception:
                pass
            try:
                _sos_start_runtime_watchdog()
            except Exception:
                pass
            try:
                _sos_tag_all_overlay_editors_redraw()
            except Exception:
                pass
        _sos_runtime_recovery_timer_attempts = max(0, int(_sos_runtime_recovery_timer_attempts or 0) - 1)
        if _sos_runtime_recovery_timer_attempts > 0:
            return _SOS_RUNTIME_RECOVERY_INTERVAL
    except Exception:
        _sos_runtime_recovery_timer_attempts = 0
    _sos_runtime_recovery_timer_pending = False
    return None


def _sos_schedule_runtime_recovery(context=None, *, attempts: int = 2, first_interval: float = _SOS_RUNTIME_RECOVERY_INTERVAL) -> None:
    """Schedule a non-draw-callback hard repair for overlay runtime state."""
    del context
    global _sos_runtime_recovery_timer_pending, _sos_runtime_recovery_timer_attempts
    try:
        _sos_runtime_recovery_timer_attempts = max(int(_sos_runtime_recovery_timer_attempts or 0), max(1, int(attempts)))
    except Exception:
        _sos_runtime_recovery_timer_attempts = 2
    if _sos_runtime_recovery_timer_pending:
        return
    _sos_runtime_recovery_timer_pending = True
    try:
        bpy.app.timers.register(_sos_runtime_recovery_timer, first_interval=max(0.0, float(first_interval)), persistent=False)
    except Exception:
        _sos_runtime_recovery_timer_pending = False


def _sos_sync_package_core_runtime_state(context=None) -> None:
    """Keep the package-level deferred-runtime state coherent after a manual reset."""
    try:
        ctx = context or bpy.context
        wm = getattr(ctx, 'window_manager', None)
        pkg = sys.modules.get(str(__package__ or ''))
        state = getattr(pkg, '_CORE_RUNTIME_STATE', None)
        if isinstance(state, dict) and wm is not None:
            state['mesh'] = bool(getattr(wm, 'sos_enabled', False)) or bool(getattr(wm, 'sos_object_hover_overlay_enabled', False))
            state['prop'] = bool(getattr(wm, 'sos_proportional_overlay_enabled', False))
            state['uv'] = bool(getattr(wm, 'sos_uv_overlay_enabled', False))
    except Exception:
        pass




def _sos_mesh_curve_overlay_runtime_unhealthy(context=None) -> bool:
    """Detect common silent-runtime states while the mesh/curve overlay is ON."""
    try:
        ctx = context or bpy.context
        wm = getattr(ctx, 'window_manager', None)
        if wm is None or not bool(getattr(wm, 'sos_enabled', False)):
            return False
        if not bool(_sos_runtime_registered):
            return True
        if _draw_handler is None or _pixel_draw_handler is None:
            return True
        handlers = getattr(bpy.app.handlers, 'depsgraph_update_post', None)
        if handlers is not None and _sos_depsgraph_update not in handlers:
            return True
        # The runtime watchdog is an event-driven compatibility one-shot and
        # intentionally has no persistent timer registration.  Runtime health
        # is defined by the actual draw handles and depsgraph handler above.
        if int(_sos_draw_exception_count or 0) > 0:
            return True
        if _sos_draw_context_has_view3d(ctx):
            now = time.time()
            last = float(_sos_last_view3d_draw_time or _sos_runtime_started_at or 0.0)
            last_request = float(_sos_last_runtime_redraw_request_time or 0.0)
            # Only a missed redraw request is unhealthy.  An old draw timestamp
            # during normal idle time must not block the shortcut from toggling OFF.
            if last_request > 0.0 and last < last_request and (now - last_request) > 0.75:
                return True
    except Exception:
        return True
    return False

def sos_hard_restart_overlay_runtime(context=None, *, target_enabled=None) -> bool:
    """Force-restart Smart Overlay runtimes and set the Mesh/Curve overlay state.

    This is intentionally stronger than a normal BoolProperty update.  It removes
    and recreates draw handlers, depsgraph handlers, passive cursor probe, GPU
    shaders, and geometry caches so the shortcut ``view3d.sos_toggle_overlay`` can
    be used as a recovery switch when a previous draw/update path went silent.
    """
    ctx = context or bpy.context
    try:
        wm = getattr(ctx, 'window_manager', None)
    except Exception:
        wm = None
    if wm is None:
        return False

    try:
        next_state = (not bool(getattr(wm, 'sos_enabled', False))) if target_enabled is None else bool(target_enabled)
    except Exception:
        next_state = bool(target_enabled)

    try:
        hover_state = bool(getattr(wm, 'sos_object_hover_overlay_enabled', False))
    except Exception:
        hover_state = False
    # Stop the shared View3D runtime first.  This removes stale draw handlers and
    # stale depsgraph handlers that may have survived editor changes or exceptions.
    try:
        unregister_addon_runtime()
    except Exception:
        pass

    try:
        _sos_reset_runtime_memory_state(preserve_evaluated_face_cache=False)
    except Exception:
        pass

    try:
        setattr(wm, 'sos_enabled', bool(next_state))
    except Exception:
        return False

    # Rebuild the shared View3D runtime if the mesh/curve overlay or object hover
    # still needs it.  register_addon_runtime() is idempotent and re-adds handlers,
    # depsgraph listeners, and the passive cursor probe.
    if bool(next_state) or bool(hover_state):
        try:
            register_addon_runtime()
        except Exception:
            try:
                _sos_install_view3d_handlers_if_needed(force=True)
                _sos_start_runtime_watchdog()
            except Exception:
                pass

    # Do not restart UV / proportional runtimes on every mesh overlay shortcut.
    # That made a simple visibility toggle unnecessarily heavy and could interrupt
    # active UV editing.  Their own watchdogs keep those runtimes alive; the mesh
    # shortcut only repairs the shared View3D mesh/curve runtime it controls.

    try:
        _sos_sync_package_core_runtime_state(ctx)
    except Exception:
        pass
    if bool(next_state) or bool(hover_state):
        try:
            _sos_schedule_runtime_recovery(ctx, attempts=2, first_interval=0.03)
        except Exception:
            pass
    try:
        tag_view3d_redraw(ctx)
    except Exception:
        pass
    return True

def _sos_native_view3d_selection_operator_active(context=None) -> bool:
    """Return True briefly while Blender's native region-selection tools run.

    ``WindowManager.operators`` is a history-like stack on some Blender builds: a
    completed ``view3d.select_box`` / ``select_circle`` / ``select_lasso`` entry can
    remain visible for many redraws after the selection operation has finished.
    Treating that stale entry as an active GPU selection pass makes every Smart
    Overlay draw callback return early, which looks like the whole add-on stopped.

    The guard is therefore time-boxed.  A new selection-operator signature suppresses
    Smart Overlay drawing for a short window covering the actual selection redraw;
    after that, the same stale operator entry is ignored and normal overlay drawing
    resumes automatically.
    """
    global _sos_selection_guard_signature, _sos_selection_guard_until
    ctx = context or getattr(bpy, 'context', None)
    try:
        wm = getattr(ctx, 'window_manager', None)
    except Exception:
        wm = None
    if wm is None:
        return False
    try:
        ops = tuple(getattr(wm, 'operators', ()) or ())
    except Exception:
        ops = ()
    now = time.time()
    select_tokens = (
        'SELECT_BOX',
        'SELECT_CIRCLE',
        'SELECT_LASSO',
        'VIEW3D_OT_SELECT_BOX',
        'VIEW3D_OT_SELECT_CIRCLE',
        'VIEW3D_OT_SELECT_LASSO',
    )
    selection_names = []
    for op in ops[-8:]:
        names = []
        for attr in ('bl_idname', 'idname', 'name'):
            try:
                value = getattr(op, attr, '')
            except Exception:
                value = ''
            if value:
                names.append(str(value))
        try:
            rna = getattr(op, 'bl_rna', None)
            ident = getattr(rna, 'identifier', '')
            if ident:
                names.append(str(ident))
        except Exception:
            pass
        joined = ' '.join(names).upper().replace('.', '_')
        if any(token in joined for token in select_tokens):
            selection_names.append(joined)

    if not selection_names:
        return bool(now <= float(_sos_selection_guard_until or 0.0))

    signature = tuple(selection_names[-3:])
    try:
        if signature != _sos_selection_guard_signature:
            _sos_selection_guard_signature = signature
            _sos_selection_guard_until = now + _SOS_SELECTION_SUPPRESS_SECONDS
            return True
        # Do not extend the timeout for the same operator-history entry forever.
        # This prevents stale selection history from permanently hiding overlays.
        return bool(now <= float(_sos_selection_guard_until or 0.0))
    except Exception:
        return False

def _sos_should_skip_custom_draw_for_selection(context=None) -> bool:
    # Keep this helper for proportional/UV callbacks, but make it non-invasive.
    # It must never write to the GPU selection ID buffer or treat normal redraws
    # as selection redraws.
    try:
        return bool(_sos_native_view3d_selection_operator_active(context))
    except Exception:
        return False

def _sos_edit_mesh_rebuild_deferred_active() -> bool:
    try:
        return time.time() < float(_sos_edit_mesh_rebuild_deferred_until or 0.0)
    except Exception:
        return False


def _sos_deferred_edit_redraw_timer():
    global _sos_deferred_edit_redraw_timer_active
    try:
        now = time.time()
        until = float(_sos_edit_mesh_rebuild_deferred_until or 0.0)
        if now < until:
            return max(0.01, min(0.15, until - now))
        _sos_apply_deferred_edit_cache_invalidations_if_safe()
        try:
            tag_view3d_redraw(getattr(bpy, 'context', None))
        except Exception:
            pass
    except Exception:
        pass
    _sos_deferred_edit_redraw_timer_active = False
    return None


def _sos_schedule_deferred_edit_redraw_timer() -> None:
    global _sos_deferred_edit_redraw_timer_active
    try:
        if _sos_deferred_edit_redraw_timer_active:
            return
        _sos_deferred_edit_redraw_timer_active = True
        bpy.app.timers.register(_sos_deferred_edit_redraw_timer, first_interval=0.02)
    except Exception:
        _sos_deferred_edit_redraw_timer_active = False


def _sos_defer_edit_mesh_cache_rebuild(obj_names=(), *, duration: float = _SOS_EDIT_MESH_REBUILD_DEFER_SECONDS, global_invalidate: bool = False) -> None:
    """Delay BMesh re-scans after edit-mesh operations that can leave Blender
    rebuilding edit data internally.

    The delay intentionally keeps existing GPU batches alive.  Rebuilding them
    inside the same depsgraph / redraw wave as seam, sharp, merge, split, or
    multi-object edit operations can dereference transient edit-mesh memory in
    Blender C code before Python can catch anything.
    """
    global _sos_edit_mesh_rebuild_deferred_until, _sos_deferred_edit_cache_global_invalidation
    try:
        now = time.time()
        _sos_edit_mesh_rebuild_deferred_until = max(
            float(_sos_edit_mesh_rebuild_deferred_until or 0.0),
            now + max(0.01, float(duration)),
        )
    except Exception:
        _sos_edit_mesh_rebuild_deferred_until = time.time() + _SOS_EDIT_MESH_REBUILD_DEFER_SECONDS
    try:
        for name in obj_names or ():
            name = str(name or '')
            if name:
                _sos_deferred_edit_cache_invalidations.add(name)
    except Exception:
        pass
    if global_invalidate:
        _sos_deferred_edit_cache_global_invalidation = True
    _sos_schedule_deferred_edit_redraw_timer()


def _sos_apply_deferred_edit_cache_invalidations_if_safe() -> None:
    global _sos_deferred_edit_cache_global_invalidation
    if _sos_edit_mesh_rebuild_deferred_active():
        return
    try:
        preserve_eval_faces = bool(_sos_should_preserve_evaluated_face_cache_for_context())
    except Exception:
        preserve_eval_faces = False
    try:
        if _sos_deferred_edit_cache_global_invalidation:
            _sos_invalidate_all_overlay_geometry_caches(preserve_evaluated_face_cache=preserve_eval_faces)
            _sos_deferred_edit_cache_global_invalidation = False
            _sos_deferred_edit_cache_invalidations.clear()
            return
    except Exception:
        _sos_deferred_edit_cache_global_invalidation = False
    try:
        pending = tuple(_sos_deferred_edit_cache_invalidations)
        _sos_deferred_edit_cache_invalidations.clear()
    except Exception:
        pending = ()
    for obj_name in pending:
        try:
            _invalidate_object_cache(str(obj_name), preserve_evaluated_face_cache=preserve_eval_faces)
        except Exception:
            pass


def _sos_edit_mesh_mutation_operator_guard_active(context=None) -> bool:
    """Return True briefly after native mesh edit operators likely to rebuild BMesh.

    WindowManager.operators is history-like, so the guard is time-boxed and keyed
    by both operator name and object identity where Blender exposes it.  This is
    only a rebuild throttle; already cached overlay batches continue to draw.
    """
    global _sos_edit_mutation_guard_signature, _sos_edit_mutation_guard_until
    ctx = context or getattr(bpy, 'context', None)
    try:
        if str(getattr(ctx, 'mode', '') or '') != 'EDIT_MESH':
            return False
    except Exception:
        return False
    try:
        wm = getattr(ctx, 'window_manager', None)
        ops = tuple(getattr(wm, 'operators', ()) or ()) if wm is not None else ()
    except Exception:
        ops = ()
    now = time.time()
    tokens = (
        # Only operations that can rebuild or invalidate BMesh storage are treated
        # as unsafe for immediate redraw.  Pure selection operations and standard
        # transform operators are intentionally excluded so overlays can follow
        # live editing without a stale-cache window.
        'MESH_OT_MARK_SEAM', 'MESH_OT_MARK_SHARP', 'MESH_OT_EDGE_CREASE',
        'MESH_OT_REMOVE_DOUBLES', 'MESH_OT_MERGE', 'MESH_OT_SPLIT',
        'MESH_OT_DELETE', 'MESH_OT_DISSOLVE', 'MESH_OT_RIP',
        'MESH_OT_SEPARATE', 'MESH_OT_DUPLICATE', 'MESH_OT_EXTRUDE',
        'MESH_OT_BEVEL', 'MESH_OT_INSET', 'MESH_OT_KNIFE',
        'OBJECT_OT_EDITMODE_TOGGLE',
    )
    seen = []
    for op in ops[-10:]:
        names = []
        for attr in ('bl_idname', 'idname', 'name'):
            try:
                value = getattr(op, attr, '')
            except Exception:
                value = ''
            if value:
                names.append(str(value))
        try:
            ident = getattr(getattr(op, 'bl_rna', None), 'identifier', '')
            if ident:
                names.append(str(ident))
        except Exception:
            pass
        joined = ' '.join(names).upper().replace('.', '_')
        if any(token in joined for token in tokens):
            try:
                ptr = int(op.as_pointer())
            except Exception:
                ptr = id(op)
            seen.append((joined, ptr))
    if not seen:
        return bool(now <= float(_sos_edit_mutation_guard_until or 0.0))
    signature = tuple(seen[-3:])
    try:
        if signature != _sos_edit_mutation_guard_signature:
            _sos_edit_mutation_guard_signature = signature
            _sos_edit_mutation_guard_until = now + _SOS_EDIT_MUTATION_SUPPRESS_SECONDS
            names = []
            try:
                for obj in getattr(ctx, 'objects_in_mode', ()) or ():
                    if getattr(obj, 'type', None) == 'MESH':
                        name = str(getattr(obj, 'name', '') or '')
                        if name:
                            names.append(name)
            except Exception:
                names = []
            _sos_defer_edit_mesh_cache_rebuild(names, duration=_SOS_EDIT_MUTATION_SUPPRESS_SECONDS)
            return True
        return bool(now <= float(_sos_edit_mutation_guard_until or 0.0))
    except Exception:
        return False


def _sos_append_cached_edit_mesh_batch(batches, obj, cache, *, prefer_evaluated_faces=False, shader=None) -> bool:
    """Append a cached edit batch without reintroducing pre-modifier face fill.

    Generic edit-cache protection paths (navigation, topology guards, draw-budget
    fallbacks) may reuse an older base batch.  When evaluated edit-mode faces are
    enabled, replace that cached face batch with the pinned modifier-result batch,
    or suppress only the face fill if no evaluated result exists yet.  Edge,
    vertex, selection, hover, and diagnostic batches remain reusable.
    """
    try:
        eval_batch = _sos_latest_evaluated_face_batch(obj, shader) if prefer_evaluated_faces else None
        if not isinstance(cache, dict):
            # A depsgraph invalidation or draw-budget guard can temporarily remove
            # the editable-cage batch even though the pinned modifier-result face
            # buffer is still valid.  Keep that face layer visible on its own; a
            # missing edge/vertex cache must never make the requested evaluated
            # face overlay disappear or expose the pre-modifier cage.
            if eval_batch is None:
                return False
            bd = SOS_BatchData(obj.matrix_world)
            bd.is_mod_eval = True
            bd.batch_tris = eval_batch
            batches.append(bd)
            return True
        bs = cache.get('base')
        if bs is None:
            if eval_batch is None:
                return False
            bd = SOS_BatchData(obj.matrix_world)
            bd.is_mod_eval = True
            bd.batch_tris = eval_batch
            batches.append(bd)
            return True
        bd = SOS_BatchData(obj.matrix_world)
        try:
            bd.is_mod_eval = bool(getattr(bs, 'is_mod_eval', False))
        except Exception:
            bd.is_mod_eval = False
        bd.face_op_mul = getattr(bs, 'face_op_mul', 1.0)
        bd.edge_alpha_mul = getattr(bs, 'edge_alpha_mul', 1.0)
        for attr in (
            'batch_tris', 'batch_edges', 'batch_verts', 'batch_sel_edges',
            'batch_sel_verts', 'batch_sel_tris', 'batch_face_center_verts',
            'batch_sel_face_center_verts', 'batch_surface_depth_tris', 'batch_cover_edges',
            'batch_cover_verts', 'batch_cover_tris', 'batch_half_sel_vis',
            'batch_half_sel_occ', 'batch_topo_seam', 'batch_topo_sharp',
            'batch_topo_crease', 'batch_topo_bevel', 'batch_topo_nonmanifold',
            'batch_topo_ngons', 'batch_topo_small', 'batch_topo_all_faces',
            'batch_native_seam', 'batch_native_sharp', 'batch_native_crease',
            'batch_native_bevel', 'batch_native_cage_seam', 'batch_native_cage_sharp',
            'batch_native_cage_crease', 'batch_native_cage_bevel',
        ):
            try:
                setattr(bd, attr, getattr(bs, attr, None))
            except Exception:
                pass
        if prefer_evaluated_faces:
            if eval_batch is not None:
                bd.batch_tris = eval_batch
                bd.is_mod_eval = True
            elif not bool(getattr(bd, 'is_mod_eval', False)):
                # Never expose the base edit-cage face while evaluated-face mode
                # is requested.  Other cached overlay components still draw.
                bd.batch_tris = None
        batches.append(bd)
        return True
    except Exception:
        return False

def object_hover_overlay_enabled(context=None):
    ctx = context or bpy.context
    wm = getattr(ctx, "window_manager", None)
    if wm is None:
        return True
    return bool(getattr(wm, "sos_object_hover_overlay_enabled", False))


def _sos_clear_selected_hover_suppression() -> None:
    global _sos_selected_hover_suppression
    _sos_selected_hover_suppression = {}


def _sos_arm_selected_hover_suppression(context, event, obj) -> None:
    """Hide hover color at one committed click until the pointer really moves."""
    global _sos_selected_hover_suppression
    try:
        if obj is None or not bool(obj.select_get()):
            _sos_selected_hover_suppression = {}
            return
        area, region, _rv3d = _sos_view3d_region_from_event(context, event)
        if area is None or region is None:
            _sos_selected_hover_suppression = {}
            return
        mouse_x = int(getattr(event, 'mouse_x', -1000000))
        mouse_y = int(getattr(event, 'mouse_y', -1000000))
        local_x = mouse_x - int(getattr(region, 'x', 0) or 0)
        local_y = mouse_y - int(getattr(region, 'y', 0) or 0)
        _sos_selected_hover_suppression = {
            'window_ptr': _sos_pointer(getattr(context, 'window', None)),
            'area_ptr': _sos_pointer(area),
            'region_ptr': _sos_pointer(region),
            'scene_ptr': _sos_pointer(getattr(context, 'scene', None)),
            'object_name': str(getattr(obj, 'name', '') or ''),
            'object_ptr': _sos_pointer(obj),
            'mouse_local': (int(local_x), int(local_y)),
            'created': time.time(),
        }
    except Exception:
        _sos_selected_hover_suppression = {}


def _sos_selected_hover_suppression_active(context, region, mx: int, my: int) -> bool:
    """Return True only at the unchanged click position after a successful select."""
    global _sos_selected_hover_suppression
    info = _sos_selected_hover_suppression if isinstance(_sos_selected_hover_suppression, dict) else {}
    if not info:
        return False
    try:
        if _sos_pointer(getattr(context, 'window', None)) != int(info.get('window_ptr', 0) or 0):
            return False
        if _sos_pointer(getattr(context, 'area', None)) != int(info.get('area_ptr', 0) or 0):
            return False
        if _sos_pointer(region) != int(info.get('region_ptr', 0) or 0):
            return False
        if _sos_pointer(getattr(context, 'scene', None)) != int(info.get('scene_ptr', 0) or 0):
            _sos_selected_hover_suppression = {}
            return False
        start_x, start_y = tuple(info.get('mouse_local') or (-1000000, -1000000))
        try:
            tolerance = max(2, min(8, int(_sos_hover_click_drag_threshold(context) or 0)))
        except Exception:
            tolerance = 3
        if abs(int(mx) - int(start_x)) > tolerance or abs(int(my) - int(start_y)) > tolerance:
            _sos_selected_hover_suppression = {}
            return False
        scene = getattr(context, 'scene', None)
        obj = scene.objects.get(str(info.get('object_name') or '')) if scene is not None else None
        if obj is None or _sos_pointer(obj) != int(info.get('object_ptr', 0) or 0) or not bool(obj.select_get()):
            _sos_selected_hover_suppression = {}
            return False
        return True
    except Exception:
        _sos_selected_hover_suppression = {}
        return False


def _sos_batch_is_active_object_hover(context, batch_data) -> bool:
    """Return the visual hover state, honoring a committed click immediately.

    A snapshot built before the click can still contain a yellow hover batch.
    While the pointer remains at the committed click position, render that batch
    with the normal selected/base overlay path instead of replaying yellow.
    """
    if not bool(getattr(batch_data, 'is_hover_obj', False)):
        return False
    # Selection color owns the object immediately after the click. A snapshot
    # completed before that click may still carry is_hover_obj=True; consult the
    # live RNA selection first so yellow can never cover the selected blue pass.
    # Sculpt Mode is the exception: the sculpted object is always selected, so
    # this rule would hide its hover overlay permanently.
    try:
        is_sculpt = str(getattr(context, 'mode', '') or '') == 'SCULPT'
    except Exception:
        is_sculpt = False
    if not is_sculpt:
        try:
            batch_name = str(getattr(batch_data, 'object_name', '') or '')
            scene = getattr(context, 'scene', None)
            selected_obj = scene.objects.get(batch_name) if scene is not None and batch_name else None
            if selected_obj is not None and bool(selected_obj.select_get()):
                return False
        except Exception:
            pass
    info = _sos_selected_hover_suppression if isinstance(_sos_selected_hover_suppression, dict) else {}
    if not info:
        return True
    try:
        if _sos_pointer(getattr(context, 'window', None)) != int(info.get('window_ptr', 0) or 0):
            return True
        if _sos_pointer(getattr(context, 'area', None)) != int(info.get('area_ptr', 0) or 0):
            return True
        if _sos_pointer(getattr(context, 'region', None)) != int(info.get('region_ptr', 0) or 0):
            return True
        batch_name = str(getattr(batch_data, 'object_name', '') or '')
        if not batch_name or batch_name != str(info.get('object_name', '') or ''):
            return True
        scene = getattr(context, 'scene', None)
        obj = scene.objects.get(batch_name) if scene is not None else None
        if obj is None or not bool(obj.select_get()):
            return True
        return False
    except Exception:
        return True


def reset_object_hover_cache(*, preserve_drawn_regions=False):
    global _sos_cached_hover_obj, _sos_global_hover_obj, _sos_last_mx, _sos_last_my, _sos_last_hover_view_sig
    global _sos_pending_hover_draw_obj, _sos_pending_hover_draw_mx, _sos_pending_hover_draw_my
    global _sos_pending_hover_draw_region_ptr, _sos_pending_hover_draw_view_sig, _sos_pending_hover_draw_until
    global _sos_drawn_hover_obj, _sos_drawn_hover_mx, _sos_drawn_hover_my, _sos_drawn_hover_region_ptr
    global _sos_drawn_hover_view_sig, _sos_drawn_hover_mode, _sos_drawn_hover_time, _sos_drawn_hover_by_region
    _sos_cached_hover_obj = ""
    _sos_global_hover_obj = ""
    _sos_last_mx = -1
    _sos_last_my = -1
    _sos_last_hover_view_sig = None
    _sos_pending_hover_draw_obj = ""
    _sos_pending_hover_draw_mx = -1
    _sos_pending_hover_draw_my = -1
    _sos_pending_hover_draw_region_ptr = 0
    _sos_pending_hover_draw_view_sig = None
    _sos_pending_hover_draw_until = 0.0
    _sos_drawn_hover_obj = ""
    _sos_drawn_hover_mx = -1
    _sos_drawn_hover_my = -1
    _sos_drawn_hover_region_ptr = 0
    _sos_drawn_hover_view_sig = None
    _sos_drawn_hover_mode = ""
    _sos_drawn_hover_time = 0.0
    if not preserve_drawn_regions:
        _sos_drawn_hover_by_region.clear()


def _sos_pointer(value) -> int:
    try:
        return int(getattr(value, "as_pointer", lambda: 0)() or 0)
    except Exception:
        return 0




def _sos_tag_view3d_region_by_token(context, window_ptr: int, area_ptr: int, region_ptr: int) -> bool:
    if not window_ptr or not region_ptr:
        return False
    try:
        wm = getattr(context or bpy.context, 'window_manager', None) or bpy.context.window_manager
        for window in getattr(wm, 'windows', ()) or ():
            if _sos_pointer(window) != int(window_ptr):
                continue
            for area in getattr(getattr(window, 'screen', None), 'areas', ()) or ():
                if area_ptr and _sos_pointer(area) != int(area_ptr):
                    continue
                if getattr(area, 'type', None) != 'VIEW_3D':
                    continue
                for region in getattr(area, 'regions', ()) or ():
                    if getattr(region, 'type', None) != 'WINDOW' or _sos_pointer(region) != int(region_ptr):
                        continue
                    try:
                        region.tag_redraw()
                        return True
                    except Exception:
                        try:
                            area.tag_redraw()
                            return True
                        except Exception:
                            return False
    except Exception:
        pass
    return False


def _sos_set_active_view_context(context, area=None, region=None, rv3d=None, *, source: str = 'unknown', mouse_x=None, mouse_y=None, window=None) -> bool:
    """Store the View3D target confirmed by an actual operation event."""
    global _sos_active_draw_window_ptr, _sos_active_draw_area_ptr
    global _sos_active_draw_region_ptr, _sos_active_draw_rv3d_ptr
    global _sos_active_draw_mouse_x, _sos_active_draw_mouse_y, _sos_active_draw_last_update_time
    global _sos_active_view_last_update_time, _sos_active_view_update_source
    try:
        ctx = context or bpy.context
        win = window or getattr(ctx, 'window', None)
        win_ptr = _sos_pointer(win)
        target_area = area or getattr(ctx, 'area', None)
        area_ptr = _sos_pointer(target_area)
        reg = region or getattr(ctx, 'region', None)
        reg_ptr = _sos_pointer(reg)
        target_rv3d = rv3d or _sos_region_3d_from_area(ctx, target_area, reg, window=win)
        rv3d_ptr = _sos_pointer(target_rv3d)
    except Exception:
        return False
    if not win_ptr or not area_ptr or not reg_ptr or not rv3d_ptr:
        return False

    old_window_ptr = int(_sos_active_draw_window_ptr or 0)
    old_area_ptr = int(_sos_active_draw_area_ptr or 0)
    old_region_ptr = int(_sos_active_draw_region_ptr or 0)
    changed = (
        old_window_ptr != win_ptr
        or old_area_ptr != area_ptr
        or old_region_ptr != reg_ptr
        or int(_sos_active_draw_rv3d_ptr or 0) != rv3d_ptr
    )
    _sos_active_draw_window_ptr = win_ptr
    _sos_active_draw_area_ptr = area_ptr
    _sos_active_draw_region_ptr = reg_ptr
    _sos_active_draw_rv3d_ptr = rv3d_ptr
    try:
        if mouse_x is not None and mouse_y is not None:
            _sos_active_draw_mouse_x = int(mouse_x)
            _sos_active_draw_mouse_y = int(mouse_y)
    except Exception:
        pass
    _sos_active_draw_last_update_time = time.time()
    _sos_active_view_last_update_time = _sos_active_draw_last_update_time
    _sos_active_view_update_source = str(source or 'unknown')

    if changed:
        tagged = set()
        if old_window_ptr and old_region_ptr:
            old_key = (old_window_ptr, old_area_ptr, old_region_ptr)
            tagged.add(old_key)
            _sos_tag_view3d_region_by_token(ctx, *old_key)
        new_key = (win_ptr, area_ptr, reg_ptr)
        if new_key not in tagged:
            _sos_tag_view3d_region_by_token(ctx, *new_key)
        # Proportional snapshots are built only for the active view in this mode.
        # Tagging the new region cannot fill a snapshot skipped by an earlier build.
        prefs = get_effective_settings(ctx)
        if getattr(prefs, 'active_view_draw_only', False):
            from . import properties
            if properties._prop_overlay_requested(ctx) and properties._prop_view3d_pref_enabled(ctx):
                properties.request_prop_view3d_snapshot_rebuild(
                    'prop_active_view_changed', context=ctx, immediate=True
                )
    return changed


def get_active_view_draw_pointers():
    return _sos_active_draw_window_ptr, _sos_active_draw_region_ptr


def get_active_view_draw_token():
    return (
        _sos_active_draw_window_ptr,
        _sos_active_draw_area_ptr,
        _sos_active_draw_region_ptr,
        _sos_active_draw_rv3d_ptr,
    )


def _sos_active_draw_token_visible(context=None) -> bool:
    """Return True only while the full Window/Area/Region/RegionView3D token is live."""
    try:
        win_ptr = int(_sos_active_draw_window_ptr or 0)
        area_ptr = int(_sos_active_draw_area_ptr or 0)
        reg_ptr = int(_sos_active_draw_region_ptr or 0)
        rv3d_ptr = int(_sos_active_draw_rv3d_ptr or 0)
    except Exception:
        win_ptr = area_ptr = reg_ptr = rv3d_ptr = 0
    if not win_ptr or not area_ptr or not reg_ptr or not rv3d_ptr:
        return False
    try:
        ctx = context or bpy.context
        wm = getattr(ctx, 'window_manager', None) or bpy.context.window_manager
        for win in getattr(wm, 'windows', ()) or ():
            if _sos_pointer(win) != win_ptr:
                continue
            screen = getattr(win, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                if _sos_pointer(area) != area_ptr or getattr(area, 'type', None) != 'VIEW_3D':
                    continue
                for region in getattr(area, 'regions', ()) or ():
                    if getattr(region, 'type', None) != 'WINDOW' or _sos_pointer(region) != reg_ptr:
                        continue
                    try:
                        if int(getattr(region, 'width', 0) or 0) <= 0 or int(getattr(region, 'height', 0) or 0) <= 0:
                            return False
                    except Exception:
                        pass
                    target_rv3d = _sos_region_3d_from_area(ctx, area, region, window=win)
                    return bool(_sos_pointer(target_rv3d) == rv3d_ptr)
    except Exception:
        pass
    return False

def _sos_clear_active_view_draw_context(context=None, *, redraw: bool = False) -> bool:
    """Clear only the draw-owner token used by Draw Active View Only."""
    global _sos_active_draw_window_ptr, _sos_active_draw_area_ptr
    global _sos_active_draw_region_ptr, _sos_active_draw_rv3d_ptr
    global _sos_active_draw_mouse_x, _sos_active_draw_mouse_y, _sos_active_draw_last_update_time
    try:
        changed = bool(_sos_active_draw_window_ptr or _sos_active_draw_region_ptr or _sos_active_draw_rv3d_ptr)
    except Exception:
        changed = False
    _sos_active_draw_window_ptr = 0
    _sos_active_draw_area_ptr = 0
    _sos_active_draw_region_ptr = 0
    _sos_active_draw_rv3d_ptr = 0
    _sos_active_draw_mouse_x = -1
    _sos_active_draw_mouse_y = -1
    _sos_active_draw_last_update_time = 0.0
    if redraw and changed:
        try:
            tag_view3d_redraw(context)
        except Exception:
            pass
    return changed


def _sos_context_view3d_window_region(context=None):
    """Return the VIEW_3D area/WINDOW region for the current UI context.

    Preference updates often run from the N-panel UI region, not the 3D WINDOW
    region.  The active-view draw option still needs to seed the operated 3D view
    from that same area, otherwise every viewport can be rejected until the mouse
    is moved inside the WINDOW region.
    """
    try:
        ctx = context or bpy.context
        area = getattr(ctx, 'area', None)
        if getattr(area, 'type', None) == 'VIEW_3D':
            region = getattr(ctx, 'region', None)
            if getattr(region, 'type', None) == 'WINDOW':
                return area, region
            for candidate in getattr(area, 'regions', ()) or ():
                if getattr(candidate, 'type', None) == 'WINDOW':
                    return area, candidate
    except Exception:
        pass
    return None, None


def _sos_first_view3d_window_region_in_window(window):
    """Return a fallback VIEW_3D area/WINDOW region for a Blender window."""
    try:
        screen = getattr(window, 'screen', None)
        for area in getattr(screen, 'areas', ()) or ():
            if getattr(area, 'type', None) != 'VIEW_3D':
                continue
            for region in getattr(area, 'regions', ()) or ():
                if getattr(region, 'type', None) == 'WINDOW':
                    return area, region
    except Exception:
        pass
    return None, None


def prime_active_view_draw_context(context=None, *, force: bool = False, source: str = 'ui') -> bool:
    """Seed the Draw Active View Only owner from the currently operated UI context.

    This is intentionally separate from draw callbacks.  It is called from UI
    changes, runtime startup, and timer/event paths so the active viewport can be
    established even when the cursor is over the N-panel or when there has not yet
    been a fresh MOUSEMOVE inside the 3D WINDOW region.
    """
    try:
        ctx = context or bpy.context
    except Exception:
        ctx = bpy.context
    try:
        prefs = get_effective_settings(ctx)
        if not force and not bool(getattr(prefs, 'active_view_draw_only', False)):
            return False
    except Exception:
        if not force:
            return False
    try:
        win = getattr(ctx, 'window', None)
        if win is None:
            return False
    except Exception:
        return False

    area, region = _sos_context_view3d_window_region(ctx)
    if area is None or region is None:
        # If the preference is changed from Preferences or another editor, prefer
        # the View3D under the current window mouse, then fall back to the first
        # visible View3D in that same window.  We never scan other windows here, so
        # a secondary window cannot become active merely by redrawing.
        try:
            mx = getattr(win, 'event_mouse_x', None)
            my = getattr(win, 'event_mouse_y', None)
            if mx is not None and my is not None:
                area, region = _sos_find_view3d_window_region_at_window(win, int(mx), int(my))
        except Exception:
            area = region = None
        if area is None or region is None:
            area, region = _sos_first_view3d_window_region_in_window(win)
    if area is None or region is None:
        return False
    try:
        mx = getattr(win, 'event_mouse_x', None)
        my = getattr(win, 'event_mouse_y', None)
        return bool(_sos_set_active_view_context(ctx, area=area, region=region, rv3d=_sos_region_3d_from_area(ctx, area, region, window=win), source=source, mouse_x=mx, mouse_y=my, window=win)) or True
    except Exception:
        try:
            return bool(_sos_set_active_view_context(ctx, area=area, region=region, rv3d=_sos_region_3d_from_area(ctx, area, region, window=win), source=source, window=win)) or True
        except Exception:
            return False


def _sos_view3d_window_region_count(context=None) -> int:
    """Return the number of visible View3D WINDOW regions across all windows."""
    count = 0
    try:
        wm = getattr(context or bpy.context, 'window_manager', None) or bpy.context.window_manager
        windows = tuple(getattr(wm, 'windows', ()) or ())
    except Exception:
        windows = ()
    for win in windows:
        try:
            screen = getattr(win, 'screen', None)
            if screen is None:
                continue
            for area in getattr(screen, 'areas', ()) or ():
                if getattr(area, 'type', None) != 'VIEW_3D':
                    continue
                for region in getattr(area, 'regions', ()) or ():
                    if getattr(region, 'type', None) == 'WINDOW':
                        try:
                            if int(getattr(region, 'width', 0) or 0) > 0 and int(getattr(region, 'height', 0) or 0) > 0:
                                count += 1
                        except Exception:
                            count += 1
        except Exception:
            continue
    return count


def _sos_active_view_has_multiple_candidates(context=None) -> bool:
    try:
        return _sos_view3d_window_region_count(context) > 1
    except Exception:
        return False


def _sos_active_view_draw_signal(context=None) -> None:
    """Promote a View3D to active only when that view is actually navigated.

    Draw callbacks are not reliable cursor-event sources in multi-window setups,
    but RegionView3D matrix changes are a real operation signal.  This keeps the
    active-view-only draw switch responsive when the user orbits/pans/zooms a
    view, without allowing an inactive window's stale mouse coordinates to steal
    the active token.
    """
    global _sos_active_view_sig_by_region
    try:
        ctx = context or bpy.context
        area = getattr(ctx, 'area', None)
        region = getattr(ctx, 'region', None)
        if getattr(area, 'type', None) != 'VIEW_3D' or getattr(region, 'type', None) != 'WINDOW':
            return
        rv3d = getattr(ctx, 'region_data', None)
        if rv3d is None:
            return
        reg_ptr = _sos_pointer(region)
        if not reg_ptr:
            return
        values = []
        try:
            for row in getattr(rv3d, 'view_matrix', ()):  # navigation-sensitive
                for value in row:
                    values.append(round(float(value), 6))
        except Exception:
            values.append(0.0)
        try:
            wm = getattr(rv3d, 'window_matrix', None)
            if wm is not None:
                # Skip row 2 clip-depth values; View Clip Start/End should not be
                # treated as a different active viewport operation.
                for row_index, row in enumerate(wm):
                    if row_index == 2:
                        continue
                    for value in row:
                        values.append(round(float(value), 6))
        except Exception:
            values.append(0.0)
        try:
            values.append(int(getattr(region, 'width', 0) or 0))
            values.append(int(getattr(region, 'height', 0) or 0))
        except Exception:
            pass
        sig = tuple(values)
        prev = _sos_active_view_sig_by_region.get(reg_ptr)
        _sos_active_view_sig_by_region[reg_ptr] = sig
        try:
            overflow = len(_sos_active_view_sig_by_region) - _SOS_ACTIVE_VIEW_SIG_CACHE_LIMIT
            if overflow > 0:
                for old_key in tuple(_sos_active_view_sig_by_region.keys()):
                    if overflow <= 0:
                        break
                    if old_key == reg_ptr:
                        continue
                    _sos_active_view_sig_by_region.pop(old_key, None)
                    overflow -= 1
        except Exception:
            pass
        if prev is not None and prev != sig:
            _sos_set_active_view_context(ctx, area=area, region=region, source='view_change')
    except Exception:
        return

def _sos_region_contains_window_xy(region, mouse_x, mouse_y) -> bool:
    if region is None:
        return False
    try:
        x = int(getattr(region, "x", 0) or 0)
        y = int(getattr(region, "y", 0) or 0)
        w = int(getattr(region, "width", 0) or 0)
        h = int(getattr(region, "height", 0) or 0)
        mx = int(mouse_x)
        my = int(mouse_y)
    except Exception:
        return False
    return w > 0 and h > 0 and x <= mx < x + w and y <= my < y + h


def _sos_view3d_ui_region_contains_window_xy(area, mouse_x, mouse_y) -> bool:
    """Return True when a visible non-WINDOW View3D region owns the click."""
    try:
        regions = tuple(getattr(area, 'regions', ()) or ())
    except Exception:
        return False
    for region in regions:
        try:
            if getattr(region, 'type', None) == 'WINDOW':
                continue
            if _sos_region_contains_window_xy(region, mouse_x, mouse_y):
                return True
        except Exception:
            continue
    return False



def _sos_find_view3d_window_region_at_window(window, mouse_x, mouse_y):
    """Return a VIEW_3D WINDOW region at coordinates local to the given window."""
    screen = getattr(window, "screen", None)
    if screen is None:
        return None, None
    try:
        areas = tuple(getattr(screen, "areas", ()) or ())
    except Exception:
        areas = ()
    for area in areas:
        try:
            if getattr(area, "type", None) != 'VIEW_3D':
                continue
            if _sos_view3d_ui_region_contains_window_xy(area, mouse_x, mouse_y):
                continue
            for region in getattr(area, "regions", ()) or ():
                if getattr(region, "type", None) == 'WINDOW' and _sos_region_contains_window_xy(region, mouse_x, mouse_y):
                    return area, region
        except Exception:
            continue
    return None, None


def _sos_find_view3d_window_region_at(context, mouse_x, mouse_y):
    """Return the VIEW_3D WINDOW region currently under the window mouse.

    The hover overlay must be tied to the actual viewport region under the
    cursor.  Reusing the previous region/object when the cursor moves to the
    sidebar, another editor, or outside the viewport leaves stale object-hover
    colors on screen.
    """
    return _sos_find_view3d_window_region_at_window(getattr(context, "window", None), mouse_x, mouse_y)


def _sos_fast_view3d_region_from_context(context, mouse_x, mouse_y):
    """Cheap VIEW_3D region lookup for high-frequency mouse tracking.

    The previous runtime used a Window-level MOUSEMOVE keymap and scanned every
    area on each mouse event.  During viewport orbit/pan/zoom this can run many
    times per frame and delay Blender's native navigation.  When Blender already
    invokes the keymap from a VIEW_3D context, this fast path validates the
    active area/region directly and avoids the screen-wide scan.
    """
    try:
        area = getattr(context, 'area', None)
        if getattr(area, 'type', None) != 'VIEW_3D':
            return None, None
        if _sos_view3d_ui_region_contains_window_xy(area, mouse_x, mouse_y):
            return None, None
        region = getattr(context, 'region', None)
        if getattr(region, 'type', None) == 'WINDOW' and _sos_region_contains_window_xy(region, mouse_x, mouse_y):
            return area, region
        for candidate in getattr(area, 'regions', ()) or ():
            if getattr(candidate, 'type', None) == 'WINDOW' and _sos_region_contains_window_xy(candidate, mouse_x, mouse_y):
                return area, candidate
    except Exception:
        pass
    return None, None


def _sos_region_3d_from_area(context, area, region, *, window=None):
    """Return the exact RegionView3D for a VIEW_3D Area/WINDOW Region pair."""
    try:
        if region is not None and _sos_pointer(getattr(context, 'region', None)) == _sos_pointer(region):
            rv3d = getattr(context, 'region_data', None)
            if rv3d is not None:
                return rv3d
    except Exception:
        pass
    try:
        window = window or getattr(context, 'window', None)
        screen = getattr(window, 'screen', None)
        if window is not None and area is not None and region is not None:
            with bpy.context.temp_override(window=window, screen=screen, area=area, region=region):
                rv3d = getattr(bpy.context, 'region_data', None)
                if rv3d is not None:
                    return rv3d
    except Exception:
        pass
    try:
        for space in getattr(area, 'spaces', ()) or ():
            if getattr(space, 'type', None) != 'VIEW_3D':
                continue
            if tuple(getattr(space, 'region_quadviews', ()) or ()):
                return None
            rv3d = getattr(space, 'region_3d', None)
            if rv3d is not None:
                return rv3d
    except Exception:
        pass
    return None


def _sos_view3d_space_for_region(context, region=None, rv3d=None):
    """Return the SpaceView3D that owns the current hover region.

    Object/Sculpt hover uses scene ray-casting.  Scene ray-cast can hit
    objects that are outside the active viewport's Local View, so object-hover
    targets must be checked against Object.visible_get(..., viewport=space)
    before they are accepted for drawing or click selection.
    """
    region_ptr = _sos_pointer(region)
    rv3d_ptr = _sos_pointer(rv3d)
    try:
        space = getattr(context, 'space_data', None)
        if getattr(space, 'type', None) == 'VIEW_3D':
            if rv3d_ptr == 0 or _sos_pointer(getattr(space, 'region_3d', None)) == rv3d_ptr:
                return space
    except Exception:
        pass
    try:
        area = getattr(context, 'area', None)
        if getattr(area, 'type', None) == 'VIEW_3D':
            if region_ptr == 0 or any(_sos_pointer(r) == region_ptr for r in (getattr(area, 'regions', ()) or ())):
                for space in getattr(area, 'spaces', ()) or ():
                    if getattr(space, 'type', None) == 'VIEW_3D':
                        if rv3d_ptr == 0 or _sos_pointer(getattr(space, 'region_3d', None)) == rv3d_ptr:
                            return space
    except Exception:
        pass
    try:
        screen = getattr(getattr(context, 'window', None), 'screen', None)
        for area in getattr(screen, 'areas', ()) or ():
            if getattr(area, 'type', None) != 'VIEW_3D':
                continue
            if region_ptr and not any(_sos_pointer(r) == region_ptr for r in (getattr(area, 'regions', ()) or ())):
                continue
            fallback_space = None
            for space in getattr(area, 'spaces', ()) or ():
                if getattr(space, 'type', None) != 'VIEW_3D':
                    continue
                if fallback_space is None:
                    fallback_space = space
                if rv3d_ptr == 0 or _sos_pointer(getattr(space, 'region_3d', None)) == rv3d_ptr:
                    return space
            if fallback_space is not None:
                return fallback_space
    except Exception:
        pass
    return None


def _sos_object_visible_in_view3d(context, obj, region=None, rv3d=None) -> bool:
    """Return True only when obj is visible in the active 3D View.

    This includes viewport Local View filtering created by view3d.localview.
    """
    if obj is None:
        return False
    space = _sos_view3d_space_for_region(context, region, rv3d)
    view_layer = getattr(context, 'view_layer', None)
    if space is not None:
        try:
            return bool(obj.visible_get(view_layer=view_layer, viewport=space))
        except TypeError:
            try:
                return bool(obj.visible_get(view_layer, space))
            except TypeError:
                try:
                    return bool(obj.visible_get(viewport=space))
                except TypeError:
                    pass
            except Exception:
                pass
        except Exception:
            pass
    try:
        if view_layer is not None:
            return bool(obj.visible_get(view_layer=view_layer))
    except TypeError:
        try:
            return bool(obj.visible_get(view_layer))
        except Exception:
            pass
    except Exception:
        pass
    try:
        visible_objects = getattr(context, 'visible_objects', None)
        if visible_objects is not None:
            return any(candidate == obj for candidate in visible_objects)
    except Exception:
        pass
    try:
        return not bool(obj.hide_get())
    except Exception:
        return True


def _sos_note_drawn_object_hover_target(context, obj_name: str, region, rv3d, mx: int, my: int, overlay_mode: str) -> None:
    """Remember the exact object that the Object/Sculpt hover overlay actually drew.

    Click selection must use this drawn hover target first.  Blender's raw click
    hit test can legally return a different object when selected objects are
    skipped by the hover overlay, when local-view filtering is involved, or when
    modifiers/viewport depth create a different visual target.
    """
    global _sos_drawn_hover_obj, _sos_drawn_hover_mx, _sos_drawn_hover_my, _sos_drawn_hover_region_ptr
    global _sos_drawn_hover_view_sig, _sos_drawn_hover_mode, _sos_drawn_hover_time, _sos_drawn_hover_by_region
    area = getattr(context, 'area', None)
    key = (
        _sos_pointer(getattr(context, 'window', None)),
        _sos_pointer(area),
        _sos_pointer(region),
        _sos_pointer(getattr(context, 'scene', None)),
        str(overlay_mode or ''),
    )
    if not obj_name:
        _sos_drawn_hover_by_region.pop(key, None)
        _sos_drawn_hover_obj = ""
        _sos_drawn_hover_mx = -1
        _sos_drawn_hover_my = -1
        _sos_drawn_hover_region_ptr = 0
        _sos_drawn_hover_view_sig = None
        _sos_drawn_hover_mode = ""
        _sos_drawn_hover_time = 0.0
        return
    _sos_drawn_hover_obj = str(obj_name)
    try:
        _sos_drawn_hover_mx = int(mx)
        _sos_drawn_hover_my = int(my)
    except Exception:
        _sos_drawn_hover_mx = -1
        _sos_drawn_hover_my = -1
    _sos_drawn_hover_region_ptr = _sos_pointer(region)
    _sos_drawn_hover_view_sig = _sos_hover_view_signature(region, rv3d, context)
    _sos_drawn_hover_mode = str(overlay_mode or "")
    _sos_drawn_hover_time = time.time()
    try:
        scene = getattr(context, 'scene', None)
        drawn_obj = scene.objects.get(_sos_drawn_hover_obj) if scene is not None else None
        object_pointer = _sos_pointer(drawn_obj)
    except Exception:
        object_pointer = 0
    _sos_drawn_hover_by_region[key] = {
        'key': key,
        'object_name': _sos_drawn_hover_obj,
        'object_pointer': int(object_pointer or 0),
        'mouse': (_sos_drawn_hover_mx, _sos_drawn_hover_my),
        'view_signature': _sos_drawn_hover_view_sig,
        'mode': _sos_drawn_hover_mode,
        'time': _sos_drawn_hover_time,
        'snapshot_generation': int(_sos_overlay_snapshot_generation or 0),
    }
    if len(_sos_drawn_hover_by_region) > _SOS_DRAWN_HOVER_MAX_RECORDS:
        oldest = sorted(
            _sos_drawn_hover_by_region.items(),
            key=lambda item: float(item[1].get('time', 0.0)),
        )[:len(_sos_drawn_hover_by_region) - _SOS_DRAWN_HOVER_MAX_RECORDS]
        for old_key, _old_record in oldest:
            _sos_drawn_hover_by_region.pop(old_key, None)


def _sos_drawn_object_hover_selection_target(
    context, event, area, region, rv3d, mx: int, my: int, overlay_mode: str,
    *, mouse_tolerance: int = 0,
):
    """Return the exact object whose hover-color overlay was last drawn.

    The drawn hover target is the single authority for click selection.  Click
    handling never repicks. It accepts only the record drawn for this exact
    window/area/region, scene, mode, cursor, view signature, and published GPU
    snapshot generation.
    """
    key = (
        _sos_pointer(getattr(context, 'window', None)),
        _sos_pointer(area),
        _sos_pointer(region),
        _sos_pointer(getattr(context, 'scene', None)),
        str(overlay_mode or ''),
    )
    record = _sos_drawn_hover_by_region.get(key)
    if not isinstance(record, dict):
        return None
    try:
        record_x, record_y = tuple(record.get('mouse') or (-1000000, -1000000))
        tolerance = max(0, int(mouse_tolerance or 0))
        if abs(int(record_x) - int(mx)) > tolerance or abs(int(record_y) - int(my)) > tolerance:
            return None
    except Exception:
        return None
    if tuple(record.get('view_signature') or ()) != tuple(_sos_hover_view_signature(region, rv3d, context) or ()):
        return None
    snapshot = _sos_overlay_snapshots.get(key)
    if not isinstance(snapshot, dict):
        return None
    try:
        if int(snapshot.get('generation', -1)) != int(record.get('snapshot_generation', -2)):
            return None
    except Exception:
        return None
    try:
        scene = getattr(context, 'scene', None)
        obj = scene.objects.get(str(record.get('object_name') or '')) if scene is not None else None
        if obj is None or _sos_pointer(obj) != int(record.get('object_pointer', 0) or 0):
            return None
        return obj
    except Exception:
        return None


def _sos_selection_snapshot(context):
    try:
        view_layer = getattr(context, 'view_layer', None)
        objects = tuple(getattr(view_layer, 'objects', ()) or ()) if view_layer is not None else ()
    except Exception:
        objects = ()
    selected = []
    for obj in objects:
        try:
            if obj.select_get():
                selected.append(obj.name)
        except Exception:
            continue
    try:
        active = getattr(getattr(context, 'view_layer', None), 'objects', None).active
        active_name = active.name if active is not None else ""
    except Exception:
        active_name = ""
    return tuple(selected), active_name


def _sos_restore_selection_snapshot(context, snapshot, *, redraw=True) -> bool:
    try:
        selected_names, active_name = snapshot
    except Exception:
        return False
    selected_set = set(selected_names or ())
    try:
        view_layer = getattr(context, 'view_layer', None)
        objects = tuple(getattr(view_layer, 'objects', ()) or ()) if view_layer is not None else ()
    except Exception:
        objects = ()
    changed = False
    name_map = {}
    for obj in objects:
        try:
            name_map[obj.name] = obj
            desired = obj.name in selected_set
            if bool(obj.select_get()) != desired:
                obj.select_set(desired)
                changed = True
        except Exception:
            continue
    try:
        active_obj = name_map.get(active_name) if active_name else None
        if getattr(context.view_layer.objects, 'active', None) != active_obj:
            context.view_layer.objects.active = active_obj
            changed = True
    except Exception:
        pass
    if changed and redraw:
        tag_view3d_redraw(context)
    return True


def _sos_hover_click_stable_view_signature(region, rv3d, context=None):
    """View identity for one physical click, excluding selection redraw serials.

    ``_sos_hover_view_signature`` includes the global hover-scene revision so
    geometry/selection changes rebuild hover snapshots.  Native Object selection
    itself increments that revision between RELEASE and a backend-generated CLICK.
    Treating it as camera movement made the CLICK receipt unreachable and allowed
    Blender's front-object hit test to overwrite the already committed rear hover
    target.  Region, Space/Local View and the clip-stable view matrices remain
    exact, so an actual orbit/pan/zoom or editor change is still rejected.
    """
    signature = tuple(_sos_hover_view_signature(region, rv3d, context) or ())
    if len(signature) >= 6:
        return (signature[0], signature[1], signature[3], signature[4], signature[5])
    return signature


def _sos_record_hover_click_outcome(context, event, obj) -> None:
    global _sos_last_hover_click_outcome
    try:
        area, region, rv3d = _sos_view3d_region_from_event(context, event)
        mode = _sos_object_hover_overlay_mode(context)
        key = (
            _sos_pointer(getattr(context, 'window', None)), _sos_pointer(area), _sos_pointer(region),
            _sos_pointer(getattr(context, 'scene', None)), mode,
        )
        view_signature = tuple(_sos_hover_click_stable_view_signature(region, rv3d, context) or ())
    except Exception:
        key = ()
        view_signature = ()
    try:
        event_value = str(getattr(event, 'value', '') or '')
        mouse_x = int(getattr(event, 'mouse_x', -1000000))
        mouse_y = int(getattr(event, 'mouse_y', -1000000))
    except Exception:
        event_value = ''
        mouse_x = mouse_y = -1000000
    _sos_last_hover_click_outcome = {
        'time': time.time(),
        'object_name': getattr(obj, 'name', ''),
        'mouse_x': mouse_x,
        'mouse_y': mouse_y,
        'shift': bool(getattr(event, 'shift', False)),
        'ctrl': bool(getattr(event, 'ctrl', False)),
        'snapshot': _sos_selection_snapshot(context),
        'value': event_value,
        'key': key,
        'view_signature': view_signature,
    }


def _sos_clear_hover_click_outcome() -> None:
    global _sos_last_hover_click_outcome
    _sos_last_hover_click_outcome = {}


def _sos_restore_recent_hover_click_outcome(context, event) -> bool:
    """Consume a later CLICK event from the same physical click.

    Some Blender configurations dispatch viewport selection on CLICK rather than
    PRESS.  The PRESS handler already selected the hover-color object; this
    restores that exact outcome and consumes the CLICK event so Blender's default
    hit test cannot overwrite it with a background object.
    """
    global _sos_last_hover_click_outcome
    info = _sos_last_hover_click_outcome if isinstance(_sos_last_hover_click_outcome, dict) else {}
    if not info:
        return False
    try:
        if str(getattr(event, 'value', '') or '') != 'CLICK':
            return False
    except Exception:
        return False
    try:
        if time.time() - float(info.get('time', 0.0)) > _SOS_HOVER_PROVIDER_RECEIPT_TTL_SECONDS:
            _sos_last_hover_click_outcome = {}
            return False
    except Exception:
        _sos_last_hover_click_outcome = {}
        return False
    try:
        # Windows and some tablet/high-DPI input paths can report the synthetic
        # CLICK one or more physical pixels away from PRESS/RELEASE.  Exact
        # equality let Blender's later native click hit-test overwrite the rear
        # hover-colored object with the selected foreground object.  Accept only
        # movement inside Blender's own click/drag threshold, preserving the same
        # physical gesture while still rejecting a real drag or unrelated click.
        tolerance = max(1, int(_sos_hover_click_drag_threshold(context) or 0))
        if abs(int(getattr(event, 'mouse_x', -999999)) - int(info.get('mouse_x', -1000000))) > tolerance:
            return False
        if abs(int(getattr(event, 'mouse_y', -999999)) - int(info.get('mouse_y', -1000000))) > tolerance:
            return False
    except Exception:
        return False
    if bool(getattr(event, 'shift', False)) != bool(info.get('shift', False)):
        return False
    if bool(getattr(event, 'ctrl', False)) != bool(info.get('ctrl', False)):
        return False
    try:
        area, region, rv3d = _sos_view3d_region_from_event(context, event)
        key = (
            _sos_pointer(getattr(context, 'window', None)), _sos_pointer(area), _sos_pointer(region),
            _sos_pointer(getattr(context, 'scene', None)), _sos_object_hover_overlay_mode(context),
        )
        if key != tuple(info.get('key') or ()):
            return False
        if tuple(_sos_hover_click_stable_view_signature(region, rv3d, context) or ()) != tuple(info.get('view_signature') or ()):
            return False
        scene = getattr(context, 'scene', None)
        if scene is None or scene.objects.get(str(info.get('object_name') or '')) is None:
            return False
    except Exception:
        return False
    snapshot = info.get('snapshot')
    if snapshot is None:
        return False
    # Consume at most one synthetic CLICK from this physical input.  Clear the
    # receipt before restoring so an exception cannot leave a reusable outcome.
    _sos_last_hover_click_outcome = {}
    if _sos_hover_click_selection_matches(context, snapshot):
        return True
    return _sos_restore_selection_snapshot(context, snapshot)


def _sos_view3d_region_from_event(context, event):
    try:
        mouse_x = int(getattr(event, 'mouse_x', -1))
        mouse_y = int(getattr(event, 'mouse_y', -1))
    except Exception:
        mouse_x = mouse_y = -1
    area, region = _sos_fast_view3d_region_from_context(context, mouse_x, mouse_y)
    if region is None:
        area, region = _sos_find_view3d_window_region_at(context, mouse_x, mouse_y)
    if region is None:
        return None, None, None
    return area, region, _sos_region_3d_from_area(context, area, region)


def _sos_runtime_wants_mouse_tracking(wm, context=None) -> bool:
    if wm is None:
        return False
    try:
        if not _sos_workspace_filter_allows_addon(context or bpy.context):
            return False
    except Exception:
        return False
    try:
        if bool(getattr(wm, "sos_object_hover_overlay_enabled", False)):
            return True
        prefs = None
        try:
            prefs = get_effective_settings(context or bpy.context)
        except Exception:
            prefs = None
        if bool(getattr(wm, "sos_enabled", False)):
            try:
                if prefs is not None and (bool(getattr(prefs, 'active_view_only', False)) or bool(getattr(prefs, 'active_view_draw_only', False))):
                    return True
            except Exception:
                pass
            mode = str(getattr(context or bpy.context, 'mode', '') or '')
            if mode == 'EDIT_MESH':
                # Do not start a resident mouse/modal tracker for every edit session.
                # That made Blender feel heavy immediately after enabling Smart
                # Overlay.  Cursor probing is needed only for explicit hover features
                # or active-view filtering; live transform following uses the modal
                # transform signature and live BMesh coordinates instead.
                if prefs is None:
                    return False
                return bool(
                    getattr(prefs, 'show_hov_verts', False)
                    or getattr(prefs, 'show_hov_edges', False)
                    or getattr(prefs, 'show_hov_faces', False)
                )
            return False
        if bool(getattr(wm, "sos_proportional_overlay_enabled", False)):
            try:
                return bool(prefs is not None and (getattr(prefs, 'active_view_only', False) or getattr(prefs, 'active_view_draw_only', False)))
            except Exception:
                return False
        return False
    except Exception:
        return False


def _sos_tag_single_view3d(area=None, region=None, context=None) -> bool:
    """Tag only the VIEW_3D region affected by hover tracking."""
    tagged = False
    try:
        if region is not None and hasattr(region, 'tag_redraw'):
            region.tag_redraw()
            tagged = True
    except Exception:
        tagged = False
    if not tagged:
        try:
            if area is not None and getattr(area, 'type', None) == 'VIEW_3D':
                area.tag_redraw()
                tagged = True
        except Exception:
            tagged = False
    if not tagged:
        try:
            area_ctx = getattr(context, 'area', None) if context is not None else None
            if getattr(area_ctx, 'type', None) == 'VIEW_3D':
                area_ctx.tag_redraw()
                tagged = True
        except Exception:
            pass
    return bool(tagged)


def _sos_flush_mouse_redraw():
    global _sos_mouse_redraw_pending, _sos_last_mouse_redraw_time, _sos_pending_redraw_area, _sos_pending_redraw_region
    _sos_mouse_redraw_pending = False
    area = _sos_pending_redraw_area
    region = _sos_pending_redraw_region
    _sos_pending_redraw_area = None
    _sos_pending_redraw_region = None
    _sos_last_mouse_redraw_time = time.perf_counter()
    if not _sos_tag_single_view3d(area=area, region=region, context=getattr(bpy, 'context', None)):
        try:
            tag_view3d_redraw(getattr(bpy, 'context', None))
        except Exception:
            pass
    return None


def _sos_request_mouse_redraw(context=None, area=None, region=None) -> None:
    """Coalesce high-frequency mouse redraws to one request per frame.

    Mouse tracking must update the hover overlay immediately, but issuing a full
    redraw for every raw MOUSEMOVE event is the main source of navigation lag.
    This keeps the latest cursor state and collapses redundant redraw requests.
    """
    global _sos_last_mouse_redraw_time, _sos_mouse_redraw_pending, _sos_pending_redraw_area, _sos_pending_redraw_region
    try:
        _sos_note_runtime_redraw_request()
    except Exception:
        pass
    now = time.perf_counter()
    _sos_pending_redraw_area = area or getattr(context, 'area', None)
    _sos_pending_redraw_region = region or getattr(context, 'region', None)
    elapsed = now - float(_sos_last_mouse_redraw_time or 0.0)
    if elapsed >= _SOS_MOUSE_REDRAW_MIN_INTERVAL:
        _sos_last_mouse_redraw_time = now
        _sos_tag_single_view3d(area=_sos_pending_redraw_area, region=_sos_pending_redraw_region, context=context)
        _sos_pending_redraw_area = None
        _sos_pending_redraw_region = None
        return
    if _sos_mouse_redraw_pending:
        return
    _sos_mouse_redraw_pending = True
    try:
        bpy.app.timers.register(_sos_flush_mouse_redraw, first_interval=max(0.001, _SOS_MOUSE_REDRAW_MIN_INTERVAL - elapsed))
    except Exception:
        _sos_mouse_redraw_pending = False
        _sos_tag_single_view3d(area=_sos_pending_redraw_area, region=_sos_pending_redraw_region, context=context)
        _sos_pending_redraw_area = None
        _sos_pending_redraw_region = None


def _sos_clear_tracked_mouse(context=None, *, redraw=True) -> bool:
    global _sos_mouse_window_ptr, _sos_active_region_ptr, _sos_mouse_window_x, _sos_mouse_window_y
    global _sos_active_view_last_update_time, _sos_active_view_update_source
    ctx = context or bpy.context
    wm = getattr(ctx, "window_manager", None)
    changed = False
    changed = changed or _sos_mouse_window_x != -1 or _sos_mouse_window_y != -1
    try:
        # Keep the legacy RNA values coherent without writing to them on every
        # mouse event.  These properties are retained for compatibility only.
        changed = changed or int(getattr(wm, "sos_mouse_x", -1)) != -1 or int(getattr(wm, "sos_mouse_y", -1)) != -1
        wm.sos_mouse_x = -1
        wm.sos_mouse_y = -1
    except Exception:
        pass
    changed = changed or bool(_sos_cached_hover_obj or _sos_global_hover_obj or _sos_mouse_window_ptr or _sos_active_region_ptr)
    _sos_mouse_window_ptr = 0
    _sos_active_region_ptr = 0
    _sos_mouse_window_x = -1
    _sos_mouse_window_y = -1
    _sos_active_view_last_update_time = 0.0
    _sos_active_view_update_source = ""
    reset_object_hover_cache()
    clear_object_hover_click_input_authority()
    if redraw and changed:
        tag_view3d_redraw(ctx)
    return changed



def _sos_handle_int(value) -> int:
    """Return an integer for ctypes handles without raising on c_void_p."""
    try:
        return int(value or 0)
    except Exception:
        try:
            return int(getattr(value, 'value', 0) or 0)
        except Exception:
            return 0


def _sos_windows_process_window_geometries(context=None):
    """Return top-level client rectangles for Blender windows in this process.

    Each entry is ``(hwnd, left, top, width, height)`` in screen coordinates.
    Enumeration is cached because geometry changes are rare compared with hover
    redraws.
    """
    if not sys.platform.startswith('win'):
        return ()
    global _sos_windows_geometry_cache_time, _sos_windows_geometry_cache
    now = time.monotonic()
    try:
        if _sos_windows_geometry_cache and (now - float(_sos_windows_geometry_cache_time or 0.0)) < _SOS_WINDOWS_GEOMETRY_CACHE_SECONDS:
            return tuple(_sos_windows_geometry_cache)
    except Exception:
        pass
    result = []
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        current_pid = int(kernel32.GetCurrentProcessId())
        callback_type = getattr(ctypes, 'WINFUNCTYPE', ctypes.CFUNCTYPE)(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        @callback_type
        def _enum(hwnd, _lparam):
            try:
                pid = wintypes.DWORD(0)
                user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                if int(pid.value) != current_pid or not bool(user32.IsWindowVisible(hwnd)):
                    return True
                rect = wintypes.RECT()
                if not user32.GetClientRect(hwnd, ctypes.byref(rect)):
                    return True
                width = int(rect.right - rect.left)
                height = int(rect.bottom - rect.top)
                if width <= 0 or height <= 0:
                    return True
                origin = wintypes.POINT(0, 0)
                if not user32.ClientToScreen(hwnd, ctypes.byref(origin)):
                    return True
                result.append((_sos_handle_int(hwnd), int(origin.x), int(origin.y), width, height))
            except Exception:
                pass
            return True

        user32.EnumWindows(_enum, 0)
    except Exception:
        result = []
    _sos_windows_geometry_cache = tuple(result)
    _sos_windows_geometry_cache_time = now
    return tuple(result)


def _sos_blender_windows(context=None):
    ctx = context or getattr(bpy, 'context', None)
    try:
        wm = getattr(ctx, 'window_manager', None) or getattr(bpy.context, 'window_manager', None)
        windows = tuple(getattr(wm, 'windows', ()) or ())
    except Exception:
        windows = ()
    if windows:
        return windows
    try:
        win = getattr(ctx, 'window', None)
        return (win,) if win is not None else ()
    except Exception:
        return ()


def _sos_match_blender_window_for_geometry(geometry, context=None):
    """Match a Win32 client rectangle to Blender's Window RNA object."""
    windows = _sos_blender_windows(context)
    if not windows:
        return None
    if len(windows) == 1:
        return windows[0]
    _hwnd, left, top, width, height = geometry
    best = None
    best_score = None
    for win in windows:
        try:
            ww = int(getattr(win, 'width', 0) or 0)
            wh = int(getattr(win, 'height', 0) or 0)
            wx = int(getattr(win, 'x', left) or left)
            wy = int(getattr(win, 'y', top) or top)
            # Client size is the strongest signal.  RNA position can include the
            # native title bar/border, so position has a smaller weight.
            score = abs(ww - width) + abs(wh - height) + 0.10 * (abs(wx - left) + abs(wy - top))
        except Exception:
            continue
        if best_score is None or score < best_score:
            best_score = score
            best = win
    return best


def _sos_windows_mouse_sample(context=None):
    """Return ``(Blender Window, x, y)`` for the actual Windows cursor."""
    if not sys.platform.startswith('win'):
        return None
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        pt = wintypes.POINT()
        if not user32.GetCursorPos(ctypes.byref(pt)):
            return None
        px, py = int(pt.x), int(pt.y)
        candidates = []
        for geom in _sos_windows_process_window_geometries(context):
            _hwnd, left, top, width, height = geom
            if left <= px < left + width and top <= py < top + height:
                candidates.append(geom)
        if not candidates:
            return None
        # Prefer the smallest containing client rectangle if native windows overlap.
        geom = min(candidates, key=lambda item: int(item[3]) * int(item[4]))
        win = _sos_match_blender_window_for_geometry(geom, context)
        if win is None:
            return None
        _hwnd, left, top, width, height = geom
        x = px - left
        y = height - 1 - (py - top)
        if not (0 <= x < width and 0 <= y < height):
            return None
        return win, int(x), int(y)
    except Exception:
        return None


def _sos_windows_client_mouse_coords(context=None):
    """Compatibility wrapper returning coordinates for the context window."""
    sample = _sos_windows_mouse_sample(context)
    if sample is None:
        return None
    win, x, y = sample
    try:
        ctx_win = getattr(context or bpy.context, 'window', None)
        if ctx_win is not None and _sos_pointer(ctx_win) != _sos_pointer(win):
            return None
    except Exception:
        pass
    return int(x), int(y)


def _sos_x11_client_mouse_coords():
    """Disabled: direct X11 polling is unsafe in some Blender/Xvfb sessions."""
    return None


def _sos_window_from_pointer(context, pointer):
    ptr = int(pointer or 0)
    if ptr <= 0:
        return None
    for win in _sos_blender_windows(context):
        if _sos_pointer(win) == ptr:
            return win
    return None


def _sos_passive_mouse_sample(context=None, *, force=False):
    """Return ``(window, x, y)`` without reading mesh data or changing selection."""
    ctx = context or bpy.context
    try:
        test = bpy.app.driver_namespace.get('SOS_VIEW3D_TEST_MOUSE', None)
        if test is not None:
            win = getattr(ctx, 'window', None)
            return win, int(test[0]), int(test[1])
    except Exception:
        pass

    global _sos_last_os_mouse_probe_time, _sos_last_os_mouse_probe_coords
    global _sos_last_os_mouse_probe_window_ptr
    now = time.monotonic()
    if not force:
        try:
            cached = _sos_last_os_mouse_probe_coords
            if cached is not None and (now - float(_sos_last_os_mouse_probe_time or 0.0)) < _SOS_OS_MOUSE_PROBE_MIN_INTERVAL:
                win = _sos_window_from_pointer(ctx, _sos_last_os_mouse_probe_window_ptr)
                if win is not None:
                    return win, int(cached[0]), int(cached[1])
        except Exception:
            pass

    sample = _sos_windows_mouse_sample(ctx) if _SOS_NATIVE_MOUSE_POLL_SUPPORTED else None
    if sample is None:
        # Future Blender versions may expose event coordinates directly on Window.
        try:
            win = getattr(ctx, 'window', None)
            mx = getattr(win, 'event_mouse_x', None)
            my = getattr(win, 'event_mouse_y', None)
            if win is not None and mx is not None and my is not None:
                sample = (win, int(mx), int(my))
        except Exception:
            sample = None
    if sample is None:
        # Non-Windows event bridge records these module-level coordinates.
        try:
            win = _sos_window_from_pointer(ctx, _sos_mouse_window_ptr)
            if win is not None and int(_sos_mouse_window_x) >= 0 and int(_sos_mouse_window_y) >= 0:
                sample = (win, int(_sos_mouse_window_x), int(_sos_mouse_window_y))
        except Exception:
            sample = None
    if sample is not None:
        win, x, y = sample
        _sos_last_os_mouse_probe_time = now
        _sos_last_os_mouse_probe_coords = (int(x), int(y))
        _sos_last_os_mouse_probe_window_ptr = _sos_pointer(win)
        return win, int(x), int(y)
    return None


def _sos_passive_window_mouse_coords(context=None):
    """Return mouse coordinates only when they belong to the context window."""
    ctx = context or bpy.context
    sample = _sos_passive_mouse_sample(ctx)
    if sample is None:
        return None
    win, x, y = sample
    try:
        ctx_win = getattr(ctx, 'window', None)
        if ctx_win is not None and _sos_pointer(ctx_win) != _sos_pointer(win):
            return None
    except Exception:
        pass
    return int(x), int(y)


def _sos_prime_tracked_mouse_from_passive_coords(context, region=None, *, source='draw') -> bool:
    """Refresh hover state from a native/passive mouse sample."""
    try:
        ctx = context or bpy.context
        wm = getattr(ctx, 'window_manager', None)
        if not _sos_runtime_wants_mouse_tracking(wm, ctx):
            return False
        sample = _sos_passive_mouse_sample(ctx)
        if sample is None:
            return False
        win, mx, my = sample
        ctx_win = getattr(ctx, 'window', None)
        if str(source or '') == 'draw' and ctx_win is not None and _sos_pointer(ctx_win) != _sos_pointer(win):
            return False
        area, hit_region = _sos_find_view3d_window_region_at_window(win, int(mx), int(my))
        if hit_region is None:
            try:
                prefs = get_effective_settings(ctx)
                if str(source or '') == 'draw' and bool(getattr(prefs, 'active_view_draw_only', False)) and _sos_active_region_ptr:
                    return False
            except Exception:
                pass
            return _sos_clear_tracked_mouse(ctx, redraw=True)
        if region is not None and _sos_pointer(hit_region) != _sos_pointer(region):
            return False
        return bool(_sos_update_tracked_mouse_from_window_coords(ctx, int(mx), int(my), source=source, window=win))
    except Exception:
        return False

def _sos_hover_snapshot_tracking_enabled(context=None, prefs=None) -> bool:
    """Return True only when View3D hover colors need pointer-move snapshots."""
    ctx = context or bpy.context
    try:
        wm = getattr(ctx, 'window_manager', None)
        if wm is not None and bool(getattr(wm, 'sos_object_hover_overlay_enabled', False)):
            return True
    except Exception:
        pass
    try:
        owner = prefs if prefs is not None else get_effective_settings(ctx)
        return bool(
            owner is not None
            and (
                getattr(owner, 'show_hov_verts', False)
                or getattr(owner, 'show_hov_edges', False)
                or getattr(owner, 'show_hov_faces', False)
            )
        )
    except Exception:
        return False


def _sos_clear_drawn_hover_record_after_pointer_departure(context, area, region, mouse_x: int, mouse_y: int) -> bool:
    """Drop stale drawn-hover authority after the pointer leaves its draw point.

    The visible hover target and click authority are valid for the drawn
    coordinate and one click-sized jitter. When the user moves to another
    object/background before the next draw publishes a replacement, the old
    region record must not continue to advertise or select the previous object.
    """
    global _sos_drawn_hover_obj, _sos_drawn_hover_mx, _sos_drawn_hover_my, _sos_drawn_hover_region_ptr
    global _sos_drawn_hover_view_sig, _sos_drawn_hover_mode, _sos_drawn_hover_time
    try:
        local_x = int(mouse_x) - int(getattr(region, 'x', 0) or 0)
        local_y = int(mouse_y) - int(getattr(region, 'y', 0) or 0)
    except Exception:
        return False
    try:
        threshold = max(1, int(_sos_hover_click_drag_threshold(context) or 0))
    except Exception:
        threshold = 1
    removed_any = False
    window_ptr = _sos_pointer(getattr(context, "window", None))
    area_ptr = _sos_pointer(area)
    region_ptr = _sos_pointer(region)
    scene_ptr = _sos_pointer(getattr(context, "scene", None))
    removed_current = False
    for key, record in tuple(_sos_drawn_hover_by_region.items()):
        try:
            if (
                int(key[0] or 0) != int(window_ptr or 0)
                or int(key[1] or 0) != int(area_ptr or 0)
                or int(key[2] or 0) != int(region_ptr or 0)
                or int(key[3] or 0) != int(scene_ptr or 0)
            ):
                continue
            record_x, record_y = tuple(record.get('mouse') or (-1000000, -1000000))
            if abs(int(local_x) - int(record_x)) <= threshold and abs(int(local_y) - int(record_y)) <= threshold:
                continue
            removed = _sos_drawn_hover_by_region.pop(key, None)
            if isinstance(removed, dict):
                removed_any = True
            if isinstance(removed, dict) and str(removed.get('object_name') or '') == str(_sos_drawn_hover_obj or ''):
                removed_current = True
        except Exception:
            continue
    if removed_current and not _sos_drawn_hover_by_region:
        _sos_drawn_hover_obj = ""
        _sos_drawn_hover_mx = -1
        _sos_drawn_hover_my = -1
        _sos_drawn_hover_region_ptr = 0
        _sos_drawn_hover_view_sig = None
        _sos_drawn_hover_mode = ""
        _sos_drawn_hover_time = 0.0
    return bool(removed_any)


def _sos_update_tracked_mouse_from_event(context, event, *, update_active_view: bool = False) -> bool:
    global _sos_mouse_window_ptr, _sos_active_region_ptr, _sos_mouse_window_x, _sos_mouse_window_y
    global _sos_active_view_last_update_time, _sos_active_view_update_source
    global _sos_cached_hover_obj, _sos_global_hover_obj, _sos_last_mx, _sos_last_my, _sos_last_hover_view_sig
    global _sos_pending_hover_draw_obj, _sos_pending_hover_draw_mx, _sos_pending_hover_draw_my
    global _sos_pending_hover_draw_region_ptr, _sos_pending_hover_draw_view_sig, _sos_pending_hover_draw_until
    wm = getattr(context, "window_manager", None)
    if not _sos_runtime_wants_mouse_tracking(wm, context):
        return _sos_clear_tracked_mouse(context, redraw=True)

    try:
        mouse_x = int(getattr(event, "mouse_x", -1))
        mouse_y = int(getattr(event, "mouse_y", -1))
    except Exception:
        mouse_x = mouse_y = -1

    area, region, rv3d = _sos_view3d_region_from_event(context, event)
    if region is None:
        return _sos_clear_tracked_mouse(context, redraw=True)

    window_ptr = _sos_pointer(getattr(context, "window", None))
    region_ptr = _sos_pointer(region)
    hover_changed = (
        _sos_mouse_window_x != mouse_x
        or _sos_mouse_window_y != mouse_y
        or _sos_mouse_window_ptr != window_ptr
        or _sos_active_region_ptr != region_ptr
    )
    hover_record_departed = False
    if hover_changed:
        hover_record_departed = bool(_sos_clear_drawn_hover_record_after_pointer_departure(context, area, region, mouse_x, mouse_y))
        if hover_record_departed:
            # The stale authority has been cleared because the physical pointer
            # moved to a new position.  Do not let the next snapshot reuse the
            # previous hover cache; feed the post-update mouse coordinates back
            # into the normal picker/rebuild path for this exact region.
            _sos_cached_hover_obj = ""
            _sos_last_mx = -1
            _sos_last_my = -1
            _sos_last_hover_view_sig = None
    _sos_mouse_window_x = mouse_x
    _sos_mouse_window_y = mouse_y
    _sos_mouse_window_ptr = window_ptr
    _sos_active_region_ptr = region_ptr

    active_changed = False
    if update_active_view:
        _sos_active_view_last_update_time = time.time()
        _sos_active_view_update_source = 'operation_event'
        try:
            active_changed = bool(_sos_set_active_view_context(
                context,
                area=area,
                region=region,
                rv3d=rv3d,
                source='operation_event',
                mouse_x=mouse_x,
                mouse_y=mouse_y,
            ))
        except Exception:
            active_changed = False

    if active_changed:
        # Per-region Mesh/Curve/HPO snapshots already exist for every live view.
        # Ownership transfer only redraws the old/new physical regions in the
        # setter; it must not trigger geometry or HPO reconstruction.
        pass

    hover_snapshot_changed = bool(hover_changed and _sos_hover_snapshot_tracking_enabled(context))
    if hover_snapshot_changed:
        if hover_record_departed:
            try:
                _sos_set_active_view_context(
                    context,
                    area=area,
                    region=region,
                    rv3d=rv3d,
                    source='hover_record_departed',
                    mouse_x=mouse_x,
                    mouse_y=mouse_y,
                )
            except Exception:
                pass
            try:
                prefs = get_effective_settings(context)
                overlay_mode = _sos_object_hover_overlay_mode(context)
                local_x = int(mouse_x) - int(getattr(region, 'x', 0) or 0)
                local_y = int(mouse_y) - int(getattr(region, 'y', 0) or 0)
                hover_obj_name = _sos_pick_object_hover_overlay_name(
                    context, prefs, overlay_mode, region, rv3d, local_x, local_y,
                ) if prefs is not None else ""
                _sos_cached_hover_obj = str(hover_obj_name or "")
                _sos_last_mx = int(local_x) if hover_obj_name else -1
                _sos_last_my = int(local_y) if hover_obj_name else -1
                _sos_last_hover_view_sig = _sos_hover_view_signature(region, rv3d, context) if hover_obj_name else None
                _sos_global_hover_obj = str(hover_obj_name or "")
                if hover_obj_name:
                    _sos_pending_hover_draw_obj = str(hover_obj_name or "")
                    _sos_pending_hover_draw_mx = int(local_x)
                    _sos_pending_hover_draw_my = int(local_y)
                    _sos_pending_hover_draw_region_ptr = _sos_pointer(region)
                    _sos_pending_hover_draw_view_sig = _sos_last_hover_view_sig
                    _sos_pending_hover_draw_until = time.time() + max(0.05, float(getattr(prefs, "hover_delay_sec", 0.25) or 0.25) + 0.10)
                else:
                    _sos_pending_hover_draw_obj = ""
                    _sos_pending_hover_draw_mx = -1
                    _sos_pending_hover_draw_my = -1
                    _sos_pending_hover_draw_region_ptr = 0
                    _sos_pending_hover_draw_view_sig = None
                    _sos_pending_hover_draw_until = 0.0
            except Exception:
                pass
        # Active ownership and hover are independent.  Same-pane motion updates
        # only the existing hover snapshot path and never rebuilds HPO geometry.
        request_overlay_snapshot_rebuild(
            'hover_record_departed' if hover_record_departed else 'hover_event',
            context=context,
            immediate=bool(hover_record_departed),
        )
        _sos_request_mouse_redraw(context, area=area, region=region)
    return bool(hover_changed or active_changed)


# Event classes for the Draw Active View Only owner.  Blender sends keyboard
# operators to the View3D region under the cursor, so a real key press there
# makes that region the view the user is working in.  The former keymap
# whitelist (translate/rotate/resize and view operators only) missed Alt+S,
# Shift+Alt+S, Shift+Ctrl+Alt+S, O, selection keys and remapped tools, which
# left the overlay fixed on the previously used quad-view region.
_SOS_ACTIVE_VIEW_NAVIGATION_EVENTS = frozenset({
    'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'WHEELINMOUSE', 'WHEELOUTMOUSE',
    'TRACKPADPAN', 'TRACKPADZOOM', 'MOUSEROTATE', 'NDOF_MOTION',
})
_SOS_ACTIVE_VIEW_BUTTON_EVENTS = frozenset({
    'LEFTMOUSE', 'MIDDLEMOUSE', 'RIGHTMOUSE',
    'BUTTON4MOUSE', 'BUTTON5MOUSE', 'BUTTON6MOUSE', 'BUTTON7MOUSE',
    'EVT_TWEAK_L', 'EVT_TWEAK_M', 'EVT_TWEAK_R',
})
# Never ownership events: modifier keys pressed on their own, Esc, and
# window / timer / IME / action-zone traffic.
_SOS_ACTIVE_VIEW_IGNORED_EVENTS = frozenset({
    '', 'NONE',
    'LEFT_CTRL', 'LEFT_ALT', 'LEFT_SHIFT', 'RIGHT_ALT', 'RIGHT_CTRL', 'RIGHT_SHIFT',
    'OSKEY', 'HYPER', 'APP', 'ESC',
    'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE', 'TEXTINPUT', 'WINDOW_DEACTIVATE',
    'TIMER', 'TIMER0', 'TIMER1', 'TIMER2', 'TIMER_JOBS', 'TIMER_AUTOSAVE',
    'TIMER_REPORT', 'TIMERREGION',
    'ACTIONZONE_AREA', 'ACTIONZONE_REGION', 'ACTIONZONE_REGION_QUAD',
    'ACTIONZONE_FULLSCREEN', 'XR_ACTION',
})


def _sos_active_view_operation_event(event, context=None) -> bool:
    try:
        event_type = str(getattr(event, 'type', '') or '')
        event_value = str(getattr(event, 'value', '') or '')
    except Exception:
        return False
    if event_type in _SOS_ACTIVE_VIEW_NAVIGATION_EVENTS:
        return True
    if event_type in _SOS_ACTIVE_VIEW_BUTTON_EVENTS:
        return event_value in {'PRESS', 'CLICK', 'DOUBLE_CLICK', 'CLICK_DRAG'}
    if event_value != 'PRESS' or bool(getattr(event, 'is_repeat', False)):
        return False
    if event_type in _SOS_ACTIVE_VIEW_IGNORED_EVENTS:
        return False
    if context is None or _sos_view3d_region_from_event(context, event)[1] is None:
        return False
    # Any other key pressed over a View3D main region acts on that region
    # (transform, shrink/fatten, to sphere, shear, proportional toggle,
    # selection, view keys, user-remapped tools).  Plain hover and key
    # auto-repeat never transfer ownership.
    return True


def _sos_tracked_mouse_region_coords(context, region=None):
    region = region or getattr(context, "region", None)
    if region is None:
        return -1, -1

    def _coords_from_state():
        try:
            if _sos_pointer(getattr(context, "window", None)) != _sos_mouse_window_ptr:
                return -1, -1
            if _sos_pointer(region) != _sos_active_region_ptr:
                return -1, -1
            mx_win = int(_sos_mouse_window_x)
            my_win = int(_sos_mouse_window_y)
            if mx_win < 0 or my_win < 0:
                return -1, -1
            mx_local = mx_win - int(getattr(region, "x", 0) or 0)
            my_local = my_win - int(getattr(region, "y", 0) or 0)
            width = int(getattr(region, "width", 0) or 0)
            height = int(getattr(region, "height", 0) or 0)
            if 0 <= mx_local < width and 0 <= my_local < height:
                return mx_local, my_local
        except Exception:
            pass
        return -1, -1

    mx, my = _coords_from_state()
    if mx != -1 and my != -1:
        return mx, my

    # No modal tracker is installed.  Prime the same state from passive window/OS
    # coordinates when the draw callback needs hover information.  This restores
    # Mesh Hover while keeping the no-resident-modal performance policy.
    try:
        _sos_prime_tracked_mouse_from_passive_coords(context, region=region)
    except Exception:
        pass
    return _coords_from_state()


def _sos_clip_stable_matrix_signature(rv3d, precision: int = 7) -> tuple:
    """Return a view signature that deliberately ignores View Clip Start/End.

    The visible screen position of Smart Overlay vertices/edges/faces is driven
    by the view matrix plus the X/Y projection rows.  N-panel View > Clip Start
    and Clip End edit only the projection depth mapping in normal viewport use.
    Including those Z-depth projection terms in hover/navigation signatures made
    a clip-range edit look like a real view navigation event: cached hover targets
    were rebuilt and the Lightest navigation gate could temporarily suppress the
    mesh and curve overlay.  This signature keeps orbit/pan/zoom/FOV/orthographic-scale
    sensitivity, but removes the projection row that stores clip-range depth.
    """
    if rv3d is None:
        return ()
    values = []
    try:
        view_matrix = getattr(rv3d, 'view_matrix', None)
        if view_matrix is not None:
            for row in view_matrix:
                for value in row:
                    values.append(round(float(value), precision))
    except Exception:
        values.append(0.0)
    try:
        window_matrix = getattr(rv3d, 'window_matrix', None)
        if window_matrix is not None:
            for row_index, row in enumerate(window_matrix):
                if row_index == 2:
                    # Row 2 is the clip-depth mapping in Blender's viewport
                    # projection matrices.  Skipping it makes Clip Start/End
                    # changes unable to alter overlay cache/navigation state.
                    continue
                for value in row:
                    values.append(round(float(value), precision))
    except Exception:
        values.append(0.0)
    try:
        values.append(bool(getattr(rv3d, 'is_perspective', False)))
    except Exception:
        values.append(False)
    return tuple(values)


def _sos_view_ray_clip_stable(region, rv3d, coord):
    """Return a viewport ray whose origin is not derived from Clip End.

    ``region_2d_to_origin_3d`` uses the far clipping distance for orthographic
    views unless a clamp is supplied.  A fixed clamp keeps object/face hover
    picking stable when the N-panel View clipping range is edited.
    """
    try:
        origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord, clamp=100000.0)
    except TypeError:
        try:
            origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord, 100000.0)
        except Exception:
            origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
    direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
    try:
        direction.normalize()
    except Exception:
        pass
    return origin, direction


def _sos_hover_view_signature(region, rv3d, context=None):
    try:
        values = _sos_clip_stable_matrix_signature(rv3d, precision=6)
        width = int(getattr(region, "width", 0) or 0)
        height = int(getattr(region, "height", 0) or 0)
        space_ptr = 0
        local_view_token = 0
        if context is not None:
            try:
                space = _sos_view3d_space_for_region(context, region, rv3d)
                space_ptr = _sos_pointer(space)
                local_view_token = _sos_pointer(getattr(space, 'local_view', None)) if space is not None else 0
            except Exception:
                space_ptr = 0
                local_view_token = 0
        return (width, height, _sos_hover_scene_revision, space_ptr, local_view_token, tuple(values))
    except Exception:
        return (0, 0, _sos_hover_scene_revision, 0, 0, ())


def _sos_object_hover_overlay_mode(context) -> str:
    mode = str(getattr(context, 'mode', '') or '')
    if mode == 'SCULPT':
        return 'SCULPT'
    if mode == 'OBJECT':
        return 'OBJECT'
    return ''


def _sos_object_hover_mode_objects(context, prefs, overlay_mode: str):
    mode_objs = []
    if overlay_mode == 'SCULPT':
        objs_in_mode = getattr(context, 'objects_in_mode', None)
        if objs_in_mode:
            mode_objs = [o for o in objs_in_mode if _sos_obj_supported_objmode(o, prefs)]
        else:
            mode_objs = [
                o for o in getattr(context, 'selected_objects', [])
                if _sos_obj_supported_objmode(o, prefs) and getattr(o, 'mode', None) == 'SCULPT'
            ]
        act = getattr(context, 'active_object', None)
        if act and _sos_obj_supported_objmode(act, prefs) and act not in mode_objs and getattr(act, 'mode', None) == 'SCULPT':
            mode_objs.append(act)
    elif overlay_mode == 'OBJECT':
        mode_objs = [o for o in (getattr(context, 'selected_objects', ()) or ()) if _sos_obj_supported_objmode(o, prefs)]
    return mode_objs


def _sos_pick_object_hover_overlay_name(context, prefs, overlay_mode: str, region, rv3d, mx: int, my: int) -> str:
    if overlay_mode not in {'OBJECT', 'SCULPT'}:
        return ''
    if mx == -1 or my == -1 or region is None or rv3d is None:
        return ''
    try:
        depsgraph = context.evaluated_depsgraph_get()
    except Exception:
        return ''
    try:
        scene = getattr(context, 'scene', None)
    except Exception:
        scene = None
    if scene is None:
        return ''

    is_sculpt = (overlay_mode == 'SCULPT')
    mode_objs = _sos_object_hover_mode_objects(context, prefs, overlay_mode)
    mode_obj_names = {o.name for o in mode_objs}
    hover_obj_name = ''
    skipped_selected_front_names = set()
    rear_hover_blocked = False

    try:
        ro, rd = _sos_view_ray_clip_stable(region, rv3d, (mx, my))
        co = ro
        for _ in range(15):
            res, loc, norm, f_idx, hit_obj, mat = scene.ray_cast(depsgraph, co, rd)
            if not res:
                break
            if hit_obj and _sos_obj_supported_objmode(hit_obj, prefs) and _sos_object_visible_in_view3d(context, hit_obj, region, rv3d) and not hit_obj.hide_get() and not hit_obj.hide_select:
                if is_sculpt:
                    if hit_obj.name in mode_obj_names:
                        hover_obj_name = hit_obj.name
                        break
                else:
                    hit_name = str(hit_obj.name)
                    # Object hover deliberately looks through the selected object
                    # directly under the pointer.  Once that foreground owner has
                    # been skipped, the next distinct object is the visible hover
                    # authority even when it is already selected; this is required
                    # for Ctrl-remove and Shift+Ctrl-toggle of an occluded object.
                    # Repeated entry/exit hits on the same foreground mesh remain
                    # skipped so its back face cannot become the hover target.
                    if not skipped_selected_front_names and bool(hit_obj.select_get()):
                        if not object_hover_click_selection_enabled(context):
                            # When occluded-object selection is disabled, do not
                            # advertise a rear object that the click path will not
                            # select. The selected front remains Blender-owned and
                            # receives no SmartOverlay rear-hover replacement.
                            rear_hover_blocked = True
                            break
                        skipped_selected_front_names.add(hit_name)
                    elif hit_name not in skipped_selected_front_names:
                        hover_obj_name = hit_name
                        break
            co = loc + rd * 0.0001
    except Exception:
        pass

    if not hover_obj_name and not rear_hover_blocked:
        try:
            hover_obj_name = _pick_lattice_hover_object(
                context,
                prefs,
                region,
                rv3d,
                mx,
                my,
                exclude_selected=not is_sculpt,
                allowed_names=mode_obj_names if is_sculpt else None,
            )
        except Exception:
            hover_obj_name = ''
    if not hover_obj_name and not rear_hover_blocked:
        try:
            hover_obj_name = _pick_curve_shape_hover_object(
                context,
                prefs,
                region,
                rv3d,
                mx,
                my,
                exclude_selected=not is_sculpt,
                allowed_names=mode_obj_names if is_sculpt else None,
            )
        except Exception:
            hover_obj_name = ''
    return hover_obj_name or ''


def object_hover_click_selection_enabled(context=None) -> bool:
    ctx = context or bpy.context
    wm = getattr(ctx, 'window_manager', None)
    if wm is None:
        return True
    try:
        return bool(getattr(wm, 'sos_object_hover_click_select_enabled', True))
    except Exception:
        return True


def object_hover_selection_target(context, event=None, *, record_provider_receipt=True):
    """Return only the object whose Object/Sculpt hover color is currently drawn."""
    wm = getattr(context, 'window_manager', None)
    if wm is None:
        return None
    if not bool(getattr(wm, 'sos_object_hover_overlay_enabled', False)):
        return None
    if not object_hover_click_selection_enabled(context):
        return None
    overlay_mode = _sos_object_hover_overlay_mode(context)
    if overlay_mode not in {'OBJECT', 'SCULPT'}:
        return None

    area = getattr(context, 'area', None)
    region = getattr(context, 'region', None)
    rv3d = getattr(context, 'region_data', None)
    if event is not None:
        try:
            area, region, rv3d = _sos_view3d_region_from_event(context, event)
        except Exception:
            return None
    if area is None or region is None or rv3d is None:
        return None
    try:
        if event is not None:
            mx = int(getattr(event, 'mouse_x', -1)) - int(getattr(region, 'x', 0) or 0)
            my = int(getattr(event, 'mouse_y', -1)) - int(getattr(region, 'y', 0) or 0)
        else:
            mx, my = _sos_tracked_mouse_region_coords(context, region)
    except Exception:
        return None

    # Preserve the existing click-driven active-view tracking side effect.  This
    # updates only the active-view token; it is not used to repick the object.
    if event is not None:
        try:
            _sos_update_tracked_mouse_from_event(
                context, event, update_active_view=_sos_active_view_operation_event(event)
            )
        except Exception:
            pass

    # The hover renderer has already resolved all occlusion and overlay rules and
    # recorded the exact object that received the visible hover color.  Consume
    # that value directly: never ray-pick again and never replace it with a
    # visibility/selectability re-filter at click time.
    try:
        event_value = str(getattr(event, 'value', '') or '') if event is not None else ''
    except Exception:
        event_value = ''
    # Win32/Blender can quantize the click event one physical pixel away from
    # the last MOUSEMOVE used by the draw callback.  Keep the drawn record as
    # authority for that bounded input jitter; larger movement remains native.
    click_tolerance = 1 if event_value in {'PRESS', 'RELEASE', 'CLICK'} else 0
    target = _sos_drawn_object_hover_selection_target(
        context,
        event,
        area,
        region,
        rv3d,
        mx,
        my,
        overlay_mode,
        mouse_tolerance=click_tolerance,
    )
    if target is not None and event is not None and event_value == 'PRESS' and bool(record_provider_receipt):
        _sos_note_hover_provider_press_receipt(
            context, event, area, region, rv3d, mx, my, overlay_mode, target,
        )
    return target


def _sos_note_hover_provider_press_receipt(context, event, area, region, rv3d, mx, my, overlay_mode, obj) -> None:
    """Record an explicit PRESS query by the loaded SmartTransform provider.

    Selection equality alone is not evidence that SmartTransform handled the
    gesture: ADD/SUBTRACT/no-op states can already equal the expected result.
    This short-lived receipt is therefore required before RELEASE is allowed to
    pass through for Transform modal cleanup.
    """
    global _sos_hover_provider_press_receipts
    now = time.time()
    try:
        key = (
            _sos_pointer(getattr(context, 'window', None)),
            _sos_pointer(area),
            _sos_pointer(region),
            _sos_pointer(getattr(context, 'scene', None)),
            str(overlay_mode or ''),
            int(getattr(event, 'mouse_x', -1)),
            int(getattr(event, 'mouse_y', -1)),
            bool(getattr(event, 'shift', False)),
            bool(getattr(event, 'ctrl', False)),
            str(getattr(obj, 'name', '') or ''),
            _sos_pointer(obj),
        )
        record_key = (
            _sos_pointer(getattr(context, 'window', None)),
            _sos_pointer(area),
            _sos_pointer(region),
            _sos_pointer(getattr(context, 'scene', None)),
            str(overlay_mode or ''),
        )
        drawn_record = _sos_drawn_hover_by_region.get(record_key)
        if not isinstance(drawn_record, dict):
            return
        _sos_hover_provider_press_receipts[key] = {
            'time': now,
            'key': key,
            'view_signature': tuple(_sos_hover_view_signature(region, rv3d, context) or ()),
            'mouse_local': (int(mx), int(my)),
            'snapshot_generation': int(drawn_record.get('snapshot_generation', -1)),
        }
        stale = [
            receipt_key for receipt_key, receipt in _sos_hover_provider_press_receipts.items()
            if now - float(receipt.get('time', 0.0) or 0.0) > _SOS_HOVER_PROVIDER_RECEIPT_TTL_SECONDS
        ]
        for receipt_key in stale:
            _sos_hover_provider_press_receipts.pop(receipt_key, None)
        if len(_sos_hover_provider_press_receipts) > _SOS_HOVER_PROVIDER_RECEIPT_MAX_RECORDS:
            oldest = sorted(
                _sos_hover_provider_press_receipts.items(),
                key=lambda item: float(item[1].get('time', 0.0) or 0.0),
            )[:len(_sos_hover_provider_press_receipts) - _SOS_HOVER_PROVIDER_RECEIPT_MAX_RECORDS]
            for receipt_key, _receipt in oldest:
                _sos_hover_provider_press_receipts.pop(receipt_key, None)
    except Exception:
        pass


def _sos_take_matching_hover_provider_press_receipt(context, latch) -> bool:
    global _sos_hover_provider_press_receipts
    if not isinstance(latch, dict):
        return False
    now = time.time()
    try:
        window_ptr, area_ptr, region_ptr, scene_ptr, overlay_mode = tuple(latch.get('key') or ())
        mouse_x, mouse_y = tuple(latch.get('mouse_window') or (-1000000, -1000000))
        expected_prefix = (
            int(window_ptr), int(area_ptr), int(region_ptr), int(scene_ptr), str(overlay_mode or ''),
        )
        for receipt_key, receipt in tuple(_sos_hover_provider_press_receipts.items()):
            age = now - float(receipt.get('time', 0.0) or 0.0)
            if age > _SOS_HOVER_PROVIDER_RECEIPT_TTL_SECONDS:
                _sos_hover_provider_press_receipts.pop(receipt_key, None)
                continue
            if tuple(receipt_key[:5]) != expected_prefix:
                continue
            if abs(int(receipt_key[5]) - int(mouse_x)) > 1 or abs(int(receipt_key[6]) - int(mouse_y)) > 1:
                continue
            if bool(receipt_key[7]) != bool(latch.get('shift', False)) or bool(receipt_key[8]) != bool(latch.get('ctrl', False)):
                continue
            if str(receipt_key[9] or '') != str(latch.get('object_name') or ''):
                continue
            if int(receipt_key[10] or 0) != int(latch.get('object_pointer', 0) or 0):
                continue
            if tuple(receipt.get('view_signature') or ()) != tuple(latch.get('view_signature') or ()):
                continue
            if int(receipt.get('snapshot_generation', -2)) != int(latch.get('snapshot_generation', -1)):
                continue
            _sos_hover_provider_press_receipts.pop(receipt_key, None)
            return True
    except Exception:
        return False
    return False


def clear_object_hover_click_input_authority() -> None:
    """Drop click-only receipts immediately without changing draw settings."""
    try:
        _sos_hover_provider_press_receipts.clear()
    except Exception:
        pass
    _sos_clear_hover_click_outcome()
    _sos_clear_selected_hover_suppression()


def _sos_event_matches_select_mouse(context, event) -> bool:
    try:
        if bool(getattr(event, 'alt', False)) or bool(getattr(event, 'oskey', False)):
            return False
        etype = str(getattr(event, 'type', '') or '')
        select_mouse = str(getattr(getattr(getattr(context, 'preferences', None), 'inputs', None), 'select_mouse', 'LEFT') or 'LEFT')
        expected = 'RIGHTMOUSE' if select_mouse == 'RIGHT' else 'LEFTMOUSE'
        return etype == expected
    except Exception:
        return False


def _sos_hover_click_selection_action(context, event) -> str:
    """Resolve the selection action once from the physical PRESS gesture.

    Plain/Shift/Ctrl follow the public SmartTools contract.  For Shift+Ctrl,
    honor an exact active Blender Object Mode keymap item when one exists; the
    established SmartTools fallback is TOGGLE.
    """
    shift = bool(getattr(event, 'shift', False))
    ctrl = bool(getattr(event, 'ctrl', False))
    if not (shift and ctrl):
        return 'SUBTRACT' if ctrl else ('ADD' if shift else 'SET')
    try:
        wm = getattr(context, 'window_manager', None)
        keyconfigs = getattr(wm, 'keyconfigs', None)
        seen = set()
        for cfg_name in ('user', 'active', 'default'):
            cfg = getattr(keyconfigs, cfg_name, None)
            if cfg is None:
                continue
            token = _sos_pointer(cfg)
            if token in seen:
                continue
            seen.add(token)
            for km_name in ('Object Mode', '3D View'):
                km = getattr(cfg, 'keymaps', {}).get(km_name)
                if km is None:
                    continue
                for kmi in getattr(km, 'keymap_items', ()) or ():
                    if not bool(getattr(kmi, 'active', True)):
                        continue
                    if str(getattr(kmi, 'idname', '') or '') != 'view3d.select':
                        continue
                    if str(getattr(kmi, 'type', '') or '') != str(getattr(event, 'type', '') or ''):
                        continue
                    value = str(getattr(kmi, 'value', '') or '')
                    if value not in {'PRESS', 'CLICK', 'ANY'}:
                        continue
                    if not bool(getattr(kmi, 'shift', False)) or not bool(getattr(kmi, 'ctrl', False)):
                        continue
                    if bool(getattr(kmi, 'alt', False)) or bool(getattr(kmi, 'oskey', False)):
                        continue
                    props = getattr(kmi, 'properties', None)
                    if bool(getattr(props, 'deselect', False)):
                        return 'SUBTRACT'
                    if bool(getattr(props, 'toggle', False)):
                        return 'TOGGLE'
                    if bool(getattr(props, 'extend', False)):
                        return 'ADD'
                    return 'TOGGLE'
    except Exception:
        pass
    return 'TOGGLE'


def _sos_target_in_view_layer(context, obj) -> bool:
    try:
        view_layer = getattr(context, 'view_layer', None)
        if view_layer is None:
            return False
        for candidate in getattr(view_layer, 'objects', ()) or ():
            if candidate == obj:
                return True
    except Exception:
        pass
    return False


def _sos_set_active_object(context, obj) -> None:
    try:
        context.view_layer.objects.active = obj
    except Exception:
        pass


def _sos_set_active_to_remaining_selection(context, exclude=None) -> None:
    try:
        selected = tuple(getattr(context, 'selected_objects', ()) or ())
    except Exception:
        selected = ()
    for obj in selected:
        if obj is exclude:
            continue
        try:
            if obj.select_get() and _sos_target_in_view_layer(context, obj):
                _sos_set_active_object(context, obj)
                return
        except Exception:
            continue
    try:
        context.view_layer.objects.active = None
    except Exception:
        pass


def _sos_rebuild_current_overlay_snapshot_now(context) -> bool:
    """Synchronously publish the exact current View3D snapshot after a click.

    This one-shot event-side rebuild prevents one or more stale yellow frames
    while the normal finite coalescing timer catches up. It never runs from a
    draw callback.
    """
    global _sos_overlay_snapshot_generation, _sos_overlay_snapshot_last_build_time
    global _sos_edit_collect_degraded
    try:
        if context is None or not _sos_runtime_registered:
            return False
        if getattr(getattr(context, 'area', None), 'type', None) != 'VIEW_3D':
            return False
        if getattr(getattr(context, 'region', None), 'type', None) != 'WINDOW':
            return False
        if getattr(context, 'region_data', None) is None:
            return False
        _sos_overlay_snapshot_generation += 1
        generation = int(_sos_overlay_snapshot_generation)
        _sos_edit_collect_degraded = False
        record = _sos_build_overlay_snapshot_for_context(context, generation)
        if record is None or not _sos_publish_overlay_snapshot(record):
            return False
        _sos_overlay_snapshot_last_build_time = float(time.monotonic())
        if _sos_edit_collect_degraded:
            _sos_schedule_degraded_snapshot_followup(context)
        return True
    except Exception:
        return False


def select_object_hover_target_like_click(context, event, obj, *, action=None) -> bool:
    """Apply Object Mode style Set/Add/Subtract/Toggle selection to obj."""
    global _sos_selection_changed_time
    if obj is None:
        return False

    # The object was already accepted by the hover renderer and visibly received
    # the hover color.  Do not replace that result with a click-time view-layer,
    # visibility, selectability, or occlusion filter.
    shift = bool(getattr(event, 'shift', False))
    ctrl = bool(getattr(event, 'ctrl', False))
    if action:
        selection_action = str(action)
    elif shift and ctrl:
        try:
            selection_action = str(_sos_hover_click_selection_action(context, event) or 'TOGGLE')
        except Exception:
            selection_action = 'TOGGLE'
    else:
        selection_action = 'SUBTRACT' if ctrl else ('ADD' if shift else 'SET')
    try:
        selected_now = bool(obj.select_get())
    except Exception:
        selected_now = False

    try:
        if selection_action == 'TOGGLE':
            if selected_now:
                obj.select_set(False)
                active = getattr(context, 'active_object', None)
                if active == obj:
                    _sos_set_active_to_remaining_selection(context, exclude=obj)
            else:
                obj.select_set(True)
                _sos_set_active_object(context, obj)
        elif selection_action == 'SUBTRACT':
            if selected_now:
                obj.select_set(False)
                active = getattr(context, 'active_object', None)
                if active == obj:
                    _sos_set_active_to_remaining_selection(context, exclude=obj)
        elif selection_action == 'ADD':
            obj.select_set(True)
            _sos_set_active_object(context, obj)
        else:
            try:
                for other in tuple(getattr(context, 'selected_objects', ()) or ()):
                    if other != obj:
                        other.select_set(False)
            except Exception:
                try:
                    for other in getattr(getattr(context, 'view_layer', None), 'objects', ()) or ():
                        if other != obj:
                            try:
                                other.select_set(False)
                            except Exception:
                                pass
                except Exception:
                    pass
            obj.select_set(True)
            _sos_set_active_object(context, obj)
    except Exception:
        return False

    _sos_selection_changed_time = time.time()
    _sos_record_hover_click_outcome(context, event, obj)
    reset_object_hover_cache()
    try:
        if bool(obj.select_get()):
            _sos_arm_selected_hover_suppression(context, event, obj)
        else:
            _sos_clear_selected_hover_suppression()
    except Exception:
        _sos_clear_selected_hover_suppression()
    # Publish the click result immediately so an already completed yellow
    # snapshot cannot survive until the asynchronous coalescing timer. The
    # normal finite rebuild remains as a race-safe follow-up.
    _sos_rebuild_current_overlay_snapshot_now(context)
    request_overlay_snapshot_rebuild(
        'hover_click_selection_committed', context=context, immediate=True,
    )
    tag_view3d_redraw(context)
    return True


def _sos_hover_click_expected_selection(snapshot, target_name: str, shift: bool, ctrl: bool, action=None):
    """Pure expected result used to detect a SmartTransform-owned click."""
    try:
        selected_names, active_name = snapshot
    except Exception:
        selected_names, active_name = (), ''
    ordered = list(dict.fromkeys(str(name) for name in (selected_names or ()) if name))
    target_name = str(target_name or '')
    selected = set(ordered)
    active = str(active_name or '')
    selection_action = str(action or ('TOGGLE' if (ctrl and shift) else ('SUBTRACT' if ctrl else ('ADD' if shift else 'SET'))))
    if selection_action == 'TOGGLE':
        if target_name in selected:
            selected.discard(target_name)
            ordered = [name for name in ordered if name != target_name]
            if active == target_name:
                active = ordered[0] if ordered else ''
        else:
            selected.add(target_name)
            ordered.append(target_name)
            active = target_name
    elif selection_action == 'SUBTRACT':
        if target_name in selected:
            selected.discard(target_name)
            ordered = [name for name in ordered if name != target_name]
            if active == target_name:
                active = ordered[0] if ordered else ''
    elif selection_action == 'ADD':
        selected.add(target_name)
        if target_name not in ordered:
            ordered.append(target_name)
        active = target_name
    else:
        selected = {target_name} if target_name else set()
        active = target_name
    return frozenset(selected), active


def _sos_hover_click_selection_matches(context, expected) -> bool:
    selected_names, active_name = _sos_selection_snapshot(context)
    try:
        return frozenset(selected_names) == frozenset(expected[0]) and str(active_name or '') == str(expected[1] or '')
    except Exception:
        return False


def _sos_hover_click_drag_threshold(context) -> int:
    inputs = getattr(getattr(context, 'preferences', None), 'inputs', None)
    for name in ('drag_threshold_mouse', 'drag_threshold', 'move_threshold'):
        try:
            value = int(getattr(inputs, name, 0) or 0)
            if value > 0:
                return value
        except Exception:
            pass
    return 5


_sos_hover_click_latches_by_window = {}


def _sos_clear_hover_click_runtime_state():
    global _sos_mouse_tracker_modal_generation
    try:
        _sos_mouse_tracker_modal_generation = int(_sos_mouse_tracker_modal_generation or 0) + 1
    except Exception:
        _sos_mouse_tracker_modal_generation = 1
    _sos_hover_click_latches_by_window.clear()
    try:
        _sos_mouse_tracker_modal_windows.clear()
    except Exception:
        pass
    try:
        _sos_clear_hover_click_outcome()
    except Exception:
        pass
    try:
        reset_object_hover_cache()
    except Exception:
        pass


def _sos_hover_click_press_latch(context, event):
    if not SOS_OT_HoverClickSelect.poll(context) or not _sos_event_matches_select_mouse(context, event):
        return None
    try:
        if str(getattr(event, 'value', '') or '') != 'PRESS':
            return None
        _sos_update_tracked_mouse_from_event(context, event, update_active_view=True)
        area, region, rv3d = _sos_view3d_region_from_event(context, event)
        if area is None or region is None or rv3d is None:
            return None
        mx_win = int(getattr(event, 'mouse_x', -1))
        my_win = int(getattr(event, 'mouse_y', -1))
        mx = mx_win - int(getattr(region, 'x', 0) or 0)
        my = my_win - int(getattr(region, 'y', 0) or 0)
        overlay_mode = _sos_object_hover_overlay_mode(context)
        key = (
            _sos_pointer(getattr(context, 'window', None)), _sos_pointer(area), _sos_pointer(region),
            _sos_pointer(getattr(context, 'scene', None)), overlay_mode,
        )
        record = _sos_drawn_hover_by_region.get(key)
        if not isinstance(record, dict):
            return None
        current_view_signature = tuple(_sos_hover_view_signature(region, rv3d, context) or ())
        if tuple(record.get('view_signature') or ()) != current_view_signature:
            return None
        threshold = max(1, int(_sos_hover_click_drag_threshold(context) or 0))
        authority_x, authority_y = tuple(record.get('mouse') or (-1000000, -1000000))
        if abs(int(mx) - int(authority_x)) > threshold or abs(int(my) - int(authority_y)) > threshold:
            return None
        scene = getattr(context, 'scene', None)
        obj = scene.objects.get(str(record.get('object_name') or '')) if scene is not None else None
        if obj is None:
            return None
        if _sos_pointer(obj) != int(record.get('object_pointer', 0) or 0):
            return None
        return {
            'key': key,
            'window_pointer': int(key[0] or 0),
            'object_name': str(getattr(obj, 'name', '') or ''),
            'object_pointer': _sos_pointer(obj),
            'snapshot_generation': int(record.get('snapshot_generation', -1)),
            'runtime_generation': int(_sos_mouse_tracker_modal_generation or 0),
            'view_signature': current_view_signature,
            'mouse_window': (mx_win, my_win),
            'mouse_local': (mx, my),
            'authority_mouse_local': tuple(record.get('mouse') or (mx, my)),
            'shift': bool(getattr(event, 'shift', False)),
            'ctrl': bool(getattr(event, 'ctrl', False)),
            'selection_action': (
                _sos_hover_click_selection_action(context, event)
                if bool(getattr(event, 'shift', False)) and bool(getattr(event, 'ctrl', False))
                else ('SUBTRACT' if bool(getattr(event, 'ctrl', False)) else ('ADD' if bool(getattr(event, 'shift', False)) else 'SET'))
            ),
            'selection_snapshot': _sos_selection_snapshot(context),
        }
    except Exception:
        return None


def _sos_hover_click_release_record_is_compatible(record, latch, current_view_signature, current_mouse_local, threshold) -> bool:
    """Keep the PRESS authority for one click-sized physical gesture.

    PRESS already proved record/snapshot publication integrity.  A native or
    SmartTransform selection on that same physical click may legitimately clear
    the drawn record, advance the general overlay generation, or redraw another
    selected object before RELEASE. Small OS/Blender MOUSEMOVE events are also
    normal during a click, so neither a selection-redrawn target nor sub-threshold
    cursor movement can replace the object whose drawn authority was latched at
    PRESS. Region/view/modifier checks remain exact, and motion beyond Blender's
    drag threshold clears or rejects the latch.
    """
    if record is None:
        return True
    if not isinstance(record, dict) or not isinstance(latch, dict):
        return False
    try:
        current_view = tuple(current_view_signature or ())
        if tuple(record.get('view_signature') or ()) != current_view:
            return False
        if current_view != tuple(latch.get('view_signature') or ()):
            return False
        # PRESS already latched the exact object that visibly owned the hover
        # color. Blender's native selection may redraw the already-selected
        # foreground object before RELEASE, replacing the current draw record.
        # That redraw must not revoke the PRESS authority: region, view, input
        # modifiers, latched object identity, and drag distance are still checked.
        start_x, start_y = tuple(latch.get('mouse_local') or (-1000000, -1000000))
        current_x, current_y = tuple(current_mouse_local or (-999999, -999999))
        limit = max(0, int(threshold or 0))
        return abs(int(current_x) - int(start_x)) <= limit and abs(int(current_y) - int(start_y)) <= limit
    except Exception:
        return False


def _sos_hover_click_latch_is_current(context, event, latch) -> bool:
    if not isinstance(latch, dict) or not SOS_OT_HoverClickSelect.poll(context):
        return False
    try:
        if int(latch.get('runtime_generation', -1)) != int(_sos_mouse_tracker_modal_generation or 0):
            return False
        window_pointer = _sos_pointer(getattr(context, 'window', None))
        if window_pointer != int(latch.get('window_pointer', 0) or 0):
            return False
        if _sos_hover_click_latches_by_window.get(int(window_pointer)) is not latch:
            return False
        area, region, rv3d = _sos_view3d_region_from_event(context, event)
        key = (
            _sos_pointer(getattr(context, 'window', None)), _sos_pointer(area), _sos_pointer(region),
            _sos_pointer(getattr(context, 'scene', None)), _sos_object_hover_overlay_mode(context),
        )
        if key != tuple(latch.get('key') or ()):
            return False
        record = _sos_drawn_hover_by_region.get(key)
        current_view_signature = tuple(_sos_hover_view_signature(region, rv3d, context) or ())
        if current_view_signature != tuple(latch.get('view_signature') or ()):
            return False
        start_x, start_y = latch.get('mouse_window') or (-1000000, -1000000)
        now_x = int(getattr(event, 'mouse_x', -999999))
        now_y = int(getattr(event, 'mouse_y', -999999))
        threshold = _sos_hover_click_drag_threshold(context)
        if abs(now_x - int(start_x)) > threshold or abs(now_y - int(start_y)) > threshold:
            return False
        current_mouse_local = (
            now_x - int(getattr(region, 'x', 0) or 0),
            now_y - int(getattr(region, 'y', 0) or 0),
        )
        if not _sos_hover_click_release_record_is_compatible(
            record, latch, current_view_signature, current_mouse_local, threshold,
        ):
            return False
        scene = getattr(context, 'scene', None)
        obj = scene.objects.get(str(latch.get('object_name') or '')) if scene is not None else None
        return bool(obj is not None and _sos_pointer(obj) == int(latch.get('object_pointer', 0) or 0))
    except Exception:
        return False


def _sos_hover_click_commit_latch(context, event, latch) -> bool:
    if not _sos_hover_click_latch_is_current(context, event, latch):
        return False
    target_name = str(latch.get('object_name') or '')
    expected = _sos_hover_click_expected_selection(
        latch.get('selection_snapshot'), target_name,
        bool(latch.get('shift', False)), bool(latch.get('ctrl', False)),
        action=latch.get('selection_action'),
    )
    try:
        obj = context.scene.objects.get(target_name)
    except Exception:
        obj = None
    if obj is None:
        return False
    # SmartTransform may already have consumed PRESS through the same provider.
    # Never reapply or restore selection in that case.  RELEASE must pass through
    # so Transform can finish its modal cleanup, but leave a one-shot receipt for
    # Blender configurations that dispatch a later CLICK.  If CLICK arrives while
    # this latch is still pending, consume that event immediately with zero
    # selection mutation.
    provider_owned = _sos_take_matching_hover_provider_press_receipt(context, latch)
    if provider_owned and _sos_hover_click_selection_matches(context, expected):
        try:
            event_value = str(getattr(event, 'value', '') or '')
        except Exception:
            event_value = ''
        if event_value == 'RELEASE':
            _sos_record_hover_click_outcome(context, event, obj)
            return False
        if event_value == 'CLICK':
            _sos_clear_hover_click_outcome()
            return True
        return False
    if not _sos_restore_selection_snapshot(context, latch.get('selection_snapshot'), redraw=False):
        return False
    return bool(select_object_hover_target_like_click(
        context, event, obj, action=latch.get('selection_action'),
    ))



def _sos_lightest_view_key(context=None, rv3d=None) -> int:
    try:
        region = getattr(context, 'region', None) if context is not None else None
        key = _sos_pointer(region)
        if key:
            return key
    except Exception:
        pass
    try:
        key = _sos_pointer(rv3d)
        if key:
            return key
    except Exception:
        pass
    return 0


def _sos_lightest_matrix_signature(rv3d) -> tuple:
    """Compact viewport signature for the Lightest navigation gate.

    Orbit, pan, zoom, FOV, orthographic-scale, and projection-mode changes still
    move this signature.  Clip Start/End depth-row edits are intentionally
    ignored so changing the N-panel View clipping range cannot temporarily hide,
    freeze, or rebuild the Mesh/Hover overlay.
    """
    return _sos_clip_stable_matrix_signature(rv3d, precision=7)


def _sos_lightest_nav_redraw_timer():
    global _sos_lightest_view_nav_timer_pending
    try:
        now = time.perf_counter()
        future_until = [float(v) for v in _sos_lightest_view_nav_until.values() if float(v) > now]
        if future_until:
            return max(0.01, min(0.05, min(future_until) - now + 0.01))
    except Exception:
        pass
    _sos_lightest_view_nav_timer_pending = False
    try:
        tag_view3d_redraw(getattr(bpy, 'context', None))
    except Exception:
        pass
    return None


def _sos_schedule_lightest_nav_restore_redraw() -> None:
    global _sos_lightest_view_nav_timer_pending
    if _sos_lightest_view_nav_timer_pending:
        return
    _sos_lightest_view_nav_timer_pending = True
    try:
        bpy.app.timers.register(_sos_lightest_nav_redraw_timer, first_interval=0.05)
    except Exception:
        _sos_lightest_view_nav_timer_pending = False


def _sos_lightest_mesh_overlay_navigation_active(context=None, prefs=None, rv3d=None, *, force=False) -> bool:
    if prefs is None:
        try:
            prefs = get_effective_settings(context or getattr(bpy, 'context', None))
        except Exception:
            prefs = None
    if not force and not (
        _sos_opt_bool(prefs, 'show_embedded_edit_cage_while_view_still_xray_off', True)
        or _sos_opt_bool(prefs, 'optimization_navigation_light_mode', False)
        or _sos_opt_bool(prefs, 'optimization_lightest_freeze_batches_during_navigation', False)
    ):
        return False
    rv3d = rv3d or getattr(context, 'region_data', None) if context is not None else rv3d
    key = _sos_lightest_view_key(context, rv3d)
    if not key:
        return False
    sig = _sos_lightest_matrix_signature(rv3d)
    if not sig:
        return False
    now = time.perf_counter()
    try:
        prev = _sos_lightest_view_nav_signatures.get(key)
    except Exception:
        prev = None
    if prev is not None and prev != sig:
        try:
            _sos_lightest_view_nav_until[key] = now + _SOS_LIGHTEST_NAV_HOLD_SECONDS
            _sos_schedule_lightest_nav_restore_redraw()
        except Exception:
            pass
    try:
        _sos_lightest_view_nav_signatures[key] = sig
        if len(_sos_lightest_view_nav_signatures) > _SOS_LIGHTEST_NAV_CACHE_LIMIT:
            for old_key in list(_sos_lightest_view_nav_signatures.keys())[:-_SOS_LIGHTEST_NAV_CACHE_LIMIT]:
                _sos_lightest_view_nav_signatures.pop(old_key, None)
                _sos_lightest_view_nav_until.pop(old_key, None)
    except Exception:
        pass
    try:
        return now < float(_sos_lightest_view_nav_until.get(key, 0.0) or 0.0)
    except Exception:
        return False


def _sos_lightest_lod_limit(prefs=None) -> int:
    try:
        return max(1000, int(getattr(prefs, 'optimization_lightest_lod_element_limit', 200000) or 200000))
    except Exception:
        return 200000

def tag_view3d_redraw(context=None, *, area=None, region=None):
    try:
        _sos_note_runtime_redraw_request()
    except Exception:
        pass
    if (area is not None or region is not None) and _sos_tag_single_view3d(area=area, region=region, context=context):
        return
    ctx = context or bpy.context
    try:
        prefs = get_effective_settings(ctx)
        if _sos_opt_bool(prefs, 'active_view_only', False) or _sos_opt_bool(prefs, 'optimization_navigation_light_mode', False):
            if _sos_tag_single_view3d(area=getattr(ctx, 'area', None), region=getattr(ctx, 'region', None), context=ctx):
                return
    except Exception:
        pass
    wm = getattr(ctx, "window_manager", None)
    if wm:
        seen = set()
        for w in getattr(wm, 'windows', ()) or ():
            screen = getattr(w, 'screen', None)
            for a in getattr(screen, 'areas', ()) or ():
                if getattr(a, 'type', None) == 'VIEW_3D':
                    token = _sos_pointer(a)
                    if token and token in seen:
                        continue
                    if token:
                        seen.add(token)
                    try:
                        a.tag_redraw()
                    except Exception:
                        pass


def _safe_collection_len(owner, attr_name: str) -> int:
    try:
        value = getattr(owner, attr_name, None)
    except Exception:
        return -1
    if value is None:
        return -1
    try:
        return int(len(value))
    except Exception:
        return -1


def _is_lattice_object(obj) -> bool:
    try:
        return getattr(obj, 'type', None) == 'LATTICE'
    except Exception:
        return False


def _is_lattice_data(data) -> bool:
    if data is None:
        return False
    try:
        lattice_type = getattr(bpy.types, 'Lattice', None)
        if lattice_type is not None and isinstance(data, lattice_type):
            return True
    except Exception:
        pass
    try:
        return type(data).__name__ == 'Lattice'
    except Exception:
        return False


def _lattice_dimensions(data) -> tuple[int, int, int]:
    try:
        u = max(0, int(getattr(data, 'points_u', 0) or 0))
        v = max(0, int(getattr(data, 'points_v', 0) or 0))
        w = max(0, int(getattr(data, 'points_w', 0) or 0))
    except Exception:
        u = v = w = 0
    return u, v, w


def _lattice_point_local_co(point) -> tuple[float, float, float]:
    co = None
    for attr_name in ('co_deform', 'co'):
        try:
            value = getattr(point, attr_name, None)
        except Exception:
            value = None
        if value is not None:
            co = value
            break
    if co is None:
        return (0.0, 0.0, 0.0)
    try:
        return (float(co[0]), float(co[1]), float(co[2]))
    except Exception:
        try:
            return (float(getattr(co, 'x', 0.0)), float(getattr(co, 'y', 0.0)), float(getattr(co, 'z', 0.0)))
        except Exception:
            return (0.0, 0.0, 0.0)


def _lattice_point_signature(data) -> tuple:
    try:
        points = tuple(getattr(data, 'points', ()) or ())
    except Exception:
        points = ()
    if not points:
        return ()
    sig = []
    for point in points:
        try:
            co = _lattice_point_local_co(point)
            selected = bool(getattr(point, 'select', False)) if hasattr(point, 'select') else False
            sig.append((round(co[0], 6), round(co[1], 6), round(co[2], 6), selected))
        except Exception:
            continue
    return tuple(sig)


def _lattice_index(u: int, v: int, w: int, dims: tuple[int, int, int]) -> int:
    du, dv, _dw = dims
    return (int(w) * int(dv) + int(v)) * int(du) + int(u)


def _lattice_edges_for_dims(dims: tuple[int, int, int], total: int) -> np.ndarray:
    du, dv, dw = dims
    edges = []
    if du <= 0 or dv <= 0 or dw <= 0 or total <= 0:
        return np.empty((0, 2), dtype=np.int32)
    if du * dv * dw != total:
        # Last-resort fallback for unusual data ordering: draw a simple point chain
        # instead of risking invalid indices.
        edges = [(i, i + 1) for i in range(max(0, total - 1))]
        return np.asarray(edges, dtype=np.int32) if edges else np.empty((0, 2), dtype=np.int32)
    for w in range(dw):
        for v in range(dv):
            for u in range(du):
                a = _lattice_index(u, v, w, dims)
                if u + 1 < du:
                    edges.append((a, _lattice_index(u + 1, v, w, dims)))
                if v + 1 < dv:
                    edges.append((a, _lattice_index(u, v + 1, w, dims)))
                if w + 1 < dw:
                    edges.append((a, _lattice_index(u, v, w + 1, dims)))
    return np.asarray(edges, dtype=np.int32) if edges else np.empty((0, 2), dtype=np.int32)


def _lattice_surface_tris_for_dims(dims: tuple[int, int, int], total: int) -> np.ndarray:
    du, dv, dw = dims
    if du <= 0 or dv <= 0 or dw <= 0 or total <= 0 or du * dv * dw != total:
        return np.empty((0, 3), dtype=np.int32)
    tris = []
    quads_seen = set()

    def add_quad(a, b, c, d):
        quad_key = tuple(sorted((int(a), int(b), int(c), int(d))))
        if quad_key in quads_seen:
            return
        quads_seen.add(quad_key)
        tris.append((int(a), int(b), int(c)))
        tris.append((int(a), int(c), int(d)))

    # XY planes (front/back in lattice W)
    if du > 1 and dv > 1:
        planes = (0,) if dw == 1 else (0, dw - 1)
        for w in planes:
            for v in range(dv - 1):
                for u in range(du - 1):
                    add_quad(
                        _lattice_index(u, v, w, dims),
                        _lattice_index(u + 1, v, w, dims),
                        _lattice_index(u + 1, v + 1, w, dims),
                        _lattice_index(u, v + 1, w, dims),
                    )
    # XZ planes (min/max V)
    if du > 1 and dw > 1:
        planes = (0,) if dv == 1 else (0, dv - 1)
        for v in planes:
            for w in range(dw - 1):
                for u in range(du - 1):
                    add_quad(
                        _lattice_index(u, v, w, dims),
                        _lattice_index(u + 1, v, w, dims),
                        _lattice_index(u + 1, v, w + 1, dims),
                        _lattice_index(u, v, w + 1, dims),
                    )
    # YZ planes (min/max U)
    if dv > 1 and dw > 1:
        planes = (0,) if du == 1 else (0, du - 1)
        for u in planes:
            for w in range(dw - 1):
                for v in range(dv - 1):
                    add_quad(
                        _lattice_index(u, v, w, dims),
                        _lattice_index(u, v + 1, w, dims),
                        _lattice_index(u, v + 1, w + 1, dims),
                        _lattice_index(u, v, w + 1, dims),
                    )
    return np.asarray(tris, dtype=np.int32) if tris else np.empty((0, 3), dtype=np.int32)


def _lattice_geometry_arrays(obj):
    data = getattr(obj, 'data', None)
    if not _is_lattice_data(data):
        return None
    try:
        points = tuple(getattr(data, 'points', ()) or ())
    except Exception:
        points = ()
    total = len(points)
    if total <= 0:
        return None
    dims = _lattice_dimensions(data)
    if dims[0] * dims[1] * dims[2] != total:
        dims = (total, 1, 1)
    verts = np.asarray([_lattice_point_local_co(point) for point in points], dtype=np.float32)
    edges = _lattice_edges_for_dims(dims, total)
    # Lattice objects are cage/control-point overlays only. Do not generate
    # surface triangles; the lattice include option must never draw face fills.
    tris = np.empty((0, 3), dtype=np.int32)
    selected = np.asarray([bool(getattr(point, 'select', False)) if hasattr(point, 'select') else False for point in points], dtype=np.bool_)
    return verts, edges, tris, selected


def _screen_segment_distance_sq(px, py, ax, ay, bx, by) -> float:
    dx = float(bx) - float(ax)
    dy = float(by) - float(ay)
    l2 = dx * dx + dy * dy
    if l2 <= 1e-10:
        return (float(px) - float(ax)) ** 2 + (float(py) - float(ay)) ** 2
    t = max(0.0, min(1.0, ((float(px) - float(ax)) * dx + (float(py) - float(ay)) * dy) / l2))
    qx = float(ax) + t * dx
    qy = float(ay) + t * dy
    return (float(px) - qx) ** 2 + (float(py) - qy) ** 2


def _lattice_projected_points(obj, verts, region, rv3d):
    try:
        mw = getattr(obj, 'matrix_world', None)
    except Exception:
        mw = None
    if mw is None or verts is None:
        return []
    projected = []
    for co in verts:
        try:
            p2 = view3d_utils.location_3d_to_region_2d(region, rv3d, mw @ Vector((float(co[0]), float(co[1]), float(co[2]))))
            if p2 is None:
                projected.append(None)
            else:
                projected.append((float(p2.x), float(p2.y)))
        except Exception:
            projected.append(None)
    return projected


def _lattice_pick_distance_sq(obj, verts, edges, region, rv3d, mx, my) -> float | None:
    projected = _lattice_projected_points(obj, verts, region, rv3d)
    if not projected:
        return None
    best = None
    for p2 in projected:
        if p2 is None:
            continue
        d = (float(mx) - p2[0]) ** 2 + (float(my) - p2[1]) ** 2
        best = d if best is None or d < best else best
    try:
        edge_iter = edges.tolist() if hasattr(edges, 'tolist') else edges
    except Exception:
        edge_iter = ()
    for a, b in edge_iter:
        try:
            pa = projected[int(a)]
            pb = projected[int(b)]
        except Exception:
            continue
        if pa is None or pb is None:
            continue
        d = _screen_segment_distance_sq(mx, my, pa[0], pa[1], pb[0], pb[1])
        best = d if best is None or d < best else best
    return best


def _pick_lattice_hover_object(context, prefs, region, rv3d, mx, my, *, exclude_selected: bool = True, allowed_names=None) -> str:
    if not bool(getattr(prefs, 'include_lattice_objects', True)):
        return ''
    if mx == -1 or my == -1 or region is None or rv3d is None:
        return ''
    allowed_names = set(allowed_names or ()) if allowed_names is not None else None
    try:
        objects = tuple(getattr(context, 'visible_objects', ()) or ())
    except Exception:
        objects = ()
    if not objects:
        try:
            objects = tuple(getattr(getattr(context, 'scene', None), 'objects', ()) or ())
        except Exception:
            objects = ()
    try:
        threshold = max(float(get_csdt_radius('VERT') or 0.0), float(get_csdt_radius('EDGE') or 0.0), 12.0)
    except Exception:
        threshold = 12.0
    threshold_sq = threshold * threshold
    best_name = ''
    best_dist = None
    for obj in objects:
        try:
            if not _is_lattice_object(obj):
                continue
            if allowed_names is not None and obj.name not in allowed_names:
                continue
            if not _sos_obj_supported_objmode(obj, prefs):
                continue
            if exclude_selected and bool(obj.select_get()):
                continue
            if bool(obj.hide_get()) or bool(getattr(obj, 'hide_select', False)) or not _sos_object_visible_in_view3d(context, obj, region, rv3d):
                continue
            arrays = _lattice_geometry_arrays(obj)
            if not arrays:
                continue
            verts, edges, _tris, _selected = arrays
            dist_sq = _lattice_pick_distance_sq(obj, verts, edges, region, rv3d, mx, my)
            if dist_sq is None or dist_sq > threshold_sq:
                continue
            if best_dist is None or dist_sq < best_dist:
                best_dist = dist_sq
                best_name = obj.name
        except Exception:
            continue
    return best_name


def _lattice_element_hover(obj, verts, edges, tris, region, rv3d, mx, my) -> tuple[int, int, int]:
    if mx == -1 or my == -1 or region is None or rv3d is None:
        return -1, -1, -1
    projected = _lattice_projected_points(obj, verts, region, rv3d)
    if not projected:
        return -1, -1, -1
    try:
        v_threshold = max(float(get_csdt_radius('VERT') or 0.0), 8.0)
    except Exception:
        v_threshold = 8.0
    try:
        e_threshold = max(float(get_csdt_radius('EDGE') or 0.0), 9.0)
    except Exception:
        e_threshold = 9.0
    best_v = -1
    best_vd = v_threshold * v_threshold
    for i, p2 in enumerate(projected):
        if p2 is None:
            continue
        d = (float(mx) - p2[0]) ** 2 + (float(my) - p2[1]) ** 2
        if d < best_vd:
            best_vd = d
            best_v = int(i)
    if best_v != -1:
        return best_v, -1, -1

    best_e = -1
    best_ed = e_threshold * e_threshold
    try:
        edge_iter = edges.tolist() if hasattr(edges, 'tolist') else edges
    except Exception:
        edge_iter = ()
    for i, edge in enumerate(edge_iter):
        try:
            a, b = int(edge[0]), int(edge[1])
            pa = projected[a]
            pb = projected[b]
        except Exception:
            continue
        if pa is None or pb is None:
            continue
        d = _screen_segment_distance_sq(mx, my, pa[0], pa[1], pb[0], pb[1])
        if d < best_ed:
            best_ed = d
            best_e = int(i)
    return -1, best_e, -1




def _is_curve_object(obj) -> bool:
    try:
        return getattr(obj, 'type', None) == 'CURVE'
    except Exception:
        return False


def _sos_curve_has_render_mesh_settings(obj) -> bool:
    """Return True when a Curve is expected to produce polygonal render mesh.

    A plain 3D curve without bevel normally evaluates to a line mesh only.  Face
    overlay and mesh-like hover should use the evaluated render mesh only when
    bevel, extrusion, or 2D fill settings can create polygons.
    """
    if not _is_curve_object(obj):
        return False
    data = getattr(obj, 'data', None)
    if data is None:
        return False
    try:
        if float(getattr(data, 'bevel_depth', 0.0) or 0.0) > 0.0:
            return True
    except Exception:
        pass
    try:
        if float(getattr(data, 'extrude', 0.0) or 0.0) > 0.0:
            return True
    except Exception:
        pass
    try:
        if str(getattr(data, 'dimensions', '') or '') == '2D' and str(getattr(data, 'fill_mode', '') or '') not in {'NONE', 'HALF'}:
            return True
    except Exception:
        pass
    return False


def _curve_point_local_co(point) -> tuple[float, float, float]:
    try:
        co = getattr(point, 'co', None)
    except Exception:
        co = None
    if co is None:
        return (0.0, 0.0, 0.0)
    try:
        if len(co) >= 4:
            w = float(co[3]) if abs(float(co[3])) > 1.0e-12 else 1.0
            return (float(co[0]) / w, float(co[1]) / w, float(co[2]) / w)
    except Exception:
        pass
    try:
        return (float(co[0]), float(co[1]), float(co[2]))
    except Exception:
        try:
            return (float(getattr(co, 'x', 0.0)), float(getattr(co, 'y', 0.0)), float(getattr(co, 'z', 0.0)))
        except Exception:
            return (0.0, 0.0, 0.0)


def _curve_bezier_signature_point(point) -> tuple:
    try:
        co = tuple(round(float(v), 6) for v in getattr(point, 'co', (0.0, 0.0, 0.0))[:3])
    except Exception:
        co = (0.0, 0.0, 0.0)
    try:
        hl = tuple(round(float(v), 6) for v in getattr(point, 'handle_left', (0.0, 0.0, 0.0))[:3])
    except Exception:
        hl = (0.0, 0.0, 0.0)
    try:
        hr = tuple(round(float(v), 6) for v in getattr(point, 'handle_right', (0.0, 0.0, 0.0))[:3])
    except Exception:
        hr = (0.0, 0.0, 0.0)
    try:
        sel = bool(getattr(point, 'select_control_point', False))
    except Exception:
        sel = False
    return (co, hl, hr, sel)


def _curve_point_signature_point(point) -> tuple:
    co = _curve_point_local_co(point)
    try:
        sel = bool(getattr(point, 'select', False))
    except Exception:
        sel = False
    return (round(co[0], 6), round(co[1], 6), round(co[2], 6), sel)


def _sos_curve_bezier_point_arrays(spline):
    """Read one Bezier spline with foreach_get, in RNA order (float32 / bool)."""
    bps = spline.bezier_points
    n = len(bps)
    co = np.empty(n * 3, dtype=np.float32)
    hl = np.empty(n * 3, dtype=np.float32)
    hr = np.empty(n * 3, dtype=np.float32)
    sel = np.empty(n, dtype=np.bool_)
    if n:
        bps.foreach_get('co', co)
        bps.foreach_get('handle_left', hl)
        bps.foreach_get('handle_right', hr)
        bps.foreach_get('select_control_point', sel)
    return co.reshape(n, 3), hl.reshape(n, 3), hr.reshape(n, 3), sel


def _sos_curve_nurbs_point_arrays(spline):
    """Read one Poly/NURBS spline with foreach_get, in RNA order (float32[4] / bool)."""
    pts = spline.points
    n = len(pts)
    co = np.empty(n * 4, dtype=np.float32)
    sel = np.empty(n, dtype=np.bool_)
    if n:
        pts.foreach_get('co', co)
        pts.foreach_get('select', sel)
    return co.reshape(n, 4), sel


def _sos_curve_points_fast_signature(spline, spline_type):
    """Exact raw point signature of one spline, or None to use the per-point path.

    Bit-identical inputs give an identical signature, so a cache hit never shows
    different geometry than a rebuild would.  The raw form is stricter than the
    rounded per-point tuples, therefore it can only rebuild more often, never less.
    """
    try:
        if spline_type == 'BEZIER':
            co, hl, hr, sel = _sos_curve_bezier_point_arrays(spline)
            return ('SOS_RAW_BEZIER', co.tobytes(), hl.tobytes(), hr.tobytes(), sel.tobytes())
        co4, sel = _sos_curve_nurbs_point_arrays(spline)
        return ('SOS_RAW_POINTS', co4.tobytes(), sel.tobytes())
    except Exception:
        return None


def _sos_curve_forward_diff_bezier_np(q0, q1, q2, q3, it):
    """BKE_curve_forward_diff_bezier() for many segments at once.

    Same float32 operations in the same order, so every sample is bit-identical
    to mathutils.geometry.interpolate_bezier(k1, h1, h2, k2, it + 1).
    q0..q3 are float32 arrays of shape (segments, dims).
    """
    f32 = np.float32
    f = f32(it)
    rt0 = q0
    rt1 = (f32(3.0) * (q1 - q0)) / f
    f = f32(f * f)
    rt2 = (f32(3.0) * ((q0 - f32(2.0) * q1) + q2)) / f
    f = f32(f * f32(it))
    rt3 = ((q3 - q0) + f32(3.0) * (q1 - q2)) / f
    a0 = np.array(rt0, dtype=np.float32, copy=True)
    a1 = (rt1 + rt2) + rt3
    a2 = f32(2.0) * rt2 + f32(6.0) * rt3
    a3 = f32(6.0) * rt3
    out = np.empty((q0.shape[0], it + 1, q0.shape[1]), dtype=np.float32)
    for a in range(it + 1):
        out[:, a, :] = a0
        a0 = a0 + a1
        a1 = a1 + a2
        a2 = a2 + a3
    return out


def _sos_curve_control_and_shape_arrays_fast(splines, default_res):
    """Vectorized _curve_control_and_shape_arrays() body; None means use the slow path."""
    try:
        ctrl_chunks = []
        sel_chunks = []
        shape_chunks = []
        edge_chunks = []
        shape_total = 0
        for spline in splines:
            try:
                st = str(getattr(spline, 'type', '') or '')
            except Exception:
                st = ''
            try:
                cyclic = bool(getattr(spline, 'use_cyclic_u', False))
            except Exception:
                cyclic = False
            if st == 'BEZIER':
                co, hl, hr, sel = _sos_curve_bezier_point_arrays(spline)
                nbp = int(co.shape[0])
                if nbp == 0:
                    continue
                ctrl_chunks.append(co)
                sel_chunks.append(sel)
                seg_total = nbp if cyclic and nbp > 1 else max(0, nbp - 1)
                try:
                    local_res = max(1, int(getattr(spline, 'resolution_u', default_res) or default_res))
                except Exception:
                    local_res = default_res
                if seg_total > 0:
                    n = max(2, local_res + 1)
                    idx1 = (np.arange(seg_total, dtype=np.int64) + 1) % nbp
                    samples = _sos_curve_forward_diff_bezier_np(co[:seg_total], hr[:seg_total], hl[idx1], co[idx1], n - 1)
                    shape_chunks.append(samples.reshape(seg_total * n, 3))
                    base = shape_total + np.arange(seg_total, dtype=np.int64) * n
                    e0 = (base[:, None] + np.arange(n - 1, dtype=np.int64)[None, :]).reshape(-1)
                    edge_chunks.append(np.stack((e0, e0 + 1), axis=1))
                    shape_total += seg_total * n
                if nbp == 1 and shape_total == 0:
                    shape_chunks.append(co[:1])
                    shape_total += 1
            else:
                co4, sel = _sos_curve_nurbs_point_arrays(spline)
                npt = int(co4.shape[0])
                if npt == 0:
                    continue
                c64 = co4.astype(np.float64)
                w = c64[:, 3]
                w = np.where(np.abs(w) > 1.0e-12, w, 1.0)
                local = (c64[:, :3] / w[:, None]).astype(np.float32)
                ctrl_chunks.append(local)
                sel_chunks.append(sel)
                shape_chunks.append(local)
                if npt > 1:
                    idx = shape_total + np.arange(npt - 1, dtype=np.int64)
                    edges = np.stack((idx, idx + 1), axis=1)
                    if cyclic:
                        edges = np.concatenate((edges, np.asarray([[shape_total + npt - 1, shape_total]], dtype=np.int64)), axis=0)
                    edge_chunks.append(edges)
                shape_total += npt
        ctrl_va = np.ascontiguousarray(np.concatenate(ctrl_chunks), dtype=np.float32) if ctrl_chunks else np.empty((0, 3), dtype=np.float32)
        selected = np.ascontiguousarray(np.concatenate(sel_chunks), dtype=np.bool_) if sel_chunks else np.empty((0,), dtype=np.bool_)
        shape_va = np.ascontiguousarray(np.concatenate(shape_chunks), dtype=np.float32) if shape_chunks else np.empty((0, 3), dtype=np.float32)
        shape_ei = np.ascontiguousarray(np.concatenate(edge_chunks), dtype=np.int32) if edge_chunks else np.empty((0, 2), dtype=np.int32)
        if shape_ei.size == 0:
            shape_ei = np.empty((0, 2), dtype=np.int32)
        return ctrl_va, selected, shape_va, shape_ei
    except Exception:
        return None


def _curve_data_live_signature(data) -> tuple:
    if data is None:
        return ()
    props = []
    for attr_name in ('dimensions', 'fill_mode', 'resolution_u', 'render_resolution_u', 'bevel_depth', 'bevel_resolution', 'extrude', 'twist_smooth', 'use_path'):
        try:
            value = getattr(data, attr_name)
            if isinstance(value, float):
                value = round(float(value), 6)
            props.append((attr_name, value))
        except Exception:
            pass
    splines_sig = []
    try:
        splines = tuple(getattr(data, 'splines', ()) or ())
    except Exception:
        splines = ()
    for spline in splines:
        try:
            st = str(getattr(spline, 'type', '') or '')
            cyc = bool(getattr(spline, 'use_cyclic_u', False))
            res = int(getattr(spline, 'resolution_u', getattr(data, 'resolution_u', 12)) or 0)
        except Exception:
            st, cyc, res = '', False, 0
        fast_sig = _sos_curve_points_fast_signature(spline, st)
        if fast_sig is not None:
            splines_sig.append((st, cyc, res, fast_sig))
            continue
        points_sig = []
        if st == 'BEZIER':
            try:
                for bp in getattr(spline, 'bezier_points', ()) or ():
                    points_sig.append(_curve_bezier_signature_point(bp))
            except Exception:
                pass
        else:
            try:
                for pt in getattr(spline, 'points', ()) or ():
                    points_sig.append(_curve_point_signature_point(pt))
            except Exception:
                pass
        splines_sig.append((st, cyc, res, tuple(points_sig)))
    return (tuple(props), tuple(splines_sig))


def _sos_curve_live_signature_for_cache(obj, data, prefs=None) -> tuple:
    """Return a conservative Curve cache signature without redundant scans.

    A single-user Curve in Object mode is invalidated by the registered
    depsgraph handler before geometry caches can be reused, so its object dirty
    generation is sufficient.  Shared datablocks and Edit Curve retain the full
    point signature because their user/selection propagation is not reliably
    object-addressable from the RNA-light depsgraph callback.
    """
    try:
        if not _sos_opt_bool(prefs, 'optimization_dirty_generation_cache', False):
            return _curve_data_live_signature(data)
        if str(getattr(obj, 'mode', '') or '') != 'OBJECT':
            return _curve_data_live_signature(data)
        if int(getattr(data, 'users', 0) or 0) != 1:
            return _curve_data_live_signature(data)
        return ('DIRTY_GENERATION', _sos_dirty_generation_for_object(obj))
    except Exception:
        return _curve_data_live_signature(data)


def _curve_append_polyline_edges(verts, edges, points):
    if not points:
        return
    start = len(verts)
    for p in points:
        try:
            verts.append((float(p[0]), float(p[1]), float(p[2])))
        except Exception:
            continue
    count = len(verts) - start
    if count <= 1:
        return
    for i in range(count - 1):
        edges.append((start + i, start + i + 1))


def _curve_control_and_shape_arrays(obj):
    """Return curve control-point and centerline/shape arrays in local space.

    Control points drive vertex/selected-vertex overlay in Edit Curve.  Shape
    edges are sampled from the curve itself, so bevelled curves keep a readable
    centerline instead of drawing every bevel cross-section edge.
    """
    data = getattr(obj, 'data', None)
    if data is None:
        return None
    try:
        splines = tuple(getattr(data, 'splines', ()) or ())
    except Exception:
        splines = ()
    if not splines:
        return None
    ctrl_verts = []
    ctrl_selected = []
    shape_verts = []
    shape_edges = []
    try:
        default_res = max(1, int(getattr(data, 'resolution_u', 12) or 12))
    except Exception:
        default_res = 12
    fast_arrays = _sos_curve_control_and_shape_arrays_fast(splines, default_res)
    if fast_arrays is not None:
        return fast_arrays
    for spline in splines:
        try:
            st = str(getattr(spline, 'type', '') or '')
        except Exception:
            st = ''
        try:
            cyclic = bool(getattr(spline, 'use_cyclic_u', False))
        except Exception:
            cyclic = False
        if st == 'BEZIER':
            try:
                bps = tuple(getattr(spline, 'bezier_points', ()) or ())
            except Exception:
                bps = ()
            if not bps:
                continue
            base_idx = len(ctrl_verts)
            for bp in bps:
                try:
                    co = getattr(bp, 'co', None)
                    ctrl_verts.append((float(co[0]), float(co[1]), float(co[2])))
                except Exception:
                    ctrl_verts.append((0.0, 0.0, 0.0))
                try:
                    ctrl_selected.append(bool(getattr(bp, 'select_control_point', False)))
                except Exception:
                    ctrl_selected.append(False)
            # Sample the actual curve shape through Bezier interpolation.  This
            # keeps the edge overlay on the visible curve shape rather than on
            # the coarse control polygon.
            seg_total = len(bps) if cyclic and len(bps) > 1 else max(0, len(bps) - 1)
            try:
                local_res = max(1, int(getattr(spline, 'resolution_u', default_res) or default_res))
            except Exception:
                local_res = default_res
            for i in range(seg_total):
                p0 = bps[i]
                p1 = bps[(i + 1) % len(bps)]
                try:
                    from mathutils import geometry
                    samples = list(geometry.interpolate_bezier(p0.co, p0.handle_right, p1.handle_left, p1.co, max(2, local_res + 1)))
                    _curve_append_polyline_edges(shape_verts, shape_edges, samples)
                except Exception:
                    _curve_append_polyline_edges(shape_verts, shape_edges, [p0.co, p1.co])
            # If a single-point curve exists, still expose the control point.
            if len(bps) == 1 and len(shape_verts) == 0:
                try:
                    _curve_append_polyline_edges(shape_verts, shape_edges, [bps[0].co])
                except Exception:
                    pass
        else:
            try:
                pts = tuple(getattr(spline, 'points', ()) or ())
            except Exception:
                pts = ()
            if not pts:
                continue
            local_points = []
            for pt in pts:
                co = _curve_point_local_co(pt)
                ctrl_verts.append(co)
                local_points.append(co)
                try:
                    ctrl_selected.append(bool(getattr(pt, 'select', False)))
                except Exception:
                    ctrl_selected.append(False)
            start = len(shape_verts)
            shape_verts.extend(local_points)
            for i in range(max(0, len(local_points) - 1)):
                shape_edges.append((start + i, start + i + 1))
            if cyclic and len(local_points) > 1:
                shape_edges.append((start + len(local_points) - 1, start))
    ctrl_va = np.asarray(ctrl_verts, dtype=np.float32) if ctrl_verts else np.empty((0, 3), dtype=np.float32)
    selected = np.asarray(ctrl_selected, dtype=np.bool_) if ctrl_selected else np.empty((0,), dtype=np.bool_)
    shape_va = np.asarray(shape_verts, dtype=np.float32) if shape_verts else np.empty((0, 3), dtype=np.float32)
    shape_ei = np.asarray(shape_edges, dtype=np.int32) if shape_edges else np.empty((0, 2), dtype=np.int32)
    return ctrl_va, selected, shape_va, shape_ei


def _curve_evaluated_mesh_arrays(obj, depsgraph=None):
    if obj is None:
        return None
    eo = None
    me = None
    try:
        if depsgraph is None:
            try:
                depsgraph = bpy.context.evaluated_depsgraph_get()
            except Exception:
                depsgraph = None
        if depsgraph is not None:
            eo = obj.evaluated_get(depsgraph)
            try:
                me = eo.to_mesh(preserve_all_data_layers=False, depsgraph=depsgraph)
            except Exception:
                try:
                    me = eo.to_mesh()
                except Exception:
                    me = None
        if me is None:
            return None
        try:
            vc = len(getattr(me, 'vertices', ()) or ())
        except Exception:
            vc = 0
        if vc <= 0:
            return None
        va = np.empty(vc * 3, dtype=np.float32)
        me.vertices.foreach_get('co', va)
        va = va.reshape(-1, 3).copy()
        try:
            ec = len(getattr(me, 'edges', ()) or ())
        except Exception:
            ec = 0
        if ec > 0:
            ei = np.empty(ec * 2, dtype=np.int32)
            me.edges.foreach_get('vertices', ei)
            ei = ei.reshape(-1, 2).copy()
        else:
            ei = np.empty((0, 2), dtype=np.int32)
        try:
            me.calc_loop_triangles()
        except Exception:
            pass
        try:
            tc = len(getattr(me, 'loop_triangles', ()) or ())
        except Exception:
            tc = 0
        if tc > 0:
            ti = np.empty(tc * 3, dtype=np.int32)
            me.loop_triangles.foreach_get('vertices', ti)
            ti = ti.reshape(-1, 3).copy()
        else:
            ti = np.empty((0, 3), dtype=np.int32)
        return {'verts': va, 'edges': ei, 'tris': ti, 'has_render_mesh': bool(len(ti) > 0)}
    except Exception:
        return None
    finally:
        try:
            if eo is not None:
                eo.to_mesh_clear()
        except Exception:
            pass


def _curve_projected_points(obj, verts, region, rv3d):
    return _lattice_projected_points(obj, verts, region, rv3d)


def _curve_pick_distance_sq(obj, verts, edges, region, rv3d, mx, my) -> float | None:
    return _lattice_pick_distance_sq(obj, verts, edges, region, rv3d, mx, my)


def _pick_curve_shape_hover_object(context, prefs, region, rv3d, mx, my, *, exclude_selected: bool = True, allowed_names=None) -> str:
    if not bool(getattr(prefs, 'include_curve_shape_overlay', True)):
        return ''
    if mx == -1 or my == -1 or region is None or rv3d is None:
        return ''
    allowed_names = set(allowed_names or ()) if allowed_names is not None else None
    try:
        objects = tuple(getattr(context, 'visible_objects', ()) or ())
    except Exception:
        objects = ()
    if not objects:
        try:
            objects = tuple(getattr(getattr(context, 'scene', None), 'objects', ()) or ())
        except Exception:
            objects = ()
    try:
        threshold = max(float(get_csdt_radius('VERT') or 0.0), float(get_csdt_radius('EDGE') or 0.0), 12.0)
    except Exception:
        threshold = 12.0
    threshold_sq = threshold * threshold
    best_name = ''
    best_dist = None
    for obj in objects:
        try:
            if not _is_curve_object(obj):
                continue
            # Polygonal curves can be found by scene.ray_cast; this fallback is
            # for line-only curves where Blender has no face target.
            if _sos_curve_has_render_mesh_settings(obj):
                continue
            if allowed_names is not None and obj.name not in allowed_names:
                continue
            if not _sos_obj_supported_objmode(obj, prefs):
                continue
            if exclude_selected and bool(obj.select_get()):
                continue
            if bool(obj.hide_get()) or bool(getattr(obj, 'hide_select', False)) or not _sos_object_visible_in_view3d(context, obj, region, rv3d):
                continue
            arrays = _curve_control_and_shape_arrays(obj)
            if not arrays:
                continue
            ctrl_va, _selected, shape_va, shape_ei = arrays
            verts = shape_va if shape_va is not None and len(shape_va) > 0 else ctrl_va
            edges = shape_ei if shape_ei is not None else np.empty((0, 2), dtype=np.int32)
            dist_sq = _curve_pick_distance_sq(obj, verts, edges, region, rv3d, mx, my)
            if dist_sq is None or dist_sq > threshold_sq:
                continue
            if best_dist is None or dist_sq < best_dist:
                best_dist = dist_sq
                best_name = obj.name
        except Exception:
            continue
    return best_name


def _curve_element_hover(obj, ctrl_verts, shape_verts, shape_edges, mesh_verts, mesh_edges, mesh_tris, region, rv3d, mx, my, *, use_render_mesh: bool) -> tuple[int, int, int]:
    if mx == -1 or my == -1 or region is None or rv3d is None:
        return -1, -1, -1
    if use_render_mesh and mesh_verts is not None and len(mesh_verts) > 0:
        verts = mesh_verts
        edges = mesh_edges if mesh_edges is not None else np.empty((0, 2), dtype=np.int32)
    else:
        verts = ctrl_verts if ctrl_verts is not None else np.empty((0, 3), dtype=np.float32)
        edges = shape_edges if shape_edges is not None else np.empty((0, 2), dtype=np.int32)
    projected = _curve_projected_points(obj, verts, region, rv3d)
    if not projected:
        return -1, -1, -1
    try:
        v_threshold = max(float(get_csdt_radius('VERT') or 0.0), 8.0)
    except Exception:
        v_threshold = 8.0
    try:
        e_threshold = max(float(get_csdt_radius('EDGE') or 0.0), 9.0)
    except Exception:
        e_threshold = 9.0
    best_v = -1
    best_vd = v_threshold * v_threshold
    for i, p2 in enumerate(projected):
        if p2 is None:
            continue
        d = (float(mx) - p2[0]) ** 2 + (float(my) - p2[1]) ** 2
        if d < best_vd:
            best_vd = d
            best_v = int(i)
    if best_v != -1:
        return best_v, -1, -1

    best_e = -1
    best_ed = e_threshold * e_threshold
    try:
        edge_iter = edges.tolist() if hasattr(edges, 'tolist') else edges
    except Exception:
        edge_iter = ()
    edge_projected = projected
    if not use_render_mesh and shape_verts is not None and len(shape_verts) > 0:
        edge_projected = _curve_projected_points(obj, shape_verts, region, rv3d)
    for i, edge in enumerate(edge_iter):
        try:
            a, b = int(edge[0]), int(edge[1])
            pa = edge_projected[a]
            pb = edge_projected[b]
        except Exception:
            continue
        if pa is None or pb is None:
            continue
        d = _screen_segment_distance_sq(mx, my, pa[0], pa[1], pb[0], pb[1])
        if d < best_ed:
            best_ed = d
            best_e = int(i)
    if best_e != -1:
        return -1, best_e, -1

    if use_render_mesh and mesh_verts is not None and mesh_tris is not None and len(mesh_tris) > 0:
        try:
            ro_world, rd_world = _sos_view_ray_clip_stable(region, rv3d, (mx, my))
            inv_mw = obj.matrix_world.inverted()
            ro = inv_mw @ ro_world
            rd = inv_mw.to_3x3() @ rd_world
            try:
                rd.normalize()
            except Exception:
                pass
            from mathutils import geometry
            best_f = -1
            best_t = None
            for i, tri in enumerate(mesh_tris):
                try:
                    v0 = Vector(mesh_verts[int(tri[0])])
                    v1 = Vector(mesh_verts[int(tri[1])])
                    v2 = Vector(mesh_verts[int(tri[2])])
                    hit = geometry.intersect_ray_tri(v0, v1, v2, rd, ro, False)
                    if hit is None:
                        continue
                    d = float((hit - ro).length_squared)
                    if best_t is None or d < best_t:
                        best_t = d
                        best_f = int(i)
                except Exception:
                    continue
            if best_f != -1:
                return -1, -1, best_f
        except Exception:
            pass
    return -1, -1, -1

def _iter_lattice_user_object_names(lattice) -> tuple[str, ...]:
    # Same safety rule as _iter_mesh_user_object_names: never scan Object.data
    # from depsgraph callbacks.  Lattice user updates are handled by conservative
    # cache invalidation.
    return ()


def _modifier_viewport_signature(obj) -> tuple:
    try:
        modifiers = getattr(obj, 'modifiers', None)
    except Exception:
        modifiers = None
    if not modifiers:
        return ()
    signature = []
    for mod in modifiers:
        try:
            signature.append((
                str(getattr(mod, 'name', '') or ''),
                str(getattr(mod, 'type', '') or ''),
                bool(getattr(mod, 'show_viewport', True)),
                bool(getattr(mod, 'show_in_editmode', False)) if hasattr(mod, 'show_in_editmode') else None,
                bool(getattr(mod, 'show_on_cage', False)) if hasattr(mod, 'show_on_cage') else None,
                bool(getattr(mod, 'show_render', True)) if hasattr(mod, 'show_render') else None,
            ))
        except Exception:
            continue
    return tuple(signature)


def _sos_simple_rna_value_signature(value):
    """Return a small hashable representation for simple RNA values.

    This is used only to invalidate evaluated edit-mode face batches.  The
    existing overlay cache already tracks edit-mesh selection and topology; this
    helper adds modifier-parameter changes such as Subdivision Surface levels,
    Bevel width, Mirror axes, or Boolean operation so the face overlay cannot
    stay on a stale evaluated mesh after the user edits a modifier.
    """
    try:
        if isinstance(value, bool):
            return bool(value)
        if isinstance(value, int):
            return int(value)
        if isinstance(value, float):
            return round(float(value), 8)
        if isinstance(value, str):
            return str(value)
        if isinstance(value, (tuple, list)) and len(value) <= 16:
            out = []
            for item in value:
                sig = _sos_simple_rna_value_signature(item)
                if sig is None:
                    return None
                out.append(sig)
            return tuple(out)
        if hasattr(value, '__len__') and hasattr(value, '__iter__'):
            try:
                if len(value) <= 16:
                    out = []
                    for item in value:
                        sig = _sos_simple_rna_value_signature(item)
                        if sig is None:
                            return None
                        out.append(sig)
                    return tuple(out)
            except Exception:
                return None
    except Exception:
        return None
    return None


def _modifier_evaluated_runtime_signature(obj) -> tuple:
    """Modifier signature used for evaluated edit-mode face overlay caching.

    The face-only evaluated overlay must update when a visible edit-mode
    modifier changes, not only when mesh topology/selection changes.  The
    signature deliberately records simple RNA values for the relevant modifiers
    while skipping pointers, collections, and read-only runtime data.
    """
    try:
        modifiers = getattr(obj, 'modifiers', None)
    except Exception:
        modifiers = None
    if not modifiers:
        return ()
    result = []
    for mod in modifiers:
        try:
            show_viewport = bool(getattr(mod, 'show_viewport', True))
            show_edit = bool(getattr(mod, 'show_in_editmode', False)) if hasattr(mod, 'show_in_editmode') else False
            base = [
                str(getattr(mod, 'name', '') or ''),
                str(getattr(mod, 'type', '') or ''),
                show_viewport,
                show_edit,
                bool(getattr(mod, 'show_on_cage', False)) if hasattr(mod, 'show_on_cage') else None,
            ]
            values = []
            if show_viewport and show_edit:
                try:
                    props = tuple(getattr(getattr(mod, 'bl_rna', None), 'properties', ()) or ())
                except Exception:
                    props = ()
                for prop in props:
                    try:
                        ident = str(getattr(prop, 'identifier', '') or '')
                    except Exception:
                        continue
                    if not ident or ident in {'rna_type', 'name'}:
                        continue
                    try:
                        if bool(getattr(prop, 'is_readonly', False)):
                            continue
                    except Exception:
                        pass
                    try:
                        value = getattr(mod, ident)
                    except Exception:
                        continue
                    sig = _sos_simple_rna_value_signature(value)
                    if sig is not None:
                        values.append((ident, sig))
            result.append(tuple(base) + (tuple(values),))
        except Exception:
            continue
    return tuple(result)


def _has_visible_edit_mode_modifier(obj) -> bool:
    """Return True when Blender can show a modifier result while editing.

    This follows the per-modifier viewport flags used by Blender's
    "Show in Edit Mode" switch.  The helper intentionally does not require
    "show_on_cage": that switch controls cage display, while the user-facing
    request is tied to the edited viewport modifier result itself.
    """
    try:
        modifiers = getattr(obj, 'modifiers', None)
    except Exception:
        modifiers = None
    if not modifiers:
        return False
    for mod in modifiers:
        try:
            if bool(getattr(mod, 'show_viewport', True)) and bool(getattr(mod, 'show_in_editmode', False)):
                return True
        except Exception:
            continue
    return False


def _use_evaluated_edit_mode_face_overlay(obj, prefs) -> bool:
    try:
        if not bool(getattr(prefs, 'use_evaluated_edit_mode_face_overlay', True)):
            return False
    except Exception:
        return False
    try:
        if getattr(obj, 'type', None) != 'MESH':
            return False
    except Exception:
        return False
    return _has_visible_edit_mode_modifier(obj)


def _build_edit_face_state_mapper(source_bm):
    """Return a nearest-face mapper for edit-cage face selection and hidden state.

    Some evaluated edit-mode meshes report generated polygons as selected even
    when the original edit cage has no selected faces.  Mapping evaluated
    polygon centers back to the nearest edit-cage face keeps face selected / hide
    feedback consistent while the normal face fill follows modifier geometry.
    """
    if source_bm is None:
        return None
    try:
        source_bm.faces.ensure_lookup_table()
        source_bm.faces.index_update()
        count = len(source_bm.faces)
    except Exception:
        return None
    if count <= 0:
        return None
    try:
        kd = KDTree(count)
        selected = []
        hidden = []
        for index, face in enumerate(source_bm.faces):
            try:
                center = face.calc_center_median()
            except Exception:
                try:
                    center = sum((v.co for v in face.verts), Vector()) / max(1, len(face.verts))
                except Exception:
                    center = Vector((0.0, 0.0, 0.0))
            kd.insert(center, index)
            selected.append(bool(getattr(face, 'select', False)))
            hidden.append(bool(getattr(face, 'hide', False)))
        kd.balance()
        return kd, tuple(selected), tuple(hidden)
    except Exception:
        return None


def _evaluated_polygon_centers(me, coords, poly_count: int):
    centers = np.zeros((poly_count, 3), dtype=np.float32)
    if poly_count <= 0:
        return centers
    try:
        for poly in me.polygons:
            index = int(poly.index)
            verts = tuple(int(v) for v in poly.vertices)
            if verts:
                centers[index] = coords[list(verts)].mean(axis=0)
    except Exception:
        pass
    return centers




def _evaluated_edit_face_needs_source_mapping(source_bm, separate_selected: bool) -> bool:
    """Return True only when edit-cage hidden/selected state must be mapped.

    Modifier-evaluated face fill normally draws every evaluated triangle.  Building
    a KDTree and remapping every evaluated polygon is the expensive part of the
    edit-mode modifier path, so skip it whenever the edit cage has no hidden faces
    and selected faces do not need to be filtered.
    """
    if source_bm is None:
        return False
    try:
        source_bm.faces.ensure_lookup_table()
        for face in source_bm.faces:
            try:
                if bool(getattr(face, 'hide', False)):
                    return True
                if bool(separate_selected) and bool(getattr(face, 'select', False)):
                    return True
            except Exception:
                return True
        return False
    except Exception:
        return True


def _evaluated_edit_face_index_array(me, va, tri_indices, pi, tri_count: int, poly_count: int, source_bm=None, separate_selected: bool=True):
    if tri_count <= 0 or poly_count <= 0:
        return None
    try:
        tri_indices_np = np.asarray(tri_indices, dtype=np.int32)
    except Exception:
        return None
    if tri_indices_np.size <= 0:
        return None
    if not _evaluated_edit_face_needs_source_mapping(source_bm, separate_selected):
        return tri_indices_np.copy()

    hide = np.zeros(poly_count, dtype=bool)
    selected = np.zeros(poly_count, dtype=bool)
    mapper = _build_edit_face_state_mapper(source_bm)
    if mapper is not None:
        kd, source_selected, source_hidden = mapper
        centers = _evaluated_polygon_centers(me, va, poly_count)
        for poly_index in range(poly_count):
            source_index = -1
            try:
                center = centers[poly_index]
                _co, nearest_index, _dist = kd.find(Vector((float(center[0]), float(center[1]), float(center[2]))))
                source_index = int(nearest_index)
            except Exception:
                pass
            if bool(separate_selected) and 0 <= source_index < len(source_selected):
                selected[poly_index] = bool(source_selected[source_index])
            if 0 <= source_index < len(source_hidden):
                hide[poly_index] = bool(source_hidden[source_index])
    else:
        try:
            me.polygons.foreach_get('hide', hide)
        except Exception:
            pass
        if bool(separate_selected):
            try:
                me.polygons.foreach_get('select', selected)
            except Exception:
                try:
                    attr = getattr(me, 'attributes', {}).get('.select_poly')
                    if attr is not None and len(attr.data) >= poly_count:
                        attr.data.foreach_get('value', selected)
                except Exception:
                    pass

    try:
        poly_indices = np.asarray(pi, dtype=np.int32)
        if len(poly_indices) != tri_count:
            return None
        valid = (poly_indices >= 0) & (poly_indices < poly_count)
        mask = valid.copy()
        if np.any(mask):
            safe_poly_indices = np.where(valid, poly_indices, 0)
            mask &= ~hide[safe_poly_indices]
            if bool(separate_selected):
                mask &= ~selected[safe_poly_indices]
        if not np.any(mask):
            return None
        return tri_indices_np[mask].astype(np.int32, copy=True)
    except Exception:
        base_indices = []
        for tri_index in range(tri_count):
            poly_index = int(pi[tri_index]) if tri_index < len(pi) else -1
            if poly_index < 0 or poly_index >= poly_count:
                continue
            if bool(hide[poly_index]):
                continue
            if bool(separate_selected) and bool(selected[poly_index]):
                continue
            tri = tri_indices_np[tri_index]
            base_indices.append((int(tri[0]), int(tri[1]), int(tri[2])))
        if not base_indices:
            return None
        return np.asarray(base_indices, dtype=np.int32)

def _sos_eval_face_cache_key(obj):
    try:
        obj_ptr = int(getattr(obj, 'as_pointer', lambda: 0)() or 0)
    except Exception:
        obj_ptr = 0
    try:
        data_ptr = int(getattr(getattr(obj, 'data', None), 'as_pointer', lambda: 0)() or 0)
    except Exception:
        data_ptr = 0
    return ('EDIT_EVAL_CPU', str(getattr(obj, 'name', '') or ''), obj_ptr, data_ptr)


def _sos_eval_face_entry(obj):
    try:
        entry = _sos_eval_face_cpu_cache.get(_sos_eval_face_cache_key(obj))
        return entry if isinstance(entry, dict) else None
    except Exception:
        return None


def _sos_eval_face_entry_is_drawable(obj) -> bool:
    """Return True for either a CPU-backed or direct-seed evaluated batch."""
    entry = _sos_eval_face_entry(obj)
    if not isinstance(entry, dict):
        return False
    try:
        if entry.get('batch') is not None:
            return True
        data = entry.get('data')
        if not isinstance(data, dict):
            return False
        verts = data.get('verts')
        indices = data.get('indices')
        return bool(verts is not None and indices is not None and len(indices) > 0)
    except Exception:
        return False


def _sos_latest_evaluated_face_batch(obj, shader):
    """Return the latest completed modifier-result face batch, if available."""
    entry = _sos_eval_face_entry(obj)
    if not isinstance(entry, dict):
        return None
    try:
        batch = entry.get('batch')
        if batch is None and shader is not None:
            batch = _sos_make_eval_face_batch_from_cpu(entry, shader)
        return batch
    except Exception:
        return None


def _sos_eval_face_rebuild_interval(prefs) -> float:
    try:
        if not _sos_opt_bool(prefs, 'optimization_throttle_evaluated_face_rebuild', False):
            return 0.0
    except Exception:
        return 0.0
    try:
        return max(0.01, min(2.0, float(getattr(prefs, 'optimization_evaluated_face_rebuild_interval', 0.10) or 0.10)))
    except Exception:
        return 0.10


def _build_evaluated_edit_face_cpu_data(obj, depsgraph, *, separate_selected=True, source_bm=None, source_live_signature=None, force_sync=False):
    """Build CPU-side evaluated edit-mode face data outside/without GPU batch work.

    Optimized for the common edit-visible-modifier case: when selected faces do
    not need to be separated and no edit-cage faces are hidden, all evaluated
    loop triangles are passed through with vectorized numpy data and no KDTree
    face-state remapping.  Hidden/selected remapping is used only when it can
    actually change the returned triangles.
    """
    if obj is None or depsgraph is None:
        return None
    eo = None
    me = None
    try:
        if source_bm is not None:
            _sync_edit_mesh_to_evaluated_modifier_stack(obj, depsgraph, source_bm=source_bm, live_signature=source_live_signature, force=bool(force_sync))
        eo = obj.evaluated_get(depsgraph)
        try:
            me = eo.to_mesh(preserve_all_data_layers=True, depsgraph=depsgraph)
        except Exception:
            try:
                me = eo.to_mesh(preserve_all_data_layers=False, depsgraph=depsgraph)
            except Exception:
                try:
                    me = eo.to_mesh()
                except Exception:
                    me = None
        if me is None:
            return None
        vc = len(getattr(me, 'vertices', ()) or ())
        if vc <= 0:
            return None
        try:
            me.calc_loop_triangles()
        except Exception:
            pass
        tri_count = len(getattr(me, 'loop_triangles', ()) or ())
        poly_count = len(getattr(me, 'polygons', ()) or ())
        if tri_count <= 0 or poly_count <= 0:
            return None

        va = np.empty(vc * 3, dtype=np.float32)
        me.vertices.foreach_get('co', va)
        va = va.reshape(-1, 3).copy()

        ti = np.empty(tri_count * 3, dtype=np.int32)
        me.loop_triangles.foreach_get('vertices', ti)
        tri_indices = ti.reshape(-1, 3)

        source_has_hidden = False
        source_has_selected = False
        if source_bm is not None:
            try:
                source_bm.faces.ensure_lookup_table()
                for face in source_bm.faces:
                    if bool(getattr(face, 'hide', False)):
                        source_has_hidden = True
                    if separate_selected and bool(getattr(face, 'select', False)):
                        source_has_selected = True
                    if source_has_hidden and (source_has_selected or not separate_selected):
                        break
            except Exception:
                source_has_hidden = True

        if source_bm is not None and not source_has_hidden and (not separate_selected or not source_has_selected):
            # Normal modifier-evaluated face overlay path: no hidden edit faces
            # and selected faces are intentionally kept on the editable cage.
            return {
                'verts': va,
                'indices': tri_indices.copy(),
                'tri_count': int(tri_count),
                'vert_count': int(vc),
            }

        pi = np.empty(tri_count, dtype=np.int32)
        try:
            me.loop_triangles.foreach_get('polygon_index', pi)
        except Exception:
            pi.fill(-1)

        hide = np.zeros(poly_count, dtype=bool)
        selected = np.zeros(poly_count, dtype=bool)
        mapper = None
        if source_bm is not None and (source_has_hidden or separate_selected):
            mapper = _build_edit_face_state_mapper(source_bm)
        if mapper is not None:
            kd, source_selected, source_hidden = mapper
            centers = _evaluated_polygon_centers(me, va, poly_count)
            for poly_index in range(poly_count):
                source_index = -1
                try:
                    _co, nearest_index, _dist = kd.find(Vector((float(centers[poly_index][0]), float(centers[poly_index][1]), float(centers[poly_index][2]))))
                    source_index = int(nearest_index)
                except Exception:
                    pass
                if 0 <= source_index < len(source_selected):
                    selected[poly_index] = bool(source_selected[source_index])
                if 0 <= source_index < len(source_hidden):
                    hide[poly_index] = bool(source_hidden[source_index])
        else:
            try:
                me.polygons.foreach_get('hide', hide)
            except Exception:
                pass
            if separate_selected:
                try:
                    me.polygons.foreach_get('select', selected)
                except Exception:
                    try:
                        attr = getattr(me, 'attributes', {}).get('.select_poly')
                        if attr is not None and len(attr.data) >= poly_count:
                            attr.data.foreach_get('value', selected)
                    except Exception:
                        pass

        valid_poly = np.ones(poly_count, dtype=bool)
        if hide.any():
            valid_poly &= ~hide
        if separate_selected and selected.any():
            valid_poly &= ~selected
        valid_tri = (pi >= 0) & (pi < poly_count)
        try:
            valid_tri &= valid_poly[np.clip(pi, 0, max(0, poly_count - 1))]
        except Exception:
            valid_tri = np.asarray([False] * tri_count, dtype=bool)
        if not bool(valid_tri.any()):
            return None
        indices = tri_indices[valid_tri].astype(np.int32, copy=True)
        return {
            'verts': va,
            'indices': indices,
            'tri_count': int(len(indices)),
            'vert_count': int(vc),
        }
    except Exception:
        return None
    finally:
        try:
            if eo is not None:
                eo.to_mesh_clear()
        except Exception:
            pass


def _sos_make_eval_face_batch_from_cpu(entry, shader):
    try:
        if not isinstance(entry, dict):
            return None
        batch = entry.get('batch')
        if batch is not None:
            return batch
        data = entry.get('data')
        if not isinstance(data, dict):
            return None
        va = data.get('verts')
        indices = data.get('indices')
        if va is None or indices is None or len(indices) <= 0:
            return None
        batch = batch_for_shader(shader, 'TRIS', {'pos': va}, indices=indices)
        entry['batch'] = batch
        return batch
    except Exception:
        try:
            entry['batch'] = None
        except Exception:
            pass
        return None


def _sos_pin_direct_evaluated_face_batch(obj, result) -> None:
    """Keep the first drawable evaluated batch until the timer replaces it.

    The direct seed may reflect Blender's most recently available evaluated mesh,
    so it is deliberately stored with a non-matching state.  The next redraw then
    queues a fresh synchronized rebuild while reusing this modifier-result batch;
    it cannot be mistaken for a current result or cause repeated draw-time mesh
    extraction.
    """
    try:
        if obj is None or not isinstance(result, dict):
            return
        batch = result.get('batch_tris')
        if batch is None:
            return
        key = _sos_eval_face_cache_key(obj)
        _sos_eval_face_cpu_cache[key] = {
            'state': ('DIRECT_EVALUATED_SEED',),
            'data': result.get('cpu_data') if isinstance(result.get('cpu_data'), dict) else None,
            'batch': batch,
            'created': time.time(),
            'direct_seed': True,
        }
    except Exception:
        pass


def _sos_eval_face_source_total(source_live_signature) -> int:
    """Return the live edit-mesh element count encoded in a geometry signature."""
    try:
        if isinstance(source_live_signature, (tuple, list)):
            sig = tuple(source_live_signature)
            if len(sig) >= 5 and isinstance(sig[0], str) and sig[0] in {'DIRTY_GENERATION', 'LIVE_SIG_BUDGET_FALLBACK'}:
                return int(sig[2] or 0) + int(sig[3] or 0) + int(sig[4] or 0)
            if len(sig) >= 3:
                return int(sig[0] or 0) + int(sig[1] or 0) + int(sig[2] or 0)
    except Exception:
        pass
    return 0



def _sos_eval_face_state_rebased_to_current_dirty_generation(state, obj):
    """Return an evaluated-face cache state that matches post-sync dirty generation.

    Deferred evaluated-face rebuilds may call update_from_editmode()/depsgraph.update(),
    which legitimately bumps the object's dirty generation through Blender's normal
    depsgraph handler.  The CPU data was built after that sync, so the cache state
    must be rebased to the current generation; otherwise the next draw considers
    the fresh evaluated result stale and falls back to the edit cage forever.
    """
    try:
        if not isinstance(state, tuple) or len(state) < 2:
            return state
        live_sig = state[1]
        if not isinstance(live_sig, tuple) or len(live_sig) < 5:
            return state
        tag = str(live_sig[0] or '')
        if tag not in {'DIRTY_GENERATION', 'LIVE_SIG_BUDGET_FALLBACK'}:
            return state
        current_gen = _sos_dirty_generation_for_object(obj)
        if tag == 'DIRTY_GENERATION':
            rebased_sig = (live_sig[0], current_gen, live_sig[2], live_sig[3], live_sig[4], *live_sig[5:])
        else:
            rebased_sig = (live_sig[0], current_gen, live_sig[2], live_sig[3], live_sig[4], *live_sig[5:])
        return (state[0], rebased_sig, *state[2:])
    except Exception:
        return state


def _sos_eval_face_force_sync_safe(source_live_signature=None, prefs=None) -> bool:
    """Whether the deferred evaluated-face rebuild may flush edit data.

    The draw callback never calls update_from_editmode() directly.  The timer can
    safely flush an idle edit mesh after Blender has left transient modal or
    topology-mutating states.  Live-transform refresh remains size bounded so a
    dense mesh cannot force an expensive depsgraph update on every motion step.
    Once the transform ends, the queued idle rebuild is allowed to synchronize
    any mesh size exactly once and replace the stale modifier-result buffer.
    """
    try:
        total = _sos_eval_face_source_total(source_live_signature)
        if total <= 0:
            return False
    except Exception:
        return False
    try:
        ctx = getattr(bpy, 'context', None)
        transform_live = bool(_sos_edit_transform_modal_active(ctx, prefs))
        if transform_live and total > _SOS_EVALUATED_EDIT_IMMEDIATE_ELEMENT_LIMIT:
            return False
        # Active transform is the only modal state where forced evaluated sync is
        # required for correctness.  Other edit mutation guards still win.
        if not transform_live:
            if _sos_edit_mesh_rebuild_deferred_active():
                return False
            if _sos_edit_mesh_mutation_operator_guard_active(ctx):
                return False
        if _sos_edit_overlay_circuit_breaker_active():
            return False
    except Exception:
        return False
    return True


def _sos_eval_face_rebuild_timer():
    global _sos_eval_face_rebuild_timer_active
    try:
        if not _sos_eval_face_rebuild_queue:
            _sos_eval_face_rebuild_timer_active = False
            return None
        now = time.time()
        ready_key = None
        next_due = None
        for key, item in list(_sos_eval_face_rebuild_queue.items()):
            due = float(item.get('due', 0.0) or 0.0)
            if due <= now:
                ready_key = key
                break
            next_due = due if next_due is None else min(next_due, due)
        if ready_key is None:
            return max(0.01, min(0.20, float(next_due or (now + 0.05)) - now))
        _timer_ctx = getattr(bpy, 'context', None)
        pending_item = _sos_eval_face_rebuild_queue.get(ready_key) or {}
        live_transform_refresh = bool(
            pending_item.get('live_motion', False)
            and pending_item.get('force_sync', False)
        )
        if (not live_transform_refresh) and (
            _sos_edit_mesh_rebuild_deferred_active()
            or _sos_edit_mesh_mutation_operator_guard_active(_timer_ctx)
        ):
            return 0.05
        item = _sos_eval_face_rebuild_queue.pop(ready_key, None)
        if not item:
            return 0.01 if _sos_eval_face_rebuild_queue else None
        obj_name = str(item.get('obj_name', '') or '')
        obj = None
        try:
            obj = bpy.data.objects.get(obj_name)
        except Exception:
            obj = None
        if obj is None:
            _sos_eval_face_cpu_cache.pop(ready_key, None)
        else:
            try:
                if getattr(obj, 'type', None) == 'MESH' and getattr(obj, 'mode', None) == 'EDIT':
                    depsgraph = bpy.context.evaluated_depsgraph_get()
                    bm = None
                    try:
                        bm = bmesh.from_edit_mesh(obj.data)
                        bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
                    except Exception:
                        bm = None
                    _eval_build_started = time.perf_counter()
                    data = _build_evaluated_edit_face_cpu_data(
                        obj,
                        depsgraph,
                        separate_selected=False,
                        source_bm=bm,
                        source_live_signature=item.get('live_signature'),
                        force_sync=bool(item.get('force_sync', False)),
                    )
                    try:
                        _sos_eval_face_last_build_duration[ready_key] = max(0.0, time.perf_counter() - _eval_build_started)
                    except Exception:
                        pass
                    if data is not None:
                        state_for_cache = _sos_eval_face_state_rebased_to_current_dirty_generation(item.get('state'), obj)
                        _sos_eval_face_cpu_cache[ready_key] = {
                            'state': state_for_cache,
                            'data': data,
                            'batch': None,
                            'created': time.time(),
                        }
                        _sos_eval_face_last_rebuild_time[ready_key] = time.time()
                        # Evaluated faces are a separate draw layer.  Do not
                        # invalidate/rebuild all edit edges, vertices, selection and
                        # diagnostics merely to swap this face buffer; cached edit
                        # batches pick up the newest evaluated batch on the next draw.
                        try:
                            tag_view3d_redraw(bpy.context)
                        except Exception:
                            pass
            except Exception:
                pass
        if _sos_eval_face_rebuild_queue:
            return 0.01
    except Exception:
        pass
    _sos_eval_face_rebuild_timer_active = False
    return None


def _sos_queue_eval_face_rebuild(obj, state, prefs=None, *, live_signature=None, force: bool=False, live_motion: bool=False) -> None:
    global _sos_eval_face_rebuild_timer_active
    if obj is None:
        return
    try:
        src_sig = live_signature
        if src_sig is None and isinstance(state, tuple) and len(state) > 1:
            src_sig = state[1]
    except Exception:
        src_sig = live_signature
    # Large edit meshes are queued too.  They refresh at a slower adaptive
    # cadence while the last completed modifier-result buffer remains visible.
    key = _sos_eval_face_cache_key(obj)
    now = time.time()
    interval = _sos_eval_face_rebuild_interval(prefs)
    try:
        last = float(_sos_eval_face_last_rebuild_time.get(key, 0.0) or 0.0)
    except Exception:
        last = 0.0
    if live_motion:
        # Refresh actively edited modifier results at an adaptive cadence.  A
        # hard 60 Hz depsgraph flush can saturate Blender on subdivision-heavy
        # meshes, so pace the next build by both a 30 Hz ceiling and the measured
        # cost of the previous build.  The last evaluated batch remains visible
        # between refreshes, so pacing never causes a cage-face flash.
        try:
            build_cost = max(0.0, float(_sos_eval_face_last_build_duration.get(key, 0.0) or 0.0))
        except Exception:
            build_cost = 0.0
        source_total = _sos_eval_face_source_total(src_sig)
        if source_total <= 12000:
            size_interval = 1.0 / 45.0
        elif source_total <= 50000:
            size_interval = 1.0 / 30.0
        elif source_total <= 120000:
            size_interval = 1.0 / 20.0
        else:
            size_interval = 1.0 / 12.0
        live_interval = max(size_interval, min(0.25, build_cost * 1.20))
        if interval > 0.0:
            live_interval = max(live_interval, interval)
        due = max(now, last + live_interval)
    else:
        due = now if force or interval <= 0.0 else max(now, last + interval)
    try:
        existing = _sos_eval_face_rebuild_queue.get(key)
        if existing and existing.get('state') == state and float(existing.get('due', 0.0) or 0.0) <= due:
            return
    except Exception:
        pass
    _sos_eval_face_rebuild_queue[key] = {
        'obj_name': str(getattr(obj, 'name', '') or ''),
        'state': state,
        'live_signature': live_signature,
        'force_sync': bool(force),
        'live_motion': bool(live_motion),
        'due': due,
    }
    if not _sos_eval_face_rebuild_timer_active:
        _sos_eval_face_rebuild_timer_active = True
        try:
            bpy.app.timers.register(_sos_eval_face_rebuild_timer, first_interval=max(0.0, min(0.05, due - now)))
        except Exception:
            _sos_eval_face_rebuild_timer_active = False


def _get_optimized_evaluated_edit_face_data(
    obj,
    depsgraph,
    shader,
    prefs,
    *,
    source_bm=None,
    source_live_signature=None,
    state=None,
    navigation_active=False,
    strict_modifier_result=False,
    live_motion_active=False,
):
    """Return the best available modifier-evaluated edit face batch.

    ``strict_modifier_result`` is the semantic mode behind
    "Edit Mode: use faces after modifiers".  While it is active, an edit-cage
    face batch is never substituted for the modifier result.  If a fresh
    evaluated mesh is still being prepared, the last valid evaluated batch is
    retained and the newest state is rebuilt by the app-timer path.
    """
    key = _sos_eval_face_cache_key(obj)
    entry = _sos_eval_face_cpu_cache.get(key)
    state_matches = isinstance(entry, dict) and entry.get('state') == state
    try:
        reuse_stale = bool(getattr(prefs, 'optimization_reuse_stale_evaluated_faces', False))
    except Exception:
        reuse_stale = False

    if state_matches:
        batch = _sos_make_eval_face_batch_from_cpu(entry, shader)
        if batch is not None:
            return {
                'batch_tris': batch,
                'stable_eval': True,
                'suppress_edit_cage_fallback': bool(strict_modifier_result),
            }

    _sos_queue_eval_face_rebuild(
        obj,
        state,
        prefs,
        live_signature=source_live_signature,
        force=_sos_eval_face_force_sync_safe(source_live_signature, prefs),
        live_motion=bool(live_motion_active),
    )

    # In strict modifier-result mode, the last valid evaluated batch is a much
    # safer visual fallback than the editable cage.  It preserves both topology
    # and modifier identity while the current result is calculated, eliminating
    # the evaluated/cage/evaluated frame alternation.  Outside live editing, the
    # legacy preference still controls stale reuse.
    if isinstance(entry, dict) and (reuse_stale or strict_modifier_result):
        batch = entry.get('batch')
        if batch is None:
            batch = _sos_make_eval_face_batch_from_cpu(entry, shader)
        if batch is not None:
            return {
                'batch_tris': batch,
                'stable_eval': True,
                'stale_eval': True,
                'pending_eval': True,
                'suppress_edit_cage_fallback': bool(strict_modifier_result),
            }

    if strict_modifier_result:
        # No evaluated result exists yet.  Suppress the cage for this short
        # preparation window; the immediate path may still seed the first batch.
        return {
            'pending_eval': True,
            'suppress_edit_cage_fallback': True,
        }
    return None


def _build_evaluated_edit_face_data(obj, depsgraph, shader, *, separate_selected=True, source_bm=None, source_live_signature=None, force_sync=False):
    """Build evaluated edit-mode face data for face-only overlay drawing.

    GPU batch creation is now fed by the optimized CPU path so immediate and
    cached rebuild modes use the same lightweight filtering algorithm.
    """
    if obj is None or depsgraph is None or shader is None:
        return None
    data = _build_evaluated_edit_face_cpu_data(
        obj,
        depsgraph,
        separate_selected=separate_selected,
        source_bm=source_bm,
        source_live_signature=source_live_signature,
        force_sync=bool(force_sync),
    )
    if not isinstance(data, dict):
        return None
    try:
        va = data.get('verts')
        indices = data.get('indices')
        if va is None or indices is None or len(indices) <= 0:
            return None
        return {
            'batch_tris': batch_for_shader(shader, 'TRIS', {'pos': va}, indices=indices),
            'cpu_data': data,
        }
    except Exception:
        return None


def _build_evaluated_edit_face_batch(obj, depsgraph, shader):
    """Compatibility helper returning only the evaluated base face batch."""
    data = _build_evaluated_edit_face_data(obj, depsgraph, shader)
    if isinstance(data, dict):
        return data.get('batch_tris')
    return None



def _sos_eval_edge_cache_key(obj):
    try:
        obj_ptr = int(getattr(obj, 'as_pointer', lambda: 0)() or 0)
    except Exception:
        obj_ptr = 0
    try:
        data_ptr = int(getattr(getattr(obj, 'data', None), 'as_pointer', lambda: 0)() or 0)
    except Exception:
        data_ptr = 0
    return ('EDIT_EVAL_NATIVE_EDGES', str(getattr(obj, 'name', '') or ''), obj_ptr, data_ptr)


def _sos_attr_edge_mask(me, attr_names, *, threshold=0.0, fallback_edge_prop=None):
    try:
        edge_count = len(getattr(me, 'edges', ()) or ())
    except Exception:
        edge_count = 0
    mask = np.zeros(edge_count, dtype=bool)
    if edge_count <= 0:
        return mask

    try:
        attrs = getattr(me, 'attributes', None)
    except Exception:
        attrs = None
    if attrs is not None:
        for name in attr_names or ():
            attr = None
            try:
                attr = attrs.get(str(name))
            except Exception:
                attr = None
            if attr is None:
                continue
            try:
                if str(getattr(attr, 'domain', '') or '') != 'EDGE':
                    continue
                data = getattr(attr, 'data', None)
                if data is None or len(data) < edge_count:
                    continue
                data_type = str(getattr(attr, 'data_type', '') or '')
                if data_type == 'BOOLEAN':
                    arr = np.zeros(edge_count, dtype=bool)
                    try:
                        data.foreach_get('value', arr)
                    except Exception:
                        arr = np.asarray([bool(getattr(d, 'value', False)) for d in data[:edge_count]], dtype=bool)
                    mask |= arr
                else:
                    arr = np.zeros(edge_count, dtype=np.float32)
                    try:
                        data.foreach_get('value', arr)
                    except Exception:
                        arr = np.asarray([float(getattr(d, 'value', 0.0) or 0.0) for d in data[:edge_count]], dtype=np.float32)
                    mask |= (arr > float(threshold))
            except Exception:
                continue

    if fallback_edge_prop:
        try:
            for i, edge in enumerate(getattr(me, 'edges', ()) or ()):  # MeshEdge flags are still useful on evaluated meshes.
                if i >= edge_count:
                    break
                try:
                    if bool(getattr(edge, fallback_edge_prop, False)):
                        mask[i] = True
                except Exception:
                    pass
        except Exception:
            pass
    return mask


def _build_evaluated_native_edit_edge_cpu_data(obj, depsgraph, flags, *, source_bm=None, source_live_signature=None, force_sync=False):
    """Build evaluated Mesh Edit Mode diagnostic edge data.

    Blender's built-in Seam / Sharp / Crease / Bevel edit overlays are drawn on
    the edit cage.  When visible edit-mode modifiers generate a different render
    mesh, this helper reads the evaluated mesh attributes and recreates those
    same diagnostic edge overlays on the modifier result.
    """
    if obj is None or depsgraph is None:
        return None
    if not any(bool((flags or {}).get(k, False)) for k in ('seam', 'sharp', 'crease', 'bevel')):
        return None
    eo = None
    me = None
    try:
        if source_bm is not None:
            _sync_edit_mesh_to_evaluated_modifier_stack(
                obj, depsgraph, source_bm=source_bm, live_signature=source_live_signature, force=bool(force_sync)
            )
        eo = obj.evaluated_get(depsgraph)
        try:
            me = eo.to_mesh(preserve_all_data_layers=True, depsgraph=depsgraph)
        except Exception:
            try:
                me = eo.to_mesh(preserve_all_data_layers=False, depsgraph=depsgraph)
            except Exception:
                try:
                    me = eo.to_mesh()
                except Exception:
                    me = None
        if me is None:
            return None
        vc = len(getattr(me, 'vertices', ()) or ())
        ec = len(getattr(me, 'edges', ()) or ())
        if vc <= 0 or ec <= 0:
            return None

        verts = np.empty(vc * 3, dtype=np.float32)
        me.vertices.foreach_get('co', verts)
        verts = verts.reshape(-1, 3).copy()

        edge_indices = np.empty(ec * 2, dtype=np.int32)
        me.edges.foreach_get('vertices', edge_indices)
        edge_indices = edge_indices.reshape(-1, 2).astype(np.int32, copy=False)
        valid = (edge_indices[:, 0] >= 0) & (edge_indices[:, 0] < vc) & (edge_indices[:, 1] >= 0) & (edge_indices[:, 1] < vc)
        try:
            hidden = _sos_attr_edge_mask(me, ('.hide_edge', 'hide_edge'), fallback_edge_prop='hide')
            if hidden is not None and len(hidden) == ec:
                valid &= ~hidden
        except Exception:
            pass

        data = {'verts': verts, 'indices': {}}
        if bool(flags.get('seam', False)):
            mask = _sos_attr_edge_mask(me, ('uv_seam', 'seam'), fallback_edge_prop='use_seam') & valid
            if bool(mask.any()):
                data['indices']['seam'] = edge_indices[mask].astype(np.int32, copy=True)
        if bool(flags.get('sharp', False)):
            mask = _sos_attr_edge_mask(me, ('sharp_edge', 'edge_sharp'), fallback_edge_prop='use_edge_sharp') & valid
            if bool(mask.any()):
                data['indices']['sharp'] = edge_indices[mask].astype(np.int32, copy=True)
        if bool(flags.get('crease', False)):
            mask = _sos_attr_edge_mask(me, ('crease_edge', 'edge_crease', 'crease'), threshold=0.0) & valid
            if bool(mask.any()):
                data['indices']['crease'] = edge_indices[mask].astype(np.int32, copy=True)
        if bool(flags.get('bevel', False)):
            mask = _sos_attr_edge_mask(me, ('bevel_weight_edge', 'edge_bevel_weight', 'bevel_weight'), threshold=0.0) & valid
            if bool(mask.any()):
                data['indices']['bevel'] = edge_indices[mask].astype(np.int32, copy=True)

        if not data['indices']:
            return None
        return data
    except Exception:
        return None
    finally:
        try:
            if eo is not None:
                eo.to_mesh_clear()
        except Exception:
            pass


def _sos_make_evaluated_native_edge_batches(entry, shader):
    try:
        if not isinstance(entry, dict) or shader is None:
            return None
        batches = entry.get('batches')
        if isinstance(batches, dict):
            return batches
        data = entry.get('data')
        if not isinstance(data, dict):
            return None
        verts = data.get('verts')
        indices_by_kind = data.get('indices')
        if verts is None or not isinstance(indices_by_kind, dict):
            return None
        batches = {}
        for kind, indices in indices_by_kind.items():
            try:
                if indices is not None and len(indices) > 0:
                    batches[kind] = batch_for_shader(shader, 'LINES', {'pos': verts}, indices=indices)
            except Exception:
                continue
        entry['batches'] = batches
        return batches
    except Exception:
        return None


def _get_evaluated_native_edit_edge_batches(obj, depsgraph, shader, flags, state, *, source_bm=None, source_live_signature=None, force_sync=False):
    # Disabled by design.  Blender's standard Mesh Edit Mode diagnostic edge
    # overlays are edit-cage overlays; mirroring them onto evaluated modifier
    # output creates the duplicate base + final-result display reported with
    # Seam / Sharp / Crease / Bevel.  Keep this function as a compatibility
    # stub so older cache paths fail closed instead of drawing evaluated copies.
    return None
    if obj is None or depsgraph is None or shader is None:
        return None
    if not any(bool((flags or {}).get(k, False)) for k in ('seam', 'sharp', 'crease', 'bevel')):
        return None
    key = _sos_eval_edge_cache_key(obj)
    try:
        entry = _sos_eval_native_edge_cpu_cache.get(key)
        if isinstance(entry, dict) and entry.get('state') == state:
            batches = _sos_make_evaluated_native_edge_batches(entry, shader)
            if batches:
                return batches
    except Exception:
        pass

    data = _build_evaluated_native_edit_edge_cpu_data(
        obj, depsgraph, flags, source_bm=source_bm, source_live_signature=source_live_signature, force_sync=bool(force_sync)
    )
    if not isinstance(data, dict):
        try:
            _sos_eval_native_edge_cpu_cache.pop(key, None)
        except Exception:
            pass
        return None
    entry = {'state': state, 'data': data, 'batches': None, 'created': time.time()}
    try:
        _sos_eval_native_edge_cpu_cache[key] = entry
        if len(_sos_eval_native_edge_cpu_cache) > _SOS_BASE_CACHE_MAX_ENTRIES:
            for old_key in list(_sos_eval_native_edge_cpu_cache.keys())[:-_SOS_BASE_CACHE_MAX_ENTRIES]:
                _sos_eval_native_edge_cpu_cache.pop(old_key, None)
    except Exception:
        pass
    return _sos_make_evaluated_native_edge_batches(entry, shader)


def _sos_hash_mix_u64(h: int, value: int) -> int:
    """Small deterministic 64-bit mixer for live overlay signatures."""
    try:
        v = int(value) & 0xFFFFFFFFFFFFFFFF
    except Exception:
        v = 0
    h ^= v
    h = (h * 1099511628211) & 0xFFFFFFFFFFFFFFFF
    return h


def _sos_quantized_float(value, scale: float = 1000000.0) -> int:
    try:
        return int(round(float(value) * float(scale)))
    except Exception:
        return 0


def _mesh_data_live_geometry_signature(mesh) -> tuple:
    """Return a live mesh-data signature for object-mode cache invalidation.

    Object-mode batches are built from evaluated meshes, but the cache key must
    also react to edits of the source mesh coordinates.  Element counts alone do
    not change when a vertex is moved, so the overlay can otherwise keep drawing
    a stale batch until a modifier visibility toggle forces a rebuild.
    """
    if mesh is None or not isinstance(mesh, bpy.types.Mesh):
        return ()
    try:
        vc = len(mesh.vertices)
        ec = len(mesh.edges)
        pc = len(mesh.polygons)
    except Exception:
        return ()
    try:
        if vc <= 0:
            co_crc = 0
            co_sum = ()
        else:
            co = np.empty(vc * 3, dtype=np.float32)
            position = mesh.attributes.get("position")
            if position is not None and position.domain == 'POINT' and position.data_type == 'FLOAT_VECTOR' and len(position.data) == vc:
                position.data.foreach_get("vector", co)
            else:
                mesh.vertices.foreach_get("co", co)
            # Quantize to microunits to ignore insignificant binary-float noise
            # while still detecting every visible modeling change.
            q = np.rint(co.astype(np.float64) * 1000000.0).astype(np.int64, copy=False)
            co_crc = int(zlib.crc32(q.tobytes()) & 0xFFFFFFFF)
            co_sum = (
                int(q.sum(dtype=np.int64)) if q.size else 0,
                int((q * ((np.arange(q.size, dtype=np.int64) % 104729) + 1)).sum(dtype=np.int64)) if q.size else 0,
            )
    except Exception:
        co_crc = 0
        co_sum = ()
    try:
        if ec <= 0:
            edge_crc = 0
        else:
            ev = np.empty(ec * 2, dtype=np.int32)
            mesh.edges.foreach_get("vertices", ev)
            edge_crc = int(zlib.crc32(ev.tobytes()) & 0xFFFFFFFF)
    except Exception:
        edge_crc = 0
    try:
        if pc <= 0:
            poly_crc = 0
            poly_sel_crc = 0
        else:
            pi = np.empty(pc, dtype=np.int32)
            mesh.polygons.foreach_get("loop_start", pi)
            pt = np.empty(pc, dtype=np.int32)
            mesh.polygons.foreach_get("loop_total", pt)
            ph = np.empty(pc, dtype=np.bool_)
            hide_attr = mesh.attributes.get(".hide_poly")
            if hide_attr is None:
                ph.fill(False)
            elif hide_attr.domain == 'FACE' and hide_attr.data_type == 'BOOLEAN' and len(hide_attr.data) == pc:
                hide_attr.data.foreach_get("value", ph)
            else:
                mesh.polygons.foreach_get("hide", ph)
            ps = np.empty(pc, dtype=np.bool_)
            select_attr = mesh.attributes.get(".select_poly")
            if select_attr is None:
                ps.fill(False)
            elif select_attr.domain == 'FACE' and select_attr.data_type == 'BOOLEAN' and len(select_attr.data) == pc:
                select_attr.data.foreach_get("value", ps)
            else:
                mesh.polygons.foreach_get("select", ps)
            poly_crc = int(zlib.crc32(pi.tobytes() + pt.tobytes() + ph.tobytes()) & 0xFFFFFFFF)
            poly_sel_crc = int(zlib.crc32(ps.tobytes()) & 0xFFFFFFFF)
    except Exception:
        poly_crc = 0
        poly_sel_crc = 0
    return (vc, ec, pc, co_crc, co_sum, edge_crc, poly_crc, poly_sel_crc)


def _sos_live_geometry_signature_fast(bm, vc, ec, fc, start, budget):
    """Exact (non-sampled) result of ``_bmesh_live_geometry_signature`` from whole-list reads.

    Elements are read once per attribute with comprehensions and hashed in the
    same order with the same mixer.  Coordinates are quantized like
    ``_sos_quantized_float`` (float64 product, round half to even) in one numpy
    step; non-finite or huge values return None so the per-element loops keep
    their own handling.  The budget is checked at the start of each phase with
    the same reasons.  Any other error returns None and the caller runs its loops.
    """
    P = 1099511628211
    M = 0xFFFFFFFFFFFFFFFF
    H = 1469598103934665603
    try:
        verts = bm.verts
        _sos_check_edit_budget(start, budget, 'live vertex signature')
        if len(verts) != vc:
            return None
        q_list = v_sel = v_hide = ()
        if vc:
            co = np.array([v.co for v in verts], dtype=np.float64)
            if co.shape != (vc, 3):
                return None
            q = co * 1000000.0
            if not bool(np.isfinite(q).all()) or float(np.abs(q).max()) >= 4.0e15:
                return None
            q_list = np.rint(q).astype(np.int64).ravel().tolist()
            v_sel = np.flatnonzero(np.array([v.select for v in verts], dtype=bool)).tolist()
            v_hide = np.flatnonzero(np.array([v.hide for v in verts], dtype=bool)).tolist()
        h_co = H
        for x in q_list:
            h_co = ((h_co ^ (x & M)) * P) & M
        h_sel_v = H
        for i in v_sel:
            h_sel_v = ((h_sel_v ^ ((i + 1) & M)) * P) & M
        h_hide_v = H
        for i in v_hide:
            h_hide_v = ((h_hide_v ^ ((i + 1) & M)) * P) & M
        verts.index_update()

        edges = bm.edges
        _sos_check_edit_budget(start, budget, 'live edge signature')
        if len(edges) != ec:
            return None
        e_topo = e_sel = e_hide = ()
        if ec:
            pairs = []
            add_pair = pairs.extend
            for e in edges:
                v0, v1 = e.verts
                add_pair((v0.index, v1.index))
            ea = np.array(pairs, dtype=np.int64).reshape(ec, 2)
            topo = np.empty(2 * ec, dtype=np.int64)
            topo[0::2] = np.minimum(ea[:, 0], ea[:, 1]) + 1
            topo[1::2] = np.maximum(ea[:, 0], ea[:, 1]) + 1
            e_topo = topo.tolist()
            e_sel = np.flatnonzero(np.array([e.select for e in edges], dtype=bool)).tolist()
            e_hide = np.flatnonzero(np.array([e.hide for e in edges], dtype=bool)).tolist()
        h_edge_topo = H
        for x in e_topo:
            h_edge_topo = ((h_edge_topo ^ (x & M)) * P) & M
        h_sel_e = H
        for i in e_sel:
            h_sel_e = ((h_sel_e ^ ((i + 1) & M)) * P) & M
        h_hide_e = H
        for i in e_hide:
            h_hide_e = ((h_hide_e ^ ((i + 1) & M)) * P) & M

        faces = bm.faces
        _sos_check_edit_budget(start, budget, 'live face signature')
        if len(faces) != fc:
            return None
        f_topo = []
        f_sel = f_hide = ()
        if fc:
            add_len = f_topo.append
            add_idx = f_topo.extend
            for f in faces:
                fv = f.verts
                add_len(len(fv))
                add_idx([v.index + 1 for v in fv])
            f_sel = np.flatnonzero(np.array([f.select for f in faces], dtype=bool)).tolist()
            f_hide = np.flatnonzero(np.array([f.hide for f in faces], dtype=bool)).tolist()
        h_face_topo = H
        for x in f_topo:
            h_face_topo = ((h_face_topo ^ (x & M)) * P) & M
        h_sel_f = H
        for i in f_sel:
            h_sel_f = ((h_sel_f ^ ((i + 1) & M)) * P) & M
        h_hide_f = H
        for i in f_hide:
            h_hide_f = ((h_hide_f ^ ((i + 1) & M)) * P) & M
    except _SOSOverlayBudgetExceeded:
        raise
    except Exception:
        return None
    return (
        vc, ec, fc,
        int(h_co),
        int(h_edge_topo), int(h_face_topo),
        int(h_sel_v), int(h_sel_e), int(h_sel_f),
        int(h_hide_v), int(h_hide_e), int(h_hide_f),
        'FULL',
    )


def _bmesh_live_geometry_signature(bm, *, budget_start=None, budget_seconds=None) -> tuple:
    """Return a live edit-BMesh signature that changes when geometry moves.

    The exact path hashes all edit elements for normal-sized meshes.  On very
    large meshes, the signature falls back to deterministic sampling so the draw
    callback never stalls Blender while the user is editing.  The sampled path is
    only a cache key; if it misses a change, the next depsgraph/editor update still
    invalidates or redraws normally, while the UI remains responsive.
    """
    if bm is None:
        return ()
    try:
        bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
    except Exception:
        pass
    try:
        vc = len(bm.verts); ec = len(bm.edges); fc = len(bm.faces)
    except Exception:
        return ()

    start = _sos_perf_counter() if budget_start is None else float(budget_start)
    budget = _SOS_EDIT_BATCH_SIGNATURE_BUDGET_SECONDS if budget_seconds is None else float(budget_seconds)
    total = int(vc) + int(ec) + int(fc)
    sampled = total > _SOS_EDIT_BATCH_HEAVY_ELEMENT_LIMIT
    if not sampled:
        fast = _sos_live_geometry_signature_fast(bm, vc, ec, fc, start, budget)
        if fast is not None:
            return fast

    h_co = 1469598103934665603
    h_sel_v = 1469598103934665603
    h_hide_v = 1469598103934665603
    try:
        vert_iter = _sos_sample_indices(vc, 768) if sampled else range(vc)
        for n, i in enumerate(vert_iter):
            if (n & (_SOS_EDIT_BATCH_BUDGET_CHECK_STRIDE - 1)) == 0:
                _sos_check_edit_budget(start, budget, 'live vertex signature')
            try:
                v = bm.verts[int(i)]
            except Exception:
                continue
            co = getattr(v, 'co', None)
            if co is not None:
                h_co = _sos_hash_mix_u64(h_co, _sos_quantized_float(co.x))
                h_co = _sos_hash_mix_u64(h_co, _sos_quantized_float(co.y))
                h_co = _sos_hash_mix_u64(h_co, _sos_quantized_float(co.z))
            if bool(getattr(v, 'select', False)):
                h_sel_v = _sos_hash_mix_u64(h_sel_v, int(i) + 1)
            if bool(getattr(v, 'hide', False)):
                h_hide_v = _sos_hash_mix_u64(h_hide_v, int(i) + 1)
    except _SOSOverlayBudgetExceeded:
        raise
    except Exception:
        pass

    try:
        if not sampled:
            bm.verts.index_update()
    except Exception:
        pass
    h_edge_topo = 1469598103934665603
    h_sel_e = 1469598103934665603
    h_hide_e = 1469598103934665603
    try:
        edge_iter = _sos_sample_indices(ec, 768) if sampled else range(ec)
        for n, i in enumerate(edge_iter):
            if (n & (_SOS_EDIT_BATCH_BUDGET_CHECK_STRIDE - 1)) == 0:
                _sos_check_edit_budget(start, budget, 'live edge signature')
            try:
                e = bm.edges[int(i)]
            except Exception:
                continue
            try:
                v0, v1 = e.verts
                i0 = int(getattr(v0, 'index', -1)); i1 = int(getattr(v1, 'index', -1))
                if i0 > i1:
                    i0, i1 = i1, i0
                h_edge_topo = _sos_hash_mix_u64(h_edge_topo, i0 + 1)
                h_edge_topo = _sos_hash_mix_u64(h_edge_topo, i1 + 1)
            except Exception:
                pass
            if bool(getattr(e, 'select', False)):
                h_sel_e = _sos_hash_mix_u64(h_sel_e, int(i) + 1)
            if bool(getattr(e, 'hide', False)):
                h_hide_e = _sos_hash_mix_u64(h_hide_e, int(i) + 1)
    except _SOSOverlayBudgetExceeded:
        raise
    except Exception:
        pass

    h_face_topo = 1469598103934665603
    h_sel_f = 1469598103934665603
    h_hide_f = 1469598103934665603
    try:
        face_iter = _sos_sample_indices(fc, 768) if sampled else range(fc)
        for n, i in enumerate(face_iter):
            if (n & (_SOS_EDIT_BATCH_BUDGET_CHECK_STRIDE - 1)) == 0:
                _sos_check_edit_budget(start, budget, 'live face signature')
            try:
                f = bm.faces[int(i)]
            except Exception:
                continue
            try:
                h_face_topo = _sos_hash_mix_u64(h_face_topo, len(f.verts))
                for v in f.verts:
                    h_face_topo = _sos_hash_mix_u64(h_face_topo, int(getattr(v, 'index', -1)) + 1)
            except Exception:
                pass
            if bool(getattr(f, 'select', False)):
                h_sel_f = _sos_hash_mix_u64(h_sel_f, int(i) + 1)
            if bool(getattr(f, 'hide', False)):
                h_hide_f = _sos_hash_mix_u64(h_hide_f, int(i) + 1)
    except _SOSOverlayBudgetExceeded:
        raise
    except Exception:
        pass

    return (
        vc, ec, fc,
        int(h_co),
        int(h_edge_topo), int(h_face_topo),
        int(h_sel_v), int(h_sel_e), int(h_sel_f),
        int(h_hide_v), int(h_hide_e), int(h_hide_f),
        'SAMPLED' if sampled else 'FULL',
    )


def _bmesh_evaluated_edit_face_source_signature(bm, *, budget_start=None, budget_seconds=None) -> tuple:
    """Return geometry/visibility-only signature for evaluated edit face fill.

    The modifier-evaluated visible/occluded face fill is built with
    ``separate_selected=False``.  It must therefore not depend on edit-element
    selection state.  Including selection in this cache key caused multi-object
    edit selection changes to invalidate the evaluated face cache every redraw,
    producing pending frames with no stable face overlay.
    """
    if bm is None:
        return ()
    try:
        bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
    except Exception:
        pass
    try:
        bm.verts.index_update(); bm.edges.index_update(); bm.faces.index_update()
    except Exception:
        pass
    try:
        vc = len(bm.verts); ec = len(bm.edges); fc = len(bm.faces)
    except Exception:
        return ()

    start = _sos_perf_counter() if budget_start is None else float(budget_start)
    budget = _SOS_EDIT_BATCH_SIGNATURE_BUDGET_SECONDS if budget_seconds is None else float(budget_seconds)
    total = int(vc) + int(ec) + int(fc)
    sampled = total > _SOS_EDIT_BATCH_HEAVY_ELEMENT_LIMIT

    h_co = 1469598103934665603
    h_hide_v = 1469598103934665603
    try:
        vert_iter = _sos_sample_indices(vc, 768) if sampled else range(vc)
        for n, i in enumerate(vert_iter):
            if (n & (_SOS_EDIT_BATCH_BUDGET_CHECK_STRIDE - 1)) == 0:
                _sos_check_edit_budget(start, budget, 'evaluated edit face source vertex signature')
            try:
                v = bm.verts[int(i)]
            except Exception:
                continue
            co = getattr(v, 'co', None)
            if co is not None:
                h_co = _sos_hash_mix_u64(h_co, _sos_quantized_float(co.x))
                h_co = _sos_hash_mix_u64(h_co, _sos_quantized_float(co.y))
                h_co = _sos_hash_mix_u64(h_co, _sos_quantized_float(co.z))
            if bool(getattr(v, 'hide', False)):
                h_hide_v = _sos_hash_mix_u64(h_hide_v, int(i) + 1)
    except _SOSOverlayBudgetExceeded:
        raise
    except Exception:
        pass

    h_edge_topo = 1469598103934665603
    h_hide_e = 1469598103934665603
    try:
        edge_iter = _sos_sample_indices(ec, 768) if sampled else range(ec)
        for n, i in enumerate(edge_iter):
            if (n & (_SOS_EDIT_BATCH_BUDGET_CHECK_STRIDE - 1)) == 0:
                _sos_check_edit_budget(start, budget, 'evaluated edit face source edge signature')
            try:
                e = bm.edges[int(i)]
            except Exception:
                continue
            try:
                v0, v1 = e.verts
                i0 = int(getattr(v0, 'index', -1)); i1 = int(getattr(v1, 'index', -1))
                if i0 > i1:
                    i0, i1 = i1, i0
                h_edge_topo = _sos_hash_mix_u64(h_edge_topo, i0 + 1)
                h_edge_topo = _sos_hash_mix_u64(h_edge_topo, i1 + 1)
            except Exception:
                pass
            if bool(getattr(e, 'hide', False)):
                h_hide_e = _sos_hash_mix_u64(h_hide_e, int(i) + 1)
    except _SOSOverlayBudgetExceeded:
        raise
    except Exception:
        pass

    h_face_topo = 1469598103934665603
    h_hide_f = 1469598103934665603
    try:
        face_iter = _sos_sample_indices(fc, 768) if sampled else range(fc)
        for n, i in enumerate(face_iter):
            if (n & (_SOS_EDIT_BATCH_BUDGET_CHECK_STRIDE - 1)) == 0:
                _sos_check_edit_budget(start, budget, 'evaluated edit face source face signature')
            try:
                f = bm.faces[int(i)]
            except Exception:
                continue
            try:
                h_face_topo = _sos_hash_mix_u64(h_face_topo, len(f.verts))
                for v in f.verts:
                    h_face_topo = _sos_hash_mix_u64(h_face_topo, int(getattr(v, 'index', -1)) + 1)
            except Exception:
                pass
            if bool(getattr(f, 'hide', False)):
                h_hide_f = _sos_hash_mix_u64(h_hide_f, int(i) + 1)
    except _SOSOverlayBudgetExceeded:
        raise
    except Exception:
        pass

    return (
        vc, ec, fc,
        int(h_co),
        int(h_edge_topo), int(h_face_topo),
        int(h_hide_v), int(h_hide_e), int(h_hide_f),
        'SAMPLED' if sampled else 'FULL',
    )


def _sos_edge_diagnostic_hash_fast(bm, want_seam, want_sharp, want_crease, want_bevel, crease_layer, bevel_layer):
    """Hash of ``_bmesh_edge_diagnostic_signature`` computed from whole-list reads.

    Each requested mark kind is read once with a comprehension and only the
    marked edges are mixed, in the same edge order, with the same values and the
    same mixer, so the result is identical to the per-edge loop.  Returns None on
    any error so the caller runs that loop instead.
    """
    try:
        if want_crease and crease_layer is None and hasattr(bmesh.types.BMEdge, 'crease'):
            return None
        if want_bevel and bevel_layer is None and hasattr(bmesh.types.BMEdge, 'bevel_weight'):
            return None
        edges = bm.edges
        n = len(edges)
        P = 1099511628211
        M = 0xFFFFFFFFFFFFFFFF
        h = ((1469598103934665603 ^ (int(n) & M)) * P) & M
        seam = [e.seam for e in edges] if want_seam else None
        smooth = [e.smooth for e in edges] if want_sharp else None
        # Without a layer the loop reads a missing BMEdge attribute, which is 0.0.
        crease = [float(e[crease_layer]) for e in edges] if (want_crease and crease_layer is not None) else None
        bevel = [float(e[bevel_layer]) for e in edges] if (want_bevel and bevel_layer is not None) else None
        if n <= 0 or (seam is None and smooth is None and crease is None and bevel is None):
            return h
        mask = np.zeros(n, dtype=bool)
        if seam is not None:
            mask |= np.array(seam, dtype=bool)
        if smooth is not None:
            mask |= ~np.array(smooth, dtype=bool)
        if crease is not None:
            mask |= np.array(crease, dtype=np.float64) != 0.0
        if bevel is not None:
            mask |= np.array(bevel, dtype=np.float64) != 0.0
        for i in np.flatnonzero(mask).tolist():
            if seam is not None and seam[i]:
                h = ((h ^ (((i + 1) * 11) & M)) * P) & M
            if smooth is not None and not smooth[i]:
                h = ((h ^ (((i + 1) * 13) & M)) * P) & M
            if crease is not None:
                cv = crease[i]
                if cv != 0.0:
                    h = ((h ^ (((i + 1) * 17) & M)) * P) & M
                    h = ((h ^ (_sos_quantized_float(cv) & M)) * P) & M
            if bevel is not None:
                bv = bevel[i]
                if bv != 0.0:
                    h = ((h ^ (((i + 1) * 19) & M)) * P) & M
                    h = ((h ^ (_sos_quantized_float(bv) & M)) * P) & M
        return h
    except Exception:
        return None


def _bmesh_edge_diagnostic_signature(bm, flags=None) -> tuple:
    """Hash edit-edge Seam / Sharp / Crease / Bevel marks for cache invalidation.

    Blender's native Mesh Edit Mode Overlay switches can change visibility even
    when topology, coordinates, and selection counts stay unchanged.  Keep those
    marks in the Smart Overlay cache state so modifier-evaluated diagnostic
    batches are rebuilt immediately after Mark Seam, Mark Sharp, crease, or
    bevel-weight edits.
    """
    if bm is None:
        return ()
    try:
        bm.edges.ensure_lookup_table()
        bm.edges.index_update()
    except Exception:
        pass
    flags = flags or {}

    def _flag(name):
        try:
            return bool(flags.get(name, False))
        except Exception:
            return False

    want_seam = _flag('seam')
    want_sharp = _flag('sharp')
    want_crease = _flag('crease')
    want_bevel = _flag('bevel')
    if not (want_seam or want_sharp or want_crease or want_bevel):
        return ()

    crease_layer = bevel_layer = None
    try:
        edge_float_layers = bm.edges.layers.float
    except Exception:
        edge_float_layers = None
    if edge_float_layers is not None:
        if want_crease:
            for layer_name in ('crease_edge', 'edge_crease', 'crease'):
                try:
                    crease_layer = edge_float_layers.get(layer_name)
                except Exception:
                    crease_layer = None
                if crease_layer is not None:
                    break
        if want_bevel:
            for layer_name in ('bevel_weight_edge', 'edge_bevel_weight', 'bevel_weight'):
                try:
                    bevel_layer = edge_float_layers.get(layer_name)
                except Exception:
                    bevel_layer = None
                if bevel_layer is not None:
                    break

    def _edge_float(edge, layer, attr_name):
        if layer is not None:
            try:
                return float(edge[layer])
            except Exception:
                pass
        try:
            return float(getattr(edge, attr_name, 0.0) or 0.0)
        except Exception:
            return 0.0

    fast_h = _sos_edge_diagnostic_hash_fast(bm, want_seam, want_sharp, want_crease, want_bevel, crease_layer, bevel_layer)
    if fast_h is not None:
        return (int(fast_h), bool(want_seam), bool(want_sharp), bool(want_crease), bool(want_bevel))
    h = 1469598103934665603
    try:
        h = _sos_hash_mix_u64(h, len(bm.edges))
        for i, edge in enumerate(bm.edges):
            try:
                if want_seam and bool(getattr(edge, 'seam', False)):
                    h = _sos_hash_mix_u64(h, (i + 1) * 11)
                if want_sharp and (not bool(getattr(edge, 'smooth', True))):
                    h = _sos_hash_mix_u64(h, (i + 1) * 13)
                if want_crease:
                    cv = _edge_float(edge, crease_layer, 'crease')
                    if cv != 0.0:
                        h = _sos_hash_mix_u64(h, (i + 1) * 17)
                        h = _sos_hash_mix_u64(h, _sos_quantized_float(cv))
                if want_bevel:
                    bv = _edge_float(edge, bevel_layer, 'bevel_weight')
                    if bv != 0.0:
                        h = _sos_hash_mix_u64(h, (i + 1) * 19)
                        h = _sos_hash_mix_u64(h, _sos_quantized_float(bv))
            except Exception:
                continue
    except Exception:
        pass
    return (int(h), bool(want_seam), bool(want_sharp), bool(want_crease), bool(want_bevel))


def _sos_srgb_component_to_linear(value):
    try:
        value = max(0.0, min(1.0, float(value)))
    except Exception:
        return 0.0
    if value <= 0.04045:
        return value / 12.92
    return ((value + 0.055) / 1.055) ** 2.4


def _native_mesh_edit_edge_overlay_colors(context=None):
    """Return Blender theme colors for native Mesh Edit edge overlays.

    Theme colors are display (sRGB) values, while both draw paths treat edge
    colors as linear and convert them for display.  Return linear RGB so the
    seam/sharp/crease/bevel marks reach the screen in the theme color instead
    of a brighter, washed-out one.
    """
    ctx = context or getattr(bpy, 'context', None)
    fallbacks = {
        'seam': (0.8588, 0.1451, 0.0706, 1.0),
        'sharp': (0.0000, 1.0000, 1.0000, 1.0),
        'crease': (0.8000, 0.0000, 0.6000, 1.0),
        'bevel': (0.0000, 0.6471, 1.0000, 1.0),
    }
    result = dict(fallbacks)
    try:
        pref_root = getattr(ctx, 'preferences', None) or getattr(bpy.context, 'preferences', None)
        theme = (getattr(pref_root, 'themes', None) or [None])[0]
        view3d = getattr(theme, 'view_3d', None)
    except Exception:
        view3d = None
    if view3d is not None:
        for key in ('seam', 'sharp', 'crease', 'bevel'):
            try:
                col = tuple(float(v) for v in getattr(view3d, key))
                if len(col) >= 3:
                    result[key] = (col[0], col[1], col[2], 1.0)
            except Exception:
                pass
    return {
        key: (
            _sos_srgb_component_to_linear(col[0]),
            _sos_srgb_component_to_linear(col[1]),
            _sos_srgb_component_to_linear(col[2]),
            1.0,
        )
        for key, col in result.items()
    }


def _native_mesh_edit_edge_overlay_width(context=None, fallback_width=2.0):
    """Approximate Blender native diagnostic edge overlay width."""
    width = float(fallback_width or 2.0)
    ctx = context or getattr(bpy, 'context', None)
    try:
        pref_root = getattr(ctx, 'preferences', None) or getattr(bpy.context, 'preferences', None)
        theme = (getattr(pref_root, 'themes', None) or [None])[0]
        view3d = getattr(theme, 'view_3d', None)
        if view3d is not None:
            width = max(width, float(getattr(view3d, 'edge_width', 1) or 1) + 1.0)
    except Exception:
        pass
    return max(1.0, min(8.0, width))


def _mesh_object_has_viewport_modifiers(obj) -> bool:
    try:
        if getattr(obj, 'type', None) != 'MESH':
            return False
        modifiers = getattr(obj, 'modifiers', None)
        if not modifiers:
            return False
        for mod in modifiers:
            if bool(getattr(mod, 'show_viewport', True)):
                return True
    except Exception:
        return False
    return False


def _modifier_references_object_name(obj, names: set[str]) -> bool:
    if not obj or not names:
        return False
    try:
        modifiers = tuple(getattr(obj, 'modifiers', ()) or ())
    except Exception:
        modifiers = ()
    for mod in modifiers:
        try:
            if not bool(getattr(mod, 'show_viewport', True)):
                continue
        except Exception:
            pass
        try:
            props = tuple(getattr(getattr(mod, 'bl_rna', None), 'properties', ()) or ())
        except Exception:
            props = ()
        for prop in props:
            try:
                identifier = str(getattr(prop, 'identifier', '') or '')
                if not identifier or identifier == 'rna_type':
                    continue
                value = getattr(mod, identifier, None)
            except Exception:
                continue
            try:
                if isinstance(value, bpy.types.Object) and str(getattr(value, 'name', '') or '') in names:
                    return True
            except Exception:
                pass
            try:
                if isinstance(value, bpy.types.Collection):
                    for child in value.objects:
                        if str(getattr(child, 'name', '') or '') in names:
                            return True
            except Exception:
                pass
    return False


def _invalidate_modifier_dependent_mesh_caches(changed_object_names=None) -> None:
    """Clear cached mesh batches that may depend on external modifier inputs."""
    try:
        objs = tuple(getattr(getattr(bpy, 'data', None), 'objects', ()) or ())
    except Exception:
        objs = ()
    try:
        prefs = get_effective_settings(getattr(bpy, 'context', None))
    except Exception:
        prefs = None
    changed_names = {str(n) for n in (changed_object_names or ()) if str(n or '')}
    targeted = bool(changed_names) and _sos_opt_bool(prefs, 'optimization_target_modifier_dependency_dirty', False)
    for obj in objs:
        try:
            if not _mesh_object_has_viewport_modifiers(obj):
                continue
            obj_name = str(getattr(obj, 'name', '') or '')
            if targeted and obj_name not in changed_names and not _modifier_references_object_name(obj, changed_names):
                continue
            _invalidate_object_cache(obj.name)
        except Exception:
            continue

def _same_pass_object_mode_mesh_signature(obj, data, data_orig, same_pass_signature_cache) -> tuple:
    """Reuse one exact live-mesh signature only within one synchronous rebuild."""
    if same_pass_signature_cache is None:
        return _mesh_data_live_geometry_signature(data_orig)
    key = ('LIVE_MESH_SIGNATURE', _sos_pointer(data), _sos_pointer(data_orig))
    if key not in same_pass_signature_cache:
        same_pass_signature_cache[key] = _mesh_data_live_geometry_signature(data_orig)
    return same_pass_signature_cache[key]


_SOS_XFORM_SIG_TRANSFORM_IDS = frozenset((
    'TRANSFORM_OT_translate', 'TRANSFORM_OT_resize', 'TRANSFORM_OT_rotate',
    'TRANSFORM_OT_transform', 'TRANSFORM_OT_shear', 'TRANSFORM_OT_tosphere',
    'TRANSFORM_OT_bend', 'TRANSFORM_OT_mirror', 'TRANSFORM_OT_shrink_fatten',
    'TRANSFORM_OT_skin_resize', 'TRANSFORM_OT_push_pull', 'TRANSFORM_OT_edge_slide',
    'TRANSFORM_OT_vert_slide', 'TRANSFORM_OT_seq_slide', 'TRANSFORM_OT_translate_to_origin',
))


def _sos_xform_sig_bump() -> None:
    """Advance the epoch that guards cross-collect Live-signature reuse."""
    global _sos_xform_sig_epoch
    _sos_xform_sig_epoch = (int(_sos_xform_sig_epoch) + 1) & 0x7FFFFFFF


def _sos_object_xform_modal_token(context=None):
    """Identity of the running transform modal operators, or None.

    Read-only: only Window.modal_operators identifiers and pointers are read.
    None is returned when no transform modal runs, when any operator cannot be
    identified, or when the depsgraph handler that advances the epoch is not
    installed; callers then use a fresh per-collect cache.
    """
    try:
        handlers = getattr(bpy.app.handlers, 'depsgraph_update_post', None)
        if handlers is None or _sos_depsgraph_update not in handlers:
            return None
    except Exception:
        return None
    ctx = context or getattr(bpy, 'context', None)
    windows = []
    try:
        win = getattr(ctx, 'window', None)
        if win is not None:
            windows.append(win)
    except Exception:
        pass
    try:
        wm = getattr(ctx, 'window_manager', None) or getattr(bpy.context, 'window_manager', None)
        for win in getattr(wm, 'windows', ()) or ():
            if win not in windows:
                windows.append(win)
    except Exception:
        pass
    token = []
    for win in windows:
        try:
            modal_ops = tuple(getattr(win, 'modal_operators', ()) or ())
        except Exception:
            return None
        for op in modal_ops:
            try:
                op_id = str(getattr(op, 'bl_idname', '') or '')
            except Exception:
                return None
            if op_id not in _SOS_XFORM_SIG_TRANSFORM_IDS:
                continue
            try:
                ptr = int(op.as_pointer())
            except Exception:
                return None
            if not ptr:
                return None
            token.append((op_id, ptr))
    return tuple(token) if token else None


def _sos_object_xform_signature_cache(context=None, overlay_mode='OBJECT') -> dict:
    """Return the Live Mesh/Curve signature dict for one object-mode collect.

    Without a running Object-mode transform this is a new dict, i.e. the
    original per-collect cache.  While the same Move/Rotate/Scale modal runs,
    source Mesh/Curve data can only change through a depsgraph geometry update,
    a non-Object ID update or an explicit cache invalidation, and each of those
    advances _sos_xform_sig_epoch.  Until then the previous collect's dict is
    returned, so every signature equals what a full rescan would compute while
    the per-frame coordinate hashing of every selected object is skipped.
    """
    state = _sos_xform_sig_state
    token = None
    if overlay_mode == 'OBJECT':
        try:
            token = _sos_object_xform_modal_token(context)
        except Exception:
            token = None
    if not token:
        state['token'] = None
        state['epoch'] = -1
        state['cache'] = None
        return {}
    epoch = int(_sos_xform_sig_epoch)
    cache = state.get('cache')
    if isinstance(cache, dict) and state.get('token') == token and state.get('epoch') == epoch:
        return cache
    cache = {}
    state['token'] = token
    state['epoch'] = epoch
    state['cache'] = cache
    return cache


def _sos_same_pass_curve_signature(obj, data, prefs=None, same_pass_signature_cache=None) -> tuple:
    if same_pass_signature_cache is None:
        return _sos_curve_live_signature_for_cache(obj, data, prefs)
    key = ('LIVE_CURVE_SIGNATURE', _sos_pointer(obj), _sos_pointer(data))
    if key not in same_pass_signature_cache:
        same_pass_signature_cache[key] = _sos_curve_live_signature_for_cache(obj, data, prefs)
    return same_pass_signature_cache[key]


def _object_mode_cache_state(obj, same_pass_signature_cache=None) -> tuple:
    data = getattr(obj, 'data', None)
    data_orig = getattr(data, 'original', data) if data is not None else None
    try:
        data_ptr = int(getattr(data_orig, 'as_pointer', lambda: 0)() or 0) if data_orig is not None else 0
    except Exception:
        data_ptr = 0
    try:
        prefs = get_effective_settings(getattr(bpy, 'context', None))
    except Exception:
        prefs = None
    dirty_generation_authoritative = _sos_opt_bool(prefs, 'optimization_dirty_generation_cache', False)
    if isinstance(data_orig, bpy.types.Mesh):
        if dirty_generation_authoritative:
            live_mesh_sig = ('DIRTY_GENERATION', _sos_dirty_generation_for_object(obj))
        else:
            live_mesh_sig = _same_pass_object_mode_mesh_signature(
                obj, data, data_orig, same_pass_signature_cache,
            )
    else:
        live_mesh_sig = ()
    return (
        str(getattr(obj, 'type', '') or ''),
        str(type(data_orig).__name__ if data_orig is not None else ''),
        data_ptr,
        _safe_collection_len(data, 'vertices'),
        _safe_collection_len(data, 'edges'),
        _safe_collection_len(data, 'polygons'),
        _safe_collection_len(data, 'splines'),
        _safe_collection_len(data, 'points'),
        _safe_collection_len(data, 'curves'),
        _lattice_dimensions(data) if _is_lattice_data(data) else (),
        _lattice_point_signature(data) if _is_lattice_data(data) else (),
        _sos_same_pass_curve_signature(obj, data, prefs, same_pass_signature_cache) if str(getattr(obj, 'type', '') or '') == 'CURVE' else (),
        live_mesh_sig,
        _modifier_viewport_signature(obj),
        _modifier_evaluated_runtime_signature(obj)
        if (not dirty_generation_authoritative) and _mesh_object_has_viewport_modifiers(obj)
        else (),
    )


def _sos_object_has_shape_key_deformation(obj) -> bool:
    try:
        data = getattr(obj, 'data', None)
        shape_keys = getattr(data, 'shape_keys', None)
        keys = getattr(shape_keys, 'key_blocks', None)
        return bool(keys and len(keys) > 1)
    except Exception:
        return False


def _sos_occluder_cache_state(obj) -> tuple:
    """Lightweight state for all-object depth occluders.

    Extra occluders are depth-only.  Using the full object-mode overlay state
    would hash mesh coordinates and scan large geometry on every redraw, which
    makes the option disproportionately expensive.  Dirty-generation updates
    from the depsgraph provide the geometry-change signal, while transform
    changes are handled by drawing the cached local batch with the current
    matrix_world.
    """
    data = getattr(obj, 'data', None)
    data_orig = getattr(data, 'original', data) if data is not None else None
    try:
        data_ptr = int(getattr(data_orig, 'as_pointer', lambda: 0)() or 0) if data_orig is not None else 0
    except Exception:
        data_ptr = 0
    try:
        obj_type = str(getattr(obj, 'type', '') or '')
    except Exception:
        obj_type = ''
    try:
        prefs = get_effective_settings(getattr(bpy, 'context', None))
    except Exception:
        prefs = None
    has_eval = bool(obj_type != 'MESH' or _mesh_object_has_viewport_modifiers(obj) or _sos_object_has_shape_key_deformation(obj))
    return (
        obj_type,
        str(type(data_orig).__name__ if data_orig is not None else ''),
        data_ptr,
        _safe_collection_len(data, 'vertices'),
        _safe_collection_len(data, 'edges'),
        _safe_collection_len(data, 'polygons'),
        _safe_collection_len(data, 'splines'),
        _safe_collection_len(data, 'points'),
        _safe_collection_len(data, 'curves'),
        _sos_curve_live_signature_for_cache(obj, data, prefs) if obj_type == 'CURVE' else (),
        _sos_dirty_generation_for_object(obj),
        _modifier_viewport_signature(obj) if has_eval else (),
    )


def _sos_prune_occluder_cache(max_entries: int = _SOS_OCCLUDER_CACHE_MAX_ENTRIES) -> None:
    try:
        limit = max(32, int(max_entries))
    except Exception:
        limit = _SOS_OCCLUDER_CACHE_MAX_ENTRIES
    try:
        overflow = len(_sos_occluder_batch_cache) - limit
    except Exception:
        overflow = 0
    if overflow <= 0:
        return
    for key in tuple(_sos_occluder_batch_cache.keys())[:overflow]:
        try:
            _sos_occluder_batch_cache.pop(key, None)
        except Exception:
            pass


def _sos_object_bounds_intersects_active_view(obj, vpm) -> bool:
    """Fast clip-space culling for depth-only occluders.

    Objects fully outside the active viewport cannot hide Smart Overlay elements
    in that viewport, so their occluder batch does not need to be built or drawn.
    The test is conservative: if any required bound data is missing, the object
    is kept.
    """
    if obj is None or vpm is None:
        return True
    try:
        bounds = tuple(getattr(obj, 'bound_box', ()) or ())
        if len(bounds) < 8:
            return True
        mw = getattr(obj, 'matrix_world', None)
        if mw is None:
            return True
        all_left = all_right = all_bottom = all_top = all_near = all_far = True
        for co in bounds:
            try:
                clip = vpm @ (mw @ Vector((float(co[0]), float(co[1]), float(co[2])))).to_4d()
                w = float(clip.w) if abs(float(clip.w)) > 1.0e-12 else 1.0e-12
                x = float(clip.x); y = float(clip.y); z = float(clip.z)
                all_left = all_left and (x < -w)
                all_right = all_right and (x > w)
                all_bottom = all_bottom and (y < -w)
                all_top = all_top and (y > w)
                all_near = all_near and (z < -w)
                all_far = all_far and (z > w)
            except Exception:
                return True
        # Do not reject objects solely because their bounds are in front of the
        # viewport near clip plane.  The Smart Overlay depth shader remaps all
        # depth into a clip-range-independent stable layer; if a near-camera
        # object is discarded here, it never writes the hidden depth pre-pass and
        # cannot occlude mesh/curve overlay elements.  Keep XY culling and far
        # culling for performance, but keep all near-side candidates.
        return not (all_left or all_right or all_bottom or all_top or all_far)
    except Exception:
        return True


def _sos_mesh_depth_tri_batch(me, shader):
    if me is None or shader is None:
        return None
    try:
        vc = len(getattr(me, 'vertices', ()) or ())
    except Exception:
        vc = 0
    if vc <= 0:
        return None
    try:
        me.calc_loop_triangles()
    except Exception:
        pass
    try:
        tri_count = len(getattr(me, 'loop_triangles', ()) or ())
    except Exception:
        tri_count = 0
    if tri_count <= 0:
        return None
    try:
        va = np.empty(vc * 3, dtype=np.float32)
        me.vertices.foreach_get('co', va)
        va = va.reshape(-1, 3)
        ti = np.empty(tri_count * 3, dtype=np.int32)
        me.loop_triangles.foreach_get('vertices', ti)
        return batch_for_shader(shader, 'TRIS', {'pos': va}, indices=ti.reshape(-1, 3))
    except Exception:
        return None



def _sos_mesh_depth_tri_cpu_data(me):
    if me is None:
        return None
    try:
        vc = len(getattr(me, 'vertices', ()) or ())
    except Exception:
        vc = 0
    if vc <= 0:
        return None
    try:
        me.calc_loop_triangles()
    except Exception:
        pass
    try:
        tri_count = len(getattr(me, 'loop_triangles', ()) or ())
    except Exception:
        tri_count = 0
    if tri_count <= 0:
        return None
    try:
        va = np.empty(vc * 3, dtype=np.float32)
        me.vertices.foreach_get('co', va)
        va = va.reshape(-1, 3).copy()
        ti = np.empty(tri_count * 3, dtype=np.int32)
        me.loop_triangles.foreach_get('vertices', ti)
        return {'verts': va, 'indices': ti.reshape(-1, 3).copy(), 'vert_count': int(vc), 'tri_count': int(tri_count)}
    except Exception:
        return None


def _sos_occluder_geometry_data(obj, depsgraph=None):
    if obj is None:
        return None
    try:
        obj_name = str(getattr(obj, 'name', '') or '')
        obj_ptr = int(getattr(obj, 'as_pointer', lambda: 0)() or 0)
    except Exception:
        obj_name = ''
        obj_ptr = 0
    if not obj_name:
        return None
    state = _sos_occluder_cache_state(obj)
    cache_key = ('OCCLUDER_GEOMETRY', obj_name, obj_ptr)
    entry = _sos_occluder_geometry_cache.get(cache_key)
    if isinstance(entry, dict) and entry.get('state') == state:
        data = entry.get('data')
        if isinstance(data, dict):
            return data, state
    obj_type = str(getattr(obj, 'type', '') or '')
    needs_evaluated = bool(obj_type != 'MESH' or _mesh_object_has_viewport_modifiers(obj) or _sos_object_has_shape_key_deformation(obj))
    eo = None
    me = None
    try:
        if needs_evaluated:
            if depsgraph is None:
                return None
            eo = obj.evaluated_get(depsgraph)
            try:
                me = eo.to_mesh(preserve_all_data_layers=False, depsgraph=depsgraph)
            except Exception:
                try:
                    me = eo.to_mesh()
                except Exception:
                    me = None
        else:
            me = getattr(obj, 'data', None)
        data = _sos_mesh_depth_tri_cpu_data(me)
    finally:
        if needs_evaluated:
            try:
                if eo is not None:
                    eo.to_mesh_clear()
            except Exception:
                pass
    if not isinstance(data, dict):
        return None
    _sos_occluder_geometry_cache[cache_key] = {'state': state, 'data': data}
    _sos_prune_occluder_geometry_cache()
    return data, state


def _sos_prune_occluder_geometry_cache(max_entries: int = _SOS_OCCLUDER_CACHE_MAX_ENTRIES) -> None:
    try:
        limit = max(32, int(max_entries))
        overflow = len(_sos_occluder_geometry_cache) - limit
    except Exception:
        overflow = 0
    if overflow <= 0:
        return
    for key in tuple(_sos_occluder_geometry_cache.keys())[:overflow]:
        try:
            _sos_occluder_geometry_cache.pop(key, None)
        except Exception:
            pass


def _sos_prune_occluder_group_cache(max_entries: int = _SOS_OCCLUDER_GROUP_CACHE_MAX_ENTRIES) -> None:
    try:
        limit = max(1, int(max_entries))
        overflow = len(_sos_occluder_group_cache) - limit
    except Exception:
        overflow = 0
    if overflow <= 0:
        return
    for key in tuple(_sos_occluder_group_cache.keys())[:overflow]:
        try:
            _sos_occluder_group_cache.pop(key, None)
        except Exception:
            pass


def _sos_matrix_world_signature(obj) -> tuple:
    try:
        mat = getattr(obj, 'matrix_world', None)
        if mat is None:
            return ()
        values = []
        for row in mat:
            for value in row:
                values.append(int(round(float(value) * 1000000.0)))
        return tuple(values)
    except Exception:
        return ()


def _sos_transform_occluder_vertices(verts, matrix_world):
    try:
        co = np.asarray(verts, dtype=np.float32)
        if co.size <= 0:
            return None
        mat = np.asarray(matrix_world, dtype=np.float32)
        return (co @ mat[:3, :3].T) + mat[:3, 3]
    except Exception:
        try:
            return np.asarray([matrix_world @ Vector((float(v[0]), float(v[1]), float(v[2]))) for v in verts], dtype=np.float32)
        except Exception:
            return None


def _sos_make_merged_occluder_batch(shader, candidates):
    if shader is None or not candidates:
        return None
    state_items = []
    for obj, data, geom_state in candidates:
        try:
            state_items.append((
                str(getattr(obj, 'name', '') or ''),
                int(getattr(obj, 'as_pointer', lambda: 0)() or 0),
                geom_state,
                _sos_matrix_world_signature(obj),
            ))
        except Exception:
            return None
    group_state = (id(shader), tuple(state_items))
    entry = _sos_occluder_group_cache.get(group_state)
    if isinstance(entry, dict):
        batch = entry.get('batch_tris')
        if batch is not None:
            return batch
    verts_chunks = []
    index_chunks = []
    offset = 0
    try:
        for obj, data, _geom_state in candidates:
            verts = data.get('verts') if isinstance(data, dict) else None
            indices = data.get('indices') if isinstance(data, dict) else None
            if verts is None or indices is None:
                continue
            world_verts = _sos_transform_occluder_vertices(verts, obj.matrix_world)
            if world_verts is None or len(world_verts) <= 0:
                continue
            idx = np.asarray(indices, dtype=np.int32)
            if idx.size <= 0:
                continue
            verts_chunks.append(world_verts.astype(np.float32, copy=False))
            index_chunks.append((idx + int(offset)).astype(np.int32, copy=False))
            offset += int(len(world_verts))
        if not verts_chunks or not index_chunks:
            return None
        merged_verts = np.concatenate(verts_chunks, axis=0)
        merged_indices = np.concatenate(index_chunks, axis=0)
        batch = batch_for_shader(shader, 'TRIS', {'pos': merged_verts}, indices=merged_indices)
        _sos_occluder_group_cache[group_state] = {'batch_tris': batch}
        _sos_prune_occluder_group_cache()
        return batch
    except Exception:
        return None

def _sos_object_can_be_depth_occluder(obj, prefs) -> bool:
    """Return True when an object can provide real surface depth only.

    The option that uses all other objects as occluders must not color those
    objects.  It only needs surface triangles that Blender can evaluate to a
    mesh.  Lattices, cameras, lights, empties, and other non-surface objects do
    not provide a reliable occlusion surface here.
    """
    if obj is None:
        return False
    try:
        obj_type = str(getattr(obj, 'type', '') or '')
    except Exception:
        obj_type = ''
    if obj_type == 'MESH':
        return True
    # Curves, fonts, metas, and the newer Curves type can be converted to an
    # evaluated mesh and therefore can act as depth-only occluders.  This is
    # deliberately independent from the Mesh and Curve Overlay display-target filter:
    # these objects receive no Smart Overlay colors, only hidden depth.
    if obj_type in {'CURVE', 'SURFACE', 'FONT', 'META', 'CURVES'}:
        return True
    return False


def _sos_object_is_extra_depth_occluder(context, obj, prefs, exclude_names, region=None, rv3d=None) -> bool:
    if obj is None:
        return False
    try:
        obj_name = str(getattr(obj, 'name', '') or '')
    except Exception:
        obj_name = ''
    if not obj_name or obj_name in exclude_names:
        return False
    if not _sos_object_can_be_depth_occluder(obj, prefs):
        return False
    try:
        if bool(obj.select_get()):
            return False
    except Exception:
        pass
    try:
        if str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT') != 'OBJECT':
            return False
    except Exception:
        pass
    try:
        if bool(obj.hide_get()):
            return False
    except Exception:
        pass
    return _sos_object_visible_in_view3d(context, obj, region, rv3d)


def _collect_extra_occluder_batches(context, prefs, shader, exclude_names=()) -> list:
    """Collect one merged depth-only occluder batch for all eligible objects.

    The all-object occluder option is expensive if every object is converted and
    drawn separately every redraw.  This path performs conservative viewport
    bounds culling, reuses lightweight per-object CPU triangle caches, and merges
    the visible occluders into a single world-space depth batch.  The draw pass
    then pays one depth-only draw call instead of one draw call per occluder.
    """
    batches = []
    try:
        if not bool(getattr(prefs, 'use_all_objects_as_occluders', False)):
            return batches
    except Exception:
        return batches
    if shader is None:
        return batches
    try:
        ctx = context or bpy.context
    except Exception:
        ctx = context
    try:
        region = getattr(ctx, 'region', None)
        rv3d = getattr(ctx, 'region_data', None)
    except Exception:
        region = rv3d = None
    try:
        depsgraph = ctx.evaluated_depsgraph_get()
    except Exception:
        depsgraph = None
    try:
        scene = getattr(ctx, 'scene', None)
    except Exception:
        scene = None
    if scene is None:
        return batches
    try:
        exclude = {str(n) for n in (exclude_names or ()) if str(n or '')}
    except Exception:
        exclude = set()
    try:
        visible_objects = tuple(getattr(ctx, 'visible_objects', None) or ())
    except Exception:
        visible_objects = ()
    if not visible_objects:
        try:
            visible_objects = tuple(getattr(scene, 'objects', ()) or ())
        except Exception:
            visible_objects = ()
    try:
        vpm = getattr(rv3d, 'window_matrix', None) @ getattr(rv3d, 'view_matrix', None)
    except Exception:
        vpm = None

    candidates = []
    for obj in visible_objects:
        if not _sos_object_is_extra_depth_occluder(ctx, obj, prefs, exclude, region, rv3d):
            continue
        if not _sos_object_bounds_intersects_active_view(obj, vpm):
            continue
        try:
            result = _sos_occluder_geometry_data(obj, depsgraph)
            if not result:
                continue
            data, geom_state = result
            if isinstance(data, dict) and data.get('verts') is not None and data.get('indices') is not None:
                candidates.append((obj, data, geom_state))
        except Exception:
            continue

    batch = _sos_make_merged_occluder_batch(shader, candidates)
    if batch is None:
        return batches
    try:
        b = SOS_BatchData(Matrix.Identity(4))
    except Exception:
        try:
            b = SOS_BatchData(bpy.context.object.matrix_world.copy())
        except Exception:
            return batches
    b.occluder_only = True
    b.batch_tris = batch
    batches.append(b)
    return batches

def _sos_should_preserve_evaluated_face_cache_for_context(context=None, prefs=None) -> bool:
    """Return True while edit-mode evaluated face overlay should stay resident.

    The evaluated visible/occluded face fill does not depend on element selection,
    so clearing its CPU cache during multi-object edit selection/depsgraph churn
    makes the draw path alternate between evaluated faces and edit-cage fallback.
    Keep the last evaluated face CPU result resident whenever the feature is on;
    geometry signatures still decide whether the cached batch is current enough to
    draw, and a fresh rebuild is queued when geometry or modifier state changes.
    """
    try:
        ctx = context or getattr(bpy, 'context', None)
        prefs = prefs or get_effective_settings(ctx)
        if prefs is None or not bool(getattr(prefs, 'use_evaluated_edit_mode_face_overlay', False)):
            return False
        try:
            edit_objects = tuple(_sos_iter_edit_mesh_objects_for_live_transform(ctx))
        except Exception:
            edit_objects = ()
        if not edit_objects:
            try:
                edit_objects = tuple(
                    obj for obj in bpy.data.objects
                    if getattr(obj, 'type', None) == 'MESH' and getattr(obj, 'mode', None) == 'EDIT'
                )
            except Exception:
                edit_objects = ()
        return any(_has_visible_edit_mode_modifier(obj) for obj in edit_objects)
    except Exception:
        return False


def _sos_should_preserve_evaluated_face_cache_on_invalidate(obj_name: str) -> bool:
    """Keep edit-mode modifier-evaluated face CPU data through selection churn.

    Other cache classes are still invalidated normally, so topology, vertex, edge,
    selected-face, hover, and diagnostic data rebuild from the live BMesh.  Only
    the evaluated visible/occluded face-fill CPU cache is retained; its state key
    still prevents drawing stale geometry when coordinates or modifiers change.
    """
    if not obj_name:
        return False
    try:
        ctx = getattr(bpy, 'context', None)
        if not _sos_should_preserve_evaluated_face_cache_for_context(ctx):
            return False
        try:
            named_obj = bpy.data.objects.get(str(obj_name))
        except Exception:
            named_obj = None
        if named_obj is not None:
            try:
                if (
                    getattr(named_obj, 'type', None) == 'MESH'
                    and getattr(named_obj, 'mode', None) == 'EDIT'
                    and _has_visible_edit_mode_modifier(named_obj)
                ):
                    return True
            except Exception:
                pass
        objs = getattr(ctx, 'objects_in_mode', None) or ()
        if not objs:
            active = getattr(ctx, 'object', None) or getattr(ctx, 'active_object', None)
            objs = (active,) if active is not None else ()
        for edit_obj in objs:
            try:
                if getattr(edit_obj, 'type', None) == 'MESH' and str(getattr(edit_obj, 'name', '') or '') == str(obj_name):
                    return True
            except Exception:
                continue
    except Exception:
        return False
    return False


def _invalidate_object_cache(obj_name: str, *, preserve_evaluated_face_cache: bool = False, bump_dirty_generation: bool = True) -> None:
    _sos_xform_sig_bump()
    if not obj_name:
        return
    if bool(bump_dirty_generation):
        _sos_bump_dirty_generation(obj_name)
    remove_keys = []
    for key in tuple(_sos_base_cache.keys()):
        try:
            if not isinstance(key, tuple) or len(key) < 2:
                continue
            if str(key[1]) != str(obj_name):
                continue
            if key[0] not in {'EDIT', 'EDIT_EVAL', 'EDIT_EVAL_CPU', 'OBJECT', 'OCCLUDER_ONLY'}:
                continue
            remove_keys.append(key)
        except Exception:
            continue
    for key in remove_keys:
        try:
            _sos_base_cache.pop(key, None)
        except Exception:
            pass
    for key in tuple(_sos_occluder_batch_cache.keys()):
        try:
            if isinstance(key, tuple) and len(key) > 1 and str(key[1]) == str(obj_name):
                _sos_occluder_batch_cache.pop(key, None)
        except Exception:
            pass
    for key in tuple(_sos_occluder_geometry_cache.keys()):
        try:
            if isinstance(key, tuple) and len(key) > 1 and str(key[1]) == str(obj_name):
                _sos_occluder_geometry_cache.pop(key, None)
        except Exception:
            pass
    try:
        _sos_occluder_group_cache.clear()
    except Exception:
        pass
    preserve_eval_faces = bool(preserve_evaluated_face_cache or _sos_should_preserve_evaluated_face_cache_on_invalidate(obj_name))
    if not preserve_eval_faces:
        for key in tuple(_sos_eval_face_cpu_cache.keys()):
            try:
                if isinstance(key, tuple) and len(key) > 1 and str(key[1]) == str(obj_name):
                    _sos_eval_face_cpu_cache.pop(key, None)
            except Exception:
                pass
        for key in tuple(_sos_eval_face_rebuild_queue.keys()):
            try:
                if isinstance(key, tuple) and len(key) > 1 and str(key[1]) == str(obj_name):
                    _sos_eval_face_rebuild_queue.pop(key, None)
            except Exception:
                pass
    # Evaluated native edge diagnostics (Seam / Sharp / Crease / Bevel) must never
    # be preserved by the evaluated-face flicker guard. Their source attributes can
    # change without vertex coordinates or topology changing, so preserving this
    # cache causes stale seam/crease lines after settings changes or mesh edits.
    for key in tuple(_sos_eval_native_edge_cpu_cache.keys()):
        try:
            if isinstance(key, tuple) and len(key) > 1 and str(key[1]) == str(obj_name):
                _sos_eval_native_edge_cpu_cache.pop(key, None)
        except Exception:
            pass
    for key in tuple(_sos_topology_batch_cache.keys()):
        try:
            if isinstance(key, tuple) and len(key) > 1 and str(key[1]) == str(obj_name):
                _sos_topology_batch_cache.pop(key, None)
        except Exception:
            pass



def _sos_prune_base_cache(max_entries: int = _SOS_BASE_CACHE_MAX_ENTRIES) -> None:
    """Bound draw-cache memory without changing overlay output.

    Dict insertion order keeps recently rebuilt entries at the end.  Removing
    the oldest surplus entries only causes a later rebuild; it does not alter
    which vertices, edges, faces, or hover elements are drawn.
    """
    try:
        limit = int(max_entries)
    except Exception:
        limit = _SOS_BASE_CACHE_MAX_ENTRIES
    if limit <= 0:
        return
    try:
        overflow = len(_sos_base_cache) - limit
    except Exception:
        overflow = 0
    if overflow <= 0:
        return
    for key in tuple(_sos_base_cache.keys())[:overflow]:
        try:
            _sos_base_cache.pop(key, None)
        except Exception:
            pass


def _sos_invalidate_all_overlay_geometry_caches(*, preserve_evaluated_face_cache: bool = False) -> None:
    """Invalidate geometry-dependent overlay caches without touching Blender RNA data.

    This helper is intentionally limited to Python dictionaries.  It is safe to
    call from depsgraph callbacks where reading Object.data can enter Blender's
    evaluated mesh wrapper while IDs are being deleted or rebuilt.
    """
    _sos_xform_sig_bump()
    try:
        _sos_base_cache.clear()
    except Exception:
        pass
    try:
        _sos_topology_batch_cache.clear()
    except Exception:
        pass
    try:
        _sos_occluder_batch_cache.clear()
    except Exception:
        pass
    try:
        _sos_occluder_geometry_cache.clear()
    except Exception:
        pass
    try:
        _sos_occluder_group_cache.clear()
    except Exception:
        pass
    if not preserve_evaluated_face_cache:
        try:
            preserve_evaluated_face_cache = bool(_sos_should_preserve_evaluated_face_cache_for_context())
        except Exception:
            preserve_evaluated_face_cache = False
    if not preserve_evaluated_face_cache:
        try:
            _sos_eval_face_cpu_cache.clear()
        except Exception:
            pass
        try:
            _sos_eval_native_edge_cpu_cache.clear()
        except Exception:
            pass
        try:
            _sos_eval_face_rebuild_queue.clear()
        except Exception:
            pass
        try:
            _sos_eval_face_last_rebuild_time.clear()
            _sos_eval_face_last_build_duration.clear()
        except Exception:
            pass
    else:
        try:
            _sos_eval_native_edge_cpu_cache.clear()
        except Exception:
            pass


def _iter_mesh_user_object_names(mesh) -> tuple[str, ...]:
    # Do not resolve Mesh -> Object users by scanning bpy.data.objects here.
    # In Blender 5.1, reading Object.data from a depsgraph callback can force
    # BKE_mesh_wrapper_ensure_subdivision while datablocks are being duplicated,
    # deleted, or rebuilt.  That path can crash before Python can catch it.
    # Unknown mesh users are handled by a conservative cache-wide invalidation in
    # _sos_depsgraph_update instead.
    return ()


def _touch_edit_live_sync(duration: float = 0.30) -> None:
    global _sos_edit_live_sync_until
    try:
        _sos_edit_live_sync_until = max(float(_sos_edit_live_sync_until), time.time() + max(0.0, float(duration)))
    except Exception:
        _sos_edit_live_sync_until = time.time() + 0.30


def _sos_modal_transform_signature(context=None) -> tuple:
    """Return active modal transform operators and their live preview values.

    Blender keeps transform tools such as Move/Rotate/Scale in
    Window.modal_operators while the user is dragging.  WindowManager.operators is
    only history-like, so relying on it makes Smart Overlay update only after the
    transform is confirmed.  This signature is read-only and does not install a
    modal handler or keymap.
    """
    ctx = context or getattr(bpy, 'context', None)
    windows = []
    try:
        win = getattr(ctx, 'window', None)
        if win is not None:
            windows.append(win)
    except Exception:
        pass
    try:
        wm = getattr(ctx, 'window_manager', None) or getattr(bpy.context, 'window_manager', None)
        for win in getattr(wm, 'windows', ()) or ():
            if win not in windows:
                windows.append(win)
    except Exception:
        pass
    transform_ids = {
        'TRANSFORM_OT_translate', 'TRANSFORM_OT_resize', 'TRANSFORM_OT_rotate',
        'TRANSFORM_OT_transform', 'TRANSFORM_OT_shear', 'TRANSFORM_OT_tosphere',
        'TRANSFORM_OT_bend', 'TRANSFORM_OT_mirror', 'TRANSFORM_OT_shrink_fatten',
        'TRANSFORM_OT_skin_resize', 'TRANSFORM_OT_push_pull', 'TRANSFORM_OT_edge_slide',
        'TRANSFORM_OT_vert_slide', 'TRANSFORM_OT_seq_slide', 'TRANSFORM_OT_translate_to_origin',
    }
    sig = []
    for win in windows:
        try:
            modal_ops = tuple(getattr(win, 'modal_operators', ()) or ())
        except Exception:
            modal_ops = ()
        for op in modal_ops:
            try:
                op_id = str(getattr(op, 'bl_idname', '') or '')
            except Exception:
                op_id = ''
            if op_id not in transform_ids:
                continue
            props = None
            try:
                props = getattr(op, 'properties', None)
            except Exception:
                props = None
            values = []
            if props is not None:
                for name in (
                    'value', 'orient_axis', 'orient_type', 'orient_matrix_type',
                    'constraint_axis', 'mirror', 'use_proportional_edit',
                    'proportional_edit_falloff', 'proportional_size',
                    'use_proportional_connected', 'use_proportional_projected',
                    'snap', 'snap_elements', 'snap_target', 'release_confirm',
                ):
                    try:
                        value = getattr(props, name)
                    except Exception:
                        continue
                    try:
                        if isinstance(value, (set, frozenset)):
                            value = tuple(sorted(str(v) for v in value))
                        elif hasattr(value, '__len__') and hasattr(value, '__getitem__') and not isinstance(value, (str, bytes)):
                            value = tuple(round(float(value[i]), 7) if isinstance(value[i], (float, int)) else str(value[i]) for i in range(len(value)))
                        elif hasattr(value, '__iter__') and not isinstance(value, (str, bytes)):
                            value = tuple(round(float(v), 7) if isinstance(v, (float, int)) else str(v) for v in value)
                        elif isinstance(value, float):
                            value = round(float(value), 7)
                    except Exception:
                        value = str(value)
                    values.append((name, value))
            try:
                _mouse_xy = _sos_current_window_mouse_xy(ctx)
                if _mouse_xy is not None:
                    values.append(('mouse_window', (int(_mouse_xy[0]), int(_mouse_xy[1]))))
            except Exception:
                pass
            try:
                ptr = int(op.as_pointer())
            except Exception:
                ptr = id(op)
            sig.append((op_id, ptr, tuple(values)))
    return tuple(sig)



def _sos_iter_edit_mesh_objects_for_live_transform(context=None) -> tuple:
    """Return edit-mode mesh objects even when a modal transform draw context is stale.

    During Blender's modal transform operators, draw callbacks and timers can be
    executed with ``bpy.context`` pointing at the last UI region instead of the
    active 3D View edit context.  Relying only on ``context.mode`` or
    ``context.objects_in_mode`` then makes the overlay reuse stale batches until
    the transform is confirmed.  This helper is deliberately read-only and only
    gathers object references; it does not touch mesh data or modifier data.
    """
    ctx = context or getattr(bpy, 'context', None)
    result = []
    seen = set()

    def add(obj):
        if obj is None:
            return
        try:
            if getattr(obj, 'type', None) != 'MESH':
                return
            if getattr(obj, 'mode', None) != 'EDIT':
                return
            ptr = int(getattr(obj, 'as_pointer', lambda: 0)() or 0)
        except Exception:
            return
        if ptr in seen:
            return
        seen.add(ptr)
        result.append(obj)

    for attr in ('objects_in_mode_unique_data', 'objects_in_mode', 'selected_editable_objects', 'selected_objects'):
        try:
            for obj in (getattr(ctx, attr, None) or ()):  # type: ignore[arg-type]
                # add() keeps only objects in edit mode; checking the mode first
                # skips the call for every object add() would reject.
                try:
                    if getattr(obj, 'mode', None) != 'EDIT':
                        continue
                except Exception:
                    continue
                add(obj)
        except Exception:
            pass
    for attr in ('edit_object', 'object', 'active_object'):
        try:
            add(getattr(ctx, attr, None))
        except Exception:
            pass
    try:
        view_layer = getattr(ctx, 'view_layer', None)
        add(getattr(getattr(view_layer, 'objects', None), 'active', None))
    except Exception:
        pass

    # Last-resort fallback is used only while a modal transform is actually
    # running.  Scanning bpy.data.objects on every normal viewport redraw is costly
    # in large scenes and was a major source of the post-install slowdown.
    if not result:
        allow_global_scan = False
        try:
            allow_global_scan = bool(_sos_modal_transform_signature(ctx))
        except Exception:
            allow_global_scan = False
        if allow_global_scan:
            try:
                for obj in getattr(bpy.data, 'objects', ()) or ():
                    add(obj)
            except Exception:
                pass
    return tuple(result)


def _sos_has_live_edit_mesh_context(context=None) -> bool:
    try:
        return bool(_sos_iter_edit_mesh_objects_for_live_transform(context))
    except Exception:
        return False

def _sos_active_modal_transform_operator(context=None):
    """Return the newest active modal transform operator, if any."""
    ctx = context or getattr(bpy, 'context', None)
    transform_ids = {
        'TRANSFORM_OT_translate', 'TRANSFORM_OT_resize', 'TRANSFORM_OT_rotate',
        'TRANSFORM_OT_transform', 'TRANSFORM_OT_shear', 'TRANSFORM_OT_tosphere',
        'TRANSFORM_OT_bend', 'TRANSFORM_OT_mirror', 'TRANSFORM_OT_shrink_fatten',
        'TRANSFORM_OT_skin_resize', 'TRANSFORM_OT_push_pull', 'TRANSFORM_OT_edge_slide',
        'TRANSFORM_OT_vert_slide', 'TRANSFORM_OT_seq_slide', 'TRANSFORM_OT_translate_to_origin',
    }
    windows = []
    try:
        win = getattr(ctx, 'window', None)
        if win is not None:
            windows.append(win)
    except Exception:
        pass
    try:
        wm = getattr(ctx, 'window_manager', None) or getattr(bpy.context, 'window_manager', None)
        for win in getattr(wm, 'windows', ()) or ():
            if win not in windows:
                windows.append(win)
    except Exception:
        pass
    found = None
    for win in windows:
        try:
            modal_ops = tuple(getattr(win, 'modal_operators', ()) or ())
        except Exception:
            modal_ops = ()
        for op in modal_ops:
            try:
                op_id = str(getattr(op, 'bl_idname', '') or '')
            except Exception:
                op_id = ''
            if op_id in transform_ids:
                found = op
    return found


def _sos_modal_transform_key(op, obj) -> tuple:
    try:
        op_ptr = int(op.as_pointer())
    except Exception:
        op_ptr = id(op)
    try:
        obj_ptr = int(obj.as_pointer())
    except Exception:
        obj_ptr = id(obj)
    return (op_ptr, obj_ptr, str(getattr(obj, 'name', '') or ''))




def _sos_current_window_mouse_xy(context=None):
    """Return current coordinates for the context Blender window."""
    ctx = context or getattr(bpy, 'context', None)
    try:
        sample = _sos_passive_mouse_sample(ctx)
        if sample is not None:
            win, mx, my = sample
            ctx_win = getattr(ctx, 'window', None)
            if ctx_win is None or _sos_pointer(ctx_win) == _sos_pointer(win):
                return int(mx), int(my)
    except Exception:
        pass
    try:
        if _sos_pointer(getattr(ctx, 'window', None)) == int(_sos_mouse_window_ptr or 0):
            mx = int(_sos_mouse_window_x)
            my = int(_sos_mouse_window_y)
            if mx >= 0 and my >= 0:
                return mx, my
    except Exception:
        pass
    return None

def _sos_current_region_mouse_xy(context=None, region=None):
    ctx = context or getattr(bpy, 'context', None)
    reg = region or getattr(ctx, 'region', None)
    if reg is None:
        return None
    mouse = _sos_current_window_mouse_xy(ctx)
    if mouse is None:
        return None
    try:
        mx = int(mouse[0]) - int(getattr(reg, 'x', 0) or 0)
        my = int(mouse[1]) - int(getattr(reg, 'y', 0) or 0)
        w = int(getattr(reg, 'width', 0) or 0)
        h = int(getattr(reg, 'height', 0) or 0)
    except Exception:
        return None
    if 0 <= mx < w and 0 <= my < h:
        return float(mx), float(my)
    return None


def _sos_modal_transform_constraint_axes(props):
    try:
        axes = tuple(bool(v) for v in getattr(props, 'constraint_axis', (False, False, False)))
        if len(axes) >= 3:
            return axes[:3]
    except Exception:
        pass
    return (False, False, False)


def _sos_modal_transform_orient_axes_world(props):
    try:
        om = getattr(props, 'orient_matrix', None)
        mat = Matrix(om) if om is not None else Matrix.Identity(3)
        if hasattr(mat, 'to_3x3'):
            mat = mat.to_3x3()
        try:
            if abs(float(mat.determinant())) < 1e-10:
                mat = Matrix.Identity(3)
        except Exception:
            mat = Matrix.Identity(3)
    except Exception:
        mat = Matrix.Identity(3)
    axes = []
    for i, fallback in enumerate((Vector((1,0,0)), Vector((0,1,0)), Vector((0,0,1)))):
        try:
            a = mat.col[i].to_3d() if hasattr(mat, 'col') else fallback
            if a.length <= 1e-12:
                a = fallback.copy()
            else:
                a.normalize()
        except Exception:
            a = fallback.copy()
        axes.append(a)
    return tuple(axes)


def _sos_constrain_world_delta_for_modal_transform(delta_world, props):
    try:
        axes = _sos_modal_transform_constraint_axes(props)
        if not any(axes):
            return delta_world
        orient_axes = _sos_modal_transform_orient_axes_world(props)
        out = Vector((0.0, 0.0, 0.0))
        for use, axis in zip(axes, orient_axes):
            if use:
                try:
                    out += axis * float(delta_world.dot(axis))
                except Exception:
                    pass
        return out
    except Exception:
        return delta_world


def _sos_modal_transform_view_axis_local(context, obj):
    try:
        rv3d = getattr(context, 'region_data', None)
        if rv3d is not None:
            axis_world = rv3d.view_matrix.inverted_safe().to_3x3() @ Vector((0.0, 0.0, 1.0))
            if axis_world.length > 1e-12:
                axis_world.normalize()
                return obj.matrix_world.inverted_safe().to_3x3() @ axis_world
    except Exception:
        pass
    return None


def _sos_modal_transform_mouse_fallback(context, obj, entry, pivot_local):
    """Return current mouse fallback data for live modal transforms.

    This is strictly read-only.  It does not install a modal operator and does not
    write to the edit mesh.  It lets the overlay follow Blender's in-progress
    transform preview in cases where Blender has not yet committed BMesh coords
    and the active transform RNA value is still the identity/zero value.
    """
    ctx = context or getattr(bpy, 'context', None)
    region = getattr(ctx, 'region', None)
    rv3d = getattr(ctx, 'region_data', None)
    if region is None or rv3d is None or obj is None or not isinstance(entry, dict):
        return None
    current_mouse = _sos_current_region_mouse_xy(ctx, region)
    if current_mouse is None:
        return None
    try:
        if 'start_mouse_region' not in entry:
            entry['start_mouse_region'] = (float(current_mouse[0]), float(current_mouse[1]))
            entry['mouse_region_ptr'] = _sos_pointer(region)
            entry['view_sig'] = _sos_clip_stable_matrix_signature(rv3d)
        start_mouse = entry.get('start_mouse_region')
        if start_mouse is None:
            return None
        smx, smy = float(start_mouse[0]), float(start_mouse[1])
        cmx, cmy = float(current_mouse[0]), float(current_mouse[1])
        if abs(cmx - smx) < _SOS_EDIT_TRANSFORM_MOUSE_FALLBACK_EPS and abs(cmy - smy) < _SOS_EDIT_TRANSFORM_MOUSE_FALLBACK_EPS:
            return None
        pivot_vec = Vector((float(pivot_local[0]), float(pivot_local[1]), float(pivot_local[2])))
        pivot_world = obj.matrix_world @ pivot_vec
        return {
            'region': region,
            'rv3d': rv3d,
            'start_mouse': (smx, smy),
            'current_mouse': (cmx, cmy),
            'pivot_local': pivot_vec,
            'pivot_world': pivot_world,
        }
    except Exception:
        return None


def _sos_modal_translate_delta_from_mouse(fallback, props, obj):
    try:
        region = fallback['region']
        rv3d = fallback['rv3d']
        pivot_world = fallback['pivot_world']
        sm = fallback['start_mouse']
        cm = fallback['current_mouse']
        start_world = view3d_utils.region_2d_to_location_3d(region, rv3d, sm, pivot_world)
        current_world = view3d_utils.region_2d_to_location_3d(region, rv3d, cm, pivot_world)
        delta_world = current_world - start_world
        delta_world = _sos_constrain_world_delta_for_modal_transform(delta_world, props)
        try:
            return obj.matrix_world.inverted_safe().to_3x3() @ delta_world
        except Exception:
            return delta_world
    except Exception:
        return None


def _sos_modal_rotate_angle_axis_from_mouse(fallback, props, obj, context=None):
    try:
        region = fallback['region']
        rv3d = fallback['rv3d']
        pivot_world = fallback['pivot_world']
        pivot_screen = view3d_utils.location_3d_to_region_2d(region, rv3d, pivot_world)
        if pivot_screen is None:
            return None, None
        sm = fallback['start_mouse']
        cm = fallback['current_mouse']
        v0 = Vector((float(sm[0]) - float(pivot_screen.x), float(sm[1]) - float(pivot_screen.y)))
        v1 = Vector((float(cm[0]) - float(pivot_screen.x), float(cm[1]) - float(pivot_screen.y)))
        if v0.length <= 2.0 or v1.length <= 2.0:
            return None, None
        a0 = math.atan2(float(v0.y), float(v0.x))
        a1 = math.atan2(float(v1.y), float(v1.x))
        angle = a1 - a0
        while angle > math.pi:
            angle -= math.tau
        while angle < -math.pi:
            angle += math.tau
        axis = None
        try:
            if str(getattr(props, 'orient_type', '') or '').upper() == 'VIEW':
                axis = _sos_modal_transform_view_axis_local(context or getattr(bpy, 'context', None), obj)
        except Exception:
            axis = None
        if axis is None:
            axis = _sos_modal_transform_axis_local(props, obj)
        try:
            if axis.length <= 1e-12:
                axis = Vector((0.0, 0.0, 1.0))
            else:
                axis.normalize()
        except Exception:
            axis = Vector((0.0, 0.0, 1.0))
        return float(angle), axis
    except Exception:
        return None, None


def _sos_modal_scale_from_mouse(fallback, props):
    try:
        region = fallback['region']
        rv3d = fallback['rv3d']
        pivot_world = fallback['pivot_world']
        pivot_screen = view3d_utils.location_3d_to_region_2d(region, rv3d, pivot_world)
        if pivot_screen is None:
            return None
        sm = fallback['start_mouse']
        cm = fallback['current_mouse']
        d0 = math.hypot(float(sm[0]) - float(pivot_screen.x), float(sm[1]) - float(pivot_screen.y))
        d1 = math.hypot(float(cm[0]) - float(pivot_screen.x), float(cm[1]) - float(pivot_screen.y))
        if d0 <= 2.0 or not math.isfinite(d0) or not math.isfinite(d1):
            return None
        factor = max(1.0e-5, min(1.0e5, d1 / d0))
        axes = _sos_modal_transform_constraint_axes(props)
        if any(axes):
            return np.array(tuple(factor if use else 1.0 for use in axes), dtype=np.float32)
        return np.array((factor, factor, factor), dtype=np.float32)
    except Exception:
        return None

def _sos_clear_stale_edit_transform_baselines(active_signature=None) -> None:
    global _sos_edit_transform_baseline_cache
    try:
        if active_signature:
            return
        _sos_edit_transform_baseline_cache.clear()
    except Exception:
        _sos_edit_transform_baseline_cache = {}


def _sos_modal_transform_value_tuple(props, name, default=()):
    try:
        value = getattr(props, name)
    except Exception:
        return default
    try:
        return tuple(float(v) for v in value)
    except Exception:
        try:
            return (float(value),)
        except Exception:
            return default


def _sos_modal_transform_axis_local(props, obj):
    try:
        axis_name = str(getattr(props, 'orient_axis', 'Z') or 'Z').upper()
    except Exception:
        axis_name = 'Z'
    axis_world = Vector((0.0, 0.0, 1.0))
    try:
        om = getattr(props, 'orient_matrix', None)
        mat = Matrix(om) if om is not None else Matrix.Identity(3)
        # Some invoked operators expose a zero orient_matrix until the first real
        # mouse event.  Use global axes in that case.
        try:
            if abs(float(mat.determinant())) < 1e-10:
                mat = Matrix.Identity(3)
        except Exception:
            mat = Matrix.Identity(3)
        idx = 0 if axis_name == 'X' else (1 if axis_name == 'Y' else 2)
        axis_world = mat.col[idx].to_3d() if hasattr(mat, 'col') else Vector((0.0, 0.0, 1.0))
    except Exception:
        axis_world = {'X': Vector((1, 0, 0)), 'Y': Vector((0, 1, 0)), 'Z': Vector((0, 0, 1))}.get(axis_name, Vector((0, 0, 1)))
    try:
        inv3 = obj.matrix_world.inverted_safe().to_3x3()
        axis_local = inv3 @ axis_world
    except Exception:
        axis_local = axis_world
    try:
        if axis_local.length <= 1e-12:
            axis_local = Vector((0.0, 0.0, 1.0))
        else:
            axis_local.normalize()
    except Exception:
        axis_local = Vector((0.0, 0.0, 1.0))
    return axis_local


def _sos_falloff_weight(t: float, falloff: str = 'SMOOTH') -> float:
    try:
        t = max(0.0, min(1.0, float(t)))
    except Exception:
        t = 0.0
    f = str(falloff or 'SMOOTH').upper()
    if f == 'CONSTANT':
        return 1.0 if t < 1.0 else 0.0
    if f == 'LINEAR':
        return 1.0 - t
    if f == 'SHARP':
        return (1.0 - t) ** 2
    if f == 'ROOT':
        return math.sqrt(max(0.0, 1.0 - t))
    if f == 'SPHERE':
        return math.sqrt(max(0.0, 1.0 - t * t))
    if f == 'INVERSE_SQUARE':
        return (1.0 - t) * (1.0 - t)
    # Blender's smooth falloff is close enough for overlay preview.
    return 3.0 * (1.0 - t) ** 2 - 2.0 * (1.0 - t) ** 3


def _sos_modal_transform_weights(coords, selected_mask, props):
    try:
        use_prop = bool(getattr(props, 'use_proportional_edit', False))
    except Exception:
        use_prop = False
    weights = np.zeros((len(coords),), dtype=np.float32)
    try:
        weights[selected_mask] = 1.0
    except Exception:
        pass
    if not use_prop:
        return weights
    try:
        radius = float(getattr(props, 'proportional_size', 0.0) or 0.0)
    except Exception:
        radius = 0.0
    if radius <= 1e-12:
        return weights
    try:
        selected = coords[selected_mask]
        if selected.size == 0:
            return weights
        falloff = str(getattr(props, 'proportional_edit_falloff', 'SMOOTH') or 'SMOOTH')
        # Keep this bounded; if many selected vertices exist, sample enough to make
        # proportional preview stable without turning the overlay into a transform solver.
        if len(selected) > 256:
            selected = selected[np.linspace(0, len(selected) - 1, 256).astype(np.int32)]
        for i in range(len(coords)):
            if weights[i] >= 1.0:
                continue
            try:
                d = float(np.sqrt(((selected - coords[i]) ** 2).sum(axis=1).min()))
            except Exception:
                continue
            if d <= radius:
                weights[i] = max(float(weights[i]), float(_sos_falloff_weight(d / radius, falloff)))
    except Exception:
        pass
    return weights


def _sos_apply_modal_edit_transform_preview(obj, bm, coords, context=None):
    """Return coords with Blender's active modal transform preview applied.

    During modal transforms Blender may not commit BMesh coordinates until confirm,
    while the viewport shows an internal preview.  Smart Overlay has to draw the
    same preview layer, otherwise cached overlay batches visually stay behind and
    jump only after confirmation.
    """
    global _sos_edit_transform_baseline_cache
    op = _sos_active_modal_transform_operator(context)
    if op is None or obj is None or bm is None or coords is None:
        return coords
    try:
        op_id = str(getattr(op, 'bl_idname', '') or '')
        props = getattr(op, 'properties', None)
    except Exception:
        return coords
    if props is None or len(coords) == 0:
        return coords
    try:
        # Use coordinates from the first draw of this modal operator as the base,
        # so the preview does not double-transform if Blender later changes RNA state.
        key = _sos_modal_transform_key(op, obj)
        entry = _sos_edit_transform_baseline_cache.get(key)
        if not isinstance(entry, dict) or entry.get('shape') != tuple(coords.shape):
            entry = {'coords': np.array(coords, dtype=np.float32, copy=True), 'shape': tuple(coords.shape), 'time': time.time()}
            _sos_edit_transform_baseline_cache[key] = entry
            if len(_sos_edit_transform_baseline_cache) > _SOS_EDIT_TRANSFORM_BASELINE_CACHE_LIMIT:
                for old_key in list(_sos_edit_transform_baseline_cache.keys())[:-_SOS_EDIT_TRANSFORM_BASELINE_CACHE_LIMIT]:
                    _sos_edit_transform_baseline_cache.pop(old_key, None)
        base = np.array(entry.get('coords', coords), dtype=np.float32, copy=True)
    except Exception:
        base = np.array(coords, dtype=np.float32, copy=True)
    try:
        selected_mask = np.zeros((len(base),), dtype=bool)
        for v in bm.verts:
            try:
                idx = int(v.index)
                if 0 <= idx < len(selected_mask) and bool(getattr(v, 'select', False)) and not bool(getattr(v, 'hide', False)):
                    selected_mask[idx] = True
            except Exception:
                pass
        if not bool(selected_mask.any()):
            return coords
    except Exception:
        return coords
    # If Blender is already publishing live BMesh coordinates during the modal
    # transform, trust those coordinates directly.  Some platforms/tools update
    # BMesh every mouse event, while others keep BMesh at the pre-transform state
    # and only expose a viewport preview.  Always forcing the first-draw baseline
    # through the fallback solver can make the overlay lag behind a live BMesh or
    # double-apply movement.
    try:
        cur = np.asarray(coords, dtype=np.float32)
        if cur.shape == base.shape:
            # Do not limit this check to currently selected vertices.  During
            # proportional editing, modifier-edit preview, or Blender's internal
            # modal-transform update path, affected but unselected vertices can be
            # the first coordinates that prove the BMesh is live.  Any coordinate
            # motion means the safest overlay source is the live BMesh, not the
            # first-draw baseline.
            delta_all = cur - base
            if delta_all.size and float(np.max(np.linalg.norm(delta_all, axis=1))) > 1.0e-6:
                try:
                    entry['coords'] = np.array(cur, dtype=np.float32, copy=True)
                    entry['shape'] = tuple(cur.shape)
                    entry['time'] = time.time()
                    entry['uses_live_bmesh'] = True
                except Exception:
                    pass
                return coords
    except Exception:
        pass
    try:
        weights = _sos_modal_transform_weights(base, selected_mask, props)
    except Exception:
        weights = selected_mask.astype(np.float32)
    out = np.array(base, dtype=np.float32, copy=True)
    try:
        pivot = base[selected_mask].mean(axis=0)
    except Exception:
        pivot = np.zeros((3,), dtype=np.float32)
    try:
        fallback = _sos_modal_transform_mouse_fallback(context, obj, entry if isinstance(entry, dict) else {}, pivot)
    except Exception:
        fallback = None
    try:
        if op_id == 'TRANSFORM_OT_translate':
            value = _sos_modal_transform_value_tuple(props, 'value', (0.0, 0.0, 0.0))
            if len(value) < 3:
                return coords
            delta_world = Vector((float(value[0]), float(value[1]), float(value[2])))
            try:
                if delta_world.length <= 1.0e-12:
                    if fallback is not None:
                        _delta_local_fallback = _sos_modal_translate_delta_from_mouse(fallback, props, obj)
                        if _delta_local_fallback is not None and float(_delta_local_fallback.length) > 1.0e-12:
                            delta_local = _delta_local_fallback
                        else:
                            return coords
                    else:
                        return coords
                else:
                    delta_local = obj.matrix_world.inverted_safe().to_3x3() @ delta_world
            except Exception:
                if delta_world.length <= 1.0e-12:
                    return coords
                delta_local = delta_world
            dv = np.array((float(delta_local.x), float(delta_local.y), float(delta_local.z)), dtype=np.float32)
            out = base + weights[:, None] * dv[None, :]
        elif op_id == 'TRANSFORM_OT_rotate':
            try:
                angle = float(getattr(props, 'value', 0.0) or 0.0)
            except Exception:
                angle = 0.0
            axis = None
            if abs(angle) <= 1e-12 and fallback is not None:
                angle, axis = _sos_modal_rotate_angle_axis_from_mouse(fallback, props, obj, context=context)
                if angle is None:
                    return coords
            if abs(float(angle or 0.0)) <= 1e-12:
                return coords
            if axis is None:
                axis = _sos_modal_transform_axis_local(props, obj)
            for i in range(len(base)):
                w = float(weights[i])
                if w <= 0.0:
                    continue
                try:
                    rot = Matrix.Rotation(float(angle) * w, 4, axis)
                    vec = Vector((float(base[i, 0] - pivot[0]), float(base[i, 1] - pivot[1]), float(base[i, 2] - pivot[2])))
                    nv = Vector((float(pivot[0]), float(pivot[1]), float(pivot[2]))) + (rot @ vec)
                    out[i] = (nv.x, nv.y, nv.z)
                except Exception:
                    pass
        elif op_id == 'TRANSFORM_OT_resize':
            value = _sos_modal_transform_value_tuple(props, 'value', (1.0, 1.0, 1.0))
            if len(value) < 3:
                return coords
            scale = np.array((float(value[0]), float(value[1]), float(value[2])), dtype=np.float32)
            try:
                if float(np.max(np.abs(scale - 1.0))) <= 1.0e-9:
                    if fallback is not None:
                        scale_fb = _sos_modal_scale_from_mouse(fallback, props)
                        if scale_fb is not None and float(np.max(np.abs(scale_fb - 1.0))) > 1.0e-9:
                            scale = scale_fb
                        else:
                            return coords
                    else:
                        return coords
            except Exception:
                if float(np.max(np.abs(scale - 1.0))) <= 1.0e-9:
                    return coords
            eff = 1.0 + (scale[None, :] - 1.0) * weights[:, None]
            out = pivot[None, :] + (base - pivot[None, :]) * eff
        else:
            return coords
        return out.astype(np.float32, copy=False)
    except Exception:
        return coords


def _sos_edit_transform_modal_active(context=None, prefs=None) -> bool:
    try:
        sig = _sos_modal_transform_signature(context)
        if not sig:
            return False
        # Draw callbacks can be invoked with a UI/N-panel context while the
        # transform operator is still moving edit-mesh elements in the 3D View.
        # Detect the actual edit objects instead of trusting context.mode.
        return bool(_sos_has_live_edit_mesh_context(context))
    except Exception:
        return False


def _sos_edit_transform_live_timer():
    """Compatibility one-shot; edit transforms are event/depsgraph driven."""
    global _sos_edit_transform_live_timer_active
    _sos_edit_transform_live_timer_active = False
    return None

def _sos_start_edit_transform_live_timer() -> None:
    global _sos_edit_transform_live_timer_active
    _sos_edit_transform_live_timer_active = False

def _sos_stop_edit_transform_live_timer() -> None:
    global _sos_edit_transform_live_timer_active, _sos_last_modal_transform_signature
    _sos_edit_transform_live_timer_active = False
    _sos_last_modal_transform_signature = None
    try:
        _sos_edit_transform_baseline_cache.clear()
    except Exception:
        pass
    try:
        if bpy.app.timers.is_registered(_sos_edit_transform_live_timer):
            bpy.app.timers.unregister(_sos_edit_transform_live_timer)
    except Exception:
        pass


def _edit_live_sync_active() -> bool:
    try:
        prefs = get_effective_settings(getattr(bpy, 'context', None))
        if _sos_opt_bool(prefs, 'optimization_disable_timed_live_sync_flush', False) or _sos_opt_bool(prefs, 'optimization_navigation_light_mode', False):
            return False
    except Exception:
        pass
    try:
        return time.time() < float(_sos_edit_live_sync_until)
    except Exception:
        return False


def _sos_should_use_live_edit_bmesh_signature(prefs=None) -> bool:
    return True


def _sos_compact_edit_geometry_motion_signature(live_geometry_sig) -> tuple:
    """Return a selection-independent edit geometry signature for motion checks."""
    try:
        sig = tuple(live_geometry_sig or ())
        if len(sig) >= 13 and not (isinstance(sig[0], str)):
            return (
                int(sig[0] or 0), int(sig[1] or 0), int(sig[2] or 0),
                int(sig[3] or 0), int(sig[4] or 0), int(sig[5] or 0),
                int(sig[9] or 0), int(sig[10] or 0), int(sig[11] or 0), str(sig[12] or ''),
            )
        if len(sig) >= 5 and isinstance(sig[0], str):
            return tuple(sig[:5])
        return sig
    except Exception:
        return tuple(live_geometry_sig or ())


def _sos_note_edit_geometry_motion(obj, live_geometry_sig) -> bool:
    """Detect live edit-coordinate movement even when Blender exposes no modal operator.

    Some 5.1 transform paths, especially gizmo/tool based edits and modifier-visible
    edit updates, can redraw while ``window_manager.operators`` does not yet expose
    a TRANSFORM_OT_* modal entry.  Dirty-generation caching then considers the old
    batch reusable.  This detector compares the live BMesh coordinate/topology
    signature between draws and keeps a short live-motion window so caches and
    modifier-evaluated face fills do not lag behind the editable cage.
    """
    try:
        key = (str(getattr(obj, 'name', '') or ''), int(getattr(obj, 'as_pointer', lambda: 0)() or 0))
    except Exception:
        key = (str(getattr(obj, 'name', '') or ''), 0)
    if not key[0]:
        return False
    try:
        now = _sos_perf_counter()
    except Exception:
        now = time.time()
    sig = _sos_compact_edit_geometry_motion_signature(live_geometry_sig)
    try:
        prev = _sos_edit_geometry_motion_signature_cache.get(key)
    except Exception:
        prev = None
    motion = bool(prev is not None and prev != sig)
    try:
        _sos_edit_geometry_motion_signature_cache[key] = sig
        if motion:
            _sos_edit_geometry_motion_until_cache[key] = now + _SOS_EDIT_GEOMETRY_MOTION_HOLD_SECONDS
        until = float(_sos_edit_geometry_motion_until_cache.get(key, 0.0) or 0.0)
        # Opportunistic pruning to keep old deleted object keys from accumulating.
        if len(_sos_edit_geometry_motion_signature_cache) > 128:
            live_keys = {k for k, u in _sos_edit_geometry_motion_until_cache.items() if float(u or 0.0) > now}
            for old_key in list(_sos_edit_geometry_motion_signature_cache.keys())[:64]:
                if old_key not in live_keys:
                    _sos_edit_geometry_motion_signature_cache.pop(old_key, None)
                    _sos_edit_geometry_motion_until_cache.pop(old_key, None)
        return bool(motion or until > now)
    except Exception:
        return motion


def _sos_bmesh_selected_counts_signature(bm, vc=0, ec=0, fc=0, *, budget_start=None, budget_seconds=None) -> tuple:
    """Selection count signature with a freeze-safe sampled fallback for huge meshes."""
    try:
        total = int(vc or 0) + int(ec or 0) + int(fc or 0)
    except Exception:
        total = 0
    start = _sos_perf_counter() if budget_start is None else float(budget_start)
    budget = _SOS_EDIT_BATCH_SIGNATURE_BUDGET_SECONDS if budget_seconds is None else float(budget_seconds)
    sampled = total > _SOS_EDIT_BATCH_HEAVY_ELEMENT_LIMIT
    try:
        if not sampled:
            v_count = e_count = f_count = 0
            hv = he = hf = 1469598103934665603
            for i, _v in enumerate(bm.verts):
                if (i & (_SOS_EDIT_BATCH_BUDGET_CHECK_STRIDE - 1)) == 0:
                    _sos_check_edit_budget(start, budget, 'selected vertex counts')
                if bool(getattr(_v, 'select', False)):
                    v_count += 1
                    hv = _sos_hash_mix_u64(hv, int(i) + 1)
            for i, _e in enumerate(bm.edges):
                if (i & (_SOS_EDIT_BATCH_BUDGET_CHECK_STRIDE - 1)) == 0:
                    _sos_check_edit_budget(start, budget, 'selected edge counts')
                if bool(getattr(_e, 'select', False)):
                    e_count += 1
                    he = _sos_hash_mix_u64(he, int(i) + 1)
            for i, _f in enumerate(bm.faces):
                if (i & (_SOS_EDIT_BATCH_BUDGET_CHECK_STRIDE - 1)) == 0:
                    _sos_check_edit_budget(start, budget, 'selected face counts')
                if bool(getattr(_f, 'select', False)):
                    f_count += 1
                    hf = _sos_hash_mix_u64(hf, int(i) + 1)
            # Counts alone reuse a stale batch when one selected element is
            # replaced by another.  Keep exact membership hashes so ordinary
            # interactive clicks rebuild neutral/selected/diagnostic ownership.
            return (
                int(v_count), int(e_count), int(f_count),
                int(hv), int(he), int(hf), 'FULL',
            )

        hv = he = hf = 1469598103934665603
        for i in _sos_sample_indices(int(vc or 0), 768):
            try:
                if bool(getattr(bm.verts[int(i)], 'select', False)):
                    hv = _sos_hash_mix_u64(hv, int(i) + 1)
            except Exception:
                pass
        for i in _sos_sample_indices(int(ec or 0), 768):
            try:
                if bool(getattr(bm.edges[int(i)], 'select', False)):
                    he = _sos_hash_mix_u64(he, int(i) + 1)
            except Exception:
                pass
        for i in _sos_sample_indices(int(fc or 0), 768):
            try:
                if bool(getattr(bm.faces[int(i)], 'select', False)):
                    hf = _sos_hash_mix_u64(hf, int(i) + 1)
            except Exception:
                pass
        return (int(hv), int(he), int(hf), 'SAMPLED')
    except _SOSOverlayBudgetExceeded:
        raise
    except Exception:
        return (0, 0, 0, 'ERROR')


def _sos_invalidate_edit_mesh_caches_live(obj_names=(), *, global_invalidate: bool = False, preserve_evaluated_face_cache: bool = True) -> None:
    """Invalidate edit overlay batches immediately without touching Blender RNA.

    This is used for live transform follow.  It only clears Python/GPU caches; the
    subsequent draw reads the already-active edit BMesh in the normal draw
    context, not inside the depsgraph callback.
    """
    try:
        if global_invalidate:
            _sos_invalidate_all_overlay_geometry_caches(preserve_evaluated_face_cache=bool(preserve_evaluated_face_cache))
        else:
            names = tuple(str(n or '') for n in (obj_names or ()) if str(n or ''))
            if not names:
                _sos_invalidate_all_overlay_geometry_caches(preserve_evaluated_face_cache=bool(preserve_evaluated_face_cache))
            for name in names:
                _invalidate_object_cache(name, preserve_evaluated_face_cache=bool(preserve_evaluated_face_cache))
    except Exception:
        pass
    try:
        _touch_edit_live_sync(0.45)
    except Exception:
        pass


def _sync_edit_mesh_to_evaluated_modifier_stack(obj, depsgraph=None, *, source_bm=None, live_signature=None, force: bool=False) -> bool:
    """Flush live Edit Mesh edits into the evaluated modifier stack.

    The normal edit-cage overlay reads directly from the live BMesh, but the
    optional face overlay on the modifier result reads obj.evaluated_get(...).
    During edit transforms Blender can keep that evaluated mesh stale until a
    later depsgraph refresh.  This guarded sync makes evaluated visible/occluded
    face overlay follow edit-mesh movement immediately without touching vertex,
    edge, selected-face, or hover overlays.
    """
    global _sos_edit_eval_sync_signatures
    if obj is None:
        return False
    try:
        if getattr(obj, 'type', None) != 'MESH' or getattr(obj, 'mode', None) != 'EDIT':
            return False
    except Exception:
        return False
    # Normally Smart Overlay avoids update_from_editmode()/depsgraph.update() from
    # draw callbacks because heavy modifier stacks can block the UI.  The only
    # caller that passes force=True is the live edit-transform / small immediate
    # evaluated-face path below.  Do not re-check bpy.context here: while a modal
    # transform is running, Blender can call the draw handler with a stale UI/N
    # panel context even though the live edit BMesh has already moved.  Requiring
    # context.mode == EDIT_MESH at this depth is the reason modifier-applied
    # overlays updated only after confirm.  The caller has already proven that an
    # edit mesh object and live signature are available.
    try:
        if bool(_sos_edit_overlay_circuit_breaker_active()):
            return False
        if bool(_sos_draw_callback_active):
            # Never call update_from_editmode()/depsgraph.update() from a draw
            # callback.  Even small meshes become expensive with edit-visible
            # modifiers, and forcing this work every transform redraw made Blender
            # sluggish immediately after enabling the add-on.  Draw uses live cage
            # data while moving; evaluated modifier caches rebuild outside drawing.
            return False
    except Exception:
        if not bool(force):
            return False
    if not force:
        # Non-forced callers use already available evaluated data or queued caches.
        # Transform redraws pass force=True explicitly; other paths stay deferred.
        return False
    try:
        obj_key = (
            int(getattr(obj, 'as_pointer', lambda: 0)() or 0),
            int(getattr(getattr(obj, 'data', None), 'as_pointer', lambda: 0)() or 0),
            str(getattr(obj, 'name', '') or ''),
        )
    except Exception:
        obj_key = (0, 0, str(getattr(obj, 'name', '') or ''))
    sig = live_signature
    if sig is None and source_bm is not None:
        try:
            sig = _bmesh_live_geometry_signature(source_bm)
        except Exception:
            sig = None
    if sig is None:
        sig = (time.time(),)
    try:
        if _sos_edit_eval_sync_signatures.get(obj_key) == sig:
            return False
    except Exception:
        pass
    synced = False
    try:
        obj.update_from_editmode()
        synced = True
    except Exception:
        synced = False
    if synced:
        # Forced calls are issued only from the deferred evaluated-face rebuild
        # timer after modal/topology mutation guards have cleared and only for
        # bounded edit-mesh sizes.  Updating the depsgraph here is required for
        # modifiers such as Subdivision / Mirror / Solidify to receive the latest
        # edit-mode coordinates before obj.evaluated_get(...).to_mesh() is read.
        try:
            if depsgraph is not None:
                depsgraph.update()
            else:
                getattr(bpy.context, 'view_layer', None).update()
        except Exception:
            try:
                getattr(bpy.context, 'view_layer', None).update()
            except Exception:
                pass
        try:
            _sos_edit_eval_sync_signatures[obj_key] = sig
            if len(_sos_edit_eval_sync_signatures) > _SOS_EDIT_EVAL_SYNC_SIGNATURE_LIMIT:
                for old_key in list(_sos_edit_eval_sync_signatures.keys())[:-_SOS_EDIT_EVAL_SYNC_SIGNATURE_LIMIT]:
                    _sos_edit_eval_sync_signatures.pop(old_key, None)
        except Exception:
            pass
    return bool(synced)


def _bmesh_active_selection_signature(bm):
    try:
        elem = bm.select_history.active
    except Exception:
        elem = None
    if elem is None:
        return ('NONE', -1, False)
    try:
        if isinstance(elem, bmesh.types.BMVert):
            kind = 'VERT'
        elif isinstance(elem, bmesh.types.BMEdge):
            kind = 'EDGE'
        elif isinstance(elem, bmesh.types.BMFace):
            kind = 'FACE'
        else:
            kind = str(type(elem).__name__ or 'OTHER')
    except Exception:
        kind = str(type(elem).__name__ or 'OTHER')
    try:
        index = int(getattr(elem, 'index', -1))
    except Exception:
        index = -1
    try:
        selected = bool(getattr(elem, 'select', False))
    except Exception:
        selected = False
    return (kind, index, selected)

# =============================================================================
# SOS Shader & Logic
# =============================================================================
def get_lattice_pixel_shader():
    global _lattice_pixel_shader
    if _lattice_pixel_shader:
        return _lattice_pixel_shader
    vert_code = """
        void main() {
            vec2 view_size = vec2(max(u_viewSize.x, 1.0), max(u_viewSize.y, 1.0));
            vec2 ndc = (pos / view_size) * 2.0 - 1.0;
            gl_Position = vec4(ndc.x, ndc.y, 0.0, 1.0);
            gl_PointSize = u_pointSize;
        }
    """
    frag_code = "void main() { fragColor = u_color; }"
    try:
        from gpu.types import GPUShaderCreateInfo
        info = GPUShaderCreateInfo()
        info.push_constant('VEC2', 'u_viewSize')
        info.push_constant('FLOAT', 'u_pointSize')
        info.push_constant('VEC4', 'u_color')
        info.vertex_in(0, 'VEC2', 'pos')
        info.fragment_out(0, 'VEC4', 'fragColor')
        info.vertex_source(vert_code)
        info.fragment_source(frag_code)
        _lattice_pixel_shader = gpu.shader.create_from_info(info)
        return _lattice_pixel_shader
    except Exception:
        return None


def get_selected_element_pixel_shader():
    """Return the standard-depth shader used for the last native-overlays cover."""
    global _selected_element_pixel_shader
    if _selected_element_pixel_shader:
        return _selected_element_pixel_shader
    vert_code = """
        void main() {
            gl_Position = u_mvpMatrix * vec4(pos, 1.0);
            gl_PointSize = u_pointSize;
        }
    """
    frag_code = "void main() { fragColor = u_color; }"
    try:
        from gpu.types import GPUShaderCreateInfo
        info = GPUShaderCreateInfo()
        info.push_constant('MAT4', 'u_mvpMatrix')
        info.push_constant('FLOAT', 'u_pointSize')
        info.push_constant('VEC4', 'u_color')
        info.vertex_in(0, 'VEC3', 'pos')
        info.fragment_out(0, 'VEC4', 'fragColor')
        info.vertex_source(vert_code)
        info.fragment_source(frag_code)
        _selected_element_pixel_shader = gpu.shader.create_from_info(info)
        return _selected_element_pixel_shader
    except Exception:
        return None


def get_post_pixel_polyline_shader():
    """Return Blender's screen-space-expanded line shader.

    ``gpu.state.line_width_set`` is clamped to one physical pixel on some
    Windows GPU backends.  Blender's POLYLINE shader expands the line in screen
    space instead, so a selected or diagnostic replacement really covers the
    native edit-cage raster at the user's normal one-pixel edge size.
    """
    global _post_pixel_polyline_shader
    if _post_pixel_polyline_shader is not None:
        return _post_pixel_polyline_shader
    try:
        _post_pixel_polyline_shader = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
    except Exception:
        _post_pixel_polyline_shader = None
    return _post_pixel_polyline_shader


def _sos_linear_rgb_to_display(color):
    """Convert linear preference RGB for Blender's display-space polyline shader."""
    result = []
    for component in tuple(color or ())[:3]:
        try:
            value = max(0.0, min(1.0, float(component)))
        except Exception:
            value = 0.0
        if value <= 0.0031308:
            result.append(value * 12.92)
        else:
            result.append(1.055 * (value ** (1.0 / 2.4)) - 0.055)
    while len(result) < 3:
        result.append(0.0)
    return tuple(result)


def _sos_region_front_key(context=None) -> int:
    try:
        region = getattr(context or bpy.context, 'region', None)
        return int(getattr(region, 'as_pointer', lambda: 0)() or 0)
    except Exception:
        return 0


def _sos_set_lattice_front_points(context=None, points=()):
    key = _sos_region_front_key(context)
    if not key:
        return
    try:
        point_list = tuple(points or ())
    except Exception:
        point_list = ()
    try:
        region = getattr(context or bpy.context, 'region', None)
        _sos_lattice_region_size_by_region[key] = (
            max(1, int(getattr(region, 'width', 1) or 1)),
            max(1, int(getattr(region, 'height', 1) or 1)),
        )
    except Exception:
        _sos_lattice_region_size_by_region[key] = (1, 1)
    previous = _sos_lattice_front_points_by_region.get(key)
    if not point_list:
        _sos_lattice_front_points_by_region.pop(key, None)
        _sos_lattice_pixel_snapshot_by_region.pop(key, None)
        _sos_lattice_region_size_by_region.pop(key, None)
        return
    if previous == point_list and key in _sos_lattice_pixel_snapshot_by_region:
        return
    _sos_lattice_front_points_by_region[key] = point_list
    try:
        overflow = len(_sos_lattice_front_points_by_region) - _SOS_LATTICE_FRONT_CACHE_MAX_REGIONS
        if overflow > 0:
            for old_key in tuple(_sos_lattice_front_points_by_region.keys()):
                if overflow <= 0:
                    break
                if old_key == key:
                    continue
                _sos_lattice_front_points_by_region.pop(old_key, None)
                _sos_lattice_pixel_snapshot_by_region.pop(old_key, None)
                _sos_lattice_region_size_by_region.pop(old_key, None)
                overflow -= 1
    except Exception:
        pass
    _sos_schedule_lattice_pixel_snapshot_build()


def _sos_lattice_pixel_snapshot_timer():
    global _sos_lattice_pixel_snapshot_timer_pending
    _sos_lattice_pixel_snapshot_timer_pending = False
    if not _sos_runtime_registered:
        return None
    shader = get_lattice_pixel_shader()
    if shader is None:
        return None
    completed = {}
    for region_key, points in tuple(_sos_lattice_front_points_by_region.items()):
        grouped = {}
        for x, y, size, color in tuple(points or ()):
            try:
                group_key = (round(float(size), 3), tuple(round(float(c), 4) for c in color))
                grouped.setdefault(group_key, []).append((float(x), float(y)))
            except Exception:
                continue
        commands = []
        for (size, color), coords in grouped.items():
            if not coords:
                continue
            try:
                batch = batch_for_shader(shader, 'POINTS', {'pos': tuple(coords)})
            except Exception:
                continue
            commands.append((batch, float(size), tuple(float(c) for c in color)))
        if commands:
            completed[int(region_key)] = {
                'shader': shader,
                'view_size': tuple(_sos_lattice_region_size_by_region.get(region_key, (1, 1))),
                'commands': tuple(commands),
            }
    _sos_lattice_pixel_snapshot_by_region.clear()
    _sos_lattice_pixel_snapshot_by_region.update(completed)
    tag_view3d_redraw()
    return None


def _sos_schedule_lattice_pixel_snapshot_build() -> None:
    global _sos_lattice_pixel_snapshot_timer_pending
    if _sos_lattice_pixel_snapshot_timer_pending or not _sos_runtime_registered:
        return
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    if timers is None:
        return
    _sos_lattice_pixel_snapshot_timer_pending = True
    try:
        timers.register(_sos_lattice_pixel_snapshot_timer, first_interval=0.0)
    except Exception:
        _sos_lattice_pixel_snapshot_timer_pending = False

def _sos_project_lattice_front_points(context, batches, prefs, region, rv3d, *, vcv, svc, hvc, ovc, base_vertex_point, selected_vertex_point_vis, tvs):
    if not batches or region is None or rv3d is None:
        return []
    try:
        region_w = int(getattr(region, 'width', 0) or 0)
        region_h = int(getattr(region, 'height', 0) or 0)
    except Exception:
        region_w = region_h = 0
    if region_w <= 0 or region_h <= 0:
        return []

    base_size = float(max(base_vertex_point + 2.0, float(tvs) + 3.0, 6.0))
    selected_size = float(max(selected_vertex_point_vis + 2.0, base_size + 1.0))
    hover_size = float(max(base_size + 1.0, float(getattr(prefs, 'vertex_size', base_vertex_point) or base_vertex_point) + 3.0))
    points = []

    def add_points(batch_data, local_coords, color, size):
        if local_coords is None:
            return
        try:
            iterable = local_coords.tolist() if hasattr(local_coords, 'tolist') else local_coords
        except Exception:
            iterable = local_coords
        for co in iterable:
            try:
                p2 = view3d_utils.location_3d_to_region_2d(
                    region,
                    rv3d,
                    batch_data.mw @ Vector((float(co[0]), float(co[1]), float(co[2]))),
                )
                if p2 is None:
                    continue
                x = float(p2.x)
                y = float(p2.y)
                if -8.0 <= x <= region_w + 8.0 and -8.0 <= y <= region_h + 8.0:
                    points.append((x, y, float(size), tuple(float(c) for c in color)))
            except Exception:
                continue

    for b in batches:
        try:
            if not getattr(b, 'is_lattice', False):
                continue
            if getattr(b, 'batch_verts', None) is not None and getattr(b, 'lattice_front_verts', None) is not None:
                if getattr(b, 'is_hover_obj', False):
                    add_points(b, getattr(b, 'lattice_front_verts', None), ovc if getattr(prefs, 'show_hov_obj_verts', False) else vcv, hover_size)
                else:
                    add_points(b, getattr(b, 'lattice_front_verts', None), vcv, base_size)
            if getattr(b, 'batch_sel_verts', None) is not None and getattr(b, 'lattice_front_sel_verts', None) is not None:
                add_points(b, getattr(b, 'lattice_front_sel_verts', None), svc, selected_size)
            if getattr(b, 'batch_hover_verts', None) is not None and getattr(b, 'lattice_front_hover_verts', None) is not None:
                add_points(b, getattr(b, 'lattice_front_hover_verts', None), hvc, hover_size)
        except Exception:
            continue
    return points


def _sos_draw_selected_elements_post_pixel(context=None):
    """Own the final edit-element pixels after Blender's native overlay engine.

    POST_PIXEL does not reliably retain a usable scene depth buffer on every
    Blender 5.1 Windows GPU backend.  The snapshot builder therefore supplies
    CPU visibility-clipped batches for solid mode.  Drawing those batches with
    depth disabled is safe and makes the final color deterministic:

    selected vertices > selected edges > diagnostics > neutral elements.

    Face-center batches retain Blender's canonical BMesh face median; the own-face
    ray hit is used only for visibility classification.
    """
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None or str(getattr(ctx, 'mode', '') or '') != 'EDIT_MESH':
        return False
    if not _mesh_overlay_runtime_enabled(ctx):
        return False
    try:
        prefs = get_effective_settings(ctx)
    except Exception:
        prefs = None
    if prefs is None:
        return False
    try:
        _sos_enforce_native_face_center_suppression_for_context(ctx, prefs)
    except Exception:
        pass
    try:
        _scope_allowed, active_view_allowed, freeze_rebuild = mesh_curve_overlay_draw_policy(
            ctx, prefs, getattr(ctx, 'region_data', None)
        )
        if not active_view_allowed:
            return False
    except Exception:
        return False
    rv3d = getattr(ctx, 'region_data', None)
    if rv3d is None:
        return False
    snapshot = _sos_snapshot_for_draw(ctx, 'EDIT_MESH')
    if snapshot is None:
        return False
    batches = tuple(snapshot.get('batches') or ())
    if not batches:
        return False
    selection_modes = _mesh_edit_selection_modes(ctx)
    point_shader = get_selected_element_pixel_shader()
    line_shader = get_post_pixel_polyline_shader()
    if point_shader is None or line_shader is None:
        return False

    try:
        shading = getattr(getattr(ctx, 'space_data', None), 'shading', None)
        if getattr(shading, 'type', None) == 'WIREFRAME':
            is_xray = bool(getattr(shading, 'show_xray_wireframe', False))
        else:
            is_xray = bool(getattr(shading, 'show_xray', False))
            if float(getattr(shading, 'xray_alpha', 1.0)) <= 0.0:
                is_xray = False
    except Exception:
        is_xray = False

    show_embedded_while_view_still = bool(
        _sos_opt_bool(prefs, 'show_embedded_edit_cage_while_view_still_xray_off', True)
    )
    # ON reproduces the exact 1.2.239 transition: the depth-tested POST_VIEW
    # overlay remains live, but the depth-independent final vertex/edge pass is
    # omitted only while the view is moving. OFF also omits the slightly darker
    # normal vertex/edge ownership layers while still. Selection, hover,
    # diagnostics and face-center ownership remain independent below.
    # Navigation is tracked for both settings.  OFF has no darker still-view
    # layer to keep, but it must not rebuild the CPU visibility snapshot on
    # every orbit/pan/zoom frame either: each result was already stale on the
    # next frame and was discarded, which made OFF far heavier than ON while
    # navigating.  The tracker's settle redraw requests one rebuild instead.
    view_navigation_active = bool(
        not is_xray
        and _sos_lightest_mesh_overlay_navigation_active(ctx, prefs, rv3d, force=True)
    )
    if show_embedded_while_view_still and view_navigation_active:
        return False

    # Solid-mode POST_PIXEL batches are clipped on the CPU for the exact view in
    # which their immutable snapshot was built. Never replay them after orbit,
    # pan, zoom, or projection changes: doing so paints previously visible
    # elements through the mesh. The normal POST_VIEW pass uses the current matrices
    # and depth buffer on every redraw. Once navigation settles, rebuild the final
    # color-ownership pass for the new view.
    if not is_xray:
        current_view_signature = _sos_lightest_matrix_signature(rv3d)
        snapshot_view_signature = tuple(snapshot.get('view_signature') or ())
        if current_view_signature and snapshot_view_signature != tuple(current_view_signature):
            if not freeze_rebuild and not view_navigation_active:
                request_overlay_snapshot_rebuild(
                    'draw_view_visibility_stale', context=ctx, immediate=True
                )
            return False
    selected_edge_rgb = tuple(getattr(prefs, 'selected_edge_overlay_color', (1.0, 0.33, 0.0)))
    hover_edge_rgb = tuple(getattr(prefs, 'hover_edge_color', (1.0, 0.78, 0.02)))
    selected_vertex_color = (*tuple(getattr(prefs, 'selected_vertex_overlay_color', (1.0, 0.33, 0.0))), 1.0)
    hover_vertex_color = (*tuple(getattr(prefs, 'hover_vertex_color', (1.0, 0.78, 0.02))), 1.0)
    base_edge_rgb = tuple(getattr(prefs, 'edge_color', (1.0, 1.0, 1.0)))
    base_vertex_color = (*tuple(getattr(prefs, 'vertex_color', (0.0, 0.0, 1.0))), 1.0)
    occluded_vertex_color = (*tuple(getattr(prefs, 'vertex_occluded_color', (0.076, 0.087, 0.503))), 1.0)
    native_colors = _native_mesh_edit_edge_overlay_colors(ctx)
    edge_size = max(1.0, float(getattr(prefs, 'edge_size', 1.0) or 1.0))
    # The final ownership pass changes only color/order, never apparent size.
    # Using a wider cover stroke/point hid the native raster but overrode the
    # user's Edge Size / Vertex Size settings.  Every category now uses the
    # configured size verbatim; opaque POST_PIXEL ordering still determines
    # which color owns coincident pixels.
    base_edge_cover_width = edge_size
    diagnostic_edge_cover_width = edge_size
    hover_edge_cover_width = edge_size
    selected_edge_cover_width = edge_size
    vertex_size = max(1.0, float(getattr(prefs, 'vertex_size', 1.0) or 1.0))
    base_vertex_cover_size = vertex_size
    selected_vertex_cover_size = vertex_size
    hover_vertex_cover_size = vertex_size

    drawn = False
    try:
        gpu.state.blend_set('NONE')
        gpu.state.depth_mask_set(False)
        # Solid-mode batches were CPU-clipped against the live edit cage. X-Ray
        # intentionally uses complete batches. Neither path depends on the
        # backend-specific POST_PIXEL depth-buffer state.
        gpu.state.depth_test_set('NONE')
        gpu.state.face_culling_set('NONE')
        try:
            gpu.state.alpha_to_coverage_set(False)
        except Exception:
            pass
        line_shader.bind()
        line_shader.uniform_float('viewportSize', (float(ctx.region.width), float(ctx.region.height)))

        def draw_line_batch(batch_data, batch, width, linear_rgb):
            nonlocal drawn
            if batch is None:
                return
            matrix_world = getattr(batch_data, 'mw', None)
            if matrix_world is None:
                return
            line_shader.bind()
            line_shader.uniform_float('viewportSize', (float(ctx.region.width), float(ctx.region.height)))
            line_shader.uniform_float('lineWidth', max(1.0, float(width)))
            line_shader.uniform_float('color', (*_sos_linear_rgb_to_display(linear_rgb), 1.0))
            with gpu.matrix.push_pop():
                gpu.matrix.load_matrix(matrix_world)
                gpu.matrix.load_projection_matrix(rv3d.perspective_matrix)
                batch.draw(line_shader)
            drawn = True

        # X-Ray OFF: replace the native neutral cage only where the CPU visibility
        # pass proved the element is actually visible.
        if not is_xray and show_embedded_while_view_still:
            for batch_data in batches:
                if bool(getattr(batch_data, 'occluder_only', False)):
                    continue
                if bool(getattr(prefs, 'show_vis_edges', True)):
                    draw_line_batch(batch_data, getattr(batch_data, 'batch_pixel_edges', None), base_edge_cover_width, base_edge_rgb)

        # Unselected native diagnostics replace, rather than blend with, the
        # neutral edge. Selected diagnostic edges are absent from these batches.
        native_flags = _native_mesh_edit_edge_overlay_flags(ctx)
        for batch_data in batches:
            if bool(getattr(batch_data, 'occluder_only', False)):
                continue
            for key, full_attr, visible_attr in (
                ('seam', 'batch_native_cage_seam', 'batch_pixel_native_seam'),
                ('sharp', 'batch_native_cage_sharp', 'batch_pixel_native_sharp'),
                ('crease', 'batch_native_cage_crease', 'batch_pixel_native_crease'),
                ('bevel', 'batch_native_cage_bevel', 'batch_pixel_native_bevel'),
            ):
                if not bool(native_flags.get(key, False)):
                    continue
                batch = getattr(batch_data, full_attr if is_xray else visible_attr, None)
                color = tuple(native_colors.get(key, (1.0, 1.0, 1.0, 1.0)))[:3]
                draw_line_batch(batch_data, batch, diagnostic_edge_cover_width, color)

        # Topology Checks are asked for explicitly: their colors own the edge over
        # the neutral edge and the native diagnostics above.
        if getattr(prefs, 'topology_checks_enabled', False) and getattr(prefs, 'topo_edges_enabled', True):
            topo_edge_cover_width = max(edge_size, edge_size * float(getattr(prefs, 'topo_edge_size_mul', 1.4) or 1.4))
            for batch_data in batches:
                if bool(getattr(batch_data, 'occluder_only', False)):
                    continue
                for show_name, show_default, full_attr, visible_attr, color_name in (
                    ('topo_show_bevel_weight', False, 'batch_topo_bevel', 'batch_pixel_topo_bevel', 'topo_edge_color_bevel'),
                    ('topo_show_crease', False, 'batch_topo_crease', 'batch_pixel_topo_crease', 'topo_edge_color_crease'),
                    ('topo_show_sharp', True, 'batch_topo_sharp', 'batch_pixel_topo_sharp', 'topo_edge_color_sharp'),
                    ('topo_show_seams', True, 'batch_topo_seam', 'batch_pixel_topo_seam', 'topo_edge_color_seam'),
                    ('topo_show_non_manifold', True, 'batch_topo_nonmanifold', 'batch_pixel_topo_nonmanifold', 'topo_edge_color_nonmanifold'),
                ):
                    if not bool(getattr(prefs, show_name, show_default)):
                        continue
                    batch = getattr(batch_data, full_attr if is_xray else visible_attr, None)
                    draw_line_batch(batch_data, batch, topo_edge_cover_width, tuple(getattr(prefs, color_name)))

        # Hover owns the final unselected edge color.  Blender's native
        # Seam / Sharp / Crease / Bevel raster is emitted after POST_VIEW on
        # some backends, so the ordinary hover pass cannot reliably remain
        # visible.  Repaint only the CPU visibility-clipped hovered edge here,
        # after diagnostics and before the existing selected-edge priority.
        # Use the configured edge size verbatim; this pass changes order only.
        # Exception: with Topology Checks on, a hovered edge that carries a
        # topology mark sits under the wider topology stroke drawn above, so
        # cover that width or a strip of topology color stays beside the hover.
        if getattr(prefs, 'topology_checks_enabled', False) and getattr(prefs, 'topo_edges_enabled', True):
            hover_edge_cover_width = max(
                hover_edge_cover_width,
                edge_size * float(getattr(prefs, 'topo_edge_size_mul', 1.4) or 1.4),
            )
        if bool(getattr(prefs, 'show_hov_edges', True)):
            for batch_data in batches:
                if bool(getattr(batch_data, 'occluder_only', False)):
                    continue
                batch = getattr(batch_data, 'batch_hover_edges' if is_xray else 'batch_pixel_hover_edges', None)
                draw_line_batch(batch_data, batch, hover_edge_cover_width, hover_edge_rgb)

        # Selection is always the final edge category.
        if 'EDGE' in selection_modes and bool(getattr(prefs, 'show_sel_edges', True)):
            for batch_data in batches:
                if bool(getattr(batch_data, 'occluder_only', False)):
                    continue
                batch = getattr(batch_data, 'batch_sel_edges' if is_xray else 'batch_pixel_sel_edges', None)
                draw_line_batch(batch_data, batch, selected_edge_cover_width, selected_edge_rgb)

        def draw_point_batch(batch_data, batch, size, color, *, blend='NONE'):
            nonlocal drawn
            if batch is None:
                return
            matrix_world = getattr(batch_data, 'mw', None)
            if matrix_world is None:
                return
            gpu.state.blend_set(blend)
            try:
                gpu.state.program_point_size_set(True)
            except Exception:
                pass
            point_shader.bind()
            point_shader.uniform_float('u_pointSize', max(1.0, float(size)))
            point_shader.uniform_float('u_color', color)
            point_shader.uniform_float('u_mvpMatrix', rv3d.perspective_matrix @ matrix_world)
            batch.draw(point_shader)
            drawn = True

        if (
            not is_xray
            and show_embedded_while_view_still
            and 'VERT' in selection_modes
            and bool(getattr(prefs, 'show_vis_verts', True))
        ):
            for batch_data in batches:
                if bool(getattr(batch_data, 'occluder_only', False)):
                    continue
                draw_point_batch(batch_data, getattr(batch_data, 'batch_pixel_verts', None), base_vertex_cover_size, base_vertex_color)

        if 'VERT' in selection_modes and bool(getattr(prefs, 'show_sel_verts', True)):
            for batch_data in batches:
                if bool(getattr(batch_data, 'occluder_only', False)):
                    continue
                batch = getattr(batch_data, 'batch_sel_verts' if is_xray else 'batch_pixel_sel_verts', None)
                draw_point_batch(batch_data, batch, selected_vertex_cover_size, selected_vertex_color)

        # Vertex hover is the last real-vertex category, matching the existing
        # POST_VIEW ordering.  It therefore remains readable over every native
        # diagnostic edge without increasing the configured point size.
        if bool(getattr(prefs, 'show_hov_verts', True)):
            for batch_data in batches:
                if bool(getattr(batch_data, 'occluder_only', False)):
                    continue
                batch = getattr(batch_data, 'batch_hover_verts' if is_xray else 'batch_pixel_hover_verts', None)
                draw_point_batch(batch_data, batch, hover_vertex_cover_size, hover_vertex_color)

        if 'FACE' in selection_modes and bool(getattr(prefs, 'use_select_mode_vertex_center_overlay', True)):
            # X-Ray uses the CPU visibility partition built for this exact
            # view.  Hidden neutral centers use the occluded color; hidden selected
            # centers remain selected-orange.  Visible centers are drawn below at
            # their canonical face medians. No face is present in more than one batch.
            if is_xray and bool(getattr(prefs, 'show_occ_verts', True)):
                occ_alpha = max(0.0, min(1.0, float(getattr(prefs, 'occluded_alpha_mul', 1.0) or 1.0)))
                occ_color = (
                    occluded_vertex_color[0], occluded_vertex_color[1], occluded_vertex_color[2], occ_alpha,
                )
                for batch_data in batches:
                    if bool(getattr(batch_data, 'occluder_only', False)):
                        continue
                    draw_point_batch(batch_data, getattr(batch_data, 'batch_pixel_occluded_face_center_verts', None), base_vertex_cover_size, occ_color, blend='ALPHA')
                    if bool(getattr(prefs, 'show_sel_verts', True)):
                        draw_point_batch(batch_data, getattr(batch_data, 'batch_pixel_occluded_sel_face_center_verts', None), selected_vertex_cover_size, selected_vertex_color, blend='ALPHA')

            for batch_data in batches:
                if bool(getattr(batch_data, 'occluder_only', False)):
                    continue
                if bool(getattr(prefs, 'show_vis_verts', True)):
                    draw_point_batch(batch_data, getattr(batch_data, 'batch_pixel_face_center_verts', None), base_vertex_cover_size, base_vertex_color)
                if bool(getattr(prefs, 'show_sel_verts', True)):
                    draw_point_batch(batch_data, getattr(batch_data, 'batch_pixel_sel_face_center_verts', None), selected_vertex_cover_size, selected_vertex_color)
    except Exception:
        return False
    finally:
        _sos_reset_gpu_state_after_draw()
    return bool(drawn)


def _draw_callback_lattice_front_pixels_impl():
    ctx = getattr(bpy, 'context', None)
    if ctx is None or _sos_should_skip_custom_draw_for_selection(ctx):
        return
    try:
        _sos_draw_selected_elements_post_pixel(ctx)
    except Exception:
        pass
    key = _sos_region_front_key(ctx)
    record = _sos_lattice_pixel_snapshot_by_region.get(key)
    if not record:
        if key in _sos_lattice_front_points_by_region:
            _sos_schedule_lattice_pixel_snapshot_build()
        return
    shader = record.get('shader')
    commands = tuple(record.get('commands') or ())
    if shader is None or not commands:
        return
    try:
        gpu.state.blend_set('ALPHA')
        gpu.state.depth_test_set('NONE')
        gpu.state.depth_mask_set(False)
        try:
            gpu.state.program_point_size_set(True)
        except Exception:
            pass
        shader.bind()
        shader.uniform_float('u_viewSize', tuple(float(v) for v in record.get('view_size', (1, 1))))
        for batch, size, color in commands:
            shader.uniform_float('u_pointSize', float(size))
            shader.uniform_float('u_color', tuple(float(c) for c in color))
            batch.draw(shader)
    except Exception:
        pass
    finally:
        _sos_reset_gpu_state_after_draw()

def get_overlay_shader():
    global _shader
    if _shader: return _shader
    vert_code = """
        void main() {
            vec4 local_pos = vec4(pos, 1.0);
            vec4 clip_pos = u_mvpMatrix * local_pos;

            // Clip-range independent stable depth.
            // Python sends a stable depth row built from model-view Z.
            // Perspective uses -view_z. Orthographic uses a perspective-like
            // baseline - view_z and then rebuilds a synthetic perspective W for
            // depth interpolation while keeping final screen-space X/Y unchanged.
            float view_bias = clamp(u_zOffset, -0.25, 0.25);
            float depth_floor = clamp(u_stableDepthFloor, 1.0e-8, 5.0e-3);
            float raw_depth = dot(u_stableDepthRow, local_pos);
            float positive_depth = max(0.0, raw_depth);

            // Near-eye invariant depth encoding.
            // Do not collapse every fragment closer than depth_floor to one
            // depth value.  That made front and back surfaces share the same
            // pre-pass depth when the object was very close to the View3D eye,
            // so the visible pass could repaint hidden fragments and the
            // occluded color disappeared.  The close-range ordering term below
            // is monotonic and expands tiny positive view-depth differences
            // before the logarithmic encoder, preserving occluded/visible
            // ordering without changing the object's screen-space position.
            float close_order_den = positive_depth + depth_floor * 1.0e-3;
            float ordered_depth = positive_depth;
            if (close_order_den > 0.0) {
                ordered_depth += (depth_floor * positive_depth) / close_order_den;
            }
            float stable_depth = depth_floor + ordered_depth;
            float effective_bias = view_bias;
            if (view_bias > 0.0) {
                // Forward offsets are limited to half of the ordered view depth.
                // This keeps each surface in front of its own pre-pass depth
                // without allowing a farther hidden surface to jump in front of
                // a nearer surface when the camera is extremely close.
                effective_bias = min(view_bias, max(0.0, ordered_depth * 0.5));
            }
            float stable_dist = stable_depth - effective_bias;
            stable_dist = max(depth_floor * 0.5, stable_dist);
            float stable_ndc = -1.0 + (0.1 * log2(stable_dist + 1.0));
            stable_ndc = clamp(stable_ndc, -0.99999999, 0.999999);
            float w_row_abs = abs(u_mvpMatrix[0][3]) + abs(u_mvpMatrix[1][3]) + abs(u_mvpMatrix[2][3]);
            bool sos_ortho_depth = (w_row_abs < 1.0e-8 && abs(u_mvpMatrix[3][3] - 1.0) < 1.0e-6);
            if (sos_ortho_depth) {
                // Orthographic zoom can move geometry across the view origin
                // even though it remains fully visible. Preserve signed depth
                // instead of clamping negative values to the near-depth floor;
                // otherwise the visible pass equals the pre-pass and the
                // earlier occluded color survives. A signed logarithm keeps
                // ordering and useful precision over the full supported range.
                float ortho_depth = raw_depth - view_bias;
                float ortho_log_depth = sign(ortho_depth) * log2(abs(ortho_depth) + 1.0);
                stable_ndc = clamp(0.05 * ortho_log_depth, -0.999999, 0.999999);
            } else {
                // Perspective near-eye / near-clip guard.  The visible View3D
                // clip plane is a UI viewing limit, not a Smart Overlay data
                // limit.  If the original projection places a vertex before the
                // near plane, rebuild only this add-on's private clip W from
                // stable depth and clamp the projected XY to an expanded screen
                // rectangle.  This keeps occluded-color passes drawable even when
                // the mesh is closer than Clip Start or the eye is inside the
                // object, without changing Blender's scene or theme settings.
                float near_w_threshold = max(depth_floor * 4.0, 1.0e-6);
                bool sos_near_clipped = (clip_pos.z < -clip_pos.w) || (clip_pos.w <= near_w_threshold);
                if (sos_near_clipped) {
                    float orig_w = max(abs(clip_pos.w), near_w_threshold);
                    vec2 ndc_xy = clamp(clip_pos.xy / orig_w, vec2(-1.25), vec2(1.25));
                    float synthetic_w = min(1.0e6, max(near_w_threshold, stable_depth));
                    clip_pos.x = ndc_xy.x * synthetic_w;
                    clip_pos.y = ndc_xy.y * synthetic_w;
                    clip_pos.w = synthetic_w;
                }
            }
            clip_pos.z = stable_ndc * clip_pos.w;

            gl_Position = clip_pos;
            gl_PointSize = u_pointSize;
        }
    """
    frag_code = """
        void main() {
            fragColor = u_color;
        }
    """
    global _sos_overlay_shader_sources
    _sos_overlay_shader_sources = vert_code
    try:
        from gpu.types import GPUShaderCreateInfo
        info = GPUShaderCreateInfo()
        info.push_constant('MAT4', "u_mvpMatrix")
        info.push_constant('VEC4', "u_stableDepthRow")
        info.push_constant('FLOAT', "u_zOffset")
        info.push_constant('FLOAT', "u_stableDepthFloor")
        info.push_constant('FLOAT', "u_pointSize")
        info.push_constant('VEC4', "u_color")
        info.vertex_in(0, 'VEC3', "pos")
        info.fragment_out(0, 'VEC4', "fragColor")
        info.vertex_source(vert_code)
        info.fragment_source(frag_code)
        _shader = gpu.shader.create_from_info(info)
        return _shader
    except Exception: return None

def get_gradient_shader():
    global _grad_shader
    if _grad_shader: return _grad_shader
    vert_code = """
        void main() {
            vec4 local_pos = vec4(pos, 1.0);
            vec4 clip_pos = u_mvpMatrix * local_pos;
            float view_bias = clamp(u_zOffset, -0.25, 0.25);
            float depth_floor = clamp(u_stableDepthFloor, 1.0e-8, 5.0e-3);
            float raw_depth = dot(u_stableDepthRow, local_pos);
            float positive_depth = max(0.0, raw_depth);

            // Near-eye invariant depth encoding.
            // Do not collapse every fragment closer than depth_floor to one
            // depth value.  That made front and back surfaces share the same
            // pre-pass depth when the object was very close to the View3D eye,
            // so the visible pass could repaint hidden fragments and the
            // occluded color disappeared.  The close-range ordering term below
            // is monotonic and expands tiny positive view-depth differences
            // before the logarithmic encoder, preserving occluded/visible
            // ordering without changing the object's screen-space position.
            float close_order_den = positive_depth + depth_floor * 1.0e-3;
            float ordered_depth = positive_depth;
            if (close_order_den > 0.0) {
                ordered_depth += (depth_floor * positive_depth) / close_order_den;
            }
            float stable_depth = depth_floor + ordered_depth;
            float effective_bias = view_bias;
            if (view_bias > 0.0) {
                // Forward offsets are limited to half of the ordered view depth.
                // This keeps each surface in front of its own pre-pass depth
                // without allowing a farther hidden surface to jump in front of
                // a nearer surface when the camera is extremely close.
                effective_bias = min(view_bias, max(0.0, ordered_depth * 0.5));
            }
            float stable_dist = stable_depth - effective_bias;
            stable_dist = max(depth_floor * 0.5, stable_dist);
            float stable_ndc = -1.0 + (0.1 * log2(stable_dist + 1.0));
            stable_ndc = clamp(stable_ndc, -0.99999999, 0.999999);
            float w_row_abs = abs(u_mvpMatrix[0][3]) + abs(u_mvpMatrix[1][3]) + abs(u_mvpMatrix[2][3]);
            bool sos_ortho_depth = (w_row_abs < 1.0e-8 && abs(u_mvpMatrix[3][3] - 1.0) < 1.0e-6);
            if (sos_ortho_depth) {
                // Keep the orthographic gradient pass on the same signed,
                // zoom-invariant depth layer as the solid-color pass.
                float ortho_depth = raw_depth - view_bias;
                float ortho_log_depth = sign(ortho_depth) * log2(abs(ortho_depth) + 1.0);
                stable_ndc = clamp(0.05 * ortho_log_depth, -0.999999, 0.999999);
            } else {
                // Perspective near-eye / near-clip guard.  The visible View3D
                // clip plane is a UI viewing limit, not a Smart Overlay data
                // limit.  If the original projection places a vertex before the
                // near plane, rebuild only this add-on's private clip W from
                // stable depth and clamp the projected XY to an expanded screen
                // rectangle.  This keeps occluded-color passes drawable even when
                // the mesh is closer than Clip Start or the eye is inside the
                // object, without changing Blender's scene or theme settings.
                float near_w_threshold = max(depth_floor * 4.0, 1.0e-6);
                bool sos_near_clipped = (clip_pos.z < -clip_pos.w) || (clip_pos.w <= near_w_threshold);
                if (sos_near_clipped) {
                    float orig_w = max(abs(clip_pos.w), near_w_threshold);
                    vec2 ndc_xy = clamp(clip_pos.xy / orig_w, vec2(-1.25), vec2(1.25));
                    float synthetic_w = min(1.0e6, max(near_w_threshold, stable_depth));
                    clip_pos.x = ndc_xy.x * synthetic_w;
                    clip_pos.y = ndc_xy.y * synthetic_w;
                    clip_pos.w = synthetic_w;
                }
            }
            clip_pos.z = stable_ndc * clip_pos.w;
            gl_Position = clip_pos;
            vColor = color;
        }
    """
    frag_code = """
        void main() {
            fragColor = vec4(vColor.rgb, vColor.a * u_alphaMul);
        }
    """
    global _sos_gradient_shader_sources
    _sos_gradient_shader_sources = vert_code
    try:
        from gpu.types import GPUShaderCreateInfo, GPUStageInterfaceInfo
        info = GPUShaderCreateInfo()
        info.push_constant('MAT4', "u_mvpMatrix")
        info.push_constant('VEC4', "u_stableDepthRow")
        info.push_constant('FLOAT', "u_zOffset")
        info.push_constant('FLOAT', "u_stableDepthFloor")
        info.push_constant('FLOAT', "u_alphaMul")
        info.vertex_in(0, 'VEC3', "pos")
        info.vertex_in(1, 'VEC4', "color")
        iface = GPUStageInterfaceInfo("SMOGradIface")
        iface.smooth('VEC4', "vColor")
        info.vertex_out(iface)
        info.fragment_out(0, 'VEC4', "fragColor")
        info.vertex_source(vert_code)
        info.fragment_source(frag_code)
        _grad_shader = gpu.shader.create_from_info(info)
        return _grad_shader
    except Exception: return None


# Occluded Style "Dashed": the same vertex programs, plus the screen position of
# the line's provoking vertex.  The fragment stage cuts the line by its pixel
# distance from that point, so the dash length stays constant while zooming.
_SOS_DASH_VERT_TAIL = """
            vec2 sos_dash_px = (gl_Position.xy / max(abs(gl_Position.w), 1.0e-6)) * u_dashViewport * 0.5;
            vDashStart = sos_dash_px;
            vDashPos = sos_dash_px;
"""
_SOS_DASH_FRAG_HEAD = """
            if (mod(length(vDashPos - vDashStart), 10.0) > 5.0) {
                discard;
            }
"""


def get_overlay_dash_shader():
    global _dash_shader
    if _dash_shader:
        return _dash_shader
    if get_overlay_shader() is None or not _sos_overlay_shader_sources:
        return None
    try:
        from gpu.types import GPUShaderCreateInfo, GPUStageInterfaceInfo
        info = GPUShaderCreateInfo()
        info.push_constant('MAT4', "u_mvpMatrix")
        info.push_constant('VEC4', "u_stableDepthRow")
        info.push_constant('FLOAT', "u_zOffset")
        info.push_constant('FLOAT', "u_stableDepthFloor")
        info.push_constant('FLOAT', "u_pointSize")
        info.push_constant('VEC4', "u_color")
        info.push_constant('VEC2', "u_dashViewport")
        info.vertex_in(0, 'VEC3', "pos")
        iface = GPUStageInterfaceInfo("SMODashIface")
        iface.flat('VEC2', "vDashStart")
        iface.no_perspective('VEC2', "vDashPos")
        info.vertex_out(iface)
        info.fragment_out(0, 'VEC4', "fragColor")
        info.vertex_source(_sos_overlay_shader_sources.replace(
            "gl_PointSize = u_pointSize;", "gl_PointSize = u_pointSize;" + _SOS_DASH_VERT_TAIL))
        info.fragment_source("void main() {" + _SOS_DASH_FRAG_HEAD + "fragColor = u_color;\n}\n")
        _dash_shader = gpu.shader.create_from_info(info)
        return _dash_shader
    except Exception:
        return None


def get_gradient_dash_shader():
    global _grad_dash_shader
    if _grad_dash_shader:
        return _grad_dash_shader
    if get_gradient_shader() is None or not _sos_gradient_shader_sources:
        return None
    try:
        from gpu.types import GPUShaderCreateInfo, GPUStageInterfaceInfo
        info = GPUShaderCreateInfo()
        info.push_constant('MAT4', "u_mvpMatrix")
        info.push_constant('VEC4', "u_stableDepthRow")
        info.push_constant('FLOAT', "u_zOffset")
        info.push_constant('FLOAT', "u_stableDepthFloor")
        info.push_constant('FLOAT', "u_alphaMul")
        info.push_constant('VEC2', "u_dashViewport")
        info.vertex_in(0, 'VEC3', "pos")
        info.vertex_in(1, 'VEC4', "color")
        iface = GPUStageInterfaceInfo("SMOGradDashIface")
        iface.smooth('VEC4', "vColor")
        iface.flat('VEC2', "vDashStart")
        iface.no_perspective('VEC2', "vDashPos")
        info.vertex_out(iface)
        info.fragment_out(0, 'VEC4', "fragColor")
        info.vertex_source(_sos_gradient_shader_sources.replace(
            "vColor = color;", "vColor = color;" + _SOS_DASH_VERT_TAIL))
        info.fragment_source("void main() {" + _SOS_DASH_FRAG_HEAD + "fragColor = vec4(vColor.rgb, vColor.a * u_alphaMul);\n}\n")
        _grad_dash_shader = gpu.shader.create_from_info(info)
        return _grad_dash_shader
    except Exception:
        return None

# Projection-matched depth-bias constants. They are expressed in stable
# perspective-equivalent view units rather than fixed NDC/depth-buffer units.
#
# View > Clip Start / Clip End changes Blender's projection matrix and depth
# precision. A fixed NDC offset can therefore change its effective world/view
# depth when the clip range changes. Mesh and Curve Overlay and Hover Overlay instead
# encode their pre-pass and overlay passes into the same logarithmic depth
# layer. Orthographic views synthesize a perspective-equivalent focus-plane
# baseline so the same depth-offset value has the same strength as the
# corresponding perspective view.
_SOS_DEPTH_VIEW_MIN = 0.0
_SOS_DEPTH_VIEW_PREPASS = 0.0
_SOS_DEPTH_VIEW_MAX = 2.5e-1
# Stable-depth encoder near-eye floor.  When a mesh is extremely close to the
# View3D camera/eye, -view_z can become smaller than the user-requested depth
# offset.  The old shader clamped both the surface pre-pass and the forward
# visible overlay to the same near NDC value, so the visible pass could fail and
# leave the earlier occluded color on actually visible fragments.  This floor is
# intentionally tiny and is scaled from the active overlay depth strengths in
# draw_callback_3d(), so it only creates enough depth room to preserve the
# visible/pre-pass/occluded order near the eye without depending on Clip Start.
_SOS_STABLE_DEPTH_FLOOR_BASE = 1.0e-8
_SOS_STABLE_DEPTH_FLOOR_MAX = 5.0e-4
_sos_current_stable_depth_floor = _SOS_STABLE_DEPTH_FLOOR_BASE

def _sos_finite_float(value, default=0.0):
    try:
        f = float(value)
    except Exception:
        return float(default)
    try:
        if not math.isfinite(f):
            return float(default)
    except Exception:
        if f != f:
            return float(default)
    return f

def _sos_depth_bias_from_internal(value, sign=1.0, mul=1.0):
    s = max(0.0, _sos_finite_float(value, 0.0))
    bias = s * max(0.0, _sos_finite_float(mul, 1.0))
    bias = min(_SOS_DEPTH_VIEW_MAX, max(_SOS_DEPTH_VIEW_MIN, bias))
    return (1.0 if sign >= 0.0 else -1.0) * bias

def _sos_mesh_curve_priority_depth_offsets(face_bias, edge_bias, vertex_bias):
    """Return clip-stable depth offsets with fixed visual layer priority.

    The UI exposes independent depth strengths for faces, edges, and vertices.
    Those values are still used as the requested base strength, but the final
    draw order must never invert: Mesh/Curve vertices are always in front of
    Mesh/Curve edges, and Mesh/Curve edges are always in front of Mesh/Curve
    faces.  The small priority gap is expressed in the same stable view-space
    units as the normal offset, so Clip Start / Clip End edits cannot change the
    result.
    """
    try:
        f = max(0.0, min(_SOS_DEPTH_VIEW_MAX, _sos_finite_float(face_bias, 0.0)))
        e = max(0.0, min(_SOS_DEPTH_VIEW_MAX, _sos_finite_float(edge_bias, 0.0)))
        v = max(0.0, min(_SOS_DEPTH_VIEW_MAX, _sos_finite_float(vertex_bias, 0.0)))
        largest = max(f, e, v, 1.0e-6)
        gap = max(1.0e-6, min(_SOS_DEPTH_VIEW_MAX * 0.01, largest * 0.02))
        if f > 0.0 or e > 0.0:
            e = max(e, min(_SOS_DEPTH_VIEW_MAX, f + gap))
        if e > 0.0 or v > 0.0:
            v = max(v, min(_SOS_DEPTH_VIEW_MAX, e + gap))
        return f, e, v
    except Exception:
        return face_bias, edge_bias, vertex_bias

def _sos_depth_prepass_bias(sign=1.0):
    # The hidden depth pre-pass writes the unshifted mesh depth.  Visible and
    # occluded overlay layers are then offset by a clip-compensated view-space
    # distance, so the pre-pass itself must not contain any fixed NDC anchor.
    bias = min(_SOS_DEPTH_VIEW_MAX, max(_SOS_DEPTH_VIEW_MIN, _SOS_DEPTH_VIEW_PREPASS))
    return (1.0 if sign >= 0.0 else -1.0) * bias

def _sos_layered_depth_bias(current, sign=1.0, add_mul=0.35):
    current = _sos_finite_float(current, 0.0)
    if abs(current) <= 0.0:
        return 0.0
    s = 1.0 if sign >= 0.0 else -1.0
    extra = min(_SOS_DEPTH_VIEW_MAX * 0.25, abs(current) * max(0.0, _sos_finite_float(add_mul, 0.35)))
    return s * min(_SOS_DEPTH_VIEW_MAX, abs(current) + extra)

def _sos_safe_depth_uniform(value):
    # Fast path: an in-range finite float is returned unchanged, exactly as
    # the clamping path below would return it.
    if value.__class__ is float and -_SOS_DEPTH_VIEW_MAX <= value <= _SOS_DEPTH_VIEW_MAX:
        return value
    f = _sos_finite_float(value, 0.0)
    if f > _SOS_DEPTH_VIEW_MAX:
        return _SOS_DEPTH_VIEW_MAX
    if f < -_SOS_DEPTH_VIEW_MAX:
        return -_SOS_DEPTH_VIEW_MAX
    return f

def _sos_ndc_depth_direction(rv3d):
    # Return (visible_test, occluded_test, z_offset_sign, reversed_z).  The
    # magnitude of the overlay offset is never derived from the clipping range;
    # this helper only determines whether the active projection uses normal or
    # reversed depth ordering.
    mat = getattr(rv3d, 'window_matrix', None)
    if mat is None:
        return 'LESS_EQUAL', 'GREATER_EQUAL', 1.0, False

    def _project_view_z(z_value):
        try:
            v = mat @ Vector((0.0, 0.0, float(z_value), 1.0))
            w = float(v.w)
            if abs(w) <= 1.0e-20:
                return None
            ndc_z = float(v.z) / w
            if not math.isfinite(ndc_z):
                return None
            return ndc_z
        except Exception:
            return None

    for near_z, far_z in ((-1.0, -2.0), (-0.01, -100.0), (-0.1, -1000.0)):
        near_ndc = _project_view_z(near_z)
        far_ndc = _project_view_z(far_z)
        if near_ndc is None or far_ndc is None:
            continue
        delta = near_ndc - far_ndc
        if abs(delta) <= 1.0e-12:
            continue
        reversed_z = bool(delta > 0.0)
        if reversed_z:
            return 'GREATER_EQUAL', 'LESS_EQUAL', -1.0, True
        return 'LESS_EQUAL', 'GREATER_EQUAL', 1.0, False

    return 'LESS_EQUAL', 'GREATER_EQUAL', 1.0, False


def _sos_visible_depth_test_for_overlay(rv3d, visible_test, strict_enabled=False):
    if not strict_enabled:
        return visible_test
    try:
        if bool(getattr(rv3d, 'is_perspective', False)):
            return visible_test
    except Exception:
        return visible_test
    if visible_test == 'LESS_EQUAL':
        return 'LESS'
    if visible_test == 'GREATER_EQUAL':
        return 'GREATER'
    return visible_test


def _sos_occluded_depth_test_for_overlay(rv3d, occluded_test):
    return occluded_test


_SOS_NEAR_EYE_TYPES = frozenset(('MESH', 'CURVE', 'CURVES', 'SURFACE', 'FONT', 'META', 'LATTICE'))


def _sos_near_eye_object_exact(obj, view_matrix, threshold):
    """The original per-object near-eye test: True, False, or None when skipped."""
    try:
        if getattr(obj, 'type', None) not in {'MESH', 'CURVE', 'CURVES', 'SURFACE', 'FONT', 'META', 'LATTICE'}:
            return None
        mw = getattr(obj, 'matrix_world', None)
        bbox = getattr(obj, 'bound_box', None)
        if mw is None or not bbox:
            return None
        try:
            mw = mw.copy()
        except Exception:
            pass
        min_depth = None
        max_depth = None
        for corner in bbox:
            try:
                world = mw @ Vector((float(corner[0]), float(corner[1]), float(corner[2]), 1.0))
            except Exception:
                world = mw @ Vector((float(corner[0]), float(corner[1]), float(corner[2])))
                world = world.to_4d()
            view = view_matrix @ world
            depth = -float(view.z)
            if min_depth is None or depth < min_depth:
                min_depth = depth
            if max_depth is None or depth > max_depth:
                max_depth = depth
        if min_depth is None or max_depth is None:
            return None
        return bool(min_depth <= threshold and max_depth >= -threshold)
    except Exception:
        return None


def _sos_near_eye_bulk_states(objs, view_matrix, threshold):
    """Classify many objects at once: 1 surely reaches, 0 surely not or skipped, -1 decide exactly.

    One foreach_get per property reads the same RNA values the per-object loop
    reads.  Depths are evaluated in float64 with a margin about 40x above the
    float32 rounding of the exact path, so only objects inside that margin are
    left to _sos_near_eye_object_exact().  Returns None when the bulk read is
    not worthwhile or fails; the caller then runs the exact loop for all.
    """
    try:
        n_obj = len(objs)
        if n_obj < 24:
            return None
        data_objects = bpy.data.objects
        n_all = len(data_objects)
        if n_all <= 0 or n_all > 8 * n_obj:
            return None
        uids = np.empty(n_all, dtype=np.int32)
        data_objects.foreach_get('session_uid', uids)
        mats = np.empty(n_all * 16, dtype=np.float32)
        data_objects.foreach_get('matrix_world', mats)
        boxes = np.empty(n_all * 24, dtype=np.float32)
        data_objects.foreach_get('bound_box', boxes)
        index_of = {}
        for i, uid in enumerate(uids.tolist()):
            index_of[uid] = -2 if uid in index_of else i
        states = [0] * n_obj
        rows = []
        cols = []
        for k, obj in enumerate(objs):
            try:
                kind = getattr(obj, 'type', None)
            except Exception:
                continue
            if kind not in _SOS_NEAR_EYE_TYPES:
                continue
            states[k] = -1
            try:
                i = index_of.get(int(obj.session_uid), -1)
            except Exception:
                i = -1
            if i >= 0:
                rows.append(k)
                cols.append(i)
        if rows:
            idx = np.asarray(cols, dtype=np.int64)
            m = mats.reshape(n_all, 4, 4)[idx].transpose(0, 2, 1).astype(np.float64)
            b = boxes.reshape(n_all, 8, 3)[idx].astype(np.float64)
            bh = np.concatenate((b, np.ones(b.shape[:2] + (1,), dtype=np.float64)), axis=2)
            world = np.einsum('kij,kcj->kci', m, bh)
            mag = np.einsum('kij,kcj->kci', np.abs(m), np.abs(bh))
            v2 = np.asarray(view_matrix, dtype=np.float64)[2]
            depth = -(world @ v2)
            margin = 1.0e-5 * (mag @ np.abs(v2)).max(axis=1) + 1.0e-30
            dmin = depth.min(axis=1)
            dmax = depth.max(axis=1)
            finite = np.isfinite(depth).all(axis=1) & np.isfinite(margin)
            t = float(threshold)
            surely_not = (dmin - margin > t) | (dmax + margin < -t)
            surely = (dmin + margin <= t) & (dmax - margin >= -t)
            for k, fin, sn, sy in zip(rows, finite.tolist(), surely_not.tolist(), surely.tolist()):
                if fin:
                    if sn:
                        states[k] = 0
                    elif sy:
                        states[k] = 1
        return states
    except Exception:
        return None


def _sos_near_eye_occlusion_fallback_active(context, rv3d, depth_threshold: float) -> bool:
    """Return True when overlay target geometry reaches the View3D eye plane.

    The shader remaps Smart Overlay depth into a private stable layer, but GPU
    primitive clipping can still reject triangles/lines whose projected W is at
    or behind the eye before the occluded-color depth comparison runs.  A cheap
    object-bound test lets the draw path switch only the occluded-color pass to
    an unconditional near-eye seed, then the normal visible pass repaints the
    front layer.  This keeps hidden colors visible at unlimited close range
    without changing Blender clip settings or theme/UI state.
    """
    try:
        ctx = context or getattr(bpy, 'context', None)
        view_matrix = getattr(rv3d, 'view_matrix', None)
        if ctx is None or view_matrix is None:
            return False
        threshold = max(1.0e-6, float(depth_threshold or 0.0))
    except Exception:
        return False
    # Plain copies avoid one RNA read-back per matrix product; values are equal.
    try:
        view_matrix = view_matrix.copy()
    except Exception:
        pass

    candidates = []
    try:
        mode_now = str(getattr(ctx, 'mode', '') or '')
    except Exception:
        mode_now = ''
    try:
        if mode_now in {'EDIT_MESH', 'EDIT_LATTICE', 'EDIT_CURVE', 'EDIT_CURVES'}:
            candidates.extend([o for o in (getattr(ctx, 'objects_in_mode', None) or ()) if o is not None])
    except Exception:
        pass
    try:
        candidates.extend([o for o in (getattr(ctx, 'selected_objects', None) or ()) if o is not None])
    except Exception:
        pass
    try:
        for o in (getattr(ctx, 'object', None), getattr(ctx, 'active_object', None)):
            if o is not None:
                candidates.append(o)
    except Exception:
        pass

    seen = set()
    unique = []
    for obj in candidates:
        try:
            ptr = int(obj.as_pointer())
        except Exception:
            ptr = id(obj)
        if ptr in seen:
            continue
        seen.add(ptr)
        unique.append(obj)
    # Large selections: one bulk float64 pass with a safety margin settles
    # every clear case; only borderline objects run the exact float32 loop.
    states = _sos_near_eye_bulk_states(unique, view_matrix, threshold)
    if states is not None:
        if 1 in states:
            return True
        for obj, state in zip(unique, states):
            if state == -1 and _sos_near_eye_object_exact(obj, view_matrix, threshold):
                return True
        return False
    for obj in unique:
        if _sos_near_eye_object_exact(obj, view_matrix, threshold):
            return True
    return False


def _sos_strict_occluded_depth_test_for_overlay(rv3d, occluded_test):
    # Orthographic repair pass: repaint fragments that are truly behind the
    # stable depth pre-pass without accepting equal-depth front fragments.
    # This prevents a later visible-color draw from remaining on hidden
    # vertices, edges, or faces when a forward visible depth offset pulls near-camera or very close hidden fragments through.
    del rv3d
    if occluded_test == 'GREATER_EQUAL':
        return 'GREATER'
    if occluded_test == 'LESS_EQUAL':
        return 'LESS'
    return occluded_test


def get_theme_colors(context):
    try:
        t = context.preferences.themes[0].view_3d
        ec, vc = t.edge_select[:], t.vertex_select[:]
        return (*ec, 1.0) if len(ec)==3 else ec, (*vc, 1.0) if len(vc)==3 else vc, float(t.vertex_size)
    except Exception: return (1.0, 0.33, 0.0, 1.0), (1.0, 0.33, 0.0, 1.0), 3.0


def _sos_active_view3d_context_for_rv3d(rv3d):
    try:
        target_ptr = rv3d.as_pointer()
    except Exception:
        target_ptr = 0
    try:
        windows = tuple(bpy.context.window_manager.windows)
    except Exception:
        windows = ()
    for window in windows:
        screen = getattr(window, 'screen', None)
        if screen is None:
            continue
        for area in getattr(screen, 'areas', ()):  # pragma: no branch - small UI scan
            if getattr(area, 'type', None) != 'VIEW_3D':
                continue
            for space in getattr(area, 'spaces', ()):
                if getattr(space, 'type', None) != 'VIEW_3D':
                    continue
                space_rv3d = getattr(space, 'region_3d', None)
                if space_rv3d is None:
                    continue
                try:
                    same = bool(space_rv3d.as_pointer() == target_ptr)
                except Exception:
                    same = bool(space_rv3d is rv3d)
                if not same:
                    continue
                region = next((r for r in getattr(area, 'regions', ()) if getattr(r, 'type', None) == 'WINDOW'), None)
                return space, region
    return None, None


def _sos_orthographic_depth_baseline(rv3d, mat):
    """Return the signed orthographic focus-plane origin.

    Orthographic zoom changes ``view_distance`` without creating a real eye
    plane. Using that zoom value as a positive depth baseline made visible
    geometry cross zero, collapse into the near-depth floor, and retain the
    occluded color. The shader now supports signed orthographic depth, so only
    the focus-plane translation is needed and zoom no longer affects ordering.
    """
    focus_view_z = 0.0
    try:
        loc = getattr(rv3d, 'view_location', None)
        if loc is not None:
            v = rv3d.view_matrix @ Vector((float(loc.x), float(loc.y), float(loc.z), 1.0))
            focus_view_z = float(v.z)
            if not math.isfinite(focus_view_z):
                focus_view_z = 0.0
    except Exception:
        focus_view_z = 0.0

    del mat
    return max(-1.0e6, min(1.0e6, focus_view_z))


def _sos_projection_depth_uniform(rv3d):
    try:
        mat = rv3d.window_matrix
        p22 = float(mat[2][2])
        p23 = float(mat[2][3])
        p32 = float(mat[3][2])
        p33 = float(mat[3][3])
    except Exception:
        return (-1.0, 0.0, -1.0, 0.0)

    if abs(p32) <= 1.0e-8:
        p33 = _sos_orthographic_depth_baseline(rv3d, mat)
    return (p22, p23, p32, p33)


_SOS_FRAME_VIEW_UNSET = object()


def _sos_begin_frame_view(rv3d):
    """Snapshot the view matrices for the current POST_VIEW draw only.

    Overlay geometry is drawn object by object, and every draw call re-reads
    rv3d.view_matrix / window_matrix and re-multiplies the same matrices.  The
    view cannot change inside one draw callback, so the products are computed
    once per (frame, matrix_world) and every uniform call is still issued in
    the original order with the original values.  draw_callback_3d clears it.
    """
    global _sos_frame_view
    try:
        view = rv3d.view_matrix.copy()
        window = rv3d.window_matrix.copy()
    except Exception:
        _sos_frame_view = None
        return
    try:
        p32 = float(window[3][2])
    except Exception:
        p32 = -1.0
    # Slot 6: per shader, the matrix entry and depth floor last written in
    # this draw.  Uniform values stay in the shader until written again.
    _sos_frame_view = [rv3d, view, window, p32, {}, _SOS_FRAME_VIEW_UNSET, {}]


def _sos_end_frame_view():
    global _sos_frame_view
    _sos_frame_view = None


def _sos_set_depth_shader_matrices(shader, rv3d, matrix_world):
    fv = _sos_frame_view
    if fv is not None and fv[0] is rv3d:
        memo = fv[4]
        entry = memo.get(id(matrix_world))
        if entry is None or entry[0] is not matrix_world:
            model_view = fv[1] @ matrix_world
            mvp = fv[2] @ model_view
            try:
                r0, r1, r2, r3 = (float(model_view[2][0]), float(model_view[2][1]), float(model_view[2][2]), float(model_view[2][3]))
            except Exception:
                r0, r1, r2, r3 = 0.0, 0.0, 1.0, 0.0
            if abs(fv[3]) <= 1.0e-8:
                base = fv[5]
                if base is _SOS_FRAME_VIEW_UNSET:
                    base = _sos_orthographic_depth_baseline(rv3d, getattr(rv3d, 'window_matrix', None))
                    fv[5] = base
                row = (-r0, -r1, -r2, base - r3)
            else:
                row = (-r0, -r1, -r2, -r3)
            # The memo keeps matrix_world alive, so its id cannot be reused
            # by another matrix during this frame.
            entry = (matrix_world, model_view, mvp, row)
            memo[id(matrix_world)] = entry
        written = fv[6]
        last = written.get(id(shader))
        if last is None or last[0] is not shader:
            last = [shader, None, None]
            written[id(shader)] = last
        if last[1] is not entry:
            last[1] = None
            shader.uniform_float("u_mvpMatrix", entry[2])
            shader.uniform_float("u_stableDepthRow", entry[3])
            last[1] = entry
        floor = _sos_current_stable_depth_floor
        if last[2] is None or last[2] != floor or type(last[2]) is not type(floor):
            last[2] = None
            try:
                shader.uniform_float("u_stableDepthFloor", floor)
                last[2] = floor
            except Exception:
                pass
        if shader is _dash_shader or shader is _grad_dash_shader:
            shader.uniform_float("u_dashViewport", _sos_current_dash_viewport)
        return entry[1]
    if fv is not None:
        # Written outside the per-draw record below: forget what it holds.
        fv[6].pop(id(shader), None)
    model_view = rv3d.view_matrix @ matrix_world
    shader.uniform_float("u_mvpMatrix", rv3d.window_matrix @ model_view)
    try:
        p32 = float(rv3d.window_matrix[3][2])
    except Exception:
        p32 = -1.0
    try:
        r0, r1, r2, r3 = (float(model_view[2][0]), float(model_view[2][1]), float(model_view[2][2]), float(model_view[2][3]))
    except Exception:
        r0, r1, r2, r3 = 0.0, 0.0, 1.0, 0.0
    if abs(p32) <= 1.0e-8:
        base = _sos_orthographic_depth_baseline(rv3d, getattr(rv3d, 'window_matrix', None))
        shader.uniform_float("u_stableDepthRow", (-r0, -r1, -r2, base - r3))
    else:
        shader.uniform_float("u_stableDepthRow", (-r0, -r1, -r2, -r3))
    try:
        shader.uniform_float("u_stableDepthFloor", _sos_current_stable_depth_floor)
    except Exception:
        pass
    if shader is _dash_shader or shader is _grad_dash_shader:
        shader.uniform_float("u_dashViewport", _sos_current_dash_viewport)
    return model_view


_SOS_EDGE_AA_MODE = 'AA_2PASS'  # 'AA_2PASS' | 'AA_MSAA' | 'AA_OFF'

def _sos_draw_edge_aa(shader, batch, width: float, zoff: float, color, outer_add: float = 1.0, outer_alpha: float = 0.18):
    """
    Edge overlay draw helper with selectable anti-aliasing modes.

    Modes are controlled via preferences and apply to all edge overlays that currently use AA.
    - AA_2PASS: outer soft line + main line (2 draws)
    - AA_MSAA: single draw (relies on MSAA/alpha-to-coverage if available)
    - AA_OFF : single draw (and AA GPU states are disabled by the caller)
    """
    if not batch:
        return
    # Fast path: decide mode once per call (caller sets AA GPU states).
    mode = _SOS_EDGE_AA_MODE
    try:
        w = float(width)
        # The line width and both uniforms are written again before every
        # draw below, so each value is written once, right before its draw.
        z = _sos_safe_depth_uniform(zoff)

        if mode == 'AA_2PASS':
            oa = float(outer_add)
            if oa > 0.0 and color[3] > 0.001:
                # Outer AA pass (soft edge)
                try:
                    gpu.state.line_width_set(max(1.0, w + oa))
                except Exception:
                    gpu.state.line_width_set(max(1.0, w))
                c = (color[0], color[1], color[2], color[3] * float(outer_alpha))
                shader.uniform_float("u_zOffset", z)
                shader.uniform_float("u_color", c)
                batch.draw(shader)

            # Main pass
            gpu.state.line_width_set(max(1.0, w))
            shader.uniform_float("u_zOffset", z)
            shader.uniform_float("u_color", color)
            batch.draw(shader)
        else:
            # AA_MSAA / AA_OFF: single pass
            gpu.state.line_width_set(max(1.0, w))
            shader.uniform_float("u_zOffset", z)
            shader.uniform_float("u_color", color)
            batch.draw(shader)

    except Exception:
        # Fallback: single pass (keeps behavior stable even if any GPU state call fails)
        try:
            gpu.state.line_width_set(float(width))
            shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(zoff))
            shader.uniform_float("u_color", color)
            batch.draw(shader)
        except Exception:
            pass

def get_csdt_radius(kind="VERT"):
    try:
        prefs = bpy.context.preferences.addons
        target = prefs.get("Smart_Transform_Tools") or prefs.get("Smart Transform Tools")
        if not target: target = next((a for n, a in prefs.items() if "Smart" in n and "Transform" in n), None)
        if target: return float(getattr(target.preferences, f"{'vert' if kind=='VERT' else 'edge'}_hit_radius", 20.0))
    except Exception: pass
    return 20.0

class SOS_BatchData:
    __slots__ = ('mw', 'object_name', 'is_hover_obj', 'is_mod_eval', 'is_lattice', 'occluder_only', 'face_op_mul', 'edge_alpha_mul',
                 'batch_tris', 'batch_edges', 'batch_verts', 'batch_sel_edges', 'batch_sel_verts', 'batch_sel_tris',
                 'batch_face_center_verts', 'batch_sel_face_center_verts', 'batch_face_center_depth_tris', 'batch_surface_depth_tris',
                 'batch_cover_edges', 'batch_cover_verts', 'batch_cover_tris',
                 'batch_half_sel_vis', 'batch_half_sel_occ', 'batch_hover_tris', 'batch_hover_edges', 'batch_hover_verts',
                 'batch_topo_seam', 'batch_topo_sharp', 'batch_topo_crease', 'batch_topo_bevel', 'batch_topo_nonmanifold',
                 'batch_topo_ngons', 'batch_topo_small', 'batch_topo_all_faces',
                 'batch_native_seam', 'batch_native_sharp', 'batch_native_crease', 'batch_native_bevel',
                 'batch_native_cage_seam', 'batch_native_cage_sharp', 'batch_native_cage_crease', 'batch_native_cage_bevel',
                 'cpu_edges', 'cpu_sel_edges', 'cpu_hover_edges', 'cpu_verts', 'cpu_sel_verts', 'cpu_hover_verts',
                 'cpu_native_cage_seam', 'cpu_native_cage_sharp', 'cpu_native_cage_crease', 'cpu_native_cage_bevel',
                 'cpu_topo_seam', 'cpu_topo_sharp', 'cpu_topo_crease', 'cpu_topo_bevel', 'cpu_topo_nonmanifold',
                 'cpu_face_centers', 'cpu_sel_face_centers',
                 'batch_pixel_edges', 'batch_pixel_sel_edges', 'batch_pixel_hover_edges',
                 'batch_pixel_verts', 'batch_pixel_sel_verts', 'batch_pixel_hover_verts',
                 'batch_pixel_native_seam', 'batch_pixel_native_sharp', 'batch_pixel_native_crease', 'batch_pixel_native_bevel',
                 'batch_pixel_topo_seam', 'batch_pixel_topo_sharp', 'batch_pixel_topo_crease', 'batch_pixel_topo_bevel', 'batch_pixel_topo_nonmanifold',
                 'batch_pixel_face_center_verts', 'batch_pixel_sel_face_center_verts',
                 'batch_pixel_occluded_face_center_verts', 'batch_pixel_occluded_sel_face_center_verts',
                 'pixel_visibility_surface',
                 'lattice_front_verts', 'lattice_front_sel_verts', 'lattice_front_hover_verts')
    def __init__(self, mw):
        self.mw, self.object_name, self.is_hover_obj, self.is_mod_eval, self.is_lattice = mw.copy(), '', False, False, False
        self.occluder_only = False
        self.face_op_mul, self.edge_alpha_mul = 1.0, 1.0
        self.batch_tris = self.batch_edges = self.batch_verts = self.batch_sel_edges = self.batch_sel_verts = self.batch_sel_tris = None
        self.batch_face_center_verts = self.batch_sel_face_center_verts = self.batch_face_center_depth_tris = self.batch_surface_depth_tris = None
        self.batch_cover_edges = self.batch_cover_verts = self.batch_cover_tris = None
        self.batch_half_sel_vis = self.batch_half_sel_occ = self.batch_hover_tris = self.batch_hover_edges = self.batch_hover_verts = None
        self.batch_topo_seam = self.batch_topo_sharp = self.batch_topo_crease = self.batch_topo_bevel = self.batch_topo_nonmanifold = None
        self.batch_topo_ngons = self.batch_topo_small = self.batch_topo_all_faces = None
        self.batch_native_seam = self.batch_native_sharp = self.batch_native_crease = self.batch_native_bevel = None
        self.batch_native_cage_seam = self.batch_native_cage_sharp = self.batch_native_cage_crease = self.batch_native_cage_bevel = None
        self.cpu_edges = self.cpu_sel_edges = self.cpu_hover_edges = ()
        self.cpu_verts = self.cpu_sel_verts = self.cpu_hover_verts = ()
        self.cpu_native_cage_seam = self.cpu_native_cage_sharp = self.cpu_native_cage_crease = self.cpu_native_cage_bevel = ()
        self.cpu_topo_seam = self.cpu_topo_sharp = self.cpu_topo_crease = self.cpu_topo_bevel = self.cpu_topo_nonmanifold = ()
        self.cpu_face_centers = self.cpu_sel_face_centers = ()
        self.batch_pixel_edges = self.batch_pixel_sel_edges = self.batch_pixel_hover_edges = None
        self.batch_pixel_verts = self.batch_pixel_sel_verts = self.batch_pixel_hover_verts = None
        self.batch_pixel_native_seam = self.batch_pixel_native_sharp = self.batch_pixel_native_crease = self.batch_pixel_native_bevel = None
        self.batch_pixel_topo_seam = self.batch_pixel_topo_sharp = self.batch_pixel_topo_crease = self.batch_pixel_topo_bevel = self.batch_pixel_topo_nonmanifold = None
        self.batch_pixel_face_center_verts = self.batch_pixel_sel_face_center_verts = None
        self.batch_pixel_occluded_face_center_verts = self.batch_pixel_occluded_sel_face_center_verts = None
        self.pixel_visibility_surface = 'EDIT_CAGE'
        self.lattice_front_verts = self.lattice_front_sel_verts = self.lattice_front_hover_verts = None


class _SosViewRayFrame:
    """View constants for one synchronous CPU visibility build.

    ray_through() evaluates exactly the mathutils expressions of
    bpy_extras.view3d_utils.location_3d_to_region_2d, region_2d_to_origin_3d
    (clamp=100000.0) and region_2d_to_vector_3d, followed by the second
    normalize() of _sos_view_ray_clip_stable.  Only the per-ray reads of the
    rv3d matrices, their inverses and the region size are hoisted; they cannot
    change while one build runs.  build() returns None on any failure and the
    caller then uses the original per-ray helpers.
    """
    __slots__ = (
        'persmat', 'width', 'height', 'width_half', 'height_half', 'is_persp',
        'persinv', 'persinv_r3', 'persinv_r3w', 'viewinv_t',
        'ortho_dir', 'ortho_c0', 'ortho_c1', 'ortho_t', 'ortho_offset',
    )

    @classmethod
    def build(cls, region, rv3d):
        try:
            self = cls()
            self.persmat = rv3d.perspective_matrix.copy()
            self.width = region.width
            self.height = region.height
            self.width_half = region.width / 2.0
            self.height_half = region.height / 2.0
            self.is_persp = bool(rv3d.is_perspective)
            viewinv = rv3d.view_matrix.inverted()
            persinv = rv3d.perspective_matrix.inverted()
            self.persinv = persinv
            self.persinv_r3 = persinv[3].xyz
            self.persinv_r3w = persinv[3][3]
            self.viewinv_t = viewinv.translation.copy()
            ortho_dir = -viewinv.col[2].xyz
            ortho_dir.normalize()
            try:
                ortho_dir.normalize()
            except Exception:
                pass
            self.ortho_dir = ortho_dir
            self.ortho_c0 = persinv.col[0].xyz
            self.ortho_c1 = persinv.col[1].xyz
            self.ortho_t = persinv.translation
            ortho_offset = None
            if rv3d.view_perspective != 'CAMERA':
                ortho_offset = persinv.col[2].xyz
                if ortho_offset.length > 100000.0:
                    ortho_offset.length = 100000.0
            self.ortho_offset = ortho_offset
            return self
        except Exception:
            return None

    def ray_through(self, coord):
        """Return (origin, direction) for a world point, or (None, None)."""
        prj = self.persmat @ Vector((coord[0], coord[1], coord[2], 1.0))
        if not (prj.w > 0.0):
            return None, None
        width_half = self.width_half
        height_half = self.height_half
        projected = Vector((
            width_half + width_half * (prj.x / prj.w),
            height_half + height_half * (prj.y / prj.w),
        ))
        if self.is_persp:
            origin = self.viewinv_t.copy()
            out = Vector((
                (2.0 * projected[0] / self.width) - 1.0,
                (2.0 * projected[1] / self.height) - 1.0,
                -0.5
            ))
            w = out.dot(self.persinv_r3) + self.persinv_r3w
            direction = ((self.persinv @ out) / w) - self.viewinv_t
            direction.normalize()
            try:
                direction.normalize()
            except Exception:
                pass
        else:
            dx = (2.0 * projected[0] / self.width) - 1.0
            dy = (2.0 * projected[1] / self.height) - 1.0
            origin = (
                (self.ortho_c0 * dx) +
                (self.ortho_c1 * dy) +
                self.ortho_t
            )
            if self.ortho_offset is not None:
                origin -= self.ortho_offset
            direction = self.ortho_dir.copy()
        return origin, direction


_SOS_PIXEL_VIS_MEMO = {}
_SOS_PIXEL_VIS_MEMO_LIMIT = 8


def _sos_pixel_vis_view_print(region, rv3d, matrix_world):
    """Exact bits of every view/object input read by _SosViewRayFrame and ray_hit()."""
    try:
        return (
            np.asarray(rv3d.perspective_matrix, dtype=np.float32).tobytes(),
            np.asarray(rv3d.view_matrix, dtype=np.float32).tobytes(),
            np.asarray(matrix_world, dtype=np.float32).tobytes(),
            int(region.width),
            int(region.height),
            bool(rv3d.is_perspective),
            str(rv3d.view_perspective),
        )
    except Exception:
        return None


def _sos_pixel_vis_exact_mesh_print(bm):
    """Exact inputs of BVHTree.FromBMesh, read right after it indexed the BMesh.

    Vertex coordinates (float32 bits), each face's loop-order vertex indices
    (this also fixes the face order and every quad split) and n-gon normals,
    which n-gon tessellation reads.  Returns None on any failure, which turns
    the visibility memo off for that build.
    """
    try:
        from array import array as _array
        co = _array('f')
        for v in bm.verts:
            co.extend(v.co)
        fi = _array('q')
        no = _array('f')
        for f in bm.faces:
            vs = [v.index for v in f.verts]
            fi.append(len(vs))
            fi.extend(vs)
            if len(vs) > 4:
                no.extend(f.normal)
        return (len(co), co.tobytes(), fi.tobytes(), no.tobytes())
    except Exception:
        return None


def _sos_np_mat_vec(m, v, rows, homogeneous):
    """mathutils ``Matrix @ Vector`` for every row of the float32 array v (n, k).

    Each component sums the float32 products in double from the first column
    (plus m[r][k] for a 3D vector times a 4x4 matrix) and rounds it to float,
    exactly as mathutils does.
    """
    n, k = v.shape
    out = np.empty((n, rows), dtype=np.float32)
    for r in range(rows):
        acc = 0.0 + (m[r, 0] * v[:, 0]).astype(np.float64)
        for c in range(1, k):
            acc = acc + (m[r, c] * v[:, c]).astype(np.float64)
        if homogeneous:
            acc = acc + np.float64(m[r, k])
        out[:, r] = acc
    return out


def _sos_np_dot_rev(a, b):
    """``Vector.dot`` / ``length_squared``: float32 products summed in double from the last component."""
    return (((0.0 + (a[:, 2] * b[:, 2]).astype(np.float64)) + (a[:, 1] * b[:, 1]).astype(np.float64))
            + (a[:, 0] * b[:, 0]).astype(np.float64))


def _sos_np_normalize(v):
    """``Vector.normalize()``: exact double squares summed from the last component;
    above 1e-35 multiply by the float reciprocal of float(sqrt), otherwise zero."""
    v64 = v.astype(np.float64)
    d = ((0.0 + v64[:, 2] * v64[:, 2]) + v64[:, 1] * v64[:, 1]) + v64[:, 0] * v64[:, 0]
    big = d > 1.0e-35
    s = np.sqrt(np.where(big, d, 1.0)).astype(np.float32)
    out = v * (np.float32(1.0) / s)[:, None]
    out[~big] = 0.0
    return out


def _sos_np_points(seq):
    """float32 (n, 3) array of 3-component items, or None for anything else."""
    try:
        from itertools import chain
        n = len(seq)
        for item in seq:
            if len(item) != 3:
                return None
        return np.fromiter(chain.from_iterable(seq), dtype=np.float32, count=3 * n).reshape(n, 3)
    except Exception:
        return None


class _SosNpRayFrame:
    """Array form of _SosViewRayFrame.ray_through() and the ray set-up of ray_hit().

    Every step repeats the float32 / double arithmetic of the mathutils
    expression it replaces (Matrix @ Vector, Vector.dot, length_squared,
    normalize(), Vector / s multiplies by the float reciprocal of float(s),
    Vector * s rounds s to float first).  BVHTree.ray_cast is still called once
    per ray with the same float values, so the visible sets and their order
    are the ones the per-ray helpers produce.  build() and every method return
    None when anything is unexpected; the caller then runs the per-ray code.
    """
    __slots__ = (
        'mw', 'w2l', 'm3', 'persmat', 'width', 'height', 'width_half', 'height_half', 'is_persp',
        'persinv', 'persinv_r3', 'persinv_r3w', 'viewinv_t',
        'ortho_dir', 'ortho_c0', 'ortho_c1', 'ortho_t', 'ortho_offset',
    )

    @classmethod
    def build(cls, frame, mw, world_to_local, local_direction_matrix):
        try:
            f32 = np.float32
            self = cls()
            if not frame.width or not frame.height:
                return None
            self.width = float(frame.width)
            self.height = float(frame.height)
            self.width_half = float(frame.width_half)
            self.height_half = float(frame.height_half)
            self.is_persp = bool(frame.is_persp)
            self.mw = np.array(mw, dtype=f32)
            self.w2l = np.array(world_to_local, dtype=f32)
            self.m3 = np.array(local_direction_matrix, dtype=f32)
            self.persmat = np.array(frame.persmat, dtype=f32)
            self.persinv = np.array(frame.persinv, dtype=f32)
            self.persinv_r3 = np.array(frame.persinv_r3, dtype=f32)
            self.persinv_r3w = float(frame.persinv_r3w)
            self.viewinv_t = np.array(frame.viewinv_t, dtype=f32)
            self.ortho_dir = np.array(frame.ortho_dir, dtype=f32)
            self.ortho_c0 = np.array(frame.ortho_c0, dtype=f32)
            self.ortho_c1 = np.array(frame.ortho_c1, dtype=f32)
            self.ortho_t = np.array(frame.ortho_t, dtype=f32)
            offset = frame.ortho_offset
            self.ortho_offset = None if offset is None else np.array(offset, dtype=f32)
            shapes = ((self.mw, (4, 4)), (self.w2l, (4, 4)), (self.m3, (3, 3)), (self.persmat, (4, 4)),
                      (self.persinv, (4, 4)), (self.persinv_r3, (3,)), (self.viewinv_t, (3,)),
                      (self.ortho_dir, (3,)), (self.ortho_c0, (3,)), (self.ortho_c1, (3,)), (self.ortho_t, (3,)))
            if any(a.shape != shape for a, shape in shapes):
                return None
            if self.ortho_offset is not None and self.ortho_offset.shape != (3,):
                return None
            return self
        except Exception:
            return None

    def rays(self, local):
        """(castable, origin_local, direction_local) for float32 local points (n, 3).

        castable is False where ray_hit() returns None before casting.
        """
        f32 = np.float32
        n = local.shape[0]
        world = _sos_np_mat_vec(self.mw, local, 3, True)
        prj = _sos_np_mat_vec(self.persmat, world, 4, True)
        castable = prj[:, 3] > 0.0
        pw = np.where(castable, prj[:, 3], f32(1.0)).astype(np.float64)
        wh = self.width_half
        hh = self.height_half
        qx = (wh + wh * (prj[:, 0].astype(np.float64) / pw)).astype(f32)
        qy = (hh + hh * (prj[:, 1].astype(np.float64) / pw)).astype(f32)
        dx = (2.0 * qx.astype(np.float64)) / self.width - 1.0
        dy = (2.0 * qy.astype(np.float64)) / self.height - 1.0
        if self.is_persp:
            out = np.empty((n, 3), dtype=f32)
            out[:, 0] = dx
            out[:, 1] = dy
            out[:, 2] = -0.5
            w = _sos_np_dot_rev(out, self.persinv_r3[None, :]) + self.persinv_r3w
            s = w.astype(f32)
            nonzero = s != 0.0
            castable &= nonzero
            inv = f32(1.0) / np.where(nonzero, s, f32(1.0))
            direction = _sos_np_mat_vec(self.persinv, out, 3, True) * inv[:, None] - self.viewinv_t[None, :]
            direction = _sos_np_normalize(_sos_np_normalize(direction))
            origin = np.broadcast_to(self.viewinv_t, (n, 3))
        else:
            origin = ((self.ortho_c0[None, :] * dx.astype(f32)[:, None])
                      + (self.ortho_c1[None, :] * dy.astype(f32)[:, None])) + self.ortho_t[None, :]
            if self.ortho_offset is not None:
                origin = origin - self.ortho_offset[None, :]
            direction = np.broadcast_to(self.ortho_dir, (n, 3))
        origin_local = _sos_np_mat_vec(self.w2l, origin, 3, True)
        direction_local = _sos_np_mat_vec(self.m3, direction, 3, False)
        castable &= ~(_sos_np_dot_rev(direction_local, direction_local) <= 1.0e-20)
        return castable, origin_local, _sos_np_normalize(direction_local)

    def visible(self, local, bvh, distance_epsilon):
        """visible_point() for every row of local."""
        castable, origin_local, direction_local = self.rays(local)
        visible = np.ones(local.shape[0], dtype=bool)
        rows = np.flatnonzero(castable)
        if len(rows):
            ol = origin_local[rows]
            dl = direction_local[rows]
            target = _sos_np_dot_rev(local[rows] - ol, dl).tolist()
            ray_cast = bvh.ray_cast
            for j, (o, d) in enumerate(zip(ol.tolist(), dl.tolist())):
                hit_co, _hit_no, _hit_index, hit_distance = ray_cast(o, d)
                if hit_co is None or hit_distance is None:
                    continue
                if not (target[j] <= float(hit_distance) + distance_epsilon):
                    visible[rows[j]] = False
        return visible

    def edge_segments(self, coords, steps, bvh, distance_epsilon):
        """visible_edge_segments() for a tuple of flat edge coordinates."""
        try:
            pairs = len(coords) // 2
            if pairs <= 0:
                return []
            flat = _sos_np_points(coords[:2 * pairs])
            if flat is None:
                return None
            f32 = np.float32
            start = flat[0::2]
            delta = flat[1::2] - start
            t = [float(step) / float(steps) for step in range(steps + 1)]
            t_mid = np.array([(t[k] + t[k + 1]) * 0.5 for k in range(steps)], dtype=np.float64).astype(f32)
            midpoints = start[:, None, :] + delta[:, None, :] * t_mid[None, :, None]
            visible = self.visible(midpoints.reshape(-1, 3), bvh, distance_epsilon).reshape(pairs, steps)
            edge_rows, step_rows = np.nonzero(visible)
            t0 = np.array(t[:-1], dtype=np.float64).astype(f32)[step_rows][:, None]
            t1 = np.array(t[1:], dtype=np.float64).astype(f32)[step_rows][:, None]
            s = start[edge_rows]
            d = delta[edge_rows]
            result = np.empty((2 * len(edge_rows), 3), dtype=f32)
            result[0::2] = s + d * t0
            result[1::2] = s + d * t1
            return result
        except Exception:
            return None

    def points(self, coords, bvh, distance_epsilon):
        """visible_points() for a tuple of points."""
        try:
            if not coords:
                return []
            local = _sos_np_points(coords)
            if local is None:
                return None
            return np.ascontiguousarray(local[self.visible(local, bvh, distance_epsilon)])
        except Exception:
            return None

    def face_centers(self, records, bvh):
        """partition_face_centers() for a tuple of (face index, center) records."""
        try:
            if not records:
                return [], []
            indices = [int(record[0]) for record in records]
            local = _sos_np_points([record[1] for record in records])
            if local is None:
                return None
            castable, origin_local, direction_local = self.rays(local)
            visible = np.zeros(local.shape[0], dtype=bool)
            rows = np.flatnonzero(castable)
            if len(rows):
                ray_cast = bvh.ray_cast
                ol = origin_local[rows].tolist()
                dl = direction_local[rows].tolist()
                for j, row in enumerate(rows.tolist()):
                    hit_co, _hit_no, hit_index, _hit_distance = ray_cast(ol[j], dl[j])
                    if hit_co is not None and hit_index is not None and int(hit_index) == indices[row]:
                        visible[row] = True
            return np.ascontiguousarray(local[visible]), np.ascontiguousarray(local[~visible])
        except Exception:
            return None


def _sos_build_post_pixel_visibility_batches(context, obj, bm, source, target):
    """Build view-dependent, self-occlusion-safe edit-element batches.

    Blender's native edit cage is rasterized after normal POST_VIEW handlers on
    some GPU backends, while POST_PIXEL no longer has a usable scene depth
    buffer.  This function therefore resolves self visibility on the CPU while
    the immutable snapshot is built.  The final POST_PIXEL pass can then paint
    only visible solid-mode segments with depth disabled, guaranteeing that the
    native neutral/diagnostic raster cannot remain on selected or diagnostic
    elements.  X-Ray uses the complete original GPU batches instead.
    """
    region = getattr(context, 'region', None)
    rv3d = getattr(context, 'region_data', None)
    if obj is None or bm is None or region is None or rv3d is None or source is None or target is None:
        return False
    try:
        from mathutils.bvhtree import BVHTree
        cage_bvh = BVHTree.FromBMesh(bm, epsilon=0.0)
    except Exception:
        return False
    # The 1.2.239 color-priority pass intentionally tests edit elements against
    # the editable cage.  That makes front-side cage vertices/edges remain
    # readable even when a Subdivision Surface or another edit-visible modifier
    # moves the displayed surface in front of them. Turning the single still-view
    # embedded-cage switch OFF changes only vertex/edge visibility to use the
    # evaluated surface; face centers continue to use the edit-cage BVH because
    # their face indices and same-face surface anchors belong to editable topology.
    element_bvh = cage_bvh
    try:
        prefs = get_effective_settings(context)
    except Exception:
        prefs = None
    try:
        shading = getattr(getattr(context, 'space_data', None), 'shading', None)
        if getattr(shading, 'type', None) == 'WIREFRAME':
            is_xray = bool(getattr(shading, 'show_xray_wireframe', False))
        else:
            is_xray = bool(getattr(shading, 'show_xray', False))
            if float(getattr(shading, 'xray_alpha', 1.0)) <= 0.0:
                is_xray = False
    except Exception:
        is_xray = False
    use_evaluated_element_surface = bool(
        not is_xray
        and not _sos_opt_bool(prefs, 'show_embedded_edit_cage_while_view_still_xray_off', True)
        and _has_visible_edit_mode_modifier(obj)
        and _use_evaluated_edit_mode_face_overlay(obj, prefs)
    )
    if use_evaluated_element_surface:
        try:
            # Keep the vertex/edge occlusion query completely independent from
            # the evaluated-face overlay cache.  Calling evaluated_obj.to_mesh()
            # followed by to_mesh_clear() here can invalidate the temporary mesh
            # owned by the asynchronous face-overlay rebuild for the same object,
            # making the face fill disappear after the element pass is rebuilt.
            # BVHTree.FromObject asks the depsgraph for its own evaluated query
            # without acquiring or clearing the face overlay's temporary mesh.
            #
            # update_from_editmode() tags the mesh geometry; the depsgraph handler
            # then bumps this object's dirty generation and requests another
            # snapshot rebuild, which came back here and flushed again.  With
            # this setting OFF that self-feeding cycle rebuilt the snapshot about
            # every 0.43 s and caused 0.3-0.4 s hitches.  Flush only when the
            # generation changed since our own last flush (a real edit or
            # invalidation); otherwise the evaluated depsgraph is already current.
            try:
                surf_key = (int(obj.as_pointer()), str(getattr(obj, 'name', '') or ''))
            except Exception:
                surf_key = (0, str(getattr(obj, 'name', '') or ''))
            if _sos_pixel_surface_sync_generations.get(surf_key) != _sos_dirty_generation_for_object(obj):
                obj.update_from_editmode()
            depsgraph = context.evaluated_depsgraph_get()
            try:
                _sos_pixel_surface_sync_generations.pop(surf_key, None)
                _sos_pixel_surface_sync_generations[surf_key] = _sos_dirty_generation_for_object(obj)
                if len(_sos_pixel_surface_sync_generations) > _SOS_PIXEL_SURFACE_SYNC_LIMIT:
                    for old_key in list(_sos_pixel_surface_sync_generations.keys())[:-_SOS_PIXEL_SURFACE_SYNC_LIMIT]:
                        _sos_pixel_surface_sync_generations.pop(old_key, None)
            except Exception:
                pass
            evaluated_bvh = BVHTree.FromObject(
                obj,
                depsgraph,
                deform=True,
                cage=False,
                epsilon=0.0,
            )
            if evaluated_bvh is not None:
                element_bvh = evaluated_bvh
                target.pixel_visibility_surface = 'EVALUATED'
        except Exception:
            element_bvh = cage_bvh
    try:
        mw = obj.matrix_world.copy()
        world_to_local = mw.inverted_safe()
        local_direction_matrix = world_to_local.to_3x3()
    except Exception:
        return False
    try:
        diag = max(
            1.0e-6,
            (Vector((max(v.co.x for v in bm.verts), max(v.co.y for v in bm.verts), max(v.co.z for v in bm.verts)))
             - Vector((min(v.co.x for v in bm.verts), min(v.co.y for v in bm.verts), min(v.co.z for v in bm.verts)))).length,
        ) if bm.verts else 1.0
    except Exception:
        diag = 1.0
    distance_epsilon = max(1.0e-5, float(diag) * 2.5e-4)
    view_ray_frame = _SosViewRayFrame.build(region, rv3d)
    # Array form of the per-ray helpers below; None keeps them unchanged.
    np_ray_frame = None
    if view_ray_frame is not None:
        np_ray_frame = _SosNpRayFrame.build(view_ray_frame, mw, world_to_local, local_direction_matrix)
    # Hover-only rebuilds reuse the immutable base snapshot tuples.  When the
    # view, object matrix, epsilon and exact cage inputs match the previous
    # build, a category whose source tuple is the very same object yields the
    # same visible segments, so its batch is reused instead of re-casting rays.
    pixel_memo_slot = None
    pixel_memo_prev = None
    pixel_memo_new = None
    if view_ray_frame is not None and element_bvh is cage_bvh:
        try:
            pixel_memo_base = (
                _sos_pixel_vis_view_print(region, rv3d, mw),
                float(distance_epsilon),
                _sos_pixel_vis_exact_mesh_print(bm),
            )
            if pixel_memo_base[0] is not None and pixel_memo_base[2] is not None:
                pixel_memo_slot = int(obj.as_pointer())
                prev_entry = _SOS_PIXEL_VIS_MEMO.get(pixel_memo_slot)
                if prev_entry is not None and prev_entry[0] == pixel_memo_base:
                    pixel_memo_prev = prev_entry[1]
                pixel_memo_new = (pixel_memo_base, {})
        except Exception:
            pixel_memo_slot = None
            pixel_memo_prev = None
            pixel_memo_new = None

    def ray_hit(local_co, visibility_bvh=None):
        try:
            local = Vector(local_co)
            if view_ray_frame is not None:
                origin_world, direction_world = view_ray_frame.ray_through(mw @ local)
                if origin_world is None:
                    return None
            else:
                projected = view3d_utils.location_3d_to_region_2d(region, rv3d, mw @ local)
                if projected is None:
                    return None
                origin_world, direction_world = _sos_view_ray_clip_stable(region, rv3d, projected)
            origin_local = world_to_local @ origin_world
            direction_local = local_direction_matrix @ direction_world
            if direction_local.length_squared <= 1.0e-20:
                return None
            direction_local.normalize()
            active_bvh = visibility_bvh if visibility_bvh is not None else element_bvh
            hit_co, _hit_no, hit_index, hit_distance = active_bvh.ray_cast(origin_local, direction_local)
            target_distance = float((local - origin_local).dot(direction_local))
            return hit_co, hit_index, float(hit_distance) if hit_distance is not None else None, target_distance
        except Exception:
            return None

    def visible_point(local_co):
        hit = ray_hit(local_co)
        if hit is None or hit[0] is None or hit[2] is None:
            # Edge/vertex rays can numerically miss exactly on a boundary.  Do
            # not erase a point merely because the BVH returned no triangle.
            return True
        return bool(hit[3] <= hit[2] + distance_epsilon)

    def visible_edge_segments(flat_coords, subdivisions=6):
        result = []
        coords = tuple(flat_coords or ())
        steps = max(1, int(subdivisions))
        if np_ray_frame is not None:
            with np.errstate(all='ignore'):
                fast = np_ray_frame.edge_segments(coords, steps, element_bvh, distance_epsilon)
            if fast is not None:
                return fast
        for index in range(0, len(coords) - 1, 2):
            try:
                start = Vector(coords[index])
                end = Vector(coords[index + 1])
            except Exception:
                continue
            delta = end - start
            for step in range(steps):
                t0 = float(step) / float(steps)
                t1 = float(step + 1) / float(steps)
                midpoint = start + delta * ((t0 + t1) * 0.5)
                if visible_point(midpoint):
                    result.extend((start + delta * t0, start + delta * t1))
        return result

    def visible_points(coords):
        items = tuple(coords or ())
        if np_ray_frame is not None:
            with np.errstate(all='ignore'):
                fast = np_ray_frame.points(items, element_bvh, distance_epsilon)
            if fast is not None:
                return fast
        return [Vector(co) for co in items if visible_point(co)]

    def partition_face_centers(records):
        """Return one canonical point per face, split by cage visibility.

        Face centers must never be emitted by both the neutral and selected
        categories.  In X-Ray, the old path first drew every raw selected center
        with the occluded (blue) color and then drew the visible surface anchor
        with the selected (orange) color.  A non-planar face can place those two
        points at slightly different depths/positions, producing the reported
        blue+orange double dot.  Partitioning here gives every face exactly one
        draw category and preserves the same surface anchor before/after select.
        """
        items = tuple(records or ())
        if np_ray_frame is not None:
            with np.errstate(all='ignore'):
                fast = np_ray_frame.face_centers(items, cage_bvh)
            if fast is not None:
                return fast
        visible = []
        occluded = []
        for record in items:
            try:
                face_index, center = int(record[0]), Vector(record[1])
            except Exception:
                continue
            hit = ray_hit(center, cage_bvh)
            if hit is not None and hit[0] is not None and hit[1] is not None and int(hit[1]) == face_index:
                # Blender's native face-center dot is placed at the BMesh face
                # median. Keep the add-on point at that exact canonical location;
                # use the ray hit only to classify visibility. A surface-hit anchor
                # on a non-planar face visibly diverges from Blender's dot.
                visible.append(center)
            else:
                # POST_PIXEL has no reliable scene depth.  X-Ray still needs one
                # point for a hidden face, so retain its original cage center only
                # in the occluded partition.  It is never drawn a second time.
                occluded.append(center)
        return visible, occluded

    line_shader = get_post_pixel_polyline_shader()
    point_shader = get_selected_element_pixel_shader()
    try:
        if line_shader is not None:
            for source_name, target_name, subdivisions in (
                ('cpu_edges', 'batch_pixel_edges', 4),
                ('cpu_sel_edges', 'batch_pixel_sel_edges', 8),
                ('cpu_hover_edges', 'batch_pixel_hover_edges', 8),
                ('cpu_native_cage_seam', 'batch_pixel_native_seam', 6),
                ('cpu_native_cage_sharp', 'batch_pixel_native_sharp', 6),
                ('cpu_native_cage_crease', 'batch_pixel_native_crease', 6),
                ('cpu_native_cage_bevel', 'batch_pixel_native_bevel', 6),
                ('cpu_topo_seam', 'batch_pixel_topo_seam', 6),
                ('cpu_topo_sharp', 'batch_pixel_topo_sharp', 6),
                ('cpu_topo_crease', 'batch_pixel_topo_crease', 6),
                ('cpu_topo_bevel', 'batch_pixel_topo_bevel', 6),
                ('cpu_topo_nonmanifold', 'batch_pixel_topo_nonmanifold', 6),
            ):
                src_coords = getattr(source, source_name, ())
                memo_key = ('LINES', source_name, subdivisions)
                memo_hit = pixel_memo_prev.get(memo_key) if pixel_memo_prev is not None else None
                if memo_hit is not None and memo_hit[0] is src_coords and memo_hit[1] is line_shader:
                    batch_value = memo_hit[2]
                else:
                    coords = visible_edge_segments(src_coords, subdivisions=subdivisions)
                    batch_value = batch_for_shader(line_shader, 'LINES', {'pos': coords}) if len(coords) else None
                if pixel_memo_new is not None and type(src_coords) is tuple:
                    pixel_memo_new[1][memo_key] = (src_coords, line_shader, batch_value)
                setattr(target, target_name, batch_value)
        if point_shader is not None:
            for source_name, target_name in (
                ('cpu_verts', 'batch_pixel_verts'),
                ('cpu_sel_verts', 'batch_pixel_sel_verts'),
                ('cpu_hover_verts', 'batch_pixel_hover_verts'),
            ):
                src_coords = getattr(source, source_name, ())
                memo_key = ('POINTS', source_name)
                memo_hit = pixel_memo_prev.get(memo_key) if pixel_memo_prev is not None else None
                if memo_hit is not None and memo_hit[0] is src_coords and memo_hit[1] is point_shader:
                    batch_value = memo_hit[2]
                else:
                    coords = visible_points(src_coords)
                    batch_value = batch_for_shader(point_shader, 'POINTS', {'pos': coords}) if len(coords) else None
                if pixel_memo_new is not None and type(src_coords) is tuple:
                    pixel_memo_new[1][memo_key] = (src_coords, point_shader, batch_value)
                setattr(target, target_name, batch_value)
            def canonical_face_records(records, excluded_indices=()):
                """Return at most one valid center record for each face index."""
                excluded = set(int(index) for index in tuple(excluded_indices or ()))
                seen = set()
                canonical = []
                for record in tuple(records or ()):
                    try:
                        face_index = int(record[0])
                        center = Vector(record[1])
                    except Exception:
                        continue
                    if face_index in excluded or face_index in seen:
                        continue
                    seen.add(face_index)
                    canonical.append((face_index, center))
                return tuple(canonical)

            src_sel_faces = getattr(source, 'cpu_sel_face_centers', ())
            src_neutral_faces = getattr(source, 'cpu_face_centers', ())
            memo_hit = pixel_memo_prev.get(('FACE_CENTERS',)) if pixel_memo_prev is not None else None
            if memo_hit is not None and memo_hit[0] is src_sel_faces and memo_hit[1] is src_neutral_faces and memo_hit[2] is point_shader:
                (target.batch_pixel_face_center_verts, target.batch_pixel_sel_face_center_verts,
                 target.batch_pixel_occluded_face_center_verts, target.batch_pixel_occluded_sel_face_center_verts) = memo_hit[3]
            else:
                selected_records = canonical_face_records(
                    src_sel_faces or ()
                )
                selected_indices = {int(record[0]) for record in selected_records}
                # Defensive exact-set ownership: even if a stale/compatibility cache
                # ever contains the same face in both lists, selected ownership wins.
                neutral_records = canonical_face_records(
                    src_neutral_faces or (),
                    selected_indices,
                )
                face_centers, occluded_face_centers = partition_face_centers(neutral_records)
                selected_face_centers, occluded_selected_face_centers = partition_face_centers(selected_records)
                target.batch_pixel_face_center_verts = batch_for_shader(point_shader, 'POINTS', {'pos': face_centers}) if len(face_centers) else None
                target.batch_pixel_sel_face_center_verts = batch_for_shader(point_shader, 'POINTS', {'pos': selected_face_centers}) if len(selected_face_centers) else None
                target.batch_pixel_occluded_face_center_verts = batch_for_shader(point_shader, 'POINTS', {'pos': occluded_face_centers}) if len(occluded_face_centers) else None
                target.batch_pixel_occluded_sel_face_center_verts = batch_for_shader(point_shader, 'POINTS', {'pos': occluded_selected_face_centers}) if len(occluded_selected_face_centers) else None
            if pixel_memo_new is not None and type(src_sel_faces) is tuple and type(src_neutral_faces) is tuple:
                pixel_memo_new[1][('FACE_CENTERS',)] = (src_sel_faces, src_neutral_faces, point_shader, (
                    target.batch_pixel_face_center_verts, target.batch_pixel_sel_face_center_verts,
                    target.batch_pixel_occluded_face_center_verts, target.batch_pixel_occluded_sel_face_center_verts))
    except Exception:
        return False
    if pixel_memo_new is not None and pixel_memo_slot is not None:
        try:
            _SOS_PIXEL_VIS_MEMO.pop(pixel_memo_slot, None)
            while len(_SOS_PIXEL_VIS_MEMO) >= _SOS_PIXEL_VIS_MEMO_LIMIT:
                _SOS_PIXEL_VIS_MEMO.pop(next(iter(_SOS_PIXEL_VIS_MEMO)))
            _SOS_PIXEL_VIS_MEMO[pixel_memo_slot] = pixel_memo_new
        except Exception:
            pass
    return True


def _sos_snapshot_pointer(value) -> int:
    try:
        return int(value.as_pointer())
    except Exception:
        return int(id(value)) if value is not None else 0


def _sos_snapshot_key(context=None, mode=None):
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return None
    try:
        area = getattr(ctx, 'area', None)
        region = getattr(ctx, 'region', None)
        if getattr(area, 'type', None) != 'VIEW_3D' or getattr(region, 'type', None) != 'WINDOW':
            return None
        mode_value = str(mode if mode is not None else getattr(ctx, 'mode', '') or '')
        return (
            _sos_snapshot_pointer(getattr(ctx, 'window', None)),
            _sos_snapshot_pointer(area),
            _sos_snapshot_pointer(region),
            _sos_snapshot_pointer(getattr(ctx, 'scene', None)),
            mode_value,
        )
    except Exception:
        return None


def _sos_snapshot_batch_count_item(item) -> int:
    total = 0
    for slot in getattr(item, '__slots__', ()):
        if not str(slot).startswith('batch_'):
            continue
        try:
            if getattr(item, slot, None) is not None:
                total += 1
        except Exception:
            pass
    return total


# attrgetter over the batch_* slots of SOS_BatchData, built on first use
# (False when it cannot be used).
_SOS_BATCH_SLOT_GETTER = None


def _sos_snapshot_batch_count(batches) -> int:
    global _SOS_BATCH_SLOT_GETTER
    getter = _SOS_BATCH_SLOT_GETTER
    if getter is None:
        try:
            names = tuple(str(slot) for slot in SOS_BatchData.__slots__ if str(slot).startswith('batch_'))
            getter = _sos_attrgetter(*names) if len(names) > 1 else False
        except Exception:
            getter = False
        _SOS_BATCH_SLOT_GETTER = getter
    total = 0
    for item in tuple(batches or ()):
        if getter and item.__class__ is SOS_BatchData:
            try:
                values = getter(item)
            except Exception:
                values = None
            if values is not None:
                for value in values:
                    if value is not None:
                        total += 1
                continue
        total += _sos_snapshot_batch_count_item(item)
    return int(total)


def _sos_snapshot_expected_geometry(context, mode, mesh_overlay_enabled, object_hover_enabled, prefs=None) -> bool:
    if not (mesh_overlay_enabled or object_hover_enabled):
        return False
    try:
        if mode in {'EDIT_MESH', 'EDIT_LATTICE', 'EDIT_CURVE', 'EDIT_CURVES'} and not any(
            bool(getattr(prefs, name, True))
            for name in ('show_verts_edit', 'show_edges_edit', 'show_faces_edit', 'show_hov_verts', 'show_hov_edges', 'show_hov_faces')
        ):
            # Every element is switched off: an empty record is the correct result.
            return False
        if mode == 'EDIT_MESH':
            objs = tuple(getattr(context, 'objects_in_mode', ()) or ())
            return any(getattr(obj, 'type', None) == 'MESH' for obj in objs)
        if mode in {'EDIT_CURVE', 'EDIT_CURVES'}:
            objs = tuple(getattr(context, 'objects_in_mode', ()) or ())
            return any(getattr(obj, 'type', None) in {'CURVE', 'SURFACE', 'FONT', 'CURVES'} for obj in objs)
        if mode == 'EDIT_LATTICE':
            obj = getattr(context, 'object', None) or getattr(context, 'active_object', None)
            return bool(obj is not None and getattr(obj, 'type', None) == 'LATTICE')
        if mode in {'OBJECT', 'SCULPT'}:
            objs = tuple(getattr(context, 'selected_objects', ()) or ())
            if not objs:
                obj = getattr(context, 'active_object', None)
                objs = (obj,) if obj is not None else ()
            return any(getattr(obj, 'type', None) in {'MESH', 'CURVE', 'SURFACE', 'FONT', 'META', 'CURVES', 'LATTICE'} for obj in objs)
    except Exception:
        return False
    return False


def _sos_publish_proportional_snapshot(context, generation: int) -> None:
    # Mesh/Curve publication remains independent of the optional proportional
    # heatmap, and the heatmap does not need any Mesh/Curve geometry of its own.
    # Its last completed record is preserved on failure.
    try:
        from . import properties as _sos_properties
        builder = getattr(_sos_properties, 'build_view3d_snapshot_for_context', None)
        if callable(builder):
            builder(context, int(generation))
    except Exception:
        pass


def _sos_draw_proportional_front_pass(ctx) -> None:
    try:
        wm_prop = getattr(ctx, 'window_manager', None)
        if wm_prop is not None and bool(getattr(wm_prop, 'sos_proportional_overlay_enabled', False)):
            from . import properties as _sos_prop_overlay
            _draw_prop_front = getattr(_sos_prop_overlay, 'draw_callback_prop_mesh_front_pass', None)
            if callable(_draw_prop_front):
                _draw_prop_front(ctx)
    except Exception:
        pass


def _sos_build_overlay_snapshot_for_context(context, generation: int, *, same_pass_signature_cache=None):
    """Build one immutable GPU-resource record outside draw callbacks."""
    if context is None or not _sos_runtime_registered:
        return None
    if not _sos_workspace_filter_allows_addon(context):
        return None
    area = getattr(context, 'area', None)
    region = getattr(context, 'region', None)
    rv3d = getattr(context, 'region_data', None)
    if getattr(area, 'type', None) != 'VIEW_3D' or getattr(region, 'type', None) != 'WINDOW' or rv3d is None:
        return None
    mode = str(getattr(context, 'mode', '') or '')
    if mode not in {'EDIT_MESH', 'EDIT_LATTICE', 'EDIT_CURVE', 'EDIT_CURVES', 'OBJECT', 'SCULPT'}:
        return None
    wm = getattr(context, 'window_manager', None)
    mesh_overlay_enabled = bool(getattr(wm, 'sos_enabled', False))
    object_hover_enabled = bool(getattr(wm, 'sos_object_hover_overlay_enabled', False))
    runtime_needed = (
        (mode in {'EDIT_MESH', 'EDIT_LATTICE', 'EDIT_CURVE', 'EDIT_CURVES'} and mesh_overlay_enabled)
        or (mode in {'OBJECT', 'SCULPT'} and (mesh_overlay_enabled or object_hover_enabled))
    )
    if not runtime_needed:
        _sos_publish_proportional_snapshot(context, generation)
        return None
    prefs = get_effective_settings(context)
    if prefs is None:
        return None
    if not is_active_view_draw_context(context, prefs):
        return None
    shader = get_overlay_shader()
    grad_shader = get_gradient_shader()
    if shader is None:
        return None
    object_like_overlay = bool(
        (mode in {'OBJECT', 'SCULPT'} and (mesh_overlay_enabled or object_hover_enabled))
        or (mode == 'EDIT_LATTICE' and mesh_overlay_enabled)
    )
    overlay_batches = (
        _collect_edit_mesh_batches(context, prefs, mesh_overlay_enabled and mode == 'EDIT_MESH', shader, grad_shader)
        + _collect_edit_curve_batches(context, prefs, mesh_overlay_enabled and mode in {'EDIT_CURVE', 'EDIT_CURVES'}, shader, grad_shader)
        + _collect_object_mode_batches(
            context, prefs, object_like_overlay, shader,
            overlay_mode=mode, draw_base_overlay=mesh_overlay_enabled,
            same_pass_signature_cache=same_pass_signature_cache,
        )
    )
    exclude_names = set()
    for attr_name in ('selected_objects', 'objects_in_mode'):
        try:
            for obj in tuple(getattr(context, attr_name, ()) or ()):
                name = str(getattr(obj, 'name', '') or '')
                if name:
                    exclude_names.add(name)
        except Exception:
            pass
    try:
        active_obj = getattr(context, 'object', None) or getattr(context, 'active_object', None)
        name = str(getattr(active_obj, 'name', '') or '') if active_obj is not None else ''
        if name:
            exclude_names.add(name)
    except Exception:
        pass
    extra_batches = _collect_extra_occluder_batches(context, prefs, shader, exclude_names)
    batches = tuple(overlay_batches + extra_batches)
    batch_count = _sos_snapshot_batch_count(batches)
    _sos_publish_proportional_snapshot(context, generation)
    if batch_count <= 0:
        if _sos_snapshot_expected_geometry(context, mode, mesh_overlay_enabled, object_hover_enabled, prefs):
            raise RuntimeError('expected overlay geometry produced no GPU batches')
        batches = ()
    key = _sos_snapshot_key(context, mode)
    if key is None:
        return None
    try:
        region_size = (int(region.width), int(region.height))
    except Exception:
        region_size = (0, 0)
    record = {
        'key': key,
        'generation': int(generation),
        'mode': mode,
        'region_size': region_size,
        # POST_PIXEL edit-element batches are CPU visibility-clipped and may be
        # consumed only by this exact view.  POST_VIEW geometry remains view-
        # independent and is intentionally allowed to draw while this signature
        # is stale during navigation.
        'view_signature': tuple(_sos_lightest_matrix_signature(rv3d) or ()),
        'shader': shader,
        'grad_shader': grad_shader,
        'batches': batches,
        'batch_count': int(batch_count),
        'created_monotonic': float(time.monotonic()),
    }
    return record


def _sos_publish_overlay_snapshot(record) -> bool:
    if not isinstance(record, dict):
        return False
    key = record.get('key')
    if not key or record.get('shader') is None:
        return False
    if int(record.get('batch_count', 0) or 0) <= 0 and tuple(record.get('batches') or ()):
        return False
    _sos_overlay_snapshots[key] = record
    try:
        overflow = len(_sos_overlay_snapshots) - _SOS_OVERLAY_SNAPSHOT_MAX_RECORDS
        if overflow > 0:
            ordered = sorted(
                _sos_overlay_snapshots.items(),
                key=lambda item: float(item[1].get('created_monotonic', 0.0)),
            )
            for old_key, _old in ordered[:overflow]:
                _sos_overlay_snapshots.pop(old_key, None)
    except Exception:
        pass
    return True


def _sos_rebuild_overlay_snapshots() -> int:
    global _sos_overlay_snapshot_generation, _sos_overlay_snapshot_last_build_time, _sos_overlay_snapshot_last_error
    global _sos_edit_collect_degraded, _sos_overlay_snapshot_last_degraded
    _sos_edit_collect_degraded = False
    _sos_overlay_snapshot_generation += 1
    generation = int(_sos_overlay_snapshot_generation)
    built = 0
    live_keys = set()
    errors = []
    same_pass_signature_cache = {}
    for override in tuple(_sos_iter_view3d_modal_overrides(getattr(bpy, 'context', None))):
        try:
            with bpy.context.temp_override(**override):
                ctx = bpy.context
                try:
                    apply_blender_adjacent_edge_gradient_visibility(ctx, get_effective_settings(ctx))
                except Exception:
                    pass
                key = _sos_snapshot_key(ctx)
                if key is not None:
                    live_keys.add(key)
                try:
                    record = _sos_build_overlay_snapshot_for_context(
                        ctx, generation, same_pass_signature_cache=same_pass_signature_cache,
                    )
                except Exception as exc:
                    errors.append(f'{type(exc).__name__}: {exc}')
                    continue
                if record is not None and _sos_publish_overlay_snapshot(record):
                    built += 1
        except Exception as exc:
            errors.append(f'{type(exc).__name__}: {exc}')
    # Remove records whose native Window/Area/Region or scene/mode no longer exists.
    for key in tuple(_sos_overlay_snapshots.keys()):
        if key not in live_keys:
            _sos_overlay_snapshots.pop(key, None)
    _sos_overlay_snapshot_last_build_time = float(time.monotonic())
    _sos_overlay_snapshot_last_error = errors[-1] if errors else ''
    _sos_overlay_snapshot_last_degraded = bool(_sos_edit_collect_degraded)
    return int(built)


def _sos_edit_degraded_wait_seconds() -> float:
    """Seconds until the edit rebuild guards that force cached batches expire."""
    wait = 0.0
    try:
        wait = max(wait, float(_sos_edit_batch_circuit_breaker_until or 0.0) - _sos_perf_counter())
    except Exception:
        pass
    try:
        now = time.time()
        wait = max(wait, float(_sos_edit_mesh_rebuild_deferred_until or 0.0) - now)
        wait = max(wait, float(_sos_edit_mutation_guard_until or 0.0) - now)
    except Exception:
        pass
    return max(0.0, min(2.0, wait))


def _sos_schedule_degraded_snapshot_followup(context=None) -> bool:
    """Queue one rebuild for the end of the guard window after a partial record.

    Bounded: at most _SOS_OVERLAY_SNAPSHOT_DEGRADED_FOLLOWUPS_MAX consecutive
    follow-ups; the count resets when a complete record is published.
    """
    global _sos_overlay_snapshot_degraded_followups, _sos_overlay_snapshot_due
    if not _sos_runtime_registered:
        return False
    if int(_sos_overlay_snapshot_degraded_followups or 0) >= _SOS_OVERLAY_SNAPSHOT_DEGRADED_FOLLOWUPS_MAX:
        return False
    _sos_overlay_snapshot_degraded_followups = int(_sos_overlay_snapshot_degraded_followups or 0) + 1
    wait = _sos_edit_degraded_wait_seconds()
    if not request_overlay_snapshot_rebuild('degraded_followup', context=context, immediate=False):
        return False
    try:
        _sos_overlay_snapshot_due = max(
            float(_sos_overlay_snapshot_due or 0.0),
            float(time.monotonic()) + wait + 0.05,
        )
    except Exception:
        pass
    return True


def _sos_overlay_snapshot_rebuild_timer():
    global _sos_overlay_snapshot_timer_pending, _sos_overlay_snapshot_timer_attempts
    global _sos_overlay_snapshot_due, _sos_overlay_snapshot_reasons
    global _sos_overlay_snapshot_degraded_followups
    if not _sos_runtime_registered:
        _sos_overlay_snapshot_timer_pending = False
        _sos_overlay_snapshot_timer_attempts = 0
        _sos_overlay_snapshot_reasons.clear()
        return None
    now = float(time.monotonic())
    if now < float(_sos_overlay_snapshot_due or 0.0):
        return max(0.001, float(_sos_overlay_snapshot_due) - now)
    start_serial = int(_sos_overlay_snapshot_request_serial)
    _sos_overlay_snapshot_timer_attempts += 1
    built = 0
    try:
        built = int(_sos_rebuild_overlay_snapshots())
    except Exception:
        built = 0
    changed_during_build = int(_sos_overlay_snapshot_request_serial) != start_serial
    if (changed_during_build or built <= 0) and _sos_overlay_snapshot_timer_attempts < _SOS_OVERLAY_SNAPSHOT_MAX_ATTEMPTS:
        _sos_overlay_snapshot_due = float(time.monotonic()) + _SOS_OVERLAY_SNAPSHOT_MIN_INTERVAL
        return _SOS_OVERLAY_SNAPSHOT_MIN_INTERVAL
    tail_needed = bool(changed_during_build)
    degraded_followup = bool(built > 0 and _sos_overlay_snapshot_last_degraded and not tail_needed)
    if built > 0 and not _sos_overlay_snapshot_last_degraded:
        _sos_overlay_snapshot_degraded_followups = 0
    _sos_overlay_snapshot_timer_pending = False
    _sos_overlay_snapshot_timer_attempts = 0
    _sos_overlay_snapshot_due = 0.0
    _sos_overlay_snapshot_reasons.clear()
    try:
        tag_view3d_redraw()
    except Exception:
        pass
    if tail_needed and _sos_runtime_registered:
        request_overlay_snapshot_rebuild('coalesced_tail', context=getattr(bpy, 'context', None), immediate=False)
    elif degraded_followup:
        _sos_schedule_degraded_snapshot_followup(getattr(bpy, 'context', None))
    return None


def request_overlay_snapshot_rebuild(reason='', context=None, immediate=False) -> bool:
    """Request one finite, coalesced event-side snapshot build."""
    global _sos_overlay_snapshot_request_serial, _sos_overlay_snapshot_timer_pending
    global _sos_overlay_snapshot_due, _sos_overlay_snapshot_timer_attempts
    if not _sos_runtime_registered:
        return False
    # Mode/selection updates can restore Blender's native face-center flag.
    # Reclaim the exact View3D spaces before the redraw is queued, rather than
    # waiting until POST_PIXEL after the native dot has already been rasterized.
    try:
        apply_blender_adjacent_edge_gradient_visibility(
            context or getattr(bpy, 'context', None),
            get_effective_settings(context or getattr(bpy, 'context', None)),
        )
    except Exception:
        pass
    reason_text = str(reason or '')
    if reason_text:
        _sos_overlay_snapshot_reasons.add(reason_text)
    now = float(time.monotonic())
    minimum_due = float(_sos_overlay_snapshot_last_build_time or 0.0) + _SOS_OVERLAY_SNAPSHOT_MIN_INTERVAL
    requested_due = now if immediate else max(now, minimum_due)
    if _sos_overlay_snapshot_timer_pending:
        # Draw-miss requests merely confirm the already-pending job.  They must
        # not advance the input serial every redraw or an empty/stale viewport
        # could keep the finite builder alive indefinitely.
        if not reason_text.startswith('draw_') and reason_text not in {'prop_draw_missing'}:
            _sos_overlay_snapshot_request_serial += 1
        _sos_overlay_snapshot_due = min(float(_sos_overlay_snapshot_due or requested_due), requested_due)
        return True
    _sos_overlay_snapshot_request_serial += 1
    _sos_overlay_snapshot_timer_pending = True
    _sos_overlay_snapshot_timer_attempts = 0
    _sos_overlay_snapshot_due = requested_due
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    if timers is None:
        _sos_overlay_snapshot_timer_pending = False
        _sos_overlay_snapshot_timer_attempts = 0
        return False
    try:
        timers.register(_sos_overlay_snapshot_rebuild_timer, first_interval=max(0.0, requested_due - now))
        return True
    except Exception:
        _sos_overlay_snapshot_timer_pending = False
        _sos_overlay_snapshot_timer_attempts = 0
        return False


def _sos_snapshot_for_draw(context, mode):
    key = _sos_snapshot_key(context, mode)
    if key is None:
        return None
    record = _sos_overlay_snapshots.get(key)
    if not isinstance(record, dict):
        request_overlay_snapshot_rebuild('draw_missing', context=context, immediate=True)
        return None
    try:
        region = getattr(context, 'region', None)
        size = (int(region.width), int(region.height))
    except Exception:
        size = (0, 0)
    if record.get('mode') != str(mode or '') or tuple(record.get('region_size') or ()) != size:
        request_overlay_snapshot_rebuild('draw_stale_identity', context=context, immediate=True)
        return None
    return record


def clear_overlay_snapshots() -> None:
    global _sos_overlay_snapshot_timer_pending, _sos_overlay_snapshot_timer_attempts
    global _sos_overlay_snapshot_due, _sos_overlay_snapshot_reasons
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and timers.is_registered(_sos_overlay_snapshot_rebuild_timer):
            timers.unregister(_sos_overlay_snapshot_rebuild_timer)
    except Exception:
        pass
    _sos_overlay_snapshot_timer_pending = False
    _sos_overlay_snapshot_timer_attempts = 0
    _sos_overlay_snapshot_due = 0.0
    _sos_overlay_snapshot_reasons.clear()
    _sos_overlay_snapshots.clear()
    _sos_lattice_pixel_snapshot_by_region.clear()
    _sos_lattice_region_size_by_region.clear()
    try:
        from . import properties as _sos_properties
        clear_prop = getattr(_sos_properties, 'clear_view3d_snapshots', None)
        if callable(clear_prop):
            clear_prop()
    except Exception:
        pass


def _face_tris_local(face):
    try:
        from mathutils import geometry
        return [(t[0], t[1], t[2]) for t in geometry.tessellate_polygon([[v.co for v in face.verts]])]
    except Exception: return []

def _face_tri_indices_global(face):
    try:
        verts = tuple(face.verts)
        n = len(verts)
        if n == 3:
            return [(int(verts[0].index), int(verts[1].index), int(verts[2].index))]
        if n == 4:
            return [(int(verts[0].index), int(verts[1].index), int(verts[2].index)), (int(verts[0].index), int(verts[2].index), int(verts[3].index))]
        from mathutils import geometry
        local_tris = geometry.tessellate_polygon([[v.co for v in verts]])
        return [(int(verts[a].index), int(verts[b].index), int(verts[c].index)) for a, b, c in local_tris]
    except Exception:
        return []


def _sos_project_edit_local_point(mvp_np, region, co):
    """Project one edit-cage point with the same matrix used by hover picking."""
    try:
        clip = np.asarray(mvp_np, dtype=np.float64) @ np.asarray(
            (float(co[0]), float(co[1]), float(co[2]), 1.0),
            dtype=np.float64,
        )
        w = float(clip[3])
        if not math.isfinite(w) or w <= 1.0e-8:
            return None
        x = (float(clip[0]) / w + 1.0) * 0.5 * float(region.width)
        y = (float(clip[1]) / w + 1.0) * 0.5 * float(region.height)
        if not (math.isfinite(x) and math.isfinite(y)):
            return None
        return x, y, w
    except Exception:
        return None


def _sos_front_edit_face_index(bm, obj, cache, region, rv3d, mx, my):
    """Return the editable-cage face hit by the viewport ray."""
    try:
        ro_world, rd_world = _sos_view_ray_clip_stable(region, rv3d, (mx, my))
        inv_mw = obj.matrix_world.inverted()
        ro = inv_mw @ ro_world
        rd = inv_mw.to_3x3() @ rd_world
        rd.normalize()
        bvh = cache.get('hover_face_bvh')
        if bvh is None:
            from mathutils.bvhtree import BVHTree
            bvh = BVHTree.FromBMesh(bm, epsilon=0.0)
            cache['hover_face_bvh'] = bvh
        loc, _normal, face_index, _distance = bvh.ray_cast(ro, rd)
        if loc is None or face_index is None:
            return -1
        face_index = int(face_index)
        if face_index < 0 or face_index >= len(bm.faces):
            return -1
        return face_index
    except Exception:
        return -1


def _sos_edit_click_hover_indices(
    bm,
    obj,
    cache,
    region,
    rv3d,
    mvp_np,
    mx,
    my,
    sel_mode,
    lod_mode,
    show_hov_verts,
    show_hov_edges,
    show_hov_faces,
    v_rad_sq,
    e_rad_sq,
):
    """Resolve the unselected element that the edit click picker can hit.

    Vertex and edge modes use their configured screen-space click radii. Face
    mode is deliberately face-center-dot only: the pointer must be inside the
    center-dot radius and the viewport ray must hit that same front cage face.
    """
    hv = he = hf = -1
    v_co = cache.get('v_co')
    if v_co is None or len(v_co) <= 0:
        return hv, he, hf

    try:
        v_co_np = np.asarray(v_co, dtype=np.float32)
        c4 = np.ones((len(v_co_np), 4), dtype=np.float32)
        c4[:, :3] = v_co_np
        clip = c4 @ np.asarray(mvp_np, dtype=np.float32).T
        w = clip[:, 3]
        valid_w = np.isfinite(w) & (w > 1.0e-8)
        safe_w = np.where(valid_w, w, 1.0)
        sx = (clip[:, 0] / safe_w + 1.0) * 0.5 * float(region.width)
        sy = (clip[:, 1] / safe_w + 1.0) * 0.5 * float(region.height)
    except Exception:
        return hv, he, hf

    if lod_mode != 'FACE_ONLY' and bool(sel_mode[0]) and bool(show_hov_verts):
        try:
            valid = valid_w & np.asarray(cache.get('v_m'), dtype=bool)
            if np.any(valid):
                dsq = (sx - float(mx)) ** 2 + (sy - float(my)) ** 2
                valid &= np.isfinite(dsq) & (dsq <= float(v_rad_sq))
                if np.any(valid):
                    hv = int(np.argmin(np.where(valid, dsq, np.inf)))
        except Exception:
            hv = -1

    if lod_mode != 'FACE_ONLY' and bool(sel_mode[1]) and bool(show_hov_edges) and hv == -1:
        try:
            # The normal-edge draw mask deliberately excludes Seam / Sharp /
            # Crease / Bevel edges so their native diagnostic color is not
            # mixed with the unselected Smart Overlay edge color.  Hover is a
            # separate interaction layer and must still be pickable on those
            # diagnostic edges, so use its independent mask here.
            edge_mask = np.asarray(cache.get('e_hm', cache.get('e_m')), dtype=bool)
            if np.any(edge_mask):
                e1 = np.asarray(cache.get('e1'), dtype=np.int32)
                e2 = np.asarray(cache.get('e2'), dtype=np.int32)
                x1, y1, x2, y2 = sx[e1], sy[e1], sx[e2], sy[e2]
                dx, dy = x2 - x1, y2 - y1
                length_sq = dx ** 2 + dy ** 2
                t = np.clip(
                    ((float(mx) - x1) * dx + (float(my) - y1) * dy)
                    / np.where(length_sq > 1.0e-12, length_sq, 1.0),
                    0.0,
                    1.0,
                )
                dsq = (float(mx) - (x1 + t * dx)) ** 2 + (float(my) - (y1 + t * dy)) ** 2
                valid = valid_w[e1] & valid_w[e2] & edge_mask
                valid &= np.isfinite(dsq) & (dsq <= float(e_rad_sq))
                if np.any(valid):
                    he = int(np.argmin(np.where(valid, dsq, np.inf)))
        except Exception:
            he = -1

    if bool(sel_mode[2]) and bool(show_hov_faces) and hv == -1 and he == -1:
        face_index = _sos_front_edit_face_index(bm, obj, cache, region, rv3d, mx, my)
        try:
            face = bm.faces[face_index] if face_index >= 0 else None
            if face is None or bool(face.hide) or bool(face.select):
                return hv, he, hf
            if not (cache.get('ft') or {}).get(face_index):
                return hv, he, hf
            indices = [int(v.index) for v in face.verts]
            if not indices:
                return hv, he, hf
            center = np.mean(v_co_np[indices], axis=0)
            projected = _sos_project_edit_local_point(mvp_np, region, center)
            if projected is None:
                return hv, he, hf
            dx = float(mx) - float(projected[0])
            dy = float(my) - float(projected[1])
            if (dx * dx + dy * dy) <= float(v_rad_sq):
                hf = face_index
        except Exception:
            hf = -1

    return hv, he, hf


# Live edit rebuilds during one modal transform.  Each entry is
# [element counts, consecutive budget overruns, last reason, rebuild begun].
_sos_xform_budget_fail = {}


def _sos_xform_budget_begin(name, counts):
    """Return the last budget reason when this live rebuild should be skipped.

    During one modal transform, an object whose last two live rebuilds with the
    same element counts both ran out of the edit build budget before the second
    half of the face loop (at least half of the face loop and the batch creation
    were still ahead) would repeat the same work and end in the same budget
    fallback.  The caller then raises the budget exception at once, so the same
    fallback runs without the rebuild.  The table is cleared whenever no edit
    transform is running.
    """
    try:
        entry = _sos_xform_budget_fail.get(name)
        if entry is None or entry[0] != counts:
            return ''
        if entry[3]:
            # The previous live rebuild began and did not run out of budget.
            del _sos_xform_budget_fail[name]
            return ''
        if entry[1] >= 2:
            return entry[2]
        entry[3] = True
        return ''
    except Exception:
        return ''


def _sos_xform_budget_note_failure(name, counts, reason, face_late=False):
    try:
        reason = str(reason or '')
        entry = _sos_xform_budget_fail.get(name)
        if entry is None or entry[0] != counts:
            entry = [counts, 0, '', False]
            _sos_xform_budget_fail[name] = entry
        if reason == 'edit face batch rebuild' and face_late:
            # The rebuild reached the second half of the face loop; a later
            # one may finish.
            entry[1] = 0
        else:
            entry[1] += 1
        entry[2] = reason
        entry[3] = False
    except Exception:
        pass


def _collect_edit_mesh_batches(context, prefs, do_edit, shader, grad_shader):
    global _sos_base_cache, _sos_edit_collect_degraded
    batches = []
    if not do_edit: return batches
    _sos_edit_build_start = _sos_perf_counter()
    wm, region, rv3d = getattr(context, 'window_manager', None), getattr(context, 'region', None), getattr(context, 'region_data', None)
    mx, my = _sos_tracked_mouse_region_coords(context, region)
    lightest_disable_mesh_hover = _sos_opt_bool(prefs, 'optimization_lightest_disable_mesh_hover', False)
    if lightest_disable_mesh_hover:
        mx, my = -1, -1
    navigation_light_active = _sos_lightest_mesh_overlay_navigation_active(context, prefs, rv3d)
    edit_transform_modal_active = _sos_edit_transform_modal_active(context, prefs)
    if not edit_transform_modal_active and _sos_xform_budget_fail:
        _sos_xform_budget_fail.clear()
    if edit_transform_modal_active:
        try:
            _touch_edit_live_sync(_SOS_EDIT_TRANSFORM_LIVE_ACTIVE_INTERVAL * 2.5)
        except Exception:
            pass
        # During active edit transforms, drawing stale cached batches is worse than
        # a bounded rebuild.  Navigation-freeze modes are for viewport movement,
        # not for mesh element transforms.
        navigation_light_active = False
    lightest_freeze_nav = bool(
        (
            _sos_opt_bool(prefs, 'optimization_lightest_freeze_batches_during_navigation', False)
            or _sos_opt_bool(prefs, 'optimization_navigation_light_mode', False)
        )
        and navigation_light_active
    )
    lightest_active_only = _sos_opt_bool(prefs, 'optimization_lightest_active_object_only', False)
    use_indexed_edit_batches = _sos_opt_bool(prefs, 'optimization_indexed_edit_batches', False)
    active_obj = getattr(context, 'active_object', None) or getattr(context, 'object', None)

    
    try:
        depsgraph = context.evaluated_depsgraph_get()
    except Exception:
        return batches
    sel_mode = context.tool_settings.mesh_select_mode
    mode_kind = _mesh_edit_mode_kind(context)
    mode_kinds = _mesh_edit_selection_modes(context)
    select_mode_vertex_center_overlay = bool(getattr(prefs, 'use_select_mode_vertex_center_overlay', True))
    suppress_actual_vertex_points_by_select_mode = bool(
        select_mode_vertex_center_overlay
        and ('VERT' not in mode_kinds)
        and bool(mode_kinds.intersection({'EDGE', 'FACE'}))
    )
    draw_face_center_vertex_points = bool(
        select_mode_vertex_center_overlay
        and ('FACE' in mode_kinds)
        and ('VERT' not in mode_kinds)
        and bool(getattr(prefs, 'show_verts_edit', False))
    )
    native_edge_overlay_flags = _native_mesh_edit_edge_overlay_flags(context)
    hide_vertex_mode_linked_overlay = bool(getattr(prefs, "hide_blender_vertex_mode_linked_edge_face_overlay", False))
    hide_edge_mode_linked_overlay = bool(getattr(prefs, "hide_blender_edge_mode_linked_vertex_face_overlay", False))
    hide_face_mode_linked_overlay = bool(getattr(prefs, "hide_blender_face_mode_linked_vertex_edge_overlay", False))
    need_cover_edges_from_selected_vertices = ('VERT' in mode_kinds and hide_vertex_mode_linked_overlay)
    need_cover_faces_from_selected_vertices = ('VERT' in mode_kinds and hide_vertex_mode_linked_overlay)
    need_cover_vertices_from_selected_edges = ('EDGE' in mode_kinds and hide_edge_mode_linked_overlay)
    need_cover_faces_from_selected_edges = ('EDGE' in mode_kinds and hide_edge_mode_linked_overlay)
    need_cover_vertices_from_selected_faces = ('FACE' in mode_kinds and hide_face_mode_linked_overlay)
    need_cover_edges_from_selected_faces = ('FACE' in mode_kinds and hide_face_mode_linked_overlay)
    if suppress_actual_vertex_points_by_select_mode:
        need_cover_vertices_from_selected_edges = False
        need_cover_vertices_from_selected_faces = False
    v_rad_sq, e_rad_sq = get_csdt_radius("VERT")**2, get_csdt_radius("EDGE")**2
    se_col, e_vis, e_occ = (*prefs.selected_edge_overlay_color, 1.0), (*prefs.edge_color, 1.0), (*prefs.edge_occluded_color, 1.0)
    hide_adjacent_edge_gradient = bool(getattr(prefs, "hide_blender_adjacent_edge_gradient", True))
    # --- Topology Checks (config) ---
    topo_on = bool(getattr(prefs, "topology_checks_enabled", False))
    topo_sel = getattr(prefs, "topo_selection_filter", "ALL") or "ALL"
    if _sos_opt_bool(prefs, 'optimization_lightest_disable_topology_diagnostics', False):
        topo_on = False
    topo_edges_on = topo_on and bool(getattr(prefs, "topo_edges_enabled", True))
    topo_faces_on = topo_on and bool(getattr(prefs, "topo_faces_enabled", True))

    topo_show_seams = topo_edges_on and bool(getattr(prefs, "topo_show_seams", True))
    topo_show_sharp = topo_edges_on and bool(getattr(prefs, "topo_show_sharp", True))
    topo_show_crease = topo_edges_on and bool(getattr(prefs, "topo_show_crease", False))
    topo_show_bevel = topo_edges_on and bool(getattr(prefs, "topo_show_bevel_weight", False))
    topo_show_nm = topo_edges_on and bool(getattr(prefs, "topo_show_non_manifold", True))
    native_show_seams = bool(native_edge_overlay_flags.get('seam', False))
    native_show_sharp = bool(native_edge_overlay_flags.get('sharp', False))
    native_show_crease = bool(native_edge_overlay_flags.get('crease', False))
    native_show_bevel = bool(native_edge_overlay_flags.get('bevel', False))

    topo_crease_th = float(getattr(prefs, "topo_crease_threshold", 0.5) or 0.5)
    topo_bevel_th = float(getattr(prefs, "topo_bevel_weight_threshold", 0.5) or 0.5)

    topo_show_ngons = topo_faces_on and bool(getattr(prefs, "topo_show_ngons", False))
    topo_show_small = topo_faces_on and bool(getattr(prefs, "topo_show_small_faces", False))
    topo_small_area = float(getattr(prefs, "topo_small_face_area", 1e-6) or 1e-6)
    topo_show_backfaces = topo_faces_on and bool(getattr(prefs, "topo_show_backfaces", False))


    edit_mesh_objects = [o for o in _sos_iter_edit_mesh_objects_for_live_transform(context) if getattr(o, 'type', None) == 'MESH']
    if lightest_active_only and active_obj is not None:
        filtered = [o for o in edit_mesh_objects if o == active_obj]
        if filtered:
            edit_mesh_objects = filtered
    if _sos_edit_overlay_circuit_breaker_active() and not edit_transform_modal_active:
        # Emergency path: draw only last known-good batches and return immediately.
        # This keeps menus/transforms responsive while a heavy edit rebuild settles.
        if edit_mesh_objects:
            _sos_edit_collect_degraded = True
        for _obj in edit_mesh_objects:
            try:
                _cache = _sos_base_cache.get(("EDIT", _obj.name))
                _sos_append_cached_edit_mesh_batch(
                    batches, _obj, _cache,
                    prefer_evaluated_faces=bool(_has_visible_edit_mode_modifier(_obj) and _use_evaluated_edit_mode_face_overlay(_obj, prefs)),
                    shader=shader,
                )
            except Exception:
                pass
        return batches
    try:
        _sos_apply_deferred_edit_cache_invalidations_if_safe()
    except Exception:
        pass
    guarded_edit_rebuild = bool(
        (not edit_transform_modal_active)
        and (
            _sos_edit_mesh_rebuild_deferred_active()
            or _sos_edit_mesh_mutation_operator_guard_active(context)
        )
    )
    for obj in edit_mesh_objects:
        _sos_xform_counts = None
        _sos_xform_skip_reason = ''
        try:
            cache_key = ("EDIT", obj.name)
            cache = _sos_base_cache.get(cache_key)
            if edit_transform_modal_active:
                # A transform-in-progress must never display a previous edit batch.
                # Blender may update the edit BMesh between modal mouse events while
                # dependency dirty generations and evaluated modifier caches still lag;
                # rebuild from the currently live edit data for this redraw.
                cache = None
            # Use a larger bounded preliminary budget while Dense Mesh/Curve LOD is OFF.
            # The previous fixed 60 ms check could trip before the actual element
            # count was known, leaving high-density edit meshes with no first cache.
            _sos_check_edit_budget(
                _sos_edit_build_start,
                0.30 if not _sos_opt_bool(prefs, 'optimization_lightest_lod_skip_dense_vertices_edges', False) else _SOS_EDIT_BATCH_BUILD_BUDGET_SECONDS,
                'before edit object rebuild',
            )

            if guarded_edit_rebuild:
                _sos_edit_collect_degraded = True
                # Do not touch obj.data / BMesh while Blender is still finalizing a
                # multi-object edit operation.  Reuse the last known-good GPU batches
                # for this short window, then rebuild from fresh BMesh data.
                if _sos_append_cached_edit_mesh_batch(
                    batches, obj, cache,
                    prefer_evaluated_faces=bool(_has_visible_edit_mode_modifier(obj) and _use_evaluated_edit_mode_face_overlay(obj, prefs)),
                    shader=shader,
                ):
                    continue
                # No previous batch is available.  Skipping one or two redraws is
                # safer than asking Blender for a transient edit mesh and crashing.
                continue
            visible_edit_mods = _has_visible_edit_mode_modifier(obj)
            use_evaluated_faces_pref = bool(visible_edit_mods and _use_evaluated_edit_mode_face_overlay(obj, prefs))
            # Blender's own Mesh Edit Mode diagnostic edge overlays
            # (Seam / Sharp / Crease / Bevel) are edit-cage overlays.  Do not
            # mirror them onto modifier-evaluated meshes: with Mirror, Solidify,
            # Subdivision, etc. this creates a second diagnostic overlay on the
            # final modifier result while Blender's standard overlay remains on
            # the base editable mesh.  Smart Overlay only keeps edit-cage batches
            # for the X-Ray front redraw pass, so the diagnostics stay readable
            # without appearing twice on cage + evaluated geometry.
            use_native_eval_edge_pref = False
            # Modifier-evaluated visible/occluded face fill remains active during
            # in-progress edit transforms.  A double-buffered evaluated-face cache
            # keeps the previous modifier result visible until the fresh result is
            # ready, so the face overlay never switches to the base edit cage.
            has_edit_mods = bool(use_evaluated_faces_pref)
            native_eval_edge_overlay = False
            bm = bmesh.from_edit_mesh(obj.data)
            try:
                bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
            except Exception:
                pass
            edge_diag_flags = {
                'seam': bool(native_show_seams or topo_show_seams),
                'sharp': bool(native_show_sharp or topo_show_sharp),
                'crease': bool(native_show_crease or topo_show_crease),
                'bevel': bool(native_show_bevel or topo_show_bevel),
            }
            live_sync = bool(_edit_live_sync_active() or edit_transform_modal_active)
            # Hover LOD (NEW) - computed every call (fixes cached path)
            num_v_cur = len(bm.verts)
            num_e_cur = len(bm.edges)
            num_f_cur = len(bm.faces)
            _sos_total_edit_elements = int(num_v_cur) + int(num_e_cur) + int(num_f_cur)
            if edit_transform_modal_active:
                _sos_xform_counts = (int(num_v_cur), int(num_e_cur), int(num_f_cur))
                _sos_xform_skip_reason = _sos_xform_budget_begin(getattr(obj, 'name', ''), _sos_xform_counts)
                if _sos_xform_skip_reason:
                    raise _SOSOverlayBudgetExceeded(_sos_xform_skip_reason)
            _sos_edit_effective_build_budget = _sos_edit_build_budget_for_elements(_sos_total_edit_elements, prefs)
            _sos_edit_effective_signature_budget = _sos_edit_signature_budget_for_elements(_sos_total_edit_elements, prefs)
            try:
                _sos_multi_edit_object_count = max(1, len(edit_mesh_objects))
            except Exception:
                _sos_multi_edit_object_count = 1
            if _sos_multi_edit_object_count > 1 and not _sos_opt_bool(prefs, 'optimization_lightest_lod_skip_dense_vertices_edges', False):
                # The edit rebuild budget is measured from the beginning of the
                # whole multi-object collection pass.  Keep the same per-object
                # guard, but scale the pass budget so later selected objects do
                # not disappear just because earlier objects consumed the shared
                # stopwatch.
                _sos_edit_effective_build_budget = min(
                    max(_sos_edit_effective_build_budget, 0.28) * min(_sos_multi_edit_object_count, 8),
                    1.50,
                )
                _sos_edit_effective_signature_budget = min(
                    max(_sos_edit_effective_signature_budget, 0.05) * min(_sos_multi_edit_object_count, 8),
                    0.75,
                )
            lightest_lod_requested = bool(
                _sos_opt_bool(prefs, 'optimization_lightest_lod_skip_dense_vertices_edges', False)
                and (num_v_cur + num_e_cur + num_f_cur) > _sos_lightest_lod_limit(prefs)
            )
            if _sos_heavy_edit_mesh_fallback_required(_sos_total_edit_elements, cache) and lightest_lod_requested:
                if _sos_append_cached_edit_mesh_batch(
                    batches, obj, cache,
                    prefer_evaluated_faces=bool(_has_visible_edit_mode_modifier(obj) and _use_evaluated_edit_mode_face_overlay(obj, prefs)),
                    shader=shader,
                ):
                    _sos_note_edit_budget_overrun('heavy edit mesh cache reuse', getattr(obj, 'name', ''), 0.0)
                    continue
                _sos_note_edit_budget_overrun('heavy edit mesh skipped without cache', getattr(obj, 'name', ''), 0.0)
                continue
            native_diag_sig = _bmesh_edge_diagnostic_signature(bm, edge_diag_flags) if any(edge_diag_flags.values()) else ()
            lightest_lod_faces_only = bool(lightest_lod_requested)
            show_verts_edit_eff = bool(getattr(prefs, 'show_verts_edit', False)) and (not lightest_lod_faces_only)
            show_edges_edit_eff = bool(getattr(prefs, 'show_edges_edit', False)) and (not lightest_lod_faces_only)
            show_faces_edit_eff = bool(getattr(prefs, 'show_faces_edit', False))
            show_hov_verts_eff = bool(getattr(prefs, 'show_hov_verts', False)) and (not lightest_disable_mesh_hover) and (not lightest_lod_faces_only)
            show_hov_edges_eff = bool(getattr(prefs, 'show_hov_edges', False)) and (not lightest_disable_mesh_hover) and (not lightest_lod_faces_only)
            show_hov_faces_eff = bool(getattr(prefs, 'show_hov_faces', False)) and (not lightest_disable_mesh_hover)
            suppress_actual_vertex_points_obj = bool(suppress_actual_vertex_points_by_select_mode or lightest_lod_faces_only)
            draw_face_center_vertex_points_obj = bool(draw_face_center_vertex_points and (not lightest_lod_faces_only))
            need_cover_edges_from_selected_vertices_obj = bool(need_cover_edges_from_selected_vertices and (not lightest_lod_faces_only))
            need_cover_faces_from_selected_vertices_obj = bool(need_cover_faces_from_selected_vertices)
            need_cover_vertices_from_selected_edges_obj = bool(need_cover_vertices_from_selected_edges and (not lightest_lod_faces_only))
            need_cover_faces_from_selected_edges_obj = bool(need_cover_faces_from_selected_edges)
            need_cover_vertices_from_selected_faces_obj = bool(need_cover_vertices_from_selected_faces and (not lightest_lod_faces_only))
            need_cover_edges_from_selected_faces_obj = bool(need_cover_edges_from_selected_faces and (not lightest_lod_faces_only))
            try:
                selected_counts_sig = _sos_bmesh_selected_counts_signature(
                    bm, num_v_cur, num_e_cur, num_f_cur,
                    budget_start=_sos_edit_build_start,
                    budget_seconds=_sos_edit_effective_signature_budget,
                )
            except _SOSOverlayBudgetExceeded:
                # Dense LOD is OFF: do not let the signature phase suppress the
                # actual overlay. Use a conservative generation key and continue
                # into batch construction. When LOD is ON, preserve the freeze-safe
                # overrun path so intentionally light presets stay responsive.
                if not bool(_sos_opt_bool(prefs, 'optimization_lightest_lod_skip_dense_vertices_edges', False)):
                    selected_counts_sig = (0, 0, 0, 'BUDGET_FALLBACK', _sos_dirty_generation_for_object(obj), num_v_cur, num_e_cur, num_f_cur)
                else:
                    raise
            except Exception:
                selected_counts_sig = (0, 0, 0, 'ERROR')
            # Always include live edit-mesh coordinates in the cache signature.
            # Dirty-generation-only keys are cheaper, but Blender does not reliably
            # bump them for every in-progress edit transform, gizmo move, or
            # modifier-visible cage update.  Using the live BMesh signature here is
            # the correctness path that keeps vertices, edges, faces, and modifier
            # fallback drawing locked to the mesh on every redraw.
            precise_edit_transform_follow = True
            try:
                live_geometry_sig = _bmesh_live_geometry_signature(
                    bm,
                    budget_start=_sos_edit_build_start,
                    budget_seconds=_sos_edit_effective_signature_budget,
                )
            except _SOSOverlayBudgetExceeded:
                if not bool(_sos_opt_bool(prefs, 'optimization_lightest_lod_skip_dense_vertices_edges', False)):
                    live_geometry_sig = ('LIVE_SIG_BUDGET_FALLBACK', _sos_dirty_generation_for_object(obj), num_v_cur, num_e_cur, num_f_cur, selected_counts_sig)
                else:
                    raise
            live_geometry_motion_active = bool(edit_transform_modal_active or _sos_note_edit_geometry_motion(obj, live_geometry_sig))
            if live_geometry_motion_active:
                # Keep the modifier-result face layer active throughout an edit.
                # Older builds deliberately changed ``has_edit_mods`` to False here,
                # which made the normal face fill jump to the pre-modifier cage for
                # one or more frames and then back to the evaluated mesh.  That is the
                # visible flicker reported with Subdivision, Mirror, Solidify, etc.
                #
                # The draw callback now keeps the last valid evaluated face batch and
                # queues a refreshed evaluated result outside drawing.  Edges,
                # vertices, selection and hover still follow the live BMesh directly.
                native_eval_edge_overlay = False
                try:
                    _touch_edit_live_sync(_SOS_EDIT_TRANSFORM_LIVE_ACTIVE_INTERVAL * 3.0)
                except Exception:
                    pass
            lod_mode = getattr(prefs, 'hover_lod_mode', 'FULL') or 'FULL'
            lod_th = int(getattr(prefs, 'hover_lod_threshold_verts', 200000) or 200000)
            if lod_mode == 'AUTO' and num_v_cur > lod_th:
                lod_mode = 'FACE_ONLY'
            active_sel_sig = _bmesh_active_selection_signature(bm)
            modal_transform_sig = _sos_modal_transform_signature(context) if edit_transform_modal_active else ()
            state = (selected_counts_sig, active_sel_sig, live_geometry_sig, modal_transform_sig, num_v_cur, num_e_cur, num_f_cur, tuple(sorted(mode_kinds)), hide_adjacent_edge_gradient, hide_vertex_mode_linked_overlay, hide_edge_mode_linked_overlay, hide_face_mode_linked_overlay, bool(has_edit_mods), bool(native_eval_edge_overlay), native_diag_sig, _modifier_viewport_signature(obj), (_modifier_evaluated_runtime_signature(obj) if (has_edit_mods or native_eval_edge_overlay) else ()), bool(select_mode_vertex_center_overlay), bool(suppress_actual_vertex_points_obj), bool(draw_face_center_vertex_points_obj), bool(lightest_lod_faces_only), bool(lightest_disable_mesh_hover), bool(use_indexed_edit_batches), tuple(sorted((str(k), bool(v)) for k, v in native_edge_overlay_flags.items())), topo_on, topo_sel, topo_edges_on, topo_faces_on, topo_show_seams, topo_show_sharp, topo_show_crease, topo_show_bevel, topo_show_nm, topo_crease_th, topo_bevel_th, topo_show_ngons, topo_show_small, topo_small_area, topo_show_backfaces)
            if live_sync and not (lightest_freeze_nav and cache):
                cache = None
            elif cache and cache.get("state") != state and not lightest_freeze_nav:
                cache = None

            if not cache:
                bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
                # Deleting / dissolving elements can leave BMesh .index values
                # stale even after lookup tables are refreshed. Update indices
                # before using v.index / e.index / f.index as array keys so the
                # overlay batches stay aligned with the live edit mesh.
                bm.verts.index_update(); bm.edges.index_update(); bm.faces.index_update()
                # --- Topology Checks (per-object lists) ---
                topo_seam = []; topo_sharp = []; topo_crease = []; topo_bevel = []; topo_nm = []
                topo_ngon_tris = []; topo_small_tris = []; topo_all_tris = []
                topo_cache_entry = None
                topo_cache_state = (
                    live_geometry_sig,
                    native_diag_sig,
                    tuple(sorted((str(k), bool(v)) for k, v in native_edge_overlay_flags.items())),
                    topo_on, topo_sel, topo_edges_on, topo_faces_on,
                    topo_show_seams, topo_show_sharp, topo_show_crease, topo_show_bevel, topo_show_nm,
                    topo_crease_th, topo_bevel_th,
                    topo_show_ngons, topo_show_small, topo_small_area, topo_show_backfaces,
                )
                topo_cache_key = ('TOPO', str(getattr(obj, 'name', '') or ''), int(getattr(obj, 'as_pointer', lambda: 0)() or 0))
                if _sos_opt_bool(prefs, 'optimization_split_topology_cache', False):
                    try:
                        cached_topo = _sos_topology_batch_cache.get(topo_cache_key)
                        if isinstance(cached_topo, dict) and cached_topo.get('state') == topo_cache_state:
                            topo_cache_entry = cached_topo
                    except Exception:
                        topo_cache_entry = None
                # Unselected edges that receive one of the explicit Mesh Edit
                # Mode diagnostic overlays (Seam / Sharp / Crease / Bevel) keep
                # that diagnostic color. Selected edges are deliberately excluded
                # from this priority set and stay in the selected-edge batch, so a
                # native diagnostic color can never hide the user's selection.
                topo_priority_edge_indices = set()
                if topo_cache_entry is not None:
                    try:
                        topo_priority_edge_indices.update(int(i) for i in topo_cache_entry.get('priority_edges', ()) or ())
                    except Exception:
                        pass

                num_v, num_e = num_v_cur, len(bm.edges)
                _sos_check_edit_budget(_sos_edit_build_start, _sos_edit_effective_build_budget, 'before edit coordinate batch allocation')
                v_coords = np.array([v.co for v in bm.verts], dtype=np.float32) if num_v > 0 else np.empty((0,3), dtype=np.float32)
                if edit_transform_modal_active:
                    v_coords = _sos_apply_modal_edit_transform_preview(obj, bm, v_coords, context)
                # tolist() yields the same Python floats as float(_c[k]) per row,
                # converted once for all vertices instead of once per call.
                _sos_vco_rows = None
                try:
                    if isinstance(v_coords, np.ndarray) and v_coords.ndim == 2 and v_coords.shape[1] == 3:
                        _sos_vco_rows = v_coords.tolist()
                except Exception:
                    _sos_vco_rows = None
                def _sos_vco(_v):
                    try:
                        _idx = int(_v.index)
                        if 0 <= _idx < len(v_coords):
                            if _sos_vco_rows is not None:
                                return Vector(_sos_vco_rows[_idx])
                            _c = v_coords[_idx]
                            return Vector((float(_c[0]), float(_c[1]), float(_c[2])))
                    except Exception:
                        pass
                    return _v.co
                v_mask, e_mask = np.zeros(num_v, dtype=bool), np.zeros(num_e, dtype=bool)
                # Keep hover eligibility independent from normal-edge color
                # ownership.  Diagnostic edges are absent from ``e_mask`` by
                # design, but remain valid unselected hover targets.
                e_hover_mask = np.zeros(num_e, dtype=bool)
                e_v1, e_v2 = np.zeros(num_e, dtype=np.int32), np.zeros(num_e, dtype=np.int32)
                tris, edges, verts, sel_edges, sel_verts, sel_face_tris, half_edges, half_vis, half_occ, face_tris = [], [], [], [], [], [], [], [], [], {}
                face_center_verts, sel_face_center_verts = [], []
                face_center_records, sel_face_center_records = [], []
                face_center_depth_tris, face_center_depth_tris_idx = [], []
                surface_depth_tris, surface_depth_tris_idx = [], []
                native_cage_seam, native_cage_sharp, native_cage_crease, native_cage_bevel = [], [], [], []
                tris_idx, edges_idx, sel_edges_idx = [], [], []
                cover_face_tris = []
                cover_edge_indices, cover_vert_indices = set(), set()
                topo_crease_layer = topo_bevel_layer = None
                if topo_show_crease or topo_show_bevel or native_show_crease or native_show_bevel:
                    try:
                        edge_float_layers = bm.edges.layers.float
                    except Exception:
                        edge_float_layers = None
                    if edge_float_layers is not None:
                        if topo_show_crease or native_show_crease:
                            for _layer_name in ('crease_edge', 'edge_crease', 'crease'):
                                try:
                                    topo_crease_layer = edge_float_layers.get(_layer_name)
                                except Exception:
                                    topo_crease_layer = None
                                if topo_crease_layer is not None:
                                    break
                        if topo_show_bevel or native_show_bevel:
                            for _layer_name in ('bevel_weight_edge', 'edge_bevel_weight', 'bevel_weight'):
                                try:
                                    topo_bevel_layer = edge_float_layers.get(_layer_name)
                                except Exception:
                                    topo_bevel_layer = None
                                if topo_bevel_layer is not None:
                                    break

                def _topo_edge_value(edge, layer, attr_name):
                    if layer is not None:
                        try:
                            return float(edge[layer])
                        except Exception:
                            pass
                    try:
                        return float(getattr(edge, attr_name, 0.0) or 0.0)
                    except Exception:
                        return 0.0
                suppress_linked_selected_vertices = (
                    bool(suppress_actual_vertex_points_by_select_mode) or
                    ('EDGE' in mode_kinds and hide_edge_mode_linked_overlay) or
                    ('FACE' in mode_kinds and hide_face_mode_linked_overlay)
                )
                suppress_linked_selected_edges = (
                    ('VERT' in mode_kinds and hide_vertex_mode_linked_overlay) or
                    ('FACE' in mode_kinds and hide_face_mode_linked_overlay)
                )
                allow_vertex_half_edge_gradient = bool(
                    (not hide_adjacent_edge_gradient)
                    and _sos_vertex_selection_edge_gradient_allowed(mode_kinds)
                )

                for _sos_i_v, v in enumerate(bm.verts):
                    if (_sos_i_v & (_SOS_EDIT_BATCH_BUDGET_CHECK_STRIDE - 1)) == 0:
                        _sos_check_edit_budget(_sos_edit_build_start, _sos_edit_effective_build_budget, 'edit vertex batch rebuild')
                    if v.hide:
                        continue
                    if v.select and (not suppress_linked_selected_vertices) and show_verts_edit_eff:
                        sel_verts.append(_sos_vco(v))
                    elif not suppress_actual_vertex_points_obj and (show_verts_edit_eff or show_hov_verts_eff):
                        v_mask[v.index] = True
                        if show_verts_edit_eff:
                            verts.append(_sos_vco(v))

                for _sos_i_e, e in enumerate(bm.edges):
                    if (_sos_i_e & (_SOS_EDIT_BATCH_BUDGET_CHECK_STRIDE - 1)) == 0:
                        _sos_check_edit_budget(_sos_edit_build_start, _sos_edit_effective_build_budget, 'edit edge batch rebuild')
                    if e.hide: continue
                    # --- Priority edge diagnostics (Blender native + Smart Overlay topology) ---
                    # Blender's native Bevel / Crease / Seam / Sharp colors own
                    # only unselected edges. Smart Overlay topology diagnostics
                    # retain their existing priority policy independently.
                    edge_has_priority_topo = False
                    edge_is_selected = bool(getattr(e, 'select', False))
                    try:
                        v0t, v1t = e.verts
                        if (not edge_is_selected) and native_show_seams and getattr(e, 'seam', False):
                            native_cage_seam.extend((_sos_vco(v0t), _sos_vco(v1t)))
                            edge_has_priority_topo = True
                        if (not edge_is_selected) and native_show_sharp and (not getattr(e, 'smooth', True)):
                            native_cage_sharp.extend((_sos_vco(v0t), _sos_vco(v1t)))
                            edge_has_priority_topo = True
                        if (not edge_is_selected) and native_show_crease and _topo_edge_value(e, topo_crease_layer, 'crease') > 0.0:
                            native_cage_crease.extend((_sos_vco(v0t), _sos_vco(v1t)))
                            edge_has_priority_topo = True
                        if (not edge_is_selected) and native_show_bevel and _topo_edge_value(e, topo_bevel_layer, 'bevel_weight') > 0.0:
                            native_cage_bevel.extend((_sos_vco(v0t), _sos_vco(v1t)))
                            edge_has_priority_topo = True

                        if topo_edges_on and topo_cache_entry is None:
                            # Actual selection has absolute visual priority over
                            # every topology/native diagnostic category.
                            topo_allowed = not edge_is_selected
                            if topo_sel == 'UNSELECTED' and e.select:
                                topo_allowed = False
                            elif topo_sel == 'SELECTED' and (not e.select):
                                topo_allowed = False
                            if topo_allowed:
                                if topo_show_seams and getattr(e, 'seam', False):
                                    topo_seam.extend((_sos_vco(v0t), _sos_vco(v1t)))
                                    edge_has_priority_topo = True
                                if topo_show_sharp and (not getattr(e, 'smooth', True)):
                                    topo_sharp.extend((_sos_vco(v0t), _sos_vco(v1t)))
                                    edge_has_priority_topo = True
                                if topo_show_crease and _topo_edge_value(e, topo_crease_layer, 'crease') >= topo_crease_th:
                                    topo_crease.extend((_sos_vco(v0t), _sos_vco(v1t)))
                                    edge_has_priority_topo = True
                                if topo_show_bevel and _topo_edge_value(e, topo_bevel_layer, 'bevel_weight') >= topo_bevel_th:
                                    topo_bevel.extend((_sos_vco(v0t), _sos_vco(v1t)))
                                    edge_has_priority_topo = True
                                if topo_show_nm and (not bool(getattr(e, 'is_manifold', True))):
                                    topo_nm.extend((_sos_vco(v0t), _sos_vco(v1t)))
                                    edge_has_priority_topo = True
                        if edge_has_priority_topo:
                            topo_priority_edge_indices.add(e.index)
                    except Exception:
                        pass
                    v0, v1 = e.verts
                    e_v1[e.index], e_v2[e.index] = v0.index, v1.index
                    edge_has_priority_topo = e.index in topo_priority_edge_indices
                    if edge_is_selected:
                        if (not suppress_linked_selected_edges) and show_edges_edit_eff:
                            if use_indexed_edit_batches:
                                sel_edges_idx.append((int(v0.index), int(v1.index)))
                            else:
                                sel_edges.extend((_sos_vco(v0), _sos_vco(v1)))
                        if need_cover_vertices_from_selected_edges_obj:
                            cover_vert_indices.add(v0.index)
                            cover_vert_indices.add(v1.index)
                    else:
                        if show_hov_edges_eff:
                            e_hover_mask[e.index] = True
                        if not edge_has_priority_topo and (show_edges_edit_eff or show_hov_edges_eff):
                            e_mask[e.index] = True
                            s0, s1 = v0.select, v1.select
                            if allow_vertex_half_edge_gradient and s0 != s1:
                                half_edges.extend((_sos_vco(v0), _sos_vco(v1)))
                                half_vis.extend((se_col if s0 else e_vis, se_col if s1 else e_vis))
                                half_occ.extend((se_col if s0 else e_occ, se_col if s1 else e_occ))
                            elif show_edges_edit_eff:
                                if use_indexed_edit_batches:
                                    edges_idx.append((int(v0.index), int(v1.index)))
                                else:
                                    edges.extend((_sos_vco(v0), _sos_vco(v1)))
                    if (not edge_has_priority_topo) and need_cover_edges_from_selected_vertices_obj and v0.select and v1.select:
                        cover_edge_indices.add(e.index)

                need_selected_faces = bool('FACE' in mode_kinds)
                eval_face_data = None
                face_fill_requested = bool(show_faces_edit_eff)
                if _sos_opt_bool(prefs, 'optimization_skip_inactive_batches', False):
                    face_fill_requested = bool(face_fill_requested and (getattr(prefs, 'show_vis_faces', False) or getattr(prefs, 'show_occ_faces', False)))
                if has_edit_mods and face_fill_requested:
                    # Evaluated edit-mode face overlay is limited to the normal
                    # face fill used by the visible / occluded colors.  Selected
                    # and hover face overlays intentionally remain on the editable
                    # cage so selection feedback continues to match the mesh the
                    # user is editing.  Lightweight / Lightest presets route this
                    # expensive modifier-evaluated face extraction through a
                    # separate CPU cache that is rebuilt from a timer/depsgraph
                    # path instead of blocking the draw callback.
                    try:
                        eval_face_live_sig = _bmesh_evaluated_edit_face_source_signature(
                            bm,
                            budget_start=_sos_edit_build_start,
                            budget_seconds=_sos_edit_effective_signature_budget,
                        )
                    except _SOSOverlayBudgetExceeded:
                        # Same rule as the selection / live-geometry signatures
                        # above: only the Dense LOD preset keeps the freeze-safe
                        # overrun path.  With LOD OFF the fallback key is used so
                        # a dense mesh with an edit-mode modifier still builds.
                        if _sos_opt_bool(prefs, 'optimization_lightest_lod_skip_dense_vertices_edges', False):
                            raise
                        eval_face_live_sig = (
                            num_v_cur, num_e_cur, num_f_cur,
                            'EVAL_FACE_SIGNATURE_BUDGET_FALLBACK',
                        )
                    except Exception:
                        eval_face_live_sig = (
                            num_v_cur, num_e_cur, num_f_cur,
                            'EVAL_FACE_SIGNATURE_ERROR',
                        )
                    eval_face_state = (
                        'EVAL_FACE_VISIBLE_OCCLUDED_ONLY',
                        eval_face_live_sig,
                        _modifier_viewport_signature(obj),
                        _modifier_evaluated_runtime_signature(obj),
                    )
                    _eval_face_cache_missing = not _sos_eval_face_entry_is_drawable(obj)
                    immediate_eval_safe = bool(
                        (
                            bool(edit_transform_modal_active)
                            or bool(_eval_face_cache_missing)
                            or (
                                (not _sos_opt_bool(prefs, 'optimization_split_evaluated_face_cache', False))
                                and (not _sos_opt_bool(prefs, 'optimization_async_evaluated_face_rebuild', False))
                            )
                        )
                        and (not lightest_freeze_nav)
                        and _sos_total_edit_elements <= _SOS_EVALUATED_EDIT_IMMEDIATE_ELEMENT_LIMIT
                        and not _sos_edit_overlay_circuit_breaker_active()
                    )
                    force_live_evaluated_faces = False
                    if force_live_evaluated_faces:
                        pass
                    elif immediate_eval_safe:
                        # Highest Quality uses a direct small-mesh fallback for the
                        # first frame, but still asks the deferred cache to perform
                        # the safe update_from_editmode()/depsgraph sync outside the
                        # draw callback.  When that fresh cache is available it wins
                        # on subsequent redraws, so evaluated modifier faces update
                        # reliably after edits instead of staying on stale depsgraph
                        # data.
                        eval_face_data = _get_optimized_evaluated_edit_face_data(
                            obj, depsgraph, shader, prefs,
                            source_bm=bm, source_live_signature=eval_face_live_sig,
                            state=eval_face_state, navigation_active=False,
                            strict_modifier_result=True,
                            live_motion_active=live_geometry_motion_active,
                        )
                        # Seed the first evaluated batch synchronously from Blender's
                        # already-available evaluated mesh.  Once a drawable evaluated
                        # batch exists, never rebuild it inside the draw callback; the
                        # app timer refreshes it and the last result remains visible.
                        if not (isinstance(eval_face_data, dict) and eval_face_data.get('batch_tris') is not None):
                            _immediate_eval = _build_evaluated_edit_face_data(
                                obj, depsgraph, shader, separate_selected=False,
                                source_bm=bm, source_live_signature=eval_face_live_sig,
                                force_sync=True,
                            )
                            if _immediate_eval is not None:
                                eval_face_data = _immediate_eval
                                _sos_pin_direct_evaluated_face_batch(obj, _immediate_eval)
                    elif (
                        _sos_opt_bool(prefs, 'optimization_async_evaluated_face_rebuild', False)
                        or _sos_opt_bool(prefs, 'optimization_split_evaluated_face_cache', False)
                    ):
                        eval_face_data = _get_optimized_evaluated_edit_face_data(
                            obj,
                            depsgraph,
                            shader,
                            prefs,
                            source_bm=bm,
                            source_live_signature=eval_face_live_sig,
                            state=eval_face_state,
                            navigation_active=lightest_freeze_nav,
                            strict_modifier_result=True,
                            live_motion_active=live_geometry_motion_active,
                        )
                    else:
                        # Even when the optimization preset does not explicitly ask
                        # for async evaluated-face rebuilds, never force evaluated
                        # modifier mesh extraction from a live draw callback.  Use the
                        # same cache/queue path and retain the last modifier-result
                        # face buffer while the evaluated result is prepared later.
                        eval_face_data = _get_optimized_evaluated_edit_face_data(
                            obj, depsgraph, shader, prefs,
                            source_bm=bm, source_live_signature=eval_face_live_sig,
                            state=eval_face_state, navigation_active=lightest_freeze_nav,
                            strict_modifier_result=True,
                            live_motion_active=live_geometry_motion_active,
                        )
                eval_face_pending_suppresses_cage = bool(
                    has_edit_mods
                    or (isinstance(eval_face_data, dict) and eval_face_data.get('suppress_edit_cage_fallback'))
                )
                # Evaluated-face mode owns the normal visible/occluded face fill.
                # Never build the base-cage fill merely because the newest modifier
                # result is pending; that is the source of the visible mode switch.
                need_f = bool(show_faces_edit_eff and (not has_edit_mods))
                need_hf = show_faces_edit_eff and show_hov_faces_eff
                need_topo_faces = (topo_cache_entry is None) and topo_faces_on and (topo_show_ngons or topo_show_small or topo_show_backfaces)
                need_cover_faces = bool(show_faces_edit_eff and (need_cover_faces_from_selected_vertices_obj or need_cover_faces_from_selected_edges_obj))

                # With the face fill off nothing seeds the overlay depth layer, and
                # hidden edges and vertices would pass the visible depth test.
                need_surface_depth = bool((not show_faces_edit_eff) and (not draw_face_center_vertex_points_obj))

                if need_f or need_hf or need_topo_faces or need_cover_faces or need_selected_faces or draw_face_center_vertex_points_obj or need_surface_depth:
                    for _sos_i_f, f in enumerate(bm.faces):
                        if (_sos_i_f & (_SOS_EDIT_BATCH_BUDGET_CHECK_STRIDE - 1)) == 0:
                            _sos_check_edit_budget(_sos_edit_build_start, _sos_edit_effective_build_budget, 'edit face batch rebuild')
                        if f.hide:
                            continue

                        if need_surface_depth:
                            if use_indexed_edit_batches:
                                surface_depth_tris_idx.extend(_face_tri_indices_global(f))
                            else:
                                co_sd = [_sos_vco(v) for v in f.verts]
                                for a, b, c in _face_tris_local(f):
                                    surface_depth_tris.extend((co_sd[a], co_sd[b], co_sd[c]))

                        # Selection filter for topology checks
                        if topo_sel == 'UNSELECTED' and f.select:
                            topo_ok = False
                        elif topo_sel == 'SELECTED' and (not f.select):
                            topo_ok = False
                        else:
                            topo_ok = True

                        face_is_selected = bool(getattr(f, 'select', False))
                        try:
                            face_from_selected_vertices = all(bool(getattr(fv, 'select', False)) for fv in f.verts)
                        except Exception:
                            face_from_selected_vertices = face_is_selected
                        try:
                            face_from_selected_edges = all(bool(getattr(fe, 'select', False)) for fe in f.edges)
                        except Exception:
                            face_from_selected_edges = face_is_selected

                        if draw_face_center_vertex_points_obj:
                            # Keep one complete cage-surface batch for face-center
                            # visibility. Normal and selected face fills are split
                            # into separate color batches, but drawing those
                            # sequentially with an ALWAYS depth bootstrap makes
                            # the later batch overwrite the earlier one on complex
                            # or overlapping meshes. A single all-face batch lets
                            # the GPU resolve the cage surface consistently.
                            if use_indexed_edit_batches:
                                face_center_depth_tris_idx.extend(_face_tri_indices_global(f))
                            else:
                                co_depth = [_sos_vco(v) for v in f.verts]
                                n_depth = len(f.verts)
                                ft_depth = [(co_depth[0], co_depth[1], co_depth[2])] if n_depth == 3 else ([(co_depth[0], co_depth[1], co_depth[2]), (co_depth[0], co_depth[2], co_depth[3])] if n_depth == 4 else [(co_depth[a], co_depth[b], co_depth[c]) for a, b, c in _face_tris_local(f)])
                                for t_depth in ft_depth:
                                    face_center_depth_tris.extend(t_depth)
                            try:
                                center_co = f.calc_center_median()
                            except Exception:
                                center_co = None
                            if center_co is not None:
                                # Face-select center dots are separate from real vertex
                                # batches so they can receive a final face-front cover
                                # pass. This keeps the center dot readable even when a
                                # translucent face overlay or selected-face fill is drawn
                                # at nearly the same depth.
                                if face_is_selected:
                                    if getattr(prefs, 'show_sel_verts', True):
                                        sel_face_center_verts.append(center_co)
                                        sel_face_center_records.append((int(f.index), Vector(center_co)))
                                else:
                                    face_center_verts.append(center_co)
                                    face_center_records.append((int(f.index), Vector(center_co)))

                        if face_is_selected:
                            if need_selected_faces:
                                co_sel = [_sos_vco(v) for v in f.verts]
                                n_sel = len(f.verts)
                                ft_sel = [(co_sel[0], co_sel[1], co_sel[2])] if n_sel == 3 else ([(co_sel[0], co_sel[1], co_sel[2]), (co_sel[0], co_sel[2], co_sel[3])] if n_sel == 4 else [(co_sel[a], co_sel[b], co_sel[c]) for a, b, c in _face_tris_local(f)])
                                for t in ft_sel:
                                    sel_face_tris.extend(t)
                            if need_cover_vertices_from_selected_faces_obj:
                                for fv in f.verts:
                                    cover_vert_indices.add(fv.index)
                            if need_cover_edges_from_selected_faces_obj:
                                for fe in f.edges:
                                    cover_edge_indices.add(fe.index)

                        if need_cover_faces and (
                            face_is_selected or
                            (need_cover_faces_from_selected_vertices_obj and face_from_selected_vertices) or
                            (need_cover_faces_from_selected_edges_obj and face_from_selected_edges)
                        ):
                            co_cover = [_sos_vco(v) for v in f.verts]
                            n_cover = len(f.verts)
                            ft_cover = [(co_cover[0], co_cover[1], co_cover[2])] if n_cover == 3 else ([(co_cover[0], co_cover[1], co_cover[2]), (co_cover[0], co_cover[2], co_cover[3])] if n_cover == 4 else [(co_cover[a], co_cover[b], co_cover[c]) for a, b, c in _face_tris_local(f)])
                            for t in ft_cover:
                                cover_face_tris.extend(t)

                        # Base overlay triangles (only for non-selected faces)
                        if (need_f or need_hf) and (not f.select):
                            co = [_sos_vco(v) for v in f.verts]
                            n = len(f.verts)
                            ft = [(co[0], co[1], co[2])] if n == 3 else ([(co[0], co[1], co[2]), (co[0], co[2], co[3])] if n == 4 else [(co[a], co[b], co[c]) for a, b, c in _face_tris_local(f)])
                            if need_hf:
                                face_tris[f.index] = ft
                            if need_f:
                                if use_indexed_edit_batches:
                                    tris_idx.extend(_face_tri_indices_global(f))
                                else:
                                    for t in ft:
                                        tris.extend(t)

                        # Topology faces (NEW)
                        if need_topo_faces and topo_ok:
                            co2 = [_sos_vco(v) for v in f.verts]
                            n2 = len(f.verts)
                            ft2 = [(co2[0], co2[1], co2[2])] if n2 == 3 else ([(co2[0], co2[1], co2[2]), (co2[0], co2[2], co2[3])] if n2 == 4 else [(co2[a], co2[b], co2[c]) for a, b, c in _face_tris_local(f)])

                            if topo_show_backfaces:
                                for t in ft2:
                                    topo_all_tris.extend(t)

                            if topo_show_ngons and n2 >= 5:
                                for t in ft2:
                                    topo_ngon_tris.extend(t)

                            if topo_show_small:
                                try:
                                    area = float(f.calc_area())
                                except Exception:
                                    area = 0.0
                                if area > 0.0 and area <= topo_small_area:
                                    for t in ft2:
                                        topo_small_tris.extend(t)

                if topo_priority_edge_indices and cover_edge_indices:
                    cover_edge_indices.difference_update(topo_priority_edge_indices)
                # A selected element is owned by its selected-color batch. Linked
                # cover helpers must never repaint it with an unselected color.
                if cover_edge_indices:
                    cover_edge_indices.difference_update(
                        int(edge.index) for edge in bm.edges
                        if (not edge.hide) and bool(edge.select))
                if cover_vert_indices:
                    cover_vert_indices.difference_update(
                        int(vert.index) for vert in bm.verts
                        if (not vert.hide) and bool(vert.select))
                cover_edges = []
                if cover_edge_indices:
                    for edge_index in sorted(cover_edge_indices):
                        try:
                            ce = bm.edges[edge_index]
                            if ce.hide:
                                continue
                            cv0, cv1 = ce.verts
                            cover_edges.extend((_sos_vco(cv0), _sos_vco(cv1)))
                        except Exception:
                            continue
                cover_verts = []
                if cover_vert_indices:
                    for vert_index in sorted(cover_vert_indices):
                        try:
                            cv = bm.verts[vert_index]
                            if cv.hide:
                                continue
                            cover_verts.append(_sos_vco(cv))
                        except Exception:
                            continue

                bb = SOS_BatchData(obj.matrix_world)
                bb.face_op_mul = 1.0
                if isinstance(eval_face_data, dict):
                    try:
                        bb.is_mod_eval = True
                    except Exception:
                        pass
                    if eval_face_data.get('batch_tris') is not None:
                        bb.batch_tris = eval_face_data.get('batch_tris')
                elif use_indexed_edit_batches and tris_idx:
                    bb.batch_tris = batch_for_shader(shader, 'TRIS', {"pos": v_coords}, indices=np.asarray(tris_idx, dtype=np.int32))
                elif tris:
                    bb.batch_tris = batch_for_shader(shader, 'TRIS', {"pos": tris})
                if use_indexed_edit_batches and edges_idx:
                    bb.batch_edges = batch_for_shader(shader, 'LINES', {"pos": v_coords}, indices=np.asarray(edges_idx, dtype=np.int32))
                elif edges:
                    bb.batch_edges = batch_for_shader(shader, 'LINES', {"pos": edges})
                if verts: bb.batch_verts = batch_for_shader(shader, 'POINTS', {"pos": verts})
                if face_center_verts: bb.batch_face_center_verts = batch_for_shader(shader, 'POINTS', {"pos": face_center_verts})
                if sel_face_center_verts: bb.batch_sel_face_center_verts = batch_for_shader(shader, 'POINTS', {"pos": sel_face_center_verts})
                if use_indexed_edit_batches and face_center_depth_tris_idx:
                    bb.batch_face_center_depth_tris = batch_for_shader(shader, 'TRIS', {"pos": v_coords}, indices=np.asarray(face_center_depth_tris_idx, dtype=np.int32))
                elif face_center_depth_tris:
                    bb.batch_face_center_depth_tris = batch_for_shader(shader, 'TRIS', {"pos": face_center_depth_tris})
                if use_indexed_edit_batches and surface_depth_tris_idx:
                    bb.batch_surface_depth_tris = batch_for_shader(shader, 'TRIS', {"pos": v_coords}, indices=np.asarray(surface_depth_tris_idx, dtype=np.int32))
                elif surface_depth_tris:
                    bb.batch_surface_depth_tris = batch_for_shader(shader, 'TRIS', {"pos": surface_depth_tris})
                if use_indexed_edit_batches and sel_edges_idx:
                    bb.batch_sel_edges = batch_for_shader(shader, 'LINES', {"pos": v_coords}, indices=np.asarray(sel_edges_idx, dtype=np.int32))
                elif sel_edges:
                    bb.batch_sel_edges = batch_for_shader(shader, 'LINES', {"pos": sel_edges})
                if sel_verts: bb.batch_sel_verts = batch_for_shader(shader, 'POINTS', {"pos": sel_verts})
                # Face selection color always stays on the editable cage.
                # Only the visible/occluded face fill may use evaluated
                # modifier geometry.
                if sel_face_tris:
                    bb.batch_sel_tris = batch_for_shader(shader, 'TRIS', {"pos": sel_face_tris})

                def _coords_from_edge_indices(index_pairs):
                    coords = []
                    for first, second in tuple(index_pairs or ()):
                        try:
                            coords.extend((Vector(v_coords[int(first)]), Vector(v_coords[int(second)])))
                        except Exception:
                            continue
                    return tuple(coords)

                bb.cpu_edges = _coords_from_edge_indices(edges_idx) if use_indexed_edit_batches else tuple(Vector(co) for co in edges)
                bb.cpu_sel_edges = _coords_from_edge_indices(sel_edges_idx) if use_indexed_edit_batches else tuple(Vector(co) for co in sel_edges)
                bb.cpu_verts = tuple(Vector(co) for co in verts)
                bb.cpu_sel_verts = tuple(Vector(co) for co in sel_verts)
                bb.cpu_native_cage_seam = tuple(Vector(co) for co in native_cage_seam)
                bb.cpu_native_cage_sharp = tuple(Vector(co) for co in native_cage_sharp)
                bb.cpu_native_cage_crease = tuple(Vector(co) for co in native_cage_crease)
                bb.cpu_native_cage_bevel = tuple(Vector(co) for co in native_cage_bevel)
                bb.cpu_face_centers = tuple(face_center_records)
                bb.cpu_sel_face_centers = tuple(sel_face_center_records)
                if cover_edges: bb.batch_cover_edges = batch_for_shader(shader, 'LINES', {"pos": cover_edges})
                if cover_verts: bb.batch_cover_verts = batch_for_shader(shader, 'POINTS', {"pos": cover_verts})
                if cover_face_tris: bb.batch_cover_tris = batch_for_shader(shader, 'TRIS', {"pos": cover_face_tris})
                if half_edges and grad_shader:
                    bb.batch_half_sel_vis = batch_for_shader(grad_shader, 'LINES', {"pos": half_edges, "color": half_vis})
                    bb.batch_half_sel_occ = batch_for_shader(grad_shader, 'LINES', {"pos": half_edges, "color": half_occ})

                # Topology batches (NEW)
                if topo_cache_entry is not None:
                    bb.batch_topo_seam = topo_cache_entry.get('batch_topo_seam')
                    bb.batch_topo_sharp = topo_cache_entry.get('batch_topo_sharp')
                    bb.batch_topo_crease = topo_cache_entry.get('batch_topo_crease')
                    bb.batch_topo_bevel = topo_cache_entry.get('batch_topo_bevel')
                    bb.batch_topo_nonmanifold = topo_cache_entry.get('batch_topo_nonmanifold')
                    bb.batch_topo_ngons = topo_cache_entry.get('batch_topo_ngons')
                    bb.batch_topo_small = topo_cache_entry.get('batch_topo_small')
                    bb.batch_topo_all_faces = topo_cache_entry.get('batch_topo_all_faces')
                    bb.cpu_topo_seam = topo_cache_entry.get('cpu_topo_seam', ())
                    bb.cpu_topo_sharp = topo_cache_entry.get('cpu_topo_sharp', ())
                    bb.cpu_topo_crease = topo_cache_entry.get('cpu_topo_crease', ())
                    bb.cpu_topo_bevel = topo_cache_entry.get('cpu_topo_bevel', ())
                    bb.cpu_topo_nonmanifold = topo_cache_entry.get('cpu_topo_nonmanifold', ())
                elif topo_on:
                    bb.cpu_topo_seam = tuple(Vector(co) for co in topo_seam)
                    bb.cpu_topo_sharp = tuple(Vector(co) for co in topo_sharp)
                    bb.cpu_topo_crease = tuple(Vector(co) for co in topo_crease)
                    bb.cpu_topo_bevel = tuple(Vector(co) for co in topo_bevel)
                    bb.cpu_topo_nonmanifold = tuple(Vector(co) for co in topo_nm)
                    if topo_seam:
                        bb.batch_topo_seam = batch_for_shader(shader, 'LINES', {"pos": topo_seam})
                    if topo_sharp:
                        bb.batch_topo_sharp = batch_for_shader(shader, 'LINES', {"pos": topo_sharp})
                    if topo_crease:
                        bb.batch_topo_crease = batch_for_shader(shader, 'LINES', {"pos": topo_crease})
                    if topo_bevel:
                        bb.batch_topo_bevel = batch_for_shader(shader, 'LINES', {"pos": topo_bevel})
                    if topo_nm:
                        bb.batch_topo_nonmanifold = batch_for_shader(shader, 'LINES', {"pos": topo_nm})
                    if topo_ngon_tris:
                        bb.batch_topo_ngons = batch_for_shader(shader, 'TRIS', {"pos": topo_ngon_tris})
                    if topo_small_tris:
                        bb.batch_topo_small = batch_for_shader(shader, 'TRIS', {"pos": topo_small_tris})
                    if topo_all_tris:
                        bb.batch_topo_all_faces = batch_for_shader(shader, 'TRIS', {"pos": topo_all_tris})
                    if _sos_opt_bool(prefs, 'optimization_split_topology_cache', False):
                        try:
                            _sos_topology_batch_cache[topo_cache_key] = {
                                'state': topo_cache_state,
                                'priority_edges': tuple(sorted(int(i) for i in topo_priority_edge_indices)),
                                'batch_topo_seam': bb.batch_topo_seam,
                                'batch_topo_sharp': bb.batch_topo_sharp,
                                'batch_topo_crease': bb.batch_topo_crease,
                                'batch_topo_bevel': bb.batch_topo_bevel,
                                'batch_topo_nonmanifold': bb.batch_topo_nonmanifold,
                                'batch_topo_ngons': bb.batch_topo_ngons,
                                'batch_topo_small': bb.batch_topo_small,
                                'batch_topo_all_faces': bb.batch_topo_all_faces,
                                'cpu_topo_seam': bb.cpu_topo_seam,
                                'cpu_topo_sharp': bb.cpu_topo_sharp,
                                'cpu_topo_crease': bb.cpu_topo_crease,
                                'cpu_topo_bevel': bb.cpu_topo_bevel,
                                'cpu_topo_nonmanifold': bb.cpu_topo_nonmanifold,
                            }
                            if len(_sos_topology_batch_cache) > _SOS_BASE_CACHE_MAX_ENTRIES:
                                for old_key in list(_sos_topology_batch_cache.keys())[:-_SOS_BASE_CACHE_MAX_ENTRIES]:
                                    _sos_topology_batch_cache.pop(old_key, None)
                        except Exception:
                            pass

                # Native Blender Mesh Edit Mode edge diagnostics on the editable cage.
                # Blender draws these before or around custom POST_VIEW handlers, so
                # Smart Overlay keeps same-color cage batches and redraws them only
                # in the final X-Ray front pass.  This preserves the standard
                # Mesh Edit Mode overlay switches while preventing translucent Smart
                # Overlay faces/edges from covering Seam / Sharp / Crease / Bevel.
                if native_cage_seam:
                    bb.batch_native_cage_seam = batch_for_shader(shader, 'LINES', {"pos": native_cage_seam})
                if native_cage_sharp:
                    bb.batch_native_cage_sharp = batch_for_shader(shader, 'LINES', {"pos": native_cage_sharp})
                if native_cage_crease:
                    bb.batch_native_cage_crease = batch_for_shader(shader, 'LINES', {"pos": native_cage_crease})
                if native_cage_bevel:
                    bb.batch_native_cage_bevel = batch_for_shader(shader, 'LINES', {"pos": native_cage_bevel})

                # Native Blender Mesh Edit Mode edge diagnostics are intentionally
                # not generated for the modifier-evaluated result.  They belong
                # to the base editable mesh, matching Blender's standard overlay
                # behavior and avoiding duplicate cage + final-result display.

                cache = {
                    "base": bb,
                    "v_co": v_coords,
                    "v_m": v_mask,
                    "e_m": e_mask,
                    "e_hm": e_hover_mask,
                    "e1": e_v1,
                    "e2": e_v2,
                    "ft": face_tris,
                    "state": state,
                }
                _sos_base_cache[cache_key] = cache
                _sos_prune_base_cache()

            bd = SOS_BatchData(obj.matrix_world)
            bs = cache["base"]
            try:
                bd.is_mod_eval = bool(getattr(bs, 'is_mod_eval', False))
            except Exception:
                bd.is_mod_eval = False
            bd.face_op_mul, bd.batch_tris, bd.batch_edges, bd.batch_verts = bs.face_op_mul, bs.batch_tris, bs.batch_edges, bs.batch_verts
            bd.batch_sel_edges, bd.batch_sel_verts, bd.batch_sel_tris = bs.batch_sel_edges, bs.batch_sel_verts, getattr(bs, 'batch_sel_tris', None)
            bd.batch_face_center_verts = getattr(bs, 'batch_face_center_verts', None)
            bd.batch_sel_face_center_verts = getattr(bs, 'batch_sel_face_center_verts', None)
            bd.batch_face_center_depth_tris = getattr(bs, 'batch_face_center_depth_tris', None)
            bd.batch_surface_depth_tris = getattr(bs, 'batch_surface_depth_tris', None)
            bd.batch_cover_edges, bd.batch_cover_verts, bd.batch_cover_tris = getattr(bs, 'batch_cover_edges', None), getattr(bs, 'batch_cover_verts', None), getattr(bs, 'batch_cover_tris', None)
            bd.batch_half_sel_vis, bd.batch_half_sel_occ = getattr(bs, 'batch_half_sel_vis', None), getattr(bs, 'batch_half_sel_occ', None)
            bd.batch_topo_seam = getattr(bs, 'batch_topo_seam', None)
            bd.batch_topo_sharp = getattr(bs, 'batch_topo_sharp', None)
            bd.batch_topo_crease = getattr(bs, 'batch_topo_crease', None)
            bd.batch_topo_bevel = getattr(bs, 'batch_topo_bevel', None)
            bd.batch_topo_nonmanifold = getattr(bs, 'batch_topo_nonmanifold', None)
            bd.batch_topo_ngons = getattr(bs, 'batch_topo_ngons', None)
            bd.batch_topo_small = getattr(bs, 'batch_topo_small', None)
            bd.batch_topo_all_faces = getattr(bs, 'batch_topo_all_faces', None)
            bd.batch_native_seam = getattr(bs, 'batch_native_seam', None)
            bd.batch_native_sharp = getattr(bs, 'batch_native_sharp', None)
            bd.batch_native_crease = getattr(bs, 'batch_native_crease', None)
            bd.batch_native_bevel = getattr(bs, 'batch_native_bevel', None)
            bd.batch_native_cage_seam = getattr(bs, 'batch_native_cage_seam', None)
            bd.batch_native_cage_sharp = getattr(bs, 'batch_native_cage_sharp', None)
            bd.batch_native_cage_crease = getattr(bs, 'batch_native_cage_crease', None)
            bd.batch_native_cage_bevel = getattr(bs, 'batch_native_cage_bevel', None)
            for _cpu_attr in (
                'cpu_edges', 'cpu_sel_edges', 'cpu_verts', 'cpu_sel_verts',
                'cpu_native_cage_seam', 'cpu_native_cage_sharp',
                'cpu_native_cage_crease', 'cpu_native_cage_bevel',
                'cpu_topo_seam', 'cpu_topo_sharp', 'cpu_topo_crease', 'cpu_topo_bevel', 'cpu_topo_nonmanifold',
                'cpu_face_centers', 'cpu_sel_face_centers',
            ):
                try:
                    setattr(bd, _cpu_attr, getattr(bs, _cpu_attr, ()))
                except Exception:
                    pass
            if has_edit_mods and show_faces_edit_eff:
                _latest_eval_batch = _sos_latest_evaluated_face_batch(obj, shader)
                if _latest_eval_batch is not None:
                    bd.batch_tris = _latest_eval_batch
                    bd.is_mod_eval = True
                elif not bool(getattr(bd, 'is_mod_eval', False)):
                    # Strict modifier-result mode never exposes the pre-modifier
                    # cage face while the first evaluated result is being prepared.
                    bd.batch_tris = None

            hv, he, hf = -1, -1, -1
            hover_opt_cache = bool(_sos_opt_bool(prefs, 'optimization_hover_event_only', False))
            hover_cached = False
            hover_key = None
            if hover_opt_cache:
                try:
                    hover_key = (
                        'EDIT_CLICK_PICK_V1',
                        int(mx), int(my),
                        int(getattr(region, 'width', 0) or 0), int(getattr(region, 'height', 0) or 0),
                        _sos_lightest_matrix_signature(rv3d),
                        _sos_hover_scene_revision,
                        tuple(bool(v) for v in sel_mode),
                        bool(show_hov_verts_eff), bool(show_hov_edges_eff), bool(show_hov_faces_eff),
                        live_geometry_sig,
                    )
                    if cache.get('hover_key') == hover_key:
                        hv, he, hf = cache.get('hover_result', (-1, -1, -1))
                        hover_cached = True
                except Exception:
                    hover_cached = False
            if (not hover_cached) and mx != -1 and my != -1 and region and rv3d:
                mvp_np = np.array(rv3d.window_matrix @ rv3d.view_matrix @ obj.matrix_world, dtype=np.float32)
                hv, he, hf = _sos_edit_click_hover_indices(
                    bm,
                    obj,
                    cache,
                    region,
                    rv3d,
                    mvp_np,
                    mx,
                    my,
                    sel_mode,
                    lod_mode,
                    show_hov_verts_eff,
                    show_hov_edges_eff,
                    show_hov_faces_eff,
                    v_rad_sq,
                    e_rad_sq,
                )
            if hover_opt_cache and not hover_cached:
                try:
                    cache['hover_key'] = hover_key
                    cache['hover_result'] = (int(hv), int(he), int(hf))
                except Exception:
                    pass
            batches.append(bd)

            try:
                if hv != -1:
                    hover_vert_co = Vector(cache["v_co"][hv])
                    bd.batch_hover_verts = batch_for_shader(shader, 'POINTS', {"pos": [hover_vert_co]})
                    bd.cpu_hover_verts = (hover_vert_co,)
                if he != -1:
                    hover_edge_coords = (
                        Vector(cache["v_co"][cache["e1"][he]]),
                        Vector(cache["v_co"][cache["e2"][he]]),
                    )
                    bd.batch_hover_edges = batch_for_shader(shader, 'LINES', {"pos": hover_edge_coords})
                    bd.cpu_hover_edges = hover_edge_coords
                # Hover face color is generated from the editable cage only.
                ft = cache["ft"].get(hf) if hf != -1 else None
                if ft:
                    bd.batch_hover_tris = batch_for_shader(shader, 'TRIS', {"pos": [t for tri in ft for t in tri]})
            except Exception:
                pass
            try:
                # Hover is view-dependent and is resolved after the immutable
                # base cache is copied.  Build POST_PIXEL visibility batches only
                # after attaching that frame's hover coordinates, otherwise the
                # final ownership pass cannot outdraw Blender's native diagnostic
                # overlay in solid mode.
                _sos_build_post_pixel_visibility_batches(context, obj, bm, bd, bd)
            except Exception:
                pass

        except _SOSOverlayBudgetExceeded as _sos_budget_exc:
            _sos_edit_collect_degraded = True
            if _sos_xform_counts is not None:
                # A real face-loop overrun (not the skip above) in the second
                # half of the faces may finish next time; unknown counts as late.
                _sos_xform_face_late = False
                if (not _sos_xform_skip_reason) and str(_sos_budget_exc) == 'edit face batch rebuild':
                    try:
                        _sos_xform_face_late = int(_sos_i_f) * 2 >= int(_sos_xform_counts[2])
                    except Exception:
                        _sos_xform_face_late = True
                _sos_xform_budget_note_failure(getattr(obj, 'name', ''), _sos_xform_counts, str(_sos_budget_exc), _sos_xform_face_late)
            try:
                cache = _sos_base_cache.get(("EDIT", getattr(obj, 'name', '')))
                _sos_append_cached_edit_mesh_batch(
                    batches, obj, cache,
                    prefer_evaluated_faces=bool(_has_visible_edit_mode_modifier(obj) and _use_evaluated_edit_mode_face_overlay(obj, prefs)),
                    shader=shader,
                )
            except Exception:
                pass
            try:
                _sos_note_edit_budget_overrun(str(_sos_budget_exc), getattr(obj, 'name', ''), _sos_perf_counter() - _sos_edit_build_start)
            except Exception:
                pass
            # Continue through the remaining edit objects so their last known
            # good batches can be reused.  Breaking here made multi-object edit
            # overlays blink off for later selected objects when one object hit
            # the shared draw-budget guard.
            continue
        except Exception:
            _sos_edit_collect_degraded = True
            # Transient edit-mesh access failures can occur while Blender swaps
            # Subdivision/evaluated wrappers during an in-progress edit.  The old
            # behavior silently returned no batch for that object, causing a blank
            # flash.  Preserve the pinned modifier-result face layer (and any safe
            # cached edge/vertex data) for this frame instead.
            try:
                cache = _sos_base_cache.get(("EDIT", getattr(obj, 'name', '')))
                _sos_append_cached_edit_mesh_batch(
                    batches, obj, cache,
                    prefer_evaluated_faces=bool(_has_visible_edit_mode_modifier(obj) and _use_evaluated_edit_mode_face_overlay(obj, prefs)),
                    shader=shader,
                )
            except Exception:
                pass
            continue
    return batches


def _collect_edit_curve_batches(context, prefs, do_curve, shader, grad_shader=None):
    """Collect Mesh / Curve Overlay batches for Curve edit mode.

    Vertex overlay is placed on actual curve control points.  Edge overlay is
    placed on the sampled curve shape.  Face overlay and mesh-like hover use the
    evaluated render mesh when bevel/extrude/fill settings produce polygons.
    """
    global _sos_base_cache
    batches = []
    if not do_curve:
        return batches
    if shader is None:
        return batches
    try:
        depsgraph = context.evaluated_depsgraph_get()
    except Exception:
        depsgraph = None
    if depsgraph is None:
        return batches
    try:
        region = getattr(context, 'region', None)
        rv3d = getattr(context, 'region_data', None)
    except Exception:
        region = rv3d = None
    mx, my = _sos_tracked_mouse_region_coords(context, region)
    lightest_disable_hover = _sos_opt_bool(prefs, 'optimization_lightest_disable_mesh_hover', False)
    if lightest_disable_hover:
        mx, my = -1, -1
    lightest_active_only = _sos_opt_bool(prefs, 'optimization_lightest_active_object_only', False)
    active_obj = getattr(context, 'active_object', None) or getattr(context, 'object', None)
    try:
        curve_objects = [o for o in (getattr(context, 'objects_in_mode', ()) or ()) if _is_curve_object(o)]
    except Exception:
        curve_objects = []
    if not curve_objects:
        obj = getattr(context, 'object', None) or getattr(context, 'active_object', None)
        if _is_curve_object(obj):
            curve_objects = [obj]
    if lightest_active_only and active_obj is not None:
        filtered = [o for o in curve_objects if o == active_obj]
        if filtered:
            curve_objects = filtered

    include_shape = bool(getattr(prefs, 'include_curve_shape_overlay', True))
    base_faces = bool(getattr(prefs, 'show_faces_edit', False))
    base_edges = bool(getattr(prefs, 'show_edges_edit', False)) and include_shape
    base_verts = bool(getattr(prefs, 'show_verts_edit', False)) and include_shape
    hov_faces = bool(getattr(prefs, 'show_hov_faces', False)) and (not lightest_disable_hover)
    hov_edges = bool(getattr(prefs, 'show_hov_edges', False)) and (not lightest_disable_hover)
    hov_verts = bool(getattr(prefs, 'show_hov_verts', False)) and (not lightest_disable_hover)
    lod_limit = _sos_lightest_lod_limit(prefs)

    for obj in curve_objects:
        try:
            if not _sos_obj_supported_objmode(obj, prefs):
                continue
            curve_data = getattr(obj, 'data', None)
            shape_sig = _curve_data_live_signature(curve_data)
            render_sig = _modifier_viewport_signature(obj)
            cache_key = (
                'EDIT_CURVE', str(getattr(obj, 'name', '') or ''),
                bool(base_faces or hov_faces), bool(base_edges or hov_edges), bool(base_verts or hov_verts),
                bool(include_shape),
            )
            cache_state = (
                shape_sig,
                render_sig,
                _sos_dirty_generation_for_object(obj),
                bool(_sos_curve_has_render_mesh_settings(obj)),
                bool(base_faces), bool(base_edges), bool(base_verts), bool(hov_faces), bool(hov_edges), bool(hov_verts),
            )
            cb_entry = _sos_base_cache.get(cache_key)
            if not isinstance(cb_entry, dict) or cb_entry.get('state') != cache_state:
                ctrl_va = np.empty((0, 3), dtype=np.float32)
                ctrl_selected = np.empty((0,), dtype=np.bool_)
                shape_va = np.empty((0, 3), dtype=np.float32)
                shape_ei = np.empty((0, 2), dtype=np.int32)
                arrays = _curve_control_and_shape_arrays(obj) if include_shape else None
                if arrays:
                    ctrl_va, ctrl_selected, shape_va, shape_ei = arrays
                mesh_data = _curve_evaluated_mesh_arrays(obj, depsgraph)
                mesh_va = np.empty((0, 3), dtype=np.float32)
                mesh_ei = np.empty((0, 2), dtype=np.int32)
                mesh_ti = np.empty((0, 3), dtype=np.int32)
                has_render_mesh = False
                if isinstance(mesh_data, dict):
                    mesh_va = mesh_data.get('verts') if mesh_data.get('verts') is not None else mesh_va
                    mesh_ei = mesh_data.get('edges') if mesh_data.get('edges') is not None else mesh_ei
                    mesh_ti = mesh_data.get('tris') if mesh_data.get('tris') is not None else mesh_ti
                    has_render_mesh = bool(mesh_data.get('has_render_mesh') and mesh_ti is not None and len(mesh_ti) > 0)
                try:
                    source_total = int(len(ctrl_va)) + int(len(shape_ei)) + int(len(mesh_ti))
                except Exception:
                    source_total = 0
                lod_faces_only = bool(
                    _sos_opt_bool(prefs, 'optimization_lightest_lod_skip_dense_vertices_edges', False)
                    and source_total > lod_limit
                )
                bb = SOS_BatchData(obj.matrix_world)
                bb.is_mod_eval = bool(has_render_mesh)
                if base_faces and has_render_mesh and mesh_va is not None and mesh_ti is not None and len(mesh_ti) > 0:
                    try:
                        bb.batch_tris = batch_for_shader(shader, 'TRIS', {'pos': mesh_va}, indices=mesh_ti)
                    except Exception:
                        pass
                if include_shape and (not lod_faces_only):
                    # Shape edges stay on the curve centerline/shape, including
                    # bevelled curves; this avoids drawing every bevel cross-edge.
                    if base_edges and shape_va is not None and shape_ei is not None and len(shape_ei) > 0:
                        try:
                            bb.batch_edges = batch_for_shader(shader, 'LINES', {'pos': shape_va}, indices=shape_ei)
                        except Exception:
                            pass
                    if base_verts and ctrl_va is not None and len(ctrl_va) > 0:
                        try:
                            if ctrl_selected is not None and len(ctrl_selected) == len(ctrl_va):
                                unsel = np.where(~ctrl_selected)[0]
                                sel = np.where(ctrl_selected)[0]
                                if len(unsel) > 0:
                                    bb.batch_verts = batch_for_shader(shader, 'POINTS', {'pos': ctrl_va[unsel]})
                                if len(sel) > 0 and bool(getattr(prefs, 'show_sel_verts', True)):
                                    bb.batch_sel_verts = batch_for_shader(shader, 'POINTS', {'pos': ctrl_va[sel]})
                            else:
                                bb.batch_verts = batch_for_shader(shader, 'POINTS', {'pos': ctrl_va})
                        except Exception:
                            pass
                cb_entry = {
                    'base': bb,
                    'state': cache_state,
                    'ctrl_verts': ctrl_va,
                    'ctrl_selected': ctrl_selected,
                    'shape_verts': shape_va,
                    'shape_edges': shape_ei,
                    'mesh_verts': mesh_va,
                    'mesh_edges': mesh_ei,
                    'mesh_tris': mesh_ti,
                    'has_render_mesh': bool(has_render_mesh),
                    'lod_faces_only': bool(lod_faces_only),
                }
                _sos_base_cache[cache_key] = cb_entry
                _sos_prune_base_cache()

            cb = cb_entry.get('base') if isinstance(cb_entry, dict) else None
            if cb is None:
                continue
            bd = SOS_BatchData(obj.matrix_world)
            bd.is_mod_eval = bool(getattr(cb, 'is_mod_eval', False))
            bd.batch_tris = getattr(cb, 'batch_tris', None)
            bd.batch_edges = getattr(cb, 'batch_edges', None)
            bd.batch_verts = getattr(cb, 'batch_verts', None)
            bd.batch_sel_verts = getattr(cb, 'batch_sel_verts', None)
            try:
                ctrl_va = cb_entry.get('ctrl_verts')
                shape_va = cb_entry.get('shape_verts')
                shape_ei = cb_entry.get('shape_edges')
                mesh_va = cb_entry.get('mesh_verts')
                mesh_ei = cb_entry.get('mesh_edges')
                mesh_ti = cb_entry.get('mesh_tris')
                has_render_mesh = bool(cb_entry.get('has_render_mesh'))
                lod_faces_only = bool(cb_entry.get('lod_faces_only'))
                use_render_hover = bool(has_render_mesh)
                if mx != -1 and my != -1 and region is not None and rv3d is not None and (hov_verts or hov_edges or hov_faces):
                    hv, he, hf = _curve_element_hover(
                        obj, ctrl_va, shape_va, shape_ei, mesh_va, mesh_ei, mesh_ti,
                        region, rv3d, mx, my,
                        use_render_mesh=use_render_hover,
                    )
                    if use_render_hover:
                        if hv != -1 and hov_verts and (not lod_faces_only) and mesh_va is not None and len(mesh_va) > hv:
                            bd.batch_hover_verts = batch_for_shader(shader, 'POINTS', {'pos': np.asarray([mesh_va[hv]], dtype=np.float32)})
                        if he != -1 and hov_edges and (not lod_faces_only) and mesh_ei is not None and len(mesh_ei) > he:
                            edge = mesh_ei[he]
                            bd.batch_hover_edges = batch_for_shader(shader, 'LINES', {'pos': np.asarray([mesh_va[int(edge[0])], mesh_va[int(edge[1])]], dtype=np.float32)})
                        if hf != -1 and hov_faces and mesh_ti is not None and len(mesh_ti) > hf:
                            tri = mesh_ti[hf]
                            bd.batch_hover_tris = batch_for_shader(shader, 'TRIS', {'pos': np.asarray([mesh_va[int(tri[0])], mesh_va[int(tri[1])], mesh_va[int(tri[2])]], dtype=np.float32)})
                    else:
                        if hv != -1 and hov_verts and include_shape and ctrl_va is not None and len(ctrl_va) > hv:
                            bd.batch_hover_verts = batch_for_shader(shader, 'POINTS', {'pos': np.asarray([ctrl_va[hv]], dtype=np.float32)})
                        if he != -1 and hov_edges and include_shape and shape_ei is not None and shape_va is not None and len(shape_ei) > he:
                            edge = shape_ei[he]
                            bd.batch_hover_edges = batch_for_shader(shader, 'LINES', {'pos': np.asarray([shape_va[int(edge[0])], shape_va[int(edge[1])]], dtype=np.float32)})
            except Exception:
                pass
            if (bd.batch_tris or bd.batch_edges or bd.batch_verts or bd.batch_sel_verts or bd.batch_hover_tris or bd.batch_hover_edges or bd.batch_hover_verts):
                batches.append(bd)
        except Exception:
            continue
    return batches

def _collect_object_mode_batches(context, prefs, do_obj, shader, overlay_mode='OBJECT', *, draw_base_overlay=True, same_pass_signature_cache=None):
    global _sos_selection_changed_time, _sos_base_cache, _sos_cached_hover_obj, _sos_last_mx, _sos_last_my
    global _sos_global_hover_obj, _sos_last_hover_view_sig
    global _sos_pending_hover_draw_obj, _sos_pending_hover_draw_mx, _sos_pending_hover_draw_my
    global _sos_pending_hover_draw_region_ptr, _sos_pending_hover_draw_view_sig, _sos_pending_hover_draw_until
    batches = []
    # Live source-Mesh signatures are shareable only during this collector
    # invocation. Object-specific evaluated geometry remains separate below.
    # During one Object-mode transform modal the dict is reused until any
    # geometry-relevant update advances the epoch (see the helper).
    same_pass_signature_cache = _sos_object_xform_signature_cache(context, overlay_mode)
    if not do_obj: return batches
    obj_hover_enabled = object_hover_overlay_enabled(context) and overlay_mode in {'OBJECT', 'SCULPT'}
    wm, region, rv3d = getattr(context, 'window_manager', None), getattr(context, 'region', None), getattr(context, 'region_data', None)
    mx, my = _sos_tracked_mouse_region_coords(context, region)

    hover_obj_name = ""
    
    try:
        depsgraph = context.evaluated_depsgraph_get()
    except Exception:
        return batches
    try:
        scene = getattr(context, 'scene', None)
    except Exception:
        scene = None
    if scene is None:
        return batches
    is_sculpt = (overlay_mode == 'SCULPT')
    is_lattice_edit = (overlay_mode == 'EDIT_LATTICE')

    mode_objs = []
    if is_sculpt:
        objs_in_mode = getattr(context, "objects_in_mode", None)
        if objs_in_mode:
            mode_objs = [o for o in objs_in_mode if _sos_obj_supported_objmode(o, prefs)]
        else:
            mode_objs = [
                o for o in getattr(context, "selected_objects", [])
                if _sos_obj_supported_objmode(o, prefs) and getattr(o, "mode", None) == 'SCULPT'
            ]
        act = getattr(context, "active_object", None)
        if act and _sos_obj_supported_objmode(act, prefs) and act not in mode_objs and getattr(act, "mode", None) == 'SCULPT':
            mode_objs.append(act)
    elif is_lattice_edit:
        objs_in_mode = getattr(context, "objects_in_mode", None)
        if objs_in_mode:
            mode_objs = [o for o in objs_in_mode if _is_lattice_object(o) and _sos_obj_supported_objmode(o, prefs)]
        if not mode_objs:
            act = getattr(context, "active_object", None) or getattr(context, "object", None)
            if act and _is_lattice_object(act) and _sos_obj_supported_objmode(act, prefs):
                mode_objs = [act]
    else:
        mode_objs = [o for o in (getattr(context, 'selected_objects', ()) or ()) if _sos_obj_supported_objmode(o, prefs)]

    mode_obj_names = {o.name for o in mode_objs}

    if obj_hover_enabled and (time.time() - _sos_selection_changed_time) >= getattr(prefs, "hover_delay_sec", 0.25):
        if mx != -1 and my != -1 and region and rv3d:
            hover_view_sig = _sos_hover_view_signature(region, rv3d, context)
            pending_hover_obj = ""
            pending_hover_valid = False
            try:
                pending_hover_valid = (
                    bool(_sos_pending_hover_draw_obj)
                    and time.time() <= float(_sos_pending_hover_draw_until or 0.0)
                    and int(_sos_pending_hover_draw_mx) == int(mx)
                    and int(_sos_pending_hover_draw_my) == int(my)
                    and int(_sos_pending_hover_draw_region_ptr or 0) == _sos_pointer(region)
                    and _sos_pending_hover_draw_view_sig == hover_view_sig
                )
                if pending_hover_valid:
                    pending_hover_obj = str(_sos_pending_hover_draw_obj or "")
            except Exception:
                pending_hover_valid = False
            use_cached_hover = mx == _sos_last_mx and my == _sos_last_my and hover_view_sig == _sos_last_hover_view_sig
            if pending_hover_valid:
                use_cached_hover = True
                _sos_cached_hover_obj = pending_hover_obj
                _sos_last_mx, _sos_last_my = mx, my
                _sos_last_hover_view_sig = hover_view_sig
            if use_cached_hover:
                hover_obj_name = _sos_cached_hover_obj
                try:
                    cached_obj = scene.objects.get(hover_obj_name) if hover_obj_name else None
                    if hover_obj_name and (
                        cached_obj is None
                        or bool(cached_obj.hide_get())
                        or bool(getattr(cached_obj, 'hide_select', False))
                        or not _sos_object_visible_in_view3d(context, cached_obj, region, rv3d)
                    ):
                        use_cached_hover = False
                except Exception:
                    use_cached_hover = False
            if not use_cached_hover:
                _sos_last_mx, _sos_last_my = mx, my
                _sos_last_hover_view_sig = hover_view_sig
                try:
                    # Drawing and click selection share this single picker.  The
                    # draw record is the click authority, so a second, older
                    # selected-object filter here would make Ctrl/Toggle color a
                    # different object than the one that receives the click.
                    hover_obj_name = _sos_pick_object_hover_overlay_name(
                        context, prefs, overlay_mode, region, rv3d, mx, my,
                    )
                except Exception:
                    hover_obj_name = ""
                _sos_cached_hover_obj = hover_obj_name
            if hover_obj_name:
                try:
                    _hover_obj = scene.objects.get(hover_obj_name)
                    if _hover_obj is None or not _sos_object_visible_in_view3d(context, _hover_obj, region, rv3d):
                        hover_obj_name = ""
                        _sos_cached_hover_obj = ""
                except Exception:
                    hover_obj_name = ""
                    _sos_cached_hover_obj = ""
            if _sos_selected_hover_suppression_active(context, region, mx, my):
                hover_obj_name = ""
                _sos_cached_hover_obj = ""
            _sos_global_hover_obj = hover_obj_name
            if hover_obj_name:
                _sos_note_drawn_object_hover_target(context, hover_obj_name, region, rv3d, mx, my, overlay_mode)
                if pending_hover_valid and hover_obj_name == pending_hover_obj:
                    _sos_pending_hover_draw_obj = ""
                    _sos_pending_hover_draw_mx = -1
                    _sos_pending_hover_draw_my = -1
                    _sos_pending_hover_draw_region_ptr = 0
                    _sos_pending_hover_draw_view_sig = None
                    _sos_pending_hover_draw_until = 0.0
            else:
                _sos_note_drawn_object_hover_target(context, "", region, rv3d, -1, -1, overlay_mode)
                if pending_hover_valid:
                    _sos_pending_hover_draw_obj = ""
                    _sos_pending_hover_draw_mx = -1
                    _sos_pending_hover_draw_my = -1
                    _sos_pending_hover_draw_region_ptr = 0
                    _sos_pending_hover_draw_view_sig = None
                    _sos_pending_hover_draw_until = 0.0
        else:
            # Cursor is not inside the active 3D View WINDOW region.  Do not
            # reuse the previous hover object; clear it so object-hover colors
            # disappear immediately outside true hover.
            _sos_note_drawn_object_hover_target(context, "", region, rv3d, -1, -1, overlay_mode)
            reset_object_hover_cache(preserve_drawn_regions=True)
            hover_obj_name = ""
    else:
        _sos_note_drawn_object_hover_target(context, "", region, rv3d, -1, -1, overlay_mode)
        reset_object_hover_cache(preserve_drawn_regions=True)

    target_objs = list(mode_objs) if draw_base_overlay or (obj_hover_enabled and is_sculpt) else []
    if _sos_opt_bool(prefs, 'optimization_lightest_active_object_only', False):
        active_obj = getattr(context, 'active_object', None) or getattr(context, 'object', None)
        if active_obj is not None:
            filtered = [o for o in target_objs if o == active_obj]
            if filtered:
                target_objs = filtered
    if obj_hover_enabled and (not is_sculpt) and hover_obj_name and (ho := scene.objects.get(hover_obj_name)) and _sos_obj_supported_objmode(ho, prefs) and _sos_object_visible_in_view3d(context, ho, region, rv3d) and ho not in target_objs:
        target_objs.append(ho)

    base_faces = bool(draw_base_overlay and getattr(prefs, "show_faces_edit" if is_lattice_edit else "show_faces_object", False))
    base_edges = bool(draw_base_overlay and getattr(prefs, "show_edges_edit" if is_lattice_edit else "show_edges_object", False))
    base_verts = bool(draw_base_overlay and getattr(prefs, "show_verts_edit" if is_lattice_edit else "show_verts_object", False))
    hov_faces = bool((obj_hover_enabled and getattr(prefs, "show_hov_obj_faces", False)) or (is_lattice_edit and getattr(prefs, "show_hov_faces", False)))
    hov_edges = bool((obj_hover_enabled and getattr(prefs, "show_hov_obj_edges", False)) or (is_lattice_edit and getattr(prefs, "show_hov_edges", False)))
    hov_verts = bool((obj_hover_enabled and getattr(prefs, "show_hov_obj_verts", False)) or (is_lattice_edit and getattr(prefs, "show_hov_verts", False)))

    recent_edit_sync = _edit_live_sync_active()
    navigation_light_active = _sos_lightest_mesh_overlay_navigation_active(context, prefs, rv3d)
    lightest_freeze_nav = bool(
        (
            _sos_opt_bool(prefs, 'optimization_lightest_freeze_batches_during_navigation', False)
            or _sos_opt_bool(prefs, 'optimization_navigation_light_mode', False)
        )
        and navigation_light_active
    )
    # Reuse immutable local-space geometry only within this synchronous collect.
    # Object transforms remain per-object below, and modifiers/shape keys retain
    # their existing object-specific evaluated-mesh path.
    same_pass_geometry_cache = {}
    # Keep one draw-cache entry per drawn object.  With more target objects
    # than the global bound, oldest-first pruning evicted every entry before
    # its next use and rebuilt all batches on every snapshot rebuild.
    object_cache_limit = max(_SOS_BASE_CACHE_MAX_ENTRIES, len(target_objs) + 32)

    for obj in target_objs:
        try:
            try:
                source_data = getattr(obj, 'data', None)
                source_total = int(len(getattr(source_data, 'vertices', ()) or ())) + int(len(getattr(source_data, 'edges', ()) or ())) + int(len(getattr(source_data, 'polygons', ()) or ()))
            except Exception:
                source_total = 0
            obj_lod_faces_only = bool(
                _sos_opt_bool(prefs, 'optimization_lightest_lod_skip_dense_vertices_edges', False)
                and source_total > _sos_lightest_lod_limit(prefs)
            )
            obj_base_faces = bool(base_faces)
            obj_base_edges = bool(base_edges and (not obj_lod_faces_only))
            obj_base_verts = bool(base_verts and (not obj_lod_faces_only))
            obj_hov_faces = bool(hov_faces and (not _sos_opt_bool(prefs, 'optimization_lightest_disable_mesh_hover', False)))
            obj_hov_edges = bool(hov_edges and (not obj_lod_faces_only) and (not _sos_opt_bool(prefs, 'optimization_lightest_disable_mesh_hover', False)))
            obj_hov_verts = bool(hov_verts and (not obj_lod_faces_only) and (not _sos_opt_bool(prefs, 'optimization_lightest_disable_mesh_hover', False)))
            cache_key = ("OBJECT", obj.name, bool(obj_base_faces or obj_hov_faces), bool(obj_base_edges or obj_hov_edges), bool(obj_base_verts or obj_hov_verts), bool(obj_lod_faces_only))
            cache_state = _object_mode_cache_state(obj, same_pass_signature_cache)
            cb_entry = _sos_base_cache.get(cache_key)
            if recent_edit_sync and not (lightest_freeze_nav and cb_entry):
                cb_entry = None
            elif not isinstance(cb_entry, dict):
                cb_entry = None
            elif cb_entry.get("state") != cache_state and not lightest_freeze_nav:
                cb_entry = None
            shared_geometry_key = None
            if not _is_lattice_object(obj) and isinstance(source_data, bpy.types.Mesh):
                try:
                    no_modifiers = len(getattr(obj, 'modifiers', ()) or ()) == 0
                except Exception:
                    no_modifiers = False
                if no_modifiers and not _sos_object_has_shape_key_deformation(obj):
                    shared_geometry_key = (
                        source_data,
                        bool(obj_base_faces or obj_hov_faces),
                        bool(obj_base_edges or obj_hov_edges),
                        bool(obj_base_verts or obj_hov_verts),
                        bool(obj_lod_faces_only),
                    )
                    if cb_entry is None:
                        cb_entry = same_pass_geometry_cache.get(shared_geometry_key)
                    else:
                        same_pass_geometry_cache.setdefault(shared_geometry_key, cb_entry)
            if not cb_entry:
                if _is_lattice_object(obj):
                    arrays = _lattice_geometry_arrays(obj)
                    if arrays:
                        va, ei, ti, selected = arrays
                        if len(va) > 0:
                            bb = SOS_BatchData(obj.matrix_world)
                            bb.is_lattice = True
                            # Lattice overlays intentionally skip face fills.  Only
                            # control points and cage edges are valid Smart Overlay
                            # targets for lattice objects.
                            if (obj_base_edges or obj_hov_edges) and len(ei) > 0:
                                try:
                                    bb.batch_edges = batch_for_shader(shader, 'LINES', {"pos": va}, indices=ei)
                                except Exception:
                                    pass
                            if obj_base_verts or obj_hov_verts:
                                try:
                                    bb.batch_verts = batch_for_shader(shader, 'POINTS', {"pos": va})
                                except Exception:
                                    pass
                            if is_lattice_edit:
                                try:
                                    sel_idx = np.where(selected)[0]
                                    if len(sel_idx) > 0:
                                        bb.batch_sel_verts = batch_for_shader(shader, 'POINTS', {"pos": va[sel_idx]})
                                    if len(ei) > 0 and len(sel_idx) > 0:
                                        sel_edge_mask = selected[ei[:, 0]] & selected[ei[:, 1]]
                                        sel_edges = ei[sel_edge_mask]
                                        if len(sel_edges) > 0:
                                            bb.batch_sel_edges = batch_for_shader(shader, 'LINES', {"pos": va}, indices=sel_edges)
                                    # No selected-face overlay for lattice objects.
                                except Exception:
                                    pass
                            cb_entry = {"base": bb, "state": cache_state, "verts": va, "edges": ei, "tris": ti, "selected": selected}
                            _sos_base_cache[cache_key] = cb_entry
                            _sos_prune_base_cache(object_cache_limit)
                else:
                    eo = obj.evaluated_get(depsgraph)
                    try:
                        me = eo.to_mesh(preserve_all_data_layers=False, depsgraph=depsgraph)
                    except Exception:
                        try:
                            me = eo.to_mesh()
                        except Exception:
                            me = None
                    if me:
                        try:
                            if (vc := len(me.vertices)) > 0:
                                va = np.empty(vc * 3, dtype=np.float32)
                                me.vertices.foreach_get("co", va); va = va.reshape(-1, 3)
                                bb = SOS_BatchData(obj.matrix_world)
                                if obj_base_faces or obj_hov_faces or obj_base_edges or obj_hov_edges or obj_base_verts or obj_hov_verts:
                                    try:
                                        me.calc_loop_triangles(); ti = np.empty(len(me.loop_triangles) * 3, dtype=np.int32)
                                        me.loop_triangles.foreach_get("vertices", ti)
                                        surface_batch = batch_for_shader(shader, 'TRIS', {"pos": va}, indices=ti.reshape(-1, 3))
                                        if obj_base_faces or obj_hov_faces:
                                            bb.batch_tris = surface_batch
                                        bb.batch_surface_depth_tris = surface_batch
                                    except Exception:
                                        pass
                                if obj_base_edges or obj_hov_edges:
                                    try:
                                        ei = np.empty(len(me.edges) * 2, dtype=np.int32); me.edges.foreach_get("vertices", ei)
                                        bb.batch_edges = batch_for_shader(shader, 'LINES', {"pos": va}, indices=ei.reshape(-1, 2))
                                    except Exception:
                                        pass
                                if obj_base_verts or obj_hov_verts:
                                    bb.batch_verts = batch_for_shader(shader, 'POINTS', {"pos": va})
                                cb_entry = {"base": bb, "state": cache_state}
                                _sos_base_cache[cache_key] = cb_entry
                                _sos_prune_base_cache(object_cache_limit)
                        finally:
                            try:
                                eo.to_mesh_clear()
                            except Exception:
                                pass
                if not cb_entry:
                    continue
                if shared_geometry_key is not None:
                    same_pass_geometry_cache.setdefault(shared_geometry_key, cb_entry)

            cb = cb_entry.get("base") if isinstance(cb_entry, dict) else None
            if cb is None:
                continue

            is_hover_obj = obj_hover_enabled and (obj.name == hover_obj_name)
            bd = SOS_BatchData(obj.matrix_world)
            bd.object_name = str(getattr(obj, 'name', '') or '')
            is_lattice_obj = _is_lattice_object(obj)
            bd.is_lattice = bool(is_lattice_obj)
            bd.batch_tris = None if is_lattice_obj else (cb.batch_tris if (obj_base_faces or (is_hover_obj and obj_hov_faces)) else None)
            bd.batch_surface_depth_tris = None if is_lattice_obj else getattr(cb, 'batch_surface_depth_tris', None)
            bd.batch_edges = cb.batch_edges if (obj_base_edges or (is_hover_obj and obj_hov_edges)) else None
            bd.batch_verts = cb.batch_verts if (obj_base_verts or (is_hover_obj and obj_hov_verts)) else None
            if is_lattice_obj:
                try:
                    bd.lattice_front_verts = cb_entry.get('verts') if bd.batch_verts is not None else None
                except Exception:
                    bd.lattice_front_verts = None
            if is_lattice_edit and is_lattice_obj:
                bd.batch_sel_tris = None
                bd.batch_sel_edges = getattr(cb, 'batch_sel_edges', None)
                bd.batch_sel_verts = getattr(cb, 'batch_sel_verts', None)
                try:
                    va = cb_entry.get('verts')
                    selected = cb_entry.get('selected')
                    if va is not None and selected is not None and bd.batch_sel_verts is not None:
                        sel_idx = np.where(selected)[0]
                        bd.lattice_front_sel_verts = va[sel_idx] if len(sel_idx) > 0 else None
                except Exception:
                    bd.lattice_front_sel_verts = None
                try:
                    va = cb_entry.get('verts')
                    ei = cb_entry.get('edges')
                    ti = cb_entry.get('tris')
                    hv, he, hf = _lattice_element_hover(obj, va, ei, ti, region, rv3d, mx, my)
                    if hv != -1 and obj_hov_verts:
                        hover_va = np.asarray([va[hv]], dtype=np.float32)
                        bd.batch_hover_verts = batch_for_shader(shader, 'POINTS', {"pos": hover_va})
                        bd.lattice_front_hover_verts = hover_va
                    # Lattice edit mode hovers points only: an edge hover was
                    # returned whenever the pointer missed a point, which drew
                    # a hover line Blender's lattice editing never selects.
                except Exception:
                    pass
            bd.is_hover_obj = is_hover_obj
            if (bd.batch_tris or bd.batch_edges or bd.batch_verts or bd.batch_sel_tris or bd.batch_sel_edges or bd.batch_sel_verts or bd.batch_face_center_verts or bd.batch_sel_face_center_verts or bd.batch_face_center_depth_tris or bd.batch_hover_tris or bd.batch_hover_edges or bd.batch_hover_verts):
                batches.append(bd)
        except Exception:
            continue
    return batches


def _sos_face_depth_batches(batch_data):
    """Return the single safest surface batch for overlay depth seeding.

    Face-select mode supplies one complete edit-cage batch that contains normal
    and selected faces together. Other modes retain the original normal-face
    source. Never mix color/hover/cover batches into the depth bootstrap because
    their draw order is not a reliable surface order on complex meshes.
    """
    if batch_data is None:
        return ()
    complete_cage = getattr(batch_data, 'batch_face_center_depth_tris', None)
    if complete_cage is not None:
        return (complete_cage,)
    surface_depth = getattr(batch_data, 'batch_surface_depth_tris', None)
    if surface_depth is not None:
        return (surface_depth,)
    normal_faces = getattr(batch_data, 'batch_tris', None)
    return (normal_faces,) if normal_faces is not None else ()


# =============================================================================
# Draw Callbacks

def _sos_draw_edge_front_cover(
    shader, batch, rv3d, mw, width, z_offset, color, *,
    outer_add=1.0, outer_alpha=0.18, opaque_main_cover=False,
    opaque_cover_add=0.0,
):
    """Redraw Mesh/Curve edges in a final edge-priority pass.

    Face overlays are alpha-blended fills and some later repair/diagnostic
    passes can be emitted after the normal edge pass.  This helper redraws only
    Mesh/Curve edge overlays after face drawing, but before the final vertex
    cover pass, so the visual stack is fixed as vertices > edges > faces.
    """
    if not batch or shader is None or rv3d is None or mw is None:
        return
    try:
        c = tuple(float(v) for v in color)
        if len(c) < 4 or c[3] <= 0.0:
            return
    except Exception:
        c = color
    try:
        shader.bind()
        _sos_set_depth_shader_matrices(shader, rv3d, mw)
        if opaque_main_cover and len(c) >= 4 and float(c[3]) >= 0.999:
            # Blender's one-pixel native edit-cage underlay can otherwise remain
            # visible through alpha-to-coverage samples at the selected line.
            # Paint one opaque selected-color main line first, then add the
            # normal same-color AA passes. No neutral/diagnostic hue can bleed
            # through, while the outside antialiasing remains intact.
            try:
                gpu.state.blend_set('NONE')
                gpu.state.alpha_to_coverage_set(False)
                # The native edit cage and diagnostic lines use their own raster
                # coverage. A same-width replacement can leave one-pixel color
                # shoulders at diagonal or MSAA samples. Paint a slightly wider
                # opaque line in the same target color before the normal AA line.
                gpu.state.line_width_set(max(1.0, float(width) + max(0.0, float(opaque_cover_add))))
                shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(z_offset))
                shader.uniform_float("u_color", c)
                batch.draw(shader)
            finally:
                try:
                    gpu.state.blend_set('ALPHA')
                except Exception:
                    pass
                try:
                    gpu.state.alpha_to_coverage_set(_SOS_EDGE_AA_MODE != 'AA_OFF')
                except Exception:
                    pass
        _sos_draw_edge_aa(
            shader,
            batch,
            max(1.0, float(width)),
            _sos_safe_depth_uniform(z_offset),
            c,
            outer_add=max(0.0, float(outer_add)),
            outer_alpha=max(0.0, float(outer_alpha)),
        )
    except Exception:
        pass


def _sos_draw_face_fill(shader, batch, z_offset, color, *, opaque=False):
    """Draw a face fill, optionally bypassing alpha blending completely."""
    if shader is None or batch is None:
        return
    try:
        if opaque:
            gpu.state.blend_set('NONE')
            try:
                gpu.state.alpha_to_coverage_set(False)
            except Exception:
                pass
        shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(z_offset))
        shader.uniform_float("u_color", color)
        batch.draw(shader)
    finally:
        if opaque:
            try:
                gpu.state.blend_set('ALPHA')
            except Exception:
                pass
            try:
                gpu.state.alpha_to_coverage_set(_SOS_EDGE_AA_MODE != 'AA_OFF')
            except Exception:
                pass


def _sos_draw_vertex_front_cover(shader, batch, rv3d, mw, point_size, z_offset, color):
    """Draw a vertex point again in the final front-cover pass.

    Mesh/hover edges can be emitted by later object batches, anti-alias passes,
    or orthographic repair paths after an earlier vertex batch.  This helper is
    used by the final vertex-only pass so vertex overlays remain visually on top
    of edge overlays while still using the same stable depth test and z-offset
    rules as the normal mesh and curve overlay path.
    """
    if not batch or shader is None or rv3d is None or mw is None:
        return
    try:
        c = tuple(float(v) for v in color)
        if len(c) < 4 or c[3] <= 0.0:
            return
    except Exception:
        c = color
    try:
        # Opaque vertex colors are rendered without blending in the final cover
        # pass.  This guarantees an already-rendered edge cannot remain visible
        # through the vertex point.  Semi-transparent hover/occluded vertices keep
        # normal alpha blending.
        try:
            gpu.state.blend_set('NONE' if float(c[3]) >= 0.999 else 'ALPHA')
        except Exception:
            pass
        shader.bind()
        _sos_set_depth_shader_matrices(shader, rv3d, mw)
        shader.uniform_float("u_pointSize", max(1.0, float(point_size)))
        shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(z_offset))
        shader.uniform_float("u_color", c)
        batch.draw(shader)
    except Exception:
        pass



def _sos_draw_native_mesh_edit_diagnostics_front(
    ctx, shader, rv3d, batches, native_flags_draw, front_offset,
    fallback_width=2.0, depth_test='NONE',
):
    """Redraw unselected Blender edit-edge diagnostics above normal edges.

    Blender's standard Mesh Edit Mode overlay draws Seam / Sharp / Crease /
    Bevel lines outside this add-on. Custom POST_VIEW lines and Blender's native
    edit-cage underlay can visually mix with those standard diagnostic colors.
    Python cannot reorder Blender's internal overlay pass, so Smart Overlay
    mirrors only enabled, unselected diagnostic edge batches after its normal
    edge pass. Selected diagnostic edges are intentionally absent so the
    selected-edge color retains priority. The opaque main line prevents the
    neutral edit-cage hue from bleeding through, while its same-color AA fringe
    remains intact. This does not alter the user's native overlay switches.
    """
    if shader is None or rv3d is None or not batches:
        return False
    try:
        flags = native_flags_draw or {}
        if not any(bool(flags.get(k, False)) for k in ('seam', 'sharp', 'crease', 'bevel')):
            return False
    except Exception:
        return False
    colors = _native_mesh_edit_edge_overlay_colors(ctx)
    # This mirror pass exists only to establish color priority.  It must not
    # enlarge Blender's diagnostic marks or the configured SmartOverlay edge.
    width = max(1.0, float(fallback_width))
    zoff = _sos_safe_depth_uniform(front_offset)
    drawn = False

    def _draw_one(batch, mw, color):
        nonlocal drawn
        if batch is None or mw is None:
            return
        try:
            _sos_draw_edge_front_cover(
                shader, batch, rv3d, mw, width, zoff, color,
                outer_add=0.0, outer_alpha=0.0, opaque_main_cover=True,
                opaque_cover_add=0.0,
            )
            drawn = True
        except Exception:
            pass

    try:
        gpu.state.blend_set('ALPHA')
        gpu.state.depth_mask_set(False)
        gpu.state.depth_test_set(depth_test)
        gpu.state.face_culling_set('NONE')
        try:
            gpu.state.program_point_size_set(False)
        except Exception:
            pass
        try:
            gpu.state.alpha_to_coverage_set(False)
        except Exception:
            pass
        for nb in batches:
            if bool(getattr(nb, 'occluder_only', False)):
                continue
            mw = getattr(nb, 'mw', None)
            if mw is None:
                continue
            if bool(flags.get('seam', False)):
                _draw_one(getattr(nb, 'batch_native_cage_seam', None), mw, colors.get('seam', (0.8588, 0.1451, 0.0706, 1.0)))
            if bool(flags.get('sharp', False)):
                _draw_one(getattr(nb, 'batch_native_cage_sharp', None), mw, colors.get('sharp', (0.0, 1.0, 1.0, 1.0)))
            if bool(flags.get('crease', False)):
                _draw_one(getattr(nb, 'batch_native_cage_crease', None), mw, colors.get('crease', (0.8, 0.0, 0.6, 1.0)))
            if bool(flags.get('bevel', False)):
                _draw_one(getattr(nb, 'batch_native_cage_bevel', None), mw, colors.get('bevel', (0.0, 0.6471, 1.0, 1.0)))
    except Exception:
        pass
    return bool(drawn)

# =============================================================================
class _SosFrameSettings:
    """Read-through cache of the effective settings for one draw callback.

    The POST_VIEW pass reads the same settings for every object and every
    pass.  Each name is resolved on the wrapped settings object the first time
    and kept for the rest of this draw only; the instance is created per call.
    Writes and deletes go to the wrapped object and drop the cached value.
    """

    def __init__(self, base):
        self.__dict__['_sos_frame_settings_base'] = base

    def __getattr__(self, name):
        value = getattr(self.__dict__['_sos_frame_settings_base'], name)
        self.__dict__[name] = value
        return value

    def __setattr__(self, name, value):
        d = self.__dict__
        d.pop(name, None)
        setattr(d['_sos_frame_settings_base'], name, value)

    def __delattr__(self, name):
        d = self.__dict__
        d.pop(name, None)
        delattr(d['_sos_frame_settings_base'], name)

    def __bool__(self):
        return bool(self.__dict__['_sos_frame_settings_base'])


def _draw_callback_3d_impl():
    global _sos_last_runtime_mode
    ctx, wm = bpy.context, bpy.context.window_manager
    prefs = get_effective_settings(ctx)
    if prefs is not None:
        prefs = _SosFrameSettings(prefs)
    _scope_allowed, active_view_allowed, _freeze_rebuild = mesh_curve_overlay_draw_policy(
        ctx, prefs, getattr(ctx, 'region_data', None)
    )
    if prefs is None or not active_view_allowed:
        _sos_set_lattice_front_points(ctx, [])
        reset_object_hover_cache()
        _sos_reset_gpu_state_after_draw()
        return
    mode = getattr(ctx, "mode", "")
    try:
        active_obj = getattr(ctx, 'object', None) or getattr(ctx, 'active_object', None)
    except Exception:
        active_obj = None
    live_edit_mesh_objects_for_draw = ()
    try:
        if mode != 'EDIT_MESH':
            live_edit_mesh_objects_for_draw = _sos_iter_edit_mesh_objects_for_live_transform(ctx)
            if live_edit_mesh_objects_for_draw:
                # During modal transforms Blender can call POST_VIEW from a stale
                # UI/context region even though edit mesh elements are still being
                # moved in the 3D View.  Treat that draw as EDIT_MESH so the
                # overlay rebuilds from live edit data instead of returning early
                # or keeping the previous cache until confirm.
                mode = 'EDIT_MESH'
                if active_obj is None:
                    active_obj = live_edit_mesh_objects_for_draw[0]
    except Exception:
        live_edit_mesh_objects_for_draw = ()
    if mode != 'OBJECT' and active_obj is None:
        request_overlay_snapshot_rebuild('draw_missing_active', context=ctx, immediate=True)
        reset_object_hover_cache()
        return
    runtime_mode = mode if mode in {'EDIT_MESH', 'EDIT_LATTICE', 'EDIT_CURVE', 'EDIT_CURVES', 'OBJECT', 'SCULPT'} else ""
    if runtime_mode != _sos_last_runtime_mode:
        _sos_last_runtime_mode = runtime_mode
        request_overlay_snapshot_rebuild('mode_changed', context=ctx, immediate=True)
        reset_object_hover_cache()
    rv3d = getattr(ctx, 'region_data', None)
    if rv3d is None:
        return
    _sos_begin_frame_view(rv3d)
    mesh_overlay_enabled = bool(getattr(wm, "sos_enabled", False))
    object_hover_enabled = bool(getattr(wm, "sos_object_hover_overlay_enabled", False))
    runtime_needed = (mode == 'EDIT_MESH' and mesh_overlay_enabled) or (mode == 'EDIT_LATTICE' and mesh_overlay_enabled) or (mode in {'EDIT_CURVE', 'EDIT_CURVES'} and mesh_overlay_enabled) or (mode in {'OBJECT', 'SCULPT'} and (mesh_overlay_enabled or object_hover_enabled))
    if not runtime_needed:
        return
    sh = getattr(ctx.space_data, "shading", None)
    is_xray = False
    if sh:
        try:
            if sh.type == 'WIREFRAME':
                is_xray = bool(getattr(sh, "show_xray_wireframe", False))
            else:
                is_xray = bool(getattr(sh, "show_xray", False))
                try:
                    xa = float(getattr(sh, "xray_alpha", 1.0))
                    if xa <= 0.0:
                        is_xray = False
                except Exception:
                    pass
        except Exception:
            is_xray = False
    try:
        # Native edit-overlay suppression is only relevant in Edit Mesh, or when
        # there is restore state left from leaving Edit Mesh.  Skipping this work
        # in Object/Sculpt viewport navigation avoids a per-frame scan of all
        # View3D spaces while preserving the restore path.
        if mode == 'EDIT_MESH' or _sos_adjacent_edge_wire_restore or _sos_editmode_theme_overlay_restore:
            apply_blender_adjacent_edge_gradient_visibility(ctx, prefs)
    except Exception:
        pass

    global _SOS_EDGE_AA_MODE
    # Occluded mode/style (NEW)
    occ_mode = getattr(prefs, 'occluded_display_mode', 'ALWAYS') or 'ALWAYS'
    do_occ_pass = (occ_mode == 'ALWAYS') or (occ_mode == 'XRAY_ONLY' and is_xray)
    if occ_mode == 'NEVER':
        do_occ_pass = False
    # Hide only at draw time so saved occluded colors, per-element Occluded
    # toggles, and Occluded Display Mode remain unchanged.
    hide_occ_colors_now = bool(getattr(prefs, 'hide_occluded_colors_when_xray_off', False) and (not is_xray))
    if hide_occ_colors_now:
        do_occ_pass = False
    if _sos_opt_bool(prefs, 'optimization_lightest_disable_occluded_pass', False):
        do_occ_pass = False
    # Optional visibility clamp: when the occluded-color pass is OFF, a large
    # visible-pass depth offset can pull hidden vertices, edges, or faces through
    # the front surface and leave them drawn in visible colors.  This flag keeps
    # matching visible pass tied to the unshifted stable surface depth
    # whenever the occluded pass, or a per-element Occluded toggle, is disabled,
    # so hidden parts disappear instead of falling back to visible color.
    hide_visible_occluded_when_occ_off = bool(getattr(prefs, 'hide_visible_occluded_when_occluded_off', False))
    hide_visible_occluded_now = bool(
        hide_visible_occluded_when_occ_off
        and (
            (not do_occ_pass)
            or (not bool(getattr(prefs, 'show_occ_faces', True)))
            or (not bool(getattr(prefs, 'show_occ_edges', True)))
            or (not bool(getattr(prefs, 'show_occ_verts', True)))
        )
    )
    occ_style = getattr(prefs, 'occluded_style', 'FADE_THIN') or 'FADE_THIN'
    occ_fade = occ_style in {'FADE', 'FADE_THIN'}
    occ_thin = occ_style in {'THIN', 'FADE_THIN'}
    occ_alpha_mul = float(getattr(prefs, 'occluded_alpha_mul', 1.0)) if occ_fade else 1.0
    occ_thick_mul = float(getattr(prefs, 'occluded_thickness_mul', 1.0)) if occ_thin else 1.0
    occ_point_mul = float(getattr(prefs, 'occluded_point_mul', 1.0)) if occ_thin else 1.0

    _SOS_EDGE_AA_MODE = getattr(prefs, 'edge_aa_mode', 'AA_2PASS') or 'AA_2PASS'
    
    snapshot = _sos_snapshot_for_draw(ctx, mode)
    if snapshot is None:
        _sos_set_lattice_front_points(ctx, [])
        _sos_draw_proportional_front_pass(ctx)
        return
    shader = snapshot.get('shader')
    grad_shader = snapshot.get('grad_shader')
    batches = snapshot.get('batches') or ()
    if shader is None or not batches:
        _sos_set_lattice_front_points(ctx, [])
        _sos_draw_proportional_front_pass(ctx)
        return
    # Occluded edges only: the normal pair is used when the style is not Dashed.
    occ_edge_shader = shader
    occ_grad_shader = grad_shader
    if occ_style == 'DASHED':
        global _sos_current_dash_viewport
        try:
            _sos_current_dash_viewport = (float(ctx.region.width), float(ctx.region.height))
        except Exception:
            _sos_current_dash_viewport = (1.0, 1.0)
        occ_edge_shader = get_overlay_dash_shader() or shader
        occ_grad_shader = get_gradient_dash_shader() or grad_shader

    def _draw_occ_edge_aa(batch, mw, width, zoff, color, **kwargs):
        if occ_edge_shader is shader:
            _sos_draw_edge_aa(shader, batch, width, zoff, color, **kwargs)
            return
        occ_edge_shader.bind()
        _sos_set_depth_shader_matrices(occ_edge_shader, rv3d, mw)
        _sos_draw_edge_aa(occ_edge_shader, batch, width, zoff, color, **kwargs)
        shader.bind()

    vpm = rv3d.window_matrix @ rv3d.view_matrix
    dv, do, os, rev_z = _sos_ndc_depth_direction(rv3d)
    # Clip-range compensated depth offset.
    # The shader receives a fixed signed view-space distance and encodes both
    # the hidden depth pre-pass and overlay passes into the same stable
    # logarithmic depth layer. View > Clip Start / Clip End edits therefore do
    # not rescale the visible depth relationship of mesh or hover overlay
    # vertices, edges, and faces.
    face_depth_setting = max(0.0, _sos_finite_float(getattr(prefs, "face_depth_offset", 0.0), 0.0))
    edge_depth_setting = max(0.0, _sos_finite_float(getattr(prefs, "edge_depth_offset", 0.0), 0.0))
    vertex_depth_setting = max(0.0, _sos_finite_float(getattr(prefs, "vertex_depth_offset", 0.0), 0.0))
    fo = _sos_depth_bias_from_internal(face_depth_setting, 1.0)
    eo = _sos_depth_bias_from_internal(edge_depth_setting, 1.0)
    vo = _sos_depth_bias_from_internal(vertex_depth_setting, 1.0)
    # Lock Mesh/Curve Overlay visual priority before all visible, occluded,
    # hover, and final-cover offsets are derived from these values.
    # This keeps the rendered order stable as: vertices > edges > faces, even
    # when a user sets a face depth value larger than an edge or vertex value.
    fo, eo, vo = _sos_mesh_curve_priority_depth_offsets(fo, eo, vo)
    # Keep a small but non-zero stable-depth range in front of surfaces that are
    # closer to the View3D eye than the requested depth offset.  Without this,
    # the shader's near clamp can make the visible overlay fail its depth test
    # and leave the occluded color on actually visible fragments.
    global _sos_current_stable_depth_floor
    try:
        # Keep the stable-depth floor extremely small.  A floor scaled from the
        # visible depth offsets collapses front and hidden surfaces together when
        # the mesh is very close to the View3D camera, which can remove the
        # occluded-color result.  The shader and final repair pass now handle
        # near-eye ordering without needing a large floor.
        _sos_current_stable_depth_floor = min(
            _SOS_STABLE_DEPTH_FLOOR_MAX,
            max(_SOS_STABLE_DEPTH_FLOOR_BASE, max(abs(fo), abs(eo), abs(vo)) * 0.0001),
        )
    except Exception:
        _sos_current_stable_depth_floor = _SOS_STABLE_DEPTH_FLOOR_BASE
    
    vcv, vco = (*prefs.vertex_color, 1.0), (*prefs.vertex_occluded_color, 1.0)
    sec, svc = (*prefs.selected_edge_overlay_color, 1.0), (*prefs.selected_vertex_overlay_color, 1.0)
    sfc_rgb = tuple(getattr(prefs, 'selected_face_overlay_color', getattr(prefs, 'selected_edge_overlay_color', (1.0, 0.33, 0.0))))
    def _sos_clamp_alpha(value, fallback=1.0):
        try:
            f = float(value)
        except Exception:
            f = float(fallback)
        return 0.0 if f < 0.0 else (1.0 if f > 1.0 else f)

    hover_obj_ve_alpha = _sos_clamp_alpha(getattr(prefs, 'hover_obj_vertex_edge_opacity', 1.0), 1.0)
    hover_obj_face_alpha = _sos_clamp_alpha(getattr(prefs, 'hover_obj_face_opacity', getattr(prefs, 'opacity', 0.2)), getattr(prefs, 'opacity', 0.2))

    hvc, hec, hfc = (*prefs.hover_vertex_color, 1.0), (*prefs.hover_edge_color, 1.0), (*prefs.hover_face_color, prefs.opacity)
    ovc, oec, ofc = (*prefs.hover_obj_vertex_color, hover_obj_ve_alpha), (*prefs.hover_obj_edge_color, hover_obj_ve_alpha), (*prefs.hover_obj_face_color, hover_obj_face_alpha)
    _, _, tvs = get_theme_colors(ctx)
    edit_mode_overlay_flags = _mesh_edit_overlay_suppression_flags(ctx, prefs) if mode == 'EDIT_MESH' else {}
    force_vertex_cover = bool(edit_mode_overlay_flags.get('force_vertex_cover', False)) if edit_mode_overlay_flags else False
    force_edge_cover = bool(edit_mode_overlay_flags.get('force_edge_cover', False)) if edit_mode_overlay_flags else False
    force_face_cover = bool(edit_mode_overlay_flags.get('force_face_cover', False)) if edit_mode_overlay_flags else False

    # Selection-mode size policy:
    # - Edges must remain at the normal Smart Overlay edge size in vertex, edge,
    #   and face selection modes. This covers selected edges, linked-cover edges,
    #   hover edges, and half-selected gradient edges.
    # - Vertices must remain at the normal Smart Overlay vertex size in edge and
    #   face selection modes only. Vertex selection mode can still use the existing
    #   selected-vertex emphasis.
    edit_selection_kinds = _mesh_edit_selection_modes(ctx) if mode == 'EDIT_MESH' else set()
    draw_selected_faces = bool(mode == 'EDIT_MESH' and 'FACE' in edit_selection_kinds and bool(getattr(prefs, 'show_sel_faces', True)))
    keep_edge_base_size = bool(edit_selection_kinds.intersection({'VERT', 'EDGE', 'FACE'}))
    keep_vertex_base_size = bool(edit_selection_kinds.intersection({'EDGE', 'FACE'}))
    base_edge_width = max(1.0, float(getattr(prefs, "edge_size", 1.0) or 1.0))
    base_vertex_point = max(1.0, float(getattr(prefs, "vertex_size", 1.0) or 1.0))
    base_edge_width_occ = max(1.0, base_edge_width * float(occ_thick_mul))
    base_vertex_point_occ = max(1.0, base_vertex_point * float(occ_point_mul))
    # Selection and diagnostic priority are controlled by draw order, never by
    # inflating a line or point beyond the user's configured overlay sizes.
    selected_edge_width_vis = base_edge_width
    selected_edge_width_occ = base_edge_width_occ
    cover_edge_width_vis = base_edge_width
    cover_edge_width_occ = base_edge_width_occ
    hover_edge_width_vis = base_edge_width if keep_edge_base_size else base_edge_width + 1.0
    hover_edge_width_occ = base_edge_width_occ if keep_edge_base_size else base_edge_width + 1.0
    selected_vertex_point_vis = base_vertex_point
    selected_vertex_point_occ = base_vertex_point_occ
    cover_vertex_point_vis = base_vertex_point
    cover_vertex_point_occ = base_vertex_point_occ
    half_sel_outer_width_vis = base_edge_width
    half_sel_main_width_vis = base_edge_width
    half_sel_outer_width_occ = base_edge_width_occ
    half_sel_main_width_occ = base_edge_width_occ
    edge_emphasis_outer_alpha = 0.18 if keep_edge_base_size else 0.22
    # Selection/cover overlays are placed on deterministic sub-layers derived
    # from the same clip-invariant NDC baseline.  Hover overlays intentionally
    # use the exact Mesh/Curve Overlay per-element depth offsets below, so the
    # Hover Overlay vertex, edge, and face depth strength always matches the
    # corresponding Mesh/Curve Overlay settings instead of adding an extra
    # hover-only depth sub-layer.
    fso = _sos_layered_depth_bias(fo, 1.0, 0.35)
    eso = _sos_layered_depth_bias(eo, 1.0, 0.35)
    vso = _sos_layered_depth_bias(vo, 1.0, 0.50)
    fo_occ, eo_occ, vo_occ = -fo, -eo, -vo
    fso_occ, eso_occ, vso_occ = -fso, -eso, -vso
    # Solid display (X-Ray OFF) gets a small visible-pass-only forward sublayer
    # so overlay fragments do not collapse onto the same depth as the reference
    # surface. This sublayer is also expressed in fixed view-space units.
    front_face_boost = min(_SOS_DEPTH_VIEW_MAX * 0.25, abs(fo) * 0.30) if not is_xray else 0.0
    front_edge_boost = min(_SOS_DEPTH_VIEW_MAX * 0.25, abs(eo) * 0.30) if not is_xray else 0.0
    front_vert_boost = min(_SOS_DEPTH_VIEW_MAX * 0.25, abs(vo) * 0.30) if not is_xray else 0.0
    fo_vis, eo_vis, vo_vis = (fo + front_face_boost, eo + front_edge_boost, vo + front_vert_boost)
    fso_vis = (fso + front_face_boost) if abs(fso) > 0.0 else 0.0
    eso_vis = (eso + front_edge_boost) if abs(eso) > 0.0 else 0.0
    vso_vis = (vso + front_vert_boost) if abs(vso) > 0.0 else 0.0
    if hide_visible_occluded_when_occ_off:
        # In this mode the visible-color pass is a visibility mask for any
        # element type whose occluded-color counterpart is currently disabled.
        # Use the same stable depth as the surface pre-pass for those visible
        # colors so hidden parts disappear instead of being pulled through by the
        # visible depth offset.  Selection sub-layers keep their normal offset
        # while an occluded pass exists, because they have their own occluded
        # draw branch.  Hover follows the base Mesh/Curve per-element offsets.
        if not (do_occ_pass and bool(getattr(prefs, 'show_occ_faces', True))):
            fo_vis = 0.0
        if not (do_occ_pass and bool(getattr(prefs, 'show_occ_edges', True))):
            eo_vis = 0.0
        if not (do_occ_pass and bool(getattr(prefs, 'show_occ_verts', True))):
            vo_vis = 0.0
        if not do_occ_pass:
            fso_vis = eso_vis = vso_vis = 0.0
    _sos_has_depth_offset = max(abs(fo_vis), abs(eo_vis), abs(vo_vis), abs(fso_vis), abs(eso_vis), abs(vso_vis)) > 1.0e-10
    dv_overlay = _sos_visible_depth_test_for_overlay(rv3d, dv, _sos_has_depth_offset)
    do_overlay = _sos_occluded_depth_test_for_overlay(rv3d, do)
    near_eye_occlusion_fallback = False
    try:
        near_eye_occlusion_fallback = bool(
            do_occ_pass
            and bool(getattr(rv3d, 'is_perspective', False))
            and _sos_near_eye_occlusion_fallback_active(
                ctx, rv3d,
                max(_sos_current_stable_depth_floor * 4.0, max(abs(fo), abs(eo), abs(vo), 1.0e-6) * 2.0),
            )
        )
    except Exception:
        near_eye_occlusion_fallback = False
    try:
        _sos_orthographic_depth_mode = not bool(getattr(rv3d, 'is_perspective', False))
    except Exception:
        _sos_orthographic_depth_mode = True
    # Final occluded-color repair is required in perspective as well as
    # orthographic views.  Near-camera visible offsets can otherwise pull hidden
    # fragments in front of the depth pre-pass and overwrite the occluded color.
    # The repair pass uses unshifted stable depth with a strict occluded test, so
    # it repaints only fragments that are actually behind the nearest overlay
    # surface and does not affect front/equal visible fragments.
    do_stable_occlusion_repair = bool(do_occ_pass and _sos_has_depth_offset)
    stable_repair_depth = _sos_strict_occluded_depth_test_for_overlay(rv3d, do_overlay)

    try:
        _sos_set_lattice_front_points(
            ctx,
            _sos_project_lattice_front_points(
                ctx, batches, prefs, region, rv3d,
                vcv=vcv, svc=svc, hvc=hvc, ovc=ovc,
                base_vertex_point=base_vertex_point,
                selected_vertex_point_vis=selected_vertex_point_vis,
                tvs=tvs,
            ),
        )
    except Exception:
        _sos_set_lattice_front_points(ctx, [])

    # -------------------------------------------------------------------------
    # 根本修正 [1]: Depth Pre-Pass (深度の強制書き込み)
    # 透過時(X-Ray ON)でも、表面のメッシュ形状を透明な状態で深度バッファに書き込み、
    # 遮蔽判定（何が手前で何が奥か）が確実に計算されるようにします。
    # -------------------------------------------------------------------------
    extra_occluder_depth_active = any(bool(getattr(b, 'occluder_only', False)) for b in batches)
    run_depth_prepass = True
    try:
        if run_depth_prepass and _sos_opt_bool(prefs, 'optimization_conditional_depth_prepass', False):
            has_face_depth_source = any(bool(_sos_face_depth_batches(b)) for b in batches)
            run_depth_prepass = bool(has_face_depth_source or extra_occluder_depth_active)
    except Exception:
        run_depth_prepass = True
    if run_depth_prepass:
        try:
            gpu.state.blend_set('NONE')
            gpu.state.depth_test_set(dv)
            gpu.state.depth_mask_set(True)
            try: gpu.state.color_mask_set(False, False, False, False)
            except AttributeError: pass
            # Use a two-sided geometry reference. Orthographic views can expose
            # small unwritten depth gaps on edge-on or flipped faces when the
            # pre-pass is back-face culled; those gaps let the visible pass
            # repaint hidden overlay fragments. Writing both sides keeps the
            # nearest stable depth for Mesh and Curve Overlay and Hover Overlay.
            gpu.state.face_culling_set('NONE')
            
            # Bootstrap the Smart Overlay depth field before the normal
            # depth-tested pre-pass.  The View3D already contains Blender's
            # native scene depth when POST_VIEW handlers run.  Near-camera
            # geometry can have native depth values at the near limit; if the
            # stable overlay pre-pass is tested against those native values, the
            # stable pre-pass may fail to write and the following visible pass
            # can leave the occluded color on actually visible fragments.
            #
            # First seed every overlay surface with our own stable depth while
            # ignoring the existing native buffer.  Then run the same pass with
            # the normal stable depth comparison so the nearest Smart Overlay
            # surface wins.  This keeps close-camera visibility correct without
            # reading or modifying Blender mesh data.
            depth_prepass_tests = ('ALWAYS', dv)
            # Module constants only: the same value for every batch.
            prepass_z = _sos_safe_depth_uniform(_sos_depth_prepass_bias(1.0))
            # The depth source of each batch is the same in both passes.
            prepass_items = [(b, _sos_face_depth_batches(b)) for b in batches]
            for _prepass_depth_test in depth_prepass_tests:
                gpu.state.depth_test_set(_prepass_depth_test)
                # Only matrices change between these draws, so u_zOffset keeps
                # the value written before the first draw of this pass.
                prepass_z_written = False
                for b, face_depth_batches in prepass_items:
                    for face_depth_batch in face_depth_batches:
                        shader.bind()
                        model_view = _sos_set_depth_shader_matrices(shader, rv3d, b.mw)
                        if not prepass_z_written:
                            shader.uniform_float("u_zOffset", prepass_z)
                            prepass_z_written = True
                        face_depth_batch.draw(shader)
        finally:
            try: gpu.state.color_mask_set(True, True, True, True)
            except AttributeError: pass
            gpu.state.depth_mask_set(False)

    # -------------------------------------------------------------------------
    # 根本修正 [2]: メイン描画ループ (遮蔽パスと可視パスを完全分離)
    # -------------------------------------------------------------------------
    try:
        gpu.state.blend_set('ALPHA')
        aa_enabled = (_SOS_EDGE_AA_MODE != 'AA_OFF')
        for s, v in [('line_smooth_set', aa_enabled), ('multisample_set', aa_enabled), ('alpha_to_coverage_set', aa_enabled), ('program_point_size_set', True)]:
            try: getattr(gpu.state, s)(v)
            except Exception: pass
        
        gpu.state.face_culling_set('NONE' if prefs.double_sided else 'BACK')
        
        _sos_obj_color_cache = {}
        for b in batches:
            if bool(getattr(b, 'occluder_only', False)):
                continue
            shader.bind()
            model_view = _sos_set_depth_shader_matrices(shader, rv3d, b.mw)
            
            fm, em = float(getattr(b, 'face_op_mul', 1.0)), float(getattr(b, 'edge_alpha_mul', 1.0))
            # These colors depend only on (fm, em) and this draw's settings;
            # batches with the same multipliers reuse the first batch's tuples
            # (zero multipliers are rebuilt so the sign of zero is kept).
            _sos_ck = (fm, em) if (fm and em) else None
            _sos_cv = _sos_obj_color_cache.get(_sos_ck) if _sos_ck is not None else None
            if _sos_cv is None:
                ecv_m = (*prefs.edge_color, 1.0 * em)
                eco_m = (*prefs.edge_occluded_color, 1.0 * em * occ_alpha_mul)
                fcv_m = (*prefs.face_color, prefs.opacity * fm)
                fco_m = (*prefs.face_occluded_color, prefs.opacity * fm * occ_alpha_mul)
                # With viewport X-Ray OFF, a selected edit face is a selection mask,
                # not a translucent face overlay. Keep its chosen RGB but make the
                # visible selected fill fully opaque so the material/base face cannot
                # show through it. X-Ray keeps the configured overlay opacity.
                selected_face_alpha_vis = 1.0 if (mode == 'EDIT_MESH' and not is_xray) else _sos_clamp_alpha(prefs.opacity * fm)
                sfc_m = (*sfc_rgb, selected_face_alpha_vis)
                sfc_occ_m = (*sfc_rgb, prefs.opacity * fm * occ_alpha_mul)
                if _sos_ck is not None:
                    _sos_obj_color_cache[_sos_ck] = (ecv_m, eco_m, fcv_m, fco_m, selected_face_alpha_vis, sfc_m, sfc_occ_m)
            else:
                ecv_m, eco_m, fcv_m, fco_m, selected_face_alpha_vis, sfc_m, sfc_occ_m = _sos_cv
            # Read-only check; the same answer for the occluded and visible pass.
            _sos_b_hover = mode in {'OBJECT', 'SCULPT'} and _sos_batch_is_active_object_hover(ctx, b)
            
            # === [PASS A] OCCLUDED PASS (遮蔽パス) ===
            # Disabled when Occluded Display Mode is Never, or when the
            # transparent-display-off suppression option is currently active.
            if do_occ_pass:
                gpu.state.depth_test_set('ALWAYS' if near_eye_occlusion_fallback else do_overlay)  # GREATER 等（奥にあるかテスト）
                
                if _sos_b_hover:
                    if b.batch_tris:
                        # Object-hover overlay should respect per-type depth offsets
                        # (face/edge/vert) instead of using a single shared selection offset.
                        shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(fo_occ))
                        shader.uniform_float("u_color", ofc if prefs.show_hov_obj_faces else fco_m)
                        b.batch_tris.draw(shader)
                    if b.batch_edges:
                        _sos_draw_edge_aa(shader, b.batch_edges, float(prefs.edge_size + (1.0 if prefs.show_hov_obj_edges else 0.0)), eo_occ, (oec if prefs.show_hov_obj_edges else eco_m))
                    if b.batch_verts:
                        shader.uniform_float("u_pointSize", float(prefs.vertex_size + (2.0 if prefs.show_hov_obj_verts else 0.0)))
                        shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(vo_occ))
                        shader.uniform_float("u_color", ovc if prefs.show_hov_obj_verts else vco)
                        b.batch_verts.draw(shader)
                else:
                    if b.batch_tris and prefs.show_occ_faces:
                        shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(fo_occ))
                        shader.uniform_float("u_color", fco_m)
                        b.batch_tris.draw(shader)
                    if getattr(b, 'batch_sel_tris', None) and draw_selected_faces:
                        shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(fso_occ if abs(fso_occ) > 0.0 else fo_occ))
                        shader.uniform_float("u_color", sfc_occ_m)
                        b.batch_sel_tris.draw(shader)
                    if getattr(b, 'batch_cover_tris', None) and force_face_cover and prefs.show_occ_faces:
                        # Linked cover faces are not actual Face Select selections.
                        # Draw them with the normal face overlay color, not Blender's
                        # or Smart Overlay's selected color.
                        shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(fo_occ))
                        shader.uniform_float("u_color", fco_m)
                        b.batch_cover_tris.draw(shader)
                    if getattr(b, 'batch_hover_tris', None) and prefs.show_hov_faces:
                        shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(fo_occ))
                        shader.uniform_float("u_color", hfc)
                        b.batch_hover_tris.draw(shader)
                    if b.batch_edges and prefs.show_occ_edges:
                        _draw_occ_edge_aa(b.batch_edges, b.mw, base_edge_width_occ, eo_occ, eco_m)
                    if getattr(b, 'batch_half_sel_occ', None) and occ_grad_shader and prefs.show_occ_edges:
                        occ_grad_shader.bind()
                        _sos_set_depth_shader_matrices(occ_grad_shader, rv3d, b.mw)
                        occ_grad_shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(eso_occ))
                        # Anti-alias (outer soft pass + main pass)
                        try:
                            occ_grad_shader.uniform_float("u_alphaMul", 0.18)
                        except Exception:
                            pass
                        gpu.state.line_width_set(half_sel_outer_width_occ)
                        b.batch_half_sel_occ.draw(occ_grad_shader)
                        try:
                            occ_grad_shader.uniform_float("u_alphaMul", 1.0)
                        except Exception:
                            pass
                        gpu.state.line_width_set(half_sel_main_width_occ)
                        b.batch_half_sel_occ.draw(occ_grad_shader)
                        shader.bind()
                    if b.batch_cover_edges and force_edge_cover:
                        # Linked cover edges are not actual edge-mode selections.
                        # Always redraw them with the base overlay color, never the
                        # selected orange color, otherwise the Blender highlight appears
                        # to remain even when the suppression option is enabled.
                        cover_edge_width_occ_draw = cover_edge_width_occ
                        cover_edge_offset_occ = eso_occ if abs(eso_occ) > 0.0 else eo_occ
                        cover_edge_color_occ = eco_m
                        outer_add_cover_occ = 1.0
                        outer_alpha_cover_occ = edge_emphasis_outer_alpha
                        _draw_occ_edge_aa(b.batch_cover_edges, b.mw, cover_edge_width_occ_draw, cover_edge_offset_occ, cover_edge_color_occ, outer_add=outer_add_cover_occ, outer_alpha=outer_alpha_cover_occ)
                    if getattr(b, 'batch_hover_edges', None) and prefs.show_hov_edges:
                        _sos_draw_edge_aa(shader, b.batch_hover_edges, hover_edge_width_occ, eo_occ, hec, outer_add=1.0, outer_alpha=edge_emphasis_outer_alpha)
                    draw_selected_edges_occ = bool(prefs.show_sel_edges) or force_edge_cover
                    if b.batch_sel_edges and draw_selected_edges_occ:
                        sel_edge_width_occ = selected_edge_width_occ if prefs.show_sel_edges else base_edge_width_occ
                        sel_edge_offset_occ = eso_occ if prefs.show_sel_edges else eo_occ
                        sel_edge_color_occ = sec if prefs.show_sel_edges else eco_m
                        outer_add_occ = 1.0 if prefs.show_sel_edges else 0.0
                        outer_alpha_occ = edge_emphasis_outer_alpha if prefs.show_sel_edges else 0.0
                        _draw_occ_edge_aa(b.batch_sel_edges, b.mw, sel_edge_width_occ, sel_edge_offset_occ, sel_edge_color_occ, outer_add=outer_add_occ, outer_alpha=outer_alpha_occ)
                    if b.batch_verts and prefs.show_occ_verts:
                        shader.uniform_float("u_pointSize", base_vertex_point_occ)
                        shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(vo_occ))
                        shader.uniform_float("u_color", (vco[0], vco[1], vco[2], vco[3] * occ_alpha_mul))
                        b.batch_verts.draw(shader)
                    draw_selected_verts_occ = bool(prefs.show_sel_verts) or force_vertex_cover
                    if b.batch_sel_verts and draw_selected_verts_occ:
                        sel_vert_point_occ = selected_vertex_point_occ if prefs.show_sel_verts else base_vertex_point_occ
                        sel_vert_offset_occ = vso_occ if prefs.show_sel_verts else vo_occ
                        sel_vert_color_occ = svc if prefs.show_sel_verts else (vco[0], vco[1], vco[2], vco[3] * occ_alpha_mul)
                        shader.uniform_float("u_pointSize", sel_vert_point_occ)
                        shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(sel_vert_offset_occ))
                        shader.uniform_float("u_color", sel_vert_color_occ)
                        b.batch_sel_verts.draw(shader)
                    if b.batch_cover_verts and force_vertex_cover:
                        # Linked cover vertices are not actual vertex-mode selections.
                        # Use the base vertex color so the native orange linked-vertex
                        # highlight is visibly replaced instead of being reintroduced.
                        cover_vert_point_occ = cover_vertex_point_occ
                        cover_vert_offset_occ = vso_occ if abs(vso_occ) > 0.0 else vo_occ
                        cover_vert_color_occ = (vco[0], vco[1], vco[2], vco[3] * occ_alpha_mul)
                        shader.uniform_float("u_pointSize", cover_vert_point_occ)
                        shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(cover_vert_offset_occ))
                        shader.uniform_float("u_color", cover_vert_color_occ)
                        b.batch_cover_verts.draw(shader)
                    if getattr(b, 'batch_hover_verts', None) and prefs.show_hov_verts:
                        shader.uniform_float("u_pointSize", base_vertex_point_occ if keep_vertex_base_size else base_vertex_point)
                        shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(vo_occ))
                        shader.uniform_float("u_color", hvc)
                        b.batch_hover_verts.draw(shader)

            # === [PASS B] VISIBLE PASS (可視パス) ===
            gpu.state.depth_test_set(dv_overlay)  # LESS_EQUAL 等（手前にあるかテスト）
            
            if _sos_b_hover:
                if b.batch_tris:
                    # Object-hover overlay should respect per-type depth offsets
                    # (face/edge/vert) instead of using a single shared selection offset.
                    shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(fo_vis))
                    shader.uniform_float("u_color", ofc if prefs.show_hov_obj_faces else fcv_m)
                    b.batch_tris.draw(shader)
                if b.batch_edges:
                    _sos_draw_edge_aa(shader, b.batch_edges, float(prefs.edge_size + (1.0 if prefs.show_hov_obj_edges else 0.0)), eo_vis, (oec if prefs.show_hov_obj_edges else ecv_m))
                if b.batch_verts:
                    shader.uniform_float("u_pointSize", float(prefs.vertex_size + (2.0 if prefs.show_hov_obj_verts else 0.0)))
                    shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(vo_vis))
                    shader.uniform_float("u_color", ovc if prefs.show_hov_obj_verts else vcv)
                    b.batch_verts.draw(shader)
                if do_stable_occlusion_repair:
                    # Final occluded-color repair pass.  Near-camera or flat
                    # depth can let a visible-color fragment survive on hidden
                    # hover geometry.  Re-test the original, unshifted
                    # geometry against the stable pre-pass with a strict occluded
                    # comparison and repaint only fragments that are actually
                    # behind the surface.  Perspective is left untouched.
                    gpu.state.depth_test_set(stable_repair_depth)
                    shader.bind()
                    _sos_set_depth_shader_matrices(shader, rv3d, b.mw)
                    _repair_z = _sos_safe_depth_uniform(0.0)
                    if b.batch_tris:
                        shader.uniform_float("u_zOffset", _repair_z)
                        shader.uniform_float("u_color", ofc if prefs.show_hov_obj_faces else fco_m)
                        b.batch_tris.draw(shader)
                    if b.batch_edges:
                        _sos_draw_edge_aa(shader, b.batch_edges, float(prefs.edge_size + (1.0 if prefs.show_hov_obj_edges else 0.0)), _repair_z, (oec if prefs.show_hov_obj_edges else eco_m))
                    if b.batch_verts:
                        shader.uniform_float("u_pointSize", float(prefs.vertex_size + (2.0 if prefs.show_hov_obj_verts else 0.0)))
                        shader.uniform_float("u_zOffset", _repair_z)
                        shader.uniform_float("u_color", ovc if prefs.show_hov_obj_verts else vco)
                        b.batch_verts.draw(shader)
                    gpu.state.depth_test_set(dv_overlay)
            else:
                if b.batch_tris and prefs.show_vis_faces:
                    shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(fo_vis))
                    shader.uniform_float("u_color", fcv_m)
                    b.batch_tris.draw(shader)
                if getattr(b, 'batch_sel_tris', None) and draw_selected_faces:
                    _sos_draw_face_fill(
                        shader,
                        b.batch_sel_tris,
                        fso_vis if abs(fso_vis) > 0.0 else fo_vis,
                        sfc_m,
                        opaque=bool(not is_xray),
                    )
                if getattr(b, 'batch_cover_tris', None) and force_face_cover and prefs.show_vis_faces:
                    # Linked cover faces are intentionally redrawn as normal face
                    # overlays so Vertex/Edge Select modes do not reintroduce a
                    # selected-orange face fill through Smart Overlay.
                    shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(fo_vis))
                    shader.uniform_float("u_color", fcv_m)
                    b.batch_cover_tris.draw(shader)
                if getattr(b, 'batch_hover_tris', None) and prefs.show_hov_faces:
                    shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(fo_vis))
                    shader.uniform_float("u_color", hfc)
                    b.batch_hover_tris.draw(shader)
                if b.batch_edges and prefs.show_vis_edges:
                    _sos_draw_edge_aa(shader, b.batch_edges, base_edge_width, eo_vis, ecv_m)
                if getattr(b, 'batch_half_sel_vis', None) and grad_shader and prefs.show_vis_edges:
                    grad_shader.bind()
                    _sos_set_depth_shader_matrices(grad_shader, rv3d, b.mw)
                    grad_shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(eso_vis))
                    # Anti-alias (outer soft pass + main pass)
                    try:
                        grad_shader.uniform_float("u_alphaMul", 0.18)
                    except Exception:
                        pass
                    gpu.state.line_width_set(half_sel_outer_width_vis)
                    b.batch_half_sel_vis.draw(grad_shader)
                    try:
                        grad_shader.uniform_float("u_alphaMul", 1.0)
                    except Exception:
                        pass
                    gpu.state.line_width_set(half_sel_main_width_vis)
                    b.batch_half_sel_vis.draw(grad_shader)
                    shader.bind()
                if b.batch_cover_edges and force_edge_cover:
                    # Linked cover edges are not actual edge-mode selections.
                    # Always redraw them with the base overlay color, never the
                    # selected orange color, otherwise the Blender highlight appears
                    # to remain even when the suppression option is enabled.
                    cover_edge_width_vis_draw = cover_edge_width_vis
                    cover_edge_offset_vis = eso_vis if abs(eso_vis) > 0.0 else eo_vis
                    cover_edge_color_vis = ecv_m
                    outer_add_cover_vis = 1.0
                    outer_alpha_cover_vis = edge_emphasis_outer_alpha
                    _sos_draw_edge_aa(shader, b.batch_cover_edges, cover_edge_width_vis_draw, cover_edge_offset_vis, cover_edge_color_vis, outer_add=outer_add_cover_vis, outer_alpha=outer_alpha_cover_vis)
                if getattr(b, 'batch_hover_edges', None) and prefs.show_hov_edges:
                    _sos_draw_edge_aa(shader, b.batch_hover_edges, hover_edge_width_vis, eo_vis, hec, outer_add=1.0, outer_alpha=edge_emphasis_outer_alpha)
                draw_selected_edges_vis = bool(prefs.show_sel_edges) or force_edge_cover
                if b.batch_sel_edges and draw_selected_edges_vis:
                    sel_edge_width_vis = selected_edge_width_vis if prefs.show_sel_edges else base_edge_width
                    sel_edge_offset_vis = eso_vis if prefs.show_sel_edges else eo_vis
                    sel_edge_color_vis = sec if prefs.show_sel_edges else ecv_m
                    outer_add_vis = 1.0 if prefs.show_sel_edges else 0.0
                    outer_alpha_vis = edge_emphasis_outer_alpha if prefs.show_sel_edges else 0.0
                    _sos_draw_edge_aa(shader, b.batch_sel_edges, sel_edge_width_vis, sel_edge_offset_vis, sel_edge_color_vis, outer_add=outer_add_vis, outer_alpha=outer_alpha_vis)
                if b.batch_verts and prefs.show_vis_verts:
                    shader.uniform_float("u_pointSize", base_vertex_point)
                    shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(vo_vis))
                    shader.uniform_float("u_color", vcv)
                    b.batch_verts.draw(shader)
                draw_selected_verts_vis = bool(prefs.show_sel_verts) or force_vertex_cover
                if b.batch_sel_verts and draw_selected_verts_vis:
                    sel_vert_point_vis = selected_vertex_point_vis if prefs.show_sel_verts else base_vertex_point
                    sel_vert_offset_vis = vso_vis if prefs.show_sel_verts else vo_vis
                    sel_vert_color_vis = svc if prefs.show_sel_verts else vcv
                    shader.uniform_float("u_pointSize", sel_vert_point_vis)
                    shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(sel_vert_offset_vis))
                    shader.uniform_float("u_color", sel_vert_color_vis)
                    b.batch_sel_verts.draw(shader)
                if b.batch_cover_verts and force_vertex_cover:
                    # Linked cover vertices are not actual vertex-mode selections.
                    # Use the base vertex color so the native orange linked-vertex
                    # highlight is visibly replaced instead of being reintroduced.
                    cover_vert_point_vis = cover_vertex_point_vis
                    cover_vert_offset_vis = vso_vis if abs(vso_vis) > 0.0 else vo_vis
                    cover_vert_color_vis = vcv
                    shader.uniform_float("u_pointSize", cover_vert_point_vis)
                    shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(cover_vert_offset_vis))
                    shader.uniform_float("u_color", cover_vert_color_vis)
                    b.batch_cover_verts.draw(shader)
                if getattr(b, 'batch_hover_verts', None) and prefs.show_hov_verts:
                    shader.uniform_float("u_pointSize", base_vertex_point)
                    shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(vo_vis))
                    shader.uniform_float("u_color", hvc)
                    b.batch_hover_verts.draw(shader)

                if do_stable_occlusion_repair:
                    # Final occluded-color repair pass for Mesh and Curve Overlay.
                    # The pass uses the unshifted stable depth and a strict
                    # occluded comparison, so front/equal fragments are not
                    # recolored, while hidden fragments are guaranteed to be
                    # restored to the occluded/hover occluded color after the
                    # visible-color pass.
                    gpu.state.depth_test_set(stable_repair_depth)
                    shader.bind()
                    _sos_set_depth_shader_matrices(shader, rv3d, b.mw)
                    _repair_z = _sos_safe_depth_uniform(0.0)
                    if b.batch_tris and prefs.show_occ_faces:
                        shader.uniform_float("u_zOffset", _repair_z)
                        shader.uniform_float("u_color", fco_m)
                        b.batch_tris.draw(shader)
                    if getattr(b, 'batch_sel_tris', None) and draw_selected_faces:
                        shader.uniform_float("u_zOffset", _repair_z)
                        shader.uniform_float("u_color", sfc_occ_m)
                        b.batch_sel_tris.draw(shader)
                    if getattr(b, 'batch_cover_tris', None) and force_face_cover and prefs.show_occ_faces:
                        shader.uniform_float("u_zOffset", _repair_z)
                        shader.uniform_float("u_color", fco_m)
                        b.batch_cover_tris.draw(shader)
                    if getattr(b, 'batch_hover_tris', None) and prefs.show_hov_faces:
                        shader.uniform_float("u_zOffset", _repair_z)
                        shader.uniform_float("u_color", hfc)
                        b.batch_hover_tris.draw(shader)
                    if b.batch_edges and prefs.show_occ_edges:
                        _draw_occ_edge_aa(b.batch_edges, b.mw, base_edge_width_occ, _repair_z, eco_m)
                    if getattr(b, 'batch_cover_edges', None) and force_edge_cover:
                        _draw_occ_edge_aa(b.batch_cover_edges, b.mw, cover_edge_width_occ, _repair_z, eco_m, outer_add=1.0, outer_alpha=edge_emphasis_outer_alpha)
                    if getattr(b, 'batch_hover_edges', None) and prefs.show_hov_edges:
                        _sos_draw_edge_aa(shader, b.batch_hover_edges, hover_edge_width_occ, _repair_z, hec, outer_add=1.0, outer_alpha=edge_emphasis_outer_alpha)
                    draw_selected_edges_repair = bool(prefs.show_sel_edges) or force_edge_cover
                    if b.batch_sel_edges and draw_selected_edges_repair:
                        sel_edge_width_repair = selected_edge_width_occ if prefs.show_sel_edges else base_edge_width_occ
                        sel_edge_color_repair = sec if prefs.show_sel_edges else eco_m
                        outer_add_repair = 1.0 if prefs.show_sel_edges else 0.0
                        outer_alpha_repair = edge_emphasis_outer_alpha if prefs.show_sel_edges else 0.0
                        _draw_occ_edge_aa(b.batch_sel_edges, b.mw, sel_edge_width_repair, _repair_z, sel_edge_color_repair, outer_add=outer_add_repair, outer_alpha=outer_alpha_repair)
                    if b.batch_verts and prefs.show_occ_verts:
                        shader.uniform_float("u_pointSize", base_vertex_point_occ)
                        shader.uniform_float("u_zOffset", _repair_z)
                        shader.uniform_float("u_color", (vco[0], vco[1], vco[2], vco[3] * occ_alpha_mul))
                        b.batch_verts.draw(shader)
                    draw_selected_verts_repair = bool(prefs.show_sel_verts) or force_vertex_cover
                    if b.batch_sel_verts and draw_selected_verts_repair:
                        sel_vert_point_repair = selected_vertex_point_occ if prefs.show_sel_verts else base_vertex_point_occ
                        sel_vert_color_repair = svc if prefs.show_sel_verts else (vco[0], vco[1], vco[2], vco[3] * occ_alpha_mul)
                        shader.uniform_float("u_pointSize", sel_vert_point_repair)
                        shader.uniform_float("u_zOffset", _repair_z)
                        shader.uniform_float("u_color", sel_vert_color_repair)
                        b.batch_sel_verts.draw(shader)
                    if b.batch_cover_verts and force_vertex_cover:
                        shader.uniform_float("u_pointSize", cover_vertex_point_occ)
                        shader.uniform_float("u_zOffset", _repair_z)
                        shader.uniform_float("u_color", (vco[0], vco[1], vco[2], vco[3] * occ_alpha_mul))
                        b.batch_cover_verts.draw(shader)
                    if getattr(b, 'batch_hover_verts', None) and prefs.show_hov_verts:
                        shader.uniform_float("u_pointSize", base_vertex_point_occ if keep_vertex_base_size else base_vertex_point)
                        shader.uniform_float("u_zOffset", _repair_z)
                        shader.uniform_float("u_color", hvc)
                        b.batch_hover_verts.draw(shader)
                    gpu.state.depth_test_set(dv_overlay)

                # --- Topology Checks Overlay (NEW) ---
                if mode == 'EDIT_MESH' and getattr(prefs, "topology_checks_enabled", False):
                    try:
                        # Ensure shader + matrices for this object
                        shader.bind()
                        _sos_set_depth_shader_matrices(shader, rv3d, b.mw)

                        topo_off = min(_SOS_DEPTH_VIEW_MAX, max(abs(fo), abs(eo), abs(vo), abs(fso), abs(eso), abs(vso), abs(front_edge_boost), 1.0e-6) + 1.0e-6)
                        topo_w = float(prefs.edge_size) * float(getattr(prefs, "topo_edge_size_mul", 1.4) or 1.4)
                        topo_w = max(
                            topo_w,
                            float(base_edge_width), float(base_edge_width_occ),
                            float(selected_edge_width_vis), float(selected_edge_width_occ),
                            float(hover_edge_width_vis), float(hover_edge_width_occ),
                            float(cover_edge_width_vis), float(cover_edge_width_occ),
                        )

                        # Diagnostic face fills are drawn first.  Diagnostic edges are
                        # drawn last so Seam / Sharp / Crease / Bevel colors always
                        # take priority over Mesh and Curve Overlay edge colors.
                        if getattr(prefs, "topo_faces_enabled", True):
                            topo_face_a = float(prefs.opacity) * float(getattr(prefs, "topo_face_opacity_mul", 0.65) or 0.65)
                            if getattr(b, "batch_topo_ngons", None) and getattr(prefs, "topo_show_ngons", False):
                                shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(topo_off))
                                shader.uniform_float("u_color", (*prefs.topo_face_color_ngon, topo_face_a))
                                b.batch_topo_ngons.draw(shader)
                            if getattr(b, "batch_topo_small", None) and getattr(prefs, "topo_show_small_faces", False):
                                shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(topo_off))
                                shader.uniform_float("u_color", (*prefs.topo_face_color_small, topo_face_a))
                                b.batch_topo_small.draw(shader)
                            if getattr(b, "batch_topo_all_faces", None) and getattr(prefs, "topo_show_backfaces", False):
                                try:
                                    gpu.state.face_culling_set('FRONT')
                                    shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(topo_off))
                                    shader.uniform_float("u_color", (*prefs.topo_face_color_backface, topo_face_a))
                                    b.batch_topo_all_faces.draw(shader)
                                finally:
                                    gpu.state.face_culling_set('NONE' if prefs.double_sided else 'BACK')

                        if getattr(prefs, "topo_edges_enabled", True):
                            if getattr(b, "batch_topo_seam", None) and getattr(prefs, "topo_show_seams", True):
                                _sos_draw_edge_aa(shader, b.batch_topo_seam, topo_w, topo_off, (*prefs.topo_edge_color_seam, 1.0))
                            if getattr(b, "batch_topo_sharp", None) and getattr(prefs, "topo_show_sharp", True):
                                _sos_draw_edge_aa(shader, b.batch_topo_sharp, topo_w, topo_off, (*prefs.topo_edge_color_sharp, 1.0))
                            if getattr(b, "batch_topo_crease", None) and getattr(prefs, "topo_show_crease", False):
                                _sos_draw_edge_aa(shader, b.batch_topo_crease, topo_w, topo_off, (*prefs.topo_edge_color_crease, 1.0))
                            if getattr(b, "batch_topo_bevel", None) and getattr(prefs, "topo_show_bevel_weight", False):
                                _sos_draw_edge_aa(shader, b.batch_topo_bevel, topo_w, topo_off, (*prefs.topo_edge_color_bevel, 1.0))
                            if getattr(b, "batch_topo_nonmanifold", None) and getattr(prefs, "topo_show_non_manifold", True):
                                _sos_draw_edge_aa(shader, b.batch_topo_nonmanifold, topo_w, topo_off, (*prefs.topo_edge_color_nonmanifold, 1.0))
                    except Exception:
                        pass


        # === [PASS C] FINAL EDGE FRONT-COVER PASS ===
        # Redraw Mesh/Curve edge overlays after all face-fill and orthographic
        # repair face passes.  This fixes the visual stack so Mesh/Curve edges
        # cannot be muted by face alpha when later batches or repair paths draw
        # faces after the normal edge pass.  Native Seam / Sharp / Crease /
        # Bevel diagnostic redraw is still emitted after this block so those
        # diagnostic marks keep their own priority over normal overlay edges.
        try:
            gpu.state.blend_set('ALPHA')
            gpu.state.depth_mask_set(False)
            gpu.state.face_culling_set('NONE')
            aa_enabled_front = (_SOS_EDGE_AA_MODE != 'AA_OFF')
            for s, v in [('line_smooth_set', aa_enabled_front), ('multisample_set', aa_enabled_front), ('alpha_to_coverage_set', aa_enabled_front)]:
                try:
                    getattr(gpu.state, s)(v)
                except Exception:
                    pass

            _sos_edge_front_items = []

            def _draw_mesh_edge_front_sets(depth_test, *, occluded=False, repair=False):
                gpu.state.depth_test_set(depth_test)
                # The batch list and its attributes do not change during this
                # draw, so the three calls share one pass of the filter below.
                if not _sos_edge_front_items:
                    _items = []
                    for eb in batches:
                        if bool(getattr(eb, 'occluder_only', False)):
                            continue
                        mw = getattr(eb, 'mw', None)
                        if mw is None:
                            continue
                        # Every draw below needs one of these edge batches; a batch
                        # without any of them (e.g. face-only Object-mode overlay)
                        # would draw nothing, so skip its per-batch setup.
                        if not (getattr(eb, 'batch_edges', None) or getattr(eb, 'batch_sel_edges', None)
                                or getattr(eb, 'batch_hover_edges', None) or getattr(eb, 'batch_cover_edges', None)
                                or getattr(eb, 'batch_half_sel_occ', None) or getattr(eb, 'batch_half_sel_vis', None)):
                            continue
                        _items.append((eb, mw))
                    _sos_edge_front_items.append(_items)
                for eb, mw in _sos_edge_front_items[0]:
                    fm = float(getattr(eb, 'face_op_mul', 1.0))
                    em = float(getattr(eb, 'edge_alpha_mul', 1.0))
                    del fm
                    ecv_front = (*prefs.edge_color, 1.0 * em)
                    eco_front = (*prefs.edge_occluded_color, 1.0 * em * occ_alpha_mul)

                    if mode in {'OBJECT', 'SCULPT'} and _sos_batch_is_active_object_hover(ctx, eb):
                        if getattr(eb, 'batch_edges', None):
                            z_value = _sos_safe_depth_uniform(0.0 if repair else (eo_occ if occluded else eo_vis))
                            color_value = (oec if prefs.show_hov_obj_edges else (eco_front if (occluded or repair) else ecv_front))
                            width_value = float(prefs.edge_size + (1.0 if prefs.show_hov_obj_edges else 0.0))
                            _sos_draw_edge_front_cover(shader, eb.batch_edges, rv3d, mw, width_value, z_value, color_value, outer_add=1.0, outer_alpha=edge_emphasis_outer_alpha)
                        continue

                    if occluded or repair:
                        z_base = _sos_safe_depth_uniform(0.0 if repair else eo_occ)
                        z_sel = _sos_safe_depth_uniform(0.0 if repair else (eso_occ if prefs.show_sel_edges else eo_occ))
                        z_cover = _sos_safe_depth_uniform(0.0 if repair else (eso_occ if abs(eso_occ) > 0.0 else eo_occ))
                        z_hover = _sos_safe_depth_uniform(0.0 if repair else eo_occ)
                        if getattr(eb, 'batch_edges', None) and prefs.show_occ_edges:
                            _sos_draw_edge_front_cover(occ_edge_shader, eb.batch_edges, rv3d, mw, base_edge_width_occ, z_base, eco_front, outer_add=1.0, outer_alpha=edge_emphasis_outer_alpha)
                        if getattr(eb, 'batch_half_sel_occ', None) and occ_grad_shader and prefs.show_occ_edges:
                            try:
                                occ_grad_shader.bind()
                                _sos_set_depth_shader_matrices(occ_grad_shader, rv3d, mw)
                                occ_grad_shader.uniform_float("u_zOffset", z_sel)
                                occ_grad_shader.uniform_float("u_alphaMul", 0.18)
                                gpu.state.line_width_set(half_sel_outer_width_occ)
                                eb.batch_half_sel_occ.draw(occ_grad_shader)
                                occ_grad_shader.uniform_float("u_alphaMul", 1.0)
                                gpu.state.line_width_set(half_sel_main_width_occ)
                                eb.batch_half_sel_occ.draw(occ_grad_shader)
                                shader.bind()
                            except Exception:
                                try:
                                    shader.bind()
                                except Exception:
                                    pass
                        if getattr(eb, 'batch_cover_edges', None) and force_edge_cover:
                            _sos_draw_edge_front_cover(occ_edge_shader, eb.batch_cover_edges, rv3d, mw, cover_edge_width_occ, z_cover, eco_front, outer_add=1.0, outer_alpha=edge_emphasis_outer_alpha)
                        if getattr(eb, 'batch_hover_edges', None) and prefs.show_hov_edges:
                            _sos_draw_edge_front_cover(shader, eb.batch_hover_edges, rv3d, mw, hover_edge_width_occ, z_hover, hec, outer_add=1.0, outer_alpha=edge_emphasis_outer_alpha)
                        draw_selected_edges_front = bool(prefs.show_sel_edges) or force_edge_cover
                        if getattr(eb, 'batch_sel_edges', None) and draw_selected_edges_front:
                            sel_width = selected_edge_width_occ if prefs.show_sel_edges else base_edge_width_occ
                            sel_color = sec if prefs.show_sel_edges else eco_front
                            outer_add = 1.0 if prefs.show_sel_edges else 0.0
                            outer_alpha = edge_emphasis_outer_alpha if prefs.show_sel_edges else 0.0
                            _sos_draw_edge_front_cover(
                                occ_edge_shader, eb.batch_sel_edges, rv3d, mw, sel_width, z_sel, sel_color,
                                outer_add=0.0, outer_alpha=0.0,
                                opaque_main_cover=bool(prefs.show_sel_edges),
                                opaque_cover_add=0.0,
                            )
                    else:
                        if getattr(eb, 'batch_edges', None) and prefs.show_vis_edges:
                            _sos_draw_edge_front_cover(shader, eb.batch_edges, rv3d, mw, base_edge_width, _sos_safe_depth_uniform(eo_vis), ecv_front, outer_add=1.0, outer_alpha=edge_emphasis_outer_alpha)
                        if getattr(eb, 'batch_half_sel_vis', None) and grad_shader and prefs.show_vis_edges:
                            try:
                                grad_shader.bind()
                                _sos_set_depth_shader_matrices(grad_shader, rv3d, mw)
                                grad_shader.uniform_float("u_zOffset", _sos_safe_depth_uniform(eso_vis))
                                grad_shader.uniform_float("u_alphaMul", 0.18)
                                gpu.state.line_width_set(half_sel_outer_width_vis)
                                eb.batch_half_sel_vis.draw(grad_shader)
                                grad_shader.uniform_float("u_alphaMul", 1.0)
                                gpu.state.line_width_set(half_sel_main_width_vis)
                                eb.batch_half_sel_vis.draw(grad_shader)
                                shader.bind()
                            except Exception:
                                try:
                                    shader.bind()
                                except Exception:
                                    pass
                        if getattr(eb, 'batch_cover_edges', None) and force_edge_cover:
                            z_cover = _sos_safe_depth_uniform(eso_vis if abs(eso_vis) > 0.0 else eo_vis)
                            _sos_draw_edge_front_cover(shader, eb.batch_cover_edges, rv3d, mw, cover_edge_width_vis, z_cover, ecv_front, outer_add=1.0, outer_alpha=edge_emphasis_outer_alpha)
                        if getattr(eb, 'batch_hover_edges', None) and prefs.show_hov_edges:
                            _sos_draw_edge_front_cover(shader, eb.batch_hover_edges, rv3d, mw, hover_edge_width_vis, _sos_safe_depth_uniform(eo_vis), hec, outer_add=1.0, outer_alpha=edge_emphasis_outer_alpha)
                        draw_selected_edges_front = bool(prefs.show_sel_edges) or force_edge_cover
                        if getattr(eb, 'batch_sel_edges', None) and draw_selected_edges_front:
                            sel_width = selected_edge_width_vis if prefs.show_sel_edges else base_edge_width
                            sel_z = _sos_safe_depth_uniform(eso_vis if prefs.show_sel_edges else eo_vis)
                            sel_color = sec if prefs.show_sel_edges else ecv_front
                            outer_add = 1.0 if prefs.show_sel_edges else 0.0
                            outer_alpha = edge_emphasis_outer_alpha if prefs.show_sel_edges else 0.0
                            _sos_draw_edge_front_cover(
                                shader, eb.batch_sel_edges, rv3d, mw, sel_width, sel_z, sel_color,
                                outer_add=0.0, outer_alpha=0.0,
                                opaque_main_cover=bool(prefs.show_sel_edges),
                                opaque_cover_add=0.0,
                            )

            if do_occ_pass:
                _draw_mesh_edge_front_sets(do_overlay, occluded=True)
            _draw_mesh_edge_front_sets(dv_overlay, occluded=False)
            if do_stable_occlusion_repair:
                _draw_mesh_edge_front_sets(stable_repair_depth, repair=True)
        except Exception:
            pass

        # === [PASS C2] NATIVE EDIT-EDGE DIAGNOSTIC FRONT-COVER PASS ===
        # Mirror only unselected Seam / Sharp / Crease / Bevel edges after the
        # normal edge pass. With X-Ray OFF the stable visible-depth test keeps
        # hidden diagnostics hidden; X-Ray ON preserves Blender's transparent
        # all-depth behavior. The opaque main line hides the neutral edit cage.
        # These cage diagnostics are intentionally not synthesized for
        # modifier-evaluated geometry.
        try:
            if mode == 'EDIT_MESH':
                native_flags_front = _native_mesh_edit_edge_overlay_flags(ctx)
                if any(bool(native_flags_front.get(k, False)) for k in ('seam', 'sharp', 'crease', 'bevel')):
                    native_front_offset = min(
                        _SOS_DEPTH_VIEW_MAX,
                        max(abs(fo), abs(eo), abs(vo), abs(fso), abs(eso), abs(vso), abs(front_edge_boost), 1.0e-6) + 4.0e-6,
                    )
                    _sos_draw_native_mesh_edit_diagnostics_front(
                        ctx, shader, rv3d, batches, native_flags_front, native_front_offset,
                        max(
                            float(base_edge_width), float(base_edge_width_occ),
                            float(selected_edge_width_vis), float(selected_edge_width_occ),
                            float(hover_edge_width_vis), float(hover_edge_width_occ),
                            float(cover_edge_width_vis), float(cover_edge_width_occ),
                        ),
                        depth_test='NONE' if is_xray else dv_overlay,
                    )
        except Exception:
            pass

        # === [PASS C2b] TOPOLOGY EDGE FRONT-COVER PASS ===
        # Topology Checks are asked for explicitly, so their colors stay above the
        # normal edge front-cover pass and the native diagnostic mirror above.
        try:
            if mode == 'EDIT_MESH' and getattr(prefs, 'topology_checks_enabled', False) and getattr(prefs, 'topo_edges_enabled', True):
                topo_front_offset = min(
                    _SOS_DEPTH_VIEW_MAX,
                    max(abs(fo), abs(eo), abs(vo), abs(fso), abs(eso), abs(vso), abs(front_edge_boost), 1.0e-6) + 6.0e-6,
                )
                topo_front_width = max(
                    float(prefs.edge_size) * float(getattr(prefs, 'topo_edge_size_mul', 1.4) or 1.4),
                    float(base_edge_width), float(base_edge_width_occ),
                )
                gpu.state.depth_mask_set(False)
                gpu.state.face_culling_set('NONE')
                gpu.state.depth_test_set('NONE' if is_xray else dv_overlay)
                topo_front_sets = (
                    ('topo_show_bevel_weight', False, 'batch_topo_bevel', 'topo_edge_color_bevel'),
                    ('topo_show_crease', False, 'batch_topo_crease', 'topo_edge_color_crease'),
                    ('topo_show_sharp', True, 'batch_topo_sharp', 'topo_edge_color_sharp'),
                    ('topo_show_seams', True, 'batch_topo_seam', 'topo_edge_color_seam'),
                    ('topo_show_non_manifold', True, 'batch_topo_nonmanifold', 'topo_edge_color_nonmanifold'),
                )
                for tb in batches:
                    if bool(getattr(tb, 'occluder_only', False)):
                        continue
                    tb_mw = getattr(tb, 'mw', None)
                    if tb_mw is None:
                        continue
                    for show_name, show_default, batch_name, color_name in topo_front_sets:
                        topo_batch = getattr(tb, batch_name, None)
                        if topo_batch is None or not bool(getattr(prefs, show_name, show_default)):
                            continue
                        _sos_draw_edge_front_cover(
                            shader, topo_batch, rv3d, tb_mw, topo_front_width,
                            _sos_safe_depth_uniform(topo_front_offset),
                            (*getattr(prefs, color_name), 1.0),
                            outer_add=0.0, outer_alpha=0.0,
                            opaque_main_cover=True, opaque_cover_add=0.0,
                        )
        except Exception:
            pass

        # === [PASS C3] ABSOLUTE SELECTED-EDGE PRIORITY PASS ===
        # Blender's native diagnostic overlay and Smart Overlay's mirrored
        # diagnostic pass must never be the final color on an actually selected
        # edge. Repaint selected edges once, after every edge-category pass, with
        # an opaque same-color coverage margin. Vertex points are drawn afterward
        # and therefore still retain the highest element priority.
        try:
            if mode == 'EDIT_MESH' and bool(getattr(prefs, 'show_sel_edges', True)):
                gpu.state.depth_mask_set(False)
                gpu.state.face_culling_set('NONE')
                gpu.state.depth_test_set('NONE' if is_xray else dv_overlay)
                for eb in batches:
                    if bool(getattr(eb, 'occluder_only', False)):
                        continue
                    sel_batch = getattr(eb, 'batch_sel_edges', None)
                    mw = getattr(eb, 'mw', None)
                    if sel_batch is None or mw is None:
                        continue
                    _sos_draw_edge_front_cover(
                        shader, sel_batch, rv3d, mw,
                        selected_edge_width_vis,
                        _sos_safe_depth_uniform(eso_vis),
                        sec,
                        outer_add=0.0,
                        outer_alpha=0.0,
                        opaque_main_cover=True,
                        opaque_cover_add=0.0,
                    )
        except Exception:
            pass


        # === [PASS D] FINAL VERTEX FRONT-COVER PASS ===
        # Redraw vertex overlays after all face/edge/diagnostic edge passes.
        # This prevents line batches from later objects, anti-alias outer passes,
        # and orthographic repair lines from visually crossing or bleeding through
        # vertex points.  The same stable depth tests are retained, so hidden
        # vertices still remain hidden/occluded according to the current overlay
        # settings; only the vertex-vs-edge draw priority is changed.
        try:
            gpu.state.blend_set('ALPHA')
            gpu.state.depth_mask_set(False)
            gpu.state.face_culling_set('NONE')
            try:
                gpu.state.program_point_size_set(True)
            except Exception:
                pass
            # Alpha-to-coverage is useful for lines, but on point sprites it can
            # create sample holes where the already-drawn edge color remains
            # visible.  Disable it only for this final vertex cover pass.
            try:
                gpu.state.alpha_to_coverage_set(False)
            except Exception:
                pass

            _sos_vert_front_items = []

            def _draw_mesh_vertex_front_sets(depth_test, *, occluded=False, repair=False):
                gpu.state.depth_test_set(depth_test)
                # Same filter for the three calls of this draw; evaluated once.
                if not _sos_vert_front_items:
                    _items = []
                    for vb in batches:
                        if bool(getattr(vb, 'occluder_only', False)):
                            continue
                        mw = getattr(vb, 'mw', None)
                        if mw is None:
                            continue
                        # Every draw below needs one of these point batches.
                        if not (getattr(vb, 'batch_verts', None) or getattr(vb, 'batch_sel_verts', None)
                                or getattr(vb, 'batch_hover_verts', None) or getattr(vb, 'batch_cover_verts', None)):
                            continue
                        _items.append((vb, mw))
                    _sos_vert_front_items.append(_items)
                for vb, mw in _sos_vert_front_items[0]:
                    if mode in {'OBJECT', 'SCULPT'} and _sos_batch_is_active_object_hover(ctx, vb):
                        if getattr(vb, 'batch_verts', None):
                            if repair:
                                z_value = _sos_safe_depth_uniform(0.0)
                                color_value = ovc if prefs.show_hov_obj_verts else vco
                            elif occluded:
                                z_value = _sos_safe_depth_uniform(vo_occ)
                                color_value = ovc if prefs.show_hov_obj_verts else vco
                            else:
                                z_value = _sos_safe_depth_uniform(vo_vis)
                                color_value = ovc if prefs.show_hov_obj_verts else vcv
                            _sos_draw_vertex_front_cover(
                                shader, vb.batch_verts, rv3d, mw,
                                float(prefs.vertex_size + (2.0 if prefs.show_hov_obj_verts else 0.0)),
                                z_value,
                                color_value,
                            )
                        continue

                    if occluded or repair:
                        base_occ_color = (vco[0], vco[1], vco[2], vco[3] * occ_alpha_mul)
                        z_base = _sos_safe_depth_uniform(0.0 if repair else vo_occ)
                        z_sel = _sos_safe_depth_uniform(0.0 if repair else (vso_occ if prefs.show_sel_verts else vo_occ))
                        z_cover = _sos_safe_depth_uniform(0.0 if repair else (vso_occ if abs(vso_occ) > 0.0 else vo_occ))
                        z_hover = _sos_safe_depth_uniform(0.0 if repair else vo_occ)
                        if getattr(vb, 'batch_verts', None) and prefs.show_occ_verts:
                            _sos_draw_vertex_front_cover(shader, vb.batch_verts, rv3d, mw, base_vertex_point_occ, z_base, base_occ_color)
                        draw_selected_verts_front = bool(prefs.show_sel_verts) or force_vertex_cover
                        if getattr(vb, 'batch_sel_verts', None) and draw_selected_verts_front:
                            sel_size = selected_vertex_point_occ if prefs.show_sel_verts else base_vertex_point_occ
                            sel_color = svc if prefs.show_sel_verts else base_occ_color
                            _sos_draw_vertex_front_cover(shader, vb.batch_sel_verts, rv3d, mw, sel_size, z_sel, sel_color)
                        if getattr(vb, 'batch_cover_verts', None) and force_vertex_cover:
                            _sos_draw_vertex_front_cover(shader, vb.batch_cover_verts, rv3d, mw, cover_vertex_point_occ, z_cover, base_occ_color)
                        if getattr(vb, 'batch_hover_verts', None) and prefs.show_hov_verts:
                            hover_size = base_vertex_point_occ if keep_vertex_base_size else base_vertex_point
                            _sos_draw_vertex_front_cover(shader, vb.batch_hover_verts, rv3d, mw, hover_size, z_hover, hvc)
                    else:
                        if getattr(vb, 'batch_verts', None) and prefs.show_vis_verts:
                            _sos_draw_vertex_front_cover(shader, vb.batch_verts, rv3d, mw, base_vertex_point, _sos_safe_depth_uniform(vo_vis), vcv)
                        draw_selected_verts_front = bool(prefs.show_sel_verts) or force_vertex_cover
                        if getattr(vb, 'batch_sel_verts', None) and draw_selected_verts_front:
                            sel_size = selected_vertex_point_vis if prefs.show_sel_verts else base_vertex_point
                            sel_offset = vso_vis if prefs.show_sel_verts else vo_vis
                            sel_color = svc if prefs.show_sel_verts else vcv
                            _sos_draw_vertex_front_cover(shader, vb.batch_sel_verts, rv3d, mw, sel_size, _sos_safe_depth_uniform(sel_offset), sel_color)
                        if getattr(vb, 'batch_cover_verts', None) and force_vertex_cover:
                            cover_offset = vso_vis if abs(vso_vis) > 0.0 else vo_vis
                            _sos_draw_vertex_front_cover(shader, vb.batch_cover_verts, rv3d, mw, cover_vertex_point_vis, _sos_safe_depth_uniform(cover_offset), vcv)
                        if getattr(vb, 'batch_hover_verts', None) and prefs.show_hov_verts:
                            _sos_draw_vertex_front_cover(shader, vb.batch_hover_verts, rv3d, mw, base_vertex_point, _sos_safe_depth_uniform(vo_vis), hvc)

            if do_occ_pass:
                _draw_mesh_vertex_front_sets(do_overlay, occluded=True)
            _draw_mesh_vertex_front_sets(dv_overlay, occluded=False)
            if do_stable_occlusion_repair:
                _draw_mesh_vertex_front_sets(stable_repair_depth, repair=True)

            # Face-select center dots are edit-mode readability markers, not real
            # vertices. Blender's native face dots are suppressed while this path
            # is active, so Smart Overlay owns the complete result: occluded dots
            # first, then visible dots over them. Both compare against the single
            # complete cage depth batch built above, avoiding selection-batch order
            # artifacts on mixed selected/unselected or non-planar meshes.
            # POST_PIXEL owns face-center dots whenever its runtime handler is
            # available. Drawing the same size once in POST_VIEW and again in
            # POST_PIXEL can shift the two point sprites by a subpixel on some
            # GPUs, turning a configured 4 px dot into a visible 5-6 px union.
            # Keep this depth-tested path strictly as a handler fallback.
            if mode == 'EDIT_MESH' and 'FACE' in edit_selection_kinds and _pixel_draw_handler is None:
                try:
                    face_center_depth_base = max(abs(vo_vis), abs(vso_vis), abs(eo_vis), abs(fo_vis), 1.0e-6)
                    face_center_z = _sos_safe_depth_uniform(_sos_layered_depth_bias(face_center_depth_base, 1.0, 0.75))
                    face_center_z_occ = _sos_safe_depth_uniform(_sos_layered_depth_bias(face_center_depth_base, -1.0, 0.75))

                    if do_occ_pass and bool(getattr(prefs, 'show_occ_verts', True)):
                        gpu.state.depth_test_set(do_overlay)
                        base_center_occ = (vco[0], vco[1], vco[2], vco[3] * occ_alpha_mul)
                        for vb in batches:
                            if bool(getattr(vb, 'occluder_only', False)):
                                continue
                            mw = getattr(vb, 'mw', None)
                            if mw is None:
                                continue
                            if getattr(vb, 'batch_face_center_verts', None):
                                _sos_draw_vertex_front_cover(shader, vb.batch_face_center_verts, rv3d, mw, base_vertex_point_occ, face_center_z_occ, base_center_occ)
                            if getattr(vb, 'batch_sel_face_center_verts', None) and prefs.show_sel_verts:
                                # Fallback handler path: selected ownership is
                                # orange from the first and only selected-center
                                # draw, never an occluded blue seed plus orange.
                                _sos_draw_vertex_front_cover(shader, vb.batch_sel_face_center_verts, rv3d, mw, selected_vertex_point_occ, face_center_z_occ, svc)

                    gpu.state.depth_test_set(dv_overlay)
                    for vb in batches:
                        if bool(getattr(vb, 'occluder_only', False)):
                            continue
                        mw = getattr(vb, 'mw', None)
                        if mw is None:
                            continue
                        if getattr(vb, 'batch_face_center_verts', None) and prefs.show_vis_verts:
                            _sos_draw_vertex_front_cover(shader, vb.batch_face_center_verts, rv3d, mw, base_vertex_point, face_center_z, vcv)
                        if getattr(vb, 'batch_sel_face_center_verts', None) and prefs.show_sel_verts and not do_occ_pass:
                            # If the occluded pass ran, the selected center was
                            # already drawn once in the selected color above.
                            _sos_draw_vertex_front_cover(shader, vb.batch_sel_face_center_verts, rv3d, mw, selected_vertex_point_vis, face_center_z, svc)
                except Exception:
                    pass
        except Exception:
            pass

        # === [PASS E] PROPORTIONAL OVERLAY FINAL FRONT PASS ===
        # The proportional heatmap has its own POST_VIEW handler, but handler order
        # can invert when Blender or Smart Overlay re-hooks draw callbacks during
        # recovery, UV/editor switching, or mode changes.  Draw it once more here
        # as the last Mesh/Curve-owned View3D pass, and let properties.py skip its
        # standalone View3D handler while this mesh runtime is active.  This fixes
        # the visual stack deterministically: Mesh/Curve/Hover overlays first,
        # Proportional overlay last.
        _sos_draw_proportional_front_pass(ctx)

    finally:
        _sos_reset_gpu_state_after_draw()


def draw_callback_lattice_front_pixels():
    """Safe POST_PIXEL wrapper for the lattice-front helper draw."""
    global _sos_last_lattice_pixel_draw_time, _sos_draw_exception_count
    _sos_last_lattice_pixel_draw_time = time.time()
    _sos_gpu_snapshot = _sos_push_gpu_state_restore()
    _sos_clip_token = _sos_begin_post_pixel_ui_region_clip(bpy.context)
    try:
        return _draw_callback_lattice_front_pixels_impl()
    except Exception:
        _sos_draw_exception_count += 1
        try:
            _sos_reset_gpu_state_after_draw()
        except Exception:
            pass
        try:
            _sos_schedule_runtime_recovery(attempts=2, first_interval=0.03)
        except Exception:
            pass
        try:
            tag_view3d_redraw()
        except Exception:
            pass
        return None
    finally:
        _sos_end_post_pixel_ui_region_clip(_sos_clip_token)
        _sos_pop_gpu_state_restore(_sos_gpu_snapshot, ui_safe=True)


def draw_callback_3d():
    """Safe POST_VIEW wrapper.

    Never allow an exception to escape Blender's draw callback.  Escaped draw
    exceptions are the common cause of resident overlay drawing going silent until
    the add-on is toggled.  The wrapper also marks draw-time execution so expensive
    edit/evaluated-mesh sync paths can refuse to block Blender's UI thread.
    """
    global _sos_last_view3d_draw_time, _sos_draw_exception_count, _sos_draw_callback_active
    _sos_last_view3d_draw_time = time.time()
    _sos_draw_start = _sos_perf_counter()
    _sos_gpu_snapshot = _sos_push_gpu_state_restore()
    _sos_clip_token = _sos_begin_sidebar_safe_overlay_clip(bpy.context)
    _sos_draw_callback_active = True
    try:
        return _draw_callback_3d_impl()
    except _SOSOverlayBudgetExceeded as _sos_budget_exc:
        try:
            _sos_note_edit_budget_overrun(str(_sos_budget_exc), duration=_sos_perf_counter() - _sos_draw_start)
        except Exception:
            pass
        try:
            _sos_reset_gpu_state_after_draw()
        except Exception:
            pass
        return None
    except Exception:
        _sos_draw_exception_count += 1
        try:
            _sos_reset_gpu_state_after_draw()
        except Exception:
            pass
        try:
            _sos_schedule_runtime_recovery(attempts=2, first_interval=0.03)
        except Exception:
            pass
        try:
            tag_view3d_redraw()
        except Exception:
            pass
        return None
    finally:
        _sos_draw_callback_active = False
        _sos_end_frame_view()
        try:
            _sos_draw_duration = _sos_perf_counter() - _sos_draw_start
            if _sos_draw_duration > _SOS_DRAW_DURATION_WARN_SECONDS:
                _sos_note_edit_budget_overrun('slow draw callback', duration=_sos_draw_duration)
        except Exception:
            pass
        _sos_end_sidebar_safe_overlay_clip(_sos_clip_token)
        _sos_pop_gpu_state_restore(_sos_gpu_snapshot, ui_safe=True)


@persistent
def _sos_depsgraph_update(scene, depsgraph):
    global _sos_last_selected_names, _sos_selection_changed_time, _sos_hover_scene_revision
    try:
        ctx = bpy.context
        mode_now = getattr(ctx, "mode", "")
        edit_target_names = set()
        if mode_now in {'EDIT_MESH', 'EDIT_LATTICE'}:
            try:
                edit_objs = getattr(ctx, 'objects_in_mode', None) or ()
            except Exception:
                edit_objs = ()
            if not edit_objs:
                try:
                    edit_obj = getattr(ctx, 'object', None) or getattr(ctx, 'active_object', None)
                    edit_objs = (edit_obj,) if edit_obj is not None else ()
                except Exception:
                    edit_objs = ()
            for obj in edit_objs:
                try:
                    obj_type = getattr(obj, 'type', None)
                    if mode_now == 'EDIT_MESH' and obj_type != 'MESH':
                        continue
                    if mode_now == 'EDIT_LATTICE' and obj_type != 'LATTICE':
                        continue
                    name = str(getattr(obj, 'name', '') or '')
                    if name:
                        edit_target_names.add(name)
                except Exception:
                    continue

        changed_object_names = set()
        edit_geometry_dirty = False
        edit_target_touched = False
        hover_scene_dirty = False
        modifier_dependency_dirty = False
        unknown_data_dirty = False

        # Critical crash guard:
        # Keep this depsgraph callback RNA-light.  Do not read Object.data, do not
        # scan bpy.data.objects for mesh users, and do not force evaluated meshes.
        # Blender can be inside ID deletion / curve-to-mesh / subdivision wrapper
        # rebuilds here; Object.data access can enter C code and crash before a
        # Python try/except can intercept it.
        for up in getattr(depsgraph, 'updates', ()): 
            try:
                upd_id = getattr(up, 'id', None)
                orig = getattr(upd_id, 'original', upd_id)
            except Exception:
                _sos_xform_sig_bump()
                continue

            try:
                is_geo = bool(getattr(up, 'is_updated_geometry', False))
            except Exception:
                is_geo = False
            try:
                is_transform = bool(getattr(up, 'is_updated_transform', False))
            except Exception:
                is_transform = False

            try:
                if isinstance(orig, bpy.types.Object):
                    obj_name = str(getattr(orig, 'name', '') or '')
                    if is_geo or not is_transform:
                        _sos_xform_sig_bump()
                    if is_geo or is_transform:
                        hover_scene_dirty = True
                        modifier_dependency_dirty = True
                    if obj_name and obj_name in edit_target_names:
                        edit_target_touched = True
                        if is_geo:
                            edit_geometry_dirty = True
                    if is_geo:
                        if obj_name:
                            changed_object_names.add(obj_name)
                    else:
                        # Modifier viewport toggles or parameter changes can be
                        # reported as object updates without geometry flags.  Do
                        # not inspect Object.modifiers here; keep the depsgraph
                        # callback free of pointer-property reads and invalidate
                        # conservatively by object name instead.
                        if obj_name and not is_transform:
                            changed_object_names.add(obj_name)
                            modifier_dependency_dirty = True
                    continue
            except Exception:
                _sos_xform_sig_bump()
                continue

            _sos_xform_sig_bump()
            try:
                is_mesh_id = isinstance(orig, bpy.types.Mesh)
            except Exception:
                is_mesh_id = False
            if is_mesh_id:
                if is_geo or not hasattr(up, 'is_updated_geometry'):
                    hover_scene_dirty = True
                    modifier_dependency_dirty = True
                    unknown_data_dirty = True
                    if edit_target_names:
                        edit_target_touched = True
                        edit_geometry_dirty = True
                continue

            try:
                is_lattice_id = _is_lattice_data(orig)
            except Exception:
                is_lattice_id = False
            if is_lattice_id:
                if is_geo or not hasattr(up, 'is_updated_geometry'):
                    hover_scene_dirty = True
                    modifier_dependency_dirty = True
                    unknown_data_dirty = True
                    if edit_target_names:
                        edit_target_touched = True
                        edit_geometry_dirty = True
                continue

            # Curve/font/surface/metaball data can feed evaluated meshes through
            # bevels, geometry nodes, conversions, or object-mode occluders.  Treat
            # these IDs as unknown geometry dependencies without resolving users.
            try:
                id_name = str(getattr(orig, 'name', '') or '')
            except Exception:
                id_name = ''
            try:
                id_rna = str(getattr(getattr(orig, 'bl_rna', None), 'identifier', '') or '')
            except Exception:
                id_rna = ''
            if id_rna in {'Curve', 'Curves', 'SurfaceCurve', 'MetaBall', 'GreasePencil', 'PointCloud'}:
                unknown_data_dirty = True
                hover_scene_dirty = True
                modifier_dependency_dirty = True

        edit_defer_names = set(edit_target_names)
        if changed_object_names and mode_now == 'EDIT_MESH':
            try:
                edit_defer_names.update(str(n) for n in changed_object_names if str(n or ''))
            except Exception:
                pass

        prefs_for_deps = None
        try:
            prefs_for_deps = _prefs(ctx)
        except Exception:
            prefs_for_deps = None
        try:
            unsafe_edit_rebuild = bool(_sos_edit_mesh_mutation_operator_guard_active(ctx))
        except Exception:
            unsafe_edit_rebuild = False
        live_edit_invalidate_now = bool(
            mode_now == 'EDIT_MESH' and edit_target_names and (not unsafe_edit_rebuild)
        )

        if unknown_data_dirty:
            # Unknown Mesh/Lattice/Curve data users cannot be resolved safely in a
            # depsgraph callback.  In Edit Mesh mode, do not clear the last safe
            # batches immediately: a mark seam / clear seam / multi-object edit
            # update can be followed by a redraw while Blender is still rebuilding
            # edit data.  Keep cached batches for a short grace window, then clear
            # and rebuild from stable BMesh data.
            if mode_now == 'EDIT_MESH':
                if live_edit_invalidate_now:
                    _sos_invalidate_edit_mesh_caches_live(edit_defer_names, global_invalidate=True, preserve_evaluated_face_cache=True)
                else:
                    _sos_defer_edit_mesh_cache_rebuild(edit_defer_names, global_invalidate=True)
            else:
                _sos_invalidate_all_overlay_geometry_caches()

        if modifier_dependency_dirty and changed_object_names and not unknown_data_dirty:
            # Known object-only dependency changes can still use the lighter targeted
            # invalidation path.  In Edit Mesh mode, defer the invalidation so the
            # next draw does not force BMesh/evaluated-mesh access during Blender's
            # internal edit-data rebuild.
            if mode_now == 'EDIT_MESH':
                if live_edit_invalidate_now:
                    _sos_invalidate_edit_mesh_caches_live(edit_defer_names or changed_object_names, preserve_evaluated_face_cache=True)
                else:
                    _sos_defer_edit_mesh_cache_rebuild(edit_defer_names or changed_object_names)
            else:
                _invalidate_modifier_dependent_mesh_caches(changed_object_names)

        geometry_dirty = bool(changed_object_names) or bool(modifier_dependency_dirty) or bool(unknown_data_dirty)
        edit_runtime_dirty = bool(edit_target_names and (edit_geometry_dirty or edit_target_touched or modifier_dependency_dirty or unknown_data_dirty))
        if hover_scene_dirty:
            _sos_hover_scene_revision = (_sos_hover_scene_revision + 1) % 1000000000
        if changed_object_names:
            if mode_now == 'EDIT_MESH':
                if live_edit_invalidate_now:
                    _sos_invalidate_edit_mesh_caches_live(edit_defer_names or changed_object_names, preserve_evaluated_face_cache=True)
                else:
                    _sos_defer_edit_mesh_cache_rebuild(edit_defer_names or changed_object_names)
            else:
                for obj_name in changed_object_names:
                    _invalidate_object_cache(obj_name)
        if edit_runtime_dirty:
            # Edit-mode mesh edits are not always marked as is_updated_geometry,
            # but the depsgraph still reports the live edit Object / Mesh IDs.
            # For live transforms we invalidate immediately so the next redraw
            # reads the current BMesh coordinates.  Dangerous topology/attribute
            # rebuild operations still use the short stale-cache safety window.
            if live_edit_invalidate_now:
                _sos_invalidate_edit_mesh_caches_live(edit_defer_names or edit_target_names, preserve_evaluated_face_cache=True)
            else:
                _sos_defer_edit_mesh_cache_rebuild(edit_defer_names or edit_target_names)
                _touch_edit_live_sync(0.45)

        if mode_now in {'OBJECT', 'SCULPT', 'EDIT_LATTICE'}:
            prefs = _prefs(ctx)
            if mode_now == 'SCULPT':
                try:
                    objs = getattr(ctx, "objects_in_mode", None) or [
                        o for o in getattr(ctx, "selected_objects", []) if getattr(o, "mode", None) == 'SCULPT'
                    ]
                except Exception:
                    objs = ()
            elif mode_now == 'EDIT_LATTICE':
                try:
                    objs = getattr(ctx, "objects_in_mode", None) or []
                except Exception:
                    objs = []
                if not objs:
                    try:
                        obj = getattr(ctx, "object", None) or getattr(ctx, "active_object", None)
                        objs = [obj] if obj is not None else []
                    except Exception:
                        objs = []
            else:
                try:
                    objs = getattr(ctx, "selected_objects", [])
                except Exception:
                    objs = []
            curr = set()
            for o in objs:
                try:
                    if o is None:
                        continue
                    obj_type = getattr(o, 'type', None)
                    if obj_type in {'MESH', 'LATTICE', 'CURVE', 'SURFACE', 'FONT', 'META', 'CURVES'}:
                        name = str(getattr(o, 'name', '') or '')
                        if name:
                            curr.add(name)
                except Exception:
                    continue
            if curr != _sos_last_selected_names:
                _sos_last_selected_names, _sos_selection_changed_time = curr, time.time()
                try:
                    d = prefs.hover_delay_sec if prefs else 0.25
                except Exception:
                    d = 0.25
                try:
                    if not bpy.app.timers.is_registered(_delayed_redraw):
                        bpy.app.timers.register(_delayed_redraw, first_interval=d)
                except Exception:
                    pass

        if geometry_dirty or edit_runtime_dirty or (hover_scene_dirty and mode_now in {'OBJECT', 'SCULPT', 'EDIT_LATTICE'}):
            request_overlay_snapshot_rebuild('depsgraph_update', context=ctx, immediate=False)
            try:
                wm = getattr(ctx, 'window_manager', None)
                if wm and (getattr(wm, 'sos_enabled', False) or getattr(wm, 'sos_proportional_overlay_enabled', False) or getattr(wm, 'sos_object_hover_overlay_enabled', False)):
                    tag_view3d_redraw(ctx)
            except Exception:
                pass
    except Exception:
        _sos_xform_sig_bump()

def _delayed_redraw():
    request_overlay_snapshot_rebuild('selection_delay', context=getattr(bpy, 'context', None), immediate=True)
    tag_view3d_redraw()
    return None

# =============================================================================
# Operators
# =============================================================================
class SOS_OT_HoverClickSelect(bpy.types.Operator):
    bl_idname = "view3d.sos_hover_click_select"
    bl_label = "SOS Hover Overlay Click Select"
    bl_description = "Internal selector that makes viewport click selection use the exact object currently receiving the Object / Sculpt hover color, overriding Blender's separate raw click hit test. Shift adds, Ctrl subtracts, and Ctrl+Shift toggles the hovered object."
    bl_options = {'INTERNAL', 'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    @classmethod
    def poll(cls, context):
        try:
            if getattr(getattr(context, 'area', None), 'type', None) != 'VIEW_3D':
                return False
            if str(getattr(context, 'mode', '') or '') not in {'OBJECT', 'SCULPT'}:
                return False
            wm = getattr(context, 'window_manager', None)
            if wm is None:
                return False
            if not bool(getattr(wm, 'sos_object_hover_overlay_enabled', False)):
                return False
            if not bool(getattr(wm, 'sos_object_hover_click_select_enabled', True)):
                return False
            return True
        except Exception:
            return False

    def invoke(self, context, event):
        if not _sos_event_matches_select_mouse(context, event):
            return {'PASS_THROUGH'}
        try:
            value = str(getattr(event, 'value', '') or '')
        except Exception:
            value = ''
        if value == 'CLICK' and _sos_restore_recent_hover_click_outcome(context, event):
            return {'FINISHED'}
        if value not in {'PRESS', 'CLICK'}:
            return {'PASS_THROUGH'}
        obj = object_hover_selection_target(context, event, record_provider_receipt=False)
        if obj is None:
            return {'PASS_THROUGH'}
        if select_object_hover_target_like_click(context, event, obj):
            return {'FINISHED'}
        return {'PASS_THROUGH'}


class SOS_OT_MouseTracker(bpy.types.Operator):
    bl_idname = "view3d.sos_mouse_tracker"
    bl_label = "SOS Mouse Coordinate Bridge"
    bl_description = "Internal pass-through bridge for hover coordinates and actual viewport-operation active ownership."
    bl_options = {'INTERNAL'}

    _window_ptr: int = 0
    _generation: int = 0
    _pending_hover_click = None

    @classmethod
    def poll(cls, context):
        try:
            if not _SOS_ALLOW_RESIDENT_MOUSE_TRACKER or bool(getattr(bpy.app, 'background', False)):
                return False
            if getattr(context, 'window', None) is None:
                return False
            if getattr(getattr(context, 'area', None), 'type', None) != 'VIEW_3D':
                return False
            if getattr(getattr(context, 'region', None), 'type', None) != 'WINDOW':
                return False
            return bool(_sos_modal_tracker_wanted(context))
        except Exception:
            return False

    def _cancel(self):
        pending = getattr(self, '_pending_hover_click', None)
        window_ptr = int(getattr(self, '_window_ptr', 0) or 0)
        current_generation = (
            int(getattr(self, '_generation', 0) or 0)
            == int(_sos_mouse_tracker_modal_generation or 0)
        )
        try:
            if current_generation and _sos_hover_click_latches_by_window.get(window_ptr) is pending:
                _sos_hover_click_latches_by_window.pop(window_ptr, None)
        except Exception:
            pass
        self._pending_hover_click = None
        if current_generation:
            _sos_clear_hover_click_outcome()
        try:
            # A replacement can start before the retiring modal instance receives
            # its generation mismatch. Only the current generation owns the live
            # per-window marker.
            if current_generation:
                _sos_mouse_tracker_modal_windows.discard(window_ptr)
        except Exception:
            pass
        return {'CANCELLED'}

    def cancel(self, context):
        self._cancel()

    def invoke(self, context, event):
        if not self.poll(context):
            return {'CANCELLED'}
        ptr = _sos_pointer(getattr(context, 'window', None))
        if ptr <= 0:
            return {'CANCELLED'}
        if ptr in _sos_mouse_tracker_modal_windows:
            return {'CANCELLED'}
        self._window_ptr = int(ptr)
        self._generation = int(_sos_mouse_tracker_modal_generation or 0)
        self._pending_hover_click = None
        _sos_hover_click_latches_by_window.pop(int(ptr), None)
        _sos_mouse_tracker_modal_windows.add(int(ptr))
        try:
            _sos_update_tracked_mouse_from_event(
                context,
                event,
                update_active_view=_sos_active_view_operation_event(event, context),
            )
        except Exception:
            pass
        try:
            context.window_manager.modal_handler_add(self)
        except Exception:
            _sos_mouse_tracker_modal_windows.discard(int(ptr))
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if int(getattr(self, '_generation', 0) or 0) != int(_sos_mouse_tracker_modal_generation or 0):
            return self._cancel()
        try:
            if _sos_pointer(getattr(context, 'window', None)) != int(getattr(self, '_window_ptr', 0) or 0):
                pending = getattr(self, '_pending_hover_click', None)
                if _sos_hover_click_latches_by_window.get(int(getattr(self, '_window_ptr', 0) or 0)) is pending:
                    _sos_hover_click_latches_by_window.pop(int(getattr(self, '_window_ptr', 0) or 0), None)
                self._pending_hover_click = None
                return {'PASS_THROUGH'}
        except Exception:
            return {'PASS_THROUGH'}

        try:
            event_type = str(getattr(event, 'type', '') or '')
            event_value = str(getattr(event, 'value', '') or '')
        except Exception:
            event_type = ''
            event_value = ''
        if _sos_event_matches_select_mouse(context, event):
            if event_value == 'PRESS':
                # The selection-latch branch returns early, even without hover
                # selection enabled. Record the real click before passing it on.
                _sos_update_tracked_mouse_from_event(context, event, update_active_view=True)
                _sos_clear_hover_click_outcome()
                self._pending_hover_click = _sos_hover_click_press_latch(context, event)
                if self._pending_hover_click is not None:
                    _sos_hover_click_latches_by_window[int(self._window_ptr)] = self._pending_hover_click
                else:
                    _sos_hover_click_latches_by_window.pop(int(self._window_ptr), None)
                return {'PASS_THROUGH'}
            if event_value in {'RELEASE', 'CLICK'}:
                pending = _sos_hover_click_latches_by_window.get(int(self._window_ptr))
                if pending is None:
                    pending = self._pending_hover_click
                self._pending_hover_click = None
                if pending is not None:
                    try:
                        if _sos_consume_hover_click_select_if_needed(context, event, latch=pending):
                            return {'RUNNING_MODAL'}
                    except Exception:
                        pass
                    finally:
                        if _sos_hover_click_latches_by_window.get(int(self._window_ptr)) is pending:
                            _sos_hover_click_latches_by_window.pop(int(self._window_ptr), None)
                elif _sos_consume_hover_click_select_if_needed(context, event):
                    return {'RUNNING_MODAL'}
                elif event_value == 'CLICK':
                    try:
                        if _sos_restore_recent_hover_click_outcome(context, event):
                            return {'RUNNING_MODAL'}
                    except Exception:
                        _sos_clear_hover_click_outcome()
                return {'PASS_THROUGH'}
        is_hover_move = event_type in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}
        if is_hover_move and self._pending_hover_click is not None:
            try:
                start_x, start_y = self._pending_hover_click.get('mouse_window') or (-1000000, -1000000)
                now_x = int(getattr(event, 'mouse_x', -999999))
                now_y = int(getattr(event, 'mouse_y', -999999))
                threshold = _sos_hover_click_drag_threshold(context)
                if abs(now_x - int(start_x)) > threshold or abs(now_y - int(start_y)) > threshold:
                    pending = self._pending_hover_click
                    if _sos_hover_click_latches_by_window.get(int(self._window_ptr)) is pending:
                        _sos_hover_click_latches_by_window.pop(int(self._window_ptr), None)
                    self._pending_hover_click = None
            except Exception:
                pending = self._pending_hover_click
                if _sos_hover_click_latches_by_window.get(int(self._window_ptr)) is pending:
                    _sos_hover_click_latches_by_window.pop(int(self._window_ptr), None)
                self._pending_hover_click = None
        is_operation = _sos_active_view_operation_event(event, context)
        if is_operation and not is_hover_move and self._pending_hover_click is not None:
            pending = self._pending_hover_click
            if _sos_hover_click_latches_by_window.get(int(self._window_ptr)) is pending:
                _sos_hover_click_latches_by_window.pop(int(self._window_ptr), None)
            self._pending_hover_click = None
        if not is_hover_move and not is_operation:
            return {'PASS_THROUGH'}
        if not _sos_modal_tracker_wanted(context):
            return self._cancel()
        try:
            _sos_update_tracked_mouse_from_event(
                context,
                event,
                update_active_view=is_operation,
            )
        except Exception:
            pass
        return {'PASS_THROUGH'}

class SOS_OT_ToggleOverlay(bpy.types.Operator):
    bl_idname = "view3d.sos_toggle_overlay"
    bl_label = T("Toggle Overlay")
    bl_description = T('Toggle the mesh and curve overlay. OFF stops it; ON starts it cleanly. If the overlay is ON but has stopped drawing, the shortcut restarts it without changing the ON state.')
    bl_options = set()
    bl_undo_group = 'Smart Overlay Suite'

    use_target_state: bpy.props.BoolProperty(name="Use Target State", description="Internal: use target_state instead of shortcut recovery/toggle behavior.", default=False, options={'HIDDEN', 'SKIP_SAVE'})
    target_state: bpy.props.BoolProperty(name="Target State", description="Internal explicit ON/OFF state for UI buttons.", default=False, options={'HIDDEN', 'SKIP_SAVE'})

    def execute(self, context):
        global _sos_last_manual_overlay_recovery_time
        try:
            wm = getattr(context, 'window_manager', None)
            current = bool(getattr(wm, 'sos_enabled', False)) if wm is not None else False
            explicit = bool(getattr(self, 'use_target_state', False))
            if explicit:
                target = bool(getattr(self, 'target_state', False))
            elif current:
                if bool(_sos_mesh_curve_overlay_runtime_unhealthy(context)):
                    # When the logical toggle is ON but the draw/runtime layer has
                    # actually failed, keep the visible state ON and rebuild it.
                    # Otherwise this operator must behave as a normal shortcut
                    # toggle and turn the overlay OFF on the first press.
                    target = True
                    _sos_last_manual_overlay_recovery_time = time.time()
                else:
                    target = False
                    _sos_last_manual_overlay_recovery_time = 0.0
            else:
                target = True
                _sos_last_manual_overlay_recovery_time = 0.0
            ok = sos_hard_restart_overlay_runtime(context, target_enabled=target)
        except Exception:
            ok = False
        if not ok:
            return {'CANCELLED'}
        return {'FINISHED'}


classes = (SOS_OT_MouseTracker, SOS_OT_HoverClickSelect, SOS_OT_ToggleOverlay)
CLASSES = classes


def _safe_unregister_class(cls):
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass


def register_classes():
    global _sos_adjacent_edge_gradient_timer_enabled
    for c in classes:
        try:
            from . import undo_support
            undo_support.prepare_operator_class(c)
        except Exception:
            pass
        existing = getattr(bpy.types, getattr(c, '__name__', ''), None)
        if existing is c:
            continue
        if isinstance(existing, type):
            try:
                bpy.utils.unregister_class(existing)
            except Exception:
                pass
        bpy.utils.register_class(c)
    _sos_adjacent_edge_gradient_timer_enabled = False
    try:
        if bpy.app.timers.is_registered(_sos_adjacent_edge_gradient_timer):
            bpy.app.timers.unregister(_sos_adjacent_edge_gradient_timer)
    except Exception:
        pass
    try:
        apply_blender_adjacent_edge_gradient_visibility(bpy.context)
    except Exception:
        pass


def unregister_classes():
    global _sos_adjacent_edge_gradient_timer_enabled
    _sos_adjacent_edge_gradient_timer_enabled = False
    try:
        if bpy.app.timers.is_registered(_sos_adjacent_edge_gradient_timer):
            bpy.app.timers.unregister(_sos_adjacent_edge_gradient_timer)
    except Exception:
        pass
    restore_blender_adjacent_edge_gradient_visibility(bpy.context)
    for c in reversed(classes):
        _safe_unregister_class(c)




def _sos_iter_view3d_modal_overrides(context=None):
    """Yield every live VIEW_3D/WINDOW Region as an independent override.

    Omitting explicit ``space_data``/``region_data`` lets Blender derive the
    exact RegionView3D for each normal or quad-view Region during
    ``temp_override``.
    """
    ctx = context or getattr(bpy, 'context', None)
    windows = []
    try:
        win = getattr(ctx, 'window', None)
        if win is not None:
            windows.append(win)
    except Exception:
        pass
    try:
        wm = getattr(ctx, 'window_manager', None) or getattr(bpy.context, 'window_manager', None)
        for win in getattr(wm, 'windows', ()) or ():
            if win not in windows:
                windows.append(win)
    except Exception:
        pass
    for win in windows:
        try:
            screen = getattr(win, 'screen', None)
        except Exception:
            screen = None
        if screen is None:
            continue
        for area in getattr(screen, 'areas', ()) or ():
            try:
                if getattr(area, 'type', None) != 'VIEW_3D':
                    continue
            except Exception:
                continue
            for region in getattr(area, 'regions', ()) or ():
                try:
                    if getattr(region, 'type', None) != 'WINDOW':
                        continue
                    if int(getattr(region, 'width', 0) or 0) <= 0 or int(getattr(region, 'height', 0) or 0) <= 0:
                        continue
                except Exception:
                    continue
                yield {'window': win, 'screen': screen, 'area': area, 'region': region}

def _sos_modal_tracker_wanted(context=None) -> bool:
    try:
        ctx = context or bpy.context
        wm = getattr(ctx, 'window_manager', None)
        proportional_enabled = bool(getattr(wm, 'sos_proportional_overlay_enabled', False))
        return bool(
            (_sos_runtime_registered or proportional_enabled)
            and _sos_runtime_wants_mouse_tracking(wm, ctx)
        )
    except Exception:
        return False


def _sos_update_tracked_mouse_from_window_coords(context, mouse_x, mouse_y, *, source='timer', window=None) -> bool:
    """Update passive hover coordinates without transferring active-view ownership."""
    global _sos_mouse_window_ptr, _sos_active_region_ptr, _sos_mouse_window_x, _sos_mouse_window_y
    wm = getattr(context, 'window_manager', None)
    if not _sos_runtime_wants_mouse_tracking(wm, context):
        return _sos_clear_tracked_mouse(context, redraw=True)
    try:
        mx = int(mouse_x)
        my = int(mouse_y)
    except Exception:
        return False
    win = window or getattr(context, 'window', None)
    area, region = _sos_find_view3d_window_region_at_window(win, mx, my)
    if region is None:
        # Never let a stale draw callback from another window clear the current
        # active View3D token.  Timer/event sources still clear normally when the
        # cursor leaves the View3D area.
        try:
            prefs = get_effective_settings(context)
            if str(source or '') == 'draw' and bool(getattr(prefs, 'active_view_draw_only', False)) and _sos_active_region_ptr:
                return False
        except Exception:
            pass
        return _sos_clear_tracked_mouse(context, redraw=True)
    window_ptr = _sos_pointer(win)
    region_ptr = _sos_pointer(region)
    try:
        prefs = get_effective_settings(context)
        draw_source = str(source or '') == 'draw'
        if draw_source and bool(getattr(prefs, 'active_view_draw_only', False)) and _sos_active_view_has_multiple_candidates(context):
            # In multi-window/multi-view layouts, draw callbacks are not input
            # ownership signals.  They may refresh the already-active region, but
            # they must not steal active status for a different window/region.
            if _sos_active_region_ptr and _sos_mouse_window_ptr:
                if window_ptr != _sos_mouse_window_ptr or region_ptr != _sos_active_region_ptr:
                    return False
            else:
                return False
    except Exception:
        pass
    changed = (
        _sos_mouse_window_x != mx
        or _sos_mouse_window_y != my
        or _sos_mouse_window_ptr != window_ptr
        or _sos_active_region_ptr != region_ptr
    )
    _sos_mouse_window_x = mx
    _sos_mouse_window_y = my
    _sos_mouse_window_ptr = window_ptr
    _sos_active_region_ptr = region_ptr
    if changed and _sos_hover_snapshot_tracking_enabled(context):
        request_overlay_snapshot_rebuild('passive_hover', context=context, immediate=False)
        _sos_request_mouse_redraw(context, area=area, region=region)
    return changed


def _sos_mouse_probe_timer():
    """Compatibility one-shot; no native mouse polling remains resident."""
    global _sos_mouse_probe_timer_active
    _sos_mouse_probe_timer_active = False
    return None

def _sos_start_mouse_probe_timer() -> bool:
    """Start only the PASS_THROUGH real-input bridge; never a timer."""
    global _sos_mouse_probe_timer_active, _sos_mouse_tracker_bootstrap_pending
    global _sos_mouse_tracker_bootstrap_attempts
    _sos_mouse_probe_timer_active = False
    if not _sos_modal_tracker_wanted(getattr(bpy, 'context', None)):
        return False
    try:
        if _sos_start_mouse_tracker_modal(getattr(bpy, 'context', None)):
            _sos_mouse_tracker_bootstrap_pending = False
            _sos_mouse_tracker_bootstrap_attempts = 0
            return True
    except Exception:
        pass
    # Registration/settings replay can run before Blender accepts modal_handler_add.
    # Retry only a bounded number of event-loop ticks; this is not a resident poll.
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is None:
            return False
        if not timers.is_registered(_sos_mouse_tracker_bootstrap_timer):
            _sos_mouse_tracker_bootstrap_attempts = 0
            _sos_mouse_tracker_bootstrap_pending = True
            timers.register(_sos_mouse_tracker_bootstrap_timer, first_interval=0.01)
        return True
    except Exception:
        _sos_mouse_tracker_bootstrap_pending = False
        _sos_mouse_tracker_bootstrap_attempts = 0
        return False

def _sos_stop_mouse_probe_timer() -> None:
    global _sos_mouse_probe_timer_active
    _sos_mouse_probe_timer_active = False
    try:
        if bpy.app.timers.is_registered(_sos_mouse_probe_timer):
            bpy.app.timers.unregister(_sos_mouse_probe_timer)
    except Exception:
        pass



def _sos_start_mouse_tracker_modal(context=None) -> bool:
    """Start one lightweight real-input bridge per Blender window."""
    if not _SOS_ALLOW_RESIDENT_MOUSE_TRACKER:
        return False
    ctx = context or getattr(bpy, 'context', None)
    if not _sos_modal_tracker_wanted(ctx):
        return False
    started_or_alive = False
    for override in _sos_iter_view3d_modal_overrides(ctx):
        win = override.get('window')
        ptr = _sos_pointer(win)
        if ptr <= 0:
            continue
        if ptr in _sos_mouse_tracker_modal_windows:
            started_or_alive = True
            continue
        try:
            with bpy.context.temp_override(**override):
                result = bpy.ops.view3d.sos_mouse_tracker('INVOKE_DEFAULT')
            if 'RUNNING_MODAL' in result or 'FINISHED' in result:
                started_or_alive = True
        except Exception:
            _sos_mouse_tracker_modal_windows.discard(int(ptr))
    return started_or_alive

def _sos_mouse_tracker_bootstrap_timer():
    """Finite event-loop bootstrap for the real-input bridge."""
    global _sos_mouse_tracker_bootstrap_pending, _sos_mouse_tracker_bootstrap_attempts
    _sos_mouse_tracker_bootstrap_attempts += 1
    try:
        if not _sos_modal_tracker_wanted():
            _sos_mouse_tracker_bootstrap_pending = False
            _sos_mouse_tracker_bootstrap_attempts = 0
            return None
        if _SOS_ALLOW_RESIDENT_MOUSE_TRACKER and _sos_start_mouse_tracker_modal(bpy.context):
            _sos_mouse_tracker_bootstrap_pending = False
            _sos_mouse_tracker_bootstrap_attempts = 0
            return None
    except Exception:
        pass
    if _sos_mouse_tracker_bootstrap_attempts < _SOS_MOUSE_TRACKER_BOOTSTRAP_MAX_ATTEMPTS:
        return 0.05
    _sos_mouse_tracker_bootstrap_pending = False
    _sos_mouse_tracker_bootstrap_attempts = 0
    return None


def _sos_stop_mouse_tracker_modal() -> None:
    """Cancel legacy modal trackers and stop the passive mouse probe."""
    global _sos_mouse_tracker_modal_generation, _sos_mouse_tracker_bootstrap_pending
    global _sos_mouse_tracker_bootstrap_attempts
    try:
        _sos_mouse_tracker_modal_generation += 1
    except Exception:
        _sos_mouse_tracker_modal_generation = 1
    try:
        _sos_mouse_tracker_modal_windows.clear()
    except Exception:
        pass
    _sos_mouse_tracker_bootstrap_pending = False
    _sos_mouse_tracker_bootstrap_attempts = 0
    try:
        if bpy.app.timers.is_registered(_sos_mouse_tracker_bootstrap_timer):
            bpy.app.timers.unregister(_sos_mouse_tracker_bootstrap_timer)
    except Exception:
        pass
    try:
        _sos_stop_mouse_probe_timer()
    except Exception:
        pass


def _sos_consume_hover_click_select_if_needed(context, event, latch=None) -> bool:
    """Override native selection only for a click on the drawn hover target.

    The lightweight resident input bridge calls this for real events.  Strict
    viewport, feature-toggle, mouse-button, event-value, and target checks keep
    all unrelated Blender input on the normal PASS_THROUGH path.
    """
    if not SOS_OT_HoverClickSelect.poll(context):
        return False
    try:
        area, region, _rv3d = _sos_view3d_region_from_event(context, event)
        if area is None or region is None:
            return False
    except Exception:
        return False
    if not _sos_event_matches_select_mouse(context, event):
        return False
    try:
        value = str(getattr(event, 'value', '') or '')
    except Exception:
        value = ''
    if latch is not None:
        if value not in {'RELEASE', 'CLICK'}:
            return False
        return bool(_sos_hover_click_commit_latch(context, event, latch))
    if value == 'CLICK' and _sos_restore_recent_hover_click_outcome(context, event):
        return True
    return False


def _purge_legacy_internal_keymap_items() -> int:
    """Remove stale auto-created internal keymaps from older Smart Overlay builds.

    Only internal, undocumented runtime operators are touched.  Public manual
    shortcut IDs such as view3d.sos_toggle_overlay are never removed.
    """
    removed = 0
    target_ids = {SOS_OT_MouseTracker.bl_idname, SOS_OT_HoverClickSelect.bl_idname}
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        addon_cfg = getattr(getattr(wm, 'keyconfigs', None), 'addon', None)
        if addon_cfg is None:
            return 0
        for km in tuple(getattr(addon_cfg, 'keymaps', ()) or ()):  # tuple: stable during removal
            try:
                items = tuple(getattr(km, 'keymap_items', ()) or ())
            except Exception:
                items = ()
            for kmi in items:
                try:
                    if str(getattr(kmi, 'idname', '') or '') not in target_ids:
                        continue
                except Exception:
                    continue
                try:
                    km.keymap_items.remove(kmi)
                    removed += 1
                except Exception:
                    try:
                        kmi.active = False
                    except Exception:
                        pass
    except Exception:
        pass
    return removed


# Deprecated keymap functions kept as no-op compatibility shims.  They must not
# create or re-enable Preferences > Keymap items.
def _iter_mouse_tracker_keymap_items():
    return ()


def _keymap_item_token(kmi):
    if kmi is None:
        return None
    try:
        return int(kmi.as_pointer())
    except Exception:
        return id(kmi)


def _remove_mouse_tracker_keymaps():
    addon_keymaps.clear()
    try:
        _purge_legacy_internal_keymap_items()
    except Exception:
        pass


def _iter_hover_click_select_keymap_items():
    return ()


def _hover_click_key(kmi):
    try:
        return (
            str(getattr(kmi, 'type', '') or ''),
            str(getattr(kmi, 'value', '') or ''),
            bool(getattr(kmi, 'shift', False)),
            bool(getattr(kmi, 'ctrl', False)),
        )
    except Exception:
        return ('', '', False, False)


def _remove_hover_click_select_keymaps():
    _sos_hover_click_select_keymaps.clear()
    try:
        _purge_legacy_internal_keymap_items()
    except Exception:
        pass


def _register_hover_click_select_keymaps(addon_cfg=None):
    # No automatic Keymap registration.  Hover click override is handled by the
    # passive cursor probe and released when the overlay runtime stops.
    _sos_hover_click_select_keymaps.clear()
    return None


def register_addon_runtime():
    global _draw_handler, _pixel_draw_handler, _sos_runtime_registered, _sos_runtime_started_at
    if _sos_runtime_registered:
        _sos_install_view3d_handlers_if_needed(force=False)
        handlers = getattr(bpy.app.handlers, 'depsgraph_update_post', None)
        if handlers is not None and _sos_depsgraph_update not in handlers:
            handlers.append(_sos_depsgraph_update)
        # Runtime may have been registered before persisted Object-hover state was
        # replayed.  Reconcile the click bridge on every idempotent register so a
        # visible hover can never exist without its real-event consumer.
        try:
            if _sos_modal_tracker_wanted(getattr(bpy, 'context', None)):
                _sos_start_mouse_probe_timer()
            else:
                _sos_stop_mouse_tracker_modal()
        except Exception:
            pass
        request_overlay_snapshot_rebuild('runtime_reregister', context=getattr(bpy, 'context', None), immediate=True)
        return
    _sos_runtime_registered = True
    _sos_runtime_started_at = time.time()
    try:
        _sos_reset_runtime_memory_state(preserve_evaluated_face_cache=True)
    except Exception:
        pass
    _sos_install_view3d_handlers_if_needed(force=False)
    handlers = getattr(bpy.app.handlers, 'depsgraph_update_post', None)
    if handlers is not None and _sos_depsgraph_update not in handlers:
        handlers.append(_sos_depsgraph_update)
    _remove_mouse_tracker_keymaps()
    _remove_hover_click_select_keymaps()
    try:
        _purge_legacy_internal_keymap_items()
    except Exception:
        pass
    try:
        _sos_start_mouse_probe_timer()
    except Exception:
        pass
    try:
        prefs = get_effective_settings(bpy.context)
        if prefs is not None and bool(getattr(prefs, 'active_view_draw_only', False)):
            prime_active_view_draw_context(bpy.context, force=True, source='runtime_start')
    except Exception:
        pass
    request_overlay_snapshot_rebuild('runtime_register', context=getattr(bpy, 'context', None), immediate=True)

def unregister_addon_runtime():
    global _draw_handler, _pixel_draw_handler, _shader, _grad_shader, _dash_shader, _grad_dash_shader, _lattice_pixel_shader, _selected_element_pixel_shader, _post_pixel_polyline_shader, _sos_last_runtime_mode
    global _sos_mouse_redraw_pending, _sos_pending_redraw_area, _sos_pending_redraw_region, _sos_overlay_suppression_last_sig
    global _sos_runtime_registered

    _sos_runtime_registered = False
    _sos_release_front_post_pixel_providers()
    try:
        clear_overlay_snapshots()
    except Exception:
        pass
    try:
        globals()['_sos_runtime_recovery_timer_pending'] = False
        globals()['_sos_runtime_recovery_timer_attempts'] = 0
    except Exception:
        pass
    _sos_stop_runtime_watchdog()
    _sos_stop_edit_transform_live_timer()
    _sos_stop_mouse_tracker_modal()
    _sos_stop_mouse_probe_timer()

    _remove_mouse_tracker_keymaps()
    _remove_hover_click_select_keymaps()
    _sos_last_runtime_mode = ""
    _sos_overlay_suppression_last_sig = None
    _sos_mouse_redraw_pending = False
    _sos_pending_redraw_area = None
    _sos_pending_redraw_region = None
    _sos_clear_tracked_mouse(bpy.context, redraw=True)
    try:
        restore_blender_adjacent_edge_gradient_visibility(bpy.context)
    except Exception:
        pass

    handlers = getattr(bpy.app.handlers, 'depsgraph_update_post', None)
    if handlers is not None:
        try:
            while _sos_depsgraph_update in handlers:
                handlers.remove(_sos_depsgraph_update)
        except Exception:
            pass

    try:
        if bpy.app.timers.is_registered(_delayed_redraw):
            bpy.app.timers.unregister(_delayed_redraw)
    except Exception:
        pass

    _shader = None
    _grad_shader = None
    _dash_shader = None
    _grad_dash_shader = None
    _lattice_pixel_shader = None
    _selected_element_pixel_shader = None
    _post_pixel_polyline_shader = None
    if _draw_handler is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_draw_handler, 'WINDOW')
        except Exception:
            pass
        _draw_handler = None
    if _pixel_draw_handler is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_pixel_draw_handler, 'WINDOW')
        except Exception:
            pass
        _pixel_draw_handler = None
    try:
        _sos_lattice_front_points_by_region.clear()
    except Exception:
        pass
    _sos_base_cache.clear()
    _sos_eval_face_cpu_cache.clear()
    _sos_eval_native_edge_cpu_cache.clear()
    _sos_eval_face_rebuild_queue.clear()
    _SOS_PIXEL_VIS_MEMO.clear()
    _sos_pixel_surface_sync_generations.clear()
    _sos_topology_batch_cache.clear()
    _sos_occluder_batch_cache.clear()
    _sos_occluder_geometry_cache.clear()
    _sos_occluder_group_cache.clear()


def register():
    register_classes()
    register_addon_runtime()


def unregister():
    unregister_addon_runtime()
    unregister_classes()
