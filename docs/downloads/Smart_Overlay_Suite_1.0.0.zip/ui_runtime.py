# SPDX-License-Identifier: GPL-3.0-or-later
"""Remove obsolete Overlay UI only when its exact class is owned by the suite."""

import bpy


_RECEIPTS_KEY = "SMART_OVERLAY_SUITE_CLASS_RECEIPTS_V1"
_ROOT_EDITORS = frozenset((
    "VIEW3D", "IMAGE", "NODE", "SEQUENCER", "CLIP", "DOPESHEET",
    "GRAPH", "NLA", "TEXT", "FILEBROWSER", "SPREADSHEET",
))
_SECTION_PANELS = frozenset(f"VIEW3D_PT_sos_{section}" for section in (
    "occluded_display_mode", "vertex", "edge", "face", "mesh_overlay",
    "hover_optimization", "object_hover", "uv_hover", "hover_overlay",
    "edge_anti_aliasing", "topology_checks", "proportional_overlay", "presets",
    "scene_overrides",
))
_MEASURE_PANELS = frozenset(f"{tool}_PT_{panel}" for tool in ("SMART_MEASURE", "MEASUREIT")
                            for panel in ("Edit", "Conf", "Render", "Main"))
_BUNDLED_PANELS = frozenset((
    "VIEW3D_PT_smart_measure_grid_overlay", "VIEW3D_PT_grid_dimension_overlay",
    "VIEW3D_PT_idv_settings", "VIEW3D_PT_silhouette",
))
_LEGACY_OPERATOR_PREFIX = "SMART_OVERLAY_SUITE_30F9D7"
_OLD_OPERATORS = frozenset(f"{prefix}_OT_integrated_{suffix}"
                           for prefix in (_LEGACY_OPERATOR_PREFIX, f"{_LEGACY_OPERATOR_PREFIX}_SMARTTOOLS")
                           for suffix in ("addon_info", "invoke"))


def _owned_classes():
    value = bpy.app.driver_namespace.get(_RECEIPTS_KEY, ())
    return tuple(cls for cls in value if isinstance(cls, type)) if isinstance(value, (list, tuple)) else ()


def _sos_is_external_manager_panel(cls):
    return (bool(getattr(cls, "_smart_tools_manager_anchor", False))
            or bool(getattr(cls, "_smart_tools_manager_proxy", False))
            or "smart_tools_manager" in cls.__module__.lower())


def _sos_class_is_suite_owned(cls):
    return any(receipt is cls for receipt in _owned_classes())


def _registered_name(cls):
    identity = getattr(getattr(cls, "bl_rna", None), "identifier", "")
    return identity if getattr(bpy.types, identity, None) is cls else ""


def _non_root_category_panel(cls, name):
    editor, separator, panel = name.partition("_PT_")
    return (not (separator and editor in _ROOT_EDITORS and panel == "sos_root")
            and getattr(cls, "bl_region_type", "") == "UI"
            and getattr(cls, "bl_category", "") == "Smart Overlay"
            and not _sos_is_external_manager_panel(cls))


def _try_unregister(cls):
    try:
        bpy.utils.unregister_class(cls)
    except (RuntimeError, ValueError):
        return


def _purge_non_root_smart_overlay_category_panels():
    for cls in _owned_classes():
        if not issubclass(cls, bpy.types.Panel):
            continue
        name = _registered_name(cls)
        if name and _non_root_category_panel(cls, name):
            _try_unregister(cls)


def purge_stale_dynamic_classes():
    for cls in _owned_classes():
        name = _registered_name(cls)
        if not name or _sos_is_external_manager_panel(cls):
            continue
        stale = (name.startswith(("SMART_OVERLAY_PT_INT", "SMARTTOOLS_PT_INT"))
                 or name in _OLD_OPERATORS or name in _SECTION_PANELS
                 or name in _MEASURE_PANELS or name in _BUNDLED_PANELS)
        if stale and issubclass(cls, (bpy.types.Panel, bpy.types.Operator)):
            _try_unregister(cls)
    _purge_non_root_smart_overlay_category_panels()


def register():
    purge_stale_dynamic_classes()


def unregister():
    purge_stale_dynamic_classes()


def refresh_all_suites(context=None):
    purge_stale_dynamic_classes()
