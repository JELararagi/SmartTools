# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Exact-ownership cleanup for Smart Overlay persistent artifacts.

Smart Overlay's normal overlays are transient CPU/GPU snapshots and do not
create persistent proxy datablocks.  This module therefore never infers
ownership from an ID name, prefix, ``users`` count, another Suite's property, or
an all-database scan.  A datablock may be removed only when a receipt created by
this Suite and the datablock's complete ownership tuple match the current
file/session generation exactly.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
import uuid

import bpy

from . import events
from bpy.app.handlers import persistent


_OWNER_STATE_KEY = 'SMART_OVERLAY_SUITE_ARTIFACT_OWNER_V1'
_OWNER_RECEIPTS_KEY = 'SMART_OVERLAY_SUITE_ARTIFACT_RECEIPTS_V1'
_LAST_REPORT_KEY = 'SMART_OVERLAY_SUITE_LAST_PROXY_CLEANUP'
_OWNER_SCHEMA = 1
_SUITE_ID = 'smart_overlay_suite'
_TAG_SUITE = '_sos_suite_id'
_TAG_OWNER_UUID = '_sos_owner_uuid'
_TAG_ARTIFACT_UUID = '_sos_artifact_uuid'
_TAG_SOURCE_UUID = '_sos_source_uuid'
_TAG_FILE_GENERATION = '_sos_file_generation'
_TAG_SESSION_GENERATION = '_sos_session_generation'
_TAG_SCHEMA = '_sos_schema'

_TIMER_ACTIVE = False
_CLEANING = False
_LAST_REPORT: dict[str, Any] = {}


@dataclass
class CleanupReport:
    reason: str = ''
    removed_objects: list[str] = field(default_factory=list)
    removed_meshes: list[str] = field(default_factory=list)
    removed_node_groups: list[str] = field(default_factory=list)
    cleared_object_properties: list[tuple[str, str]] = field(default_factory=list)
    skipped_reason: str = ''

    @property
    def changed(self) -> bool:
        return bool(
            self.removed_objects
            or self.removed_meshes
            or self.removed_node_groups
            or self.cleared_object_properties
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            'reason': self.reason,
            'removed_objects': list(self.removed_objects),
            'removed_meshes': list(self.removed_meshes),
            'removed_node_groups': list(self.removed_node_groups),
            'cleared_object_properties': [list(item) for item in self.cleared_object_properties],
            'skipped_reason': self.skipped_reason,
            'changed': self.changed,
        }


def _namespace() -> dict[str, Any]:
    try:
        ns = bpy.app.driver_namespace
        return ns if isinstance(ns, dict) else {}
    except Exception:
        return {}


def _new_generation_token() -> str:
    return uuid.uuid4().hex


def _owner_state(*, create: bool = False) -> dict[str, Any] | None:
    ns = _namespace()
    state = ns.get(_OWNER_STATE_KEY)
    if isinstance(state, dict):
        return state
    if not create or not ns:
        return None
    state = {
        'suite_id': _SUITE_ID,
        'owner_uuid': _new_generation_token(),
        'file_generation': _new_generation_token(),
        'session_generation': _new_generation_token(),
        'schema': _OWNER_SCHEMA,
    }
    ns[_OWNER_STATE_KEY] = state
    ns[_OWNER_RECEIPTS_KEY] = []
    return state


def _receipts() -> list[dict[str, Any]]:
    receipts = _namespace().get(_OWNER_RECEIPTS_KEY)
    return receipts if isinstance(receipts, list) else []


def _safe_idprop(id_block: Any, key: str, default: Any = None) -> Any:
    try:
        return id_block.get(key, default)
    except Exception:
        return default


def _protected_id(id_block: Any) -> bool:
    try:
        return bool(
            getattr(id_block, 'library', None) is not None
            or getattr(id_block, 'override_library', None) is not None
            or getattr(id_block, 'asset_data', None)
            or getattr(id_block, 'use_fake_user', False)
            or getattr(id_block, 'packed_file', None)
        )
    except (ReferenceError, AttributeError):
        return True
    except Exception:
        return True


def _exact_owned_id(id_block: Any, receipt: dict[str, Any], state: dict[str, Any]) -> bool:
    if id_block is None or _protected_id(id_block):
        return False
    expected = {
        _TAG_SUITE: state.get('suite_id'),
        _TAG_OWNER_UUID: state.get('owner_uuid'),
        _TAG_ARTIFACT_UUID: receipt.get('artifact_uuid'),
        _TAG_SOURCE_UUID: receipt.get('source_uuid'),
        _TAG_FILE_GENERATION: state.get('file_generation'),
        _TAG_SESSION_GENERATION: state.get('session_generation'),
        _TAG_SCHEMA: state.get('schema'),
    }
    if not all(value not in (None, '') for value in expected.values()):
        return False
    return all(_safe_idprop(id_block, key) == value for key, value in expected.items())


def _resolve_receipt(receipt: dict[str, Any]) -> Any:
    kind = str(receipt.get('kind') or '')
    name = str(receipt.get('name') or '')
    collection_name = {
        'OBJECT': 'objects',
        'MESH': 'meshes',
        'NODE_GROUP': 'node_groups',
    }.get(kind)
    if not collection_name or not name:
        return None
    try:
        collection = getattr(bpy.data, collection_name, None)
        return collection.get(name) if collection is not None else None
    except Exception:
        return None


def _id_name(value: Any) -> str:
    try:
        return str(value or '').strip()
    except Exception:
        return ''


def _remove_exact_owned(id_block: Any, kind: str) -> None:
    if kind == 'OBJECT':
        bpy.data.objects.remove(id_block, do_unlink=True)
    elif kind == 'MESH':
        bpy.data.meshes.remove(id_block, do_unlink=True)
    elif kind == 'NODE_GROUP':
        bpy.data.node_groups.remove(id_block, do_unlink=True)
    else:
        raise ValueError(f'Unsupported Smart Overlay artifact kind: {kind}')


def cleanup_stale_proxy_data(
        context: Any | None = None,
        *,
        reason: str = '',
        dry_run: bool = False,
        force: bool = False,
) -> dict[str, Any]:
    """Remove only receipt-backed, exact-owned artifacts.

    ``context`` and ``force`` are retained for public API compatibility.  Neither
    broadens ownership or triggers a ``bpy.data`` scan.
    """
    del context, force
    global _CLEANING, _LAST_REPORT
    report = CleanupReport(reason=reason or 'manual')
    if _CLEANING:
        report.skipped_reason = 'already_cleaning'
        return report.as_dict()

    state = _owner_state(create=False)
    owned = list(_receipts())
    if not state or not owned:
        report.skipped_reason = 'no_exact_owned_receipts'
        _LAST_REPORT = report.as_dict()
        return dict(_LAST_REPORT)

    retained: list[dict[str, Any]] = []
    _CLEANING = True
    try:
        for receipt in owned:
            if not isinstance(receipt, dict):
                continue
            id_block = _resolve_receipt(receipt)
            if id_block is None:
                # Native resource is already absent: idempotent success.
                continue
            if not _exact_owned_id(id_block, receipt, state):
                # A foreign replacement or mismatched generation is never touched.
                retained.append(receipt)
                continue
            kind = str(receipt.get('kind') or '')
            name = _id_name(getattr(id_block, 'name', receipt.get('name', '')))
            if kind == 'OBJECT':
                report.removed_objects.append(name)
            elif kind == 'MESH':
                report.removed_meshes.append(name)
            elif kind == 'NODE_GROUP':
                report.removed_node_groups.append(name)
            else:
                retained.append(receipt)
                continue
            if dry_run:
                retained.append(receipt)
                continue
            try:
                _remove_exact_owned(id_block, kind)
            except Exception:
                retained.append(receipt)
    finally:
        _CLEANING = False

    ns = _namespace()
    if ns:
        ns[_OWNER_RECEIPTS_KEY] = retained
    _LAST_REPORT = report.as_dict()
    try:
        ns[_LAST_REPORT_KEY] = dict(_LAST_REPORT)
    except Exception:
        pass
    return dict(_LAST_REPORT)


def get_last_cleanup_report() -> dict[str, Any]:
    return dict(_LAST_REPORT)


def _cleanup_timer():
    """Compatibility one-shot; no periodic cleanup timer is registered."""
    return None


@persistent
def _cleanup_load_pre(_dummy) -> None:
    """Fence exact receipts before Blender replaces file-bound IDs."""
    ns = _namespace()
    state = _owner_state(create=False)
    if isinstance(state, dict):
        state['file_generation'] = _new_generation_token()
    if ns:
        ns[_OWNER_RECEIPTS_KEY] = []


@persistent
def _cleanup_load_post(_dummy) -> None:
    # Receipt-only cleanup is normally empty after the load_pre fence.
    cleanup_stale_proxy_data(reason='load_post', dry_run=True)


@persistent
def _cleanup_save_pre(_dummy) -> None:
    cleanup_stale_proxy_data(reason='save_pre', dry_run=False)


def _append_handler_once(collection: Any, callback: Any) -> None:
    try:
        if callback not in collection:
            collection.append(callback)
    except Exception:
        pass


def _remove_handler(collection: Any, callback: Any) -> None:
    try:
        while callback in collection:
            collection.remove(callback)
    except Exception:
        pass


def register(context: Any | None = None) -> None:
    """Register event-bound exact cleanup without scanning Blender data."""
    del context
    global _TIMER_ACTIVE
    _owner_state(create=True)
    events.add_hook('load_pre', _cleanup_load_pre)
    events.add_hook('load_post', _cleanup_load_post)
    events.add_hook('save_pre', _cleanup_save_pre)
    _TIMER_ACTIVE = False


def unregister() -> None:
    global _TIMER_ACTIVE
    _TIMER_ACTIVE = False
    try:
        if bpy.app.timers.is_registered(_cleanup_timer):
            bpy.app.timers.unregister(_cleanup_timer)
    except Exception:
        pass
    events.remove_hook('load_pre', _cleanup_load_pre)
    events.remove_hook('load_post', _cleanup_load_post)
    events.remove_hook('save_pre', _cleanup_save_pre)
    cleanup_stale_proxy_data(reason='unregister', dry_run=False)
    ns = _namespace()
    if ns and not _receipts():
        ns.pop(_OWNER_RECEIPTS_KEY, None)
        ns.pop(_OWNER_STATE_KEY, None)
