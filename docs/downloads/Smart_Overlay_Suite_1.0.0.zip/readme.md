# Smart Overlay 1.0.0

Blender 5.1.2 対応。辺を選んで長さの合計を確認したり、UV 編集中に選択やプロポーショナル編集の状態を画面に表示したりできます。操作手順と画面例は [Smart Overlay 解説・ヘルプ](https://jelararagi.github.io/SmartTools/manuals/SmartOverlay/) をご覧ください。

For Blender 5.1.2. Measure the combined length of selected edges and see selection and proportional editing overlays in the UV Editor. See the [Smart Overlay guide](https://jelararagi.github.io/SmartTools/en/manuals/SmartOverlay/) for screenshots and instructions.
