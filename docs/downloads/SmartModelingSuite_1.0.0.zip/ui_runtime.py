# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

import hashlib
import importlib
import textwrap
import time
from typing import Any

import bpy

from . import language as _language, loader as loader, registry as registry
from .bootstrap_common import (
    safe_register_class as _ui_exact_safe_register_class,
    safe_unregister_class as _ui_exact_safe_unregister_class,
)

_REGISTERED_CLASSES: list[type] = []
_UI_RUNTIME_LAST_REDRAW = 0.0
_RECORDS_BY_ALIAS: dict[str, dict[str, Any]] = {}
_SUITE_RECORDS: dict[str, list[dict[str, Any]]] = {}
_NAV_MODULE_CACHE: dict[str, object] = {}
_SUITE_ROOT_PANEL_IDS: dict[str, str] = {}
_ADDON_PANEL_IDS: dict[str, str] = {}
_DYNAMIC_PANEL_CLASSES_BY_ALIAS: dict[str, list[type]] = {}
_OPERATOR_INVOKE_DENYLIST = {'wm.tool_set_by_id'}



class _IdFactory:
    @staticmethod
    def token(*parts: object, size: int = 10) -> str:
        source = '||'.join(str(part or '') for part in parts)
        return hashlib.md5(source.encode('utf-8')).hexdigest()[: max(6, int(size))].upper()

    @staticmethod
    def panel(prefix: str, *parts: object) -> tuple[str, str]:
        token = _IdFactory.token(prefix, *parts)
        class_name = f'SMARTTOOLS_PT_{prefix}_{token}'
        return class_name, class_name


ID_FACTORY = _IdFactory()


def _is_japanese(context=None) -> bool:
    return _language.is_japanese(context)


def _ui_text(text: str, context=None) -> str:
    return _language.ui_text(text, context=context)


def _pick_text(en: str, ja: str, context=None) -> str:
    return _language.pick_text(en, ja, context=context)


_UI_ICON_CACHE: set[str] | None = None

def _valid_ui_icons() -> set[str]:
    global _UI_ICON_CACHE
    if _UI_ICON_CACHE is not None:
        return _UI_ICON_CACHE
    icons: set[str] = set()
    try:
        params = getattr(getattr(bpy.types.UILayout, 'bl_rna', None), 'functions', {}).get('operator').parameters
        icon_param = params.get('icon') if hasattr(params, 'get') else params['icon']
        enum_items = getattr(icon_param, 'enum_items', None)
        if enum_items is not None:
            icons = {str(item.identifier) for item in enum_items if getattr(item, 'identifier', None)}
    except Exception:
        icons = set()
    _UI_ICON_CACHE = icons
    return _UI_ICON_CACHE

def _safe_icon(icon: str, fallback: str = 'TOOL_SETTINGS') -> str:
    icon = str(icon or '').strip() or str(fallback or 'NONE').strip() or 'NONE'
    fallback = str(fallback or 'NONE').strip() or 'NONE'
    valid = _valid_ui_icons()
    if valid:
        if icon in valid:
            return icon
        if fallback in valid:
            return fallback
        if 'NONE' in valid:
            return 'NONE'
    return icon


def _safe_register_class(cls: type) -> bool:
    try:
        _language.sanitize_class_ui(cls)
    except Exception:
        pass
    if not _ui_exact_safe_register_class(cls):
        return False
    if cls not in _REGISTERED_CLASSES:
        _REGISTERED_CLASSES.append(cls)
    return True


def _safe_unregister_class(cls: type) -> None:
    _ui_exact_safe_unregister_class(cls)
    try:
        _REGISTERED_CLASSES.remove(cls)
    except ValueError:
        pass


def _safe_unregister_registered_classes() -> None:
    for alias in list(_DYNAMIC_PANEL_CLASSES_BY_ALIAS.keys()):
        _unregister_alias_dynamic_panels(alias)
    for cls in reversed(_REGISTERED_CLASSES):
        _ui_exact_safe_unregister_class(cls)
    _REGISTERED_CLASSES.clear()
    _SUITE_ROOT_PANEL_IDS.clear()
    _ADDON_PANEL_IDS.clear()
    _DYNAMIC_PANEL_CLASSES_BY_ALIAS.clear()
    _RECORDS_BY_ALIAS.clear()
    _SUITE_RECORDS.clear()


def _tag_redraw_all_regions(*, force: bool = False) -> None:
    global _UI_RUNTIME_LAST_REDRAW
    try:
        now = time.monotonic()
    except Exception:
        now = 0.0
    if not force and now and (now - _UI_RUNTIME_LAST_REDRAW) < 0.16:
        return
    _UI_RUNTIME_LAST_REDRAW = now
    allowed = {'VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR', 'SEQUENCE_EDITOR', 'CLIP_EDITOR', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR', 'TEXT_EDITOR', 'FILE_BROWSER', 'SPREADSHEET'}
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        windows = getattr(wm, 'windows', None) if wm is not None else None
        if not windows:
            return
        for window in windows:
            screen = getattr(window, 'screen', None)
            if screen is None:
                continue
            for area in getattr(screen, 'areas', ()):
                try:
                    if str(getattr(area, 'type', '') or '').upper() in allowed:
                        area.tag_redraw()
                except Exception:
                    pass
    except Exception:
        pass


def _import_nav_module(module_name: str):
    cached = _NAV_MODULE_CACHE.get(module_name)
    if cached is not None:
        return cached
    mod = importlib.import_module(f'.{module_name}', __package__)
    _NAV_MODULE_CACHE[module_name] = mod
    return mod


def suite_is_active(context, suite_key: str) -> bool:
    suite_key = str(suite_key or '').strip()
    module_name = registry.SUITE_META.get(suite_key, ('', ''))[1]
    if not module_name:
        return False
    try:
        nav = _import_nav_module(module_name)
        fn = getattr(nav, 'is_active', None)
        if callable(fn):
            return bool(fn(context, suite_key))
    except Exception:
        pass
    return False


def suite_panel_context(suite_key: str) -> str:
    suite_key = str(suite_key or '').strip()
    module_name = registry.SUITE_META.get(suite_key, ('', ''))[1]
    if not module_name:
        return 'render'
    try:
        nav = _import_nav_module(module_name)
        value = getattr(nav, '_SMART_TOOLS_CONTEXT', 'RENDER')
        return str(value or 'RENDER').lower()
    except Exception:
        return 'render'


def refresh_all_suites(context=None) -> None:
    if context is None:
        context = getattr(bpy, 'context', None)
    for suite_key, (_suite_name, module_name) in registry.SUITE_META.items():
        try:
            nav = _import_nav_module(module_name)
            force_fn = getattr(nav, 'force_runtime_refresh', None)
            if callable(force_fn):
                force_fn()
        except Exception:
            pass
        try:
            nav = _import_nav_module(module_name)
            refresh_fn = getattr(nav, 'refresh_ui_runtime', None)
            if callable(refresh_fn):
                refresh_fn(context=context, addon_key=suite_key, activate_if_properties=False)
        except Exception:
            pass




def _n_panel_category(suite_key: str = '', suite_name: str = '') -> str:
    value = str(suite_name or '').strip()
    if not value:
        try:
            value = str(registry.SUITE_META.get(str(suite_key or ''), ('', ''))[0] or '')
        except Exception:
            value = ''
    if not value:
        value = str(suite_key or '').replace('_suite', '').replace('_', ' ').strip()
    value = value.replace(' Toolset', '').replace(' suite', '').replace('_Toolset', '').replace('_suite', '').strip()
    if value and not value.lower().startswith('smart '):
        value = 'Smart ' + value
    return value or 'Smart Tools'


def _feature_toggle_module():
    try:
        import importlib
    except Exception:
        return None
    package = str(__package__ or __name__ or '').strip('.')
    candidates = []
    if package:
        candidates.append(package)
        if '.' in package:
            candidates.append(package.rsplit('.', 1)[0])
        parts = [part for part in package.split('.') if part]
        if 'user_default' in parts:
            idx = parts.index('user_default')
            if idx + 1 < len(parts):
                candidates.append('.'.join(parts[:idx + 2]))
        elif parts:
            candidates.append(parts[0])
    for base in candidates:
        try:
            return importlib.import_module(f'{base}.feature_toggle')
        except Exception:
            continue
    return None


def _draw_inline_feature_toggles(layout, context, alias: str) -> bool:
    del layout, context, alias
    return False

def _wrap_lines(layout, text: str, width: int = 78, icon: str = 'NONE', context=None) -> None:
    text = _ui_text(str(text or '').strip(), context=context)
    if not text:
        return
    lines = textwrap.wrap(text, width=max(24, int(width))) or [text]
    first = True
    for line in lines:
        if first:
            layout.label(text=line, icon=icon)
            first = False
        else:
            layout.label(text=line)


def _status_text(record: dict, context=None) -> str:
    status = str(record.get('status') or '')
    if status == 'loaded':
        return _pick_text('Loaded', '読み込み済み', context)
    if status == 'available':
        return _pick_text('Not loaded', '未読み込み', context)
    if status == 'loading':
        return _pick_text('Loading', '読み込み中', context)
    if status == 'unsupported_platform':
        return _pick_text('Unsupported platform', '現在の OS・CPU では無効', context)
    if status == 'failed':
        return _pick_text('Load failed', '読み込み失敗', context)
    if status == 'disabled':
        return _pick_text('Superseded or deduplicated', '上位互換または重複のため統合対象外', context)
    return _pick_text(status or 'Unknown', status or '不明', context)


def _addon_help_en(spec: dict) -> str:
    desc = str(spec.get('description') or spec.get('display_name') or '').strip()
    if desc:
        return (
            f'Function: {desc}. How to use: open this entry when you need its settings, then use the migrated child panels or quick buttons below. '
            f'Legacy side panels are hidden and the entry point is now inside Smart Tools.'
        )
    return (
        'Function: This add-on has been migrated into Smart Tools. How to use: open this entry when you need its settings, then use '
        'the migrated child panels or quick buttons below. Legacy side panels are hidden.'
    )


def _addon_help_ja(spec: dict) -> str:
    name = str(spec.get('display_name') or 'Integrated Add-on').strip()
    desc = str(spec.get('description') or '').strip()
    if desc:
        return (
            f'機能: {name} の元機能を Smart Tools 内へ統合しています。内容: {desc}。使い方: 必要な時にこの項目を開き、下のクイックボタン、'
            f'または子パネルを開いて必要な機能を使ってください。旧サイドバーや元パネルは非表示化されています。'
        )
    return (
        f'機能: {name} の元機能を Smart Tools 内へ統合しています。使い方: 必要な時にこの項目を開き、下のクイックボタン、または子パネルを開いて'
        f'必要な機能を使ってください。旧サイドバーや元パネルは非表示化されています。'
    )


def _addon_help_text(spec: dict, context=None) -> str:
    return _pick_text(_addon_help_en(spec), _addon_help_ja(spec), context)


def _target_help_en(kind: str, label: str, desc: str, *, is_pie: bool = False) -> str:
    label = str(label or '').strip() or 'Integrated Tool'
    desc = str(desc or '').strip()
    if kind == 'menu':
        menu_kind = 'pie menu' if is_pie else 'menu'
        return (
            f'Function: opens the migrated {label} {menu_kind} inside Smart Tools. '
            f'How to use: click this button, then choose a command from the opened menu.'
        )
    body = desc or label
    return (
        f'Function: {body}. How to use: click this button to run the migrated command inside Smart Tools. '
        f'Some tools may open additional dialogs or require a valid selection or mode.'
    )


def _target_help_ja(kind: str, label: str, desc: str, *, is_pie: bool = False) -> str:
    label = str(label or '').strip() or '統合ツール'
    desc = str(desc or '').strip()
    if kind == 'menu':
        menu_kind = 'パイメニュー' if is_pie else 'メニュー'
        return (
            f'機能: Smart Tools 内で移植済みの {label} {menu_kind} を開きます。'
            f'使い方: このボタンを押して、表示されたメニューから目的の機能を選んでください。'
        )
    body = desc or label
    return (
        f'機能: {body}。使い方: このボタンを押すと Smart Tools 内の移植コマンドを実行します。'
        f'機能によっては追加ダイアログが開く場合や、選択状態・モードが必要な場合があります。'
    )


def _target_help_text(kind: str, label: str, desc: str, *, is_pie: bool = False, context=None) -> str:
    return _pick_text(_target_help_en(kind, label, desc, is_pie=is_pie), _target_help_ja(kind, label, desc, is_pie=is_pie), context)


def _trace_excerpt(text: str) -> str:
    for line in reversed(str(text or '').splitlines()):
        line = line.strip()
        if line:
            return line[:240]
    return ''


class _SmartToolsPanelDrawShim:
    __slots__ = ('layout', '_panel_cls', 'is_popover')

    def __init__(self, panel_cls, layout):
        self.layout = layout
        self._panel_cls = panel_cls
        self.is_popover = False

    def __getattr__(self, name):
        try:
            return getattr(self._panel_cls, name)
        except Exception as exc:
            raise AttributeError(name) from exc


def _call_draw(draw_fn, panel_cls, layout, context) -> None:
    """Call an original panel draw function through a minimal Python shim.

    Do not copy a registered RNA Panel class dictionary into a dynamic type.
    That older shim could carry descriptors and Blender RNA internals into an
    ordinary Python object and crash during N-panel drawing on Blender 5.1.
    """
    if not callable(draw_fn):
        return
    shim = _SmartToolsPanelDrawShim(panel_cls, layout)
    draw_fn(shim, context)


def _menu_entries(record: dict) -> list[tuple[str, str, bool]]:
    items = []
    seen = set()
    for cls in record.get('menus', ()) or ():
        menu_id = str(getattr(cls, 'bl_idname', '') or '').strip()
        if not menu_id or menu_id in seen:
            continue
        seen.add(menu_id)
        label = _ui_text(str(getattr(cls, 'bl_label', '') or getattr(cls, '__name__', '') or menu_id).strip())
        upper = f'{menu_id} {label} {getattr(cls, "__name__", "")}'.upper()
        is_pie = 'PIE' in upper
        items.append((menu_id, label or menu_id, is_pie))
    items.sort(key=lambda item: item[1].lower())
    return items


def _operator_entries(record: dict) -> list[tuple[str, str, str]]:
    items = []
    seen = set()
    for cls in record.get('operators', ()) or ():
        op_id = str(getattr(cls, 'bl_idname', '') or '').strip()
        if not op_id or op_id in seen or op_id in _OPERATOR_INVOKE_DENYLIST:
            continue
        seen.add(op_id)
        label = _ui_text(str(getattr(cls, 'bl_label', '') or '').strip()) or op_id
        desc = _ui_text(str(getattr(cls, 'bl_description', '') or '').strip())
        items.append((op_id, label, desc))
    items.sort(key=lambda item: (item[1].lower(), item[0].lower()))
    return items


def _quick_entries(record: dict, limit: int = 6) -> list[tuple[str, str, str, str, bool]]:
    quick: list[tuple[str, str, str, str, bool]] = []
    menu_limit = max(1, int(limit) // 2) if limit else 0
    for menu_id, label, is_pie in _menu_entries(record)[:menu_limit]:
        quick.append(('menu', menu_id, label, '', is_pie))
    remaining = max(0, int(limit) - len(quick))
    for op_id, label, desc in _operator_entries(record)[:remaining]:
        quick.append(('operator', op_id, label, desc, False))
    return quick


_COMMAND_ICON_RULES = (
    ('delete remove trash clear purge erase', 'TRASH'),
    ('copy duplicate clone', 'COPYDOWN'),
    ('paste apply transfer', 'PASTEDOWN'),
    ('validate audit inspect check', 'VIEWZOOM'),
    ('restore backup undo back', 'LOOP_BACK'),
    ('connect bridge link split cut knife', 'MOD_EDGESPLIT'),
    ('slide move transform align flow', 'EMPTY_ARROWS'),
    ('crease bevel chamfer fillet', 'MOD_BEVEL'),
    ('normal weighted shade', 'MOD_NORMALEDIT'),
    ('snap merge magnet', 'SNAP_ON'),
    ('curve path rail pipe cable sweep', 'CURVE_DATA'),
    ('annotation grease sketch pencil draw', 'GREASEPENCIL'),
    ('quad retopo fill grid mesh', 'MESH_GRID'),
    ('paint brush', 'BRUSH_DATA'),
    ('shrinkwrap wrap conform project', 'MOD_SHRINKWRAP'),
    ('boolean union difference intersect', 'MOD_BOOLEAN'),
    ('solidify shell thickness', 'MOD_SOLIDIFY'),
    ('modifier stack preset', 'MODIFIER'),
    ('clean repair cad decimate dissolve', 'MOD_DECIM'),
    ('scatter particle random', 'PARTICLES'),
    ('cursor origin pivot workplane', 'PIVOT_CURSOR'),
    ('solo isolate reveal hide show', 'HIDE_OFF'),
)

def _command_icon(target_kind: str, target_id: str, label: str = '', desc: str = '', is_pie: bool = False) -> str:
    if target_kind == 'menu':
        return _safe_icon('PRESET' if is_pie else 'DOWNARROW_HLT', 'MENU_PANEL')
    hay = f'{target_id or ""} {label or ""} {desc or ""}'.replace('_', ' ').replace('.', ' ').lower()
    for words, icon in _COMMAND_ICON_RULES:
        if any(token and token in hay for token in str(words).split()):
            return _safe_icon(icon)
    target_id = str(target_id or '')
    if target_id.startswith('mesh.'):
        return _safe_icon('EDITMODE_HLT')
    if target_id.startswith('object.'):
        return _safe_icon('OUTLINER_OB_MESH')
    if target_id.startswith('curve.'):
        return _safe_icon('CURVE_DATA')
    if target_id.startswith('view3d.'):
        return _safe_icon('VIEW3D')
    return _safe_icon('TOOL_SETTINGS')

def _invoke_operator(layout, *, addon_alias: str, target_kind: str, target_id: str, label: str, desc: str = '', is_pie: bool = False) -> None:
    target_id = str(target_id or '').strip()
    if not target_id or (target_kind == 'operator' and target_id in _OPERATOR_INVOKE_DENYLIST):
        return
    icon = _command_icon(target_kind, target_id, label, desc, is_pie)
    try:
        label = _ui_text(label)
        desc = _ui_text(desc)
        op = layout.operator(SMART_MODELING_SUITE_90F6B1_SMARTTOOLS_OT_integrated_invoke.bl_idname, text=label, icon=icon)
        op.addon_alias = addon_alias
        op.target_kind = target_kind
        op.target_id = target_id
        op.target_label = label
        op.target_desc = desc
        op.is_pie_menu = bool(is_pie)
    except Exception:
        layout.label(text=label)


def _draw_tool_list(layout, record: dict, compact: bool = False) -> None:
    alias = str(record.get('spec', {}).get('alias') or '')
    menus = _menu_entries(record)
    operators = _operator_entries(record)
    if not menus and not operators:
        layout.label(
            text=_pick_text('No direct operator or menu entry was found.', '直接呼び出せるオペレーターやメニューが見つかりませんでした。'),
        )
        return

    if menus:
        box = layout.box()
        box.label(text=_pick_text('Menus', 'メニュー'), icon='MENU_PANEL')
        col = box.column(align=True)
        for menu_id, label, is_pie in menus:
            _invoke_operator(col, addon_alias=alias, target_kind='menu', target_id=menu_id, label=label, is_pie=is_pie)

    if operators:
        box = layout.box()
        box.label(text=_pick_text('Operators', 'オペレーター'), icon='TOOL_SETTINGS')
        flow = box.grid_flow(row_major=True, columns=1 if compact else 2, even_columns=True, even_rows=False, align=True)
        for op_id, label, desc in operators:
            _invoke_operator(flow, addon_alias=alias, target_kind='operator', target_id=op_id, label=label, desc=desc)


def _resolve_operator_callable(op_id: str):
    op_id = str(op_id or '').strip()
    if '.' not in op_id:
        return None
    head, tail = op_id.split('.', 1)
    group = getattr(bpy.ops, head, None)
    if group is None:
        return None
    op = getattr(group, tail, None)
    if not callable(op):
        return None
    get_rna_type = getattr(op, 'get_rna_type', None)
    if not callable(get_rna_type):
        return None
    try:
        get_rna_type()
    except Exception:
        return None
    return op


class SMART_MODELING_SUITE_90F6B1_SMARTTOOLS_OT_integrated_addon_info(bpy.types.Operator):
    bl_idname = 'smart_modeling_suite.integrated_addon_info'
    bl_label = 'Integrated Add-on Info'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    addon_alias: bpy.props.StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def description(cls, _context, properties):
        alias = str(getattr(properties, 'addon_alias', '') or '')
        record = _RECORDS_BY_ALIAS.get(alias, {})
        spec = record.get('spec', {}) if isinstance(record, dict) else {}
        status = _status_text(record, _context) if isinstance(record, dict) else _pick_text('Unknown', '不明', _context)
        note = str(spec.get('note') or '').strip()
        lines = [
            f"{spec.get('display_name', alias)}",
            _addon_help_text(spec, _context),
            f'Status: {status}',
        ]
        if note:
            lines.append(f'Note: {note}')
        return ' '.join(str(line) for line in lines if line)

    def execute(self, _context):
        alias = str(self.addon_alias or '')
        record = _RECORDS_BY_ALIAS.get(alias, {})
        spec = record.get('spec', {}) if isinstance(record, dict) else {}
        status = _status_text(record, _context) if isinstance(record, dict) else _pick_text('Unknown', '不明', _context)
        self.report({'INFO'}, f"{spec.get('display_name', alias)} - {status}")
        return {'FINISHED'}


class SMART_MODELING_SUITE_90F6B1_SMARTTOOLS_OT_integrated_invoke(bpy.types.Operator):
    bl_idname = 'smart_modeling_suite.integrated_invoke'
    bl_label = 'Integrated Tool'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    addon_alias: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_kind: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_id: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_label: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_desc: bpy.props.StringProperty(options={'SKIP_SAVE'})
    is_pie_menu: bpy.props.BoolProperty(default=False, options={'SKIP_SAVE'})

    @classmethod
    def description(cls, _context, properties):
        kind = str(getattr(properties, 'target_kind', '') or '')
        label = str(getattr(properties, 'target_label', '') or '')
        desc = str(getattr(properties, 'target_desc', '') or '')
        is_pie = bool(getattr(properties, 'is_pie_menu', False))
        return _target_help_text(kind, label, desc, is_pie=is_pie, context=_context)

    def execute(self, context):
        alias = str(self.addon_alias or '').strip()
        if alias:
            record = _RECORDS_BY_ALIAS.get(alias, {})
            if str(record.get('status') or '') != 'loaded':
                loader.ensure_loaded(alias)
                _collect_records()
                _register_alias_dynamic_panels(alias)
                try:
                    refresh_all_suites(context)
                except Exception:
                    pass
        kind = str(self.target_kind or '').strip()
        target_id = str(self.target_id or '').strip()
        if not target_id or (kind == 'operator' and target_id in _OPERATOR_INVOKE_DENYLIST):
            self.report({'WARNING'}, _pick_text('This command requires a concrete workspace tool ID and cannot be run as a generic button.', 'このコマンドは具体的なワークスペースツールIDが必要なため、汎用ボタンとしては実行できません。', context))
            return {'CANCELLED'}
        if kind == 'menu':
            try:
                if self.is_pie_menu:
                    return bpy.ops.wm.call_menu_pie(name=target_id)
                return bpy.ops.wm.call_menu(name=target_id)
            except Exception as exc:
                self.report({'ERROR'}, _pick_text('This menu is not available.', 'このメニューは使えません。', context))
                return {'CANCELLED'}

        op_callable = _resolve_operator_callable(target_id)
        if not callable(op_callable):
            self.report({'ERROR'}, _pick_text('This command is not available.', 'このコマンドは使えません。', context))
            return {'CANCELLED'}

        last_error = None
        for args in (('INVOKE_DEFAULT',), tuple()):
            try:
                result = op_callable(*args)
                if isinstance(result, set):
                    return result
                return {'FINISHED'}
            except Exception as exc:
                last_error = exc
        self.report({'ERROR'}, _pick_text('This command could not run. Check the mode and the selection.', 'このコマンドを実行できませんでした。モードと選択を確かめてください。', context))
        return {'CANCELLED'}


def _suite_root_panel_class(suite_key: str, suite_name: str):
    class_name, panel_id = ID_FACTORY.panel('INTROOT', suite_key)
    panel_context = suite_panel_context(suite_key)
    desc_en = 'Lists integrated add-ons migrated into Smart Modeling and explains how to open each migrated section.'
    desc_ja = 'Smart Modeling に移植した統合アドオンの一覧を表示し、各移植セクションの開き方を案内します。'
    _language.register_translation(desc_en, desc_ja)

    @classmethod
    def poll(cls, context):
        area = getattr(context, 'area', None)
        if area is None or getattr(area, 'type', None) != 'VIEW_3D':
            return False
        return suite_is_active(context, suite_key) and bool(_SUITE_RECORDS.get(suite_key))

    def draw(self, context):
        layout = self.layout
        records = _SUITE_RECORDS.get(suite_key, [])
        loaded = sum(1 for item in records if str(item.get('status') or '') == 'loaded')
        standby = sum(1 for item in records if str(item.get('status') or '') == 'available')
        failed = sum(1 for item in records if str(item.get('status') or '') == 'failed')
        total = len(records)
        layout.label(text=_pick_text(f'{loaded}/{total} integrated add-ons are loaded.', f'読み込み済み: {loaded}/{total} 件', context))
        layout.label(text=_pick_text('Integrated tools are grouped in Smart Modeling and are loaded only when their settings or commands are opened.', '統合ツールは Smart Modeling 内で分類され、設定やコマンドを開いた時に読み込まれます。', context))
        if failed:
            layout.label(text=_pick_text(f'{failed} add-ons reported load errors.', f'{failed} 件で読み込みエラーがあります。', context), icon='ERROR')
        layout.label(text=_pick_text('Open an add-on below and use its migrated Smart Tools controls directly.', '下のアドオンを開き、移植済みの Smart Tools コントロールをそのまま使用してください。', context))

    _language.register_translation('Integrated Tools', '統合ツール')
    _language.register_translation(
        'Lists integrated add-ons migrated into Smart Modeling and explains how to open each migrated section.',
        'Smart Modeling に移植した統合アドオンの一覧を表示し、各移植セクションの開き方を案内します。',
    )
    attrs = {
        '__module__': __name__,
        'bl_idname': panel_id,
        'bl_label': 'Integrated Tools',
        'bl_space_type': 'VIEW_3D',
        'bl_region_type': 'UI',
        'bl_category': 'Smart Modeling',
        'bl_options': {'DEFAULT_CLOSED'},
        'bl_description': 'Lists integrated add-ons migrated into Smart Modeling and explains how to open each migrated section.',
        'bl_order': 9500,
        'poll': poll,
        'draw': draw,
        '_smart_suite_host_panel': True,
        '_smart_suite_name': suite_name,
    }
    cls = type(class_name, (bpy.types.Panel,), attrs)
    _SUITE_ROOT_PANEL_IDS[suite_key] = panel_id
    return cls


def _addon_panel_class(record: dict):
    spec = record['spec']
    suite_key = str(spec['suite'])
    alias = str(spec['alias'])
    class_name, panel_id = ID_FACTORY.panel('INTADDON', suite_key, alias)
    parent_id = _SUITE_ROOT_PANEL_IDS[suite_key]
    panel_context = suite_panel_context(suite_key)
    desc_en = 'Lists integrated add-ons migrated into Smart Modeling and explains how to open each migrated section.'
    desc_ja = 'Smart Modeling に移植した統合アドオンの一覧を表示し、各移植セクションの開き方を案内します。'
    _language.register_translation(desc_en, desc_ja)

    @classmethod
    def poll(cls, context):
        area = getattr(context, 'area', None)
        if area is None or getattr(area, 'type', None) != 'VIEW_3D':
            return False
        return suite_is_active(context, suite_key)

    def draw(self, _context):
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False
        status = str(record.get('status') or '')

        row = layout.row(align=True)
        op = row.operator('smart_modeling_suite.integrated_addon_info', text=_pick_text('About', '説明', _context), icon='QUESTION')
        op.addon_alias = alias
        if status in {'unsupported_platform', 'disabled'}:
            row.label(text=_pick_text('Not Loadable', '読み込み不可', _context))
        elif status in {'loading', 'failed'}:
            row.label(text=_status_text(record, _context), icon='TIME' if status == 'loading' else 'ERROR')

        if status in {'loading', 'failed', 'unsupported_platform', 'disabled'}:
            layout.label(text=_status_text(record, _context))

        box = layout.box()
        _wrap_lines(box, _addon_help_text(spec, _context), width=74, icon='NONE', context=_context)


        if status == 'failed':
            excerpt = _trace_excerpt(record.get('error', ''))
            if excerpt:
                warn = layout.box()
                warn.alert = True
                _wrap_lines(warn, _pick_text(f'Load error: {excerpt}', f'読み込みエラー: {excerpt}', _context), width=70, icon='ERROR')
        note = str(spec.get('note') or '').strip()
        if note:
            note_box = layout.box()
            _wrap_lines(note_box, _pick_text(f'Note: {note}', f'メモ: {note}', _context), width=72)

        if status == 'loaded':
            info = layout.row(align=True)
            panels_count = len(record.get('panels', ()) or ())
            operators_count = len(record.get('operators', ()) or ())
            menus_count = len(record.get('menus', ()) or ())
            info.label(text=_pick_text(f"Panels: {panels_count}", f"パネル: {panels_count}", _context))
            info.label(text=_pick_text(f"Operators: {operators_count}", f"オペレーター: {operators_count}", _context))
            info.label(text=_pick_text(f"Menus: {menus_count}", f"メニュー: {menus_count}", _context))

            quick = _quick_entries(record, limit=6)
            if quick:
                quick_box = layout.box()
                quick_box.label(text=_pick_text('Quick Access', 'クイックアクセス', _context), icon='TOOL_SETTINGS')
                col = quick_box.column(align=True)
                for kind, item_id, label, desc, is_pie in quick:
                    _invoke_operator(
                        col,
                        addon_alias=alias,
                        target_kind=kind,
                        target_id=item_id,
                        label=label,
                        desc=desc,
                        is_pie=is_pie,
                    )
        elif status == 'unsupported_platform':
            layout.label(text=_pick_text('This package is bundled, but it is disabled on the current platform.', '同梱済みですが現在の環境では無効です。', _context))
        elif status == 'disabled':
            layout.label(text=_pick_text('This package is intentionally disabled because a duplicate or superseded version was skipped.', '重複または上位互換により無効化されています。', _context))

    attrs = {
        '__module__': __name__,
        'bl_idname': panel_id,
        'bl_label': _language.normalize_text_for_registration(str(spec.get('display_name') or alias)),
        'bl_space_type': 'VIEW_3D',
        'bl_region_type': 'UI',
        'bl_category': 'Smart Modeling',
        'bl_parent_id': parent_id,
        'bl_description': desc_en,
        'bl_options': {'DEFAULT_CLOSED'},
        'poll': poll,
        'draw': draw,
        '_smart_suite_host_panel': True,
    }
    cls = type(class_name, (bpy.types.Panel,), attrs)
    _ADDON_PANEL_IDS[alias] = panel_id
    return cls


def _proxy_panel_class(record: dict, original_panel_cls: type, order_index: int):
    spec = record['spec']
    suite_key = str(spec['suite'])
    alias = str(spec['alias'])
    parent_id = _ADDON_PANEL_IDS[alias]
    class_name, panel_id = ID_FACTORY.panel('INTPROXY', suite_key, alias, getattr(original_panel_cls, '__name__', ''), order_index)
    panel_context = suite_panel_context(suite_key)
    original_label = _language.normalize_text_for_registration(str(getattr(original_panel_cls, 'bl_label', '') or getattr(original_panel_cls, '__name__', '') or panel_id))
    original_desc = _language.normalize_text_for_registration(str(getattr(original_panel_cls, 'bl_description', '') or (str(original_label) + ' migrated panel.')).strip())
    original_draw = getattr(original_panel_cls, 'draw', None)

    @classmethod
    def poll(cls, context):
        area = getattr(context, 'area', None)
        if area is None or getattr(area, 'type', None) != 'VIEW_3D':
            return False
        return suite_is_active(context, suite_key)

    def draw(self, context):
        layout = self.layout
        _draw_inline_feature_toggles(layout, context, alias)
        if not callable(original_draw):
            layout.label(text=_pick_text('Original panel has no draw function.', '元パネルに draw 関数がありません。', context))
            return
        try:
            _call_draw(original_draw, original_panel_cls, layout, context)
        except Exception as exc:
            layout.label(text=_pick_text(f'Proxy draw failed: {exc}', f'プロキシ描画に失敗しました: {exc}', context), icon='ERROR')

    attrs = {
        '__module__': __name__,
        'bl_idname': panel_id,
        'bl_label': original_label,
        'bl_space_type': 'VIEW_3D',
        'bl_region_type': 'UI',
        'bl_category': 'Smart Modeling',
        'bl_parent_id': parent_id,
        'bl_description': original_desc,
        'bl_options': {'DEFAULT_CLOSED'},
        'poll': poll,
        'draw': draw,
        '_smart_suite_host_panel': True,
    }
    return type(class_name, (bpy.types.Panel,), attrs)


def _tool_panel_class(record: dict):
    spec = record['spec']
    suite_key = str(spec['suite'])
    alias = str(spec['alias'])
    parent_id = _ADDON_PANEL_IDS[alias]
    class_name, panel_id = ID_FACTORY.panel('INTTOOLS', suite_key, alias)
    panel_context = suite_panel_context(suite_key)
    desc_en = _addon_help_en(spec)
    desc_ja = _addon_help_ja(spec)
    _language.register_translation(desc_en, desc_ja)
    _language.register_translation('Tools', 'ツール')

    @classmethod
    def poll(cls, context):
        area = getattr(context, 'area', None)
        if area is None or getattr(area, 'type', None) != 'VIEW_3D':
            return False
        return suite_is_active(context, suite_key)

    def draw(self, _context):
        _draw_inline_feature_toggles(self.layout, _context, alias)
        _draw_tool_list(self.layout, record, compact=True)

    attrs = {
        '__module__': __name__,
        'bl_idname': panel_id,
        'bl_label': 'Tools',
        'bl_space_type': 'VIEW_3D',
        'bl_region_type': 'UI',
        'bl_category': 'Smart Modeling',
        'bl_parent_id': parent_id,
        'bl_description': desc_en,
        'bl_options': {'DEFAULT_CLOSED'},
        'poll': poll,
        'draw': draw,
        '_smart_suite_host_panel': True,
    }
    return type(class_name, (bpy.types.Panel,), attrs)


def _unregister_alias_dynamic_panels(alias: str) -> None:
    classes = _DYNAMIC_PANEL_CLASSES_BY_ALIAS.pop(str(alias or '').strip(), [])
    for cls in reversed(classes):
        _safe_unregister_class(cls)


def _register_alias_dynamic_panels(alias: str) -> None:
    """Do not register extra proxy panels for integrated add-ons.

    The standard Smart Modeling N-panel hosts all integrated controls inside the
    single suite panel.  Registering additional proxy Panel classes increases
    panel_draw callbacks and can expose Blender to stale RNA panel classes after
    dynamic reloads.  Existing proxies for the alias are removed defensively.
    """
    alias = str(alias or '').strip()
    if alias:
        _unregister_alias_dynamic_panels(alias)
    return None


def _collect_records() -> None:
    _RECORDS_BY_ALIAS.clear()
    _SUITE_RECORDS.clear()
    for record in loader.get_records():
        spec = record.get('spec') or {}
        alias = str(spec.get('alias') or '')
        suite_key = str(spec.get('suite') or '')
        if alias:
            _RECORDS_BY_ALIAS[alias] = record
        if suite_key:
            _SUITE_RECORDS.setdefault(suite_key, []).append(record)


_STATIC_OPERATOR_CLASSES = (
    SMART_MODELING_SUITE_90F6B1_SMARTTOOLS_OT_integrated_addon_info,
    SMART_MODELING_SUITE_90F6B1_SMARTTOOLS_OT_integrated_invoke,
)


def register() -> None:
    # The visible UI is provided by core as a normal VIEW_3D/UI panel, so no
    # dynamic Panel classes are registered here.  The two lightweight command
    # owners below are still required because the core panel calls them for
    # About/Quick Access buttons.  Keeping them registered prevents a visible
    # button from resolving to an unknown operator while preserving lazy tool
    # loading and zero idle runtime.
    _safe_unregister_registered_classes()
    for cls in _STATIC_OPERATOR_CLASSES:
        _safe_register_class(cls)
    _collect_records()
    _tag_redraw_all_regions()


def unregister() -> None:
    _safe_unregister_registered_classes()
