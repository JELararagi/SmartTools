# -*- coding: utf-8 -*-
# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi. All Rights Reserved.
#
#  Blender Extension / user_default compatible package
# ------------------------------------------------------------------------------

bl_info = {
    "name": "Mesh Split",
    "author": "JELararagi",
    "version": (1, 0, 2),
    "blender": (5, 1, 0),
    "location": "Edit Mode > Mesh Split",
    "description": "Split or break the current mesh selection according to Vertex / Edge / Face selection mode.",
    "category": "Mesh",
}

import bpy
import bmesh

try:
    from . import undo_bridge as _split_undo_bridge
except Exception:
    _split_undo_bridge = None

try:
    from ..edit_multi import edit_mesh_objects as _sms_edit_mesh_objects
except Exception:
    _sms_edit_mesh_objects = None

translation_dict = {
    "ja_JP": {
        ("*", "Mesh Split"): "メッシュ分割",
        ("*", "Split or break the current mesh selection according to Vertex / Edge / Face selection mode."): '頂点 / 辺 / 面の選択モードに応じて今の選択を分割します。',
        ("*", "Break selected vertices by splitting every connected selected vertex edge."): "選択頂点につながる辺を分離して、頂点をブレイクします。",
        ("*", "No editable mesh was found."): "編集可能なメッシュが見つかりません。",
        ("*", "No vertices are selected."): "頂点が選択されていません。",
        ("*", "No edges are selected."): "辺が選択されていません。",
        ("*", "No faces are selected."): "面が選択されていません。",
        ("*", "Vertices were broken."): "頂点をブレイクしました。",
        ("*", "Edges were split."): "辺を分離しました。",
        ("*", "Faces were split."): "面を分離しました。",
        ("*", "Mesh Split failed safely."): "メッシュ分割は安全に中止されました。",
    }
}


def _tr(text):
    try:
        return bpy.app.translations.pgettext(str(text))
    except Exception:
        return str(text)



def _edit_mesh_objects(context):
    if callable(_sms_edit_mesh_objects):
        try:
            return list(_sms_edit_mesh_objects(context, unique_data=True))
        except Exception:
            pass
    objects = []
    try:
        for obj in tuple(getattr(context, 'objects_in_mode_unique_data', None) or getattr(context, 'objects_in_mode', None) or ()):  # multi-object edit mode
            if obj is not None and getattr(obj, "type", None) == "MESH" and getattr(obj, "mode", "") == "EDIT" and obj not in objects:
                objects.append(obj)
    except Exception:
        pass
    if objects:
        return objects
    try:
        obj = getattr(context, "edit_object", None) or getattr(context, "active_object", None)
        if obj is not None and getattr(obj, "type", None) == "MESH" and getattr(context, "mode", "") == "EDIT_MESH":
            objects.append(obj)
    except Exception:
        pass
    return objects


def _active_edit_mesh(context):
    objects = _edit_mesh_objects(context)
    if not objects:
        return None
    try:
        active = getattr(context, "active_object", None)
        if active in objects:
            return active
    except Exception:
        pass
    return objects[0]


def _is_valid_element(element) -> bool:
    try:
        if not bool(getattr(element, "is_valid", True)):
            return False
        if bool(getattr(element, "hide", False)):
            return False
        return True
    except Exception:
        return False


def _is_selected(element) -> bool:
    try:
        return _is_valid_element(element) and bool(getattr(element, "select", False))
    except Exception:
        return False


def _safe_update_edit_mesh(mesh, *, destructive=True) -> None:
    try:
        bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=bool(destructive))
    except TypeError:
        try:
            bmesh.update_edit_mesh(mesh, False, bool(destructive))
        except Exception:
            pass
    except Exception:
        pass


def _flush_selection(bm) -> None:
    try:
        bm.select_flush_mode()
    except Exception:
        try:
            bm.select_flush(True)
        except Exception:
            pass


def _selected_faces(bm):
    try:
        bm.faces.ensure_lookup_table()
    except Exception:
        pass
    faces = []
    try:
        for face in bm.faces:
            if _is_selected(face):
                faces.append(face)
    except Exception:
        return []
    return faces


def _selected_edges(bm):
    try:
        bm.edges.ensure_lookup_table()
    except Exception:
        pass
    edges = []
    try:
        for edge in bm.edges:
            if _is_selected(edge):
                edges.append(edge)
    except Exception:
        return []
    return edges


def _selected_vertices(bm):
    try:
        bm.verts.ensure_lookup_table()
    except Exception:
        pass
    verts = []
    try:
        for vert in bm.verts:
            if _is_selected(vert):
                verts.append(vert)
    except Exception:
        return []
    return verts


def _unique_valid_edges(edges):
    result = []
    seen = set()
    for edge in edges or []:
        if not _is_valid_element(edge):
            continue
        key = id(edge)
        if key in seen:
            continue
        seen.add(key)
        result.append(edge)
    return result


def _edges_from_vertices(verts):
    edges = []
    seen = set()
    for vert in verts or []:
        if not _is_valid_element(vert):
            continue
        try:
            linked = list(vert.link_edges)
        except Exception:
            linked = []
        for edge in linked:
            if not _is_valid_element(edge):
                continue
            key = id(edge)
            if key in seen:
                continue
            seen.add(key)
            edges.append(edge)
    return edges


def _split_edges_bmesh(bm, edges):
    edges = _unique_valid_edges(edges)
    if not edges:
        return False
    # Keep the operation single-step and avoid bpy.ops.mesh.edge_split().
    # Blender 5.1.0 Windows can crash after nested native mesh operators when
    # storing last-operator properties. bmesh.ops avoids that RNA path entirely.
    result_edges = []
    try:
        result = bmesh.ops.split_edges(bm, edges=edges)
        result_edges = [e for e in result.get("edges", []) if _is_valid_element(e)] if isinstance(result, dict) else []
    except Exception:
        return False
    try:
        for edge in bm.edges:
            if _is_valid_element(edge):
                edge.select_set(False)
        for edge in edges:
            if _is_valid_element(edge):
                edge.select_set(True)
        for edge in result_edges:
            if _is_valid_element(edge):
                edge.select_set(True)
    except Exception:
        pass
    _flush_selection(bm)
    return True


def _split_faces_bmesh(bm, faces):
    faces = [face for face in faces or [] if _is_valid_element(face)]
    if not faces:
        return False
    try:
        result = bmesh.ops.split(bm, geom=faces, use_only_faces=True)
    except Exception:
        return False
    result_geom = []
    if isinstance(result, dict):
        try:
            result_geom = list(result.get("geom", []) or [])
        except Exception:
            result_geom = []
    try:
        for face in bm.faces:
            if _is_valid_element(face):
                face.select_set(False)
        for face in faces:
            if _is_valid_element(face):
                face.select_set(True)
        for elem in result_geom:
            if _is_valid_element(elem) and hasattr(elem, "select_set"):
                try:
                    elem.select_set(True)
                except Exception:
                    pass
    except Exception:
        pass
    _flush_selection(bm)
    return True



def _topology_counts(bm):
    """Return a constant-time topology fingerprint for split change detection."""
    try:
        return (len(bm.verts), len(bm.edges), len(bm.faces))
    except Exception:
        return (-1, -1, -1)


def _capture_selection_state(bm):
    """Capture exact BMesh selection/history so a no-op stays side-effect free."""
    try:
        return {
            "verts": tuple(v for v in bm.verts if _is_valid_element(v) and v.select),
            "edges": tuple(e for e in bm.edges if _is_valid_element(e) and e.select),
            "faces": tuple(f for f in bm.faces if _is_valid_element(f) and f.select),
            "history": tuple(elem for elem in bm.select_history if _is_valid_element(elem)),
            "active_face": getattr(bm.faces, "active", None),
        }
    except Exception:
        return {"verts": (), "edges": (), "faces": (), "history": (), "active_face": None}


def _restore_selection_state(bm, state) -> None:
    try:
        for face in bm.faces:
            if _is_valid_element(face):
                face.select_set(False)
        for edge in bm.edges:
            if _is_valid_element(edge):
                edge.select_set(False)
        for vert in bm.verts:
            if _is_valid_element(vert):
                vert.select_set(False)
        for vert in state.get("verts", ()):
            if _is_valid_element(vert):
                vert.select_set(True)
        for edge in state.get("edges", ()):
            if _is_valid_element(edge):
                edge.select_set(True)
        for face in state.get("faces", ()):
            if _is_valid_element(face):
                face.select_set(True)
        bm.select_history.clear()
        for elem in state.get("history", ()):
            if _is_valid_element(elem):
                try:
                    bm.select_history.add(elem)
                except Exception:
                    pass
        active = state.get("active_face")
        if active is None or _is_valid_element(active):
            try:
                bm.faces.active = active
            except Exception:
                pass
    except Exception:
        pass




def _can_split_bmesh(bm, select_mode) -> bool:
    """Return whether the current selection can produce a topology change.

    The check runs before the undo transaction starts so a repeated no-op does
    not create an empty history entry.  It intentionally uses only local
    topology and performs no mutation.
    """
    if bm is None:
        return False
    try:
        mode = tuple(bool(v) for v in select_mode)
    except Exception:
        mode = (True, False, False)
    if len(mode) < 3:
        mode = tuple(list(mode) + [False, False, False])[:3]

    def face_candidate() -> bool:
        selected = set(_selected_faces(bm))
        if not selected:
            return False
        for face in selected:
            for edge in tuple(getattr(face, "edges", ()) or ()):
                try:
                    if any(other not in selected for other in edge.link_faces):
                        return True
                except Exception:
                    continue
        return False

    def edge_candidate(edges=None) -> bool:
        for edge in tuple(edges if edges is not None else _selected_edges(bm)):
            if not _is_valid_element(edge):
                continue
            try:
                if len(edge.link_faces) >= 2:
                    return True
            except Exception:
                continue
        return False

    def vertex_candidate() -> bool:
        verts = _selected_vertices(bm)
        if not verts:
            return False
        edges = _edges_from_vertices(verts)
        if edge_candidate(edges):
            return True
        # A loose/non-manifold vertex can still be broken when multiple selected
        # incident edges belong to distinct local fans.  Require at least two
        # valid incident edges so an isolated endpoint remains a true no-op.
        for vert in verts:
            try:
                if sum(1 for edge in vert.link_edges if _is_valid_element(edge)) >= 2:
                    return True
            except Exception:
                continue
        return False

    only_vert = mode[0] and not mode[1] and not mode[2]
    only_edge = mode[1] and not mode[2]
    if mode[2] and face_candidate():
        return True
    if only_edge or mode[1]:
        if edge_candidate():
            return True
    if only_vert or mode[0]:
        if vertex_candidate():
            return True
    return False


def _can_split_object(obj, select_mode) -> bool:
    mesh = getattr(obj, "data", None)
    bm = _get_bmesh(mesh)
    return _can_split_bmesh(bm, select_mode)


def _get_bmesh(mesh):
    try:
        bm = bmesh.from_edit_mesh(mesh)
    except Exception:
        return None
    try:
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
    except Exception:
        pass
    return bm


def _apply_split_to_object(obj, select_mode) -> bool:
    mesh = getattr(obj, "data", None)
    bm = _get_bmesh(mesh)
    if bm is None:
        return False

    if len(select_mode) < 3:
        select_mode = tuple(list(select_mode) + [False, False, False])[:3]

    is_vert = bool(select_mode[0]) and not bool(select_mode[1]) and not bool(select_mode[2])
    is_edge = bool(select_mode[1]) and not bool(select_mode[2])
    is_face = bool(select_mode[2])
    before_counts = _topology_counts(bm)
    before_selection = _capture_selection_state(bm)
    operation_succeeded = False

    try:
        if is_face:
            faces = _selected_faces(bm)
            operation_succeeded = bool(faces and _split_faces_bmesh(bm, faces))
        elif is_edge:
            edges = _selected_edges(bm)
            operation_succeeded = bool(edges and _split_edges_bmesh(bm, edges))
        elif is_vert:
            verts = _selected_vertices(bm)
            edges = _edges_from_vertices(verts)
            operation_succeeded = bool(edges and _split_edges_bmesh(bm, edges))
        else:
            # Mixed selection modes default to the most destructive available
            # mode in this order: Face > Edge > Vertex.
            if bool(select_mode[2]):
                faces = _selected_faces(bm)
                operation_succeeded = bool(faces and _split_faces_bmesh(bm, faces))
            if not operation_succeeded and bool(select_mode[1]):
                edges = _selected_edges(bm)
                operation_succeeded = bool(edges and _split_edges_bmesh(bm, edges))
            if not operation_succeeded and bool(select_mode[0]):
                verts = _selected_vertices(bm)
                edges = _edges_from_vertices(verts)
                operation_succeeded = bool(edges and _split_edges_bmesh(bm, edges))
    except Exception:
        operation_succeeded = False

    changed = operation_succeeded and _topology_counts(bm) != before_counts
    if changed:
        _safe_update_edit_mesh(mesh, destructive=True)
        return True

    # A native BMesh split may report a result even when the selected elements
    # are already fully separated.  Restore the exact click-before selection and
    # treat the operation as a no-op so repeated clicks do not add empty undo
    # entries or alter the active selection history.
    _restore_selection_state(bm, before_selection)
    try:
        _safe_update_edit_mesh(mesh, destructive=False)
    except Exception:
        pass
    return False


class MESH_OT_smart_split(bpy.types.Operator):
    """Split or break the current mesh selection according to Vertex / Edge / Face selection mode."""
    bl_idname = "mesh.smart_split"
    bl_label = "Mesh Split"
    bl_description = "Split or break the current mesh selection according to Vertex / Edge / Face selection mode."
    # Intentionally omit REGISTER. The tool has no redo parameters, and avoiding
    # last-operator-property storage removes a Blender 5.1.0 Windows crash path.
    bl_options = set()
    _sms_no_undo = True

    @classmethod
    def poll(cls, context):
        return _active_edit_mesh(context) is not None

    def execute(self, context):
        objects = _edit_mesh_objects(context)
        if not objects:
            return {'CANCELLED'}

        try:
            raw_mode = getattr(context.tool_settings, "mesh_select_mode", (True, False, False))
            select_mode = tuple(bool(v) for v in raw_mode)
        except Exception:
            select_mode = (True, False, False)
        if len(select_mode) < 3:
            select_mode = tuple(list(select_mode) + [False, False, False])[:3]

        # Reject a true no-op before the bridge creates the click-before
        # baseline.  This keeps repeated use on an already separated selection
        # from adding an empty Undo entry.
        if not any(_can_split_object(obj, select_mode) for obj in objects):
            return {'CANCELLED'}

        transaction = None
        if _split_undo_bridge is not None:
            try:
                transaction = _split_undo_bridge.begin(context)
            except Exception:
                transaction = None
        if transaction is None:
            return {'CANCELLED'}

        changed = False
        for obj in objects:
            try:
                if _apply_split_to_object(obj, select_mode):
                    changed = True
            except Exception:
                continue

        if not changed:
            try:
                _split_undo_bridge.rollback(transaction)
            except Exception:
                pass
            return {'CANCELLED'}

        try:
            committed = bool(_split_undo_bridge.commit(transaction, context))
        except Exception:
            committed = False
        if not committed:
            # Geometry has changed but no valid directional history entry was
            # created.  Roll back the bridge metadata and report cancellation
            # rather than adding an incomplete automatic Undo boundary.
            try:
                _split_undo_bridge.rollback(transaction)
            except Exception:
                pass
            return {'CANCELLED'}
        return {'FINISHED'}

def execute_mesh_split(context=None, invoke=False):
    context = context or getattr(bpy, 'context', None)
    if context is None:
        return {'CANCELLED'}
    try:
        if invoke:
            return bpy.ops.mesh.smart_split('INVOKE_DEFAULT')
        return bpy.ops.mesh.smart_split('EXEC_DEFAULT')
    except Exception:
        return {'CANCELLED'}


classes = (
    MESH_OT_smart_split,
)


def register():
    try:
        bpy.app.translations.register(__name__, translation_dict)
    except ValueError:
        try:
            bpy.app.translations.unregister(__name__)
        except Exception:
            pass
        try:
            bpy.app.translations.register(__name__, translation_dict)
        except Exception:
            pass
    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except ValueError:
            pass


def unregister():
    if _split_undo_bridge is not None:
        try:
            _split_undo_bridge.shutdown()
        except Exception:
            pass
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass
