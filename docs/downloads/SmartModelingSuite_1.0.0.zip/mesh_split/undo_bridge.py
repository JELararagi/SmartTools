# -*- coding: utf-8 -*-
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

"""Directional Edit-Mesh Undo bridge for Mesh Split.

Mesh Split performs a direct BMesh topology mutation.  Blender's automatic edit-mode UNDO does not reliably preserve the live click-before
selection when lazy wrappers or non-undo selection setup precede the click.
This bridge records one explicit post-change state per click and restores the
exact directional selection snapshot for Undo and Redo.

A naive pair of ``undo_push`` calls (before and after each split) creates an
extra visible step between consecutive splits.  This bridge records only one
post-change state per click and stores a private BMesh token.  Undo/Redo event
handlers restore the *directional* selection snapshot for that exact click:

* Undo token N -> N-1 applies operation N's ``before`` selection.
* Redo token N-1 -> N applies operation N's ``after`` selection.

The private token layer is removed before saving, restored only in memory after
the save, and removed during full Smart Modeling shutdown.  The bridge uses no
polling timer, frame handler, draw handler, key monitor, or background thread.
"""

from __future__ import annotations

from collections import Counter
import secrets

import bmesh
import bpy


_NS_KEY = "SMART_MODELING_MESH_SPLIT_UNDO_BRIDGE"
_LAYER_PREFIX = ".jel_sms_mesh_split_undo_"
_HANDLER_NAMES = {
    "_undo_post",
    "_redo_post",
    "_load_pre",
    "_save_pre",
    "_save_post",
    "_save_post_fail",
}
_MAX_OPERATIONS = 2048
_MAX_TOKEN = 2_000_000_000


def _id_uid(id_data) -> int:
    try:
        return int(getattr(id_data, "session_uid", 0) or 0)
    except Exception:
        return 0


def _state(create: bool = True):
    try:
        namespace = bpy.app.driver_namespace
    except Exception:
        return None
    state = namespace.get(_NS_KEY)
    if not isinstance(state, dict):
        if not create:
            return None
        state = {
            "layer_name": f"{_LAYER_PREFIX}{secrets.token_hex(6)}",
            "next_token": 1,
            "current_token": 0,
            "operations": {},
            "order": [],
            "meshes": {},
            "save_restore": [],
            "syncing": False,
            "shutdown": False,
            "shutdown_callback": shutdown,
        }
        namespace[_NS_KEY] = state
    layer_name = str(state.get("layer_name") or "")
    if not layer_name.startswith(_LAYER_PREFIX):
        state["layer_name"] = f"{_LAYER_PREFIX}{secrets.token_hex(6)}"
    state.setdefault("next_token", 1)
    state.setdefault("current_token", 0)
    state.setdefault("operations", {})
    state.setdefault("order", [])
    state.setdefault("meshes", {})
    state.setdefault("save_restore", [])
    state.setdefault("syncing", False)
    state.setdefault("shutdown", False)
    state["shutdown_callback"] = shutdown
    return state


def _layer_name() -> str:
    state = _state(True)
    return str(state.get("layer_name") or "") if state else ""


def _mesh_key(mesh) -> str:
    return f"{_id_uid(mesh)}:{str(getattr(mesh, 'name_full', '') or getattr(mesh, 'name', '') or '')}"


def _mesh_record(mesh) -> dict:
    return {
        "name": str(getattr(mesh, "name_full", "") or getattr(mesh, "name", "") or ""),
        "uid": _id_uid(mesh),
    }


def _object_record(obj) -> dict:
    return {
        "name": str(getattr(obj, "name_full", "") or getattr(obj, "name", "") or ""),
        "uid": _id_uid(obj),
    }


def _resolve_mesh(record):
    if not isinstance(record, dict):
        return None
    name = str(record.get("name") or "")
    uid = int(record.get("uid") or 0)
    mesh = bpy.data.meshes.get(name) if name else None
    if mesh is not None and (not uid or _id_uid(mesh) == uid):
        return mesh
    if uid:
        for candidate in bpy.data.meshes:
            if _id_uid(candidate) == uid:
                record["name"] = str(candidate.name)
                return candidate
    return mesh


def _resolve_object(record):
    if not isinstance(record, dict):
        return None
    name = str(record.get("name") or "")
    uid = int(record.get("uid") or 0)
    obj = bpy.data.objects.get(name) if name else None
    if obj is not None and (not uid or _id_uid(obj) == uid):
        return obj
    if uid:
        for candidate in bpy.data.objects:
            if _id_uid(candidate) == uid:
                record["name"] = str(candidate.name)
                return candidate
    return obj


def _mesh_entry(mesh, create: bool = True):
    state = _state(create)
    if state is None:
        return None
    key = _mesh_key(mesh)
    entry = state["meshes"].get(key)
    if not isinstance(entry, dict):
        if not create:
            uid = _id_uid(mesh)
            for old_key, candidate in tuple(state["meshes"].items()):
                if uid and int(candidate.get("uid") or 0) == uid:
                    entry = candidate
                    if old_key != key:
                        state["meshes"].pop(old_key, None)
                        state["meshes"][key] = entry
                    break
        if not isinstance(entry, dict):
            if not create:
                return None
            entry = {
                "name": str(mesh.name),
                "uid": _id_uid(mesh),
                "baseline_ready": False,
                "known_tokens": set(),
                "last_token": 0,
            }
            state["meshes"][key] = entry
    entry["name"] = str(mesh.name)
    entry["uid"] = _id_uid(mesh)
    entry.setdefault("baseline_ready", False)
    entry.setdefault("known_tokens", set())
    entry.setdefault("last_token", 0)
    return entry


def _is_handler(function) -> bool:
    try:
        module_name = str(getattr(function, "__module__", "") or "")
        function_name = str(getattr(function, "__name__", "") or "")
    except Exception:
        return False
    return module_name.endswith(".mesh_split.undo_bridge") and function_name in _HANDLER_NAMES


def ensure() -> bool:
    state = _state(True)
    if state is None:
        return False
    state["shutdown"] = False
    for collection, current in (
        (bpy.app.handlers.undo_post, _undo_post),
        (bpy.app.handlers.redo_post, _redo_post),
        (bpy.app.handlers.load_pre, _load_pre),
        (bpy.app.handlers.save_pre, _save_pre),
        (bpy.app.handlers.save_post, _save_post),
        (bpy.app.handlers.save_post_fail, _save_post_fail),
    ):
        for function in tuple(collection):
            if function is current:
                continue
            if _is_handler(function):
                try:
                    collection.remove(function)
                except Exception:
                    pass
        if current not in collection:
            collection.append(current)
    return True


def _next_token() -> int:
    state = _state(True)
    if state is None:
        return 0
    token = int(state.get("next_token") or 1)
    if token <= 0 or token > _MAX_TOKEN:
        token = 1
    state["next_token"] = token + 1
    return token


def _domain_layer(domain, layer_name: str, create: bool):
    try:
        layer = domain.layers.int.get(layer_name)
        if layer is None and create:
            layer = domain.layers.int.new(layer_name)
        return layer
    except Exception:
        return None


def _write_token(mesh, token: int, *, bm=None) -> bool:
    layer_name = _layer_name()
    if mesh is None or not layer_name:
        return False
    try:
        bm = bm or (bmesh.from_edit_mesh(mesh) if bool(getattr(mesh, "is_editmode", False)) else None)
    except Exception:
        bm = None
    if bm is None:
        return False
    changed = False
    for domain in (bm.verts, bm.edges, bm.faces):
        layer = _domain_layer(domain, layer_name, token > 0)
        if token <= 0:
            if layer is not None:
                try:
                    domain.layers.int.remove(layer)
                    changed = True
                except Exception:
                    pass
            continue
        if layer is None:
            continue
        try:
            for element in domain:
                element[layer] = int(token)
            changed = True
        except Exception:
            pass
    try:
        bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
    except Exception:
        pass
    if token > 0:
        entry = _mesh_entry(mesh, create=True)
        if isinstance(entry, dict):
            entry["last_token"] = int(token)
    return changed or token <= 0


def _read_token(mesh, entry=None) -> int:
    entry = entry or _mesh_entry(mesh, create=False)
    if not isinstance(entry, dict):
        return 0
    known = {int(value) for value in entry.get("known_tokens", set()) if int(value) > 0}
    if not known:
        return 0
    try:
        bm = bmesh.from_edit_mesh(mesh) if bool(getattr(mesh, "is_editmode", False)) else None
    except Exception:
        bm = None
    if bm is None:
        return 0
    counts = Counter()
    layer_name = _layer_name()
    layer_seen = False
    element_count = 0
    for domain in (bm.verts, bm.edges, bm.faces):
        layer = _domain_layer(domain, layer_name, False)
        if layer is None:
            continue
        layer_seen = True
        try:
            element_count += len(domain)
            counts.update(int(element[layer]) for element in domain if int(element[layer]) in known)
        except Exception:
            pass
    candidates = [(count, token) for token, count in counts.items() if token in known]
    if not candidates:
        # A delete can remove the final vertex/edge/face.  Blender still keeps
        # the empty CustomData layer in that Undo state, but there are no
        # elements from which to count the token.  Use the last token written
        # only while that private layer itself is present; the baseline Undo
        # state has no layer and therefore still resolves to token 0.
        fallback = int(entry.get("last_token") or 0)
        if layer_seen and element_count == 0 and fallback in known:
            return fallback
        return 0
    candidates.sort(reverse=True)
    return int(candidates[0][1])


def _remove_stale_layers(mesh) -> None:
    current = _layer_name()
    try:
        bm = bmesh.from_edit_mesh(mesh) if bool(getattr(mesh, "is_editmode", False)) else None
    except Exception:
        bm = None
    if bm is None:
        return
    changed = False
    for domain in (bm.verts, bm.edges, bm.faces):
        try:
            names = tuple(domain.layers.int.keys())
        except Exception:
            names = ()
        for name in names:
            if str(name).startswith(_LAYER_PREFIX) and str(name) != current:
                try:
                    layer = domain.layers.int.get(name)
                    if layer is not None:
                        domain.layers.int.remove(layer)
                        changed = True
                except Exception:
                    pass
    if changed:
        try:
            bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        except Exception:
            pass


def _edit_objects(context) -> tuple:
    try:
        objects = tuple(getattr(context, "objects_in_mode_unique_data", None) or getattr(context, "objects_in_mode", None) or ())
    except Exception:
        objects = ()
    if not objects:
        obj = getattr(context, "edit_object", None) or getattr(context, "active_object", None)
        objects = (obj,) if obj is not None else ()
    result = []
    seen = set()
    for obj in objects:
        try:
            if obj is None or obj.type != "MESH" or obj.mode != "EDIT":
                continue
            key = int(obj.data.as_pointer())
            if key in seen:
                continue
            seen.add(key)
            result.append(obj)
        except Exception:
            continue
    return tuple(result)


def _element_indices(elements) -> tuple:
    result = []
    for element in elements:
        try:
            if bool(element.select):
                result.append(int(element.index))
        except Exception:
            pass
    return tuple(result)


def _capture_selection(context, objects=None) -> dict:
    objects = tuple(objects or _edit_objects(context))
    records = []
    for obj in objects:
        mesh = getattr(obj, "data", None)
        if mesh is None:
            continue
        try:
            bm = bmesh.from_edit_mesh(mesh)
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()
            bm.verts.index_update()
            bm.edges.index_update()
            bm.faces.index_update()
        except Exception:
            continue
        history = []
        try:
            for element in bm.select_history:
                if isinstance(element, bmesh.types.BMVert):
                    history.append(("VERT", int(element.index)))
                elif isinstance(element, bmesh.types.BMEdge):
                    history.append(("EDGE", int(element.index)))
                elif isinstance(element, bmesh.types.BMFace):
                    history.append(("FACE", int(element.index)))
        except Exception:
            pass
        try:
            active_face = int(bm.faces.active.index) if bm.faces.active is not None else -1
        except Exception:
            active_face = -1
        records.append({
            "mesh": _mesh_record(mesh),
            "object": _object_record(obj),
            "verts": _element_indices(bm.verts),
            "edges": _element_indices(bm.edges),
            "faces": _element_indices(bm.faces),
            "history": tuple(history),
            "active_face": active_face,
        })
    try:
        select_mode = tuple(bool(value) for value in context.tool_settings.mesh_select_mode)
    except Exception:
        select_mode = (True, False, False)
    try:
        active = context.view_layer.objects.active
        active_record = _object_record(active) if active is not None else None
    except Exception:
        active_record = None
    return {
        "select_mode": select_mode,
        "active_object": active_record,
        "records": tuple(records),
    }


def _apply_selection(payload) -> bool:
    if not isinstance(payload, dict):
        return False
    try:
        if getattr(bpy.context, "mode", "") != "EDIT_MESH":
            return False
    except Exception:
        return False
    try:
        mode = tuple(bool(value) for value in tuple(payload.get("select_mode") or (True, False, False)))
        if len(mode) >= 3:
            bpy.context.tool_settings.mesh_select_mode = mode[:3]
    except Exception:
        pass
    changed = False
    for record in tuple(payload.get("records") or ()):
        mesh = _resolve_mesh(record.get("mesh"))
        if mesh is None or not bool(getattr(mesh, "is_editmode", False)):
            continue
        try:
            bm = bmesh.from_edit_mesh(mesh)
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()
            bm.verts.index_update()
            bm.edges.index_update()
            bm.faces.index_update()
        except Exception:
            continue
        for domain in (bm.verts, bm.edges, bm.faces):
            try:
                for element in domain:
                    element.select = False
            except Exception:
                pass
        for key, domain in (("verts", bm.verts), ("edges", bm.edges), ("faces", bm.faces)):
            for index in tuple(record.get(key) or ()):
                try:
                    if 0 <= int(index) < len(domain):
                        domain[int(index)].select = True
                except Exception:
                    pass
        try:
            bm.select_history.clear()
            for kind, index in tuple(record.get("history") or ()):
                domain = bm.verts if kind == "VERT" else bm.edges if kind == "EDGE" else bm.faces
                if 0 <= int(index) < len(domain):
                    bm.select_history.add(domain[int(index)])
        except Exception:
            pass
        try:
            active_face = int(record.get("active_face", -1))
            bm.faces.active = bm.faces[active_face] if 0 <= active_face < len(bm.faces) else None
        except Exception:
            pass
        try:
            bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
            changed = True
        except Exception:
            pass
    active = _resolve_object(payload.get("active_object"))
    if active is not None:
        try:
            bpy.context.view_layer.objects.active = active
        except Exception:
            pass
    return changed


def _geometry_counts(objects) -> tuple:
    result = []
    for obj in tuple(objects or ()):
        mesh = getattr(obj, "data", None)
        if mesh is None:
            continue
        try:
            bm = bmesh.from_edit_mesh(mesh)
            result.append((_mesh_key(mesh), len(bm.verts), len(bm.edges), len(bm.faces)))
        except Exception:
            pass
    return tuple(sorted(result))


def _current_known_token(state) -> int:
    counts = Counter()
    for entry in tuple(state.get("meshes", {}).values()):
        mesh = _resolve_mesh(entry)
        if mesh is None:
            continue
        token = _read_token(mesh, entry)
        if token > 0:
            counts[token] += 1
    if not counts:
        return 0
    return int(counts.most_common(1)[0][0])


def _prune_future(state, current_token: int) -> None:
    operations = state.get("operations", {})
    for token in tuple(operations):
        if int(token) > int(current_token):
            operations.pop(token, None)
    order = [int(token) for token in state.get("order", ()) if int(token) <= int(current_token)]
    state["order"] = order
    known = {int(token) for token in operations}
    for entry in tuple(state.get("meshes", {}).values()):
        entry["known_tokens"] = {int(token) for token in entry.get("known_tokens", set()) if int(token) in known}


def begin(context):
    """Prepare one Mesh Split click and return a transaction record."""
    objects = _edit_objects(context)
    if not objects or not ensure():
        return None
    state = _state(True)
    meshes = []
    need_baseline = False
    for obj in objects:
        mesh = obj.data
        _remove_stale_layers(mesh)
        entry = _mesh_entry(mesh, create=True)
        if not bool(entry.get("baseline_ready")):
            need_baseline = True
        meshes.append((mesh, entry))
    current_token = int(state.get("current_token") or 0)
    read_token = _current_known_token(state)
    if read_token or current_token == 0:
        current_token = read_token
    _prune_future(state, current_token)
    if need_baseline:
        # This is the one click-before state for newly tracked meshes.  It is
        # not repeated for subsequent Mesh Split clicks on the same history
        # branch, preventing the old extra Undo step.
        try:
            bpy.ops.ed.undo_push(message="Mesh Split Baseline")
        except Exception:
            return None
        for _mesh, entry in meshes:
            entry["baseline_ready"] = True
    before = _capture_selection(context, objects)
    before_counts = _geometry_counts(objects)
    token = _next_token()
    if token <= 0:
        return None
    return {
        "before_token": current_token,
        "after_token": token,
        "objects": objects,
        "meshes": tuple(mesh for mesh, _entry in meshes),
        "before": before,
        "before_counts": before_counts,
    }


def commit(record, context=None) -> bool:
    """Record the post-split state and create exactly one visible step."""
    if not isinstance(record, dict):
        return False
    state = _state(False)
    if not state:
        return False
    context = context or bpy.context
    token = int(record.get("after_token") or 0)
    objects = tuple(record.get("objects") or ())
    if token <= 0 or not objects:
        return False
    after = _capture_selection(context, objects)
    after_counts = _geometry_counts(objects)
    for mesh in tuple(record.get("meshes") or ()):
        entry = _mesh_entry(mesh, create=True)
        entry.setdefault("known_tokens", set()).add(token)
        try:
            bm = bmesh.from_edit_mesh(mesh) if bool(getattr(mesh, "is_editmode", False)) else None
        except Exception:
            bm = None
        _write_token(mesh, token, bm=bm)
    operation = {
        "before_token": int(record.get("before_token") or 0),
        "after_token": token,
        "before": record.get("before"),
        "after": after,
        "before_counts": tuple(record.get("before_counts") or ()),
        "after_counts": after_counts,
    }
    state["operations"][token] = operation
    order = state.setdefault("order", [])
    if token in order:
        order.remove(token)
    order.append(token)
    while len(order) > _MAX_OPERATIONS:
        old = int(order.pop(0))
        state["operations"].pop(old, None)
    state["current_token"] = token
    try:
        bpy.ops.ed.undo_push(message="Mesh Split")
        return True
    except Exception:
        return False


def rollback(record) -> None:
    if not isinstance(record, dict):
        return
    state = _state(False)
    if not state:
        return
    token = int(record.get("after_token") or 0)
    state.get("operations", {}).pop(token, None)
    try:
        state.get("order", []).remove(token)
    except Exception:
        pass
    state["current_token"] = int(record.get("before_token") or 0)
    _apply_selection(record.get("before"))


def _tracked_geometry_counts(state) -> tuple:
    objects = []
    seen = set()
    for entry in tuple(state.get("meshes", {}).values()):
        mesh = _resolve_mesh(entry)
        if mesh is None:
            continue
        try:
            for obj in bpy.data.objects:
                if obj.type != "MESH" or obj.data != mesh or obj.mode != "EDIT":
                    continue
                key = int(obj.data.as_pointer())
                if key not in seen:
                    seen.add(key)
                    objects.append(obj)
                break
        except Exception:
            continue
    return _geometry_counts(objects)


def _undo_post(_dummy=None):
    state = _state(False)
    if not state or state.get("shutdown") or state.get("syncing"):
        return
    state["syncing"] = True
    try:
        previous = int(state.get("current_token") or 0)
        if previous <= 0:
            return
        operation = state.get("operations", {}).get(previous)
        if not isinstance(operation, dict):
            return
        read_token = _current_known_token(state)
        target = int(operation.get("before_token") or 0)
        counts = _tracked_geometry_counts(state)
        if read_token != target and counts != tuple(operation.get("before_counts") or ()):
            return
        _apply_selection(operation.get("before"))
        state["current_token"] = target
    finally:
        state["syncing"] = False


def _redo_post(_dummy=None):
    state = _state(False)
    if not state or state.get("shutdown") or state.get("syncing"):
        return
    state["syncing"] = True
    try:
        current = int(state.get("current_token") or 0)
        read_token = _current_known_token(state)
        counts = _tracked_geometry_counts(state)
        candidates = [
            operation for operation in state.get("operations", {}).values()
            if int(operation.get("before_token") or 0) == current
        ]
        candidates.sort(key=lambda operation: int(operation.get("after_token") or 0))
        for operation in candidates:
            token = int(operation.get("after_token") or 0)
            if read_token != token and counts != tuple(operation.get("after_counts") or ()):
                continue
            _apply_selection(operation.get("after"))
            state["current_token"] = token
            break
    finally:
        state["syncing"] = False


def _load_pre(_dummy=None):
    shutdown()


def _remove_current_layer(mesh) -> int:
    entry = _mesh_entry(mesh, create=False)
    token = _read_token(mesh, entry) if entry else 0
    _write_token(mesh, 0)
    return token


def _save_pre(_filepath=None):
    state = _state(False)
    if not state or state.get("shutdown"):
        return
    restore = []
    for entry in tuple(state.get("meshes", {}).values()):
        mesh = _resolve_mesh(entry)
        if mesh is None:
            continue
        token = _remove_current_layer(mesh)
        if token > 0:
            restore.append((_mesh_record(mesh), token))
    state["save_restore"] = restore


def _restore_after_save():
    state = _state(False)
    if not state or state.get("shutdown"):
        return
    restore = list(state.get("save_restore", ()) or ())
    state["save_restore"] = []
    for mesh_record, token in restore:
        mesh = _resolve_mesh(mesh_record)
        if mesh is not None:
            _write_token(mesh, int(token or 0))


def _save_post(_filepath=None):
    _restore_after_save()


def _save_post_fail(_filepath=None):
    _restore_after_save()


def shutdown() -> None:
    state = _state(False)
    if state:
        state["shutdown"] = True
    for collection, current in (
        (bpy.app.handlers.undo_post, _undo_post),
        (bpy.app.handlers.redo_post, _redo_post),
        (bpy.app.handlers.load_pre, _load_pre),
        (bpy.app.handlers.save_pre, _save_pre),
        (bpy.app.handlers.save_post, _save_post),
        (bpy.app.handlers.save_post_fail, _save_post_fail),
    ):
        for function in tuple(collection):
            if function is current or _is_handler(function):
                try:
                    collection.remove(function)
                except Exception:
                    pass
    if state:
        for entry in tuple(state.get("meshes", {}).values()):
            mesh = _resolve_mesh(entry)
            if mesh is not None:
                _write_token(mesh, 0)
    try:
        namespace = bpy.app.driver_namespace
        namespace.pop(_NS_KEY, None)
    except Exception:
        pass


__all__ = (
    "begin",
    "commit",
    "rollback",
    "ensure",
    "shutdown",
)
