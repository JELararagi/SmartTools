# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

import bpy
from ..bootstrap_common import class_is_owned_for_mutation as _qsd_owned_class
from ..bootstrap_common import safe_unregister_class as _qsd_safe_unregister_class

# 1. 冒頭のライセンス・権利表記
# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi. All Rights Reserved.
#  Official Contact: 
#  Video Tutorials: 
#
#  【利用規約】
#  - 著作権: 本ソフトウェアの権利は「JELararagi」に帰属します。
#  - 禁止事項: 許可なき再配布、改変、転売を固く禁じます。
# ------------------------------------------------------------------------------

bl_info = {
    "name": "Quad Retopo",
    "author": "Smart Modeling",
    "version": (1, 11, 1),
    "blender": (5, 0, 0),
    "location": "View3D > Sidebar > (Custom Tab)",
    "description": "Tool to draw strip polygons with mouse operations. Launched from the N-panel.",
    "category": "Mesh",
}

import bmesh
import gpu
import blf
import math
from .. import preferences as _sms_preferences
from bpy.types import Operator, Panel, PropertyGroup
from bpy.props import FloatProperty, BoolProperty, IntProperty, EnumProperty, StringProperty, PointerProperty
from mathutils import Vector, geometry
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from gpu_extras.batch import batch_for_shader

# ============================================================
# 0) Localization & Constants (日本語辞書・ツールチップ)
# ============================================================
CONST_TEXT = {
    "PANEL_LABEL": {
        "en": "Quad Retopo",
        "ja": "クアッドストリップを描画"
    },
    "ADDON_DESC": {
        "en": "Tool to draw strip polygons with mouse operations. Launched from the N-panel.",
        "ja": "マウス操作で帯状ポリゴンを描画するツール。Nパネルから起動します。"
    },
    "LBL_TAB_NAME": {
        "en": "Tab Category Name",
        "ja": "タブカテゴリー名"
    },
    "TIP_PREF_CATEGORY": {
        "en": "Change the category name shown on the 3D Viewport sidebar tab for this add-on. The panel is organized into foldout sections, and detailed guidance is available from each section and tool tooltip.",
        "ja": "3Dビューポートのサイドバーに表示される、このアドオンのタブ名を変更します。パネルは折りたたみ式セクションで構成されており、詳しい使い方は各セクションや各ツールのツールチップで確認できます。"
    },
    "BTN_START": {
        "en": "Start Strip Drawing",
        "ja": "ストリップ描写を開始"
    },
    "BTN_RUNNING": {
        "en": "Strip Drawing Active",
        "ja": "ストリップ描写中"
    },
    "BOX_DRAWING": {
        "en": "Drawing Settings",
        "ja": "描画設定"
    },
    "BOX_GEOMETRY": {
        "en": "Geometry",
        "ja": "形状設定"
    },
    "PROP_WIDTH": {
        "en": "Width (cm)",
        "ja": "幅 (cm)"
    },
    "PROP_THICKNESS": {
        "en": "Thickness (cm)",
        "ja": "厚み (cm)"
    },
    "PROP_SOLIDIFY": {
        "en": "Solidify",
        "ja": "厚み付け"
    },
    "PROP_SEGMENTS": {
        "en": "Segments",
        "ja": "分割数"
    },
    "PROP_SNAP": {
        "en": "Surface Snap",
        "ja": "表面スナップ"
    },
    "PROP_PLANE": {
        "en": "Plane",
        "ja": "描画平面"
    },
    "PLANE_VIEW": {
        "en": "View",
        "ja": "ビュー"
    },
    "PLANE_VIEW_DESC": {
        "en": "Draw on a plane that faces the current viewport.",
        "ja": "現在のビューに正対した平面を基準に描画します。"
    },
    "PLANE_X": {
        "en": "X",
        "ja": "X"
    },
    "PLANE_X_DESC": {
        "en": "Draw on the global YZ plane.",
        "ja": "グローバルYZ平面を基準に描画します。"
    },
    "PLANE_Y": {
        "en": "Y",
        "ja": "Y"
    },
    "PLANE_Y_DESC": {
        "en": "Draw on the global XZ plane.",
        "ja": "グローバルXZ平面を基準に描画します。"
    },
    "PLANE_Z": {
        "en": "Z",
        "ja": "Z"
    },
    "PLANE_Z_DESC": {
        "en": "Draw on the global XY plane.",
        "ja": "グローバルXY平面を基準に描画します。"
    },
    "TIP_OP_START": {
        "en": "Start Draw Quad Strip.\nLeft Click: place / confirm the next segment\nAlt + Mouse Move: adjust width\nCtrl + Alt + Mouse Move: adjust thickness\nRight Click: end the current strip and keep the tool running\nEsc / Enter: finish the tool and generate UVs",
        "ja": "クアッドストリップを描画します。\n左クリック: 次のセグメントを配置・確定\nAlt + マウス移動: 幅を調整\nCtrl + Alt + マウス移動: 厚みを調整\n右クリック: 現在の一連のスプリットだけ終了してツールは継続\nEsc / Enter: ツールを終了してUVを生成"
    },
    "TIP_WIDTH": {
        "en": "Base width of the strip.\nThis value defines the initial ribbon width for newly added segments.\nYou can also tweak it interactively during drawing with Alt + mouse move.",
        "ja": "ストリップの基準幅です。\n新しく追加するセグメントの初期幅を決めます。\n描画中に Alt + マウス移動でもインタラクティブに調整できます。"
    },
    "TIP_THICKNESS": {
        "en": "Thickness applied when Solidify is enabled.\nUse this to turn the ribbon into box-like geometry instead of a single polygon strip.\nYou can also tweak it during drawing with Ctrl + Alt + mouse move.",
        "ja": "Solidify が有効なときに使われる厚みです。\n板状ストリップを箱形状の立体ジオメトリとして生成できます。\n描画中に Ctrl + Alt + マウス移動でも調整できます。"
    },
    "TIP_SOLIDIFY": {
        "en": "Create solid thickness instead of a flat ribbon.\nOff: generate a single quad strip.\nOn: generate a closed box-like strip with thickness.",
        "ja": "平面リボンではなく、厚みのある形状として生成します。\nOFF: 1枚の帯ポリゴンを生成\nON: 厚み付きの閉じた箱状ストリップを生成"
    },
    "TIP_SEGMENTS": {
        "en": "Interpolation amount between the previous point and the next point.\n0 creates a straight connection.\nHigher values insert extra subdivisions and smooth the strip with a curved path.",
        "ja": "前のポイントと次のポイントの間に入れる補間量です。\n0 は直線接続になります。\n値を上げるほど分割が増え、曲線的に滑らかなストリップになります。"
    },
    "TIP_SNAP": {
        "en": "Snap the drawing cursor to the surface under the mouse.\nUseful for retopo-like placement, surface detailing, and drawing directly over existing meshes.",
        "ja": "マウス下の表面へ描画位置を吸着させます。\nリトポ配置、表面ディテール作成、既存メッシュの上への直接描画に便利です。"
    },
    "PROP_STRIP_VERTEX_MERGE": {
        "en": "Merge Nearby Vertices",
        "ja": "近い頂点を結合"
    },
    "TIP_STRIP_VERTEX_MERGE": {
        "en": "When enabled, flat strip drawing reuses nearby existing vertices instead of always creating new ones.\nThe preview updates live while drawing, while changing width, and while adjusting the merge distance in the N-panel.\nThis option is forced off whenever Solidify is enabled.",
        "ja": "有効にすると、平面ストリップ描画時に毎回新規頂点を作る代わりに、近くの既存頂点を再利用して結合します。\n描画中、幅調整中、Nパネルで結合距離を変更したときも、プレビューへリアルタイム反映されます。\nSolidify を有効にして厚み付きにした場合、この機能は強制的にOFF扱いになります。"
    },
    "PROP_STRIP_VERTEX_MERGE_DIST": {
        "en": "Vertex Merge Distance (cm)",
        "ja": "頂点結合距離 (cm)"
    },
    "TIP_STRIP_VERTEX_MERGE_DIST": {
        "en": "Maximum world-space distance used when deciding whether a previewed strip vertex should snap to an existing vertex.\nChanging this value while the tool is running immediately updates the preview, so you can see whether the strip will stitch or stay separate before you click to confirm.",
        "ja": "プレビュー中のストリップ頂点を既存頂点へ吸着させるかどうかを判定する、ワールド空間での最大距離です。\nツール実行中にこの値を変えるとプレビューへ即時反映され、クリック確定前に結合されるか独立したままかを確認できます。"
    },
    "TIP_PLANE": {
        "en": "Reference plane used when Surface Snap is off or when no surface is hit.\nView follows the current viewport. X / Y / Z use global axis planes.",
        "ja": "Surface Snap がOFF、またはヒット面がない場合に使う基準平面です。\nView は現在のビュー基準、X / Y / Z はグローバル軸平面を使います。"
    },
    "HUD_STATE_0": {
        "en": "Click to Start",
        "ja": "クリックして始点を決定"
    },
    "HUD_STATE_1": {
        "en": "Set Direction",
        "ja": "方向を設定"
    },
    "HUD_STATE_2": {
        "en": "Drawing...",
        "ja": "ストリップ描写中"
    },
    "HUD_HELP": {
        "en": "Alt:Width / Ctrl+Alt:Thick / Right Click:End Strip / Esc・Enter:Finish",
        "ja": "Alt:幅 / Ctrl+Alt:厚み / 右クリック:一連終了 / Esc・Enter:終了"
    },
    "HUD_LOCKED": {
        "en": "(Locked)",
        "ja": "（固定中）"
    },
    "HUD_DISABLED": {
        "en": "(Disabled)",
        "ja": "（無効）"
    },
    "BOX_RETOPO": {
        "en": "Ultimate Retopo",
        "ja": "Ultimate Retopo"
    },
    "UI_ENABLE": {
        "en": "Enable",
        "ja": "有効"
    },
    "UI_TARGET": {
        "en": "Target",
        "ja": "ターゲット"
    },
    "UI_OFFSET": {
        "en": "Offset (cm)",
        "ja": "オフセット (cm)"
    },
    "UI_MAX_DIST": {
        "en": "Max Dist (cm)",
        "ja": "最大距離 (cm)"
    },
    "UI_FRONTFACE_ONLY": {
        "en": "Frontface Only",
        "ja": "前面のみ"
    },
    "UI_SNAP_PX": {
        "en": "Snap(px)",
        "ja": "スナップ(px)"
    },
    "LABEL_GUIDES": {
        "en": "Guides",
        "ja": "ガイド"
    },
    "LABEL_FIELD_PAINT": {
        "en": "Field Paint",
        "ja": "フィールドペイント"
    },
    "LABEL_FILL_RELAX_PROJECT": {
        "en": "Fill / Relax / Project",
        "ja": "面張り / リラックス / 投影"
    },
    "LABEL_BOUNDARY_TRACE": {
        "en": "Boundary Trace",
        "ja": "境界トレース"
    },
    "OP_GUIDES_SET": {
        "en": "Set",
        "ja": "設定"
    },
    "OP_GUIDES_CLEAR": {
        "en": "Clear",
        "ja": "クリア"
    },
    "OP_GUIDES_SELECT": {
        "en": "Select",
        "ja": "選択"
    },
    "OP_RETOPO_PEN": {
        "en": "Retopo Strip Draw",
        "ja": "リトポ・ストリップ描画"
    },
    "OP_PROJECT_SELECTED": {
        "en": "Project Selected",
        "ja": "選択を投影"
    },
    "OP_RELAX_PROJECT": {
        "en": "Relax + Project",
        "ja": "緩和＋投影"
    },
    "OP_GRID_FILL_PROJECT": {
        "en": "Grid Fill + Project",
        "ja": "グリッドフィル＋投影"
    },
    "OP_LOOP_TRACE_EXTEND": {
        "en": "Loop Trace Extend (Drag)",
        "ja": "ループトレース延長（ドラッグ）"
    },
    "OP_BOUNDARY_TRACE_PAINT": {
        "en": "Boundary Trace Paint (Drag)",
        "ja": "境界トレース描画（ドラッグ）"
    },
    "OP_QUAD_FIELD_PAINT": {
        "en": "Quad Field Paint (Drag)",
        "ja": "クアッドフィールド描画（ドラッグ）"
    },
    "TIP_OP_RETOPO_PEN": {
        "en": "Start Retopo Pen is no longer a separate workflow. Use the main Draw Quad Strip operator with Retopo Mode enabled.\nThe strip will project to the Retopo Target, keep viewport navigation available, and optionally merge with nearby vertices while previewing the result in real time.",
        "ja": "リトポペンを開始は独立したワークフローではなくなりました。Retopo Mode を有効にした状態で、メインの Draw Quad Strip を使ってください。\nストリップは Retopo Target に投影され、実行中もビューナビゲーションが可能で、近い頂点との結合もリアルタイムプレビューしながら使えます。"
    },
    "TIP_OP_GUIDES_SET": {
        "en": "Mark the currently selected edges as guide edges.\nGuide edges are used by Quad Field Paint to bias the flow direction.",
        "ja": "現在選択中の辺をガイド辺として登録します。\n登録したガイドは Quad Field Paint の流れ方向の誘導に使われます。"
    },
    "TIP_OP_GUIDES_CLEAR": {
        "en": "Clear guide flags from the selected edges.\nIf nothing is selected, all guide edges in the edit mesh are cleared.",
        "ja": "選択中の辺からガイド指定を解除します。\n何も選択していない場合は、編集メッシュ内の全ガイドを解除します。"
    },
    "TIP_OP_GUIDES_SELECT": {
        "en": "Select all edges currently marked as guides.\nUseful when you want to review, edit, or clear existing guide paths.",
        "ja": "現在ガイドとして登録されている辺を選択します。\n既存ガイドの確認、編集、解除を行いたいときに便利です。"
    },
    "TIP_OP_PROJECT_SELECTED": {
        "en": "Project the selected vertices onto the Retopo Target.\nEach selected vertex is moved to the closest point on the target surface, then offset along the target normal.",
        "ja": "選択頂点を Retopo Target 上へ投影します。\n各頂点を最寄り表面へ移動し、その後ターゲット法線方向にオフセットします。"
    },
    "TIP_OP_RELAX_PROJECT_SELECTED": {
        "en": "Relax the selected vertices, then project them back to the Retopo Target.\nUseful for evening out spacing while keeping the result adhered to the highpoly surface.",
        "ja": "選択頂点を緩和してから Retopo Target 上へ再投影します。\n表面への追従を保ちながら、頂点間隔を整えたいときに便利です。"
    },
    "TIP_OP_GRID_FILL_PROJECT": {
        "en": "Run Grid Fill on the selected boundary edges, then project the result to the Retopo Target.\nUse this to close retopo holes and immediately conform the new topology to the target surface.",
        "ja": "選択した境界辺に Grid Fill を行い、その結果を Retopo Target に投影します。\n穴埋め後すぐに新規トポロジーをターゲット表面へ沿わせたいときに使います。"
    },
    "TIP_OP_LOOP_TRACE_EXTEND": {
        "en": "Drag-based loop extension from the current selected boundary.\nThe operator extrudes the open boundary step by step while following the target surface and mouse direction.",
        "ja": "現在選択中の境界から、ドラッグでループを延長します。\nターゲット表面とマウス方向に沿って、境界を段階的に押し出します。"
    },
    "TIP_OP_BOUNDARY_TRACE_PAINT": {
        "en": "Paint along an existing boundary to extend topology.\nThe stroke follows nearby boundary direction, can fill faces while tracing, and can merge the result as it grows.",
        "ja": "既存境界に沿ってトポロジーを延長する描画ツールです。\n近傍境界の方向に追従し、トレースしながら面作成やマージも行えます。"
    },
    "TIP_OP_QUAD_FIELD_PAINT": {
        "en": "Paint a quad patch over the target surface.\nThis tool samples the stroke, builds a width-defined quad field, optionally follows guides / boundaries, and can auto stitch on finish.",
        "ja": "ターゲット表面上にクアッドパッチを描画します。\nストロークをサンプリングし、指定幅のクアッドフィールドを生成します。ガイドや境界への追従、自動ステッチにも対応します。"
    },
    "PROP_RETOPO_MODE": {
        "en": "Retopo Mode",
        "ja": "リトポモード"
    },
    "PROP_RETOPO_TARGET": {
        "en": "Retopo Target",
        "ja": "リトポターゲット"
    },
    "PROP_RETOPO_OFFSET": {
        "en": "Retopo Offset (cm)",
        "ja": "リトポオフセット (cm)"
    },
    "PROP_RETOPO_PROJECT_MAX_DIST": {
        "en": "Project Max Dist (cm)",
        "ja": "投影最大距離 (cm)"
    },
    "PROP_RETOPO_FRONTFACE_ONLY": {
        "en": "Frontface Only",
        "ja": "前面のみ"
    },
    "PROP_RETOPO_SNAP_RADIUS": {
        "en": "Snap Radius (px)",
        "ja": "スナップ半径 (px)"
    },
    "PROP_RETOPO_AUTO_CONNECT": {
        "en": "Merge Nearby Vertices",
        "ja": "近い頂点を結合"
    },
    "PROP_RETOPO_CONNECT_DIST": {
        "en": "Vertex Merge Distance (cm)",
        "ja": "頂点結合距離 (cm)"
    },
    "PROP_RETOPO_AUTO_QUAD": {
        "en": "Auto Quad",
        "ja": "自動クアッド"
    },
    "PROP_RETOPO_LOOP_STEP": {
        "en": "Step (cm)",
        "ja": "ステップ (cm)"
    },
    "PROP_RETOPO_LOOP_SPACING_PX": {
        "en": "Spacing (px)",
        "ja": "間隔 (px)"
    },
    "PROP_RETOPO_LOOP_FLIP": {
        "en": "Flip",
        "ja": "反転"
    },
    "PROP_RETOPO_LOOP_MAKE_FACES": {
        "en": "Make Faces",
        "ja": "面を作成"
    },
    "PROP_RETOPO_LOOP_MERGE_DIST": {
        "en": "Loop Merge Dist (cm)",
        "ja": "ループマージ距離 (cm)"
    },
    "PROP_RETOPO_LOOP_SNAP_PX": {
        "en": "Boundary Snap (px)",
        "ja": "境界スナップ (px)"
    },
    "PROP_RETOPO_LOOP_LOCK_STRENGTH": {
        "en": "Boundary Lock",
        "ja": "境界ロック"
    },
    "PROP_RETOPO_LOOP_INERTIA": {
        "en": "Boundary Inertia",
        "ja": "境界慣性"
    },
    "PROP_FIELD_WIDTH": {
        "en": "Field Width (cm)",
        "ja": "フィールド幅 (cm)"
    },
    "PROP_FIELD_COLUMNS": {
        "en": "Columns",
        "ja": "列数"
    },
    "PROP_FIELD_SPACING_PX": {
        "en": "Spacing(px)",
        "ja": "間隔(px)"
    },
    "PROP_FIELD_SCREEN_ADAPTIVE": {
        "en": "Adaptive",
        "ja": "適応"
    },
    "PROP_FIELD_SILHOUETTE_BOOST": {
        "en": "Silhouette Boost",
        "ja": "シルエット強調"
    },
    "PROP_FIELD_CURVATURE_BOOST": {
        "en": "Curvature Boost",
        "ja": "曲率強調"
    },
    "PROP_FIELD_ALIGN_GUIDES": {
        "en": "Align Guides",
        "ja": "ガイド整列"
    },
    "PROP_FIELD_GUIDE_STRENGTH": {
        "en": "Guide Strength",
        "ja": "ガイド強度"
    },
    "PROP_FIELD_AUTO_STITCH": {
        "en": "Auto Stitch",
        "ja": "自動ステッチ"
    },
    "PROP_FIELD_MERGE_DIST": {
        "en": "Merge Distance (cm)",
        "ja": "マージ距離 (cm)"
    },
    "PROP_FIELD_EDGE_SNAP_PX": {
        "en": "Edge Snap (px)",
        "ja": "辺スナップ (px)"
    },
    "PROP_FIELD_BOUNDARY_ONLY": {
        "en": "Boundary Only",
        "ja": "境界のみ"
    },
    "PROP_FIELD_TRACE_BOUNDARY": {
        "en": "Trace Boundary",
        "ja": "境界追従"
    },
    "PROP_FIELD_EDGE_SNAP_TO_EDGES": {
        "en": "Edge Snap To Edges",
        "ja": "辺へスナップ"
    },
    "PROP_FIELD_BOUNDARY_STRENGTH": {
        "en": "Boundary Strength",
        "ja": "境界強度"
    },
    "PROP_FIELD_TANGENT_INERTIA": {
        "en": "Tangent Inertia",
        "ja": "接線慣性"
    },
    "PROP_FIELD_LIVE_MERGE": {
        "en": "Live Merge",
        "ja": "ライブマージ"
    },
    "PROP_FIELD_LIVE_MERGE_DIST": {
        "en": "Live Merge Dist (cm)",
        "ja": "ライブマージ距離 (cm)"
    },
    "PROP_FIELD_STOP_ON_INTERSECT": {
        "en": "Stop On Intersect",
        "ja": "交差で停止"
    },
    "PROP_FIELD_INTERSECT_TOL": {
        "en": "Intersect Tol (cm)",
        "ja": "交差許容値 (cm)"
    },
    "PROP_FIELD_AUTO_FILL_ON_FINISH": {
        "en": "Auto Fill On Finish",
        "ja": "終了時自動フィル"
    },
    "PROP_FIELD_FILL_SPAN": {
        "en": "Fill Span (0=Auto)",
        "ja": "フィル Span (0=自動)"
    },
    "PROP_FIELD_FILL_RELAX_ITERS": {
        "en": "Fill Relax Iters",
        "ja": "フィル緩和反復"
    },
    "PROP_FIELD_FILL_RELAX_STRENGTH": {
        "en": "Fill Relax Strength",
        "ja": "フィル緩和強度"
    },
    "PROP_RELAX_ITERATIONS": {
        "en": "Iterations",
        "ja": "反復回数"
    },
    "PROP_RELAX_STRENGTH": {
        "en": "Strength",
        "ja": "強さ"
    },
    "PROP_GRID_FILL_SPAN": {
        "en": "Span (0=Auto)",
        "ja": "Span (0=自動)"
    },
    "PROP_GUIDE_SELECT": {
        "en": "Select",
        "ja": "選択"
    },
    "TIP_RETOPO_MODE": {
        "en": "Enable the Ultimate Retopo toolset in the panel.\nWhen enabled, the add-on exposes the target projection, guide, field paint, and boundary tracing tools.",
        "ja": "パネル内の Ultimate Retopo ツール群を有効にします。\n有効化すると、ターゲット投影、ガイド、フィールド描画、境界トレース系ツールが使用可能になります。"
    },
    "TIP_RETOPO_TARGET": {
        "en": "Highpoly or reference mesh used for snapping and projection.\nMost Ultimate Retopo tools require this target to project vertices onto the surface.",
        "ja": "スナップや投影の基準となるハイポリ／参照メッシュです。\nUltimate Retopo の多くの機能は、このターゲット表面への投影を前提に動作します。"
    },
    "TIP_RETOPO_OFFSET": {
        "en": "Distance to offset projected results along the target surface normal.\nUse a small positive value to keep retopo geometry slightly above the target surface.",
        "ja": "投影後にターゲット法線方向へずらす距離です。\n小さな正の値を使うと、リトポメッシュをターゲット表面からわずかに浮かせられます。"
    },
    "TIP_RETOPO_PROJECT_MAX_DIST": {
        "en": "Maximum allowed distance for projection.\n0 means unlimited.\nIf the nearest target point is farther than this value, the projection is skipped.",
        "ja": "投影を許可する最大距離です。\n0 は無制限です。\n最寄りターゲット点がこの値より遠い場合、その投影をスキップします。"
    },
    "TIP_RETOPO_FRONTFACE_ONLY": {
        "en": "Prefer front-facing hits when snapping or projecting.\nThis helps reduce backface penetration and unwanted projection through the model.",
        "ja": "スナップや投影時に前面ヒットを優先します。\n背面貫通や、モデルを突き抜けた不要な投影を減らすのに役立ちます。"
    },
    "TIP_RETOPO_SNAP_RADIUS": {
        "en": "Screen-space pickup radius used by Start Retopo Pen while choosing an anchor on the target surface.\nLarger values make it easier to pick nearby existing vertices as strip anchors before projection.",
        "ja": "Start Retopo Pen がターゲット表面上のアンカー位置を決めるときに使う、画面空間の拾い範囲です。\n値を大きくすると、投影前に近くの既存頂点をストリップの基点として拾いやすくなります。"
    },
    "TIP_RETOPO_AUTO_CONNECT": {
        "en": "Reuse nearby existing vertices while drawing the retopo strip.\nWhen enabled, each newly generated strip corner searches for an existing mesh vertex within Connect Distance and reuses it instead of creating a duplicate.\nThis is useful for stitching the new strip into existing topology.",
        "ja": "リトポストリップ描画時に、近くの既存頂点を再利用します。\n有効時は、生成される各コーナー頂点が Connect Distance の範囲内にある既存メッシュ頂点を探し、重複頂点を作らず再利用します。\n既存トポロジーへ自然につなぎたいときに便利です。"
    },
    "TIP_RETOPO_CONNECT_DIST": {
        "en": "World-space distance used when Connect Nearby is enabled.\nIf a newly generated strip corner is inside this distance from an existing mesh vertex, that existing vertex is reused instead of creating a new one.",
        "ja": "「近接頂点に接続」が有効なときに使うワールド空間の距離です。\n新しく生成されるストリップのコーナーが、この距離の範囲内にある既存メッシュ頂点へ近い場合は、新規作成せずその頂点を再利用します。"
    },
    "TIP_RETOPO_AUTO_QUAD": {
        "en": "When using Start Retopo Pen, try to create a quad face every time four consecutive vertices are available.",
        "ja": "Start Retopo Pen 使用時、4つの連続頂点が揃うたびにクアッド面化を試みます。"
    },
    "TIP_RETOPO_LOOP_STEP": {
        "en": "World-space extrusion distance added on each boundary extension step.",
        "ja": "境界延長1ステップごとに押し出すワールド空間距離です。"
    },
    "TIP_RETOPO_LOOP_SPACING_PX": {
        "en": "How much mouse travel is required before the next loop extension step is created.",
        "ja": "次の延長ステップを生成するまでに必要なマウス移動量です。"
    },
    "TIP_RETOPO_LOOP_FLIP": {
        "en": "Flip the outward direction used when extending the selected boundary.",
        "ja": "選択境界を延長する際の外向き方向を反転します。"
    },
    "TIP_RETOPO_LOOP_MAKE_FACES": {
        "en": "Create quad faces between the previous boundary and the newly extended boundary while tracing.",
        "ja": "トレース中、元の境界と新しい境界の間にクアッド面を生成します。"
    },
    "TIP_RETOPO_LOOP_MERGE_DIST": {
        "en": "Optional merge distance applied after each loop extension step.\n0 disables the merge.",
        "ja": "各延長ステップ後に適用する任意のマージ距離です。\n0 で無効になります。"
    },
    "TIP_RETOPO_LOOP_SNAP_PX": {
        "en": "Screen-space snap radius used by Boundary Trace Paint.\n0 disables boundary snapping.",
        "ja": "Boundary Trace Paint が使う画面空間スナップ半径です。\n0 で境界スナップを無効化します。"
    },
    "TIP_RETOPO_LOOP_LOCK_STRENGTH": {
        "en": "How strongly mouse motion is constrained to the detected boundary direction.\nHigher values feel more locked and stable.",
        "ja": "検出した境界方向へどれだけ強くマウス移動を拘束するかを決めます。\n高いほどロック感が強く安定します。"
    },
    "TIP_RETOPO_LOOP_INERTIA": {
        "en": "Smoothing applied to the tracked boundary tangent.\nHigher values reduce jitter but react more slowly to sharp direction changes.",
        "ja": "追跡中の境界接線に適用するスムージング量です。\n高いほどブレは減りますが、急な方向変化への追従は遅くなります。"
    },
    "TIP_FIELD_WIDTH": {
        "en": "Total width of the quad patch generated by Quad Field Paint.",
        "ja": "Quad Field Paint が生成するクアッドパッチ全体の幅で、単位は cm です。"
    },
    "TIP_FIELD_COLUMNS": {
        "en": "Number of quads generated across the patch width.",
        "ja": "パッチ幅方向に生成するクアッド数です。"
    },
    "TIP_FIELD_SPACING_PX": {
        "en": "Base sampling spacing of the stroke in screen pixels.\nSmaller values sample more densely and create more geometry.",
        "ja": "ストロークをサンプリングする基準間隔です（画面ピクセル単位）。\n小さいほど密にサンプリングされ、生成ジオメトリも増えます。"
    },
    "TIP_FIELD_SCREEN_ADAPTIVE": {
        "en": "Adapt sampling density based on visible silhouette and curvature cues.",
        "ja": "見た目のシルエットや曲率に応じてサンプリング密度を自動調整します。"
    },
    "TIP_FIELD_SILHOUETTE_BOOST": {
        "en": "Additional density multiplier near silhouette regions.",
        "ja": "シルエット付近で密度を増やす補正量です。"
    },
    "TIP_FIELD_CURVATURE_BOOST": {
        "en": "Additional density multiplier on highly curved surface areas.",
        "ja": "曲率の高い表面領域で密度を増やす補正量です。"
    },
    "TIP_FIELD_ALIGN_GUIDES": {
        "en": "Use nearby guide edges to influence the stroke flow direction.",
        "ja": "近くのガイド辺を利用して、ストロークの流れ方向へ影響を与えます。"
    },
    "TIP_FIELD_GUIDE_STRENGTH": {
        "en": "Strength of guide influence when Align Guides is enabled.",
        "ja": "Align Guides 有効時に、ガイドが流れ方向へ与える影響の強さです。"
    },
    "TIP_FIELD_AUTO_STITCH": {
        "en": "Automatically merge doubles / stitch the result when the paint operation finishes.",
        "ja": "描画終了時に重複頂点を自動マージし、結果を縫い合わせます。"
    },
    "TIP_FIELD_MERGE_DIST": {
        "en": "Merge threshold used by Auto Stitch.",
        "ja": "Auto Stitch が使うマージしきい値です。"
    },
    "TIP_FIELD_EDGE_SNAP_PX": {
        "en": "Snap Field Paint endpoints to nearby boundary features in screen pixels.\n0 disables endpoint snapping.",
        "ja": "Field Paint の端点を近傍境界へスナップする半径です（画面ピクセル単位）。\n0 で端点スナップを無効化します。"
    },
    "TIP_FIELD_BOUNDARY_ONLY": {
        "en": "Restrict endpoint snapping to boundary vertices only.",
        "ja": "端点スナップ先を境界頂点のみに制限します。"
    },
    "TIP_FIELD_TRACE_BOUNDARY": {
        "en": "When the stroke is close to a boundary, align the generated flow to that boundary direction.",
        "ja": "ストロークが境界に近い場合、生成フローをその境界方向に合わせます。"
    },
    "TIP_FIELD_EDGE_SNAP_TO_EDGES": {
        "en": "When edge snapping is enabled, prefer snapping to the nearest edge segment instead of only to vertices.",
        "ja": "Edge Snap 有効時、頂点だけでなく最寄りの辺セグメントへ優先的にスナップします。"
    },
    "TIP_FIELD_BOUNDARY_STRENGTH": {
        "en": "How strongly boundary direction influences the field flow when boundary tracing is active.",
        "ja": "境界追従が有効なとき、境界方向がフィールドの流れに与える影響の強さです。"
    },
    "TIP_FIELD_TANGENT_INERTIA": {
        "en": "Smoothing for the sampled field tangent direction across the stroke.",
        "ja": "ストローク全体でサンプリングされる接線方向へのスムージング量です。"
    },
    "TIP_FIELD_LIVE_MERGE": {
        "en": "Reuse nearby existing vertices while drawing to reduce doubles and cleanup work later.",
        "ja": "描画中に近傍の既存頂点を再利用し、重複頂点や後処理の手間を減らします。"
    },
    "TIP_FIELD_LIVE_MERGE_DIST": {
        "en": "Distance threshold used by Live Merge.",
        "ja": "Live Merge が使う距離しきい値です。"
    },
    "TIP_FIELD_STOP_ON_INTERSECT": {
        "en": "Stop generating new rings when the local intersection guard detects conflicting topology.",
        "ja": "ローカル交差ガードが競合トポロジーを検出した場合、新しいリング生成を停止します。"
    },
    "TIP_FIELD_INTERSECT_TOL": {
        "en": "Tolerance, in centimeters, used by the local intersection guard.",
        "ja": "ローカル交差ガードが使う許容値です。"
    },
    "TIP_FIELD_AUTO_FILL_ON_FINISH": {
        "en": "After painting, try to detect a closed boundary loop around the patch and fill it automatically.",
        "ja": "描画終了後、パッチ周囲の閉じた境界ループを検出して自動で面を張ろうとします。"
    },
    "TIP_FIELD_FILL_SPAN": {
        "en": "Span value passed to Grid Fill during Auto Fill.\n0 lets the add-on estimate an appropriate value.",
        "ja": "Auto Fill 時に Grid Fill へ渡す span 値です。\n0 の場合はアドオンが適切な値を推定します。"
    },
    "TIP_FIELD_FILL_RELAX_ITERS": {
        "en": "Relax iterations applied after Auto Fill to even out the filled patch.",
        "ja": "Auto Fill 後に、埋めたパッチを均すために行う緩和反復回数です。"
    },
    "TIP_FIELD_FILL_RELAX_STRENGTH": {
        "en": "Relax strength applied after Auto Fill.",
        "ja": "Auto Fill 後に適用する緩和の強さです。"
    },
    "TIP_RELAX_ITERATIONS": {
        "en": "Number of relax passes performed before projection.",
        "ja": "投影前に実行する緩和パスの回数です。"
    },
    "TIP_RELAX_STRENGTH": {
        "en": "How strongly each relax pass moves selected vertices toward their neighbor average.",
        "ja": "各緩和パスで、選択頂点を隣接頂点の平均位置へどれだけ近づけるかを決めます。"
    },
    "TIP_GRID_FILL_SPAN": {
        "en": "Grid Fill span value.\n0 lets the operator estimate a suitable span automatically from the selected boundary.",
        "ja": "Grid Fill の span 値です。\n0 の場合、選択境界から適切な値を自動推定します。"
    },
    "TIP_GUIDE_SELECT": {
        "en": "Select or deselect the stored guide edges when the operator runs.",
        "ja": "オペレーター実行時に、保存済みガイド辺を選択または選択解除します。"
    }
}


CONST_TEXT.update({
    "BTN_START": {
        "en": "Start Strip Drawing",
        "ja": "ストリップ描画を開始"
    },
    "BTN_RUNNING": {
        "en": "Strip Drawing Active... (Esc / Enter = Finish)",
        "ja": "ストリップ描画中...（Esc / Enter で終了）"
    },
    "PROP_PLANE": {
        "en": "Draw Plane",
        "ja": "描画基準面"
    },
    "PROP_SNAP": {
        "en": "Snap to Surface",
        "ja": "表面にスナップ"
    },
    "PROP_SEGMENTS": {
        "en": "Extra Segments",
        "ja": "追加分割"
    },
    "UI_MAX_DIST": {
        "en": "Max Projection Distance",
        "ja": "最大投影距離"
    },
    "UI_SNAP_PX": {
        "en": "Snap Radius (px)",
        "ja": "スナップ半径 (px)"
    },
    "UI_SECTION_QUICKSTART": {
        "en": "Quick Start",
        "ja": "クイックスタート"
    },
    "UI_SECTION_BASIC_STRIP": {
        "en": "Basic Strip Settings",
        "ja": "基本ストリップ設定"
    },
    "UI_SECTION_RETOPO_ROOT": {
        "en": "Ultimate Retopo",
        "ja": "Ultimate Retopo"
    },
    "UI_SECTION_RETOPO_SETUP": {
        "en": "Retopo Setup",
        "ja": "リトポ設定"
    },
    "UI_SECTION_RETOPO_PEN": {
        "en": "Retopo Strip Draw",
        "ja": "リトポ・ストリップ描画"
    },
    "UI_SECTION_GUIDES": {
        "en": "Guides",
        "ja": "ガイド"
    },
    "UI_SECTION_FIELD_PAINT": {
        "en": "Quad Field Paint",
        "ja": "クアッドフィールド描画"
    },
    "UI_SECTION_FILL_TOOLS": {
        "en": "Fill / Relax / Project",
        "ja": "面張り / リラックス / 投影"
    },
    "UI_SECTION_BOUNDARY_TRACE": {
        "en": "Boundary Trace",
        "ja": "境界トレース"
    },
    "UI_SECTION_ADVANCED_OPTIONS": {
        "en": "Advanced Options",
        "ja": "詳細オプション"
    },
    "UI_BEGINNER_RECOMMENDED": {
        "en": "Recommended for beginners",
        "ja": "初心者向けおすすめ設定"
    },
    "UI_LABEL_STATUS_READY": {
        "en": "Ready to draw a new strip.",
        "ja": "新しいストリップを描画できます。"
    },
    "UI_LABEL_STATUS_RUNNING": {
        "en": "Drawing is currently active in the viewport.",
        "ja": "現在ビューポート上で描画ツールが動作中です。"
    },
    "UI_QUICKSTART_STEP_1": {
        "en": "1. Press Start Strip Drawing.",
        "ja": "1. まず「ストリップ描画を開始」を押します。"
    },
    "UI_QUICKSTART_STEP_2": {
        "en": "2. Move the mouse and left-click to place each segment.",
        "ja": "2. マウスを動かし、左クリックで各セグメントを配置します。"
    },
    "UI_QUICKSTART_STEP_3": {
        "en": "3. Right-click ends only the current strip. Press Esc or Enter to finish the tool.",
        "ja": "3. 右クリックは現在の一連だけ終了します。Esc または Enter でツール全体を終了します。"
    },
    "UI_QUICKSTART_STEP_4": {
        "en": "4. Turn on Snap to Surface when drawing over an existing mesh.",
        "ja": "4. 既存メッシュの上に描くときは「表面にスナップ」をONにします。"
    },
    "UI_BASIC_HINT_1": {
        "en": "Width changes the strip size. Extra Segments adds smoother intermediate cuts.",
        "ja": "「幅」でストリップの太さを調整します。「追加分割」を増やすと途中に分割が入り、より滑らかになります。"
    },
    "UI_BASIC_HINT_2": {
        "en": "Turn on Solidify only when you want actual thickness.",
        "ja": "立体的な厚みが必要なときだけ「厚み付け」をONにしてください。"
    },
    "UI_RETOPO_DISABLED_HINT": {
        "en": "Turn this on only when rebuilding topology on top of another mesh.",
        "ja": "別メッシュの表面に沿ってトポロジーを作り直すときだけONにしてください。"
    },
    "UI_RETOPO_SETUP_HINT": {
        "en": "Pick the target mesh first, then use the tools below.",
        "ja": "最初にターゲットメッシュを指定し、その後で下のツールを使います。"
    },
    "UI_RETOPO_PEN_HINT": {
        "en": "Best when you want to place vertices one by one on the target surface.",
        "ja": "ターゲット表面に頂点を1点ずつ置いていきたいときに最適です。"
    },
    "UI_GUIDES_HINT": {
        "en": "In Edit Mode, select edges first, then register or clear them here.",
        "ja": "編集モードで辺を選択してから、ここでガイド登録または解除を行います。"
    },
    "UI_FIELD_PAINT_HINT": {
        "en": "Use this when you want to paint a quad patch instead of placing points one by one.",
        "ja": "頂点を1点ずつ置く代わりに、面のかたまりを一気に描きたいときに使います。"
    },
    "UI_FILL_HINT": {
        "en": "These commands work on the current selection in Edit Mode.",
        "ja": "これらのコマンドは編集モードで現在選択されている要素に対して実行されます。"
    },
    "UI_BOUNDARY_HINT": {
        "en": "Use this to extend topology while following an existing edge boundary.",
        "ja": "既存の境界エッジに沿ってトポロジーを延長したいときに使います。"
    },
    "UI_GROUP_FIELD_SHAPE": {
        "en": "Patch Shape",
        "ja": "パッチ形状"
    },
    "UI_GROUP_FIELD_GUIDANCE": {
        "en": "Flow Guidance",
        "ja": "流れの誘導"
    },
    "UI_GROUP_FIELD_FINISH": {
        "en": "Stitch / Finish",
        "ja": "ステッチ / 仕上げ"
    },
    "UI_GROUP_FILL_SETTINGS": {
        "en": "Operation Settings",
        "ja": "実行設定"
    },
    "UI_GROUP_BOUNDARY_CORE": {
        "en": "Basic Trace Settings",
        "ja": "基本トレース設定"
    },
    "UI_GROUP_BOUNDARY_ADV": {
        "en": "Advanced Trace Settings",
        "ja": "詳細トレース設定"
    },
    "TIP_UI_SHOW_QUICKSTART": {
        "en": "Show or hide the quick-start help. Basic operating steps are also explained in the Start Strip Drawing button tooltip.",
        "ja": "クイックスタートのヘルプを表示 / 非表示にします。基本操作手順は「ストリップ描画を開始」ボタンのツールチップでも確認できます。"
    },
    "TIP_UI_SHOW_BASIC_STRIP": {
        "en": "Show or hide the basic strip drawing settings. Start here for normal use: choose Draw Plane, enable Surface Snap when drawing over existing geometry, adjust Width and Extra Segments, and enable Solidify only when real thickness is needed.",
        "ja": "基本ストリップ描画設定を表示 / 非表示にします。通常はここから設定します。描画基準面を選び、既存メッシュ上に描くときは表面スナップをONにし、幅と追加分割を調整し、実際の厚みが必要なときだけ厚み付けを有効にしてください。"
    },
    "TIP_UI_SHOW_RETOPO_SETUP": {
        "en": "Show or hide the retopo setup section. Enable Ultimate Retopo only when rebuilding topology on top of another mesh, then choose the target mesh first before using the tools below.",
        "ja": "リトポ設定セクションを表示 / 非表示にします。Ultimate Retopo は別メッシュの上でトポロジーを作り直すときだけ有効にし、その後に下のツールを使う前に最初にターゲットメッシュを指定してください。"
    },
    "TIP_UI_SHOW_RETOPO_PEN": {
        "en": "Show or hide the Start Retopo Pen section. Use Start Retopo Pen when you want to place vertices one by one directly on the target surface.",
        "ja": "リトポペンを開始のセクションを表示 / 非表示にします。Start Retopo Pen はターゲット表面に頂点を1点ずつ直接置いていきたいときに使います。"
    },
    "TIP_UI_SHOW_GUIDES": {
        "en": "Show or hide the Guides section. In Edit Mode, select edges first and then register or clear them here. Stored guide edges are used to influence Quad Field Paint flow.",
        "ja": "ガイドのセクションを表示 / 非表示にします。編集モードで先に辺を選択してから、ここで登録または解除します。保存したガイド辺は Quad Field Paint の流れ方向の誘導に使われます。"
    },
    "TIP_UI_SHOW_FIELD_PAINT": {
        "en": "Show or hide the Quad Field Paint section. Use this tool when you want to paint a quad patch instead of placing points one by one. Patch Shape controls density, Flow Guidance controls direction, and Stitch / Finish controls merge and fill behavior.",
        "ja": "クアッドフィールド描画のセクションを表示 / 非表示にします。このツールは頂点を1点ずつ置く代わりに、クアッドのパッチをまとめて描きたいときに使います。パッチ形状では密度、流れの誘導では方向、ステッチ / 仕上げではマージやフィルの挙動を調整します。"
    },
    "TIP_UI_SHOW_FILL_TOOLS": {
        "en": "Show or hide the Fill / Relax / Project section. These commands operate on the current Edit Mode selection and are useful for projecting, smoothing, or rebuilding selected topology.",
        "ja": "Fill / Relax / Project セクションを表示 / 非表示にします。これらのコマンドは編集モードで現在選択中の要素に対して実行され、投影、平滑化、選択トポロジーの再構成に役立ちます。"
    },
    "TIP_UI_SHOW_BOUNDARY_TRACE": {
        "en": "Show or hide the Boundary Trace section. Use this when you want to extend topology while following an existing edge boundary or loop.",
        "ja": "境界トレースのセクションを表示 / 非表示にします。既存の境界エッジやループに沿ってトポロジーを延長したいときに使います。"
    },
    "TIP_UI_SHOW_FIELD_ADVANCED": {
        "en": "Show or hide the advanced Quad Field Paint options. Open this only when you need detailed control over edge snapping, boundary tracing, live merge, or intersection stopping.",
        "ja": "クアッドフィールド描画の詳細オプションを表示 / 非表示にします。辺スナップ、境界追従、ライブマージ、交差停止などを細かく制御したいときだけ開いてください。"
    },
    "TIP_UI_SHOW_BOUNDARY_ADVANCED": {
        "en": "Show or hide the advanced Boundary Trace options. Open this only when you need to tune snapping, lock strength, or tracing inertia.",
        "ja": "境界トレースの詳細オプションを表示 / 非表示にします。スナップ、ロック強度、追従慣性を細かく調整したいときだけ開いてください。"
    },
    "PREF_PANEL_DISPLAY": {
        "en": "Panel Display",
        "ja": "パネル表示"
    },
    "PREF_HELP_LINE_1": {
        "en": "You can change the sidebar tab name here.",
        "ja": "ここでサイドバーのタブ名を変更できます。"
    },
    "PREF_HELP_LINE_2": {
        "en": "The main panel uses foldout sections so beginners can focus on only the needed tools.",
        "ja": "メインパネルは折りたたみ式なので、初心者でも必要なツールだけに集中できます。"
    }
})


CONST_TEXT.update({
    "BTN_SETTINGS": {
        "en": "Settings...",
        "ja": "設定..."
    },
    "BTN_ADVANCED": {
        "en": "Advanced...",
        "ja": "詳細..."
    },
    "BTN_GUIDE_ACTIONS": {
        "en": "Guide Actions...",
        "ja": "ガイド操作..."
    },
    "BTN_SELECTION_TOOLS": {
        "en": "Selection Tools...",
        "ja": "選択ツール..."
    },
    "BTN_BOUNDARY_TOOLS": {
        "en": "Boundary Trace...",
        "ja": "境界トレース..."
    },
    "UI_GROUP_RETOPO_ACTIONS": {
        "en": "Retopo Tools",
        "ja": "リトポツール"
    },
    "POPUP_RETOPO_SETUP_TITLE": {
        "en": "Retopo Setup",
        "ja": "リトポ設定"
    },
    "POPUP_GUIDES_TITLE": {
        "en": "Guide Actions",
        "ja": "ガイド操作"
    },
    "POPUP_FIELD_SETTINGS_TITLE": {
        "en": "Quad Field Paint Settings",
        "ja": "クアッドフィールド描画設定"
    },
    "POPUP_FIELD_ADVANCED_TITLE": {
        "en": "Quad Field Paint Advanced",
        "ja": "クアッドフィールド描画詳細"
    },
    "POPUP_FILL_TOOLS_TITLE": {
        "en": "Fill / Relax / Project",
        "ja": "面張り / リラックス / 投影"
    },
    "POPUP_BOUNDARY_TITLE": {
        "en": "Boundary Trace",
        "ja": "境界トレース"
    },
    "POPUP_BOUNDARY_ADVANCED_TITLE": {
        "en": "Boundary Trace Advanced",
        "ja": "境界トレース 詳細"
    },
    "TIP_POPUP_RETOPO_SETUP": {
        "en": "Open the shared retopo settings in a popup. Use this to set the target mesh, projection offset, snap radius, and automatic connection behavior without expanding the main panel.",
        "ja": "共通のリトポ設定をポップアップで開きます。メインパネルを広げずに、ターゲットメッシュ、投影オフセット、スナップ半径、自動接続の挙動をまとめて調整できます。"
    },
    "TIP_POPUP_GUIDES": {
        "en": "Open guide actions in a compact popup. From here you can register selected edges as guides, clear guide flags, or reselect saved guides.",
        "ja": "ガイド操作をコンパクトなポップアップで開きます。ここから、選択中の辺をガイド登録したり、ガイド指定を解除したり、保存済みガイドを再選択できます。"
    },
    "TIP_POPUP_FIELD_SETTINGS": {
        "en": "Open the Quad Field Paint settings in a popup. Use this when you want to adjust patch width, density, flow guidance, stitch behavior, and finish options without filling the sidebar with controls.",
        "ja": "クアッドフィールド描画の設定をポップアップで開きます。サイドバーを項目で埋めずに、パッチ幅、密度、流れの誘導、ステッチ、仕上げの挙動を調整したいときに使います。"
    },
    "TIP_POPUP_FIELD_ADVANCED": {
        "en": "Open the advanced Quad Field Paint controls in a popup. Use these only when you need detailed control over edge snapping, boundary following, live merge, or intersection stopping.",
        "ja": "クアッドフィールド描画の詳細設定をポップアップで開きます。辺スナップ、境界追従、ライブマージ、交差停止を細かく調整したいときだけ使ってください。"
    },
    "TIP_POPUP_FILL_TOOLS": {
        "en": "Open the selection-based retopo tools in a popup. These commands work on the current Edit Mode selection and help you project, relax, or rebuild selected topology.",
        "ja": "選択ベースのリトポ補助ツールをポップアップで開きます。これらのコマンドは編集モードで現在選択中の要素に対して働き、投影、緩和、再構築を行います。"
    },
    "TIP_POPUP_BOUNDARY": {
        "en": "Open Boundary Trace tools in a popup. From here you can launch drag-based tracing tools and adjust the main tracing behavior without keeping a large settings block visible at all times.",
        "ja": "境界トレース系ツールをポップアップで開きます。ここからドラッグ式トレースツールを起動し、常時大きな設定欄を表示せずに基本トレース挙動を調整できます。"
    },
    "TIP_POPUP_BOUNDARY_ADVANCED": {
        "en": "Open the advanced Boundary Trace controls in a popup. Use these when you need to tune snapping range, boundary lock strength, or tracing inertia.",
        "ja": "境界トレースの詳細設定をポップアップで開きます。スナップ範囲、境界ロック強度、追従慣性を細かく調整したいときに使います。"
    },
    "BTN_SET_FROM_SELECTION": {
        "en": "Set from Selection",
        "ja": "選択から設定"
    },
    "BTN_USE_ACTIVE_TARGET": {
        "en": "Use Active Mesh",
        "ja": "アクティブを使用"
    },
    "BTN_CLEAR_TARGET": {
        "en": "Clear Target",
        "ja": "解除"
    },
    "TIP_OP_SET_TARGET_FROM_SELECTION": {
        "en": "Set the Retopo Target from the current selection. In Edit Mode, this looks for another selected mesh first, then falls back to the active mesh if it has surface polygons. Use this when the target picker feels ambiguous.",
        "ja": "現在の選択状態からリトポターゲットを設定します。編集モードでは、まず別の選択メッシュを探し、無ければ面を持つアクティブメッシュを使います。ターゲット指定が分かりづらいときに使ってください。"
    },
    "TIP_OP_USE_ACTIVE_TARGET": {
        "en": "Use the active mesh as the Retopo Target. This is useful when you want to draw directly on the current mesh or when only one mesh exists in the scene.",
        "ja": "アクティブメッシュをリトポターゲットとして使います。現在のメッシュ上に直接描きたいときや、シーン内に1つしかメッシュが無いときに便利です。"
    },
    "TIP_OP_CLEAR_TARGET": {
        "en": "Clear the current Retopo Target reference. Use this when the stored target points to the wrong object and you want to re-pick it cleanly.",
        "ja": "現在のリトポターゲット参照を解除します。保存されているターゲットが違うオブジェクトを指しているときに、一度まっさらに戻して選び直したい場合に使います。"
    },
    "UI_TARGET_STATUS_NONE": {
        "en": "Target not chosen yet.",
        "ja": "ターゲットはまだ未設定です。"
    },
    "UI_TARGET_STATUS_ACTIVE": {
        "en": "Using the active mesh as target.",
        "ja": "アクティブメッシュをターゲットとして使用中です。"
    },
    "UI_TARGET_STATUS_READY": {
        "en": "Current target is ready.",
        "ja": "現在のターゲットは使用可能です。"
    },
    "UI_TARGET_STATUS_AUTO": {
        "en": "A likely target can be auto-detected.",
        "ja": "自動検出できそうな候補があります。"
    },
    "UI_TARGET_STATUS_INVALID": {
        "en": "Stored target is invalid. Pick it again.",
        "ja": "保存済みターゲットが無効です。選び直してください。"
    }
})


CONST_TEXT.update({
    "HUD_ON": {
        "en": "ON",
        "ja": "ON"
    },
    "HUD_OFF": {
        "en": "OFF",
        "ja": "OFF"
    },
    "HUD_FIELD_HELP": {
        "en": "Quad Field Paint: LMB drag = draw | Backspace = undo | RMB/Enter = finish | ESC = cancel",
        "ja": "Quad Field Paint: 左ドラッグ = 描画 | Backspace = 1手戻す | 右クリック/Enter = 終了 | ESC = キャンセル"
    },
    "OP_GUIDES_SET_LABEL": {
        "en": "Set Guide Edges",
        "ja": "ガイド辺を登録"
    },
    "OP_GUIDES_CLEAR_LABEL": {
        "en": "Clear Guide Edges",
        "ja": "ガイド辺を解除"
    },
    "OP_GUIDES_SELECT_LABEL": {
        "en": "Select Guide Edges",
        "ja": "ガイド辺を選択"
    },
    "OP_PROJECT_SELECTED_LABEL": {
        "en": "Project Selected to Target",
        "ja": "選択をターゲットへ投影"
    },
    "OP_RELAX_PROJECT_LABEL": {
        "en": "Relax and Project Selected",
        "ja": "選択を緩和して投影"
    },
    "OP_GRID_FILL_PROJECT_LABEL": {
        "en": "Grid Fill and Project",
        "ja": "グリッドフィルして投影"
    },
    "REPORT_RUNTIME_ERROR": {
        "en": "Draw Quad Strip: {message}",
        "ja": "Draw Quad Strip: {message}"
    },
    "REPORT_RETOPO_TARGET_MISSING": {
        "en": "Retopo Target is not set. Open Retopo Setup and choose the high-poly target, or select the target mesh together with the retopo mesh before starting.",
        "ja": "リトポターゲットが未設定です。開始前に Retopo Setup でハイポリターゲットを指定するか、リトポ用メッシュと一緒にターゲットメッシュも選択してください。"
    },
    "REPORT_RETOPO_TARGET_AUTOSET": {
        "en": "Retopo Target was auto-set to: {name}",
        "ja": "リトポターゲットを自動設定しました: {name}"
    },
    "REPORT_TARGET_BUILD_FAILED": {
        "en": "Failed to build Retopo Target data. The target mesh may be invalid, hidden by evaluation, or unsupported in the current state.",
        "ja": "リトポターゲットのデータ構築に失敗しました。ターゲットメッシュが無効、評価結果で取得不能、または現在の状態では未対応の可能性があります。"
    },
    "REPORT_SELECT_MESH_FOR_RETOPO": {
        "en": "Select a mesh object first. Retopo Strip Draw will switch that mesh to Edit Mode automatically.",
        "ja": "先にメッシュオブジェクトを選択してください。Retopo Strip Draw はそのメッシュを自動で編集モードへ切り替えます。"
    },
    "REPORT_ENABLE_RETOPO_MODE": {
        "en": "Enable Retopo Mode in the panel before using retopo tools.",
        "ja": "リトポツールを使う前に、パネルで Retopo Mode を有効にしてください。"
    },
    "REPORT_GRID_FILL_FAILED": {
        "en": "Grid Fill failed: {message}",
        "ja": "Grid Fill に失敗しました: {message}"
    },
    "REPORT_VIEW3D_NOT_FOUND": {
        "en": "A 3D View region could not be found. Run this tool from a visible 3D Viewport.",
        "ja": "3Dビュー領域が見つかりませんでした。表示中の 3D ビューポートから実行してください。"
    },
    "REPORT_NO_USABLE_TARGET_SELECTION": {
        "en": "No usable mesh target was found in the current selection. Choose a mesh that has at least one face.",
        "ja": "現在の選択から有効なメッシュターゲットを見つけられませんでした。少なくとも1つ以上の面を持つメッシュを選択してください。"
    },
    "REPORT_ASSIGN_TARGET_FAILED": {
        "en": "Failed to assign the Retopo Target.",
        "ja": "リトポターゲットの設定に失敗しました。"
    },
    "REPORT_TARGET_SET": {
        "en": "Retopo Target set to: {name}",
        "ja": "リトポターゲットを設定しました: {name}"
    },
    "REPORT_ACTIVE_NOT_USABLE_TARGET": {
        "en": "The active object cannot be used as the Retopo Target. It must be a mesh with at least one face.",
        "ja": "アクティブオブジェクトはリトポターゲットとして使えません。少なくとも1つ以上の面を持つメッシュである必要があります。"
    },
    "REPORT_ASSIGN_ACTIVE_TARGET_FAILED": {
        "en": "Failed to assign the active mesh as the Retopo Target.",
        "ja": "アクティブメッシュをリトポターゲットとして設定できませんでした。"
    },
    "REPORT_TARGET_SET_ACTIVE": {
        "en": "Retopo Target set to active mesh: {name}",
        "ja": "アクティブメッシュをリトポターゲットに設定しました: {name}"
    },
    "REPORT_TARGET_CLEAR_FAILED": {
        "en": "Failed to clear the Retopo Target.",
        "ja": "リトポターゲットを解除できませんでした。"
    },
    "REPORT_TARGET_CLEARED": {
        "en": "Retopo Target cleared.",
        "ja": "リトポターゲットを解除しました。"
    },
    "REPORT_SELECT_GUIDE_EDGES": {
        "en": "Select one or more edges first, then run Set Guide Edges.",
        "ja": "先に1本以上の辺を選択してから、「ガイド辺を登録」を実行してください。"
    },
    "REPORT_SELECT_RELAX_VERTS": {
        "en": "Select one or more vertices to relax before running this command.",
        "ja": "このコマンドを実行する前に、緩和したい頂点を1つ以上選択してください。"
    },
    "REPORT_SELECT_GRID_FILL_BOUNDARY": {
        "en": "Select boundary edges for Grid Fill first. Open boundary loops work best.",
        "ja": "先に Grid Fill 用の境界辺を選択してください。開いた境界ループが最も適しています。"
    },
    "REPORT_INTERSECTION_GUARD": {
        "en": "Intersection guard stopped the stroke. Increase Tol or disable Stop on Intersect if you intentionally need tighter overlap.",
        "ja": "交差ガードがストロークを停止しました。意図的にもっと密接させたい場合は、Tol を上げるか Stop on Intersect を無効にしてください。"
    },
    "TIP_FIELD_WIDTH": {
        "en": "Overall width of the quad patch generated by Quad Field Paint, measured in centimeters. Larger values make the stroke cover a wider band on the surface. Start small when placing detail loops, and increase it when you want to lay down broader surface patches quickly.",
        "ja": "Quad Field Paint が生成するクアッドパッチ全体の幅で、単位は cm です。値を大きくすると、ストロークが表面上のより広い帯を覆います。細いディテールループを置くときは小さめ、広い面を一気に作りたいときは大きめから始めてください。"
    },
    "TIP_FIELD_COLUMNS": {
        "en": "Number of quad columns created across the patch width. Increasing this adds density across the width, which is useful for broader deformation areas. Keep it low for simple blockout, then raise it only when extra edge flow is needed.",
        "ja": "パッチの幅方向に作られるクアッド列数です。増やすほど幅方向の密度が上がるため、変形の多い広い領域に向きます。大まかな下書きでは少なめ、追加のエッジフローが必要になった段階で増やすのが扱いやすいです。"
    },
    "TIP_FIELD_SPACING_PX": {
        "en": "Screen-space spacing used while sampling the stroke. Smaller values sample the mouse path more densely and generate more geometry, while larger values produce a lighter and simpler patch. Use small spacing for tight curves and larger spacing for long smooth strokes.",
        "ja": "ストロークをサンプリングするときの画面上の間隔です。小さい値ほどマウス軌跡を細かく取り、生成ジオメトリも増えます。大きい値ほど軽くシンプルなパッチになります。きつい曲線では小さめ、長く滑らかなストロークでは大きめが向いています。"
    },
    "TIP_FIELD_SCREEN_ADAPTIVE": {
        "en": "Automatically vary sampling density using what is visible on screen. When enabled, silhouettes and curved areas receive denser sampling, which helps preserve shape where it matters most. Turn it off when you want fully predictable, uniform spacing along the whole stroke.",
        "ja": "画面上で見えている形状に応じてサンプリング密度を自動調整します。有効にすると、シルエットや曲面が強い場所でより細かくサンプリングされ、重要な形状を保ちやすくなります。ストローク全体で均一かつ予測しやすい間隔が欲しい場合はOFFにしてください。"
    },
    "TIP_FIELD_SILHOUETTE_BOOST": {
        "en": "Extra density multiplier used near silhouette areas. Raise this when the patch needs to follow an outer contour more faithfully, especially around limbs, fingers, or profile edges. Lower values keep the result lighter and more even.",
        "ja": "シルエット付近で追加される密度倍率です。手足、指、外形の輪郭線など、外周の形をより忠実に追いたいときに上げてください。低い値にすると、結果はより軽く均一になります。"
    },
    "TIP_FIELD_CURVATURE_BOOST": {
        "en": "Extra density multiplier used on strongly curved surfaces. Increase this when the patch should preserve bends, folds, or pronounced shape transitions. Reduce it if the tool is producing more density than you need on smooth surfaces.",
        "ja": "曲率の強い表面で追加される密度倍率です。曲がり、折れ、形状変化の大きい場所をしっかり残したいときに上げてください。滑らかな面で密度が増えすぎる場合は下げると扱いやすくなります。"
    },
    "TIP_FIELD_ALIGN_GUIDES": {
        "en": "Use previously registered guide edges to steer the patch flow. This is useful when you already know the desired edge-loop direction and want the generated quads to align to it. Turn it off when the patch should follow only the painted stroke and surface cues.",
        "ja": "事前に登録したガイド辺を使ってパッチの流れ方向を誘導します。狙ったエッジループ方向が決まっていて、生成されるクアッドをそこへ合わせたいときに便利です。描いたストロークと表面形状だけに従わせたい場合はOFFにしてください。"
    },
    "TIP_FIELD_GUIDE_STRENGTH": {
        "en": "How strongly the stored guide edges influence the generated patch. Low values keep the stroke behavior natural, while high values force the patch to follow the guide direction more aggressively. Start around the middle and raise it only when the flow keeps drifting away from your guides.",
        "ja": "保存済みガイド辺が生成パッチへどれだけ強く影響するかを決めます。低い値ではストローク本来の流れを残し、高い値ではガイド方向をより強く優先します。まずは中間付近から始め、流れがガイドから外れやすいときだけ上げるのが分かりやすいです。"
    },
    "TIP_FIELD_AUTO_STITCH": {
        "en": "Automatically merge or stitch the new patch into nearby existing topology when the stroke is finished. This is convenient for building connected retopo patches without manual cleanup after every stroke. Turn it off when you want to place test patches first and decide later what should be welded.",
        "ja": "ストローク終了時に、新しいパッチを近くの既存トポロジーへ自動でマージ / ステッチします。毎回手作業で後処理せず、接続されたリトポパッチを作りたいときに便利です。まずは仮配置して、後でどこを溶接するか決めたい場合はOFFにしてください。"
    },
    "TIP_FIELD_MERGE_DIST": {
        "en": "Distance threshold used by Auto Stitch when deciding whether new vertices should weld to existing ones. Larger values close gaps more aggressively, while smaller values preserve separation. Increase it only enough to catch the intended neighbors, otherwise unrelated vertices can merge together.",
        "ja": "Auto Stitch が新規頂点を既存頂点へ溶接するか判定するときの距離しきい値です。大きいほど隙間を積極的に閉じ、小さいほど独立性を保ちます。狙った近傍だけを拾える程度に少しずつ上げるのが安全で、上げすぎると無関係な頂点まで結合されます。"
    },
    "TIP_FIELD_EDGE_SNAP_PX": {
        "en": "Screen-space snapping radius for patch endpoints. Increase this when you want stroke ends to find nearby boundaries or target features more easily. Set it to 0 when you want fully free placement with no endpoint snapping assistance.",
        "ja": "パッチ端点を吸着させる画面上のスナップ半径です。ストロークの端を近くの境界や特徴点へ合わせやすくしたいときに上げてください。端点スナップ補助を使わず完全に自由配置したい場合は 0 にします。"
    },
    "TIP_FIELD_BOUNDARY_ONLY": {
        "en": "Limit endpoint snapping to boundary vertices only. This helps when you want to extend existing open topology without accidentally snapping into interior vertices. Turn it off when interior points should also be valid snap targets.",
        "ja": "端点スナップ先を境界頂点のみに制限します。既存の開いたトポロジーを延長したいときに、内部頂点へ誤って吸着しにくくなります。内部点も有効なスナップ先にしたい場合はOFFにしてください。"
    },
    "TIP_FIELD_TRACE_BOUNDARY": {
        "en": "When the stroke approaches an existing boundary, rotate the generated flow so it follows that boundary direction. This helps extend loops cleanly along openings and cut edges. Turn it off if the patch should follow only the freehand stroke direction.",
        "ja": "ストロークが既存境界に近づいたとき、生成フローをその境界方向へ合わせます。開口部や切れ目に沿ってループをきれいに延長したいときに役立ちます。手描きの方向だけを優先したい場合はOFFにしてください。"
    },
    "TIP_FIELD_EDGE_SNAP_TO_EDGES": {
        "en": "Prefer snapping to the nearest edge segment instead of only to vertices. This is useful when the target boundary is sparsely tessellated and the exact vertex positions do not line up with the place you want to connect. Disable it if snapping feels too eager along long edges.",
        "ja": "頂点だけでなく、最も近い辺セグメントへの吸着を優先します。ターゲット境界の分割が粗く、目的の位置にちょうど頂点が無い場合に便利です。長い辺に対して吸着が強すぎると感じる場合はOFFにしてください。"
    },
    "TIP_FIELD_BOUNDARY_STRENGTH": {
        "en": "Strength of the boundary-direction influence when boundary tracing is active. Lower values keep more of your painted direction, while higher values lock the patch to the detected boundary flow. Raise it when loops should hug an existing outline closely.",
        "ja": "境界追従が有効なとき、境界方向の影響度を決めます。低い値では描いた方向をより残し、高い値では検出した境界フローへ強く沿います。既存アウトラインへぴったり沿わせたいループでは高めが有効です。"
    },
    "TIP_FIELD_TANGENT_INERTIA": {
        "en": "Smoothing applied to the field tangent along the stroke. Higher values reduce jitter and sudden twists, but make the patch react more slowly to fast directional changes. Use medium values for most work, and lower it only when you need very sharp steering.",
        "ja": "ストロークに沿ったフィールド接線の平滑化量です。高い値ではジッターや急なねじれを抑えますが、方向変化への反応は遅くなります。通常は中間程度が扱いやすく、鋭い方向転換が必要なときだけ下げてください。"
    },
    "TIP_FIELD_LIVE_MERGE": {
        "en": "Try to reuse nearby existing vertices while drawing instead of creating duplicates. This keeps the result cleaner and reduces later merge-by-distance cleanup. Turn it off when you want to draft a patch freely first and weld it only after checking the shape.",
        "ja": "描画中に重複頂点を増やさず、近くの既存頂点を再利用しようとします。結果が整理されやすく、後で距離マージする手間も減ります。まずは自由にパッチを下書きし、形を見てから溶接したい場合はOFFにしてください。"
    },
    "TIP_FIELD_LIVE_MERGE_DIST": {
        "en": "Distance threshold, in centimeters, used by Live Merge while the stroke is still being created. A larger value connects more readily, and a smaller value keeps patch vertices independent until they are very close. Adjust this carefully while watching the preview so only intended connections are captured.",
        "ja": "ストローク生成中に Live Merge が使う距離しきい値で、単位は cm です。大きいほど接続されやすく、小さいほど非常に近づくまで独立した頂点のまま保たれます。プレビューを見ながら少しずつ調整し、意図した接続だけを拾うようにしてください。"
    },
    "TIP_FIELD_STOP_ON_INTERSECT": {
        "en": "Stop adding new rings when the tool detects likely self-intersection or conflicting topology in the local area. This protects the patch from folding into itself during dense strokes. Disable it only when you deliberately need to force the tool through cramped regions.",
        "ja": "局所的な自己交差や衝突しそうなトポロジーを検出したら、新しいリング生成を停止します。密なストロークでパッチが自分自身へ折り込むのを防ぐ安全装置です。狭い領域へ意図的に押し込みたい特別な場合だけOFFにしてください。"
    },
    "TIP_FIELD_INTERSECT_TOL": {
        "en": "Tolerance, in centimeters, used by the local intersection guard. Larger values treat near misses as collisions sooner, which is safer but more conservative. Smaller values allow tighter packing, but also increase the chance of overlaps slipping through.",
        "ja": "局所交差ガードが使う許容値で、単位は cm です。大きい値では、接近しただけでも早めに衝突扱いになり、安全寄りですが保守的になります。小さい値では詰めた配置ができますが、重なりを見逃す可能性も増えます。"
    },
    "TIP_FIELD_AUTO_FILL_ON_FINISH": {
        "en": "After painting, try to detect a closed boundary around the patch and fill it automatically. This is useful for turning an outlined area into a finished quad patch with one stroke. Leave it off when you only want to sketch guiding strips and fill the area manually later.",
        "ja": "描画後、パッチ周囲に閉じた境界が見つかれば自動で穴埋めを試みます。輪郭を囲った領域を、1回の操作で完成したクアッドパッチへ変えたいときに便利です。ガイド用の帯だけを描いて、穴埋めは後で手動で行いたい場合はOFFにしてください。"
    },
    "TIP_FIELD_FILL_SPAN": {
        "en": "Span value passed to Grid Fill during Auto Fill. Use it when the automatically chosen span is not giving a clean quad arrangement. 0 lets the add-on estimate a suitable value, so keep it there until you specifically need manual control.",
        "ja": "Auto Fill 時に Grid Fill へ渡す Span 値です。自動推定の Span でクアッド配置がきれいにならないときに使います。0 ではアドオンが適切な値を推定するため、必要性を感じるまでは 0 のままが分かりやすいです。"
    },
    "TIP_FIELD_FILL_RELAX_ITERS": {
        "en": "Number of relax passes applied after Auto Fill. More iterations produce a smoother and more even result, but may also soften the original shape more strongly. Start with a low value and increase it only when the fill looks too stiff or uneven.",
        "ja": "Auto Fill 後に行う Relax の反復回数です。増やすほど結果は滑らかで均一になりますが、元の形状もより強く丸められます。まずは少なめから始め、フィル結果が硬すぎる・ムラが強いと感じたときだけ増やしてください。"
    },
    "TIP_FIELD_FILL_RELAX_STRENGTH": {
        "en": "Strength of each relax pass applied after Auto Fill. Higher values smooth the filled patch more aggressively, while lower values preserve the original placement more closely. Use small values when you want cleanup without losing the stroke's original intent.",
        "ja": "Auto Fill 後に各 Relax パスがどれだけ強く効くかを決めます。高い値ほど積極的に平滑化し、低い値ほど元の配置を保ちます。描いた意図を残したまま軽く整えたい場合は小さめが向いています。"
    },
    "TIP_RETOPO_LOOP_STEP": {
        "en": "World-space distance, in centimeters, added on each boundary extension step. Larger values advance the loop farther with each sampled step, which is faster but rougher. Smaller values give you tighter control and a cleaner fit around detailed shapes.",
        "ja": "境界延長の1ステップごとに追加されるワールド空間距離で、単位は cm です。大きい値では1回のステップで大きく進むため速いですが荒くなり、小さい値では細かく制御しやすくディテールの多い形状にもきれいに沿います。"
    },
    "TIP_RETOPO_LOOP_SPACING_PX": {
        "en": "How much mouse travel is required before the next loop extension step is created. A small value reacts quickly and generates more steps, while a large value spaces the new rings farther apart. Lower it for careful tracing and raise it for long smooth sweeps.",
        "ja": "次のループ延長ステップが作られるまでに必要なマウス移動量です。小さい値では反応が速くステップ数も増え、大きい値では新しいリング間隔が広くなります。慎重なトレースでは小さめ、長く滑らかな延長では大きめが向いています。"
    },
    "TIP_RETOPO_LOOP_FLIP": {
        "en": "Reverse the outward direction used when extending the selected boundary. Use this when the preview is growing on the wrong side of the loop. It is simply a direction switch and does not change the selected source edges themselves.",
        "ja": "選択境界を延長するときの外向き方向を反転します。プレビューがループの逆側へ伸びてしまうときに使ってください。これは方向の切り替えであり、選択元の辺そのものを変更するわけではありません。"
    },
    "TIP_RETOPO_LOOP_MAKE_FACES": {
        "en": "Create quad faces between the previous boundary and each newly extended boundary while tracing. Turn this off if you want to build only guide edges first and generate faces later. For normal retopo extension work, leaving it on is usually the most convenient choice.",
        "ja": "トレース中、前の境界と新しく延長した境界の間にクアッド面を作成します。まずはガイド辺だけを作り、面は後で張りたい場合はOFFにしてください。通常のリトポ延長作業では、ONのままが最も扱いやすいです。"
    },
    "TIP_RETOPO_LOOP_MERGE_DIST": {
        "en": "Optional merge distance applied after each loop extension step. Use it to weld the newly extended result into nearby existing topology automatically. Set it to 0 when you want to keep every new step separate until the tracing is finished.",
        "ja": "各ループ延長ステップの後に適用する任意のマージ距離です。新しく延長した結果を、近くの既存トポロジーへ自動溶接したいときに使います。トレース完了まで各ステップを独立のまま保ちたい場合は 0 にしてください。"
    },
    "TIP_RETOPO_LOOP_SNAP_PX": {
        "en": "Screen-space snapping radius used while Boundary Trace looks for nearby boundary features. Increase it when the target boundary is hard to catch, and lower it when the tool keeps grabbing neighboring structures you did not intend to follow. Setting it to 0 disables this snapping helper entirely.",
        "ja": "Boundary Trace が近くの境界特徴を探すときに使う画面上のスナップ半径です。狙った境界を捕まえにくい場合は上げ、意図しない隣接構造まで拾ってしまう場合は下げてください。0 にすると、このスナップ補助を完全に無効化できます。"
    },
    "TIP_RETOPO_LOOP_LOCK_STRENGTH": {
        "en": "How strongly mouse motion is locked to the detected boundary direction. Low values allow freer steering, while high values make the trace cling to the boundary and feel steadier. Raise it when you want stable loop growth, especially along long existing borders.",
        "ja": "マウス移動を検出した境界方向へどれだけ強く固定するかを決めます。低い値では自由に操舵しやすく、高い値では境界へ強く沿って安定した挙動になります。特に長い既存境界に沿って安定してループを伸ばしたいときに上げると効果的です。"
    },
    "TIP_RETOPO_LOOP_INERTIA": {
        "en": "Smoothing applied to the tracked boundary tangent over time. Higher values suppress jitter and small hand tremors, but respond more slowly to sharp turns. Lower it when the boundary direction must react instantly, and raise it when you want calmer, cleaner tracing.",
        "ja": "追跡中の境界接線に時間方向でかける平滑化量です。高い値ではジッターや手ブレを抑えますが、急な方向転換への反応は遅くなります。境界方向へ即座に反応したいときは下げ、より穏やかでクリーンなトレースが欲しいときは上げてください。"
    },
    "TIP_RELAX_ITERATIONS": {
        "en": "Number of relax passes performed before projection. More iterations even out spacing more strongly, but can also drift the selection farther from its original shape before it is projected back. Use a low value for gentle cleanup and a higher value when the selected topology is visibly uneven.",
        "ja": "投影前に行う Relax の反復回数です。増やすほど頂点間隔はより均一になりますが、再投影前に元の形状から離れやすくもなります。軽い整えには少なめ、選択トポロジーのムラが目立つ場合は多めを使ってください。"
    },
    "TIP_RELAX_STRENGTH": {
        "en": "How strongly each relax pass moves selected vertices toward the average of their neighbors. Lower values preserve the current shape more closely, while higher values smooth more aggressively. Start low if you are unsure, then raise it only when the result still looks uneven after projection.",
        "ja": "各 Relax パスで選択頂点を周囲平均へどれだけ強く寄せるかを決めます。低い値では現在形状を残しやすく、高い値ではより積極的に平滑化されます。迷う場合は低めから始め、再投影後もムラが残るときだけ上げてください。"
    },
    "TIP_GUIDE_SELECT": {
        "en": "Choose whether the stored guide edges should become selected or deselected when this operator runs. This is helpful when you want to review guide placement visually, or clear their selection state after checking them. It does not delete the guide flags themselves.",
        "ja": "このオペレーター実行時に、保存済みガイド辺を選択するか解除するかを決めます。ガイド配置を目で確認したいときや、確認後に選択状態だけ外したいときに便利です。ガイドフラグそのものを削除するわけではありません。"
    },
    "TIP_GRID_FILL_SPAN": {
        "en": "Span value passed to Blender's Grid Fill. 0 lets the operator estimate a suitable span automatically from the selected boundary, which is usually the easiest starting point. Set a manual value only when the default fill layout twists or distributes quads in an undesirable way.",
        "ja": "Blender の Grid Fill に渡す Span 値です。0 では選択境界から適切な値を自動推定するため、まずはそのまま使うのが最も簡単です。既定レイアウトでクアッドの並びがねじれる、または望まない分布になる場合だけ手動値を指定してください。"
    }
})

def _EN(key: str) -> str:
    return CONST_TEXT.get(key, {}).get("en", key)

def _T(key: str) -> str:
    try:
        lang = bpy.context.preferences.view.language
        if lang == "ja_JP":
            return CONST_TEXT.get(key, {}).get("ja", key)
    except Exception:
        pass
    return _EN(key)


def _TT(key: str, **kwargs) -> str:
    text = _T(key)
    if kwargs:
        try:
            return text.format(**kwargs)
        except Exception:
            return text
    return text

def _build_translation_dict():
    pairs = {}
    for data in CONST_TEXT.values():
        en = data.get("en")
        ja = data.get("ja")
        if en and ja:
            pairs[("*", en)] = ja

    extra_pairs = {
        "Cols": "列",
        "Spacing(px)": "間隔(px)",
        "Sil Boost": "シル強調",
        "Curv Boost": "曲率強調",
        "Strength": "強さ",
        "Merge Dist": "マージ距離",
        "EdgeSnap(px)": "辺スナップ(px)",
        "Boundary": "境界",
        "Trace": "追従",
        "To Edges": "辺へ",
        "B Strength": "境界強度",
        "Inertia": "慣性",
        "Live Merge": "ライブマージ",
        "Dist": "距離",
        "StopIntersect": "交差停止",
        "Tol": "許容値",
        "Auto Fill": "自動フィル",
        "Span": "Span",
        "Step": "ステップ",
        "Flip": "反転",
        "Make Faces": "面を作成",
        "Lock": "ロック",
    }
    for en, ja in extra_pairs.items():
        pairs[("*", en)] = ja

    return {"ja_JP": pairs}

# bl_info description動的書き換え用の専用辞書（元の翻訳機能を壊さないため）
bl_info_translation_dict = _build_translation_dict()

# ============================================================
# 1) Preferences (設定画面)
# ============================================================

_QSD_STANDALONE_PANEL_IDS = ('VIEW3D_PT_quad_strip_draw_final', 'VIEW3D_PT_sms_quad_strip_draw')


def _qsd_unregister_standalone_panels():
    for panel_id in _QSD_STANDALONE_PANEL_IDS:
        cls = globals().get(panel_id)
        if isinstance(cls, type) and _qsd_owned_class(cls):
            _qsd_safe_unregister_class(cls)

def update_panel_category(self, context):
    _qsd_unregister_standalone_panels()
    try:
        for area in getattr(getattr(context, 'screen', None), 'areas', ()):
            if getattr(area, 'type', '') == 'VIEW_3D':
                area.tag_redraw()
    except Exception:
        pass

class QSD_AddonPreferences(PropertyGroup):
    bl_idname = __name__

    category_name: StringProperty(
        name=_EN("LBL_TAB_NAME"),
        description=_EN("TIP_PREF_CATEGORY"),
        default="Quad Retopo",
        update=update_panel_category
    )

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        box = layout.box()
        box.label(text=_T("PREF_PANEL_DISPLAY"), icon="PREFERENCES")
        box.prop(self, "category_name")

# ============================================================
# 2) Global Helpers
# ============================================================
_WM_FLAG_NAME = "safe_qsd_running"
_WM_STOP_FLAG_NAME = "safe_qsd_stop_requested"
_QSD_DRAW_TOGGLE_SYNC = False
_QSD_PENDING_TOGGLE_START = False

def _wm_get_running(context) -> bool:
    return bool(getattr(context.window_manager, _WM_FLAG_NAME, False))

def _wm_set_running(context, state: bool):
    if not hasattr(bpy.types.WindowManager, _WM_FLAG_NAME):
        try:
            bpy.types.WindowManager.safe_qsd_running = BoolProperty(name="QSD Running", description="Internal runtime flag for Draw Quad Strip.", default=False)
        except Exception:
            pass
    try:
        setattr(context.window_manager, _WM_FLAG_NAME, bool(state))
    except Exception:
        pass

def _wm_get_stop_requested(context) -> bool:
    return bool(getattr(context.window_manager, _WM_STOP_FLAG_NAME, False))

def _wm_set_stop_requested(context, state: bool):
    if not hasattr(bpy.types.WindowManager, _WM_STOP_FLAG_NAME):
        try:
            bpy.types.WindowManager.safe_qsd_stop_requested = BoolProperty(name="QSD Stop Requested", description="Internal stop request flag for Draw Quad Strip.", default=False)
        except Exception:
            pass
    try:
        setattr(context.window_manager, _WM_STOP_FLAG_NAME, bool(state))
    except Exception:
        pass

def _find_view3d_override(context=None):
    ctx = context or bpy.context
    try:
        window = getattr(ctx, "window", None)
        area = getattr(ctx, "area", None)
        region = getattr(ctx, "region", None)
        if window and area and area.type == 'VIEW_3D':
            if region is None or region.type != 'WINDOW':
                region = next((r for r in area.regions if r.type == 'WINDOW'), None)
            if region is not None:
                return {"window": window, "screen": window.screen, "area": area, "region": region}
    except Exception:
        pass

    wm = getattr(bpy.context, "window_manager", None)
    if wm is None:
        return None
    for window in wm.windows:
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        for area in screen.areas:
            if area.type != 'VIEW_3D':
                continue
            region = next((r for r in area.regions if r.type == 'WINDOW'), None)
            if region is not None:
                return {"window": window, "screen": screen, "area": area, "region": region}
    return None

def _scene_get_draw_toggle(context) -> bool:
    try:
        scn = getattr(context, "scene", None)
        if scn is not None and hasattr(scn, "qsd_draw_toggle"):
            return bool(scn.qsd_draw_toggle)
    except Exception:
        pass
    return False

def _scene_sync_draw_toggle(context, state: bool):
    global _QSD_DRAW_TOGGLE_SYNC
    scn = getattr(context, "scene", None)
    if scn is None or not hasattr(scn, "qsd_draw_toggle"):
        return
    try:
        _QSD_DRAW_TOGGLE_SYNC = True
        scn.qsd_draw_toggle = bool(state)
    except Exception:
        pass
    finally:
        _QSD_DRAW_TOGGLE_SYNC = False

def _qsd_start_from_toggle(context=None) -> bool:
    override = _find_view3d_override(context)
    if override is None:
        if context is not None:
            _scene_sync_draw_toggle(context, False)
        else:
            try:
                bpy.context.scene.qsd_draw_toggle = False
            except Exception:
                pass
        return False
    try:
        with bpy.context.temp_override(**override):
            result = bpy.ops.mesh.quad_strip_draw('INVOKE_DEFAULT')
        ok = 'RUNNING_MODAL' in result or 'FINISHED' in result
        if not ok:
            if context is not None:
                _scene_sync_draw_toggle(context, False)
            else:
                try:
                    bpy.context.scene.qsd_draw_toggle = False
                except Exception:
                    pass
        return ok
    except Exception:
        if context is not None:
            _scene_sync_draw_toggle(context, False)
        else:
            try:
                bpy.context.scene.qsd_draw_toggle = False
            except Exception:
                pass
        return False

def _qsd_schedule_toggle_start():
    global _QSD_PENDING_TOGGLE_START
    if _QSD_PENDING_TOGGLE_START:
        return
    _QSD_PENDING_TOGGLE_START = True

    def _run():
        global _QSD_PENDING_TOGGLE_START
        _QSD_PENDING_TOGGLE_START = False
        try:
            ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
            if isinstance(ns, dict) and bool(ns.get('SMART_MODELING_SUITE_SHUTTING_DOWN')):
                return None
        except Exception:
            return None
        try:
            ctx = bpy.context
            scn = getattr(ctx, "scene", None)
            if scn is None or not hasattr(scn, "qsd_draw_toggle"):
                return None
            if not bool(scn.qsd_draw_toggle):
                return None
            if _wm_get_running(ctx):
                return None
            _qsd_start_from_toggle(ctx)
        except Exception:
            try:
                bpy.context.scene.qsd_draw_toggle = False
            except Exception:
                pass
        return None

    try:
        bpy.app.timers.register(_run, first_interval=0.01)
    except Exception:
        _QSD_PENDING_TOGGLE_START = False

def _qsd_update_draw_toggle(self, context):
    global _QSD_DRAW_TOGGLE_SYNC
    if _QSD_DRAW_TOGGLE_SYNC:
        return


    # Keep the visible N-panel toggle in the suite's canonical JSON even
    # though its semantic callback also starts/stops a modal drawing tool.
    try:
        from .. import common as _suite_common
        _suite_common.save_persistent_settings(context, force=False)
    except Exception:
        pass

    desired = bool(getattr(self, "qsd_draw_toggle", False))
    try:
        wm = getattr(context, 'window_manager', None)
        area = getattr(context, 'area', None)
        if desired and (wm is None or (area is not None and getattr(area, 'type', None) != 'VIEW_3D')):
            _QSD_DRAW_TOGGLE_SYNC = True
            try:
                setattr(self, "qsd_draw_toggle", False)
            finally:
                _QSD_DRAW_TOGGLE_SYNC = False
            return
    except Exception:
        return

    running = _wm_get_running(context)

    if desired:
        if not running:
            _qsd_schedule_toggle_start()
        return

    if running:
        _wm_set_stop_requested(context, True)
        _force_redraw_view3d()

def _force_redraw_view3d():
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

def _cm_to_bu(value: float) -> float:
    return float(value) * 0.01

def _bu_to_cm(value: float) -> float:
    return float(value) * 100.0

# ------------------------------------------------------------
# BLF compatibility (Blender 5.x changed blf.size signature)
# ------------------------------------------------------------
def _blf_size(font_id: int, size: int, dpi: int = 72):
    """Call blf.size with Blender-version compatible signature."""
    try:
        blf.size(font_id, size, dpi)
    except TypeError:
        blf.size(font_id, size)

# ------------------------------------------------------------
# Cursor warp helper (cross-platform; avoids OS-specific ctypes)
# We use Blender's window.cursor_warp when needed.
# ------------------------------------------------------------
def _cursor_warp(window, x, y):
    try:
        window.cursor_warp(int(x), int(y))
    except Exception:
        pass

def _get_region_under_mouse(area, x, y):
    """Mouse coordinates x, y are absolute window coordinates."""
    if not area: return None
    for region in area.regions:
        if region.type == 'WINDOW':
            # Check if mouse is within region bounds
            if (region.x <= x < region.x + region.width) and \
               (region.y <= y < region.y + region.height):
                return region
    return None

# ============================================================
# 3) Math & Geometry Logic
# ============================================================

def _get_view_vector(rv3d):
    # Modified to take rv3d directly for Quad View support
    return (rv3d.view_rotation @ Vector((0.0, 0.0, -1.0))).normalized()

def _get_mouse_ray(region, rv3d, mouse_xy):
    # Modified to take region and rv3d directly for Quad View support
    origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, mouse_xy)
    direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, mouse_xy)
    return origin, direction

def _ray_cast_plane_intersection(ray_origin, ray_dir, plane_point, plane_normal):
    return geometry.intersect_line_plane(ray_origin, ray_origin + ray_dir * 10000.0, plane_point, plane_normal, False)

def _bezier_quad(p0, p1, p2, t):
    return (1-t)**2 * p0 + 2*(1-t)*t * p1 + t**2 * p2

class StripCalculator:
    @staticmethod
    def calc_ribbon_points(
        p_start, p_end, n_start, n_end, 
        w_start, w_end, 
        subdivisions, 
        prev_tangent, prev_side_vec
    ):
        dist = (p_end - p_start).length
        steps = max(1, subdivisions + 1)
        
        center_points = []
        t0 = prev_tangent if prev_tangent else ((p_end - p_start).normalized() if dist > 0 else Vector((1,0,0)))
        
        if subdivisions > 0:
            cp = p_start + t0 * (dist * 0.4)
            SAMPLE_RES = 32
            raw_bezier = [_bezier_quad(p_start, cp, p_end, i/SAMPLE_RES) for i in range(SAMPLE_RES+1)]
            lens = [0.0]
            for i in range(1, len(raw_bezier)):
                lens.append(lens[-1] + (raw_bezier[i] - raw_bezier[i-1]).length)
            total_len = lens[-1]
            
            for i in range(steps + 1):
                target_d = total_len * (i / steps)
                idx = 0
                for k in range(len(lens)-1):
                    if lens[k] <= target_d <= lens[k+1]:
                        idx = k
                        break
                span = lens[idx+1] - lens[idx]
                local_t = (target_d - lens[idx]) / span if span > 1e-8 else 0
                real_t = (idx + local_t) / SAMPLE_RES
                
                pos = _bezier_quad(p_start, cp, p_end, real_t)
                norm = n_start.lerp(n_end, real_t).normalized()
                center_points.append({'pos': pos, 'norm': norm, 't_fac': i/steps})
        else:
            for i in range(steps + 1):
                t = i / steps
                pos = p_start.lerp(p_end, t)
                norm = n_start.lerp(n_end, t).normalized()
                center_points.append({'pos': pos, 'norm': norm, 't_fac': t})

        results = []
        count = len(center_points)
        
        for i in range(count):
            pt = center_points[i]
            pos = pt['pos']
            norm = pt['norm']
            t_fac = pt['t_fac']
            
            if i == 0: tan_in = t0
            else: tan_in = (pos - center_points[i-1]['pos']).normalized()
                
            if i == count - 1: tan_out = tan_in 
            else:
                diff = center_points[i+1]['pos'] - pos
                if diff.length_squared > 1e-8: tan_out = diff.normalized()
                else: tan_out = tan_in

            avg_tan = (tan_in + tan_out).normalized()
            if avg_tan.length_squared < 1e-6: avg_tan = tan_in 
            
            side = norm.cross(avg_tan).normalized()
            eff_tangent = tan_out if i < count-1 else tan_in
            current_w = w_start * (1 - t_fac) + w_end * t_fac
            
            p_l = pos + side * (current_w * 0.5)
            p_r = pos - side * (current_w * 0.5)
            
            results.append({
                'l': p_l, 'r': p_r, 
                'pos': pos, 'norm': norm, 'tan': eff_tangent, 'side': side,
                'width': current_w
            })
            
        return results

# ============================================================
# Draw snapshots
# ============================================================

class _QSDDrawSnapshot:
    """Operator-owned immutable view consumed by the two draw callbacks."""

    __slots__ = (
        "shader",
        "tris_batch",
        "lines_batch",
        "points_batch",
        "hud_lines",
    )

    def __init__(self, shader=None):
        self.shader = shader
        self.tris_batch = None
        self.lines_batch = None
        self.points_batch = None
        self.hud_lines = ()

    def clear_geometry(self):
        self.tris_batch = None
        self.lines_batch = None
        self.points_batch = None

    def clear(self):
        self.clear_geometry()
        self.hud_lines = ()


def _qsd_draw_scene(snapshot):
    """Draw prebuilt batches only; no BMesh/RNA/BVH/batch construction."""
    if snapshot is None:
        return
    shader = snapshot.shader
    if shader is None:
        return
    tris_batch = snapshot.tris_batch
    lines_batch = snapshot.lines_batch
    points_batch = snapshot.points_batch
    if tris_batch is None and lines_batch is None and points_batch is None:
        return
    try:
        shader.bind()
        gpu.state.depth_test_set('LESS_EQUAL')
        gpu.state.blend_set('ALPHA')
        if tris_batch is not None:
            shader.uniform_float('color', (0.2, 0.8, 1.0, 0.4))
            tris_batch.draw(shader)
        if lines_batch is not None:
            shader.uniform_float('color', (0.0, 0.0, 0.0, 1.0))
            lines_batch.draw(shader)
        if points_batch is not None:
            gpu.state.point_size_set(8.0)
            shader.uniform_float('color', (1.0, 0.85, 0.1, 0.95))
            points_batch.draw(shader)
    except Exception:
        return
    finally:
        try:
            gpu.state.point_size_set(1.0)
        except Exception:
            pass
        try:
            gpu.state.blend_set('NONE')
        except Exception:
            pass
        try:
            gpu.state.depth_test_set('NONE')
        except Exception:
            pass


def _qsd_draw_hud(snapshot):
    """Draw cached localized HUD strings only."""
    if snapshot is None or not snapshot.hud_lines:
        return
    try:
        font_id = 0
        _blf_size(font_id, 16)
        blf.color(font_id, 1, 1, 1, 1)
        x, y, line_height = 60, 100, 20
        for index, line in enumerate(reversed(snapshot.hud_lines)):
            blf.position(font_id, x, y + index * line_height, 0)
            blf.draw(font_id, line)
    except Exception:
        return


# ============================================================
# 4) Main Operator
# ============================================================
class MESH_OT_quad_strip_draw(Operator):
    bl_idname = "mesh.quad_strip_draw"
    bl_label = "Draw Quad Strip"
    bl_description = _EN("TIP_OP_START")
    bl_options = {"UNDO", "BLOCKING"}

    qsd_retopo_pen_mode: BoolProperty(default=False, description="Internal flag used to route Retopo Strip Draw through the main strip operator.", options={'HIDDEN', 'SKIP_SAVE'})
    stop_running: BoolProperty(default=False, description="Internal flag used to stop the running strip drawing session.", options={'HIDDEN', 'SKIP_SAVE'})

    _draw_handle = None
    _draw_handle_hud = None
    _draw_state = 0 
    
    _start_co = None
    _current_co = None
    _start_norm = None
    _current_norm = None
    _start_width = 1.0
    _start_thickness = 0.1
    _prev_elem_data = None 
    _history = []
    
    _cursor_locked = False
    _cursor_lock_xy = (0,0)
    
    _locked_solidify = None

    # Quad View / Region Support
    _active_region = None
    _active_rv3d = None

    
    def _init_settings(self, context, obj):
        scn = context.scene
        self.width = _cm_to_bu(scn.qsd_width)
        self.thickness = _cm_to_bu(scn.qsd_thickness)
        self.subdivisions = scn.qsd_subdivisions
        self.use_solidify = scn.qsd_use_solidify
        self.plane_mode = scn.qsd_plane_mode
        self.use_snap = scn.qsd_use_surface_snap

        self.obj = obj
        self.bm = bmesh.from_edit_mesh(self.obj.data)

        self._history = []
        self._prev_elem_data = None
        self._shader = gpu.shader.from_builtin("UNIFORM_COLOR")
        # Draw callbacks receive only this operator-owned snapshot.  All BMesh,
        # BVH, coordinate and GPU-batch work remains in modal/operator code.
        self._draw_snapshot = _QSDDrawSnapshot(self._shader)
        self._preview_batch_tris = None
        self._preview_batch_lines = None
        self._preview_batch_points = None
        self._preview_merge_points = []
        self._preview_signature = None
        self._preview_revision = 0
        self._merge_kdtree = None
        self._merge_kd_verts = ()
        self._merge_recent_verts = []
        self._merge_cache_dirty = True
        self._merge_matrix_signature = None
        self._locked_solidify = None

        self._start_width = self.width
        self._start_thickness = self.thickness
        self._active_region = None
        self._active_rv3d = None
        self._nav_passthrough = False
        self._scene_ref = scn

        self._retopo_pen_mode = bool(getattr(self, "qsd_retopo_pen_mode", False) or getattr(scn, "qsd_retopo_mode", False))
        self._tgt_eval = None
        self._tgt_mesh = None
        self._tgt_bvh = None
        self._retopo_target_obj = None
        self._preview_merge_points = []
        if self._retopo_pen_mode:
            # Retopo strips are intended to stay as flat quads projected to the target.
            self.use_solidify = False
            self.use_snap = True

    def _safe_face_new(self, bm, verts):
        if not verts:
            return None
        ids = set()
        for v in verts:
            if v is None or not getattr(v, "is_valid", False):
                return None
            vid = id(v)
            if vid in ids:
                return None
            ids.add(vid)
        try:
            return bm.faces.new(tuple(verts))
        except ValueError:
            return None

    def _merge_enabled_live(self):
        scn = getattr(self, "_scene_ref", None)
        if scn is None:
            return False
        if self.use_solidify:
            return False
        return bool(getattr(scn, "qsd_strip_vertex_merge", True))

    def _merge_distance_live(self):
        scn = getattr(self, "_scene_ref", None)
        if scn is None:
            return 0.0
        return _cm_to_bu(getattr(scn, "qsd_strip_vertex_merge_distance", 0.0))

    def _mark_merge_spatial_cache_dirty(self):
        self._merge_cache_dirty = True
        self._merge_kdtree = None
        self._merge_kd_verts = ()
        self._merge_matrix_signature = None

    def _object_matrix_signature(self):
        try:
            return tuple(float(value) for row in self.obj.matrix_world for value in row)
        except Exception:
            return ()

    def _ensure_merge_spatial_cache(self):
        """Build a KDTree only when edit geometry or object space changes."""
        if not self._merge_enabled_live() or self._merge_distance_live() <= 0.0:
            return False
        matrix_signature = self._object_matrix_signature()
        if (
            not self._merge_cache_dirty
            and self._merge_kdtree is not None
            and matrix_signature == self._merge_matrix_signature
        ):
            return True

        try:
            verts = tuple(v for v in self.bm.verts if v.is_valid)
            tree = KDTree(len(verts))
            matrix_world = self.obj.matrix_world
            for index, vert in enumerate(verts):
                tree.insert(matrix_world @ vert.co, index)
            tree.balance()
        except Exception:
            self._mark_merge_spatial_cache_dirty()
            return False

        self._merge_kdtree = tree
        self._merge_kd_verts = verts
        self._merge_recent_verts = []
        self._merge_cache_dirty = False
        self._merge_matrix_signature = matrix_signature
        return True

    def _find_connect_candidate(self, local_co, exclude=None):
        if not self._merge_enabled_live():
            return None
        max_dist = self._merge_distance_live()
        if max_dist <= 0.0 or not self._ensure_merge_spatial_cache():
            return None

        exclude_ids = {id(v) for v in (exclude or ()) if v is not None}
        try:
            target_world = self.obj.matrix_world @ local_co
            matches = self._merge_kdtree.find_range(target_world, max_dist)
        except Exception:
            return None

        best = None
        best_distance = float('inf')
        best_order = -1
        tie_epsilon = 1.0e-12
        verts = self._merge_kd_verts
        for _co, index, distance in matches:
            try:
                order = int(index)
                vert = verts[order]
                if not vert.is_valid or id(vert) in exclude_ids:
                    continue
                distance = float(distance)
            except Exception:
                continue
            if (
                distance < best_distance - tie_epsilon
                or (abs(distance - best_distance) <= tie_epsilon and order >= best_order)
            ):
                best = vert
                best_distance = distance
                best_order = order

        # KDTree is deliberately rebuilt once per committed geometry revision.
        # Vertices created during the current commit are kept in this small list
        # so later points in the same strip step still see them.  Equal-distance
        # ties choose the later BMesh iteration entry, matching the previous
        # full-scan ``<=`` behavior while avoiding a full scan per point.
        base_order = len(verts)
        for recent_index, vert in enumerate(tuple(getattr(self, '_merge_recent_verts', ()))):
            try:
                if not vert.is_valid or id(vert) in exclude_ids:
                    continue
                distance = float((self.obj.matrix_world @ vert.co - target_world).length)
                order = base_order + recent_index
            except Exception:
                continue
            if distance <= max_dist and (
                distance < best_distance - tie_epsilon
                or (abs(distance - best_distance) <= tie_epsilon and order >= best_order)
            ):
                best = vert
                best_distance = distance
                best_order = order
        return best

    def _get_or_create_vert(self, bm, local_co, exclude=None):
        existing = self._find_connect_candidate(local_co, exclude=exclude)
        if existing is not None:
            return existing, True
        created = bm.verts.new(local_co)
        self._merge_recent_verts.append(created)
        return created, False

    def _preview_resolve_local(self, local_co, exclude=None):
        existing = self._find_connect_candidate(local_co, exclude=exclude)
        if existing is not None and existing.is_valid:
            return self.obj.matrix_world @ existing.co, existing, True
        return self.obj.matrix_world @ local_co, None, False

    def _find_anchor_snap(self, context, region, rv3d, mouse_xy):
        if not getattr(self, "_retopo_pen_mode", False):
            return None, None
        snap_px = max(0, int(getattr(context.scene, "qsd_retopo_snap_radius", 0)))
        if snap_px <= 0:
            return None, None
        bm = self.bm
        try:
            bm.verts.ensure_lookup_table()
        except Exception:
            pass
        best_v = None
        best_d = float('inf')
        for v in bm.verts:
            if not v.is_valid:
                continue
            p2 = view3d_utils.location_3d_to_region_2d(region, rv3d, self.obj.matrix_world @ v.co)
            if p2 is None:
                continue
            d = (p2 - Vector(mouse_xy)).length
            if d < best_d:
                best_d = d
                best_v = v
        if best_v is None or best_d > snap_px:
            return None, None
        n = best_v.normal.copy() if best_v.normal.length_squared > 1.0e-10 else Vector((0.0, 0.0, 1.0))
        n = (self.obj.matrix_world.to_3x3() @ n).normalized()
        return self.obj.matrix_world @ best_v.co, n

    def _get_target_plane(self, context, origin_point=Vector((0,0,0))):
        mode = self.plane_mode
        if mode == 'VIEW':
            # Use stored rv3d instead of context
            if self._active_rv3d:
                view_vec = _get_view_vector(self._active_rv3d)
                return origin_point, -view_vec
            else:
                return origin_point, Vector((0,0,1))
        elif mode == 'X': return origin_point, Vector((1,0,0))
        elif mode == 'Y': return origin_point, Vector((0,1,0))
        elif mode == 'Z': return origin_point, Vector((0,0,1))
        return origin_point, Vector((0,0,1))

    def _get_mouse_location(self, context, mouse_xy):
        # We need a valid region to raycast
        if not self._active_region or not self._active_rv3d:
            return Vector((0,0,0)), Vector((0,0,1))

        ray_origin, ray_dir = _get_mouse_ray(self._active_region, self._active_rv3d, mouse_xy)
        if getattr(self, "_retopo_pen_mode", False) and self._retopo_target_obj and self._tgt_bvh:
            snap_loc, snap_norm = self._find_anchor_snap(context, self._active_region, self._active_rv3d, mouse_xy)
            loc_w, n_w, dist = _qsd_target_raycast(
                self._retopo_target_obj,
                self._tgt_bvh,
                ray_origin,
                ray_dir,
                frontface_only=context.scene.qsd_retopo_frontface_only,
            )
            maxd = _cm_to_bu(getattr(context.scene, "qsd_retopo_project_max_dist", 0.0))
            if loc_w is not None and maxd > 0.0 and dist is not None and dist > maxd:
                loc_w = None
            if snap_loc is not None:
                return snap_loc, (snap_norm if snap_norm is not None else (n_w if n_w is not None else Vector((0, 0, 1))))
            if loc_w is not None and n_w is not None:
                offset = _cm_to_bu(getattr(context.scene, "qsd_retopo_offset", 0.0))
                return loc_w + n_w * offset, n_w
            fallback_loc = self._current_co or self._start_co
            fallback_norm = self._current_norm or self._start_norm
            if fallback_loc is not None and fallback_norm is not None:
                return fallback_loc.copy(), fallback_norm.copy()
            return Vector((0,0,0)), Vector((0,0,1))
        if self.use_snap:
            depsgraph = context.evaluated_depsgraph_get()
            hit, loc, norm, _, _, _ = context.scene.ray_cast(depsgraph, ray_origin, ray_dir, distance=10000.0)
            if hit: return loc, norm
        anchor = self._start_co if self._start_co else (self.obj.matrix_world.translation if self.obj else Vector((0,0,0)))
        p_pt, p_norm = self._get_target_plane(context, anchor)
        loc = _ray_cast_plane_intersection(ray_origin, ray_dir, p_pt, p_norm)
        if loc: return loc, p_norm
        return Vector((0,0,0)), Vector((0,0,1))

    def _calculate_bisect_side_vector(self, prev_tan, curr_tan, normal):
        avg_tan = (prev_tan + curr_tan).normalized()
        if avg_tan.length_squared < 0.001: avg_tan = curr_tan 
        side = normal.cross(avg_tan).normalized()
        return side

    def _update_previous_joint_bmesh(self, bm, current_tan_start):
        if not self._prev_elem_data: return
        prev_data = self._prev_elem_data
        prev_tan = prev_data['tangent']
        norm = prev_data['normal']
        new_side = self._calculate_bisect_side_vector(prev_tan, current_tan_start, norm)
        
        verts = [v for v in prev_data['verts'] if v.is_valid]
        if not verts: return
        
        center = prev_data['center']
        half_w = prev_data['width'] * 0.5
        mat_inv = self.obj.matrix_world.inverted()
        
        if self.use_solidify and len(verts) == 4:
            tl, tr, bl, br = verts
            half_th = prev_data['thickness'] * 0.5
            th_vec = norm * half_th
            tl.co = mat_inv @ (center + new_side * half_w + th_vec)
            tr.co = mat_inv @ (center - new_side * half_w + th_vec)
            bl.co = mat_inv @ (center + new_side * half_w - th_vec)
            br.co = mat_inv @ (center - new_side * half_w - th_vec)
        elif len(verts) == 2:
            l, r = verts
            l.co = mat_inv @ (center + new_side * half_w)
            r.co = mat_inv @ (center - new_side * half_w)
            
        bmesh.update_edit_mesh(self.obj.data, loop_triangles=True, destructive=True)
        self._mark_merge_spatial_cache_dirty()
        self._preview_revision += 1
        self._prev_elem_data['side'] = new_side

    def _create_geometry_step(self):
        if not self._start_co or not self._current_co: return
        self._merge_recent_verts = []
        
        prev_tan = self._prev_elem_data['tangent'] if self._prev_elem_data else None
        prev_side = self._prev_elem_data['side'] if self._prev_elem_data else None
        
        strip_points = StripCalculator.calc_ribbon_points(
            self._start_co, self._current_co,
            self._start_norm, self._current_norm,
            self._start_width, self.width,
            self.subdivisions,
            prev_tan, prev_side
        )
        if not strip_points: return

        current_start_tan = strip_points[0]['tan']
        if self._prev_elem_data and not (getattr(self, "_retopo_pen_mode", False) and self._prev_elem_data.get("locked", False)):
            self._update_previous_joint_bmesh(self.bm, current_start_tan)
            start_side = self._prev_elem_data['side']
        else:
            start_side = strip_points[0]['side']

        bm = self.bm
        mat_inv = self.obj.matrix_world.inverted()
        created_faces = []
        last_verts_dict = {}
        
        if self._prev_elem_data:
            p_verts = self._prev_elem_data['verts']
            if self.use_solidify and len(p_verts) == 4:
                last_verts_dict = {'tl': p_verts[0], 'tr': p_verts[1], 'bl': p_verts[2], 'br': p_verts[3]}
            elif not self.use_solidify and len(p_verts) == 2:
                last_verts_dict = {'l': p_verts[0], 'r': p_verts[1]}
        else:
            first_pt = strip_points[0]
            c, s, w = first_pt['pos'], start_side, first_pt['width']
            if self.use_solidify:
                th_vec = first_pt['norm'] * (self._start_thickness * 0.5)
                used = []
                v_tl, _ = self._get_or_create_vert(bm, mat_inv @ (c + s*(w*0.5) + th_vec), used)
                used.append(v_tl)
                v_tr, _ = self._get_or_create_vert(bm, mat_inv @ (c - s*(w*0.5) + th_vec), used)
                used.append(v_tr)
                v_bl, _ = self._get_or_create_vert(bm, mat_inv @ (c + s*(w*0.5) - th_vec), used)
                used.append(v_bl)
                v_br, _ = self._get_or_create_vert(bm, mat_inv @ (c - s*(w*0.5) - th_vec), used)
                last_verts_dict = {'tl': v_tl, 'tr': v_tr, 'bl': v_bl, 'br': v_br}
            else:
                used = []
                v_l, _ = self._get_or_create_vert(bm, mat_inv @ (c + s*(w*0.5)), used)
                used.append(v_l)
                v_r, _ = self._get_or_create_vert(bm, mat_inv @ (c - s*(w*0.5)), used)
                last_verts_dict = {'l': v_l, 'r': v_r}

        thick_start = self._start_thickness
        thick_end = self.thickness
        total_len_pts = len(strip_points)
        
        for i in range(1, total_len_pts):
            pt = strip_points[i]
            t_fac = i / (total_len_pts - 1)
            curr_th = thick_start*(1-t_fac) + thick_end*t_fac
            c, s, w, n = pt['pos'], pt['side'], pt['width'], pt['norm']
            
            if self.use_solidify:
                th_vec = n * (curr_th * 0.5)
                nt = c + th_vec
                nb = c - th_vec
                prev = last_verts_dict
                used = [prev['tl'], prev['tr'], prev['bl'], prev['br']]
                v_tl, _ = self._get_or_create_vert(bm, mat_inv @ (nt + s * (w*0.5)), used)
                used.append(v_tl)
                v_tr, _ = self._get_or_create_vert(bm, mat_inv @ (nt - s * (w*0.5)), used)
                used.append(v_tr)
                v_bl, _ = self._get_or_create_vert(bm, mat_inv @ (nb + s * (w*0.5)), used)
                used.append(v_bl)
                v_br, _ = self._get_or_create_vert(bm, mat_inv @ (nb - s * (w*0.5)), used)
                for verts in [
                    (prev['tl'], prev['tr'], v_tr, v_tl),
                    (prev['br'], prev['bl'], v_bl, v_br),
                    (prev['bl'], prev['tl'], v_tl, v_bl),
                    (prev['tr'], prev['br'], v_br, v_tr),
                ]:
                    face = self._safe_face_new(bm, verts)
                    if face is not None:
                        created_faces.append(face)
                last_verts_dict = {'tl': v_tl, 'tr': v_tr, 'bl': v_bl, 'br': v_br}
            else:
                prev = last_verts_dict
                used = [prev['l'], prev['r']]
                v_l, _ = self._get_or_create_vert(bm, mat_inv @ (c + s * (w*0.5)), used)
                used.append(v_l)
                v_r, _ = self._get_or_create_vert(bm, mat_inv @ (c - s * (w*0.5)), used)
                face = self._safe_face_new(bm, (prev['l'], prev['r'], v_r, v_l))
                if face is not None:
                    created_faces.append(face)
                last_verts_dict = {'l': v_l, 'r': v_r}

        bmesh.ops.recalc_face_normals(bm, faces=created_faces)
        bmesh.update_edit_mesh(self.obj.data, loop_triangles=True, destructive=True)
        self._mark_merge_spatial_cache_dirty()
        self._preview_revision += 1

        last_pt = strip_points[-1]
        if self.use_solidify:
            saved_verts = [last_verts_dict['tl'], last_verts_dict['tr'], last_verts_dict['bl'], last_verts_dict['br']]
        else:
            saved_verts = [last_verts_dict['l'], last_verts_dict['r']]
            
        next_elem_data = {
            'verts': saved_verts,
            'center': last_pt['pos'],
            'tangent': last_pt['tan'],
            'side': last_pt['side'],
            'normal': last_pt['norm'],
            'width': last_pt['width'],
            'thickness': self.thickness,
            'locked': bool(getattr(self, "_retopo_pen_mode", False)),
        }
        
        self._history.append({
            'faces': created_faces,
            'prev_elem_data': self._prev_elem_data,
            'new_elem_data': next_elem_data,
            'is_solidify': self.use_solidify 
        })
        
        self._prev_elem_data = next_elem_data
        self._start_co = self._current_co.copy()
        self._start_norm = self._current_norm.copy()
        self._start_width = self.width
        self._start_thickness = self.thickness

    def _finalize_uvs(self):
        if not self.bm.is_valid: return 
        bm = self.bm
        if not bm.loops.layers.uv:
            bm.loops.layers.uv.new()
        uv_layer = bm.loops.layers.uv.active

        all_segments = []
        for step in self._history:
            faces = [f for f in step['faces'] if f.is_valid]
            if not faces: continue
            is_solid = step.get('is_solidify', False)
            stride = 4 if is_solid else 1
            for i in range(0, len(faces), stride):
                segment_faces = faces[i : i+stride]
                if len(segment_faces) == stride:
                    all_segments.append( (segment_faces, is_solid) )
        
        total_segments = len(all_segments)
        if total_segments == 0: return

        for i, (seg_faces, is_solid) in enumerate(all_segments):
            v_start = 1.0 - (i / total_segments)
            v_end = 1.0 - ((i + 1) / total_segments)
            
            if is_solid:
                f_top, f_bot, f_left, f_right = seg_faces[0], seg_faces[1], seg_faces[2], seg_faces[3]
                f_top.loops[0][uv_layer].uv = (1.00, v_start)
                f_top.loops[1][uv_layer].uv = (0.75, v_start)
                f_top.loops[2][uv_layer].uv = (0.75, v_end)
                f_top.loops[3][uv_layer].uv = (1.00, v_end)
                f_right.loops[0][uv_layer].uv = (0.75, v_start)
                f_right.loops[1][uv_layer].uv = (0.50, v_start)
                f_right.loops[2][uv_layer].uv = (0.50, v_end)
                f_right.loops[3][uv_layer].uv = (0.75, v_end)
                f_bot.loops[0][uv_layer].uv = (0.50, v_start)
                f_bot.loops[1][uv_layer].uv = (0.25, v_start)
                f_bot.loops[2][uv_layer].uv = (0.25, v_end)
                f_bot.loops[3][uv_layer].uv = (0.50, v_end)
                f_left.loops[0][uv_layer].uv = (0.25, v_start)
                f_left.loops[1][uv_layer].uv = (0.00, v_start)
                f_left.loops[2][uv_layer].uv = (0.00, v_end)
                f_left.loops[3][uv_layer].uv = (0.25, v_end)
            else:
                f = seg_faces[0]
                f.loops[0][uv_layer].uv = (1.0, v_start) 
                f.loops[1][uv_layer].uv = (0.0, v_start) 
                f.loops[2][uv_layer].uv = (0.0, v_end)   
                f.loops[3][uv_layer].uv = (1.0, v_end)   

        bmesh.update_edit_mesh(self.obj.data, loop_triangles=True, destructive=True)

    def _exit(self, context):
        if self._draw_handle:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(self._draw_handle, "WINDOW")
            except Exception:
                pass
            self._draw_handle = None
        if self._draw_handle_hud:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(self._draw_handle_hud, "WINDOW")
            except Exception:
                pass
            self._draw_handle_hud = None
        try:
            self._finalize_uvs()
        except Exception:
            pass
        scn = context.scene
        scn.qsd_width = _bu_to_cm(self.width)
        if not getattr(self, "_retopo_pen_mode", False):
            scn.qsd_thickness = _bu_to_cm(self.thickness)
        _qsd_clear_target_bvh(getattr(self, "_tgt_eval", None), getattr(self, "_tgt_mesh", None))
        self._tgt_eval = None
        self._tgt_mesh = None
        self._tgt_bvh = None
        self._retopo_target_obj = None
        self._clear_preview_batches(clear_hud=True)
        _wm_set_running(context, False)
        _wm_set_stop_requested(context, False)
        _scene_sync_draw_toggle(context, False)
        _force_redraw_view3d()
        return {'FINISHED'}

    def _fail_and_exit(self, context, exc):
        try:
            msg = str(exc).strip() or exc.__class__.__name__
            self.report({'ERROR'}, _TT("REPORT_RUNTIME_ERROR", message=msg))
        except Exception:
            pass
        return self._exit(context)

    def _clear_preview_batches(self, *, clear_hud=False):
        self._preview_batch_tris = None
        self._preview_batch_lines = None
        self._preview_batch_points = None
        self._preview_merge_points = []
        self._preview_signature = None
        snapshot = getattr(self, '_draw_snapshot', None)
        if snapshot is not None:
            snapshot.clear_geometry()
            if clear_hud:
                snapshot.hud_lines = ()

    def _reset_current_strip(self):
        self._draw_state = 0
        self._prev_elem_data = None
        self._locked_solidify = None
        self._current_co = None
        self._current_norm = None
        self._clear_preview_batches()
        self._update_hud_snapshot()

    @staticmethod
    def _vector_signature(value):
        if value is None:
            return None
        try:
            return tuple(round(float(component), 9) for component in value)
        except Exception:
            return None

    def _preview_state_signature(self):
        scn = getattr(self, '_scene_ref', None)
        try:
            merge_enabled = bool(self._merge_enabled_live())
            merge_distance = round(float(self._merge_distance_live()), 9)
        except Exception:
            merge_enabled = False
            merge_distance = 0.0
        try:
            prev_signature = (
                id(self._prev_elem_data),
                tuple(id(v) for v in (self._prev_elem_data or {}).get('verts', ())),
            )
        except Exception:
            prev_signature = (0, ())
        return (
            int(self._draw_state),
            self._vector_signature(self._start_co),
            self._vector_signature(self._current_co),
            self._vector_signature(self._start_norm),
            self._vector_signature(self._current_norm),
            round(float(self._start_width), 9),
            round(float(self.width), 9),
            round(float(self._start_thickness), 9),
            round(float(self.thickness), 9),
            int(self.subdivisions),
            bool(self.use_solidify),
            bool(self._locked_solidify) if self._locked_solidify is not None else None,
            bool(getattr(self, '_retopo_pen_mode', False)),
            merge_enabled,
            merge_distance,
            int(self._preview_revision),
            prev_signature,
            id(scn),
        )

    def _update_hud_snapshot(self):
        snapshot = getattr(self, '_draw_snapshot', None)
        if snapshot is None:
            return
        if self._draw_state == 0:
            status_txt = _T("HUD_STATE_0")
        elif self._draw_state == 1:
            status_txt = _T("HUD_STATE_1")
        else:
            status_txt = _T("HUD_STATE_2")

        solid_status = _T("HUD_ON") if self.use_solidify else _T("HUD_OFF")
        if not self.use_solidify:
            solid_status += " " + _T("HUD_DISABLED")
        elif self._draw_state == 2 and self._locked_solidify is False:
            solid_status += " " + _T("HUD_LOCKED")

        snapshot.hud_lines = (
            f"{_T('PANEL_LABEL')} | {status_txt}",
            f"{_T('PROP_WIDTH')}: {_bu_to_cm(self.width):.2f}",
            f"{_T('PROP_THICKNESS')}: {_bu_to_cm(self.thickness):.2f} ({solid_status})",
            f"{_T('PROP_SEGMENTS')}: {self.subdivisions}",
            _T("HUD_HELP"),
        )

    def _rebuild_preview_batches(self, *, force=False):
        """Rebuild preview snapshots only when operator state actually changed."""
        signature = self._preview_state_signature()
        if not force and signature == self._preview_signature:
            return False
        self._preview_signature = signature
        self._preview_merge_points = []
        self._preview_batch_tris = None
        self._preview_batch_lines = None
        self._preview_batch_points = None
        snapshot = getattr(self, '_draw_snapshot', None)
        if snapshot is not None:
            snapshot.clear_geometry()
        self._update_hud_snapshot()

        if self._draw_state < 1 or self._start_co is None or self._current_co is None:
            return True
        prev_tan = self._prev_elem_data['tangent'] if self._prev_elem_data else None
        prev_side = self._prev_elem_data['side'] if self._prev_elem_data else None
        points = StripCalculator.calc_ribbon_points(
            self._start_co, self._current_co,
            self._start_norm, self._current_norm,
            self._start_width, self.width,
            self.subdivisions, prev_tan, prev_side,
        )
        if not points:
            return True

        tris = []
        lines = []
        merge_points = []

        if self.use_solidify:
            def get_v(i, loc):
                point = points[i]
                center, side, width, normal = point['pos'], point['side'], point['width'], point['norm']
                ratio = i / max(1, (len(points) - 1))
                thickness = self._start_thickness * (1.0 - ratio) + self.thickness * ratio
                offset = side * (width * 0.5) if loc == 'l' else -side * (width * 0.5)
                return (
                    center + offset + normal * thickness * 0.5,
                    center + offset - normal * thickness * 0.5,
                )

            for index in range(len(points) - 1):
                clt, clb = get_v(index, 'l')
                crt, crb = get_v(index, 'r')
                nlt, nlb = get_v(index + 1, 'l')
                nrt, nrb = get_v(index + 1, 'r')
                tris.extend([
                    clt, crt, nrt, clt, nrt, nlt,
                    clb, nrb, crb, clb, nlb, nrb,
                    clt, nlt, nlb, clt, nlb, clb,
                    crt, crb, nrb, crt, nrb, nrt,
                ])
                lines.extend([
                    clt, nlt, crt, nrt, clb, nlb, crb, nrb,
                    clt, crt, crt, crb, crb, clb, clb, clt,
                ])
                if index == len(points) - 2:
                    lines.extend([nlt, nrt, nrt, nrb, nrb, nlb, nlb, nlt])
        else:
            matrix_inverse = self.obj.matrix_world.inverted()

            def resolve_local(local_co, exclude=None):
                world_co, vert, merged = self._preview_resolve_local(local_co, exclude=exclude)
                if merged:
                    merge_points.append(world_co)
                return {'world': world_co, 'vert': vert}

            if self._prev_elem_data:
                previous_verts = self._prev_elem_data['verts']
                last_pair = {
                    'l': {'world': self.obj.matrix_world @ previous_verts[0].co, 'vert': previous_verts[0]},
                    'r': {'world': self.obj.matrix_world @ previous_verts[1].co, 'vert': previous_verts[1]},
                }
            else:
                first_point = points[0]
                center, side, width = first_point['pos'], first_point['side'], first_point['width']
                left_local = matrix_inverse @ (center + side * (width * 0.5))
                right_local = matrix_inverse @ (center - side * (width * 0.5))
                left = resolve_local(left_local)
                right = resolve_local(right_local, exclude=[left['vert']] if left['vert'] is not None else None)
                last_pair = {'l': left, 'r': right}

            for index in range(1, len(points)):
                point = points[index]
                center, side, width = point['pos'], point['side'], point['width']
                left_local = matrix_inverse @ (center + side * (width * 0.5))
                right_local = matrix_inverse @ (center - side * (width * 0.5))
                exclude = [entry['vert'] for entry in (last_pair['l'], last_pair['r']) if entry['vert'] is not None]
                new_left = resolve_local(left_local, exclude=exclude)
                exclude_right = exclude + ([new_left['vert']] if new_left['vert'] is not None else [])
                new_right = resolve_local(right_local, exclude=exclude_right)
                clt = last_pair['l']['world']
                crt = last_pair['r']['world']
                nlt = new_left['world']
                nrt = new_right['world']
                tris.extend([clt, crt, nrt, clt, nrt, nlt])
                lines.extend([clt, nlt, crt, nrt, clt, crt])
                if index == len(points) - 1:
                    lines.extend([nlt, nrt])
                last_pair = {'l': new_left, 'r': new_right}

        self._preview_merge_points = list(merge_points)
        shader = self._shader
        if shader is not None:
            if tris:
                self._preview_batch_tris = batch_for_shader(shader, 'TRIS', {'pos': tris})
            if lines:
                self._preview_batch_lines = batch_for_shader(shader, 'LINES', {'pos': lines})
            if merge_points:
                self._preview_batch_points = batch_for_shader(shader, 'POINTS', {'pos': merge_points})

        if snapshot is not None:
            snapshot.tris_batch = self._preview_batch_tris
            snapshot.lines_batch = self._preview_batch_lines
            snapshot.points_batch = self._preview_batch_points
        return True

    # Compatibility wrappers.  Draw handlers are registered to the module-level
    # callbacks above so these methods are never draw entry points.
    def _draw_scene(self):
        _qsd_draw_scene(self._draw_snapshot)

    def _draw_hud(self):
        _qsd_draw_hud(self._draw_snapshot)

    def modal(self, context, event):
        try:
            if _wm_get_stop_requested(context):
                _wm_set_stop_requested(context, False)
                return self._exit(context)
            if event.type in {'RET', 'NUMPAD_ENTER', 'ESC'} and event.value == 'PRESS':
                return self._exit(context)

            region_type = getattr(getattr(context, 'region', None), 'type', None)
            if region_type != 'WINDOW':
                return {'PASS_THROUGH'}

            if event.alt and event.type in {'LEFTMOUSE', 'RIGHTMOUSE', 'MIDDLEMOUSE'}:
                self._nav_passthrough = event.value != 'RELEASE'
                return {'PASS_THROUGH'}
            if event.type == 'RIGHTMOUSE' and event.value == 'PRESS':
                self._cursor_locked = False
                self._reset_current_strip()
                if context.area:
                    context.area.tag_redraw()
                return {'RUNNING_MODAL'}

            nav_events = {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'WHEELINMOUSE', 'WHEELOUTMOUSE', 'TRACKPADPAN', 'TRACKPADZOOM', 'MOUSEROTATE', 'MOUSESMARTZOOM'}
            if event.type in nav_events:
                self._nav_passthrough = event.value != 'RELEASE'
                return {'PASS_THROUGH'}
            if event.type == 'MOUSEMOVE' and getattr(self, '_nav_passthrough', False):
                return {'PASS_THROUGH'}

            if self._draw_state == 0 and context.area:
                reg = _get_region_under_mouse(context.area, event.mouse_x, event.mouse_y)
                if reg:
                    self._active_region = reg
                    self._active_rv3d = reg.data

            mx, my = event.mouse_region_x, event.mouse_region_y
            if self._active_region:
                mx = event.mouse_x - self._active_region.x
                my = event.mouse_y - self._active_region.y

            if event.type == 'MOUSEMOVE':
                def lock_and_get_delta():
                    if not getattr(self, '_cursor_locked', False):
                        self._cursor_locked = True
                        self._cursor_lock_xy = (event.mouse_x, event.mouse_y)
                        self._last_mx = event.mouse_x
                        return 0
                    dx = event.mouse_x - self._cursor_lock_xy[0]
                    _cursor_warp(context.window, self._cursor_lock_xy[0], self._cursor_lock_xy[1])
                    return dx

                if event.alt and not event.ctrl:
                    dx = lock_and_get_delta()
                    self.width = max(0.01, self.width + dx * 0.005)
                    if self._draw_state == 1:
                        self._start_width = self.width
                elif event.ctrl and event.alt and not getattr(self, "_retopo_pen_mode", False):
                    if not self.use_solidify:
                        pass
                    elif self._draw_state == 2 and self._locked_solidify is False:
                        pass
                    else:
                        dx = lock_and_get_delta()
                        self.thickness = max(0.01, self.thickness + dx * 0.005)
                        if self._draw_state == 1:
                            self._start_thickness = self.thickness
                else:
                    self._cursor_locked = False
                    loc, norm = self._get_mouse_location(context, (mx, my))
                    if self._draw_state == 0:
                        self._start_co = loc
                        self._start_norm = norm
                    else:
                        self._current_co = loc
                        self._current_norm = norm
                self._last_mx = event.mouse_x

            if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
                if not (event.ctrl or event.alt):
                    if self._draw_state == 0:
                        if not self._active_region:
                            self._active_region = getattr(context, 'region', None)
                            self._active_rv3d = getattr(getattr(context, 'space_data', None), 'region_3d', None)
                        if self._start_co is None or self._start_norm is None:
                            loc, norm = self._get_mouse_location(context, (mx, my))
                            self._start_co = loc
                            self._start_norm = norm
                        self._draw_state = 1
                        self._current_co = self._start_co.copy()
                        self._current_norm = self._start_norm.copy()
                    elif self._draw_state == 1:
                        if self._current_co is None or self._current_norm is None:
                            loc, norm = self._get_mouse_location(context, (mx, my))
                            self._current_co = loc
                            self._current_norm = norm
                        self._draw_state = 2
                        self._locked_solidify = self.use_solidify
                    elif self._draw_state == 2:
                        self._create_geometry_step()
            # The signature check makes unrelated modal events O(1). Heavy
            # preview/BMesh/KD/GPU work runs only after operator state changes.
            if self._rebuild_preview_batches() and context.area:
                context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        except Exception as exc:
            return self._fail_and_exit(context, exc)

    def invoke(self, context, event):
        if getattr(self, "stop_running", False):
            if _wm_get_running(context):
                _wm_set_stop_requested(context, True)
                _force_redraw_view3d()
                return {'FINISHED'}
            _scene_sync_draw_toggle(context, False)
            return {'CANCELLED'}
        if _wm_get_running(context):
            _scene_sync_draw_toggle(context, True)
            return {'CANCELLED'}

        use_retopo_mode = bool(getattr(self, "qsd_retopo_pen_mode", False) or getattr(context.scene, "qsd_retopo_mode", False))

        selected_meshes = [o for o in context.selected_objects if o.type == 'MESH']
        obj = None
        if selected_meshes:
            if context.active_object and context.active_object in selected_meshes:
                obj = context.active_object
            else:
                obj = selected_meshes[0]
        if not obj:
            mesh = bpy.data.meshes.new("QuadStrip_Mesh")
            obj = bpy.data.objects.new("QuadStrip", mesh)
            context.collection.objects.link(obj)
            context.view_layer.objects.active = obj
            obj.select_set(True)
        context.view_layer.objects.active = obj
        if obj.mode != 'EDIT':
            try:
                bpy.ops.object.mode_set(mode='EDIT')
            except Exception:
                _scene_sync_draw_toggle(context, False)
                return {'CANCELLED'}

        prev_tgt = getattr(context.scene, "qsd_retopo_target", None)
        tgt = None
        if use_retopo_mode:
            tgt = _qsd_get_target(context)
            if not tgt:
                self.report({'ERROR'}, _T("REPORT_RETOPO_TARGET_MISSING"))
                _scene_sync_draw_toggle(context, False)
                return {'CANCELLED'}
            if tgt is not None and tgt != prev_tgt:
                self.report({'INFO'}, _TT("REPORT_RETOPO_TARGET_AUTOSET", name=tgt.name))

        try:
            self._init_settings(context, obj)
            if use_retopo_mode:
                self._retopo_target_obj = tgt
                depsgraph = context.evaluated_depsgraph_get()
                self._tgt_eval, self._tgt_mesh, self._tgt_bvh = _qsd_build_target_bvh(tgt, depsgraph)
                if self._tgt_bvh is None:
                    self.report({'ERROR'}, _T("REPORT_TARGET_BUILD_FAILED"))
                    _scene_sync_draw_toggle(context, False)
                    return {'CANCELLED'}
        except Exception:
            _qsd_clear_target_bvh(getattr(self, "_tgt_eval", None), getattr(self, "_tgt_mesh", None))
            _scene_sync_draw_toggle(context, False)
            return {'CANCELLED'}

        _wm_set_stop_requested(context, False)
        _wm_set_running(context, True)
        _scene_sync_draw_toggle(context, True)
        self._rebuild_preview_batches(force=True)
        snapshot = self._draw_snapshot
        self._draw_handle = bpy.types.SpaceView3D.draw_handler_add(_qsd_draw_scene, (snapshot,), "WINDOW", "POST_VIEW")
        self._draw_handle_hud = bpy.types.SpaceView3D.draw_handler_add(_qsd_draw_hud, (snapshot,), "WINDOW", "POST_PIXEL")
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

class MESH_OT_qsd_stop_drawing(Operator):
    bl_idname = "mesh.qsd_stop_drawing"
    bl_label = _EN("BTN_START")
    bl_description = _EN("TIP_OP_START")
    bl_options = {"INTERNAL", 'UNDO'}

    def execute(self, context):
        if _wm_get_running(context):
            _wm_set_stop_requested(context, True)
            _force_redraw_view3d()
        _scene_sync_draw_toggle(context, False)
        return {'FINISHED'}


# ============================================================
# 5) UI Registration
# ============================================================

# ============================================================
# 4) Ultimate Retopo Toolset (Quad Draw / Field Paint / Guides)
# ============================================================

from mathutils import Matrix

def _qsd_poll_mesh_edit(context):
    obj = context.active_object
    return obj and obj.type == 'MESH' and context.mode == 'EDIT_MESH'

def _qsd_prepare_retopo_edit_mesh(context):
    """Ensure there is an active mesh object and switch to mesh edit mode if needed.
    Returns the active mesh object on success, or None on failure.
    """
    obj = context.active_object
    if not obj or obj.type != 'MESH':
        selected_meshes = [o for o in context.selected_objects if getattr(o, 'type', None) == 'MESH']
        if not selected_meshes:
            return None
        obj = selected_meshes[0]
        try:
            context.view_layer.objects.active = obj
        except Exception:
            return None
    if context.mode != 'EDIT_MESH':
        try:
            bpy.ops.object.mode_set(mode='EDIT')
        except Exception:
            return None
    obj = context.active_object
    if not obj or obj.type != 'MESH' or context.mode != 'EDIT_MESH':
        return None
    return obj

def _qsd_mesh_complexity_score(obj):
    """Return a practical score used to guess the most likely high-poly retopo target."""
    try:
        data = getattr(obj, "data", None)
        polys = len(getattr(data, "polygons", []))
        verts = len(getattr(data, "vertices", []))
        edges = len(getattr(data, "edges", []))
        mods = len(getattr(obj, "modifiers", []))
        dims = getattr(obj, "dimensions", Vector((0.0, 0.0, 0.0)))
        volume_hint = float(dims.x * dims.y * dims.z)
        return (polys * 1000000) + (verts * 1000) + (edges * 10) + mods + volume_hint
    except Exception:
        return 0


def _qsd_is_mesh_target(obj, require_polys=True):
    if obj is None:
        return False
    if getattr(obj, "type", None) != 'MESH':
        return False
    try:
        data = getattr(obj, "data", None)
        if data is None:
            return False
        if len(getattr(data, "vertices", [])) == 0:
            return False
        if require_polys and len(getattr(data, "polygons", [])) == 0:
            return False
    except Exception:
        return False
    return True


def _qsd_is_valid_target(context, obj, active=None, allow_active=True):
    if not _qsd_is_mesh_target(obj, require_polys=True):
        return False
    if not allow_active and obj == active:
        return False
    return True


def _qsd_iter_target_candidates(context, allow_active=False):
    active = getattr(context, "active_object", None)
    seen = set()

    def push(obj):
        if not _qsd_is_valid_target(context, obj, active, allow_active=allow_active):
            return None
        key = getattr(obj, "name_full", None) or getattr(obj, "name", None) or id(obj)
        if key in seen:
            return None
        seen.add(key)
        return obj

    for obj in (getattr(context, "selected_objects", None) or []):
        cand = push(obj)
        if cand is not None:
            yield cand

    try:
        for obj in context.view_layer.objects:
            try:
                selected = obj.select_get(view_layer=context.view_layer)
            except TypeError:
                selected = obj.select_get()
            except Exception:
                selected = False
            if not selected:
                continue
            cand = push(obj)
            if cand is not None:
                yield cand
    except Exception:
        pass

    if active is not None:
        try:
            for mod in getattr(active, "modifiers", []):
                for attr in ("target", "object", "auxiliary_target"):
                    cand = push(getattr(mod, attr, None))
                    if cand is not None:
                        yield cand
        except Exception:
            pass

    try:
        for obj in context.view_layer.objects:
            if not _qsd_is_valid_target(context, obj, active, allow_active=allow_active):
                continue
            try:
                if obj.hide_get() or getattr(obj, "hide_viewport", False):
                    continue
            except Exception:
                pass
            try:
                if hasattr(obj, "visible_get") and not obj.visible_get(view_layer=context.view_layer):
                    continue
            except TypeError:
                try:
                    if hasattr(obj, "visible_get") and not obj.visible_get():
                        continue
                except Exception:
                    pass
            except Exception:
                pass
            cand = push(obj)
            if cand is not None:
                yield cand
    except Exception:
        pass

    try:
        for obj in getattr(context.scene, "objects", []):
            cand = push(obj)
            if cand is not None:
                yield cand
    except Exception:
        pass

    try:
        for obj in bpy.data.objects:
            cand = push(obj)
            if cand is not None:
                yield cand
    except Exception:
        pass


def _qsd_find_target_candidate(context, allow_active=False):
    candidates = list(_qsd_iter_target_candidates(context, allow_active=allow_active))
    if not candidates:
        return None
    if len(candidates) == 1:
        return candidates[0]
    try:
        return max(candidates, key=_qsd_mesh_complexity_score)
    except Exception:
        return candidates[0]


def _qsd_get_target(context, auto_assign=True):
    scene = getattr(context, "scene", None)
    active = getattr(context, "active_object", None)
    tgt = getattr(scene, "qsd_retopo_target", None)

    # Root fix: keep honoring an explicitly chosen active mesh target.
    if _qsd_is_valid_target(context, tgt, active, allow_active=True):
        return tgt

    if auto_assign:
        candidate = _qsd_find_target_candidate(context, allow_active=False)
        if candidate is not None:
            try:
                scene.qsd_retopo_target = candidate
            except Exception:
                pass
            return candidate

        if _qsd_is_valid_target(context, active, active, allow_active=True):
            try:
                scene.qsd_retopo_target = active
            except Exception:
                pass
            return active
    return None


def _qsd_target_status_info(context):
    active = getattr(context, "active_object", None)
    stored = getattr(context.scene, "qsd_retopo_target", None)
    if _qsd_is_valid_target(context, stored, active, allow_active=True):
        if stored == active:
            return _T("UI_TARGET_STATUS_ACTIVE"), 'MESH_DATA'
        return f"{_T('UI_TARGET_STATUS_READY')}  [{stored.name}]", 'CHECKMARK'

    if stored is not None:
        return _T("UI_TARGET_STATUS_INVALID"), 'ERROR'

    candidate = _qsd_find_target_candidate(context, allow_active=False)
    if candidate is not None:
        return f"{_T('UI_TARGET_STATUS_AUTO')}  [{candidate.name}]", 'CHECKMARK'

    if _qsd_is_valid_target(context, active, active, allow_active=True):
        return _T("UI_TARGET_STATUS_ACTIVE"), 'CHECKMARK'

    return _T("UI_TARGET_STATUS_NONE"), 'ERROR'


def _qsd_assign_target(scene, obj):
    try:
        scene.qsd_retopo_target = obj
        return True
    except Exception:
        return False


def _qsd_pick_selected_target(context, allow_active_fallback=True):
    active = getattr(context, "active_object", None)
    candidate = _qsd_find_target_candidate(context, allow_active=False)
    if candidate is not None:
        return candidate
    if allow_active_fallback and _qsd_is_valid_target(context, active, active, allow_active=True):
        return active
    return None

def _qsd_build_target_bvh(target_obj, depsgraph):
    eval_obj = target_obj.evaluated_get(depsgraph)
    mesh = eval_obj.to_mesh()
    if mesh is None:
        return eval_obj, None, None

    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        bm.normal_update()
        bvh = BVHTree.FromBMesh(bm)
    finally:
        bm.free()

    return eval_obj, mesh, bvh

def _qsd_clear_target_bvh(eval_obj, mesh):
    try:
        if eval_obj and mesh:
            eval_obj.to_mesh_clear()
    except Exception:
        pass

def _qsd_target_raycast(target_obj, bvh, origin_w, direction_w, max_dist=100000.0, frontface_only=False):
    inv = target_obj.matrix_world.inverted()
    origin = inv @ origin_w
    direction = (inv.to_3x3() @ direction_w).normalized()
    hit = bvh.ray_cast(origin, direction, max_dist)
    if hit and hit[0] is not None:
        loc_l, n_l, face_index, dist = hit
        loc_w = target_obj.matrix_world @ loc_l
        n_w = (target_obj.matrix_world.to_3x3() @ n_l).normalized()
        if frontface_only:
            # Require surface normal to face against the ray (avoid backface hits / penetration)
            if n_w.dot(-direction_w.normalized()) <= 0.0001:
                return None, None, None
        return loc_w, n_w, dist
    return None, None, None

def _qsd_target_nearest(target_obj, bvh, point_w):
    inv = target_obj.matrix_world.inverted()
    p_l = inv @ point_w
    hit = bvh.find_nearest(p_l)
    if hit and hit[0] is not None:
        loc_l, n_l, face_index, dist = hit
        loc_w = target_obj.matrix_world @ loc_l
        n_w = (target_obj.matrix_world.to_3x3() @ n_l).normalized()
        return loc_w, n_w, dist
    return None, None, None

def _qsd_point_seg_dist_2d(p, a, b):
    ab = b - a
    denom = ab.length_squared
    if denom <= 1e-12:
        return (p - a).length, 0.0
    t = (p - a).dot(ab) / denom
    t = max(0.0, min(1.0, t))
    proj = a + ab * t
    return (p - proj).length, t
def _qsd_seg_seg_dist_sq(p1, q1, p2, q2):
    """Return squared distance between two 3D segments, plus closest points.
    Robust enough for local intersection/penetration guards.
    """
    d1 = q1 - p1
    d2 = q2 - p2
    r = p1 - p2
    a = d1.dot(d1)
    e = d2.dot(d2)
    f = d2.dot(r)

    if a <= 1e-12 and e <= 1e-12:
        return (p1 - p2).length_squared, p1, p2
    if a <= 1e-12:
        s = 0.0
        t = max(0.0, min(1.0, f / e)) if e > 1e-12 else 0.0
    else:
        c = d1.dot(r)
        if e <= 1e-12:
            t = 0.0
            s = max(0.0, min(1.0, -c / a))
        else:
            b = d1.dot(d2)
            denom = a * e - b * b
            if denom != 0.0:
                s = max(0.0, min(1.0, (b * f - c * e) / denom))
            else:
                s = 0.0
            t = (b * s + f) / e
            if t < 0.0:
                t = 0.0
                s = max(0.0, min(1.0, -c / a))
            elif t > 1.0:
                t = 1.0
                s = max(0.0, min(1.0, (b - c) / a))
    cp1 = p1 + d1 * s
    cp2 = p2 + d2 * t
    return (cp1 - cp2).length_squared, cp1, cp2

def _qsd_estimate_world_per_pixel(region, rv3d, world_point):
    """Estimate world distance that corresponds to 1 pixel near world_point."""
    try:
        p2d = view3d_utils.location_3d_to_region_2d(region, rv3d, world_point)
        if p2d is None:
            return 0.0
        view_dir = _get_view_vector(rv3d)
        # plane passing through world_point facing the camera
        plane_p = world_point
        plane_n = view_dir

        o0, d0 = _get_mouse_ray(region, rv3d, (p2d.x, p2d.y))
        o1, d1 = _get_mouse_ray(region, rv3d, (p2d.x + 1.0, p2d.y))

        ip0 = _ray_cast_plane_intersection(o0, d0, plane_p, plane_n)
        ip1 = _ray_cast_plane_intersection(o1, d1, plane_p, plane_n)
        if ip0 is None or ip1 is None:
            return 0.0
        return (ip1 - ip0).length
    except Exception:
        return 0.0


def _qsd_estimate_span_pca(points, avg_edge_len, clamp_max=64):
    # Lightweight PCA-ish span estimate without numpy; stable fallback.
    if len(points) < 6 or avg_edge_len <= 1e-12:
        return max(1, min(clamp_max, int(round(len(points) / 4)) or 1))
    c = Vector((0,0,0))
    for p in points: c += p
    c /= len(points)
    # covariance
    xx=yy=zz=xy=xz=yz=0.0
    for p in points:
        d = p - c
        xx += d.x*d.x; yy += d.y*d.y; zz += d.z*d.z
        xy += d.x*d.y; xz += d.x*d.z; yz += d.y*d.z
    n=float(len(points))
    xx/=n; yy/=n; zz/=n; xy/=n; xz/=n; yz/=n
    A = [[xx,xy,xz],[xy,yy,yz],[xz,yz,zz]]
    V = [[1.0,0.0,0.0],[0.0,1.0,0.0],[0.0,0.0,1.0]]
    def max_off(A):
        m=0.0;p=q=0
        for i in range(3):
            for j in range(i+1,3):
                if abs(A[i][j])>m:
                    m=abs(A[i][j]);p=i;q=j
        return m,p,q
    for _ in range(18):
        m,p,q = max_off(A)
        if m<1e-12: break
        app=A[p][p]; aqq=A[q][q]; apq=A[p][q]
        phi=0.5*math.atan2(2*apq,(aqq-app))
        c0=math.cos(phi); s0=math.sin(phi)
        for i in range(3):
            aip=A[i][p]; aiq=A[i][q]
            A[i][p]=c0*aip - s0*aiq
            A[i][q]=s0*aip + c0*aiq
        for i in range(3):
            api=A[p][i]; aqi=A[q][i]
            A[p][i]=c0*api - s0*aqi
            A[q][i]=s0*api + c0*aqi
        A[p][q]=A[q][p]=0.0
        for i in range(3):
            vip=V[i][p]; viq=V[i][q]
            V[i][p]=c0*vip - s0*viq
            V[i][q]=s0*vip + c0*viq
    evals=[A[0][0],A[1][1],A[2][2]]
    evecs=[Vector((V[0][i],V[1][i],V[2][i])) for i in range(3)]
    order=sorted(range(3), key=lambda i: evals[i], reverse=True)
    u=evecs[order[0]].normalized()
    v=evecs[order[1]].normalized()
    pu=[(p-c).dot(u) for p in points]
    pv=[(p-c).dot(v) for p in points]
    long=max(max(pu)-min(pu), max(pv)-min(pv))
    seg=max(1, int(round(long/avg_edge_len)))
    return max(1, min(clamp_max, seg))

def _qsd_edge_guide_layer(bm):
    layer = bm.edges.layers.int.get("qsd_guide")
    if layer is None:
        layer = bm.edges.layers.int.new("qsd_guide")
    return layer

def _qsd_set_guide_edges(bm, edges):
    # Adding custom data can invalidate existing BMEdge wrappers.
    bm.edges.index_update()
    indices = [edge.index for edge in edges]
    layer = _qsd_edge_guide_layer(bm)
    bm.edges.ensure_lookup_table()
    for index in indices:
        bm.edges[index][layer] = 1

def _qsd_clear_guide_edges(bm, edges):
    layer = bm.edges.layers.int.get("qsd_guide")
    if layer is None:
        return
    for e in edges:
        e[layer] = 0

def _qsd_select_guide_edges(bm, select=True):
    layer = _qsd_edge_guide_layer(bm)
    for e in bm.edges:
        if e[layer] == 1:
            e.select = bool(select)

def _qsd_nearest_guide_dir(obj, bm, point_w, radius=0.05):
    layer = bm.edges.layers.int.get("qsd_guide")
    if layer is None:
        return None
    inv = obj.matrix_world.inverted()
    p = inv @ point_w
    best = None
    best_d2 = radius * radius
    for e in bm.edges:
        if e[layer] != 1:
            continue
        a = e.verts[0].co
        b = e.verts[1].co
        # distance to segment
        ab = b - a
        denom = ab.length_squared
        if denom <= 1e-12:
            d2 = (p - a).length_squared
            t = 0.0
        else:
            t = (p - a).dot(ab) / denom
            t = max(0.0, min(1.0, t))
            proj = a + ab * t
            d2 = (p - proj).length_squared
        if d2 < best_d2:
            best_d2 = d2
            d = (b - a)
            if d.length > 1e-12:
                best = (obj.matrix_world.to_3x3() @ d).normalized()
    return best

class MESH_OT_qsd_guides_set(Operator):
    bl_idname = "mesh.qsd_guides_set"
    bl_label = _EN("OP_GUIDES_SET_LABEL")
    bl_description = _EN("TIP_OP_GUIDES_SET")
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return _qsd_poll_mesh_edit(context)

    def execute(self, context):
        bm = bmesh.from_edit_mesh(context.active_object.data)
        edges = [e for e in bm.edges if e.select]
        if not edges:
            self.report({'WARNING'}, _T("REPORT_SELECT_GUIDE_EDGES"))
            return {'CANCELLED'}
        _qsd_set_guide_edges(bm, edges)
        bmesh.update_edit_mesh(context.active_object.data, loop_triangles=True, destructive=True)
        return {'FINISHED'}

class MESH_OT_qsd_guides_clear(Operator):
    bl_idname = "mesh.qsd_guides_clear"
    bl_label = _EN("OP_GUIDES_CLEAR_LABEL")
    bl_description = _EN("TIP_OP_GUIDES_CLEAR")
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return _qsd_poll_mesh_edit(context)

    def execute(self, context):
        bm = bmesh.from_edit_mesh(context.active_object.data)
        edges = [e for e in bm.edges if e.select]
        if not edges:
            # if nothing selected, clear all guides
            layer = bm.edges.layers.int.get("qsd_guide")
            if layer is not None:
                for e in bm.edges:
                    e[layer] = 0
        else:
            _qsd_clear_guide_edges(bm, edges)
        bmesh.update_edit_mesh(context.active_object.data, loop_triangles=True, destructive=True)
        return {'FINISHED'}

class MESH_OT_qsd_guides_select(Operator):
    bl_idname = "mesh.qsd_guides_select"
    bl_label = _EN("OP_GUIDES_SELECT_LABEL")
    bl_description = _EN("TIP_OP_GUIDES_SELECT")
    bl_options = {"UNDO"}

    select: BoolProperty(name=_EN("PROP_GUIDE_SELECT"), default=True, description=_EN("TIP_GUIDE_SELECT"))

    @classmethod
    def poll(cls, context):
        return _qsd_poll_mesh_edit(context)

    def execute(self, context):
        bm = bmesh.from_edit_mesh(context.active_object.data)
        _qsd_select_guide_edges(bm, select=self.select)
        bmesh.update_edit_mesh(context.active_object.data, loop_triangles=True, destructive=True)
        return {'FINISHED'}

class MESH_OT_qsd_retopo_pen(Operator):
    bl_idname = "mesh.qsd_retopo_pen"
    bl_label = _EN("OP_RETOPO_PEN")
    bl_description = _EN("TIP_OP_RETOPO_PEN")
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if obj and obj.type == 'MESH':
            return True
        return any(getattr(o, 'type', None) == 'MESH' for o in context.selected_objects)

    def invoke(self, context, event):
        obj = _qsd_prepare_retopo_edit_mesh(context)
        if not obj:
            self.report({'ERROR'}, _T("REPORT_SELECT_MESH_FOR_RETOPO"))
            return {'CANCELLED'}
        if not context.scene.qsd_retopo_mode:
            self.report({'ERROR'}, _T("REPORT_ENABLE_RETOPO_MODE"))
            return {'CANCELLED'}
        prev_tgt = getattr(context.scene, "qsd_retopo_target", None)
        tgt = _qsd_get_target(context)
        if not tgt:
            self.report({'ERROR'}, _T("REPORT_RETOPO_TARGET_MISSING"))
            return {'CANCELLED'}
        if tgt is not None and tgt != prev_tgt:
            self.report({'INFO'}, _TT("REPORT_RETOPO_TARGET_AUTOSET", name=tgt.name))
        result = bpy.ops.mesh.quad_strip_draw('INVOKE_DEFAULT')
        if 'CANCELLED' in result:
            return {'CANCELLED'}
        # The launcher stays on the handler stack until the first event, which
        # keeps the strip operator's modal handler reachable.
        return result

    def modal(self, context, event):
        return {'CANCELLED', 'PASS_THROUGH'}


class MESH_OT_qsd_project_selected(Operator):
    bl_idname = "mesh.qsd_project_selected"
    bl_label = _EN("OP_PROJECT_SELECTED_LABEL")
    bl_description = _EN("TIP_OP_PROJECT_SELECTED")
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return _qsd_poll_mesh_edit(context)

    def execute(self, context):
        tgt = _qsd_get_target(context)
        if not tgt:
            self.report({'ERROR'}, _T("REPORT_RETOPO_TARGET_MISSING"))
            return {'CANCELLED'}
        deps = context.evaluated_depsgraph_get()
        eval_obj, mesh, bvh = _qsd_build_target_bvh(tgt, deps)
        try:
            obj = context.active_object
            scn = context.scene
            offset = _cm_to_bu(scn.qsd_retopo_offset)
            maxd = _cm_to_bu(scn.qsd_retopo_project_max_dist)
            inv = obj.matrix_world.inverted()
            bm = bmesh.from_edit_mesh(obj.data)
            bm.verts.ensure_lookup_table()
            for v in bm.verts:
                if not v.select:
                    continue
                w = obj.matrix_world @ v.co
                loc_w, n_w, dist = _qsd_target_nearest(tgt, bvh, w)
                if loc_w is None:
                    continue
                if maxd > 0.0 and dist > maxd:
                    continue
                v.co = inv @ (loc_w + n_w * offset)
            bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
        finally:
            _qsd_clear_target_bvh(eval_obj, mesh)
        return {'FINISHED'}

class MESH_OT_qsd_relax_project_selected(Operator):
    bl_idname = "mesh.qsd_relax_project_selected"
    bl_label = _EN("OP_RELAX_PROJECT_LABEL")
    bl_description = _EN("TIP_OP_RELAX_PROJECT_SELECTED")
    bl_options = {"UNDO"}

    iterations: IntProperty(name=_EN("PROP_RELAX_ITERATIONS"), default=10, min=1, max=200, description=_EN("TIP_RELAX_ITERATIONS"))
    strength: FloatProperty(name=_EN("PROP_RELAX_STRENGTH"), default=0.5, min=0.0, max=1.0, description=_EN("TIP_RELAX_STRENGTH"))

    @classmethod
    def poll(cls, context):
        return _qsd_poll_mesh_edit(context)

    def execute(self, context):
        tgt = _qsd_get_target(context)
        if not tgt:
            self.report({'ERROR'}, _T("REPORT_RETOPO_TARGET_MISSING"))
            return {'CANCELLED'}
        deps = context.evaluated_depsgraph_get()
        eval_obj, mesh, bvh = _qsd_build_target_bvh(tgt, deps)
        try:
            obj = context.active_object
            scn = context.scene
            offset = _cm_to_bu(scn.qsd_retopo_offset)
            maxd = _cm_to_bu(scn.qsd_retopo_project_max_dist)
            inv = obj.matrix_world.inverted()
            bm = bmesh.from_edit_mesh(obj.data)
            bm.verts.ensure_lookup_table()

            sel = [v for v in bm.verts if v.select]
            if not sel:
                self.report({'WARNING'}, _T("REPORT_SELECT_RELAX_VERTS"))
                return {'CANCELLED'}

            for _ in range(self.iterations):
                targets = {}
                for v in sel:
                    if not v.link_edges:
                        continue
                    avg = Vector((0,0,0))
                    n=0
                    for e in v.link_edges:
                        ov = e.other_vert(v)
                        avg += ov.co
                        n += 1
                    if n:
                        avg /= n
                        targets[v] = v.co.lerp(avg, self.strength)
                for v, co in targets.items():
                    v.co = co

            # project
            for v in sel:
                w = obj.matrix_world @ v.co
                loc_w, n_w, dist = _qsd_target_nearest(tgt, bvh, w)
                if loc_w is None:
                    continue
                if maxd > 0.0 and dist > maxd:
                    continue
                v.co = inv @ (loc_w + n_w * offset)

            bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
        finally:
            _qsd_clear_target_bvh(eval_obj, mesh)
        return {'FINISHED'}

class MESH_OT_qsd_grid_fill_project(Operator):
    bl_idname = "mesh.qsd_grid_fill_project"
    bl_label = _EN("OP_GRID_FILL_PROJECT_LABEL")
    bl_description = _EN("TIP_OP_GRID_FILL_PROJECT")
    bl_options = {"UNDO"}

    span: IntProperty(name=_EN("PROP_GRID_FILL_SPAN"), default=0, min=0, max=64, description=_EN("TIP_GRID_FILL_SPAN"))

    @classmethod
    def poll(cls, context):
        return _qsd_poll_mesh_edit(context)

    def execute(self, context):
        tgt = _qsd_get_target(context)
        if not tgt:
            self.report({'ERROR'}, _T("REPORT_RETOPO_TARGET_MISSING"))
            return {'CANCELLED'}
        deps = context.evaluated_depsgraph_get()
        eval_obj, mesh, bvh = _qsd_build_target_bvh(tgt, deps)
        try:
            obj = context.active_object
            scn = context.scene
            offset = _cm_to_bu(scn.qsd_retopo_offset)
            maxd = _cm_to_bu(scn.qsd_retopo_project_max_dist)
            inv = obj.matrix_world.inverted()

            bm = bmesh.from_edit_mesh(obj.data)
            bm.edges.ensure_lookup_table()
            bm.verts.ensure_lookup_table()

            edges = [e for e in bm.edges if e.select]
            if not edges:
                self.report({'WARNING'}, _T("REPORT_SELECT_GRID_FILL_BOUNDARY"))
                return {'CANCELLED'}

            boundary_verts = list({v for e in edges for v in e.verts})
            avg_len = 0.0
            cnt = 0
            for e in edges:
                avg_len += (e.verts[0].co - e.verts[1].co).length
                cnt += 1
            avg_len = (avg_len / cnt) if cnt else 0.01

            span = self.span
            if span <= 0:
                span = _qsd_estimate_span_pca([obj.matrix_world @ v.co for v in boundary_verts], avg_len, 64)

            try:
                # The mesh operator supports span; bmesh.ops.grid_fill does not.
                result = bpy.ops.mesh.fill_grid(span=span)
                if "FINISHED" not in result:
                    return {"CANCELLED"}
                bm = bmesh.from_edit_mesh(obj.data)
            except Exception as ex:
                self.report({'ERROR'}, _TT("REPORT_GRID_FILL_FAILED", message=ex))
                return {'CANCELLED'}

            # project all selected/new verts (simple: project all verts in boundary_verts neighborhood)
            bm.verts.ensure_lookup_table()
            for v in bm.verts:
                if not v.select:
                    continue
                w = obj.matrix_world @ v.co
                loc_w, n_w, dist = _qsd_target_nearest(tgt, bvh, w)
                if loc_w is None:
                    continue
                if maxd > 0.0 and dist > maxd:
                    continue
                v.co = inv @ (loc_w + n_w * offset)

            bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
        finally:
            _qsd_clear_target_bvh(eval_obj, mesh)
        return {'FINISHED'}

class MESH_OT_qsd_loop_trace_extend(Operator):
    bl_idname = "mesh.qsd_loop_trace_extend"
    bl_label = _EN("OP_LOOP_TRACE_EXTEND")
    bl_description = _EN("TIP_OP_LOOP_TRACE_EXTEND")
    bl_options = {"UNDO", "BLOCKING"}

    def _reset_runtime_state(self):
        self._depsgraph = None
        self._tgt_eval = None
        self._tgt_mesh = None
        self._tgt_bvh = None
        self._accum = 0.0

    @classmethod
    def poll(cls, context):
        return _qsd_poll_mesh_edit(context)

    def invoke(self, context, event):
        self._reset_runtime_state()
        if not context.scene.qsd_retopo_mode:
            self.report({'ERROR'}, _T("REPORT_ENABLE_RETOPO_MODE"))
            return {'CANCELLED'}
        tgt = _qsd_get_target(context)
        if not tgt:
            self.report({'ERROR'}, _T("REPORT_RETOPO_TARGET_MISSING"))
            return {'CANCELLED'}
        self._depsgraph = context.evaluated_depsgraph_get()
        self._tgt_eval, self._tgt_mesh, self._tgt_bvh = _qsd_build_target_bvh(tgt, self._depsgraph)
        self._accum = 0.0
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def finish(self, context):
        _qsd_clear_target_bvh(self._tgt_eval, self._tgt_mesh)
        return {'FINISHED'}

    def cancel(self, context):
        _qsd_clear_target_bvh(self._tgt_eval, self._tgt_mesh)
        return {'CANCELLED'}

    def _step_extrude(self, context):

        obj = context.active_object
        scn = context.scene
        step_len = _cm_to_bu(scn.qsd_retopo_loop_step)
        flip = scn.qsd_retopo_loop_flip
        offset = _cm_to_bu(scn.qsd_retopo_offset)
        maxd = _cm_to_bu(scn.qsd_retopo_project_max_dist)
        frontface = scn.qsd_retopo_frontface_only

        bm = bmesh.from_edit_mesh(obj.data)
        bm.edges.ensure_lookup_table()
        bm.verts.ensure_lookup_table()
        bm.normal_update()

        boundary_edges = [e for e in bm.edges if e.select and len(e.link_faces) == 1]
        if not boundary_edges:
            return

        boundary_verts = list({v for e in boundary_edges for v in e.verts})
        tgt = _qsd_get_target(context)

        inv_obj = obj.matrix_world.inverted()
        obj3 = obj.matrix_world.to_3x3()
        obj3_inv = obj3.inverted()

        # Boundary loops follow the winding of their one incident face.
        # Use the same directed tangent at both ends of each selected edge.
        tangents = {v: Vector((0.0, 0.0, 0.0)) for v in boundary_verts}
        for edge in boundary_edges:
            loop = edge.link_loops[0]
            start = loop.vert
            end = loop.link_loop_next.vert
            tangent = (end.co - start.co).normalized()
            tangents[start] += tangent
            tangents[end] += tangent

        # Outward direction per old boundary vert (local-space vector)
        dir_map = {}
        for v in boundary_verts:
            t_l = tangents[v]
            if t_l.length < 1e-12:
                t_l = v.normal.orthogonal()
            t_l.normalize()
            t_w = (obj3 @ t_l).normalized()

            # Prefer target normal for stability on curved/highpoly surfaces
            n_w = None
            if tgt and self._tgt_bvh:
                wpos = obj.matrix_world @ v.co
                loc_w, nn_w, dist = _qsd_target_nearest(tgt, self._tgt_bvh, wpos)
                if nn_w is not None:
                    n_w = nn_w.normalized()
            if n_w is None:
                n_w = (obj3 @ v.normal).normalized()

            outward_w = t_w.cross(n_w)
            if outward_w.length < 1e-12:
                outward_w = n_w.orthogonal()
            outward_w.normalize()
            if flip:
                outward_w.negate()
            outward_l = (obj3_inv @ outward_w)
            if outward_l.length < 1e-12:
                outward_l = Vector((1.0, 0.0, 0.0))
            outward_l.normalize()
            dir_map[v] = outward_l

        # Extrude selected boundary edges (creates new boundary verts at same positions)
        res = bmesh.ops.extrude_edge_only(bm, edges=boundary_edges)
        new_verts = [g for g in res.get("geom", []) if isinstance(g, bmesh.types.BMVert)]
        if not new_verts:
            return

        # Map old->new using a KDTree (robust)
        kd = KDTree(len(boundary_verts))
        for i, ov in enumerate(boundary_verts):
            kd.insert(ov.co, i)
        kd.balance()

        old_to_new = {}
        for nv in new_verts:
            co, idx, dist = kd.find(nv.co)
            if idx is not None and dist is not None and dist < 1e-10:
                ov = boundary_verts[idx]
                old_to_new[ov] = nv

        # Create quad faces between old and new boundary (optional)
        if scn.qsd_retopo_loop_make_faces and old_to_new:
            for e in boundary_edges:
                ov0, ov1 = e.verts[0], e.verts[1]
                nv0 = old_to_new.get(ov0)
                nv1 = old_to_new.get(ov1)
                if nv0 is None or nv1 is None:
                    continue
                try:
                    bm.faces.new((ov0, ov1, nv1, nv0))
                except ValueError:
                    pass

        # Move and project new verts
        for ov, nv in old_to_new.items():
            d = dir_map.get(ov, Vector((1.0, 0.0, 0.0)))
            if d.length < 1e-12:
                d = Vector((1.0, 0.0, 0.0))
            nv.co = nv.co + d * step_len

            if tgt and self._tgt_bvh:
                w = obj.matrix_world @ nv.co
                loc_w, n_w, dist = _qsd_target_nearest(tgt, self._tgt_bvh, w)
                if loc_w is not None and n_w is not None:
                    if maxd <= 0.0 or dist <= maxd:
                        # Optional max distance clamp
                        nv.co = inv_obj @ (loc_w + n_w * offset)

        # Optional live merge after each step
        md = _cm_to_bu(scn.qsd_retopo_loop_merge_dist)
        if md and md > 0.0:
            try:
                bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=md)
            except Exception:
                pass

        # Select the new boundary loop (edges with both verts in the new set)
        for e in bm.edges:
            e.select = False
        new_set = set(old_to_new.values())
        for e in bm.edges:
            if len(e.link_faces) == 1 and (e.verts[0] in new_set and e.verts[1] in new_set):
                e.select = True

        bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
    def modal(self, context, event):
        context.area.tag_redraw()
        if event.type in {'RIGHTMOUSE', 'RET', 'NUMPAD_ENTER'}:
            return self.finish(context)
        if event.type == 'ESC':
            return self.cancel(context)
        if event.type == 'MOUSEMOVE':
            # use pixel accumulation to trigger steps
            lx = getattr(self, "_last_x", event.mouse_x)
            ly = getattr(self, "_last_y", event.mouse_y)
            dx = event.mouse_x - lx
            dy = event.mouse_y - ly
            self._accum += math.sqrt(dx*dx + dy*dy)
            self._last_x = event.mouse_x
            self._last_y = event.mouse_y
            spacing = max(1.0, context.scene.qsd_retopo_loop_spacing_px)
            while self._accum >= spacing:
                self._accum -= spacing
                self._step_extrude(context)
        return {'RUNNING_MODAL'}


class MESH_OT_qsd_boundary_trace_paint(Operator):
    bl_idname = "mesh.qsd_boundary_trace_paint"
    bl_label = _EN("OP_BOUNDARY_TRACE_PAINT")
    bl_description = _EN("TIP_OP_BOUNDARY_TRACE_PAINT")
    bl_options = {"UNDO", "BLOCKING"}

    def _reset_runtime_state(self):
        self._depsgraph = None
        self._tgt_eval = None
        self._tgt_mesh = None
        self._tgt_bvh = None
        self._accum = 0.0
        self._region = None
        self._rv3d = None
        self._last_mouse = None
        self._last_tan = None

    @classmethod
    def poll(cls, context):
        return _qsd_poll_mesh_edit(context)

    def _get_window_region(self, context):
        try:
            area = context.area
            if not area or area.type != 'VIEW_3D':
                return None, None
            region = None
            for r in area.regions:
                if r.type == 'WINDOW':
                    region = r
                    break
            rv3d = getattr(context.space_data, "region_3d", None)
            if region and rv3d:
                return region, rv3d
        except Exception:
            pass
        return None, None

    def _mouse_region_xy(self, event):
        if not self._region:
            return Vector((0.0, 0.0))
        return Vector((float(event.mouse_x - self._region.x), float(event.mouse_y - self._region.y)))

    def _iter_selected_boundary_edges(self, bm):
        return [e for e in bm.edges if e.select and len(e.link_faces) == 1]

    def _nearest_boundary_info_2d(self, context, bm, obj, mouse2d):
        region, rv3d = self._region, self._rv3d
        if not region or not rv3d:
            return None, None, None
        best_d = None
        best_t = None
        best_p = None
        for e in self._iter_selected_boundary_edges(bm):
            v0, v1 = e.verts
            p0 = view3d_utils.location_3d_to_region_2d(region, rv3d, obj.matrix_world @ v0.co)
            p1 = view3d_utils.location_3d_to_region_2d(region, rv3d, obj.matrix_world @ v1.co)
            if p0 is None or p1 is None:
                continue
            d, t = _qsd_point_seg_dist_2d(mouse2d, p0, p1)
            if best_d is None or d < best_d:
                seg = (p1 - p0)
                if seg.length > 1e-6:
                    best_d = d
                    best_t = seg.normalized()
                    best_p = p0 + seg * t
        return best_d, best_t, best_p

    def _auto_select_boundary_loop_under_mouse(self, context, mouse2d):
        obj = context.active_object
        bm = bmesh.from_edit_mesh(obj.data)
        bm.edges.ensure_lookup_table()
        bm.verts.ensure_lookup_table()
        region, rv3d = self._region, self._rv3d
        if not region or not rv3d:
            return False

        all_boundary = [e for e in bm.edges if len(e.link_faces) == 1]
        if not all_boundary:
            return False

        best_e = None
        best_d = None
        for e in all_boundary:
            v0, v1 = e.verts
            p0 = view3d_utils.location_3d_to_region_2d(region, rv3d, obj.matrix_world @ v0.co)
            p1 = view3d_utils.location_3d_to_region_2d(region, rv3d, obj.matrix_world @ v1.co)
            if p0 is None or p1 is None:
                continue
            d, t = _qsd_point_seg_dist_2d(mouse2d, p0, p1)
            if best_d is None or d < best_d:
                best_d = d
                best_e = e

        if best_e is None:
            return False

        # Select connected boundary loop starting from best_e
        for e in bm.edges:
            e.select = False
        stack = [best_e]
        visited = set()
        while stack:
            e = stack.pop()
            if e in visited:
                continue
            visited.add(e)
            if len(e.link_faces) != 1:
                continue
            e.select = True
            for v in e.verts:
                for ne in v.link_edges:
                    if ne not in visited and len(ne.link_faces) == 1:
                        stack.append(ne)

        bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
        return True

    def invoke(self, context, event):
        self._reset_runtime_state()
        if not context.scene.qsd_retopo_mode:
            self.report({'ERROR'}, _T("REPORT_ENABLE_RETOPO_MODE"))
            return {'CANCELLED'}
        tgt = _qsd_get_target(context)
        if not tgt:
            self.report({'ERROR'}, _T("REPORT_RETOPO_TARGET_MISSING"))
            return {'CANCELLED'}

        self._region, self._rv3d = self._get_window_region(context)
        if not self._region or not self._rv3d:
            self.report({'ERROR'}, _T("REPORT_VIEW3D_NOT_FOUND"))
            return {'CANCELLED'}

        self._depsgraph = context.evaluated_depsgraph_get()
        self._tgt_eval, self._tgt_mesh, self._tgt_bvh = _qsd_build_target_bvh(tgt, self._depsgraph)
        self._accum = 0.0
        self._last_mouse = self._mouse_region_xy(event)
        self._last_tan = None

        # If nothing is selected, auto-pick boundary loop under mouse (safe convenience)
        bm = bmesh.from_edit_mesh(context.active_object.data)
        if not self._iter_selected_boundary_edges(bm):
            self._auto_select_boundary_loop_under_mouse(context, self._last_mouse)

        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def finish(self, context):
        _qsd_clear_target_bvh(self._tgt_eval, self._tgt_mesh)
        return {'FINISHED'}

    def cancel(self, context):
        _qsd_clear_target_bvh(self._tgt_eval, self._tgt_mesh)
        return {'CANCELLED'}

    def _step_extrude(self, context):

        obj = context.active_object
        scn = context.scene
        step_len = _cm_to_bu(scn.qsd_retopo_loop_step)
        flip = scn.qsd_retopo_loop_flip
        offset = _cm_to_bu(scn.qsd_retopo_offset)
        maxd = _cm_to_bu(scn.qsd_retopo_project_max_dist)
        frontface = scn.qsd_retopo_frontface_only

        bm = bmesh.from_edit_mesh(obj.data)
        bm.edges.ensure_lookup_table()
        bm.verts.ensure_lookup_table()
        bm.normal_update()

        boundary_edges = [e for e in bm.edges if e.select and len(e.link_faces) == 1]
        if not boundary_edges:
            return

        boundary_verts = list({v for e in boundary_edges for v in e.verts})
        tgt = _qsd_get_target(context)

        inv_obj = obj.matrix_world.inverted()
        obj3 = obj.matrix_world.to_3x3()
        obj3_inv = obj3.inverted()

        # Build neighbor map to estimate boundary tangents
        neigh = {v: [] for v in boundary_verts}
        for e in boundary_edges:
            v0, v1 = e.verts
            if v0 in neigh and v1 in neigh:
                neigh[v0].append(v1)
                neigh[v1].append(v0)

        # Outward direction per old boundary vert (local-space vector)
        dir_map = {}
        for v in boundary_verts:
            t_l = Vector((0.0, 0.0, 0.0))
            for nb in neigh.get(v, []):
                vec = (nb.co - v.co)
                if vec.length > 1e-12:
                    t_l += vec.normalized()
            if t_l.length < 1e-12:
                t_l = v.normal.orthogonal()
            t_l.normalize()
            t_w = (obj3 @ t_l).normalized()

            # Prefer target normal for stability on curved/highpoly surfaces
            n_w = None
            if tgt and self._tgt_bvh:
                wpos = obj.matrix_world @ v.co
                loc_w, nn_w, dist = _qsd_target_nearest(tgt, self._tgt_bvh, wpos)
                if nn_w is not None:
                    n_w = nn_w.normalized()
            if n_w is None:
                n_w = (obj3 @ v.normal).normalized()

            outward_w = t_w.cross(n_w)
            if outward_w.length < 1e-12:
                outward_w = n_w.orthogonal()
            outward_w.normalize()
            if flip:
                outward_w.negate()
            outward_l = (obj3_inv @ outward_w)
            if outward_l.length < 1e-12:
                outward_l = Vector((1.0, 0.0, 0.0))
            outward_l.normalize()
            dir_map[v] = outward_l

        # Extrude selected boundary edges (creates new boundary verts at same positions)
        res = bmesh.ops.extrude_edge_only(bm, edges=boundary_edges)
        new_verts = [g for g in res.get("geom", []) if isinstance(g, bmesh.types.BMVert)]
        if not new_verts:
            return

        # Map old->new using a KDTree (robust)
        kd = KDTree(len(boundary_verts))
        for i, ov in enumerate(boundary_verts):
            kd.insert(ov.co, i)
        kd.balance()

        old_to_new = {}
        for nv in new_verts:
            co, idx, dist = kd.find(nv.co)
            if idx is not None and dist is not None and dist < 1e-10:
                ov = boundary_verts[idx]
                old_to_new[ov] = nv

        # Create quad faces between old and new boundary (optional)
        if scn.qsd_retopo_loop_make_faces and old_to_new:
            for e in boundary_edges:
                ov0, ov1 = e.verts[0], e.verts[1]
                nv0 = old_to_new.get(ov0)
                nv1 = old_to_new.get(ov1)
                if nv0 is None or nv1 is None:
                    continue
                try:
                    bm.faces.new((ov0, ov1, nv1, nv0))
                except ValueError:
                    pass

        # Move and project new verts
        for ov, nv in old_to_new.items():
            d = dir_map.get(ov, Vector((1.0, 0.0, 0.0)))
            if d.length < 1e-12:
                d = Vector((1.0, 0.0, 0.0))
            nv.co = nv.co + d * step_len

            if tgt and self._tgt_bvh:
                w = obj.matrix_world @ nv.co
                loc_w, n_w, dist = _qsd_target_nearest(tgt, self._tgt_bvh, w)
                if loc_w is not None and n_w is not None:
                    if maxd <= 0.0 or dist <= maxd:
                        # Optional max distance clamp
                        nv.co = inv_obj @ (loc_w + n_w * offset)

        # Optional live merge after each step
        md = _cm_to_bu(scn.qsd_retopo_loop_merge_dist)
        if md and md > 0.0:
            try:
                bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=md)
            except Exception:
                pass

        # Select the new boundary loop (edges with both verts in the new set)
        for e in bm.edges:
            e.select = False
        new_set = set(old_to_new.values())
        for e in bm.edges:
            if len(e.link_faces) == 1 and (e.verts[0] in new_set and e.verts[1] in new_set):
                e.select = True

        bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
    def modal(self, context, event):
        context.area.tag_redraw()
        if event.type in {'RIGHTMOUSE', 'RET', 'NUMPAD_ENTER'}:
            return self.finish(context)
        if event.type == 'ESC':
            return self.cancel(context)

        if event.type == 'MOUSEMOVE':
            scn = context.scene
            mouse_raw = self._mouse_region_xy(event)
            if self._last_mouse is None:
                self._last_mouse = mouse_raw
                return {'RUNNING_MODAL'}

            obj = context.active_object
            bm = bmesh.from_edit_mesh(obj.data)

            snap_px = float(getattr(scn, "qsd_retopo_loop_snap_px", 14.0))
            lock = float(getattr(scn, "qsd_retopo_loop_lock_strength", 0.9))
            inertia = float(getattr(scn, "qsd_retopo_loop_inertia", 0.6))

            best_d, tan, snap_p = self._nearest_boundary_info_2d(context, bm, obj, mouse_raw)
            if tan is None and self._last_tan is not None:
                tan = self._last_tan

            # lock mouse to boundary (screen-space) when close enough
            mouse = mouse_raw
            if snap_p is not None and best_d is not None and best_d <= snap_px and lock > 0.0:
                lock_clamped = max(0.0, min(1.0, lock))
                mouse = mouse_raw.lerp(snap_p, lock_clamped)

            delta = mouse - self._last_mouse
            self._last_mouse = mouse

            if tan is not None:
                # stabilize tangent orientation and apply inertia smoothing
                if self._last_tan is not None:
                    if tan.dot(self._last_tan) < 0.0:
                        tan = -tan
                    try:
                        a = max(0.0, min(1.0, inertia))
                        tan = (tan.lerp(self._last_tan, a)).normalized()
                    except Exception:
                        pass
                self._last_tan = tan

                comp = float(delta.dot(tan))
                # suppress perpendicular motion based on lock strength
                perp = (delta - tan * comp)
                lock_clamped = max(0.0, min(1.0, lock))
                move = abs(comp) + perp.length * (1.0 - lock_clamped) * 0.05
            else:
                move = delta.length

            self._accum += float(move)

            spacing = max(1.0, context.scene.qsd_retopo_loop_spacing_px)
            while self._accum >= spacing:
                self._accum -= spacing
                self._step_extrude(context)

        return {'RUNNING_MODAL'}

class MESH_OT_qsd_quad_field_paint(Operator):
    bl_idname = "mesh.qsd_quad_field_paint"
    bl_label = _EN("OP_QUAD_FIELD_PAINT")
    bl_description = _EN("TIP_OP_QUAD_FIELD_PAINT")
    bl_options = {"UNDO", "BLOCKING"}

    def _reset_runtime_state(self):
        self._active_region = None
        self._active_rv3d = None
        self._depsgraph = None
        self._tgt_eval = None
        self._tgt_mesh = None
        self._tgt_bvh = None
        self._stroke = False
        self._last_mouse = None
        self._last_loc = None
        self._last_n = None
        self._last_side = None
        self._last_tangent = None
        self._rings = []
        self._stack = []  # for undo/cancel
        self._hud = None
        self._edit_bmesh = None
        self._bm_vert_kd = None
        self._bm_vert_list = None
        self._bm_boundary_kd = None
        self._bm_boundary_list = None
        self._bm_boundary_edge_kd = None
        self._bm_boundary_edges = None
        self._edge_mid_kd = None
        self._edge_mid_edges = None
        self._kd_rebuild_counter = 0
        self._guard_tripped = False
        self._guard_reported = False


    @classmethod
    def poll(cls, context):
        return _qsd_poll_mesh_edit(context)

    def _ensure_region(self, context, event):
        if self._active_region is None:
            reg = _get_region_under_mouse(context.area, event.mouse_x, event.mouse_y)
            if reg:
                self._active_region = reg
                self._active_rv3d = reg.data
        return (self._active_region, self._active_rv3d)

    def _mouse_ray_world(self, context, event):
        region, rv3d = self._ensure_region(context, event)
        if not region or not rv3d:
            region = context.region
            rv3d = context.region_data
        mx = event.mouse_x - region.x
        my = event.mouse_y - region.y
        origin, direction = _get_mouse_ray(region, rv3d, (mx, my))
        return origin, direction, region, rv3d, Vector((mx, my))

    def invoke(self, context, event):
        self._reset_runtime_state()
        if not context.scene.qsd_retopo_mode:
            self.report({'ERROR'}, _T("REPORT_ENABLE_RETOPO_MODE"))
            return {'CANCELLED'}
        tgt = _qsd_get_target(context)
        if not tgt:
            self.report({'ERROR'}, _T("REPORT_RETOPO_TARGET_MISSING"))
            return {'CANCELLED'}

        self._depsgraph = context.evaluated_depsgraph_get()
        self._tgt_eval, self._tgt_mesh, self._tgt_bvh = _qsd_build_target_bvh(tgt, self._depsgraph)
        self._stroke = False
        self._last_mouse = None
        self._rings.clear()
        self._stack.clear()
        self._last_loc = None
        self._last_n = None
        self._last_side = None
        self._last_tangent = None

        # Cached ring vertices belong to this BMesh wrapper for the entire stroke.
        self._edit_bmesh = bmesh.from_edit_mesh(context.active_object.data)
        self._hud = bpy.types.SpaceView3D.draw_handler_add(self._draw_hud, (context,), "WINDOW", "POST_PIXEL")
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def _cleanup(self):
        try:
            if self._hud:
                bpy.types.SpaceView3D.draw_handler_remove(self._hud, "WINDOW")
        except Exception:
            pass
        self._hud = None
        _qsd_clear_target_bvh(self._tgt_eval, self._tgt_mesh)
        self._tgt_eval = None
        self._tgt_mesh = None
        self._tgt_bvh = None
        self._edit_bmesh = None

    def _draw_hud(self, context):
        # Minimal HUD
        try:
            font_id = 0
            _blf_size(font_id, 14)
            blf.color(font_id, 1, 1, 1, 1)
            x, y = 30, 60
            blf.position(font_id, x, y, 0)
            blf.draw(font_id, _T("HUD_FIELD_HELP"))
        except Exception:
            pass

    def _effective_spacing_px(self, rv3d, n_w):
        scn = bpy.context.scene
        base = max(1.0, float(scn.qsd_field_spacing_px))
        if not scn.qsd_field_screen_adaptive:
            return base
        view_dir = _get_view_vector(rv3d)
        sil = 1.0 - abs(max(-1.0, min(1.0, n_w.dot(view_dir))))
        curv = 0.0
        if self._last_n is not None:
            a = max(-1.0, min(1.0, self._last_n.dot(n_w)))
            curv = math.acos(a) / math.pi
        eff = base / (1.0 + scn.qsd_field_silhouette_boost * sil + scn.qsd_field_curvature_boost * curv)
        return max(1.0, eff)

    
    def _rebuild_kd(self, bm, scn):
        """Rebuild KD trees used by Field Paint for snapping/guards."""
        try:
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
        except Exception:
            pass

        # All verts
        self._bm_vert_list = list(bm.verts)
        if self._bm_vert_list:
            kd = KDTree(len(self._bm_vert_list))
            for i, v in enumerate(self._bm_vert_list):
                kd.insert(v.co, i)
            kd.balance()
            self._bm_vert_kd = kd
        else:
            self._bm_vert_kd = None

        # Boundary verts
        bverts = []
        if scn.qsd_field_boundary_only:
            for v in bm.verts:
                for e in v.link_edges:
                    if len(e.link_faces) == 1:
                        bverts.append(v)
                        break
        else:
            bverts = self._bm_vert_list

        self._bm_boundary_list = bverts
        if bverts:
            kd2 = KDTree(len(bverts))
            for i, v in enumerate(bverts):
                kd2.insert(v.co, i)
            kd2.balance()
            self._bm_boundary_kd = kd2
        else:
            self._bm_boundary_kd = None

        # Boundary/all edges (for edge snapping & boundary tracing)
        try:
            all_edges = list(bm.edges)
            if scn.qsd_field_boundary_only:
                bedges = [e for e in all_edges if len(e.link_faces) == 1]
            else:
                bedges = all_edges
        except Exception:
            all_edges = list(bm.edges)
            bedges = all_edges

        self._bm_boundary_edges = bedges
        if bedges:
            kdE = KDTree(len(bedges))
            for i, e in enumerate(bedges):
                mid = (e.verts[0].co + e.verts[1].co) * 0.5
                kdE.insert(mid, i)
            kdE.balance()
            self._bm_boundary_edge_kd = kdE
        else:
            self._bm_boundary_edge_kd = None

        # Edge midpoints (for local intersection guard)
        edges = all_edges
        self._edge_mid_edges = edges
        if edges:
            kd3 = KDTree(len(edges))
            for i, e in enumerate(edges):
                mid = (e.verts[0].co + e.verts[1].co) * 0.5
                kd3.insert(mid, i)
            kd3.balance()
            self._edge_mid_kd = kd3
        else:
            self._edge_mid_kd = None

    def _snap_to_boundary_vertex(self, context, obj, bm, region, rv3d, point_w):
        scn = context.scene
        snap_px = int(scn.qsd_field_edge_snap_px)
        if snap_px <= 0 or self._bm_boundary_kd is None or not self._bm_boundary_list:
            return None, None, None

        wpp = _qsd_estimate_world_per_pixel(region, rv3d, point_w)
        if wpp <= 0.0:
            return None, None, None

        snap_dist_w = wpp * float(snap_px)
        # Approx local conversion using average object scale
        try:
            sx, sy, sz = obj.matrix_world.to_scale()
            s = max(1e-8, (abs(sx) + abs(sy) + abs(sz)) / 3.0)
        except Exception:
            s = 1.0
        snap_dist_l = snap_dist_w / s

        inv = obj.matrix_world.inverted()
        p_l = inv @ point_w

        co, idx, dist = self._bm_boundary_kd.find(p_l)
        if idx is None or dist is None or dist > snap_dist_l:
            return None, None, None

        v = self._bm_boundary_list[idx]
        v_w = obj.matrix_world @ v.co

        # boundary direction (world) for tracing
        d_l = Vector((0, 0, 0))
        for e in v.link_edges:
            if len(e.link_faces) == 1:
                ov = e.other_vert(v)
                vec = (ov.co - v.co)
                if vec.length > 1e-12:
                    d_l += vec.normalized()
        if d_l.length < 1e-12:
            d_l = v.normal.orthogonal()
        d_l.normalize()
        d_w = (obj.matrix_world.to_3x3() @ d_l).normalized()
        return v_w, v, d_w

    def _snap_to_boundary_edge(self, context, obj, bm, region, rv3d, point_w):
        """Snap a world point to the nearest (boundary/all) edge segment within EdgeSnap(px)."""
        scn = context.scene
        snap_px = int(getattr(scn, "qsd_field_edge_snap_px", 0))
        if snap_px <= 0 or self._bm_boundary_edge_kd is None or not self._bm_boundary_edges:
            return None, None, None

        wpp = _qsd_estimate_world_per_pixel(region, rv3d, point_w)
        if wpp <= 0.0:
            return None, None, None

        snap_dist_w = wpp * float(snap_px)
        try:
            sx, sy, sz = obj.matrix_world.to_scale()
            s = max(1e-8, (abs(sx) + abs(sy) + abs(sz)) / 3.0)
        except Exception:
            s = 1.0
        snap_dist_l = snap_dist_w / s

        inv = obj.matrix_world.inverted()
        p_l = inv @ point_w

        best_e = None
        best_q = None
        best_d = None

        search_r = max(snap_dist_l * 2.0, 1e-6)
        tol2 = snap_dist_l * snap_dist_l

        for co, ei, dd in self._bm_boundary_edge_kd.find_range(p_l, search_r):
            e = self._bm_boundary_edges[ei]
            if getattr(scn, "qsd_field_boundary_only", False) and len(e.link_faces) != 1:
                continue
            a = e.verts[0].co
            b = e.verts[1].co
            ab = b - a
            denom = ab.dot(ab)
            if denom < 1e-20:
                continue
            t = (p_l - a).dot(ab) / denom
            if t < 0.0:
                t = 0.0
            elif t > 1.0:
                t = 1.0
            q = a + ab * t
            d2 = (p_l - q).length_squared
            if d2 <= tol2 and (best_d is None or d2 < best_d):
                best_d = d2
                best_e = e
                best_q = q

        if best_e is None or best_q is None:
            return None, None, None

        obj3 = obj.matrix_world.to_3x3()
        ed = (best_e.verts[1].co - best_e.verts[0].co)
        if ed.length < 1e-12:
            ed = Vector((1.0, 0.0, 0.0))
        ed.normalize()
        d_w = (obj3 @ ed).normalized()
        q_w = obj.matrix_world @ best_q
        return q_w, best_e, d_w

    def _snap_to_boundary_auto(self, context, obj, bm, region, rv3d, point_w):
        """Auto snap helper: prefer edge snap when enabled, fallback to vertex snap."""
        scn = context.scene
        use_edges = bool(getattr(scn, "qsd_field_edge_snap_to_edges", True))
        if use_edges:
            sw, src, dw = self._snap_to_boundary_edge(context, obj, bm, region, rv3d, point_w)
            if sw is not None:
                return sw, src, dw
        return self._snap_to_boundary_vertex(context, obj, bm, region, rv3d, point_w)

    def _maybe_trace_boundary(self, context, obj, bm, region, rv3d, center_w, tangent_w):
        scn = context.scene
        if not scn.qsd_field_trace_boundary:
            return center_w, tangent_w
        snapped, _src, d_w = self._snap_to_boundary_auto(context, obj, bm, region, rv3d, center_w)
        if snapped is None or d_w is None:
            return center_w, tangent_w
        # blend tangent with boundary direction (separate strength from guide strength)
        s = 0.85
        try:
            s = max(0.0, min(1.0, float(getattr(scn, "qsd_field_boundary_strength", 0.85))))
        except Exception:
            pass
        if tangent_w is None:
            t = d_w.normalized()
        else:
            t = (tangent_w.lerp(d_w, s)).normalized()
        return snapped, t

    def _live_merge_find(self, bm, point_l, dist_l):
        if self._bm_vert_kd is None or not self._bm_vert_list or dist_l <= 0.0:
            return None
        co, idx, d = self._bm_vert_kd.find(point_l)
        if idx is None or d is None or d > dist_l:
            return None
        return self._bm_vert_list[idx]

    def _guard_intersection(self, obj, bm, created_verts, created_faces, tol_l):
        """Local, conservative intersection guard. Returns True if intersection risk detected."""
        if tol_l <= 0.0 or self._edge_mid_kd is None or not self._edge_mid_edges:
            return False

        cand_edges = set()
        for f in created_faces:
            for e in f.edges:
                cand_edges.add(e)

        if not cand_edges:
            return False

        # AABB of created verts
        mins = Vector((1e20, 1e20, 1e20))
        maxs = Vector((-1e20, -1e20, -1e20))
        for v in created_verts:
            c = v.co
            mins.x = min(mins.x, c.x); mins.y = min(mins.y, c.y); mins.z = min(mins.z, c.z)
            maxs.x = max(maxs.x, c.x); maxs.y = max(maxs.y, c.y); maxs.z = max(maxs.z, c.z)
        pad = tol_l * 8.0
        mins -= Vector((pad, pad, pad))
        maxs += Vector((pad, pad, pad))

        def in_aabb(vco):
            return (mins.x <= vco.x <= maxs.x) and (mins.y <= vco.y <= maxs.y) and (mins.z <= vco.z <= maxs.z)

        tol2 = tol_l * tol_l
        search_r = max(tol_l * 12.0, 0.01)

        for ce in cand_edges:
            a = ce.verts[0].co
            b = ce.verts[1].co
            mid = (a + b) * 0.5
            for co, ei, d in self._edge_mid_kd.find_range(mid, search_r):
                e = self._edge_mid_edges[ei]
                if e in cand_edges:
                    continue
                # Skip edges outside local area quickly
                if not (in_aabb(e.verts[0].co) or in_aabb(e.verts[1].co)):
                    continue
                # Skip if sharing verts (connected)
                if (e.verts[0] in ce.verts) or (e.verts[1] in ce.verts):
                    continue
                c = e.verts[0].co
                d0 = e.verts[1].co
                dsq, _, _ = _qsd_seg_seg_dist_sq(a, b, c, d0)
                if dsq < tol2:
                    return True
        return False

    def _auto_fill_on_finish(self, context, obj, bm):
        scn = context.scene
        if not scn.qsd_field_auto_fill_on_finish:
            return

        tgt = _qsd_get_target(context)
        if not tgt or self._tgt_bvh is None:
            return

        # collect boundary edges touching created geometry
        created = set()
        for step in self._stack:
            for v in step.get("verts", []):
                created.add(v)
        if not created:
            return

        bedges = [e for e in bm.edges if len(e.link_faces) == 1 and (e.verts[0] in created or e.verts[1] in created)]
        if len(bedges) < 4:
            return

        # build vertex->edges adjacency
        v2e = {}
        for e in bedges:
            for v in e.verts:
                v2e.setdefault(v, []).append(e)

        used = set()
        loops = []
        for e0 in bedges:
            if e0 in used:
                continue
            loop = []
            used.add(e0)
            loop.append(e0)
            v_start = e0.verts[0]
            v_prev = e0.verts[0]
            v_curr = e0.verts[1]
            closed = False
            for _ in range(10000):
                if v_curr == v_start:
                    closed = True
                    break
                cands = [e for e in v2e.get(v_curr, []) if e not in used]
                if not cands:
                    break
                # choose edge that doesn't go back to previous if possible
                ne = cands[0]
                if len(cands) > 1:
                    for e in cands:
                        ov = e.other_vert(v_curr)
                        if ov != v_prev:
                            ne = e
                            break
                used.add(ne)
                loop.append(ne)
                v_next = ne.other_vert(v_curr)
                v_prev, v_curr = v_curr, v_next
            if closed and len(loop) >= 4:
                loops.append(loop)

        if not loops:
            return

        # choose largest loop
        loop_edges = max(loops, key=lambda L: len(L))
        if len(loop_edges) < 4:
            return

        # estimate span
        boundary_verts = list({v for e in loop_edges for v in e.verts})
        avg_len = 0.0
        cnt = 0
        for e in loop_edges:
            avg_len += (e.verts[0].co - e.verts[1].co).length
            cnt += 1
        avg_len = (avg_len / cnt) if cnt else 0.01

        span = int(scn.qsd_field_fill_span)
        if span <= 0:
            span = _qsd_estimate_span_pca([obj.matrix_world @ v.co for v in boundary_verts], avg_len, 64)

        # run grid fill
        try:
            res = bmesh.ops.grid_fill(bm, edges=loop_edges, span=span)
        except Exception:
            return

        new_verts = [g for g in res.get("geom", []) if isinstance(g, bmesh.types.BMVert)]
        # relax new verts (boundary fixed)
        iters = int(scn.qsd_field_fill_relax_iters)
        strength = float(scn.qsd_field_fill_relax_strength)
        if iters > 0 and new_verts and strength > 0.0:
            new_set = set(new_verts)
            boundary_set = set(boundary_verts)
            for _ in range(iters):
                targets = {}
                for v in new_verts:
                    if v in boundary_set:
                        continue
                    avg = Vector((0,0,0))
                    n = 0
                    for e in v.link_edges:
                        ov = e.other_vert(v)
                        avg += ov.co
                        n += 1
                    if n:
                        avg /= n
                        targets[v] = v.co.lerp(avg, strength)
                for v, co in targets.items():
                    v.co = co

        # project new verts
        inv = obj.matrix_world.inverted()
        offset = _cm_to_bu(scn.qsd_retopo_offset)
        maxd = _cm_to_bu(scn.qsd_retopo_project_max_dist)
        for v in new_verts:
            w = obj.matrix_world @ v.co
            loc_w, n_w, dist = _qsd_target_nearest(tgt, self._tgt_bvh, w)
            if loc_w is None:
                continue
            if maxd > 0.0 and dist > maxd:
                continue
            v.co = inv @ (loc_w + n_w * offset)
    def _project_w(self, tgt, wpoint):
        scn = bpy.context.scene
        offset = _cm_to_bu(scn.qsd_retopo_offset)
        maxd = _cm_to_bu(scn.qsd_retopo_project_max_dist)
        loc_w, n_w, dist = _qsd_target_nearest(tgt, self._tgt_bvh, wpoint)
        if loc_w is None:
            return None, None
        if maxd > 0.0 and dist > maxd:
            return None, None
        return (loc_w + n_w * offset), n_w

    
    def _make_ring(self, context, obj, bm, region, rv3d, inv, loc_w, n_w, tangent_w, side_prev):
        scn = context.scene
        tgt = _qsd_get_target(context)
        cols = max(1, int(scn.qsd_field_columns))
        width = float(scn.qsd_field_width)

        # guide alignment
        if scn.qsd_field_align_guides:
            gdir = _qsd_nearest_guide_dir(obj, bm, loc_w, radius=max(0.01, width*2.0))
            if gdir is not None:
                s = max(0.0, min(1.0, scn.qsd_field_guide_strength))
                tangent_w = (tangent_w.lerp(gdir, s)).normalized()

        side = n_w.cross(tangent_w)
        if side.length < 1e-12:
            side = n_w.orthogonal()
        side.normalize()
        if side_prev is not None and side.dot(side_prev) < 0.0:
            side = -side

        # live merge distance in local space
        live_merge = bool(scn.qsd_field_live_merge)
        merge_dist_w = _cm_to_bu(scn.qsd_field_live_merge_dist)
        try:
            sx, sy, sz = obj.matrix_world.to_scale()
            s_avg = max(1e-8, (abs(sx) + abs(sy) + abs(sz)) / 3.0)
        except Exception:
            s_avg = 1.0
        merge_dist_l = (merge_dist_w / s_avg) if s_avg > 1e-8 else merge_dist_w

        ring = []
        for i in range(cols + 1):
            t = i / cols
            off = (t - 0.5) * width
            p_w = loc_w + side * off
            p_w2, _n2 = self._project_w(tgt, p_w)
            if p_w2 is None:
                p_w2 = p_w

            # endpoint snap to boundary (vertex/edge)
            if i == 0 or i == cols:
                snapped, _src, _d = self._snap_to_boundary_auto(context, obj, bm, region, rv3d, p_w2)
                if snapped is not None:
                    p_w2 = snapped

            p_l = inv @ p_w2

            if live_merge and merge_dist_l > 0.0:
                ex = self._live_merge_find(bm, p_l, merge_dist_l)
                if ex is not None:
                    ring.append(ex)
                    continue

            v = bm.verts.new(p_l)
            ring.append(v)

        return ring, side

    def _connect_rings(self, obj, bm, ring_a, ring_b):
        cols = len(ring_a) - 1
        created_faces = []
        for i in range(cols):
            v0 = ring_a[i]
            v1 = ring_a[i+1]
            v2 = ring_b[i+1]
            v3 = ring_b[i]
            try:
                f = bm.faces.new((v0, v1, v2, v3))
                created_faces.append(f)
            except ValueError:
                pass
        return created_faces

    def _undo_last(self, context):
        if not self._stack:
            return
        obj = context.active_object
        bm = self._edit_bmesh
        step = self._stack.pop()
        geom = []
        geom.extend(step.get("faces", []))
        geom.extend(step.get("verts", []))
        try:
            bmesh.ops.delete(bm, geom=geom, context="FACES")
        except Exception:
            # fallback: delete verts
            try:
                bmesh.ops.delete(bm, geom=geom, context="VERTS")
            except Exception:
                pass
        if self._rings:
            self._rings.pop()
        bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)

    def _finish(self, context):
        obj = context.active_object
        bm = self._edit_bmesh
        scn = context.scene
        # Optional: try to close and fill the painted region on finish
        try:
            self._auto_fill_on_finish(context, obj, bm)
        except Exception:
            pass
        if scn.qsd_field_auto_stitch and _cm_to_bu(scn.qsd_field_merge_dist) > 0.0:
            try:
                bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=_cm_to_bu(scn.qsd_field_merge_dist))
            except Exception:
                pass
        bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
        self._cleanup()
        return {'FINISHED'}

    def _cancel(self, context):
        # delete everything created in this operator
        obj = context.active_object
        bm = self._edit_bmesh
        geom = []
        for step in self._stack:
            geom.extend(step.get("faces", []))
            geom.extend(step.get("verts", []))
        if geom:
            try:
                bmesh.ops.delete(bm, geom=geom, context="FACES")
            except Exception:
                try:
                    bmesh.ops.delete(bm, geom=geom, context="VERTS")
                except Exception:
                    pass
            bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
        self._cleanup()
        return {'CANCELLED'}

    def modal(self, context, event):
        context.area.tag_redraw()
        if event.type in {'RIGHTMOUSE', 'RET', 'NUMPAD_ENTER'}:
            return self._finish(context)
        if event.type == 'ESC':
            return self._cancel(context)
        if event.type in {'BACK_SPACE'} or (event.type == 'Z' and event.ctrl and event.value == 'PRESS'):
            self._undo_last(context)
            return {'RUNNING_MODAL'}

        # update region in quad-view while not drawing
        if event.type == 'MOUSEMOVE':
            reg = _get_region_under_mouse(context.area, event.mouse_x, event.mouse_y)
            if reg:
                self._active_region = reg
                self._active_rv3d = reg.data

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            self._stroke = True
            self._last_mouse = None
            self._last_loc = None
            self._last_n = None
            self._last_side = None
            self._last_tangent = None
            self._rings.clear()
            self._stack.clear()
            self._kd_rebuild_counter = 0
            self._guard_reported = False
            return {'RUNNING_MODAL'}

        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            self._stroke = False
            return {'RUNNING_MODAL'}

        if event.type == 'MOUSEMOVE' and self._stroke:
            origin_w, dir_w, region, rv3d, mouse2d = self._mouse_ray_world(context, event)
            tgt = _qsd_get_target(context)
            loc_w, n_w, dist = _qsd_target_raycast(tgt, self._tgt_bvh, origin_w, dir_w, frontface_only=context.scene.qsd_retopo_frontface_only)
            if loc_w is None:
                return {'RUNNING_MODAL'}

            spacing = self._effective_spacing_px(rv3d, n_w)
            if self._last_mouse is not None:
                if (mouse2d - self._last_mouse).length < spacing:
                    return {'RUNNING_MODAL'}

            # sample accepted
            self._last_mouse = mouse2d.copy()
            # project center point
            center_w, n2 = self._project_w(tgt, loc_w)
            if center_w is None:
                center_w = loc_w
                n2 = n_w

            if self._last_loc is None:
                # first ring: tangent along view vector
                tangent = _get_view_vector(rv3d)
            else:
                tangent = (center_w - self._last_loc)
                if tangent.length < 1e-6:
                    return {'RUNNING_MODAL'}
                tangent.normalize()

            
            obj = context.active_object
            bm = self._edit_bmesh
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()

            scn = context.scene
            if (self._kd_rebuild_counter % 4) == 0:
                self._rebuild_kd(bm, scn)

            inv = obj.matrix_world.inverted()

            # Boundary trace (optional): snap center to nearby boundary and align flow direction
            center_w, tangent = self._maybe_trace_boundary(context, obj, bm, region, rv3d, center_w, tangent)
            # Re-project center after snapping
            center_w2, n3 = self._project_w(tgt, center_w)
            if center_w2 is not None:
                center_w = center_w2
                if n3 is not None:
                    n2 = n3

            # Tangent inertia: keep a stable flow direction (reduces jitter)
            try:
                inert = float(getattr(scn, "qsd_field_tangent_inertia", 0.6))
            except Exception:
                inert = 0.6
            inert = max(0.0, min(1.0, inert))
            if tangent is not None and self._last_tangent is not None:
                if tangent.dot(self._last_tangent) < 0.0:
                    tangent = -tangent
                try:
                    tangent = (tangent.lerp(self._last_tangent, inert)).normalized()
                except Exception:
                    pass
            if tangent is not None:
                self._last_tangent = tangent.copy()

            ring, side = self._make_ring(context, obj, bm, region, rv3d, inv, center_w, n2, tangent, self._last_side)
            created = {"verts": list(ring), "faces": []}

            if self._rings:
                prev = self._rings[-1]
                faces = self._connect_rings(obj, bm, prev, ring)
                created["faces"] = faces

            # Local intersection guard (conservative)
            if scn.qsd_field_stop_on_intersect and float(scn.qsd_field_intersect_tol) > 0.0 and created["faces"]:
                tol_w = float(scn.qsd_field_intersect_tol)
                try:
                    sx, sy, sz = obj.matrix_world.to_scale()
                    s_avg = max(1e-8, (abs(sx) + abs(sy) + abs(sz)) / 3.0)
                except Exception:
                    s_avg = 1.0
                tol_l = tol_w / s_avg if s_avg > 1e-8 else tol_w

                if self._guard_intersection(obj, bm, created["verts"], created["faces"], tol_l):
                    # rollback this step
                    try:
                        bmesh.ops.delete(bm, geom=created["faces"] + created["verts"], context="FACES")
                    except Exception:
                        try:
                            bmesh.ops.delete(bm, geom=created["verts"], context="VERTS")
                        except Exception:
                            pass
                    if not self._guard_reported:
                        self._guard_reported = True
                        self.report({'WARNING'}, _T("REPORT_INTERSECTION_GUARD"))
                    self._stroke = False
                    bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
                    return {'RUNNING_MODAL'}

            self._rings.append(ring)
            self._stack.append(created)
            self._kd_rebuild_counter += 1
            self._last_loc = center_w
            self._last_n = n2
            self._last_side = side

            bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)

        return {'RUNNING_MODAL'}



_QSD_UI_STATE_PROPS = (
    ("qsd_ui_show_quickstart", "UI_SECTION_QUICKSTART", True, "TIP_UI_SHOW_QUICKSTART"),
    ("qsd_ui_show_basic_strip", "UI_SECTION_BASIC_STRIP", True, "TIP_UI_SHOW_BASIC_STRIP"),
    ("qsd_ui_show_retopo_setup", "UI_SECTION_RETOPO_SETUP", True, "TIP_UI_SHOW_RETOPO_SETUP"),
    ("qsd_ui_show_retopo_pen", "UI_SECTION_RETOPO_PEN", True, "TIP_UI_SHOW_RETOPO_PEN"),
    ("qsd_ui_show_guides", "UI_SECTION_GUIDES", False, "TIP_UI_SHOW_GUIDES"),
    ("qsd_ui_show_field_paint", "UI_SECTION_FIELD_PAINT", False, "TIP_UI_SHOW_FIELD_PAINT"),
    ("qsd_ui_show_fill_tools", "UI_SECTION_FILL_TOOLS", False, "TIP_UI_SHOW_FILL_TOOLS"),
    ("qsd_ui_show_boundary_trace", "UI_SECTION_BOUNDARY_TRACE", False, "TIP_UI_SHOW_BOUNDARY_TRACE"),
    ("qsd_ui_show_field_advanced", "UI_SECTION_ADVANCED_OPTIONS", False, "TIP_UI_SHOW_FIELD_ADVANCED"),
    ("qsd_ui_show_boundary_advanced", "UI_SECTION_ADVANCED_OPTIONS", False, "TIP_UI_SHOW_BOUNDARY_ADVANCED"),
)

def _register_qsd_ui_state_props():
    for prop_name, label_key, default_value, tip_key in _QSD_UI_STATE_PROPS:
        if not hasattr(bpy.types.WindowManager, prop_name):
            setattr(
                bpy.types.WindowManager,
                prop_name,
                BoolProperty(
                    name=_EN(label_key),
                    default=default_value,
                    description=_EN(tip_key)
                )
            )

def _unregister_qsd_ui_state_props():
    for prop_name, _label_key, _default_value, _tip_key in reversed(_QSD_UI_STATE_PROPS):
        if hasattr(bpy.types.WindowManager, prop_name):
            try:
                delattr(bpy.types.WindowManager, prop_name)
            except Exception:
                pass

def _qsd_draw_foldout(parent, owner, prop_name, title, icon="NONE"):
    box = parent.box()
    row = box.row(align=True)
    is_open = bool(getattr(owner, prop_name, False))
    row.prop(owner, prop_name, text=title, emboss=False, icon='TRIA_DOWN' if is_open else 'TRIA_RIGHT')
    if icon != "NONE":
        row.label(text="", icon=icon)
    if not is_open:
        return None
    content = box.column(align=True)
    content.use_property_split = True
    content.use_property_decorate = False
    return content

def _qsd_draw_info_lines(parent, lines):
    col = parent.column(align=True)
    col.use_property_split = False
    first = True
    for line in lines:
        col.label(text=line, icon="NONE" if first else "BLANK1")
        first = False
    return col


def _qsd_popup_column(layout):
    col = layout.column(align=True)
    col.use_property_split = True
    col.use_property_decorate = False
    return col


def _qsd_draw_field_basic_popup(layout, scn):
    shape = layout.box().column(align=True)
    shape.use_property_split = True
    shape.use_property_decorate = False
    shape.label(text=_T("UI_GROUP_FIELD_SHAPE"), icon="MESH_GRID")
    shape.prop(scn, "qsd_field_width", text=_T("PROP_FIELD_WIDTH"))
    shape.prop(scn, "qsd_field_columns", text=_T("PROP_FIELD_COLUMNS"))
    shape.prop(scn, "qsd_field_spacing_px", text=_T("PROP_FIELD_SPACING_PX"))
    shape.prop(scn, "qsd_field_screen_adaptive", text=_T("PROP_FIELD_SCREEN_ADAPTIVE"), toggle=True)

    guide = layout.box().column(align=True)
    guide.use_property_split = True
    guide.use_property_decorate = False
    guide.label(text=_T("UI_GROUP_FIELD_GUIDANCE"), icon="CURVE_DATA")
    guide.prop(scn, "qsd_field_silhouette_boost", text=_T("PROP_FIELD_SILHOUETTE_BOOST"))
    guide.prop(scn, "qsd_field_curvature_boost", text=_T("PROP_FIELD_CURVATURE_BOOST"))
    guide.prop(scn, "qsd_field_align_guides", text=_T("PROP_FIELD_ALIGN_GUIDES"), toggle=True)
    guide.prop(scn, "qsd_field_guide_strength", text=_T("PROP_FIELD_GUIDE_STRENGTH"))

    finish = layout.box().column(align=True)
    finish.use_property_split = True
    finish.use_property_decorate = False
    finish.label(text=_T("UI_GROUP_FIELD_FINISH"), icon="MOD_ARRAY")
    finish.prop(scn, "qsd_field_auto_stitch", text=_T("PROP_FIELD_AUTO_STITCH"), toggle=True)
    finish.prop(scn, "qsd_field_merge_dist", text=_T("PROP_FIELD_MERGE_DIST"))
    finish.prop(scn, "qsd_field_auto_fill_on_finish", text=_T("PROP_FIELD_AUTO_FILL_ON_FINISH"), toggle=True)
    finish.prop(scn, "qsd_field_fill_span", text=_T("PROP_FIELD_FILL_SPAN"))
    finish.prop(scn, "qsd_field_fill_relax_iters", text=_T("PROP_FIELD_FILL_RELAX_ITERS"))
    finish.prop(scn, "qsd_field_fill_relax_strength", text=_T("PROP_FIELD_FILL_RELAX_STRENGTH"))


class MESH_OT_qsd_set_target_from_selection(Operator):
    bl_idname = "mesh.qsd_set_target_from_selection"
    bl_label = _EN("BTN_SET_FROM_SELECTION")
    bl_options = {'UNDO'}
    bl_description = _EN("TIP_OP_SET_TARGET_FROM_SELECTION")

    def execute(self, context):
        candidate = _qsd_pick_selected_target(context, allow_active_fallback=True)
        if candidate is None:
            self.report({'ERROR'}, _T("REPORT_NO_USABLE_TARGET_SELECTION"))
            return {'CANCELLED'}
        if not _qsd_assign_target(context.scene, candidate):
            self.report({'ERROR'}, _T("REPORT_ASSIGN_TARGET_FAILED"))
            return {'CANCELLED'}
        self.report({'INFO'}, _TT("REPORT_TARGET_SET", name=candidate.name))
        return {'FINISHED'}


class MESH_OT_qsd_use_active_as_target(Operator):
    bl_idname = "mesh.qsd_use_active_as_target"
    bl_label = _EN("BTN_USE_ACTIVE_TARGET")
    bl_options = {'UNDO'}
    bl_description = _EN("TIP_OP_USE_ACTIVE_TARGET")

    def execute(self, context):
        active = getattr(context, "active_object", None)
        if not _qsd_is_valid_target(context, active, active, allow_active=True):
            self.report({'ERROR'}, _T("REPORT_ACTIVE_NOT_USABLE_TARGET"))
            return {'CANCELLED'}
        if not _qsd_assign_target(context.scene, active):
            self.report({'ERROR'}, _T("REPORT_ASSIGN_ACTIVE_TARGET_FAILED"))
            return {'CANCELLED'}
        self.report({'INFO'}, _TT("REPORT_TARGET_SET_ACTIVE", name=active.name))
        return {'FINISHED'}


class MESH_OT_qsd_clear_retopo_target(Operator):
    bl_idname = "mesh.qsd_clear_retopo_target"
    bl_label = _EN("BTN_CLEAR_TARGET")
    bl_options = {'UNDO'}
    bl_description = _EN("TIP_OP_CLEAR_TARGET")

    def execute(self, context):
        try:
            context.scene.qsd_retopo_target = None
        except Exception:
            self.report({'ERROR'}, _T("REPORT_TARGET_CLEAR_FAILED"))
            return {'CANCELLED'}
        self.report({'INFO'}, _T("REPORT_TARGET_CLEARED"))
        return {'FINISHED'}


class MESH_OT_qsd_retopo_setup_popup(Operator):
    bl_idname = "mesh.qsd_retopo_setup_popup"
    bl_label = _EN("POPUP_RETOPO_SETUP_TITLE")
    bl_options = set()
    _sms_no_undo = True
    bl_description = _EN("TIP_POPUP_RETOPO_SETUP")

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, context):
        layout = self.layout
        scn = context.scene
        col = _qsd_popup_column(layout)
        col.prop(scn, "qsd_retopo_target", text=_T("UI_TARGET"))
        status_text, status_icon = _qsd_target_status_info(context)
        info = col.row()
        info.use_property_split = False
        info.label(text=status_text, icon=status_icon)

        actions = col.row(align=True)
        actions.use_property_split = False
        actions.operator("mesh.qsd_set_target_from_selection", text=_T("BTN_SET_FROM_SELECTION"), icon="RESTRICT_SELECT_OFF")
        actions.operator("mesh.qsd_use_active_as_target", text=_T("BTN_USE_ACTIVE_TARGET"), icon="MESH_DATA")
        actions.operator("mesh.qsd_clear_retopo_target", text=_T("BTN_CLEAR_TARGET"), icon="X")

        col.separator()
        col.prop(scn, "qsd_retopo_offset", text=_T("UI_OFFSET"))
        col.prop(scn, "qsd_retopo_project_max_dist", text=_T("UI_MAX_DIST"))
        col.prop(scn, "qsd_retopo_frontface_only", text=_T("UI_FRONTFACE_ONLY"), toggle=True)
        col.prop(scn, "qsd_retopo_snap_radius", text=_T("UI_SNAP_PX"))


class MESH_OT_qsd_guides_popup(Operator):
    bl_idname = "mesh.qsd_guides_popup"
    bl_label = _EN("POPUP_GUIDES_TITLE")
    bl_options = set()
    _sms_no_undo = True
    bl_description = _EN("TIP_POPUP_GUIDES")

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.operator("mesh.qsd_guides_set", text=_T("OP_GUIDES_SET"), icon="ADD")
        col.operator("mesh.qsd_guides_clear", text=_T("OP_GUIDES_CLEAR"), icon="REMOVE")
        col.operator("mesh.qsd_guides_select", text=_T("OP_GUIDES_SELECT"), icon="RESTRICT_SELECT_OFF")


class MESH_OT_qsd_field_paint_popup(Operator):
    bl_idname = "mesh.qsd_field_paint_popup"
    bl_label = _EN("POPUP_FIELD_SETTINGS_TITLE")
    bl_options = set()
    _sms_no_undo = True
    bl_description = _EN("TIP_POPUP_FIELD_SETTINGS")

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=450)

    def draw(self, context):
        layout = self.layout
        scn = context.scene
        start = layout.row()
        start.scale_y = 1.1
        start.operator("mesh.qsd_quad_field_paint", text=_T("OP_QUAD_FIELD_PAINT"), icon="BRUSH_DATA")
        _qsd_draw_field_basic_popup(layout, scn)
        footer = layout.row(align=True)
        footer.operator_context = 'INVOKE_DEFAULT'
        footer.operator("mesh.qsd_field_paint_advanced_popup", text=_T("BTN_ADVANCED"), icon="PREFERENCES")


class MESH_OT_qsd_field_paint_advanced_popup(Operator):
    bl_idname = "mesh.qsd_field_paint_advanced_popup"
    bl_label = _EN("POPUP_FIELD_ADVANCED_TITLE")
    bl_options = set()
    _sms_no_undo = True
    bl_description = _EN("TIP_POPUP_FIELD_ADVANCED")

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, context):
        layout = self.layout
        scn = context.scene
        col = _qsd_popup_column(layout)
        col.prop(scn, "qsd_field_edge_snap_px", text=_T("PROP_FIELD_EDGE_SNAP_PX"))
        col.prop(scn, "qsd_field_boundary_only", text=_T("PROP_FIELD_BOUNDARY_ONLY"), toggle=True)
        col.prop(scn, "qsd_field_trace_boundary", text=_T("PROP_FIELD_TRACE_BOUNDARY"), toggle=True)
        col.prop(scn, "qsd_field_edge_snap_to_edges", text=_T("PROP_FIELD_EDGE_SNAP_TO_EDGES"), toggle=True)
        col.prop(scn, "qsd_field_boundary_strength", text=_T("PROP_FIELD_BOUNDARY_STRENGTH"))
        col.prop(scn, "qsd_field_tangent_inertia", text=_T("PROP_FIELD_TANGENT_INERTIA"))
        col.prop(scn, "qsd_field_live_merge", text=_T("PROP_FIELD_LIVE_MERGE"), toggle=True)
        col.prop(scn, "qsd_field_live_merge_dist", text=_T("PROP_FIELD_LIVE_MERGE_DIST"))
        col.prop(scn, "qsd_field_stop_on_intersect", text=_T("PROP_FIELD_STOP_ON_INTERSECT"), toggle=True)
        col.prop(scn, "qsd_field_intersect_tol", text=_T("PROP_FIELD_INTERSECT_TOL"))


class MESH_OT_qsd_fill_tools_popup(Operator):
    bl_idname = "mesh.qsd_fill_tools_popup"
    bl_label = _EN("POPUP_FILL_TOOLS_TITLE")
    bl_options = set()
    _sms_no_undo = True
    bl_description = _EN("TIP_POPUP_FILL_TOOLS")

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=340)

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.operator("mesh.qsd_project_selected", text=_T("OP_PROJECT_SELECTED"), icon="MOD_SHRINKWRAP")
        col.operator("mesh.qsd_relax_project_selected", text=_T("OP_RELAX_PROJECT"), icon="MOD_SMOOTH")
        col.operator("mesh.qsd_grid_fill_project", text=_T("OP_GRID_FILL_PROJECT"), icon="MESH_GRID")


class MESH_OT_qsd_boundary_trace_popup(Operator):
    bl_idname = "mesh.qsd_boundary_trace_popup"
    bl_label = _EN("POPUP_BOUNDARY_TITLE")
    bl_options = set()
    _sms_no_undo = True
    bl_description = _EN("TIP_POPUP_BOUNDARY")

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=430)

    def draw(self, context):
        layout = self.layout
        scn = context.scene
        actions = layout.column(align=True)
        actions.operator("mesh.qsd_boundary_trace_paint", text=_T("OP_BOUNDARY_TRACE_PAINT"), icon="TRACKING_FORWARDS")
        actions.operator("mesh.qsd_loop_trace_extend", text=_T("OP_LOOP_TRACE_EXTEND"), icon="MOD_ARRAY")

        core = layout.box().column(align=True)
        core.use_property_split = True
        core.use_property_decorate = False
        core.label(text=_T("UI_GROUP_BOUNDARY_CORE"), icon="MESH_DATA")
        core.prop(scn, "qsd_retopo_loop_step", text=_T("PROP_RETOPO_LOOP_STEP"))
        core.prop(scn, "qsd_retopo_loop_spacing_px", text=_T("PROP_RETOPO_LOOP_SPACING_PX"))
        core.prop(scn, "qsd_retopo_loop_flip", text=_T("PROP_RETOPO_LOOP_FLIP"), toggle=True)
        core.prop(scn, "qsd_retopo_loop_make_faces", text=_T("PROP_RETOPO_LOOP_MAKE_FACES"), toggle=True)
        core.prop(scn, "qsd_retopo_loop_merge_dist", text=_T("PROP_RETOPO_LOOP_MERGE_DIST"))

        footer = layout.row(align=True)
        footer.operator_context = 'INVOKE_DEFAULT'
        footer.operator("mesh.qsd_boundary_trace_advanced_popup", text=_T("BTN_ADVANCED"), icon="PREFERENCES")


class MESH_OT_qsd_boundary_trace_advanced_popup(Operator):
    bl_idname = "mesh.qsd_boundary_trace_advanced_popup"
    bl_label = _EN("POPUP_BOUNDARY_ADVANCED_TITLE")
    bl_options = set()
    _sms_no_undo = True
    bl_description = _EN("TIP_POPUP_BOUNDARY_ADVANCED")

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=400)

    def draw(self, context):
        layout = self.layout
        scn = context.scene
        col = _qsd_popup_column(layout)
        col.prop(scn, "qsd_retopo_loop_snap_px", text=_T("PROP_RETOPO_LOOP_SNAP_PX"))
        col.prop(scn, "qsd_retopo_loop_lock_strength", text=_T("PROP_RETOPO_LOOP_LOCK_STRENGTH"))
        col.prop(scn, "qsd_retopo_loop_inertia", text=_T("PROP_RETOPO_LOOP_INERTIA"))


class VIEW3D_PT_quad_strip_draw_final(Panel):
    bl_label = "Draw Quad Strip"
    bl_idname = "VIEW3D_PT_quad_strip_draw_final"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Smart Modeling'
    _smart_suite_host_panel = True

    def draw_header(self, context):
        self.layout.label(text="", icon="MESH_GRID")

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        scn = context.scene

        status = layout.box()
        status_col = status.column(align=True)
        status_col.use_property_split = False

        op_row = status_col.row()
        op_row.scale_y = 1.2
        op_row.use_property_split = False
        running = _wm_get_running(context)
        op_row.prop(scn, "qsd_draw_toggle", text=_T("BTN_START"), toggle=True)
        if running:
            status_col.label(text=_T("UI_LABEL_STATUS_RUNNING"))

        basic = layout.box().column(align=True)
        basic.label(text=_T("UI_SECTION_BASIC_STRIP"), icon="MESH_DATA")
        basic.prop(scn, "qsd_plane_mode", text=_T("PROP_PLANE"))
        basic.prop(scn, "qsd_use_surface_snap", text=_T("PROP_SNAP"), toggle=True)
        basic.prop(scn, "qsd_width", text=_T("PROP_WIDTH"))
        basic.prop(scn, "qsd_subdivisions", text=_T("PROP_SEGMENTS"))
        merge_row = basic.row(align=True)
        merge_row.use_property_split = False
        merge_row.enabled = not scn.qsd_use_solidify
        if scn.qsd_strip_vertex_merge and not scn.qsd_use_solidify:
            merge_split = merge_row.split(factor=0.42, align=True)
            merge_split.prop(scn, "qsd_strip_vertex_merge", text=_T("PROP_STRIP_VERTEX_MERGE"), toggle=True)
            merge_split.prop(scn, "qsd_strip_vertex_merge_distance", text="")
        else:
            merge_row.prop(scn, "qsd_strip_vertex_merge", text=_T("PROP_STRIP_VERTEX_MERGE"), toggle=True)
        solid_row = basic.row(align=True)
        solid_row.use_property_split = False
        if scn.qsd_use_solidify:
            solid_split = solid_row.split(factor=0.42, align=True)
            solid_split.prop(scn, "qsd_use_solidify", text=_T("PROP_SOLIDIFY"), toggle=True)
            solid_split.prop(scn, "qsd_thickness", text="")
        else:
            solid_row.prop(scn, "qsd_use_solidify", text=_T("PROP_SOLIDIFY"), toggle=True)

        ret = layout.box()
        ret_header = ret.row(align=True)
        ret_header.label(text=_T("UI_SECTION_RETOPO_ROOT"), icon="MOD_SHRINKWRAP")
        ret_header.prop(scn, "qsd_retopo_mode", text=_T("UI_ENABLE"), toggle=True)

        if scn.qsd_retopo_mode:
            ret_col = ret.column(align=True)
            target_row = ret_col.row(align=True)
            target_row.prop(scn, "qsd_retopo_target", text=_T("UI_TARGET"))
            target_row.operator_context = 'INVOKE_DEFAULT'
            target_row.operator("mesh.qsd_retopo_setup_popup", text="", icon="PREFERENCES")

            status_text, status_icon = _qsd_target_status_info(context)
            status_row = ret_col.row()
            status_row.use_property_split = False
            status_row.label(text=status_text, icon=status_icon)

            action_row = ret_col.row(align=True)
            action_row.use_property_split = False
            action_row.operator("mesh.qsd_set_target_from_selection", text="", icon="RESTRICT_SELECT_OFF")
            action_row.operator("mesh.qsd_use_active_as_target", text="", icon="MESH_DATA")
            action_row.operator("mesh.qsd_clear_retopo_target", text="", icon="X")

            tools = ret.box().column(align=True)
            tools.use_property_split = False
            tools.label(text=_T("UI_GROUP_RETOPO_ACTIONS"), icon="TOOL_SETTINGS")


            guides_row = tools.row(align=True)
            guides_row.operator_context = 'INVOKE_DEFAULT'
            guides_row.operator("mesh.qsd_guides_popup", text=_T("BTN_GUIDE_ACTIONS"), icon="CURVE_DATA")

            field_row = tools.row(align=True)
            field_row.operator("mesh.qsd_quad_field_paint", text=_T("OP_QUAD_FIELD_PAINT"), icon="BRUSH_DATA")
            field_row.operator_context = 'INVOKE_DEFAULT'
            field_row.operator("mesh.qsd_field_paint_popup", text="", icon="PREFERENCES")

            fill_row = tools.row(align=True)
            fill_row.operator_context = 'INVOKE_DEFAULT'
            fill_row.operator("mesh.qsd_fill_tools_popup", text=_T("BTN_SELECTION_TOOLS"), icon="MESH_GRID")

            boundary_row = tools.row(align=True)
            boundary_row.operator_context = 'INVOKE_DEFAULT'
            boundary_row.operator("mesh.qsd_boundary_trace_popup", text=_T("BTN_BOUNDARY_TOOLS"), icon="TRACKING_FORWARDS")


def draw_smart_modeling_settings(layout, context):
    if layout is None:
        return
    try:
        shim = type('_QSDHostedPanelShim', (), {})()
        shim.layout = layout
        VIEW3D_PT_quad_strip_draw_final.draw(shim, context)
    except Exception as exc:
        box = layout.box()
        box.alert = True
        box.label(text=str(exc)[:240], icon='ERROR')


classes = (

    QSD_AddonPreferences,
    MESH_OT_quad_strip_draw,
    MESH_OT_qsd_stop_drawing,

    # Target helpers
    MESH_OT_qsd_set_target_from_selection,
    MESH_OT_qsd_use_active_as_target,
    MESH_OT_qsd_clear_retopo_target,

    # Popup UI
    MESH_OT_qsd_retopo_setup_popup,
    MESH_OT_qsd_guides_popup,
    MESH_OT_qsd_field_paint_popup,
    MESH_OT_qsd_field_paint_advanced_popup,
    MESH_OT_qsd_fill_tools_popup,
    MESH_OT_qsd_boundary_trace_popup,
    MESH_OT_qsd_boundary_trace_advanced_popup,

    # Ultimate Retopo
    MESH_OT_qsd_guides_set,
    MESH_OT_qsd_guides_clear,
    MESH_OT_qsd_guides_select,
    MESH_OT_qsd_retopo_pen,
    MESH_OT_qsd_project_selected,
    MESH_OT_qsd_relax_project_selected,
    MESH_OT_qsd_grid_fill_project,
    MESH_OT_qsd_loop_trace_extend,
    MESH_OT_qsd_boundary_trace_paint,
    MESH_OT_qsd_quad_field_paint,
)

def register():
    try:
        bpy.app.translations.register(__name__, bl_info_translation_dict)
    except ValueError:
        try:
            bpy.app.translations.unregister(__name__)
            bpy.app.translations.register(__name__, bl_info_translation_dict)
        except Exception:
            pass

    if not hasattr(bpy.types.WindowManager, _WM_FLAG_NAME): 
        bpy.types.WindowManager.safe_qsd_running = BoolProperty(name="QSD Running", description="Internal runtime flag for Draw Quad Strip.", default=False)
    if not hasattr(bpy.types.WindowManager, _WM_STOP_FLAG_NAME):
        bpy.types.WindowManager.safe_qsd_stop_requested = BoolProperty(name="QSD Stop Requested", description="Internal stop request flag for Draw Quad Strip.", default=False)
    _register_qsd_ui_state_props()
    _qsd_unregister_standalone_panels()
    for cls in classes:
        try: bpy.utils.register_class(cls)
        except ValueError: pass 
    
    bpy.types.Scene.qsd_draw_toggle = BoolProperty(name=_EN("BTN_START"), default=False, update=_qsd_update_draw_toggle, description=_EN("TIP_OP_START"), options={'SKIP_SAVE'})
    bpy.types.Scene.qsd_width = FloatProperty(name=_EN("PROP_WIDTH"), default=2.0, min=0.1, description=_EN("TIP_WIDTH"))
    bpy.types.Scene.qsd_thickness = FloatProperty(name=_EN("PROP_THICKNESS"), default=2.0, min=0.1, description=_EN("TIP_THICKNESS"))
    bpy.types.Scene.qsd_subdivisions = IntProperty(name=_EN("PROP_SEGMENTS"), default=0, min=0, max=32, description=_EN("TIP_SEGMENTS"))
    bpy.types.Scene.qsd_use_solidify = BoolProperty(name=_EN("PROP_SOLIDIFY"), default=False, description=_EN("TIP_SOLIDIFY"))
    bpy.types.Scene.qsd_use_surface_snap = BoolProperty(name=_EN("PROP_SNAP"), default=True, description=_EN("TIP_SNAP"))
    bpy.types.Scene.qsd_strip_vertex_merge = BoolProperty(name=_EN("PROP_STRIP_VERTEX_MERGE"), default=True, description=_EN("TIP_STRIP_VERTEX_MERGE"))
    bpy.types.Scene.qsd_strip_vertex_merge_distance = FloatProperty(name=_EN("PROP_STRIP_VERTEX_MERGE_DIST"), default=1.0, min=0.0, description=_EN("TIP_STRIP_VERTEX_MERGE_DIST"))
    
    plane_items = [
        ('VIEW', _EN("PLANE_VIEW"), _EN("PLANE_VIEW_DESC")),
        ('X', _EN("PLANE_X"), _EN("PLANE_X_DESC")),
        ('Y', _EN("PLANE_Y"), _EN("PLANE_Y_DESC")),
        ('Z', _EN("PLANE_Z"), _EN("PLANE_Z_DESC")),
    ]
    bpy.types.Scene.qsd_plane_mode = EnumProperty(name=_EN("PROP_PLANE"), items=plane_items, default='VIEW', description=_EN("TIP_PLANE"))


    # --- Ultimate Retopo settings ---
    bpy.types.Scene.qsd_retopo_mode = BoolProperty(
        name=_EN("PROP_RETOPO_MODE"),
        default=False,
        description=_EN("TIP_RETOPO_MODE")
    )
    bpy.types.Scene.qsd_retopo_target = PointerProperty(
        name=_EN("PROP_RETOPO_TARGET"),
        type=bpy.types.Object,
        description=_EN("TIP_RETOPO_TARGET")
    )
    bpy.types.Scene.qsd_retopo_offset = FloatProperty(
        name=_EN("PROP_RETOPO_OFFSET"),
        default=0.0,
        description=_EN("TIP_RETOPO_OFFSET")
    )
    bpy.types.Scene.qsd_retopo_project_max_dist = FloatProperty(
        name=_EN("PROP_RETOPO_PROJECT_MAX_DIST"),
        default=0.0,
        min=0.0,
        description=_EN("TIP_RETOPO_PROJECT_MAX_DIST")
    )

    bpy.types.Scene.qsd_retopo_frontface_only = BoolProperty(
        name=_EN("PROP_RETOPO_FRONTFACE_ONLY"),
        default=True,
        description=_EN("TIP_RETOPO_FRONTFACE_ONLY")
    )
    bpy.types.Scene.qsd_retopo_snap_radius = IntProperty(
        name=_EN("PROP_RETOPO_SNAP_RADIUS"),
        default=12,
        min=2,
        max=120,
        description=_EN("TIP_RETOPO_SNAP_RADIUS")
    )
    bpy.types.Scene.qsd_retopo_auto_connect = BoolProperty(
        name=_EN("PROP_RETOPO_AUTO_CONNECT"),
        default=True,
        description=_EN("TIP_RETOPO_AUTO_CONNECT")
    )
    bpy.types.Scene.qsd_retopo_connect_dist = FloatProperty(
        name=_EN("PROP_RETOPO_CONNECT_DIST"),
        default=0.5,
        min=0.0,
        description=_EN("TIP_RETOPO_CONNECT_DIST")
    )
    bpy.types.Scene.qsd_retopo_auto_quad = BoolProperty(
        name=_EN("PROP_RETOPO_AUTO_QUAD"),
        default=False,
        description=_EN("TIP_RETOPO_AUTO_QUAD")
    )

    # Boundary trace (loop extend)
    bpy.types.Scene.qsd_retopo_loop_step = FloatProperty(
        name=_EN("PROP_RETOPO_LOOP_STEP"),
        default=2.0,
        min=0.01,
        description=_EN("TIP_RETOPO_LOOP_STEP")
    )
    bpy.types.Scene.qsd_retopo_loop_spacing_px = FloatProperty(
        name=_EN("PROP_RETOPO_LOOP_SPACING_PX"),
        default=18.0,
        min=1.0,
        description=_EN("TIP_RETOPO_LOOP_SPACING_PX")
    )
    bpy.types.Scene.qsd_retopo_loop_flip = BoolProperty(
        name=_EN("PROP_RETOPO_LOOP_FLIP"),
        default=False,
        description=_EN("TIP_RETOPO_LOOP_FLIP")
    )
    bpy.types.Scene.qsd_retopo_loop_make_faces = BoolProperty(
        name=_EN("PROP_RETOPO_LOOP_MAKE_FACES"),
        default=True,
        description=_EN("TIP_RETOPO_LOOP_MAKE_FACES")
    )
    bpy.types.Scene.qsd_retopo_loop_merge_dist = FloatProperty(
        name=_EN("PROP_RETOPO_LOOP_MERGE_DIST"),
        default=0.05,
        min=0.0,
        description=_EN("TIP_RETOPO_LOOP_MERGE_DIST")
    )

    bpy.types.Scene.qsd_retopo_loop_snap_px = IntProperty(
        name=_EN("PROP_RETOPO_LOOP_SNAP_PX"),
        default=14,
        min=0,
        max=120,
        description=_EN("TIP_RETOPO_LOOP_SNAP_PX")
    )
    bpy.types.Scene.qsd_retopo_loop_lock_strength = FloatProperty(
        name=_EN("PROP_RETOPO_LOOP_LOCK_STRENGTH"),
        default=0.9,
        min=0.0,
        max=1.0,
        description=_EN("TIP_RETOPO_LOOP_LOCK_STRENGTH")
    )
    bpy.types.Scene.qsd_retopo_loop_inertia = FloatProperty(
        name=_EN("PROP_RETOPO_LOOP_INERTIA"),
        default=0.6,
        min=0.0,
        max=1.0,
        description=_EN("TIP_RETOPO_LOOP_INERTIA")
    )


    # Quad Field Paint
    bpy.types.Scene.qsd_field_width = FloatProperty(
        name=_EN("PROP_FIELD_WIDTH"),
        default=10.0,
        min=0.01,
        description=_EN("TIP_FIELD_WIDTH")
    )
    bpy.types.Scene.qsd_field_columns = IntProperty(
        name=_EN("PROP_FIELD_COLUMNS"),
        default=2,
        min=1,
        max=64,
        description=_EN("TIP_FIELD_COLUMNS")
    )
    bpy.types.Scene.qsd_field_spacing_px = FloatProperty(
        name=_EN("PROP_FIELD_SPACING_PX"),
        default=12.0,
        min=1.0,
        description=_EN("TIP_FIELD_SPACING_PX")
    )
    bpy.types.Scene.qsd_field_screen_adaptive = BoolProperty(
        name=_EN("PROP_FIELD_SCREEN_ADAPTIVE"),
        default=True,
        description=_EN("TIP_FIELD_SCREEN_ADAPTIVE")
    )
    bpy.types.Scene.qsd_field_silhouette_boost = FloatProperty(
        name=_EN("PROP_FIELD_SILHOUETTE_BOOST"),
        default=1.0,
        min=0.0,
        max=10.0,
        description=_EN("TIP_FIELD_SILHOUETTE_BOOST")
    )
    bpy.types.Scene.qsd_field_curvature_boost = FloatProperty(
        name=_EN("PROP_FIELD_CURVATURE_BOOST"),
        default=1.0,
        min=0.0,
        max=10.0,
        description=_EN("TIP_FIELD_CURVATURE_BOOST")
    )
    bpy.types.Scene.qsd_field_align_guides = BoolProperty(
        name=_EN("PROP_FIELD_ALIGN_GUIDES"),
        default=True,
        description=_EN("TIP_FIELD_ALIGN_GUIDES")
    )
    bpy.types.Scene.qsd_field_guide_strength = FloatProperty(
        name=_EN("PROP_FIELD_GUIDE_STRENGTH"),
        default=0.75,
        min=0.0,
        max=1.0,
        description=_EN("TIP_FIELD_GUIDE_STRENGTH")
    )
    bpy.types.Scene.qsd_field_auto_stitch = BoolProperty(
        name=_EN("PROP_FIELD_AUTO_STITCH"),
        default=True,
        description=_EN("TIP_FIELD_AUTO_STITCH")
    )
    bpy.types.Scene.qsd_field_merge_dist = FloatProperty(
        name=_EN("PROP_FIELD_MERGE_DIST"),
        default=0.05,
        min=0.0,
        description=_EN("TIP_FIELD_MERGE_DIST")
    )


    bpy.types.Scene.qsd_field_edge_snap_px = IntProperty(
        name=_EN("PROP_FIELD_EDGE_SNAP_PX"),
        default=14,
        min=0,
        max=120,
        description=_EN("TIP_FIELD_EDGE_SNAP_PX")
    )
    bpy.types.Scene.qsd_field_boundary_only = BoolProperty(
        name=_EN("PROP_FIELD_BOUNDARY_ONLY"),
        default=True,
        description=_EN("TIP_FIELD_BOUNDARY_ONLY")
    )
    bpy.types.Scene.qsd_field_trace_boundary = BoolProperty(
        name=_EN("PROP_FIELD_TRACE_BOUNDARY"),
        default=True,
        description=_EN("TIP_FIELD_TRACE_BOUNDARY")
    )

    bpy.types.Scene.qsd_field_edge_snap_to_edges = BoolProperty(
        name=_EN("PROP_FIELD_EDGE_SNAP_TO_EDGES"),
        default=True,
        description=_EN("TIP_FIELD_EDGE_SNAP_TO_EDGES")
    )
    bpy.types.Scene.qsd_field_boundary_strength = FloatProperty(
        name=_EN("PROP_FIELD_BOUNDARY_STRENGTH"),
        default=0.85,
        min=0.0,
        max=1.0,
        description=_EN("TIP_FIELD_BOUNDARY_STRENGTH")
    )
    bpy.types.Scene.qsd_field_tangent_inertia = FloatProperty(
        name=_EN("PROP_FIELD_TANGENT_INERTIA"),
        default=0.6,
        min=0.0,
        max=1.0,
        description=_EN("TIP_FIELD_TANGENT_INERTIA")
    )
    bpy.types.Scene.qsd_field_live_merge = BoolProperty(
        name=_EN("PROP_FIELD_LIVE_MERGE"),
        default=True,
        description=_EN("TIP_FIELD_LIVE_MERGE")
    )
    bpy.types.Scene.qsd_field_live_merge_dist = FloatProperty(
        name=_EN("PROP_FIELD_LIVE_MERGE_DIST"),
        default=0.05,
        min=0.0,
        description=_EN("TIP_FIELD_LIVE_MERGE_DIST")
    )
    bpy.types.Scene.qsd_field_stop_on_intersect = BoolProperty(
        name=_EN("PROP_FIELD_STOP_ON_INTERSECT"),
        default=True,
        description=_EN("TIP_FIELD_STOP_ON_INTERSECT")
    )
    bpy.types.Scene.qsd_field_intersect_tol = FloatProperty(
        name=_EN("PROP_FIELD_INTERSECT_TOL"),
        default=0.05,
        min=0.0,
        description=_EN("TIP_FIELD_INTERSECT_TOL")
    )
    bpy.types.Scene.qsd_field_auto_fill_on_finish = BoolProperty(
        name=_EN("PROP_FIELD_AUTO_FILL_ON_FINISH"),
        default=False,
        description=_EN("TIP_FIELD_AUTO_FILL_ON_FINISH")
    )
    bpy.types.Scene.qsd_field_fill_span = IntProperty(
        name=_EN("PROP_FIELD_FILL_SPAN"),
        default=0,
        min=0,
        max=64,
        description=_EN("TIP_FIELD_FILL_SPAN")
    )
    bpy.types.Scene.qsd_field_fill_relax_iters = IntProperty(
        name=_EN("PROP_FIELD_FILL_RELAX_ITERS"),
        default=6,
        min=0,
        max=50,
        description=_EN("TIP_FIELD_FILL_RELAX_ITERS")
    )
    bpy.types.Scene.qsd_field_fill_relax_strength = FloatProperty(
        name=_EN("PROP_FIELD_FILL_RELAX_STRENGTH"),
        default=0.35,
        min=0.0,
        max=1.0,
        description=_EN("TIP_FIELD_FILL_RELAX_STRENGTH")
    )
    # --- Add-on設定画面のdescription動的書き換え ---
    try:
        import addon_utils
        for mod in addon_utils.modules():
            if mod.__name__ == __name__:
                desc_eng = _EN("ADDON_DESC")
                try:
                    desc_tr = bpy.app.translations.pgettext(desc_eng)
                except Exception:
                    desc_tr = desc_eng
                    
                try:
                    prefs = getattr(bpy.context, "preferences", None)
                    lang = getattr(getattr(prefs, "view", None), "language", "") if prefs else ""
                    if (lang or "").startswith("ja") and desc_tr == desc_eng:
                        desc_tr = bl_info_translation_dict.get("ja_JP", {}).get(("*", desc_eng), desc_tr)
                except Exception:
                    pass
                
                mod.bl_info["description"] = desc_tr
                break
    except Exception:
        pass

    try:
        _qsd_unregister_standalone_panels()
    except Exception:
        pass

def unregister():
    _qsd_unregister_standalone_panels()
    try:
        # --- Add-on設定画面のdescriptionを元の英語に戻す ---
        import addon_utils
        for mod in addon_utils.modules():
            if mod.__name__ == __name__:
                mod.bl_info["description"] = _EN("ADDON_DESC")
                break
    except Exception:
        pass

    try:
        wm = getattr(bpy.context, 'window_manager', None)
        if wm is not None and hasattr(wm, _WM_STOP_FLAG_NAME):
            setattr(wm, _WM_STOP_FLAG_NAME, True)
        scn = getattr(bpy.context, 'scene', None)
        if scn is not None and hasattr(scn, 'qsd_draw_toggle'):
            scn.qsd_draw_toggle = False
    except Exception:
        pass

    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass

    _unregister_qsd_ui_state_props()
    if hasattr(bpy.types.WindowManager, _WM_FLAG_NAME): 
        del bpy.types.WindowManager.safe_qsd_running
    if hasattr(bpy.types.WindowManager, _WM_STOP_FLAG_NAME):
        del bpy.types.WindowManager.safe_qsd_stop_requested
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

    for attr in (
        "qsd_width",
        "qsd_thickness",
        "qsd_subdivisions",
        "qsd_use_solidify",
        "qsd_use_surface_snap",
        "qsd_plane_mode",
        "qsd_draw_toggle",
        "qsd_strip_vertex_merge",
        "qsd_strip_vertex_merge_distance",
    ):
        if hasattr(bpy.types.Scene, attr):
            try:
                delattr(bpy.types.Scene, attr)
            except Exception:
                pass

    # Ultimate Retopo properties (safe)
    for attr in (
        "qsd_retopo_mode",
        "qsd_retopo_target",
        "qsd_retopo_offset",
        "qsd_retopo_project_max_dist",
        "qsd_retopo_frontface_only",
        "qsd_retopo_snap_radius",
        "qsd_retopo_auto_connect",
        "qsd_retopo_connect_dist",
        "qsd_retopo_auto_quad",
        "qsd_retopo_loop_step",
        "qsd_retopo_loop_spacing_px",
        "qsd_retopo_loop_flip",
        "qsd_retopo_loop_make_faces",
        "qsd_retopo_loop_merge_dist",
        "qsd_retopo_loop_snap_px",
        "qsd_retopo_loop_lock_strength",
        "qsd_retopo_loop_inertia",
        "qsd_field_width",
        "qsd_field_columns",
        "qsd_field_spacing_px",
        "qsd_field_screen_adaptive",
        "qsd_field_silhouette_boost",
        "qsd_field_curvature_boost",
        "qsd_field_align_guides",
        "qsd_field_guide_strength",
        "qsd_field_edge_snap_px",
        "qsd_field_boundary_only",
        "qsd_field_trace_boundary",
        "qsd_field_edge_snap_to_edges",
        "qsd_field_boundary_strength",
        "qsd_field_tangent_inertia",
        "qsd_field_auto_stitch",
        "qsd_field_merge_dist",
        "qsd_field_live_merge",
        "qsd_field_live_merge_dist",
        "qsd_field_stop_on_intersect",
        "qsd_field_intersect_tol",
        "qsd_field_auto_fill_on_finish",
        "qsd_field_fill_span",
        "qsd_field_fill_relax_iters",
        "qsd_field_fill_relax_strength",
    ):
        if hasattr(bpy.types.Scene, attr):
            try:
                delattr(bpy.types.Scene, attr)
            except Exception:
                pass

if __name__ == "__main__":
    try: unregister()
    except: pass
    register()
