
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

# Add-on bootstrap: Smart Modeling
# Format policy: metadata, ownership guard, runtime registration, runtime unregistration.

import importlib
import os
import sys
import traceback
import time

import bpy

_SMS_OWNED_DRIVER_NAMESPACE_KEYS_V1391 = (
    'SMART_MODELING_SUITE_EXACT_CLASS_LEDGER_V1352',
    'SMART_MODELING_SUITE_NPANEL_PREFS_SYNCED',
    'SMART_MODELING_SUITE_REGISTERING_NATIVE_TOOL',
    'SMART_MODELING_SUITE_RNA_UNSAFE_UNTIL',
    'SMART_MODELING_SUITE_RUNTIME_TOKEN',
    'SMART_MODELING_SUITE_SAFE_INSTALLING',
    'SMART_MODELING_SUITE_SHUTTING_DOWN',
)
_SMS_DRIVER_NAMESPACE_MISSING_V1395 = object()
_SMS_DRIVER_NAMESPACE_SNAPSHOT_V1395 = {}
_SMS_DRIVER_NAMESPACE_OWNED_VALUES_V1395 = {}
_SMS_DRIVER_NAMESPACE_REGISTER_STARTED_V1395 = False
_SMS_DRIVER_NAMESPACE_SHUTTING_DOWN_TOKEN_V1396 = object()


def _sms_driver_namespace_v1395():
    namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
    return namespace if isinstance(namespace, dict) else None


def _sms_snapshot_driver_namespace_v1395() -> None:
    """Capture exact pre-suite values once, before this module's first write."""
    if _SMS_DRIVER_NAMESPACE_SNAPSHOT_V1395:
        return
    namespace = _sms_driver_namespace_v1395()
    if namespace is None:
        return
    for key in _SMS_OWNED_DRIVER_NAMESPACE_KEYS_V1391:
        _SMS_DRIVER_NAMESPACE_SNAPSHOT_V1395[key] = namespace.get(
            key, _SMS_DRIVER_NAMESPACE_MISSING_V1395
        )


def _sms_namespace_values_v1395():
    namespace = _sms_driver_namespace_v1395()
    if namespace is None:
        return None, {}
    return namespace, {
        key: namespace.get(key, _SMS_DRIVER_NAMESPACE_MISSING_V1395)
        for key in _SMS_OWNED_DRIVER_NAMESPACE_KEYS_V1391
    }


def _sms_remember_owned_namespace_value_v1395(key, value) -> None:
    if value is _SMS_DRIVER_NAMESPACE_MISSING_V1395:
        return
    owned = _SMS_DRIVER_NAMESPACE_OWNED_VALUES_V1395.setdefault(key, [])
    if not any(value is item for item in owned):
        owned.append(value)


def _sms_is_owned_namespace_value_v1395(key, value) -> bool:
    if value is _SMS_DRIVER_NAMESPACE_MISSING_V1395:
        return False
    return any(
        value is item
        for item in _SMS_DRIVER_NAMESPACE_OWNED_VALUES_V1395.get(key, ())
    )


_sms_snapshot_driver_namespace_v1395()

# Keep a strong reference to the package module while import-time compatibility
# cleanup runs.  Some legacy cleanup lists used the historical mixed-case
# Extension name and could remove the package currently being imported from
# sys.modules on Windows.  Relative imports would then re-execute this file.
_SMS_IMPORT_MODULE_REF = sys.modules.get(__name__)


def _sms_restore_current_import_registration() -> None:
    module = _SMS_IMPORT_MODULE_REF
    if module is None:
        return
    for key in {str(__name__ or '').strip(), str(__package__ or '').strip()}:
        if key:
            sys.modules[key] = module


_sms_restore_current_import_registration()

try:
    _sms_ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
    if isinstance(_sms_ns, dict):
        _sms_ns['SMART_MODELING_SUITE_RNA_UNSAFE_UNTIL'] = time.monotonic() + 1.25
except Exception:
    pass


# --- Blender Extension policy cleanup START ---
def _sms_remove_legacy_top_level_module_alias() -> None:
    """Remove bare ``smart_modeling_suite`` modules when running as an Extension.

    Blender Extensions are imported under ``bl_ext.<repository>.<id>``.  Older
    builds added a legacy ``sys.modules['smart_modeling_suite']`` alias for
    non-extension compatibility, but Blender flags that bare top-level module
    as an Extension policy violation.  Keep the normal package name only when
    the add-on is actually loaded as a legacy non-extension add-on.
    """
    try:
        if (__name__ or '') == 'smart_modeling_suite':
            return
        package_root = os.path.normcase(os.path.abspath(os.path.dirname(__file__)))
        for module_name, module in list(sys.modules.items()):
            name = str(module_name or '')
            if name != 'smart_modeling_suite' and not name.startswith('smart_modeling_suite.'):
                continue
            if module is None:
                sys.modules.pop(module_name, None)
                continue
            module_file = str(getattr(module, '__file__', '') or '')
            if not module_file:
                sys.modules.pop(module_name, None)
                continue
            module_path = os.path.normcase(os.path.abspath(module_file))
            if module_path == package_root or module_path.startswith(package_root + os.sep):
                sys.modules.pop(module_name, None)
    except Exception:
        pass


_sms_remove_legacy_top_level_module_alias()
# --- Blender Extension policy cleanup END ---


# --- Smart Modeling legacy python_site sys.path cleanup v26 START ---
def _sms_remove_legacy_python_site_from_sys_path_v26() -> None:
    """Remove stale extension-local python_site entries left by older builds.

    v25 and earlier could append ``./python_site`` for optional Tissue/Numba
    acceleration. Blender Extension policy flags that entry. This cleanup only
    removes the known stale Smart Modeling entry and never adds anything to
    ``sys.path``.
    """
    try:
        package_root = os.path.normcase(os.path.normpath(os.path.abspath(os.path.dirname(__file__))))
        cleaned = []
        changed = False
        for entry in list(sys.path):
            raw = str(entry or "").strip()
            normalized = os.path.normpath(raw.replace('\\', os.sep).replace('/', os.sep)) if raw else raw
            is_relative_python_site = normalized in {"python_site", os.path.join(".", "python_site")}
            if raw:
                absolute = normalized if os.path.isabs(normalized) else os.path.abspath(os.path.join(package_root, normalized))
                absolute = os.path.normcase(os.path.normpath(absolute))
            else:
                absolute = ""
            basename = os.path.basename(absolute).lower() if absolute else ""
            inside_suite = absolute.startswith(package_root + os.sep) or absolute == os.path.join(package_root, "python_site")
            if basename == "python_site" and (inside_suite or is_relative_python_site):
                changed = True
                continue
            cleaned.append(entry)
        if changed:
            sys.path[:] = cleaned
    except Exception:
        pass


_sms_remove_legacy_python_site_from_sys_path_v26()
# --- Smart Modeling legacy python_site sys.path cleanup v26 END ---


# --- Smart Modeling stale timer guard v12 START ---
def _sms_cancel_stale_runtime_timers_v12() -> None:
    """Release only exact Smart Modeling receipts from an older generation.

    No ``sys.modules`` traversal, callback-name matching, shared handler scan, or
    foreign resource mutation is permitted.  Integrated modules remain
    responsible for their own exact timers/draw handlers; the package-level
    generation ledger provides a final exact handler rollback.
    """
    try:
        from . import status_runtime as _sms_status_runtime
        _sms_status_runtime.restore_legacy_process_api_receipts()
        _sms_status_runtime.restore_package_handlers('smart_modeling_suite')
        _sms_status_runtime.release_handler_generations('smart_modeling_suite')
    except Exception:
        pass
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if isinstance(ns, dict):
            ns['SMART_MODELING_SUITE_RUNTIME_TOKEN'] = None
            ns['SMART_MODELING_SUITE_REGISTERING_NATIVE_TOOL'] = False
    except Exception:
        pass

_sms_cancel_stale_runtime_timers_v12()


def _sms_release_loaded_exact_property_ledgers_v1() -> int:
    """Release only descriptors recorded by already-loaded Suite modules."""
    removed = 0
    for suffix, cleanup_name in (
        ('key_operators_toolkit.fix_maya_pivot.utils.register_extensions',
         'release_all_shared_scene_properties'),
        ('key_operators_toolkit.fix_maya_pivot.operators.cad_decimate',
         '_unregister_cad_properties'),
    ):
        module = sys.modules.get(f'{__package__}.{suffix}')
        cleanup = getattr(module, cleanup_name, None) if module is not None else None
        if not callable(cleanup):
            continue
        try:
            value = cleanup()
            if isinstance(value, int):
                removed += value
        except Exception:
            pass
    return removed


def _sms_quit_pre_mark_shutdown_v26(*_args):
    """Mark Smart Modeling inactive before Blender destroys workspaces, panels, and timers."""
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if isinstance(ns, dict):
            ns['SMART_MODELING_SUITE_SHUTTING_DOWN'] = True
            ns['SMART_MODELING_SUITE_RUNTIME_TOKEN'] = None
            ns['SMART_MODELING_SUITE_RNA_UNSAFE_UNTIL'] = time.monotonic() + 3600.0
    except Exception:
        pass
    try:
        _sms_cancel_stale_runtime_timers_v12()
    except Exception:
        pass


def _sms_install_quit_pre_guard_v26() -> None:
    try:
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        collection = getattr(handlers, 'quit_pre', None) if handlers is not None else None
        if collection is None:
            return
        if not any(callback is _sms_quit_pre_mark_shutdown_v26 for callback in tuple(collection)):
            collection.append(_sms_quit_pre_mark_shutdown_v26)
    except Exception:
        pass


def _sms_purge_stale_load_handlers_v13() -> None:
    """Compatibility no-op; stale handlers require an exact generation receipt."""
    return None

_sms_purge_stale_load_handlers_v13()

# --- Smart Modeling stale timer guard v12 END ---


# --- Toolset console-clean early install v60 START ---
try:
    from . import console_clean as _safe_console_clean
    _safe_console_clean.install()
except Exception:
    pass
finally:
    # A mixed-case Extension install must never disappear from sys.modules while
    # its __init__.py is still executing.  This also protects users updating over
    # older builds that retained the historical cleanup list.
    _sms_restore_current_import_registration()
# --- Toolset console-clean early install v60 END ---

# --- Toolset Smart Tools stale preference cleanup v20 START ---
def _safe_remove_legacy_scene_core_property_v40() -> None:
    """Remove stale Scene.core from older Smart Modeling builds.

    Current Smart Modeling stores N-panel state on WindowManager and in
    user_default JSON. Older generated builds used context.scene.core with a
    show_always_on_toggles callback; crash logs show that stale path entering
    panel_draw_header on Blender 5.1. Remove it only as part of legacy suite
    cleanup, never for ordinary current registration.
    """
    try:
        if hasattr(bpy.types.Scene, "core"):
            delattr(bpy.types.Scene, "core")
    except Exception:
        pass

def _safe_smart_tools_cleanup_stale_external_addons_v20() -> None:
    try:
        import sys as _sys
        _stale = (
            "bl_ext.user_default.smart_tools_window_prototype",
            "bl_ext.user_default.smart_tools_independent_window_shell",
            "bl_ext.user_default.view_plane_generator",
            "bl_ext.user_default.smart_tools_browser_prototype",
            "bl_ext.user_default.smart_tools_window",
            "smart_tools_window_prototype",
            "smart_tools_independent_window_shell",
            "view_plane_generator",
            "smart_tools_browser_prototype",
            "smart_tools_window",
        )
        changed = False
        removed_legacy_suite = False
        prefs = getattr(getattr(bpy, "context", None), "preferences", None)
        addons = getattr(prefs, "addons", None) if prefs is not None else None
        if addons is not None:
            for _name in _stale:
                _entry = None
                try:
                    _entry = addons.get(_name)
                except Exception:
                    _entry = None
                if _entry is None:
                    try:
                        _entry = addons[_name]
                    except Exception:
                        _entry = None
                if _entry is not None:
                    if str(_name or '').endswith('Smart_Modeling_Suite'):
                        removed_legacy_suite = True
                    try:
                        _legacy_mod = _sys.modules.get(str(_name or ''))
                        _legacy_unregister = getattr(_legacy_mod, 'unregister', None) if _legacy_mod is not None else None
                        if callable(_legacy_unregister):
                            _legacy_unregister()
                    except Exception:
                        pass
                    try:
                        addons.remove(_entry)
                        changed = True
                    except Exception:
                        try:
                            del addons[_name]
                            changed = True
                        except Exception:
                            pass
                try:
                    _popped = _sys.modules.pop(_name, None)
                    if _popped is not None and str(_name or '').endswith('Smart_Modeling_Suite'):
                        removed_legacy_suite = True
                except Exception:
                    pass
        try:
            wm = getattr(getattr(bpy, "context", None), "window_manager", None)
            keyconfigs = getattr(wm, "keyconfigs", None) if wm is not None else None
            for _config_name in ("addon",):
                _kc = getattr(keyconfigs, _config_name, None) if keyconfigs is not None else None
                _keymaps = getattr(_kc, "keymaps", None) if _kc is not None else None
                if _keymaps is None:
                    continue
                try:
                    _km = _keymaps.get("User Interface")
                except Exception:
                    _km = None
                if _km is None:
                    continue
                try:
                    if len(getattr(_km, "keymap_items", ())) == 0:
                        _keymaps.remove(_km)
                        changed = True
                except Exception:
                    pass
        except Exception:
            pass
        if removed_legacy_suite:
            _safe_remove_legacy_scene_core_property_v40()
        # Do not call save_userpref during package import/register. Saving
        # preferences from startup cleanup can re-enter Blender UI drawing while
        # extension classes are still being refreshed. The explicit N-panel
        # Save Preferences button remains responsible for user-initiated saves.
        if changed:
            pass
    except Exception:
        pass

# Do not modify Preferences.addons or delete Scene RNA properties during package
# import/register. On Blender 5.1.0 Windows the Preferences UI can still be
# handling the install event, and changing add-on collections/RNA here may crash
# in ui_handler_panel before Python can catch it. Stale artifacts are ignored by
# the current package and disappear after restart.
# _safe_smart_tools_cleanup_stale_external_addons_v20()
# --- Toolset Smart Tools stale preference cleanup v20 END ---

from bpy.props import BoolProperty



# --- Toolset stale wrapper quarantine START ---
def _safe_purge_stale_wrapper_artifacts() -> None:
    """Unload obsolete wrapper modules without mutating the Extension package.

    Old wrapper files may still contain migration information, so the installed
    package is treated as a read-only source.  Generated or migrated data belongs
    under Blender CONFIG/Smart_Modeling_Suite and is handled by the storage layer.
    """
    try:
        import sys
        prefix = str(__package__ or __name__ or '').strip('.')
        if prefix:
            for key in tuple(sys.modules.keys()):
                text = str(key or '').strip()
                if not text:
                    continue
                if not text.startswith(prefix + '.'):
                    continue
                if text.endswith('.smart_tools_unified_entry') or text.endswith('._smarttools_impl'):
                    sys.modules.pop(key, None)
    except Exception:
        pass

_safe_purge_stale_wrapper_artifacts()
_sms_restore_current_import_registration()
# --- Toolset stale wrapper quarantine END ---

from . import runtime as _runtime
_SUITE_SMART_TOOLS_BOOT_KEY = 'smart_modeling_suite'


def _safe_boot_desired_enabled(default: bool = True) -> bool:
    return bool(default)


def _safe_boot_preflight_cleanup(runtime_module, package_name, module_name, module_file):
    if runtime_module is None:
        return None
    try:
        if not _safe_boot_desired_enabled(True):
            return None
    except Exception:
        pass
    try:
        return runtime_module.preflight_cleanup(package_name, module_name, module_file)
    except TypeError:
        try:
            return runtime_module.preflight_cleanup(package_name, module_name, module_file, force=False)
        except Exception:
            return None
    except Exception:
        return None

from . import navigation_bridge as _navigation_bridge
from .bootstrap_common import (
    anchored_namespace_value as _anchored_namespace_value,
    begin_class_ownership_generation as _begin_class_ownership_generation,
    class_belongs_to_current_package as _exact_class_belongs_to_current_package,
    cleanup_stale_owned_classes as _cleanup_stale_owned_classes,
    drop_anchored_namespace_value as _drop_anchored_namespace_value,
    publish_anchored_namespace_value as _publish_anchored_namespace_value,
    release_current_owned_classes as _release_current_owned_classes,
    safe_register_class as _safe_register_class_common,
    safe_unregister_class as _safe_unregister_class_common,
)

__version__ = "1.3.119"

bl_info = {
    "name": 'Smart Modeling',
    "author": 'JELararagi',
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "location": "View3D > Sidebar > Smart Modeling",
    "description": "Smart Modeling stores and exposes its settings in the 3D View Sidebar N-panel category Smart Modeling.",
    "category": 'Smart Modeling',
}

_ROOT_PACKAGE = (__package__ or __name__ or '').strip() or 'smart_modeling_suite'
_RUNTIME_MODULES = (
    'core',
)
_PROXY_ADDON_KEY = 'smart_modeling_suite'
_PROXY_LABEL = 'Smart Modeling'
_PROXY_ICON = 'MESH_CUBE'
_PROXY_OPERATOR_ID = 'smart_modeling_suite.open_window'
_PROXY_ORDER = 50
_OWNER_KEY = 'SMART_MODELING_SUITE_OWNER'
_STX_USERPREF_ADDONS_PATCH = {'cls': None, 'draw_addon_preferences': None}
_LOADED_MODULES: dict[str, object] = {}
_TRANSLATIONS = {
    'ja_JP': {
        ('*', 'Open Smart Tools'): 'Smart Tools を開く',
        ('*', 'Smart Tools'): 'Smart Tools',
        ('Operator', 'Open the Smart Modeling N-panel. Tool settings and keymap commands load only when used.'): 'Smart Modeling Nパネルを開きます。各ツールの設定とキーマップコマンドは、使用時だけ読み込まれます。',
    },
}


# ------------------------------------------------------------------------------
# Duplicate-registration guard:
# If both an old wrapped package and this flattened package are installed,
# only the first one that registers becomes the active owner to avoid
# duplicate keymaps, handlers, and shared Smart Tools UI registrations.
# ------------------------------------------------------------------------------
def _sms_get_owner():
    # Blender replaces bpy.app.driver_namespace on every file load (measured on
    # 5.1.2 ec6e62d40fa9), which silently disarmed this guard after the user's
    # first .blend open.  The process anchor keeps the receipt reachable and
    # re-publishes it into the fresh namespace on first read.
    try:
        return _anchored_namespace_value(_OWNER_KEY)
    except Exception:
        return None


def _sms_set_owner(owner):
    try:
        _publish_anchored_namespace_value(_OWNER_KEY, owner)
    except Exception:
        pass


def _sms_clear_owner(owner):
    try:
        _drop_anchored_namespace_value(_OWNER_KEY, expected=owner, match_expected=True)
    except Exception:
        pass


def _sms_can_register():
    """Claim the package owner slot without silently hiding the Suite.

    A live foreign owner remains authoritative and registration is rejected with
    one explicit warning.  A stale owner string whose module is no longer loaded
    is reclaimed without scanning ``sys.modules`` or touching foreign resources.
    """
    owner = _sms_get_owner()
    if owner and owner != __package__:
        if sys.modules.get(str(owner)) is None:
            _sms_set_owner(__package__)
            return True
        print(
            "[Smart Modeling Suite] WARNING: registration skipped because the "
            f"live owner {owner!r} still holds the exact package receipt."
        )
        return False
    _sms_set_owner(__package__)
    return True


# Remove stale legacy files and already-imported removed integrated modules as
# early as possible. The standalone extension no longer ships those payloads,
# so older in-place installs are cleaned before any runtime state is restored.
try:
    _safe_boot_preflight_cleanup(_runtime, __package__, __name__, __file__)
except Exception:
    pass


def _qualify_module_name(module_name: str) -> str:
    text = str(module_name or '').strip()
    if not text:
        return text
    if text == _ROOT_PACKAGE or text.startswith(_ROOT_PACKAGE + '.'):
        return text
    return f'{_ROOT_PACKAGE}.{text}'


def _import_module(module_name: str):
    qualified = _qualify_module_name(module_name)
    module = sys.modules.get(qualified)
    if module is not None:
        try:
            # After an in-place reinstall Blender reloads this package file, but
            # submodules may still be the previous copy in sys.modules.  If the
            # old runtime has already been unregistered, reload it so newly
            # added operators and UI fixes are available without requiring a
            # manual Blender restart.  Do not reload an actively registered
            # runtime module; that can invalidate open panel custom data.
            if not bool(getattr(module, '_smart_modeling_suite_registered', False)):
                return importlib.reload(module)
        except Exception:
            pass
        return module
    return importlib.import_module(qualified)


def _language_module():
    return _import_module('language')


def _pick_text(en: str, ja: str, context=None) -> str:
    return _language_module().pick_text(en, ja, context=context)


def _safe_register_class(cls) -> bool:
    return bool(_safe_register_class_common(cls))


def _safe_unregister_class(cls) -> None:
    _safe_unregister_class_common(cls)


def _module_registered(module) -> bool:
    return bool(getattr(module, '_smart_modeling_suite_registered', False))


def _set_module_registered(module, value: bool) -> None:
    try:
        setattr(module, '_smart_modeling_suite_registered', bool(value))
    except Exception:
        pass


def _module_key(module) -> str:
    name = str(getattr(module, '__name__', '') or '').strip()
    if '.' in name:
        return name.rsplit('.', 1)[-1]
    return name or 'module'


def _register_module_object(module, module_key: str | None = None):
    key = str(module_key or _module_key(module)).strip() or _module_key(module)
    if not _module_registered(module):
        register_fn = getattr(module, 'register', None)
        if callable(register_fn):
            try:
                register_fn()
            except Exception:
                # register() can fail after creating part of its RNA surface.
                # Roll that exact module back before a retry so an enabled
                # extension never depends on an N-panel draw to repair it.
                unregister_fn = getattr(module, 'unregister', None)
                if callable(unregister_fn):
                    try:
                        unregister_fn()
                    except Exception:
                        pass
                _set_module_registered(module, False)
                _LOADED_MODULES.pop(key, None)
                raise
        _set_module_registered(module, True)
    _LOADED_MODULES[key] = module
    return module


def _unregister_module_object(module, module_key: str | None = None) -> None:
    key = str(module_key or _module_key(module)).strip() or _module_key(module)
    if _module_registered(module):
        unregister_fn = getattr(module, 'unregister', None)
        if callable(unregister_fn):
            unregister_fn()
        _set_module_registered(module, False)
    _LOADED_MODULES.pop(key, None)


def _register_runtime_module(module_name: str):
    return _register_module_object(_import_module(module_name), module_name)


def _unregister_runtime_module(module_name: str) -> None:
    module = _LOADED_MODULES.get(module_name)
    if module is None:
        module = sys.modules.get(_qualify_module_name(module_name))
    if module is None:
        return
    _unregister_module_object(module, module_name)


def _runtime_loaded() -> bool:
    module = _LOADED_MODULES.get('core')
    if module is None:
        module = sys.modules.get(_qualify_module_name('core'))
    return bool(module is not None and _module_registered(module))


def _prime_preferences_subgroups(context=None):
    """Compatibility no-op.

    Do not force WindowManager/Panel RNA access from the package bootstrap.
    The core runtime creates the N-panel settings property during normal class
    registration, and each tool initializes its nested settings lazily when used.
    This avoids C/RNA crashes during add-on reinstall or shutdown.
    """
    return None

def _unload_full_runtime(*, restore_bootstrap_preferences: bool = False) -> None:
    for module_name in reversed(_RUNTIME_MODULES):
        try:
            _unregister_runtime_module(module_name)
        except Exception:
            pass
    if restore_bootstrap_preferences:
        try:
            _register_bootstrap_modules()
        except Exception:
            pass


def _purge_runtime_module_cache_v22() -> None:
    """Drop cached runtime submodules before loading the current ZIP contents.

    Blender's in-place extension reinstall can keep Python submodules from the
    previous archive in sys.modules even after the new manifest is detected.
    v1.2.19-v1.2.21 changed N-panel tool settings to independent WindowManager
    properties; this build restores the v1.2.17-compatible nested settings
    layout, so stale runtime modules must not be reused.
    """
    root = str(_ROOT_PACKAGE or __package__ or '').strip()
    if not root:
        return
    prefixes = (
        root + '.core',
        root + '.utils',
        root + '.preferences',
        root + '.vertex_slide',
        root + '.direct_delete',
        root + '.apply_weighted_normal',
        root + '.crease_preset',
        root + '.toggle_auto_merge_snap',
        root + '.key_operators_toolkit',
        root + '.polyquilt_fork',
        root + '.tissue',
    )
    for name in list(sys.modules.keys()):
        if any(name == prefix or name.startswith(prefix + '.') for prefix in prefixes):
            try:
                sys.modules.pop(name, None)
            except Exception:
                pass
    try:
        _LOADED_MODULES.clear()
    except Exception:
        pass


def _ensure_full_runtime_loaded() -> tuple[bool, str]:
    if _runtime_loaded():
        return True, ''

    failures: list[tuple[str, BaseException, str]] = []
    try:
        _unregister_bootstrap_modules()
    except Exception:
        pass

    registered_now: list[str] = []
    for module_name in _RUNTIME_MODULES:
        try:
            _register_runtime_module(module_name)
            registered_now.append(module_name)
        except Exception as exc:
            trace = traceback.format_exc()
            # Keep the core Smart Tools runtime active even when optional
            # integrated tool runtime pieces fail. A partial load is still far
            # better than falling back to an empty proxy entry.
            if module_name == 'tool_runtime' and 'core' in registered_now:
                # Keep the bounded diagnostic in module state; normal registration
                # must not write to the process console.
                globals()['_SMS_LAST_RUNTIME_NOTICE'] = str(exc)[:512]
                break
            failures.append((module_name, exc, trace))
            break

    if failures:
        for module_name in reversed(registered_now):
            try:
                _unregister_runtime_module(module_name)
            except Exception:
                pass
        try:
            _register_bootstrap_modules()
        except Exception:
            pass
        label, exc, trace = failures[0]
        globals()['_SMS_LAST_RUNTIME_NOTICE'] = f'{label}: {exc}'[:512]
        return False, f'{label}: {exc}'

    _prime_preferences_subgroups(bpy.context)
    return True, ''




def _panel_class_belongs_to_current_package(cls) -> bool:
    return _exact_class_belongs_to_current_package(cls)

def _purge_stale_smarttools_proxy_panels() -> int:
    return _cleanup_stale_owned_classes(panels_only=True)


def _tag_redraw_view3d_areas() -> None:
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        unsafe_until = float((ns or {}).get('SMART_MODELING_SUITE_RNA_UNSAFE_UNTIL', 0.0) or 0.0) if isinstance(ns, dict) else 0.0
        if unsafe_until and time.monotonic() < unsafe_until:
            return
    except Exception:
        return
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    except Exception:
        wm = None
    for window in getattr(wm, 'windows', ()) if wm is not None else ():
        screen = getattr(window, 'screen', None)
        for area in getattr(screen, 'areas', ()) if screen is not None else ():
            try:
                if str(getattr(area, 'type', '') or '') == 'VIEW_3D':
                    area.tag_redraw()
            except Exception:
                pass


_SMS_INITIAL_NPANEL_REFRESH_PENDING = False


def _sms_initial_npanel_refresh_timer():
    """One-shot redraw after add-on enable/install so the 3D View Sidebar shows immediately.

    This timer is intentionally UI-only.  It does not create RNA properties or
    register classes, avoiding the stale-RNA crash path that can happen during
    extension install/reload.
    """
    global _SMS_INITIAL_NPANEL_REFRESH_PENDING
    _SMS_INITIAL_NPANEL_REFRESH_PENDING = False
    try:
        if _sms_get_owner() not in (None, __package__):
            return None
    except Exception:
        return None
    try:
        _install_proxy_entry()
    except Exception:
        pass
    try:
        _navigation_bridge.force_runtime_refresh()
    except Exception:
        pass
    try:
        _tag_redraw_view3d_areas()
    except Exception:
        pass
    return None


def _schedule_initial_npanel_refresh() -> None:
    global _SMS_INITIAL_NPANEL_REFRESH_PENDING
    _SMS_INITIAL_NPANEL_REFRESH_PENDING = False
    # Keep startup free of delayed UI/RNA callbacks.  The Smart Tools proxy entry
    # is installed synchronously; redraw happens when Blender draws the UI.
    return


def _cancel_initial_npanel_refresh() -> None:
    global _SMS_INITIAL_NPANEL_REFRESH_PENDING
    _SMS_INITIAL_NPANEL_REFRESH_PENDING = False
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and timers.is_registered(_sms_initial_npanel_refresh_timer):
            timers.unregister(_sms_initial_npanel_refresh_timer)
    except Exception:
        pass


def _install_proxy_entry() -> None:
    try:
        _navigation_bridge.install(
            _PROXY_ADDON_KEY,
            _PROXY_LABEL,
            _PROXY_ICON,
            _PROXY_OPERATOR_ID,
            (),
            order=_PROXY_ORDER,
        )
    except Exception:
        pass
    _purge_stale_smarttools_proxy_panels()
    # Avoid forced Sidebar redraw while Blender is replacing Panel classes.


def _uninstall_proxy_entry() -> None:
    try:
        _navigation_bridge.uninstall(_PROXY_ADDON_KEY)
    except Exception:
        pass
    _purge_stale_smarttools_proxy_panels()
    # Avoid forced Sidebar redraw while Blender is replacing Panel classes.


_SMS_REPAIR_TIMER_ATTEMPTS = 0
_SMS_REPAIR_TIMER_ENABLED = False


def _sms_runtime_repair_timer():
    """Compatibility timer kept only so older registration calls can be cancelled.

    The repair pass used to run shortly after registration and after opening the
    N-panel. Crash logs showed this timer touching nested settings while Blender
    was refining or removing Panel RNA during reinstall. It is now disabled by
    default and returns immediately if invoked by a stale registration.
    """
    global _SMS_REPAIR_TIMER_ATTEMPTS
    _SMS_REPAIR_TIMER_ATTEMPTS = 0
    if not _SMS_REPAIR_TIMER_ENABLED:
        return None
    try:
        if _sms_get_owner() not in (None, __package__):
            return None
    except Exception:
        return None
    try:
        _sms_repair_runtime(bpy.context)
    except Exception:
        pass
    return None


def _schedule_runtime_repair(attempts: int = 1) -> None:
    """No-op repair scheduler.

    Runtime initialization is performed synchronously in register()/open paths and
    by core load_post handlers. Avoid scheduling a bpy timer here because add-on
    reinstall can execute it against stale RNA/Panel objects and crash Blender.
    """
    global _SMS_REPAIR_TIMER_ATTEMPTS
    _SMS_REPAIR_TIMER_ATTEMPTS = 0
    try:
        if bpy.app.timers.is_registered(_sms_runtime_repair_timer):
            bpy.app.timers.unregister(_sms_runtime_repair_timer)
    except Exception:
        pass


def _sms_repair_runtime(context=None) -> None:
    # Keep this repair pass UI-only and RNA-safe. File/module cleanup and child
    # PointerProperty creation are intentionally not performed from this path,
    # because it may run during add-on refresh/reinstall when Blender is still
    # refining or removing Panel RNA.
    if not _runtime_loaded():
        try:
            _install_proxy_entry()
            proxy_installed = True
        except Exception:
            pass
        return

    try:
        _navigation_bridge.force_runtime_refresh()
    except Exception:
        pass


def ensure_runtime_initialized(context=None, *args, force: bool = False, **kwargs):
    try:
        ok, _reason = _ensure_full_runtime_loaded()
    except Exception:
        return False
    if not ok:
        return False
    try:
        _sms_repair_runtime(context or bpy.context)
    except Exception:
        pass
    _schedule_runtime_repair(attempts=2 if force else 1)
    return True


class SMS_OT_open_smart_tools(bpy.types.Operator):
    bl_idname = 'smart_modeling_suite.open_window'
    bl_label = 'Open Smart Tools'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True
    bl_description = 'Open the Smart Modeling N-panel. Tool settings and keymap commands load only when used.'

    reuse_existing: BoolProperty(default=True, options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        return getattr(getattr(context, 'window_manager', None), 'windows', None) is not None

    def execute(self, context):
        ok, message = _ensure_full_runtime_loaded()
        if not ok:
            return {'CANCELLED'}
        if message:
            pass

        try:
            _sms_repair_runtime(context)
        except Exception:
            pass

        area = context.area
        if area is None or area.type != 'VIEW_3D':
            screen = context.screen
            area = next((item for item in screen.areas if item.type == 'VIEW_3D'), None) if screen else None
        if area is not None:
            area.spaces.active.show_region_ui = True
            area.tag_redraw()

            def select_sidebar_category(attempts=8):
                try:
                    if area.type != 'VIEW_3D' or not area.spaces.active.show_region_ui:
                        return None
                    sidebar = next((region for region in area.regions if region.type == 'UI'), None)
                    if sidebar is not None and not sidebar.is_property_readonly('active_panel_category'):
                        sidebar.active_panel_category = _PROXY_LABEL
                        if sidebar.active_panel_category == _PROXY_LABEL:
                            area.tag_redraw()
                            return None
                except ReferenceError:
                    return None
                except (AttributeError, RuntimeError, TypeError):
                    pass
                if attempts > 1:
                    bpy.app.timers.register(lambda: select_sidebar_category(attempts - 1), first_interval=0.1)
                return None

            select_sidebar_category()

        _purge_stale_smarttools_proxy_panels()
        _tag_redraw_view3d_areas()
        _schedule_runtime_repair(attempts=2)
        return {'FINISHED'}


# No bootstrap preference shim is registered here.
# The runtime preferences panel is provided directly by core.
modules = ()


def _register_bootstrap_modules() -> None:
    for module in modules:
        _register_module_object(module, _module_key(module))


def _unregister_bootstrap_modules() -> None:
    for module in reversed(modules):
        _unregister_module_object(module, _module_key(module))


def register():
    if not _sms_can_register():
        return
    _begin_class_ownership_generation()

    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if isinstance(ns, dict):
            ns['SMART_MODELING_SUITE_SAFE_INSTALLING'] = True
    except Exception:
        pass

    try:
        _safe_boot_preflight_cleanup(_runtime, __package__, __name__, __file__)
    except Exception:
        pass

    translations_registered = False
    operator_registered = False
    bootstrap_registered = False
    proxy_installed = False
    try:
        _language_module().install()
        _register_bootstrap_modules()
        bootstrap_registered = True

        try:
            bpy.app.translations.unregister(__name__)
        except Exception:
            pass
        bpy.app.translations.register(__name__, _TRANSLATIONS)
        translations_registered = True

        if not _safe_register_class(SMS_OT_open_smart_tools):
            raise RuntimeError('Smart Modeling operator registration collision')
        operator_registered = True

        _prime_preferences_subgroups(bpy.context)
        # Install the Smart Modeling N-panel entry first, then immediately
        # initialize the runtime so the sidebar can draw the real tool UI.
        try:
            _install_proxy_entry()
        except Exception:
            pass

        ok, message = _ensure_full_runtime_loaded()
        if not ok:
            # A failed core registration must not leave the extension enabled
            # without its keymap entrypoints.  Retry once after an exact runtime
            # teardown; do not purge module identities during normal startup.
            _unload_full_runtime(restore_bootstrap_preferences=False)
            ok, retry_message = _ensure_full_runtime_loaded()
            if retry_message:
                message = retry_message
        if not ok:
            detail = (
                'Smart Modeling runtime registration failed: '
                + str(message or 'unknown runtime registration error')
            )
            globals()['_SMS_LAST_RUNTIME_NOTICE'] = detail[:512]
            raise RuntimeError(detail)

        # No forced unload/reload, panel repair, or delayed UI timer from register().
        # Those paths can invalidate open Sidebar panel custom data during extension install.

        try:
            ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
            if isinstance(ns, dict):
                ns['SMART_MODELING_SUITE_SAFE_INSTALLING'] = False
        except Exception:
            pass
    except Exception:
        if proxy_installed:
            try:
                _uninstall_proxy_entry()
            except Exception:
                pass
        if operator_registered:
            _safe_unregister_class(SMS_OT_open_smart_tools)
        if translations_registered:
            try:
                bpy.app.translations.unregister(__name__)
            except Exception:
                pass
        try:
            _language_module().uninstall()
        except Exception:
            pass
        try:
            _unload_full_runtime(restore_bootstrap_preferences=False)
        except Exception:
            pass
        if bootstrap_registered:
            try:
                _unregister_bootstrap_modules()
            except Exception:
                pass
        try:
            ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
            if isinstance(ns, dict):
                ns['SMART_MODELING_SUITE_SAFE_INSTALLING'] = False
        except Exception:
            pass
        try:
            # Remove only classes recorded by this exact registration
            # generation.  This closes partial core.register() failures without
            # mutating Blender or another add-on's RNA identities.
            _release_current_owned_classes()
        except Exception:
            pass
        _sms_clear_owner(__package__)
        raise


def unregister():
    if _sms_get_owner() not in (None, __package__):
        return
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if isinstance(ns, dict):
            ns['SMART_MODELING_SUITE_SAFE_INSTALLING'] = True
    except Exception:
        pass
    try:
        _cancel_initial_npanel_refresh()
        try:
            if bpy.app.timers.is_registered(_sms_runtime_repair_timer):
                bpy.app.timers.unregister(_sms_runtime_repair_timer)
        except Exception:
            pass

        try:
            _uninstall_proxy_entry()
        except Exception:
            pass

        _safe_unregister_class(SMS_OT_open_smart_tools)
        _unload_full_runtime(restore_bootstrap_preferences=False)
        _unregister_bootstrap_modules()

        try:
            bpy.app.translations.unregister(__name__)
        except Exception:
            pass
        try:
            _language_module().uninstall()
        except Exception:
            pass
    finally:
        try:
            ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
            if isinstance(ns, dict):
                ns['SMART_MODELING_SUITE_SAFE_INSTALLING'] = False
        except Exception:
            pass
        try:
            _release_current_owned_classes()
        except Exception:
            pass
        _sms_clear_owner(__package__)


# Tooltip audit disabled for lower startup cost.


if __name__ == '__main__':
    try:
        unregister()
    except Exception:
        pass
    register()



# --- Toolset Smart Tools standard N-panel compatibility START ---
# Smart Modeling uses ordinary 3D View Sidebar panels directly.
# Legacy wrapper code is disabled so the sidebar keeps Blender's native drawing behavior.
# --- Toolset Smart Tools standard N-panel compatibility END ---

# --- Toolset Smart Modeling N-panel open-by-default wrapper START ---
# Copyright (C) 2026 JELararagi. All Rights Reserved.

def _safe_npanel_open_default_context():
    try:
        return bpy.context
    except Exception:
        return None


def _safe_npanel_open_default_call(fn, context=None):
    if not callable(fn):
        return None
    ctx = context or _safe_npanel_open_default_context()
    for args, kwargs in (
        ((ctx,), {'force': False}),
        ((ctx,), {'refresh_ui': True}),
        ((ctx,), {}),
        ((), {'context': ctx}),
        ((), {}),
    ):
        try:
            return fn(*args, **kwargs)
        except TypeError:
            continue
        except Exception:
            return None
    return None


def _safe_npanel_open_default_activate(context=None):
    ctx = context or _safe_npanel_open_default_context()
    package_key = str(__package__ or __name__ or '').rsplit('.', 1)[-1]

    # Smart Render must not load the heavy integrated runtime at enable time.
    # Register only its lightweight settings UI so the N-panel is populated
    # immediately without the startup freeze caused by tools_runtime.
    if package_key == 'smart_render_suite':
        try:
            _reg = globals().get('registration')
            _register = getattr(_reg, 'register', None)
            if callable(_register):
                _register()
        except Exception:
            pass
        try:
            _repair = globals().get('_srs_repair_runtime')
            if callable(_repair):
                _repair(ctx)
        except Exception:
            pass
        try:
            _schedule = globals().get('_schedule_runtime_repair')
            if callable(_schedule):
                _schedule(attempts=2)
        except Exception:
            pass
        return True

    for _name in (
        'ensure_runtime_initialized',
        'ensure_full_runtime_loaded',
        '_sf_ensure_full_runtime_loaded',
        '_ensure_full_runtime_loaded',
    ):
        _fn = globals().get(_name)
        if callable(_fn):
            _safe_npanel_open_default_call(_fn, ctx)

    for _name, _fn in list(globals().items()):
        try:
            if callable(_fn) and str(_name).endswith('_repair_runtime'):
                _safe_npanel_open_default_call(_fn, ctx)
        except Exception:
            pass
    try:
        _schedule = globals().get('_schedule_runtime_repair')
        if callable(_schedule):
            _schedule(attempts=2)
    except Exception:
        pass
    return True


try:
    _SUITE_NPANEL_OPEN_DEFAULT_ORIG_REGISTER = register
    _SUITE_NPANEL_OPEN_DEFAULT_ORIG_UNREGISTER = unregister
except Exception:
    pass
else:
    if callable(_SUITE_NPANEL_OPEN_DEFAULT_ORIG_REGISTER) and not getattr(_SUITE_NPANEL_OPEN_DEFAULT_ORIG_REGISTER, '_safe_npanel_open_default_wrapped', False):
        def register():
            # Do not force-open or force-refresh the N-panel during extension
            # installation. Opening the Sidebar while Blender is replacing panel
            # RNA can crash in ui_handler_panel on 5.1.0 Windows.
            return _SUITE_NPANEL_OPEN_DEFAULT_ORIG_REGISTER()
        register._safe_npanel_open_default_wrapped = True

# --- Toolset Smart Modeling N-panel open-by-default wrapper END ---

# --- Toolset console-clean final wrapper v60 START ---
try:
    _SUITE_CONSOLE_CLEAN_ORIG_REGISTER_V60
except NameError:
    _SUITE_CONSOLE_CLEAN_ORIG_REGISTER_V60 = register
    _SUITE_CONSOLE_CLEAN_ORIG_UNREGISTER_V60 = unregister if 'unregister' in globals() else None

    def _safe_console_clean_install_v60():
        try:
            from . import console_clean as _safe_console_clean
            _safe_console_clean.install()
        except Exception:
            pass

    def register():
        _safe_console_clean_install_v60()
        result = _SUITE_CONSOLE_CLEAN_ORIG_REGISTER_V60()
        _safe_console_clean_install_v60()
        return result

    def unregister():
        try:
            from . import console_clean as _safe_console_clean
            _safe_console_clean.sanitize_panel_draws()
        except Exception:
            pass
        if callable(_SUITE_CONSOLE_CLEAN_ORIG_UNREGISTER_V60):
            return _SUITE_CONSOLE_CLEAN_ORIG_UNREGISTER_V60()
        return None
# --- Toolset console-clean final wrapper v60 END ---



def _sms_suspend_sidebar_regions_for_reinstall() -> None:
    """Do not touch Space.show_region_ui during install, reinstall, or quit.

    Older builds temporarily closed and reopened the 3D View Sidebar while Panel
    RNA was being replaced.  Blender 5.1.0 Windows can call add-on unregister
    during WM_exit_ex after the active workspace has already been released; any
    write to Space.show_region_ui at that point enters ED_region_visibility_* and
    can crash natively.  Panel churn is now handled by in-place class patching, so
    sidebar visibility must be left exactly as Blender owns it.
    """
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if isinstance(ns, dict):
            ns.pop('SMART_MODELING_SUITE_RESTORE_SIDEBAR_UI', None)
    except Exception:
        pass


def _sms_restore_sidebar_regions_for_reinstall_timer():
    # Legacy one-shot timers from previous builds may still execute after an
    # in-place reinstall.  Never modify UI region visibility from a timer; just
    # discard any saved state and stop.
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if isinstance(ns, dict):
            ns.pop('SMART_MODELING_SUITE_RESTORE_SIDEBAR_UI', None)
    except Exception:
        pass
    return None


def _sms_schedule_sidebar_restore_for_reinstall(delay: float = 1.5) -> None:
    # No-op by design.  Restoring Sidebars from a delayed timer is unsafe during
    # Blender quit and unnecessary now that panel classes are patched in place.
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if isinstance(ns, dict):
            ns.pop('SMART_MODELING_SUITE_RESTORE_SIDEBAR_UI', None)
    except Exception:
        pass
    return None

# --- Smart common extension patch START ---
try:
    from . import common as _SMART_COMMON
except Exception:
    _SMART_COMMON = None

_SMART_ORIGINAL_REGISTER = globals().get('register')
_SMART_ORIGINAL_UNREGISTER = globals().get('unregister')


def _sms_instrument_registered_operator_classes():
    try:
        from . import status_runtime as _status_runtime
        operator_base = getattr(bpy.types, 'Operator', None)
        if operator_base is None:
            return 0
        count = 0
        for cls in tuple(operator_base.__subclasses__()):
            try:
                module_name = str(getattr(cls, '__module__', '') or '')
                if 'smart_modeling_suite' not in module_name.lower():
                    continue
                if not str(getattr(cls, 'bl_idname', '') or '').strip():
                    continue
                _status_runtime.instrument_operator_class(
                    cls, 'smart_modeling_suite', 'Smart Modeling Suite'
                )
                count += 1
            except Exception:
                continue
        return count
    except Exception:
        return 0


def register():
    # Read-only compatibility migration: copy recognized package-local seeds
    # into CONFIG before runtime modules request writable paths. Sources remain
    # untouched and existing CONFIG values take precedence.
    try:
        from . import storage as _sms_storage
        _sms_storage.migrate_legacy_mutable_data()
    except Exception:
        pass
    try:
        _sms_install_quit_pre_guard_v26()
    except Exception:
        pass
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if isinstance(ns, dict):
            ns.pop('SMART_MODELING_SUITE_SHUTTING_DOWN', None)
            ns['SMART_MODELING_SUITE_RUNTIME_TOKEN'] = None
    except Exception:
        pass
    try:
        _sms_cancel_stale_runtime_timers_v12()
    except Exception:
        pass
    try:
        _sms_suspend_sidebar_regions_for_reinstall()
    except Exception:
        pass
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if isinstance(ns, dict):
            ns['SMART_MODELING_SUITE_RNA_UNSAFE_UNTIL'] = time.monotonic() + 1.25
    except Exception:
        pass
    if _SMART_COMMON is not None:
        try:
            _SMART_COMMON.begin_register()
        except Exception:
            pass
    try:
        if callable(_SMART_ORIGINAL_REGISTER):
            _SMART_ORIGINAL_REGISTER()
        try:
            _sms_schedule_sidebar_restore_for_reinstall(delay=1.5)
        except Exception:
            pass
        if _SMART_COMMON is not None:
            _SMART_COMMON.register()
        try:
            from . import blend_cleanup as _sms_blend_cleanup
            _sms_blend_cleanup.register()
        except Exception:
            pass
        try:
            _sms_instrument_registered_operator_classes()
        except Exception:
            pass
        # Keep common wrapper passive during extension install.
    finally:
        if _SMART_COMMON is not None:
            try:
                _SMART_COMMON.end_register()
            except Exception:
                pass


def _sms_shutdown_edit_mode_undo_bridge() -> None:
    """Tear down lazy Edit-Mode Undo support, even after module cache purge."""
    callback = None
    try:
        namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        state = namespace.get('SMART_MODELING_EDIT_MODE_UNDO_BRIDGE') if isinstance(namespace, dict) else None
        if isinstance(state, dict):
            callback = state.get('shutdown_callback')
    except Exception:
        callback = None
    if callable(callback):
        try:
            callback()
            return
        except Exception:
            pass
    try:
        for module_name, module in tuple(sys.modules.items()):
            if not str(module_name).endswith('.fix_maya_pivot.utils.edit_mode_undo_bridge'):
                continue
            shutdown_bridge = getattr(module, 'shutdown', None)
            if callable(shutdown_bridge):
                shutdown_bridge()
                return
    except Exception:
        pass
    # Last-resort import is used only during full Suite disable and only when a
    # live bridge state exists but the optional tool module was purged.
    try:
        namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if not isinstance(namespace, dict) or 'SMART_MODELING_EDIT_MODE_UNDO_BRIDGE' not in namespace:
            return
        module = importlib.import_module(
            f'{_ROOT_PACKAGE}.key_operators_toolkit.fix_maya_pivot.utils.edit_mode_undo_bridge'
        )
        shutdown_bridge = getattr(module, 'shutdown', None)
        if callable(shutdown_bridge):
            shutdown_bridge()
    except Exception:
        pass


def _sms_shutdown_direct_delete_undo_bridge() -> None:
    """Tear down Direct Delete's Edit-Mesh and Object-mode Undo bridges."""
    bridge_specs = (
        (
            'SMART_MODELING_DIRECT_DELETE_UNDO_BRIDGE',
            '.direct_delete.undo_bridge',
            f'{_ROOT_PACKAGE}.direct_delete.undo_bridge',
        ),
        (
            'SMART_MODELING_DIRECT_DELETE_OBJECT_UNDO_BRIDGE',
            '.direct_delete.object_undo_bridge',
            f'{_ROOT_PACKAGE}.direct_delete.object_undo_bridge',
        ),
    )
    for namespace_key, module_suffix, import_name in bridge_specs:
        callback = None
        try:
            namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
            state = namespace.get(namespace_key) if isinstance(namespace, dict) else None
            if isinstance(state, dict):
                callback = state.get('shutdown_callback')
        except Exception:
            callback = None
        if callable(callback):
            try:
                callback()
                continue
            except Exception:
                pass
        stopped = False
        try:
            for module_name, module in tuple(sys.modules.items()):
                if not str(module_name).endswith(module_suffix):
                    continue
                shutdown_bridge = getattr(module, 'shutdown', None)
                if callable(shutdown_bridge):
                    shutdown_bridge()
                    stopped = True
                    break
        except Exception:
            stopped = False
        if stopped:
            continue
        try:
            namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
            if not isinstance(namespace, dict) or namespace_key not in namespace:
                continue
            module = importlib.import_module(import_name)
            shutdown_bridge = getattr(module, 'shutdown', None)
            if callable(shutdown_bridge):
                shutdown_bridge()
        except Exception:
            pass


def _sms_shutdown_mesh_align_undo_bridge() -> None:
    """Tear down Mesh Align directional selection Undo support on full disable."""
    namespace_key = 'SMART_MODELING_MESH_ALIGN_UNDO_BRIDGE'
    callback = None
    try:
        namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        state = namespace.get(namespace_key) if isinstance(namespace, dict) else None
        if isinstance(state, dict):
            callback = state.get('shutdown_callback')
    except Exception:
        callback = None
    if callable(callback):
        try:
            callback()
            return
        except Exception:
            pass
    try:
        for module_name, module in tuple(sys.modules.items()):
            if not str(module_name).endswith('.mesh_align_preset.undo_bridge'):
                continue
            shutdown_bridge = getattr(module, 'shutdown', None)
            if callable(shutdown_bridge):
                shutdown_bridge()
                return
    except Exception:
        pass
    try:
        namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if not isinstance(namespace, dict) or namespace_key not in namespace:
            return
        module = importlib.import_module(f'{_ROOT_PACKAGE}.mesh_align_preset.undo_bridge')
        shutdown_bridge = getattr(module, 'shutdown', None)
        if callable(shutdown_bridge):
            shutdown_bridge()
    except Exception:
        pass


def unregister():
    # Direct Delete and Origin/Modifier transactions install event-only Undo
    # handlers only after first use. Tear them down only during full Suite
    # disable so closing an individual settings section does not invalidate an
    # already-created Undo history.
    _sms_shutdown_direct_delete_undo_bridge()
    _sms_shutdown_mesh_align_undo_bridge()
    # Origin/Modifier Edit-Mode transactions install event-only Undo handlers
    # only after first use. Tear them down during full Suite disable even when
    # the optional Key Operations UI was closed and its module was unloaded.
    _sms_shutdown_edit_mode_undo_bridge()
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if isinstance(ns, dict):
            _shutdown_token = _SMS_DRIVER_NAMESPACE_SHUTTING_DOWN_TOKEN_V1396
            ns['SMART_MODELING_SUITE_SHUTTING_DOWN'] = _shutdown_token
            _sms_remember_owned_namespace_value_v1395(
                'SMART_MODELING_SUITE_SHUTTING_DOWN', _shutdown_token
            )
            ns.pop('SMART_MODELING_SUITE_RESTORE_SIDEBAR_UI', None)
    except Exception:
        pass
    try:
        _sms_cancel_stale_runtime_timers_v12()
    except Exception:
        pass
    try:
        _sms_suspend_sidebar_regions_for_reinstall()
    except Exception:
        pass
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if isinstance(ns, dict):
            _unsafe_until = time.monotonic() + 1.25
            ns['SMART_MODELING_SUITE_RNA_UNSAFE_UNTIL'] = _unsafe_until
            _sms_remember_owned_namespace_value_v1395(
                'SMART_MODELING_SUITE_RNA_UNSAFE_UNTIL', _unsafe_until
            )
    except Exception:
        pass
    try:
        from . import blend_cleanup as _sms_blend_cleanup
        _sms_blend_cleanup.unregister()
    except Exception:
        pass
    if _SMART_COMMON is not None:
        try:
            _SMART_COMMON.unregister()
        except Exception:
            pass
    try:
        if callable(_SMART_ORIGINAL_UNREGISTER):
            _SMART_ORIGINAL_UNREGISTER()
    finally:
        _sms_release_loaded_exact_property_ledgers_v1()
        try:
            from . import status_runtime as _status_runtime
            _status_runtime.clear_prefix('smart_modeling_suite', context=getattr(bpy, 'context', None))
        except Exception:
            pass
# --- Smart common extension patch END ---


# --- JELararagi shared single-slot status integration v3 ---
try:
    _JEL_STATUS_ORIGINAL_REGISTER_V3 = register
    _JEL_STATUS_ORIGINAL_UNREGISTER_V3 = unregister
except Exception:
    _JEL_STATUS_ORIGINAL_REGISTER_V3 = None
    _JEL_STATUS_ORIGINAL_UNREGISTER_V3 = None

_JEL_STATUS_HANDLER_OWNER_UUID_V3 = '2ab7662b-798a-4f67-a65d-f167a16bb5a8'
_JEL_STATUS_HANDLER_GENERATION_V3 = None
_JEL_STATUS_HANDLER_TRANSACTION_V3 = None


def _jel_status_instrument_class_v2(cls):
    try:
        from . import status_runtime as _jel_status_runtime_v3
        return _jel_status_runtime_v3.instrument_operator_class(
            cls, 'smart_modeling_suite', 'Smart Modeling Suite'
        )
    except Exception:
        return cls


def register():
    global _JEL_STATUS_HANDLER_GENERATION_V3, _JEL_STATUS_HANDLER_TRANSACTION_V3
    if not callable(_JEL_STATUS_ORIGINAL_REGISTER_V3):
        return None

    from . import status_runtime as _jel_status_runtime_v3
    # Recover only exact receipts from a prior failed/disabled generation.  The
    # legacy API restoration is limited to exact native/wrapper receipts written
    # by Smart Modeling <= 1.3.54; current generations never install wrappers.
    _jel_status_runtime_v3.restore_legacy_process_api_receipts()
    _jel_status_runtime_v3.restore_package_handlers('smart_modeling_suite')
    _jel_status_runtime_v3.release_handler_generations(
        'smart_modeling_suite', owner_uuid=_JEL_STATUS_HANDLER_OWNER_UUID_V3
    )
    transaction = _jel_status_runtime_v3.begin_handler_generation(
        'smart_modeling_suite', _JEL_STATUS_HANDLER_OWNER_UUID_V3
    )
    try:
        result = _JEL_STATUS_ORIGINAL_REGISTER_V3()
    except Exception:
        _jel_status_runtime_v3.rollback_handler_generation(transaction)
        raise

    _JEL_STATUS_HANDLER_GENERATION_V3 = _jel_status_runtime_v3.commit_handler_generation(transaction)
    _JEL_STATUS_HANDLER_TRANSACTION_V3 = transaction
    try:
        _jel_status_runtime_v3.instrument_loaded_package_operators(
            'smart_modeling_suite', 'smart_modeling_suite', 'Smart Modeling Suite'
        )
    except Exception:
        pass
    # Handler callbacks intentionally remain their native exact identities.
    # The generation receipt above is sufficient for rollback/disable cleanup.
    return result


def unregister():
    global _JEL_STATUS_HANDLER_GENERATION_V3, _JEL_STATUS_HANDLER_TRANSACTION_V3
    try:
        if callable(_JEL_STATUS_ORIGINAL_UNREGISTER_V3):
            return _JEL_STATUS_ORIGINAL_UNREGISTER_V3()
        return None
    finally:
        try:
            from . import status_runtime as _jel_status_runtime_v3
            # Remove any callback the integrated modules failed to release, using
            # only the exact list/callback identities captured after register().
            # The local transaction retains strong references even if Blender
            # recreates driver_namespace during a file load.
            if isinstance(_JEL_STATUS_HANDLER_TRANSACTION_V3, dict):
                _jel_status_runtime_v3.rollback_handler_generation(
                    _JEL_STATUS_HANDLER_TRANSACTION_V3
                )
            _jel_status_runtime_v3.release_handler_generations(
                'smart_modeling_suite',
                owner_uuid=_JEL_STATUS_HANDLER_OWNER_UUID_V3,
                generation=_JEL_STATUS_HANDLER_GENERATION_V3,
            )
            _jel_status_runtime_v3.restore_package_handlers('smart_modeling_suite')
            _jel_status_runtime_v3.restore_legacy_process_api_receipts()
            _jel_status_runtime_v3.clear_prefix('smart_modeling_suite')
        except Exception:
            pass
        _JEL_STATUS_HANDLER_GENERATION_V3 = None
        _JEL_STATUS_HANDLER_TRANSACTION_V3 = None
# --- JELararagi shared single-slot status integration v3 --- END

# SmartTools shared specification registration boundary.
from .smarttools_spec_guard import wrap as _smarttools_spec_wrap

register, unregister = _smarttools_spec_wrap(register, unregister)

# Finalize session-only lazy UI state after the outermost registration guard has
# finished materializing RNA defaults.  FloatVectorProperty defaults can invoke
# update callbacks during class registration; those callbacks are not user edits.
_SMS_SPEC_GUARDED_REGISTER = register
_SMS_SPEC_GUARDED_UNREGISTER = unregister

def _sms_release_owned_driver_namespace_v1391(before_unregister) -> int:
    """Restore/remove only values whose exact identity is owned by this Suite."""
    changed = 0
    try:
        namespace = _sms_driver_namespace_v1395()
        if namespace is None:
            return 0
        for key in _SMS_OWNED_DRIVER_NAMESPACE_KEYS_V1391:
            original = _SMS_DRIVER_NAMESPACE_SNAPSHOT_V1395.get(
                key, _SMS_DRIVER_NAMESPACE_MISSING_V1395
            )
            before = before_unregister.get(key, _SMS_DRIVER_NAMESPACE_MISSING_V1395)
            current = namespace.get(key, _SMS_DRIVER_NAMESPACE_MISSING_V1395)
            before_owned = _sms_is_owned_namespace_value_v1395(key, before)
            current_owned = _sms_is_owned_namespace_value_v1395(key, current)
            current_teardown_null = before_owned and current is None
            current_releasable = current_owned or current_teardown_null

            # A foreign value present immediately before unregister wins.  The
            # guarded teardown may still touch the key, so restore that exact
            # identity rather than the older pre-register snapshot.
            if before is not _SMS_DRIVER_NAMESPACE_MISSING_V1395 and not before_owned:
                if current is not before:
                    namespace[key] = before
                    changed += 1
                continue

            # Never remove or replace a value installed by another owner while
            # unregister was running.
            if current is not _SMS_DRIVER_NAMESPACE_MISSING_V1395 and not current_releasable:
                continue

            if original is _SMS_DRIVER_NAMESPACE_MISSING_V1395:
                if current_releasable and namespace.get(key, _SMS_DRIVER_NAMESPACE_MISSING_V1395) is current:
                    namespace.pop(key, None)
                    changed += 1
            elif current is not original:
                namespace[key] = original
                changed += 1
    except Exception:
        pass
    finally:
        _SMS_DRIVER_NAMESPACE_SNAPSHOT_V1395.clear()
        _SMS_DRIVER_NAMESPACE_OWNED_VALUES_V1395.clear()
        global _SMS_DRIVER_NAMESPACE_REGISTER_STARTED_V1395
        _SMS_DRIVER_NAMESPACE_REGISTER_STARTED_V1395 = False
    return changed


def register():
    global _SMS_DRIVER_NAMESPACE_REGISTER_STARTED_V1395
    _sms_snapshot_driver_namespace_v1395()
    _namespace, before_register = _sms_namespace_values_v1395()
    if not _SMS_DRIVER_NAMESPACE_REGISTER_STARTED_V1395:
        # Values changed since the import-entry snapshot were written by this
        # module's import-time bootstrap.  Capture them only on the first
        # register so a later foreign replacement is never adopted as owned.
        for _key, _value in before_register.items():
            _original = _SMS_DRIVER_NAMESPACE_SNAPSHOT_V1395.get(
                _key, _SMS_DRIVER_NAMESPACE_MISSING_V1395
            )
            if _value is not _original:
                _sms_remember_owned_namespace_value_v1395(_key, _value)
        _SMS_DRIVER_NAMESPACE_REGISTER_STARTED_V1395 = True
    try:
        result = _SMS_SPEC_GUARDED_REGISTER()
    finally:
        _after_namespace, after_register = _sms_namespace_values_v1395()
        for _key, _value in after_register.items():
            if _value is not before_register.get(_key, _SMS_DRIVER_NAMESPACE_MISSING_V1395):
                _sms_remember_owned_namespace_value_v1395(_key, _value)
    try:
        from . import core as _sms_core
        _sms_core._SMS_LAZY_UI_DIRTY_KEYS.clear()
        from . import common as _sms_common
        saved = getattr(_sms_common, '_LOADED_SETTINGS', None)
        if isinstance(saved, dict):
            _sms_core._sms_restore_saved_crease_lazy_ui(bpy.context, saved.get('window_manager'))
    except Exception:
        pass
    return result


def unregister():
    _namespace, before_unregister = _sms_namespace_values_v1395()
    try:
        return _SMS_SPEC_GUARDED_UNREGISTER()
    finally:
        _sms_release_owned_driver_namespace_v1391(before_unregister)


# Exact shared-status ownership boundary v1392.  A pre-existing mapping is
# never adopted.  A state created during this Suite's register may be released
# only after the guarded unregister made it exact-idle, and only while the
# driver-namespace value is still that same object.
_SMS_V1392_GUARDED_REGISTER = register
_SMS_V1392_GUARDED_UNREGISTER = unregister
_SMS_SHARED_STATUS_CREATED_STATE_V1392 = None


def register():
    global _SMS_SHARED_STATUS_CREATED_STATE_V1392
    from . import status_runtime as _sms_status_runtime_v1392
    snapshot = _sms_status_runtime_v1392.shared_state_identity_snapshot()
    try:
        return _SMS_V1392_GUARDED_REGISTER()
    finally:
        created = _sms_status_runtime_v1392.shared_state_created_since(snapshot)
        if created is None:
            created = _sms_status_runtime_v1392.shared_state_created_by_this_module()
        if created is not None:
            _SMS_SHARED_STATUS_CREATED_STATE_V1392 = created


def unregister():
    global _SMS_SHARED_STATUS_CREATED_STATE_V1392
    created = _SMS_SHARED_STATUS_CREATED_STATE_V1392
    try:
        return _SMS_V1392_GUARDED_UNREGISTER()
    finally:
        _SMS_SHARED_STATUS_CREATED_STATE_V1392 = None
        try:
            from . import status_runtime as _sms_status_runtime_v1392
            _sms_status_runtime_v1392.release_shared_state_if_exact_idle(created)
        except Exception:
            pass
