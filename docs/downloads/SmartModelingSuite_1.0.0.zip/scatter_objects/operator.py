# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

import bpy
import gpu
import blf
import math
import enum
import random

from itertools import islice
from mathutils.bvhtree import BVHTree
from mathutils import Vector, Matrix, Euler
from gpu_extras.batch import batch_for_shader

from bpy_extras.view3d_utils import (
    region_2d_to_vector_3d,
    region_2d_to_origin_3d,
)


_UNIFORM_COLOR_SHADER = None
_STROKE_POINT_EPSILON_SQ = 1.0e-12


class _ScatterDrawSnapshot:
    """Mutable operator-owned snapshot consumed by draw callbacks only.

    The snapshot contains GPU resources and plain immutable values.  It never
    contains Blender objects, BMesh/BVH builders, targets, or callbacks that can
    reach evaluated geometry from the draw thread.
    """

    __slots__ = (
        "shader",
        "stroke_batches",
        "matrix_batches",
        "instance_text",
        "font_size",
    )

    def __init__(self, shader=None, font_size=15):
        self.shader = shader
        self.stroke_batches = ()
        self.matrix_batches = ()
        self.instance_text = "Instances: 0"
        self.font_size = int(font_size)

    def clear(self):
        self.stroke_batches = ()
        self.matrix_batches = ()
        self.instance_text = "Instances: 0"


def _draw_scatter_view(snapshot):
    """Draw prebuilt stroke and instance batches; never rebuild geometry."""
    if snapshot is None:
        return
    shader = snapshot.shader
    if shader is None:
        return

    try:
        gpu.state.blend_set('ALPHA')
        gpu.state.depth_mask_set(False)

        stroke_batches = snapshot.stroke_batches
        if stroke_batches:
            gpu.state.line_width_set(5.0)
            shader.bind()
            shader.uniform_float("color", (1.0, 0.4, 0.1, 1.0))
            for batch in stroke_batches:
                if batch is not None:
                    batch.draw(shader)

        matrix_batches = snapshot.matrix_batches
        if matrix_batches:
            shader.bind()
            shader.uniform_float("color", (0.4, 0.4, 1.0, 0.3))
            for batch in matrix_batches:
                if batch is not None:
                    batch.draw(shader)
    except Exception:
        return
    finally:
        try:
            gpu.state.line_width_set(1.0)
        except Exception:
            pass
        try:
            gpu.state.blend_set('NONE')
        except Exception:
            pass
        try:
            gpu.state.depth_mask_set(True)
        except Exception:
            pass


def _draw_scatter_px(snapshot):
    """Draw cached text only; matrix generation is forbidden in this callback."""
    if snapshot is None:
        return
    try:
        font_id = 0
        blf.position(font_id, 20, 20, 0)
        blf.size(font_id, max(1, int(snapshot.font_size)))
        blf.draw(font_id, snapshot.instance_text)
    except Exception:
        return


# Modal Operator
################################################################

class ScatterObjects(bpy.types.Operator):
    bl_idname = "object.scatter"
    bl_label = "Object Scatter"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return (
            currently_in_3d_view(context)
            and context.active_object is not None
            and context.active_object.mode == 'OBJECT'
        )

    def invoke(self, context, event):
        self.target_object = context.active_object
        self.objects_to_scatter = get_selected_non_active_objects(context)

        if self.target_object is None or len(self.objects_to_scatter) == 0:
            self.report({'ERROR'}, "Select objects to scatter and a target object")
            return {'CANCELLED'}

        try:
            depsgraph = context.evaluated_depsgraph_get()
            target_bvh = bvhtree_from_object(self.target_object, depsgraph)
        except Exception:
            target_bvh = None
        if target_bvh is None:
            self.report({'ERROR'}, "Unable to build the target surface cache")
            return {'CANCELLED'}

        self.base_scale = get_max_object_side_length(self.objects_to_scatter)
        self.targets = []
        self.active_target = None
        self.target_cache = {}
        self._target_bvh = target_bvh
        self._region = getattr(context, 'region', None)
        self._region_3d = getattr(getattr(context, 'space_data', None), 'region_3d', None)
        try:
            ui_scale = float(context.preferences.system.ui_scale)
        except Exception:
            ui_scale = 1.0
        self._draw_snapshot = _ScatterDrawSnapshot(
            shader=get_uniform_color_shader(),
            font_size=round(15 * max(0.25, ui_scale)),
        )
        self._draw_callback_view = None
        self._draw_callback_px = None
        self._last_settings = None

        self.refresh_draw_cache(context, force=True)
        self.enable_draw_callback()
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if not event_is_in_region(event, self._region) and self.active_target is None:
            return {'PASS_THROUGH'}

        if event.type == 'ESC' and event.value == 'PRESS':
            return self.finish(context, 'CANCELLED')

        if event.type in {'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
            self.refresh_draw_cache(context, force=True)
            self.create_scatter_object(context)
            return self.finish(context, 'FINISHED')

        event_used, geometry_changed = self.handle_non_exit_event(context, event)
        settings_changed = self._settings_changed(context)
        if geometry_changed or settings_changed:
            self.refresh_draw_cache(context, force=True)
            tag_redraw(context)

        if event_used:
            return {'RUNNING_MODAL'}
        return {'PASS_THROUGH'}

    def handle_non_exit_event(self, context, event):
        if self.active_target is None:
            if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
                self.active_target = StrokeTarget()
                self.active_target.start_build(
                    self._target_bvh,
                    self._region,
                    self._region_3d,
                )
                return True, True
            return False, False

        build_state, changed = self.active_target.continue_build(event)
        if build_state == BuildState.FINISHED:
            self.targets.append(self.active_target)
            self.active_target = None
            return True, True
        return True, bool(changed)

    def enable_draw_callback(self):
        snapshot = self._draw_snapshot
        self._draw_callback_view = bpy.types.SpaceView3D.draw_handler_add(
            _draw_scatter_view,
            (snapshot,),
            'WINDOW',
            'POST_VIEW',
        )
        self._draw_callback_px = bpy.types.SpaceView3D.draw_handler_add(
            _draw_scatter_px,
            (snapshot,),
            'WINDOW',
            'POST_PIXEL',
        )

    def disable_draw_callback(self):
        if self._draw_callback_view is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(self._draw_callback_view, 'WINDOW')
            except Exception:
                pass
            self._draw_callback_view = None
        if self._draw_callback_px is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(self._draw_callback_px, 'WINDOW')
            except Exception:
                pass
            self._draw_callback_px = None

    def _settings_changed(self, context):
        try:
            settings = self.get_current_settings(context)
        except Exception:
            return False
        return settings != self._last_settings

    def refresh_draw_cache(self, context, force=False):
        """Update operation-local matrix and GPU snapshots from modal events."""
        try:
            settings = self.get_current_settings(context)
        except Exception:
            return False
        if not force and settings == self._last_settings:
            return False

        stroke_batches = []
        matrix_batches = []
        instance_count = 0
        live_targets = set()
        for target in self.iter_targets():
            live_targets.add(target)
            try:
                stroke_batches.extend(target.get_draw_batches())
            except Exception:
                pass
            try:
                self.ensure_target_is_in_cache(target)
                entry = self.target_cache[target]
                entry.sync(settings)
                matrix_batches.extend(entry.get_batches(settings))
                instance_count += entry.get_matrix_count(settings)
            except Exception:
                continue

        # Remove only entries no longer owned by this running operator.  The
        # cache is therefore bounded by the user's current stroke list.
        for target in tuple(self.target_cache):
            if target not in live_targets:
                self.target_cache.pop(target, None)

        snapshot = self._draw_snapshot
        snapshot.stroke_batches = tuple(batch for batch in stroke_batches if batch is not None)
        snapshot.matrix_batches = tuple(batch for batch in matrix_batches if batch is not None)
        snapshot.instance_text = "Instances: " + str(instance_count)
        self._last_settings = settings
        return True

    def finish(self, context, return_value):
        self.disable_draw_callback()
        snapshot = getattr(self, '_draw_snapshot', None)
        if snapshot is not None:
            snapshot.clear()
        self.target_cache = {}
        self.targets = []
        self.active_target = None
        self._target_bvh = None
        tag_redraw(context)
        return {return_value}

    def cancel(self, context):
        self.finish(context, 'CANCELLED')

    def create_scatter_object(self, context):
        matrix_chunks = make_random_chunks(
            self.get_all_matrices(context),
            len(self.objects_to_scatter),
        )

        collection = bpy.data.collections.new("Scatter")
        context.collection.children.link(collection)

        for obj, matrices in zip(self.objects_to_scatter, matrix_chunks):
            make_duplicator(collection, obj, matrices)

    def get_all_matrices(self, context):
        settings = self.get_current_settings(context)
        matrices = []
        for target in self.iter_targets():
            self.ensure_target_is_in_cache(target)
            matrices.extend(self.target_cache[target].get_matrices(settings))
        return matrices

    def iter_targets(self):
        yield from self.targets
        if self.active_target is not None:
            yield self.active_target

    def ensure_target_is_in_cache(self, target):
        if target not in self.target_cache:
            self.target_cache[target] = TargetCacheEntry(target, self.base_scale)

    def get_current_settings(self, context):
        return context.scene.scatter_properties.to_settings()


class TargetCacheEntry:
    """Incremental, operation-bounded scatter cache for one stroke."""

    def __init__(self, target, base_scale):
        self.target = target
        self.base_scale = base_scale
        self.last_used_settings = None
        self.segment_matrices = []
        self.segment_batches = []
        self._flat_matrices = ()
        self._flat_dirty = False
        self._synced_segment_count = 0

    def _reset(self):
        self.segment_matrices = []
        self.segment_batches = []
        self._flat_matrices = ()
        self._flat_dirty = False
        self._synced_segment_count = 0

    def _handle_new_settings(self, settings):
        if settings != self.last_used_settings:
            self._reset()
            self.last_used_settings = settings

    def sync(self, settings):
        self._handle_new_settings(settings)
        segment_count = self.target.segment_count()
        if segment_count < self._synced_segment_count:
            self._reset()
            self.last_used_settings = settings

        for segment_index in range(self._synced_segment_count, segment_count):
            matrices = tuple(self.target.get_segment_matrices(segment_index, settings))
            self.segment_matrices.append(matrices)
            self.segment_batches.append(
                create_batch_for_matrices(matrices, self.base_scale) if matrices else None
            )
            self._flat_dirty = True
        self._synced_segment_count = segment_count

    def get_matrices(self, settings):
        self.sync(settings)
        if self._flat_dirty:
            self._flat_matrices = tuple(
                matrix
                for segment in self.segment_matrices
                for matrix in segment
            )
            self._flat_dirty = False
        return self._flat_matrices

    def get_matrix_count(self, settings):
        self.sync(settings)
        return sum(len(segment) for segment in self.segment_matrices)

    def get_batches(self, settings):
        self.sync(settings)
        return tuple(batch for batch in self.segment_batches if batch is not None)

    # Compatibility with the previous internal interface.
    def prepare_batch(self, settings):
        batches = self.get_batches(settings)
        return batches[0] if len(batches) == 1 else None

    def get_batch(self, settings):
        return self.prepare_batch(settings)


# Duplicator Creation
######################################################

def make_duplicator(target_collection, source_object, matrices):
    triangle_scale = 0.1

    duplicator = triangle_object_from_matrices(source_object.name + " Duplicator", matrices, triangle_scale)
    duplicator.instance_type = 'FACES'
    duplicator.use_instance_faces_scale = True
    duplicator.show_instancer_for_viewport = True
    duplicator.show_instancer_for_render = False
    duplicator.instance_faces_scale = 1 / triangle_scale

    copy_obj = source_object.copy()
    copy_obj.name = source_object.name + " - copy"
    copy_obj.location = (0, 0, 0)
    copy_obj.parent = duplicator

    target_collection.objects.link(duplicator)
    target_collection.objects.link(copy_obj)


def triangle_object_from_matrices(name, matrices, triangle_scale):
    mesh = triangle_mesh_from_matrices(name, matrices, triangle_scale)
    return bpy.data.objects.new(name, mesh)


def triangle_mesh_from_matrices(name, matrices, triangle_scale):
    mesh = bpy.data.meshes.new(name)
    vertices, polygons = mesh_data_from_matrices(matrices, triangle_scale)
    mesh.from_pydata(vertices, [], polygons)
    mesh.update()
    mesh.validate()
    return mesh


unit_triangle_vertices = (
    Vector((-3**-0.25, -3**-0.75, 0)),
    Vector((3**-0.25, -3**-0.75, 0)),
    Vector((0, 2/3**0.75, 0)),
)


def mesh_data_from_matrices(matrices, triangle_scale):
    vertices = []
    polygons = []
    triangle_vertices = [triangle_scale * v for v in unit_triangle_vertices]

    for i, matrix in enumerate(matrices):
        vertices.extend((matrix @ v for v in triangle_vertices))
        polygons.append((i * 3 + 0, i * 3 + 1, i * 3 + 2))

    return vertices, polygons


# Target Provider
#################################################

class BuildState(enum.Enum):
    FINISHED = enum.auto()
    ONGOING = enum.auto()


class TargetProvider:
    def start_build(self, target_bvh, region, region_3d):
        del target_bvh, region, region_3d

    def continue_build(self, event):
        del event
        return BuildState.FINISHED, False

    def segment_count(self):
        return 0

    def get_segment_matrices(self, segment_index, scatter_settings):
        del segment_index, scatter_settings
        return ()

    def get_draw_batches(self):
        return ()


class StrokeTarget(TargetProvider):
    def start_build(self, target_bvh, region, region_3d):
        self.points = []
        self.bvhtree = target_bvh
        self.region = region
        self.region_3d = region_3d
        self._line_batches = []

    def continue_build(self, event):
        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            return BuildState.FINISHED, False
        if event.type != 'MOUSEMOVE':
            return BuildState.ONGOING, False

        mouse_pos = (event.mouse_region_x, event.mouse_region_y)
        location, *_ = shoot_region_2d_ray(
            self.bvhtree,
            mouse_pos,
            self.region,
            self.region_3d,
        )
        if location is None:
            return BuildState.ONGOING, False
        location = location.copy()
        if self.points and (location - self.points[-1]).length_squared <= _STROKE_POINT_EPSILON_SQ:
            return BuildState.ONGOING, False
        if self.points:
            self._line_batches.append(create_line_segment_batch(self.points[-1], location))
        self.points.append(location)
        return BuildState.ONGOING, True

    def segment_count(self):
        return max(0, len(self.points) - 1)

    def get_segment_matrices(self, segment_index, scatter_settings):
        if segment_index < 0 or segment_index >= self.segment_count():
            return ()
        return scatter_around_segment(
            self.points[segment_index],
            self.points[segment_index + 1],
            segment_index,
            self.bvhtree,
            scatter_settings,
        )

    def get_draw_batches(self):
        return tuple(batch for batch in self._line_batches if batch is not None)

    def get_matrices(self, scatter_settings):
        matrices = []
        for segment_index in range(self.segment_count()):
            matrices.extend(self.get_segment_matrices(segment_index, scatter_settings))
        return matrices


def scatter_around_segment(start, end, segment_index, bvhtree, settings):
    scattered_matrices = []
    for point, local_seed in iter_points_on_segment_with_seed(
        start,
        end,
        segment_index,
        settings.density,
        settings.seed,
    ):
        matrix = scatter_from_source_point(bvhtree, point, local_seed, settings)
        if matrix is not None:
            scattered_matrices.append(matrix)
    return scattered_matrices


def scatter_around_stroke(stroke_points, bvhtree, settings):
    scattered_matrices = []
    for i, (start, end) in enumerate(iter_pairwise(stroke_points)):
        scattered_matrices.extend(scatter_around_segment(start, end, i, bvhtree, settings))
    return scattered_matrices


def iter_points_on_segment_with_seed(start, end, segment_index, density, seed):
    segment_seed = sub_seed(seed, segment_index)
    segment_vector = end - start
    segment_length = segment_vector.length
    amount = round_random(segment_length * density, segment_seed)

    for j in range(amount):
        t = random_uniform(sub_seed(segment_seed, j, 0))
        origin = start + t * segment_vector
        yield origin, sub_seed(segment_seed, j, 1)


def iter_points_on_stroke_with_seed(stroke_points, density, seed):
    for i, (start, end) in enumerate(iter_pairwise(stroke_points)):
        yield from iter_points_on_segment_with_seed(start, end, i, density, seed)


def scatter_from_source_point(bvhtree, point, seed, settings):
    radius = random_uniform(sub_seed(seed, 0)) * settings.radius
    offset = random_vector(sub_seed(seed, 2)) * radius
    location, normal, *_ = bvhtree.find_nearest(point + offset)
    if location is None or normal is None:
        return None
    normal.normalize()

    up_direction = normal if settings.use_normal_rotation else Vector((0, 0, 1))

    min_scale = settings.scale * (1 - settings.random_scale)
    max_scale = settings.scale
    scale = random_uniform(sub_seed(seed, 1), min_scale, max_scale)

    location += normal * settings.normal_offset * scale

    z_rotation = Euler((0, 0, random_uniform(sub_seed(seed, 3), 0, 2 * math.pi))).to_matrix()
    up_rotation = up_direction.to_track_quat('Z', 'X').to_matrix()
    local_rotation = random_euler(sub_seed(seed, 3), settings.rotation).to_matrix()
    rotation = local_rotation @ up_rotation @ z_rotation

    return Matrix.Translation(location) @ rotation.to_4x4() @ scale_matrix(scale)


# Drawing
#################################################

box_vertices = (
    (-1, -1, 1), (1, -1, 1), (1, 1, 1), (-1, 1, 1),
    (-1, -1, -1), (1, -1, -1), (1, 1, -1), (-1, 1, -1),
)

box_indices = (
    (0, 1, 2), (2, 3, 0), (1, 5, 6), (6, 2, 1),
    (7, 6, 5), (5, 4, 7), (4, 0, 3), (3, 7, 4),
    (4, 5, 1), (1, 0, 4), (3, 2, 6), (6, 7, 3),
)

box_vertices = tuple(Vector(vertex) * 0.5 for vertex in box_vertices)


def create_batch_for_matrices(matrices, base_scale):
    shader = get_uniform_color_shader()
    if shader is None or not matrices:
        return None
    coords = []
    indices = []

    scaled_box_vertices = [base_scale * vertex for vertex in box_vertices]

    for matrix in matrices:
        offset = len(coords)
        coords.extend((matrix @ vertex for vertex in scaled_box_vertices))
        indices.extend(tuple(index + offset for index in element) for element in box_indices)

    return batch_for_shader(shader, 'TRIS', {"pos": coords}, indices=indices)


def create_line_segment_batch(start, end):
    shader = get_uniform_color_shader()
    if shader is None:
        return None
    return batch_for_shader(shader, 'LINES', {"pos": (start, end)})


def create_line_strip_batch(coords):
    shader = get_uniform_color_shader()
    if shader is None or not coords:
        return None
    return batch_for_shader(shader, 'LINE_STRIP', {"pos": coords})


# Utilities
########################################################

'''
Pythons random functions are designed to be used in cases
when a seed is set once and then many random numbers are
generated. To improve the user experience I want to have
full control over how random seeds propagate through the
functions. This is why I use custom random functions.

One benefit is that changing the object density does not
generate new random positions for all objects.
'''


def round_random(value, seed):
    probability = value % 1
    if probability < random_uniform(seed):
        return math.floor(value)
    return math.ceil(value)


def random_vector(x, min=-1, max=1):
    return Vector((
        random_uniform(sub_seed(x, 0), min, max),
        random_uniform(sub_seed(x, 1), min, max),
        random_uniform(sub_seed(x, 2), min, max),
    ))


def random_euler(x, factor):
    return Euler(tuple(random_vector(x) * factor))


def random_uniform(x, min=0, max=1):
    return random_int(x) / 2147483648 * (max - min) + min


def random_int(x):
    x = (x << 13) ^ x
    return (x * (x * x * 15731 + 789221) + 1376312589) & 0x7fffffff


def sub_seed(seed, index, index2=0):
    return random_int(seed * 3243 + index * 5643 + index2 * 54243)


def currently_in_3d_view(context):
    space = getattr(context, 'space_data', None)
    return getattr(space, 'type', None) == 'VIEW_3D'


def get_selected_non_active_objects(context):
    return set(context.selected_objects) - {context.active_object}


def make_random_chunks(sequence, chunk_amount):
    sequence = list(sequence)
    random.shuffle(sequence)
    return make_chunks(sequence, chunk_amount)


def make_chunks(sequence, chunk_amount):
    sequence = list(sequence)
    chunk_amount = max(0, int(chunk_amount))
    if chunk_amount == 0:
        return []
    if not sequence:
        return [[] for _ in range(chunk_amount)]
    length = max(1, math.ceil(len(sequence) / chunk_amount))
    chunks = [sequence[i:i + length] for i in range(0, len(sequence), length)]
    if len(chunks) < chunk_amount:
        chunks.extend([] for _ in range(chunk_amount - len(chunks)))
    return chunks[:chunk_amount]


def iter_pairwise(sequence):
    return zip(sequence, islice(sequence, 1, None))


def bvhtree_from_object(obj, depsgraph):
    import bmesh

    bm = bmesh.new()
    obj_eval = None
    mesh = None
    try:
        obj_eval = obj.evaluated_get(depsgraph)
        mesh = obj_eval.to_mesh()
        if mesh is None:
            return None
        bm.from_mesh(mesh)
        bm.transform(obj.matrix_world)
        return BVHTree.FromBMesh(bm)
    finally:
        if obj_eval is not None and mesh is not None:
            try:
                obj_eval.to_mesh_clear()
            except Exception:
                pass
        try:
            bm.free()
        except Exception:
            pass


def shoot_region_2d_ray(bvhtree, position_2d, region, region_3d):
    if bvhtree is None or region is None or region_3d is None:
        return None, None, None, None
    origin = region_2d_to_origin_3d(region, region_3d, position_2d)
    direction = region_2d_to_vector_3d(region, region_3d, position_2d)
    return bvhtree.ray_cast(origin, direction)


def scale_matrix(factor):
    matrix = Matrix.Identity(4)
    matrix[0][0] = factor
    matrix[1][1] = factor
    matrix[2][2] = factor
    return matrix


def event_is_in_region(event, region):
    if region is None:
        return False
    return (
        region.x <= event.mouse_x <= region.x + region.width
        and region.y <= event.mouse_y <= region.y + region.height
    )


def get_max_object_side_length(objects):
    return max(
        max(obj.dimensions[0] for obj in objects),
        max(obj.dimensions[1] for obj in objects),
        max(obj.dimensions[2] for obj in objects),
    )


def get_uniform_color_shader():
    return _UNIFORM_COLOR_SHADER


def tag_redraw(context):
    area = getattr(context, 'area', None)
    if area is not None:
        try:
            area.tag_redraw()
        except Exception:
            pass


# Registration
###############################################

def register():
    global _UNIFORM_COLOR_SHADER
    if _UNIFORM_COLOR_SHADER is None and not bpy.app.background:
        try:
            _UNIFORM_COLOR_SHADER = gpu.shader.from_builtin('UNIFORM_COLOR')
        except Exception:
            _UNIFORM_COLOR_SHADER = None
    bpy.utils.register_class(ScatterObjects)


def unregister():
    global _UNIFORM_COLOR_SHADER
    bpy.utils.unregister_class(ScatterObjects)
    _UNIFORM_COLOR_SHADER = None
