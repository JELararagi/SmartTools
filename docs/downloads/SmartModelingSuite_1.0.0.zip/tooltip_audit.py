# ============================================================================
# Tooltip audit runtime helper
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package
# ============================================================================

from __future__ import annotations

import inspect
import re
import sys
from typing import Any

import bpy

_PROP_FACTORY_NAMES = (
    "BoolProperty",
    "BoolVectorProperty",
    "CollectionProperty",
    "EnumProperty",
    "FloatProperty",
    "FloatVectorProperty",
    "IntProperty",
    "IntVectorProperty",
    "PointerProperty",
    "StringProperty",
)

_TRANSLATION_CONTEXTS = ("*", "Operator", "Property", "Tooltip", "UI", "Panel", "Menu", "Addon")

_JA_RE = re.compile(r"[ぁ-んァ-ヶ一-龯]")
_ASCII_RE = re.compile(r"[A-Za-z]")
_SPACE_RE = re.compile(r"\s+")
_CAMEL_RE = re.compile(r"([a-z0-9])([A-Z])")
_TOKEN_RE = re.compile(r"[A-Za-z0-9]+")

_EXCLUDED_MODULE_SUFFIXES = (
    ".navigation_properties",
    ".tooltip_audit",
)

_EXCLUDED_OPERATOR_IDS = {
    "wm.smart_modeling_suite_switch_tab_v250",
    "wm.smart_modeling_suite_open_window_v250",
    "wm.smart_modeling_suite_pick_scene_v270",
    "wm.smart_modeling_suite_block_context_header_clicks_v310",
}

_ACTIVE = False
_FINISHED = False
_OWNER = (__package__ or "addon") + ".tooltip_audit"
_PENDING_TRANSLATIONS: dict[str, dict[tuple[str, str], str]] = {"ja_JP": {}}
_ORIGINAL_CLASS_DESCRIPTIONS: dict[tuple[str, str], Any] = {}
_ORIGINAL_PROPERTY_DATA: dict[tuple[str, str, str], dict[str, Any]] = {}
_ORIGINAL_BPY_FACTORIES: dict[str, Any] = {}
_WRAPPED_FACTORIES: dict[str, Any] = {}
_WRAPPED_FACTORY_OBJECTS: set[Any] = set()
_WRAPPED_MODULE_ALIASES: dict[tuple[str, str], Any] = {}


def _contains_japanese(text: object) -> bool:
    return isinstance(text, str) and bool(_JA_RE.search(text))


def _contains_ascii(text: object) -> bool:
    return isinstance(text, str) and bool(_ASCII_RE.search(text))


def _clean_text(text: object) -> str:
    if text is None:
        return ""
    return _SPACE_RE.sub(" ", str(text).strip())


def _humanize_identifier(text: object) -> str:
    value = _clean_text(text)
    if not value:
        return "this item"
    if "." in value:
        value = value.split(".")[-1]
    value = value.replace("__", "_")
    value = _CAMEL_RE.sub(r"\1 \2", value)
    value = value.replace("_", " ").replace("-", " ")
    value = _SPACE_RE.sub(" ", value).strip()
    if not value:
        return "this item"
    pieces = []
    preserve = {"UV", "NLA", "IK", "FK", "UDIM", "PBR", "JSON", "RGB", "RGBA", "CPU", "GPU", "FBX"}
    for part in value.split(" "):
        up = part.upper()
        if up in preserve:
            pieces.append(up)
        elif len(part) <= 3 and part.isupper():
            pieces.append(part)
        else:
            pieces.append(part[:1].upper() + part[1:])
    return " ".join(pieces)


def _label_text(label: object, fallback: object = "this item") -> str:
    cleaned = _clean_text(label)
    if cleaned:
        return cleaned
    return _humanize_identifier(fallback)


def _tokenize(*parts: object) -> set[str]:
    tokens: set[str] = set()
    for part in parts:
        value = _clean_text(part)
        if not value:
            continue
        value = _CAMEL_RE.sub(r"\1 \2", value)
        value = value.replace(".", " ").replace("_", " ").replace("-", " ")
        for token in _TOKEN_RE.findall(value.lower()):
            tokens.add(token)
    return tokens


def _is_short_description(text: object) -> bool:
    cleaned = _clean_text(text)
    if not cleaned:
        return True
    if len(cleaned) < 28:
        return True
    return False


def _needs_description_patch(text: object) -> bool:
    cleaned = _clean_text(text)
    if not cleaned:
        return True
    if len(cleaned) < 28:
        return True
    # Placeholder-style descriptions are not helpful enough for beginners.
    lowered = cleaned.lower()
    if lowered in {"toggle", "option", "setting", "property", "operator"}:
        return True
    return False


def _package_name() -> str:
    return __package__ or "addon"


def _iter_package_modules():
    package = _package_name()
    prefix = package + "."
    for module_name, module in list(sys.modules.items()):
        if module is None:
            continue
        if module_name != package and not module_name.startswith(prefix):
            continue
        if any(module_name.endswith(suffix) for suffix in _EXCLUDED_MODULE_SUFFIXES):
            continue
        yield module_name, module


def _iter_package_classes():
    seen: set[tuple[str, str]] = set()
    package = _package_name()
    for module_name, module in _iter_package_modules():
        for class_name, cls in inspect.getmembers(module, inspect.isclass):
            owner = str(getattr(cls, "__module__", "") or "")
            if not owner.startswith(package):
                continue
            key = (module_name, class_name)
            if key in seen:
                continue
            seen.add(key)
            yield module_name, class_name, cls


def _property_keywords(prop_def):
    keywords = getattr(prop_def, "keywords", None)
    if isinstance(keywords, dict):
        fn = getattr(getattr(prop_def, "function", None), "__name__", "")
        return keywords, str(fn or "")
    if isinstance(prop_def, tuple) and len(prop_def) == 2 and isinstance(prop_def[1], dict):
        return prop_def[1], str(prop_def[0] or "")
    return None, ""


def _register_translation(msgid: object, ja_text: object) -> None:
    msgid = _clean_text(msgid)
    ja_text = _clean_text(ja_text)
    if not msgid or not ja_text:
        return
    if _contains_japanese(msgid) and not _contains_ascii(msgid):
        return
    table = _PENDING_TRANSLATIONS.setdefault("ja_JP", {})
    for ctx in _TRANSLATION_CONTEXTS:
        table.setdefault((ctx, msgid), ja_text)


def _operator_category(tokens: set[str]) -> str:
    if tokens & {"preview", "report", "audit", "inspect", "scan", "analyze", "analyse", "diagnostic", "validate", "log", "health", "debug"}:
        return "inspect"
    if tokens & {"save", "export", "write", "store", "backup", "snapshot", "record"}:
        return "save"
    if tokens & {"load", "import", "apply", "restore", "use", "assign"}:
        return "apply"
    if tokens & {"delete", "remove", "clear", "cleanup", "reset", "purge"}:
        return "remove"
    if tokens & {"toggle", "switch", "select", "focus", "show", "hide", "open", "close", "activate"}:
        return "switch"
    if tokens & {"add", "create", "generate", "build", "insert", "setup", "prepare", "make", "init"}:
        return "create"
    if tokens & {"bake"}:
        return "bake"
    if tokens & {"pack", "unwrap", "align", "project", "transfer", "retarget", "mirror", "symmetrize", "normalize", "repair", "fix", "bind", "convert", "process", "update", "refresh"}:
        return "process"
    return "run"


def _operator_en(label: str, category: str) -> str:
    subject = _label_text(label, "this tool")
    if category == "inspect":
        return f"Run {subject} to inspect the current setup and show a readable result before you make larger changes. Review the output in the panel, popup, or generated report."
    if category == "save":
        return f"Run {subject} to save or export the current data using the chosen destination settings. Check the file path, preset, or entry name before running the tool."
    if category == "apply":
        return f"Run {subject} to apply the chosen source, preset, or settings to the current target. Confirm that the correct objects, files, or entries are selected first."
    if category == "remove":
        return f"Run {subject} to remove, clear, or reset related data on the current target. Use it carefully because it changes or discards existing data."
    if category == "switch":
        return f"Run {subject} to change the current mode, active target, or visible working state. This is mainly for switching context rather than creating new data."
    if category == "create":
        return f"Run {subject} to create or prepare related data using the current settings and the current selection. Check the generated result before moving on."
    if category == "bake":
        return f"Run {subject} to bake the current result into editable scene data using the active settings. Check the target, frame range, and overwrite behavior before running the tool."
    if category == "process":
        return f"Run {subject} to process the current target using the active settings. Review the result and adjust the options if you need a different outcome."
    return f"Run {subject} with the current settings and the current selection. Review the result after the tool finishes."


def _operator_ja(category: str) -> str:
    if category == "inspect":
        return "現在の状態や設定内容を確認し、結果をパネル、ポップアップ、またはレポートで見やすく表示するためのツールです。大きな変更の前に使う確認用の操作です。"
    if category == "save":
        return "現在のデータを保存または書き出すための操作です。実行前に保存先、プリセット、名前などを確認してください。"
    if category == "apply":
        return "選択したソース、プリセット、または設定を現在の対象へ適用する操作です。実行前に正しい対象やモードを確認してください。"
    if category == "remove":
        return "現在の対象にある関連データを削除、初期化、または整理する操作です。既存データを変更するため、実行前に対象を確認してください。"
    if category == "switch":
        return "現在の作業モード、アクティブ対象、表示状態などを切り替えるための操作です。新規データ作成よりも作業状態の変更に向いています。"
    if category == "create":
        return "現在の設定と選択対象を使って、必要なデータや補助要素を作成または準備する操作です。実行後は生成結果を確認してください。"
    if category == "bake":
        return "現在の結果を編集可能なシーンデータとして焼き付ける操作です。実行前に対象、フレーム範囲、上書き条件を確認してください。"
    if category == "process":
        return "現在の対象を、今の設定で処理・変換・調整する操作です。結果が想定と違う場合は、オプションを見直して再実行してください。"
    return "現在の設定と選択対象を使ってこのツールを実行します。結果を確認しながら次の工程へ進んでください。"


def _property_category(prop_name: object, prop_type: str, label: object) -> str:
    tokens = _tokenize(prop_name, label)
    if prop_type in {"PointerProperty"}:
        return "pointer"
    if prop_type in {"CollectionProperty"}:
        return "collection"
    if prop_type in {"FloatVectorProperty", "IntVectorProperty", "BoolVectorProperty"}:
        if tokens & {"color", "colour", "base", "tint", "highlight"}:
            return "color"
        return "vector"
    if prop_type == "EnumProperty":
        return "enum"
    if prop_type == "BoolProperty":
        return "bool"
    if tokens & {"path", "file", "folder", "directory", "json", "text", "note", "message", "filter", "search", "query", "name"}:
        return "text"
    if tokens & {"start", "end", "frame", "range", "step", "gap", "offset", "index"}:
        return "range"
    if tokens & {"threshold", "factor", "strength", "amount", "influence", "weight", "scale", "size", "padding", "radius", "angle", "density", "width", "height", "resolution", "distance"}:
        return "amount"
    return "value"


def _property_en(prop_name: object, prop_type: str, label: object) -> str:
    label_text = _label_text(label, prop_name).lower()
    category = _property_category(prop_name, prop_type, label)
    if category == "bool":
        return f"Enable this option when the related tool should use {label_text} as part of its process. Turn it off when you want to skip this extra step."
    if category == "enum":
        return f"Choose which {label_text} option the related tool uses. Change this before running the matching button in the same panel."
    if category == "pointer":
        return f"Choose the data-block or object used as the {label_text} for the related tool. Select the correct target before running the matching button."
    if category == "collection":
        return "Stores the runtime list used by the related tool. This is usually managed by the add-on rather than edited manually."
    if category == "color":
        return f"Set the {label_text} color used by the related tool. Review the result in the viewport or material after you change it."
    if category == "vector":
        return f"Adjust the {label_text} values used by the related tool. Review the result after you run the matching button."
    if category == "text":
        return f"Enter or review the {label_text} used by the related tool. Check the text carefully before running the matching button."
    if category == "range":
        return f"Set the {label_text} value used by the related tool. Review the range or index before running the matching button."
    if category == "amount":
        return f"Adjust the {label_text} value used by the related tool. Small changes can noticeably affect the final result."
    return f"Adjust the {label_text} setting used by the related tool before running the matching button."


def _property_ja(prop_name: object, prop_type: str, label: object) -> str:
    category = _property_category(prop_name, prop_type, label)
    if category == "bool":
        return "この項目を ON にすると、関連ツールがこの追加処理や条件を使います。不要な場合は OFF にしてください。"
    if category == "enum":
        return "関連ツールで使う方式やモードをここで選びます。同じパネルの実行ボタンを押す前に確認してください。"
    if category == "pointer":
        return "関連ツールが参照する対象データやオブジェクトをここで選びます。実行前に正しい対象か確認してください。"
    if category == "collection":
        return "関連ツールが内部で使う一覧データです。通常はアドオン側で管理されるため、手動編集は補助的な用途です。"
    if category == "color":
        return "関連ツールで使う色をここで調整します。変更後はビューポートや結果表示を確認してください。"
    if category == "vector":
        return "関連ツールで使う複数値をここで調整します。変更後は結果を確認してください。"
    if category == "text":
        return "関連ツールで使う文字列、名前、検索語、またはパスをここで指定します。実行前に入力内容を確認してください。"
    if category == "range":
        return "関連ツールで使う範囲、開始値、終了値、または番号をここで調整します。実行前に確認してください。"
    if category == "amount":
        return "関連ツールで使う数値をここで調整します。値の変化で結果が大きく変わる場合があります。"
    return "関連ツールで使う設定項目です。同じパネルの実行ボタンを押す前に調整してください。"


def _enum_item_en(prop_name: object, prop_label: object, item_identifier: object, item_label: object) -> str:
    item_name = _label_text(item_label, item_identifier)
    prop_text = _label_text(prop_label, prop_name).lower()
    return f"Choose {item_name} as the {prop_text} option for the related tool."


def _enum_item_ja(prop_name: object, prop_label: object, item_identifier: object, item_label: object) -> str:
    return "この項目を選ぶと、関連ツールでこのオプションを使います。目的に合うものを選んでください。"


def _patch_static_enum_items(prop_name: object, prop_label: object, keywords: dict) -> bool:
    items = keywords.get("items")
    if not isinstance(items, (list, tuple)):
        return False
    changed = False
    new_items = []
    for item in items:
        if item is None or not isinstance(item, (list, tuple)):
            new_items.append(item)
            continue
        if len(item) < 2:
            new_items.append(item)
            continue
        item_identifier = item[0]
        item_label = item[1]
        item_desc = item[2] if len(item) >= 3 else ""
        if _needs_description_patch(item_desc):
            en_desc = _enum_item_en(prop_name, prop_label, item_identifier, item_label)
            ja_desc = _enum_item_ja(prop_name, prop_label, item_identifier, item_label)
            rebuilt = list(item)
            if len(rebuilt) >= 3:
                rebuilt[2] = en_desc
            else:
                rebuilt.append(en_desc)
            item = tuple(rebuilt)
            changed = True
            _register_translation(en_desc, ja_desc)
        else:
            desc_text = _clean_text(item_desc)
            if desc_text and _contains_ascii(desc_text) and not _contains_japanese(desc_text):
                _register_translation(desc_text, _enum_item_ja(prop_name, prop_label, item_identifier, item_label))
        new_items.append(item)
    if changed:
        keywords["items"] = tuple(new_items) if isinstance(items, tuple) else list(new_items)
    return changed


def _patch_annotation_properties() -> None:
    for module_name, class_name, cls in _iter_package_classes():
        annotations = getattr(cls, "__annotations__", {}) or {}
        for prop_name, prop_def in annotations.items():
            keywords, prop_type = _property_keywords(prop_def)
            prop_type = str(prop_type or "").split(".")[-1]
            if not isinstance(keywords, dict) or prop_type not in _PROP_FACTORY_NAMES:
                continue
            key = (module_name, class_name, str(prop_name))
            if key not in _ORIGINAL_PROPERTY_DATA:
                _ORIGINAL_PROPERTY_DATA[key] = {
                    "description_present": "description" in keywords,
                    "description": keywords.get("description"),
                    "items_present": "items" in keywords,
                    "items": keywords.get("items"),
                }
            label = keywords.get("name") or _humanize_identifier(prop_name)
            desc = keywords.get("description")
            if _needs_description_patch(desc):
                keywords["description"] = _property_en(prop_name, prop_type, label)
            final_desc = _clean_text(keywords.get("description"))
            if final_desc and _contains_ascii(final_desc) and not _contains_japanese(final_desc):
                _register_translation(final_desc, _property_ja(prop_name, prop_type, label))
            try:
                _patch_static_enum_items(prop_name, label, keywords)
            except Exception:
                pass


def _patch_operator_descriptions() -> None:
    for module_name, class_name, cls in _iter_package_classes():
        try:
            is_operator = issubclass(cls, bpy.types.Operator)
        except Exception:
            is_operator = False
        if not is_operator:
            continue
        bl_idname = _clean_text(getattr(cls, "bl_idname", ""))
        if not bl_idname or bl_idname in _EXCLUDED_OPERATOR_IDS or bl_idname.startswith("wm.smart_modeling_suite_"):
            continue
        existing = getattr(cls, "bl_description", "")
        label = getattr(cls, "bl_label", "") or class_name
        category = _operator_category(_tokenize(bl_idname, class_name, label))
        if (module_name, class_name) not in _ORIGINAL_CLASS_DESCRIPTIONS:
            _ORIGINAL_CLASS_DESCRIPTIONS[(module_name, class_name)] = existing
        if _needs_description_patch(existing):
            try:
                setattr(cls, "bl_description", _operator_en(label, category))
            except Exception:
                pass
        final_desc = _clean_text(getattr(cls, "bl_description", ""))
        if final_desc and _contains_ascii(final_desc) and not _contains_japanese(final_desc):
            _register_translation(final_desc, _operator_ja(category))


def _make_factory_wrapper(factory_name: str, original):
    def _wrapper(*args, **kwargs):
        label = kwargs.get("name") or factory_name.replace("Property", "")
        desc = kwargs.get("description")
        if _needs_description_patch(desc):
            kwargs["description"] = _property_en(factory_name, factory_name, label)
        final_desc = _clean_text(kwargs.get("description"))
        if final_desc and _contains_ascii(final_desc) and not _contains_japanese(final_desc):
            _register_translation(final_desc, _property_ja(factory_name, factory_name, label))
        if factory_name == "EnumProperty":
            try:
                _patch_static_enum_items(factory_name, label, kwargs)
            except Exception:
                pass
        return original(*args, **kwargs)

    _wrapper.__name__ = getattr(original, "__name__", factory_name)
    _wrapper.__qualname__ = getattr(original, "__qualname__", factory_name)
    return _wrapper


def _install_property_factory_wrappers() -> None:
    if _ORIGINAL_BPY_FACTORIES:
        return
    for factory_name in _PROP_FACTORY_NAMES:
        original = getattr(bpy.props, factory_name, None)
        if not callable(original):
            continue
        _ORIGINAL_BPY_FACTORIES[factory_name] = original
        wrapper = _make_factory_wrapper(factory_name, original)
        _WRAPPED_FACTORIES[factory_name] = wrapper
        _WRAPPED_FACTORY_OBJECTS.add(wrapper)
        try:
            setattr(bpy.props, factory_name, wrapper)
        except Exception:
            pass
    for module_name, module in _iter_package_modules():
        for factory_name, wrapper in _WRAPPED_FACTORIES.items():
            if not hasattr(module, factory_name):
                continue
            current = getattr(module, factory_name)
            if current is wrapper:
                continue
            _WRAPPED_MODULE_ALIASES[(module_name, factory_name)] = current
            try:
                setattr(module, factory_name, wrapper)
            except Exception:
                pass


def _restore_property_factory_wrappers() -> None:
    for factory_name, original in list(_ORIGINAL_BPY_FACTORIES.items()):
        try:
            setattr(bpy.props, factory_name, original)
        except Exception:
            pass
    for module_name, module in _iter_package_modules():
        for factory_name in _PROP_FACTORY_NAMES:
            current = getattr(module, factory_name, None)
            if current in _WRAPPED_FACTORY_OBJECTS:
                replacement = _ORIGINAL_BPY_FACTORIES.get(factory_name) or getattr(bpy.props, factory_name, None)
                if replacement is not None:
                    try:
                        setattr(module, factory_name, replacement)
                    except Exception:
                        pass
    for (module_name, factory_name), original in list(_WRAPPED_MODULE_ALIASES.items()):
        module = sys.modules.get(module_name)
        if module is None:
            continue
        try:
            setattr(module, factory_name, original)
        except Exception:
            pass
    _ORIGINAL_BPY_FACTORIES.clear()
    _WRAPPED_FACTORIES.clear()
    _WRAPPED_FACTORY_OBJECTS.clear()
    _WRAPPED_MODULE_ALIASES.clear()


def _restore_annotation_properties() -> None:
    for (module_name, class_name, prop_name), original in list(_ORIGINAL_PROPERTY_DATA.items()):
        module = sys.modules.get(module_name)
        if module is None:
            continue
        cls = getattr(module, class_name, None)
        if cls is None:
            continue
        annotations = getattr(cls, "__annotations__", {}) or {}
        prop_def = annotations.get(prop_name)
        keywords, _prop_type = _property_keywords(prop_def)
        if not isinstance(keywords, dict):
            continue
        if original.get("description_present", False):
            keywords["description"] = original.get("description")
        else:
            keywords.pop("description", None)
        if original.get("items_present", False):
            keywords["items"] = original.get("items")
        else:
            keywords.pop("items", None)
    _ORIGINAL_PROPERTY_DATA.clear()


def _restore_operator_descriptions() -> None:
    for (module_name, class_name), original in list(_ORIGINAL_CLASS_DESCRIPTIONS.items()):
        module = sys.modules.get(module_name)
        if module is None:
            continue
        cls = getattr(module, class_name, None)
        if cls is None:
            continue
        try:
            setattr(cls, "bl_description", original)
        except Exception:
            pass
    _ORIGINAL_CLASS_DESCRIPTIONS.clear()


def _register_pending_translations() -> None:
    table = _PENDING_TRANSLATIONS.get("ja_JP", {})
    if not table:
        return
    try:
        bpy.app.translations.unregister(_OWNER)
    except Exception:
        pass
    try:
        bpy.app.translations.register(_OWNER, _PENDING_TRANSLATIONS)
    except Exception:
        pass


def _unregister_pending_translations() -> None:
    try:
        bpy.app.translations.unregister(_OWNER)
    except Exception:
        pass


def _clear_pending_translations() -> None:
    _PENDING_TRANSLATIONS.clear()
    _PENDING_TRANSLATIONS["ja_JP"] = {}


def begin_runtime_audit() -> None:
    global _ACTIVE, _FINISHED
    _ACTIVE = False
    _FINISHED = True
    return None


def finish_runtime_audit() -> None:
    global _ACTIVE, _FINISHED
    _ACTIVE = False
    _FINISHED = True
    return None


def clear_runtime_audit() -> None:
    global _ACTIVE, _FINISHED
    _ACTIVE = False
    _FINISHED = False
    _clear_pending_translations()
    return None


def abort_runtime_audit() -> None:
    clear_runtime_audit()
    return None
