# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import importlib.util
import platform
import sys
import traceback
import types
from pathlib import Path
from typing import Any

import bpy
from . import feature_toggle as _feature_toggle
from . import language as _language
from . import status_runtime as _status_runtime
from .bootstrap_common import (
    class_belongs_to_current_package as _loader_class_belongs_to_current_package,
    class_is_owned_for_mutation as _loader_class_is_owned_for_mutation,
    safe_register_class as _loader_safe_register_class,
    safe_unregister_class as _loader_safe_unregister_class,
)

from . import registry as registry

_RECORDS: list[dict[str, Any]] = []
_RECORDS_BY_ALIAS: dict[str, dict[str, Any]] = {}
_HIDDEN_PANEL_POLLS: dict[type, object] = {}


def _suite_is_shutting_down() -> bool:
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        return isinstance(ns, dict) and bool(ns.get('SMART_MODELING_SUITE_SHUTTING_DOWN'))
    except Exception:
        return False


def _is_panel_class_51(cls) -> bool:
    try:
        panel_base = getattr(bpy.types, 'Panel', None)
        return bool(panel_base is not None and isinstance(cls, type) and issubclass(cls, panel_base))
    except Exception:
        return False

_MISSING_POLL = object()


_SMART_MODELING_NATIVE_ROOT_IDS = frozenset(('VIEW3D_PT_sms_hub', 'IMAGE_PT_sms_hub', 'NODE_PT_sms_hub', 'SEQUENCER_PT_sms_hub', 'CLIP_PT_sms_hub', 'DOPESHEET_PT_sms_hub', 'GRAPH_PT_sms_hub', 'NLA_PT_sms_hub', 'TEXT_PT_sms_hub', 'FILEBROWSER_PT_sms_hub', 'SPREADSHEET_PT_sms_hub'))


def _is_single_visible_smart_modeling_root(cls) -> bool:
    try:
        identifiers = {
            str(getattr(cls, '__name__', '') or ''),
            str(getattr(cls, 'bl_idname', '') or ''),
        }
        return bool(identifiers.intersection(_SMART_MODELING_NATIVE_ROOT_IDS))
    except Exception:
        return False


def _should_skip_panel_registration(cls: type) -> bool:
    panel_base = getattr(bpy.types, 'Panel', None)
    if panel_base is None or not isinstance(cls, type):
        return False
    try:
        if not issubclass(cls, panel_base):
            return False
    except Exception:
        return False
    if _is_single_visible_smart_modeling_root(cls):
        return False
    try:
        if str(getattr(cls, 'bl_region_type', '') or '') != 'UI':
            return False
        module_name = str(getattr(cls, '__module__', '') or '')
        category = str(getattr(cls, 'bl_category', '') or '')
    except Exception:
        return False
    return ('smart_modeling_suite' in module_name) or category == 'Smart Modeling'


def clear_records() -> None:
    _RECORDS.clear()
    _RECORDS_BY_ALIAS.clear()


def get_records() -> list[dict[str, Any]]:
    return list(_RECORDS)


def get_record(alias: str) -> dict[str, Any] | None:
    return _RECORDS_BY_ALIAS.get(str(alias or '').strip())


def _root_module_prefix() -> str:
    package = str(__package__ or '').strip()
    return package or 'smart_modeling_suite'


def _platform_supported(outer_zip: str) -> bool:
    text = str(outer_zip or '').lower()
    system = platform.system().lower()
    machine = platform.machine().lower()
    if 'windows-x64' in text:
        return system == 'windows' and machine in {'amd64', 'x86_64'}
    if 'linux-x64' in text:
        return system == 'linux' and machine in {'amd64', 'x86_64'}
    if 'macos-arm64' in text:
        return system == 'darwin' and machine in {'arm64', 'aarch64'}
    if 'macos-x64' in text:
        return system == 'darwin' and machine in {'amd64', 'x86_64'}
    return True


def _module_name_for_spec(spec: dict[str, Any]) -> str:
    prefix = _root_module_prefix()
    alias = str(spec.get('alias') or 'addon').strip()
    return f'{prefix}.{alias}'


def _spec_import_paths(spec: dict[str, Any]) -> tuple[str, str, Path]:
    src_dir = Path(str(spec.get('src_dir') or ''))
    init_relpath = Path(str(spec.get('init_relpath') or ''))
    init_path = (src_dir / init_relpath).resolve() if src_dir and init_relpath else Path()
    module_name = _module_name_for_spec(spec)
    package_dir = init_path.parent if init_path.name == '__init__.py' else src_dir
    return module_name, str(init_path), package_dir


def _load_module_from_spec(spec: dict[str, Any]):
    module_name, init_path_str, package_dir = _spec_import_paths(spec)
    if not init_path_str:
        raise FileNotFoundError('init_relpath is empty')
    init_path = Path(init_path_str)
    if not init_path.exists():
        raise FileNotFoundError(f'Missing init file: {init_path}')

    sys.modules.pop(module_name, None)
    spec_obj = importlib.util.spec_from_file_location(
        module_name,
        str(init_path),
        submodule_search_locations=[str(package_dir)],
    )
    if spec_obj is None or spec_obj.loader is None:
        raise ImportError(f'Failed to create module spec for {init_path}')
    module = importlib.util.module_from_spec(spec_obj)
    sys.modules[module_name] = module

    spec_obj.loader.exec_module(module)
    return module


def _sms_force_operator_undo(cls) -> None:
    try:
        op_base = getattr(bpy.types, 'Operator', None)
        if op_base is None or not isinstance(cls, type) or not issubclass(cls, op_base):
            return
        opts = set(getattr(cls, 'bl_options', set()) or set())
        # Undo support is required, but REGISTER forces Blender to store
        # operator last-properties. On Blender 5.1.x Windows that storage path
        # can crash for stale or compatibility operators, so never add REGISTER
        # here.
        if bool(getattr(cls, '_sms_requires_register', False)):
            opts.add('REGISTER')
        else:
            opts.discard('REGISTER')
        opts.discard('UNDO_GROUPED')
        is_lazy_proxy = bool(getattr(cls, '_sms_lazy_keymap_proxy', False))
        preserve_lazy_undo = bool(getattr(cls, '_sms_lazy_proxy_preserve_undo', False))
        if bool(getattr(cls, '_sms_no_undo', False)) or (is_lazy_proxy and not preserve_lazy_undo):
            opts.discard('UNDO')
        else:
            opts.add('UNDO')
        cls.bl_options = opts
    except Exception:
        pass


def _prepare_hidden_panel_registration(cls) -> None:
    if not _loader_class_belongs_to_current_package(cls):
        return
    panel_base = getattr(bpy.types, 'Panel', None)
    if panel_base is None or not isinstance(cls, type):
        return
    try:
        if not issubclass(cls, panel_base):
            return
    except Exception:
        return
    try:
        if str(getattr(cls, 'bl_region_type', '') or '') != 'UI':
            return
    except Exception:
        return
    if cls in _HIDDEN_PANEL_POLLS:
        return
    raw_poll = cls.__dict__.get('poll', _MISSING_POLL)

    @classmethod
    def _hidden_poll(_inner_cls, _context):
        return False

    try:
        cls.poll = _hidden_poll
        try:
            setattr(cls, '_sms_hidden_from_top_level_npanel', True)
            setattr(cls, '_sms_skip_sidebar_registration', True)
        except Exception:
            pass
        # Integrated add-ons may define draw_header callbacks that read stale
        # operator or object RNA while Blender lays out the sidebar.  The unified
        # Smart Modeling host draws these panels inside each tool's 設定 section,
        # so their standalone N-panel headers are unnecessary.
        try:
            if 'draw_header' in getattr(cls, '__dict__', {}):
                setattr(cls, '_sms_original_draw_header_disabled', cls.__dict__.get('draw_header'))
                delattr(cls, 'draw_header')
        except Exception:
            pass
        _HIDDEN_PANEL_POLLS[cls] = raw_poll
    except Exception:
        pass



def _sms_final_exit_in_progress_51() -> bool:
    try:
        from .bootstrap_common import _sms_blender_exit_in_progress_51
        return bool(_sms_blender_exit_in_progress_51())
    except Exception:
        return False


def _registered_rna_class_51(cls):
    if not isinstance(cls, type):
        return None
    if _sms_final_exit_in_progress_51():
        return None
    bl_idname = str(getattr(cls, 'bl_idname', '') or '').strip()

    # Never identify a registered add-on class by Python class name alone.
    # Names such as Spline, Curve, and Space are also built-in Blender RNA data
    # types.  Treating bpy.types.Spline as an already registered Operator made
    # the loader skip mesh.edgetools_spline (and similarly Curve/Space), then
    # attempted to patch the unrelated built-in type in place.
    try:
        existing = getattr(bpy.types, str(getattr(cls, '__name__', '') or ''), None)
        if isinstance(existing, type):
            base_names = (
                'Operator', 'Menu', 'Panel', 'AddonPreferences', 'PropertyGroup',
                'Gizmo', 'GizmoGroup', 'UIList', 'Header',
            )
            same_base = False
            for base_name in base_names:
                base = getattr(bpy.types, base_name, None)
                if base is None:
                    continue
                try:
                    if issubclass(cls, base) and issubclass(existing, base):
                        same_base = True
                        break
                except Exception:
                    continue
            if same_base:
                existing_idname = str(getattr(existing, 'bl_idname', '') or '').strip()
                same_id = bool(bl_idname and existing_idname == bl_idname)
                same_origin = (
                    not bl_idname
                    and str(getattr(existing, '__module__', '') or '')
                    == str(getattr(cls, '__module__', '') or '')
                )
                if same_id or same_origin:
                    try:
                        getattr(existing, 'bl_rna')
                        return existing
                    except Exception:
                        pass
    except Exception:
        pass
    if not bl_idname:
        return None
    try:
        class_name = str(getattr(cls, '__name__', '') or '').strip()
        candidates = {bl_idname, class_name}
        if bl_idname and '.' in bl_idname and '_OT_' in class_name:
            namespace = bl_idname.split('.', 1)[0].upper()
            _, suffix = class_name.split('_OT_', 1)
            if namespace and suffix:
                candidates.add(f'{namespace}_OT_{suffix}')
        for candidate in tuple(c for c in candidates if c):
            for base_name in ('Operator', 'Menu', 'Panel', 'AddonPreferences', 'PropertyGroup', 'Gizmo', 'GizmoGroup', 'UIList', 'Header'):
                try:
                    base = getattr(bpy.types, base_name, None)
                    getter = getattr(base, 'bl_rna_get_subclass_py', None) if base is not None else None
                    if callable(getter):
                        existing = getter(candidate, None)
                        if isinstance(existing, type):
                            return existing
                except Exception:
                    pass
    except Exception:
        pass
    for base_name in ('Operator', 'Menu', 'Panel', 'AddonPreferences', 'PropertyGroup', 'Gizmo', 'GizmoGroup', 'UIList', 'Header'):
        try:
            base = getattr(bpy.types, base_name, None)
            getter = getattr(base, 'bl_rna_get_subclass_py', None) if base is not None else None
            if callable(getter):
                existing = getter(bl_idname, None)
                if isinstance(existing, type):
                    return existing
        except Exception:
            pass
    try:
        if bl_idname and '.' in bl_idname:
            namespace, opname = bl_idname.split('.', 1)
            op_ns = getattr(bpy.ops, namespace, None)
            op_fn = getattr(op_ns, opname, None) if op_ns is not None else None
            get_rna_type = getattr(op_fn, 'get_rna_type', None)
            if callable(get_rna_type):
                try:
                    rna = get_rna_type()
                except Exception:
                    rna = None
                identifier = str(getattr(rna, 'identifier', '') or '').strip() if rna is not None else ''
                if identifier:
                    class_name = str(getattr(cls, '__name__', '') or '').strip()
                    candidates = {class_name}
                    opname_suffix = ''.join(ch if ch.isalnum() else '_' for ch in opname).strip('_')
                    if namespace and opname_suffix:
                        candidates.add(f'{namespace.upper()}_OT_{opname_suffix}')
                    if '_OT_' in class_name:
                        try:
                            _prefix, suffix = class_name.split('_OT_', 1)
                            if suffix:
                                candidates.add(f'{namespace.upper()}_OT_{suffix}')
                        except Exception:
                            pass
                    if identifier in candidates:
                        # Resolve the actual registered Python class.  Returning
                        # ``cls`` here is unsafe when another class with the same
                        # bl_idname is already registered: Blender then treats the
                        # source class as unregistered and register_class() silently
                        # replaces the live RNA type, which can invalidate open UI or
                        # modal operator pointers.
                        for base_name in ('Operator', 'Menu', 'Panel', 'AddonPreferences', 'PropertyGroup', 'Gizmo', 'GizmoGroup', 'UIList', 'Header'):
                            try:
                                base = getattr(bpy.types, base_name, None)
                                getter = getattr(base, 'bl_rna_get_subclass_py', None) if base is not None else None
                                existing = getter(identifier, None) if callable(getter) else None
                                if isinstance(existing, type):
                                    return existing
                            except Exception:
                                pass
                        try:
                            existing = getattr(bpy.types, identifier, None)
                            if isinstance(existing, type):
                                getattr(existing, 'bl_rna')
                                return existing
                        except Exception:
                            pass
    except Exception:
        pass
    return None


def _patch_registered_class_namespace_51(existing, source) -> None:
    try:
        source_dict = dict(getattr(source, '__dict__', {}) or {})
    except Exception:
        return
    try:
        annotation_names = set((source_dict.get('__annotations__') or {}).keys())
    except Exception:
        annotation_names = set()
    skip = {
        '__dict__', '__weakref__', '__module__', '__doc__', '__annotations__',
        '__slots__', 'bl_rna', 'rna_type',
        '_sms_lazy_keymap_proxy', '_sms_lazy_tool_id', '_sms_lazy_target_idname',
    }
    for name, value in source_dict.items():
        if name in skip or name in annotation_names or name.startswith('__'):
            continue
        try:
            if callable(getattr(value, 'function', None)) and hasattr(value, 'keywords'):
                continue
        except Exception:
            pass
        try:
            setattr(existing, name, value)
        except Exception:
            pass


def _patch_registered_class_in_place_51(existing, source) -> bool:
    if not (isinstance(existing, type) and isinstance(source, type)):
        return False
    if not _loader_class_is_owned_for_mutation(existing) or not _loader_class_belongs_to_current_package(source):
        return False
    if _is_panel_class_51(existing):
        for attr in ('bl_label', 'bl_description', 'bl_category', 'bl_space_type', 'bl_region_type', 'bl_parent_id', 'bl_options', 'bl_order'):
            if attr in getattr(source, '__dict__', {}):
                try:
                    setattr(existing, attr, getattr(source, attr))
                except Exception:
                    pass
        for attr in ('poll', 'draw', 'draw_header', 'draw_header_preset'):
            if attr in getattr(source, '__dict__', {}):
                try:
                    setattr(existing, attr, getattr(source, attr))
                except Exception:
                    pass
        return True
    _patch_registered_class_namespace_51(existing, source)
    return True

_SMS_HOSTED_PANELS_WITH_CALLBACK: set[type] = set()


def _run_class_register_callback(cls: type, *, hosted: bool = False) -> None:
    # Blender runs a class's register() only when it registers that very class.
    # A class merged into a live shell or hosted inside the N-panel never gets
    # that call, so the properties and child classes it owns must be created here.
    if 'register' not in getattr(cls, '__dict__', {}):
        return
    try:
        cls.register()
    except Exception:
        traceback.print_exc()
        return
    if hosted and 'unregister' in cls.__dict__:
        _SMS_HOSTED_PANELS_WITH_CALLBACK.add(cls)


def _run_hosted_panel_unregister_callbacks(classes) -> None:
    for cls in reversed(list(classes or ())):
        if cls not in _SMS_HOSTED_PANELS_WITH_CALLBACK:
            continue
        _SMS_HOSTED_PANELS_WITH_CALLBACK.discard(cls)
        try:
            cls.unregister()
        except Exception:
            traceback.print_exc()


def _capture_registered_classes(callable_obj) -> tuple[list[type], Exception | None, str]:
    captured: list[type] = []
    original_register_class = bpy.utils.register_class

    def _wrapped_register_class(cls):
        try:
            _language.sanitize_class_ui(cls)
        except Exception:
            pass
        try:
            _sms_force_operator_undo(cls)
        except Exception:
            pass
        try:
            _status_runtime.instrument_operator_class(cls, 'smart_modeling_suite', 'Smart Modeling Suite')
        except Exception:
            pass
        try:
            _prepare_hidden_panel_registration(cls)
        except Exception:
            pass
        try:
            if _should_skip_panel_registration(cls):
                captured.append(cls)
                _run_class_register_callback(cls, hosted=True)
                return None
        except Exception:
            pass
        try:
            existing = _registered_rna_class_51(cls)
            if isinstance(existing, type) and existing is not cls:
                if _patch_registered_class_in_place_51(existing, cls):
                    try:
                        _status_runtime.instrument_operator_class(existing, 'smart_modeling_suite', 'Smart Modeling Suite')
                    except Exception:
                        pass
                    captured.append(existing)
                    _run_class_register_callback(cls)
                return None
        except Exception:
            pass
        try:
            if _loader_safe_register_class(cls):
                captured.append(cls)
        except ValueError:
            try:
                existing = _registered_rna_class_51(cls)
                if isinstance(existing, type):
                    _patch_registered_class_in_place_51(existing, cls)
                    captured.append(existing)
            except Exception:
                pass
        except Exception:
            pass

    bpy.utils.register_class = _wrapped_register_class
    error: Exception | None = None
    trace_text = ''
    try:
        try:
            _language.install_property_wrappers()
        except Exception:
            pass
        callable_obj()
    except Exception as exc:
        error = exc
        trace_text = traceback.format_exc()
    finally:
        try:
            _language._restore_property_wrappers()
        except Exception:
            pass
        bpy.utils.register_class = original_register_class
    return captured, error, trace_text


def _class_belongs_to_loaded_addon(cls: type, module, spec: dict[str, Any]) -> bool:
    class_module = str(getattr(cls, '__module__', '') or '').strip()
    if not class_module:
        return False
    prefixes = []
    module_name = str(getattr(module, '__name__', '') or '').strip()
    if module_name:
        prefixes.append(module_name)
    original_module_name = str(spec.get('original_module_name') or '').strip()
    if original_module_name:
        prefixes.append(original_module_name)
    for prefix in prefixes:
        if class_module == prefix or class_module.startswith(prefix + '.'):
            return True
    return False


def _iter_loaded_module_tree(module, spec: dict[str, Any]):
    prefixes = []
    module_name = str(getattr(module, '__name__', '') or '').strip()
    if module_name:
        prefixes.append(module_name)
    original_module_name = str(spec.get('original_module_name') or '').strip()
    if original_module_name:
        prefixes.append(original_module_name)
    prefixes = tuple(prefixes)
    if not prefixes:
        return []

    seen = set()
    stack = [module]
    modules = []
    while stack:
        mod = stack.pop()
        if mod is None:
            continue
        mod_id = id(mod)
        if mod_id in seen:
            continue
        seen.add(mod_id)
        modules.append(mod)
        for value in getattr(mod, '__dict__', {}).values():
            if not isinstance(value, types.ModuleType):
                continue
            child_name = str(getattr(value, '__name__', '') or '').strip()
            if not child_name:
                continue
            if any(child_name == prefix or child_name.startswith(prefix + '.') for prefix in prefixes):
                stack.append(value)
    return modules


def _class_registered(cls: type) -> bool:
    if cls is None or not isinstance(cls, type):
        return False
    try:
        if getattr(bpy.types, getattr(cls, '__name__', ''), None) is cls:
            return True
    except Exception:
        pass
    bl_idname = str(getattr(cls, 'bl_idname', '') or '').strip()
    if not bl_idname:
        return False
    for base_name in ('Operator', 'Menu', 'Panel', 'PropertyGroup'):
        try:
            base = getattr(bpy.types, base_name, None)
            getter = getattr(base, 'bl_rna_get_subclass_py', None) if base is not None else None
            if callable(getter) and getter(bl_idname, None) is cls:
                return True
        except Exception:
            continue
    return False


def _collect_public_ui_classes(module, spec: dict[str, Any]) -> list[type]:
    panel_base = getattr(bpy.types, 'Panel', None)
    operator_base = getattr(bpy.types, 'Operator', None)
    menu_base = getattr(bpy.types, 'Menu', None)
    classes: list[type] = []
    seen: set[type] = set()
    for mod in _iter_loaded_module_tree(module, spec):
        for value in getattr(mod, '__dict__', {}).values():
            if not isinstance(value, type):
                continue
            if value in seen:
                continue
            seen.add(value)
            if not _class_belongs_to_loaded_addon(value, module, spec):
                continue
            name = str(getattr(value, '__name__', '') or '').strip()
            if not name or name.startswith('_'):
                continue
            try:
                if panel_base is not None and issubclass(value, panel_base):
                    classes.append(value)
                    continue
            except Exception:
                pass
            try:
                if operator_base is not None and issubclass(value, operator_base):
                    if str(getattr(value, 'bl_idname', '') or '').strip():
                        classes.append(value)
                    continue
            except Exception:
                pass
            try:
                if menu_base is not None and issubclass(value, menu_base):
                    if str(getattr(value, 'bl_idname', '') or '').strip():
                        classes.append(value)
                    continue
            except Exception:
                pass
    return classes


def _extra_ui_classes(module, spec: dict[str, Any], captured: list[type]) -> list[type]:
    """Recover omitted public UI classes without replacing a live RNA identity.

    Several bundled upstream add-ons keep legacy/base classes with the same
    ``bl_idname`` as the class explicitly registered by their ``register()``
    function.  Registering those secondary classes makes Blender unregister the
    intended class automatically and can invalidate operator/UI pointers.  The
    class explicitly captured from ``register()`` is therefore authoritative;
    only one class per RNA id is ever considered here.
    """
    extras: list[type] = []
    seen = set(captured)
    claimed_idnames: dict[str, type] = {}

    for cls in captured:
        try:
            idname = str(getattr(cls, 'bl_idname', '') or '').strip()
        except Exception:
            idname = ''
        if idname:
            claimed_idnames.setdefault(idname, cls)

    public_classes = _collect_public_ui_classes(module, spec)

    # Classes already registered by module side effects also take precedence
    # over unregistered compatibility/base definitions found by the scanner.
    for cls in public_classes:
        if cls in seen:
            continue
        try:
            idname = str(getattr(cls, 'bl_idname', '') or '').strip()
        except Exception:
            idname = ''
        if idname and idname in claimed_idnames:
            continue
        if _class_registered(cls):
            extras.append(cls)
            seen.add(cls)
            if idname:
                claimed_idnames[idname] = cls

    for cls in public_classes:
        if cls in seen:
            continue
        try:
            idname = str(getattr(cls, 'bl_idname', '') or '').strip()
        except Exception:
            idname = ''
        if idname and idname in claimed_idnames:
            # A captured/registered class already owns this RNA id.  Do not
            # register or patch a differently named base/legacy implementation.
            continue
        if idname:
            claimed_idnames[idname] = cls
        seen.add(cls)

        try:
            _language.sanitize_class_ui(cls)
        except Exception:
            pass
        try:
            _status_runtime.instrument_operator_class(cls, 'smart_modeling_suite', 'Smart Modeling Suite')
        except Exception:
            pass
        try:
            _prepare_hidden_panel_registration(cls)
        except Exception:
            pass
        try:
            if _should_skip_panel_registration(cls):
                extras.append(cls)
                _run_class_register_callback(cls, hosted=True)
                continue
        except Exception:
            pass
        try:
            existing = _registered_rna_class_51(cls)
            if isinstance(existing, type) and existing is not cls:
                # Same class name means this is a stale same-session copy and is
                # safe to patch in place.  A different class name sharing the
                # id is a compatibility/alternate implementation and is left
                # untouched.
                if str(getattr(existing, '__name__', '') or '') == str(getattr(cls, '__name__', '') or ''):
                    _patch_registered_class_in_place_51(existing, cls)
                    extras.append(existing)
                continue
        except Exception:
            pass
        try:
            bpy.utils.register_class(cls)
        except ValueError:
            try:
                existing = _registered_rna_class_51(cls)
                if isinstance(existing, type):
                    if str(getattr(existing, '__name__', '') or '') == str(getattr(cls, '__name__', '') or ''):
                        _patch_registered_class_in_place_51(existing, cls)
                        extras.append(existing)
            except Exception:
                pass
            continue
        except Exception:
            continue
        if _class_registered(cls):
            extras.append(cls)
    return extras






def _call_with_panel_unregister_guard(fn):
    """Run an integrated module's real unregister path.

    Older builds converted every class removal into a no-op to work around an
    obsolete live-reload crash.  That left hundreds of Operators, Panels and
    PropertyGroups resident after the suite was disabled.  The loader now owns
    every class it registers, so symmetric teardown is both safe and required.
    """
    return fn()


def _unregister_classes(classes: list[type] | tuple[type, ...]) -> None:
    for cls in reversed(list(classes or ())):
        if _loader_class_is_owned_for_mutation(cls):
            _loader_safe_unregister_class(cls)


def _unregister_owned_rna_classes(module, spec: dict[str, Any]) -> None:
    # Registration-time capture already holds the exact class identities.  A
    # bpy.types/module-prefix sweep is forbidden because it can include foreign
    # classes that merely share a name, id, category, or imported module string.
    return None

def _categorize_classes(classes: list[type]) -> tuple[list[type], list[type], list[type], list[type]]:
    panels: list[type] = []
    operators: list[type] = []
    menus: list[type] = []
    prefs: list[type] = []
    panel_base = getattr(bpy.types, 'Panel', None)
    operator_base = getattr(bpy.types, 'Operator', None)
    menu_base = getattr(bpy.types, 'Menu', None)
    prefs_base = getattr(bpy.types, 'AddonPreferences', None)
    property_group_base = getattr(bpy.types, 'PropertyGroup', None)
    for cls in classes:
        try:
            if panel_base is not None and isinstance(cls, type) and issubclass(cls, panel_base):
                panels.append(cls)
                continue
        except Exception:
            pass
        try:
            if operator_base is not None and isinstance(cls, type) and issubclass(cls, operator_base):
                operators.append(cls)
                continue
        except Exception:
            pass
        try:
            if menu_base is not None and isinstance(cls, type) and issubclass(cls, menu_base):
                menus.append(cls)
                continue
        except Exception:
            pass
        try:
            if prefs_base is not None and isinstance(cls, type) and issubclass(cls, prefs_base):
                prefs.append(cls)
                continue
        except Exception:
            pass
        try:
            if property_group_base is not None and isinstance(cls, type) and issubclass(cls, property_group_base):
                class_name = str(getattr(cls, '__name__', '') or '')
                if 'Preferences' in class_name or class_name.endswith('Prefs') or class_name.endswith('PrefsProxy'):
                    prefs.append(cls)
                    continue
        except Exception:
            pass
    return panels, operators, menus, prefs


def _hide_original_panels(panels: list[type]) -> None:
    panels = [cls for cls in panels if _loader_class_is_owned_for_mutation(cls)]
    for cls in panels:
        try:
            # Keep non-sidebar utility panels visible.  The single-N-panel rule
            # only applies to Sidebar-style tool panels.
            if str(getattr(cls, 'bl_space_type', '') or '') == 'PROPERTIES':
                continue
        except Exception:
            pass
        if cls in _HIDDEN_PANEL_POLLS:
            continue
        raw_poll = cls.__dict__.get('poll', _MISSING_POLL)

        @classmethod
        def _hidden_poll(_inner_cls, _context):
            return False

        try:
            cls.poll = _hidden_poll
            _HIDDEN_PANEL_POLLS[cls] = raw_poll
        except Exception:
            pass


def _restore_hidden_panels_for_classes(panels: list[type]) -> None:
    if _suite_is_shutting_down():
        for cls in panels:
            _HIDDEN_PANEL_POLLS.pop(cls, None)
        return
    for cls in panels:
        raw_poll = _HIDDEN_PANEL_POLLS.pop(cls, None)
        if raw_poll is None:
            continue
        try:
            if raw_poll is _MISSING_POLL:
                if hasattr(cls, 'poll'):
                    setattr(cls, 'poll', classmethod(lambda _cls, _context: True))
            else:
                setattr(cls, 'poll', raw_poll)
        except Exception:
            pass


def _restore_hidden_panels() -> None:
    if _suite_is_shutting_down():
        _HIDDEN_PANEL_POLLS.clear()
        return
    _restore_hidden_panels_for_classes(list(_HIDDEN_PANEL_POLLS.keys()))
    _HIDDEN_PANEL_POLLS.clear()


def _standby_status_for_spec(spec: dict[str, Any]) -> str:
    if not bool(spec.get('load', True)):
        return 'disabled'
    if not _platform_supported(str(spec.get('outer_zip') or '')):
        return 'unsupported_platform'
    return 'available'


def _new_record(spec: dict[str, Any]) -> dict[str, Any]:
    return {
        'spec': spec,
        'status': _standby_status_for_spec(spec),
        'module': None,
        'registered_classes': [],
        'proxy_panels': [],
        'panels': [],
        'operators': [],
        'menus': [],
        'preferences': [],
        'recovered_classes': [],
        'error': '',
        'hidden_panels': [],
    }


def _reset_runtime_fields(record: dict[str, Any]) -> None:
    record['module'] = None
    record['registered_classes'] = []
    record['proxy_panels'] = []
    record['panels'] = []
    record['operators'] = []
    record['menus'] = []
    record['preferences'] = []
    record['recovered_classes'] = []
    record['error'] = ''
    record['hidden_panels'] = []
    record['registered_rna_properties'] = []


def _rna_root_property_snapshot() -> dict[str, set[str]]:
    result: dict[str, set[str]] = {}
    for owner_name in ('Scene', 'WindowManager', 'Object', 'Mesh', 'Material'):
        owner = getattr(bpy.types, owner_name, None)
        if owner is None:
            continue
        try:
            result[owner_name] = {
                str(prop.identifier)
                for prop in getattr(getattr(owner, 'bl_rna', None), 'properties', ())
                if str(getattr(prop, 'identifier', '') or '')
            }
        except Exception:
            result[owner_name] = set()
    return result


def _remove_registered_rna_properties(items) -> None:
    for owner_name, attr_name in reversed(list(items or ())):
        owner = getattr(bpy.types, str(owner_name or ''), None)
        attr_name = str(attr_name or '').strip()
        if owner is None or not attr_name:
            continue
        try:
            if hasattr(owner, attr_name):
                delattr(owner, attr_name)
        except Exception:
            pass


def _purge_module_entries(spec: dict[str, Any], module=None) -> None:
    module_name = _module_name_for_spec(spec)
    keys = list(sys.modules.keys())
    for key in keys:
        if key == module_name or key.startswith(module_name + '.'):
            sys.modules.pop(key, None)


def register_all() -> list[dict[str, Any]]:
    try:
        _feature_toggle.register_ui()
    except Exception:
        pass
    clear_records()
    visible_spec = getattr(registry, 'is_visible_addon_spec', lambda spec: True)
    specs = [spec for spec in registry.build_specs(force=True) if bool(visible_spec(spec))]
    for spec in specs:
        record = _new_record(spec)
        _RECORDS.append(record)
        alias = str(spec.get('alias') or '').strip()
        if alias:
            _RECORDS_BY_ALIAS[alias] = record
    return get_records()

def ensure_loaded(alias: str) -> dict[str, Any] | None:
    record = get_record(alias)
    if record is None:
        return None

    spec = record.get('spec') or {}
    standby_status = _standby_status_for_spec(spec)
    if standby_status in {'disabled', 'unsupported_platform'}:
        record['status'] = standby_status
        return record
    if str(record.get('status') or '') == 'loaded' and record.get('module') is not None:
        return record

    old_module = record.get('module')
    _purge_module_entries(spec, module=old_module)
    _restore_hidden_panels_for_classes(list(record.get('hidden_panels', ()) or ()))
    _reset_runtime_fields(record)
    record['status'] = 'loading'

    module = None
    captured: list[type] = []
    recovered: list[type] = []
    error_text = ''
    _persistence = None
    _rna_before = _rna_root_property_snapshot()
    try:
        try:
            from . import common as _persistence
            _persistence.begin_dynamic_registration()
        except Exception:
            _persistence = None
        module = _load_module_from_spec(spec)
        try:
            _language.sanitize_module_ui(module)
        except Exception:
            pass
        record['module'] = module
        register_fn = getattr(module, 'register', None)
        _ft_alias = str((spec.get('alias') if isinstance(spec, dict) else '') or globals().get('alias', '') or 'integrated_tool').strip()
        _ft_label = str((spec.get('display_name') if isinstance(spec, dict) else '') or _ft_alias or 'Integrated Tool').strip()
        with _feature_toggle.capture_runtime(_ft_alias, _ft_label):
            if callable(register_fn):
                captured, register_error, register_trace = _capture_registered_classes(register_fn)
                if register_error is not None:
                    error_text = register_trace or str(register_error)
                    raise register_error
    
        captured = [cls for cls in captured if _class_belongs_to_loaded_addon(cls, module, spec)]
        recovered = _extra_ui_classes(module, spec, captured)
        available_classes: list[type] = []
        seen_classes: set[type] = set()
        for cls in list(captured) + list(recovered):
            if cls in seen_classes:
                continue
            seen_classes.add(cls)
            available_classes.append(cls)
        panels, operators, menus, prefs = _categorize_classes(available_classes)
        record['registered_classes'] = available_classes
        record['recovered_classes'] = recovered
        record['panels'] = panels
        record['operators'] = operators
        record['menus'] = menus
        record['preferences'] = prefs
        record['hidden_panels'] = list(panels)
        _rna_after = _rna_root_property_snapshot()
        record['registered_rna_properties'] = [
            (owner_name, prop_name)
            for owner_name, after_names in _rna_after.items()
            for prop_name in sorted(after_names - _rna_before.get(owner_name, set()))
        ]
        _hide_original_panels(panels)
        record['status'] = 'loaded'
        record['error'] = ''
        try:
            from . import common as _sms_common
            _sms_common.restore_dynamic_persistent_settings(getattr(bpy, 'context', None))
        except Exception:
            pass
    except Exception as exc:
        try:
            if module is not None:
                unregister_fn = getattr(module, 'unregister', None)
                if callable(unregister_fn):
                    _call_with_panel_unregister_guard(unregister_fn)
        except Exception:
            pass
        try:
            panels_to_restore, _ops, _menus, _prefs = _categorize_classes(list(captured) + list(recovered))
            _restore_hidden_panels_for_classes(panels_to_restore)
        except Exception:
            pass
        _unregister_classes(recovered)
        _purge_module_entries(spec, module=module)
        _reset_runtime_fields(record)
        record['status'] = 'failed'
        record['error'] = (error_text or traceback.format_exc() or str(exc)).strip()
    finally:
        if _persistence is not None:
            try:
                _persistence.end_dynamic_registration(getattr(bpy, 'context', None))
            except Exception:
                pass
    return record


def unload(alias: str) -> dict[str, Any] | None:
    alias = str(alias or '').strip()
    record = get_record(alias)
    if record is None:
        return None

    spec = record.get('spec') or {}
    module = record.get('module')
    panels_to_restore = list(record.get('hidden_panels', ()) or ())
    registered_classes = list(record.get('registered_classes', ()) or ())
    recovered_classes = list(record.get('recovered_classes', ()) or ())
    registered_rna_properties = list(record.get('registered_rna_properties', ()) or ())

    try:
        _feature_toggle.deactivate_alias(alias)
    except Exception:
        pass
    try:
        _feature_toggle.clear_alias(alias)
    except Exception:
        pass

    if module is not None:
        try:
            unregister_fn = getattr(module, 'unregister', None)
            if callable(unregister_fn):
                _call_with_panel_unregister_guard(unregister_fn)
        except Exception:
            pass

    # Give the bundled module its expected teardown order first, then detach
    # any RNA roots it omitted before the loader's final class ownership sweep.
    # Removing roots before module.unregister() can make Blender abort class
    # cleanup halfway through when an Operator annotation references a sibling
    # WindowManager property.
    _remove_registered_rna_properties(registered_rna_properties)

    _restore_hidden_panels_for_classes(panels_to_restore)
    _run_hosted_panel_unregister_callbacks(registered_classes)
    # Module unregister functions are not uniformly exhaustive across the
    # bundled third-party tools.  Clean up every class captured at registration
    # as a final ownership pass; already-unregistered classes are skipped.
    _unregister_classes(registered_classes)
    _unregister_classes(recovered_classes)
    _unregister_owned_rna_classes(module, spec)
    _purge_module_entries(spec, module=module)
    _reset_runtime_fields(record)
    record['status'] = _standby_status_for_spec(spec)
    # Do not traverse persistent RNA after unregistering the integrated module.
    # Its PropertyGroups have just been removed and any cached bpy_struct proxy
    # is invalid at this boundary.  The next load restores settings after the
    # module has registered fresh RNA through end_dynamic_registration().
    return record


def unregister_all() -> None:
    try:
        _feature_toggle.unregister_all()
    except Exception:
        pass
    for record in reversed(_RECORDS):
        if str(record.get('status') or '') == 'loaded' or record.get('module') is not None:
            try:
                unload(str(record.get('spec', {}).get('alias') or ''))
            except Exception:
                pass
    _restore_hidden_panels()
    clear_records()
    registry.clear_cache()
