# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

import bpy
from ..bootstrap_common import class_is_owned_for_mutation as _vscpz_owned_class
from ..bootstrap_common import safe_unregister_class as _vscpz_exact_safe_unregister_class
import bmesh
import gpu
import math
from gpu_extras.batch import batch_for_shader
from ..compat import get_uniform_color_shader
from .. import language as _language
from bpy.props import BoolProperty, CollectionProperty, FloatProperty, IntProperty, PointerProperty, StringProperty
from ..common import persistent_property_factory as _persistent_property

BoolProperty = _persistent_property(BoolProperty)
FloatProperty = _persistent_property(FloatProperty)
IntProperty = _persistent_property(IntProperty)
PointerProperty = _persistent_property(PointerProperty)
StringProperty = _persistent_property(StringProperty)
from bpy_extras import view3d_utils
from mathutils import Vector

from . import core, extension

_LINES_DRAW_HANDLER = None
_PREV_BUILD_MAPPING = None
_LINE_CACHE = {}


class _MappingLinesDrawSnapshot:
    __slots__ = ("shader", "line_entries", "point_entries", "enabled")

    def __init__(self):
        self.shader = None
        self.line_entries = ()
        self.point_entries = ()
        self.enabled = False

    def clear(self):
        self.line_entries = ()
        self.point_entries = ()
        self.enabled = False


_LINES_DRAW_SNAPSHOT = _MappingLinesDrawSnapshot()


def _add_lines_draw_handler():
    global _LINES_DRAW_HANDLER
    # Mapping lines are a GUI-only SpaceView3D resource.  Do not touch the draw
    # API in headless/background jobs; persistence still retains the user's
    # desired state for the next interactive session.
    if bpy.app.background:
        return
    if _LINES_DRAW_HANDLER is not None:
        return
    _rebuild_lines_draw_snapshot(getattr(bpy, 'context', None))
    try:
        _LINES_DRAW_HANDLER = bpy.types.SpaceView3D.draw_handler_add(
            _lines_draw_callback, (_LINES_DRAW_SNAPSHOT,), 'WINDOW', 'POST_VIEW'
        )
    except Exception:
        _LINES_DRAW_HANDLER = None


def _remove_lines_draw_handler():
    global _LINES_DRAW_HANDLER
    if _LINES_DRAW_HANDLER is None:
        return
    try:
        bpy.types.SpaceView3D.draw_handler_remove(_LINES_DRAW_HANDLER, 'WINDOW')
    except Exception:
        pass
    _LINES_DRAW_HANDLER = None
    _LINES_DRAW_SNAPSHOT.clear()


def sync_lines_draw_handler(force_state=None):
    state = force_state
    if state is None:
        try:
            settings = _settings(bpy.context)
            state = bool(getattr(settings, 'show_mapping_edit_overlay', False))
        except Exception:
            state = False
    if state:
        if _LINES_DRAW_HANDLER is None:
            _add_lines_draw_handler()
        else:
            _rebuild_lines_draw_snapshot(getattr(bpy, 'context', None))
    else:
        _remove_lines_draw_handler()
    _tag_redraw()


def _update_mapping_overlay_toggle(self, context):
    sync_lines_draw_handler(bool(getattr(self, 'show_mapping_edit_overlay', False)))
    try:
        from .. import common as _persistent_settings
        _persistent_settings.save_persistent_settings(context or getattr(bpy, 'context', None), force=False)
    except Exception:
        pass




def _update_mapping_overlay_visuals(self, context):
    """Refresh cached overlay colors, sizes, and selected visual state."""
    del self
    if _LINES_DRAW_HANDLER is not None:
        _rebuild_lines_draw_snapshot(context or getattr(bpy, 'context', None))
    _tag_redraw()
    try:
        from .. import common as _persistent_settings
        _persistent_settings.save_persistent_settings(context or getattr(bpy, 'context', None), force=False)
    except Exception:
        pass


def _tag_redraw():
    try:
        core._tag_redraw_all_view3d()
    except Exception:
        pass


def _settings(context=None):
    context = context or bpy.context
    scene = getattr(context, 'scene', None)
    return getattr(scene, 'vscpz_settings', None) if scene else None


def _payload(context=None):
    context = context or bpy.context
    try:
        return core._active_payload(context)
    except Exception:
        return None


def _source_dict_from_payload(payload, source_index):
    if not payload:
        return None
    for item in payload.get('vertices', []):
        if int(item.get('index', -1)) == int(source_index):
            return item
    return None


def _excluded_target_set(zs):
    return {int(item.target_index) for item in zs.excluded_targets}


def _fixed_pair_dict(zs):
    return {int(item.source_index): int(item.target_index) for item in zs.fixed_pairs}


def _mapping_edit_signature(zs):
    return (
        tuple(sorted((int(i.source_index), int(i.target_index)) for i in zs.fixed_pairs)),
        tuple(sorted(int(i.target_index) for i in zs.excluded_targets)),
        int(zs.selected_source_index),
        int(zs.selected_target_index),
        bool(zs.show_mapping_edit_overlay),
    )


def _invalidate_all_caches():
    _LINE_CACHE.clear()
    try:
        core._invalidate_preview_cache()
    except Exception:
        pass
    try:
        extension._EXT_PREVIEW_CACHE.clear()
    except Exception:
        pass
    if _LINES_DRAW_HANDLER is not None:
        _rebuild_lines_draw_snapshot(getattr(bpy, 'context', None))
    _tag_redraw()


def _apply_mapping_edits(mapping, payload, zs, *, include_excluded=False):
    if not isinstance(mapping, dict):
        return mapping
    excluded = set() if include_excluded else _excluded_target_set(zs)
    fixed = _fixed_pair_dict(zs)
    out = {}
    for tgt, src in mapping.items():
        try:
            tgt_i = int(tgt)
        except Exception:
            out[tgt] = src
            continue
        if tgt_i in excluded:
            continue
        src_idx = int(src.get('index', -1)) if isinstance(src, dict) else -1
        if src_idx in fixed:
            continue
        out[tgt_i] = src

    # ensure fixed mappings override everything else
    for src_idx, tgt_idx in fixed.items():
        if tgt_idx in excluded:
            continue
        src = _source_dict_from_payload(payload, src_idx)
        if not src:
            continue
        # remove any existing mapping using same target or same source
        to_remove = []
        for existing_tgt, existing_src in out.items():
            existing_idx = int(existing_src.get('index', -1)) if isinstance(existing_src, dict) else -1
            if int(existing_tgt) == tgt_idx or existing_idx == src_idx:
                to_remove.append(existing_tgt)
        for key in to_remove:
            out.pop(key, None)
        out[tgt_idx] = dict(src)
    return out


def _patched_build_mapping_for_mode(context, obj, payload, settings):
    global _PREV_BUILD_MAPPING
    mapping, mirror_mode, projected_mode = _PREV_BUILD_MAPPING(context, obj, payload, settings)
    zs = _settings(context)
    if zs is None:
        return mapping, mirror_mode, projected_mode
    return _apply_mapping_edits(mapping, payload, zs), mirror_mode, projected_mode


def _line_cache_key(context, obj, payload, settings, zs):
    return (
        core._preview_signature(context, obj, payload, settings),
        getattr(extension, '_preview_cache_key', lambda *a, **k: None)(context, obj, payload, settings, getattr(context.scene, 'vscpx_settings', None)),
        _mapping_edit_signature(zs),
    )


def _build_current_line_data(context):
    zs = _settings(context)
    obj = core._get_active_mesh(context)
    payload = _payload(context)
    if zs is None or obj is None or payload is None or context.mode != 'EDIT_MESH':
        return []
    settings = context.scene.vscp_settings
    key = _line_cache_key(context, obj, payload, settings, zs)
    cached = _LINE_CACHE.get('entry')
    if cached and cached.get('key') == key:
        return cached.get('lines', [])
    # Display keeps excluded candidates pickable; paste/validation still use
    # the filtered mapping returned by _patched_build_mapping_for_mode.
    builder = _PREV_BUILD_MAPPING or core._build_mapping_for_mode
    mapping, _mirror_mode, _projected = builder(context, obj, payload, settings)
    mapping = _apply_mapping_edits(mapping, payload, zs, include_excluded=True)
    conf_map = {}
    try:
        conf_map, _unused = extension._confidence_for_mapping(obj, mapping, payload, settings)
    except Exception:
        pass
    lines = []
    for tgt, src in mapping.items():
        if not isinstance(src, dict):
            continue
        pred = core._list_to_vec(src.get('projected_local', src.get('co_local', (0.0, 0.0, 0.0))))
        pred_w = obj.matrix_world @ pred
        src_idx = int(src.get('index', -1))
        if isinstance(tgt, int) and 0 <= tgt < len(obj.data.vertices):
            tgt_w = obj.matrix_world @ obj.data.vertices[tgt].co
            conf = float(conf_map.get(tgt, 1.0 if settings.paste_mode in {'EXACT', 'MIRROR_EXACT'} else 0.5))
            lines.append({
                'source_index': src_idx,
                'target_index': int(tgt),
                'pred_world': pred_w,
                'target_world': tgt_w,
                'confidence': conf,
                'is_fixed': int(src_idx) in _fixed_pair_dict(zs) and _fixed_pair_dict(zs).get(int(src_idx)) == int(tgt),
                'is_excluded': int(tgt) in _excluded_target_set(zs),
            })
        elif 'project_weights' in src:
            for tgt_idx, weight in src['project_weights']:
                if 0 <= int(tgt_idx) < len(obj.data.vertices):
                    tgt_w = obj.matrix_world @ obj.data.vertices[int(tgt_idx)].co
                    conf = float(conf_map.get(int(tgt_idx), max(0.0, min(1.0, float(weight)))))
                    lines.append({
                        'source_index': src_idx,
                        'target_index': int(tgt_idx),
                        'pred_world': pred_w,
                        'target_world': tgt_w,
                        'confidence': conf,
                        'is_fixed': False,
                        'is_excluded': int(tgt_idx) in _excluded_target_set(zs),
                    })
    _LINE_CACHE.clear()
    _LINE_CACHE['entry'] = {'key': key, 'lines': lines}
    return lines


def _point_segment_distance_2d(p, a, b):
    ab = b - a
    denom = ab.length_squared
    if denom <= 1e-20:
        return (p - a).length
    t = max(0.0, min(1.0, (p - a).dot(ab) / denom))
    q = a + ab * t
    return (p - q).length


def _pick_line_by_event(context, event):
    obj = core._get_active_mesh(context)
    if obj is None or context.area is None or context.area.type != 'VIEW_3D':
        return None
    region = context.region
    rv3d = context.space_data.region_3d
    zs = _settings(context)
    radius = zs.pick_line_radius if zs else 18
    mouse = Vector((event.mouse_region_x, event.mouse_region_y))
    best = None
    best_d = None
    for item in _build_current_line_data(context):
        a2 = view3d_utils.location_3d_to_region_2d(region, rv3d, item['pred_world'])
        b2 = view3d_utils.location_3d_to_region_2d(region, rv3d, item['target_world'])
        if a2 is None or b2 is None:
            continue
        d = _point_segment_distance_2d(mouse, Vector(a2), Vector(b2))
        if d <= radius and (best is None or d < best_d):
            best = item
            best_d = d
    return best




def _pick_target_vertex_by_event(context, event):
    obj = core._get_active_mesh(context)
    if obj is None or context.area is None or context.area.type != 'VIEW_3D' or context.mode != 'EDIT_MESH':
        return None
    region = context.region
    rv3d = context.space_data.region_3d
    zs = _settings(context)
    radius = zs.pick_vertex_radius if zs else 18
    mouse = Vector((event.mouse_region_x, event.mouse_region_y))
    bm = core._bm_from_edit_object(obj)
    best_idx = None
    best_d = None
    active = getattr(bm.select_history, 'active', None)
    active_idx = int(active.index) if active and isinstance(active, bmesh.types.BMVert) else None
    for v in bm.verts:
        world_co = obj.matrix_world @ v.co
        co2d = view3d_utils.location_3d_to_region_2d(region, rv3d, world_co)
        if co2d is None:
            continue
        d = (mouse - Vector(co2d)).length
        if d > radius:
            continue
        if best_idx is None or d < best_d or (abs(d - best_d) < 1e-6 and active_idx is not None and int(v.index) == active_idx):
            best_idx = int(v.index)
            best_d = d
    return best_idx
def _set_selected_line(zs, item):
    if item is None:
        zs.has_selected_mapping = False
        zs.selected_source_index = -1
        zs.selected_target_index = -1
        zs.selected_confidence = 0.0
        zs.selected_label = ''
        return
    zs.has_selected_mapping = True
    zs.selected_source_index = int(item['source_index'])
    zs.selected_target_index = int(item['target_index'])
    zs.selected_confidence = float(item.get('confidence', 0.0))
    zs.selected_label = f"{zs.selected_source_index} -> {zs.selected_target_index} | {zs.selected_confidence:.3f}"



def _selected_pair_items(zs):
    return [(int(it.source_index), int(it.target_index)) for it in zs.selected_pairs]


def _has_selected_pair(zs, src, tgt):
    src = int(src)
    tgt = int(tgt)
    return any(int(it.source_index) == src and int(it.target_index) == tgt for it in zs.selected_pairs)


def _add_selected_pair(zs, src, tgt):
    src = int(src)
    tgt = int(tgt)
    if _has_selected_pair(zs, src, tgt):
        return False
    item = zs.selected_pairs.add()
    item.source_index = src
    item.target_index = tgt
    return True


def _remove_selected_pair(zs, src, tgt):
    src = int(src)
    tgt = int(tgt)
    removed = False
    for idx in reversed(range(len(zs.selected_pairs))):
        it = zs.selected_pairs[idx]
        if int(it.source_index) == src and int(it.target_index) == tgt:
            zs.selected_pairs.remove(idx)
            removed = True
    return removed


def _clear_selected_pairs(zs):
    zs.selected_pairs.clear()


def _toggle_selected_pair(zs, src, tgt):
    if _has_selected_pair(zs, src, tgt):
        _remove_selected_pair(zs, src, tgt)
        return False
    _add_selected_pair(zs, src, tgt)
    return True


def _multi_selected_count(zs):
    return len(zs.selected_pairs)


def _selected_target_vertices_for_batch(context, order_mode='INDEX'):
    obj = core._get_active_mesh(context)
    if obj is None or context.mode != 'EDIT_MESH':
        return []
    bm = core._bm_from_edit_object(obj)
    verts = [v for v in bm.verts if v.select]
    if order_mode == 'X':
        verts.sort(key=lambda v: (v.co.x, v.co.y, v.co.z, v.index))
    elif order_mode == 'Y':
        verts.sort(key=lambda v: (v.co.y, v.co.x, v.co.z, v.index))
    elif order_mode == 'Z':
        verts.sort(key=lambda v: (v.co.z, v.co.x, v.co.y, v.index))
    else:
        verts.sort(key=lambda v: v.index)
    return [int(v.index) for v in verts]


def _rebuild_lines_draw_snapshot(context=None):
    """Build mapping-line GPU batches outside the draw callback."""
    context = context or getattr(bpy, 'context', None)
    snapshot = _LINES_DRAW_SNAPSHOT
    if context is None:
        snapshot.clear()
        return False
    try:
        zs = _settings(context)
        if zs is None or not bool(zs.show_mapping_edit_overlay):
            snapshot.clear()
            return False
        obj = core._get_active_mesh(context)
        if obj is None or context.mode != 'EDIT_MESH':
            snapshot.clear()
            return False
        lines = _build_current_line_data(context)
        if not lines:
            snapshot.clear()
            return False

        selected = []
        multi_selected = []
        fixed = []
        excluded = []
        fixed_points = []
        excluded_points = []
        multi_points = []
        relink_points = []
        selected_pairs = set(_selected_pair_items(zs))
        selected_target = None
        for item in lines:
            segment = (item['pred_world'], item['target_world'])
            pair = (int(item['source_index']), int(item['target_index']))
            if (
                item['source_index'] == zs.selected_source_index
                and item['target_index'] == zs.selected_target_index
                and zs.has_selected_mapping
            ):
                selected.extend(segment)
                selected_target = item['target_world']
            if pair in selected_pairs:
                multi_selected.extend(segment)
                multi_points.append(item['target_world'])
            elif item['is_fixed']:
                fixed.extend(segment)
                fixed_points.append(item['target_world'])
            elif item['is_excluded']:
                excluded.extend(segment)
                excluded_points.append(item['target_world'])

        relink_index = int(zs.relink_target_index)
        if 0 <= relink_index < len(obj.data.vertices):
            relink_points.append(obj.matrix_world @ obj.data.vertices[relink_index].co)

        shader = get_uniform_color_shader('3D')
        line_entries = []
        point_entries = []

        def add_line(coordinates, color, width):
            if coordinates:
                line_entries.append((
                    batch_for_shader(shader, 'LINES', {'pos': tuple(coordinates)}),
                    tuple(color),
                    float(width),
                ))

        def add_points(coordinates, color, size):
            if coordinates:
                point_entries.append((
                    batch_for_shader(shader, 'POINTS', {'pos': tuple(coordinates)}),
                    tuple(color),
                    float(size),
                ))

        add_line(fixed, zs.fixed_line_color, zs.overlay_line_width + 1.0)
        add_line(excluded, zs.excluded_line_color, zs.overlay_line_width + 1.0)
        add_line(multi_selected, zs.multi_selected_line_color, zs.overlay_line_width + 1.5)
        add_line(selected, zs.selected_line_color, zs.overlay_line_width + 2.0)
        add_points(fixed_points, zs.fixed_line_color, zs.overlay_point_size)
        add_points(excluded_points, zs.excluded_line_color, zs.overlay_point_size)
        add_points(multi_points, zs.multi_selected_line_color, zs.overlay_point_size + 1.0)
        add_points(relink_points, zs.relink_target_color, zs.overlay_point_size + 3.0)
        if selected_target is not None:
            add_points((selected_target,), zs.selected_line_color, zs.overlay_point_size + 2.0)

        snapshot.shader = shader
        snapshot.line_entries = tuple(line_entries)
        snapshot.point_entries = tuple(point_entries)
        snapshot.enabled = bool(line_entries or point_entries)
        return snapshot.enabled
    except Exception:
        snapshot.clear()
        return False


def _lines_draw_callback(snapshot):
    """Draw prebuilt line/point batches only; mapping and RNA stay outside Draw."""
    if snapshot is None or not snapshot.enabled or snapshot.shader is None:
        return
    shader = snapshot.shader
    try:
        gpu.state.blend_set('ALPHA')
        gpu.state.depth_test_set('NONE')
        for batch, color, width in snapshot.line_entries:
            gpu.state.line_width_set(width)
            shader.bind()
            shader.uniform_float('color', color)
            batch.draw(shader)
        for batch, color, size in snapshot.point_entries:
            gpu.state.point_size_set(size)
            shader.bind()
            shader.uniform_float('color', color)
            batch.draw(shader)
    except Exception:
        return
    finally:
        try:
            gpu.state.line_width_set(1.0)
        except Exception:
            pass
        try:
            gpu.state.point_size_set(1.0)
        except Exception:
            pass
        try:
            gpu.state.depth_test_set('LESS_EQUAL')
        except Exception:
            pass
        try:
            gpu.state.blend_set('NONE')
        except Exception:
            pass


def _line_distance_world(item):
    try:
        return float((item['target_world'] - item['pred_world']).length)
    except Exception:
        return 0.0


def _iter_filtered_line_candidates(context, zs):
    lines = list(_build_current_line_data(context))
    if not lines:
        return []
    out = []
    mode = zs.auto_select_scope
    fixed = _fixed_pair_dict(zs)
    excluded = _excluded_target_set(zs)
    selected = {(int(i.source_index), int(i.target_index)) for i in zs.selected_pairs}
    for item in lines:
        src = int(item.get('source_index', -1))
        tgt = int(item.get('target_index', -1))
        is_fixed = src in fixed and int(fixed.get(src, -999999)) == tgt
        is_excluded = tgt in excluded
        is_selected = (src, tgt) in selected
        if mode == 'LOW_CONF' and float(item.get('confidence', 1.0)) > zs.auto_select_confidence_max:
            continue
        if mode == 'LONG_DIST' and _line_distance_world(item) < zs.auto_select_distance_min:
            continue
        if mode == 'BOTH':
            if float(item.get('confidence', 1.0)) > zs.auto_select_confidence_max:
                continue
            if _line_distance_world(item) < zs.auto_select_distance_min:
                continue
        if zs.auto_select_include_fixed is False and is_fixed:
            continue
        if zs.auto_select_include_excluded is False and is_excluded:
            continue
        if zs.auto_select_include_selected is False and is_selected:
            continue
        out.append(item)
    sort_mode = zs.auto_select_sort
    reverse = False
    if sort_mode == 'CONF_ASC':
        key = lambda it: float(it.get('confidence', 1.0))
    elif sort_mode == 'CONF_DESC':
        key = lambda it: float(it.get('confidence', 1.0))
        reverse = True
    elif sort_mode == 'DIST_ASC':
        key = _line_distance_world
    else:
        key = _line_distance_world
        reverse = True
    out.sort(key=key, reverse=reverse)
    limit = int(zs.auto_select_limit)
    if limit > 0:
        out = out[:limit]
    return out


def _apply_auto_selected_lines(context, zs, replace=False):
    items = _iter_filtered_line_candidates(context, zs)
    if replace:
        zs.selected_pairs.clear()
    added = 0
    for item in items:
        if _add_selected_pair(zs, int(item['source_index']), int(item['target_index'])):
            added += 1
    if items:
        _set_selected_line(zs, items[0])
    _invalidate_all_caches()
    return items, added


class VSCPZ_FixedPair(bpy.types.PropertyGroup):
    source_index: IntProperty(name='Copy Source', default=-1, description='Adjust Copy Source. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')
    target_index: IntProperty(name='Paste Target', default=-1, description='Adjust Paste Target. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')


class VSCPZ_ExcludedTarget(bpy.types.PropertyGroup):
    target_index: IntProperty(name='Excluded Target', default=-1, description='Adjust Excluded Target. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')


class VSCPZ_SelectedPair(bpy.types.PropertyGroup):
    source_index: IntProperty(name='Copy Source', default=-1, description='Adjust Copy Source. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')
    target_index: IntProperty(name='Paste Target', default=-1, description='Adjust Paste Target. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')


class VSCPZ_Settings(bpy.types.PropertyGroup):
    show_mapping_edit_overlay: BoolProperty(name='Per-item Edit Overlay', description='Overlay pinned/excluded/selected mapping lines in the 3D View only when you need manual line editing. Disabled by default so the viewport callback stays off during normal work.', default=False, update=_update_mapping_overlay_toggle)
    pick_line_radius: IntProperty(name='Line Pick Radius (px)', description='Pick radius for mapping lines in the 3D View (px).', default=18, min=4, max=128)
    pick_vertex_radius: IntProperty(name='Vertex Pick Radius (px)', description='Pick radius for the replacement target vertex in the 3D View (px).', default=16, min=4, max=128)
    overlay_line_width: FloatProperty(name='Edit Line Width', default=2.0, min=1.0, soft_max=8.0, update=_update_mapping_overlay_visuals, description='Adjust Edit Line Width. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')
    overlay_point_size: FloatProperty(name='Edit Point Size', default=8.0, min=2.0, soft_max=20.0, update=_update_mapping_overlay_visuals, description='Adjust Edit Point Size. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')
    selected_line_color: bpy.props.FloatVectorProperty(name='Select', subtype='COLOR', size=4, min=0.0, max=1.0, default=(1.0, 1.0, 0.2, 1.0), update=_update_mapping_overlay_visuals, description='Vector or color setting for Select. Use this to control color, direction, or other multi-value data used by the interface or tool.')
    fixed_line_color: bpy.props.FloatVectorProperty(name='Pinned Line Color', subtype='COLOR', size=4, min=0.0, max=1.0, default=(0.2, 1.0, 0.45, 0.95), update=_update_mapping_overlay_visuals, description='Vector or color setting for Pinned Line Color. Use this to control color, direction, or other multi-value data used by the interface or tool.')
    excluded_line_color: bpy.props.FloatVectorProperty(name='Excluded Line Color', subtype='COLOR', size=4, min=0.0, max=1.0, default=(1.0, 0.25, 0.25, 0.95), update=_update_mapping_overlay_visuals, description='Vector or color setting for Excluded Line Color. Use this to control color, direction, or other multi-value data used by the interface or tool.')
    multi_selected_line_color: bpy.props.FloatVectorProperty(name='Multi-Selected Line Color', subtype='COLOR', size=4, min=0.0, max=1.0, default=(0.2, 0.85, 1.0, 0.95), update=_update_mapping_overlay_visuals, description='Vector or color setting for Select. Use this to control color, direction, or other multi-value data used by the interface or tool.')
    relink_target_color: bpy.props.FloatVectorProperty(name='Replacement Target Color', subtype='COLOR', size=4, min=0.0, max=1.0, default=(0.15, 0.7, 1.0, 0.95), update=_update_mapping_overlay_visuals, description='Vector or color setting for Replacement Target Color. Use this to control color, direction, or other multi-value data used by the interface or tool.')
    selected_source_index: IntProperty(name='Select Copy Source', default=-1, description='Adjust Select Copy Source. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')
    selected_target_index: IntProperty(name='Select Paste Target', default=-1, description='Adjust Select Paste Target. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')
    selected_confidence: FloatProperty(name='Select', default=0.0, description='Adjust Select. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')
    selected_label: StringProperty(name='Select Show', default='', description='Text field for Select Show. Use it to enter a name, filter, note, identifier, or other text used by the tool.')
    has_selected_mapping: BoolProperty(name='Select', default=False, description='Enable or disable Select. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.')
    relink_target_index: IntProperty(name='Replacement Target Vertex', description='Target vertex index for manual relink. If -1, use the currently selected vertex in Edit Mode.', default=-1, update=_update_mapping_overlay_visuals)
    batch_relink_order: bpy.props.EnumProperty(
        name='Batch Relink Order',
        description='Order for pairing multi-selected mapping lines with selected vertices in Edit Mode.',
        items=[('INDEX', 'Index Order', ''), ('X', 'X Order', ''), ('Y', 'Y Order', ''), ('Z', 'Z Order', '')],
        default='INDEX',
    )
    auto_select_scope: bpy.props.EnumProperty(
        name='Auto-extract Conditions',
        description='Extraction conditions for auto-adding mapping lines to multi-selection.',
        items=[
            ('LOW_CONF', 'Low Confidence', 'Extract mapping lines with confidence at or below the threshold.'),
            ('LONG_DIST', 'Long Distance', 'Extract mapping lines whose distance between predicted position and target vertex exceeds the threshold.'),
            ('BOTH', 'Low confidence + long distance', 'Extract mapping lines that are both low-confidence and long-distance.'),
            ('ALL', 'All Mapping Lines', 'Use all current mapping lines as extraction targets.'),
        ],
        default='LOW_CONF',
    )
    auto_select_confidence_max: FloatProperty(name='Max Confidence', description='Confidence at or below this is treated as low confidence.', default=0.35, min=0.0, max=1.0)
    auto_select_distance_min: FloatProperty(name='Min Distance', description='Mappings with world-space distance above this are treated as long-distance.', default=0.02, min=0.0, soft_max=10.0)
    auto_select_limit: IntProperty(name='Extract Limit', description='0 means no limit.', default=0, min=0, soft_max=100000)
    auto_select_include_fixed: BoolProperty(name='Include pinned', description='Include pinned mapping lines as auto-extract targets.', default=False)
    auto_select_include_excluded: BoolProperty(name='Include excluded', description='Include excluded mapping lines as auto-extract targets.', default=False)
    auto_select_include_selected: BoolProperty(name='Include Multi-Selected', description='Include already multi-selected mapping lines as extraction targets.', default=False)
    auto_select_sort: bpy.props.EnumProperty(
        name='Extract Sort Order',
        description='Order used when adding auto-extracted items to multi-selection.',
        items=[
            ('CONF_ASC', 'Confidence Ascending', 'Sort mappings by lower confidence first.'),
            ('CONF_DESC', 'Confidence Descending', 'Sort mappings by higher confidence first.'),
            ('DIST_DESC', 'Distance Descending', 'Sort mappings by larger distance first.'),
            ('DIST_ASC', 'Distance Ascending', 'Sort mappings by smaller distance first.'),
        ],
        default='CONF_ASC',
    )
    range_select_close_loop: BoolProperty(name='Auto-close Lasso', description='Auto-close the lasso by connecting to the first point on finish.', default=True)
    range_select_min_step: IntProperty(name='Min (px)', description='Minimum mouse movement to add a point while drawing a lasso.', default=10, min=2, max=128)
    fixed_pairs: CollectionProperty(type=VSCPZ_FixedPair, description='Collection for Fixed Pairs. The tool stores multiple items here, such as presets, reports, backups, or temporary entries.')
    excluded_targets: CollectionProperty(type=VSCPZ_ExcludedTarget, description='Collection for Excluded Targets. The tool stores multiple items here, such as presets, reports, backups, or temporary entries.')
    selected_pairs: CollectionProperty(type=VSCPZ_SelectedPair, description='Collection for Selected Pairs. The tool stores multiple items here, such as presets, reports, backups, or temporary entries.')


class VSCPZ_OT_pick_mapping_line(bpy.types.Operator):
    bl_idname = 'vscpz.pick_mapping_line'
    bl_label = '3D Select'
    bl_description = 'Click a mapping line in the 3D View to select it for per-item editing.'
    bl_options = {'UNDO'}
    action: StringProperty(default='SELECT', description='Text field for Action. Use it to enter a name, filter, note, identifier, or other text used by the tool.')

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D' and core._get_active_mesh(context) is not None

    def modal(self, context, event):
        zs = _settings(context)
        if event.type in {'RIGHTMOUSE', 'ESC'}:
            self.report({'INFO'}, 'Mapping line selection canceled.')
            return {'CANCELLED'}
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            item = _pick_line_by_event(context, event)
            if item is None:
                self.report({'WARNING'}, 'Could not pick a mapping line. Please click again.')
                return {'RUNNING_MODAL'}
            already_same = zs.has_selected_mapping and int(zs.selected_source_index) == int(item['source_index']) and int(zs.selected_target_index) == int(item['target_index'])
            _set_selected_line(zs, item)
            if self.action == 'EXCLUDE':
                if item['is_excluded'] or already_same:
                    _remove_exclusion_for_target(zs, zs.selected_target_index)
                    self.report({'INFO'}, f"Cleared exclusion: {zs.selected_label}")
                else:
                    _exclude_selected(zs)
                    self.report({'INFO'}, f"Exclude mapping: {zs.selected_label}")
            elif self.action == 'FIX':
                if item['is_fixed'] or already_same:
                    _remove_fix_for_source(zs, zs.selected_source_index)
                    self.report({'INFO'}, f"Unpinned: {zs.selected_label}")
                else:
                    _fix_selected(zs)
                    self.report({'INFO'}, f"Pin mapping: {zs.selected_label}")
            else:
                if self.action == 'ADD_SELECT':
                    added = _toggle_selected_pair(zs, item['source_index'], item['target_index'])
                    if added:
                        self.report({'INFO'}, f"Select to Add : {zs.selected_label}")
                    else:
                        self.report({'INFO'}, 'Removed from multi-selection.')
                elif already_same:
                    _set_selected_line(zs, None)
                    self.report({'INFO'}, 'Mapping selection cleared.')
                else:
                    self.report({'INFO'}, f"Select : {zs.selected_label}")
            _invalidate_all_caches()
            return {'FINISHED'}
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        context.window_manager.modal_handler_add(self)
        if self.action == 'EXCLUDE':
            self.report({'INFO'}, 'Click the mapping line you want to exclude.')
        elif self.action == 'FIX':
            self.report({'INFO'}, 'Click the mapping line you want to pin.')
        elif self.action == 'ADD_SELECT':
            self.report({'INFO'}, 'Click mapping lines to add to multi-selection. Click again to remove.')
        else:
            self.report({'INFO'}, 'Click the mapping line you want to select.')
        return {'RUNNING_MODAL'}


def _exclude_selected(zs):
    if not zs.has_selected_mapping or zs.selected_target_index < 0:
        return False
    tgt = int(zs.selected_target_index)
    for item in zs.excluded_targets:
        if int(item.target_index) == tgt:
            return True
    new_item = zs.excluded_targets.add()
    new_item.target_index = tgt
    # if same mapping is fixed, remove the fix
    to_remove = [i for i, it in enumerate(zs.fixed_pairs) if int(it.target_index) == tgt]
    for idx in reversed(to_remove):
        zs.fixed_pairs.remove(idx)
    return True


def _fix_selected(zs):
    if not zs.has_selected_mapping or zs.selected_source_index < 0 or zs.selected_target_index < 0:
        return False
    src = int(zs.selected_source_index)
    tgt = int(zs.selected_target_index)
    # remove exclusion on this target
    to_remove = [i for i, it in enumerate(zs.excluded_targets) if int(it.target_index) == tgt]
    for idx in reversed(to_remove):
        zs.excluded_targets.remove(idx)
    # replace same source or same target
    to_remove = [i for i, it in enumerate(zs.fixed_pairs) if int(it.source_index) == src or int(it.target_index) == tgt]
    for idx in reversed(to_remove):
        zs.fixed_pairs.remove(idx)
    item = zs.fixed_pairs.add()
    item.source_index = src
    item.target_index = tgt
    return True


def _remove_fix_for_source(zs, src):
    removed = False
    for idx in reversed(range(len(zs.fixed_pairs))):
        if int(zs.fixed_pairs[idx].source_index) == int(src):
            zs.fixed_pairs.remove(idx)
            removed = True
    return removed


def _remove_exclusion_for_target(zs, tgt):
    removed = False
    for idx in reversed(range(len(zs.excluded_targets))):
        if int(zs.excluded_targets[idx].target_index) == int(tgt):
            zs.excluded_targets.remove(idx)
            removed = True
    return removed


def _selected_target_vertex_index(context):
    obj = core._get_active_mesh(context)
    if obj is None or context.mode != 'EDIT_MESH':
        return None
    bm = core._bm_from_edit_object(obj)
    selected = [v.index for v in bm.verts if v.select]
    if not selected:
        return None
    active = getattr(bm.select_history, 'active', None)
    if active and isinstance(active, bmesh.types.BMVert) and active.select:
        return int(active.index)
    return int(selected[-1])


class VSCPZ_OT_exclude_selected_mapping(bpy.types.Operator):
    bl_idname = 'vscpz.exclude_selected_mapping'
    bl_label = 'Exclude Selected Line'
    bl_description = 'Exclude the currently selected mapping line from future auto-matching.'
    bl_options = {'UNDO'}

    def execute(self, context):
        zs = _settings(context)
        if not _exclude_selected(zs):
            self.report({'ERROR'}, 'No excludable mapping is selected.')
            return {'CANCELLED'}
        _invalidate_all_caches()
        self.report({'INFO'}, f'Excluded: {zs.selected_label}')
        return {'FINISHED'}


class VSCPZ_OT_fix_selected_mapping(bpy.types.Operator):
    bl_idname = 'vscpz.fix_selected_mapping'
    bl_label = 'Pin Selected Line'
    bl_description = 'Pin the currently selected mapping line so it remains after recalculation.'
    bl_options = {'UNDO'}

    def execute(self, context):
        zs = _settings(context)
        if not _fix_selected(zs):
            self.report({'ERROR'}, 'No pinnable mapping is selected.')
            return {'CANCELLED'}
        _invalidate_all_caches()
        self.report({'INFO'}, f'Pinned: {zs.selected_label}')
        return {'FINISHED'}


class VSCPZ_OT_remove_selected_fix(bpy.types.Operator):
    bl_idname = 'vscpz.remove_selected_fix'
    bl_label = 'Unpin Selected Line'
    bl_description = 'Clear pin for the currently selected mapping.'
    bl_options = {'UNDO'}

    def execute(self, context):
        zs = _settings(context)
        if not zs.has_selected_mapping:
            self.report({'ERROR'}, 'No mapping is selected.')
            return {'CANCELLED'}
        src = int(zs.selected_source_index)
        removed = False
        for idx in reversed(range(len(zs.fixed_pairs))):
            if int(zs.fixed_pairs[idx].source_index) == src:
                zs.fixed_pairs.remove(idx)
                removed = True
        if not removed:
            self.report({'WARNING'}, 'The selected mapping is not pinned.')
            return {'CANCELLED'}
        _invalidate_all_caches()
        self.report({'INFO'}, 'Pin cleared.')
        return {'FINISHED'}


class VSCPZ_OT_remove_selected_exclusion(bpy.types.Operator):
    bl_idname = 'vscpz.remove_selected_exclusion'
    bl_label = 'Clear Line Exclusion'
    bl_description = 'Clear exclusion for the currently selected mapping line.'
    bl_options = {'UNDO'}

    def execute(self, context):
        zs = _settings(context)
        if not zs.has_selected_mapping:
            self.report({'ERROR'}, 'No mapping is selected.')
            return {'CANCELLED'}
        tgt = int(zs.selected_target_index)
        removed = False
        for idx in reversed(range(len(zs.excluded_targets))):
            if int(zs.excluded_targets[idx].target_index) == tgt:
                zs.excluded_targets.remove(idx)
                removed = True
        if not removed:
            self.report({'WARNING'}, 'The selected mapping is not excluded.')
            return {'CANCELLED'}
        _invalidate_all_caches()
        self.report({'INFO'}, 'Exclusion cleared.')
        return {'FINISHED'}


class VSCPZ_OT_clear_mapping_edits(bpy.types.Operator):
    bl_idname = 'vscpz.clear_mapping_edits'
    bl_label = 'Clear All Per-item Edits'
    bl_description = 'Clear all pinned and excluded mappings.'
    bl_options = {'UNDO'}

    def execute(self, context):
        zs = _settings(context)
        zs.fixed_pairs.clear()
        zs.excluded_targets.clear()
        _set_selected_line(zs, None)
        _invalidate_all_caches()
        self.report({'INFO'}, 'Cleared all pins and exclusions.')
        return {'FINISHED'}


class VSCPZ_OT_capture_selected_target_vertex(bpy.types.Operator):
    bl_idname = 'vscpz.capture_selected_target_vertex'
    bl_label = 'Selected Verts'
    bl_description = 'Pick the currently selected vertex in Edit Mode as the manual relink target. If an active vertex exists, it is preferred.'
    bl_options = {'UNDO'}

    def execute(self, context):
        zs = _settings(context)
        idx = _selected_target_vertex_index(context)
        if idx is None:
            self.report({'ERROR'}, 'No vertex is selected to use as replacement target.')
            return {'CANCELLED'}
        zs.relink_target_index = int(idx)
        _tag_redraw()
        self.report({'INFO'}, f'Picked replacement target vertex: {idx}')
        return {'FINISHED'}


class VSCPZ_OT_relink_selected_mapping(bpy.types.Operator):
    bl_idname = 'vscpz.relink_selected_mapping'
    bl_label = 'Relink Selected Line'
    bl_description = 'Manually replace and pin the selected source mapping to the specified target vertex. If target is -1, use the currently selected vertex in Edit Mode.'
    bl_options = {'UNDO'}

    def execute(self, context):
        zs = _settings(context)
        if zs is None or not zs.has_selected_mapping or zs.selected_source_index < 0:
            self.report({'ERROR'}, 'No mapping line is selected for replacement.')
            return {'CANCELLED'}
        tgt = int(zs.relink_target_index)
        if tgt < 0:
            picked = _selected_target_vertex_index(context)
            if picked is None:
                self.report({'ERROR'}, 'No replacement target vertex specified.')
                return {'CANCELLED'}
            tgt = int(picked)
        obj = core._get_active_mesh(context)
        if obj is None or tgt < 0 or tgt >= len(obj.data.vertices):
            self.report({'ERROR'}, 'Replacement target vertex index is invalid.')
            return {'CANCELLED'}
        zs.selected_target_index = tgt
        if not _fix_selected(zs):
            self.report({'ERROR'}, 'Failed to replace mapping.')
            return {'CANCELLED'}
        zs.relink_target_index = tgt
        _invalidate_all_caches()
        self.report({'INFO'}, f'Replaced and pinned mapping: {zs.selected_source_index} -> {tgt}')
        return {'FINISHED'}


class VSCPZ_OT_clear_relink_target(bpy.types.Operator):
    bl_idname = 'vscpz.clear_relink_target'
    bl_label = 'Clear Replacement Target'
    bl_description = 'Clear the replacement target vertex index for manual relink.'
    bl_options = {'UNDO'}

    def execute(self, context):
        zs = _settings(context)
        zs.relink_target_index = -1
        self.report({'INFO'}, 'Replacement target vertex cleared.')
        return {'FINISHED'}




class VSCPZ_OT_pick_relink_target_vertex(bpy.types.Operator):
    bl_idname = 'vscpz.pick_relink_target_vertex'
    bl_label = 'Pick Replacement Target Vertex in 3D View'
    bl_description = 'Click a vertex in the 3D View to pick it as the replacement target.'
    bl_options = {'UNDO'}
    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D' and core._get_active_mesh(context) is not None

    def modal(self, context, event):
        zs = _settings(context)
        if event.type in {'RIGHTMOUSE', 'ESC'}:
            self.report({'INFO'}, 'Canceled picking replacement target vertex.')
            return {'CANCELLED'}
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            idx = _pick_target_vertex_by_event(context, event)
            if idx is None:
                self.report({'WARNING'}, 'Could not pick a vertex. Please click again.')
                return {'RUNNING_MODAL'}
            zs.relink_target_index = int(idx)
            _tag_redraw()
            self.report({'INFO'}, f'Picked replacement target vertex: {idx}')
            return {'FINISHED'}
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        context.window_manager.modal_handler_add(self)
        self.report({'INFO'}, 'Click the vertex you want to use as the replacement target.')
        return {'RUNNING_MODAL'}


class VSCPZ_OT_pick_and_relink_selected_mapping(bpy.types.Operator):
    bl_idname = 'vscpz.pick_and_relink_selected_mapping'
    bl_label = 'Relink by Clicking Target in 3D View'
    bl_description = 'Keep the source of the selected mapping line, replace the target with the vertex you click in the 3D View, and pin it.'
    bl_options = {'UNDO'}
    @classmethod
    def poll(cls, context):
        zs = _settings(context)
        return context.area is not None and context.area.type == 'VIEW_3D' and core._get_active_mesh(context) is not None and zs is not None and zs.has_selected_mapping

    def modal(self, context, event):
        zs = _settings(context)
        if event.type in {'RIGHTMOUSE', 'ESC'}:
            self.report({'INFO'}, 'One-step relink canceled.')
            return {'CANCELLED'}
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            idx = _pick_target_vertex_by_event(context, event)
            if idx is None:
                self.report({'WARNING'}, 'Could not pick the replacement target vertex. Please click again.')
                return {'RUNNING_MODAL'}
            obj = core._get_active_mesh(context)
            if obj is None or idx < 0 or idx >= len(obj.data.vertices):
                self.report({'ERROR'}, 'Replacement target vertex index is invalid.')
                return {'CANCELLED'}
            zs.relink_target_index = int(idx)
            zs.selected_target_index = int(idx)
            if not _fix_selected(zs):
                self.report({'ERROR'}, 'Failed to replace mapping.')
                return {'CANCELLED'}
            _invalidate_all_caches()
            self.report({'INFO'}, f'Replaced and pinned mapping: {zs.selected_source_index} -> {idx}')
            return {'FINISHED'}
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        context.window_manager.modal_handler_add(self)
        self.report({'INFO'}, 'Click the vertex you want to use as the replacement target.')
        return {'RUNNING_MODAL'}



class VSCPZ_OT_clear_selected_mapping_list(bpy.types.Operator):
    bl_idname = 'vscpz.clear_selected_mapping_list'
    bl_label = 'Clear Multi-Selection'
    bl_description = 'Clear the multi-selection list.'
    bl_options = {'UNDO'}

    def execute(self, context):
        zs = _settings(context)
        count = len(zs.selected_pairs)
        zs.selected_pairs.clear()
        _invalidate_all_caches()
        self.report({'INFO'}, f'Select : {count}')
        return {'FINISHED'}


class VSCPZ_OT_add_current_to_selected_list(bpy.types.Operator):
    bl_idname = 'vscpz.add_current_to_selected_list'
    bl_label = 'Current Select to Add'
    bl_description = 'Add the currently selected mapping line to multi-selection.'
    bl_options = {'UNDO'}

    def execute(self, context):
        zs = _settings(context)
        if not zs.has_selected_mapping:
            self.report({'ERROR'}, 'No mapping line is currently selected.')
            return {'CANCELLED'}
        added = _add_selected_pair(zs, zs.selected_source_index, zs.selected_target_index)
        _invalidate_all_caches()
        self.report({'INFO'}, 'Added to multi-selection.' if added else 'Already added to multi-selection.')
        return {'FINISHED'}


class VSCPZ_OT_batch_fix_selected_list(bpy.types.Operator):
    bl_idname = 'vscpz.batch_fix_selected_list'
    bl_label = 'Pin Multi-Selected'
    bl_description = 'Pin all multi-selected mapping lines.'
    bl_options = {'UNDO'}

    def execute(self, context):
        zs = _settings(context)
        pairs = _selected_pair_items(zs)
        if not pairs:
            self.report({'ERROR'}, 'No mapping lines are multi-selected.')
            return {'CANCELLED'}
        count = 0
        for src, tgt in pairs:
            zs.selected_source_index = int(src)
            zs.selected_target_index = int(tgt)
            if _fix_selected(zs):
                count += 1
        _invalidate_all_caches()
        self.report({'INFO'}, f'Pinned in batch: {count} items')
        return {'FINISHED'}


class VSCPZ_OT_batch_exclude_selected_list(bpy.types.Operator):
    bl_idname = 'vscpz.batch_exclude_selected_list'
    bl_label = 'Exclude Multi-Selected'
    bl_description = 'Exclude all multi-selected mapping lines.'
    bl_options = {'UNDO'}

    def execute(self, context):
        zs = _settings(context)
        pairs = _selected_pair_items(zs)
        if not pairs:
            self.report({'ERROR'}, 'No mapping lines are multi-selected.')
            return {'CANCELLED'}
        count = 0
        for src, tgt in pairs:
            zs.selected_source_index = int(src)
            zs.selected_target_index = int(tgt)
            zs.has_selected_mapping = True
            if _exclude_selected(zs):
                count += 1
        _invalidate_all_caches()
        self.report({'INFO'}, f'Excluded in batch: {count} items')
        return {'FINISHED'}


class VSCPZ_OT_batch_unfix_selected_list(bpy.types.Operator):
    bl_idname = 'vscpz.batch_unfix_selected_list'
    bl_label = 'Unpin Multi-Selected'
    bl_description = 'Clear pins for multi-selected source items.'
    bl_options = {'UNDO'}

    def execute(self, context):
        zs = _settings(context)
        pairs = _selected_pair_items(zs)
        if not pairs:
            self.report({'ERROR'}, 'No mapping lines are multi-selected.')
            return {'CANCELLED'}
        count = 0
        for src, _tgt in pairs:
            if _remove_fix_for_source(zs, src):
                count += 1
        _invalidate_all_caches()
        self.report({'INFO'}, f'Cleared pins in batch: {count} items')
        return {'FINISHED'}


class VSCPZ_OT_batch_unexclude_selected_list(bpy.types.Operator):
    bl_idname = 'vscpz.batch_unexclude_selected_list'
    bl_label = 'Clear Multi-Selected Exclusions'
    bl_description = 'Clear exclusions for multi-selected targets.'
    bl_options = {'UNDO'}

    def execute(self, context):
        zs = _settings(context)
        pairs = _selected_pair_items(zs)
        if not pairs:
            self.report({'ERROR'}, 'No mapping lines are multi-selected.')
            return {'CANCELLED'}
        count = 0
        for _src, tgt in pairs:
            if _remove_exclusion_for_target(zs, tgt):
                count += 1
        _invalidate_all_caches()
        self.report({'INFO'}, f'Cleared exclusions in batch: {count} items')
        return {'FINISHED'}


class VSCPZ_OT_batch_relink_selected_list(bpy.types.Operator):
    bl_idname = 'vscpz.batch_relink_selected_list'
    bl_label = 'Relink Multi-Selected'
    bl_description = 'For multi-selected mapping lines, replace targets in order with the vertices selected in Edit Mode, and pin.'
    bl_options = {'UNDO'}

    def execute(self, context):
        zs = _settings(context)
        pairs = _selected_pair_items(zs)
        if not pairs:
            self.report({'ERROR'}, 'No mapping lines are multi-selected.')
            return {'CANCELLED'}
        target_indices = _selected_target_vertices_for_batch(context, zs.batch_relink_order)
        if len(target_indices) < len(pairs):
            self.report({'ERROR'}, f'Not enough replacement target vertices. Required: {len(pairs)} / Current: {len(target_indices)}')
            return {'CANCELLED'}
        pairs_sorted = sorted(pairs, key=lambda it: it[0])
        count = 0
        for (src, _old_tgt), new_tgt in zip(pairs_sorted, target_indices):
            zs.selected_source_index = int(src)
            zs.selected_target_index = int(new_tgt)
            zs.has_selected_mapping = True
            if _fix_selected(zs):
                count += 1
        _invalidate_all_caches()
        self.report({'INFO'}, f'Batch relinked and pinned: {count} items')
        return {'FINISHED'}


class VSCPZ_OT_auto_select_mapping_lines(bpy.types.Operator):
    bl_idname = 'vscpz.auto_select_mapping_lines'
    bl_label = 'Auto-extract by Conditions'
    bl_description = 'Auto-add mapping lines that match confidence/distance conditions to multi-selection.'
    bl_options = {'UNDO'}

    replace: BoolProperty(name='Replace', default=False, description='Enable or disable Replace. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.')

    def execute(self, context):
        zs = _settings(context)
        items, added = _apply_auto_selected_lines(context, zs, replace=self.replace)
        if not items:
            self.report({'WARNING'}, 'No mapping lines matched the conditions.')
            return {'CANCELLED'}
        self.report({'INFO'}, f'Auto-extract: {len(items)} items / Added to multi-selection: {added} items')
        return {'FINISHED'}


class VSCPZ_OT_select_all_fixed_pairs(bpy.types.Operator):
    bl_idname = 'vscpz.select_all_fixed_pairs'
    bl_label = 'Extract pinned'
    bl_description = 'Add pinned mapping lines to multi-selection.'
    bl_options = {'UNDO'}

    replace: BoolProperty(name='Replace', default=False, description='Enable or disable Replace. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.')

    def execute(self, context):
        zs = _settings(context)
        if self.replace:
            zs.selected_pairs.clear()
        count = 0
        for item in zs.fixed_pairs:
            if _add_selected_pair(zs, int(item.source_index), int(item.target_index)):
                count += 1
        _invalidate_all_caches()
        self.report({'INFO'}, f'Select to Add : {count}')
        return {'FINISHED'}


class VSCPZ_OT_select_all_excluded_pairs(bpy.types.Operator):
    bl_idname = 'vscpz.select_all_excluded_pairs'
    bl_label = 'Extract excluded'
    bl_description = 'Add mapping lines that use excluded targets to multi-selection.'
    bl_options = {'UNDO'}

    replace: BoolProperty(name='Replace', default=False, description='Enable or disable Replace. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.')

    def execute(self, context):
        zs = _settings(context)
        if self.replace:
            zs.selected_pairs.clear()
        excluded = _excluded_target_set(zs)
        count = 0
        picked = None
        for item in _build_current_line_data(context):
            if int(item['target_index']) in excluded:
                if _add_selected_pair(zs, int(item['source_index']), int(item['target_index'])):
                    count += 1
                if picked is None:
                    picked = item
        if picked is not None:
            _set_selected_line(zs, picked)
        _invalidate_all_caches()
        if count == 0:
            self.report({'WARNING'}, 'No excluded mapping lines were found.')
            return {'CANCELLED'}
        self.report({'INFO'}, f'Select to Add : {count}')
        return {'FINISHED'}



def _segment_intersects_segment_2d(a, b, c, d):
    def cross(u, v):
        return u.x * v.y - u.y * v.x
    r = b - a
    s = d - c
    denom = cross(r, s)
    qp = c - a
    if abs(denom) < 1e-20:
        # 平Row: 端点近接のみ簡易判定
        return ((a - c).length < 1e-6 or (a - d).length < 1e-6 or (b - c).length < 1e-6 or (b - d).length < 1e-6)
    t = cross(qp, s) / denom
    u = cross(qp, r) / denom
    return 0.0 <= t <= 1.0 and 0.0 <= u <= 1.0


def _segment_intersects_rect_2d(a, b, xmin, ymin, xmax, ymax):
    if xmin <= a.x <= xmax and ymin <= a.y <= ymax:
        return True
    if xmin <= b.x <= xmax and ymin <= b.y <= ymax:
        return True
    rect = [
        (Vector((xmin, ymin)), Vector((xmax, ymin))),
        (Vector((xmax, ymin)), Vector((xmax, ymax))),
        (Vector((xmax, ymax)), Vector((xmin, ymax))),
        (Vector((xmin, ymax)), Vector((xmin, ymin))),
    ]
    for c, d in rect:
        if _segment_intersects_segment_2d(a, b, c, d):
            return True
    return False


def _point_in_polygon_2d(p, poly):
    inside = False
    n = len(poly)
    if n < 3:
        return False
    j = n - 1
    for i in range(n):
        pi = poly[i]
        pj = poly[j]
        cond = ((pi.y > p.y) != (pj.y > p.y))
        if cond:
            x = (pj.x - pi.x) * (p.y - pi.y) / ((pj.y - pi.y) if abs(pj.y - pi.y) > 1e-20 else 1e-20) + pi.x
            if p.x < x:
                inside = not inside
        j = i
    return inside


def _segment_intersects_polygon_2d(a, b, poly):
    if _point_in_polygon_2d(a, poly) or _point_in_polygon_2d(b, poly):
        return True
    if len(poly) < 2:
        return False
    rng = range(len(poly))
    for i in rng:
        c = poly[i]
        d = poly[(i + 1) % len(poly)]
        if _segment_intersects_segment_2d(a, b, c, d):
            return True
    return False


def _screen_line_points(context, item):
    region = context.region
    rv3d = context.space_data.region_3d
    a2 = view3d_utils.location_3d_to_region_2d(region, rv3d, item['pred_world'])
    b2 = view3d_utils.location_3d_to_region_2d(region, rv3d, item['target_world'])
    if a2 is None or b2 is None:
        return None, None
    return Vector(a2), Vector(b2)


def _collect_lines_in_box(context, x0, y0, x1, y1):
    xmin, xmax = sorted((float(x0), float(x1)))
    ymin, ymax = sorted((float(y0), float(y1)))
    out = []
    for item in _build_current_line_data(context):
        a2, b2 = _screen_line_points(context, item)
        if a2 is None or b2 is None:
            continue
        if _segment_intersects_rect_2d(a2, b2, xmin, ymin, xmax, ymax):
            out.append(item)
    return out


def _collect_lines_in_lasso(context, points):
    poly = [Vector((float(x), float(y))) for x, y in points]
    if len(poly) < 3:
        return []
    out = []
    for item in _build_current_line_data(context):
        a2, b2 = _screen_line_points(context, item)
        if a2 is None or b2 is None:
            continue
        if _segment_intersects_polygon_2d(a2, b2, poly):
            out.append(item)
    return out


def _apply_items_action(zs, items, action, replace=False):
    if replace:
        zs.selected_pairs.clear()
    count = 0
    first = items[0] if items else None
    for item in items:
        src = int(item['source_index'])
        tgt = int(item['target_index'])
        if action in {'SELECT', 'ADD_SELECT'}:
            if _add_selected_pair(zs, src, tgt):
                count += 1
        elif action == 'EXCLUDE':
            if not any(int(it.target_index) == tgt for it in zs.excluded_targets):
                ex = zs.excluded_targets.add()
                ex.target_index = tgt
                count += 1
            # 同じターゲットのPinがあれば外す
            for idx in reversed(range(len(zs.fixed_pairs))):
                if int(zs.fixed_pairs[idx].target_index) == tgt:
                    zs.fixed_pairs.remove(idx)
        elif action == 'FIX':
            # 同じ source / target は入れ替え
            for idx in reversed(range(len(zs.excluded_targets))):
                if int(zs.excluded_targets[idx].target_index) == tgt:
                    zs.excluded_targets.remove(idx)
            for idx in reversed(range(len(zs.fixed_pairs))):
                if int(zs.fixed_pairs[idx].source_index) == src or int(zs.fixed_pairs[idx].target_index) == tgt:
                    zs.fixed_pairs.remove(idx)
            fp = zs.fixed_pairs.add()
            fp.source_index = src
            fp.target_index = tgt
            count += 1
    if first is not None:
        _set_selected_line(zs, first)
    _invalidate_all_caches()
    return count


class _VSCPZ_RangePickBase:
    action: StringProperty(default='ADD_SELECT', description='Text field for Action. Use it to enter a name, filter, note, identifier, or other text used by the tool.')

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D' and core._get_active_mesh(context) is not None

    def _finish_apply(self, context, items, replace=False):
        zs = _settings(context)
        count = _apply_items_action(zs, items, self.action, replace=replace)
        if count <= 0 and not items:
            self.report({'WARNING'}, 'No mapping lines found within the region.')
            return {'CANCELLED'}
        mode_name = {'ADD_SELECT': 'Select', 'SELECT': 'Select', 'EXCLUDE': 'Exclude', 'FIX': 'Pin'}.get(self.action, self.action)
        self.report({'INFO'}, f'{mode_name}: {len(items)}')
        return {'FINISHED'}


class VSCPZ_OT_box_select_mapping_lines(_VSCPZ_RangePickBase, bpy.types.Operator):
    bl_idname = 'vscpz.box_select_mapping_lines'
    bl_label = 'Add by Rectangle'
    bl_description = 'Use a rectangle drag in the 3D View to select/pin/exclude mapping lines in the region.'
    bl_options = {'UNDO'}
    # Blender does not register RNA annotations inherited from a plain Python
    # mixin.  Declare the button-assigned action on each concrete Operator.
    action: StringProperty(default='ADD_SELECT', description='Choose whether the region adds selections, excludes mappings, or pins mappings.')
    replace: BoolProperty(name='Replace', default=False, description='Enable or disable Replace. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.')

    def invoke(self, context, event):
        self.start = (event.mouse_region_x, event.mouse_region_y)
        self.end = self.start
        context.window_manager.modal_handler_add(self)
        self.report({'INFO'}, 'Drag with LMB to define a rectangle region.')
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type in {'RIGHTMOUSE', 'ESC'}:
            self.report({'INFO'}, 'Rectangle selection canceled.')
            return {'CANCELLED'}
        if event.type == 'MOUSEMOVE':
            self.end = (event.mouse_region_x, event.mouse_region_y)
            return {'RUNNING_MODAL'}
        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            self.end = (event.mouse_region_x, event.mouse_region_y)
            items = _collect_lines_in_box(context, self.start[0], self.start[1], self.end[0], self.end[1])
            return self._finish_apply(context, items, replace=self.replace)
        return {'RUNNING_MODAL'}


class VSCPZ_OT_lasso_select_mapping_lines(_VSCPZ_RangePickBase, bpy.types.Operator):
    bl_idname = 'vscpz.lasso_select_mapping_lines'
    bl_label = 'Add by Lasso'
    bl_description = 'Draw a lasso in the 3D View to select/pin/exclude mapping lines in the region.'
    bl_options = {'UNDO'}
    action: StringProperty(default='ADD_SELECT', description='Choose whether the region adds selections, excludes mappings, or pins mappings.')
    replace: BoolProperty(name='Replace', default=False, description='Enable or disable Replace. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.')

    def invoke(self, context, event):
        zs = _settings(context)
        self.points = [(event.mouse_region_x, event.mouse_region_y)]
        self.min_step = max(2, int(getattr(zs, 'range_select_min_step', 10)))
        context.window_manager.modal_handler_add(self)
        self.report({'INFO'}, 'Drag with LMB to draw a lasso. Release to confirm.')
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type in {'RIGHTMOUSE', 'ESC'}:
            self.report({'INFO'}, 'Lasso selection canceled.')
            return {'CANCELLED'}
        if event.type == 'MOUSEMOVE':
            p = Vector((event.mouse_region_x, event.mouse_region_y))
            last = Vector(self.points[-1])
            if (p - last).length >= self.min_step:
                self.points.append((event.mouse_region_x, event.mouse_region_y))
            return {'RUNNING_MODAL'}
        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            self.points.append((event.mouse_region_x, event.mouse_region_y))
            zs = _settings(context)
            pts = list(self.points)
            if getattr(zs, 'range_select_close_loop', True) and pts and pts[0] != pts[-1]:
                pts.append(pts[0])
            items = _collect_lines_in_lasso(context, pts)
            return self._finish_apply(context, items, replace=self.replace)
        return {'RUNNING_MODAL'}


class VSCPZ_PT_mapping_edit_panel(bpy.types.Panel):
    bl_label = 'Auxiliary Mapping Lines'
    bl_description = 'Vertex Copy panel in the Smart Modeling workspace.'
    bl_idname = 'VSCPZ_PT_mapping_edit_panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    @classmethod
    def poll(cls, context):
        try:
            from ..utils import feature_enabled
            return bool(
                feature_enabled(context, "enable_vertex_copy", True)
                and getattr(context, 'scene', None) is not None
                and hasattr(context.scene, 'vscpz_settings')
            )
        except Exception:
            return False

    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        zs = context.scene.vscpz_settings
        box = layout.box()
        box.prop(zs, 'show_mapping_edit_overlay')
        box.prop(zs, 'pick_line_radius')
        box.prop(zs, 'pick_vertex_radius')
        box.prop(zs, 'overlay_line_width')
        box.prop(zs, 'overlay_point_size')

        row = layout.row(align=True)
        op = row.operator('vscpz.pick_mapping_line', text='3D Select', icon='RESTRICT_SELECT_OFF')
        op.action = 'SELECT'
        op = row.operator('vscpz.pick_mapping_line', text='3D Add Select', icon='ADD')
        op.action = 'ADD_SELECT'
        row = layout.row(align=True)
        op = row.operator('vscpz.pick_mapping_line', text='Exclude in 3D View', icon='X')
        op.action = 'EXCLUDE'
        op = row.operator('vscpz.pick_mapping_line', text='Pin in 3D View', icon='PINNED')
        op.action = 'FIX'

        range_box = layout.box()
        range_box.label(text='Select')
        row = range_box.row(align=True)
        op = row.operator('vscpz.box_select_mapping_lines', text='Add by Rectangle', icon='BORDERMOVE')
        op.action = 'ADD_SELECT'
        op.replace = False
        op = row.operator('vscpz.box_select_mapping_lines', text='Replace', icon='SELECT_SET')
        op.action = 'ADD_SELECT'
        op.replace = True
        row = range_box.row(align=True)
        op = row.operator('vscpz.lasso_select_mapping_lines', text='Add by Lasso', icon='GP_SELECT_STROKES')
        op.action = 'ADD_SELECT'
        op.replace = False
        op = row.operator('vscpz.lasso_select_mapping_lines', text='Replace', icon='GREASEPENCIL')
        op.action = 'ADD_SELECT'
        op.replace = True
        row = range_box.row(align=True)
        op = row.operator('vscpz.box_select_mapping_lines', text='Rectangle to Exclude', icon='X')
        op.action = 'EXCLUDE'
        op.replace = False
        op = row.operator('vscpz.box_select_mapping_lines', text='Rectangle to Pin', icon='PINNED')
        op.action = 'FIX'
        op.replace = False
        row = range_box.row(align=True)
        op = row.operator('vscpz.lasso_select_mapping_lines', text='Lasso to Exclude', icon='X')
        op.action = 'EXCLUDE'
        op.replace = False
        op = row.operator('vscpz.lasso_select_mapping_lines', text='Lasso to Pin', icon='PINNED')
        op.action = 'FIX'
        op.replace = False
        range_box.prop(zs, 'range_select_close_loop')
        range_box.prop(zs, 'range_select_min_step')

        sel = layout.box()
        sel.label(text='Current Select')
        sel.label(text=zs.selected_label if zs.has_selected_mapping else 'Select')
        if zs.has_selected_mapping:
            row = sel.row(align=True)
            row.operator('vscpz.exclude_selected_mapping', icon='X')
            row.operator('vscpz.fix_selected_mapping', icon='PINNED')
            row = sel.row(align=True)
            row.operator('vscpz.remove_selected_exclusion', icon='LOOP_BACK')
            row.operator('vscpz.remove_selected_fix', icon='UNPINNED')


        multi = layout.box()
        multi.label(text=_language.pick_text(f'Selected: {len(zs.selected_pairs)}', f'選択中: {len(zs.selected_pairs)}', context))
        row = multi.row(align=True)
        row.operator('vscpz.add_current_to_selected_list', icon='ADD')
        row.operator('vscpz.clear_selected_mapping_list', icon='TRASH')
        auto = multi.box()
        auto.label(text='Conditional Extract')
        auto.prop(zs, 'auto_select_scope')
        if zs.auto_select_scope in {'LOW_CONF', 'BOTH'}:
            auto.prop(zs, 'auto_select_confidence_max')
        if zs.auto_select_scope in {'LONG_DIST', 'BOTH'}:
            auto.prop(zs, 'auto_select_distance_min')
        auto.prop(zs, 'auto_select_sort')
        auto.prop(zs, 'auto_select_limit')
        row = auto.row(align=True)
        row.prop(zs, 'auto_select_include_fixed')
        row.prop(zs, 'auto_select_include_excluded')
        auto.prop(zs, 'auto_select_include_selected')
        row = auto.row(align=True)
        op = row.operator('vscpz.auto_select_mapping_lines', text='Extract & Add', icon='FILTER')
        op.replace = False
        op = row.operator('vscpz.auto_select_mapping_lines', text='Replace', icon='FILE_REFRESH')
        op.replace = True
        row = auto.row(align=True)
        op = row.operator('vscpz.select_all_fixed_pairs', text='Pinned', icon='PINNED')
        op.replace = False
        op = row.operator('vscpz.select_all_excluded_pairs', text='Excluded', icon='X')
        op.replace = False
        multi.prop(zs, 'multi_selected_line_color')
        row = multi.row(align=True)
        row.operator('vscpz.batch_fix_selected_list', icon='PINNED')
        row.operator('vscpz.batch_exclude_selected_list', icon='X')
        row = multi.row(align=True)
        row.operator('vscpz.batch_unfix_selected_list', icon='UNPINNED')
        row.operator('vscpz.batch_unexclude_selected_list', icon='LOOP_BACK')
        multi.prop(zs, 'batch_relink_order')
        multi.operator('vscpz.batch_relink_selected_list', icon='TRACKING_REFINE_FORWARDS')
        preview_rows = list(zs.selected_pairs)[:8]
        for item in preview_rows:
            multi.label(text=f'{item.source_index} -> {item.target_index}', icon='LINKED')
        if len(zs.selected_pairs) > 8:
            multi.label(text='…')

        relink = layout.box()
        relink.label(text='Manual Relink')
        relink.label(text='Replace and pin the selected mapping line to a different target vertex.')
        relink.prop(zs, 'relink_target_index')
        row = relink.row(align=True)
        row.operator('vscpz.capture_selected_target_vertex', icon='VERTEXSEL')
        row.operator('vscpz.pick_relink_target_vertex', icon='EYEDROPPER')
        row.operator('vscpz.clear_relink_target', icon='X')
        relink.operator('vscpz.relink_selected_mapping', icon='TRACKING_REFINE_FORWARDS')
        relink.operator('vscpz.pick_and_relink_selected_mapping', icon='CON_TRACKTO')

        info = layout.box()
        info.label(text=_language.pick_text(f'Pinned mappings: {len(zs.fixed_pairs)}', f'固定マッピング: {len(zs.fixed_pairs)}', context))
        for item in list(zs.fixed_pairs)[:8]:
            info.label(text=f'{item.source_index} -> {item.target_index}', icon='PINNED')
        if len(zs.fixed_pairs) > 8:
            info.label(text='…')

        info2 = layout.box()
        info2.label(text=_language.pick_text(f'Target: {len(zs.excluded_targets)}', f'ターゲット: {len(zs.excluded_targets)}', context))
        vals = [str(item.target_index) for item in list(zs.excluded_targets)[:8]]
        info2.label(text=', '.join(vals) if vals else 'None', icon='X')
        if len(zs.excluded_targets) > 8:
            info2.label(text='…')

        relink_info = layout.box()
        relink_info.label(text='Replacement Target Preview')
        relink_info.label(text=_language.pick_text(f"Current: {zs.relink_target_index if zs.relink_target_index >= 0 else ' '}", f"現在: {zs.relink_target_index if zs.relink_target_index >= 0 else ' '}", context), icon='TRACKER')
        relink_info.label(text='Displayed in the 3D View as blue points.')

        layout.operator('vscpz.clear_mapping_edits', icon='TRASH')


classes = (
    VSCPZ_FixedPair,
    VSCPZ_ExcludedTarget,
    VSCPZ_SelectedPair,
    VSCPZ_Settings,
    VSCPZ_OT_pick_mapping_line,
    VSCPZ_OT_clear_selected_mapping_list,
    VSCPZ_OT_add_current_to_selected_list,
    VSCPZ_OT_batch_fix_selected_list,
    VSCPZ_OT_batch_exclude_selected_list,
    VSCPZ_OT_batch_unfix_selected_list,
    VSCPZ_OT_batch_unexclude_selected_list,
    VSCPZ_OT_batch_relink_selected_list,
    VSCPZ_OT_auto_select_mapping_lines,
    VSCPZ_OT_select_all_fixed_pairs,
    VSCPZ_OT_select_all_excluded_pairs,
    VSCPZ_OT_box_select_mapping_lines,
    VSCPZ_OT_lasso_select_mapping_lines,
    VSCPZ_OT_exclude_selected_mapping,
    VSCPZ_OT_fix_selected_mapping,
    VSCPZ_OT_remove_selected_fix,
    VSCPZ_OT_remove_selected_exclusion,
    VSCPZ_OT_clear_mapping_edits,
    VSCPZ_OT_capture_selected_target_vertex,
    VSCPZ_OT_pick_relink_target_vertex,
    VSCPZ_OT_relink_selected_mapping,
    VSCPZ_OT_pick_and_relink_selected_mapping,
    VSCPZ_OT_clear_relink_target,
)

_VSCPZ_PROPERTY_CLASSES = (
    VSCPZ_FixedPair,
    VSCPZ_ExcludedTarget,
    VSCPZ_SelectedPair,
    VSCPZ_Settings,
)
_VSCPZ_RUNTIME_CLASSES = tuple(cls for cls in classes if cls not in _VSCPZ_PROPERTY_CLASSES)


def _unregister_panel_by_idname(panel_idname):
    # The string ID is used only to locate this module's own class object. It is
    # never used to fetch or mutate a live class from bpy.types.
    cls = globals().get(str(panel_idname))
    if isinstance(cls, type) and _vscpz_owned_class(cls):
        _vscpz_exact_safe_unregister_class(cls)


def register():
    global _LINES_DRAW_HANDLER, _PREV_BUILD_MAPPING
    _unregister_panel_by_idname("VSCPZ_PT_mapping_edit_panel")
    for cls in classes:
        bpy.utils.register_class(cls)
    try:
        if hasattr(bpy.types.Scene, "vscpz_settings"):
            del bpy.types.Scene.vscpz_settings
    except Exception:
        pass
    bpy.types.Scene.vscpz_settings = PointerProperty(type=VSCPZ_Settings, description='Stores settings for Vertex Copy Extension Lines.')
    _PREV_BUILD_MAPPING = core._build_mapping_for_mode
    core._build_mapping_for_mode = _patched_build_mapping_for_mode
    sync_lines_draw_handler()
    _invalidate_all_caches()

def unregister():
    global _LINES_DRAW_HANDLER, _PREV_BUILD_MAPPING
    _unregister_panel_by_idname("VSCPZ_PT_mapping_edit_panel")
    _remove_lines_draw_handler()
    if _PREV_BUILD_MAPPING is not None:
        core._build_mapping_for_mode = _PREV_BUILD_MAPPING
        _PREV_BUILD_MAPPING = None
    _LINE_CACHE.clear()
    for cls in reversed(_VSCPZ_RUNTIME_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    if hasattr(bpy.types.Scene, 'vscpz_settings'):
        del bpy.types.Scene.vscpz_settings
    for cls in reversed(_VSCPZ_PROPERTY_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

# --- Tooltip completion (Vertex Copy mapping panel) ---
VSCPZ_PT_mapping_edit_panel.bl_description = 'Per-pair editing panel for pinned, excluded, relinked, and batch-edited mapping lines.'
