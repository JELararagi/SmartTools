# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

bl_info = {
    "name": "Vertex Copy",
    "author": "Smart Modeling",
    "version": (13, 0, 0),
    "blender": (5, 0, 0),
    "location": "View3D > Sidebar > Vertex Copy",
    "description": "High-precision vertex shape copy & paste (Exact / Mirror / Smart / Surface / Shape Key / Soft Wrap).",
    "category": "Mesh",
}

import json
import bpy
from ..bootstrap_common import class_is_owned_for_mutation as _vscp_owned_class
from ..bootstrap_common import safe_unregister_class as _vscp_exact_safe_unregister_class
import bmesh
from mathutils import Vector
from mathutils.kdtree import KDTree
from mathutils.bvhtree import BVHTree
from mathutils.geometry import barycentric_transform
import gpu
from gpu_extras.batch import batch_for_shader
from ..compat import get_uniform_color_shader
from ..utils import draw_section_help
from .. import language as _language
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    FloatVectorProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from ..common import persistent_property_factory as _persistent_property

# Commit every visible scalar/ID selector at the RNA update boundary.  The
# message bus remains a lifecycle safety net, not a delayed save mechanism.
BoolProperty = _persistent_property(BoolProperty)
EnumProperty = _persistent_property(EnumProperty)
FloatProperty = _persistent_property(FloatProperty)
FloatVectorProperty = _persistent_property(FloatVectorProperty)
IntProperty = _persistent_property(IntProperty)
PointerProperty = _persistent_property(PointerProperty)
StringProperty = _persistent_property(StringProperty)

ADDON_SLOT_KEY = "vscp_ultimate_jp_slots"
ADDON_ACTIVE_SLOT_KEY = "vscp_ultimate_jp_active_slot"
_MAX_SLOTS = 16
_GPU_DRAW_HANDLER = None
_PREVIEW_CACHE = {}


class _GPUPreviewSnapshot:
    __slots__ = (
        "shader", "point_batch", "line_batch", "point_color", "line_color",
        "point_size", "line_width", "enabled",
    )

    def __init__(self):
        self.shader = None
        self.point_batch = None
        self.line_batch = None
        self.point_color = (1.0, 0.5, 0.0, 0.8)
        self.line_color = (0.1, 0.8, 1.0, 0.5)
        self.point_size = 5.0
        self.line_width = 1.0
        self.enabled = False

    def clear(self):
        self.point_batch = None
        self.line_batch = None
        self.enabled = False


_GPU_PREVIEW_SNAPSHOT = _GPUPreviewSnapshot()


def _add_gpu_draw_handler():
    global _GPU_DRAW_HANDLER
    # SpaceView3D draw handlers are GUI-only.  In background mode Blender has
    # no drawable viewport, so the persisted switch must remain a harmless
    # desired state instead of attempting a registration that can fail inside
    # the window-manager API.  A later GUI session restores the same RNA value
    # and registers the handler through this function normally.
    if bpy.app.background:
        return
    if _GPU_DRAW_HANDLER is not None:
        return
    _rebuild_gpu_preview_snapshot(getattr(bpy, 'context', None))
    try:
        _GPU_DRAW_HANDLER = bpy.types.SpaceView3D.draw_handler_add(
            _gpu_draw_callback, (_GPU_PREVIEW_SNAPSHOT,), 'WINDOW', 'POST_VIEW'
        )
    except Exception:
        _GPU_DRAW_HANDLER = None


def _remove_gpu_draw_handler():
    global _GPU_DRAW_HANDLER
    if _GPU_DRAW_HANDLER is None:
        return
    try:
        bpy.types.SpaceView3D.draw_handler_remove(_GPU_DRAW_HANDLER, 'WINDOW')
    except Exception:
        pass
    _GPU_DRAW_HANDLER = None
    _GPU_PREVIEW_SNAPSHOT.clear()


def sync_gpu_draw_handler(force_state=None):
    state = force_state
    if state is None:
        try:
            scene = getattr(bpy.context, 'scene', None)
            settings = getattr(scene, 'vscp_settings', None) if scene is not None else None
            state = bool(getattr(settings, 'show_gpu_preview', False))
        except Exception:
            state = False
    if state:
        if _GPU_DRAW_HANDLER is None:
            _add_gpu_draw_handler()
        else:
            _rebuild_gpu_preview_snapshot(getattr(bpy, 'context', None))
    else:
        _remove_gpu_draw_handler()
    _tag_redraw_all_view3d()


def _update_gpu_preview_toggle(self, context):
    sync_gpu_draw_handler(bool(getattr(self, 'show_gpu_preview', False)))
    try:
        from .. import common as _persistent_settings
        _persistent_settings.save_persistent_settings(context or getattr(bpy, 'context', None), force=False)
    except Exception:
        pass




def _update_gpu_preview_visual(self, context):
    """Refresh cached visual settings at the RNA update boundary."""
    del self
    if _GPU_DRAW_HANDLER is not None:
        _rebuild_gpu_preview_snapshot(context or getattr(bpy, 'context', None))
    _tag_redraw_all_view3d()


def _run_nested_operator(owner, operator):
    """Run a Vertex Copy operator from another one.

    bpy.ops raises RuntimeError when the inner operator reports an error, which
    would turn its plain refusal into a traceback for the outer operator. A real
    exception (one carrying a traceback) still propagates.
    """
    try:
        return operator()
    except RuntimeError as exc:
        text = str(exc).strip()
        if 'Traceback' in text:
            raise
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        lines = [line[len('Error: '):] if line.startswith('Error: ') else line for line in lines]
        owner.report({'ERROR'}, ' '.join(lines))
        return {'CANCELLED'}


def _get_active_mesh(context):
    obj = context.active_object
    return obj if obj and obj.type == 'MESH' else None


def _ensure_edit_mesh_object(context):
    obj = _get_active_mesh(context)
    if obj is None:
        raise RuntimeError("The active object is not a mesh.")
    if context.mode != 'EDIT_MESH':
        raise RuntimeError("Run in Edit Mode.")
    return obj


def _bm_from_edit_object(obj):
    bm = bmesh.from_edit_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    return bm


def _centroid(vectors):
    if not vectors:
        return Vector((0.0, 0.0, 0.0))
    acc = Vector((0.0, 0.0, 0.0))
    for v in vectors:
        acc += v
    return acc / len(vectors)


def _smoothstep(edge0, edge1, x):
    if edge1 <= edge0:
        return 1.0 if x >= edge1 else 0.0
    t = max(0.0, min(1.0, (x - edge0) / (edge1 - edge0)))
    return t * t * (3.0 - 2.0 * t)




def _draw_section(layout, data, prop_name, label, icon='NONE'):
    box = layout.box()
    header, body = box.panel_prop(data, prop_name)
    if icon != 'NONE':
        header.label(text=label, icon=icon)
    else:
        header.label(text=label)
    draw_section_help(header, prop_name)
    return body

def _vec_to_list(v):
    return [float(v.x), float(v.y), float(v.z)]


def _list_to_vec(v):
    return Vector((float(v[0]), float(v[1]), float(v[2])))


def _safe_normal(v):
    n = v.normal.copy()
    if n.length > 0.0:
        n.normalize()
        return n
    return Vector((0.0, 0.0, 1.0))


def _name_flip_lr(name):
    pairs = [
        (".L", ".R"), (".R", ".L"),
        ("_L", "_R"), ("_R", "_L"),
        ("-L", "-R"), ("-R", "-L"),
        (" Left", " Right"), (" Right", " Left"),
        ("left", "right"), ("right", "left"),
        ("Left", "Right"), ("Right", "Left"),
    ]
    for a, b in pairs:
        if a in name:
            return name.replace(a, b)
    return name


def _mirror_vec_local(v, axis='X'):
    x, y, z = v.x, v.y, v.z
    if axis == 'X':
        return Vector((-x, y, z))
    if axis == 'Y':
        return Vector((x, -y, z))
    return Vector((x, y, -z))


def _bool_penalty(a, b):
    return 0.0 if bool(a) == bool(b) else 1.0


def _selected_edit_verts(bm):
    return [v for v in bm.verts if v.select]


def _iter_edit_mesh_objects(context):
    """Yield editable mesh objects with the active object first.

    Vertex Copy stores one source object per clipboard slot.  In Blender's
    multi-object Edit Mode the active mesh can legitimately have no selected
    vertices while another edited mesh contains the user's selection.  Looking
    only at ``context.active_object`` made that valid state raise an uncaught
    ``RuntimeError``.  Keep the single-source clipboard model, but resolve the
    first edited mesh that actually owns selected vertices.
    """
    if context is None or getattr(context, 'mode', None) != 'EDIT_MESH':
        return

    seen = set()
    active = _get_active_mesh(context)
    if active is not None and getattr(active, 'mode', None) == 'EDIT':
        seen.add(id(active))
        yield active

    collections = (
        getattr(context, 'objects_in_mode_unique_data', None),
        getattr(context, 'objects_in_mode', None),
    )
    for objects in collections:
        if not objects:
            continue
        for obj in objects:
            try:
                if obj is None or obj.type != 'MESH' or obj.mode != 'EDIT':
                    continue
            except Exception:
                continue
            marker = id(obj)
            if marker in seen:
                continue
            seen.add(marker)
            yield obj


def _find_selected_source_edit_object(context):
    """Return the edited mesh that currently owns a vertex selection."""
    for obj in _iter_edit_mesh_objects(context) or ():
        try:
            bm = _bm_from_edit_object(obj)
            if any(v.select for v in bm.verts):
                return obj
        except Exception:
            continue
    return None


def _edge_len_score(a, b):
    total = 0.0
    count = 0
    for x, y in zip(a, b):
        if x < 0.0 or y < 0.0:
            continue
        total += abs(x - y)
        count += 1
    return 999999.0 if count == 0 else total / count


def _normal_score(a, b):
    if a.length == 0.0 or b.length == 0.0:
        return 1.0
    dot = max(-1.0, min(1.0, a.normalized().dot(b.normalized())))
    return 1.0 - dot


def _vertex_signature(v, max_edge_lengths=8):
    edge_lengths = []
    directions = []
    linked = list(v.link_edges)
    for e in linked:
        ov = e.other_vert(v)
        delta = ov.co - v.co
        edge_lengths.append(delta.length)
        if delta.length > 0.0:
            directions.append(delta.normalized())
    edge_lengths.sort()
    edge_lengths = edge_lengths[:max_edge_lengths]
    while len(edge_lengths) < max_edge_lengths:
        edge_lengths.append(-1.0)

    curvature_proxy = 0.0
    if directions:
        avg = Vector((0.0, 0.0, 0.0))
        for d in directions:
            avg += d
        avg /= len(directions)
        curvature_proxy = 1.0 - min(1.0, avg.length)

    sharp_count = 0
    seam = False
    for e in linked:
        if not e.smooth:
            sharp_count += 1
        if e.seam:
            seam = True

    return {
        "valence": len(linked),
        "face_count": len(v.link_faces),
        "edge_lengths": edge_lengths,
        "normal": _vec_to_list(_safe_normal(v)),
        "boundary": v.is_boundary,
        "seam": seam,
        "sharp_count": sharp_count,
        "curvature": curvature_proxy,
        "coord_abs": [abs(float(v.co.x)), abs(float(v.co.y)), abs(float(v.co.z))],
    }


def _serialize_weight_map(obj, vertex_index):
    out = {}
    for group in obj.vertex_groups:
        try:
            w = group.weight(vertex_index)
        except RuntimeError:
            continue
        if w > 0.0:
            out[group.name] = float(w)
    return out


def _apply_weight_map(obj, vertex_index, weight_map, mode='REPLACE', mirror_names=False):
    if mode == 'CLEAR_THEN_SET':
        for group in obj.vertex_groups:
            group.remove([vertex_index])
    for group_name, weight in weight_map.items():
        target_name = _name_flip_lr(group_name) if mirror_names else group_name
        group = obj.vertex_groups.get(target_name)
        if group is None:
            group = obj.vertex_groups.new(name=target_name)
        if mode == 'ADD':
            try:
                existing = group.weight(vertex_index)
            except RuntimeError:
                existing = 0.0
            weight = max(existing, weight)
        group.add([vertex_index], weight, 'REPLACE')


def _has_uv_layer(mesh):
    return bool(mesh.uv_layers) and mesh.uv_layers.active is not None


def _capture_selected_uv_data(obj, selected_indices):
    mesh = obj.data
    if not _has_uv_layer(mesh):
        return {}
    sel = set(selected_indices)
    uv_layer = mesh.uv_layers.active.data
    data = {}
    for poly in mesh.polygons:
        for loop_index, vertex_index in zip(poly.loop_indices, poly.vertices):
            if vertex_index not in sel:
                continue
            bucket = data.setdefault(str(vertex_index), [])
            uv = uv_layer[loop_index].uv
            bucket.append({
                "poly": int(poly.index),
                "loop": int(loop_index),
                "uv": [float(uv.x), float(uv.y)],
            })
    return data


def _apply_uv_data_exact(mesh, mapping, src_uv_payload):
    if not _has_uv_layer(mesh) or not src_uv_payload:
        return 0
    uv_layer = mesh.uv_layers.active.data
    changed = 0
    for poly in mesh.polygons:
        for loop_index, vertex_index in zip(poly.loop_indices, poly.vertices):
            if vertex_index not in mapping:
                continue
            src_vidx = mapping[vertex_index]
            bucket = src_uv_payload.get(str(src_vidx), [])
            if not bucket:
                continue
            sx = sum(x["uv"][0] for x in bucket) / len(bucket)
            sy = sum(x["uv"][1] for x in bucket) / len(bucket)
            uv_layer[loop_index].uv = (sx, sy)
            changed += 1
    return changed


def _build_clipboards(context):
    raw = context.window_manager.get(ADDON_SLOT_KEY, "")
    if not raw:
        return []
    try:
        data = json.loads(raw)
    except Exception:
        return []
    return data if isinstance(data, list) else []


def _save_clipboards(context, slots):
    context.window_manager[ADDON_SLOT_KEY] = json.dumps(slots)


def _get_active_slot_index(context):
    return int(context.window_manager.get(ADDON_ACTIVE_SLOT_KEY, 0))


def _set_active_slot_index(context, idx):
    context.window_manager[ADDON_ACTIVE_SLOT_KEY] = int(idx)


def _slot_summary(payload):
    return f"{payload.get('source_object','?')} | {payload.get('selected_count', 0)}"


def _ensure_basis_shape_key(obj):
    if obj.data.shape_keys is None:
        obj.shape_key_add(name="Basis", from_mix=False)


def _get_or_create_shape_key(obj, name):
    _ensure_basis_shape_key(obj)
    key = obj.data.shape_keys.key_blocks.get(name)
    if key is None:
        key = obj.shape_key_add(name=name, from_mix=False)
    return key


def _capture_selected_vertices_payload(context, obj, settings):
    bm = _bm_from_edit_object(obj)
    selected = _selected_edit_verts(bm)
    if not selected:
        raise RuntimeError("No vertices selected.")

    coords = [v.co.copy() for v in selected]
    center = _centroid(coords)
    selected_indices = [v.index for v in selected]

    payload = {
        "source_object": obj.name,
        "source_object_flipped_name": _name_flip_lr(obj.name),
        "source_total_vert_count": len(bm.verts),
        "selected_count": len(selected),
        "selected_indices": selected_indices,
        "center_local": _vec_to_list(center),
        "vertices": [],
        "options": {
            "copied_weights": bool(settings.copy_weights),
            "copied_uvs": bool(settings.copy_uvs),
            "copied_normals": bool(settings.copy_normals),
        },
        "uv_data": _capture_selected_uv_data(obj, selected_indices) if settings.copy_uvs else {},
    }

    mesh = obj.data
    if hasattr(mesh, "calc_normals_split"):
        mesh.calc_normals_split()

    for v in selected:
        payload["vertices"].append({
            "index": v.index,
            "co_local": _vec_to_list(v.co.copy()),
            "co_rel": _vec_to_list(v.co.copy() - center),
            "signature": _vertex_signature(v),
            "weights": _serialize_weight_map(obj, v.index) if settings.copy_weights else {},
            "normal_local": _vec_to_list(_safe_normal(v)),
        })
    return payload


def _mesh_and_mapping_exact_possible(payload, bm, settings):
    src_total = int(payload.get("source_total_vert_count", -1))
    src_indices = payload.get("selected_indices", [])
    if len(bm.verts) != src_total:
        return False, "Vertex counts do not match."
    if not src_indices:
        return False, "No vertex data in the clipboard."
    if max(src_indices) >= len(bm.verts):
        return False, "Source vertex indices exceed target range."
    if settings.exact_require_same_connectivity:
        src_by_index = {item['index']: item for item in payload['vertices']}
        for idx in src_indices:
            src_sig = src_by_index[idx]['signature']
            tgt_sig = _vertex_signature(bm.verts[idx])
            if src_sig['valence'] != tgt_sig['valence']:
                return False, f"Topology validation failed: Vertex {idx} valence does not match."
            if src_sig['face_count'] != tgt_sig['face_count']:
                return False, f"Topology validation failed: Vertex {idx} face count does not match."
    return True, ""


def _parse_index_list(text):
    out = []
    if not text.strip():
        return out
    for raw in text.replace(";", ",").split(","):
        raw = raw.strip()
        if not raw:
            continue
        try:
            out.append(int(raw))
        except Exception:
            continue
    return out


def _parse_landmark_pairs(text):
    pairs = []
    raw = text.replace(";", ",")
    for token in raw.split(","):
        token = token.strip()
        if not token or ":" not in token:
            continue
        a, b = token.split(":", 1)
        try:
            pairs.append((int(a.strip()), int(b.strip())))
        except Exception:
            continue
    return pairs


def _compute_candidate_indices(obj, bm, settings):
    candidate_indices = None
    if settings.smart_selected_only:
        candidate_indices = {v.index for v in bm.verts if v.select}
    if settings.filter_target_vertex_group and settings.target_vertex_group_name:
        group = obj.vertex_groups.get(settings.target_vertex_group_name)
        if group is not None:
            group_members = set()
            for v in bm.verts:
                try:
                    if group.weight(v.index) > settings.target_vertex_group_min_weight:
                        group_members.add(v.index)
                except RuntimeError:
                    continue
            candidate_indices = group_members if candidate_indices is None else candidate_indices.intersection(group_members)
    if settings.filter_target_index_list:
        explicit = set(_parse_index_list(settings.target_index_list))
        candidate_indices = explicit if candidate_indices is None else candidate_indices.intersection(explicit)
    if candidate_indices is None:
        candidate_indices = {v.index for v in bm.verts}
    return sorted(candidate_indices)


def _build_target_features(bm, candidate_indices=None):
    verts = [bm.verts[i] for i in candidate_indices] if candidate_indices is not None else list(bm.verts)
    center = _centroid([v.co.copy() for v in verts]) if verts else Vector((0.0, 0.0, 0.0))
    features = []
    for v in verts:
        sig = _vertex_signature(v)
        features.append({
            "index": v.index,
            "co_local": v.co.copy(),
            "co_rel": v.co.copy() - center,
            "signature": sig,
            "normal": _list_to_vec(sig["normal"]),
        })
    return features, center


def _build_kdtree(features):
    kd = KDTree(len(features))
    for i, f in enumerate(features):
        kd.insert(f["co_rel"], i)
    kd.balance()
    return kd


def _candidate_allowed(settings, src, tgt):
    ss = src["signature"]
    ts = tgt["signature"]
    if settings.alg_use_valence and abs(ss["valence"] - ts["valence"]) > settings.alg_valence_tolerance:
        return False
    if settings.alg_use_face_count and abs(ss["face_count"] - ts["face_count"]) > settings.alg_face_count_tolerance:
        return False
    if settings.alg_use_boundary and bool(ss["boundary"]) != bool(ts["boundary"]):
        return False
    if settings.alg_use_seam and bool(ss["seam"]) != bool(ts["seam"]):
        return False
    if settings.alg_use_sharp and abs(ss["sharp_count"] - ts["sharp_count"]) > settings.alg_sharp_tolerance:
        return False
    if settings.alg_use_curvature and abs(float(ss["curvature"]) - float(ts["curvature"])) > settings.alg_curvature_tolerance:
        return False
    if settings.alg_use_abs_axis:
        sa = ss["coord_abs"]
        ta = ts["coord_abs"]
        if any(abs(sa[i] - ta[i]) > settings.alg_abs_axis_tolerance for i in range(3)):
            return False
    if settings.alg_use_edge_lengths and _edge_len_score(ss["edge_lengths"], ts["edge_lengths"]) > settings.alg_edge_tolerance:
        return False
    if settings.alg_use_normal:
        sn = _list_to_vec(ss["normal"])
        tn = _list_to_vec(ts["normal"])
        if _normal_score(sn, tn) > settings.alg_normal_tolerance:
            return False
    if settings.alg_use_position and (tgt["co_rel"] - _list_to_vec(src["co_rel"])).length > settings.alg_position_tolerance:
        return False
    return True


def _candidate_score(settings, src, tgt):
    total = 0.0
    if settings.alg_use_position:
        total += (tgt["co_rel"] - _list_to_vec(src["co_rel"])).length * settings.weight_position
    if settings.alg_use_normal:
        total += _normal_score(_list_to_vec(src["signature"]["normal"]), tgt["normal"]) * settings.weight_normal
    if settings.alg_use_edge_lengths:
        total += _edge_len_score(src["signature"]["edge_lengths"], tgt["signature"]["edge_lengths"]) * settings.weight_edge
    if settings.alg_use_valence:
        total += abs(src["signature"]["valence"] - tgt["signature"]["valence"]) * settings.weight_valence
    if settings.alg_use_face_count:
        total += abs(src["signature"]["face_count"] - tgt["signature"]["face_count"]) * settings.weight_face_count
    if settings.alg_use_boundary:
        total += _bool_penalty(src["signature"]["boundary"], tgt["signature"]["boundary"]) * settings.weight_boundary
    if settings.alg_use_seam:
        total += _bool_penalty(src["signature"]["seam"], tgt["signature"]["seam"]) * settings.weight_seam
    if settings.alg_use_sharp:
        total += abs(src["signature"]["sharp_count"] - tgt["signature"]["sharp_count"]) * settings.weight_sharp
    if settings.alg_use_curvature:
        total += abs(src["signature"]["curvature"] - tgt["signature"]["curvature"]) * settings.weight_curvature
    if settings.alg_use_abs_axis:
        sa = src["signature"]["coord_abs"]
        ta = tgt["signature"]["coord_abs"]
        total += sum(abs(sa[i] - ta[i]) for i in range(3)) * settings.weight_abs_axis
    return total


def _build_landmark_seed_mapping(payload, settings, bm):
    mapping = {}
    if not settings.use_landmark_pairs:
        return mapping
    src_valid = {item["index"] for item in payload["vertices"]}
    for src_idx, tgt_idx in _parse_landmark_pairs(settings.landmark_pairs_text):
        if src_idx in src_valid and 0 <= tgt_idx < len(bm.verts):
            for src in payload["vertices"]:
                if src["index"] == src_idx:
                    mapping[tgt_idx] = src
                    break
    return mapping


def _map_exact_by_index(payload):
    return {item["index"]: item for item in payload["vertices"]}


def _target_selected_index_set(bm):
    try:
        bm.verts.ensure_lookup_table()
    except Exception:
        pass
    return {v.index for v in bm.verts if v.select}


def _filter_exact_mapping_to_selected_targets(mapping, bm, settings):
    if not getattr(settings, "same_index_selected_targets_only", True):
        return mapping
    selected = _target_selected_index_set(bm)
    if not selected:
        raise RuntimeError("Select target vertices before pasting by vertex number.")
    filtered = {idx: src for idx, src in mapping.items() if isinstance(idx, int) and idx in selected}
    if not filtered:
        raise RuntimeError("No selected target vertex has the same vertex number as the copied source selection.")
    return filtered


def _same_index_overlap_count(context, payload):
    obj = _get_active_mesh(context)
    if obj is None or context.mode != 'EDIT_MESH' or not payload:
        return 0, 0, 0
    try:
        bm = _bm_from_edit_object(obj)
        selected = _target_selected_index_set(bm)
    except Exception:
        return 0, 0, 0
    source_indices = {int(i) for i in payload.get('selected_indices', [])}
    return len(selected), len(source_indices.intersection(selected)), len(source_indices)


def _smart_map(payload, obj, bm, settings, mirror_mode=False):
    candidate_indices = _compute_candidate_indices(obj, bm, settings)
    features, _target_center = _build_target_features(bm, candidate_indices)
    if not features:
        raise RuntimeError("No smart paste candidates.")

    mapping = _build_landmark_seed_mapping(payload, settings, bm)
    used = set(mapping.keys()) if settings.smart_unique_match else set()

    if settings.use_landmark_pairs and settings.landmark_bias > 0.0 and mapping:
        src_points = []
        tgt_points = []
        for target_idx, src in mapping.items():
            src_local = _list_to_vec(src["co_local"])
            if mirror_mode:
                src_local = _mirror_vec_local(src_local, settings.mirror_axis)
            src_points.append(src_local)
            tgt_points.append(bm.verts[target_idx].co.copy())
        src_landmark_center = _centroid(src_points)
        tgt_landmark_center = _centroid(tgt_points)
        landmark_offset = tgt_landmark_center - src_landmark_center
    else:
        landmark_offset = Vector((0.0, 0.0, 0.0))

    kd = _build_kdtree(features)

    for src in payload["vertices"]:
        if any(src is s for s in mapping.values()):
            continue
        src_rel = _list_to_vec(src["co_rel"])
        if mirror_mode:
            src_rel = _mirror_vec_local(src_rel, settings.mirror_axis)
        nearby = kd.find_n(src_rel, min(settings.smart_search_neighbors, len(features)))
        best = None
        best_score = None
        for _co, feature_idx, _dist in nearby:
            tgt = features[feature_idx]
            if settings.smart_unique_match and tgt["index"] in used:
                continue
            fake_src = dict(src)
            if mirror_mode:
                fake_sig = dict(src["signature"])
                fake_sig["normal"] = _vec_to_list(_mirror_vec_local(_list_to_vec(src["signature"]["normal"]), settings.mirror_axis))
                fake_src["signature"] = fake_sig
                fake_src["co_rel"] = _vec_to_list(src_rel)
            if not _candidate_allowed(settings, fake_src, tgt):
                continue
            score = _candidate_score(settings, fake_src, tgt)
            if settings.use_landmark_pairs and settings.landmark_bias > 0.0:
                src_local = _list_to_vec(src["co_local"])
                if mirror_mode:
                    src_local = _mirror_vec_local(src_local, settings.mirror_axis)
                predicted = src_local + landmark_offset
                score += (tgt["co_local"] - predicted).length * settings.landmark_bias
            if best is None or score < best_score:
                best = tgt["index"]
                best_score = score
        if best is not None:
            mapping[best] = src
            if settings.smart_unique_match:
                used.add(best)

    if settings.smart_min_match_count > 0 and len(mapping) < settings.smart_min_match_count:
        raise RuntimeError(f"Match count {len(mapping)} is below the minimum.")
    if settings.smart_min_match_ratio > 0.0:
        ratio = len(mapping) / max(1, len(payload["vertices"]))
        if ratio < settings.smart_min_match_ratio:
            raise RuntimeError(f"Match ratio {ratio:.3f} is below minimum {settings.smart_min_match_ratio:.3f}.")
    return mapping


def _barycentric_weights(hit_loc, face):
    verts = face.verts
    if len(verts) < 3:
        return None
    v1, v2, v3 = verts[0], verts[1], verts[2]
    bary = barycentric_transform(hit_loc, v1.co, v2.co, v3.co,
                                 Vector((1.0, 0.0, 0.0)), Vector((0.0, 1.0, 0.0)), Vector((0.0, 0.0, 1.0)))
    weights = [bary.x, bary.y, bary.z]
    if len(verts) == 3:
        return [(v1.index, weights[0]), (v2.index, weights[1]), (v3.index, weights[2])]
    # N-gon は三角基準 + 残りは 0 として扱う
    out = [(v1.index, weights[0]), (v2.index, weights[1]), (v3.index, weights[2])]
    for v in verts[3:]:
        out.append((v.index, 0.0))
    return out


def _surface_project_map(payload, obj, bm, settings):
    candidate_indices = _compute_candidate_indices(obj, bm, settings)
    if not candidate_indices:
        raise RuntimeError("No surface projection candidates.")
    if not bm.faces:
        raise RuntimeError("Surface Project requires faces.")

    domain_center = _centroid([bm.verts[i].co.copy() for i in candidate_indices])
    bvh = BVHTree.FromBMesh(bm)
    if bvh is None:
        raise RuntimeError("Failed to build BVH.")

    mapping = {}
    used = set()
    candidate_set = set(candidate_indices)
    for src in payload["vertices"]:
        src_rel = _list_to_vec(src["co_rel"])
        src_local = _list_to_vec(src["co_local"])
        predicted = domain_center + src_rel if settings.smart_fit_to_target_center else src_local
        result = bvh.find_nearest(predicted)
        if result is None:
            continue
        hit_loc, _hit_normal, hit_face_index, hit_dist = result
        if hit_loc is None or hit_face_index is None:
            continue
        if hit_dist is not None and hit_dist > settings.project_max_distance:
            continue

        face = bm.faces[hit_face_index]
        if settings.surface_project_bind_mode == 'BARYCENTRIC':
            weights = _barycentric_weights(hit_loc, face)
            if not weights:
                continue
            weights = [(idx, w) for idx, w in weights if idx in candidate_set and (not settings.smart_unique_match or idx not in used)]
            if not weights:
                continue
            wrapped = dict(src)
            wrapped["projected_local"] = _vec_to_list(hit_loc)
            wrapped["project_weights"] = weights
            wrapped["project_face_index"] = int(hit_face_index)
            mapping[f"bary_{src['index']}_{len(mapping)}"] = wrapped
            if settings.smart_unique_match:
                for idx, _w in weights:
                    used.add(idx)
            continue

        best_idx = None
        best_dist = None
        for v in face.verts:
            if v.index not in candidate_set:
                continue
            if settings.smart_unique_match and v.index in used:
                continue
            d = (v.co - hit_loc).length
            if best_idx is None or d < best_dist:
                best_idx = v.index
                best_dist = d
        if best_idx is None:
            for idx in candidate_indices:
                if settings.smart_unique_match and idx in used:
                    continue
                d = (bm.verts[idx].co - hit_loc).length
                if best_idx is None or d < best_dist:
                    best_idx = idx
                    best_dist = d
        if best_idx is None:
            continue
        if settings.smart_unique_match:
            used.add(best_idx)
        wrapped = dict(src)
        wrapped["projected_local"] = _vec_to_list(hit_loc)
        mapping[best_idx] = wrapped
    return mapping


def _resolve_dest_container(obj, settings):
    if settings.target_mode == 'MESH':
        return obj.data.vertices
    if settings.target_mode == 'SHAPE_KEY_NEW':
        key = _get_or_create_shape_key(obj, settings.shape_key_name or "CopiedShape")
        return key.data
    key = _get_or_create_shape_key(obj, settings.shape_key_name or "CopiedShape")
    return key.data


def _gather_target_index_set(mapping_by_target):
    out = set()
    for key, src in mapping_by_target.items():
        if isinstance(key, int):
            out.add(key)
        elif isinstance(src, dict) and "project_weights" in src:
            for idx, _w in src["project_weights"]:
                out.add(idx)
    return out


def _compute_target_center_from_mapping(mesh, mapping_by_target, bm=None):
    idxs = sorted(_gather_target_index_set(mapping_by_target))
    if not idxs:
        return Vector((0.0, 0.0, 0.0))
    if bm is not None:
        try:
            bm.verts.ensure_lookup_table()
            coords = [bm.verts[i].co.copy() for i in idxs if 0 <= i < len(bm.verts)]
            if coords:
                return _centroid(coords)
        except Exception:
            pass
    return _centroid([mesh.vertices[i].co.copy() for i in idxs if 0 <= i < len(mesh.vertices)])


def _compute_soft_weights(bm, seeds, radius, mode='GEODESIC'):
    if not seeds:
        return {}
    weights = {idx: 1.0 for idx in seeds}
    if radius <= 0.0:
        return weights
    if mode == 'EUCLIDEAN':
        seed_cos = [_vec_to_list(bm.verts[idx].co) for idx in seeds]
        seed_vecs = [Vector(v) for v in seed_cos]
        for v in bm.verts:
            d = min((v.co - sv).length for sv in seed_vecs)
            if d <= radius:
                weights[v.index] = max(weights.get(v.index, 0.0), 1.0 - _smoothstep(0.0, radius, d))
        return weights

    frontier = [(idx, 0.0) for idx in seeds]
    best = {idx: 0.0 for idx in seeds}
    head = 0
    while head < len(frontier):
        vidx, dist = frontier[head]
        head += 1
        if dist > radius:
            continue
        base_v = bm.verts[vidx]
        for e in base_v.link_edges:
            ov = e.other_vert(base_v)
            nd = dist + (ov.co - base_v.co).length
            if nd > radius:
                continue
            prev = best.get(ov.index)
            if prev is None or nd < prev:
                best[ov.index] = nd
                frontier.append((ov.index, nd))
    for idx, d in best.items():
        weights[idx] = max(weights.get(idx, 0.0), 1.0 - _smoothstep(0.0, radius, d))
    return weights


def _collect_displacements(mesh, payload, mapping_by_target, settings, mirror_mode=False, projected_mode=False, bm=None):
    source_center = _list_to_vec(payload["center_local"])
    target_center = _compute_target_center_from_mapping(mesh, mapping_by_target, bm=bm)
    displacements = {}

    def current_co(idx):
        if bm is not None:
            try:
                if 0 <= idx < len(bm.verts):
                    return bm.verts[idx].co.copy()
            except Exception:
                pass
        return mesh.vertices[idx].co.copy()

    for target_key, src in mapping_by_target.items():
        src_local = _list_to_vec(src["co_local"])
        src_rel = _list_to_vec(src["co_rel"])
        if mirror_mode:
            src_local = _mirror_vec_local(src_local, settings.mirror_axis)
            src_rel = _mirror_vec_local(src_rel, settings.mirror_axis)

        use_smart_offset = getattr(settings, 'paste_mode', 'EXACT') in {'SMART', 'MIRROR_SMART', 'SURFACE_PROJECT'}
        if projected_mode and "projected_local" in src:
            new_local = _list_to_vec(src["projected_local"])
        elif use_smart_offset and settings.smart_keep_relative_offset:
            rel = src_local - source_center
            new_local = target_center + rel
        elif use_smart_offset and settings.smart_fit_to_target_center:
            new_local = target_center + src_rel
        else:
            new_local = src_local

        if isinstance(target_key, int):
            old_co = current_co(target_key)
            displacements[target_key] = displacements.get(target_key, Vector((0.0, 0.0, 0.0))) + (new_local - old_co)
        elif isinstance(src, dict) and "project_weights" in src:
            for idx, w in src["project_weights"]:
                if idx < 0 or idx >= len(mesh.vertices):
                    continue
                old_co = current_co(idx)
                displacements[idx] = displacements.get(idx, Vector((0.0, 0.0, 0.0))) + ((new_local - old_co) * max(0.0, w))
    return displacements, target_center


def _apply_displacements_to_destination(mesh, dest, displacements, target_center, settings):
    changed = 0
    for idx, delta in displacements.items():
        if idx < 0 or idx >= len(dest):
            continue
        new_local = dest[idx].co.copy() + delta
        if settings.use_proportional:
            domain_dist = (mesh.vertices[idx].co - target_center).length
            w = 1.0 - _smoothstep(0.0, settings.proportional_radius, domain_dist)
            if w <= 0.0:
                continue
            current = dest[idx].co.copy()
            dest[idx].co = current.lerp(new_local, w)
        else:
            dest[idx].co = new_local
        changed += 1
    return changed


def _apply_displacements_to_bmesh(bm, displacements, target_center, settings):
    changed = 0
    bm.verts.ensure_lookup_table()
    for idx, delta in displacements.items():
        if idx < 0 or idx >= len(bm.verts):
            continue
        current = bm.verts[idx].co.copy()
        new_local = current + delta
        if settings.use_proportional:
            domain_dist = (current - target_center).length
            w = 1.0 - _smoothstep(0.0, settings.proportional_radius, domain_dist)
            if w <= 0.0:
                continue
            bm.verts[idx].co = current.lerp(new_local, w)
        else:
            bm.verts[idx].co = new_local
        changed += 1
    return changed


def _apply_positions_to_mesh(obj, bm, payload, mapping_by_target, settings, mirror_mode=False, projected_mode=False):
    mesh = obj.data
    dest = _resolve_dest_container(obj, settings)
    if not mapping_by_target:
        return 0

    displacements, target_center = _collect_displacements(mesh, payload, mapping_by_target, settings, mirror_mode=mirror_mode, projected_mode=projected_mode, bm=bm)
    if not displacements:
        return 0

    final_displacements = dict(displacements)
    if settings.enable_soft_wrap:
        seed_indices = list(displacements.keys())
        soft_weights = _compute_soft_weights(bm, seed_indices, settings.soft_wrap_radius, mode=settings.soft_wrap_distance_mode)
        new_disp = {}
        for idx, weight in soft_weights.items():
            if idx in displacements:
                new_disp[idx] = displacements[idx]
                continue
            acc = Vector((0.0, 0.0, 0.0))
            acc_w = 0.0
            v = bm.verts[idx]
            for seed_idx, seed_delta in displacements.items():
                seed_v = bm.verts[seed_idx]
                dist = (v.co - seed_v.co).length
                if dist > settings.soft_wrap_radius and settings.soft_wrap_distance_mode == 'EUCLIDEAN':
                    continue
                local_w = weight * max(0.0, 1.0 - _smoothstep(0.0, max(settings.soft_wrap_radius, 1e-8), dist))
                if local_w <= 0.0:
                    continue
                acc += seed_delta * local_w
                acc_w += local_w
            if acc_w > 0.0:
                new_disp[idx] = acc / acc_w
        final_displacements = new_disp
        # 軽い平滑化
        for _i in range(settings.soft_wrap_smooth_iterations):
            smoothed = dict(final_displacements)
            for idx, delta in list(final_displacements.items()):
                if idx in displacements:
                    continue
                v = bm.verts[idx]
                acc = delta.copy()
                count = 1
                for e in v.link_edges:
                    ov = e.other_vert(v)
                    if ov.index in final_displacements:
                        acc += final_displacements[ov.index]
                        count += 1
                smoothed[idx] = acc / count
            final_displacements = smoothed

    if settings.target_mode == 'MESH':
        changed = _apply_displacements_to_bmesh(bm, final_displacements, target_center, settings)
        try:
            bm.normal_update()
        except Exception:
            pass
        return changed

    changed = _apply_displacements_to_destination(mesh, dest, final_displacements, target_center, settings)
    mesh.update()
    return changed


def _apply_normals_if_possible(obj, mapping_by_target, settings, mirror_mode=False):
    if not settings.copy_normals or not mapping_by_target:
        return 0
    mesh = obj.data
    if not hasattr(mesh, "normals_split_custom_set_from_vertices"):
        return 0
    normal_array = [v.normal.copy() for v in mesh.vertices]
    applied = set()
    for target_idx, src in mapping_by_target.items():
        if not isinstance(target_idx, int):
            continue
        n = _list_to_vec(src.get("normal_local", src["signature"]["normal"]))
        if mirror_mode:
            n = _mirror_vec_local(n, settings.mirror_axis)
        if n.length > 0.0:
            n.normalize()
            normal_array[target_idx] = n
            applied.add(target_idx)
    if applied:
        mesh.normals_split_custom_set_from_vertices(normal_array)
        if hasattr(mesh, "use_auto_smooth"):
            mesh.use_auto_smooth = True
        mesh.update()
    return len(applied)


def _apply_weights(obj, mapping_by_target, settings, mirror_mode=False):
    if not settings.copy_weights:
        return 0
    count = 0
    for target_idx, src in mapping_by_target.items():
        if not isinstance(target_idx, int):
            continue
        weights = src.get("weights", {})
        if not weights:
            continue
        _apply_weight_map(obj, target_idx, weights, mode=settings.weight_paste_mode, mirror_names=(mirror_mode and settings.mirror_flip_group_names))
        count += 1
    return count


def _apply_uvs(obj, mapping_by_target, payload, settings):
    if not settings.copy_uvs:
        return 0
    exact_mapping = {tgt: src["index"] for tgt, src in mapping_by_target.items() if isinstance(tgt, int) and "index" in src}
    return _apply_uv_data_exact(obj.data, exact_mapping, payload.get("uv_data", {}))


def _compute_preview(mapping_by_target, obj, settings):
    points = []
    lines = []
    for target_idx, src in mapping_by_target.items():
        if isinstance(target_idx, int):
            if target_idx >= len(obj.data.vertices):
                continue
            target_world = obj.matrix_world @ obj.data.vertices[target_idx].co
            points.append(target_world)
            if settings.preview_show_lines:
                pred = _list_to_vec(src.get("projected_local", src["co_local"]))
                lines.extend([obj.matrix_world @ pred, target_world])
        elif isinstance(src, dict) and "project_weights" in src:
            pred = _list_to_vec(src.get("projected_local", src["co_local"]))
            pred_world = obj.matrix_world @ pred
            points.append(pred_world)
            if settings.preview_show_lines:
                for idx, _w in src["project_weights"]:
                    if idx < len(obj.data.vertices):
                        lines.extend([pred_world, obj.matrix_world @ obj.data.vertices[idx].co])
    return points, lines


def _build_mapping_for_mode(context, obj, payload, settings):
    bm = _bm_from_edit_object(obj)
    mode = settings.paste_mode
    if mode == 'EXACT':
        ok, reason = _mesh_and_mapping_exact_possible(payload, bm, settings)
        if not ok:
            raise RuntimeError(reason)
        mapping = _filter_exact_mapping_to_selected_targets(_map_exact_by_index(payload), bm, settings)
        return mapping, False, False
    if mode == 'MIRROR_EXACT':
        ok, reason = _mesh_and_mapping_exact_possible(payload, bm, settings)
        if not ok:
            raise RuntimeError(reason)
        mapping = _filter_exact_mapping_to_selected_targets(_map_exact_by_index(payload), bm, settings)
        return mapping, True, False
    if mode == 'SMART':
        return _smart_map(payload, obj, bm, settings, mirror_mode=False), False, False
    if mode == 'MIRROR_SMART':
        return _smart_map(payload, obj, bm, settings, mirror_mode=True), True, False
    return _surface_project_map(payload, obj, bm, settings), False, True


def _iter_view3d_areas():
    wm = bpy.context.window_manager
    if not wm:
        return
    for window in wm.windows:
        screen = window.screen
        if not screen:
            continue
        for area in screen.areas:
            if area.type == 'VIEW_3D':
                yield area


def _tag_redraw_all_view3d():
    for area in _iter_view3d_areas():
        area.tag_redraw()


def _active_payload(context):
    slots = _build_clipboards(context)
    idx = _get_active_slot_index(context)
    if idx < 0 or idx >= len(slots):
        return None
    return slots[idx] if slots[idx] else None


def _preview_signature(context, obj, payload, settings):
    sel = tuple(v.index for v in obj.data.vertices if v.select) if obj and obj.type == 'MESH' else ()
    payload_sig = (
        payload.get('source_object', ''),
        payload.get('selected_count', 0),
        tuple(payload.get('selected_indices', [])[:256]),
    )
    setting_sig = (
        settings.paste_mode, settings.smart_selected_only, settings.smart_fit_to_target_center,
        settings.smart_keep_relative_offset, settings.smart_search_neighbors, settings.smart_unique_match,
        settings.use_proportional, round(settings.proportional_radius, 6),
        round(settings.project_max_distance, 6), settings.surface_project_bind_mode,
        settings.preview_show_lines, settings.target_object_mode, settings.mirror_axis,
        settings.use_landmark_pairs, len(settings.landmark_items), settings.enable_soft_wrap,
        round(settings.soft_wrap_radius, 6), settings.soft_wrap_distance_mode, settings.soft_wrap_smooth_iterations,
    )
    return (obj.name_full if obj else '', obj.data.name_full if obj else '', payload_sig, sel, setting_sig)


def _rebuild_gpu_preview_snapshot(context=None):
    """Build the bounded GPU preview snapshot outside the draw callback."""
    context = context or getattr(bpy, 'context', None)
    if context is None:
        _GPU_PREVIEW_SNAPSHOT.clear()
        return False
    try:
        scene = context.scene
        settings = getattr(scene, "vscp_settings", None) if scene is not None else None
        if settings is None or not bool(settings.show_gpu_preview):
            _GPU_PREVIEW_SNAPSHOT.clear()
            return False
        obj = _get_active_mesh(context)
        if obj is None or context.mode != 'EDIT_MESH':
            _GPU_PREVIEW_SNAPSHOT.clear()
            return False
        payload = _active_payload(context)
        if not payload:
            _GPU_PREVIEW_SNAPSHOT.clear()
            return False
        points, lines = _preview_points_and_lines(context, obj, payload, settings)
        if not points:
            _GPU_PREVIEW_SNAPSHOT.clear()
            return False

        shader = get_uniform_color_shader('3D')
        point_batch = batch_for_shader(shader, 'POINTS', {"pos": tuple(points)})
        line_batch = None
        if lines and bool(settings.preview_show_lines):
            line_batch = batch_for_shader(shader, 'LINES', {"pos": tuple(lines)})
        snapshot = _GPU_PREVIEW_SNAPSHOT
        snapshot.shader = shader
        snapshot.point_batch = point_batch
        snapshot.line_batch = line_batch
        snapshot.point_color = tuple(settings.preview_color)
        snapshot.line_color = tuple(settings.preview_line_color)
        snapshot.point_size = float(settings.preview_point_size)
        snapshot.line_width = float(settings.preview_line_width)
        snapshot.enabled = True
        return True
    except Exception:
        _GPU_PREVIEW_SNAPSHOT.clear()
        return False


def _invalidate_preview_cache():
    _PREVIEW_CACHE.clear()
    if _GPU_DRAW_HANDLER is not None:
        _rebuild_gpu_preview_snapshot(getattr(bpy, 'context', None))


def _preview_points_and_lines(context, obj, payload, settings):
    key = _preview_signature(context, obj, payload, settings)
    cached = _PREVIEW_CACHE.get('entry')
    if cached and cached.get('key') == key:
        return cached['points'], cached['lines']
    mapping, _mirror_mode, _projected_mode = _build_mapping_for_mode(context, obj, payload, settings)
    points, lines = _compute_preview(mapping, obj, settings)
    _PREVIEW_CACHE['entry'] = {'key': key, 'points': points, 'lines': lines}
    return points, lines


def _gpu_draw_callback(snapshot):
    """Draw prebuilt preview batches only; no RNA, mapping, BVH, or batch build."""
    if snapshot is None or not snapshot.enabled or snapshot.shader is None or snapshot.point_batch is None:
        return
    shader = snapshot.shader
    try:
        gpu.state.blend_set('ALPHA')
        gpu.state.depth_test_set('NONE')
        gpu.state.point_size_set(snapshot.point_size)
        shader.bind()
        shader.uniform_float("color", snapshot.point_color)
        snapshot.point_batch.draw(shader)
        if snapshot.line_batch is not None:
            gpu.state.line_width_set(snapshot.line_width)
            shader.bind()
            shader.uniform_float("color", snapshot.line_color)
            snapshot.line_batch.draw(shader)
    except Exception:
        return
    finally:
        try:
            gpu.state.point_size_set(1.0)
        except Exception:
            pass
        try:
            gpu.state.line_width_set(1.0)
        except Exception:
            pass
        try:
            gpu.state.depth_test_set('LESS_EQUAL')
        except Exception:
            pass
        try:
            gpu.state.blend_set('NONE')
        except Exception:
            pass


class VSCP_LandmarkItem(bpy.types.PropertyGroup):
    source_index: IntProperty(name="Copy Source", default=0, min=0, description='Adjust Copy Source. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')
    target_index: IntProperty(name="Paste Target", default=0, min=0, description='Adjust Paste Target. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')


class VSCP_ReportItem(bpy.types.PropertyGroup):
    object_name: StringProperty(name="Object", default="", description='Text field for Object. Use it to enter a name, filter, note, identifier, or other text used by the tool.')
    status: StringProperty(name="Status", default="", description='Text field for Status. Use it to enter a name, filter, note, identifier, or other text used by the tool.')
    changed_count: IntProperty(name="Changed Verts", default=0, min=0, description='Adjust Changed Verts. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')
    mapped_count: IntProperty(name="Mapping Count", default=0, min=0, description='Adjust Mapping Count. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')
    normal_count: IntProperty(name="Normal", default=0, min=0, description='Adjust Normal. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')
    weight_count: IntProperty(name="Weight", default=0, min=0, description='Adjust Weight. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')
    uv_count: IntProperty(name="UV", default=0, min=0, description='Adjust UV. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')
    message: StringProperty(name="Details", default="", description='Text field for Details. Use it to enter a name, filter, note, identifier, or other text used by the tool.')


class VSCP_CustomPresetItem(bpy.types.PropertyGroup):
    name: StringProperty(name="Name", default="", description='Text field for Name. Use it to enter a name, filter, note, identifier, or other text used by the tool.')
    payload_json: StringProperty(name="SettingsJSON", default="", description='Text field for SettingsJSON. Use it to enter a name, filter, note, identifier, or other text used by the tool.')


def _settings_to_preset_payload(settings):
    keys = [
        'paste_mode','target_mode','shape_key_name','exact_require_same_connectivity','same_index_selected_targets_only',
        'smart_selected_only','smart_search_neighbors','smart_unique_match','smart_min_match_count','smart_min_match_ratio',
        'smart_keep_relative_offset','smart_fit_to_target_center','filter_target_vertex_group','target_vertex_group_name',
        'target_vertex_group_min_weight','filter_target_index_list','target_index_list','mirror_axis','mirror_flip_group_names',
        'weight_paste_mode','use_landmark_pairs','landmark_bias','use_proportional','proportional_radius',
        'project_max_distance','surface_project_bind_mode','enable_soft_wrap','soft_wrap_radius','soft_wrap_distance_mode',
        'soft_wrap_smooth_iterations','alg_use_position','alg_use_normal','alg_use_edge_lengths','alg_use_valence',
        'alg_use_face_count','alg_use_boundary','alg_use_seam','alg_use_sharp','alg_use_curvature','alg_use_abs_axis',
        'alg_position_tolerance','alg_normal_tolerance','alg_edge_tolerance','alg_valence_tolerance','alg_face_count_tolerance',
        'alg_sharp_tolerance','alg_curvature_tolerance','alg_abs_axis_tolerance','weight_position','weight_normal',
        'weight_edge','weight_valence','weight_face_count','weight_boundary','weight_seam','weight_sharp','weight_curvature',
        'weight_abs_axis','copy_weights','copy_uvs','copy_normals','preview_show_lines','preview_point_size',
        'preview_line_width','preview_color','preview_line_color','paste_skip_ng_from_last_validation',
        'landmark_auto_pair_mode','landmark_auto_clear_before_add','landmark_auto_limit_count'
    ]
    data = {}
    for key in keys:
        try:
            value = getattr(settings, key)
            if hasattr(value, 'to_list'):
                value = list(value)
            elif hasattr(value, '__len__') and value.__class__.__name__ == 'bpy_prop_array':
                value = list(value)
            data[key] = value
        except Exception:
            pass
    data['landmark_pairs_text'] = settings.landmark_pairs_text
    data['landmark_items'] = [{'source_index': int(i.source_index), 'target_index': int(i.target_index)} for i in settings.landmark_items]
    return data


def _apply_preset_payload_to_settings(settings, data):
    for key, value in data.items():
        if key in {'landmark_items', 'landmark_pairs_text'}:
            continue
        if hasattr(settings, key):
            try:
                setattr(settings, key, value)
            except Exception:
                pass
    if 'landmark_items' in data:
        settings.landmark_items.clear()
        for item in data['landmark_items']:
            row = settings.landmark_items.add()
            row.source_index = int(item.get('source_index', 0))
            row.target_index = int(item.get('target_index', 0))
        _sync_landmark_text_from_collection(settings)
    elif 'landmark_pairs_text' in data:
        settings.landmark_pairs_text = data['landmark_pairs_text']
        _ensure_landmark_collection_from_text(settings)


def _validated_ok_object_names(settings):
    return {item.object_name for item in settings.last_run_reports if item.status == 'OK'}


def _reported_object_names_by_status(settings, status):
    return [item.object_name for item in settings.last_run_reports if item.status == status]


def _sort_landmark_target_verts(verts, mode):
    if mode == 'SORT_X':
        return sorted(verts, key=lambda v: (v.co.x, v.co.y, v.co.z, v.index))
    if mode == 'SORT_Y':
        return sorted(verts, key=lambda v: (v.co.y, v.co.x, v.co.z, v.index))
    if mode == 'SORT_Z':
        return sorted(verts, key=lambda v: (v.co.z, v.co.x, v.co.y, v.index))
    if mode == 'CENTER_DISTANCE':
        c = _centroid([v.co.copy() for v in verts])
        return sorted(verts, key=lambda v: ((v.co - c).length, v.index))
    return sorted(verts, key=lambda v: v.index)


def _clear_runtime_reports(settings):
    settings.last_run_reports.clear()
    settings.last_run_summary = ""


def _set_batch_progress(context, settings, label, index=0, total=0):
    if total > 0:
        settings.batch_progress_text = f"{label} ({index}/{total})"
    else:
        settings.batch_progress_text = label
    wm = getattr(context, 'window_manager', None)
    if wm is not None and total > 0:
        try:
            wm.progress_update(min(max(index, 0), total))
        except Exception:
            pass


def _clear_batch_progress(context, settings):
    settings.batch_progress_text = ""
    wm = getattr(context, 'window_manager', None)
    if wm is not None:
        try:
            wm.progress_end()
        except Exception:
            pass


def _append_runtime_report(settings, object_name, status, changed=0, mapped=0, normal_count=0, weight_count=0, uv_count=0, message=""):
    item = settings.last_run_reports.add()
    item.object_name = object_name
    item.status = status
    item.changed_count = int(changed)
    item.mapped_count = int(mapped)
    item.normal_count = int(normal_count)
    item.weight_count = int(weight_count)
    item.uv_count = int(uv_count)
    item.message = message


def _sync_landmark_text_from_collection(settings):
    pairs = []
    for item in settings.landmark_items:
        pairs.append(f"{int(item.source_index)}:{int(item.target_index)}")
    settings.landmark_pairs_text = ",".join(pairs)


def _ensure_landmark_collection_from_text(settings):
    parsed = _parse_landmark_pairs(settings.landmark_pairs_text)
    current = [(int(i.source_index), int(i.target_index)) for i in settings.landmark_items]
    if current == parsed:
        return
    settings.landmark_items.clear()
    for src, tgt in parsed:
        item = settings.landmark_items.add()
        item.source_index = src
        item.target_index = tgt


def _resolve_target_object(context, settings):
    active = context.active_object
    if settings.target_object_mode == 'ACTIVE':
        return active
    if settings.target_object_mode == 'MIRROR_NAME':
        if active is None:
            return None
        target_name = _name_flip_lr(active.name)
        return bpy.data.objects.get(target_name)
    if settings.target_object_mode == 'NAMED':
        return bpy.data.objects.get(settings.target_object_name)
    if settings.target_object_mode == 'COLLECTION':
        return None
    return active


def _resolve_target_objects(context, settings):
    active = context.active_object
    if settings.target_object_mode == 'SELECTED':
        out = []
        for obj in context.selected_objects:
            if obj and obj.type == 'MESH':
                out.append(obj)
    elif settings.target_object_mode == 'COLLECTION':
        out = []
        coll = bpy.data.collections.get(settings.target_collection_name) if settings.target_collection_name else None
        if coll is not None:
            for obj in coll.objects:
                if obj and obj.type == 'MESH':
                    out.append(obj)
    else:
        obj = _resolve_target_object(context, settings)
        out = [obj] if obj else []

    if settings.batch_skip_source_object and active is not None and settings.target_object_mode in {'SELECTED', 'COLLECTION'}:
        out = [obj for obj in out if obj != active]

    uniq = []
    seen = set()
    for obj in out:
        if obj is None or obj.name in seen:
            continue
        seen.add(obj.name)
        uniq.append(obj)
    return uniq


def _snapshot_object_state(context):
    view_layer = context.view_layer
    return {
        'active_name': view_layer.objects.active.name if view_layer.objects.active else '',
        'selected_names': [obj.name for obj in context.selected_objects],
        'mode': context.mode,
    }


def _restore_object_state(context, snapshot):
    try:
        bpy.ops.object.mode_set(mode='OBJECT')
    except Exception:
        pass
    try:
        bpy.ops.object.select_all(action='DESELECT')
    except Exception:
        pass
    active = None
    for name in snapshot.get('selected_names', []):
        obj = bpy.data.objects.get(name)
        if obj is not None:
            try:
                obj.select_set(True)
            except Exception:
                pass
    active_name = snapshot.get('active_name', '')
    if active_name:
        active = bpy.data.objects.get(active_name)
        if active is not None:
            context.view_layer.objects.active = active
            try:
                active.select_set(True)
            except Exception:
                pass
    mode = snapshot.get('mode', 'OBJECT')
    if active is not None and mode == 'EDIT_MESH':
        try:
            bpy.ops.object.mode_set(mode='EDIT')
        except Exception:
            pass


class VSCP_Settings(bpy.types.PropertyGroup):
    clipboard_info: StringProperty(name="Clipboard Info", default="No copied data", description='Text field for Clipboard Info. Use it to enter a name, filter, note, identifier, or other text used by the tool.')
    batch_progress_text: StringProperty(name="Progress", description="Progress for batch validation/paste.", default="")
    preset_overwrite_direct: BoolProperty(name="Overwrite same-name preset directly", description="If off and a preset with the same name exists, ask for confirmation before saving.", default=False)

    ui_section_clipboard: BoolProperty(name="Clipboard", default=True, description='Enable or disable Clipboard. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.')
    ui_section_transfer: BoolProperty(name="Transfer Settings", default=True, description='Enable or disable Transfer Settings. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.')
    ui_section_presets: BoolProperty(name="Use-case Presets", default=False, description='Enable or disable Use-case Presets. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.')
    ui_section_custom_presets: BoolProperty(name="Custom Presets", default=False, description='Enable or disable Custom Presets. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.')
    ui_section_filter: BoolProperty(name="Paste Candidate Filtering", default=False, description='Enable or disable Paste Candidate Filtering. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.')
    ui_section_data: BoolProperty(name="Extra Data Transfer", default=False, description='Enable or disable Extra Data Transfer. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.')
    ui_section_smart: BoolProperty(name="Smart / Surface Settings", default=True, description='Enable or disable Smart / Surface Settings. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.')
    ui_section_wrap: BoolProperty(name="Soft Wrap Extension", default=False, description='Enable or disable Soft Wrap Extension. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.')
    ui_section_algo: BoolProperty(name="Smart Matching Algorithm", default=False, description='Enable or disable Smart Matching Algorithm. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.')
    ui_section_preview: BoolProperty(name="GPU Preview", default=False, description='Enable or disable GPU Preview. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.')
    ui_section_report: BoolProperty(name="Last Run Report", default=True, description='Enable or disable Last Run Report. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.')
    ui_section_note: BoolProperty(name="Notes", default=False, description='Enable or disable Notes. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.')
    ui_section_main_options: BoolProperty(name="Main Options", default=False, description="Open the basic Same Vertex Number options. Use this when you need to paste to a shape key, disable target-selection filtering, or relax the same-topology check.")
    ui_section_auxiliary: BoolProperty(name="Auxiliary Functions", default=False, description="Open auxiliary transfer modes such as mirror, smart matching, surface projection, extra data, preview, landmarks, and presets. Keep it closed for the simple same-topology vertex-copy workflow.")
    ui_section_expert_matching: BoolProperty(name="Detailed Matching", default=False, description="Open detailed Smart matching tolerances and weights. Beginners should leave this closed unless a Smart transfer needs manual tuning.")

    target_object_mode: EnumProperty(
        name="Paste Target Object",
        description="How paste target objects are chosen. Mirror Name searches the .L/.R counterpart.",
        items=[
            ('ACTIVE', "Active", "Paste to the active object."),
            ('SELECTED', "Select", "Paste sequentially to all selected meshes."),
            ('COLLECTION', "Collection", "Paste sequentially to all meshes in the specified collection."),
            ('MIRROR_NAME', "Mirror Name", "Paste to the object whose name is the mirrored .L/.R counterpart."),
            ('NAMED', "Named", "Paste to the specified object name."),
        ],
        default='ACTIVE',
    )
    target_object_name: StringProperty(name="Paste Target Name", description="Target object name used in Named mode.", default="")
    target_collection_name: StringProperty(name="Paste Target Collection", description="Target collection name used in Collection mode.", default="")
    batch_skip_source_object: BoolProperty(name="Copy Source", description="When pasting to multiple objects, exclude the source object from targets.", default=False)

    last_run_reports: CollectionProperty(type=VSCP_ReportItem, description='Collection for Last Run Reports. The tool stores multiple items here, such as presets, reports, backups, or temporary entries.')
    last_run_active_index: IntProperty(name="Run Report", default=0, min=0, description='Adjust Run Report. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')
    last_run_summary: StringProperty(name="Run Summary", default="", description='Text field for Run Summary. Use it to enter a name, filter, note, identifier, or other text used by the tool.')

    landmark_items: CollectionProperty(type=VSCP_LandmarkItem, description='Collection for Landmark Items. The tool stores multiple items here, such as presets, reports, backups, or temporary entries.')
    landmark_active_index: IntProperty(name="Landmark Active", default=0, min=0, description='Adjust Landmark Active. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')
    landmark_source_input: IntProperty(name="Copy Source", default=0, min=0, description='Adjust Copy Source. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')
    landmark_target_input: IntProperty(name="Paste Target", default=0, min=0, description='Adjust Paste Target. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')

    custom_presets: CollectionProperty(type=VSCP_CustomPresetItem, description='Collection for Custom Presets. The tool stores multiple items here, such as presets, reports, backups, or temporary entries.')
    custom_preset_active_index: IntProperty(name="Custom Presets", default=0, min=0, description='Adjust Custom Presets. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')
    custom_preset_name: StringProperty(name="Save", description="Custom preset name to save current settings.", default="MyPreset")

    paste_skip_ng_from_last_validation: BoolProperty(name="Last NG Target", description="When batch pasting, run only targets marked OK in the last validation report.", default=False)

    landmark_auto_pair_mode: EnumProperty(
        name="Auto Landmark Pairing",
        description="How to pair the source selection with the current target selection.",
        items=[
            ('SELECTION_ORDER', "Selection Order (Index Order)", "Pair by source save order and target index order."),
            ('SORT_X', "X Order", "Pair by sorting local X coordinate."),
            ('SORT_Y', "Y Order", "Pair by sorting local Y coordinate."),
            ('SORT_Z', "Z Order", "Pair by sorting local Z coordinate."),
            ('CENTER_DISTANCE', "Distance from Center", "Pair by distance from each selection set’s center."),
        ],
        default='SELECTION_ORDER',
    )
    landmark_auto_clear_before_add: BoolProperty(name="Clear existing before auto-add", description="Clear existing landmarks before auto-registration.", default=False)
    landmark_auto_limit_count: IntProperty(name="Auto-add Limit", description="If greater than 0, auto-register up to that many.", default=0, min=0, max=4096)

    copy_weights: BoolProperty(name="Copy Vertex Groups", description="Copy vertex-group assignments and weights together with vertex positions. Leave this off for a simple shape-only copy; turn it on only when skin weights or grouping data must follow the pasted vertices.", default=False)
    copy_uvs: BoolProperty(name="Copy Active UV", description="Copy UV coordinates from the active UV layer together with the same-index paste. Leave this off unless the target needs the source UVs copied as well as the shape.", default=False)
    copy_normals: BoolProperty(name="Copy Custom Normals", description="Copy custom split normals together with vertex positions when Blender can write them. Leave this off for normal shape transfer; turn it on when edited shading normals must also be transferred.", default=False)

    paste_mode: EnumProperty(
        name="Paste Mode",
        description="Choose how vertex shapes are pasted.",
        items=[
            ('EXACT', "Exact", "Paste directly (same topology and vertex order)."),
            ('MIRROR_EXACT', "Mirror Exact", "Paste mirrored (same topology assumed)."),
            ('SMART', "Smart", "Estimate corresponding vertices using various algorithms and paste."),
            ('MIRROR_SMART', "Mirror Smart", "Paste using Smart matching while mirroring coordinates."),
            ('SURFACE_PROJECT', "Surface Project", "Paste while projecting onto the target surface."),
        ],
        default='EXACT',
    )

    target_mode: EnumProperty(
        name="Apply To",
        description="Choose whether to write directly to the mesh or to a shape key.",
        items=[
            ('MESH', "Mesh", "Write directly to the target mesh."),
            ('SHAPE_KEY_NEW', "New Shape Key", "Create a new shape key and write to it."),
            ('SHAPE_KEY_NAMED', "Named Shape Key", "Create/get a named shape key and write to it."),
        ],
        default='MESH',
    )
    shape_key_name: StringProperty(name="Shape Key Name", description="Shape key name used as the paste target.", default="CopiedShape")

    exact_require_same_connectivity: BoolProperty(name="Validate Connectivity for Exact", description="For Same Vertex Number / Exact modes, also compare each copied vertex's connection count and face count before pasting. Keep this on to catch different topology early; turn it off only when the vertex order is intentionally compatible but local connectivity differs.", default=True)
    same_index_selected_targets_only: BoolProperty(name="Selected Same-Index Only", description="Paste only to target vertices that are currently selected and whose vertex numbers were copied from the source. This is the main 3ds Max-style Vertex Copy workflow: select source vertices, copy, select target vertices on a same-topology object, then paste only the matching vertex numbers.", default=True)

    smart_selected_only: BoolProperty(name="Candidates: Selected Verts Only", description="Limit candidates to currently selected vertices.", default=False)
    smart_search_neighbors: IntProperty(name="Neighbor Search Count", description="Number of candidates to test during Smart matching. Higher can improve accuracy but is slower.", default=32, min=1, max=512)
    smart_unique_match: BoolProperty(name="Unique Match", description="Prevent multiple source vertices from mapping to the same target vertex.", default=True)
    smart_min_match_count: IntProperty(name="Min Match Count", description="Cancel if fewer matches than this. 0 disables.", default=0, min=0)
    smart_min_match_ratio: FloatProperty(name="Min Match Ratio", description="Minimum match ratio relative to source vertex count. 0 disables.", default=0.0, min=0.0, max=1.0, subtype='FACTOR')
    smart_keep_relative_offset: BoolProperty(name="Keep Relative Offset", description="Paste while keeping the relative offset from the source selection center.", default=True)
    smart_fit_to_target_center: BoolProperty(name="Fit to Target Center", description="Align the whole source selection to the target center.", default=False)

    filter_target_vertex_group: BoolProperty(name="Filter by Vertex Group", description="Limit paste candidates to vertices in the specified vertex group.", default=False)
    target_vertex_group_name: StringProperty(name="Target Vertex Group", description="Vertex group name used for candidate filtering.", default="")
    target_vertex_group_min_weight: FloatProperty(name="Min Weight", description="Only vertices with weight greater than this are candidates.", default=0.0001, min=0.0, max=1.0)
    filter_target_index_list: BoolProperty(name="Filter by Vertex Index List", description="Limit candidates to the manually entered vertex index list.", default=False)
    target_index_list: StringProperty(name="Target Vertex Indices", description="Example: 1,2,8,10", default="")

    mirror_axis: EnumProperty(
        name="Mirror Axis",
        description="Axis used for mirroring in Mirror modes.",
        items=[('X', "X", "Mirror on X"), ('Y', "Y", "Mirror on Y"), ('Z', "Z", "Mirror on Z")],
        default='X',
    )
    mirror_flip_group_names: BoolProperty(name="Flip .L/.R names", description="When transferring vertex groups in Mirror modes, also flip .L/.R names.", default=True)

    weight_paste_mode: EnumProperty(
        name="Vertex Group Paste Mode",
        description="Choose how vertex group weights are applied.",
        items=[
            ('REPLACE', "Replace", "Replace weights in same-named groups."),
            ('ADD', "Add/Max", "Keep the larger value compared to existing."),
            ('CLEAR_THEN_SET', "Clear Then Set", "Clear all group assignments on the target vertex, then set."),
        ],
        default='REPLACE',
    )

    use_landmark_pairs: BoolProperty(name="Use Landmark Pairs", description="Use manually specified landmark pairs to assist Smart matching.", default=False)
    landmark_pairs_text: StringProperty(name="Landmark Pairs", description="Format: Source:Target, Source:Target", default="")
    landmark_bias: FloatProperty(name="Landmark Bias Strength", description="How strongly landmark prediction is weighted.", default=1.0, min=0.0, soft_max=20.0)

    use_proportional: BoolProperty(name="Proportional Falloff", description="Smoothly fall off the paste influence from the center.", default=False)
    proportional_radius: FloatProperty(name="Falloff Radius", description="Radius for proportional falloff.", default=1.0, min=0.0001, soft_max=1000.0)
    project_max_distance: FloatProperty(name="Max Projection Distance", description="Maximum allowed distance for Surface Project.", default=10.0, min=0.0001, soft_max=10000.0)
    surface_project_bind_mode: EnumProperty(
        name="Surface Project Bind Mode",
        description="Choose which vertices receive the projection result.",
        items=[
            ('VERTEX_NEAREST', "Nearest Vertex", "Apply to the nearest vertex to the projected point."),
            ('BARYCENTRIC', "Face Barycentric", "Distribute to the face’s vertices using barycentric weights."),
        ],
        default='VERTEX_NEAREST',
    )

    enable_soft_wrap: BoolProperty(name="Soft Wrap Extension", description="Spread deformation to nearby vertices, not only matched ones (Wrap/SkinWrap-like).", default=False)
    soft_wrap_radius: FloatProperty(name="Soft Wrap Radius", description="Radius to spread deformation outward.", default=0.25, min=0.0, soft_max=1000.0)
    soft_wrap_distance_mode: EnumProperty(
        name="Soft Wrap Distance",
        description="Type of distance used for neighborhood tests.",
        items=[
            ('GEODESIC', "Geodesic Distance", "Spread using mesh geodesic (edge-walk) distance."),
            ('EUCLIDEAN', "Euclidean Distance", "Spread using straight-line distance in 3D space."),
        ],
        default='GEODESIC',
    )
    soft_wrap_smooth_iterations: IntProperty(name="Soft Wrap Smoothing Iterations", description="How many times to smooth the soft-wrap result.", default=1, min=0, max=32)

    alg_use_position: BoolProperty(name="Use Relative Position", description="Compare relative positions between source and candidates.", default=True)
    alg_use_normal: BoolProperty(name="Use Normal", description="Compare vertex normal direction.", default=True)
    alg_use_edge_lengths: BoolProperty(name="Use Connected Edge Lengths", description="Compare connected edge-length distributions.", default=True)
    alg_use_valence: BoolProperty(name="Use Valence", description="Compare number of edges connected to the vertex.", default=True)
    alg_use_face_count: BoolProperty(name="Use Face Count", description="Compare number of faces connected to the vertex.", default=True)
    alg_use_boundary: BoolProperty(name="Use Boundary Test", description="Match whether the vertex is a boundary vertex.", default=True)
    alg_use_seam: BoolProperty(name="Use Seam Test", description="Compare whether the vertex has UV seam edges.", default=False)
    alg_use_sharp: BoolProperty(name="Use Sharp Edge Count", description="Compare sharp-edge count.", default=False)
    alg_use_curvature: BoolProperty(name="Use Curvature Proxy", description="Compare local curvature proxy.", default=True)
    alg_use_abs_axis: BoolProperty(name="Use Abs-Axis Distance", description="Compare absolute distances in local space (not world space).", default=False)

    alg_position_tolerance: FloatProperty(name="Position Tolerance", description="Tolerance for relative position comparison.", default=999999.0, min=0.0, soft_max=10000.0)
    alg_normal_tolerance: FloatProperty(name="Normal Tolerance", description="Tolerance for normal comparison. Closer to 0 is stricter.", default=0.35, min=0.0, max=2.0)
    alg_edge_tolerance: FloatProperty(name="Edge Length Tolerance", description="Tolerance for edge-length comparison.", default=0.25, min=0.0, soft_max=1000.0)
    alg_valence_tolerance: IntProperty(name="Valence Tolerance", description="Tolerance for valence comparison.", default=0, min=0, max=64)
    alg_face_count_tolerance: IntProperty(name="Face Count Tolerance", description="Tolerance for face-count comparison.", default=0, min=0, max=64)
    alg_sharp_tolerance: IntProperty(name="Sharp Edge Tolerance", description="Tolerance for sharp-edge count comparison.", default=0, min=0, max=64)
    alg_curvature_tolerance: FloatProperty(name="Curvature Tolerance", description="Tolerance for curvature proxy comparison.", default=0.5, min=0.0, soft_max=10.0)
    alg_abs_axis_tolerance: FloatProperty(name="Abs-Axis Tolerance", description="Tolerance for absolute axis distance comparison.", default=999999.0, min=0.0, soft_max=999999.0)

    weight_position: FloatProperty(name="Position Weight", description="Weight for relative position comparison.", default=1.0, min=0.0, soft_max=20.0)
    weight_normal: FloatProperty(name="Normal Weight", description="Weight for normal comparison.", default=0.3, min=0.0, soft_max=20.0)
    weight_edge: FloatProperty(name="Edge Length Weight", description="Weight for edge-length comparison.", default=0.75, min=0.0, soft_max=20.0)
    weight_valence: FloatProperty(name="Valence Weight", description="Weight for valence comparison.", default=1.0, min=0.0, soft_max=20.0)
    weight_face_count: FloatProperty(name="Face Count Weight", description="Weight for face-count comparison.", default=0.75, min=0.0, soft_max=20.0)
    weight_boundary: FloatProperty(name="Boundary Weight", description="Weight for boundary comparison.", default=1.5, min=0.0, soft_max=20.0)
    weight_seam: FloatProperty(name="Seam Weight", description="Weight for seam comparison.", default=0.25, min=0.0, soft_max=20.0)
    weight_sharp: FloatProperty(name="Sharp Weight", description="Weight for sharp-edge count comparison.", default=0.25, min=0.0, soft_max=20.0)
    weight_curvature: FloatProperty(name="Curvature Weight", description="Weight for curvature proxy comparison.", default=0.75, min=0.0, soft_max=20.0)
    weight_abs_axis: FloatProperty(name="Abs-Axis Weight", description="Weight for absolute axis distance comparison.", default=0.25, min=0.0, soft_max=20.0)

    show_gpu_preview: BoolProperty(name="Show GPU Preview", description='Draw paste candidates in the 3D View only when you need preview feedback. Disabled by default to avoid always-on viewport callbacks during startup and normal editing.', default=False, update=_update_gpu_preview_toggle)
    preview_show_lines: BoolProperty(name="Show Mapping Lines", description="Show lines between predicted and pasted positions.", default=True, update=_update_gpu_preview_visual)
    preview_point_size: FloatProperty(name="Preview Point Size", description="Preview point size.", default=5.0, min=1.0, max=64.0, update=_update_gpu_preview_visual)
    preview_line_width: FloatProperty(name="Preview Line Width", description="Thickness of preview lines.", default=1.0, min=1.0, max=16.0, update=_update_gpu_preview_visual)
    preview_color: FloatVectorProperty(name="Preview Point Color", description="Color of preview points.", subtype='COLOR', size=4, min=0.0, max=1.0, default=(1.0, 0.5, 0.0, 0.8), update=_update_gpu_preview_visual)
    preview_line_color: FloatVectorProperty(name="Preview Line Color", description="Color of preview mapping lines.", subtype='COLOR', size=4, min=0.0, max=1.0, default=(0.1, 0.8, 1.0, 0.5), update=_update_gpu_preview_visual)


class VSCP_OT_add_landmark_pair(bpy.types.Operator):
    bl_idname = "vscp.add_landmark_pair"
    bl_label = "Add Landmark Pair"
    bl_description = "Add the entered source/target vertex indices as a landmark pair."
    bl_options = {'UNDO'}

    def execute(self, context):
        s = context.scene.vscp_settings
        item = s.landmark_items.add()
        item.source_index = int(s.landmark_source_input)
        item.target_index = int(s.landmark_target_input)
        s.landmark_active_index = max(0, len(s.landmark_items) - 1)
        _sync_landmark_text_from_collection(s)
        _tag_redraw_all_view3d()
        return {'FINISHED'}


class VSCP_OT_remove_landmark_pair(bpy.types.Operator):
    bl_idname = "vscp.remove_landmark_pair"
    bl_label = "Remove Landmark Pair"
    bl_description = "Delete the selected landmark row."
    bl_options = {'UNDO'}

    def execute(self, context):
        s = context.scene.vscp_settings
        if not s.landmark_items:
            return {'CANCELLED'}
        idx = min(max(0, s.landmark_active_index), len(s.landmark_items) - 1)
        s.landmark_items.remove(idx)
        s.landmark_active_index = min(idx, max(0, len(s.landmark_items) - 1))
        _sync_landmark_text_from_collection(s)
        _tag_redraw_all_view3d()
        return {'FINISHED'}


class VSCP_OT_clear_landmark_pairs(bpy.types.Operator):
    bl_idname = "vscp.clear_landmark_pairs"
    bl_label = "Clear All Landmark Pairs"
    bl_description = "Delete all registered landmarks."
    bl_options = {'UNDO'}

    def execute(self, context):
        s = context.scene.vscp_settings
        s.landmark_items.clear()
        s.landmark_active_index = 0
        _sync_landmark_text_from_collection(s)
        _tag_redraw_all_view3d()
        return {'FINISHED'}


class VSCP_OT_remove_landmark_pair_at(bpy.types.Operator):
    bl_idname = "vscp.remove_landmark_pair_at"
    bl_label = "Remove Landmark Row"
    bl_description = "Delete the specified landmark row."
    bl_options = {'UNDO'}

    item_index: IntProperty(name="Row", default=-1, min=-1, description='Adjust Row. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')

    def execute(self, context):
        s = context.scene.vscp_settings
        if not s.landmark_items:
            return {'CANCELLED'}
        idx = self.item_index if self.item_index >= 0 else s.landmark_active_index
        idx = min(max(0, idx), len(s.landmark_items) - 1)
        s.landmark_items.remove(idx)
        s.landmark_active_index = min(idx, max(0, len(s.landmark_items) - 1))
        _sync_landmark_text_from_collection(s)
        _tag_redraw_all_view3d()
        return {'FINISHED'}


class VSCP_OT_move_landmark_pair(bpy.types.Operator):
    bl_idname = "vscp.move_landmark_pair"
    bl_label = "Move Landmark Row"
    bl_description = "Move the landmark row up/down."
    bl_options = {'UNDO'}

    item_index: IntProperty(name="Row", default=-1, min=-1, description='Adjust Row. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')
    direction: EnumProperty(
        name="Direction",
        description='Choose how Direction works. Pick the mode that best matches the current task and modeling workflow.',
        items=[('UP', "Up", "Move Up"), ('DOWN', "Down", "Move Down")],
        default='UP',
    )

    def execute(self, context):
        s = context.scene.vscp_settings
        if len(s.landmark_items) < 2:
            return {'CANCELLED'}
        idx = self.item_index if self.item_index >= 0 else s.landmark_active_index
        idx = min(max(0, idx), len(s.landmark_items) - 1)
        new_idx = idx - 1 if self.direction == 'UP' else idx + 1
        if new_idx < 0 or new_idx >= len(s.landmark_items):
            return {'CANCELLED'}
        s.landmark_items.move(idx, new_idx)
        s.landmark_active_index = new_idx
        _sync_landmark_text_from_collection(s)
        _tag_redraw_all_view3d()
        return {'FINISHED'}


class VSCP_OT_select_report_objects(bpy.types.Operator):
    bl_idname = "vscp.select_report_objects"
    bl_label = "Target Select"
    bl_description = "Select only OK/NG objects from the previous report."
    bl_options = {'UNDO'}

    status: EnumProperty(
        name="Status",
        description='Choose how Status works. Pick the mode that best matches the current task and modeling workflow.',
        items=[('OK', "OK", "OK Object Select"), ('NG', "NG", "NG Object Select")],
        default='OK',
    )

    def execute(self, context):
        settings = context.scene.vscp_settings
        names = _reported_object_names_by_status(settings, self.status)
        if not names:
            self.report({'WARNING'}, f'No report items for {self.status}.')
            return {'CANCELLED'}
        try:
            if context.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
        except Exception:
            pass
        try:
            bpy.ops.object.select_all(action='DESELECT')
        except Exception:
            pass
        active = None
        count = 0
        for name in names:
            obj = bpy.data.objects.get(name)
            if obj is None:
                continue
            try:
                obj.select_set(True)
                count += 1
                if active is None:
                    active = obj
            except Exception:
                pass
        if active is not None:
            context.view_layer.objects.active = active
        self.report({'INFO'}, f'Selected {count} {self.status} objects.')
        return {'FINISHED'}


class VSCP_OT_move_custom_preset(bpy.types.Operator):
    bl_idname = "vscp.move_custom_preset"
    bl_label = "Custom Presets"
    bl_description = "Change the order of custom presets."
    bl_options = {'UNDO'}

    direction: EnumProperty(
        name="Direction",
        description='Choose how Direction works. Pick the mode that best matches the current task and modeling workflow.',
        items=[('UP', "Up", "Move Up"), ('DOWN', "Down", "Move Down")],
        default='UP',
    )

    def execute(self, context):
        s = context.scene.vscp_settings
        if len(s.custom_presets) < 2:
            return {'CANCELLED'}
        idx = max(0, min(s.custom_preset_active_index, len(s.custom_presets)-1))
        new_idx = idx - 1 if self.direction == 'UP' else idx + 1
        if new_idx < 0 or new_idx >= len(s.custom_presets):
            return {'CANCELLED'}
        s.custom_presets.move(idx, new_idx)
        s.custom_preset_active_index = new_idx
        self.report({'INFO'}, 'Custom preset order updated.')
        return {'FINISHED'}


class VSCP_OT_add_landmark_from_active_target(bpy.types.Operator):
    bl_idname = "vscp.add_landmark_from_active_target"
    bl_label = "Add from Active Vertex"
    bl_description = "Add one pair using the Source input and the current active vertex index."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        # Keep explicit shortcut/operator execution available even when the
        # Vertex Copy Always-on preview/runtime switch is off.
        return _get_active_mesh(context) is not None and context.mode == 'EDIT_MESH'

    def execute(self, context):
        s = context.scene.vscp_settings
        obj = _ensure_edit_mesh_object(context)
        bm = _bm_from_edit_object(obj)
        active_elem = bm.select_history.active if bm.select_history else None
        if active_elem is None or not isinstance(active_elem, bmesh.types.BMVert):
            self.report({'ERROR'}, 'Make sure there is exactly one active vertex on the paste target.')
            return {'CANCELLED'}
        item = s.landmark_items.add()
        item.source_index = int(s.landmark_source_input)
        item.target_index = int(active_elem.index)
        s.landmark_active_index = max(0, len(s.landmark_items) - 1)
        s.use_landmark_pairs = True
        _sync_landmark_text_from_collection(s)
        _invalidate_preview_cache()
        _tag_redraw_all_view3d()
        self.report({'INFO'}, f'Added landmark {item.source_index}:{item.target_index}.')
        return {'FINISHED'}


class VSCP_OT_copy_vertices(bpy.types.Operator):
    bl_idname = "vscp.copy_vertices"
    bl_label = 'Copy Source'
    bl_description = "Copy the shape of selected vertices to the clipboard (Edit Mode)."
    bl_options = {'UNDO'}

    slot_index: IntProperty(name="Slot", default=-1, min=-1, max=_MAX_SLOTS - 1, description='Adjust Slot. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')

    @classmethod
    def poll(cls, context):
        # Keep explicit shortcut/operator execution available even when the
        # Vertex Copy Always-on preview/runtime switch is off.
        return _get_active_mesh(context) is not None and context.mode == 'EDIT_MESH'

    def execute(self, context):
        settings = context.scene.vscp_settings
        obj = _find_selected_source_edit_object(context)
        if obj is None:
            self.report(
                {'WARNING'},
                _language.pick_text(
                    "No vertices selected.",
                    "頂点が選択されていません。",
                    context,
                ),
            )
            return {'CANCELLED'}
        try:
            payload = _capture_selected_vertices_payload(context, obj, settings)
        except RuntimeError as exc:
            message = str(exc or "No vertices selected.").strip() or "No vertices selected."
            if message == "No vertices selected.":
                message = _language.pick_text(
                    "No vertices selected.",
                    "頂点が選択されていません。",
                    context,
                )
            self.report({'WARNING'}, message)
            return {'CANCELLED'}
        slots = _build_clipboards(context)
        slot_idx = self.slot_index if self.slot_index >= 0 else _get_active_slot_index(context)
        slot_idx = max(0, min(slot_idx, _MAX_SLOTS - 1))
        while len(slots) <= slot_idx:
            slots.append({})
        slots[slot_idx] = payload
        _save_clipboards(context, slots)
        _set_active_slot_index(context, slot_idx)
        settings.clipboard_info = _slot_summary(payload)
        _tag_redraw_all_view3d()
        self.report({'INFO'}, f"{payload['selected_count']} verts copied to slot {slot_idx + 1}.")
        return {'FINISHED'}


class VSCP_OT_select_clipboard_slot(bpy.types.Operator):
    bl_idname = "vscp.select_clipboard_slot"
    bl_label = 'Select Clipboard Slot'
    bl_description = "Choose the clipboard slot to make active."
    bl_options = {'UNDO'}

    slot_index: IntProperty(default=0, min=0, max=_MAX_SLOTS - 1, description='Adjust Slot Index. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')

    def execute(self, context):
        slots = _build_clipboards(context)
        if self.slot_index >= len(slots) or not slots[self.slot_index]:
            self.report({'WARNING'}, "This slot is empty.")
            return {'CANCELLED'}
        _set_active_slot_index(context, self.slot_index)
        context.scene.vscp_settings.clipboard_info = _slot_summary(slots[self.slot_index])
        _tag_redraw_all_view3d()
        return {'FINISHED'}


class VSCP_OT_clear_clipboard_slot(bpy.types.Operator):
    bl_idname = "vscp.clear_clipboard_slot"
    bl_label = "Clear Clipboard Slot"
    bl_description = "Clear the current clipboard slot."
    bl_options = {'UNDO'}

    def execute(self, context):
        slots = _build_clipboards(context)
        idx = _get_active_slot_index(context)
        if idx < len(slots):
            slots[idx] = {}
            _save_clipboards(context, slots)
        context.scene.vscp_settings.clipboard_info = "No copied data"
        _tag_redraw_all_view3d()
        return {'FINISHED'}


class VSCP_OT_auto_landmark_from_selection(bpy.types.Operator):
    bl_idname = "vscp.auto_landmark_from_selection"
    bl_label = "Select"
    bl_description = "Auto-register landmarks from the active slot source selection and the current target selection."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        # Keep explicit shortcut/operator execution available even when the
        # Vertex Copy Always-on preview/runtime switch is off.
        return _get_active_mesh(context) is not None and context.mode == 'EDIT_MESH' and _active_payload(context) is not None

    def execute(self, context):
        settings = context.scene.vscp_settings
        payload = _active_payload(context)
        obj = _ensure_edit_mesh_object(context)
        bm = _bm_from_edit_object(obj)
        target_sel = _selected_edit_verts(bm)
        if not target_sel:
            self.report({'ERROR'}, 'Select a vertex on the paste target.')
            return {'CANCELLED'}
        src_indices = list(payload.get('selected_indices', []))
        if not src_indices:
            self.report({'ERROR'}, 'No source selected-vertex info in the slot.')
            return {'CANCELLED'}
        ordered_targets = _sort_landmark_target_verts(target_sel, settings.landmark_auto_pair_mode)
        count = min(len(src_indices), len(ordered_targets))
        if settings.landmark_auto_limit_count > 0:
            count = min(count, settings.landmark_auto_limit_count)
        if count <= 0:
            self.report({'ERROR'}, 'No selectable vertices available for pairing.')
            return {'CANCELLED'}
        if settings.landmark_auto_clear_before_add:
            settings.landmark_items.clear()
        for src_idx, tgt_v in zip(src_indices[:count], ordered_targets[:count]):
            row = settings.landmark_items.add()
            row.source_index = int(src_idx)
            row.target_index = int(tgt_v.index)
        _sync_landmark_text_from_collection(settings)
        settings.use_landmark_pairs = True
        _invalidate_preview_cache()
        _tag_redraw_all_view3d()
        self.report({'INFO'}, f'Auto-registered {count} landmarks.')
        return {'FINISHED'}


class VSCP_OT_save_custom_preset(bpy.types.Operator):
    bl_idname = "vscp.save_custom_preset"
    bl_label = "Current Settings Save"
    bl_description = "Save or overwrite the current settings as a custom preset."
    bl_options = {'UNDO'}

    overwrite_confirmed: BoolProperty(name="Overwrite Confirmed", default=False, options={'HIDDEN'}, description='Enable or disable Overwrite Confirmed. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.')

    def invoke(self, context, event):
        s = context.scene.vscp_settings
        name = (s.custom_preset_name or '').strip()
        exists = any(item.name == name for item in s.custom_presets)
        if exists and not s.preset_overwrite_direct:
            from ..utils import smart_tools_invoke_confirm
            return smart_tools_invoke_confirm(context, self, event)
        return self.execute(context)

    def execute(self, context):
        s = context.scene.vscp_settings
        name = (s.custom_preset_name or '').strip()
        if not name:
            self.report({'ERROR'}, 'Enter a save name.')
            return {'CANCELLED'}
        data = json.dumps(_settings_to_preset_payload(s), ensure_ascii=False)
        target = None
        for i, item in enumerate(s.custom_presets):
            if item.name == name:
                target = item
                s.custom_preset_active_index = i
                break
        if target is None:
            target = s.custom_presets.add()
            target.name = name
            s.custom_preset_active_index = len(s.custom_presets) - 1
        target.payload_json = data
        self.report({'INFO'}, f'Saved custom preset "{name}".')
        return {'FINISHED'}


class VSCP_OT_load_custom_preset(bpy.types.Operator):
    bl_idname = "vscp.load_custom_preset"
    bl_label = "Select"
    bl_description = "Load the selected custom preset into current settings."
    bl_options = {'UNDO'}

    def execute(self, context):
        s = context.scene.vscp_settings
        if not s.custom_presets:
            self.report({'ERROR'}, 'No saved custom presets.')
            return {'CANCELLED'}
        idx = max(0, min(s.custom_preset_active_index, len(s.custom_presets)-1))
        item = s.custom_presets[idx]
        try:
            data = json.loads(item.payload_json) if item.payload_json else {}
        except Exception as exc:
            self.report({'ERROR'}, f'Failed to load preset: {exc}')
            return {'CANCELLED'}
        _apply_preset_payload_to_settings(s, data)
        s.custom_preset_name = item.name
        _invalidate_preview_cache()
        _tag_redraw_all_view3d()
        self.report({'INFO'}, f'Loaded custom preset "{item.name}".')
        return {'FINISHED'}


class VSCP_OT_delete_custom_preset(bpy.types.Operator):
    bl_idname = "vscp.delete_custom_preset"
    bl_label = "Select Remove"
    bl_description = "Delete the selected custom preset."
    bl_options = {'UNDO'}

    def execute(self, context):
        s = context.scene.vscp_settings
        if not s.custom_presets:
            self.report({'ERROR'}, 'No custom preset can be deleted.')
            return {'CANCELLED'}
        idx = max(0, min(s.custom_preset_active_index, len(s.custom_presets)-1))
        name = s.custom_presets[idx].name
        s.custom_presets.remove(idx)
        s.custom_preset_active_index = max(0, min(idx, len(s.custom_presets)-1)) if s.custom_presets else 0
        self.report({'INFO'}, f'Deleted custom preset "{name}".')
        return {'FINISHED'}


class VSCP_OT_apply_preset(bpy.types.Operator):
    bl_idname = "vscp.apply_preset"
    bl_label = "Apply Preset"
    bl_description = "Apply a use-case preset."
    bl_options = {'UNDO'}

    preset: EnumProperty(
        description='Choose how Preset works. Pick the mode that best matches the current task and modeling workflow.',
        items=[
            ('EXACT_SAFE', "Exact All", "For identical topology"),
            ('NEAR_TOPO', "Approximate Topology", "Mesh"),
            ('FACIAL', "Facial", "For facial shape transfer"),
            ('HARDSURFACE', "Hard Surface Modeling", "For mechanical / hard shapes"),
            ('CLOTHING', "Clothing / soft shapes", "For cloth / soft surfaces"),
            ('LANDMARK', "Landmark Assist", "Use Pair Points Together"),
            ('WRAP_SOFT', "Soft Wrap", "Soft Spread to Neighbors"),
            ('SURFACE_BARY', "Face Barycentric", "Project with Face Distribution"),
        ]
    )

    def execute(self, context):
        s = context.scene.vscp_settings
        p = self.preset
        if p == 'EXACT_SAFE':
            s.paste_mode = 'EXACT'
            s.exact_require_same_connectivity = True
            s.smart_unique_match = True
            s.enable_soft_wrap = False
        elif p == 'NEAR_TOPO':
            s.paste_mode = 'SMART'
            s.alg_use_position = True
            s.alg_use_normal = True
            s.alg_use_edge_lengths = True
            s.alg_use_valence = True
            s.alg_use_face_count = True
            s.alg_use_curvature = True
            s.alg_use_boundary = True
            s.alg_position_tolerance = 999999.0
            s.alg_normal_tolerance = 0.5
            s.alg_edge_tolerance = 0.35
            s.smart_unique_match = True
            s.enable_soft_wrap = False
        elif p == 'FACIAL':
            s.paste_mode = 'SMART'
            s.alg_use_position = True
            s.alg_use_normal = True
            s.alg_use_edge_lengths = True
            s.alg_use_valence = True
            s.alg_use_face_count = True
            s.alg_use_curvature = True
            s.alg_use_boundary = False
            s.smart_unique_match = True
            s.smart_keep_relative_offset = True
            s.enable_soft_wrap = True
            s.soft_wrap_radius = 0.08
        elif p == 'HARDSURFACE':
            s.paste_mode = 'SMART'
            s.alg_use_sharp = True
            s.alg_use_boundary = True
            s.alg_use_face_count = True
            s.alg_use_seam = True
            s.alg_use_edge_lengths = True
            s.alg_use_curvature = False
            s.alg_use_normal = True
            s.smart_unique_match = True
            s.enable_soft_wrap = False
        elif p == 'CLOTHING':
            s.paste_mode = 'SURFACE_PROJECT'
            s.surface_project_bind_mode = 'VERTEX_NEAREST'
            s.alg_use_boundary = False
            s.smart_unique_match = True
            s.use_proportional = True
            s.proportional_radius = 0.2
            s.enable_soft_wrap = True
            s.soft_wrap_radius = 0.15
        elif p == 'LANDMARK':
            s.paste_mode = 'SMART'
            s.use_landmark_pairs = True
            s.landmark_bias = 2.0
            s.smart_unique_match = True
        elif p == 'WRAP_SOFT':
            s.enable_soft_wrap = True
            s.soft_wrap_radius = 0.25
            s.soft_wrap_distance_mode = 'GEODESIC'
            s.soft_wrap_smooth_iterations = 2
        elif p == 'SURFACE_BARY':
            s.paste_mode = 'SURFACE_PROJECT'
            s.surface_project_bind_mode = 'BARYCENTRIC'
            s.enable_soft_wrap = False
        _invalidate_preview_cache()
        _tag_redraw_all_view3d()
        return {'FINISHED'}


class VSCP_OT_clear_last_reports(bpy.types.Operator):
    bl_idname = "vscp.clear_last_reports"
    bl_label = 'Clear Report'
    bl_description = "Clear the last validation/paste report."
    bl_options = {'UNDO'}

    def execute(self, context):
        _clear_runtime_reports(context.scene.vscp_settings)
        return {'FINISHED'}


class VSCP_OT_validate_targets(bpy.types.Operator):
    bl_idname = "vscp.validate_targets"
    bl_label = 'Auxiliary Check'
    bl_description = "Do not apply; validate whether mapping is possible for each target and report."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        # Keep explicit shortcut/operator execution available even when the
        # Vertex Copy Always-on preview/runtime switch is off.
        return _get_active_mesh(context) is not None and context.mode == 'EDIT_MESH'

    def execute(self, context):
        payload = _active_payload(context)
        if not payload:
            self.report({'ERROR'}, "Active slot is empty.")
            return {'CANCELLED'}
        settings = context.scene.vscp_settings
        _ensure_landmark_collection_from_text(settings)
        source_obj = _ensure_edit_mesh_object(context)
        target_objects = [obj for obj in _resolve_target_objects(context, settings) if obj is not None and obj.type == 'MESH']
        if settings.paste_skip_ng_from_last_validation and settings.target_object_mode in {'SELECTED', 'COLLECTION'} and settings.last_run_reports:
            ok_names = _validated_ok_object_names(settings)
            target_objects = [obj for obj in target_objects if obj.name in ok_names]
        if not target_objects:
            self.report({'ERROR'}, "Validation target object not found or not a mesh.")
            return {'CANCELLED'}

        snapshot = _snapshot_object_state(context)
        _clear_runtime_reports(settings)
        ok_count = 0
        total = len(target_objects)
        wm = getattr(context, 'window_manager', None)
        if wm is not None:
            try:
                wm.progress_begin(0, total)
            except Exception:
                pass
        try:
            for idx, target_obj in enumerate(target_objects, start=1):
                _set_batch_progress(context, settings, f'Validating: {target_obj.name}', idx - 1, total)
                try:
                    if target_obj != source_obj or context.mode != 'EDIT_MESH' or context.active_object != target_obj:
                        try:
                            bpy.ops.object.mode_set(mode='OBJECT')
                        except Exception:
                            pass
                        bpy.ops.object.select_all(action='DESELECT')
                        target_obj.select_set(True)
                        context.view_layer.objects.active = target_obj
                        bpy.ops.object.mode_set(mode='EDIT')
                    mapping, _mirror_mode, _projected_mode = _build_mapping_for_mode(context, target_obj, payload, settings)
                    mapped = len(_gather_target_index_set(mapping))
                    if mapped == 0:
                        raise RuntimeError("No target vertex could be mapped from the copied vertices.")
                    _append_runtime_report(settings, target_obj.name, 'OK', changed=0, mapped=mapped, message=f'Validation OK / Candidates {mapped}')
                    ok_count += 1
                except Exception as exc:
                    _append_runtime_report(settings, target_obj.name, 'NG', message=str(exc))
                _set_batch_progress(context, settings, f'Validating: {target_obj.name}', idx, total)
        finally:
            _restore_object_state(context, snapshot)
            _clear_batch_progress(context, settings)
        settings.last_run_summary = f'Validation: OK {ok_count} / Total {len(target_objects)}'
        _invalidate_preview_cache()
        _tag_redraw_all_view3d()
        self.report({'INFO'}, settings.last_run_summary)
        return {'FINISHED'}


def _run_same_index_operator(operator, context, nested_op):
    # The Same Vertex Number workflow must stay Exact: the AUTO switch would
    # otherwise fall back to Smart and report success on a different mesh.
    settings = context.scene.vscp_settings
    ext = getattr(context.scene, 'vscpx_settings', None)
    old_mode = settings.paste_mode
    old_target = settings.target_object_mode
    old_auto = getattr(ext, 'enable_auto_mode', None)
    try:
        settings.paste_mode = 'EXACT'
        settings.target_object_mode = 'ACTIVE'
        if old_auto:
            ext.enable_auto_mode = False
        return _run_nested_operator(operator, nested_op)
    finally:
        try:
            settings.paste_mode = old_mode
            settings.target_object_mode = old_target
            if old_auto:
                ext.enable_auto_mode = old_auto
        except Exception:
            pass


class VSCP_OT_validate_same_index(bpy.types.Operator):
    bl_idname = "vscp.validate_same_index"
    bl_label = "Validate Same Vertex Number"
    bl_description = "Validate the main Same Vertex Number workflow without changing geometry. It checks the active Edit Mode target and reports how many selected target vertices have copied source vertex numbers."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return _get_active_mesh(context) is not None and context.mode == 'EDIT_MESH'

    def execute(self, context):
        return _run_same_index_operator(self, context, bpy.ops.vscp.validate_targets)


class VSCP_OT_paste_same_index(bpy.types.Operator):
    bl_idname = "vscp.paste_same_index"
    bl_label = "Paste Same Vertex Number"
    bl_description = "Paste copied source vertex positions to the active target mesh by identical vertex number. Only selected target vertices are changed when Selected Same-Index Only is enabled."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return _get_active_mesh(context) is not None and context.mode == 'EDIT_MESH'

    def execute(self, context):
        return _run_same_index_operator(self, context, bpy.ops.vscp.paste_vertices)


class VSCP_OT_paste_vertices(bpy.types.Operator):
    bl_idname = "vscp.paste_vertices"
    bl_label = 'Auxiliary Paste'
    bl_description = "Paste current slot contents to the active mesh in Edit Mode."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        # Keep explicit shortcut/operator execution available even when the
        # Vertex Copy Always-on preview/runtime switch is off.
        return _get_active_mesh(context) is not None and context.mode == 'EDIT_MESH'

    def _apply_single(self, context, obj, payload, settings):
        bm = _bm_from_edit_object(obj)
        mapping, mirror_mode, projected_mode = _build_mapping_for_mode(context, obj, payload, settings)
        changed = _apply_positions_to_mesh(obj, bm, payload, mapping, settings, mirror_mode=mirror_mode, projected_mode=projected_mode)
        normal_count = _apply_normals_if_possible(obj, mapping, settings, mirror_mode=mirror_mode)
        weight_count = _apply_weights(obj, mapping, settings, mirror_mode=mirror_mode)
        uv_count = _apply_uvs(obj, mapping, payload, settings)
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        obj.data.update()
        return changed, len(_gather_target_index_set(mapping)), normal_count, weight_count, uv_count

    def execute(self, context):
        payload = _active_payload(context)
        if not payload:
            self.report({'ERROR'}, "Active slot is empty.")
            return {'CANCELLED'}
        settings = context.scene.vscp_settings
        _ensure_landmark_collection_from_text(settings)
        source_obj = _ensure_edit_mesh_object(context)
        target_objects = [obj for obj in _resolve_target_objects(context, settings) if obj is not None and obj.type == 'MESH']
        if settings.paste_skip_ng_from_last_validation and settings.target_object_mode in {'SELECTED', 'COLLECTION'} and settings.last_run_reports:
            ok_names = _validated_ok_object_names(settings)
            target_objects = [obj for obj in target_objects if obj.name in ok_names]
        if not target_objects:
            self.report({'ERROR'}, "Paste target object not found or not a mesh.")
            return {'CANCELLED'}

        snapshot = _snapshot_object_state(context)
        _clear_runtime_reports(settings)
        total_changed = total_mapped = total_normal = total_weight = total_uv = 0
        done_names = []
        total = len(target_objects)
        wm = getattr(context, 'window_manager', None)
        if wm is not None:
            try:
                wm.progress_begin(0, total)
            except Exception:
                pass
        try:
            for idx, target_obj in enumerate(target_objects, start=1):
                _set_batch_progress(context, settings, f'Paste : {target_obj.name}', idx - 1, total)
                try:
                    if target_obj != source_obj or context.mode != 'EDIT_MESH' or context.active_object != target_obj:
                        try:
                            bpy.ops.object.mode_set(mode='OBJECT')
                        except Exception:
                            pass
                        bpy.ops.object.select_all(action='DESELECT')
                        target_obj.select_set(True)
                        context.view_layer.objects.active = target_obj
                        bpy.ops.object.mode_set(mode='EDIT')
                    changed, mapped, normal_count, weight_count, uv_count = self._apply_single(context, target_obj, payload, settings)
                    total_changed += changed
                    total_mapped += mapped
                    total_normal += normal_count
                    total_weight += weight_count
                    total_uv += uv_count
                    done_names.append(target_obj.name)
                    _append_runtime_report(settings, target_obj.name, 'OK', changed, mapped, normal_count, weight_count, uv_count, 'Paste')
                except Exception as exc:
                    _append_runtime_report(settings, target_obj.name, 'NG', message=str(exc))
                    self.report({'WARNING'}, f"{target_obj.name}: {exc}")
                _set_batch_progress(context, settings, f'Paste : {target_obj.name}', idx, total)
        finally:
            _restore_object_state(context, snapshot)
            _clear_batch_progress(context, settings)
        _tag_redraw_all_view3d()
        target_text = ', '.join(done_names[:4])
        if len(done_names) > 4:
            target_text += f"{len(done_names)-4}"
        settings.last_run_summary = f"Paste Target {target_text or '-'} | Changed Verts {total_changed} | {total_mapped} | {total_normal} | {total_weight} | UV {total_uv}"
        self.report({'INFO'}, settings.last_run_summary)
        return {'FINISHED'}


class VSCP_PT_panel(bpy.types.Panel):
    bl_label = "Vertex Copy"
    bl_description = 'Vertex Copy panel in the Smart Modeling workspace.'
    bl_idname = "VSCP_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'

    @classmethod
    def poll(cls, context):
        try:
            from ..utils import feature_enabled
            return bool(
                feature_enabled(context, "enable_vertex_copy", True)
                and getattr(context, 'scene', None) is not None
                and hasattr(context.scene, 'vscp_settings')
            )
        except Exception:
            return False

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False
        s = context.scene.vscp_settings
        active_slot = _get_active_slot_index(context)
        payload = _active_payload(context)
        tr = lambda en, ja: _language.pick_text(en, ja, context)

        main = layout.box()
        main.label(text=tr("Vertex Copy / Paste", "頂点コピー / 貼り付け"), icon='COPYDOWN')
        guide = main.column(align=True)
        from ..core import _sms_label_wrapped
        _sms_label_wrapped(guide, context, tr("Copy selected source vertices, then paste to identical vertex numbers on the target.", "コピー元の選択頂点を記憶し、貼り付け先の同じ頂点番号へ貼り付けます。"))
        _sms_label_wrapped(guide, context, tr("By default, only selected target vertices are changed.", "初期設定では、貼り付け先で選択中の頂点だけを変更します。"))

        row = main.row(align=True)
        row.scale_y = 1.25
        row.operator("vscp.copy_vertices", text=tr("Copy", "コピー"), icon='COPYDOWN')
        row.operator("vscp.paste_same_index", text=tr("Paste", "貼り付け"), icon='PASTEDOWN')

        info = main.box()
        if payload:
            target_selected, overlap, source_count = _same_index_overlap_count(context, payload)
            info.label(text=tr(f"Slot {active_slot + 1}: {payload.get('selected_count', 0)} copied / Source: {payload.get('source_object', '?')}", f"スロット {active_slot + 1}: コピー済み {payload.get('selected_count', 0)} / コピー元: {payload.get('source_object', '?')}"), icon='CHECKMARK')
            info.label(text=tr(f"Target selected: {target_selected} / Paste matches: {overlap}", f"対象側選択: {target_selected} / 貼り付け一致: {overlap}"))
            if overlap <= 0 and target_selected > 0 and source_count > 0:
                info.label(text=tr("No selected target vertex has a copied vertex number.", "選択中の対象頂点に、コピー済みの頂点番号がありません。"), icon='ERROR')
        else:
            info.label(text=tr(f"Slot {active_slot + 1}: no copied vertices.", f"スロット {active_slot + 1}: コピー済み頂点なし。"))

        row = main.row(align=True)
        row.operator("vscp.validate_same_index", text=tr("Check", "確認"), icon='VIEWZOOM')
        row.operator("vscp.clear_clipboard_slot", text=tr("Clear", "クリア"), icon='TRASH')
        row.operator("vscp.clear_last_reports", text=tr("Report", "結果消去"), icon='X')

        options = _draw_section(layout, s, "ui_section_main_options", tr("Options", "設定"), 'PREFERENCES')
        if options:
            col = options.column(align=True)
            col.prop(s, "same_index_selected_targets_only", text=tr("Selected target vertices only", "選択中の対象頂点のみ"))
            col.prop(s, "exact_require_same_connectivity", text=tr("Validate same topology", "同一トポロジーを検証"))
            col.prop(s, "target_mode", text=tr("Write to", "書き込み先"))
            if s.target_mode != 'MESH':
                col.prop(s, "shape_key_name", text=tr("Shape Key", "シェイプキー"))
            row = options.row(align=True)
            row.label(text=tr("Slot", "スロット"))
            for i in range(min(_MAX_SLOTS, 4)):
                op = row.operator("vscp.select_clipboard_slot", text=str(i + 1), depress=(i == active_slot))
                op.slot_index = i
            data = options.row(align=True)
            data.prop(s, "copy_weights", text=tr("Weights", "ウェイト"), toggle=True)
            data.prop(s, "copy_uvs", text=tr("UV", "UV"), toggle=True)
            data.prop(s, "copy_normals", text=tr("Normals", "法線"), toggle=True)
            if s.copy_weights:
                options.prop(s, "weight_paste_mode", text=tr("Weight mode", "ウェイト方式"))

        aux = _draw_section(layout, s, "ui_section_auxiliary", tr("Auxiliary", "補助機能"), 'MOD_DATA_TRANSFER')
        if aux:
            aux.prop(s, "paste_mode", text=tr("Mode", 'モード'))
            aux.prop(s, "target_object_mode", text=tr("Target", "対象"))
            row = aux.row(align=True)
            row.scale_y = 1.1
            row.operator("vscp.paste_vertices", text=tr("Aux Paste", "補助貼り付け"), icon='PASTEDOWN')
            row.operator("vscp.validate_targets", text=tr("Aux Check", "補助確認"), icon='VIEWZOOM')
            details = _draw_section(aux, s, "ui_section_expert_matching", tr("Advanced", "詳細"), 'SETTINGS')
            if details:
                details.prop(s, "show_gpu_preview", text=tr("Preview", "プレビュー"))
                details.prop(s, "enable_soft_wrap", text=tr("Soft Wrap", "ソフトラップ"))
                details.prop(s, "filter_target_vertex_group", text=tr("Filter by vertex group", "頂点グループで絞り込み"))
                details.prop(s, "filter_target_index_list", text=tr("Filter by index list", "番号リストで絞り込み"))
                details.prop(s, "use_landmark_pairs", text=tr("Landmarks", "ランドマーク"))
                row = details.row(align=True)
                for p, label_en, label_ja in (('EXACT_SAFE', 'Exact', '同番号'), ('NEAR_TOPO', 'Smart', 'Smart'), ('SURFACE_BARY', 'Surface', '投影'), ('WRAP_SOFT', 'Wrap', 'Wrap')):
                    op = row.operator("vscp.apply_preset", text=tr(label_en, label_ja))
                    op.preset = p

        if s.batch_progress_text or s.last_run_summary or s.last_run_reports:
            report = layout.box()
            report.label(text=tr("Result", "結果"), icon='TEXT')
            if s.batch_progress_text:
                report.label(text=s.batch_progress_text, icon='TIME')
            if s.last_run_summary:
                report.label(text=s.last_run_summary)
            if s.last_run_reports:
                row = report.row(align=True)
                row.operator("vscp.select_report_objects", text=tr("OK", "OKを選択"), icon='CHECKMARK').status = 'OK'
                row.operator("vscp.select_report_objects", text=tr("NG", "NGを選択"), icon='ERROR').status = 'NG'
                for item in list(s.last_run_reports)[:6]:
                    icon = 'CHECKMARK' if item.status == 'OK' else 'ERROR'
                    text = f"{item.object_name} [{item.status}]"
                    if item.status == 'OK':
                        text += tr(f"  Changed: {item.changed_count}", f"  変更: {item.changed_count}")
                    elif item.message:
                        text += f"  {item.message}"
                    report.label(text=text, icon=icon)
                if len(s.last_run_reports) > 6:
                    report.label(text=tr(f"...and {len(s.last_run_reports) - 6} more", f"...ほか {len(s.last_run_reports) - 6} 件"))


class VSCP_PT_help(bpy.types.Panel):
    """Beginner-friendly guide for Vertex Copy."""

    bl_label = "Guide / Tips"
    bl_description = 'Guide / Tips help panel with workflow notes and beginner guidance.'
    bl_idname = "VSCP_PT_help"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        try:
            from ..utils import feature_enabled
            return feature_enabled(context, "enable_vertex_copy", True)
        except Exception:
            return True

    def draw(self, context):
        tr = lambda en, ja: _language.pick_text(en, ja, context)
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False

        box = layout.box()
        box.label(text=tr("Main workflow", "メインワークフロー"))
        col = box.column(align=True)
        col.label(text=tr("This section is centered on Same Vertex Number Copy.", "このセクションは、同頂点番号コピーを中心に構成しています。"))
        col.label(text=tr("It stores the selected source vertex positions and pastes them to matching vertex numbers on a same-topology target.", "コピー元で選択した頂点位置を記憶し、同トポロジー対象の同じ頂点番号へ貼り付けます。"))

        box = layout.box()
        box.label(text=tr("Basic steps", "基本手順"), icon='MOUSE_LMB')
        col = box.column(align=True)
        col.label(text=tr("1) Source object: enter Edit Mode, select vertices, then press Copy Selected.", "1) コピー元オブジェクトを編集モードにし、頂点を選択して「選択をコピー」を押します。"))
        col.label(text=tr("2) Target object: enter Edit Mode and select the vertices that may receive the shape.", "2) 貼り付け先オブジェクトを編集モードにし、形状を受け取る頂点を選択します。"))
        col.label(text=tr("3) Press Paste Same Number. Only copied indices that are also selected on the target are changed.", "3) 「同番号へ貼り付け」を押します。コピー済み番号かつ対象側で選択中の頂点だけが変更されます。"))

        box = layout.box()
        box.label(text=tr("Auxiliary functions", "補助機能"), icon='MOD_DATA_TRANSFER')
        col = box.column(align=True)
        col.label(text=tr("Open Auxiliary Functions only when you need Mirror, Smart matching, Surface Project, previews, landmarks, or presets.", "Mirror、Smart対応、サーフェス投影、プレビュー、ランドマーク、プリセットが必要な場合だけ「補助機能」を開きます。"))
        col.label(text=tr("Keep it closed for a simple same-topology shape copy.", "単純な同トポロジー形状コピーでは閉じたままで使用します。"))


classes = (
    VSCP_LandmarkItem,
    VSCP_ReportItem,
    VSCP_CustomPresetItem,
    VSCP_Settings,
    VSCP_OT_add_landmark_pair,
    VSCP_OT_remove_landmark_pair,
    VSCP_OT_clear_landmark_pairs,
    VSCP_OT_remove_landmark_pair_at,
    VSCP_OT_move_landmark_pair,
    VSCP_OT_auto_landmark_from_selection,
    VSCP_OT_add_landmark_from_active_target,
    VSCP_OT_select_report_objects,
    VSCP_OT_move_custom_preset,
    VSCP_OT_copy_vertices,
    VSCP_OT_select_clipboard_slot,
    VSCP_OT_clear_clipboard_slot,
    VSCP_OT_save_custom_preset,
    VSCP_OT_load_custom_preset,
    VSCP_OT_delete_custom_preset,
    VSCP_OT_apply_preset,
    VSCP_OT_clear_last_reports,
    VSCP_OT_validate_targets,
    VSCP_OT_validate_same_index,
    VSCP_OT_paste_same_index,
    VSCP_OT_paste_vertices,
    VSCP_PT_panel,
)

_VSCP_PROPERTY_CLASSES = (
    VSCP_LandmarkItem,
    VSCP_ReportItem,
    VSCP_CustomPresetItem,
    VSCP_Settings,
)
_VSCP_RUNTIME_CLASSES = tuple(cls for cls in classes if cls not in _VSCP_PROPERTY_CLASSES)


def _unregister_panel_by_idname(panel_idname):
    # The string ID is used only to locate this module's own class object. It is
    # never used to fetch or mutate a live class from bpy.types.
    cls = globals().get(str(panel_idname))
    if isinstance(cls, type) and _vscp_owned_class(cls):
        _vscp_exact_safe_unregister_class(cls)


def register():
    global _GPU_DRAW_HANDLER
    _unregister_panel_by_idname("VSCP_PT_help")
    for cls in classes:
        bpy.utils.register_class(cls)
    try:
        if hasattr(bpy.types.Scene, "vscp_settings"):
            del bpy.types.Scene.vscp_settings
    except Exception:
        pass
    bpy.types.Scene.vscp_settings = PointerProperty(type=VSCP_Settings, description='Stores settings for Vertex Copy.')
    sync_gpu_draw_handler()


def unregister():
    global _GPU_DRAW_HANDLER
    _remove_gpu_draw_handler()
    _unregister_panel_by_idname("VSCP_PT_help")
    for cls in reversed(_VSCP_RUNTIME_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    if hasattr(bpy.types.Scene, 'vscp_settings'):
        del bpy.types.Scene.vscp_settings
    for cls in reversed(_VSCP_PROPERTY_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass


if __name__ == "__main__":
    register()


# --- Tooltip completion (Vertex Copy panels) ---
VSCP_PT_panel.bl_description = 'Main Vertex Copy panel for copy, preview, matching inspection, and controlled transfer workflows.'
VSCP_PT_help.bl_description = 'Beginner-friendly usage notes for Vertex Copy.'
