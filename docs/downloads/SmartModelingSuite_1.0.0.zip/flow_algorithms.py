# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package
"""Shared edge-flow helpers for Smart Modeling Suite.

The functions in this module are intentionally UI-free.  Mesh Align and Mesh
Connect call the same implementation so the selectable flow algorithm behaves
consistently in both tools.
"""

from __future__ import annotations

import math
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Set, Tuple

import bmesh
from mathutils import Vector

FLOW_ALGORITHM_CURRENT = 'CURRENT'
FLOW_ALGORITHM_MAX = 'MAX_3DS'
FLOW_ALGORITHM_EDGEFLOW = 'EDGEFLOW'


def normalize_flow_algorithm(value: object) -> str:
    try:
        value = str(value or '').upper()
    except Exception:
        value = ''
    if value in {FLOW_ALGORITHM_MAX, 'MAX', '3DSMAX', '3DS_MAX'}:
        return FLOW_ALGORITHM_MAX
    if value in {FLOW_ALGORITHM_EDGEFLOW, 'EDGE_FLOW', 'EDGEFLOW_V112'}:
        return FLOW_ALGORITHM_EDGEFLOW
    return FLOW_ALGORITHM_CURRENT


def selected_flow_vertices(bm: bmesh.types.BMesh) -> List[bmesh.types.BMVert]:
    verts: List[bmesh.types.BMVert] = []
    seen: Set[int] = set()
    try:
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
    except Exception:
        pass

    for vert in list(getattr(bm, 'verts', ())):
        try:
            if vert.is_valid and vert.select and not vert.hide:
                key = int(vert.index)
                if key not in seen:
                    seen.add(key)
                    verts.append(vert)
        except Exception:
            continue

    for edge in list(getattr(bm, 'edges', ())):
        try:
            if not edge.is_valid or edge.hide or not edge.select:
                continue
            for vert in edge.verts:
                if vert.is_valid and not vert.hide:
                    key = int(vert.index)
                    if key not in seen:
                        seen.add(key)
                        verts.append(vert)
        except Exception:
            continue
    return verts


def selected_flow_edges(
    bm: bmesh.types.BMesh,
    target_verts: Optional[Iterable[bmesh.types.BMVert]] = None,
) -> List[bmesh.types.BMEdge]:
    edges: List[bmesh.types.BMEdge] = []
    seen: Set[int] = set()
    target_set: Set[bmesh.types.BMVert] = set()
    try:
        if target_verts is not None:
            target_set = {v for v in target_verts if v is not None and v.is_valid and not v.hide}
    except Exception:
        target_set = set()

    try:
        bm.edges.ensure_lookup_table()
    except Exception:
        pass

    for edge in list(getattr(bm, 'edges', ())):
        try:
            if not edge.is_valid or edge.hide:
                continue
            add = bool(edge.select)
            if not add and target_set:
                add = all(v in target_set for v in edge.verts)
            if add and int(edge.index) not in seen:
                seen.add(int(edge.index))
                edges.append(edge)
        except Exception:
            continue
    return edges


def _get_straight_path(start_v, first_e, max_steps: int = 256):
    path = [start_v]
    curr_v = start_v
    curr_e = first_e
    for _index in range(max(1, int(max_steps))):
        try:
            next_v = curr_e.other_vert(curr_v)
        except Exception:
            break
        if next_v in path:
            break
        path.append(next_v)
        try:
            in_faces = set(curr_e.link_faces)
        except Exception:
            in_faces = set()
        candidates = []
        try:
            linked_edges = list(next_v.link_edges)
        except Exception:
            linked_edges = []
        for edge in linked_edges:
            if edge is curr_e:
                continue
            try:
                if not edge.is_valid or edge.hide:
                    continue
            except Exception:
                pass
            try:
                if not in_faces.intersection(set(edge.link_faces)):
                    candidates.append(edge)
            except Exception:
                continue
        if len(candidates) == 1:
            curr_v = next_v
            curr_e = candidates[0]
        else:
            break
    return path


def _flow_factor_from_current_position(vert, left_co: Vector, right_co: Vector, fallback: float) -> float:
    try:
        direction = right_co - left_co
        length_sq = float(direction.length_squared)
        if length_sq <= 1.0e-12:
            return float(fallback)
        factor = float((vert.co - left_co).dot(direction) / length_sq)
        if factor != factor:
            return float(fallback)
        return max(0.0, min(1.0, factor))
    except Exception:
        return float(fallback)


def _find_best_flow_path(vert, selected_set: Set[bmesh.types.BMVert]):
    try:
        edges = [edge for edge in vert.link_edges if edge.is_valid and not edge.hide]
    except Exception:
        return None
    if len(edges) < 1:
        return None

    min_sel_depth = float('inf')
    best_full_path = None
    try:
        for index_a in range(len(edges)):
            for index_b in range(index_a + 1, len(edges)):
                edge_a, edge_b = edges[index_a], edges[index_b]
                try:
                    if set(edge_a.link_faces).intersection(set(edge_b.link_faces)):
                        continue
                except Exception:
                    continue
                path_a = _get_straight_path(vert, edge_a, 256)
                path_b = _get_straight_path(vert, edge_b, 256)
                depth_a = sum(1 for path_vert in path_a[1:] if path_vert in selected_set)
                depth_b = sum(1 for path_vert in path_b[1:] if path_vert in selected_set)
                if (depth_a + depth_b) < min_sel_depth:
                    min_sel_depth = depth_a + depth_b
                    best_full_path = path_a[::-1][:-1] + path_b
    except Exception:
        best_full_path = None

    if not best_full_path:
        try:
            for edge in edges:
                path = _get_straight_path(vert, edge, 256)
                depth = sum(1 for path_vert in path[1:] if path_vert in selected_set)
                if depth < min_sel_depth:
                    min_sel_depth = depth
                    best_full_path = path
        except Exception:
            best_full_path = None

    if not best_full_path or vert not in best_full_path:
        return None
    return best_full_path


def _path_anchors_for_vert(path: Sequence[bmesh.types.BMVert], vert, selected_set: Set[bmesh.types.BMVert]):
    try:
        idx_vert = path.index(vert)
    except Exception:
        return None

    idx_left, idx_right = -1, -1
    for idx in range(idx_vert - 1, -1, -1):
        if path[idx] not in selected_set:
            idx_left = idx
            break
    for idx in range(idx_vert + 1, len(path)):
        if path[idx] not in selected_set:
            idx_right = idx
            break
    if idx_left == -1:
        idx_left = 0
    if idx_right == -1:
        idx_right = len(path) - 1
    if idx_left == idx_vert or idx_right == idx_vert or idx_left >= idx_right:
        return None
    return idx_vert, idx_left, idx_right


def _catmull_rom(p0: Vector, p1: Vector, p2: Vector, p3: Vector, t: float) -> Vector:
    t = max(0.0, min(1.0, float(t)))
    t2 = t * t
    t3 = t2 * t
    return 0.5 * (
        (2.0 * p1) +
        (-p0 + p2) * t +
        ((2.0 * p0) - (5.0 * p1) + (4.0 * p2) - p3) * t2 +
        (-p0 + (3.0 * p1) - (3.0 * p2) + p3) * t3
    )


def _preserve_segment_factor(current: Vector, proposed: Vector, segment) -> Vector:
    if segment is None:
        return proposed
    try:
        start, end = segment
        if not isinstance(start, Vector):
            start = Vector(start)
        if not isinstance(end, Vector):
            end = Vector(end)
        direction = end - start
        length_sq = float(direction.length_squared)
        if length_sq <= 1.0e-12:
            return proposed
        delta = proposed - current
        parallel = direction * (delta.dot(direction) / length_sq)
        return current + (delta - parallel)
    except Exception:
        return proposed


def _segment_for_vert(vert, preserve_axis_segments):
    if not preserve_axis_segments:
        return None
    try:
        if isinstance(preserve_axis_segments, Mapping):
            return preserve_axis_segments.get(vert) or preserve_axis_segments.get(int(vert.index))
    except Exception:
        pass
    return None


def apply_current_flow_to_vertices(
    bm: bmesh.types.BMesh,
    target_verts: Iterable[bmesh.types.BMVert],
    *,
    iterations: int = 1,
    preserve_current_factors: bool = False,
    preserve_axis_segments: Optional[Mapping[object, Tuple[Vector, Vector]]] = None,
) -> int:
    try:
        selected_set = {v for v in target_verts if v is not None and v.is_valid and not v.hide}
    except Exception:
        selected_set = set()
    if not selected_set:
        return 0

    moved_total = 0
    for _iteration in range(max(1, int(iterations or 1))):
        new_positions: Dict[bmesh.types.BMVert, Vector] = {}
        for vert in list(selected_set):
            try:
                if not vert.is_valid or vert.hide:
                    continue
                best_full_path = _find_best_flow_path(vert, selected_set)
                if not best_full_path:
                    continue
                anchors = _path_anchors_for_vert(best_full_path, vert, selected_set)
                if anchors is None:
                    continue
                idx_vert, idx_left, idx_right = anchors
                num_segments = float(idx_right - idx_left)
                fallback_t = float(idx_vert - idx_left) / num_segments if num_segments > 0.0 else 0.5
                left_co = best_full_path[idx_left].co.copy()
                right_co = best_full_path[idx_right].co.copy()
                left_outer = (
                    best_full_path[idx_left - 1].co.copy()
                    if idx_left >= 1
                    else left_co + (left_co - best_full_path[idx_left + 1].co)
                )
                right_outer = (
                    best_full_path[idx_right + 1].co.copy()
                    if idx_right + 1 < len(best_full_path)
                    else right_co + (right_co - best_full_path[idx_right - 1].co)
                )
            except Exception:
                continue

            t = _flow_factor_from_current_position(vert, left_co, right_co, fallback_t) if preserve_current_factors else fallback_t
            chord = right_co - left_co
            chord_len = float(chord.length)
            if chord_len <= 1.0e-12:
                continue
            n = max(1.0, num_segments)
            avg_seg_len = chord_len / n
            left_vec = left_co - left_outer
            right_vec = right_outer - right_co
            try:
                tangent_left = left_vec.normalized() * avg_seg_len if left_vec.length > 1.0e-6 else chord.normalized() * avg_seg_len
            except Exception:
                tangent_left = chord.normalized() * avg_seg_len
            try:
                tangent_right = right_vec.normalized() * avg_seg_len if right_vec.length > 1.0e-6 else chord.normalized() * avg_seg_len
            except Exception:
                tangent_right = chord.normalized() * avg_seg_len

            tangent_1 = (n ** 2 / (n + 1.0)) * tangent_left + (1.0 / (n + 1.0)) * chord
            tangent_2 = (1.0 / (n + 1.0)) * chord + (n ** 2 / (n + 1.0)) * tangent_right
            try:
                if tangent_1.length > chord_len * 1.5:
                    tangent_1 = tangent_1.normalized() * chord_len * 1.5
                if tangent_2.length > chord_len * 1.5:
                    tangent_2 = tangent_2.normalized() * chord_len * 1.5
            except Exception:
                pass

            t2 = t * t
            t3 = t2 * t
            h1 = 2.0 * t3 - 3.0 * t2 + 1.0
            h2 = -2.0 * t3 + 3.0 * t2
            h3 = t3 - 2.0 * t2 + t
            h4 = t3 - t2
            try:
                proposed = h1 * left_co + h2 * right_co + h3 * tangent_1 + h4 * tangent_2
                segment = _segment_for_vert(vert, preserve_axis_segments)
                new_positions[vert] = _preserve_segment_factor(vert.co.copy(), proposed, segment)
            except Exception:
                continue

        for vert, co in new_positions.items():
            try:
                if vert.is_valid and not vert.hide:
                    vert.co = co
                    moved_total += 1
            except Exception:
                continue
    return moved_total


def apply_max_flow_to_vertices(
    bm: bmesh.types.BMesh,
    target_verts: Iterable[bmesh.types.BMVert],
    *,
    iterations: int = 1,
    preserve_current_factors: bool = False,
    preserve_axis_segments: Optional[Mapping[object, Tuple[Vector, Vector]]] = None,
) -> int:
    """Approximate a 3ds Max style Set Flow / Flow Connect fit.

    This variant treats the nearest unselected neighbours on the same flow path as
    the segment being rebuilt and uses the next outer vertices as Catmull-Rom
    controls.  It differs from the legacy algorithm by matching the surrounding
    curve directly instead of using the legacy tangent weighting.
    """
    try:
        selected_set = {v for v in target_verts if v is not None and v.is_valid and not v.hide}
    except Exception:
        selected_set = set()
    if not selected_set:
        return 0

    moved_total = 0
    for _iteration in range(max(1, int(iterations or 1))):
        new_positions: Dict[bmesh.types.BMVert, Vector] = {}
        for vert in list(selected_set):
            try:
                if not vert.is_valid or vert.hide:
                    continue
                best_full_path = _find_best_flow_path(vert, selected_set)
                if not best_full_path:
                    continue
                anchors = _path_anchors_for_vert(best_full_path, vert, selected_set)
                if anchors is None:
                    continue
                idx_vert, idx_left, idx_right = anchors
                num_segments = float(idx_right - idx_left)
                fallback_t = float(idx_vert - idx_left) / num_segments if num_segments > 0.0 else 0.5
                p1 = best_full_path[idx_left].co.copy()
                p2 = best_full_path[idx_right].co.copy()
                p0 = best_full_path[idx_left - 1].co.copy() if idx_left >= 1 else p1 + (p1 - best_full_path[idx_left + 1].co)
                p3 = best_full_path[idx_right + 1].co.copy() if idx_right + 1 < len(best_full_path) else p2 + (p2 - best_full_path[idx_right - 1].co)
            except Exception:
                continue
            t = _flow_factor_from_current_position(vert, p1, p2, fallback_t) if preserve_current_factors else fallback_t
            try:
                proposed = _catmull_rom(p0, p1, p2, p3, t)
                chord = p2 - p1
                # Clamp runaway tangents on very uneven topology while still
                # retaining the rounded surface-fit character.
                chord_len = float(chord.length)
                if chord_len > 1.0e-12:
                    offset = proposed - p1
                    if offset.length > chord_len * 2.5:
                        proposed = p1 + offset.normalized() * chord_len * 2.5
                segment = _segment_for_vert(vert, preserve_axis_segments)
                new_positions[vert] = _preserve_segment_factor(vert.co.copy(), proposed, segment)
            except Exception:
                continue

        for vert, co in new_positions.items():
            try:
                if vert.is_valid and not vert.hide:
                    vert.co = co
                    moved_total += 1
            except Exception:
                continue
    return moved_total


def _edgeflow_vertex_topology_safe(vert) -> bool:
    """Return whether EdgeFlow's radial-loop traversal is safe for this vertex.

    The bundled EdgeFlow algorithm assumes a manifold quad neighbourhood.  On
    ngons, non-manifold radial cycles, or partially rebuilt edit topology, its
    multi-hop BMLoop traversal can enter native code with an invalid topology
    assumption.  Such vertices use the Current Flow fallback instead.
    """
    try:
        if vert is None or not vert.is_valid or vert.hide:
            return False
        linked_edges = tuple(vert.link_edges)
    except Exception:
        return False

    usable = False
    for edge in linked_edges:
        try:
            if not edge.is_valid or edge.hide or edge.is_boundary:
                continue
            if not edge.is_manifold:
                return False
            faces = tuple(edge.link_faces)
            loops = tuple(edge.link_loops)
            if len(faces) != 2 or len(loops) != 2:
                return False
            if any(
                face is None or not face.is_valid or face.hide or len(face.verts) != 4
                for face in faces
            ):
                return False
            usable = True
        except Exception:
            return False
    return usable


def _edgeflow_local_result_for_vert(vert, min_angle: float = 0.0, tension: float = 1.8):
    """Compute the same local Hermite target used by EdgeFlow's Loop.set_flow()."""
    proposals: List[Vector] = []
    if not _edgeflow_vertex_topology_safe(vert):
        return None
    try:
        linked_edges = [
            e for e in vert.link_edges
            if e.is_valid and not e.hide and not e.is_boundary and e.is_manifold
        ]
    except Exception:
        linked_edges = []

    for edge in linked_edges:
        try:
            for loop in edge.link_loops:
                center = edge.other_vert(loop.vert)
                if center is not vert:
                    continue
                ring1 = loop.link_loop_next.link_loop_next
                ring2 = loop.link_loop_radial_prev.link_loop_prev.link_loop_prev
                p1 = None
                p2 = ring1.vert
                p3 = ring2.link_loop_radial_next.vert
                p4 = None
                if not ring1.edge.is_boundary:
                    final = ring1.link_loop_radial_next.link_loop_next
                    a, b = final.edge.verts
                    p1 = b.co if p2 == a else a.co
                    a_vec = (p1 - p2.co).normalized()
                    b_vec = (center.co - p2.co).normalized()
                    dot = min(1.0, max(-1.0, a_vec.dot(b_vec)))
                    angle = math.acos(dot)
                    if angle < min_angle:
                        p1 = p2.co - (p3.co - p2.co) * 0.5
                else:
                    p1 = p2.co - (p3.co - p2.co)

                if not ring2.edge.is_boundary:
                    final = ring2.link_loop_radial_prev.link_loop_prev
                    a, b = final.edge.verts
                    p4 = b.co if p3 == a else a.co
                    a_vec = (p4 - p3.co).normalized()
                    b_vec = (center.co - p3.co).normalized()
                    dot = min(1.0, max(-1.0, a_vec.dot(b_vec)))
                    angle = math.acos(dot)
                    if angle < min_angle:
                        p4 = p3.co - (p2.co - p3.co) * 0.5
                else:
                    p3 = ring2.edge.other_vert(p3)
                    p4 = p3.co - (p2.co - p3.co)

                if p1 is None or p4 is None or p1 == p2.co or p3.co == p4:
                    continue
                d = (p2.co - p3.co).length * 0.5
                if d <= 1.0e-12:
                    continue
                p1n = p2.co + (d * (p1 - p2.co).normalized())
                p4n = p3.co + (d * (p4 - p3.co).normalized())
                proposals.append(_hermite_3d(p1n, p2.co, p3.co, p4n, 0.5, -float(tension), 0.0))
        except Exception:
            continue
    if not proposals:
        return None
    try:
        total = Vector((0.0, 0.0, 0.0))
        for co in proposals:
            total += co
        return total / float(len(proposals))
    except Exception:
        return proposals[0]


def _hermite_3d(p1: Vector, p2: Vector, p3: Vector, p4: Vector, mu: float, tension: float, bias: float) -> Vector:
    # Equivalent to EdgeFlow interpolate.hermite_3d for one Vector result.
    mu = float(mu)
    mu2 = mu * mu
    mu3 = mu2 * mu
    m0 = (p2 - p1) * (1.0 + bias) * (1.0 - tension) / 2.0
    m0 += (p3 - p2) * (1.0 - bias) * (1.0 - tension) / 2.0
    m1 = (p3 - p2) * (1.0 + bias) * (1.0 - tension) / 2.0
    m1 += (p4 - p3) * (1.0 - bias) * (1.0 - tension) / 2.0
    a0 = 2.0 * mu3 - 3.0 * mu2 + 1.0
    a1 = mu3 - 2.0 * mu2 + mu
    a2 = mu3 - mu2
    a3 = -2.0 * mu3 + 3.0 * mu2
    return (a0 * p2) + (a1 * m0) + (a2 * m1) + (a3 * p3)


def apply_edgeflow_to_vertices(
    bm: bmesh.types.BMesh,
    target_verts: Iterable[bmesh.types.BMVert],
    *,
    iterations: int = 8,
    tension: float = 1.8,
    min_angle: float = 0.0,
    preserve_axis_segments: Optional[Mapping[object, Tuple[Vector, Vector]]] = None,
) -> int:
    try:
        selected_set = {v for v in target_verts if v is not None and v.is_valid and not v.hide}
    except Exception:
        selected_set = set()
    if not selected_set:
        return 0

    moved_total = 0
    for _iteration in range(max(1, int(iterations or 1))):
        new_positions: Dict[bmesh.types.BMVert, Vector] = {}
        for vert in list(selected_set):
            try:
                if not vert.is_valid or vert.hide:
                    continue
                proposed = _edgeflow_local_result_for_vert(vert, min_angle=float(min_angle), tension=float(tension))
                if proposed is None:
                    continue
                segment = _segment_for_vert(vert, preserve_axis_segments)
                new_positions[vert] = _preserve_segment_factor(vert.co.copy(), proposed, segment)
            except Exception:
                continue
        for vert, co in new_positions.items():
            try:
                if vert.is_valid and not vert.hide:
                    vert.co = co
                    moved_total += 1
            except Exception:
                continue
    return moved_total


def apply_edgeflow_original_to_edges(
    bm: bmesh.types.BMesh,
    edges: Iterable[bmesh.types.BMEdge],
    *,
    iterations: int = 8,
    tension: float = 1.8,
    min_angle: float = 0.0,
) -> int:
    """Run the bundled EdgeFlow loop implementation on explicit edges.

    This is used as a secondary path.  The vertex-local EdgeFlow implementation
    above is preferred when Mesh Connect must preserve the existing cut factor.
    """
    try:
        from .edgeflow import util as edgeflow_util
    except Exception:
        edgeflow_util = None
    if edgeflow_util is None:
        return 0
    try:
        edge_list = [e for e in edges if e is not None and e.is_valid and not e.hide]
    except Exception:
        edge_list = []
    if not edge_list:
        return 0
    moved = 0
    try:
        loops = edgeflow_util.get_edgeloops(bm, edge_list)
    except Exception:
        loops = []
    for _iteration in range(max(1, int(iterations or 1))):
        for loop in loops:
            try:
                before = [v.co.copy() for v in loop.verts]
                loop.set_flow(tension=float(tension), min_angle=float(min_angle))
                for vert, old_co in zip(loop.verts, before):
                    try:
                        if (vert.co - old_co).length_squared > 1.0e-16:
                            moved += 1
                    except Exception:
                        pass
            except Exception:
                continue
    return moved


def apply_flow_algorithm_to_vertices(
    bm: bmesh.types.BMesh,
    target_verts: Iterable[bmesh.types.BMVert],
    *,
    algorithm: str = FLOW_ALGORITHM_CURRENT,
    iterations: int = 1,
    preserve_current_factors: bool = False,
    preserve_axis_segments: Optional[Mapping[object, Tuple[Vector, Vector]]] = None,
) -> int:
    algorithm = normalize_flow_algorithm(algorithm)
    try:
        target_list = [
            vert for vert in tuple(target_verts or ())
            if vert is not None and vert.is_valid and not vert.hide
        ]
    except Exception:
        target_list = []
    if algorithm == FLOW_ALGORITHM_MAX:
        return apply_max_flow_to_vertices(
            bm,
            target_list,
            iterations=max(1, int(iterations or 1)),
            preserve_current_factors=preserve_current_factors,
            preserve_axis_segments=preserve_axis_segments,
        )
    if algorithm == FLOW_ALGORITHM_EDGEFLOW:
        safe_verts = [vert for vert in target_list if _edgeflow_vertex_topology_safe(vert)]
        safe_set = set(safe_verts)
        fallback_verts = [vert for vert in target_list if vert not in safe_set]
        moved = 0
        if safe_verts:
            moved += apply_edgeflow_to_vertices(
                bm,
                safe_verts,
                iterations=max(1, int(iterations or 8)),
                tension=1.8,
                min_angle=0.0,
                preserve_axis_segments=preserve_axis_segments,
            )
        if fallback_verts:
            # Preserve functionality on non-quad/non-manifold selections without
            # entering EdgeFlow's unsafe radial-loop path.
            moved += apply_current_flow_to_vertices(
                bm,
                fallback_verts,
                iterations=1,
                preserve_current_factors=True,
                preserve_axis_segments=preserve_axis_segments,
            )
        return moved
    return apply_current_flow_to_vertices(
        bm,
        target_list,
        iterations=max(1, int(iterations or 1)),
        preserve_current_factors=preserve_current_factors,
        preserve_axis_segments=preserve_axis_segments,
    )
