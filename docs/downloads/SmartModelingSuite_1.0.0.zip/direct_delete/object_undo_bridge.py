# -*- coding: utf-8 -*-
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

"""Directional Global-Undo bridge for Direct Delete object operations.

Blender's Global Undo restores deleted objects correctly, but object selection
changes made immediately before each Direct Delete click are not guaranteed to
be separate Undo states.  Pushing both a before and after state for every click
creates an extra visible step.  This bridge instead creates one baseline state
when first used and exactly one post-change state per click.  A hidden Scene RNA
token travels with Global Undo and event-only Undo/Redo handlers restore the
selection snapshot belonging to that exact click.

The bridge is also reused by ``Delete History (Remove Modifiers)`` because that
operation has the same Object-mode selection/history boundary.  It uses no
polling timer, frame handler, draw handler, key monitor, or background thread.
"""

from __future__ import annotations

import secrets

import bpy


_NS_KEY = "SMART_MODELING_DIRECT_DELETE_OBJECT_UNDO_BRIDGE"
_PROP_PREFIX = "jel_sms_direct_delete_object_token_"
_HANDLER_NAMES = {"_undo_post", "_redo_post", "_load_pre"}
_MAX_OPERATIONS = 2048
_MAX_TOKEN = 2_000_000_000


def _id_uid(id_data) -> int:
    try:
        return int(getattr(id_data, "session_uid", 0) or 0)
    except Exception:
        return 0


def _state(create: bool = True):
    try:
        namespace = bpy.app.driver_namespace
    except Exception:
        return None
    state = namespace.get(_NS_KEY)
    if not isinstance(state, dict):
        if not create:
            return None
        state = {
            "property_name": f"{_PROP_PREFIX}{secrets.token_hex(6)}",
            "next_token": 1,
            "current_token": 0,
            "last_scene_id": "",
            "operations": {},
            "order": [],
            "scenes": {},
            "syncing": False,
            "shutdown": False,
            "shutdown_callback": shutdown,
        }
        namespace[_NS_KEY] = state
    prop_name = str(state.get("property_name") or "")
    if not prop_name.startswith(_PROP_PREFIX):
        state["property_name"] = f"{_PROP_PREFIX}{secrets.token_hex(6)}"
    state.setdefault("next_token", 1)
    state.setdefault("current_token", 0)
    state.setdefault("last_scene_id", "")
    state.setdefault("operations", {})
    state.setdefault("order", [])
    state.setdefault("scenes", {})
    state.setdefault("syncing", False)
    state.setdefault("shutdown", False)
    state["shutdown_callback"] = shutdown
    return state


def _property_name() -> str:
    state = _state(True)
    return str(state.get("property_name") or "") if state else ""


def _ensure_property() -> bool:
    name = _property_name()
    if not name:
        return False
    try:
        if not hasattr(bpy.types.Scene, name):
            setattr(
                bpy.types.Scene,
                name,
                bpy.props.IntProperty(
                    name="Direct Delete Object Undo Token",
                    description="Internal runtime token used to keep Direct Delete object operations atomic.",
                    default=0,
                    options={"HIDDEN", "SKIP_SAVE"},
                ),
            )
        return hasattr(bpy.types.Scene, name)
    except Exception:
        return False


def _scene_token(scene=None) -> int:
    scene = scene or getattr(bpy.context, "scene", None)
    name = _property_name()
    if scene is None or not name:
        return 0
    try:
        return int(getattr(scene, name, 0) or 0)
    except Exception:
        return 0


def _set_scene_token(token: int, scene=None) -> bool:
    scene = scene or getattr(bpy.context, "scene", None)
    name = _property_name()
    if scene is None or not name or not _ensure_property():
        return False
    try:
        setattr(scene, name, max(0, int(token)))
        return True
    except Exception:
        return False


def _object_record(obj) -> dict:
    return {
        "name": str(getattr(obj, "name_full", "") or getattr(obj, "name", "") or ""),
        "uid": _id_uid(obj),
    }


def _scene_record(scene) -> dict:
    return {
        "name": str(getattr(scene, "name_full", "") or getattr(scene, "name", "") or ""),
        "uid": _id_uid(scene),
    }


def _scene_key(scene) -> str:
    return f"{_id_uid(scene)}:{str(getattr(scene, 'name_full', '') or getattr(scene, 'name', '') or '')}"


def _scene_entry(scene, create: bool = True):
    state = _state(create)
    if state is None or scene is None:
        return None
    key = _scene_key(scene)
    entry = state["scenes"].get(key)
    if not isinstance(entry, dict):
        uid = _id_uid(scene)
        name = str(getattr(scene, "name_full", "") or getattr(scene, "name", "") or "")
        for old_key, candidate in tuple(state["scenes"].items()):
            same_uid = bool(uid and int(candidate.get("uid") or 0) == uid)
            same_name = bool(name and str(candidate.get("name") or "") == name)
            if not (same_uid or same_name):
                continue
            entry = candidate
            if old_key != key:
                state["scenes"].pop(old_key, None)
                state["scenes"][key] = entry
            break
        if not isinstance(entry, dict):
            if not create:
                return None
            entry = {
                "name": str(scene.name),
                "uid": uid,
                "history_id": secrets.token_hex(8),
                "current_token": 0,
                "baseline_ready": False,
            }
            state["scenes"][key] = entry
    entry["name"] = str(scene.name)
    entry["uid"] = _id_uid(scene)
    entry.setdefault("history_id", secrets.token_hex(8))
    entry.setdefault("current_token", 0)
    entry.setdefault("baseline_ready", False)
    entry["key"] = key
    return entry


def _resolve_object(record):
    if not isinstance(record, dict):
        return None
    name = str(record.get("name") or "")
    uid = int(record.get("uid") or 0)
    obj = bpy.data.objects.get(name) if name else None
    if obj is not None and (not uid or _id_uid(obj) == uid):
        return obj
    if uid:
        for candidate in bpy.data.objects:
            if _id_uid(candidate) == uid:
                record["name"] = str(candidate.name)
                return candidate
    return obj


def _capture_selection(context=None) -> dict:
    context = context or bpy.context
    selected = []
    try:
        selected = [_object_record(obj) for obj in tuple(getattr(context, "selected_objects", ()) or ()) if obj is not None]
    except Exception:
        selected = []
    try:
        active = context.view_layer.objects.active
        active_record = _object_record(active) if active is not None else None
    except Exception:
        active_record = None
    try:
        mode = str(getattr(context, "mode", "OBJECT") or "OBJECT")
    except Exception:
        mode = "OBJECT"
    return {
        "selected": tuple(selected),
        "active": active_record,
        "mode": mode,
    }


def _apply_selection(payload) -> bool:
    if not isinstance(payload, dict):
        return False
    context = bpy.context
    try:
        if str(getattr(context, "mode", "OBJECT") or "OBJECT") != "OBJECT":
            return False
    except Exception:
        return False
    try:
        for obj in tuple(context.view_layer.objects):
            try:
                obj.select_set(False)
            except Exception:
                pass
    except Exception:
        pass
    changed = False
    for record in tuple(payload.get("selected") or ()):
        obj = _resolve_object(record)
        if obj is None:
            continue
        try:
            obj.select_set(True)
            changed = True
        except Exception:
            pass
    active = _resolve_object(payload.get("active"))
    try:
        context.view_layer.objects.active = active
        changed = True
    except Exception:
        pass
    return changed


def _is_handler(function) -> bool:
    try:
        module_name = str(getattr(function, "__module__", "") or "")
        function_name = str(getattr(function, "__name__", "") or "")
    except Exception:
        return False
    return module_name.endswith(".direct_delete.object_undo_bridge") and function_name in _HANDLER_NAMES


def ensure() -> bool:
    state = _state(True)
    if state is None or not _ensure_property():
        return False
    state["shutdown"] = False
    for collection, current in (
        (bpy.app.handlers.undo_post, _undo_post),
        (bpy.app.handlers.redo_post, _redo_post),
        (bpy.app.handlers.load_pre, _load_pre),
    ):
        for function in tuple(collection):
            if function is current:
                continue
            if _is_handler(function):
                try:
                    collection.remove(function)
                except Exception:
                    pass
        if current not in collection:
            collection.append(current)
    return True


def _next_token() -> int:
    state = _state(True)
    if state is None:
        return 0
    token = int(state.get("next_token") or 1)
    if token <= 0 or token > _MAX_TOKEN:
        token = 1
    state["next_token"] = token + 1
    return token


def _prune_future(state, scene_id: str, current_token: int) -> None:
    operations = state.get("operations", {})
    removed = set()
    for token, operation in tuple(operations.items()):
        if str(operation.get("scene_id") or "") != str(scene_id or ""):
            continue
        if int(token) > int(current_token):
            operations.pop(token, None)
            removed.add(int(token))
    state["order"] = [int(token) for token in state.get("order", ()) if int(token) not in removed]


def begin(context=None):
    """Prepare one Object-mode operation and return a transaction record."""
    context = context or bpy.context
    try:
        if str(getattr(context, "mode", "OBJECT") or "OBJECT") != "OBJECT":
            return None
    except Exception:
        return None
    if not ensure():
        return None
    state = _state(True)
    scene = getattr(context, "scene", None)
    scene_entry = _scene_entry(scene, create=True)
    if not isinstance(scene_entry, dict):
        return None
    scene_id = str(scene_entry.get("history_id") or "")
    current_token = _scene_token(scene)
    operation = state.get("operations", {}).get(current_token) if current_token else None
    if current_token and (not isinstance(operation, dict) or str(operation.get("scene_id") or "") != scene_id):
        current_token = int(scene_entry.get("current_token") or 0)
    _prune_future(state, scene_id, current_token)
    before = _capture_selection(context)
    # Global Undo also stores the active Scene.  When the user switches to a
    # different Scene between Direct Delete clicks, the top Undo state still
    # belongs to the previously active Scene.  Push one click-before baseline
    # for that Scene transition so the next Ctrl+Z returns to the exact Scene,
    # selection, and active object that existed immediately before this click.
    need_baseline = (
        not bool(scene_entry.get("baseline_ready"))
        or str(state.get("last_scene_id") or "") != scene_id
    )
    if need_baseline:
        if not _set_scene_token(current_token, scene):
            return None
        try:
            bpy.ops.ed.undo_push(message="Direct Delete Object Baseline")
        except Exception:
            return None
        scene_entry["baseline_ready"] = True
        state["last_scene_id"] = scene_id
    token = _next_token()
    if token <= 0:
        return None
    state["current_token"] = current_token
    scene_entry["current_token"] = current_token
    return {
        "scene": scene,
        "scene_record": _scene_record(scene),
        "scene_id": scene_id,
        "before_token": current_token,
        "after_token": token,
        "before": before,
    }


def commit(record, context=None, *, message="Direct Delete Objects") -> bool:
    """Record one Object-mode mutation and create exactly one visible step."""
    if not isinstance(record, dict):
        return False
    state = _state(False)
    if not state:
        return False
    context = context or bpy.context
    token = int(record.get("after_token") or 0)
    if token <= 0:
        return False
    scene = record.get("scene") or getattr(context, "scene", None)
    after = _capture_selection(context)
    if not _set_scene_token(token, scene):
        return False
    scene_entry = _scene_entry(scene, create=True)
    scene_id = str(record.get("scene_id") or (scene_entry.get("history_id") if isinstance(scene_entry, dict) else ""))
    operation = {
        "scene_id": scene_id,
        "scene": record.get("scene_record") or _scene_record(scene),
        "before_token": int(record.get("before_token") or 0),
        "after_token": token,
        "before": record.get("before"),
        "after": after,
    }
    state["operations"][token] = operation
    order = state.setdefault("order", [])
    if token in order:
        order.remove(token)
    order.append(token)
    while len(order) > _MAX_OPERATIONS:
        old = int(order.pop(0))
        state["operations"].pop(old, None)
    state["current_token"] = token
    state["last_scene_id"] = scene_id
    if isinstance(scene_entry, dict):
        scene_entry["current_token"] = token
    try:
        bpy.ops.ed.undo_push(message=str(message or "Direct Delete Objects"))
        return True
    except Exception:
        return False


def rollback(record) -> None:
    if not isinstance(record, dict):
        return
    state = _state(False)
    if not state:
        return
    token = int(record.get("after_token") or 0)
    state.get("operations", {}).pop(token, None)
    try:
        state.get("order", []).remove(token)
    except Exception:
        pass
    previous = int(record.get("before_token") or 0)
    state["current_token"] = previous
    scene_entry = _scene_entry(record.get("scene"), create=False)
    if isinstance(scene_entry, dict):
        scene_entry["current_token"] = previous
    _set_scene_token(previous, record.get("scene"))
    _apply_selection(record.get("before"))


def _undo_post(_dummy=None):
    state = _state(False)
    if not state or state.get("shutdown") or state.get("syncing"):
        return
    scene = getattr(bpy.context, "scene", None)
    scene_entry = _scene_entry(scene, create=False)
    if not isinstance(scene_entry, dict):
        return
    scene_id = str(scene_entry.get("history_id") or "")
    previous = int(scene_entry.get("current_token") or 0)
    if previous <= 0:
        return
    operation = state.get("operations", {}).get(previous)
    if not isinstance(operation, dict) or str(operation.get("scene_id") or "") != scene_id:
        return
    target = _scene_token(scene)
    if target != int(operation.get("before_token") or 0):
        return
    state["syncing"] = True
    try:
        _apply_selection(operation.get("before"))
        scene_entry["current_token"] = target
        state["current_token"] = target
        state["last_scene_id"] = scene_id
        state["last_scene_id"] = scene_id
    finally:
        state["syncing"] = False


def _redo_post(_dummy=None):
    state = _state(False)
    if not state or state.get("shutdown") or state.get("syncing"):
        return
    scene = getattr(bpy.context, "scene", None)
    scene_entry = _scene_entry(scene, create=False)
    if not isinstance(scene_entry, dict):
        return
    scene_id = str(scene_entry.get("history_id") or "")
    current = int(scene_entry.get("current_token") or 0)
    target = _scene_token(scene)
    candidates = [
        operation for operation in state.get("operations", {}).values()
        if str(operation.get("scene_id") or "") == scene_id
        and int(operation.get("before_token") or 0) == current
        and int(operation.get("after_token") or 0) == target
    ]
    if not candidates:
        return
    operation = candidates[0]
    state["syncing"] = True
    try:
        _apply_selection(operation.get("after"))
        scene_entry["current_token"] = target
        state["current_token"] = target
    finally:
        state["syncing"] = False


def _load_pre(_dummy=None):
    # Loading a file discards Blender's current Global Undo stack.  Tear down
    # the bridge entirely so a stale token cannot be associated with the next
    # file.  The feature lazily creates a fresh bridge on its next use.
    shutdown()


def shutdown() -> None:
    state = _state(False)
    if state:
        state["shutdown"] = True
    for collection, current in (
        (bpy.app.handlers.undo_post, _undo_post),
        (bpy.app.handlers.redo_post, _redo_post),
        (bpy.app.handlers.load_pre, _load_pre),
    ):
        for function in tuple(collection):
            if function is current or _is_handler(function):
                try:
                    collection.remove(function)
                except Exception:
                    pass
    name = str(state.get("property_name") or "") if isinstance(state, dict) else ""
    if name:
        try:
            if hasattr(bpy.types.Scene, name):
                delattr(bpy.types.Scene, name)
        except Exception:
            pass
    try:
        bpy.app.driver_namespace.pop(_NS_KEY, None)
    except Exception:
        pass


__all__ = ("begin", "commit", "rollback", "ensure", "shutdown")
