# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

import bpy
import gpu
from gpu_extras.batch import batch_for_shader
from mathutils import Vector
from bpy.props import EnumProperty


_NUMERAL_SEGMENTS = (
    ((0, 0), (0, 2), (0, 2), (1, 2), (1, 2), (1, 0), (1, 0), (0, 0)),
    ((0, 1), (1, 2), (1, 2), (1, 0)),
    ((0, 2), (1, 2), (1, 2), (1, 1), (1, 1), (0, 0), (0, 0), (1, 0)),
    ((0, 2), (1, 2), (1, 2), (0, 1), (0, 1), (1, 1), (1, 1), (0, 0)),
    ((0, 2), (0, 1), (0, 1), (1, 1), (1, 1), (1, 2), (1, 2), (1, 0)),
    ((1, 2), (0, 2), (0, 2), (0, 1), (0, 1), (1, 1), (1, 1), (1, 0), (1, 0), (0, 0)),
    ((1, 2), (0, 1), (0, 1), (0, 0), (0, 0), (1, 0), (1, 0), (1, 1), (1, 1), (0, 1)),
    ((0, 2), (1, 2), (1, 2), (0, 1), (0, 1), (0, 0)),
    ((0, 1), (0, 2), (0, 2), (1, 2), (1, 2), (1, 0), (1, 0), (0, 0), (0, 0), (0, 1), (0, 1), (1, 1)),
    ((0, 0), (1, 1), (1, 1), (1, 2), (1, 2), (0, 2), (0, 2), (0, 1), (0, 1), (1, 1)),
)


class _SequenceDrawSnapshot:
    __slots__ = ("shader", "batches", "color", "line_width")

    def __init__(self):
        self.shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        self.batches = ()
        self.color = (1.0, 1.0, 1.0, 1.0)
        self.line_width = 1.0

    def clear(self):
        self.batches = ()


def draw_number(number, coordinate, font_height):
    return [
        Vector((x * font_height, y * font_height, 0.0)) + coordinate
        for x, y in _NUMERAL_SEGMENTS[int(number)]
    ]


def _build_sequence_snapshot(snapshot, splines, sequence_color, font_thickness, font_size, matrix_world):
    shader = snapshot.shader
    batches = []
    digit_spacing = font_size * 1.5
    for number, spline in enumerate(splines):
        if spline.type == 'BEZIER':
            if not spline.bezier_points:
                continue
            origin = matrix_world @ spline.bezier_points[0].co
        else:
            if not spline.points:
                continue
            point = matrix_world @ spline.points[0].co
            origin = Vector((point.x, point.y, point.z))

        for digit_index, digit in enumerate(str(number)):
            coordinate = origin + Vector((digit_index * digit_spacing, 0.0, 0.0))
            points = draw_number(int(digit), coordinate, font_size)
            if points:
                batches.append(batch_for_shader(shader, 'LINES', {"pos": points}))

    snapshot.batches = tuple(batches)
    snapshot.color = tuple(sequence_color)
    snapshot.line_width = float(font_thickness)


def draw(snapshot):
    """Draw prebuilt numeral batches only; no spline/RNA traversal occurs here."""
    if snapshot is None or not snapshot.batches:
        return
    try:
        shader = snapshot.shader
        gpu.state.line_width_set(snapshot.line_width)
        shader.bind()
        shader.uniform_float("color", snapshot.color)
        for batch in snapshot.batches:
            batch.draw(shader)
    except Exception:
        return
    finally:
        try:
            gpu.state.line_width_set(1.0)
        except Exception:
            pass


class ShowSplinesSequence(bpy.types.Operator):
    bl_idname = "curvetools.show_splines_sequence"
    bl_label = "Show Splines Sequence"
    bl_options = set()
    _sms_no_undo = True
    bl_description = "Show Splines Sequence / [ESC] - remove"

    def _remove_handlers(self):
        for handler in tuple(getattr(self, "handlers", ())):
            try:
                bpy.types.SpaceView3D.draw_handler_remove(handler, 'WINDOW')
            except Exception:
                pass
        self.handlers = []
        snapshot = getattr(self, "_draw_snapshot", None)
        if snapshot is not None:
            snapshot.clear()

    def _refresh_snapshot(self, context):
        obj = getattr(context, "active_object", None)
        scene = getattr(context, "scene", None)
        settings = getattr(scene, "curvetools", None) if scene is not None else None
        if obj is None or obj.type != 'CURVE' or settings is None:
            return False
        _build_sequence_snapshot(
            self._draw_snapshot,
            obj.data.splines,
            settings.sequence_color,
            settings.font_thickness,
            settings.font_size,
            obj.matrix_world.copy(),
        )
        return True

    def modal(self, context, event):
        if event.type == 'ESC' and event.value == 'PRESS':
            self._remove_handlers()
            if context.area is not None:
                context.area.tag_redraw()
            return {'CANCELLED'}

        if event.value == 'RELEASE' or event.type not in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE', 'TIMER'}:
            if self._refresh_snapshot(context) and context.area is not None:
                context.area.tag_redraw()
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        if context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "View3D not found, cannot run operator")
            return {'CANCELLED'}

        self.handlers = []
        self._draw_snapshot = _SequenceDrawSnapshot()
        if not self._refresh_snapshot(context):
            return {'CANCELLED'}

        handler = bpy.types.SpaceView3D.draw_handler_add(
            draw,
            (self._draw_snapshot,),
            'WINDOW',
            'POST_VIEW',
        )
        self.handlers.append(handler)
        context.window_manager.modal_handler_add(self)
        context.area.tag_redraw()
        return {'RUNNING_MODAL'}

    def cancel(self, context):
        self._remove_handlers()

    @classmethod
    def poll(cls, context):
        return context.object is not None and context.object.type == 'CURVE'



# ------------------------------------------------------------
# RearrangeSpline

def rearrangesplines(dataCurve, select_spline1, select_spline2):
    spline1 = dataCurve.splines[select_spline1]
    spline2 = dataCurve.splines[select_spline2]

    bpy.ops.curve.select_all(action='SELECT')
    bpy.ops.curve.spline_type_set(type='BEZIER')
    bpy.ops.curve.select_all(action='DESELECT')

    type1 = spline1.type
    type2 = spline2.type

    len_spline1 = len(spline1.bezier_points)
    len_spline2 = len(spline2.bezier_points)

    newSpline = dataCurve.splines.new(type=type1)
    newSpline.bezier_points.add(len_spline1 - 1)
    newSpline.use_cyclic_u = spline1.use_cyclic_u
    for n in range(0, len_spline1):
        newSpline.bezier_points[n].co = spline1.bezier_points[n].co
        newSpline.bezier_points[n].handle_left_type = spline1.bezier_points[n].handle_left_type
        newSpline.bezier_points[n].handle_left = spline1.bezier_points[n].handle_left
        newSpline.bezier_points[n].handle_right_type = spline1.bezier_points[n].handle_right_type
        newSpline.bezier_points[n].handle_right = spline1.bezier_points[n].handle_right
        spline1.bezier_points[n].select_control_point = True

    spline1.bezier_points[0].select_control_point = False
    spline1.bezier_points[0].select_left_handle = False
    spline1.bezier_points[0].select_right_handle = False
    bpy.ops.curve.delete(type='VERT')

    spline1.bezier_points[0].select_control_point = True
    bpy.ops.curve.spline_type_set(type=type2)

    bpy.ops.curve.select_all(action='DESELECT')

    spline1.bezier_points.add(len_spline2 - 1)
    spline1.use_cyclic_u = spline2.use_cyclic_u
    for n in range(0, len_spline2):
        spline1.bezier_points[n].co = spline2.bezier_points[n].co
        spline1.bezier_points[n].handle_left_type = spline2.bezier_points[n].handle_left_type
        spline1.bezier_points[n].handle_left = spline2.bezier_points[n].handle_left
        spline1.bezier_points[n].handle_right_type = spline2.bezier_points[n].handle_right_type
        spline1.bezier_points[n].handle_right = spline2.bezier_points[n].handle_right
        spline1.bezier_points[n].select_control_point = False
        spline1.bezier_points[n].select_left_handle = False
        spline1.bezier_points[n].select_right_handle = False
        spline2.bezier_points[n].select_control_point = True

    spline2.bezier_points[0].select_control_point = False
    spline2.bezier_points[0].select_left_handle = False
    spline2.bezier_points[0].select_right_handle = False
    bpy.ops.curve.delete(type='VERT')

    spline2.bezier_points[0].select_control_point = True
    bpy.ops.curve.spline_type_set(type=type1)

    spline2.bezier_points.add(len_spline1 - 1)
    spline2.use_cyclic_u = newSpline.use_cyclic_u
    for m in range(0, len_spline1):
        spline2.bezier_points[m].co = newSpline.bezier_points[m].co
        spline2.bezier_points[m].handle_left_type = newSpline.bezier_points[m].handle_left_type
        spline2.bezier_points[m].handle_left = newSpline.bezier_points[m].handle_left
        spline2.bezier_points[m].handle_right_type = newSpline.bezier_points[m].handle_right_type
        spline2.bezier_points[m].handle_right = newSpline.bezier_points[m].handle_right

    bpy.ops.curve.select_all(action='DESELECT')
    for point in newSpline.bezier_points:
        point.select_control_point = True
    bpy.ops.curve.delete(type='VERT')

    spline2.bezier_points[0].select_control_point = True


def rearrange(dataCurve, select_spline, command):
    len_splines = len(dataCurve.splines)
    if command == 'NEXT':
        if select_spline < len_splines - 1:
            rearrangesplines(dataCurve, select_spline + 1, select_spline)

    if command == 'PREV':
        if select_spline > 0:
            rearrangesplines(dataCurve, select_spline, select_spline - 1)


class RearrangeSpline(bpy.types.Operator):
    bl_idname = "curvetools.rearrange_spline"
    bl_label = "Rearrange Spline"
    bl_description = "Rearrange Spline"
    bl_options = {'UNDO'}

    Types = [('NEXT', "Next", "next"),
             ('PREV', "Prev", "prev")]
    command: EnumProperty(
        name="command",
        description="Command (prev or next)",
        items=Types,
    )

    def execute(self, context):
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.context.view_layer.update()

        dataCurve = context.active_object.data
        splines = context.active_object.data.splines
        select_spline = 0

        sn = 0
        for spline in splines:
            for bezier_points in spline.bezier_points:
                if bezier_points.select_control_point:
                    select_spline = sn
            sn += 1

        sn = 0
        for spline in splines:
            for point in spline.points:
                if point.select:
                    select_spline = sn
            sn += 1

        rearrange(dataCurve, select_spline, self.command)
        return {'FINISHED'}

    @classmethod
    def poll(cls, context):
        return context.object is not None and context.object.type == 'CURVE'


operators = [ShowSplinesSequence, RearrangeSpline]

def register():
    for cls in operators:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(operators):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
