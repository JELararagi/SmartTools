# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

import bpy
import gpu
from gpu_extras.batch import batch_for_shader
from mathutils.geometry import interpolate_bezier


class _ResolutionDrawSnapshot:
    __slots__ = ("shader", "batches", "color")

    def __init__(self):
        self.shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        self.batches = ()
        self.color = (1.0, 1.0, 1.0, 1.0)

    def clear(self):
        self.batches = ()


def get_points(spline, matrix_world):
    bezier_points = spline.bezier_points
    if len(bezier_points) < 2:
        return []

    resolution = spline.resolution_u + 1
    if resolution < 2:
        return []

    segments = len(bezier_points)
    if not spline.use_cyclic_u:
        segments -= 1

    point_list = []
    for index in range(segments):
        next_index = (index + 1) % len(bezier_points)
        bezier = (
            matrix_world @ bezier_points[index].co,
            matrix_world @ bezier_points[index].handle_right,
            matrix_world @ bezier_points[next_index].handle_left,
            matrix_world @ bezier_points[next_index].co,
            resolution,
        )
        point_list.extend(interpolate_bezier(*bezier))
    return point_list


def _build_resolution_snapshot(snapshot, splines, curve_vertcolor, matrix_world):
    batches = []
    shader = snapshot.shader
    for spline in splines:
        points = get_points(spline, matrix_world)
        if points:
            batches.append(batch_for_shader(shader, 'POINTS', {"pos": points}))
    snapshot.batches = tuple(batches)
    snapshot.color = tuple(curve_vertcolor)


def draw(snapshot):
    """Draw prebuilt GPU batches only; curve evaluation happens in modal code."""
    if snapshot is None or not snapshot.batches:
        return
    try:
        shader = snapshot.shader
        shader.bind()
        shader.uniform_float("color", snapshot.color)
        for batch in snapshot.batches:
            batch.draw(shader)
    except Exception:
        return


class ShowCurveResolution(bpy.types.Operator):
    bl_idname = "curvetools.show_resolution"
    bl_label = "Show Curve Resolution"
    bl_options = set()
    _sms_no_undo = True
    bl_description = "Show curve Resolution / [ESC] - remove"

    def _remove_handlers(self):
        for handler in tuple(getattr(self, "handlers", ())):
            try:
                bpy.types.SpaceView3D.draw_handler_remove(handler, 'WINDOW')
            except Exception:
                pass
        self.handlers = []
        snapshot = getattr(self, "_draw_snapshot", None)
        if snapshot is not None:
            snapshot.clear()

    def _refresh_snapshot(self, context):
        obj = getattr(context, "active_object", None)
        if obj is None or obj.type != 'CURVE':
            return False
        scene = getattr(context, "scene", None)
        settings = getattr(scene, "curvetools", None) if scene is not None else None
        if settings is None:
            return False
        _build_resolution_snapshot(
            self._draw_snapshot,
            obj.data.splines,
            settings.curve_vertcolor,
            obj.matrix_world.copy(),
        )
        return True

    def modal(self, context, event):
        if event.type == 'ESC' and event.value == 'PRESS':
            self._remove_handlers()
            if context.area is not None:
                context.area.tag_redraw()
            return {'CANCELLED'}

        # Rebuild only while this explicit display operator is running and only
        # after events that can commit a curve/property change.  Draw itself is
        # a pure GPU snapshot consumer.
        if event.value == 'RELEASE' or event.type not in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE', 'TIMER'}:
            if self._refresh_snapshot(context) and context.area is not None:
                context.area.tag_redraw()
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        if context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "View3D not found, cannot run operator")
            return {'CANCELLED'}

        self.handlers = []
        self._draw_snapshot = _ResolutionDrawSnapshot()
        if not self._refresh_snapshot(context):
            return {'CANCELLED'}

        handler = bpy.types.SpaceView3D.draw_handler_add(
            draw,
            (self._draw_snapshot,),
            'WINDOW',
            'POST_VIEW',
        )
        self.handlers.append(handler)
        context.window_manager.modal_handler_add(self)
        context.area.tag_redraw()
        return {'RUNNING_MODAL'}

    def cancel(self, context):
        self._remove_handlers()

    @classmethod
    def poll(cls, context):
        return context.object is not None and context.object.type == 'CURVE'



operators = [ShowCurveResolution]

def register():
    for cls in operators:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(operators):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
