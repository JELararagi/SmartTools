# -*- coding: utf-8 -*-
# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi. All Rights Reserved.
#
#  Blender Extension / user_default compatible package
# ------------------------------------------------------------------------------
"""Compatibility shim for legacy Key Ops preference imports."""

from .preferences import KeyOpsPreferences

__all__ = ("KeyOpsPreferences",)
