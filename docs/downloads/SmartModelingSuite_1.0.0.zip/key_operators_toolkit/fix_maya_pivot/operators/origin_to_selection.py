# -*- coding: utf-8 -*-
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

"""Atomic origin tools for Object Mode and Mesh Edit Mode."""

from __future__ import annotations

import bpy
import bmesh
from bpy.types import Menu, Operator
from mathutils import Matrix, Vector

from ..utils import edit_mode_undo_bridge as _undo_bridge


_EPSILON = 1.0e-9


def _selected_world_center(context) -> Vector | None:
    total = Vector((0.0, 0.0, 0.0))
    count = 0
    for obj in _undo_bridge.capture_edit_objects(context):
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            matrix = obj.matrix_world
        except Exception:
            continue
        for vert in bm.verts:
            try:
                if vert.select and not vert.hide:
                    total += matrix @ vert.co
                    count += 1
            except Exception:
                continue
    return (total / float(count)) if count else None


def _target_world(context, operation_type: str) -> Vector | None:
    if operation_type == "origin_to_3d_cursor":
        try:
            return context.scene.cursor.location.copy()
        except Exception:
            return None
    if operation_type == "origin_to_geometry":
        return _selected_world_center(context)
    return None


def _matrix_close(a: Matrix, b: Matrix, epsilon: float = _EPSILON) -> bool:
    try:
        return all(
            abs(float(a[row][column]) - float(b[row][column])) <= epsilon
            for row in range(4)
            for column in range(4)
        )
    except Exception:
        return False


def _descendants(objects) -> tuple:
    roots = {int(obj.as_pointer()) for obj in objects if obj is not None}
    seen = set(roots)
    result = []
    queue = [(obj, 0) for obj in objects if obj is not None]
    while queue:
        parent, depth = queue.pop(0)
        try:
            children = tuple(parent.children)
        except Exception:
            children = ()
        for child in children:
            try:
                key = int(child.as_pointer())
            except Exception:
                continue
            if key in seen:
                continue
            seen.add(key)
            result.append((depth + 1, child))
            queue.append((child, depth + 1))
    result.sort(key=lambda item: item[0])
    return tuple(obj for _depth, obj in result)


def _transform_edit_bmesh(bm, transform: Matrix) -> None:
    shape_layers = []
    try:
        for name in tuple(bm.verts.layers.shape.keys()):
            layer = bm.verts.layers.shape.get(name)
            if layer is not None:
                shape_layers.append(layer)
    except Exception:
        pass
    for vert in bm.verts:
        vert.co = transform @ vert.co
        for layer in shape_layers:
            try:
                vert[layer] = transform @ vert[layer]
            except Exception:
                pass


def _origin_already_at_target(context, target: Vector) -> bool:
    active = getattr(context.view_layer.objects, "active", None)
    objects = _undo_bridge.capture_edit_objects(context)
    ordered = ([active] if active in objects else []) + [obj for obj in objects if obj is not active]
    seen_meshes = set()
    checked = False
    for obj in ordered:
        try:
            key = int(obj.data.as_pointer())
            if key in seen_meshes:
                continue
            seen_meshes.add(key)
            checked = True
            if (obj.matrix_world.translation - target).length > _EPSILON:
                return False
        except Exception:
            return False
    return checked


def _apply_edit_origin(context, target: Vector) -> bool:
    records = _undo_bridge.begin_transaction(context)
    if not records:
        return False
    active = getattr(context.view_layer.objects, "active", None)
    plans = []
    for record in records:
        mesh = record.get("mesh")
        edit_objects = tuple(record.get("edit_objects") or ())
        if mesh is None or not edit_objects:
            return False
        reference = active if active in edit_objects else edit_objects[0]
        old_reference = reference.matrix_world.copy()
        new_reference = old_reference.copy()
        new_reference.translation = target
        local_transform = new_reference.inverted_safe() @ old_reference
        if _matrix_close(local_transform, Matrix.Identity(4)):
            continue
        inverse_local = local_transform.inverted_safe()
        users = tuple(record.get("users") or ())
        descendants = _descendants(users)
        tracked = tuple(users) + tuple(descendants)
        _undo_bridge.track_transaction_objects(record, tracked)
        before = {str(obj.name): obj.matrix_world.copy() for obj in tracked}
        after = {str(obj.name): obj.matrix_world @ inverse_local for obj in users}
        after.update({str(obj.name): before[str(obj.name)].copy() for obj in descendants})
        try:
            bm = bmesh.from_edit_mesh(mesh)
        except Exception:
            return False
        plans.append({
            "record": record,
            "mesh": mesh,
            "bm": bm,
            "transform": local_transform,
            "inverse": inverse_local,
            "before": before,
            "after": after,
            "users": users,
            "descendants": descendants,
        })
    if not plans:
        return False

    applied = []
    try:
        for plan in plans:
            _transform_edit_bmesh(plan["bm"], plan["transform"])
            for obj in plan["users"]:
                obj.matrix_world = plan["after"][str(obj.name)]
            for obj in plan["descendants"]:
                obj.matrix_world = plan["after"][str(obj.name)]
            bmesh.update_edit_mesh(plan["mesh"], loop_triangles=False, destructive=False)
            if not _undo_bridge.commit_transaction_record(plan["record"], plan["after"], bm=plan["bm"]):
                raise RuntimeError("Unable to commit Edit Mode origin state")
            applied.append(plan)
        context.view_layer.update()
        return True
    except Exception:
        for plan in reversed(applied or plans):
            try:
                _transform_edit_bmesh(plan["bm"], plan["inverse"])
                for obj in tuple(plan["users"]) + tuple(plan["descendants"]):
                    matrix = plan["before"].get(str(obj.name))
                    if matrix is not None:
                        obj.matrix_world = matrix
                _undo_bridge.rollback_transaction_record(plan["record"], bm=plan["bm"])
                bmesh.update_edit_mesh(plan["mesh"], loop_triangles=False, destructive=False)
            except Exception:
                pass
        return False


def _data_users(data, candidates) -> tuple:
    result = []
    seen = set()
    for obj in candidates:
        try:
            if obj.data == data:
                key = int(obj.as_pointer())
                if key not in seen:
                    seen.add(key)
                    result.append(obj)
        except Exception:
            pass
    try:
        expected = int(data.users)
    except Exception:
        expected = len(result)
    if expected > len(result):
        for obj in bpy.data.objects:
            try:
                if obj.data != data:
                    continue
                key = int(obj.as_pointer())
                if key in seen:
                    continue
                seen.add(key)
                result.append(obj)
            except Exception:
                pass
    return tuple(result)


def _local_bounds_center(obj) -> Vector | None:
    try:
        points = [Vector(corner) for corner in obj.bound_box]
    except Exception:
        return None
    if not points:
        return None
    minimum = Vector((min(p.x for p in points), min(p.y for p in points), min(p.z for p in points)))
    maximum = Vector((max(p.x for p in points), max(p.y for p in points), max(p.z for p in points)))
    return (minimum + maximum) * 0.5


def _apply_object_origin(context, operation_type: str) -> bool:
    selected = tuple(getattr(context, "selected_editable_objects", None) or ())
    if not selected and context.active_object is not None:
        selected = (context.active_object,)
    active = context.active_object
    groups = {}
    for obj in selected:
        data = getattr(obj, "data", None)
        if data is None or not callable(getattr(data, "transform", None)):
            continue
        groups.setdefault(int(data.as_pointer()), {"data": data, "selected": []})["selected"].append(obj)
    plans = []
    for group in groups.values():
        data = group["data"]
        chosen = tuple(group["selected"])
        reference = active if active in chosen else chosen[0]
        if operation_type == "origin_to_geometry":
            center = _local_bounds_center(reference)
            if center is None:
                continue
            target = reference.matrix_world @ center
        else:
            target = context.scene.cursor.location.copy()
        old_reference = reference.matrix_world.copy()
        new_reference = old_reference.copy()
        new_reference.translation = target
        local_transform = new_reference.inverted_safe() @ old_reference
        if _matrix_close(local_transform, Matrix.Identity(4)):
            continue
        inverse_local = local_transform.inverted_safe()
        users = _data_users(data, chosen)
        descendants = _descendants(users)
        tracked = tuple(users) + tuple(descendants)
        before = {str(obj.name): obj.matrix_world.copy() for obj in tracked}
        after = {str(obj.name): obj.matrix_world @ inverse_local for obj in users}
        after.update({str(obj.name): before[str(obj.name)].copy() for obj in descendants})
        plans.append((data, local_transform, inverse_local, users, descendants, before, after))
    if not plans:
        return False
    applied = []
    try:
        for data, transform, inverse, users, descendants, before, after in plans:
            try:
                data.transform(transform, shape_keys=True)
            except TypeError:
                data.transform(transform)
            for obj in users:
                obj.matrix_world = after[str(obj.name)]
            for obj in descendants:
                obj.matrix_world = after[str(obj.name)]
            update = getattr(data, "update", None)
            if callable(update):
                update()
            applied.append((data, transform, inverse, users, descendants, before, after))
        context.view_layer.update()
        return True
    except Exception:
        for data, transform, inverse, users, descendants, before, after in reversed(applied):
            try:
                try:
                    data.transform(inverse, shape_keys=True)
                except TypeError:
                    data.transform(inverse)
                for obj in tuple(users) + tuple(descendants):
                    matrix = before.get(str(obj.name))
                    if matrix is not None:
                        obj.matrix_world = matrix
            except Exception:
                pass
        return False


class OriginToSelection(Operator):
    bl_description = "Set the origin of the selected object to the center of its geometry or selection"
    bl_idname = "keyops.origin_to_selection"
    bl_label = "Origin to Selection"
    bl_options = {"INTERNAL", "UNDO"}

    type: bpy.props.StringProperty(name="Type", default="origin_to_geometry")  # type: ignore

    @classmethod
    def poll(cls, context):
        return context.mode in {"OBJECT", "EDIT_MESH"} and context.active_object is not None

    def execute(self, context):
        operation_type = str(self.type or "")
        if operation_type not in {"origin_to_geometry", "origin_to_3d_cursor"}:
            self.report({"ERROR"}, "Unsupported origin operation")
            return {"CANCELLED"}
        if context.mode == "EDIT_MESH":
            target = _target_world(context, operation_type)
            if target is None:
                self.report({"WARNING"}, "Select at least one mesh element")
                return {"CANCELLED"}
            if _origin_already_at_target(context, target):
                return {"CANCELLED"}
            if _apply_edit_origin(context, target):
                return {"FINISHED"}
            self.report({"ERROR"}, "Unable to change the origin in Edit Mode")
            return {"CANCELLED"}
        if _apply_object_origin(context, operation_type):
            return {"FINISHED"}
        return {"CANCELLED"}


class CursorPie(Menu):
    bl_idname = "KEYOPS_MT_cursor_pie"
    bl_label = "Cursor Pie"

    def draw(self, context):
        pie = self.layout.menu_pie()
        pie.operator("keyops.origin_to_selection", text="Origin to 3D Cursor", icon="LAYER_USED").type = "origin_to_3d_cursor"
        pie.operator("keyops.origin_to_selection", text="Origin to Selection", icon="LAYER_USED").type = "origin_to_geometry"
        pie.operator("view3d.snap_cursor_to_selected", text="Cursor to Selection", icon="CURSOR")
        pie.operator("view3d.snap_selected_to_cursor", text="Selection to Cursor", icon="RESTRICT_SELECT_OFF")
        pie.operator("view3d.snap_selected_to_grid", text="Selection to Grid", icon="SNAP_GRID")
        pie.operator("view3d.snap_cursor_to_grid", text="Cursor to Grid", icon="SNAP_GRID")
        pie.operator("view3d.snap_cursor_to_center", text="Cursor to World Origin", icon="PIVOT_CURSOR")
        pie.operator("view3d.snap_cursor_to_active", text="Cursor to Active", icon="CURSOR")
