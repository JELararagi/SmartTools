# -*- coding: utf-8 -*-
# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi. All Rights Reserved.
#  Official Contact: 
#  Video Tutorials: 
#
#  Blender Extension / user_default compatible package
# ------------------------------------------------------------------------------

import bpy
from .bootstrap_common import class_is_owned_for_mutation as _smsk_owned_class
from .bootstrap_common import safe_unregister_class as _smsk_safe_unregister_class
from bpy.props import BoolProperty, FloatProperty, IntProperty, PointerProperty
from bpy.types import Operator, Panel, PropertyGroup
from mathutils import Vector

from . import language as _language

PANEL_CATEGORY = "Smart Modeling"


def _ui_text(text, context=None):
    return _language.ui_text(text, context=context)


def _pick_text(en, ja, context=None):
    return _language.pick_text(en, ja, context=context)


def _active_collection(context):
    view_layer = getattr(context, 'view_layer', None)
    layer_collection = getattr(view_layer, 'active_layer_collection', None) if view_layer else None
    if layer_collection and getattr(layer_collection, 'collection', None):
        return layer_collection.collection
    scene = getattr(context, 'scene', None)
    return getattr(scene, 'collection', None)


def _link_object_to_active_collection(context, obj):
    target = _active_collection(context)
    if target is None or obj is None:
        return
    try:
        if obj.name not in target.objects:
            target.objects.link(obj)
    except Exception:
        pass


def _activate_only(context, obj):
    if obj is None:
        return
    try:
        bpy.ops.object.select_all(action='DESELECT')
    except Exception:
        pass
    try:
        obj.select_set(True)
    except Exception:
        pass
    try:
        context.view_layer.objects.active = obj
    except Exception:
        pass


def _unique_name(base: str) -> str:
    names = set(bpy.data.objects.keys())
    if base not in names:
        return base
    i = 1
    while True:
        candidate = f"{base}_{i:03d}"
        if candidate not in names:
            return candidate
        i += 1


def _new_curve_object(context, name: str, paths, cyclic=False, dimensions='3D'):
    if not paths:
        return None
    curve = bpy.data.curves.new(name=name, type='CURVE')
    curve.dimensions = dimensions
    curve.fill_mode = 'NONE' if dimensions == '2D' else 'FULL'
    for path in paths:
        if not path or len(path) < 2:
            continue
        spline = curve.splines.new('POLY')
        spline.points.add(len(path) - 1)
        for i, p in enumerate(path):
            spline.points[i].co = (float(p.x), float(p.y), float(p.z), 1.0)
        spline.use_cyclic_u = bool(cyclic)
    if not curve.splines:
        bpy.data.curves.remove(curve)
        return None
    obj = bpy.data.objects.new(name, curve)
    _link_object_to_active_collection(context, obj)
    return obj


def _new_mesh_object(context, name: str, vertices, faces, shade_smooth=False):
    if not vertices or not faces:
        return None
    mesh = bpy.data.meshes.new(name=name)
    mesh.from_pydata([tuple(map(float, v)) for v in vertices], [], faces)
    try:
        mesh.update()
    except Exception:
        pass
    obj = bpy.data.objects.new(name, mesh)
    _link_object_to_active_collection(context, obj)
    if shade_smooth:
        try:
            for poly in mesh.polygons:
                poly.use_smooth = True
        except Exception:
            pass
    return obj


def _view_facing_axis(context):
    # The strip faces the view it was drawn in, so it never collapses to a line
    # on screen.  Without a 3D view (background runs) it faces straight up.
    try:
        rv3d = getattr(context, 'region_data', None) or getattr(getattr(context, 'space_data', None), 'region_3d', None)
        axis = rv3d.view_rotation @ Vector((0.0, 0.0, 1.0))
        if axis.length > 1.0e-6:
            return axis.normalized()
    except Exception:
        pass
    return Vector((0.0, 0.0, 1.0))


def _build_surface_strip_mesh(paths, width: float, offset: float = 0.0, close_strip: bool = False, up_axis=None):
    verts = []
    faces = []
    half = max(0.00001, float(width)) * 0.5
    up_axis = Vector((0.0, 0.0, 1.0)) if up_axis is None else Vector(up_axis)
    alt_axis = Vector((1.0, 0.0, 0.0))
    for path in paths:
        if not path or len(path) < 2:
            continue
        start = len(verts)
        count = len(path)
        for i, p in enumerate(path):
            prev_p = path[i - 1] if i > 0 else path[i]
            next_p = path[i + 1] if i < count - 1 else path[i]
            tangent = (next_p - prev_p)
            if tangent.length < 1.0e-8:
                tangent = Vector((1.0, 0.0, 0.0))
            tangent.normalize()
            side = tangent.cross(up_axis)
            if side.length < 1.0e-6:
                side = tangent.cross(alt_axis)
            if side.length < 1.0e-6:
                side = Vector((0.0, 1.0, 0.0))
            side.normalize()
            left = p - side * half + up_axis * float(offset)
            right = p + side * half + up_axis * float(offset)
            verts.append(left)
            verts.append(right)
        seg_count = count if close_strip and count > 2 else count - 1
        for i in range(seg_count):
            ni = (i + 1) % count
            faces.append((start + i * 2, start + i * 2 + 1, start + ni * 2 + 1, start + ni * 2))
    return verts, faces


def _annotation_stroke_paths(context, active_layer_only=True, min_points=2):
    # Support old annotation data and new grease pencil object data defensively.
    gps = []
    seen = set()

    def _push(gp, matrix=None):
        if gp is None:
            return
        as_pointer = getattr(gp, 'as_pointer', None)
        key = as_pointer() if callable(as_pointer) else id(gp)
        if key in seen:
            return
        seen.add(key)
        gps.append((gp, matrix))

    active_obj = getattr(context, 'active_object', None)
    if active_obj and getattr(active_obj, 'type', None) in {'GREASEPENCIL', 'GPENCIL'}:
        # Grease Pencil points are local to the object; annotation points are already world.
        _push(getattr(active_obj, 'data', None), active_obj.matrix_world.copy())

    for owner in (
        getattr(context, 'annotation_data_owner', None),
        getattr(context, 'space_data', None),
        getattr(context, 'scene', None),
        context,
    ):
        if owner is None:
            continue
        _push(getattr(owner, 'annotation_data', None))
        _push(getattr(owner, 'grease_pencil', None))
        _push(getattr(owner, 'grease_pencil_data', None))

    paths = []
    for gp, matrix in gps:
        layers = getattr(gp, 'layers', None)
        if not layers:
            continue
        layer_iter = []
        active_layer = getattr(layers, 'active', None)
        if active_layer_only and active_layer is not None:
            layer_iter = [active_layer]
        else:
            try:
                layer_iter = list(layers)
            except Exception:
                layer_iter = [active_layer] if active_layer else []
        for layer in layer_iter:
            if layer is None:
                continue
            frame = getattr(layer, 'active_frame', None)
            if frame is None:
                current_frame = getattr(layer, 'current_frame', None)
                if callable(current_frame):
                    frame = current_frame()
            if frame is None:
                try:
                    frames = getattr(layer, 'frames', None)
                    if frames:
                        frame = frames[-1]
                except Exception:
                    frame = None
            if frame is None:
                continue
            strokes = getattr(frame, 'strokes', None)
            if strokes is None:
                # Grease Pencil v3 keeps its strokes on the frame's drawing.
                strokes = getattr(getattr(frame, 'drawing', None), 'strokes', None)
            if strokes is None or len(strokes) == 0:
                continue
            for stroke in strokes:
                pts = getattr(stroke, 'points', None)
                if not pts:
                    continue
                path = []
                for p in pts:
                    co = getattr(p, 'co', None)
                    if co is None:
                        # Grease Pencil v3 stroke points use `position`.
                        co = getattr(p, 'position', None)
                    if co is None:
                        continue
                    if matrix is not None:
                        co = matrix @ Vector(co)
                    try:
                        path.append(Vector((float(co[0]), float(co[1]), float(co[2]))))
                    except Exception:
                        try:
                            path.append(Vector((float(co.x), float(co.y), float(co.z))))
                        except Exception:
                            pass
                if len(path) >= int(min_points):
                    paths.append(path)
    return paths


class SMSK_Properties(PropertyGroup):
    active_layer_only: BoolProperty(
        name="Active Layer Only",
        description='Read only the active annotation / grease pencil layer when building guide curves.',
        default=True,
    )
    close_curve: BoolProperty(
        name="Close Curve",
        description='Create cyclic curves from the sampled strokes.',
        default=False,
    )
    min_points: IntProperty(
        name="Min Points",
        description='Ignore strokes with fewer sampled points than this value.',
        default=2,
        min=2,
        soft_max=64,
    )
    bevel_depth: FloatProperty(
        name="Preview Bevel",
        description='Optional curve bevel depth applied to the generated guide curve. Leave at 0 for a pure path.',
        default=0.0,
        min=0.0,
        soft_max=1.0,
        precision=4,
    )

    surface_width: FloatProperty(
        name="Surface Width",
        description='Width of the generated sketch surface strip. Useful for fast Bsurfaces-style ribbons, guides, straps, trims, and panel bands.',
        default=0.05,
        min=0.0001,
        soft_max=10.0,
        precision=4,
    )
    surface_offset: FloatProperty(
        name="Surface Offset",
        description='Move the generated strip slightly toward or away from the current view.',
        default=0.0,
        soft_min=-1.0,
        soft_max=1.0,
        precision=4,
    )
    surface_close_strip: BoolProperty(
        name="Close Surface Strip",
        description='Close the generated strip so the last stroke point connects back to the first.',
        default=False,
    )
    surface_shade_smooth: BoolProperty(
        name="Shade Smooth",
        description='Enable smooth shading on the generated sketch surface strip.',
        default=True,
    )


class SMSK_OT_annotation_to_curve(Operator):
    bl_idname = "smsk.annotation_to_curve"
    bl_label = 'Convert to Curve'
    bl_description = 'Convert annotation / grease pencil strokes into reusable guide curves for direct modeling, blockout splines, trim routing, and Bsurfaces-style preparation.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        props = getattr(getattr(context, 'scene', None), 'smsk_props', None)
        if props is None:
            self.report({'WARNING'}, "Sketch properties were not found")
            return {'CANCELLED'}
        paths = _annotation_stroke_paths(context, bool(props.active_layer_only), int(props.min_points))
        if not paths:
            self.report({'WARNING'}, "No usable annotation / grease pencil strokes were found")
            return {'CANCELLED'}
        obj = _new_curve_object(context, _unique_name("SMS_Annotation_Guide"), paths, cyclic=bool(props.close_curve), dimensions='3D')
        if obj is None:
            self.report({'ERROR'}, "Failed to convert annotation strokes to a guide curve")
            return {'CANCELLED'}
        try:
            obj.data.bevel_depth = float(props.bevel_depth)
        except Exception:
            pass
        _activate_only(context, obj)
        self.report({'INFO'}, "Created guide curve from annotation strokes")
        return {'FINISHED'}




class SMSK_OT_annotation_to_surface_strip(Operator):
    bl_idname = "smsk.annotation_to_surface_strip"
    bl_label = 'Convert to Surface Strip'
    bl_description = 'Convert annotation / grease pencil strokes into quick surface strips for Bsurfaces-style sketch blocking, straps, trims, panel bands, and retopo guides.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        props = getattr(getattr(context, 'scene', None), 'smsk_props', None)
        if props is None:
            self.report({'WARNING'}, "Sketch properties were not found")
            return {'CANCELLED'}
        paths = _annotation_stroke_paths(context, bool(props.active_layer_only), int(props.min_points))
        if not paths:
            self.report({'WARNING'}, "No usable annotation / grease pencil strokes were found")
            return {'CANCELLED'}
        vertices, faces = _build_surface_strip_mesh(
            paths,
            width=float(props.surface_width),
            offset=float(props.surface_offset),
            close_strip=bool(props.surface_close_strip),
            up_axis=_view_facing_axis(context),
        )
        obj = _new_mesh_object(
            context,
            _unique_name("SMS_Sketch_Surface"),
            vertices,
            faces,
            shade_smooth=bool(props.surface_shade_smooth),
        )
        if obj is None:
            self.report({'ERROR'}, "Failed to create a sketch surface strip from the annotation strokes")
            return {'CANCELLED'}
        _activate_only(context, obj)
        self.report({'INFO'}, "Created sketch surface strip from annotation strokes")
        return {'FINISHED'}


class VIEW3D_PT_sketch_tools(Panel):
    bl_label = "Sketch Surface"
    bl_idname = "VIEW3D_PT_sketch_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    _smart_suite_host_panel = True
    bl_description = 'Direct sketch helpers for turning annotation strokes into modeling guide curves without moving them into the modifier stack.'

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        props = context.scene.smsk_props

        box = layout.box()
        box.label(text=_pick_text("Guide Curves", "ガイドカーブ", context), icon='GREASEPENCIL')
        row = box.row(align=True)
        row.scale_y = 1.1
        row.operator("smsk.annotation_to_curve", icon='CURVE_DATA', text=_pick_text("Annotation To Curve", "カーブに変換", context))
        box.prop(props, "active_layer_only")
        row = box.row(align=True)
        row.prop(props, "close_curve")
        row.prop(props, "min_points")
        box.prop(props, "bevel_depth")

        box = layout.box()
        box.label(text=_pick_text("Surface Strip", "面ストリップ", context), icon='MESH_GRID')
        row = box.row(align=True)
        row.scale_y = 1.1
        row.operator("smsk.annotation_to_surface_strip", icon='MESH_DATA', text=_pick_text("Annotation To Surface Strip", "注釈を面ストリップ化", context))
        row = box.row(align=True)
        row.prop(props, "surface_width")
        row.prop(props, "surface_offset")
        row = box.row(align=True)
        row.prop(props, "surface_close_strip")
        row.prop(props, "surface_shade_smooth")

        scn = context.scene
        if hasattr(scn, "qsd_draw_toggle"):
            qbox = layout.box()
            qbox.label(text=_pick_text("Quad Strip / Retopo", "クアッドストリップ・リトポ", context), icon='MESH_GRID')
            row = qbox.row(align=True)
            row.scale_y = 1.1
            row.prop(scn, "qsd_draw_toggle", text=_pick_text("Start Strip Drawing", "ストリップ描画開始", context), toggle=True)
            row.prop(scn, "qsd_retopo_mode", text=_pick_text("Retopo Mode", "リトポモード", context), toggle=True)
            row = qbox.row(align=True)
            row.prop(scn, "qsd_plane_mode", text=_pick_text("Plane", "基準面", context))
            row.prop(scn, "qsd_use_surface_snap", text=_pick_text("Snap", "スナップ", context), toggle=True)
            row = qbox.row(align=True)
            row.operator_context = 'INVOKE_DEFAULT'
            row.operator("mesh.qsd_field_paint_popup", text=_pick_text("Quad Field Paint", "クアッドフィールド", context), icon='BRUSH_DATA')
            row.operator("mesh.qsd_boundary_trace_popup", text=_pick_text("Boundary Trace", "境界トレース", context), icon='TRACKING_FORWARDS')
            row = qbox.row(align=True)
            row.operator_context = 'INVOKE_DEFAULT'
            row.operator("mesh.qsd_retopo_setup_popup", text=_pick_text("Retopo Setup", "リトポ設定", context), icon='MOD_SHRINKWRAP')
            row.operator("mesh.qsd_fill_tools_popup", text=_pick_text("Fill / Project", "フィル・投影", context), icon='MESH_GRID')


def draw_smart_modeling_settings(layout, context):
    if layout is None:
        return
    try:
        shim = type('_SMSKHostedPanelShim', (), {})()
        shim.layout = layout
        VIEW3D_PT_sketch_tools.draw(shim, context)
    except Exception as exc:
        box = layout.box()
        box.alert = True
        box.label(text=str(exc)[:240], icon='ERROR')


_SMSK_HOSTED_PANEL_IDS = ('VIEW3D_PT_sketch_tools',)


def _smsk_unregister_hosted_panels():
    for panel_id in _SMSK_HOSTED_PANEL_IDS:
        cls = globals().get(panel_id)
        if isinstance(cls, type) and _smsk_owned_class(cls):
            _smsk_safe_unregister_class(cls)


classes = (
    SMSK_Properties,
    SMSK_OT_annotation_to_curve,
    SMSK_OT_annotation_to_surface_strip,
)

_SMSK_PROPERTY_CLASSES = (SMSK_Properties,)
_SMSK_RUNTIME_CLASSES = tuple(cls for cls in classes if cls not in _SMSK_PROPERTY_CLASSES)


def register():
    _smsk_unregister_hosted_panels()
    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except Exception:
            pass
    try:
        if hasattr(bpy.types.Scene, 'smsk_props'):
            del bpy.types.Scene.smsk_props
    except Exception:
        pass
    try:
        bpy.types.Scene.smsk_props = PointerProperty(type=SMSK_Properties, description='Settings for sketch-to-curve helpers.')
    except Exception:
        pass


def unregister():
    _smsk_unregister_hosted_panels()
    for cls in reversed(_SMSK_RUNTIME_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    try:
        if hasattr(bpy.types.Scene, 'smsk_props'):
            del bpy.types.Scene.smsk_props
    except Exception:
        pass
    for cls in reversed(_SMSK_PROPERTY_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
