# -*- coding: utf-8 -*-
# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi. All Rights Reserved.
#
#  Blender Extension / user_default compatible package
# ------------------------------------------------------------------------------

from __future__ import annotations

import os
import bpy

SUITE_BASENAME = "smart_modeling_suite"
_NPANEL_PROP_NAME = "smart_modeling_suite_npanel_settings"
_NPANEL_PREFS_SYNCED_KEY = "SMART_MODELING_SUITE_NPANEL_PREFS_SYNCED"


def draw_section_help(layout, section):
    operator = layout.operator("smart_modeling_suite.show_tool_help", text="", icon="QUESTION")
    operator.kind = "section"
    operator.alias = section




def _rna_data_is_current(data) -> bool:
    if data is None:
        return False
    try:
        cls = type(data)
        cls_name = str(getattr(cls, "__name__", "") or "")
    except Exception:
        return False
    if not cls_name:
        return False
    try:
        registered = getattr(bpy.types, cls_name, None)
    except Exception:
        registered = None
    if registered is cls:
        return True
    # Registered Python PropertyGroups need not be attributes of bpy.types.
    # Resolve the live RNA registration and retain the exact-class guard so
    # stale classes from an earlier enable/reload are never adopted.
    try:
        if isinstance(data, bpy.types.PropertyGroup):
            return bpy.types.PropertyGroup.bl_rna_get_subclass_py(cls_name) is cls
    except (ReferenceError, RuntimeError, TypeError):
        return False
    try:
        module_name = str(getattr(cls, "__module__", "") or "")
    except Exception:
        module_name = ""
    return module_name in {"bpy.types", "_bpy_types"} and registered is not None
def _root_id_from_package(pkg: str) -> str:
    """Return the logical root package for this extension."""
    if not pkg:
        return SUITE_BASENAME
    parts = str(pkg).split(".")
    if SUITE_BASENAME in parts:
        idx = parts.index(SUITE_BASENAME)
        return ".".join(parts[:idx + 1])
    return parts[0]


def _manifest_extension_id(default: str = SUITE_BASENAME) -> str:
    """Read blender_manifest.toml id without importing TOML support."""
    default = str(default or SUITE_BASENAME).strip() or SUITE_BASENAME
    try:
        current = os.path.dirname(os.path.abspath(__file__))
        while True:
            manifest = os.path.join(current, "blender_manifest.toml")
            if os.path.isfile(manifest):
                with open(manifest, "r", encoding="utf-8") as handle:
                    for raw_line in handle:
                        line = raw_line.strip()
                        if line.startswith("id"):
                            _, _, value = line.partition("=")
                            value = value.strip().strip('"').strip("'")
                            if value:
                                return value
                break
            parent = os.path.dirname(current)
            if parent == current:
                break
            current = parent
    except Exception:
        pass
    if ".user_default." in default or default.startswith("bl_ext."):
        default = default.rsplit(".", 1)[-1]
    if "." in default:
        default = default.split(".", 1)[0]
    return default or SUITE_BASENAME


# Backward-compatible helper names used by older bundled modules.
def _smart_tools_manifest_extension_id(default: str = "") -> str:
    return _manifest_extension_id(default or SUITE_BASENAME)


def extension_package_id_candidates() -> tuple[str, ...]:
    candidates: list[str] = []
    manifest_id = _manifest_extension_id(SUITE_BASENAME)
    for value in (manifest_id, globals().get("__package__"), __name__, SUITE_BASENAME):
        text = str(value or "").strip()
        if not text:
            continue
        if ".user_default." in text or text.startswith("bl_ext."):
            text = text.rsplit(".", 1)[-1]
        parts = text.split(".")
        if SUITE_BASENAME in parts:
            text = SUITE_BASENAME
        if text and text not in candidates:
            candidates.append(text)
    return tuple(candidates) or (SUITE_BASENAME,)


def extension_package_id() -> str:
    return extension_package_id_candidates()[0]


def _blender_version_label() -> str:
    try:
        version = getattr(getattr(bpy, "app", None), "version", None)
        if version and len(version) >= 2:
            return f"{int(version[0])}.{int(version[1])}"
    except Exception:
        pass
    return "5.1"


def _version_root() -> str:
    """Return Blender's version directory without creating side folders."""
    utils = getattr(bpy, "utils", None)
    user_resource = getattr(utils, "user_resource", None) if utils is not None else None
    if callable(user_resource):
        config_dir = ""
        try:
            config_dir = str(user_resource("CONFIG", create=False) or "")
        except TypeError:
            try:
                config_dir = str(user_resource("CONFIG") or "")
            except Exception:
                config_dir = ""
        except Exception:
            config_dir = ""
        if config_dir:
            return os.path.dirname(os.path.normpath(config_dir))

    version = _blender_version_label()
    if os.name == "nt":
        appdata = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), "AppData", "Roaming")
        return os.path.join(appdata, "Blender Foundation", "Blender", version)
    return os.path.join(os.path.expanduser("~"), ".config", "blender", version)


def _smart_tools_version_user_default_root(package_id: str, create: bool = False) -> str:
    """Compatibility writable-root API redirected to Smart Modeling CONFIG."""
    del package_id
    path = os.path.join(_version_root(), "config", "Smart_Modeling_Suite")
    if create:
        os.makedirs(path, exist_ok=True)
    return path


def _smart_tools_extension_candidates() -> tuple[str, ...]:
    return extension_package_id_candidates()


def _smart_tools_extension_user_root(create: bool = False) -> str:
    for package_id in _smart_tools_extension_candidates():
        path = _smart_tools_version_user_default_root(package_id, create=create)
        if path:
            return path
    return _smart_tools_version_user_default_root(SUITE_BASENAME, create=create)


def extension_user_root(create: bool = False) -> str:
    """Root for all generated Smart Modeling files.

    The historical function name is kept for callers, but the returned path is
    always CONFIG/Smart_Modeling_Suite. Installed packages are read-only.
    """
    try:
        from .storage import mutable_root as _storage_mutable_root
        return str(_storage_mutable_root(create=create))
    except Exception:
        return _smart_tools_extension_user_root(create=create)


def suite_user_dir(category: str = "data", create: bool = False) -> str:
    safe_category = str(category or "data").strip().replace("\\", "/") or "data"
    safe_parts = [part for part in safe_category.split("/") if part not in {"", ".", ".."}]
    path = os.path.join(extension_user_root(create=create), *safe_parts) if safe_parts else extension_user_root(create=create)
    if create:
        os.makedirs(path, exist_ok=True)
    return path


def default_user_filepath(filename: str, category: str = "data", create: bool = True) -> str:
    safe_name = os.path.basename(str(filename or "").strip() or "data.json")
    return os.path.join(suite_user_dir(category=category, create=create), safe_name)


def ensure_parent_dir(filepath: str) -> str:
    path = str(filepath or "")
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    return path


def get_suite_prefs(context=None):
    """Return the Smart Modeling N-panel settings proxy, or None."""
    for ctx in (context, getattr(bpy, "context", None)):
        if ctx is None:
            continue
        try:
            wm = getattr(ctx, "window_manager", None)
        except Exception:
            wm = None
        if wm is None or not _rna_data_is_current(wm):
            continue
        try:
            prefs = getattr(wm, _NPANEL_PROP_NAME, None)
            if prefs is not None and _rna_data_is_current(prefs):
                return prefs
        except Exception:
            pass
    return None


def _npanel_preferences_synchronized() -> bool:
    """Return whether the host has restored the persisted N-panel values.

    Blender can expose a newly constructed WindowManager PropertyGroup before
    the post-startup restore has copied the saved values into it. During that
    bounded window its BoolProperties contain factory defaults and must not gate
    keymap operators. The core marks the exact restore boundary in the driver
    namespace; absence or False therefore means fail-open for command polling.
    """
    try:
        namespace = getattr(getattr(bpy, "app", None), "driver_namespace", None)
        return bool(isinstance(namespace, dict) and namespace.get(_NPANEL_PREFS_SYNCED_KEY) is True)
    except Exception:
        return False


def feature_enabled(context, flag_name: str, default=True) -> bool:
    prefs = get_suite_prefs(context)
    if not prefs:
        return bool(default)
    if not _npanel_preferences_synchronized():
        return True
    try:
        return bool(getattr(prefs, str(flag_name)))
    except Exception:
        pass
    try:
        getter = getattr(prefs, "get", None)
        if callable(getter):
            return bool(getter(str(flag_name), default))
    except Exception:
        pass
    try:
        return bool(prefs[str(flag_name)])
    except Exception:
        return bool(default)


# --- Popup host helpers retained for bundled tools that expect Smart Tools names. ---
def _smart_tools_popup_runtime():
    try:
        from . import pseudo_properties
    except Exception:
        return None
    return pseudo_properties


def smart_tools_popup_override_context(context=None, prefer_view3d: bool = False):
    runtime = _smart_tools_popup_runtime()
    if runtime is None:
        return None
    getter = getattr(runtime, "popup_override_context", None)
    if not callable(getter):
        return None
    try:
        return getter(context=context, prefer_view3d=bool(prefer_view3d))
    except Exception:
        return None


def smart_tools_invoke_popup(context, operator, *, width: int = 300):
    runtime = _smart_tools_popup_runtime()
    if runtime is not None:
        caller = getattr(runtime, "invoke_popup_outside_smart_tools", None)
        if callable(caller):
            try:
                return caller(operator, context=context, width=int(width))
            except Exception:
                pass
    return context.window_manager.invoke_popup(operator, width=int(width))


def smart_tools_invoke_props_dialog(context, operator, *, width: int = 300):
    runtime = _smart_tools_popup_runtime()
    if runtime is not None:
        caller = getattr(runtime, "invoke_props_dialog_outside_smart_tools", None)
        if callable(caller):
            try:
                return caller(operator, context=context, width=int(width))
            except Exception:
                pass
    return context.window_manager.invoke_props_dialog(operator, width=int(width))


def smart_tools_invoke_confirm(context, operator, event=None):
    runtime = _smart_tools_popup_runtime()
    if runtime is not None:
        caller = getattr(runtime, "invoke_confirm_outside_smart_tools", None)
        if callable(caller):
            try:
                return caller(operator, event=event, context=context)
            except Exception:
                pass
    return context.window_manager.invoke_confirm(operator, event=event) if event is not None else context.window_manager.invoke_confirm(operator)


def smart_tools_call_menu_pie(context, *, name: str):
    runtime = _smart_tools_popup_runtime()
    if runtime is not None:
        caller = getattr(runtime, "call_menu_pie_outside_smart_tools", None)
        if callable(caller):
            try:
                return caller(name=str(name), context=context)
            except Exception:
                pass
    return bpy.ops.wm.call_menu_pie(name=str(name))
