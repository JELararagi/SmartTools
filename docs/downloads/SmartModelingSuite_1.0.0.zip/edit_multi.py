# -*- coding: utf-8 -*-
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi. All Rights Reserved.
#
#  Blender Extension / user_default compatible package
# ------------------------------------------------------------------------------

"""Small helpers for Blender multi-object Edit Mode.

These helpers intentionally avoid bpy.ops so mesh tools can work on every object
that is already participating in Edit Mode without changing active selection.
"""

from __future__ import annotations

from typing import Iterable


def _as_tuple(value):
    try:
        return tuple(value or ())
    except Exception:
        return tuple()


def edit_mesh_objects(context, *, unique_data: bool = True) -> list:
    """Return all editable mesh objects in the current multi-object Edit Mode.

    Blender exposes both ``objects_in_mode`` and ``objects_in_mode_unique_data``.
    Mesh data edits should normally use the unique-data list to avoid mutating the
    same BMesh twice when linked duplicates are edited together. Object-level
    operations, such as adding modifiers, can request the non-unique list.
    """
    objects: list = []
    if context is None:
        return objects

    source = None
    if unique_data:
        source = getattr(context, 'objects_in_mode_unique_data', None)
    if source is None:
        source = getattr(context, 'objects_in_mode', None)
    for obj in _as_tuple(source):
        try:
            if obj is not None and getattr(obj, 'type', None) == 'MESH' and getattr(obj, 'mode', '') == 'EDIT':
                if obj not in objects:
                    objects.append(obj)
        except Exception:
            pass

    if objects:
        return objects

    for name in ('edit_object', 'active_object', 'object'):
        try:
            obj = getattr(context, name, None)
        except Exception:
            obj = None
        try:
            if obj is not None and getattr(obj, 'type', None) == 'MESH' and getattr(obj, 'mode', '') == 'EDIT':
                if obj not in objects:
                    objects.append(obj)
        except Exception:
            pass
    return objects


def selected_mesh_objects(context) -> list:
    objects: list = []
    if context is None:
        return objects
    try:
        selected = tuple(getattr(context, 'selected_objects', ()) or ())
    except Exception:
        selected = tuple()
    for obj in selected:
        try:
            if obj is not None and getattr(obj, 'type', None) == 'MESH' and obj not in objects:
                objects.append(obj)
        except Exception:
            pass
    try:
        active = getattr(context, 'active_object', None)
        if active is not None and getattr(active, 'type', None) == 'MESH' and active not in objects:
            objects.insert(0, active)
    except Exception:
        pass
    return objects
