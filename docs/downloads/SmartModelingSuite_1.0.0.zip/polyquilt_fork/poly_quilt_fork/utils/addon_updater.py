# -*- coding: utf-8 -*-
# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi. All Rights Reserved.
#
#  Blender Extension / user_default compatible package
# ------------------------------------------------------------------------------
"""Compatibility shim for PolyQuilt updater imports."""

from .updater import *  # noqa: F401,F403
