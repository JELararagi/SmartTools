# -*- coding: utf-8 -*-
# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi. All Rights Reserved.
#  Official Contact: 
#  Video Tutorials: 
#
#  Blender Extension / user_default compatible package
# ------------------------------------------------------------------------------

import ast
import contextlib
import importlib
import io
import json
import os
import re
import sys
import traceback
import types
import time
from pathlib import Path

import bpy

from . import language as _language
from . import status_runtime as _status_runtime
try:
    from .lazy_ui_snapshot import (
        PROPERTY_SCHEMAS as _SMS_LAZY_UI_PROPERTY_SCHEMAS,
        UI_SNAPSHOT as _SMS_LAZY_UI_SNAPSHOT,
    )
except Exception:
    # The snapshot is generated from the bundled source tree at package-build
    # time.  Keep extension registration recoverable if an incomplete package is
    # inspected, but never scan files or import feature modules from Panel.draw.
    _SMS_LAZY_UI_PROPERTY_SCHEMAS = {}
    _SMS_LAZY_UI_SNAPSHOT = {'native': {}, 'integrated': {}}
from .bootstrap_common import (
    class_belongs_to_current_package as _sms_exact_class_belongs_to_current_package,
    class_is_owned_for_mutation as _sms_class_is_owned_for_mutation,
    cleanup_stale_owned_classes as _sms_cleanup_stale_owned_classes,
    disable_owned_panel_class as _sms_disable_exact_owned_panel_class,
    registered_propertygroup_subclass as _sms_registered_propertygroup_subclass,
    propertygroup_is_registered as _sms_propertygroup_is_registered,
    rearm_process_namespace_state as _sms_rearm_process_namespace_state,
    safe_register_class as _sms_exact_safe_register_class,
    safe_unregister_class as _sms_exact_safe_unregister_class,
)
from bpy.app.handlers import persistent
from bpy.props import (
    BoolProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
__version__ = "1.3.74"

bl_info = {
    "name": "Smart Modeling",
    "author": "JELararagi",
    "version": (1, 3, 74),
    "blender": (5, 1, 0),
    "location": "View3D > Sidebar > Smart Modeling",
    "description": "Unified direct-modeling toolkit with standard Smart Modeling controls in the 3D View Sidebar N-panel for edit, cleanup, hard-surface, and sketch / retopo workflows.",
    "category": "Mesh",
}


def _ui_text(text, context=None):
    # Tool imports register their own catalogs. Keep suite labels independent
    # of that lazy-load order, including the unloaded snapshot headers.
    if _language.is_japanese(context):
        catalog = globals().get('translation_dict', {}).get('ja_JP', {})
        value = catalog.get(('*', str(text))) or catalog.get(('Operator', str(text)))
        if value:
            return value
    return _language.ui_text(text, context=context)


def _pick_lang(en, ja, context=None):
    return _language.pick_text(en, ja, context=context)


_SMS_UI_ICON_CACHE = None
_SMS_UI_ICON_ALIASES = {
    'TRANSFORM_MOVE': 'EMPTY_ARROWS',
}
_SMS_OPERATOR_INVOKE_DENYLIST = {'wm.tool_set_by_id'}
_SMS_OPERATOR_INVOKE_DEFAULT_IDS = {'mesh.edge_crease_master', 'mesh.mesh_align_master'}
_SMS_KEYOPS_STATIC_KEYMAP_CACHE = None




_SMS_KEYMAP_PREF_PATHS = {
    'Mesh': (
        'Edit > Preferences > Keymap > 3D View > Mesh',
        '編集 > プリファレンス > キーマップ > 3Dビュー > メッシュ',
    ),
    'Object Mode': (
        'Edit > Preferences > Keymap > 3D View > Object Mode',
        '編集 > プリファレンス > キーマップ > 3Dビュー > オブジェクトモード',
    ),
    '3D View Generic': (
        'Edit > Preferences > Keymap > 3D View > 3D View Generic',
        '編集 > プリファレンス > キーマップ > 3Dビュー > 3D View Generic',
    ),
    'Window': (
        'Edit > Preferences > Keymap > Window',
        '編集 > プリファレンス > キーマップ > Window',
    ),
    'UV Editor': (
        'Edit > Preferences > Keymap > UV Editor',
        '編集 > プリファレンス > キーマップ > UV Editor',
    ),
    'Image': (
        'Edit > Preferences > Keymap > Image',
        '編集 > プリファレンス > キーマップ > Image',
    ),
    'View2D': (
        'Edit > Preferences > Keymap > View2D',
        '編集 > プリファレンス > キーマップ > View2D',
    ),
    'Property Editor': (
        'Edit > Preferences > Keymap > Properties',
        '編集 > プリファレンス > キーマップ > プロパティ',
    ),
    'Outliner': (
        'Edit > Preferences > Keymap > Outliner',
        '編集 > プリファレンス > キーマップ > アウトライナー',
    ),
    'Curve': (
        'Edit > Preferences > Keymap > Curve',
        '編集 > プリファレンス > キーマップ > Curve',
    ),
    'Curves': (
        'Edit > Preferences > Keymap > Curves',
        '編集 > プリファレンス > キーマップ > Curves',
    ),
}

_SMS_NATIVE_KEYMAP_INFO = {
    'vertex_copy': (
        {
            'label_en': 'Copy', 'label_ja': 'コピー',
            'purpose_en': 'Copy the selected source vertex positions into the active Vertex Copy slot.',
            'purpose_ja': '選択中のコピー元頂点位置を、現在の頂点コピースロットへ記憶します。',
            'idname': 'vscp.copy_vertices', 'keymap': 'Mesh',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Paste Same Number', 'label_ja': '同番号へ貼り付け',
            'purpose_en': 'Paste copied positions to matching vertex numbers on the target mesh.',
            'purpose_ja': 'コピー済みの位置を、貼り付け先メッシュの一致する頂点番号へ反映します。',
            'idname': 'vscp.paste_same_index', 'keymap': 'Mesh',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Check Same Number', 'label_ja': '同番号を確認',
            'purpose_en': 'Check how many selected target vertices match copied source vertex numbers.',
            'purpose_ja': '貼り付け先で選択中の頂点が、コピー済みの頂点番号とどれだけ一致するか確認します。',
            'idname': 'vscp.validate_same_index', 'keymap': 'Mesh',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Auxiliary Paste', 'label_ja': '補助貼り付け',
            'purpose_en': 'Run the auxiliary Vertex Copy paste modes such as Smart, Mirror, Surface, or batch targets.',
            'purpose_ja': 'スマート、ミラー、サーフェス、複数の対象などの補助の貼り付けを実行します。',
            'idname': 'vscp.paste_vertices', 'keymap': 'Mesh',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Auxiliary Check', 'label_ja': '補助確認',
            'purpose_en': 'Validate target candidates for the auxiliary Vertex Copy paste modes.',
            'purpose_ja': '補助貼り付け用の貼り付け先候補を検証します。',
            'idname': 'vscp.validate_targets', 'keymap': 'Mesh',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
    ),
    'vertex_slide': (
        {
            'label_en': 'Toggle Vertex Slide', 'label_ja': '頂点スライドを切替',
            'purpose_en': 'Toggle Vertex Slide Constraint. While ON, normal G/R/S and transform gizmo edits slide along connected edges.',
            'purpose_ja': '頂点スライド制約を切り替えます。ONの間、通常のG/R/Sやトランスフォームギズモ操作が接続エッジ上のスライドになります。',
            'idname': 'mesh.smart_vert_slide', 'id_prop': 'svs_km_operator', 'keymap': 'Mesh',
            'shortcut_en': 'Recommended: Shift+V if it does not conflict', 'shortcut_ja': '推奨: 競合しない場合は Shift+V',
        },
    ),
    'connect': (
        {
            'label_en': 'Connect Selection', 'label_ja': '選択を接続',
            'purpose_en': 'Connect selected vertices or edges with Mesh Connect.',
            'purpose_ja': '選択した頂点または辺を メッシュ接続で接続します。',
            'idname': 'mesh.smart_connect', 'keymap': 'Mesh',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
    ),
    'mesh_split': (
        {
            'label_en': 'Mesh Split', 'label_ja': 'メッシュ分割',
            'purpose_en': 'Split or break the current mesh selection according to Vertex / Edge / Face selection mode.',
            'purpose_ja': '現在の頂点 / 辺 / 面の選択モードに応じて、選択部分を分割またはブレイクします。',
            'idname': 'mesh.smart_split', 'id_prop': 'ms_km_operator', 'keymap': 'Mesh',
            'shortcut_en': 'Recommended: Alt+Y if it does not conflict', 'shortcut_ja': '推奨: 競合しない場合は Alt+Y',
        },
    ),
    'mesh_align_preset': (
        {
            'label_en': 'Open Align Presets', 'label_ja': '整列プリセットを開く',
            'purpose_en': 'Open the mesh alignment preset popup.',
            'purpose_ja': 'メッシュ整列のポップアップを開きます。',
            'idname': 'mesh.mesh_align_master', 'id_prop': 'map_km_operator', 'keymap': 'Mesh',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
    ),
    'direct_delete': (
        {
            'label_en': 'Delete Selection', 'label_ja': '選択を削除',
            'purpose_en': 'Run Direct Delete with the current selection and delete mode.',
            'purpose_ja': '現在の選択と削除モードで Direct Delete を実行します。',
            'idname': 'mesh.delete_direct', 'id_prop': 'dd_km_operator_main', 'keymap': 'Mesh',
            'shortcut_en': 'Manual direct binding', 'shortcut_ja': '手動の直接割り当て',
        },
        {
            'label_en': 'Override Delete Key', 'label_ja': 'Deleteキーを上書き',
            'purpose_en': 'Use the Delete key to run Direct Delete in Edit Mode.',
            'purpose_ja': '編集モードの Delete キーで Direct Delete を実行します。',
            'idname': 'mesh.delete_direct_del', 'id_prop': 'dd_km_operator_del', 'keymap': 'Mesh',
            'shortcut_en': 'Delete', 'shortcut_ja': 'Delete',
        },
        {
            'label_en': 'Override Backspace', 'label_ja': 'Backspaceを上書き',
            'purpose_en': 'Use Backspace to run Direct Delete in Edit Mode.',
            'purpose_ja': '編集モードの Backspace キーで Direct Delete を実行します。',
            'idname': 'mesh.delete_direct_bs', 'id_prop': 'dd_km_operator_bs', 'keymap': 'Mesh',
            'shortcut_en': 'Backspace', 'shortcut_ja': 'Backspace',
        },
        {
            'label_en': 'Delete Through Selection', 'label_ja': '貫通選択を削除',
            'purpose_en': 'Run the through-selection Direct Delete variant.',
            'purpose_ja': '貫通選択向けの Direct Delete 版を実行します。',
            'idname': 'mesh.delete_direct_through', 'id_prop': 'dd_km_operator_through', 'keymap': 'Mesh',
            'shortcut_en': 'Ctrl+Shift+Delete', 'shortcut_ja': 'Ctrl+Shift+Delete',
        },
        {
            'label_en': 'Delete Objects', 'label_ja': 'オブジェクトを削除',
            'purpose_en': 'Direct-delete selected objects in Object Mode.',
            'purpose_ja': 'オブジェクトモードで選択オブジェクトを直接削除します。',
            'idname': 'object.delete_direct_objects', 'keymap': 'Object Mode',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Delete History', 'label_ja': '履歴を削除',
            'purpose_en': 'Remove every modifier from the selected objects as one atomic operation.',
            'purpose_ja': '選択オブジェクトの全モディファイアを1つの操作として削除します。',
            'idname': 'object.delete_history_modifiers', 'keymap': 'Object Mode',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
    ),
    'model_organized': (
        {
            'label_en': 'Organize Selection', 'label_ja': '選択を整理',
            'purpose_en': 'Start the model organization and cleanup operation.',
            'purpose_ja': 'モデル整理・クリーンアップ操作を開始します。',
            'idname': 'mo2.organize_modal', 'keymap': 'Object Mode',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Restore Backup', 'label_ja': 'バックアップを復元',
            'purpose_en': 'Restore a backup created by Model Organizer.',
            'purpose_ja': 'Model Organizer が作成したバックアップを復元します。',
            'idname': 'mo2.restore_backup', 'keymap': 'Object Mode',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
    ),
    'crease_preset': (
        {
            'label_en': 'Open Crease Presets', 'label_ja': 'クリースプリセットを開く',
            'purpose_en': 'Open the crease preset popup for selected edges.',
            'purpose_ja': '選択辺向けのクリースプリセットポップアップを開きます。',
            'idname': 'mesh.edge_crease_master', 'id_prop': 'cp_km_operator', 'keymap': 'Mesh',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
    ),
    'toggle_auto_merge_snap': (
        {
            'label_en': 'Toggle Merge and Snap', 'label_ja': 'マージとスナップを切替',
            'purpose_en': 'Toggle Blender auto-merge and snap related settings together.',
            'purpose_ja': '自動マージとスナップ関連設定をまとめて切り替えます。',
            'idname': 'mesh.toggle_merge_snap', 'id_prop': 'tams_km_operator', 'keymap': 'Mesh',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
    ),
    'apply_weighted_normal': (
        {
            'label_en': 'Apply Weighted Normal', 'label_ja': '重み付き法線を適用',
            'purpose_en': 'Apply weighted normals to the current mesh selection.',
            'purpose_ja': '現在のメッシュ選択に重み付き法線を適用します。',
            'idname': 'mesh.apply_weighted_normal', 'id_prop': 'awn_km_operator', 'keymap': 'Mesh',
            'shortcut_en': 'Optional hotkey; also available from Alt+N normals menu', 'shortcut_ja': '任意ホットキー。Alt+N の法線メニューからも使用可能',
        },
    ),
    'sketch_tools': (
        {
            'label_en': 'Convert to Curve', 'label_ja': 'カーブに変換',
            'purpose_en': 'Convert annotation strokes into editable curves.',
            'purpose_ja': '注釈ストロークを編集可能なカーブへ変換します。',
            'idname': 'smsk.annotation_to_curve', 'keymap': '3D View Generic',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Convert to Surface Strip', 'label_ja': 'サーフェスストリップに変換',
            'purpose_en': 'Convert annotation strokes into surface strip geometry.',
            'purpose_ja': '注釈ストロークをサーフェスストリップ形状へ変換します。',
            'idname': 'smsk.annotation_to_surface_strip', 'keymap': '3D View Generic',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
    ),
    'quad_strip_draw': (
        {
            'label_en': 'Draw Quad Strip', 'label_ja': 'クアッドストリップを描画',
            'purpose_en': 'Start the modal quad-strip drawing tool.',
            'purpose_ja': 'クアッドストリップ描画のモーダルツールを開始します。',
            'idname': 'mesh.quad_strip_draw', 'keymap': 'Mesh',
            'shortcut_en': 'Recommended: assign a custom modal-start hotkey', 'shortcut_ja': '推奨: モーダル開始用の任意ホットキーを割り当て',
        },
        {
            'label_en': 'Start Retopo Pen', 'label_ja': 'リトポペンを開始',
            'purpose_en': 'Start the retopology pen modal tool.',
            'purpose_ja': 'リトポロジーペンのモーダルツールを開始します。',
            'idname': 'mesh.qsd_retopo_pen', 'keymap': 'Mesh',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
    ),
    'modeling_toolset_tools': (
        {
            'label_en': 'Model by Context', 'label_ja': 'コンテキストに応じて作成',
            'purpose_en': 'Run context-sensitive fill, inset, extrude, or bridge operations from the current mesh selection.',
            'purpose_ja': '選択状態に応じて面張り、インセット、押し出し、ブリッジを実行します。',
            'idname': 'smsuite.context_modeler', 'keymap': 'Mesh',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Shape Loops', 'label_ja': 'ループ形状を調整',
            'purpose_en': 'Circle, relax, space, bridge, and flatten selected loops with Loop Tools-style fallbacks.',
            'purpose_ja': '選択ループを円形化、リラックス、等間隔化、ブリッジ、平面化します。',
            'idname': 'smsuite.loop_shape_suite', 'keymap': 'Mesh',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Rebuild Quads', 'label_ja': 'クアッドを再構築',
            'purpose_en': 'Rebuild selected topology with fill, grid fill, tris-to-quads, and cleanup operations.',
            'purpose_ja': '面張り、格子面張り、三角形から四角形への変換、整理でトポロジーを再構築します。',
            'idname': 'smsuite.quad_rebuild', 'keymap': 'Mesh',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Align and Unbend', 'label_ja': '整列して直線化',
            'purpose_en': 'Align selected vertices to a best-fit line or local axis.',
            'purpose_ja': '選択頂点をベストフィット線またはローカル軸へ揃えます。',
            'idname': 'smsuite.align_unbend', 'keymap': 'Mesh',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Create Boolean Fusion', 'label_ja': 'ブーリアン融合を作成',
            'purpose_en': 'Create a non-destructive boolean, bevel, and weighted-normal hard-surface stack.',
            'purpose_ja': '非破壊ブーリアン、ベベル、重み付き法線のハードサーフェススタックを作成します。',
            'idname': 'smsuite.boolean_fusion_stack', 'keymap': 'Object Mode',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Apply and Clean Boolean', 'label_ja': 'ブーリアンを適用して整理',
            'purpose_en': 'Apply boolean modifiers and clean the resulting mesh.',
            'purpose_ja': 'ブーリアンモディファイアを適用し、結果メッシュを整理します。',
            'idname': 'smsuite.boolean_apply_clean', 'keymap': 'Object Mode',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Create Bevel Normal Stack', 'label_ja': 'ベベル法線スタックを作成',
            'purpose_en': 'Add a bevel and weighted-normal stack for hard-surface shading.',
            'purpose_ja': 'ハードサーフェスの陰影を整えるベベルと重み付き法線スタックを追加します。',
            'idname': 'smsuite.bevel_normal_stack', 'keymap': 'Object Mode',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Clean Planar Bevels', 'label_ja': '平面ベベルを整理',
            'purpose_en': 'Limited-dissolve near-planar bevel support edges and recalculate normals.',
            'purpose_ja': 'ほぼ平面のベベル補助辺を制限溶解し、法線を再計算します。',
            'idname': 'smsuite.unbevel_planar_clean', 'keymap': 'Mesh',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Create Solidify Shell', 'label_ja': 'シェル厚みを作成',
            'purpose_en': 'Add robust thickness, optional bevels, and weighted normals.',
            'purpose_ja': '堅牢な厚み付け、任意のベベル、重み付き法線を追加します。',
            'idname': 'smsuite.solidify_plus', 'keymap': 'Object Mode',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Insert Kit Asset', 'label_ja': 'キット素材を挿入',
            'purpose_en': 'Place selected kit assets onto the active surface and optionally prepare boolean cuts.',
            'purpose_ja': '選択キット素材をアクティブ面へ配置し、必要に応じてブーリアンカットを準備します。',
            'idname': 'smsuite.kit_insert', 'keymap': 'Object Mode',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Create Cable Pipe', 'label_ja': 'ケーブルパイプを作成',
            'purpose_en': 'Create cables or pipes from selected curves or mesh edges.',
            'purpose_ja': '選択カーブまたは選択辺からケーブルやパイプを作成します。',
            'idname': 'smsuite.cable_pipe_from_selection', 'keymap': 'Mesh',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Generate Rail Sweep', 'label_ja': 'レールスイープを生成',
            'purpose_en': 'Turn curves into rails or duplicate source objects along curves.',
            'purpose_ja': 'カーブをレール化するか、ソースオブジェクトをカーブ沿いに複製します。',
            'idname': 'smsuite.rail_sweep_generator', 'keymap': 'Object Mode',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Bend and Project', 'label_ja': '曲げて投影',
            'purpose_en': 'Add bend deformation or project selected geometry to a target surface.',
            'purpose_ja': '曲げ変形を追加するか、選択形状をターゲット面へ投影します。',
            'idname': 'smsuite.bend_projection', 'keymap': 'Object Mode',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Wrap and Remesh', 'label_ja': '追従してリメッシュ',
            'purpose_en': 'Add remesh and shrinkwrap-based retopology helpers.',
            'purpose_ja': 'リメッシュとシュリンクラップによるリトポ補助を追加します。',
            'idname': 'smsuite.retopo_wrap_remesh', 'keymap': 'Object Mode',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Deform with Falloff', 'label_ja': 'フォールオフで変形',
            'purpose_en': 'Apply radial falloff deformation around the 3D cursor.',
            'purpose_ja': '3Dカーソル中心の放射フォールオフで変形を適用します。',
            'idname': 'smsuite.falloff_deform', 'keymap': 'Mesh',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Scatter on Surface', 'label_ja': '表面に散布',
            'purpose_en': 'Scatter selected source objects over the active mesh surface.',
            'purpose_ja': '選択ソースオブジェクトをアクティブメッシュ表面へ散布します。',
            'idname': 'smsuite.scatter_surface', 'keymap': 'Object Mode',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Generate Floor and Wall', 'label_ja': '床と壁を生成',
            'purpose_en': 'Generate floor tiles, brick walls, stairs, and facade grids.',
            'purpose_ja': '床タイル、レンガ壁、階段、ファサードグリッドを生成します。',
            'idname': 'smsuite.floor_wall_generator', 'keymap': 'Object Mode',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Generate Terrain', 'label_ja': '地形を生成',
            'purpose_en': 'Generate editable procedural terrain meshes.',
            'purpose_ja': '編集可能なプロシージャル地形メッシュを生成します。',
            'idname': 'smsuite.terrain_generator', 'keymap': 'Object Mode',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Add Slice Wire Detail', 'label_ja': 'スライスワイヤ詳細を追加',
            'purpose_en': 'Add wireframe detail stacks or slicing guide planes.',
            'purpose_ja': 'ワイヤーフレーム詳細スタックまたはスライスガイド平面を追加します。',
            'idname': 'smsuite.slice_wire_detail', 'keymap': 'Object Mode',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Add Modifier Stack', 'label_ja': 'モディファイアスタックを追加',
            'purpose_en': 'Add non-destructive hard-surface, array, detail, or cleanup stacks.',
            'purpose_ja': '非破壊のハードサーフェス、配列、ディテール、整理スタックを追加します。',
            'idname': 'smsuite.modifier_stack_preset', 'keymap': 'Object Mode',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Audit and Repair Mesh', 'label_ja': 'メッシュを監査して修復',
            'purpose_en': 'Audit and repair selected meshes for loose geometry, doubles, and normals.',
            'purpose_ja': 'ルーズ形状、重複頂点、法線を監査して修復します。',
            'idname': 'smsuite.mesh_repair_audit', 'keymap': 'Object Mode',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Clean CAD Import', 'label_ja': 'CADインポートを整理',
            'purpose_en': 'Clean imported CAD, DWG, Plasticity, MoI3D, and kitbash assets.',
            'purpose_ja': 'インポートしたCAD、DWG、Plasticity、MoI3D、キットバッシュ素材を整理します。',
            'idname': 'smsuite.cad_import_cleaner', 'keymap': 'Object Mode',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Set Workplane and Pivot', 'label_ja': '作業平面と原点を設定',
            'purpose_en': 'Place the 3D cursor, object origin, or helper workplane from the selection.',
            'purpose_ja': '選択から3Dカーソル、原点、補助作業平面を配置します。',
            'idname': 'smsuite.workplane_pivot_tools', 'keymap': 'Object Mode',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Drop and Snap', 'label_ja': '接地してスナップ',
            'purpose_en': 'Drop, snap, or align selected objects to the active target or floor.',
            'purpose_ja': '選択オブジェクトをアクティブ対象または床へ接地、スナップ、整列します。',
            'idname': 'smsuite.drop_snap_tools', 'keymap': 'Object Mode',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Replace and Randomize Assets', 'label_ja': 'アセットを置換してランダム化',
            'purpose_en': 'Replace placeholders with the active object or randomize selected transforms.',
            'purpose_ja': 'プレースホルダーをアクティブオブジェクトで置換するか、選択の変形をランダム化します。',
            'idname': 'smsuite.asset_replace_randomize', 'keymap': 'Object Mode',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
        {
            'label_en': 'Solo Visibility', 'label_ja': '単独表示',
            'purpose_en': 'Isolate, reveal, or hide selected objects for focused layout inspection.',
            'purpose_ja': '集中確認用に選択オブジェクトを単独表示、全表示、非表示にします。',
            'idname': 'smsuite.magic_solo', 'keymap': 'Object Mode',
            'shortcut_en': 'Assign manually if needed', 'shortcut_ja': '必要に応じて手動割り当て',
        },
    ),

}

def _sms_build_valid_ui_icons():
    """Build the icon identifier snapshot only at the explicit register boundary."""
    icons = set()
    try:
        ui_layout = getattr(getattr(bpy, 'types', None), 'UILayout', None)
        bl_rna = getattr(ui_layout, 'bl_rna', None) if ui_layout is not None else None
        functions = getattr(bl_rna, 'functions', None) if bl_rna is not None else None
        fn = None
        if functions is not None:
            try:
                fn = functions.get('prop')
            except Exception:
                try:
                    fn = functions['prop']
                except Exception:
                    fn = None
        params = getattr(fn, 'parameters', None) if fn is not None else None
        icon_param = None
        if params is not None:
            try:
                icon_param = params.get('icon')
            except Exception:
                try:
                    icon_param = params['icon']
                except Exception:
                    icon_param = None
        enum_items = getattr(icon_param, 'enum_items', None) if icon_param is not None else None
        if enum_items is not None:
            try:
                icons = {str(item.identifier) for item in enum_items if getattr(item, 'identifier', None)}
            except Exception:
                try:
                    icons = {str(key) for key in enum_items.keys()}
                except Exception:
                    icons = set()
    except Exception:
        icons = set()
    return frozenset(icons)


def _sms_valid_ui_icons():
    """Pure read used by Panel.draw; cache construction never occurs here."""
    cached = _SMS_UI_ICON_CACHE
    return cached if isinstance(cached, frozenset) else frozenset()


def _sms_safe_icon(icon, fallback='TOOL_SETTINGS'):
    icon = str(icon or '').strip()
    fallback = str(fallback or 'NONE').strip() or 'NONE'
    if not icon:
        icon = fallback
    icon = _SMS_UI_ICON_ALIASES.get(icon, icon)
    fallback = _SMS_UI_ICON_ALIASES.get(fallback, fallback)
    valid_icons = _sms_valid_ui_icons()
    if valid_icons:
        if icon in valid_icons:
            return icon
        if fallback in valid_icons:
            return fallback
        if 'NONE' in valid_icons:
            return 'NONE'
    return icon or fallback


_SMS_COMMAND_ICON_EXACT = {
    'vscp.copy_vertices': 'COPYDOWN',
    'vscp.validate_targets': 'VIEWZOOM',
    'vscp.paste_vertices': 'PASTEDOWN',
    'vscp.apply_preset': 'PRESET',
    'mesh.smart_vert_slide': 'EMPTY_ARROWS',
    'mesh.smart_connect': 'MOD_EDGESPLIT',
    'mesh.mesh_align_master': 'EMPTY_ARROWS',
    'mesh.align_view': 'VIEW3D',
    'mesh.align_linear_3d': 'EMPTY_ARROWS',
    'mesh.set_flow': 'FORCE_CURVE',
    'mesh.delete_direct': 'TRASH',
    'mesh.delete_direct_del': 'EVENT_DEL',
    'mesh.delete_direct_bs': 'EVENT_BACKSPACE',
    'mesh.delete_direct_through': 'XRAY',
    'object.delete_direct_objects': 'OUTLINER_OB_MESH',
    'mo2.organize_modal': 'OUTLINER_COLLECTION',
    'mo2.restore_backup': 'LOOP_BACK',
    'mo2.clear_backup': 'TRASH',
    'mo2.rename_data_to_object_name': 'SORTALPHA',
    'mesh.edge_crease_master': 'MOD_BEVEL',
    'mesh.crease_apply': 'MOD_BEVEL',
    'view3d.toggle_edge_crease_overlay': 'OVERLAY',
    'mesh.toggle_merge_snap': 'SNAP_ON',
    'mesh.tams_cycle_snap': 'FILE_REFRESH',
    'mesh.tams_quick_popup': 'PREFERENCES',
    'mesh.apply_weighted_normal': 'MOD_NORMALEDIT',
    'smsk.annotation_to_curve': 'CURVE_DATA',
    'smsk.annotation_to_surface_strip': 'MESH_DATA',
    'mesh.quad_strip_draw': 'MESH_GRID',
    'mesh.qsd_retopo_pen': 'MOD_SHRINKWRAP',
    'mesh.qsd_retopo_setup_popup': 'MOD_SHRINKWRAP',
    'mesh.qsd_guides_popup': 'CURVE_DATA',
    'mesh.qsd_field_paint_popup': 'BRUSH_DATA',
    'mesh.qsd_fill_tools_popup': 'MESH_GRID',
    'mesh.qsd_boundary_trace_popup': 'TRACKING_FORWARDS',
    'smsuite.context_modeler': 'EDITMODE_HLT',
    'smsuite.loop_shape_suite': 'FORCE_CURVE',
    'smsuite.quad_rebuild': 'MESH_GRID',
    'smsuite.align_unbend': 'EMPTY_ARROWS',
    'smsuite.boolean_fusion_stack': 'MOD_BOOLEAN',
    'smsuite.boolean_apply_clean': 'CHECKMARK',
    'smsuite.bevel_normal_stack': 'MOD_BEVEL',
    'smsuite.unbevel_planar_clean': 'MOD_DECIM',
    'smsuite.solidify_plus': 'MOD_SOLIDIFY',
    'smsuite.kit_insert': 'MESH_CUBE',
    'smsuite.cable_pipe_from_selection': 'CURVE_PATH',
    'smsuite.rail_sweep_generator': 'CURVE_PATH',
    'smsuite.bend_projection': 'MOD_SIMPLEDEFORM',
    'smsuite.retopo_wrap_remesh': 'MOD_SHRINKWRAP',
    'smsuite.falloff_deform': 'FORCE_HARMONIC',
    'smsuite.scatter_surface': 'PARTICLES',
    'smsuite.floor_wall_generator': 'MESH_GRID',
    'smsuite.terrain_generator': 'RNDCURVE',
    'smsuite.slice_wire_detail': 'MOD_WIREFRAME',
    'smsuite.modifier_stack_preset': 'MODIFIER',
    'smsuite.mesh_repair_audit': 'VIEWZOOM',
    'smsuite.cad_import_cleaner': 'MOD_DECIM',
    'smsuite.workplane_pivot_tools': 'PIVOT_CURSOR',
    'smsuite.drop_snap_tools': 'SNAP_ON',
    'smsuite.asset_replace_randomize': 'FILE_REFRESH',
    'smsuite.magic_solo': 'HIDE_OFF',
}

_SMS_COMMAND_ICON_RULES = (
    ('delete remove trash clear purge erase', 'TRASH'),
    ('through xray', 'XRAY'),
    ('copy duplicate clone', 'COPYDOWN'),
    ('paste apply transfer', 'PASTEDOWN'),
    ('validate audit inspect check', 'VIEWZOOM'),
    ('restore backup undo back', 'LOOP_BACK'),
    ('connect bridge link', 'MOD_EDGESPLIT'),
    ('subdivide split slice cut knife', 'MOD_EDGESPLIT'),
    ('slide move transform', 'EMPTY_ARROWS'),
    ('align line straighten unbend flow', 'EMPTY_ARROWS'),
    ('crease bevel chamfer fillet round', 'MOD_BEVEL'),
    ('normal normals weighted shade shading', 'MOD_NORMALEDIT'),
    ('snap merge magnet floor drop', 'SNAP_ON'),
    ('cycle refresh reload update rebuild', 'FILE_REFRESH'),
    ('curve path rail pipe cable sweep', 'CURVE_DATA'),
    ('annotation grease sketch pencil draw', 'GREASEPENCIL'),
    ('surface strip mesh grid quad retopo fill grid', 'MESH_GRID'),
    ('paint brush field', 'BRUSH_DATA'),
    ('shrinkwrap wrap conform project projection', 'MOD_SHRINKWRAP'),
    ('boolean union difference intersect intersect slice', 'MOD_BOOLEAN'),
    ('solidify thickness shell', 'MOD_SOLIDIFY'),
    ('array stack modifier preset', 'MODIFIER'),
    ('decimate dissolve clean repair cad cleanup', 'MOD_DECIM'),
    ('material shader texture uv color', 'MATERIAL'),
    ('terrain landscape mountain', 'RNDCURVE'),
    ('scatter particle particles distribute random', 'PARTICLES'),
    ('cursor origin pivot workplane plane', 'PIVOT_CURSOR'),
    ('solo isolate reveal hide show visibility', 'HIDE_OFF'),
    ('import load open file', 'IMPORT'),
    ('export save', 'EXPORT'),
    ('settings preferences setup options', 'PREFERENCES'),
)

def _sms_command_icon(op_id='', label='', desc='', fallback='TOOL_SETTINGS'):
    op_id = str(op_id or '').strip()
    exact = _SMS_COMMAND_ICON_EXACT.get(op_id)
    if exact:
        return _sms_safe_icon(exact, fallback)
    hay = f'{op_id} {label or ""} {desc or ""}'.replace('_', ' ').replace('.', ' ').lower()
    for words, icon in _SMS_COMMAND_ICON_RULES:
        tokens = tuple(str(words).split())
        if any(token and token in hay for token in tokens):
            return _sms_safe_icon(icon, fallback)
    if op_id.startswith('mesh.'):
        return _sms_safe_icon('EDITMODE_HLT', fallback)
    if op_id.startswith('object.'):
        return _sms_safe_icon('OUTLINER_OB_MESH', fallback)
    if op_id.startswith('curve.'):
        return _sms_safe_icon('CURVE_DATA', fallback)
    if op_id.startswith('view3d.'):
        return _sms_safe_icon('VIEW3D', fallback)
    if op_id.startswith('wm.'):
        return _sms_safe_icon('MENU_PANEL', fallback)
    return _sms_safe_icon(fallback, 'TOOL_SETTINGS')


_SMS_CORE_ICON_PREVIEW_COLLECTION = None

def _sms_load_core_icon_previews(force=False):
    """Load root-level Smart Modeling custom icons without relying on add-on preferences."""
    global _SMS_CORE_ICON_PREVIEW_COLLECTION
    if force:
        _sms_release_core_icon_previews()
    if _SMS_CORE_ICON_PREVIEW_COLLECTION is not None:
        return _SMS_CORE_ICON_PREVIEW_COLLECTION
    try:
        import bpy.utils.previews as previews
    except Exception:
        return None
    try:
        pcoll = previews.new()
    except Exception:
        return None
    icon_root = Path(__file__).resolve().parent / 'icons'
    try:
        from . import icon_runtime as _sms_icon_runtime
    except Exception:
        _sms_icon_runtime = None
    loaded = 0
    for key in ('header', 'help', 'clock', 'move_transform_arrows'):
        path = _sms_icon_runtime.resolve_icon_path(key) if _sms_icon_runtime is not None else icon_root / f'{key}.png'
        if not path.is_file():
            continue
        try:
            pcoll.load(key, str(path), 'IMAGE')
            loaded += 1
        except Exception:
            pass
    if loaded:
        _SMS_CORE_ICON_PREVIEW_COLLECTION = pcoll
        return pcoll
    try:
        previews.remove(pcoll)
    except Exception:
        pass
    return None


def _sms_core_icon_value(name, fallback=0):
    key = str(name or '').strip()
    if not key:
        return int(fallback or 0)
    try:
        pcoll = _sms_load_core_icon_previews(force=False)
        item = pcoll.get(key) if pcoll is not None else None
        value = int(getattr(item, 'icon_id', 0) or 0)
        if value:
            return value
    except Exception:
        pass
    try:
        from . import common as _sms_common_icons
        return int(_sms_common_icons.icon_value(key, fallback) or fallback or 0)
    except Exception:
        return int(fallback or 0)


def _sms_release_core_icon_previews():
    global _SMS_CORE_ICON_PREVIEW_COLLECTION
    pcoll = _SMS_CORE_ICON_PREVIEW_COLLECTION
    _SMS_CORE_ICON_PREVIEW_COLLECTION = None
    if pcoll is None:
        return
    try:
        import bpy.utils.previews as previews
        previews.remove(pcoll)
    except Exception:
        pass

# ------------------------------------------------------------
# Translations (Toolset-level)
# ------------------------------------------------------------
translation_dict = {
    "ja_JP": {
        # Headings
        ("*", "Smart Modeling"): "Smart Modeling",
        ("*", "Tool Details"): "ツール詳細",
        ("*", "Review the tools inside the suite. Tools are grouped by runtime behavior."):
            "ツールセット内のツールを確認します。ツールは動作負荷の種類別に分類されています。",
        # Tool names
        ("*", "Vertex Copy"): "頂点コピー",
        ("*", "Vertex Slide"): "頂点スライド",
        ("*", "Direct Delete"): '直接削除',
        ("*", "Model Organizer"): 'モデル整理',
        ("*", "Mesh Align"): "メッシュ整列",
        ("*", "Mesh Split"): "メッシュ分割",
    ("*", "Show Mesh Split"): 'メッシュ分割を表示',
    ("*", "Enable Mesh Split"): 'メッシュ分割を有効化',
    ("*", "Run Mesh Split"): "メッシュ分割を実行",
    ("*", "Expand or collapse the Mesh Split section inside the Smart Modeling N-panel."): 'N パネルのメッシュ分割の項目を開閉します。',
    ("*", "Crease Preset"): "クリースプリセット",
        ("*", "Merge Snap"): "マージスナップ",
        ("*", "Apply Weighted Normal"): "重み付き法線を適用",
        ("*", "Smart Modifier Notice"): "Smart Modifier への移行案内",
        ("*", "Modifier-style workflows moved to Smart Modifier. Install/enable Smart Modifier to add and execute migrated modifiers from Smart Modifier's Add Modifier menu (including Stack Tools).\nCore direct-modeling tools remain here."): "モディファイア系ワークフローは Smart Modifier へ移行しました。移行したモディファイアを追加・実行するには、Smart Modifier の『モディファイアを追加』（Stack Tools 含む）を使ってください。\nこちらには直接モデリング系ツールが残ります。",
        ("*", "Detected and ready"): "検出済み・使用可能",
        ("*", "Not detected"): "未検出",
        ("*", "Recommended split"): "推奨される役割分担",
        ("*", "Current status"): "現在の状態",
        ("*", "Smart Modifier: booleans, pipes, sweeps, conform, deformers, CAD, audit, slice, scatter, and stack-managed modifier tools."): 'Smart Modifier: ブーリアン、パイプ、スイープ、面への追従、変形、CAD、点検、スライス、散布、スタック管理のモディファイアー',
        ("*", "Smart Modeling: direct edit, delete, align, crease, normals, organization, sketch, quad-strip."): "Smart Modeling: 直接編集、削除、整列、クリース、法線、整理、スケッチ、クアッドストリップ。",
        ("*", "Smart Modifier is enabled."): "Smart Modifier は有効です。",
        ("*", "Smart Modifier is not enabled or not detected."): "Smart Modifier は無効、または未検出です。",
        ("*", "Enable it to access migrated modifier tools."): "移行済みモディファイアツールにアクセスするには有効化してください。",
        ("*", "Modifier Stack UI stays in Smart Modifier."): 'モディファイアースタックの画面は Smart Modifier にあります。',
        ("*", "Use Smart Modifier > Preflight / Compatibility to verify companion tools and fallback readiness."): 'Smart Modifier の事前確認 / 互換性で、連携ツールと代替の準備を確かめられます。',
        ("*", "Use Smart Modifier > Tool Browser / Search to see live blockers before running migrated tools."): '実行前に Smart Modifier のツール一覧 / 検索で足りない条件を確かめられます。',
        ("*", "Context quick picks in Smart Modifier help surface tools that are already ready in the current mode / selection."): "Smart Modifier の Context quick picks で、現在のモード / 選択ですぐ使えるツールを見つけやすくなります。",
        ("*", "Smart Modifier layout helpers now also include Align To Active and Distribute Selected for archviz-style placement cleanup."): "Smart Modifier のレイアウト補助には、Archviz 風の配置整理向けに アクティブへ整列 と 選択を均等配置 も追加されています。",
        # Keymap section
        ("*", "Keymap / Shortcut"): "キーマップ / ショートカット",
        ("*", "Manual Keymap Registration"): "手動キーマップ登録",
        ("*", "Smart Modeling Suite does not register shortcuts automatically. Use the location as a guide and copy only the registration ID."): "Smart Modeling Suite はショートカットを自動登録しません。登録場所を目安にし、登録IDのみをコピーして手動登録してください。",
        ("*", "Copyable Keymap Info"): "コピー用キーマップ情報",
        ("*", "The registration location and purpose are shown for reference. Only the registration ID is copyable."): "登録場所と用途は参照用に表示します。コピーできる項目は登録IDのみです。",
        ("*", "Purpose"): "用途",
        ("*", "Only the registration ID is copyable. Paste it into Preferences > Keymap search or a new keymap item."): "コピーできる項目は登録IDのみです。プリファレンス > キーマップの検索欄または新規キーマップ項目へ貼り付けてください。",
        ("*", "Copy only the registration ID, then paste it into Preferences > Keymap search or a new keymap item."): "登録IDだけをコピーし、プリファレンス > キーマップの検索欄または新規キーマップ項目へ貼り付けてください。",
        ("*", "Clipboard is not available."): "クリップボードを使用できません。",
        ("*", "Copied"): "コピーしました",
        ("*", "(These are editable text fields so you can copy & paste.)"): "（コピー用の編集可能テキストです）",
        ("*", "Unassigned (set your own)"): "未割り当て（任意に設定）",
        ("*", "Operator ID (Main)"): "オペレーターID（メイン）",
        ("*", "Operator ID (DEL override)"): 'コマンド ID（DEL の上書き）',
        ("*", "Operator ID (Backspace override)"): "オペレーターID（Backspaceを上書き）",
        ("*", "Operator ID (Through)"): "オペレーターID（貫通）",
        ("*", "Operator ID"): 'コマンド ID',
        ("*", "Keymap Name"): "キーマップ名",
        ("*", "Default / Recommended Shortcut"): "既定/推奨ショートカット",
        ("*", "Where to register"): "登録場所",
        ("*", "How to register"): "登録方法",
        ("*", "Open Preferences > Keymap, search the Operator ID, and add a new key binding under the specified Keymap Name."):
            "「編集 > プリファレンス > キーマップ」でオペレーターIDを検索し、指定のキーマップ名の下で新規キーバインドを追加してください。",
        ("*", "Edit > Preferences > Keymap > Mesh (Global)"):
            "編集 > プリファレンス > キーマップ > メッシュ（グローバル）",
        ("*", "Mesh"): "メッシュ",
        # Property names (suite toggles)
        ("*", "Enable Vertex Copy"): '頂点コピーを有効化',
        ("*", "Enable Vertex Slide"): '頂点スライドを有効化',
        ("*", "Enable Direct Delete"): '直接削除を有効化',
        ("*", "Enable Model Organizer"): 'モデル整理を有効化',
        ("*", "Enable Mesh Align"): 'メッシュ整列を有効化',
        ("*", "Enable Crease Preset"): 'クリースプリセットを有効化',
        ("*", "Enable Merge Snap"): 'マージとスナップを有効化',
        ("*", "Enable Apply Weighted Normal"): '重み付き法線を有効化',
        # Property descriptions (tooltips)
        ("*", "Show/hide Vertex Copy UI and prevent its operators from being used when disabled."):
            "無効化すると頂点コピーのUIを非表示にし、オペレーターの使用も抑止します。",
        ("*", "Show/hide Vertex Slide UI and runtime. Shortcuts are manual-only and are never registered automatically."):
            "Vertex Slide のUIとランタイム表示を切り替えます。ショートカットは手動登録専用で、自動登録されません。",
        ("*", "Show/hide Direct Delete UI and runtime. Delete / Backspace shortcuts are manual-only and are never registered automatically."):
            "Direct Delete のUIとランタイムを切り替えます。Delete / Backspace ショートカットは手動登録専用で、自動登録されません。",
        ("*", "Show/hide Model Organizer UI and operators."):
            '無効化するとモデル整理のUIとオペレーターを抑止します。',
        ("*", "Show/hide Mesh Align operators and menus."):
            '無効化すると メッシュ整列 のオペレーター/メニューを抑止します。',
        ("*", "Show/hide Crease Preset operators and menus."):
            '無効化するとクリースプリセットのオペレーター/メニューを抑止します。',
        ("*", "Show/hide Merge Snap operators."):
            'マージとスナップのコマンドを表示/非表示にします。',
        ("*", "Show/hide Apply Weighted Normal operators and its Alt+N menu entry."):
            '重み付き法線のコマンドと Alt+N メニューの項目を表示/非表示にします。',
        ("*", "The optional panel always appears under the Smart Modeling tab."):
            "任意パネルは常に Smart Modeling タブ内に表示されます。",
        ("*", "This add-on follows Blender's interface language automatically."):
            "このアドオンは Blender のインターフェース言語設定に自動追従します。",
        ("*", "Ready"): "使用可能",
        ("*", "Missing: "): "不足: ",
        ("*", "Requires: "): "前提: ",
        # Keymap field descriptions
        ("*", "Copy this text and paste into Preferences > Keymap search or into a keymap item."):
            "このテキストをコピーして「プリファレンス > キーマップ」の検索欄、またはキーマップ項目に貼り付けてください。",
        ("*", "This is the Blender keymap section name where the shortcut should be added."):
            "ショートカットを追加するBlenderのキーマップセクション名です。",
        ("*", "Default or recommended shortcut for this feature. You can change it in Blender Preferences > Keymap."):
            "この機能の既定/推奨ショートカットです。「プリファレンス > キーマップ」で変更できます。",
        ("*", "Exact UI path in Blender Preferences > Keymap where you should add the shortcut."):
            "「プリファレンス > キーマップ」でショートカットを追加する正確な場所（パス）です。",
        ("*", "Step-by-step instructions."):
            "手順の説明です。",
        ("*", "Open Preferences > Keymap, paste this ID into the search box, then add a shortcut for this operator."):
            "「編集 > プリファレンス > キーマップ」で、このIDを検索欄に貼り付け、オペレーターにショートカットを追加してください。",
        # Additional detailed lines used in the reworked N-panel UI
        ("*", "Smart vertex position transfer between meshes with smart matching and preview."):
            "スマートマッチングとプレビューでメッシュ間の頂点位置を転送します。",
        ("*", "Verify matches and visualize correspondences before applying."):
            "適用前に対応を検証し、対応線を可視化できます。",
        ("*", "Optionally Pin/Exclude individual pairs by clicking overlay lines in the 3D View."):
            '3D ビューの対応の線をクリックして、組を固定 / 除外できます。',
        ("*", "1) Select source and target meshes (active object is the target)."):
            "1) コピー元と貼り付け先メッシュを選択（アクティブが貼り付け先）",
        ("*", "2) Run Copy/Preview and inspect the overlay."):
            '2) コピー/プレビューを実行し、オーバーレイで確かめます。',
        ("*", "3) In Pair Line Edit, click lines to Pin (keep) or Exclude (ignore)."):
            "3) 対応ライン個別編集でラインをクリックし、固定（保持）/除外（無視）を設定",
        ("*", "4) Recalculate if needed, then Apply to commit the result."):
            '4) 必要なら再計算し、適用で確定します。',
        ("*", "Enhanced Vertex Slide for faster retopo and cleanup."):
            "リトポや整理を高速化する強化版の頂点スライドです。",
        ("*", "Supports multi-object edit, HUD display, and proportional options."):
            "マルチオブジェクト編集、HUD表示、プロポーショナル設定に対応します。",
        ("*", "Loop/Ring priority helps maintain clean edge flow while sliding."):
            "ループ/リング優先で、スライド中のエッジフローを崩しにくくします。",
        ("*", "Edit Mode: select vertices/edges (supports multiple objects in multi-edit)."):
            "編集モードで頂点/辺を選択（マルチ編集では複数オブジェクト対応）",
        ("*", "Run Vertex Slide (default Shift+V), then move the mouse to slide."):
            'Vertex Slide（既定 Shift+V）を実行し、マウス移動でスライド',
        ("*", "Confirm / cancel as usual (LMB/Enter to confirm, RMB/Esc to cancel)."):
            "通常通り確定/キャンセル（LMB/Enterで確定、RMB/Escでキャンセル）",
        ("*", "Delete geometry instantly without confirmation popups."):
            "確認ポップアップ無しで素早く削除します。",
        ("*", "Includes Smart delete and dedicated overrides for Delete / Backspace."):
            "選択を削除に加え、Delete/Backspace 上書き用のオペレーターを収録します。",
        ("*", "Also includes a Through variant for specific workflows."):
            "用途に応じた貫通版（Through）も収録しています。",
        ("*", "If you manually bind the registration IDs below, press those keys in Edit Mode for instant delete."):
            "下記の登録IDを手動で割り当てた場合、編集モードでそのキーを押すと即削除します。",
        ("*", "You can also run Direct Delete operators from F3 search."):
            "F3 検索から Direct Delete オペレーターを実行することもできます。",
        ("*", "Fine-tune behavior in the Direct Delete panel (modes, options, etc.)."):
            "Direct Delete パネルで挙動（モード/各種オプション）を調整できます。",
        ("*", "Organize and clean up models with safe, preset-driven operations."):
            "安全なプリセット駆動の処理でモデルを整理・クリーンアップします。",
        ("*", "Includes backup/restore, cleanup helpers, modifier keep, and utilities."):
            "バックアップ/復元、クリーンアップ補助、モディファイア保持、各種ユーティリティを含みます。",
        ("*", "Open the Model Organizer panel and run Organize / cleanup operators."):
            'モデル整理のパネルを開き、整理や各種の掃除を実行します。',
        ("*", "Use Backup/Restore to revert changes when needed."):
            "必要に応じて Backup/Restore で変更を戻せます。",
        ("*", "Adjust presets and options directly in the panel."):
            "プリセットやオプションはパネル内で調整します。",
        ("*", "Popup preset menu for common mesh alignment operations."):
            "よく使うメッシュ整列操作をまとめたポップアッププリセットメニューです。",
        ("*", "Includes standard align, distribute evenly, view/grid align, loop align, annotation align, etc."):
            "標準整列、均等配置、ビュー/グリッド整列、ループ整列、アノテーション整列などを含みます。",
        ("*", "Run Mesh Align from F3 (assign a shortcut if desired)."):
            "F3 からメッシュ整列を実行します（必要ならショートカット割当）。",
        ("*", "Choose a preset in the popup and follow the header hints."):
            "ポップアップでプリセットを選び、ヘッダーの案内に従って操作します。",
        ("*", "Use Alt/Ctrl modifiers for slide-based / all-objects behaviors when available."):
            "機能に応じて Alt/Ctrl 修飾キーでスライド基準/全オブジェクト適用などを切り替えます。",
        ("*", "Popup menu for setting edge crease values quickly."):
            "エッジのクリース値を素早く設定するポップアップメニューです。",
        ("*", "Useful for Subdivision / hard-surface workflows."):
            "サブディビジョン/ハードサーフェス作業に便利です。",
        ("*", "Edit Mode: select edges, then run the Open Crease Presets."):
            "編集モードで辺を選択し、クリースプリセットを実行します。",
        ("*", "Choose a crease value to apply to the selection."):
            "選択に適用するクリース値を選びます。",
        ("*", "Quick toggles for Auto Merge and Snap."):
            "自動マージとスナップを素早く切り替えます。",
        ("*", "Includes a configurable cycle list and a quick popup for snap settings."):
            "スナップ設定のサイクルリストとクイックポップアップを備えています。",
        ("*", "Run Toggle Merge and Snap (assign a shortcut if desired)."):
            'マージとスナップの切り替えを実行します（必要ならショートカットを割り当てます）。',
        ("*", "Use the panel to cycle snap modes and open quick settings."):
            "パネルからスナップモードの切替やクイック設定を開けます。",
        ("*", "Apply a Weighted Normal setup quickly to improve shading."):
            "シェーディング改善のために Weighted Normal を素早く適用します。",
        ("*", "Usually accessed via the Alt+N normals menu, but can be hotkeyed."):
            "通常は Alt+N の法線メニューから使いますが、ホットキー割当も可能です。",
        ("*", "Use Alt+N > Apply Weighted Normal."):
            "Alt+N > Apply Weighted Normal を使用します。",
        ("*", "Or assign a shortcut to the operator for one-click access."):
            "またはオペレーターにショートカットを割り当ててワンクリック実行できます。",
        ("*", "Copy the text to the system clipboard."):
            "テキストをクリップボードにコピーします。",
        ("*", "Copy the displayed registration ID to the system clipboard."):
            "表示中の登録IDをクリップボードへコピーします。",
        ("*", "The registration location and purpose are shown for reference. Only the registration ID is copyable."):
            "登録場所と用途は参照用に表示します。コピーできる項目は登録IDのみです。",
        ("*", "Purpose"):
            "用途",
        ("*", "Only the registration ID is copyable. Paste it into Preferences > Keymap search or a new keymap item."):
            "コピーできる項目は登録IDのみです。プリファレンス > キーマップの検索欄または新規キーマップ項目へ貼り付けてください。",
        ("*", "Registration Location"):
            "登録場所",
        ("*", "Recommended / Existing Shortcut"):
            "推奨 / 既存ショートカット",
        ("*", "Required Properties"):
            "必要プロパティ",
        # N-panel UI (FULL I18N)
        ("*", "Copy"):
            "コピー",
        ("*", "Open Crease Presets"):
            "クリースプリセット",
        ("*", "Toggle Merge and Snap"):
            "マージとスナップを切替",
        ("*", "Show/hide Vertex Slide UI and block its operator when disabled."):
            "無効化すると Vertex Slide のUIを非表示にし、オペレーターの使用も抑止します。",
        ("*", "Enabled"):
            "\u6709\u52b9",
        ("*", "Overview"):
            "\u6982\u8981",
        ("*", "How to use"):
            "\u4f7f\u3044\u65b9",
        ("*", "Keymap Setup"):
            "\u30ad\u30fc\u30de\u30c3\u30d7\u8a2d\u5b9a",
        ("*", "Keymap Registration ID"):
            "\u30ad\u30fc\u30de\u30c3\u30d7\u767b\u9332\u7528ID",
        ("*", "Keymap Registration ID (Main)"):
            "\u30ad\u30fc\u30de\u30c3\u30d7\u767b\u9332\u7528ID\uff08\u30e1\u30a4\u30f3\uff09",
        ("*", "Keymap Registration ID (DEL override)"):
            'キーマップ登録用 ID（DEL の上書き）',
        ("*", "Keymap Registration ID (Backspace override)"):
            'キーマップ登録用ID（Backspaceを上書き）',
        ("*", "Keymap Registration ID (Through)"):
            'キーマップ登録用 ID（貫通）',
        ("*", "Keymap Display Name"):
            "\u30ad\u30fc\u30de\u30c3\u30d7\u8868\u793a\u540d",
        ("*", "Copied to clipboard"):
            "\u30af\u30ea\u30c3\u30d7\u30dc\u30fc\u30c9\u306b\u30b3\u30d4\u30fc\u3057\u307e\u3057\u305f",
        ("*", "Copy / paste vertex positions using clipboard slots (Edit Mode)."):
            "\u30af\u30ea\u30c3\u30d7\u30dc\u30fc\u30c9\u30b9\u30ed\u30c3\u30c8\u3092\u4f7f\u3063\u3066\u9802\u70b9\u4f4d\u7f6e\u3092\u30b3\u30d4\u30fc/\u30da\u30fc\u30b9\u30c8\u3057\u307e\u3059\uff08\u7de8\u96c6\u30e2\u30fc\u30c9\uff09\u3002",
        ("*", "Supports Exact / Smart / Mirror / Surface Project paste modes for different use cases."):
            '用途に合わせて完全一致 / スマート / ミラー / サーフェス投影の貼り付けを選べます。',
        ("*", "Includes presets and validation tools to prevent mismatched transfers."):
            "\u30df\u30b9\u30de\u30c3\u30c1\u3092\u9632\u3050\u305f\u3081\u306e\u30d7\u30ea\u30bb\u30c3\u30c8\u3068\u691c\u8a3c\u30c4\u30fc\u30eb\u3092\u642d\u8f09\u3057\u3066\u3044\u307e\u3059\u3002",
        ("*", "Optional extra data transfer: weights, UVs, and custom normals (depending on settings)."):
            "\u8a2d\u5b9a\u306b\u3088\u308a\u3001\u30a6\u30a7\u30a4\u30c8\u30fbUV\u30fb\u30ab\u30b9\u30bf\u30e0\u6cd5\u7dda\u306a\u3069\u306e\u8ffd\u52a0\u30c7\u30fc\u30bf\u8ee2\u9001\u3082\u53ef\u80fd\u3067\u3059\u3002",
        ("*", "1) In Edit Mode, select the vertices you want to copy, then press Copy (stores into the active slot)."):
            "1) \u7de8\u96c6\u30e2\u30fc\u30c9\u3067\u30b3\u30d4\u30fc\u3057\u305f\u3044\u9802\u70b9\u3092\u9078\u629e\u3057\u3001Copy \u3092\u62bc\u3057\u307e\u3059\uff08\u30a2\u30af\u30c6\u30a3\u30d6\u30b9\u30ed\u30c3\u30c8\u306b\u4fdd\u5b58\uff09\u3002",
        ("*", "2) Choose the paste target (active object, named object, selected objects, or collection) in Transfer Settings."):
            '2) 転送の設定で貼り付け先（アクティブ/名前指定/選択中/コレクション）を選びます。',
        ("*", "3) Pick a Paste Mode (Exact for same topology, Smart for near topology, Mirror for L/R, Surface Project for projection)."):
            '3) 貼り付けの形を選びます（完全一致=同じトポロジー、スマート=近いトポロジー、ミラー=左右、サーフェス投影=投影）。',
        ("*", "4) Press Paste. Use Target / Validate to check candidates before pasting in batch scenarios."):
            "4) Paste \u3092\u62bc\u3057\u307e\u3059\u3002\u30d0\u30c3\u30c1\u8cbc\u308a\u4ed8\u3051\u3067\u306f Target / Validate \u3067\u5019\u88dc\u3092\u4e8b\u524d\u30c1\u30a7\u30c3\u30af\u3067\u304d\u307e\u3059\u3002",
        ("*", "Tip: Start from a preset (Exact / Approximate / Face / Rigid / Cloth) and tweak only what you need."):
            "Tip: \u307e\u305a\u306f\u30d7\u30ea\u30bb\u30c3\u30c8\uff08Exact / Approximate / Face / Rigid / Cloth\uff09\u304b\u3089\u59cb\u3081\u3001\u5fc5\u8981\u306a\u6240\u3060\u3051\u8abf\u6574\u3059\u308b\u306e\u304c\u304a\u3059\u3059\u3081\u3067\u3059\u3002",
        ("*", "Enhanced Vertex Slide operator designed for fast retopo and cleanup."):
            "\u30ea\u30c8\u30dd\u3084\u30e1\u30c3\u30b7\u30e5\u6574\u7406\u3092\u9ad8\u901f\u5316\u3059\u308b\u62e1\u5f35 Vertex Slide \u30aa\u30da\u30ec\u30fc\u30bf\u30fc\u3067\u3059\u3002",
        ("*", "Works with multi-object edit, optional proportional influence, and HUD feedback."):
            "\u30de\u30eb\u30c1\u30aa\u30d6\u30b8\u30a7\u30af\u30c8\u7de8\u96c6\u3001\u30d7\u30ed\u30dd\u30fc\u30b7\u30e7\u30ca\u30eb\u5f71\u97ff\u3001HUD\u8868\u793a\u306b\u5bfe\u5fdc\u3057\u307e\u3059\u3002",
        ("*", "Loop/Ring priority helps keep edge flow clean while sliding."):
            "Loop/Ring \u512a\u5148\u3067\u3001\u30b9\u30e9\u30a4\u30c9\u6642\u306e\u30a8\u30c3\u30b8\u30d5\u30ed\u30fc\u3092\u5d29\u3057\u306b\u304f\u304f\u3057\u307e\u3059\u3002",
        ("*", "Important: This tool does NOT auto-register a shortcut. Bind it in Blender Preferences > Keymap."):
            "\u91cd\u8981: \u3053\u306e\u30c4\u30fc\u30eb\u306f\u30b7\u30e7\u30fc\u30c8\u30ab\u30c3\u30c8\u3092\u81ea\u52d5\u767b\u9332\u3057\u307e\u305b\u3093\u3002\u30d7\u30ea\u30d5\u30a1\u30ec\u30f3\u30b9 > \u30ad\u30fc\u30de\u30c3\u30d7\u3067\u5272\u308a\u5f53\u3066\u3066\u304f\u3060\u3055\u3044\u3002",
        ("*", "1) Enter Edit Mode and select vertices/edges to slide (multi-object selection is supported)."):
            "1) \u7de8\u96c6\u30e2\u30fc\u30c9\u3067\u30b9\u30e9\u30a4\u30c9\u3057\u305f\u3044\u9802\u70b9/\u8fba\u3092\u9078\u629e\u3057\u307e\u3059\uff08\u30de\u30eb\u30c1\u30aa\u30d6\u30b8\u30a7\u30af\u30c8\u9078\u629e\u53ef\uff09\u3002",
        ("*", "2) Run Vertex Slide and move the mouse to slide."):
            "2) Vertex Slide \u3092\u5b9f\u884c\u3057\u3001\u30de\u30a6\u30b9\u79fb\u52d5\u3067\u30b9\u30e9\u30a4\u30c9\u3057\u307e\u3059\u3002",
        ("*", "3) Confirm: LMB / Enter. Cancel: RMB / Esc."):
            "3) \u78ba\u5b9a: LMB / Enter\u3001\u30ad\u30e3\u30f3\u30bb\u30eb: RMB / Esc\u3002",
        ("*", "While running: C cycles behavior (Straight/Stop/Corner). Shift+C toggles Proportional mode."):
            '実行中: C で動きを切り替え（直進/停止/角）。Shift+C でプロポーショナルをオン・オフ',
        ("*", "While running: L toggles Loop priority, R toggles Ring priority, B toggles baseline (Individual/Active)."):
            '実行中: L でループを優先、R でリングを優先、B で基準（個別/アクティブ）を切り替え',
        ("*", "While running: Mouse wheel adjusts proportional radius (when proportional is enabled)."):
            "\u5b9f\u884c\u4e2d: \u30d7\u30ed\u30dd\u30fc\u30b7\u30e7\u30ca\u30eb\u6709\u52b9\u6642\u3001\u30de\u30a6\u30b9\u30db\u30a4\u30fc\u30eb\u3067\u534a\u5f84\u3092\u8abf\u6574\u3057\u307e\u3059\u3002",
        ("*", "To replace Blender's built-in Vertex Slide, rebind its shortcut to this operator."):
            "Blender\u6a19\u6e96\u306e Vertex Slide \u3092\u7f6e\u304d\u63db\u3048\u308b\u5834\u5408\u3001\u305d\u306e\u30b7\u30e7\u30fc\u30c8\u30ab\u30c3\u30c8\u3092\u3053\u306e\u30aa\u30da\u30ec\u30fc\u30bf\u30fc\u306b\u5272\u308a\u5f53\u3066\u76f4\u3057\u307e\u3059\u3002",
        ("*", "1) Preferences > Keymap > search for 'Vertex Slide' (operator: transform.vert_slide)."):
            '1) プリファレンス > キーマップで「頂点スライド」を検索します（コマンド: transform.vert_slide）。',
        ("*", "2) Change that entry to this ID, or add a new entry with the same shortcut:"):
            "2) \u305d\u306e\u9805\u76ee\u3092\u3053\u306eID\u306b\u7f6e\u63db\u3059\u308b\u304b\u3001\u540c\u3058\u30b7\u30e7\u30fc\u30c8\u30ab\u30c3\u30c8\u3067\u65b0\u898f\u8ffd\u52a0\u3057\u307e\u3059\u3002",
        ("*", "mesh.smart_vert_slide"):
            "mesh.smart_vert_slide",
        ("*", "3) Remove or change the original binding to avoid conflicts."):
            "3) \u7af6\u5408\u3092\u907f\u3051\u308b\u305f\u3081\u3001\u5143\u306e\u5272\u308a\u5f53\u3066\u306f\u524a\u9664/\u5909\u66f4\u3057\u3066\u304f\u3060\u3055\u3044\u3002",
        ("*", "Instant delete without confirmation popups (Edit Mode)."):
            "\u78ba\u8a8d\u30dd\u30c3\u30d7\u30a2\u30c3\u30d7\u306a\u3057\u3067\u5373\u524a\u9664\u3057\u307e\u3059\uff08\u7de8\u96c6\u30e2\u30fc\u30c9\uff09\u3002",
        ("*", "Smart Context can choose the best delete action based on selection pattern."):
            "Smart Context \u306b\u3088\u308a\u3001\u9078\u629e\u30d1\u30bf\u30fc\u30f3\u304b\u3089\u6700\u9069\u306a\u524a\u9664\u52d5\u4f5c\u3092\u81ea\u52d5\u9078\u629e\u3067\u304d\u307e\u3059\u3002",
        ("*", "Supports dedicated overrides for Delete / Backspace and an optional Through variant."):
            'Delete / Backspace の専用の上書きと、任意の貫通版に対応します。',
        ("*", "Useful when doing repetitive cleanup and you want a faster delete workflow."):
            "\u7e70\u308a\u8fd4\u3057\u306e\u30af\u30ea\u30fc\u30f3\u30a2\u30c3\u30d7\u4f5c\u696d\u3092\u9ad8\u901f\u5316\u3057\u305f\u3044\u6642\u306b\u4fbf\u5229\u3067\u3059\u3002",
        ("*", "1) Register the desired Direct Delete operator ID manually in Preferences > Keymap, then press your assigned key in Edit Mode."):
            "1) \u7de8\u96c6\u30e2\u30fc\u30c9\u3067 Delete / Backspace \u3092\u62bc\u3059\u3068 Direct Delete \u304c\u5b9f\u884c\u3055\u308c\u307e\u3059\uff08\u30ad\u30fc\u30de\u30c3\u30d7\u6709\u52b9\u6642\uff09\u3002",
        ("*", "2) Adjust behavior in the Direct Delete panel: Smart Context, ignore hidden, action mode (Delete/Dissolve/etc.)."):
            '2) 直接削除のパネルで動きを調整します（賢い判定、隠れた物を無視、削除/溶解など）。',
        ("*", "3) Use the Through variant when you want the action to ignore typical limitations for your workflow."):
            "3) \u5fc5\u8981\u306b\u5fdc\u3058\u3066 Through \u7248\u3092\u4f7f\u3044\u3001\u30ef\u30fc\u30af\u30d5\u30ed\u30fc\u306b\u5408\u308f\u305b\u305f\u52d5\u4f5c\u306b\u3067\u304d\u307e\u3059\u3002",
        ("*", "Batch organization and cleanup suite for mesh objects."):
            "\u30e1\u30c3\u30b7\u30e5\u30aa\u30d6\u30b8\u30a7\u30af\u30c8\u5411\u3051\u306e\u4e00\u62ec\u6574\u7406\u30fb\u30af\u30ea\u30fc\u30f3\u30a2\u30c3\u30d7\u30b9\u30a4\u30fc\u30c8\u3067\u3059\u3002",
        ("*", "Includes presets, safe transform / cleanup steps, modifier keep, and backup/restore."):
            "\u30d7\u30ea\u30bb\u30c3\u30c8\u3001\u5b89\u5168\u306a\u5909\u63db/\u6383\u9664\u3001\u30e2\u30c7\u30a3\u30d5\u30a1\u30a4\u30a2\u4fdd\u6301\u3001\u30d0\u30c3\u30af\u30a2\u30c3\u30d7/\u5fa9\u5143\u3092\u542b\u307f\u307e\u3059\u3002",
        ("*", "Designed to standardize naming and scene hygiene while minimizing destructive changes."):
            "\u7834\u58ca\u7684\u5909\u66f4\u3092\u6291\u3048\u3064\u3064\u3001\u547d\u540d\u898f\u5247\u3068\u30b7\u30fc\u30f3\u306e\u6574\u7406\u3092\u6a19\u6e96\u5316\u3059\u308b\u8a2d\u8a08\u3067\u3059\u3002",
        ("*", "1) Select one or more mesh objects."):
            "1) 1\u3064\u4ee5\u4e0a\u306e\u30e1\u30c3\u30b7\u30e5\u30aa\u30d6\u30b8\u30a7\u30af\u30c8\u3092\u9078\u629e\u3057\u307e\u3059\u3002",
        ("*", "2) Open the Model Organizer panel and run Organize Selection."):
            '2) モデル整理のパネルで「選択を整理」を実行します。',
        ("*", "3) Choose a preset (or configure steps) and run; review the report if anything is skipped."):
            "3) \u30d7\u30ea\u30bb\u30c3\u30c8\uff08\u307e\u305f\u306f\u624b\u9806\uff09\u3092\u9078\u3093\u3067\u5b9f\u884c\u3057\u3001\u30b9\u30ad\u30c3\u30d7\u304c\u3042\u308c\u3070\u30ec\u30dd\u30fc\u30c8\u3092\u78ba\u8a8d\u3057\u307e\u3059\u3002",
        ("*", "Tip: Enable Backup/Restore if you want a safety net while testing new presets."):
            "Tip: \u65b0\u3057\u3044\u30d7\u30ea\u30bb\u30c3\u30c8\u3092\u8a66\u3059\u6642\u306f Backup/Restore \u3092\u6709\u52b9\u306b\u3059\u308b\u3068\u5b89\u5168\u3067\u3059\u3002",
        ("*", "Popup preset menu for aligning selected vertices."):
            "\u9078\u629e\u9802\u70b9\u3092\u6574\u5217\u3059\u308b\u305f\u3081\u306e\u30d7\u30ea\u30bb\u30c3\u30c8\u30dd\u30c3\u30d7\u30a2\u30c3\u30d7\u30e1\u30cb\u30e5\u30fc\u3067\u3059\u3002",
        ("*", "Includes Standard Align (axis/center), View/Grid align, Loop align, Annotation align, and Distribute Evenly."):
            '標準の整列（軸/中心）、ビュー/グリッド、ループ、アノテーション、等間隔の配分を含みます。',
        ("*", "Modifier keys: Alt uses slide-based alignment; Ctrl applies to all selected objects (when supported)."):
            "\u4fee\u98fe\u30ad\u30fc: Alt=\u30b9\u30e9\u30a4\u30c9\u57fa\u6e96\u6574\u5217\u3001Ctrl=\u9078\u629e\u4e2d\u306e\u5168\u30aa\u30d6\u30b8\u30a7\u30af\u30c8\u3078\u9069\u7528\uff08\u5bfe\u5fdc\u30b3\u30de\u30f3\u30c9\uff09\u3002",
        ("*", "1) In Edit Mode, select vertices (or edges/faces where supported)."):
            "1) \u7de8\u96c6\u30e2\u30fc\u30c9\u3067\u9802\u70b9\u3092\u9078\u629e\u3057\u307e\u3059\uff08\u5bfe\u5fdc\u6a5f\u80fd\u3067\u306f\u8fba/\u9762\u3082\u53ef\uff09\u3002",
        ("*", "2) Run Mesh Align to open the popup and choose a command."):
            "2) Mesh Align \u3092\u5b9f\u884c\u3057\u3066\u30dd\u30c3\u30d7\u30a2\u30c3\u30d7\u3092\u958b\u304d\u3001\u30b3\u30de\u30f3\u30c9\u3092\u9078\u3073\u307e\u3059\u3002",
        ("*", "3) Use Alt/Ctrl modifiers as described in each command tooltip for advanced behavior."):
            "3) \u8a73\u7d30\u52d5\u4f5c\u306f\u5404\u30b3\u30de\u30f3\u30c9\u306e\u30c4\u30fc\u30eb\u30c1\u30c3\u30d7\u306b\u5f93\u3044\u3001Alt/Ctrl \u3092\u4f7f\u3044\u5206\u3051\u307e\u3059\u3002",
        ("*", "Popup preset menu for applying and managing edge crease values."):
            "\u30a8\u30c3\u30b8\u306e\u30af\u30ea\u30fc\u30b9\u5024\u3092\u9069\u7528/\u7ba1\u7406\u3059\u308b\u30d7\u30ea\u30bb\u30c3\u30c8\u30dd\u30c3\u30d7\u30a2\u30c3\u30d7\u3067\u3059\u3002",
        ("*", "Includes quick apply (selected / linked / all) and preset management (save/load/export)."):
            "\u30af\u30a4\u30c3\u30af\u9069\u7528\uff08\u9078\u629e/\u30ea\u30f3\u30af/\u5168\u4f53\uff09\u3068\u3001\u30d7\u30ea\u30bb\u30c3\u30c8\u7ba1\u7406\uff08\u4fdd\u5b58/\u8aad\u8fbc/\u66f8\u51fa\uff09\u3092\u542b\u307f\u307e\u3059\u3002",
        ("*", "Designed to be assigned to a shortcut so you can crease while modeling without leaving the 3D View."):
            "\u30b7\u30e7\u30fc\u30c8\u30ab\u30c3\u30c8\u5272\u5f53\u3092\u524d\u63d0\u306b\u30013D\u30d3\u30e5\u30fc\u304b\u3089\u96e2\u308c\u305a\u306b\u30af\u30ea\u30fc\u30b9\u64cd\u4f5c\u3067\u304d\u307e\u3059\u3002",
        ("*", "1) In Edit Mode, select edges to crease."):
            "1) \u7de8\u96c6\u30e2\u30fc\u30c9\u3067\u30af\u30ea\u30fc\u30b9\u3057\u305f\u3044\u8fba\u3092\u9078\u629e\u3057\u307e\u3059\u3002",
        ("*", "2) Run the Open Crease Presets and choose a preset value or enter a custom value."):
            '2) クリースプリセットを開き、プリセットを選ぶか値を入力します。',
        ("*", "3) Use Apply Mode (Selected / Linked / All) and optional delimit settings (seam/sharp/material) to control spread."):
            '3) 適用の範囲（選択中/リンク/すべて）と区切り（シーム/シャープ/マテリアル）で広がりを調整します。',
        ("*", "One-button toggle for Auto Merge and Snap settings."):
            "Auto Merge \u3068 Snap \u3092\u30ef\u30f3\u30dc\u30bf\u30f3\u3067\u5207\u308a\u66ff\u3048\u307e\u3059\u3002",
        ("*", "Default: toggle both. Shift: Auto Merge only. Alt: Snap only. Ctrl: open quick popup."):
            '通常: 両方を切り替え / Shift: 自動マージのみ / Alt: スナップのみ / Ctrl: クイックポップアップ',
        ("*", "Also supports cycling through predefined states if you enable cycle mode in its N-panel settings."):
            'Nパネル設定でサイクルモードを有効にすると、定義済み状態を順番に切替できます。',
        ("*", "1) Invoke the operator to toggle states quickly while modeling."):
            "1) \u30aa\u30da\u30ec\u30fc\u30bf\u30fc\u3092\u5b9f\u884c\u3057\u3066\u3001\u30e2\u30c7\u30ea\u30f3\u30b0\u4e2d\u306b\u7d20\u65e9\u304f\u72b6\u614b\u3092\u5207\u66ff\u3048\u307e\u3059\u3002",
        ("*", "2) Use Shift/Alt for single-feature toggles, Ctrl for quick popup."):
            "2) Shift/Alt \u3067\u7247\u65b9\u3060\u3051\u5207\u66ff\u3001Ctrl \u3067\u30af\u30a4\u30c3\u30af\u30dd\u30c3\u30d7\u30a2\u30c3\u30d7\u3002",
        ("*", "3) If you use cycling, repeat the operator to rotate through saved states."):
            "3) \u30b5\u30a4\u30af\u30eb\u5229\u7528\u6642\u306f\u3001\u7e70\u308a\u8fd4\u3057\u5b9f\u884c\u3067\u4fdd\u5b58\u72b6\u614b\u3092\u9806\u756a\u306b\u5207\u66ff\u3048\u307e\u3059\u3002",
        ("*", "Add/apply a Weighted Normal modifier directly from Edit Mode."):
            '編集モードから直接、重み付き法線モディファイアーを追加/適用します。',
        ("*", "Supports presets, multi-object operation, and optional selection-limited baking."):
            "\u30d7\u30ea\u30bb\u30c3\u30c8\u3001\u8907\u6570\u30aa\u30d6\u30b8\u30a7\u30af\u30c8\u51e6\u7406\u3001\u9078\u629e\u9650\u5b9a\u30d9\u30a4\u30af\u306b\u5bfe\u5fdc\u3057\u307e\u3059\u3002",
        ("*", "Useful for hard-surface shading cleanup without leaving your modeling workflow."):
            "\u30e2\u30c7\u30ea\u30f3\u30b0\u4f5c\u696d\u3092\u6b62\u3081\u305a\u306b\u30cf\u30fc\u30c9\u30b5\u30fc\u30d5\u30a7\u30b9\u306e\u30b7\u30a7\u30fc\u30c7\u30a3\u30f3\u30b0\u3092\u6574\u3048\u3089\u308c\u307e\u3059\u3002",
        ("*", "1) Enter Edit Mode on a mesh object (or multiple objects in multi-edit)."):
            "1) \u30e1\u30c3\u30b7\u30e5\u3092\u7de8\u96c6\u30e2\u30fc\u30c9\u306b\u3057\u307e\u3059\uff08\u30de\u30eb\u30c1\u7de8\u96c6\u306a\u3089\u8907\u6570\u53ef\uff09\u3002",
        ("*", "2) Run Apply Weighted Normal and choose execution mode (Add & Apply or Add Only)."):
            '2) 重み付き法線を適用し、実行の形（追加して適用 / 追加のみ）を選びます。',
        ("*", "3) Choose a preset; optionally enable Limit To Selection to bake only selected vertices."):
            '3) プリセットを選びます。必要なら「選択に限定」で選択中の頂点のみベイクします。',
        ("*", "4) If custom normals already exist, choose how to proceed in the dialog."):
            "4) \u65e2\u5b58\u306e\u30ab\u30b9\u30bf\u30e0\u6cd5\u7dda\u304c\u3042\u308b\u5834\u5408\u306f\u3001\u30c0\u30a4\u30a2\u30ed\u30b0\u3067\u51e6\u7406\u65b9\u6cd5\u3092\u9078\u3073\u307e\u3059\u3002",
        ("*", "Direct Delete (Smart)"):
            '直接削除（スマート）',
        ("*", "Direct Delete (DEL)"):
            '直接削除（DEL）',
        ("*", "Direct Delete (Backspace)"):
            "Direct Delete\uff08Backspace\uff09",
        ("*", "Direct Delete (Through)"):
            '直接削除（貫通）',
        # Added (Preferences detail lines)
        ("*", "Exact is best when source and target have identical topology (same vertex order)."):
            "Exact はコピー元と貼り付け先が同一トポロジ（頂点順序も同じ）のときに最適です。",
        ("*", "Smart is designed for similar-but-not-identical meshes (common after retopo or edits)."):
            "Smart はトポロジが近いが完全一致しないメッシュ向けです（リトポ後や編集後など）。",
        ("*", "Mirror modes help transfer from one side to the other (check the Mirror Axis setting)."):
            "Mirror モードは左右転送に便利です（Mirror Axis の設定を確認してください）。",
        ("*", "Surface Project projects copied offsets onto the target surface when topology differs a lot."):
            "Surface Project は差が大きい場合に、コピー情報をターゲット表面へ投影します。",
        ("*", "Recommended setup: replace Blender's Vertex Slide hotkey so this tool becomes your default slide."):
            "推奨: Blender標準の Vertex Slide のショートカットを、このツールに差し替えて使います。",
        ("*", "This is a modal tool: start it, move the mouse to slide, then confirm/cancel."):
            "これはモーダルツールです。開始→マウス移動→確定/キャンセルの流れで操作します。",
        ("*", "Variants: Smart (context-based), DEL override, Backspace override, and Through (special-case)."):
            '種類: スマート（状況に応じて）、DEL の上書き、Backspace の上書き、貫通（特殊な用途）',
        ("*", "Assign only the variants you need to avoid conflicting with your existing delete workflow."):
            "既存の削除操作と衝突しないよう、必要な種類だけ割り当てるのがおすすめです。",
        ("*", "Key areas: Preset, Modifiers, Transforms, Clean Data, Rename/Collections, Preflight, Backup/Restore."):
            '主な項目: プリセット、モディファイアー、トランスフォーム、データ整理、名前変更/コレクション、事前確認、バックアップ/復元',
        ("*", "Clean Data can handle: remove crease/bevel weight, clear custom normals, recalc normals, merge by distance, delete loose, purge orphans."):
            'データ整理でできること: クリース/ベベルのウェイト除去、カスタム法線の消去、法線の再計算、距離でマージ、孤立の削除、未使用データの削除',
        ("*", "Use Preflight to detect issues like non-manifold geometry or negative scale before applying changes."):
            "Preflight で非多様体や負スケールなどを事前検出してから処理できます。",
        ("*", "Typical commands include: Align X/Y/Z, Align to Center, Distribute Evenly, Align to View/Grid, Align to Annotation."):
            "代表コマンド: X/Y/Z整列、中心合わせ、均等配置、ビュー/グリッド整列、アノテーション整列。",
        ("*", "Tip: When assigning a shortcut, prefer a chord that doesn't conflict with Blender's built-ins."):
            "Tip: ショートカットはBlender標準と衝突しにくい組み合わせにしてください。",
        ("*", "Crease values are 0.0 - 1.0 (0 = none, 1 = full). Great for Subdivision hard edges."):
            'クリースの値は 0.0 から 1.0（0 でなし、1 で最大）です。サブディビジョンの硬い辺に向きます。',
        ("*", "You can manage presets (save/load/export) to keep consistent crease standards across projects."):
            "プリセット（保存/読み込み/書き出し）で、プロジェクト間の統一基準を保てます。",
        ("*", "Use this when switching between free modeling and precise snapping frequently."):
            "フリーモデリングと精密スナップを頻繁に切り替える作業に便利です。",
        ("*", "Because it touches global tool settings, keep its shortcut distinct to avoid accidental toggles."):
            "グローバル設定を切り替えるため、誤操作しにくいキーに割り当てるのがおすすめです。",
        ("*", "If a Weighted Normal modifier already exists, the tool can reuse/update it depending on options."):
            "Weighted Normal が既にある場合、設定に応じて再利用/更新できます。",
        ("*", "When Limit To Selection is enabled, select vertices first; otherwise the operator will warn."):
            "「選択範囲のみ」を使う場合は先に頂点を選択してください。未選択だと警告します。",
        # N-Panel UI (per-tool tabs)
        ("*", "1) In Edit Mode, select vertices on the SOURCE mesh."): '1) 編集モードで元のメッシュの頂点を選択します。',
        ("*", "1) Select vertices/edges   2) Run Start   3) Drag mouse   4) Confirm"): '1) 頂点/辺を選択  2) 開始  3) マウスを動かす  4) 確定',
        ("*", "2) Click Copy to store positions in the Clipboard slot."): "2) Copy を押して、クリップボードスロットに位置情報を保存します。",
        ("*", "3) Select the TARGET mesh (or set Paste Target in Transfer Settings)."): '3) 先のメッシュを選択します（または転送の設定で貼り付け先を指定します）。',
        ("*", "4) Click Paste. Use Target validation if the paste fails."): "4) Paste を押します。失敗する場合は Target（検証）を使ってください。",
        ("*", "Add & Apply (Bake)"): "追加して適用（ベイク）",
        ("*", "Add Only (Non-Destructive)"): "追加のみ（非破壊）",
        ("*", "Align selected vertices/edges/faces in common directions without hunting menus."): "よく使う方向へ、選択した頂点/辺/面を素早く整列します（メニューを探す必要がありません）。",
        ("*", "Apply common crease weights quickly (0.0 to 1.0)."): 'よく使うクリース値（0.0〜1.0）をすばやく適用します。',
        ("*", "Assign a shortcut to \"mesh.toggle_merge_snap\" for fastest workflow."): "最速運用のために「mesh.toggle_merge_snap」にショートカットを割り当てるのがおすすめです。",
        ("*", "Auto Merge"): "自動マージ",
        ("*", "Auto Merge & Snap: {state}"): "自動マージ＆スナップ: {state}",
        ("*", "Auto Merge: {state}"): "自動マージ: {state}",
        ("*", "B : Baseline (Individual / Active)"): "B：基準（個別 / アクティブ）切替",
        ("*", "Override Backspace"): "Backspace 上書き",
        ("*", "Baseline"): "基準",
        ("*", "Baseline / Lock / Priority"): "基準 / ロック / 優先度",
        ("*", "Beginner steps"): "初心者手順",
        ("*", "Beginner workflow"): "初心者ワークフロー",
        ("*", "Behavior"): "挙動",
        ("*", "Best Fit Plane"): "最適平面",
        ("*", "Best practices"): "おすすめ運用",
        ("*", "C : Cycle behavior / target"): "C：挙動/ターゲットを切替",
        ("*", "Clean Data"): "データ整理",
        ("*", "Convert Geometry Nodes to Standard Mesh"): "ジオメトリノードを標準メッシュ化",
        ("*", "Apply every Geometry Nodes modifier on each processed mesh object and bake the node-generated result into ordinary editable mesh data. When a Curve object is selected, its bevel, extrusion, taper, fill, and resolution render geometry is also converted to an ordinary editable mesh. Geometry Nodes modifiers are removed after a successful conversion; other modifiers continue to follow the Modifiers setting."): "処理対象の各メッシュオブジェクトにあるジオメトリノードモディファイアを適用し、ノードで生成された結果を通常編集できる標準メッシュデータへ変換します。カーブオブジェクトを選択している場合は、ベベル、押し出し、テーパー、フィル、解像度などのレンダリング設定で生成される形状も、通常編集できる標準メッシュへ変換します。正常に変換できたジオメトリノードモディファイアは削除され、その他のモディファイアは「モディファイア」の設定に従います。",
        ("*", "Common workflow tips"): "よくある使い分け",
        ("*", "Confirm: LMB / Enter    Cancel: RMB / Esc"): "確定：左クリック / Enter    キャンセル：右クリック / Esc",
        ("*", "Control keys (during modal)"): "操作キー（モーダル中）",
        ("*", "Crease weights affect Subdivision behavior (sharpness) without adding support loops."): "クリース値は、サポートループを増やさずにサブディビジョンのシャープさを調整します。",
        ("*", "Cycle Snap"): 'スナップサイクル',
        ("*", "DEL Override"): 'DEL の上書き',
        ("*", "Delete History (Remove Modifiers)"): "履歴削除（モディファイア削除）",
        ("*", "Delete Objects (No Popup)"): "オブジェクトを削除（ポップアップ無し）",
        ("*", "Delete Through"): "貫通選択を削除",
        ("*", "Direct Delete removes geometry without opening Blender's delete popup."): "Direct Delete は、Blender標準の削除ポップアップを出さずにジオメトリを削除します。",
        ("*", "Distance"): "距離",
        ("*", "Example: bind it to a nearby key you can hit often while modeling."): "例：モデリング中によく押せる近いキーに割り当てます。",
        ("*", "Game Asset"): "ゲームアセット",
        ("*", "Guide / Tips"): 'ガイド / ヒント',
        ("*", "Hard Surface Modeling"): "ハードサーフェス",
        ("*", "How to use (basic)"): "使い方（基本）",
        ("*", "How to use (beginner)"): "使い方（初心者）",
        ("*", "Improve shading on hard-surface models by weighting normals."): "法線を重み付けして、ハードサーフェスのシェーディングを改善します。",
        ("*", "It can apply transforms, clean data, and optionally rename/move to collections."): "トランスフォーム適用、データ整理、必要に応じてリネームやコレクション移動も行えます。",
        ("*", "It helps you keep surface flow while adjusting shapes quickly and precisely."): "形状の流れ（エッジフロー）を保ちながら、素早く正確に形を整えられます。",
        ("*", "It is useful for retopo fixes, mirrored parts, and transferring edits between similar meshes."): "リトポ修正、左右対称パーツ、似たメッシュ間での編集転送に便利です。",
        ("*", "It picks a safe action automatically (delete / dissolve) depending on your selection."): "選択内容に応じて、削除/溶解など最適な処理を自動で選びます。",
        ("*", "L : Loop priority   R : Ring priority"): "L：ループ優先   R：リング優先",
        ("*", "L toggles Loop priority. R toggles Ring priority. B toggles baseline (Individual/Active)."): 'Lでループ優先、Rでリング優先、Bで基準（個別/アクティブ）を切替。',
        ("*", "Lock"): "ロック",
        ("*", "Loop"): "ループ",
        ("*", "Mesh Align provides fast alignment tools for modeling and retopo."): "メッシュ整列は、モデリング/リトポ向けの高速整列ツールです。",
        ("*", "Minimal"): "最小",
        ("*", "Mode"): "モード",
        ("*", "Modifiers"): "モディファイア",
        ("*", "Mouse Wheel : Change proportional radius"): "マウスホイール：プロポーショナル半径を変更",
        ("*", "Object Mode"): "オブジェクトモード",
        ("*", "Open Crease Preset"): "クリースプリセットを開く",
        ("*", "Open Mesh Align"): "メッシュ整列を開く",
        ("*", "Open the panels below for detailed settings and a beginner guide."): "詳しい設定や初心者向けガイドは下のパネルを開いてください。",
        ("*", "Open the sections below for detailed options."): "詳しい設定は下のセクションを開いてください。",
        ("*", "Open: Edit > Preferences > Keymap > (search) \"transform.vert_slide\""): '開く: 編集 > プリファレンス > キーマップ >（検索）"transform.vert_slide"',
        ("*", "Organize Selection"): '選択を整理',
        ("*", "Origin / Pivot"): "原点 / ピボット",
        ("*", "Per-Element Action"): '要素別アクション',
        ("*", "Post Process"): "後処理",
        ("*", "Preset"): "プリセット",
        ("*", "Presets"): "プリセット",
        ("*", "Press C to cycle behavior. Shift+C toggles proportional effect."): "Cで挙動を切替。Shift+CでプロポーショナルをON/OFF。",
        ("*", "Quick Align"): "クイック整列",
        ("*", "Quick Apply (Selected)"): "クイック適用（選択）",
        ("*", "Quick Delete"): "クイック削除",
        ("*", "Quick Popup"): "クイックポップアップ",
        ("*", "Quick Snap Settings"): "クイックスナップ設定",
        ("*", "Quick Start"): "クイックスタート",
        ("*", "Rename / Collections"): "リネーム / コレクション",
        ("*", "Replace Blender's default Vertex Slide (recommended)"): "Blender標準の Vertex Slide を置き換える（推奨）",
        ("*", "Restore Backup"): "バックアップを復元",
        ("*", "Restored previous settings."): '元の設定を復元しました。',
        ("*", "Ring"): "リング",
        ("*", "Settings not found."): "設定が見つかりません。",
        ("*", "Shift : Slow move   Ctrl : Snap   Alt : Invert"): "Shift：低速   Ctrl：スナップ   Alt：反転",
        ("*", "Shift = slow, Ctrl = snap, Alt = invert, Wheel = radius, Type numbers = ratio."): 'Shift=スロー、Ctrl=スナップ、Alt=反転、ホイール=半径、数値入力=比率。',
        ("*", "Shift+C : Toggle proportional effect"): "Shift+C：プロポーショナルをON/OFF",
        ("*", "Smart = chooses the safest delete/dissolve for the current selection."): "自動判断：現在の選択に対して、最も安全な削除/溶解を選びます。",
        ("*", "Vertex Copy copies vertex positions from a source mesh and pastes them to a target mesh."): "頂点コピーは、元メッシュの頂点位置をコピーして別メッシュへ貼り付けます。",
        ("*", "Vertex Slide is a modal vertex/edge slide tool with extra control keys."): "頂点スライドは、追加キー操作を備えたモーダル方式の頂点/辺スライドツールです。",
        ("*", "Snap"): "スナップ",
        ("*", "Snap Elements: {elements}"): "スナップ要素: {elements}",
        ("*", "Snap: {state}"): "スナップ: {state}",
        ("*", "Start Vertex Slide (Modal)"): "頂点スライドを開始（モーダル）",
        ("*", "Status"): "状態",
        ("*", "Then change the Operator to: \"mesh.smart_vert_slide\" (Vertex Slide)."): '次にコマンドを "mesh.smart_vert_slide"（頂点スライド）へ変更します。',
        ("*", "This is useful when you switch between precise snapping and free editing."): "精密なスナップ作業と自由な編集を切り替えるときに便利です。",
        ("*", "This tool is designed to be used instead of Blender's default Vertex Slide."): "本ツールはBlender標準の Vertex Slide の代わりに使う設計です。",
        ("*", "This tool standardizes and cleans selected objects for modeling/export."): "選択したオブジェクトを、モデリング/書き出し向けに標準化・整理します。",
        ("*", "Through"): "貫通",
        ("*", "Tip: Increase radius for small details, decrease for precision."): "ヒント：細部は半径を上げる／精密に狙うなら半径を下げると扱いやすいです。",
        ("*", "Tip: Open \"Guide / Tips\" below for full controls and setup."): "ヒント：詳細な操作説明は下の「ガイド / Tips」を開いてください。",
        ("*", "Tip: Use multiple clipboard slots (1-8) to store variations."): "ヒント：スロット（1〜8）を使い分けて複数パターンを保存できます。",
        ("*", "Tip: add a shortcut"): "ヒント：ショートカットを追加",
        ("*", "Tips"): "ヒント",
        ("*", "To View"): "ビュー方向へ",
        ("*", "Toggle Auto Merge Only"): "自動マージのみ切替",
        ("*", "Toggle Auto Merge and Snap quickly while modeling."): "モデリング中に「自動マージ」と「スナップ」を素早く切り替えます。",
        ("*", "Toggle Both"): "両方切替",
        ("*", "Toggle Snap Only"): "スナップのみ切替",
        ("*", "Topology Aware"): "トポロジー考慮",
        ("*", "Transforms"): "トランスフォーム",
        ("*", "Type numbers : Set ratio directly (e.g. 0.5)"): "数値入力：比率を直接指定（例：0.5）",
        ("*", "Use \"Through\" to delete elements behind the cursor (useful for dense meshes)."): "「貫通」を使うと、カーソル下の奥にある要素も削除できます（密集メッシュに便利）。",
        ("*", "Use X/Y/Z for quick axis alignment. Use the Master panel for advanced modes."): "X/Y/Zで軸整列、Masterパネルで高度なモードを使えます。",
        ("*", "Use it for hard-surface edges when you want quick, non-destructive sharpness."): "素早く非破壊でエッジを立てたいハードサーフェスに向いています。",
        ("*", "View / Utility"): "ビュー / ユーティリティ",
        ("*", "What is Crease?"): 'クリースとは？',
        ("*", "What this tool does"): "このツールでできること",
        ("*", "What this tool is"): "このツールについて",
        ("*", "When to use"): "使いどころ",
        ("*", "Workflow"): 'ワークフロー',
        ("*", "You can keep the same shortcut (e.g. Shift+V) and just swap the operator."): "ショートカット（例：Shift+V）はそのままに、オペレーターだけ差し替えできます。",
        ("*", "• After bevel/subdivision to get clean highlights."): "• ベベル/サブディビジョン後に綺麗なハイライトが欲しいとき",
        ("*", "• After running, you can adjust settings in the modifier (if Add Only)."): "• 実行後、（追加のみの場合）モディファイアで設定を調整できます。",
        ("*", "• Auto Relax can smooth the area after deletion (increase iterations for stronger relax)."): "• Auto Relax は削除後に周辺を滑らかにします（Iterations を上げるほど強くかかります）。",
        ("*", "• Choose a Preset first."): "• まずプリセットを選びます。",
        ("*", "• Click \"Direct Delete (Smart)\" for the recommended action."): "• 推奨の処理は「Direct Delete（自動判断）」を押します。",
        ("*", "• Click Organize Selection. A backup is created automatically."): "• 「選択を整理（実行）」を押すと自動でバックアップが作成されます。",
        ("*", "• Click X/Y/Z to align along that axis (in object space)."): "• X/Y/Zを押すと、その軸方向へ整列します（オブジェクト空間）。",
        ("*", "• Click a value (0.0/0.25/0.5/1.0)."): "• 値（0.0/0.25/0.5/1.0）をクリックします。",
        ("*", "• For complex cases, click Open Mesh Align and choose a mode."): "• 複雑なケースでは「メッシュ整列を開く」からモードを選びます。",
        ("*", "• If pasting to multiple objects, use Collection/Selected target modes."): '• 複数のオブジェクトへ貼る時は、貼り付け先をコレクションか選択中にします。',
        ("*", "• If results are unexpected, click Restore Backup."): "• 想定外の結果になったら「バックアップを復元」を押します。",
        ("*", "• If you want to override keys, bind your Delete / Backspace to the provided operators."): "• Delete/Backspace を置き換えたい場合は、用意されたオペレーターにキーマップを割り当てます。",
        ("*", "• In Edit Mode, select vertices/edges/faces."): "• 編集モードで頂点/辺/面を選択します。",
        ("*", "• Select edges in Edit Mode."): "• 編集モードで辺を選択します。",
        ("*", "• Start with meshes that share similar topology/order for best results."): "• できるだけトポロジー/頂点順が近いメッシュほど成功率が上がります。",
        ("*", "• Topology Aware helps when deleting creates holes; it can try a clean fill."): "• 削除で穴が空きやすい時は「トポロジー考慮」で綺麗な穴埋めを試せます。",
        ("*", "• Try Hard Surface Modeling preset first."): "• まずは「ハードサーフェス」プリセットを試します。",
        ("*", "• Use \"Through\" when you want to delete hidden elements under the cursor."): "• カーソル下の隠れた要素も削除したい時は「貫通」を使います。",
        ("*", "• Use Add Only if you want to keep it non-destructive."): "• 非破壊で残したい場合は「追加のみ（非破壊）」を使います。",
        ("*", "• Use Clean Data when models come from many sources and contain messy data."): "• さまざまなソース由来でデータが荒れているモデルには「データ整理」が有効です。",
        ("*", "• Use Open Crease Preset for presets and import/export."): "• プリセットやインポート/エクスポートは「クリースプリセットを開く」から行います。",
        ("*", "• Use Rename / Collections to keep Outliner tidy for large projects."): "• 大規模案件では「リネーム / コレクション」でアウトライナを整理すると管理が楽になります。",
        ("*", "• Use the report to understand skipped vertices and mismatches."): "• レポートを確認すると、スキップや不一致の理由が分かります。",
        ("*", "• When shading looks wavy/dirty on hard-surface meshes."): "• ハードサーフェスでハイライトが波打つ/汚れるとき",

    }
}
# ------------------------------------------------------------
# Submodules
# ------------------------------------------------------------
from .vertex_slide.preferences import SmartVertSlidePreferences
from .direct_delete.settings import DIRECTDELETE_AddonPreferences
from .model_organized.preferences import MO2_AddonPreferences
from .preference_types import (
    SMS_AWN_AddonPreferencesProxy,
    SMS_CreasePresetItemProxy,
    SMS_CreasePresetPreferencesProxy,
    SMS_MSAP_AddonPreferencesProxy,
    SMS_TAMS_CycleItemProxy,
    SMS_TAMS_PrefsProxy,
)


_SMS_MANAGER_TOOL_KEY = 'SMART_MODELING'
_SMS_MANAGER_MODULE_KEYS = (
    'bl_ext.user_default.smart_tools_manager',
    'bl_ext.user_default.smart_tools_manager.manager',
    'bl_ext.user_default.smart_tools_manager.api',
    'smart_tools_manager',
    'smart_tools_manager.manager',
    'smart_tools_manager.api',
)
_SMS_ROOT_NPANEL_IDS = frozenset((
    'VIEW3D_PT_sms_hub',
    'IMAGE_PT_sms_hub',
    'NODE_PT_sms_hub',
    'SEQUENCER_PT_sms_hub',
    'CLIP_PT_sms_hub',
    'DOPESHEET_PT_sms_hub',
    'GRAPH_PT_sms_hub',
    'NLA_PT_sms_hub',
    'TEXT_PT_sms_hub',
    'FILEBROWSER_PT_sms_hub',
    'ASSETBROWSER_PT_sms_hub',
    'SPREADSHEET_PT_sms_hub',
))
_SMS_PHYSICAL_ROOT_SPECS = (
    ('VIEW3D_PT_sms_hub', 'VIEW_3D'),
    ('IMAGE_PT_sms_hub', 'IMAGE_EDITOR'),
    ('NODE_PT_sms_hub', 'NODE_EDITOR'),
    ('SEQUENCER_PT_sms_hub', 'SEQUENCE_EDITOR'),
    ('CLIP_PT_sms_hub', 'CLIP_EDITOR'),
    ('DOPESHEET_PT_sms_hub', 'DOPESHEET_EDITOR'),
    ('GRAPH_PT_sms_hub', 'GRAPH_EDITOR'),
    ('NLA_PT_sms_hub', 'NLA_EDITOR'),
    ('TEXT_PT_sms_hub', 'TEXT_EDITOR'),
    ('FILEBROWSER_PT_sms_hub', 'FILE_BROWSER'),
    ('ASSETBROWSER_PT_sms_hub', 'FILE_BROWSER'),
    ('SPREADSHEET_PT_sms_hub', 'SPREADSHEET'),
)
_SMS_DIRECT_LOGICAL_EDITOR_KEYS = {
    'VIEW_3D': 'VIEW_3D',
    'SEQUENCE_EDITOR': 'VIDEO_SEQUENCER',
    'CLIP_EDITOR': 'MOVIE_CLIP_EDITOR',
    'DOPESHEET_EDITOR': 'DOPE_SHEET',
    'NLA_EDITOR': 'NLA_EDITOR',
    'TEXT_EDITOR': 'TEXT_EDITOR',
    'SPREADSHEET': 'SPREADSHEET',
}

_SMS_NPANEL_ALLOWED_AREA_TYPES = frozenset((
    'VIEW_3D',
    'IMAGE_EDITOR',
    'NODE_EDITOR',
    'SEQUENCE_EDITOR',
    'CLIP_EDITOR',
    'DOPESHEET_EDITOR',
    'GRAPH_EDITOR',
    'NLA_EDITOR',
    'TEXT_EDITOR',
    'FILE_BROWSER',
    'SPREADSHEET',
))

# Viewport responsiveness guard.  N-panel updates may be requested from property
# updates, tool loading, and compatibility cleanup.  Tagging every possible editor
# on every small change competes directly with 3D View navigation redraws, so these
# requests are coalesced.  Explicit operator actions can still force an immediate
# redraw.
_SMS_REDRAW_THROTTLE_SECONDS = 0.085
_SMS_ALL_AREA_REDRAW_THROTTLE_SECONDS = 0.16
_SMS_SETTINGS_AUTOSAVE_INTERVAL = 8.0
_SMS_LAST_VIEW_REDRAW_TAG = 0.0
_SMS_LAST_ALL_AREA_REDRAW_TAG = 0.0


def _sms_area_type_can_host_npanel(area_type) -> bool:
    try:
        return str(area_type or '').strip().upper() in _SMS_NPANEL_ALLOWED_AREA_TYPES
    except Exception:
        return False


def _sms_panel_identifier_set(cls) -> set:
    identifiers = set()
    if cls is None:
        return identifiers
    for attr in ('__name__', 'bl_idname'):
        try:
            value = str(getattr(cls, attr, '') or '').strip()
        except Exception:
            value = ''
        if value:
            identifiers.add(value)
    return identifiers


def _sms_is_root_smart_modeling_panel_class(cls) -> bool:
    try:
        return any(value in _SMS_ROOT_NPANEL_IDS for value in _sms_panel_identifier_set(cls))
    except Exception:
        return False


def _sms_panel_is_visible_root(cls) -> bool:
    """Return True only for one of the eleven public Smart Modeling roots."""
    return _sms_is_root_smart_modeling_panel_class(cls)


def _sms_should_skip_panel_registration(cls) -> bool:
    """Block bundled standalone N-panel classes before RNA registration.

    Blender stores several Panel callbacks at registration time.  Merely forcing
    poll() to False after registration can leave old panels visible after
    in-place extension updates.  The suite therefore registers only the eleven
    native physical-space root panels.  Native tool panel classes remain ordinary
    Python classes and their draw() functions are hosted from inside the root
    panel's compact 設定 area.
    """
    if cls is None or not isinstance(cls, type):
        return False
    try:
        if not issubclass(cls, bpy.types.Panel):
            return False
    except Exception:
        return False
    if _sms_panel_is_visible_root(cls):
        # Native root classes declare their exact physical space. Registration
        # must preserve that declaration; shared physical spaces classify the
        # exact logical editor inside the root poll.
        return False
    try:
        region_type = str(getattr(cls, 'bl_region_type', '') or '')
        space_type = str(getattr(cls, 'bl_space_type', '') or '')
        category = str(getattr(cls, 'bl_category', '') or '')
        module_name = str(getattr(cls, '__module__', '') or '')
    except Exception:
        return False
    if region_type != 'UI':
        return False
    # Suppress every bundled UI panel and every stale Smart Modeling panel that
    # is not the root.  This includes panels in VIEW_3D, IMAGE_EDITOR/UV, node
    # editors, and old manager-generated copies.
    if 'smart_modeling_suite' in module_name:
        return True
    if category == 'Smart Modeling' and space_type:
        return True
    return False


def _sms_suppress_sidebar_panel_class(cls) -> bool:
    """Mark a bundled panel as hidden when it must be kept as a class object."""
    if not _sms_exact_class_belongs_to_current_package(cls):
        return False
    if not _sms_should_skip_panel_registration(cls):
        return False
    try:
        raw_poll = cls.__dict__.get('poll', None)
    except Exception:
        raw_poll = None
    try:
        if raw_poll is not None and not getattr(cls, '_sms_original_poll_before_npanel_suppression', None):
            setattr(cls, '_sms_original_poll_before_npanel_suppression', raw_poll)
    except Exception:
        pass
    try:
        cls.poll = classmethod(lambda _cls, _context: False)
        setattr(cls, '_sms_hidden_from_top_level_npanel', True)
        setattr(cls, '_sms_skip_sidebar_registration', True)
        return True
    except Exception:
        return False


def _sms_disable_panel_draw_header_before_register(cls):
    """Remove package Panel.draw_header callbacks before class registration.

    Blender 5.1 crash logs showed a native access violation in panel_draw_header
    while toggling Smart Modeling UI state. Header callbacks are not required
    for tool execution, and several bundled tools access scene/object RNA from
    headers. Removing them before RNA registration prevents header-time access
    to stale or temporarily invalid data during mode changes, scene loads, and
    add-on refreshes.

    Non-root bundled VIEW_3D/UI panels are also hidden from the top-level
    sidebar so the only visible N-panel entry from this package is the unified
    Smart Modeling root panel.
    """
    if not _sms_exact_class_belongs_to_current_package(cls):
        return cls
    if not isinstance(cls, type):
        return cls
    try:
        if not issubclass(cls, bpy.types.Panel):
            return cls
    except Exception:
        return cls
    try:
        if _sms_should_skip_panel_registration(cls):
            _sms_suppress_sidebar_panel_class(cls)
        elif _sms_is_root_smart_modeling_panel_class(cls):
            # Keep the exact physical-space declaration made by each native root.
            pass
    except Exception:
        pass
    try:
        original = cls.__dict__.get('draw_header', None)
    except Exception:
        original = None
    if original is None:
        return cls
    try:
        setattr(cls, '_sms_original_draw_header_disabled', original)
    except Exception:
        pass
    try:
        delattr(cls, 'draw_header')
    except Exception:
        def _sms_noop_draw_header(self, context):
            return None
        try:
            cls.draw_header = _sms_noop_draw_header
        except Exception:
            pass
    return cls


def _sms_force_operator_undo_class(cls) -> None:
    try:
        op_base = getattr(bpy.types, 'Operator', None)
        if op_base is None or not isinstance(cls, type) or not issubclass(cls, op_base):
            return
        opts = set(getattr(cls, 'bl_options', set()) or set())
        # Pure dispatcher/lazy-proxy operators do not mutate Blender data. Giving
        # those wrappers UNDO makes Blender create an operator-history entry while
        # a different child operator owns the actual modal dialog/transaction.
        # On Blender 5.1.x this can leave two owners for one invocation and is a
        # reproducible native crash path when the child dialog finishes.
        if bool(getattr(cls, '_sms_no_undo', False)):
            if bool(getattr(cls, '_sms_requires_register', False)):
                opts.add('REGISTER')
            else:
                opts.discard('REGISTER')
            opts.discard('UNDO')
            opts.discard('UNDO_GROUPED')
            cls.bl_options = opts
            return
        # Undo support is required for operators that directly mutate data, but
        # REGISTER forces Blender to store last-properties. On Blender 5.1.x
        # Windows that storage path can crash for stale or compatibility
        # operators, so never add REGISTER here.
        if bool(getattr(cls, '_sms_requires_register', False)):
            opts.add('REGISTER')
        else:
            opts.discard('REGISTER')
        opts.add('UNDO')
        cls.bl_options = opts
    except Exception:
        pass




def _safe_register_class(cls):
    try:
        _sms_force_operator_undo_class(cls)
    except Exception:
        pass
    try:
        _status_runtime.instrument_operator_class(cls, 'smart_modeling_suite', 'Smart Modeling Suite')
    except Exception:
        pass
    try:
        _language.sanitize_class_ui(cls)
    except Exception:
        pass
    _sms_disable_panel_draw_header_before_register(cls)
    try:
        _sms_harden_panel_class_before_register(cls)
    except Exception:
        pass
    try:
        if _sms_should_skip_panel_registration(cls):
            _sms_suppress_sidebar_panel_class(cls)
            return False
    except Exception:
        pass
    return bool(_sms_exact_safe_register_class(cls))




def _sms_call_with_panel_unregister_guard(fn):
    """Run a native tool's unregister path against the live RNA classes.

    Lazy keymap operators are registered first and later patched in place with
    the real implementation.  Bundled tools still hold their original Python
    class objects, so calling ``unregister_class(original)`` can raise
    ``missing bl_rna`` even though a class with the same ``bl_idname`` is live.
    Resolve and unregister that live class instead.  Hosted sidebar panels are
    hidden rather than removed while Blender may still hold panel pointers.
    """
    if not callable(fn):
        return None
    original_unregister = getattr(bpy.utils, 'unregister_class', None)
    if not callable(original_unregister):
        return fn()

    def _safe_native_unregister(cls):
        try:
            existing = _sms_registered_rna_class(cls)
        except Exception:
            existing = None
        target = existing if isinstance(existing, type) else cls

        # Never unregister a lazy shell or a class whose public operator ID is
        # currently being preserved/delegated. Blender retains the live
        # wmOperator RNA owner until invoke/execute returns; removing it here
        # invalidates self and consumes the first shortcut event.
        try:
            candidate_idnames = {
                str(getattr(candidate, 'bl_idname', '') or '').strip()
                for candidate in (target, cls)
                if isinstance(candidate, type)
            }
            if _sms_is_lazy_proxy_class(target) or _sms_is_lazy_proxy_class(cls):
                return None
            if any(
                idname in _SMS_LAZY_KEYMAP_PRESERVE_IDNAMES
                or idname in _SMS_LAZY_KEYMAP_DELEGATING
                for idname in candidate_idnames
                if idname
            ):
                return None
        except Exception:
            pass

        try:
            if _sms_panel_class_is_panel(target) or _sms_panel_class_is_panel(cls):
                _sms_disable_resident_panel_class(target if isinstance(target, type) else cls)
                return None
        except Exception:
            pass
        try:
            if _sms_shared_pref_class_registered(cls):
                return None
        except Exception:
            pass
        if not isinstance(existing, type):
            # The class is already absent.  Native unregister functions commonly
            # run defensively; absence is a successful no-op, not an error.
            return None
        try:
            return original_unregister(existing)
        except Exception:
            return None

    try:
        bpy.utils.unregister_class = _safe_native_unregister
    except Exception:
        return fn()
    try:
        return fn()
    finally:
        try:
            bpy.utils.unregister_class = original_unregister
        except Exception:
            pass


def _sms_store_and_hide_panel_for_unregister(cls) -> None:
    if not _sms_class_is_owned_for_mutation(cls):
        return
    if not _sms_panel_class_is_panel(cls):
        return
    try:
        if not getattr(cls, '_sms_unregister_hidden_methods_saved', False):
            for attr in ('poll', 'draw', 'draw_header', 'draw_header_preset'):
                try:
                    if attr in getattr(cls, '__dict__', {}):
                        setattr(cls, f'_sms_original_before_unregister_{attr}', getattr(cls, attr))
                except Exception:
                    pass
            setattr(cls, '_sms_unregister_hidden_methods_saved', True)
    except Exception:
        pass
    try:
        cls.poll = classmethod(lambda _cls, _context: False)
    except Exception:
        pass
    def _sms_empty_unregister_panel_draw(self, context):
        return None
    try:
        cls.draw = _sms_empty_unregister_panel_draw
        cls.draw_header = _sms_empty_unregister_panel_draw
        setattr(cls, '_sms_hidden_by_suite_unregister', True)
    except Exception:
        pass


def _sms_restore_panel_after_safe_unregister(cls) -> None:
    if not _sms_class_is_owned_for_mutation(cls):
        return
    if not _sms_panel_class_is_panel(cls):
        return
    try:
        if not getattr(cls, '_sms_unregister_hidden_methods_saved', False):
            return
    except Exception:
        return
    for attr in ('poll', 'draw', 'draw_header', 'draw_header_preset'):
        try:
            sentinel = f'_sms_original_before_unregister_{attr}'
            if hasattr(cls, sentinel):
                setattr(cls, attr, getattr(cls, sentinel))
                try:
                    delattr(cls, sentinel)
                except Exception:
                    pass
        except Exception:
            pass
    try:
        delattr(cls, '_sms_unregister_hidden_methods_saved')
    except Exception:
        pass
    try:
        if hasattr(cls, '_sms_hidden_by_suite_unregister'):
            delattr(cls, '_sms_hidden_by_suite_unregister')
    except Exception:
        pass


def _safe_unregister_class(cls):
    _sms_exact_safe_unregister_class(cls)


def _addon_keyconfig():
    try:
        wm = getattr(bpy.context, "window_manager", None)
        keyconfigs = getattr(wm, "keyconfigs", None) if wm else None
        return getattr(keyconfigs, "addon", None) if keyconfigs else None
    except Exception:
        return None


def _sms_prune_empty_addon_keymaps() -> int:
    kc = _addon_keyconfig()
    if kc is None:
        return 0
    removed = 0
    for km in list(getattr(kc, 'keymaps', ())):
        try:
            keymap_items = list(getattr(km, 'keymap_items', ()))
        except Exception:
            keymap_items = []
        if keymap_items:
            continue
        try:
            kc.keymaps.remove(km)
            removed += 1
        except Exception:
            pass
    return removed


def _sms_import_relative_module(module_path: str):
    module_path = str(module_path or '').strip().lstrip('.')
    if not module_path:
        return None
    module = _SMS_NATIVE_MODULE_CACHE.get(module_path)
    if module is not None:
        return module
    try:
        module = importlib.import_module(f'.{module_path}', __package__)
    except Exception:
        return None
    _SMS_NATIVE_MODULE_CACHE[module_path] = module
    return module


def _sms_standard_n_panel_module():
    return None


def _sms_tag_redraw_view3d_areas(*, force: bool = False, all_supported_editors: bool = False) -> None:
    global _SMS_LAST_VIEW_REDRAW_TAG
    try:
        if _sms_rna_access_is_unsafe():
            return
    except Exception:
        return
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        unsafe_until = float((ns or {}).get('SMART_MODELING_SUITE_RNA_UNSAFE_UNTIL', 0.0) or 0.0) if isinstance(ns, dict) else 0.0
        if unsafe_until and time.monotonic() < unsafe_until:
            return
    except Exception:
        return
    try:
        now = time.monotonic()
    except Exception:
        now = 0.0
    if not force and now and (now - _SMS_LAST_VIEW_REDRAW_TAG) < _SMS_REDRAW_THROTTLE_SECONDS:
        return
    _SMS_LAST_VIEW_REDRAW_TAG = now
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    except Exception:
        wm = None
    target_types = _SMS_NPANEL_ALLOWED_AREA_TYPES if all_supported_editors else {'VIEW_3D'}
    for window in getattr(wm, 'windows', ()) if wm is not None else ():
        screen = getattr(window, 'screen', None)
        for area in getattr(screen, 'areas', ()) if screen is not None else ():
            try:
                if str(getattr(area, 'type', '') or '').upper() in target_types:
                    area.tag_redraw()
            except Exception:
                pass



_SMS_USERPREF_SAVE_PENDING = False
_SMS_PANEL_SETTINGS_CACHE = None
_SMS_PANEL_SETTINGS_DIRTY = False
_SMS_PANEL_SETTINGS_SAVE_PENDING = False
_SMS_PANEL_SETTINGS_VERSION = 1
_SMS_NPANEL_SETTINGS_PROP = "smart_modeling_suite_npanel_settings"
_SMS_SUITE_TOGGLE_UPDATE_DEPTH = 0
_SMS_PERSISTENT_TOGGLE_SYNC_DEPTH = 0
_SMS_PERSISTENT_RUNTIME_SYNC_DEPTH = 0
_SMS_RESTORE_KNOWN_PANEL_SETTINGS_DEPTH = 0
_SMS_NATIVE_PANEL_RESTORE_DEPTH = 0
_SMS_NPANEL_STATE_SAVE_CACHE = None


def _sms_toggle_update_active() -> bool:
    try:
        return bool(_SMS_SUITE_TOGGLE_UPDATE_DEPTH > 0 or _SMS_PERSISTENT_TOGGLE_SYNC_DEPTH > 0)
    except Exception:
        return False


def _sms_runtime_sync_active() -> bool:
    try:
        return bool(_SMS_PERSISTENT_RUNTIME_SYNC_DEPTH > 0)
    except Exception:
        return False


_SMS_DYNAMIC_POINTER_PROPERTY_NAMES = {
    # WindowManager / Scene runtime pointer groups.
    "vscp_settings",
    "direct_delete_settings",
    "mo2_props",
    "align_slide_props",
    "smsk_props",
    "qsd_retopo_target",
    "tams_state",
    # Suite preference pointer groups.  During toggle/update/lazy-load paths,
    # Blender 5.1 can crash inside RNA_property_pointer_get when these are
    # resolved while the owning PropertyGroup is being restored or reloaded.
    # Treat them as deferred pointer properties even if static annotation lookup
    # fails after an Extension reinstall.
    "vertex_slide",
    "direct_delete",
    "model_organized",
    "mesh_align_preset",
    "crease_preset",
    "toggle_auto_merge_snap",
    "apply_weighted_normal",
}


def _sms_rna_pointer_get_is_deferred() -> bool:
    try:
        return bool(
            _sms_toggle_update_active()
            or _sms_runtime_sync_active()
            or int(globals().get('_SMS_RESTORE_KNOWN_PANEL_SETTINGS_DEPTH', 0) or 0) > 0
            or bool(globals().get('_SMS_ON_DEMAND_LOAD_ACTIVE', False))
        )
    except Exception:
        return True


def _sms_rna_prop_kind_for_safe_access(data, prop_name: str) -> str:
    prop_name = str(prop_name or '').strip()
    if not prop_name:
        return ''
    try:
        if prop_name in globals().get('_SMS_DYNAMIC_POINTER_PROPERTY_NAMES', set()):
            return 'PointerProperty'
    except Exception:
        pass
    try:
        prop_def = _sms_static_property_def(data, prop_name)
        kind = _sms_prop_deferred_kind(prop_def)
        if kind:
            return kind
    except Exception:
        pass
    return ''


def _sms_persistent_toggle_prop_names() -> set[str]:
    names: set[str] = set()
    try:
        for spec in tuple(globals().get('_SMS_ALWAYS_ON_TOOL_SPECS', ())):
            if not _sms_spec_has_persistent_load(spec):
                continue
            prop_name = str((spec or {}).get('enable_prop') or '').strip()
            if prop_name:
                names.add(prop_name)
    except Exception:
        pass
    try:
        for meta in _sms_tool_meta_entries():
            tool_id = str((meta or {}).get('tool_id') or '').strip()
            if not _sms_native_tool_has_persistent_load(tool_id):
                continue
            prop_name = str((meta or {}).get('toggle') or '').strip()
            if prop_name:
                names.add(prop_name)
    except Exception:
        pass
    try:
        for alias in tuple(globals().get('_SMS_PERSISTENT_INTEGRATED_ALIASES', ())):
            prop_name = _sms_integrated_enable_prop(str(alias or '').strip())
            if prop_name:
                names.add(prop_name)
    except Exception:
        pass
    return names


def _sms_rna_data_is_current(data) -> bool:
    """Return True only when a bpy_struct instance belongs to the current RNA class.

    Accessing data.bl_rna or hasattr(data, prop) on a stale PropertyGroup/Panel
    proxy can crash Blender 5.1 at the C/RNA layer. This check uses only the
    Python type object and bpy.types registration table so callers can refuse to
    draw or serialize stale RNA objects before touching their properties.
    """
    if data is None:
        return False
    try:
        cls = type(data)
        cls_name = str(getattr(cls, '__name__', '') or '')
    except Exception:
        return False
    if not cls_name:
        return False
    try:
        registered = getattr(bpy.types, cls_name, None)
    except Exception:
        registered = None
    if registered is cls:
        return True
    try:
        module_name = str(getattr(cls, '__module__', '') or '')
    except Exception:
        module_name = ''
    # PropertyGroup classes are not always exposed as bpy.types.<ClassName> on
    # Blender 5.1 extension imports.  Do not touch data.bl_rna here: Blender 5.1
    # can crash in RNA path resolution when a stale or transitional RNA pointer is
    # probed via hasattr/getattr during lazy tool loading.  A module-name-only
    # match is not enough after in-place Extension reinstall, because old Python
    # class objects can keep the same module string.  Require the class object to
    # still be the one exported by the currently loaded module.
    if module_name and (
        module_name.startswith(str(__package__ or '')) or 'smart_modeling_suite' in module_name
    ):
        try:
            module = sys.modules.get(module_name)
            if module is None:
                return False
            if getattr(module, cls_name, None) is not cls:
                return False
            return hasattr(cls, 'bl_rna')
        except Exception:
            return False
    # Built-in RNA structs are generally stable even when bpy.types does not
    # return the exact same Python proxy object on every Blender build.  Blender
    # 5.1 also materializes registered custom PropertyGroup instances as
    # ``bpy.types.<ClassName>`` proxies that are not exposed through
    # getattr(bpy.types, ClassName).  Accept those only when a currently loaded
    # Smart Modeling module still exports a class with the same name; this keeps
    # native settings panels visible without probing data.bl_rna or arbitrary
    # operator-property objects.
    if module_name in {'bpy.types', '_bpy_types'}:
        if registered is not None:
            return True
        try:
            return bool(hasattr(cls, 'bl_rna'))
        except Exception:
            return False
    return False


def _sms_rna_class_is_current(cls) -> bool:
    if not isinstance(cls, type):
        return False
    try:
        cls_name = str(getattr(cls, '__name__', '') or '')
    except Exception:
        return False
    if not cls_name:
        return False
    try:
        if getattr(bpy.types, cls_name, None) is cls:
            return True
    except Exception:
        pass
    try:
        module_name = str(getattr(cls, '__module__', '') or '')
        if module_name and (module_name.startswith(str(__package__ or '')) or 'smart_modeling_suite' in module_name):
            try:
                panel_base = getattr(bpy.types, 'Panel', None)
                if panel_base is not None and issubclass(cls, panel_base):
                    # Integrated panel draw uses a Python shim and does not need
                    # RNA registration.  Keeping this True allows us to avoid
                    # registering standalone panels while preserving their UI
                    # inside the unified root panel.
                    return True
            except Exception:
                pass
            return hasattr(cls, 'bl_rna')
        if module_name in {'bpy.types', '_bpy_types'} and cls_name:
            return bool(hasattr(cls, 'bl_rna'))
    except Exception:
        pass
    return False


def _sms_prop_deferred_kind(prop_def) -> str:
    try:
        fn = getattr(prop_def, 'function', None)
        name = str(getattr(fn, '__name__', '') or '')
        if name:
            return name
    except Exception:
        pass
    try:
        text = repr(prop_def)
    except Exception:
        text = ''
    for name in (
        'BoolProperty', 'IntProperty', 'FloatProperty', 'StringProperty',
        'EnumProperty', 'FloatVectorProperty', 'IntVectorProperty',
        'BoolVectorProperty', 'PointerProperty', 'CollectionProperty',
    ):
        if name in text:
            return name
    return ''


def _sms_static_property_def(data, prop_name: str):
    if data is None or not prop_name:
        return None
    try:
        mro = type(data).__mro__
    except Exception:
        return None
    for cls in mro:
        try:
            annotations = cls.__dict__.get('__annotations__', {})
        except Exception:
            annotations = {}
        if isinstance(annotations, dict) and prop_name in annotations:
            return annotations.get(prop_name)
    return None


def _sms_static_rna_setting_ids(data, include_names=None, exclude=None):
    if data is None or not _sms_rna_data_is_current(data):
        return []
    exclude = set(exclude or ())
    include = tuple(str(name or '').strip() for name in (include_names or ()) if str(name or '').strip())
    if include:
        return [name for name in include if name and name not in exclude]
    result = []
    seen = set()
    try:
        mro = reversed(type(data).__mro__)
    except Exception:
        mro = ()
    for cls in mro:
        try:
            annotations = cls.__dict__.get('__annotations__', {})
        except Exception:
            annotations = {}
        if not isinstance(annotations, dict):
            continue
        for pid, prop_def in annotations.items():
            pid = str(pid or '').strip()
            if not pid or pid == 'rna_type' or pid in exclude or pid in seen:
                continue
            kind = _sms_prop_deferred_kind(prop_def)
            if kind in {'PointerProperty', 'CollectionProperty'}:
                continue
            # Accept unclassified annotations only for classes that use bpy.props
            # deferred objects; ordinary Python-only annotations are not drawn.
            if not kind and not hasattr(prop_def, 'keywords'):
                continue
            seen.add(pid)
            result.append(pid)
    return result


def _sms_safe_get_rna_attr(data, prop_name: str, default=None):
    prop_name = str(prop_name or '').strip()
    if data is None or not prop_name or not _sms_rna_data_is_current(data):
        return default
    try:
        kind = _sms_rna_prop_kind_for_safe_access(data, prop_name)
    except Exception:
        kind = ''
    if kind in {'PointerProperty', 'CollectionProperty'} and _sms_rna_pointer_get_is_deferred():
        return default
    try:
        return getattr(data, prop_name)
    except Exception:
        return default




def _sms_rna_has_prop(data, prop_name: str) -> bool:
    """Check a registered PropertyGroup property without direct RNA getattr/hasattr."""
    prop_name = str(prop_name or '').strip()
    if data is None or not prop_name or not _sms_rna_data_is_current(data):
        return False
    try:
        return _sms_static_property_def(data, prop_name) is not None
    except Exception:
        return False


def _sms_safe_bool_prop(data, prop_name: str, default=False) -> bool:
    if not _sms_rna_has_prop(data, prop_name):
        return bool(default)
    return bool(_sms_safe_get_rna_attr(data, prop_name, default))


def _sms_safe_set_bool_prop(data, prop_name: str, value) -> bool:
    if not _sms_rna_has_prop(data, prop_name):
        return False
    return _sms_safe_set_rna_attr(data, prop_name, bool(value))


def _sms_rna_prop_exists(data, prop_name: str) -> bool:
    """Return True only for properties declared on the current Python RNA class.

    Avoids hasattr(data, name), which can call Blender's C/RNA lookup on stale
    bpy_struct proxies during extension reinstall or panel redraw.
    """
    prop_name = str(prop_name or '').strip()
    if data is None or not prop_name or not _sms_rna_data_is_current(data):
        return False
    try:
        return _sms_static_property_def(data, prop_name) is not None
    except Exception:
        return False

def _sms_safe_set_rna_attr(data, prop_name: str, value) -> bool:
    prop_name = str(prop_name or '').strip()
    if data is None or not prop_name or not _sms_rna_data_is_current(data):
        return False
    try:
        kind = _sms_rna_prop_kind_for_safe_access(data, prop_name)
    except Exception:
        kind = ''
    if kind in {'PointerProperty', 'CollectionProperty'} and _sms_rna_pointer_get_is_deferred():
        return False
    try:
        setattr(data, prop_name, value)
        return True
    except Exception:
        return False


def _sms_safe_layout_prop(layout, data, prop_name: str, **kwargs) -> bool:
    if layout is None or data is None or not prop_name or not _sms_rna_data_is_current(data):
        return False
    if not _sms_rna_has_prop(data, prop_name):
        return False
    try:
        layout.prop(data, prop_name, **kwargs)
        return True
    except Exception:
        return False


def _sms_flush_userpref_save():
    global _SMS_USERPREF_SAVE_PENDING
    _SMS_USERPREF_SAVE_PENDING = False
    if not _sms_runtime_active():
        return None
    # Never call bpy.ops.wm.save_userpref() from RNA update callbacks or
    # automatic UI refresh paths. On Blender 5.1 this can re-enter UI layout and
    # panel header drawing while RNA is still changing. N-panel values are saved
    # to the extension JSON snapshot here; Blender preferences are saved only by
    # the explicit Smart Modeling "Save Preferences" operator.
    try:
        _sms_capture_suite_panel_settings(context=getattr(bpy, 'context', None), prefs=_sms_get_suite_prefs(getattr(bpy, 'context', None)))
    except Exception:
        pass
    try:
        _sms_flush_panel_settings_save(force=True)
    except TypeError:
        try:
            _sms_flush_panel_settings_save()
        except Exception:
            pass
    except Exception:
        pass
    return None

def _sms_npanel_state_save_from_snapshot(default=True):
    try:
        snapshot = _sms_load_panel_settings_snapshot()
        values = snapshot.get('values', {}) if isinstance(snapshot, dict) else {}
        if isinstance(values, dict):
            for section in values.values():
                if isinstance(section, dict) and 'n_panel_state_save' in section:
                    value = section.get('n_panel_state_save')
                    if isinstance(value, bool):
                        return value
    except Exception:
        pass
    try:
        path = _sms_panel_settings_path()
        if path.exists():
            root = json.loads(path.read_text(encoding='utf-8'))
            if isinstance(root, dict) and 'n_panel_state_save' in root:
                value = root.get('n_panel_state_save')
                if isinstance(value, bool):
                    return value
    except Exception:
        pass
    return bool(default)


def _sms_npanel_state_save_enabled(context=None, prefs=None, *, default=True) -> bool:
    """Read the materialized N-panel save switch without file I/O."""
    try:
        if isinstance(_SMS_NPANEL_STATE_SAVE_CACHE, bool):
            return bool(_SMS_NPANEL_STATE_SAVE_CACHE)
    except Exception:
        pass
    try:
        live = prefs or _sms_get_suite_prefs(context or getattr(bpy, 'context', None))
        if live is not None and _sms_rna_prop_exists(live, 'n_panel_state_save'):
            return bool(_sms_safe_get_rna_attr(live, 'n_panel_state_save', bool(default)))
    except Exception:
        pass
    try:
        snapshot = _SMS_PANEL_SETTINGS_CACHE if isinstance(_SMS_PANEL_SETTINGS_CACHE, dict) else {}
        values = snapshot.get('values', {}) if isinstance(snapshot, dict) else {}
        if isinstance(values, dict):
            for section in tuple(values.values()):
                if isinstance(section, dict) and 'n_panel_state_save' in section:
                    return bool(section.get('n_panel_state_save'))
    except Exception:
        pass
    return bool(default)


def _sms_schedule_userpref_save():
    global _SMS_USERPREF_SAVE_PENDING
    if not _sms_runtime_active():
        return
    # All writes are controlled exclusively by N-panel State Save.  Turning it
    # OFF records that transition once; no later event, save/load boundary or
    # force path may write until the switch is enabled again.
    if not _sms_npanel_state_save_enabled(getattr(bpy, 'context', None), default=True):
        _SMS_USERPREF_SAVE_PENDING = False
        return
    _SMS_USERPREF_SAVE_PENDING = True
    _sms_flush_userpref_save()


def _sms_cleanup_legacy_idle_resources_if_all_off(context=None, prefs_override=None):
    """Release late-installed legacy resources when centralized runtimes are OFF."""
    prefs = prefs_override or _sms_get_suite_prefs(context or getattr(bpy, 'context', None))
    try:
        from . import unified_contract as _contract
        names = tuple(str(path).rsplit('.', 1)[-1] for path in _contract.RUNTIME_TOGGLE_PATHS)
    except Exception:
        names = ()
    if not names:
        return
    try:
        if prefs is not None:
            any_enabled = any(bool(_sms_safe_get_rna_attr(prefs, name, False)) for name in names)
        else:
            # During the short Blender 5.1 RNA safety window, use the durable
            # toggle snapshot instead of abandoning cleanup altogether.
            any_enabled = any(
                bool(_sms_persistent_toggle_state_get(name, context=context, prefs=None, default=False))
                for name in names
            )
        if any_enabled:
            return
    except Exception:
        return
    try:
        _none_live = sys.modules.get(f'{__package__}.key_operators_toolkit.fix_maya_pivot.operators.none_live_booleans')
        cls = getattr(_none_live, 'ENTERING_TRANSFORM_OT_None_Live_Booleans', None) if _none_live is not None else None
        cleanup = getattr(cls, 'unregister', None) if cls is not None else None
        if callable(cleanup):
            cleanup()
    except Exception:
        pass
    try:
        # All centralized runtime toggles are OFF.  Do not import the heavy
        # Tissue package merely to prove that an optional frame handler is not
        # running.  If the user actually loaded Tissue earlier, clean up that
        # already-resident module; otherwise the zero-load state remains truly
        # lazy and avoids importing NumPy/Tissue during Blender startup.
        _tex_rd = sys.modules.get(f'{__package__}.tissue.texture_reaction_diffusion')
        cleanup = getattr(_tex_rd, 'tex_reaction_diffusion_remove_handler', None) if _tex_rd is not None else None
        if callable(cleanup):
            cleanup(None, context)
    except Exception:
        pass


def _sms_update_ui_state(self, context, *, skip_common_persistence=False):
    try:
        _sms_capture_suite_panel_settings(context=context, prefs=_sms_get_suite_prefs(context))
    except Exception:
        pass
    try:
        _sms_schedule_panel_settings_save()
    except Exception:
        pass
    try:
        _sms_schedule_userpref_save()
    except Exception:
        pass
    try:
        _sms_tag_redraw_view3d_areas()
    except Exception:
        pass
    try:
        _sms_cleanup_legacy_idle_resources_if_all_off(context, prefs_override=self)
    except Exception:
        pass
    if not skip_common_persistence:
        try:
            from . import common as _sms_common
            sync = getattr(_sms_common, 'sync_persistence_subscriptions', None)
            save = getattr(_sms_common, 'save_persistent_settings', None)
            if callable(sync):
                sync(context)
            if callable(save):
                save(context, force=False)
        except Exception:
            pass
    return None


def _update_click_only_tool_setting(self, context):
    """Persist click-only UI state without resynchronizing resident features.

    Legacy ``enable_*`` fields for command-only tools are ordinary N-panel
    preferences.  Sending them through the resident runtime callback used to
    unload independently opened Key Ops/Tissue settings whenever one changed.
    """
    return _sms_update_ui_state(self, context)


def _sms_config_dir() -> Path:
    try:
        cfg = bpy.utils.user_resource('CONFIG')
        if cfg:
            path = Path(cfg)
            path.mkdir(parents=True, exist_ok=True)
            return path
    except Exception:
        pass
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', (5, 1, 0))
        version_label = f"{int(version[0])}.{int(version[1])}" if version and len(version) >= 2 else '5.1'
    except Exception:
        version_label = '5.1'
    if os.name == 'nt':
        base = os.environ.get('APPDATA') or os.path.join(os.path.expanduser('~'), 'AppData', 'Roaming')
        path = Path(base) / 'Blender Foundation' / 'Blender' / version_label / 'config'
    else:
        path = Path(os.path.expanduser('~')) / '.config' / 'blender' / version_label / 'config'
    try:
        path.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return path


def _sms_panel_settings_path() -> Path:
    try:
        from . import common as _sms_common
        return Path(_sms_common.settings_path())
    except Exception:
        return _sms_config_dir() / 'Smart_Modeling_Suite' / 'Smart_Modeling_Suite.json'


def _sms_legacy_panel_settings_paths():
    paths = []
    try:
        from . import common as _sms_common
        getter = getattr(_sms_common, 'legacy_settings_paths', None)
        if callable(getter):
            paths.extend(Path(p) for p in getter())
    except Exception:
        pass
    try:
        paths.append(_sms_config_dir() / 'Smart_Modeling_Suite.json')
    except Exception:
        pass
    current = _sms_panel_settings_path()
    unique = []
    seen = set()
    for path in paths:
        try:
            key = str(Path(path).resolve())
        except Exception:
            key = str(path)
        try:
            if Path(path) == current:
                continue
        except Exception:
            pass
        if key not in seen:
            seen.add(key)
            unique.append(Path(path))
    return tuple(unique)


def _sms_load_panel_settings_snapshot() -> dict:
    global _SMS_PANEL_SETTINGS_CACHE
    if isinstance(_SMS_PANEL_SETTINGS_CACHE, dict):
        return _SMS_PANEL_SETTINGS_CACHE
    data = {}
    candidate_paths = [_sms_panel_settings_path()]
    try:
        candidate_paths.extend(_sms_legacy_panel_settings_paths())
    except Exception:
        pass
    for path in candidate_paths:
        try:
            if path.exists():
                raw = json.loads(path.read_text(encoding='utf-8'))
                if isinstance(raw, dict):
                    candidate = raw.get('panel_settings') if isinstance(raw.get('panel_settings'), dict) else raw
                    if isinstance(candidate, dict):
                        data = candidate
                        break
        except Exception:
            data = {}
    if not isinstance(data, dict):
        data = {}
    if not isinstance(data.get('values'), dict):
        data['values'] = {}
    if not isinstance(data.get('ui_state'), dict):
        data['ui_state'] = {}
    else:
        data['ui_state'] = {
            str(key): value for key, value in data['ui_state'].items()
            if isinstance(value, bool)
        }
    if not isinstance(data.get('persistent_toggle_state'), dict):
        data['persistent_toggle_state'] = {}
    else:
        data['persistent_toggle_state'] = {
            str(key): value for key, value in data['persistent_toggle_state'].items()
            if isinstance(value, bool)
        }
    if 'n_panel_state_save' in data and not isinstance(data.get('n_panel_state_save'), bool):
        data.pop('n_panel_state_save', None)
    resident_keys = _sms_persistent_toggle_prop_names()
    for section in tuple(data['values'].values()):
        if not isinstance(section, dict):
            continue
        for key in tuple(section.keys()):
            if (key == 'n_panel_state_save' or key in resident_keys or str(key).startswith('ui_show_')) and not isinstance(section.get(key), bool):
                section.pop(key, None)
    data['version'] = _SMS_PANEL_SETTINGS_VERSION
    _SMS_PANEL_SETTINGS_CACHE = data
    return _SMS_PANEL_SETTINGS_CACHE


def _sms_flush_panel_settings_save(force=False, *, allow_disabled_transition=False):
    global _SMS_PANEL_SETTINGS_DIRTY, _SMS_PANEL_SETTINGS_SAVE_PENDING
    _SMS_PANEL_SETTINGS_SAVE_PENDING = False
    if not force and not _sms_runtime_active():
        return None
    if not _sms_npanel_state_save_enabled(getattr(bpy, 'context', None), default=True) and not allow_disabled_transition:
        return None
    if not force and not _SMS_PANEL_SETTINGS_DIRTY:
        return None
    try:
        from . import common as _sms_common
        writer = getattr(_sms_common, 'save_persistent_settings', None)
        if not callable(writer):
            return None
        wrote = bool(writer(
            getattr(bpy, 'context', None),
            force=bool(force),
            allow_disabled_transition=bool(allow_disabled_transition),
        ))
        if wrote:
            _SMS_PANEL_SETTINGS_DIRTY = False
        return wrote
    except Exception:
        return None
    return None


def _sms_schedule_panel_settings_save():
    global _SMS_PANEL_SETTINGS_DIRTY, _SMS_PANEL_SETTINGS_SAVE_PENDING
    if not _sms_runtime_active():
        return
    _SMS_PANEL_SETTINGS_DIRTY = True
    _SMS_PANEL_SETTINGS_SAVE_PENDING = True
    if not _sms_npanel_state_save_enabled(getattr(bpy, 'context', None), default=True):
        return
    _sms_flush_panel_settings_save()


def _sms_ui_section_state_get(prefs, section_key: str, default=False) -> bool:
    """Read an already-materialized UI state without I/O or mutation."""
    section_key = str(section_key or '').strip()
    if not section_key:
        return bool(default)
    try:
        snapshot = _SMS_PANEL_SETTINGS_CACHE if isinstance(_SMS_PANEL_SETTINGS_CACHE, dict) else {}
        ui_state = snapshot.get('ui_state', {}) if isinstance(snapshot, dict) else {}
        if isinstance(ui_state, dict) and section_key in ui_state:
            return bool(ui_state.get(section_key, default))
    except Exception:
        pass
    if prefs is not None and _sms_rna_prop_exists(prefs, section_key):
        return bool(_sms_safe_get_rna_attr(prefs, section_key, default))
    return bool(default)


def _sms_ui_section_state_set(section_key: str, value, *, context=None, prefs=None):
    section_key = str(section_key or '').strip()
    if not section_key:
        return
    context = context or getattr(bpy, 'context', None)
    prefs = prefs or _sms_get_suite_prefs(context)
    value = bool(value)
    try:
        snapshot = _sms_load_panel_settings_snapshot()
        ui_state = snapshot.setdefault('ui_state', {})
        if not isinstance(ui_state, dict):
            ui_state = {}
            snapshot['ui_state'] = ui_state
        ui_state[section_key] = value
        _sms_schedule_panel_settings_save()
    except Exception:
        pass
    if prefs is not None and _sms_rna_prop_exists(prefs, section_key):
        current = bool(_sms_safe_get_rna_attr(prefs, section_key, not value))
        if current != value:
            _sms_safe_set_rna_attr(prefs, section_key, value)
        try:
            _sms_capture_suite_panel_settings(context=context, prefs=prefs)
            _sms_schedule_panel_settings_save()
        except Exception:
            pass
        try:
            _sms_schedule_userpref_save()
        except Exception:
            pass
        try:
            _sms_tag_redraw_view3d_areas()
        except Exception:
            pass
        return
    try:
        snapshot = _sms_load_panel_settings_snapshot()
        ui_state = snapshot.setdefault('ui_state', {})
        if not isinstance(ui_state, dict):
            ui_state = {}
            snapshot['ui_state'] = ui_state
        if bool(ui_state.get(section_key, not value)) != value:
            ui_state[section_key] = value
            _sms_schedule_panel_settings_save()
    except Exception:
        pass
    try:
        _sms_schedule_userpref_save()
    except Exception:
        pass
    try:
        _sms_tag_redraw_view3d_areas()
    except Exception:
        pass


def _sms_persistent_toggle_snapshot_get(prop_name: str, default=False) -> bool:
    prop_name = str(prop_name or '').strip()
    if not prop_name:
        return bool(default)
    try:
        snapshot = _sms_load_panel_settings_snapshot()
        states = snapshot.setdefault('persistent_toggle_state', {})
        if not isinstance(states, dict):
            states = {}
            snapshot['persistent_toggle_state'] = states
        return bool(states.get(prop_name, default))
    except Exception:
        return bool(default)


def _sms_persistent_toggle_snapshot_set(prop_name: str, value) -> None:
    prop_name = str(prop_name or '').strip()
    if not prop_name:
        return
    value = bool(value)
    try:
        snapshot = _sms_load_panel_settings_snapshot()
        states = snapshot.setdefault('persistent_toggle_state', {})
        if not isinstance(states, dict):
            states = {}
            snapshot['persistent_toggle_state'] = states
        if bool(states.get(prop_name, not value)) != value:
            states[prop_name] = value
            _sms_schedule_panel_settings_save()
    except Exception:
        pass


def _sms_persistent_toggle_state_get(prop_name: str, *, context=None, prefs=None, default=False) -> bool:
    """Read a materialized persistent toggle without loading or saving data."""
    prop_name = str(prop_name or '').strip()
    if not prop_name:
        return bool(default)
    try:
        snapshot = _SMS_PANEL_SETTINGS_CACHE if isinstance(_SMS_PANEL_SETTINGS_CACHE, dict) else {}
        states = snapshot.get('persistent_toggle_state', {}) if isinstance(snapshot, dict) else {}
        if isinstance(states, dict) and prop_name in states:
            value = states.get(prop_name, default)
            if isinstance(value, bool):
                return value
    except Exception:
        pass
    live_prefs = prefs or _sms_get_suite_prefs(context or getattr(bpy, 'context', None))
    if live_prefs is not None and _sms_rna_prop_exists(live_prefs, prop_name):
        return bool(_sms_safe_get_rna_attr(live_prefs, prop_name, default))
    return bool(default)


def _sms_persistent_toggle_state_set(prop_name: str, value, *, context=None, prefs=None) -> None:
    prop_name = str(prop_name or '').strip()
    if not prop_name:
        return
    value = bool(value)
    context = context or getattr(bpy, 'context', None)
    prefs = prefs or _sms_get_suite_prefs(context)
    stored_in_rna = False
    if prefs is not None and _sms_rna_prop_exists(prefs, prop_name):
        current = bool(_sms_safe_get_rna_attr(prefs, prop_name, not value))
        if current != value:
            stored_in_rna = bool(_sms_safe_set_rna_attr(prefs, prop_name, value))
        else:
            stored_in_rna = True
    _sms_persistent_toggle_snapshot_set(prop_name, value)
    if stored_in_rna:
        try:
            _sms_capture_suite_panel_settings(context=context, prefs=prefs)
        except Exception:
            pass
        try:
            _sms_schedule_userpref_save()
        except Exception:
            pass
    # The master N-panel state-save switch governs startup toggle persistence as
    # well; OFF defers the write and ON flushes the in-memory snapshot.
    _sms_schedule_panel_settings_save()
    try:
        _sms_tag_redraw_view3d_areas()
    except Exception:
        pass



def _sms_npanel_state_save_state_set(value, *, context=None, prefs=None) -> None:
    """Set the N-panel state-save switch without relying on direct layout.prop.

    The Always-on list uses operator-style toggles.  Keeping this switch on a
    direct RNA property row made it unresponsive on some Blender 5.1 reload
    states when the visible PropertyGroup proxy was stale.  This helper updates
    the live RNA object when it is safe, mirrors the value into the JSON-backed
    snapshot, and force-flushes once so OFF is also persisted immediately.
    """
    global _SMS_NPANEL_STATE_SAVE_CACHE, _SMS_PANEL_SETTINGS_DIRTY
    value = bool(value)
    _SMS_NPANEL_STATE_SAVE_CACHE = value
    try:
        from . import common as _sms_common
        set_fn = getattr(_sms_common, 'set_n_panel_state_save_enabled', None)
        if callable(set_fn):
            set_fn(value, context or getattr(bpy, 'context', None), force_save=False)
    except Exception:
        pass
    try:
        prefs = prefs or _sms_get_suite_prefs(context or getattr(bpy, 'context', None))
    except Exception:
        prefs = None
    try:
        if prefs is not None and _sms_rna_prop_exists(prefs, 'n_panel_state_save'):
            current = bool(_sms_safe_get_rna_attr(prefs, 'n_panel_state_save', not value))
            if current != value:
                _sms_safe_set_rna_attr(prefs, 'n_panel_state_save', value)
    except Exception:
        pass
    try:
        snapshot = _sms_load_panel_settings_snapshot()
        values = snapshot.setdefault('values', {})
        if not isinstance(values, dict):
            values = {}
            snapshot['values'] = values
        namespace = _sms_suite_panel_settings_namespace(prefs)
        section = values.setdefault(namespace, {})
        if not isinstance(section, dict):
            section = {}
            values[namespace] = section
        section['n_panel_state_save'] = value
        # Backward-compatible location read by older recovery paths.
        snapshot['n_panel_state_save'] = value
        _SMS_PANEL_SETTINGS_DIRTY = True
    except Exception:
        pass
    try:
        _sms_flush_panel_settings_save(force=True, allow_disabled_transition=True)
    except Exception:
        pass
    try:
        _sms_tag_redraw_view3d_areas()
    except Exception:
        pass

def _sms_sync_persistent_toggle_snapshot_to_prefs(context=None, prefs=None) -> None:
    global _SMS_PERSISTENT_TOGGLE_SYNC_DEPTH
    if _sms_toggle_update_active() or _sms_runtime_sync_active():
        return
    prefs = prefs or _sms_get_suite_prefs(context or getattr(bpy, 'context', None))
    if prefs is None:
        return
    try:
        snapshot = _sms_load_panel_settings_snapshot()
        states = snapshot.get('persistent_toggle_state', {})
        if not isinstance(states, dict):
            states = {}
        # Migration/fallback for v007 and earlier: persistent toggles may exist
        # only in the generic values namespace.  Promote them before applying so
        # Blender startup and scene-load restore do not fall back to defaults.
        if not states:
            values = snapshot.get('values', {})
            namespace = _sms_suite_panel_settings_namespace(prefs)
            section = values.get(namespace) if isinstance(values, dict) else None
            if isinstance(section, dict):
                promoted = {}
                for prop_name in tuple(_sms_persistent_toggle_prop_names()):
                    if prop_name in section:
                        value = section.get(prop_name)
                        if isinstance(value, bool):
                            promoted[prop_name] = value
                if promoted:
                    states = promoted
                    snapshot['persistent_toggle_state'] = dict(promoted)
                    try:
                        _sms_schedule_panel_settings_save()
                    except Exception:
                        pass
    except Exception:
        states = {}
    if not isinstance(states, dict) or not states:
        return
    changed = False
    _SMS_PERSISTENT_TOGGLE_SYNC_DEPTH += 1
    try:
        for prop_name, value in tuple(states.items()):
            prop_name = str(prop_name or '').strip()
            if not prop_name or not isinstance(value, bool) or not _sms_rna_prop_exists(prefs, prop_name):
                continue
            current = bool(_sms_safe_get_rna_attr(prefs, prop_name, not value))
            if current == value:
                continue
            if _sms_safe_set_rna_attr(prefs, prop_name, value):
                changed = True
    finally:
        _SMS_PERSISTENT_TOGGLE_SYNC_DEPTH = max(0, _SMS_PERSISTENT_TOGGLE_SYNC_DEPTH - 1)
    if changed:
        try:
            _sms_capture_suite_panel_settings(context=context, prefs=prefs)
        except Exception:
            pass
        try:
            _sms_schedule_userpref_save()
        except Exception:
            pass
        try:
            _sms_update_persistent_tool_runtime_from_prefs(context)
        except Exception:
            pass


def _sms_serializable_setting_value(value):
    if isinstance(value, (bool, int, float, str)) or value is None:
        return value
    if isinstance(value, (tuple, list)) and len(value) <= 32:
        result = []
        for item in value:
            if not isinstance(item, (bool, int, float, str)) and item is not None:
                return None
            result.append(item)
        return result
    try:
        if hasattr(value, '__len__') and not isinstance(value, (str, bytes)):
            seq = list(value)
            if len(seq) <= 32 and all(isinstance(item, (bool, int, float, str)) or item is None for item in seq):
                return seq
    except Exception:
        pass
    return None


def _sms_iter_rna_setting_ids(data, include_names=None, exclude=None):
    # Do not inspect data.bl_rna here. On Blender 5.1, stale PropertyGroup
    # instances left after an in-place extension reinstall can crash in
    # RNA_struct_find_property before Python can catch an exception. Use the
    # current Python class annotations instead, and only when the data object is
    # still backed by the currently registered bpy.types class.
    return _sms_static_rna_setting_ids(data, include_names=include_names, exclude=exclude)


def _sms_settings_namespace(kind: str, key: str, data, title='') -> str:
    try:
        cls = type(data)
        class_key = f'{getattr(cls, "__module__", "")}.{getattr(cls, "__name__", cls.__class__.__name__)}'
    except Exception:
        class_key = 'unknown'
    raw_title = ''.join(ch if ch.isalnum() or ch in '._-' else '_' for ch in str(title or ''))[:80]
    return f'{str(kind or "misc")}:{str(key or "unknown")}:{class_key}:{raw_title}'


def _sms_rna_data_is_scene_local(data) -> bool:
    """True for data stored in a .blend scene rather than global add-on prefs."""
    if data is None:
        return False
    try:
        cls = type(data)
        cls_name = str(getattr(cls, '__name__', '') or '')
        module_name = str(getattr(cls, '__module__', '') or '')
    except Exception:
        return False
    if cls_name == 'Scene' and module_name in {'bpy.types', '_bpy_types'}:
        return True
    return False


def _sms_restore_rna_settings(namespace: str, data, include_names=None, exclude=None):
    namespace = str(namespace or '').strip()
    if not namespace or data is None or not _sms_rna_data_is_current(data):
        return
    if _sms_rna_data_is_scene_local(data):
        # Scene-local tool settings are part of the .blend file.  Restoring them
        # from the external N-panel settings snapshot on load can overwrite the
        # opened file's own values and fire update callbacks.
        return
    values = _sms_load_panel_settings_snapshot().get('values', {})
    section = values.get(namespace)
    if not isinstance(section, dict):
        return
    allowed = set(_sms_iter_rna_setting_ids(data, include_names=include_names, exclude=exclude))
    for pid, value in tuple(section.items()):
        pid = str(pid or '').strip()
        if not pid or pid not in allowed:
            continue
        current = _sms_safe_get_rna_attr(data, pid, None)
        try:
            if _sms_serializable_setting_value(current) == value:
                continue
        except Exception:
            pass
        _sms_safe_set_rna_attr(data, pid, value)


def _sms_capture_rna_settings(namespace: str, data, include_names=None, exclude=None):
    if _sms_is_panel_draw_active():
        return
    namespace = str(namespace or '').strip()
    if not namespace or data is None or not _sms_rna_data_is_current(data):
        return
    if _sms_rna_data_is_scene_local(data):
        return
    snapshot = _sms_load_panel_settings_snapshot()
    values = snapshot.setdefault('values', {})
    section = values.setdefault(namespace, {})
    changed = False
    for pid in _sms_iter_rna_setting_ids(data, include_names=include_names, exclude=exclude):
        value = _sms_serializable_setting_value(_sms_safe_get_rna_attr(data, pid, None))
        if value is None:
            continue
        if section.get(pid) != value:
            section[pid] = value
            changed = True
    if changed:
        _sms_schedule_panel_settings_save()


def _sms_suite_panel_settings_namespace(prefs=None) -> str:
    return _sms_settings_namespace('suite', 'n_panel', prefs, 'Smart Modeling N-panel')


def _sms_capture_suite_panel_settings(context=None, prefs=None):
    prefs = prefs or _sms_get_suite_prefs(context or getattr(bpy, 'context', None))
    if prefs is None:
        return
    try:
        toggle_names = set(_sms_persistent_toggle_prop_names())
    except Exception:
        toggle_names = set()
    # The startup-runtime switches are snapshot-authoritative and are changed by
    # operator-style buttons.  Do not let a freshly-created RNA PropertyGroup full
    # of default False values overwrite already-saved ON states during startup,
    # reinstall, or unsafe UI redraw phases.
    _sms_capture_rna_settings(_sms_suite_panel_settings_namespace(prefs), prefs, exclude={'rna_type', *toggle_names})
    try:
        snapshot = _sms_load_panel_settings_snapshot()
        states = snapshot.setdefault('persistent_toggle_state', {})
        if not isinstance(states, dict):
            states = {}
            snapshot['persistent_toggle_state'] = states
        changed = False
        for prop_name in tuple(toggle_names):
            prop_name = str(prop_name or '').strip()
            if not prop_name or prop_name in states or not _sms_rna_prop_exists(prefs, prop_name):
                continue
            value = bool(_sms_safe_get_rna_attr(prefs, prop_name, False))
            states[prop_name] = value
            changed = True
        if changed:
            _sms_schedule_panel_settings_save()
    except Exception:
        pass


def _sms_saved_npanel_default_values() -> dict:
    """Return JSON-backed defaults for SMS_NPanelSettings before RNA exists."""
    result = {}
    try:
        snapshot = _sms_load_panel_settings_snapshot()
    except Exception:
        snapshot = {}
    try:
        values = snapshot.get('values', {}) if isinstance(snapshot, dict) else {}
        if isinstance(values, dict):
            for namespace, section in tuple(values.items()):
                if not isinstance(section, dict):
                    continue
                if 'SMS_NPanelSettings' not in str(namespace):
                    continue
                for key, value in tuple(section.items()):
                    if isinstance(value, (bool, int, float, str)) or value is None:
                        result[str(key)] = value
    except Exception:
        pass
    try:
        states = snapshot.get('persistent_toggle_state', {}) if isinstance(snapshot, dict) else {}
        if isinstance(states, dict):
            for key, value in tuple(states.items()):
                result[str(key)] = bool(value)
    except Exception:
        pass
    return result


def _sms_apply_saved_defaults_to_npanel_annotations() -> None:
    """Seed PropertyGroup defaults from external JSON before registration.

    This makes startup restoration visible as soon as WindowManager creates the
    pointer property, before UI timers or delayed load-post repair callbacks run.
    Only existing static/deferred RNA declarations are rewritten, preserving their
    names, descriptions, update callbacks, and UI text.
    """
    try:
        saved = _sms_saved_npanel_default_values()
        if not saved:
            return
        annotations = dict(getattr(SMS_NPanelSettings, '__annotations__', {}) or {})
        changed = False
        for prop_name, value in tuple(saved.items()):
            prop_name = str(prop_name or '').strip()
            if prop_name not in annotations:
                continue
            deferred = annotations.get(prop_name)
            keywords = dict(getattr(deferred, 'keywords', {}) or {})
            if not keywords or 'default' not in keywords:
                continue
            current_default = keywords.get('default')
            if isinstance(current_default, bool):
                keywords['default'] = bool(value)
            elif isinstance(current_default, int) and not isinstance(current_default, bool):
                try:
                    keywords['default'] = int(value)
                except Exception:
                    continue
            elif isinstance(current_default, float):
                try:
                    keywords['default'] = float(value)
                except Exception:
                    continue
            elif isinstance(current_default, str):
                keywords['default'] = str(value)
            else:
                continue
            try:
                if isinstance(current_default, bool):
                    annotations[prop_name] = BoolProperty(**keywords)
                elif isinstance(current_default, int) and not isinstance(current_default, bool):
                    annotations[prop_name] = IntProperty(**keywords)
                elif isinstance(current_default, float):
                    annotations[prop_name] = FloatProperty(**keywords)
                elif isinstance(current_default, str):
                    annotations[prop_name] = StringProperty(**keywords)
                changed = True
            except Exception:
                pass
        if changed:
            SMS_NPanelSettings.__annotations__ = annotations
    except Exception:
        pass


def _sms_wire_npanel_setting_updates() -> None:
    """Attach immediate JSON persistence to every scalar N-panel property.

    A number of compatibility properties are appended to ``SMS_NPanelSettings``
    dynamically and historically had no update callback.  Wiring the class once
    before RNA registration makes the persistence contract exhaustive without a
    polling timer.  Existing semantic callbacks are preserved and run first.
    """
    try:
        annotations = dict(getattr(SMS_NPanelSettings, '__annotations__', {}) or {})
    except Exception:
        return
    changed = False
    for prop_name, deferred in tuple(annotations.items()):
        try:
            factory = getattr(deferred, 'function', None)
            keywords = dict(getattr(deferred, 'keywords', {}) or {})
            if not callable(factory) or not keywords:
                continue
            # Blender's CollectionProperty has no ``update`` keyword.  It is
            # persisted by the explicit collection mutation helpers instead.
            if getattr(factory, '__name__', '') == 'CollectionProperty':
                continue
            previous = keywords.get('update')
            if bool(getattr(previous, '_sms_npanel_persistence_wrapper', False)):
                continue

            # RNA validates the callback signature and rejects a closure that
            # exposes the captured callback as a third/default parameter.
            def _make_persisting_update(_previous, _prop_name):
                def _persisting_update(self, context):
                    # Direct BoolProperty buttons in the common section bypass
                    # the legacy operator setter, so publish the changed runtime
                    # switch before the semantic callback reads the authoritative
                    # snapshot.
                    try:
                        if _prop_name in _sms_persistent_toggle_prop_names():
                            _sms_persistent_toggle_snapshot_set(
                                _prop_name,
                                bool(getattr(self, _prop_name, False)),
                            )
                    except Exception:
                        pass
                    _unload_generation_before = int(globals().get('_SMS_DYNAMIC_UNLOAD_GENERATION', 0) or 0)
                    if callable(_previous):
                        _previous(self, context)
                    _sms_update_ui_state(
                        self,
                        context,
                        skip_common_persistence=(
                            int(globals().get('_SMS_DYNAMIC_UNLOAD_GENERATION', 0) or 0)
                            != _unload_generation_before
                        ),
                    )
                _persisting_update.__name__ = f'_sms_persist_{_prop_name}'
                _persisting_update._sms_npanel_persistence_wrapper = True
                return _persisting_update

            _persisting_update = _make_persisting_update(previous, prop_name)
            _persisting_update._sms_npanel_persistence_wrapper = True
            keywords['update'] = _persisting_update
            annotations[prop_name] = factory(**keywords)
            changed = True
        except Exception:
            continue
    if changed:
        SMS_NPanelSettings.__annotations__ = annotations


def _sms_restore_suite_panel_settings(context=None, prefs=None):
    global _SMS_NATIVE_PANEL_RESTORE_DEPTH
    prefs = prefs or _sms_get_suite_prefs(context or getattr(bpy, 'context', None))
    if prefs is None:
        return
    _SMS_NATIVE_PANEL_RESTORE_DEPTH += 1
    try:
        exclude = {'rna_type'}
        try:
            exclude.update(_sms_persistent_toggle_prop_names())
        except Exception:
            pass
        _sms_restore_rna_settings(_sms_suite_panel_settings_namespace(prefs), prefs, exclude=exclude)
        if not _sms_toggle_update_active() and not _sms_runtime_sync_active():
            _sms_sync_persistent_toggle_snapshot_to_prefs(context=context, prefs=prefs)
    finally:
        _SMS_NATIVE_PANEL_RESTORE_DEPTH = max(0, _SMS_NATIVE_PANEL_RESTORE_DEPTH - 1)


def _sms_restore_known_panel_settings(context=None):
    global _SMS_RESTORE_KNOWN_PANEL_SETTINGS_DEPTH
    if _sms_toggle_update_active() or _sms_runtime_sync_active():
        return
    if _SMS_RESTORE_KNOWN_PANEL_SETTINGS_DEPTH > 0:
        return
    context = context or getattr(bpy, 'context', None)
    prefs = _sms_get_suite_prefs(context) if context is not None else None
    _SMS_RESTORE_KNOWN_PANEL_SETTINGS_DEPTH += 1
    try:
        try:
            _sms_restore_suite_panel_settings(context, prefs)
        except Exception:
            pass
        return
    finally:
        _SMS_RESTORE_KNOWN_PANEL_SETTINGS_DEPTH = max(0, _SMS_RESTORE_KNOWN_PANEL_SETTINGS_DEPTH - 1)


def _sms_panel_class_belongs_to_current_package(cls) -> bool:
    try:
        import os as _os
        import sys as _sys
        root = _os.path.normcase(_os.path.abspath(_os.path.dirname(__file__)))
        module_name = str(getattr(cls, '__module__', '') or '')
        module = _sys.modules.get(module_name)
        module_file = str(getattr(module, '__file__', '') or '') if module is not None else ''
        if not module_file:
            return False
        module_path = _os.path.normcase(_os.path.abspath(module_file))
        return module_path == root or module_path.startswith(root + _os.sep)
    except Exception:
        return False



def _sms_panel_class_is_panel(cls) -> bool:
    try:
        panel_base = getattr(bpy.types, 'Panel', None)
        return bool(panel_base is not None and isinstance(cls, type) and issubclass(cls, panel_base))
    except Exception:
        return False


def _sms_patch_registered_panel_in_place(existing, source) -> bool:
    if not (_sms_panel_class_is_panel(existing) and isinstance(source, type)):
        return False
    if not _sms_class_is_owned_for_mutation(existing) or not _sms_exact_class_belongs_to_current_package(source):
        return False
    for attr in ('bl_label', 'bl_description', 'bl_category', 'bl_space_type', 'bl_region_type', 'bl_parent_id', 'bl_options', 'bl_order', 'bl_context'):
        if attr in getattr(source, '__dict__', {}):
            try:
                setattr(existing, attr, getattr(source, attr))
            except Exception:
                pass
    for attr in ('poll', 'draw', 'draw_header', 'draw_header_preset'):
        if attr in getattr(source, '__dict__', {}):
            try:
                setattr(existing, attr, getattr(source, attr))
            except Exception:
                pass
    return True




def _sms_registered_rna_class(cls):
    if not isinstance(cls, type):
        return None
    try:
        existing = getattr(bpy.types, str(getattr(cls, '__name__', '') or ''), None)
        if isinstance(existing, type):
            try:
                getattr(existing, 'bl_rna')
                return existing
            except Exception:
                pass
    except Exception:
        pass
    # Registered PropertyGroups never appear as bpy.types attributes on
    # Blender 5.1 and usually have no bl_idname; without this lookup they are
    # invisible here (measured on 5.1.2).
    try:
        group_base = getattr(bpy.types, 'PropertyGroup', None)
        if group_base is not None and issubclass(cls, group_base):
            existing = _sms_registered_propertygroup_subclass(str(getattr(cls, '__name__', '') or ''))
            if isinstance(existing, type):
                return existing
    except Exception:
        pass
    bl_idname = str(getattr(cls, 'bl_idname', '') or '').strip()
    if not bl_idname:
        return None
    try:
        class_name = str(getattr(cls, '__name__', '') or '').strip()
        candidates = {bl_idname, class_name}
        if bl_idname and '.' in bl_idname and '_OT_' in class_name:
            namespace = bl_idname.split('.', 1)[0].upper()
            _, suffix = class_name.split('_OT_', 1)
            if namespace and suffix:
                candidates.add(f'{namespace}_OT_{suffix}')
        for candidate in tuple(c for c in candidates if c):
            for base_name in ('Operator', 'Menu', 'Panel', 'AddonPreferences', 'PropertyGroup', 'Gizmo', 'GizmoGroup', 'UIList', 'Header'):
                try:
                    base = getattr(bpy.types, base_name, None)
                    getter = getattr(base, 'bl_rna_get_subclass_py', None) if base is not None else None
                    if callable(getter):
                        existing = getter(candidate, None)
                        if isinstance(existing, type):
                            return existing
                except Exception:
                    pass
    except Exception:
        pass
    for base_name in ('Operator', 'Menu', 'Panel', 'AddonPreferences', 'PropertyGroup', 'Gizmo', 'GizmoGroup', 'UIList', 'Header'):
        try:
            base = getattr(bpy.types, base_name, None)
            getter = getattr(base, 'bl_rna_get_subclass_py', None) if base is not None else None
            if callable(getter):
                existing = getter(bl_idname, None)
                if isinstance(existing, type):
                    return existing
        except Exception:
            pass
    try:
        if bl_idname and '.' in bl_idname:
            namespace, opname = bl_idname.split('.', 1)
            op_ns = getattr(bpy.ops, namespace, None)
            op_fn = getattr(op_ns, opname, None) if op_ns is not None else None
            get_rna_type = getattr(op_fn, 'get_rna_type', None)
            if callable(get_rna_type):
                try:
                    rna = get_rna_type()
                except Exception:
                    rna = None
                identifier = str(getattr(rna, 'identifier', '') or '').strip() if rna is not None else ''
                if identifier:
                    class_name = str(getattr(cls, '__name__', '') or '').strip()
                    candidates = {class_name}
                    opname_suffix = ''.join(ch if ch.isalnum() else '_' for ch in opname).strip('_')
                    if namespace and opname_suffix:
                        candidates.add(f'{namespace.upper()}_OT_{opname_suffix}')
                    if '_OT_' in class_name:
                        try:
                            _prefix, suffix = class_name.split('_OT_', 1)
                            if suffix:
                                candidates.add(f'{namespace.upper()}_OT_{suffix}')
                        except Exception:
                            pass
                    if identifier in candidates:
                        # Resolve the actual registered Python class.  Returning
                        # ``cls`` here is unsafe when another class with the same
                        # bl_idname is already registered: Blender then treats the
                        # source class as unregistered and register_class() silently
                        # replaces the live RNA type, which can invalidate open UI or
                        # modal operator pointers.
                        for base_name in ('Operator', 'Menu', 'Panel', 'AddonPreferences', 'PropertyGroup', 'Gizmo', 'GizmoGroup', 'UIList', 'Header'):
                            try:
                                base = getattr(bpy.types, base_name, None)
                                getter = getattr(base, 'bl_rna_get_subclass_py', None) if base is not None else None
                                existing = getter(identifier, None) if callable(getter) else None
                                if isinstance(existing, type):
                                    return existing
                            except Exception:
                                pass
                        try:
                            existing = getattr(bpy.types, identifier, None)
                            if isinstance(existing, type):
                                getattr(existing, 'bl_rna')
                                return existing
                        except Exception:
                            pass
    except Exception:
        pass
    return None


def _sms_patch_registered_class_namespace(existing, source) -> None:
    """Copy the executable Python namespace of *source* to live RNA *existing*.

    Lazy keymap proxies are registered before their real operators.  Replacing
    only Blender's standard callbacks (``invoke``/``execute``/...) is not
    sufficient: real operators may call private helpers, class methods or use
    class constants from those callbacks.  Missing helpers caused first-use
    failures such as Mesh Align's ``_open_fixed_width_popup`` AttributeError.

    RNA property declarations are deliberately excluded.  They are materialized
    when the RNA type is first registered and cannot be safely replaced while an
    operator instance may be alive.
    """
    try:
        source_dict = dict(getattr(source, '__dict__', {}) or {})
    except Exception:
        return
    try:
        annotation_names = set((source_dict.get('__annotations__') or {}).keys())
    except Exception:
        annotation_names = set()
    skip = {
        '__dict__', '__weakref__', '__module__', '__doc__', '__annotations__',
        '__slots__', 'bl_rna', 'rna_type',
        # Keep the live shell identifiable until it is explicitly destroyed at
        # the add-on lifecycle boundary.
        '_sms_lazy_keymap_proxy', '_sms_lazy_tool_id', '_sms_lazy_target_idname',
    }
    preserve_lazy_popup_draw = bool(getattr(existing, '_sms_lazy_popup_owner', False))
    for name, value in source_dict.items():
        if name in skip or name in annotation_names or name.startswith('__'):
            continue
        if preserve_lazy_popup_draw and name == 'draw':
            continue
        # Deferred bpy.props values are part of RNA registration, not ordinary
        # Python behavior, and must never be installed on an already-live type.
        try:
            if callable(getattr(value, 'function', None)) and hasattr(value, 'keywords'):
                continue
        except Exception:
            pass
        try:
            # Use the raw namespace value so classmethod/staticmethod/property
            # descriptors keep their descriptor semantics.
            setattr(existing, name, value)
        except Exception:
            pass


def _sms_patch_registered_class_in_place(existing, source) -> bool:
    if not (isinstance(existing, type) and isinstance(source, type)):
        return False
    if not _sms_class_is_owned_for_mutation(existing) or not _sms_exact_class_belongs_to_current_package(source):
        return False
    if _sms_panel_class_is_panel(existing):
        return _sms_patch_registered_panel_in_place(existing, source)
    try:
        source_dict = dict(getattr(source, '__dict__', {}) or {})
    except Exception:
        return False
    skip = {'__dict__', '__weakref__', '__module__', '__doc__', '__annotations__', '__slots__', 'bl_rna', 'rna_type'}
    for name, value in source_dict.items():
        if name in skip or name.startswith('__'):
            continue
        try:
            setattr(existing, name, value)
        except Exception:
            pass
    return True

def _sms_disable_resident_panel_class(cls) -> bool:
    return _sms_disable_exact_owned_panel_class(cls)

def _sms_panel_context_is_safe(context) -> bool:
    try:
        if _sms_rna_access_is_unsafe():
            return False
    except Exception:
        return False
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        unsafe_until = float((ns or {}).get('SMART_MODELING_SUITE_RNA_UNSAFE_UNTIL', 0.0) or 0.0) if isinstance(ns, dict) else 0.0
        if unsafe_until and time.monotonic() < unsafe_until:
            return False
    except Exception:
        return False
    try:
        if context is None:
            return False
        area = getattr(context, 'area', None)
        if area is not None and not _sms_area_type_can_host_npanel(getattr(area, 'type', None)):
            return False
        if getattr(context, 'window_manager', None) is None:
            return False
        if getattr(context, 'scene', None) is None:
            return False
        return True
    except Exception:
        return False


def _sms_is_view3d_ui_panel_class(cls) -> bool:
    try:
        panel_base = getattr(bpy.types, 'Panel', None)
        if panel_base is not None and not issubclass(cls, panel_base):
            return False
    except Exception:
        return False
    try:
        return str(getattr(cls, 'bl_space_type', '') or '') == 'VIEW_3D' and str(getattr(cls, 'bl_region_type', '') or '') == 'UI'
    except Exception:
        return False


def _sms_harden_panel_class_before_register(cls):
    """Guard VIEW_3D/UI panel classes against Blender 5.1 UI handler crashes.

    Blender 5.1 can crash in C-side panel handlers when a panel draw/poll runs
    during mode transitions or when an operator popup attempts to refresh stale
    RNA.  This wrapper keeps every suite-hosted sidebar panel from drawing when
    the context is incomplete and converts Python-side draw failures to a small
    warning row instead of letting the UI handler keep a bad panel state.
    """
    if not _sms_exact_class_belongs_to_current_package(cls):
        return cls
    if cls is None or not isinstance(cls, type) or not _sms_is_view3d_ui_panel_class(cls):
        return cls
    try:
        if not getattr(cls, '_sms_panel_poll_guarded_51', False):
            original_poll = cls.__dict__.get('poll', None)
            def _sms_guarded_poll(_cls, context):
                if not _sms_panel_context_is_safe(context):
                    return False
                if original_poll is None:
                    return True
                try:
                    func = getattr(original_poll, '__func__', original_poll)
                    return bool(func(_cls, context))
                except TypeError:
                    try:
                        return bool(original_poll(context))
                    except Exception:
                        return False
                except Exception:
                    return False
            cls.poll = classmethod(_sms_guarded_poll)
            setattr(cls, '_sms_panel_poll_guarded_51', True)
    except Exception:
        pass
    try:
        if not getattr(cls, '_sms_panel_draw_guarded_51', False):
            original_draw = cls.__dict__.get('draw', None)
            if callable(original_draw):
                try:
                    if not hasattr(cls, '_sms_original_draw_before_guard_51'):
                        setattr(cls, '_sms_original_draw_before_guard_51', original_draw)
                except Exception:
                    pass
                def _sms_guarded_draw(self, context):
                    if not _sms_panel_context_is_safe(context):
                        return
                    try:
                        return original_draw(self, context)
                    except Exception as exc:
                        try:
                            layout = getattr(self, 'layout', None)
                            if layout is not None:
                                box = layout.box()
                                box.alert = True
                                box.label(text=_pick_lang('This panel could not be drawn safely.', 'このパネルを安全に描画できませんでした。', context), icon='ERROR')
                                box.label(text=str(exc)[:180], icon='ERROR')
                        except Exception:
                            pass
                        return None
                cls.draw = _sms_guarded_draw
                setattr(cls, '_sms_panel_draw_guarded_51', True)
    except Exception:
        pass
    return cls


def _sms_purge_stale_smarttools_proxy_panels() -> int:
    if _sms_install_safe_phase_active():
        return 0
    return _sms_cleanup_stale_owned_classes(panels_only=True)


def _refresh_keymaps(context=None):
    """Smart Modeling does not modify Blender keymaps automatically."""
    return 0


_SMS_LAZY_UI_DIRTY_KEYS = set()
_SMS_LAZY_UI_SYNC_DEPTH = 0


def _sms_make_lazy_ui_update(prop_key: str):
    """Return a two-argument RNA update callback for one static UI proxy."""
    prop_key = str(prop_key or '')

    def _sms_lazy_ui_update(_self, _context):
        if int(globals().get('_SMS_LAZY_UI_SYNC_DEPTH', 0) or 0) <= 0 and prop_key:
            _SMS_LAZY_UI_DIRTY_KEYS.add(prop_key)

    _sms_lazy_ui_update.__name__ = f'_sms_lazy_ui_update_{prop_key}'
    return _sms_lazy_ui_update


def _sms_normalize_lazy_enum_items(items):
    normalized = []
    seen = set()
    for raw in tuple(items or ()):
        if not isinstance(raw, (tuple, list)) or len(raw) < 3:
            continue
        identifier = str(raw[0] or '')
        if not identifier or identifier in seen:
            continue
        seen.add(identifier)
        entry = tuple(raw[:5])
        normalized.append(entry)
    return tuple(normalized)


def _sms_build_lazy_ui_property(prop_key: str, schema):
    """Create one session-only RNA property from immutable generated metadata."""
    schema = dict(schema or {})
    factory_name = str(schema.get('factory') or '').strip()
    factory = getattr(bpy.props, factory_name, None)
    if not callable(factory):
        return None

    kwargs = dict(schema.get('kwargs') or {})
    options = set(kwargs.get('options') or ())
    options.add('SKIP_SAVE')
    kwargs['options'] = options
    kwargs['update'] = _sms_make_lazy_ui_update(prop_key)

    if factory_name == 'EnumProperty':
        items = _sms_normalize_lazy_enum_items(kwargs.get('items'))
        if not items:
            return None
        kwargs['items'] = items
        identifiers = tuple(str(item[0]) for item in items)
        if 'ENUM_FLAG' in options:
            default = kwargs.get('default', set())
            if isinstance(default, str):
                default = {default}
            elif isinstance(default, (tuple, list, set, frozenset)):
                default = set(default)
            else:
                default = set()
            kwargs['default'] = {str(value) for value in default if str(value) in identifiers}
        else:
            default = str(kwargs.get('default') or '')
            if default not in identifiers:
                kwargs['default'] = identifiers[0]

    if factory_name.endswith('VectorProperty'):
        try:
            size = max(1, int(kwargs.get('size', 3) or 3))
        except Exception:
            size = 3
        kwargs['size'] = size
        default = kwargs.get('default')
        if isinstance(default, (tuple, list)):
            values = list(default[:size])
            fill = False if factory_name == 'BoolVectorProperty' else 0
            values.extend([fill] * max(0, size - len(values)))
            kwargs['default'] = tuple(values)

    if factory_name in {'IntProperty', 'FloatProperty'}:
        default = kwargs.get('default')
        minimum = kwargs.get('min')
        maximum = kwargs.get('max')
        try:
            if default is not None and minimum is not None:
                default = max(default, minimum)
            if default is not None and maximum is not None:
                default = min(default, maximum)
            if default is not None:
                kwargs['default'] = default
        except Exception:
            pass

    try:
        return factory(**kwargs)
    except Exception:
        return None


def _sms_build_lazy_ui_annotations():
    annotations = {}
    for prop_key, schema in tuple(dict(_SMS_LAZY_UI_PROPERTY_SCHEMAS or {}).items()):
        deferred = _sms_build_lazy_ui_property(str(prop_key or ''), schema)
        if deferred is not None:
            annotations[str(prop_key)] = deferred
    return annotations


class SMS_LazyUISettings(bpy.types.PropertyGroup):
    """Session-only controls displayed before a feature package is registered."""

    bl_idname = 'SMS_LazyUISettings'
    __annotations__ = _sms_build_lazy_ui_annotations()


_SMS_SHARED_PREF_CLASSES = (
    SMS_LazyUISettings,
    SmartVertSlidePreferences,
    DIRECTDELETE_AddonPreferences,
    MO2_AddonPreferences,
    SMS_MSAP_AddonPreferencesProxy,
    SMS_CreasePresetItemProxy,
    SMS_CreasePresetPreferencesProxy,
    SMS_TAMS_CycleItemProxy,
    SMS_TAMS_PrefsProxy,
    SMS_AWN_AddonPreferencesProxy,
)


def _sms_is_shared_pref_class(cls) -> bool:
    try:
        if cls in _SMS_SHARED_PREF_CLASSES:
            return True
    except Exception:
        pass
    try:
        name = str(getattr(cls, '__name__', '') or '')
        return bool(name and any(str(getattr(pref_cls, '__name__', '') or '') == name for pref_cls in _SMS_SHARED_PREF_CLASSES))
    except Exception:
        return False


def _sms_shared_pref_class_registered(cls) -> bool:
    if not _sms_is_shared_pref_class(cls):
        return False
    try:
        return bool(hasattr(cls, 'bl_rna'))
    except Exception:
        return False


_SMS_NATIVE_MODULE_CACHE = {}


def _sms_native_module_from_meta(meta, *, require_loaded=False):
    if not isinstance(meta, dict):
        return None
    module = meta.get('module')
    if isinstance(module, types.ModuleType):
        return module
    tool_id = str(meta.get('tool_id') or '').strip()
    if require_loaded and tool_id and not _sms_native_tool_loaded(tool_id):
        return None
    module_path = str(meta.get('module_path') or '').strip()
    if not module_path:
        return None
    if _sms_is_panel_draw_active():
        return sys.modules.get(f'{__package__}.{module_path.lstrip(".")}')
    module = _sms_import_relative_module(module_path)
    if module is not None:
        meta['module'] = module
    return module



def _sms_has_live_smart_tools_hosts() -> bool:
    return False


def _sms_remove_all_suite_keymaps():
    """Automatic keymap cleanup is intentionally disabled."""
    return None
def _update_npanel_state_save(self, context):
    try:
        value = getattr(self, 'n_panel_state_save', True)
        if not isinstance(value, bool):
            value = True
        _sms_npanel_state_save_state_set(value, context=context, prefs=self)
    except Exception:
        pass
    try:
        _sms_tag_redraw_view3d_areas()
    except Exception:
        pass
    return None


def _update_suite_toggles(self, context):
    global _SMS_SUITE_TOGGLE_UPDATE_DEPTH
    _unload_generation_before = int(globals().get('_SMS_DYNAMIC_UNLOAD_GENERATION', 0) or 0)
    prefs = None
    runtime_state_changed = False
    try:
        prefs = _sms_get_suite_prefs(context)
        _sms_capture_suite_panel_settings(context=context, prefs=prefs)
        # Compare the actual resident switches with their authoritative snapshot.
        # A no-op RNA assignment (False -> False) must not unload independently
        # opened lazy settings.  Only a real switch transition is allowed to run
        # the resident-runtime synchronizer.
        try:
            snapshot = _sms_load_panel_settings_snapshot()
            states = snapshot.setdefault('persistent_toggle_state', {})
            if not isinstance(states, dict):
                states = {}
                snapshot['persistent_toggle_state'] = states
        except Exception:
            states = {}
        for _prop_name in tuple(_sms_persistent_toggle_prop_names()):
            try:
                if prefs is not None and _sms_rna_prop_exists(prefs, _prop_name):
                    _live_value = bool(_sms_safe_get_rna_attr(prefs, _prop_name, False))
                    if _prop_name not in states:
                        states[_prop_name] = _live_value
                        runtime_state_changed = runtime_state_changed or _live_value
                        _sms_schedule_panel_settings_save()
                    elif bool(states.get(_prop_name, False)) != _live_value:
                        states[_prop_name] = _live_value
                        runtime_state_changed = True
                        _sms_schedule_panel_settings_save()
            except Exception:
                pass
        _sms_flush_panel_settings_save()
    except Exception:
        pass
    try:
        _sms_schedule_userpref_save()
    except Exception:
        pass
    if runtime_state_changed and _SMS_PERSISTENT_TOGGLE_SYNC_DEPTH <= 0 and _SMS_SUITE_TOGGLE_UPDATE_DEPTH <= 0:
        _SMS_SUITE_TOGGLE_UPDATE_DEPTH += 1
        try:
            try:
                _sms_update_persistent_tool_runtime_from_prefs(context)
            except Exception:
                pass
        finally:
            _SMS_SUITE_TOGGLE_UPDATE_DEPTH = max(0, _SMS_SUITE_TOGGLE_UPDATE_DEPTH - 1)
    root_mod = sys.modules.get(str(__package__ or '').strip())
    if root_mod is not None:
        try:
            schedule = getattr(root_mod, '_stx_schedule_apply', None)
            if callable(schedule):
                schedule(first_interval=0.05, reset_attempts=True)
        except Exception:
            pass
        try:
            refresh = getattr(root_mod, '_stx_try_refresh_ui', None)
            if callable(refresh):
                refresh(context)
        except Exception:
            pass
    try:
        _sms_cleanup_legacy_idle_resources_if_all_off(context, prefs_override=self)
    except Exception:
        pass
    # Enabling a centralized tool can materialize additional RNA after the
    # initial suite snapshot.  Capture it at that registration boundary so all
    # newly available N-panel settings already exist in the canonical JSON.
    if int(globals().get('_SMS_DYNAMIC_UNLOAD_GENERATION', 0) or 0) == _unload_generation_before:
        try:
            from . import common as _sms_common
            sync = getattr(_sms_common, 'sync_persistence_subscriptions', None)
            save = getattr(_sms_common, 'save_persistent_settings', None)
            if callable(sync):
                sync(context)
            if callable(save):
                save(context, force=False)
        except Exception:
            pass
    return None


def _sms_set_archimesh_hint_overlay(enabled: bool, context=None) -> None:
    """Synchronize the canonical Archimesh viewport-hint resident switch."""
    context = context or getattr(bpy, 'context', None)
    enabled = bool(enabled)
    panel_module = None
    if enabled:
        try:
            _sms_ensure_integrated_tool_loaded('archimesh', context=context)
        except Exception:
            pass
    panel_name = f'{__package__}.archimesh.achm_main_panel'
    panel_module = sys.modules.get(panel_name)
    if enabled and panel_module is None:
        try:
            panel_module = importlib.import_module(panel_name)
        except Exception:
            panel_module = None
    operator_cls = getattr(panel_module, 'ARCHIMESH_OT_HintDisplay', None) if panel_module is not None else None
    try:
        if operator_cls is not None:
            if enabled:
                operator_cls.handle_add(operator_cls, context)
            else:
                operator_cls.handle_remove(operator_cls, context)
    except Exception:
        if enabled:
            # A missing drawable View3D context must never leave a misleading
            # enabled resident state behind.
            try:
                prefs = _sms_get_suite_prefs(context)
                if prefs is not None and bool(getattr(prefs, 'enable_archimesh_hint_overlay', False)):
                    prefs['enable_archimesh_hint_overlay'] = False
            except Exception:
                pass
    if not enabled:
        try:
            wm = getattr(context, 'window_manager', None)
            if wm is not None and hasattr(wm, 'archimesh_run_opengl'):
                wm.archimesh_run_opengl = False
        except Exception:
            pass


def _update_archimesh_hint_overlay(self, context):
    _update_suite_toggles(self, context)
    try:
        enabled = bool(getattr(self, 'enable_archimesh_hint_overlay', False))
    except Exception:
        enabled = False
    _sms_set_archimesh_hint_overlay(enabled, context)


def _sms_finalize_lazy_settings_timer():
    """Finish one lazy-tool registration without leaving an idle service."""
    ctx = getattr(bpy, 'context', None)
    prefs = None
    try:
        wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
        prefs = getattr(wm, _SMS_NPANEL_SETTINGS_PROP, None) if wm is not None else None
    except Exception:
        prefs = None
    try:
        _sms_cleanup_legacy_idle_resources_if_all_off(ctx, prefs_override=prefs)
    except Exception:
        pass
    try:
        from . import common as _sms_common
        sync = getattr(_sms_common, 'sync_persistence_subscriptions', None)
        save = getattr(_sms_common, 'save_persistent_settings', None)
        if callable(sync):
            sync(ctx)
        if callable(save):
            save(ctx, force=False)
    except Exception:
        pass
    return None


def _sms_get_suite_prefs(context=None):
    if _sms_rna_access_is_unsafe():
        return None
    ctx = context or getattr(bpy, 'context', None)

    def _read_from_window_manager(candidate):
        try:
            wm = getattr(candidate, 'window_manager', None)
        except Exception:
            wm = None
        if wm is None:
            return None
        prefs = _sms_safe_get_rna_attr(wm, _SMS_NPANEL_SETTINGS_PROP, None)
        if prefs is not None and _sms_rna_data_is_current(prefs):
            return prefs
        return None

    for candidate in (ctx, getattr(bpy, 'context', None)):
        prefs = _read_from_window_manager(candidate)
        if prefs is not None:
            return prefs

    # Never repair or recreate the WindowManager PointerProperty from a getter.
    # On Blender 5.1.0 Windows, stale/recreated PointerProperty access during
    # startup/panel callbacks can crash in RNA_struct_find_property or
    # rna_pointer_create_with_ancestors before Python can handle the exception.
    return None


def _sms_ui_lang(context=None) -> str:
    try:
        prefs = getattr(context or bpy.context, "preferences", None)
        view = getattr(prefs, "view", None) if prefs else None
        lang = getattr(view, "language", "") if view else ""
        return "ja" if str(lang or "").startswith("ja") else "en"
    except Exception:
        return "en"


def _sms_compact_n_panel_enabled(context=None) -> bool:
    # The old compact child panels are no longer registered as independent
    # N-panel sections. Their contents are hosted inside the unified
    # Smart Modeling list, grouped by runtime behavior.
    return False


def _sms_legacy_panels_enabled(context=None) -> bool:
    return False


def _sms_any_enabled(context, *keys) -> bool:
    for key in keys:
        try:
            if _sms_enabled(context, key, True):
                return True
        except Exception:
            continue
    return False


def _sms_wrap_panel_poll(panel_cls):
    if not _sms_class_is_owned_for_mutation(panel_cls):
        return
    if panel_cls is None or getattr(panel_cls, "_sms_poll_wrapped", False):
        return
    orig_poll = getattr(panel_cls, "poll", None)
    try:
        panel_cls._smart_tools_proxy_orig_poll = orig_poll
    except Exception:
        pass

    @classmethod
    def _wrapped_poll(cls, context):
        if not _sms_legacy_panels_enabled(context):
            return False
        if orig_poll is None:
            return True
        try:
            return bool(orig_poll(context))
        except TypeError:
            try:
                return bool(orig_poll(cls, context))
            except Exception:
                return False
        except Exception:
            return False

    try:
        panel_cls.poll = _wrapped_poll
        panel_cls._sms_poll_wrapped = True
    except Exception:
        pass




def _sms_iter_legacy_panel_classes():
    panels = []
    seen = set()
    for meta in _sms_tool_meta_entries():
        tool_id = str(meta.get('tool_id') or '')
        if not _sms_native_tool_loaded(tool_id):
            continue
        record = _sms_native_tool_record(tool_id)
        record_panels = tuple(record.get('panels') or ())
        for cls in record_panels:
            if cls is None or cls in seen:
                continue
            seen.add(cls)
            panels.append(cls)
    return panels


def _sms_wrap_legacy_panel_polls():
    for panel_cls in _sms_iter_legacy_panel_classes():
        _sms_wrap_panel_poll(panel_cls)




def _sms_properties_panel_classes():
    panels = list(_sms_wrapper_panel_classes())
    panels.extend(tuple(_SMS_NATIVE_ACCESS_PANEL_CLASSES))
    panels.extend(_sms_modifier_workspace_panel_classes())
    panels.extend(_sms_iter_legacy_panel_classes())
    ordered = []
    seen = set()
    for cls in panels:
        if cls is None or cls in seen:
            continue
        seen.add(cls)
        ordered.append(cls)
    return ordered


def _sms_prepare_properties_panels():
    try:
        return tuple(_sms_properties_panel_classes())
    except Exception:
        return tuple(_sms_wrapper_panel_classes())


def _sms_install_standard_n_panel():
    _sms_purge_stale_smarttools_proxy_panels()
    try:
        _sms_purge_non_root_smart_modeling_panels()
    except Exception:
        pass
    _sms_tag_redraw_view3d_areas()
    return True


def _sms_uninstall_standard_n_panel():
    _sms_purge_stale_smarttools_proxy_panels()
    try:
        _sms_purge_non_root_smart_modeling_panels()
    except Exception:
        pass
    _sms_tag_redraw_view3d_areas()
    return True


_SMS_RUNTIME_REFRESH_ACTIVE = False
_SMS_RUNTIME_REFRESH_GENERATION = 0
_SMS_RUNTIME_REFRESH_SCHEDULED = False
_SMS_RUNTIME_REFRESH_TIMER = None
_SMS_FILE_LOAD_ACTIVE = False
_SMS_RNA_UNSAFE_UNTIL = 0.0
_SMS_LOAD_POST_RESTORE_PENDING = False
_SMS_LOAD_POST_RESTORE_ATTEMPTS = 0
_SMS_SETTINGS_AUTOSAVE_TIMER_ENABLED = False
_SMS_STARTUP_ALWAYS_ON_SYNC_ATTEMPTS = 0


def _sms_install_safe_phase_active() -> bool:
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if isinstance(ns, dict) and bool(ns.get('SMART_MODELING_SUITE_SAFE_INSTALLING', False)):
            return True
    except Exception:
        return True
    try:
        return _sms_rna_access_is_unsafe()
    except Exception:
        return True


def _sms_rna_access_is_unsafe() -> bool:
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if isinstance(ns, dict) and bool(ns.get('SMART_MODELING_SUITE_SAFE_INSTALLING', False)):
            return True
    except Exception:
        return True
    try:
        if bool(_SMS_FILE_LOAD_ACTIVE):
            return True
    except Exception:
        return True
    try:
        return time.monotonic() < float(_SMS_RNA_UNSAFE_UNTIL or 0.0)
    except Exception:
        return False


def _sms_refresh_standard_n_panel_once():
    _sms_purge_stale_smarttools_proxy_panels()
    try:
        _sms_purge_non_root_smart_modeling_panels()
    except Exception:
        pass
    _sms_tag_redraw_view3d_areas()
    return True


def _sms_cancel_standard_n_panel_refresh_timer():
    global _SMS_RUNTIME_REFRESH_TIMER, _SMS_RUNTIME_REFRESH_SCHEDULED
    timer = _SMS_RUNTIME_REFRESH_TIMER
    _SMS_RUNTIME_REFRESH_TIMER = None
    if timer is None:
        return
    try:
        is_registered = getattr(bpy.app.timers, 'is_registered', None)
        if callable(is_registered):
            if is_registered(timer):
                bpy.app.timers.unregister(timer)
        else:
            bpy.app.timers.unregister(timer)
    except Exception:
        pass
    _SMS_RUNTIME_REFRESH_SCHEDULED = False


def _sms_schedule_standard_n_panel_refresh():
    global _SMS_RUNTIME_REFRESH_SCHEDULED, _SMS_RUNTIME_REFRESH_TIMER
    _SMS_RUNTIME_REFRESH_SCHEDULED = False
    _SMS_RUNTIME_REFRESH_TIMER = None
    _sms_refresh_standard_n_panel_once()
    return None

@persistent
def _sms_save_pre_capture_settings(_dummy):
    if not _sms_runtime_active() or _sms_rna_access_is_unsafe():
        return
    try:
        _sms_capture_suite_panel_settings(context=getattr(bpy, 'context', None), prefs=_sms_get_suite_prefs(getattr(bpy, 'context', None)))
    except Exception:
        pass
    try:
        _sms_flush_panel_settings_save(force=True)
    except Exception:
        pass


def _sms_stop_known_transient_draw_handlers() -> None:
    """Stop preview/overlay draw handlers owned by already-loaded suite modules."""
    for module_suffix, function_names in (
        ('connect', ('_smart_connect_preview_stop',)),
        ('direct_delete.preview', ('remove_handler',)),
        ('vertex_copy.core', ('_remove_gpu_draw_handler',)),
        ('vertex_copy.extension', ('_remove_ext_draw_handler',)),
        ('vertex_copy.extension_lines', ('_remove_lines_draw_handler',)),
    ):
        try:
            module_name = f'{__package__}.{module_suffix}' if __package__ else module_suffix
            module = sys.modules.get(module_name)
            if module is None:
                continue
            for function_name in function_names:
                fn = getattr(module, function_name, None)
                if callable(fn):
                    try:
                        fn()
                    except Exception:
                        pass
        except Exception:
            pass


def _sms_reset_transient_scene_runtime_state(context=None) -> None:
    """Reset live scene toggles outside file-load/RNA-unsafe phases only."""
    if _sms_rna_access_is_unsafe():
        try:
            _sms_stop_known_transient_draw_handlers()
        except Exception:
            pass
        return
    try:
        ctx = context or getattr(bpy, 'context', None)
        scene = getattr(ctx, 'scene', None) if ctx is not None else None
        if scene is not None:
            for prop_name in ('svs_vertex_slide_constraint_enabled', 'qsd_draw_toggle'):
                try:
                    if prop_name in getattr(scene, 'keys', lambda: ())():
                        pass
                except Exception:
                    pass
                try:
                    setattr(scene, prop_name, False)
                except Exception:
                    pass
        try:
            for module_suffix in ('quad_strip_draw.common', 'quad_strip_draw'):
                module_name = f'{__package__}.{module_suffix}' if __package__ else module_suffix
                module = sys.modules.get(module_name)
                fn = getattr(module, '_wm_set_stop_requested', None) if module is not None else None
                if callable(fn) and ctx is not None:
                    try:
                        fn(ctx, True)
                    except Exception:
                        pass
        except Exception:
            pass
    except Exception:
        pass
    _sms_stop_known_transient_draw_handlers()


@persistent
def _sms_load_pre_runtime_safety(_dummy):
    global _SMS_FILE_LOAD_ACTIVE, _SMS_RNA_UNSAFE_UNTIL
    # Scene/file close begins here.  Do not read Blender RNA in this callback;
    # Windows Blender 5.1 can have partially invalid WindowManager/Panel owners.
    # Event callbacks have already committed allowed changes.  This safety
    # callback therefore performs no settings collection or persistence.
    _SMS_FILE_LOAD_ACTIVE = True
    try:
        _SMS_RNA_UNSAFE_UNTIL = time.monotonic() + 1.25
        try:
            ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
            if isinstance(ns, dict):
                ns['SMART_MODELING_SUITE_RNA_UNSAFE_UNTIL'] = _SMS_RNA_UNSAFE_UNTIL
        except Exception:
            pass
    except Exception:
        _SMS_RNA_UNSAFE_UNTIL = 0.0
    try:
        _sms_cancel_standard_n_panel_refresh_timer()
    except Exception:
        pass
    try:
        _sms_cancel_on_demand_loads()
    except Exception:
        pass


def _sms_load_post_restore_timer():
    global _SMS_LOAD_POST_RESTORE_PENDING, _SMS_LOAD_POST_RESTORE_ATTEMPTS
    # Preserve only edits that happened after load_post.  Blender materializes
    # FloatVectorProperty defaults while rebuilding WindowManager RNA; those
    # automatic callbacks must never be mistaken for user-edited pre-load UI.
    _lazy_dirty_before_restore = set(_SMS_LAZY_UI_DIRTY_KEYS)
    if not _sms_runtime_active():
        _SMS_LOAD_POST_RESTORE_PENDING = False
        _SMS_LOAD_POST_RESTORE_ATTEMPTS = 0
        return None
    if _sms_rna_access_is_unsafe():
        _SMS_LOAD_POST_RESTORE_ATTEMPTS += 1
        # In normal Blender timing this reaches a safe context after two or
        # three half-second ticks.  Keep the retry finite for background/manual
        # event loops that do not advance wall-clock time between callbacks.
        if _SMS_LOAD_POST_RESTORE_ATTEMPTS < 6:
            return 0.5
    _SMS_LOAD_POST_RESTORE_PENDING = False
    _SMS_LOAD_POST_RESTORE_ATTEMPTS = 0
    ctx = getattr(bpy, 'context', None)
    try:
        _sms_load_panel_settings_snapshot()
    except Exception:
        pass
    try:
        from . import common as _sms_common
        load_fn = getattr(_sms_common, 'load_settings_file', None)
        apply_fn = getattr(_sms_common, 'apply_persistent_settings', None)
        if callable(load_fn):
            load_fn()
        if callable(apply_fn):
            apply_fn(ctx)
    except Exception:
        pass
    try:
        # Do not detach or recreate the WindowManager PointerProperty from a
        # delayed load-post timer.  Existing UI/RNA holders may still refer to the
        # current object, so only restore when the current pointer is already
        # valid.  Panel draw can repair storage later if needed.
        prefs = _sms_get_suite_prefs(ctx)
    except Exception:
        prefs = None
    prefs_synchronized = False
    try:
        if prefs is not None:
            _sms_restore_suite_panel_settings(ctx, prefs)
            _sms_sync_persistent_toggle_snapshot_to_prefs(context=ctx, prefs=prefs)
            prefs_synchronized = True
    except Exception:
        prefs_synchronized = False
    _sms_set_npanel_preferences_synchronized(prefs_synchronized)
    try:
        _sms_update_persistent_tool_runtime_from_prefs(ctx)
    except Exception:
        pass
    try:
        _sms_force_load_enabled_persistent_tools(ctx)
    except Exception:
        pass
    try:
        _sms_refresh_standard_n_panel_once()
    except Exception:
        pass
    _SMS_LAZY_UI_DIRTY_KEYS.clear()
    _SMS_LAZY_UI_DIRTY_KEYS.update(_lazy_dirty_before_restore)
    return None


def _sms_schedule_load_post_restore(delay=0.5):
    global _SMS_LOAD_POST_RESTORE_PENDING, _SMS_LOAD_POST_RESTORE_ATTEMPTS
    _SMS_LOAD_POST_RESTORE_PENDING = True
    _SMS_LOAD_POST_RESTORE_ATTEMPTS = 0
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is None:
            return
        if hasattr(timers, 'is_registered') and timers.is_registered(_sms_load_post_restore_timer):
            return
        timers.register(_sms_load_post_restore_timer, first_interval=float(delay))
    except Exception:
        pass



def _sms_periodic_settings_autosave_timer():
    """Retire a legacy periodic autosave callback after one bounded flush.

    Smart Modeling now saves through explicit property/update, save, load and
    unregister boundaries.  This callback remains only so an exact callback left
    by an interrupted older generation self-terminates when Blender invokes it.
    """
    global _SMS_SETTINGS_AUTOSAVE_TIMER_ENABLED
    _SMS_SETTINGS_AUTOSAVE_TIMER_ENABLED = False
    if not _sms_runtime_active() or _sms_rna_access_is_unsafe():
        return None
    if not bool(globals().get('_SMS_PANEL_SETTINGS_DIRTY', False)
                or globals().get('_SMS_PANEL_SETTINGS_SAVE_PENDING', False)):
        return None
    ctx = getattr(bpy, 'context', None)
    try:
        prefs = _sms_get_suite_prefs(ctx)
        if prefs is not None:
            _sms_capture_suite_panel_settings(context=ctx, prefs=prefs)
    except Exception:
        pass
    try:
        _sms_flush_panel_settings_save(force=True)
    except Exception:
        pass
    try:
        from . import common as _sms_common
        save_fn = getattr(_sms_common, 'save_persistent_settings', None)
        if callable(save_fn):
            save_fn(ctx, force=False)
    except Exception:
        pass
    return None



def _sms_register_settings_autosave_timer():
    """Compatibility no-op: continuous settings polling is prohibited."""
    global _SMS_SETTINGS_AUTOSAVE_TIMER_ENABLED
    _SMS_SETTINGS_AUTOSAVE_TIMER_ENABLED = False
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_sms_periodic_settings_autosave_timer):
            timers.unregister(_sms_periodic_settings_autosave_timer)
    except Exception:
        pass
    return None



def _sms_unregister_settings_autosave_timer():
    global _SMS_SETTINGS_AUTOSAVE_TIMER_ENABLED
    _SMS_SETTINGS_AUTOSAVE_TIMER_ENABLED = False
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_sms_periodic_settings_autosave_timer):
            timers.unregister(_sms_periodic_settings_autosave_timer)
    except Exception:
        pass



@persistent
def _sms_undo_redo_pre_runtime_safety(_dummy):
    if not _sms_runtime_active() or _sms_rna_access_is_unsafe():
        return
    try:
        _sms_reset_transient_scene_runtime_state(getattr(bpy, 'context', None))
    except Exception:
        pass


@persistent
def _sms_exit_pre_runtime_safety(_dummy):
    try:
        if not _sms_rna_access_is_unsafe():
            _sms_reset_transient_scene_runtime_state(getattr(bpy, 'context', None))
    except Exception:
        pass


@persistent
def _sms_load_post_runtime_refresh(_dummy):
    global _SMS_FILE_LOAD_ACTIVE, _SMS_RNA_UNSAFE_UNTIL, _SMS_RUNTIME_REFRESH_ACTIVE
    # Blender replaced bpy.app.driver_namespace with a fresh dict during this
    # load (measured on 5.1.2 ec6e62d40fa9).  Re-publish this package's
    # anchored process state FIRST, before anything below reads or writes the
    # namespace: without it the exact-class ownership ledger is gone and the
    # next unregister() removes 0 classes, stranding every PropertyGroup.
    # rearm_process_namespace_state() never raises.
    try:
        _sms_rearm_process_namespace_state()
    except Exception:
        pass
    # The session-only static UI proxy is recreated during file load.  Discard
    # its automatic default-update callbacks before any real user interaction.
    _SMS_LAZY_UI_DIRTY_KEYS.clear()
    _sms_set_npanel_preferences_synchronized(False)
    _SMS_FILE_LOAD_ACTIVE = False
    _SMS_RUNTIME_REFRESH_ACTIVE = True
    try:
        _sms_set_runtime_token()
    except Exception:
        pass
    try:
        _SMS_RNA_UNSAFE_UNTIL = time.monotonic() + 1.25
        try:
            ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
            if isinstance(ns, dict):
                ns['SMART_MODELING_SUITE_RNA_UNSAFE_UNTIL'] = _SMS_RNA_UNSAFE_UNTIL
        except Exception:
            pass
    except Exception:
        _SMS_RNA_UNSAFE_UNTIL = 0.0
    try:
        _sms_cancel_standard_n_panel_refresh_timer()
    except Exception:
        pass
    try:
        _sms_cancel_on_demand_loads()
    except Exception:
        pass
    # Restore JSON-backed N-panel values after Blender's file-load RNA has
    # stabilized.  This keeps always-on toggles consistent across scene opens
    # without touching RNA inside load_post itself.  Also schedule the standalone
    # startup sync so enabled tools are loaded even if preferences restoration is
    # skipped by Blender during file open.
    _sms_schedule_load_post_restore(delay=0.35)
    try:
        _sms_schedule_startup_always_on_sync(delay=0.35)
    except Exception:
        pass
    try:
        from . import common as _sms_common
        _sms_common.apply_persistent_settings(getattr(bpy, 'context', None))
    except Exception:
        pass
    _SMS_LAZY_UI_DIRTY_KEYS.clear()


_SMS_RUNTIME_HANDLER_RECEIPTS = []


def _sms_lifecycle_safety_handler_specs():
    return (
        ('load_pre', _sms_load_pre_runtime_safety),
        ('load_post', _sms_load_post_runtime_refresh),
        ('exit_pre', _sms_exit_pre_runtime_safety),
    )


def _sms_persistence_handler_specs():
    return (
        ('save_pre', _sms_save_pre_capture_settings),
    )


def _sms_runtime_handler_specs():
    return _sms_lifecycle_safety_handler_specs() + _sms_persistence_handler_specs()


def _sms_remove_exact_handler(collection, handler) -> int:
    removed = 0
    try:
        for index in range(len(collection) - 1, -1, -1):
            if collection[index] is handler:
                collection.pop(index)
                removed += 1
    except Exception:
        pass
    return removed


def _sms_register_handler_specs(specs):
    """Register exact current-generation handlers without stale-name scanning.

    Ownership is the exact list/callback pair recorded in
    ``_SMS_RUNTIME_HANDLER_RECEIPTS`` and in the package-level generation
    receipt.  Similar names, module strings, and foreign callbacks are ignored.
    """
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    if handlers is None:
        return
    added_callbacks = []
    added_receipts = []
    for collection_name, handler in tuple(specs):
        collection = getattr(handlers, collection_name, None)
        if not isinstance(collection, list):
            continue
        try:
            if not any(callback is handler for callback in tuple(collection)):
                collection.append(handler)
                added_callbacks.append((collection, handler))
            if not any(
                recorded_name == collection_name and recorded_collection is collection and recorded_handler is handler
                for recorded_name, recorded_collection, recorded_handler in tuple(_SMS_RUNTIME_HANDLER_RECEIPTS)
            ):
                receipt = (collection_name, collection, handler)
                _SMS_RUNTIME_HANDLER_RECEIPTS.append(receipt)
                added_receipts.append(receipt)
        except Exception:
            # Roll back only callbacks already added by this exact attempt.
            for receipt in reversed(added_receipts):
                try:
                    _SMS_RUNTIME_HANDLER_RECEIPTS.remove(receipt)
                except Exception:
                    pass
            for added_collection, added_handler in reversed(added_callbacks):
                _sms_remove_exact_handler(added_collection, added_handler)
            raise


def _sms_unregister_handler_specs(specs):
    exact_specs = tuple(specs)
    exact_keys = {(collection_name, handler) for collection_name, handler in exact_specs}
    # Reverse exact receipts first.  A small exact-identity fallback handles a
    # repeated register call in the same module generation before the receipt
    # list was committed; it cannot match a foreign callback.
    retained = []
    for collection_name, collection, handler in tuple(_SMS_RUNTIME_HANDLER_RECEIPTS):
        if (collection_name, handler) in exact_keys:
            _sms_remove_exact_handler(collection, handler)
        else:
            retained.append((collection_name, collection, handler))
    _SMS_RUNTIME_HANDLER_RECEIPTS[:] = retained

    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    if handlers is None:
        return
    for collection_name, handler in exact_specs:
        collection = getattr(handlers, collection_name, None)
        if isinstance(collection, list):
            _sms_remove_exact_handler(collection, handler)


def _sms_register_runtime_handlers():
    _sms_unregister_runtime_handlers()
    _sms_register_handler_specs(_sms_runtime_handler_specs())


def _sms_unregister_runtime_handlers():
    global _SMS_LOAD_POST_RESTORE_PENDING
    _SMS_LOAD_POST_RESTORE_PENDING = False
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_sms_load_post_restore_timer):
            timers.unregister(_sms_load_post_restore_timer)
    except Exception:
        pass
    _sms_unregister_handler_specs(_sms_runtime_handler_specs())


def _sms_sync_settings_resident_resources(enabled: bool) -> None:
    """Keep lifecycle safety resident; gate persistence-only resources."""
    _sms_register_handler_specs(_sms_lifecycle_safety_handler_specs())
    if bool(enabled):
        _sms_register_handler_specs(_sms_persistence_handler_specs())
    else:
        _sms_unregister_handler_specs(_sms_persistence_handler_specs())


class SMS_OT_copy_to_clipboard(bpy.types.Operator):
    """Copy helper for Smart Modeling UI."""
    bl_idname = "smart_modeling_suite.copy_to_clipboard"
    bl_label = "Copy"
    bl_description = "Copy the displayed registration ID to the system clipboard."
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    text: StringProperty(description="Internal helper text that will be copied to the system clipboard.", default="", options={'SKIP_SAVE'})
    report_label: StringProperty(description="Short label used in the copy completion report.", default="", options={'SKIP_SAVE'})

    def execute(self, context):
        wm = getattr(context, 'window_manager', None)
        if wm is None:
            self.report({'ERROR'}, _pick_lang('Clipboard is not available.', 'クリップボードを使用できません。', context))
            return {'CANCELLED'}
        try:
            wm.clipboard = str(self.text or '')
        except Exception as exc:
            self.report({'ERROR'}, _pick_lang(f'Copy failed: {exc}', f'コピーに失敗しました: {exc}', context))
            return {'CANCELLED'}
        label = str(self.report_label or self.text or '').strip()
        self.report({'INFO'}, f"{_pick_lang('Copied', 'コピーしました', context)}: {label}" if label else _pick_lang('Copied', 'コピーしました', context))
        return {'FINISHED'}


def _sms_redraw_after_section_toggle(context=None) -> None:
    try:
        _sms_restore_known_panel_settings(context or getattr(bpy, 'context', None))
    except Exception:
        pass
    try:
        _sms_rebuild_native_tool_records()
    except Exception:
        pass
    try:
        _sms_tag_redraw_view3d_areas()
    except Exception:
        try:
            _sms_tag_redraw_all_areas()
        except Exception:
            pass



def _sms_section_key_tool_ref(section_key: str) -> tuple[str, str]:
    section_key = str(section_key or '').strip()
    if not section_key:
        return '', ''
    try:
        native_map = {str(value): str(key) for key, value in dict(_SMS_NATIVE_SHOW_PROP_MAP).items()}
    except Exception:
        native_map = {}
    tool_id = native_map.get(section_key, '')
    if tool_id:
        return 'native', tool_id
    prefix = 'ui_show_tool_'
    if section_key.startswith(prefix):
        alias = section_key[len(prefix):].strip()
        if alias:
            return 'integrated', alias
    prefix = 'ui_show_suite_panel_'
    if section_key.startswith(prefix):
        item_id = section_key[len(prefix):].strip()
        if item_id:
            return 'suite_panel', item_id
    return '', ''


def _sms_tool_enable_prop(kind: str, alias: str) -> str:
    kind = str(kind or '').strip()
    alias = str(alias or '').strip()
    if not kind or not alias:
        return ''
    if kind == 'native':
        try:
            return str((_sms_native_tool_meta(alias) or {}).get('toggle') or '').strip()
        except Exception:
            return ''
    if kind == 'integrated':
        return _sms_integrated_enable_prop(alias)
    if kind == 'suite_panel':
        for spec in tuple(globals().get('_SMS_ALWAYS_ON_TOOL_SPECS', ())):
            if str((spec or {}).get('kind') or '') == 'suite_panel' and str((spec or {}).get('id') or '') == alias:
                return str((spec or {}).get('enable_prop') or '').strip()
    return ''


def _sms_tool_show_prop(kind: str, alias: str) -> str:
    kind = str(kind or '').strip()
    alias = str(alias or '').strip()
    if not kind or not alias:
        return ''
    if kind == 'native':
        return str(_SMS_NATIVE_SHOW_PROP_MAP.get(alias, f'ui_show_{alias}') or '').strip()
    if kind == 'integrated':
        return f'ui_show_tool_{alias}'
    if kind == 'suite_panel':
        return f'ui_show_suite_panel_{alias}'
    return ''


def _sms_collapse_tool_settings(kind: str, alias: str, *, context=None, prefs=None) -> None:
    show_prop = _sms_tool_show_prop(kind, alias)
    if not show_prop:
        return
    try:
        _sms_ui_section_state_set(show_prop, False, context=context, prefs=prefs or _sms_get_suite_prefs(context or getattr(bpy, 'context', None)))
    except Exception:
        pass


def _sms_tool_switch_enabled(kind: str, alias: str, *, context=None, prefs=None, default=False) -> bool:
    prop_name = _sms_tool_enable_prop(kind, alias)
    if not prop_name:
        return bool(default)
    return _sms_persistent_toggle_state_get(prop_name, context=context, prefs=prefs, default=default)


def _sms_deactivate_tool_runtime(kind: str, alias: str, *, context=None, unload=True) -> None:
    global _SMS_DYNAMIC_UNLOAD_GENERATION
    kind = str(kind or '').strip()
    alias = str(alias or '').strip()
    if not kind or not alias:
        return
    try:
        _sms_cancel_pending_tool_load(kind, alias)
    except Exception:
        pass
    try:
        _sms_seed_runtime_feature_state(alias, False)
    except Exception:
        pass
    try:
        _sms_set_integrated_runtime_features(alias, False)
    except Exception:
        pass
    if kind == 'native':
        try:
            _sms_deactivate_known_native_background_hooks(alias)
        except Exception:
            pass
        try:
            _sms_unregister_lazy_keymap_proxies_for_tool(alias)
        except Exception:
            pass
        if unload:
            _SMS_DYNAMIC_UNLOAD_GENERATION += 1
            try:
                _sms_unload_native_tool(alias, context=context, keep_registered_safe=(alias in {'direct_delete', 'vertex_slide'}))
            except TypeError:
                try:
                    _sms_unload_native_tool(alias, context=context)
                except Exception:
                    pass
            except Exception:
                pass
    elif kind == 'integrated':
        if unload:
            _SMS_DYNAMIC_UNLOAD_GENERATION += 1
            try:
                _sms_loader = sys.modules.get(f'{__package__}.loader')
                if _sms_loader is not None:
                    _sms_loader.unload(alias)
            except Exception:
                pass
    elif kind == 'suite_panel':
        if alias == 'modifier_companion':
            try:
                prefs = _sms_get_suite_prefs(context or getattr(bpy, 'context', None))
                if prefs is not None and _sms_rna_prop_exists(prefs, 'ui_activate_suite_panel_modifier_companion'):
                    _sms_safe_set_rna_attr(prefs, 'ui_activate_suite_panel_modifier_companion', False)
            except Exception:
                pass


def _sms_start_tool_runtime(kind: str, alias: str, *, context=None) -> None:
    kind = str(kind or '').strip()
    alias = str(alias or '').strip()
    if not kind or not alias:
        return
    try:
        _sms_seed_runtime_feature_state(alias, True)
    except Exception:
        pass
    if kind == 'native':
        try:
            _sms_ensure_native_tool_loaded(alias, context=context)
        except Exception:
            pass
        try:
            _sms_set_integrated_runtime_features(alias, True)
        except Exception:
            pass
        try:
            _sms_activate_known_native_background_hooks(alias)
        except Exception:
            pass
    elif kind == 'integrated':
        try:
            _sms_ensure_integrated_tool_loaded(alias, context=context)
        except Exception:
            pass
        try:
            _sms_set_integrated_runtime_features(alias, True)
        except Exception:
            pass
    elif kind == 'suite_panel':
        try:
            prefs = _sms_get_suite_prefs(context or getattr(bpy, 'context', None))
            if alias == 'all_commands' and prefs is not None:
                _sms_ui_section_state_set('ui_show_suite_panel_all_commands', True, context=context, prefs=prefs)
            elif alias == 'modifier_companion' and prefs is not None:
                if _sms_rna_prop_exists(prefs, 'ui_activate_suite_panel_modifier_companion'):
                    _sms_safe_set_rna_attr(prefs, 'ui_activate_suite_panel_modifier_companion', True)
        except Exception:
            pass


def _sms_unload_disabled_tool_for_section_key(context, section_key: str) -> None:
    kind, alias = _sms_section_key_tool_ref(section_key)
    if not kind or not alias:
        return
    prefs = _sms_get_suite_prefs(context)
    if _sms_tool_switch_enabled(kind, alias, context=context, prefs=prefs, default=False):
        return
    _sms_deactivate_tool_runtime(kind, alias, context=context, unload=True)


def _sms_load_tool_for_section_key(context, section_key: str) -> bool:
    """Compatibility helper for explicit command-boundary feature loading.

    Expanding or collapsing an N-panel section never calls this function.  It is
    retained for older internal callers that already run from an operator/event
    boundary, where registering the requested tool is safe.
    """
    kind, alias = _sms_section_key_tool_ref(section_key)
    if not kind or not alias:
        return True
    try:
        if kind == 'native':
            return bool(_sms_ensure_native_tool_loaded(alias, context=context))
        if kind == 'integrated':
            return bool(_sms_ensure_integrated_tool_loaded(alias, context=context))
        # Suite-panel sections are part of the resident lightweight UI and do
        # not own a separately importable tool module.
        return True
    except Exception:
        return False


class SMS_OT_toggle_edge_crease_overlay(bpy.types.Operator):
    bl_idname = "view3d.toggle_edge_crease_overlay"
    bl_label = "Toggle Edge Crease Overlay"
    bl_description = "Show or hide edge-crease values in the current 3D Viewport. This changes only viewport display and does not create an Undo step."
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    @classmethod
    def poll(cls, context):
        space = getattr(context, 'space_data', None)
        return getattr(space, 'type', '') == 'VIEW_3D' and getattr(space, 'overlay', None) is not None

    def execute(self, context):
        overlay = getattr(getattr(context, 'space_data', None), 'overlay', None)
        if overlay is None or not hasattr(overlay, 'show_edge_crease'):
            self.report({'INFO'}, _pick_lang('Edge crease overlay is not available in this viewport.', 'このビューポートではエッジクリース表示を使用できません。', context))
            return {'CANCELLED'}
        overlay.show_edge_crease = not bool(overlay.show_edge_crease)
        try:
            context.area.tag_redraw()
        except Exception:
            pass
        return {'FINISHED'}


class SMS_OT_toggle_ui_section(bpy.types.Operator):
    bl_idname = "smart_modeling_suite.toggle_ui_section"
    bl_label = "Toggle UI Section"
    bl_description = 'Expand or collapse this Smart Modeling section.'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    section_key: StringProperty(options={'SKIP_SAVE'})
    label: StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        label = str(getattr(properties, 'label', '') or getattr(properties, 'section_key', '') or '').strip()
        return _pick_lang(
            f'Open or close the {label} section.',
            f'{label} セクションを開閉します。',
            context,
        )

    def execute(self, context):
        section_key = str(self.section_key or '').strip()
        if not section_key:
            return {'CANCELLED'}
        prefs = _sms_get_suite_prefs(context)
        current = _sms_ui_section_state_get(prefs, section_key, False)
        next_state = not current
        _sms_ui_section_state_set(section_key, next_state, context=context, prefs=prefs)
        _sms_redraw_after_section_toggle(context)
        return {'FINISHED'}


_SMS_HELP_POPUP_WIDTH = 640



class SMS_OT_toggle_npanel_state_save(bpy.types.Operator):
    bl_idname = "smart_modeling_suite.toggle_npanel_state_save"
    bl_label = "Toggle N-panel State Save"
    bl_description = 'Turn N-panel state saving on or off.'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    @classmethod
    def description(cls, context, properties):
        return _pick_lang(
            'Turn N-panel state saving on or off. Turning it off records OFF once, then blocks all settings writes until it is enabled again. File-load safety cleanup remains active without writing settings.',
            'Nパネル状態保存を切り替えます。無効化時はOFFを一度だけ記録し、再び有効にするまで設定を書き込みません。ファイル読み込み時の安全処理は設定を書き込まず継続します。',
            context,
        )

    def execute(self, context):
        prefs = _sms_get_suite_prefs(context)
        current = _sms_npanel_state_save_enabled(context=context, prefs=prefs, default=True)
        _sms_npanel_state_save_state_set(not current, context=context, prefs=prefs)
        return {'FINISHED'}


class SMS_OT_toggle_persistent_runtime_switch(bpy.types.Operator):
    bl_idname = "smart_modeling_suite.toggle_persistent_runtime_switch"
    bl_label = "Toggle Persistent Runtime Switch"
    bl_description = 'Turn this centralized always-on switch on or off.'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    prop_name: StringProperty(options={'SKIP_SAVE'})
    label: StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        label = str(getattr(properties, 'label', '') or getattr(properties, 'prop_name', '') or '').strip()
        return _pick_lang(
            f'Turn the always-on runtime switch for {label} on or off.',
            f'{label} の常時機能切り替えを切り替えます。',
            context,
        )

    def execute(self, context):
        prop_name = str(self.prop_name or '').strip()
        if not prop_name:
            return {'CANCELLED'}
        prefs = _sms_get_suite_prefs(context)
        current = _sms_persistent_toggle_state_get(prop_name, context=context, prefs=prefs, default=False)
        next_state = not current
        _sms_persistent_toggle_state_set(prop_name, next_state, context=context, prefs=prefs)
        try:
            for spec in tuple(globals().get('_SMS_ALWAYS_ON_TOOL_SPECS', ())):
                if str((spec or {}).get('enable_prop') or '').strip() != prop_name:
                    continue
                kind = str((spec or {}).get('kind') or '').strip()
                alias = str((spec or {}).get('tool_id') or (spec or {}).get('alias') or (spec or {}).get('id') or '').strip()
                if next_state:
                    _sms_start_tool_runtime(kind, alias, context=context)
                else:
                    _sms_collapse_tool_settings(kind, alias, context=context, prefs=prefs)
                    _sms_deactivate_tool_runtime(kind, alias, context=context, unload=True)
                break
        except Exception:
            pass
        try:
            _sms_update_persistent_tool_runtime_from_prefs(context)
        except Exception:
            pass
        return {'FINISHED'}


class SMS_OT_show_tool_help(bpy.types.Operator):
    """Lightweight Help launcher.  The detailed help popup is registered lazily."""
    bl_idname = "smart_modeling_suite.show_tool_help"
    bl_label = "Help"
    bl_description = "Open detailed help for this Smart Modeling tool."
    bl_options = {'INTERNAL'}
    _sms_no_undo = True
    kind: StringProperty(options={'SKIP_SAVE'}, default="")
    alias: StringProperty(options={'SKIP_SAVE'}, default="")
    label: StringProperty(options={'SKIP_SAVE'}, default="")

    @classmethod
    def description(cls, context, properties):
        label = str(getattr(properties, 'label', '') or getattr(properties, 'alias', '') or '').strip()
        if label:
            return _pick_lang(
                f'Open detailed help for {label}.',
                f'{label} の詳細ヘルプを開きます。',
                context,
            )
        return _pick_lang(
            'Open detailed help for this Smart Modeling tool.',
            'このSmart Modelingツールの詳細ヘルプを開きます。',
            context,
        )

    def execute(self, context):
        try:
            from . import help as _sms_help
            ok = bool(_sms_help.show_tool_help(
                context,
                str(self.kind or '').strip(),
                str(self.alias or '').strip(),
                str(self.label or '').strip(),
                runtime=sys.modules.get(__name__),
                popup_width=_SMS_HELP_POPUP_WIDTH,
            ))
        except Exception as exc:
            self.report({'ERROR'}, _pick_lang(f'Failed to open help: {exc}', f'ヘルプを開けませんでした: {exc}', context))
            return {'CANCELLED'}
        if not ok:
            self.report({'ERROR'}, _pick_lang('Help is not available for this tool.', 'このツールのヘルプは利用できません。', context))
            return {'CANCELLED'}
        return {'FINISHED'}


class SMS_OT_show_keymap_registration(bpy.types.Operator):
    """Popup launcher for keymap registration details."""
    _sms_no_undo = True
    bl_idname = "smart_modeling_suite.show_keymap_registration"
    bl_label = "Keymap Registration"
    bl_description = "Open keymap registration IDs, locations, and copy buttons for this tool in a popup."
    bl_options = {'INTERNAL'}

    kind: StringProperty(options={'SKIP_SAVE'}, default="")
    alias: StringProperty(options={'SKIP_SAVE'}, default="")
    label: StringProperty(options={'SKIP_SAVE'}, default="")
    popup_width: IntProperty(options={'SKIP_SAVE'}, default=760, min=320, max=1400)

    @classmethod
    def description(cls, context, properties):
        label = str(getattr(properties, 'label', '') or getattr(properties, 'alias', '') or '').strip()
        if label:
            return _pick_lang(
                f'Open a popup that shows the keymap registration IDs, registration locations, and copy buttons for {label}.',
                f'{label} のキーマップ登録ID、登録場所、コピー用ボタンをポップアップで表示します。',
                context,
            )
        return _pick_lang(
            'Open a popup that shows keymap registration IDs, registration locations, and copy buttons for this tool.',
            'このツールのキーマップ登録ID、登録場所、コピー用ボタンをポップアップで表示します。',
            context,
        )

    def invoke(self, context, _event):
        wm = getattr(context, 'window_manager', None)
        if wm is None:
            return {'CANCELLED'}
        return wm.invoke_popup(self, width=max(320, min(int(self.popup_width or 760), 1400)))

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False
        label = str(self.label or self.alias or '').strip()
        title = _pick_lang('Keymap Registration', 'キーマップ登録', context)
        if label:
            layout.label(text=label, icon=_sms_safe_icon('KEYINGSET', 'KEYFRAME'))
        else:
            layout.label(text=title, icon=_sms_safe_icon('KEYINGSET', 'KEYFRAME'))
        entries = _sms_keymap_entries_for_target(str(self.kind or ''), str(self.alias or ''), context=context)
        if not entries:
            layout.label(
                text=_pick_lang('No keymap registration items were found.', 'キーマップ登録項目は見つかりませんでした。', context),
            )
            return
        prefs = _sms_get_suite_prefs(context) if str(self.kind or '') == 'native' else None
        _sms_draw_keymap_reference(layout, context, entries, prefs=prefs)

    def execute(self, _context):
        return {'FINISHED'}



SMS_RENAME_TRANSLATION_OVERRIDES = {
    ("*", 'Add Modifier Stack'): 'モディファイアスタックを追加',
    ("*", 'Add Slice Wire Detail'): 'スライスワイヤ詳細を追加',
    ("*", 'Align and Unbend'): '整列して直線化',
    ("*", 'Align, Flow and Deform'): '整列・フロー・変形',
    ("*", 'Apply Transfer'): '補助貼り付け',
    ("*", 'Apply Weighted Normal'): '重み付き法線を適用',
    ("*", 'Apply and Clean Boolean'): 'ブーリアンを適用して整理',
    ("*", 'Architecture Generator'): '建築生成',
    ("*", 'Architecture'): '建築生成',
    ("*", 'Audit and Repair Mesh'): 'メッシュを監査して修復',
    ("*", 'Bend and Project'): '曲げて投影',
    ("*", 'Bolt Generator'): 'ボルト生成',
    ("*", 'Cell Fracture'): 'セル破砕',
    ("*", 'Clean CAD Import'): 'CAD の読み込みを整理',
    ("*", 'Clean Planar Bevels'): '平面ベベルを整理',
    ("*", 'Click-only Commands'): 'クリック起動コマンド',
    ("*", 'Command Browser'): 'コマンドブラウザー',
    ("*", 'Connect Selection'): '選択を接続',
    ("*", 'Convert to Curve'): 'カーブに変換',
    ("*", 'Convert to Surface Strip'): 'サーフェスストリップに変換',
    ("*", 'Copy Source'): 'コピー元',
    ("*", 'Create Bevel Normal Stack'): 'ベベル法線スタックを作成',
    ("*", 'Create Boolean Fusion'): 'ブーリアン融合を作成',
    ("*", 'Create Cable Pipe'): 'ケーブルパイプを作成',
    ("*", 'Create Solidify Shell'): 'シェル厚みを作成',
    ("*", 'Curve Objects'): 'カーブオブジェクト',
    ("*", 'Curve Toolkit'): 'カーブツール',
    ("*", 'Deform with Falloff'): 'フォールオフで変形',
    ("*", 'Delete Objects'): 'オブジェクトを削除',
    ("*", 'Delete Selection'): '選択を削除',
    ("*", 'Delete Through Selection'): '貫通選択を削除',
    ("*", 'Delete and Cleanup'): '削除と整理',
    ("*", 'Direct Delete'): '直接削除',
    ("*", 'Draw Quad Strip'): 'クアッドストリップを描画',
    ("*", 'Drop and Snap'): '接地してスナップ',
    ("*", 'Edge Flow'): 'エッジフロー',
    ("*", 'Edit and Transfer'): '編集と転送',
    ("*", 'Face Builder'): '面作成',
    ("*", 'Flex Deform'): 'フレックス変形',
    ("*", 'Generate Floor and Wall'): '床と壁を生成',
    ("*", 'Generate Rail Sweep'): 'レールスイープを生成',
    ("*", 'Generate Terrain'): '地形を生成',
    ("*", 'Generation, Scatter and Architecture'): '生成・散布・建築',
    ("*", 'Generate, Scatter, Build'): '生成・散布・建築',
    ("*", 'Hard Surface Modeling'): 'ハードサーフェス',
    ("*", 'Insert Kit Asset'): 'キット素材を挿入',
    ("*", 'Ivy Generator'): 'ツタ生成',
    ("*", 'Key Ops Toolkit'): 'キー操作ツール',
    ("*", 'Loop Tools'): 'ループツール',
    ("*", 'Merge Snap'): 'マージスナップ',
    ("*", 'Mesh Align'): 'メッシュ整列',
    ("*", 'Mesh Connect'): 'メッシュ接続',
    ("*", 'Mesh Edit Toolkit'): 'メッシュ編集ツール',
    ("*", 'Mesh Repair'): 'メッシュ修復',
    ("*", 'Model Organizer'): 'モデル整理',
    ("*", 'Model by Context'): 'コンテキストに応じて作成',
    ("*", 'Modeling Toolkit'): 'モデリングツール',
    ("*", 'Modifier Companion'): 'モディファイア補助',
    ("*", 'Object Scatter'): 'オブジェクト散布',
    ("*", 'Open Align Presets'): '整列プリセットを開く',
    ("*", 'Open Crease Presets'): 'クリースプリセットを開く',
    ("*", 'Organize Selection'): '選択を整理',
    ("*", 'Override Backspace'): 'Backspaceを上書き',
    ("*", 'Override Delete Key'): 'Deleteキーを上書き',
    ("*", 'Always-on Feature Toggles'): '常時機能切り替え',
    ("*", 'PolyQuilt Retopo'): 'PolyQuiltリトポ',
    ("*", 'Quad Retopo'): 'クアッドリトポ',
    ("*", 'Rebuild Quads'): 'クアッドを再構築',
    ("*", 'Replace and Randomize Assets'): 'アセットを置換してランダム化',
    ("*", 'Restore Backup'): 'バックアップを復元',
    ("*", 'Retopo and Rebuild'): 'リトポと再構築',
    ("*", 'Scatter on Surface'): '表面に散布',
    ("*", 'Set Workplane and Pivot'): '作業平面と原点を設定',
    ("*", 'Shape Loops'): 'ループ形状を調整',
    ("*", 'Sketch Surface'): 'スケッチサーフェス',
    ("*", 'Sketch and Retopo'): 'スケッチとリトポ',
    ("*", 'Snow Generator'): '雪生成',
    ("*", 'Solo Visibility'): '単独表示',
    ("*", 'Start Retopo Pen'): 'リトポペンを開始',
    ("*", 'Start Slide'): 'スライド開始',
    ("*", 'Terrain Generator'): '地形生成',
    ("*", 'Tissue Generator'): 'Tissue生成',
    ("*", 'Toggle Merge and Snap'): 'マージとスナップを切替',
    ("*", 'Tree Generator'): '樹木生成',
    ("*", 'Utility Tools'): 'ユーティリティ',
    ("*", 'Validate Targets'): '補助確認',
    ("*", 'Vertex Slide'): '頂点スライド',
    ("*", 'Vertex Copy'): '頂点コピー',
    ("*", 'Weighted Normal'): '重み付き法線',
    ("*", 'Wrap and Remesh'): '追従してリメッシュ',
}
try:
    translation_dict.setdefault("ja_JP", {}).update(SMS_RENAME_TRANSLATION_OVERRIDES)
except Exception:
    pass

# Register nested PropertyGroup types before SMS_NPanelSettings defines
# PointerProperty annotations.  Blender 5.1 can emit missing-bl_rna errors if a
# PointerProperty is constructed with an unregistered type during extension
# install/reinstall.  Safe registration patches or keeps existing RNA classes and
# never unregisters live ones.
for _sms_early_pref_cls in (
    SMS_LazyUISettings,
    SmartVertSlidePreferences,
    DIRECTDELETE_AddonPreferences,
    MO2_AddonPreferences,
    SMS_MSAP_AddonPreferencesProxy,
    SMS_CreasePresetItemProxy,
    SMS_CreasePresetPreferencesProxy,
    SMS_TAMS_CycleItemProxy,
    SMS_TAMS_PrefsProxy,
    SMS_AWN_AddonPreferencesProxy,
):
    try:
        _safe_register_class(_sms_early_pref_cls)
        _sms_existing_pref_cls = _sms_registered_rna_class(_sms_early_pref_cls)
        if isinstance(_sms_existing_pref_cls, type) and (
            _sms_existing_pref_cls is _sms_early_pref_cls
            or _sms_class_is_owned_for_mutation(_sms_existing_pref_cls)
        ):
            try:
                getattr(_sms_existing_pref_cls, 'bl_rna')
                _sms_pref_name = str(getattr(_sms_early_pref_cls, '__name__', '') or '')
                if _sms_pref_name:
                    globals()[_sms_pref_name] = _sms_existing_pref_cls
            except Exception:
                pass
    except Exception:
        pass
try:
    del _sms_existing_pref_cls
except Exception:
    pass
try:
    del _sms_pref_name
except Exception:
    pass


class SMS_NPanelSettings(bpy.types.PropertyGroup):
    bl_idname = "SMS_NPanelSettings"
    lazy_ui_settings: PointerProperty(
        name="Initial Tool UI",
        description="Session-only settings shown before an on-demand Smart Modeling tool is loaded.",
        type=SMS_LazyUISettings,
        options={'SKIP_SAVE'},
    )
    # ------------------------------------------------------------------
    # Toolset toggles (master enable per tool)
    # ------------------------------------------------------------------
    n_panel_state_save: BoolProperty(
        name="N-panel State Save",
        description="When enabled, every Smart Modeling Suite N-panel setting change is immediately saved to the versioned Blender config folder Smart_Modeling_Suite/Smart_Modeling_Suite.json. Turning it off records that choice once; no later setting change writes until it is enabled again.",
        default=True,
        update=_update_npanel_state_save,
    )
    enable_vertex_copy: BoolProperty(
        name="Vertex Copy Always-on Runtime",
        description="Controls Vertex Copy live preview and draw-handler based runtime. Disabled means the tool stays unloaded and light until explicitly used; enable only when you need live background preview support while modeling.",
        default=False,
        update=_update_suite_toggles,
    )
    enable_vertex_slide: BoolProperty(
        name="Vertex Slide Always-on Runtime",
        description="Controls the Vertex Slide top-bar toggle, shortcut toggle, status display, and live transform monitor. Disabled keeps the tool unloaded and light until the always-on switch is enabled again.",
        default=False,
        update=_update_suite_toggles,
    )
    enable_direct_delete: BoolProperty(
        name="Direct Delete Always-on Runtime",
        description="Controls Direct Delete preview/runtime only. It never registers Delete / Backspace keymaps automatically; bind the shown operator IDs manually if you need shortcuts.",
        default=False,
        update=_update_suite_toggles,
    )
    enable_model_organized: BoolProperty(
        name="Enable Model Organizer",
        description="Show/hide Model Organizer UI and operators.",
        default=False,
        update=_update_click_only_tool_setting,
    )
    enable_mesh_split: BoolProperty(
        name="Enable Mesh Split",
        description="Show/hide Mesh Split operators and settings. Its complete UI is available immediately, while the tool implementation stays unloaded until you execute a command.",
        default=False,
        update=_update_click_only_tool_setting,
    )
    enable_mesh_align_preset: BoolProperty(
        name="Enable Mesh Align",
        description="Show/hide Mesh Align operators and menus.",
        default=False,
        update=_update_click_only_tool_setting,
    )
    enable_crease_preset: BoolProperty(
        name="Enable Crease Preset",
        description="Show/hide Crease Preset operators and menus.",
        default=False,
        update=_update_click_only_tool_setting,
    )
    enable_toggle_auto_merge_snap: BoolProperty(
        name="Merge Snap Always-on Runtime",
        description="Controls Merge Snap status/header runtime and related automatic indicators. Disabled removes the always-visible status/header integration; enable only when you need persistent merge/snap status or shortcut support.",
        default=False,
        update=_update_suite_toggles,
    )
    enable_apply_weighted_normal: BoolProperty(
        name="Apply Weighted Normal Menu Runtime",
        description="Controls the persistent Alt+N normals menu integration for Apply Weighted Normal. Disabled keeps the normals menu untouched and light; enable only when you frequently need the Alt+N menu entry in edit mode.",
        default=False,
        update=_update_suite_toggles,
    )
    enable_archimesh_hint_overlay: BoolProperty(
        name="Architecture Hint Overlay",
        description="Controls the Archimesh measurement/name viewport draw handler. Disabled removes the draw handler completely; enable only while persistent architectural hints are needed.",
        default=False,
        update=_update_archimesh_hint_overlay,
    )
    enable_sketch_tools: BoolProperty(
        name="Enable Sketch Surface",
        description="Show/hide Sketch Surface operators and related helper UI.",
        default=False,
        update=_update_click_only_tool_setting,
    )
    enable_quad_strip_draw: BoolProperty(
        name="Enable Quad Retopo",
        description="Show/hide Quad Strip / Retopo operators and related helper UI.",
        default=False,
        update=_update_click_only_tool_setting,
    )
    use_compact_n_panel: BoolProperty(
        name="Use Compact Hub UI",
        description="Stores the compact hub layout flag for older saved setups. The visible controls remain in the standard Smart Modeling N-panel.",
        default=True,
        update=_sms_update_ui_state,
    )
    show_legacy_panels: BoolProperty(
        name="Show Legacy Detailed Panels",
        description="Stores the legacy-panel visibility flag for older saved setups. All visible controls remain in the standard Smart Modeling N-panel.",
        default=False,
        update=_sms_update_ui_state,
    )

    
    
    # ------------------------------------------------------------------
    # Internal per-tool settings storage (not shown in UI)
    # ------------------------------------------------------------------
    # Nested tool setting PointerProperties are attached after class registration
    # by _sms_attach_nested_tool_settings_properties().  Defining them here during
    # module import can pass unregistered/stale PropertyGroup classes into
    # PointerProperty on Blender 5.1 extension reinstall.

    # ------------------------------------------------------------------
    # N-panel UI state (collapsible sections)
    # ------------------------------------------------------------------
    ui_show_vertex_copy: BoolProperty(name="Show Vertex Copy", description="Expand or collapse the Vertex Copy section inside the Smart Modeling N-panel.", default=False, update=_sms_update_ui_state)
    ui_show_vertex_slide: BoolProperty(name="Show Vertex Slide", description="Expand or collapse the Vertex Slide section inside the Smart Modeling N-panel.", default=False, update=_sms_update_ui_state)
    ui_show_direct_delete: BoolProperty(name="Show Direct Delete", description="Expand or collapse the Direct Delete section inside the Smart Modeling N-panel.", default=False, update=_sms_update_ui_state)
    ui_show_model_organized: BoolProperty(name="Show Model Organizer", description="Expand or collapse the Model Organizer section inside the Smart Modeling N-panel.", default=False, update=_sms_update_ui_state)
    ui_show_mesh_split: BoolProperty(name="Show Mesh Split", description="Expand or collapse the Mesh Split section inside the Smart Modeling N-panel.", default=False, update=_sms_update_ui_state)
    ui_show_mesh_align_preset: BoolProperty(name="Show Mesh Align", description="Expand or collapse the Mesh Align section inside the Smart Modeling N-panel.", default=False, update=_sms_update_ui_state)
    ui_show_crease_preset: BoolProperty(name="Show Crease Preset", description="Expand or collapse the Crease Preset section inside the Smart Modeling N-panel.", default=False, update=_sms_update_ui_state)
    ui_show_toggle_auto_merge_snap: BoolProperty(name="Show Merge Snap", description="Expand or collapse the Merge Snap section inside the Smart Modeling N-panel.", default=False, update=_sms_update_ui_state)
    ui_show_apply_weighted_normal: BoolProperty(name="Show Apply Weighted Normal", description="Expand or collapse the Apply Weighted Normal section inside the Smart Modeling N-panel.", default=False, update=_sms_update_ui_state)
# ------------------------------------------------------------------
    # Copyable keymap info fields (StringProperty so the user can copy)
    # ------------------------------------------------------------------
    # Vertex Slide
    svs_km_operator: StringProperty(
        name="Keymap Registration ID",
        description="Copy this text and paste into Preferences > Keymap search or into a keymap item.",
        default="mesh.smart_vert_slide",
        options={'SKIP_SAVE'},
    )
    svs_km_where: StringProperty(
        name="Where to register",
        description="Exact UI path in Blender Preferences > Keymap where you should add the shortcut.",
        default="Edit > Preferences > Keymap > Mesh (Global)",
        options={'SKIP_SAVE'},
    )
    svs_km_how: StringProperty(
        name="How to register",
        description="Step-by-step instructions.",
        default="Open Preferences > Keymap, paste this ID into the search box, then add a shortcut for this operator.",
        options={'SKIP_SAVE'},
    )
    # Direct Delete
    dd_km_operator_main: StringProperty(
        name="Keymap Registration ID",
        description="Copy this text and paste into Preferences > Keymap search or into a keymap item.",
        default="mesh.delete_direct",
        options={'SKIP_SAVE'},
    )
    dd_km_operator_del: StringProperty(
        name="Keymap Registration ID",
        description="Copy this text and paste into Preferences > Keymap search or into a keymap item.",
        default="mesh.delete_direct_del",
        options={'SKIP_SAVE'},
    )
    dd_km_operator_bs: StringProperty(
        name="Keymap Registration ID",
        description="Copy this text and paste into Preferences > Keymap search or into a keymap item.",
        default="mesh.delete_direct_bs",
        options={'SKIP_SAVE'},
    )
    dd_km_operator_through: StringProperty(
        name="Keymap Registration ID",
        description="Copy this text and paste into Preferences > Keymap search or into a keymap item.",
        default="mesh.delete_direct_through",
        options={'SKIP_SAVE'},
    )
    dd_km_where: StringProperty(
        name="Where to register",
        description="Exact UI path in Blender Preferences > Keymap where you should add the shortcut.",
        default="Edit > Preferences > Keymap > Mesh (Global)",
        options={'SKIP_SAVE'},
    )
    dd_km_how: StringProperty(
        name="How to register",
        description="Step-by-step instructions.",
        default="Open Preferences > Keymap, paste this ID into the search box, then add a shortcut for this operator.",
        options={'SKIP_SAVE'},
    )
    # Mesh Align (popup; assign shortcut manually)
    map_km_operator: StringProperty(
        name="Keymap Registration ID",
        description="Copy this text and paste into Preferences > Keymap search or into a keymap item.",
        default="mesh.mesh_align_master",
        options={'SKIP_SAVE'},
    )
    map_km_where: StringProperty(
        name="Where to register",
        description="Exact UI path in Blender Preferences > Keymap where you should add the shortcut.",
        default="Edit > Preferences > Keymap > Mesh (Global)",
        options={'SKIP_SAVE'},
    )
    map_km_how: StringProperty(
        name="How to register",
        description="Step-by-step instructions.",
        default="Open Preferences > Keymap, paste this ID into the search box, then add a shortcut for this operator.",
        options={'SKIP_SAVE'},
    )
    # Mesh Split (assign shortcut manually)
    ms_km_operator: StringProperty(
        name="Keymap Registration ID",
        description="Copy this text and paste into Preferences > Keymap search or into a keymap item.",
        default="mesh.smart_split",
        options={'SKIP_SAVE'},
    )
    ms_km_where: StringProperty(
        name="Where to register",
        description="Exact UI path in Blender Preferences > Keymap where you should add the shortcut.",
        default="Edit > Preferences > Keymap > Mesh (Global)",
        options={'SKIP_SAVE'},
    )
    ms_km_how: StringProperty(
        name="How to register",
        description="Step-by-step instructions.",
        default="Open Preferences > Keymap, paste this ID into the search box, then add a shortcut for this operator.",
        options={'SKIP_SAVE'},
    )
    # Crease Preset (popup; assign shortcut manually)
    cp_km_operator: StringProperty(
        name="Keymap Registration ID",
        description="Copy this text and paste into Preferences > Keymap search or into a keymap item.",
        default="mesh.edge_crease_master",
        options={'SKIP_SAVE'},
    )
    cp_km_where: StringProperty(
        name="Where to register",
        description="Exact UI path in Blender Preferences > Keymap where you should add the shortcut.",
        default="Edit > Preferences > Keymap > Mesh (Global)",
        options={'SKIP_SAVE'},
    )
    cp_km_how: StringProperty(
        name="How to register",
        description="Step-by-step instructions.",
        default="Open Preferences > Keymap, paste this ID into the search box, then add a shortcut for this operator.",
        options={'SKIP_SAVE'},
    )
    # Merge Snap (assign shortcut manually)
    tams_km_operator: StringProperty(
        name="Keymap Registration ID",
        description="Copy this text and paste into Preferences > Keymap search or into a keymap item.",
        default="mesh.toggle_merge_snap",
        options={'SKIP_SAVE'},
    )
    tams_km_where: StringProperty(
        name="Where to register",
        description="Exact UI path in Blender Preferences > Keymap where you should add the shortcut.",
        default="Edit > Preferences > Keymap > Mesh (Global)",
        options={'SKIP_SAVE'},
    )
    tams_km_how: StringProperty(
        name="How to register",
        description="Step-by-step instructions.",
        default="Open Preferences > Keymap, paste this ID into the search box, then add a shortcut for this operator.",
        options={'SKIP_SAVE'},
    )
    # Apply Weighted Normal (optional manual shortcut; main access is Alt+N menu)
    awn_km_operator: StringProperty(
        name="Keymap Registration ID",
        description="Copy this text and paste into Preferences > Keymap search or into a keymap item.",
        default="mesh.apply_weighted_normal",
        options={'SKIP_SAVE'},
    )
    awn_km_where: StringProperty(
        name="Where to register",
        description="Exact UI path in Blender Preferences > Keymap where you should add the shortcut.",
        default="Edit > Preferences > Keymap > Mesh (Global)",
        options={'SKIP_SAVE'},
    )
    awn_km_how: StringProperty(
        name="How to register",
        description="Step-by-step instructions.",
        default="Open Preferences > Keymap, paste this ID into the search box, then add a shortcut for this operator.",
        options={'SKIP_SAVE'},
    )
    def draw(self, context):
        del self, context
        return None
        layout = self.layout
        tr = bpy.app.translations.pgettext_iface
        def _ml(ui, s):
            # multi-line label helper (each line is translatable)
            for _ln in str(s).splitlines():
                _ln = _ln.strip()
                if not _ln:
                    continue
                ui.label(text=tr(_ln))
        def _copy_prop(ui, prop_name, label_msgid):
            row = ui.row(align=True)
            row.prop(self, prop_name, text=tr(label_msgid))
            op = row.operator("smart_modeling_suite.copy_to_clipboard", text="", icon="COPYDOWN")
            op.text = getattr(self, prop_name)
        def _header(box, expand_prop, title_msgid, enable_prop):
            row = box.row(align=True)
            row.prop(
                self,
                expand_prop,
                text="",
                icon="TRIA_DOWN" if getattr(self, expand_prop) else "TRIA_RIGHT",
                emboss=False,
            )
            row.label(text=tr(title_msgid))
            return getattr(self, expand_prop)
        layout.label(text=tr("Smart Modeling"))
        layout.separator()

        hub_box = layout.box()
        hub_box.label(text=tr("Smart Modeling N-panel"))
        hub_box.label(text=tr("Smart Modeling uses the standard 3D View Sidebar N-panel."))
        hub_box.label(text=tr("All settings are shown in the Smart Modeling tab of the 3D View Sidebar."))
        layout.separator()
        # ------------------------------------------------------------------
        # Tool sections (collapsible)
        # ------------------------------------------------------------------
        # Vertex Copy
        box = layout.box()
        if _header(box, "ui_show_vertex_copy", "Vertex Copy", "enable_vertex_copy"):
            col = box.column(align=False)
            col.label(text=tr("Overview"))
            _ml(col, "Copy / paste vertex positions using clipboard slots (Edit Mode).")
            _ml(col, "Supports Exact / Smart / Mirror / Surface Project paste modes for different use cases.")
            _ml(col, "Includes presets and validation tools to prevent mismatched transfers.")
            _ml(col, "Optional extra data transfer: weights, UVs, and custom normals (depending on settings).")
            _ml(col, "Exact is best when source and target have identical topology (same vertex order).")
            _ml(col, "Smart is designed for similar-but-not-identical meshes (common after retopo or edits).")
            _ml(col, "Mirror modes help transfer from one side to the other (check the Mirror Axis setting).")
            _ml(col, "Surface Project projects copied offsets onto the target surface when topology differs a lot.")
            col.separator()
            col.label(text=tr("How to use"))
            _ml(col, "1) In Edit Mode, select the vertices you want to copy, then press Copy (stores into the active slot).")
            _ml(col, "2) Choose the paste target (active object, named object, selected objects, or collection) in Transfer Settings.")
            _ml(col, "3) Pick a Paste Mode (Exact for same topology, Smart for near topology, Mirror for L/R, Surface Project for projection).")
            _ml(col, "4) Press Paste. Use Target / Validate to check candidates before pasting in batch scenarios.")
            _ml(col, "Tip: Start from a preset (Exact / Approximate / Face / Rigid / Cloth) and tweak only what you need.")
        # Vertex Slide
        box = layout.box()
        if _header(box, "ui_show_vertex_slide", "Vertex Slide", "enable_vertex_slide"):
            col = box.column(align=False)
            col.label(text=tr("Overview"))
            _ml(col, "Enhanced Vertex Slide operator designed for fast retopo and cleanup.")
            _ml(col, "Works with multi-object edit, optional proportional influence, and HUD feedback.")
            _ml(col, "Loop/Ring priority helps keep edge flow clean while sliding.")
            _ml(col, "Important: This tool does NOT auto-register a shortcut. Bind it in Blender Preferences > Keymap.")
            _ml(col, "Recommended setup: replace Blender's Vertex Slide hotkey so this tool becomes your default slide.")
            _ml(col, "This is a modal tool: start it, move the mouse to slide, then confirm/cancel.")
            col.separator()
            col.label(text=tr("How to use"))
            _ml(col, "1) Enter Edit Mode and select vertices/edges to slide (multi-object selection is supported).")
            _ml(col, "2) Run Vertex Slide and move the mouse to slide.")
            _ml(col, "3) Confirm: LMB / Enter. Cancel: RMB / Esc.")
            _ml(col, "While running: C cycles behavior (Straight/Stop/Corner). Shift+C toggles Proportional mode.")
            _ml(col, "While running: L toggles Loop priority, R toggles Ring priority, B toggles baseline (Individual/Active).")
            _ml(col, "While running: Mouse wheel adjusts proportional radius (when proportional is enabled).")
            col.separator()
            k = col.box()
            k.label(text=tr("Keymap Setup"))
            _copy_prop(k, "svs_km_operator", "Keymap Registration ID")
            row = k.row(); row.label(text=tr("Keymap Display Name")); row.label(text=tr("Vertex Slide"))
            k.label(text=tr("Where to register")); _ml(k, self.svs_km_where)
            k.label(text=tr("How to register"))
            _ml(k, "To replace Blender's built-in Vertex Slide, rebind its shortcut to this operator.")
            _ml(k, "1) Preferences > Keymap > search for 'Vertex Slide' (operator: transform.vert_slide).")
            _ml(k, "2) Change that entry to this ID, or add a new entry with the same shortcut:")
            _ml(k, "mesh.smart_vert_slide")
            _ml(k, "3) Remove or change the original binding to avoid conflicts.")
        # Direct Delete
        box = layout.box()
        if _header(box, "ui_show_direct_delete", "Direct Delete", "enable_direct_delete"):
            col = box.column(align=False)
            col.label(text=tr("Overview"))
            _ml(col, "Instant delete without confirmation popups (Edit Mode).")
            _ml(col, "Smart Context can choose the best delete action based on selection pattern.")
            _ml(col, "Supports dedicated overrides for Delete / Backspace and an optional Through variant.")
            _ml(col, "Useful when doing repetitive cleanup and you want a faster delete workflow.")
            _ml(col, "Variants: Smart (context-based), DEL override, Backspace override, and Through (special-case).")
            _ml(col, "Assign only the variants you need to avoid conflicting with your existing delete workflow.")
            col.separator()
            col.label(text=tr("How to use"))
            _ml(col, "1) Register the desired Direct Delete operator ID manually in Preferences > Keymap, then press your assigned key in Edit Mode.")
            _ml(col, "2) Adjust behavior in the Direct Delete panel: Smart Context, ignore hidden, action mode (Delete/Dissolve/etc.).")
            _ml(col, "3) Use the Through variant when you want the action to ignore typical limitations for your workflow.")
            col.separator()
            k = col.box()
            k.label(text=tr("Keymap Setup"))
            _copy_prop(k, "dd_km_operator_main", "Keymap Registration ID (Main)")
            row = k.row(); row.label(text=tr("Keymap Display Name")); row.label(text=tr("Direct Delete (Smart)"))
            _copy_prop(k, "dd_km_operator_del", "Keymap Registration ID (DEL override)")
            row = k.row(); row.label(text=tr("Keymap Display Name")); row.label(text=tr("Direct Delete (DEL)"))
            _copy_prop(k, "dd_km_operator_bs", "Keymap Registration ID (Backspace override)")
            row = k.row(); row.label(text=tr("Keymap Display Name")); row.label(text=tr("Direct Delete (Backspace)"))
            _copy_prop(k, "dd_km_operator_through", "Keymap Registration ID (Through)")
            row = k.row(); row.label(text=tr("Keymap Display Name")); row.label(text=tr("Direct Delete (Through)"))
            k.label(text=tr("Where to register")); _ml(k, self.dd_km_where)
            k.label(text=tr("How to register")); _ml(k, self.dd_km_how)
        # Model Organizer
        box = layout.box()
        if _header(box, "ui_show_model_organized", "Model Organizer", "enable_model_organized"):
            col = box.column(align=False)
            col.label(text=tr("Overview"))
            _ml(col, "Batch organization and cleanup suite for mesh objects.")
            _ml(col, "Includes presets, safe transform / cleanup steps, modifier keep, and backup/restore.")
            _ml(col, "Designed to standardize naming and scene hygiene while minimizing destructive changes.")
            _ml(col, "Key areas: Preset, Modifiers, Transforms, Clean Data, Rename/Collections, Preflight, Backup/Restore.")
            _ml(col, "Clean Data can handle: remove crease/bevel weight, clear custom normals, recalc normals, merge by distance, delete loose, purge orphans.")
            _ml(col, "Use Preflight to detect issues like non-manifold geometry or negative scale before applying changes.")
            col.separator()
            col.label(text=tr("How to use"))
            _ml(col, "1) Select one or more mesh objects.")
            _ml(col, "2) Open the Model Organizer panel and run Organize Selection.")
            _ml(col, "3) Choose a preset (or configure steps) and run; review the report if anything is skipped.")
            _ml(col, "Tip: Enable Backup/Restore if you want a safety net while testing new presets.")
        # Mesh Align
        box = layout.box()
        if _header(box, "ui_show_mesh_align_preset", "Mesh Align", "enable_mesh_align_preset"):
            col = box.column(align=False)
            col.label(text=tr("Overview"))
            _ml(col, "Popup preset menu for aligning selected vertices.")
            _ml(col, "Includes Standard Align (axis/center), View/Grid align, Loop align, Annotation align, and Distribute Evenly.")
            _ml(col, "Modifier keys: Alt uses slide-based alignment; Ctrl applies to all selected objects (when supported).")
            _ml(col, "Typical commands include: Align X/Y/Z, Align to Center, Distribute Evenly, Align to View/Grid, Align to Annotation.")
            _ml(col, "Tip: When assigning a shortcut, prefer a chord that doesn't conflict with Blender's built-ins.")
            col.separator()
            col.label(text=tr("How to use"))
            _ml(col, "1) In Edit Mode, select vertices (or edges/faces where supported).")
            _ml(col, "2) Run Mesh Align to open the popup and choose a command.")
            _ml(col, "3) Use Alt/Ctrl modifiers as described in each command tooltip for advanced behavior.")
            col.separator()
            k = col.box()
            k.label(text=tr("Keymap Setup"))
            _copy_prop(k, "map_km_operator", "Keymap Registration ID")
            row = k.row(); row.label(text=tr("Keymap Display Name")); row.label(text=tr("Mesh Align"))
            k.label(text=tr("Where to register")); _ml(k, self.map_km_where)
            k.label(text=tr("How to register")); _ml(k, self.map_km_how)
        # Crease Preset
        box = layout.box()
        if _header(box, "ui_show_crease_preset", "Crease Preset", "enable_crease_preset"):
            col = box.column(align=False)
            col.label(text=tr("Overview"))
            _ml(col, "Popup preset menu for applying and managing edge crease values.")
            _ml(col, "Includes quick apply (selected / linked / all) and preset management (save/load/export).")
            _ml(col, "Designed to be assigned to a shortcut so you can crease while modeling without leaving the 3D View.")
            _ml(col, "Crease values are 0.0 - 1.0 (0 = none, 1 = full). Great for Subdivision hard edges.")
            _ml(col, "You can manage presets (save/load/export) to keep consistent crease standards across projects.")
            col.separator()
            col.label(text=tr("How to use"))
            _ml(col, "1) In Edit Mode, select edges to crease.")
            _ml(col, "2) Run the Open Crease Presets and choose a preset value or enter a custom value.")
            _ml(col, "3) Use Apply Mode (Selected / Linked / All) and optional delimit settings (seam/sharp/material) to control spread.")
            col.separator()
            k = col.box()
            k.label(text=tr("Keymap Setup"))
            _copy_prop(k, "cp_km_operator", "Keymap Registration ID")
            row = k.row(); row.label(text=tr("Keymap Display Name")); row.label(text=tr("Open Crease Presets"))
            k.label(text=tr("Where to register")); _ml(k, self.cp_km_where)
            k.label(text=tr("How to register")); _ml(k, self.cp_km_how)
        # Merge Snap
        box = layout.box()
        if _header(box, "ui_show_toggle_auto_merge_snap", "Merge Snap", "enable_toggle_auto_merge_snap"):
            col = box.column(align=False)
            col.label(text=tr("Overview"))
            _ml(col, "One-button toggle for Auto Merge and Snap settings.")
            _ml(col, "Default: toggle both. Shift: Auto Merge only. Alt: Snap only. Ctrl: open quick popup.")
            _ml(col, "Also supports cycling through predefined states if you enable cycle mode in its N-panel settings.")
            _ml(col, "Use this when switching between free modeling and precise snapping frequently.")
            _ml(col, "Because it touches global tool settings, keep its shortcut distinct to avoid accidental toggles.")
            col.separator()
            col.label(text=tr("How to use"))
            _ml(col, "1) Invoke the operator to toggle states quickly while modeling.")
            _ml(col, "2) Use Shift/Alt for single-feature toggles, Ctrl for quick popup.")
            _ml(col, "3) If you use cycling, repeat the operator to rotate through saved states.")
            col.separator()
            k = col.box()
            k.label(text=tr("Keymap Setup"))
            _copy_prop(k, "tams_km_operator", "Keymap Registration ID")
            row = k.row(); row.label(text=tr("Keymap Display Name")); row.label(text=tr("Toggle Merge and Snap"))
            k.label(text=tr("Where to register")); _ml(k, self.tams_km_where)
            k.label(text=tr("How to register")); _ml(k, self.tams_km_how)
            col.separator()
            col.label(text=tr("Detailed Settings"))
            try:
                tams = self.toggle_auto_merge_snap
            except Exception:
                tams = None
            if tams:
                sbox = col.box()
                sbox.prop(tams, "toggle_basis")
                sbox.prop(tams, "snap_enable_mode")
                if getattr(tams, "snap_enable_mode", "FORCE_VERTEX") == 'CUSTOM_SET':
                    sbox.prop(tams, "custom_snap_elements")
                sbox.prop(tams, "repeat_action_when_on")
                row = sbox.row(align=True)
                row.prop(tams, "enable_cycling")
                row.prop(tams, "status_bar_indicator")
                row = sbox.row(align=True)
                row.prop(tams, "debug_logging")
                if getattr(tams, "enable_cycling", False):
                    sbox.label(text=tr("Cycle Order"))
                    list_row = sbox.row()
                    list_row.template_list("TAMS_UL_cycle_order", "", tams, "cycle_order", tams, "cycle_order_index", rows=4)
                    col_ops = list_row.column(align=True)
                    col_ops.operator("mesh.tams_cycle_add", text="", icon='ADD')
                    col_ops.operator("mesh.tams_cycle_remove", text="", icon='REMOVE')
                    col_ops.separator()
                    up = col_ops.operator("mesh.tams_cycle_move", text="", icon='TRIA_UP')
                    up.direction = 'UP'
                    down = col_ops.operator("mesh.tams_cycle_move", text="", icon='TRIA_DOWN')
                    down.direction = 'DOWN'
                _ml(sbox, "The dedicated N-panel can stay compact if you prefer the hub entry only.")
        # Apply Weighted Normal
        box = layout.box()
        if _header(box, "ui_show_apply_weighted_normal", "Apply Weighted Normal", "enable_apply_weighted_normal"):
            col = box.column(align=False)
            col.label(text=tr("Overview"))
            _ml(col, "Add/apply a Weighted Normal modifier directly from Edit Mode.")
            _ml(col, "Supports presets, multi-object operation, and optional selection-limited baking.")
            _ml(col, "Useful for hard-surface shading cleanup without leaving your modeling workflow.")
            _ml(col, "If a Weighted Normal modifier already exists, the tool can reuse/update it depending on options.")
            _ml(col, "When Limit To Selection is enabled, select vertices first; otherwise the operator will warn.")
            col.separator()
            col.label(text=tr("How to use"))
            _ml(col, "1) Enter Edit Mode on a mesh object (or multiple objects in multi-edit).")
            _ml(col, "2) Run Apply Weighted Normal and choose execution mode (Add & Apply or Add Only).")
            _ml(col, "3) Choose a preset; optionally enable Limit To Selection to bake only selected vertices.")
            _ml(col, "4) If custom normals already exist, choose how to proceed in the dialog.")
            col.separator()
            run_box = col.box()
            run_box.label(text=tr("Execute"), icon='PLAY')
            run_row = run_box.row(align=True)
            run_row.scale_y = 1.15
            _sms_layout_operator_if_registered(run_row, "mesh.apply_weighted_normal", text=tr("Run Apply Weighted Normal"), icon='MOD_NORMALEDIT')
            _ml(run_box, "When this feature is enabled, an Apply Weighted Normal button is also added to Blender's standard Alt+N Normal popup.")
            col.separator()
            k = col.box()
            k.label(text=tr("Keymap Setup"))
            _copy_prop(k, "awn_km_operator", "Keymap Registration ID")
            row = k.row(); row.label(text=tr("Keymap Display Name")); row.label(text=tr("Apply Weighted Normal"))
            k.label(text=tr("Where to register")); _ml(k, self.awn_km_where)
            k.label(text=tr("How to register")); _ml(k, self.awn_km_how)


def _sms_attach_nested_tool_settings_properties():
    # Disabled intentionally for Blender 5.1 extension reinstall safety.
    # Dynamic nested PointerProperty creation with resident PropertyGroup classes
    # can emit missing-bl_rna errors or enter stale RNA paths during package
    # install/reinstall.  These nested settings are not part of the visible UI;
    # individual tools keep their own safe Scene/WindowManager storage when they
    # are actually loaded.
    return None


def _sms_resolve_npanel_pointer_annotations():
    """Re-resolve stale Pointer/Collection targets on SMS_NPanelSettings.

    Register-side tolerance for cross-version live reinstall: a deferred
    PointerProperty annotation can capture a PropertyGroup class object that is
    no longer the registered one (the OLD install's object, or a fresh object
    blocked by a same-name residue class).  Registering SMS_NPanelSettings with
    such a target raises ``TypeError: PointerProperty(...) expected an RNA
    type ... missing bl_rna`` and kills the whole suite register.  This helper
    runs at registration time, re-resolves every target from the CURRENT module
    namespace / live RNA, re-registers it through the tolerant safe path, and
    as a last resort drops the annotation instead of letting register() die.
    NOTE: getattr(cls, 'bl_rna') is NOT usable as the health check here - on
    Blender 5.1.2 an unregistered PropertyGroup subclass inherits bl_rna from
    the base type.  Only _sms_propertygroup_is_registered() is truthful.
    """
    try:
        annotations = dict(getattr(SMS_NPanelSettings, '__annotations__', {}) or {})
    except Exception:
        return
    changed = False
    for prop_name, deferred in tuple(annotations.items()):
        try:
            factory = getattr(deferred, 'function', None)
            if str(getattr(factory, '__name__', '') or '') not in {'PointerProperty', 'CollectionProperty'}:
                continue
            keywords = dict(getattr(deferred, 'keywords', {}) or {})
            target = keywords.get('type')
            if not isinstance(target, type):
                continue
            if _sms_propertygroup_is_registered(target):
                continue
            target_name = str(getattr(target, '__name__', '') or '')
            resolved = None
            # 1) current module namespace (the live class of this install)
            live = globals().get(target_name)
            if isinstance(live, type) and live is not target and _sms_propertygroup_is_registered(live):
                resolved = live
            # 2) live RNA registry
            if resolved is None:
                registered = _sms_registered_propertygroup_subclass(target_name)
                if isinstance(registered, type) and _sms_class_is_owned_for_mutation(registered):
                    resolved = registered
            # 3) register the current-namespace class (tolerant path clears
            #    same-name residue left by an old install)
            if resolved is None:
                candidate = live if isinstance(live, type) else target
                if _sms_exact_safe_register_class(candidate) and _sms_propertygroup_is_registered(candidate):
                    resolved = candidate
            if resolved is None:
                # unresolvable: degrade (drop this one annotation) instead of
                # letting the whole suite registration raise missing-bl_rna
                annotations.pop(prop_name, None)
                changed = True
                continue
            if resolved is not target:
                keywords['type'] = resolved
                annotations[prop_name] = factory(**keywords)
                changed = True
                if globals().get(target_name) is target:
                    globals()[target_name] = resolved
        except Exception:
            continue
    if changed:
        try:
            SMS_NPanelSettings.__annotations__ = annotations
        except Exception:
            pass


def _sms_attach_npanel_settings_property():
    try:
        if not _sms_propertygroup_is_registered(SMS_NPanelSettings):
            _sms_resolve_npanel_pointer_annotations()
            _safe_register_class(SMS_NPanelSettings)
        registered_np = _sms_registered_propertygroup_subclass('SMS_NPanelSettings')
        if registered_np is None:
            return
        if registered_np is not SMS_NPanelSettings and not _sms_class_is_owned_for_mutation(registered_np):
            return
        if hasattr(bpy.types.WindowManager, _SMS_NPANEL_SETTINGS_PROP):
            # Cross-version live reinstall tolerance: an old install's property
            # (or a foreign one) can survive on WindowManager under this name,
            # pointing at a stale or foreign PropertyGroup.  Keeping it makes
            # the suite silently read the wrong storage.  Validate the target
            # and recreate the property when it is not this install's own
            # SMS_NPanelSettings RNA.
            valid = False
            try:
                rna_prop = bpy.types.WindowManager.bl_rna.properties.get(_SMS_NPANEL_SETTINGS_PROP)
                fixed = getattr(rna_prop, 'fixed_type', None)
                fixed_name = str(getattr(fixed, 'identifier', '') or '')
                valid = (
                    fixed_name == 'SMS_NPanelSettings'
                    and _sms_registered_propertygroup_subclass(fixed_name) is registered_np
                )
            except Exception:
                valid = False
            if not valid:
                try:
                    delattr(bpy.types.WindowManager, _SMS_NPANEL_SETTINGS_PROP)
                except Exception:
                    return
        if not hasattr(bpy.types.WindowManager, _SMS_NPANEL_SETTINGS_PROP):
            setattr(
                bpy.types.WindowManager,
                _SMS_NPANEL_SETTINGS_PROP,
                PointerProperty(
                    type=registered_np,
                    name="Smart Modeling N-panel Settings",
                    description="Stores Smart Modeling N-panel settings in a runtime property group; values are mirrored to the versioned Blender config folder Smart_Modeling_Suite/Smart_Modeling_Suite.json for restart and scene-load persistence.",
                    options={'SKIP_SAVE'},
                ),
            )
    except Exception:
        pass


def _sms_detach_npanel_settings_property():
    try:
        if hasattr(bpy.types.WindowManager, _SMS_NPANEL_SETTINGS_PROP):
            delattr(bpy.types.WindowManager, _SMS_NPANEL_SETTINGS_PROP)
    except Exception:
        pass


def _sms_ensure_npanel_settings_storage(context=None, *, recreate=False):
    """Ensure the WindowManager-backed N-panel setting storage is ready.

    The main N-panel should not draw a temporary repair warning.  This helper is
    called at registration and load-post time so stale or missing RNA pointers
    are corrected before the panel is visible.
    """
    ctx = context or getattr(bpy, 'context', None)
    if recreate:
        try:
            _sms_detach_npanel_settings_property()
        except Exception:
            pass
    try:
        if not _sms_class_registered(SMS_NPanelSettings):
            _sms_resolve_npanel_pointer_annotations()
            _safe_register_class(SMS_NPanelSettings)
        _sms_attach_nested_tool_settings_properties()
    except Exception:
        pass
    try:
        _sms_attach_npanel_settings_property()
    except Exception:
        pass
    prefs = _sms_get_suite_prefs(ctx)
    if prefs is None and not recreate:
        try:
            _sms_detach_npanel_settings_property()
            _sms_attach_npanel_settings_property()
        except Exception:
            pass
        prefs = _sms_get_suite_prefs(ctx)
    if prefs is not None:
        try:
            _sms_restore_suite_panel_settings(ctx, prefs)
        except Exception:
            pass
    return prefs


class SMS_OT_rebuild_npanel_settings(bpy.types.Operator):
    """Explicitly repair the N-panel RNA storage outside Panel.draw()."""

    bl_idname = "smart_modeling_suite.rebuild_npanel_settings"
    bl_label = "Rebuild N-panel Settings"
    bl_description = 'Rebuild unavailable Smart Modeling N-panel setting storage.'
    bl_options = {'INTERNAL'}

    def execute(self, context):
        try:
            prefs = _sms_ensure_npanel_settings_storage(context, recreate=True)
        except Exception:
            prefs = None
        if prefs is None or not _sms_rna_data_is_current(prefs):
            self.report(
                {'ERROR'},
                _pick_lang(
                    'N-panel settings could not be rebuilt. Restart Blender and try again.',
                    'Nパネル設定を再構築できませんでした。Blenderを再起動して再試行してください。',
                    context,
                ),
            )
            return {'CANCELLED'}
        try:
            _sms_tag_redraw_view3d_areas(force=True, all_supported_editors=True)
        except Exception:
            pass
        self.report(
            {'INFO'},
            _pick_lang('N-panel settings were rebuilt.', 'Nパネル設定を再構築しました。', context),
        )
        return {'FINISHED'}


def _sms_draw_npanel_settings_unavailable(layout, context) -> None:
    """Draw a read-only recovery notice without repairing RNA from draw()."""

    box = layout.box()
    box.alert = True
    box.label(
        text=_pick_lang(
            'N-panel settings are temporarily unavailable.',
            'Nパネル設定を一時的に利用できません。',
            context,
        ),
        icon='ERROR',
    )
    box.label(
        text=_pick_lang(
            'Press Rebuild to repair them explicitly.',
            '「再構築」を押して明示的に修復してください。',
            context,
        ),
    )
    box.operator(
        SMS_OT_rebuild_npanel_settings.bl_idname,
        text=_pick_lang('Rebuild N-panel Settings', 'Nパネル設定を再構築', context),
        icon='FILE_REFRESH',
    )


class VIEW3D_PT_sms_modifier_suite_notice(bpy.types.Panel):
    bl_label = "Smart Modifier Split"
    bl_description = 'Explains the new split: Smart Modifier keeps the stack UI, while non-stack companion tools are surfaced from Smart Modeling.'
    bl_idname = "VIEW3D_PT_sms_modifier_suite_notice"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 50

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False
        modifier_suite_enabled = _sms_addon_enabled(context, "smart_modifier_suite")

        box = layout.box()
        row = box.row(align=True)
        label = _pick_lang("Smart Modifier Split", 'スマートモディファイアの分割', context)
        row.label(text=label)
        _sms_draw_help_icon_button(row, 'suite_panel', 'modifier_suite_notice', label, context)
        status = row.row(align=True)
        status.alignment = 'RIGHT'
        status.alert = not modifier_suite_enabled
        status.label(text=_t("Detected and ready") if modifier_suite_enabled else _t("Not detected"), icon='CHECKMARK' if modifier_suite_enabled else 'ERROR')


def _sms_find_addon_module_key(context, suite_basename: str) -> str:
    suite_basename = str(suite_basename or '').strip()
    if not suite_basename:
        return ''
    suffix = '.' + suite_basename
    try:
        import addon_utils
        for module in addon_utils.modules():
            module_name = str(getattr(module, '__name__', '') or '').strip()
            if not module_name:
                continue
            if module_name == suite_basename or module_name.endswith(suffix):
                try:
                    if addon_utils.check(module_name)[1]:
                        return module_name
                except Exception:
                    return module_name
    except Exception:
        pass
    return suite_basename


def _sms_import_modifier_companion_modules(context):
    keys = []
    resolved = _sms_find_addon_module_key(context, 'smart_modifier_suite')
    if resolved:
        keys.append(resolved)
    if 'smart_modifier_suite' not in keys:
        keys.append('smart_modifier_suite')
    for key in keys:
        try:
            catalog_mod = importlib.import_module(f"{key}.plugin_catalog")
            ctx_mod = importlib.import_module(f"{key}.context_checks")
            return catalog_mod, ctx_mod
        except Exception:
            continue
    return None, None



def _sms_loaded_smart_modifier_module(relative_name: str):
    relative_name = str(relative_name or '').strip().strip('.')
    if not relative_name:
        return None
    candidates = []
    pkg = str(__package__ or __name__ or '').strip('.')
    if pkg:
        bundle_prefix = pkg.rpartition('.')[0]
        if bundle_prefix:
            candidates.append(f"{bundle_prefix}.smart_modifier_suite.{relative_name}")
    candidates.append(f"smart_modifier_suite.{relative_name}")
    for module_name in candidates:
        mod = sys.modules.get(module_name)
        if mod is not None:
            return mod
    return None


def _sms_modifier_workspace_panel_classes():
    panel_specs = (
        ('sms_hub', ('VIEW3D_PT_msm_hub', 'VIEW3D_PT_msm_hub_help')),
        ('sms_precision_tools', ('SMSP_PT_precision_layout', 'SMSP_PT_precision_guide')),
        ('sms_advanced_tools', ('VIEW3D_PT_sms_advanced', 'VIEW3D_PT_sms_advanced_help')),
        ('sms_preflight', ('VIEW3D_PT_sms_preflight',)),
        ('sms_catalog_browser', ('VIEW3D_PT_sms_catalog_browser',)),
    )
    panels = []
    for module_name, class_names in panel_specs:
        mod = _sms_loaded_smart_modifier_module(module_name)
        if mod is None:
            continue
        for class_name in class_names:
            cls = getattr(mod, class_name, None)
            if cls is not None:
                panels.append(cls)
    return panels



_SMS_SMART_MODIFIER_NATIVE_EQUIVALENTS = {
    "hard_surface_modifier",
    "symmetry_modifier",
    "quick_solidify_modifier",
    "bend_modifier",
    "twist_modifier",
    "taper_modifier",
    "relax_modifier",
    "cast_modifier",
}


def _sms_append_companion_entry(entries, seen_ids, meta):
    if not isinstance(meta, dict):
        return
    plugin_id = str(meta.get('id') or meta.get('plugin_id') or '').strip()
    if not plugin_id or plugin_id in seen_ids:
        return
    entries.append(meta)
    seen_ids.add(plugin_id)


def _sms_modifier_companion_entries(context):
    catalog_mod, ctx_mod = _sms_import_modifier_companion_modules(context)
    if catalog_mod is None:
        return None, None, []
    entries = []
    seen_ids = set()
    stack_filter = getattr(catalog_mod, 'is_stack_addable_plugin', None)
    try:
        for plugin_id in getattr(catalog_mod, 'PLUGIN_CATALOG', {}).keys():
            meta = catalog_mod.get_plugin_meta(plugin_id=plugin_id)
            if not isinstance(meta, dict):
                continue
            if str(plugin_id) in _SMS_SMART_MODIFIER_NATIVE_EQUIVALENTS:
                continue
            is_stack = False
            if callable(stack_filter):
                try:
                    is_stack = bool(stack_filter(plugin_id=plugin_id, plugin_meta=meta))
                except Exception:
                    is_stack = False
            if not is_stack:
                _sms_append_companion_entry(entries, seen_ids, meta)
    except Exception:
        entries = []
        seen_ids = set()

    return catalog_mod, ctx_mod, entries


class VIEW3D_PT_sms_modifier_companion_tools(bpy.types.Panel):
    bl_label = "Modifier Companion"
    bl_description = "Companion utility and generator tools moved out of Smart Modifier's compact N-panel area."
    bl_idname = "VIEW3D_PT_sms_modifier_companion_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_parent_id = ""
    bl_order = 51
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False

        modifier_suite_enabled = _sms_addon_enabled(context, 'smart_modifier_suite')
        box = layout.box()
        row = box.row(align=True)
        label = _pick_lang('Modifier Companion Tools', 'モディファイア補助ツール', context)
        row.label(text=label, icon='MODIFIER')
        _sms_draw_help_icon_button(row, 'suite_panel', 'modifier_companion', label, context)
        status = row.row(align=True)
        status.alignment = 'RIGHT'
        status.alert = not modifier_suite_enabled
        status.label(text=_t('Detected and ready') if modifier_suite_enabled else _t('Not detected'), icon='CHECKMARK' if modifier_suite_enabled else 'ERROR')


        if not modifier_suite_enabled:
            return

        catalog_mod, ctx_mod, entries = _sms_modifier_companion_entries(context)
        if catalog_mod is None:
            box.label(text=_pick_lang('Could not read Smart Modifier companion catalog.', 'Smart Modifier の補助ツール一覧を読み込めませんでした。', context), icon='ERROR')
            return

        if not entries:
            box.label(text=_pick_lang('No companion tools were found.', '補助ツールが見つかりませんでした。', context))
            return

        for group_id, group_entries in catalog_mod.iter_plugins_grouped(entries):
            gbox = layout.box()
            try:
                gbox.label(text=catalog_mod.get_plugin_group_label(group_id), icon=catalog_mod.get_plugin_group_icon(group_id))
            except Exception:
                gbox.label(text=str(group_id))
            ordered = sorted(group_entries, key=lambda m: int(m.get('priority', 0)), reverse=True)
            for meta in ordered:
                plugin_id = meta.get('id')
                operator_id = meta.get('operator_id')
                status_data = None
                if ctx_mod and hasattr(ctx_mod, 'get_tool_runtime_status'):
                    try:
                        status_data = ctx_mod.get_tool_runtime_status(context, plugin_id, operator_id)
                    except Exception:
                        status_data = None
                if not isinstance(status_data, dict):
                    status_data = {'bucket': 'ready', 'text': _t('Ready'), 'icon': 'CHECKMARK'}

                row = gbox.row(align=True)
                row.enabled = True
                row.alert = status_data.get('bucket') == 'context'
                try:
                    op = row.operator("smsm.run_user_plugin", text=str(meta.get('label') or operator_id), icon=_sms_safe_icon(meta.get('icon'), 'TOOL_SETTINGS'))
                    op.plugin_id = str(plugin_id or '')
                    op.operator_id = str(operator_id or '')
                    op.label = str(meta.get('label') or operator_id)
                except Exception:
                    try:
                        row.operator(str(operator_id), text=str(meta.get('label') or operator_id), icon=_sms_safe_icon(meta.get('icon'), 'TOOL_SETTINGS'))
                    except Exception:
                        row.enabled = True
                        row.alert = True
                        row.label(text=str(meta.get('label') or operator_id), icon='ERROR')
                tag = row.row(align=True)
                tag.enabled = True
                try:
                    tag.alignment = 'RIGHT'
                except Exception:
                    pass
                tag.label(text=str(status_data.get('text') or ''), icon=_sms_safe_icon(status_data.get('icon'), 'NONE'))

                extra_line = ''
                extra_icon = 'NONE'
                if status_data.get('bucket') == 'context' and ctx_mod is not None:
                    try:
                        blockers = ctx_mod.get_plugin_context_blockers(context, plugin_id=plugin_id)
                    except Exception:
                        blockers = []
                    try:
                        extra_line = ctx_mod.summarize_blockers(blockers, lang=_sms_ui_lang(context), limit=2)
                    except Exception:
                        extra_line = ''
                    extra_icon = 'ERROR'
                if not extra_line:
                    ui_lang = _sms_ui_lang(context)
                    extra_line = str(meta.get(f'short_hint_{ui_lang}') or meta.get('short_hint') or '')
                if not extra_line:
                    try:
                        extra_line = catalog_mod.get_plugin_short_hint(plugin_id=plugin_id, lang=_sms_ui_lang(context))
                    except Exception:
                        extra_line = ''
                if extra_line:
                    sub = gbox.row(align=False)
                    sub.scale_y = 0.85
                    sub.enabled = True
                    sub.alert = status_data.get('bucket') == 'context'
                    prefix = _t('Missing: ') if status_data.get('bucket') == 'context' else _t('Requires: ')
                    sub.label(text=prefix + str(extra_line), icon=extra_icon if status_data.get('bucket') == 'context' else 'NONE')



def _sms_draw_native_tool_load_box(layout, context, tool_id: str, label: str, icon: str = 'TOOL_SETTINGS') -> bool:
    tool_id = str(tool_id or '').strip()
    label = str(label or tool_id or 'Native Tool').strip()
    state = _sms_native_tool_state(tool_id)
    status = str(state.get('status') or 'available').strip().lower()
    if status == 'loaded':
        return True
    box = layout.box()
    row = box.row(align=True)
    row.label(text=label, icon=_sms_safe_icon(icon, 'TOOL_SETTINGS'))
    if status == 'failed':
        row.label(text=_pick_lang('Error', 'エラー', context), icon='ERROR')
        excerpt = _sms_native_tool_error_excerpt(tool_id)
        if excerpt:
            warn = box.column(align=True)
            warn.alert = True
            warn.label(text=_pick_lang(f'Activation error: {excerpt}', f'有効化エラー: {excerpt}', context), icon='ERROR')
        return False
    if status in {'disabled', 'unsupported_platform'}:
        row.label(text=_pick_lang('Disabled', '無効', context), icon='HIDE_OFF')
        return False
    if status == 'loading':
        row.label(text=_pick_lang('Loading', '読み込み中', context), icon='TIME')
    else:
        row.label(text=_pick_lang('Ready to load', '読込可能', context))
    return False


# ------------------------------------------------------------
# Compact Hub UI
# ------------------------------------------------------------

def _sms_normalize_editor_token(value) -> str:
    try:
        return ''.join(ch for ch in str(value or '').upper() if ch.isalnum() or ch == '_')
    except Exception:
        return ''


def _sms_context_editor_tokens(context) -> tuple[str, ...]:
    """Read only the current area/space discriminator fields."""
    values = []
    try:
        area = getattr(context, 'area', None)
        space = getattr(context, 'space_data', None)
    except Exception:
        area = None
        space = None
    for owner, names in (
        (area, ('type', 'ui_type')),
        (space, ('type', 'ui_type', 'mode', 'tree_type', 'browse_mode')),
    ):
        if owner is None:
            continue
        for name in names:
            try:
                token = _sms_normalize_editor_token(getattr(owner, name, ''))
            except Exception:
                token = ''
            if token and token not in values:
                values.append(token)
    return tuple(values)


def _sms_context_logical_editor_key(context, physical_space: str) -> str:
    """Classify one of the 17 Manager logical editors without side effects."""
    physical = _sms_normalize_editor_token(physical_space)
    if not physical:
        return ''
    try:
        area = getattr(context, 'area', None)
        actual = _sms_normalize_editor_token(getattr(area, 'type', '')) if area is not None else ''
    except Exception:
        actual = ''
    if actual and actual != physical:
        return ''
    tokens = _sms_context_editor_tokens(context)
    if physical == 'IMAGE_EDITOR':
        if any(token in {'UV', 'UVS', 'UVEDIT', 'UV_EDITOR'} or token.startswith('UV') for token in tokens):
            return 'UV_EDITOR'
        return 'IMAGE_EDITOR'
    if physical == 'NODE_EDITOR':
        if any('COMPOSITOR' in token for token in tokens):
            return 'COMPOSITOR'
        if any('GEOMETRY' in token for token in tokens):
            return 'GEOMETRY_NODE_EDITOR'
        if any('TEXTURE' in token for token in tokens):
            return 'TEXTURE_NODE_EDITOR'
        return 'SHADER_EDITOR'
    if physical == 'GRAPH_EDITOR':
        if any('DRIVER' in token for token in tokens):
            return 'DRIVERS'
        return 'GRAPH_EDITOR'
    if physical == 'FILE_BROWSER':
        if any('ASSET' in token for token in tokens):
            return 'ASSET_BROWSER'
        return 'FILE_BROWSER'
    return str(_SMS_DIRECT_LOGICAL_EDITOR_KEYS.get(physical, ''))


def _sms_loaded_manager_placement_allowed():
    """Resolve only the already-loaded Manager public API from fixed module keys."""
    for module_key in _SMS_MANAGER_MODULE_KEYS:
        module = sys.modules.get(module_key)
        if module is None:
            continue
        try:
            candidate = getattr(module, 'placement_allowed', None)
        except Exception:
            candidate = None
        if callable(candidate):
            return candidate
    return None


def _sms_native_root_poll(cls, context) -> bool:
    """Pure O(1) Manager-cell lookup; unavailable/NOT_READY fails open."""
    editor_key = _sms_context_logical_editor_key(context, getattr(cls, 'bl_space_type', ''))
    editor_keys = getattr(cls, '_smart_tools_manager_editor_keys', ())
    if not editor_key or (editor_keys and editor_key not in editor_keys):
        return False
    placement_allowed = _sms_loaded_manager_placement_allowed()
    if placement_allowed is None:
        return True
    try:
        result = placement_allowed(_SMS_MANAGER_TOOL_KEY, context, editor_key=editor_key)
    except Exception:
        return True
    # READY returns a strict bool. None, NOT_READY sentinels, and unknown values
    # fail open so the suite stays usable while Manager is absent or settling.
    return result is not False


def _sms_draw_native_root_header(self, context):
    # A narrow region cannot hold the panel title next to the Help button.  The
    # title then leaves the header for this redraw (Blender sets Panel.text from
    # bl_label again on every redraw) and the body draws it on wrapped rows, so
    # it is never cut.  The Help button stays here while it fits on its own.
    if not _sms_hub_header_help_fits(self, context):
        try:
            self.text = ''
        except Exception:
            pass
        if not _sms_hub_header_help_alone_fits(self, context):
            return
    _sms_draw_help_icon_button(self.layout, 'suite_panel', 'all_commands', 'Smart Modeling', context)


def _sms_draw_native_root_body(self, context) -> None:
    """Draw the same complete Smart Modeling body in every physical editor."""
    layout = self.layout
    layout.use_property_split = False
    layout.use_property_decorate = False
    prefs = _sms_get_suite_prefs(context)
    previous_content = _SMS_HUB_CONTENT_PX[0]
    _SMS_HUB_CONTENT_PX[0] = _sms_hub_panel_content_pixels(self, context)
    try:
        if not _sms_hub_header_help_fits(self, context):
            # The header left the title out; draw it here on wrapped rows.
            title = str(getattr(self, 'bl_label', '') or 'Smart Modeling')
            try:
                title = bpy.app.translations.pgettext_iface(title)
            except Exception:
                pass
            title_col = layout.column(align=True)
            for line in _sms_hub_wrap_lines(title, _sms_hub_content_pixels(context) - _SMS_HUB_LINE_PADDING_PX, context):
                title_col.label(text=line, translate=False)
            if not _sms_hub_header_help_alone_fits(self, context):
                help_row = layout.row(align=True)
                help_row.alignment = 'RIGHT'
                _sms_draw_help_icon_button(help_row, 'suite_panel', 'all_commands', 'Smart Modeling', context)
        try:
            _sms_draw_unified_tools_ui(layout, context, prefs, host='n_panel')
        except Exception as exc:
            box = layout.box()
            box.label(text=_pick_lang('Smart Modeling UI could not be drawn.', 'Smart Modeling UIを描画できませんでした。', context), icon='ERROR')
            box.label(text=str(exc)[:240], icon='ERROR')
    finally:
        _SMS_HUB_CONTENT_PX[0] = previous_content


class VIEW3D_PT_sms_hub(bpy.types.Panel):
    bl_label = 'Smart Modeling'
    bl_description = 'Complete Smart Modeling tools in the 3D View Sidebar.'
    bl_idname = 'VIEW3D_PT_sms_hub'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_order = 0
    _smart_tools_manager_tool_key = 'SMART_MODELING'
    _smart_tools_manager_native_npanel_root = True
    poll = classmethod(_sms_native_root_poll)
    draw = _sms_draw_native_root_body
    draw_header_preset = _sms_draw_native_root_header


class IMAGE_PT_sms_hub(bpy.types.Panel):
    bl_label = 'Smart Modeling'
    bl_description = 'Complete Smart Modeling tools in Image and UV Editors.'
    bl_idname = 'IMAGE_PT_sms_hub'
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_order = 0
    _smart_tools_manager_tool_key = 'SMART_MODELING'
    _smart_tools_manager_native_npanel_root = True
    poll = classmethod(_sms_native_root_poll)
    draw = _sms_draw_native_root_body
    draw_header_preset = _sms_draw_native_root_header


class NODE_PT_sms_hub(bpy.types.Panel):
    bl_label = 'Smart Modeling'
    bl_description = 'Complete Smart Modeling tools in Shader, Compositor, Geometry, and Texture Node Editors.'
    bl_idname = 'NODE_PT_sms_hub'
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_order = 0
    _smart_tools_manager_tool_key = 'SMART_MODELING'
    _smart_tools_manager_native_npanel_root = True
    poll = classmethod(_sms_native_root_poll)
    draw = _sms_draw_native_root_body
    draw_header_preset = _sms_draw_native_root_header


class SEQUENCER_PT_sms_hub(bpy.types.Panel):
    bl_label = 'Smart Modeling'
    bl_description = 'Complete Smart Modeling tools in the Video Sequencer.'
    bl_idname = 'SEQUENCER_PT_sms_hub'
    bl_space_type = 'SEQUENCE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_order = 0
    _smart_tools_manager_tool_key = 'SMART_MODELING'
    _smart_tools_manager_native_npanel_root = True
    poll = classmethod(_sms_native_root_poll)
    draw = _sms_draw_native_root_body
    draw_header_preset = _sms_draw_native_root_header


class CLIP_PT_sms_hub(bpy.types.Panel):
    bl_label = 'Smart Modeling'
    bl_description = 'Complete Smart Modeling tools in the Movie Clip Editor.'
    bl_idname = 'CLIP_PT_sms_hub'
    bl_space_type = 'CLIP_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_order = 0
    _smart_tools_manager_tool_key = 'SMART_MODELING'
    _smart_tools_manager_native_npanel_root = True
    poll = classmethod(_sms_native_root_poll)
    draw = _sms_draw_native_root_body
    draw_header_preset = _sms_draw_native_root_header


class DOPESHEET_PT_sms_hub(bpy.types.Panel):
    bl_label = 'Smart Modeling'
    bl_description = 'Complete Smart Modeling tools in the Dope Sheet.'
    bl_idname = 'DOPESHEET_PT_sms_hub'
    bl_space_type = 'DOPESHEET_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_order = 0
    _smart_tools_manager_tool_key = 'SMART_MODELING'
    _smart_tools_manager_native_npanel_root = True
    poll = classmethod(_sms_native_root_poll)
    draw = _sms_draw_native_root_body
    draw_header_preset = _sms_draw_native_root_header


class GRAPH_PT_sms_hub(bpy.types.Panel):
    bl_label = 'Smart Modeling'
    bl_description = 'Complete Smart Modeling tools in Graph and Drivers Editors.'
    bl_idname = 'GRAPH_PT_sms_hub'
    bl_space_type = 'GRAPH_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_order = 0
    _smart_tools_manager_tool_key = 'SMART_MODELING'
    _smart_tools_manager_native_npanel_root = True
    poll = classmethod(_sms_native_root_poll)
    draw = _sms_draw_native_root_body
    draw_header_preset = _sms_draw_native_root_header


class NLA_PT_sms_hub(bpy.types.Panel):
    bl_label = 'Smart Modeling'
    bl_description = 'Complete Smart Modeling tools in the NLA Editor.'
    bl_idname = 'NLA_PT_sms_hub'
    bl_space_type = 'NLA_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_order = 0
    _smart_tools_manager_tool_key = 'SMART_MODELING'
    _smart_tools_manager_native_npanel_root = True
    poll = classmethod(_sms_native_root_poll)
    draw = _sms_draw_native_root_body
    draw_header_preset = _sms_draw_native_root_header


class TEXT_PT_sms_hub(bpy.types.Panel):
    bl_label = 'Smart Modeling'
    bl_description = 'Complete Smart Modeling tools in the Text Editor.'
    bl_idname = 'TEXT_PT_sms_hub'
    bl_space_type = 'TEXT_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_order = 0
    _smart_tools_manager_tool_key = 'SMART_MODELING'
    _smart_tools_manager_native_npanel_root = True
    poll = classmethod(_sms_native_root_poll)
    draw = _sms_draw_native_root_body
    draw_header_preset = _sms_draw_native_root_header


class FILEBROWSER_PT_sms_hub(bpy.types.Panel):
    bl_label = 'Smart Modeling'
    bl_description = 'Complete Smart Modeling tools in the File Browser.'
    bl_idname = 'FILEBROWSER_PT_sms_hub'
    bl_space_type = 'FILE_BROWSER'
    # FILES needs the scrollable Source List for the complete tool body.
    bl_region_type = 'TOOLS'
    bl_category = 'Smart Modeling'
    bl_order = 0
    _smart_tools_manager_tool_key = 'SMART_MODELING'
    _smart_tools_manager_editor_keys = ('FILE_BROWSER',)
    _smart_tools_manager_native_npanel_root = True
    poll = classmethod(_sms_native_root_poll)
    draw = _sms_draw_native_root_body
    draw_header_preset = _sms_draw_native_root_header


class ASSETBROWSER_PT_sms_hub(bpy.types.Panel):
    bl_label = 'Smart Modeling'
    bl_description = 'Complete Smart Modeling tools in the Asset Browser.'
    bl_idname = 'ASSETBROWSER_PT_sms_hub'
    bl_space_type = 'FILE_BROWSER'
    bl_region_type = 'TOOL_PROPS'
    bl_category = 'Smart Modeling'
    bl_order = 0
    _smart_tools_manager_tool_key = 'SMART_MODELING'
    _smart_tools_manager_editor_keys = ('ASSET_BROWSER',)
    _smart_tools_manager_native_npanel_root = True
    poll = classmethod(_sms_native_root_poll)
    draw = _sms_draw_native_root_body
    draw_header_preset = _sms_draw_native_root_header


class SPREADSHEET_PT_sms_hub(bpy.types.Panel):
    bl_label = 'Smart Modeling'
    bl_description = 'Complete Smart Modeling tools in the Spreadsheet.'
    bl_idname = 'SPREADSHEET_PT_sms_hub'
    bl_space_type = 'SPREADSHEET'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_order = 0
    _smart_tools_manager_tool_key = 'SMART_MODELING'
    _smart_tools_manager_native_npanel_root = True
    poll = classmethod(_sms_native_root_poll)
    draw = _sms_draw_native_root_body
    draw_header_preset = _sms_draw_native_root_header


class VIEW3D_PT_sms_hub_edit(bpy.types.Panel):
    bl_label = "Edit and Transfer"
    bl_description = 'Compact edit tools: slide, vertex copy, and alignment helpers.'
    bl_idname = "VIEW3D_PT_sms_hub_edit"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _sms_compact_n_panel_enabled(context) and _sms_any_enabled(
            context,
            "enable_vertex_slide",
            "enable_vertex_copy",
            "enable_connect",
            "enable_mesh_split",
            "enable_mesh_align_preset",
        )

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False
        suite_prefs = _sms_get_suite_prefs(context)

        if _sms_enabled(context, "enable_vertex_slide", True):
            if _sms_draw_native_tool_load_box(layout, context, "vertex_slide", "Vertex Slide", icon=_sms_safe_icon('TRANSFORM_MOVE', 'EMPTY_ARROWS')):
                svs = _sms_safe_get_rna_attr(suite_prefs, "vertex_slide", None) if suite_prefs else None
                box = layout.box()
                box.label(text="Vertex Slide", icon=_sms_safe_icon('TRACKING', 'EMPTY_ARROWS'))
                row = box.row(align=True)
                row.scale_y = 1.15
                wm = getattr(context, "window_manager", None)
                scene = getattr(context, "scene", None)
                enabled = bool(getattr(wm, "svs_vertex_slide_constraint_enabled", getattr(scene, "svs_vertex_slide_constraint_enabled", False)))
                row.operator("mesh.smart_vert_slide", text=("Vertex Slide: ON" if enabled else "Vertex Slide: OFF"), icon=('CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT'), depress=enabled)
                if svs:
                    row = box.row(align=True)
                    row.prop(svs, "baseline", text="")
                    row.prop(svs, "use_proportional_editing", text="Prop Edit", toggle=True)
                    row = box.row(align=True)
                    row.prop(svs, "loop_priority", text="Loop", toggle=True)
                    row.prop(svs, "ring_priority", text="Ring", toggle=True)

        if _sms_enabled(context, "enable_vertex_copy", True):
            if _sms_draw_native_tool_load_box(layout, context, "vertex_copy", "Vertex Copy", icon='COPYDOWN') and hasattr(context.scene, "vscp_settings"):
                s = context.scene.vscp_settings
                box = layout.box()
                box.label(text=_pick_lang("Vertex Copy / Paste", "頂点コピー / 貼り付け", context), icon='COPYDOWN')
                col = box.column(align=True)
                _sms_label_wrapped(col, context, _pick_lang("Copy selected source vertices, then paste to the same vertex numbers.", "コピー元の選択頂点を記憶し、同じ頂点番号へ貼り付けます。", context))
                _sms_label_wrapped(col, context, _pick_lang("Only selected target vertices are changed by default.", "初期設定では、貼り付け先で選択中の頂点だけを変更します。", context))
                row = box.row(align=True)
                row.scale_y = 1.2
                _sms_layout_operator_if_registered(row, "vscp.copy_vertices", text=_pick_lang("Copy", "コピー", context), icon='COPYDOWN')
                _sms_layout_operator_if_registered(row, "vscp.paste_same_index", text=_pick_lang("Paste", "貼り付け", context), icon='PASTEDOWN')
                info = box.box()
                clip_info = str(getattr(s, "clipboard_info", "") or "")
                if clip_info and clip_info != "No copied data":
                    info.label(text=clip_info, icon='CHECKMARK')
                else:
                    info.label(text=_pick_lang("No copied vertices in the active slot.", 'アクティブスロットにコピー済み頂点がありません。', context))
                row = box.row(align=True)
                _sms_layout_operator_if_registered(row, "vscp.validate_same_index", text=_pick_lang("Check", "確認", context), icon='VIEWZOOM')
                _sms_layout_operator_if_registered(row, "vscp.clear_clipboard_slot", text=_pick_lang("Clear", "クリア", context), icon='TRASH')
                _sms_layout_operator_if_registered(row, "vscp.clear_last_reports", text=_pick_lang("Clear Result", "結果消去", context), icon='X')

                opt_row = box.row(align=True)
                opt_row.prop(s, "ui_section_main_options", text="", emboss=False, icon='TRIA_DOWN' if getattr(s, "ui_section_main_options", False) else 'TRIA_RIGHT')
                opt_row.label(text=_pick_lang("Options", "設定", context), icon='PREFERENCES')
                if getattr(s, "ui_section_main_options", False):
                    opt = box.box()
                    opt.prop(s, "same_index_selected_targets_only", text=_pick_lang("Selected target vertices only", "選択中の対象頂点のみ", context))
                    opt.prop(s, "exact_require_same_connectivity", text=_pick_lang("Validate same topology", "同一トポロジーを検証", context))
                    opt.prop(s, "target_mode", text=_pick_lang("Write to", "書き込み先", context))
                    if getattr(s, "target_mode", "MESH") != 'MESH':
                        opt.prop(s, "shape_key_name", text=_pick_lang("Shape Key", "シェイプキー", context))
                    row = opt.row(align=True)
                    row.prop(s, "copy_weights", text=_pick_lang("Weights", "ウェイト", context), toggle=True)
                    row.prop(s, "copy_uvs", text="UV", toggle=True)
                    row.prop(s, "copy_normals", text=_pick_lang("Normals", "法線", context), toggle=True)
                    if getattr(s, "copy_weights", False):
                        opt.prop(s, "weight_paste_mode", text=_pick_lang("Weight Mode", "ウェイト方式", context))

                aux_row = box.row(align=True)
                aux_row.prop(s, "ui_section_auxiliary", text="", emboss=False, icon='TRIA_DOWN' if getattr(s, "ui_section_auxiliary", False) else 'TRIA_RIGHT')
                aux_row.label(text=_pick_lang("Auxiliary", "補助機能", context), icon='MOD_DATA_TRANSFER')
                if getattr(s, "ui_section_auxiliary", False):
                    aux = box.box()
                    aux.prop(s, "paste_mode", text=_pick_lang("Mode", 'モード', context))
                    aux.prop(s, "target_object_mode", text=_pick_lang("Target", "対象", context))
                    if getattr(s, "target_object_mode", "ACTIVE") == 'NAMED':
                        aux.prop_search(s, "target_object_name", bpy.data, "objects", text=_pick_lang("Object", "オブジェクト", context))
                    elif getattr(s, "target_object_mode", "ACTIVE") == 'COLLECTION':
                        aux.prop_search(s, "target_collection_name", bpy.data, "collections", text=_pick_lang("Collection", "コレクション", context))
                        aux.prop(s, "batch_skip_source_object", text=_pick_lang("Skip source", "コピー元を除外", context))
                    elif getattr(s, "target_object_mode", "ACTIVE") == 'SELECTED':
                        aux.prop(s, "batch_skip_source_object", text=_pick_lang("Skip source", "コピー元を除外", context))
                    if getattr(s, "paste_mode", "EXACT") in {'MIRROR_EXACT', 'MIRROR_SMART'}:
                        row = aux.row(align=True)
                        row.prop(s, "mirror_axis", text=_pick_lang("Mirror Axis", "ミラー軸", context))
                        row.prop(s, "mirror_flip_group_names", text=_pick_lang("Flip Names", "名前反転", context))
                    if getattr(s, "paste_mode", "EXACT") == 'SURFACE_PROJECT':
                        aux.prop(s, "surface_project_bind_mode", text=_pick_lang("Project", '投影', context))
                        aux.prop(s, "project_max_distance", text=_pick_lang("Max Distance", "最大距離", context))
                    if getattr(s, "paste_mode", "EXACT") in {'SMART', 'MIRROR_SMART', 'SURFACE_PROJECT'}:
                        aux.prop(s, "smart_selected_only", text=_pick_lang("Selected candidates only", "選択候補のみ", context))
                        aux.prop(s, "smart_unique_match", text=_pick_lang("Unique match", "重複対応を防止", context))
                    row = aux.row(align=True)
                    _sms_layout_operator_if_registered(row, "vscp.paste_vertices", text=_pick_lang("Aux Paste", "補助貼り付け", context), icon='PASTEDOWN')
                    _sms_layout_operator_if_registered(row, "vscp.validate_targets", text=_pick_lang("Aux Check", "補助確認", context), icon='VIEWZOOM')
                    detail_row = aux.row(align=True)
                    detail_row.prop(s, "ui_section_expert_matching", text="", emboss=False, icon='TRIA_DOWN' if getattr(s, "ui_section_expert_matching", False) else 'TRIA_RIGHT')
                    detail_row.label(text=_pick_lang("Advanced", "詳細", context), icon='SETTINGS')
                    if getattr(s, "ui_section_expert_matching", False):
                        detail = aux.box()
                        detail.prop(s, "show_gpu_preview", text=_pick_lang("Preview", "プレビュー", context))
                        detail.prop(s, "enable_soft_wrap", text=_pick_lang("Soft Wrap", "ソフトラップ", context))
                        detail.prop(s, "filter_target_vertex_group", text=_pick_lang("Filter by vertex group", "頂点グループで絞り込み", context))
                        detail.prop(s, "filter_target_index_list", text=_pick_lang("Filter by index list", "番号リストで絞り込み", context))
                        detail.prop(s, "use_landmark_pairs", text=_pick_lang("Landmarks", "ランドマーク", context))
                        row = detail.row(align=True)
                        for preset_id, label_en, label_ja in (('EXACT_SAFE', 'Exact', '同番号'), ('NEAR_TOPO', 'Smart', 'Smart'), ('SURFACE_BARY', 'Surface', '投影'), ('WRAP_SOFT', 'Wrap', 'Wrap')):
                            op = row.operator("vscp.apply_preset", text=_pick_lang(label_en, label_ja, context))
                            op.preset = preset_id
                if getattr(s, "last_run_summary", ""):
                    box.label(text=str(s.last_run_summary), icon='TEXT')

        if _sms_enabled(context, "enable_connect", True):
            if _sms_draw_native_tool_load_box(layout, context, "connect", "Mesh Connect", icon='MOD_EDGESPLIT'):
                box = layout.box()
                box.label(text="Mesh Connect", icon='MOD_EDGESPLIT')
                row = box.row(align=True)
                row.scale_y = 1.1
                _sms_layout_operator_if_registered(row, "mesh.smart_connect", text="Connect Selection", icon='MOD_EDGESPLIT')

        if _sms_enabled(context, "enable_mesh_split", True):
            if _sms_draw_native_tool_load_box(layout, context, "mesh_split", "Mesh Split", icon='MOD_EDGESPLIT'):
                box = layout.box()
                box.label(text=_pick_lang("Mesh Split", "メッシュ分割", context), icon='MOD_EDGESPLIT')
                row = box.row(align=True)
                row.scale_y = 1.1
                _sms_layout_operator_if_registered(row, "mesh.smart_split", text=_pick_lang("Run Mesh Split", "メッシュ分割を実行", context), icon='MOD_EDGESPLIT')

        if _sms_enabled(context, "enable_mesh_align_preset", True):
            if _sms_draw_native_tool_load_box(layout, context, "mesh_align_preset", "Align / Flow", icon='EMPTY_ARROWS'):
                box = layout.box()
                box.label(text="Align / Flow", icon='ORIENTATION_GLOBAL')
                row = box.row(align=True)
                row.scale_y = 1.1
                row.operator_context = 'INVOKE_DEFAULT'
                row.operator("mesh.mesh_align_master", text="Open Align Presets", icon='EMPTY_ARROWS')
                row = box.row(align=True)
                _sms_layout_operator_if_registered(row, "mesh.align_x", text="X")
                _sms_layout_operator_if_registered(row, "mesh.align_y", text="Y")
                _sms_layout_operator_if_registered(row, "mesh.align_z", text="Z")
                row = box.row(align=True)
                row.operator("mesh.align_view", text="View")
                row.operator("mesh.align_linear_3d", text="Line")
                row.operator("mesh.set_flow", text="Set Flow")


class VIEW3D_PT_sms_hub_cleanup(bpy.types.Panel):
    bl_label = "Delete and Cleanup"
    bl_description = 'Compact cleanup tools that group direct delete and model organization.'
    bl_idname = "VIEW3D_PT_sms_hub_cleanup"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _sms_compact_n_panel_enabled(context) and _sms_any_enabled(
            context,
            "enable_direct_delete",
            "enable_model_organized",
        )

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False

        if _sms_enabled(context, "enable_direct_delete", True):
            if _sms_draw_native_tool_load_box(layout, context, "direct_delete", "Direct Delete", icon='TRASH'):
                dd = getattr(getattr(context, "window_manager", None), "direct_delete_settings", None)
                box = layout.box()
                box.label(text="Direct Delete", icon='TRASH')
                row = box.row(align=True)
                row.scale_y = 1.1
                row.operator("mesh.delete_direct", text="Delete Selection", icon='TRASH')
                row.operator("mesh.delete_direct_through", text="Through", icon='XRAY')
                if context.mode != 'EDIT_MESH':
                    row = box.row(align=True)
                    row.operator("object.delete_direct_objects", text="Delete Objects", icon='OUTLINER_OB_MESH')
                if dd:
                    row = box.row(align=True)
                    row.prop(dd, "smart_context", text="Context", toggle=True)
                    row.prop(dd, "topology_aware", text="Topo", toggle=True)
                    row.prop(dd, "auto_clean", text="Clean", toggle=True)
                    row = box.row(align=True)
                    row.prop(dd, "soft_delete", text="Soft", toggle=True)
                    row.prop(dd, "preview_overlay", text="Overlay", toggle=True)

        if _sms_enabled(context, "enable_model_organized", True):
            if _sms_draw_native_tool_load_box(layout, context, "model_organized", "Model Organizer", icon='OUTLINER_COLLECTION') and hasattr(context.scene, "mo2_props"):
                box = layout.box()
                box.label(text=_pick_lang("Model Organizer", "モデル整理", context), icon='OUTLINER_COLLECTION')
                module = None
                try:
                    module = _sms_native_tool_record("model_organized").get('module')
                except Exception:
                    module = None
                if module is None:
                    try:
                        module = _sms_native_module_from_meta(_sms_native_tool_meta("model_organized"), require_loaded=True)
                    except Exception:
                        module = None
                draw_fn = getattr(module, 'draw_smart_modeling_settings', None) if module is not None else None
                if callable(draw_fn):
                    try:
                        draw_fn(box.column(align=False), context)
                    except Exception as exc:
                        warn = box.box(); warn.alert = True
                        warn.label(text=_pick_lang(f"Model Organizer UI error: {str(exc)[:160]}", f"モデル整理UIエラー: {str(exc)[:160]}", context), icon='ERROR')
                else:
                    mo2 = context.scene.mo2_props
                    box.prop(mo2, "preset", text=_pick_lang("Preset", "プリセット", context))
                    row = box.row(align=True)
                    row.scale_y = 1.1
                    row.operator("mo2.organize_modal", text=_pick_lang("Organize Selection", "選択オブジェクトを整理", context), icon='OUTLINER_COLLECTION')
                    row.operator("mo2.restore_backup", text=_pick_lang("Restore Backup", "バックアップを復元", context), icon='LOOP_BACK')
                    row.operator("mo2.clear_backup", text="", icon='TRASH')


class VIEW3D_PT_sms_hub_surface(bpy.types.Panel):
    bl_label = "Hard Surface Modeling"
    bl_description = 'Compact hard-surface helpers for crease, normals, and snap state control.'
    bl_idname = "VIEW3D_PT_sms_hub_surface"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _sms_compact_n_panel_enabled(context) and _sms_any_enabled(
            context,
            "enable_crease_preset",
            "enable_apply_weighted_normal",
            "enable_toggle_auto_merge_snap",
        )

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False
        suite_prefs = _sms_get_suite_prefs(context)

        if _sms_enabled(context, "enable_crease_preset", True):
            if _sms_draw_native_tool_load_box(layout, context, "crease_preset", "Crease", icon='MOD_BEVEL'):
                cp = getattr(suite_prefs, "crease_preset", None) if suite_prefs else None
                box = layout.box()
                box.label(text="Crease", icon='MOD_BEVEL')
                row = box.row(align=True)
                for value, label in ((0.0, "0"), (0.25, "0.25"), (0.5, "0.5"), (1.0, "1.0")):
                    op = row.operator("mesh.crease_apply", text=label)
                    op.crease_value = value
                    op.apply_mode = 'SELECTED'
                row = box.row(align=True)
                row.operator_context = 'INVOKE_DEFAULT'
                row.operator("mesh.edge_crease_master", text="Preset Menu", icon='PRESET')
                row.operator_context = 'EXEC_DEFAULT'
                row.operator("view3d.toggle_edge_crease_overlay", text="", icon='OVERLAY')
                if cp:
                    row = box.row(align=True)
                    row.prop(cp, "use_pie_menu", text="Pie", toggle=True)
                    row.prop(cp, "linked_delimit_seam", text="Seam", toggle=True)
                    row.prop(cp, "linked_delimit_sharp", text="Sharp", toggle=True)

        if _sms_enabled(context, "enable_apply_weighted_normal", True):
            if _sms_draw_native_tool_load_box(layout, context, "apply_weighted_normal", "Weighted Normal", icon='MOD_NORMALEDIT'):
                awn = getattr(suite_prefs, "apply_weighted_normal", None) if suite_prefs else None
                box = layout.box()
                box.label(text="Weighted Normal", icon='MOD_NORMALEDIT')
                if awn:
                    row = box.row(align=True)
                    row.prop(awn, "preset", text="")
                    row.prop(awn, "apply_mode", text="")
                info = box.column(align=True)
                row = box.row(align=True)
                row.scale_y = 1.1
                op = row.operator("mesh.apply_weighted_normal", text=_pick_lang('Run', '実行', context), icon='MOD_NORMALEDIT')
                if awn:
                    try:
                        op.preset = awn.preset
                        op.apply_mode = awn.apply_mode
                        op.limit_to_selection = awn.limit_to_selection
                        op.keep_sharp = awn.keep_sharp
                        op.weight = awn.weight
                        op.threshold = awn.threshold
                    except Exception:
                        pass

        if _sms_enabled(context, "enable_toggle_auto_merge_snap", True):
            if _sms_draw_native_tool_load_box(layout, context, "toggle_auto_merge_snap", "Merge / Snap", icon='SNAP_ON'):
                tams = getattr(suite_prefs, "toggle_auto_merge_snap", None) if suite_prefs else None
                box = layout.box()
                box.label(text="Merge / Snap", icon='SNAP_ON')
                row = box.row(align=True)
                row.scale_y = 1.1
                _sms_layout_operator_if_registered(row, "mesh.toggle_merge_snap", text="Toggle", icon='SNAP_ON')
                _sms_layout_operator_if_registered(row, "mesh.tams_cycle_snap", text="Cycle", icon='FILE_REFRESH')
                row.operator_context = 'INVOKE_DEFAULT'
                _sms_layout_operator_if_registered(row, "mesh.tams_quick_popup", text="", icon='PREFERENCES')
                if tams:
                    row = box.row(align=True)
                    row.prop(tams, "toggle_basis", text="")
                    row.prop(tams, "enable_cycling", text="Cycling", toggle=True)


class VIEW3D_PT_sms_hub_sketch(bpy.types.Panel):
    bl_label = "Sketch and Retopo"
    bl_description = 'Compact sketch and retopo hub that groups annotation conversion and quad-strip helpers.'
    bl_idname = "VIEW3D_PT_sms_hub_sketch"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _sms_compact_n_panel_enabled(context) and _sms_any_enabled(
            context,
            "enable_sketch_tools",
            "enable_quad_strip_draw",
        )

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False

        if _sms_enabled(context, "enable_sketch_tools", True):
            if _sms_draw_native_tool_load_box(layout, context, "sketch_tools", "Sketch Surface", icon='GREASEPENCIL') and hasattr(context.scene, "smsk_props"):
                sk = context.scene.smsk_props
                box = layout.box()
                box.label(text="Sketch Surface", icon='GREASEPENCIL')
                row = box.row(align=True)
                row.scale_y = 1.1
                row.operator("smsk.annotation_to_curve", text="To Curve", icon='CURVE_DATA')
                row.operator("smsk.annotation_to_surface_strip", text="To Strip", icon='MESH_DATA')
                row = box.row(align=True)
                row.prop(sk, "active_layer_only", text="Active Layer", toggle=True)
                row.prop(sk, "close_curve", text="Close", toggle=True)
                row = box.row(align=True)
                row.prop(sk, "bevel_depth", text="Bevel")
                row.prop(sk, "surface_width", text="Width")

        if _sms_enabled(context, "enable_quad_strip_draw", True):
            if _sms_draw_native_tool_load_box(layout, context, "quad_strip_draw", "Quad Strip / Retopo", icon='MESH_GRID') and hasattr(context.scene, "qsd_draw_toggle"):
                scn = context.scene
                box = layout.box()
                box.label(text="Quad Strip / Retopo", icon='MESH_GRID')
                row = box.row(align=True)
                row.scale_y = 1.1
                row.prop(scn, "qsd_draw_toggle", text="Draw", toggle=True)
                row.prop(scn, "qsd_retopo_mode", text="Retopo", toggle=True)
                row = box.row(align=True)
                row.prop(scn, "qsd_plane_mode", text="")
                row.prop(scn, "qsd_use_surface_snap", text="Snap", toggle=True)
                row = box.row(align=True)
                row.operator_context = 'INVOKE_DEFAULT'
                row.operator("mesh.qsd_retopo_setup_popup", text="Setup", icon='MOD_SHRINKWRAP')
                row.operator("mesh.qsd_guides_popup", text="Guides", icon='CURVE_DATA')
                row = box.row(align=True)
                row.operator_context = 'INVOKE_DEFAULT'
                row.operator("mesh.qsd_field_paint_popup", text="Field", icon='BRUSH_DATA')
                row.operator("mesh.qsd_fill_tools_popup", text="Fill", icon='MESH_GRID')
                row.operator("mesh.qsd_boundary_trace_popup", text="Boundary", icon='TRACKING_FORWARDS')

# ------------------------------------------------------------
# Registration
# ------------------------------------------------------------

_SMS_NATIVE_RECOVERED_CLASSES = []
_SMS_NATIVE_ACCESS_PANEL_CLASSES = []
_SMS_NATIVE_TOOL_RECORDS = {}
_SMS_NATIVE_TOOL_META = (
    {
        'tool_id': 'vertex_copy',
        'label': 'Vertex Copy',
        'module_path': 'vertex_copy',
        'toggle': 'enable_vertex_copy',
        'parent': 'VIEW3D_PT_sms_hub_edit',
        'icon': 'COPYDOWN',
    },
    {
        'tool_id': 'vertex_slide',
        'label': 'Vertex Slide',
        'module_path': 'vertex_slide',
        'toggle': 'enable_vertex_slide',
        'parent': 'VIEW3D_PT_sms_hub_edit',
        'icon': 'EMPTY_ARROWS',
    },
    {
        'tool_id': 'connect',
        'label': 'Mesh Connect',
        'module_path': 'connect',
        'toggle': 'enable_connect',
        'parent': 'VIEW3D_PT_sms_hub_edit',
        'icon': 'MOD_EDGESPLIT',
    },
    {
        'tool_id': 'mesh_split',
        'label': 'Mesh Split',
        'module_path': 'mesh_split',
        'toggle': 'enable_mesh_split',
        'parent': 'VIEW3D_PT_sms_hub_edit',
        'icon': 'MOD_EDGESPLIT',
    },
    {
        'tool_id': 'mesh_align_preset',
        'label': 'Mesh Align',
        'module_path': 'mesh_align_preset',
        'toggle': 'enable_mesh_align_preset',
        'parent': 'VIEW3D_PT_sms_hub_edit',
        'icon': 'EMPTY_ARROWS',
    },
    {
        'tool_id': 'direct_delete',
        'label': 'Direct Delete',
        'module_path': 'direct_delete',
        'toggle': 'enable_direct_delete',
        'parent': 'VIEW3D_PT_sms_hub_cleanup',
        'icon': 'TRASH',
    },
    {
        'tool_id': 'model_organized',
        'label': 'Model Organizer',
        'module_path': 'model_organized',
        'toggle': 'enable_model_organized',
        'parent': 'VIEW3D_PT_sms_hub_cleanup',
        'icon': 'OUTLINER_COLLECTION',
    },
    {
        'tool_id': 'crease_preset',
        'label': 'Crease Preset',
        'module_path': 'crease_preset',
        'toggle': 'enable_crease_preset',
        'parent': 'VIEW3D_PT_sms_hub_surface',
        'icon': 'MOD_BEVEL',
    },
    {
        'tool_id': 'toggle_auto_merge_snap',
        'label': 'Merge Snap',
        'module_path': 'toggle_auto_merge_snap',
        'toggle': 'enable_toggle_auto_merge_snap',
        'parent': 'VIEW3D_PT_sms_hub_surface',
        'icon': 'SNAP_ON',
    },
    {
        'tool_id': 'apply_weighted_normal',
        'label': 'Weighted Normal',
        'module_path': 'apply_weighted_normal',
        'toggle': 'enable_apply_weighted_normal',
        'parent': 'VIEW3D_PT_sms_hub_surface',
        'icon': 'MOD_NORMALEDIT',
    },
    {
        'tool_id': 'sketch_tools',
        'label': 'Sketch Surface',
        'module_path': 'sketch_tools',
        'toggle': 'enable_sketch_tools',
        'parent': 'VIEW3D_PT_sms_hub_sketch',
        'icon': 'GREASEPENCIL',
    },
    {
        'tool_id': 'quad_strip_draw',
        'label': 'Quad Retopo',
        'module_path': 'quad_strip_draw',
        'toggle': 'enable_quad_strip_draw',
        'parent': 'VIEW3D_PT_sms_hub_sketch',
        'icon': 'MESH_GRID',
    },
    {
        'tool_id': 'modeling_toolset_tools',
        'label': 'Modeling Toolkit',
        'module_path': 'modeling_toolset_tools',
        'toggle': 'enable_modeling_toolset_tools',
        'parent': 'VIEW3D_PT_sms_hub',
        'icon': 'TOOL_SETTINGS',
    },
)


# Native tools whose operator IDs are shown as keymap-registration targets in
# the Smart Modeling N-panel.  v1.2.49 keeps those IDs available through tiny
# lazy proxy operators instead of loading the full tool modules at startup.
# The real module is imported only when the shortcut/F3 command or another
# explicit tool command is executed.  Opening Settings displays static UI only.
_SMS_KEYMAP_STARTUP_NATIVE_TOOL_IDS = tuple(
    tool_id for tool_id in _SMS_NATIVE_KEYMAP_INFO.keys()
    if any(str(meta.get('tool_id') or '').strip() == tool_id for meta in _SMS_NATIVE_TOOL_META)
)

# Old Smart Modeling releases exposed a small number of public compatibility
# operator IDs.  Existing user keymaps keep those exact IDs, so they need the
# same zero-idle first-use shells as the canonical IDs.  These aliases stay out
# of the visible keymap-registration list to avoid presenting duplicate choices.
_SMS_NATIVE_KEYMAP_COMPAT_ALIASES: dict[str, dict[str, str]] = {
    'connect': {
        'mesh.connect': 'mesh.smart_connect',
    },
}


_SMS_LAZY_KEYMAP_PROXY_CLASSES: dict[str, type] = {}
_SMS_LAZY_KEYMAP_PROXY_TOOL_BY_IDNAME: dict[str, str] = {}
_SMS_LAZY_KEYMAP_PROXY_ACTIVE: set[str] = set()
_SMS_LAZY_KEYMAP_DELEGATING: set[str] = set()
_SMS_LAZY_KEYMAP_PRESERVE_IDNAMES: set[str] = set()
_SMS_LAZY_KEYMAP_SOURCE_CLASSES: dict[str, type] = {}
_SMS_LAZY_KEYMAP_DECLARED_IDNAMES = frozenset(
    str((entry or {}).get('idname') or '').strip()
    for entries in _SMS_NATIVE_KEYMAP_INFO.values()
    for entry in tuple(entries or ())
    if str((entry or {}).get('idname') or '').strip()
) | frozenset(
    str(alias_idname or '').strip()
    for aliases in _SMS_NATIVE_KEYMAP_COMPAT_ALIASES.values()
    for alias_idname in aliases.keys()
    if str(alias_idname or '').strip()
)
# The lightweight first-use shell must carry the same operation-history flags as
# the unloaded real operator.  Otherwise the first key event can execute the
# mutation but miss the real operator's single Undo owner.  These are bounded,
# static declarations; they do not import any feature module at startup.
_SMS_LAZY_KEYMAP_UNDO_TOOL_IDS = frozenset({
    'vertex_copy',
    'model_organized',
    'toggle_auto_merge_snap',
    'apply_weighted_normal',
    'sketch_tools',
    'quad_strip_draw',
    'modeling_toolset_tools',
})
_SMS_LAZY_KEYMAP_EXTRA_OPTIONS_BY_IDNAME = {
    'mesh.quad_strip_draw': frozenset({'BLOCKING'}),
}
_SMS_LAZY_SAME_EVENT_UNAVAILABLE = object()
_SMS_OPERATOR_CLASS_INDEX: dict[str, type] | None = None
_SMS_LAZY_PROXY_DIRECT_HELPERS: dict[tuple[str, str], str] = {
    ('connect', 'mesh.smart_connect'): 'execute_smart_connect',
    ('connect', 'mesh.connect'): 'execute_smart_connect',
    ('vertex_slide', 'mesh.smart_vert_slide'): 'execute_vertex_slide_toggle_safe',
    # Popup owners must stay registered for the entire modal lifetime.  Route
    # the first shortcut invocation through the current lazy proxy instance
    # instead of unregistering/replacing its RNA class while Blender owns the
    # popup wmOperator pointer.
    ('mesh_align_preset', 'mesh.mesh_align_master'): 'invoke_mesh_align_popup',
    ('crease_preset', 'mesh.edge_crease_master'): 'invoke_crease_preset_menu',
    # Direct Delete shortcut proxies must not unregister their own operator
    # class while Blender is still inside invoke/execute. Doing so can leave
    # Blender 5.1 with a dangling RNA/operator pointer and crash in
    # WM_operator_pystring_ex / wm_operator_reports. Route those ids through
    # direct helpers instead.
    ('direct_delete', 'mesh.delete_direct'): 'execute_delete_direct_smart',
    ('direct_delete', 'mesh.delete_direct_del'): 'execute_delete_direct_del',
    ('direct_delete', 'mesh.delete_direct_bs'): 'execute_delete_direct_bs',
    ('direct_delete', 'mesh.delete_direct_through'): 'execute_delete_direct_through',
    ('direct_delete', 'object.delete_direct_objects'): 'execute_delete_direct_objects',
    ('direct_delete', 'object.delete_history_modifiers'): 'execute_delete_history_modifiers',
}
_SMS_LAZY_PROXY_POPUP_HELPERS: set[tuple[str, str]] = {
    ('mesh_align_preset', 'mesh.mesh_align_master'),
    ('crease_preset', 'mesh.edge_crease_master'),
}
_SMS_LAZY_PROXY_POPUP_DRAW_HELPERS: dict[tuple[str, str], str] = {
    ('mesh_align_preset', 'mesh.mesh_align_master'): '_msap_draw_mesh_align_master_layout',
    ('crease_preset', 'mesh.edge_crease_master'): '_draw_crease_preset_layout',
}
_SMS_EXPLICIT_SETTINGS_LOAD_SECTIONS: set[str] = set()


def _sms_iter_native_keymap_specs(tool_id: str | None = None):
    requested = str(tool_id or '').strip()
    for _tool_id, entries in tuple(_SMS_NATIVE_KEYMAP_INFO.items()):
        if requested and _tool_id != requested:
            continue
        canonical_entries = tuple(entries or ())
        for entry in canonical_entries:  # pragma: no branch
            idname = str((entry or {}).get('idname') or '').strip()
            if idname:
                yield _tool_id, entry
        aliases = _SMS_NATIVE_KEYMAP_COMPAT_ALIASES.get(_tool_id, {})
        for alias_idname, canonical_idname in tuple(aliases.items()):
            alias_idname = str(alias_idname or '').strip()
            canonical_idname = str(canonical_idname or '').strip()
            if not alias_idname:
                continue
            source_entry = next(
                (
                    entry for entry in canonical_entries
                    if str((entry or {}).get('idname') or '').strip() == canonical_idname
                ),
                None,
            )
            if not isinstance(source_entry, dict):
                continue
            alias_entry = dict(source_entry)
            alias_entry['idname'] = alias_idname
            alias_entry['_sms_compat_alias_for'] = canonical_idname
            yield _tool_id, alias_entry


def _sms_keymap_idnames_for_native_tool(tool_id: str) -> tuple[str, ...]:
    return tuple(str((entry or {}).get('idname') or '').strip() for _tid, entry in _sms_iter_native_keymap_specs(tool_id) if str((entry or {}).get('idname') or '').strip())


def _sms_operator_registered_idname(idname: str) -> bool:
    idname = str(idname or '').strip()
    if not idname or '.' not in idname:
        return False
    try:
        op_base = getattr(bpy.types, 'Operator', None)
        getter = getattr(op_base, 'bl_rna_get_subclass_py', None) if op_base is not None else None
        if callable(getter) and getter(idname, None) is not None:
            return True
    except Exception:
        pass
    # Do not resolve bpy.ops.* here.  On Blender 5.1 Windows stale Macro
    # operators can crash inside WM_operator_properties_create_ptr while merely
    # resolving operator RNA during install/reinstall.
    return False


def _sms_operator_class_index() -> dict[str, type]:
    """Return the bounded exact cache without scanning the global RNA registry."""
    global _SMS_OPERATOR_CLASS_INDEX
    if not isinstance(_SMS_OPERATOR_CLASS_INDEX, dict):
        _SMS_OPERATOR_CLASS_INDEX = {}
    return _SMS_OPERATOR_CLASS_INDEX


def _sms_cache_operator_class(idname: str, cls) -> None:
    if not isinstance(cls, type):
        return
    try:
        index = _sms_operator_class_index()
        index[str(idname or '').strip()] = cls
    except Exception:
        pass


def _sms_uncache_operator_class(idname: str, cls=None) -> None:
    global _SMS_OPERATOR_CLASS_INDEX
    if not isinstance(_SMS_OPERATOR_CLASS_INDEX, dict):
        return
    key = str(idname or '').strip()
    current = _SMS_OPERATOR_CLASS_INDEX.get(key)
    if cls is None or current is cls:
        _SMS_OPERATOR_CLASS_INDEX.pop(key, None)


def _sms_operator_class_by_idname(idname: str):
    idname = str(idname or '').strip()
    if not idname:
        return None
    candidates = []
    try:
        namespace, op_name = idname.split('.', 1)
        safe_namespace = ''.join(ch if ch.isalnum() else '_' for ch in namespace).upper()
        safe_op_name = ''.join(ch if ch.isalnum() else '_' for ch in op_name).strip('_')
        if safe_namespace and safe_op_name:
            candidates.append(f'{safe_namespace}_OT_{safe_op_name}')
            candidates.append(f'{safe_namespace}_OT_{safe_op_name.upper()}')
    except Exception:
        pass
    try:
        op_base = getattr(bpy.types, 'Operator', None)
        getter = getattr(op_base, 'bl_rna_get_subclass_py', None) if op_base is not None else None
        if callable(getter):
            for key in (idname, *candidates):
                cls = getter(key, None)
                if isinstance(cls, type):
                    try:
                        if str(getattr(cls, 'bl_idname', '') or '').strip() == idname:
                            _sms_cache_operator_class(idname, cls)
                            return cls
                    except Exception:
                        _sms_cache_operator_class(idname, cls)
                        return cls
    except Exception:
        pass
    try:
        for key in candidates:
            cls = getattr(bpy.types, key, None)
            if isinstance(cls, type) and str(getattr(cls, 'bl_idname', '') or '').strip() == idname:
                _sms_cache_operator_class(idname, cls)
                return cls
    except Exception:
        pass
    # Stale proxies created by older builds can have non-canonical Python class
    # names.  A single indexed scan preserves that cleanup compatibility without
    # repeating dir(bpy.types) for every one of the 49 startup proxy ids.
    cls = _sms_operator_class_index().get(idname)
    if isinstance(cls, type):
        try:
            if str(getattr(cls, 'bl_idname', '') or '').strip() == idname:
                return cls
        except Exception:
            pass
        _sms_uncache_operator_class(idname, cls)
    return None


def _sms_is_lazy_proxy_class(cls) -> bool:
    try:
        return bool(getattr(cls, '_sms_lazy_keymap_proxy', False))
    except Exception:
        return False


def _sms_make_lazy_proxy_class_name(idname: str) -> str:
    try:
        namespace, op_name = str(idname or '').strip().split('.', 1)
    except Exception:
        namespace, op_name = 'smslazy', str(idname or 'operator')
    namespace = ''.join(ch if ch.isalnum() else '_' for ch in namespace).strip('_').upper() or 'SMSLAZY'
    op_name = ''.join(ch if ch.isalnum() else '_' for ch in op_name).strip('_') or 'operator'
    # Match Blender's namespace_OT_operator naming convention so registration
    # stays warning-free and old proxy classes are easy to identify by idname.
    return f'{namespace}_OT_{op_name}'


def _sms_call_operator_by_idname(idname: str, *, invoke: bool = False):
    namespace, op_name = str(idname or '').split('.', 1)
    op_ns = getattr(bpy.ops, namespace, None)
    op = getattr(op_ns, op_name, None) if op_ns is not None else None
    if op is None:
        return {'CANCELLED'}
    try:
        if invoke:
            return op('INVOKE_DEFAULT')
    except Exception:
        # Some operators do not implement invoke or cannot be invoked from the
        # current context.  Fall back to execute so keymap/F3 calls still reach the
        # real implementation when possible.
        pass
    try:
        return op('EXEC_DEFAULT')
    except Exception:
        raise


def _sms_unregister_lazy_keymap_proxy_idname(idname: str, *, destroy: bool = False) -> bool:
    idname = str(idname or '').strip()
    if not destroy and (idname in _SMS_LAZY_KEYMAP_DELEGATING or idname in _SMS_LAZY_KEYMAP_PRESERVE_IDNAMES):
        return False
    # During normal lazy delegation, keep the registered RNA class alive: the
    # real implementation is patched into that class in place so Blender never
    # observes a dangling wmOperator pointer.  At the add-on lifecycle boundary,
    # however, no delegated operator is active and the dynamic proxy RNA must be
    # unregistered so disable/re-enable leaves no stale operators behind.
    if destroy:
        cls = _SMS_LAZY_KEYMAP_PROXY_CLASSES.get(idname)
        if not isinstance(cls, type):
            cls = _sms_operator_class_by_idname(idname)
        if isinstance(cls, type) and _sms_is_lazy_proxy_class(cls):
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass
    _SMS_LAZY_KEYMAP_PROXY_ACTIVE.discard(idname)
    _sms_uncache_operator_class(idname, cls if 'cls' in locals() else None)
    _SMS_LAZY_KEYMAP_PROXY_CLASSES.pop(idname, None)
    _SMS_LAZY_KEYMAP_PROXY_TOOL_BY_IDNAME.pop(idname, None)
    try:
        _sms_rebuild_native_tool_records()
    except Exception:
        pass
    return True


def _sms_unregister_lazy_keymap_proxies_for_tool(tool_id: str, *, destroy: bool = False) -> None:
    for idname in _sms_keymap_idnames_for_native_tool(tool_id):
        _sms_unregister_lazy_keymap_proxy_idname(idname, destroy=destroy)


def _sms_unregister_all_lazy_keymap_proxies(*, destroy: bool = False) -> None:
    idnames = set(_SMS_LAZY_KEYMAP_PROXY_CLASSES.keys())
    if destroy:
        # Loaded native tools may have been patched into a proxy class after its
        # runtime map entry was cleared.  Include every declared shortcut target
        # so final teardown can still find and unregister those live classes.
        try:
            idnames.update(
                str((entry or {}).get('idname') or '').strip()
                for _tool_id, entry in _sms_iter_native_keymap_specs()
                if str((entry or {}).get('idname') or '').strip()
            )
        except Exception:
            pass
    for idname in tuple(idnames):
        _sms_unregister_lazy_keymap_proxy_idname(idname, destroy=destroy)
    _SMS_LAZY_KEYMAP_PROXY_TOOL_BY_IDNAME.clear()
    _SMS_LAZY_KEYMAP_PROXY_ACTIVE.clear()
    if destroy:
        _SMS_LAZY_KEYMAP_SOURCE_CLASSES.clear()


def _sms_normalize_direct_helper_result(result):
    """Return a terminal result for the lazy proxy that launched a child.

    Direct helpers are plain Python functions; they cannot own Blender's modal
    handler.  When such a helper launches a child popup and returns
    ``RUNNING_MODAL``, propagating that status would incorrectly make the lazy
    proxy itself a modal operator even though it has no modal callback.  Finish
    the proxy immediately and leave modal ownership exclusively with the child.
    """
    try:
        status = set(result or ())
    except Exception:
        status = set()
    if 'RUNNING_MODAL' in status or 'FINISHED' in status:
        return {'FINISHED'}
    return {'CANCELLED'}


def _sms_record_native_keymap_failure(tool_id: str, message) -> str:
    tool_id = str(tool_id or '').strip()
    if isinstance(message, BaseException):
        detail = ''.join(traceback.format_exception_only(type(message), message)).strip()
    else:
        detail = str(message or '').strip()
    detail = detail[:1024] or 'Native shortcut activation failed.'
    try:
        state = _sms_native_tool_state(tool_id)
        state['error'] = detail
        if str(state.get('status') or '').strip().lower() == 'loading':
            state['status'] = 'failed'
    except Exception:
        pass
    return detail


def _sms_report_native_keymap_failure(operator, tool_id: str, fallback='') -> None:
    excerpt = ''
    try:
        excerpt = _sms_native_tool_error_excerpt(tool_id)
    except Exception:
        excerpt = ''
    message = excerpt or str(fallback or '').strip() or 'Native shortcut activation failed.'
    try:
        reporter = getattr(operator, 'report', None)
        if callable(reporter):
            reporter({'ERROR'}, f'Smart Modeling: {message[:240]}')
    except Exception:
        pass


def _sms_try_direct_lazy_proxy_delegate(
    tool_id: str,
    idname: str,
    context=None,
    *,
    invoke: bool = False,
    operator=None,
    event=None,
    captured_values=None,
):
    helper_name = _SMS_LAZY_PROXY_DIRECT_HELPERS.get((str(tool_id or '').strip(), str(idname or '').strip()))
    if not helper_name:
        return None
    meta = _sms_native_tool_meta(tool_id)
    if not isinstance(meta, dict):
        _sms_record_native_keymap_failure(tool_id, 'Native shortcut metadata is unavailable.')
        _sms_report_native_keymap_failure(operator, tool_id)
        return {'CANCELLED'}
    ctx = context or getattr(bpy, 'context', None)
    protected_idname = str(idname or '').strip()
    _SMS_LAZY_KEYMAP_PRESERVE_IDNAMES.add(protected_idname)
    try:
        try:
            ok = bool(_sms_ensure_native_tool_loaded(tool_id, context=ctx))
        except Exception as exc:
            _sms_record_native_keymap_failure(tool_id, exc)
            ok = False
        if not ok:
            _sms_report_native_keymap_failure(operator, tool_id, 'The native tool could not be loaded.')
            return {'CANCELLED'}
        try:
            _sms_sync_lazy_ui_settings_to_runtime(
                'native',
                tool_id,
                context=ctx,
                captured_values=dict(captured_values or {}),
            )
        except Exception:
            pass
        module = _sms_native_module_from_meta(meta, require_loaded=False)
        helper = getattr(module, helper_name, None) if module is not None else None
        if not callable(helper):
            _sms_record_native_keymap_failure(tool_id, f'Missing shortcut entry point: {helper_name}')
            _sms_report_native_keymap_failure(operator, tool_id)
            return {'CANCELLED'}
        helper_key = (str(tool_id or '').strip(), str(idname or '').strip())
        if helper_key in _SMS_LAZY_PROXY_POPUP_HELPERS:
            # Preserve the current wmOperator instance.  Creating a Python-side
            # operator instance or unregistering this proxy while invoke_popup
            # is active leaves Blender with an invalid popup owner and causes
            # the first key press to be lost (or can crash on teardown).
            result = helper(
                ctx,
                invoke=invoke,
                operator=operator,
                event=event,
            )
            # The lazy proxy itself is the popup owner and implements draw(),
            # so RUNNING_MODAL must be propagated.  Normalizing it to FINISHED
            # closes the popup immediately and makes the first shortcut appear
            # to do nothing.
            return result
        try:
            result = helper(ctx, invoke=invoke)
        except TypeError:
            result = helper(ctx)
        return _sms_normalize_direct_helper_result(result)
    except Exception as exc:
        _sms_record_native_keymap_failure(tool_id, exc)
        _sms_report_native_keymap_failure(operator, tool_id)
        return {'CANCELLED'}
    finally:
        # Keep protection active for the complete helper call, not only module
        # registration. The helper may launch another operator before returning.
        _SMS_LAZY_KEYMAP_PRESERVE_IDNAMES.discard(protected_idname)


def _sms_lazy_deferred_property_default(deferred):
    """Return the declared default for one lazily loaded Operator property."""
    try:
        keywords = getattr(deferred, 'keywords', None)
    except Exception:
        keywords = None
    if not isinstance(keywords, dict):
        return _SMS_LAZY_SAME_EVENT_UNAVAILABLE
    if 'default' in keywords:
        value = keywords.get('default')
    else:
        try:
            function_name = str(getattr(getattr(deferred, 'function', None), '__name__', '') or '')
        except Exception:
            function_name = ''
        if function_name == 'BoolProperty':
            value = False
        elif function_name == 'IntProperty':
            value = 0
        elif function_name == 'FloatProperty':
            value = 0.0
        elif function_name == 'StringProperty':
            value = ''
        elif function_name == 'EnumProperty':
            items = keywords.get('items')
            if not isinstance(items, (tuple, list)) or not items:
                return _SMS_LAZY_SAME_EVENT_UNAVAILABLE
            try:
                value = items[0][0]
            except Exception:
                return _SMS_LAZY_SAME_EVENT_UNAVAILABLE
        elif function_name in {'BoolVectorProperty', 'IntVectorProperty', 'FloatVectorProperty'}:
            size = max(1, int(keywords.get('size', 3) or 3))
            scalar = False if function_name == 'BoolVectorProperty' else (0 if function_name == 'IntVectorProperty' else 0.0)
            value = tuple(scalar for _index in range(size))
        else:
            return _SMS_LAZY_SAME_EVENT_UNAVAILABLE
    if isinstance(value, dict):
        return dict(value)
    if isinstance(value, list):
        return list(value)
    if isinstance(value, set):
        return set(value)
    return value


def _sms_seed_lazy_operator_defaults(operator, source_cls) -> None:
    """Seed missing source defaults on the already-running lightweight shell.

    The real Operator RNA cannot be re-created while Blender owns the first key
    event's wmOperator pointer.  Default values are therefore copied only to that
    live Python instance before its real invoke/execute method is called.  Any
    value already supplied by Blender or a keymap is preserved unchanged.
    """
    if operator is None or not isinstance(source_cls, type):
        return
    try:
        annotations = dict(getattr(source_cls, '__dict__', {}).get('__annotations__', {}) or {})
    except Exception:
        annotations = {}
    for name, deferred in annotations.items():
        try:
            getattr(operator, name)
            continue
        except Exception:
            pass
        value = _sms_lazy_deferred_property_default(deferred)
        if value is _SMS_LAZY_SAME_EVENT_UNAVAILABLE:
            continue
        try:
            setattr(operator, name, value)
        except Exception:
            pass


def _sms_run_loaded_lazy_operator_same_event(
    tool_id: str,
    idname: str,
    context,
    operator,
    *,
    invoke: bool,
    event=None,
):
    """Run the real implementation on the first key event's wmOperator.

    Re-entering the same ``bpy.ops`` ID after lazy registration can route back to
    Blender's original shell callback and consume the first key press.  The
    source class captured during this exact module registration is instead
    invoked directly on the current shell instance, preserving its Event,
    popup/modal ownership, context and one-operation Undo lifetime.
    """
    del tool_id
    if operator is None:
        return _SMS_LAZY_SAME_EVENT_UNAVAILABLE
    source_cls = _SMS_LAZY_KEYMAP_SOURCE_CLASSES.get(str(idname or '').strip())
    if not isinstance(source_cls, type):
        return _SMS_LAZY_SAME_EVENT_UNAVAILABLE
    try:
        if str(getattr(source_cls, 'bl_idname', '') or '').strip() != str(idname or '').strip():
            return _SMS_LAZY_SAME_EVENT_UNAVAILABLE
        if not _sms_exact_class_belongs_to_current_package(source_cls):
            return _SMS_LAZY_SAME_EVENT_UNAVAILABLE
    except Exception:
        return _SMS_LAZY_SAME_EVENT_UNAVAILABLE
    try:
        poll_method = getattr(source_cls, 'poll', None)
        if callable(poll_method) and not bool(poll_method(context)):
            return {'CANCELLED'}
    except Exception:
        return {'CANCELLED'}
    _sms_seed_lazy_operator_defaults(operator, source_cls)
    method = getattr(source_cls, 'invoke' if invoke else 'execute', None)
    call_with_event = bool(invoke and callable(method))
    if not callable(method) and invoke:
        method = getattr(source_cls, 'execute', None)
        call_with_event = False
    if not callable(method):
        return _SMS_LAZY_SAME_EVENT_UNAVAILABLE
    if call_with_event:
        return method(operator, context, event)
    return method(operator, context)



def _sms_patch_and_run_native_lazy_operator_same_event(
    tool_id: str,
    idname: str,
    context,
    operator,
    *,
    invoke: bool,
    event=None,
    proxy_invoke=None,
    proxy_execute=None,
):
    """Patch the live lazy shell and run the native method on the first event.

    The exact source class captured during this package's native registration is
    copied into the still-registered shell with the same in-place loader used by
    integrated tools.  Blender's live ``wmOperator`` RNA owner, keymap-supplied
    properties, ``self`` and ``event`` therefore remain valid for the entire call.
    """
    tool_id = str(tool_id or '').strip()
    idname = str(idname or '').strip()
    if operator is None or not idname:
        return _SMS_LAZY_SAME_EVENT_UNAVAILABLE
    live_cls = type(operator)
    source_cls = _SMS_LAZY_KEYMAP_SOURCE_CLASSES.get(idname)
    if not (isinstance(live_cls, type) and isinstance(source_cls, type)):
        return _SMS_LAZY_SAME_EVENT_UNAVAILABLE
    try:
        if str(getattr(live_cls, 'bl_idname', '') or '').strip() != idname:
            return _SMS_LAZY_SAME_EVENT_UNAVAILABLE
        if str(getattr(source_cls, 'bl_idname', '') or '').strip() != idname:
            return _SMS_LAZY_SAME_EVENT_UNAVAILABLE
        if not _sms_is_lazy_proxy_class(live_cls):
            return _SMS_LAZY_SAME_EVENT_UNAVAILABLE
        if not _sms_exact_class_belongs_to_current_package(source_cls):
            return _SMS_LAZY_SAME_EVENT_UNAVAILABLE
    except Exception:
        return _SMS_LAZY_SAME_EVENT_UNAVAILABLE
    try:
        from . import loader as _sms_loader
    except Exception:
        return _SMS_LAZY_SAME_EVENT_UNAVAILABLE
    patch_namespace = getattr(_sms_loader, '_patch_registered_class_namespace_51', None)
    patch_class = getattr(_sms_loader, '_patch_registered_class_in_place_51', None)
    if not callable(patch_class):
        return _SMS_LAZY_SAME_EVENT_UNAVAILABLE
    if callable(patch_namespace):
        try:
            for source_type in reversed(tuple(getattr(source_cls, '__mro__', ()) or ())):
                if source_type in {object, source_cls}:
                    continue
                if _sms_exact_class_belongs_to_current_package(source_type):
                    patch_namespace(live_cls, source_type)
        except Exception:
            return _SMS_LAZY_SAME_EVENT_UNAVAILABLE
    try:
        if not bool(patch_class(live_cls, source_cls)):
            return _SMS_LAZY_SAME_EVENT_UNAVAILABLE
    except Exception:
        return _SMS_LAZY_SAME_EVENT_UNAVAILABLE
    try:
        poll_method = getattr(live_cls, 'poll', None)
        if callable(poll_method) and not bool(poll_method(context)):
            # The tool loaded correctly: its own poll refused this mode or selection.
            reporter = getattr(operator, 'report', None)
            if callable(reporter):
                reporter({'WARNING'}, _pick_lang(
                    'This tool cannot run in the current mode or selection.',
                    'このツールは今のモードや選択では実行できません。',
                    context,
                ))
            return {'CANCELLED'}
    except Exception as exc:
        _sms_record_native_keymap_failure(tool_id, exc)
        return {'CANCELLED'}
    _sms_seed_lazy_operator_defaults(operator, source_cls)
    method = getattr(live_cls, 'invoke' if invoke else 'execute', None)
    source_invoke = getattr(source_cls, 'invoke', None)
    source_execute = getattr(source_cls, 'execute', None)
    # A preloaded shell may already contain the real callback when delegation
    # captures its namespace. Identity with that captured callback alone does
    # not mean it is still a recursive proxy.
    call_with_event = bool(invoke and callable(method) and (method is not proxy_invoke or method is source_invoke))
    if invoke and not call_with_event:
        method = getattr(live_cls, 'execute', None)
        call_with_event = False
    if not callable(method) or (method is proxy_execute and method is not source_execute):
        return _SMS_LAZY_SAME_EVENT_UNAVAILABLE
    if call_with_event:
        return method(operator, context, event)
    return method(operator, context)


def _sms_delegate_lazy_keymap_operator(
    tool_id: str,
    idname: str,
    context=None,
    *,
    invoke: bool = False,
    operator=None,
    event=None,
):
    tool_id = str(tool_id or '').strip()
    idname = str(idname or '').strip()
    if not tool_id or not idname:
        return {'CANCELLED'}
    if idname in _SMS_LAZY_KEYMAP_DELEGATING:
        return {'CANCELLED'}
    _SMS_LAZY_KEYMAP_DELEGATING.add(idname)
    try:
        try:
            captured_values = _sms_capture_lazy_ui_values('native', tool_id, context=context)
        except Exception:
            captured_values = {}
        direct_result = _sms_try_direct_lazy_proxy_delegate(
            tool_id,
            idname,
            context=context,
            invoke=invoke,
            operator=operator,
            event=event,
            captured_values=captured_values,
        )
        if direct_result is not None:
            return direct_result
        # Keep Blender's active wmOperator RNA owner registered for the complete
        # first key event.  The native register path patches this exact shell in
        # place; unregistering it here would invalidate ``self`` before its keymap
        # properties can be read.
        proxy_cls = type(operator) if operator is not None else None
        try:
            proxy_namespace = dict(getattr(proxy_cls, '__dict__', {}) or {}) if isinstance(proxy_cls, type) else {}
        except Exception:
            proxy_namespace = {}
        proxy_invoke = proxy_namespace.get('invoke')
        proxy_execute = proxy_namespace.get('execute')
        _SMS_LAZY_KEYMAP_PRESERVE_IDNAMES.add(idname)
        try:
            try:
                ok = bool(_sms_ensure_native_tool_loaded(tool_id, context=context or getattr(bpy, 'context', None)))
            except Exception as exc:
                _sms_record_native_keymap_failure(tool_id, exc)
                ok = False
            if not ok:
                _sms_report_native_keymap_failure(operator, tool_id, 'The native tool could not be loaded.')
                return {'CANCELLED'}
            # Loaded: an error recorded by an earlier attempt no longer applies. The
            # tool's own exceptions and refusals below are not load failures.
            try:
                _sms_native_tool_state(tool_id)['error'] = ''
            except Exception:
                pass
            try:
                _sms_sync_lazy_ui_settings_to_runtime(
                    'native',
                    tool_id,
                    context=context,
                    captured_values=captured_values,
                )
            except Exception:
                pass
            result = _sms_patch_and_run_native_lazy_operator_same_event(
                tool_id,
                idname,
                context or getattr(bpy, 'context', None),
                operator,
                invoke=invoke,
                event=event,
                proxy_invoke=proxy_invoke,
                proxy_execute=proxy_execute,
            )
            if result is _SMS_LAZY_SAME_EVENT_UNAVAILABLE:
                _sms_record_native_keymap_failure(tool_id, f'Could not bind the live shortcut shell for {idname}.')
                _sms_report_native_keymap_failure(operator, tool_id)
                return {'CANCELLED'}
            try:
                cancelled = 'CANCELLED' in set(result or ())
            except Exception:
                cancelled = False
            if cancelled and _sms_native_tool_error_excerpt(tool_id):
                _sms_report_native_keymap_failure(operator, tool_id)
            elif not cancelled:
                try:
                    _sms_native_tool_state(tool_id)['error'] = ''
                except Exception:
                    pass
            return result
        finally:
            _SMS_LAZY_KEYMAP_PRESERVE_IDNAMES.discard(idname)
    finally:
        _SMS_LAZY_KEYMAP_DELEGATING.discard(idname)


def _sms_draw_lazy_popup_owner(tool_id: str, idname: str, operator, context) -> None:
    """Draw a lazy popup through a callback that exists before RNA registration.

    Blender binds the popup owner to the Python Operator type that received the
    original key event.  Adding ``draw`` only after that event has begun is too
    late for the active wmOperator: Blender falls back to its automatic property
    layout.  Keep this stable draw callback on the lightweight shell from the
    moment it is registered, then delegate its contents after the real module is
    loaded.
    """
    key = (str(tool_id or '').strip(), str(idname or '').strip())
    helper_name = _SMS_LAZY_PROXY_POPUP_DRAW_HELPERS.get(key, '')
    if not helper_name:
        return
    meta = _sms_native_tool_meta(key[0])
    module = _sms_native_module_from_meta(meta, require_loaded=False) if isinstance(meta, dict) else None
    helper = getattr(module, helper_name, None) if module is not None else None
    if callable(helper):
        helper(operator.layout, context)
        return
    # Never display Blender's automatic RNA property fallback for a Smart
    # Modeling popup.  A failed lazy load is shown as one explicit error row so
    # unrelated operator properties cannot leak into the popup.
    try:
        row = operator.layout.row(align=True)
        row.alert = True
        row.label(
            text=_pick_lang(
                'The popup content could not be loaded.',
                'ポップアップ内容を読み込めませんでした。',
                context,
            ),
            icon='ERROR',
        )
    except Exception:
        pass


# BEGIN GENERATED SMART MODELING LAZY RNA SCHEMA
# Generated from source operator classes and package-owned MRO.
# Runtime registration consumes only these literals and never imports a tool module.
_SMS_LAZY_RNA_NATIVE_IDS = ('vscp.copy_vertices',
 'vscp.paste_same_index',
 'vscp.validate_same_index',
 'vscp.paste_vertices',
 'vscp.validate_targets',
 'mesh.smart_vert_slide',
 'mesh.smart_connect',
 'mesh.smart_split',
 'mesh.mesh_align_master',
 'mesh.delete_direct',
 'mesh.delete_direct_del',
 'mesh.delete_direct_bs',
 'mesh.delete_direct_through',
 'object.delete_direct_objects',
 'object.delete_history_modifiers',
 'mo2.organize_modal',
 'mo2.restore_backup',
 'mesh.edge_crease_master',
 'mesh.toggle_merge_snap',
 'mesh.apply_weighted_normal',
 'smsk.annotation_to_curve',
 'smsk.annotation_to_surface_strip',
 'mesh.quad_strip_draw',
 'mesh.qsd_retopo_pen',
 'smsuite.context_modeler',
 'smsuite.loop_shape_suite',
 'smsuite.quad_rebuild',
 'smsuite.align_unbend',
 'smsuite.boolean_fusion_stack',
 'smsuite.boolean_apply_clean',
 'smsuite.bevel_normal_stack',
 'smsuite.unbevel_planar_clean',
 'smsuite.solidify_plus',
 'smsuite.kit_insert',
 'smsuite.cable_pipe_from_selection',
 'smsuite.rail_sweep_generator',
 'smsuite.bend_projection',
 'smsuite.retopo_wrap_remesh',
 'smsuite.falloff_deform',
 'smsuite.scatter_surface',
 'smsuite.floor_wall_generator',
 'smsuite.terrain_generator',
 'smsuite.slice_wire_detail',
 'smsuite.modifier_stack_preset',
 'smsuite.mesh_repair_audit',
 'smsuite.cad_import_cleaner',
 'smsuite.workplane_pivot_tools',
 'smsuite.drop_snap_tools',
 'smsuite.asset_replace_randomize',
 'smsuite.magic_solo')
_SMS_LAZY_RNA_INTEGRATED_IDS = ('keyops.auto_delete',
 'keyops.double_click_select_island',
 'keyops.fast_merge',
 'keyops.modi_key',
 'keyops.modi_key_no_undo',
 'keyops.outliner_click',
 'keyops.pivot_press',
 'keyops.quick_export',
 'keyops.remove_seam',
 'keyops.select_edge_loop',
 'keyops.select_edge_loop_shift',
 'keyops.smart_uv_sync',
 'keyops.toggle_retopology',
 'keyops.toolkit_panel',
 'mesh.fast_connect',
 'transform.entering_transform_none_live_booleans',
 'uv.keyops_uv_cut')
_SMS_LAZY_RNA_PROPERTY_SCHEMAS = {'vscp.copy_vertices': {'slot_index': ('IntProperty',
                                       {'name': 'Slot',
                                        'default': -1,
                                        'min': -1,
                                        'max': 15,
                                        'description': 'Adjust Slot. Larger or smaller values change the strength, '
                                                       'amount, size, or precision used by the related tool.'})},
 'vscp.paste_same_index': {},
 'vscp.validate_same_index': {},
 'vscp.paste_vertices': {},
 'vscp.validate_targets': {},
 'mesh.smart_vert_slide': {},
 'mesh.smart_connect': {},
 'mesh.smart_split': {},
 'mesh.mesh_align_master': {},
 'mesh.delete_direct': {},
 'mesh.delete_direct_del': {},
 'mesh.delete_direct_bs': {},
 'mesh.delete_direct_through': {},
 'object.delete_direct_objects': {},
 'object.delete_history_modifiers': {},
 'mo2.organize_modal': {},
 'mo2.restore_backup': {},
 'mesh.edge_crease_master': {},
 'mesh.toggle_merge_snap': {},
 'mesh.apply_weighted_normal': {'preset': ('EnumProperty',
                                           {'name': 'Preset',
                                            'items': [('HARD_SURFACE', 'Hard Surface Modeling', ''),
                                                      ('GAME', 'Game Asset', ''),
                                                      ('MINIMAL', 'Minimal', ''),
                                                      ('CUSTOM', 'Custom', '')],
                                            'default': 'CUSTOM'}),
                                'apply_mode': ('EnumProperty',
                                               {'name': 'Apply Mode',
                                                'items': [('ADD_AND_APPLY', 'Add & Apply', ''),
                                                          ('ADD_ONLY', 'Add Only', '')],
                                                'default': 'ADD_AND_APPLY'}),
                                'limit_to_selection': ('BoolProperty',
                                                       {'name': 'Limit To Selection', 'default': False}),
                                'keep_sharp': ('BoolProperty', {'name': 'Keep Sharp', 'default': True}),
                                'weight': ('FloatProperty',
                                           {'name': 'Weight', 'default': 50.0, 'min': 1.0, 'max': 100.0}),
                                'threshold': ('FloatProperty',
                                              {'name': 'Threshold',
                                               'default': 0.01,
                                               'min': 0.0,
                                               'max': 10.0,
                                               'precision': 4})},
 'smsk.annotation_to_curve': {},
 'smsk.annotation_to_surface_strip': {},
 'mesh.quad_strip_draw': {'qsd_retopo_pen_mode': ('BoolProperty',
                                                  {'default': False,
                                                   'description': 'Internal flag used to route Retopo Strip Draw '
                                                                  'through the main strip operator.',
                                                   'options': {'HIDDEN', 'SKIP_SAVE'}}),
                          'stop_running': ('BoolProperty',
                                           {'default': False,
                                            'description': 'Internal flag used to stop the running strip drawing '
                                                           'session.',
                                            'options': {'HIDDEN', 'SKIP_SAVE'}})},
 'mesh.qsd_retopo_pen': {},
 'smsuite.context_modeler': {'action': ('EnumProperty',
                                        {'name': 'Action',
                                         'description': 'Choose the context modeling action. Auto mode tries to '
                                                        'infer the safest operation from the active selection and '
                                                        'falls back to face creation.',
                                         'items': (('AUTO',
                                                    'Auto',
                                                    'Infer the best action from the current selection and context.'),
                                                   ('FILL',
                                                    'Fill',
                                                    'Create faces from selected vertices or edges, similar to F2 and '
                                                    'grid-fill workflows.'),
                                                   ('EXTRUDE',
                                                    'Clean Extrude',
                                                    'Extrude the selected region and immediately merge, recalculate '
                                                    'normals, and remove tiny overlaps.'),
                                                   ('INSET',
                                                    'Inset',
                                                    'Inset selected faces and keep the result editable for '
                                                    'panel-line or CAD-like blocking.'),
                                                   ('BRIDGE',
                                                    'Bridge',
                                                    'Bridge selected edge loops when two compatible boundaries are '
                                                    'selected.')),
                                         'default': 'AUTO'}),
                             'distance': ('FloatProperty',
                                          {'name': 'Distance',
                                           'description': 'Extrusion distance used by Clean Extrude. Use a small '
                                                          'value for panel lips and a larger value for block-out '
                                                          'modeling.',
                                           'default': 0.1,
                                           'min': -1000.0,
                                           'max': 1000.0}),
                             'inset_amount': ('FloatProperty',
                                              {'name': 'Inset Amount',
                                               'description': 'Inset width used by the Inset action. This creates a '
                                                              'local border suitable for panel lines, bevel '
                                                              'preparation, and ZModeler-like edits.',
                                               'default': 0.03,
                                               'min': 0.0,
                                               'max': 1000.0})},
 'smsuite.loop_shape_suite': {'mode': ('EnumProperty',
                                       {'name': 'Mode',
                                        'description': 'Select the loop operation. Circle regularizes holes, Relax '
                                                       'evens tension, Space equalizes vertex spacing, Bridge and '
                                                       'Loft connect loops, and Flatten projects the selection to a '
                                                       'plane.',
                                        'items': (('CIRCLE',
                                                   'Circle',
                                                   'Regularize the selected loop into a circular shape.'),
                                                  ('RELAX',
                                                   'Relax',
                                                   'Smooth selected vertices while preserving the overall shape.'),
                                                  ('SPACE', 'Space', 'Equalize spacing along selected loops.'),
                                                  ('BRIDGE',
                                                   'Bridge',
                                                   'Bridge two selected loops or boundary selections.'),
                                                  ('FLATTEN',
                                                   'Flatten',
                                                   'Flatten selected vertices to their average local Z plane.')),
                                        'default': 'RELAX'}),
                              'iterations': ('IntProperty',
                                             {'name': 'Iterations',
                                              'description': 'Number of smoothing or spacing passes used by modes '
                                                             'that support iterative cleanup. Higher values are '
                                                             'smoother but can soften details.',
                                              'default': 4,
                                              'min': 1,
                                              'max': 64})},
 'smsuite.quad_rebuild': {'mode': ('EnumProperty',
                                   {'name': 'Mode',
                                    'description': 'Choose a quad rebuild operation. Auto tries a safe sequence for '
                                                   'missing faces and N-gon cleanup.',
                                    'items': (('AUTO',
                                               'Auto',
                                               'Run a safe sequence of fill, triangle-to-quad, and cleanup '
                                               'operations.'),
                                              ('FILL', 'Fill', 'Fill selected boundary edges or vertices.'),
                                              ('GRID',
                                               'Grid Fill',
                                               'Create an organized quad grid across selected boundary loops.'),
                                              ('TRIS_TO_QUADS',
                                               'Tris to Quads',
                                               'Convert adjacent triangles into quads where possible.'),
                                              ('POKE',
                                               'Poke',
                                               'Poke selected faces to create radial topology for controlled '
                                               'cleanup.')),
                                    'default': 'AUTO'})},
 'smsuite.align_unbend': {'mode': ('EnumProperty',
                                   {'name': 'Mode',
                                    'description': 'Line mode projects selected vertices to a best-fit line. Axis '
                                                   'modes align to the average coordinate on the chosen local axis.',
                                    'items': (('LINE',
                                               'Best Fit Line',
                                               'Project selected vertices to the line between the farthest selected '
                                               'points.'),
                                              ('X',
                                               'Local X',
                                               'Align selected vertices to their average local X coordinate.'),
                                              ('Y',
                                               'Local Y',
                                               'Align selected vertices to their average local Y coordinate.'),
                                              ('Z',
                                               'Local Z',
                                               'Align selected vertices to their average local Z coordinate.')),
                                    'default': 'LINE'}),
                          'preserve_span': ('BoolProperty',
                                            {'name': 'Preserve Span',
                                             'description': 'When using Best Fit Line, keep vertices distributed '
                                                            'along the full selected span instead of collapsing them '
                                                            'to the center.',
                                             'default': True})},
 'smsuite.boolean_fusion_stack': {'operation': ('EnumProperty',
                                                {'name': 'Operation',
                                                 'description': 'Boolean operation applied from each selected cutter '
                                                                'to the active target. Difference cuts holes, Union '
                                                                'fuses forms, and Intersect keeps only overlapping '
                                                                'volume.',
                                                 'items': (('DIFFERENCE',
                                                            'Difference',
                                                            'Subtract each cutter from the active object.'),
                                                           ('UNION',
                                                            'Union',
                                                            'Union each cutter with the active object.'),
                                                           ('INTERSECT',
                                                            'Intersect',
                                                            'Keep only the overlapping volume between target and '
                                                            'cutters.')),
                                                 'default': 'DIFFERENCE'}),
                                  'hide_cutters': ('BoolProperty',
                                                   {'name': 'Hide Cutters',
                                                    'description': 'Hide cutter objects in the viewport after the '
                                                                   'boolean modifiers are created while keeping them '
                                                                   'available for later non-destructive editing.',
                                                    'default': True}),
                                  'add_bevel': ('BoolProperty',
                                                {'name': 'Add Bevel',
                                                 'description': 'Add a small bevel modifier after the boolean stack '
                                                                'to create cleaner hard-surface highlights and a '
                                                                'MeshFusion-like softened intersection.',
                                                 'default': True}),
                                  'bevel_width': ('FloatProperty',
                                                  {'name': 'Bevel Width',
                                                   'description': 'Width of the bevel modifier added after the '
                                                                  'boolean stack. Keep this low for panel cuts and '
                                                                  'increase it for mechanical fillets.',
                                                   'default': 0.025,
                                                   'min': 0.0,
                                                   'max': 1000.0})},
 'smsuite.boolean_apply_clean': {'apply_all_booleans': ('BoolProperty',
                                                        {'name': 'Apply All Boolean Modifiers',
                                                         'description': 'Apply every Boolean modifier on each '
                                                                        'selected mesh before cleanup. Disable this '
                                                                        'when you only want to clean already-applied '
                                                                        'boolean results.',
                                                         'default': True}),
                                 'merge_distance': ('FloatProperty',
                                                    {'name': 'Merge Distance',
                                                     'description': 'Distance used to weld overlapping vertices '
                                                                    'after boolean application. Increase slightly '
                                                                    'when cutters leave doubled vertices.',
                                                     'default': 0.0001,
                                                     'min': 0.0,
                                                     'max': 1.0}),
                                 'add_weighted_normal': ('BoolProperty',
                                                         {'name': 'Add Weighted Normal',
                                                          'description': 'Add a Weighted Normal modifier after '
                                                                         'cleanup to reduce shading artifacts on '
                                                                         'N-gon and boolean-heavy hard-surface '
                                                                         'meshes.',
                                                          'default': True})},
 'smsuite.bevel_normal_stack': {'width': ('FloatProperty',
                                          {'name': 'Width',
                                           'description': 'Bevel width applied to selected mesh objects. Use very '
                                                          'small values for highlight bevels and larger values for '
                                                          'visible mechanical fillets.',
                                           'default': 0.025,
                                           'min': 0.0,
                                           'max': 1000.0}),
                                'segments': ('IntProperty',
                                             {'name': 'Segments',
                                              'description': 'Number of bevel segments. One segment creates '
                                                             'chamfers, two or more create rounded fillets.',
                                              'default': 2,
                                              'min': 1,
                                              'max': 64}),
                                'apply_stack': ('BoolProperty',
                                                {'name': 'Apply Stack',
                                                 'description': 'Apply the bevel and weighted-normal modifiers '
                                                                'immediately. Leave this disabled to keep the stack '
                                                                'non-destructive.',
                                                 'default': False})},
 'smsuite.unbevel_planar_clean': {'angle_degrees': ('FloatProperty',
                                                    {'name': 'Planar Angle',
                                                     'description': 'Maximum angle treated as planar during limited '
                                                                    'dissolve. Low values preserve bevels; higher '
                                                                    'values remove more support edges.',
                                                     'default': 3.0,
                                                     'min': 0.0,
                                                     'max': 45.0}),
                                  'merge_distance': ('FloatProperty',
                                                     {'name': 'Merge Distance',
                                                      'description': 'Weld distance after dissolve. Use a tiny value '
                                                                     'to remove duplicate boolean vertices without '
                                                                     'collapsing intended detail.',
                                                      'default': 0.0001,
                                                      'min': 0.0,
                                                      'max': 1.0})},
 'smsuite.solidify_plus': {'thickness': ('FloatProperty',
                                         {'name': 'Thickness',
                                          'description': 'Thickness added by the Solidify modifier. Positive values '
                                                         'expand outward according to the selected offset setting.',
                                          'default': 0.05,
                                          'min': -1000.0,
                                          'max': 1000.0}),
                           'offset': ('FloatProperty',
                                      {'name': 'Offset',
                                       'description': 'Solidify offset. Use 1 for outward, 0 for centered, and -1 '
                                                      'for inward thickness.',
                                       'default': 1.0,
                                       'min': -1.0,
                                       'max': 1.0}),
                           'add_bevel': ('BoolProperty',
                                         {'name': 'Add Bevel and Normals',
                                          'description': 'Add bevel and weighted-normal modifiers after Solidify to '
                                                         'keep shell edges readable and shading stable.',
                                          'default': True})},
 'smsuite.kit_insert': {'snap_to_surface': ('BoolProperty',
                                            {'name': 'Snap to Surface',
                                             'description': 'Snap inserted kit objects to the closest point on the '
                                                            'active mesh surface near the 3D cursor.',
                                             'default': True}),
                        'align_to_normal': ('BoolProperty',
                                            {'name': 'Align to Normal',
                                             'description': 'Align inserted kit objects so their local Z axis '
                                                            'follows the active surface normal.',
                                             'default': True}),
                        'add_boolean': ('BoolProperty',
                                        {'name': 'Add Boolean Difference',
                                         'description': 'Add a Difference boolean from each inserted kit object to '
                                                        'the active target for cut-in details. Leave disabled for '
                                                        'surface-only kitbash placement.',
                                         'default': False}),
                        'scale': ('FloatProperty',
                                  {'name': 'Scale',
                                   'description': 'Scale multiplier applied to inserted kit objects after '
                                                  'duplication.',
                                   'default': 1.0,
                                   'min': 0.0001,
                                   'max': 1000.0})},
 'smsuite.cable_pipe_from_selection': {'radius': ('FloatProperty',
                                                  {'name': 'Radius',
                                                   'description': 'Cable or pipe radius assigned to generated '
                                                                  'curves. Increase for pipes and decrease for thin '
                                                                  'wires.',
                                                   'default': 0.025,
                                                   'min': 0.0001,
                                                   'max': 1000.0}),
                                       'resolution': ('IntProperty',
                                                      {'name': 'Resolution',
                                                       'description': 'Curve bevel resolution used for rounded cable '
                                                                      'cross sections. Higher values are smoother '
                                                                      'but heavier.',
                                                       'default': 4,
                                                       'min': 0,
                                                       'max': 32}),
                                       'convert_mesh_edges': ('BoolProperty',
                                                              {'name': 'Convert Selected Mesh Edges',
                                                               'description': 'When running in Edit Mode on a mesh, '
                                                                              'convert selected edges into separate '
                                                                              'pipe curves before applying bevel '
                                                                              'settings.',
                                                               'default': True})},
 'smsuite.rail_sweep_generator': {'mode': ('EnumProperty',
                                           {'name': 'Mode',
                                            'description': 'Curve Pipe sets bevel depth on selected curves. '
                                                           'Duplicate Source places the selected source object along '
                                                           'the active curve control points.',
                                            'items': (('PIPE',
                                                       'Curve Pipe',
                                                       'Turn selected curve paths into editable pipes or rails.'),
                                                      ('DUPLICATE',
                                                       'Duplicate Source',
                                                       'Duplicate a selected source object along the active curve '
                                                       'points.')),
                                            'default': 'PIPE'}),
                                  'radius': ('FloatProperty',
                                             {'name': 'Radius',
                                              'description': 'Pipe radius for Curve Pipe mode.',
                                              'default': 0.04,
                                              'min': 0.0001,
                                              'max': 10000.0}),
                                  'count': ('IntProperty',
                                            {'name': 'Count',
                                             'description': 'Maximum number of duplicates sampled along curve points '
                                                            'in Duplicate Source mode.',
                                             'default': 16,
                                             'min': 2,
                                             'max': 10000})},
 'smsuite.bend_projection': {'mode': ('EnumProperty',
                                      {'name': 'Mode',
                                       'description': 'Bend adds a non-destructive Simple Deform modifier. Project '
                                                      'moves selected vertices or objects to the closest point on '
                                                      'the active target surface.',
                                       'items': (('BEND',
                                                  'Bend',
                                                  'Add a Simple Deform Bend modifier to selected mesh objects.'),
                                                 ('PROJECT',
                                                  'Project to Target',
                                                  'Project selected object vertices to the active target mesh by '
                                                  'closest point.')),
                                       'default': 'BEND'}),
                             'angle': ('FloatProperty',
                                       {'name': 'Angle',
                                        'description': 'Bend angle in degrees for the Simple Deform modifier.',
                                        'default': 90.0,
                                        'min': -3600.0,
                                        'max': 3600.0}),
                             'max_distance': ('FloatProperty',
                                              {'name': 'Max Distance',
                                               'description': 'Maximum projection distance for closest-point '
                                                              'projection. Increase when source geometry is far away '
                                                              'from the target surface.',
                                               'default': 100.0,
                                               'min': 0.0,
                                               'max': 100000.0})},
 'smsuite.retopo_wrap_remesh': {'method': ('EnumProperty',
                                           {'name': 'Method',
                                            'description': 'Choose the remesh strategy. Quadriflow is used when '
                                                           'available; Voxel Remesh is a broadly available fallback; '
                                                           'Shrinkwrap Only keeps existing topology.',
                                            'items': (('QUADRIFLOW',
                                                       'Quadriflow',
                                                       'Run Blender Quadriflow remesh when the operator is '
                                                       'available.'),
                                                      ('VOXEL',
                                                       'Voxel',
                                                       'Add or run voxel remeshing for even all-quad-like sculpt '
                                                       'base topology.'),
                                                      ('SHRINKWRAP',
                                                       'Shrinkwrap Only',
                                                       'Add a shrinkwrap modifier to conform source topology to the '
                                                       'active target.')),
                                            'default': 'VOXEL'}),
                                'target_faces': ('IntProperty',
                                                 {'name': 'Target Faces',
                                                  'description': 'Approximate target face count for Quadriflow '
                                                                 'remeshing. Ignored by methods that do not expose '
                                                                 'target face count.',
                                                  'default': 5000,
                                                  'min': 100,
                                                  'max': 1000000}),
                                'voxel_size': ('FloatProperty',
                                               {'name': 'Voxel Size',
                                                'description': 'Voxel size for voxel remesh fallback. Smaller values '
                                                               'preserve more detail and create heavier meshes.',
                                                'default': 0.05,
                                                'min': 0.0001,
                                                'max': 1000.0}),
                                'add_shrinkwrap': ('BoolProperty',
                                                   {'name': 'Add Shrinkwrap',
                                                    'description': 'Add a shrinkwrap modifier to the active target '
                                                                   'or to the second selected mesh after remeshing, '
                                                                   'useful for retopology projection.',
                                                    'default': True})},
 'smsuite.falloff_deform': {'strength': ('FloatProperty',
                                         {'name': 'Strength',
                                          'description': 'Displacement strength applied along selected vertex '
                                                         'normals near the 3D cursor.',
                                          'default': 0.1,
                                          'min': -1000.0,
                                          'max': 1000.0}),
                            'radius': ('FloatProperty',
                                       {'name': 'Radius',
                                        'description': 'Falloff radius around the 3D cursor. Vertices outside this '
                                                       'radius remain unchanged.',
                                        'default': 1.0,
                                        'min': 0.0001,
                                        'max': 100000.0}),
                            'power': ('FloatProperty',
                                      {'name': 'Power',
                                       'description': 'Falloff exponent. Higher values concentrate deformation near '
                                                      'the cursor; lower values make a broad deformation.',
                                       'default': 2.0,
                                       'min': 0.01,
                                       'max': 32.0})},
 'smsuite.scatter_surface': {'count': ('IntProperty',
                                       {'name': 'Count',
                                        'description': 'Number of scattered instances to create across the active '
                                                       'target surface.',
                                        'default': 50,
                                        'min': 1,
                                        'max': 100000}),
                             'seed': ('IntProperty',
                                      {'name': 'Seed',
                                       'description': 'Random seed for deterministic scatter placement. Change this '
                                                      'value to generate a different distribution.',
                                       'default': 1,
                                       'min': 0,
                                       'max': 999999}),
                             'min_scale': ('FloatProperty',
                                           {'name': 'Minimum Scale',
                                            'description': 'Minimum random scale multiplier applied to scattered '
                                                           'instances.',
                                            'default': 0.7,
                                            'min': 0.0,
                                            'max': 1000.0}),
                             'max_scale': ('FloatProperty',
                                           {'name': 'Maximum Scale',
                                            'description': 'Maximum random scale multiplier applied to scattered '
                                                           'instances.',
                                            'default': 1.3,
                                            'min': 0.0,
                                            'max': 1000.0}),
                             'align_to_normal': ('BoolProperty',
                                                 {'name': 'Align to Normal',
                                                  'description': 'Rotate each scattered instance so its local Z axis '
                                                                 'follows the sampled surface normal, useful for '
                                                                 'rocks, plants, bolts, and panel details.',
                                                  'default': True}),
                             'linked_data': ('BoolProperty',
                                             {'name': 'Linked Data',
                                              'description': 'Use linked object data for lower memory usage. Disable '
                                                             'this when each scattered object needs unique mesh '
                                                             'edits later.',
                                              'default': True})},
 'smsuite.floor_wall_generator': {'mode': ('EnumProperty',
                                           {'name': 'Mode',
                                            'description': 'Choose the procedural asset to generate: floor tiles, '
                                                           'brick wall, stairs, or facade strips.',
                                            'items': (('FLOOR',
                                                       'Floor Tiles',
                                                       'Generate individual floor or tile faces inside a rectangular '
                                                       'area.'),
                                                      ('WALL',
                                                       'Brick Wall',
                                                       'Generate a brick wall from stacked box bricks with '
                                                       'alternating offsets.'),
                                                      ('STAIRS',
                                                       'Stairs',
                                                       'Generate block-out stairs from repeated rectangular steps.'),
                                                      ('FACADE',
                                                       'Facade Grid',
                                                       'Generate a simple architectural facade grid for fast concept '
                                                       'blocking.')),
                                            'default': 'FLOOR'}),
                                  'width': ('FloatProperty',
                                            {'name': 'Width',
                                             'description': 'Overall generated width in Blender units.',
                                             'default': 4.0,
                                             'min': 0.001,
                                             'max': 100000.0}),
                                  'depth': ('FloatProperty',
                                            {'name': 'Depth',
                                             'description': 'Overall generated depth or thickness depending on the '
                                                            'selected generator mode.',
                                             'default': 4.0,
                                             'min': 0.001,
                                             'max': 100000.0}),
                                  'height': ('FloatProperty',
                                             {'name': 'Height',
                                              'description': 'Overall generated height for walls, stairs, and facade '
                                                             'grids.',
                                              'default': 2.5,
                                              'min': 0.001,
                                              'max': 100000.0}),
                                  'columns': ('IntProperty',
                                              {'name': 'Columns',
                                               'description': 'Number of generated columns, tiles, bricks per row, '
                                                              'or facade bays.',
                                               'default': 8,
                                               'min': 1,
                                               'max': 1000}),
                                  'rows': ('IntProperty',
                                           {'name': 'Rows',
                                            'description': 'Number of generated rows, tile rows, brick courses, '
                                                           'steps, or facade floors.',
                                            'default': 6,
                                            'min': 1,
                                            'max': 1000}),
                                  'gap': ('FloatProperty',
                                          {'name': 'Gap',
                                           'description': 'Gap between tiles, bricks, or facade pieces. Use zero for '
                                                          'continuous geometry.',
                                           'default': 0.02,
                                           'min': 0.0,
                                           'max': 1000.0})},
 'smsuite.terrain_generator': {'size': ('FloatProperty',
                                        {'name': 'Size',
                                         'description': 'Overall terrain width and depth in Blender units.',
                                         'default': 8.0,
                                         'min': 0.001,
                                         'max': 100000.0}),
                               'subdivisions': ('IntProperty',
                                                {'name': 'Subdivisions',
                                                 'description': 'Grid subdivisions used to build the terrain. Higher '
                                                                'values create smoother terrain but heavier meshes.',
                                                 'default': 64,
                                                 'min': 2,
                                                 'max': 512}),
                               'height': ('FloatProperty',
                                          {'name': 'Height',
                                           'description': 'Maximum vertical displacement applied by the layered '
                                                          'procedural noise.',
                                           'default': 1.0,
                                           'min': 0.0,
                                           'max': 100000.0}),
                               'seed': ('IntProperty',
                                        {'name': 'Seed',
                                         'description': 'Random seed used by the procedural terrain noise.',
                                         'default': 7,
                                         'min': 0,
                                         'max': 999999}),
                               'roughness': ('FloatProperty',
                                             {'name': 'Roughness',
                                              'description': 'Controls how much higher-frequency detail is added to '
                                                             'the terrain. Higher values create rougher landscapes.',
                                              'default': 0.55,
                                              'min': 0.0,
                                              'max': 2.0})},
 'smsuite.slice_wire_detail': {'mode': ('EnumProperty',
                                        {'name': 'Mode',
                                         'description': 'Wire Detail adds triangulate, wireframe, and displacement '
                                                        'modifiers. Slice Guides creates evenly spaced guide planes '
                                                        'through the selected objects.',
                                         'items': (('WIRE',
                                                    'Wire Detail',
                                                    'Add procedural wireframe and displacement detail modifiers.'),
                                                   ('SLICE_GUIDES',
                                                    'Slice Guides',
                                                    'Create evenly spaced slicing guide planes through selected '
                                                    'object bounds.')),
                                         'default': 'WIRE'}),
                               'count': ('IntProperty',
                                         {'name': 'Count',
                                          'description': 'Number of slicing guide planes or detail repetitions.',
                                          'default': 8,
                                          'min': 1,
                                          'max': 1000}),
                               'thickness': ('FloatProperty',
                                             {'name': 'Thickness',
                                              'description': 'Wire thickness or guide plane thickness.',
                                              'default': 0.02,
                                              'min': 0.0001,
                                              'max': 1000.0})},
 'smsuite.modifier_stack_preset': {'preset': ('EnumProperty',
                                              {'name': 'Preset',
                                               'description': 'Choose a modifier stack. Hard Surface Modeling adds '
                                                              'bevel and normals; Mirror Array adds mirror and '
                                                              'array; Procedural Detail adds wireframe and '
                                                              'displacement; Game Cleanup adds decimate and normals.',
                                               'items': (('HARD_SURFACE',
                                                          'Hard Surface Modeling',
                                                          'Bevel plus weighted normals for clean hard-surface '
                                                          'shading.'),
                                                         ('MIRROR_ARRAY',
                                                          'Mirror Array',
                                                          'Mirror and array modifiers for symmetric repeated '
                                                          'modeling.'),
                                                         ('PROCEDURAL_DETAIL',
                                                          'Procedural Detail',
                                                          'Wireframe and displacement detail stack for BY-GEN or '
                                                          'Trypogen-style forms.'),
                                                         ('GAME_CLEANUP',
                                                          'Game Cleanup',
                                                          'Weighted normals and decimate for lightweight game asset '
                                                          'cleanup.')),
                                               'default': 'HARD_SURFACE'})},
 'smsuite.mesh_repair_audit': {'fix_mesh': ('BoolProperty',
                                            {'name': 'Fix Mesh',
                                             'description': 'When enabled, remove loose geometry, weld doubles, '
                                                            'dissolve near-planar edges, and recalculate normals. '
                                                            'When disabled, only reports basic mesh counts.',
                                             'default': True}),
                               'merge_distance': ('FloatProperty',
                                                  {'name': 'Merge Distance',
                                                   'description': 'Weld threshold for duplicate vertices. Use tiny '
                                                                  'values for scans and imported CAD meshes; '
                                                                  'increase carefully for messy data.',
                                                   'default': 0.0001,
                                                   'min': 0.0,
                                                   'max': 1.0}),
                               'planar_angle': ('FloatProperty',
                                                {'name': 'Planar Angle',
                                                 'description': 'Limited dissolve angle in degrees for removing tiny '
                                                                'planar support edges while preserving intentional '
                                                                'corners.',
                                                 'default': 1.0,
                                                 'min': 0.0,
                                                 'max': 45.0})},
 'smsuite.cad_import_cleaner': {'convert_curves': ('BoolProperty',
                                                   {'name': 'Convert Curves',
                                                    'description': 'Convert selected curve objects to meshes before '
                                                                   'cleanup so imported CAD splines can be welded '
                                                                   'and simplified.',
                                                    'default': False}),
                                'apply_transforms': ('BoolProperty',
                                                     {'name': 'Apply Transforms',
                                                      'description': 'Apply location, rotation, and scale transforms '
                                                                     'to selected objects before mesh cleanup.',
                                                      'default': True}),
                                'rename_prefix': ('StringProperty',
                                                  {'name': 'Rename Prefix',
                                                   'description': 'Optional prefix applied to cleaned objects for '
                                                                  'easier scene organization.',
                                                   'default': 'SMS_CAD'}),
                                'merge_distance': ('FloatProperty',
                                                   {'name': 'Merge Distance',
                                                    'description': 'Weld threshold for converted or imported mesh '
                                                                   'objects.',
                                                    'default': 0.0001,
                                                    'min': 0.0,
                                                    'max': 1.0})},
 'smsuite.workplane_pivot_tools': {'mode': ('EnumProperty',
                                            {'name': 'Mode',
                                             'description': 'Cursor to Selection moves the 3D cursor. Origin to '
                                                            'Cursor moves selected object origins. Workplane creates '
                                                            'a helper plane at the cursor.',
                                             'items': (('CURSOR_TO_SELECTION',
                                                        'Cursor to Selection',
                                                        'Move the 3D cursor to the center of the selected elements '
                                                        'or objects.'),
                                                       ('ORIGIN_TO_CURSOR',
                                                        'Origin to Cursor',
                                                        'Move selected object origins to the current 3D cursor.'),
                                                       ('CREATE_WORKPLANE',
                                                        'Create Workplane',
                                                        'Create a named helper plane at the cursor for visual '
                                                        'modeling reference.')),
                                             'default': 'CURSOR_TO_SELECTION'}),
                                   'plane_size': ('FloatProperty',
                                                  {'name': 'Plane Size',
                                                   'description': 'Size of the helper plane created by Create '
                                                                  'Workplane mode.',
                                                   'default': 2.0,
                                                   'min': 0.001,
                                                   'max': 100000.0})},
 'smsuite.drop_snap_tools': {'mode': ('EnumProperty',
                                      {'name': 'Mode',
                                       'description': 'Drop moves selected objects down to the active target '
                                                      'surface. Snap Origin moves objects to the active origin. '
                                                      'Floor moves objects to world Z zero.',
                                       'items': (('DROP',
                                                  'Drop to Active Surface',
                                                  'Drop selected objects vertically onto the active mesh surface.'),
                                                 ('SNAP_ORIGIN',
                                                  'Snap to Active Origin',
                                                  "Move selected objects to the active object's origin."),
                                                 ('FLOOR',
                                                  'Drop to Floor',
                                                  'Move selected objects so their lowest point rests on world Z '
                                                  'zero.')),
                                       'default': 'DROP'}),
                             'offset': ('FloatProperty',
                                        {'name': 'Offset',
                                         'description': 'Vertical offset left above the hit surface or floor after '
                                                        'dropping.',
                                         'default': 0.0,
                                         'min': -1000.0,
                                         'max': 1000.0}),
                             'ray_height': ('FloatProperty',
                                            {'name': 'Ray Height',
                                             'description': 'Height above each object origin where downward raycasts '
                                                            'begin for surface dropping.',
                                             'default': 100.0,
                                             'min': 0.0,
                                             'max': 100000.0})},
 'smsuite.asset_replace_randomize': {'replace_with_active': ('BoolProperty',
                                                             {'name': 'Replace With Active',
                                                              'description': 'Replace selected placeholder objects '
                                                                             'with linked duplicates of the active '
                                                                             'object while preserving each '
                                                                             'placeholder transform.',
                                                              'default': True}),
                                     'keep_placeholders': ('BoolProperty',
                                                           {'name': 'Keep Placeholders',
                                                            'description': 'Keep original placeholder objects after '
                                                                           'creating replacements. Disable this for '
                                                                           'a true replacement operation.',
                                                            'default': False}),
                                     'random_rotation': ('BoolProperty',
                                                         {'name': 'Random Rotation',
                                                          'description': 'Apply random Z rotation to selected or '
                                                                         'replacement objects for natural layout '
                                                                         'variation.',
                                                          'default': True}),
                                     'min_scale': ('FloatProperty',
                                                   {'name': 'Minimum Scale',
                                                    'description': 'Minimum random scale multiplier.',
                                                    'default': 0.9,
                                                    'min': 0.0,
                                                    'max': 1000.0}),
                                     'max_scale': ('FloatProperty',
                                                   {'name': 'Maximum Scale',
                                                    'description': 'Maximum random scale multiplier.',
                                                    'default': 1.1,
                                                    'min': 0.0,
                                                    'max': 1000.0}),
                                     'seed': ('IntProperty',
                                              {'name': 'Seed',
                                               'description': 'Random seed for repeatable replacement and transform '
                                                              'variation.',
                                               'default': 3,
                                               'min': 0,
                                               'max': 999999})},
 'smsuite.magic_solo': {'mode': ('EnumProperty',
                                 {'name': 'Mode',
                                  'description': 'Isolate hides unselected objects, Reveal All shows everything, and '
                                                 'Hide Selected hides only the current selection.',
                                  'items': (('ISOLATE',
                                             'Isolate',
                                             'Hide unselected scene objects and keep selected objects visible.'),
                                            ('REVEAL', 'Reveal All', 'Reveal all objects in the current view layer.'),
                                            ('HIDE_SELECTED', 'Hide Selected', 'Hide the selected objects only.')),
                                  'default': 'ISOLATE'})},
 'keyops.auto_delete': {'object_mode': ('BoolProperty',
                                        {'name': 'Object Mode',
                                         'description': 'Delete objects in object mode',
                                         'default': False})},
 'keyops.double_click_select_island': {},
 'keyops.fast_merge': {'preserve_uvs': ('BoolProperty',
                                        {'name': 'Preserve UVs',
                                         'description': 'Try Preserve UVs (Slower and does not always work)',
                                         'default': False})},
 'keyops.modi_key': {'type': ('StringProperty', {'name': 'type'})},
 'keyops.modi_key_no_undo': {'type': ('StringProperty', {'name': 'type'})},
 'keyops.outliner_click': {},
 'keyops.pivot_press': {'type': ('StringProperty', {'default': ''})},
 'keyops.quick_export': {'scale': ('FloatProperty', {'name': 'Scale', 'default': 1.0}),
                         'format': ('EnumProperty',
                                    {'name': 'Format',
                                     'items': [('OBJ', 'Wavefront (.obj', 'Wavefront (.obj)'),
                                               ('FBX', '.fbx', '.fbx'),
                                               ('GLTF', 'GLTF', 'GLTF'),
                                               ('USD', 'USD', 'USD'),
                                               ('ABC', 'Alembic (.ABC)', 'Alembic')],
                                     'default': 'OBJ'}),
                         'selected': ('BoolProperty', {'name': 'Selected', 'default': True})},
 'keyops.remove_seam': {},
 'keyops.select_edge_loop': {},
 'keyops.select_edge_loop_shift': {},
 'keyops.smart_uv_sync': {'fast_sync': ('BoolProperty',
                                        {'name': 'Fast Mode',
                                         'default': False,
                                         'description': 'Fast Mode, Right Click to Toggle Sync Mode and UV '
                                                        'Selection, can be slow on very large meshes'})},
 'keyops.toggle_retopology': {'type': ('StringProperty', {'default': ''})},
 'keyops.toolkit_panel': {'type': ('StringProperty', {}),
                          'select_children': ('BoolProperty', {'name': 'Select Children', 'default': True}),
                          'select_parent': ('BoolProperty', {'name': 'Select Parent', 'default': True}),
                          'select_top_parent': ('BoolProperty', {'name': 'Select Top Parent', 'default': True}),
                          'set_material_index': ('BoolProperty', {'name': 'Set Material Index', 'default': False}),
                          'join_objects': ('BoolProperty', {'name': 'Join Objects', 'default': True}),
                          'apply_instances': ('BoolProperty', {'name': 'Apply Instances', 'default': True}),
                          'scale': ('FloatProperty', {'name': 'Scale', 'default': 5.0}),
                          'mix_factor': ('FloatProperty',
                                         {'name': 'Mix Factor', 'default': 1.0, 'min': 0.0, 'max': 1.0}),
                          'set_orgin_to_geometry': ('BoolProperty',
                                                    {'name': 'Set Origin to Geometry', 'default': True}),
                          'subdivide': ('IntProperty', {'name': 'Subdivide', 'default': 6, 'min': 0, 'max': 10}),
                          'try_deduplicate_materials': ('BoolProperty',
                                                        {'name': 'Try Deduplicate Materials', 'default': True}),
                          'triangulate': ('BoolProperty', {'name': 'Triangulate', 'default': False}),
                          'rename_uv_layer': ('BoolProperty',
                                              {'name': 'Rename UV Layer 0 To UVMap', 'default': True}),
                          'join_children': ('BoolProperty', {'name': 'Join Children', 'default': True}),
                          'world_offset': ('BoolProperty', {'name': 'World Offset', 'default': False}),
                          'world_scale': ('BoolProperty', {'name': 'World Scale', 'default': False}),
                          'scale_triplanar': ('FloatProperty', {'name': 'Scale', 'default': 0.5}),
                          'rotation_triplanar': ('FloatProperty', {'name': 'Rotation', 'default': 0.0}),
                          'axis_x': ('FloatProperty', {'name': 'X', 'default': 0.5}),
                          'axis_y': ('FloatProperty', {'name': 'Y', 'default': 0.5}),
                          'appy_triplanar': ('BoolProperty', {'name': 'Apply Triplanar', 'default': False}),
                          'recalculate_normals': ('BoolProperty', {'name': 'Recalculate Normals', 'default': False}),
                          'triangulate_end': ('BoolProperty', {'name': 'Triangulate End', 'default': True}),
                          'angle_to_skip': ('FloatProperty',
                                            {'name': 'Angle to Skip',
                                             'subtype': 'ANGLE',
                                             'default': 1.5708,
                                             'min': 0.0,
                                             'max': 1.5708}),
                          'full_edge_loops': ('BoolProperty', {'name': 'Full Edge Loops', 'default': True}),
                          'angle_to_add': ('FloatProperty',
                                           {'name': 'Angle to Add',
                                            'subtype': 'ANGLE',
                                            'default': 1.5708,
                                            'min': 0.0,
                                            'max': 1.5708}),
                          'use_full_edge_loops': ('BoolProperty', {'name': 'Full Edge Loops', 'default': True}),
                          'convert_to_options': ('EnumProperty',
                                                 {'name': 'Convert To',
                                                  'items': [('Insta_Apply_Modifiers',
                                                             'Apply Viewport Modifiers',
                                                             'Apply Modifiers',
                                                             'MODIFIER_ON',
                                                             0),
                                                            ('Mesh', 'Mesh', 'Mesh', 'OUTLINER_OB_MESH', 1),
                                                            ('Curve', 'Curve', 'Curve', 'OUTLINER_OB_CURVE', 2),
                                                            ('Curves', 'Curves', 'Curves', 'OUTLINER_OB_CURVES', 3),
                                                            ('Grease_Pencil',
                                                             'Grease Pencil',
                                                             'Grease Pencil',
                                                             'OUTLINER_OB_GREASEPENCIL',
                                                             4)],
                                                  'default': 'Insta_Apply_Modifiers'}),
                          'remove_modifiers': ('BoolProperty', {'name': 'Remove Modifiers', 'default': True}),
                          'ovveride_color': ('BoolProperty', {'name': 'Override Color', 'default': False}),
                          'ovveride_color_vec': ('FloatVectorProperty',
                                                 {'name': 'Color',
                                                  'default': (0.0, 0.0, 0.0, 1.0),
                                                  'subtype': 'COLOR',
                                                  'size': 4}),
                          'individual': ('BoolProperty',
                                         {'name': 'Individual',
                                          'description': 'Snap each object to the floor individually (hold Alt when '
                                                         'clicking button)',
                                          'default': False,
                                          'options': {'SKIP_SAVE'}}),
                          'exact': ('BoolProperty',
                                    {'name': 'Exact',
                                     'description': 'Exact snap to floor, but slower (hold Ctrl when clicking '
                                                    'button)',
                                     'default': True,
                                     'options': {'SKIP_SAVE'}}),
                          'instance': ('BoolProperty',
                                       {'name': 'Instanced',
                                        'description': 'Might provde better viewport performance, but some modifiers '
                                                       'and exporters will not work',
                                        'default': False})},
 'mesh.fast_connect': {},
 'transform.entering_transform_none_live_booleans': {},
 'uv.keyops_uv_cut': {'quick': ('BoolProperty',
                                {'name': 'Quick',
                                 'default': False,
                                 'description': 'Quick Cut',
                                 'options': {'HIDDEN', 'SKIP_SAVE'}})}}
_SMS_LAZY_RNA_SOURCE_CLASSES = {'vscp.copy_vertices': ('vertex_copy/core.py', 'VSCP_OT_copy_vertices'),
 'vscp.paste_same_index': ('vertex_copy/core.py', 'VSCP_OT_paste_same_index'),
 'vscp.validate_same_index': ('vertex_copy/core.py', 'VSCP_OT_validate_same_index'),
 'vscp.paste_vertices': ('vertex_copy/core.py', 'VSCP_OT_paste_vertices'),
 'vscp.validate_targets': ('vertex_copy/core.py', 'VSCP_OT_validate_targets'),
 'mesh.smart_vert_slide': ('vertex_slide/operators.py', 'MESH_OT_smart_vert_slide'),
 'mesh.smart_connect': ('connect/__init__.py', 'MESH_OT_smart_connect'),
 'mesh.smart_split': ('mesh_split/__init__.py', 'MESH_OT_smart_split'),
 'mesh.mesh_align_master': ('mesh_align_preset/__init__.py', 'MESH_OT_MeshAlignMaster'),
 'mesh.delete_direct': ('direct_delete/core.py', 'MESH_OT_delete_direct'),
 'mesh.delete_direct_del': ('direct_delete/core.py', 'MESH_OT_delete_direct_del'),
 'mesh.delete_direct_bs': ('direct_delete/core.py', 'MESH_OT_delete_direct_bs'),
 'mesh.delete_direct_through': ('direct_delete/core.py', 'MESH_OT_delete_direct_through'),
 'object.delete_direct_objects': ('direct_delete/core.py', 'OBJECT_OT_delete_direct_objects'),
 'object.delete_history_modifiers': ('direct_delete/core.py', 'OBJECT_OT_delete_history_mods'),
 'mo2.organize_modal': ('model_organized/operators.py', 'MO2_OT_OrganizeModal'),
 'mo2.restore_backup': ('model_organized/operators.py', 'MO2_OT_RestoreBackup'),
 'mesh.edge_crease_master': ('crease_preset/__init__.py', 'MESH_OT_CreaseMaster'),
 'mesh.toggle_merge_snap': ('toggle_auto_merge_snap/__init__.py', 'MESH_OT_toggle_merge_snap'),
 'mesh.apply_weighted_normal': ('apply_weighted_normal/__init__.py', 'MESH_OT_ApplyWeightedNormal'),
 'smsk.annotation_to_curve': ('sketch_tools.py', 'SMSK_OT_annotation_to_curve'),
 'smsk.annotation_to_surface_strip': ('sketch_tools.py', 'SMSK_OT_annotation_to_surface_strip'),
 'mesh.quad_strip_draw': ('quad_strip_draw/__init__.py', 'MESH_OT_quad_strip_draw'),
 'mesh.qsd_retopo_pen': ('quad_strip_draw/__init__.py', 'MESH_OT_qsd_retopo_pen'),
 'smsuite.context_modeler': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_context_modeler'),
 'smsuite.loop_shape_suite': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_loop_shape_suite'),
 'smsuite.quad_rebuild': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_quad_rebuild'),
 'smsuite.align_unbend': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_align_unbend'),
 'smsuite.boolean_fusion_stack': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_boolean_fusion_stack'),
 'smsuite.boolean_apply_clean': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_boolean_apply_clean'),
 'smsuite.bevel_normal_stack': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_bevel_normal_stack'),
 'smsuite.unbevel_planar_clean': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_unbevel_planar_clean'),
 'smsuite.solidify_plus': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_solidify_plus'),
 'smsuite.kit_insert': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_kit_insert'),
 'smsuite.cable_pipe_from_selection': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_cable_pipe_from_selection'),
 'smsuite.rail_sweep_generator': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_rail_sweep_generator'),
 'smsuite.bend_projection': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_bend_projection'),
 'smsuite.retopo_wrap_remesh': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_retopo_wrap_remesh'),
 'smsuite.falloff_deform': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_falloff_deform'),
 'smsuite.scatter_surface': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_scatter_surface'),
 'smsuite.floor_wall_generator': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_floor_wall_generator'),
 'smsuite.terrain_generator': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_terrain_generator'),
 'smsuite.slice_wire_detail': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_slice_wire_detail'),
 'smsuite.modifier_stack_preset': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_modifier_stack_preset'),
 'smsuite.mesh_repair_audit': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_mesh_repair_audit'),
 'smsuite.cad_import_cleaner': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_cad_import_cleaner'),
 'smsuite.workplane_pivot_tools': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_workplane_pivot_tools'),
 'smsuite.drop_snap_tools': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_drop_snap_tools'),
 'smsuite.asset_replace_randomize': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_asset_replace_randomize'),
 'smsuite.magic_solo': ('modeling_toolset_tools/__init__.py', 'SMSUITE_OT_magic_solo'),
 'keyops.auto_delete': ('key_operators_toolkit/fix_maya_pivot/operators/auto_delete.py', 'AutoDelete'),
 'keyops.double_click_select_island': ('key_operators_toolkit/fix_maya_pivot/operators/double_click_select_island.py',
                                       'DoubleClickSelectIsland'),
 'keyops.fast_merge': ('key_operators_toolkit/fix_maya_pivot/operators/fast_merge.py', 'FastMerge'),
 'keyops.modi_key': ('key_operators_toolkit/fix_maya_pivot/operators/modi_key.py', 'ModiKey'),
 'keyops.modi_key_no_undo': ('key_operators_toolkit/fix_maya_pivot/operators/modi_key.py', 'ModiKeyNoUndo'),
 'keyops.outliner_click': ('key_operators_toolkit/fix_maya_pivot/operators/outliner_options.py', 'OutlinerClick'),
 'keyops.pivot_press': ('key_operators_toolkit/fix_maya_pivot/operators/maya_pivot.py', 'PivotPress'),
 'keyops.quick_export': ('key_operators_toolkit/fix_maya_pivot/operators/quick_export.py', 'QuickExport'),
 'keyops.remove_seam': ('key_operators_toolkit/fix_maya_pivot/operators/uv_tools.py', 'RemoveSeam'),
 'keyops.select_edge_loop': ('key_operators_toolkit/fix_maya_pivot/operators/double_click_select_island.py',
                             'SelectEdgeLoop'),
 'keyops.select_edge_loop_shift': ('key_operators_toolkit/fix_maya_pivot/operators/double_click_select_island.py',
                                   'SelectEdgeLoopShift'),
 'keyops.smart_uv_sync': ('key_operators_toolkit/fix_maya_pivot/operators/uv_tools.py', 'SmartUVSync'),
 'keyops.toggle_retopology': ('key_operators_toolkit/fix_maya_pivot/operators/toggle_retopology.py',
                              'ToggleRetopology'),
 'keyops.toolkit_panel': ('key_operators_toolkit/fix_maya_pivot/operators/toolkit_panel.py', 'ToolkitPanel'),
 'mesh.fast_connect': ('key_operators_toolkit/fix_maya_pivot/operators/fast_merge.py', 'FastConnect'),
 'transform.entering_transform_none_live_booleans': ('key_operators_toolkit/fix_maya_pivot/operators/none_live_booleans.py',
                                                     'ENTERING_TRANSFORM_OT_None_Live_Booleans'),
 'uv.keyops_uv_cut': ('key_operators_toolkit/fix_maya_pivot/operators/uv_tools.py', 'UVCut')}
_SMS_LAZY_RNA_DYNAMIC_ENUM_FALLBACKS = {'enum_tool_callback': (('NONE', 'None', '', '', 0),
                        ('MASTER', 'Master Tool', '', '', 1),
                        ('LOWPOLY', 'Make Polygon', '', '', 2),
                        ('BRUSH', 'Brush', '', '', 3),
                        ('EXTRUDE', 'Edge Extrude', '', '', 4),
                        ('KNIFE', 'Knife', '', '', 5),
                        ('DELETE', 'Delete', '', '', 6),
                        ('EDGELOOP', 'EdgeLoop Tool', '', '', 7),
                        ('LOOPCUT', 'Loop Cut', '', '', 8),
                        ('EDGELOOP_EXTRUDE', 'EdgeLoop Extrude', '', '', 9),
                        ('EDGELOOP_DISSOLVE', 'Dissolve Loop', '', '', 10),
                        ('MARK_SEAM', 'Mark Seam', '', '', 11),
                        ('MARK_SEAM_LOOP', 'Mark Seam Loop', '', '', 12),
                        ('QUADPATCH', 'QuadPatch Tool', '', '', 13)),
 'enum_geometry_type_callback': (('VERT', 'Vertex', '', 0, 1),
                                 ('EDGE', 'Edge', '', 0, 2),
                                 ('TRI', 'Triangle', '', 0, 3),
                                 ('QUAD', 'Quad', '', 0, 0),
                                 ('POLY', 'Polygon', '', 0, 4)),
 'enum_move_type_callback': (('FREE', 'Free', '', 0, 0),
                             ('X', 'X', '', 0, 1),
                             ('Y', 'Y', '', 0, 2),
                             ('Z', 'Z', '', 0, 3),
                             ('NORMAL', 'Normal', '', 0, 4),
                             ('TANGENT', 'Tangent', '', 0, 5)),
 'enum_brush_type_callback': (('SMOOTH', 'Smooth', '', 0, 0),
                              ('MOVE', 'Move', '', 0, 1),
                              ('DELETE', 'Delete', '', 0, 2))}
_SMS_LAZY_OPERATOR_METADATA = {'vscp.copy_vertices': {'bl_options': ('UNDO',), 'no_undo': False, 'explicit_no_undo': False, 'preserve_undo': True},
 'vscp.paste_same_index': {'bl_options': ('UNDO',),
                           'no_undo': False,
                           'explicit_no_undo': False,
                           'preserve_undo': True},
 'vscp.validate_same_index': {'bl_options': ('UNDO',),
                              'no_undo': False,
                              'explicit_no_undo': False,
                              'preserve_undo': True},
 'vscp.paste_vertices': {'bl_options': ('UNDO',), 'no_undo': False, 'explicit_no_undo': False, 'preserve_undo': True},
 'vscp.validate_targets': {'bl_options': ('UNDO',),
                           'no_undo': False,
                           'explicit_no_undo': False,
                           'preserve_undo': True},
 'mesh.smart_vert_slide': {'bl_options': ('UNDO',),
                           'no_undo': False,
                           'explicit_no_undo': False,
                           'preserve_undo': True},
 'mesh.smart_connect': {'bl_options': (), 'no_undo': True, 'explicit_no_undo': True, 'preserve_undo': False},
 'mesh.smart_split': {'bl_options': (), 'no_undo': True, 'explicit_no_undo': True, 'preserve_undo': False},
 'mesh.mesh_align_master': {'bl_options': ('INTERNAL',),
                            'no_undo': True,
                            'explicit_no_undo': True,
                            'preserve_undo': False},
 'mesh.delete_direct': {'bl_options': (), 'no_undo': True, 'explicit_no_undo': True, 'preserve_undo': False},
 'mesh.delete_direct_del': {'bl_options': (), 'no_undo': True, 'explicit_no_undo': True, 'preserve_undo': False},
 'mesh.delete_direct_bs': {'bl_options': (), 'no_undo': True, 'explicit_no_undo': True, 'preserve_undo': False},
 'mesh.delete_direct_through': {'bl_options': (), 'no_undo': True, 'explicit_no_undo': True, 'preserve_undo': False},
 'object.delete_direct_objects': {'bl_options': (),
                                  'no_undo': True,
                                  'explicit_no_undo': True,
                                  'preserve_undo': False},
 'object.delete_history_modifiers': {'bl_options': (),
                                     'no_undo': True,
                                     'explicit_no_undo': True,
                                     'preserve_undo': False},
 'mo2.organize_modal': {'bl_options': ('UNDO',), 'no_undo': False, 'explicit_no_undo': False, 'preserve_undo': True},
 'mo2.restore_backup': {'bl_options': ('UNDO',), 'no_undo': False, 'explicit_no_undo': False, 'preserve_undo': True},
 'mesh.edge_crease_master': {'bl_options': ('INTERNAL',),
                             'no_undo': True,
                             'explicit_no_undo': True,
                             'preserve_undo': False},
 'mesh.toggle_merge_snap': {'bl_options': ('UNDO',),
                            'no_undo': False,
                            'explicit_no_undo': False,
                            'preserve_undo': True},
 'mesh.apply_weighted_normal': {'bl_options': ('UNDO',),
                                'no_undo': False,
                                'explicit_no_undo': False,
                                'preserve_undo': True},
 'smsk.annotation_to_curve': {'bl_options': ('UNDO',),
                              'no_undo': False,
                              'explicit_no_undo': False,
                              'preserve_undo': True},
 'smsk.annotation_to_surface_strip': {'bl_options': ('UNDO',),
                                      'no_undo': False,
                                      'explicit_no_undo': False,
                                      'preserve_undo': True},
 'mesh.quad_strip_draw': {'bl_options': ('BLOCKING', 'UNDO'),
                          'no_undo': False,
                          'explicit_no_undo': False,
                          'preserve_undo': True},
 'mesh.qsd_retopo_pen': {'bl_options': ('UNDO',), 'no_undo': False, 'explicit_no_undo': False, 'preserve_undo': True},
 'smsuite.context_modeler': {'bl_options': ('UNDO',),
                             'no_undo': False,
                             'explicit_no_undo': False,
                             'preserve_undo': True},
 'smsuite.loop_shape_suite': {'bl_options': ('UNDO',),
                              'no_undo': False,
                              'explicit_no_undo': False,
                              'preserve_undo': True},
 'smsuite.quad_rebuild': {'bl_options': ('UNDO',),
                          'no_undo': False,
                          'explicit_no_undo': False,
                          'preserve_undo': True},
 'smsuite.align_unbend': {'bl_options': ('UNDO',),
                          'no_undo': False,
                          'explicit_no_undo': False,
                          'preserve_undo': True},
 'smsuite.boolean_fusion_stack': {'bl_options': ('UNDO',),
                                  'no_undo': False,
                                  'explicit_no_undo': False,
                                  'preserve_undo': True},
 'smsuite.boolean_apply_clean': {'bl_options': ('UNDO',),
                                 'no_undo': False,
                                 'explicit_no_undo': False,
                                 'preserve_undo': True},
 'smsuite.bevel_normal_stack': {'bl_options': ('UNDO',),
                                'no_undo': False,
                                'explicit_no_undo': False,
                                'preserve_undo': True},
 'smsuite.unbevel_planar_clean': {'bl_options': ('UNDO',),
                                  'no_undo': False,
                                  'explicit_no_undo': False,
                                  'preserve_undo': True},
 'smsuite.solidify_plus': {'bl_options': ('UNDO',),
                           'no_undo': False,
                           'explicit_no_undo': False,
                           'preserve_undo': True},
 'smsuite.kit_insert': {'bl_options': ('UNDO',), 'no_undo': False, 'explicit_no_undo': False, 'preserve_undo': True},
 'smsuite.cable_pipe_from_selection': {'bl_options': ('UNDO',),
                                       'no_undo': False,
                                       'explicit_no_undo': False,
                                       'preserve_undo': True},
 'smsuite.rail_sweep_generator': {'bl_options': ('UNDO',),
                                  'no_undo': False,
                                  'explicit_no_undo': False,
                                  'preserve_undo': True},
 'smsuite.bend_projection': {'bl_options': ('UNDO',),
                             'no_undo': False,
                             'explicit_no_undo': False,
                             'preserve_undo': True},
 'smsuite.retopo_wrap_remesh': {'bl_options': ('UNDO',),
                                'no_undo': False,
                                'explicit_no_undo': False,
                                'preserve_undo': True},
 'smsuite.falloff_deform': {'bl_options': ('UNDO',),
                            'no_undo': False,
                            'explicit_no_undo': False,
                            'preserve_undo': True},
 'smsuite.scatter_surface': {'bl_options': ('UNDO',),
                             'no_undo': False,
                             'explicit_no_undo': False,
                             'preserve_undo': True},
 'smsuite.floor_wall_generator': {'bl_options': ('UNDO',),
                                  'no_undo': False,
                                  'explicit_no_undo': False,
                                  'preserve_undo': True},
 'smsuite.terrain_generator': {'bl_options': ('UNDO',),
                               'no_undo': False,
                               'explicit_no_undo': False,
                               'preserve_undo': True},
 'smsuite.slice_wire_detail': {'bl_options': ('UNDO',),
                               'no_undo': False,
                               'explicit_no_undo': False,
                               'preserve_undo': True},
 'smsuite.modifier_stack_preset': {'bl_options': ('UNDO',),
                                   'no_undo': False,
                                   'explicit_no_undo': False,
                                   'preserve_undo': True},
 'smsuite.mesh_repair_audit': {'bl_options': ('UNDO',),
                               'no_undo': False,
                               'explicit_no_undo': False,
                               'preserve_undo': True},
 'smsuite.cad_import_cleaner': {'bl_options': ('UNDO',),
                                'no_undo': False,
                                'explicit_no_undo': False,
                                'preserve_undo': True},
 'smsuite.workplane_pivot_tools': {'bl_options': ('UNDO',),
                                   'no_undo': False,
                                   'explicit_no_undo': False,
                                   'preserve_undo': True},
 'smsuite.drop_snap_tools': {'bl_options': ('UNDO',),
                             'no_undo': False,
                             'explicit_no_undo': False,
                             'preserve_undo': True},
 'smsuite.asset_replace_randomize': {'bl_options': ('UNDO',),
                                     'no_undo': False,
                                     'explicit_no_undo': False,
                                     'preserve_undo': True},
 'smsuite.magic_solo': {'bl_options': ('UNDO',), 'no_undo': False, 'explicit_no_undo': False, 'preserve_undo': True},
 'keyops.auto_delete': {'bl_options': ('UNDO',), 'no_undo': False, 'explicit_no_undo': False, 'preserve_undo': True},
 'keyops.double_click_select_island': {'bl_options': ('INTERNAL',),
                                       'no_undo': True,
                                       'explicit_no_undo': True,
                                       'preserve_undo': False},
 'keyops.fast_merge': {'bl_options': ('UNDO',), 'no_undo': False, 'explicit_no_undo': False, 'preserve_undo': True},
 'keyops.modi_key': {'bl_options': ('INTERNAL',), 'no_undo': True, 'explicit_no_undo': True, 'preserve_undo': False},
 'keyops.modi_key_no_undo': {'bl_options': ('INTERNAL',),
                             'no_undo': True,
                             'explicit_no_undo': True,
                             'preserve_undo': False},
 'keyops.outliner_click': {'bl_options': ('INTERNAL',),
                           'no_undo': True,
                           'explicit_no_undo': True,
                           'preserve_undo': False},
 'keyops.pivot_press': {'bl_options': (), 'no_undo': True, 'explicit_no_undo': True, 'preserve_undo': False},
 'keyops.quick_export': {'bl_options': (), 'no_undo': True, 'explicit_no_undo': True, 'preserve_undo': False},
 'keyops.remove_seam': {'bl_options': ('UNDO',), 'no_undo': False, 'explicit_no_undo': False, 'preserve_undo': True},
 'keyops.select_edge_loop': {'bl_options': ('INTERNAL',),
                             'no_undo': True,
                             'explicit_no_undo': True,
                             'preserve_undo': False},
 'keyops.select_edge_loop_shift': {'bl_options': ('INTERNAL',),
                                   'no_undo': True,
                                   'explicit_no_undo': True,
                                   'preserve_undo': False},
 'keyops.smart_uv_sync': {'bl_options': ('UNDO',),
                          'no_undo': False,
                          'explicit_no_undo': False,
                          'preserve_undo': True},
 'keyops.toggle_retopology': {'bl_options': ('INTERNAL', 'PRESET', 'UNDO'),
                              'no_undo': False,
                              'explicit_no_undo': False,
                              'preserve_undo': True},
 'keyops.toolkit_panel': {'bl_options': ('UNDO',),
                          'no_undo': False,
                          'explicit_no_undo': False,
                          'preserve_undo': True},
 'mesh.fast_connect': {'bl_options': (), 'no_undo': True, 'explicit_no_undo': True, 'preserve_undo': False},
 'transform.entering_transform_none_live_booleans': {'bl_options': ('INTERNAL',),
                                                     'no_undo': True,
                                                     'explicit_no_undo': True,
                                                     'preserve_undo': False},
 'uv.keyops_uv_cut': {'bl_options': ('UNDO',), 'no_undo': False, 'explicit_no_undo': False, 'preserve_undo': True}}
# END GENERATED SMART MODELING LAZY RNA SCHEMA


_SMS_LAZY_RNA_DYNAMIC_ENUM_CALLBACKS = {}


def _sms_canonical_lazy_schema_idname(idname: str) -> str:
    idname = str(idname or '').strip()
    for aliases in _SMS_NATIVE_KEYMAP_COMPAT_ALIASES.values():
        canonical = str(aliases.get(idname) or '').strip()
        if canonical:
            return canonical
    return idname


def _sms_lazy_dynamic_enum_callback(callback_name: str):
    """Return a zero-import enum bridge for a deferred operator property."""
    callback_name = str(callback_name or '').strip()
    cached = _SMS_LAZY_RNA_DYNAMIC_ENUM_CALLBACKS.get(callback_name)
    if callable(cached):
        return cached
    fallback = tuple(_SMS_LAZY_RNA_DYNAMIC_ENUM_FALLBACKS.get(callback_name, ()))

    def items(owner, context):
        module = sys.modules.get(
            f'{__package__}.polyquilt_fork.poly_quilt_fork.pq_operator'
        )
        if module is None:
            for module_name, candidate in tuple(sys.modules.items()):
                if str(module_name).endswith('.poly_quilt_fork.pq_operator'):
                    module = candidate
                    break
        real_callback = getattr(module, callback_name, None) if module is not None else None
        if callable(real_callback):
            try:
                real_items = tuple(real_callback(owner, context))
                if real_items:
                    return real_items
            except Exception:
                pass
        return fallback

    items.__name__ = f'_sms_lazy_{callback_name}'
    _SMS_LAZY_RNA_DYNAMIC_ENUM_CALLBACKS[callback_name] = items
    return items


def _sms_build_lazy_rna_annotations(idname: str) -> dict:
    """Materialize the complete lightweight RNA schema for one shell ID."""
    idname = _sms_canonical_lazy_schema_idname(idname)
    definitions = _SMS_LAZY_RNA_PROPERTY_SCHEMAS.get(idname)
    if definitions is None:
        raise RuntimeError(f'No lazy RNA schema is declared for {idname!r}')
    annotations = {}
    for property_name, definition in definitions.items():
        factory_name, source_kwargs = definition
        factory = getattr(bpy.props, str(factory_name or ''), None)
        if not callable(factory):
            raise RuntimeError(
                f'Unsupported lazy RNA factory for {idname}.{property_name}: {factory_name}'
            )
        kwargs = dict(source_kwargs or {})
        marker = kwargs.get('items')
        if (
            isinstance(marker, tuple)
            and len(marker) == 2
            and marker[0] == '__SMS_DYNAMIC_ENUM__'
        ):
            kwargs['items'] = _sms_lazy_dynamic_enum_callback(marker[1])
        annotations[property_name] = factory(**kwargs)
    return annotations


def _sms_lazy_operator_registration_metadata(idname: str):
    """Return normalized flags that must exist before wmOperatorType register."""
    idname = _sms_canonical_lazy_schema_idname(idname)
    metadata = _SMS_LAZY_OPERATOR_METADATA.get(idname)
    if metadata is None:
        raise RuntimeError(f'No lazy operator metadata is declared for {idname!r}')
    options = {str(item) for item in metadata.get('bl_options', ())}
    options.discard('REGISTER')
    options.discard('UNDO_GROUPED')
    no_undo = bool(metadata.get('no_undo', False))
    if no_undo:
        options.discard('UNDO')
    preserve_undo = bool(metadata.get('preserve_undo', False))
    expected_preserve = bool('UNDO' in options and not no_undo)
    if preserve_undo != expected_preserve:
        raise RuntimeError(
            f'Invalid lazy Undo metadata for {idname}: '
            f'options={sorted(options)!r}, no_undo={no_undo!r}, '
            f'preserve_undo={preserve_undo!r}'
        )
    return options, no_undo, preserve_undo


def _sms_lazy_popup_proxy_needs_rebuild(cls, tool_id: str, idname: str) -> bool:
    """Return True for popup shells created by the malformed legacy layout."""
    if not isinstance(cls, type):
        return False
    key = (str(tool_id or '').strip(), str(idname or '').strip())
    if key not in _SMS_LAZY_PROXY_POPUP_HELPERS:
        return False
    try:
        namespace = getattr(cls, '__dict__', {}) or {}
        annotations = set((namespace.get('__annotations__') or {}).keys())
        has_draw = callable(namespace.get('draw'))
    except Exception:
        annotations = set()
        has_draw = False
    return (
        not has_draw
        or bool(annotations.intersection({'mode', 'action', 'topic'}))
    )


def _sms_make_lazy_keymap_proxy_class(tool_id: str, entry: dict):
    idname = str((entry or {}).get('idname') or '').strip()
    label = str((entry or {}).get('label_en') or (entry or {}).get('label_ja') or idname or 'Smart Modeling Command').strip()
    description = str((entry or {}).get('purpose_en') or (entry or {}).get('purpose_ja') or '').strip()
    tool_id = str(tool_id or '').strip()

    def poll(cls, context):
        # Do not import the real tool from poll(); Blender may call poll very
        # frequently while drawing menus/keymap UI.  The real operator validates
        # context after it is invoked.
        del cls, context
        return True

    def invoke(self, context, event):
        return _sms_delegate_lazy_keymap_operator(
            tool_id,
            idname,
            context=context,
            invoke=True,
            operator=self,
            event=event,
        )

    def execute(self, context):
        return _sms_delegate_lazy_keymap_operator(
            tool_id,
            idname,
            context=context,
            invoke=False,
            operator=self,
            event=None,
        )

    options, no_undo, preserve_undo = _sms_lazy_operator_registration_metadata(idname)
    options.update(_SMS_LAZY_KEYMAP_EXTRA_OPTIONS_BY_IDNAME.get(idname, ()))
    attrs = {
        '__module__': __name__,
        '__annotations__': _sms_build_lazy_rna_annotations(idname),
        'bl_idname': idname,
        'bl_label': label,
        'bl_description': description or f'Load and run {label}.',
        'bl_options': options,
        '_sms_lazy_proxy_preserve_undo': preserve_undo,
        '_sms_no_undo': no_undo,
        '_sms_lazy_keymap_proxy': True,
        '_sms_lazy_tool_id': tool_id,
        '_sms_lazy_target_idname': idname,
        'poll': classmethod(poll),
        'invoke': invoke,
        'execute': execute,
    }
    # Blender reads the modal callback when the class is registered, so the shell
    # must own one for every tool whose real operator turns modal on first use.
    def modal(self, context, event):
        source_cls = _SMS_LAZY_KEYMAP_SOURCE_CLASSES.get(idname)
        source_modal = getattr(source_cls, 'modal', None) if isinstance(source_cls, type) else None
        if callable(source_modal):
            return source_modal(self, context, event)
        _sms_record_native_keymap_failure(tool_id, f'{idname} modal implementation is unavailable.')
        return {'CANCELLED'}
    attrs['modal'] = modal
    if tool_id == 'model_organized' and idname == 'mo2.organize_modal':
        attrs['_sms_lazy_modal_owner'] = True
    if (tool_id, idname) in _SMS_LAZY_PROXY_POPUP_HELPERS:
        def draw(self, context):
            _sms_draw_lazy_popup_owner(tool_id, idname, self, context)
        attrs['draw'] = draw
        attrs['_sms_lazy_popup_owner'] = True
    return type(_sms_make_lazy_proxy_class_name(idname), (bpy.types.Operator,), attrs)


def _sms_register_lazy_keymap_proxy(tool_id: str, entry: dict) -> bool:
    idname = str((entry or {}).get('idname') or '').strip()
    if not idname:
        return False
    current = _sms_operator_class_by_idname(idname)
    if current is None:
        # Blender 5.1 does not always resolve dynamic Operator subclasses by
        # bl_idname.  Fall back to the canonical bpy.types class name so an
        # in-place upgrade can replace a malformed legacy popup shell.
        try:
            candidate = getattr(bpy.types, _sms_make_lazy_proxy_class_name(idname), None)
            if isinstance(candidate, type) and str(getattr(candidate, 'bl_idname', '') or '').strip() == idname:
                current = candidate
        except Exception:
            current = None
    if _sms_lazy_popup_proxy_needs_rebuild(current, tool_id, idname):
        if not _sms_class_is_owned_for_mutation(current):
            return False
        _sms_exact_safe_unregister_class(current)
        _sms_uncache_operator_class(idname, current)
        _SMS_LAZY_KEYMAP_PROXY_CLASSES.pop(idname, None)
        _SMS_LAZY_KEYMAP_PROXY_TOOL_BY_IDNAME.pop(idname, None)
        _SMS_LAZY_KEYMAP_PROXY_ACTIVE.discard(idname)
        current = None
    if _sms_is_lazy_proxy_class(current):
        _SMS_LAZY_KEYMAP_PROXY_CLASSES[idname] = current
        _SMS_LAZY_KEYMAP_PROXY_TOOL_BY_IDNAME[idname] = str(tool_id or '').strip()
        _SMS_LAZY_KEYMAP_PROXY_ACTIVE.add(idname)
        return True
    if current is not None and not _sms_is_lazy_proxy_class(current):
        # A real operator is already registered, so a proxy is not needed.
        return False
    if _sms_operator_registered_idname(idname):
        return False
    cls = _sms_make_lazy_keymap_proxy_class(tool_id, entry)
    try:
        existing_by_name = getattr(bpy.types, getattr(cls, '__name__', ''), None)
        if isinstance(existing_by_name, type) and existing_by_name is not cls:
            return False
    except Exception:
        pass
    if not _sms_exact_safe_register_class(cls):
        return False
    _SMS_LAZY_KEYMAP_PROXY_CLASSES[idname] = cls
    _sms_cache_operator_class(idname, cls)
    _SMS_LAZY_KEYMAP_PROXY_TOOL_BY_IDNAME[idname] = str(tool_id or '').strip()
    _SMS_LAZY_KEYMAP_PROXY_ACTIVE.add(idname)
    return True


def _sms_lazy_keymap_entrypoint_class(idname: str):
    """Return the exact live Operator class for a shortcut target."""
    idname = str(idname or '').strip()
    if not idname:
        return None
    cls = _sms_operator_class_by_idname(idname)
    if not isinstance(cls, type):
        try:
            cls = getattr(bpy.types, _sms_make_lazy_proxy_class_name(idname), None)
        except Exception:
            cls = None
    if not isinstance(cls, type):
        return None
    try:
        return cls if str(getattr(cls, 'bl_idname', '') or '').strip() == idname else None
    except Exception:
        return None


def _sms_register_lazy_keymap_proxies(tool_ids=None, *, strict: bool = False) -> int:
    requested = {str(item or '').strip() for item in tuple(tool_ids or ()) if str(item or '').strip()} if tool_ids else None
    expected = []
    errors = []
    for tool_id, entry in _sms_iter_native_keymap_specs():
        if requested is not None and tool_id not in requested:
            continue
        # The per-entry registrar preserves every real operator and creates a
        # shell only when that exact public ID is missing. Do not skip the whole
        # tool merely because its module state says loaded: an Always-on OFF
        # transition may have removed a captured operator while leaving the safe
        # module resident.
        idname = str((entry or {}).get('idname') or '').strip()
        if not idname:
            continue
        expected.append(idname)
        try:
            _sms_register_lazy_keymap_proxy(tool_id, entry)
        except Exception as exc:
            errors.append(f'{idname}:{type(exc).__name__}:{exc}')

        # A stale lookup cache must not consume the first shortcut.  Retry once
        # after an exact cache eviction, then verify the actual registered RNA
        # class rather than trusting register_class()'s return path.
        if _sms_lazy_keymap_entrypoint_class(idname) is None:
            try:
                _sms_uncache_operator_class(idname)
                _sms_register_lazy_keymap_proxy(tool_id, entry)
            except Exception as exc:
                errors.append(f'{idname}:retry:{type(exc).__name__}:{exc}')
    try:
        _sms_rebuild_native_tool_records()
    except Exception:
        pass
    available = tuple(
        idname for idname in dict.fromkeys(expected)
        if _sms_lazy_keymap_entrypoint_class(idname) is not None
    )
    missing = tuple(idname for idname in dict.fromkeys(expected) if idname not in available)
    if strict and missing:
        details = ['missing=' + ','.join(missing)]
        if errors:
            details.append('errors=' + ';'.join(errors[:8]))
        raise RuntimeError('Smart Modeling native first-key entrypoints unavailable: ' + ' | '.join(details))
    return len(available)



# Key Operation Tools is an integrated tool, but its manually registered
# shortcut IDs must exist before the user opens the Settings section.  Keep
# these RNA shells deliberately small: they register no timers, handlers,
# keymaps or draw callbacks.  The full integrated module is loaded only when
# one of the IDs is actually invoked.
_SMS_INTEGRATED_LAZY_ALIAS = 'key_operators_toolkit'
_SMS_INTEGRATED_LAZY_PROXY_CLASSES: dict[str, type] = {}
_SMS_INTEGRATED_LAZY_PROXY_DELEGATING: set[str] = set()


def _sms_integrated_lazy_specs():
    P = bpy.props
    return (
        {'idname':'keyops.auto_delete','label':'Auto Delete','options':{'UNDO'},'props':{'object_mode':P.BoolProperty(name='Object Mode', description='Delete objects in object mode', default=False)}},
        {'idname':'keyops.double_click_select_island','label':'Double Click Select Island','options':{'INTERNAL'},'no_undo':True,'props':{}},
        {'idname':'keyops.fast_merge','label':'Fast Merge','options':{'UNDO'},'props':{'preserve_uvs':P.BoolProperty(name='Preserve UVs', description='Try Preserve UVs (Slower and does not always work)', default=False)}},
        # Modi Key owns its atomic edit-mode bridge internally.  The shell must
        # not create an additional global undo step on the first invocation.
        {'idname':'keyops.modi_key','label':'Modifier Key','options':{'INTERNAL'},'no_undo':True,'props':{'type':P.StringProperty(name='type')}},
        {'idname':'keyops.modi_key_no_undo','label':'Modifier Key No Undo','options':{'INTERNAL'},'no_undo':True,'props':{'type':P.StringProperty(name='type')}},
        {'idname':'keyops.outliner_click','label':'Outliner Click','options':{'INTERNAL'},'no_undo':True,'props':{}},
        {'idname':'keyops.pivot_press','label':'Pivot Press','options':set(),'no_undo':True,'props':{'type':P.StringProperty(default='')}},
        {'idname':'keyops.quick_export','label':'Quick Export','options':set(),'no_undo':True,'props':{
            'scale':P.FloatProperty(name='Scale', default=1.0),
            'format':P.EnumProperty(name='Format', items=[('OBJ','Wavefront (.obj','Wavefront (.obj)'),('FBX','.fbx','.fbx'),('GLTF','GLTF','GLTF'),('USD','USD','USD'),('ABC','Alembic (.ABC)','Alembic')], default='OBJ'),
            'selected':P.BoolProperty(name='Selected', default=True),
        }},
        {'idname':'keyops.remove_seam','label':'Remove Seam','options':{'UNDO'},'props':{}},
        {'idname':'keyops.select_edge_loop','label':'Select Edge Loop','options':{'INTERNAL'},'no_undo':True,'props':{}},
        {'idname':'keyops.select_edge_loop_shift','label':'Select Edge Loop Shift','options':{'INTERNAL'},'no_undo':True,'props':{}},
        {'idname':'keyops.smart_uv_sync','label':'Smart UV Sync','options':{'UNDO'},'props':{'fast_sync':P.BoolProperty(name='Fast Mode', default=False, description='Fast Mode, Right Click to Toggle Sync Mode and UV Selection, can be slow on very large meshes')}},
        {'idname':'keyops.toggle_retopology','label':'Toggle Retopology','options':{'INTERNAL','PRESET','UNDO'},'props':{'type':P.StringProperty(default='')}},
        {'idname':'keyops.toolkit_panel','label':'Key Operations Toolkit','options':{'UNDO'},'props':{
            'type':P.StringProperty(),
            'select_children':P.BoolProperty(name='Select Children', default=True),
            'select_parent':P.BoolProperty(name='Select Parent', default=True),
            'select_top_parent':P.BoolProperty(name='Select Top Parent', default=True),
            'set_material_index':P.BoolProperty(name='Set Material Index', default=False),
            'join_objects':P.BoolProperty(name='Join Objects', default=True),
            'apply_instances':P.BoolProperty(name='Apply Instances', default=True),
            'scale':P.FloatProperty(name='Scale', default=5.0),
            'mix_factor':P.FloatProperty(name='Mix Factor', default=1.0, min=0.0, max=1.0),
            'set_orgin_to_geometry':P.BoolProperty(name='Set Origin to Geometry', default=True),
            'subdivide':P.IntProperty(name='Subdivide', default=6, min=0, max=10),
            'try_deduplicate_materials':P.BoolProperty(name='Try Deduplicate Materials', default=True),
            'triangulate':P.BoolProperty(name='Triangulate', default=False),
            'rename_uv_layer':P.BoolProperty(name='Rename UV Layer 0 To UVMap', default=True),
            'join_children':P.BoolProperty(name='Join Children', default=True),
            'world_offset':P.BoolProperty(name='World Offset', default=False),
            'world_scale':P.BoolProperty(name='World Scale', default=False),
            'scale_triplanar':P.FloatProperty(name='Scale', default=0.5),
            'rotation_triplanar':P.FloatProperty(name='Rotation', default=0.0),
            'axis_x':P.FloatProperty(name='X', default=0.5),
            'axis_y':P.FloatProperty(name='Y', default=0.5),
            'appy_triplanar':P.BoolProperty(name='Apply Triplanar', default=False),
            'recalculate_normals':P.BoolProperty(name='Recalculate Normals', default=False),
            'triangulate_end':P.BoolProperty(name='Triangulate End', default=True),
            'angle_to_skip':P.FloatProperty(name='Angle to Skip', subtype='ANGLE', default=1.5708, min=0.0, max=1.5708),
            'full_edge_loops':P.BoolProperty(name='Full Edge Loops', default=True),
            'angle_to_add':P.FloatProperty(name='Angle to Add', subtype='ANGLE', default=1.5708, min=0.0, max=1.5708),
            'use_full_edge_loops':P.BoolProperty(name='Full Edge Loops', default=True),
            'convert_to_options':P.EnumProperty(name='Convert To', items=[
                ('Insta_Apply_Modifiers','Apply Viewport Modifiers','Apply Modifiers','MODIFIER_ON',0),
                ('Mesh','Mesh','Mesh','OUTLINER_OB_MESH',1),
                ('Curve','Curve','Curve','OUTLINER_OB_CURVE',2),
                ('Curves','Curves','Curves','OUTLINER_OB_CURVES',3),
                ('Grease_Pencil','Grease Pencil','Grease Pencil','OUTLINER_OB_GREASEPENCIL',4),
            ], default='Insta_Apply_Modifiers'),
            'remove_modifiers':P.BoolProperty(name='Remove Modifiers', default=True),
            'ovveride_color':P.BoolProperty(name='Override Color', default=False),
            'ovveride_color_vec':P.FloatVectorProperty(name='Color', default=(0.0,0.0,0.0,1.0), subtype='COLOR', size=4),
            'individual':P.BoolProperty(name='Individual', description='Snap each object to the floor individually (hold Alt when clicking button)', default=False, options={'SKIP_SAVE'}),
            'exact':P.BoolProperty(name='Exact', description='Exact snap to floor, but slower (hold Ctrl when clicking button)', default=True, options={'SKIP_SAVE'}),
            'instance':P.BoolProperty(name='Instanced', description='Might provide better viewport performance, but some modifiers and exporters will not work', default=False),
        }},
        {'idname':'mesh.fast_connect','label':'Fast Connect','options':set(),'no_undo':True,'props':{}},
        {'idname':'transform.entering_transform_none_live_booleans','label':'None Live Booleans Transform','options':{'INTERNAL'},'no_undo':True,'props':{}},
        {'idname':'uv.keyops_uv_cut','label':'UV Cut','options':{'UNDO'},'props':{'quick':P.BoolProperty(name='Quick', default=False, description='Quick Cut', options={'HIDDEN','SKIP_SAVE'})}},
    )


def _sms_integrated_lazy_class_name(idname: str) -> str:
    namespace, opname = str(idname).split('.', 1)
    return f"{namespace.upper()}_OT_{''.join(ch if ch.isalnum() else '_' for ch in opname)}"


_SMS_INTEGRATED_LAZY_SOURCE_CLASSES = {
    'keyops.auto_delete': ('operators.auto_delete', 'AutoDelete'),
    'keyops.double_click_select_island': ('operators.double_click_select_island', 'DoubleClickSelectIsland'),
    'keyops.fast_merge': ('operators.fast_merge', 'FastMerge'),
    'keyops.modi_key': ('operators.modi_key', 'ModiKey'),
    'keyops.modi_key_no_undo': ('operators.modi_key', 'ModiKeyNoUndo'),
    'keyops.outliner_click': ('operators.outliner_options', 'OutlinerClick'),
    'keyops.pivot_press': ('operators.maya_pivot', 'PivotPress'),
    'keyops.quick_export': ('operators.quick_export', 'QuickExport'),
    'keyops.remove_seam': ('operators.uv_tools', 'RemoveSeam'),
    'keyops.select_edge_loop': ('operators.double_click_select_island', 'SelectEdgeLoop'),
    'keyops.select_edge_loop_shift': ('operators.double_click_select_island', 'SelectEdgeLoopShift'),
    'keyops.smart_uv_sync': ('operators.uv_tools', 'SmartUVSync'),
    'keyops.toggle_retopology': ('operators.toggle_retopology', 'ToggleRetopology'),
    'keyops.toolkit_panel': ('operators.toolkit_panel', 'ToolkitPanel'),
    'mesh.fast_connect': ('operators.fast_merge', 'FastConnect'),
    'transform.entering_transform_none_live_booleans': ('operators.none_live_booleans', 'ENTERING_TRANSFORM_OT_None_Live_Booleans'),
    'uv.keyops_uv_cut': ('operators.uv_tools', 'UVCut'),
}


def _sms_patch_integrated_lazy_targets() -> None:
    """Patch all public shortcut shells without enabling optional runtimes.

    Key Operation Tools allows individual operators to be disabled in its own
    preferences.  A user may still have a manually registered shortcut for
    such an operator.  Loading the integrated package must therefore make the
    public implementation available, but it must not invoke the source class's
    register() callback because that callback may install handlers or UI.
    """
    try:
        from . import loader as _sms_loader
    except Exception:
        return
    for idname, (module_rel, class_name) in _SMS_INTEGRATED_LAZY_SOURCE_CLASSES.items():
        live = _SMS_INTEGRATED_LAZY_PROXY_CLASSES.get(idname) or _sms_operator_class_by_idname(idname)
        if not isinstance(live, type):
            continue
        try:
            module = __import__(
                f'{__package__}.key_operators_toolkit.fix_maya_pivot.{module_rel}',
                fromlist=[class_name],
            )
            source = getattr(module, class_name, None)
            if isinstance(source, type):
                _sms_loader._patch_registered_class_in_place_51(live, source)
        except Exception:
            continue


def _sms_integrated_lazy_delegate(self, context, *, invoke=False, event=None):
    idname = str(getattr(type(self), 'bl_idname', '') or '').strip()
    if not idname or idname in _SMS_INTEGRATED_LAZY_PROXY_DELEGATING:
        return {'CANCELLED'}
    _SMS_INTEGRATED_LAZY_PROXY_DELEGATING.add(idname)
    try:
        try:
            captured_values = _sms_capture_lazy_ui_values(
                'integrated',
                _SMS_INTEGRATED_LAZY_ALIAS,
                context=context,
            )
        except Exception:
            captured_values = {}
        if not _sms_ensure_integrated_tool_loaded(_SMS_INTEGRATED_LAZY_ALIAS, context=context):
            return {'CANCELLED'}
        try:
            _sms_sync_lazy_ui_settings_to_runtime(
                'integrated',
                _SMS_INTEGRATED_LAZY_ALIAS,
                context=context,
                captured_values=captured_values,
            )
        except Exception:
            pass
        _sms_patch_integrated_lazy_targets()
        live_cls = _SMS_INTEGRATED_LAZY_PROXY_CLASSES.get(idname) or _sms_operator_class_by_idname(idname)
        if not isinstance(live_cls, type):
            return {'CANCELLED'}
        # The lightweight shell must accept a shortcut before the real module
        # exists, so its initial poll() is deliberately permissive.  Re-run the
        # real operator's poll() after patching to avoid executing a manually
        # bound shortcut in an invalid editor or mode.
        try:
            poll_method = getattr(live_cls, 'poll', None)
            if callable(poll_method) and not bool(poll_method(context)):
                return {'CANCELLED'}
        except Exception:
            return {'CANCELLED'}
        # The loader patches the registered shell in place.  Call the newly
        # installed implementation directly on this same wmOperator instance so
        # RNA properties supplied by the keymap survive the first invocation.
        # Status instrumentation wraps proxy callbacks, so identity with the
        # unwrapped proxy function cannot tell whether invoke is implemented.
        # Resolve the source's actual callback contract before dispatching.
        module_rel, class_name = _SMS_INTEGRATED_LAZY_SOURCE_CLASSES[idname]
        source_module = __import__(
            f'{__package__}.key_operators_toolkit.fix_maya_pivot.{module_rel}',
            fromlist=[class_name],
        )
        source_cls = getattr(source_module, class_name)
        call_with_event = bool(invoke and callable(getattr(source_cls, 'invoke', None)))
        method = getattr(live_cls, 'invoke' if call_with_event else 'execute', None)
        if not callable(method):
            return {'CANCELLED'}
        if call_with_event:
            return method(self, context, event)
        return method(self, context)
    except Exception:
        return {'CANCELLED'}
    finally:
        _SMS_INTEGRATED_LAZY_PROXY_DELEGATING.discard(idname)


def _sms_integrated_lazy_invoke(self, context, event):
    return _sms_integrated_lazy_delegate(self, context, invoke=True, event=event)


def _sms_integrated_lazy_execute(self, context):
    return _sms_integrated_lazy_delegate(self, context, invoke=False)


def _sms_make_integrated_lazy_proxy(spec):
    idname = str(spec.get('idname') or '').strip()
    options = set(spec.get('options') or ())
    no_undo = bool(spec.get('no_undo', False))
    owns_undo = 'UNDO' in options and not no_undo
    attrs = {
        '__module__': __name__,
        '__annotations__': dict(spec.get('props') or {}),
        'bl_idname': idname,
        'bl_label': str(spec.get('label') or idname),
        'bl_description': 'Load Key Operation Tools on first use and run this command.',
        'bl_options': options,
        '_sms_integrated_lazy_proxy': True,
        '_sms_lazy_keymap_proxy': True,
        '_sms_lazy_proxy_preserve_undo': owns_undo,
        '_sms_no_undo': no_undo,
        '_sms_lazy_tool_id': _SMS_INTEGRATED_LAZY_ALIAS,
        '_sms_lazy_target_idname': idname,
        'poll': classmethod(lambda cls, context: True),
        'invoke': _sms_integrated_lazy_invoke,
        'execute': _sms_integrated_lazy_execute,
    }
    return type(_sms_integrated_lazy_class_name(idname), (bpy.types.Operator,), attrs)


def _sms_register_integrated_lazy_proxies(*, strict: bool = False) -> int:
    expected = []
    errors = []
    for spec in _sms_integrated_lazy_specs():
        idname = str(spec.get('idname') or '').strip()
        if not idname:
            continue
        expected.append(idname)
        current = _sms_lazy_keymap_entrypoint_class(idname)
        if isinstance(current, type):
            if bool(getattr(current, '_sms_integrated_lazy_proxy', False)):
                _SMS_INTEGRATED_LAZY_PROXY_CLASSES[idname] = current
            continue
        cls = _sms_make_integrated_lazy_proxy(spec)
        try:
            if _sms_exact_safe_register_class(cls):
                _SMS_INTEGRATED_LAZY_PROXY_CLASSES[idname] = cls
                _sms_cache_operator_class(idname, cls)
        except Exception as exc:
            errors.append(f'{idname}:{type(exc).__name__}:{exc}')
        if _sms_lazy_keymap_entrypoint_class(idname) is None:
            try:
                _sms_uncache_operator_class(idname)
                if _sms_exact_safe_register_class(cls):
                    _SMS_INTEGRATED_LAZY_PROXY_CLASSES[idname] = cls
                    _sms_cache_operator_class(idname, cls)
            except Exception as exc:
                errors.append(f'{idname}:retry:{type(exc).__name__}:{exc}')

    available = tuple(
        idname for idname in dict.fromkeys(expected)
        if _sms_lazy_keymap_entrypoint_class(idname) is not None
    )
    missing = tuple(idname for idname in dict.fromkeys(expected) if idname not in available)
    if strict and missing:
        details = ['missing=' + ','.join(missing)]
        if errors:
            details.append('errors=' + ';'.join(errors[:8]))
        raise RuntimeError('Smart Modeling integrated first-key entrypoints unavailable: ' + ' | '.join(details))
    return len(available)


_SMS_BOUND_KEYMAP_PRELOAD_RESULTS: dict[str, bool] = {}
_SMS_BOUND_KEYMAP_POST_STARTUP_TIMER_ACTIVE = False
_SMS_BOUND_KEYMAP_ACTIVE_BRIDGES: list[tuple[object, object]] = []
_SMS_BOUND_KEYMAP_ACTIVE_BRIDGE_ERRORS: list[str] = []


def _sms_effective_keymap(keymap):
    """Return the runtime/user-editable map Blender actually dispatches."""
    try:
        active = getattr(keymap, 'active', None)
        if callable(active):
            resolved = active()
            if resolved is not None:
                return resolved
    except Exception:
        pass
    return keymap


def _sms_keymap_views(keymap) -> tuple:
    """Return base and active views without losing either registration form."""
    effective = _sms_effective_keymap(keymap)
    if effective is keymap:
        return (keymap,)
    return (keymap, effective)


def _sms_bound_keymap_idnames() -> tuple[str, ...]:
    """Return enabled Smart Modeling shortcuts restored by Blender.

    Blender 5.1 may keep a restored user keymap item out of event dispatch when
    its operator did not exist while the key configuration was built.  Merely
    registering a lightweight operator with that ID later does not reliably
    reactivate the item.  Keep this scan bounded to the two writable key
    configurations and to the exact public IDs declared by this suite.
    """
    try:
        integrated_ids = {
            str((spec or {}).get('idname') or '').strip()
            for spec in _sms_integrated_lazy_specs()
            if str((spec or {}).get('idname') or '').strip()
        }
    except Exception:
        integrated_ids = set()
    target_ids = set(_SMS_LAZY_KEYMAP_DECLARED_IDNAMES)
    target_ids.update(integrated_ids)
    if not target_ids:
        return ()

    found = set()
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        keyconfigs = getattr(wm, 'keyconfigs', None) if wm is not None else None
        if keyconfigs is None:
            return ()
        seen_configs = set()
        for config_name in ('user', 'addon', 'active', 'default'):
            keyconfig = getattr(keyconfigs, config_name, None)
            if keyconfig is None or id(keyconfig) in seen_configs:
                continue
            seen_configs.add(id(keyconfig))
            for keymap in keyconfig.keymaps:
                for keymap_view in _sms_keymap_views(keymap):
                    for item in keymap_view.keymap_items:
                        try:
                            idname = str(item.idname or '').strip()
                            if idname in target_ids and bool(item.active):
                                found.add(idname)
                        except Exception:
                            continue
    except Exception:
        return tuple(sorted(found))
    return tuple(sorted(found))


def _sms_preload_bound_keymap_tools(context=None) -> dict[str, bool]:
    """Materialize only tools that already own an enabled shortcut.

    This runs synchronously during add-on registration so Blender sees the real
    operator class before the restored keymap cache is rebuilt.  It performs no
    scene scan and installs no recurring timer.  Unbound tools remain lazy and
    therefore keep their zero-idle startup behavior.
    """
    global _SMS_BOUND_KEYMAP_PRELOAD_RESULTS
    bound_ids = set(_sms_bound_keymap_idnames())
    results: dict[str, bool] = {}
    if not bound_ids:
        _SMS_BOUND_KEYMAP_PRELOAD_RESULTS = results
        return results

    native_by_idname = {
        str((entry or {}).get('idname') or '').strip(): str(tool_id or '').strip()
        for tool_id, entry in _sms_iter_native_keymap_specs()
        if str((entry or {}).get('idname') or '').strip() and str(tool_id or '').strip()
    }
    native_tool_ids = tuple(dict.fromkeys(
        native_by_idname[idname]
        for idname in bound_ids
        if idname in native_by_idname
    ))
    for tool_id in native_tool_ids:
        try:
            # Preserve the registered startup shell's RNA identity. Blender's
            # active keymap keeps a pointer to that operator type; unregistering
            # it here makes the first restored shortcut silently disappear until
            # an unrelated UI action rebuilds the keymap. Native registration
            # patches the exact live shell in place with the real implementation.
            _sms_unregister_lazy_keymap_proxies_for_tool(tool_id)
            results[f'native:{tool_id}'] = bool(
                _sms_ensure_native_tool_loaded(tool_id, context=context or getattr(bpy, 'context', None))
            )
        except Exception:
            results[f'native:{tool_id}'] = False

    integrated_ids = {
        str((spec or {}).get('idname') or '').strip()
        for spec in _sms_integrated_lazy_specs()
        if str((spec or {}).get('idname') or '').strip()
    }
    if bound_ids.intersection(integrated_ids):
        try:
            results[f'integrated:{_SMS_INTEGRATED_LAZY_ALIAS}'] = bool(
                _sms_ensure_integrated_tool_loaded(
                    _SMS_INTEGRATED_LAZY_ALIAS,
                    context=context or getattr(bpy, 'context', None),
                )
            )
        except Exception:
            results[f'integrated:{_SMS_INTEGRATED_LAZY_ALIAS}'] = False

    _SMS_BOUND_KEYMAP_PRELOAD_RESULTS = results
    return dict(results)


def _sms_refresh_bound_keymap_entrypoints() -> bool:
    """Rebuild Blender's keymap cache after first-use operator IDs exist.

    User keymaps are restored before extension registration on some Blender 5.1
    startup paths.  An item whose operator ID did not exist at that moment stays
    absent from event dispatch even though its RNA row remains visible.  Opening
    the N-panel used to hide this by causing a later keyconfig rebuild.  Refresh
    once, and only when a Smart Modeling target is actually bound, so the first
    shortcut works after its bounded real operator registration.
    """
    try:
        integrated_ids = {
            str((spec or {}).get('idname') or '').strip()
            for spec in _sms_integrated_lazy_specs()
            if str((spec or {}).get('idname') or '').strip()
        }
    except Exception:
        integrated_ids = set()
    target_ids = set(_SMS_LAZY_KEYMAP_DECLARED_IDNAMES)
    target_ids.update(integrated_ids)
    if not target_ids:
        return False
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        keyconfigs = getattr(wm, 'keyconfigs', None) if wm is not None else None
        if keyconfigs is None:
            return False
        has_binding = False
        for config_name in ('user', 'addon'):
            keyconfig = getattr(keyconfigs, config_name, None)
            if keyconfig is None:
                continue
            for keymap in keyconfig.keymaps:
                for keymap_view in _sms_keymap_views(keymap):
                    if any(str(item.idname or '').strip() in target_ids for item in keymap_view.keymap_items):
                        has_binding = True
                        break
                if has_binding:
                    break
            if has_binding:
                break
        if not has_binding:
            return False
        update = getattr(keyconfigs, 'update', None)
        if not callable(update):
            return False
        update()
        return True
    except Exception:
        return False


def _sms_bound_keymap_item_signature(item) -> tuple:
    return (
        str(getattr(item, 'idname', '') or '').strip(),
        str(getattr(item, 'type', '') or '').strip(),
        str(getattr(item, 'value', '') or '').strip(),
        bool(getattr(item, 'any', False)),
        bool(getattr(item, 'shift', False)),
        bool(getattr(item, 'ctrl', False)),
        bool(getattr(item, 'alt', False)),
        bool(getattr(item, 'oskey', False)),
        str(getattr(item, 'key_modifier', 'NONE') or 'NONE'),
        str(getattr(item, 'direction', 'ANY') or 'ANY'),
        bool(getattr(item, 'repeat', False)),
    )


def _sms_copy_bound_keymap_properties(source, target) -> None:
    source_props = getattr(source, 'properties', None)
    target_props = getattr(target, 'properties', None)
    rna = getattr(source_props, 'bl_rna', None) if source_props is not None else None
    if source_props is None or target_props is None or rna is None:
        return
    for prop in getattr(rna, 'properties', ()):
        identifier = str(getattr(prop, 'identifier', '') or '').strip()
        if not identifier or identifier == 'rna_type' or bool(getattr(prop, 'is_readonly', False)):
            continue
        try:
            is_set = getattr(source_props, 'is_property_set', None)
            if callable(is_set) and not is_set(identifier):
                continue
            setattr(target_props, identifier, getattr(source_props, identifier))
        except Exception:
            continue


def _sms_remove_bound_keymap_active_bridges() -> None:
    global _SMS_BOUND_KEYMAP_ACTIVE_BRIDGES
    for keymap, item in reversed(tuple(_SMS_BOUND_KEYMAP_ACTIVE_BRIDGES)):
        try:
            keymap.keymap_items.remove(item)
        except Exception:
            pass
    _SMS_BOUND_KEYMAP_ACTIVE_BRIDGES = []


def _sms_install_bound_keymap_active_bridges() -> int:
    """Restore user rows Blender omitted before their operators existed."""
    global _SMS_BOUND_KEYMAP_ACTIVE_BRIDGES, _SMS_BOUND_KEYMAP_ACTIVE_BRIDGE_ERRORS
    _SMS_BOUND_KEYMAP_ACTIVE_BRIDGE_ERRORS = []
    target_ids = set(_sms_bound_keymap_idnames())
    if not target_ids:
        return 0
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        keyconfigs = getattr(wm, 'keyconfigs', None) if wm is not None else None
        user_config = getattr(keyconfigs, 'user', None) if keyconfigs is not None else None
        active_config = getattr(keyconfigs, 'active', None) if keyconfigs is not None else None
        if user_config is None or active_config is None:
            return 0
    except Exception:
        return 0

    active_signatures = set()
    try:
        for keymap in active_config.keymaps:
            identity = (
                str(getattr(keymap, 'name', '') or ''),
                str(getattr(keymap, 'space_type', 'EMPTY') or 'EMPTY'),
                str(getattr(keymap, 'region_type', 'WINDOW') or 'WINDOW'),
            )
            for item in keymap.keymap_items:
                if str(getattr(item, 'idname', '') or '').strip() in target_ids and bool(getattr(item, 'active', True)):
                    active_signatures.add((*identity, _sms_bound_keymap_item_signature(item)))
    except Exception:
        pass

    for source_keymap in user_config.keymaps:
        identity = (
            str(getattr(source_keymap, 'name', '') or ''),
            str(getattr(source_keymap, 'space_type', 'EMPTY') or 'EMPTY'),
            str(getattr(source_keymap, 'region_type', 'WINDOW') or 'WINDOW'),
        )
        for source_item in source_keymap.keymap_items:
            try:
                idname = str(source_item.idname or '').strip()
                if idname not in target_ids or not bool(source_item.active):
                    continue
                signature = _sms_bound_keymap_item_signature(source_item)
                if (*identity, signature) in active_signatures:
                    continue
                target_keymap = next(
                    (
                        keymap for keymap in active_config.keymaps
                        if str(getattr(keymap, 'name', '') or '') == identity[0]
                        and str(getattr(keymap, 'space_type', 'EMPTY') or 'EMPTY') == identity[1]
                        and str(getattr(keymap, 'region_type', 'WINDOW') or 'WINDOW') == identity[2]
                    ),
                    None,
                )
                if target_keymap is None:
                    target_keymap = active_config.keymaps.new(
                        name=identity[0],
                        space_type=identity[1],
                        region_type=identity[2],
                    )
                kwargs = {
                    'any': signature[3],
                    'shift': signature[4],
                    'ctrl': signature[5],
                    'alt': signature[6],
                    'oskey': signature[7],
                    'key_modifier': signature[8],
                    'repeat': signature[10],
                    'head': True,
                }
                if signature[9] not in {'', 'ANY'}:
                    kwargs['direction'] = signature[9]
                try:
                    target_item = target_keymap.keymap_items.new(
                        idname,
                        type=signature[1],
                        value=signature[2],
                        **kwargs,
                    )
                except TypeError:
                    kwargs.pop('direction', None)
                    kwargs.pop('repeat', None)
                    target_item = target_keymap.keymap_items.new(
                        idname,
                        type=signature[1],
                        value=signature[2],
                        **kwargs,
                    )
                target_item.active = True
                _sms_copy_bound_keymap_properties(source_item, target_item)
                _SMS_BOUND_KEYMAP_ACTIVE_BRIDGES.append((target_keymap, target_item))
                active_signatures.add((*identity, signature))
            except Exception as exc:
                if len(_SMS_BOUND_KEYMAP_ACTIVE_BRIDGE_ERRORS) < 8:
                    _SMS_BOUND_KEYMAP_ACTIVE_BRIDGE_ERRORS.append(
                        f'{type(exc).__name__}: {exc}'[:300]
                    )
                continue
    try:
        update = getattr(keyconfigs, 'update', None)
        if callable(update):
            update()
    except Exception:
        pass
    return len(_SMS_BOUND_KEYMAP_ACTIVE_BRIDGES)


def _sms_bound_keymap_post_startup_timer():
    """Merge restored shortcuts once Blender's window event loop is live."""
    global _SMS_BOUND_KEYMAP_POST_STARTUP_TIMER_ACTIVE
    _SMS_BOUND_KEYMAP_POST_STARTUP_TIMER_ACTIVE = False
    if not _sms_runtime_active():
        return None
    _sms_preload_bound_keymap_tools(getattr(bpy, 'context', None))
    try:
        _sms_register_lazy_keymap_proxies(strict=True)
    except Exception:
        pass
    try:
        _sms_register_integrated_lazy_proxies(strict=True)
    except Exception:
        pass
    _sms_refresh_bound_keymap_entrypoints()
    # Never copy items into keyconfigs.active. That collection is Blender's
    # derived dispatch map; direct additions can look valid in RNA while being
    # ignored by the window event system. The saved user map is refreshed above.
    return None


def _sms_schedule_bound_keymap_post_startup_sync(delay: float = 0.05) -> bool:
    global _SMS_BOUND_KEYMAP_POST_STARTUP_TIMER_ACTIVE
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is None:
            return False
        try:
            if hasattr(timers, 'is_registered') and timers.is_registered(_sms_bound_keymap_post_startup_timer):
                timers.unregister(_sms_bound_keymap_post_startup_timer)
        except Exception:
            pass
        timers.register(_sms_bound_keymap_post_startup_timer, first_interval=max(0.0, float(delay)))
        _SMS_BOUND_KEYMAP_POST_STARTUP_TIMER_ACTIVE = True
        return True
    except Exception:
        _SMS_BOUND_KEYMAP_POST_STARTUP_TIMER_ACTIVE = False
        return False


def _sms_cancel_bound_keymap_post_startup_sync() -> None:
    global _SMS_BOUND_KEYMAP_POST_STARTUP_TIMER_ACTIVE
    _SMS_BOUND_KEYMAP_POST_STARTUP_TIMER_ACTIVE = False
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_sms_bound_keymap_post_startup_timer):
            timers.unregister(_sms_bound_keymap_post_startup_timer)
    except Exception:
        pass
    _sms_remove_bound_keymap_active_bridges()


def _sms_unregister_integrated_lazy_proxies(*, force=False) -> None:
    # Loaded integrated classes are owned by loader.unregister_all().  This
    # function removes only shells that are still registered afterwards.  A
    # source class may define its own unregister() hook; suppress that hook here
    # because the loader has already executed it exactly once.
    for idname, remembered in reversed(tuple(_SMS_INTEGRATED_LAZY_PROXY_CLASSES.items())):
        cls = _sms_operator_class_by_idname(idname) or remembered
        if not isinstance(cls, type):
            continue
        if not force and not bool(getattr(cls, '_sms_integrated_lazy_proxy', False)):
            continue
        raw_unregister = getattr(cls, '__dict__', {}).get('unregister', None)
        replaced = False
        try:
            if raw_unregister is not None:
                cls.unregister = classmethod(lambda _cls: None)
                replaced = True
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
        finally:
            if replaced:
                try:
                    cls.unregister = raw_unregister
                except Exception:
                    pass
    _SMS_INTEGRATED_LAZY_PROXY_CLASSES.clear()
    _SMS_INTEGRATED_LAZY_PROXY_DELEGATING.clear()


_SMS_NATIVE_TOOL_STATE = {}


def _sms_init_native_tool_state():
    for meta in _sms_tool_meta_entries():
        tool_id = str(meta.get('tool_id') or '').strip()
        if not tool_id:
            continue
        _SMS_NATIVE_TOOL_STATE.setdefault(tool_id, {'status': 'available', 'error': ''})


def _sms_native_tool_state(tool_id: str):
    tool_id = str(tool_id or '').strip()
    if not tool_id:
        return {'status': 'available', 'error': ''}
    return _SMS_NATIVE_TOOL_STATE.setdefault(tool_id, {'status': 'available', 'error': ''})


def _sms_native_tool_loaded(tool_id: str) -> bool:
    return str(_sms_native_tool_state(tool_id).get('status') or '') == 'loaded'


def _sms_native_tool_error_excerpt(tool_id: str) -> str:
    # The recorded error is an internal exception text, so the user gets a plain message.
    if not str(_sms_native_tool_state(tool_id).get('error') or '').strip():
        return ''
    return _pick_lang('This tool could not be loaded. Turn the add-on off and on, then try again.', 'このツールを読み込めませんでした。アドオンを入れ直してから、もう一度試してください。')


def _sms_native_tool_meta(tool_id: str):
    tool_id = str(tool_id or '').strip()
    for meta in _SMS_NATIVE_TOOL_META:
        if str(meta.get('tool_id') or '').strip() == tool_id:
            return meta
    return None

_SMS_ON_DEMAND_LOAD_QUEUE = []
_SMS_ON_DEMAND_LOAD_PENDING = set()
_SMS_ON_DEMAND_LOAD_ACTIVE = False
_SMS_DYNAMIC_UNLOAD_GENERATION = 0
_SMS_PANEL_DRAW_DEPTH = 0
_SMS_PRELOAD_ALL_TOOLS_TIMER_ACTIVE = False
_SMS_NATIVE_KEYMAP_EAGER_LOAD_TIMER_ACTIVE = False
_SMS_NATIVE_KEYMAP_EAGER_LOAD_RESULTS = {}

_SMS_RUNTIME_TOKEN_KEY = 'SMART_MODELING_SUITE_RUNTIME_TOKEN'
_SMS_NPANEL_PREFS_SYNCED_KEY = 'SMART_MODELING_SUITE_NPANEL_PREFS_SYNCED'
_SMS_REGISTERING_NATIVE_TOOL_KEY = 'SMART_MODELING_SUITE_REGISTERING_NATIVE_TOOL'
_SMS_RUNTIME_TOKEN = None


def _sms_set_npanel_preferences_synchronized(value: bool) -> None:
    try:
        namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if isinstance(namespace, dict):
            namespace[_SMS_NPANEL_PREFS_SYNCED_KEY] = bool(value)
    except Exception:
        pass


def _sms_set_runtime_token() -> None:
    global _SMS_RUNTIME_TOKEN
    try:
        _SMS_RUNTIME_TOKEN = f"{__package__ or __name__}:{time.monotonic_ns()}:{id(object())}"
    except Exception:
        _SMS_RUNTIME_TOKEN = f"{__package__ or __name__}:{id(object())}"
    try:
        bpy.app.driver_namespace[_SMS_RUNTIME_TOKEN_KEY] = _SMS_RUNTIME_TOKEN
    except Exception:
        pass


def _sms_clear_runtime_token() -> None:
    global _SMS_RUNTIME_TOKEN
    try:
        ns = bpy.app.driver_namespace
        if ns.get(_SMS_RUNTIME_TOKEN_KEY) == _SMS_RUNTIME_TOKEN:
            ns[_SMS_RUNTIME_TOKEN_KEY] = None
    except Exception:
        pass
    _SMS_RUNTIME_TOKEN = None


def _sms_runtime_token_current() -> bool:
    try:
        if _SMS_RUNTIME_TOKEN is None:
            return False
        return bpy.app.driver_namespace.get(_SMS_RUNTIME_TOKEN_KEY) == _SMS_RUNTIME_TOKEN
    except Exception:
        return False


def _sms_runtime_active() -> bool:
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if isinstance(ns, dict) and bool(ns.get('SMART_MODELING_SUITE_SHUTTING_DOWN')):
            return False
    except Exception:
        pass
    return bool(_SMS_RUNTIME_REFRESH_ACTIVE and _sms_runtime_token_current())


def _sms_mark_native_registering(value: bool) -> None:
    try:
        bpy.app.driver_namespace[_SMS_REGISTERING_NATIVE_TOOL_KEY] = bool(value)
    except Exception:
        pass



def _sms_preload_all_tools_now(context=None) -> None:
    """Refresh startup-safe runtimes without enabling unwanted background work.

    Persistent tools are synchronized from the centralized Always-on Toggles.
    Only tools whose centralized 常時機能切り替え switch is ON keep background
    actions active. Disabled tools retain only dormant operator/RNA entry points
    and install no handlers, timers, draw handlers, or header/status hooks.
    """
    if not _sms_runtime_active():
        return
    context = context or getattr(bpy, 'context', None)
    try:
        _sms_restore_known_panel_settings(context or getattr(bpy, 'context', None))
    except Exception:
        pass
    try:
        _sms_update_persistent_tool_runtime_from_prefs(context or getattr(bpy, 'context', None))
    except Exception:
        pass
    try:
        _sms_register_lazy_keymap_proxies()
    except Exception:
        pass
    try:
        _sms_register_integrated_lazy_proxies()
    except Exception:
        pass
    # The persistent-tool synchronization above installs the established
    # Vertex Slide header toggle when its always-on switch is enabled.  Do not
    # immediately tear it down again; retain it for the enabled runtime and
    # remove it only when the feature is disabled.
    if not _sms_vertex_slide_runtime_allowed(context):
        try:
            _sms_unregister_vertex_slide_topbar_button(remove_state_props=False)
        except Exception:
            pass
    try:
        _sms_refresh_standard_n_panel_once()
    except Exception:
        pass
    try:
        _sms_tag_redraw_all_areas()
    except Exception:
        pass


def _sms_prime_click_start_native_tools(context=None) -> None:
    """Install only the zero-idle keymap entry points for click-start tools."""
    del context
    try:
        _sms_register_lazy_keymap_proxies()
    except Exception:
        pass

def _sms_eager_load_native_keymap_tools_once(context=None) -> dict:
    """Materialize every native shortcut target outside the first key event.

    The function runs only from the post-startup one-shot timer. Each module is
    registered once, then its Always-on/background hooks are returned to the
    centralized toggle state. Failed tools retain a zero-idle proxy and a bounded
    diagnostic so a shortcut is never silently consumed.
    """
    context = context or getattr(bpy, 'context', None)
    results = {}
    for tool_id in tuple(_SMS_NATIVE_KEYMAP_INFO.keys()):
        tool_id = str(tool_id or '').strip()
        if not tool_id:
            continue
        try:
            loaded = bool(_sms_ensure_native_tool_loaded(tool_id, context=context))
        except Exception as exc:
            _sms_record_native_keymap_failure(tool_id, exc)
            loaded = False
        if loaded:
            try:
                meta = _sms_native_tool_meta(tool_id) or {}
                if not (_sms_native_tool_has_persistent_load(tool_id) and _sms_native_tool_enabled(context, meta)):
                    _sms_seed_runtime_feature_state(tool_id, False)
                    _sms_set_integrated_runtime_features(tool_id, False)
                    _sms_deactivate_known_native_background_hooks(tool_id)
            except Exception:
                pass
        else:
            try:
                _sms_register_lazy_keymap_proxies((tool_id,))
            except Exception:
                pass
        results[tool_id] = {
            'loaded': loaded,
            'error': _sms_native_tool_error_excerpt(tool_id),
        }
    _SMS_NATIVE_KEYMAP_EAGER_LOAD_RESULTS.clear()
    _SMS_NATIVE_KEYMAP_EAGER_LOAD_RESULTS.update(results)
    return results


def _sms_native_keymap_eager_load_timer():
    global _SMS_NATIVE_KEYMAP_EAGER_LOAD_TIMER_ACTIVE
    _SMS_NATIVE_KEYMAP_EAGER_LOAD_TIMER_ACTIVE = False
    if not _sms_runtime_active():
        return None
    context = getattr(bpy, 'context', None)
    prefs_synchronized = False
    try:
        prefs = _sms_get_suite_prefs(context)
        if prefs is not None:
            _sms_restore_suite_panel_settings(context, prefs)
            _sms_sync_persistent_toggle_snapshot_to_prefs(context=context, prefs=prefs)
            prefs_synchronized = True
    except Exception:
        prefs_synchronized = False
    _sms_set_npanel_preferences_synchronized(prefs_synchronized)
    _sms_eager_load_native_keymap_tools_once(context)
    return None


def _sms_schedule_native_keymap_eager_load(first_interval=None) -> None:
    global _SMS_NATIVE_KEYMAP_EAGER_LOAD_TIMER_ACTIVE
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    if timers is None:
        return
    try:
        if hasattr(timers, 'is_registered') and timers.is_registered(_sms_native_keymap_eager_load_timer):
            timers.unregister(_sms_native_keymap_eager_load_timer)
    except Exception:
        pass
    if first_interval is None:
        try:
            first_interval = max(0.05, float(_SMS_RNA_UNSAFE_UNTIL) - time.monotonic() + 0.05)
        except Exception:
            first_interval = 0.25
    try:
        timers.register(_sms_native_keymap_eager_load_timer, first_interval=max(0.0, float(first_interval)))
        _SMS_NATIVE_KEYMAP_EAGER_LOAD_TIMER_ACTIVE = True
    except Exception:
        _SMS_NATIVE_KEYMAP_EAGER_LOAD_TIMER_ACTIVE = False


def _sms_cancel_native_keymap_eager_load_timer() -> None:
    global _SMS_NATIVE_KEYMAP_EAGER_LOAD_TIMER_ACTIVE
    _SMS_NATIVE_KEYMAP_EAGER_LOAD_TIMER_ACTIVE = False
    _SMS_NATIVE_KEYMAP_EAGER_LOAD_RESULTS.clear()
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_sms_native_keymap_eager_load_timer):
            timers.unregister(_sms_native_keymap_eager_load_timer)
    except Exception:
        pass


def _sms_preload_all_tools_timer():
    global _SMS_PRELOAD_ALL_TOOLS_TIMER_ACTIVE
    _SMS_PRELOAD_ALL_TOOLS_TIMER_ACTIVE = False
    return None


def _sms_schedule_preload_all_tools(first_interval: float = 0.15) -> None:
    global _SMS_PRELOAD_ALL_TOOLS_TIMER_ACTIVE
    _SMS_PRELOAD_ALL_TOOLS_TIMER_ACTIVE = False
    return None

def _sms_cancel_preload_all_tools_timer() -> None:
    global _SMS_PRELOAD_ALL_TOOLS_TIMER_ACTIVE
    _SMS_PRELOAD_ALL_TOOLS_TIMER_ACTIVE = False
    try:
        if bpy.app.timers.is_registered(_sms_preload_all_tools_timer):
            bpy.app.timers.unregister(_sms_preload_all_tools_timer)
    except Exception:
        pass


def _sms_enter_panel_draw() -> None:
    global _SMS_PANEL_DRAW_DEPTH
    _SMS_PANEL_DRAW_DEPTH += 1


def _sms_exit_panel_draw() -> None:
    global _SMS_PANEL_DRAW_DEPTH
    _SMS_PANEL_DRAW_DEPTH = max(0, _SMS_PANEL_DRAW_DEPTH - 1)


def _sms_is_panel_draw_active() -> bool:
    return _SMS_PANEL_DRAW_DEPTH > 0


def _sms_on_demand_load_pending(kind: str, alias: str) -> bool:
    key = (str(kind or '').strip(), str(alias or '').strip())
    return key in _SMS_ON_DEMAND_LOAD_PENDING



def _sms_tag_redraw_all_areas(*, force: bool = False) -> None:
    global _SMS_LAST_ALL_AREA_REDRAW_TAG
    try:
        if _sms_rna_access_is_unsafe():
            return
    except Exception:
        return
    try:
        now = time.monotonic()
    except Exception:
        now = 0.0
    if not force and now and (now - _SMS_LAST_ALL_AREA_REDRAW_TAG) < _SMS_ALL_AREA_REDRAW_THROTTLE_SECONDS:
        return
    _SMS_LAST_ALL_AREA_REDRAW_TAG = now
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        windows = getattr(wm, 'windows', None) if wm is not None else None
        if not windows:
            return
        for window in windows:
            screen = getattr(window, 'screen', None)
            if screen is None:
                continue
            for area in getattr(screen, 'areas', ()):  # pragma: no branch
                try:
                    area_type = str(getattr(area, 'type', '') or '').upper()
                    if area_type == 'VIEW_3D' or area_type in _SMS_NPANEL_ALLOWED_AREA_TYPES:
                        area.tag_redraw()
                except Exception:
                    pass
    except Exception:
        pass



def _sms_on_demand_integrated_enabled(alias: str, context=None) -> bool:
    return _sms_integrated_enabled_from_prefs(context, alias, False)

def _sms_ensure_integrated_tool_loaded(alias: str, context=None) -> bool:
    alias = str(alias or '').strip()
    if not alias:
        return False
    try:
        from . import loader as _sms_loader
    except Exception:
        return False

    try:
        records = list(_sms_loader.get_records() or [])
    except Exception:
        records = []
    if not records:
        try:
            _sms_loader.register_all()
        except Exception:
            pass

    try:
        record = _sms_loader.get_record(alias) or {}
    except Exception:
        record = {}
    status = str(record.get('status') or 'available').strip().lower()
    if status == 'loaded':
        # A full Suite disable removes every RNA root.  Some integrated tools
        # keep their Python loader record alive until the next registration
        # pass, so a stale ``loaded`` record must not suppress reconstruction
        # of its native settings owner.  Polycount is the only UI-lazy runtime
        # owner in this tool and provides a cheap, authoritative integrity
        # check for the whole Key Operation Tools registration.
        keyops_incomplete = (
            alias == 'key_operators_toolkit'
            and not hasattr(bpy.types.Scene, 'polycount_props')
        )
        if not keyops_incomplete:
            return True
        try:
            _sms_loader.unload(alias)
            record = _sms_loader.get_record(alias) or {}
            status = str(record.get('status') or 'available').strip().lower()
        except Exception:
            return False
    if status in {'disabled', 'unsupported_platform'}:
        return False

    try:
        if _sms_integrated_tool_has_persistent_load(alias):
            _sms_seed_runtime_feature_state(alias, _sms_integrated_enabled_from_prefs(context, alias, False))
    except Exception:
        pass
    try:
        record = _sms_loader.ensure_loaded(alias) or {}
    except Exception:
        record = {}

    # Do not register migrated proxy panels here. The standard N-panel draws
    # integrated records inline, and dynamic child panel registration during or
    # immediately after sidebar layout is a known crash vector in Blender 5.x.
    try:
        from . import ui_runtime as _sms_ui_runtime
        _sms_ui_runtime._collect_records()
    except Exception:
        pass

    try:
        _sms_prepare_properties_panels()
    except Exception:
        pass
    loaded = str(record.get('status') or '').strip().lower() == 'loaded'
    if loaded:
        try:
            _sms_restore_known_panel_settings(context or bpy.context)
        except Exception:
            pass
        try:
            from . import common as _sms_common
            _sms_common.restore_dynamic_persistent_settings(context or bpy.context)
        except Exception:
            pass
    if loaded and _sms_integrated_tool_has_persistent_load(alias):
        try:
            _sms_set_integrated_runtime_features(alias, _sms_integrated_enabled_from_prefs(context, alias, False))
        except Exception:
            pass
    if loaded:
        try:
            _sms_refresh_canonical_translations()
        except Exception:
            pass
    _sms_tag_redraw_all_areas()
    return loaded



def _sms_enqueue_on_demand_load(kind: str, alias: str, context=None, *, delay: float = 0.01) -> bool:
    """Queue a tool load so Panel.draw never registers classes directly."""
    global _SMS_ON_DEMAND_LOAD_ACTIVE
    if not _sms_runtime_active():
        return False
    kind = str(kind or '').strip()
    alias = str(alias or '').strip()
    if not kind or not alias:
        return False
    status = _sms_load_status_for_item(kind, alias)
    if status in {'loaded', 'loading', 'failed', 'disabled', 'unsupported_platform'}:
        return status == 'loaded'
    key = (kind, alias)
    if key not in _SMS_ON_DEMAND_LOAD_PENDING:
        _SMS_ON_DEMAND_LOAD_PENDING.add(key)
        _SMS_ON_DEMAND_LOAD_QUEUE.append(key)
    if not _SMS_ON_DEMAND_LOAD_ACTIVE:
        _SMS_ON_DEMAND_LOAD_ACTIVE = True
        try:
            timers = getattr(getattr(bpy, 'app', None), 'timers', None)
            if timers is not None:
                is_registered = getattr(timers, 'is_registered', None)
                if not callable(is_registered) or not is_registered(_sms_process_on_demand_load_queue):
                    timers.register(_sms_process_on_demand_load_queue, first_interval=max(float(delay), 0.01))
        except Exception:
            try:
                _SMS_ON_DEMAND_LOAD_ACTIVE = False
                _SMS_ON_DEMAND_LOAD_PENDING.discard(key)
                if key in _SMS_ON_DEMAND_LOAD_QUEUE:
                    _SMS_ON_DEMAND_LOAD_QUEUE.remove(key)
            except Exception:
                pass
            return False
    return True


def _sms_process_on_demand_load_queue():
    global _SMS_ON_DEMAND_LOAD_ACTIVE
    if not _sms_runtime_active():
        _SMS_ON_DEMAND_LOAD_QUEUE.clear()
        _SMS_ON_DEMAND_LOAD_PENDING.clear()
        _SMS_ON_DEMAND_LOAD_ACTIVE = False
        return None
    if not _SMS_ON_DEMAND_LOAD_QUEUE:
        _SMS_ON_DEMAND_LOAD_ACTIVE = False
        return None

    kind, alias = _SMS_ON_DEMAND_LOAD_QUEUE.pop(0)
    _SMS_ON_DEMAND_LOAD_PENDING.discard((kind, alias))
    context = getattr(bpy, 'context', None)
    try:
        if kind == 'native':
            meta = _sms_native_tool_meta(alias)
            if isinstance(meta, dict):
                _sms_ensure_native_tool_loaded(alias, context=context)
        elif kind == 'integrated':
            _sms_ensure_integrated_tool_loaded(alias, context=context)
    except Exception:
        pass

    try:
        _sms_tag_redraw_view3d_areas(force=True, all_supported_editors=True)
    except Exception:
        pass
    if _SMS_ON_DEMAND_LOAD_QUEUE:
        return 0.05
    _SMS_ON_DEMAND_LOAD_ACTIVE = False
    # The queued tool's RNA now exists.  Complete persistence materialization
    # and zero-idle cleanup synchronously at this exact boundary so no second
    # timer can outlive the lazy-load queue.
    try:
        _sms_finalize_lazy_settings_timer()
    except Exception:
        pass
    return None



def _sms_request_on_demand_load(kind: str, alias: str, context=None) -> bool:
    if not _sms_runtime_active():
        return False
    kind = str(kind or '').strip()
    alias = str(alias or '').strip()
    if not kind or not alias:
        return False
    if _sms_is_panel_draw_active() or _sms_toggle_update_active() or _sms_runtime_sync_active():
        return _sms_enqueue_on_demand_load(kind, alias, context=context)
    try:
        if kind == 'native':
            meta = _sms_native_tool_meta(alias)
            if not isinstance(meta, dict):
                return False
            status = str(_sms_native_tool_state(alias).get('status') or 'available').strip().lower()
            if status in {'loaded', 'loading', 'failed'}:
                return False
            return bool(_sms_ensure_native_tool_loaded(alias, context=context))
        if kind == 'integrated':
            return bool(_sms_ensure_integrated_tool_loaded(alias, context=context))
    except Exception:
        return False
    return False



def _sms_cancel_on_demand_loads() -> None:
    global _SMS_ON_DEMAND_LOAD_ACTIVE
    _SMS_ON_DEMAND_LOAD_QUEUE.clear()
    _SMS_ON_DEMAND_LOAD_PENDING.clear()
    _SMS_ON_DEMAND_LOAD_ACTIVE = False
    try:
        if bpy.app.timers.is_registered(_sms_process_on_demand_load_queue):
            bpy.app.timers.unregister(_sms_process_on_demand_load_queue)
    except Exception:
        pass



def _sms_cancel_pending_tool_load(kind: str, alias: str) -> None:
    """Remove queued lazy loads for a tool before disabling it.

    A disabled section can be closed while a Panel.draw-triggered load is still
    pending.  Leaving that queued work alive would reload the tool immediately
    after the user closed or disabled it, which violates the zero-background
    runtime contract and can reintroduce stale UI/operator callbacks.
    """
    global _SMS_ON_DEMAND_LOAD_ACTIVE
    key = (str(kind or '').strip(), str(alias or '').strip())
    if not key[0] or not key[1]:
        return
    try:
        _SMS_ON_DEMAND_LOAD_PENDING.discard(key)
    except Exception:
        pass
    try:
        _SMS_ON_DEMAND_LOAD_QUEUE[:] = [item for item in _SMS_ON_DEMAND_LOAD_QUEUE if item != key]
    except Exception:
        pass
    try:
        if not _SMS_ON_DEMAND_LOAD_QUEUE:
            _SMS_ON_DEMAND_LOAD_ACTIVE = False
            timers = getattr(getattr(bpy, 'app', None), 'timers', None)
            is_registered = getattr(timers, 'is_registered', None) if timers is not None else None
            unregister = getattr(timers, 'unregister', None) if timers is not None else None
            if callable(is_registered) and callable(unregister) and is_registered(_sms_process_on_demand_load_queue):
                unregister(_sms_process_on_demand_load_queue)
    except Exception:
        pass




def _sms_load_status_for_item(kind: str, alias: str) -> str:
    kind = str(kind or '').strip()
    alias = str(alias or '').strip()
    if not alias:
        return ''
    if kind == 'native':
        try:
            return str(_sms_native_tool_state(alias).get('status') or 'available').strip().lower()
        except Exception:
            return 'available'
    if kind == 'integrated':
        try:
            _sms_loader = sys.modules.get(f'{__package__}.loader')
            if _sms_loader is None:
                return 'available'
            record = _sms_loader.get_record(alias) or {}
            return str(record.get('status') or 'available').strip().lower()
        except Exception:
            return 'available'
    return ''


_SMS_HOSTED_NATIVE_NPANEL_IDS = frozenset((
    'VIEW3D_PT_sketch_tools',
    'VIEW3D_PT_quad_strip_draw_final',
    'VIEW3D_PT_sms_quad_strip_draw',
))


def _sms_is_hosted_native_npanel_identifier(identifier: str) -> bool:
    identifier = str(identifier or '').strip()
    return bool(identifier and identifier in _SMS_HOSTED_NATIVE_NPANEL_IDS)


def _sms_is_hosted_native_npanel_class(cls) -> bool:
    if cls is None or not isinstance(cls, type):
        return False
    try:
        panel_base = getattr(bpy.types, 'Panel', None)
        if panel_base is None or not issubclass(cls, panel_base):
            return False
    except Exception:
        return False
    identifiers = set()
    try:
        identifiers.add(str(getattr(cls, '__name__', '') or '').strip())
    except Exception:
        pass
    try:
        identifiers.add(str(getattr(cls, 'bl_idname', '') or '').strip())
    except Exception:
        pass
    try:
        identifiers.add(str(getattr(cls, 'bl_parent_id', '') or '').strip())
    except Exception:
        pass
    return any(_sms_is_hosted_native_npanel_identifier(value) for value in identifiers if value)


def _sms_lookup_registered_panel(identifier: str):
    identifier = str(identifier or '').strip()
    if not identifier:
        return None
    try:
        cls = getattr(bpy.types, identifier, None)
        if isinstance(cls, type):
            return cls
    except Exception:
        pass
    try:
        panel_base = getattr(bpy.types, 'Panel', None)
        getter = getattr(panel_base, 'bl_rna_get_subclass_py', None) if panel_base is not None else None
        if callable(getter):
            cls = getter(identifier, None)
            if isinstance(cls, type):
                return cls
    except Exception:
        pass
    return None


def _sms_purge_hosted_native_npanel(identifier_or_cls=None) -> int:
    if _sms_install_safe_phase_active():
        return 0
    if isinstance(identifier_or_cls, type):
        return 1 if _sms_disable_exact_owned_panel_class(identifier_or_cls) else 0
    return _sms_cleanup_stale_owned_classes(panels_only=True)


def _sms_call_native_register(register_fn):
    if not callable(register_fn):
        return
    original_register_class = getattr(bpy.utils, 'register_class', None)
    original_unregister_class = getattr(bpy.utils, 'unregister_class', None)

    def _wrapped_register_class(cls):
        try:
            _language.sanitize_class_ui(cls)
        except Exception:
            pass
        try:
            _sms_force_operator_undo_class(cls)
        except Exception:
            pass
        try:
            cls_idname = str(getattr(cls, 'bl_idname', '') or '').strip()
            operator_base = getattr(bpy.types, 'Operator', None)
            if (
                cls_idname
                and cls_idname in _SMS_LAZY_KEYMAP_DECLARED_IDNAMES
                and isinstance(operator_base, type)
                and isinstance(cls, type)
                and issubclass(cls, operator_base)
                and _sms_exact_class_belongs_to_current_package(cls)
            ):
                _SMS_LAZY_KEYMAP_SOURCE_CLASSES[cls_idname] = cls
        except Exception:
            pass
        _sms_disable_panel_draw_header_before_register(cls)
        try:
            _sms_harden_panel_class_before_register(cls)
        except Exception:
            pass
        preserve_proxy = False
        try:
            cls_idname = str(getattr(cls, 'bl_idname', '') or '')
            preserve_proxy = bool(cls_idname and cls_idname in _SMS_LAZY_KEYMAP_PRESERVE_IDNAMES)
            if cls_idname and not preserve_proxy:
                _sms_unregister_lazy_keymap_proxy_idname(cls_idname)
        except Exception:
            cls_idname = ''
            preserve_proxy = False
        if _sms_is_hosted_native_npanel_class(cls) or _sms_should_skip_panel_registration(cls):
            try:
                _sms_suppress_sidebar_panel_class(cls)
            except Exception:
                pass
            try:
                _sms_purge_hosted_native_npanel(cls)
            except Exception:
                pass
            return None
        if _sms_shared_pref_class_registered(cls):
            return None
        try:
            existing = _sms_registered_rna_class(cls)
            if preserve_proxy and isinstance(existing, type) and _sms_is_lazy_proxy_class(existing):
                try:
                    existing_idname = str(getattr(existing, 'bl_idname', '') or '')
                except Exception:
                    existing_idname = ''
                if existing_idname == cls_idname:
                    # Preserve Blender's currently executing wmOperator/RNA owner,
                    # but install the real Python implementation on that same live
                    # class before the popup starts.  Without this in-place patch,
                    # the first lazy invocation keeps the shell's invoke/execute
                    # methods but has no real draw() implementation, producing an
                    # empty or malformed popup.
                    _sms_patch_registered_class_in_place(existing, cls)
                    return None
            if isinstance(existing, type) and existing is not cls:
                _sms_patch_registered_class_in_place(existing, cls)
                return None
        except Exception:
            pass
        try:
            return original_register_class(cls)
        except ValueError:
            try:
                existing = _sms_registered_rna_class(cls)
                if isinstance(existing, type):
                    _sms_patch_registered_class_in_place(existing, cls)
            except Exception:
                pass
            return None
        except Exception:
            return None

    def _wrapped_unregister_class(cls):
        # Native modules from older standalone builds often start register() by
        # unregistering their legacy panels.  In an integrated suite those panels
        # are hosted as plain Python draw classes and must not be removed/re-added
        # at RNA level.  Besides destabilizing open Blender 5.1 panels, that churn
        # also makes external panel managers rebuild their generated ``stm_anchor``
        # panels and emit duplicate-registration messages.
        try:
            if _sms_panel_class_is_panel(cls):
                _sms_disable_resident_panel_class(cls)
                return None
        except Exception:
            pass
        # Never unregister a lazy proxy (especially the proxy currently running)
        # from inside its delegated tool's register() call.  Blender keeps a native
        # wmOperator pointer to the registered RNA type until invoke/execute
        # returns; unregistering that class mid-call leaves a dangling pointer and
        # can crash in wm_operator_reports/operator-history finalization.
        try:
            cls_idname = str(getattr(cls, 'bl_idname', '') or '').strip()
            if _sms_is_lazy_proxy_class(cls):
                return None
            if cls_idname and (
                cls_idname in _SMS_LAZY_KEYMAP_PRESERVE_IDNAMES
                or cls_idname in _SMS_LAZY_KEYMAP_DELEGATING
            ):
                return None
        except Exception:
            pass
        if callable(original_unregister_class):
            try:
                return original_unregister_class(cls)
            except Exception:
                return None
        return None

    if callable(original_register_class):
        try:
            bpy.utils.register_class = _wrapped_register_class
        except Exception:
            original_register_class = None
    if callable(original_unregister_class):
        try:
            bpy.utils.unregister_class = _wrapped_unregister_class
        except Exception:
            original_unregister_class = None
    try:
        # Property factories are wrapped only for the duration of the tool's
        # register() call. This keeps class/property names and tooltips
        # language-safe without leaving global UI monkey patches active during
        # N-panel drawing.
        _sms_mark_native_registering(True)
        try:
            _language.install_property_wrappers()
        except Exception:
            pass
        try:
            register_fn()
        finally:
            try:
                _language._restore_property_wrappers()
            except Exception:
                pass
            _sms_mark_native_registering(False)
    finally:
        if callable(original_register_class):
            try:
                bpy.utils.register_class = original_register_class
            except Exception:
                pass
        if callable(original_unregister_class):
            try:
                bpy.utils.unregister_class = original_unregister_class
            except Exception:
                pass


def _sms_purge_native_tool_module_cache(meta):
    if not isinstance(meta, dict):
        return
    module_path = str(meta.get('module_path') or '').strip().lstrip('.')
    if not module_path:
        return
    try:
        for idname in _sms_keymap_idnames_for_native_tool(str(meta.get('tool_id') or '').strip()):
            _SMS_LAZY_KEYMAP_SOURCE_CLASSES.pop(idname, None)
    except Exception:
        pass
    try:
        _SMS_NATIVE_MODULE_CACHE.pop(module_path, None)
    except Exception:
        pass
    package = str(__package__ or '').strip()
    prefixes = []
    if package:
        prefixes.append(f'{package}.{module_path}')
    prefixes.append(module_path)
    for name in list(sys.modules.keys()):
        sname = str(name or '')
        if any(sname == prefix or sname.startswith(prefix + '.') for prefix in prefixes):
            try:
                sys.modules.pop(name, None)
            except Exception:
                pass
    try:
        meta['module'] = None
    except Exception:
        pass


def _sms_ensure_native_tool_loaded(tool_id: str, context=None) -> bool:
    meta = _sms_native_tool_meta(tool_id)
    if not isinstance(meta, dict):
        return False
    state = _sms_native_tool_state(tool_id)
    current_status = str(state.get('status') or '')
    if current_status == 'loading':
        return True
    if current_status == 'loaded':
        if str(tool_id or '').strip() in {'sketch_tools', 'quad_strip_draw'}:
            try:
                _sms_purge_hosted_native_npanel()
            except Exception:
                pass
        return True

    try:
        _sms_unregister_lazy_keymap_proxies_for_tool(tool_id)
    except Exception:
        pass

    module = _sms_native_module_from_meta(meta)
    try:
        _language.sanitize_module_ui(module)
    except Exception:
        pass
    if module is None:
        state['status'] = 'failed'
        module_name = str(meta.get('module_path') or meta.get('module') or tool_id or 'unknown')
        state['error'] = f'Missing module for {module_name}'
        return False

    state['status'] = 'loading'
    state['error'] = ''
    try:
        register_fn = getattr(module, 'register', None)
        if callable(register_fn):
            # Register operator/UI classes for both persistent and click-start native
            # tools, but capture any handlers, timers, keymaps, msgbus hooks, or
            # draw handlers they try to install. Persistent tools activate those
            # captured background actions only when the centralized toggle is ON;
            # click-start tools keep them disabled so startup remains light while
            # their command operators are reliably available after Blender starts.
            if _sms_native_tool_has_persistent_load(tool_id):
                try:
                    _sms_seed_runtime_feature_state(tool_id, _sms_native_tool_enabled(context, meta))
                except Exception:
                    pass
            else:
                try:
                    _sms_seed_runtime_feature_state(tool_id, False)
                except Exception:
                    pass
            try:
                from . import feature_toggle as _sms_feature_runtime
            except Exception:
                _sms_feature_runtime = None
            label = str(meta.get('label') or tool_id or 'Native Tool')
            if _sms_feature_runtime is not None:
                with _sms_feature_runtime.capture_runtime(tool_id, label):
                    _sms_call_native_register(register_fn)
                if not _sms_native_tool_has_persistent_load(tool_id):
                    try:
                        _sms_feature_runtime.deactivate_alias(tool_id)
                    except Exception:
                        pass
            else:
                _sms_call_native_register(register_fn)
        state['status'] = 'loaded'
        state['error'] = ''
        if _sms_native_tool_has_persistent_load(tool_id):
            try:
                _sms_set_integrated_runtime_features(tool_id, _sms_native_tool_enabled(context, meta))
            except Exception:
                pass
        try:
            if not (_sms_native_tool_has_persistent_load(tool_id) and _sms_native_tool_enabled(context, meta)):
                _sms_deactivate_known_native_background_hooks(tool_id)
        except Exception:
            pass
    except Exception:
        state['status'] = 'failed'
        state['error'] = traceback.format_exc().strip()
        try:
            unregister_fn = getattr(module, 'unregister', None)
            if callable(unregister_fn):
                _sms_call_with_panel_unregister_guard(unregister_fn)
        except Exception:
            pass
        # Shared preference/property classes used by the suite must remain live
        # even if an on-demand tool fails during registration.
        for cls in _SMS_SHARED_PREF_CLASSES:
            try:
                _safe_register_class(cls)
            except Exception:
                pass
        try:
            _sms_rebuild_native_tool_records()
        except Exception:
            pass
        try:
            _sms_purge_native_tool_module_cache(meta)
        except Exception:
            pass
        try:
            _sms_unregister_lazy_keymap_proxies_for_tool(tool_id)
        except Exception:
            pass
        return False

    try:
        _sms_rescue_native_ui_classes(tool_ids=(tool_id,))
    except Exception:
        pass
    try:
        _sms_purge_hosted_native_npanel()
    except Exception:
        pass
    try:
        _sms_purge_obsolete_standard_child_panels()
    except Exception:
        pass
    try:
        _sms_purge_non_root_smart_modeling_panels()
    except Exception:
        pass
    try:
        _sms_rebuild_native_tool_records()
    except Exception:
        pass
    try:
        _sms_restore_known_panel_settings(context or bpy.context)
    except Exception:
        pass
    try:
        from . import common as _sms_common
        _sms_common.restore_dynamic_persistent_settings(context or bpy.context)
    except Exception:
        pass
    try:
        _sms_wrap_legacy_panel_polls()
    except Exception:
        pass
    try:
        _sms_prepare_properties_panels()
    except Exception:
        pass
    try:
        _sms_refresh_standard_n_panel_once()
    except Exception:
        pass
    try:
        _refresh_keymaps(context or bpy.context)
    except Exception:
        pass
    try:
        _sms_refresh_canonical_translations()
    except Exception:
        pass
    try:
        _sms_tag_redraw_view3d_areas(force=True, all_supported_editors=True)
    except Exception:
        pass
    return True


def _sms_native_tool_sync_runtime(context=None):
    try:
        _sms_rebuild_native_tool_records()
    except Exception:
        pass
    try:
        _sms_wrap_legacy_panel_polls()
    except Exception:
        pass
    try:
        _sms_prepare_properties_panels()
    except Exception:
        pass
    try:
        _sms_refresh_standard_n_panel_once()
    except Exception:
        pass
    try:
        if _sms_has_live_smart_tools_hosts():
            _sms_schedule_standard_n_panel_refresh()
    except Exception:
        pass
    try:
        _refresh_keymaps(context or bpy.context)
    except Exception:
        pass
    try:
        _sms_tag_redraw_view3d_areas(force=True, all_supported_editors=True)
    except Exception:
        pass


def _sms_unload_native_tool(tool_id: str, context=None, *, keep_registered_safe: bool = False) -> bool:
    meta = _sms_native_tool_meta(tool_id)
    if not isinstance(meta, dict):
        return False
    state = _sms_native_tool_state(tool_id)
    if str(state.get('status') or '') != 'loaded':
        state['status'] = 'available'
        state['error'] = ''
        try:
            _sms_purge_native_tool_module_cache(meta)
        except Exception:
            pass
        # If the native module is not loaded there is nothing to deactivate.
        # Keep only its zero-idle keymap entry points so a registered shortcut
        # can load the real tool on first use.
        try:
            _sms_register_lazy_keymap_proxies((tool_id,))
        except Exception:
            pass
        return True
    module = _sms_native_module_from_meta(meta, require_loaded=False)
    if keep_registered_safe or str(tool_id or '').strip() in {'direct_delete', 'vertex_slide'}:
        # Avoid unregistering operator/property classes that Blender UI or the
        # operator system may still reference.  All persistent runtime work is
        # removed above by _sms_deactivate_tool_runtime / known-hook cleanup.
        try:
            _sms_set_integrated_runtime_features(tool_id, False)
        except Exception:
            pass
        try:
            _sms_deactivate_known_native_background_hooks(tool_id)
        except Exception:
            pass
        try:
            _sms_unregister_lazy_keymap_proxies_for_tool(tool_id)
        except Exception:
            pass
        state['status'] = 'loaded'
        state['error'] = ''
        return True
    try:
        unregister_fn = getattr(module, 'unregister', None) if module is not None else None
        if callable(unregister_fn):
            _sms_call_with_panel_unregister_guard(unregister_fn)
    except Exception:
        state['status'] = 'failed'
        state['error'] = traceback.format_exc().strip()
        _sms_native_tool_sync_runtime(context)
        return False
    for cls in _SMS_SHARED_PREF_CLASSES:
        try:
            _safe_register_class(cls)
        except Exception:
            pass
    state['status'] = 'available'
    state['error'] = ''
    try:
        _sms_purge_native_tool_module_cache(meta)
    except Exception:
        pass
    try:
        _sms_clear_recovered_native_ui_classes()
    except Exception:
        pass
    remaining = [
        str(meta_entry.get('tool_id') or '').strip()
        for meta_entry in _sms_tool_meta_entries()
        if str(meta_entry.get('tool_id') or '').strip() != str(tool_id or '').strip() and _sms_native_tool_loaded(str(meta_entry.get('tool_id') or '').strip())
    ]
    if remaining:
        try:
            _sms_rescue_native_ui_classes(tool_ids=tuple(remaining))
        except Exception:
            pass
    _sms_native_tool_sync_runtime(context)
    try:
        _sms_register_lazy_keymap_proxies((tool_id,))
    except Exception:
        pass
    return True


def _sms_tool_meta_entries():
    return tuple(_SMS_NATIVE_TOOL_META)


def _sms_iter_tool_module_tree(root_module):
    if root_module is None:
        return []
    root_name = str(getattr(root_module, '__name__', '') or '').strip()
    if not root_name:
        return []
    seen = set()
    stack = [root_module]
    modules = []
    while stack:
        mod = stack.pop()
        if mod is None:
            continue
        mod_id = id(mod)
        if mod_id in seen:
            continue
        seen.add(mod_id)
        modules.append(mod)
        for value in getattr(mod, '__dict__', {}).values():
            if not isinstance(value, types.ModuleType):
                continue
            child_name = str(getattr(value, '__name__', '') or '').strip()
            if not child_name:
                continue
            if child_name == root_name or child_name.startswith(root_name + '.'):
                stack.append(value)
    return modules


def _sms_class_registered(cls):
    if cls is None or not isinstance(cls, type):
        return False
    try:
        existing = getattr(bpy.types, getattr(cls, '__name__', ''), None)
        if existing is cls:
            try:
                getattr(cls, 'bl_rna')
                return True
            except Exception:
                return False
    except Exception:
        pass
    bl_idname = str(getattr(cls, 'bl_idname', '') or '').strip()
    if not bl_idname:
        return False
    for base_name in ('Operator', 'Menu', 'Panel', 'PropertyGroup'):
        try:
            base = getattr(bpy.types, base_name, None)
            getter = getattr(base, 'bl_rna_get_subclass_py', None) if base is not None else None
            if callable(getter) and getter(bl_idname, None) is cls:
                return True
        except Exception:
            continue
    return False


def _sms_collect_public_ui_classes(root_module):
    panel_base = getattr(bpy.types, 'Panel', None)
    operator_base = getattr(bpy.types, 'Operator', None)
    menu_base = getattr(bpy.types, 'Menu', None)
    panels = []
    operators = []
    menus = []
    seen = set()
    root_name = str(getattr(root_module, '__name__', '') or '').strip()
    for module in _sms_iter_tool_module_tree(root_module):
        for value in getattr(module, '__dict__', {}).values():
            if not isinstance(value, type):
                continue
            if value in seen:
                continue
            seen.add(value)
            class_name = str(getattr(value, '__name__', '') or '').strip()
            class_module = str(getattr(value, '__module__', '') or '').strip()
            if not class_name or class_name.startswith('_'):
                continue
            if root_name and not (class_module == root_name or class_module.startswith(root_name + '.')):
                continue
            try:
                if panel_base is not None and issubclass(value, panel_base):
                    if not bool(getattr(value, '_smart_suite_host_panel', False)) and not _sms_is_hosted_native_npanel_class(value):
                        panels.append(value)
                    continue
            except Exception:
                pass
            try:
                if operator_base is not None and issubclass(value, operator_base):
                    if str(getattr(value, 'bl_idname', '') or '').strip():
                        operators.append(value)
                    continue
            except Exception:
                pass
            try:
                if menu_base is not None and issubclass(value, menu_base):
                    if str(getattr(value, 'bl_idname', '') or '').strip():
                        menus.append(value)
                    continue
            except Exception:
                pass
    panels.sort(key=lambda cls: str(getattr(cls, 'bl_label', '') or getattr(cls, '__name__', '') or '').lower())
    operators.sort(key=lambda cls: (str(getattr(cls, 'bl_label', '') or getattr(cls, '__name__', '') or '').lower(), str(getattr(cls, 'bl_idname', '') or '').lower()))
    menus.sort(key=lambda cls: (str(getattr(cls, 'bl_label', '') or getattr(cls, '__name__', '') or '').lower(), str(getattr(cls, 'bl_idname', '') or '').lower()))
    return panels, operators, menus


def _sms_try_rescue_native_class(cls):
    if cls is None or not isinstance(cls, type):
        return False
    if _sms_is_hosted_native_npanel_class(cls):
        try:
            _sms_purge_hosted_native_npanel(cls)
        except Exception:
            pass
        return False
    try:
        panel_base = getattr(bpy.types, 'Panel', None)
        if panel_base is not None and issubclass(cls, panel_base):
            # Native tool panels are drawn inside VIEW3D_PT_sms_hub from their
            # Python draw methods.  Registering them as standalone RNA panels is
            # both unnecessary and contrary to the single-N-panel architecture.
            # It also causes panel-order manager add-ons to regenerate their
            # anchor panels every time a tool is loaded.
            _sms_suppress_sidebar_panel_class(cls)
            return False
    except Exception:
        pass
    already_registered = _sms_class_registered(cls)
    if already_registered:
        return True
    try:
        existing = _sms_registered_rna_class(cls)
        if isinstance(existing, type) and existing is not cls:
            _sms_patch_registered_class_in_place(existing, cls)
            return True
    except Exception:
        pass
    try:
        panel_base = getattr(bpy.types, 'Panel', None)
        if panel_base is not None and issubclass(cls, panel_base):
            _sms_wrap_panel_poll(cls)
    except Exception:
        pass
    try:
        bpy.utils.register_class(cls)
    except ValueError:
        try:
            existing = _sms_registered_rna_class(cls)
            if isinstance(existing, type):
                _sms_patch_registered_class_in_place(existing, cls)
                return True
        except Exception:
            pass
    except Exception:
        return False
    return _sms_class_registered(cls)


def _sms_rescue_native_ui_classes(tool_ids=None):
    requested = {str(item or '').strip() for item in tuple(tool_ids or ()) if str(item or '').strip()} if tool_ids else None
    recovered = list(_SMS_NATIVE_RECOVERED_CLASSES)
    seen = set(recovered)
    claimed_idnames = {
        str(getattr(cls, 'bl_idname', '') or '').strip()
        for cls in recovered
        if str(getattr(cls, 'bl_idname', '') or '').strip()
    }
    for meta in _sms_tool_meta_entries():
        tool_id = str(meta.get('tool_id') or '').strip()
        if requested is not None and tool_id not in requested:
            continue
        if not _sms_native_tool_loaded(tool_id):
            continue
        module = _sms_native_module_from_meta(meta, require_loaded=True)
        panels, operators, menus = _sms_collect_public_ui_classes(module)
        candidates = list(operators) + list(menus) + list(panels)

        # The classes explicitly registered by the native module are
        # authoritative.  Some bundled tools retain a base/legacy class with the
        # same bl_idname; rescuing it would make Blender replace the live RNA
        # class and can invalidate open operator or panel pointers.
        for cls in candidates:
            try:
                if _sms_class_registered(cls):
                    idname = str(getattr(cls, 'bl_idname', '') or '').strip()
                    if idname:
                        claimed_idnames.add(idname)
            except Exception:
                pass

        for cls in candidates:
            if cls in seen:
                continue
            try:
                idname = str(getattr(cls, 'bl_idname', '') or '').strip()
            except Exception:
                idname = ''
            if idname and idname in claimed_idnames and not _sms_class_registered(cls):
                continue
            seen.add(cls)
            if idname:
                claimed_idnames.add(idname)
            if _sms_try_rescue_native_class(cls):
                recovered.append(cls)
    _SMS_NATIVE_RECOVERED_CLASSES[:] = recovered
    _sms_rebuild_native_tool_records()



def _sms_clear_recovered_native_ui_classes():
    for cls in reversed(list(_SMS_NATIVE_RECOVERED_CLASSES)):
        try:
            if _sms_panel_class_is_panel(cls):
                _sms_disable_resident_panel_class(cls)
        except Exception:
            pass
    _SMS_NATIVE_RECOVERED_CLASSES.clear()

def _sms_rebuild_native_tool_records():
    _SMS_NATIVE_TOOL_RECORDS.clear()
    for meta in _sms_tool_meta_entries():
        tool_id = str(meta.get('tool_id') or '').strip()
        state = dict(_sms_native_tool_state(tool_id))
        module = meta.get('module')
        if module is None and _sms_native_tool_loaded(tool_id):
            module = _sms_native_module_from_meta(meta, require_loaded=True)
        panels, operators, menus = _sms_collect_public_ui_classes(module)
        live_operators = [cls for cls in operators if _sms_class_registered(cls)]
        live_menus = [cls for cls in menus if _sms_class_registered(cls)]
        # Standalone native N-panel classes are intentionally not registered.
        # Keep their Python class objects in the record so their draw() bodies can
        # still be hosted inside the unified Smart Modeling root panel.
        live_panels = list(panels)
        record = {
            'meta': meta,
            'module': module,
            'status': str(state.get('status') or 'available'),
            'error': str(state.get('error') or ''),
            'loaded': _sms_native_tool_loaded(tool_id),
            'panels': tuple(live_panels),
            'operators': tuple(live_operators),
            'menus': tuple(live_menus),
            'discoverable_panels': tuple(panels),
            'discoverable_operators': tuple(operators),
            'discoverable_menus': tuple(menus),
            'recovered_count': sum(1 for cls in tuple(live_panels) + tuple(live_operators) + tuple(live_menus) if cls in _SMS_NATIVE_RECOVERED_CLASSES),
        }
        _SMS_NATIVE_TOOL_RECORDS[tool_id] = record


def _sms_native_tool_record(tool_id: str):
    return _SMS_NATIVE_TOOL_RECORDS.get(str(tool_id or '').strip(), {})


def _sms_native_tool_enabled(context, meta: dict) -> bool:
    if not isinstance(meta, dict):
        return True
    tool_id = str(meta.get('tool_id') or '').strip()
    if not _sms_native_tool_has_persistent_load(tool_id):
        return True
    prop_name = str(meta.get('toggle') or '').strip()
    prefs = _sms_get_suite_prefs(context)
    # Persistent tools must fail closed. If the saved BoolProperty is missing
    # during reinstall, startup, or a Blender preference repair pass, the tool is
    # treated as disabled instead of being loaded accidentally.
    if not prop_name:
        return False
    return _sms_persistent_toggle_state_get(prop_name, context=context, prefs=prefs, default=False)

def _sms_native_tool_status_lines(context, meta: dict, record: dict):
    enabled = _sms_native_tool_enabled(context, meta)
    tool_id = str(meta.get('tool_id') or '').strip()
    status = str(record.get('status') or _sms_native_tool_state(tool_id).get('status') or 'available')
    recovered_count = int(record.get('recovered_count') or 0)
    counts = (
        len(tuple(record.get('discoverable_panels') or record.get('panels') or ())),
        len(tuple(record.get('discoverable_operators') or record.get('operators') or ())),
        len(tuple(record.get('discoverable_menus') or record.get('menus') or ())),
    )
    if status == 'loaded':
        en = f'Active. Panels: {counts[0]} / Operators: {counts[1]} / Menus: {counts[2]}.'
        ja = f'動作中です。パネル: {counts[0]} / オペレーター: {counts[1]} / メニュー: {counts[2]}。'
    elif status == 'loading':
        en = f'Loading. Panels: {counts[0]} / Operators: {counts[1]} / Menus: {counts[2]}.'
        ja = f'読み込み中です。パネル: {counts[0]} / オペレーター: {counts[1]} / メニュー: {counts[2]}。'
    elif status == 'failed':
        en = f'Activation failed. Panels: {counts[0]} / Operators: {counts[1]} / Menus: {counts[2]}.'
        ja = f'有効化に失敗しました。パネル: {counts[0]} / オペレーター: {counts[1]} / メニュー: {counts[2]}。'
    elif enabled:
        en = f'Enabled. Not loaded yet. Panels: {counts[0]} / Operators: {counts[1]} / Menus: {counts[2]}.'
        ja = f'有効です。まだ読み込まれていません。パネル: {counts[0]} / オペレーター: {counts[1]} / メニュー: {counts[2]}。'
    else:
        en = f'Disabled. Panels: {counts[0]} / Operators: {counts[1]} / Menus: {counts[2]}.'
        ja = f'無効です。パネル: {counts[0]} / オペレーター: {counts[1]} / メニュー: {counts[2]}。'
    if recovered_count:
        en += f' Recovered dormant UI classes: {recovered_count}.'
        ja += f' 休眠していた UI クラスを {recovered_count} 件復旧しました。'
    return en, ja


def _sms_native_menu_entries(record: dict, context=None):
    items = []
    seen = set()
    for cls in tuple(record.get('menus') or ()):
        menu_id = str(getattr(cls, 'bl_idname', '') or '').strip()
        if not menu_id or menu_id in seen:
            continue
        seen.add(menu_id)
        label = _ui_text(str(getattr(cls, 'bl_label', '') or getattr(cls, '__name__', '') or menu_id).strip(), context)
        upper = f'{menu_id} {label} {getattr(cls, "__name__", "")}'.upper()
        items.append((menu_id, label or menu_id, 'PIE' in upper))
    items.sort(key=lambda item: item[1].lower())
    return items


def _sms_native_operator_entries(record: dict, context=None):
    items = []
    seen = set()
    for cls in tuple(record.get('operators') or ()):
        op_id = str(getattr(cls, 'bl_idname', '') or '').strip()
        if not op_id or op_id in seen or op_id in _SMS_OPERATOR_INVOKE_DENYLIST:
            continue
        seen.add(op_id)
        label = _ui_text(str(getattr(cls, 'bl_label', '') or getattr(cls, '__name__', '') or op_id).strip() or op_id, context)
        desc = _ui_text(str(getattr(cls, 'bl_description', '') or '').strip(), context)
        items.append((op_id, label, desc))
    items.sort(key=lambda item: (item[1].lower(), item[0].lower()))
    return items


def _sms_native_target_help_en(kind: str, label: str, desc: str, *, is_pie: bool = False) -> str:
    label = str(label or '').strip() or 'Native Tool'
    desc = str(desc or '').strip()
    if kind == 'menu':
        menu_kind = 'pie menu' if is_pie else 'menu'
        return (
            f'Function: opens the migrated {label} {menu_kind} inside Smart Tools. '
            f'How to use: click this button, then choose a command from the opened menu.'
        )
    return (
        f'Function: {desc or label}. How to use: click this button to run the command directly from Smart Tools. '
        f'Some tools may open a dialog or require a valid mode or selection.'
    )


def _sms_native_target_help_ja(kind: str, label: str, desc: str, *, is_pie: bool = False) -> str:
    label = str(label or '').strip() or 'ネイティブツール'
    desc = str(desc or '').strip()
    if kind == 'menu':
        menu_kind = 'パイメニュー' if is_pie else 'メニュー'
        return (
            f'機能: Smart Tools 内で移植済みの {label} {menu_kind} を開きます。'
            f'使い方: このボタンを押して、表示されたメニューから目的の機能を選んでください。'
        )
    return (
        f'機能: {desc or label}。使い方: このボタンを押すと Smart Tools から直接実行します。'
        f'機能によってはダイアログが開く場合や、適切なモード・選択状態が必要な場合があります。'
    )


def _sms_operator_can_run(op_callable) -> bool:
    try:
        return bool(op_callable.poll())
    except Exception:
        return True


def _sms_operator_reported_message(error) -> str:
    # The message a tool reported for the user, or '' for an internal exception.
    match = re.match(r'^\s*(?:Error|エラー)\s*[:：]\s*(.+)$', str(error or ''), flags=re.S)
    message = str(match.group(1) if match else '').strip()
    if message and ('Traceback' in message or 'Python:' in message):
        message = ''
    return message


def _sms_operator_failure_text(button_operator, error, context=None) -> str:
    # A message the tool reported for the user is kept. An internal exception
    # text is replaced so that it is never shown as it is.
    message = _sms_operator_reported_message(error)
    if message:
        message = bpy.app.translations.pgettext_rpt(message)
        if _language.is_japanese(context) == bool(re.search(r'[\u3040-\u30ff\u3400-\u9fff]', message)):
            return message
    label = str(getattr(button_operator, 'target_label', '') or '').strip()
    label = _ui_text(label, context) if label else ''
    if label:
        return _pick_lang(f'{label} could not run. Check the mode and the selection.', f'「{label}」を実行できませんでした。モードと選択を確かめてください。', context)
    return _pick_lang('This command could not run. Check the mode and the selection.', 'このコマンドを実行できませんでした。モードと選択を確かめてください。', context)


def _sms_push_button_undo_step(target_id: str, target_label: str, result) -> None:
    # The button operators stay without UNDO (see _sms_force_operator_undo_class)
    # and a nested operator leaves no undo step of its own, so a finished command
    # adds its one step here. A command still running owns its own step.
    if not isinstance(result, set) or 'FINISHED' not in result:
        return
    target_id = str(target_id or '').strip()
    head, _, tail = target_id.partition('.')
    if head == 'screen':
        return
    try:
        op_cls = getattr(bpy.types, f'{head.upper()}_OT_{tail}', None)
        if (
            isinstance(op_cls, type)
            and 'UNDO' not in set(getattr(op_cls, 'bl_options', ()) or ())
            and not _sms_is_lazy_proxy_class(op_cls)
        ):
            return
        bpy.ops.ed.undo_push(message=str(target_label or target_id))
    except Exception:
        pass


def _sms_call_forwarding_warnings(button_operator, op_callable, *args, **kwargs):
    # Blender only writes the warnings and results of a nested operator to
    # sys.stdout, so they are reported again on the operator behind the button.
    forwarded = (
        (bpy.app.translations.pgettext_rpt('Warning') + ': ', 'WARNING'),
        (bpy.app.translations.pgettext_rpt('Info') + ': ', 'INFO'),
    )
    buffer = io.StringIO()
    try:
        with contextlib.redirect_stdout(buffer):
            return op_callable(*args, **kwargs)
    finally:
        for line in buffer.getvalue().splitlines():
            for prefix, level in forwarded:
                if line.startswith(prefix):
                    button_operator.report({level}, line[len(prefix):])
                    break
            else:
                print(line)


def _sms_resolve_operator_callable(op_id: str):
    op_id = str(op_id or '').strip()
    if '.' not in op_id:
        return None
    head, tail = op_id.split('.', 1)
    group = getattr(bpy.ops, head, None)
    if group is None:
        return None
    op = getattr(group, tail, None)
    if not callable(op):
        return None
    get_rna_type = getattr(op, 'get_rna_type', None)
    if not callable(get_rna_type):
        return None
    try:
        get_rna_type()
    except Exception:
        return None
    return op


class _SMS_NullOperatorProxy:
    def __setattr__(self, name, value):
        return None


_SMS_NULL_OPERATOR_PROXY = _SMS_NullOperatorProxy()


def _sms_layout_operator_if_registered(layout, op_id: str, *, text='', icon='NONE'):
    op_id = str(op_id or '').strip()
    icon = str(icon or 'NONE').strip() or 'NONE'
    resolved_icon = _sms_command_icon(op_id, text, '', 'TOOL_SETTINGS') if icon == 'NONE' else _sms_safe_icon(icon, 'TOOL_SETTINGS')
    if not op_id or op_id in _SMS_OPERATOR_INVOKE_DENYLIST:
        row = layout.row(align=True)
        row.enabled = False
        row.label(text=str(text or op_id or ''), icon=resolved_icon or 'NONE')
        return _SMS_NULL_OPERATOR_PROXY
    if callable(_sms_resolve_operator_callable(op_id)):
        if op_id in _SMS_OPERATOR_INVOKE_DEFAULT_IDS:
            old_context = getattr(layout, 'operator_context', 'EXEC_DEFAULT')
            try:
                layout.operator_context = 'INVOKE_DEFAULT'
                return layout.operator(op_id, text=text, icon=resolved_icon)
            finally:
                try:
                    layout.operator_context = old_context
                except Exception:
                    pass
        return layout.operator(op_id, text=text, icon=resolved_icon)
    row = layout.row(align=True)
    row.enabled = True
    row.label(text=str(text or op_id), icon=resolved_icon or 'NONE')
    return _SMS_NULL_OPERATOR_PROXY


def _sms_lazy_ui_snapshot_entry(kind: str, alias: str):
    try:
        return dict(((_SMS_LAZY_UI_SNAPSHOT or {}).get(str(kind or ''), {}) or {}).get(str(alias or ''), {}) or {})
    except Exception:
        return {}


def _sms_lazy_ui_proxy(context=None):
    global _SMS_LAZY_UI_SYNC_DEPTH
    prefs = _sms_get_suite_prefs(context or getattr(bpy, 'context', None))
    if prefs is None:
        return None
    _SMS_LAZY_UI_SYNC_DEPTH += 1
    try:
        return getattr(prefs, 'lazy_ui_settings', None)
    except Exception:
        return None
    finally:
        _SMS_LAZY_UI_SYNC_DEPTH = max(0, _SMS_LAZY_UI_SYNC_DEPTH - 1)


def _sms_lazy_ui_settings(kind: str, alias: str):
    return tuple(_sms_lazy_ui_snapshot_entry(kind, alias).get('settings') or ())


def _sms_restore_saved_crease_lazy_ui(context, wm_data):
    """Restore the unloaded Crease UI from its existing canonical tool settings."""
    global _SMS_LAZY_UI_SYNC_DEPTH
    if not isinstance(wm_data, dict):
        return
    from . import preferences as pref_bridge, common
    package = f'{__package__}.crease_preset'
    key = f'{package}:{package}.CreasePresetPreferences'
    prop_name = 'sms_intprefs_' + pref_bridge._key_token(key).lower().lstrip('_')
    saved = wm_data.get(prop_name)
    if not isinstance(saved, dict):
        return
    proxy = _sms_lazy_ui_proxy(context)
    if proxy is None:
        return
    mapped = {}
    for setting in _sms_lazy_ui_settings('native', 'crease_preset'):
        name, target = setting.get('name'), setting.get('proxy_key')
        if (setting.get('source_class') == 'CreasePresetPreferences'
                and name in saved and target and target not in _SMS_LAZY_UI_DIRTY_KEYS):
            mapped[target] = saved[name]
    _SMS_LAZY_UI_SYNC_DEPTH += 1
    try:
        common._apply_group(proxy, mapped, path='window_manager.lazy_ui_settings')
    finally:
        _SMS_LAZY_UI_SYNC_DEPTH -= 1


def _sms_lazy_ui_dirty_settings(kind: str, alias: str):
    dirty = set(_SMS_LAZY_UI_DIRTY_KEYS)
    return tuple(
        dict(setting or {})
        for setting in _sms_lazy_ui_settings(kind, alias)
        if str((setting or {}).get('proxy_key') or '').strip() in dirty
    )


def _sms_capture_lazy_ui_values(kind: str, alias: str, context=None):
    proxy = _sms_lazy_ui_proxy(context)
    if proxy is None:
        return {}
    captured = {}
    for setting in _sms_lazy_ui_dirty_settings(kind, alias):
        prop_key = str(setting.get('proxy_key') or '').strip()
        if not prop_key:
            continue
        try:
            captured[prop_key] = _sms_lazy_ui_value(proxy, prop_key)
        except Exception:
            pass
    return captured


def _sms_lazy_ui_value(proxy, prop_key: str):
    if proxy is None or not prop_key:
        raise AttributeError(prop_key)
    value = getattr(proxy, prop_key)
    if type(value).__name__ == 'bpy_prop_array':
        return tuple(value)
    if isinstance(value, set):
        return set(value)
    return value


def _sms_lazy_ui_runtime_roots(kind: str, alias: str, context=None):
    """Return a bounded set of live RNA owners that can contain tool settings."""
    context = context or getattr(bpy, 'context', None)
    roots = []
    seen = set()

    def _add(value):
        if value is None:
            return
        try:
            pointer = int(value.as_pointer())
        except Exception:
            pointer = id(value)
        key = (type(value), pointer)
        if key in seen:
            return
        seen.add(key)
        roots.append(value)

    if context is not None:
        for name in (
            'scene',
            'window_manager',
            'tool_settings',
            'active_object',
            'object',
            'space_data',
            'world',
        ):
            try:
                _add(getattr(context, name, None))
            except Exception:
                pass
        try:
            obj = getattr(context, 'active_object', None) or getattr(context, 'object', None)
            _add(getattr(obj, 'data', None) if obj is not None else None)
            _add(getattr(obj, 'active_material', None) if obj is not None else None)
        except Exception:
            pass

    _add(_sms_get_suite_prefs(context))

    if str(kind or '') == 'integrated':
        try:
            loader_mod = sys.modules.get(f'{__package__}.loader')
            record = loader_mod.get_record(str(alias or '')) if loader_mod is not None else {}
        except Exception:
            record = {}
        try:
            for _title, pref_obj in _sms_preferences_objects(context, record or {}):
                _add(pref_obj)
        except Exception:
            pass
    return tuple(roots)


def _sms_lazy_ui_apply_to_rna_owner(owner, source_settings, values):
    applied = set()
    if owner is None or not values:
        return applied
    try:
        class_names = {str(cls.__name__) for cls in type(owner).__mro__}
    except Exception:
        class_names = {str(type(owner).__name__)}
    proxied_class = str(getattr(type(owner), '_sms_source_class_name', '') or '')
    if proxied_class:
        class_names.add(proxied_class)
    for setting in tuple(source_settings or ()):
        source_class = str((setting or {}).get('source_class') or '').strip()
        name = str((setting or {}).get('name') or '').strip()
        prop_key = str((setting or {}).get('proxy_key') or '').strip()
        if not source_class or source_class not in class_names or not name or not prop_key:
            continue
        if prop_key not in values:
            continue
        try:
            rna_props = getattr(getattr(owner, 'bl_rna', None), 'properties', None)
            if rna_props is not None and rna_props.get(name) is None:
                continue
        except Exception:
            pass
        try:
            setattr(owner, name, values[prop_key])
            applied.add(prop_key)
        except Exception:
            pass
    return applied


def _sms_sync_lazy_ui_settings_to_runtime(kind: str, alias: str, context=None, *, captured_values=None) -> int:
    """Copy only user-edited pre-load values into newly registered RNA owners."""
    values = dict(captured_values or _sms_capture_lazy_ui_values(kind, alias, context=context))
    if not values:
        return 0
    dirty_settings = tuple(
        dict(setting or {})
        for setting in _sms_lazy_ui_settings(kind, alias)
        if str((setting or {}).get('proxy_key') or '').strip() in values
    )
    if not dirty_settings:
        return 0

    wanted_classes = {str(item.get('source_class') or '').strip() for item in dirty_settings}
    wanted_classes.discard('')
    if not wanted_classes:
        return 0

    applied = set()
    seen = set()

    def _walk(owner, depth: int):
        if owner is None:
            return
        try:
            pointer = int(owner.as_pointer())
        except Exception:
            pointer = id(owner)
        key = (type(owner), pointer)
        if key in seen:
            return
        seen.add(key)

        applied.update(_sms_lazy_ui_apply_to_rna_owner(owner, dirty_settings, values))
        if depth <= 0:
            return
        try:
            rna_props = tuple(getattr(getattr(owner, 'bl_rna', None), 'properties', ()) or ())
        except Exception:
            return
        for prop in rna_props:
            try:
                if str(getattr(prop, 'type', '') or '') != 'POINTER':
                    continue
                identifier = str(getattr(prop, 'identifier', '') or '')
                if not identifier or identifier == 'rna_type':
                    continue
                child = getattr(owner, identifier, None)
                if child is None:
                    continue
                child_names = {str(cls.__name__) for cls in type(child).__mro__}
                is_settings_owner = bool(child_names & wanted_classes)
                is_nested_group = isinstance(child, (bpy.types.PropertyGroup, bpy.types.AddonPreferences))
                if is_settings_owner or is_nested_group:
                    _walk(child, depth - 1)
            except Exception:
                continue

    for root in _sms_lazy_ui_runtime_roots(kind, alias, context=context):
        _walk(root, 3)

    for prop_key in applied:
        _SMS_LAZY_UI_DIRTY_KEYS.discard(prop_key)
    return len(applied)


def _sms_lazy_ui_target_operator_class(kind: str, alias: str, target_id: str):
    target_id = str(target_id or '').strip()
    if not target_id:
        return None
    record = {}
    if str(kind or '') == 'native':
        record = _sms_native_tool_record(alias) or {}
    elif str(kind or '') == 'integrated':
        try:
            loader_mod = sys.modules.get(f'{__package__}.loader')
            record = loader_mod.get_record(alias) if loader_mod is not None else {}
        except Exception:
            record = {}
    candidates = tuple((record or {}).get('operators') or ()) + tuple((record or {}).get('discoverable_operators') or ())
    for cls in candidates:
        try:
            if str(getattr(cls, 'bl_idname', '') or '').strip() == target_id:
                return cls
        except Exception:
            pass
    return None


def _sms_keyops_prepare_target(target_id: str, context=None) -> None:
    """Make a Key Ops button work when its command lives outside the loaded core."""
    if target_id.startswith('mesh.looptools_'):
        _sms_ensure_integrated_tool_loaded('looptools', context=context)
    elif target_id in {'keyops.cad_decimate', 'keyops.export_cad_decimate', 'keyops.import_cad_decimate', 'keyops.import_all_cad_decimate'}:
        pref_utils = sys.modules.get(f'{__package__}.key_operators_toolkit.fix_maya_pivot.utils.pref_utils')
        prefs = pref_utils.get_keyops_prefs() if pref_utils is not None else None
        if prefs is not None:
            prefs.enable_cad_decimate = True
        cad = sys.modules.get(f'{__package__}.key_operators_toolkit.fix_maya_pivot.operators.cad_decimate')
        loader_mod = sys.modules.get(f'{__package__}.loader')
        record = loader_mod.get_record('key_operators_toolkit') if loader_mod is not None else None
        if cad is not None and record is not None:
            panels = list(record.get('panels') or ())
            panels += [cls for cls in (cad.CADDecimatePanel, cad.KEYOPS_PT_cad_decimate_panel_manual) if cls not in panels]
            record['panels'] = panels


def _sms_lazy_ui_operator_kwargs(kind: str, alias: str, target_id: str, context=None, *, captured_values=None):
    values = dict(captured_values or _sms_capture_lazy_ui_values(kind, alias, context=context))
    target_cls = _sms_lazy_ui_target_operator_class(kind, alias, target_id)
    if not values or target_cls is None:
        return {}, set()
    try:
        class_names = {str(cls.__name__) for cls in target_cls.__mro__}
    except Exception:
        class_names = {str(getattr(target_cls, '__name__', '') or '')}
    try:
        rna_props = getattr(getattr(target_cls, 'bl_rna', None), 'properties', None)
    except Exception:
        rna_props = None
    kwargs = {}
    used = set()
    for setting in _sms_lazy_ui_settings(kind, alias):
        source_class = str(setting.get('source_class') or '').strip()
        name = str(setting.get('name') or '').strip()
        prop_key = str(setting.get('proxy_key') or '').strip()
        if source_class not in class_names or not name or not prop_key or prop_key not in values:
            continue
        try:
            if rna_props is not None and rna_props.get(name) is None:
                continue
            kwargs[name] = values[prop_key]
            used.add(prop_key)
        except Exception:
            pass
    return kwargs, used


class SMS_OT_native_tool_invoke(bpy.types.Operator):
    bl_idname = 'smart_modeling_suite.native_tool_invoke'
    bl_label = 'Native Tool Command'
    bl_description = 'Run a native Smart Modeling command or open a migrated menu from the Smart Modeling N-panel.'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    tool_id: StringProperty(options={'SKIP_SAVE'})
    target_kind: StringProperty(options={'SKIP_SAVE'})
    target_id: StringProperty(options={'SKIP_SAVE'})
    target_label: StringProperty(options={'SKIP_SAVE'})
    target_desc: StringProperty(options={'SKIP_SAVE'})
    is_pie_menu: BoolProperty(default=False, options={'SKIP_SAVE'})

    @classmethod
    def description(cls, _context, properties):
        kind = str(getattr(properties, 'target_kind', '') or '')
        label = str(getattr(properties, 'target_label', '') or '')
        desc = str(getattr(properties, 'target_desc', '') or '')
        is_pie = bool(getattr(properties, 'is_pie_menu', False))
        return _pick_lang(
            _sms_native_target_help_en(kind, label, desc, is_pie=is_pie),
            _sms_native_target_help_ja(kind, label, desc, is_pie=is_pie),
            _context,
        )

    def execute(self, _context):
        tool_id = str(self.tool_id or '').strip()
        try:
            captured_values = _sms_capture_lazy_ui_values('native', tool_id, context=_context)
        except Exception:
            captured_values = {}
        if tool_id and not _sms_native_tool_loaded(tool_id):
            if not _sms_ensure_native_tool_loaded(tool_id, context=_context):
                self.report({'ERROR'}, _sms_native_tool_error_excerpt(tool_id) or _pick_lang('This tool could not be loaded. Turn the add-on off and on, then try again.', 'このツールを読み込めませんでした。アドオンを入れ直してから、もう一度試してください。', _context))
                return {'CANCELLED'}
        try:
            _sms_sync_lazy_ui_settings_to_runtime('native', tool_id, context=_context, captured_values=captured_values)
        except Exception:
            pass
        kind = str(self.target_kind or '').strip()
        target_id = str(self.target_id or '').strip()
        if not target_id or (kind == 'operator' and target_id in _SMS_OPERATOR_INVOKE_DENYLIST):
            self.report({'WARNING'}, _pick_lang('This command requires a concrete workspace tool ID and cannot be run as a generic button.', 'このコマンドは具体的なワークスペースツールIDが必要なため、汎用ボタンとしては実行できません。', _context))
            return {'CANCELLED'}
        if kind == 'menu':
            try:
                if self.is_pie_menu:
                    return bpy.ops.wm.call_menu_pie(name=target_id)
                return bpy.ops.wm.call_menu(name=target_id)
            except Exception as exc:
                self.report({'ERROR'}, _pick_lang('This menu is not available.', 'このメニューは使えません。', _context))
                return {'CANCELLED'}

        op_callable = _sms_resolve_operator_callable(target_id)
        if not callable(op_callable):
            self.report({'ERROR'}, _pick_lang('This command is not available.', 'このコマンドは使えません。', _context))
            return {'CANCELLED'}

        try:
            invoke_kwargs, used_proxy_keys = _sms_lazy_ui_operator_kwargs(
                'native',
                tool_id,
                target_id,
                context=_context,
                captured_values=captured_values,
            )
        except Exception:
            invoke_kwargs, used_proxy_keys = {}, set()
        if not _sms_operator_can_run(op_callable):
            self.report({'WARNING'}, _pick_lang('This tool cannot run in the current state. Check the mode and the selection.', '今の状態では実行できません。モードと選択を確かめてください。', _context))
            return {'CANCELLED'}
        last_error = None
        for args in (('INVOKE_DEFAULT',), tuple()):
            try:
                call_args = (*args, True) if target_id == 'mo2.rename_data_to_object_name' else args
                result = _sms_call_forwarding_warnings(self, op_callable, *call_args, **invoke_kwargs)
                for prop_key in used_proxy_keys:
                    _SMS_LAZY_UI_DIRTY_KEYS.discard(prop_key)
                if isinstance(result, set):
                    # The organizer registers its own modal handler before
                    # returning RUNNING_MODAL.  This N-panel bridge is only the
                    # launcher and has no modal callback of its own, so it must
                    # finish while the child operator retains TIMER/ESC/RMB
                    # ownership.  Propagating RUNNING_MODAL makes Blender treat
                    # this bridge as a second, non-modal owner.
                    if target_id == 'mo2.organize_modal' and 'RUNNING_MODAL' in result:
                        return {'FINISHED'}
                    _sms_push_button_undo_step(target_id, self.target_label, result)
                    return result
                return {'FINISHED'}
            except Exception as exc:
                last_error = exc
                # The tool refused by itself: running it again cannot help and
                # would replace its message.
                if _sms_operator_reported_message(exc):
                    break
        self.report({'ERROR'}, _sms_operator_failure_text(self, last_error, _context))
        return {'CANCELLED'}


class SMS_OT_integrated_tool_invoke(bpy.types.Operator):
    bl_idname = 'smart_modeling_suite.integrated_tool_invoke'
    bl_label = 'Integrated Tool Command'
    bl_description = 'Load one integrated Smart Modeling tool and run the selected command from the Smart Modeling N-panel.'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    alias: StringProperty(options={'SKIP_SAVE'})
    target_kind: StringProperty(options={'SKIP_SAVE'})
    target_id: StringProperty(options={'SKIP_SAVE'})
    target_label: StringProperty(options={'SKIP_SAVE'})
    target_desc: StringProperty(options={'SKIP_SAVE'})
    is_pie_menu: BoolProperty(default=False, options={'SKIP_SAVE'})

    @classmethod
    def description(cls, _context, properties):
        kind = str(getattr(properties, 'target_kind', '') or '')
        label = str(getattr(properties, 'target_label', '') or '')
        desc = str(getattr(properties, 'target_desc', '') or '')
        is_pie = bool(getattr(properties, 'is_pie_menu', False))
        return _pick_lang(
            _sms_native_target_help_en(kind, label, desc, is_pie=is_pie),
            _sms_native_target_help_ja(kind, label, desc, is_pie=is_pie),
            _context,
        )

    def execute(self, context):
        alias = str(self.alias or '').strip()
        try:
            captured_values = _sms_capture_lazy_ui_values('integrated', alias, context=context)
        except Exception:
            captured_values = {}
        if not alias or not _sms_ensure_integrated_tool_loaded(alias, context=context):
            self.report({'ERROR'}, _pick_lang('This tool could not be loaded. Turn the add-on off and on, then try again.', 'このツールを読み込めませんでした。アドオンを入れ直してから、もう一度試してください。', context))
            return {'CANCELLED'}
        try:
            _sms_sync_lazy_ui_settings_to_runtime('integrated', alias, context=context, captured_values=captured_values)
        except Exception:
            pass

        kind = str(self.target_kind or '').strip()
        target_id = str(self.target_id or '').strip()
        if not target_id or (kind == 'operator' and target_id in _SMS_OPERATOR_INVOKE_DENYLIST):
            self.report({'WARNING'}, _pick_lang('This command cannot be run as a generic button.', 'このコマンドは汎用ボタンとして実行できません。', context))
            return {'CANCELLED'}
        if kind == 'menu':
            try:
                if self.is_pie_menu:
                    return bpy.ops.wm.call_menu_pie(name=target_id)
                return bpy.ops.wm.call_menu(name=target_id)
            except Exception as exc:
                self.report({'ERROR'}, _pick_lang('This menu is not available.', 'このメニューは使えません。', context))
                return {'CANCELLED'}

        op_callable = _sms_resolve_operator_callable(target_id)
        if not callable(op_callable) and alias == 'key_operators_toolkit':
            _sms_keyops_prepare_target(target_id, context)
            op_callable = _sms_resolve_operator_callable(target_id)
        if not callable(op_callable):
            self.report({'ERROR'}, _pick_lang('This command is not available.', 'このコマンドは使えません。', context))
            return {'CANCELLED'}
        try:
            invoke_kwargs, used_proxy_keys = _sms_lazy_ui_operator_kwargs(
                'integrated',
                alias,
                target_id,
                context=context,
                captured_values=captured_values,
            )
        except Exception:
            invoke_kwargs, used_proxy_keys = {}, set()
        if not _sms_operator_can_run(op_callable):
            self.report({'WARNING'}, _pick_lang('This tool cannot run in the current state. Check the mode and the selection.', '今の状態では実行できません。モードと選択を確かめてください。', context))
            return {'CANCELLED'}
        last_error = None
        for args in (('INVOKE_DEFAULT',), tuple()):
            try:
                result = _sms_call_forwarding_warnings(self, op_callable, *args, **invoke_kwargs)
                for prop_key in used_proxy_keys:
                    _SMS_LAZY_UI_DIRTY_KEYS.discard(prop_key)
                if isinstance(result, set):
                    _sms_push_button_undo_step(target_id, self.target_label, result)
                    return result
                return {'FINISHED'}
            except Exception as exc:
                last_error = exc
                # The tool refused by itself: running it again cannot help and
                # would replace its message.
                if _sms_operator_reported_message(exc):
                    break
        self.report({'ERROR'}, _sms_operator_failure_text(self, last_error, context))
        return {'CANCELLED'}


class VIEW3D_PT_sms_all_commands(bpy.types.Panel):
    bl_label = 'Command Browser'
    bl_description = 'Comprehensive access browser that exposes every discoverable Smart Modeling native menu, operator, and migrated panel entry inside the Smart Modeling N-panel.'
    bl_idname = 'VIEW3D_PT_sms_all_commands'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, _context):
        return True

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False
        total_panels = sum(len(tuple(record.get('discoverable_panels') or record.get('panels') or ())) for record in _SMS_NATIVE_TOOL_RECORDS.values())
        total_ops = sum(len(tuple(record.get('discoverable_operators') or record.get('operators') or ())) for record in _SMS_NATIVE_TOOL_RECORDS.values())
        total_menus = sum(len(tuple(record.get('discoverable_menus') or record.get('menus') or ())) for record in _SMS_NATIVE_TOOL_RECORDS.values())
        loaded = sum(1 for record in _SMS_NATIVE_TOOL_RECORDS.values() if str(record.get('status') or '') == 'loaded')
        standby = sum(1 for record in _SMS_NATIVE_TOOL_RECORDS.values() if str(record.get('status') or '') == 'available')
        recovered = len(tuple(_SMS_NATIVE_RECOVERED_CLASSES))
        box = layout.box()
        loading = sum(1 for record in _SMS_NATIVE_TOOL_RECORDS.values() if str(record.get('status') or '') == 'loading')
        failed = sum(1 for record in _SMS_NATIVE_TOOL_RECORDS.values() if str(record.get('status') or '') == 'failed')
        disabled = sum(1 for meta in _sms_tool_meta_entries() if not _sms_native_tool_enabled(context, meta))
        box.label(text=_pick_lang(f'Panels: {total_panels} / Operators: {total_ops} / Menus: {total_menus}', f'パネル: {total_panels} / オペレーター: {total_ops} / メニュー: {total_menus}', context), icon='TOOL_SETTINGS')
        box.label(text=_pick_lang(f'Loaded: {loaded} / Loading: {loading} / Disabled: {disabled} / Error: {failed}', f'読み込み済み: {loaded} / 読み込み中: {loading} / 無効: {disabled} / エラー: {failed}', context))
        if recovered:
            box.label(text=_pick_lang(f'Recovered dormant UI classes: {recovered}', f'休眠 UI クラス復旧: {recovered}', context), icon='CHECKMARK')


def _sms_native_tool_browser_panel_class(meta: dict):
    tool_id = str(meta.get('tool_id') or '').strip()
    label = str(meta.get('label') or tool_id or 'Native Tool').strip()
    class_name = f'SMS_PT_NATIVE_ALL_{tool_id.upper()}'
    panel_id = f'SMS_PT_NATIVE_ALL_{tool_id.upper()}'
    icon = str(meta.get('icon') or 'TOOL_SETTINGS')

    @classmethod
    def poll(cls, _context):
        return True

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False
        record = _sms_native_tool_record(tool_id)
        enabled = _sms_native_tool_enabled(context, meta)
        en_line, ja_line = _sms_native_tool_status_lines(context, meta, record)
        status = str(record.get('status') or 'available')

        status_box = layout.box()
        status_box.label(text=_pick_lang(en_line, ja_line, context), icon=icon)
        row = status_box.row(align=True)
        if status == 'loaded':
            row.label(text=_pick_lang('Active', 'アクティブ', context), icon='CHECKMARK')
        elif status == 'loading':
            row.label(text=_pick_lang('Loading', '読み込み中', context), icon='TIME')
        elif not enabled:
            row.label(text=_pick_lang('Disabled', '無効', context), icon='HIDE_OFF')
        elif status == 'failed':
            row.label(text=_pick_lang('Error', 'エラー', context), icon='ERROR')
        else:
            row.label(text=_pick_lang('Not loaded', '未読み込み', context))
        if status == 'failed':
            excerpt = _sms_native_tool_error_excerpt(tool_id)
            if excerpt:
                warn = layout.box()
                warn.alert = True
                warn.label(text=_pick_lang(f'Activation error: {excerpt}', f'有効化エラー: {excerpt}', context), icon='ERROR')

        menus = _sms_native_menu_entries(record, context)
        if menus:
            box = layout.box()
            box.label(text=_pick_lang('Menus', 'メニュー', context), icon='MENU_PANEL')
            col = box.column(align=True)
            col.enabled = True
            for menu_id, menu_label, is_pie in menus:
                op = col.operator(SMS_OT_native_tool_invoke.bl_idname, text=menu_label, icon='PRESET' if is_pie else 'DOWNARROW_HLT')
                op.tool_id = tool_id
                op.target_kind = 'menu'
                op.target_id = menu_id
                op.target_label = menu_label
                op.target_desc = ''
                op.is_pie_menu = bool(is_pie)

        operators = _sms_native_operator_entries(record, context)
        if operators:
            box = layout.box()
            box.label(text=_pick_lang('Operators', 'オペレーター', context), icon='TOOL_SETTINGS')
            flow = box.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
            flow.enabled = True
            for op_id, op_label, op_desc in operators:
                op = flow.operator(SMS_OT_native_tool_invoke.bl_idname, text=op_label, icon=_sms_command_icon(op_id, op_label, op_desc))
                op.tool_id = tool_id
                op.target_kind = 'operator'
                op.target_id = op_id
                op.target_label = op_label
                op.target_desc = op_desc
                op.is_pie_menu = False

        if not menus and not operators:
            layout.label(text=_pick_lang('No public menus or operators were discovered for this tool.', 'このツールでは公開メニューまたはオペレーターを検出できませんでした。', context))

    attrs = {
        '__module__': __name__,
        'bl_label': label,
        'bl_description': f'Complete Smart Modeling access panel for {label}.',
        'bl_idname': panel_id,
        'bl_space_type': 'VIEW_3D',
        'bl_region_type': 'UI',
        'bl_category': 'Smart Modeling',
        'bl_parent_id': 'VIEW3D_PT_sms_all_commands',
        'bl_options': {'DEFAULT_CLOSED'},
        'poll': poll,
        'draw': draw,
    }
    return type(class_name, (bpy.types.Panel,), attrs)


def _sms_register_native_access_panels():
    _sms_unregister_native_access_panels()
    return None


def _sms_unregister_native_access_panels():
    for cls in reversed(list(_SMS_NATIVE_ACCESS_PANEL_CLASSES)):
        _safe_unregister_class(cls)
    _SMS_NATIVE_ACCESS_PANEL_CLASSES.clear()


def _sms_purge_stale_dynamic_tool_panels() -> int:
    if _sms_install_safe_phase_active():
        return 0
    return _sms_cleanup_stale_owned_classes(panels_only=True)


_SMS_OBSOLETE_STANDARD_CHILD_PANEL_NAMES = (
    'VIEW3D_PT_sms_modifier_suite_notice',
    'VIEW3D_PT_sms_hub_edit',
    'VIEW3D_PT_sms_hub_cleanup',
    'VIEW3D_PT_sms_hub_surface',
    'VIEW3D_PT_sms_hub_sketch',
    'VIEW3D_PT_sms_modifier_companion_tools',
    'VIEW3D_PT_sms_all_commands',
    'VIEW3D_PT_sms_mesh_align',
    'VIEW3D_PT_sms_mesh_align_help',
    'VIEW3D_PT_sms_crease_preset',
    'VIEW3D_PT_sms_crease_preset_help',
    'VIEW3D_PT_sms_apply_weighted_normal',
    'VIEW3D_PT_sms_apply_weighted_normal_help',
    'VIEW3D_PT_sketch_tools',
    'VIEW3D_PT_quad_strip_draw_final',
    'VIEW3D_PT_sms_quad_strip_draw',
)


def _sms_wrapper_panel_classes():
    # Keep the N-panel as a normal Blender sidebar panel. All former child
    # panels are now drawn inside the unified tool list so they can be grouped
    # as 常時機能 / クリック起動コマンド and use the same 設定 UI pattern.
    panel_names = tuple(panel_id for panel_id, _space_type in _SMS_PHYSICAL_ROOT_SPECS)
    return tuple(cls for cls in (globals().get(name) for name in panel_names) if isinstance(cls, type))


def _sms_purge_obsolete_standard_child_panels() -> int:
    if _sms_install_safe_phase_active():
        return 0
    return _sms_cleanup_stale_owned_classes(panels_only=True)




def _sms_purge_non_root_smart_modeling_panels() -> int:
    if _sms_install_safe_phase_active():
        return 0
    return _sms_cleanup_stale_owned_classes(panels_only=True)

def _sms_iter_legacy_panel_classes():
    panels = []
    seen = set()
    for meta in _sms_tool_meta_entries():
        record = _sms_native_tool_record(str(meta.get('tool_id') or ''))
        record_panels = tuple(record.get('panels') or ())
        if not record_panels:
            module = meta.get('module')
            if module is None and _sms_native_tool_loaded(str(meta.get('tool_id') or '')):
                module = _sms_native_module_from_meta(meta, require_loaded=True)
            record_panels = _sms_collect_public_ui_classes(module)[0]
        for cls in record_panels:
            if cls is None or cls in seen:
                continue
            seen.add(cls)
            panels.append(cls)
    return panels


def _sms_properties_panel_classes():
    panels = list(_sms_wrapper_panel_classes())
    panels.extend(tuple(_SMS_NATIVE_ACCESS_PANEL_CLASSES))
    panels.extend(_sms_modifier_workspace_panel_classes())
    panels.extend(_sms_iter_legacy_panel_classes())
    ordered = []
    seen = set()
    for cls in panels:
        if cls is None or cls in seen:
            continue
        seen.add(cls)
        ordered.append(cls)
    return ordered


# ------------------------------------------------------------
# Compact N-panel wrappers for tools that do not ship their own dedicated panels
# (Shared suite tab wrappers for tools that don't expose their own compact panel)
# ------------------------------------------------------------

def _sms_enabled(context, key: str, default: bool = True) -> bool:
    prefs = _sms_get_suite_prefs(context)
    prop_name = str(key or '').strip()
    if prefs is None or not prop_name or not _sms_rna_prop_exists(prefs, prop_name):
        return bool(default)
    return bool(_sms_safe_get_rna_attr(prefs, prop_name, default))

def _sms_addon_enabled(context, suite_basename: str) -> bool:
    suite_basename = str(suite_basename or '').strip()
    if not suite_basename:
        return False
    suffix = '.' + suite_basename
    try:
        import addon_utils
        for module in addon_utils.modules():
            module_name = str(getattr(module, '__name__', '') or '').strip()
            if not module_name:
                continue
            if module_name == suite_basename or module_name.endswith(suffix):
                try:
                    return bool(addon_utils.check(module_name)[1])
                except Exception:
                    return True
    except Exception:
        pass
    return False


def _t(msgid: str) -> str:
    return bpy.app.translations.pgettext(msgid)

class VIEW3D_PT_sms_mesh_align(bpy.types.Panel):
    bl_label = "Mesh Align"
    bl_description = 'Mesh Align panel in the Smart Modeling workspace.'
    bl_idname = "VIEW3D_PT_sms_mesh_align"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'

    @classmethod
    def poll(cls, context):
        return _sms_enabled(context, "enable_mesh_align_preset", True) and _sms_native_tool_loaded("mesh_align_preset")

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        box = layout.box()
        box.label(text=_t("Quick Start"), icon='PLAY')
        row = box.row(align=True)
        row.scale_y = 1.25
        row.operator_context = 'INVOKE_DEFAULT'
        _sms_layout_operator_if_registered(row, "mesh.mesh_align_master", text=_t("Open Mesh Align"), icon='MODIFIER')
        col = box.column(align=True)

        box = layout.box()
        box.label(text=_t("Quick Align"), icon='EMPTY_ARROWS')
        row = box.row(align=True)
        _sms_layout_operator_if_registered(row, "mesh.align_x", text="X")
        _sms_layout_operator_if_registered(row, "mesh.align_y", text="Y")
        _sms_layout_operator_if_registered(row, "mesh.align_z", text="Z")

        box = layout.box()
        box.label(text=_t("View / Utility"), icon='HIDE_OFF')
        row = box.row(align=True)
        _sms_layout_operator_if_registered(row, "mesh.align_view", text=_t("To View"))
        _sms_layout_operator_if_registered(row, "mesh.best_fit_plane", text=_t("Best Fit Plane"))

# Obsolete inline help panel removed. Help content is in help.py and loads only from the Help button.

class VIEW3D_PT_sms_crease_preset(bpy.types.Panel):
    bl_label = "Crease Preset"
    bl_description = 'Crease Preset panel in the Smart Modeling workspace.'
    bl_idname = "VIEW3D_PT_sms_crease_preset"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'

    @classmethod
    def poll(cls, context):
        return _sms_enabled(context, "enable_crease_preset", True) and _sms_native_tool_loaded("crease_preset")

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        try:
            record = _sms_native_tool_record('crease_preset')
            module = record.get('module') or _sms_native_module_from_meta({'tool_id': 'crease_preset', 'module_path': 'crease_preset'}, require_loaded=True)
            draw_fn = getattr(module, 'draw_smart_modeling_panel', None) if module is not None else None
            if callable(draw_fn):
                draw_fn(layout, context)
                return
        except Exception:
            pass

        box = layout.box()
        box.label(text=_t("Quick Start"), icon='PLAY')
        row = box.row(align=True)
        row.scale_y = 1.25
        row.operator_context = 'INVOKE_DEFAULT'
        _sms_layout_operator_if_registered(row, "mesh.edge_crease_master", text=_t("Open Crease Preset"), icon='PRESET')
        col = box.column(align=True)

        box = layout.box()
        box.label(text=_t("Quick Apply (Selected)"), icon='GREASEPENCIL')
        row = box.row(align=True)
        op = _sms_layout_operator_if_registered(row, "mesh.crease_apply", text="0.0")
        op.crease_value = 0.0
        op.apply_mode = 'SELECTED'
        op = _sms_layout_operator_if_registered(row, "mesh.crease_apply", text="0.25")
        op.crease_value = 0.25
        op.apply_mode = 'SELECTED'
        op = _sms_layout_operator_if_registered(row, "mesh.crease_apply", text="0.5")
        op.crease_value = 0.5
        op.apply_mode = 'SELECTED'
        op = _sms_layout_operator_if_registered(row, "mesh.crease_apply", text="1.0")
        op.crease_value = 1.0
        op.apply_mode = 'SELECTED'

# Obsolete inline help panel removed. Help content is in help.py and loads only from the Help button.

class VIEW3D_PT_sms_apply_weighted_normal(bpy.types.Panel):
    bl_label = "Apply Weighted Normal"
    bl_description = 'Apply Weighted Normal panel in the Smart Modeling workspace.'
    bl_idname = "VIEW3D_PT_sms_apply_weighted_normal"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'

    @classmethod
    def poll(cls, context):
        return _sms_enabled(context, "enable_apply_weighted_normal", True) and _sms_native_tool_loaded("apply_weighted_normal")

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        box = layout.box()
        box.label(text=_t("Quick Start"), icon='PLAY')
        col = box.column(align=True)

        row = box.row(align=True)
        row.scale_y = 1.25
        op = _sms_layout_operator_if_registered(row, "mesh.apply_weighted_normal", text=_t("Add & Apply (Bake)"), icon='MOD_NORMALEDIT')
        op.apply_mode = 'ADD_AND_APPLY'
        op.preset = 'HARD_SURFACE'
        op.limit_to_selection = False

        op = _sms_layout_operator_if_registered(row, "mesh.apply_weighted_normal", text=_t("Add Only (Non-Destructive)"), icon='MODIFIER')
        op.apply_mode = 'ADD_ONLY'
        op.preset = 'HARD_SURFACE'
        op.limit_to_selection = False

        box = layout.box()
        box.label(text=_t("Presets"), icon='PRESET')
        row = box.row(align=True)
        op = _sms_layout_operator_if_registered(row, "mesh.apply_weighted_normal", text=_t("Hard Surface Modeling"))
        op.apply_mode = 'ADD_AND_APPLY'
        op.preset = 'HARD_SURFACE'
        op.limit_to_selection = False
        op = _sms_layout_operator_if_registered(row, "mesh.apply_weighted_normal", text=_t("Game Asset"))
        op.apply_mode = 'ADD_AND_APPLY'
        op.preset = 'GAME'
        op.limit_to_selection = False
        op = _sms_layout_operator_if_registered(row, "mesh.apply_weighted_normal", text=_t("Minimal"))
        op.apply_mode = 'ADD_AND_APPLY'
        op.preset = 'MINIMAL'
        op.limit_to_selection = False

# Obsolete inline help panel removed. Help content is in help.py and loads only from the Help button.


try:
    translation_dict.setdefault('ja_JP', {}).update({
        ('*', 'Vertex Slide Always-on Runtime'): '頂点スライド常時ランタイム',
        ('*', 'Controls the Vertex Slide top-bar toggle, shortcut toggle, status display, and live transform monitor. Disabled keeps the tool unloaded and light until the always-on switch is enabled again.'): '頂点スライドの上部バー切り替え、ショートカット切り替え、ステータス表示、ライブ変形監視を制御します。無効時は、常時機能切り替えを再度有効にするまでツールを未読み込みの軽い状態に保ちます。',
        ('*', 'Vertex Slide Constraint'): '頂点スライド制約',
        ('*', 'Runtime-only Vertex Slide toggle state used by the 3D View top-bar button, keymap toggle, and status display.'): '3Dビュー上部バー、キーマップ切り替え、ステータス表示で使う、保存されない頂点スライド状態です。',
    })
except Exception:
    pass

def _sms_force_load_enabled_persistent_tools(context=None) -> None:
    """Synchronously load all switches that are enabled in the saved state.

    This is used only after Blender's startup/reload RNA guard has cleared.
    The normal lazy queue is intentionally bypassed here so tools marked
    有効 are available immediately after Blender opens, exactly as the
    常時機能切り替え contract states.
    """
    context = context or getattr(bpy, 'context', None)
    if not _sms_runtime_active() or _sms_rna_access_is_unsafe():
        return
    # Use the JSON snapshot as the source of truth.  Do not read or write the
    # WindowManager settings PointerProperty from startup timers; crash logs show
    # Blender can route timer-driven RNA access through stale panel custom data
    # during extension install/reinstall.
    prefs = None
    for spec in tuple(globals().get('_SMS_ALWAYS_ON_TOOL_SPECS', ())):
        try:
            if not _sms_spec_has_persistent_load(spec):
                continue
            kind = str((spec or {}).get('kind') or '').strip()
            alias = str((spec or {}).get('tool_id') or (spec or {}).get('alias') or (spec or {}).get('id') or '').strip()
            enable_prop = str((spec or {}).get('enable_prop') or '').strip()
            if not kind or not alias or not enable_prop:
                continue
            if not _sms_persistent_toggle_snapshot_get(enable_prop, False):
                continue
            _sms_start_tool_runtime(kind, alias, context=context)
        except Exception:
            pass


def _sms_enabled_persistent_runtime_pending(context=None) -> bool:
    """Return True while an enabled startup toggle has not reached a usable state."""
    context = context or getattr(bpy, 'context', None)
    prefs = _sms_get_suite_prefs(context) if context is not None else None
    for spec in tuple(globals().get('_SMS_ALWAYS_ON_TOOL_SPECS', ())):
        try:
            if not _sms_spec_has_persistent_load(spec):
                continue
            kind = str((spec or {}).get('kind') or '').strip()
            alias = str((spec or {}).get('tool_id') or (spec or {}).get('alias') or (spec or {}).get('id') or '').strip()
            enable_prop = str((spec or {}).get('enable_prop') or '').strip()
            if not kind or not alias or not enable_prop:
                continue
            if not _sms_persistent_toggle_state_get(enable_prop, context=context, prefs=prefs, default=False):
                continue
            if kind == 'native':
                if not _sms_native_tool_loaded(alias):
                    return True
            elif kind == 'integrated':
                try:
                    _sms_loader = sys.modules.get(f'{__package__}.loader')
                    if _sms_loader is None:
                        return True
                    record = _sms_loader.get_record(alias) or {}
                    if str((record or {}).get('status') or '').strip().lower() != 'loaded':
                        return True
                except Exception:
                    return True
            elif kind == 'suite_panel':
                # Suite-panel entries do not import external modules; the runtime
                # state is the saved UI/start flag itself.
                continue
        except Exception:
            continue
    return False


def _sms_startup_always_on_sync_timer():
    global _SMS_STARTUP_ALWAYS_ON_SYNC_ATTEMPTS
    _SMS_STARTUP_ALWAYS_ON_SYNC_ATTEMPTS += 1
    try:
        if not _sms_runtime_active():
            return None
        if _sms_rna_access_is_unsafe():
            return 0.35 if _SMS_STARTUP_ALWAYS_ON_SYNC_ATTEMPTS < 24 else None
        ctx = getattr(bpy, 'context', None)
        try:
            _sms_force_load_enabled_persistent_tools(ctx)
        except Exception:
            pass
        try:
            _sms_rebuild_native_tool_records()
        except Exception:
            pass
        if _SMS_STARTUP_ALWAYS_ON_SYNC_ATTEMPTS < 24:
            try:
                if _sms_enabled_persistent_runtime_pending(ctx):
                    return 0.35
            except Exception:
                pass
    except Exception:
        pass
    return None


def _sms_schedule_startup_always_on_sync(delay=2.0):
    global _SMS_STARTUP_ALWAYS_ON_SYNC_ATTEMPTS
    _SMS_STARTUP_ALWAYS_ON_SYNC_ATTEMPTS = 0
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is None:
            return
        try:
            if hasattr(timers, 'is_registered') and timers.is_registered(_sms_startup_always_on_sync_timer):
                timers.unregister(_sms_startup_always_on_sync_timer)
        except Exception:
            pass
        # There is nothing to poll when every persistent runtime is disabled.
        # Keep the all-OFF state genuinely idle: no bounded retry timer, handler,
        # or keymap is needed until a user explicitly enables a runtime switch.
        try:
            if not _sms_enabled_persistent_runtime_pending(getattr(bpy, 'context', None)):
                return
        except Exception:
            return
        timers.register(_sms_startup_always_on_sync_timer, first_interval=float(delay))
    except Exception:
        pass


def _sms_cancel_startup_always_on_sync():
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_sms_startup_always_on_sync_timer):
            timers.unregister(_sms_startup_always_on_sync_timer)
    except Exception:
        pass


def register():
    global _SMS_RUNTIME_REFRESH_ACTIVE, _SMS_RNA_UNSAFE_UNTIL
    _sms_set_npanel_preferences_synchronized(False)
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if isinstance(ns, dict):
            ns['SMART_MODELING_SUITE_SAFE_INSTALLING'] = True
    except Exception:
        pass
    try:
        _SMS_RNA_UNSAFE_UNTIL = time.monotonic() + 1.25
        try:
            ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
            if isinstance(ns, dict):
                ns['SMART_MODELING_SUITE_RNA_UNSAFE_UNTIL'] = _SMS_RNA_UNSAFE_UNTIL
        except Exception:
            pass
    except Exception:
        _SMS_RNA_UNSAFE_UNTIL = 0.0
    _sms_set_runtime_token()
    _SMS_RUNTIME_REFRESH_ACTIVE = True
    _sms_cancel_on_demand_loads()
    _sms_init_native_tool_state()
    try:
        from . import registry as _sms_registry
        _sms_registry.clear_cache()
    except Exception:
        pass
    try:
        _sms_refresh_integrated_ui_specs_snapshot()
    except Exception:
        pass
    try:
        _sms_build_keyops_static_keymap_entries()
    except Exception:
        pass
    # Toolset translations
    global _SMS_UI_ICON_CACHE
    try:
        _SMS_UI_ICON_CACHE = _sms_build_valid_ui_icons()
    except Exception:
        _SMS_UI_ICON_CACHE = frozenset()
    try:
        bpy.app.translations.register(__name__, translation_dict)
    except ValueError:
        try:
            bpy.app.translations.unregister(__name__)
        except Exception:
            pass
        try:
            bpy.app.translations.register(__name__, translation_dict)
        except Exception:
            pass
    # Register suite-side operators and N-panel setting storage first (no dependency on native runtime modules).
    # Do not detach/recreate existing WindowManager RNA during in-place install;
    # stale UI handlers may still hold old pointers.
    _safe_register_class(SMS_OT_copy_to_clipboard)
    _safe_register_class(SMS_OT_rebuild_npanel_settings)
    _safe_register_class(SMS_OT_toggle_ui_section)
    _safe_register_class(SMS_OT_toggle_edge_crease_overlay)
    _safe_register_class(SMS_OT_toggle_npanel_state_save)
    _safe_register_class(SMS_OT_toggle_persistent_runtime_switch)
    _safe_register_class(SMS_OT_show_tool_help)
    _safe_register_class(SMS_OT_show_keymap_registration)
    _safe_register_class(SMS_OT_native_tool_invoke)
    _safe_register_class(SMS_OT_integrated_tool_invoke)
    # The integrated-tool Overview UI calls two lightweight command owners from
    # ui_runtime.  They must be registered even though the integrated feature
    # modules themselves stay lazy; otherwise visible About/Quick Access buttons
    # resolve to unknown operators until an unrelated tool load happens.
    try:
        from . import ui_runtime as _sms_ui_runtime
        _sms_ui_runtime.register()
    except Exception:
        pass
    # Pre-register property-group types referenced by SMS_NPanelSettings.
    for cls in _SMS_SHARED_PREF_CLASSES:
        _safe_register_class(cls)
    try:
        _sms_wire_npanel_setting_updates()
    except Exception:
        pass
    try:
        _sms_apply_saved_defaults_to_npanel_annotations()
    except Exception:
        pass
    # Cross-version live reinstall tolerance: re-resolve stale captured
    # Pointer/Collection targets before RNA resolves the deferred annotations,
    # so a residue class from an old install can never raise
    # "PointerProperty(...) expected an RNA type ... missing bl_rna" here.
    try:
        _sms_resolve_npanel_pointer_annotations()
    except Exception:
        pass
    _safe_register_class(SMS_NPanelSettings)
    try:
        _sms_attach_nested_tool_settings_properties()
    except Exception:
        pass
    _sms_attach_npanel_settings_property()
    try:
        _sms_load_panel_settings_snapshot()
    except Exception:
        pass
    try:
        from . import common as _sms_common
        load_fn = getattr(_sms_common, 'load_settings_file', None)
        apply_fn = getattr(_sms_common, 'apply_persistent_settings', None)
        if callable(load_fn):
            load_fn()
        if callable(apply_fn):
            apply_fn(getattr(bpy, 'context', None))
    except Exception:
        pass
    try:
        globals()['_SMS_NPANEL_STATE_SAVE_CACHE'] = _sms_npanel_state_save_from_snapshot(True)
    except Exception:
        pass
    try:
        prefs = _sms_get_suite_prefs(getattr(bpy, 'context', None))
        if prefs is not None:
            _sms_restore_suite_panel_settings(getattr(bpy, 'context', None), prefs)
            _sms_sync_persistent_toggle_snapshot_to_prefs(context=getattr(bpy, 'context', None), prefs=prefs)
    except Exception:
        pass
    # Keep command polling fail-open until the post-startup callback reaches a
    # stable WindowManager context and repeats the persisted-value restore.
    _sms_set_npanel_preferences_synchronized(False)
    # Blender 5.1 can omit a restored user-keymap item from dispatch when only a
    # late-created proxy owns its operator ID.  Materialize the real classes for
    # enabled, already-bound shortcuts before rebuilding the keyconfig.  Every
    # unbound tool keeps its zero-idle lazy shell, so this does not restore the
    # old all-tools startup import or any recurring background work.
    # Keep-alive guards: a single tool's residue (stale class, foreign RNA
    # property, translations cache from an old install) must never kill the
    # whole suite registration during a cross-version live reinstall.
    try:
        _sms_preload_bound_keymap_tools(getattr(bpy, 'context', None))
    except Exception:
        pass
    try:
        _sms_register_lazy_keymap_proxies(strict=True)
    except Exception:
        pass
    try:
        _sms_register_integrated_lazy_proxies(strict=True)
    except Exception:
        pass
    try:
        _sms_refresh_bound_keymap_entrypoints()
    except Exception:
        pass
    try:
        _sms_schedule_bound_keymap_post_startup_sync(delay=0.05)
    except Exception:
        pass
    try:
        _sms_unregister_vertex_slide_topbar_button(remove_state_props=False)
    except Exception:
        pass
    # Remove stale header/status callbacks left by older builds before any new
    # always-on runtime is started.  Enabled tools are reactivated by the startup
    # sync below; disabled tools remain zero-background.
    for _sms_cleanup_tool_id in ('vertex_slide', 'toggle_auto_merge_snap', 'direct_delete'):
        try:
            _sms_deactivate_known_native_background_hooks(_sms_cleanup_tool_id)
        except Exception:
            pass
    # Every declared keymap target already has a zero-idle RNA shell. The real
    # tool module is loaded by that shell on the first shortcut event, while
    # background hooks remain controlled by Always-on toggles.
    try:
        _sms_purge_hosted_native_npanel()
    except Exception:
        pass
    try:
        _sms_purge_obsolete_standard_child_panels()
    except Exception:
        pass
    try:
        _sms_purge_stale_dynamic_tool_panels()
    except Exception:
        pass
    try:
        _sms_purge_non_root_smart_modeling_panels()
    except Exception:
        pass
    for cls in _sms_wrapper_panel_classes():
        _safe_register_class(cls)
    try:
        _sms_purge_non_root_smart_modeling_panels()
    except Exception:
        pass
    try:
        _sms_rebuild_native_tool_records()
    except Exception:
        pass
    _sms_prepare_properties_panels()
    _sms_purge_stale_smarttools_proxy_panels()
    _sms_tag_redraw_view3d_areas()
    # No recurring keymap bootstrap work is started here.
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if isinstance(ns, dict):
            ns['SMART_MODELING_SUITE_SAFE_INSTALLING'] = False
    except Exception:
        pass
    # Persistence-only subscriptions belong to N-panel State Save.  File-load
    # cancellation, namespace rearm and exit cleanup are lifecycle safety and
    # remain registered even while settings writes are OFF.
    try:
        _sms_sync_settings_resident_resources(
            _sms_npanel_state_save_enabled(getattr(bpy, 'context', None), default=True)
        )
    except Exception:
        pass
    # A delayed startup sync starts only tools whose 常時機能切り替え switch is ON.
    # Disabled tools remain fully deactivated until a command is explicitly run.
    try:
        _sms_schedule_startup_always_on_sync(delay=0.25)
    except Exception:
        pass
    # RNA may evaluate update callbacks while the session-only proxy group is
    # materialized during registration.  Those defaults are not user edits.
    _SMS_LAZY_UI_DIRTY_KEYS.clear()
def unregister():
    global _SMS_RUNTIME_REFRESH_ACTIVE
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if isinstance(ns, dict):
            ns['SMART_MODELING_SUITE_SAFE_INSTALLING'] = True
    except Exception:
        pass
    _sms_original_unregister_class_for_shutdown = getattr(bpy.utils, 'unregister_class', None)
    _SMS_LAZY_UI_DIRTY_KEYS.clear()
    try:
        _sms_capture_suite_panel_settings(context=getattr(bpy, 'context', None), prefs=_sms_get_suite_prefs(getattr(bpy, 'context', None)))
        _sms_flush_panel_settings_save(force=True)
    except Exception:
        pass
    _SMS_RUNTIME_REFRESH_ACTIVE = False
    _sms_set_npanel_preferences_synchronized(False)
    _sms_clear_runtime_token()
    _sms_mark_native_registering(False)

    try:
        _sms_remove_all_suite_keymaps()
    except Exception:
        pass

    _sms_unregister_settings_autosave_timer()
    _sms_unregister_runtime_handlers()
    _sms_cancel_standard_n_panel_refresh_timer()
    _sms_cancel_preload_all_tools_timer()
    _sms_cancel_native_keymap_eager_load_timer()
    _sms_cancel_bound_keymap_post_startup_sync()
    _sms_cancel_on_demand_loads()
    try:
        _sms_cancel_startup_always_on_sync()
    except Exception:
        pass
    try:
        _sms_unregister_all_lazy_keymap_proxies(destroy=True)
    except Exception:
        pass
    try:
        _sms_unregister_vertex_slide_topbar_button(remove_state_props=False)
    except Exception:
        pass

    # Integrated tools are owned by the suite loader.  Tear them down before
    # unregistering the host classes so their handlers, RNA roots and UI types
    # cannot survive an extension disable/re-enable cycle.
    try:
        from . import loader as _sms_loader
        _sms_loader.unregister_all()
    except Exception:
        pass
    try:
        _sms_unregister_integrated_lazy_proxies(force=True)
    except Exception:
        pass
    # The integrated loader removes its captured WindowManager proxy roots.
    # Clear the corresponding Python maps and proxy classes immediately so a
    # same-session re-enable cannot reuse a stale property name.
    try:
        from . import preferences as _sms_integrated_preferences
        _sms_integrated_preferences.unregister()
    except Exception:
        pass

    _sms_uninstall_standard_n_panel()
    _sms_unregister_native_access_panels()
    try:
        _sms_purge_hosted_native_npanel()
    except Exception:
        pass
    try:
        _sms_purge_obsolete_standard_child_panels()
    except Exception:
        pass
    try:
        _sms_purge_stale_dynamic_tool_panels()
    except Exception:
        pass
    try:
        _sms_purge_non_root_smart_modeling_panels()
    except Exception:
        pass

    # Unregister suite-side panels and N-panel setting storage before native runtime modules.
    try:
        _sms_capture_suite_panel_settings(context=getattr(bpy, 'context', None), prefs=_sms_get_suite_prefs(getattr(bpy, 'context', None)))
        _sms_flush_panel_settings_save(force=True)
    except Exception:
        pass
    for cls in reversed(_sms_wrapper_panel_classes()):
        _safe_unregister_class(cls)
    _sms_detach_npanel_settings_property()

    # Unregister only the native modules that were actually loaded in this session.
    for meta in reversed(_sms_tool_meta_entries()):
        tool_id = str(meta.get('tool_id') or '').strip()
        if not _sms_native_tool_loaded(tool_id):
            continue
        module = _sms_native_module_from_meta(meta, require_loaded=True)
        try:
            unregister_fn = getattr(module, 'unregister', None)
            if callable(unregister_fn):
                _sms_call_with_panel_unregister_guard(unregister_fn)
        except Exception:
            pass

    _sms_clear_recovered_native_ui_classes()
    _SMS_NATIVE_TOOL_RECORDS.clear()
    _SMS_NATIVE_TOOL_STATE.clear()
    try:
        _sms_unregister_vertex_slide_state_properties()
    except Exception:
        pass

    try:
        _sms_remove_all_suite_keymaps()
    except Exception:
        pass

    try:
        _sms_flush_panel_settings_save(force=True)
    except Exception:
        pass
    try:
        _sms_flush_userpref_save()
    except Exception:
        pass

    _safe_unregister_class(SMS_NPanelSettings)
    for cls in reversed(_SMS_SHARED_PREF_CLASSES):
        _safe_unregister_class(cls)
    try:
        for _sms_help_mod_name in (__package__ + '.help', 'smart_modeling_suite.help', 'bl_ext.user_default.smart_modeling_suite.help'):
            _sms_help_mod = sys.modules.get(_sms_help_mod_name)
            if _sms_help_mod is not None:
                _sms_help_unregister = getattr(_sms_help_mod, 'unregister', None)
                if callable(_sms_help_unregister):
                    _sms_help_unregister()
    except Exception:
        pass
    try:
        from . import ui_runtime as _sms_ui_runtime
        _sms_ui_runtime.unregister()
    except Exception:
        pass
    _safe_unregister_class(SMS_OT_integrated_tool_invoke)
    _safe_unregister_class(SMS_OT_native_tool_invoke)
    _safe_unregister_class(SMS_OT_show_keymap_registration)
    _safe_unregister_class(SMS_OT_show_tool_help)
    _safe_unregister_class(SMS_OT_toggle_persistent_runtime_switch)
    _safe_unregister_class(SMS_OT_toggle_npanel_state_save)
    _safe_unregister_class(SMS_OT_toggle_edge_crease_overlay)
    _safe_unregister_class(SMS_OT_toggle_ui_section)
    _safe_unregister_class(SMS_OT_rebuild_npanel_settings)
    _safe_unregister_class(SMS_OT_copy_to_clipboard)
    try:
        _sms_release_core_icon_previews()
    except Exception:
        pass

    # Toolset translations
    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass
    try:
        if callable(_sms_original_unregister_class_for_shutdown):
            bpy.utils.unregister_class = _sms_original_unregister_class_for_shutdown
    except Exception:
        pass
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if isinstance(ns, dict):
            ns['SMART_MODELING_SUITE_SAFE_INSTALLING'] = False
    except Exception:
        pass


# Tooltip audit disabled for lower startup cost.



# --- Smart Modeling unified tool UI bridge ---
_SMS_WORKFLOW_CATEGORY_DEFS = (
    {
        'id': 'edit_transfer',
        'label_en': 'Edit and Transfer',
        'label_ja': '編集と転送',
        'icon': 'EDITMODE_HLT',
    },
    {
        'id': 'alignment_flow',
        'label_en': 'Align, Flow and Deform',
        'label_ja': '整列・フロー・変形',
        'icon': 'EMPTY_ARROWS',
    },
    {
        'id': 'retopo_rebuild',
        'label_en': 'Retopo and Rebuild',
        'label_ja': 'リトポと再構築',
        'icon': 'MESH_GRID',
    },
    {
        'id': 'cleanup_organize',
        'label_en': 'Delete and Cleanup',
        'label_ja': '削除と整理',
        'icon': 'TRASH',
    },
    {
        'id': 'hard_surface_shading',
        'label_en': 'Hard Surface Modeling',
        'label_ja': 'ハードサーフェス',
        'icon': 'MOD_BEVEL',
    },
    {
        'id': 'sketch_curve',
        'label_en': 'Sketch and Retopo',
        'label_ja': 'スケッチとリトポ',
        'icon': 'CURVE_DATA',
    },
    {
        'id': 'generate_scatter',
        'label_en': 'Generate, Scatter, Build',
        'label_ja': '生成・散布・建築',
        'icon': 'OUTLINER_COLLECTION',
    },
    {
        'id': 'other_tools',
        'label_en': 'Utility Tools',
        'label_ja': 'ユーティリティ',
        'icon': 'TOOL_SETTINGS',
    },
)

_SMS_NATIVE_WORKFLOW_CATEGORY = {
    'vertex_copy': 'edit_transfer',
    'connect': 'edit_transfer',
    'vertex_slide': 'alignment_flow',
    'mesh_split': 'edit_transfer',
    'mesh_align_preset': 'alignment_flow',
    'toggle_auto_merge_snap': 'alignment_flow',
    'quad_strip_draw': 'retopo_rebuild',
    'direct_delete': 'cleanup_organize',
    'model_organized': 'cleanup_organize',
    'crease_preset': 'hard_surface_shading',
    'apply_weighted_normal': 'hard_surface_shading',
    'sketch_tools': 'sketch_curve',
    'modeling_toolset_tools': 'other_tools',
}

_SMS_INTEGRATED_WORKFLOW_CATEGORY = {
    'edit_mesh_tools': 'edit_transfer',
    'key_operators_toolkit': 'edit_transfer',
    'edgeflow': 'alignment_flow',
    'looptools': 'alignment_flow',
    'mio3_flex': 'alignment_flow',
    'f2': 'retopo_rebuild',
    'polyquilt_fork': 'retopo_rebuild',
    'mesh_repair_tools': 'cleanup_organize',
    'boltfactory': 'hard_surface_shading',
    'curve_tools': 'sketch_curve',
    'extra_curve_objectes': 'sketch_curve',
    'antlandscape': 'generate_scatter',
    'archimesh': 'generate_scatter',
    'cell_fracture': 'generate_scatter',
    'ivygen': 'generate_scatter',
    'real_snow': 'generate_scatter',
    'sapling_tree_gen': 'generate_scatter',
    'scatter_objects': 'generate_scatter',
    'tissue': 'generate_scatter',
}




_SMS_VERTEX_SLIDE_HEADER_APPENDED = False
_SMS_VERTEX_SLIDE_XFORM_TEMPLATE_ORIGINAL = None
_SMS_VERTEX_SLIDE_EDITOR_MENUS_ORIGINAL = None
_SMS_SVS_TRANSIENT_FLAG = 'svs_vertex_slide_constraint_enabled'
_SMS_VERTEX_SLIDE_ICON_RELOAD_ATTEMPTED = False


def _sms_vertex_slide_state_from_context(context):
    try:
        wm = getattr(context, 'window_manager', None)
        scene = getattr(context, 'scene', None)
        for owner in (wm, scene):
            if owner is None:
                continue
            try:
                getter = getattr(owner, 'get', None)
                if callable(getter):
                    value = getter(_SMS_SVS_TRANSIENT_FLAG, None)
                    if value is not None:
                        return bool(value)
            except Exception:
                pass
            try:
                if hasattr(owner, _SMS_SVS_TRANSIENT_FLAG):
                    return bool(getattr(owner, _SMS_SVS_TRANSIENT_FLAG, False))
            except Exception:
                pass
    except Exception:
        pass
    return False


def _sms_vertex_slide_runtime_allowed(context):
    # During Blender startup and add-on reinstall, do not dereference nested
    # AddonPreferences / PointerProperty state from the 3D View header.
    if _sms_rna_access_is_unsafe():
        return True
    try:
        prefs = _sms_get_suite_prefs(context)
    except Exception:
        prefs = None
    if prefs is None:
        return True
    try:
        if _sms_rna_prop_exists(prefs, 'enable_vertex_slide'):
            return bool(_sms_safe_get_rna_attr(prefs, 'enable_vertex_slide', True))
    except Exception:
        return True
    return True


def _sms_vertex_slide_header_icon_value():
    global _SMS_VERTEX_SLIDE_ICON_RELOAD_ATTEMPTED
    try:
        value = _sms_core_icon_value('move_transform_arrows', 0)
        if int(value or 0):
            return int(value)
    except Exception:
        pass
    # Some Blender UI sessions create the preview collection before icon ids are
    # assigned.  Retry once after the UI context exists so the top-bar button can
    # use the same transform-arrow style icon instead of falling back forever.
    try:
        if not bool(getattr(bpy.app, 'background', False)) and not _SMS_VERTEX_SLIDE_ICON_RELOAD_ATTEMPTED:
            _SMS_VERTEX_SLIDE_ICON_RELOAD_ATTEMPTED = True
            _sms_load_core_icon_previews(force=True)
            value = _sms_core_icon_value('move_transform_arrows', 0)
            if int(value or 0):
                return int(value)
    except Exception:
        pass
    return 0


def _sms_draw_vertex_slide_topbar_button_in_layout(layout, context):
    try:
        if context is None or getattr(context, 'mode', '') != 'EDIT_MESH':
            return
        if not _sms_vertex_slide_runtime_allowed(context):
            return
        if layout is None:
            return
        enabled = _sms_vertex_slide_state_from_context(context)
        # Keep the button compact so it can sit directly beside the left-side
        # 3D View header menus, next to the UV menu cluster instead of the
        # transform-orientation controls on the right.
        row = layout.row(align=True)
        row.alert = False
        row.operator(
            'mesh.smart_vert_slide',
            text='',
            icon=_sms_safe_icon('EMPTY_ARROWS', 'TRANSFORM_MOVE'),
            emboss=True,
            depress=enabled,
        )
    except Exception:
        pass

def _sms_draw_vertex_slide_topbar_button(self, context):
    try:
        _sms_draw_vertex_slide_topbar_button_in_layout(getattr(self, 'layout', None), context)
    except Exception:
        pass


def _sms_vertex_slide_draw_xform_template(layout, context):
    # Compatibility wrapper used mainly to unwrap older in-session builds that
    # inserted the Vertex Slide button into Blender's transform-control block.
    # It is also kept as a fallback for uncommon builds without editor menus.
    result = None
    original = _SMS_VERTEX_SLIDE_XFORM_TEMPLATE_ORIGINAL
    if callable(original):
        result = original(layout, context)
    if _SMS_VERTEX_SLIDE_EDITOR_MENUS_ORIGINAL is None:
        try:
            _sms_draw_vertex_slide_topbar_button_in_layout(layout, context)
        except Exception:
            pass
    return result


def _sms_vertex_slide_draw_collapsible_with_button(context, layout):
    # Draw Blender's left-side View/Select/Add/Mesh/.../UV menus first, then place
    # the Vertex Slide toggle immediately after that UV menu group and before the
    # spacer that separates the transform-orientation controls on the right.
    result = None
    original = _SMS_VERTEX_SLIDE_EDITOR_MENUS_ORIGINAL
    if callable(original):
        try:
            result = original(context, layout)
        except Exception:
            result = None
    try:
        _sms_draw_vertex_slide_topbar_button_in_layout(layout, context)
    except Exception:
        pass
    return result


def _sms_register_vertex_slide_state_properties():
    for owner_cls in (getattr(bpy.types, 'WindowManager', None), getattr(bpy.types, 'Scene', None)):
        if owner_cls is None:
            continue
        try:
            if not hasattr(owner_cls, _SMS_SVS_TRANSIENT_FLAG):
                setattr(owner_cls, _SMS_SVS_TRANSIENT_FLAG, BoolProperty(
                    name='Vertex Slide Constraint',
                    description='Runtime-only Vertex Slide toggle state used by the 3D View top-bar button, keymap toggle, and status display.',
                    default=False,
                    options={'SKIP_SAVE'},
                ))
        except Exception:
            pass


def _sms_unregister_vertex_slide_state_properties():
    for owner_cls in (getattr(bpy.types, 'WindowManager', None), getattr(bpy.types, 'Scene', None)):
        if owner_cls is None:
            continue
        try:
            if hasattr(owner_cls, _SMS_SVS_TRANSIENT_FLAG):
                delattr(owner_cls, _SMS_SVS_TRANSIENT_FLAG)
        except Exception:
            pass


def _sms_register_vertex_slide_topbar_button():
    global _SMS_VERTEX_SLIDE_HEADER_APPENDED, _SMS_VERTEX_SLIDE_XFORM_TEMPLATE_ORIGINAL, _SMS_VERTEX_SLIDE_EDITOR_MENUS_ORIGINAL
    try:
        _sms_register_vertex_slide_state_properties()
    except Exception:
        pass
    if _SMS_VERTEX_SLIDE_HEADER_APPENDED:
        return

    header = getattr(bpy.types, 'VIEW3D_HT_header', None)
    menus_cls = getattr(bpy.types, 'VIEW3D_MT_editor_menus', None)
    if header is None:
        return

    try:
        # Remove old append-style hooks and unwrap older xform-template wrappers.
        try:
            header.remove(_sms_draw_vertex_slide_topbar_button)
        except Exception:
            pass

        current_xform = getattr(header, 'draw_xform_template', None)
        if getattr(current_xform, '__name__', '') == '_sms_vertex_slide_draw_xform_template':
            previous_xform = None
            try:
                previous_xform = getattr(current_xform, '__globals__', {}).get('_SMS_VERTEX_SLIDE_XFORM_TEMPLATE_ORIGINAL')
            except Exception:
                previous_xform = None
            if callable(previous_xform):
                try:
                    header.draw_xform_template = staticmethod(previous_xform)
                    current_xform = previous_xform
                except Exception:
                    pass
        _SMS_VERTEX_SLIDE_XFORM_TEMPLATE_ORIGINAL = None

        if menus_cls is not None:
            current_menu = getattr(menus_cls, 'draw_collapsible', None)
            if current_menu is _sms_vertex_slide_draw_collapsible_with_button or getattr(current_menu, '__name__', '') == '_sms_vertex_slide_draw_collapsible_with_button':
                previous_menu = None
                try:
                    previous_menu = getattr(current_menu, '__globals__', {}).get('_SMS_VERTEX_SLIDE_EDITOR_MENUS_ORIGINAL')
                except Exception:
                    previous_menu = None
                if callable(previous_menu):
                    current_menu = previous_menu
                else:
                    _SMS_VERTEX_SLIDE_HEADER_APPENDED = True
                    return

            if callable(current_menu):
                _SMS_VERTEX_SLIDE_EDITOR_MENUS_ORIGINAL = current_menu
                menus_cls.draw_collapsible = staticmethod(_sms_vertex_slide_draw_collapsible_with_button)
                _SMS_VERTEX_SLIDE_HEADER_APPENDED = True
                return

        # Fallback for uncommon builds without VIEW3D_MT_editor_menus: keep the
        # button available, but prefer the menu-side placement on Blender 5.1.
        current_xform = getattr(header, 'draw_xform_template', None)
        if callable(current_xform):
            _SMS_VERTEX_SLIDE_XFORM_TEMPLATE_ORIGINAL = current_xform
            header.draw_xform_template = staticmethod(_sms_vertex_slide_draw_xform_template)
            _SMS_VERTEX_SLIDE_HEADER_APPENDED = True
    except Exception:
        _SMS_VERTEX_SLIDE_HEADER_APPENDED = False

def _sms_unregister_vertex_slide_topbar_button(remove_state_props=True):
    global _SMS_VERTEX_SLIDE_HEADER_APPENDED, _SMS_VERTEX_SLIDE_XFORM_TEMPLATE_ORIGINAL, _SMS_VERTEX_SLIDE_EDITOR_MENUS_ORIGINAL
    header = getattr(bpy.types, 'VIEW3D_HT_header', None)
    menus_cls = getattr(bpy.types, 'VIEW3D_MT_editor_menus', None)
    try:
        if header is not None:
            try:
                current = getattr(header, 'draw_xform_template', None)
                if (
                    (current is _sms_vertex_slide_draw_xform_template or getattr(current, '__name__', '') == '_sms_vertex_slide_draw_xform_template')
                    and callable(_SMS_VERTEX_SLIDE_XFORM_TEMPLATE_ORIGINAL)
                ):
                    header.draw_xform_template = staticmethod(_SMS_VERTEX_SLIDE_XFORM_TEMPLATE_ORIGINAL)
            except Exception:
                pass
            try:
                header.remove(_sms_draw_vertex_slide_topbar_button)
            except Exception:
                pass
        if menus_cls is not None:
            try:
                current = getattr(menus_cls, 'draw_collapsible', None)
                if (
                    (current is _sms_vertex_slide_draw_collapsible_with_button or getattr(current, '__name__', '') == '_sms_vertex_slide_draw_collapsible_with_button')
                    and callable(_SMS_VERTEX_SLIDE_EDITOR_MENUS_ORIGINAL)
                ):
                    menus_cls.draw_collapsible = staticmethod(_SMS_VERTEX_SLIDE_EDITOR_MENUS_ORIGINAL)
            except Exception:
                pass
    except Exception:
        pass
    _SMS_VERTEX_SLIDE_XFORM_TEMPLATE_ORIGINAL = None
    _SMS_VERTEX_SLIDE_EDITOR_MENUS_ORIGINAL = None
    _SMS_VERTEX_SLIDE_HEADER_APPENDED = False
    if remove_state_props:
        try:
            _sms_unregister_vertex_slide_state_properties()
        except Exception:
            pass



_SMS_PERSISTENT_NATIVE_TOOL_IDS = {
    # Only native tools with real resident hooks belong in the centralized
    # Always-on list.  Click-only operators and modal tools are deliberately
    # excluded: loading them on demand must not be presented as background work.
    'vertex_copy',
    'vertex_slide',
    'toggle_auto_merge_snap',
    'direct_delete',
    'apply_weighted_normal',
}

_SMS_PERSISTENT_INTEGRATED_ALIASES = {
    # Key Operators installs optional Outliner/load handlers and Tissue can run
    # frame-change reaction-diffusion services.  The remaining bundled tools
    # are explicit command/modal generators and therefore stay click-only.
    'key_operators_toolkit',
    'tissue',
}

_SMS_ALWAYS_ON_TOOL_SPECS = (
    {'kind': 'native', 'tool_id': 'vertex_copy', 'enable_prop': 'enable_vertex_copy', 'label_en': 'Vertex Copy', 'label_ja': '頂点コピー'},
    {'kind': 'native', 'tool_id': 'connect', 'enable_prop': 'enable_connect', 'label_en': 'Mesh Connect', 'label_ja': 'メッシュ接続'},
    {'kind': 'native', 'tool_id': 'mesh_split', 'enable_prop': 'enable_mesh_split', 'label_en': 'Mesh Split', 'label_ja': 'メッシュ分割'},
    {'kind': 'integrated', 'alias': 'key_operators_toolkit', 'enable_prop': 'enable_tool_key_operators_toolkit', 'label_en': 'Key Operation Tools', 'label_ja': 'キー操作ツール'},
    {'kind': 'integrated', 'alias': 'edit_mesh_tools', 'enable_prop': 'enable_tool_edit_mesh_tools', 'label_en': 'Mesh Edit Tools', 'label_ja': 'メッシュ編集ツール'},
    {'kind': 'native', 'tool_id': 'vertex_slide', 'enable_prop': 'enable_vertex_slide', 'label_en': 'Vertex Slide', 'label_ja': '頂点スライド'},
    {'kind': 'native', 'tool_id': 'mesh_align_preset', 'enable_prop': 'enable_mesh_align_preset', 'label_en': 'Mesh Align', 'label_ja': 'メッシュ整列'},
    {'kind': 'native', 'tool_id': 'toggle_auto_merge_snap', 'enable_prop': 'enable_toggle_auto_merge_snap', 'label_en': 'Merge Snap', 'label_ja': 'マージスナップ'},
    {'kind': 'integrated', 'alias': 'edgeflow', 'enable_prop': 'enable_tool_edgeflow', 'label_en': 'Edge Flow', 'label_ja': 'エッジフロー'},
    {'kind': 'integrated', 'alias': 'mio3_flex', 'enable_prop': 'enable_tool_mio3_flex', 'label_en': 'Flex Deform', 'label_ja': 'フレックス変形'},
    {'kind': 'integrated', 'alias': 'looptools', 'enable_prop': 'enable_tool_looptools', 'label_en': 'Loop Tools', 'label_ja': 'ループツール'},
    {'kind': 'native', 'tool_id': 'quad_strip_draw', 'enable_prop': 'enable_quad_strip_draw', 'label_en': 'Quad Retopo', 'label_ja': 'クアッドリトポ'},
    {'kind': 'integrated', 'alias': 'f2', 'enable_prop': 'enable_tool_f2', 'label_en': 'Face Builder', 'label_ja': '面作成'},
    {'kind': 'integrated', 'alias': 'polyquilt_fork', 'enable_prop': 'enable_tool_polyquilt_fork', 'label_en': 'PolyQuilt Retopo', 'label_ja': 'PolyQuiltリトポ'},
    {'kind': 'native', 'tool_id': 'direct_delete', 'enable_prop': 'enable_direct_delete', 'label_en': 'Direct Delete', 'label_ja': '直接削除'},
    {'kind': 'native', 'tool_id': 'model_organized', 'enable_prop': 'enable_model_organized', 'label_en': 'Model Organizer', 'label_ja': 'モデル整理'},
    {'kind': 'integrated', 'alias': 'mesh_repair_tools', 'enable_prop': 'enable_tool_mesh_repair_tools', 'label_en': 'Mesh Repair', 'label_ja': 'メッシュ修復'},
    {'kind': 'native', 'tool_id': 'crease_preset', 'enable_prop': 'enable_crease_preset', 'label_en': 'Crease Preset', 'label_ja': 'Crease プリセット'},
    {'kind': 'native', 'tool_id': 'apply_weighted_normal', 'enable_prop': 'enable_apply_weighted_normal', 'label_en': 'Weighted Normal', 'label_ja': '重み付き法線'},
    {'kind': 'resident_proxy', 'id': 'archimesh_hint_overlay', 'runtime_group': 'persistent', 'enable_prop': 'enable_archimesh_hint_overlay', 'label_en': 'Architecture Hint Overlay', 'label_ja': '建築ヒント表示'},
    {'kind': 'integrated', 'alias': 'boltfactory', 'enable_prop': 'enable_tool_boltfactory', 'label_en': 'Bolt Generator', 'label_ja': 'ボルト生成'},
    {'kind': 'native', 'tool_id': 'sketch_tools', 'enable_prop': 'enable_sketch_tools', 'label_en': 'Sketch Surface', 'label_ja': 'Sketch サーフェス'},
    {'kind': 'integrated', 'alias': 'extra_curve_objectes', 'enable_prop': 'enable_tool_extra_curve_objectes', 'label_en': 'Curve Objects', 'label_ja': 'カーブオブジェクト'},
    {'kind': 'integrated', 'alias': 'curve_tools', 'enable_prop': 'enable_tool_curve_tools', 'label_en': 'Curve Tools', 'label_ja': 'カーブツール'},
    {'kind': 'integrated', 'alias': 'archimesh', 'enable_prop': 'enable_tool_archimesh', 'label_en': 'Architecture', 'label_ja': '建築生成'},
    {'kind': 'integrated', 'alias': 'cell_fracture', 'enable_prop': 'enable_tool_cell_fracture', 'label_en': 'Cell Fracture', 'label_ja': 'セル破砕'},
    {'kind': 'integrated', 'alias': 'ivygen', 'enable_prop': 'enable_tool_ivygen', 'label_en': 'Ivy Generator', 'label_ja': 'ツタ生成'},
    {'kind': 'integrated', 'alias': 'scatter_objects', 'enable_prop': 'enable_tool_scatter_objects', 'label_en': 'Object Scatter', 'label_ja': 'オブジェクト散布'},
    {'kind': 'integrated', 'alias': 'real_snow', 'enable_prop': 'enable_tool_real_snow', 'label_en': 'Snow Generator', 'label_ja': '雪生成'},
    {'kind': 'integrated', 'alias': 'antlandscape', 'enable_prop': 'enable_tool_antlandscape', 'label_en': 'Terrain Generator', 'label_ja': '地形生成'},
    {'kind': 'integrated', 'alias': 'tissue', 'enable_prop': 'enable_tool_tissue', 'label_en': 'Tissue Generator', 'label_ja': 'Tissue生成'},
    {'kind': 'integrated', 'alias': 'sapling_tree_gen', 'enable_prop': 'enable_tool_sapling_tree_gen', 'label_en': 'Tree Generator', 'label_ja': '樹木生成'},
    {'kind': 'suite_panel', 'id': 'all_commands', 'enable_prop': 'enable_suite_panel_all_commands', 'label_en': 'Command Browser', 'label_ja': 'コマンドブラウザー'},
    {'kind': 'suite_panel', 'id': 'modifier_companion', 'enable_prop': 'enable_suite_panel_modifier_companion', 'label_en': 'Modifier Companion', 'label_ja': 'モディファイア補助'},
    {'kind': 'native', 'tool_id': 'modeling_toolset_tools', 'enable_prop': 'enable_modeling_toolset_tools', 'label_en': 'Integrated Modeling Tools', 'label_ja': '統合モデリングツール'},
)

_SMS_RUNTIME_GROUP_DEFS = (
    {
        'id': 'persistent',
        'label_en': 'Always-on Features',
        'label_ja': '常時機能切り替え',
        'description_en': 'Features in this group can keep shortcuts, handlers, timers, live indicators, or viewport helpers active after they are loaded. Use the toggle only when you want to completely allow or block that background behavior.',
        'description_ja': 'このグループは、読み込み後にショートカット、ハンドラー、タイマー、ライブ表示、ビューポート補助などが継続して動作し得る機能です。常時動作を許可または完全に止めたい場合だけトグルを使います。',
        'icon': 'CHECKMARK',
        'show_prop': 'ui_show_runtime_group_persistent',
    },
    {
        'id': 'click_only',
        'label_en': 'Click-only Commands',
        'label_ja': 'クリック起動コマンド',
        'description_en': 'Tools in this group do work only after you press a command button, open a popup, or start a modal tool. They do not need an enable/disable switch in this list.',
        'description_ja': 'このグループは、ボタン、ポップアップ、モーダル操作を開始した時だけ処理するツールです。この一覧では有効・無効の切り替えを表示しません。',
        'icon': 'MOUSE_LMB',
        'show_prop': 'ui_show_runtime_group_click_only',
    },
)


_SMS_SUITE_PANEL_ITEMS = (
    {
        'id': 'edit_transfer_hub',
        'label_en': 'Edit and Transfer',
        'label_ja': '編集と転送',
        'description_en': 'Compact access to edit, connection, vertex copy, and alignment helpers that run only when you press their buttons.',
        'description_ja': '編集、接続、頂点コピー、整列補助をまとめたクリック起動コマンドの簡易アクセスです。ボタンを押した時だけ処理します。',
        'category': 'edit_transfer',
        'runtime_group': 'click_only',
        'icon': 'EDITMODE_HLT',
        'panel_cls_name': 'VIEW3D_PT_sms_hub_edit',
        'native_tool_ids': ('vertex_slide', 'vertex_copy', 'connect', 'mesh_split', 'mesh_align_preset'),
        'sort_key': -60,
    },
    {
        'id': 'delete_cleanup_hub',
        'label_en': 'Delete and Cleanup',
        'label_ja': '削除と整理',
        'description_en': 'Compact access to direct delete and model cleanup commands that execute only from explicit user actions.',
        'description_ja': '直接削除とモデル整理をまとめたクリック起動コマンドの簡易アクセスです。明示的にボタンを押した時だけ実行します。',
        'category': 'cleanup_organize',
        'runtime_group': 'click_only',
        'icon': 'TRASH',
        'panel_cls_name': 'VIEW3D_PT_sms_hub_cleanup',
        'native_tool_ids': ('direct_delete', 'model_organized'),
        'sort_key': -50,
    },
    {
        'id': 'hard_surface_hub',
        'label_en': 'Hard Surface Modeling',
        'label_ja': 'ハードサーフェス',
        'description_en': 'Compact access to crease, weighted-normal, and merge/snap helpers. Commands run only when clicked unless the listed persistent tool is enabled separately.',
        'description_ja': 'クリース、重み付き法線、マージ/スナップ補助をまとめた簡易アクセスです。常時機能として個別に有効化される機能以外は、クリック時だけ処理します。',
        'category': 'hard_surface_shading',
        'runtime_group': 'click_only',
        'icon': 'MOD_BEVEL',
        'panel_cls_name': 'VIEW3D_PT_sms_hub_surface',
        'native_tool_ids': ('crease_preset', 'apply_weighted_normal', 'toggle_auto_merge_snap'),
        'sort_key': -40,
    },
    {
        'id': 'sketch_retopo_hub',
        'label_en': 'Sketch and Retopo',
        'label_ja': 'スケッチとリトポ',
        'description_en': 'Compact access to sketch conversion and retopo helpers. These controls run from explicit clicks or modal starts.',
        'description_ja': 'スケッチ変換とリトポ補助をまとめた簡易アクセスです。ボタン操作またはモーダル開始時に処理します。',
        'category': 'sketch_curve',
        'runtime_group': 'click_only',
        'icon': 'MESH_GRID',
        'panel_cls_name': 'VIEW3D_PT_sms_hub_sketch',
        'native_tool_ids': ('sketch_tools', 'quad_strip_draw'),
        'sort_key': -30,
    },
    {
        'id': 'all_commands',
        'label_en': 'Command Browser',
        'label_ja': 'コマンドブラウザー',
        'description_en': 'Command browser for menus and operators discovered from the bundled tools. Use it when you need a direct command button.',
        'description_ja': '同梱ツールから検出したメニューとオペレーターのコマンドブラウザーです。直接コマンドボタンが必要な時に使います。',
        'category': 'other_tools',
        'runtime_group': 'click_only',
        'icon': 'TOOL_SETTINGS',
        'panel_cls_name': 'VIEW3D_PT_sms_all_commands',
        'native_tool_ids': ('vertex_slide', 'vertex_copy', 'connect', 'mesh_split', 'mesh_align_preset', 'direct_delete', 'model_organized', 'crease_preset', 'apply_weighted_normal', 'toggle_auto_merge_snap', 'sketch_tools', 'quad_strip_draw', 'modeling_toolset_tools'),
        'sort_key': -20,
    },
    {
        'id': 'modifier_companion',
        'label_en': 'Modifier Companion',
        'label_ja': 'モディファイア補助',
        'description_en': 'Companion helpers shared with Smart Modifier. These are explicit command buttons, not background services.',
        'description_ja': 'Smart Modifier と連携する補助ツール群です。常駐処理ではなく、明示的に押したコマンドだけ実行します。',
        'category': 'other_tools',
        'runtime_group': 'click_only',
        'icon': 'MODIFIER',
        'panel_cls_name': 'VIEW3D_PT_sms_modifier_companion_tools',
        'native_tool_ids': tuple(),
        'sort_key': -10,
    },
)


# These are workflow hub containers, not independent tools.  Keeping them as
# top-level tool entries duplicated the same native tools that are already
# listed individually below.  They now function as category/group structure only.
_SMS_AGGREGATE_SUITE_PANEL_ITEM_IDS = {
    'edit_transfer_hub',
    'delete_cleanup_hub',
    'hard_surface_hub',
    'sketch_retopo_hub',
}


def _sms_native_tool_has_persistent_load(tool_id: str) -> bool:
    return str(tool_id or '').strip() in _SMS_PERSISTENT_NATIVE_TOOL_IDS


def _sms_integrated_tool_has_persistent_load(alias: str) -> bool:
    return str(alias or '').strip() in _SMS_PERSISTENT_INTEGRATED_ALIASES


def _sms_spec_has_persistent_load(spec) -> bool:
    """Return whether an Always-on spec owns genuine resident runtime."""
    spec = dict(spec or {})
    kind = str(spec.get('kind') or '').strip()
    if kind == 'native':
        return _sms_native_tool_has_persistent_load(str(spec.get('tool_id') or '').strip())
    if kind == 'integrated':
        return _sms_integrated_tool_has_persistent_load(str(spec.get('alias') or '').strip())
    return str(spec.get('runtime_group') or '').strip() == 'persistent'


def _sms_item_runtime_group(item) -> str:
    explicit = str((item or {}).get('runtime_group') or '').strip()
    if explicit in {'persistent', 'click_only'}:
        return explicit
    kind = str((item or {}).get('kind') or '').strip()
    if kind == 'native':
        tool_id = str(((item or {}).get('meta') or {}).get('tool_id') or '').strip()
        return 'persistent' if _sms_native_tool_has_persistent_load(tool_id) else 'click_only'
    if kind == 'integrated':
        alias = str(((item or {}).get('spec') or {}).get('alias') or '').strip()
        return 'persistent' if _sms_integrated_tool_has_persistent_load(alias) else 'click_only'
    return 'click_only'


def _sms_integrated_enable_prop(alias: str) -> str:
    alias = str(alias or '').strip()
    if not alias or not _sms_integrated_tool_has_persistent_load(alias):
        return ''
    safe = ''.join(ch if ch.isalnum() or ch == '_' else '_' for ch in alias)
    return f'enable_tool_{safe}'


def _sms_integrated_enabled_from_prefs(context, alias: str, default: bool = False) -> bool:
    alias = str(alias or '').strip()
    if not _sms_integrated_tool_has_persistent_load(alias):
        return True
    prop_name = _sms_integrated_enable_prop(alias)
    prefs = _sms_get_suite_prefs(context)
    if not prop_name:
        return bool(default)
    return _sms_persistent_toggle_state_get(prop_name, context=context, prefs=prefs, default=default)


def _sms_set_integrated_runtime_features(alias: str, enabled: bool) -> None:
    alias = str(alias or '').strip()
    if not alias:
        return
    # Keep the runtime state authoritative even when registration captured no
    # action for a kind (for example Tissue had no Animatable object yet). This
    # lets later object-setting updates consult the centralized master without
    # manufacturing a handler while OFF.
    try:
        _sms_seed_runtime_feature_state(alias, bool(enabled))
    except Exception:
        pass
    try:
        from . import feature_toggle as _sms_feature_runtime
    except Exception:
        return
    try:
        entries = tuple(_sms_feature_runtime.feature_entries(alias) or ())
    except Exception:
        entries = ()
    for entry in entries:
        key = str((entry or {}).get('key') or '').strip()
        if not key:
            continue
        try:
            setter = getattr(_sms_feature_runtime, 'set_feature_enabled_runtime', None) or getattr(_sms_feature_runtime, 'set_feature_enabled', None)
            if callable(setter):
                setter(alias, key, bool(enabled))
        except Exception:
            pass
    if alias == 'key_operators_toolkit':
        # This operator owns three application handlers.  They are normally
        # captured by ``feature_toggle`` while the integrated package is
        # registered, but Blender can invoke the class-level register callback
        # again while reconstructing RNA after an Extension disable/enable
        # cycle.  Reconcile the live functions themselves so a stale capture
        # record can never leave depsgraph/undo/redo work behind while the
        # canonical Key Operation Tools switch is OFF.
        try:
            _module_name = f'{__package__}.key_operators_toolkit.fix_maya_pivot.operators.none_live_booleans'
            _none_live = sys.modules.get(_module_name)
            # Enabling follows a successful integrated-tool load, so the module
            # should already exist.  Disabling must never import the full Key
            # Operation Tools package merely to confirm that it is off.
            cls = getattr(_none_live, 'ENTERING_TRANSFORM_OT_None_Live_Booleans', None) if _none_live is not None else None
            callback = getattr(cls, 'register' if enabled else 'unregister', None) if cls is not None else None
            if callable(callback):
                callback()
        except Exception:
            pass
    if alias == 'tissue':
        # Reaction-diffusion ``run`` is object-owned artistic state, while the
        # frame-change service is controlled exclusively by the centralized
        # Tissue Always-on switch.  Reconcile both handlers explicitly because
        # an object value may be restored after module registration and thus
        # outside the generic registration-capture window.
        try:
            from .tissue import weight_reaction_diffusion as _weight_rd
            from .tissue import texture_reaction_diffusion as _texture_rd
            handlers = bpy.app.handlers.frame_change_post
            for fn in (_weight_rd.reaction_diffusion_scene, _texture_rd.tex_rd_scene):
                while fn in handlers:
                    handlers.remove(fn)
            if enabled:
                has_weight = False
                has_texture = False
                for scene in tuple(getattr(bpy.data, 'scenes', ()) or ()):
                    for obj in tuple(getattr(scene, 'objects', ()) or ()):
                        has_weight = has_weight or bool(getattr(getattr(obj, 'reaction_diffusion_settings', None), 'run', False))
                        has_texture = has_texture or bool(getattr(getattr(obj, 'tex_reaction_diffusion_settings', None), 'run', False))
                if has_weight and _weight_rd.reaction_diffusion_scene not in handlers:
                    handlers.append(_weight_rd.reaction_diffusion_scene)
                if has_texture and _texture_rd.tex_rd_scene not in handlers:
                    handlers.append(_texture_rd.tex_rd_scene)
        except Exception:
            pass
        # Tissue's per-object ``Animatable`` property can be restored after
        # registration, outside the generic capture window.  Keep the property
        # value, but attach its frame-change callback only while the centralized
        # Tissue Always-on switch is enabled.
        try:
            from .tissue import tissue_properties as _tissue_props
            remove = getattr(_tissue_props, 'remove_tissue_handler', None)
            sync = getattr(_tissue_props, 'set_tissue_handler', None)
            if callable(remove):
                remove()
            if enabled and callable(sync):
                sync(None, getattr(bpy, 'context', None))
        except Exception:
            pass


def _sms_seed_runtime_feature_state(alias: str, enabled: bool) -> None:
    """Seed captured runtime feature states before a tool registers.

    The capture layer checks these saved states while register() is running.
    Seeding them first keeps enabled toggles active during registration and
    keeps disabled toggles from adding handlers, timers, keymaps, msgbus
    subscriptions, or draw handlers even when the settings UI is opened.
    """
    alias = str(alias or '').strip()
    if not alias:
        return
    try:
        from . import feature_toggle as _sms_feature_runtime
    except Exception:
        return
    for key in ('handlers', 'timers', 'msgbus', 'keymaps', 'draw_handlers'):
        try:
            setter = getattr(_sms_feature_runtime, 'set_feature_enabled_runtime', None) or getattr(_sms_feature_runtime, 'set_feature_enabled', None)
            if callable(setter):
                setter(alias, key, bool(enabled))
        except Exception:
            pass



def _sms_deactivate_known_native_background_hooks(tool_id: str) -> None:
    """Remove passive native hooks when a tool is not running as always-on."""
    tool_id = str(tool_id or '').strip()
    if not tool_id:
        return
    meta = _sms_native_tool_meta(tool_id) or {}
    module_path = str(meta.get('module_path') or '').strip().lstrip('.')
    package = str(__package__ or '').strip()
    candidate_names = []
    if module_path:
        if package:
            candidate_names.append(f'{package}.{module_path}')
        candidate_names.append(f'smart_modeling_suite.{module_path}')
        candidate_names.append(module_path)
    modules = []
    try:
        module = _sms_native_module_from_meta(meta, require_loaded=False) if meta else None
        if isinstance(module, types.ModuleType):
            modules.append(module)
    except Exception:
        pass
    for name in candidate_names:
        try:
            mod = sys.modules.get(name)
        except Exception:
            mod = None
        if isinstance(mod, types.ModuleType) and mod not in modules:
            modules.append(mod)

    def _remove_from(owner, fn) -> None:
        if owner is None or not callable(fn):
            return
        remover = getattr(owner, 'remove', None)
        if not callable(remover):
            return
        try:
            remover(fn)
        except Exception:
            pass

    try:
        if tool_id == 'apply_weighted_normal':
            owner = getattr(bpy.types, 'VIEW3D_MT_edit_mesh_normals', None)
            for mod in modules:
                disabled = False
                disable_fn = getattr(mod, 'disable_menu_integration', None)
                if callable(disable_fn):
                    try:
                        disable_fn()
                        disabled = True
                    except Exception:
                        disabled = False
                if not disabled:
                    _remove_from(owner, getattr(mod, 'menu_func', None))
                    try:
                        setattr(mod, '_menu_appended', False)
                    except Exception:
                        pass
        elif tool_id == 'toggle_auto_merge_snap':
            for mod in modules:
                _remove_from(getattr(bpy.types, 'VIEW3D_HT_header', None), getattr(mod, 'tams_draw_header', None))
                _remove_from(getattr(bpy.types, 'STATUSBAR_HT_header', None), getattr(mod, 'tams_draw_statusbar', None))
                for attr in ('_header_appended', '_status_appended'):
                    try:
                        setattr(mod, attr, False)
                    except Exception:
                        pass
        elif tool_id == 'direct_delete':
            for mod in modules:
                preview = getattr(mod, 'preview', None)
                remove_handler = getattr(preview, 'remove_handler', None) if preview is not None else None
                if callable(remove_handler):
                    try:
                        remove_handler()
                    except Exception:
                        pass
                keymap_mod = getattr(mod, 'keymap', None)
                remove_keymaps = getattr(keymap_mod, 'remove_keymaps', None) if keymap_mod is not None else None
                if callable(remove_keymaps):
                    try:
                        remove_keymaps()
                    except Exception:
                        pass
                core_mod = getattr(mod, 'core', None)
                clear_pending = getattr(core_mod, 'clear_pending_delete_snapshots', None) if core_mod is not None else None
                if callable(clear_pending):
                    try:
                        clear_pending()
                    except Exception:
                        pass
        elif tool_id == 'vertex_slide':
            try:
                _sms_unregister_vertex_slide_topbar_button(remove_state_props=False)
            except Exception:
                pass
            for mod in modules:
                ops_mod = getattr(mod, 'operators', None)
                if ops_mod is None:
                    ops_mod = mod
                stop = getattr(ops_mod, '_svs_stop_timer_monitor', None)
                if callable(stop):
                    try:
                        stop()
                    except Exception:
                        pass
                reset = getattr(ops_mod, '_svs_reset_scene_toggle', None)
                if callable(reset):
                    try:
                        reset(getattr(bpy, 'context', None))
                    except Exception:
                        pass
        elif tool_id == 'vertex_copy':
            for mod in modules:
                for subname in ('core', 'extension', 'extension_lines'):
                    submod = getattr(mod, subname, None)
                    if submod is None:
                        continue
                    for fn_name in ('sync_gpu_draw_handler', 'sync_ext_draw_handler', 'sync_lines_draw_handler'):
                        fn = getattr(submod, fn_name, None)
                        if callable(fn):
                            try:
                                fn(False)
                            except Exception:
                                pass
    except Exception:
        pass


def _sms_activate_known_native_background_hooks(tool_id: str) -> None:
    tool_id = str(tool_id or '').strip()
    if not tool_id:
        return
    meta = _sms_native_tool_meta(tool_id) or {}
    module_path = str(meta.get('module_path') or '').strip().lstrip('.')
    package = str(__package__ or '').strip()
    candidate_names = []
    if module_path:
        if package:
            candidate_names.append(f'{package}.{module_path}')
        candidate_names.append(f'smart_modeling_suite.{module_path}')
        candidate_names.append(module_path)
    modules = []
    try:
        module = _sms_native_module_from_meta(meta, require_loaded=False) if meta else None
        if isinstance(module, types.ModuleType):
            modules.append(module)
    except Exception:
        pass
    for name in candidate_names:
        try:
            mod = sys.modules.get(name)
        except Exception:
            mod = None
        if isinstance(mod, types.ModuleType) and mod not in modules:
            modules.append(mod)
    try:
        if tool_id == 'vertex_slide':
            try:
                _sms_register_vertex_slide_topbar_button()
            except Exception:
                pass
        elif tool_id == 'apply_weighted_normal':
            for mod in modules:
                fn = getattr(mod, 'enable_menu_integration', None)
                if callable(fn):
                    try:
                        fn()
                        continue
                    except Exception:
                        pass
                owner = getattr(bpy.types, 'VIEW3D_MT_edit_mesh_normals', None)
                menu_func = getattr(mod, 'menu_func', None)
                if owner is not None and callable(menu_func):
                    try:
                        owner.remove(menu_func)
                    except Exception:
                        pass
                    try:
                        owner.append(menu_func)
                    except Exception:
                        pass
    except Exception:
        pass

def _sms_update_persistent_tool_runtime_from_prefs(context=None) -> None:
    """Synchronize centralized always-on switches with actual runtime state.

    Disabled entries have their captured background/runtime actions deactivated.
    User-assigned shortcuts remain callable through lightweight lazy proxies
    after startup and after the Always-on switch is turned off.  Enabled entries
    are the only case where persistent runtime functionality is requested;
    disabled entries unload their native modules and leave only proxies behind.
    """
    global _SMS_PERSISTENT_RUNTIME_SYNC_DEPTH
    if _SMS_PERSISTENT_RUNTIME_SYNC_DEPTH > 0:
        return
    context = context or getattr(bpy, 'context', None)
    prefs = _sms_get_suite_prefs(context)

    _SMS_PERSISTENT_RUNTIME_SYNC_DEPTH += 1
    try:
        for meta in _sms_tool_meta_entries():
            tool_id = str(meta.get('tool_id') or '').strip()
            if not tool_id or not _sms_native_tool_has_persistent_load(tool_id):
                continue
            prop_name = str(meta.get('toggle') or '').strip()
            enabled = _sms_persistent_toggle_state_get(prop_name, context=context, prefs=prefs, default=False) if prop_name else False
            loaded_now = _sms_native_tool_loaded(tool_id)
            if enabled:
                try:
                    _sms_seed_runtime_feature_state(tool_id, True)
                except Exception:
                    pass
                if not loaded_now:
                    try:
                        _sms_request_on_demand_load('native', tool_id, context=context)
                    except Exception:
                        try:
                            _sms_ensure_native_tool_loaded(tool_id, context=context)
                        except Exception:
                            pass
                try:
                    _sms_set_integrated_runtime_features(tool_id, True)
                except Exception:
                    pass
                try:
                    _sms_activate_known_native_background_hooks(tool_id)
                except Exception:
                    pass
            else:
                # Disabled always-on features must have no active background work.
                # The actual operator/settings classes may remain registered in a safe
                # dormant state if Blender is currently holding RNA references, but
                # handlers, timers, draw handlers, keymaps, msgbus subscriptions,
                # header/status hooks, and lazy shortcut proxies are removed.
                try:
                    # Explicitly opened operator/RNA classes are dormant and
                    # cost no background work.  Keep them materialized across
                    # scene/file restoration while removing every handler,
                    # timer, draw hook, keymap and message-bus feature owned by
                    # the disabled Always-on switch.  Closing the section or
                    # disabling the extension still unloads the module.
                    _sms_deactivate_tool_runtime('native', tool_id, context=context, unload=False)
                except Exception:
                    pass
                try:
                    _sms_register_lazy_keymap_proxies((tool_id,))
                except Exception:
                    pass
                state = _sms_native_tool_state(tool_id)
                if not _sms_native_tool_loaded(tool_id):
                    state['status'] = 'available'
                    state['error'] = ''

        # Integrated add-ons are not scanned/registered at startup unless one of
        # their explicit persistent switches is enabled or the loader is already live
        # in the current session.  This avoids importing integrated packages just to
        # discover that their always-on toggles are off.
        persistent_aliases = tuple(globals().get('_SMS_PERSISTENT_INTEGRATED_ALIASES', ()))
        enabled_integrated = {alias for alias in persistent_aliases if _sms_integrated_enabled_from_prefs(context, alias, False)}
        _sms_loader = None
        if enabled_integrated or f'{__package__}.loader' in sys.modules:
            try:
                from . import loader as _sms_loader
            except Exception:
                _sms_loader = None
        if _sms_loader is not None:
            try:
                records = list(_sms_loader.get_records() or [])
            except Exception:
                records = []
            if enabled_integrated and not records:
                try:
                    _sms_loader.register_all()
                    records = list(_sms_loader.get_records() or [])
                except Exception:
                    records = []
            for alias in persistent_aliases:
                enabled = alias in enabled_integrated
                try:
                    record = _sms_loader.get_record(alias) or {}
                except Exception:
                    record = {}
                if enabled:
                    try:
                        _sms_seed_runtime_feature_state(alias, True)
                    except Exception:
                        pass
                    if str(record.get('status') or '').strip().lower() != 'loaded':
                        try:
                            _sms_request_on_demand_load('integrated', alias, context=context)
                        except Exception:
                            try:
                                _sms_ensure_integrated_tool_loaded(alias, context=context)
                            except Exception:
                                pass
                    try:
                        _sms_set_integrated_runtime_features(alias, True)
                    except Exception:
                        pass
                else:
                    if record and (str(record.get('status') or '').strip().lower() == 'loaded' or record.get('module') is not None):
                        try:
                            _sms_set_integrated_runtime_features(alias, False)
                        except Exception:
                            pass
                        # Keep explicitly opened lazy RNA registered in a
                        # dormant state.  Unloading here erased Key Ops/Tissue
                        # N-panel roots again during the delayed load/scene
                        # restore pass, so their canonical settings could not
                        # be read or restored.  Captured handlers, timers,
                        # msgbus, draw handlers, and keymaps are already removed
                        # by the feature synchronizer above; registered classes
                        # themselves add no idle work and are torn down at the
                        # extension lifecycle boundary.
        # Archimesh's hint overlay is a resident draw handler but its owning
        # tool remains otherwise click-only, so synchronize its dedicated
        # canonical proxy separately from whole-tool persistent aliases.
        try:
            _sms_set_archimesh_hint_overlay(
                _sms_persistent_toggle_state_get(
                    'enable_archimesh_hint_overlay',
                    context=context,
                    prefs=prefs,
                    default=False,
                ),
                context,
            )
        except Exception:
            pass
    finally:
        _SMS_PERSISTENT_RUNTIME_SYNC_DEPTH = max(0, _SMS_PERSISTENT_RUNTIME_SYNC_DEPTH - 1)


_SMS_NATIVE_SHOW_PROP_MAP = {
    'vertex_copy': 'ui_show_vertex_copy',
    'vertex_slide': 'ui_show_vertex_slide',
    'connect': 'ui_show_connect',
    'direct_delete': 'ui_show_direct_delete',
    'model_organized': 'ui_show_model_organized',
    'mesh_split': 'ui_show_mesh_split',
    'mesh_align_preset': 'ui_show_mesh_align_preset',
    'crease_preset': 'ui_show_crease_preset',
    'toggle_auto_merge_snap': 'ui_show_toggle_auto_merge_snap',
    'apply_weighted_normal': 'ui_show_apply_weighted_normal',
    'sketch_tools': 'ui_show_sketch_tools',
    'quad_strip_draw': 'ui_show_quad_strip_draw',
    'modeling_toolset_tools': 'ui_show_modeling_toolset_tools',
}


_SMS_INTEGRATED_NON_TOOL_ALIASES = {
    # Native tool implemented in smart_modeling_suite.mesh_split; do not also
    # expose the same package as a separate integrated tool.
    'mesh_split',
    '__pycache__',
    'icon',
    'icons',
    'image',
    'images',
    'resource',
    'resources',
    'asset',
    'assets',
    'settings',
    'setting',
    'user_data',
    'userdata',
    'data',
    'storage',
    'cache',
    'caches',
    'runtime',
    'tmp',
    'temp',
    'log',
    'logs',
    'backup',
    'backups',
    'preset',
    'presets',
    'locale',
    'locales',
    'translation',
    'translations',
    'doc',
    'docs',
    'documentation',
}


def _sms_is_visible_integrated_spec(spec) -> bool:
    if not isinstance(spec, dict):
        return False
    if not bool(spec.get('load', True)):
        return False
    alias = str(spec.get('alias') or '').strip()
    if not alias:
        return False
    if alias.lower() in _SMS_INTEGRATED_NON_TOOL_ALIASES:
        return False
    for key in ('source_alias', 'outer_zip'):
        value = str(spec.get(key) or '').strip()
        if value.lower().endswith('.zip'):
            value = value[:-4]
        if value and value.lower() in _SMS_INTEGRATED_NON_TOOL_ALIASES:
            return False
    src_dir = str(spec.get('src_dir') or spec.get('vendor_dir') or '').strip()
    if src_dir:
        try:
            import os as _sms_os
            if _sms_os.path.basename(src_dir).lower() in _SMS_INTEGRATED_NON_TOOL_ALIASES:
                return False
        except Exception:
            pass
    if not str(spec.get('init_relpath') or '').strip():
        return False
    return True


def _sms_add_dynamic_preference_props():
    annotations = dict(getattr(SMS_NPanelSettings, '__annotations__', {}) or {})
    changed = False

    def _add_bool(name, label, description, default=False, update=None):
        nonlocal changed
        if name in annotations:
            return
        kwargs = dict(name=label, description=description, default=default)
        if update is not None:
            kwargs['update'] = update
        annotations[name] = BoolProperty(**kwargs)
        changed = True

    _add_bool(
        'ui_show_always_on_toggles',
        'Always-on Toggles',
        'Expand or collapse the centralized startup/runtime switch group at the top of the Smart Modeling N-panel.',
        False,
        update=_sms_update_ui_state,
    )

    _add_bool(
        'ui_show_runtime_group_persistent',
        'Show Always-on Toggles',
        'Compatibility state for older layouts. Always-on switches are now centralized at the top of the Smart Modeling N-panel.',
        True,
        update=_sms_update_ui_state,
    )
    _add_bool(
        'ui_show_runtime_group_click_only',
        'Show Click-only Commands',
        'Expand or collapse the group for tools that run only after a button, popup, or modal command is started.',
        True,
        update=_sms_update_ui_state,
    )

    for category in _SMS_WORKFLOW_CATEGORY_DEFS:
        cat_id = str(category.get('id') or '').strip()
        if not cat_id:
            continue
        label = str(category.get('label_en') or cat_id.replace('_', ' ').title())
        _add_bool(
            f'ui_show_category_{cat_id}',
            f'Show {label}',
            f'Expand or collapse the {label} category inside the suite UI.',
            True,
            update=_sms_update_ui_state,
        )

    for meta in _SMS_NATIVE_TOOL_META:
        tool_id = str(meta.get('tool_id') or '').strip()
        if not tool_id:
            continue
        label = str(meta.get('label') or tool_id.replace('_', ' ').title())
        show_prop = _SMS_NATIVE_SHOW_PROP_MAP.get(tool_id, f'ui_show_{tool_id}')
        _add_bool(
            show_prop,
            f'Show {label}',
            f'Expand or collapse the {label} section inside the Smart Modeling N-panel.',
            False,
            update=_sms_update_ui_state,
        )
        enable_prop = str(meta.get('toggle') or '').strip()
        if enable_prop:
            _add_bool(
                enable_prop,
                f'Enable {label}',
                f'When enabled, {label} starts when Blender starts. When disabled, its UI remains visible but the implementation loads only when a command is executed, with all background runtime kept inactive.',
                False,
                update=_update_suite_toggles if _sms_native_tool_has_persistent_load(tool_id) else _update_click_only_tool_setting,
            )

    for item in _SMS_SUITE_PANEL_ITEMS:
        item_id = str(item.get('id') or '').strip()
        if not item_id:
            continue
        if item_id in globals().get('_SMS_AGGREGATE_SUITE_PANEL_ITEM_IDS', set()):
            continue
        label = str(item.get('label_en') or item_id.replace('_', ' ').title())
        _add_bool(
            f'ui_show_suite_panel_{item_id}',
            f'Show {label}',
            f'Expand or collapse the {label} compact command section inside the Smart Modeling N-panel.',
            False,
            update=_sms_update_ui_state,
        )
        suite_enable_prop = str(item.get('enable_prop') or '').strip()
        if suite_enable_prop:
            _add_bool(
                suite_enable_prop,
                f'Enable {label}',
                f'When enabled, {label} is prepared at Blender startup. When disabled, its UI remains visible and the implementation starts only from an explicit command.',
                False,
                update=_update_click_only_tool_setting,
            )
        if item_id == 'modifier_companion':
            _add_bool(
                'ui_activate_suite_panel_modifier_companion',
                'Start Modifier Companion',
                'Load Modifier Companion command buttons only after you explicitly start this click-start section.',
                False,
                update=_sms_update_ui_state,
            )

    try:
        from . import registry as _sms_registry
        visible_spec = getattr(_sms_registry, 'is_visible_addon_spec', None)
        for spec in _sms_registry.build_specs(force=False):
            registry_visible = bool(visible_spec(spec)) if callable(visible_spec) else True
            if not registry_visible or not _sms_is_visible_integrated_spec(spec):
                continue
            alias = str(spec.get('alias') or '').strip()
            if not alias:
                continue
            display_name = str(spec.get('display_name') or alias.replace('_', ' ').title())
            show_name = f'Show {display_name}'
            show_description = f'Expand or collapse the {display_name} section inside the Smart Modeling N-panel.'
            _add_bool(
                f'ui_show_tool_{alias}',
                show_name,
                show_description,
                False,
                update=_sms_update_ui_state,
            )
            enable_prop = _sms_integrated_enable_prop(alias)
            if enable_prop:
                description = {
                    'key_operators_toolkit': 'Controls Key Ops Toolkit handlers, menu hooks, and tablet / outliner background integration. Key Ops shortcuts remain manual-only and are never installed automatically.',
                    'curve_tools': 'Controls Curve Tools file export menu entries and curve/object context-menu hooks. Keep this disabled unless you want those curve menus to stay available outside this N-panel.',
                    'tissue': 'Controls Tissue frame-change handlers used by animated tessellation and reaction-diffusion workflows. Keep this disabled unless you need automatic frame updates.',
                }.get(
                    alias,
                    f'Allow or block persistent runtime features for {display_name}. Turn this off when you do not want this tool to keep background handlers, timers, keymaps, or automatic monitors active.',
                )
                enable_name = f'Enable {display_name}'
                _add_bool(
                    enable_prop,
                    enable_name,
                    description,
                    False,
                    update=_update_suite_toggles if _sms_integrated_tool_has_persistent_load(alias) else _update_click_only_tool_setting,
                )
    except Exception:
        pass

    if changed:
        SMS_NPanelSettings.__annotations__ = annotations


def _sms_localize_editable_ui_string_value(data, prop_name: str, prop=None, context=None) -> None:
    if _sms_is_panel_draw_active():
        return
    # Do not translate arbitrary user-authored text.  Only collapse values that
    # are explicitly stored as English / Japanese UI strings, and skip file/path
    # fields where a slash is part of the data format.  Most importantly, do not
    # probe unknown RNA / operator-property objects here.  Blender 5.1 Windows can
    # crash in WM_operator_properties_create_ptr / RNA_path_resolve when a panel
    # draw reads a transient operator or stale PointerProperty.  This helper is
    # optional UI cleanup, so it is deliberately limited to statically declared
    # StringProperty entries on current Smart Modeling PropertyGroups.
    try:
        if data is None or not prop_name or not _sms_rna_data_is_current(data):
            return
        prop_def = prop or _sms_static_property_def(data, prop_name)
        kind = _sms_prop_deferred_kind(prop_def)
        if kind != 'StringProperty':
            return
        try:
            cls = type(data)
            module_name = str(getattr(cls, '__module__', '') or '')
        except Exception:
            module_name = ''
        if 'smart_modeling_suite' not in module_name and not module_name.startswith(str(__package__ or '')):
            return
        try:
            keywords = getattr(prop_def, 'keywords', {}) or {}
        except Exception:
            keywords = {}
        subtype = str(keywords.get('subtype') or '')
        if subtype in {'FILE_PATH', 'DIR_PATH', 'FILE_NAME', 'BYTE_STRING'}:
            return
        default_value = str(keywords.get('default') or '')
        if '/' not in default_value and '／' not in default_value:
            return
        value = _sms_safe_get_rna_attr(data, prop_name, None)
        if not isinstance(value, str) or not value:
            return
        en, ja, changed = _language.split_bilingual_text(value)
        if not changed:
            return
        localized = _pick_lang(en, ja, context)
        if localized and localized != value:
            _sms_safe_set_rna_attr(data, prop_name, localized)
    except Exception:
        pass


def _sms_rna_prop_is_dropdown(data, prop_name) -> bool:
    try:
        prop = data.bl_rna.properties.get(prop_name)
        return prop is not None and (prop.type == 'STRING' or (prop.type == 'ENUM' and not prop.is_enum_flag))
    except Exception:
        return False


def _sms_own_line_for_dropdown(layout, data, prop_name):
    # A dropdown keeps its name readable at the default sidebar width by taking
    # a line of its own.
    if not _sms_rna_prop_is_dropdown(data, prop_name):
        return (layout,)
    column = layout.column(align=True)
    column.label(text=data.bl_rna.properties[prop_name].name)
    return (column,)


def _sms_draw_rna_properties(layout, data, *, exclude=None, namespace=None):
    """Draw already-materialized RNA properties without mutating or persisting them."""
    del namespace
    if data is None or not _sms_rna_data_is_current(data):
        return 0
    exclude = set(exclude or ())
    drawn = 0
    for pid in _sms_iter_rna_setting_ids(data, exclude=exclude):
        if not pid:
            continue
        try:
            if _sms_safe_layout_prop(*_sms_own_line_for_dropdown(layout, data, pid), data, pid, **({'text': ''} if _sms_rna_prop_is_dropdown(data, pid) else {})):
                drawn += 1
        except Exception:
            continue
    return drawn


def _sms_button_columns(labels) -> int:
    # Two columns only when every name is readable at the current width.
    from . import help as _sms_help
    try:
        context = bpy.context
        scale = float(context.preferences.system.ui_scale) or 1.0
        limit = (float(context.region.width) - 60.0 * scale) / 2.0 - 34.0 * scale
        for label in labels:
            if _sms_help._sms_text_pixel_width(bpy.app.translations.pgettext_iface(str(label or '')), context) > limit:
                return 1
    except Exception:
        return 1
    return 2


def _sms_draw_menu_buttons(layout, menu_entries):
    if not menu_entries:
        return 0
    drawn = 0
    flow = layout.grid_flow(row_major=True, columns=_sms_button_columns(label for _id, label, _pie in menu_entries), even_columns=True, even_rows=False, align=True)
    for menu_id, label, is_pie in menu_entries:
        try:
            op = flow.operator('wm.call_menu_pie' if is_pie else 'wm.call_menu', text=label, icon='MENU_PANEL')
            op.name = menu_id
            drawn += 1
        except Exception:
            pass
    return drawn



def _sms_readable_operator(layout, op_id, *, text='', context=None, **kwargs):
    context = context or bpy.context
    label = _ui_text(text, context)
    try:
        import blf
        scale = float(context.preferences.system.ui_scale) or 1.0
        blf.size(0, 11 * scale)
        width = blf.dimensions(0, label)[0]
        available = max(80.0, float(context.region.width) - 108.0 * scale)
    except Exception:
        width, available = 0.0, 240.0
    if width > available:
        _sms_label_wrapped(layout, context, label)
        label = _pick_lang('Run', '実行', context)
    return layout.operator(op_id, text=label, **kwargs)


def _sms_draw_operator_buttons(layout, operator_entries, *, max_items=12):
    if not operator_entries:
        return 0
    drawn = 0
    flow = layout.grid_flow(row_major=True, columns=_sms_button_columns(label for _id, label, _desc in list(operator_entries)[:max_items]), even_columns=True, even_rows=False, align=True)
    for op_id, label, _desc in list(operator_entries)[:max_items]:
        op_id = str(op_id or '').strip()
        if not op_id or op_id in _SMS_OPERATOR_INVOKE_DENYLIST:
            continue
        if callable(_sms_resolve_operator_callable(op_id)):
            try:
                if op_id == 'mesh.smart_vert_slide':
                    ctx_now = getattr(bpy, 'context', None)
                    wm_now = getattr(ctx_now, 'window_manager', None) if ctx_now is not None else None
                    scene_now = getattr(ctx_now, 'scene', None) if ctx_now is not None else None
                    svs_enabled = bool(getattr(wm_now, 'svs_vertex_slide_constraint_enabled', getattr(scene_now, 'svs_vertex_slide_constraint_enabled', False)))
                    _sms_readable_operator(flow, op_id, text=label, icon=_sms_command_icon(op_id, label, _desc), depress=svs_enabled)
                else:
                    if op_id in _SMS_OPERATOR_INVOKE_DEFAULT_IDS:
                        old_context = getattr(flow, 'operator_context', 'EXEC_DEFAULT')
                        try:
                            flow.operator_context = 'INVOKE_DEFAULT'
                            _sms_readable_operator(flow, op_id, text=label, icon=_sms_command_icon(op_id, label, _desc))
                        finally:
                            try:
                                flow.operator_context = old_context
                            except Exception:
                                pass
                    else:
                        _sms_readable_operator(flow, op_id, text=label, icon=_sms_command_icon(op_id, label, _desc))
                drawn += 1
            except Exception:
                row = flow.row(align=True)
                row.enabled = True
                row.label(text=label, icon='ERROR')
        else:
            row = flow.row(align=True)
            row.enabled = True
            row.label(text=label)
    return drawn



def _sms_section_header(box, prefs, show_prop, label, enable_prop, *, icon='TOOL_SETTINGS', context=None, show_toggle=True):
    expanded = bool(_sms_safe_get_rna_attr(prefs, show_prop, False)) if prefs and _sms_rna_prop_exists(prefs, show_prop) else False
    row = box.row(align=True)
    row.use_property_split = False
    row.use_property_decorate = False
    if prefs is not None and _sms_rna_prop_exists(prefs, show_prop):
        row.prop(prefs, show_prop, text='', emboss=False, icon='TRIA_DOWN' if expanded else 'TRIA_RIGHT')
    else:
        row.label(text='', icon='BLANK1')
    row.label(text=label, icon=_sms_safe_icon(icon, 'TOOL_SETTINGS'))
    if show_toggle:
        sub = row.row(align=True)
        sub.alignment = 'RIGHT'
        sub.label(text=_pick_lang('Enabled', '有効', context), icon='CHECKMARK')
    return expanded




def _sms_keymap_pref_path(km_name: str, space_type: str = '', context=None) -> str:
    km_name = str(km_name or '').strip()
    space_type = str(space_type or '').strip()
    if not km_name:
        return _pick_lang(
            'Edit > Preferences > Keymap',
            '編集 > プリファレンス > キーマップ',
            context,
        )
    item = _SMS_KEYMAP_PREF_PATHS.get(km_name)
    if item:
        return _pick_lang(item[0], item[1], context)
    return _pick_lang(
        f'Edit > Preferences > Keymap > {km_name}',
        f'編集 > プリファレンス > キーマップ > {km_name}',
        context,
    )


def _sms_keymap_property_summary(properties) -> str:
    if not properties:
        return ''
    items = []
    if isinstance(properties, dict):
        iterator = properties.items()
    else:
        iterator = properties
    try:
        for item in iterator:
            if isinstance(item, (list, tuple)) and len(item) >= 2:
                name, value = item[0], item[1]
            else:
                continue
            name = str(name or '').strip()
            if not name:
                continue
            items.append(f'{name}={value}')
    except Exception:
        return ''
    return '; '.join(items)


def _sms_shortcut_from_keymap_entry(entry) -> str:
    entry = dict(entry or {})
    shortcut = str(entry.get('shortcut') or entry.get('shortcut_en') or '').strip()
    if shortcut:
        return shortcut
    type_name = str(entry.get('type') or '').strip()
    if not type_name:
        return ''
    mods = []
    if bool(entry.get('ctrl')):
        mods.append('Ctrl')
    if bool(entry.get('shift')):
        mods.append('Shift')
    if bool(entry.get('alt')):
        mods.append('Alt')
    if bool(entry.get('oskey')):
        mods.append('OSKey')
    key_names = {
        'DEL': 'Delete',
        'BACK_SPACE': 'Backspace',
        'LEFTMOUSE': 'Left Mouse',
        'RIGHTMOUSE': 'Right Mouse',
        'MIDDLEMOUSE': 'Middle Mouse',
        'RET': 'Enter',
        'SPACE': 'Space',
        'BACK_SLASH': 'Backslash',
    }
    key = key_names.get(type_name, type_name.replace('_', ' ').title())
    value = str(entry.get('value') or 'PRESS').strip()
    suffix = '' if value in {'', 'PRESS'} else f' {value.replace("_", " ").title()}'
    return '+'.join(mods + [key + suffix]) if mods else key + suffix


def _sms_keymap_registration_id_text(entry) -> str:
    entry = dict(entry or {})
    # The copy target must stay limited to the Blender operator registration ID.
    # Extra keymap properties are shown only as non-copyable context labels.
    return str(entry.get('idname') or entry.get('operator_id') or '').strip()



def _sms_keymap_entry_label(entry, context=None) -> str:
    entry = dict(entry or {})
    en = str(entry.get('label_en') or entry.get('label') or '').strip()
    ja = str(entry.get('label_ja') or '').strip()
    if _language.is_japanese(context):
        return _ui_text(ja if ja and ja != en else en, context)
    return _ui_text(en or ja, context)


def _sms_keymap_purpose_text(entry, context=None) -> str:
    """Return a short non-copyable description of what this keymap triggers."""
    entry = dict(entry or {})
    en = str(entry.get('purpose_en') or entry.get('purpose') or entry.get('description_en') or '').strip()
    ja = str(entry.get('purpose_ja') or entry.get('description_ja') or '').strip()
    if not en:
        label_en = str(entry.get('label_en') or entry.get('label') or '').strip()
        reg_id = _sms_keymap_registration_id_text(entry)
        en = f'Run {label_en}.' if label_en else (f'Run operator {reg_id}.' if reg_id else '')
    if not ja:
        label_ja = str(entry.get('label_ja') or '').strip()
        label_en = str(entry.get('label_en') or entry.get('label') or '').strip()
        label = label_ja or label_en
        reg_id = _sms_keymap_registration_id_text(entry)
        ja = f'{label}を実行します。' if label else (f'オペレーター {reg_id} を実行します。' if reg_id else en)
    if _language.is_japanese(context):
        return _ui_text(ja if ja and ja != en else en, context)
    return _ui_text(en or ja, context)


def _sms_keymap_full_copy_text(entry, context=None) -> str:
    entry = dict(entry or {})
    label = _sms_keymap_entry_label(entry, context)
    km_name = str(entry.get('keymap') or entry.get('km_name') or '').strip()
    reg_id = _sms_keymap_registration_id_text(entry)
    shortcut = _sms_shortcut_from_keymap_entry(entry)
    props = _sms_keymap_property_summary(entry.get('properties'))
    parts = []
    if label:
        parts.append(f'Label: {label}')
    if km_name:
        parts.append(f'Keymap: {km_name}')
    if reg_id:
        parts.append(f'ID: {reg_id}')
    if shortcut:
        parts.append(f'Shortcut: {shortcut}')
    if props and props not in reg_id:
        parts.append(f'Properties: {props}')
    return ' | '.join(parts) or reg_id


def _sms_draw_registration_id_row(layout, context, prefs, prop_name: str, value: str, *, label_en: str = 'Registration ID', label_ja: str = '登録ID') -> bool:
    """Draw one compact keymap registration ID row.

    Only the registration ID itself receives a copy action.  This mirrors the
    compact Smart Workspace shortcut-ID UI and avoids exposing paths, shortcuts,
    property summaries, or full keymap lines as separate copy targets.
    """
    value = str(value or '').strip()
    prop_name = str(prop_name or '').strip()
    if not value:
        return False
    # The name stays readable at the default width; the identifier itself is only copied, never shown.
    row = layout.row(align=True)
    row.label(text=_pick_lang(label_en, label_ja, context))
    copy_value = value
    if prefs is not None and prop_name and _sms_rna_prop_exists(prefs, prop_name):
        try:
            copy_value = str(_sms_safe_get_rna_attr(prefs, prop_name, '') or '').strip() or value
        except Exception:
            copy_value = value
    op = row.operator(
        'smart_modeling_suite.copy_to_clipboard',
        text='',
        icon=_sms_safe_icon('COPYDOWN', 'COPYDOWN'),
    )
    op.text = copy_value
    op.report_label = copy_value
    return True

def _sms_normalize_keymap_entry(entry) -> dict:
    data = dict(entry or {})
    if 'keymap' not in data and 'km_name' in data:
        data['keymap'] = data.get('km_name')
    if 'idname' not in data and 'operator_id' in data:
        data['idname'] = data.get('operator_id')
    if not str(data.get('label_en') or data.get('label') or '').strip():
        label = str(data.get('idname') or data.get('operator_id') or data.get('keymap') or 'Keymap Item').strip()
        data['label_en'] = label
        data['label_ja'] = label
    return data


def _sms_dedupe_keymap_entries(entries) -> list[dict]:
    out = []
    seen = set()
    for raw in tuple(entries or ()):  # pragma: no branch
        entry = _sms_normalize_keymap_entry(raw)
        idname = str(entry.get('idname') or '').strip()
        if not idname:
            continue
        key = (
            str(entry.get('keymap') or '').strip(),
            idname,
            str(entry.get('type') or '').strip(),
            str(entry.get('value') or '').strip(),
            bool(entry.get('ctrl')),
            bool(entry.get('shift')),
            bool(entry.get('alt')),
            bool(entry.get('oskey')),
            _sms_keymap_property_summary(entry.get('properties')),
        )
        if key in seen:
            continue
        seen.add(key)
        out.append(entry)
    return out



def _sms_label_wrapped(layout, context, text) -> None:
    # Wraps by measured width so that no line is cut off at the panel edge.
    from . import help as _sms_help
    try:
        scale = float(context.preferences.system.ui_scale) or 1.0
        max_pixels = max(120.0, float(context.region.width) - 108.0 * scale)
    except Exception:
        max_pixels = 240.0
    for line in _sms_help._sms_wrap_help_text(text, context=context, max_pixels=max_pixels, min_pixels=120.0):
        if line:
            layout.label(text=line, translate=False)


def _sms_draw_keymap_reference(layout, context, entries, *, prefs=None) -> int:
    entries = _sms_dedupe_keymap_entries(entries)
    if not entries:
        return 0
    root = layout.box()
    root.label(text=_pick_lang('Manual Keymap Registration', '手動キーマップ登録', context), icon=_sms_safe_icon('KEYINGSET', 'KEYFRAME'))
    drawn = 0
    for entry in entries:
        label = _sms_keymap_entry_label(entry, context)
        reg_id = _sms_keymap_registration_id_text(entry)
        if not reg_id:
            continue
        item_box = root.box()
        item_box.label(text=label or reg_id, icon='DOT')
        purpose = _sms_keymap_purpose_text(entry, context)
        if purpose:
            purpose_col = item_box.column(align=True)
            purpose_col.label(text=_pick_lang('Purpose', '用途', context))
            _sms_label_wrapped(purpose_col, context, purpose)
        km_name = str(entry.get('keymap') or entry.get('km_name') or '').strip()
        space_type = str(entry.get('space_type') or '').strip()
        location = _sms_keymap_pref_path(km_name, space_type, context)
        loc_col = item_box.column(align=True)
        loc_col.label(text=_pick_lang('Registration Location', '登録場所', context), icon='FILE_FOLDER')
        _sms_label_wrapped(loc_col, context, location)
        if _sms_draw_registration_id_row(item_box, context, prefs, str(entry.get('id_prop') or ''), reg_id):
            drawn += 1
    return drawn

def _sms_native_keymap_entries(tool_id: str) -> tuple[dict, ...]:
    return tuple(_SMS_NATIVE_KEYMAP_INFO.get(str(tool_id or '').strip(), ()))


def _sms_draw_native_keymap_reference(layout, context, prefs, tool_id: str) -> int:
    return _sms_draw_keymap_reference(layout, context, _sms_native_keymap_entries(tool_id), prefs=prefs)


def _sms_build_keyops_static_keymap_entries(context=None) -> list[dict]:
    global _SMS_KEYOPS_STATIC_KEYMAP_CACHE
    if _SMS_KEYOPS_STATIC_KEYMAP_CACHE is not None:
        return [dict(entry) for entry in _SMS_KEYOPS_STATIC_KEYMAP_CACHE]
    entries = []
    raw_map = {}
    try:
        keymap_file = Path(__file__).resolve().parent / 'key_operators_toolkit' / 'fix_maya_pivot' / 'classes_keymap_items.py'
        source = keymap_file.read_text(encoding='utf-8', errors='ignore')
        tree = ast.parse(source)
        for node in getattr(tree, 'body', ()):
            if not isinstance(node, ast.Assign):
                continue
            if not any(isinstance(target, ast.Name) and target.id == 'keymap_items' for target in node.targets):
                continue
            value = ast.literal_eval(node.value)
            if isinstance(value, dict):
                raw_map = value
            break
    except Exception:
        raw_map = {}
    for _group_key, values in raw_map.items():
        for item in tuple(values or ()):  # pragma: no branch
            if not isinstance(item, dict):
                continue
            _label = str(item.get('label') or item.get('idname') or 'Key Ops Shortcut')
            entry = {
                'label_en': _label,
                'label_ja': _language._translation_for_ja(_label.strip()),
                'purpose_en': 'Run the Key Ops Toolkit shortcut: ' + _label + '.',
                'purpose_ja': 'キー操作ツールのショートカット「' + _language._translation_for_ja(_label.strip()) + '」を実行します。',
                'idname': str(item.get('idname') or ''),
                'keymap': str(item.get('keymap') or ''),
                'space_type': str(item.get('space_type') or 'EMPTY'),
                'type': str(item.get('type') or ''),
                'value': str(item.get('value') or 'PRESS'),
                'ctrl': bool(item.get('ctrl', False)),
                'shift': bool(item.get('shift', False)),
                'alt': bool(item.get('alt', False)),
                'oskey': bool(item.get('oskey', False)),
                'repeat': bool(item.get('repeat', False)),
                'properties': item.get('properties') or (),
            }
            if entry['idname'] and entry['keymap']:
                entries.append(entry)
    entries.extend([
        {'label_en': 'Key Ops Outliner Click', 'label_ja': 'Key Ops アウトライナークリック', 'purpose_en': 'Run Key Ops outliner click handling.', 'purpose_ja': 'アウトライナー上の Key Ops クリック処理を実行します。', 'idname': 'keyops.outliner_click', 'keymap': 'Outliner', 'space_type': 'OUTLINER', 'type': 'LEFTMOUSE', 'value': 'CLICK'},
        {'label_en': 'Key Ops Outliner Right Click', 'label_ja': 'Key Ops アウトライナー右クリック', 'purpose_en': 'Run Key Ops right-click handling in the Outliner.', 'purpose_ja': 'アウトライナー上の Key Ops 右クリック処理を実行します。', 'idname': 'keyops.outliner_click', 'keymap': 'Outliner', 'space_type': 'OUTLINER', 'type': 'RIGHTMOUSE', 'value': 'CLICK'},
        {'label_en': 'Key Ops Outliner Shift Click', 'label_ja': 'Key Ops アウトライナーShiftクリック', 'purpose_en': 'Run Key Ops Shift-click selection handling in the Outliner.', 'purpose_ja': 'アウトライナー上の Key Ops Shiftクリック選択処理を実行します。', 'idname': 'keyops.outliner_click', 'keymap': 'Outliner', 'space_type': 'OUTLINER', 'type': 'LEFTMOUSE', 'value': 'CLICK', 'shift': True},
        {'label_en': 'Key Ops Outliner Ctrl Click', 'label_ja': 'Key Ops アウトライナーCtrlクリック', 'purpose_en': 'Run Key Ops Ctrl-click selection handling in the Outliner.', 'purpose_ja': 'アウトライナー上の Key Ops Ctrlクリック選択処理を実行します。', 'idname': 'keyops.outliner_click', 'keymap': 'Outliner', 'space_type': 'OUTLINER', 'type': 'LEFTMOUSE', 'value': 'CLICK', 'ctrl': True},
        {'label_en': 'Key Ops Outliner Ctrl Shift Click', 'label_ja': 'Key Ops アウトライナーCtrl+Shiftクリック', 'purpose_en': 'Run Key Ops Ctrl+Shift-click selection handling in the Outliner.', 'purpose_ja': 'アウトライナー上の Key Ops Ctrl+Shiftクリック選択処理を実行します。', 'idname': 'keyops.outliner_click', 'keymap': 'Outliner', 'space_type': 'OUTLINER', 'type': 'LEFTMOUSE', 'value': 'CLICK', 'ctrl': True, 'shift': True},
        {'label_en': 'Key Ops Outliner Alt+A', 'label_ja': 'Key Ops アウトライナー Alt+A', 'purpose_en': 'Run the Key Ops Outliner Alt+A command.', 'purpose_ja': 'アウトライナー上の Key Ops Alt+A コマンドを実行します。', 'idname': 'keyops.outliner_click', 'keymap': 'Outliner', 'space_type': 'OUTLINER', 'type': 'A', 'value': 'PRESS', 'alt': True},
        {'label_en': 'Key Ops Outliner A', 'label_ja': 'Key Ops アウトライナー A', 'purpose_en': 'Run the Key Ops Outliner A command.', 'purpose_ja': 'アウトライナー上の Key Ops A コマンドを実行します。', 'idname': 'keyops.outliner_click', 'keymap': 'Outliner', 'space_type': 'OUTLINER', 'type': 'A', 'value': 'PRESS'},
        {'label_en': 'None Live Booleans Move', 'label_ja': 'None Live Booleans 移動', 'purpose_en': 'Start Move while handling non-live boolean workflows.', 'purpose_ja': '非ライブブーリアン用の移動操作を開始します。', 'idname': 'transform.entering_transform_none_live_booleans', 'keymap': 'Object Mode', 'type': 'G', 'value': 'PRESS'},
        {'label_en': 'None Live Booleans Rotate', 'label_ja': 'None Live Booleans 回転', 'purpose_en': 'Start Rotate while handling non-live boolean workflows.', 'purpose_ja': '非ライブブーリアン用の回転操作を開始します。', 'idname': 'transform.entering_transform_none_live_booleans', 'keymap': 'Object Mode', 'type': 'R', 'value': 'PRESS'},
        {'label_en': 'None Live Booleans Scale', 'label_ja': 'None Live Booleans スケール', 'purpose_en': 'Start Scale while handling non-live boolean workflows.', 'purpose_ja': '非ライブブーリアン用のスケール操作を開始します。', 'idname': 'transform.entering_transform_none_live_booleans', 'keymap': 'Object Mode', 'type': 'S', 'value': 'PRESS'},
        {'label_en': 'Maya Navigation Tablet Zoom', 'label_ja': 'Maya Navigation タブレットズーム', 'purpose_en': 'Use tablet input for Maya-style 3D View zoom.', 'purpose_ja': 'タブレット入力で Maya 風の3Dビューズームを行います。', 'idname': 'view3d.zoom', 'keymap': '3D View Generic', 'space_type': 'VIEW_3D', 'type': 'LEFTMOUSE', 'value': 'CLICK_DRAG', 'ctrl': True, 'alt': True},
        {'label_en': 'Maya Navigation Tablet Pan', 'label_ja': 'Maya Navigation タブレットパン', 'purpose_en': 'Use tablet input for Maya-style 3D View pan.', 'purpose_ja': 'タブレット入力で Maya 風の3Dビューパンを行います。', 'idname': 'view3d.move', 'keymap': '3D View Generic', 'space_type': 'VIEW_3D', 'type': 'LEFTMOUSE', 'value': 'CLICK_DRAG', 'shift': True, 'alt': True},
    ])
    _SMS_KEYOPS_STATIC_KEYMAP_CACHE = tuple(dict(entry) for entry in entries)
    return [dict(entry) for entry in entries]



def _sms_keyops_static_keymap_entries(context=None) -> list[dict]:
    del context
    if _SMS_KEYOPS_STATIC_KEYMAP_CACHE is None:
        return []
    return [dict(entry) for entry in _SMS_KEYOPS_STATIC_KEYMAP_CACHE]

def _sms_integrated_static_keymap_entries(alias: str, context=None) -> list[dict]:
    alias = str(alias or '').strip()
    if alias == 'key_operators_toolkit':
        return _sms_keyops_static_keymap_entries(context)
    if alias == 'f2':
        return [
            {'label_en': 'F2 Face Creation', 'label_ja': 'F2 面作成', 'purpose_en': 'Create faces or edges from the current mesh selection.', 'purpose_ja': '現在のメッシュ選択から面または辺を作成します。', 'idname': 'mesh.f2', 'keymap': 'Mesh', 'shortcut_en': 'Recommended: F if you want to replace Blender Make Edge/Face', 'shortcut_ja': '推奨: Blender標準の辺/面作成を置き換える場合は F'},
        ]
    if alias == 'polyquilt_fork':
        return [
            {'label_en': 'PolyQuilt Tool Operator', 'label_ja': 'PolyQuilt ツールオペレーター', 'purpose_en': 'Start the PolyQuilt workspace mesh editing tool.', 'purpose_ja': 'PolyQuilt のワークスペースメッシュ編集ツールを開始します。', 'idname': 'mesh.poly_quilt', 'keymap': '3D View Tool: Edit Mesh, PolyQuilt', 'shortcut_en': 'Workspace tool keymap; usually Left Mouse in the tool', 'shortcut_ja': 'ワークスペースツール用キーマップ。通常はツール内の Left Mouse'},
            {'label_en': 'PolyQuilt Retopo Operator', 'label_ja': 'PolyQuilt Retopo オペレーター', 'purpose_en': 'Start the PolyQuilt retopology / quad patch operator.', 'purpose_ja': 'PolyQuilt のリトポ / クアッドパッチ操作を開始します。', 'idname': 'mesh.poly_quilt_retopo', 'keymap': '3D View Tool: Edit Mesh, PolyQuilt:QuadPatch', 'shortcut_en': 'Workspace tool keymap; usually Left Mouse in the tool', 'shortcut_ja': 'ワークスペースツール用キーマップ。通常はツール内の Left Mouse'},
            {'label_en': 'PolyQuilt Daemon', 'label_ja': 'PolyQuilt デーモン', 'purpose_en': 'Run PolyQuilt mouse-move/event update while the PolyQuilt workflow is active.', 'purpose_ja': 'PolyQuilt ワークフロー実行中のマウス移動/イベント更新を実行します。', 'idname': 'none.poly_quilt_daemon', 'keymap': '3D View Tool: Edit Mesh, PolyQuilt', 'shortcut_en': 'Optional manual binding: Mouse Move Any', 'shortcut_ja': '任意の手動割り当て: Mouse Move Any'},
        ]
    return []


def _sms_captured_integrated_keymap_entries(alias: str) -> list[dict]:
    alias = str(alias or '').strip()
    if not alias:
        return []
    try:
        _sms_feature_runtime = sys.modules.get(f'{__package__}.feature_toggle')
        feature_entries = getattr(_sms_feature_runtime, 'feature_entries', None) if _sms_feature_runtime is not None else None
        features = tuple(feature_entries(alias) or ()) if callable(feature_entries) else ()
    except Exception:
        features = ()
    entries = []
    for feature in features:
        if str((feature or {}).get('key') or '') != 'keymaps':
            continue
        for action in tuple((feature or {}).get('actions') or ()):  # pragma: no branch
            if str((action or {}).get('kind') or '') != 'keymaps':
                continue
            idname = str((action or {}).get('idname') or '').strip()
            km_name = str((action or {}).get('km_name') or '').strip()
            if not idname or not km_name:
                continue
            entries.append({
                'label_en': str((action or {}).get('label') or idname),
                'label_ja': 'ショートカット: ' + str((action or {}).get('label') or idname),
                'purpose_en': str((action or {}).get('purpose') or (action or {}).get('description') or ('Run ' + str((action or {}).get('label') or idname) + '.')),
                'purpose_ja': '統合ツールのショートカット「' + str((action or {}).get('label') or idname) + '」を実行します。',
                'idname': idname,
                'keymap': km_name,
                'space_type': str((action or {}).get('space_type') or 'EMPTY'),
                'region_type': str((action or {}).get('region_type') or 'WINDOW'),
                'type': str((action or {}).get('type') or ''),
                'value': str((action or {}).get('value') or 'PRESS'),
                'ctrl': bool((action or {}).get('ctrl', False)),
                'shift': bool((action or {}).get('shift', False)),
                'alt': bool((action or {}).get('alt', False)),
                'oskey': bool((action or {}).get('oskey', False)),
                'repeat': bool((action or {}).get('repeat', False)),
                'properties': (action or {}).get('properties') or {},
            })
    return entries


def _sms_draw_integrated_keymap_reference(layout, context, spec, record) -> int:
    alias = str((spec or {}).get('alias') or '').strip()
    entries = []
    entries.extend(_sms_captured_integrated_keymap_entries(alias))
    entries.extend(_sms_integrated_static_keymap_entries(alias, context))
    return _sms_draw_keymap_reference(layout, context, entries, prefs=None)



def _sms_keymap_entries_for_target(kind: str, alias: str, context=None) -> tuple[dict, ...]:
    kind = str(kind or '').strip()
    alias = str(alias or '').strip()
    entries = []
    if kind == 'native' and alias:
        entries.extend(_sms_native_keymap_entries(alias))
    elif kind == 'integrated' and alias:
        entries.extend(_sms_captured_integrated_keymap_entries(alias))
        entries.extend(_sms_integrated_static_keymap_entries(alias, context))
    elif kind == 'suite_panel' and alias:
        try:
            for item in tuple(globals().get('_SMS_SUITE_PANEL_ITEMS', ())):
                if str((item or {}).get('id') or '').strip() != alias:
                    continue
                for tool_id in tuple((item or {}).get('native_tool_ids') or ()):  # pragma: no branch
                    entries.extend(_sms_native_keymap_entries(str(tool_id or '').strip()))
                for int_alias in tuple((item or {}).get('integrated_aliases') or ()):  # future-proof
                    int_alias = str(int_alias or '').strip()
                    if int_alias:
                        entries.extend(_sms_captured_integrated_keymap_entries(int_alias))
                        entries.extend(_sms_integrated_static_keymap_entries(int_alias, context))
                break
        except Exception:
            pass
    return tuple(_sms_dedupe_keymap_entries(entries))


def _sms_draw_keymap_registration_button(layout, context, kind: str, alias: str, label: str = '') -> int:
    """Draw manual keymap registration information inline at section bottom.

    Smart Modeling Suite must not install persistent keymap entries by itself.
    Every shortcut-oriented tool therefore exposes the recommended registration
    location and a copyable operator ID directly in the settings section.
    """
    entries = _sms_keymap_entries_for_target(str(kind or ''), str(alias or ''), context=context)
    if not entries:
        return 0
    prefs = _sms_get_suite_prefs(context) if str(kind or '') == 'native' else None
    return _sms_draw_keymap_reference(layout, context, entries, prefs=prefs)


def _sms_native_unified_settings_groups(context, prefs, tool_id):
    scene = getattr(context, 'scene', None)
    wm = getattr(context, 'window_manager', None)
    groups = []
    if _sms_rna_pointer_get_is_deferred():
        return groups

    def _add_group(title, data, include_names=()):
        if data is not None and _sms_rna_data_is_current(data):
            if include_names:
                groups.append((title, data, tuple(), tuple(include_names)))
            else:
                groups.append((title, data))

    if tool_id == 'vertex_copy':
        # Vertex Copy has a dedicated compact UI.  Do not dump every RNA option here.
        pass
    elif tool_id == 'vertex_slide':
        _add_group(
            _pick_lang('Settings', '設定', context),
            _sms_safe_get_rna_attr(prefs, 'vertex_slide'),
            include_names=(
                'use_proportional_editing',
                'hit_behavior_normal',
                'hit_behavior_proportional',
                'baseline',
                'edge_lock_enabled',
                'edge_lock_keep_dot',
                'edge_lock_switch_margin',
                'loop_priority',
                'ring_priority',
                'loop_ring_bonus',
                'flow_bias',
                'sensitivity',
                'slow_factor',
                'snap_step',
                'show_hud',
                'show_guides',
            ),
        )
    elif tool_id == 'direct_delete':
        # Direct Delete uses a dedicated hosted settings UI.  Do not dump the
        # shortcut/keymap PropertyGroup directly into the settings page; keymap
        # registration belongs to the suite-level popup button at the bottom.
        return groups
    elif tool_id == 'model_organized':
        # Model Organizer has a dedicated grouped UI.  Do not expose the empty
        # compatibility preference container or raw RNA dump here.
        return groups
    elif tool_id == 'mesh_align_preset':
        _add_group(_pick_lang('Settings', '設定', context), _sms_safe_get_rna_attr(scene, 'align_slide_props'))
    elif tool_id == 'crease_preset':
        # Crease Preset now provides a dedicated settings UI with current-value,
        # select-by-value, and crease copy/paste controls.  Avoid dumping a raw
        # RNA PropertyGroup here so the visible settings remain stable.
        return groups
    elif tool_id == 'toggle_auto_merge_snap':
        _add_group(_pick_lang('Settings', '設定', context), _sms_safe_get_rna_attr(prefs, 'toggle_auto_merge_snap'))
    elif tool_id == 'apply_weighted_normal':
        _add_group(_pick_lang('Settings', '設定', context), _sms_safe_get_rna_attr(prefs, 'apply_weighted_normal'))
    elif tool_id == 'quad_strip_draw' and scene is not None:
        qsd_props = ('qsd_draw_toggle', 'qsd_retopo_mode', 'qsd_plane_mode', 'qsd_use_surface_snap', 'qsd_width', 'qsd_thickness', 'qsd_subdivisions', 'qsd_use_solidify')
        if _sms_rna_data_is_current(scene):
            groups.append((_pick_lang('Settings', '設定', context), scene, tuple(), tuple(qsd_props)))
    return groups

def _sms_integrated_panel_classes(record):
    classes = []
    seen = set()
    for cls in tuple((record or {}).get('panels') or ()):  # pragma: no branch
        if cls in seen:
            continue
        seen.add(cls)
        classes.append(cls)
    return classes




def _sms_is_help_panel_class(panel_cls) -> bool:
    try:
        keys = ' '.join(str(value or '') for value in (
            getattr(panel_cls, 'bl_idname', ''),
            getattr(panel_cls, 'bl_label', ''),
            getattr(panel_cls, '__name__', ''),
        )).lower()
    except Exception:
        return False
    help_tokens = ('_help', ' help', 'help_', 'help panel', 'guide / tips', 'guide_tips', 'usage', 'how to use', 'beginner', 'function overview', 'workflow notes', 'ヘルプ', '使用方法', '使い方', '概要', '初心者')
    return any(token in keys for token in help_tokens)


def _sms_draw_record_original_panels(layout, context, record, *, ignore_poll=False):
    panels = _sms_integrated_panel_classes(record)
    if not panels:
        return 0
    try:
        _sms_ui_runtime = sys.modules.get(f'{__package__}.ui_runtime')
        call_draw = getattr(_sms_ui_runtime, '_call_draw', None) if _sms_ui_runtime is not None else None
    except Exception:
        call_draw = None
    if not callable(call_draw):
        return 0

    drawn = 0
    for panel_cls in panels:
        if _sms_is_help_panel_class(panel_cls):
            continue
        if not _sms_rna_class_is_current(panel_cls):
            continue
        # A UV editor panel reads the UV editor space and cannot draw elsewhere.
        if getattr(panel_cls, 'bl_space_type', '') == 'IMAGE_EDITOR' and getattr(getattr(context, 'area', None), 'type', '') != 'IMAGE_EDITOR':
            continue
        panel_label = _ui_text(str(getattr(panel_cls, 'bl_label', '') or getattr(panel_cls, '__name__', '') or 'Panel').strip() or 'Panel', context)
        poll_fn = getattr(panel_cls, 'poll', None)
        try:
            poll_ok = not callable(poll_fn) or bool(poll_fn(context))
        except Exception:
            poll_ok = False
        if not ignore_poll and not poll_ok:
            continue
        draw_fn = getattr(panel_cls, 'draw', None)
        if not callable(draw_fn):
            continue
        box = layout.box()
        box.label(text=panel_label, icon='PREFERENCES')
        body = box.column(align=False)
        try:
            call_draw(draw_fn, panel_cls, body, context)
            drawn += 1
        except Exception as exc:
            if not poll_ok:
                # The panel does not apply to the current object; that is not an error.
                box.label(text=_pick_lang(
                    'Select a matching object to use this section.',
                    'この項目を使うには、対応するオブジェクトを選んでください。',
                    context,
                ))
                continue
            warn = box.box()
            warn.alert = True
            warn.label(text=str(exc)[:240], icon='ERROR')
    return drawn



def _sms_draw_hosted_native_settings_panel(layout, context, record, meta) -> bool:
    tool_id = str((meta or {}).get('tool_id') or '').strip()
    if tool_id not in {'connect', 'sketch_tools', 'quad_strip_draw', 'model_organized', 'vertex_copy', 'direct_delete', 'crease_preset'}:
        return False
    module = None
    try:
        module = (record or {}).get('module')
    except Exception:
        module = None
    if module is None:
        try:
            module = (meta or {}).get('module')
        except Exception:
            module = None
    if not isinstance(module, types.ModuleType):
        return False
    draw_fn = getattr(module, 'draw_smart_modeling_settings', None)
    if not callable(draw_fn):
        return False
    label = _ui_text(str((meta or {}).get('label') or getattr(module, '__name__', '') or tool_id).strip(), context)
    icon = _sms_safe_icon((meta or {}).get('icon'), 'PREFERENCES')
    box = layout.box()
    box.label(text=label or tool_id, icon=icon)
    body = box.column(align=False)
    try:
        draw_fn(body, context)
    except Exception as exc:
        warn = box.box()
        warn.alert = True
        warn.label(text=str(exc)[:240], icon='ERROR')
    return True



def _sms_draw_mesh_split_execute_box(layout, context, prefs):
    if layout is None:
        return
    box = layout.box()
    box.label(text=_pick_lang('Execution', '実行', context), icon='MOD_EDGESPLIT')
    row = box.row(align=True)
    row.scale_y = 1.15
    row.operator('mesh.smart_split', text=_pick_lang('Run Mesh Split', 'メッシュ分割を実行', context), icon='MOD_EDGESPLIT')


def _sms_draw_apply_weighted_normal_execute_box(layout, context, prefs):
    if layout is None:
        return
    box = layout.box()
    box.label(text=_pick_lang('Execution', '実行', context), icon='MOD_NORMALEDIT')
    col = box.column(align=True)
    awn = None
    try:
        awn = _sms_safe_get_rna_attr(prefs, 'apply_weighted_normal') if prefs is not None else None
    except Exception:
        awn = None
    row = box.row(align=True)
    row.scale_y = 1.15
    op = row.operator('mesh.apply_weighted_normal', text=_pick_lang('Run Apply Weighted Normal', '重み付き法線を実行', context), icon='MOD_NORMALEDIT')
    if awn is not None:
        for name in ('preset', 'apply_mode', 'limit_to_selection', 'keep_sharp', 'weight', 'threshold'):
            try:
                setattr(op, name, getattr(awn, name))
            except Exception:
                pass

def _sms_draw_native_unified_body(layout, context, prefs, meta):
    tool_id = str(meta.get('tool_id') or '')
    record = _sms_native_tool_record(tool_id)
    status = str(record.get('status') or 'available')
    line_en, line_ja = _sms_native_tool_status_lines(context, meta, record)
    if status in {'loading', 'failed'}:
        status_box = layout.box()
        status_box.label(text=_pick_lang(line_en, line_ja, context), icon=_sms_safe_icon(meta.get('icon'), 'TOOL_SETTINGS'))
        if status == 'failed':
            excerpt = _sms_native_tool_error_excerpt(tool_id)
            if excerpt:
                warn = status_box.row()
                warn.alert = True
                warn.label(text=excerpt, icon='ERROR')

    if tool_id == 'modeling_toolset_tools':
        # The former standalone command deck is now a fully integrated Toolset body.
        # Keep the N-panel simple: draw only the compact large-icon deck here.
        # Function overview, usage, and all setting explanations live in help.py
        # and are loaded only when the Help button is clicked.
        display_label = _ui_text(str(meta.get('label') or tool_id).strip(), context) or tool_id
        if status == 'failed':
            _sms_draw_keymap_registration_button(layout, context, 'native', tool_id, display_label)
            return
        if status != 'loaded':
            loading = layout.box()
            loading.label(text=_pick_lang('Loading Modeling Toolkit command deck.', '統合モデリングツールのコマンドデッキを読み込んでいます。', context), icon='TIME')
            _sms_draw_keymap_registration_button(layout, context, 'native', tool_id, display_label)
            return
        module = record.get('module')
        draw_fn = getattr(module, 'draw_integrated_panel', None) if module is not None else None
        if callable(draw_fn):
            try:
                draw_fn(layout, context)
            except Exception as exc:
                warn = layout.box()
                warn.alert = True
                warn.label(text=_pick_lang(f'Failed to draw Modeling Toolkit: {str(exc)[:180]}', f'統合モデリングツールの描画に失敗しました: {str(exc)[:180]}', context), icon='ERROR')
        else:
            warn = layout.box()
            warn.alert = True
            warn.label(text=_pick_lang('Modeling Toolkit command deck is not available.', '統合モデリングツールのコマンドデッキを利用できません。', context), icon='ERROR')
        _sms_draw_keymap_registration_button(layout, context, 'native', tool_id, display_label)
        return

    display_label = _ui_text(str(meta.get('label') or tool_id).strip(), context) or tool_id

    if tool_id == 'vertex_copy':
        hosted = _sms_draw_hosted_native_settings_panel(layout, context, record, meta)
        if not hosted:
            box = layout.box()
            box.label(text=_pick_lang('Vertex Copy settings are not available.', '頂点コピーの設定を利用できません。', context), icon='ERROR')
        _sms_draw_keymap_registration_button(layout, context, 'native', tool_id, display_label)
        return

    if tool_id == 'model_organized':
        hosted = _sms_draw_hosted_native_settings_panel(layout, context, record, meta)
        if not hosted:
            box = layout.box()
            box.label(text=_pick_lang('Model Organizer settings are not available.', 'モデル整理の設定を利用できません。', context), icon='ERROR')
        _sms_draw_keymap_registration_button(layout, context, 'native', tool_id, display_label)
        return

    if tool_id == 'direct_delete':
        hosted = _sms_draw_hosted_native_settings_panel(layout, context, record, meta)
        if not hosted:
            box = layout.box()
            box.label(text=_pick_lang('Direct Delete settings are not available.', '直接削除の設定を利用できません。', context), icon='ERROR')
        _sms_draw_keymap_registration_button(layout, context, 'native', tool_id, display_label)
        return

    if tool_id == 'crease_preset':
        hosted = _sms_draw_hosted_native_settings_panel(layout, context, record, meta)
        if not hosted:
            box = layout.box()
            box.label(text=_pick_lang('Crease Preset settings are not available.', 'クリースプリセットの設定を利用できません。', context), icon='ERROR')
        _sms_draw_keymap_registration_button(layout, context, 'native', tool_id, display_label)
        return

    settings_groups = _sms_native_unified_settings_groups(context, prefs, tool_id)
    for group in settings_groups:
        title = group[0]
        data = group[1]
        include_names = tuple(group[3]) if len(group) >= 4 else tuple()
        namespace = _sms_settings_namespace('native', tool_id, data, title)
        box = layout.box()
        box.label(text=_ui_text(title, context), icon='PREFERENCES')
        col = box.column(align=False)
        if include_names:
            drawn = 0
            for prop_name in include_names:
                try:
                    if _sms_safe_layout_prop(col, data, prop_name):
                        drawn += 1
                except Exception:
                    pass
        else:
            drawn = _sms_draw_rna_properties(col, data, namespace=namespace)
        if not drawn:
            box.label(text=_pick_lang('No editable settings were found.', '編集可能な設定は見つかりませんでした。', context))

    if tool_id == 'mesh_split':
        _sms_draw_mesh_split_execute_box(layout, context, prefs)

    if tool_id == 'apply_weighted_normal':
        _sms_draw_apply_weighted_normal_execute_box(layout, context, prefs)

    hosted_panel_drawn = _sms_draw_hosted_native_settings_panel(layout, context, record, meta)
    panels = _sms_integrated_panel_classes(record)
    if tool_id in {'sketch_tools', 'quad_strip_draw'}:
        panels = []
    if panels and not hosted_panel_drawn:
        box = layout.box()
        box.label(text=_pick_lang('Panel UI', 'パネルUI', context), icon='PREFERENCES')
        panel_drawn = _sms_draw_record_original_panels(box, context, record, ignore_poll=True)
        if not panel_drawn:
            box.label(text=_pick_lang('No panel UI could be drawn in this context.', 'このコンテキストで描画できるパネルUIはありません。', context))

    if tool_id in _SMS_NATIVE_EXECUTE_ONLY or tool_id in _SMS_NATIVE_EXECUTE_POPUP:
        box = layout.box()
        box.label(text=_pick_lang('Execution', '実行', context), icon='PLAY')
        for command in _sms_lazy_ui_execute_commands('native', tool_id):
            _sms_lazy_ui_command('native', tool_id, box, context, command, command_kind='operator')
        _sms_draw_keymap_registration_button(layout, context, 'native', tool_id, display_label)
        return

    menus = _sms_native_menu_entries(record, context)
    if menus:
        box = layout.box()
        box.label(text=_pick_lang('Menus', 'メニュー', context), icon='MENU_PANEL')
        _sms_draw_menu_buttons(box, menus)
    operators = _sms_native_operator_entries(record, context)
    if operators:
        box = layout.box()
        box.label(text=_pick_lang('Operators', 'オペレーター', context), icon='TOOL_SETTINGS')
        _sms_draw_operator_buttons(box, operators, max_items=16)

    _sms_draw_keymap_registration_button(layout, context, 'native', tool_id, display_label)



def _sms_integrated_menu_entries(record, context=None):
    items = []
    seen = set()
    for cls in tuple(record.get('menus') or ()):
        menu_id = str(getattr(cls, 'bl_idname', '') or '').strip()
        if not menu_id or menu_id in seen:
            continue
        seen.add(menu_id)
        label = _ui_text(str(getattr(cls, 'bl_label', '') or getattr(cls, '__name__', '') or menu_id).strip(), context) or menu_id
        upper = f'{menu_id} {label} {getattr(cls, "__name__", "")}'.upper()
        items.append((menu_id, label, 'PIE' in upper))
    items.sort(key=lambda item: item[1].lower())
    return items



def _sms_integrated_operator_entries(record, context=None):
    items = []
    seen = set()
    for cls in tuple(record.get('operators') or ()):
        op_id = str(getattr(cls, 'bl_idname', '') or '').strip()
        if not op_id or op_id in seen or op_id in _SMS_OPERATOR_INVOKE_DENYLIST:
            continue
        seen.add(op_id)
        label = _ui_text(str(getattr(cls, 'bl_label', '') or getattr(cls, '__name__', '') or op_id).strip() or op_id, context)
        desc = _ui_text(str(getattr(cls, 'bl_description', '') or '').strip(), context)
        items.append((op_id, label, desc))
    items.sort(key=lambda item: (item[1].lower(), item[0].lower()))
    return items



def _sms_preferences_objects(context, record):
    result = []
    prefs_classes = tuple(record.get('preferences') or ())
    if not prefs_classes:
        return result
    _sms_preferences = sys.modules.get(f'{__package__}.preferences')
    if _sms_preferences is None:
        return result
    module = record.get('module')
    addon_key = str(getattr(module, '__package__', '') or getattr(module, '__name__', '') or '')
    seen = set()
    for cls in prefs_classes:
        if cls in seen:
            continue
        seen.add(cls)
        try:
            pref_obj = _sms_preferences.get_preferences(context=context, addon_key=addon_key, prefs_cls=cls)
        except Exception:
            pref_obj = None
        if pref_obj is not None and _sms_rna_data_is_current(pref_obj):
            result.append((str(getattr(cls, 'bl_label', '') or getattr(cls, '__name__', '') or 'Preferences'), pref_obj))
    return result



def _sms_draw_integrated_original_panels(layout, context, record):
    # Integrated add-ons have their original Panel.poll methods hidden while
    # hosted by Smart Modeling to prevent duplicate top-level N-panel entries.
    # The unified Smart Modeling browser is the intended host, so draw those
    # captured panels directly and ignore the hidden duplicate-suppression poll.
    return _sms_draw_record_original_panels(layout, context, record, ignore_poll=True)



def _sms_draw_manual_setup_guidance(layout, context, alias, *, loaded=False):
    if alias == 'key_operators_toolkit':
        lines = (
            ("In Preferences > Keymap, edit or add a binding and set its event to Press.",
             "プリファレンスのキーマップで項目を編集または追加し、イベントを「押す」に設定します。"),
            ("Object Mode: W or Right Mouse > wm.call_menu > VIEW3D_MT_object_context_menu.",
             "オブジェクトモード: W または右クリック > wm.call_menu > VIEW3D_MT_object_context_menu。"),
            ("Mesh: W or Right Mouse > wm.call_menu > VIEW3D_MT_edit_mesh_context_menu.",
             "メッシュ編集モード: W または右クリック > wm.call_menu > VIEW3D_MT_edit_mesh_context_menu。"),
            ("3D View Generic: Alt+Shift+A > wm.call_menu_pie > KEYOPS_MT_add_objects_pie_menu (enable Add Objects Pie).",
             "3D ビュー汎用: Alt+Shift+A > wm.call_menu_pie > KEYOPS_MT_add_objects_pie_menu（Add Objects Pie を有効化）。"),
            ("3D View: Space > wm.call_menu_pie > VIEW3D_MT_view_pie (Blender View pie).",
             "3D ビュー: Space > wm.call_menu_pie > VIEW3D_MT_view_pie（Blender のビューパイメニュー）。"),
            ("If a binding conflicts, search Keymap by the full shortcut and disable the conflicting item, including in other keymaps.",
             "競合する場合は、修飾キーを含むショートカットでキーマップ全体を検索し、競合する項目を無効にします。"),
        )
    elif alias == 'polyquilt_fork':
        lines = (
            ("In Preferences > Keymap, find the tool keymap shown above. Edit or add an item.",
             "プリファレンスのキーマップで上記のツール用キーマップを探し、項目を編集または追加します。"),
            ("Set the operator ID, event and modifiers for each tool. Use Left Mouse Press for the standard tool action.",
             "ツールごとにオペレーター ID、イベント、修飾キーを設定します。標準のツール操作は左クリックの「押す」です。"),
            ("For custom game-engine-style bindings, choose your own events here. PolyQuilt provides no automatic preset.",
             "ゲームエンジン風の割り当てはここでイベントを個別に設定します。PolyQuilt に自動プリセットはありません。"),
            ("Use Save Preferences in Blender's Preferences menu if Auto-Save Preferences is off.",
             "プリファレンスの自動保存が無効な場合は、Blender のプリファレンスメニューから設定を保存します。"),
        )
    elif alias == 'tissue':
        if loaded and sys.modules.get('numba') is not None:
            lines = (
                ("Numba is available. NumPy is used if Numba tessellation is turned off.",
                 "Numba を利用できます。Numba によるテッセレーションが無効なら NumPy を使います。"),
            )
        elif loaded:
            lines = (
                ("Numba is unavailable. Tissue uses the bundled NumPy fallback.",
                 "Numba を利用できないため、Tissue は同梱の NumPy を使います。"),
            )
        else:
            lines = (
                ("Tissue uses the bundled NumPy fallback when Numba is unavailable.",
                 "Numba を利用できない場合、Tissue は同梱の NumPy を使います。"),
            )
    else:
        return

    guidance = layout.column(align=True)
    for en, ja in lines:
        _sms_label_wrapped(guidance, context, _pick_lang(en, ja, context))


def _sms_draw_integrated_unified_body(layout, context, spec, record):
    display_name = str(spec.get('display_name') or spec.get('alias') or 'Integrated Tool')
    status = str(record.get('status') or 'available') if record else 'unavailable'
    panels = len(tuple((record or {}).get('panels') or ()))
    operators = len(tuple((record or {}).get('operators') or ()))
    menus = len(tuple((record or {}).get('menus') or ()))
    if status == 'loaded':
        line = _pick_lang(
            f'Loaded. Panels: {panels} / Operators: {operators} / Menus: {menus}.',
            f'ロード済みです。パネル: {panels} / オペレーター: {operators} / メニュー: {menus}。',
            context,
        )
    elif status == 'failed':
        line = _pick_lang(
            f'Failed to load. Panels: {panels} / Operators: {operators} / Menus: {menus}.',
            f'読み込みに失敗しました。パネル: {panels} / オペレーター: {operators} / メニュー: {menus}。',
            context,
        )
    elif status == 'disabled':
        line = _pick_lang('Disabled.', '無効です。', context)
    else:
        line = _pick_lang('Not loaded.', '未読み込みです。', context)
    if status in {'loading', 'failed'}:
        status_box = layout.box()
        status_box.label(text=line, icon='TOOL_SETTINGS')
        if record and status == 'failed':
            excerpt = str(record.get('error') or '').strip().splitlines()
            if excerpt:
                row = status_box.row()
                row.alert = True
                row.label(text=excerpt[-1][:240], icon='ERROR')

    pref_drawn = 0
    for title, pref_obj in _sms_preferences_objects(context, record or {}):
        box = layout.box()
        box.label(text=_ui_text(title, context), icon='PREFERENCES')
        col = box.column(align=False)
        namespace = _sms_settings_namespace('integrated', str(spec.get('alias') or ''), pref_obj, title)
        drawn = _sms_draw_rna_properties(col, pref_obj, namespace=namespace)
        pref_drawn += drawn
        if not drawn:
            box.label(text=_pick_lang('No editable settings were found.', '編集可能な設定は見つかりませんでした。', context))

    panel_drawn = 0
    if record and status == 'loaded':
        box = layout.box()
        box.label(text=_pick_lang('Panel UI', 'パネルUI', context), icon='PREFERENCES')
        panel_drawn = _sms_draw_integrated_original_panels(box, context, record or {})
        if not panel_drawn:
            box.label(text=_pick_lang('No panel UI could be drawn in this context.', 'このコンテキストで描画できるパネルUIはありません。', context))

    menus = _sms_integrated_menu_entries(record or {}, context)
    if menus:
        box = layout.box()
        box.label(text=_pick_lang('Menus', 'メニュー', context), icon='MENU_PANEL')
        _sms_draw_menu_buttons(box, menus)
    ops = _sms_integrated_operator_entries(record or {}, context)
    if ops:
        box = layout.box()
        box.label(text=_pick_lang('Operators', 'オペレーター', context), icon='TOOL_SETTINGS')
        _sms_draw_operator_buttons(box, ops, max_items=16)

    alias = str(spec.get('alias') or '').strip()
    _sms_draw_keymap_registration_button(layout, context, 'integrated', alias, _ui_text(display_name, context))
    _sms_draw_manual_setup_guidance(layout, context, alias, loaded=status == 'loaded')




def _sms_suite_panel_item_label(item, context=None) -> str:
    return _pick_lang(str((item or {}).get('label_en') or ''), str((item or {}).get('label_ja') or ''), context)


class _SMS_SuitePanelDrawShim:
    layout = None


def _sms_draw_suite_panel_body(layout, context, prefs, item):
    item = dict(item or {})
    # Toolset command sections are click-start containers.  Panel.draw reads
    # only records built at registration or an explicit load operation.

    item_id = str(item.get('id') or '').strip()
    panel_name = str(item.get('panel_cls_name') or '').strip()
    panel_cls = globals().get(panel_name)
    draw_fn = getattr(panel_cls, 'draw', None) if isinstance(panel_cls, type) else None
    if not callable(draw_fn):
        warn = layout.box()
        warn.alert = True
        warn.label(text=_pick_lang('This command section is not available.', 'このコマンド項目は利用できません。', context), icon='ERROR')
        return

    try:
        _sms_ui_runtime = sys.modules.get(f'{__package__}.ui_runtime')
        call_draw = getattr(_sms_ui_runtime, '_call_draw', None) if _sms_ui_runtime is not None else None
    except Exception:
        call_draw = None

    if panel_name == 'VIEW3D_PT_sms_all_commands':
        try:
            call_draw(draw_fn, panel_cls, layout, context) if callable(call_draw) else None
        except Exception:
            pass
        _sms_draw_all_commands_inline(layout, context)
        return

    try:
        if callable(call_draw):
            call_draw(draw_fn, panel_cls, layout, context)
        else:
            shim = _SMS_SuitePanelDrawShim()
            shim.layout = layout
            draw_fn(shim, context)
    except Exception as exc:
        warn = layout.box()
        warn.alert = True
        warn.label(text=_pick_lang(f'Failed to draw this command section: {str(exc)[:180]}', f'このコマンド項目の描画に失敗しました: {str(exc)[:180]}', context), icon='ERROR')

    _sms_draw_keymap_registration_button(layout, context, 'suite_panel', item_id, _sms_suite_panel_item_label(item, context))


def _sms_draw_all_commands_inline(layout, context):
    loaded_tools = [meta for meta in _sms_tool_meta_entries() if _sms_native_tool_loaded(str(meta.get('tool_id') or ''))]
    if not loaded_tools:
        return
    for meta in loaded_tools:
        tool_id = str(meta.get('tool_id') or '').strip()
        label = str(meta.get('label') or tool_id).strip()
        record = _sms_native_tool_record(tool_id)
        menus = _sms_native_menu_entries(record, context)
        operators = _sms_native_operator_entries(record, context)
        if not menus and not operators:
            continue
        box = layout.box()
        box.label(text=_ui_text(label, context), icon=_sms_safe_icon(meta.get('icon'), 'TOOL_SETTINGS'))
        if menus:
            sub = box.column(align=True)
            sub.label(text=_pick_lang('Menus', 'メニュー', context), icon='MENU_PANEL')
            _sms_draw_menu_buttons(sub, menus)
        if operators:
            sub = box.column(align=True)
            sub.label(text=_pick_lang('Operators', 'オペレーター', context), icon='TOOL_SETTINGS')
            _sms_draw_operator_buttons(sub, operators, max_items=24)

def _sms_workflow_category_label(category, context=None):
    return _pick_lang(str(category.get('label_en') or ''), str(category.get('label_ja') or ''), context)



def _sms_workflow_category_for_native(meta):
    tool_id = str((meta or {}).get('tool_id') or '').strip()
    return _SMS_NATIVE_WORKFLOW_CATEGORY.get(tool_id, 'other_tools')



def _sms_workflow_category_for_integrated(spec):
    alias = str((spec or {}).get('alias') or '').strip()
    return _SMS_INTEGRATED_WORKFLOW_CATEGORY.get(alias, 'other_tools')




def _sms_unified_item_key(item) -> str:
    item = item or {}
    kind = str(item.get('kind') or '').strip()
    if kind == 'native':
        tool_id = str(((item.get('meta') or {}).get('tool_id')) or '').strip()
        return f'native:{tool_id}' if tool_id else ''
    if kind == 'integrated':
        alias = str(((item.get('spec') or {}).get('alias')) or '').strip()
        return f'integrated:{alias}' if alias else ''
    if kind == 'suite_panel':
        item_id = str(item.get('id') or '').strip()
        return f'suite_panel:{item_id}' if item_id else ''
    label = str(item.get('label') or item.get('label_en') or item.get('id') or '').strip().lower()
    return f'{kind}:{label}' if label else ''


def _sms_dedupe_unified_items(items):
    result = []
    seen = set()
    for item in tuple(items or ()):  # pragma: no branch
        key = _sms_unified_item_key(item)
        if not key:
            continue
        if key in seen:
            continue
        seen.add(key)
        result.append(item)
    return result


_SMS_INTEGRATED_UI_SPECS_SNAPSHOT = ()


def _sms_refresh_integrated_ui_specs_snapshot() -> tuple:
    global _SMS_INTEGRATED_UI_SPECS_SNAPSHOT
    registry_module = sys.modules.get(f'{__package__}.registry')
    build_specs = getattr(registry_module, 'build_specs', None) if registry_module is not None else None
    visible_spec = getattr(registry_module, 'is_visible_addon_spec', None) if registry_module is not None else None
    result = []
    if callable(build_specs):
        try:
            for raw_spec in tuple(build_specs(force=False) or ()):
                spec = dict(raw_spec or {})
                registry_visible = bool(visible_spec(spec)) if callable(visible_spec) else True
                if registry_visible and _sms_is_visible_integrated_spec(spec):
                    result.append(spec)
        except Exception:
            result = []
    _SMS_INTEGRATED_UI_SPECS_SNAPSHOT = tuple(result)
    return _SMS_INTEGRATED_UI_SPECS_SNAPSHOT


def _sms_build_unified_items(context, prefs):
    del context, prefs
    items = []
    for panel_item in _SMS_SUITE_PANEL_ITEMS:
        item_id = str(panel_item.get('id') or '').strip()
        if not item_id:
            continue
        if item_id in _SMS_AGGREGATE_SUITE_PANEL_ITEM_IDS:
            continue
        item = dict(panel_item)
        item.update({
            'kind': 'suite_panel',
            'runtime_group': str(panel_item.get('runtime_group') or 'click_only'),
            'category': str(panel_item.get('category') or 'other_tools'),
            'label': str(panel_item.get('label_en') or item_id.replace('_', ' ').title()),
            'icon': str(panel_item.get('icon') or 'TOOL_SETTINGS'),
            'enable_prop': str(panel_item.get('enable_prop') or '').strip() if str(panel_item.get('runtime_group') or '') == 'persistent' else '',
            'show_prop': f'ui_show_suite_panel_{item_id}',
            'sort_key': int(panel_item.get('sort_key', -1)),
        })
        items.append(item)

    for meta in _sms_tool_meta_entries():
        tool_id = str(meta.get('tool_id') or '').strip()
        if not tool_id:
            continue
        runtime_group = 'persistent' if _sms_native_tool_has_persistent_load(tool_id) else 'click_only'
        items.append({
            'kind': 'native',
            'runtime_group': runtime_group,
            'category': _sms_workflow_category_for_native(meta),
            'label': str(meta.get('label') or tool_id),
            'icon': str(meta.get('icon') or 'TOOL_SETTINGS'),
            'enable_prop': str(meta.get('toggle') or '').strip() if runtime_group == 'persistent' else '',
            'show_prop': _SMS_NATIVE_SHOW_PROP_MAP.get(tool_id, f'ui_show_{tool_id}'),
            'meta': meta,
            'sort_key': len(items),
        })

    try:
        for spec in _SMS_INTEGRATED_UI_SPECS_SNAPSHOT:
            alias = str(spec.get('alias') or '').strip()
            if not alias:
                continue
            runtime_group = 'persistent' if _sms_integrated_tool_has_persistent_load(alias) else 'click_only'
            items.append({
                'kind': 'integrated',
                'runtime_group': runtime_group,
                'category': _sms_workflow_category_for_integrated(spec),
                'label': str(spec.get('display_name') or alias.replace('_', ' ').title()),
                'icon': 'PLUGIN',
                'enable_prop': _sms_integrated_enable_prop(alias) if runtime_group == 'persistent' else '',
                'show_prop': f'ui_show_tool_{alias}',
                'spec': spec,
                'sort_key': str(spec.get('display_name') or alias).lower(),
            })
    except Exception:
        pass
    return _sms_dedupe_unified_items(items)

def _sms_group_unified_items(items):
    grouped = {str(cat.get('id') or ''): [] for cat in _SMS_WORKFLOW_CATEGORY_DEFS}
    for item in items:
        cat_id = str(item.get('category') or 'other_tools').strip() or 'other_tools'
        grouped.setdefault(cat_id, []).append(item)

    result = []
    for category in _SMS_WORKFLOW_CATEGORY_DEFS:
        cat_id = str(category.get('id') or '').strip()
        category_items = list(grouped.get(cat_id, ()))
        if not category_items:
            continue
        suite_items = [item for item in category_items if str(item.get('kind') or '') == 'suite_panel']
        native_items = [item for item in category_items if str(item.get('kind') or '') == 'native']
        integrated_items = [item for item in category_items if str(item.get('kind') or '') == 'integrated']
        other_items = [item for item in category_items if str(item.get('kind') or '') not in {'suite_panel', 'native', 'integrated'}]
        suite_items.sort(key=lambda item: int(item.get('sort_key', 0)))
        native_items.sort(key=lambda item: int(item.get('sort_key', 0)))
        integrated_items.sort(key=lambda item: str(item.get('sort_key') or '').lower())
        other_items.sort(key=lambda item: str(item.get('sort_key') or '').lower())
        result.append((category, suite_items + native_items + integrated_items + other_items))
    return result



def _sms_flatten_unified_items(grouped_sections):
    items = []
    for _category, section_items in tuple(grouped_sections or ()):
        for item in tuple(section_items or ()):
            items.append(item)
    return items



def _sms_unified_item_enabled(prefs, item) -> bool:
    if _sms_item_runtime_group(item) != 'persistent':
        return True
    enable_prop = str((item or {}).get('enable_prop') or '').strip()
    if not enable_prop:
        return False
    return _sms_persistent_toggle_state_get(enable_prop, prefs=prefs, default=False)


def _sms_unified_item_runtime_badge(context, prefs, item):
    kind = str(item.get('kind') or '').strip()
    alias = ''
    status = 'available'
    if kind == 'native':
        alias = str((item.get('meta') or {}).get('tool_id') or '').strip()
        record = _sms_native_tool_record(alias)
        status = str(record.get('status') or _sms_native_tool_state(alias).get('status') or 'available').strip().lower()
    elif kind == 'integrated':
        alias = str((item.get('spec') or {}).get('alias') or '').strip()
        try:
            _sms_loader = sys.modules.get(f'{__package__}.loader')
            record = _sms_loader.get_record(alias) if _sms_loader is not None else {}
        except Exception:
            record = {}
        status = str((record or {}).get('status') or 'available').strip().lower()

    if alias and _sms_on_demand_load_pending(kind, alias):
        status = 'loading'

    if status in {'loading', 'initializing'}:
        return _pick_lang('Loading', '読み込み中', context), 'TIME'
    if status in {'failed', 'error'}:
        return _pick_lang('Error', 'エラー', context), 'ERROR'
    return '', 'NONE'


def _sms_always_on_description_for_item(item, context=None) -> str:
    kind = str((item or {}).get('kind') or '').strip()
    if kind == 'native':
        tool_id = str(((item or {}).get('meta') or {}).get('tool_id') or '').strip()
        info = {
            'vertex_copy': (
                'Controls Vertex Copy live preview and draw-handler based runtime. Enable it only when you need background preview support.',
                '頂点コピーのライブプレビューと描画ハンドラー系ランタイムを制御します。バックグラウンドのプレビュー補助が必要な時だけ有効にしてください。',
            ),
            'vertex_slide': (
                'Controls the Vertex Slide top-bar toggle, shortcut toggle, status display, and live transform monitor. Enable it only when you want the slide constraint available persistently while modeling.',
                '頂点スライドの上部バー切り替え、ショートカット切り替え、ステータス表示、ライブ変形監視を制御します。モデリング中に頂点スライド制約を常時使いたい時だけ有効にしてください。',
            ),
            'direct_delete': (
                'Controls Direct Delete preview/runtime support. Delete / Backspace shortcuts remain manual-only and are never installed by the add-on.',
                'Direct Delete のプレビュー / ランタイムを制御します。Delete / Backspace ショートカットは手動登録専用で、アドオンから自動登録されません。',
            ),
            'toggle_auto_merge_snap': (
                'Controls Merge Snap status/header runtime. Shortcuts remain manual-only and are never installed by the add-on.',
                'Merge Snap のステータス表示・ヘッダー連携を制御します。ショートカットは手動登録専用で、アドオンから自動登録されません。',
            ),
            'apply_weighted_normal': (
                'Controls the persistent Alt+N normals menu integration. Disable it for lighter startup and use the N-panel settings when one-shot execution is enough.',
                'Alt+N 法線メニューへの常時登録を制御します。起動を軽くしたい場合は無効にし、単発実行はNパネルの設定から使用してください。',
            ),
        }.get(tool_id)
        if info:
            return _pick_lang(info[0], info[1], context)
    if kind == 'integrated':
        alias = str(((item or {}).get('spec') or {}).get('alias') or '').strip()
        info = {
            'key_operators_toolkit': (
                'Controls Key Ops Toolkit hotkeys, handlers, menu hooks, and tablet / outliner background integration. Enable only the sessions that need these persistent operations.',
                'Key Ops Toolkit のホットキー、ハンドラー、メニュー連携、タブレット / アウトライナー連携を制御します。これらの常時動作が必要な作業時だけ有効にしてください。',
            ),
            'curve_tools': (
                'Controls Curve Tools export menu entries and curve/object context-menu hooks. Enable it only when you want those menus available at all times.',
                'Curve Tools の書き出しメニュー項目とカーブ / オブジェクトのコンテキストメニュー連携を制御します。これらのメニューを常時使いたい時だけ有効にしてください。',
            ),
            'tissue': (
                'Controls Tissue frame-change handlers used by animated tessellation and reaction-diffusion workflows. Enable only when you need automatic frame updates.',
                'Tissue のアニメーションテッセレーションやリアクション拡散で使うフレーム変更ハンドラーを制御します。自動フレーム更新が必要な時だけ有効にしてください。',
            ),
        }.get(alias)
        if info:
            return _pick_lang(info[0], info[1], context)
    return _pick_lang(
        'Controls runtime behavior that can stay active without pressing a command button. Disable it for lighter startup and idle operation.',
        'コマンドボタンを押していなくても動作し続ける可能性があるランタイムを制御します。起動時や待機時を軽くしたい場合は無効にしてください。',
        context,
    )


def _sms_draw_help_icon_button(layout, kind, alias, label, context=None, *, scale_x=0.82, leading_gap=False):
    """Draw a lazy Help icon button without importing the heavy help catalog."""
    # Use a fixed separator instead of separator_spacer().  In Blender 5.1 the
    # stretchy spacer can keep nested layout state alive inside repeated rows,
    # which appears as a one-step-right indentation drift in lower workflow
    # categories.  A normal separator gives the requested gap beside 設定 without
    # changing the host row's horizontal origin.
    if leading_gap:
        try:
            layout.separator(factor=0.35)
        except TypeError:
            try:
                layout.separator()
            except Exception:
                pass
        except Exception:
            pass
    try:
        row = layout.row(align=True)
    except Exception:
        row = layout
    try:
        row.scale_x = 0.82
    except Exception:
        pass
    try:
        row.scale_y = 1.0
    except Exception:
        pass
    try:
        op = row.operator(
            'smart_modeling_suite.show_tool_help',
            text='',
            icon=_sms_safe_icon('QUESTION', 'HELP'),
            emboss=True,
        )
        op.kind = str(kind or '')
        op.alias = str(alias or '')
        op.label = str(label or '')
        return op
    except Exception:
        return None


def _sms_lazy_ui_prop(layout, proxy, setting, context=None, *, text=None, toggle=False) -> bool:
    setting = dict(setting or {})
    prop_key = str(setting.get('proxy_key') or '').strip()
    if layout is None or proxy is None or not prop_key:
        return False
    try:
        rna_props = getattr(getattr(proxy, 'bl_rna', None), 'properties', None)
        if rna_props is not None and rna_props.get(prop_key) is None:
            return False
    except Exception:
        pass
    kwargs = {}
    label = text
    if label is None:
        label = str(setting.get('text') or '').strip()
    if label is not None:
        kwargs['text'] = _ui_text(str(label), context) if str(label) else ''
    if toggle:
        kwargs['toggle'] = True
    try:
        # A dropdown keeps its name readable at the default sidebar width by
        # taking a line of its own.
        rna_prop = proxy.bl_rna.properties.get(prop_key)
        caption = kwargs.get('text') or ''
        crease_value_field = setting.get('source_class') == 'CreasePresetPreferences' and setting.get('name') in {'active_crease_value', 'select_crease_value', 'match_tolerance', 'approx_match_tolerance'}
        if caption and rna_prop is not None and (crease_value_field or rna_prop.type == 'STRING' or (rna_prop.type == 'ENUM' and not rna_prop.is_enum_flag)):
            column = layout.column(align=True)
            column.label(text=caption)
            column.prop(proxy, prop_key, text='')
            return True
        layout.prop(proxy, prop_key, **kwargs)
        return True
    except Exception:
        return False


def _sms_lazy_ui_setting_map(kind: str, alias: str):
    result = {}
    for setting in _sms_lazy_ui_settings(kind, alias):
        name = str((setting or {}).get('name') or '').strip()
        if name and name not in result:
            result[name] = dict(setting or {})
    return result


def _sms_lazy_ui_command(kind: str, alias: str, layout, context, command, *, command_kind='operator', text=None, icon=None):
    command = dict(command or {})
    target_id = str(command.get('idname') or '').strip()
    if not target_id:
        return None
    if target_id in {
        'smart_modeling_suite.native_tool_invoke',
        'smart_modeling_suite.integrated_tool_invoke',
        'smart_modeling_suite.show_tool_help',
        'smart_modeling_suite.show_keymap_registration',
    }:
        return None
    label = str(text).strip() if text is not None else (str(command.get('label') or '').strip() or target_id)
    if label == target_id:
        try:
            module_name, op_name = target_id.split('.', 1)
            rna_name = getattr(getattr(bpy.ops, module_name), op_name).get_rna_type().name
            if rna_name:
                label = bpy.app.translations.pgettext_iface(rna_name, 'Operator')
        except Exception:
            pass
    desc = str(command.get('description') or '').strip()
    icon_name = str(icon if icon is not None else (command.get('icon') or '')).strip()
    resolved_icon = _sms_safe_icon(
        icon_name,
        _sms_command_icon(target_id, label, desc, 'TOOL_SETTINGS'),
    )
    invoke_id = (
        'smart_modeling_suite.native_tool_invoke'
        if str(kind or '') == 'native'
        else 'smart_modeling_suite.integrated_tool_invoke'
    )
    try:
        op = _sms_readable_operator(layout, invoke_id, text=label, context=context, icon=resolved_icon)
    except Exception:
        return None
    if str(kind or '') == 'native':
        op.tool_id = str(alias or '')
    else:
        op.alias = str(alias or '')
    op.target_kind = str(command_kind or 'operator')
    op.target_id = target_id
    op.target_label = label
    op.target_desc = desc
    upper = f'{target_id} {label}'.upper()
    op.is_pie_menu = bool(command_kind == 'menu' and 'PIE' in upper)
    return op


def _sms_draw_lazy_model_organizer_body(layout, context, proxy) -> bool:
    settings = _sms_lazy_ui_setting_map('native', 'model_organized')
    snapshot = _sms_lazy_ui_snapshot_entry('native', 'model_organized')
    operators = {str(item.get('idname') or ''): dict(item or {}) for item in tuple(snapshot.get('operators') or ())}
    if proxy is None or not settings:
        return False

    layout.use_property_split = True
    layout.use_property_decorate = False

    def _prop(host, name, *, text=None, toggle=False):
        return _sms_lazy_ui_prop(host, proxy, settings.get(name), context, text=text, toggle=toggle)

    box = layout.box()
    box.label(text=_pick_lang('Execution', '実行', context), icon='PLAY')
    row = box.row(align=True)
    row.scale_y = 1.15
    _sms_lazy_ui_command('native', 'model_organized', row, context, operators.get('mo2.organize_modal'), text='Organize Selection', icon='CHECKMARK')
    _sms_lazy_ui_command('native', 'model_organized', row, context, operators.get('mo2.restore_backup'), text='Restore Backup', icon='LOOP_BACK')
    _sms_lazy_ui_command('native', 'model_organized', row, context, operators.get('mo2.clear_backup'), text='', icon='TRASH')
    box.column(align=True).label(
        text=_ui_text('Select mesh objects, adjust the settings below, then run Organize Selection.', context),
    )

    box = layout.box()
    box.label(text=_ui_text('Preset', context), icon='PRESET')
    _prop(box, 'preset', text='')

    box = layout.box()
    box.label(text=_ui_text('Modifiers', context), icon='MODIFIER')
    _prop(box, 'keep_mode', text='')
    sub = box.column(align=True)
    try:
        sub.enabled = getattr(proxy, str(settings['keep_mode']['proxy_key'])) in {'KEEP_REBUILD', 'KEEP_SAFE'}
    except Exception:
        sub.enabled = True
    _prop(sub, 'keep_modifier_drivers')

    box = layout.box()
    box.label(text=_ui_text('Transforms', context), icon='ORIENTATION_GLOBAL')
    col = box.column(align=True)
    row = col.row(align=True)
    _prop(row, 'apply_location', text='Location', toggle=True)
    _prop(row, 'apply_rotation', text='Rotation', toggle=True)
    _prop(row, 'apply_scale', text='Scale', toggle=True)
    _prop(col, 'shade_smooth')

    box = layout.box()
    box.label(text=_ui_text('Display', context), icon='RESTRICT_VIEW_OFF')
    col = box.column(align=True)
    _prop(col, 'set_object_color')
    sub = col.column(align=True)
    try:
        sub.enabled = bool(getattr(proxy, str(settings['set_object_color']['proxy_key'])))
    except Exception:
        sub.enabled = True
    _prop(sub, 'object_color')
    _prop(col, 'set_wire_off')

    box = layout.box()
    box.label(text=_ui_text('Clean Data', context), icon='BRUSH_DATA')
    col = box.column(align=True)
    for name in (
        'remove_crease',
        'remove_bevel_weight',
        'clear_custom_normals',
        'recalc_normals',
        'convert_geometry_nodes_to_mesh',
    ):
        _prop(col, name)
    row = col.row(align=True)
    _prop(row, 'merge_by_distance')
    sub = row.row(align=True)
    try:
        sub.enabled = bool(getattr(proxy, str(settings['merge_by_distance']['proxy_key'])))
    except Exception:
        sub.enabled = True
    _prop(sub, 'merge_distance', text='Distance')
    for name in ('delete_loose', 'remove_empty_material_slots', 'purge_orphans', 'rename_data_to_object_name'):
        _prop(col, name)
    _sms_lazy_ui_command(
        'native',
        'model_organized',
        col,
        context,
        {
            'idname': 'mo2.rename_data_to_object_name',
            'label': 'Rename Data to Object Name',
            'description': 'Rename the data-block of each selected object to match its object name. Multi-user, linked, and library data-blocks are skipped and reported. Running it again changes nothing.',
        },
        text=_pick_lang('Rename Data to Object Name', 'データ名をオブジェクト名に改名', context),
        icon='SORTALPHA',
    )

    box = layout.box()
    box.label(text=_ui_text('Origin / Pivot', context), icon='PIVOT_ACTIVE')
    _prop(box, 'origin_mode', text='')

    box = layout.box()
    box.label(text=_ui_text('Rename / Collections', context), icon='OUTLINER_COLLECTION')
    col = box.column(align=True)
    _prop(col, 'rename_enable')
    sub = col.column(align=True)
    try:
        sub.enabled = bool(getattr(proxy, str(settings['rename_enable']['proxy_key'])))
    except Exception:
        sub.enabled = True
    _prop(sub, 'rename_pattern')
    _prop(sub, 'rename_start_index')
    col.separator()
    _prop(col, 'move_to_collection_enable')
    sub = col.column(align=True)
    try:
        sub.enabled = bool(getattr(proxy, str(settings['move_to_collection_enable']['proxy_key'])))
    except Exception:
        sub.enabled = True
    _prop(sub, 'target_collection')
    _prop(sub, 'remove_empty_collections')

    box = layout.box()
    box.label(text=_ui_text('Preflight Checks', context), icon='VIEWZOOM')
    col = box.column(align=True)
    _prop(col, 'preflight_enable')
    sub = col.column(align=True)
    try:
        sub.enabled = bool(getattr(proxy, str(settings['preflight_enable']['proxy_key'])))
    except Exception:
        sub.enabled = True
    for name in ('check_nonmanifold', 'check_negative_scale', 'auto_fix_negative_scale', 'warn_shapekeys_armature'):
        _prop(sub, name)

    box = layout.box()
    box.label(text=_ui_text('Backup / Restore', context), icon='FILE_BACKUP')
    col = box.column(align=True)
    _prop(col, 'backup_enable')
    sub = col.column(align=True)
    try:
        sub.enabled = bool(getattr(proxy, str(settings['backup_enable']['proxy_key'])))
    except Exception:
        sub.enabled = True
    _prop(sub, 'restore_on_cancel')
    try:
        count = len(getattr(getattr(context, 'scene', None), 'mo2_backup_items', ()))
    except Exception:
        count = 0
    col.label(text=_ui_text('Stored Backups: {count}', context).format(count=count))
    return True


# Commands shown under Execution instead of every class the tool registers.
# Mesh Connect's other operators only serve its popup.  The popup-opening
# commands of Mesh Align and Crease Preset carry the rest of their functions.
_SMS_NATIVE_EXECUTE_ONLY = {
    'connect': ('mesh.smart_connect',),
}
_SMS_NATIVE_EXECUTE_POPUP = {
    'mesh_align_preset': {'idname': 'mesh.mesh_align_master', 'label': 'Open Align Presets', 'icon': 'PRESET', 'description': ''},
    'crease_preset': {'idname': 'mesh.edge_crease_master', 'label': 'Open Crease Preset', 'icon': 'PRESET', 'description': ''},
}


def _sms_lazy_ui_execute_commands(kind: str, alias: str, snapshot=None):
    snapshot = snapshot if snapshot is not None else _sms_lazy_ui_snapshot_entry(kind, alias)
    commands = tuple(snapshot.get('operators') or ())
    if str(kind or '') != 'native':
        return commands
    only = _SMS_NATIVE_EXECUTE_ONLY.get(str(alias or ''))
    if only:
        commands = tuple(command for command in commands if str((command or {}).get('idname') or '') in only)
    popup = _SMS_NATIVE_EXECUTE_POPUP.get(str(alias or ''))
    if popup:
        commands = (popup,) + commands
    return commands


def _sms_draw_lazy_snapshot_body(layout, context, kind: str, alias: str, label: str = '') -> bool:
    """Draw immutable startup UI without importing or registering the tool."""
    snapshot = _sms_lazy_ui_snapshot_entry(kind, alias)
    proxy = _sms_lazy_ui_proxy(context)
    if not snapshot:
        return False
    if str(kind or '') == 'native' and str(alias or '') == 'model_organized':
        drawn = _sms_draw_lazy_model_organizer_body(layout, context, proxy)
        _sms_draw_keymap_registration_button(layout, context, kind, alias, label)
        return drawn

    settings = tuple(snapshot.get('settings') or ())
    if settings:
        box = layout.box()
        box.label(text=_pick_lang('Settings', '設定', context), icon='PREFERENCES')
        col = box.column(align=False)
        col.use_property_split = False
        col.use_property_decorate = False
        drawn_settings = 0
        seen_keys = set()
        for setting in settings:
            prop_key = str((setting or {}).get('proxy_key') or '').strip()
            if not prop_key or prop_key in seen_keys:
                continue
            seen_keys.add(prop_key)
            if _sms_lazy_ui_prop(col, proxy, setting, context):
                drawn_settings += 1
        if not drawn_settings:
            box.label(text=_pick_lang('No editable settings were found.', '編集可能な設定は見つかりませんでした。', context))

    menus = tuple(snapshot.get('menus') or ())
    if menus:
        box = layout.box()
        box.label(text=_pick_lang('Menus', 'メニュー', context), icon='MENU_PANEL')
        for command in menus:
            _sms_lazy_ui_command(kind, alias, box, context, command, command_kind='menu')

    operators = _sms_lazy_ui_execute_commands(kind, alias, snapshot)
    if operators:
        box = layout.box()
        box.label(text=_pick_lang('Execution', '実行', context), icon='PLAY')
        for command in operators:
            _sms_lazy_ui_command(kind, alias, box, context, command, command_kind='operator')

    _sms_draw_keymap_registration_button(layout, context, kind, alias, label)
    return bool(settings or menus or operators)


# Narrow-space layout for the Smart Modeling hub.  Every width here is in
# unscaled UI pixels: text is measured with blf at the widget point size and
# region widths are divided by the effective UI scale.  Measured on Blender
# 5.1.2: a panel body is the region width minus about 32 px of margins, the
# category tab column of a UI region takes 20 px, a popover body is
# bl_ui_units_x (default 10) * 20 px, and a tool row header spends about 118 px
# of the body on the arrow, icon, settings icon and Help button.  When a name
# does not fit, it moves to its own wrapped row instead of being cut with "...".
_SMS_HUB_TAB_COLUMN_PX = 20.0
_SMS_HUB_PANEL_MARGINS_PX = 32.0
_SMS_HUB_POPOVER_UNITS = 10
_SMS_HUB_TOOL_ROW_OVERHEAD_PX = 118.0
_SMS_HUB_TITLE_FACTOR = 0.87 * 0.74
_SMS_HUB_TITLE_PADDING_PX = 16.0
_SMS_HUB_BOX_PX = 10.0
_SMS_HUB_LINE_PADDING_PX = 14.0
# Panel header, measured on Blender 5.1.2: the header is 16 px wider than the
# body, the title starts 22 px from its left edge (after the collapse arrow),
# the drag grip takes the last 20 px and the Help button drawn by
# draw_header_preset takes about 20 px just left of the grip.  With the Help
# button the title has about body - 46 px; 54 keeps 8 px of margin.  Without
# the title the Help button has body + 16 - 22 - 20 = body - 26 px and needs 24.
_SMS_HUB_PANEL_HEADER_OVERHEAD_PX = 70.0 - 16.0
_SMS_HUB_PANEL_HEADER_BARE_PX = 42.0 - 16.0
_SMS_HUB_HEADER_HELP_PX = 24.0
# Body width of the panel that is drawing right now (0 = unknown).
_SMS_HUB_CONTENT_PX = [0.0]


def _sms_hub_ui_scale(context) -> float:
    try:
        scale = float(context.preferences.system.ui_scale)
    except Exception:
        scale = 1.0
    if scale <= 0.0:
        scale = 1.0
    return min(4.0, max(0.5, scale))


def _sms_hub_tab_column_pixels(context) -> float:
    try:
        region_type = str(getattr(getattr(context, 'region', None), 'type', '') or '')
        space_type = str(getattr(getattr(context, 'space_data', None), 'type', '') or '')
    except Exception:
        return 0.0
    if region_type == 'UI' or (space_type == 'CLIP_EDITOR' and region_type == 'TOOLS'):
        return _SMS_HUB_TAB_COLUMN_PX
    return 0.0


def _sms_hub_region_content_pixels(context) -> float:
    try:
        width = float(getattr(getattr(context, 'region', None), 'width', 0) or 0)
    except Exception:
        width = 0.0
    if width <= 0.0:
        return 0.0
    content = width / _sms_hub_ui_scale(context) - _sms_hub_tab_column_pixels(context) - _SMS_HUB_PANEL_MARGINS_PX
    return max(1.0, content)


def _sms_hub_panel_content_pixels(panel, context) -> float:
    try:
        if bool(getattr(panel, 'is_popover', False)):
            units = int(getattr(panel, 'bl_ui_units_x', 0) or 0) or _SMS_HUB_POPOVER_UNITS
            return float(units) * 20.0
    except Exception:
        pass
    return _sms_hub_region_content_pixels(context)


def _sms_hub_content_pixels(context) -> float:
    try:
        current = float(_SMS_HUB_CONTENT_PX[0] or 0.0)
    except Exception:
        current = 0.0
    if current > 0.0:
        return current
    return _sms_hub_region_content_pixels(context)


def _sms_hub_text_pixels(text, context) -> float:
    text = str(text or '')
    if not text:
        return 0.0
    try:
        from . import help as _sms_help
        return float(_sms_help._sms_text_pixel_width(text, context))
    except Exception:
        return float(len(text)) * 11.0


def _sms_hub_fits(text_px, room_px, content_px) -> bool:
    # An unknown body width keeps the original one-row layout.
    if content_px <= 0.0:
        return True
    return float(text_px) <= float(room_px)


def _sms_hub_wrap_lines(text, width_px, context):
    text = str(text or '').strip()
    if not text:
        return []
    try:
        from . import help as _sms_help
        lines = _sms_help._sms_wrap_help_text(
            text,
            context=context,
            max_pixels=max(40.0, float(width_px)),
            min_pixels=40.0,
        )
    except Exception:
        lines = [text]
    lines = [str(line) for line in (lines or ()) if str(line or '').strip()]
    return lines or [text]


def _sms_hub_header_help_fits(panel, context) -> bool:
    """True when the panel title and the header Help button share the header."""
    try:
        if bool(getattr(panel, 'is_popover', False)):
            return True
    except Exception:
        return True
    content_px = _sms_hub_region_content_pixels(context)
    label = str(getattr(panel, 'bl_label', '') or 'Smart Modeling')
    widths = [_sms_hub_text_pixels(label, context)]
    try:
        widths.append(_sms_hub_text_pixels(bpy.app.translations.pgettext_iface(label), context))
    except Exception:
        pass
    return _sms_hub_fits(max(widths), content_px - _SMS_HUB_PANEL_HEADER_OVERHEAD_PX, content_px)


def _sms_hub_header_help_alone_fits(panel, context) -> bool:
    """True when the header Help button fits once the title has left the header."""
    try:
        if bool(getattr(panel, 'is_popover', False)):
            return True
    except Exception:
        return True
    content_px = _sms_hub_region_content_pixels(context)
    return _sms_hub_fits(_SMS_HUB_HEADER_HELP_PX, content_px - _SMS_HUB_PANEL_HEADER_BARE_PX, content_px)


def _sms_hub_draw_section_header(box, context, *, show_prop, label, expanded, icon, help_kind, help_alias, count_text=''):
    """Draw a collapsible section header in the shared Smart Tools format."""

    def _toggle(layout, text, toggle_icon, emboss, translate=True):
        kwargs = {'text': text, 'emboss': emboss, 'depress': bool(expanded), 'translate': translate}
        if toggle_icon:
            kwargs['icon'] = toggle_icon
        op = layout.operator('smart_modeling_suite.toggle_ui_section', **kwargs)
        op.section_key = str(show_prop)
        op.label = label
        return op

    header = box.row(align=True)
    header.use_property_split = False
    header.use_property_decorate = False
    # Shared Smart Tools section header: triangle, borderless icon+title, small gap, compact help.
    _toggle(header, '', 'TRIA_DOWN' if expanded else 'TRIA_RIGHT', True)
    if count_text:
        _toggle(header, _pick_lang('%s (%s)', '%s（%s）', context) % (label, count_text), icon, False, translate=False)
    else:
        _toggle(header, label, icon, False)
    try:
        header.separator(factor=0.35)
    except Exception:
        pass
    _sms_draw_help_icon_button(header, help_kind, help_alias, label, context)


def _sms_hub_toggle_row_metrics(context):
    """Split factor and name room shared by every Enabled / Disabled row."""
    content_px = _sms_hub_content_pixels(context)
    row_px = content_px - _SMS_HUB_BOX_PX if content_px > 0.0 else 0.0
    if row_px <= 0.0:
        return 0.72, 0.0, 0.0
    button_px = max(
        _sms_hub_text_pixels(_pick_lang('Enabled', '有効', context), context),
        _sms_hub_text_pixels(_pick_lang('Disabled', '無効', context), context),
    ) + 20.0 + _SMS_HUB_LINE_PADDING_PX
    factor = min(0.72, max(0.2, 1.0 - button_px / row_px))
    return factor, factor * row_px - 12.0, row_px


def _sms_hub_draw_toggle_row(col, context, label, owner, prop_name, enabled, metrics):
    del metrics
    row = col.row(align=True)
    row.scale_y = 0.95
    split = row.split(factor=0.72, align=True)
    left = split.row(align=True)
    left.label(text=label)
    button = split.row(align=True)
    button.alignment = 'RIGHT'
    button.use_property_split = False
    button.use_property_decorate = False
    button_label = _pick_lang('On', '有効', context) if enabled else _pick_lang('Off', '無効', context)
    button_icon = 'CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT'
    button.row(align=True).prop(
        owner,
        prop_name,
        text=button_label,
        icon=button_icon,
        toggle=True,
    )


def _sms_draw_unified_item_entry(layout, context, prefs, item):
    kind = str(item.get('kind') or '').strip()
    label = _sms_suite_panel_item_label(item, context) if str(item.get('kind') or '') == 'suite_panel' else _ui_text(str(item.get('label') or '').strip(), context)
    show_prop = str(item.get('show_prop') or '').strip()
    runtime_group = _sms_item_runtime_group(item)
    icon = _sms_safe_icon(item.get('icon'), 'TOOL_SETTINGS')
    if not label:
        return

    expanded = _sms_ui_section_state_get(prefs, show_prop, False) if show_prop else False
    enabled = _sms_unified_item_enabled(prefs, item)

    pending_alias = ''
    if kind == 'native':
        pending_alias = str((item.get('meta') or {}).get('tool_id') or '').strip()
    elif kind == 'integrated':
        pending_alias = str((item.get('spec') or {}).get('alias') or '').strip()

    # Panel.draw remains read-only.  Unloaded tools are represented by immutable
    # startup UI metadata; only a command button crosses the transactional load
    # boundary and registers the selected tool implementation.

    status_text, status_icon = _sms_unified_item_runtime_badge(context, prefs, item)

    help_kind = kind
    help_alias = ''
    if kind == 'native':
        help_alias = str((item.get('meta') or {}).get('tool_id') or '').strip()
    elif kind == 'integrated':
        help_alias = str((item.get('spec') or {}).get('alias') or '').strip()
    elif kind == 'suite_panel':
        help_alias = str(item.get('id') or '').strip()

    tool_box = layout.box()
    # A name that does not fit beside the arrow, icon, settings icon and Help
    # button gets its own wrapped rows above the header instead of "...".
    content_px = _sms_hub_content_pixels(context)
    status_px = (_sms_hub_text_pixels(status_text, context) + 20.0 + _SMS_HUB_LINE_PADDING_PX) if status_text else 0.0
    name_on_own_row = not _sms_hub_fits(
        _sms_hub_text_pixels(label, context),
        content_px - _SMS_HUB_TOOL_ROW_OVERHEAD_PX - status_px,
        content_px,
    )
    if name_on_own_row:
        names = tool_box.column(align=True)
        for line in _sms_hub_wrap_lines(label, content_px - 34.0, context):
            names.label(text=line, translate=False)
        if status_text:
            status = tool_box.row(align=True)
            status.enabled = True
            status.label(text=status_text, icon=status_icon)
    if show_prop and prefs is not None and _sms_rna_prop_exists(prefs, show_prop):
        row, panel_body = tool_box.panel_prop(prefs, show_prop)
    else:
        panel_key = ''.join(
            char if (char.isalnum() or char == '_') else '_'
            for char in (show_prop or f'{kind}_{help_alias or label}')
        )
        row, panel_body = tool_box.panel(
            f'SMART_MODELING_PT_TOOL_{panel_key}',
            default_closed=not bool(expanded),
        )
    row.use_property_split = False
    row.use_property_decorate = False
    row.label(text='' if name_on_own_row else label, icon=_sms_safe_icon(icon, 'TOOL_SETTINGS'))

    right = row.row(align=True)
    right.alignment = 'RIGHT'
    right.enabled = True
    right.label(text='', icon='PREFERENCES')
    _sms_draw_help_icon_button(right, help_kind, help_alias, label, context, leading_gap=True)

    if status_text and not name_on_own_row:
        status = right.row(align=True)
        status.enabled = True
        status.label(text=status_text, icon=status_icon)

    if panel_body is None:
        return

    detail = panel_body.box()
    detail.use_property_split = False
    detail.use_property_decorate = False

    if not enabled:
        detail.label(text=_pick_lang('Always-on is off.', 'この常時機能は無効です。', context), icon='HIDE_OFF')

    if pending_alias and _sms_on_demand_load_pending(kind, pending_alias):
        detail.label(text=_pick_lang('Loading tool settings.', 'ツール設定を読み込んでいます。', context), icon='TIME')
        if kind in {'native', 'integrated'}:
            _sms_draw_keymap_registration_button(detail, context, kind, pending_alias, label)
        return

    load_status = _sms_load_status_for_item(kind, pending_alias) if pending_alias else ''
    if pending_alias and load_status == 'loading':
        detail.label(text=_pick_lang('Loading tool settings.', 'ツール設定を読み込んでいます。', context), icon='TIME')
        if kind in {'native', 'integrated'}:
            _sms_draw_keymap_registration_button(detail, context, kind, pending_alias, label)
        return
    if kind in {'native', 'integrated'} and pending_alias and load_status in {'disabled', 'unsupported_platform'}:
        detail.label(text=_pick_lang('Disabled', '無効', context), icon='HIDE_OFF')
        return
    if kind in {'native', 'integrated'} and pending_alias and load_status not in {'loaded', 'failed'}:
        body = detail.column(align=False)
        body.use_property_split = False
        body.use_property_decorate = False
        if not _sms_draw_lazy_snapshot_body(body, context, kind, pending_alias, label):
            warn = detail.box()
            warn.alert = True
            warn.label(text=_pick_lang('Initial tool UI is unavailable.', '初期ツールUIを利用できません。', context), icon='ERROR')
        return

    body = detail.column(align=False)
    body.use_property_split = False
    body.use_property_decorate = False

    if kind == 'native':
        _sms_draw_native_unified_body(body, context, prefs, dict(item.get('meta') or {}))
        return

    if kind == 'integrated':
        try:
            _sms_loader = sys.modules.get(f'{__package__}.loader')
            alias = str((item.get('spec') or {}).get('alias') or '')
            record = _sms_loader.get_record(alias) if _sms_loader is not None else {}
        except Exception:
            record = {}
        _sms_draw_integrated_unified_body(body, context, dict(item.get('spec') or {}), record or {})
        return

    if kind == 'suite_panel':
        _sms_draw_suite_panel_body(body, context, prefs, item)
        return


def _sms_always_on_control_items(flat_items):
    # This list is strictly for actual resident services.  Click-only and modal
    # tools remain available in their normal sections and never gain a misleading
    # startup switch merely because they have an enable preference internally.
    by_key = {}
    try:
        for item in tuple(flat_items or ()):  # pragma: no branch
            kind = str((item or {}).get('kind') or '').strip()
            if kind == 'native':
                tool_id = str(((item or {}).get('meta') or {}).get('tool_id') or '').strip()
                if tool_id:
                    by_key[(kind, tool_id)] = item
            elif kind == 'integrated':
                alias = str(((item or {}).get('spec') or {}).get('alias') or '').strip()
                if alias:
                    by_key[(kind, alias)] = item
            elif kind == 'suite_panel':
                item_id = str((item or {}).get('id') or '').strip()
                if item_id:
                    by_key[(kind, item_id)] = item
    except Exception:
        by_key = {}

    result = []
    seen = set()
    for spec in tuple(globals().get('_SMS_ALWAYS_ON_TOOL_SPECS', ())):
        spec = dict(spec or {})
        kind = str(spec.get('kind') or '').strip()
        key_value = str(spec.get('tool_id') or spec.get('alias') or spec.get('id') or '').strip()
        enable_prop = str(spec.get('enable_prop') or '').strip()
        if not kind or not key_value or not enable_prop or enable_prop in seen:
            continue
        if kind == 'native' and not _sms_native_tool_has_persistent_load(key_value):
            continue
        if kind == 'integrated' and not _sms_integrated_tool_has_persistent_load(key_value):
            continue
        if kind == 'suite_panel':
            continue
        item = dict(by_key.get((kind, key_value), {}) or {})
        item.update(spec)
        item.setdefault('runtime_group', 'persistent')
        item['kind'] = kind
        item['enable_prop'] = enable_prop
        if kind == 'native':
            meta = dict(item.get('meta') or _sms_native_tool_meta(key_value) or {})
            if not meta:
                meta = {'tool_id': key_value, 'toggle': enable_prop, 'label': str(spec.get('label_en') or key_value)}
            meta['tool_id'] = key_value
            meta.setdefault('toggle', enable_prop)
            meta.setdefault('label', str(spec.get('label_en') or key_value))
            item['meta'] = meta
            item.setdefault('label', str(spec.get('label_en') or key_value))
        elif kind == 'integrated':
            item.setdefault('spec', {'alias': key_value, 'display_name': str(spec.get('label_en') or key_value)})
            item.setdefault('label', str(spec.get('label_en') or key_value))
        elif kind == 'suite_panel':
            item.setdefault('id', key_value)
            item.setdefault('label_en', str(spec.get('label_en') or key_value))
            item.setdefault('label_ja', str(spec.get('label_ja') or spec.get('label_en') or key_value))
        seen.add(enable_prop)
        result.append(item)
    # Polycount is owned by the UI-lazy Key Operation Tools module.  Once that
    # module has been explicitly materialized, expose its *original* RNA in the
    # canonical top section.  No proxy Bool is introduced: both this row and the
    # local Polycount row edit scene.polycount_props.auto_update_polycount.
    try:
        scene = getattr(getattr(bpy, 'context', None), 'scene', None)
        polycount_props = getattr(scene, 'polycount_props', None) if scene is not None else None
        if polycount_props is not None and hasattr(polycount_props, 'auto_update_polycount'):
            result.append({
                'kind': 'dynamic_runtime',
                'owner_path': 'scene.polycount_props',
                'enable_prop': 'auto_update_polycount',
                'label_en': 'Polycount Auto Update',
                'label_ja': 'ポリカウント自動更新',
                'runtime_group': 'persistent',
            })
    except Exception:
        pass
    # Vertex Copy owns three optional live draw handlers.  Their local N-panel
    # rows and these top-level rows intentionally edit the exact same RNA;
    # materializing the tool adds the rows, while an unopened tool creates no
    # proxy properties and no startup work.
    try:
        scene = getattr(getattr(bpy, 'context', None), 'scene', None)
        dynamic_vertex_copy = (
            ('vscp_settings', 'show_gpu_preview', 'Vertex Copy GPU Preview', '頂点コピーGPUプレビュー'),
            ('vscpx_settings', 'enable_advanced_preview', 'Vertex Copy Advanced Preview', '頂点コピー拡張プレビュー'),
            ('vscpz_settings', 'show_mapping_edit_overlay', 'Vertex Copy Mapping Overlay', '頂点コピー対応ライン表示'),
        )
        for owner_name, prop_name, label_en, label_ja in dynamic_vertex_copy:
            owner = getattr(scene, owner_name, None) if scene is not None else None
            if owner is None or not hasattr(owner, prop_name):
                continue
            result.append({
                'kind': 'dynamic_runtime',
                'owner_path': f'scene.{owner_name}',
                'enable_prop': prop_name,
                'label_en': label_en,
                'label_ja': label_ja,
                'runtime_group': 'persistent',
            })
    except Exception:
        pass
    return result


def _sms_draw_always_on_toggles_group(layout, context, prefs, flat_items):
    items = _sms_always_on_control_items(flat_items)
    if not items:
        return 0
    box = layout.box()
    show_prop = 'ui_show_always_on_toggles'
    header_label = _pick_lang('Always-on Toggles', '常時機能切り替え', context)
    expanded = _sms_ui_section_state_get(prefs, show_prop, False)
    _sms_hub_draw_section_header(
        box,
        context,
        show_prop=show_prop,
        label=header_label,
        expanded=expanded,
        icon=_sms_safe_icon('TIME', 'TOOL_SETTINGS'),
        help_kind='runtime_group',
        help_alias='always_on_toggles',
    )
    if not expanded:
        return len(items)
    toggle_metrics = _sms_hub_toggle_row_metrics(context)

    col = box.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False

    try:
        from . import common as _sms_common
        settings_error = str(_sms_common.settings_load_error() or '').strip()
        if settings_error:
            warning = col.box()
            warning.alert = True
            warning.label(text=_pick_lang('Settings file was preserved because it could not be read or written.', '設定ファイルを読み書きできないため、既存ファイルを保持しました。', context), icon='ERROR')
            warning.label(text=settings_error[:240])
    except Exception:
        pass

    # Keep this at the top of the startup-runtime section as the master
    # N-panel-state persistence control requested by the user.  It uses the same
    # split/operator layout as every tool row so the 有効 / 無効 button width is
    # identical.
    try:
        enabled = _sms_npanel_state_save_enabled(context=context, prefs=prefs, default=True)
        _sms_hub_draw_toggle_row(
            col,
            context,
            _pick_lang('N-panel State Save', 'Nパネル状態保存', context),
            prefs,
            'n_panel_state_save',
            enabled,
            toggle_metrics,
        )
        col.separator(factor=0.5)
    except Exception:
        pass

    for item in items:
        if str((item or {}).get('label_en') or '').strip() or str((item or {}).get('label_ja') or '').strip():
            label = _pick_lang(str((item or {}).get('label_en') or '').strip(), str((item or {}).get('label_ja') or '').strip(), context)
        else:
            label = _sms_suite_panel_item_label(item, context) if str(item.get('kind') or '') == 'suite_panel' else _ui_text(str(item.get('label') or '').strip(), context)
        if not label:
            continue
        enable_prop = str(item.get('enable_prop') or '').strip()
        if not enable_prop:
            continue
        prop_owner = prefs
        if str(item.get('kind') or '') == 'dynamic_runtime':
            try:
                prop_owner = context
                for part in tuple(p for p in str(item.get('owner_path') or '').split('.') if p):
                    prop_owner = getattr(prop_owner, part, None)
                    if prop_owner is None:
                        break
            except Exception:
                prop_owner = None
        if prop_owner is None or not hasattr(prop_owner, enable_prop):
            continue
        if str(item.get('kind') or '') == 'dynamic_runtime':
            try:
                enabled = bool(getattr(prop_owner, enable_prop))
            except Exception:
                enabled = False
        else:
            enabled = _sms_persistent_toggle_state_get(enable_prop, context=context, prefs=prefs, default=False)
        _sms_hub_draw_toggle_row(col, context, label, prop_owner, enable_prop, enabled, toggle_metrics)
    return len(items)


def _sms_draw_workflow_tool_groups(layout, context, prefs, flat_items):
    for category, section_items in _sms_group_unified_items(flat_items):
        if not section_items:
            continue
        cat_id = str(category.get('id') or '').strip()
        cat_show_prop = f'ui_show_category_{cat_id}'
        cat_expanded = _sms_ui_section_state_get(prefs, cat_show_prop, True)
        cat_box = layout.box()
        cat_box.use_property_split = False
        cat_box.use_property_decorate = False
        cat_label = _pick_lang(str(category.get('label_en') or cat_id), str(category.get('label_ja') or cat_id), context)
        _sms_hub_draw_section_header(
            cat_box,
            context,
            show_prop=cat_show_prop,
            label=cat_label,
            expanded=cat_expanded,
            icon=_sms_safe_icon(category.get('icon'), 'TOOL_SETTINGS'),
            help_kind='workflow_category',
            help_alias=cat_id,
            count_text=str(len(section_items)),
        )
        if not cat_expanded:
            continue
        # Stable Blender UI rule: keep every tool entry as a sibling inside one
        # category-local column.  Do not generate child Panel classes or nested
        # cumulative columns for lower categories; otherwise old Panel RNA can
        # make rows appear progressively indented after in-place updates.
        column = cat_box.column(align=False)
        column.use_property_split = False
        column.use_property_decorate = False
        for item in tuple(section_items or ()):  # pragma: no branch
            try:
                _sms_draw_unified_item_entry(column, context, prefs, item)
            except Exception as exc:
                warn = column.box()
                warn.alert = True
                label = str((item or {}).get('label') or 'Tool').strip() or 'Tool'
                warn.label(
                    text=_pick_lang(
                        f'Failed to draw {label}: {str(exc)[:180]}',
                        f'{label} の描画に失敗しました: {str(exc)[:180]}',
                        context,
                    ),
                    icon='ERROR',
                )


def _sms_draw_enable_disable_group(layout, context, prefs, flat_items):
    _sms_draw_always_on_toggles_group(layout, context, prefs, flat_items)
    _sms_draw_workflow_tool_groups(layout, context, prefs, flat_items)

def _sms_draw_unified_tools_ui(layout, context, prefs, *, host='preferences'):
    del host
    layout.use_property_split = False
    layout.use_property_decorate = False
    if prefs is None or not _sms_rna_data_is_current(prefs):
        try:
            prefs = _sms_get_suite_prefs(context)
        except Exception:
            prefs = None
    if prefs is None or not _sms_rna_data_is_current(prefs):
        _sms_draw_npanel_settings_unavailable(layout, context)
        return

    grouped_sections = _sms_group_unified_items(_sms_build_unified_items(context, prefs))
    flat_items = _sms_flatten_unified_items(grouped_sections)
    if not flat_items:
        layout.label(text=_pick_lang('No tools are available.', '利用可能なツールがありません。', context))
        return

    # Settings are restored at registration/load-post and saved from property
    # update callbacks.  Re-reading and re-writing the full settings snapshot from
    # Panel.draw() makes every 3D View redraw heavier, including orbit/pan/zoom.
    _sms_draw_enable_disable_group(layout, context, prefs, flat_items)


translation_dict["ja_JP"].update({
    ("*", "Help"): "ヘルプ",
    ("*", "Show this tool's function overview, usage method, and setting item reference."): "このツールの機能概要、使用方法、設定項目の解説を表示します。",
    ("*", "Show function overview, usage method, and setting items."): "機能概要、使用方法、設定項目を表示します。",
    ("*", "Tool Function Overview"): "ツールの機能概要",
    ("*", "Tool Feature Overview"): "ツールの機能概要",
    ("*", "Tool Usage"): "ツールの使用方法",
    ("*", "Setting Items"): "設定項目",
    ("*", "Keymap Registration"): "キーマップ登録",
    ("*", "Panel UI"): "パネルUI",
    ("*", "Menus"): "メニュー",
    ("*", "Operators"): "オペレーター",
    ("*", "Command Section"): "コマンド項目",
    ("*", "Linked Tool Settings"): "連携ツール設定",
    ("*", "Discovered Operators"): "検出済みオペレーター",
    ("*", "Preferences"): "プリファレンス",
    ("*", "No additional setting items are exposed in this tool settings section."): "このツールの設定欄に追加設定項目はありません。",
    ("*", "Smart Modeling Help"): "Smart Modeling ヘルプ",
    ("*", "Display detailed Smart Modeling tool help."): "Smart Modeling ツールの詳細ヘルプを表示します。",
    ("*", "Open detailed help for this Smart Modeling tool."): 'このツールの詳しいヘルプを開きます。',
    
    ("*", "Help is not available for this tool."): "このツールのヘルプは利用できません。",
    ("*", "Failed to open help: {message}"): "ヘルプを開けませんでした: {message}",
    ("*", "Tool"): "ツール",
})


def _sms_apply_localization_successor_patch() -> None:
    """Apply the canonical Japanese catalog after every legacy catalog update."""
    try:
        from . import localization_successor_patch as _sms_localization_patch
        apply_fn = getattr(_sms_localization_patch, 'apply', None)
        if callable(apply_fn):
            apply_fn(translation_dict)
    except Exception:
        pass


def _sms_refresh_canonical_translations() -> None:
    """Keep the suite catalog authoritative after an on-demand tool registers."""
    _sms_apply_localization_successor_patch()
    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass
    try:
        bpy.app.translations.register(__name__, translation_dict)
    except Exception:
        pass


_sms_apply_localization_successor_patch()

_sms_add_dynamic_preference_props()


def _sms_draw_preferences_empty(self, context):
    del self, context
    return None


if __name__ == "__main__":
    register()

# --- Tooltip completion (suite wrappers) ---
for _sms_desc_class_name, _sms_desc_text in (
    ('VIEW3D_PT_sms_modifier_suite_notice', "Explains the updated split between stack-manageable modifier tools and non-stack companion workflows."),
    ('VIEW3D_PT_sms_mesh_align', "Open the Mesh Align wrapper panel for common alignment, flatten, projection, and distribution helpers."),
    ('VIEW3D_PT_sms_mesh_align_help', "Beginner-friendly usage notes for the Mesh Align wrapper panel."),
    ('VIEW3D_PT_sms_crease_preset', "Open the Crease Preset wrapper panel for quick hard-surface crease application and preset management."),
    ('VIEW3D_PT_sms_crease_preset_help', "Beginner-friendly usage notes for crease presets, popup access, and overlay checks."),
    ('VIEW3D_PT_sms_apply_weighted_normal', "Open the Apply Weighted Normal wrapper panel for quick shading cleanup on hard-surface meshes."),
    ('VIEW3D_PT_sms_apply_weighted_normal_help', "Beginner-friendly usage notes for weighted-normal cleanup and preset choice."),
    ('VIEW3D_PT_sms_modifier_companion_tools', "Grouped non-stack companion utility and generator tools that remain outside Smart Modifier's stack-side Add Modifier flow."),
):
    _sms_desc_class = globals().get(_sms_desc_class_name)
    if _sms_desc_class is not None:
        _sms_desc_class.bl_description = _sms_desc_text
del _sms_desc_class_name, _sms_desc_text, _sms_desc_class
# Sketch / Quad Strip panel descriptions are assigned lazily after those
# tools load, to keep startup imports minimal.



translation_dict["ja_JP"].update({
    ("*", "Explains the updated split between stack-manageable modifier tools and non-stack companion workflows."): "スタック管理できるモディファイア系ツールと、非スタックの補助ワークフローの新しい役割分担を案内します。",
    ("*", "Open the Mesh Align wrapper panel for common alignment, flatten, projection, and distribution helpers."): '整列・平坦化・投影・分布の補助をまとめたメッシュ整列のパネルを開きます。',
    ("*", "Beginner-friendly usage notes for the Mesh Align wrapper panel."): "Mesh Align ラッパーパネル向けの初心者用ガイドです。",
    ("*", "Open the Crease Preset wrapper panel for quick hard-surface crease application and preset management."): 'ハードサーフェス向けのクリース適用とプリセット管理を行うクリースプリセットラッパーパネルです。',
    ("*", "Beginner-friendly usage notes for crease presets, popup access, and overlay checks."): "クリースプリセット、ポップアップ起動、オーバーレイ確認向けの初心者用ガイドです。",
    ("*", "Open the Apply Weighted Normal wrapper panel for quick shading cleanup on hard-surface meshes."): 'ハードサーフェスのメッシュのシェーディングを整える、重み付き法線のパネルです。',
    ("*", "Beginner-friendly usage notes for weighted-normal cleanup and preset choice."): "重み付き法線の整理とプリセット選択向けの初心者用ガイドです。",
    ("*", "Grouped non-stack companion utility and generator tools that remain outside Smart Modifier's stack-side Add Modifier flow."): 'Smart Modifier の追加メニューに含まれない補助ツールと生成ツールをまとめて表示します。',
    ("*", "Always-on Feature Toggles"): "常時機能切り替え",
    ("*", "This always-on feature is disabled."): "この常時機能は無効です。",
    ("*", "Enable it in the Always-on Toggles group at the top before loading its settings."): "設定を読み込む前に、最上部の「常時機能切り替え」で有効にしてください。",
    ("*", "Loading tool settings."): "ツール設定を読み込んでいます。",
    ("*", "Vertex Copy Always-on Runtime"): "頂点コピー常時機能ランタイム",
    ("*", "Direct Delete Always-on Runtime"): '直接削除常時機能ランタイム',
    ("*", "Merge Snap Always-on Runtime"): 'マージとスナップの常時機能',
    ("*", "Apply Weighted Normal Menu Runtime"): '重み付き法線 メニューランタイム',
    ("*", "Controls Vertex Copy live preview and draw-handler based runtime. Disabled means the tool stays unloaded and light until explicitly used; enable only when you need live background preview support while modeling."): "頂点コピーのライブプレビューと描画ハンドラー系ランタイムを制御します。起動を軽くする場合は無効にし、バックグラウンドのプレビュー補助が必要な時だけ有効にしてください。",
    ("*", "Controls Direct Delete preview/runtime only. It never registers Delete / Backspace keymaps automatically; bind the shown operator IDs manually if you need shortcuts."): '直接削除のプレビュー / ランタイムのみを制御します。Delete / Backspace キーマップは自動登録されないため、必要な場合は表示された登録IDを手動で割り当ててください。',
    ("*", "Controls Merge Snap status/header runtime and related automatic indicators. Disabled removes the always-visible status/header integration; enable only when you need persistent merge/snap status or shortcut support."): 'マージとスナップのステータス / ヘッダーランタイムと自動表示を制御します。無効時は常時表示されるステータス / ヘッダー連携を外し、マージ / スナップ状態の常時表示やショートカット補助が必要な時だけ有効にしてください。',
    ("*", "Controls the persistent Alt+N normals menu integration for Apply Weighted Normal. Disabled keeps the normals menu untouched and light; enable only when you frequently need the Alt+N menu entry in edit mode."): '重み付き法線 の Alt+N 法線メニュー常時登録を制御します。無効時は法線メニューへ登録せず軽量に保ち、編集モードで Alt+N のメニュー項目を頻繁に使う場合だけ有効にしてください。',
    ("*", "Controls Key Ops Toolkit handlers, menu hooks, and tablet / outliner background integration. Key Ops shortcuts remain manual-only and are never installed automatically."): 'キー操作ツール のハンドラー、メニュー連携、タブレット / アウトライナー連携を制御します。Key Ops のショートカットは手動登録専用で、自動登録されません。',
    ("*", "Controls Tissue frame-change handlers used by animated tessellation and reaction-diffusion workflows. Keep this disabled unless you need automatic frame updates."): "Tissue のアニメーションテッセレーションやリアクション拡散で使うフレーム変更ハンドラーを制御します。自動フレーム更新が必要な時だけ有効にしてください。",
    ("*", "Controls Vertex Copy live preview and draw-handler based runtime. Disabled means the tool stays unloaded and light until explicitly used; enable only when you need live background preview support while modeling."): "頂点コピーのライブプレビューと描画ハンドラー系ランタイムを制御します。無効時は明示的に使うまでツールを読み込まず軽量な状態を保ち、モデリング中にライブ背景プレビューが必要な時だけ有効にしてください。",
    ("*", "Controls Direct Delete preview/runtime only. It never registers Delete / Backspace keymaps automatically; bind the shown operator IDs manually if you need shortcuts."): '直接削除のプレビュー / ランタイムのみを制御します。Delete / Backspace キーマップは自動登録されないため、必要な場合は表示された登録IDを手動で割り当ててください。',
    ("*", "Controls Merge Snap status/header runtime and related automatic indicators. Disabled removes the always-visible status/header integration; enable only when you need persistent merge/snap status or shortcut support."): 'マージとスナップのステータス / ヘッダーランタイムと自動表示を制御します。無効時は常時表示されるステータス / ヘッダー連携を外し、マージ / スナップ状態の常時表示やショートカット補助が必要な時だけ有効にしてください。',
    ("*", "Controls the persistent Alt+N normals menu integration for Apply Weighted Normal. Disabled keeps the normals menu untouched and light; enable only when you frequently need the Alt+N menu entry in edit mode."): '重み付き法線 の Alt+N 法線メニュー常時登録を制御します。無効時は法線メニューへ登録せず軽量に保ち、編集モードで Alt+N のメニュー項目を頻繁に使う場合だけ有効にしてください。',
    ("*", "Controls Key Ops Toolkit handlers, menu hooks, and tablet / outliner background integration. Key Ops shortcuts remain manual-only and are never installed automatically."): 'キー操作ツール のハンドラー、メニュー連携、タブレット / アウトライナー連携を制御します。Key Ops のショートカットは手動登録専用で、自動登録されません。',
    ("*", "Enable Curve Tools"): 'カーブツールを有効化',
    ("*", "Controls Curve Tools file export menu entries and curve/object context-menu hooks. Keep this disabled unless you want those curve menus to stay available outside this N-panel."): "Curve Tools のファイル書き出しメニュー項目とカーブ / オブジェクトのコンテキストメニュー連携を制御します。このNパネル外でもカーブ系メニューを常時使いたい時だけ有効にしてください。",
    ("*", "Controls Curve Tools export menu entries and curve/object context-menu hooks. Enable it only when you want those menus available at all times."): "Curve Tools の書き出しメニュー項目とカーブ / オブジェクトのコンテキストメニュー連携を制御します。これらのメニューを常時使いたい時だけ有効にしてください。",
})

translation_dict["ja_JP"].update({
    ("*", "Always-on Feature Toggles"): "常時機能切り替え",
    ("*", "Click-only Commands"): "クリック起動コマンド",
    ("*", "Show Always-on Toggles"): "常時機能切り替えを表示",
    ("*", "Show Click-only Commands"): "クリック起動コマンドを表示",
    ("*", "Edit and Transfer"): "編集と転送",
    ("*", "Delete and Cleanup"): "削除と整理",
    ("*", "Hard Surface Modeling"): 'ハードサーフェス',
    ("*", "Command Browser"): 'コマンドブラウザー',
    ("*", "Modifier Companion"): "モディファイア補助",
    ("*", "Show Command Browser"): 'コマンドブラウザーを表示',
    ("*", "Show Modifier Companion"): 'モディファイア補助を表示',
    ("*", "Show Sketch and Retopo"): 'スケッチとリトポを表示',
    ("*", "Show Mesh Connect"): 'メッシュ接続を表示',
    ("*", "Show Sketch Surface"): 'スケッチサーフェスを表示',
    ("*", "Show Quad Retopo"): 'クアッドリトポを表示',
    ("*", "Modeling Toolkit"): "統合モデリングツール",
    ("*", "Show Modeling Toolkit"): 'モデリングツールを表示',
    ("*", "Settings and commands are loaded automatically when this section is opened."): "このセクションを開くと、設定とコマンドは自動で読み込まれます。",
    ("*", "Settings and commands can still be loaded automatically; enable the always-on toggle only when persistent background behavior is needed."): "設定とコマンドは自動で読み込めます。常時機能切り替えは、バックグラウンド動作が必要な場合だけ有効にしてください。",
    ("*", "Loading command browser."): "コマンドブラウザーを読み込んでいます。",
    ("*", "Start Modifier Companion"): "モディファイア補助を起動",
    ("*", "Load Modifier Companion command buttons only after you explicitly start this click-start section."): "クリック起動コマンドのこの項目を明示的に起動した後だけ、モディファイア補助のコマンドボタンを読み込みます。",
    ("*", "This click-start tool is displayed without loading its runtime until you start it."): "このクリック起動コマンドツールは、起動するまでランタイムを読み込まずUIのみ表示します。",
    ("*", "This click-start section keeps companion modules unloaded until you start it."): "このクリック起動コマンド項目は、起動するまで補助モジュールを読み込みません。",
})


SMS_NPanelSettings.bl_description = "Smart Modeling N-panel settings are stored in the versioned Blender config folder Smart_Modeling_Suite/Smart_Modeling_Suite.json and restored at Blender startup and scene load."



translation_dict["ja_JP"].update({
    ("*", "Compact Hub UI"): "コンパクトハブUI",
    ("*", "Use Compact Hub UI"): "コンパクトハブUIを使用",
    ("*", "Show Legacy Detailed Panels"): "従来の詳細パネルを表示",
    ("*", "Default Smart Modeling N-panel layout is grouped into a small hub and legacy detail panels stay hidden."):
        "既定では Smart Modeling Nパネルの内容を小さなハブへまとめ、従来の詳細パネルは非表示になります。",
    ("*", "Compact Hub is off, so the original detailed panels stay visible."):
        "Compact Hub がオフのため、元の詳細パネルが表示されたままになります。",
})



translation_dict["ja_JP"].update({
    ("*", "Internal helper text that will be copied to the system clipboard."): "システムクリップボードへコピーされる内部補助テキストです。",
    ("*", "Reveal the original detailed panels alongside the compact hub."):
        "コンパクトハブと並べて、元の詳細パネル群も表示します。",
    ("*", "Show Vertex Copy"): '頂点コピーを表示',
    ("*", "Expand or collapse the Vertex Copy section inside the Smart Modeling N-panel."): 'N パネルの頂点コピーの項目を開閉します。',
    ("*", "Show Vertex Slide"): '頂点スライドを表示',
    ("*", "Expand or collapse the Vertex Slide section inside the Smart Modeling N-panel."): 'N パネルの頂点スライドの項目を開閉します。',
    ("*", "Show Direct Delete"): '直接削除を表示',
    ("*", "Expand or collapse the Direct Delete section inside the Smart Modeling N-panel."): 'N パネルの直接削除の項目を開閉します。',
    ("*", "Show Model Organizer"): 'モデル整理を表示',
    ("*", "Expand or collapse the Model Organizer section inside the Smart Modeling N-panel."): 'N パネルのモデル整理の項目を開閉します。',
    ("*", "Show Mesh Align"): 'メッシュ整列を表示',
    ("*", "Expand or collapse the Mesh Align section inside the Smart Modeling N-panel."): 'N パネルのメッシュ整列の項目を開閉します。',
    ("*", "Show Crease Preset"): 'クリースプリセットを表示',
    ("*", "Expand or collapse the Crease Preset section inside the Smart Modeling N-panel."): 'N パネルのクリースプリセットの項目を開閉します。',
    ("*", "Show Merge Snap"): 'マージとスナップを表示',
    ("*", "Expand or collapse the Merge Snap section inside the Smart Modeling N-panel."): 'N パネルのマージとスナップの項目を開閉します。',
    ("*", "Show Apply Weighted Normal"): '重み付き法線を表示',
    ("*", "Expand or collapse the Apply Weighted Normal section inside the Smart Modeling N-panel."): 'N パネルの重み付き法線の項目を開閉します。',
})

# --- Auto-localized raw tooltip strings (no dual-language display) ---
translation_dict["ja_JP"].update({
    ("*", 'Adjust Changed Verts. Larger or smaller values change the strength, amount, size, or precision used by the related tool.'): '変更した頂点を調整します。値を大きくまたは小さくすると、関連ツールで使う強さ、量、サイズ、または精度が変わります。',
    ("*", 'Adjust Copy Source. Larger or smaller values change the strength, amount, size, or precision used by the related tool.'): 'コピー元を調整します。値を大きくまたは小さくすると、関連ツールで使う強さ、量、サイズ、または精度が変わります。',
    ("*", 'Adjust Custom Presets. Larger or smaller values change the strength, amount, size, or precision used by the related tool.'): 'カスタムプリセットを調整します。値を大きくまたは小さくすると、関連ツールで使う強さ、量、サイズ、または精度が変わります。',
    ("*", 'Adjust Cycle Order Index. Larger or smaller values change the strength, amount, size, or precision used by the related tool.'): '巡回の順の番号を調整します。値を大きくまたは小さくすると、関連ツールで使う強さ、量、サイズ、または精度が変わります。',
    ("*", 'Adjust Edit Line Width. Larger or smaller values change the strength, amount, size, or precision used by the related tool.'): '編集時の線の太さを調整します。値を大きくまたは小さくすると、関連ツールで使う強さ、量、サイズ、または精度が変わります。',
    ("*", 'Adjust Edit Point Size. Larger or smaller values change the strength, amount, size, or precision used by the related tool.'): '編集時の点のサイズを調整します。値を大きくまたは小さくすると、関連ツールで使う強さ、量、サイズ、または精度が変わります。',
    ("*", 'Adjust Excluded Target. Larger or smaller values change the strength, amount, size, or precision used by the related tool.'): '除外する対象を調整します。値を大きくまたは小さくすると、関連ツールで使う強さ、量、サイズ、または精度が変わります。',
    ("*", 'Adjust Landmark Active. Larger or smaller values change the strength, amount, size, or precision used by the related tool.'): 'アクティブな目印を調整します。値を大きくまたは小さくすると、関連ツールで使う強さ、量、サイズ、または精度が変わります。',
    ("*", 'Adjust Low Confidence Threshold. Larger or smaller values change the strength, amount, size, or precision used by the related tool.'): '低信頼のしきい値を調整します。値を大きくまたは小さくすると、関連ツールで使う強さ、量、サイズ、または精度が変わります。',
    ("*", 'Adjust Mapping Count. Larger or smaller values change the strength, amount, size, or precision used by the related tool.'): '対応の数を調整します。値を大きくまたは小さくすると、関連ツールで使う強さ、量、サイズ、または精度が変わります。',
    ("*", 'Adjust Material. Larger or smaller values change the strength, amount, size, or precision used by the related tool.'): 'マテリアルを調整します。値を大きくまたは小さくすると、関連ツールで使う強さ、量、サイズ、または精度が変わります。',
    ("*", 'Adjust Normal. Larger or smaller values change the strength, amount, size, or precision used by the related tool.'): '法線を調整します。値を大きくまたは小さくすると、関連ツールで使う強さ、量、サイズ、または精度が変わります。',
    ("*", 'Adjust Paste Target. Larger or smaller values change the strength, amount, size, or precision used by the related tool.'): '貼り付け先を調整します。値を大きくまたは小さくすると、関連ツールで使う強さ、量、サイズ、または精度が変わります。',
    ("*", 'Adjust Pick Radius (px). Larger or smaller values change the strength, amount, size, or precision used by the related tool.'): '選択の半径 (px)を調整します。値を大きくまたは小さくすると、関連ツールで使う強さ、量、サイズ、または精度が変わります。',
    ("*", 'Adjust Row. Larger or smaller values change the strength, amount, size, or precision used by the related tool.'): '行を調整します。値を大きくまたは小さくすると、関連ツールで使う強さ、量、サイズ、または精度が変わります。',
    ("*", 'Adjust Run Report. Larger or smaller values change the strength, amount, size, or precision used by the related tool.'): '実行の報告を調整します。値を大きくまたは小さくすると、関連ツールで使う強さ、量、サイズ、または精度が変わります。',
    ("*", 'Adjust Select Copy Source. Larger or smaller values change the strength, amount, size, or precision used by the related tool.'): 'コピー元を選択を調整します。値を大きくまたは小さくすると、関連ツールで使う強さ、量、サイズ、または精度が変わります。',
    ("*", 'Adjust Select Paste Target. Larger or smaller values change the strength, amount, size, or precision used by the related tool.'): '貼り付け先を選択を調整します。値を大きくまたは小さくすると、関連ツールで使う強さ、量、サイズ、または精度が変わります。',
    ("*", 'Adjust Select. Larger or smaller values change the strength, amount, size, or precision used by the related tool.'): '選択を調整します。値を大きくまたは小さくすると、関連ツールで使う強さ、量、サイズ、または精度が変わります。',
    ("*", 'Adjust Slot Index. Larger or smaller values change the strength, amount, size, or precision used by the related tool.'): 'スロットの番号を調整します。値を大きくまたは小さくすると、関連ツールで使う強さ、量、サイズ、または精度が変わります。',
    ("*", 'Adjust Slot. Larger or smaller values change the strength, amount, size, or precision used by the related tool.'): 'スロットを調整します。値を大きくまたは小さくすると、関連ツールで使う強さ、量、サイズ、または精度が変わります。',
    ("*", 'Adjust Source Index. Larger or smaller values change the strength, amount, size, or precision used by the related tool.'): '元の番号を調整します。値を大きくまたは小さくすると、関連ツールで使う強さ、量、サイズ、または精度が変わります。',
    ("*", 'Adjust UV. Larger or smaller values change the strength, amount, size, or precision used by the related tool.'): 'UV を調整します。値を大きくまたは小さくすると、関連ツールで使う強さ、量、サイズ、または精度が変わります。',
    ("*", 'Adjust Weight. Larger or smaller values change the strength, amount, size, or precision used by the related tool.'): 'ウェイトを調整します。値を大きくまたは小さくすると、関連ツールで使う強さ、量、サイズ、または精度が変わります。',
    ("*", 'Apply Weighted Normal panel in the Smart Modeling workspace.'): 'Smart Modeling ワークスペース内の Apply Weighted Normal パネルです。',
    ("*", 'Batch renaming and collection organization helpers for cleaner scenes.'): '一括リネームとコレクション整理でシーンを整える補助パネルです。',
    ("*", 'Beginner-friendly usage notes for Auto Merge / Snap toggle presets and cycling behavior. / Auto Merge'): '自動マージ / スナップの切り替えのプリセットと順送りの動きの説明です。',
    ("*", 'Beginner-friendly usage notes for Direct Delete and shortcut setup.'): '直接削除とショートカット設定向けの初心者用ガイドです。',
    ("*", 'Beginner-friendly usage notes for Vertex Copy.'): '頂点コピー向けの初心者用ガイドです。',
    ("*", 'Beginner-friendly usage notes for Vertex Slide.'): 'Vertex Slide 向けの初心者用ガイドです。',
    ("*", 'Beginner-friendly workflow notes for Model Organizer.'): 'モデル整理向けの初心者用ガイドです。',
    ("*", 'Mapping method used when AUTO cannot use an exact vertex match.'): '自動で頂点を完全一致できない時に使う対応方式です。',
    ("*", 'Choose how Direction works. Pick the mode that best matches the current task and modeling workflow.'): '方向の動作方法を選びます。現在の作業内容に合うモードを選択してください。',
    ("*", 'Choose how Mirror Axis works. Pick the mode that best matches the current task and modeling workflow.'): 'ミラーの軸の動作方法を選びます。現在の作業内容に合うモードを選択してください。',
    ("*", 'Choose how Preset works. Pick the mode that best matches the current task and modeling workflow.'): 'プリセットの動作方法を選びます。現在の作業内容に合うモードを選択してください。',
    ("*", 'Choose how Preview Mode works. Pick the mode that best matches the current task and modeling workflow.'): 'プレビューモードの動作方法を選びます。現在の作業内容に合うモードを選択してください。',
    ("*", 'Choose which source-to-target mapping lines appear in the preview.'): 'プレビューに表示する、コピー元と貼り付け先を結ぶ線を選びます。',
    ("*", 'Choose how Status works. Pick the mode that best matches the current task and modeling workflow.'): '状態の動作方法を選びます。現在の作業内容に合うモードを選択してください。',
    ("*", 'Filter which report targets are re-validated or pasted again.'): 'レポートから再検証・再貼り付けする対象を絞り込みます。',
    ("*", 'Choose how Workflow works. Pick the mode that best matches the current task and modeling workflow.'): '作業の流れの動作方法を選びます。現在の作業内容に合うモードを選択してください。',
    ("*", 'Choose the primary Direct Delete mode and how the shortcut behaves.'): '直接削除の主動作モードとショートカット時の挙動を選びます。',
    ("*", 'Clean Data panel in the Smart Modeling workspace.'): 'Smart Modeling ワークスペースのデータ整理のパネルです。',
    ("*", 'Close the generated strip so the last stroke point connects back to the first.'): '生成したストリップを閉じ、最後のストローク点を最初の点へ接続します。',
    ("*", 'Collection for Custom Presets. The tool stores multiple items here, such as presets, reports, backups, or temporary entries.'): '指定のプリセットの内部のコレクションです。',
    ("*", 'Collection for Cycle Order. The tool stores multiple items here, such as presets, reports, backups, or temporary entries.'): '巡回の順用のコレクションです。プリセット、レポート、バックアップ、一時項目など複数のデータをここに保持します。',
    ("*", 'Collection for Excluded Targets. The tool stores multiple items here, such as presets, reports, backups, or temporary entries.'): '除外した対象の内部のコレクションです。',
    ("*", 'Collection for Fixed Pairs. The tool stores multiple items here, such as presets, reports, backups, or temporary entries.'): '固定の組用のコレクションです。プリセット、レポート、バックアップ、一時項目など複数のデータをここに保持します。',
    ("*", 'Collection for Landmark Items. The tool stores multiple items here, such as presets, reports, backups, or temporary entries.'): '目印の内部のコレクションです。',
    ("*", 'Collection for Last Run Reports. The tool stores multiple items here, such as presets, reports, backups, or temporary entries.'): '前回の実行の報告の内部のコレクションです。',
    ("*", 'Collection for Mo2 Backup Items. The tool stores multiple items here, such as presets, reports, backups, or temporary entries.'): 'モデル整理のバックアップの内部のコレクションです。',
    ("*", 'Collection for Selected Pairs. The tool stores multiple items here, such as presets, reports, backups, or temporary entries.'): '選択した組の内部のコレクションです。',
    ("*", 'Compact cleanup tools that group direct delete and model organization.'): '直接削除とモデル整理をまとめたコンパクトなクリーンアップツールです。',
    ("*", 'Compact edit tools: slide, vertex copy, and alignment helpers.'): 'スライド、頂点コピー、整列補助をまとめたコンパクト編集ツールです。',
    ("*", 'Compact hard-surface helpers for crease, normals, and snap state control.'): 'クリース、法線、スナップ状態をまとめたコンパクトなハードサーフェス補助です。',
    ("*", 'Compact main panel for organizing, cleaning, and standardizing selected objects before export or further modeling.'): '選択オブジェクトを整理・クリーニング・標準化して、書き出しや次工程に備えるためのコンパクトなメインパネルです。',
    ("*", 'Compact panel for toggling Auto Merge and snapping presets quickly while modeling.'): 'モデリング中に自動マージとスナッププリセットを素早く切り替えるためのコンパクトなパネルです。',
    ("*", "Companion utility and generator tools moved out of Smart Modifier's compact N-panel area."): 'Smart Modifier のコンパクトなNパネル領域から外した補助ツールと生成系ツールの一覧です。',
    ("*", 'Configure per-element behavior for vertices, edges, and faces when deleting instantly.'): '頂点・辺・面を即削除する際の要素別挙動を設定します。',
    ("*", 'Crease Preset panel in the Smart Modeling workspace.'): 'Smart Modeling ワークスペース内の Crease Preset パネルです。',
    ("*", 'Create cyclic curves from the sampled strokes.'): '取得したストロークから閉じたカーブを作成します。',
    ("*", 'Delete Through panel in the Smart Modeling workspace.'): 'Smart Modeling ワークスペースの貫通削除のパネルです。',
    ("*", 'Direct Delete panel in the Smart Modeling workspace.'): 'Smart Modeling ワークスペース内の Direct Delete パネルです。',
    ("*", 'Direct sketch helpers for turning annotation strokes into modeling guide curves without moving them into the modifier stack.'): '注釈ストロークをモディファイアスタックへ移さず、モデリング用ガイドカーブへ変換するダイレクトスケッチ補助です。',
    ("*", 'Draw a viewport preview of the current selection or affected area only while you need it. The draw callback is disabled by default so it does not stay active during startup or normal editing.'): '必要な時だけ現在の選択や影響範囲のビューポートプレビューを描画します。起動時や通常編集時に描画コールバックが常駐しないよう既定ではオフです。',
    ("*", 'Draw paste candidates in the 3D View only when you need preview feedback. Disabled by default to avoid always-on viewport callbacks during startup and normal editing.'): '必要な時だけ 3D ビューに貼り付け候補を描画します。起動時や通常編集時の常駐コールバック負荷を避けるため既定ではオフです。',
    ("*", 'Enable or disable Automerge Managed. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.'): '自動マージの管理を有効または無効にします。関連機能を使いたいときはオン、より単純または安全なワークフローにしたいときはオフにします。',
    ("*", 'Enable or disable Clipboard. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.'): 'クリップボードを有効または無効にします。関連機能を使いたいときはオン、より単純または安全なワークフローにしたいときはオフにします。',
    ("*", 'Enable or disable Custom Presets. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.'): 'カスタムプリセットを有効または無効にします。関連機能を使いたいときはオン、より単純または安全なワークフローにしたいときはオフにします。',
    ("*", 'Enable or disable Extra Data Transfer. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.'): '追加データの転送を有効または無効にします。関連機能を使いたいときはオン、より単純または安全なワークフローにしたいときはオフにします。',
    ("*", 'Enable or disable GPU Preview. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.'): 'GPU プレビューを有効または無効にします。関連機能を使いたいときはオン、より単純または安全なワークフローにしたいときはオフにします。',
    ("*", 'Enable or disable Last Run Report. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.'): '前回の実行の報告を有効または無効にします。関連機能を使いたいときはオン、より単純または安全なワークフローにしたいときはオフにします。',
    ("*", 'Enable or disable Notes. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.'): 'メモを有効または無効にします。関連機能を使いたいときはオン、より単純または安全なワークフローにしたいときはオフにします。',
    ("*", 'Enable or disable Overwrite Confirmed. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.'): '上書きの確認済みを有効または無効にします。関連機能を使いたいときはオン、より単純または安全なワークフローにしたいときはオフにします。',
    ("*", 'Enable or disable Overwrite Same Name. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.'): '同名の上書きを有効または無効にします。関連機能を使いたいときはオン、より単純または安全なワークフローにしたいときはオフにします。',
    ("*", 'Enable or disable Paste Candidate Filtering. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.'): '貼り付け候補の絞り込みを有効または無効にします。関連機能を使いたいときはオン、より単純または安全なワークフローにしたいときはオフにします。',
    ("*", 'Enable or disable Replace. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.'): '置き換えを有効または無効にします。関連機能を使いたいときはオン、より単純または安全なワークフローにしたいときはオフにします。',
    ("*", 'Enable or disable Select. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.'): '選択を有効または無効にします。関連機能を使いたいときはオン、より単純または安全なワークフローにしたいときはオフにします。',
    ("*", 'Highlight target vertices for which no source match was found.'): 'コピー元との対応が見つからない貼り付け先の頂点を強調表示します。',
    ("*", 'Enable or disable Smart / Surface Settings. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow. / Smart'): 'Surface Settings を有効または無効にします。関連機能を使いたいときはオン、より単純または安全なワークフローにしたいときはオフにします。',
    ("*", 'Enable or disable Smart Matching Algorithm. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.'): 'スマート判定の方式を有効または無効にします。関連機能を使いたいときはオン、より単純または安全なワークフローにしたいときはオフにします。',
    ("*", 'Enable or disable Snap Managed. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.'): 'スナップの管理を有効または無効にします。関連機能を使いたいときはオン、より単純または安全なワークフローにしたいときはオフにします。',
    ("*", 'Enable or disable Soft Wrap Extension. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.'): 'ソフトラップの拡張を有効または無効にします。関連機能を使いたいときはオン、より単純または安全なワークフローにしたいときはオフにします。',
    ("*", 'Enable or disable Transfer Settings. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.'): '転送の設定を有効または無効にします。関連機能を使いたいときはオン、より単純または安全なワークフローにしたいときはオフにします。',
    ("*", 'Enable or disable Use-case Presets. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.'): '用途別プリセットを有効または無効にします。関連機能を使いたいときはオン、より単純または安全なワークフローにしたいときはオフにします。',
    ("*", 'Enable smooth shading on the generated sketch surface strip.'): '生成したスケッチ面ストリップでスムーズシェードを有効にします。',
    ("*", 'Explains the new split: Smart Modifier keeps the stack UI, while non-stack companion tools are surfaced from Smart Modeling.'): 'スタックの画面は Smart Modifier に、それ以外の補助ツールは Smart Modeling にあります。',
    ("*", 'Extended Vertex Copy workflow panel with reporting, staged actions, and safer transfer review.'): 'レポート、段階実行、安全なコピー確認を含む拡張頂点コピーワークフローパネルです。',
    ("*", 'Guide / Tips help panel with workflow notes and beginner guidance.'): 'ワークフローの補足と初心者向けガイドを表示するヘルプパネルです。',
    ("*", 'Ignore strokes with fewer sampled points than this value.'): 'この値より少ない点しか持たないストロークは無視します。',
    ("*", 'Internal base operator class used by the suite.'): 'ツールセット内で共有される内部オペレーター基底クラスです。',
    ("*", 'Legacy/plus Vertex Copy panel kept for compatibility and alternate workflows.'): '互換性と別系統ワークフローのために残している頂点コピーの 旧来のパネルです。',
    ("*", 'Load this tool when its settings section is opened.'): 'このツールの設定セクションを開いた時に読み込みます。',
    ("*", 'Main Smart Modeling panel in the standard 3D View Sidebar N-panel.'): '標準の3DビューサイドバーNパネルに表示する Smart Modeling のメインパネルです。',
    ("*", 'Main Vertex Copy panel for copy, preview, matching inspection, and controlled transfer workflows.'): 'コピー、プレビュー、対応確認、制御付き転送を行う頂点コピーのメインパネルです。',
    ("*", 'Main Vertex Slide panel for fast constrained sliding, HUD options, and proportional support.'): '速い拘束スライド、画面表示の設定、プロポーショナル対応をまとめた頂点スライドのパネルです。',
    ("*", 'Main panel for instant delete behaviors, delete-through, topology-aware cleanup, and post-process options.'): '即削除、貫通選択を削除、トポロジー配慮、後処理オプションをまとめた直接削除メインパネルです。',
    ("*", 'Mesh Align panel in the Smart Modeling workspace.'): 'Smart Modeling ワークスペース内の Mesh Align パネルです。',
    ("*", 'Mode panel in the Smart Modeling workspace.'): 'Smart Modeling ワークスペースのモードのパネルです。',
    ("*", 'Model Organizer panel in the Smart Modeling workspace.'): 'Smart Modeling ワークスペース内の Model Organizer パネルです。',
    ("*", 'Modifier cleanup, apply, keep, and organization helpers for safer object housekeeping.'): 'モディファイア整理、適用、保持、整理を行う安全寄りのオブジェクト管理パネルです。',
    ("*", 'Modifiers panel in the Smart Modeling workspace.'): 'Smart Modeling ワークスペースのモディファイアーのパネルです。',
    ("*", 'Optional curve bevel depth applied to the generated guide curve. Leave at 0 for a pure path.'): '生成ガイドカーブに任意で付けるベベル深さです。0 のままなら純粋なパスになります。',
    ("*", 'Optional post-process steps that run after the delete action completes.'): '削除処理の後に実行する任意の後処理ステップです。',
    ("*", 'Options for deleting through occluded or stacked mesh elements.'): '隠れた要素や重なったメッシュを貫通選択を削除するための設定です。',
    ("*", 'Origin and pivot helpers for reorganizing object control points safely.'): 'オブジェクトの原点とピボットを安全に整理する補助パネルです。',
    ("*", 'Overlay pinned/excluded/selected mapping lines in the 3D View only when you need manual line editing. Disabled by default so the viewport callback stays off during normal work.'): '手動ライン編集が必要な時だけ 3D ビューに固定・除外・選択ラインを表示します。通常作業中にビューポートコールバックが常駐しないよう既定ではオフです。',
    ("*", 'Per-Element Action panel in the Smart Modeling workspace.'): 'Smart Modeling ワークスペースの要素ごとの操作のパネルです。',
    ("*", 'Per-pair editing panel for pinned, excluded, relinked, and batch-edited mapping lines.'): '固定、除外、再リンク、一括編集された対応ラインを個別調整するパネルです。',
    ("*", 'Post Process panel in the Smart Modeling workspace.'): 'Smart Modeling ワークスペースの後処理のパネルです。',
    ("*", 'Run a native Smart Modeling command or open a migrated menu from the Smart Modeling N-panel.'): 'Smart Modeling の N パネルからコマンドを実行するか、メニューを開きます。',
    ("*", 'Settings for sketch-to-curve helpers.'): 'スケッチ→カーブ補助の設定です。',
    ("*", 'Shared settings pointer for Apply Weighted Normal. This links the suite to another internal settings group used by the related tool.'): '重み付き法線 用の共有設定ポインターです。関連ツールが使う内部設定グループへの参照を保持します。',
    ("*", 'Shared settings pointer for Crease Preset. This links the suite to another internal settings group used by the related tool.'): 'クリースプリセット用の共有設定ポインターです。関連ツールが使う内部設定グループへの参照を保持します。',
    ("*", 'Shared settings pointer for Direct Delete. This links the suite to another internal settings group used by the related tool.'): '直接削除用の共有設定ポインターです。関連ツールが使う内部設定グループへの参照を保持します。',
    ("*", 'Shared settings pointer for Mesh Align. This links the suite to another internal settings group used by the related tool.'): 'メッシュ整列の設定への内部の参照です。',
    ("*", 'Shared settings pointer for Model Organizer. This links the suite to another internal settings group used by the related tool.'): 'モデル整理の設定への内部の参照です。',
    ("*", 'Shared settings pointer for Toggle Auto Merge Snap. This links the suite to another internal settings group used by the related tool.'): '自動マージとスナップの設定への内部の参照です。',
    ("*", 'Shared settings pointer for Vertex Slide. This links the suite to another internal settings group used by the related tool.'): '頂点スライド用の共有設定ポインターです。関連ツールが使う内部設定グループへの参照を保持します。',
    ("*", 'Show the v12 color-coded preview only while you need comparison feedback. Disabled by default so this preview callback does not stay active all the time.'): '比較確認が必要な時だけ v12 の色分けプレビューを表示します。常時コールバックが動かないよう既定ではオフです。',
    ("*", 'Vertex Copy panel in the Smart Modeling workspace.'): 'Smart Modeling ワークスペース内の頂点コピーパネルです。',
    ("*", 'Vertex Slide panel in the Smart Modeling workspace.'): 'Smart Modeling ワークスペース内の Vertex Slide パネルです。',
    ("*", 'Stores runtime state for Merge Snap.'): 'マージとスナップの実行時の状態を保持します。',
    ("*", 'Stores settings for Direct Delete.'): 'Direct Delete の設定を保持します。',
    ("*", 'Stores settings for Model Organizer.'): 'Model Organizer の設定を保持します。',
    ("*", 'Stores settings for Vertex Copy Extension Lines.'): '頂点コピー拡張ラインの設定を保持します。',
    ("*", 'Stores settings for Vertex Copy Extension Plus.'): '頂点コピーの拡張の設定を保持します。',
    ("*", 'Stores settings for Vertex Copy Extension.'): '頂点コピー拡張の設定を保持します。',
    ("*", 'Stores settings for Vertex Copy.'): '頂点コピーの設定を保持します。',
    ("*", 'Stores temporary backup entries for Model Organizer.'): 'モデル整理の一時バックアップ項目を保持します。',
    ("*", 'Text field for Action. Use it to enter a name, filter, note, identifier, or other text used by the tool.'): '動作用のテキスト入力欄です。名前、フィルター、メモ、識別子などを入力するために使います。',
    ("*", 'Text field for Automerge Backup Json. Use it to enter a name, filter, note, identifier, or other text used by the tool.'): '自動マージの控え用のテキスト入力欄です。名前、フィルター、メモ、識別子などを入力するために使います。',
    ("*", 'Text field for Backup Name. Use it to enter a name, filter, note, identifier, or other text used by the tool.'): '控えの名前用のテキスト入力欄です。名前、フィルター、メモ、識別子などを入力するために使います。',
    ("*", 'Text field for Clipboard Info. Use it to enter a name, filter, note, identifier, or other text used by the tool.'): 'クリップボードの情報用のテキスト入力欄です。名前、フィルター、メモ、識別子などを入力するために使います。',
    ("*", 'Text field for Details. Use it to enter a name, filter, note, identifier, or other text used by the tool.'): '詳細用のテキスト入力欄です。名前、フィルター、メモ、識別子などを入力するために使います。',
    ("*", 'Text field for Export Name. Use it to enter a name, filter, note, identifier, or other text used by the tool.'): '書き出しの名前用のテキスト入力欄です。名前、フィルター、メモ、識別子などを入力するために使います。',
    ("*", 'Text field for Filter Glob. Use it to enter a name, filter, note, identifier, or other text used by the tool.'): '絞り込みのパターン用のテキスト入力欄です。名前、フィルター、メモ、識別子などを入力するために使います。',
    ("*", 'Text field for Name. Use it to enter a name, filter, note, identifier, or other text used by the tool.'): '名前用のテキスト入力欄です。名前、フィルター、メモ、識別子などを入力するために使います。',
    ("*", 'Text field for Object. Use it to enter a name, filter, note, identifier, or other text used by the tool.'): 'オブジェクト用のテキスト入力欄です。名前、フィルター、メモ、識別子などを入力するために使います。',
    ("*", 'Text field for Original Name. Use it to enter a name, filter, note, identifier, or other text used by the tool.'): '元の名前用のテキスト入力欄です。名前、フィルター、メモ、識別子などを入力するために使います。',
    ("*", 'Text field for Phase. Use it to enter a name, filter, note, identifier, or other text used by the tool.'): '段階用のテキスト入力欄です。名前、フィルター、メモ、識別子などを入力するために使います。',
    ("*", 'Text field for Run Summary. Use it to enter a name, filter, note, identifier, or other text used by the tool.'): '実行の要約用のテキスト入力欄です。名前、フィルター、メモ、識別子などを入力するために使います。',
    ("*", 'Text field for Select Show. Use it to enter a name, filter, note, identifier, or other text used by the tool.'): '選択を表示用のテキスト入力欄です。名前、フィルター、メモ、識別子などを入力するために使います。',
    ("*", 'Text field for SettingsJSON. Use it to enter a name, filter, note, identifier, or other text used by the tool.'): '設定データ用のテキスト入力欄です。名前、フィルター、メモ、識別子などを入力するために使います。',
    ("*", 'Text field for Snap Backup Json. Use it to enter a name, filter, note, identifier, or other text used by the tool.'): 'スナップの控え用のテキスト入力欄です。名前、フィルター、メモ、識別子などを入力するために使います。',
    ("*", 'Text field for Status. Use it to enter a name, filter, note, identifier, or other text used by the tool.'): '状態用のテキスト入力欄です。名前、フィルター、メモ、識別子などを入力するために使います。',
    ("*", 'Merge Snap panel in the Smart Modeling workspace.'): 'Smart Modeling ワークスペースのマージとスナップのパネルです。',
    ("*", 'Topology Aware panel in the Smart Modeling workspace.'): 'Smart Modeling ワークスペースのトポロジー考慮のパネルです。',
    ("*", 'Topology-aware safeguards and cleanup choices to reduce messy results after delete.'): '削除後の乱れを減らすための、トポロジー配慮設定とクリーンアップ項目です。',
    ("*", 'Transform cleanup helpers for scale, rotation, and data-safe normalization workflows.'): 'スケール、回転、各種正規化を整理するトランスフォーム補助パネルです。',
    ("*", 'Transforms panel in the Smart Modeling workspace.'): 'Smart Modeling ワークスペースのトランスフォームのパネルです。',
    ("*", 'Vector or color setting for All Lines Color. Use this to control color, direction, or other multi-value data used by the interface or tool.'): 'すべての線の色です。',
    ("*", 'Vector or color setting for Excluded Line Color. Use this to control color, direction, or other multi-value data used by the interface or tool.'): '除外した線の色です。',
    ("*", 'Vector or color setting for High Confidence Color. Use this to control color, direction, or other multi-value data used by the interface or tool.'): '信頼度が高い対応の色です。',
    ("*", 'Vector or color setting for Landmark Line Color. Use this to control color, direction, or other multi-value data used by the interface or tool.'): '目印の線の色です。',
    ("*", 'Vector or color setting for Low Confidence Color. Use this to control color, direction, or other multi-value data used by the interface or tool.'): '信頼度が低い対応の色です。',
    ("*", 'Vector or color setting for Low Confidence Line Color. Use this to control color, direction, or other multi-value data used by the interface or tool.'): '信頼度が低い線の色です。',
    ("*", 'Vector or color setting for Medium Confidence Color. Use this to control color, direction, or other multi-value data used by the interface or tool.'): '信頼度が中くらいの対応の色です。',
    ("*", 'Vector or color setting for Pinned Line Color. Use this to control color, direction, or other multi-value data used by the interface or tool.'): '固定した線の色です。',
    ("*", 'Vector or color setting for Replacement Target Color. Use this to control color, direction, or other multi-value data used by the interface or tool.'): '置き換え先の色です。',
    ("*", 'Vector or color setting for Select. Use this to control color, direction, or other multi-value data used by the interface or tool.'): '選択用のベクトルまたはカラー設定です。色、方向、ユーティリティの複数値データを調整します。',
    ("*", 'Vector or color setting for Unmatched Color. Use this to control color, direction, or other multi-value data used by the interface or tool.'): '対応しない頂点の色です。',
    ("*", 'Vertex Copy v14 panel in the Smart Modeling workspace.'): 'Smart Modeling ワークスペースの頂点コピーのパネルです。',
    ("*", 'Width of the generated sketch surface strip. Useful for fast Bsurfaces-style ribbons, guides, straps, trims, and panel bands.'): '生成するスケッチ面ストリップの幅です。Bsurfaces 風のリボン面、ガイド、ストラップ、トリム、パネル帯の作成に使えます。',
})

# --- Manual corrections for slash-containing localized tooltips ---
translation_dict["ja_JP"].update({
    ("*", 'Beginner-friendly usage notes for Auto Merge / Snap toggle presets and cycling behavior.'): '自動マージ / スナップの切り替えのプリセットと順送りの動きの説明です。',
    ("*", 'Compact sketch and retopo hub that groups annotation conversion and quad-strip helpers.'): '注釈変換とクアッドストリップ補助をまとめたコンパクトなスケッチ / リトポハブです。',
    ("*", 'Complete Smart Modeling access panel for {label}.'): '{label} の全機能アクセスパネルです。',
    ("*", 'Convert annotation / grease pencil strokes into quick surface strips for Bsurfaces-style sketch blocking, straps, trims, panel bands, and retopo guides.'): '注釈 / グリースペンシルのストロークを、Bsurfaces風のスケッチブロック、ストラップ、トリム、パネル帯、リトポガイド向けの簡易面ストリップへ変換します。',
    ("*", 'Convert annotation / grease pencil strokes into reusable guide curves for direct modeling, blockout splines, trim routing, and Bsurfaces-style preparation.'): '注釈 / グリースペンシルのストロークを、ダイレクトモデリング用のガイドカーブ、ブロックアウト用スプライン、トリム配線、Bsurfaces風の準備に使える再利用可能なガイドカーブへ変換します。',
    ("*", 'Enable or disable Smart / Surface Settings. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.'): 'スマート / サーフェスの設定を有効または無効にします。関連機能を使う場合はオンにし、より単純または安全な操作にしたい場合はオフにします。',
    ("*", 'Integrated quad-strip drawing and retopo sketch panel grouped under Sketch Surface so strip creation, guide curves, and surface sketch helpers stay together.'): 'クアッドリトポ をスケッチサーフェス配下にまとめ、ストリップ作成、ガイドカーブ、サーフェススケッチ補助を同じ場所で扱います。',
    ("*", 'Mesh/data cleanup helpers for normals, doubles, unused slots, and similar maintenance tasks.'): '法線、重複、未使用スロットなどを整理するメッシュ / データ整理補助です。',
    ("*", 'Move the generated strip slightly toward or away from the current view.'): '作った帯を、今の表示の手前または奥へ少しずらします。',
    ("*", 'Origin / Pivot panel in the Smart Modeling workspace.'): 'Smart Modeling ワークスペースの原点 / ピボットのパネルです。',
    ("*", 'Read only the active annotation / grease pencil layer when building guide curves.'): 'ガイドカーブ作成時にアクティブな注釈 / グリースペンシルレイヤーだけを対象にします。',
    ("*", 'Rename / Collections panel in the Smart Modeling workspace.'): 'Smart Modeling ワークスペースの名前変更 / コレクションのパネルです。',
})

translation_dict["ja_JP"].update({
    ("*", "Toggle Vertex Slide"): "頂点スライドを切替",
    ("*", "Vertex Slide: ON"): "頂点スライド: ON",
    ("*", "Vertex Slide: OFF"): '頂点スライド: オフ',
    ("*", "Toggle Vertex Slide Constraint. While ON, normal G/R/S and transform gizmo edits slide along connected edges."):
        "頂点スライド制約を切り替えます。ONの間、通常のG/R/Sやトランスフォームギズモ操作が接続エッジ上のスライドになります。",
})


# Later compatibility catalogs intentionally remain in their original source
# locations. Re-apply the single canonical catalog after all of them so runtime
# lookup and the lazy-load refresh path resolve to the same values.
_sms_apply_localization_successor_patch()
