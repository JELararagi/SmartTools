# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

import time
import bpy
import bmesh
import blf
import gpu
from gpu_extras.batch import batch_for_shader
from bpy.app.handlers import persistent
from mathutils import Vector
from bpy_extras import view3d_utils

from .const import get_prefs, pref_get, pref_set
from .geom import (
    build_kdtree,
    vertices_within_radius,
    connected_distances_cutoff,
    falloff_weight,
    compute_loop_ring_sets,
)
from . import draw as drawutil
from .. import status_runtime as _status_runtime


_SVS_UNSET = object()


_SVS_TRANSIENT_SCENE_FLAG = "svs_vertex_slide_constraint_enabled"
_SVS_TRANSIENT_WM_FLAG = _SVS_TRANSIENT_SCENE_FLAG

_SVS_STATUSBAR_APPENDED = False
_SVS_STATUS_FLASH_UNTIL = 0.0
_SVS_LAST_STATUS_TEXT = ''
_SVS_WORKSPACE_STATUS_CLEAR_AT = 0.0

_SVS_TOGGLE_OVERLAY_HANDLE = None
_SVS_TOGGLE_OVERLAY_TEXT = ''
# Cursor anchor inside the target VIEW_3D WINDOW region. The draw callback
# lays the text box out directly below this anchor.
_SVS_TOGGLE_OVERLAY_POS = (80.0, 80.0)
_SVS_TOGGLE_OVERLAY_UNTIL = 0.0
# SpaceView3D draw handlers run for every 3D View. Store one concrete
# window/screen/area/region target so the temporary Vertex Slide notice is
# rendered only in the active view where the toggle was invoked.
_SVS_TOGGLE_OVERLAY_TARGET = None
_SVS_TOGGLE_OVERLAY_REPLAY_MANAGED = False
_SVS_ACTIVE_MODAL = None

_SVS_FRONT_POST_PIXEL_LAYER_POLICY_KEY = "JELARARAGI_VIEW3D_POST_PIXEL_LAYER_POLICY_V2"
_SVS_FRONT_POST_PIXEL_REPLAY_ACTIVE_KEY = "JELARARAGI_SMART_OVERLAY_FRONT_REPLAY_ACTIVE_V1"
_SVS_FRONT_POST_PIXEL_REPLAY_CONTEXT_KEY = "JELARARAGI_SMART_OVERLAY_FRONT_REPLAY_CONTEXT_V1"
_SVS_FRONT_POST_PIXEL_LAYER_OWNER = "smart_modeling_suite.vertex_slide_hud"
_SVS_FRONT_POST_PIXEL_LAYER_OWNER_TOKEN = object()


class _SVSToggleOverlaySnapshot:
    __slots__ = ("target", "text", "until", "shader", "batch", "text_x", "text_y")

    def __init__(self):
        self.target = None
        self.text = ""
        self.until = 0.0
        self.shader = None
        self.batch = None
        self.text_x = 0.0
        self.text_y = 0.0

    def clear(self):
        self.target = None
        self.text = ""
        self.until = 0.0
        self.shader = None
        self.batch = None
        self.text_x = 0.0
        self.text_y = 0.0


_SVS_TOGGLE_OVERLAY_SNAPSHOT = _SVSToggleOverlaySnapshot()


def _svs_set_active_modal(operator=None) -> None:
    global _SVS_ACTIVE_MODAL
    _SVS_ACTIVE_MODAL = operator


def _svs_overlay_front_replay_active() -> bool:
    try:
        return bool(bpy.app.driver_namespace.get(_SVS_FRONT_POST_PIXEL_REPLAY_ACTIVE_KEY, False))
    except Exception:
        return False


def _svs_rehook_front_post_pixel_handlers() -> bool:
    global _SVS_TOGGLE_OVERLAY_HANDLE, _SVS_TOGGLE_OVERLAY_REPLAY_MANAGED
    if not _svs_overlay_front_replay_active():
        return False
    rehooked = False
    operator = _SVS_ACTIVE_MODAL
    if operator is not None:
        callback = getattr(operator, '_rehook_post_pixel_handler_after_overlay', None)
        if callable(callback):
            try:
                rehooked = bool(callback()) or rehooked
            except Exception:
                pass
    if time.monotonic() <= float(_SVS_TOGGLE_OVERLAY_UNTIL or 0.0) and _SVS_TOGGLE_OVERLAY_SNAPSHOT.text:
        handle = _SVS_TOGGLE_OVERLAY_HANDLE
        if handle is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(handle, 'WINDOW')
            except Exception:
                pass
        _SVS_TOGGLE_OVERLAY_HANDLE = None
        try:
            _SVS_TOGGLE_OVERLAY_HANDLE = bpy.types.SpaceView3D.draw_handler_add(
                _svs_draw_toggle_overlay,
                (_SVS_TOGGLE_OVERLAY_SNAPSHOT,),
                'WINDOW',
                'POST_PIXEL',
            )
            rehooked = True
        except Exception:
            _SVS_TOGGLE_OVERLAY_HANDLE = None
    _SVS_TOGGLE_OVERLAY_REPLAY_MANAGED = False
    return rehooked


def _svs_release_front_post_pixel_handlers() -> bool:
    global _SVS_TOGGLE_OVERLAY_HANDLE, _SVS_TOGGLE_OVERLAY_REPLAY_MANAGED
    released = False
    operator = _SVS_ACTIVE_MODAL
    if operator is not None:
        callback = getattr(operator, '_ensure_independent_post_pixel_handler', None)
        if callable(callback):
            try:
                released = bool(callback()) or released
            except Exception:
                pass
    _SVS_TOGGLE_OVERLAY_REPLAY_MANAGED = False
    if (
        _SVS_TOGGLE_OVERLAY_HANDLE is None
        and time.monotonic() <= float(_SVS_TOGGLE_OVERLAY_UNTIL or 0.0)
        and _SVS_TOGGLE_OVERLAY_SNAPSHOT.text
    ):
        try:
            _SVS_TOGGLE_OVERLAY_HANDLE = bpy.types.SpaceView3D.draw_handler_add(
                _svs_draw_toggle_overlay,
                (_SVS_TOGGLE_OVERLAY_SNAPSHOT,),
                'WINDOW',
                'POST_PIXEL',
            )
            released = True
        except Exception:
            _SVS_TOGGLE_OVERLAY_HANDLE = None
    return released


def _svs_publish_front_post_pixel_layer_policy() -> bool:
    try:
        namespace = bpy.app.driver_namespace
        registry = namespace.get(_SVS_FRONT_POST_PIXEL_LAYER_POLICY_KEY)
        if registry is None:
            registry = {}
            namespace[_SVS_FRONT_POST_PIXEL_LAYER_POLICY_KEY] = registry
        elif not isinstance(registry, dict):
            return False
        registry[_SVS_FRONT_POST_PIXEL_LAYER_OWNER] = {
            'owner': _SVS_FRONT_POST_PIXEL_LAYER_OWNER,
            'owner_token': _SVS_FRONT_POST_PIXEL_LAYER_OWNER_TOKEN,
            'space': 'SpaceView3D',
            'region': 'WINDOW',
            'stage': 'POST_PIXEL',
            'layer': 11500,
            'role': 'front_modeling_hud',
            'rehook_callback': _svs_rehook_front_post_pixel_handlers,
            'release_callback': _svs_release_front_post_pixel_handlers,
            'registration_order_independent': True,
        }
        return True
    except Exception:
        return False


def _svs_clear_front_post_pixel_layer_policy() -> None:
    try:
        namespace = bpy.app.driver_namespace
        registry = namespace.get(_SVS_FRONT_POST_PIXEL_LAYER_POLICY_KEY)
        if not isinstance(registry, dict):
            return
        record = registry.get(_SVS_FRONT_POST_PIXEL_LAYER_OWNER)
        if isinstance(record, dict) and record.get('owner_token') is _SVS_FRONT_POST_PIXEL_LAYER_OWNER_TOKEN:
            registry.pop(_SVS_FRONT_POST_PIXEL_LAYER_OWNER, None)
        if not registry and namespace.get(_SVS_FRONT_POST_PIXEL_LAYER_POLICY_KEY) is registry:
            namespace.pop(_SVS_FRONT_POST_PIXEL_LAYER_POLICY_KEY, None)
    except Exception:
        pass


def _svs_is_japanese(context=None):
    try:
        ctx = context or getattr(bpy, 'context', None)
        prefs = getattr(ctx, 'preferences', None) if ctx is not None else None
        view = getattr(prefs, 'view', None) if prefs is not None else None
        lang = str(getattr(view, 'language', '') or '')
        return lang.startswith('ja')
    except Exception:
        return False


def _svs_text(context, english, japanese):
    return japanese if _svs_is_japanese(context) else english


def _svs_rna_access_is_unsafe():
    try:
        import sys
        package_root = str(__package__ or '').rsplit('.', 1)[0]
        for module_name in (package_root + '.core' if package_root else '', 'smart_modeling_suite.core', 'bl_ext.user_default.smart_modeling_suite.core'):
            if not module_name:
                continue
            module = sys.modules.get(module_name)
            fn = getattr(module, '_sms_rna_access_is_unsafe', None) if module is not None else None
            if callable(fn):
                return bool(fn())
    except Exception:
        pass
    return False


def _svs_mesh_select_mode_flags(context=None):
    try:
        ctx = context or getattr(bpy, 'context', None)
        tool = getattr(ctx, 'tool_settings', None) if ctx is not None else None
        flags = tuple(bool(v) for v in getattr(tool, 'mesh_select_mode', (False, False, False)))
        if len(flags) >= 3:
            return flags[:3]
    except Exception:
        pass
    return (False, False, False)


def _svs_mesh_select_mode_label(context=None):
    try:
        ctx = context or getattr(bpy, 'context', None)
        if ctx is not None and getattr(ctx, 'mode', '') != 'EDIT_MESH':
            return _svs_text(ctx, 'Object Mode', 'オブジェクトモード')
    except Exception:
        pass
    flags = _svs_mesh_select_mode_flags(context)
    items = []
    if flags[0]:
        items.append(_svs_text(context, 'Vertex', '頂点'))
    if flags[1]:
        items.append(_svs_text(context, 'Edge', '辺'))
    if flags[2]:
        items.append(_svs_text(context, 'Face', '面'))
    if not items:
        items.append(_svs_text(context, 'Edit Mesh', 'メッシュ編集'))
    return ' / '.join(items)


def _svs_status_text_for_context(context=None):
    ctx = context or getattr(bpy, 'context', None)
    enabled = _svs_scene_enabled(ctx) if ctx is not None else False
    mode_label = _svs_mesh_select_mode_label(ctx)
    if _svs_is_japanese(ctx):
        return '頂点スライド: ' + ('有効' if enabled else '無効') + ' / ' + mode_label
    return 'Vertex Slide: ' + ('ON' if enabled else 'OFF') + ' / ' + mode_label


def _svs_push_status_notice(context=None, duration=3.2):
    global _SVS_STATUS_FLASH_UNTIL, _SVS_LAST_STATUS_TEXT
    try:
        _SVS_LAST_STATUS_TEXT = _svs_status_text_for_context(context)
        _SVS_STATUS_FLASH_UNTIL = time.monotonic() + float(duration)
        _svs_schedule_statusbar_flash_redraw()
    except Exception:
        _SVS_LAST_STATUS_TEXT = ''
        _SVS_STATUS_FLASH_UNTIL = 0.0


def _svs_tag_statusbar_redraw(context=None):
    try:
        ctx = context or getattr(bpy, 'context', None)
        screen = getattr(ctx, 'screen', None) if ctx is not None else None
        for area in getattr(screen, 'areas', ()):
            area_type = getattr(area, 'type', None)
            if area_type in {'STATUSBAR', 'VIEW_3D'}:
                area.tag_redraw()
    except Exception:
        pass


def _svs_statusbar_flash_redraw_timer():
    try:
        ctx = getattr(bpy, 'context', None)
        _svs_tag_statusbar_redraw(ctx)
        if time.monotonic() <= float(_SVS_STATUS_FLASH_UNTIL or 0.0):
            return 0.15
        if _svs_rna_access_is_unsafe():
            return 0.15
    except Exception:
        pass
    return None


def _svs_schedule_statusbar_flash_redraw():
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is None:
            return
        try:
            if hasattr(timers, 'is_registered') and timers.is_registered(_svs_statusbar_flash_redraw_timer):
                return
        except Exception:
            pass
        timers.register(_svs_statusbar_flash_redraw_timer, first_interval=0.05)
    except Exception:
        pass


def _svs_clear_workspace_status_timer():
    # Compatibility callback retained so older registered timers can finish
    # safely after an in-place Extension update.  New code uses the shared
    # SmartTools single-slot runtime and never registers this callback.
    global _SVS_WORKSPACE_STATUS_CLEAR_AT
    _SVS_WORKSPACE_STATUS_CLEAR_AT = 0.0
    try:
        _status_runtime.clear("smart_modeling_suite.vertex_slide.toggle")
    except Exception:
        pass
    return None


def _svs_set_workspace_toggle_status(context=None, duration=3.2):
    # Replace the existing Vertex Slide notice in the one shared SmartTools
    # status slot.  Repeated toggles extend/replace this entry; they never append
    # another STATUSBAR_HT_header callback or another visible label.
    try:
        ctx = context or getattr(bpy, 'context', None)
        _status_runtime.set_transient(
            "smart_modeling_suite.vertex_slide.toggle",
            _svs_status_text_for_context(ctx),
            duration=float(duration),
            context=ctx,
        )
    except Exception:
        pass



def _svs_ptr(value):
    try:
        if value is None:
            return None
        fn = getattr(value, 'as_pointer', None)
        if callable(fn):
            return int(fn())
    except Exception:
        pass
    return None


def _svs_view3d_window_regions(area):
    """Return every drawable WINDOW region in one 3D View area.

    A normal 3D View has one WINDOW region, while Blender's Quad View has four
    WINDOW regions inside the same area.  Treating an area as if it had only
    one WINDOW region makes a class-level SpaceView3D draw handler stick to the
    first quadrant instead of following the cursor.
    """
    try:
        if getattr(area, 'type', None) != 'VIEW_3D':
            return ()
        return tuple(
            region
            for region in getattr(area, 'regions', ())
            if getattr(region, 'type', None) == 'WINDOW'
            and int(getattr(region, 'width', 0) or 0) > 1
            and int(getattr(region, 'height', 0) or 0) > 1
        )
    except Exception:
        return ()


def _svs_region_contains_window_point(region, mouse_x, mouse_y):
    """Return whether absolute window coordinates are inside ``region``."""
    try:
        x = float(mouse_x)
        y = float(mouse_y)
        rx = float(getattr(region, 'x', 0.0) or 0.0)
        ry = float(getattr(region, 'y', 0.0) or 0.0)
        rw = float(getattr(region, 'width', 0.0) or 0.0)
        rh = float(getattr(region, 'height', 0.0) or 0.0)
        return rw > 1.0 and rh > 1.0 and rx <= x < rx + rw and ry <= y < ry + rh
    except Exception:
        return False


def _svs_region_distance_sq_to_window_point(region, mouse_x, mouse_y):
    """Squared distance from a window-space point to a region rectangle."""
    try:
        x = float(mouse_x)
        y = float(mouse_y)
        rx = float(getattr(region, 'x', 0.0) or 0.0)
        ry = float(getattr(region, 'y', 0.0) or 0.0)
        rw = max(0.0, float(getattr(region, 'width', 0.0) or 0.0))
        rh = max(0.0, float(getattr(region, 'height', 0.0) or 0.0))
        right = rx + rw
        top = ry + rh
        dx = rx - x if x < rx else x - right if x > right else 0.0
        dy = ry - y if y < ry else y - top if y > top else 0.0
        return dx * dx + dy * dy
    except Exception:
        return float('inf')


def _svs_view3d_window_region(area, mouse_x=None, mouse_y=None, preferred_region=None, nearest=False):
    """Resolve one WINDOW region, including the correct Quad View quadrant."""
    regions = _svs_view3d_window_regions(area)
    if not regions:
        return None

    preferred_ptr = _svs_ptr(preferred_region)
    if preferred_ptr is not None:
        for region in regions:
            if _svs_ptr(region) == preferred_ptr:
                return region

    if mouse_x is not None and mouse_y is not None:
        for region in regions:
            if _svs_region_contains_window_point(region, mouse_x, mouse_y):
                return region
        if nearest:
            try:
                return min(
                    regions,
                    key=lambda region: _svs_region_distance_sq_to_window_point(region, mouse_x, mouse_y),
                )
            except Exception:
                pass
    return regions[0]


def _svs_resolve_toggle_overlay_target(context=None, event=None):
    """Return one concrete 3D View WINDOW region for the temporary toggle HUD."""
    try:
        ctx = context or getattr(bpy, 'context', None)
        if ctx is None:
            return (None, None, None, None)
        window = getattr(ctx, 'window', None)
        screen = getattr(ctx, 'screen', None)
        mx = getattr(event, 'mouse_x', None) if event is not None else None
        my = getattr(event, 'mouse_y', None) if event is not None else None

        # A keymap event delivered inside a Quad View already carries the exact
        # WINDOW region under the cursor in ``context.region``.  Prefer that
        # region before scanning the parent area; all four quadrants share the
        # same Area and scanning the Area alone would otherwise select the first
        # WINDOW region every time.
        area = getattr(ctx, 'area', None)
        context_region = getattr(ctx, 'region', None)
        if (
            getattr(area, 'type', None) == 'VIEW_3D'
            and getattr(context_region, 'type', None) == 'WINDOW'
        ):
            region = _svs_view3d_window_region(area, preferred_region=context_region)
            # Trust the context region when no event coordinates are available,
            # or when the cursor is actually inside that region.  If a caller
            # supplied a stale WINDOW override, the absolute cursor position
            # below remains authoritative.
            if region is not None and (
                mx is None
                or my is None
                or _svs_region_contains_window_point(region, mx, my)
            ):
                return (window, screen, area, region)

        if mx is not None and my is not None and screen is not None:
            try:
                mx = float(mx)
                my = float(my)
                # Resolve by the concrete WINDOW-region rectangles, not merely
                # by the parent Area rectangle.  This is what distinguishes the
                # four sub-views in Quad View.
                for candidate_area in getattr(screen, 'areas', ()):
                    if getattr(candidate_area, 'type', None) != 'VIEW_3D':
                        continue
                    region = _svs_view3d_window_region(candidate_area, mx, my)
                    if region is not None and _svs_region_contains_window_point(region, mx, my):
                        return (window, screen, candidate_area, region)
            except Exception:
                pass

        if getattr(area, 'type', None) == 'VIEW_3D':
            # Invokes from the N-panel/header do not have a WINDOW context
            # region.  Select the sub-view nearest the actual cursor, so a
            # Quad View still receives the notice on the cursor side instead
            # of being pinned to its first quadrant.
            region = _svs_view3d_window_region(area, mx, my, nearest=mx is not None and my is not None)
            if region is not None:
                return (window, screen, area, region)
        # Last resort: use a single 3D View on the active screen. This avoids
        # the old class-handler behavior that made the notice appear in all
        # split 3D Views at once.
        for candidate_area in getattr(screen, 'areas', ()) if screen is not None else ():
            if getattr(candidate_area, 'type', None) == 'VIEW_3D':
                region = _svs_view3d_window_region(
                    candidate_area,
                    mx,
                    my,
                    nearest=mx is not None and my is not None,
                )
                if region is not None:
                    return (window, screen, candidate_area, region)
    except Exception:
        pass
    return (None, None, None, None)


# Compatibility for older code paths that may still call the earlier helper name.
def _svs_resolve_overlay_target(context=None):
    return _svs_resolve_toggle_overlay_target(context, None)


def _svs_clamp(value, low, high):
    try:
        value = float(value)
        low = float(low)
        high = float(high)
        if high < low:
            return low
        return low if value < low else high if value > high else value
    except Exception:
        return float(low or 0.0)


def _svs_capture_toggle_overlay_target(context=None, event=None):
    try:
        window, screen, area, region = _svs_resolve_toggle_overlay_target(context, event)
        if area is None or region is None:
            return None
        return {
            'window': _svs_ptr(window),
            'screen': _svs_ptr(screen),
            'area': _svs_ptr(area),
            'region': _svs_ptr(region),
            'region_x': int(getattr(region, 'x', 0) or 0),
            'region_y': int(getattr(region, 'y', 0) or 0),
            'region_width': int(getattr(region, 'width', 0) or 0),
            'region_height': int(getattr(region, 'height', 0) or 0),
        }
    except Exception:
        return None


def _svs_current_overlay_target_matches(target=None):
    target = target if isinstance(target, dict) else _SVS_TOGGLE_OVERLAY_TARGET
    if not isinstance(target, dict):
        return False
    try:
        ctx = getattr(bpy, 'context', None)
        replay = None
        try:
            replay = bpy.app.driver_namespace.get(_SVS_FRONT_POST_PIXEL_REPLAY_CONTEXT_KEY)
        except Exception:
            replay = None
        if isinstance(replay, dict):
            area = replay.get('area')
            region = replay.get('region')
            current_window = replay.get('window')
            current_screen = replay.get('screen')
        else:
            if ctx is None:
                return False
            area = getattr(ctx, 'area', None)
            region = getattr(ctx, 'region', None)
            current_window = getattr(ctx, 'window', None)
            current_screen = getattr(ctx, 'screen', None)
        if getattr(area, 'type', None) != 'VIEW_3D':
            return False
        if getattr(region, 'type', None) != 'WINDOW':
            return False
        for key, value in (
            ('window', current_window),
            ('screen', current_screen),
            ('area', area),
            ('region', region),
        ):
            expected = target.get(key)
            if expected is not None and _svs_ptr(value) != expected:
                return False
        return True
    except Exception:
        return False


def _svs_iter_screens(context=None):
    seen = set()
    try:
        ctx = context or getattr(bpy, 'context', None)
        wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
        for window in getattr(wm, 'windows', ()) if wm is not None else ():
            screen = getattr(window, 'screen', None)
            ptr = _svs_ptr(screen)
            if screen is not None and ptr not in seen:
                seen.add(ptr)
                yield screen
        screen = getattr(ctx, 'screen', None) if ctx is not None else None
        ptr = _svs_ptr(screen)
        if screen is not None and ptr not in seen:
            yield screen
    except Exception:
        return


def _svs_tag_toggle_overlay_redraw(context=None):
    try:
        target = _SVS_TOGGLE_OVERLAY_TARGET
        target_area = target.get('area') if isinstance(target, dict) else None
        if target_area is not None:
            for screen in _svs_iter_screens(context):
                for area in getattr(screen, 'areas', ()): 
                    if _svs_ptr(area) == target_area:
                        area.tag_redraw()
                        return
        ctx = context or getattr(bpy, 'context', None)
        area = getattr(ctx, 'area', None) if ctx is not None else None
        if getattr(area, 'type', None) == 'VIEW_3D':
            area.tag_redraw()
    except Exception:
        pass


# Backward-compatible name for internal callers in this module.
def _svs_tag_view3d_redraw(context=None):
    _svs_tag_toggle_overlay_redraw(context)


def _svs_toggle_overlay_text(context=None, enabled=False):
    if _svs_is_japanese(context):
        return '頂点スライド：' + ('有効' if enabled else '無効')
    return 'Vertex Slide: ' + ('ON' if enabled else 'OFF')


def _svs_toggle_overlay_position(context=None, event=None, target=None):
    try:
        target = target or {}
        width = max(1.0, float(target.get('region_width') or 160.0)) if isinstance(target, dict) else 160.0
        height = max(1.0, float(target.get('region_height') or 120.0)) if isinstance(target, dict) else 120.0
        x = None
        y = None
        ctx = context or getattr(bpy, 'context', None)
        if event is not None:
            try:
                # Absolute window coordinates are unambiguous in Quad View.
                # Convert them against the selected sub-region rather than
                # trusting coordinates from a different UI/quad region.
                mx = getattr(event, 'mouse_x', None)
                my = getattr(event, 'mouse_y', None)
                if mx is not None and my is not None:
                    x = float(mx) - float(target.get('region_x') or 0.0)
                    y = float(my) - float(target.get('region_y') or 0.0)
            except Exception:
                x = y = None
            try:
                # Direct viewport invoke: use exact cursor coordinates only when
                # the invoke region is the same VIEW_3D/WINDOW region selected
                # as the overlay target.
                if (x is None or y is None) and isinstance(target, dict) and target.get('region') is not None and _svs_ptr(getattr(ctx, 'region', None)) == target.get('region'):
                    rx = getattr(event, 'mouse_region_x', None)
                    ry = getattr(event, 'mouse_region_y', None)
                    if rx is not None and ry is not None:
                        x = float(rx)
                        y = float(ry)
            except Exception:
                pass
            if x is None or y is None:
                try:
                    # N-panel/tool-region invoke: convert absolute window mouse
                    # coordinates to the target 3D View WINDOW region.
                    mx = getattr(event, 'mouse_x', None)
                    my = getattr(event, 'mouse_y', None)
                    if mx is not None and my is not None:
                        x = float(mx) - float(target.get('region_x') or 0.0)
                        y = float(my) - float(target.get('region_y') or 0.0)
                except Exception:
                    x = y = None
        if x is None or y is None:
            x = width * 0.5
            y = height * 0.5
        # Keep the cursor anchor inside the active target view. The draw
        # callback positions the box immediately under this anchor.
        return (_svs_clamp(x, 8.0, width - 8.0), _svs_clamp(y, 8.0, height - 8.0))
    except Exception:
        pass
    return (80.0, 80.0)

def _svs_remove_toggle_overlay_handler():
    global _SVS_TOGGLE_OVERLAY_HANDLE, _SVS_TOGGLE_OVERLAY_TEXT, _SVS_TOGGLE_OVERLAY_UNTIL, _SVS_TOGGLE_OVERLAY_TARGET, _SVS_TOGGLE_OVERLAY_REPLAY_MANAGED
    handle = _SVS_TOGGLE_OVERLAY_HANDLE
    if handle is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(handle, 'WINDOW')
        except Exception:
            pass
    _SVS_TOGGLE_OVERLAY_HANDLE = None
    _SVS_TOGGLE_OVERLAY_TEXT = ''
    _SVS_TOGGLE_OVERLAY_UNTIL = 0.0
    _SVS_TOGGLE_OVERLAY_TARGET = None
    _SVS_TOGGLE_OVERLAY_REPLAY_MANAGED = False
    _SVS_TOGGLE_OVERLAY_SNAPSHOT.clear()


def _svs_prepare_toggle_overlay_snapshot(target, text, cursor_position, until):
    snapshot = _SVS_TOGGLE_OVERLAY_SNAPSHOT
    snapshot.clear()
    if not isinstance(target, dict) or not text:
        return False

    font_id = 0
    try:
        blf.size(font_id, 18)
    except TypeError:
        try:
            blf.size(font_id, 18, 72)
        except Exception:
            pass
    try:
        width, height = blf.dimensions(font_id, text)
    except Exception:
        width, height = (160.0, 18.0)

    pad_x = 10.0
    pad_y = 6.0
    gap_y = 8.0
    margin = 8.0
    region_width = float(target.get('region_width') or 160.0)
    region_height = float(target.get('region_height') or 120.0)
    cursor_x, cursor_y = cursor_position
    box_w = float(width) + pad_x * 2.0
    box_h = float(height) + pad_y * 2.0
    box_left = _svs_clamp(float(cursor_x) - box_w * 0.5, margin, max(margin, region_width - box_w - margin))
    box_top = float(cursor_y) - gap_y
    box_bottom = box_top - box_h
    if box_bottom < margin:
        box_bottom = margin
        box_top = box_bottom + box_h
    if box_top > region_height - margin:
        box_top = region_height - margin
        box_bottom = max(margin, box_top - box_h)

    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    vertices = (
        (box_left, box_bottom),
        (box_left + box_w, box_bottom),
        (box_left + box_w, box_bottom + box_h),
        (box_left, box_bottom + box_h),
    )
    indices = ((0, 1, 2), (0, 2, 3))
    snapshot.target = dict(target)
    snapshot.text = str(text)
    snapshot.until = float(until)
    snapshot.shader = shader
    snapshot.batch = batch_for_shader(shader, 'TRIS', {'pos': vertices}, indices=indices)
    snapshot.text_x = box_left + pad_x
    snapshot.text_y = box_bottom + pad_y
    return True


def _svs_draw_toggle_overlay(snapshot):
    """Draw the temporary toggle notice from a prebuilt GPU snapshot only."""
    try:
        if snapshot is None or not _svs_current_overlay_target_matches(snapshot.target):
            return
        text = snapshot.text
        if not text:
            return
        remaining = float(snapshot.until) - time.monotonic()
        if remaining <= 0.0:
            return
        alpha = 1.0 if remaining >= 0.25 else max(0.0, min(1.0, remaining / 0.25))

        if snapshot.shader is not None and snapshot.batch is not None:
            gpu.state.blend_set('ALPHA')
            snapshot.shader.bind()
            snapshot.shader.uniform_float('color', (0.0, 0.0, 0.0, 0.56 * alpha))
            snapshot.batch.draw(snapshot.shader)
            gpu.state.blend_set('NONE')

        font_id = 0
        try:
            blf.size(font_id, 18)
        except TypeError:
            blf.size(font_id, 18, 72)
        blf.position(font_id, snapshot.text_x + 1.0, snapshot.text_y - 1.0, 0.0)
        blf.color(font_id, 0.0, 0.0, 0.0, 0.85 * alpha)
        blf.draw(font_id, text)
        blf.position(font_id, snapshot.text_x, snapshot.text_y, 0.0)
        blf.color(font_id, 1.0, 1.0, 1.0, alpha)
        blf.draw(font_id, text)
    except Exception:
        return


def _svs_toggle_overlay_timer():
    try:
        ctx = getattr(bpy, 'context', None)
        _svs_tag_toggle_overlay_redraw(ctx)
        if time.monotonic() <= float(_SVS_TOGGLE_OVERLAY_UNTIL or 0.0):
            return 0.05
    except Exception:
        pass
    _svs_remove_toggle_overlay_handler()
    try:
        _svs_tag_toggle_overlay_redraw(getattr(bpy, 'context', None))
    except Exception:
        pass
    return None


def _svs_show_toggle_overlay(context=None, enabled=False, event=None, duration=1.15):
    global _SVS_TOGGLE_OVERLAY_HANDLE, _SVS_TOGGLE_OVERLAY_TEXT, _SVS_TOGGLE_OVERLAY_POS, _SVS_TOGGLE_OVERLAY_UNTIL, _SVS_TOGGLE_OVERLAY_TARGET
    try:
        if getattr(getattr(bpy, 'app', None), 'background', False):
            return
    except Exception:
        pass
    try:
        _SVS_TOGGLE_OVERLAY_TARGET = _svs_capture_toggle_overlay_target(context, event)
        if not _SVS_TOGGLE_OVERLAY_TARGET:
            return
        _SVS_TOGGLE_OVERLAY_TEXT = _svs_toggle_overlay_text(context, bool(enabled))
        _SVS_TOGGLE_OVERLAY_POS = _svs_toggle_overlay_position(context, event, _SVS_TOGGLE_OVERLAY_TARGET)
        _SVS_TOGGLE_OVERLAY_UNTIL = time.monotonic() + max(0.25, float(duration))
        if not _svs_prepare_toggle_overlay_snapshot(
            _SVS_TOGGLE_OVERLAY_TARGET,
            _SVS_TOGGLE_OVERLAY_TEXT,
            _SVS_TOGGLE_OVERLAY_POS,
            _SVS_TOGGLE_OVERLAY_UNTIL,
        ):
            return
        if _SVS_TOGGLE_OVERLAY_HANDLE is None:
            _SVS_TOGGLE_OVERLAY_HANDLE = bpy.types.SpaceView3D.draw_handler_add(
                _svs_draw_toggle_overlay,
                (_SVS_TOGGLE_OVERLAY_SNAPSHOT,),
                'WINDOW',
                'POST_PIXEL',
            )
        if _svs_overlay_front_replay_active():
            _svs_rehook_front_post_pixel_handlers()
        _svs_tag_toggle_overlay_redraw(context)
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None:
            try:
                if hasattr(timers, 'is_registered') and timers.is_registered(_svs_toggle_overlay_timer):
                    timers.unregister(_svs_toggle_overlay_timer)
            except Exception:
                pass
            try:
                timers.register(_svs_toggle_overlay_timer, first_interval=0.01)
            except Exception:
                pass
    except Exception:
        pass

def _svs_draw_statusbar(self, context):
    if _svs_rna_access_is_unsafe():
        return
    try:
        if context is None:
            return
        enabled = _svs_scene_enabled(context)
        flash_active = time.monotonic() <= float(_SVS_STATUS_FLASH_UNTIL or 0.0)
        if not enabled and not flash_active:
            return
        if getattr(context, 'mode', '') != 'EDIT_MESH' and not enabled and not flash_active:
            return
        layout = self.layout
        if hasattr(layout, 'separator_spacer'):
            layout.separator_spacer()
        else:
            layout.separator()
        outer = layout.row(align=True)
        try:
            outer.alignment = 'CENTER'
        except Exception:
            pass
        outer.scale_x = 1.25
        try:
            box = outer.box()
        except Exception:
            box = outer
        try:
            # Enabled: normal theme text (white on dark themes).
            # Disabled flash: alert text (red) so OFF is visually distinct.
            box.alert = not bool(enabled)
        except Exception:
            pass
        msg = _svs_status_text_for_context(context) if enabled else (_SVS_LAST_STATUS_TEXT or _svs_status_text_for_context(context))
        inner = box.row(align=True)
        try:
            inner.alignment = 'CENTER'
        except Exception:
            pass
        inner.label(text=msg)
        if hasattr(layout, 'separator_spacer'):
            layout.separator_spacer()
    except Exception:
        return


def _svs_remove_stale_statusbar_callbacks():
    try:
        import sys
        header = getattr(bpy.types, 'STATUSBAR_HT_header', None)
        if header is None:
            return
        remove = getattr(header, 'remove', None)
        if not callable(remove):
            return
        for module_name, module in list(sys.modules.items()):
            if module is None or 'smart_modeling_suite' not in str(module_name).lower():
                continue
            for fn_name in ('_svs_draw_statusbar', 'tams_draw_statusbar'):
                try:
                    fn = getattr(module, fn_name, None)
                except Exception:
                    fn = None
                if callable(fn):
                    try:
                        remove(fn)
                    except Exception:
                        pass
    except Exception:
        pass


def _svs_append_statusbar_handler_once():
    global _SVS_STATUSBAR_APPENDED
    # Do not append to STATUSBAR_HT_header.  Appended callbacks survive some
    # reload paths and were the direct cause of the repeated
    # "Vertex Slide: Enabled..." labels growing horizontally.  Keep only the
    # one shared Workspace.status_text_set slot managed by status_runtime.
    try:
        _svs_remove_stale_statusbar_callbacks()
    except Exception:
        pass
    _SVS_STATUSBAR_APPENDED = False

def _svs_remove_statusbar_handler():
    global _SVS_STATUSBAR_APPENDED
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_svs_statusbar_flash_redraw_timer):
            timers.unregister(_svs_statusbar_flash_redraw_timer)
    except Exception:
        pass
    try:
        header = getattr(bpy.types, 'STATUSBAR_HT_header', None)
        if header is not None:
            try:
                header.remove(_svs_draw_statusbar)
            except Exception:
                pass
        _svs_remove_stale_statusbar_callbacks()
    except Exception:
        pass
    try:
        _status_runtime.clear("smart_modeling_suite.vertex_slide.toggle")
        _status_runtime.clear("smart_modeling_suite.vertex_slide.modal")
    except Exception:
        pass
    _SVS_STATUSBAR_APPENDED = False

def _svs_selected_vertex_indices_from_bm(bm):
    """Return vertices affected by the current edit selection.

    Blender's BMesh vertex select flag is not reliable enough by itself in Edge
    and Face selection modes.  Explicitly expand selected edges and faces to
    their component vertices so the constraint monitor reacts in all three mesh
    selection modes.
    """
    selected = set()
    try:
        bm.verts.ensure_lookup_table()
    except Exception:
        pass
    try:
        bm.edges.ensure_lookup_table()
    except Exception:
        pass
    try:
        bm.faces.ensure_lookup_table()
    except Exception:
        pass
    try:
        modes = {str(m) for m in getattr(bm, 'select_mode', set())}
    except Exception:
        modes = set()
    scan_verts = (not modes) or ('VERT' in modes)
    scan_edges = (not modes) or ('EDGE' in modes)
    scan_faces = (not modes) or ('FACE' in modes)
    if scan_verts:
        try:
            for v in bm.verts:
                if getattr(v, 'select', False):
                    selected.add(int(v.index))
        except Exception:
            pass
    if scan_edges:
        try:
            for e in bm.edges:
                if getattr(e, 'select', False):
                    for v in e.verts:
                        selected.add(int(v.index))
        except Exception:
            pass
    if scan_faces:
        try:
            for f in bm.faces:
                if getattr(f, 'select', False):
                    for v in f.verts:
                        selected.add(int(v.index))
        except Exception:
            pass
    return selected


def _svs_selected_edge_indices_from_bm(bm):
    try:
        bm.edges.ensure_lookup_table()
        return tuple(int(e.index) for e in bm.edges if getattr(e, 'select', False))
    except Exception:
        return ()


def _svs_selected_face_indices_from_bm(bm):
    try:
        bm.faces.ensure_lookup_table()
        return tuple(int(f.index) for f in bm.faces if getattr(f, 'select', False))
    except Exception:
        return ()


def _svs_toggle_roots(context=None):
    try:
        ctx = context or getattr(bpy, 'context', None)
    except Exception:
        ctx = None
    wm = None
    scene = None
    try:
        wm = getattr(ctx, 'window_manager', None) if ctx is not None else getattr(bpy.context, 'window_manager', None)
    except Exception:
        wm = None
    try:
        scene = getattr(ctx, 'scene', None) if ctx is not None else getattr(bpy.context, 'scene', None)
    except Exception:
        scene = None
    return wm, scene


def _svs_reset_scene_toggle(context=None):
    try:
        wm, scene = _svs_toggle_roots(context)
        for owner in (wm, scene):
            if owner is None:
                continue
            try:
                setattr(owner, _SVS_TRANSIENT_SCENE_FLAG, False)
            except Exception:
                pass
    except Exception:
        pass


@persistent
def _svs_load_post_disable_constraint(_dummy=None):
    """Never reopen a blend file with the live slide constraint enabled."""
    try:
        _svs_stop_timer_monitor()
    except Exception:
        pass
    _svs_reset_scene_toggle(getattr(bpy, 'context', None))


def _svs_append_load_post_handler_once():
    try:
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        load_post = getattr(handlers, 'load_post', None) if handlers is not None else None
        if load_post is None:
            return
        for fn in list(load_post):
            if fn is _svs_load_post_disable_constraint:
                return
            if getattr(fn, '__name__', '') == _svs_load_post_disable_constraint.__name__ and getattr(fn, '__module__', '') == __name__:
                try:
                    load_post.remove(fn)
                except Exception:
                    pass
        load_post.append(_svs_load_post_disable_constraint)
    except Exception:
        pass


def _svs_remove_load_post_handler():
    try:
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        load_post = getattr(handlers, 'load_post', None) if handlers is not None else None
        if load_post is None:
            return
        for fn in list(load_post):
            if fn is _svs_load_post_disable_constraint or (
                getattr(fn, '__name__', '') == _svs_load_post_disable_constraint.__name__
                and getattr(fn, '__module__', '') == __name__
            ):
                try:
                    load_post.remove(fn)
                except Exception:
                    pass
    except Exception:
        pass


class _VertItem:
    __slots__ = (
        "obj",
        "bm",
        "vi",
        "v",
        "orig",
        "weight",
        "neighbors",
        "active_neighbor",
        "last_dot",
        "corner_path",
        "corner_cum",
        "corner_seed",
        "edge_switch_wait",
    )

    def __init__(self, obj, bm, vi, v, orig, weight):
        self.obj = obj
        self.bm = bm
        self.vi = vi
        self.v = v
        self.orig = orig
        self.weight = weight
        self.neighbors = []
        self.active_neighbor = None
        self.last_dot = -2.0
        self.corner_path = None
        self.corner_cum = None
        self.corner_seed = None
        self.edge_switch_wait = 0


class MESH_OT_smart_vert_slide_modal(bpy.types.Operator):
    _jelararagi_status_managed_v2 = True
    bl_idname = "mesh.smart_vert_slide_modal"
    bl_label = 'Start Slide'
    bl_description = "Enhanced Vertex Slide with multi-object edit support, optional proportional influence, a viewport HUD, and loop/ring-aware direction picking."
    bl_options = {'UNDO', 'GRAB_CURSOR', 'BLOCKING'}

    def _reset_runtime_state(self):
        self._items = []
        self._objs = []
        self._bms = {}
        self._kd = {}
        self._kd_counts = {}
        self._all_verts = {}
        self._sel_verts = {}
        self._obj_cache = {}

        self._area = None
        self._region = None
        self._rv3d = None
        self._draw_handle_3d = None
        self._draw_handle_2d = None
        self._draw_context = None
        self._overlay_front_replay_managed = False

        self._init_mouse = Vector((0.0, 0.0))
        self._last_mouse = Vector((0.0, 0.0))
        self._mouse_vec = Vector((0.0, 0.0))
        self._mouse_vec_smooth = Vector((0.0, 0.0))
        self._mouse_smooth_inited = False

        self._seed_edge_by_obj = {}
        self._loop_set = {}
        self._ring_set = {}

        self._behavior = 'STOP'
        self._use_prop = False

        self._numeric = ""
        self._numeric_active = False

        self._last_update_time = 0.0
        self._last_view_sig = None
        self._last_mdir = Vector((1.0, 0.0))
        self._prev_corner_dir = None
        self._corner_paths = {}

        self._prop_enabled = False
        self._prop_setting_enabled = True
        self._prop_radius = 1.0
        self._prop_falloff = 'SMOOTH'
        self._prop_projected = False
        self._prop_connected = False
        self._prop_preview_radius_px = 60.0

        self._cfg_edge_lock_enabled = True
        self._cfg_edge_lock_keep_dot = 0.75
        self._cfg_edge_lock_switch_margin = 0.08
        self._cfg_loop_priority = False
        self._cfg_ring_priority = False
        self._cfg_loop_ring_bonus = 0.25
        self._cfg_flow_bias = 0.35
        self._cfg_sensitivity = 0.0045
        self._cfg_slow_factor = 0.2
        self._cfg_snap_step = 0.1
        self._cfg_baseline = 'INDIVIDUAL'
        self._edge_switch_allowed = False
        self._edge_switch_min_mouse_px = 6.0
        self._edge_switch_hold_margin = 0.24
        self._edge_switch_confirm_frames = 3

    @classmethod
    def poll(cls, context):
        try:
            from ..utils import feature_enabled
            if not feature_enabled(context, "enable_vertex_slide", True):
                return False
        except Exception:
            pass
        return context.mode == 'EDIT_MESH'

    def invoke(self, context, event):
        self._reset_runtime_state()

        self._area = context.area
        self._region = context.region
        self._rv3d = context.region_data
        if not self._area or self._area.type != 'VIEW_3D' or self._region is None or self._rv3d is None:
            return {'CANCELLED'}

        self._init_mouse = Vector((float(event.mouse_region_x), float(event.mouse_region_y)))
        self._last_mouse = self._init_mouse.copy()

        if not self._build_items(context):
            return {'CANCELLED'}

        self._install_draw_handlers(context)
        _svs_set_active_modal(self)
        if _svs_overlay_front_replay_active():
            _svs_rehook_front_post_pixel_handlers()
        self._update_status(context)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def _ensure_obj_cache(self, obj, bm):
        cache = self._obj_cache.get(obj)
        vert_count = len(bm.verts)
        if cache is None or cache.get('vert_count') != vert_count:
            cache = {
                'bm': bm,
                'obj': obj,
                'mat_world': obj.matrix_world.copy(),
                'orig_co': [v.co.copy() for v in bm.verts],
                'screen': [_SVS_UNSET] * vert_count,
                'edges': [_SVS_UNSET] * vert_count,
                'vert_count': vert_count,
            }
            self._obj_cache[obj] = cache
        return cache

    def _clear_view_caches(self, reset_corner=False):
        for cache in self._obj_cache.values():
            count = int(cache.get('vert_count', 0))
            cache['screen'] = [_SVS_UNSET] * count
            cache['edges'] = [_SVS_UNSET] * count
        if reset_corner:
            self._clear_item_runtime_caches(clear_edge_pick=False)
            self._corner_paths = {}

    def _clear_item_runtime_caches(self, clear_edge_pick=True):
        for it in self._items:
            it.corner_path = None
            it.corner_cum = None
            it.corner_seed = None
            if clear_edge_pick:
                it.active_neighbor = None
                it.last_dot = -2.0
                it.edge_switch_wait = 0
        self._prev_corner_dir = None

    def _current_view_signature(self):
        if self._region is None or self._rv3d is None:
            return None
        try:
            view = tuple(round(v, 6) for row in self._rv3d.view_matrix for v in row)
            win = tuple(round(v, 6) for row in self._rv3d.window_matrix for v in row)
            return (
                int(getattr(self._region, 'width', 0)),
                int(getattr(self._region, 'height', 0)),
                view,
                win,
            )
        except Exception:
            return None

    def _refresh_view_caches_if_needed(self):
        sig = self._current_view_signature()
        if sig != self._last_view_sig:
            self._last_view_sig = sig
            self._clear_view_caches(reset_corner=True)

    def _build_items(self, context):
        self._items.clear()
        self._objs = [obj for obj in (list(context.objects_in_mode) if hasattr(context, "objects_in_mode") else [context.object]) if obj and obj.type == 'MESH']
        if not self._objs:
            return False

        tool = context.tool_settings
        prop_enabled, is_connected, is_projected, prop_radius, prop_falloff = self._read_proportional_settings(tool)
        self._prop_enabled = bool(prop_enabled)
        self._prop_radius = float(prop_radius)
        self._prop_falloff = str(prop_falloff)
        self._prop_projected = bool(is_projected)
        self._prop_connected = bool(is_connected)
        self._prop_preview_radius_px = 60.0

        prefs = get_prefs(context)
        self._prop_setting_enabled = bool(pref_get(prefs, "use_proportional_editing", True))
        self._use_prop = bool(self._prop_setting_enabled and self._prop_enabled)
        self._behavior = pref_get(prefs, "hit_behavior_proportional", "CORNER") if self._use_prop else pref_get(prefs, "hit_behavior_normal", "STOP")

        for obj in self._objs:
            bm = bmesh.from_edit_mesh(obj.data)
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()

            self._bms[obj] = bm
            self._all_verts[obj] = list(bm.verts)
            selected_indices = _svs_selected_vertex_indices_from_bm(bm)
            self._sel_verts[obj] = [v for v in bm.verts if v.index in selected_indices]
            self._ensure_obj_cache(obj, bm)

            for v in self._sel_verts[obj]:
                item = _VertItem(obj, bm, v.index, v, v.co.copy(), 1.0)
                item.neighbors = [e.other_vert(v).index for e in v.link_edges]
                self._items.append(item)

        if self._use_prop:
            self._rebuild_proportional(context)

        self._refresh_seed_edges(context, force=True)
        return len(self._items) > 0

    def _read_proportional_settings(self, tool_settings):
        enabled = False
        connected_only = False
        projected = False

        if hasattr(tool_settings, "use_proportional_edit"):
            try:
                enabled = bool(tool_settings.use_proportional_edit)
            except Exception:
                enabled = bool(getattr(tool_settings, "use_proportional_edit", False))

        mode = getattr(tool_settings, "proportional_edit", None)
        if mode is not None:
            mode_str = str(mode)
            if mode_str not in {'DISABLED', 'OFF', 'NONE'}:
                enabled = enabled or True
            connected_only = (mode_str == 'CONNECTED') or bool(getattr(tool_settings, "use_proportional_connected", False))
            projected = (mode_str == 'PROJECTED') or bool(getattr(tool_settings, "use_proportional_projected", False))
        else:
            enabled = enabled or bool(getattr(tool_settings, "use_proportional_edit", False))
            connected_only = bool(getattr(tool_settings, "use_proportional_connected", False))
            projected = bool(getattr(tool_settings, "use_proportional_projected", False))

        radius = None
        if hasattr(tool_settings, "proportional_distance"):
            try:
                radius = float(getattr(tool_settings, "proportional_distance", 0.0))
            except Exception:
                radius = None
        if radius is None or radius <= 0.0:
            radius = float(getattr(tool_settings, "proportional_size", 1.0))
        falloff = str(getattr(tool_settings, "proportional_edit_falloff", 'SMOOTH'))
        return enabled, connected_only, projected, max(radius, 1.0e-6), falloff

    def _connected_distances_cutoff_world(self, obj, bm, source_verts, cutoff):
        import heapq
        cutoff = float(cutoff)
        dist = {}
        heap = []
        world = [obj.matrix_world @ v.co for v in bm.verts]
        for v in source_verts:
            dist[v.index] = 0.0
            heapq.heappush(heap, (0.0, v.index))
        while heap:
            d, vi = heapq.heappop(heap)
            if d > cutoff:
                break
            if d != dist.get(vi, None):
                continue
            v = bm.verts[vi]
            for e in v.link_edges:
                ov = e.other_vert(v)
                nd = d + (world[ov.index] - world[vi]).length
                if nd <= cutoff and (ov.index not in dist or nd < dist[ov.index]):
                    dist[ov.index] = nd
                    heapq.heappush(heap, (nd, ov.index))
        return dist

    def _rebuild_proportional(self, context):
        tool = context.tool_settings
        prefs = get_prefs(context)
        self._prop_setting_enabled = bool(pref_get(prefs, "use_proportional_editing", True))

        prop_enabled, is_connected, is_projected, prop_radius, prop_falloff = self._read_proportional_settings(tool)
        self._prop_enabled = bool(prop_enabled)
        self._prop_radius = float(prop_radius)
        self._prop_falloff = str(prop_falloff)
        self._prop_projected = bool(is_projected)
        self._prop_connected = bool(is_connected)
        self._prop_preview_radius_px = 60.0
        self._use_prop = bool(self._prop_setting_enabled and self._prop_enabled)

        # Rebuild from the actual edit-mode selection only.  Do not infer
        # selected vertices from weight >= 1.0; a near unselected vertex can
        # legitimately have a high proportional weight, and treating it as
        # selected on the next rebuild makes the whole influence area move at
        # full strength.
        selected_key = {
            (obj, v.index)
            for obj in self._objs
            for v in self._sel_verts.get(obj, ())
        }
        selected_items = []
        current_by_key = {(it.obj, it.vi): it for it in self._items}
        for obj in self._objs:
            bm = self._bms.get(obj)
            if bm is None:
                continue
            for v in self._sel_verts.get(obj, ()):
                key = (obj, v.index)
                it = current_by_key.get(key)
                if it is None:
                    it = _VertItem(obj, bm, v.index, v, v.co.copy(), 1.0)
                    it.neighbors = [e.other_vert(v).index for e in v.link_edges]
                else:
                    it.weight = 1.0
                    it.orig = v.co.copy()
                    it.v = v
                    it.corner_path = None
                    it.corner_cum = None
                    it.corner_seed = None
                selected_items.append(it)
        self._items = selected_items

        if not self._use_prop or self._prop_radius <= 1.0e-12:
            self._clear_item_runtime_caches(clear_edge_pick=False)
            return

        radius = self._prop_radius
        falloff = self._prop_falloff

        for obj in self._objs:
            bm = self._bms[obj]
            all_verts = self._all_verts[obj]
            sel = self._sel_verts[obj]
            if not sel:
                continue

            if is_connected:
                distmap = self._connected_distances_cutoff_world(obj, bm, sel, radius)
                for vi, dist in distmap.items():
                    if (obj, vi) in selected_key:
                        continue
                    weight = falloff_weight(dist / radius, falloff)
                    if weight <= 0.0:
                        continue
                    v = bm.verts[vi]
                    item = _VertItem(obj, bm, vi, v, v.co.copy(), weight)
                    item.neighbors = [e.other_vert(v).index for e in v.link_edges]
                    self._items.append(item)
                continue

            if is_projected:
                src2d = []
                sel_world = []
                for v in sel:
                    co_world = obj.matrix_world @ v.co
                    p = view3d_utils.location_3d_to_region_2d(self._region, self._rv3d, co_world)
                    if p is None:
                        continue
                    src2d.append(Vector((float(p.x), float(p.y))))
                    sel_world.append(co_world)
                if not src2d:
                    continue

                projected_world_per_px = 1.0
                ref_world = sel_world[0].copy()
                if len(sel_world) > 1:
                    ref_world = Vector((0.0, 0.0, 0.0))
                    for wco in sel_world:
                        ref_world += wco
                    ref_world /= float(len(sel_world))
                try:
                    vm = getattr(self._rv3d, "view_matrix", None)
                    if vm is not None:
                        ivm3 = vm.inverted().to_3x3()
                        view_right = (ivm3 @ Vector((1.0, 0.0, 0.0))).normalized()
                        view_up = (ivm3 @ Vector((0.0, 1.0, 0.0))).normalized()
                        sc0 = view3d_utils.location_3d_to_region_2d(self._region, self._rv3d, ref_world)
                        scR = view3d_utils.location_3d_to_region_2d(self._region, self._rv3d, ref_world + view_right)
                        scU = view3d_utils.location_3d_to_region_2d(self._region, self._rv3d, ref_world + view_up)
                        if sc0 is not None and scR is not None and scU is not None:
                            p0 = Vector((float(sc0.x), float(sc0.y)))
                            pr = Vector((float(scR.x), float(scR.y)))
                            pu = Vector((float(scU.x), float(scU.y)))
                            px_per_unit_r = (pr - p0).length
                            px_per_unit_u = (pu - p0).length
                            px_per_unit = (px_per_unit_r + px_per_unit_u) * 0.5
                            if px_per_unit > 1.0e-6:
                                projected_world_per_px = 1.0 / px_per_unit
                                self._prop_preview_radius_px = radius / projected_world_per_px
                except Exception:
                    projected_world_per_px = 1.0

                for v in all_verts:
                    if (obj, v.index) in selected_key:
                        continue
                    p = view3d_utils.location_3d_to_region_2d(self._region, self._rv3d, obj.matrix_world @ v.co)
                    if p is None:
                        continue
                    p2 = Vector((float(p.x), float(p.y)))
                    dist_px = min((p2 - sp).length for sp in src2d)
                    dist = float(dist_px) * float(projected_world_per_px)
                    if dist > radius:
                        continue
                    weight = falloff_weight(dist / radius, falloff)
                    if weight <= 0.0:
                        continue
                    item = _VertItem(obj, bm, v.index, v, v.co.copy(), weight)
                    item.neighbors = [e.other_vert(v).index for e in v.link_edges]
                    self._items.append(item)
                continue

            world_positions = [obj.matrix_world @ v.co for v in all_verts]
            source_pos = [obj.matrix_world @ v.co for v in sel]
            kd = build_kdtree(world_positions)
            candidates = vertices_within_radius(kd, source_pos, radius)
            for ci in candidates:
                if (obj, ci) in selected_key:
                    continue
                v = all_verts[ci]
                world_co = world_positions[ci]
                dist = min((world_co - sp).length for sp in source_pos)
                if dist > radius:
                    continue
                weight = falloff_weight(dist / radius, falloff)
                if weight <= 0.0:
                    continue
                item = _VertItem(obj, bm, ci, v, v.co.copy(), weight)
                item.neighbors = [e.other_vert(v).index for e in v.link_edges]
                self._items.append(item)

        self._clear_item_runtime_caches(clear_edge_pick=False)

    def _install_draw_handlers(self, context):
        self._draw_context = context
        if self._draw_handle_3d is None:
            self._draw_handle_3d = bpy.types.SpaceView3D.draw_handler_add(self._draw_3d, (context,), 'WINDOW', 'POST_VIEW')
        if self._draw_handle_2d is None:
            self._draw_handle_2d = bpy.types.SpaceView3D.draw_handler_add(self._draw_2d, (context,), 'WINDOW', 'POST_PIXEL')

    def _rehook_post_pixel_handler_after_overlay(self):
        """Keep the native HUD handler and place it after Smart Overlay."""
        if self._draw_context is None:
            return False
        handle = self._draw_handle_2d
        if handle is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(handle, 'WINDOW')
            except Exception:
                pass
            self._draw_handle_2d = None
        self._overlay_front_replay_managed = False
        try:
            self._draw_handle_2d = bpy.types.SpaceView3D.draw_handler_add(
                self._draw_2d,
                (self._draw_context,),
                'WINDOW',
                'POST_PIXEL',
            )
            return True
        except Exception:
            self._draw_handle_2d = None
            return False

    def _ensure_independent_post_pixel_handler(self):
        self._overlay_front_replay_managed = False
        if self._draw_handle_2d is not None:
            return True
        try:
            context = self._draw_context
        except Exception:
            context = None
        if context is None:
            context = getattr(bpy, 'context', None)
        try:
            self._draw_handle_2d = bpy.types.SpaceView3D.draw_handler_add(self._draw_2d, (context,), 'WINDOW', 'POST_PIXEL')
            return True
        except Exception:
            self._draw_handle_2d = None
            return False

    def _remove_draw_handlers(self):
        self._overlay_front_replay_managed = False
        if self._draw_handle_3d is not None:
            bpy.types.SpaceView3D.draw_handler_remove(self._draw_handle_3d, 'WINDOW')
            self._draw_handle_3d = None
        if self._draw_handle_2d is not None:
            bpy.types.SpaceView3D.draw_handler_remove(self._draw_handle_2d, 'WINDOW')
            self._draw_handle_2d = None
        self._draw_context = None

    def _update_status(self, context):
        prefs = get_prefs(context)
        parts = [
            f"SVS [{self._behavior}]",
            "PropEdit" + ("ON" if self._use_prop else "OFF"),
            "BlenderO:" + ("ON" if self._prop_enabled else "OFF"),
            "Baseline:" + str(pref_get(prefs, "baseline", "INDIVIDUAL")),
            "Loop" + ("ON" if bool(pref_get(prefs, "loop_priority", False)) else "OFF"),
            "Ring" + ("ON" if bool(pref_get(prefs, "ring_priority", False)) else "OFF"),
        ]
        if self._numeric_active:
            parts.append("Num:" + self._numeric)
        _status_runtime.set_service(
            "smart_modeling_suite.vertex_slide.modal",
            " | ".join(parts),
            context=context,
        )

    def _clear_status(self, context):
        _status_runtime.clear("smart_modeling_suite.vertex_slide.modal", context=context)

    def _get_active_vert(self, bm):
        selected_indices = _svs_selected_vertex_indices_from_bm(bm)
        try:
            active = bm.select_history.active if bm.select_history else None
        except Exception:
            active = None
        try:
            if isinstance(active, bmesh.types.BMVert):
                if active and active.index in selected_indices:
                    return active
            if isinstance(active, bmesh.types.BMEdge) and getattr(active, 'select', False):
                for v in active.verts:
                    if v.index in selected_indices:
                        return v
            if isinstance(active, bmesh.types.BMFace) and getattr(active, 'select', False):
                for v in active.verts:
                    if v.index in selected_indices:
                        return v
        except Exception:
            pass
        try:
            for vi in sorted(selected_indices):
                if 0 <= vi < len(bm.verts):
                    return bm.verts[vi]
        except Exception:
            pass
        return None

    def _refresh_seed_edges(self, context, force=False):
        prefs = get_prefs(context)
        want_loop = bool(pref_get(prefs, "loop_priority", False))
        want_ring = bool(pref_get(prefs, "ring_priority", False))

        for obj in self._objs:
            bm = self._bms[obj]
            av = self._get_active_vert(bm)
            seed_edge = av.link_edges[0] if (av is not None and av.link_edges) else None
            prev = self._seed_edge_by_obj.get(obj)
            changed = (prev is None) or (seed_edge is None) or (prev.index != seed_edge.index)
            self._seed_edge_by_obj[obj] = seed_edge

            if force or changed:
                if want_loop or want_ring:
                    loop_set, ring_set = compute_loop_ring_sets(
                        context,
                        obj,
                        bm,
                        seed_edge,
                        want_loop=want_loop,
                        want_ring=want_ring,
                    )
                    self._loop_set[obj] = loop_set
                    self._ring_set[obj] = ring_set
                else:
                    self._loop_set[obj] = set()
                    self._ring_set[obj] = set()
            else:
                self._loop_set.setdefault(obj, set())
                self._ring_set.setdefault(obj, set())

    def modal(self, context, event):
        if event.type in {'LEFTMOUSE', 'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
            return self._finish(context, cancelled=False)

        if event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
            return self._finish(context, cancelled=True)

        if event.value == 'PRESS':
            if event.type == 'C':
                prefs = get_prefs(context)
                order = ['STRAIGHT', 'STOP', 'CORNER']
                if event.shift:
                    new_prop_value = not bool(pref_get(prefs, "use_proportional_editing", True))
                    pref_set(prefs, "use_proportional_editing", new_prop_value)
                    self._rebuild_proportional(context)
                    self._behavior = pref_get(prefs, "hit_behavior_proportional", "CORNER") if self._use_prop else pref_get(prefs, "hit_behavior_normal", "STOP")
                    self._refresh_seed_edges(context, force=True)
                else:
                    cur = self._behavior
                    self._behavior = order[(order.index(cur) + 1) % len(order)] if cur in order else 'STOP'
                    if self._use_prop:
                        pref_set(prefs, "hit_behavior_proportional", self._behavior)
                    else:
                        pref_set(prefs, "hit_behavior_normal", self._behavior)
                    self._clear_item_runtime_caches(clear_edge_pick=False)
                self._update_status(context)
                self._apply(context, event)
                return {'RUNNING_MODAL'}

            if event.type == 'L':
                prefs = get_prefs(context)
                pref_set(prefs, "loop_priority", not bool(pref_get(prefs, "loop_priority", False)))
                self._refresh_seed_edges(context, force=True)
                self._clear_item_runtime_caches(clear_edge_pick=False)
                self._update_status(context)
                self._apply(context, event)
                return {'RUNNING_MODAL'}

            if event.type == 'R':
                prefs = get_prefs(context)
                pref_set(prefs, "ring_priority", not bool(pref_get(prefs, "ring_priority", False)))
                self._refresh_seed_edges(context, force=True)
                self._clear_item_runtime_caches(clear_edge_pick=False)
                self._update_status(context)
                self._apply(context, event)
                return {'RUNNING_MODAL'}

            if event.type == 'B':
                prefs = get_prefs(context)
                pref_set(prefs, "baseline", 'ACTIVE' if pref_get(prefs, "baseline", 'INDIVIDUAL') == 'INDIVIDUAL' else 'INDIVIDUAL')
                self._clear_item_runtime_caches(clear_edge_pick=False)
                self._update_status(context)
                self._apply(context, event)
                return {'RUNNING_MODAL'}

            if event.type in {'MINUS', 'NUMPAD_MINUS'}:
                if not self._numeric_active:
                    self._numeric_active = True
                    self._numeric = "-"
                elif self._numeric == "":
                    self._numeric = "-"
                self._update_status(context)
                self._apply(context, event)
                return {'RUNNING_MODAL'}

            if event.type in {'PERIOD', 'NUMPAD_PERIOD'}:
                if not self._numeric_active:
                    self._numeric_active = True
                    self._numeric = "0."
                elif '.' not in self._numeric:
                    self._numeric += '.'
                self._update_status(context)
                self._apply(context, event)
                return {'RUNNING_MODAL'}

            if event.type == 'BACK_SPACE' and self._numeric_active:
                self._numeric = self._numeric[:-1]
                self._update_status(context)
                self._apply(context, event)
                return {'RUNNING_MODAL'}

            if event.type in {'DEL', 'X'} and self._numeric_active:
                self._numeric = ""
                self._numeric_active = False
                self._update_status(context)
                self._apply(context, event)
                return {'RUNNING_MODAL'}

            if event.type.startswith('NUMPAD_') and len(event.type) == 8 and event.type[-1].isdigit():
                self._numeric_active = True
                self._numeric += event.type[-1]
                self._update_status(context)
                self._apply(context, event)
                return {'RUNNING_MODAL'}

            if event.type in {'ZERO', 'ONE', 'TWO', 'THREE', 'FOUR', 'FIVE', 'SIX', 'SEVEN', 'EIGHT', 'NINE'}:
                digit_map = {
                    'ZERO': '0', 'ONE': '1', 'TWO': '2', 'THREE': '3', 'FOUR': '4',
                    'FIVE': '5', 'SIX': '6', 'SEVEN': '7', 'EIGHT': '8', 'NINE': '9',
                }
                self._numeric_active = True
                self._numeric += digit_map[event.type]
                self._update_status(context)
                self._apply(context, event)
                return {'RUNNING_MODAL'}

        if event.type in {'WHEELUPMOUSE', 'WHEELDOWNMOUSE'} and event.value == 'PRESS':
            tool = context.tool_settings
            cur = None
            if hasattr(tool, "proportional_distance"):
                try:
                    cur = float(getattr(tool, "proportional_distance", 0.0))
                except Exception:
                    cur = None
            if cur is None or cur <= 0.0:
                cur = float(getattr(tool, "proportional_size", 1.0))
            step = max(0.001, cur * 0.1)
            newv = cur + step if event.type == 'WHEELUPMOUSE' else max(0.001, cur - step)
            try:
                if hasattr(tool, "proportional_distance"):
                    setattr(tool, "proportional_distance", newv)
            except Exception:
                pass
            try:
                setattr(tool, "proportional_size", newv)
            except Exception:
                pass
            self._rebuild_proportional(context)
            self._update_status(context)
            self._apply(context, event)
            return {'RUNNING_MODAL'}

        if event.type == 'MOUSEMOVE':
            self._apply(context, event)
            return {'RUNNING_MODAL'}

        return {'RUNNING_MODAL'}

    def _parse_numeric_ratio(self):
        if not self._numeric_active or self._numeric in {"", "-", ".", "0."}:
            return None
        try:
            val = float(self._numeric)
        except Exception:
            return None
        if abs(val) > 1.0:
            val = val / 100.0
        return val

    def _cache_screen(self, cache, vert_index):
        screen = cache['screen'][vert_index]
        if screen is not _SVS_UNSET:
            return screen

        world_co = cache['mat_world'] @ cache['orig_co'][vert_index]
        p = view3d_utils.location_3d_to_region_2d(self._region, self._rv3d, world_co)
        if p is None:
            cache['screen'][vert_index] = None
            return None

        out = Vector((float(p.x), float(p.y)))
        cache['screen'][vert_index] = out
        return out

    def _cache_edges(self, cache, vert_index):
        edges = cache['edges'][vert_index]
        if edges is not _SVS_UNSET:
            return edges

        bm = cache['bm']
        v = bm.verts[vert_index]
        p0 = self._cache_screen(cache, vert_index)
        if p0 is None or not v.link_edges:
            cache['edges'][vert_index] = ()
            return cache['edges'][vert_index]

        out = []
        orig_co = cache['orig_co']
        co_v = orig_co[vert_index]
        for e in v.link_edges:
            ov = e.other_vert(v)
            j = ov.index
            p1 = self._cache_screen(cache, j)
            if p1 is None:
                continue
            dv = p1 - p0
            slen_sq = dv.length_squared
            if slen_sq <= 1.0e-12:
                continue
            slen = slen_sq ** 0.5
            out.append((
                j,
                dv,
                slen,
                dv / slen,
                orig_co[j] - co_v,
                e.index,
            ))

        cache['edges'][vert_index] = tuple(out)
        return cache['edges'][vert_index]

    def _pick_edge_info_by_mouse(self, obj, vert_index, mouse_dir_2d, prev_neighbor=None, allow_lock=False, item=None):
        cache = self._obj_cache.get(obj)
        if cache is None:
            return None, -2.0

        edges = self._cache_edges(cache, vert_index)
        if not edges:
            return None, -2.0

        loop_set = self._loop_set.get(obj, set())
        ring_set = self._ring_set.get(obj, set())

        best = None
        best_score = -2.0
        prev_edge = None
        prev_score = -2.0

        for info in edges:
            score = mouse_dir_2d.dot(info[3])
            edge_index = info[5]
            if (self._cfg_loop_priority and edge_index in loop_set) or (self._cfg_ring_priority and edge_index in ring_set):
                score += self._cfg_loop_ring_bonus

            if score > best_score:
                best_score = score
                best = info

            if prev_neighbor is not None and info[0] == prev_neighbor:
                prev_edge = info
                prev_score = score

        chosen = best
        chosen_score = best_score
        if allow_lock and self._cfg_edge_lock_enabled and prev_neighbor is not None and prev_edge is not None and best is not None:
            # Angle-following hysteresis.  Keep the previous rail only while the
            # new candidate is not clearly better.  This removes flip-flop jitter
            # near equal angles without freezing the slide direction for the whole
            # stroke.
            try:
                margin = max(0.0, float(self._cfg_edge_lock_switch_margin))
            except Exception:
                margin = 0.08
            if (best_score - prev_score) <= margin:
                chosen = prev_edge
                chosen_score = prev_score
                if item is not None:
                    item.edge_switch_wait = 0

        return chosen, chosen_score

    def _pick_next_at_vertex_cached(self, obj, cur_vi, prev_vi, prev_dir3, mouse_dir_2d, behavior):
        if behavior == 'STOP':
            return None

        cache = self._obj_cache.get(obj)
        if cache is None:
            return None

        edges = self._cache_edges(cache, cur_vi)
        if not edges:
            return None

        loop_set = self._loop_set.get(obj, set())
        ring_set = self._ring_set.get(obj, set())

        best = None
        best_score = -1.0e18
        fallback = None
        fallback_score = -1.0e18

        for info in edges:
            next_vi = info[0]
            local_vec = info[4]
            if local_vec.length_squared <= 1.0e-18:
                continue
            dir3 = local_vec.normalized()
            cont = dir3.dot(prev_dir3)
            dot2 = mouse_dir_2d.dot(info[3])

            if behavior == 'STRAIGHT':
                score = cont
            else:
                score = dot2 + (self._cfg_flow_bias * cont)
                edge_index = info[5]
                if (self._cfg_loop_priority and edge_index in loop_set) or (self._cfg_ring_priority and edge_index in ring_set):
                    score += self._cfg_loop_ring_bonus

            if prev_vi is None or next_vi != prev_vi:
                if score > best_score:
                    best_score = score
                    best = next_vi
            if score > fallback_score:
                fallback_score = score
                fallback = next_vi

        return best if best is not None else fallback

    def _build_corner_path_cached(self, obj, start_vi, mouse_dir_2d, max_steps=64, first_edge_info=None):
        cache = self._obj_cache.get(obj)
        if cache is None:
            return (), ()

        first_info = first_edge_info
        if first_info is None:
            first_info, _ = self._pick_edge_info_by_mouse(obj, start_vi, mouse_dir_2d, prev_neighbor=None, allow_lock=False)
        if first_info is None:
            return (), ()

        path = []
        cum = []
        total = 0.0
        cur_vi = start_vi
        next_vi = first_info[0]
        prev_vi = None

        for _ in range(max_steps):
            cur_co = cache['orig_co'][cur_vi]
            next_co = cache['orig_co'][next_vi]
            seg = next_co - cur_co
            seg_len = seg.length
            if seg_len <= 1.0e-12:
                break

            path.append((cur_vi, next_vi, seg_len, seg))
            total += seg_len
            cum.append(total)

            prev_dir3 = seg / seg_len
            prev_vi, cur_vi = cur_vi, next_vi
            next_vi = self._pick_next_at_vertex_cached(obj, cur_vi, prev_vi, prev_dir3, mouse_dir_2d, 'CORNER')
            if next_vi is None:
                break

        return tuple(path), tuple(cum)

    def _pos_along_corner_path(self, obj, path, cum, distance):
        if not path or not cum or distance <= 0.0:
            return None

        cache = self._obj_cache.get(obj)
        if cache is None:
            return None

        if distance >= cum[-1]:
            return cache['orig_co'][path[-1][1]].copy()

        import bisect
        seg_i = bisect.bisect_left(cum, distance)
        prev_cum = 0.0 if seg_i == 0 else cum[seg_i - 1]
        cur_vi, _next_vi, seg_len, seg_vec = path[seg_i]
        if seg_len <= 1.0e-12:
            return cache['orig_co'][cur_vi].copy()

        t = (distance - prev_cum) / seg_len
        if t < 0.0:
            t = 0.0
        elif t > 1.0:
            t = 1.0
        return cache['orig_co'][cur_vi] + (seg_vec * t)

    def _walk_cached(self, obj, start_vi, next_vi, distance, behavior, mouse_dir_2d):
        cache = self._obj_cache.get(obj)
        if cache is None:
            return None

        remaining = float(distance)
        cur_vi = int(start_vi)
        next_vi = int(next_vi)
        cur_co = cache['orig_co'][cur_vi].copy()
        prev_vi = None

        first_seg = cache['orig_co'][next_vi] - cache['orig_co'][cur_vi]
        prev_dir3 = first_seg.normalized() if first_seg.length > 1.0e-12 else Vector((1.0, 0.0, 0.0))

        for _ in range(64):
            next_co = cache['orig_co'][next_vi]
            seg = next_co - cur_co
            seg_len = seg.length
            if seg_len <= 1.0e-12:
                candidate = self._pick_next_at_vertex_cached(obj, next_vi, prev_vi, prev_dir3, mouse_dir_2d, behavior)
                if candidate is None:
                    return cur_co
                prev_vi, cur_vi, next_vi = cur_vi, next_vi, candidate
                cur_co = cache['orig_co'][cur_vi].copy()
                seg = cache['orig_co'][next_vi] - cur_co
                seg_len = seg.length
                if seg_len <= 1.0e-12:
                    return cur_co
                prev_dir3 = seg / seg_len

            dir3 = seg / seg_len
            if behavior == 'STOP':
                return cur_co + (dir3 * min(seg_len, remaining))
            if remaining <= seg_len:
                return cur_co + (dir3 * remaining)

            cur_co = next_co.copy()
            remaining -= seg_len
            prev_vi = cur_vi
            cur_vi = next_vi
            prev_dir3 = dir3
            candidate = self._pick_next_at_vertex_cached(obj, cur_vi, prev_vi, prev_dir3, mouse_dir_2d, behavior)
            if candidate is None:
                return cur_co
            next_vi = candidate

        return cur_co

    def _apply(self, context, event):
        now = time.time()
        if event.type == 'MOUSEMOVE' and (now - self._last_update_time) < (1.0 / 60.0):
            return
        self._last_update_time = now

        self._refresh_view_caches_if_needed()

        prefs = get_prefs(context)
        self._cfg_edge_lock_enabled = bool(pref_get(prefs, "edge_lock_enabled", True))
        self._cfg_edge_lock_keep_dot = float(pref_get(prefs, "edge_lock_keep_dot", 0.75))
        self._cfg_edge_lock_switch_margin = float(pref_get(prefs, "edge_lock_switch_margin", 0.08))
        self._cfg_loop_priority = bool(pref_get(prefs, "loop_priority", False))
        self._cfg_ring_priority = bool(pref_get(prefs, "ring_priority", False))
        self._cfg_loop_ring_bonus = float(pref_get(prefs, "loop_ring_bonus", 0.25))
        self._cfg_flow_bias = float(pref_get(prefs, "flow_bias", 0.35))
        self._cfg_sensitivity = float(pref_get(prefs, "sensitivity", 0.0045))
        self._cfg_slow_factor = float(pref_get(prefs, "slow_factor", 0.2))
        self._cfg_snap_step = float(pref_get(prefs, "snap_step", 0.1))
        self._cfg_baseline = str(pref_get(prefs, "baseline", 'INDIVIDUAL'))

        mouse = Vector((float(event.mouse_region_x), float(event.mouse_region_y)))
        self._mouse_vec = mouse - self._init_mouse
        if event.type == 'MOUSEMOVE' and self._mouse_vec.length_squared < 1.0 and not self._numeric_active:
            self._tag_redraw(context)
            return

        self._edge_switch_allowed = bool(self._mouse_vec.length >= float(getattr(self, '_edge_switch_min_mouse_px', 6.0)))

        if self._mouse_vec.length_squared > 1.0e-12:
            mdir_raw = self._mouse_vec.normalized()
            self._last_mdir = mdir_raw.copy()
        else:
            mdir_raw = self._last_mdir.copy()

        if not self._mouse_smooth_inited:
            self._mouse_vec_smooth = self._mouse_vec.copy()
            self._mouse_smooth_inited = True
        else:
            self._mouse_vec_smooth = self._mouse_vec_smooth.lerp(self._mouse_vec, 0.35)

        mdir_corner = None
        if self._mouse_vec_smooth.length_squared >= 1.0:
            mdir_corner = self._mouse_vec_smooth.normalized()

        # Use a native-like screen-space slide amount.  The previous object-space
        # multiplier made large edges move too little for the same mouse travel.
        # Here, dragging roughly one projected edge length moves one edge length,
        # while the existing Sensitivity setting remains available as a multiplier
        # around the default 1.0x behavior.
        signed_amount = self._mouse_vec.length
        if event.alt:
            signed_amount *= -1.0

        numeric_ratio = self._parse_numeric_ratio()
        direction_sign = -1.0 if ((numeric_ratio is not None and numeric_ratio < 0.0) or signed_amount < 0.0) else 1.0

        amount_mouse_vec = self._mouse_vec if direction_sign >= 0.0 else -self._mouse_vec
        base_sensitivity = 0.0045
        try:
            screen_sensitivity = float(self._cfg_sensitivity) / base_sensitivity
        except Exception:
            screen_sensitivity = 1.0
        if screen_sensitivity < 0.01:
            screen_sensitivity = 0.01
        elif screen_sensitivity > 50.0:
            screen_sensitivity = 50.0
        if event.shift:
            screen_sensitivity *= self._cfg_slow_factor

        base_pick_dir = mdir_raw if direction_sign >= 0.0 else -mdir_raw
        corner_pick_dir = None
        if mdir_corner is not None:
            corner_pick_dir = mdir_corner if direction_sign >= 0.0 else -mdir_corner

        numeric_ratio_abs = abs(numeric_ratio) if numeric_ratio is not None else None

        baseline_dir = None
        if self._cfg_baseline == 'ACTIVE':
            for obj in self._objs:
                bm = self._bms[obj]
                av = self._get_active_vert(bm)
                if av is None:
                    continue
                edge_info, _ = self._pick_edge_info_by_mouse(obj, av.index, base_pick_dir, prev_neighbor=None, allow_lock=False)
                if edge_info is not None:
                    baseline_dir = edge_info[3].copy()
                    break

        if self._cfg_loop_priority or self._cfg_ring_priority:
            self._refresh_seed_edges(context, force=False)

        global_rebuild_corner = False
        if self._behavior == 'CORNER' and corner_pick_dir is not None:
            if self._prev_corner_dir is None or self._prev_corner_dir.dot(corner_pick_dir) < 0.94:
                global_rebuild_corner = True
                self._prev_corner_dir = corner_pick_dir.copy()

        affected_objects = set()
        chosen_preview_paths = {}

        for it in self._items:
            obj = it.obj
            bm = it.bm
            v = bm.verts[it.vi]
            cache = self._obj_cache.get(obj)
            if cache is None:
                continue
            affected_objects.add(obj)

            ref_dir = baseline_dir if baseline_dir is not None else base_pick_dir
            ref_dir = ref_dir if ref_dir.length_squared > 1.0e-12 else base_pick_dir

            edge_info, edge_score = self._pick_edge_info_by_mouse(
                obj,
                it.vi,
                ref_dir,
                prev_neighbor=it.active_neighbor,
                allow_lock=True,
                item=it,
            )
            if edge_info is None:
                v.co = cache['orig_co'][it.vi].copy()
                continue

            it.active_neighbor = edge_info[0]
            it.last_dot = edge_score

            edge_screen_len = float(edge_info[2])
            edge_len = float(edge_info[4].length)
            if edge_len <= 1.0e-12 or edge_screen_len <= 1.0e-12:
                v.co = cache['orig_co'][it.vi].copy()
                continue

            if numeric_ratio_abs is not None:
                amount = numeric_ratio_abs * edge_len
            else:
                # Convert mouse pixels to slide distance through the chosen edge's
                # projected screen length. This makes Vertex Slide track the
                # cursor similarly to Blender's regular Vertex Slide instead of
                # using a small fixed object-space distance per pixel.
                screen_len = max(edge_screen_len, 1.0e-6)
                projected_px = float(amount_mouse_vec.dot(edge_info[3])) if amount_mouse_vec.length_squared > 1.0e-12 else 0.0
                if projected_px < 0.0:
                    projected_px = 0.0
                amount = (projected_px / screen_len) * edge_len * screen_sensitivity
            if event.ctrl:
                step = max(1.0e-6, self._cfg_snap_step)
                ratio = amount / edge_len
                ratio = round(ratio / step) * step
                amount = ratio * edge_len
            amount *= float(it.weight)

            if self._behavior == 'CORNER':
                corner_dir = corner_pick_dir if corner_pick_dir is not None else ref_dir
                corner_dir = corner_dir if corner_dir.length_squared > 1.0e-12 else ref_dir
                if corner_dir.length_squared <= 1.0e-12:
                    v.co = cache['orig_co'][it.vi].copy()
                    continue

                corner_seed = (
                    edge_info[0],
                    round(corner_dir.x, 4),
                    round(corner_dir.y, 4),
                )
                if global_rebuild_corner or it.corner_path is None or it.corner_seed != corner_seed:
                    path, cum = self._build_corner_path_cached(obj, it.vi, corner_dir, max_steps=64, first_edge_info=edge_info)
                    it.corner_path = path
                    it.corner_cum = cum
                    it.corner_seed = corner_seed
                pos = self._pos_along_corner_path(obj, it.corner_path, it.corner_cum, amount)
                v.co = pos if pos is not None else cache['orig_co'][it.vi].copy()
            else:
                pos = self._walk_cached(obj, it.vi, edge_info[0], amount, self._behavior, ref_dir)
                v.co = pos if pos is not None else cache['orig_co'][it.vi].copy()

        if bool(pref_get(prefs, "show_guides", True)) and self._behavior == 'CORNER' and corner_pick_dir is not None:
            for obj in self._objs:
                bm = self._bms[obj]
                av = self._get_active_vert(bm)
                if av is None:
                    continue
                path, _cum = self._build_corner_path_cached(obj, av.index, corner_pick_dir, max_steps=16)
                if not path:
                    continue
                cache = self._obj_cache.get(obj)
                pts = [obj.matrix_world @ cache['orig_co'][av.index].copy()]
                for _cur_vi, next_vi, _seg_len, _seg_vec in path:
                    pts.append(obj.matrix_world @ cache['orig_co'][next_vi].copy())
                chosen_preview_paths[obj] = pts
        self._corner_paths = chosen_preview_paths

        for obj in affected_objects:
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)

        self._tag_redraw(context)

    def _tag_redraw(self, context):
        screen = getattr(context, 'screen', None)
        if screen is None:
            return
        for area in screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

    def _draw_3d(self, context):
        prefs = get_prefs(context)
        if not bool(pref_get(prefs, "show_guides", True)):
            return

        lines = []
        for it in self._items:
            if it.weight < 0.9999 or it.active_neighbor is None:
                continue
            bm = it.bm
            obj = it.obj
            try:
                v = bm.verts[it.vi]
                v2 = bm.verts[it.active_neighbor]
            except Exception:
                continue
            lines.append(obj.matrix_world @ v.co)
            lines.append(obj.matrix_world @ v2.co)

        if lines:
            drawutil.draw_lines_3d(lines, color=(1.0, 1.0, 1.0, 0.8))

        for pts in getattr(self, '_corner_paths', {}).values():
            if pts and len(pts) >= 2:
                drawutil.draw_polyline_3d(pts, color=(1.0, 1.0, 1.0, 0.35))

    def _draw_2d(self, context):
        prefs = get_prefs(context)
        if bool(pref_get(prefs, "show_guides", True)) and self._use_prop:
            center = (self._init_mouse.x, self._init_mouse.y)
            rad = max(12.0, float(getattr(self, "_prop_preview_radius_px", 60.0))) if self._prop_projected else 60.0
            drawutil.draw_circle_2d(center, rad, segments=64, color=(1.0, 1.0, 1.0, 0.35))

        if bool(pref_get(prefs, "show_hud", True)):
            lines = [
                f"Behavior: {self._behavior}   (C to cycle)",
                f"Apply Prop Edit: {'ON' if bool(pref_get(prefs, 'use_proportional_editing', True)) else 'OFF'}  /  Blender O: {'ON' if self._prop_enabled else 'OFF'}  /  Active: {'ON' if self._use_prop else 'OFF'}  (Shift+C)",
                f"Baseline: {pref_get(prefs, 'baseline', 'INDIVIDUAL')}  (B)",
                f"Loop: {'ON' if bool(pref_get(prefs, 'loop_priority', False)) else 'OFF'} (L)   Ring: {'ON' if bool(pref_get(prefs, 'ring_priority', False)) else 'OFF'} (R)",
                "Shift=Slow  Ctrl=Snap  Alt=Invert  Wheel=Radius  Numbers=Ratio",
            ]
            if self._numeric_active:
                lines.append(f"Numeric: {self._numeric}")
            drawutil.draw_hud_text(lines, x=16, y=80)

    def _finish(self, context, cancelled=False):
        if cancelled:
            for it in self._items:
                try:
                    it.bm.verts[it.vi].co = it.orig
                except Exception:
                    pass
            for obj in self._objs:
                try:
                    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
                except Exception:
                    pass

        if _SVS_ACTIVE_MODAL is self:
            _svs_set_active_modal(None)
        self._remove_draw_handlers()
        self._clear_status(context)
        self._tag_redraw(context)
        return {'CANCELLED'} if cancelled else {'FINISHED'}



# ------------------------------------------------------------------------------
# Toggle-style Vertex Slide constraint
# ------------------------------------------------------------------------------
_SVS_CONSTRAINT_MONITOR_RUNNING = False
_SVS_CONSTRAINT_TIMER_INTERVAL = 0.04
_SVS_VIEW_NAVIGATION_SUSPEND_SECONDS = 0.22
_SVS_CONSTRAINT_EPS = 1.0e-6
_SVS_CONSTRAINT_TIMER_OBJECT = None
# Live modal monitor instance.  Blender's window-modal timers do not expose the
# operator instance after bpy.ops invocation, so keep a private pointer for
# explicit rebasing after topology-changing Smart Modeling operators.
_SVS_ACTIVE_CONSTRAINT_MONITOR = None
# Topology-changing operators must not let the live Vertex Slide monitor read or
# write the edit BMesh while Blender is rebuilding its topology and derived
# caches.  The counter supports nested Smart Modeling operations, while the
# pending flag makes the monitor rebase itself on the first safe event after the
# transaction.  Keeping the rebase inside the monitor avoids touching the same
# edit BMesh from two operator lifecycles during native finalization.
_SVS_EXTERNAL_TOPOLOGY_DEPTH = 0
_SVS_EXTERNAL_REBASE_PENDING = False
_SVS_CONSTRAINT_IDLE_LOCK_TICKS = 8
_SVS_TOGGLE_WATCHDOG_INTERVAL = 0.25
_SVS_TOGGLE_WATCHDOG_REGISTERED = False


def _svs_schedule_safe_undo_push(message="Vertex Slide Constraint"):
    # Intentionally no-op.  The crash logs show Blender 5.1.0 failing while
    # storing/reporting operator state after these lightweight toggle commands.
    # Avoiding extra operator calls here keeps the toggle path history-free.
    return None


def _svs_scene_enabled(context):
    try:
        wm, scene = _svs_toggle_roots(context)
        if wm is not None:
            try:
                value = bool(getattr(wm, _SVS_TRANSIENT_WM_FLAG))
                try:
                    if scene is not None:
                        setattr(scene, _SVS_TRANSIENT_SCENE_FLAG, value)
                except Exception:
                    pass
                return value
            except Exception:
                pass
        if scene is not None:
            return bool(getattr(scene, _SVS_TRANSIENT_SCENE_FLAG, False))
    except Exception:
        pass
    return False


def _svs_set_scene_enabled(context, value):
    value = bool(value)
    try:
        wm, scene = _svs_toggle_roots(context)
        for owner, attr in ((wm, _SVS_TRANSIENT_WM_FLAG), (scene, _SVS_TRANSIENT_SCENE_FLAG)):
            if owner is None:
                continue
            try:
                setattr(owner, attr, value)
            except Exception:
                pass
    except Exception:
        pass
    _svs_tag_statusbar_redraw(context)


def _svs_get_edit_mesh_objects(context):
    try:
        if getattr(context, "mode", "") != 'EDIT_MESH':
            return []
    except Exception:
        return []
    try:
        objects = list(getattr(context, "objects_in_mode_unique_data", None) or getattr(context, "objects_in_mode", None) or [])
    except Exception:
        objects = []
    if not objects:
        obj = getattr(context, "object", None)
        if obj is not None:
            objects = [obj]
    return [obj for obj in objects if obj is not None and getattr(obj, "type", None) == 'MESH' and getattr(obj, "data", None) is not None]


def _svs_bm_signature(bm):
    try:
        # This signature is evaluated on every monitor tick, so keep it limited
        # to the data that changes the constraint target set.  Edge and face
        # selection are already expanded into their component vertices by
        # _svs_selected_vertex_indices_from_bm(), which is enough for the slide
        # constraint and avoids two additional full BMesh scans per tick.
        selected_verts = tuple(sorted(_svs_selected_vertex_indices_from_bm(bm)))
        return (len(bm.verts), len(bm.edges), len(bm.faces), selected_verts)
    except Exception:
        return None


def _svs_project_to_slide_edge(
    index,
    raw_co,
    anchor_coords,
    bm,
    behavior='STOP',
    locked_neighbor=None,
    lock_enabled=True,
    switch_margin=0.08,
):
    """Project a transformed vertex position onto an angle-preferred slide rail.

    The chosen rail follows the current movement direction. A previous rail is
    kept only while the score difference is within a small hysteresis margin, so
    near-equal candidates do not flicker but a clearly closer movement angle can
    switch to the appropriate connected edge.
    """
    try:
        index = int(index)
        orig = anchor_coords[index]
        delta = raw_co - orig
        if delta.length_squared <= (_SVS_CONSTRAINT_EPS * _SVS_CONSTRAINT_EPS):
            return orig.copy(), locked_neighbor
        move_len_sq = max(delta.length_squared, 1.0e-18)
        move_dir = delta / (move_len_sq ** 0.5)
        v = bm.verts[index]
    except Exception:
        return raw_co.copy(), locked_neighbor

    allow_straight = str(behavior or 'STOP') == 'STRAIGHT'

    try:
        edges = list(v.link_edges)
    except Exception:
        edges = []

    candidates = []
    for edge in edges:
        try:
            ov = edge.other_vert(v)
            ni = int(ov.index)
            if ni < 0 or ni >= len(anchor_coords):
                continue
            vec = anchor_coords[ni] - orig
            length_sq = vec.length_squared
            if length_sq <= 1.0e-18:
                continue
            edge_len = length_sq ** 0.5
            axis = vec / edge_len
            angle_score = move_dir.dot(axis)
            t_raw = delta.dot(vec) / length_sq
            t = t_raw
            if allow_straight:
                t = max(-0.25, min(1.25, t))
            else:
                t = max(0.0, min(1.0, t))
                if t_raw < 0.0:
                    angle_score -= 1.0
            cand = orig + (vec * t)
            dist = (raw_co - cand).length_squared
            norm_dist = dist / max(length_sq, 1.0e-18)
            candidates.append((angle_score, -norm_dist, -dist, ni, cand, length_sq, t))
        except Exception:
            continue

    if not candidates:
        return raw_co.copy(), locked_neighbor

    best = max(candidates, key=lambda item: (item[0], item[1], item[2]))
    chosen = best
    chosen_neighbor = best[3]

    if lock_enabled and locked_neighbor is not None:
        try:
            locked_neighbor = int(locked_neighbor)
        except Exception:
            locked_neighbor = None
        locked = None
        if locked_neighbor is not None:
            for item in candidates:
                if item[3] == locked_neighbor:
                    locked = item
                    break
        if locked is not None:
            try:
                margin = max(0.0, float(switch_margin))
            except Exception:
                margin = 0.08
            if (best[0] - locked[0]) <= margin:
                chosen = locked
                chosen_neighbor = locked_neighbor

    return chosen[4].copy(), chosen_neighbor


def _svs_rebase_active_monitor_to_current_selection(context=None):
    """Synchronize the live constraint monitor with the current edit mesh.

    Topology-changing operators such as Mesh Connect can create and select new
    edges while Vertex Slide is ON.  If the user starts a transform before the
    modal timer has observed that new topology, the first timer tick can treat
    the already-transformed coordinates as the new baseline and the beginning of
    the transform behaves unconstrained.  Rebasing immediately after the
    topology operation fixes the baseline before the next transform begins.
    """
    try:
        monitor = globals().get('_SVS_ACTIVE_CONSTRAINT_MONITOR') or globals().get('_SVS_CONSTRAINT_TIMER_OBJECT')
        if monitor is None or not bool(globals().get('_SVS_CONSTRAINT_MONITOR_RUNNING', False)):
            return False
        fn = getattr(monitor, '_rebase_current_edit_context', None)
        if not callable(fn):
            return False
        return bool(fn(context or getattr(bpy, 'context', None)))
    except Exception:
        return False


def external_topology_change_active():
    """Return whether another Smart Modeling operator owns edit topology."""
    try:
        return int(globals().get('_SVS_EXTERNAL_TOPOLOGY_DEPTH', 0) or 0) > 0
    except Exception:
        return False


def begin_external_topology_change(context=None):
    """Suspend Vertex Slide BMesh access for an external topology transaction.

    This function only changes Python-side monitor state.  It deliberately does
    not call ``bmesh.from_edit_mesh`` because the caller may already be inside a
    destructive BMesh operation.
    """
    del context
    global _SVS_EXTERNAL_TOPOLOGY_DEPTH, _SVS_EXTERNAL_REBASE_PENDING
    try:
        _SVS_EXTERNAL_TOPOLOGY_DEPTH = max(0, int(_SVS_EXTERNAL_TOPOLOGY_DEPTH)) + 1
    except Exception:
        _SVS_EXTERNAL_TOPOLOGY_DEPTH = 1
    _SVS_EXTERNAL_REBASE_PENDING = True

    # Discard only cached coordinates/references held by the Python monitor.
    # The live BMesh itself is owned exclusively by the external operator until
    # end_external_topology_change() is called.
    try:
        monitor = globals().get('_SVS_ACTIVE_CONSTRAINT_MONITOR') or globals().get('_SVS_CONSTRAINT_TIMER_OBJECT')
        if monitor is not None:
            monitor._states = {}
            monitor._release_commit_pending = False
            monitor._request_stop = False
    except Exception:
        pass
    return int(_SVS_EXTERNAL_TOPOLOGY_DEPTH)


def end_external_topology_change(context=None, *, request_rebase=True):
    """Release an external topology transaction without immediate BMesh access.

    The active monitor performs the requested rebase on its next event/timer.
    This ensures Blender has finished operator history, edit-mesh cache, and
    modifier updates before Vertex Slide reads the new topology.
    """
    global _SVS_EXTERNAL_TOPOLOGY_DEPTH, _SVS_EXTERNAL_REBASE_PENDING
    try:
        _SVS_EXTERNAL_TOPOLOGY_DEPTH = max(0, int(_SVS_EXTERNAL_TOPOLOGY_DEPTH) - 1)
    except Exception:
        _SVS_EXTERNAL_TOPOLOGY_DEPTH = 0
    if request_rebase:
        _SVS_EXTERNAL_REBASE_PENDING = True

    ctx = context or getattr(bpy, 'context', None)
    if _SVS_EXTERNAL_TOPOLOGY_DEPTH == 0:
        try:
            if ctx is not None and _svs_scene_enabled(ctx):
                _svs_register_toggle_watchdog()
        except Exception:
            pass
    return int(_SVS_EXTERNAL_TOPOLOGY_DEPTH)


def _svs_consume_pending_external_rebase(monitor, context):
    """Rebase one live monitor after an external topology transaction."""
    global _SVS_EXTERNAL_REBASE_PENDING
    if external_topology_change_active() or not bool(_SVS_EXTERNAL_REBASE_PENDING):
        return False
    try:
        if context is None or not _svs_scene_enabled(context) or getattr(context, 'mode', '') != 'EDIT_MESH':
            return False
    except Exception:
        return False
    fn = getattr(monitor, '_rebase_current_edit_context', None)
    if not callable(fn):
        return False
    try:
        rebased = bool(fn(context))
    except Exception:
        rebased = False
    if rebased:
        _SVS_EXTERNAL_REBASE_PENDING = False
    return rebased


def sync_constraint_after_topology_change(context=None, *, restart=True):
    """Public internal hook used by other Smart Modeling tools.

    It keeps the Vertex Slide ON/OFF state unchanged, but when ON it refreshes
    the monitor baseline to the current selected vertices/edges/faces.  This is
    intentionally not exposed as a user operator and does not modify keymaps.
    """
    ctx = context or getattr(bpy, 'context', None)
    try:
        if ctx is None or not _svs_scene_enabled(ctx):
            return False
        if getattr(ctx, 'mode', '') != 'EDIT_MESH':
            return False
    except Exception:
        return False

    global _SVS_EXTERNAL_REBASE_PENDING
    _SVS_EXTERNAL_REBASE_PENDING = True

    # Never re-enter the edit BMesh while the external operator still owns its
    # destructive topology transaction.  The monitor consumes the pending
    # rebase on the first event after the transaction is released.
    if external_topology_change_active():
        try:
            _svs_register_toggle_watchdog()
        except Exception:
            pass
        return True

    synced = _svs_rebase_active_monitor_to_current_selection(ctx)
    if synced:
        _SVS_EXTERNAL_REBASE_PENDING = False
    if not synced and restart:
        try:
            _svs_register_toggle_watchdog()
        except Exception:
            pass
        try:
            if not bool(getattr(bpy.app, 'background', False)):
                _svs_start_timer_monitor(ctx)
        except Exception:
            pass
        synced = _svs_rebase_active_monitor_to_current_selection(ctx)
        if synced:
            _SVS_EXTERNAL_REBASE_PENDING = False

    try:
        _svs_tag_statusbar_redraw(ctx)
    except Exception:
        pass
    return bool(synced)


# Backward-compatible alias for integration code in other modules.
def ensure_constraint_monitor_synced(context=None, *, restart=True):
    return sync_constraint_after_topology_change(context, restart=restart)


class MESH_OT_smart_vert_slide_constraint_monitor(bpy.types.Operator):
    _jelararagi_status_managed_v2 = True
    bl_idname = "mesh.smart_vert_slide_constraint_monitor"
    bl_label = "Vertex Slide Constraint Monitor"
    bl_description = "Internal monitor that constrains normal Move, Rotate, Scale, and gizmo vertex transforms to connected mesh edges while Vertex Slide is ON."
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    _timer = None

    def _reset_state(self):
        self._states = {}
        self._last_activity = 0.0
        self._request_stop = False
        self._release_commit_pending = False
        self._view_navigation_suspend_until = 0.0

    def _mark_view_navigation_event(self, event):
        try:
            event_type = str(getattr(event, 'type', '') or '')
            now = time.monotonic()
        except Exception:
            return
        nav_events = {
            'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE',
            'TRACKPADPAN', 'TRACKPADZOOM', 'MOUSEROTATE',
        }
        if event_type in nav_events:
            self._view_navigation_suspend_until = max(
                float(getattr(self, '_view_navigation_suspend_until', 0.0) or 0.0),
                now + _SVS_VIEW_NAVIGATION_SUSPEND_SECONDS,
            )
        elif event_type == 'MOUSEMOVE' and now < float(getattr(self, '_view_navigation_suspend_until', 0.0) or 0.0):
            self._view_navigation_suspend_until = now + _SVS_VIEW_NAVIGATION_SUSPEND_SECONDS

    def _view_navigation_suspended(self):
        try:
            return time.monotonic() < float(getattr(self, '_view_navigation_suspend_until', 0.0) or 0.0)
        except Exception:
            return False

    def _state_key(self, obj):
        try:
            return int(obj.as_pointer())
        except Exception:
            return id(obj)

    def _make_state(self, obj, bm):
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        coords = [v.co.copy() for v in bm.verts]
        return {
            'obj_name': getattr(obj, 'name', ''),
            'sig': _svs_bm_signature(bm),
            'last_applied': [co.copy() for co in coords],
            'anchor_coords': None,
            'locked_edges': {},
            'raw_active': False,
            'idle_ticks': 0,
        }

    def _commit_if_idle(self, state):
        if state.get('raw_active'):
            state['idle_ticks'] = int(state.get('idle_ticks', 0)) + 1
            if state['idle_ticks'] >= _SVS_CONSTRAINT_IDLE_LOCK_TICKS:
                state['anchor_coords'] = None
                try:
                    state.get('locked_edges', {}).clear()
                except Exception:
                    state['locked_edges'] = {}
                state['raw_active'] = False
                state['idle_ticks'] = 0

    def _commit_state_to_current(self, obj, state):
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()
        except Exception:
            return False
        try:
            state["last_applied"] = [v.co.copy() for v in bm.verts]
            state["anchor_coords"] = None
            try:
                state.get("locked_edges", {}).clear()
            except Exception:
                state["locked_edges"] = {}
            state["raw_active"] = False
            state["idle_ticks"] = 0
            state["sig"] = _svs_bm_signature(bm)
            return True
        except Exception:
            return False

    def _commit_all_active(self, context):
        committed = False
        try:
            objects = _svs_get_edit_mesh_objects(context)
        except Exception:
            objects = []
        for obj in objects:
            key = self._state_key(obj)
            state = self._states.get(key)
            if not state:
                continue
            if not state.get("raw_active") and state.get("anchor_coords") is None:
                continue
            if self._commit_state_to_current(obj, state):
                committed = True
        return committed

    def _rebase_current_edit_context(self, context):
        """Make current topology and selection the active slide baseline."""
        try:
            if context is None or getattr(context, 'mode', '') != 'EDIT_MESH':
                return False
            objects = _svs_get_edit_mesh_objects(context)
        except Exception:
            objects = []
        if not objects:
            return False

        live_keys = set()
        rebased = False
        for obj in objects:
            try:
                bm = bmesh.from_edit_mesh(obj.data)
                bm.verts.ensure_lookup_table()
                bm.edges.ensure_lookup_table()
                bm.faces.ensure_lookup_table()
                key = self._state_key(obj)
                self._states[key] = self._make_state(obj, bm)
                live_keys.add(key)
                rebased = True
            except Exception:
                continue

        try:
            for key in list(self._states.keys()):
                if key not in live_keys:
                    self._states.pop(key, None)
        except Exception:
            pass

        self._release_commit_pending = False
        self._request_stop = False
        self._last_activity = time.monotonic()
        return bool(rebased)

    def _tick_object(self, context, obj):
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()
        except Exception:
            return False

        key = self._state_key(obj)
        sig = _svs_bm_signature(bm)
        state = self._states.get(key)
        if state is None:
            self._states[key] = self._make_state(obj, bm)
            return False
        if state.get('sig') != sig:
            # Selection, mesh select mode, and topology operations are normal while
            # the toggle is ON.  Rebase the monitor state for the new edit context
            # without changing the user's ON/OFF intent.  This keeps the constraint
            # active through Vertex / Edge / Face mode changes and selection edits
            # while avoiding BMesh writes during the selection-changing operator.
            self._states[key] = self._make_state(obj, bm)
            self._request_stop = False
            return False

        prefs = get_prefs(context)
        tool = getattr(context, 'tool_settings', None)
        use_prop_setting = bool(pref_get(prefs, "use_proportional_editing", True))
        prop_enabled = False
        if tool is not None:
            try:
                prop_enabled = bool(getattr(tool, 'use_proportional_edit', False))
            except Exception:
                prop_enabled = False
            try:
                mode = str(getattr(tool, 'proportional_edit', '') or '')
                if mode and mode not in {'DISABLED', 'OFF', 'NONE'}:
                    prop_enabled = True
            except Exception:
                pass
        allow_unselected = bool(use_prop_setting and prop_enabled)
        behavior = str(pref_get(prefs, "hit_behavior_proportional", "CORNER") if allow_unselected else pref_get(prefs, "hit_behavior_normal", "STOP"))
        edge_lock_enabled = bool(pref_get(prefs, "edge_lock_enabled", True))
        edge_lock_switch_margin = float(pref_get(prefs, "edge_lock_switch_margin", 0.08))

        last_applied = state.get('last_applied') or []
        if len(last_applied) != len(bm.verts):
            self._states[key] = self._make_state(obj, bm)
            return False

        try:
            selected_indices = set(sig[3]) if sig and len(sig) >= 4 else set()
        except Exception:
            selected_indices = set()
        if not allow_unselected and not selected_indices:
            self._commit_if_idle(state)
            return False

        changed_indices = []
        eps_sq = _SVS_CONSTRAINT_EPS * _SVS_CONSTRAINT_EPS
        if allow_unselected:
            iterable = range(len(bm.verts))
        else:
            iterable = selected_indices
        for vi in iterable:
            try:
                if vi < 0 or vi >= len(bm.verts):
                    continue
                v = bm.verts[vi]
                if (v.co - last_applied[vi]).length_squared > eps_sq:
                    changed_indices.append(vi)
            except Exception:
                continue

        if not changed_indices:
            self._commit_if_idle(state)
            return False

        if state.get('anchor_coords') is None:
            state['anchor_coords'] = [co.copy() for co in last_applied]
            state['locked_edges'] = {}
        anchor_coords = state.get('anchor_coords') or last_applied
        locked_edges = state.setdefault('locked_edges', {})
        state['raw_active'] = True
        state['idle_ticks'] = 0

        moved = False
        for vi in changed_indices:
            try:
                v = bm.verts[vi]
                projected, locked_neighbor = _svs_project_to_slide_edge(
                    vi,
                    v.co.copy(),
                    anchor_coords,
                    bm,
                    behavior=behavior,
                    locked_neighbor=locked_edges.get(vi),
                    lock_enabled=edge_lock_enabled,
                    switch_margin=edge_lock_switch_margin,
                )
                if locked_neighbor is None:
                    locked_edges.pop(vi, None)
                else:
                    locked_edges[vi] = int(locked_neighbor)
                if (v.co - projected).length_squared > (_SVS_CONSTRAINT_EPS * _SVS_CONSTRAINT_EPS):
                    v.co = projected
                    moved = True
                last_applied[vi] = projected.copy()
            except Exception:
                continue

        if moved:
            try:
                bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
            except Exception:
                pass
        return moved

    def _tick(self, context):
        if not _svs_scene_enabled(context):
            return False
        if external_topology_change_active():
            # Another operator owns the destructive edit-BMesh transaction.
            # Keep this monitor alive but do not touch BMesh/RNA until released.
            return True
        if context is None or getattr(context, 'mode', '') != 'EDIT_MESH':
            # Leaving Edit Mesh mode pauses the monitor only.  The scene flag is the
            # user's persistent toggle state and must stay ON until the user toggles
            # mesh.smart_vert_slide again.
            return False
        objects = _svs_get_edit_mesh_objects(context)
        if not objects:
            # Object/selection transitions can temporarily expose no editable mesh.
            # Do not convert that transient state into an OFF command.
            return False

        if bool(globals().get('_SVS_EXTERNAL_REBASE_PENDING', False)):
            if _svs_consume_pending_external_rebase(self, context):
                # Do not compare coordinates in the same tick as a topology
                # rebase; the newly built state is the fresh transform baseline.
                return True
            # A transient context/cache state can delay rebasing.  Waiting is
            # safer than processing stale topology state.
            return True

        live_keys = set()
        any_moved = False
        self._request_stop = False
        for obj in objects:
            key = self._state_key(obj)
            live_keys.add(key)
            if self._tick_object(context, obj):
                any_moved = True

        for key in list(self._states.keys()):
            if key not in live_keys:
                self._states.pop(key, None)

        if self._request_stop:
            # Safety requests rebuild/finish the current monitor pass, but they do
            # not disable the user's toggle state.  A watchdog restarts monitoring
            # when the edit context is stable again.
            self._request_stop = False
            return False

        if any_moved:
            try:
                for area in getattr(context.screen, 'areas', ()): 
                    if area.type == 'VIEW_3D':
                        area.tag_redraw()
            except Exception:
                pass
        return True

    def invoke(self, context, event):
        global _SVS_CONSTRAINT_MONITOR_RUNNING, _SVS_ACTIVE_CONSTRAINT_MONITOR
        if _SVS_CONSTRAINT_MONITOR_RUNNING:
            if _SVS_ACTIVE_CONSTRAINT_MONITOR is not None:
                return {'CANCELLED'}
            # Older builds did not keep a live instance pointer.  Treat that as
            # stale state so the watchdog can arm a fresh monitor.
            _SVS_CONSTRAINT_MONITOR_RUNNING = False
        if not _svs_scene_enabled(context):
            return {'CANCELLED'}
        self._reset_state()
        try:
            self._timer = context.window_manager.event_timer_add(_SVS_CONSTRAINT_TIMER_INTERVAL, window=context.window)
            context.window_manager.modal_handler_add(self)
            _SVS_ACTIVE_CONSTRAINT_MONITOR = self
            _SVS_CONSTRAINT_MONITOR_RUNNING = True
            if external_topology_change_active():
                globals()['_SVS_EXTERNAL_REBASE_PENDING'] = True
            else:
                self._rebase_current_edit_context(context)
            return {'RUNNING_MODAL'}
        except Exception:
            _SVS_ACTIVE_CONSTRAINT_MONITOR = None
            _SVS_CONSTRAINT_MONITOR_RUNNING = False
            return {'CANCELLED'}

    def modal(self, context, event):
        global _SVS_CONSTRAINT_MONITOR_RUNNING
        if not _svs_scene_enabled(context):
            return self._finish(context)

        if external_topology_change_active():
            return {'PASS_THROUGH'}

        # Consume the topology rebase before any new transform/navigation event
        # can be interpreted against the old vertex array.  This preserves the
        # immediate post-Mesh-Connect Vertex Slide behavior without re-entering
        # BMesh during Mesh Connect's operator finalization.
        if bool(globals().get('_SVS_EXTERNAL_REBASE_PENDING', False)):
            _svs_consume_pending_external_rebase(self, context)

        self._mark_view_navigation_event(event)

        # Normal Blender transform operators with release_confirm=True finalize on
        # mouse release.  Defer the rebase to the following timer pass so Blender
        # writes final coordinates first, then make that point the next slide
        # baseline without requiring selection/deselection.
        try:
            if event.value == 'RELEASE' and event.type in {'LEFTMOUSE', 'MIDDLEMOUSE', 'RIGHTMOUSE'}:
                self._release_commit_pending = True
        except Exception:
            pass
        try:
            if event.value == 'PRESS' and event.type in {'RET', 'NUMPAD_ENTER'}:
                self._release_commit_pending = True
        except Exception:
            pass

        if event.type == 'TIMER':
            if self._view_navigation_suspended():
                return {'PASS_THROUGH'}
            if not self._tick(context):
                return self._finish(context)
            if getattr(self, '_release_commit_pending', False):
                self._commit_all_active(context)
                self._release_commit_pending = False
        return {'PASS_THROUGH'}

    def _finish(self, context):
        global _SVS_CONSTRAINT_MONITOR_RUNNING, _SVS_ACTIVE_CONSTRAINT_MONITOR
        try:
            if self._timer is not None:
                context.window_manager.event_timer_remove(self._timer)
        except Exception:
            pass
        self._timer = None
        self._states = {}
        if _SVS_ACTIVE_CONSTRAINT_MONITOR is self:
            _SVS_ACTIVE_CONSTRAINT_MONITOR = None
        _SVS_CONSTRAINT_MONITOR_RUNNING = False
        return {'CANCELLED'}


def _svs_constraint_timer_callback():
    global _SVS_CONSTRAINT_MONITOR_RUNNING, _SVS_CONSTRAINT_TIMER_OBJECT
    context = getattr(bpy, 'context', None)
    try:
        if context is None or not _svs_scene_enabled(context):
            _SVS_CONSTRAINT_MONITOR_RUNNING = False
            _SVS_CONSTRAINT_TIMER_OBJECT = None
            return None
        monitor = _SVS_CONSTRAINT_TIMER_OBJECT
        if monitor is None:
            try:
                monitor = MESH_OT_smart_vert_slide_constraint_monitor()
            except Exception:
                monitor = object.__new__(MESH_OT_smart_vert_slide_constraint_monitor)
            try:
                monitor._reset_state()
            except Exception:
                pass
            _SVS_CONSTRAINT_TIMER_OBJECT = monitor
        try:
            if not monitor._tick(context):
                _SVS_CONSTRAINT_MONITOR_RUNNING = False
                _SVS_CONSTRAINT_TIMER_OBJECT = None
                return None
        except Exception:
            # Do not propagate timer errors into Blender's event loop.  If the
            # edit context disappears, stop this monitor pass cleanly but preserve
            # the user's ON/OFF toggle state.
            _SVS_CONSTRAINT_MONITOR_RUNNING = False
            _SVS_CONSTRAINT_TIMER_OBJECT = None
            try:
                if _svs_scene_enabled(context):
                    _svs_register_toggle_watchdog()
            except Exception:
                pass
            return None
        return float(_SVS_CONSTRAINT_TIMER_INTERVAL)
    except Exception:
        _SVS_CONSTRAINT_MONITOR_RUNNING = False
        _SVS_CONSTRAINT_TIMER_OBJECT = None
        return None


def _svs_toggle_watchdog_callback():
    """Keep an enabled Vertex Slide toggle armed across mode/selection changes."""
    global _SVS_TOGGLE_WATCHDOG_REGISTERED
    context = getattr(bpy, 'context', None)
    try:
        if context is None or not _svs_scene_enabled(context):
            _SVS_TOGGLE_WATCHDOG_REGISTERED = False
            return None
        _svs_tag_statusbar_redraw(context)
        if getattr(context, 'mode', '') == 'EDIT_MESH' and not bool(getattr(bpy.app, 'background', False)):
            try:
                if not _SVS_CONSTRAINT_MONITOR_RUNNING:
                    _svs_start_timer_monitor(context)
            except Exception:
                pass
        return float(_SVS_TOGGLE_WATCHDOG_INTERVAL)
    except Exception:
        # Keep polling while the scene flag is still ON; Blender can transiently
        # invalidate context/RNA during mode switches and selection operations.
        try:
            if context is not None and _svs_scene_enabled(context):
                return float(_SVS_TOGGLE_WATCHDOG_INTERVAL)
        except Exception:
            pass
        _SVS_TOGGLE_WATCHDOG_REGISTERED = False
        return None


def _svs_register_toggle_watchdog():
    global _SVS_TOGGLE_WATCHDOG_REGISTERED
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is None:
            _SVS_TOGGLE_WATCHDOG_REGISTERED = False
            return False
        if hasattr(timers, 'is_registered') and timers.is_registered(_svs_toggle_watchdog_callback):
            _SVS_TOGGLE_WATCHDOG_REGISTERED = True
            return True
        timers.register(_svs_toggle_watchdog_callback, first_interval=float(_SVS_TOGGLE_WATCHDOG_INTERVAL), persistent=False)
        _SVS_TOGGLE_WATCHDOG_REGISTERED = True
        return True
    except Exception:
        _SVS_TOGGLE_WATCHDOG_REGISTERED = False
        return False


def _svs_unregister_toggle_watchdog():
    global _SVS_TOGGLE_WATCHDOG_REGISTERED
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_svs_toggle_watchdog_callback):
            timers.unregister(_svs_toggle_watchdog_callback)
    except Exception:
        pass
    _SVS_TOGGLE_WATCHDOG_REGISTERED = False


def _svs_start_timer_monitor(context):
    global _SVS_CONSTRAINT_MONITOR_RUNNING, _SVS_CONSTRAINT_TIMER_OBJECT
    try:
        if bool(getattr(bpy.app, 'background', False)):
            return False
        if context is None or getattr(context, 'mode', '') != 'EDIT_MESH':
            return False
        if _SVS_CONSTRAINT_MONITOR_RUNNING:
            return True
        _SVS_CONSTRAINT_TIMER_OBJECT = None
        # Use Blender's window-modal timer instead of bpy.app.timers.  The app
        # timer can fire while Blender is still finalizing unrelated mesh
        # operators, which matches the access-violation pattern seen after
        # select/deselect operations.
        try:
            result = bpy.ops.mesh.smart_vert_slide_constraint_monitor('INVOKE_DEFAULT')
            if isinstance(result, set) and 'RUNNING_MODAL' in result:
                return True
        except Exception:
            pass
        _SVS_CONSTRAINT_MONITOR_RUNNING = False
        _SVS_CONSTRAINT_TIMER_OBJECT = None
        return False
    except Exception:
        _SVS_CONSTRAINT_MONITOR_RUNNING = False
        _SVS_CONSTRAINT_TIMER_OBJECT = None
        return False


def _svs_stop_timer_monitor():
    global _SVS_CONSTRAINT_MONITOR_RUNNING, _SVS_CONSTRAINT_TIMER_OBJECT, _SVS_ACTIVE_CONSTRAINT_MONITOR
    global _SVS_EXTERNAL_TOPOLOGY_DEPTH, _SVS_EXTERNAL_REBASE_PENDING
    _SVS_CONSTRAINT_MONITOR_RUNNING = False
    _SVS_CONSTRAINT_TIMER_OBJECT = None
    _SVS_ACTIVE_CONSTRAINT_MONITOR = None
    _SVS_EXTERNAL_TOPOLOGY_DEPTH = 0
    _SVS_EXTERNAL_REBASE_PENDING = False
    _svs_unregister_toggle_watchdog()
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_svs_constraint_timer_callback):
            timers.unregister(_svs_constraint_timer_callback)
    except Exception:
        pass


def execute_vertex_slide_toggle_safe(context=None, invoke=False, reporter=None, event=None):
    del invoke
    context = context or getattr(bpy, 'context', None)
    # Return CANCELLED deliberately after toggling.  Blender 5.1.0 Windows crash
    # logs show wm_operator_reports / WM_operator_last_properties_store
    # dereferencing invalid operator state immediately after this command returns
    # FINISHED.  The toggle itself has no redo properties, so keeping it out of
    # operator history is the safest behavior.
    if context is None:
        return {'CANCELLED'}
    enable = not _svs_scene_enabled(context)
    _svs_set_scene_enabled(context, enable)
    if enable:
        _svs_register_toggle_watchdog()
        if getattr(context, 'mode', '') == 'EDIT_MESH':
            _svs_start_timer_monitor(context)
    else:
        _svs_stop_timer_monitor()
    _svs_append_statusbar_handler_once()
    _svs_set_workspace_toggle_status(context)
    _svs_push_status_notice(context)
    _svs_show_toggle_overlay(context, enable, event=event)
    # Do not send an operator report here.  Blender shows those reports in the
    # bottom status bar with the report/"!" icon, duplicating the custom
    # colored Vertex Slide status notice requested for this tool.
    _svs_tag_statusbar_redraw(context)
    return {'CANCELLED'}


class MESH_OT_smart_vert_slide(bpy.types.Operator):
    _jelararagi_status_managed_v2 = True
    bl_idname = "mesh.smart_vert_slide"
    bl_label = "Toggle Vertex Slide"
    bl_description = "Toggle Vertex Slide Constraint. While ON in Edit Mode, normal Move, Rotate, Scale, and transform gizmo operations are constrained so moved vertices slide along connected mesh edges."
    bl_options = {'UNDO'}
    @classmethod
    def poll(cls, context):
        try:
            from ..utils import feature_enabled
            if not feature_enabled(context, "enable_vertex_slide", True):
                return False
        except Exception:
            pass
        return context is not None

    @classmethod
    def description(cls, context, properties):
        try:
            lang = str(getattr(getattr(context.preferences, 'view', None), 'language', '') or '')
            if lang.startswith('ja'):
                return "頂点スライド制約を切り替えます。ONの間は編集モードの通常移動、回転、スケール、トランスフォームギズモによる頂点操作を、接続エッジ上のスライド移動へ補正します。"
        except Exception:
            pass
        return cls.bl_description

    def invoke(self, context, event):
        # Capture the cursor position so the short ON/OFF overlay appears near
        # the user's action point in the 3D View.
        return execute_vertex_slide_toggle_safe(context, event=event)

    def execute(self, context):
        # Keep this toggle out of Blender's report feed.  The custom STATUSBAR
        # drawing below is the single visible ON/OFF notice.
        return execute_vertex_slide_toggle_safe(context)


def register():
    _svs_publish_front_post_pixel_layer_policy()
    bpy.utils.register_class(MESH_OT_smart_vert_slide_modal)
    bpy.utils.register_class(MESH_OT_smart_vert_slide_constraint_monitor)
    bpy.utils.register_class(MESH_OT_smart_vert_slide)
    for owner_cls in (bpy.types.WindowManager, bpy.types.Scene):
        if not hasattr(owner_cls, "svs_vertex_slide_constraint_enabled"):
            setattr(owner_cls, "svs_vertex_slide_constraint_enabled", bpy.props.BoolProperty(
                name="Vertex Slide Constraint",
                description="Toggle-style Vertex Slide constraint. While enabled in Edit Mode, normal Move, Rotate, Scale, and transform gizmo edits are projected onto connected mesh edges.",
                default=False,
                options={'SKIP_SAVE'},
            ))
    # Do not append load_post callbacks during startup.  The live toggle property
    # is SKIP_SAVE, so it does not persist into reopened files.
    _svs_append_statusbar_handler_once()


def unregister():
    _svs_set_active_modal(None)
    _svs_clear_front_post_pixel_layer_policy()
    _svs_stop_timer_monitor()
    _svs_reset_scene_toggle(getattr(bpy, 'context', None))
    _svs_remove_statusbar_handler()
    _svs_remove_toggle_overlay_handler()
    _svs_remove_load_post_handler()
    for owner_cls in (bpy.types.Scene, bpy.types.WindowManager):
        try:
            if hasattr(owner_cls, "svs_vertex_slide_constraint_enabled"):
                delattr(owner_cls, "svs_vertex_slide_constraint_enabled")
        except Exception:
            pass
    for cls in (MESH_OT_smart_vert_slide, MESH_OT_smart_vert_slide_constraint_monitor, MESH_OT_smart_vert_slide_modal):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
