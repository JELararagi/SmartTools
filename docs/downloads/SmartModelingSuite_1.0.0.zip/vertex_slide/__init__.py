# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

import bpy

bl_info = {
    "name": "Vertex Slide",
    "author": "JELararagi",
    "version": (1, 2, 2),
    "blender": (5, 0, 0),
    "location": "View3D > Edit Mode (assign in Preferences > Keymap)",
    "description": "Enhanced Vertex Slide with Multi-Object Edit, Proportional, HUD, Loop/Ring priority",
    "category": "Mesh",
}

from . import preferences as _prefs
from . import ui as _ui
from . import operators as _ops


def _remove_legacy_addon_keymaps():
    """Remove any legacy addon keymaps created by older versions (e.g. Shift+V auto register)."""
    try:
        wm = bpy.context.window_manager
        kc = wm.keyconfigs.addon
        if not kc:
            return
        idname = _ops.MESH_OT_smart_vert_slide.bl_idname
        for km in list(kc.keymaps):
            try:
                for kmi in list(km.keymap_items):
                    if getattr(kmi, "idname", "") == idname:
                        try:
                            km.keymap_items.remove(kmi)
                        except Exception:
                            pass
            except Exception:
                pass
    except Exception:
        pass


def execute_vertex_slide_toggle_safe(context=None, invoke=False):
    return _ops.execute_vertex_slide_toggle_safe(context, invoke=invoke)


def register():
    _prefs.register()
    _ops.register()
    _ui.register()



def unregister():
    _ui.unregister()
    _ops.unregister()
    _prefs.unregister()
