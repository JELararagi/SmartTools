# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

import json
import re
from contextlib import AbstractContextManager
from pathlib import Path
from typing import Any, Callable

import bpy

_SUITE_KEY = ''
_SUITE_LABEL = ''
_CATEGORY = ''
_OPERATOR_ID = ''
_REGISTERED_CLASSES: list[type] = []
_FEATURES: dict[str, dict[str, dict[str, Any]]] = {}
_STATE_CACHE: dict[str, dict[str, bool]] | None = None
_CAPTURE_STACK: list['_RuntimeCapture'] = []

_KIND_ORDER = ('handlers', 'timers', 'msgbus', 'keymaps', 'draw_handlers')
_KIND_INFO = {
    'handlers': {
        'label_en': 'Application Handlers',
        'label_ja': 'アプリケーションハンドラー',
        'description_en': 'Enables handler functions that Blender runs automatically on file loading, saving, frame changes, dependency-graph updates, undo, redo, or rendering events. Use this only when this feature must react in the background. The setting is saved immediately and remains after Blender restarts and scene changes.',
        'description_ja': 'ファイル読込・保存、フレーム変更、依存グラフ更新、Undo / Redo、レンダー関連イベントなどで Blender が自動実行するハンドラーを有効化します。この機能をバックグラウンドで自動反応させたい場合だけ有効にしてください。設定は即時保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    },
    'timers': {
        'label_en': 'Background Timers',
        'label_ja': 'バックグラウンドタイマー',
        'description_en': 'Enables timer callbacks that run after a delay or repeatedly without pressing a button. Use this only when this feature must keep checking or updating data automatically. The setting is saved immediately and remains after Blender restarts and scene changes.',
        'description_ja': 'ボタン操作なしで、一定時間後または一定間隔で実行されるタイマー処理を有効化します。この機能で自動チェックや自動更新が必要な場合だけ有効にしてください。設定は即時保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    },
    'msgbus': {
        'label_en': 'RNA Message Bus Watchers',
        'label_ja': 'RNAメッセージバス監視',
        'description_en': 'Enables msgbus subscriptions that watch Blender data and run callbacks automatically when watched properties change. Use this only when this feature must monitor Blender data in real time. The setting is saved immediately and remains after Blender restarts and scene changes.',
        'description_ja': 'Blender データの変更を監視し、監視対象プロパティが変わった時に自動でコールバックを実行する msgbus 購読を有効化します。この機能でリアルタイム監視が必要な場合だけ有効にしてください。設定は即時保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    },
    'keymaps': {
        'label_en': 'Manual Hotkey IDs',
        'label_ja': '手動ホットキーID',
        'description_en': 'Smart Modeling Suite does not create persistent Preferences > Keymap entries automatically. Use the operator IDs shown at the bottom of each tool section and bind them manually when needed.',
        'description_ja': 'Smart Modeling Suite はプリファレンス > キーマップへ永続ショートカットを自動作成しません。必要な場合は各ツールセクション最下部に表示される登録IDを使って手動登録してください。',
    },
    'draw_handlers': {
        'label_en': 'Viewport / Editor Draw',
        'label_ja': 'ビューポート / エディター描画',
        'description_en': 'Enables draw handlers that keep drawing overlays or helper graphics in the viewport or editors. Use this only when this feature must show live guides or overlays automatically. The setting is saved immediately and remains after Blender restarts and scene changes.',
        'description_ja': 'ビューポートや各エディターにオーバーレイ・補助表示を描き続ける描画ハンドラーを有効化します。この機能のライブガイドやオーバーレイ表示が必要な場合だけ有効にしてください。設定は即時保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    },
}

_SPACE_CLASS_NAMES = (
    'SpaceView3D', 'SpaceImageEditor', 'SpaceNodeEditor', 'SpaceSequenceEditor',
    'SpaceClipEditor', 'SpaceDopeSheetEditor', 'SpaceGraphEditor', 'SpaceNLA',
    'SpaceTextEditor', 'SpaceConsole', 'SpaceInfo', 'SpaceProperties',
    'SpaceFileBrowser', 'SpaceSpreadsheet', 'SpaceOutliner', 'SpacePreferences',
)

_KNOWN_HANDLER_LISTS = (
    'animation_playback_pre', 'animation_playback_post',
    'blend_import_pre', 'blend_import_post',
    'composite_pre', 'composite_post', 'composite_cancel',
    'depsgraph_update_pre', 'depsgraph_update_post',
    'exit_pre', 'quit_pre',
    'extension_repos_update_pre', 'extension_repos_update_post',
    'frame_change_pre', 'frame_change_post',
    'load_factory_preferences_post', 'load_factory_startup_post',
    'load_pre', 'load_post',
    'object_bake_pre', 'object_bake_complete', 'object_bake_cancel',
    'redo_pre', 'redo_post',
    'render_init', 'render_pre', 'render_post', 'render_write',
    'render_complete', 'render_cancel', 'render_stats',
    'save_pre', 'save_post', 'save_post_fail',
    'translation_update_post', 'undo_pre', 'undo_post',
    'version_update', 'xr_session_start_pre',
)


def _clean_identifier(value: str, fallback: str = 'smart_tools') -> str:
    text = str(value or '').strip().split('.')[-1]
    text = re.sub(r'[^0-9A-Za-z_]+', '_', text)
    text = re.sub(r'_+', '_', text).strip('_').lower()
    return text or fallback


def _title_from_key(value: str) -> str:
    text = str(value or '').strip().split('.')[-1]
    text = text.replace('_suite', '').replace('_', ' ').strip()
    if not text:
        return 'Smart Tools'
    return ' '.join(part[:1].upper() + part[1:] for part in text.split())


def _infer_suite_key() -> str:
    package = str(__package__ or '').strip('.')
    if package:
        parts = [p for p in package.split('.') if p]
        if 'user_default' in parts:
            idx = parts.index('user_default')
            if idx + 1 < len(parts):
                return _clean_identifier(parts[idx + 1])
        if parts:
            return _clean_identifier(parts[0])
    return 'smart_tools'


def _infer_category(suite_key: str) -> str:
    title = _title_from_key(suite_key)
    return title if title.lower().startswith('smart ') else f'Smart {title}'


def configure(*, suite_key: str | None = None, suite_label: str | None = None, category: str | None = None) -> None:
    global _SUITE_KEY, _SUITE_LABEL, _CATEGORY, _OPERATOR_ID
    if not _SUITE_KEY:
        _SUITE_KEY = _clean_identifier(suite_key or _infer_suite_key())
    if suite_key:
        _SUITE_KEY = _clean_identifier(suite_key)
    if suite_label:
        _SUITE_LABEL = str(suite_label).strip()
    if not _SUITE_LABEL:
        _SUITE_LABEL = _title_from_key(_SUITE_KEY)
    if category:
        _CATEGORY = str(category).strip()
    if not _CATEGORY:
        _CATEGORY = _infer_category(_SUITE_KEY)
    _OPERATOR_ID = f'{_SUITE_KEY}.toggle_persistent_feature'


def _is_ja(context=None) -> bool:
    try:
        prefs = getattr(getattr(context, 'preferences', None), 'view', None) if context is not None else getattr(getattr(bpy.context, 'preferences', None), 'view', None)
        lang = str(getattr(prefs, 'language', '') or '').lower()
    except Exception:
        lang = ''
    try:
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '').lower()
    except Exception:
        locale = ''
    return lang.startswith('ja') or locale.startswith('ja') or 'japanese' in lang


def _t(context, en: str, ja: str) -> str:
    return str(ja if _is_ja(context) else en)


def _static_t(en: str, ja: str) -> str:
    return str(ja if _is_ja(None) else en)


def _settings_path() -> Path | None:
    configure()
    try:
        from .common import settings_path
        return Path(settings_path())
    except Exception:
        return None


def _legacy_settings_path() -> Path | None:
    filename = f'{_SUITE_KEY}_persistent_feature_toggles.json'
    package_seed = Path(__file__).resolve().parent / 'settings' / filename
    if package_seed.is_file():
        return package_seed
    try:
        from .utils import default_user_filepath
        return Path(default_user_filepath(filename, category='settings', create=False))
    except Exception:
        return None


def _load_state() -> dict[str, dict[str, bool]]:
    global _STATE_CACHE
    if _STATE_CACHE is not None:
        return _STATE_CACHE
    data: dict[str, dict[str, bool]] = {}
    path = _settings_path()
    if path is not None and path.exists():
        try:
            raw = json.loads(path.read_text(encoding='utf-8'))
            if isinstance(raw, dict):
                candidate = raw.get('feature_toggles') if isinstance(raw.get('feature_toggles'), dict) else raw
                if isinstance(candidate, dict):
                    for alias, values in candidate.items():
                        if isinstance(values, dict):
                            data[str(alias)] = {str(k): v for k, v in values.items() if isinstance(v, bool)}
        except Exception:
            data = {}
    if not data:
        legacy = _legacy_settings_path()
        if legacy is not None and legacy.exists():
            try:
                raw = json.loads(legacy.read_text(encoding='utf-8'))
                if isinstance(raw, dict):
                    for alias, values in raw.items():
                        if isinstance(values, dict):
                            data[str(alias)] = {str(k): v for k, v in values.items() if isinstance(v, bool)}
            except Exception:
                pass
    _STATE_CACHE = data
    return _STATE_CACHE


def persistent_state_snapshot() -> dict[str, dict[str, bool]]:
    return {
        str(alias): {str(key): value for key, value in values.items() if isinstance(value, bool)}
        for alias, values in _load_state().items()
        if isinstance(values, dict)
    }


def _save_state() -> bool:
    """Delegate every write to the suite's canonical gated atomic writer."""
    try:
        from . import common
        if not common.settings_write_allowed() or not common.n_panel_state_save_enabled(getattr(bpy, 'context', None)):
            return False
        return bool(common.save_persistent_settings(getattr(bpy, 'context', None), force=False))
    except Exception:
        return False


def is_feature_enabled(alias: str, feature_key: str) -> bool:
    alias = str(alias or '').strip()
    feature_key = str(feature_key or '').strip()
    return bool(_load_state().get(alias, {}).get(feature_key, False))


def set_feature_enabled(alias: str, feature_key: str, enabled: bool) -> bool:
    alias = str(alias or '').strip()
    feature_key = str(feature_key or '').strip()
    if not alias or not feature_key:
        return False
    _load_state().setdefault(alias, {})[feature_key] = bool(enabled)
    _save_state()
    feature = _FEATURES.get(alias, {}).get(feature_key)
    if feature is not None:
        _set_feature_active(feature, bool(enabled))
    _tag_redraw()
    return True


def set_feature_enabled_runtime(alias: str, feature_key: str, enabled: bool) -> bool:
    """Set a runtime feature state without disk writes or redraw scheduling.

    Used by the suite startup synchronization path.  The N-panel settings JSON is
    the persistent source of truth, so repeatedly saving feature_toggle state for
    every handler/timer/draw kind during Blender startup only adds idle overhead.
    """
    alias = str(alias or '').strip()
    feature_key = str(feature_key or '').strip()
    if not alias or not feature_key:
        return False
    _load_state().setdefault(alias, {})[feature_key] = bool(enabled)
    feature = _FEATURES.get(alias, {}).get(feature_key)
    if feature is not None:
        _set_feature_active(feature, bool(enabled))
    return True


def _feature_record(alias: str, tool_label: str, feature_key: str) -> dict[str, Any]:
    alias = str(alias or '').strip()
    tool_label = str(tool_label or alias or 'Integrated Tool').strip()
    feature_key = str(feature_key or '').strip()
    info = _KIND_INFO.get(feature_key, {})
    features = _FEATURES.setdefault(alias, {})
    feature = features.get(feature_key)
    if feature is None:
        feature = {
            'alias': alias,
            'tool_label': tool_label,
            'key': feature_key,
            'label_en': str(info.get('label_en') or feature_key),
            'label_ja': str(info.get('label_ja') or feature_key),
            'description_en': str(info.get('description_en') or ''),
            'description_ja': str(info.get('description_ja') or ''),
            'actions': [],
        }
        features[feature_key] = feature
    else:
        feature['tool_label'] = tool_label
    return feature


def _add_action(alias: str, tool_label: str, feature_key: str, action: dict[str, Any]) -> None:
    feature = _feature_record(alias, tool_label, feature_key)
    feature.setdefault('actions', []).append(action)


def feature_entries(alias: str | None = None) -> list[dict[str, Any]]:
    aliases = [str(alias).strip()] if alias else sorted(_FEATURES.keys())
    out: list[dict[str, Any]] = []
    for alias_key in aliases:
        feature_map = _FEATURES.get(alias_key, {})
        for key in _KIND_ORDER:
            feature = feature_map.get(key)
            if not feature or not feature.get('actions'):
                continue
            item = dict(feature)
            item['enabled'] = is_feature_enabled(alias_key, key)
            item['action_count'] = len(feature.get('actions') or [])
            out.append(item)
    return out


def all_feature_aliases() -> tuple[str, ...]:
    return tuple(sorted(alias for alias, items in _FEATURES.items() if any((f.get('actions') for f in items.values()))))


def _snapshot_handlers() -> dict[str, dict[str, Any]]:
    """Capture exact callbacks from a fixed set of Blender handler lists.

    This is a bounded registration transaction snapshot, not a process-wide
    attribute scan.  The list objects and callbacks are retained as exact
    identity receipts for rollback and feature deactivation.
    """
    result: dict[str, dict[str, Any]] = {}
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    if handlers is None:
        return result
    for name in _KNOWN_HANDLER_LISTS:
        try:
            seq = getattr(handlers, name, None)
        except Exception:
            seq = None
        if not isinstance(seq, list):
            continue
        result[name] = {'list': seq, 'callbacks': tuple(seq)}
    return result


def _collect_new_handlers(before: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    actions: list[dict[str, Any]] = []
    for name, receipt in tuple(before.items()):
        seq = receipt.get('list') if isinstance(receipt, dict) else None
        if not isinstance(seq, list):
            continue
        baseline = tuple(receipt.get('callbacks', ()) or ())
        baseline_counts: list[list[Any]] = []
        for callback in baseline:
            for item in baseline_counts:
                if item[0] is callback:
                    item[1] += 1
                    break
            else:
                baseline_counts.append([callback, 1])
        seen_counts: list[list[Any]] = []
        for callback in tuple(seq):
            occurrence = 1
            for item in seen_counts:
                if item[0] is callback:
                    item[1] += 1
                    occurrence = item[1]
                    break
            else:
                seen_counts.append([callback, 1])
            baseline_count = 0
            for item in baseline_counts:
                if item[0] is callback:
                    baseline_count = item[1]
                    break
            if occurrence <= baseline_count:
                continue
            actions.append({
                'kind': 'handlers',
                'list_name': name,
                'handler_list': seq,
                'fn': callback,
                'active': True,
            })
    return actions


def _remove_exact_identity(sequence, target) -> bool:
    try:
        for index in range(len(sequence) - 1, -1, -1):
            if sequence[index] is target:
                sequence.pop(index)
                return True
    except Exception:
        pass
    return False


def _contains_exact_identity(sequence, target) -> bool:
    try:
        return any(item is target for item in tuple(sequence))
    except Exception:
        return False


def _snapshot_keymaps() -> set[int]:
    # Do not scan KeyMapItems during extension install/reinstall. Several
    # Blender 5.1.0 Windows crash logs enter native operator-property and UI
    # handler paths from keymap inspection. Shortcut items created by tools are
    # left under Blender's normal add-on keyconfig instead of being mirrored here.
    return set()


def _copy_keymap_properties(kmi) -> dict[str, Any]:
    # Blender 5.1.x can crash in native RNA when stale or macro
    # KeyMapItem.properties is resolved during extension reinstall,
    # timer-driven loading, or UI refresh. Never dereference it.
    del kmi
    return {}

def _describe_keymap_item(km, kmi) -> dict[str, Any]:
    # Do not dereference KeyMap / KeyMapItem attributes here. Even basic fields
    # can route through stale RNA during in-place reinstall.
    del km, kmi
    return {'kind': 'keymaps', 'active': False}


def _collect_new_keymaps(before: set[int]) -> list[dict[str, Any]]:
    # Keymap capture is intentionally disabled for install safety. Do not hold
    # live KeyMapItem references or resolve operator properties; both can become
    # stale during an in-place extension update.
    del before
    return []


def _remove_action(action: dict[str, Any]) -> None:
    kind = str(action.get('kind') or '')
    if not bool(action.get('active', False)):
        return
    try:
        if kind == 'handlers':
            seq = action.get('handler_list')
            fn = action.get('fn')
            if isinstance(seq, list):
                _remove_exact_identity(seq, fn)
        elif kind == 'timers':
            timers = getattr(getattr(bpy, 'app', None), 'timers', None)
            fn = action.get('fn')
            if timers is not None and callable(fn):
                try:
                    if hasattr(timers, 'is_registered') and timers.is_registered(fn):
                        timers.unregister(fn)
                except Exception:
                    try:
                        timers.unregister(fn)
                    except Exception:
                        pass
        elif kind == 'msgbus':
            owner = action.get('owner')
            if owner is not None:
                try:
                    bpy.msgbus.clear_by_owner(owner)
                except Exception:
                    pass
        elif kind == 'draw_handlers':
            handle = action.get('handle')
            space_cls = action.get('space_cls')
            region_type = action.get('region_type')
            if handle is not None and space_cls is not None:
                try:
                    remove = action.get('remove_fn') or getattr(space_cls, 'draw_handler_remove', None)
                    if callable(remove):
                        remove(handle, region_type)
                except Exception:
                    pass
                action['handle'] = None
        elif kind == 'keymaps':
            # Do not touch KeyMapItem objects during reinstall/shutdown. Live
            # KMI proxies may be stale and even setting kmi.active can enter
            # native RNA. Native add-on keymaps are left to Blender.
            action['active_km'] = None
            action['active_kmi'] = None
            action.pop('km', None)
            action.pop('kmi', None)
    finally:
        action['active'] = False


def _apply_keymap_action(action: dict[str, Any]) -> None:
    # Manual-only policy: keymap actions are not re-applied by the feature toggle
    # layer, and native tool register() functions must not create persistent
    # Preferences > Keymap shortcuts automatically.
    try:
        action['active'] = False
        action['active_km'] = None
        action['active_kmi'] = None
    except Exception:
        pass


def _apply_action(action: dict[str, Any]) -> None:
    if bool(action.get('active', False)):
        return
    kind = str(action.get('kind') or '')
    try:
        if kind == 'handlers':
            seq = action.get('handler_list')
            fn = action.get('fn')
            if isinstance(seq, list) and callable(fn) and not _contains_exact_identity(seq, fn):
                seq.append(fn)
                action['active'] = True
        elif kind == 'timers':
            timers = getattr(getattr(bpy, 'app', None), 'timers', None)
            fn = action.get('fn')
            if timers is not None and callable(fn):
                register = action.get('register_fn') or timers.register
                try:
                    if hasattr(timers, 'is_registered') and timers.is_registered(fn):
                        action['active'] = True
                        return
                except Exception:
                    pass
                register(fn, *tuple(action.get('args') or ()), **dict(action.get('kwargs') or {}))
                action['active'] = True
        elif kind == 'msgbus':
            subscribe = action.get('subscribe_fn') or getattr(bpy.msgbus, 'subscribe_rna', None)
            if callable(subscribe):
                subscribe(*tuple(action.get('args') or ()), **dict(action.get('kwargs') or {}))
                action['active'] = True
        elif kind == 'draw_handlers':
            space_cls = action.get('space_cls')
            add = action.get('add_fn') or getattr(space_cls, 'draw_handler_add', None)
            if callable(add):
                action['handle'] = add(*tuple(action.get('args') or ()), **dict(action.get('kwargs') or {}))
                action['active'] = True
        elif kind == 'keymaps':
            _apply_keymap_action(action)
    except Exception:
        action['active'] = False


def _set_feature_active(feature: dict[str, Any], enabled: bool) -> None:
    actions = list(feature.get('actions') or [])
    if enabled:
        for action in actions:
            _apply_action(action)
    else:
        for action in reversed(actions):
            _remove_action(action)


def deactivate_alias(alias: str) -> None:
    for feature in list(_FEATURES.get(str(alias or '').strip(), {}).values()):
        _set_feature_active(feature, False)


def clear_alias(alias: str) -> None:
    alias = str(alias or '').strip()
    deactivate_alias(alias)
    _FEATURES.pop(alias, None)


def _current_capture() -> '_RuntimeCapture | None':
    return _CAPTURE_STACK[-1] if _CAPTURE_STACK else None


# Resource ownership is captured only through direct module registration results
# and explicit action records. Blender process-global APIs are never replaced.
class _RuntimeCapture(AbstractContextManager):
    def __init__(self, alias: str, tool_label: str | None = None):
        configure()
        self.alias = str(alias or '').strip()
        self.tool_label = str(tool_label or self.alias or 'Integrated Tool').strip()
        self._before_handlers: dict[str, dict[str, Any]] = {}
        self._before_keymaps: set[int] = set()

    def __enter__(self):
        self._before_handlers = _snapshot_handlers()
        self._before_keymaps = _snapshot_keymaps()
        _CAPTURE_STACK.append(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        try:
            for action in _collect_new_handlers(self._before_handlers):
                self.record_action('handlers', action)
                if not self.kind_enabled('handlers'):
                    _remove_action(action)
            for action in _collect_new_keymaps(self._before_keymaps):
                self.record_action('keymaps', action)
                if not self.kind_enabled('keymaps'):
                    _remove_action(action)
        finally:
            if self in _CAPTURE_STACK:
                _CAPTURE_STACK.remove(self)
            _tag_redraw()
        return False

    def kind_enabled(self, feature_key: str) -> bool:
        return is_feature_enabled(self.alias, feature_key)

    def record_action(self, feature_key: str, action: dict[str, Any]) -> None:
        if self.alias and feature_key:
            _add_action(self.alias, self.tool_label, feature_key, action)


def capture_runtime(alias: str, tool_label: str | None = None) -> _RuntimeCapture:
    return _RuntimeCapture(alias, tool_label)


def capture_call(alias: str, tool_label: str | None, callback: Callable[[], Any]) -> Any:
    with capture_runtime(alias, tool_label):
        return callback()


def _tag_redraw() -> None:
    return None

def _operator_description(context, properties) -> str:
    alias = str(getattr(properties, 'alias', '') or '')
    feature_key = str(getattr(properties, 'feature_key', '') or '')
    feature = _FEATURES.get(alias, {}).get(feature_key)
    if feature:
        label = _t(context, feature.get('label_en', ''), feature.get('label_ja', ''))
        desc = _t(context, feature.get('description_en', ''), feature.get('description_ja', ''))
        state = _t(context, 'Click to switch this feature between enabled and disabled.', 'クリックすると、この機能の有効 / 無効を切り替えます。')
        return f'{label}: {desc} {state}'
    return _t(context, 'Toggle an always-on Smart Tools feature. The setting is saved immediately.', 'Smart Tools の常時機能を切り替えます。設定は即時保存されます。')



def _feature_toggle_operator_exists(idname: str) -> bool:
    # Do not resolve bpy.ops.* here.  Blender creates lightweight callables for
    # missing operators, so a namespace lookup can report a false positive and
    # prevent the real toggle operator from being registered.
    try:
        idname = str(idname or '').strip()
        if not idname:
            return False
        base = getattr(bpy.types, 'Operator', None)
        getter = getattr(base, 'bl_rna_get_subclass_py', None) if base is not None else None
        if not callable(getter):
            return False
        candidates = [idname]
        if '.' in idname:
            namespace, opname = idname.split('.', 1)
            suffix = ''.join(ch if ch.isalnum() else '_' for ch in opname).strip('_')
            if namespace and suffix:
                candidates.append(f'{namespace.upper()}_OT_{suffix}')
        for candidate in tuple(dict.fromkeys(candidates)):
            if getter(candidate, None) is not None:
                return True
    except Exception:
        pass
    return False

def register_ui(*, suite_key: str | None = None, suite_label: str | None = None, category: str | None = None) -> None:
    configure(suite_key=suite_key, suite_label=suite_label, category=category)
    if _REGISTERED_CLASSES:
        return
    operator_id = _OPERATOR_ID

    class SMARTTOOLS_OT_toggle_persistent_feature(bpy.types.Operator):
        bl_idname = operator_id
        bl_label = 'Toggle Feature'
        bl_options = {'UNDO'}
        bl_description = 'Switch an always-on feature on or off and save the setting immediately.'

        alias: bpy.props.StringProperty(default='')
        feature_key: bpy.props.StringProperty(default='')
        enabled: bpy.props.BoolProperty(default=True)

        @classmethod
        def description(cls, context, properties):
            return _operator_description(context, properties)

        def execute(self, context):
            alias = str(getattr(self, 'alias', '') or '')
            feature_key = str(getattr(self, 'feature_key', '') or '')
            desired = bool(getattr(self, 'enabled', True))
            if not set_feature_enabled(alias, feature_key, desired):
                return {'CANCELLED'}
            return {'FINISHED'}

    SMARTTOOLS_OT_toggle_persistent_feature.__name__ = f"SMARTTOOLS_OT_{_SUITE_KEY.upper()}_TOGGLE_PERSISTENT_FEATURE"
    SMARTTOOLS_OT_toggle_persistent_feature.__qualname__ = SMARTTOOLS_OT_toggle_persistent_feature.__name__
    SMARTTOOLS_OT_toggle_persistent_feature.__module__ = __name__
    try:
        existing = getattr(bpy.types, SMARTTOOLS_OT_toggle_persistent_feature.__name__, None)
        if isinstance(existing, type) and existing is not SMARTTOOLS_OT_toggle_persistent_feature:
            for attr in ('poll', 'execute', 'invoke', 'description'):
                if attr in getattr(SMARTTOOLS_OT_toggle_persistent_feature, '__dict__', {}):
                    try:
                        setattr(existing, attr, getattr(SMARTTOOLS_OT_toggle_persistent_feature, attr))
                    except Exception:
                        pass
            _REGISTERED_CLASSES.append(existing)
            return
    except Exception:
        pass
    if _feature_toggle_operator_exists(_OPERATOR_ID):
        _REGISTERED_CLASSES.append(SMARTTOOLS_OT_toggle_persistent_feature)
        return
    try:
        bpy.utils.register_class(SMARTTOOLS_OT_toggle_persistent_feature)
        _REGISTERED_CLASSES.append(SMARTTOOLS_OT_toggle_persistent_feature)
    except RuntimeError:
        _REGISTERED_CLASSES.append(SMARTTOOLS_OT_toggle_persistent_feature)
    except Exception:
        raise


def draw_inline_toggles(layout, context, alias: str, *, compact: bool = True) -> bool:
    """Draw feature toggles using the standardized Smart toolset layout."""
    configure()
    alias = str(alias or '').strip()
    entries = feature_entries(alias)
    if not entries:
        return False
    try:
        col = layout.column(align=True)
        for item in entries:
            enabled = bool(item.get('enabled'))
            feature_key = str(item.get('key') or '')
            label = _t(context, str(item.get('label_en') or feature_key), str(item.get('label_ja') or feature_key))
            row = col.row(align=True)
            row.label(text=label)
            op = row.operator(_OPERATOR_ID, text=_t(context, 'Enabled', '有効'), depress=enabled)
            op.alias = alias
            op.feature_key = feature_key
            try:
                op.enabled = True
            except Exception:
                pass
            op = row.operator(_OPERATOR_ID, text=_t(context, 'Disabled', '無効'), depress=not enabled)
            op.alias = alias
            op.feature_key = feature_key
            try:
                op.enabled = False
            except Exception:
                pass
            if not compact:
                desc = _t(context, str(item.get('description_en') or ''), str(item.get('description_ja') or ''))
                if desc:
                    col.label(text=desc[:240])
        return True
    except Exception:
        return False


def unregister_ui() -> None:
    for cls in reversed(_REGISTERED_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED_CLASSES.clear()


def unregister_all() -> None:
    for alias in list(_FEATURES.keys()):
        deactivate_alias(alias)
    unregister_ui()
    _FEATURES.clear()


def _safe_safe_set_kmi_property_v60(kmi, prop_name, value) -> bool:
    # Fallback-created keymap items are kept basic; touching kmi.properties is
    # unsafe on Blender 5.1.0 during extension reinstall and can crash native RNA
    # before Python can catch anything.
    del kmi, prop_name, value
    return False
