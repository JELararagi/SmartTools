"""Public seam_angle routing."""

from math import radians

import bpy


def run(context, op):
    return "FINISHED" in bpy.ops.uv.suv_auto_seam_advanced(mode="ANGLE", scope=(op.scope or "SELECTED").upper(), **({"angle_threshold": radians(op.angle)} if op.properties.is_property_set("angle") else {}))


def build_handlers(api):
    return {"smart_uv_suite.seam_angle": api.Handler(run, 'Mark mesh edges whose fold angle reaches the threshold in degrees.', '面の折れ角が指定した度数以上の辺にシームを付けます。')}
