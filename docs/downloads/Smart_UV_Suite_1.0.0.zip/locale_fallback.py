# SPDX-License-Identifier: GPL-3.0-or-later
"""Keep bilingual tool text available when Blender changes language."""

from functools import wraps

import bpy

from .locale_fallback_data import JA_EN
from .panel_tools import FILE_BUTTONS
from .text_translation_curated import CURATED_EN_JA


def _catalogs():
    english = {
        (context, source): label
        for source, label in JA_EN.items()
        for context in ("*", "Operator")
    }
    catalogs = dict.fromkeys(
        (language for language in bpy.app.translations.locales
         if language.split("_", 1)[0] != "ja"), english
    )
    catalogs["en_US"] = english
    catalogs["ja_JP"] = {
        ("Operator", source): label for source, label in CURATED_EN_JA.items()
    }
    for _, english_label, japanese_label in FILE_BUTTONS:
        catalogs["ja_JP"]["*", english_label] = japanese_label
        catalogs["ja_JP"]["Operator", english_label] = japanese_label
    return catalogs


def _remove_catalog():
    try:
        bpy.app.translations.unregister(__name__)
    except ValueError:
        pass


def wrap(register, unregister):
    @wraps(register)
    def activate(*args, **kwargs):
        result = register(*args, **kwargs)
        _remove_catalog()
        bpy.app.translations.register(__name__, _catalogs())
        return result

    @wraps(unregister)
    def deactivate(*args, **kwargs):
        _remove_catalog()
        return unregister(*args, **kwargs)

    return activate, deactivate

