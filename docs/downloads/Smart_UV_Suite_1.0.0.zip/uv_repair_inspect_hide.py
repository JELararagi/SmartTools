"""Implement the inspect hide public UV operations."""

import bpy


def inspect_hide(context, op):
    return 'FINISHED' in bpy.ops.uv.hide(unselected=op.mode == 'UNSELECTED')


def build_handlers(api):
    return {

        "smart_uv_suite.inspect_hide": api.Handler(inspect_hide, 'Hide selected UVs in the UV editor.', 'UVエディターで選択したUVを非表示にします。'),

    }
