# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""UV map-channel selection helpers for Smart UV Suite."""
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

from typing import Any

import bpy

ACTIVE_IDENTIFIER = 'ACTIVE'
CHANNEL_PREFIX = 'CHANNEL_'
COPY_TARGET_IDENTIFIER = 'TARGET_UNWRAP'
DEFAULT_UV_NAME = 'UVMap'
_ENUM_ITEMS_CACHE: tuple[tuple[str, str, str], ...] = ((
    ACTIVE_IDENTIFIER,
    '現在のアクティブ',
    '現在アクティブなUVマップを展開に使用します。',
),)
_COPY_SOURCE_ITEMS_CACHE: tuple[tuple[str, str, str], ...] = ((
    ACTIVE_IDENTIFIER,
    '現在のアクティブ',
    '現在アクティブなUVマップをコピー元にします。',
),)
_COPY_DESTINATION_ITEMS_CACHE: tuple[tuple[str, str, str], ...] = ((
    COPY_TARGET_IDENTIFIER,
    '展開使用チャンネル',
    '展開使用マップチャンネルで選択中のチャンネルをコピー書き込み先にします。',
),)


def _is_ja(context: Any | None = None) -> bool:
    try:
        lang = str(getattr(getattr(getattr(context, 'preferences', None), 'view', None), 'language', '') or '')
    except Exception:
        lang = ''
    return lang.upper().startswith('JA') or lang in {'', 'DEFAULT'}


def _tx(context: Any | None, en: str, ja: str) -> str:
    return ja if _is_ja(context) else en


def mesh_object_from_context(context: Any):
    """Return the selected/active mesh object used by UV unwrap tools."""
    obj = None
    try:
        obj = getattr(context, 'edit_object', None)
    except Exception:
        obj = None
    if obj is None:
        try:
            obj = getattr(context, 'active_object', None)
        except Exception:
            obj = None
    if obj is not None and getattr(obj, 'type', None) == 'MESH':
        return obj
    try:
        for candidate in getattr(context, 'selected_objects', []) or []:
            if getattr(candidate, 'type', None) == 'MESH':
                return candidate
    except Exception:
        pass
    return None


def uv_layers(obj: Any):
    try:
        data = getattr(obj, 'data', None)
        layers = getattr(data, 'uv_layers', None)
        return layers
    except Exception:
        return None


def _safe_layer_name(layer: Any, fallback: str) -> str:
    try:
        name = str(getattr(layer, 'name', '') or '')
    except Exception:
        name = ''
    return name if name else fallback


def map_channel_enum_items(context: Any) -> tuple[tuple[str, str, str], ...]:
    """Dynamic EnumProperty items for the active object's UV map channels."""
    global _ENUM_ITEMS_CACHE
    obj = mesh_object_from_context(context or bpy.context)
    layers = uv_layers(obj)
    items: list[tuple[str, str, str]] = [(
        ACTIVE_IDENTIFIER,
        _tx(context, 'Active UV Map', '現在のアクティブ'),
        _tx(
            context,
            'Use the UV map that is currently active on the selected mesh object. Use this when you want Smart UV Suite to follow Blender\'s active UV map instead of forcing a numbered channel.',
            '選択中メッシュオブジェクトで現在アクティブなUVマップを展開に使用します。番号指定で固定せず、Blender側のアクティブUVマップに追従させたい場合に使います。',
        ),
    )]
    if obj is None or layers is None:
        items[0] = (
            ACTIVE_IDENTIFIER,
            _tx(context, 'No selected mesh', '選択メッシュなし'),
            _tx(context, 'Select a mesh object to show UV map channels.', 'メッシュオブジェクトを選択するとUVマップチャンネルを表示します。'),
        )
        _ENUM_ITEMS_CACHE = tuple(items)
        return _ENUM_ITEMS_CACHE
    try:
        count = len(layers)
    except Exception:
        count = 0
    if count <= 0:
        items.append((
            CHANNEL_PREFIX + '0',
            _tx(context, '0: New UVMap', '0: 新規UVMap'),
            _tx(context, 'No UV map exists. Smart UV Suite creates UV map index 0 and uses it for unwrap.', 'UVマップが無い場合、インデックス0のUVマップを作成して展開に使用します。'),
        ))
    else:
        try:
            active_index = int(getattr(layers, 'active_index', 0) or 0)
        except Exception:
            active_index = 0
        for index, layer in enumerate(layers):
            name = _safe_layer_name(layer, f'UVMap.{index + 1:03d}')
            active_mark = ' ●' if index == active_index else ''
            items.append((
                CHANNEL_PREFIX + str(index),
                f'{index}: {name}{active_mark}',
                _tx(
                    context,
                    f'Use UV map channel index {index} named "{name}" for unwrap. The channel is made active before Smart, Square, Circle, projection, selection-scope, quality, and packing passes run.',
                    f'「{name}」を展開に使用するUVマップチャンネルの実インデックス {index} として使います。スマート、四角、円、投影、選択スコープ、品質最適化、パッキングの実行前にこのチャンネルをアクティブ化します。',
                ),
            ))
    _ENUM_ITEMS_CACHE = tuple(items)
    return _ENUM_ITEMS_CACHE


def _parse_channel_index(value: Any) -> int | None:
    raw = str(value or ACTIVE_IDENTIFIER).upper()
    if raw.startswith(CHANNEL_PREFIX):
        try:
            return max(0, int(raw[len(CHANNEL_PREFIX):]))
        except Exception:
            return None
    if raw.startswith('INDEX_'):
        try:
            return max(0, int(raw.split('_', 1)[1]))
        except Exception:
            return None
    try:
        if raw.isdigit():
            return max(0, int(raw))
    except Exception:
        pass
    return None


def _ensure_layer_exists(layers: Any) -> bool:
    try:
        if len(layers) > 0:
            return True
    except Exception:
        return False
    try:
        layers.new(name=DEFAULT_UV_NAME)
        return True
    except Exception:
        return False


def apply_channel_to_object(obj: Any, channel_value: Any = ACTIVE_IDENTIFIER) -> str:
    """Make the requested UV map active on *obj* and return its layer name."""
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return ''
    layers = uv_layers(obj)
    if layers is None:
        return ''
    _ensure_layer_exists(layers)
    try:
        count = len(layers)
    except Exception:
        count = 0
    if count <= 0:
        return ''
    target_index = _parse_channel_index(channel_value)
    if target_index is not None:
        target_index = max(0, min(int(target_index), count - 1))
        try:
            layers.active_index = target_index
        except Exception:
            pass
    try:
        active_layer = getattr(layers, 'active', None)
    except Exception:
        active_layer = None
    if active_layer is None:
        try:
            active_layer = layers[int(getattr(layers, 'active_index', 0) or 0)]
        except Exception:
            active_layer = None
    return _safe_layer_name(active_layer, '') if active_layer is not None else ''


def mesh_objects_for_context(context: Any) -> list[Any]:
    """Return mesh objects that should receive the unwrap-channel activation."""
    ctx = context or bpy.context
    result: list[Any] = []
    seen: set[int] = set()

    def add(obj: Any) -> None:
        try:
            if obj is None or getattr(obj, 'type', None) != 'MESH':
                return
            key = id(obj)
            if key not in seen:
                seen.add(key)
                result.append(obj)
        except Exception:
            pass

    try:
        for obj in getattr(ctx, 'objects_in_mode', []) or []:
            add(obj)
    except Exception:
        pass
    try:
        add(getattr(ctx, 'edit_object', None))
    except Exception:
        pass
    try:
        add(getattr(ctx, 'active_object', None))
    except Exception:
        pass
    try:
        for obj in getattr(ctx, 'selected_objects', []) or []:
            add(obj)
    except Exception:
        pass
    return result


def _needs_edit_mode_refresh_for_channel(targets: list[Any], channel_value: Any) -> bool:
    target_index = _parse_channel_index(channel_value)
    if target_index is None:
        return False
    for target in targets:
        layers = uv_layers(target)
        if layers is None:
            continue
        try:
            count = len(layers)
        except Exception:
            count = 0
        if count <= 0:
            return True
        wanted = max(0, min(int(target_index), count - 1))
        try:
            if int(getattr(layers, 'active_index', 0) or 0) != wanted:
                return True
        except Exception:
            return True
    return False


def _context_is_edit_mesh(context: Any) -> bool:
    try:
        obj = getattr(context, 'edit_object', None) or getattr(context, 'active_object', None)
        return bool(obj is not None and getattr(obj, 'mode', '') == 'EDIT')
    except Exception:
        return False


def ensure_unwrap_map_channel(context: Any, ws: Any = None, obj: Any = None) -> str:
    """Activate the workspace-selected UV map channel before any unwrap route.

    Blender's BMesh edit session keeps its own active UV layer.  If the user
    changes the target channel while already in Edit Mode, setting
    ``mesh.uv_layers.active_index`` alone is not enough for native UV operators.
    For explicit numbered channels this helper briefly refreshes Edit Mode, then
    restores it, so Smart Project, Unwrap, packing and BMesh reads all operate on
    the requested map channel.
    """
    ctx = context or bpy.context
    if ws is None:
        try:
            ws = getattr(getattr(ctx, 'scene', None), 'suv_workspace', None)
        except Exception:
            ws = None
    value = ACTIVE_IDENTIFIER
    if ws is not None:
        try:
            value = str(getattr(ws, 'unwrap_map_channel', ACTIVE_IDENTIFIER) or ACTIVE_IDENTIFIER)
        except Exception:
            value = ACTIVE_IDENTIFIER

    targets = [obj] if obj is not None else mesh_objects_for_context(ctx)
    targets = [target for target in targets if target is not None and getattr(target, 'type', None) == 'MESH']
    was_edit = _context_is_edit_mesh(ctx)
    toggled = False
    if was_edit and _needs_edit_mode_refresh_for_channel(targets, value):
        try:
            if bpy.ops.object.mode_set.poll():
                bpy.ops.object.mode_set(mode='OBJECT')
                toggled = True
        except Exception:
            toggled = False

    layer_name = ''
    active_index = None
    for target in targets:
        name = apply_channel_to_object(target, value)
        if name and not layer_name:
            layer_name = name
            try:
                layers = uv_layers(target)
                active_index = int(getattr(layers, 'active_index', 0) or 0) if layers is not None else None
            except Exception:
                active_index = None

    if toggled:
        try:
            bpy.ops.object.mode_set(mode='EDIT')
        except Exception:
            pass

    if ws is not None:
        if layer_name:
            try:
                setattr(ws, 'unwrap_map_channel_name', layer_name)
            except Exception:
                pass
        if active_index is not None:
            # Compatibility for legacy Smart Standard/Core routes that still use 1-based channel fields.
            for attr in ('smart_standard_target_channel', 'smart_standard_source_channel'):
                try:
                    if hasattr(ws, attr):
                        setattr(ws, attr, int(active_index) + 1)
                except Exception:
                    pass
    return layer_name

def selected_index(context: Any, ws: Any = None, obj: Any = None, *, create: bool = False) -> int | None:
    if ws is None:
        try:
            ws = getattr(getattr(context, 'scene', None), 'suv_workspace', None)
        except Exception:
            ws = None
    if obj is None:
        obj = mesh_object_from_context(context or bpy.context)
    layers = uv_layers(obj)
    if layers is None:
        return None
    if create:
        _ensure_layer_exists(layers)
    try:
        count = len(layers)
    except Exception:
        count = 0
    if count <= 0:
        return None
    value = ACTIVE_IDENTIFIER
    if ws is not None:
        try:
            value = str(getattr(ws, 'unwrap_map_channel', ACTIVE_IDENTIFIER) or ACTIVE_IDENTIFIER)
        except Exception:
            value = ACTIVE_IDENTIFIER
    index = _parse_channel_index(value)
    if index is None:
        try:
            index = int(getattr(layers, 'active_index', 0) or 0)
        except Exception:
            index = 0
    return max(0, min(int(index), count - 1))


def channel_rows(context: Any, ws: Any = None):
    obj = mesh_object_from_context(context or bpy.context)
    layers = uv_layers(obj)
    rows: list[tuple[int, str, bool, bool]] = []
    if layers is None:
        return rows
    try:
        active_index = int(getattr(layers, 'active_index', 0) or 0)
    except Exception:
        active_index = 0
    target_index = selected_index(context, ws, obj, create=False)
    try:
        for index, layer in enumerate(layers):
            rows.append((index, _safe_layer_name(layer, f'UVMap.{index + 1:03d}'), index == active_index, index == target_index))
    except Exception:
        pass
    return rows




def map_channel_copy_source_enum_items(context: Any) -> tuple[tuple[str, str, str], ...]:
    """Dynamic items for the UV-map copy source selector."""
    global _COPY_SOURCE_ITEMS_CACHE
    ctx = context or bpy.context
    obj = mesh_object_from_context(ctx)
    layers = uv_layers(obj)
    items: list[tuple[str, str, str]] = [(
        ACTIVE_IDENTIFIER,
        _tx(ctx, 'Active UV Map', '現在のアクティブ'),
        _tx(ctx, 'Use the currently active UV map as the copy source.', '現在アクティブなUVマップをコピー元として使います。'),
    )]
    if layers is not None:
        try:
            for index, layer in enumerate(layers):
                name = _safe_layer_name(layer, f'UVMap.{index + 1:03d}')
                items.append((
                    CHANNEL_PREFIX + str(index),
                    f'{index}: {name}',
                    _tx(
                        ctx,
                        f'Copy UV coordinates from UV map channel index {index} named "{name}".',
                        f'「{name}」のUVマップチャンネル実インデックス {index} からUV座標をコピーします。',
                    ),
                ))
        except Exception:
            pass
    _COPY_SOURCE_ITEMS_CACHE = tuple(items)
    return _COPY_SOURCE_ITEMS_CACHE


def map_channel_copy_destination_enum_items(context: Any) -> tuple[tuple[str, str, str], ...]:
    """Dynamic items for the UV-map copy destination selector."""
    global _COPY_DESTINATION_ITEMS_CACHE
    ctx = context or bpy.context
    obj = mesh_object_from_context(ctx)
    layers = uv_layers(obj)
    items: list[tuple[str, str, str]] = [(
        COPY_TARGET_IDENTIFIER,
        _tx(ctx, 'Unwrap Target Channel', '展開使用チャンネル'),
        _tx(ctx, 'Copy UV coordinates to the map channel currently selected as the unwrap/edit target.', '展開使用マップチャンネルで選択しているチャンネルへUV座標を書き込みます。'),
    ), (
        ACTIVE_IDENTIFIER,
        _tx(ctx, 'Active UV Map', '現在のアクティブ'),
        _tx(ctx, 'Copy UV coordinates to the currently active UV map.', '現在アクティブなUVマップへUV座標をコピーします。'),
    )]
    if layers is not None:
        try:
            for index, layer in enumerate(layers):
                name = _safe_layer_name(layer, f'UVMap.{index + 1:03d}')
                items.append((
                    CHANNEL_PREFIX + str(index),
                    f'{index}: {name}',
                    _tx(
                        ctx,
                        f'Overwrite UV coordinates in UV map channel index {index} named "{name}".',
                        f'「{name}」のUVマップチャンネル実インデックス {index} のUV座標を上書きします。',
                    ),
                ))
        except Exception:
            pass
    _COPY_DESTINATION_ITEMS_CACHE = tuple(items)
    return _COPY_DESTINATION_ITEMS_CACHE


def _workspace(context: Any):
    try:
        return getattr(getattr(context, 'scene', None), 'suv_workspace', None)
    except Exception:
        return None


def _object_mode(obj: Any) -> str:
    try:
        return str(getattr(obj, 'mode', '') or '')
    except Exception:
        return ''


def _set_mode_for_object(obj: Any, mode: str) -> bool:
    if obj is None:
        return False
    try:
        if getattr(bpy.context, 'active_object', None) is not obj:
            bpy.context.view_layer.objects.active = obj
    except Exception:
        pass
    try:
        if bpy.ops.object.mode_set.poll():
            bpy.ops.object.mode_set(mode=mode)
            return True
    except Exception:
        pass
    return False


def _resolve_channel_identifier(context: Any, ws: Any, obj: Any, value: Any, *, create: bool = False) -> int | None:
    layers = uv_layers(obj)
    if layers is None:
        return None
    if create:
        _ensure_layer_exists(layers)
    try:
        count = len(layers)
    except Exception:
        count = 0
    if count <= 0:
        return None
    raw = str(value or ACTIVE_IDENTIFIER).upper()
    if raw == COPY_TARGET_IDENTIFIER:
        try:
            raw = str(getattr(ws, 'unwrap_map_channel', ACTIVE_IDENTIFIER) or ACTIVE_IDENTIFIER).upper() if ws is not None else ACTIVE_IDENTIFIER
        except Exception:
            raw = ACTIVE_IDENTIFIER
    parsed = _parse_channel_index(raw)
    if parsed is None:
        try:
            parsed = int(getattr(layers, 'active_index', 0) or 0)
        except Exception:
            parsed = 0
    return max(0, min(int(parsed), count - 1))


def _set_workspace_target_channel(ws: Any, index: int | None, layer_name: str = '') -> None:
    if ws is None:
        return
    if index is not None:
        try:
            setattr(ws, 'unwrap_map_channel', CHANNEL_PREFIX + str(max(0, int(index))))
        except Exception:
            pass
        try:
            setattr(ws, 'smart_standard_target_channel', int(index) + 1)
            setattr(ws, 'smart_standard_source_channel', int(index) + 1)
        except Exception:
            pass
    if layer_name:
        try:
            setattr(ws, 'unwrap_map_channel_name', layer_name)
        except Exception:
            pass




def _channel_identifier(index: int) -> str:
    return CHANNEL_PREFIX + str(max(0, int(index)))


def _remap_channel_value_after_remove(value: Any, removed_index: int, new_count: int, *, default: str) -> str:
    raw = str(value or default)
    upper = raw.upper()
    if upper in {ACTIVE_IDENTIFIER, COPY_TARGET_IDENTIFIER}:
        return upper
    parsed = _parse_channel_index(upper)
    if parsed is None:
        return default
    removed_index = max(0, int(removed_index))
    new_count = max(0, int(new_count))
    if parsed == removed_index:
        return default
    if parsed > removed_index:
        parsed -= 1
    if parsed < 0 or parsed >= new_count:
        return default
    return _channel_identifier(parsed)


def _remap_channel_value_after_swap(value: Any, first_index: int, second_index: int, *, default: str) -> str:
    raw = str(value or default)
    upper = raw.upper()
    if upper in {ACTIVE_IDENTIFIER, COPY_TARGET_IDENTIFIER}:
        return upper
    parsed = _parse_channel_index(upper)
    if parsed is None:
        return default
    first_index = max(0, int(first_index))
    second_index = max(0, int(second_index))
    if parsed == first_index:
        parsed = second_index
    elif parsed == second_index:
        parsed = first_index
    return _channel_identifier(parsed)


def _set_workspace_channel_value(ws: Any, attr: str, value: str) -> None:
    if ws is None:
        return
    try:
        setattr(ws, attr, value)
    except Exception:
        pass


def _snapshot_uv_loop(loop: Any) -> dict[str, Any]:
    snapshot: dict[str, Any] = {}
    try:
        uv = getattr(loop, 'uv', None)
        snapshot['uv'] = (float(uv[0]), float(uv[1])) if uv is not None else (0.0, 0.0)
    except Exception:
        snapshot['uv'] = (0.0, 0.0)
    for attr in ('pin_uv', 'select', 'select_edge', 'select_vert'):
        try:
            snapshot[attr] = bool(getattr(loop, attr))
        except Exception:
            snapshot[attr] = None
    return snapshot


def _restore_uv_loop(loop: Any, snapshot: dict[str, Any]) -> None:
    try:
        loop.uv = snapshot.get('uv', (0.0, 0.0))
    except Exception:
        pass
    for attr in ('pin_uv', 'select', 'select_edge', 'select_vert'):
        value = snapshot.get(attr, None)
        if value is None:
            continue
        try:
            setattr(loop, attr, bool(value))
        except Exception:
            pass


def _snapshot_uv_layer(layer: Any, index: int) -> dict[str, Any]:
    data = []
    try:
        data = [_snapshot_uv_loop(loop) for loop in getattr(layer, 'data', ())]
    except Exception:
        data = []
    return {
        'name': _safe_layer_name(layer, f'UVMap.{int(index) + 1:03d}'),
        'active_render': bool(getattr(layer, 'active_render', False)) if layer is not None else False,
        'active_clone': bool(getattr(layer, 'active_clone', False)) if layer is not None else False,
        'data': data,
    }


def _restore_uv_layer(layer: Any, snapshot: dict[str, Any]) -> None:
    loops = snapshot.get('data', ()) or ()
    try:
        for loop, loop_snapshot in zip(getattr(layer, 'data', ()), loops):
            _restore_uv_loop(loop, loop_snapshot)
    except Exception:
        pass


def _rebuild_uv_layers_in_order(obj: Any, snapshots: list[dict[str, Any]]) -> list[Any]:
    layers = uv_layers(obj)
    if layers is None:
        return []
    try:
        while len(layers) > 0:
            layers.remove(layers[0])
    except Exception:
        # If Blender refuses removal for a transient edit-state reason, leave the
        # mesh untouched and let the caller report the original exception path.
        raise
    created: list[Any] = []
    for snapshot in snapshots:
        name = str(snapshot.get('name') or DEFAULT_UV_NAME)
        try:
            layer = layers.new(name=name, do_init=False)
        except TypeError:
            layer = layers.new(name=name)
        _restore_uv_layer(layer, snapshot)
        created.append(layer)
    for layer, snapshot in zip(created, snapshots):
        try:
            if bool(snapshot.get('active_render', False)):
                layer.active_render = True
        except Exception:
            pass
        try:
            if bool(snapshot.get('active_clone', False)):
                layer.active_clone = True
        except Exception:
            pass
    return created

def _tag_uv_channel_redraw(context: Any | None = None) -> None:
    ctx = context or getattr(bpy, 'context', None)
    screens = []
    try:
        screen = getattr(ctx, 'screen', None)
        if screen is not None:
            screens.append(screen)
    except Exception:
        pass
    try:
        wm = getattr(ctx, 'window_manager', None) if ctx is not None else getattr(getattr(bpy, 'context', None), 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            if screen is not None:
                screens.append(screen)
    except Exception:
        pass
    seen: set[int] = set()
    for screen in screens:
        try:
            key = int(screen.as_pointer())
        except Exception:
            key = id(screen)
        if key in seen:
            continue
        seen.add(key)
        try:
            for area in getattr(screen, 'areas', ()) or ():
                if str(getattr(area, 'type', '') or '') in {'IMAGE_EDITOR', 'VIEW_3D'}:
                    try:
                        area.tag_redraw()
                    except Exception:
                        pass
        except Exception:
            pass


def select_map_channel(context: Any, index: int) -> tuple[bool, str, int | None]:
    """Select a UV map channel from the visible list and make it the edit target.

    The workspace enum is kept in sync with the row selection, then
    ``ensure_unwrap_map_channel`` performs the same Blender 5.1 Edit Mode refresh
    used by unwrap operators.  This makes the requested layer active for the UV
    Editor without changing mesh/UV component selection.
    """
    ctx = context or bpy.context
    ws = _workspace(ctx)
    obj = mesh_object_from_context(ctx)
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return False, _tx(ctx, 'No mesh object is selected.', 'メッシュオブジェクトが選択されていません。'), None
    layers = uv_layers(obj)
    if layers is None:
        return False, _tx(ctx, 'The selected object has no UV map container.', '選択オブジェクトにUVマップコンテナがありません。'), None
    try:
        count = len(layers)
    except Exception:
        count = 0
    if count <= 0:
        return False, _tx(ctx, 'No UV map channel exists.', 'UVマップチャンネルがありません。'), None
    target_index = max(0, min(int(index), count - 1))
    target_identifier = CHANNEL_PREFIX + str(target_index)
    try:
        layer_name = _safe_layer_name(layers[target_index], f'UVMap.{target_index + 1:03d}')
    except Exception:
        layer_name = ''
    if ws is not None:
        try:
            setattr(ws, 'unwrap_map_channel', target_identifier)
        except Exception:
            pass
    try:
        active_name = ensure_unwrap_map_channel(ctx, ws, None)
    except Exception:
        active_name = ''
    # If the enum value did not change, Blender will not call its update
    # callback.  Explicitly apply the row selection so clicking the current
    # target still repairs a stale active UV layer.
    try:
        layers = uv_layers(obj)
        if layers is not None and len(layers) > 0:
            target_index = max(0, min(target_index, len(layers) - 1))
            layers.active_index = target_index
            try:
                layer_name = _safe_layer_name(layers[target_index], layer_name or f'UVMap.{target_index + 1:03d}')
            except Exception:
                pass
    except Exception:
        pass
    if ws is not None:
        try:
            _set_workspace_target_channel(ws, target_index, active_name or layer_name)
        except Exception:
            pass
    try:
        data = getattr(obj, 'data', None)
        if data is not None and hasattr(data, 'update'):
            data.update()
    except Exception:
        pass
    _tag_uv_channel_redraw(ctx)
    return True, active_name or layer_name or target_identifier, target_index


def _unique_uv_name(layers: Any, base_name: str, *, active_layer: Any = None) -> str:
    base = str(base_name or DEFAULT_UV_NAME).strip() or DEFAULT_UV_NAME
    try:
        names = {str(layer.name) for layer in layers if layer is not active_layer}
    except Exception:
        names = set()
    if base not in names:
        return base
    i = 1
    while True:
        candidate = f'{base}.{i:03d}'
        if candidate not in names:
            return candidate
        i += 1


def add_map_channel(context: Any, name: str = '') -> tuple[bool, str, int | None]:
    ctx = context or bpy.context
    ws = _workspace(ctx)
    obj = mesh_object_from_context(ctx)
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return False, _tx(ctx, 'No mesh object is selected.', 'メッシュオブジェクトが選択されていません。'), None
    layers = uv_layers(obj)
    if layers is None:
        return False, _tx(ctx, 'The selected object has no UV map container.', '選択オブジェクトにUVマップコンテナがありません。'), None
    old_mode = _object_mode(obj)
    toggled = False
    try:
        if old_mode == 'EDIT':
            toggled = _set_mode_for_object(obj, 'OBJECT')
        base_name = str(name or getattr(ws, 'map_channel_new_name', '') or getattr(ws, 'uv_new_name', '') or DEFAULT_UV_NAME).strip() or DEFAULT_UV_NAME
        layer_name = _unique_uv_name(layers, base_name)
        try:
            layer = layers.new(name=layer_name, do_init=True)
        except TypeError:
            layer = layers.new(name=layer_name)
        try:
            layers.active = layer
        except Exception:
            pass
        try:
            active_index = int(getattr(layers, 'active_index', len(layers) - 1) or 0)
        except Exception:
            active_index = max(0, len(layers) - 1)
        _set_workspace_target_channel(ws, active_index, _safe_layer_name(layer, layer_name))
        try:
            if ws is not None:
                setattr(ws, 'map_channel_new_name', base_name)
                setattr(ws, 'map_channel_copy_destination', COPY_TARGET_IDENTIFIER)
        except Exception:
            pass
        return True, _safe_layer_name(layer, layer_name), active_index
    except Exception as exc:
        return False, str(exc), None
    finally:
        if toggled and old_mode == 'EDIT':
            _set_mode_for_object(obj, 'EDIT')


def remove_map_channel(context: Any, value: Any = None) -> tuple[bool, str, int | None]:
    ctx = context or bpy.context
    ws = _workspace(ctx)
    obj = mesh_object_from_context(ctx)
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return False, _tx(ctx, 'No mesh object is selected.', 'メッシュオブジェクトが選択されていません。'), None
    layers = uv_layers(obj)
    if layers is None:
        return False, _tx(ctx, 'The selected object has no UV map container.', '選択オブジェクトにUVマップコンテナがありません。'), None
    old_mode = _object_mode(obj)
    toggled = False
    try:
        if old_mode == 'EDIT':
            toggled = _set_mode_for_object(obj, 'OBJECT')
        try:
            count = len(layers)
        except Exception:
            count = 0
        if count <= 0:
            return False, _tx(ctx, 'No UV map channel exists.', 'UVマップチャンネルがありません。'), None
        if value is None:
            try:
                value = getattr(ws, 'unwrap_map_channel', ACTIVE_IDENTIFIER) if ws is not None else ACTIVE_IDENTIFIER
            except Exception:
                value = ACTIVE_IDENTIFIER
        index = _resolve_channel_identifier(ctx, ws, obj, value, create=False)
        if index is None:
            return False, _tx(ctx, 'No removable UV map channel was found.', '削除できるUVマップチャンネルが見つかりません。'), None
        layer = layers[index]
        removed_name = _safe_layer_name(layer, f'UVMap.{index + 1:03d}')
        remapped_src = ACTIVE_IDENTIFIER
        remapped_dst = COPY_TARGET_IDENTIFIER
        try:
            current_src = str(getattr(ws, 'map_channel_copy_source', ACTIVE_IDENTIFIER) or ACTIVE_IDENTIFIER) if ws is not None else ACTIVE_IDENTIFIER
            current_dst = str(getattr(ws, 'map_channel_copy_destination', COPY_TARGET_IDENTIFIER) or COPY_TARGET_IDENTIFIER) if ws is not None else COPY_TARGET_IDENTIFIER
            remapped_src = _remap_channel_value_after_remove(current_src, index, count - 1, default=ACTIVE_IDENTIFIER)
            remapped_dst = _remap_channel_value_after_remove(current_dst, index, count - 1, default=COPY_TARGET_IDENTIFIER)
        except Exception:
            remapped_src = ACTIVE_IDENTIFIER
            remapped_dst = COPY_TARGET_IDENTIFIER
        try:
            # Put dynamic enum-backed properties on stable identifiers before the
            # UV layer collection shrinks.  This avoids transient invalid enum
            # values such as CHANNEL_3 when the last channel is deleted.
            _set_workspace_channel_value(ws, 'unwrap_map_channel', ACTIVE_IDENTIFIER)
            _set_workspace_channel_value(ws, 'map_channel_copy_source', ACTIVE_IDENTIFIER)
            _set_workspace_channel_value(ws, 'map_channel_copy_destination', COPY_TARGET_IDENTIFIER)
        except Exception:
            pass
        layers.remove(layer)
        try:
            new_count = len(layers)
        except Exception:
            new_count = 0
        new_index = None
        if new_count > 0:
            new_index = max(0, min(index, new_count - 1))
            try:
                layers.active_index = new_index
            except Exception:
                pass
            try:
                _set_workspace_target_channel(ws, new_index, _safe_layer_name(layers[new_index], ''))
            except Exception:
                _set_workspace_target_channel(ws, new_index, '')
            try:
                if ws is not None:
                    setattr(ws, 'map_channel_copy_source', remapped_src)
                    setattr(ws, 'map_channel_copy_destination', remapped_dst)
            except Exception:
                pass
        else:
            try:
                if ws is not None:
                    setattr(ws, 'unwrap_map_channel', ACTIVE_IDENTIFIER)
                    setattr(ws, 'unwrap_map_channel_name', '')
                    setattr(ws, 'map_channel_copy_source', ACTIVE_IDENTIFIER)
                    setattr(ws, 'map_channel_copy_destination', COPY_TARGET_IDENTIFIER)
            except Exception:
                pass
        return True, removed_name, new_index
    except Exception as exc:
        return False, str(exc), None
    finally:
        if toggled and old_mode == 'EDIT':
            _set_mode_for_object(obj, 'EDIT')



def reorder_map_channel(context: Any, direction: int = -1) -> tuple[bool, str, tuple[int, int] | None]:
    """Move the selected UV map channel up or down by one slot.

    Blender 5.1 exposes UV maps as a collection without a public ``move``
    method.  To keep the UI operation functional, the add-on snapshots every UV
    layer, rebuilds the collection in the requested order, restores UV loop
    coordinates/selection/pin state, and then reselects the moved channel as the
    active unwrap/edit target.
    """
    ctx = context or bpy.context
    ws = _workspace(ctx)
    obj = mesh_object_from_context(ctx)
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return False, _tx(ctx, 'No mesh object is selected.', 'メッシュオブジェクトが選択されていません。'), None
    layers = uv_layers(obj)
    if layers is None:
        return False, _tx(ctx, 'The selected object has no UV map container.', '選択オブジェクトにUVマップコンテナがありません。'), None
    try:
        count = len(layers)
    except Exception:
        count = 0
    if count <= 1:
        return False, _tx(ctx, 'At least two UV map channels are required for reordering.', '並び替えには2つ以上のUVマップチャンネルが必要です。'), None
    step = -1 if int(direction or 0) < 0 else 1
    index = selected_index(ctx, ws, obj, create=False)
    if index is None:
        return False, _tx(ctx, 'No UV map channel is selected for reordering.', '並び替えるUVマップチャンネルが選択されていません。'), None
    index = max(0, min(int(index), count - 1))
    new_index = index + step
    if new_index < 0:
        return False, _tx(ctx, 'The selected UV map channel is already at the top.', '選択中のUVマップチャンネルはすでに先頭です。'), None
    if new_index >= count:
        return False, _tx(ctx, 'The selected UV map channel is already at the bottom.', '選択中のUVマップチャンネルはすでに末尾です。'), None

    old_mode = _object_mode(obj)
    toggled = False
    try:
        if old_mode == 'EDIT':
            toggled = _set_mode_for_object(obj, 'OBJECT')
        layers = uv_layers(obj)
        if layers is None:
            return False, _tx(ctx, 'The selected object has no UV map container.', '選択オブジェクトにUVマップコンテナがありません。'), None
        try:
            count = len(layers)
        except Exception:
            count = 0
        if count <= max(index, new_index):
            return False, _tx(ctx, 'The selected UV map channel could not be resolved after mode change.', 'モード変更後に選択中のUVマップチャンネルを解決できませんでした。'), None

        try:
            snapshots = [_snapshot_uv_layer(layer, idx) for idx, layer in enumerate(layers)]
        except Exception as exc:
            return False, str(exc), None
        moved_name = str(snapshots[index].get('name') or f'UVMap.{index + 1:03d}')
        snapshots[index], snapshots[new_index] = snapshots[new_index], snapshots[index]

        try:
            current_src = str(getattr(ws, 'map_channel_copy_source', ACTIVE_IDENTIFIER) or ACTIVE_IDENTIFIER) if ws is not None else ACTIVE_IDENTIFIER
            current_dst = str(getattr(ws, 'map_channel_copy_destination', COPY_TARGET_IDENTIFIER) or COPY_TARGET_IDENTIFIER) if ws is not None else COPY_TARGET_IDENTIFIER
            remapped_src = _remap_channel_value_after_swap(current_src, index, new_index, default=ACTIVE_IDENTIFIER)
            remapped_dst = _remap_channel_value_after_swap(current_dst, index, new_index, default=COPY_TARGET_IDENTIFIER)
        except Exception:
            remapped_src = ACTIVE_IDENTIFIER
            remapped_dst = COPY_TARGET_IDENTIFIER

        try:
            _set_workspace_channel_value(ws, 'unwrap_map_channel', ACTIVE_IDENTIFIER)
            _set_workspace_channel_value(ws, 'map_channel_copy_source', ACTIVE_IDENTIFIER)
            _set_workspace_channel_value(ws, 'map_channel_copy_destination', COPY_TARGET_IDENTIFIER)
        except Exception:
            pass

        created = _rebuild_uv_layers_in_order(obj, snapshots)
        if not created or len(created) != count:
            return False, _tx(ctx, 'UV map channels could not be rebuilt for reordering.', '並び替え用にUVマップチャンネルを再構築できませんでした。'), None
        layers = uv_layers(obj)
        try:
            layers.active_index = new_index
        except Exception:
            pass
        try:
            _set_workspace_target_channel(ws, new_index, _safe_layer_name(layers[new_index], moved_name))
        except Exception:
            _set_workspace_target_channel(ws, new_index, moved_name)
        try:
            if ws is not None:
                setattr(ws, 'map_channel_copy_source', remapped_src)
                setattr(ws, 'map_channel_copy_destination', remapped_dst)
        except Exception:
            pass
        try:
            data = getattr(obj, 'data', None)
            if data is not None and hasattr(data, 'update'):
                data.update()
        except Exception:
            pass
        _tag_uv_channel_redraw(ctx)
        return True, moved_name, (index, new_index)
    except Exception as exc:
        return False, str(exc), None
    finally:
        if toggled and old_mode == 'EDIT':
            _set_mode_for_object(obj, 'EDIT')


def _copy_loop_uv_attrs(src: Any, dst: Any) -> None:
    try:
        dst.uv = src.uv.copy()
    except Exception:
        try:
            dst.uv = src.uv
        except Exception:
            pass
    for attr in ('pin_uv', 'select', 'select_edge', 'select_vert'):
        try:
            setattr(dst, attr, getattr(src, attr))
        except Exception:
            pass


def copy_map_channel(context: Any, source_value: Any = None, destination_value: Any = None) -> tuple[bool, str, tuple[int, int] | None]:
    ctx = context or bpy.context
    ws = _workspace(ctx)
    obj = mesh_object_from_context(ctx)
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return False, _tx(ctx, 'No mesh object is selected.', 'メッシュオブジェクトが選択されていません。'), None
    layers = uv_layers(obj)
    if layers is None:
        return False, _tx(ctx, 'The selected object has no UV map container.', '選択オブジェクトにUVマップコンテナがありません。'), None
    try:
        if len(layers) <= 0:
            return False, _tx(ctx, 'No UV map channel exists.', 'UVマップチャンネルがありません。'), None
    except Exception:
        return False, _tx(ctx, 'No UV map channel exists.', 'UVマップチャンネルがありません。'), None
    if source_value is None:
        try:
            source_value = getattr(ws, 'map_channel_copy_source', ACTIVE_IDENTIFIER) if ws is not None else ACTIVE_IDENTIFIER
        except Exception:
            source_value = ACTIVE_IDENTIFIER
    if destination_value is None:
        # The UI no longer exposes a separate copy destination.  Copy output is
        # always written to the channel selected in unwrap_map_channel.
        destination_value = COPY_TARGET_IDENTIFIER
    src_index = _resolve_channel_identifier(ctx, ws, obj, source_value, create=False)
    dst_index = _resolve_channel_identifier(ctx, ws, obj, destination_value, create=False)
    if src_index is None or dst_index is None:
        return False, _tx(ctx, 'Copy source or unwrap map channel could not be resolved.', 'コピー元または展開使用マップチャンネルを解決できません。'), None
    if int(src_index) == int(dst_index):
        return False, _tx(ctx, 'Copy source and unwrap map channel are the same UV map channel.', 'コピー元と展開使用マップチャンネルが同じUVマップチャンネルです。'), (src_index, dst_index)
    old_mode = _object_mode(obj)
    toggled = False
    try:
        # Copy through object-mode mesh UV data even while the user is editing.
        # This preserves mesh component selection after returning to Edit Mode
        # and avoids stale/non-active BMesh UV-layer values in Blender 5.1.
        if old_mode == 'EDIT':
            toggled = _set_mode_for_object(obj, 'OBJECT')
        layers = uv_layers(obj)
        if layers is None:
            return False, _tx(ctx, 'The selected object has no UV map container.', '選択オブジェクトにUVマップコンテナがありません。'), None
        try:
            count_after_mode = len(layers)
        except Exception:
            count_after_mode = 0
        if count_after_mode <= max(int(src_index), int(dst_index)):
            return False, _tx(ctx, 'Copy source or unwrap map channel could not be resolved.', 'コピー元または展開使用マップチャンネルを解決できません。'), None
        src_layer = layers[int(src_index)]
        dst_layer = layers[int(dst_index)]
        for src, dst in zip(getattr(src_layer, 'data', ()), getattr(dst_layer, 'data', ())):
            _copy_loop_uv_attrs(src, dst)
        try:
            obj.data.update()
        except Exception:
            pass
        try:
            layers.active_index = int(dst_index)
        except Exception:
            pass
        try:
            _set_workspace_target_channel(ws, int(dst_index), _safe_layer_name(layers[int(dst_index)], ''))
        except Exception:
            _set_workspace_target_channel(ws, int(dst_index), '')
        src_name = _safe_layer_name(layers[int(src_index)], f'UVMap.{int(src_index) + 1:03d}')
        dst_name = _safe_layer_name(layers[int(dst_index)], f'UVMap.{int(dst_index) + 1:03d}')
        return True, f'{src_name} -> {dst_name}', (int(src_index), int(dst_index))
    except Exception as exc:
        return False, str(exc), None
    finally:
        if toggled and old_mode == 'EDIT':
            _set_mode_for_object(obj, 'EDIT')


class SMARTUVSUITE_OT_map_channel_select(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.map_channel_select'
    bl_label = 'Select Map Channel'
    bl_description = 'Selects a UV map channel from the selected-object channel list and makes it the active edit target in the UV Editor.'
    bl_options = {'UNDO'}

    index: bpy.props.IntProperty(name='Channel Number', default=0, min=0)

    @classmethod
    def description(cls, context, properties):
        index = 0
        try:
            index = int(getattr(properties, 'index', 0) or 0)
        except Exception:
            index = 0
        name = ''
        try:
            obj = mesh_object_from_context(context or bpy.context)
            layers = uv_layers(obj)
            if layers is not None and 0 <= index < len(layers):
                name = _safe_layer_name(layers[index], f'UVMap.{index + 1:03d}')
        except Exception:
            name = ''
        if name:
            return _tx(
                context,
                f'Function: selects UV map channel index {index} named "{name}" as the Smart UV Suite unwrap/edit target and makes it the active UV map shown in the UV Editor. How to use: select this channel in the Unwrap Map Channel dropdown. The index shown beside Active/Target is Blender\'s actual UV layer index. Edit the Channel Name field in the Map Channels group when you only want to rename the selected channel.',
                f'機能: 「{name}」をSmart UV Suiteの展開/編集対象マップチャンネルの実インデックス {index} として選択し、UVエディターで表示・編集するアクティブUVマップにします。使い方: 「展開使用マップチャンネル」ドロップダウンでこのチャンネルを選択します。「アクティブ・展開対象」の横に表示されるインデックスはBlenderの実際のUVレイヤーインデックスです。名前だけを変更したい場合は、「マップチャンネル」内の「チャンネル名」を編集します。',
            )
        return _tx(
            context,
            f'Function: selects UV map channel index {index} as the Smart UV Suite unwrap/edit target and makes it active in the UV Editor. How to use: select this channel in the Unwrap Map Channel dropdown.',
            f'機能: UVマップチャンネルの実インデックス {index} をSmart UV Suiteの展開/編集対象として選択し、UVエディターのアクティブUVマップにします。使い方: 「展開使用マップチャンネル」ドロップダウンでこのチャンネルを選択します。',
        )

    def execute(self, context):
        ok, message, index = select_map_channel(context, int(getattr(self, 'index', 0) or 0))
        if not ok:
            self.report({'WARNING'}, str(message))
            return {'CANCELLED'}
        self.report({'INFO'}, _tx(context, f'Selected UV map channel: {message}', f'UVマップチャンネルを選択しました: {message}'))
        return {'FINISHED'}


class SMARTUVSUITE_OT_map_channel_add(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.map_channel_add'
    bl_label = 'Map Channel Add'
    bl_description = 'Add a UV map channel to the selected mesh object and set the new channel as the unwrap/edit target.'
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        del properties
        return _tx(
            context,
            'Function: adds a new UV map channel to the selected mesh object, copies the current UV layout into it when Blender initializes the new layer, and makes the new channel the active unwrap/edit target in the UV Editor. How to use: enter the new map name in New Map Name, then press Add. If the name already exists, Smart UV Suite automatically appends a number so existing channels are not overwritten.',
            '機能: 選択中メッシュオブジェクトに新しいUVマップチャンネルを追加し、Blenderの新規レイヤー初期化で現在のUV配置を引き継いだうえで、その新規チャンネルをUVエディターのアクティブな展開/編集対象にします。使い方: 「新規マップ名」に作成したい名前を入力してから「追加」を押します。同名が既にある場合は、既存チャンネルを上書きせず自動で連番を付けます。',
        )

    def execute(self, context):
        ok, message, index = add_map_channel(context)
        if not ok:
            self.report({'WARNING'}, str(message))
            return {'CANCELLED'}
        self.report({'INFO'}, _tx(context, f'Added UV map channel: {message}', f'UVマップチャンネルを追加しました: {message}'))
        return {'FINISHED'}


class SMARTUVSUITE_OT_map_channel_remove(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.map_channel_remove'
    bl_label = 'Map Channel Remove'
    bl_description = 'Remove the UV map channel selected as the unwrap/edit target.'
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        del properties
        return _tx(
            context,
            'Function: removes the UV map channel currently selected as the Smart UV Suite unwrap/edit target. How to use: choose the channel in the Map Channel dropdown, confirm that the Active/Target index is the channel you want to delete, then press Remove Target. The operation is undoable and does not intentionally change mesh element selection.',
            '機能: Smart UV Suiteの展開/編集対象として選択中のUVマップチャンネルを削除します。使い方: 「マップチャンネル」ドロップダウンで削除したいチャンネルを選び、「アクティブ・展開対象」のインデックスが対象チャンネルであることを確認してから「展開対象を削除」を押します。操作はUndo可能で、メッシュエレメントの選択状態は意図的に変更しません。',
        )

    def execute(self, context):
        ok, message, index = remove_map_channel(context)
        if not ok:
            self.report({'WARNING'}, str(message))
            return {'CANCELLED'}
        self.report({'INFO'}, _tx(context, f'Removed UV map channel: {message}', f'UVマップチャンネルを削除しました: {message}'))
        return {'FINISHED'}


class SMARTUVSUITE_OT_map_channel_move(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.map_channel_move'
    bl_label = 'Map Channel Move'
    bl_description = 'Move the selected UV map channel up or down in the selected object UV map order.'
    bl_options = {'UNDO'}

    direction: bpy.props.IntProperty(name='Move Direction', default=-1, min=-1, max=1)

    @classmethod
    def description(cls, context, properties):
        direction = -1
        try:
            direction = int(getattr(properties, 'direction', -1) or -1)
        except Exception:
            direction = -1
        if direction < 0:
            return _tx(
                context,
                'Function: moves the currently selected unwrap/edit UV map channel one index upward. How to use: select a channel in the Map Channel dropdown, then press Move Up. Smart UV Suite preserves the channel name and UV coordinates, updates the actual Blender UV layer index, and keeps the moved channel active in the UV Editor.',
                '機能: 現在選択している展開/編集対象UVマップチャンネルを、実際のBlender UVレイヤー順で1つ上のインデックスへ移動します。使い方: 「マップチャンネル」ドロップダウンで対象を選び、「上へ移動」を押します。チャンネル名とUV座標を保持し、実UVレイヤーインデックスを更新して、移動後のチャンネルをUVエディターのアクティブ対象のまま維持します。',
            )
        return _tx(
            context,
            'Function: moves the currently selected unwrap/edit UV map channel one index downward. How to use: select a channel in the Map Channel dropdown, then press Move Down. Smart UV Suite preserves the channel name and UV coordinates, updates the actual Blender UV layer index, and keeps the moved channel active in the UV Editor.',
            '機能: 現在選択している展開/編集対象UVマップチャンネルを、実際のBlender UVレイヤー順で1つ下のインデックスへ移動します。使い方: 「マップチャンネル」ドロップダウンで対象を選び、「下へ移動」を押します。チャンネル名とUV座標を保持し、実UVレイヤーインデックスを更新して、移動後のチャンネルをUVエディターのアクティブ対象のまま維持します。',
        )

    def execute(self, context):
        direction = -1
        try:
            direction = int(getattr(self, 'direction', -1) or -1)
        except Exception:
            direction = -1
        ok, message, pair = reorder_map_channel(context, direction)
        if not ok:
            self.report({'WARNING'}, str(message))
            return {'CANCELLED'}
        if pair is not None:
            self.report({'INFO'}, _tx(context, f'Moved UV map channel: {message} ({pair[0]} -> {pair[1]})', f'UVマップチャンネルを移動しました: {message} ({pair[0]} -> {pair[1]})'))
        else:
            self.report({'INFO'}, _tx(context, f'Moved UV map channel: {message}', f'UVマップチャンネルを移動しました: {message}'))
        return {'FINISHED'}


class SMARTUVSUITE_OT_map_channel_copy(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.map_channel_copy'
    bl_label = 'Map Channel UV Copy'
    bl_description = 'Copy UV layout data from the selected source UV map channel to the selected destination UV map channel.'
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        del properties
        return _tx(
            context,
            'Function: copies UV coordinates, pin state, and UV selection state from the chosen source map channel to the map channel currently selected in Unwrap Map Channel on the selected mesh object. How to use: choose Copy Source, choose the write target in Unwrap Map Channel, then press Copy UV Layout to Unwrap Map Channel. The selected unwrap map channel is overwritten, the source channel is left unchanged, and the unwrap map channel remains the active edit target.',
            '機能: 選択中メッシュオブジェクトで、指定したコピー元マップチャンネルのUV座標、ピン状態、UV選択状態を、「展開使用マップチャンネル」で選択中のチャンネルへコピーします。使い方: 「コピー元」を選び、書き込み先は「展開使用マップチャンネル」で選択してから「UV展開情報を展開使用マップチャンネルへコピー」を押します。展開使用マップチャンネルは上書きされ、コピー元は変更せず、コピー後も展開使用マップチャンネルがアクティブな編集対象になります。',
        )

    def execute(self, context):
        ok, message, pair = copy_map_channel(context)
        if not ok:
            self.report({'WARNING'}, str(message))
            return {'CANCELLED'}
        self.report({'INFO'}, _tx(context, f'Copied UV map channel: {message}', f'UVマップチャンネルのUV展開情報をコピーしました: {message}'))
        return {'FINISHED'}


_CLASSES = (
    SMARTUVSUITE_OT_map_channel_select,
    SMARTUVSUITE_OT_map_channel_add,
    SMARTUVSUITE_OT_map_channel_remove,
    SMARTUVSUITE_OT_map_channel_move,
    SMARTUVSUITE_OT_map_channel_copy,
)


def _suv_stage_001_register() -> None:
    for cls in _CLASSES:
        try:
            if bool(getattr(cls, 'is_registered', False)) or getattr(cls, '__dict__', {}).get('bl_rna') is not None:
                continue
        except Exception:
            pass
        try:
            _suv_resource.register_class(cls)
        except ValueError:
            pass
        except RuntimeError:
            pass
        except Exception:
            pass


def _suv_stage_001_unregister() -> None:
    for cls in reversed(_CLASSES):
        try:
            _suv_resource.unregister_class(cls)
        except Exception:
            pass

def describe_active_channels(context: Any, ws: Any = None) -> dict[str, Any]:
    """Return display data for the selected object's UV map channels."""
    obj = mesh_object_from_context(context or bpy.context)
    rows = channel_rows(context, ws)
    try:
        layers = uv_layers(obj)
        active_index = int(getattr(layers, 'active_index', 0) or 0) if layers is not None else -1
    except Exception:
        active_index = -1
    return {
        'object': str(getattr(obj, 'name', '') or '') if obj is not None else '',
        'active_index': active_index,
        'channels': [
            {
                'index': index,
                'name': name,
                'active': bool(is_active),
                'selected': bool(is_target),
            }
            for index, name, is_active, is_target in rows
        ],
    }

# -----------------------------------------------------------------------------
# Smart UV Suite 1.8.127 - multi-object map-channel list target support
# -----------------------------------------------------------------------------
# The previous 1.8.104 route treated map-channel operations as bulk operations
# across every selected mesh.  The Basic Settings UI now exposes a selected
# object list, and the controls below operate on the object selected in that
# list only.  Per-object unwrap-channel targets are stored on the mesh object so
# multi-object selections can keep different unwrap/edit channels at the same
# time.
OBJECT_TARGET_PROP = 'smart_uv_suite_unwrap_map_channel'
OBJECT_TARGET_NAME_PROP = 'smart_uv_suite_unwrap_map_channel_name'
_WORKSPACE_OBJECT_SYNC_GUARD = False


def selected_mesh_objects_for_map_channels(context: Any) -> list[Any]:
    ctx = context or bpy.context
    result: list[Any] = []
    seen: set[int] = set()

    def add(obj: Any) -> None:
        try:
            if obj is None or getattr(obj, 'type', None) != 'MESH':
                return
            key = id(obj)
            if key in seen:
                return
            seen.add(key)
            result.append(obj)
        except Exception:
            pass

    # Keep the visible order predictable: active/edit object first, then the
    # remaining selected meshes.  Multi-object Edit Mode exposes objects_in_mode;
    # include it because selected_objects can be stale in some 5.1 UI contexts.
    try:
        add(getattr(ctx, 'edit_object', None))
    except Exception:
        pass
    try:
        add(getattr(ctx, 'active_object', None))
    except Exception:
        pass
    try:
        for obj in getattr(ctx, 'selected_objects', []) or []:
            add(obj)
    except Exception:
        pass
    try:
        for obj in getattr(ctx, 'objects_in_mode', []) or []:
            add(obj)
    except Exception:
        pass
    return result


def _object_custom_target_value(obj: Any) -> str:
    try:
        value = str(obj.get(OBJECT_TARGET_PROP, '') or '')
    except Exception:
        value = ''
    return value if value else ACTIVE_IDENTIFIER


def _set_object_custom_target(obj: Any, value: Any, name: str = '') -> None:
    if obj is None:
        return
    raw = str(value or ACTIVE_IDENTIFIER).upper()
    if raw not in {ACTIVE_IDENTIFIER, COPY_TARGET_IDENTIFIER} and _parse_channel_index(raw) is None:
        raw = ACTIVE_IDENTIFIER
    try:
        obj[OBJECT_TARGET_PROP] = raw
    except Exception:
        pass
    if name:
        try:
            obj[OBJECT_TARGET_NAME_PROP] = str(name)
        except Exception:
            pass


def _guarded_set_workspace_target_channel(ws: Any, index: int | None, layer_name: str = '') -> None:
    global _WORKSPACE_OBJECT_SYNC_GUARD
    if ws is None:
        return
    previous = _WORKSPACE_OBJECT_SYNC_GUARD
    _WORKSPACE_OBJECT_SYNC_GUARD = True
    try:
        _set_workspace_target_channel(ws, index, layer_name)
    finally:
        _WORKSPACE_OBJECT_SYNC_GUARD = previous


def _target_value_for_object(context: Any, ws: Any, obj: Any) -> str:
    if obj is None:
        return ACTIVE_IDENTIFIER
    value = _object_custom_target_value(obj)
    # A selected object that has never received an explicit Smart UV Suite target
    # follows its own Blender active UV map.  Do not fall back to the workspace
    # enum here: in a multi-object selection that enum mirrors the list-selected
    # object, and using it as a global fallback would force unrelated selected
    # objects to the same channel during unwrap/pack preparation.
    return value or ACTIVE_IDENTIFIER


def _resolve_object_target_index(context: Any, ws: Any, obj: Any, *, create: bool = False) -> int | None:
    return _resolve_channel_identifier(context or bpy.context, ws, obj, _target_value_for_object(context or bpy.context, ws, obj), create=create)


def map_channel_object_from_context(context: Any, ws: Any = None, *, fallback: bool = True) -> Any:
    ctx = context or bpy.context
    if ws is None:
        ws = _workspace(ctx)
    targets = selected_mesh_objects_for_map_channels(ctx)
    if not targets:
        return None
    wanted = ''
    try:
        wanted = str(getattr(ws, 'map_channel_object_name', '') or '') if ws is not None else ''
    except Exception:
        wanted = ''
    if wanted:
        for obj in targets:
            try:
                if str(getattr(obj, 'name', '') or '') == wanted:
                    return obj
            except Exception:
                pass
    if not fallback:
        return None
    try:
        active = getattr(ctx, 'active_object', None)
    except Exception:
        active = None
    if active in targets:
        return active
    return targets[0]


def ensure_map_channel_object_selection(context: Any, ws: Any = None) -> Any:
    ctx = context or bpy.context
    if ws is None:
        ws = _workspace(ctx)
    obj = map_channel_object_from_context(ctx, ws, fallback=True)
    if obj is not None and ws is not None:
        try:
            if str(getattr(ws, 'map_channel_object_name', '') or '') != str(getattr(obj, 'name', '') or ''):
                setattr(ws, 'map_channel_object_name', str(getattr(obj, 'name', '') or ''))
        except Exception:
            pass
    return obj


def sync_workspace_to_map_channel_object(context: Any, ws: Any = None, obj: Any = None, *, apply: bool = False) -> None:
    global _WORKSPACE_OBJECT_SYNC_GUARD
    ctx = context or bpy.context
    if ws is None:
        ws = _workspace(ctx)
    if ws is None:
        return
    if obj is None:
        obj = ensure_map_channel_object_selection(ctx, ws)
    if obj is None:
        return
    value = _target_value_for_object(ctx, ws, obj)
    index = _resolve_channel_identifier(ctx, ws, obj, value, create=False)
    if index is not None:
        value = CHANNEL_PREFIX + str(index)
    _WORKSPACE_OBJECT_SYNC_GUARD = True
    try:
        try:
            setattr(ws, 'unwrap_map_channel', value)
        except Exception:
            pass
        try:
            if obj is not None:
                setattr(ws, 'map_channel_object_name', str(getattr(obj, 'name', '') or ''))
        except Exception:
            pass
        if apply and index is not None:
            try:
                name = apply_channel_to_object(obj, value)
            except Exception:
                name = ''
            try:
                _guarded_set_workspace_target_channel(ws, index, name)
            except Exception:
                pass
            _set_object_custom_target(obj, value, name)
    finally:
        _WORKSPACE_OBJECT_SYNC_GUARD = False


def workspace_channel_update(context: Any, ws: Any = None) -> None:
    ctx = context or bpy.context
    if ws is None:
        ws = _workspace(ctx)
    if ws is None or _WORKSPACE_OBJECT_SYNC_GUARD:
        return
    obj = ensure_map_channel_object_selection(ctx, ws)
    if obj is None:
        return
    try:
        value = str(getattr(ws, 'unwrap_map_channel', ACTIVE_IDENTIFIER) or ACTIVE_IDENTIFIER).upper()
    except Exception:
        value = ACTIVE_IDENTIFIER
    index = _resolve_channel_identifier(ctx, ws, obj, value, create=True)
    if index is not None:
        value = CHANNEL_PREFIX + str(index)
    name = ''
    try:
        name = apply_channel_to_object(obj, value)
    except Exception:
        name = ''
    _set_object_custom_target(obj, value, name)
    try:
        if index is not None:
            _guarded_set_workspace_target_channel(ws, index, name)
    except Exception:
        pass
    _tag_uv_channel_redraw(ctx)


def map_channel_object_rows(context: Any, ws: Any = None) -> list[dict[str, Any]]:
    ctx = context or bpy.context
    if ws is None:
        ws = _workspace(ctx)
    selected_obj = ensure_map_channel_object_selection(ctx, ws)
    rows: list[dict[str, Any]] = []
    try:
        active_obj = getattr(ctx, 'active_object', None)
    except Exception:
        active_obj = None
    for obj in selected_mesh_objects_for_map_channels(ctx):
        layers = uv_layers(obj)
        try:
            count = len(layers) if layers is not None else 0
        except Exception:
            count = 0
        try:
            active_index = int(getattr(layers, 'active_index', 0) or 0) if layers is not None and count > 0 else -1
        except Exception:
            active_index = -1
        target_index = _resolve_object_target_index(ctx, ws, obj, create=False)
        if target_index is None and count > 0:
            target_index = max(0, min(active_index, count - 1))
        target_name = ''
        if layers is not None and target_index is not None and 0 <= int(target_index) < count:
            try:
                target_name = _safe_layer_name(layers[int(target_index)], f'UVMap.{int(target_index) + 1:03d}')
            except Exception:
                target_name = ''
        if not target_name:
            target_name = _tx(ctx, 'No UV map', 'UVマップなし') if count <= 0 else _tx(ctx, 'Active UV Map', '現在のアクティブ')
        rows.append({
            'object': obj,
            'object_name': str(getattr(obj, 'name', '') or ''),
            'selected': obj is selected_obj,
            'active_object': obj is active_obj,
            'channel_count': count,
            'active_index': active_index,
            'target_index': int(target_index) if target_index is not None else -1,
            'target_name': target_name,
            'label': f"{getattr(obj, 'name', '')}: " + ((f"{int(target_index)}: {target_name}") if target_index is not None and count > 0 else target_name),
        })
    return rows


def _multi_map_channel_enum_items(context: Any) -> tuple[tuple[str, str, str], ...]:
    global _ENUM_ITEMS_CACHE
    ctx = context or bpy.context
    ws = _workspace(ctx)
    obj = ensure_map_channel_object_selection(ctx, ws)
    layers = uv_layers(obj)
    items: list[tuple[str, str, str]] = [(
        ACTIVE_IDENTIFIER,
        _tx(ctx, 'Active UV Map', '現在のアクティブ'),
        _tx(ctx, 'Use the UV map that is currently active on the object selected in the object list. This does not force other selected objects to the same channel.', 'オブジェクトリストで選択中のオブジェクトで、現在アクティブなUVマップを展開に使用します。他の選択オブジェクトへ同じチャンネルを強制しません。'),
    )]
    if obj is None or layers is None:
        items[0] = (
            ACTIVE_IDENTIFIER,
            _tx(ctx, 'No selected mesh', '選択メッシュなし'),
            _tx(ctx, 'Select a mesh object to show UV map channels.', 'メッシュオブジェクトを選択するとUVマップチャンネルを表示します。'),
        )
        _ENUM_ITEMS_CACHE = tuple(items)
        return _ENUM_ITEMS_CACHE
    try:
        count = len(layers)
    except Exception:
        count = 0
    if count <= 0:
        items.append((
            CHANNEL_PREFIX + '0',
            _tx(ctx, '0: New UVMap', '0: 新規UVMap'),
            _tx(ctx, 'No UV map exists on the object selected in the list. Smart UV Suite creates UV map index 0 and uses it for unwrap.', 'リストで選択中のオブジェクトにUVマップが無い場合、インデックス0のUVマップを作成して展開に使用します。'),
        ))
    else:
        try:
            active_index = int(getattr(layers, 'active_index', 0) or 0)
        except Exception:
            active_index = 0
        try:
            target_index = _resolve_object_target_index(ctx, ws, obj, create=False)
        except Exception:
            target_index = None
        for index, layer in enumerate(layers):
            name = _safe_layer_name(layer, f'UVMap.{index + 1:03d}')
            marks = []
            if index == active_index:
                marks.append(_tx(ctx, 'Active', 'アクティブ'))
            if target_index is not None and index == int(target_index):
                marks.append(_tx(ctx, 'Target', '展開対象'))
            suffix = (' ● ' + ', '.join(marks)) if marks else ''
            items.append((
                CHANNEL_PREFIX + str(index),
                f'{index}: {name}{suffix}',
                _tx(
                    ctx,
                    f'Use UV map channel index {index} named "{name}" for unwrap on the object selected in the object list. Other selected objects keep their own map-channel targets.',
                    f'リストで選択中のオブジェクトで、「{name}」を展開に使用するUVマップチャンネルの実インデックス {index} として使います。他の選択オブジェクトはそれぞれの展開対象マップチャンネルを維持します。',
                ),
            ))
    _ENUM_ITEMS_CACHE = tuple(items)
    return _ENUM_ITEMS_CACHE


map_channel_enum_items = _multi_map_channel_enum_items


def selected_index(context: Any, ws: Any = None, obj: Any = None, *, create: bool = False) -> int | None:
    ctx = context or bpy.context
    if ws is None:
        ws = _workspace(ctx)
    if obj is None:
        obj = map_channel_object_from_context(ctx, ws)
    layers = uv_layers(obj)
    if layers is None:
        return None
    if create:
        _ensure_layer_exists(layers)
    try:
        count = len(layers)
    except Exception:
        count = 0
    if count <= 0:
        return None
    index = _resolve_object_target_index(ctx, ws, obj, create=create)
    if index is None:
        try:
            index = int(getattr(layers, 'active_index', 0) or 0)
        except Exception:
            index = 0
    return max(0, min(int(index), count - 1))


def channel_rows(context: Any, ws: Any = None, obj: Any = None):
    ctx = context or bpy.context
    if ws is None:
        ws = _workspace(ctx)
    if obj is None:
        obj = map_channel_object_from_context(ctx, ws)
    layers = uv_layers(obj)
    rows: list[tuple[int, str, bool, bool]] = []
    if layers is None:
        return rows
    try:
        active_index = int(getattr(layers, 'active_index', 0) or 0)
    except Exception:
        active_index = 0
    target_index = selected_index(ctx, ws, obj, create=False)
    try:
        for index, layer in enumerate(layers):
            rows.append((index, _safe_layer_name(layer, f'UVMap.{index + 1:03d}'), index == active_index, index == target_index))
    except Exception:
        pass
    return rows


def _needs_edit_mode_refresh_for_targets(targets: list[Any], context: Any, ws: Any) -> bool:
    for target in targets:
        target_index = _resolve_object_target_index(context, ws, target, create=False)
        if target_index is None:
            continue
        layers = uv_layers(target)
        if layers is None:
            continue
        try:
            count = len(layers)
        except Exception:
            count = 0
        if count <= 0:
            return True
        wanted = max(0, min(int(target_index), count - 1))
        try:
            if int(getattr(layers, 'active_index', 0) or 0) != wanted:
                return True
        except Exception:
            return True
    return False


def ensure_unwrap_map_channel(context: Any, ws: Any = None, obj: Any = None) -> str:
    ctx = context or bpy.context
    if ws is None:
        ws = _workspace(ctx)
    if obj is not None:
        targets = [obj]
    else:
        targets = mesh_objects_for_context(ctx)
    targets = [target for target in targets if target is not None and getattr(target, 'type', None) == 'MESH']
    was_edit = _context_is_edit_mesh(ctx)
    toggled = False
    if was_edit and _needs_edit_mode_refresh_for_targets(targets, ctx, ws):
        try:
            if bpy.ops.object.mode_set.poll():
                bpy.ops.object.mode_set(mode='OBJECT')
                toggled = True
        except Exception:
            toggled = False
    layer_name = ''
    active_index = None
    try:
        for target in targets:
            value = _target_value_for_object(ctx, ws, target)
            index = _resolve_channel_identifier(ctx, ws, target, value, create=True)
            if index is not None:
                value = CHANNEL_PREFIX + str(index)
            name = apply_channel_to_object(target, value)
            _set_object_custom_target(target, value, name)
            if target is map_channel_object_from_context(ctx, ws) or not layer_name:
                layer_name = name or layer_name
                active_index = index
    finally:
        if toggled:
            try:
                bpy.ops.object.mode_set(mode='EDIT')
            except Exception:
                pass
    if ws is not None:
        if layer_name:
            try:
                setattr(ws, 'unwrap_map_channel_name', layer_name)
            except Exception:
                pass
        if active_index is not None:
            for attr in ('smart_standard_target_channel', 'smart_standard_source_channel'):
                try:
                    if hasattr(ws, attr):
                        setattr(ws, attr, int(active_index) + 1)
                except Exception:
                    pass
    return layer_name


def select_map_channel(context: Any, index: int, obj: Any = None) -> tuple[bool, str, int | None]:
    ctx = context or bpy.context
    ws = _workspace(ctx)
    if obj is None:
        obj = ensure_map_channel_object_selection(ctx, ws)
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return False, _tx(ctx, 'No mesh object is selected in the map-channel object list.', 'マップチャンネルのオブジェクトリストでメッシュオブジェクトが選択されていません。'), None
    layers = uv_layers(obj)
    if layers is None:
        return False, _tx(ctx, 'The selected object has no UV map container.', '選択オブジェクトにUVマップコンテナがありません。'), None
    try:
        count = len(layers)
    except Exception:
        count = 0
    if count <= 0:
        return False, _tx(ctx, 'No UV map channel exists.', 'UVマップチャンネルがありません。'), None
    target_index = max(0, min(int(index), count - 1))
    target_identifier = CHANNEL_PREFIX + str(target_index)
    try:
        layer_name = _safe_layer_name(layers[target_index], f'UVMap.{target_index + 1:03d}')
    except Exception:
        layer_name = ''
    _set_object_custom_target(obj, target_identifier, layer_name)
    try:
        if ws is not None:
            setattr(ws, 'map_channel_object_name', str(getattr(obj, 'name', '') or ''))
    except Exception:
        pass
    try:
        active_name = ensure_unwrap_map_channel(ctx, ws, obj)
    except Exception:
        active_name = ''
    try:
        layers = uv_layers(obj)
        if layers is not None and len(layers) > 0:
            target_index = max(0, min(target_index, len(layers) - 1))
            layers.active_index = target_index
            layer_name = _safe_layer_name(layers[target_index], layer_name or f'UVMap.{target_index + 1:03d}')
    except Exception:
        pass
    if ws is not None:
        try:
            sync_workspace_to_map_channel_object(ctx, ws, obj, apply=False)
            _guarded_set_workspace_target_channel(ws, target_index, active_name or layer_name)
        except Exception:
            pass
    try:
        data = getattr(obj, 'data', None)
        if data is not None and hasattr(data, 'update'):
            data.update()
    except Exception:
        pass
    _tag_uv_channel_redraw(ctx)
    return True, active_name or layer_name or target_identifier, target_index


def rename_map_channel(context: Any, name: str, obj: Any = None) -> tuple[bool, str, int | None]:
    ctx = context or bpy.context
    ws = _workspace(ctx)
    if obj is None:
        obj = ensure_map_channel_object_selection(ctx, ws)
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return False, _tx(ctx, 'No mesh object is selected in the map-channel object list.', 'マップチャンネルのオブジェクトリストでメッシュオブジェクトが選択されていません。'), None
    layers = uv_layers(obj)
    if layers is None:
        return False, _tx(ctx, 'The selected object has no UV map container.', '選択オブジェクトにUVマップコンテナがありません。'), None
    index = selected_index(ctx, ws, obj, create=False)
    if index is None:
        return False, _tx(ctx, 'No UV map channel exists.', 'UVマップチャンネルがありません。'), None
    try:
        count = len(layers)
    except Exception:
        count = 0
    if count <= 0:
        return False, _tx(ctx, 'No UV map channel exists.', 'UVマップチャンネルがありません。'), None
    index = max(0, min(int(index), count - 1))
    layer = layers[index]
    new_name = _unique_uv_name(layers, str(name or DEFAULT_UV_NAME).strip() or DEFAULT_UV_NAME, active_layer=layer)
    try:
        layer.name = new_name
    except Exception as exc:
        return False, str(exc), None
    _set_object_custom_target(obj, CHANNEL_PREFIX + str(index), new_name)
    try:
        _guarded_set_workspace_target_channel(ws, index, new_name)
    except Exception:
        pass
    _tag_uv_channel_redraw(ctx)
    return True, new_name, index


def add_map_channel(context: Any, name: str = '', obj: Any = None) -> tuple[bool, str, int | None]:
    ctx = context or bpy.context
    ws = _workspace(ctx)
    if obj is None:
        obj = ensure_map_channel_object_selection(ctx, ws)
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return False, _tx(ctx, 'No mesh object is selected in the map-channel object list.', 'マップチャンネルのオブジェクトリストでメッシュオブジェクトが選択されていません。'), None
    layers = uv_layers(obj)
    if layers is None:
        return False, _tx(ctx, 'The selected object has no UV map container.', '選択オブジェクトにUVマップコンテナがありません。'), None
    old_mode = _object_mode(obj)
    toggled = False
    try:
        if old_mode == 'EDIT':
            toggled = _set_mode_for_object(obj, 'OBJECT')
        layers = uv_layers(obj)
        base_name = str(name or getattr(ws, 'map_channel_new_name', '') or getattr(ws, 'uv_new_name', '') or DEFAULT_UV_NAME).strip() or DEFAULT_UV_NAME
        layer_name = _unique_uv_name(layers, base_name)
        try:
            layer = layers.new(name=layer_name, do_init=True)
        except TypeError:
            layer = layers.new(name=layer_name)
        try:
            layers.active = layer
        except Exception:
            pass
        try:
            active_index = int(getattr(layers, 'active_index', len(layers) - 1) or 0)
        except Exception:
            active_index = max(0, len(layers) - 1)
        _set_object_custom_target(obj, CHANNEL_PREFIX + str(active_index), _safe_layer_name(layer, layer_name))
        try:
            if ws is not None:
                setattr(ws, 'map_channel_object_name', str(getattr(obj, 'name', '') or ''))
                setattr(ws, 'map_channel_new_name', base_name)
                setattr(ws, 'map_channel_copy_destination', COPY_TARGET_IDENTIFIER)
                sync_workspace_to_map_channel_object(ctx, ws, obj, apply=False)
                _guarded_set_workspace_target_channel(ws, active_index, _safe_layer_name(layer, layer_name))
        except Exception:
            pass
        _tag_uv_channel_redraw(ctx)
        return True, _safe_layer_name(layer, layer_name), active_index
    except Exception as exc:
        return False, str(exc), None
    finally:
        if toggled and old_mode == 'EDIT':
            _set_mode_for_object(obj, 'EDIT')


def remove_map_channel(context: Any, value: Any = None, obj: Any = None) -> tuple[bool, str, int | None]:
    ctx = context or bpy.context
    ws = _workspace(ctx)
    if obj is None:
        obj = ensure_map_channel_object_selection(ctx, ws)
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return False, _tx(ctx, 'No mesh object is selected in the map-channel object list.', 'マップチャンネルのオブジェクトリストでメッシュオブジェクトが選択されていません。'), None
    layers = uv_layers(obj)
    if layers is None:
        return False, _tx(ctx, 'The selected object has no UV map container.', '選択オブジェクトにUVマップコンテナがありません。'), None
    old_mode = _object_mode(obj)
    toggled = False
    try:
        if old_mode == 'EDIT':
            toggled = _set_mode_for_object(obj, 'OBJECT')
        layers = uv_layers(obj)
        try:
            count = len(layers)
        except Exception:
            count = 0
        if count <= 0:
            return False, _tx(ctx, 'No UV map channel exists.', 'UVマップチャンネルがありません。'), None
        if value is None:
            value = _target_value_for_object(ctx, ws, obj)
        index = _resolve_channel_identifier(ctx, ws, obj, value, create=False)
        if index is None:
            return False, _tx(ctx, 'No removable UV map channel was found.', '削除できるUVマップチャンネルが見つかりません。'), None
        index = max(0, min(int(index), count - 1))
        layer = layers[index]
        removed_name = _safe_layer_name(layer, f'UVMap.{index + 1:03d}')
        layers.remove(layer)
        try:
            new_count = len(layers)
        except Exception:
            new_count = 0
        new_index = None
        if new_count > 0:
            new_index = max(0, min(index, new_count - 1))
            try:
                layers.active_index = new_index
            except Exception:
                pass
            new_name = _safe_layer_name(layers[new_index], '')
            _set_object_custom_target(obj, CHANNEL_PREFIX + str(new_index), new_name)
            try:
                _guarded_set_workspace_target_channel(ws, new_index, new_name)
            except Exception:
                pass
        else:
            _set_object_custom_target(obj, ACTIVE_IDENTIFIER, '')
            try:
                if ws is not None:
                    setattr(ws, 'unwrap_map_channel', ACTIVE_IDENTIFIER)
                    setattr(ws, 'unwrap_map_channel_name', '')
            except Exception:
                pass
        try:
            if ws is not None:
                setattr(ws, 'map_channel_object_name', str(getattr(obj, 'name', '') or ''))
                sync_workspace_to_map_channel_object(ctx, ws, obj, apply=False)
        except Exception:
            pass
        _tag_uv_channel_redraw(ctx)
        return True, removed_name, new_index
    except Exception as exc:
        return False, str(exc), None
    finally:
        if toggled and old_mode == 'EDIT':
            _set_mode_for_object(obj, 'EDIT')


def reorder_map_channel(context: Any, direction: int = -1, obj: Any = None) -> tuple[bool, str, tuple[int, int] | None]:
    ctx = context or bpy.context
    ws = _workspace(ctx)
    if obj is None:
        obj = ensure_map_channel_object_selection(ctx, ws)
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return False, _tx(ctx, 'No mesh object is selected in the map-channel object list.', 'マップチャンネルのオブジェクトリストでメッシュオブジェクトが選択されていません。'), None
    layers = uv_layers(obj)
    if layers is None:
        return False, _tx(ctx, 'The selected object has no UV map container.', '選択オブジェクトにUVマップコンテナがありません。'), None
    try:
        count = len(layers)
    except Exception:
        count = 0
    if count <= 1:
        return False, _tx(ctx, 'At least two UV map channels are required for reordering.', '並び替えには2つ以上のUVマップチャンネルが必要です。'), None
    step = -1 if int(direction or 0) < 0 else 1
    index = selected_index(ctx, ws, obj, create=False)
    if index is None:
        return False, _tx(ctx, 'No UV map channel is selected for reordering.', '並び替えるUVマップチャンネルが選択されていません。'), None
    index = max(0, min(int(index), count - 1))
    new_index = index + step
    if new_index < 0:
        return False, _tx(ctx, 'The selected UV map channel is already at the top.', '選択中のUVマップチャンネルはすでに先頭です。'), None
    if new_index >= count:
        return False, _tx(ctx, 'The selected UV map channel is already at the bottom.', '選択中のUVマップチャンネルはすでに末尾です。'), None
    old_mode = _object_mode(obj)
    toggled = False
    try:
        if old_mode == 'EDIT':
            toggled = _set_mode_for_object(obj, 'OBJECT')
        layers = uv_layers(obj)
        snapshots = [_snapshot_uv_layer(layer, idx) for idx, layer in enumerate(layers)]
        moved_name = str(snapshots[index].get('name') or f'UVMap.{index + 1:03d}')
        snapshots[index], snapshots[new_index] = snapshots[new_index], snapshots[index]
        created = _rebuild_uv_layers_in_order(obj, snapshots)
        if not created or len(created) != count:
            return False, _tx(ctx, 'UV map channels could not be rebuilt for reordering.', '並び替え用にUVマップチャンネルを再構築できませんでした。'), None
        layers = uv_layers(obj)
        try:
            layers.active_index = new_index
        except Exception:
            pass
        new_name = _safe_layer_name(layers[new_index], moved_name)
        _set_object_custom_target(obj, CHANNEL_PREFIX + str(new_index), new_name)
        try:
            if ws is not None:
                setattr(ws, 'map_channel_object_name', str(getattr(obj, 'name', '') or ''))
                sync_workspace_to_map_channel_object(ctx, ws, obj, apply=False)
                _guarded_set_workspace_target_channel(ws, new_index, new_name)
        except Exception:
            pass
        try:
            data = getattr(obj, 'data', None)
            if data is not None and hasattr(data, 'update'):
                data.update()
        except Exception:
            pass
        _tag_uv_channel_redraw(ctx)
        return True, moved_name, (index, new_index)
    except Exception as exc:
        return False, str(exc), None
    finally:
        if toggled and old_mode == 'EDIT':
            _set_mode_for_object(obj, 'EDIT')


def copy_map_channel(context: Any, source_value: Any = None, destination_value: Any = None, obj: Any = None) -> tuple[bool, str, tuple[int, int] | None]:
    ctx = context or bpy.context
    ws = _workspace(ctx)
    if obj is None:
        obj = ensure_map_channel_object_selection(ctx, ws)
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return False, _tx(ctx, 'No mesh object is selected in the map-channel object list.', 'マップチャンネルのオブジェクトリストでメッシュオブジェクトが選択されていません。'), None
    layers = uv_layers(obj)
    if layers is None:
        return False, _tx(ctx, 'The selected object has no UV map container.', '選択オブジェクトにUVマップコンテナがありません。'), None
    try:
        if len(layers) <= 0:
            return False, _tx(ctx, 'No UV map channel exists.', 'UVマップチャンネルがありません。'), None
    except Exception:
        return False, _tx(ctx, 'No UV map channel exists.', 'UVマップチャンネルがありません。'), None
    if source_value is None:
        try:
            source_value = getattr(ws, 'map_channel_copy_source', ACTIVE_IDENTIFIER) if ws is not None else ACTIVE_IDENTIFIER
        except Exception:
            source_value = ACTIVE_IDENTIFIER
    if destination_value is None:
        destination_value = _target_value_for_object(ctx, ws, obj)
    src_index = _resolve_channel_identifier(ctx, ws, obj, source_value, create=False)
    dst_index = _resolve_channel_identifier(ctx, ws, obj, destination_value, create=False)
    if src_index is None or dst_index is None:
        return False, _tx(ctx, 'Copy source or unwrap map channel could not be resolved.', 'コピー元または展開使用マップチャンネルを解決できません。'), None
    if int(src_index) == int(dst_index):
        return False, _tx(ctx, 'Copy source and unwrap map channel are the same UV map channel.', 'コピー元と展開使用マップチャンネルが同じUVマップチャンネルです。'), (src_index, dst_index)
    old_mode = _object_mode(obj)
    toggled = False
    try:
        if old_mode == 'EDIT':
            toggled = _set_mode_for_object(obj, 'OBJECT')
        layers = uv_layers(obj)
        src_layer = layers[int(src_index)]
        dst_layer = layers[int(dst_index)]
        for src, dst in zip(getattr(src_layer, 'data', ()), getattr(dst_layer, 'data', ())):
            _copy_loop_uv_attrs(src, dst)
        try:
            obj.data.update()
        except Exception:
            pass
        try:
            layers.active_index = int(dst_index)
        except Exception:
            pass
        dst_name = _safe_layer_name(layers[int(dst_index)], f'UVMap.{int(dst_index) + 1:03d}')
        _set_object_custom_target(obj, CHANNEL_PREFIX + str(int(dst_index)), dst_name)
        try:
            _guarded_set_workspace_target_channel(ws, int(dst_index), dst_name)
        except Exception:
            pass
        src_name = _safe_layer_name(layers[int(src_index)], f'UVMap.{int(src_index) + 1:03d}')
        return True, f'{src_name} -> {dst_name}', (int(src_index), int(dst_index))
    except Exception as exc:
        return False, str(exc), None
    finally:
        if toggled and old_mode == 'EDIT':
            _set_mode_for_object(obj, 'EDIT')


class SMARTUVSUITE_OT_map_channel_object_select(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.map_channel_object_select'
    bl_label = 'Map Channel Object Select'
    bl_description = 'Select the object row whose UV map channels are edited by the map-channel controls.'
    bl_options = set()

    object_name: bpy.props.StringProperty(name='Object Name', default='')

    @classmethod
    def description(cls, context, properties):
        name = ''
        try:
            name = str(getattr(properties, 'object_name', '') or '')
        except Exception:
            name = ''
        return _tx(
            context,
            f'Function: selects "{name}" in the map-channel object list. The controls below the list edit only this object\'s unwrap map channel, name, add/remove, and order. How to use: click an object row, then use the map-channel controls shown below the list.',
            f'機能: マップチャンネルのオブジェクトリストで「{name}」を選択します。リスト下の展開使用マップチャンネル、名称変更、追加、削除、移動はこのオブジェクトだけを編集します。使い方: オブジェクト行をクリックしてから、リスト下のマップチャンネル操作を実行します。',
        )

    def execute(self, context):
        ws = _workspace(context)
        name = str(getattr(self, 'object_name', '') or '')
        if ws is not None:
            try:
                setattr(ws, 'map_channel_object_name', name)
            except Exception:
                pass
        obj = map_channel_object_from_context(context, ws, fallback=True)
        if obj is None:
            self.report({'WARNING'}, _tx(context, 'No mesh object is selected.', 'メッシュオブジェクトが選択されていません。'))
            return {'CANCELLED'}
        sync_workspace_to_map_channel_object(context, ws, obj, apply=True)
        return {'FINISHED'}


class SMARTUVSUITE_OT_map_channel_rename(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.map_channel_rename'
    bl_label = 'Map Channel Rename'
    bl_description = 'Rename the unwrap map channel selected on the object selected in the object list.'
    bl_options = {'UNDO'}

    name: bpy.props.StringProperty(
        name='Channel Name',
        description='Name to assign to the unwrap map channel selected on the object selected in the map-channel object list.',
        default='',
    )

    @classmethod
    def description(cls, context, properties):
        del properties
        return _tx(
            context,
            'Function: renames the unwrap map channel selected on the object selected in the object list. How to use: click Channel Name Rename, enter the new UV map name in the popup, then confirm. Only the listed object currently selected in the map-channel list is changed; other selected objects are not renamed.',
            '機能: オブジェクトリストで選択中のオブジェクトにある、展開使用マップチャンネルの名前を変更します。使い方: 「チャンネル名変更」を押し、表示されたポップアップで新しいUVマップ名を入力して確定します。変更されるのはマップチャンネルリストで選択中のオブジェクトだけで、他の選択オブジェクトの名前は変更しません。',
        )

    def invoke(self, context, event):
        del event
        ws = _workspace(context)
        obj = ensure_map_channel_object_selection(context, ws)
        current = ''
        try:
            layers = uv_layers(obj)
            idx = selected_index(context, ws, obj, create=False)
            if layers is not None and idx is not None and 0 <= int(idx) < len(layers):
                current = _safe_layer_name(layers[int(idx)], '')
        except Exception:
            current = ''
        self.name = current or DEFAULT_UV_NAME
        try:
            return context.window_manager.invoke_props_dialog(self, width=360)
        except Exception:
            return self.execute(context)

    def draw(self, context):
        try:
            self.layout.prop(self, 'name', text=_tx(context, 'Channel Name', 'チャンネル名'), translate=False)
        except Exception:
            pass

    def execute(self, context):
        ok, message, index = rename_map_channel(context, getattr(self, 'name', '') or DEFAULT_UV_NAME)
        if not ok:
            self.report({'WARNING'}, str(message))
            return {'CANCELLED'}
        self.report({'INFO'}, _tx(context, f'Renamed UV map channel: {message}', f'UVマップチャンネル名を変更しました: {message}'))
        return {'FINISHED'}


# Popup support for the existing Add operator.  The class itself is preserved so
# existing operator identifiers and shortcuts remain compatible.
try:
    _ann = getattr(SMARTUVSUITE_OT_map_channel_add, '__annotations__', None)
    if _ann is None:
        _ann = {}
        setattr(SMARTUVSUITE_OT_map_channel_add, '__annotations__', _ann)
    if 'name' not in _ann:
        _ann['name'] = bpy.props.StringProperty(
            name='Map Name',
            description='Name for the new UV map channel created on the object selected in the map-channel object list.',
            default='',
        )
except Exception:
    pass


def _map_channel_add_description(cls, context, properties):
    del cls, properties
    return _tx(
        context,
        'Function: adds a new UV map channel to the object selected in the object list and makes the new channel that object\'s unwrap/edit target. How to use: press Add, enter the new map name in the popup, then confirm. Other selected objects are not changed.',
        '機能: オブジェクトリストで選択中のオブジェクトに新しいUVマップチャンネルを追加し、その新規チャンネルをそのオブジェクトの展開/編集対象にします。使い方: 「追加」を押し、表示されたポップアップで新しいマップ名を入力して確定します。他の選択オブジェクトは変更しません。',
    )


def _map_channel_add_invoke(self, context, event):
    del event
    try:
        ws = _workspace(context)
        self.name = str(getattr(ws, 'map_channel_new_name', '') or DEFAULT_UV_NAME) if ws is not None else DEFAULT_UV_NAME
    except Exception:
        self.name = DEFAULT_UV_NAME
    try:
        return context.window_manager.invoke_props_dialog(self, width=360)
    except Exception:
        return self.execute(context)


def _map_channel_add_draw(self, context):
    try:
        self.layout.prop(self, 'name', text=_tx(context, 'Map Name', 'マップ名'), translate=False)
    except Exception:
        pass


def _map_channel_add_execute(self, context):
    ok, message, index = add_map_channel(context, getattr(self, 'name', '') or '')
    if not ok:
        self.report({'WARNING'}, str(message))
        return {'CANCELLED'}
    self.report({'INFO'}, _tx(context, f'Added UV map channel: {message}', f'UVマップチャンネルを追加しました: {message}'))
    return {'FINISHED'}


try:
    SMARTUVSUITE_OT_map_channel_add.description = classmethod(_map_channel_add_description)
    SMARTUVSUITE_OT_map_channel_add.invoke = _map_channel_add_invoke
    SMARTUVSUITE_OT_map_channel_add.draw = _map_channel_add_draw
    SMARTUVSUITE_OT_map_channel_add.execute = _map_channel_add_execute
except Exception:
    pass

# Replace class tuple for registration.  Existing classes remain, with two new
# list-specific operators added.
_CLASSES = (
    SMARTUVSUITE_OT_map_channel_object_select,
    SMARTUVSUITE_OT_map_channel_select,
    SMARTUVSUITE_OT_map_channel_rename,
    SMARTUVSUITE_OT_map_channel_add,
    SMARTUVSUITE_OT_map_channel_remove,
    SMARTUVSUITE_OT_map_channel_move,
    SMARTUVSUITE_OT_map_channel_copy,
)


def describe_active_channels(context: Any, ws: Any = None) -> dict[str, Any]:
    ctx = context or bpy.context
    if ws is None:
        ws = _workspace(ctx)
    obj = map_channel_object_from_context(ctx, ws)
    rows = channel_rows(ctx, ws, obj)
    try:
        layers = uv_layers(obj)
        active_index = int(getattr(layers, 'active_index', 0) or 0) if layers is not None else -1
    except Exception:
        active_index = -1
    return {
        'object': str(getattr(obj, 'name', '') or '') if obj is not None else '',
        'active_index': active_index,
        'objects': [
            {
                'name': row.get('object_name', ''),
                'selected': bool(row.get('selected', False)),
                'target_index': int(row.get('target_index', -1)),
                'target_name': str(row.get('target_name', '') or ''),
            }
            for row in map_channel_object_rows(ctx, ws)
        ],
        'channels': [
            {
                'index': index,
                'name': name,
                'active': bool(is_active),
                'selected': bool(is_target),
            }
            for index, name, is_active, is_target in rows
        ],
    }

# -----------------------------------------------------------------------------
# Smart UV Suite 1.8.137 - checked multi-object map-channel unification
# -----------------------------------------------------------------------------
# Adds checkbox-like row toggles to the multi-object map-channel list and a
# command that makes every checked object's unwrap target use the same real UV
# layer index and map-channel name as the currently list-selected object.  UV
# coordinates are not copied; the target object's own unwrap channel data is
# preserved by moving that layer to the requested index before renaming it.
OBJECT_UNIFY_CHECK_PROP = 'smart_uv_suite_map_channel_unify_checked'


def _map_channel_unify_checked(obj: Any) -> bool:
    try:
        return bool(obj.get(OBJECT_UNIFY_CHECK_PROP, False))
    except Exception:
        return False


def _set_map_channel_unify_checked(obj: Any, state: bool) -> None:
    if obj is None:
        return
    try:
        obj[OBJECT_UNIFY_CHECK_PROP] = bool(state)
    except Exception:
        pass


def checked_map_channel_objects(context: Any, ws: Any = None) -> list[Any]:
    ctx = context or bpy.context
    result: list[Any] = []
    seen: set[int] = set()
    for obj in selected_mesh_objects_for_map_channels(ctx):
        try:
            if obj is None or getattr(obj, 'type', None) != 'MESH':
                continue
            if not _map_channel_unify_checked(obj):
                continue
            key = id(obj)
            if key in seen:
                continue
            seen.add(key)
            result.append(obj)
        except Exception:
            pass
    return result


_SUS_18128_BASE_MAP_CHANNEL_OBJECT_ROWS = map_channel_object_rows


def map_channel_object_rows(context: Any, ws: Any = None) -> list[dict[str, Any]]:
    rows = []
    try:
        rows = list(_SUS_18128_BASE_MAP_CHANNEL_OBJECT_ROWS(context, ws) or [])
    except Exception:
        rows = []
    for row in rows:
        try:
            obj = row.get('object')
            row['checked'] = _map_channel_unify_checked(obj)
        except Exception:
            row['checked'] = False
    return rows


def _find_selected_mesh_object_by_name(context: Any, name: str) -> Any:
    target_name = str(name or '')
    if not target_name:
        return None
    for obj in selected_mesh_objects_for_map_channels(context or bpy.context):
        try:
            if str(getattr(obj, 'name', '') or '') == target_name:
                return obj
        except Exception:
            pass
    return None


def _ensure_uv_layer_count(layers: Any, count: int) -> bool:
    try:
        wanted = max(0, int(count))
    except Exception:
        wanted = 0
    if layers is None:
        return False
    try:
        while len(layers) < wanted:
            try:
                layers.new(name=_unique_uv_name(layers, DEFAULT_UV_NAME), do_init=True)
            except TypeError:
                layers.new(name=_unique_uv_name(layers, DEFAULT_UV_NAME))
        return len(layers) >= wanted
    except Exception:
        return False


def _free_exact_uv_layer_name(layers: Any, target_index: int, desired_name: str) -> None:
    name = str(desired_name or DEFAULT_UV_NAME).strip() or DEFAULT_UV_NAME
    try:
        for index, layer in enumerate(layers):
            if int(index) == int(target_index):
                continue
            try:
                if str(getattr(layer, 'name', '') or '') == name:
                    layer.name = _unique_uv_name(layers, f'{name}_old', active_layer=layer)
            except Exception:
                pass
    except Exception:
        pass


def _move_current_target_to_index(obj: Any, ctx: Any, ws: Any, target_index: int) -> tuple[bool, str | None]:
    layers = uv_layers(obj)
    if layers is None:
        return False, _tx(ctx, 'The object has no UV map container.', '対象オブジェクトにUVマップコンテナがありません。')
    if not _ensure_uv_layer_count(layers, int(target_index) + 1):
        return False, _tx(ctx, 'Could not create the required UV map channel index.', '必要なUVマップチャンネルのインデックスを作成できませんでした。')
    current_index = selected_index(ctx, ws, obj, create=True)
    try:
        layers = uv_layers(obj)
        count = len(layers) if layers is not None else 0
    except Exception:
        count = 0
    if layers is None or count <= 0:
        return False, _tx(ctx, 'No UV map channel exists.', 'UVマップチャンネルがありません。')
    if current_index is None:
        try:
            current_index = int(getattr(layers, 'active_index', 0) or 0)
        except Exception:
            current_index = 0
    current_index = max(0, min(int(current_index), count - 1))
    target_index = max(0, min(int(target_index), count - 1))
    if int(current_index) == int(target_index):
        return True, None
    try:
        snapshots = [_snapshot_uv_layer(layer, idx) for idx, layer in enumerate(layers)]
        moving = snapshots.pop(int(current_index))
        snapshots.insert(int(target_index), moving)
        created = _rebuild_uv_layers_in_order(obj, snapshots)
        if not created or len(created) != len(snapshots):
            return False, _tx(ctx, 'UV map channels could not be rebuilt for unification.', '統一用にUVマップチャンネルを再構築できませんでした。')
    except Exception as exc:
        return False, str(exc)
    return True, None


def _unify_object_map_channel_to_source(context: Any, ws: Any, obj: Any, source_index: int, source_name: str) -> tuple[bool, str]:
    ctx = context or bpy.context
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return False, _tx(ctx, 'Target object is not a mesh.', '対象オブジェクトがメッシュではありません。')
    layers = uv_layers(obj)
    if layers is None:
        return False, _tx(ctx, 'The target object has no UV map container.', '対象オブジェクトにUVマップコンテナがありません。')
    source_index = max(0, int(source_index))
    if not _ensure_uv_layer_count(layers, source_index + 1):
        return False, _tx(ctx, 'Could not create the required UV map channel index.', '必要なUVマップチャンネルのインデックスを作成できませんでした。')
    ok, reason = _move_current_target_to_index(obj, ctx, ws, source_index)
    if not ok:
        return False, reason or ''
    layers = uv_layers(obj)
    if layers is None:
        return False, _tx(ctx, 'The target object has no UV map container.', '対象オブジェクトにUVマップコンテナがありません。')
    try:
        if len(layers) <= source_index:
            return False, _tx(ctx, 'The required UV map channel index could not be resolved.', '必要なUVマップチャンネルのインデックスを解決できませんでした。')
    except Exception:
        return False, _tx(ctx, 'The required UV map channel index could not be resolved.', '必要なUVマップチャンネルのインデックスを解決できませんでした。')
    name = str(source_name or DEFAULT_UV_NAME).strip() or DEFAULT_UV_NAME
    try:
        _free_exact_uv_layer_name(layers, source_index, name)
        layers[int(source_index)].name = name
    except Exception as exc:
        return False, str(exc)
    try:
        layers.active_index = int(source_index)
    except Exception:
        pass
    _set_object_custom_target(obj, CHANNEL_PREFIX + str(int(source_index)), name)
    try:
        data = getattr(obj, 'data', None)
        if data is not None and hasattr(data, 'update'):
            data.update()
    except Exception:
        pass
    return True, name


def unify_checked_map_channels(context: Any, ws: Any = None) -> tuple[bool, str, int]:
    ctx = context or bpy.context
    if ws is None:
        ws = _workspace(ctx)
    source_obj = ensure_map_channel_object_selection(ctx, ws)
    if source_obj is None or getattr(source_obj, 'type', None) != 'MESH':
        return False, _tx(ctx, 'No source mesh object is selected in the map-channel object list.', '基準にするメッシュオブジェクトがマップチャンネルリストで選択されていません。'), 0
    source_layers = uv_layers(source_obj)
    if source_layers is None:
        return False, _tx(ctx, 'The source object has no UV map container.', '基準オブジェクトにUVマップコンテナがありません。'), 0
    try:
        if len(source_layers) <= 0:
            return False, _tx(ctx, 'The source object has no UV map channel.', '基準オブジェクトにUVマップチャンネルがありません。'), 0
    except Exception:
        return False, _tx(ctx, 'The source object has no UV map channel.', '基準オブジェクトにUVマップチャンネルがありません。'), 0
    source_index = selected_index(ctx, ws, source_obj, create=False)
    if source_index is None:
        return False, _tx(ctx, 'The source unwrap map channel could not be resolved.', '基準の展開使用マップチャンネルを解決できませんでした。'), 0
    source_index = max(0, min(int(source_index), len(source_layers) - 1))
    source_name = _safe_layer_name(source_layers[source_index], f'UVMap.{source_index + 1:03d}')
    targets = checked_map_channel_objects(ctx, ws)
    if not targets:
        return False, _tx(ctx, 'No object is checked for map-channel unification.', 'マップチャンネル統一対象にチェックされたオブジェクトがありません。'), 0

    old_active = None
    old_mode = ''
    selected_state: dict[int, tuple[Any, bool]] = {}
    try:
        old_active = getattr(ctx, 'active_object', None)
        old_mode = str(getattr(old_active, 'mode', '') or '') if old_active is not None else ''
    except Exception:
        old_active = None
        old_mode = ''
    try:
        for obj in getattr(ctx, 'selected_objects', []) or []:
            selected_state[id(obj)] = (obj, bool(obj.select_get()))
    except Exception:
        selected_state = {}
    toggled = False
    try:
        if old_mode == 'EDIT' and bpy.ops.object.mode_set.poll():
            bpy.ops.object.mode_set(mode='OBJECT')
            toggled = True
    except Exception:
        toggled = False

    changed = 0
    errors: list[str] = []
    try:
        for obj in targets:
            ok, message = _unify_object_map_channel_to_source(ctx, ws, obj, source_index, source_name)
            if ok:
                changed += 1
            else:
                try:
                    errors.append(f"{getattr(obj, 'name', '')}: {message}")
                except Exception:
                    errors.append(str(message))
        try:
            sync_workspace_to_map_channel_object(ctx, ws, source_obj, apply=False)
            _guarded_set_workspace_target_channel(ws, source_index, source_name)
        except Exception:
            pass
        _tag_uv_channel_redraw(ctx)
    finally:
        try:
            for obj, selected in selected_state.values():
                obj.select_set(bool(selected))
        except Exception:
            pass
        try:
            if old_active is not None:
                ctx.view_layer.objects.active = old_active
        except Exception:
            pass
        if toggled and old_mode == 'EDIT':
            try:
                if bpy.ops.object.mode_set.poll():
                    bpy.ops.object.mode_set(mode='EDIT')
            except Exception:
                pass
    if changed <= 0:
        return False, '; '.join(errors) if errors else _tx(ctx, 'No checked object could be unified.', 'チェック対象を統一できませんでした。'), 0
    if errors:
        return True, _tx(ctx, f'Unified {changed} object(s). Some objects failed: ' + '; '.join(errors), f'{changed}個のオブジェクトを統一しました。一部失敗: ' + '; '.join(errors)), changed
    return True, _tx(ctx, f'Unified {changed} checked object(s) to index {source_index}: {source_name}', f'チェック対象 {changed}個をインデックス {source_index}: {source_name} に統一しました。'), changed


class SMARTUVSUITE_OT_map_channel_toggle_unify_check(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.map_channel_toggle_unify_check'
    bl_label = 'Map Channel Unify Check'
    bl_description = 'Toggle whether this object is included when unifying map-channel index and name.'
    bl_options = set()

    object_name: bpy.props.StringProperty(name='Object Name', default='')

    @classmethod
    def description(cls, context, properties):
        try:
            name = str(getattr(properties, 'object_name', '') or '')
        except Exception:
            name = ''
        return _tx(
            context,
            f'Function: toggles whether "{name}" is included in map-channel unification. How to use: turn this checkbox on for each object that should receive the list-selected object\'s unwrap map-channel index and map-channel name, then press Unify Checked.',
            f'機能: 「{name}」をマップチャンネル統一の対象に含めるか切り替えます。使い方: リスト選択中オブジェクトの展開使用マップチャンネルのインデックス番号とマップチャンネル名へ揃えたいオブジェクトにチェックを入れ、「チェック対象を統一」を実行します。',
        )

    def execute(self, context):
        obj = _find_selected_mesh_object_by_name(context, getattr(self, 'object_name', '') or '')
        if obj is None:
            self.report({'WARNING'}, _tx(context, 'The object was not found in the selected mesh-object list.', '選択中メッシュオブジェクトリスト内に対象オブジェクトが見つかりません。'))
            return {'CANCELLED'}
        _set_map_channel_unify_checked(obj, not _map_channel_unify_checked(obj))
        _tag_uv_channel_redraw(context)
        return {'FINISHED'}


class SMARTUVSUITE_OT_map_channel_unify_checked(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.map_channel_unify_checked'
    bl_label = 'Unify Checked Map Channels'
    bl_description = 'Unify the unwrap map-channel index and map-channel name of checked objects to the object selected in the map-channel list.'
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        del properties
        return _tx(
            context,
            'Function: uses the object currently selected in the map-channel object list as the source, then sets every checked selected mesh object to the same unwrap map-channel index and the same UV map-channel name. UV coordinates are not copied; each target keeps its own UV data by moving its current unwrap target to the source index before renaming it. How to use: select the source object row, check the objects to match, then press Unify Checked.',
            '機能: マップチャンネルリストで選択中のオブジェクトを基準にし、チェック済みの選択メッシュオブジェクトの展開使用マップチャンネルを、同じインデックス番号と同じUVマップチャンネル名へ統一します。UV座標はコピーせず、各対象オブジェクト自身の展開対象UVデータを基準インデックスへ移動してから名称を揃えます。使い方: 基準にしたいオブジェクト行を選択し、揃えたいオブジェクトにチェックを入れてから「チェック対象を統一」を押します。',
        )

    def execute(self, context):
        ok, message, changed = unify_checked_map_channels(context)
        if not ok:
            self.report({'WARNING'}, str(message))
            return {'CANCELLED'}
        self.report({'INFO'}, str(message))
        return {'FINISHED'}


_SUS_18128_BASE_REGISTER = _suv_stage_001_register
_SUS_18128_BASE_UNREGISTER = _suv_stage_001_unregister
_SUS_18128_CLASSES = (
    SMARTUVSUITE_OT_map_channel_toggle_unify_check,
    SMARTUVSUITE_OT_map_channel_unify_checked,
)


def register(_base_register=_SUS_18128_BASE_REGISTER) -> None:
    if callable(_base_register):
        _base_register()
    for cls in _SUS_18128_CLASSES:
        try:
            if bool(getattr(cls, 'is_registered', False)) or getattr(cls, '__dict__', {}).get('bl_rna') is not None:
                continue
        except Exception:
            pass
        try:
            _suv_resource.register_class(cls)
        except ValueError:
            pass
        except RuntimeError:
            pass
        except Exception:
            pass


def unregister(_base_unregister=_SUS_18128_BASE_UNREGISTER) -> None:
    for cls in reversed(_SUS_18128_CLASSES):
        try:
            _suv_resource.unregister_class(cls)
        except Exception:
            pass
    if callable(_base_unregister):
        _base_unregister()
