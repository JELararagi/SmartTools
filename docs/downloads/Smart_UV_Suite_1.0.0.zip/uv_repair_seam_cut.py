def build_handlers(api):
    def run(context, op):
        if context.mode != 'EDIT_MESH':
            return False
        rows = api._edit_targets(context)
        changed = []
        for row in rows:
            _, bm, _ = row
            edges = {loop.edge for loop in api._selected_edge_loops(context, bm)}
            if api._sync(context):
                edges.update(edge for edge in bm.edges if edge.select and not edge.hide)
            pending = {edge for edge in edges if not edge.seam}
            for edge in pending:
                edge.seam = True
            if pending:
                changed.append(row)
        api._flush(changed)
        return bool(changed)

    return {
        'smart_uv_suite.seam_cut': api.Handler(run, 'Mark selected edges as UV seams.', '選択した辺にUVシームを付けます。'),
        'smart_uv_suite.seam_cut_seam': api.Handler(run, 'Mark selected edges as UV seams.', '選択した辺にUVシームを付けます。'),
    }
