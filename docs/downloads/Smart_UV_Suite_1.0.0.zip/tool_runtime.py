# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import traceback

import bpy

from . import loader, preferences_proxy, ui_runtime

_BOOTSTRAP_OWNER = 'uv_suite'
_BOOTSTRAP_LABEL = 'Smart UV'
_BOOTSTRAP_ICON = 'GROUP_UVS'
_BOOTSTRAP_ORDER = 80
_BOOTSTRAP_ACTIVE = False
_RUNTIME_REGISTERED = False
_RUNTIME_LAST_ERROR = ''


def tool_runtime_is_registered() -> bool:
    return bool(_RUNTIME_REGISTERED)


def tool_runtime_last_error() -> str:
    return str(_RUNTIME_LAST_ERROR or '')


def ensure_bootstrap_host() -> None:
    global _BOOTSTRAP_ACTIVE
    # The tool_runtime is shown by normal bpy.types.Panel registration.  No shared
    # shared bootstrap host is installed.
    _BOOTSTRAP_ACTIVE = False
    return None

def mark_bootstrap_host_removed() -> None:
    global _BOOTSTRAP_ACTIVE
    _BOOTSTRAP_ACTIVE = False



def remove_bootstrap_host() -> None:
    global _BOOTSTRAP_ACTIVE
    _BOOTSTRAP_ACTIVE = False
    return None

def register() -> None:
    global _RUNTIME_REGISTERED, _RUNTIME_LAST_ERROR
    if _RUNTIME_REGISTERED:
        ensure_bootstrap_host()
        return
    _RUNTIME_LAST_ERROR = ''
    try:
        loader.register_all()
        ui_runtime.register()
        ensure_bootstrap_host()
        _RUNTIME_REGISTERED = True
    except Exception as exc:
        _RUNTIME_LAST_ERROR = f'{exc}\n{traceback.format_exc()}'
        try:
            remove_bootstrap_host()
        except Exception:
            pass
        try:
            ui_runtime.unregister()
        except Exception:
            pass
        try:
            loader.unregister_all()
        except Exception:
            pass
        try:
            preferences_proxy.unregister_all()
        except Exception:
            pass
        _RUNTIME_REGISTERED = False
        raise



def open_smart_tools(context=None, reuse_existing: bool = True) -> bool:
    # Compatibility entry point for old buttons. It does not create a host
    # surface; it loads the tool_runtime and redraws the standard UV Suite N-panel.
    del reuse_existing
    register()
    ctx = context or getattr(bpy, 'context', None)
    try:
        from . import navigation_properties
        set_active_owner = getattr(navigation_properties, 'set_active_owner', None)
        if callable(set_active_owner):
            set_active_owner(ctx, _BOOTSTRAP_OWNER)
    except Exception:
        pass
    try:
        for area in getattr(getattr(ctx, 'screen', None), 'areas', ()):
            if str(getattr(area, 'type', '') or '') == 'VIEW_3D':
                area.tag_redraw()
    except Exception:
        pass
    return True

def unregister() -> None:
    global _RUNTIME_REGISTERED
    try:
        remove_bootstrap_host()
    finally:
        try:
            ui_runtime.unregister()
        finally:
            try:
                loader.unregister_all()
            finally:
                preferences_proxy.unregister_all()
    _RUNTIME_REGISTERED = False
