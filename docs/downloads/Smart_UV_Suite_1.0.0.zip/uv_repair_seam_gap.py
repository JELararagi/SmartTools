def build_handlers(api):
    backend = api._run_uv_layout('suv_uv_seam_gap_tools', mode='mode', scope='scope')

    def run(context, op):
        return backend(context, op)

    return {
        'smart_uv_suite.seam_gap_tools': api.Handler(run, 'Select or mark UV border edges with missing seams.', 'シームの付いていないUV境界を選択、またはシームに設定します。'),
    }
