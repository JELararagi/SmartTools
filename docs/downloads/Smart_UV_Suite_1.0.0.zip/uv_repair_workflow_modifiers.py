# SPDX-License-Identifier: GPL-3.0-or-later
"""Operate on the active mesh's viewport modifier switches."""


def build_handlers(api):
    def set_visibility(context, operation):
        mesh = context.active_object
        if mesh is None or mesh.type != "MESH" or not mesh.modifiers:
            return False
        action = (operation.mode or "TOGGLE").strip().upper()
        if action == "TOGGLE":
            show = all(not item.show_viewport for item in mesh.modifiers)
        elif action in ("SHOW", "HIDE"):
            show = action == "SHOW"
        else:
            return False
        for item in mesh.modifiers:
            item.show_viewport = show
        return True

    return {"smart_uv_suite.workflow_modifiers_toggle": api.Handler(
        set_visibility,
        "Show, hide, or toggle all viewport modifiers on the active mesh.",
        "アクティブなメッシュのモディファイアを、ビューポートで一括表示または非表示にします。",
    )}
