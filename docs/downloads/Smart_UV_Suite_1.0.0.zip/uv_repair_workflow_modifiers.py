def _toggle(context, op):
    obj = context.active_object
    if obj is None or obj.type != 'MESH':
        return False
    modifiers = list(obj.modifiers)
    mode = (op.mode or 'TOGGLE').strip().upper()
    if not modifiers or mode not in {'TOGGLE', 'SHOW', 'HIDE'}:
        return False
    visible = mode == 'SHOW' or (mode == 'TOGGLE' and not any(m.show_viewport for m in modifiers))
    for modifier in modifiers:
        modifier.show_viewport = visible
    return True


def build_handlers(api):
    return {
        'smart_uv_suite.workflow_modifiers_toggle': api.Handler(_toggle, 'Toggle viewport modifiers on the active mesh.', 'アクティブメッシュのビューポート用モディファイア表示を切り替えます。'),
    }
