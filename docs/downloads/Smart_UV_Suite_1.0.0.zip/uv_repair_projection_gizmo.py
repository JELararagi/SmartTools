"""Manage the Empty used by Smart UV projection modes."""

import bmesh
import bpy
from mathutils import Matrix, Vector

GIZMO_TAG = "_smart_uv_projection_gizmo"
TARGET_KEY = "_smart_uv_projection_target"


def _target_mesh(context, gizmo):
    active = context.active_object
    if active is not None and active.type == "MESH":
        return active
    if gizmo is not None:
        target = context.scene.objects.get(gizmo.get(TARGET_KEY, ""))
        if target is not None and target.type == "MESH":
            return target
    return next((obj for obj in context.selected_objects if obj.type == "MESH"), None)


def _bounds(context, target, native_bounds):
    if target is None:
        return None
    if target.mode != "EDIT":
        return native_bounds(context, target)

    mesh = bmesh.from_edit_mesh(target.data)
    visible = [vertex for vertex in mesh.verts if not vertex.hide]
    vertices = [vertex for vertex in visible if vertex.select] or visible
    if not vertices:
        return None
    coordinates = [target.matrix_world @ vertex.co for vertex in vertices]
    lower = Vector(tuple(min(co[axis] for co in coordinates) for axis in range(3)))
    upper = Vector(tuple(max(co[axis] for co in coordinates) for axis in range(3)))
    return (lower + upper) * 0.5, Vector(tuple(max(span, 0.0001) for span in upper - lower))


def build_handlers(api):
    # Resolve native helpers after the package and panel handler table are initialized.
    from . import _sus_projection_gizmo_name, _sus_selected_world_bounds_for_gizmo

    def run(context, op):
        action = (op.action or "CREATE").upper()
        name = _sus_projection_gizmo_name(context)
        gizmo = bpy.data.objects.get(name)
        if gizmo is not None:
            if gizmo.type != "EMPTY" or context.scene.objects.get(name) != gizmo:
                api._warn(context, op, "The projection gizmo name is in use by another object.",
                          "投影ギズモ名が別のオブジェクトに使用されています。")
                return False
        else:
            gizmo = next((obj for obj in context.scene.objects
                          if obj.type == "EMPTY" and obj.get(GIZMO_TAG, False)), None)

        if action in {"REMOVE", "SELECT"} and gizmo is None:
            api._warn(context, op, "Projection gizmo was not found.", "投影ギズモが見つかりません。")
            return False
        if action not in {"CREATE", "RESET", "FIT", "REMOVE", "SELECT"}:
            return False

        if action == "REMOVE":
            if not gizmo.is_editable or len(gizmo.users_scene) != 1 or gizmo.children:
                api._warn(context, op, "The projection gizmo is shared, read-only, or has child objects.",
                          "投影ギズモは共有中、読み取り専用、または子オブジェクトを持っています。")
                return False
            bpy.data.objects.remove(gizmo, do_unlink=True)
            return True

        layer = context.view_layer
        if gizmo is not None and (
            layer.objects.get(gizmo.name) != gizmo or not gizmo.visible_get(view_layer=layer) or gizmo.hide_select
            or (action != "SELECT" and not gizmo.is_editable)
        ):
            api._warn(context, op, "The projection gizmo must be visible and selectable in this view layer.",
                      "このビューレイヤーで投影ギズモを表示し、選択可能にしてください。")
            return False

        target = _target_mesh(context, gizmo)
        fit = action in {"RESET", "FIT"}
        bounds = _bounds(context, target, _sus_selected_world_bounds_for_gizmo) if fit else None
        if fit and bounds is None:
            api._warn(context, op, "Select a mesh to fit the projection gizmo.",
                      "投影ギズモを合わせるメッシュを選択してください。")
            return False

        if gizmo is None and not context.collection.is_editable:
            api._warn(context, op, "Choose an editable collection for the projection gizmo.",
                      "投影ギズモを作成できるコレクションを選択してください。")
            return False

        # The Empty must be active in Object Mode for viewport transforms.
        # Read the edit mesh first, then leave existing object selections in place.
        if context.mode != "OBJECT" and bpy.ops.object.mode_set(mode="OBJECT") != {"FINISHED"}:
            return False
        if gizmo is None:
            gizmo = bpy.data.objects.new(name, None)
            context.collection.objects.link(gizmo)
            gizmo.location = context.scene.cursor.location
            layer.update()

        if action != "SELECT":
            gizmo[GIZMO_TAG] = True
            if target is not None:
                gizmo[TARGET_KEY] = target.name
            gizmo.empty_display_type = "CUBE"
            gizmo.show_name = True
            if bounds is not None:
                center, size = bounds
                gizmo.matrix_world = Matrix.Translation(center) @ Matrix.Diagonal((*size, 1.0))

        gizmo.select_set(True, view_layer=layer)
        layer.objects.active = gizmo
        return gizmo.select_get(view_layer=layer) and layer.objects.active == gizmo

    return {
        "smart_uv_suite.projection_gizmo_action": api.Handler(
            run,
            "Create, select, fit, or remove the 3D Empty used by Smart UV projection. "
            "Fit uses the active mesh or its Edit Mode selection. Transform the Empty in the 3D View before projecting.",
            "Smart UV 投影用の Empty を作成・選択・フィット・削除します。"
            "フィットはアクティブメッシュまたは編集モードの選択範囲を使います。投影前に 3D ビューで Empty を変形できます。",
        ),
    }
