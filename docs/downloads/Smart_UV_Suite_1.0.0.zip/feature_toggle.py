# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Always-on feature toggle facade for Smart UV Suite.

No process-global API is replaced here.  Runtime resources are not discovered by
monkeypatching; features must explicitly opt in through the finite public API.
"""
from __future__ import annotations

import json
import os
import re
from contextlib import AbstractContextManager, contextmanager
from pathlib import Path
from typing import Any, Callable

import bpy

try:
    from . import text_translation as _text_translation
except Exception:
    _text_translation = None

_SUITE_KEY = ''
_SUITE_LABEL = ''
_CATEGORY = ''
_OPERATOR_ID = ''
_REGISTERED_CLASSES: list[type] = []
_FEATURES: dict[str, dict[str, dict[str, Any]]] = {}
_STATE_CACHE: dict[str, dict[str, bool]] | None = None

_KIND_ORDER = ('handlers', 'timers', 'msgbus', 'keymaps', 'draw_handlers')
_KIND_INFO = {
    'handlers': ('Application Handlers', 'アプリケーションハンドラー'),
    'timers': ('Background Timers', 'バックグラウンドタイマー'),
    'msgbus': ('RNA Message Bus Watchers', 'RNAメッセージバス監視'),
    'keymaps': ('Hotkeys', 'ホットキー'),
    'draw_handlers': ('Viewport / Editor Draw', 'ビューポート / エディター描画'),
}


def _clean_identifier(value: str, fallback: str = 'smart_tools') -> str:
    text = str(value or '').strip().split('.')[-1]
    text = re.sub(r'[^0-9A-Za-z_]+', '_', text)
    text = re.sub(r'_+', '_', text).strip('_').lower()
    return text or fallback


def _title_from_key(value: str) -> str:
    text = str(value or '').strip().replace('_suite', '').replace('_', ' ')
    return ' '.join(part[:1].upper() + part[1:] for part in text.split()) or 'Smart Tools'


def configure(*, suite_key: str | None = None, suite_label: str | None = None, category: str | None = None) -> None:
    global _SUITE_KEY, _SUITE_LABEL, _CATEGORY, _OPERATOR_ID
    if suite_key or not _SUITE_KEY:
        _SUITE_KEY = _clean_identifier(suite_key or (__package__ or 'smart_uv_suite').split('.')[-1])
    if suite_label or not _SUITE_LABEL:
        _SUITE_LABEL = str(suite_label or _title_from_key(_SUITE_KEY)).strip()
    if category or not _CATEGORY:
        _CATEGORY = str(category or _SUITE_LABEL).strip()
    _OPERATOR_ID = f'{_SUITE_KEY}.toggle_persistent_feature'


def _is_ja(context=None) -> bool:
    try:
        if _text_translation is not None and bool(_text_translation.is_japanese(context)):
            return True
    except Exception:
        pass
    try:
        prefs = getattr(getattr(context or bpy.context, 'preferences', None), 'view', None)
        lang = str(getattr(prefs, 'language', '') or '').lower()
    except Exception:
        lang = ''
    return lang.startswith('ja') or 'japanese' in lang


def _t(context, en: str, ja: str) -> str:
    return str(ja if _is_ja(context) else en)


def _legacy_settings_path() -> Path | None:
    # Read-only legacy location; the switches are now kept in Smart_UV_Suite.json (store "feature_toggles").
    configure()
    try:
        from . import storage as _storage
        base = Path(_storage.runtime_dir('state', create=False))
    except Exception:
        return None
    return base / f'{_SUITE_KEY}_persistent_feature_toggles.json'


def _load_state() -> dict[str, dict[str, bool]]:
    """Lifecycle-only strict load. Draw paths use the already loaded cache."""
    global _STATE_CACHE
    if _STATE_CACHE is not None:
        return _STATE_CACHE
    data: dict[str, dict[str, bool]] = {}
    path = _legacy_settings_path()
    migrate = False
    raw_store = None
    try:
        from . import npanel_persistence as _store
        raw_store = _store.get_store('feature_toggles')
    except Exception:
        _store = None
    if raw_store is not None or (path is not None and path.exists()):
        try:
            def _pairs(pairs):
                out = {}
                for key, value in pairs:
                    if key in out:
                        raise ValueError(f'duplicate member: {key}')
                    out[key] = value
                return out
            if raw_store is not None:
                raw = raw_store
            else:
                raw = json.loads(
                    path.read_text(encoding='utf-8'),
                    object_pairs_hook=_pairs,
                    parse_constant=lambda value: (_ for _ in ()).throw(ValueError(f'invalid constant: {value}')),
                )
                migrate = True
            if not isinstance(raw, dict):
                raise TypeError('feature state root must be an object')
            for alias, values in raw.items():
                if not isinstance(alias, str) or not isinstance(values, dict):
                    raise TypeError('feature state members must be objects')
                unknown = set(values) - set(_KIND_ORDER)
                if unknown:
                    raise ValueError('unknown feature state member: ' + ', '.join(sorted(unknown)))
                if any(not isinstance(v, bool) for v in values.values()):
                    raise TypeError('feature state values must be boolean')
                data[alias] = dict(values)
            if migrate and _store is not None and data:
                _store.set_store('feature_toggles', data)
        except Exception:
            data = {}
    _STATE_CACHE = data
    return data


def _atomic_write_json(path: Path, payload: dict[str, Any]) -> None:
    import tempfile
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + '\n'
    fd, temp_name = tempfile.mkstemp(prefix='.suv-', suffix='.tmp', dir=str(path.parent), text=True)
    temp = Path(temp_name)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8', newline='\n') as fh:
            fh.write(text)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(str(temp), str(path))
        if path.read_text(encoding='utf-8') != text:
            raise OSError('feature state readback mismatch')
        json.loads(path.read_text(encoding='utf-8'), parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
        try:
            dfd = os.open(str(path.parent), getattr(os, 'O_DIRECTORY', 0) | os.O_RDONLY)
            try:
                os.fsync(dfd)
            finally:
                os.close(dfd)
        except Exception:
            pass
    finally:
        try:
            if temp.exists():
                temp.unlink()
        except Exception:
            pass


def _save_state() -> None:
    try:
        from . import npanel_persistence as _store
        _store.set_store('feature_toggles', _load_state())
    except Exception:
        pass


def is_feature_enabled(alias: str, feature_key: str) -> bool:
    state = _STATE_CACHE if isinstance(_STATE_CACHE, dict) else {}
    return bool(state.get(str(alias or ''), {}).get(str(feature_key or ''), False))


def set_feature_enabled(alias: str, feature_key: str, enabled: bool) -> bool:
    alias = str(alias or '').strip(); feature_key = str(feature_key or '').strip()
    if not alias or feature_key not in _KIND_ORDER:
        return False
    state = _load_state()
    state.setdefault(alias, {})[feature_key] = bool(enabled)
    _save_state()
    feature = _FEATURES.get(alias, {}).get(feature_key)
    if feature is not None:
        feature['enabled'] = bool(enabled)
    # Explicit state-change events may activate their own resources. Draw/poll
    # never enter this path.
    try:
        action = (feature or {}).get('enable_action' if enabled else 'disable_action')
        if callable(action):
            action()
    except Exception:
        return False
    try:
        screen = getattr(getattr(bpy, 'context', None), 'screen', None)
        for area in getattr(screen, 'areas', ()) or ():
            area.tag_redraw()
    except Exception:
        pass
    return True


def _feature_record(alias: str, tool_label: str, feature_key: str) -> dict[str, Any]:
    alias = str(alias or '').strip(); feature_key = str(feature_key or '').strip()
    if feature_key not in _KIND_ORDER:
        feature_key = 'handlers'
    en, ja = _KIND_INFO.get(feature_key, (feature_key, feature_key))
    features = _FEATURES.setdefault(alias, {})
    rec = features.get(feature_key)
    if rec is None:
        rec = {'alias': alias, 'tool_label': str(tool_label or alias), 'key': feature_key, 'label_en': en, 'label_ja': ja,
               'description_en': f'Enable the explicitly owned {en.lower()} resource for this Smart UV feature.',
               'description_ja': f'このSmart UV機能で明示所有された「{ja}」リソースを有効にします。',
               'enabled': is_feature_enabled(alias, feature_key)}
        features[feature_key] = rec
    return rec


def _add_action(alias: str, tool_label: str, feature_key: str, action: dict[str, Any] | None = None) -> dict[str, Any]:
    return _feature_record(alias, tool_label, feature_key)


def feature_entries(alias: str | None = None) -> list[dict[str, Any]]:
    aliases = [str(alias)] if alias else sorted(_FEATURES)
    out: list[dict[str, Any]] = []
    for name in aliases:
        for key in _KIND_ORDER:
            rec = _FEATURES.get(name, {}).get(key)
            if rec:
                item = dict(rec); item['enabled'] = is_feature_enabled(name, key); out.append(item)
    return out


def all_feature_aliases() -> tuple[str, ...]:
    return tuple(sorted(_FEATURES))


def deactivate_alias(alias: str) -> int:
    count = 0
    for key in tuple(_load_state().get(str(alias or ''), {})):
        if set_feature_enabled(alias, key, False):
            count += 1
    return count


def clear_alias(alias: str) -> None:
    _FEATURES.pop(str(alias or ''), None)
    _load_state().pop(str(alias or ''), None)
    _save_state()


class _RuntimeCapture(AbstractContextManager):
    def __init__(self, alias: str, tool_label: str):
        self.alias = str(alias or '').strip(); self.tool_label = str(tool_label or self.alias).strip()
    def __enter__(self):
        return self
    def __exit__(self, exc_type, exc, tb):
        return False
    def add_action(self, feature_key: str, action: dict[str, Any] | None = None):
        return _add_action(self.alias, self.tool_label, feature_key, action)


def capture_tool_runtime(alias: str, tool_label: str | None = None) -> _RuntimeCapture:
    return _RuntimeCapture(alias, tool_label or alias)


def capture_call(alias: str, tool_label: str, func: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
    with capture_tool_runtime(alias, tool_label):
        return func(*args, **kwargs)


def _operator_description(context, properties) -> str:
    feature = _FEATURES.get(str(getattr(properties, 'alias', '') or ''), {}).get(str(getattr(properties, 'feature_key', '') or ''))
    if feature:
        return _t(context, feature.get('description_en', ''), feature.get('description_ja', ''))
    return _t(context, 'Toggle an explicitly owned Smart UV always-on feature.', 'Smart UVの明示所有された常時起動機能を切り替えます。')


def register_ui(*, suite_key: str | None = None, suite_label: str | None = None, category: str | None = None) -> None:
    configure(suite_key=suite_key, suite_label=suite_label, category=category)
    _load_state()
    if _REGISTERED_CLASSES:
        return
    operator_id = _OPERATOR_ID
    class SMARTTOOLS_OT_toggle_persistent_feature(bpy.types.Operator):
        bl_idname = operator_id
        bl_label = _t(None, 'Toggle Persistent Feature', '常時起動切替')
        bl_description = _t(None, 'Switch an explicitly owned always-on feature on or off.', '明示所有された常時起動機能の有効・無効を切り替えます。')
        alias: bpy.props.StringProperty(default='')
        feature_key: bpy.props.StringProperty(default='')
        enabled: bpy.props.BoolProperty(default=True)
        @classmethod
        def description(cls, context, properties):
            return _operator_description(context, properties)
        def execute(self, context):
            if not set_feature_enabled(getattr(self, 'alias', ''), getattr(self, 'feature_key', ''), bool(getattr(self, 'enabled', True))):
                return {'CANCELLED'}
            return {'FINISHED'}
    SMARTTOOLS_OT_toggle_persistent_feature.__name__ = f"SMARTTOOLS_OT_{_SUITE_KEY.upper()}_TOGGLE_PERSISTENT_FEATURE"
    SMARTTOOLS_OT_toggle_persistent_feature.__qualname__ = SMARTTOOLS_OT_toggle_persistent_feature.__name__
    SMARTTOOLS_OT_toggle_persistent_feature.__module__ = __name__
    try:
        from . import ownership_runtime_18168 as _ownership
        if _ownership.register_class(SMARTTOOLS_OT_toggle_persistent_feature):
            _REGISTERED_CLASSES.append(SMARTTOOLS_OT_toggle_persistent_feature)
    except Exception:
        pass


def draw_inline_toggles(layout, context, alias: str, *, compact: bool = True) -> bool:
    configure()
    entries = feature_entries(alias)
    if not entries:
        return False
    try:
        col = layout.column(align=True)
        for item in entries:
            key = str(item.get('key') or '')
            enabled = bool(item.get('enabled'))
            row = col.row(align=True)
            row.label(text=_t(context, item.get('label_en', key), item.get('label_ja', key)))
            op = row.operator(_OPERATOR_ID, text=_t(context, 'ON', '有効'), depress=enabled)
            op.alias = str(alias); op.feature_key = key; op.enabled = True
            op = row.operator(_OPERATOR_ID, text=_t(context, 'OFF', '無効'), depress=not enabled)
            op.alias = str(alias); op.feature_key = key; op.enabled = False
        return True
    except Exception:
        return False


def draw_global_toggles(layout, context, addon_key: str) -> bool:
    return draw_inline_toggles(layout, context, addon_key)


def unregister_ui() -> None:
    try:
        from . import ownership_runtime_18168 as _own
        for cls in reversed(tuple(_REGISTERED_CLASSES)):
            _own.unregister_class(cls)
    except Exception:
        pass
    _REGISTERED_CLASSES.clear()


def unregister_all() -> None:
    for alias in tuple(_FEATURES):
        deactivate_alias(alias)
    unregister_ui()
    _FEATURES.clear()


def _safe_safe_set_kmi_property_v60(kmi, prop_name, value) -> bool:
    try:
        from . import resource_api_18168 as _resource
        return bool(_resource.keymap_item_set_property(kmi, str(prop_name), value))
    except Exception:
        return False
