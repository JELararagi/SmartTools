# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Native Smart UV Suite hub tools.

The operators in this module are JELararagi-native implementations that group
UV editing workflows by function family.  They are intentionally exposed only as
``smart_uv_suite.*`` operators and do not import, register, or forward external
add-on operator IDs.
"""

from __future__ import annotations
from . import resource_api_18168 as _suv_resource

import json
import math
import random
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

import bpy
from bpy.props import EnumProperty, FloatProperty, IntProperty, StringProperty
from mathutils import Vector

_SUV_WARNED = set()


def _suv_warn_once(key, *parts):
    if key not in _SUV_WARNED:
        _SUV_WARNED.add(key)
        print(' '.join(str(p) for p in parts))



_REGISTERED: list[type] = []
_UV_COPY_BUFFER: list[tuple[float, float]] = []
_LAST_TEXEL_DENSITY: float = 1.0


def _is_ja(context=None) -> bool:
    try:
        view = getattr(getattr(context or bpy.context, "preferences", None), "view", None)
        if view is not None and not bool(getattr(view, "use_translate_interface", True)):
            return False
        language = str(getattr(view, "language", "") or "") if view is not None else ""
        locale = str(getattr(getattr(bpy.app, "translations", None), "locale", "") or "")
        raw = (locale or language).lower()
        return raw.startswith("ja") or raw == "default_japanese" or "japanese" in raw
    except Exception:
        return False


def _t(context, en: str, ja: str) -> str:
    return str(ja if _is_ja(context) else en)


def _report(operator, context, level: str, en: str, ja: str) -> None:
    try:
        operator.report({level}, _t(context, en, ja))
    except Exception:
        pass


def _operator_exists(op_id: str) -> bool:
    if "." not in str(op_id or ""):
        return False
    head, tail = str(op_id).split(".", 1)
    try:
        op = getattr(getattr(bpy.ops, head), tail)
        rna = op.get_rna_type()
        ident = str(getattr(rna, "identifier", "") or "")
        return bool(ident) and ident not in {"Operator", "OperatorProperties", "UnknownType", "bpy_struct"}
    except Exception:
        return False


def _safe_call(op_id: str, **kwargs) -> bool:
    if "." not in str(op_id or ""):
        return False
    if not _operator_exists(op_id):
        return False
    head, tail = str(op_id).split(".", 1)
    try:
        op = getattr(getattr(bpy.ops, head), tail)
    except Exception:
        return False
    attempts = [(("EXEC_DEFAULT",), dict(kwargs)), (tuple(), dict(kwargs)), (("EXEC_DEFAULT",), {}), (tuple(), {})]
    for args, kw in attempts:
        try:
            result = op(*args, **kw)
            if isinstance(result, set):
                if "FINISHED" in result:
                    return True
                if "CANCELLED" in result:
                    continue
            elif result:
                return True
        except Exception:
            continue
    return False


def _active_mesh(context=None):
    ctx = context or bpy.context
    for attr in ("edit_object", "active_object", "object"):
        obj = getattr(ctx, attr, None)
        if obj is not None and getattr(obj, "type", "") == "MESH":
            return obj
    try:
        for obj in getattr(ctx, "selected_objects", ()) or ():
            if getattr(obj, "type", "") == "MESH":
                return obj
    except Exception:
        pass
    return None


def _selected_meshes(context=None) -> list:
    ctx = context or bpy.context
    meshes = []
    try:
        for obj in getattr(ctx, "selected_objects", ()) or ():
            if getattr(obj, "type", "") == "MESH" and obj not in meshes:
                meshes.append(obj)
    except Exception:
        pass
    obj = _active_mesh(ctx)
    if obj is not None and obj not in meshes:
        meshes.insert(0, obj)
    return meshes


def _set_active(context, obj) -> None:
    if obj is None:
        return
    try:
        context.view_layer.objects.active = obj
    except Exception:
        pass
    try:
        obj.select_set(True)
    except Exception:
        pass


def _mode_set(mode: str) -> bool:
    try:
        if getattr(bpy.context.object, "mode", "") != mode:
            bpy.ops.object.mode_set(mode=mode)
        return True
    except Exception:
        return False


@dataclass
class _UVState:
    obj: object
    bm: object
    uv_layer: object
    loops: list
    faces: list
    previous_mode: str = "OBJECT"


def _ensure_edit_state(context=None, *, all_if_empty: bool = True, select_all_if_empty: bool = True) -> _UVState | None:
    ctx = context or bpy.context
    obj = _active_mesh(ctx)
    if obj is None:
        return None
    previous_mode = str(getattr(obj, "mode", "OBJECT") or "OBJECT")
    _set_active(ctx, obj)
    if previous_mode != "EDIT":
        if not _mode_set("EDIT"):
            return None
    try:
        import bmesh
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active
        if uv_layer is None:
            uv_layer = bm.loops.layers.uv.verify()
        try:
            bm.faces.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.verts.ensure_lookup_table()
        except Exception:
            pass
        loops: list = []
        faces: list = []
        for face in bm.faces:
            if getattr(face, "hide", False):
                continue
            face_selected = bool(getattr(face, "select", False))
            selected_loops = []
            uv_sync = bool(getattr(ctx.tool_settings, "use_uv_select_sync", False))
            for loop in face.loops:
                if not uv_sync:
                    if face_selected and loop.uv_select_vert:
                        selected_loops.append(loop)
                    continue
                selected = face_selected
                try:
                    luv = loop[uv_layer]
                    selected = selected or bool(getattr(luv, "select", False)) or bool(getattr(luv, "select_edge", False))
                except Exception:
                    pass
                try:
                    selected = selected or bool(loop.vert.select)
                except Exception:
                    pass
                try:
                    selected = selected or bool(loop.edge.select)
                except Exception:
                    pass
                if selected:
                    selected_loops.append(loop)
            if selected_loops:
                faces.append(face)
                loops.extend(selected_loops)
        if all_if_empty and not loops:
            for face in bm.faces:
                if getattr(face, "hide", False):
                    continue
                faces.append(face)
                loops.extend(list(face.loops))
                if select_all_if_empty:
                    try:
                        face.select = True
                    except Exception:
                        pass
                    for loop in face.loops:
                        try:
                            loop[uv_layer].select = True
                            loop[uv_layer].select_edge = True
                        except Exception:
                            pass
        return _UVState(obj=obj, bm=bm, uv_layer=uv_layer, loops=loops, faces=faces, previous_mode=previous_mode)
    except Exception:
        return None


def _finish_state(state: _UVState | None, *, restore: bool = False) -> None:
    if state is None:
        return
    try:
        import bmesh
        bmesh.update_edit_mesh(state.obj.data, loop_triangles=False, destructive=False)
    except Exception:
        try:
            state.obj.data.update()
        except Exception:
            pass
    if restore and str(state.previous_mode) != "EDIT":
        try:
            bpy.ops.object.mode_set(mode=state.previous_mode)
        except Exception:
            try:
                bpy.ops.object.mode_set(mode="OBJECT")
            except Exception:
                pass



_STRICT_UV_FACE_SCOPE_DEPTH = 0
_PACK_MENU_ACTIONS = {"PACK", "PACK_PRECISION", "PACK_UDIM", "ATLAS_CELL", "TRIM_STRIP", "HOTSPOT_FIT", "FIT", "FILL", "ALIGN_CENTER"}


def _mesh_bool_attr(me, name: str, domain: str, *, create: bool = False):
    try:
        attrs = getattr(me, "attributes", None)
        if attrs is None:
            return None
        attr = attrs.get(name)
        if attr is None and create:
            attr = attrs.new(name=name, type='BOOLEAN', domain=domain)
        return attr
    except Exception:
        return None


def _read_uv_select_attrs(me) -> dict:
    out = {'vert': [], 'edge': [], 'face': [], 'has_vert': False, 'has_edge': False, 'has_face': False, 'has_any': False}
    for attr_name, key in ((".uv_select_vert", "vert"), (".uv_select_edge", "edge"), (".uv_select_face", "face")):
        try:
            attr = _mesh_bool_attr(me, attr_name, 'CORNER' if key != 'face' else 'FACE', create=False)
            if attr is None:
                continue
            vals = []
            for item in getattr(attr, 'data', []) or []:
                try:
                    vals.append(bool(getattr(item, 'value', False)))
                except Exception:
                    vals.append(False)
            out[key] = vals
            out['has_' + key] = True
            out['has_any'] = bool(out['has_any'] or any(vals))
        except Exception:
            pass
    return out


def _uv_attr_flag(attr_state: dict | None, key: str, index: int) -> bool:
    try:
        vals = list((attr_state or {}).get(key) or [])
        return 0 <= int(index) < len(vals) and bool(vals[int(index)])
    except Exception:
        return False


def _loop_uv_vert_selected(loop, face, uv_layer, attr_state: dict | None) -> bool:
    try:
        if bool((attr_state or {}).get('has_vert')):
            return _uv_attr_flag(attr_state, 'vert', int(getattr(loop, 'index', -1)))
    except Exception:
        pass
    try:
        return bool(getattr(loop[uv_layer], 'select', False))
    except Exception:
        return False


def _face_is_complete_uv_face_selection(face, uv_layer, attr_state: dict | None) -> bool:
    loops = list(getattr(face, 'loops', []) or [])
    if not loops:
        return False
    fi = int(getattr(face, 'index', -1))
    try:
        # When Blender 5.1 exposes the UV-face selection attribute, it is
        # authoritative.  All UV corners selected in vertex/edge mode is still
        # not a face selection and must not enter Pack/Atlas/Trim scope.
        if bool((attr_state or {}).get('has_face')):
            if not _uv_attr_flag(attr_state, 'face', fi):
                return False
    except Exception:
        return False
    for loop in loops:
        if not _loop_uv_vert_selected(loop, face, uv_layer, attr_state):
            return False
    return True


def _write_uv_face_selection_attrs(context, obj, selected_faces: set[int]) -> bool:
    if obj is None or getattr(obj, 'type', '') != 'MESH':
        return False
    me = getattr(obj, 'data', None)
    if me is None:
        return False
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed = False
    try:
        if old_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
            changed = True
        uv_vert = _mesh_bool_attr(me, '.uv_select_vert', 'CORNER', create=True)
        uv_edge = _mesh_bool_attr(me, '.uv_select_edge', 'CORNER', create=True)
        uv_face = _mesh_bool_attr(me, '.uv_select_face', 'FACE', create=True)
        loop_flags = [False] * len(getattr(me, 'loops', []) or [])
        face_flags = [False] * len(getattr(me, 'polygons', []) or [])
        selected_faces = {int(i) for i in selected_faces}
        for poly in getattr(me, 'polygons', []) or []:
            try:
                in_scope = int(poly.index) in selected_faces
                if 0 <= int(poly.index) < len(face_flags):
                    face_flags[int(poly.index)] = bool(in_scope)
                for li in list(getattr(poly, 'loop_indices', []) or []):
                    if 0 <= int(li) < len(loop_flags):
                        loop_flags[int(li)] = bool(in_scope)
            except Exception:
                pass
        if uv_vert is not None:
            for i, flag in enumerate(loop_flags):
                if i < len(uv_vert.data):
                    try:
                        uv_vert.data[i].value = bool(flag)
                    except Exception:
                        pass
        if uv_edge is not None:
            for i, flag in enumerate(loop_flags):
                if i < len(uv_edge.data):
                    try:
                        uv_edge.data[i].value = bool(flag)
                    except Exception:
                        pass
        if uv_face is not None:
            for i, flag in enumerate(face_flags):
                if i < len(uv_face.data):
                    try:
                        uv_face.data[i].value = bool(flag)
                    except Exception:
                        pass
        return True
    except Exception:
        return False
    finally:
        if changed:
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                try:
                    bpy.ops.object.mode_set(mode='EDIT')
                except Exception:
                    pass


def _prepare_strict_uv_face_scope(context, obj=None) -> dict:
    """Prepare Pack/Atlas/Trim operations for complete UV-face selections only.

    A UV vertex-only, edge-only, or partially selected face is rejected.  The
    scoped faces are temporarily selected as if they were the full mesh, while
    unscoped UV coordinates and all 3D View mesh selections are captured for
    restoration after the operation.
    """
    state = {'ok': False, 'selected_faces': set(), 'old_mode': 'OBJECT', 'changed_mode': False, 'mesh_face': {}, 'mesh_edge': {}, 'mesh_vert': {}, 'uv_unselected': [], 'uv_all': []}
    try:
        ctx = context or bpy.context
        if obj is None:
            obj = _active_mesh(ctx)
        if obj is None or getattr(obj, 'type', '') != 'MESH':
            return state
        state['obj'] = obj
        old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
        state['old_mode'] = old_mode
        _set_active(ctx, obj)
        # Blender 5.1 hides .uv_select_* attributes while an object is in Edit
        # Mode.  Read them in Object Mode first, then return to Edit Mode for
        # BMesh operations.
        pre_attr_state = None
        if old_mode == 'EDIT':
            try:
                bpy.ops.object.mode_set(mode='OBJECT')
                pre_attr_state = _read_uv_select_attrs(obj.data)
            except Exception:
                pre_attr_state = None
            try:
                bpy.ops.object.mode_set(mode='EDIT')
            except Exception:
                pass
        else:
            pre_attr_state = _read_uv_select_attrs(obj.data)
        if str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT') != 'EDIT':
            if not _mode_set('EDIT'):
                return state
            state['changed_mode'] = old_mode != 'EDIT'
        import bmesh
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        try:
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
        except Exception:
            pass
        attr_state = pre_attr_state if isinstance(pre_attr_state, dict) else _read_uv_select_attrs(obj.data)
        selected_faces: set[int] = set()
        uv_all = []
        for face in bm.faces:
            try:
                for pos, loop in enumerate(list(face.loops)):
                    luv = loop[uv_layer]
                    uv_all.append((int(face.index), int(pos), (float(luv.uv.x), float(luv.uv.y)), bool(getattr(luv, 'pin_uv', False))))
            except Exception:
                pass
            if getattr(face, 'hide', False):
                continue
            if _face_is_complete_uv_face_selection(face, uv_layer, attr_state):
                selected_faces.add(int(getattr(face, 'index', -1)))
        state['selected_faces'] = selected_faces
        state['uv_all'] = uv_all
        state['mesh_face'] = {int(f.index): bool(getattr(f, 'select', False)) for f in bm.faces}
        state['mesh_edge'] = {int(e.index): bool(getattr(e, 'select', False)) for e in bm.edges}
        state['mesh_vert'] = {int(v.index): bool(getattr(v, 'select', False)) for v in bm.verts}
        if not selected_faces:
            try:
                for face in bm.faces:
                    try:
                        face.select_set(False)
                    except Exception:
                        face.select = False
                    for loop in face.loops:
                        luv = loop[uv_layer]
                        if hasattr(luv, 'select'):
                            luv.select = False
                        if hasattr(luv, 'select_edge'):
                            luv.select_edge = False
                bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
            except Exception:
                pass
            _write_uv_face_selection_attrs(context, obj, set())
            try:
                if str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT') != 'EDIT':
                    bpy.ops.object.mode_set(mode='EDIT')
            except Exception:
                pass
            return state
        selected_verts = set()
        selected_edges = set()
        for face in bm.faces:
            in_scope = int(getattr(face, 'index', -1)) in selected_faces
            try:
                face.select_set(bool(in_scope))
            except Exception:
                face.select = bool(in_scope)
            if in_scope:
                for edge in face.edges:
                    selected_edges.add(edge)
                for vert in face.verts:
                    selected_verts.add(vert)
        for edge in bm.edges:
            try:
                edge.select_set(edge in selected_edges)
            except Exception:
                edge.select = edge in selected_edges
        for vert in bm.verts:
            try:
                vert.select_set(vert in selected_verts)
            except Exception:
                vert.select = vert in selected_verts
        uv_unselected = []
        for face in bm.faces:
            in_scope = int(getattr(face, 'index', -1)) in selected_faces
            loops = list(face.loops)
            for pos, loop in enumerate(loops):
                try:
                    luv = loop[uv_layer]
                    if not in_scope:
                        uv_unselected.append((int(face.index), int(pos), (float(luv.uv.x), float(luv.uv.y)), bool(getattr(luv, 'pin_uv', False))))
                    if hasattr(luv, 'select'):
                        luv.select = bool(in_scope)
                    if hasattr(luv, 'select_edge'):
                        luv.select_edge = bool(in_scope)
                except Exception:
                    pass
        state['uv_unselected'] = uv_unselected
        try:
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        except Exception:
            pass
        _write_uv_face_selection_attrs(context, obj, selected_faces)
        try:
            if str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT') != 'EDIT':
                bpy.ops.object.mode_set(mode='EDIT')
        except Exception:
            pass
        state['ok'] = True
        return state
    except Exception:
        return state


def _restore_strict_uv_face_scope(context, state: dict | None) -> None:
    state = dict(state or {})
    obj = state.get('obj')
    if obj is None or getattr(obj, 'type', '') != 'MESH':
        return
    selected_faces = {int(i) for i in (state.get('selected_faces') or set())}
    try:
        if str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT') != 'EDIT':
            _set_active(context or bpy.context, obj)
            bpy.ops.object.mode_set(mode='EDIT')
        import bmesh
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        try:
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
        except Exception:
            pass
        face_by_i = {int(f.index): f for f in bm.faces}
        edge_by_i = {int(e.index): e for e in bm.edges}
        vert_by_i = {int(v.index): v for v in bm.verts}
        restore_uv_records = list(state.get('uv_all') or []) if not selected_faces else list(state.get('uv_unselected') or [])
        for face_i, loop_pos, uv, pin in restore_uv_records:
            face = face_by_i.get(int(face_i))
            if face is None:
                continue
            loops = list(face.loops)
            if not (0 <= int(loop_pos) < len(loops)):
                continue
            try:
                luv = loops[int(loop_pos)][uv_layer]
                luv.uv = Vector((float(uv[0]), float(uv[1])))
                if hasattr(luv, 'select'):
                    luv.select = False
                if hasattr(luv, 'select_edge'):
                    luv.select_edge = False
                if hasattr(luv, 'pin_uv'):
                    luv.pin_uv = bool(pin)
            except Exception:
                pass
        for face in bm.faces:
            in_scope = int(getattr(face, 'index', -1)) in selected_faces
            for loop in face.loops:
                try:
                    luv = loop[uv_layer]
                    if hasattr(luv, 'select'):
                        luv.select = bool(in_scope)
                    if hasattr(luv, 'select_edge'):
                        luv.select_edge = bool(in_scope)
                except Exception:
                    pass
        for idx, val in dict(state.get('mesh_face') or {}).items():
            face = face_by_i.get(int(idx))
            if face is not None:
                try:
                    face.select_set(bool(val))
                except Exception:
                    face.select = bool(val)
        for idx, val in dict(state.get('mesh_edge') or {}).items():
            edge = edge_by_i.get(int(idx))
            if edge is not None:
                try:
                    edge.select_set(bool(val))
                except Exception:
                    edge.select = bool(val)
        for idx, val in dict(state.get('mesh_vert') or {}).items():
            vert = vert_by_i.get(int(idx))
            if vert is not None:
                try:
                    vert.select_set(bool(val))
                except Exception:
                    vert.select = bool(val)
        try:
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        except Exception:
            pass
        _write_uv_face_selection_attrs(context, obj, selected_faces)
    except Exception:
        pass
    finally:
        try:
            old_mode = str(state.get('old_mode') or 'EDIT')
            if bool(state.get('changed_mode')) and old_mode != 'EDIT':
                bpy.ops.object.mode_set(mode=old_mode)
        except Exception:
            pass


def _pack_margin(context) -> float:
    margin = _workspace_float(context, ("smart_unwrap_island_margin", "island_margin", "fit_padding_px"), 0.01)
    return max(0.0, min(0.49, margin))


def _pack(context, *, udim: bool = False) -> bool:
    """Native fallback pack used when unified auto-packing is unavailable."""
    margin = _pack_margin(context)
    if udim:
        return _safe_call("uv.pack_islands", udim_source='CLOSEST_UDIM', margin=margin)
    return _safe_call("uv.pack_islands", margin=margin)


def _atlas_cell(context) -> int:
    # The real atlas/hotspot grid layout lives in
    # unified_packing.run_auto_pack_for_action ('ATLAS_CELL' / 'HOTSPOT_FIT'),
    # which every dispatcher tries first.  There is no native Blender
    # equivalent to fall back to, so report zero placed islands instead of
    # raising NameError.
    return 0


def _trim_strip(context) -> int:
    # Same as _atlas_cell: 'TRIM_STRIP' is implemented by unified_packing;
    # without it there is nothing safe to do here.
    return 0


def _call_on_all_faces(context, op_id: str, **kwargs) -> bool:
    """Run a whole-mesh native UV operator and put the selection back afterwards."""
    obj = _active_mesh(context)
    state = _ensure_edit_state(context, all_if_empty=False, select_all_if_empty=False)
    if obj is None or state is None:
        return False
    bm = state.bm
    saved_verts = [v.select for v in bm.verts]
    saved_edges = [e.select for e in bm.edges]
    saved_faces = [(f.select, f.uv_select, [(l.uv_select_vert, l.uv_select_edge) for l in f.loops]) for f in bm.faces]
    _select_all_edit_faces(context)
    result = _safe_call(op_id, **kwargs)
    import bmesh
    bm = bmesh.from_edit_mesh(obj.data)
    for vert, value in zip(bm.verts, saved_verts):
        vert.select = value
    for edge, value in zip(bm.edges, saved_edges):
        edge.select = value
    for face, (selected, uv_selected, loops) in zip(bm.faces, saved_faces):
        face.select = selected
        face.uv_select_set(uv_selected)
        for loop, (uv_vert, uv_edge) in zip(face.loops, loops):
            loop.uv_select_vert = uv_vert
            loop.uv_select_edge = uv_edge
    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    return result


def _sharp_from_uv_islands(context) -> int:
    """Mark sharp edges along UV island boundaries via the native operator."""
    return 1 if _call_on_all_faces(context, "uv.seams_from_islands", mark_seams=False, mark_sharp=True) else 0


def _pin_action(context, mode: str = "PIN") -> int:
    """Native fallback for pin actions when seam_pin_tools is unavailable."""
    mode = str(mode or "PIN").upper()
    if mode == "INVERT":
        ok = _safe_call("uv.pin", invert=True)
    else:
        ok = _safe_call("uv.pin", clear=(mode == "UNPIN"))
    return 1 if ok else 0


def _stitch_or_weld(context) -> bool:
    # A UV stitch must never fall back to merging mesh vertices: that destroys the geometry.
    return _safe_call("smart_uv_suite.stitch_action", mode='ISLAND_CONNECTED_TO_SELECTED')


def _copy_uv(context) -> int:
    return 1 if _safe_call("uv.copy") else 0


def _paste_uv(context) -> int:
    return 1 if _safe_call("uv.paste") else 0


def _dispatch_pack_action_unscoped(context, action: str) -> bool:
    action = str(action or '').upper()
    if action in {"PACK", "PACK_PRECISION", "PACK_UDIM", "ATLAS_CELL", "TRIM_STRIP", "HOTSPOT_FIT"}:
        try:
            from . import unified_packing as _up
            if _up.run_auto_pack_for_action(context, action):
                return True
        except Exception:
            pass
        if action == "PACK_UDIM":
            return _pack(context, udim=True)
        if action == "ATLAS_CELL":
            return _atlas_cell(context) > 0
        if action == "TRIM_STRIP":
            return _trim_strip(context) > 0
        if action == "HOTSPOT_FIT":
            return _atlas_cell(context) > 0
        return _safe_call("smart_uv_suite.precision_pack", udim=False) or _pack(context, udim=False)
    if action == "FIT":
        return _fit_uvs(context, mode="FIT") > 0
    if action == "FILL":
        return _fit_uvs(context, mode="FILL") > 0
    if action == "ALIGN_CENTER":
        return _align_uvs(context, "CENTER") > 0
    return False


def _dispatch_pack_action_scoped(context, action: str) -> bool:
    global _STRICT_UV_FACE_SCOPE_DEPTH
    if _STRICT_UV_FACE_SCOPE_DEPTH > 0:
        return _dispatch_pack_action_unscoped(context, action)
    state = _prepare_strict_uv_face_scope(context)
    if not bool(state.get('ok')):
        _restore_strict_uv_face_scope(context, state)
        return False
    _STRICT_UV_FACE_SCOPE_DEPTH += 1
    try:
        return bool(_dispatch_pack_action_unscoped(context, action))
    finally:
        _STRICT_UV_FACE_SCOPE_DEPTH = max(0, _STRICT_UV_FACE_SCOPE_DEPTH - 1)
        _restore_strict_uv_face_scope(context, state)



def _uv_sticky_select_mode(context=None) -> str:
    try:
        ctx = context or bpy.context
        tool_settings = getattr(ctx, "tool_settings", None) or getattr(getattr(ctx, "scene", None), "tool_settings", None)
        mode = str(getattr(tool_settings, "uv_sticky_select_mode", "DISABLED") or "DISABLED").upper()
    except Exception:
        mode = "DISABLED"
    return {"SAME_LOCATION": "SHARED_LOCATION", "SAME_POSITION": "SHARED_LOCATION", "LOCATION": "SHARED_LOCATION", "VERTEX": "SHARED_VERTEX", "SHARED_VERT": "SHARED_VERTEX"}.get(mode, mode)


def _state_loop_groups(state: _UVState) -> list[list]:
    loops = list(getattr(state, "loops", []) or [])
    mode = _uv_sticky_select_mode()
    if mode not in {"SHARED_LOCATION", "SHARED_VERTEX"}:
        return [[loop] for loop in loops]
    buckets: dict[tuple, list] = {}
    ordered: list[tuple] = []
    for index, loop in enumerate(loops):
        try:
            if mode == "SHARED_VERTEX":
                key = ("vert", int(getattr(loop.vert, "index", -1)))
            else:
                uv = loop[state.uv_layer].uv
                key = ("uv", round(float(uv.x), 6), round(float(uv.y), 6))
        except Exception:
            key = ("loop", index)
        if key not in buckets:
            ordered.append(key)
            buckets[key] = []
        buckets[key].append(loop)
    return [buckets[key] for key in ordered if buckets.get(key)]


def _group_uv_center(group: list, uv_layer) -> Vector | None:
    pts = []
    for loop in group:
        try:
            pts.append(loop[uv_layer].uv.copy())
        except Exception:
            pass
    if not pts:
        return None
    sx = sum(float(p.x) for p in pts) / len(pts)
    sy = sum(float(p.y) for p in pts) / len(pts)
    return Vector((sx, sy))


def _uv_points(state: _UVState) -> list[Vector]:
    pts = []
    for group in _state_loop_groups(state):
        center = _group_uv_center(group, state.uv_layer)
        if center is not None:
            pts.append(center)
    return pts

def _bbox(points: Iterable[Vector]) -> tuple[float, float, float, float] | None:
    pts = list(points)
    if not pts:
        return None
    return (
        min(float(p.x) for p in pts),
        min(float(p.y) for p in pts),
        max(float(p.x) for p in pts),
        max(float(p.y) for p in pts),
    )


def _apply_uv_transform(state: _UVState, fn) -> int:
    count = 0
    for group in _state_loop_groups(state):
        center = _group_uv_center(group, state.uv_layer)
        if center is None:
            continue
        try:
            new_uv = fn(center.copy())
        except Exception:
            continue
        for loop in group:
            try:
                loop[state.uv_layer].uv = new_uv.copy()
                count += 1
            except Exception:
                pass
    return count


def _workspace(context=None):
    ctx = context or bpy.context
    return getattr(ctx, "scene", None) or getattr(ctx, "window_manager", None)


def _workspace_float(context, names: Sequence[str], default: float) -> float:
    for owner in (getattr(context, "scene", None), getattr(context, "window_manager", None)):
        if owner is None:
            continue
        for name in names:
            try:
                if hasattr(owner, name):
                    return float(getattr(owner, name))
            except Exception:
                continue
    return float(default)


def _workspace_int(context, names: Sequence[str], default: int) -> int:
    return int(round(_workspace_float(context, names, float(default))))


def _uv_area_face(face, uv_layer) -> float:
    try:
        pts = [loop[uv_layer].uv.copy() for loop in face.loops]
        if len(pts) < 3:
            return 0.0
        area = 0.0
        for i, p in enumerate(pts):
            q = pts[(i + 1) % len(pts)]
            area += p.x * q.y - q.x * p.y
        return area * 0.5
    except Exception:
        return 0.0


def _mesh_area_face(face) -> float:
    try:
        return float(face.calc_area())
    except Exception:
        return 0.0


def _ensure_object_uv_layer(obj, name: str = "SmartUV"):
    if obj is None or getattr(obj, "type", "") != "MESH":
        return None
    try:
        layers = obj.data.uv_layers
        if len(layers) == 0:
            return layers.new(name=name or "SmartUV")
        return layers.active or layers[0]
    except Exception:
        return None


def _set_face_uv_selected(context, face, state: bool) -> None:
    """Select a face in the UV editor: the mesh selection with UV Sync, the UV flags without it."""
    if bool(getattr(context.tool_settings, "use_uv_select_sync", False)):
        face.select = bool(state)
        return
    face.uv_select_set(bool(state))
    for loop in face.loops:
        loop.uv_select_vert = bool(state)
        loop.uv_select_edge = bool(state)


def _select_all_edit_faces(context) -> bool:
    state = _ensure_edit_state(context, all_if_empty=True, select_all_if_empty=True)
    if state is None:
        return False
    try:
        for face in state.bm.faces:
            if not getattr(face, "hide", False):
                face.select = True
                _set_face_uv_selected(context or bpy.context, face, True)
        _finish_state(state)
        return True
    except Exception:
        return False


def _run_existing_smart_unwrap(context) -> bool:
    if _operator_exists("smart_uv_suite.unwrap_auto_run"):
        try:
            if _safe_call("smart_uv_suite.unwrap_auto_run"):
                return True
        except Exception:
            pass
    return False


def _unwrap(context, method: str = "SMART") -> bool:
    obj = _active_mesh(context)
    if obj is None:
        return False
    _set_active(context, obj)
    _select_all_edit_faces(context)
    method = str(method or "SMART").upper()
    margin = _workspace_float(context, ("smart_unwrap_island_margin", "island_margin", "fit_padding_px"), 0.01)
    margin = max(0.0, min(0.49, margin))
    if method == "SMART":
        if _run_existing_smart_unwrap(context):
            return True
        if _safe_call("uv.unwrap", method="ANGLE_BASED", margin=margin):
            _safe_call("uv.average_islands_scale")
            if bool(getattr(getattr(context, "scene", None), "smart_unwrap_pack_after", True)):
                _safe_call("uv.pack_islands", margin=margin)
            return True
        return _safe_call("uv.smart_project", island_margin=margin)
    if method in {"ANGLE", "ANGLE_BASED"}:
        return _safe_call("uv.unwrap", method="ANGLE_BASED", margin=margin)
    if method in {"CONFORMAL", "LSCM"}:
        return _safe_call("uv.unwrap", method="CONFORMAL", margin=margin)
    if method in {"AUTO"}:
        return _safe_call("smart_uv_suite.unwrap_auto_action", mode="AUTO") or _safe_call("uv.smart_project", island_margin=margin)
    if method in {"FLAT", "FLAT_MAPPING"}:
        return _safe_call("smart_uv_suite.unwrap_auto_action", mode="FLAT_MAPPING") or _safe_call("uv.smart_project", island_margin=margin)
    if method in {"BOX", "CUBE"}:
        return _safe_call("smart_uv_suite.unwrap_auto_action", mode="BOX_PROJECT") or _safe_call("uv.cube_project", cube_size=1.0)
    if method in {"CYLINDER", "CYLINDRICAL"}:
        return _safe_call("smart_uv_suite.unwrap_auto_action", mode="CYLINDRICAL") or _safe_call("uv.cylinder_project")
    if method in {"SPHERE", "SPHERICAL"}:
        return _safe_call("smart_uv_suite.unwrap_auto_action", mode="SPHERICAL") or _safe_call("uv.sphere_project")
    if method in {"VIEW"}:
        return _safe_call("smart_uv_suite.unwrap_auto_action", mode="VIEW_PROJECT") or _safe_call("uv.project_from_view", correct_aspect=True)
    if method in {"SMART_PROJECT"}:
        return _safe_call("uv.smart_project", island_margin=margin)
    return _safe_call("uv.unwrap", method="ANGLE_BASED", margin=margin)




_NATIVE_UNIFIED_ORIGINAL_UNWRAP = _unwrap
def _unwrap(context, method: str = "SMART") -> bool:
    ok = bool(_NATIVE_UNIFIED_ORIGINAL_UNWRAP(context, method))
    if ok:
        try:
            from . import seam_pin_tools as _spt
            _spt.sync_after_unwrap_if_enabled(context)
        except Exception:
            pass
        try:
            from . import unified_packing as _up
            _up.run_auto_pack(context, 'PACK_STANDARD', use_panel_settings=False)
        except Exception:
            pass
    return ok


def _world_planar_project(context, *, axis: str = "AUTO") -> int:
    state = _ensure_edit_state(context, all_if_empty=True)
    if state is None:
        return 0
    axis = str(axis or "AUTO").upper()
    count = 0
    try:
        # Normalize by object-space bounds so the generated UVs land in 0..1.
        coords = [state.obj.matrix_world @ v.co for v in state.bm.verts]
        if not coords:
            return 0
        xs = [v.x for v in coords]; ys = [v.y for v in coords]; zs = [v.z for v in coords]
        bounds = {
            "XY": (min(xs), min(ys), max(xs), max(ys)),
            "XZ": (min(xs), min(zs), max(xs), max(zs)),
            "YZ": (min(ys), min(zs), max(ys), max(zs)),
        }
        for face in state.faces or list(state.bm.faces):
            normal = (state.obj.matrix_world.to_3x3() @ face.normal).normalized()
            face_axis = axis
            if face_axis == "AUTO":
                ax = max(((abs(normal.x), "YZ"), (abs(normal.y), "XZ"), (abs(normal.z), "XY")), key=lambda item: item[0])[1]
                face_axis = ax
            min_a, min_b, max_a, max_b = bounds.get(face_axis, bounds["XY"])
            span_a = max(1.0e-8, max_a - min_a)
            span_b = max(1.0e-8, max_b - min_b)
            for loop in face.loops:
                co = state.obj.matrix_world @ loop.vert.co
                if face_axis == "YZ":
                    u, v = (co.y - min_a) / span_a, (co.z - min_b) / span_b
                elif face_axis == "XZ":
                    u, v = (co.x - min_a) / span_a, (co.z - min_b) / span_b
                else:
                    u, v = (co.x - min_a) / span_a, (co.y - min_b) / span_b
                loop[state.uv_layer].uv = Vector((u, v))
                count += 1
    finally:
        _finish_state(state)
    return count


def _fit_uvs(context, *, mode: str = "FIT", padding: float | None = None) -> int:
    state = _ensure_edit_state(context, all_if_empty=True)
    if state is None:
        return 0
    box = _bbox(_uv_points(state))
    if box is None:
        return 0
    min_u, min_v, max_u, max_v = box
    width = max(1.0e-8, max_u - min_u)
    height = max(1.0e-8, max_v - min_v)
    pad = _workspace_float(context, ("smart_unwrap_island_margin", "fit_padding_px"), 0.01) if padding is None else float(padding)
    pad = max(0.0, min(0.49, pad))
    mode = str(mode or "FIT").upper()
    if mode == "CROP":
        target_w = target_h = 1.0
        scale_x = target_w / width
        scale_y = target_h / height
    elif mode == "FILL":
        target_w = target_h = max(1.0e-8, 1.0 - pad * 2.0)
        s = max(target_w / width, target_h / height)
        scale_x = scale_y = s
    else:
        target_w = target_h = max(1.0e-8, 1.0 - pad * 2.0)
        s = min(target_w / width, target_h / height)
        scale_x = scale_y = s
    new_w, new_h = width * scale_x, height * scale_y
    off_u = pad + (1.0 - pad * 2.0 - new_w) * 0.5
    off_v = pad + (1.0 - pad * 2.0 - new_h) * 0.5

    def tr(uv: Vector) -> Vector:
        return Vector((off_u + (uv.x - min_u) * scale_x, off_v + (uv.y - min_v) * scale_y))

    count = _apply_uv_transform(state, tr)
    _finish_state(state)
    return count


def _align_uvs(context, direction: str = "CENTER") -> int:
    state = _ensure_edit_state(context, all_if_empty=True)
    if state is None:
        return 0
    box = _bbox(_uv_points(state))
    if box is None:
        return 0
    min_u, min_v, max_u, max_v = box
    direction = str(direction or "CENTER").upper()
    target_u = 0.5
    target_v = 0.5
    if "LEFT" in direction:
        target_u = min_u
    elif "RIGHT" in direction:
        target_u = max_u
    if "TOP" in direction:
        target_v = max_v
    elif "BOTTOM" in direction:
        target_v = min_v
    du = dv = 0.0
    if direction in {"LEFT", "ALIGN_LEFT"}:
        du = -min_u
    elif direction in {"RIGHT", "ALIGN_RIGHT"}:
        du = 1.0 - max_u
    elif direction in {"TOP", "ALIGN_TOP"}:
        dv = 1.0 - max_v
    elif direction in {"BOTTOM", "ALIGN_BOTTOM"}:
        dv = -min_v
    elif direction in {"H", "CENTER_H", "ALIGN_H"}:
        du = 0.5 - ((min_u + max_u) * 0.5)
    elif direction in {"V", "CENTER_V", "ALIGN_V"}:
        dv = 0.5 - ((min_v + max_v) * 0.5)
    else:
        du = 0.5 - ((min_u + max_u) * 0.5)
        dv = 0.5 - ((min_v + max_v) * 0.5)
    count = _apply_uv_transform(state, lambda uv: Vector((uv.x + du, uv.y + dv)))
    _finish_state(state)
    return count


def _rotate_flip_uvs(context, *, angle: float = 0.0, flip_u: bool = False, flip_v: bool = False) -> int:
    state = _ensure_edit_state(context, all_if_empty=True)
    if state is None:
        return 0
    box = _bbox(_uv_points(state))
    if box is None:
        return 0
    min_u, min_v, max_u, max_v = box
    center = Vector(((min_u + max_u) * 0.5, (min_v + max_v) * 0.5))
    rad = math.radians(float(angle))
    c, s = math.cos(rad), math.sin(rad)

    def tr(uv: Vector) -> Vector:
        x = uv.x - center.x
        y = uv.y - center.y
        if flip_u:
            x = -x
        if flip_v:
            y = -y
        if angle:
            x, y = x * c - y * s, x * s + y * c
        return Vector((center.x + x, center.y + y))

    count = _apply_uv_transform(state, tr)
    _finish_state(state)
    return count


def _straighten_uvs(context, *, axis: str = "AUTO") -> int:
    state = _ensure_edit_state(context, all_if_empty=True)
    if state is None:
        return 0
    box = _bbox(_uv_points(state))
    if box is None:
        return 0
    min_u, min_v, max_u, max_v = box
    axis = str(axis or "AUTO").upper()
    if axis == "AUTO":
        axis = "U" if (max_u - min_u) >= (max_v - min_v) else "V"
    if axis in {"U", "X", "HORIZONTAL"}:
        mid = (min_v + max_v) * 0.5
        count = _apply_uv_transform(state, lambda uv: Vector((uv.x, mid)))
    else:
        mid = (min_u + max_u) * 0.5
        count = _apply_uv_transform(state, lambda uv: Vector((mid, uv.y)))
    _finish_state(state)
    return count


def _gridify_uvs(context, *, divisions: int | None = None) -> int:
    div = int(divisions or _workspace_int(context, ("snap_grid_divisions", "suv_native_grid_divisions"), 16))
    div = max(1, min(512, div))
    state = _ensure_edit_state(context, all_if_empty=True)
    if state is None:
        return 0
    count = _apply_uv_transform(state, lambda uv: Vector((round(uv.x * div) / div, round(uv.y * div) / div)))
    _finish_state(state)
    return count


def _circle_uvs(context) -> int:
    state = _ensure_edit_state(context, all_if_empty=True)
    if state is None or not state.loops:
        return 0
    box = _bbox(_uv_points(state))
    if box is None:
        return 0
    min_u, min_v, max_u, max_v = box
    center = Vector(((min_u + max_u) * 0.5, (min_v + max_v) * 0.5))
    radius = max(max_u - min_u, max_v - min_v, 1.0e-8) * 0.5
    loops = list(dict.fromkeys(state.loops))
    loops.sort(key=lambda loop: math.atan2(loop[state.uv_layer].uv.y - center.y, loop[state.uv_layer].uv.x - center.x))
    count = 0
    for i, loop in enumerate(loops):
        ang = math.tau * (i / max(1, len(loops)))
        try:
            loop[state.uv_layer].uv = Vector((center.x + math.cos(ang) * radius, center.y + math.sin(ang) * radius))
            count += 1
        except Exception:
            pass
    _finish_state(state)
    return count


def _randomize_uvs(context) -> int:
    amount = _workspace_float(context, ("randomize_amount", "suv_native_random_amount"), 0.05)
    amount = max(0.0, min(10.0, amount))
    du = random.uniform(-amount, amount)
    dv = random.uniform(-amount, amount)
    angle = random.choice((0.0, 90.0, 180.0, 270.0))
    moved = _rotate_flip_uvs(context, angle=angle)
    state = _ensure_edit_state(context, all_if_empty=True)
    if state is None:
        return moved
    count = _apply_uv_transform(state, lambda uv: Vector((uv.x + du, uv.y + dv)))
    _finish_state(state)
    return count


def _snap_uvs(context, mode: str = "GRID") -> int:
    mode = str(mode or "GRID").upper()
    if mode not in {"GRID", "PIXEL", "VERTEX"}:
        return 0
    try:
        kwargs = {"mode": mode}
        if mode == "PIXEL":
            kwargs["texture_size"] = _workspace_int(context, ("canvas_size", "checker_size", "suv_native_texture_size"), 1024)
        if bpy.ops.smart_uv_suite.consolidated_snap_uv.poll():
            result = bpy.ops.smart_uv_suite.consolidated_snap_uv(**kwargs)
            return 1 if "FINISHED" in set(result or []) else 0
    except Exception:
        pass
    if mode == "GRID":
        return _gridify_uvs(context)
    if mode == "PIXEL":
        tex = _workspace_int(context, ("canvas_size", "checker_size", "suv_native_texture_size"), 1024)
        return _gridify_uvs(context, divisions=max(1, tex))
    # Vertex snap is implemented by the consolidated snap operator because it
    # requires distance-based clustering of selected UV vertices.
    return 0


def _select_issue(context, issue: str = "ZERO") -> int:
    state = _ensure_edit_state(context, all_if_empty=True)
    if state is None:
        return 0
    issue = str(issue or "ZERO").upper()
    seen: set[tuple] = set()
    count = 0
    try:
        for face in state.bm.faces:
            _set_face_uv_selected(context, face, False)
        for face in state.bm.faces:
            if getattr(face, "hide", False):
                continue
            select = False
            uv_area = _uv_area_face(face, state.uv_layer)
            if issue in {"ZERO", "ZERO_AREA", "DEGENERATE"}:
                select = abs(uv_area) <= 1.0e-8 or _mesh_area_face(face) <= 1.0e-10
            elif issue in {"FLIPPED", "FLIP"}:
                select = uv_area < -1.0e-8
            elif issue in {"UDIM", "UDIM_CROSSING"}:
                tiles = set()
                for loop in face.loops:
                    uv = loop[state.uv_layer].uv
                    tiles.add((math.floor(float(uv.x)), math.floor(float(uv.y))))
                select = len(tiles) > 1 or any(tile != (0, 0) for tile in tiles)
            elif issue in {"OVERLAP", "OVERLAPPED"}:
                pts = [loop[state.uv_layer].uv for loop in face.loops]
                centroid = sum(pts, Vector((0.0, 0.0))) / max(1, len(pts))
                key = (round(centroid.x, 4), round(centroid.y, 4), len(pts), round(abs(uv_area), 4))
                select = key in seen
                seen.add(key)
            elif issue in {"BORDER", "BOUNDARY"}:
                select = any(len(getattr(loop.edge, "link_faces", ()) or ()) <= 1 for loop in face.loops)
            elif issue in {"SIMILAR"}:
                target = abs(uv_area)
                select = any(abs(target - abs(_uv_area_face(other, state.uv_layer))) <= 1.0e-5 for other in state.faces if other is not face)
            if select:
                _set_face_uv_selected(context, face, True)
                count += 1
    finally:
        _finish_state(state)
    return count


def _invert_selection(context) -> bool:
    state = _ensure_edit_state(context, all_if_empty=False)
    if state is None:
        return False
    try:
        uv_sync = bool(getattr(context.tool_settings, "use_uv_select_sync", False))
        for face in state.bm.faces:
            if uv_sync:
                face.select = not bool(getattr(face, "select", False))
            elif getattr(face, "select", False):
                current = all(loop.uv_select_vert for loop in face.loops)
                _set_face_uv_selected(context, face, not current)
        _finish_state(state)
        return True
    except Exception:
        _finish_state(state)
        return False


def _texel_stats(context) -> tuple[float, float, float, int]:
    mesh_area = 0.0
    uv_area = 0.0
    face_count = 0
    state = _ensure_edit_state(context, all_if_empty=True)
    if state is None:
        return 0.0, 0.0, 0.0, 0
    try:
        for face in state.bm.faces:
            mesh_area += max(0.0, _mesh_area_face(face))
            uv_area += abs(_uv_area_face(face, state.uv_layer))
            face_count += 1
    finally:
        _finish_state(state)
    tex_size = max(1, _workspace_int(context, ("canvas_size", "checker_size", "suv_native_texture_size"), 1024))
    density = math.sqrt(max(0.0, uv_area) / max(1.0e-12, mesh_area)) * tex_size
    return mesh_area, uv_area, density, face_count


def _texel_get(context) -> float:
    global _LAST_TEXEL_DENSITY
    _, _, density, _ = _texel_stats(context)
    _LAST_TEXEL_DENSITY = max(1.0e-8, density)
    try:
        setattr(context.scene, "suv_native_last_density", float(_LAST_TEXEL_DENSITY))
    except Exception:
        pass
    return _LAST_TEXEL_DENSITY


def _texel_normalize(context, *, target: float | None = None) -> int:
    current = _texel_get(context)
    if current <= 1.0e-8:
        return 0
    target_density = float(target if target is not None else _workspace_float(context, ("workflow_density", "target_texel_density", "suv_native_target_density"), current))
    scale = max(1.0e-8, target_density / current)
    state = _ensure_edit_state(context, all_if_empty=True)
    if state is None:
        return 0
    try:
        box = _bbox(_uv_points(state))
        if box is None:
            return 0
        center = Vector(((box[0] + box[2]) * 0.5, (box[1] + box[3]) * 0.5))
        count = _apply_uv_transform(state, lambda uv: center + (uv - center) * scale)
        return count
    finally:
        _finish_state(state)


def _create_checker(context, *, clear: bool = False) -> int:
    from . import native_stage as _native_stage
    if clear:
        count = 0
        for obj in bpy.data.objects:
            if obj.type == 'MESH':
                _native_stage._suv_restore_material_state(obj, '_suv_checker_restore')
        for mat in list(bpy.data.materials):
            try:
                if str(mat.name).startswith("Smart UV Checker"):
                    bpy.data.materials.remove(mat)
                    count += 1
            except Exception:
                pass
        for img in list(bpy.data.images):
            try:
                if str(img.name).startswith("Smart UV Checker"):
                    bpy.data.images.remove(img)
                    count += 1
            except Exception:
                pass
        return count
    size = max(16, _workspace_int(context, ("checker_size", "canvas_size", "suv_native_texture_size"), 1024))
    name = "Smart UV Checker"
    try:
        mat = bpy.data.materials.get(name) or bpy.data.materials.new(name)
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        bsdf = nodes.get("Principled BSDF")
        checker = nodes.get("Smart UV Checker Texture") or nodes.new("ShaderNodeTexChecker")
        checker.name = "Smart UV Checker Texture"
        try:
            checker.inputs["Scale"].default_value = max(2, min(256, size // 64))
        except Exception:
            pass
        if bsdf is not None:
            try:
                mat.node_tree.links.new(checker.outputs.get("Color"), bsdf.inputs.get("Base Color"))
            except Exception:
                pass
    except Exception:
        mat = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    count = 0
    for obj in _selected_meshes(context):
        try:
            _native_stage._suv_show_preview_material(obj, mat, '_suv_checker_restore')
            count += 1
        except Exception:
            pass
    return count


def _color_ids(context, mode: str = "OBJECT") -> int:
    mode = str(mode or "OBJECT").upper()
    count = 0
    if mode == "FACES":
        state = _ensure_edit_state(context, all_if_empty=True)
        if state is None:
            return 0
        mats = []
        try:
            for i in range(12):
                mat = bpy.data.materials.get(f"Smart UV ID {i+1:02d}") or bpy.data.materials.new(f"Smart UV ID {i+1:02d}")
                mat.diffuse_color = (random.random(), random.random(), random.random(), 1.0)
                if mat.name not in [m.name for m in state.obj.data.materials if m]:
                    state.obj.data.materials.append(mat)
                mats.append(list(state.obj.data.materials).index(mat))
            for idx, face in enumerate(state.faces or list(state.bm.faces)):
                face.material_index = mats[idx % len(mats)]
                count += 1
        finally:
            _finish_state(state)
        return count
    for idx, obj in enumerate(_selected_meshes(context)):
        try:
            mat = bpy.data.materials.get(f"Smart UV Object ID {idx+1:02d}") or bpy.data.materials.new(f"Smart UV Object ID {idx+1:02d}")
            mat.diffuse_color = (random.random(), random.random(), random.random(), 1.0)
            # The ID colour goes on the object's own slots: the mesh keeps the user's materials,
            # and objects sharing a mesh still get a colour each.
            if len(obj.material_slots) == 0:
                obj.data.materials.append(None)
            for slot in obj.material_slots:
                slot.link = "OBJECT"
                slot.material = mat
            count += 1
        except Exception:
            pass
    return count


def _bake_prep(context) -> int:
    count = 0
    try:
        context.scene.render.engine = "CYCLES"
        count += 1
    except Exception:
        pass
    for obj in _selected_meshes(context):
        try:
            _ensure_object_uv_layer(obj, "SmartUV_Bake")
            count += 1
        except Exception:
            pass
    count += _create_checker(context, clear=False)
    try:
        size = max(16, _workspace_int(context, ("canvas_size", "checker_size", "suv_native_texture_size"), 2048))
        if bpy.data.images.get("Smart UV Bake Canvas") is None:
            bpy.data.images.new("Smart UV Bake Canvas", width=size, height=size, alpha=True)
            count += 1
    except Exception:
        pass
    return count


def _reload_or_save_textures(context, mode: str = "RELOAD") -> int:
    mode = str(mode or "RELOAD").upper()
    count = 0
    for image in list(bpy.data.images):
        try:
            if mode == "RELOAD" and image.filepath:
                image.reload()
                count += 1
            elif mode == "SAVE" and image.is_dirty and image.filepath:
                image.save()
                count += 1
        except Exception:
            pass
    return count


def _uv_mesh_from_uv(context) -> int:
    obj = _active_mesh(context)
    if obj is None:
        return 0
    previous = str(getattr(obj, "mode", "OBJECT") or "OBJECT")
    try:
        if previous != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
    except Exception:
        pass
    uv_layer = _ensure_object_uv_layer(obj)
    if uv_layer is None:
        return 0
    verts = []
    faces = []
    try:
        for poly in obj.data.polygons:
            face_indices = []
            for li in poly.loop_indices:
                uv = uv_layer.data[li].uv
                face_indices.append(len(verts))
                verts.append((float(uv.x), float(uv.y), 0.0))
            if len(face_indices) >= 3:
                faces.append(tuple(face_indices))
        mesh = bpy.data.meshes.new(obj.name + "_SmartUVMesh")
        mesh.from_pydata(verts, [], faces)
        mesh.update()
        new_obj = bpy.data.objects.new(obj.name + "_SmartUVMesh", mesh)
        context.collection.objects.link(new_obj)
        count = len(faces)
    except Exception:
        count = 0
    try:
        if previous != "OBJECT":
            _set_active(context, obj)
            bpy.ops.object.mode_set(mode=previous)
    except Exception:
        pass
    return count


def _flatten_to_shape_key(context) -> int:
    obj = _active_mesh(context)
    if obj is None:
        return 0
    previous = str(getattr(obj, "mode", "OBJECT") or "OBJECT")
    try:
        if previous != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
    except Exception:
        pass
    uv_layer = _ensure_object_uv_layer(obj)
    if uv_layer is None:
        return 0
    try:
        if obj.data.shape_keys is None:
            obj.shape_key_add(name="Basis")
        key = obj.shape_key_add(name="Smart UV Flatten")
        accum = {i: Vector((0.0, 0.0)) for i in range(len(obj.data.vertices))}
        hits = {i: 0 for i in range(len(obj.data.vertices))}
        for poly in obj.data.polygons:
            for li in poly.loop_indices:
                vi = obj.data.loops[li].vertex_index
                accum[vi] += uv_layer.data[li].uv
                hits[vi] += 1
        box = _bbox((accum[i] / max(1, hits[i]) for i in accum))
        if box is None:
            return 0
        min_u, min_v, max_u, max_v = box
        scale = 1.0 / max(max_u - min_u, max_v - min_v, 1.0e-8)
        for vi, vert in enumerate(obj.data.vertices):
            uv = accum[vi] / max(1, hits[vi])
            key.data[vi].co = Vector(((uv.x - min_u - 0.5 * (max_u - min_u)) * scale, (uv.y - min_v - 0.5 * (max_v - min_v)) * scale, 0.0))
        count = len(obj.data.vertices)
    except Exception:
        count = 0
    try:
        if previous != "OBJECT":
            _set_active(context, obj)
            bpy.ops.object.mode_set(mode=previous)
    except Exception:
        pass
    return count


def _seam_action(context, mode: str) -> int:
    """Route consolidated seam actions to the registered native seam tools."""
    mode = str(mode or 'ALL').upper()
    if mode == 'CLEAR':
        return 1 if _safe_call('mesh.mark_seam', clear=True) else 0
    target_mode = {
        'ANGLE': 'ANGLE',
        'BOUNDARY': 'BOUNDARY',
        'NONMANIFOLD': 'BOUNDARY',
        'MATERIAL': 'MATERIAL',
        'ALL': 'ALL',
    }.get(mode, 'ALL')
    return 1 if _safe_call(
        'uv.suv_auto_seam_advanced',
        mode=target_mode,
        scope='SELECTED',
    ) else 0


def _uvmap_action(context, mode: str) -> int:
    """Route consolidated UV-map actions to the maintained UV-map operators."""
    mode = str(mode or 'ADD').upper()
    direct = {
        'ADD': 'mesh.suv_uvmap_add',
        'DUPLICATE': 'mesh.suv_uvmap_duplicate',
        'REMOVE': 'mesh.suv_uvmap_remove',
        'RENAME': 'mesh.suv_uvmap_rename_active',
        'SET_RENDER': 'mesh.suv_uvmap_set_render',
    }
    op_id = direct.get(mode)
    if op_id:
        return 1 if _safe_call(op_id) else 0
    if mode == 'COPY_TO_SELECTED':
        return 1 if _safe_call(
            'mesh.suv_native_stage_uvmap',
            mode='COPY_ACTIVE_TO_SELECTED',
        ) else 0
    return 0


def _auto_repair(context) -> int:
    count = 0
    count += _select_issue(context, "ZERO")
    count += _seam_action(context, "NONMANIFOLD")
    count += _texel_normalize(context)
    _pack(context)
    return count


def _focus_view(context) -> bool:
    screen = getattr(context, "screen", None)
    for area_type, ops in (("IMAGE_EDITOR", ("image.view_selected", "image.view_all")), ("VIEW_3D", ("view3d.view_selected", "view3d.view_all"))):
        for area in getattr(screen, "areas", []) or []:
            region = next((r for r in area.regions if r.type == "WINDOW"), None)
            if area.type != area_type or region is None:
                continue
            with context.temp_override(area=area, region=region):
                if any(_safe_call(op_id) for op_id in ops):
                    return True
    return False


def _write_report(context) -> int:
    mesh_area, uv_area, density, faces = _texel_stats(context)
    payload = {
        "tool": "Smart UV Suite",
        "license_holder": "JELararagi",
        "version_family": "1.5.4",
        "mesh_area": mesh_area,
        "uv_area": uv_area,
        "texel_density": density,
        "face_count": faces,
        "feature_families": [
            "smart unwrap/projection/flatten",
            "seam/pin/stitch/split",
            "layout/pack/atlas/trim/hotspot",
            "snap/align/rectify/relax/transform",
            "selection/inspection/repair",
            "uv-map/copy/paste/transfer",
            "texel/checker/texture/material/color",
            "bake preparation/preview/report",
        ],
    }
    try:
        text = bpy.data.texts.get("Smart UV Suite Report") or bpy.data.texts.new("Smart UV Suite Report")
        text.clear()
        text.write(json.dumps(payload, ensure_ascii=False, indent=2))
        return 1
    except Exception:
        return 0


def _cleanup_generated(context) -> int:
    count = 0
    count += _create_checker(context, clear=True)
    for block in list(bpy.data.texts):
        try:
            if str(block.name).startswith("Smart UV Suite Report"):
                bpy.data.texts.remove(block)
                count += 1
        except Exception:
            pass
    return count


def _export_settings(context) -> int:
    scene = getattr(context, "scene", None)
    if scene is None:
        return 0
    data = {}
    for name in dir(scene):
        if name.startswith(("smart_unwrap_", "suv_native_", "workflow_", "checker_", "canvas_", "fit_padding")):
            try:
                value = getattr(scene, name)
                if isinstance(value, (int, float, str, bool)):
                    data[name] = value
            except Exception:
                pass
    try:
        text = bpy.data.texts.get("Smart UV Suite Settings") or bpy.data.texts.new("Smart UV Suite Settings")
        text.clear()
        text.write(json.dumps(data, ensure_ascii=False, indent=2))
        return 1
    except Exception:
        return 0


def _dispatch(context, operator, action: str) -> bool:
    action = str(action or "").upper()
    try:
        op_idname = str(getattr(type(operator), "bl_idname", "") or getattr(operator, "bl_idname", "") or "")
    except Exception:
        op_idname = ""
    if op_idname in {"smart_uv_suite.native_pack_action", "smart_uv_suite.native_hub_action"} and action in _PACK_MENU_ACTIONS:
        return _dispatch_pack_action_scoped(context, action)
    if action in {"SMART_UNWRAP", "UNWRAP_SMART"}:
        return _unwrap(context, "SMART")
    if action == "AUTO_UNWRAP":
        return _unwrap(context, "AUTO")
    if action == "FLAT_MAPPING":
        return _unwrap(context, "FLAT_MAPPING")
    if action == "UNWRAP_ANGLE":
        return _unwrap(context, "ANGLE_BASED")
    if action == "UNWRAP_CONFORMAL":
        return _unwrap(context, "CONFORMAL")
    if action == "PROJECT_BOX":
        return _unwrap(context, "BOX") or _world_planar_project(context) > 0
    if action == "PROJECT_CYLINDER":
        return _unwrap(context, "CYLINDER")
    if action == "PROJECT_SPHERE":
        return _unwrap(context, "SPHERE")
    if action == "PROJECT_VIEW":
        return _unwrap(context, "VIEW") or _world_planar_project(context) > 0
    if action == "PROJECT_WORLD":
        return _world_planar_project(context) > 0
    if action == "TEXTURE_PROJECT":
        return _unwrap(context, "VIEW") or _world_planar_project(context) > 0
    if action == "UV_MESH":
        return _uv_mesh_from_uv(context) > 0
    if action == "FLATTEN_SHAPE_KEY":
        return _flatten_to_shape_key(context) > 0

    if action == "AUTO_SEAM":
        try:
            from . import seam_pin_tools as _spt
            return _spt.enhanced_auto_seam(context, mode="ALL") >= 0
        except Exception:
            return _seam_action(context, "ALL") >= 0
    if action == "MARK_SEAM":
        try:
            from . import seam_pin_tools as _spt
            return _spt.standard_mark_seam_selected_edges(context, clear=False) >= 0
        except Exception:
            return _safe_call("mesh.mark_seam", clear=False)
    if action == "CLEAR_SEAM":
        try:
            from . import seam_pin_tools as _spt
            return _spt.standard_mark_seam_selected_edges(context, clear=True) >= 0
        except Exception:
            return _safe_call("mesh.mark_seam", clear=True)
    if action in {"CREASE_VALUE", "CREASE_TO_SEAM"}:
        try:
            from . import seam_pin_tools as _spt
            ws = getattr(getattr(context, 'scene', None), 'suv_workspace', None)
            crease_value = float(getattr(ws, 'suv_crease_seam_value', 1.0) if ws is not None else 1.0)
            tolerance = float(getattr(ws, 'suv_crease_seam_tolerance', 0.001) if ws is not None else 0.001)
            apply_mode = str(getattr(ws, 'suv_crease_seam_apply_mode', 'ADD') if ws is not None else 'ADD')
            return _spt.mark_seams_by_edge_crease_value(context, crease_value=crease_value, tolerance=tolerance, apply_mode=apply_mode) >= 0
        except Exception:
            return False
    if action == "SEAM_ANGLE":
        return _seam_action(context, "ANGLE") >= 0
    if action == "SEAM_BOUNDARY":
        return _seam_action(context, "BOUNDARY") >= 0
    if action == "SEAM_MATERIAL":
        return _seam_action(context, "MATERIAL") >= 0
    if action == "SEAM_CLEAR":
        return _seam_action(context, "CLEAR") >= 0
    if action == "SEAMS_FROM_ISLANDS":
        return _call_on_all_faces(context, "uv.seams_from_islands")
    if action == "SHARP_FROM_UV":
        return _sharp_from_uv_islands(context) >= 0
    if action == "PIN":
        try:
            from . import seam_pin_tools as _spt
            return _spt.pin_uv_selection(context, action="PIN") >= 0
        except Exception:
            return _pin_action(context, "PIN") > 0
    if action == "UNPIN":
        try:
            from . import seam_pin_tools as _spt
            return _spt.pin_uv_selection(context, action="CLEAR_PINS") >= 0
        except Exception:
            return _pin_action(context, "UNPIN") >= 0
    if action == "PIN_INVERT":
        try:
            from . import seam_pin_tools as _spt
            return _spt.pin_uv_selection(context, action="INVERT_PINS") >= 0
        except Exception:
            return _pin_action(context, "INVERT") >= 0
    if action == "STITCH_WELD":
        return _stitch_or_weld(context)

    if action == "FIT":
        return _fit_uvs(context, mode="FIT") > 0
    if action == "FILL":
        return _fit_uvs(context, mode="FILL") > 0
    if action == "CROP":
        return _fit_uvs(context, mode="CROP") > 0
    if action == "ALIGN_CENTER":
        return _align_uvs(context, "CENTER") > 0
    if action == "ALIGN_LEFT":
        return _align_uvs(context, "LEFT") > 0
    if action == "ALIGN_RIGHT":
        return _align_uvs(context, "RIGHT") > 0
    if action == "ALIGN_TOP":
        return _align_uvs(context, "TOP") > 0
    if action == "ALIGN_BOTTOM":
        return _align_uvs(context, "BOTTOM") > 0
    if action == "ROTATE_90":
        return _rotate_flip_uvs(context, angle=90.0) > 0
    if action == "FLIP_U":
        return _rotate_flip_uvs(context, flip_u=True) > 0
    if action == "FLIP_V":
        return _rotate_flip_uvs(context, flip_v=True) > 0
    if action == "STRAIGHTEN":
        return _straighten_uvs(context) > 0
    if action == "GRIDIFY":
        return _gridify_uvs(context) > 0
    if action == "CIRCLE":
        return _circle_uvs(context) > 0
    if action == "RELAX":
        _select_all_edit_faces(context)
        return _safe_call("uv.minimize_stretch", iterations=10) or _unwrap(context, "ANGLE_BASED")
    if action == "RANDOMIZE":
        return _randomize_uvs(context) > 0
    if action == "SNAP_GRID":
        return _snap_uvs(context, "GRID") > 0
    if action == "SNAP_PIXEL":
        return _snap_uvs(context, "PIXEL") > 0
    if action == "SNAP_VERTEX":
        return _snap_uvs(context, "VERTEX") > 0

    if action in {"PACK", "PACK_PRECISION", "PACK_UDIM", "ATLAS_CELL", "TRIM_STRIP", "HOTSPOT_FIT"}:
        try:
            from . import unified_packing as _up
            return bool(_up.run_auto_pack_for_action(context, action))
        except Exception:
            return _dispatch_pack_action_scoped(context, action)

    if action == "SELECT_ZERO":
        return _select_issue(context, "ZERO") >= 0
    if action == "SELECT_FLIPPED":
        return _select_issue(context, "FLIPPED") >= 0
    if action == "SELECT_OVERLAP":
        return _select_issue(context, "OVERLAP") >= 0
    if action == "SELECT_UDIM":
        return _select_issue(context, "UDIM") >= 0
    if action == "SELECT_BORDER":
        return _select_issue(context, "BORDER") >= 0
    if action == "SELECT_SIMILAR":
        return _select_issue(context, "SIMILAR") >= 0
    if action == "SELECT_INVERT":
        return _invert_selection(context)
    if action == "AUTO_REPAIR":
        return _auto_repair(context) >= 0

    if action == "UVMAP_ADD":
        return _uvmap_action(context, "ADD") > 0
    if action == "UVMAP_DUPLICATE":
        return _uvmap_action(context, "DUPLICATE") > 0
    if action == "UVMAP_REMOVE":
        return _uvmap_action(context, "REMOVE") > 0
    if action == "UVMAP_RENAME":
        return _uvmap_action(context, "RENAME") > 0
    if action == "UVMAP_RENDER":
        return _uvmap_action(context, "SET_RENDER") > 0
    if action == "UVMAP_TRANSFER":
        return _uvmap_action(context, "COPY_TO_SELECTED") >= 0
    if action == "UV_COPY":
        return _copy_uv(context) > 0
    if action == "UV_PASTE":
        return _paste_uv(context) > 0

    if action == "DENSITY_GET":
        return _texel_get(context) > 0
    if action == "DENSITY_NORMALIZE":
        return _texel_normalize(context) > 0
    if action == "CHECKER_CREATE":
        return _create_checker(context, clear=False) > 0
    if action == "CHECKER_CLEAR":
        return _create_checker(context, clear=True) >= 0
    if action == "COLOR_ID_OBJECTS":
        return _color_ids(context, "OBJECT") > 0
    if action == "COLOR_ID_FACES":
        return _color_ids(context, "FACES") > 0
    if action == "BAKE_PREP":
        return _bake_prep(context) > 0
    if action == "TEXTURE_RELOAD":
        return _reload_or_save_textures(context, "RELOAD") >= 0
    if action == "TEXTURE_SAVE":
        return _reload_or_save_textures(context, "SAVE") >= 0

    if action == "FOCUS_VIEW":
        return _focus_view(context)
    if action == "WRITE_REPORT":
        return _write_report(context) > 0
    if action == "EXPORT_SETTINGS":
        return _export_settings(context) > 0
    if action == "CLEAN_GENERATED":
        return _cleanup_generated(context) >= 0
    return False


def _item(identifier: str, en: str, ja: str, desc_en: str, desc_ja: str):
    return (identifier, en, _t(None, desc_en, desc_ja))


UNWRAP_ITEMS = [
    ("SMART_UNWRAP", "Smart Unwrap", "Smart Unwrap: preserve connected no-seam meshes where possible, use configured temporary cut conditions when required, then relax/scale/pack according to Smart settings."),
    ("AUTO_UNWRAP", "Auto Unwrap", "High-quality automatic unwrap with temporary cuts, relax, scale normalization and optional packing."),
    ("FLAT_MAPPING", "Flat Mapping", "Flatten Mapping style angle-cluster unwrap with spacing and optional packing."),
    ("PROJECT_WORLD", "World Planar", "Project UVs from object/world axes. Use for architectural panels, decals, and flat mechanical parts."),
    ("PROJECT_BOX", "Box Project", "Create box-style projection for hard-surface forms."),
    ("PROJECT_CYLINDER", "Cylinder Project", "Create cylindrical projection for pipes and rounded parts."),
    ("PROJECT_SPHERE", "Sphere Project", "Create spherical projection for dome-like forms."),
    ("PROJECT_VIEW", "View Project", "Project from the current view, falling back to planar projection when the view operator is unavailable."),
    ("TEXTURE_PROJECT", "Texture Project", "Projection workflow for matching a visible image or camera-aligned texture."),
    ("UV_MESH", "UV Mesh", "Create a mesh object from the active UV layout for flattening, labels, or external inspection."),
    ("FLATTEN_SHAPE_KEY", "Flatten Shape Key", "Create a shape key that flattens the mesh to its UV coordinates."),
]

ALIGN_ITEMS = [
    ("ALIGN_CENTER", "Center", "Move selected UVs to the 0-1 tile center."),
    ("FIT", "Fit", "Fit selected UVs inside the 0-1 tile with padding."),
    ("FILL", "Fill", "Scale selected UVs until the tile is filled."),
    ("CROP", "Crop", "Normalize selected UV bounds to the full 0-1 tile."),
    ("STRAIGHTEN", "Straighten", "Straighten selected UVs along their dominant axis."),
    ("GRIDIFY", "Gridify", "Snap selected UVs to a configurable grid."),
    ("CIRCLE", "Circularize", "Place selected UV vertices around a circle."),
    ("RELAX", "Relax", "Minimize UV stretch using Blender's native solver when available."),
    ("ROTATE_90", "Rotate 90", "Rotate the current UV selection by 90 degrees."),
    ("FLIP_U", "Flip U", "Mirror the current UV selection horizontally."),
    ("FLIP_V", "Flip V", "Mirror the current UV selection vertically."),
    ("RANDOMIZE", "Randomize", "Randomize selected UV island transform for variation layouts."),
    ("SNAP_GRID", "Snap Grid", "Snap selected UVs to the grid division."),
    ("SNAP_PIXEL", "Snap Pixel", "Snap selected UVs to texture pixels."),
    ("SNAP_VERTEX", "Snap Vertex", "Move selected UV vertices within the distance setting to their shared midpoint."),
    ("STITCH_WELD", "Stitch/Weld", "Stitch or weld selected UV edges using available native operations."),
]

SEAM_ITEMS = [
    ("AUTO_SEAM", "Auto Seam", "Analyze angle, boundary, stretch, loop continuity and cylinder cut candidates, then mark real mesh seams."),
    ("MARK_SEAM", "Mark Seam", "Run Blender-standard Mark Seam on the selected 3D View mesh edges."),
    ("CLEAR_SEAM", "Clear Seam", "Run Blender-standard Clear Seam on the selected 3D View mesh edges."),
    ("CREASE_VALUE", "Crease Value Seam", "Mark edges whose Edge Crease value matches the configured number."),
    ("SEAM_ANGLE", "Seam by Angle", "Mark seams where mesh fold angle exceeds the configured Smart threshold."),
    ("SEAM_BOUNDARY", "Boundary Seams", "Mark open boundary edges as seams."),
    ("SEAM_MATERIAL", "Material Seams", "Mark seams where adjacent faces use different material slots."),
    ("SEAMS_FROM_ISLANDS", "Seams from Islands", "Convert current UV island borders to mesh seams."),
    ("SHARP_FROM_UV", "Sharp from UV", "Mark UV island border seams and set them as sharp edges when supported."),
    ("SEAM_CLEAR", "Clear All Seams", "Clear all seams on the active mesh."),
    ("PIN", "Pin", "Pin selected UVs."),
    ("UNPIN", "Unpin", "Clear selected UV pins."),
    ("PIN_INVERT", "Invert Pins", "Invert selected UV pin states."),
]

PACK_ITEMS = [
    ("PACK", "Pack", "High-density exact-margin pack selected UV islands into the current tile."),
    ("PACK_PRECISION", "Precision Pack", "Run the Smart UV exact-margin packer with equal spacing and rotation candidates."),
    ("PACK_UDIM", "UDIM Pack", "Pack selected UVs with UDIM-safe behavior where Blender supports it."),
    ("ATLAS_CELL", "Atlas Cell", "Fit selected UVs into a configured atlas grid cell."),
    ("TRIM_STRIP", "Trim Strip", "Fit selected UVs into a trim-sheet row."),
    ("HOTSPOT_FIT", "Hotspot Fit", "Fit selected UVs to the configured hotspot/atlas cell while preserving aspect."),
    ("FIT", "Fit", "Fit selected UVs into the tile."),
    ("FILL", "Fill", "Fill selected UVs in the tile."),
    ("ALIGN_CENTER", "Center", "Center the selection in UV space."),
]

BAKE_ITEMS = [
    ("BAKE_PREP", "Bake Prep", "Prepare UV layer, checker material, bake canvas, and Cycles setup for texture baking."),
    ("DENSITY_GET", "Get Density", "Measure active UV texel density from mesh and UV area."),
    ("DENSITY_NORMALIZE", "Normalize Density", "Scale selected UVs toward the configured target density."),
    ("CHECKER_CREATE", "Checker", "Create and assign a managed procedural checker material."),
    ("CHECKER_CLEAR", "Clear Checker", "Remove generated Smart UV checker materials/images."),
    ("COLOR_ID_OBJECTS", "Object IDs", "Assign distinct ID colors to selected objects."),
    ("COLOR_ID_FACES", "Face IDs", "Assign distinct ID materials to selected faces."),
    ("TEXTURE_RELOAD", "Reload Textures", "Reload all file-backed images in the current file."),
    ("TEXTURE_SAVE", "Save Textures", "Save dirty file-backed images where possible."),
]

ID_ITEMS = [
    ("UVMAP_ADD", "Add UV", "Create a UV map on selected meshes."),
    ("UVMAP_DUPLICATE", "Duplicate UV", "Duplicate the active UV map."),
    ("UVMAP_REMOVE", "Remove UV", "Remove the active UV map."),
    ("UVMAP_RENAME", "Rename UV", "Rename the active UV map using the configured UV name."),
    ("UVMAP_RENDER", "Render UV", "Set the active UV map as render UV."),
    ("UVMAP_TRANSFER", "Transfer UV", "Copy active-object UV coordinates to selected meshes with matching topology."),
    ("UV_COPY", "Copy UV", "Copy selected UV coordinates into the Smart UV clipboard."),
    ("UV_PASTE", "Paste UV", "Paste Smart UV clipboard coordinates into the current selection."),
    ("COLOR_ID_OBJECTS", "Object IDs", "Assign object ID colors."),
    ("COLOR_ID_FACES", "Face IDs", "Assign face ID colors."),
]

CLEANUP_ITEMS = [
    ("SELECT_ZERO", "Zero Area", "Select degenerate or zero-area UV faces."),
    ("SELECT_FLIPPED", "Flipped", "Select faces whose UV winding is flipped."),
    ("SELECT_OVERLAP", "Overlap", "Select probable overlapped UV faces by duplicate UV centroid/area."),
    ("SELECT_UDIM", "UDIM", "Select faces outside the 1001 tile or crossing UDIM boundaries."),
    ("SELECT_BORDER", "Border", "Select mesh/UV boundary faces."),
    ("SELECT_SIMILAR", "Similar", "Select faces with similar UV area."),
    ("SELECT_INVERT", "Invert", "Invert current mesh face selection."),
    ("AUTO_REPAIR", "Auto Repair", "Run a conservative cleanup: select issues, mark non-manifold seams, normalize density, and pack."),
    ("CLEAN_GENERATED", "Clean Generated", "Remove generated checker/report helper data."),
]

BASIC_ITEMS = [
    ("CHECKER_CREATE", "Checker", "Create and assign the managed checker material."),
    ("CHECKER_CLEAR", "Clear Checker", "Remove managed checker data."),
    ("FOCUS_VIEW", "Focus View", "Focus the UV editor or 3D view on the current selection."),
    ("SNAP_GRID", "Snap Grid", "Snap selected UVs to a grid."),
    ("EXPORT_SETTINGS", "Export Settings", "Write current Smart UV settings to a Blender text block."),
]

IO_ITEMS = [
    ("EXPORT_SETTINGS", "Export Settings", "Write current Smart UV settings to a text block."),
    ("WRITE_REPORT", "Write Report", "Write a concise Smart UV Suite report into a Blender text block."),
    ("CLEAN_GENERATED", "Clean Generated", "Remove generated helper data."),
    ("FOCUS_VIEW", "Focus View", "Focus the active UV or viewport area."),
]

ALL_ITEMS = []
for _items in (UNWRAP_ITEMS, ALIGN_ITEMS, SEAM_ITEMS, PACK_ITEMS, BAKE_ITEMS, ID_ITEMS, CLEANUP_ITEMS, BASIC_ITEMS, IO_ITEMS):
    for _item_def in _items:
        if _item_def[0] not in {i[0] for i in ALL_ITEMS}:
            ALL_ITEMS.append(_item_def)




def _item_lookup(action: str):
    action = str(action or '').strip().upper()
    for ident, name, desc in ALL_ITEMS:
        if str(ident or '').upper() == action:
            return str(ident or ''), str(name or ident), str(desc or '')
    return action, action.replace('_', ' ').title() if action else 'Native Action', ''

_ACTION_DESC_JA = {
    "SMART_UNWRAP": "現在の選択またはアクティブメッシュを、Smart UVの一時カット、リラックス、スケール、パック設定に従って自動展開します。",
    "AUTO_UNWRAP": "一時カット、リラックス、スケール正規化、必要に応じたパックを使って高品質な自動UV展開を実行します。",
    "FLAT_MAPPING": "角度クラスタを基準に面を平面化して展開し、間隔やパック設定を反映します。",
    "PROJECT_WORLD": "オブジェクト軸またはワールド軸からUVを投影します。建築パネル、デカール、平たい機械部品に向きます。",
    "PROJECT_BOX": "ハードサーフェス形状向けに、箱投影ベースのUVを作成します。",
    "PROJECT_CYLINDER": "パイプや円柱状パーツ向けに、円柱投影のUVを作成します。",
    "PROJECT_SPHERE": "ドーム状、球状の形状向けに、球投影のUVを作成します。",
    "PROJECT_VIEW": "現在のビュー方向からUVを投影します。ビュー投影が使えない場合は平面投影へフォールバックします。",
    "TEXTURE_PROJECT": "表示中の画像やカメラ合わせのテクスチャに合わせる投影ワークフローを実行します。",
    "UV_MESH": "現在のUVレイアウトからメッシュオブジェクトを作成し、平面確認、ラベル付け、外部確認に使える形にします。",
    "FLATTEN_SHAPE_KEY": "メッシュをUV座標へ平面化するシェイプキーを作成します。",
    "ALIGN_CENTER": "選択UVをUV空間または0-1タイルの中央へ移動します。",
    "FIT": "選択UVを指定余白付きで0-1タイル内へ収めます。",
    "FILL": "選択UVがタイルを満たすまでスケールします。",
    "CROP": "選択UVの外接範囲を0-1タイル全体へ正規化します。",
    "STRAIGHTEN": "選択UVを主軸に沿って直線化します。",
    "GRIDIFY": "選択UVを設定グリッドへ揃えます。",
    "CIRCLE": "選択UV頂点を円周上へ配置します。",
    "RELAX": "Blender標準ソルバーが使用できる場合、それを使ってUVの歪みを緩和します。",
    "ROTATE_90": "現在のUV選択を90度回転します。",
    "FLIP_U": "現在のUV選択をU方向へ左右反転します。",
    "FLIP_V": "現在のUV選択をV方向へ上下反転します。",
    "RANDOMIZE": "バリエーション作成用に、選択UVアイランドの変形をランダム化します。",
    "SNAP_GRID": "選択UVを現在のグリッド分割へ吸着します。",
    "SNAP_PIXEL": "選択UVをテクスチャピクセルへ吸着します。",
    "SNAP_VERTEX": "距離設定内にある選択UV頂点を検出し、対象グループの中点へ揃えます。",
    "STITCH_WELD": "利用可能な標準操作を使って、選択UV辺をスティッチまたはウェルドします。",
    "AUTO_SEAM": "角度、境界、伸び、ループ連続性、円筒カット候補を解析し、実メッシュのシームを設定します。",
    "MARK_SEAM": "3Dビューの選択メッシュ辺にBlender標準のMark Seamを実行します。",
    "CLEAR_SEAM": "3Dビューの選択メッシュ辺からBlender標準のClear Seamを実行します。",
    "CREASE_VALUE": "設定したEdge Crease値と一致する辺をシームとしてマークします。",
    "SEAM_ANGLE": "メッシュの折れ角がSmartしきい値を超える場所にシームをマークします。",
    "SEAM_BOUNDARY": "開いた境界辺をシームとしてマークします。",
    "SEAM_MATERIAL": "隣接面のマテリアルスロットが異なる辺をシームとしてマークします。",
    "SEAMS_FROM_ISLANDS": "現在のUVアイランド境界をメッシュシームへ変換します。",
    "SHARP_FROM_UV": "UVアイランド境界をシームとしてマークし、対応可能な場合はシャープ辺にも設定します。",
    "SEAM_CLEAR": "アクティブメッシュ上の全シームを解除します。",
    "PIN": "選択UVをピン留めします。",
    "UNPIN": "選択UVのピンを解除します。",
    "PIN_INVERT": "選択UVのピン状態を反転します。",
    "PACK": "選択UVアイランドを、現在のタイルへ正確な余白で高密度パックします。",
    "PACK_PRECISION": "等間隔と回転候補を使い、Smart UVの正確余白パッカーを実行します。",
    "PACK_UDIM": "Blenderが対応している範囲で、UDIMに安全なパックを実行します。",
    "ATLAS_CELL": "選択UVを設定済みアトラスグリッドのセルへ収めます。",
    "TRIM_STRIP": "選択UVをトリムシートの行へ収めます。",
    "HOTSPOT_FIT": "選択UVを、縦横比を保ちながら設定済みホットスポットまたはアトラスセルへ収めます。",
    "BAKE_PREP": "UVレイヤー、チェッカー材質、ベイクキャンバス、Cycles設定をテクスチャベイク用に準備します。",
    "DENSITY_GET": "メッシュ面積とUV面積から、アクティブUVのテクセル密度を測定します。",
    "DENSITY_NORMALIZE": "選択UVを設定された目標テクセル密度へ近づけるようにスケールします。",
    "CHECKER_CREATE": "管理対象のプロシージャルチェッカー材質を作成して割り当てます。",
    "CHECKER_CLEAR": "生成済みのSmart UVチェッカー材質や画像を削除します。",
    "COLOR_ID_OBJECTS": "選択オブジェクトへ識別用の個別IDカラーを割り当てます。",
    "COLOR_ID_FACES": "選択面へ識別用のIDマテリアルを割り当てます。",
    "TEXTURE_RELOAD": "現在のファイル内にあるファイル参照画像を再読み込みします。",
    "TEXTURE_SAVE": "保存が必要なファイル参照画像を、可能な範囲で保存します。",
    "UVMAP_ADD": "選択メッシュにUVマップを作成します。",
    "UVMAP_DUPLICATE": "アクティブUVマップを複製します。",
    "UVMAP_REMOVE": "アクティブUVマップを削除します。",
    "UVMAP_RENAME": "設定されたUV名を使ってアクティブUVマップをリネームします。",
    "UVMAP_RENDER": "アクティブUVマップをレンダー用UVに設定します。",
    "UVMAP_TRANSFER": "同一トポロジーの選択メッシュへ、アクティブオブジェクトのUV座標を転送します。",
    "UV_COPY": "選択UV座標をSmart UVのクリップボードへコピーします。",
    "UV_PASTE": "Smart UVのクリップボード座標を現在の選択へ貼り付けます。",
    "SELECT_ZERO": "縮退またはゼロ面積のUV面を選択します。",
    "SELECT_FLIPPED": "UVの巻き方向が反転している面を選択します。",
    "SELECT_OVERLAP": "UV中心や面積の重複から、重なりが疑われるUV面を選択します。",
    "SELECT_UDIM": "1001タイル外、またはUDIM境界をまたぐ面を選択します。",
    "SELECT_BORDER": "メッシュまたはUVの境界面を選択します。",
    "SELECT_SIMILAR": "UV面積が近い面を選択します。",
    "SELECT_INVERT": "現在のメッシュ面選択を反転します。",
    "AUTO_REPAIR": "問題選択、非多様体シーム、密度正規化、パックを含む保守的な自動修復を実行します。",
    "CLEAN_GENERATED": "生成済みチェッカー、レポート、補助データを削除します。",
    "FOCUS_VIEW": "現在の選択へUVエディターまたは3Dビューをフォーカスします。",
    "EXPORT_SETTINGS": "現在のSmart UV設定をBlenderテキストブロックへ書き出します。",
    "WRITE_REPORT": "Smart UV Suiteの簡易レポートをBlenderテキストブロックへ作成します。",
}


def _action_tooltip(context, action: str, *, section_en: str = 'Native UV action', section_ja: str = '標準連携UVアクション') -> str:
    ident, name, desc_en = _item_lookup(action)
    desc_en = desc_en or f'Run the {name} native UV action from this section.'
    desc_ja = _ACTION_DESC_JA.get(str(ident or '').upper(), f'{name} に対応する標準連携UVアクションを、この項目から実行します。')
    return _t(
        context,
        f'{name}: {desc_en}  This button runs only the {ident} function assigned to it, not every command in {section_en}.',
        f'{name}: {desc_ja} このボタンは {section_ja} 内の全機能ではなく、割り当てられた {ident} 機能だけを実行します。',
    )

def _enum_items(items):
    result = []
    for ident, name, desc in items:
        result.append((ident, name, desc))
    return result


class SMARTUVSUITE_OT_native_hub_action(bpy.types.Operator):
    bl_idname = "smart_uv_suite.native_hub_action"
    bl_label = "Smart UV Native Action"
    bl_options = {'UNDO'}

    action: EnumProperty(name="Action", items=_enum_items(ALL_ITEMS), default="SMART_UNWRAP")

    @classmethod
    def poll(cls, context):
        return True

    @classmethod
    def description(cls, context, properties):
        action = str(getattr(properties, "action", "") or "")
        return _action_tooltip(context, action, section_en="Native Hub", section_ja="標準連携ハブ")

    def execute(self, context):
        action = str(getattr(self, "action", "") or "SMART_UNWRAP")
        try:
            ok = _dispatch(context, self, action)
        except Exception as exc:
            try:
                _suv_warn_once('a106:native_unified_tools.py:2144', "[Smart UV Suite] Native action failed:", action, exc)
            except Exception:
                pass
            ok = False
        if ok:
            _report(self, context, "INFO", f"Smart UV action executed: {action}", f"Smart UVアクションを実行しました: {action}")
            return {"FINISHED"}
        _report(self, context, "WARNING", f"Smart UV action could not run in the current context: {action}", f"現在のコンテキストではSmart UVアクションを実行できません: {action}")
        return {"CANCELLED"}


def _make_section_operator(class_name: str, bl_idname: str, label: str, default: str, items):
    attrs = {
        "bl_idname": bl_idname,
        "bl_label": label,
        "bl_options": {"REGISTER", "UNDO"},
        "__annotations__": {"action": EnumProperty(name="Action", items=_enum_items(items), default=default)},
    }

    @classmethod
    def poll(cls, context):
        return True

    @classmethod
    def description(cls, context, properties):
        action = str(getattr(properties, "action", default) or default)
        return _action_tooltip(context, action, section_en=label, section_ja=label)

    def execute(self, context):
        action = str(getattr(self, "action", default) or default)
        try:
            ok = _dispatch(context, self, action)
        except Exception as exc:
            try:
                _suv_warn_once('a106:native_unified_tools.py:2179', "[Smart UV Suite] Section action failed:", action, exc)
            except Exception:
                pass
            ok = False
        if ok:
            _report(self, context, "INFO", f"Smart UV action executed: {action}", f"Smart UVアクションを実行しました: {action}")
            return {"FINISHED"}
        _report(self, context, "WARNING", f"Smart UV action could not run in the current context: {action}", f"現在のコンテキストではSmart UVアクションを実行できません: {action}")
        return {"CANCELLED"}

    attrs["poll"] = poll
    attrs["description"] = description
    attrs["execute"] = execute
    return type(class_name, (bpy.types.Operator,), attrs)


SMARTUVSUITE_OT_native_basic_action = _make_section_operator("SMARTUVSUITE_OT_native_basic_action", "smart_uv_suite.native_basic_action", "Smart UV Basic Action", "CHECKER_CREATE", BASIC_ITEMS)
SMARTUVSUITE_OT_native_unwrap_action = _make_section_operator("SMARTUVSUITE_OT_native_unwrap_action", "smart_uv_suite.native_unwrap_action", "Smart UV Unwrap Action", "SMART_UNWRAP", UNWRAP_ITEMS)
SMARTUVSUITE_OT_native_align_action = _make_section_operator("SMARTUVSUITE_OT_native_align_action", "smart_uv_suite.native_align_action", "Smart UV Align Action", "FIT", ALIGN_ITEMS)
SMARTUVSUITE_OT_native_seam_action = _make_section_operator("SMARTUVSUITE_OT_native_seam_action", "smart_uv_suite.native_seam_action", "Smart UV Seam Action", "SEAM_ANGLE", SEAM_ITEMS)
SMARTUVSUITE_OT_native_pack_action = _make_section_operator("SMARTUVSUITE_OT_native_pack_action", "smart_uv_suite.native_pack_action", "Smart UV Pack Action", "PACK", PACK_ITEMS)
SMARTUVSUITE_OT_native_bake_action = _make_section_operator("SMARTUVSUITE_OT_native_bake_action", "smart_uv_suite.native_bake_action", "Smart UV Bake Action", "BAKE_PREP", BAKE_ITEMS)
SMARTUVSUITE_OT_native_id_action = _make_section_operator("SMARTUVSUITE_OT_native_id_action", "smart_uv_suite.native_id_action", "Smart UV ID Action", "UVMAP_ADD", ID_ITEMS)
SMARTUVSUITE_OT_native_cleanup_action = _make_section_operator("SMARTUVSUITE_OT_native_cleanup_action", "smart_uv_suite.native_cleanup_action", "Smart UV Cleanup Action", "SELECT_ZERO", CLEANUP_ITEMS)
SMARTUVSUITE_OT_native_io_action = _make_section_operator("SMARTUVSUITE_OT_native_io_action", "smart_uv_suite.native_io_action", "Smart UV I/O Action", "WRITE_REPORT", IO_ITEMS)

_CLASSES = (
    SMARTUVSUITE_OT_native_hub_action,
    SMARTUVSUITE_OT_native_basic_action,
    SMARTUVSUITE_OT_native_unwrap_action,
    SMARTUVSUITE_OT_native_align_action,
    SMARTUVSUITE_OT_native_seam_action,
    SMARTUVSUITE_OT_native_pack_action,
    SMARTUVSUITE_OT_native_bake_action,
    SMARTUVSUITE_OT_native_id_action,
    SMARTUVSUITE_OT_native_cleanup_action,
    SMARTUVSUITE_OT_native_io_action,
)



_NATIVE_JA_TEXT = {
    "Smart UV Native Action": "Smart UV統合アクション",
    "Smart UV Basic Action": "Smart UV基本アクション",
    "Smart UV Unwrap Action": "Smart UV展開アクション",
    "Smart UV Align Action": "Smart UV整列アクション",
    "Smart UV Seam Action": "Smart UVシームアクション",
    "Smart UV Pack Action": "Smart UVパックアクション",
    "Smart UV Bake Action": "Smart UVベイクアクション",
    "Smart UV ID Action": "Smart UV IDアクション",
    "Smart UV Cleanup Action": "Smart UV整理アクション",
    "Smart UV I/O Action": "Smart UV入出力アクション",
    "Action": "アクション",
    "Smart Unwrap": "スマート展開",
    "World Planar": "ワールド平面",
    "Box Project": "ボックス投影",
    "Cylinder Project": "円柱投影",
    "Sphere Project": "球投影",
    "View Project": "ビュー投影",
    "Texture Project": "テクスチャ投影",
    "UV Mesh": "UVメッシュ",
    "Flatten Shape Key": "UV形状キー",
    "Center": "中央",
    "Fit": "フィット",
    "Fill": "フィル",
    "Crop": "クロップ",
    "Straighten": "直線化",
    "Gridify": "グリッド化",
    "Circularize": "円形化",
    "Relax": "リラックス",
    "Rotate 90": "90度回転",
    "Flip U": "U反転",
    "Flip V": "V反転",
    "Randomize": "ランダム",
    "Snap Grid": "グリッド吸着",
    "Snap Pixel": "ピクセル吸着",
    "Snap Vertex": "頂点吸着",
    "Stitch/Weld": "スティッチ/結合",
    "Seam by Angle": "角度シーム",
    "Boundary Seams": "境界シーム",
    "Material Seams": "マテリアルシーム",
    "Seams from Islands": "島からシーム",
    "Sharp from UV": "UVからシャープ",
    "Clear Seams": "シーム解除",
    "Pin": "ピン",
    "Unpin": "ピン解除",
    "Pack": "パック",
    "UDIM Pack": "UDIMパック",
    "Atlas Cell": "アトラスセル",
    "Trim Strip": "トリム帯",
    "Hotspot Fit": "ホットスポット合わせ",
    "Bake Prep": "ベイク準備",
    "Get Density": "密度取得",
    "Normalize Density": "密度正規化",
    "Checker": "チェッカー",
    "Clear Checker": "チェッカー解除",
    "Object IDs": "オブジェクトID",
    "Face IDs": "面ID",
    "Reload Textures": "テクスチャ再読込",
    "Save Textures": "テクスチャ保存",
    "Add UV": "UV追加",
    "Duplicate UV": "UV複製",
    "Remove UV": "UV削除",
    "Rename UV": "UV名変更",
    "Render UV": "レンダーUV",
    "Transfer UV": "UV転送",
    "Copy UV": "UVコピー",
    "Paste UV": "UV貼付",
    "Zero Area": "ゼロ面積",
    "Flipped": "反転",
    "Overlap": "重なり",
    "UDIM": "UDIM",
    "Border": "境界",
    "Similar": "類似",
    "Invert": "反転選択",
    "Auto Repair": "自動修復",
    "Clean Generated": "生成データ整理",
    "Focus View": "表示調整",
    "Export Settings": "設定出力",
    "Write Report": "レポート作成",
    "Last Density": "前回密度",
    "Target Density": "目標密度",
    "Grid Divisions": "グリッド分割",
    "UV Name": "UV名",
    "Function: Stores the last measured Smart UV texel density. How to use: run Get Density, then use Normalize Density or inspect the generated report.": "機能: 最後に測定したSmart UVテクセル密度を保存します。使い方: 密度取得を実行し、密度正規化または生成レポート確認に使います。",
    "Function: Target texel density for native Smart UV normalization. How to use: enter the desired density, then run Normalize Density.": "機能: Smart UV統合密度正規化の目標テクセル密度です。使い方: 目的の密度を入力してから密度正規化を実行します。",
    "Function: Grid divisions used by native Smart UV snapping and gridify actions. How to use: set a division count such as 16, 32, or texture size before running Snap Grid.": "機能: Smart UV統合の吸着とグリッド化で使う分割数です。使い方: グリッド吸着の前に16、32、テクスチャサイズなどを設定します。",
    "Function: Name used by native Smart UV map creation and rename actions. How to use: enter the desired UV map name before Add UV or Rename UV.": "機能: Smart UV統合のUV作成・名称変更で使う名前です。使い方: UV追加またはUV名変更の前に目的のUV名を入力します。",
}
_TRANSLATIONS_REGISTERED = False


def _translation_dictionary() -> dict:
    """bpy.app.translations payload built from this module's EN->JA table."""
    ja = {}
    for en, text in _NATIVE_JA_TEXT.items():
        ja[('*', en)] = text
        ja[('Operator', en)] = text
    return {'ja_JP': ja}


def _register_translations() -> None:
    try:
        from . import ownership_runtime_18168 as _ownership
        data = _translation_dictionary()
        _ownership.register_translation(__name__, data)
    except Exception:
        pass


def _unregister_translations() -> None:
    try:
        from . import ownership_runtime_18168 as _ownership
        _ownership.unregister_translation(__name__)
    except Exception:
        pass


def register() -> None:
    _register_translations()
    if _REGISTERED:
        return
    for cls in _CLASSES:
        try:
            _suv_resource.register_class(cls)
            _REGISTERED.append(cls)
        except Exception:
            pass
    try:
        _suv_resource.register_property(bpy.types.Scene, 'suv_native_last_density', FloatProperty(name='Last Density', description='Function: Stores the last measured Smart UV texel density. How to use: run Get Density, then use Normalize Density or inspect the generated report.', default=1.0, min=0.0))
        _suv_resource.register_property(bpy.types.Scene, 'suv_native_target_density', FloatProperty(name='Target Density', description='Function: Target texel density for native Smart UV normalization. How to use: enter the desired density, then run Normalize Density.', default=256.0, min=0.0))
        _suv_resource.register_property(bpy.types.Scene, 'suv_native_grid_divisions', IntProperty(name='Grid Divisions', description='Function: Grid divisions used by native Smart UV snapping and gridify actions. How to use: set a division count such as 16, 32, or texture size before running Snap Grid.', default=16, min=1, max=4096))
        _suv_resource.register_property(bpy.types.Scene, 'suv_native_uv_name', StringProperty(name='UV Name', description='Function: Name used by native Smart UV map creation and rename actions. How to use: enter the desired UV map name before Add UV or Rename UV.', default='SmartUV'))
    except Exception:
        pass


def unregister() -> None:
    for prop in ("suv_native_last_density", "suv_native_target_density", "suv_native_grid_divisions", "suv_native_uv_name"):
        try:
            _suv_resource.unregister_property(bpy.types.Scene, prop)
        except Exception:
            pass
    for cls in reversed(_REGISTERED):
        try:
            _suv_resource.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED.clear()
    _unregister_translations()


__all__ = ["register", "unregister"]

# ---------------------------------------------------------------------------
# 1.6.26 Route Native Unified unwrap shortcuts through Smart UV strict pipeline
# ---------------------------------------------------------------------------
_NATIVE_UNIFIED_1626_ORIGINAL_UNWRAP = _unwrap

def _unwrap(context, method: str = "SMART") -> bool:
    m = str(method or 'SMART').upper()
    route = {
        'SMART': 'SMART',
        'AUTO': 'SMART',
        'FLAT_MAPPING': 'FLAT_MAPPING',
        'ANGLE_BASED': 'BLENDER_ANGLE_BASED',
        'ANGLE': 'BLENDER_ANGLE_BASED',
        'CONFORMAL': 'BLENDER_CONFORMAL',
        'MIN_STRETCH': 'BLENDER_MIN_STRETCH',
        'MINIMUM_STRETCH': 'BLENDER_MIN_STRETCH',
        'SMART_PROJECT': 'BLENDER_SMART_PROJECT',
        'LIGHTMAP': 'BLENDER_LIGHTMAP_PACK',
        'LIGHTMAP_PACK': 'BLENDER_LIGHTMAP_PACK',
        'FOLLOW_QUADS': 'BLENDER_FOLLOW_ACTIVE_QUADS',
        'FOLLOW_ACTIVE_QUADS': 'BLENDER_FOLLOW_ACTIVE_QUADS',
        'BOX': 'BOX_PROJECT',
        'BOX_PROJECT': 'BOX_PROJECT',
        'CUBE': 'BOX_PROJECT',
        'CYLINDER': 'CYLINDRICAL',
        'CYLINDRICAL': 'CYLINDRICAL',
        'SPHERE': 'SPHERICAL',
        'SPHERICAL': 'SPHERICAL',
        'VIEW': 'VIEW_PROJECT',
        'VIEW_PROJECT': 'VIEW_PROJECT',
        'UNITIZE': 'UNITIZE_FACES',
        'UNITIZE_FACES': 'UNITIZE_FACES',
    }.get(m)
    if route:
        try:
            return bool(_safe_call('smart_uv_suite.unwrap_auto_action', mode=route))
        except Exception:
            pass
    old = globals().get('_NATIVE_UNIFIED_1626_ORIGINAL_UNWRAP')
    return bool(old(context, method)) if callable(old) else False


# ---------------------------------------------------------------------------
# 1.6.26 Route Native Hub unwraps through the central strict Smart UV pipeline
# ---------------------------------------------------------------------------
# Older hub buttons selected all edit faces before invoking Blender UV operators.
# That bypassed the strict UV Editor complete-face scope, Mark Seam pre-split,
# persistent pin/seam handling and selected-scope final pack.  Keep the button
# names, but dispatch destructive unwrap/projection methods into the unified
# smart_uv_suite.unwrap_auto_action operator.
_NATIVE_UNIFIED_1626_ORIGINAL_UNWRAP = _unwrap

def _unwrap(context, method: str = "SMART") -> bool:
    method_u = str(method or 'SMART').upper()
    mode_map = {
        'SMART': 'SMART',
        'UNWRAP_SMART': 'SMART',
        'AUTO': 'SMART',
        'FLAT': 'FLAT_MAPPING',
        'FLAT_MAPPING': 'FLAT_MAPPING',
        'ANGLE': 'BLENDER_ANGLE_BASED',
        'ANGLE_BASED': 'BLENDER_ANGLE_BASED',
        'CONFORMAL': 'BLENDER_CONFORMAL',
        'LSCM': 'BLENDER_CONFORMAL',
        'MIN_STRETCH': 'BLENDER_MIN_STRETCH',
        'MINIMUM_STRETCH': 'BLENDER_MIN_STRETCH',
        'SMART_PROJECT': 'BLENDER_SMART_PROJECT',
        'LIGHTMAP': 'BLENDER_LIGHTMAP_PACK',
        'LIGHTMAP_PACK': 'BLENDER_LIGHTMAP_PACK',
        'FOLLOW_QUADS': 'BLENDER_FOLLOW_ACTIVE_QUADS',
        'FOLLOW_ACTIVE_QUADS': 'BLENDER_FOLLOW_ACTIVE_QUADS',
        'BOX': 'BOX_PROJECT',
        'CUBE': 'BOX_PROJECT',
        'BOX_PROJECT': 'BOX_PROJECT',
        'CYLINDER': 'CYLINDRICAL',
        'CYLINDRICAL': 'CYLINDRICAL',
        'SPHERE': 'SPHERICAL',
        'SPHERICAL': 'SPHERICAL',
        'VIEW': 'VIEW_PROJECT',
        'VIEW_PROJECT': 'VIEW_PROJECT',
        'UNITIZE': 'UNITIZE_FACES',
        'UNITIZE_FACES': 'UNITIZE_FACES',
    }
    mode = mode_map.get(method_u)
    if mode:
        try:
            return bool(_safe_call('smart_uv_suite.unwrap_auto_action', mode=mode))
        except Exception:
            pass
    old = globals().get('_NATIVE_UNIFIED_1626_ORIGINAL_UNWRAP')
    return bool(old(context, method)) if callable(old) else False

# ---------------------------------------------------------------------------
# 1.6.27 Complete projection routing for strict UV-face unwrap scope
# ---------------------------------------------------------------------------
_NATIVE_UNIFIED_1627_ORIGINAL_UNWRAP = _unwrap
_NATIVE_UNIFIED_1627_ORIGINAL_DISPATCH = _dispatch

def _unwrap(context, method: str = "SMART") -> bool:
    method_u = str(method or 'SMART').upper()
    mode_map = {
        'SMART': 'SMART', 'UNWRAP_SMART': 'SMART', 'AUTO': 'SMART',
        'FLAT': 'FLAT_MAPPING', 'FLAT_MAPPING': 'FLAT_MAPPING',
        'ANGLE': 'BLENDER_ANGLE_BASED', 'ANGLE_BASED': 'BLENDER_ANGLE_BASED',
        'CONFORMAL': 'BLENDER_CONFORMAL', 'LSCM': 'BLENDER_CONFORMAL',
        'MIN_STRETCH': 'BLENDER_MIN_STRETCH', 'MINIMUM_STRETCH': 'BLENDER_MIN_STRETCH',
        'SMART_PROJECT': 'BLENDER_SMART_PROJECT', 'LIGHTMAP': 'BLENDER_LIGHTMAP_PACK', 'LIGHTMAP_PACK': 'BLENDER_LIGHTMAP_PACK',
        'FOLLOW_QUADS': 'BLENDER_FOLLOW_ACTIVE_QUADS', 'FOLLOW_ACTIVE_QUADS': 'BLENDER_FOLLOW_ACTIVE_QUADS',
        'BOX': 'BOX_PROJECT', 'CUBE': 'BOX_PROJECT', 'BOX_PROJECT': 'BOX_PROJECT',
        'CYLINDER': 'CYLINDRICAL', 'CYLINDRICAL': 'CYLINDRICAL',
        'SPHERE': 'SPHERICAL', 'SPHERICAL': 'SPHERICAL',
        'VIEW': 'VIEW_PROJECT', 'VIEW_PROJECT': 'VIEW_PROJECT',
        'PLANAR': 'QUICK_PLANAR', 'QUICK_PLANAR': 'QUICK_PLANAR', 'WORLD': 'QUICK_PLANAR', 'PROJECT_WORLD': 'QUICK_PLANAR',
        'UNITIZE': 'UNITIZE_FACES', 'UNITIZE_FACES': 'UNITIZE_FACES',
    }
    mode = mode_map.get(method_u)
    if mode:
        try:
            return bool(_safe_call('smart_uv_suite.unwrap_auto_action', mode=mode))
        except Exception:
            pass
    old = globals().get('_NATIVE_UNIFIED_1627_ORIGINAL_UNWRAP')
    return bool(old(context, method)) if callable(old) else False


def _dispatch(context, operator, action: str) -> bool:
    action_u = str(action or '').upper()
    if action_u in {'PROJECT_WORLD'}:
        return bool(_unwrap(context, 'QUICK_PLANAR'))
    old = globals().get('_NATIVE_UNIFIED_1627_ORIGINAL_DISPATCH')
    return bool(old(context, operator, action)) if callable(old) else False
