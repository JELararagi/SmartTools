"""Route quality and layout inspection buttons to their native operations."""

import bpy


def _audit(context, op):
    return 'FINISHED' in bpy.ops.uv.suv_quality_audit_suite(open_after_write=False)


def _clear_notices(context, op):
    return 'FINISHED' in bpy.ops.uv.suv_quality_clear_notice_cache()


def _prepare_context(context, op):
    return 'FINISHED' in bpy.ops.uv.suv_quality_prepare_context_basics()


def _scan_readiness(context, op):
    return 'FINISHED' in bpy.ops.uv.suv_quality_scan_context_readiness()


def build_handlers(api):
    def unavailable_document_tool(context, op):
        # key を同梱の native action の一覧（data/jel_native_feature_matrix.json）で引き、一致すればその action を実行する（PD34C v2）
        key = str(getattr(op, 'key', '') or '').strip().upper().replace('-', '_').replace(' ', '_')
        if key:
            from . import uv_router
            entry = uv_router.find_feature(key)
            if entry and entry.get('native'):
                return 'FINISHED' in bpy.ops.smart_uv_suite.native_hub_action('EXEC_DEFAULT', action=entry['key'])
        api._warn(context, op, 'No named document tool mapping is available for this request.',
                  'この要求に対応する名前付きドキュメントツールの割り当てがありません。')
        return False

    def inspect_overlap_and_flip(context, op):
        rows = api._edit_targets(context)
        if not rows:
            return api._no_uv(context, op)
        scan = api._scan(context, rows)
        for _obj, mesh, _uv in rows:
            overlaps = scan['overlap'].get(mesh, set())
            flipped = scan['flipped'].get(mesh, set())
            api._select_faces(context, mesh, overlaps | flipped)
        api._flush(rows)
        counts = api._counts(scan)
        overlap, flipped = counts['overlap'], counts['flipped']
        api._info(context, op, f'UV check: {overlap} overlapping faces, {flipped} flipped faces.',
                  f'UV 検査: 重なり {overlap} 面、裏返り {flipped} 面。')
        return True

    return {
        'smart_uv_suite.inspect_apply_document_tool': api.Handler(
            unavailable_document_tool, 'Apply a named tool from the document tool mapping when available.',
            '対応表に割り当てがある場合に、名前付きドキュメントツールを適用します。'),
        'smart_uv_suite.inspect_inspection_render': api.Handler(
            inspect_overlap_and_flip, 'Select overlapping and flipped UV faces and report the count of each.',
            '重なりと裏返りのある UV 面を選択し、それぞれの面数を表示します。'),
        'smart_uv_suite.inspect_quality_audit_suite': api.Handler(_audit, 'Write a UV Suite quality audit report.', 'UV Suite の品質監査レポートを書き出します。'),
        'smart_uv_suite.inspect_quality_clear_notice_cache': api.Handler(_clear_notices, 'Clear the quality notice cache.', '品質通知キャッシュを消去します。'),
        'smart_uv_suite.inspect_quality_prepare_context_basics': api.Handler(_prepare_context, 'Prepare a selected mesh, Edit Mode, and a UV map.', '選択メッシュ、編集モード、UV マップを準備します。'),
        'smart_uv_suite.inspect_quality_scan_context_readiness': api.Handler(_scan_readiness, 'Scan the active context for UV editing readiness.', '現在のコンテキストが UV 編集に適しているか確認します。'),
        'smart_uv_suite.inspect_layout_preflight_audit': api.Handler(
            api._run_uv_layout('suv_layout_preflight_audit', scope='scope'),
            'Audit overlaps, stack candidates and tile crossings.', '重なり、スタック候補、タイルまたぎを監査します。'),
        'smart_uv_suite.inspect_layout_audit_relayout': api.Handler(
            api._run_uv_layout('suv_layout_audit_relayout', defaults={'write_json': False},
                               mode='mode', scope='scope', texture_size='texture_size',
                               margin_px='margin_px', band_count='band_count'),
            'Rank or run relayout profiles based on the preflight audit.', '事前監査の結果から再配置プロファイルを順位付けまたは実行します。'),
        'smart_uv_suite.inspect_layout_autoheal': api.Handler(
            api._run_uv_layout('suv_layout_autoheal', defaults={'write_json': False, 'repack_after': False},
                               scope='scope', texture_size='texture_size', margin_px='margin_px'),
            'Repair overlap and tile crossings with the native layout tool.', 'ネイティブの配置ツールで重なりとタイルまたぎを修復します。'),
        'smart_uv_suite.inspect_validate_workflow_assets': api.Handler(
            api._run_uv_layout('suv_validate_workflow_assets', defaults={'write_json': False}),
            'Validate bundled workflows, recipes and their preset references.', '同梱ワークフロー、レシピ、参照プリセットを検証します。'),
        'smart_uv_suite.inspect_workspace_auto_repair': api.Handler(
            api._run_uv_layout('suv_workspace_auto_repair'),
            'Repair missing UV maps and workspace setup.', '未作成の UV マップとワークスペースの設定を修復します。'),
        'smart_uv_suite.inspect_cleanup_bridge': api.Handler(
            api._run_uv_layout('suv_cleanup_bridge', mode='mode'),
            'Apply the selected UV cleanup operation.', '指定した UV クリーンアップ処理を適用します。'),
        'smart_uv_suite.inspect_batch_object_to_udim_tiles': api.Handler(
            api._run_uv_layout('suv_batch_object_to_udim_tiles', scope='scope', layout_mode='mode', padding_uv='padding'),
            'Move each selected mesh to its own UDIM tile and write a batch report.',
            '選択メッシュを個別の UDIM タイルへ移動し、一括処理レポートを作成します。'),
        'smart_uv_suite.density_guard_normalize': api.Handler(
            api._run_uv_layout('suv_density_guard_normalize', defaults={'write_json': False},
                               scope='scope', target_mode='mode', texture_size='texture_size'),
            'Normalize texel density within the configured scale limits.', '倍率制限内でテクセル密度を均一化します。'),
        'smart_uv_suite.auto_unwrap_pro': api.Handler(
            api._run_uv_layout('suv_auto_unwrap_pro', angle_threshold='angle',
                               pack_margin_px='margin_px', texture_size='texture_size'),
            'Run the full Auto Unwrap Pro workflow.', '自動展開 Pro のワークフローを実行します。'),
    }
