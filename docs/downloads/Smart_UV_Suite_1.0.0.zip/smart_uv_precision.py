# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

'UV Suite Precision Engine.\n\nLocal high-precision routing layer for UV Suite.  It does not copy or\nembed third-party UV engines.  Instead it combines Blender-core operators,\nUV Suite operators, and measurable pre/post checks into deterministic\nquality passes that approximate the strongest workflows described in the UV\nresearch documents.\n'
from . import resource_api_18168 as _suv_resource

import json
import os
import math
import time
from pathlib import Path

import bpy


def _is_ja(context=None):
    try:
        lang = str(getattr(getattr(context, 'preferences', None).view, 'language', '') or '')
    except Exception:
        lang = ''
    return lang.startswith('ja') or lang.startswith('jp') or lang == 'DEFAULT_JAPANESE'


def _tr(context, en, ja):
    return str(ja if _is_ja(context) else en)


def _workspace_values(context):
    ws = None
    try:
        ws = getattr(getattr(context, 'scene', None), 'suv_workspace', None)
    except Exception:
        ws = None
    try:
        texture_size = int(getattr(ws, 'canvas_size', 2048) or 2048)
    except Exception:
        texture_size = 2048
    try:
        margin_px = int(getattr(ws, 'fit_padding_px', 8) or 8)
    except Exception:
        margin_px = 8
    try:
        margin_strategy = str(getattr(ws, 'smart_margin_strategy', 'BALANCED') or 'BALANCED').upper()
        if margin_strategy == 'BAKE_SAFE':
            margin_px = max(margin_px, 24)
        elif margin_strategy == 'DENSE':
            margin_px = max(1, int(round(margin_px * 0.55)))
    except Exception:
        pass
    try:
        density = float(getattr(ws, 'workflow_density', 1024.0) or 1024.0)
    except Exception:
        density = 1024.0
    return max(128, texture_size), max(0, min(1024, margin_px)), max(1.0, density)


def _precision_settings(context):
    ws = None
    try:
        ws = getattr(getattr(context, 'scene', None), 'suv_workspace', None)
    except Exception:
        ws = None
    try:
        level = str(getattr(ws, 'smart_precision_level', 'ULTRA') or 'ULTRA').upper()
    except Exception:
        level = 'ULTRA'
    try:
        iterations = int(getattr(ws, 'smart_relax_iterations', 96) or 96)
    except Exception:
        iterations = 96
    if level == 'SAFE':
        iterations = max(16, min(iterations, 64))
    elif level == 'EXTREME':
        iterations = max(iterations, 160)
    else:
        iterations = max(iterations, 96)
    try:
        candidates = int(getattr(ws, 'smart_pack_candidates', 4) or 4)
    except Exception:
        candidates = 4
    if level == 'SAFE':
        candidates = max(1, min(candidates, 2))
    elif level == 'EXTREME':
        candidates = max(candidates, 6)
    else:
        candidates = max(candidates, 4)
    try:
        lock_overlaps = bool(getattr(ws, 'smart_lock_overlaps', False))
    except Exception:
        lock_overlaps = False
    try:
        sliver = bool(getattr(ws, 'smart_sliver_protection', True))
    except Exception:
        sliver = True
    return {
        'level': level,
        'iterations': max(0, min(512, iterations)),
        'candidates': max(1, min(12, candidates)),
        'lock_overlaps': lock_overlaps,
        'sliver_protection': sliver,
    }


def _operator_proxy(op_id):
    text = str(op_id or '').strip()
    if '.' not in text:
        return None
    group, name = text.split('.', 1)
    try:
        ops_group = getattr(getattr(bpy, 'ops', None), group, None)
        return getattr(ops_group, name, None) if ops_group is not None else None
    except Exception:
        return None


def _rna_identifier_is_real(identifier):
    text = str(identifier or '').strip()
    return bool(text) and text not in {'Operator', 'OperatorProperties', 'UnknownType', 'bpy_struct'}


def _operator_rna(op_id):
    op = _operator_proxy(op_id)
    if op is None:
        return None
    try:
        rna = op.get_rna_type()
        if not _rna_identifier_is_real(getattr(rna, 'identifier', '')):
            return None
        return rna
    except Exception:
        return None


def operator_exists(op_id):
    return _operator_rna(op_id) is not None


def _property_names(op_id):
    rna = _operator_rna(op_id)
    names = set()
    if rna is None:
        return names
    try:
        props = getattr(rna, 'properties', None)
        try:
            names.update(str(k) for k in props.keys())
        except Exception:
            pass
        try:
            for prop in props:
                ident = str(getattr(prop, 'identifier', '') or '')
                if ident:
                    names.add(ident)
        except Exception:
            pass
    except Exception:
        pass
    return names


def _filtered_kwargs(op_id, kwargs):
    if not kwargs:
        return {}
    names = _property_names(op_id)
    if not names:
        return {}
    return {str(k): v for k, v in dict(kwargs).items() if str(k) in names}


def _call(op_id, **kwargs):
    op = _operator_proxy(op_id)
    if op is None or not operator_exists(op_id):
        return False
    safe = _filtered_kwargs(op_id, kwargs)
    attempts = (
        (('EXEC_DEFAULT',), safe),
        (tuple(), safe),
        (('EXEC_DEFAULT',), {}),
        (tuple(), {}),
    )
    for args, call_kwargs in attempts:
        try:
            result = op(*args, **call_kwargs)
            try:
                return 'CANCELLED' not in set(result or set())
            except Exception:
                return True
        except TypeError:
            continue
        except Exception:
            continue
    return False


def _run_first(candidates, log=None, label=''):
    for op_id, kwargs in candidates:
        ok = _call(op_id, **dict(kwargs or {}))
        if log is not None:
            log.append({'label': label or op_id, 'operator': op_id, 'ok': bool(ok)})
        if ok:
            return True
    return False


def _run_chain(groups, log=None, *, require_each=False):
    any_ok = False
    for index, group in enumerate(groups):
        ok = _run_first(group, log=log, label=f'stage_{index + 1}')
        any_ok = any_ok or ok
        if require_each and not ok:
            return False
    return any_ok


def _ensure_mesh_context(context):
    try:
        obj = getattr(context, 'active_object', None)
        if obj is None or getattr(obj, 'type', '') != 'MESH':
            return False
        if str(getattr(obj, 'mode', '') or '') != 'EDIT':
            try:
                bpy.ops.object.mode_set(mode='EDIT')
            except Exception:
                pass
        return True
    except Exception:
        return False


def _vec_area2(a, b, c):
    try:
        ab = b - a
        ac = c - a
        cross = ab.cross(ac)
        return float(cross.length) * 0.5
    except Exception:
        return 0.0


def _uv_area2(a, b, c):
    try:
        return float(((b.x - a.x) * (c.y - a.y)) - ((b.y - a.y) * (c.x - a.x))) * 0.5
    except Exception:
        return 0.0


def collect_metrics(context=None, *, selected_only=True):
    metrics = {
        'ok': False,
        'faces': 0,
        'world_area': 0.0,
        'uv_area': 0.0,
        'zero_area_faces': 0,
        'flipped_triangles': 0,
        'density_min': 0.0,
        'density_max': 0.0,
        'density_average': 0.0,
        'density_spread_percent': 0.0,
        'timestamp': time.strftime('%Y-%m-%dT%H:%M:%S'),
    }
    try:
        import bmesh
        obj = getattr(context, 'active_object', None) if context is not None else None
        if obj is None or getattr(obj, 'type', '') != 'MESH':
            return metrics
        tex, _margin, _density = _workspace_values(context)
        was_edit = str(getattr(obj, 'mode', '') or '') == 'EDIT'
        if not was_edit:
            try:
                bpy.ops.object.mode_set(mode='EDIT')
            except Exception:
                pass
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        faces = [f for f in bm.faces if bool(getattr(f, 'select', False))] if selected_only else list(bm.faces)
        if selected_only and not faces:
            faces = list(bm.faces)
        world_mat = getattr(obj, 'matrix_world', None)
        densities = []
        weighted = 0.0
        weight_total = 0.0
        for face in faces:
            loops = list(getattr(face, 'loops', ()) or ())
            if len(loops) < 3:
                continue
            metrics['faces'] += 1
            face_world = 0.0
            face_uv = 0.0
            base_loop = loops[0]
            for i in range(1, len(loops) - 1):
                la = base_loop
                lb = loops[i]
                lc = loops[i + 1]
                try:
                    va = world_mat @ la.vert.co if world_mat is not None else la.vert.co
                    vb = world_mat @ lb.vert.co if world_mat is not None else lb.vert.co
                    vc = world_mat @ lc.vert.co if world_mat is not None else lc.vert.co
                except Exception:
                    va, vb, vc = la.vert.co, lb.vert.co, lc.vert.co
                wa = _vec_area2(va, vb, vc)
                try:
                    ua = la[uv_layer].uv.copy()
                    ub = lb[uv_layer].uv.copy()
                    uc = lc[uv_layer].uv.copy()
                    signed = _uv_area2(ua, ub, uc)
                    uva = abs(signed)
                    if signed < -1.0e-12:
                        metrics['flipped_triangles'] += 1
                except Exception:
                    uva = 0.0
                face_world += wa
                face_uv += uva
            metrics['world_area'] += face_world
            metrics['uv_area'] += face_uv
            if face_world <= 1.0e-12 or face_uv <= 1.0e-12:
                metrics['zero_area_faces'] += 1
                continue
            d = math.sqrt(face_uv) * float(tex) / max(1.0e-12, math.sqrt(face_world))
            densities.append(d)
            weighted += d * face_world
            weight_total += face_world
        if densities:
            metrics['density_min'] = float(min(densities))
            metrics['density_max'] = float(max(densities))
            metrics['density_average'] = float(weighted / max(1.0e-12, weight_total))
            if metrics['density_average'] > 1.0e-12:
                metrics['density_spread_percent'] = float((metrics['density_max'] - metrics['density_min']) / metrics['density_average'] * 100.0)
        # Production quality score: intentionally simple and deterministic.
        # It penalizes UV-degenerate faces, flipped UV triangles and density spread.
        face_count = max(1, int(metrics.get('faces') or 0))
        zero_ratio = float(metrics.get('zero_area_faces') or 0) / face_count
        flipped_ratio = float(metrics.get('flipped_triangles') or 0) / max(1, face_count * 2)
        spread = float(metrics.get('density_spread_percent') or 0.0)
        score = 100.0
        score -= min(35.0, zero_ratio * 180.0)
        score -= min(30.0, flipped_ratio * 180.0)
        score -= min(30.0, spread / 3.5)
        if metrics.get('uv_area', 0.0) <= 1.0e-12:
            score -= 20.0
        score = max(0.0, min(100.0, score))
        metrics['quality_score'] = float(round(score, 3))
        metrics['quality_grade'] = 'S' if score >= 96 else ('A' if score >= 88 else ('B' if score >= 76 else ('C' if score >= 60 else 'D')))
        metrics['ok'] = bool(metrics['faces'])
    except Exception as exc:
        metrics['error'] = str(exc).splitlines()[0]
    return metrics


def write_precision_report(context=None, payload=None):
    data = dict(payload or {})
    data.setdefault('metrics', collect_metrics(context))
    data.setdefault('precision_settings', _precision_settings(context))
    data.setdefault('schema', 'smart_uv_precision_report_v2')
    try:
        from . import storage
        path = Path(storage.runtime_file('smart_uv_precision_report.json', 'reports', create=True))
    except Exception:
        path = (Path(os.environ.get('APPDATA')) / 'Blender Foundation' / 'Blender' / '5.1' / 'config' / 'Smart_UV_Suite' / 'user_data' / 'runtime' / 'reports' / 'smart_uv_precision_report.json') if os.environ.get('APPDATA') else (Path.home() / '.config' / 'blender' / '5.1' / 'config' / 'Smart_UV_Suite' / 'user_data' / 'runtime' / 'reports' / 'smart_uv_precision_report.json')
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
        try:
            text = bpy.data.texts.get('Smart_UV_Suite_Precision_Report') or bpy.data.texts.new('Smart_UV_Suite_Precision_Report')
            text.clear()
            text.write(json.dumps({
                'schema': data.get('schema'),
                'action': data.get('action'),
                'metrics': data.get('metrics'),
                'stages': data.get('stages', []),
            }, ensure_ascii=False, indent=2))
        except Exception:
            pass
        return True
    except Exception:
        return False


def _preflight_group(tex, margin, density):
    return [
        ('uv.suv_layout_preflight_audit', {'scope': 'ALL', 'texture_size': tex, 'margin_px': margin}),
        ('uv.suv_inspector_scan', {'scope': 'ALL', 'check_overlap': True, 'check_stretch': True, 'check_out_of_tile': True}),
    ]


def _auto_seam_group():
    return [
        ('uv.suv_auto_seam_advanced', {'mode': 'ANGLE', 'angle_threshold': math.radians(55.0), 'scope': 'ALL'}),
        ('uv.suv_auto_seam_advanced', {'mode': 'SHARP', 'scope': 'ALL'}),
        ('uv.suv_smart_seams', {}),
    ]


def _unwrap_group(tex, margin):
    uv_margin = max(0.001, float(margin) / max(1.0, float(tex)))
    return [
        ('uv.suv_native_projection', {'mode': 'UNWRAP_ABF', 'relax_after': False, 'pack_after': False, 'apply_density': False}),
        ('uv.suv_native_projection', {'mode': 'MIN_STRETCH', 'relax_after': False, 'pack_after': False, 'apply_density': False}),
        ('uv.unwrap', {'method': 'ANGLE_BASED', 'margin': uv_margin}),
        ('uv.unwrap', {'method': 'CONFORMAL', 'margin': uv_margin}),
    ]


def _relax_group(context=None):
    settings = _precision_settings(context)
    iterations = int(settings.get('iterations', 96) or 96)
    return [
        ('uv.suv_constraint_relax_preserve', {'iterations': iterations, 'preserve_boundary': True}),
        ('uv.suv_cleanup_bridge', {'mode': 'OPTIMIZE_REALTIME', 'iterations': iterations}),
        ('uv.minimize_stretch', {'iterations': iterations}),
        ('smart_uv_suite.native_hub_action', {}),
    ]


def _density_group(tex, margin, density):
    return [
        ('uv.suv_density_guard_normalize', {'target_density': density, 'texture_size': tex, 'margin_px': margin, 'scope': 'ALL'}),
        ('uv.suv_texel_normalize', {'mode': 'AVERAGE', 'value_density': density, 'texture_size': tex, 'use_world_scale': True, 'skip_pinned': True}),
        ('uv.suv_texel_set', {'scope': 'SELECTED', 'target_density': density, 'texture_size': tex, 'use_world_scale': True, 'skip_pinned': True, 'keep_tile': True}),
    ]


def _pack_group(tex, margin, *, density_priority=False, keep_tiles=False, group_mode='SIMILAR', context=None):
    settings = _precision_settings(context)
    uv_margin = max(0.001, float(margin) / max(1.0, float(tex)))
    candidates = int(settings.get('candidates', 4) or 4)
    lock_overlaps = bool(settings.get('lock_overlaps', False)) or bool(keep_tiles)
    area_tol = 0.02 if settings.get('level') == 'EXTREME' else 0.035
    aspect_tol = 0.035 if settings.get('level') == 'EXTREME' else 0.055
    rotations = ['15', '45', '90', '0']
    group = []
    if density_priority:
        group.append(('uv.suv_priority_density_pack', {'texture_size': tex, 'margin_px': margin, 'scope': 'SELECTED'}))
    if lock_overlaps:
        group.extend([
            ('uv.suv_stack_topology_groups', {'scope': 'ALL', 'rotation_step': '15', 'allow_mirror': True, 'preserve_tile': True}),
            ('uv.suv_stack_grouped', {'mode': 'IDENTICAL', 'area_tol': area_tol, 'aspect_tol': aspect_tol, 'rotation_step': '15', 'allow_mirror': True}),
        ])
    for rot in rotations[:max(1, min(len(rotations), candidates))]:
        group.append(('uv.suv_pack_pro', {
            'engine': 'DETERMINISTIC', 'scope': 'SELECTED', 'udim_mode': 'KEEP_TILES' if keep_tiles else 'SINGLE',
            'margin_px': margin, 'texture_size': tex, 'rotation_step': rot, 'group_mode': group_mode,
            'group_layout': 'TILES' if keep_tiles else 'SINGLE_TILE', 'area_tol': area_tol, 'aspect_tol': aspect_tol,
            'stack_identical_groups': True, 'lock_pinned': True,
        }))
    group.extend([
        ('uv.suv_pack_pro', {'engine': 'DETERMINISTIC', 'scope': 'ALL', 'udim_mode': 'KEEP_TILES' if keep_tiles else 'SINGLE', 'margin_px': margin, 'texture_size': tex, 'rotation_step': '15', 'lock_pinned': True}),
        ('uv.pack_islands', {'margin': uv_margin, 'rotate': True}),
        ('smart_uv_suite.native_hub_action', {}),
    ])
    return group


def _postflight_group(tex, margin, density):
    return [
        ('uv.suv_layout_candidate_audit', {'texture_size': tex, 'margin_px': margin, 'target_density': density}),
        ('uv.suv_inspector_scan', {'scope': 'ALL', 'check_overlap': True, 'check_stretch': True, 'check_out_of_tile': True}),
        ('uv.suv_inspector_write_report', {}),
    ]


def _run_super_auto(context, *, safe=False):
    tex, margin, density = _workspace_values(context)
    log = []
    groups = [
        _preflight_group(tex, margin, density),
        _auto_seam_group() if not safe else [('uv.suv_layout_preflight_audit', {'scope': 'ALL'})],
        _unwrap_group(tex, margin),
        _relax_group(context),
        _density_group(tex, margin, density),
        _pack_group(tex, margin, density_priority=True, group_mode='SIMILAR', context=context),
        _postflight_group(tex, margin, density),
    ]
    ok = _run_chain(groups, log=log, require_each=False)
    write_precision_report(context, {'action': 'SUPER_AUTO_SAFE' if safe else 'SUPER_AUTO', 'stages': log})
    return bool(ok)


def _run_super_unwrap(context):
    tex, margin, density = _workspace_values(context)
    log = []
    ok = _run_chain([
        _preflight_group(tex, margin, density),
        _auto_seam_group(),
        _unwrap_group(tex, margin),
        _relax_group(context),
        _density_group(tex, margin, density),
        _postflight_group(tex, margin, density),
    ], log=log, require_each=False)
    write_precision_report(context, {'action': 'SUPER_UNWRAP', 'stages': log})
    return bool(ok)


def _run_super_pack(context, *, density_priority=True, keep_tiles=False):
    tex, margin, density = _workspace_values(context)
    log = []
    ok = _run_chain([
        _preflight_group(tex, margin, density),
        _density_group(tex, margin, density),
        _pack_group(tex, margin, density_priority=density_priority, keep_tiles=keep_tiles, group_mode='SIMILAR', context=context),
        _postflight_group(tex, margin, density),
    ], log=log, require_each=False)
    write_precision_report(context, {'action': 'SUPER_PACK', 'stages': log})
    return bool(ok)


def _run_super_density(context):
    tex, margin, density = _workspace_values(context)
    log = []
    before = collect_metrics(context)
    ok = _run_chain([
        [('uv.suv_texel_get', {'scope': 'SELECTED', 'texture_size': tex, 'use_world_scale': True})],
        _density_group(tex, margin, density),
        [('object.suv_create_checker_material', {})],
        _postflight_group(tex, margin, density),
    ], log=log, require_each=False)
    after = collect_metrics(context)
    write_precision_report(context, {'action': 'SUPER_DENSITY', 'before': before, 'after': after, 'stages': log})
    return bool(ok)


def _run_super_repair(context):
    tex, margin, density = _workspace_values(context)
    log = []
    ok = _run_chain([
        _preflight_group(tex, margin, density),
        [('uv.suv_inspector_fix_flipped', {}), ('uv.suv_repair_flipped_islands', {})],
        [('uv.suv_layout_autoheal', {}), ('uv.suv_fix_all_issues', {})],
        [('uv.suv_unstack_overlapped', {'offset_px': margin, 'texture_size': tex}), ('uv.suv_unstack_groups', {})],
        _density_group(tex, margin, density),
        _pack_group(tex, margin, density_priority=True, group_mode='SIMILAR', context=context),
        _postflight_group(tex, margin, density),
    ], log=log, require_each=False)
    write_precision_report(context, {'action': 'SUPER_REPAIR', 'stages': log})
    return bool(ok)


def _run_super_analyze(context):
    metrics = collect_metrics(context)
    return write_precision_report(context, {'action': 'SUPER_ANALYZE', 'metrics': metrics, 'stages': []})


def run_precision_action(action, context=None):
    action = str(action or '').strip().upper()
    _ensure_mesh_context(context)
    if action in {'SUPER_AUTO', 'FULL_AUTO', 'UVMASTER_LOCAL', 'MINISTRY_FLAT_LOCAL', 'SMART_STANDARD_AUTO', 'SUBSTANCE_AUTO_PREP'}:
        return _run_super_auto(context, safe=False)
    if action in {'SUPER_SAFE_AUTO', 'AUTO_UV_SAFE', 'UNITY_PROBUILDER', 'UE_LIGHTMAP'}:
        return _run_super_auto(context, safe=True)
    if action in {'SUPER_UNWRAP', 'UNWRAP_ABF', 'UNWRAP_LSCM', 'UNWRAP_SLIM', 'OPTIMIZE_RELAX', 'RELAX_PRESERVE', 'PELT_UNWRAP'}:
        return _run_super_unwrap(context)
    if action in {'SUPER_PACK', 'PACK_HEURISTIC', 'PACK_EXACT', 'PACK_BBOX', 'PRIORITY_DENSITY_PACK', 'LOCK_OVERLAP_PACK', 'UVPACKMASTER_BRIDGE', 'RIZOM_BRIDGE', 'HEADUS_BRIDGE'}:
        return _run_super_pack(context, density_priority=True, keep_tiles=(action == 'LOCK_OVERLAP_PACK'))
    if action in {'SUPER_DENSITY', 'TD_GET', 'TD_SET', 'TD_NORMALIZE', 'TD_WORLD_SCALE'}:
        return _run_super_density(context)
    if action in {'SUPER_REPAIR', 'FIX_ALL', 'INSPECT_SCAN', 'STRETCH_HEATMAP', 'DISTORTION_SHADER', 'HISTOGRAM'}:
        return _run_super_repair(context)
    if action in {'SUPER_ANALYZE', 'REPORT_MATRIX'}:
        return _run_super_analyze(context)
    return False


def enhance_action(action, context=None):
    return run_precision_action(action, context)


def enhance_feature(entry, context=None):
    if not isinstance(entry, dict):
        return False
    text = ' '.join(str(entry.get(k) or '') for k in ('tool', 'feature', 'category', 'detail', 'detail_en')).lower()
    if any(word in text for word in ('pack', 'packing', 'udim', 'tile', 'uvpackmaster', 'rizom', 'headus')):
        return _run_super_pack(context, density_priority=True)
    if any(word in text for word in ('texel', 'density', 'world scale', 'checker')):
        return _run_super_density(context)
    if any(word in text for word in ('inspect', 'overlap', 'flipped', 'stretch', 'distortion', 'repair', 'fix')):
        return _run_super_repair(context)
    if any(word in text for word in ('unwrap', 'unfold', 'relax', 'seam', 'pelt', 'peel', 'slim', 'lscm', 'abf')):
        return _run_super_unwrap(context)
    if any(word in text for word in ('auto', 'substance', 'uv master', 'ministry', 'smart_standard')):
        return _run_super_auto(context)
    return False


_PRECISION_ACTION_ITEMS = (
    ('SUPER_AUTO', 'Supreme Auto', 'Full precision auto seam, unwrap, relax, density, pack, and inspection.'),
    ('SUPER_SAFE_AUTO', 'Safe Supreme Auto', 'Safer high precision route that avoids aggressive seam changes when possible.'),
    ('SUPER_UNWRAP', 'Supreme Unwrap', 'High precision unwrap and relax route with postflight checks.'),
    ('SUPER_PACK', 'Supreme Pack', 'Density-aware deterministic pack route with candidate audit.'),
    ('SUPER_DENSITY', 'Supreme Density', 'Measure, normalize, checker, and post-scan density route.'),
    ('SUPER_REPAIR', 'Supreme Repair', 'Run flipped/overlap/autoheal repair and finish with density-aware pack.'),
    ('SUPER_ANALYZE', 'Precision Analyze', 'Write metrics and quality report without changing the UV layout.'),
)


class SMARTUVPRECISION_OT_action(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.smart_uv_precision_action'
    bl_label = 'Precision Action'
    bl_description = 'Run a maximum-precision UV Suite route. These actions combine measurable preflight checks, high quality unwrap/pack/density stages, and postflight reports.'
    bl_options = {'UNDO'}

    action: bpy.props.EnumProperty(name='Action', items=_PRECISION_ACTION_ITEMS, default='SUPER_AUTO', options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        action = str(getattr(properties, 'action', '') or 'SUPER_AUTO')
        labels = {key: (en, desc) for key, en, desc in _PRECISION_ACTION_ITEMS}
        label, desc = labels.get(action, labels['SUPER_AUTO'])
        ja_map = {
            'SUPER_AUTO': '最高精度の自動UV処理を実行します。プリフライト、シーム、展開、リラックス、密度、パック、検査を連続実行します。',
            'SUPER_SAFE_AUTO': '既存の構造をなるべく壊さない安全寄りの最高精度自動UV処理です。',
            'SUPER_UNWRAP': '展開とリラックスの精度を優先し、完了後に検査レポートを作成します。',
            'SUPER_PACK': '密度と余白を考慮して高密度なパック候補を実行し、結果を検査します。',
            'SUPER_DENSITY': 'テクセル密度を測定・正規化し、チェッカーと検査で確認できる状態へ整えます。',
            'SUPER_REPAIR': '反転、重なり、破損、密度差をできる限り自動修復してから整理します。',
            'SUPER_ANALYZE': 'UVを変更せず、現在のUV品質メトリクスだけを書き出します。',
        }
        return _tr(context, f'{label}: {desc}', ja_map.get(action, desc))

    def execute(self, context):
        action = str(getattr(self, 'action', 'SUPER_AUTO') or 'SUPER_AUTO')
        if run_precision_action(action, context):
            self.report({'INFO'}, _tr(context, 'UV Suite precision route completed.', 'UV Suite最高精度ルートが完了しました。'))
            return {'FINISHED'}
        self.report({'WARNING'}, _tr(context, 'UV Suite precision route could not complete in the current mesh/UV context.', '現在のメッシュ/UV状態ではUV Suite最高精度ルートを完了できませんでした。'))
        return {'CANCELLED'}


_CLASSES = (SMARTUVPRECISION_OT_action,)
_REGISTERED = []


def register():
    try:
        from .bootstrap_common import safe_register_class
    except Exception:
        safe_register_class = None
    for cls in _CLASSES:
        ok = False
        if callable(safe_register_class):
            try:
                ok = bool(safe_register_class(cls))
            except Exception:
                ok = False
        if not ok:
            try:
                _suv_resource.register_class(cls)
                ok = True
            except Exception:
                ok = False
        if ok and cls not in _REGISTERED:
            _REGISTERED.append(cls)


def unregister():
    for cls in reversed(_REGISTERED or list(_CLASSES)):
        try:
            _suv_resource.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED.clear()


__all__ = ['register', 'unregister', 'run_precision_action', 'enhance_action', 'enhance_feature', 'collect_metrics', 'write_precision_report', 'operator_exists']
