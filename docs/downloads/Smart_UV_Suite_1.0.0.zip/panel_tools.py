# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Dedicated behaviour for the Smart UV panel buttons.

``unified_uv_tools`` registers these operator ids; when an id is listed in
``HANDLERS`` the operator runs the handler below.
"""

from __future__ import annotations

import json
import math
import sys
from collections import deque
from dataclasses import dataclass
from typing import Any, Callable, Optional

import bmesh
import bpy
from mathutils import Vector
from mathutils.kdtree import KDTree

from . import unified_uv_tools as _u
from . import (
    uv_repair_align_pie,
    uv_repair_align_seam,
    uv_repair_snap_targets,
    uv_repair_align_stretch,
    uv_repair_division,
    uv_repair_inspect_circle,
    uv_repair_inspect_clip,
    uv_repair_inspect_face,
    uv_repair_inspect_hide,
    uv_repair_inspect_inspection,
    uv_repair_inspect_lattice,
    uv_repair_inspect_offset,
    uv_repair_inspect_quality,
    uv_repair_inspect_show,
    uv_repair_inspect_similarity,
    uv_repair_inspect_stack,
    uv_repair_inspect_stage,
    uv_repair_inspect_straight,
    uv_repair_inspect_sync,
    uv_repair_inspect_wand,
    uv_repair_island_distribute,
    uv_repair_island_stretch,
    uv_repair_texel_world,
    uv_repair_unwrap_normal,
    uv_repair_unwrap_project,
    uv_repair_unwrap_projection,
    uv_repair_unwrap_view,
    uv_repair_uv_list_crud,
    uv_repair_view_cockpit,
    uv_repair_view_fit,
    uv_repair_weld_seam,
    uv_repair_workflow_add,
    uv_repair_workflow_modifiers,
    uv_repair_workflow_move,
    uv_repair_workflow_preferences,
    uv_repair_workflow_remove,
    uv_repair_workflow_scale,
    uv_repair_workflow_set,
    uv_repair_workflow_toggle,
    uv_repair_workflow_uvw,
    uv_repair_align,
    uv_repair_gridify,
    uv_repair_pack_horizontal,
    uv_repair_pack_load,
    uv_repair_pack_match,
    uv_repair_pack_random,
    uv_repair_pack_randomize,
    uv_repair_pack_shuffle,
    uv_repair_pack_stage,
    uv_repair_pack_unstack,
    uv_repair_projection_gizmo,
    uv_repair_seam_angle,
    uv_repair_seam_batch,
    uv_repair_seam_border,
    uv_repair_seam_cut,
    uv_repair_seam_edit,
    uv_repair_seam_gap,
    uv_repair_seam_join,
    uv_repair_seam_mark,
    uv_repair_seam_match,
    uv_repair_seam_paste,
    uv_repair_seam_symmetrize,
    uv_repair_select_border,
    uv_repair_stitch_stitch,
    uv_repair_texel_flatten,
    uv_repair_texel_layers,
    uv_repair_texel_priority,
    uv_repair_texel_reset,
    uv_repair_workflow_world,
)
from .base import _UVOverride
from .core import _get_sets, _set_sets

_BAKE_UV = 'UV_Bake'
_BAKE_IMAGE = 'SmartUV_Bake'
_BAKE_NODE = 'SmartUV Bake Target'
_BAKED_MATERIAL = 'SmartUV_Baked'
_ID_IMAGE = 'SmartUV_IDMap'
_BAKE_SOURCE_ATTR = '.suv_bake_source_material'
_BAKE_UV_KEY = 'smart_uv_bake_uv'
_DIAG_TEXT = 'Smart UV Diagnostics'
_REPORT_MARK = 'smart_uv_report'
_EPS = 1.0e-5
_SIMILAR_RATIO = 0.2
_MAX_OVERLAP_TRIS = 200000


def _t(context, en: str, ja: str) -> str:
    return _u._t(context, en, ja)


def _info(context, op, en: str, ja: str) -> None:
    _u._message(context, op, en, ja)


def _warn(context, op, en: str, ja: str) -> None:
    _u._message(context, op, en, ja, 'WARNING')


def _ws(context):
    return getattr(getattr(context, 'scene', None), 'suv_workspace', None)


def _sync(context) -> bool:
    return bool(context.tool_settings.use_uv_select_sync)


# ---------------------------------------------------------------------------
# Targets and selection
# ---------------------------------------------------------------------------
def _mesh_objects(context) -> list:
    out = []
    active = getattr(context, 'active_object', None)
    if active is not None and active.type == 'MESH':
        out.append(active)
    for obj in getattr(context, 'selected_objects', []) or []:
        if obj.type == 'MESH' and obj not in out:
            out.append(obj)
    return out


def _edit_targets(context) -> list:
    """Enter Edit Mode when needed and return (object, bmesh, uv layer) rows."""
    active = getattr(context, 'active_object', None)
    if active is None or active.type != 'MESH':
        objs = _mesh_objects(context)
        if not objs:
            return []
        active = objs[0]
    if active.mode != 'EDIT':
        bpy.ops.object.mode_set(mode='EDIT')
    rows = []
    seen = set()
    for obj in (getattr(context, 'objects_in_mode_unique_data', None) or [active]):
        if obj.type != 'MESH' or obj.data in seen:
            continue
        seen.add(obj.data)
        bm = bmesh.from_edit_mesh(obj.data)
        uv = bm.loops.layers.uv.active
        if uv is None:
            continue
        bm.faces.ensure_lookup_table()
        rows.append((obj, bm, uv))
    return rows


def _flush(rows) -> None:
    for obj, _bm, _uv in rows:
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)


def _visible(face, sync: bool) -> bool:
    return (not face.hide) and (sync or face.select)


def _face_selected(face, sync: bool) -> bool:
    if face.hide or not face.select:
        return False
    if sync:
        return True
    return bool(face.uv_select) or all(l.uv_select_vert for l in face.loops)


def _select_faces(context, bm, faces, *, extend: bool = False) -> None:
    sync = _sync(context)
    faces = set(faces)
    if sync:
        if not extend:
            for f in bm.faces:
                f.select_set(False)
            for e in bm.edges:
                e.select_set(False)
            for v in bm.verts:
                v.select_set(False)
        for f in faces:
            f.select_set(True)
        bm.select_flush_mode()
        bm.uv_select_sync_valid = False
        return
    for f in faces:
        if not f.select:
            f.select_set(True)
    bm.select_flush_mode()
    if not extend:
        for f in bm.faces:
            f.uv_select_set(False)
            for l in f.loops:
                l.uv_select_vert_set(False)
                l.uv_select_edge_set(False)
    for f in faces:
        f.uv_select_set(True)
    bm.uv_select_flush_mode(flush_down=True)


def _select_edge_loops(context, bm, loops) -> None:
    sync = _sync(context)
    ts = context.tool_settings
    if sync:
        ts.mesh_select_mode = (False, True, False)
        bm.select_mode = {'EDGE'}
        for f in bm.faces:
            f.select_set(False)
        for e in bm.edges:
            e.select_set(False)
        for v in bm.verts:
            v.select_set(False)
        for l in loops:
            l.edge.select_set(True)
        bm.select_flush_mode()
        bm.uv_select_sync_valid = False
        return
    ts.uv_select_mode = 'EDGE'
    for f in bm.faces:
        f.uv_select_set(False)
        for l in f.loops:
            l.uv_select_vert_set(False)
            l.uv_select_edge_set(False)
    for l in loops:
        l.uv_select_edge_set(True)
        l.uv_select_vert_set(True)
        l.link_loop_next.uv_select_vert_set(True)


def _selected_edge_loops(context, bm) -> list:
    sync = _sync(context)
    out = []
    for f in bm.faces:
        if not _visible(f, sync):
            continue
        for l in f.loops:
            if (l.edge.select if sync else l.uv_select_edge):
                out.append(l)
    return out


# ---------------------------------------------------------------------------
# Islands and measurements
# ---------------------------------------------------------------------------
def _same_uv(a, b, uv) -> bool:
    return (a[uv].uv - b[uv].uv).length_squared <= _EPS * _EPS


def _uv_connected(l, other, uv) -> bool:
    """True when the two loops on one mesh edge share that edge in UV space."""
    if l.vert is other.vert:
        return _same_uv(l, other, uv) and _same_uv(l.link_loop_next, other.link_loop_next, uv)
    return _same_uv(l, other.link_loop_next, uv) and _same_uv(l.link_loop_next, other, uv)


def _islands(bm, uv, sync: bool) -> list:
    faces = {f for f in bm.faces if _visible(f, sync)}
    seen = set()
    out = []
    for start in bm.faces:
        if start not in faces or start in seen:
            continue
        seen.add(start)
        group = []
        queue = deque([start])
        while queue:
            f = queue.popleft()
            group.append(f)
            for l in f.loops:
                other = l.link_loop_radial_next
                while other is not l:
                    g = other.face
                    if g in faces and g not in seen and _uv_connected(l, other, uv):
                        seen.add(g)
                        queue.append(g)
                    other = other.link_loop_radial_next
        out.append(group)
    return out


def _face_uv_area(face, uv) -> float:
    return _u._face_uv_area(face, uv)


@dataclass
class _Isl:
    faces: list
    uv_area: float
    mesh_area: float
    box: tuple

    @property
    def width(self) -> float:
        return self.box[2] - self.box[0]

    @property
    def height(self) -> float:
        return self.box[3] - self.box[1]

    @property
    def density(self) -> float:
        return math.sqrt(self.uv_area / self.mesh_area) if self.mesh_area > 1.0e-12 else 0.0


def _island_info(obj, faces, uv) -> _Isl:
    us = [l[uv].uv.x for f in faces for l in f.loops]
    vs = [l[uv].uv.y for f in faces for l in f.loops]
    scale = _world_area_scale(obj)
    return _Isl(
        faces=faces,
        uv_area=sum(abs(_face_uv_area(f, uv)) for f in faces),
        mesh_area=sum(f.calc_area() for f in faces) * scale,
        box=(min(us), min(vs), max(us), max(vs)),
    )


def _world_area_scale(obj) -> float:
    s = obj.matrix_world.to_scale()
    return abs(s.x * s.y + s.y * s.z + s.z * s.x) / 3.0


def _all_islands(context, rows) -> list:
    sync = _sync(context)
    out = []
    for obj, bm, uv in rows:
        for group in _islands(bm, uv, sync):
            out.append((obj, bm, uv, _island_info(obj, group, uv)))
    return out


def _selected_scope(context, rows) -> list:
    """Islands holding a selected face, or every shown island when none is selected."""
    sync = _sync(context)
    every = _all_islands(context, rows)
    picked = [row for row in every if any(_face_selected(f, sync) for f in row[3].faces)]
    return picked or every


def _select_by_islands(context, rows, chosen) -> int:
    wanted = {}
    for obj, bm, uv, isl in chosen:
        wanted.setdefault(bm, set()).update(isl.faces)
    for _obj, bm, _uv in rows:
        _select_faces(context, bm, wanted.get(bm, set()))
    _flush(rows)
    return sum(len(v) for v in wanted.values())


def _seed_islands(context, rows) -> list:
    sync = _sync(context)
    return [row for row in _all_islands(context, rows) if any(_face_selected(f, sync) for f in row[3].faces)]


def _no_uv(context, op) -> bool:
    _warn(context, op, 'Select a mesh that has a UV map.', 'UV マップのあるメッシュを選んでください。')
    return False


def _pick_seed_first(context, op) -> bool:
    _warn(context, op, 'Select one island first as the reference.', '基準にするアイランドを先に選んでください。')
    return False


# ---------------------------------------------------------------------------
# Issue scan
# ---------------------------------------------------------------------------
def _tri_overlap(a, b, eps: float = 1.0e-6) -> bool:
    for tri, oth in ((a, b), (b, a)):
        area2 = (tri[1][0] - tri[0][0]) * (tri[2][1] - tri[0][1]) - (tri[1][1] - tri[0][1]) * (tri[2][0] - tri[0][0])
        sign = 1.0 if area2 >= 0.0 else -1.0
        for i in range(3):
            p, q = tri[i], tri[(i + 1) % 3]
            ex, ey = q[0] - p[0], q[1] - p[1]
            if all(sign * (ex * (r[1] - p[1]) - ey * (r[0] - p[0])) <= eps for r in oth):
                return False
    return True


def _overlap_faces(bm, uv, faces) -> set:
    tris = []
    wanted = set(faces)
    for tri in bm.calc_loop_triangles():
        f = tri[0].face
        if f not in wanted:
            continue
        pts = tuple(tuple(l[uv].uv) for l in tri)
        area2 = (pts[1][0] - pts[0][0]) * (pts[2][1] - pts[0][1]) - (pts[1][1] - pts[0][1]) * (pts[2][0] - pts[0][0])
        if abs(area2) > 1.0e-10:
            tris.append((f, pts))
    if not tris or len(tris) > _MAX_OVERLAP_TRIS:
        return set()
    minu = min(p[0] for _f, t in tris for p in t)
    minv = min(p[1] for _f, t in tris for p in t)
    maxu = max(p[0] for _f, t in tris for p in t)
    maxv = max(p[1] for _f, t in tris for p in t)
    cells_n = max(4, min(512, int(math.sqrt(len(tris)))))
    du = max(maxu - minu, 1.0e-6) / cells_n
    dv = max(maxv - minv, 1.0e-6) / cells_n
    cells: dict = {}
    hits = set()
    for idx, (f, t) in enumerate(tris):
        u0 = int((min(p[0] for p in t) - minu) / du)
        u1 = int((max(p[0] for p in t) - minu) / du)
        v0 = int((min(p[1] for p in t) - minv) / dv)
        v1 = int((max(p[1] for p in t) - minv) / dv)
        checked = set()
        for cu in range(u0, u1 + 1):
            for cv in range(v0, v1 + 1):
                bucket = cells.setdefault((cu, cv), [])
                for j in bucket:
                    if j in checked:
                        continue
                    checked.add(j)
                    g, s = tris[j]
                    if g is f:
                        continue
                    if _tri_overlap(t, s):
                        hits.add(f)
                        hits.add(g)
                bucket.append(idx)
    return hits


def _scan(context, rows) -> dict:
    sync = _sync(context)
    ws = _ws(context)
    limit = float(getattr(ws, 'stretch_threshold', 1.8) or 1.8)
    result = {'zero': {}, 'flipped': {}, 'outside': {}, 'overlap': {}, 'stretch': {}}
    for obj, bm, uv in rows:
        shown = [f for f in bm.faces if _visible(f, sync)]
        zero = set()
        flipped = set()
        outside = set()
        for f in shown:
            area = _face_uv_area(f, uv)
            if abs(area) <= 1.0e-8:
                zero.add(f)
            elif area < 0.0:
                flipped.add(f)
            tiles = {(math.floor(l[uv].uv.x), math.floor(l[uv].uv.y)) for l in f.loops}
            if len(tiles) > 1 or any(t != (0, 0) for t in tiles):
                if not all(0.0 <= l[uv].uv.x <= 1.0 and 0.0 <= l[uv].uv.y <= 1.0 for l in f.loops):
                    outside.add(f)
        stretch = set()
        for group in _islands(bm, uv, sync):
            info = _island_info(obj, group, uv)
            mean = info.density
            if mean <= 0.0:
                continue
            for f in group:
                mesh_area = f.calc_area() * _world_area_scale(obj)
                if mesh_area <= 1.0e-12:
                    continue
                d = math.sqrt(abs(_face_uv_area(f, uv)) / mesh_area)
                if d <= 0.0:
                    continue
                if max(d / mean, mean / d) >= limit:
                    stretch.add(f)
        result['zero'][bm] = zero
        result['flipped'][bm] = flipped
        result['outside'][bm] = outside
        result['overlap'][bm] = _overlap_faces(bm, uv, shown)
        result['stretch'][bm] = stretch
    return result


def _counts(scan: dict) -> dict:
    return {key: sum(len(v) for v in groups.values()) for key, groups in scan.items()}


def _summary(context, counts: dict) -> str:
    return _t(
        context,
        f"Overlap {counts['overlap']}, flipped {counts['flipped']}, zero area {counts['zero']}, outside tile {counts['outside']}, stretched {counts['stretch']} faces.",
        f"重なり {counts['overlap']}・裏返り {counts['flipped']}・面積ゼロ {counts['zero']}・枠の外 {counts['outside']}・伸び {counts['stretch']} 面です。",
    )


def _validate(context, op) -> bool:
    rows = _edit_targets(context)
    if not rows:
        return _no_uv(context, op)
    counts = _counts(_scan(context, rows))
    _info(context, op, _summary(context, counts), _summary(context, counts))
    return True


def _select_issues(context, op, issue=None) -> bool:
    rows = _edit_targets(context)
    if not rows:
        return _no_uv(context, op)
    scan = _scan(context, rows)
    total = 0
    for _obj, bm, _uv in rows:
        faces = set()
        for groups in (scan.values() if issue is None else (scan[issue],)):
            faces |= groups.get(bm, set())
        _select_faces(context, bm, faces)
        total += len(faces)
    _flush(rows)
    if total:
        _info(context, op, f'Selected {total} faces with UV issues.', f'問題のある面を {total} 個選びました。')
    else:
        _info(context, op, 'No UV issues were found.', '問題のある面は見つかりませんでした。')
    return True


def _select_issue(issue):
    def run(context, op):
        return _select_issues(context, op, issue)
    return run


def _native_uv_selection(name):
    def run(context, op):
        if not _edit_targets(context):
            return _no_uv(context, op)
        with _UVOverride(context) as override:
            if not override.kwargs:
                return False
            with context.temp_override(**override.kwargs):
                return 'FINISHED' in getattr(bpy.ops.uv, name)()
    return run


def _move_island(faces, uv, du: float, dv: float) -> None:
    offset = Vector((du, dv))
    for f in faces:
        for l in f.loops:
            l[uv].uv = l[uv].uv + offset


def _boxes_hit(a, b, margin: float = 0.005) -> bool:
    return not (a[2] + margin <= b[0] or b[2] + margin <= a[0] or a[3] + margin <= b[1] or b[3] + margin <= a[1])


def _free_spot(w: float, h: float, placed) -> Optional[tuple]:
    """Lowest free position next to the islands already placed, tile by tile."""
    margin = 0.006
    for tile in range(0, 9):
        left = float(tile)
        right = left + 1.0
        us = sorted({left} | {p.box[2] + margin for p in placed if left <= p.box[2] + margin < right})
        vs = sorted({0.0} | {p.box[3] + margin for p in placed if 0.0 <= p.box[3] + margin < 1.0})
        for v in vs:
            if v + h > 1.0 + 1.0e-6:
                continue
            for u in us:
                if u + w > right + 1.0e-6:
                    continue
                box = (u, v, u + w, v + h)
                if not any(_boxes_hit(box, p.box) for p in placed):
                    return box
    return None


def _unstack(context, rows, scope=None) -> int:
    moved = 0
    for obj, bm, uv in rows:
        sync = _sync(context)
        hits = _overlap_faces(bm, uv, [f for f in bm.faces if _visible(f, sync)])
        if not hits:
            continue
        infos = [_island_info(obj, group, uv) for group in _islands(bm, uv, sync)]
        infos.sort(key=lambda i: i.uv_area, reverse=True)
        allowed = None
        if scope is not None:
            allowed = {f for row in scope if row[1] is bm for f in row[3].faces}
        placed = []
        pending = []
        for info in infos:
            info_hits = [f for f in info.faces if f in hits]
            clashes = bool(info_hits) and any(_boxes_hit(info.box, p.box, 0.0) for p in placed)
            movable = allowed is None or any(f in allowed for f in info.faces)
            if clashes and movable:
                pending.append(info)
            else:
                placed.append(info)
        for info in pending:
            spot = _free_spot(info.width, info.height, placed)
            if spot is None:
                continue
            _move_island(info.faces, uv, spot[0] - info.box[0], spot[1] - info.box[1])
            info.box = spot
            placed.append(info)
            moved += 1
    return moved


def _unstack_overlapped(context, op) -> bool:
    rows = _edit_targets(context)
    if not rows:
        return _no_uv(context, op)
    moved = _unstack(context, rows, _selected_scope(context, rows))
    _flush(rows)
    if moved:
        _info(context, op, f'Moved {moved} overlapping islands apart.', f'重なっていたアイランドを {moved} 個離しました。')
    else:
        _info(context, op, 'No overlapping islands were found.', '重なっているアイランドはありませんでした。')
    return True


def _fix_issues(context, op) -> bool:
    rows = _edit_targets(context)
    if not rows:
        return _no_uv(context, op)
    sync = _sync(context)
    flipped_fixed = 0
    for obj, bm, uv in rows:
        for group in _islands(bm, uv, sync):
            negative = sum(1 for f in group if _face_uv_area(f, uv) < -1.0e-8)
            if negative * 2 <= len(group):
                continue
            box = _island_info(obj, group, uv).box
            mid = (box[0] + box[2]) * 0.5
            for f in group:
                for l in f.loops:
                    l[uv].uv.x = 2.0 * mid - l[uv].uv.x
            flipped_fixed += 1
    ws = _ws(context)
    moved = 0
    if not bool(getattr(ws, 'smart_lock_overlaps', False)):
        moved = _unstack(context, rows)
    _flush(rows)
    left = _counts(_scan(context, rows))
    _info(
        context,
        op,
        f"Flipped {flipped_fixed} islands back and moved {moved} overlapping islands. Remaining: zero area {left['zero']}, overlap {left['overlap']}, flipped {left['flipped']} faces.",
        f"裏返ったアイランドを {flipped_fixed} 個戻し、重なったアイランドを {moved} 個離しました。残り：面積ゼロ {left['zero']}・重なり {left['overlap']}・裏返り {left['flipped']} 面。",
    )
    return True


# ---------------------------------------------------------------------------
# Selection buttons
# ---------------------------------------------------------------------------
def _report_selected(context, op, count: int) -> bool:
    if count:
        _info(context, op, f'Selected {count} faces.', f'面を {count} 個選びました。')
    else:
        _info(context, op, 'Nothing matched.', '当てはまる物はありませんでした。')
    return True


def _select_stacked(context, op) -> bool:
    rows = _edit_targets(context)
    if not rows:
        return _no_uv(context, op)
    every = _all_islands(context, rows)
    chosen = []
    for i, row in enumerate(every):
        a = row[3].box
        for j, other in enumerate(every):
            if i == j:
                continue
            b = other[3].box
            if all(abs(a[k] - b[k]) <= 0.01 * max(a[2] - a[0], a[3] - a[1], 1.0e-4) for k in range(4)):
                chosen.append(row)
                break
    return _report_selected(context, op, _select_by_islands(context, rows, chosen))


def _select_square(context, op) -> bool:
    rows = _edit_targets(context)
    if not rows:
        return _no_uv(context, op)
    chosen = []
    for row in _all_islands(context, rows):
        info = row[3]
        box_area = info.width * info.height
        if box_area > 1.0e-10 and info.uv_area / box_area >= 0.95:
            chosen.append(row)
    return _report_selected(context, op, _select_by_islands(context, rows, chosen))


def _select_matching(context, op, value: Callable[[_Isl], float]) -> bool:
    rows = _edit_targets(context)
    if not rows:
        return _no_uv(context, op)
    seeds = _seed_islands(context, rows)
    if not seeds:
        return _pick_seed_first(context, op)
    refs = [value(s[3]) for s in seeds]
    chosen = []
    for row in _all_islands(context, rows):
        v = value(row[3])
        if any(abs(v - r) <= abs(r) * _SIMILAR_RATIO for r in refs):
            chosen.append(row)
    return _report_selected(context, op, _select_by_islands(context, rows, chosen))


def _select_by_area(context, op) -> bool:
    return _select_matching(context, op, lambda i: i.uv_area)


def _select_by_density(context, op) -> bool:
    return _select_matching(context, op, lambda i: i.density)


def _uv_cursor(context) -> Vector:
    spaces = [getattr(context, 'space_data', None)]
    for area in getattr(context.screen, 'areas', []) or []:
        if area.type == 'IMAGE_EDITOR':
            spaces.append(area.spaces.active)
    for sp in spaces:
        if sp is not None and getattr(sp, 'type', '') == 'IMAGE_EDITOR':
            return Vector(sp.cursor_location)
    return Vector((0.0, 0.0))


def _point_in_tri(p, a, b, c) -> bool:
    def side(u, v, w):
        return (v.x - u.x) * (w.y - u.y) - (v.y - u.y) * (w.x - u.x)
    if side(a, b, c) == 0.0:
        return False
    d1, d2, d3 = side(a, b, p), side(b, c, p), side(c, a, p)
    return not ((d1 < 0 or d2 < 0 or d3 < 0) and (d1 > 0 or d2 > 0 or d3 > 0))


def _select_by_cursor(context, op) -> bool:
    rows = _edit_targets(context)
    if not rows:
        return _no_uv(context, op)
    cur = _uv_cursor(context)
    chosen = []
    sync = _sync(context)
    for obj, bm, uv in rows:
        hit = None
        for tri in bm.calc_loop_triangles():
            if _visible(tri[0].face, sync) and _point_in_tri(cur, tri[0][uv].uv, tri[1][uv].uv, tri[2][uv].uv):
                hit = tri[0].face
                break
        if hit is None:
            continue
        for group in _islands(bm, uv, sync):
            if hit in group:
                chosen.append((obj, bm, uv, _island_info(obj, group, uv)))
                break
    return _report_selected(context, op, _select_by_islands(context, rows, chosen))


def _select_fragmented(context, op) -> bool:
    rows = _edit_targets(context)
    if not rows:
        return _no_uv(context, op)
    every = _all_islands(context, rows)
    if not every:
        return _report_selected(context, op, 0)
    areas = sorted(r[3].uv_area for r in every)
    median = areas[len(areas) // 2]
    chosen = [r for r in every if len(r[3].faces) <= 2 or r[3].uv_area <= median * 0.05]
    return _report_selected(context, op, _select_by_islands(context, rows, chosen))


def _select_half(context, op) -> bool:
    rows = _edit_targets(context)
    if not rows:
        return _no_uv(context, op)
    wanted = {}
    for row in _selected_scope(context, rows):
        _obj, bm, uv, info = row
        mid = (info.box[0] + info.box[2]) * 0.5
        for f in info.faces:
            center = sum((l[uv].uv.x for l in f.loops)) / max(1, len(f.loops))
            if center < mid:
                wanted.setdefault(bm, set()).add(f)
    for _obj, bm, _uv in rows:
        _select_faces(context, bm, wanted.get(bm, set()))
    _flush(rows)
    return _report_selected(context, op, sum(len(v) for v in wanted.values()))


def _select_directional_edges(context, op) -> bool:
    rows = _edit_targets(context)
    if not rows:
        return _no_uv(context, op)
    sync = _sync(context)
    dirs = []
    for _obj, bm, uv in rows:
        for l in _selected_edge_loops(context, bm):
            d = l.link_loop_next[uv].uv - l[uv].uv
            if d.length > 1.0e-7:
                dirs.append(d.normalized())
    if not dirs:
        _warn(context, op, 'Select a UV edge first as the reference.', '基準にする UV の辺を先に選んでください。')
        return False
    limit = math.cos(math.radians(10.0))
    total = 0
    for _obj, bm, uv in rows:
        loops = []
        for f in bm.faces:
            if not _visible(f, sync):
                continue
            for l in f.loops:
                d = l.link_loop_next[uv].uv - l[uv].uv
                if d.length <= 1.0e-7:
                    continue
                d = d.normalized()
                if any(abs(d.dot(s)) >= limit for s in dirs):
                    loops.append(l)
        _select_edge_loops(context, bm, loops)
        total += len(loops)
    _flush(rows)
    _info(context, op, f'Selected {total} UV edges.', f'UV の辺を {total} 本選びました。')
    return True


def _select_uv_boundary(context, op) -> bool:
    rows = _edit_targets(context)
    if not rows:
        return _no_uv(context, op)
    sync = _sync(context)
    scope = _selected_scope(context, rows)
    total = 0
    for obj, bm, uv in rows:
        faces = {f for row in scope if row[1] is bm for f in row[3].faces}
        loops = []
        for f in faces:
            for l in f.loops:
                other = l.link_loop_radial_next
                connected = False
                while other is not l:
                    if _visible(other.face, sync) and _uv_connected(l, other, uv):
                        connected = True
                        break
                    other = other.link_loop_radial_next
                if not connected:
                    loops.append(l)
        _select_edge_loops(context, bm, loops)
        total += len(loops)
    _flush(rows)
    _info(context, op, f'Selected {total} UV boundary edges.', f'アイランドの外周の辺を {total} 本選びました。')
    return True


# ---------------------------------------------------------------------------
# Mirror / combine
# ---------------------------------------------------------------------------
def _mirror_maps(bm) -> tuple:
    bm.verts.ensure_lookup_table()
    tree = KDTree(len(bm.verts))
    for v in bm.verts:
        tree.insert(v.co, v.index)
    tree.balance()
    size = max((v.co.length for v in bm.verts), default=1.0)
    tol = max(size * 1.0e-3, 1.0e-5)
    vert_map = {}
    for v in bm.verts:
        co, index, dist = tree.find(Vector((-v.co.x, v.co.y, v.co.z)))
        if co is not None and dist <= tol:
            vert_map[v] = bm.verts[index]
    by_verts = {frozenset(v.index for v in f.verts): f for f in bm.faces}

    def mirror_face(face):
        key = []
        for v in face.verts:
            m = vert_map.get(v)
            if m is None:
                return None
            key.append(m.index)
        return by_verts.get(frozenset(key))

    return vert_map, mirror_face


def _select_mirror3d(context, op) -> bool:
    rows = _edit_targets(context)
    if not rows:
        return _no_uv(context, op)
    sync = _sync(context)
    total = 0
    any_seed = False
    for _obj, bm, _uv in rows:
        seeds = [f for f in bm.faces if _face_selected(f, sync)]
        any_seed = any_seed or bool(seeds)
        _vert_map, mirror_face = _mirror_maps(bm)
        extra = {mirror_face(f) for f in seeds} - {None}
        _select_faces(context, bm, set(seeds) | extra)
        total += len(extra - set(seeds))
    _flush(rows)
    if not any_seed:
        _warn(context, op, 'Select faces first.', '先に面を選んでください。')
        return False
    _info(context, op, f'Added {total} mirrored faces to the selection.', f'左右反対側の面を {total} 個、選択に足しました。')
    return True


def _mirror_uv(context, op) -> bool:
    rows = _edit_targets(context)
    if not rows:
        return _no_uv(context, op)
    sync = _sync(context)
    total = 0
    for _obj, bm, uv in rows:
        vert_map, mirror_face = _mirror_maps(bm)
        selected = {f for f in bm.faces if _face_selected(f, sync)}
        for f in selected:
            g = mirror_face(f)
            if g is None or g is f or g in selected:
                continue
            source = {l.vert: l[uv].uv.copy() for l in f.loops}
            for l in g.loops:
                m = vert_map.get(l.vert)
                if m in source:
                    src = source[m]
                    l[uv].uv = (1.0 - src.x, src.y)
            total += 1
    _flush(rows)
    if not total:
        _warn(context, op, 'Select the faces of one side of a mesh that is symmetric in X.', 'X 方向に左右対称なメッシュの、片側の面を選んでください。')
        return False
    _info(context, op, f'Mirrored the UVs onto {total} faces on the other side.', f'反対側の {total} 面へ、左右反転した UV を写しました。')
    return True


def _symmetry_snap(context, op) -> bool:
    rows = _edit_targets(context)
    if not rows:
        return _no_uv(context, op)
    sync = _sync(context)
    total = 0
    for _obj, bm, uv in rows:
        vert_map, mirror_face = _mirror_maps(bm)
        selected = {f for f in bm.faces if _face_selected(f, sync)}
        if not selected:
            continue
        us = [l[uv].uv.x for f in selected for l in f.loops]
        mid = (min(us) + max(us)) * 0.5
        done = set()
        new_uv = {}
        for f in selected:
            if f in done:
                continue
            g = mirror_face(f)
            if g is None or g not in selected:
                continue
            done.add(f)
            done.add(g)
            other = {l.vert: l for l in g.loops}
            for l in f.loops:
                m = other.get(vert_map.get(l.vert))
                if m is None:
                    continue
                a, b = l[uv].uv, m[uv].uv
                half = ((a.x - mid) - (b.x - mid)) * 0.5
                height = (a.y + b.y) * 0.5
                new_uv[l] = (mid + half, height)
                new_uv[m] = (mid - half, height)
            total += 1
        for l, value in new_uv.items():
            l[uv].uv = value
    _flush(rows)
    if not total:
        _warn(context, op, 'Select an island whose left and right faces are symmetric in 3D.', '3D で左右対称な面を持つアイランドを選んでください。')
        return False
    _info(context, op, f'Made {total} face pairs symmetric in UV.', f'{total} 組の面の UV を左右対称にそろえました。')
    return True


def _island_points(faces, uv) -> list:
    return [Vector(p) for p in {(round(l[uv].uv.x, 6), round(l[uv].uv.y, 6)) for f in faces for l in f.loops}]


def _points_center(points) -> Vector:
    return sum(points, Vector((0.0, 0.0))) / len(points)


def _rotated(p, center, angle: float) -> Vector:
    c, s = math.cos(angle), math.sin(angle)
    x, y = p.x - center.x, p.y - center.y
    return Vector((center.x + c * x - s * y, center.y + s * x + c * y))


@dataclass
class _Shape:
    points: list
    center: Vector
    tree: KDTree


def _island_shape(faces, uv) -> _Shape:
    points = _island_points(faces, uv)
    center = _points_center(points)
    tree = KDTree(len(points))
    for i, p in enumerate(points):
        tree.insert((p.x, p.y, 0.0), i)
    tree.balance()
    return _Shape(points, center, tree)


def _shape_turn(shape: _Shape, base: _Shape, tol: float) -> Optional[float]:
    """Return the turn that lays ``shape`` exactly over ``base``, or None when the shapes differ."""
    if len(shape.points) != len(base.points):
        return None
    offset = base.center - shape.center
    # A turn must carry the point farthest from the center onto a base point just as far out.
    far = max(shape.points, key=lambda p: (p - shape.center).length)
    radius = (far - shape.center).length
    far_angle = math.atan2(far.y - shape.center.y, far.x - shape.center.x)
    turns = [0.0, 0.5 * math.pi, math.pi, 1.5 * math.pi]
    for p in base.points:
        if abs((p - base.center).length - radius) <= tol:
            turns.append(math.atan2(p.y - base.center.y, p.x - base.center.x) - far_angle)
    for angle in turns:
        moved = [_rotated(p, shape.center, angle) + offset for p in shape.points]
        if any(base.tree.find((p.x, p.y, 0.0))[2] > tol for p in moved):
            continue
        back = KDTree(len(moved))
        for i, p in enumerate(moved):
            back.insert((p.x, p.y, 0.0), i)
        back.balance()
        if all(back.find((p.x, p.y, 0.0))[2] <= tol for p in base.points):
            return angle
    return None


def _smart_stack(context, op) -> bool:
    rows = _edit_targets(context)
    if not rows:
        return _no_uv(context, op)
    clusters: dict = {}
    moved = 0
    for _obj, _bm, uv, info in _selected_scope(context, rows):
        if info.uv_area <= 1.0e-9:
            continue
        key = (len(info.faces), sum(len(f.verts) for f in info.faces))
        shape = _island_shape(info.faces, uv)
        for base_info, base in clusters.setdefault(key, []):
            if abs(info.uv_area - base_info.uv_area) > 0.05 * base_info.uv_area:
                continue
            angle = _shape_turn(shape, base, 0.02 * math.sqrt(base_info.uv_area))
            if angle is None:
                continue
            offset = base.center - shape.center
            for face in info.faces:
                for loop in face.loops:
                    loop[uv].uv = _rotated(loop[uv].uv, shape.center, angle) + offset
            moved += 1
            break
        else:
            clusters[key].append((info, shape))
    _flush(rows)
    if not moved:
        _info(context, op, 'No islands of the same shape were found.', '同じ形のアイランドはありませんでした。')
        return True
    _info(context, op, f'Stacked {moved} islands of the same shape.', f'同じ形のアイランドを {moved} 個重ねました。')
    return True


def _call_uv_op(context, op, fn, **kw) -> bool:
    rows = _edit_targets(context)
    if not rows:
        return _no_uv(context, op)
    result = fn(**kw)
    return 'FINISHED' in result


def _weld(context, op) -> bool:
    if not _call_uv_op(context, op, bpy.ops.uv.weld):
        return False
    _info(context, op, 'Welded the selected UVs to one point.', '選んだ UV を 1 点にまとめました。')
    return True


def _merge_vertices(context, op) -> bool:
    dist = float(getattr(context.scene, 'suv_consolidated_snap_vertex_distance', 0.02) or 0.02)
    if not _call_uv_op(context, op, bpy.ops.uv.remove_doubles, threshold=dist):
        return False
    _info(context, op, 'Merged selected UV vertices that are within the distance.', '「距離」の中にある選んだ UV の頂点をまとめました。')
    return True


def _constraint_unwrap(context, op) -> bool:
    rows = _edit_targets(context)
    if not rows:
        return _no_uv(context, op)
    if 'FINISHED' not in bpy.ops.uv.unwrap(method='ANGLE_BASED', margin=0.001):
        _warn(context, op, 'Select the UVs to unwrap first.', '展開し直す UV を先に選んでください。')
        return False
    _info(context, op, 'Unwrapped the selected UVs while keeping the pinned UVs in place.', 'ピンの UV を動かさずに、選んだ UV を展開し直しました。')
    return True


# ---------------------------------------------------------------------------
# Selection sets
# ---------------------------------------------------------------------------
def _save_set(context, op) -> bool:
    rows = _edit_targets(context)
    if not rows:
        return _no_uv(context, op)
    obj, bm, _uv = rows[0]
    sync = _sync(context)
    faces = [f.index for f in bm.faces if _face_selected(f, sync)]
    if not faces:
        _warn(context, op, 'Select faces first.', '先に面を選んでください。')
        return False
    name = str(op.name or 'Set').strip() or 'Set'
    data = _get_sets(obj)
    data[name] = {'faces': faces}
    _set_sets(obj, data)
    _info(context, op, f'Saved the selection as "{name}" ({len(faces)} faces).', f'選択を「{name}」として保存しました（{len(faces)} 面）。')
    return True


def _recall_set(context, op) -> bool:
    rows = _edit_targets(context)
    if not rows:
        return _no_uv(context, op)
    obj, bm, _uv = rows[0]
    name = str(op.name or '')
    record = _get_sets(obj).get(name)
    if not isinstance(record, dict):
        _warn(context, op, 'That selection set does not exist.', 'その選択セットはありません。')
        return False
    bm.faces.ensure_lookup_table()
    faces = {bm.faces[i] for i in record.get('faces', ()) if isinstance(i, int) and 0 <= i < len(bm.faces)}
    _select_faces(context, bm, faces)
    _flush(rows)
    _info(context, op, f'Recalled "{name}".', f'「{name}」の選択に戻しました。')
    return True


def _set_menu_invoke(context, op, event) -> set:
    obj = getattr(context, 'active_object', None)
    names = sorted(_get_sets(obj)) if obj is not None else []
    if not names:
        _warn(context, op, 'No selection set has been saved yet.', '保存した選択セットがまだありません。')
        return {'CANCELLED'}
    op_id = op.bl_idname

    def draw(self, _context):
        for name in names:
            item = self.layout.operator(op_id, text=name, translate=False)
            item.name = name

    context.window_manager.popup_menu(draw, title=_t(context, 'Selection Sets', '選択セット'))
    return {'FINISHED'}


def _name_dialog_invoke(context, op, event) -> set:
    if not op.name:
        op.name = 'Set'
    return context.window_manager.invoke_props_dialog(op, title=_t(context, 'Save Set', 'セット保存'), confirm_text=_t(context, 'Save', '保存'))


def _name_dialog_draw(op, context) -> None:
    op.layout.prop(op, 'name', text=_t(context, 'Set Name', 'セット名'), translate=False)


# ---------------------------------------------------------------------------
# UV map buttons
# ---------------------------------------------------------------------------
def _set_work_uv(context, op) -> bool:
    ws = _ws(context)
    name = str(getattr(ws, 'uv_new_name', '') or '')
    done = 0
    for obj in _mesh_objects(context):
        layer = obj.data.uv_layers.get(name)
        if layer is not None:
            obj.data.uv_layers.active = layer
            done += 1
    if not done:
        _warn(context, op, f'No UV map is named "{name}".', f'「{name}」という名前の UV マップがありません。')
        return False
    for obj in _mesh_objects(context):
        obj.data.update()
    _info(context, op, f'"{name}" is now the working UV map on {done} objects.', f'{done} 個のオブジェクトで「{name}」を作業用の UV マップにしました。')
    return True


# ---------------------------------------------------------------------------
# Measurements
# ---------------------------------------------------------------------------
def _triangles(rows, sync: bool, *, selected_only: bool) -> list:
    out = []
    for _obj, bm, uv in rows:
        for tri in bm.calc_loop_triangles():
            f = tri[0].face
            if (_face_selected(f, sync) if selected_only else _visible(f, sync)):
                out.append((f, uv, tuple(tuple(l[uv].uv) for l in tri)))
    return out


def _rasterize(size: int, tris, color_of: Optional[Callable] = None):
    import numpy as np
    img = np.zeros((size, size, 4), dtype=np.float32)
    mask = np.zeros((size, size), dtype=bool)
    for item in tris:
        pts = item[2]
        xs = [p[0] * size for p in pts]
        ys = [p[1] * size for p in pts]
        x0, x1 = max(int(math.floor(min(xs))), 0), min(int(math.ceil(max(xs))), size)
        y0, y1 = max(int(math.floor(min(ys))), 0), min(int(math.ceil(max(ys))), size)
        if x0 >= x1 or y0 >= y1:
            continue
        gx, gy = np.meshgrid(np.arange(x0, x1) + 0.5, np.arange(y0, y1) + 0.5)
        d1 = (xs[1] - xs[0]) * (gy - ys[0]) - (ys[1] - ys[0]) * (gx - xs[0])
        d2 = (xs[2] - xs[1]) * (gy - ys[1]) - (ys[2] - ys[1]) * (gx - xs[1])
        d3 = (xs[0] - xs[2]) * (gy - ys[2]) - (ys[0] - ys[2]) * (gx - xs[2])
        inside = ((d1 >= 0) & (d2 >= 0) & (d3 >= 0)) | ((d1 <= 0) & (d2 <= 0) & (d3 <= 0))
        mask[y0:y1, x0:x1] |= inside
        if color_of is not None:
            color = color_of(item)
            img[y0:y1, x0:x1][inside] = color
    return mask, img


def _coverage(context, op) -> bool:
    rows = _edit_targets(context)
    if not rows:
        return _no_uv(context, op)
    tris = _triangles(rows, _sync(context), selected_only=False)
    mask, _img = _rasterize(512, tris)
    percent = float(mask.mean()) * 100.0
    _info(context, op, f'The UVs cover {percent:.1f}% of the tile.', f'UV は枠の {percent:.1f}% を使っています。')
    return True


def _uv_area(context, op) -> bool:
    rows = _edit_targets(context)
    if not rows:
        return _no_uv(context, op)
    sync = _sync(context)
    uv_total = 0.0
    mesh_total = 0.0
    for row in _selected_scope(context, rows):
        info = row[3]
        uv_total += info.uv_area
        mesh_total += info.mesh_area
    _ = sync
    _info(context, op, f'UV area {uv_total:.4f} ({uv_total * 100.0:.1f}% of a tile), 3D area {mesh_total:.4f}.', f'UV の面積 {uv_total:.4f}（枠の {uv_total * 100.0:.1f}%）、3D の面積 {mesh_total:.4f} です。')
    return True


def _active_image(context, obj):
    sp = getattr(context, 'space_data', None)
    if sp is not None and getattr(sp, 'type', '') == 'IMAGE_EDITOR' and sp.image is not None:
        return sp.image
    mat = getattr(obj, 'active_material', None)
    tree = getattr(mat, 'node_tree', None)
    if tree is not None:
        node = tree.nodes.active
        if node is not None and node.type == 'TEX_IMAGE' and node.image is not None:
            return node.image
        for node in tree.nodes:
            if node.type == 'TEX_IMAGE' and node.image is not None:
                return node.image
    return None


def _density_from_texture(context, op) -> bool:
    rows = _edit_targets(context)
    if not rows:
        return _no_uv(context, op)
    image = _active_image(context, rows[0][0])
    ws = _ws(context)
    if image is not None and image.size[0] > 0:
        size = max(int(image.size[0]), int(image.size[1]))
        label = image.name
    else:
        size = int(getattr(ws, 'canvas_size', 2048) or 2048)
        label = _t(context, 'Texture Size', 'テクスチャサイズ')
    uv_total = 0.0
    mesh_total = 0.0
    for row in _selected_scope(context, rows):
        uv_total += row[3].uv_area
        mesh_total += row[3].mesh_area
    if mesh_total <= 1.0e-12:
        return _no_uv(context, op)
    density = math.sqrt(uv_total / mesh_total) * size
    if ws is not None:
        ws.workflow_density = density
    _info(context, op, f'Density {density:.1f} px/unit ({size} px, {label}) was put in Target Density.', f'密度は {density:.1f} px/unit です（{size} px、{label}）。「目標密度」に入れました。')
    return True


# ---------------------------------------------------------------------------
# Bake flow
# ---------------------------------------------------------------------------
class _ObjectMode:
    def __init__(self, context):
        self.context = context
        self.old = None

    def __enter__(self):
        active = getattr(self.context, 'active_object', None)
        self.old = active.mode if active is not None else None
        if active is not None and active.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        return self

    def __exit__(self, *_exc):
        active = getattr(self.context, 'active_object', None)
        if active is not None and self.old and active.mode != self.old:
            bpy.ops.object.mode_set(mode=self.old)
        return False


def _bake_size(context) -> int:
    return max(16, int(getattr(_ws(context), 'canvas_size', 2048) or 2048))


def _bake_margin_px(context) -> int:
    return max(0, int(getattr(_ws(context), 'fit_padding_px', 8) or 0))


def _bake_uv_prep(context, op) -> bool:
    objs = _mesh_objects(context)
    if not objs:
        return _no_uv(context, op)
    old_mode = objs[0].mode
    if old_mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    made = 0
    for obj in objs:
        maps = obj.data.uv_layers
        layer = maps.get(_BAKE_UV)
        if layer is None:
            src = maps.active
            layer = maps.new(name=_BAKE_UV)
            if src is not None:
                for s, d in zip(src.data, layer.data):
                    d.uv = s.uv
            made += 1
        maps.active = layer
        obj.data.update()
    bpy.ops.object.mode_set(mode='EDIT')
    rows = _edit_targets(context)
    for _obj, bm, _uv in rows:
        _select_faces(context, bm, set(bm.faces))
    _flush(rows)
    margin = _bake_margin_px(context) / float(_bake_size(context))
    bpy.ops.uv.pack_islands(udim_source='CLOSEST_UDIM', rotate=True, scale=True, margin_method='FRACTION', margin=margin)
    if old_mode != 'EDIT':
        bpy.ops.object.mode_set(mode='OBJECT')
    _info(context, op, f'"{_BAKE_UV}" is now the working UV map with the islands packed into the tile.', f'「{_BAKE_UV}」を作業用の UV マップにして、アイランドを枠の中に並べました。')
    return True


def _ensure_image(name: str, size: int):
    image = bpy.data.images.get(name)
    if image is None:
        image = bpy.data.images.new(name, size, size, alpha=False)
    elif tuple(image.size) != (size, size):
        image.scale(size, size)
    return image


def _show_image(context, image) -> None:
    for area in getattr(context.screen, 'areas', []) or []:
        if area.type == 'IMAGE_EDITOR':
            area.spaces.active.image = image


def _ensure_material(obj):
    if not obj.data.materials or all(m is None for m in obj.data.materials):
        mat = bpy.data.materials.new(name=obj.name + '_Material')
        mat.use_nodes = True
        obj.data.materials.append(mat)
    return [m for m in obj.data.materials if m is not None]


def _ensure_bake_targets(context, objs):
    image = _ensure_image(_BAKE_IMAGE, _bake_size(context))
    for obj in objs:
        for mat in _ensure_material(obj):
            if mat.name == _BAKED_MATERIAL:
                continue
            mat.use_nodes = True
            tree = mat.node_tree
            node = tree.nodes.get(_BAKE_NODE)
            if node is None:
                node = tree.nodes.new('ShaderNodeTexImage')
                node.name = _BAKE_NODE
                node.label = _BAKE_NODE
                node.location = (-700.0, -300.0)
            node.image = image
            for other in tree.nodes:
                other.select = False
            node.select = True
            tree.nodes.active = node
    return image


def _bake_image_create(context, op) -> bool:
    objs = _mesh_objects(context)
    if not objs:
        return _no_uv(context, op)
    with _ObjectMode(context):
        image = _ensure_bake_targets(context, objs)
    _show_image(context, image)
    _info(context, op, f'Created the bake image "{image.name}" ({image.size[0]} px) and set it as the bake target.', f'ベイク用の画像「{image.name}」（{image.size[0]} px）を作り、焼き先に設定しました。')
    return True


def _baked_nodes(mat) -> tuple:
    tree = mat.node_tree
    return (
        next((n for n in tree.nodes if n.type == 'BSDF_PRINCIPLED'), None),
        next((n for n in tree.nodes if n.type == 'TEX_IMAGE'), None),
        next((n for n in tree.nodes if n.type == 'UVMAP'), None),
    )


def _baked_faces(obj) -> list:
    index = obj.data.materials.find(_BAKED_MATERIAL)
    return [p for p in obj.data.polygons if p.material_index == index] if index >= 0 else []


def _source_known(obj) -> bool:
    """True when every face showing the baked material can go back to its own material."""
    faces = _baked_faces(obj)
    if not faces:
        return True
    attr = obj.data.attributes.get(_BAKE_SOURCE_ATTR)
    if attr is None:
        return False
    mats = obj.data.materials
    index = mats.find(_BAKED_MATERIAL)
    for poly in faces:
        source = attr.data[poly.index].value
        if source == index or not 0 <= source < len(mats) or mats[source] is None:
            return False
    return True


def _show_source_materials(obj) -> tuple:
    faces = [p.index for p in _baked_faces(obj)]
    if faces:
        attr = obj.data.attributes[_BAKE_SOURCE_ATTR]
        for i in faces:
            obj.data.polygons[i].material_index = attr.data[i].value
    return obj, faces


def _atlas_bake(context, op) -> bool:
    objs = _mesh_objects(context)
    if not objs:
        return _no_uv(context, op)
    scene = context.scene
    old_engine = scene.render.engine
    with _ObjectMode(context):
        if any(not obj.data.uv_layers for obj in objs):
            return _no_uv(context, op)
        uv_names = {obj.data.uv_layers.active.name for obj in objs}
        if len(uv_names) > 1:
            _warn(context, op, f'The selected objects use different working UV maps. Press Prepare Bake UV first so they all use "{_BAKE_UV}".', f'選んでいるオブジェクトの作業用の UV マップの名前が違います。先に「ベイクUV準備」を押して「{_BAKE_UV}」にそろえてください。')
            return False
        if not all(_source_known(obj) for obj in objs):
            _warn(context, op, f'Faces use "{_BAKED_MATERIAL}" but their own material is unknown, so there is no color to bake.', f'面に「{_BAKED_MATERIAL}」が当たっていて、元のマテリアルが分からないので焼けません。')
            return False
        uv_name = uv_names.pop()
        image = _ensure_bake_targets(context, objs)
        try:
            scene.render.engine = 'CYCLES'
        except Exception:
            _warn(context, op, 'Baking needs the Cycles add-on to be enabled.', 'ベイクには Cycles のアドオンを有効にしてください。')
            return False
        old_samples = scene.cycles.samples
        scene.cycles.samples = 1
        baked = bpy.data.materials.get(_BAKED_MATERIAL)
        bsdf, tex, uvnode = _baked_nodes(baked) if baked is not None else (None, None, None)
        unlinked = False
        if bsdf is not None and tex is not None:
            # The baked material reads the image being written; keep it out of the bake.
            for link in list(tex.outputs['Color'].links):
                baked.node_tree.links.remove(link)
                unlinked = True
        shown = [_show_source_materials(obj) for obj in objs]
        try:
            bpy.ops.object.bake(type='DIFFUSE', pass_filter={'COLOR'}, target='IMAGE_TEXTURES', use_clear=True, margin=_bake_margin_px(context))
        finally:
            for obj, faces in shown:
                index = obj.data.materials.find(_BAKED_MATERIAL)
                for i in faces:
                    obj.data.polygons[i].material_index = index
                obj.data.update()
            if unlinked:
                baked.node_tree.links.new(tex.outputs['Color'], bsdf.inputs['Base Color'])
            scene.cycles.samples = old_samples
            scene.render.engine = old_engine
        image.pack()
        image[_BAKE_UV_KEY] = uv_name
        if uvnode is not None:
            uvnode.uv_map = uv_name
    _show_image(context, image)
    _info(context, op, f'Baked the material colors into "{image.name}".', f'マテリアルの色を「{image.name}」に焼き付けました。')
    return True


def _remember_source_materials(obj, index: int) -> None:
    mesh = obj.data
    if mesh.attributes.get(_BAKE_SOURCE_ATTR) is None:
        mesh.attributes.new(_BAKE_SOURCE_ATTR, 'INT', 'FACE')
    attr = mesh.attributes[_BAKE_SOURCE_ATTR]
    for poly in mesh.polygons:
        if poly.material_index != index:
            attr.data[poly.index].value = poly.material_index


def _build_material(context, op) -> bool:
    objs = _mesh_objects(context)
    image = bpy.data.images.get(_BAKE_IMAGE)
    uv_name = str(image.get(_BAKE_UV_KEY, '')) if image is not None else ''
    if not objs or not uv_name:
        _warn(context, op, 'Press Bake Atlas first.', '先に「アトラスベイク」を押してください。')
        return False
    if any(obj.data.uv_layers.get(uv_name) is None for obj in objs):
        _warn(context, op, f'The image was baked with the UV map "{uv_name}", which a selected object does not have. Press Bake Atlas on that object first.', f'画像は UV マップ「{uv_name}」で焼きましたが、選んでいるオブジェクトにこの UV マップがありません。そのオブジェクトで先に「アトラスベイク」を押してください。')
        return False
    mat = bpy.data.materials.get(_BAKED_MATERIAL)
    if mat is None:
        mat = bpy.data.materials.new(_BAKED_MATERIAL)
        mat.use_nodes = True
    tree = mat.node_tree
    bsdf, tex, uvnode = _baked_nodes(mat)
    if bsdf is None:
        output = next((n for n in tree.nodes if n.type == 'OUTPUT_MATERIAL'), None) or tree.nodes.new('ShaderNodeOutputMaterial')
        bsdf = tree.nodes.new('ShaderNodeBsdfPrincipled')
        tree.links.new(bsdf.outputs['BSDF'], output.inputs['Surface'])
    tex = tex or tree.nodes.new('ShaderNodeTexImage')
    tex.image = image
    uvnode = uvnode or tree.nodes.new('ShaderNodeUVMap')
    uvnode.uv_map = uv_name
    tree.links.new(uvnode.outputs['UV'], tex.inputs['Vector'])
    tree.links.new(tex.outputs['Color'], bsdf.inputs['Base Color'])
    tree.nodes.active = tex
    with _ObjectMode(context):
        for obj in objs:
            mats = obj.data.materials
            if mats.find(mat.name) < 0:
                mats.append(mat)
            index = mats.find(mat.name)
            _remember_source_materials(obj, index)
            for poly in obj.data.polygons:
                poly.material_index = index
            obj.active_material_index = index
            obj.data.update()
    _info(context, op, f'Created "{mat.name}" and assigned it to {len(objs)} objects.', f'マテリアル「{mat.name}」を作り、{len(objs)} 個のオブジェクトに当てました。')
    return True


_ID_COLORS = (
    (0.90, 0.20, 0.20), (0.20, 0.70, 0.25), (0.20, 0.35, 0.90), (0.95, 0.80, 0.15),
    (0.80, 0.25, 0.80), (0.15, 0.80, 0.80), (0.95, 0.50, 0.15), (0.55, 0.30, 0.90),
    (0.55, 0.85, 0.20), (0.95, 0.45, 0.65), (0.25, 0.60, 0.65), (0.65, 0.45, 0.25),
)


def _bake_id_map(context, op) -> bool:
    rows = _edit_targets(context)
    if not rows:
        return _no_uv(context, op)
    sync = _sync(context)
    colors: dict = {}
    many_materials = any(len(obj.data.materials) > 1 for obj, _bm, _uv in rows)
    next_index = 0
    for obj, bm, uv in rows:
        if many_materials:
            for f in bm.faces:
                colors[f] = _ID_COLORS[f.material_index % len(_ID_COLORS)]
        else:
            for group in _islands(bm, uv, sync):
                color = _ID_COLORS[next_index % len(_ID_COLORS)]
                next_index += 1
                for f in group:
                    colors[f] = color
    tris = _triangles(rows, sync, selected_only=False)
    size = min(_bake_size(context), 4096)

    def color_of(item):
        c = colors.get(item[0], (0.5, 0.5, 0.5))
        return (c[0], c[1], c[2], 1.0)

    _mask, data = _rasterize(size, tris, color_of)
    image = _ensure_image(_ID_IMAGE, size)
    image.pixels.foreach_set(data.ravel())
    image.update()
    image.pack()
    _show_image(context, image)
    kind = ('material', 'マテリアル') if many_materials else ('island', 'アイランド')
    _info(context, op, f'Painted the image "{image.name}" by {kind[0]}.', f'画像「{image.name}」を{kind[1]}ごとに塗り分けました。')
    return True


def _preview_texture(context, op) -> bool:
    shown = 0
    new_type = None
    for area in getattr(context.screen, 'areas', []) or []:
        if area.type != 'VIEW_3D':
            continue
        shading = area.spaces.active.shading
        if new_type is None:
            new_type = 'SOLID' if shading.type == 'MATERIAL' else 'MATERIAL'
        shading.type = new_type
        area.tag_redraw()
        shown += 1
    if not shown:
        _warn(context, op, 'Open a 3D Viewport first.', '先に 3D ビューを開いてください。')
        return False
    if new_type == 'MATERIAL':
        _info(context, op, 'The 3D Viewport now shows materials and textures.', '3D ビューをマテリアルの表示にしました。もう 1 回押すと元に戻ります。')
    else:
        _info(context, op, 'The 3D Viewport is back to solid display.', '3D ビューをソリッドの表示に戻しました。')
    return True


# ---------------------------------------------------------------------------
# Reports and generated data
# ---------------------------------------------------------------------------
def _report_lines(context, rows) -> list:
    lines = []
    sync = _sync(context)
    scan = _scan(context, rows)
    for obj, bm, uv in rows:
        islands = _islands(bm, uv, sync)
        lines.append(f'{obj.name}  UV: {uv.name}  faces: {len(bm.faces)}  islands: {len(islands)}')
        lines.append('  overlap {0}, flipped {1}, zero area {2}, outside tile {3}, stretched {4}'.format(
            len(scan['overlap'][bm]), len(scan['flipped'][bm]), len(scan['zero'][bm]), len(scan['outside'][bm]), len(scan['stretch'][bm])))
    return lines


def _show_text(context, text) -> None:
    for area in getattr(context.screen, 'areas', []) or []:
        if area.type == 'TEXT_EDITOR':
            area.spaces.active.text = text


def _write_text(name: str, lines: list):
    text = bpy.data.texts.get(name) or bpy.data.texts.new(name)
    text.clear()
    text.write('\n'.join(lines) + '\n')
    text[_REPORT_MARK] = True
    return text


def _write_inspection(context, op) -> bool:
    rows = _edit_targets(context)
    if not rows:
        return _no_uv(context, op)
    name = str(getattr(_ws(context), 'scan_report_name', '') or 'SUV_Scan_Report')
    text = _write_text(name, _report_lines(context, rows))
    _show_text(context, text)
    _info(context, op, f'Wrote the report to the text "{text.name}". Read it in the Text Editor.', f'レポートをテキスト「{text.name}」に書きました。テキストエディターで読めます。')
    return True


def _analyze_cockpit(context, op) -> bool:
    return 'FINISHED' in bpy.ops.smart_uv_suite.cockpit_analyze()


def _select_udim_native(context, op) -> bool:
    return 'FINISHED' in _u._execute_action(context, op, 'SELECT_UDIM', op.bl_label)


def _place_atlas_cell(context, op) -> bool:
    return 'FINISHED' in _u._execute_action(context, op, 'ATLAS_SNAP', op.bl_label)


def _center_islands(context, op) -> bool:
    return 'FINISHED' in bpy.ops.uv.suv_centralize_islands(scope=op.scope or 'SELECTED')


def _rotate_islands(context, op) -> bool:
    return 'FINISHED' in bpy.ops.uv.suv_rotate_islands(scope=op.scope or 'SELECTED')


def _flip_islands(axis):
    def run(context, op):
        return 'FINISHED' in bpy.ops.uv.suv_flip_islands(axis=axis, scope=op.scope or 'SELECTED')
    return run


def _flatten_shape_key(context, op) -> bool:
    args = {'name': op.name} if op.name else {}
    return 'FINISHED' in bpy.ops.smart_uv_suite.consolidated_flatten_to_uv_shape_key(**args)


def _run_uv_report(name, **kwargs):
    def run(context, op):
        return 'FINISHED' in getattr(bpy.ops.uv, name)(**kwargs)
    return run


def _run_uv_layout(name, *, namespace='uv', defaults=None, **properties):
    def run(context, op):
        options = dict(defaults or ())
        options.update((target, getattr(op, source)) for target, source in properties.items()
                       if op.properties.is_property_set(source))
        return 'FINISHED' in getattr(getattr(bpy.ops, namespace), name)(**options)
    return run


def _reorder_uvmap(context, op):
    return 'FINISHED' in bpy.ops.mesh.suv_uvmap_reorder(direction=op.direction or 'UP')


def _zoom_selected_mesh(context, op):
    area = getattr(context, 'area', None)
    if getattr(area, 'type', '') != 'VIEW_3D':
        area = next((item for item in getattr(context.screen, 'areas', ()) if item.type == 'VIEW_3D'), None)
    region = next((item for item in getattr(area, 'regions', ()) if item.type == 'WINDOW'), None)
    if region is None or context.mode != 'EDIT_MESH' or not _edit_targets(context):
        return False
    with context.temp_override(area=area, region=region):
        return 'FINISHED' in bpy.ops.view3d.view_selected(use_all_regions=False)


def _texel_density(action):
    def run(context, op):
        return _u._density_action(context, action, op) > 0
    return run


def _smart_action_route(context, op) -> bool:
    action = op.action.strip().upper() or 'FULL_AUTO'
    return 'FINISHED' in bpy.ops.smart_uv_suite.uv_router_action(action=action)


def _smart_tool_route(context, op) -> bool:
    return 'FINISHED' in bpy.ops.smart_uv_suite.uv_router_tool(target=op.target)


def _apply_flow_profile(name):
    def run(context, op):
        options = {}
        if op.profile:
            options['profile'] = op.profile
        if op.scope:
            options['scope'] = op.scope
        return 'FINISHED' in getattr(bpy.ops.uv, name)(**options)
    return run


def _native_uv_clipboard(name):
    def run(context, op):
        from .base import _UVOverride

        obj = context.active_object
        if obj is None or obj.type != 'MESH' or obj.mode != 'EDIT' or obj.data.uv_layers.active is None:
            return _no_uv(context, op)
        with _UVOverride(context) as override:
            if not override.kwargs:
                return False
            with context.temp_override(**override.kwargs):
                native = getattr(bpy.ops.uv, name)
                return native.poll() and 'FINISHED' in native()
    return run


def _unwrap_projection(name, **kwargs):
    def run(context, op):
        return _u._run_unwrap(context, name, **kwargs)
    return run


def _upgrade_report(key):
    def run(context, op):
        from .upgrade_reports import write_report

        return write_report(context, op, key)
    return run


def _set_section_visibility(context, op):
    return 'FINISHED' in bpy.ops.uv.suv_quality_set_section_visibility(
        section_id=op.name or 'workflow', visible=(op.mode or 'SHOW').upper() != 'HIDE')


def _inspector_scan(context, op):
    return 'FINISHED' in bpy.ops.uv.suv_inspector_scan(scope=op.scope or getattr(_ws(context), 'scan_scope', 'SELECTED'))


def _inspector_select(context, op):
    return 'FINISHED' in bpy.ops.uv.suv_inspector_select(
        issue=op.issue or 'FLIPPED', apply_mode=op.apply_mode or 'REPLACE', auto_scan=op.auto_scan,
        scan_scope=op.scope or getattr(_ws(context), 'scan_scope', 'SELECTED'))


def _overlay_tools(name):
    def run(context, op):
        kwargs = {'mode': op.mode} if op.mode else {}
        return 'FINISHED' in getattr(bpy.ops.uv, name)(**kwargs)
    return run


def _apply_preset(name):
    def run(context, op):
        operator = getattr(bpy.ops.uv, name)
        return 'FINISHED' in (operator(preset=op.preset) if op.preset else operator())
    return run


def _select_udim_crossing(context, op) -> bool:
    return 'FINISHED' in bpy.ops.uv.suv_select_udim_crossing(scope=op.scope or 'ALL')


def _projection_bridge(context, op) -> bool:
    return 'FINISHED' in bpy.ops.uv.suv_projection_bridge(mode=op.mode or 'NORMAL_AUTO')


def _histogram_tools(context, op) -> bool:
    return 'FINISHED' in bpy.ops.uv.suv_histogram_tools(mode=op.mode or 'REPORT_SELECTED')


def _seam_set(action):
    def run(context, op):
        kwargs = {}
        if op.name:
            kwargs['text_name' if action == 'library_io' else 'set_name'] = op.name
        if action == 'library_io':
            if op.mode:
                kwargs['mode'] = op.mode
            if op.scope:
                kwargs['scope'] = op.scope
            if op.filepath:
                kwargs['filepath'] = op.filepath
        if op.apply_mode and action in {'recall', 'transfer', 'library_io'}:
            kwargs['apply_mode'] = op.apply_mode
        return 'FINISHED' in getattr(bpy.ops.uv, 'suv_seam_set_' + action)(**kwargs)
    return run


def _object_uv_clipboard(paste):
    def run(context, op):
        obj = context.active_object
        layer = obj.data.uv_layers.active if obj and obj.type == 'MESH' and obj.mode == 'OBJECT' else None
        if layer is None or not len(layer.uv) or (paste and not _u._UV_COPY_BUFFER):
            return _no_uv(context, op)
        if paste:
            for index, item in enumerate(layer.uv):
                item.vector = _u._UV_COPY_BUFFER[index % len(_u._UV_COPY_BUFFER)]
            obj.data.update()
        else:
            _u._UV_COPY_BUFFER[:] = [tuple(item.vector) for item in layer.uv]
        return True
    return run


def _toggle_uv_sync(context, op) -> bool:
    return 'FINISHED' in bpy.ops.uv.suv_uv_sync_mode_toggle(mode=op.mode or 'TOGGLE')


def _workspace_settings_io(context, op) -> bool:
    kwargs = {'mode': op.mode or 'EXPORT_TEXT'}
    if op.name:
        kwargs['text_name'] = op.name
    if op.filepath:
        kwargs['filepath'] = op.filepath
    return 'FINISHED' in bpy.ops.uv.suv_workspace_settings_io(**kwargs)


def _write_validation_report(context, op) -> bool:
    from .ui import _suv_write_validation_report
    _suv_write_validation_report(context)
    return True


def _diagnostics_lines(context) -> list:
    lines = [f'Blender {bpy.app.version_string}', f'Scene: {context.scene.name}', f'Mode: {context.mode}']
    ts = context.tool_settings
    lines.append(f'UV sync: {ts.use_uv_select_sync}  UV select mode: {ts.uv_select_mode}  sticky: {ts.uv_sticky_select_mode}')
    for obj in _mesh_objects(context):
        names = ', '.join(layer.name for layer in obj.data.uv_layers) or '-'
        lines.append(f'{obj.name}  verts: {len(obj.data.vertices)}  faces: {len(obj.data.polygons)}  UV maps: {names}')
    return lines


def _open_diagnostics(context, op) -> bool:
    text = _write_text(_DIAG_TEXT, _diagnostics_lines(context))
    _show_text(context, text)
    _info(context, op, f'Wrote the diagnostics to the text "{text.name}". Read it in the Text Editor.', f'診断の内容をテキスト「{text.name}」に書きました。テキストエディターで読めます。')
    return True


def _write_diagnostics(context, op) -> bool:
    path = _file_path(op, '.txt')
    if not path:
        return False
    with open(path, 'w', encoding='utf-8') as handle:
        handle.write('\n'.join(_diagnostics_lines(context)) + '\n')
    _info(context, op, f'Saved {path}.', f'{path} に保存しました。')
    return True


_REPORT_NAMES = frozenset((
    'Smart UV Suite Report', _DIAG_TEXT, 'SUV_Scan_Report', 'SUV_Validation_Report', 'SUV_Batch_Report',
    'SUV_Support_Bundle', 'SUV_Runtime_Log', 'SUV_Runtime_Snapshot', 'SUV_External_Compatibility_Report',
))


def _is_report_text(text) -> bool:
    return bool(text.get(_REPORT_MARK)) or text.name in _REPORT_NAMES


def _clear_reports(context, op) -> bool:
    count = 0
    for text in list(bpy.data.texts):
        if _is_report_text(text):
            bpy.data.texts.remove(text)
            count += 1
    _info(context, op, f'Removed {count} report texts.', f'レポートのテキストを {count} 個消しました。')
    return True


def _clean_generated(context, op) -> bool:
    count = 0
    for name in (_ID_IMAGE,):
        image = bpy.data.images.get(name)
        if image is not None:
            bpy.data.images.remove(image)
            count += 1
    for mat in list(bpy.data.materials):
        if mat.name.startswith('Smart UV Checker') and mat.users == 0:
            bpy.data.materials.remove(mat)
            count += 1
    for name in (_BAKE_IMAGE,):
        image = bpy.data.images.get(name)
        if image is not None and image.users == 0:
            bpy.data.images.remove(image)
            count += 1
    _clear = 0
    for text in list(bpy.data.texts):
        if _is_report_text(text):
            bpy.data.texts.remove(text)
            _clear += 1
    _info(context, op, f'Removed {count + _clear} generated items.', f'Smart UV が作った物を {count + _clear} 個消しました。')
    return True


# ---------------------------------------------------------------------------
# Files
# ---------------------------------------------------------------------------
def _file_path(op, ext: str) -> str:
    path = str(op.filepath or '')
    if not path:
        return ''
    path = bpy.path.abspath(path)
    if not path.lower().endswith(ext):
        path += ext
    return path


def _file_invoke_for(default_name: str) -> Callable:
    def invoke(context, op, event):
        if not op.filepath:
            op.filepath = default_name
        context.window_manager.fileselect_add(op)
        return {'RUNNING_MODAL'}
    return invoke


def _settings_payload(ws) -> dict:
    data = {}
    for prop in ws.bl_rna.properties:
        pid = prop.identifier
        if pid == 'rna_type' or prop.is_readonly or prop.type not in {'BOOLEAN', 'INT', 'FLOAT', 'STRING', 'ENUM'}:
            continue
        value = getattr(ws, pid)
        if prop.type in {'BOOLEAN', 'INT', 'FLOAT'} and getattr(prop, 'is_array', False):
            value = list(value)
        elif isinstance(value, (set, frozenset)):
            value = sorted(value)
        data[pid] = value
    return data


def _settings_export(context, op) -> bool:
    ws = _ws(context)
    path = _file_path(op, '.json')
    if ws is None or not path:
        return False
    with open(path, 'w', encoding='utf-8') as handle:
        json.dump(_settings_payload(ws), handle, ensure_ascii=False, indent=1)
    _info(context, op, f'Saved the Smart UV settings to {path}.', f'Smart UV の設定を {path} に書き出しました。')
    return True


def _settings_import(context, op) -> bool:
    ws = _ws(context)
    path = _file_path(op, '.json')
    if ws is None or not path:
        return False
    with open(path, 'r', encoding='utf-8') as handle:
        data = json.load(handle)
    count = 0
    for key, value in data.items():
        try:
            if isinstance(value, list) and ws.bl_rna.properties[key].type == 'ENUM':
                value = set(value)
            setattr(ws, key, value)
            count += 1
        except Exception:
            continue
    _info(context, op, f'Loaded {count} settings.', f'設定を {count} 項目読み込みました。')
    return True


def _workspace_reset(context, op) -> bool:
    ws = _ws(context)
    if ws is None:
        return False
    count = 0
    for prop in ws.bl_rna.properties:
        if prop.identifier == 'rna_type' or prop.is_readonly:
            continue
        try:
            ws.property_unset(prop.identifier)
            count += 1
        except Exception:
            continue
    _info(context, op, 'Reset the Smart UV settings to their defaults.', 'Smart UV の設定を初めの値に戻しました。')
    return True


def _refresh_sidebar(context, op) -> bool:
    if getattr(context.area, "type", None) != "VIEW_3D":
        return False
    return 'FINISHED' in bpy.ops.wm.suv_toggle_properties_pseudo_tab()


def _confirm_invoke(context, op, event) -> set:
    return context.window_manager.invoke_confirm(
        op, event,
        title=_t(context, 'Reset Settings', '設定を戻す'),
        message=_t(context, 'Return all Smart UV settings to their defaults?', 'Smart UV の設定を全部、初めの値に戻します。'),
        confirm_text=_t(context, 'Reset', '戻す'),
    )


def _active_edit_row(context):
    rows = _edit_targets(context)
    active = getattr(context, 'active_object', None)
    for row in rows:
        if row[0] is active:
            return row
    return rows[0] if rows else None


def _layout_export(context, op) -> bool:
    row = _active_edit_row(context)
    path = _file_path(op, '.json')
    if row is None or not path:
        return _no_uv(context, op)
    _obj, bm, uv = row
    payload = {'faces': [[list(l[uv].uv) for l in f.loops] for f in bm.faces]}
    with open(path, 'w', encoding='utf-8') as handle:
        json.dump(payload, handle)
    _info(context, op, f'Saved the UV layout to {path}.', f'UV の配置を {path} に書き出しました。')
    return True


def _layout_import(context, op) -> bool:
    row = _active_edit_row(context)
    path = _file_path(op, '.json')
    if row is None or not path:
        return _no_uv(context, op)
    _obj, bm, uv = row
    with open(path, 'r', encoding='utf-8') as handle:
        faces = json.load(handle).get('faces', [])
    if len(faces) != len(bm.faces) or any(len(a) != len(f.loops) for a, f in zip(faces, bm.faces)):
        _warn(context, op, 'This file was saved from a mesh with a different structure.', 'このファイルは、面のつくりが違うメッシュのものです。')
        return False
    for values, f in zip(faces, bm.faces):
        for value, l in zip(values, f.loops):
            l[uv].uv = value
    _flush([row])
    _info(context, op, 'Loaded the UV layout.', 'UV の配置を読み込みました。')
    return True


def _seam_export(context, op) -> bool:
    row = _active_edit_row(context)
    path = _file_path(op, '.json')
    if row is None or not path:
        return _no_uv(context, op)
    _obj, bm, _uv = row
    edges = [[e.verts[0].index, e.verts[1].index] for e in bm.edges if e.seam]
    with open(path, 'w', encoding='utf-8') as handle:
        json.dump({'verts': len(bm.verts), 'seams': edges}, handle)
    _info(context, op, f'Saved {len(edges)} seam edges to {path}.', f'シームの辺 {len(edges)} 本を {path} に書き出しました。')
    return True


def _seam_import(context, op) -> bool:
    row = _active_edit_row(context)
    path = _file_path(op, '.json')
    if row is None or not path:
        return _no_uv(context, op)
    _obj, bm, _uv = row
    with open(path, 'r', encoding='utf-8') as handle:
        data = json.load(handle)
    if int(data.get('verts', -1)) != len(bm.verts):
        _warn(context, op, 'This file was saved from a mesh with a different structure.', 'このファイルは、面のつくりが違うメッシュのものです。')
        return False
    bm.verts.ensure_lookup_table()
    wanted = {frozenset(pair) for pair in data.get('seams', [])}
    count = 0
    for e in bm.edges:
        e.seam = frozenset((e.verts[0].index, e.verts[1].index)) in wanted
        count += int(e.seam)
    _flush([row])
    _info(context, op, f'Loaded {count} seam edges.', f'シームの辺を {count} 本読み込みました。')
    return True


def _selection_export(context, op) -> bool:
    row = _active_edit_row(context)
    path = _file_path(op, '.json')
    if row is None or not path:
        return _no_uv(context, op)
    _obj, bm, _uv = row
    sync = _sync(context)
    faces = [f.index for f in bm.faces if _face_selected(f, sync)]
    with open(path, 'w', encoding='utf-8') as handle:
        json.dump({'count': len(bm.faces), 'faces': faces}, handle)
    _info(context, op, f'Saved {len(faces)} selected faces to {path}.', f'選んでいる {len(faces)} 面を {path} に書き出しました。')
    return True


def _selection_import(context, op) -> bool:
    row = _active_edit_row(context)
    path = _file_path(op, '.json')
    if row is None or not path:
        return _no_uv(context, op)
    _obj, bm, _uv = row
    with open(path, 'r', encoding='utf-8') as handle:
        data = json.load(handle)
    if int(data.get('count', -1)) != len(bm.faces):
        _warn(context, op, 'This file was saved from a mesh with a different structure.', 'このファイルは、面のつくりが違うメッシュのものです。')
        return False
    faces = {bm.faces[i] for i in data.get('faces', []) if 0 <= i < len(bm.faces)}
    _select_faces(context, bm, faces)
    _flush([row])
    _info(context, op, f'Selected {len(faces)} faces.', f'{len(faces)} 面を選びました。')
    return True


# ---------------------------------------------------------------------------
# Table
# ---------------------------------------------------------------------------
@dataclass
class Handler:
    run: Callable
    tip_en: str
    tip_ja: str
    invoke: Optional[Callable] = None
    draw: Optional[Callable] = None


# The file browser takes its title and run button from the operator name, so
# each save and load button is its own operator.
FILE_BUTTONS = (
    ('smart_uv_suite.settings_save', 'Save Settings', '設定書き出し'),
    ('smart_uv_suite.settings_load', 'Load Settings', '設定読み込み'),
    ('smart_uv_suite.seams_save', 'Save Seams', 'シーム書き出し'),
    ('smart_uv_suite.seams_load', 'Load Seams', 'シーム読み込み'),
    ('smart_uv_suite.layout_save', 'Save Layout', '配置書き出し'),
    ('smart_uv_suite.layout_load', 'Load Layout', '配置読み込み'),
    ('smart_uv_suite.selection_save', 'Save Selection', '選択書き出し'),
    ('smart_uv_suite.selection_load', 'Load Selection', '選択読み込み'),
    ('smart_uv_suite.diagnostics_save', 'Save Diagnostics', '診断を保存'),
)


HANDLERS: dict = {
    'smart_uv_suite.workflow_uv_router_action': Handler(_smart_action_route, 'Run the selected Smart UV action.', '選択した Smart UV 操作を実行します。'),
    'smart_uv_suite.workflow_uv_router_tool': Handler(_smart_tool_route, 'Run the Smart UV route for the supplied tool target.', '指定されたツールの Smart UV ルートを実行します。'),
    'smart_uv_suite.select_stacked': Handler(_select_stacked, 'Select islands that lie on top of an island with the same bounds.', '同じ位置・同じ大きさで重なっているアイランドを選びます。'),
    'smart_uv_suite.select_square_island': Handler(_select_square, 'Select islands that fill an axis-aligned rectangle.', '軸にそろった長方形を満たしているアイランドを選びます。'),
    'smart_uv_suite.select_by_area': Handler(_select_by_area, 'Select islands whose UV area is close to the selected island.', '選んでいるアイランドと UV の面積が近いアイランドを選びます。'),
    'smart_uv_suite.select_texel_density': Handler(_select_by_density, 'Select islands whose texel density is close to the selected island.', '選んでいるアイランドとテクセル密度が近いアイランドを選びます。'),
    'smart_uv_suite.select_by_cursor': Handler(_select_by_cursor, 'Select the island under the 2D cursor.', '2D カーソルの下にあるアイランドを選びます。'),
    'smart_uv_suite.select_edge': Handler(_select_directional_edges, 'Select every UV edge running in the same direction as the selected edge.', '選んでいる辺と同じ向きの UV の辺を全部選びます。'),
    'smart_uv_suite.select_half': Handler(_select_half, 'Keep only the left half of the selected islands selected.', '選んでいるアイランドの左半分の面だけを選びます。'),
    'smart_uv_suite.select_fragmented_islands': Handler(_select_fragmented, 'Select very small islands and islands of one or two faces.', 'とても小さいアイランドと、1〜2 面だけのアイランドを選びます。'),
    'smart_uv_suite.select_mirror3d': Handler(_select_mirror3d, 'Add the faces on the opposite side of the object X axis to the selection.', 'オブジェクトの X 軸の反対側にある面を選択に足します。'),
    'smart_uv_suite.select_uv_boundary': Handler(_select_uv_boundary, 'Select the outer edges of the selected islands.', '選んでいるアイランドの外周の辺を選びます。'),
    'smart_uv_suite.select_uv_zoom_selected_uv': Handler(_zoom_selected_mesh, 'Frame the selected mesh elements in the 3D View.', '選択メッシュ要素を 3D ビューの中央に表示します。'),
    'smart_uv_suite.inspect_inspector_select_all': Handler(_select_issues, 'Select faces that overlap, are flipped, have no area, leave the tile or are stretched.', '重なり・裏返り・面積ゼロ・枠の外・伸びの面を全部選びます。'),
    'smart_uv_suite.inspect_check_over': Handler(_select_issue('outside'), 'Select faces extending outside the base UV tile.', '基準 UV タイルからはみ出した面を選びます。'),
    'smart_uv_suite.inspect_check_overlap': Handler(_select_issue('overlap'), 'Select both faces in each overlapping UV pair.', 'UV が重なっている面を両方選びます。'),
    'smart_uv_suite.select_grow': Handler(_native_uv_selection('select_more'), 'Grow the UV selection by one step.', 'UV 選択を 1 段階広げます。'),
    'smart_uv_suite.select_linked_select': Handler(_native_uv_selection('select_linked'), 'Select the UV islands linked to the current selection.', '現在の選択につながる UV アイランドを選びます。'),
    'smart_uv_suite.select_similar': Handler(_run_uv_report('suv_select_similar_islands'), 'Select islands similar in size and aspect to the active island.', 'アクティブな島と大きさや縦横比が近いアイランドを選びます。'),
    'smart_uv_suite.select_similar_select': Handler(_run_uv_report('suv_select_similar_islands'), 'Select islands similar in size and aspect to the active island.', 'アクティブな島と大きさや縦横比が近いアイランドを選びます。'),
    'smart_uv_suite.inspect_inspector_scan': Handler(_inspector_scan, 'Scan UVs and record the issues found.', 'UV を検査し、見つかった問題を記録します。'),
    'smart_uv_suite.inspect_inspector_rescan': Handler(_run_uv_report('suv_inspector_rescan'), 'Repeat the previous UV inspection.', '直前の UV 検査を再実行します。'),
    'smart_uv_suite.inspect_inspector_clear_cache': Handler(_run_uv_report('suv_inspector_clear_cache'), 'Clear the cached UV inspection results.', '保存された UV 検査結果を消去します。'),
    'smart_uv_suite.inspect_inspector_select': Handler(_inspector_select, 'Select faces with the chosen UV issue.', '指定した UV の問題がある面を選択します。'),
    'smart_uv_suite.inspect_workspace_validate': Handler(_validate, 'Count the UV issues and show the result at the bottom of the window.', 'UV の問題を数えて、結果を画面の下に出します。UV は変えません。'),
    'smart_uv_suite.inspect_fix_all_issues': Handler(_fix_issues, 'Turn flipped islands back and move overlapping islands apart.', '裏返ったアイランドを戻し、重なったアイランドを離します。'),
    'smart_uv_suite.inspect_unstack_overlapped': Handler(_unstack_overlapped, 'Move overlapping islands to free space without changing their size.', '重なっているアイランドを、大きさを変えずに空いている所へ動かします。'),
    'smart_uv_suite.inspect_clear_all_reports': Handler(_clear_reports, 'Delete the report texts written by Smart UV.', 'Smart UV が書いたレポートのテキストを消します。'),
    'smart_uv_suite.inspect_smart_tube': Handler(_run_uv_report('suv_smart_tube'), 'Project the selected faces onto a cylinder.', '選択した面を円筒に投影します。'),
    'smart_uv_suite.align_orient': Handler(_run_uv_report('suv_orient_islands'), 'Rotate the selected islands to a compact orientation.', '選択したアイランドをコンパクトな向きに回転します。'),
    'smart_uv_suite.inspect_orient_to_edge': Handler(_run_uv_report('suv_orient_to_edge'), 'Rotate islands to align the selected UV edge to the nearest axis.', '選択した UV 辺が最も近い軸に揃うようアイランドを回転します。'),
    'smart_uv_suite.align_straight_line': Handler(_run_uv_report('suv_straight_line'), 'Straighten the selected UV chains.', '選択した UV チェーンを直線にします。'),
    'smart_uv_suite.align_set_flow': Handler(_run_uv_report('suv_set_flow'), 'Smooth the flow of the selected UV chains.', '選択した UV チェーンの流れを滑らかにします。'),
    'smart_uv_suite.pack_smart_edge_straighten': Handler(_run_uv_report('suv_smart_edge_straighten'), 'Straighten the selected UV edges.', '選択した UV 辺を直線にします。'),
    'smart_uv_suite.seam_stack_grouped': Handler(_run_uv_report('suv_stack_grouped'), 'Stack selected islands of similar shape.', '形が似ている選択アイランドを重ねます。'),
    'smart_uv_suite.seam_stack_topology_groups': Handler(_run_uv_report('suv_stack_topology_groups'), 'Stack selected islands with matching mesh topology.', 'メッシュのトポロジーが一致する選択アイランドを重ねます。'),
    'smart_uv_suite.seam_stack_symmetry_topology': Handler(_run_uv_report('suv_stack_symmetry_topology'), 'Stack selected islands with symmetric mesh topology.', 'メッシュのトポロジーが対称な選択アイランドを重ねます。'),
    'smart_uv_suite.seam_flip_islands': Handler(_run_uv_report('suv_flip_islands'), 'Flip the selected islands horizontally.', '選択したアイランドを左右反転します。'),
    'smart_uv_suite.seam_smart_seams': Handler(_run_uv_report('suv_smart_seams'), 'Mark seams using mesh boundaries, angles, sharp edges and material borders.', '境界、角度、シャープ辺、マテリアル境界に基づいてシームをマークします。'),
    'smart_uv_suite.pack_crop_tile': Handler(_run_uv_layout('suv_crop_tile', padding_px='margin_px', texture_size='texture_size', scope='scope'), 'Fit the selected islands within their tile while preserving aspect ratio.', '縦横比を保ちながら選択アイランドをタイルに収めます。'),
    'smart_uv_suite.pack_fill_tile': Handler(_run_uv_layout('suv_fill_tile', padding_px='margin_px', texture_size='texture_size', scope='scope'), 'Scale the selected islands to fill their tile.', '選択アイランドを拡大してタイルいっぱいに配置します。'),
    'smart_uv_suite.pack_distribute_islands': Handler(_run_uv_layout('suv_distribute_islands', axis='axis', scope='scope'), 'Space the selected islands evenly along the chosen axis.', '選んだ軸に沿って選択アイランドを等間隔に配置します。'),
    'smart_uv_suite.pack_trim_strip_layout': Handler(_run_uv_layout('suv_trim_strip_layout', axis='axis', padding_px='margin_px', texture_size='texture_size', scope='scope'), 'Arrange selected islands in a trim strip.', '選択アイランドをトリムストリップに配置します。'),
    'smart_uv_suite.pack_trim_band_layout': Handler(_run_uv_layout('suv_trim_band_layout', axis='axis', band_count='band_count', padding_px='margin_px', texture_size='texture_size', scope='scope'), 'Arrange selected islands in several trim bands.', '選択アイランドを複数のトリム帯に配置します。'),
    'smart_uv_suite.pack_apply_hotspot_preset': Handler(_run_uv_layout('suv_apply_hotspot_preset', preset='preset'), 'Load the hotspot preset into the workspace.', 'ホットスポットプリセットを作業環境に読み込みます。'),
    'smart_uv_suite.pack_apply_named_layout_library': Handler(_run_uv_layout('suv_apply_named_layout_library', library='preset'), 'Load the named layout settings into the workspace.', '名前付きレイアウト設定を作業環境に読み込みます。'),
    'smart_uv_suite.pack_hotspot_cell_tools': Handler(_run_uv_layout('suv_hotspot_cell_tools', mode='mode', scope='scope', cols='columns', rows='rows', padding_px='margin_px', texture_size='texture_size'), 'Select hotspot cells, place groups into cells, or export cell usage.', 'ホットスポットセルを選択し、グループを配置し、セルの使用状況を書き出します。'),
    'smart_uv_suite.pack_groups_to_tiles': Handler(_run_uv_layout('suv_groups_to_tiles', mode='mode', scope='scope', margin_px='margin_px', texture_size='texture_size'), 'Move island groups to separate UDIM tiles.', 'アイランドグループを別々の UDIM タイルに移動します。'),
    'smart_uv_suite.pack_group_normalize_layout': Handler(_run_uv_layout('suv_group_normalize_layout', mode='mode', scope='scope'), 'Normalize the size of the island groups.', 'アイランドグループの大きさをそろえます。'),
    'smart_uv_suite.pack_orient_groups_advanced': Handler(_run_uv_layout('suv_orient_groups_advanced', scope='scope'), 'Orient selected island groups using the native orientation tool.', '選択したアイランドグループの向きを専用ツールで調整します。'),
    'smart_uv_suite.pack_external_layout_profile': Handler(_run_uv_layout('suv_external_layout_profile', profile='profile', scope='scope', margin_px='margin_px', texture_size='texture_size', band_count='band_count'), 'Run the chosen layout profile on the active mesh.', 'アクティブなメッシュに指定のレイアウトプロファイルを適用します。'),
    'smart_uv_suite.pack_batch_layout_profile': Handler(_run_uv_layout('suv_batch_layout_profile', profile='profile', scope='scope', margin_px='margin_px', texture_size='texture_size', band_count='band_count'), 'Run the chosen layout profile on the selected meshes.', '選択メッシュに指定のレイアウトプロファイルを一括適用します。'),
    'smart_uv_suite.inspect_audit_chain_preset': Handler(_run_uv_layout('suv_audit_chain_preset', mode='mode', scope='scope', margin_px='margin_px', texture_size='texture_size', band_count='band_count'), 'Save, inspect or run audit relayout chains.', '監査に基づく再配置チェーンを保存、確認、実行します。'),
    'smart_uv_suite.pack_layout_recipe_materialize': Handler(_run_uv_layout('suv_layout_recipe_materialize', mode='mode', scope='scope', margin_px='margin_px', texture_size='texture_size', band_axis='axis'), 'Build a layout plan from the recommendation or apply its template.', '推奨結果から配置計画を作成するか、テンプレートを適用します。'),
    'smart_uv_suite.seam_candidate_tools': Handler(_run_uv_layout('suv_uv_seam_candidate_tools', mode='mode', scope='scope'), 'Inspect and apply UV seam candidates.', 'UV シーム候補を確認して適用します。'),
    'smart_uv_suite.seam_candidate_profile_tools': Handler(_run_uv_layout('suv_uv_seam_candidate_profile_tools', mode='mode', scope='scope'), 'Save and apply seam candidate profiles.', 'シーム候補プロファイルを保存して適用します。'),
    'smart_uv_suite.seam_candidate_profile_audit_tools': Handler(_run_uv_layout('suv_uv_seam_candidate_profile_audit_tools', mode='mode', scope='scope'), 'Audit seam candidate profiles.', 'シーム候補プロファイルを監査します。'),
    'smart_uv_suite.seam_candidate_profile_batch_tools': Handler(_run_uv_layout('suv_uv_seam_candidate_profile_batch_tools', mode='mode', profile_name='name', builtin_profile='profile'), 'Apply a seam candidate profile across the selected objects.', '選択オブジェクト全体にシーム候補プロファイルを適用します。'),
    'smart_uv_suite.pack_boundary_to_shape': Handler(_run_uv_layout('boundary_to_shape', namespace='suv', mode='mode'), 'Shape the selected UV boundary into a circle or quadrilateral.', '選択した UV 境界を円または四角形に整えます。'),
    'smart_uv_suite.seam_constraint_unwrap': Handler(_run_uv_layout('constraint_unwrap', namespace='suv', mode='mode'), 'Unwrap UVs using the chosen algorithm and preserve pin constraints.', '指定の方式で UV を展開し、ピンの制約を保持します。'),
    'smart_uv_suite.pack_constraint_relax_preserve': Handler(
        _run_uv_layout('suv_constraint_relax_preserve', mode='mode', scope='scope', anchor_mode='anchor_mode',
                       temporary_anchors='temporary_anchors', preserve_position='preserve_position',
                       preserve_area='preserve_area', preserve_rotation='preserve_rotation', keep_tile='keep_tile',
                       average_scale_each_pass='average_scale_each_pass', iterations='iterations', passes='passes',
                       pack_after='pack_after'),
        'Relax selected UV islands under the current constraints.', '現在の制約を保ちながら選択 UV アイランドを緩和します。'),
    'smart_uv_suite.auto_seam_advanced': Handler(_run_uv_layout('suv_auto_seam_advanced', mode='mode', scope='scope', angle_threshold='angle'), 'Mark seams using the chosen rules and target scope.', '指定の判定条件と対象範囲でシームを付けます。'),
    'smart_uv_suite.texel_group_tools': Handler(_run_uv_layout('suv_texel_group_tools', mode='mode', scope='scope', texture_size='texture_size'), 'Normalize or audit texel density by group.', 'グループごとにテクセル密度をそろえるか監査します。'),
    'smart_uv_suite.inspect_auto_uv_profile': Handler(_run_uv_layout('suv_auto_uv_profile', profile='profile', margin_px='margin_px', texture_size='texture_size'), 'Run the chosen automatic UV profile.', '指定の自動 UV プロファイルを実行します。'),
    'smart_uv_suite.island_uvmesh': Handler(_run_uv_layout('suv_native_stage_mesh', namespace='mesh', defaults={'mode': 'UV_MESH'}), 'Build a planar mesh from the selected faces in the active UV layout.', 'アクティブな UV レイアウトの選択面から平面メッシュを作成します。'),
    'smart_uv_suite.inspect_calc_uv_coverage': Handler(_coverage, 'Measure how much of the tile the UVs cover.', 'UV がタイルを何パーセント覆うかを測定します。'),
    'smart_uv_suite.texel_uvmap_reorder': Handler(_reorder_uvmap, 'Move the active UV map earlier or later in the list.', 'アクティブUVマップを一覧の上または下へ移動します。'),
    'smart_uv_suite.get_texel_density': Handler(_texel_density('GET'), 'Measure the current texel density.', '現在のテクセル密度を測定します。'),
    'smart_uv_suite.set_texel_density': Handler(_texel_density('SET'), 'Apply the measured texel density to the selection.', '測定済みのテクセル密度を選択範囲に適用します。'),
    'smart_uv_suite.inspect_issue_audit_tools': Handler(_run_uv_layout('suv_issue_audit_tools', mode='mode'), 'Audit UV island issues.', 'UV アイランドの問題を監査します。'),
    'smart_uv_suite.inspect_layout_candidate_audit': Handler(_run_uv_layout('suv_layout_candidate_audit', mode='mode', scope='scope', margin_px='margin_px'), 'Audit the current layout and recommend a layout for the selected islands.', '現在の配置を監査し、選択アイランド向けのレイアウトを提案します。'),
    'smart_uv_suite.align_islands': Handler(_run_uv_layout('suv_align_islands', axis='axis', mode='mode', scope='scope'), 'Align selected islands along the chosen axis.', '選んだ軸に沿って選択アイランドを揃えます。'),
    'smart_uv_suite.align_hs_gridify': Handler(_run_uv_layout('suv_hs_gridify', scope='scope'), 'Align selected islands to a regular UV grid.', '選択アイランドを均等な UV グリッドに揃えます。'),
    'smart_uv_suite.align_hs_quad_flow': Handler(_run_uv_report('suv_hs_quad_flow'), 'Straighten the selected quad flow.', '選択クワッドの流れを整えます。'),
    'smart_uv_suite.inspect_explode_islands': Handler(_run_uv_layout('suv_explode_islands', mode='mode', scope='scope'), 'Spread selected islands apart for inspection.', '確認しやすいように選択アイランドを分離します。'),
    'smart_uv_suite.inspect_hs_orthogonalize': Handler(_run_uv_layout('suv_hs_orthogonalize', scope='scope'), 'Rotate selected islands onto an orthogonal basis.', '選択アイランドを直交基準へ回転します。'),
    'smart_uv_suite.inspect_randomize_islands': Handler(_run_uv_layout('suv_randomize_islands', scope='scope'), 'Randomize the layout of the selected islands.', '選択アイランドの配置をランダム化します。'),
    'smart_uv_suite.pack_hs_rectify_constrained': Handler(_run_uv_layout('suv_hs_rectify_constrained', mode='mode', scope='scope'), 'Rectify selected islands with layout constraints.', '配置の制約を使って選択アイランドの形を整えます。'),
    'smart_uv_suite.pack_hs_rectify_fit': Handler(_run_uv_layout('suv_hs_rectify_fit', scope='scope', padding_px='margin_px', texture_size='texture_size'), 'Rectify and fit the selected UV islands.', '選択した UV アイランドを整形し、範囲内に収めます。'),
    'smart_uv_suite.pack_hs_squareify': Handler(_run_uv_layout('suv_hs_squareify', scope='scope'), 'Fit selected islands to square bounds.', '選択アイランドを正方形の範囲に収めます。'),
    'smart_uv_suite.pack_orient_islands': Handler(_run_uv_layout('suv_orient_islands', mode='mode', scope='scope'), 'Orient selected islands for easier layout.', '配置しやすいように選択アイランドの向きを揃えます。'),
    'smart_uv_suite.pack_sort_islands': Handler(_run_uv_layout('suv_sort_islands', axis='axis', scope='scope', gap_px='margin_px', texture_size='texture_size'), 'Sort selected islands by size and arrange them along an axis.', '選択アイランドを大きさ順に並べ、軸に沿って配置します。'),
    'smart_uv_suite.pack_layout_set_save': Handler(_run_uv_layout('suv_layout_set_save', set_name='name'), 'Save the active UV layout in a named set.', 'アクティブな UV 配置を名前付きセットに保存します。'),
    'smart_uv_suite.pack_layout_set_recall': Handler(_run_uv_layout('suv_layout_set_recall', set_name='name'), 'Recall a saved UV layout.', '保存した UV 配置を呼び出します。'),
    'smart_uv_suite.pack_layout_set_update': Handler(_run_uv_layout('suv_layout_set_update', set_name='name'), 'Update a saved set with the current UV layout.', '現在の UV 配置で保存済みセットを更新します。'),
    'smart_uv_suite.pack_layout_set_delete': Handler(_run_uv_layout('suv_layout_set_delete', set_name='name'), 'Delete a saved UV layout set.', '保存した UV 配置セットを削除します。'),
    'smart_uv_suite.pack_layout_set_library_io': Handler(_run_uv_layout('suv_layout_set_library_io', mode='mode', scope='scope', text_name='name', filepath='filepath'), 'Import or export saved UV layout sets.', '保存した UV 配置セットを読み込み、書き出します。'),
    'smart_uv_suite.pack_layout_set_transfer': Handler(_run_uv_layout('suv_layout_set_transfer', set_name='name'), 'Copy a saved UV layout set to the other selected meshes.', '他の選択メッシュに保存済み UV 配置セットをコピーします。'),
    'smart_uv_suite.annotate_align': Handler(_run_uv_report('suv_annotate_align'), 'Project selected UVs onto the active annotation stroke.', '選択したUVをアクティブな注釈線へ投影します。'),
    'smart_uv_suite.apply_pack_profile': Handler(_apply_flow_profile('suv_apply_pack_profile'), 'Apply the named packing profile to the workspace.', '名前付きパックプロファイルを作業環境に適用します。'),
    'smart_uv_suite.apply_seam_profile': Handler(_apply_flow_profile('suv_apply_seam_profile'), 'Mark seams using the selected seam profile.', '選択したシームプロファイルでシームをマークします。'),
    'smart_uv_suite.pack_pro': Handler(_run_uv_report('suv_pack_pro'), 'Pack selected islands using Pack Pro.', 'Pack Pro で選択したアイランドをパックします。'),
    'smart_uv_suite.inspect_apply_density_profile': Handler(_apply_flow_profile('suv_apply_density_profile'), 'Apply the texel-density workflow profile.', 'テクセル密度のワークフロープロファイルを適用します。'),
    'smart_uv_suite.inspect_apply_inspector_profile': Handler(_apply_flow_profile('suv_apply_inspector_profile'), 'Apply the inspector and repair profile.', '検査と修復のプロファイルを適用します。'),
    'smart_uv_suite.inspect_apply_workflow_bundle': Handler(_apply_flow_profile('suv_apply_workflow_bundle'), 'Apply the workflow bundle and run its configured actions.', 'ワークフローバンドルを適用し、設定済みの操作を実行します。'),
    'smart_uv_suite.align_apply_workflow_recipe': Handler(_apply_flow_profile('suv_apply_workflow_recipe'), 'Run the bundles in the selected workflow recipe in order.', '選択したワークフローレシピのバンドルを順番に実行します。'),
    'smart_uv_suite.inspect_quality_scan_generated_data': Handler(_run_uv_report('suv_quality_scan_generated_data'), 'Count the generated data eligible for cleanup.', 'クリーンアップの対象になる生成データを数えます。'),
    'smart_uv_suite.inspect_quality_cleanup_generated_data': Handler(_clean_generated, 'Delete the ID map, unused checker materials and the report texts written by Smart UV.', 'ID マップの画像、使っていないチェッカーのマテリアル、レポートのテキストを消します。'),
    'smart_uv_suite.inspect_inspector_write_report': Handler(_write_inspection, 'Write the issue counts of each object to a text.', 'オブジェクトごとの問題の数をテキストに書きます。'),
    'smart_uv_suite.inspect_cockpit_analyze': Handler(_analyze_cockpit, 'Measure UV quality and write a cockpit report.', 'UV 品質を測定し、コックピットレポートを書き出します。'),
    'smart_uv_suite.inspect_udim_native': Handler(_select_udim_native, 'Select faces outside the first UDIM tile or crossing tile borders.', '最初の UDIM タイルの外にある面と、タイル境界をまたぐ面を選びます。'),
    'smart_uv_suite.select_udim_crossing': Handler(_select_udim_crossing, 'Select UV islands crossing a tile border.', 'タイル境界をまたぐ UV アイランドを選びます。'),
    'smart_uv_suite.inspect_projection_bridge': Handler(_projection_bridge, 'Project the selected geometry using the chosen projection mode.', '選択した形状を指定の投影方式で展開します。'),
    'smart_uv_suite.view_visualize_stretch_heatmap': Handler(lambda context, op: 'FINISHED' in bpy.ops.object.suv_visualize_stretch_heatmap(), 'Show the stretch heatmap on the selected meshes.', '選択したメッシュに伸び歪みのヒートマップを表示します。'),
    'smart_uv_suite.view_clear_stretch_heatmap': Handler(lambda context, op: 'FINISHED' in bpy.ops.object.suv_clear_stretch_heatmap(), 'Remove the stretch heatmap from the selected meshes.', '選択したメッシュの伸び歪みのヒートマップを消去します。'),
    'smart_uv_suite.view_histogram_tools': Handler(_histogram_tools, 'Analyze UV island distributions or select a quartile by area.', 'UV アイランドの分布を分析し、面積の四分位で選択できます。'),
    'smart_uv_suite.view_stack_compare_overlay_tools': Handler(_overlay_tools('suv_uv_stack_compare_overlay_tools'), 'Build or clear the UV stack comparison overlay.', 'UV スタックの比較オーバーレイを作成または消去します。'),
    'smart_uv_suite.view_issue_overlay_tools': Handler(_overlay_tools('suv_issue_overlay_tools'), 'Build or clear the UV issue overlay.', 'UV の問題を示すオーバーレイを作成または消去します。'),
    'smart_uv_suite.seam_candidate_overlay_tools': Handler(_overlay_tools('suv_uv_seam_candidate_overlay_tools'), 'Build or clear the seam candidate overlay.', 'シーム候補のオーバーレイを作成または消去します。'),
    'smart_uv_suite.seam_state_overlay_tools': Handler(_overlay_tools('suv_uv_seam_state_overlay_tools'), 'Build or clear the seam state overlay.', 'シーム状態のオーバーレイを作成または消去します。'),
    'smart_uv_suite.view_similarity_cluster_overlay_tools': Handler(_overlay_tools('suv_uv_similarity_cluster_overlay_tools'), 'Build or clear the island similarity overlay.', 'アイランドの類似度オーバーレイを作成または消去します。'),
    'smart_uv_suite.align_horizontal': Handler(lambda context, op: _u._align_uvs(context, 'VERTICAL') > 0, 'Align selected UVs to a horizontal line.', '選択した UV を水平線に揃えます。'),
    'smart_uv_suite.view_create_checker_material': Handler(lambda context, op: 'FINISHED' in bpy.ops.object.suv_create_checker_material(), 'Create and assign the configured UV checker material.', '設定された UV チェッカーマテリアルを作成して割り当てます。'),
    'smart_uv_suite.view_stage_color': Handler(_run_uv_layout('suv_native_stage_color', namespace='object', mode='mode'), 'Create, inspect or restore Color IDs.', 'カラー ID を作成・確認・復元します。'),
    'smart_uv_suite.view_remove_checker_materials': Handler(lambda context, op: 'FINISHED' in bpy.ops.object.suv_remove_checker_materials(), 'Remove checker materials and restore the original materials.', 'チェッカーマテリアルを外し、元のマテリアルを復元します。'),
    'smart_uv_suite.unwrap_toggle_live_unwrap': Handler(lambda context, op: 'FINISHED' in bpy.ops.suv.toggle_live_unwrap(), 'Toggle live unwrap without running an unwrap.', 'UV を展開せずにライブ展開の有効・無効を切り替えます。'),
    'smart_uv_suite.unwrap_angle_based': Handler(_unwrap_projection('ANGLE_BASED'), 'Unwrap using Blender’s Angle Based method.', 'Blender の角度ベース方式で展開します。'),
    'smart_uv_suite.unwrap_conformal': Handler(_unwrap_projection('CONFORMAL'), 'Unwrap using Blender’s Conformal method.', 'Blender のコンフォーマル方式で展開します。'),
    'smart_uv_suite.unwrap_box_project_native': Handler(_unwrap_projection('BOX_PROJECT', native_defaults=True), 'Project the selection using Blender’s default cube projection.', 'Blender の標準キューブ投影で選択範囲を投影します。'),
    'smart_uv_suite.unwrap_smart_project_native': Handler(_unwrap_projection('SMART_PROJECT', native_defaults=True), 'Project the selection using Blender’s default Smart UV Project.', 'Blender の標準スマート UV 投影で選択範囲を投影します。'),
    'smart_uv_suite.island_copy_uv_native': Handler(_native_uv_clipboard('copy'), 'Copy selected UVs to Blender’s UV clipboard.', '選択 UV を Blender の UV クリップボードにコピーします。'),
    'smart_uv_suite.island_paste_uv_native': Handler(_native_uv_clipboard('paste'), 'Paste Blender’s UV clipboard onto the selected UVs.', 'Blender の UV クリップボードから選択 UV に貼り付けます。'),
    'smart_uv_suite.workflow_reload_custom_icons': Handler(_run_uv_report('suv_reload_custom_icons'), 'Reload the Smart UV icon previews.', 'Smart UV のアイコンプレビューを再読み込みします。'),
    'smart_uv_suite.pack_atlas_cell_native': Handler(_place_atlas_cell, 'Place the selection in the specified atlas cell with padding.', '選択した UV を、余白を取って指定のアトラスセルに配置します。'),
    'smart_uv_suite.pack_centralize_islands': Handler(_center_islands, 'Move the selected islands to the center of their tile.', '選択したアイランドをタイルの中央へ移動します。'),
    'smart_uv_suite.pack_rotate_islands': Handler(_rotate_islands, 'Rotate each selected island 90° around its center.', '選択したアイランドをそれぞれの中心で 90° 回転します。'),
    'smart_uv_suite.pack_flip_u': Handler(_flip_islands('U'), 'Flip each selected island along U.', '選択したアイランドをそれぞれ U 方向に反転します。'),
    'smart_uv_suite.pack_flip_v': Handler(_flip_islands('V'), 'Flip each selected island along V.', '選択したアイランドをそれぞれ V 方向に反転します。'),
    'smart_uv_suite.align_flatten': Handler(_flatten_shape_key, 'Create a shape key from the active UV coordinates.', '作業中の UV 座標からシェイプキーを作成します。'),
    'smart_uv_suite.inspect_quality_write_report_hub': Handler(_run_uv_report('suv_quality_write_report_hub', open_after_write=False), 'Write the report hub and list the available reports.', 'レポートハブを書き出し、利用できるレポートを一覧にします。'),
    'smart_uv_suite.inspect_quality_open_report_hub': Handler(_run_uv_report('suv_quality_open_report_hub'), 'Open the report hub in the Text Editor.', 'レポートハブをテキストエディターで開きます。'),
    'smart_uv_suite.inspect_quality_write_report_registry': Handler(_run_uv_report('suv_quality_write_report_registry', open_after_write=False), 'Write the report registry and helper status.', 'レポートレジストリと補助機能の登録状態を書き出します。'),
    'smart_uv_suite.inspect_quality_open_report_registry': Handler(_run_uv_report('suv_quality_open_report_registry'), 'Open the report registry in the Text Editor.', 'レポートレジストリをテキストエディターで開きます。'),
    'smart_uv_suite.view_quality_write_controls_report': Handler(_run_uv_report('suv_quality_write_controls_report', open_after_write=False), 'Write the visual controls and section visibility report.', '表示コントロールとセクションの表示状態をレポートに書き出します。'),
    'smart_uv_suite.view_quality_open_controls_report': Handler(_run_uv_report('suv_quality_open_controls_report'), 'Open the visual controls report in the Text Editor.', '表示コントロールのレポートをテキストエディターで開きます。'),
    'smart_uv_suite.inspect_quality_open_doctor_report': Handler(_run_uv_report('suv_quality_open_doctor_report'), 'Open the Quality Doctor report in the Text Editor.', '品質ドクターレポートをテキストエディターで開きます。'),
    'smart_uv_suite.inspect_quality_write_operator_catalog': Handler(_run_uv_report('suv_quality_write_operator_catalog', open_after_write=False), 'Write the operator catalog.', 'オペレーターカタログを書き出します。'),
    'smart_uv_suite.inspect_quality_open_operator_catalog': Handler(_run_uv_report('suv_quality_open_operator_catalog'), 'Open the operator catalog in the Text Editor.', 'オペレーターカタログをテキストエディターで開きます。'),
    'smart_uv_suite.inspect_quality_write_guided_help': Handler(_run_uv_report('suv_quality_write_guided_help', open_after_write=False), 'Write the guided help report.', '操作ガイドを書き出します。'),
    'smart_uv_suite.inspect_quality_open_guided_help': Handler(_run_uv_report('suv_quality_open_guided_help'), 'Open guided help in the Text Editor.', '操作ガイドをテキストエディターで開きます。'),
    'smart_uv_suite.inspect_quality_write_language_coverage': Handler(_run_uv_report('suv_quality_write_language_coverage', open_after_write=False), 'Write the translation and tooltip coverage report.', '翻訳とツールチップの網羅率レポートを書き出します。'),
    'smart_uv_suite.inspect_quality_open_language_coverage': Handler(_run_uv_report('suv_quality_open_language_coverage'), 'Open language coverage in the Text Editor.', '翻訳とツールチップの網羅率レポートをテキストエディターで開きます。'),
    'smart_uv_suite.inspect_quality_write_task_playbook': Handler(_run_uv_report('suv_quality_write_task_playbook', open_after_write=False), 'Write the task playbook.', '作業手順書を書き出します。'),
    'smart_uv_suite.inspect_quality_open_task_playbook': Handler(_run_uv_report('suv_quality_open_task_playbook'), 'Open the task playbook in the Text Editor.', '作業手順書をテキストエディターで開きます。'),
    'smart_uv_suite.inspect_quality_write_execution_profiles': Handler(_run_uv_report('suv_quality_write_execution_profiles', open_after_write=False), 'Write the execution profiles report.', '実行プロファイルのレポートを書き出します。'),
    'smart_uv_suite.inspect_quality_open_execution_profiles': Handler(_run_uv_report('suv_quality_open_execution_profiles'), 'Open execution profiles in the Text Editor.', '実行プロファイルのレポートをテキストエディターで開きます。'),
    'smart_uv_suite.inspect_quality_scan_feature_matrix': Handler(_run_uv_report('suv_quality_scan_feature_matrix', open_after_write=False), 'Scan the registered tools and write the feature matrix.', '登録済みのツールを調べ、機能マトリクスを書き出します。'),
    'smart_uv_suite.inspect_quality_open_feature_matrix': Handler(_run_uv_report('suv_quality_open_feature_matrix'), 'Open the feature matrix in the Text Editor.', '機能マトリクスをテキストエディターで開きます。'),
    'smart_uv_suite.inspect_quality_open_audit_text': Handler(_run_uv_report('suv_quality_open_audit_text'), 'Open the quality audit in the Text Editor.', '品質監査をテキストエディターで開きます。'),
    'smart_uv_suite.inspect_quality_write_external_feature_parity': Handler(_run_uv_report('suv_quality_write_external_feature_parity', open_after_write=False), 'Write the external feature parity report.', '外部機能の対応状況レポートを書き出します。'),
    'smart_uv_suite.inspect_quality_open_external_feature_parity': Handler(_run_uv_report('suv_quality_open_external_feature_parity'), 'Open the external feature parity report in the Text Editor.', '外部機能の対応状況レポートをテキストエディターで開きます。'),
    'smart_uv_suite.inspect_clear_batch_report': Handler(_run_uv_report('suv_clear_batch_report'), 'Clear the batch report and the last batch summary.', 'バッチレポートと最後のバッチ概要を消去します。'),
    'smart_uv_suite.inspect_external_report': Handler(_run_uv_report('suv_external_compat_report'), 'Write the compatibility targets and their validation status.', '互換ターゲットと検証状態を書き出します。'),
    'smart_uv_suite.align_apply_workflow_preset': Handler(_apply_preset('suv_apply_workflow_preset'), 'Apply the chosen UV workspace workflow preset.', '選んだ UV ワークスペースのワークフロープリセットを適用します。'),
    'smart_uv_suite.inspect_apply_line_flow_preset': Handler(_apply_preset('suv_apply_line_flow_preset'), 'Load the chosen UV line and flow settings.', '選んだ UV ラインとフローの設定を読み込みます。'),
    'smart_uv_suite.texel_apply_display_preset': Handler(_apply_preset('suv_apply_display_preset'), 'Apply the chosen workspace display preset.', '選んだワークスペースの表示プリセットを適用します。'),
    'smart_uv_suite.view_apply_layout_preset': Handler(_apply_preset('suv_apply_layout_preset'), 'Set the layout padding from the chosen preset.', '選んだプリセットでレイアウトの余白を設定します。'),
    'smart_uv_suite.view_quality_apply_dashboard_preset': Handler(_apply_preset('suv_quality_apply_dashboard_preset'), 'Apply the chosen visual dashboard preset.', '選んだ視覚ダッシュボードのプリセットを適用します。'),
    'smart_uv_suite.inspect_quality_reset_section_visibility': Handler(_run_uv_report('suv_quality_reset_section_visibility'), 'Show every dashboard section again.', '非表示にしたダッシュボードセクションをすべて再表示します。'),
    'smart_uv_suite.inspect_quality_set_section_visibility': Handler(_set_section_visibility, 'Show or hide a dashboard section.', 'ダッシュボードのセクションを表示または非表示にします。'),
    'smart_uv_suite.seam_set_save': Handler(_seam_set('save'), 'Save the current seam edges in a named set.', '現在のシーム辺を名前付きセットに保存します。'),
    'smart_uv_suite.seam_set_recall': Handler(_seam_set('recall'), 'Apply a saved seam set to the active mesh.', '保存したシームセットをアクティブなメッシュに適用します。'),
    'smart_uv_suite.seam_set_update': Handler(_seam_set('update'), 'Replace the contents of a saved seam set.', '保存したシームセットの内容を更新します。'),
    'smart_uv_suite.seam_set_delete': Handler(_seam_set('delete'), 'Delete a saved seam set.', '保存したシームセットを削除します。'),
    'smart_uv_suite.seam_set_library_io': Handler(_seam_set('library_io'), 'Import or export saved seam sets as JSON.', '保存したシームセットを JSON で読み込み、書き出します。'),
    'smart_uv_suite.seam_set_transfer': Handler(_seam_set('transfer'), 'Copy a saved seam set to the other selected meshes.', '保存したシームセットを他の選択メッシュへコピーします。'),
    'smart_uv_suite.seam_copy_paste_uv_object_copy_uv': Handler(_object_uv_clipboard(False), 'Copy the active UV map in Object Mode.', 'オブジェクトモードでアクティブな UV マップをコピーします。'),
    'smart_uv_suite.seam_copy_paste_uv_object_paste_uv': Handler(_object_uv_clipboard(True), 'Paste copied UV coordinates in Object Mode.', 'コピーした UV 座標をオブジェクトモードで貼り付けます。'),
    'smart_uv_suite.view_quality_reset_visual_controls': Handler(_run_uv_report('suv_quality_reset_visual_controls'), 'Reset visual dashboard controls to their defaults.', '視覚ダッシュボードの表示設定を初期値に戻します。'),
    'smart_uv_suite.view_quality_clear_status_cache': Handler(_run_uv_report('suv_quality_clear_status_cache'), 'Clear the cached visual dashboard status.', '視覚ダッシュボードの状態キャッシュを消去します。'),
    'smart_uv_suite.view_quality_write_ui_map': Handler(_run_uv_report('suv_quality_write_ui_map', open_after_write=False), 'Write the visual UI map to a Text datablock.', '視覚 UI マップをテキストデータに書き出します。'),
    'smart_uv_suite.view_quality_open_ui_map': Handler(_run_uv_report('suv_quality_open_ui_map'), 'Open the visual UI map in the Text Editor.', '視覚 UI マップをテキストエディターで開きます。'),
    'smart_uv_suite.workflow_clear_tool_runtime_log': Handler(_run_uv_report('suv_clear_tool_runtime_log'), 'Clear the runtime log and the last error.', '実行ログと最後のエラーを消去します。'),
    'smart_uv_suite.workflow_write_support_bundle': Handler(_run_uv_report('suv_write_support_bundle'), 'Write the latest diagnostics and log summaries to a support bundle.', '最新の診断結果とログの要約をサポートバンドルに書き出します。'),
    'smart_uv_suite.workflow_collect_support_bundle': Handler(_run_uv_report('suv_collect_support_bundle'), 'Collect fresh diagnostics and open the support bundle.', '最新の診断情報を収集し、サポートバンドルを開きます。'),
    'smart_uv_suite.view_upgrade_write_validation_report': Handler(_write_validation_report, 'Write the workspace validation report.', 'ワークスペースの検証レポートを書き出します。'),
    'smart_uv_suite.inspect_upgrade_write_admission_gate_report': Handler(_upgrade_report('admission_gate_report'), 'Write the admission gate report.', '対応するレポートをテキストに書き出します。'),
    'smart_uv_suite.inspect_upgrade_write_advisor_report': Handler(_upgrade_report('advisor_report'), 'Write the advisor report.', '対応するレポートをテキストに書き出します。'),
    'smart_uv_suite.inspect_upgrade_write_benchmark_catalog': Handler(_upgrade_report('benchmark_catalog'), 'Write the benchmark catalog.', '対応するレポートをテキストに書き出します。'),
    'smart_uv_suite.inspect_upgrade_write_circuit_breaker_report': Handler(_upgrade_report('circuit_breaker_report'), 'Write the circuit breaker report.', '対応するレポートをテキストに書き出します。'),
    'smart_uv_suite.inspect_upgrade_write_confidence_report': Handler(_upgrade_report('confidence_report'), 'Write the confidence report.', '対応するレポートをテキストに書き出します。'),
    'smart_uv_suite.inspect_upgrade_write_delta_report': Handler(_upgrade_report('delta_report'), 'Write the delta report.', '対応するレポートをテキストに書き出します。'),
    'smart_uv_suite.inspect_upgrade_write_execution_plan': Handler(_upgrade_report('execution_plan'), 'Write the execution plan.', '対応するレポートをテキストに書き出します。'),
    'smart_uv_suite.inspect_upgrade_write_glossary_report': Handler(_upgrade_report('glossary_report'), 'Write the glossary report.', '対応するレポートをテキストに書き出します。'),
    'smart_uv_suite.inspect_upgrade_write_integrity_guard_report': Handler(_upgrade_report('integrity_guard_report'), 'Write the integrity guard report.', '対応するレポートをテキストに書き出します。'),
    'smart_uv_suite.inspect_upgrade_write_postflight_report': Handler(_upgrade_report('postflight_report'), 'Write the postflight report.', '対応するレポートをテキストに書き出します。'),
    'smart_uv_suite.inspect_upgrade_write_reference_inventory': Handler(_upgrade_report('reference_inventory'), 'Write the reference inventory.', '対応するレポートをテキストに書き出します。'),
    'smart_uv_suite.inspect_upgrade_write_repair_playbook_report': Handler(_upgrade_report('repair_playbook_report'), 'Write the repair playbook report.', '対応するレポートをテキストに書き出します。'),
    'smart_uv_suite.inspect_upgrade_write_stability_report': Handler(_upgrade_report('stability_report'), 'Write the stability report.', '対応するレポートをテキストに書き出します。'),
    'smart_uv_suite.pack_upgrade_write_bridge_ledger': Handler(_upgrade_report('bridge_ledger'), 'Write the bridge ledger.', '対応するレポートをテキストに書き出します。'),
    'smart_uv_suite.pack_upgrade_write_failure_notebook': Handler(_upgrade_report('failure_notebook'), 'Write the failure notebook.', '対応するレポートをテキストに書き出します。'),
    'smart_uv_suite.view_upgrade_write_operator_handbook': Handler(_run_uv_report('suv_quality_write_operator_catalog', open_after_write=False), 'Write the operator handbook with grouped commands and descriptions.', '機能別のオペレーター一覧と説明を書き出します。'),
    'smart_uv_suite.seam_mirror_uv': Handler(_mirror_uv, 'Copy the UVs of the selected faces to the faces on the opposite 3D side, mirrored in U.', '選んだ面の UV を、3D で反対側の面へ左右反転して写します。'),
    'smart_uv_suite.seam_symmetry_snap': Handler(_symmetry_snap, 'Make the selected UVs symmetric for faces that are symmetric in 3D.', '3D で左右対称な面の UV を、左右対称にそろえます。'),
    'smart_uv_suite.seam_stack_pro': Handler(_smart_stack, 'Find islands that have the same shape, turn them to the same direction and stack them.', '同じ形のアイランドを探し、向きをそろえて 1 か所に重ねます。'),
    'smart_uv_suite.weld': Handler(_weld, 'Move the selected UVs to one point.', '選んだ UV を 1 点にまとめます。'),
    'smart_uv_suite.seam_merge': Handler(_merge_vertices, 'Merge selected UV vertices that are within the Distance value.', '「距離」の中にある選んだ UV の頂点をまとめます。'),
    'smart_uv_suite.unwrap_constraint': Handler(_constraint_unwrap, 'Unwrap the selected UVs again while pinned UVs stay in place.', 'ピンの UV を動かさずに、選んだ UV を展開し直します。'),
    'smart_uv_suite.inspect_set_save': Handler(_save_set, 'Save the selected faces under a name.', '選んでいる面を名前を付けて保存します。', _name_dialog_invoke, _name_dialog_draw),
    'smart_uv_suite.inspect_set_recall': Handler(_recall_set, 'Pick a saved set and select its faces again.', '保存したセットを選び、その面を選び直します。', _set_menu_invoke),
    'smart_uv_suite.inspect_set_update': Handler(_save_set, 'Pick a saved set and replace it with the selected faces.', '保存したセットを選び、今選んでいる面で置き換えます。', _set_menu_invoke),
    'smart_uv_suite.inspect_set_delete': Handler(_run_uv_layout('suv_set_delete', set_name='name'), 'Delete a saved selection set.', '保存した選択セットを削除します。', _set_menu_invoke),
    'smart_uv_suite.inspect_set_library_io': Handler(_run_uv_layout('suv_set_library_io', mode='mode', scope='scope', text_name='name', filepath='filepath'), 'Import or export saved selection sets.', '保存した選択セットを読み込み、書き出します。'),
    'smart_uv_suite.texel_uvmap_set_active': Handler(_set_work_uv, 'Make the UV map named in New UV Name the working map on the selected objects.', '「新規UV名」の名前の UV マップを、選んでいるオブジェクトの作業用にします。'),
    'smart_uv_suite.texel_density_coverage': Handler(_coverage, 'Show how much of the tile the UVs cover.', 'UV が枠をどれだけ使っているかを出します。UV は変えません。'),
    'smart_uv_suite.texel_calc_uv_area': Handler(_uv_area, 'Show the UV area and 3D area of the selection.', '選んでいるアイランドの UV の面積と 3D の面積を出します。UV は変えません。'),
    'smart_uv_suite.texel_density_from_texture': Handler(_density_from_texture, 'Measure the density using the size of the current image and put it in Target Density.', '今の画像の大きさで密度を測り、「目標密度」に入れます。'),
    'smart_uv_suite.texel_bake_uv_prep': Handler(_bake_uv_prep, 'Make a UV map for baking on the selected objects and pack the islands into the tile.', '選んでいるオブジェクトにベイク用の UV マップを作り、アイランドを枠の中に並べます。'),
    'smart_uv_suite.texel_stage_bake': Handler(_bake_image_create, 'Create the bake image with Texture Size and set it as the bake target.', '「テクスチャサイズ」の大きさのベイク画像を作り、焼き先に設定します。'),
    'smart_uv_suite.atlas_bake_multi': Handler(_atlas_bake, 'Bake the material colors of the selected objects into the bake image using the working UV map. After Build Material it bakes from the original materials again.', '選んでいるオブジェクトのマテリアルの色を、作業用の UV マップでベイク画像に焼き付けます。「マテリアル作成」の後は、元のマテリアルの色から焼き直します。'),
    'smart_uv_suite.atlas_build_mat_apply_multi': Handler(_build_material, 'Create a material from the baked image and assign it to the selected objects.', '焼いた画像のマテリアルを作り、選んでいるオブジェクトに当てます。'),
    'smart_uv_suite.atlas_build_uv_multi': Handler(_run_uv_layout('suv_atlas_build_uv_multi', margin_px='margin_px', texture_size='texture_size'), 'Build a separate shared atlas UV map for the selected meshes.', '選択メッシュに共通のアトラス用 UV マップを別に作成します。'),
    'smart_uv_suite.texel_bake_trim_id_map': Handler(_bake_id_map, 'Paint an image with a different color for each material or island.', 'マテリアルごと（1 つならアイランドごと）に色を塗り分けた画像を作ります。'),
    'smart_uv_suite.view_stage_preview': Handler(_preview_texture, 'Switch the 3D Viewport between material display and solid display.', '3D ビューをマテリアルの表示とソリッドの表示で切り替えます。'),
    'smart_uv_suite.workflow_workspace_reset': Handler(_workspace_reset, 'Return all Smart UV settings to their defaults.', 'Smart UV の設定を全部、初めの値に戻します。', _confirm_invoke),
    'smart_uv_suite.workflow_toggle_properties_pseudo_tab': Handler(_refresh_sidebar, 'Redraw the Smart UV sidebar in the 3D View.', '3D ビューの Smart UV サイドバーを再描画します。'),
    'smart_uv_suite.workflow_sync_uv_toggle': Handler(_toggle_uv_sync, 'Toggle Blender UV Sync Selection.', 'Blender の UV 同期選択を切り替えます。'),
    'smart_uv_suite.workflow_workspace_settings_io': Handler(_workspace_settings_io, 'Import or export workspace settings as JSON.', 'ワークスペース設定を JSON で読み込み、書き出します。'),
    'smart_uv_suite.workflow_open_diagnostics_text': Handler(_open_diagnostics, 'Write the scene and UV map information to a text.', 'シーンと UV マップの情報をテキストに書きます。'),
    'smart_uv_suite.settings_save': Handler(_settings_export, 'Save the Smart UV settings to a file.', 'Smart UV の設定をファイルに書き出します。', _file_invoke_for('smart_uv_export.json')),
    'smart_uv_suite.settings_load': Handler(_settings_import, 'Load the Smart UV settings from a file.', 'Smart UV の設定をファイルから読み込みます。', _file_invoke_for('smart_uv_export.json')),
    'smart_uv_suite.seams_save': Handler(_seam_export, 'Save the seams of the active object to a file.', '作業中のオブジェクトのシームをファイルに書き出します。', _file_invoke_for('smart_uv_seams.json')),
    'smart_uv_suite.seams_load': Handler(_seam_import, 'Load seams from a file onto the active object.', 'ファイルのシームを作業中のオブジェクトに読み込みます。', _file_invoke_for('smart_uv_seams.json')),
    'smart_uv_suite.layout_save': Handler(_layout_export, 'Save the UV layout of the active object to a file.', '作業中のオブジェクトの UV の配置をファイルに書き出します。', _file_invoke_for('smart_uv_layout.json')),
    'smart_uv_suite.layout_load': Handler(_layout_import, 'Load a UV layout from a file onto the active object.', 'ファイルの UV の配置を作業中のオブジェクトに読み込みます。', _file_invoke_for('smart_uv_layout.json')),
    'smart_uv_suite.selection_save': Handler(_selection_export, 'Save the selected faces to a file.', '選んでいる面をファイルに書き出します。', _file_invoke_for('smart_uv_selection.json')),
    'smart_uv_suite.selection_load': Handler(_selection_import, 'Load a saved face selection from a file.', 'ファイルの面の選択を読み込みます。', _file_invoke_for('smart_uv_selection.json')),
    'smart_uv_suite.diagnostics_save': Handler(_write_diagnostics, 'Save the scene and UV map information to a file.', 'シーンと UV マップの情報をファイルに保存します。', _file_invoke_for('smart_uv_diagnostics.txt')),
}

for _family in (
    uv_repair_align_pie,
    uv_repair_align_seam,
    uv_repair_snap_targets,
    uv_repair_align_stretch,
    uv_repair_division,
    uv_repair_inspect_circle,
    uv_repair_inspect_clip,
    uv_repair_inspect_face,
    uv_repair_inspect_hide,
    uv_repair_inspect_inspection,
    uv_repair_inspect_lattice,
    uv_repair_inspect_offset,
    uv_repair_inspect_quality,
    uv_repair_inspect_show,
    uv_repair_inspect_similarity,
    uv_repair_inspect_stack,
    uv_repair_inspect_stage,
    uv_repair_inspect_straight,
    uv_repair_inspect_sync,
    uv_repair_inspect_wand,
    uv_repair_island_distribute,
    uv_repair_island_stretch,
    uv_repair_texel_world,
    uv_repair_unwrap_normal,
    uv_repair_unwrap_project,
    uv_repair_unwrap_projection,
    uv_repair_unwrap_view,
    uv_repair_uv_list_crud,
    uv_repair_view_cockpit,
    uv_repair_view_fit,
    uv_repair_weld_seam,
    uv_repair_workflow_add,
    uv_repair_workflow_modifiers,
    uv_repair_workflow_move,
    uv_repair_workflow_preferences,
    uv_repair_workflow_remove,
    uv_repair_workflow_scale,
    uv_repair_workflow_set,
    uv_repair_workflow_toggle,
    uv_repair_workflow_uvw,
    uv_repair_align,
    uv_repair_gridify,
    uv_repair_pack_horizontal,
    uv_repair_pack_load,
    uv_repair_pack_match,
    uv_repair_pack_random,
    uv_repair_pack_randomize,
    uv_repair_pack_shuffle,
    uv_repair_pack_stage,
    uv_repair_pack_unstack,
    uv_repair_projection_gizmo,
    uv_repair_seam_angle,
    uv_repair_seam_batch,
    uv_repair_seam_border,
    uv_repair_seam_cut,
    uv_repair_seam_edit,
    uv_repair_seam_gap,
    uv_repair_seam_join,
    uv_repair_seam_mark,
    uv_repair_seam_match,
    uv_repair_seam_paste,
    uv_repair_seam_symmetrize,
    uv_repair_select_border,
    uv_repair_stitch_stitch,
    uv_repair_texel_flatten,
    uv_repair_texel_layers,
    uv_repair_texel_priority,
    uv_repair_texel_reset,
    uv_repair_workflow_world,
):
    _family_handlers = _family.build_handlers(sys.modules[__name__])
    _duplicates = HANDLERS.keys() & _family_handlers.keys()
    if _duplicates:
        raise ValueError(f'Duplicate UV operator handlers: {sorted(_duplicates)}')
    HANDLERS.update(_family_handlers)


def run_handler(handler: Handler, context, op) -> set:
    try:
        ok = handler.run(context, op)
    except Exception:
        _warn(context, op, 'This command could not run on the current selection.', '今の選択ではこの操作を実行できませんでした。')
        return {'CANCELLED'}
    return {'FINISHED'} if ok else {'CANCELLED'}
