"""Public pack_unstack_groups routing."""

import bpy


def run(context, op):
    return "FINISHED" in bpy.ops.uv.suv_unstack_groups(scope=(op.scope or "SELECTED").upper(), **({"layout_mode": op.mode.upper()} if op.mode else {}))


def build_handlers(api):
    return {"smart_uv_suite.pack_unstack_groups": api.Handler(run, 'Separate stacked groups while keeping the anchor island in place.', '基準島の位置を保ちながら重なったグループを分離します。')}
