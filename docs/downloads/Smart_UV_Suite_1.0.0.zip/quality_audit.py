from __future__ import annotations
from . import resource_api_18168 as _suv_resource
from .quality_class_inventory import iter_suite_classes

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None

_NAMESPACE = {}
_REGISTERED = []


def _tr(context, key: str, fallback_en: str, fallback_ja: str, **fmt):
    fn = _NAMESPACE.get('tr')
    text = None
    if callable(fn):
        try:
            text = fn(context, key, **fmt)
        except Exception:
            text = None
    if not text:
        text = fallback_en
    try:
        return text.format(**fmt)
    except Exception:
        return text


def _text_name(context) -> str:
    ws_fn = _NAMESPACE.get('_suv_ws')
    ws = ws_fn(context) if callable(ws_fn) else None
    name = getattr(ws, 'support_bundle_name', '') if ws else ''
    return (str(name).strip() or 'SUV_Support_Bundle') + '_Quality_Audit'


def _text_block(name: str, clear=False):
    textio = _NAMESPACE.get('_quality_textio_module')
    if textio is not None and hasattr(textio, 'ensure_report_text'):
        try:
            return textio.ensure_report_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if textio is not None and hasattr(textio, 'ensure_namespace_text'):
        try:
            return textio.ensure_namespace_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if bpy is None:
        return None
    txt = bpy.data.texts.get(name)
    if txt is None:
        if not clear:
            return None
        txt = bpy.data.texts.new(name)
    elif clear:
        txt.clear()
    return txt


def _text_tail(name: str, max_lines=400):
    if bpy is None:
        return ''
    txt = bpy.data.texts.get(name)
    if txt is None:
        return ''
    try:
        data = txt.as_string()
    except Exception:
        return ''
    if not data:
        return ''
    lines = data.splitlines()
    if max_lines and len(lines) > max_lines:
        lines = lines[-max_lines:]
    return "\n".join(lines)


def _tool_runtime_stats(context):
    name_fn = _NAMESPACE.get('_suv_tool_runtime_log_name')
    name = name_fn(context) if callable(name_fn) else 'SUV_Runtime_Log'
    tail = _text_tail(name)
    lines = tail.splitlines() if tail else []
    error_entries = sum(1 for line in lines if ' ERROR | ' in line)
    warn_entries = sum(1 for line in lines if ' WARN | ' in line)
    snapshot_count = sum(1 for line in lines if 'ErrorSnapshot' in line or 'Workspace snapshot written' in line)
    return {
        'name': name,
        'line_count': len(lines),
        'error_entries': int(error_entries),
        'warn_entries': int(warn_entries),
        'snapshot_mentions': int(snapshot_count),
    }


def _count_classes(prefixes):
    total = 0
    for name, value in iter_suite_classes(_NAMESPACE):
        if not any(name.startswith(prefix) for prefix in prefixes):
            continue
        try:
            if isinstance(value, type):
                total += 1
        except Exception:
            pass
    return total


def _bool_label(context, value: bool) -> str:
    return _tr(
        context,
        'ui.bool.on' if value else 'ui.bool.off',
        'On' if value else 'Off',
        'オン' if value else 'オフ',
    )


def scan_quality_audit(context):
    cached = dict(_NAMESPACE.get('_suv_quality_audit_last') or {})
    if bool(_NAMESPACE.get('_suv_quality_audit_scan_active', False)):
        return cached
    _NAMESPACE['_suv_quality_audit_scan_active'] = True
    try:
            tool_runtime = _tool_runtime_stats(context)
            lifecycle = _NAMESPACE.get('_suv_quality_lifecycle_state', {}) or {}
            unreg = _NAMESPACE.get('_suv_quality_lifecycle_unreg_state', {}) or {}
            readiness_scan = _NAMESPACE.get('scan_context_readiness')
            readiness = readiness_scan(_NAMESPACE, context) if callable(readiness_scan) else {}
            housekeeping_scan = _NAMESPACE.get('scan_housekeeping')
            housekeeping = housekeeping_scan(context) if callable(housekeeping_scan) else {}
            feature_scan = _NAMESPACE.get('scan_feature_matrix')
            feature_matrix = feature_scan(_NAMESPACE, context) if callable(feature_scan) else {}
            language_scan = _NAMESPACE.get('scan_language_coverage')
            language = language_scan(_NAMESPACE) if callable(language_scan) else {}
            report_scan = _NAMESPACE.get('scan_report_hub')
            report_hub = report_scan(context) if callable(report_scan) else {}
            registry_scan = _NAMESPACE.get('scan_report_registry')
            registry = registry_scan(context) if callable(registry_scan) else {}
            controls_report_name_fn = _NAMESPACE.get('_suv_controls_report_name')
            controls_report_name = controls_report_name_fn(context) if callable(controls_report_name_fn) else ''
            ui_map_scan = _NAMESPACE.get('scan_ui_map')
            ui_map = ui_map_scan(_NAMESPACE, context) if callable(ui_map_scan) else {}
            doctor_scan = _NAMESPACE.get('scan_quality_doctor')
            doctor = {}
            if callable(doctor_scan):
                if bool(_NAMESPACE.get('_suv_quality_doctor_scan_active', False)):
                    doctor = dict(_NAMESPACE.get('_suv_quality_doctor_last') or {})
                else:
                    try:
                        doctor = doctor_scan(_NAMESPACE, context) or {}
                    except Exception:
                        doctor = {}
            playbook_scan = _NAMESPACE.get('scan_task_playbook')
            playbook = playbook_scan(_NAMESPACE, context) if callable(playbook_scan) else {}
            profile_scan = _NAMESPACE.get('scan_operator_profiles')
            profiles = profile_scan(_NAMESPACE, context) if callable(profile_scan) else {}
            controls_scan = _NAMESPACE.get('scan_visual_controls')
            controls = controls_scan(_NAMESPACE, context) if callable(controls_scan) else {}
            counts = {
                'operators': _count_classes(('SUV_OT_',)),
                'panels': _count_classes(('SUV_PT_',)),
                'menus': _count_classes(('SUV_MT_',)),
                'guarded': int(_NAMESPACE.get('_suv_quality_safety_patch_count', 0) or 0),
                'prepared': int(_NAMESPACE.get('_suv_quality_preflight_patch_count', 0) or 0),
                'restored': int(_NAMESPACE.get('_suv_quality_restore_patch_count', 0) or 0),
                'descriptions': int(_NAMESPACE.get('_suv_quality_desc_patch_count', 0) or 0),
                'translations_registered': bool(_NAMESPACE.get('_SUV_TRANSLATIONS_REGISTERED', False) or _NAMESPACE.get('_suv_quality_translation_registered', False) or False),
                'translated_labels': int((language or {}).get('translated_labels', 0) or 0),
                'untranslated_labels': int((language or {}).get('untranslated_labels', 0) or 0),
                'bilingual_descriptions': int((language or {}).get('bilingual_descriptions', 0) or 0),
                'weak_descriptions': int((language or {}).get('weak_descriptions', 0) or 0),
                'tooltip_rich': int((language or {}).get('tooltip_rich', 0) or 0),
                'notice_cache': int(_NAMESPACE.get('_suv_quality_notice_cache_total', 0) or 0),
                'state_cache_hits': int(_NAMESPACE.get('_suv_quality_state_cache_hits', 0) or 0),
                'state_cache_misses': int(_NAMESPACE.get('_suv_quality_state_cache_misses', 0) or 0),
                'report_texts_total': int((report_hub or {}).get('total', 0) or 0),
                'report_texts_existing': int((report_hub or {}).get('existing', 0) or 0),
                'report_texts_missing': int((report_hub or {}).get('missing', 0) or 0),
                'tool_runtime_lines': int(tool_runtime.get('line_count', 0) or 0),
                'tool_runtime_errors': int(tool_runtime.get('error_entries', 0) or 0),
                'tool_runtime_warns': int(tool_runtime.get('warn_entries', 0) or 0),
                'cleanup_candidates': int((housekeeping or {}).get('total', 0) or 0),
                'feature_groups_total': int((feature_matrix or {}).get('total', 0) or 0),
                'feature_groups_supported': int((feature_matrix or {}).get('supported', 0) or 0),
                'feature_groups_partial': int((feature_matrix or {}).get('partial', 0) or 0),
                'feature_groups_missing': int((feature_matrix or {}).get('missing', 0) or 0),
                'readiness_score': int((readiness or {}).get('score', 0) or 0),
                'readiness_missing': int((readiness or {}).get('missing', 0) or 0),
                'workflow_groups_total': int((playbook or {}).get('total', 0) or 0),
                'workflow_groups_ready': int((playbook or {}).get('ready', 0) or 0),
                'workflow_groups_partial': int((playbook or {}).get('partial', 0) or 0),
                'workflow_groups_missing': int((playbook or {}).get('missing', 0) or 0),
                'profiled_operators': int((profiles or {}).get('profiled', 0) or 0),
                'profile_blocked_now': int((profiles or {}).get('blocked_now', 0) or 0),
                'profile_groups_total': int(len((profiles or {}).get('categories', {}) or {})),
                'registry_texts_total': int((registry or {}).get('total_texts', 0) or 0),
                'registry_texts_existing': int((registry or {}).get('existing_texts', 0) or 0),
                'registry_helpers_registered': int((registry or {}).get('helper_registered', 0) or 0),
                'doctor_actions': int((doctor or {}).get('total_actions', 0) or 0),
                'dashboard_preset_manual': bool((controls or {}).get('preset_manual', False)),
                'dashboard_preset_effective': str((controls or {}).get('preset_effective', 'AUTO') or 'AUTO'),
                'dashboard_preset_matched': bool((controls or {}).get('preset_matched', True)),
                'manual_controls': int((controls or {}).get('manual_controls', 0) or 0),
                'controls_custom': bool((controls or {}).get('custom_active', False)),
                'visible_card_sections': int((_NAMESPACE.get('_suv_visual_card_scan_last', {}) or {}).get('visible_sections', 0) or 0),
                'hidden_card_sections': int((_NAMESPACE.get('_suv_visual_card_scan_last', {}) or {}).get('hidden_sections', 0) or 0),
                'visible_cards': int((_NAMESPACE.get('_suv_visual_card_scan_last', {}) or {}).get('visible_cards', 0) or 0),
                'hidden_cards': int((_NAMESPACE.get('_suv_visual_card_scan_last', {}) or {}).get('hidden_cards', 0) or 0),
                'visible_actions': int((_NAMESPACE.get('_suv_visual_card_scan_last', {}) or {}).get('visible_actions', 0) or 0),
                'ui_map_sections': int((ui_map or {}).get('sections', 0) or 0),
                'ui_map_cards': int((ui_map or {}).get('cards', 0) or 0),
                'ui_map_actions': int((ui_map or {}).get('actions', 0) or 0),
                'doctor_high_actions': int((doctor or {}).get('high_actions', 0) or 0),
                'controls_report_existing': bool(bpy is not None and controls_report_name and bpy.data.texts.get(controls_report_name) is not None),
                'registered_quality_helpers': int(_NAMESPACE.get('_suv_quality_housekeeping_registered', 0) or 0) + int(_NAMESPACE.get('_suv_quality_context_registered', 0) or 0) + int(_NAMESPACE.get('_suv_quality_audit_registered', 0) or 0) + int(_NAMESPACE.get('_suv_quality_matrix_registered', 0) or 0) + int(_NAMESPACE.get('_suv_quality_catalog_registered', 0) or 0) + int(_NAMESPACE.get('_suv_quality_help_registered', 0) or 0) + int(_NAMESPACE.get('_suv_quality_language_registered', 0) or 0) + int(_NAMESPACE.get('_suv_quality_reports_registered', 0) or 0) + int(_NAMESPACE.get('_suv_quality_playbook_registered', 0) or 0) + int(_NAMESPACE.get('_suv_quality_profiles_registered', 0) or 0) + int(_NAMESPACE.get('_suv_quality_registry_registered', 0) or 0) + int(_NAMESPACE.get('_suv_quality_doctor_registered', 0) or 0) + int(_NAMESPACE.get('_suv_quality_ui_map_registered', 0) or 0) + int(_NAMESPACE.get('_suv_quality_state_registered', 0) or 0) + int(_NAMESPACE.get('_suv_quality_density_registered', 0) or 0) + int(_NAMESPACE.get('_suv_quality_focus_registered', 0) or 0) + int(_NAMESPACE.get('_suv_quality_sections_registered', 0) or 0) + int(_NAMESPACE.get('_suv_quality_presets_registered', 0) or 0) + int(_NAMESPACE.get('_suv_quality_controls_registered', 0) or 0)
                    + int(_NAMESPACE.get('_suv_quality_sync_registered', 0) or 0) + int(_NAMESPACE.get('_suv_quality_controls_report_registered', 0) or 0),
                'lifecycle_register_ok': all(bool(v) for v in lifecycle.values()) if isinstance(lifecycle, dict) and lifecycle else False,
                'lifecycle_unregister_ok': all(bool(v) for v in unreg.values()) if isinstance(unreg, dict) and unreg else False,
            }
            score = 0
            score += 20 if counts['guarded'] > 0 else 0
            score += 10 if counts['prepared'] > 0 else 0
            score += 10 if counts['restored'] > 0 else 0
            score += 10 if counts['descriptions'] > 0 else 0
            score += 10 if counts['translations_registered'] else 0
            if counts['operators'] > 0:
                score += min(5, int((counts['translated_labels'] / max(1, counts['operators'] + counts['panels'] + counts['menus'])) * 5))
                score += min(5, int((counts['tooltip_rich'] / max(1, counts['operators'] + counts['panels'] + counts['menus'])) * 5))
            score += 15 if counts['readiness_score'] >= 4 else max(0, counts['readiness_score']) * 3
            score += 10 if counts['tool_runtime_errors'] == 0 else max(0, 10 - min(10, counts['tool_runtime_errors']))
            score += 10 if counts['cleanup_candidates'] == 0 else max(0, 10 - min(10, counts['cleanup_candidates']))
            if counts['feature_groups_total'] > 0:
                score += min(10, counts['feature_groups_supported'])
            score += 5 if counts['notice_cache'] <= 20 else 0
            score += 5 if counts['report_texts_existing'] >= max(1, counts['report_texts_total'] - 2) else 0
            counts['audit_score'] = int(min(100, max(0, score)))
            counts['tool_runtime_name'] = tool_runtime.get('name', 'SUV_Runtime_Log')
            counts['tool_runtime_snapshot_mentions'] = int(tool_runtime.get('snapshot_mentions', 0) or 0)
            _NAMESPACE['_suv_quality_audit_last'] = dict(counts)
            return counts
    finally:
        _NAMESPACE['_suv_quality_audit_scan_active'] = False


class SUV_OT_quality_audit_suite(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_audit_suite'
    bl_label = 'Quality Audit'
    bl_description = 'Write a compact quality audit report that summarizes guards, preparation layers, translations, tool_runtime log health, readiness, and cleanup candidates. / ガード層、事前準備層、翻訳、実行ログ状態、準備状況、クリーンアップ候補をまとめた品質監査レポートを作成します。'
    bl_options = set()

    open_after_write: bpy.props.BoolProperty(
        name='Open After Write',
        description='Open the written audit text in Blender Text Editor when possible / 可能なら書き出した監査テキストを Blender テキストエディタで開きます',
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        data = scan_quality_audit(context)
        txt = None
        lines = [
            'UV Suite Quality Audit',
            f"Score: {data['audit_score']}/100",
            '',
            '[Coverage]',
            f"Operators: {data['operators']}",
            f"Panels: {data['panels']}",
            f"Menus: {data['menus']}",
            '',
            '[Guards & Guidance]',
            f"Guarded methods: {data['guarded']}",
            f"Prepared steps: {data['prepared']}",
            f"Rollback guards: {data['restored']}",
            f"Tooltip enrichments: {data['descriptions']}",
            f"Translations registered: {data['translations_registered']}",
            f"Translated labels: {data['translated_labels']}",
            f"Rich tooltips: {data['tooltip_rich']}",
            f"Weak descriptions: {data['weak_descriptions']}",
            f"Notice cache entries: {data['notice_cache']}",
            f"State cache hits/misses: {data['state_cache_hits']}/{data['state_cache_misses']}",
            f"Report texts: {data['report_texts_existing']}/{data['report_texts_total']}",
            f"Registry texts: {data['registry_texts_existing']}/{data['registry_texts_total']}",
            '',
            '[Feature Coverage]',
            f"Feature groups: {data['feature_groups_supported']}/{data['feature_groups_total']} supported",
            f"Partial groups: {data['feature_groups_partial']}",
            f"Missing groups: {data['feature_groups_missing']}",
            '',
            '[Workflow Playbooks]',
            f"Ready workflows: {data['workflow_groups_ready']}/{data['workflow_groups_total']}",
            f"Partial workflows: {data['workflow_groups_partial']}",
            f"Missing workflows: {data['workflow_groups_missing']}",
            '',
            '[Execution Profiles]',
            f"Profiled operators: {data['profiled_operators']}",
            f"Blocked in current context: {data['profile_blocked_now']}",
            f"Profile groups: {data['profile_groups_total']}",
            '',
            '[Current Context]',
            f"Readiness score: {data['readiness_score']}/5",
            f"Missing readiness checks: {data['readiness_missing']}",
            f"Cleanup candidates: {data['cleanup_candidates']}",
            f"Available reports: {data['report_texts_existing']}/{data['report_texts_total']}",
            '',
            '[Runtime]',
            f"Runtime log name: {data['tool_runtime_name']}",
            f"Runtime log lines (tail): {data['tool_runtime_lines']}",
            f"Runtime error entries: {data['tool_runtime_errors']}",
            f"Runtime warning entries: {data['tool_runtime_warns']}",
            f"Snapshot mentions: {data['tool_runtime_snapshot_mentions']}",
            '',
            '[Lifecycle]',
            f"Quality helper register state OK: {data['lifecycle_register_ok']}",
            f"Quality helper unregister state OK: {data['lifecycle_unregister_ok']}",
            f"Registered quality helpers: {data['registered_quality_helpers']}",
            f"Registry helper groups: {data['registry_helpers_registered']}",
            f"Doctor action items: {data['doctor_actions']} (high {data['doctor_high_actions']})",
            f"Visual card sections/cards/actions: {data['visible_card_sections']}/{data['visible_cards']}/{data['visible_actions']}",
            f"Manual dashboard preset: {_bool_label(context, data['dashboard_preset_manual'])}",
            f"Effective dashboard preset: {data['dashboard_preset_effective']}",
            f"Preset matches current controls: {_bool_label(context, data['dashboard_preset_matched'])}",
            f"Manual visual controls: {data['manual_controls']}",
            f"Visual controls are custom: {_bool_label(context, data['controls_custom'])}",
            f"Hidden visual sections/cards: {data['hidden_card_sections']}/{data['hidden_cards']}",
            f"Visual UI map sections/cards/actions: {data['ui_map_sections']}/{data['ui_map_cards']}/{data['ui_map_actions']}",
            f"Hidden visual cards: {data['hidden_cards']}",
            '',
            '[Hints]',
        ]
        hints = []
        if data['tool_runtime_errors'] > 0:
            hints.append('Review the tool_runtime log and fix repeated failing operator paths first.')
        if data['cleanup_candidates'] > 0:
            hints.append('Run generated-data cleanup if helper assets or stale reports are piling up.')
        if data['readiness_missing'] > 0:
            hints.append('Prepare the working context before large UV operations so fewer tools fail early.')
        if data['feature_groups_missing'] > 0:
            hints.append('Use the feature matrix to identify missing groups before claiming tool parity or broad compatibility.')
        if data['workflow_groups_missing'] > 0:
            hints.append('Write the task playbook so missing workflow groups are easier to spot from a user-facing flow view.')
        if data['profile_blocked_now'] > 0:
            hints.append('Write the execution profiles report when operators are still blocked by missing editor, selection, or mode context.')
        if data['untranslated_labels'] > 0 or data['weak_descriptions'] > 0:
            hints.append('Run the language coverage report next so untranslated labels and weak tooltip descriptions can be prioritized.')
        if data['notice_cache'] > 20:
            hints.append('Clear the quality notice cache if you need to re-check suppressed setup notifications.')
        if data['state_cache_hits'] > 200 and data['state_cache_misses'] <= 5:
            hints.append('Clear the visual status cache if dashboard values look stale after heavy context changes.')
        if data['report_texts_missing'] > 0:
            hints.append('Write the report hub so the main generated reports stay easier to find from one place.')
        if data['doctor_actions'] > 0:
            hints.append('Write the quality doctor report when you want a prioritized next-fix list instead of scanning each report separately.')
        if not hints:
            hints.append('The current quality audit looks stable. Continue with targeted operator-level fixes next.')
        for item in hints:
            lines.append(f'- {item}')
        textio = _NAMESPACE.get('_quality_textio_module')
        writer = getattr(textio, 'write_report_lines_consistent', None) if textio is not None else None
        if callable(writer):
            txt = writer(
                _NAMESPACE, context, _text_name, lines, _text_block, self,
                open_after_write=self.open_after_write,
                failed_key='msg.quality_audit_open_failed',
                failed_en='Could not open quality audit: {name}',
                failed_ja='品質監査レポートを開けませんでした: {name}',
            )
            if txt is None:
                return {'CANCELLED'}
        else:
            txt = _text_block(_text_name(context), clear=True)
            if txt is None:
                return {'CANCELLED'}
            txt.write('\n'.join(lines))
            if self.open_after_write:
                opener = _NAMESPACE.get('_suv_open_text_in_editor')
                if callable(opener):
                    try:
                        opener(context, txt)
                    except Exception:
                        pass
        msg = _tr(context, 'msg.quality_audit_written', 'Quality audit written: {name} (score {score}/100)', '品質監査レポートを書き出しました: {name}（スコア {score}/100）', name=txt.name, score=data['audit_score'])
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class SUV_OT_quality_open_audit_text(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_open_audit_text'
    bl_label = 'Open Quality Audit'
    bl_description = 'Open the latest UV Suite quality audit text block in Blender Text Editor. / 最新の UV Suite 品質監査テキストを Blender のテキストエディタで開きます。'
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        textio = _NAMESPACE.get('_quality_textio_module')
        if textio is not None and hasattr(textio, 'open_named_report_text_or_fallback'):
            return textio.open_named_report_text_or_fallback(
                _NAMESPACE, context, _text_name, self, _text_block,
                missing_key='msg.quality_audit_missing',
                missing_en='No quality audit report exists yet.',
                missing_ja='品質監査レポートはまだ作成されていません。',
                opened_key='msg.quality_audit_opened',
                opened_en='Opened quality audit: {name}',
                opened_ja='品質監査レポートを開きました: {name}',
            )
        txt = _text_block(_text_name(context), clear=False)
        if txt is None:
            self.report({'WARNING'}, _tr(context, 'msg.quality_audit_missing', 'No quality audit report exists yet.', '品質監査レポートはまだ作成されていません。'))
            return {'CANCELLED'}
        opener = _NAMESPACE.get('_suv_open_text_in_editor')
        ok = False
        if callable(opener):
            try:
                ok, _err = opener(context, txt)
            except Exception:
                ok = False
        if not ok:
            self.report({'WARNING'}, _tr(context, 'msg.quality_audit_open_failed', 'Could not open quality audit: {name}', '品質監査レポートを開けませんでした: {name}', name=txt.name))
            return {'CANCELLED'}
        msg = _tr(context, 'msg.quality_audit_opened', 'Opened quality audit: {name}', '品質監査レポートを開きました: {name}', name=txt.name)
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class SUV_OT_quality_clear_notice_cache(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_clear_notice_cache'
    bl_label = 'Clear Quality Notice Cache'
    bl_description = 'Clear the deduplicated quality notice cache so setup and recovery hints can be shown again. / 重複抑制している品質通知キャッシュを消去し、準備や復旧のヒントを再表示できるようにします。'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return context is not None

    def execute(self, context):
        from .quality_notify import clear_notice_cache
        clear_notice_cache(_NAMESPACE)
        total = int(_NAMESPACE.get('_suv_quality_notice_cache_total', 0) or 0)
        msg = _tr(context, 'msg.quality_notice_cache_cleared', 'Quality notice cache cleared. Active cached notices: {total}', '品質通知キャッシュを消去しました。現在のキャッシュ件数: {total}', total=total)
        self.report({'INFO'}, msg)
        return {'FINISHED'}


def register(namespace: dict):
    global _NAMESPACE
    _NAMESPACE = namespace if isinstance(namespace, dict) else {}
    if bpy is None:
        return []
    classes = [SUV_OT_quality_audit_suite, SUV_OT_quality_open_audit_text, SUV_OT_quality_clear_notice_cache]
    reg = []
    for cls in classes:
        try:
            _suv_resource.register_class(cls)
            reg.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = reg
    return reg


def unregister(namespace: dict | None = None):
    if bpy is None:
        return []
    removed = []
    for cls in reversed(list(_REGISTERED)):
        try:
            _suv_resource.unregister_class(cls)
            removed.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = []
    return removed
