"""Implement the inspect lattice public UV operations."""

import bpy


def inspect_lattice_compat(context, op):
    return 'FINISHED' in bpy.ops.uv.suv_uv_lattice_compat(mode=op.mode or 'SHEAR_U', amount=op.amount if op.properties.is_property_set('amount') else .15)


def build_handlers(api):
    return {

        "smart_uv_suite.inspect_lattice_compat": api.Handler(inspect_lattice_compat, 'Deform the selection using the chosen UV lattice mode.', '選択したUVを指定のラティス方式で変形します。'),

    }
