"""Align UV copies of the same mesh vertex across selected seams."""
from collections import defaultdict


def build_handlers(api):
    def align_seam(context, op) -> bool:
        if context.mode != 'EDIT_MESH':
            return False

        sync = api._sync(context)
        edge_mode = context.tool_settings.uv_select_mode == 'EDGE'
        changed_rows = []
        for row in api._edit_targets(context):
            _obj, bm, uv = row
            visible = {face for face in bm.faces if api._visible(face, sync)}
            copies = defaultdict(list)
            for face in visible:
                for loop in face.loops:
                    copies[loop.vert, tuple(loop[uv].uv)].append(loop)

            links = defaultdict(set)
            for edge in bm.edges:
                if not edge.seam or edge.hide or not edge.is_manifold:
                    continue
                left, right = edge.link_loops
                if left.face not in visible or right.face not in visible:
                    continue
                if not sync and edge_mode and not (left.uv_select_edge or right.uv_select_edge):
                    continue
                right_endpoints = {right.vert: right, right.link_loop_next.vert: right.link_loop_next}
                for first in (left, left.link_loop_next):
                    second = right_endpoints[first.vert]
                    if sync and not first.vert.select:
                        continue
                    if not sync and not edge_mode and not (first.uv_select_vert or second.uv_select_vert):
                        continue
                    a = first.vert, tuple(first[uv].uv)
                    b = second.vert, tuple(second[uv].uv)
                    if a != b:
                        links[a].add(b)
                        links[b].add(a)

            if not links:
                continue
            visited = set()
            for start in links:
                if start in visited:
                    continue
                component = [start]
                visited.add(start)
                for key in component:
                    for neighbor in links[key] - visited:
                        visited.add(neighbor)
                        component.append(neighbor)
                points = sorted(point for _, point in component)
                u = sum(point[0] for point in points) / len(points)
                v = sum(point[1] for point in points) / len(points)
                for key in component:
                    for loop in copies[key]:
                        loop[uv].uv = (u, v)
            changed_rows.append(row)

        api._flush(changed_rows)
        if not changed_rows:
            api._warn(context, op, 'Select split UVs on a marked seam.',
                      'マークしたシームで分かれたUVを選択してください。')
        return bool(changed_rows)

    return {
        'smart_uv_suite.align_seam': api.Handler(
            align_seam,
            'Align UV copies of each selected vertex across a marked seam at their midpoint.',
            'マークしたシームで分かれた選択頂点のUVを中間位置に揃えます。',
        ),
    }
