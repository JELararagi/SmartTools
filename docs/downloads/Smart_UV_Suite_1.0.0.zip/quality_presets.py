# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

from __future__ import annotations
from . import resource_api_18168 as _suv_resource

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None

_NAMESPACE = {}
_REGISTERED = []
_PROP = 'suv_quality_dashboard_preset'
_PRESETS = {
    'AUTO': {
        'label_en': 'Auto', 'label_ja': '自動',
        'focus': 'AUTO', 'density': 'AUTO',
        'sections': {'workflow': True, 'learning': True, 'maintenance': True},
        'description': 'Adaptive dashboard preset that follows the current context. / 現在の状況に合わせて自動で最適化するダッシュボードプリセットです。',
    },
    'START': {
        'label_en': 'Starter', 'label_ja': '入門',
        'focus': 'SETUP', 'density': 'ESSENTIAL',
        'sections': {'workflow': True, 'learning': True, 'maintenance': False},
        'description': 'Compact layout for first steps, preparation, and beginner-facing help. / 最初の準備と初心者向けガイドを優先するコンパクト表示です。',
    },
    'REPAIR': {
        'label_en': 'Repair', 'label_ja': '修復',
        'focus': 'REPAIR', 'density': 'ESSENTIAL',
        'sections': {'workflow': True, 'learning': False, 'maintenance': True},
        'description': 'Prioritize doctor, audit, cleanup, and recovery related cards. / ドクター、監査、整理、復旧を優先表示します。',
    },
    'ANALYZE': {
        'label_en': 'Analyze', 'label_ja': '分析',
        'focus': 'ANALYZE', 'density': 'FULL',
        'sections': {'workflow': False, 'learning': True, 'maintenance': True},
        'description': 'Focus on reports, language coverage, UI maps, and maintenance. / レポート、言語対応、UIマップ、保守を中心に表示します。',
    },
    'FULL': {
        'label_en': 'Full', 'label_ja': '全体',
        'focus': 'ALL', 'density': 'FULL',
        'sections': {'workflow': True, 'learning': True, 'maintenance': True},
        'description': 'Show every section with the full dashboard status set. / 全セクションと全状態表示を使う完全表示です。',
    },
}
_ITEMS = tuple((key, cfg['label_en'], cfg['description']) for key, cfg in _PRESETS.items())


def _tr(context, key: str, en: str, ja: str, **fmt) -> str:
    fn = _NAMESPACE.get('tr')
    text = None
    if callable(fn):
        try:
            text = fn(context, key, **fmt)
        except Exception:
            text = None
    if not text:
        text = en
    try:
        return text.format(**fmt)
    except Exception:
        return text


def _wm(context):
    try:
        return getattr(context, 'window_manager', None)
    except Exception:
        return None


def _norm(value: str) -> str:
    value = str(value or 'AUTO').strip().upper()
    if value == 'STARTER':
        value = 'START'
    return value if value in _PRESETS else 'AUTO'


def get_preset_override(context) -> str:
    wm = _wm(context)
    if wm is None:
        return 'AUTO'
    try:
        return _norm(getattr(wm, _PROP, 'AUTO'))
    except Exception:
        return 'AUTO'


def set_preset_override(context, preset: str) -> str:
    wm = _wm(context)
    preset = _norm(preset)
    if wm is not None:
        try:
            setattr(wm, _PROP, preset)
        except Exception:
            pass
    return preset


def _preset_label(context, preset: str) -> str:
    cfg = _PRESETS.get(_norm(preset), _PRESETS['AUTO'])
    return _tr(context, f"ui.visual.preset.{_norm(preset).lower()}", cfg['label_en'], cfg['label_ja'])


def apply_dashboard_preset(namespace: dict, context, preset: str) -> str:
    preset = _norm(preset)
    cfg = _PRESETS.get(preset, _PRESETS['AUTO'])
    focus_mod = namespace.get('_quality_focus_module')
    if focus_mod is not None and hasattr(focus_mod, 'set_focus_override'):
        try:
            focus_mod.set_focus_override(context, cfg['focus'])
        except Exception:
            pass
    density_mod = namespace.get('_quality_density_module')
    if density_mod is not None and hasattr(density_mod, 'set_density_override'):
        try:
            density_mod.set_density_override(context, cfg['density'])
        except Exception:
            pass
    sections_mod = namespace.get('_quality_sections_module')
    if sections_mod is not None and hasattr(sections_mod, 'set_section_visibility'):
        for sid, shown in dict(cfg.get('sections', {}) or {}).items():
            try:
                sections_mod.set_section_visibility(context, sid, bool(shown))
            except Exception:
                pass
    set_preset_override(context, preset)
    controls_mod = namespace.get('_quality_controls_module')
    if controls_mod is not None and hasattr(controls_mod, 'notify_controls_changed'):
        try:
            controls_mod.notify_controls_changed(namespace, context, reason='preset')
        except Exception:
            pass
    else:
        clear = namespace.get('clear_quality_state_cache')
        if callable(clear):
            try:
                clear(namespace)
            except Exception:
                pass
    namespace['_suv_dashboard_preset_last'] = scan_dashboard_preset(namespace, context)
    return preset


def scan_dashboard_preset(namespace: dict, context) -> dict:
    sync_mod = namespace.get('_quality_sync_module')
    if sync_mod is not None and hasattr(sync_mod, 'effective_preset'):
        try:
            data = sync_mod.effective_preset(namespace, context) or {}
            namespace['_suv_dashboard_preset_last'] = dict(data)
            return data
        except Exception:
            pass
    preset = get_preset_override(context)
    cfg = _PRESETS.get(preset, _PRESETS['AUTO'])
    data = {
        'override': preset,
        'effective': preset,
        'manual': preset != 'AUTO',
        'matched': True,
        'label': _preset_label(context, preset),
        'focus': str(cfg.get('focus', 'AUTO') or 'AUTO'),
        'density': str(cfg.get('density', 'AUTO') or 'AUTO'),
        'visible_sections': int(sum(1 for v in (cfg.get('sections', {}) or {}).values() if v)),
        'sections': dict(cfg.get('sections', {}) or {}),
        'available_presets': len(_PRESETS) + 1,
    }
    namespace['_suv_dashboard_preset_last'] = dict(data)
    return data


class SUV_OT_quality_apply_dashboard_preset(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_apply_dashboard_preset'
    bl_label = 'Apply Dashboard Preset'
    bl_description = 'Apply a compact dashboard preset that adjusts focus, density, and visible sections together. / フォーカス、表示密度、表示セクションをまとめて切り替えるダッシュボードプリセットを適用します。'
    bl_options = set()

    preset: bpy.props.EnumProperty(
        name='Dashboard Preset',
        description='Choose a dashboard preset / ダッシュボードプリセットを選びます',
        items=_ITEMS,
        default='AUTO',
    )

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        preset = apply_dashboard_preset(_NAMESPACE, context, self.preset)
        self.report({'INFO'}, _tr(context, 'msg.quality_preset_applied', 'Dashboard preset applied: {preset}.', 'ダッシュボードプリセットを適用しました: {preset}。', preset=_preset_label(context, preset)))
        return {'FINISHED'}


def register(namespace: dict):
    global _NAMESPACE
    _NAMESPACE = namespace if isinstance(namespace, dict) else {}
    if bpy is None:
        return []
    classes = [SUV_OT_quality_apply_dashboard_preset]
    reg = []
    for cls in classes:
        try:
            _suv_resource.register_class(cls)
            reg.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = reg
    try:
        if not hasattr(bpy.types.WindowManager, _PROP):
            _suv_resource.register_property(
                bpy.types.WindowManager,
                _PROP,
                bpy.props.EnumProperty(
                    name='Dashboard Preset',
                    description='Quick dashboard preset override / クイックダッシュボードプリセットの上書きです',
                    items=_ITEMS,
                    default='AUTO',
                )
            )
    except Exception:
        pass
    return reg


def unregister(namespace: dict | None = None):
    if bpy is None:
        return []
    removed = []
    for cls in reversed(list(_REGISTERED)):
        try:
            _suv_resource.unregister_class(cls)
            removed.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = []
    try:
        _suv_resource.unregister_property(bpy.types.WindowManager, _PROP)
    except Exception:
        pass
    return removed
