# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Final checker and line/even-straighten fixes for Smart UV Suite.

This layer is intentionally loaded last.  It avoids altering the existing UI
section hierarchy except for replacing the checker controls and it patches only
operator behavior that must be deterministic at runtime.
"""
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

from array import array
import json
import math
from typing import Iterable

import bpy

_REGISTERED: list[type] = []
_OLD_OPERATOR_CLASSES: list[type] = []


def _ws(context=None):
    try:
        return getattr(getattr((context or bpy.context), 'scene', None), 'suv_workspace', None)
    except Exception:
        return None


def _tr(context, en: str, ja: str) -> str:
    try:
        prefs = getattr(bpy.app, 'translations', None)
        locale = str(getattr(prefs, 'locale', '') or '')
        if locale.startswith('ja'):
            return ja
    except Exception:
        pass
    return ja if True else en


def _selected_mesh_objects(context=None):
    ctx = context or bpy.context
    objs = []
    try:
        objs.extend([o for o in getattr(ctx, 'objects_in_mode_unique_data', []) or [] if getattr(o, 'type', None) == 'MESH'])
    except Exception:
        pass
    try:
        for obj in getattr(ctx, 'selected_objects', []) or []:
            if getattr(obj, 'type', None) == 'MESH' and obj not in objs:
                objs.append(obj)
    except Exception:
        pass
    try:
        obj = getattr(ctx, 'active_object', None)
        if getattr(obj, 'type', None) == 'MESH' and obj not in objs:
            objs.append(obj)
    except Exception:
        pass
    return objs


def _checker_settings(context=None):
    ws = _ws(context)

    # Compatibility: older builds had one image-resolution value and one tile-count value.
    # New UI exposes width/height and tile U/V independently, but falls back to the old
    # values when loading files saved by previous versions.
    old_size = int(getattr(ws, 'checker_size', 1024) if ws is not None else 1024)
    old_tiles = int(getattr(ws, 'checker_tile_count', 8) if ws is not None else 8)

    width = int(getattr(ws, 'checker_size_width', getattr(ws, 'checker_width', old_size)) if ws is not None else old_size)
    height = int(getattr(ws, 'checker_size_height', getattr(ws, 'checker_height', old_size)) if ws is not None else old_size)
    width = max(16, min(8192, width))
    height = max(16, min(8192, height))

    tiles_x = int(getattr(ws, 'checker_tile_count_u', getattr(ws, 'checker_tiles_x', old_tiles)) if ws is not None else old_tiles)
    tiles_y = int(getattr(ws, 'checker_tile_count_v', getattr(ws, 'checker_tiles_y', old_tiles)) if ws is not None else old_tiles)
    tiles_x = max(1, min(4096, tiles_x))
    tiles_y = max(1, min(4096, tiles_y))

    name = str(getattr(ws, 'checker_image_name', '') or 'SUV_Checker') if ws is not None else 'SUV_Checker'
    mat_name = str(getattr(ws, 'checker_material_name', '') or 'SUV_Checker') if ws is not None else 'SUV_Checker'
    color_a = tuple(float(v) for v in (getattr(ws, 'checker_color_a', (0.05, 0.05, 0.05, 1.0)) if ws is not None else (0.05, 0.05, 0.05, 1.0)))
    color_b = tuple(float(v) for v in (getattr(ws, 'checker_color_b', (0.85, 0.85, 0.85, 1.0)) if ws is not None else (0.85, 0.85, 0.85, 1.0)))
    def rgba(c):
        vals = list(c[:4]) + [1.0]
        return tuple(max(0.0, min(1.0, float(v))) for v in vals[:4])
    return width, height, tiles_x, tiles_y, name, mat_name, rgba(color_a), rgba(color_b)


def _generated_checker_image(context=None, *, create=True):
    _width, _height, _tiles_x, _tiles_y, name, _mat, _ca, _cb = _checker_settings(context)
    img = bpy.data.images.get(name)
    if img is None and create:
        img = bpy.data.images.new(name, width=_width, height=_height, alpha=True, float_buffer=False)
    return img


def _display_image_in_uv_editors(img) -> None:
    if img is None:
        return
    try:
        for area in getattr(bpy.context.screen, 'areas', []) or []:
            if getattr(area, 'type', None) == 'IMAGE_EDITOR':
                for space in getattr(area, 'spaces', []) or []:
                    if getattr(space, 'type', None) == 'IMAGE_EDITOR':
                        try:
                            space.image = img
                        except Exception:
                            pass
    except Exception:
        pass


def _clear_image_from_uv_editors(images: set) -> None:
    try:
        for area in getattr(bpy.context.screen, 'areas', []) or []:
            if getattr(area, 'type', None) == 'IMAGE_EDITOR':
                for space in getattr(area, 'spaces', []) or []:
                    if getattr(space, 'type', None) == 'IMAGE_EDITOR' and getattr(space, 'image', None) in images:
                        try:
                            space.image = None
                        except Exception:
                            pass
    except Exception:
        pass


def _write_checker_pixels(img, width: int, height: int, tiles_x: int, tiles_y: int, color_a, color_b) -> None:
    if img is None:
        return
    width = max(16, min(8192, int(width)))
    height = max(16, min(8192, int(height)))
    tiles_x = max(1, min(4096, int(tiles_x)))
    tiles_y = max(1, min(4096, int(tiles_y)))
    try:
        if int(img.size[0]) != width or int(img.size[1]) != height:
            img.scale(width, height)
    except Exception:
        pass
    ca = tuple(float(v) for v in color_a)
    cb = tuple(float(v) for v in color_b)

    # Build a rectangular checker image.  Rows are generated once per Y tile parity,
    # so large checker images update quickly while still supporting independent U/V
    # resolution and tile counts.
    row_even = array('f')
    row_odd = array('f')
    for x in range(width):
        tx = (x * tiles_x) // width
        row_even.extend(ca if (tx % 2 == 0) else cb)
        row_odd.extend(cb if (tx % 2 == 0) else ca)
    pixels = array('f')
    for y in range(height):
        ty = (y * tiles_y) // height
        pixels.extend(row_even if (ty % 2 == 0) else row_odd)
    try:
        img.pixels.foreach_set(pixels)
    except Exception:
        img.pixels[:] = list(pixels)
    try:
        img.update()
    except Exception:
        pass
    try:
        img['suv_checker_generated'] = True
        img['suv_checker_width'] = int(width)
        img['suv_checker_height'] = int(height)
        img['suv_checker_tiles_x'] = int(tiles_x)
        img['suv_checker_tiles_y'] = int(tiles_y)
        # Keep old custom property for compatibility with older project files.
        img['suv_checker_tiles'] = int(max(tiles_x, tiles_y))
        img['suv_checker_color_a'] = list(ca)
        img['suv_checker_color_b'] = list(cb)
    except Exception:
        pass


def _ensure_checker_image(context=None, *, update=True):
    width, height, tiles_x, tiles_y, name, _mat, ca, cb = _checker_settings(context)
    img = bpy.data.images.get(name)
    if img is None:
        img = bpy.data.images.new(name, width=width, height=height, alpha=True, float_buffer=False)
    # The Create button intentionally updates an existing generated checker when one
    # already exists.  There is no separate Update button.
    if update:
        _write_checker_pixels(img, width, height, tiles_x, tiles_y, ca, cb)
    _display_image_in_uv_editors(img)
    return img


def _checker_material(context=None, *, create=True, update=True):
    img = _ensure_checker_image(context, update=update)
    _width, _height, _tiles_x, _tiles_y, _img_name, mat_name, _ca, _cb = _checker_settings(context)
    mat = bpy.data.materials.get(mat_name)
    if mat is None and create:
        mat = bpy.data.materials.new(mat_name)
    if mat is None:
        return None
    try:
        mat['suv_checker_generated'] = True
    except Exception:
        pass
    mat.use_nodes = True
    try:
        nt = mat.node_tree
        nt.nodes.clear()
        out = nt.nodes.new('ShaderNodeOutputMaterial')
        bsdf = nt.nodes.new('ShaderNodeBsdfPrincipled')
        tex = nt.nodes.new('ShaderNodeTexImage')
        uv = nt.nodes.new('ShaderNodeUVMap')
        out.location = (440, 0); bsdf.location = (160, 0); tex.location = (-160, 0); uv.location = (-420, 0)
        tex.image = img
        try:
            active_obj = bpy.context.object
            if getattr(active_obj, 'type', None) == 'MESH' and active_obj.data.uv_layers.active:
                uv.uv_map = active_obj.data.uv_layers.active.name
        except Exception:
            pass
        nt.links.new(uv.outputs.get('UV'), tex.inputs.get('Vector'))
        nt.links.new(tex.outputs.get('Color'), bsdf.inputs.get('Base Color'))
        nt.links.new(bsdf.outputs.get('BSDF'), out.inputs.get('Surface'))
    except Exception:
        pass
    return mat


class SMARTUVSUITE_OT_checker_create(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.checker_create'
    bl_label = 'チェッカー作成'
    bl_description = '設定した画像解像度・チェックサイズ・カラーからチェッカーマップを生成します。既に作成済みの場合は現在の設定で更新します。'
    bl_options = {'UNDO'}

    def execute(self, context):
        _ensure_checker_image(context, update=True)
        return {'FINISHED'}


class SMARTUVSUITE_OT_checker_delete(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.checker_delete'
    bl_label = 'チェッカー削除'
    bl_description = '作成したチェッカーマップとチェッカー表示用マテリアルを削除し、UVエディターから非表示にします。'
    bl_options = {'UNDO'}

    def execute(self, context):
        _restore_checker_materials(context, purge=True)
        images = {img for img in bpy.data.images if bool(img.get('suv_checker_generated', False)) or str(img.name).startswith('SUV_Checker')}
        _clear_image_from_uv_editors(images)
        for img in list(images):
            try:
                bpy.data.images.remove(img)
            except Exception:
                pass
        for mat in list(bpy.data.materials):
            if bool(mat.get('suv_checker_generated', False)) or str(mat.name).startswith('SUV_Checker'):
                try:
                    bpy.data.materials.remove(mat)
                except Exception:
                    pass
        return {'FINISHED'}


def _backup_material_slots(obj):
    mats = []
    try:
        for slot in obj.material_slots:
            mat = getattr(slot, 'material', None)
            mats.append(mat.name if mat is not None else '')
    except Exception:
        mats = []
    try:
        obj['suv_checker_material_backup'] = json.dumps({'materials': mats, 'active_index': int(getattr(obj, 'active_material_index', 0))})
        obj['suv_checker_material_preview_active'] = True
    except Exception:
        pass


def _restore_one_object(obj):
    if 'suv_checker_material_backup' not in obj:
        return False
    data = None
    try:
        data = json.loads(str(obj.get('suv_checker_material_backup', '{}') or '{}'))
    except Exception:
        data = None
    if not isinstance(data, dict):
        return False
    names = list(data.get('materials') or [])
    try:
        if not names:
            try:
                obj.data.materials.clear()
            except Exception:
                while len(obj.data.materials) > 0:
                    obj.data.materials.pop(index=len(obj.data.materials) - 1)
        else:
            while len(obj.data.materials) < len(names):
                obj.data.materials.append(None)
            while len(obj.data.materials) > len(names):
                obj.data.materials.pop(index=len(obj.data.materials) - 1)
            for i, name in enumerate(names):
                obj.data.materials[i] = bpy.data.materials.get(name) if name else None
        obj.active_material_index = max(0, min(int(data.get('active_index', 0)), max(0, len(obj.data.materials) - 1)))
    except Exception:
        pass
    try:
        del obj['suv_checker_material_backup']
    except Exception:
        pass
    try:
        obj['suv_checker_material_preview_active'] = False
    except Exception:
        pass
    from .native_stage import _suv_preview_relink_object_slots
    _suv_preview_relink_object_slots(obj)
    return True


def _restore_checker_materials(context=None, *, purge=False):
    objs = _selected_mesh_objects(context)
    # Also restore objects that still carry our preview marker, even if not selected,
    # when purge/delete is explicitly requested.
    if purge:
        try:
            for obj in bpy.data.objects:
                if getattr(obj, 'type', None) == 'MESH' and bool(obj.get('suv_checker_material_preview_active', False)) and obj not in objs:
                    objs.append(obj)
        except Exception:
            pass
    changed = 0
    for obj in objs:
        if _restore_one_object(obj):
            changed += 1
    if purge:
        for mat in list(bpy.data.materials):
            if bool(mat.get('suv_checker_generated', False)) and getattr(mat, 'users', 0) == 0:
                try:
                    bpy.data.materials.remove(mat)
                except Exception:
                    pass
    return changed


class SMARTUVSUITE_OT_checker_material_toggle(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.checker_material_toggle'
    bl_label = 'チェッカーマテリアル切替'
    bl_description = '選択オブジェクトのマテリアルを一時的にチェッカー表示へ切り替え、再実行で元マテリアルへ戻します。'
    bl_options = {'UNDO'}

    def execute(self, context):
        objs = _selected_mesh_objects(context)
        if not objs:
            return {'CANCELLED'}
        active = any(bool(obj.get('suv_checker_material_preview_active', False)) for obj in objs)
        if active:
            _restore_checker_materials(context, purge=True)
            return {'FINISHED'}
        mat = _checker_material(context, create=True, update=True)
        if mat is None:
            return {'CANCELLED'}
        from .native_stage import _suv_preview_unlink_object_slots
        for obj in objs:
            _suv_preview_unlink_object_slots(obj)
            _backup_material_slots(obj)
            try:
                if len(obj.data.materials) == 0:
                    obj.data.materials.append(mat)
                else:
                    for i in range(len(obj.data.materials)):
                        obj.data.materials[i] = mat
                obj.active_material = mat
            except Exception:
                pass
        return {'FINISHED'}


def _components_from_adj(indices: Iterable[int], adj: dict[int, set[int]]):
    indices = list(indices)
    seen = set(); comps = []
    for start in indices:
        if start in seen:
            continue
        stack = [start]; seen.add(start); comp = []
        while stack:
            cur = stack.pop(); comp.append(cur)
            for nb in adj.get(cur, set()):
                if nb not in seen:
                    seen.add(nb); stack.append(nb)
        comps.append(comp)
    return comps


def _shortest_path(adj, start, end):
    from collections import deque
    q = deque([start]); prev = {start: None}
    while q:
        cur = q.popleft()
        if cur == end:
            break
        for nb in adj.get(cur, set()):
            if nb not in prev:
                prev[nb] = cur; q.append(nb)
    if end not in prev:
        return []
    out = []
    cur = end
    while cur is not None:
        out.append(cur); cur = prev.get(cur)
    out.reverse()
    return out


def _line_order_for_points(points, context, globals_dict):
    n = len(points)
    if n < 2:
        return None, None, []
    adj_fn = globals_dict.get('_sus_1660_build_point_adjacency')
    adj = adj_fn(points, context) if callable(adj_fn) else {i: set() for i in range(n)}
    has_edges = any(adj.get(i) for i in range(n))
    candidates = list(range(n))
    if has_edges:
        ends = [i for i in range(n) if len(adj.get(i, set())) <= 1]
        if len(ends) >= 2:
            candidates = ends
    best = (None, None, -1.0)
    for ia, ai in enumerate(candidates):
        a = points[ai]
        ax, ay = float(a['u']), float(a['v'])
        for bi in candidates[ia + 1:]:
            b = points[bi]
            dx = float(b['u']) - ax; dy = float(b['v']) - ay
            d2 = dx*dx + dy*dy
            if d2 > best[2]:
                best = (ai, bi, d2)
    if best[0] is None or best[2] <= 1e-20:
        return None, None, []
    ia, ib, _d2 = best
    path = _shortest_path(adj, ia, ib) if has_edges else []
    if path and len(path) >= 2:
        ordered_idx = list(path)
        used = set(ordered_idx)
        # Keep out-of-main-chain selected points by projection order after the path.
        a = points[ia]; b = points[ib]
        ax, ay = float(a['u']), float(a['v']); bx, by = float(b['u']), float(b['v'])
        vx, vy = bx-ax, by-ay; d2 = max(1e-20, vx*vx + vy*vy)
        extras = []
        for i, p in enumerate(points):
            if i in used:
                continue
            t = ((float(p['u'])-ax)*vx + (float(p['v'])-ay)*vy) / d2
            extras.append((max(0.0, min(1.0, t)), i))
        if extras:
            base = [(k/(len(ordered_idx)-1), idx) for k, idx in enumerate(ordered_idx)] + extras
            base.sort(key=lambda item: item[0])
            ordered_idx = [idx for _t, idx in base]
        return ia, ib, ordered_idx
    # No selected UV-edge chain.  Use the farthest endpoints and projection order.
    a = points[ia]; b = points[ib]
    ax, ay = float(a['u']), float(a['v']); bx, by = float(b['u']), float(b['v'])
    vx, vy = bx-ax, by-ay; d2 = max(1e-20, vx*vx + vy*vy)
    order = []
    for i, p in enumerate(points):
        t = ((float(p['u'])-ax)*vx + (float(p['v'])-ay)*vy) / d2
        order.append((max(0.0, min(1.0, t)), i))
    order.sort(key=lambda item: item[0])
    return ia, ib, [i for _t, i in order]


def _apply_straight(points, *, even: bool, context, globals_dict):
    if len(points) < 2:
        return 0
    set_point = globals_dict.get('_sus_1660_set_point')
    if not callable(set_point):
        return 0
    adj_fn = globals_dict.get('_sus_1660_build_point_adjacency')
    adj = adj_fn(points, context) if callable(adj_fn) else {i: set() for i in range(len(points))}
    comps = _components_from_adj(range(len(points)), adj) if any(adj.values()) else [list(range(len(points)))]
    changed = 0
    for comp in comps:
        group = [points[i] for i in comp]
        if len(group) < 2:
            continue
        ia, ib, ordered_local = _line_order_for_points(group, context, globals_dict)
        if ia is None or ib is None or not ordered_local:
            continue
        a = group[ia]; b = group[ib]
        ax, ay = float(a['u']), float(a['v']); bx, by = float(b['u']), float(b['v'])
        vx, vy = bx - ax, by - ay
        d2 = vx*vx + vy*vy
        if d2 <= 1e-20:
            continue
        ratios = []
        if even:
            total_steps = max(1, len(ordered_local)-1)
            ratios = [i/total_steps for i in range(len(ordered_local))]
        else:
            # Preserve distance ratio between selected chain vertices when possible.
            cum = [0.0]
            total = 0.0
            for prev_idx, cur_idx in zip(ordered_local, ordered_local[1:]):
                p0 = group[prev_idx]; p1 = group[cur_idx]
                seg = math.hypot(float(p1['u'])-float(p0['u']), float(p1['v'])-float(p0['v']))
                total += seg; cum.append(total)
            if total > 1e-20:
                ratios = [c/total for c in cum]
            else:
                ratios = []
                for idx in ordered_local:
                    p = group[idx]
                    t = ((float(p['u'])-ax)*vx + (float(p['v'])-ay)*vy) / d2
                    ratios.append(max(0.0, min(1.0, t)))
        for t, idx in zip(ratios, ordered_local):
            p = group[idx]
            # Keep endpoint records exactly fixed.
            if p is a:
                t = 0.0
            elif p is b:
                t = 1.0
            changed += int(set_point(p, u=ax + vx*t, v=ay + vy*t) or 0)
    return changed


def patch_line_tools(globals_dict):
    def _new_straighten(points, *, even=False, context=None):
        return _apply_straight(points, even=bool(even), context=context, globals_dict=globals_dict)
    globals_dict['_sus_1660_straighten'] = _new_straighten
    globals_dict['_sus_1810_apply_straight'] = lambda points, even=False: _apply_straight(points, even=bool(even), context=bpy.context, globals_dict=globals_dict)


def _unregister_same_operator_id(bl_idname: str):
    for cls in ():
        try:
            if getattr(cls, 'bl_idname', '') == bl_idname:
                ident = str(getattr(getattr(cls, 'bl_rna', None), 'identifier', '') or '')
                if ident and ident not in {'Operator', 'OperatorProperties', 'UnknownType', 'bpy_struct'}:
                    _suv_resource.unregister_class(cls)
                    _OLD_OPERATOR_CLASSES.append(cls)
        except Exception:
            pass


def register(globals_dict=None):
    global _REGISTERED
    if _REGISTERED:
        return
    # Remove the obsolete standalone Update operator from previous installs/reloads.
    _unregister_same_operator_id('smart_uv_suite.checker_update')
    classes = [SMARTUVSUITE_OT_checker_create, SMARTUVSUITE_OT_checker_delete, SMARTUVSUITE_OT_checker_material_toggle]
    for cls in classes:
        try:
            _unregister_same_operator_id(getattr(cls, 'bl_idname', ''))
            _suv_resource.register_class(cls)
            _REGISTERED.append(cls)
        except ValueError:
            pass
        except Exception:
            pass
    if globals_dict is not None:
        patch_line_tools(globals_dict)


def unregister():
    global _REGISTERED
    for cls in reversed(_REGISTERED):
        try:
            _suv_resource.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED = []


def install(globals_dict):
    patch_line_tools(globals_dict)
    prev_register = globals_dict.get('register')
    prev_unregister = globals_dict.get('unregister')
    def _register(_base=prev_register):
        if callable(_base):
            _base()
        register(globals_dict)
        patch_line_tools(globals_dict)
    def _unregister(_base=prev_unregister):
        unregister()
        if callable(_base):
            _base()
    globals_dict['register'] = _register
    globals_dict['unregister'] = _unregister
    return True
