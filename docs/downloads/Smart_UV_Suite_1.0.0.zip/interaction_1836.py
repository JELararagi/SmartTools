# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (c) 2026 JELararagi
from __future__ import annotations
import bpy
from mathutils import Vector

_PG = None
_PREV_SYNC = None
_INSTALLED = False

def _pg(name, default=None):
    return _PG.get(name, default) if isinstance(_PG, dict) else default

def _axis_enabled(context=None):
    try:
        fn = _pg('_sus_1636_axis_memory_enabled')
        return bool(fn(context or bpy.context)) if callable(fn) else False
    except Exception:
        return False

def _get_axis(context=None):
    try:
        fn = _pg('_sus_1636_get_axis')
        axis = str(fn(context or bpy.context) if callable(fn) else 'FREE').upper()
    except Exception:
        axis = 'FREE'
    return axis if axis in {'U','V','FREE'} else 'FREE'

def _set_axis(axis, context=None):
    axis = str(axis or 'FREE').upper()
    if axis not in {'U','V','FREE'}:
        axis = 'FREE'
    try:
        fn = _pg('_sus_1636_set_axis')
        if callable(fn):
            fn(axis, context or bpy.context); return
    except Exception:
        pass
    try: _PG['_SUS_1636_MEMORY_AXIS'] = axis
    except Exception: pass

def _record_axis_from_mode(context, mode):
    if not _axis_enabled(context):
        return
    mode = str(mode or '').upper()
    if mode == 'MOVE_X': _set_axis('U', context)
    elif mode == 'MOVE_Y': _set_axis('V', context)
    elif mode == 'MOVE_XY': _set_axis('FREE', context)

def _axis_delta(context, delta, axis=None):
    try:
        axis = str(axis or (_get_axis(context) if _axis_enabled(context) else 'FREE')).upper()
        if axis == 'U': delta.y = 0.0
        elif axis == 'V': delta.x = 0.0
    except Exception: pass
    return delta

def _loop_key(loop, uv_layer):
    try: return (int(loop.face.index), int(list(loop.face.loops).index(loop)), str(getattr(uv_layer, 'name', '') or ''))
    except Exception: return (id(loop), id(uv_layer))

def _cache_batches(context, batches):
    try: import bmesh
    except Exception: return list(batches or [])
    cached=[]
    for batch in list(batches or []):
        mesh = batch.get('mesh') if isinstance(batch, dict) else None
        if mesh is None: continue
        try:
            bm=bmesh.from_edit_mesh(mesh); bm.faces.ensure_lookup_table()
            uv_name=str(batch.get('uv_layer_name','') or '')
            uv_layer=bm.loops.layers.uv.get(uv_name) if uv_name else None
            if uv_layer is None: uv_layer=bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        except Exception:
            cached.append(batch); continue
        refs=[]; seen=set()
        for rec in list(batch.get('loops',[]) or []):
            try:
                fi,li,original=rec; face=bm.faces[int(fi)]; li=int(li)
                if li < 0 or li >= len(face.loops): continue
                loop=face.loops[li]; key=_loop_key(loop, uv_layer)
                if key in seen: continue
                seen.add(key); refs.append((loop, uv_layer, original.copy()))
            except Exception: continue
        cached.append({'mesh':mesh,'uv_layer_name':str(getattr(uv_layer,'name',batch.get('uv_layer_name','')) or ''),'refs':refs,'loops':batch.get('loops',())} if refs else batch)
    return cached

def _apply_cached_transform(context, batches, transform_func):
    try: import bmesh
    except Exception: return False
    meshes=[]; seen_mesh=set()
    for batch in list(batches or []):
        mesh=batch.get('mesh') if isinstance(batch, dict) else None
        if mesh is None: continue
        wrote=False; refs=list(batch.get('refs') or []) if isinstance(batch, dict) else []
        if refs:
            for loop,uv_layer,original in refs:
                try: loop[uv_layer].uv = transform_func(original); wrote=True
                except (ReferenceError,RuntimeError): continue
                except Exception: continue
        else:
            try:
                bm=bmesh.from_edit_mesh(mesh); bm.faces.ensure_lookup_table()
                uv_name=str(batch.get('uv_layer_name','') or '')
                uv_layer=bm.loops.layers.uv.get(uv_name) if uv_name else None
                if uv_layer is None: uv_layer=bm.loops.layers.uv.active
            except Exception: uv_layer=None
            if uv_layer is None: continue
            for fi,li,original in list(batch.get('loops',[]) or []):
                try:
                    face=bm.faces[int(fi)]; li=int(li)
                    if 0 <= li < len(face.loops): face.loops[li][uv_layer].uv = transform_func(original); wrote=True
                except Exception: continue
        if wrote and id(mesh) not in seen_mesh:
            seen_mesh.add(id(mesh)); meshes.append(mesh)
    for mesh in meshes:
        try: bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        except TypeError:
            try: bmesh.update_edit_mesh(mesh)
            except Exception: pass
        except Exception: pass
    try:
        area=getattr(context,'area',None)
        if area is not None: area.tag_redraw()
    except Exception: pass
    return bool(meshes)

def _delta_key(delta):
    try: return (round(float(delta.x),10), round(float(delta.y),10))
    except Exception: return None

def _instant_invoke(self, context, event):
    fn=_pg('_sus_1635_immediate_enabled')
    if callable(fn):
        try:
            if not fn(context): return {'PASS_THROUGH'}
        except Exception: return {'PASS_THROUGH'}
    if str(getattr(event,'type',''))!='LEFTMOUSE' or str(getattr(event,'value',''))!='PRESS': return {'PASS_THROUGH'}
    fn=_pg('_sus_1835_uv_context')
    if callable(fn):
        try:
            if not fn(context): return {'PASS_THROUGH'}
        except Exception: return {'PASS_THROUGH'}
    fn=_pg('_sus_1835_gizmo_handle_hit')
    if callable(fn):
        try:
            if fn(context,event): return {'PASS_THROUGH'}
        except Exception: pass
    find=_pg('_sus_1835_find_uv_hit'); hit=find(context,event) if callable(find) else None
    if not hit: return {'PASS_THROUGH'}
    selected=False; chk=_pg('_sus_1835_hit_selected')
    if callable(chk):
        try: selected=bool(chk(context,hit))
        except Exception: selected=False
    if (not selected) or bool(getattr(event,'shift',False) or getattr(event,'ctrl',False)):
        sel=_pg('_sus_1835_select_hit')
        try:
            if not callable(sel) or not sel(context,hit,event): return {'PASS_THROUGH'}
        except Exception: return {'PASS_THROUGH'}
    collect=_pg('_sus_1835_collect_batches')
    try: batches=_cache_batches(context, collect(context,hit) if callable(collect) else [])
    except Exception: batches=[]
    if not batches: return {'PASS_THROUGH'}
    region_to_uv=_pg('_sus_1835_region_to_uv')
    if not callable(region_to_uv): return {'PASS_THROUGH'}
    try:
        self._suv1836_batches=batches
        self._suv1836_start_uv=region_to_uv(context,event)
        self._suv1836_start_xy=(int(getattr(event,'mouse_region_x',0) or 0), int(getattr(event,'mouse_region_y',0) or 0))
        self._suv1836_dragging=False; self._suv1836_last_delta_key=None
        self._suv1836_axis=_get_axis(context) if _axis_enabled(context) else 'FREE'
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    except Exception: return {'FINISHED'}

def _instant_modal(self, context, event):
    etype=str(getattr(event,'type','') or ''); evalue=str(getattr(event,'value','') or '')
    if etype in {'ESC','RIGHTMOUSE'}: return {'CANCELLED'}
    if etype=='LEFTMOUSE' and evalue=='RELEASE': return {'FINISHED'}
    if etype in {'MOUSEMOVE','INBETWEEN_MOUSEMOVE'}:
        try:
            region_to_uv=_pg('_sus_1835_region_to_uv')
            if not callable(region_to_uv): return {'RUNNING_MODAL'}
            cur=region_to_uv(context,event); start=getattr(self,'_suv1836_start_uv',None)
            if cur is None or start is None: return {'RUNNING_MODAL'}
            sx,sy=getattr(self,'_suv1836_start_xy',(0,0)); dx=int(getattr(event,'mouse_region_x',0) or 0)-int(sx); dy=int(getattr(event,'mouse_region_y',0) or 0)-int(sy)
            if not bool(getattr(self,'_suv1836_dragging',False)):
                if (dx*dx+dy*dy)**0.5 < 3.0: return {'RUNNING_MODAL'}
                self._suv1836_dragging=True
            delta=Vector((float(cur.x-start.x), float(cur.y-start.y)))
            delta=_axis_delta(context, delta, getattr(self,'_suv1836_axis','FREE'))
            snap=_pg('_sus_1674_snap_delta')
            if callable(snap):
                try: delta=snap(context,delta)
                except Exception: pass
            key=_delta_key(delta)
            if key is not None and key == getattr(self,'_suv1836_last_delta_key',None): return {'RUNNING_MODAL'}
            self._suv1836_last_delta_key=key
            _apply_cached_transform(context, getattr(self,'_suv1836_batches',[]), lambda original: original + delta)
            return {'RUNNING_MODAL'}
        except Exception: return {'FINISHED'}
    return {'RUNNING_MODAL'}

def _patch_instant_class():
    try:
        cls=_pg('SMARTUVSUITE_OT_instant_select_drag_move')
        if not isinstance(cls,type): return
        cls.bl_options={'UNDO', 'BLOCKING'}; cls.invoke=_instant_invoke; cls.modal=_instant_modal
        cls._find_uv_hit=lambda self,context,event: _pg('_sus_1835_find_uv_hit')(context,event)
        cls._select_uv_hit_immediate=lambda self,context,event,hit=None: _pg('_sus_1835_select_hit')(context, hit or _pg('_sus_1835_find_uv_hit')(context,event), event)
        cls._hit_is_current_selection=lambda self,context,hit: _pg('_sus_1835_hit_selected')(context,hit)
        cls._integrated_uv_gizmo_grip_should_own_press=lambda self,context,event: _pg('_sus_1835_gizmo_handle_hit')(context,event)
    except Exception: pass

def _patch_gizmo_module():
    try: from . import uv_gizmo_grip_fix as g
    except Exception: return
    try: g._sus_1835_apply_patch()
    except Exception: pass
    def _gizmo_apply_cached(self, context, transform_func): return _apply_cached_transform(context, getattr(self,'_batches',[]) or [], transform_func)
    def _gizmo_restore_cached(self, context): return _apply_cached_transform(context, getattr(self,'_batches',[]) or [], lambda original: original.copy())
    def _gizmo_invoke_cached(self, context, event):
        if str(getattr(event,'type',''))!='LEFTMOUSE' or str(getattr(event,'value',''))!='PRESS': return {'PASS_THROUGH'}
        try:
            if g._event_has_selection_modifier(event) or not g.is_enabled() or not g._is_uv_editor_context(context) or not hasattr(context.region,'view2d'): return {'PASS_THROUGH'}
        except Exception: return {'PASS_THROUGH'}
        try: press_uv=g._region_to_view(context.region,event.mouse_region_x,event.mouse_region_y)
        except Exception: press_uv=None
        try: batches,stats=g._collect_selected_uv_state(context, anchor_uv=press_uv)
        except Exception: batches,stats=[],None
        if not batches or not stats: return {'PASS_THROUGH'}
        try: pivot_uv=g._selected_uv_pivot(context,stats)
        except Exception: pivot_uv=None
        if pivot_uv is None: return {'PASS_THROUGH'}
        try:
            pivot_region=g._view_to_region(context.region,pivot_uv); mode=g._hit_test_fallback_area(context,event,pivot_region)
        except Exception: mode=None
        if mode is None: return {'PASS_THROUGH'}
        _record_axis_from_mode(context, mode)
        try:
            self._area=context.area; self._region=context.region; self._batches=_cache_batches(context,batches); self._pivot_uv=pivot_uv; self._mode=mode
            self._start_mouse_view=g._region_to_view(self._region,event.mouse_region_x,event.mouse_region_y); self._start_vector=self._start_mouse_view-self._pivot_uv; self._suv1836_last_delta_key=None
            context.window_manager.modal_handler_add(self); return {'RUNNING_MODAL'}
        except Exception: return {'PASS_THROUGH'}
    def _gizmo_apply_mode_cached(self, context, current_view):
        mode=str(getattr(self,'_mode','') or '')
        if mode.startswith('MOVE'):
            delta=current_view-self._start_mouse_view
            if mode=='MOVE_X': delta.y=0.0
            elif mode=='MOVE_Y': delta.x=0.0
            try: delta=g._snap_uv_delta_relative_to_cursor(context,delta)
            except Exception:
                snap=_pg('_sus_1674_snap_delta')
                if callable(snap):
                    try: delta=snap(context,delta)
                    except Exception: pass
            key=_delta_key(delta)
            if key is not None and key == getattr(self,'_suv1836_last_delta_key',None): return None
            self._suv1836_last_delta_key=key; self._apply_to_uvs(context, lambda original: original+delta); return None
        try:
            old=getattr(type(self),'_suv1836_original_apply_mode',None)
            if callable(old): return old(self,context,current_view)
        except Exception: return None
    try:
        op=g.JELARARAGI_OT_uv_gizmo_grip_fix_grab
        if not hasattr(op,'_suv1836_original_apply_mode'): op._suv1836_original_apply_mode=getattr(op,'_apply_mode',None)
        op.invoke=_gizmo_invoke_cached; op._apply_to_uvs=_gizmo_apply_cached; op._restore_original_uvs=_gizmo_restore_cached; op._apply_mode=_gizmo_apply_mode_cached
    except Exception: pass
    try: g._collect_selected_uv_state=g._sus_1835_collect_selected_uv_state
    except Exception: pass
    try:
        snap=_pg('_sus_1674_snap_delta')
        if callable(snap): g._snap_uv_delta_relative_to_cursor=lambda context, delta: snap(context,delta)
    except Exception: pass

def apply_all(pkg_globals=None, context=None):
    global _PG
    if pkg_globals is not None: _PG=pkg_globals
    try:
        rm=_pg('_sus_1835_remove_addon_native_gizmo_tweak_rows')
        if callable(rm): rm()
    except Exception: pass
    try:
        old=_pg('_sus_1835_apply_all')
        if callable(old): old()
    except Exception: pass
    _patch_gizmo_module(); _patch_instant_class()

def install(pkg_globals):
    global _PG, _PREV_SYNC, _INSTALLED
    _PG=pkg_globals
    if not _INSTALLED:
        _PREV_SYNC=pkg_globals.get('_sus_1652_sync_keymaps_from_workspace')
        def _sync(context=None):
            try:
                if callable(_PREV_SYNC): _PREV_SYNC(context or bpy.context)
            except Exception: pass
            apply_all(pkg_globals, context or bpy.context)
            try:
                ws_fn=pkg_globals.get('_sus_1652_ws'); ws=ws_fn(context or bpy.context) if callable(ws_fn) else None; prom=pkg_globals.get('_sus_1652_promote_instant_keymaps_to_head')
                if ws is not None and bool(getattr(ws,'operation_instant_select_enabled',False)) and callable(prom): prom(active=True)
            except Exception: pass
        pkg_globals['_sus_1652_sync_keymaps_from_workspace']=_sync; _INSTALLED=True
    apply_all(pkg_globals, bpy.context)
