import bmesh
from mathutils import Vector


def _move(context, op):
    axes = {'RIGHT': (1, 0), 'LEFT': (-1, 0), 'UP': (0, 1), 'DOWN': (0, -1)}
    axis = axes.get((op.direction or op.mode).strip().upper())
    if axis is None or not op.amount or context.mode != 'EDIT_MESH':
        return False
    delta = Vector(axis) * op.amount
    sync = context.scene.tool_settings.use_uv_select_sync
    changed = False
    for obj in context.objects_in_mode_unique_data:
        bm = bmesh.from_edit_mesh(obj.data)
        layer = bm.loops.layers.uv.active
        if layer is None:
            continue
        loops = [loop for face in bm.faces if not face.hide and (sync or face.select)
                 for loop in face.loops
                 if (loop.vert.select if sync else loop.uv_select_vert)]
        for loop in loops:
            loop[layer].uv += delta
        if loops:
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
            changed = True
    return changed


def build_handlers(api):
    return {
        'smart_uv_suite.workflow_move_uv': api.Handler(_move, 'Move the selected UVs in the specified direction by the given UV distance.', '指定した方向と UV 距離で選択 UV を移動します。'),
    }
