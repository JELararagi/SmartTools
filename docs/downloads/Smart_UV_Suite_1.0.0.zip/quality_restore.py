from __future__ import annotations

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None


def _iter_operator_classes(namespace: dict):
    for name, value in list(namespace.items()):
        if name.startswith('SUV_OT_') and isinstance(value, type):
            yield name, value


def _snapshot_context(context):
    data = {
        'active': None,
        'selected': [],
        'mode': 'OBJECT',
        'uv_sync': False,
    }
    if context is None:
        return data
    try:
        data['active'] = getattr(getattr(context, 'view_layer', None), 'objects', None)
        data['active'] = getattr(data['active'], 'active', None)
    except Exception:
        data['active'] = None
    try:
        data['selected'] = list(getattr(context, 'selected_objects', []) or [])
    except Exception:
        data['selected'] = []
    try:
        active = data['active']
        data['mode'] = str(getattr(active, 'mode', 'OBJECT') or 'OBJECT') if active is not None else 'OBJECT'
    except Exception:
        data['mode'] = 'OBJECT'
    try:
        ts = getattr(context, 'tool_settings', None)
        data['uv_sync'] = bool(getattr(ts, 'use_uv_select_sync', False))
    except Exception:
        data['uv_sync'] = False
    return data


def _restore_context(namespace: dict, context, snapshot: dict):
    issues = []
    if context is None or not isinstance(snapshot, dict):
        return issues

    prev_selected = [obj for obj in list(snapshot.get('selected', []) or []) if obj is not None]
    prev_active = snapshot.get('active')
    prev_mode = str(snapshot.get('mode', 'OBJECT') or 'OBJECT')

    try:
        current_selected = list(getattr(context, 'selected_objects', []) or [])
    except Exception:
        current_selected = []

    prev_set = set(prev_selected)
    for obj in current_selected:
        if obj is None or obj in prev_set:
            continue
        try:
            obj.select_set(False)
        except Exception as exc:
            issues.append(f'deselect:{getattr(obj, "name", "?")}: {exc}')

    for obj in prev_selected:
        try:
            obj.select_set(True)
        except Exception as exc:
            issues.append(f'reselect:{getattr(obj, "name", "?")}: {exc}')

    if prev_active is not None:
        try:
            prev_active.select_set(True)
        except Exception as exc:
            issues.append(f'active_reselect:{getattr(prev_active, "name", "?")}: {exc}')
        try:
            context.view_layer.objects.active = prev_active
        except Exception as exc:
            issues.append(f'active_restore:{getattr(prev_active, "name", "?")}: {exc}')

        safe_mode = namespace.get('_suv_safe_mode_set')
        try:
            current_mode = str(getattr(prev_active, 'mode', 'OBJECT') or 'OBJECT')
        except Exception:
            current_mode = 'OBJECT'
        if current_mode != prev_mode:
            if callable(safe_mode):
                try:
                    ok, err = safe_mode(context, prev_active, prev_mode, source='Quality Restore')
                    if not ok and err:
                        issues.append(str(err))
                except Exception as exc:
                    issues.append(f'mode_restore:{exc}')
            elif bpy is not None:
                try:
                    bpy.ops.object.mode_set(mode=prev_mode)
                except Exception as exc:
                    issues.append(f'mode_restore:{exc}')

    try:
        ts = getattr(context, 'tool_settings', None)
        if ts is not None and hasattr(ts, 'use_uv_select_sync'):
            ts.use_uv_select_sync = bool(snapshot.get('uv_sync', False))
    except Exception as exc:
        issues.append(f'uv_sync_restore:{exc}')
    return issues


def _log(namespace: dict, context, source: str, message: str, details=None, level='INFO'):
    fn = namespace.get('_suv_log_event')
    if callable(fn):
        try:
            fn(context, level, source, message, details or {})
            return
        except Exception:
            pass
    try:
        print(f'[UV Suite Restore] {level} {source}: {message} | {details or {}}')
    except Exception:
        pass


def _should_restore_result(result) -> bool:
    if isinstance(result, set):
        return 'CANCELLED' in result
    if isinstance(result, str):
        return result == 'CANCELLED'
    return False


def wrap_restore(namespace: dict, cls, method_name: str):
    original = getattr(cls, method_name, None)
    if original is None or getattr(original, '_suv_restore_wrapped', False):
        return False

    def wrapped(self, context, *args, **kwargs):
        snapshot = _snapshot_context(context)
        result = original(self, context, *args, **kwargs)
        if _should_restore_result(result):
            issues = _restore_context(namespace, context, snapshot)
            details = {
                'class': cls.__name__,
                'method': method_name,
                'restored_active': getattr(snapshot.get('active'), 'name', '-'),
                'restored_selection_count': len(snapshot.get('selected', []) or []),
                'issues': '; '.join(issues[:12]) if issues else '-',
            }
            level = 'WARN' if issues else 'INFO'
            _log(namespace, context, getattr(cls, 'bl_label', cls.__name__), 'Cancelled operator restored the previous work context.', details, level=level)
        return result

    wrapped._suv_restore_wrapped = True
    setattr(cls, method_name, wrapped)
    return True


def patch_restore(namespace: dict) -> dict:
    counts = {'operator_methods': 0}
    for _name, cls in _iter_operator_classes(namespace):
        for method_name in ('execute', 'invoke', 'modal'):
            try:
                if wrap_restore(namespace, cls, method_name):
                    counts['operator_methods'] += 1
            except Exception:
                pass
    namespace['_suv_quality_restore_counts'] = counts
    return counts
