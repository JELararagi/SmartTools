# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Blender 5.1 compatibility hardening for Smart UV Suite.

This module is intentionally narrow.  It does not install global UI/bpy.props
wrappers and it does not edit keymaps or save Blender user preferences.  It only
normalizes known stale RNA values that Blender 5.1 reports while reading old
startup/userpref data, and removes old top-level module aliases left by earlier
builds.
"""

from __future__ import annotations
from . import resource_api_18168 as _suv_resource

from pathlib import Path

try:  # Blender-only module
    import bpy  # type: ignore
    from bpy.app.handlers import persistent  # type: ignore
except Exception:  # pragma: no cover
    bpy = None  # type: ignore
    def persistent(fn):  # type: ignore
        return fn

_PACKAGE_ID = 'smart_uv_suite'
_LEGACY_TOP_LEVEL_MODULES = ('smart_uv_suite', 'uv_suite')
_IMAGE_UI_MODE_REPAIR_PASSES = 0
_IMAGE_UI_MODE_REPAIR_MAX_PASSES = 4
_REGISTERED = False


def _current_package_root() -> Path | None:
    try:
        return Path(__file__).resolve().parent
    except Exception:
        return None


def _module_points_to_this_extension(module) -> bool:
    root = _current_package_root()
    if root is None or module is None:
        return False
    try:
        module_path_value = str(getattr(module, '__file__', '') or '')
        if not module_path_value:
            spec = getattr(module, '__spec__', None)
            module_path_value = str(getattr(spec, 'origin', '') or '')
        module_file = Path(module_path_value).resolve()
    except Exception:
        return False
    try:
        if module_file == root / '__init__.py' or root in module_file.parents:
            return True
    except Exception:
        pass
    try:
        old_uv_root = root.parent / 'uv_suite'
        if module_file == old_uv_root / '__init__.py' or old_uv_root in module_file.parents:
            return True
    except Exception:
        pass
    return False


def purge_stale_top_level_aliases(package_name: str | None = None) -> int:
    """Compatibility no-op: no sys.modules traversal or module removal."""
    del package_name
    return 0



def _enum_identifiers_from_property(prop) -> tuple[str, ...]:
    values: list[str] = []
    try:
        enum_items = getattr(prop, 'enum_items', ()) or ()
        for item in enum_items:
            ident = str(getattr(item, 'identifier', '') or '')
            if ident and ident not in values:
                values.append(ident)
    except Exception:
        pass
    return tuple(values)


def _safe_ui_mode_target(space) -> str:
    try:
        prop = getattr(getattr(space, 'bl_rna', None), 'properties', {}).get('ui_mode')
    except Exception:
        prop = None
    identifiers = _enum_identifiers_from_property(prop)
    for candidate in ('UV', 'VIEW', 'IMAGE'):
        if candidate in identifiers:
            return candidate
    return identifiers[0] if identifiers else ''


def _iter_image_editor_spaces(context=None):
    seen: set[int] = set()

    def _yield_from_screen(screen):
        try:
            areas = getattr(screen, 'areas', ()) or ()
        except Exception:
            areas = ()
        for area in areas:
            try:
                if str(getattr(area, 'type', '') or '') != 'IMAGE_EDITOR':
                    continue
            except Exception:
                continue
            try:
                spaces = getattr(area, 'spaces', ()) or ()
            except Exception:
                spaces = ()
            for space in spaces:
                try:
                    if str(getattr(space, 'type', '') or '') != 'IMAGE_EDITOR':
                        continue
                except Exception:
                    continue
                try:
                    pointer = int(space.as_pointer())
                except Exception:
                    pointer = id(space)
                if pointer in seen:
                    continue
                seen.add(pointer)
                yield space

    ctx = context or (getattr(bpy, 'context', None) if bpy is not None else None)
    try:
        yield from _yield_from_screen(getattr(ctx, 'screen', None))
    except Exception:
        pass
    try:
        wm = getattr(ctx, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            yield from _yield_from_screen(getattr(window, 'screen', None))
    except Exception:
        pass
    try:
        for screen in getattr(getattr(bpy, 'data', None), 'screens', ()) or ():
            yield from _yield_from_screen(screen)
    except Exception:
        pass


def repair_image_editor_ui_mode(context=None) -> int:
    """Assign a valid UI mode to Image Editor spaces without reading it first."""
    if bpy is None:
        return 0
    fixed = 0
    for space in _iter_image_editor_spaces(context):
        target = _safe_ui_mode_target(space)
        if not target:
            continue
        try:
            setattr(space, 'ui_mode', target)
            fixed += 1
        except Exception:
            pass
    return fixed


def _normalize_language_mode(value) -> str:
    text = str(value or '').strip().upper()
    if text in {'AUTO', 'FORCE_EN', 'FORCE_JA'}:
        return text
    if text in {'0', 'LEGACY_AUTO'}:
        return 'AUTO'
    if text in {'1', 'LEGACY_FORCE_EN'}:
        return 'FORCE_EN'
    if text in {'2', 'LEGACY_FORCE_JA'}:
        return 'FORCE_JA'
    try:
        number = int(value)
    except Exception:
        number = 0
    return {0: 'AUTO', 1: 'FORCE_EN', 2: 'FORCE_JA'}.get(number, 'AUTO')


def _addon_key_candidates(package_name: str | None = None) -> tuple[str, ...]:
    raw = str(package_name or __package__ or _PACKAGE_ID).strip()
    keys = []
    for candidate in (raw, _PACKAGE_ID, f'bl_ext.user_default.{_PACKAGE_ID}', 'uv_suite', 'bl_ext.user_default.uv_suite'):
        if candidate and candidate not in keys:
            keys.append(candidate)
    return tuple(keys)


def normalize_addon_preferences_language_mode(context=None, package_name: str | None = None) -> int:
    if bpy is None:
        return 0
    ctx = context or getattr(bpy, 'context', None)
    prefs_root = None
    try:
        prefs_root = getattr(ctx, 'preferences', None)
    except Exception:
        prefs_root = None
    if prefs_root is None:
        try:
            prefs_root = getattr(getattr(bpy, 'context', None), 'preferences', None)
        except Exception:
            prefs_root = None
    addons = getattr(prefs_root, 'addons', None) if prefs_root is not None else None
    if addons is None:
        return 0
    changed = 0
    for key in _addon_key_candidates(package_name):
        try:
            addon = addons.get(key)
        except Exception:
            addon = None
        prefs = getattr(addon, 'preferences', None) if addon is not None else None
        if prefs is None:
            continue
        try:
            current = getattr(prefs, 'ui_language_mode', 'AUTO')
        except Exception:
            continue
        normalized = _normalize_language_mode(current)
        if str(current) == normalized:
            continue
        try:
            setattr(prefs, 'ui_language_mode', normalized)
            changed += 1
        except Exception:
            pass
    return changed


def run_once(context=None, package_name: str | None = None) -> None:
    try:
        purge_stale_top_level_aliases(package_name)
    except Exception:
        pass
    try:
        normalize_addon_preferences_language_mode(context, package_name)
    except Exception:
        pass
    try:
        repair_image_editor_ui_mode(context)
    except Exception:
        pass


def _timer():
    global _IMAGE_UI_MODE_REPAIR_PASSES
    try:
        run_once(getattr(bpy, 'context', None) if bpy is not None else None, __package__)
    except Exception:
        pass
    _IMAGE_UI_MODE_REPAIR_PASSES += 1
    if _IMAGE_UI_MODE_REPAIR_PASSES < _IMAGE_UI_MODE_REPAIR_MAX_PASSES:
        return 1.5
    return None



@persistent
def _load_post(_dummy=None):
    try:
        run_once(getattr(bpy, 'context', None) if bpy is not None else None, __package__)
    except Exception:
        pass
    return None



def register_handlers(package_name: str | None = None) -> None:
    global _REGISTERED, _IMAGE_UI_MODE_REPAIR_PASSES
    if bpy is None:
        return
    try:
        from . import npanel_persistence as _npanel_store
        enabled = bool(_npanel_store.get_always_on('BLENDER_510_GUARD', False))
    except Exception:
        enabled = False
    if not enabled:
        unregister_handlers()
        return
    _REGISTERED = True
    _IMAGE_UI_MODE_REPAIR_PASSES = 0
    run_once(getattr(bpy, 'context', None), package_name or __package__)
    # Event-driven only: no handler and no timer are installed.



def unregister_handlers() -> None:
    global _REGISTERED
    _REGISTERED = False
    _suv_resource.timer_unregister(_timer)
    try:
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        if handlers is not None:
            _suv_resource.handler_remove(handlers.load_post, _load_post)
    except Exception:
        pass


def _iter_spaces_by_type(space_type):
    try:
        import bpy
        for screen in getattr(bpy.data, 'screens', []) or []:
            for area in getattr(screen, 'areas', []) or []:
                for space in getattr(area, 'spaces', []) or []:
                    if getattr(space, 'type', None) == space_type:
                        yield space
    except Exception:
        return


def _safe_enum_identifiers(rna_owner, prop_name):
    try:
        prop = rna_owner.bl_rna.properties.get(prop_name)
        return [str(item.identifier) for item in prop.enum_items if str(item.identifier)]
    except Exception:
        return []


def _assign_first_valid_enum(space, prop_name, preferred):
    try:
        identifiers = _safe_enum_identifiers(space, prop_name)
        for item in list(preferred or []) + identifiers:
            if item in identifiers:
                try:
                    setattr(space, prop_name, item)
                    return True
                except Exception:
                    continue
    except Exception:
        pass
    return False


def repair_space_editor_enum_values(context=None):
    try:
        for space in _iter_spaces_by_type('NODE_EDITOR'):
            _assign_first_valid_enum(space, 'texture_type', ['ShaderNodeTree', 'OBJECT', 'NONE', 'COMPOSITING', 'GEOMETRY'])
        for space in _iter_spaces_by_type('DOPESHEET_EDITOR'):
            _assign_first_valid_enum(space, 'ui_mode', ['DOPESHEET', 'ACTION', 'TIMELINE'])
        for space in _iter_spaces_by_type('IMAGE_EDITOR'):
            _assign_first_valid_enum(space, 'ui_mode', ['UV', 'VIEW', 'IMAGE'])
    except Exception:
        pass
