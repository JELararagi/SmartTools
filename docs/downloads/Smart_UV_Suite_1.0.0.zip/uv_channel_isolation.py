# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Protect non-target UV map channels during Smart UV Suite UV edits."""
from __future__ import annotations

from functools import wraps
from typing import Any
import inspect
import sys

import bpy


_EXCLUDED_OPERATOR_PREFIXES = (
    'smart_uv_suite.map_channel_',
    'smart_uv_suite.show_help',
    'smart_uv_suite.toggle_ui_foldout',
    'smart_uv_suite.copy_operator_id',
    'smart_uv_suite.keymap_info',
    'smart_uv_suite.integrated_',
)
_EXCLUDED_OPERATOR_IDS = {
    'smart_uv_suite.export_uv_layout',  # read-only export must never activate/ensure a different unwrap map channel.
    'smart_uv_suite.uv_gizmo_grip_fix_grab',  # this modal stores the active UV layer name itself.
    'smart_uv_suite.instant_select_drag_move',  # native/modal Immediate Select must not be snapshot-restored each event.
}
_WRAPPED_ATTR = '_sus_1889_uv_channel_isolated'
_ORIGINAL_ATTR_PREFIX = '_sus_1889_original_'


def _workspace(context: Any):
    try:
        return getattr(getattr(context, 'scene', None), 'suv_workspace', None)
    except Exception:
        return None


def _uvc():
    try:
        from . import uv_map_channels as _module
        return _module
    except Exception:
        return None


def _object_mode(obj: Any) -> str:
    try:
        return str(getattr(obj, 'mode', '') or '')
    except Exception:
        return ''


def _loop_data_from_object_layer(layer: Any) -> list[tuple[tuple[float, float], Any, Any, Any, Any]]:
    out: list[tuple[tuple[float, float], Any, Any, Any, Any]] = []
    try:
        data = getattr(layer, 'data', ()) or ()
    except Exception:
        data = ()
    for loop in data:
        try:
            uv = getattr(loop, 'uv', None)
            co = (float(uv[0]), float(uv[1])) if uv is not None else (0.0, 0.0)
        except Exception:
            co = (0.0, 0.0)
        row = [co]
        for attr in ('pin_uv', 'select', 'select_edge', 'select_vert'):
            try:
                row.append(bool(getattr(loop, attr)))
            except Exception:
                row.append(None)
        out.append(tuple(row))
    return out


def _apply_loop_data_to_object_layer(layer: Any, data: list[tuple[tuple[float, float], Any, Any, Any, Any]]) -> None:
    try:
        loops = getattr(layer, 'data', ()) or ()
    except Exception:
        loops = ()
    for loop, row in zip(loops, data or []):
        try:
            loop.uv = row[0]
        except Exception:
            pass
        for attr, value in zip(('pin_uv', 'select', 'select_edge', 'select_vert'), row[1:]):
            if value is None:
                continue
            try:
                setattr(loop, attr, bool(value))
            except Exception:
                pass


def _loop_data_from_bmesh_layer(bm: Any, uv_layer: Any) -> list[tuple[tuple[float, float], Any, Any, Any, Any]]:
    out: list[tuple[tuple[float, float], Any, Any, Any, Any]] = []
    try:
        faces = list(getattr(bm, 'faces', ()) or ())
    except Exception:
        faces = []
    for face in faces:
        try:
            loops = list(getattr(face, 'loops', ()) or ())
        except Exception:
            loops = []
        for loop in loops:
            try:
                luv = loop[uv_layer]
            except Exception:
                luv = None
            try:
                uv = getattr(luv, 'uv', None)
                co = (float(uv[0]), float(uv[1])) if uv is not None else (0.0, 0.0)
            except Exception:
                co = (0.0, 0.0)
            row = [co]
            for attr in ('pin_uv', 'select', 'select_edge', 'select_vert'):
                try:
                    row.append(bool(getattr(luv, attr)))
                except Exception:
                    row.append(None)
            out.append(tuple(row))
    return out


def _apply_loop_data_to_bmesh_layer(bm: Any, uv_layer: Any, data: list[tuple[tuple[float, float], Any, Any, Any, Any]]) -> None:
    try:
        faces = list(getattr(bm, 'faces', ()) or ())
    except Exception:
        faces = []
    index = 0
    for face in faces:
        try:
            loops = list(getattr(face, 'loops', ()) or ())
        except Exception:
            loops = []
        for loop in loops:
            if index >= len(data or []):
                return
            row = data[index]
            index += 1
            try:
                luv = loop[uv_layer]
            except Exception:
                luv = None
            if luv is None:
                continue
            try:
                luv.uv = row[0]
            except Exception:
                pass
            for attr, value in zip(('pin_uv', 'select', 'select_edge', 'select_vert'), row[1:]):
                if value is None:
                    continue
                try:
                    setattr(luv, attr, bool(value))
                except Exception:
                    pass


def _layer_name(layer: Any, fallback: str = '') -> str:
    try:
        return str(getattr(layer, 'name', '') or fallback)
    except Exception:
        return fallback


def _bmesh_for_mesh(mesh: Any):
    try:
        import bmesh
        return bmesh.from_edit_mesh(mesh)
    except Exception:
        return None


def _bmesh_update(mesh: Any) -> None:
    try:
        import bmesh
        bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
    except TypeError:
        try:
            import bmesh
            bmesh.update_edit_mesh(mesh)
        except Exception:
            pass
    except Exception:
        pass


def _bmesh_uv_layer_by_record(bm: Any, mesh: Any, record: dict[str, Any]):
    try:
        layers = bm.loops.layers.uv
    except Exception:
        return None
    name = str(record.get('name') or '')
    if name:
        try:
            layer = layers.get(name)
            if layer is not None:
                return layer
        except Exception:
            pass
    try:
        index = int(record.get('index', -1))
        mesh_layers = getattr(mesh, 'uv_layers', None)
        if mesh_layers is not None and 0 <= index < len(mesh_layers):
            name = _layer_name(mesh_layers[index], '')
            if name:
                layer = layers.get(name)
                if layer is not None:
                    return layer
    except Exception:
        pass
    return None


def _object_uv_layer_by_record(mesh: Any, record: dict[str, Any]):
    try:
        layers = getattr(mesh, 'uv_layers', None)
        if layers is None:
            return None
        name = str(record.get('name') or '')
        if name:
            try:
                layer = layers.get(name)
                if layer is not None:
                    return layer
            except Exception:
                pass
        index = int(record.get('index', -1))
        if 0 <= index < len(layers):
            return layers[index]
    except Exception:
        return None
    return None


class _UVChannelIsolationGuard:
    def __init__(self, context: Any):
        self.context = context or getattr(bpy, 'context', None)
        self.records: list[dict[str, Any]] = []
        self._active_records: list[tuple[Any, int]] = []

    def __enter__(self):
        self.capture()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.restore()
        return False

    def capture(self) -> None:
        ctx = self.context or getattr(bpy, 'context', None)
        module = _uvc()
        if module is None or ctx is None:
            return
        ws = _workspace(ctx)
        try:
            objects = list(module.mesh_objects_for_context(ctx) or [])
        except Exception:
            objects = []
        seen: set[int] = set()
        for obj in objects:
            try:
                if obj is None or getattr(obj, 'type', None) != 'MESH':
                    continue
                key = int(obj.as_pointer()) if hasattr(obj, 'as_pointer') else id(obj)
                if key in seen:
                    continue
                seen.add(key)
                # Make the selected unwrap map channel Blender's active UV layer before
                # snapshotting.  The target layer itself is intentionally not restored;
                # every other channel is restored after the operator returns.
                try:
                    module.ensure_unwrap_map_channel(ctx, ws, obj)
                except Exception:
                    pass
                mesh = getattr(obj, 'data', None)
                layers = getattr(mesh, 'uv_layers', None) if mesh is not None else None
                if layers is None:
                    continue
                try:
                    count = len(layers)
                except Exception:
                    count = 0
                if count <= 1:
                    continue
                try:
                    target_index = module.selected_index(ctx, ws, obj, create=False)
                except Exception:
                    target_index = None
                if target_index is None:
                    try:
                        target_index = int(getattr(layers, 'active_index', 0) or 0)
                    except Exception:
                        target_index = 0
                try:
                    target_index = max(0, min(int(target_index), count - 1))
                except Exception:
                    target_index = 0
                try:
                    self._active_records.append((obj, int(getattr(layers, 'active_index', target_index) or target_index)))
                except Exception:
                    pass
                edit_mode = _object_mode(obj) == 'EDIT'
                if edit_mode:
                    bm = _bmesh_for_mesh(mesh)
                    if bm is None:
                        continue
                    try:
                        bm.faces.ensure_lookup_table()
                    except Exception:
                        pass
                    try:
                        bm_uv_layers = list(bm.loops.layers.uv)
                    except Exception:
                        bm_uv_layers = []
                    target_name = ''
                    try:
                        active_uv_layer = bm.loops.layers.uv.active
                        target_name = str(getattr(active_uv_layer, 'name', '') or '')
                    except Exception:
                        target_name = ''
                    if not target_name:
                        try:
                            if 0 <= target_index < len(bm_uv_layers):
                                target_name = str(getattr(bm_uv_layers[target_index], 'name', '') or '')
                        except Exception:
                            target_name = ''
                    for index, uv_layer in enumerate(bm_uv_layers):
                        name = str(getattr(uv_layer, 'name', '') or f'UVMap.{index + 1:03d}')
                        if target_name and name == target_name:
                            continue
                        self.records.append({
                            'object': obj,
                            'mesh': mesh,
                            'mode': 'EDIT',
                            'index': index,
                            'name': name,
                            'data': _loop_data_from_bmesh_layer(bm, uv_layer),
                        })
                else:
                    for index, layer in enumerate(layers):
                        if index == target_index:
                            continue
                        self.records.append({
                            'object': obj,
                            'mesh': mesh,
                            'mode': 'OBJECT',
                            'index': index,
                            'name': _layer_name(layer, f'UVMap.{index + 1:03d}'),
                            'data': _loop_data_from_object_layer(layer),
                        })
            except Exception:
                continue

    def restore(self) -> None:
        if not self.records:
            return
        touched_edit_meshes: set[int] = set()
        for record in self.records:
            try:
                obj = record.get('object')
                mesh = record.get('mesh') or getattr(obj, 'data', None)
                if obj is None or mesh is None:
                    continue
                data = record.get('data') or []
                if _object_mode(obj) == 'EDIT':
                    bm = _bmesh_for_mesh(mesh)
                    if bm is None:
                        continue
                    uv_layer = _bmesh_uv_layer_by_record(bm, mesh, record)
                    if uv_layer is None:
                        continue
                    _apply_loop_data_to_bmesh_layer(bm, uv_layer, data)
                    try:
                        touched_edit_meshes.add(int(mesh.as_pointer()))
                    except Exception:
                        touched_edit_meshes.add(id(mesh))
                else:
                    layer = _object_uv_layer_by_record(mesh, record)
                    if layer is None:
                        continue
                    _apply_loop_data_to_object_layer(layer, data)
                    try:
                        if hasattr(mesh, 'update'):
                            mesh.update()
                    except Exception:
                        pass
            except Exception:
                continue
        for record in self.records:
            try:
                obj = record.get('object')
                mesh = record.get('mesh') or getattr(obj, 'data', None)
                if obj is not None and mesh is not None and _object_mode(obj) == 'EDIT':
                    key = int(mesh.as_pointer()) if hasattr(mesh, 'as_pointer') else id(mesh)
                    if key in touched_edit_meshes:
                        _bmesh_update(mesh)
                        touched_edit_meshes.discard(key)
            except Exception:
                pass
        # Keep Blender's active UV layer synchronized with the selected target after restoration.
        ctx = self.context or getattr(bpy, 'context', None)
        module = _uvc()
        ws = _workspace(ctx) if ctx is not None else None
        if module is not None and ctx is not None:
            try:
                module.ensure_unwrap_map_channel(ctx, ws, None)
            except Exception:
                pass


def _should_wrap_operator(cls: type) -> bool:
    try:
        op_id = str(getattr(cls, 'bl_idname', '') or '')
    except Exception:
        op_id = ''
    if not op_id.startswith('smart_uv_suite.'):
        return False
    if op_id in _EXCLUDED_OPERATOR_IDS:
        return False
    for prefix in _EXCLUDED_OPERATOR_PREFIXES:
        if op_id.startswith(prefix):
            return False
    return True


def _run_with_guard(original, self, context, *args):
    guard = None
    try:
        guard = _UVChannelIsolationGuard(context)
        guard.capture()
    except Exception:
        guard = None
    try:
        return original(self, context, *args)
    finally:
        if guard is not None:
            try:
                guard.restore()
            except Exception:
                pass


def _make_execute_wrapper(original):
    @wraps(original)
    def _wrapped(self, context):
        return _run_with_guard(original, self, context)
    return _wrapped


def _make_event_wrapper(original):
    @wraps(original)
    def _wrapped(self, context, event):
        return _run_with_guard(original, self, context, event)
    return _wrapped


def _wrap_method(cls: type, name: str) -> bool:
    try:
        original = getattr(cls, name, None)
    except Exception:
        original = None
    if original is None or not callable(original):
        return False
    try:
        if getattr(original, _WRAPPED_ATTR, False):
            return False
    except Exception:
        pass
    try:
        setattr(cls, _ORIGINAL_ATTR_PREFIX + name, original)
    except Exception:
        pass

    if name == 'execute':
        _wrapped = _make_execute_wrapper(original)
    elif name in {'invoke', 'modal'}:
        _wrapped = _make_event_wrapper(original)
    else:
        return False

    try:
        setattr(_wrapped, _WRAPPED_ATTR, True)
    except Exception:
        pass
    try:
        setattr(cls, name, _wrapped)
        return True
    except Exception:
        return False


def install(package_name: str = '') -> int:
    """Wrap Smart UV Suite operator methods with the UV-channel guard."""
    package_name = str(package_name or __package__ or '')
    wrapped = 0
    modules = []
    for name, module in ():
        try:
            if not module:
                continue
            if package_name and not (name == package_name or str(name).startswith(package_name + '.')):
                continue
            modules.append(module)
        except Exception:
            continue
    for module in modules:
        try:
            values = list(vars(module).values())
        except Exception:
            values = []
        for value in values:
            try:
                if not inspect.isclass(value):
                    continue
                if not issubclass(value, bpy.types.Operator):
                    continue
                if not _should_wrap_operator(value):
                    continue
                for method_name in ('execute', 'invoke', 'modal'):
                    if _wrap_method(value, method_name):
                        wrapped += 1
            except Exception:
                continue
    return wrapped
