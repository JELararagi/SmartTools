# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Live UV Direction Align backend for Smart UV Suite 1.8.92.

This module replaces the older direction-align execution path with a live BMesh
selection path.  It reads the current UV Editor selection at execution time and
uses hidden Blender UV-selection attributes only as a last-resort fallback when
no live selection exists.  That prevents stale selection/cache state from moving
or aligning unintended UVs.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import bpy

_NS: Dict[str, Any] = {}
_PREV_VERTEX_ATTR = "_suv_1892_previous_vertex_execute"
_PREV_ISLAND_ATTR = "_suv_1892_previous_island_execute"
_DIGITS = 7
_GROUP_ACTIONS = {"ALIGN_H_GROUP", "ALIGN_V_GROUP", "DISTRIBUTE_H_GROUP", "DISTRIBUTE_V_GROUP"}
_ALL_VERTEX_ACTIONS = {
    "ALIGN_TL", "ALIGN_TOP", "ALIGN_TR", "ALIGN_LEFT", "ALIGN_CENTER", "ALIGN_RIGHT",
    "ALIGN_BL", "ALIGN_BOTTOM", "ALIGN_BR", "ALIGN_H", "ALIGN_V",
    "ALIGN_H_GROUP", "ALIGN_V_GROUP", "DISTRIBUTE_H", "DISTRIBUTE_V",
    "DISTRIBUTE_H_GROUP", "DISTRIBUTE_V_GROUP", "FLIP_H", "FLIP_V", "ROTATE_CCW", "ROTATE_CW",
}
_ALL_ISLAND_ACTIONS = {
    "ALIGN_TL", "ALIGN_TOP", "ALIGN_TR", "ALIGN_LEFT", "ALIGN_CENTER", "ALIGN_RIGHT",
    "ALIGN_BL", "ALIGN_BOTTOM", "ALIGN_BR", "ALIGN_H", "ALIGN_V",
    "DISTRIBUTE_H", "DISTRIBUTE_V", "MIRROR_H", "MIRROR_V", "ROTATE_CCW", "ROTATE_CW",
}


def _txt(context: Any, en: str, ja: str) -> str:
    fn = _NS.get("_sus_text")
    if callable(fn):
        try:
            return str(fn(en, ja, context))
        except Exception:
            pass
    try:
        lang = str(getattr(getattr(context, "preferences", None), "view", None).language or "")
        if lang.startswith("ja"):
            return ja
    except Exception:
        pass
    return ja or en


def _uv_mode(context: Any) -> str:
    fn = _NS.get("_sus_1655_uv_mode") or _NS.get("_sus_uv_select_mode")
    if callable(fn):
        try:
            return str(fn(context) or "VERTEX").upper()
        except Exception:
            pass
    try:
        return str(getattr(getattr(context, "tool_settings", None), "uv_select_mode", "VERTEX") or "VERTEX").upper()
    except Exception:
        return "VERTEX"


def _sticky(context: Any) -> str:
    fn = _NS.get("_sus_uv_sticky_select_mode")
    if callable(fn):
        try:
            return str(fn(context) or "DISABLED").upper()
        except Exception:
            pass
    try:
        return str(getattr(getattr(getattr(context, "scene", None), "suv_workspace", None), "uv_sticky_select_mode", "DISABLED") or "DISABLED").upper()
    except Exception:
        return "DISABLED"


def _sync(context: Any) -> bool:
    try:
        return bool(getattr(getattr(context, "tool_settings", None), "use_uv_select_sync", False))
    except Exception:
        return False


def _obj_key(obj: Any) -> str:
    for name in ("_sus_1655_obj_key", "_sus_1653_obj_key"):
        fn = _NS.get(name)
        if callable(fn):
            try:
                return str(fn(obj))
            except Exception:
                pass
    try:
        return str(getattr(obj, "name_full", None) or getattr(obj, "name", None) or id(obj))
    except Exception:
        return str(id(obj))


def _attr_values(mesh: Any, name: str) -> List[bool]:
    # Hidden UV selection attributes may be stale.  Callers use this only when no
    # live UV/BMesh selection is found, so it remains a fallback path.
    fn = _NS.get("_sus_1655_attr_values")
    if callable(fn):
        try:
            return [bool(x) for x in (fn(mesh, name) or [])]
        except Exception:
            pass
    try:
        attr = getattr(mesh, "attributes", None).get(name)
        if attr is None:
            return []
        return [bool(getattr(item, "value", False)) for item in getattr(attr, "data", []) or []]
    except Exception:
        return []


def _edit_objects(context: Any) -> List[Any]:
    out: List[Any] = []
    try:
        out = [o for o in (getattr(context, "objects_in_mode_unique_data", None) or []) if getattr(o, "type", "") == "MESH" and getattr(o, "mode", "") == "EDIT"]
    except Exception:
        out = []
    if not out:
        try:
            obj = getattr(context, "edit_object", None) or getattr(context, "active_object", None)
            if obj is not None and getattr(obj, "type", "") == "MESH" and getattr(obj, "mode", "") == "EDIT":
                out = [obj]
        except Exception:
            pass
    seen = set(); clean: List[Any] = []
    for obj in out:
        try:
            key = id(getattr(obj, "data", obj))
        except Exception:
            key = id(obj)
        if key in seen:
            continue
        seen.add(key); clean.append(obj)
    return clean


def _enter_edit_context(context: Any) -> Tuple[Any, str, List[Any], bool]:
    old_active = None
    old_mode = "OBJECT"
    changed = False
    try:
        old_active = getattr(getattr(context, "view_layer", None), "objects", None).active
    except Exception:
        old_active = None
    objs = _edit_objects(context)
    if objs:
        return old_active, "EDIT", objs, False
    obj = getattr(context, "active_object", None)
    if obj is None or getattr(obj, "type", "") != "MESH":
        return old_active, old_mode, [], False
    try:
        old_mode = str(getattr(obj, "mode", "OBJECT") or "OBJECT")
    except Exception:
        old_mode = "OBJECT"
    try:
        context.view_layer.objects.active = obj
        obj.select_set(True)
    except Exception:
        pass
    if old_mode != "EDIT":
        try:
            bpy.ops.object.mode_set(mode="EDIT")
            changed = True
        except Exception:
            pass
    return old_active, old_mode, _edit_objects(context), changed


def _restore_edit_context(context: Any, old_active: Any, old_mode: str, changed: bool) -> None:
    if changed and old_mode and old_mode != "EDIT":
        try:
            bpy.ops.object.mode_set(mode=old_mode)
        except Exception:
            pass
    try:
        if old_active is not None:
            context.view_layer.objects.active = old_active
    except Exception:
        pass


def _ensure_unwrap_target(context: Any, obj: Any = None) -> None:
    # Keep the active Blender UV layer equal to Basic Settings > 展開使用マップチャンネル.
    try:
        from . import uv_map_channels as _uvc
    except Exception:
        return
    try:
        ws = getattr(getattr(context, "scene", None), "suv_workspace", None)
    except Exception:
        ws = None
    try:
        if obj is not None:
            _uvc.ensure_unwrap_map_channel(context, ws, obj)
        else:
            _uvc.ensure_unwrap_map_channel(context, ws, None)
    except Exception:
        pass


def _uv_layer_for_bmesh(bm: Any):
    try:
        layer = bm.loops.layers.uv.active
        if layer is not None:
            return layer
    except Exception:
        pass
    try:
        return bm.loops.layers.uv.verify()
    except Exception:
        return None


def _uv_xy(loop: Any, uv_layer: Any) -> Tuple[float, float]:
    try:
        uv = loop[uv_layer].uv
        return float(uv.x), float(uv.y)
    except Exception:
        return 0.0, 0.0


def _uv_key(loop: Any, uv_layer: Any) -> Optional[Tuple[float, float]]:
    try:
        u, v = _uv_xy(loop, uv_layer)
        return (round(u, _DIGITS), round(v, _DIGITS))
    except Exception:
        return None


def _loop_index(loop: Any) -> int:
    try:
        return int(getattr(loop, "index", -1))
    except Exception:
        return -1


def _face_index(face: Any) -> int:
    try:
        return int(getattr(face, "index", -1))
    except Exception:
        return -1


def _live_vert_selected(loop: Any, uv_layer: Any, sync: bool) -> bool:
    for getter in (
        lambda: getattr(loop, "uv_select_vert", False),
        lambda: getattr(loop[uv_layer], "select", False),
    ):
        try:
            if bool(getter()):
                return True
        except Exception:
            pass
    if sync:
        try:
            return bool(getattr(loop.vert, "select", False))
        except Exception:
            pass
    return False


def _live_edge_selected(loop: Any, uv_layer: Any, sync: bool) -> bool:
    for getter in (
        lambda: getattr(loop, "uv_select_edge", False),
        lambda: getattr(loop[uv_layer], "select_edge", False),
    ):
        try:
            if bool(getter()):
                return True
        except Exception:
            pass
    if sync:
        try:
            if bool(getattr(loop.edge, "select", False)):
                return True
        except Exception:
            pass
    return False


def _live_face_selected(face: Any, sync: bool) -> bool:
    for getter in (
        lambda: getattr(face, "uv_select", False),
    ):
        try:
            if bool(getter()):
                return True
        except Exception:
            pass
    if sync:
        try:
            if bool(getattr(face, "select", False)):
                return True
        except Exception:
            pass
    return False


def _make_record(obj: Any, mesh: Any, bm: Any, uv_layer: Any, face: Any, loop: Any, local_i: int) -> Dict[str, Any]:
    u, v = _uv_xy(loop, uv_layer)
    obj_key = _obj_key(obj)
    return {
        "obj": obj,
        "obj_key": obj_key,
        "mesh": mesh,
        "bm": bm,
        "uv_layer": uv_layer,
        "face": face,
        "loop": loop,
        "face_index": _face_index(face),
        "face_loop_index": int(local_i),
        "loop_index": _loop_index(loop),
        "vertex_index": int(getattr(getattr(loop, "vert", None), "index", -1)),
        "edge_index": int(getattr(getattr(loop, "edge", None), "index", -1)),
        "record_id": (obj_key, _face_index(face), int(local_i), _loop_index(loop)),
        "uv_key": _uv_key(loop, uv_layer),
        "u": u,
        "v": v,
    }


def _point_key(rec: Dict[str, Any], sticky: str, fallback: int) -> Any:
    sticky = str(sticky or "DISABLED").upper()
    if sticky == "SHARED_LOCATION":
        return ("uv", rec.get("uv_key"))
    if sticky == "SHARED_VERTEX":
        return ("vert", rec.get("obj_key"), rec.get("vertex_index"))
    return ("record", rec.get("record_id", fallback))


def _points_from_records(records: Sequence[Dict[str, Any]], sticky: str) -> Tuple[List[Dict[str, Any]], Dict[Any, int], Dict[int, Any]]:
    buckets: Dict[Any, List[Dict[str, Any]]] = {}
    order: List[Any] = []
    rec_to_pkey: Dict[int, Any] = {}
    for i, rec in enumerate(records or []):
        key = _point_key(rec, sticky, i)
        rec_to_pkey[id(rec)] = key
        if key not in buckets:
            buckets[key] = []
            order.append(key)
        buckets[key].append(rec)
    points: List[Dict[str, Any]] = []
    pindex: Dict[Any, int] = {}
    for key in order:
        recs = buckets.get(key) or []
        if not recs:
            continue
        us = [float(r.get("u", 0.0)) for r in recs]
        vs = [float(r.get("v", 0.0)) for r in recs]
        pindex[key] = len(points)
        points.append({"key": key, "records": recs, "u": sum(us) / len(us), "v": sum(vs) / len(vs)})
    return points, pindex, rec_to_pkey


def _find(parent: List[int], i: int) -> int:
    while parent[i] != i:
        parent[i] = parent[parent[i]]
        i = parent[i]
    return i


def _union(parent: List[int], a: int, b: int) -> None:
    try:
        if a < 0 or b < 0 or a >= len(parent) or b >= len(parent):
            return
        ra = _find(parent, a)
        rb = _find(parent, b)
        if ra != rb:
            parent[rb] = ra
    except Exception:
        pass


def _mesh_has_live_selection(bm: Any, uv_layer: Any, mode: str, sync: bool) -> bool:
    mode = str(mode or "VERTEX").upper()
    try:
        for face in bm.faces:
            if mode in {"FACE", "ISLAND"} and _live_face_selected(face, sync):
                return True
            for loop in face.loops:
                if mode == "EDGE":
                    if _live_edge_selected(loop, uv_layer, sync):
                        return True
                elif mode in {"FACE", "ISLAND"}:
                    # Face mode handled above.  Full-vertex selection below is
                    # accepted later as a convenience, but any live loop flag is
                    # enough to reject stale hidden attributes.
                    if _live_vert_selected(loop, uv_layer, sync) or _live_edge_selected(loop, uv_layer, sync):
                        return True
                else:
                    if _live_vert_selected(loop, uv_layer, sync):
                        return True
    except Exception:
        pass
    return False


def _collect_vertex_domain(context: Any, scope: str = "SELECTED") -> Dict[str, Any]:
    import bmesh

    mode = _uv_mode(context)
    sync = _sync(context)
    sticky = _sticky(context)
    scope_all = str(scope or "SELECTED").upper() == "ALL"
    records: List[Dict[str, Any]] = []
    pair_records: List[Tuple[Dict[str, Any], Dict[str, Any]]] = []
    meshes: List[Any] = []

    for obj in _edit_objects(context):
        try:
            _ensure_unwrap_target(context, obj)
            mesh = getattr(obj, "data", None)
            bm = bmesh.from_edit_mesh(mesh)
            from .uv_sync_exact_align_18118 import _sync_uv_flags_from_mesh
            _sync_uv_flags_from_mesh(context, bm)
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
            uv_layer = _uv_layer_for_bmesh(bm)
            if uv_layer is None:
                continue
        except Exception:
            continue
        meshes.append(mesh)
        live_any = _mesh_has_live_selection(bm, uv_layer, mode, sync)
        v_attr = [] if live_any else _attr_values(mesh, ".uv_select_vert")
        e_attr = [] if live_any else _attr_values(mesh, ".uv_select_edge")
        f_attr = [] if live_any else _attr_values(mesh, ".uv_select_face")
        rec_by_loop: Dict[Tuple[str, int], Dict[str, Any]] = {}
        obj_key = _obj_key(obj)

        def add(face: Any, loop: Any, local_i: int) -> Optional[Dict[str, Any]]:
            try:
                key = (obj_key, _loop_index(loop))
                if key in rec_by_loop:
                    return rec_by_loop[key]
                rec = _make_record(obj, mesh, bm, uv_layer, face, loop, local_i)
                records.append(rec)
                rec_by_loop[key] = rec
                return rec
            except Exception:
                return None

        for face in bm.faces:
            try:
                if getattr(face, "hide", False):
                    continue
                loops = list(face.loops)
            except Exception:
                continue
            if not loops:
                continue
            fi = _face_index(face)
            face_selected = bool(scope_all)
            if not face_selected:
                if mode in {"FACE", "ISLAND"}:
                    face_selected = _live_face_selected(face, sync)
                    if not live_any and 0 <= fi < len(f_attr):
                        face_selected = face_selected or bool(f_attr[fi])
            for i, loop in enumerate(loops):
                li = _loop_index(loop)
                nloop = loop.link_loop_next
                selected = bool(scope_all)
                if not selected:
                    if mode == "EDGE":
                        selected = _live_edge_selected(loop, uv_layer, sync)
                        if not live_any and 0 <= li < len(e_attr):
                            selected = selected or bool(e_attr[li])
                    elif mode in {"FACE", "ISLAND"}:
                        selected = face_selected
                    else:
                        selected = _live_vert_selected(loop, uv_layer, sync)
                        if not live_any and 0 <= li < len(v_attr):
                            selected = selected or bool(v_attr[li])
                if selected:
                    rec = add(face, loop, i)
                    if mode == "EDGE":
                        nrec = add(face, nloop, (i + 1) % len(loops))
                        if rec is not None and nrec is not None:
                            pair_records.append((rec, nrec))
                    elif mode in {"FACE", "ISLAND"}:
                        # Connect selected face corners so each face behaves as
                        # one component for grouped actions.
                        nrec = add(face, nloop, (i + 1) % len(loops))
                        if rec is not None and nrec is not None:
                            pair_records.append((rec, nrec))
                if mode not in {"EDGE", "FACE", "ISLAND"}:
                    # For vertex-group actions, visible selected-point adjacency
                    # connects only when both endpoints are currently selected.
                    try:
                        next_selected = _live_vert_selected(nloop, uv_layer, sync)
                        if not live_any:
                            nli = _loop_index(nloop)
                            next_selected = next_selected or (0 <= nli < len(v_attr) and bool(v_attr[nli]))
                        if selected and next_selected:
                            r0 = add(face, loop, i)
                            r1 = add(face, nloop, (i + 1) % len(loops))
                            if r0 is not None and r1 is not None:
                                pair_records.append((r0, r1))
                    except Exception:
                        pass
    points, pindex, rec_to_pkey = _points_from_records(records, sticky)
    pairs: List[Tuple[int, int]] = []
    for a, b in pair_records:
        ia = pindex.get(rec_to_pkey.get(id(a)))
        ib = pindex.get(rec_to_pkey.get(id(b)))
        if ia is not None and ib is not None and ia != ib:
            pairs.append((ia, ib))
    # Connect FACE/ISLAND components across selected faces that share a welded UV edge.
    if points:
        edge_sig_to_indices: Dict[Any, List[int]] = {}
        for rec in records:
            try:
                loop = rec.get("loop")
                uv_layer = rec.get("uv_layer")
                a = _uv_key(loop, uv_layer)
                b = _uv_key(loop.link_loop_next, uv_layer)
                if a is None or b is None:
                    continue
                sig = (rec.get("obj_key"), int(getattr(loop.edge, "index", -1)), tuple(sorted((a, b))))
                ia = pindex.get(rec_to_pkey.get(id(rec)))
                if ia is not None:
                    edge_sig_to_indices.setdefault(sig, []).append(ia)
            except Exception:
                pass
        for idxs in edge_sig_to_indices.values():
            if len(idxs) > 1:
                base = idxs[0]
                for idx in idxs[1:]:
                    pairs.append((base, idx))
    return {"mode": mode, "sticky": sticky, "points": points, "pairs": pairs, "meshes": meshes}


def _write_point(point: Dict[str, Any], u: Optional[float] = None, v: Optional[float] = None) -> int:
    changed = 0
    for rec in list(point.get("records") or []):
        try:
            loop = rec.get("loop")
            uv_layer = rec.get("uv_layer")
            uv = loop[uv_layer].uv
            if u is not None:
                uv.x = float(u)
                rec["u"] = float(u)
            if v is not None:
                uv.y = float(v)
                rec["v"] = float(v)
            changed += 1
        except Exception:
            pass
    if u is not None:
        point["u"] = float(u)
    if v is not None:
        point["v"] = float(v)
    return changed


def _apply_vertex_action(points: Sequence[Dict[str, Any]], action: str) -> int:
    pts = [p for p in (points or []) if p]
    action = str(action or "").upper()
    if not pts:
        return 0
    if action in {"DISTRIBUTE_H", "DISTRIBUTE_V"}:
        axis_u = action == "DISTRIBUTE_H"
        key = (lambda p: float(p.get("u", 0.0))) if axis_u else (lambda p: float(p.get("v", 0.0)))
        ordered = sorted(pts, key=key)
        if len(ordered) < 2:
            return 0
        start = key(ordered[0])
        end = key(ordered[-1])
        if abs(end - start) <= 1.0e-12:
            return 0
        step = (end - start) / float(max(1, len(ordered) - 1))
        changed = 0
        for i, pt in enumerate(ordered):
            val = start + step * i
            changed += _write_point(pt, u=val) if axis_u else _write_point(pt, v=val)
        return changed
    us = [float(p.get("u", 0.0)) for p in pts]
    vs = [float(p.get("v", 0.0)) for p in pts]
    min_u, max_u = min(us), max(us)
    min_v, max_v = min(vs), max(vs)
    cu, cv = (min_u + max_u) * 0.5, (min_v + max_v) * 0.5
    if action in {"FLIP_H", "FLIP_V", "ROTATE_CCW", "ROTATE_CW"}:
        changed = 0
        for pt in pts:
            u0 = float(pt.get("u", 0.0))
            v0 = float(pt.get("v", 0.0))
            nu, nv = u0, v0
            if action == "FLIP_H":
                nu = cu - (u0 - cu)
            elif action == "FLIP_V":
                nv = cv - (v0 - cv)
            elif action == "ROTATE_CCW":
                du, dv = u0 - cu, v0 - cv
                nu, nv = cu - dv, cv + du
            elif action == "ROTATE_CW":
                du, dv = u0 - cu, v0 - cv
                nu, nv = cu + dv, cv - du
            changed += _write_point(pt, u=nu, v=nv)
        return changed
    set_u: Optional[float] = None
    set_v: Optional[float] = None
    if action in {"ALIGN_TL", "ALIGN_LEFT", "ALIGN_BL"}:
        set_u = min_u
    elif action in {"ALIGN_TR", "ALIGN_RIGHT", "ALIGN_BR"}:
        set_u = max_u
    elif action in {"ALIGN_CENTER", "ALIGN_V"}:
        set_u = cu
    if action in {"ALIGN_TL", "ALIGN_TOP", "ALIGN_TR"}:
        set_v = max_v
    elif action in {"ALIGN_BL", "ALIGN_BOTTOM", "ALIGN_BR"}:
        set_v = min_v
    elif action in {"ALIGN_CENTER", "ALIGN_H"}:
        set_v = cv
    if set_u is None and set_v is None:
        return 0
    changed = 0
    for pt in pts:
        changed += _write_point(pt, u=set_u, v=set_v)
    return changed


def _point_groups(domain: Dict[str, Any], by_group: bool) -> List[List[Dict[str, Any]]]:
    points = list(domain.get("points") or [])
    if not by_group:
        return [points] if points else []
    parent = list(range(len(points)))
    for a, b in list(domain.get("pairs") or []):
        _union(parent, int(a), int(b))
    groups: Dict[int, List[Dict[str, Any]]] = {}
    order: List[int] = []
    for i, pt in enumerate(points):
        root = _find(parent, i)
        if root not in groups:
            groups[root] = []
            order.append(root)
        groups[root].append(pt)
    return [groups[k] for k in order if groups.get(k)]


def _update_meshes(meshes: Iterable[Any]) -> None:
    try:
        import bmesh
    except Exception:
        return
    seen = set()
    for mesh in meshes or []:
        try:
            key = int(mesh.as_pointer()) if hasattr(mesh, "as_pointer") else id(mesh)
            if key in seen:
                continue
            seen.add(key)
            try:
                bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
            except TypeError:
                bmesh.update_edit_mesh(mesh)
            except Exception:
                pass
        except Exception:
            pass


def _vertex_execute(self: Any, context: Any) -> set:
    raw = str(getattr(self, "action", "ALIGN_CENTER") or "ALIGN_CENTER").upper()
    if raw not in _ALL_VERTEX_ACTIONS:
        raw = "ALIGN_CENTER"
    scope = str(getattr(self, "scope", "SELECTED") or "SELECTED").upper()
    old_active, old_mode, objs, changed_mode = _enter_edit_context(context)
    if not objs:
        try:
            self.report({"WARNING"}, _txt(context, "No mesh object is active.", "アクティブなメッシュオブジェクトがありません。"))
        except Exception:
            pass
        return {"CANCELLED"}
    try:
        _ensure_unwrap_target(context, None)
        domain = _collect_vertex_domain(context, scope=scope)
        points = domain.get("points") or []
        if not points:
            try:
                self.report({"WARNING"}, _txt(context, "No current UV vertices, edges, or faces are selected.", "現在選択されているUV頂点・辺・面がありません。"))
            except Exception:
                pass
            return {"CANCELLED"}
        by_group = raw.endswith("_GROUP")
        action = raw[:-6] if by_group else raw
        changed = 0
        for group in _point_groups(domain, by_group):
            changed += _apply_vertex_action(group, action)
        if changed <= 0:
            # Already aligned is a valid final state.  Return FINISHED so repeated
            # operations do not fall through to older cached backends.
            return {"FINISHED"}
        _update_meshes(domain.get("meshes") or [])
        return {"FINISHED"}
    except Exception as exc:
        try:
            self.report({"WARNING"}, _txt(context, "Vertex alignment failed.", "頂点方向整列に失敗しました。") + f" {exc}")
        except Exception:
            pass
        return {"CANCELLED"}
    finally:
        _restore_edit_context(context, old_active, old_mode, changed_mode)


def _face_fully_selected_by_live(face: Any, uv_layer: Any, mode: str, sync: bool) -> bool:
    mode = str(mode or "VERTEX").upper()
    try:
        loops = list(face.loops)
    except Exception:
        loops = []
    if not loops:
        return False
    if mode in {"FACE", "ISLAND"}:
        if _live_face_selected(face, sync):
            return True
        # Accept complete vertex selection as a face/island selection fallback.
        return all(_live_vert_selected(loop, uv_layer, sync) for loop in loops)
    if mode == "EDGE":
        return all(_live_edge_selected(loop, uv_layer, sync) for loop in loops)
    return all(_live_vert_selected(loop, uv_layer, sync) for loop in loops)


def _collect_selected_face_indices(obj: Any, bm: Any, uv_layer: Any, context: Any) -> Tuple[set[int], bool]:
    mode = _uv_mode(context)
    sync = _sync(context)
    selected: set[int] = set()
    live_any = _mesh_has_live_selection(bm, uv_layer, mode, sync)
    if live_any:
        for face in bm.faces:
            if _face_fully_selected_by_live(face, uv_layer, mode, sync):
                selected.add(_face_index(face))
        return selected, True
    # Fallback only when no live BMesh/UV selection exists.  This avoids stale
    # hidden UV attributes from previous selections driving the alignment.
    mesh = getattr(obj, "data", None)
    v_attr = _attr_values(mesh, ".uv_select_vert")
    e_attr = _attr_values(mesh, ".uv_select_edge")
    f_attr = _attr_values(mesh, ".uv_select_face")
    for face in bm.faces:
        try:
            fi = _face_index(face)
            loops = list(face.loops)
            if not loops:
                continue
            if mode in {"FACE", "ISLAND"} and 0 <= fi < len(f_attr) and bool(f_attr[fi]):
                selected.add(fi)
                continue
            if mode == "EDGE":
                if all(0 <= _loop_index(loop) < len(e_attr) and bool(e_attr[_loop_index(loop)]) for loop in loops):
                    selected.add(fi)
            else:
                if all(0 <= _loop_index(loop) < len(v_attr) and bool(v_attr[_loop_index(loop)]) for loop in loops):
                    selected.add(fi)
        except Exception:
            pass
    return selected, False


def _edge_uv_pair(loop: Any, uv_layer: Any) -> Tuple[Optional[Tuple[float, float]], Optional[Tuple[float, float]]]:
    try:
        return _uv_key(loop, uv_layer), _uv_key(loop.link_loop_next, uv_layer)
    except Exception:
        return None, None


def _same_edge_uv(a0: Any, a1: Any, b0: Any, b1: Any) -> bool:
    if a0 is None or a1 is None or b0 is None or b1 is None:
        return False
    return (a0 == b0 and a1 == b1) or (a0 == b1 and a1 == b0)


def _collect_islands(context: Any) -> Tuple[List[Dict[str, Any]], List[Any]]:
    import bmesh

    islands: List[Dict[str, Any]] = []
    meshes: List[Any] = []
    for obj in _edit_objects(context):
        try:
            _ensure_unwrap_target(context, obj)
            mesh = getattr(obj, "data", None)
            bm = bmesh.from_edit_mesh(mesh)
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
            uv_layer = _uv_layer_for_bmesh(bm)
            if uv_layer is None:
                continue
        except Exception:
            continue
        meshes.append(mesh)
        selected_faces, _used_live = _collect_selected_face_indices(obj, bm, uv_layer, context)
        faces = [f for f in bm.faces if _face_index(f) in selected_faces]
        if not faces:
            continue
        face_pos = {_face_index(face): i for i, face in enumerate(faces)}
        parent = list(range(len(faces)))
        for edge in bm.edges:
            try:
                linked = [f for f in edge.link_faces if _face_index(f) in selected_faces]
            except Exception:
                linked = []
            if len(linked) < 2:
                continue
            for i in range(len(linked)):
                for j in range(i + 1, len(linked)):
                    fa, fb = linked[i], linked[j]
                    la = next((l for l in fa.loops if l.edge is edge), None)
                    lb = next((l for l in fb.loops if l.edge is edge), None)
                    if la is None or lb is None:
                        continue
                    a0, a1 = _edge_uv_pair(la, uv_layer)
                    b0, b1 = _edge_uv_pair(lb, uv_layer)
                    if _same_edge_uv(a0, a1, b0, b1):
                        _union(parent, face_pos[_face_index(fa)], face_pos[_face_index(fb)])
        grouped: Dict[int, List[Any]] = {}
        order: List[int] = []
        for face in faces:
            root = _find(parent, face_pos[_face_index(face)])
            if root not in grouped:
                grouped[root] = []
                order.append(root)
            grouped[root].append(face)
        for root in order:
            group_faces = grouped.get(root) or []
            loops: List[Any] = []
            for face in group_faces:
                try:
                    loops.extend(list(face.loops))
                except Exception:
                    pass
            if not loops:
                continue
            us = [float(l[uv_layer].uv.x) for l in loops]
            vs = [float(l[uv_layer].uv.y) for l in loops]
            islands.append({
                "obj": obj,
                "mesh": mesh,
                "bm": bm,
                "uv_layer": uv_layer,
                "faces": group_faces,
                "loops": loops,
                "min_u": min(us), "max_u": max(us), "min_v": min(vs), "max_v": max(vs),
                "center_u": (min(us) + max(us)) * 0.5,
                "center_v": (min(vs) + max(vs)) * 0.5,
                "width": max(us) - min(us),
                "height": max(vs) - min(vs),
            })
    return islands, meshes


def _move_island(island: Dict[str, Any], du: float = 0.0, dv: float = 0.0) -> None:
    uv_layer = island.get("uv_layer")
    for loop in island.get("loops") or []:
        try:
            uv = loop[uv_layer].uv
            uv.x += float(du)
            uv.y += float(dv)
        except Exception:
            pass


def _transform_island(island: Dict[str, Any], action: str) -> None:
    uv_layer = island.get("uv_layer")
    cu = float(island.get("center_u", 0.0))
    cv = float(island.get("center_v", 0.0))
    for loop in island.get("loops") or []:
        try:
            uv = loop[uv_layer].uv
            du = float(uv.x) - cu
            dv = float(uv.y) - cv
            if action == "MIRROR_H":
                uv.x = cu - du
            elif action == "MIRROR_V":
                uv.y = cv - dv
            elif action == "ROTATE_CCW":
                uv.x = cu - dv
                uv.y = cv + du
            elif action == "ROTATE_CW":
                uv.x = cu + dv
                uv.y = cv - du
        except Exception:
            pass


def _island_execute(self: Any, context: Any) -> set:
    action = str(getattr(self, "action", "ALIGN_CENTER") or "ALIGN_CENTER").upper()
    if action not in _ALL_ISLAND_ACTIONS:
        action = "ALIGN_CENTER"
    old_active, old_mode, objs, changed_mode = _enter_edit_context(context)
    if not objs:
        try:
            self.report({"WARNING"}, _txt(context, "No mesh object is active.", "アクティブなメッシュオブジェクトがありません。"))
        except Exception:
            pass
        return {"CANCELLED"}
    try:
        _ensure_unwrap_target(context, None)
        islands, meshes = _collect_islands(context)
        if not islands:
            try:
                self.report({"WARNING"}, _txt(context, "No fully selected current UV faces are available for island alignment.", "現在選択されているUV面からアイランド方向整列の対象を取得できません。"))
            except Exception:
                pass
            return {"CANCELLED"}
        min_u = min(float(i["min_u"]) for i in islands)
        max_u = max(float(i["max_u"]) for i in islands)
        min_v = min(float(i["min_v"]) for i in islands)
        max_v = max(float(i["max_v"]) for i in islands)
        center_u = (min_u + max_u) * 0.5
        center_v = (min_v + max_v) * 0.5
        changed = 0
        if action in {"MIRROR_H", "MIRROR_V", "ROTATE_CCW", "ROTATE_CW"}:
            for island in islands:
                _transform_island(island, action)
                changed += 1
        elif action in {"DISTRIBUTE_H", "DISTRIBUTE_V"}:
            axis_u = action == "DISTRIBUTE_H"
            key = (lambda i: float(i.get("center_u", 0.0))) if axis_u else (lambda i: float(i.get("center_v", 0.0)))
            ordered = sorted(islands, key=key)
            if len(ordered) < 2:
                return {"FINISHED"}
            start = key(ordered[0])
            end = key(ordered[-1])
            if abs(end - start) <= 1.0e-12:
                return {"FINISHED"}
            step = (end - start) / float(max(1, len(ordered) - 1))
            for idx, island in enumerate(ordered):
                target = start + step * idx
                if axis_u:
                    _move_island(island, du=target - float(island.get("center_u", 0.0)))
                else:
                    _move_island(island, dv=target - float(island.get("center_v", 0.0)))
                changed += 1
        else:
            for island in islands:
                target_u: Optional[float] = None
                target_v: Optional[float] = None
                if action in {"ALIGN_TL", "ALIGN_LEFT", "ALIGN_BL"}:
                    target_u = min_u + float(island.get("width", 0.0)) * 0.5
                elif action in {"ALIGN_TR", "ALIGN_RIGHT", "ALIGN_BR"}:
                    target_u = max_u - float(island.get("width", 0.0)) * 0.5
                elif action in {"ALIGN_CENTER", "ALIGN_V"}:
                    target_u = center_u
                if action in {"ALIGN_TL", "ALIGN_TOP", "ALIGN_TR"}:
                    target_v = max_v - float(island.get("height", 0.0)) * 0.5
                elif action in {"ALIGN_BL", "ALIGN_BOTTOM", "ALIGN_BR"}:
                    target_v = min_v + float(island.get("height", 0.0)) * 0.5
                elif action in {"ALIGN_CENTER", "ALIGN_H"}:
                    target_v = center_v
                du = 0.0 if target_u is None else float(target_u) - float(island.get("center_u", 0.0))
                dv = 0.0 if target_v is None else float(target_v) - float(island.get("center_v", 0.0))
                if abs(du) > 1.0e-12 or abs(dv) > 1.0e-12:
                    _move_island(island, du=du, dv=dv)
                    changed += 1
        if changed <= 0:
            return {"FINISHED"}
        _update_meshes(meshes)
        return {"FINISHED"}
    except Exception as exc:
        try:
            self.report({"WARNING"}, _txt(context, "Island direction alignment failed.", "アイランド方向整列に失敗しました。") + f" {exc}")
        except Exception:
            pass
        return {"CANCELLED"}
    finally:
        _restore_edit_context(context, old_active, old_mode, changed_mode)


def install(ns: Dict[str, Any], context: Any = None) -> None:
    global _NS
    _NS = ns
    try:
        cls = ns.get("SMARTUVSUITE_OT_vertex_align_action")
        if isinstance(cls, type):
            current = getattr(cls, "execute", None)
            if getattr(cls, _PREV_VERTEX_ATTR, None) is None and callable(current) and current is not _vertex_execute:
                setattr(cls, _PREV_VERTEX_ATTR, current)
            cls.execute = _vertex_execute
    except Exception:
        pass
    try:
        cls = ns.get("SMARTUVSUITE_OT_island_direction_align")
        if isinstance(cls, type):
            current = getattr(cls, "execute", None)
            if getattr(cls, _PREV_ISLAND_ATTR, None) is None and callable(current) and current is not _island_execute:
                setattr(cls, _PREV_ISLAND_ATTR, current)
            cls.execute = _island_execute
    except Exception:
        pass


def apply_all(ns: Dict[str, Any], context: Any = None) -> None:
    install(ns, context)


def unregister() -> None:
    try:
        cls = _NS.get("SMARTUVSUITE_OT_vertex_align_action")
        prev = getattr(cls, _PREV_VERTEX_ATTR, None) if isinstance(cls, type) else None
        if isinstance(cls, type) and callable(prev):
            cls.execute = prev
            try:
                delattr(cls, _PREV_VERTEX_ATTR)
            except Exception:
                pass
    except Exception:
        pass
    try:
        cls = _NS.get("SMARTUVSUITE_OT_island_direction_align")
        prev = getattr(cls, _PREV_ISLAND_ATTR, None) if isinstance(cls, type) else None
        if isinstance(cls, type) and callable(prev):
            cls.execute = prev
            try:
                delattr(cls, _PREV_ISLAND_ATTR)
            except Exception:
                pass
    except Exception:
        pass
