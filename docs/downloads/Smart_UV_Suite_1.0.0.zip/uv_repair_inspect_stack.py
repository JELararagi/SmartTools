"""Implement the inspect stack public UV operations."""


def inspect_stack(context, op, api):
    return api._smart_stack(context, op)



def build_handlers(api):
    return {

        "smart_uv_suite.inspect_stack": api.Handler(lambda context, op: inspect_stack(context, op, api), 'Stack selected islands with matching shapes.', '形状が一致する選択アイランドを重ねます。'),

    }
