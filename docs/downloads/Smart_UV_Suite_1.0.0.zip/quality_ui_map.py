from __future__ import annotations
from . import resource_api_18168 as _suv_resource
from .quality_class_inventory import class_namespace
from . import quality_cards

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None

_NAMESPACE = {}
_REGISTERED = []


def _tr(context, key: str, en: str, ja: str, **fmt) -> str:
    fn = _NAMESPACE.get('tr')
    text = None
    if callable(fn):
        try:
            text = fn(context, key, **fmt)
        except Exception:
            text = None
    if not text:
        text = en
    try:
        return text.format(**fmt)
    except Exception:
        return text


def _text_name(context) -> str:
    ws_fn = _NAMESPACE.get('_suv_ws')
    ws = ws_fn(context) if callable(ws_fn) else None
    name = getattr(ws, 'support_bundle_name', '') if ws else ''
    return (str(name).strip() or 'SUV_Support_Bundle') + '_Visual_UI_Map'


def _suv_ui_map_name(context):
    return _text_name(context)


def _text_block(name: str, clear=False):
    textio = _NAMESPACE.get('_quality_textio_module')
    if textio is not None and hasattr(textio, 'ensure_report_text'):
        try:
            return textio.ensure_report_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if textio is not None and hasattr(textio, 'ensure_namespace_text'):
        try:
            return textio.ensure_namespace_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if bpy is None:
        return None
    txt = bpy.data.texts.get(name)
    if txt is None:
        if not clear:
            return None
        txt = bpy.data.texts.new(name)
    elif clear:
        txt.clear()
    return txt


def scan_ui_map(namespace: dict, context) -> dict:
    translate = lambda ctx, key, en, ja: _tr(ctx, key, en, ja)
    cards_mod = namespace.get('_quality_cards_module') or quality_cards
    namespace = class_namespace(namespace)
    sections = []
    if cards_mod is not None and hasattr(cards_mod, 'build_card_sections'):
        try:
            sections = cards_mod.build_card_sections(namespace, context, translate) or []
        except Exception:
            sections = []
    rows = []
    total_cards = 0
    total_actions = 0
    for section in sections:
        sec_row = {
            'title': str(section.get('title', '') or ''),
            'icon': str(section.get('icon', '') or ''),
            'cards': [],
        }
        for card in section.get('cards', []) or []:
            buttons = []
            for btn in card.get('buttons', []) or []:
                cls = btn.get('cls')
                buttons.append({
                    'text': str(btn.get('text', '') or ''),
                    'icon': str(btn.get('icon', '') or ''),
                    'idname': str(getattr(cls, 'bl_idname', '') or ''),
                    'label': str(getattr(cls, 'bl_label', '') or ''),
                })
            total_cards += 1
            total_actions += len(buttons)
            sec_row['cards'].append({
                'title': str(card.get('title', '') or ''),
                'buttons': buttons,
            })
        rows.append(sec_row)
    data = {
        'sections': len(rows),
        'cards': int(total_cards),
        'actions': int(total_actions),
        'rows': rows,
    }
    namespace['_suv_ui_map_last'] = data
    return data


class SUV_OT_quality_write_ui_map(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_write_ui_map'
    bl_label = 'Write Visual UI Map'
    bl_description = 'Write a compact map of the current visual dashboard sections, cards, and actions so beginners can see where each quick entry lives. / 現在の視覚ダッシュボードのセクション、カード、アクションをまとめたマップを書き出し、初心者でも各クイック入口の場所を把握しやすくします。'
    bl_options = set()

    open_after_write: bpy.props.BoolProperty(
        name='Open After Write',
        description='Open the written visual UI map in Blender Text Editor when possible / 可能なら書き出した視覚UIマップを Blender テキストエディタで開きます',
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        data = scan_ui_map(_NAMESPACE, context)
        txt = None
        lines = [
            'UV Suite Visual UI Map',
            '',
            '[Summary]',
            f"Visible sections: {data['sections']}",
            f"Visible cards: {data['cards']}",
            f"Visible actions: {data['actions']}",
            '',
            '[Sections]',
        ]
        for sec in data['rows']:
            lines.append(f"- {sec['title']}")
            for card in sec['cards']:
                lines.append(f"  * {card['title']}")
                for btn in card['buttons']:
                    label = btn['text'] or btn['label'] or btn['idname'] or '-'
                    lines.append(f"    - {label} :: {btn['idname'] or '-'}")
        lines.extend([
            '',
            '[How to use]',
            '1. Start in Workflow & Setup when the active object, editor, or UV map state still looks incomplete.',
            '2. Use Guides & Language when you want coverage views, help text, or translation checks.',
            '3. Use Reports & Maintenance for audits, registries, generated-data cleanup, and recovery utilities.',
            '',
            '[日本語メモ]',
            f"表示セクション数: {data['sections']}",
            f"表示カード数: {data['cards']}",
            f"表示アクション数: {data['actions']}",
            '最初は「ワークフローと準備」、次に「ガイドと言語」、保守や監査は「レポートと保守」から入ると把握しやすいです。',
        ])
        textio = _NAMESPACE.get('_quality_textio_module')
        writer = getattr(textio, 'write_report_lines_consistent', None) if textio is not None else None
        if callable(writer):
            txt = writer(
                _NAMESPACE, context, _text_name, lines, _text_block, self,
                open_after_write=self.open_after_write,
                failed_key='msg.quality_ui_map_open_failed',
                failed_en='Could not open visual UI map: {name}',
                failed_ja='視覚UIマップを開けませんでした: {name}',
            )
            if txt is None:
                return {'CANCELLED'}
        else:
            txt = _text_block(_text_name(context), clear=True)
            if txt is None:
                return {'CANCELLED'}
            if textio is not None and hasattr(textio, 'write_text_lines'):
                if textio.write_text_lines(txt, lines) is None:
                    return {'CANCELLED'}
            else:
                txt.write('\n'.join(lines))
            if self.open_after_write and textio is not None and hasattr(textio, 'open_written_text'):
                textio.open_written_text(
                    _NAMESPACE, context, txt, self,
                    failed_key='msg.quality_ui_map_open_failed',
                    failed_en='Could not open visual UI map: {name}',
                    failed_ja='視覚UIマップを開けませんでした: {name}',
                )
        self.report({'INFO'}, _tr(context, 'msg.quality_ui_map_written', 'Visual UI map written: {name} ({sections} sections)', '視覚UIマップを書き出しました: {name}（{sections} セクション）', name=txt.name, sections=data['sections']))
        return {'FINISHED'}


class SUV_OT_quality_open_ui_map(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_open_ui_map'
    bl_label = 'Open Visual UI Map'
    bl_description = 'Open the latest UV Suite visual UI map in Blender Text Editor. / 最新の UV Suite 視覚UIマップを Blender のテキストエディタで開きます。'
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        textio = _NAMESPACE.get('_quality_textio_module')
        if textio is not None and hasattr(textio, 'open_named_report_text_or_fallback'):
            return textio.open_named_report_text_or_fallback(
                _NAMESPACE, context, _text_name, self, _text_block,
                missing_key='msg.quality_ui_map_missing',
                missing_en='No visual UI map exists yet.',
                missing_ja='視覚UIマップはまだ作成されていません。',
                opened_key='msg.quality_ui_map_opened',
                opened_en='Opened visual UI map: {name}',
                opened_ja='視覚UIマップを開きました: {name}',
            )
        txt = _text_block(_text_name(context), clear=False)
        if txt is None:
            self.report({'WARNING'}, _tr(context, 'msg.quality_ui_map_missing', 'No visual UI map exists yet.', '視覚UIマップはまだ作成されていません。'))
            return {'CANCELLED'}
        opener = _NAMESPACE.get('_suv_open_text_in_editor')
        ok = False
        if callable(opener):
            try:
                ok, _err = opener(context, txt)
            except Exception:
                ok = False
        if not ok:
            self.report({'WARNING'}, _tr(context, 'msg.quality_ui_map_open_failed', 'Could not open visual UI map: {name}', '視覚UIマップを開けませんでした: {name}', name=txt.name))
            return {'CANCELLED'}
        self.report({'INFO'}, _tr(context, 'msg.quality_ui_map_opened', 'Opened visual UI map: {name}', '視覚UIマップを開きました: {name}', name=txt.name))
        return {'FINISHED'}


def register(namespace: dict):
    global _NAMESPACE
    _NAMESPACE = namespace if isinstance(namespace, dict) else {}
    if bpy is None:
        return []
    classes = [SUV_OT_quality_write_ui_map, SUV_OT_quality_open_ui_map]
    reg = []
    for cls in classes:
        try:
            _suv_resource.register_class(cls)
            reg.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = reg
    return reg


def unregister(namespace: dict | None = None):
    if bpy is None:
        return []
    removed = []
    for cls in reversed(list(_REGISTERED)):
        try:
            _suv_resource.unregister_class(cls)
            removed.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = []
    return removed
