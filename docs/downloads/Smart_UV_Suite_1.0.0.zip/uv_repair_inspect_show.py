"""Implement the inspect show public UV operations."""


def inspect_show_modified_uv_edges_toggle(context, op):
    space = context.space_data
    if context.area is None or context.area.ui_type != 'UV' or space is None:
        return False
    editor = space.uv_editor
    editor.show_modified_edges = not editor.show_modified_edges
    context.area.tag_redraw()
    return True


def build_handlers(api):
    return {
        "smart_uv_suite.inspect_upgrade_capture_session_snapshot": api.Handler(
            api._run_uv_layout("suv_write_tool_runtime_snapshot"),
            "Capture the active mesh, mode, selection summary and UV layer in a session snapshot.",
            "アクティブメッシュ、モード、選択の概要、UVレイヤーをセッションのスナップショットに記録します。"),

        "smart_uv_suite.inspect_show_modified_uv_edges_toggle": api.Handler(inspect_show_modified_uv_edges_toggle, 'Toggle display of modified UV edges.', '変更後のUV辺の表示を切り替えます。'),

    }
