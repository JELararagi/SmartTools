# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""1.8.72 UV Scale-tool background select fallback.

Blender 5.1's UV Scale tool owns the background left-drag through its transform
keymap.  Move/Rotate/Transform tools can fall back to selection-style background
drag behavior in the user's setup, but Scale can remain in resize mode and never
hand the drag to box selection.  This module adds a very narrow fallback only for
UV Scale tool background drags:

- The fallback runs only on the Scale tool's tweak/drag keymap.
- If the pointer is on a UV element or native gizmo, it immediately passes
  through to Blender's normal Scale/gizmo behavior.
- If the pointer is empty UV background, it switches the Image Editor tool to
  Select Box and invokes Blender's native uv.select_box operator.  Selection box
  drawing and final selection remain Blender-owned.
- It does not touch Move/Rotate/Transform tools and does not change Immediate
  Select drag-transform behavior.
"""
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

import bpy

_PG = None
_VERSION = (1, 8, 72)
_SCALE_BG_ID = "smart_uv_suite.scale_tool_background_select"
_INSTANT_ID = "smart_uv_suite.instant_select_drag_move"

_SCALE_KEYMAP_DEFS = (
    ("Image Editor Tool: Uv, Scale", "IMAGE_EDITOR"),
    # Some Blender/keyconfig setups expose a fallback keymap for tools even if the
    # default script does not list one.  Creating it is harmless and makes the
    # behavior robust across user keymap variants.
    ("Image Editor Tool: Uv, Scale (fallback)", "IMAGE_EDITOR"),
)


def _pg(name, default=None):
    try:
        return _PG.get(name, default) if isinstance(_PG, dict) else default
    except Exception:
        return default


def _base():
    try:
        from . import interaction_1871 as b
        return b
    except Exception:
        try:
            from . import interaction_1865 as b
            return b
        except Exception:
            return None


def _is_uv_context(context) -> bool:
    try:
        b = _base()
        fn = getattr(b, "_is_uv_context", None) if b is not None else None
        if callable(fn):
            return bool(fn(context))
    except Exception:
        pass
    try:
        area = getattr(context, "area", None)
        region = getattr(context, "region", None)
        return getattr(area, "type", None) == "IMAGE_EDITOR" and getattr(region, "type", None) == "WINDOW"
    except Exception:
        return False


def _workspace(context):
    try:
        ws_fn = _pg("_sus_1652_ws")
        if callable(ws_fn):
            return ws_fn(context)
    except Exception:
        pass
    try:
        return getattr(getattr(context, "scene", None), "suv_workspace", None)
    except Exception:
        return None


def _interaction_enabled(context) -> bool:
    """Enable this narrow fallback only when an interaction helper is enabled."""
    try:
        ws = _workspace(context)
        if ws is None:
            return False
        return bool(
            getattr(ws, "operation_instant_select_enabled", False)
            or getattr(ws, "operation_uv_gizmo_grip_fix_enabled", False)
            or getattr(ws, "operation_axis_constraint_memory_enabled", False)
        )
    except Exception:
        return False


def _active_uv_tool_id(context) -> str:
    try:
        tool = context.workspace.tools.from_space_image_mode("UV", create=False)
        if tool is not None:
            return str(getattr(tool, "idname", "") or "")
    except Exception:
        pass
    try:
        tool = bpy.context.workspace.tools.from_space_image_mode("UV", create=False)
        if tool is not None:
            return str(getattr(tool, "idname", "") or "")
    except Exception:
        pass
    return ""


def _is_uv_scale_tool(context) -> bool:
    tid = _active_uv_tool_id(context).lower()
    return bool(tid and (tid == "builtin.scale" or tid.endswith(".scale") or "scale" in tid))


def _find_hit(context, event):
    # Reuse the latest optimized hit path.  If it cannot answer, pass through so
    # the Scale tool keeps Blender-native behavior instead of guessing.
    try:
        b = _base()
        fn = getattr(b, "_find_hit", None) if b is not None else None
        if callable(fn):
            return fn(context, event)
    except Exception:
        return None
    return None


def _select_box_mode_from_event(event) -> str:
    try:
        if getattr(event, "ctrl", False):
            return "SUB"
        if getattr(event, "shift", False):
            return "ADD"
    except Exception:
        pass
    return "SET"


def _activate_select_box_tool(context) -> None:
    try:
        bpy.ops.wm.tool_set_by_id(name="builtin.select_box", space_type="IMAGE_EDITOR")
        return
    except Exception:
        pass
    try:
        bpy.ops.wm.tool_set_by_id(name="builtin.select_box")
    except Exception:
        pass


def _invoke_native_uv_select_box(context, event):
    """Invoke native UV box selection without changing the active UV tool."""
    mode = _select_box_mode_from_event(event)
    before_tool = _active_uv_tool_id(context)
    try:
        try:
            result = bpy.ops.uv.select_box("INVOKE_DEFAULT", wait_for_input=False, mode=mode)
        except TypeError:
            result = bpy.ops.uv.select_box("INVOKE_DEFAULT", mode=mode)
        return set(result) if result is not None else {"RUNNING_MODAL"}
    except Exception:
        return {"PASS_THROUGH"}
    finally:
        # Direct operator invocation must not alter the workspace tool.  Restore
        # defensively if a custom keyconfig/operator did so synchronously.
        try:
            after_tool = _active_uv_tool_id(context)
            if before_tool and after_tool and after_tool != before_tool:
                try:
                    bpy.ops.wm.tool_set_by_id(name=before_tool, space_type="IMAGE_EDITOR")
                except TypeError:
                    bpy.ops.wm.tool_set_by_id(name=before_tool)
        except Exception:
            pass


class SMARTUVSUITE_OT_scale_tool_background_select(bpy.types.Operator):
    bl_idname = "smart_uv_suite.scale_tool_background_select"
    bl_label = "Scale Tool Background Select"
    bl_description = "When the UV Scale tool is active, empty-background drag falls back to Blender's native Select Box instead of being swallowed by Scale. / UVスケールツール中、空背景ドラッグをスケールではなくBlender標準のボックス選択へ渡します。"
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return _is_uv_context(context)

    def invoke(self, context, event):
        try:
            if not _interaction_enabled(context):
                return {"PASS_THROUGH"}
            # This operator is installed only in the Scale tool map, but keep an
            # active-tool guard for custom keymaps and stale Blender keymap rows.
            if not _is_uv_scale_tool(context):
                return {"PASS_THROUGH"}
            if str(getattr(event, "type", "") or "") not in {"LEFTMOUSE", "EVT_TWEAK_L"}:
                return {"PASS_THROUGH"}
            # Modified drags should retain Blender's normal add/subtract box
            # selection.  They are handled by select_box below only on background.
            hit = _find_hit(context, event)
            if hit:
                # Any real UV element/gizmo-ish hit belongs to Blender's Scale or
                # native gizmo handling.  Do not intercept.
                return {"PASS_THROUGH"}
            return _invoke_native_uv_select_box(context, event)
        except Exception:
            return {"PASS_THROUGH"}


def _addon_keyconfig():
    try:
        return bpy.context.window_manager.keyconfigs.addon
    except Exception:
        return None


def _find_kmis(km, idname: str):
    try:
        from . import ownership_runtime_18168 as _own
        return [kmi for keymap, kmi in _own.owned_keymap_items(idname) if keymap is km]
    except Exception:
        return []


def _get_keymap(kc, name: str, space_type: str):
    try:
        km = kc.keymaps.get(name)
        if km is None:
            km = kc.keymaps.new(name=name, space_type=space_type, region_type="WINDOW")
        return km
    except Exception:
        return None


def _configure_scale_bg_kmi(kmi, active=True) -> None:
    # Configure only a newly-created or ledger-owned KeyMapItem.
    for name, value in (("type", "EVT_TWEAK_L"), ("value", "ANY"), ("shift", False), ("ctrl", False), ("alt", False), ("oskey", False), ("hyper", False), ("any", False)):
        try:
            _suv_resource.keymap_item_set(kmi, name, value)
        except Exception:
            pass
    try:
        from . import ownership_runtime_18168 as _ownership
        _ownership.set_keymap_item_active(kmi, bool(active))
    except Exception:
        pass


def _ensure_scale_background_keymaps(active=True):
    kc = _addon_keyconfig()
    if kc is None:
        return (0, 0)
    created = touched = 0
    for name, space in _SCALE_KEYMAP_DEFS:
        km = _get_keymap(kc, name, space)
        if km is None:
            continue
        items = list(_find_kmis(km, _SCALE_BG_ID))
        if not items:
            try:
                kmi = __import__(__package__ + '.ownership_runtime_18168', fromlist=['new_keymap_item']).new_keymap_item(km, _SCALE_BG_ID, type="EVT_TWEAK_L", value="ANY", head=True)
            except TypeError:
                try:
                    kmi = __import__(__package__ + '.ownership_runtime_18168', fromlist=['new_keymap_item']).new_keymap_item(km, _SCALE_BG_ID, type="EVT_TWEAK_L", value="ANY")
                except Exception:
                    kmi = __import__(__package__ + '.ownership_runtime_18168', fromlist=['new_keymap_item']).new_keymap_item(km, _SCALE_BG_ID, type="LEFTMOUSE", value="CLICK_DRAG")
            try:
                from . import ownership_runtime_18168 as _own
                _own.track_keymap_item(km, kmi, _SCALE_BG_ID)
            except Exception:
                pass
            items = [kmi]
            created += 1
        for kmi in items:
            _configure_scale_bg_kmi(kmi, active=active)
            touched += 1
    return (created, touched)


def _set_scale_background_active(active: bool):
    try:
        from . import ownership_runtime_18168 as _ownership
        if bool(active):
            return _ensure_scale_background_keymaps(True)
        return (_ownership.remove_owned_keymaps(_SCALE_BG_ID), 0)
    except Exception:
        return (0, 0)


def _delete_scale_background_keymaps():
    try:
        from . import ownership_runtime_18168 as _own
        return _own.remove_owned_keymaps(_SCALE_BG_ID)
    except Exception:
        return 0


def _scale_background_status():
    kc = _addon_keyconfig()
    expected = len(_SCALE_KEYMAP_DEFS)
    registered = active = 0
    if kc is not None:
        for name, _space in _SCALE_KEYMAP_DEFS:
            try:
                km = kc.keymaps.get(name)
                items = _find_kmis(km, _SCALE_BG_ID) if km is not None else []
                if items:
                    registered += 1
                    if any(bool(getattr(kmi, "active", False)) for kmi in items):
                        active += 1
            except Exception:
                pass
    return {"expected": expected, "registered": registered, "active": active}


def _patch_keymap_info():
    if not isinstance(_PG, dict):
        return
    old_rows = _PG.get("_sus_1652_public_keymap_rows")
    old_action = _PG.get("_sus_1652_apply_keymap_action")
    old_exec_cls = _PG.get("SMARTUVSUITE_OT_keymap_info_action")
    fmt = _PG.get("_sus_1652_format_status")
    txt = _PG.get("_sus_text")

    def public_rows(context=None):
        rows = []
        try:
            if callable(old_rows):
                rows = list(old_rows(context))
        except Exception:
            rows = []
        try:
            rows = [r for r in rows if str((r or {}).get("id", "")).upper() != "SCALE_BG_SELECT"]
        except Exception:
            pass
        try:
            en, ja = ("", "")
            if callable(fmt):
                en, ja = fmt(context or bpy.context, _scale_background_status())
            else:
                st = _scale_background_status()
                en = ja = f"{st.get('active',0)}/{st.get('expected',0)}"
            rows.append({
                "id": "SCALE_BG_SELECT",
                "feature_en": "Scale Tool Background Select",
                "feature_ja": "スケールツール背景選択",
                "operator": _SCALE_BG_ID,
                "location_en": "Preferences > Keymap > Image Editor Tool: Uv, Scale",
                "location_ja": "プリファレンス > キーマップ > Image Editor Tool: Uv, Scale",
                "detail_en": "Input: Left Drag / Tweak\nKeymaps:\n" + "\n".join(name for name, _ in _SCALE_KEYMAP_DEFS),
                "detail_ja": "入力: 左ドラッグ / Tweak\nキーマップ名:\n" + "\n".join(name for name, _ in _SCALE_KEYMAP_DEFS),
                "status_en": en,
                "status_ja": ja,
            })
        except Exception:
            pass
        return rows

    def apply_action(context, target: str, action: str):
        target = str(target or "").upper(); action = str(action or "").upper()
        if target == "SCALE_BG_SELECT":
            if action in {"REGISTER", "ENABLE"}:
                return {"created_touched": _ensure_scale_background_keymaps(True)}
            if action == "DISABLE":
                return {"disabled": _set_scale_background_active(False)}
            if action == "DELETE":
                return {"removed": _delete_scale_background_keymaps()}
        if callable(old_action):
            return old_action(context, target, action)
        return {}

    _PG["_sus_1652_public_keymap_rows"] = public_rows
    _PG["_sus_1652_apply_keymap_action"] = apply_action
    try:
        if isinstance(old_exec_cls, type):
            def execute(self, context):
                target = str(getattr(self, "target", "") or "").upper()
                action = str(getattr(self, "action", "REGISTER") or "REGISTER").upper()
                valid = {"INSTANT_SELECT", "UV_GIZMO_GRIP", "SCALE_BG_SELECT"}
                if target not in valid or action not in {"REGISTER", "DELETE", "ENABLE", "DISABLE"}:
                    self.report({"WARNING"}, (txt("Invalid keymap action.", "無効なキーマップ操作です。", context) if callable(txt) else "Invalid keymap action."))
                    return {"CANCELLED"}
                apply_action(context, target, action)
                self.report({"INFO"}, (txt("Keymap state updated.", "キーマップ状態を更新しました。", context) if callable(txt) else "Keymap state updated."))
                return {"FINISHED"}
            old_exec_cls.execute = execute
    except Exception:
        pass


def _register_operator_class():
    try:
        cls = SMARTUVSUITE_OT_scale_tool_background_select
        if bool(getattr(cls, 'is_registered', False)) or getattr(cls, '__dict__', {}).get('bl_rna') is not None:
            return
    except Exception:
        pass
    try:
        __import__(__package__ + '.ownership_runtime_18168', fromlist=['register_class']).register_class(SMARTUVSUITE_OT_scale_tool_background_select)
    except ValueError:
        pass
    except RuntimeError:
        pass
    except Exception:
        pass


def _unregister_operator_class():
    try:
        __import__(__package__ + '.ownership_runtime_18168', fromlist=['unregister_class']).unregister_class(SMARTUVSUITE_OT_scale_tool_background_select)
    except Exception:
        pass


def _should_enable_scale_fallback(context) -> bool:
    return _interaction_enabled(context)


def apply_all(pkg_globals=None, context=None):
    global _PG
    if pkg_globals is not None:
        _PG = pkg_globals
    ctx = context or bpy.context
    try:
        if isinstance(_PG, dict):
            bi = _PG.get("bl_info")
            if isinstance(bi, dict):
                bi["version"] = (1, 0, 0)
            _PG["__version__"] = '1.0.0'
            _PG["_sus_1872_scale_bg_select_status"] = _scale_background_status
            _PG["_sus_1872_scale_bg_select_enable"] = _ensure_scale_background_keymaps
            _PG["_sus_1872_scale_bg_select_disable"] = _set_scale_background_active
            _PG["_sus_1872_scale_bg_select_delete"] = _delete_scale_background_keymaps
    except Exception:
        pass
    _register_operator_class()
    _patch_keymap_info()
    try:
        if _should_enable_scale_fallback(ctx):
            _ensure_scale_background_keymaps(True)
        else:
            _set_scale_background_active(False)
    except Exception:
        pass


def install(pkg_globals):
    global _PG
    _PG = pkg_globals
    apply_all(pkg_globals, bpy.context)


def unregister():
    _delete_scale_background_keymaps()
    _unregister_operator_class()


# Smart UV Suite 1.8.169: restore the previous UV active tool after the native
# Scale background-select handoff has been invoked.
def _sus_18166_restore_uv_tool(context, tool_id: str) -> None:
    tool_id = str(tool_id or '').strip()
    if not tool_id:
        return
    try:
        bpy.ops.wm.tool_set_by_id(name=tool_id, space_type='IMAGE_EDITOR')
        return
    except Exception:
        pass
    try:
        bpy.ops.wm.tool_set_by_id(name=tool_id)
    except Exception:
        pass


def _sus_18166_scale_bg_invoke(self, context, event):
    previous_tool = _active_uv_tool_id(context)
    try:
        if not _interaction_enabled(context):
            return {"PASS_THROUGH"}
        if not _is_uv_scale_tool(context):
            return {"PASS_THROUGH"}
        if str(getattr(event, "type", "") or "") not in {"LEFTMOUSE", "EVT_TWEAK_L"}:
            return {"PASS_THROUGH"}
        hit = _find_hit(context, event)
        if hit:
            return {"PASS_THROUGH"}
        return _invoke_native_uv_select_box(context, event)
    except Exception:
        return {"PASS_THROUGH"}
    finally:
        _sus_18166_restore_uv_tool(context, previous_tool)

try:
    SMARTUVSUITE_OT_scale_tool_background_select.invoke = _sus_18166_scale_bg_invoke
except Exception:
    pass
