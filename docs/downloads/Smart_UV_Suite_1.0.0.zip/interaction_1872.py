# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Select UVs from an empty Scale-tool background without changing the tool."""
from __future__ import annotations
from . import ownership_runtime_18168 as _ownership
from . import resource_api_18168 as _suv_resource

import time

import bpy

_PG = None
_scale_background_requested = True
_VERSION = (1, 8, 72)
_SCALE_BG_ID = "smart_uv_suite.scale_tool_background_select"
_INSTANT_ID = "smart_uv_suite.instant_select_drag_move"

_SCALE_KEYMAP_DEFS = (("Image Editor Tool: Uv, Scale", "IMAGE_EDITOR"),)
_SELECTION_MODIFIERS = ((False, False), (True, False), (False, True))
# PRESS is held only on the background so a keymap whose Resize starts on PRESS
# (instead of CLICK_DRAG) cannot swallow the drag before it becomes a selection.
_SCALE_BG_VALUES = ("CLICK_DRAG", "PRESS")
_LAST_PRESS_PASS = {"key": None, "t": 0.0}


def _base():
    try:
        from . import interaction_1871 as b
        return b
    except Exception:
        try:
            from . import interaction_1865 as b
            return b
        except Exception:
            return None


def _is_uv_context(context) -> bool:
    try:
        b = _base()
        fn = getattr(b, "_is_uv_context", None) if b is not None else None
        if callable(fn):
            return bool(fn(context))
    except Exception:
        pass
    try:
        area = getattr(context, "area", None)
        region = getattr(context, "region", None)
        return getattr(area, "type", None) == "IMAGE_EDITOR" and getattr(region, "type", None) == "WINDOW"
    except Exception:
        return False


def _active_uv_tool_id(context) -> str:
    try:
        tool = context.workspace.tools.from_space_image_mode("UV", create=False)
        if tool is not None:
            return str(getattr(tool, "idname", "") or "")
    except Exception:
        pass
    try:
        tool = bpy.context.workspace.tools.from_space_image_mode("UV", create=False)
        if tool is not None:
            return str(getattr(tool, "idname", "") or "")
    except Exception:
        pass
    return ""


def _is_uv_scale_tool(context) -> bool:
    return _active_uv_tool_id(context) == "builtin.scale"


def _active_uv_fallback_id(context) -> str:
    for ctx in (context, bpy.context):
        try:
            tool = ctx.workspace.tools.from_space_image_mode("UV", create=False)
            if tool is not None:
                return str(getattr(tool, "idname_fallback", "") or "")
        except Exception:
            pass
    return ""


class _DragOrigin:
    def __init__(self, context, event):
        self.mouse_region_x = event.mouse_prev_press_x - context.region.x
        self.mouse_region_y = event.mouse_prev_press_y - context.region.y


def _find_hit(context, event):
    # Judge the press origin of this CLICK_DRAG with the same live scan as PRESS.
    o = _DragOrigin(context, event)
    return _scan_on_element(context, o.mouse_region_x, o.mouse_region_y) is not False


class _RegionPoint:
    def __init__(self, x, y):
        self.mouse_region_x = x
        self.mouse_region_y = y


def _press_key(context, event):
    region = getattr(context, "region", None)
    return (region.as_pointer() if region is not None else 0, int(event.mouse_x), int(event.mouse_y),
            bool(event.shift), bool(event.ctrl), bool(event.alt))


def _press_already_passed(context, event) -> bool:
    # Several keymap rows may call this operator for the same PRESS; judge it once.
    try:
        return (_LAST_PRESS_PASS["key"] == _press_key(context, event)
                and time.monotonic() - float(_LAST_PRESS_PASS["t"]) < 0.05)
    except Exception:
        return False


def _remember_press_pass(context, event) -> None:
    try:
        _LAST_PRESS_PASS["key"] = _press_key(context, event)
        _LAST_PRESS_PASS["t"] = time.monotonic()
    except Exception:
        pass


def _kmi_matches_press(kmi, event) -> bool:
    if kmi.type != event.type or kmi.value not in {"PRESS", "ANY"}:
        return False
    if getattr(kmi, "key_modifier", "NONE") not in {"NONE", ""}:
        return False
    if kmi.any:
        return True
    for name in ("shift", "ctrl", "alt", "oskey", "hyper"):
        want = int(getattr(kmi, name, 0) or 0)
        if want != -1 and bool(want) != bool(getattr(event, name, False)):
            return False
    return True


def _tool_takes_press(context, event) -> bool:
    """True when another active Scale-tool item starts on this PRESS (e.g. Resize mapped to PRESS)."""
    try:
        kc = context.window_manager.keyconfigs.user
        for name, _space in _SCALE_KEYMAP_DEFS:
            km = kc.keymaps.get(name)
            if km is None:
                continue
            for kmi in km.keymap_items:
                if kmi.idname != _SCALE_BG_ID and kmi.active and _kmi_matches_press(kmi, event):
                    return True
        return False
    except Exception:
        return True


def _i44():
    try:
        from . import interaction_1844 as m
        if not isinstance(getattr(m, "_PG", None), dict) and isinstance(_PG, dict):
            m._PG = _PG
        return m
    except Exception:
        return None


def _scan_on_element(context, x, y):
    """Scan the edit-mesh UVs at region point (x, y) with the 1844 hit rules.

    True on a UV element, False on the background, None when it cannot be judged.
    The shared hit cache is not used here: it is empty after a zoom and keeps the
    old positions after a native transform, so it can misjudge the press point.
    """
    try:
        import bmesh
        m = _i44()
        if m is None:
            return None
        p = m._region_to_uv(context, _RegionPoint(x, y))
        if p is None:
            return None
        mode = m._uv_mode(context)
        tol = float(m._uv_tolerance(context, 10.0))
        px, py = float(p.x), float(p.y)
        for obj in m._iter_edit_mesh_objects(context):
            mesh = getattr(obj, "data", None)
            if mesh is None:
                continue
            bm = bmesh.from_edit_mesh(mesh)
            uvl = bm.loops.layers.uv.active
            if uvl is None:
                continue
            for f in bm.faces:
                if f.hide:
                    continue
                if mode not in {"VERTEX", "EDGE"}:
                    coords = [l[uvl].uv for l in f.loops if not (l.vert.hide or l.edge.hide)]
                    if len(coords) < 3:
                        continue
                    if (px < min(c.x for c in coords) or px > max(c.x for c in coords)
                            or py < min(c.y for c in coords) or py > max(c.y for c in coords)):
                        continue
                    if m._point_in_poly(p, coords):
                        return True
                    continue
                for l in f.loops:
                    if l.vert.hide or l.edge.hide:
                        continue
                    a = l[uvl].uv
                    if mode == "EDGE":
                        b = l.link_loop_next[uvl].uv
                        if (px < min(a.x, b.x) - tol or px > max(a.x, b.x) + tol
                                or py < min(a.y, b.y) - tol or py > max(a.y, b.y) + tol):
                            continue
                        if m._point_segment_distance(p, a, b)[0] <= tol:
                            return True
                    elif abs(a.x - px) <= tol and abs(a.y - py) <= tol and (a - p).length <= tol:
                        return True
        return False
    except Exception:
        return None


def _press_on_element(context, event):
    """True on a UV element, False on the background, None when it cannot be judged."""
    return _scan_on_element(context, event.mouse_region_x, event.mouse_region_y)


class SMARTUVSUITE_OT_scale_tool_background_select(bpy.types.Operator):
    bl_idname = "smart_uv_suite.scale_tool_background_select"
    bl_label = "Scale Tool Background Select"
    bl_description = "When the UV Scale tool is active, empty-background drag falls back to Blender's native Select Box instead of being swallowed by Scale. / UVスケールツール中、空背景ドラッグをスケールではなくスケールツールのまま、ドラッグの範囲でUVを選択します。"
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return _is_uv_context(context)

    def invoke(self, context, event):
        if event.type == "LEFTMOUSE" and event.value == "PRESS":
            return self._invoke_press(context, event)
        if event.type != "LEFTMOUSE" or event.value != "CLICK_DRAG" or not _is_uv_scale_tool(context):
            return {"PASS_THROUGH"}
        # Behave like the Move and Rotate tools: a background drag becomes a box
        # select only when the drag fallback is Select Box. Every other fallback
        # (Tweak, Lasso, Circle) keeps Blender's native result.
        if _active_uv_fallback_id(context) != "builtin.select_box":
            return {"PASS_THROUGH"}
        if _find_hit(context, event):
            return {"PASS_THROUGH"}
        if not bpy.ops.uv.select_box.poll():
            return {"PASS_THROUGH"}
        # The Python operator receives CLICK_DRAG, but bpy.ops.invoke uses the
        # current window event. Keep this event's press origin through release.
        self._origin = (event.mouse_prev_press_x - context.region.x,
                        event.mouse_prev_press_y - context.region.y)
        self._end = (event.mouse_region_x, event.mouse_region_y)
        self._mode = "SUB" if event.ctrl else "ADD" if event.shift else "SET"
        self._region = context.region.as_pointer()
        self._draw_handle = _suv_resource.draw_handler_add(
            bpy.types.SpaceImageEditor, self._draw_box, (), "WINDOW", "POST_PIXEL"
        )
        context.window_manager.modal_handler_add(self)
        context.area.tag_redraw()
        return {"RUNNING_MODAL"}

    def _invoke_press(self, context, event):
        # Hold a background PRESS only when another Scale-tool item would start on it.
        # RUNNING_MODAL|PASS_THROUGH stops the PRESS here, but Blender still counts it as
        # unhandled, so the CLICK or CLICK_DRAG that follows reaches the select keymaps.
        try:
            if not _is_uv_scale_tool(context) or _press_already_passed(context, event):
                return {"PASS_THROUGH"}
            if (not _tool_takes_press(context, event) or not bpy.ops.uv.select_box.poll()
                    or _press_on_element(context, event) is not False):
                _remember_press_pass(context, event)
                return {"PASS_THROUGH"}
            self._hold = True
            self._draw_handle = None
            context.window_manager.modal_handler_add(self)
            return {"RUNNING_MODAL", "PASS_THROUGH"}
        except Exception:
            return {"PASS_THROUGH"}

    def modal(self, context, event):
        if getattr(self, "_hold", False):
            # Release the held PRESS on the next event; it is passed on untouched.
            return {"CANCELLED", "PASS_THROUGH"}
        if (context.region is None or context.region.as_pointer() != self._region
                or not _is_uv_scale_tool(context) or not bpy.ops.uv.select_box.poll()
                or event.type in {"ESC", "RIGHTMOUSE", "WINDOW_DEACTIVATE"}):
            self.cancel(context)
            return {"CANCELLED"}
        if event.type == "LEFTMOUSE" and event.value == "RELEASE":
            x0, y0 = self._origin
            x1, y1 = event.mouse_region_x, event.mouse_region_y
            self.cancel(context)
            return bpy.ops.uv.select_box(
                "EXEC_DEFAULT", mode=self._mode, xmin=min(x0, x1), xmax=max(x0, x1),
                ymin=min(y0, y1), ymax=max(y0, y1)
            )
        if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
            self._end = (event.mouse_region_x, event.mouse_region_y)
            context.area.tag_redraw()
        return {"RUNNING_MODAL"}

    def cancel(self, context):
        handle = getattr(self, "_draw_handle", None)
        if handle is not None:
            _ownership.remove_draw_handler(handle)
            self._draw_handle = None
        area = getattr(context, "area", None)
        if area is not None:
            area.tag_redraw()

    def _draw_box(self):
        import gpu
        from gpu_extras.batch import batch_for_shader

        region = bpy.context.region
        if region is None or region.as_pointer() != self._region:
            return
        x0, y0 = self._origin
        x1, y1 = self._end
        outline = ((x0, y0), (x1, y0), (x1, y1), (x0, y1), (x0, y0))
        shader = gpu.shader.from_builtin("UNIFORM_COLOR")
        shader.bind()
        shader.uniform_float("color", (0.85, 0.85, 0.85, 1.0))
        batch_for_shader(shader, "LINE_STRIP", {"pos": outline}).draw(shader)


def _addon_keyconfig():
    try:
        return bpy.context.window_manager.keyconfigs.addon
    except Exception:
        return None


def _find_kmis(km, idname: str):
    try:
        from . import ownership_runtime_18168 as _own
        return [kmi for keymap, kmi in _own.owned_keymap_items(idname) if keymap == km]
    except Exception:
        return []


def _get_keymap(kc, name: str, space_type: str):
    try:
        km = kc.keymaps.get(name)
        if km is None:
            km = kc.keymaps.new(name=name, space_type=space_type, region_type="WINDOW")
        return km
    except Exception:
        return None


def _sync_scale_background_keymaps():
    if not _scale_background_requested:
        return (0, 0)
    kc = _addon_keyconfig()
    if kc is None:
        return (0, 0)
    created = touched = 0
    for name, space in _SCALE_KEYMAP_DEFS:
        km = _get_keymap(kc, name, space)
        if km is None:
            continue
        items = {(str(item.value), bool(item.shift), bool(item.ctrl)): item
                 for item in _find_kmis(km, _SCALE_BG_ID)}
        for value in _SCALE_BG_VALUES:
            for shift, ctrl in _SELECTION_MODIFIERS:
                item = items.get((value, shift, ctrl))
                if item is None:
                    _ownership.new_keymap_item(
                        km, _SCALE_BG_ID, type="LEFTMOUSE", value=value, shift=shift, ctrl=ctrl, head=True
                    )
                    created += 1
                else:
                    touched += 1
    return (created, touched)


def _ensure_scale_background_keymaps(active=True):
    return _set_scale_background_active(active)


def _set_scale_background_active(active):
    global _scale_background_requested
    _scale_background_requested = bool(active)
    if _scale_background_requested:
        return _sync_scale_background_keymaps()
    return (_ownership.remove_owned_keymaps(_SCALE_BG_ID), 0)


def _delete_scale_background_keymaps():
    return _set_scale_background_active(False)[0]


def _scale_background_status():
    kc = _addon_keyconfig()
    expected = len(_SCALE_KEYMAP_DEFS)
    registered = active = 0
    if kc is not None:
        for name, _space in _SCALE_KEYMAP_DEFS:
            try:
                km = kc.keymaps.get(name)
                items = _find_kmis(km, _SCALE_BG_ID) if km is not None else []
                if items:
                    registered += 1
                    if any(bool(getattr(kmi, "active", False)) for kmi in items):
                        active += 1
            except Exception:
                pass
    return {"expected": expected, "registered": registered, "active": active}


def _patch_keymap_info():
    if not isinstance(_PG, dict):
        return
    old_rows = _PG.get("_sus_1652_public_keymap_rows")
    old_action = _PG.get("_sus_1652_apply_keymap_action")
    old_exec_cls = _PG.get("SMARTUVSUITE_OT_keymap_info_action")
    fmt = _PG.get("_sus_1652_format_status")
    txt = _PG.get("_sus_text")

    def public_rows(context=None):
        rows = []
        try:
            if callable(old_rows):
                rows = list(old_rows(context))
        except Exception:
            rows = []
        try:
            rows = [r for r in rows if str((r or {}).get("id", "")).upper() != "SCALE_BG_SELECT"]
        except Exception:
            pass
        try:
            en, ja = ("", "")
            if callable(fmt):
                en, ja = fmt(context or bpy.context, _scale_background_status())
            else:
                st = _scale_background_status()
                en = ja = f"{st.get('active',0)}/{st.get('expected',0)}"
            rows.append({
                "id": "SCALE_BG_SELECT",
                "feature_en": "Scale Tool Background Select",
                "feature_ja": "スケールツール背景選択",
                "operator": _SCALE_BG_ID,
                "location_en": "Preferences > Keymap > Image Editor Tool: Uv, Scale",
                "location_ja": "プリファレンス > キーマップ > Image Editor Tool: Uv, Scale",
                "detail_en": "Input: Left Drag\nKeymaps:\n" + "\n".join(name for name, _ in _SCALE_KEYMAP_DEFS),
                "detail_ja": "入力: 左ドラッグ\nキーマップ名:\n" + "\n".join(name for name, _ in _SCALE_KEYMAP_DEFS),
                "status_en": en,
                "status_ja": ja,
            })
        except Exception:
            pass
        return rows

    def apply_action(context, target: str, action: str):
        target = str(target or "").upper(); action = str(action or "").upper()
        if target == "SCALE_BG_SELECT":
            if action in {"REGISTER", "ENABLE"}:
                return {"created_touched": _ensure_scale_background_keymaps(True)}
            if action == "DISABLE":
                return {"disabled": _set_scale_background_active(False)}
            if action == "DELETE":
                return {"removed": _delete_scale_background_keymaps()}
        if callable(old_action):
            return old_action(context, target, action)
        return {}

    _PG["_sus_1652_public_keymap_rows"] = public_rows
    _PG["_sus_1652_apply_keymap_action"] = apply_action
    try:
        if isinstance(old_exec_cls, type):
            def execute(self, context):
                target = str(getattr(self, "target", "") or "").upper()
                action = str(getattr(self, "action", "REGISTER") or "REGISTER").upper()
                valid = {"INSTANT_SELECT", "UV_GIZMO_GRIP", "SCALE_BG_SELECT"}
                if target not in valid or action not in {"REGISTER", "DELETE", "ENABLE", "DISABLE"}:
                    self.report({"WARNING"}, (txt("Invalid keymap action.", "無効なキーマップ操作です。", context) if callable(txt) else "Invalid keymap action."))
                    return {"CANCELLED"}
                apply_action(context, target, action)
                self.report({"INFO"}, (txt("Keymap state updated.", "キーマップ状態を更新しました。", context) if callable(txt) else "Keymap state updated."))
                return {"FINISHED"}
            old_exec_cls.execute = execute
    except Exception:
        pass


def _pointer_over_main_region(area, region, x, y) -> bool:
    """True when window point (x, y) is on the UV view itself, not on a sidebar or header."""
    try:
        if not (region.x <= x < region.x + region.width and region.y <= y < region.y + region.height):
            return False
        for other in area.regions:
            if other.type == "WINDOW" or other.width <= 1 or other.height <= 1:
                continue
            if other.x <= x < other.x + other.width and other.y <= y < other.y + other.height:
                return False
        return True
    except Exception:
        return False


def _selected_uv_pointer_target(context, region):
    """Window point of the selected UV vertex nearest the selection centre, or None."""
    try:
        import bmesh
        m = _i44()
        objects = list(m._iter_edit_mesh_objects(context)) if m is not None else []
        if not objects and getattr(context, "edit_object", None) is not None:
            objects = [context.edit_object]
        sync = bool(getattr(context.tool_settings, "use_uv_select_sync", False))
        points = {}
        for obj in objects:
            mesh = getattr(obj, "data", None)
            if mesh is None or getattr(obj, "type", None) != "MESH":
                continue
            bm = bmesh.from_edit_mesh(mesh)
            uvl = bm.loops.layers.uv.active
            if uvl is None:
                continue
            for f in bm.faces:
                if f.hide or (not sync and not f.select):
                    continue
                for l in f.loops:
                    if l.vert.select if sync else l.uv_select_vert:
                        uv = l[uvl].uv
                        points[(round(uv.x, 6), round(uv.y, 6))] = (float(uv.x), float(uv.y))
        if not points:
            return None
        cx = sum(p[0] for p in points.values()) / len(points)
        cy = sum(p[1] for p in points.values()) / len(points)
        u, v = min(points.values(), key=lambda p: (p[0] - cx) ** 2 + (p[1] - cy) ** 2)
        rx, ry = region.view2d.view_to_region(u, v, clip=False)
        rx = min(max(int(rx), 2), max(int(region.width) - 3, 2))
        ry = min(max(int(ry), 2), max(int(region.height) - 3, 2))
        return int(region.x) + rx, int(region.y) + ry
    except Exception:
        return None


class SMARTUVSUITE_OT_uv_vertex_slide(bpy.types.Operator):
    bl_idname = "smart_uv_suite.uv_vertex_slide"
    bl_label = "Vertex Slide"
    bl_description = (
        "Slide the selected UV vertices along their connected UV edges. When started from the "
        "sidebar, the pointer first moves onto a selected vertex so the slide follows the "
        "direction you move it")
    bl_options = {'INTERNAL'}

    @classmethod
    def poll(cls, context):
        area = getattr(context, "area", None)
        return getattr(context, "mode", "") == "EDIT_MESH" and getattr(area, "type", "") == "IMAGE_EDITOR"

    def invoke(self, context, event):
        area = context.area
        region = next((r for r in area.regions if r.type == "WINDOW"), None)
        if region is None:
            return {'CANCELLED'}
        # Vertex Slide picks the edge from the pointer's motion since the slide started, so a
        # start on the sidebar made every slide follow the edge pointing back at the sidebar.
        if not _pointer_over_main_region(area, region, event.mouse_x, event.mouse_y):
            target = _selected_uv_pointer_target(context, region)
            if target is not None:
                try:
                    context.window.cursor_warp(target[0], target[1])
                except Exception:
                    pass
        try:
            with context.temp_override(area=area, region=region):
                result = bpy.ops.transform.vert_slide('INVOKE_DEFAULT')
        except Exception as exc:
            self.report({'WARNING'}, str(exc))
            return {'CANCELLED'}
        return {'FINISHED'} if ({'RUNNING_MODAL', 'FINISHED'} & set(result)) else {'CANCELLED'}


_OPERATOR_CLASSES = (SMARTUVSUITE_OT_scale_tool_background_select, SMARTUVSUITE_OT_uv_vertex_slide)


def _register_operator_class():
    for cls in _OPERATOR_CLASSES:
        try:
            if bool(getattr(cls, 'is_registered', False)) or getattr(cls, '__dict__', {}).get('bl_rna') is not None:
                continue
        except Exception:
            pass
        try:
            __import__(__package__ + '.ownership_runtime_18168', fromlist=['register_class']).register_class(cls)
        except ValueError:
            pass
        except RuntimeError:
            pass
        except Exception:
            pass


def _unregister_operator_class():
    for cls in reversed(_OPERATOR_CLASSES):
        try:
            __import__(__package__ + '.ownership_runtime_18168', fromlist=['unregister_class']).unregister_class(cls)
        except Exception:
            pass


def apply_all(pkg_globals=None, context=None):
    global _PG
    if pkg_globals is not None:
        _PG = pkg_globals
    try:
        if isinstance(_PG, dict):
            bi = _PG.get("bl_info")
            if isinstance(bi, dict):
                bi["version"] = (1, 0, 0)
            _PG["__version__"] = '1.0.0'
            _PG["_sus_1872_scale_bg_select_status"] = _scale_background_status
            _PG["_sus_1872_scale_bg_select_enable"] = _ensure_scale_background_keymaps
            _PG["_sus_1872_scale_bg_select_disable"] = _set_scale_background_active
            _PG["_sus_1872_scale_bg_select_delete"] = _delete_scale_background_keymaps
    except Exception:
        pass
    _register_operator_class()
    _patch_keymap_info()
    _sync_scale_background_keymaps()


def install(pkg_globals):
    global _PG
    _PG = pkg_globals
    apply_all(pkg_globals, bpy.context)


def unregister():
    # Keep _scale_background_requested: disable/enable reuses this module object, and
    # clearing the flag here left Scale-tool background selection off after re-enabling.
    try:
        _ownership.remove_owned_keymaps(_SCALE_BG_ID)
    except Exception:
        pass
    _unregister_operator_class()


