# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Select UVs from an empty Scale-tool background without changing the tool."""
from __future__ import annotations
from . import ownership_runtime_18168 as _ownership
from . import resource_api_18168 as _suv_resource

import bpy

_PG = None
_scale_background_requested = True
_VERSION = (1, 8, 72)
_SCALE_BG_ID = "smart_uv_suite.scale_tool_background_select"
_INSTANT_ID = "smart_uv_suite.instant_select_drag_move"

_SCALE_KEYMAP_DEFS = (("Image Editor Tool: Uv, Scale", "IMAGE_EDITOR"),)
_SELECTION_MODIFIERS = ((False, False), (True, False), (False, True))


def _base():
    try:
        from . import interaction_1871 as b
        return b
    except Exception:
        try:
            from . import interaction_1865 as b
            return b
        except Exception:
            return None


def _is_uv_context(context) -> bool:
    try:
        b = _base()
        fn = getattr(b, "_is_uv_context", None) if b is not None else None
        if callable(fn):
            return bool(fn(context))
    except Exception:
        pass
    try:
        area = getattr(context, "area", None)
        region = getattr(context, "region", None)
        return getattr(area, "type", None) == "IMAGE_EDITOR" and getattr(region, "type", None) == "WINDOW"
    except Exception:
        return False


def _active_uv_tool_id(context) -> str:
    try:
        tool = context.workspace.tools.from_space_image_mode("UV", create=False)
        if tool is not None:
            return str(getattr(tool, "idname", "") or "")
    except Exception:
        pass
    try:
        tool = bpy.context.workspace.tools.from_space_image_mode("UV", create=False)
        if tool is not None:
            return str(getattr(tool, "idname", "") or "")
    except Exception:
        pass
    return ""


def _is_uv_scale_tool(context) -> bool:
    return _active_uv_tool_id(context) == "builtin.scale"


class _DragOrigin:
    def __init__(self, context, event):
        self.mouse_region_x = event.mouse_prev_press_x - context.region.x
        self.mouse_region_y = event.mouse_prev_press_y - context.region.y


def _find_hit(context, event):
    return _base()._find_hit(context, _DragOrigin(context, event))


class SMARTUVSUITE_OT_scale_tool_background_select(bpy.types.Operator):
    bl_idname = "smart_uv_suite.scale_tool_background_select"
    bl_label = "Scale Tool Background Select"
    bl_description = "When the UV Scale tool is active, empty-background drag falls back to Blender's native Select Box instead of being swallowed by Scale. / UVスケールツール中、空背景ドラッグをスケールではなくスケールツールのまま、ドラッグの範囲でUVを選択します。"
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return _is_uv_context(context)

    def invoke(self, context, event):
        if event.type != "LEFTMOUSE" or event.value != "CLICK_DRAG" or not _is_uv_scale_tool(context):
            return {"PASS_THROUGH"}
        if _find_hit(context, event):
            return {"PASS_THROUGH"}
        if not bpy.ops.uv.select_box.poll():
            return {"PASS_THROUGH"}
        # The Python operator receives CLICK_DRAG, but bpy.ops.invoke uses the
        # current window event. Keep this event's press origin through release.
        self._origin = (event.mouse_prev_press_x - context.region.x,
                        event.mouse_prev_press_y - context.region.y)
        self._end = (event.mouse_region_x, event.mouse_region_y)
        self._mode = "SUB" if event.ctrl else "ADD" if event.shift else "SET"
        self._region = context.region.as_pointer()
        self._draw_handle = _suv_resource.draw_handler_add(
            bpy.types.SpaceImageEditor, self._draw_box, (), "WINDOW", "POST_PIXEL"
        )
        context.window_manager.modal_handler_add(self)
        context.area.tag_redraw()
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if (context.region is None or context.region.as_pointer() != self._region
                or not _is_uv_scale_tool(context) or not bpy.ops.uv.select_box.poll()
                or event.type in {"ESC", "RIGHTMOUSE", "WINDOW_DEACTIVATE"}):
            self.cancel(context)
            return {"CANCELLED"}
        if event.type == "LEFTMOUSE" and event.value == "RELEASE":
            x0, y0 = self._origin
            x1, y1 = event.mouse_region_x, event.mouse_region_y
            self.cancel(context)
            return bpy.ops.uv.select_box(
                "EXEC_DEFAULT", mode=self._mode, xmin=min(x0, x1), xmax=max(x0, x1),
                ymin=min(y0, y1), ymax=max(y0, y1)
            )
        if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
            self._end = (event.mouse_region_x, event.mouse_region_y)
            context.area.tag_redraw()
        return {"RUNNING_MODAL"}

    def cancel(self, context):
        if self._draw_handle is not None:
            _ownership.remove_draw_handler(self._draw_handle)
            self._draw_handle = None
        if context.area is not None:
            context.area.tag_redraw()

    def _draw_box(self):
        import gpu
        from gpu_extras.batch import batch_for_shader

        region = bpy.context.region
        if region is None or region.as_pointer() != self._region:
            return
        x0, y0 = self._origin
        x1, y1 = self._end
        outline = ((x0, y0), (x1, y0), (x1, y1), (x0, y1), (x0, y0))
        shader = gpu.shader.from_builtin("UNIFORM_COLOR")
        shader.bind()
        shader.uniform_float("color", (0.85, 0.85, 0.85, 1.0))
        batch_for_shader(shader, "LINE_STRIP", {"pos": outline}).draw(shader)


def _addon_keyconfig():
    try:
        return bpy.context.window_manager.keyconfigs.addon
    except Exception:
        return None


def _find_kmis(km, idname: str):
    try:
        from . import ownership_runtime_18168 as _own
        return [kmi for keymap, kmi in _own.owned_keymap_items(idname) if keymap == km]
    except Exception:
        return []


def _get_keymap(kc, name: str, space_type: str):
    try:
        km = kc.keymaps.get(name)
        if km is None:
            km = kc.keymaps.new(name=name, space_type=space_type, region_type="WINDOW")
        return km
    except Exception:
        return None


def _sync_scale_background_keymaps():
    if not _scale_background_requested:
        return (0, 0)
    kc = _addon_keyconfig()
    if kc is None:
        return (0, 0)
    created = touched = 0
    for name, space in _SCALE_KEYMAP_DEFS:
        km = _get_keymap(kc, name, space)
        if km is None:
            continue
        items = {(bool(item.shift), bool(item.ctrl)): item for item in _find_kmis(km, _SCALE_BG_ID)}
        for shift, ctrl in _SELECTION_MODIFIERS:
            item = items.get((shift, ctrl))
            if item is None:
                _ownership.new_keymap_item(
                    km, _SCALE_BG_ID, type="LEFTMOUSE", value="CLICK_DRAG", shift=shift, ctrl=ctrl, head=True
                )
                created += 1
            else:
                touched += 1
    return (created, touched)


def _ensure_scale_background_keymaps(active=True):
    return _set_scale_background_active(active)


def _set_scale_background_active(active):
    global _scale_background_requested
    _scale_background_requested = bool(active)
    if _scale_background_requested:
        return _sync_scale_background_keymaps()
    return (_ownership.remove_owned_keymaps(_SCALE_BG_ID), 0)


def _delete_scale_background_keymaps():
    return _set_scale_background_active(False)[0]


def _scale_background_status():
    kc = _addon_keyconfig()
    expected = len(_SCALE_KEYMAP_DEFS)
    registered = active = 0
    if kc is not None:
        for name, _space in _SCALE_KEYMAP_DEFS:
            try:
                km = kc.keymaps.get(name)
                items = _find_kmis(km, _SCALE_BG_ID) if km is not None else []
                if items:
                    registered += 1
                    if any(bool(getattr(kmi, "active", False)) for kmi in items):
                        active += 1
            except Exception:
                pass
    return {"expected": expected, "registered": registered, "active": active}


def _patch_keymap_info():
    if not isinstance(_PG, dict):
        return
    old_rows = _PG.get("_sus_1652_public_keymap_rows")
    old_action = _PG.get("_sus_1652_apply_keymap_action")
    old_exec_cls = _PG.get("SMARTUVSUITE_OT_keymap_info_action")
    fmt = _PG.get("_sus_1652_format_status")
    txt = _PG.get("_sus_text")

    def public_rows(context=None):
        rows = []
        try:
            if callable(old_rows):
                rows = list(old_rows(context))
        except Exception:
            rows = []
        try:
            rows = [r for r in rows if str((r or {}).get("id", "")).upper() != "SCALE_BG_SELECT"]
        except Exception:
            pass
        try:
            en, ja = ("", "")
            if callable(fmt):
                en, ja = fmt(context or bpy.context, _scale_background_status())
            else:
                st = _scale_background_status()
                en = ja = f"{st.get('active',0)}/{st.get('expected',0)}"
            rows.append({
                "id": "SCALE_BG_SELECT",
                "feature_en": "Scale Tool Background Select",
                "feature_ja": "スケールツール背景選択",
                "operator": _SCALE_BG_ID,
                "location_en": "Preferences > Keymap > Image Editor Tool: Uv, Scale",
                "location_ja": "プリファレンス > キーマップ > Image Editor Tool: Uv, Scale",
                "detail_en": "Input: Left Drag\nKeymaps:\n" + "\n".join(name for name, _ in _SCALE_KEYMAP_DEFS),
                "detail_ja": "入力: 左ドラッグ\nキーマップ名:\n" + "\n".join(name for name, _ in _SCALE_KEYMAP_DEFS),
                "status_en": en,
                "status_ja": ja,
            })
        except Exception:
            pass
        return rows

    def apply_action(context, target: str, action: str):
        target = str(target or "").upper(); action = str(action or "").upper()
        if target == "SCALE_BG_SELECT":
            if action in {"REGISTER", "ENABLE"}:
                return {"created_touched": _ensure_scale_background_keymaps(True)}
            if action == "DISABLE":
                return {"disabled": _set_scale_background_active(False)}
            if action == "DELETE":
                return {"removed": _delete_scale_background_keymaps()}
        if callable(old_action):
            return old_action(context, target, action)
        return {}

    _PG["_sus_1652_public_keymap_rows"] = public_rows
    _PG["_sus_1652_apply_keymap_action"] = apply_action
    try:
        if isinstance(old_exec_cls, type):
            def execute(self, context):
                target = str(getattr(self, "target", "") or "").upper()
                action = str(getattr(self, "action", "REGISTER") or "REGISTER").upper()
                valid = {"INSTANT_SELECT", "UV_GIZMO_GRIP", "SCALE_BG_SELECT"}
                if target not in valid or action not in {"REGISTER", "DELETE", "ENABLE", "DISABLE"}:
                    self.report({"WARNING"}, (txt("Invalid keymap action.", "無効なキーマップ操作です。", context) if callable(txt) else "Invalid keymap action."))
                    return {"CANCELLED"}
                apply_action(context, target, action)
                self.report({"INFO"}, (txt("Keymap state updated.", "キーマップ状態を更新しました。", context) if callable(txt) else "Keymap state updated."))
                return {"FINISHED"}
            old_exec_cls.execute = execute
    except Exception:
        pass


def _register_operator_class():
    try:
        cls = SMARTUVSUITE_OT_scale_tool_background_select
        if bool(getattr(cls, 'is_registered', False)) or getattr(cls, '__dict__', {}).get('bl_rna') is not None:
            return
    except Exception:
        pass
    try:
        __import__(__package__ + '.ownership_runtime_18168', fromlist=['register_class']).register_class(SMARTUVSUITE_OT_scale_tool_background_select)
    except ValueError:
        pass
    except RuntimeError:
        pass
    except Exception:
        pass


def _unregister_operator_class():
    try:
        __import__(__package__ + '.ownership_runtime_18168', fromlist=['unregister_class']).unregister_class(SMARTUVSUITE_OT_scale_tool_background_select)
    except Exception:
        pass


def apply_all(pkg_globals=None, context=None):
    global _PG
    if pkg_globals is not None:
        _PG = pkg_globals
    try:
        if isinstance(_PG, dict):
            bi = _PG.get("bl_info")
            if isinstance(bi, dict):
                bi["version"] = (1, 0, 0)
            _PG["__version__"] = '1.0.0'
            _PG["_sus_1872_scale_bg_select_status"] = _scale_background_status
            _PG["_sus_1872_scale_bg_select_enable"] = _ensure_scale_background_keymaps
            _PG["_sus_1872_scale_bg_select_disable"] = _set_scale_background_active
            _PG["_sus_1872_scale_bg_select_delete"] = _delete_scale_background_keymaps
    except Exception:
        pass
    _register_operator_class()
    _patch_keymap_info()
    _sync_scale_background_keymaps()


def install(pkg_globals):
    global _PG
    _PG = pkg_globals
    apply_all(pkg_globals, bpy.context)


def unregister():
    _delete_scale_background_keymaps()
    _unregister_operator_class()


