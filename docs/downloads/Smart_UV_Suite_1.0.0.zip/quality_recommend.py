from __future__ import annotations


def _workspace_tab(namespace: dict, context) -> str:
    ws_fn = namespace.get('_suv_ws')
    ws = ws_fn(context) if callable(ws_fn) else None
    return str(getattr(ws, 'tab', '') or '')


def _collect_status(namespace: dict, context) -> dict:
    cached = namespace.get('_suv_quality_state_last') or {}
    if namespace.get('_suv_quality_state_scanning') and isinstance(cached, dict):
        return dict(cached)
    state_mod = namespace.get('_quality_state_module')
    if state_mod is not None and hasattr(state_mod, 'collect_status'):
        try:
            data = state_mod.collect_status(namespace, context)
            if isinstance(data, dict):
                return dict(data)
        except Exception:
            pass
    return dict(cached) if isinstance(cached, dict) else {}


def _safe_buttons_from_sections(sections):
    out = []
    for section in sections or []:
        for card in section.get('cards', []) or []:
            for button in card.get('buttons', []) or []:
                cls = button.get('cls')
                bl_idname = str(getattr(cls, 'bl_idname', '') or '')
                if not bl_idname:
                    continue
                out.append({
                    'text': str(button.get('text', '') or getattr(cls, 'bl_label', '') or bl_idname),
                    'icon': str(button.get('icon', 'NONE') or 'NONE'),
                    'cls': cls,
                    'idname': bl_idname,
                    'card_title': str(card.get('title', '') or ''),
                    'section_title': str(section.get('title', '') or ''),
                    'props': dict(button.get('props') or {}),
                })
    return out


def _unique(buttons, limit=4):
    seen = set()
    out = []
    for button in buttons:
        key = (button.get('idname'), tuple(sorted((button.get('props') or {}).items())))
        if key in seen:
            continue
        seen.add(key)
        out.append(button)
        if len(out) >= limit:
            break
    return out


def _label(namespace: dict, context, key: str, en: str, ja: str) -> str:
    tr = namespace.get('tr')
    if callable(tr):
        try:
            text = tr(context, key)
            if text:
                return text
        except Exception:
            pass
    return en


def scan_recommended_actions(namespace: dict, context, status: dict | None = None) -> dict:
    cards_mod = namespace.get('_quality_cards_module')
    translate = namespace.get('_quality_visual_translate')
    if not callable(translate):
        translate = lambda ctx, key, en, ja: en
    sections = []
    if cards_mod is not None and hasattr(cards_mod, '_raw_sections'):
        try:
            sections = cards_mod._raw_sections(namespace, context, translate) or []
        except Exception:
            sections = []
    elif cards_mod is not None and hasattr(cards_mod, 'build_card_sections'):
        try:
            sections = cards_mod.build_card_sections(namespace, context, translate) or []
        except Exception:
            sections = []
    buttons = _safe_buttons_from_sections(sections)
    by_id = {b['idname']: b for b in buttons}
    status = dict(status) if isinstance(status, dict) else _collect_status(namespace, context)
    issues = int(status.get('issue_total', 0) or 0)
    readiness_missing = int(status.get('readiness_missing', 0) or 0)
    tool_runtime_errors = int(status.get('tool_runtime_errors', 0) or 0)
    coverage_missing = int(status.get('coverage_missing', 0) or 0)
    manual_controls = int(status.get('manual_controls', 0) or 0)
    controls_custom = bool(status.get('controls_custom', False))
    workspace = _workspace_tab(namespace, context)

    want = []
    if readiness_missing > 0:
        want += ['uv.suv_quality_prepare_context_basics', 'uv.suv_quality_scan_context_readiness', 'uv.suv_workspace_auto_repair']
    if tool_runtime_errors > 0 or issues > 0:
        want += ['uv.suv_quality_write_doctor_report', 'uv.suv_quality_audit_suite', 'uv.suv_quality_scan_generated_data']
    if coverage_missing > 0:
        want += ['uv.suv_quality_scan_feature_matrix', 'uv.suv_quality_write_task_playbook']
    if manual_controls > 0 or controls_custom:
        want += ['uv.suv_quality_write_controls_report', 'uv.suv_quality_reset_visual_controls']
    workspace_map = {
        'WORKFLOW': ['uv.suv_quality_prepare_context_basics'],
        'TRANSFORM': ['uv.suv_quality_write_task_playbook'],
        'LAYOUT': ['uv.suv_quality_write_execution_profiles'],
        'ANALYZE': ['uv.suv_quality_audit_suite', 'uv.suv_quality_write_language_coverage'],
        'MAPS': ['uv.suv_quality_prepare_context_basics'],
        'SYMMETRY': ['uv.suv_quality_write_task_playbook'],
        'ATLAS': ['uv.suv_quality_write_task_playbook'],
    }
    want += workspace_map.get(workspace, [])

    reason_map = {}
    def add_choice(item_id: str, reason_key: str, en: str, ja: str):
        btn = by_id.get(item_id)
        if btn is None:
            return
        reason = _label(namespace, context, reason_key, en, ja)
        enriched = dict(btn)
        enriched['reason'] = reason
        chosen.append(enriched)
        reason_map[item_id] = reason

    chosen = []
    if readiness_missing > 0:
        add_choice('uv.suv_quality_prepare_context_basics', 'ui.visual.reason.prepare', 'Missing setup basics', '準備不足を解消')
        add_choice('uv.suv_quality_scan_context_readiness', 'ui.visual.reason.readiness', 'Check current readiness', '現在の準備状態を確認')
        add_choice('uv.suv_workspace_auto_repair', 'ui.visual.reason.workspace', 'Repair workspace context', 'ワークスペース前提を修復')
    if tool_runtime_errors > 0 or issues > 0:
        add_choice('uv.suv_quality_write_doctor_report', 'ui.visual.reason.doctor', 'Review priority fixes', '優先修正を確認')
        add_choice('uv.suv_quality_audit_suite', 'ui.visual.reason.audit', 'Inspect tool_runtime issues', '実行時問題を点検')
        add_choice('uv.suv_quality_scan_generated_data', 'ui.visual.reason.cleanup', 'Check generated clutter', '生成データの整理候補を確認')
    if coverage_missing > 0:
        add_choice('uv.suv_quality_scan_feature_matrix', 'ui.visual.reason.coverage', 'Check missing feature groups', '不足機能グループを確認')
        add_choice('uv.suv_quality_write_task_playbook', 'ui.visual.reason.playbook', 'Open guided task flow', 'タスク別ガイドを開く')
    if manual_controls > 0 or controls_custom:
        add_choice('uv.suv_quality_write_controls_report', 'ui.visual.reason.controls_report', 'Review active visual control overrides', '現在の視覚コントロール上書きを確認')
        add_choice('uv.suv_quality_reset_visual_controls', 'ui.visual.reason.reset_controls', 'Return the dashboard to a clean baseline', 'ダッシュボードを整理された初期状態へ戻す')
    for item in workspace_map.get(workspace, []):
        add_choice(item, 'ui.visual.reason.workspace_flow', 'Suggested for this workspace', '今のワークスペース向け')

    if len(chosen) < 4:
        priority_words = ('prepare', 'scan', 'repair', 'audit', 'help', 'playbook', 'report hub', 'doctor', 'matrix', 'language')
        for button in buttons:
            text = button.get('text', '').lower()
            if any(word in text for word in priority_words):
                enriched = dict(button)
                enriched.setdefault('reason', _label(namespace, context, 'ui.visual.reason.general', 'Useful next step', '次の有力候補'))
                chosen.append(enriched)
                if len(_unique(chosen, limit=4)) >= 4:
                    break
    if len(chosen) < 4:
        for button in buttons[:4]:
            enriched = dict(button)
            enriched.setdefault('reason', _label(namespace, context, 'ui.visual.reason.general', 'Useful next step', '次の有力候補'))
            chosen.append(enriched)
    chosen = _unique(chosen, limit=4)
    reasons = []
    for button in chosen:
        reason = str(button.get('reason', '') or '').strip()
        if reason and reason not in reasons:
            reasons.append(reason)
    data = {
        'count': len(chosen),
        'buttons': chosen,
        'reasons': reasons,
        'workspace': workspace,
        'readiness_missing': readiness_missing,
        'tool_runtime_errors': tool_runtime_errors,
        'coverage_missing': coverage_missing,
    }
    namespace['_suv_recommended_actions_last'] = data
    return data
