# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations
from . import resource_api_18168 as _suv_resource
from . import npanel_schema_18169 as _strict_schema

import ast
import copy
import json
import os
from pathlib import Path
from typing import Any

import bpy
from bpy.app.handlers import persistent

_STATE_CACHE: dict[str, Any] | None = None
_DIRTY = False
_APPLYING_WORKSPACE = False
_APPLYING_NATIVE_UV = False
_REGISTERED = False
_UV_EDITOR_MSGBUS_OWNER = object()
_REGISTRATION_WRITE_GUARD_DEPTH = 0
_STATE_SAVE_SELF_COMMIT_DEPTH = 0

_STATE_DIR_NAME = 'Smart_UV_Suite'
_STATE_FILE_NAME = 'Smart_UV_Suite.json'
_STATE_VERSION = 7
_AUTOSAVE_TIMER_INTERVAL = 15.0
_PREF_SAVE_WATCH_INTERVAL = 1.0
_PREF_SAVE_MTIME: float | None = None
_WORKSPACE_PROP_NAMES_CACHE: tuple[str, ...] | None = None
_LAST_WORKSPACE_SCENE_ID: int | None = None


def _package_id() -> str:
    text = str(__package__ or 'uv_suite').strip().strip('.')
    if text.startswith('bl_ext.'):
        text = text.rsplit('.', 1)[-1]
    elif '.' in text:
        text = text.rsplit('.', 1)[-1]
    return text or 'uv_suite'


def _config_root_dir(create: bool = False) -> Path:
    """Return Blender's user config directory.

    On Windows Blender 5.1 this resolves to::

        C:/Users/<user>/AppData/Roaming/Blender Foundation/Blender/5.1/config
    """
    try:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            path_text = user_resource('CONFIG', path='', create=bool(create))
            if path_text:
                path = Path(path_text)
                if create:
                    path.mkdir(parents=True, exist_ok=True)
                return path
    except Exception:
        pass
    version = '5.1'
    try:
        app_version = getattr(getattr(bpy, 'app', None), 'version', (5, 1, 0)) or (5, 1, 0)
        version = f"{int(app_version[0])}.{int(app_version[1])}"
    except Exception:
        pass
    appdata = os.environ.get('APPDATA')
    if appdata:
        target = os.path.join(appdata, 'Blender Foundation', 'Blender', version, 'config')
    else:
        target = os.path.join(os.path.expanduser('~'), '.config', 'blender', version, 'config')
    path = Path(target)
    if create:
        try:
            path.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path


def _state_dir(create: bool = False) -> Path:
    """Return this add-on's external N-panel state directory.

    The N-panel state is stored outside scenes and outside the extension folder
    so that it survives file switching, add-on reloads and reinstalling the ZIP.
    On Windows Blender 5.1 this resolves to::

        C:/Users/<user>/AppData/Roaming/Blender Foundation/Blender/5.1/config/Smart_UV_Suite
    """
    root = _config_root_dir(create=create)
    path = root / _STATE_DIR_NAME
    if create:
        try:
            path.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path
def state_path(create: bool = False) -> Path:
    return _state_dir(create=create) / _STATE_FILE_NAME


def _userpref_path() -> Path:
    return _config_root_dir(create=False) / 'userpref.blend'


def _file_mtime(path: Path) -> float | None:
    try:
        return float(path.stat().st_mtime)
    except Exception:
        return None


def _remember_userpref_mtime() -> None:
    global _PREF_SAVE_MTIME
    _PREF_SAVE_MTIME = _file_mtime(_userpref_path())


def _deferred_preference_save_timer():
    """Flush deferred N-panel state after Blender Save Preferences is used.

    Blender exposes save_pre/save_post handlers for .blend files, but not for
    wm.save_userpref().  When N-panel State Save is disabled we therefore keep a
    tiny one-shot watcher only while unsaved panel state exists.  It observes the
    userpref.blend timestamp and writes this add-on's JSON state immediately
    after the user saves preferences.  No UV helper, overlay or tool handler is
    started by this watcher.
    """
    global _DIRTY, _PREF_SAVE_MTIME
    try:
        if get_state_save_enabled(True):
            return None
        if not bool(_DIRTY):
            return None
        current = _file_mtime(_userpref_path())
        if current is not None and current != _PREF_SAVE_MTIME:
            save_state(force=True)
            _PREF_SAVE_MTIME = current
            return None
    except Exception:
        pass
    return _PREF_SAVE_WATCH_INTERVAL


def _schedule_deferred_preference_save_watch() -> None:
    # Blender has no user-preference-save handler.  Do not poll userpref.blend:
    # deferred state is flushed at file/add-on lifecycle boundaries instead, so
    # the disabled state-save policy creates no recurring idle work.
    _remember_userpref_mtime()



def _sync_autosave_timer() -> None:
    _suv_resource.timer_unregister(_autosave_timer)
    _suv_resource.timer_unregister(_deferred_preference_save_timer)


def _default_state() -> dict[str, Any]:
    return {
        'version': _STATE_VERSION,
        'foldouts': {},
        'always_on': {},
        'workspace': {},
        'addon_preferences': {},
        'integrated_tools': {},
        'uv_editor': {},
        'npanel_state_save': True,
        'stores': {},
    }


def _legacy_state_paths() -> list[Path]:
    paths: list[Path] = []
    package_id = _package_id()
    version = '5.1'
    try:
        app_version = getattr(getattr(bpy, 'app', None), 'version', (5, 1, 0)) or (5, 1, 0)
        version = f"{int(app_version[0])}.{int(app_version[1])}"
    except Exception:
        pass
    paths.append(_config_root_dir(create=False) / _STATE_FILE_NAME)
    try:
        from . import storage as _storage
        paths.append(Path(_storage.runtime_dir('state', create=False, package=package_id)) / 'uv_suite_npanel_state.json')
        paths.append(Path(_storage.extension_user_root(package_id, create=False)) / 'uv_suite_settings.json')
    except Exception:
        pass
    appdata = os.environ.get('APPDATA')
    if appdata:
        base = Path(appdata) / 'Blender Foundation' / 'Blender' / version / 'extensions' / 'user_default' / package_id
    else:
        base = Path(os.path.expanduser('~')) / '.config' / 'blender' / version / 'extensions' / 'user_default' / package_id
    paths.append(base / 'state' / 'uv_suite_npanel_state.json')
    paths.append(base / 'uv_suite_settings.json')
    unique: list[Path] = []
    seen: set[str] = set()
    for path in paths:
        key = str(path)
        if key not in seen:
            seen.add(key)
            unique.append(path)
    return unique


def _read_json_file(path: Path) -> dict[str, Any]:
    raw_text = path.read_text(encoding="utf-8")
    raw = json.loads(
        raw_text,
        object_pairs_hook=_sus_18168_pairs,
        parse_constant=_sus_18168_constant,
    )
    return _sus_18168_validate_state(raw)


def _merge_state_payload(data: dict[str, Any], raw: dict[str, Any]) -> None:
    if not isinstance(raw, dict):
        return
    for key in ('foldouts', 'always_on', 'workspace', 'addon_preferences', 'integrated_tools', 'uv_editor'):
        value = raw.get(key)
        if isinstance(value, dict):
            data[key].update(dict(value))
    # Compatibility with the older uv_suite_settings.json format.
    value = raw.get('settings')
    if isinstance(value, dict):
        data['addon_preferences'].update(dict(value))
    if 'npanel_state_save' in raw:
        data['npanel_state_save'] = bool(raw.get('npanel_state_save'))
    for key in ('version',):
        try:
            data[key] = int(raw.get(key) or data.get(key) or _STATE_VERSION)
        except Exception:
            pass


def load_state(force: bool = False) -> dict[str, Any]:
    """Lifecycle/event-boundary load; corrupt originals are retained unchanged."""
    global _STATE_CACHE
    if isinstance(_STATE_CACHE, dict) and not force:
        return _STATE_CACHE
    data = _default_state()
    source = state_path(create=False)
    candidates = [source] if source.exists() else [p for p in _legacy_state_paths() if p.exists()]
    for path in candidates:
        try:
            loaded = _read_json_file(path)
        except Exception:
            # No rename/delete/overwrite.  Use defaults and retain source bytes.
            continue
        data.update(loaded)
        break
    try:
        data["_loaded_version"] = int(data.get("version", _STATE_VERSION))
    except Exception:
        data["_loaded_version"] = _STATE_VERSION
    data["version"] = _STATE_VERSION
    _STATE_CACHE = data
    return data


def _peek_state() -> dict[str, Any]:
    """Return the already-loaded state without file I/O or mutation.

    Panel draw callbacks use only the ``peek_*`` accessors below.  The cache is
    populated at add-on registration and file-load lifecycle boundaries; an
    uninitialized cache therefore means "use the authored default" rather than
    "read the JSON now".  This keeps redraw strictly read-only.
    """
    data = _STATE_CACHE
    return data if isinstance(data, dict) else {}


def peek_state_save_enabled(default: bool = True) -> bool:
    try:
        data = _peek_state()
        return bool(data.get('npanel_state_save', bool(default))) if data else bool(default)
    except Exception:
        return bool(default)


def peek_foldout(key: str, default: bool = False) -> bool:
    key = str(key or '').strip()
    if not key:
        return bool(default)
    try:
        data = _peek_state()
        store = data.get('foldouts', {}) if data else {}
        return bool(store.get(key, bool(default))) if isinstance(store, dict) else bool(default)
    except Exception:
        return bool(default)


def peek_always_on(feature_id: str, default: bool = False) -> bool:
    feature_id = str(feature_id or '').strip().upper()
    if not feature_id:
        return bool(default)
    try:
        data = _peek_state()
        store = data.get('always_on', {}) if data else {}
        return bool(store.get(feature_id, bool(default))) if isinstance(store, dict) else bool(default)
    except Exception:
        return bool(default)


def peek_has_always_on(feature_id: str) -> bool:
    feature_id = str(feature_id or '').strip().upper()
    if not feature_id:
        return False
    try:
        data = _peek_state()
        store = data.get('always_on', {}) if data else {}
        return feature_id in store if isinstance(store, dict) else False
    except Exception:
        return False


def peek_always_on_items() -> dict[str, bool]:
    try:
        data = _peek_state()
        store = data.get('always_on', {}) if data else {}
        return {str(k).upper(): bool(v) for k, v in dict(store or {}).items()}
    except Exception:
        return {}


def peek_addon_preferences_items() -> dict[str, Any]:
    try:
        data = _peek_state()
        store = data.get('addon_preferences', {}) if data else {}
        return dict(store or {})
    except Exception:
        return {}


def begin_registration_restore() -> dict[str, Any]:
    """Freeze the canonical profile while Blender materialises suite RNA."""
    global _REGISTRATION_WRITE_GUARD_DEPTH
    payload = copy.deepcopy(load_state(force=True))
    _REGISTRATION_WRITE_GUARD_DEPTH += 1
    return payload


def apply_registration_restore(payload: dict[str, Any] | None, context=None) -> None:
    global _STATE_CACHE
    if isinstance(payload, dict):
        _STATE_CACHE = copy.deepcopy(payload)
    apply_workspace(context or getattr(bpy, 'context', None))
    apply_uv_editor(context or getattr(bpy, 'context', None))


def end_registration_restore() -> None:
    global _REGISTRATION_WRITE_GUARD_DEPTH
    _REGISTRATION_WRITE_GUARD_DEPTH = max(0, _REGISTRATION_WRITE_GUARD_DEPTH - 1)


def get_state_save_enabled(default: bool = True) -> bool:
    try:
        return bool(_peek_state_18168().get('npanel_state_save', bool(default)))
    except Exception:
        return bool(default)


def set_state_save_enabled(value: bool, *, context=None, prefs=None) -> None:
    global _STATE_SAVE_SELF_COMMIT_DEPTH
    data = load_state()
    target = bool(value)
    data['npanel_state_save'] = target
    # Persist the toggle itself before changing subscriptions.  This guarantees
    # that a disabled state survives restart even though all leaf-property
    # watchers are removed immediately afterwards.
    if not target:
        _STATE_SAVE_SELF_COMMIT_DEPTH += 1
        try:
            save_state(force=True)
        finally:
            _STATE_SAVE_SELF_COMMIT_DEPTH = max(0, _STATE_SAVE_SELF_COMMIT_DEPTH - 1)
    else:
        flush_all(context, prefs=prefs)
    _sync_autosave_timer()
    _subscribe_native_uv_settings()


def save_state(*, force: bool = False) -> None:
    """Strict same-directory unique-temp atomic save with readback verification."""
    global _DIRTY
    if _REGISTRATION_WRITE_GUARD_DEPTH > 0:
        return
    data = load_state()
    if (not bool(data.get('npanel_state_save', True))
            and _STATE_SAVE_SELF_COMMIT_DEPTH <= 0):
        _DIRTY = True
        return
    import tempfile
    path = state_path(create=True)
    directory = path.parent
    serializable = _sus_18169_serializable_state(dict(data, version=_STATE_VERSION))
    payload = _sus_18168_validate_state(serializable)
    serialized = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + '\n'
    try:
        if path.exists() and path.read_text(encoding='utf-8') == serialized:
            _DIRTY = False
            return
    except Exception:
        pass
    old_exists = path.exists()
    old_bytes = b''
    if old_exists:
        try:
            old_bytes = path.read_bytes()
            _read_json_file(path)
        except Exception as exc:
            _DIRTY = True
            raise ValueError('existing Smart UV N-panel state is invalid; original preserved') from exc
    fd, temp_name = tempfile.mkstemp(prefix='.' + path.name + '.', suffix='.tmp', dir=str(directory))
    temp_path = Path(temp_name)
    committed = False
    replaced = False
    try:
        with os.fdopen(fd, 'w', encoding='utf-8', newline='\n') as handle:
            handle.write(serialized)
            handle.flush()
            os.fsync(handle.fileno())
        staged = temp_path.read_text(encoding='utf-8')
        parsed = json.loads(staged, object_pairs_hook=_sus_18168_pairs, parse_constant=_sus_18168_constant)
        if _sus_18168_validate_state(parsed) != payload or staged != serialized:
            raise OSError('staged state readback mismatch')
        os.replace(str(temp_path), str(path))
        replaced = True
        _sus_18168_dir_fsync(directory)
        final_text = path.read_text(encoding='utf-8')
        final_raw = json.loads(final_text, object_pairs_hook=_sus_18168_pairs, parse_constant=_sus_18168_constant)
        if _sus_18168_validate_state(final_raw) != payload or final_text != serialized:
            raise OSError('committed state readback mismatch')
        committed = True
        _DIRTY = False
    except Exception:
        if replaced and not committed:
            try:
                if old_exists:
                    restore_fd, restore_name = tempfile.mkstemp(prefix='.' + path.name + '.restore.', suffix='.tmp', dir=str(directory))
                    restore_path = Path(restore_name)
                    try:
                        with os.fdopen(restore_fd, 'wb') as handle:
                            handle.write(old_bytes)
                            handle.flush()
                            os.fsync(handle.fileno())
                        os.replace(str(restore_path), str(path))
                        _sus_18168_dir_fsync(directory)
                    finally:
                        if restore_path.exists():
                            restore_path.unlink()
                elif path.exists():
                    path.unlink()
                    _sus_18168_dir_fsync(directory)
            except Exception:
                pass
        _DIRTY = True
        raise
    finally:
        try:
            if temp_path.exists():
                temp_path.unlink()
        except Exception:
            pass



def get_foldout(key: str, default: bool = False) -> bool:
    key = str(key or '').strip()
    if not key:
        return bool(default)
    try:
        return bool(_peek_state_18168().get('foldouts', {}).get(key, bool(default)))
    except Exception:
        return bool(default)


def set_foldout(key: str, value: bool) -> None:
    key = str(key or '').strip()
    if not key:
        return
    load_state().setdefault('foldouts', {})[key] = bool(value)
    save_state()


def get_always_on(feature_id: str, default: bool = False) -> bool:
    feature_id = str(feature_id or '').strip().upper()
    if not feature_id:
        return bool(default)
    try:
        return bool(_peek_state_18168().get('always_on', {}).get(feature_id, bool(default)))
    except Exception:
        return bool(default)


def has_always_on(feature_id: str) -> bool:
    feature_id = str(feature_id or '').strip().upper()
    if not feature_id:
        return False
    try:
        return feature_id in dict(_peek_state_18168().get('always_on', {}) or {})
    except Exception:
        return False


def set_always_on(feature_id: str, value: bool) -> None:
    feature_id = str(feature_id or '').strip().upper()
    if not feature_id:
        return
    data = load_state()
    store = data.setdefault('always_on', {})
    target = bool(value)
    if feature_id not in store and not target:
        # Absence means the install-time default OFF.  Do not create false rows
        # or repeatedly rewrite JSON during registration.
        return
    if feature_id in store and bool(store.get(feature_id)) == target:
        return
    store[feature_id] = target
    save_state()


def always_on_items() -> dict[str, bool]:
    try:
        return {str(k).upper(): bool(v) for k, v in dict(_peek_state_18168().get('always_on', {}) or {}).items()}
    except Exception:
        return {}


def addon_preferences_items() -> dict[str, Any]:
    try:
        return dict(_peek_state_18168().get('addon_preferences', {}) or {})
    except Exception:
        return {}


def set_addon_preferences(values: dict[str, Any]) -> None:
    data = load_state()
    data['addon_preferences'] = dict(values or {})
    save_state()


def update_addon_preferences(values: dict[str, Any]) -> None:
    if not isinstance(values, dict):
        return
    data = load_state()
    current = dict(data.get('addon_preferences', {}) or {})
    current.update(dict(values or {}))
    data['addon_preferences'] = current
    save_state()


def get_integrated_enabled(alias: str, default: bool = False) -> bool:
    alias = str(alias or '').strip()
    if not alias:
        return bool(default)
    try:
        return bool(_peek_state_18168().get('integrated_tools', {}).get(alias, bool(default)))
    except Exception:
        return bool(default)


def set_integrated_enabled(alias: str, value: bool) -> None:
    alias = str(alias or '').strip()
    if not alias:
        return
    load_state().setdefault('integrated_tools', {})[alias] = bool(value)
    save_state()


def is_applying_workspace() -> bool:
    return bool(_APPLYING_WORKSPACE)


def _is_json_value(value: Any) -> bool:
    return _to_json_value(value, _missing_marker=None) is not None or value is None


def _to_json_value(value: Any, *, _missing_marker: Any = Ellipsis) -> Any:
    """Convert Blender RNA scalar/vector values to JSON-safe values.

    Workspace properties and UV Editor settings can include bpy_prop_array or
    mathutils.Vector values.  Older persistence only handled scalar values, so
    array-based N-panel settings such as Grid Subdivisions, Tile Grid and Image
    Display Aspect could not survive a Blender restart.  Keep this conversion
    intentionally conservative: only scalars and one-level numeric/string lists
    are stored.
    """
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, (list, tuple)):
        out = []
        for item in value:
            if isinstance(item, (bool, int, float, str)) or item is None:
                out.append(item)
            else:
                return _missing_marker
        return out
    try:
        # Handles bpy_prop_array and mathutils.Vector without treating strings
        # as iterables because strings were returned above.
        out = []
        for item in value:
            if isinstance(item, (bool, int, float, str)) or item is None:
                out.append(item)
            else:
                return _missing_marker
        return out
    except Exception:
        return _missing_marker


_UV_EDITOR_PROPS = (
    'show_grid_over_image',
    'grid_shape_source',
    'tile_grid_shape',
    'custom_grid_subdivisions',
    'show_pixel_coords',
    'show_uv',
    'show_faces',
    'edge_display_type',
    'show_modified_edges',
    'show_stretch',
    'display_stretch_type',
    'uv_opacity',
    'uv_face_opacity',
    'uv_edge_opacity',
    'stretch_opacity',
    'pixel_round_mode',
    'lock_bounds',
    'use_live_unwrap',
)


def _native_uv_setting_changed(*_args) -> None:
    if _APPLYING_NATIVE_UV:
        return
    try:
        save_uv_editor(getattr(bpy, 'context', None))
    except Exception:
        pass


def _active_scene_changed() -> None:
    """Restore saved settings only while N-panel state persistence is enabled."""
    ctx = getattr(bpy, 'context', None)
    if get_state_save_enabled(True):
        try:
            apply_workspace(ctx)
        except Exception:
            pass
        try:
            apply_uv_editor(ctx)
        except Exception:
            pass
    # Keep one scene-boundary listener even while persistence is disabled so a
    # newly-created Scene can rebuild the correct (minimal or full) owner set.
    _subscribe_native_uv_settings()


def _subscribe_native_uv_settings() -> None:
    # 1.8.169: no msgbus subscriptions at idle; persistence is lifecycle/explicit-save only.
    return None


def _iter_image_editor_spaces(context=None):
    """Yield Image Editor spaces visible in the current screen.

    The UV Editor guide/view settings exposed by the Smart UV N-panel belong to
    SpaceImageEditor.uv_editor rather than Scene.suv_workspace, so they must be
    captured separately from workspace settings.
    """
    ctx = context or getattr(bpy, 'context', None)
    yielded: set[int] = set()

    def _yield_space(space):
        try:
            if getattr(space, 'type', '') != 'IMAGE_EDITOR':
                return None
            key = id(space)
            if key in yielded:
                return None
            yielded.add(key)
            return space
        except Exception:
            return None

    try:
        space = _yield_space(getattr(ctx, 'space_data', None))
        if space is not None:
            yield space
    except Exception:
        pass
    try:
        screen = getattr(ctx, 'screen', None)
        for area in getattr(screen, 'areas', []) or []:
            if getattr(area, 'type', '') != 'IMAGE_EDITOR':
                continue
            for space in getattr(area, 'spaces', []) or []:
                found = _yield_space(space)
                if found is not None:
                    yield found
    except Exception:
        pass


def _capture_uv_editor_from_space(space) -> dict[str, Any]:
    values: dict[str, Any] = {}
    try:
        uv = getattr(space, 'uv_editor', None)
    except Exception:
        uv = None
    if uv is not None:
        for name in _UV_EDITOR_PROPS:
            try:
                value = _to_json_value(getattr(uv, name))
            except Exception:
                continue
            if value is not Ellipsis:
                values[name] = value
    try:
        if hasattr(space, 'show_repeat'):
            value = _to_json_value(getattr(space, 'show_repeat'))
            if value is not Ellipsis:
                values['space.show_repeat'] = value
                values['show_repeat'] = value
    except Exception:
        pass
    try:
        image = getattr(space, 'image', None)
        if image is not None and hasattr(image, 'display_aspect'):
            value = _to_json_value(getattr(image, 'display_aspect'))
            if value is not Ellipsis:
                values['image.display_aspect'] = value
                values['display_aspect'] = value
    except Exception:
        pass
    return values


def capture_uv_editor(context=None) -> dict[str, Any]:
    for space in _iter_image_editor_spaces(context):
        values = _capture_uv_editor_from_space(space)
        if values:
            return values
    return {}


def save_uv_editor(context=None) -> None:
    if _APPLYING_WORKSPACE:
        return
    values = capture_uv_editor(context)
    if not values:
        return
    data = load_state()
    current = dict(data.get('uv_editor', {}) or {})
    if current == values:
        return
    data['uv_editor'] = values
    save_state()


def apply_uv_editor(context=None) -> int:
    global _APPLYING_NATIVE_UV
    values = dict(load_state().get('uv_editor', {}) or {})
    if not values:
        return 0
    applied = 0
    _APPLYING_NATIVE_UV = True
    try:
        for space in _iter_image_editor_spaces(context):
            try:
                uv = getattr(space, 'uv_editor', None)
            except Exception:
                uv = None
            if uv is not None:
                for name in _UV_EDITOR_PROPS:
                    if name not in values:
                        continue
                    try:
                        setattr(uv, name, values[name])
                        applied += 1
                    except Exception:
                        continue
            if 'space.show_repeat' in values or 'show_repeat' in values:
                try:
                    if hasattr(space, 'show_repeat'):
                        setattr(space, 'show_repeat', bool(values.get('space.show_repeat', values.get('show_repeat'))))
                        applied += 1
                except Exception:
                    pass
            if 'image.display_aspect' in values or 'display_aspect' in values:
                try:
                    image = getattr(space, 'image', None)
                    if image is not None and hasattr(image, 'display_aspect'):
                        setattr(image, 'display_aspect', values.get('image.display_aspect', values.get('display_aspect')))
                        applied += 1
                except Exception:
                    pass
    finally:
        _APPLYING_NATIVE_UV = False
    return applied


def _current_workspace(context=None):
    """Return the active Scene.suv_workspace without using cached RNA pointers."""
    try:
        ctx = context or getattr(bpy, 'context', None)
        scene = getattr(ctx, 'scene', None)
        if scene is None:
            return None
        return getattr(scene, 'suv_workspace', None)
    except Exception:
        return None


def _read_workspace_prop_names_from_source() -> list[str]:
    """Read SUV_PG_WorkspaceSettings property names from ui.py source only.

    Blender 5.1.x can crash natively if a timer callback introspects RNA metadata
    on a stale PropertyGroup.  Parsing the add-on source avoids ``ws.bl_rna``,
    ``type(ws)``, ``hasattr(ws, ...)`` and class ``getattr`` on RNA objects.
    """
    names: list[str] = []
    seen: set[str] = set()

    def _add(value: object) -> None:
        name = str(value or '').strip()
        # bl_label/bl_description are plain class attributes on the
        # PropertyGroup, not user settings; capturing them made every
        # workspace snapshot exceed the strict schema.
        if not name or name in seen or name == 'rna_type' or name.startswith('_') or name.startswith('bl_'):
            return
        seen.add(name)
        names.append(name)

    try:
        ui_path = Path(__file__).with_name('ui.py')
        source = ui_path.read_text(encoding='utf-8', errors='ignore')
        tree = ast.parse(source, filename=str(ui_path))
        for node in getattr(tree, 'body', ()):
            if not isinstance(node, ast.ClassDef) or node.name != 'SUV_PG_WorkspaceSettings':
                continue
            for stmt in getattr(node, 'body', ()):
                if isinstance(stmt, ast.AnnAssign) and isinstance(stmt.target, ast.Name):
                    _add(stmt.target.id)
                elif isinstance(stmt, ast.Assign):
                    for target in getattr(stmt, 'targets', ()):
                        if isinstance(target, ast.Name):
                            _add(target.id)
            break
    except Exception:
        pass
    return names


# Read-only reports, ephemeral caches and last-operation diagnostics are not
# user settings.  Persisting them made a new scene inherit stale scan/health
# results and also rewrote the JSON after ordinary tool execution.
_TRANSIENT_WORKSPACE_PROPS = frozenset({
    'ui_mode',
    'smart_standard_core_resolved_unwrap_mode',
    'smart_standard_core_last_actual_unwrap_mode',
    'scan_has_result',
    'scan_time',
    'scan_scope',
    'scan_eps_zero',
    'scan_check_out',
    'scan_check_overlap',
    'scan_precise_overlap',
    'scan_uv_name',
    'scan_mesh_count',
    'scan_flipped_count',
    'scan_zero_count',
    'scan_out_count',
    'scan_overlap_count',
    'scan_stretch_count',
    'scan_stretch_worst',
    'scan_stretch_avg',
    'health_status',
    'health_message',
    'health_checked_time',
    'health_issue_count',
    'health_missing_uv_count',
    'health_missing_active_uv_count',
    'health_icon_count',
    'health_cache_entries',
    'health_last_operator',
    'health_last_error',
    'last_snapshot_name',
    'batch_last_summary',
})


def _iter_workspace_props(ws=None) -> list[str]:
    """Return workspace PropertyGroup names without RNA introspection.

    This intentionally ignores the ``ws`` argument.  Timer callbacks and live
    extension reloads must not keep or inspect RNA PropertyGroup objects because
    Blender can crash before Python can catch the error.
    """
    del ws
    global _WORKSPACE_PROP_NAMES_CACHE
    if _WORKSPACE_PROP_NAMES_CACHE is not None:
        return list(_WORKSPACE_PROP_NAMES_CACHE)

    names: list[str] = []
    seen: set[str] = set()

    def _add(value: object) -> None:
        name = str(value or '').strip()
        if not name or name in seen or name == 'rna_type' or name.startswith('_') or name.startswith('bl_'):
            return
        seen.add(name)
        names.append(name)

    for name in _read_workspace_prop_names_from_source():
        if name not in _TRANSIENT_WORKSPACE_PROPS:
            _add(name)

    if not names:
        try:
            for name in dict(_peek_state_18168().get('workspace', {}) or {}).keys():
                if name not in _TRANSIENT_WORKSPACE_PROPS:
                    _add(name)
        except Exception:
            pass

    _WORKSPACE_PROP_NAMES_CACHE = tuple(names)
    return list(_WORKSPACE_PROP_NAMES_CACHE)


def _restore_workspace_before_scene_save(context=None) -> None:
    """Restore canonical values before a new scene can save its defaults."""
    global _LAST_WORKSPACE_SCENE_ID
    if _APPLYING_WORKSPACE:
        return
    ctx = context or getattr(bpy, 'context', None)
    scene = getattr(ctx, 'scene', None) if ctx is not None else None
    scene_id = id(scene) if scene is not None else None
    if scene_id is None:
        return
    if _LAST_WORKSPACE_SCENE_ID is None:
        _LAST_WORKSPACE_SCENE_ID = scene_id
        return
    if scene_id == _LAST_WORKSPACE_SCENE_ID:
        return
    try:
        apply_workspace(ctx)
    finally:
        _LAST_WORKSPACE_SCENE_ID = scene_id


def capture_workspace(context=None, ws=None) -> dict[str, Any]:
    # Do not trust a PropertyGroup object that was passed through a timer or a
    # hot-reload boundary.  Re-acquire the active scene workspace for every save.
    del ws
    _restore_workspace_before_scene_save(context)
    ws = _current_workspace(context)
    if ws is None:
        return {}
    values: dict[str, Any] = {}
    for name in _iter_workspace_props(ws):
        try:
            value = getattr(ws, name)
        except Exception:
            continue
        json_value = _to_json_value(value)
        if json_value is not Ellipsis:
            values[name] = json_value
    return values


def save_workspace(context=None, ws=None) -> None:
    if _APPLYING_WORKSPACE:
        return
    values = capture_workspace(context, ws)
    if not values:
        return
    data = load_state()
    current = dict(data.get('workspace', {}) or {})
    if current == values:
        return
    data['workspace'] = values
    save_state()


def force_save_workspace(context=None, ws=None) -> None:
    """Write workspace state to Smart_UV_Suite.json immediately."""
    values = capture_workspace(context, ws)
    if not values:
        return
    data = load_state()
    data['workspace'] = values
    save_state(force=True)


def flush_all(context=None, *, prefs=None) -> None:
    """Capture every Smart UV N-panel owner and commit at most once."""
    ctx = context or getattr(bpy, 'context', None)
    data = load_state()
    try:
        workspace = capture_workspace(ctx)
        if workspace:
            data['workspace'] = workspace
    except Exception:
        pass
    try:
        uv_editor = capture_uv_editor(ctx)
        if uv_editor:
            data['uv_editor'] = uv_editor
    except Exception:
        pass
    try:
        from . import preferences as _prefs
        target = prefs if prefs is not None else _prefs.runtime_preferences(ctx)
        capture = getattr(_prefs, '_capture_settings_values', None)
        values = capture(target) if callable(capture) else {}
        if values:
            current = dict(data.get('addon_preferences', {}) or {})
            current.update(values)
            data['addon_preferences'] = current
    except Exception:
        pass
    try:
        save_state(force=True)
    except Exception:
        pass


def _autosave_timer():
    try:
        if not get_state_save_enabled(True):
            return None
        # Do not collect/write N-panel state continuously while the viewport is
        # being navigated.  Individual setting update callbacks save immediately;
        # this timer is only a quiet fallback for already-marked dirty state.
        if bool(_DIRTY):
            flush_all(getattr(bpy, 'context', None))
            return _AUTOSAVE_TIMER_INTERVAL if bool(_DIRTY) else None
        return None
    except Exception:
        pass
    return None


_SINGLE_ISLAND_PERCENT_PROPS = {
    'smart_standard_core_seam_merge_strength',
}


def _migrate_single_island_percent_value(name: str, value: Any, migrate_from_normalized: bool) -> Any:
    """Migrate pre-6 saved Single アイランド values from 0..1 to 0..100 only once."""
    if str(name) not in _SINGLE_ISLAND_PERCENT_PROPS:
        return value
    try:
        f = float(value)
    except Exception:
        return value
    if f != f:
        return 0.0
    if migrate_from_normalized and 0.0 < f <= 1.0:
        f *= 100.0
    return max(0.0, min(100.0, f))


def apply_workspace(context=None, ws=None) -> int:
    global _APPLYING_WORKSPACE, _LAST_WORKSPACE_SCENE_ID
    del ws
    ctx = context or getattr(bpy, 'context', None)
    scene = getattr(ctx, 'scene', None) if ctx is not None else None
    scene_id = id(scene) if scene is not None else None
    ws = _current_workspace(ctx)
    if ws is None:
        return 0
    state = load_state()
    values = dict(state.get('workspace', {}) or {})
    if not values:
        _LAST_WORKSPACE_SCENE_ID = scene_id
        return 0
    try:
        migrate_single_percent = int(state.get('_loaded_version', _STATE_VERSION) or _STATE_VERSION) < 6
    except Exception:
        migrate_single_percent = False
    applied = 0
    _APPLYING_WORKSPACE = True
    try:
        # Preset selector callbacks intentionally rewrite their dependent
        # controls.  Apply those drivers first, then replay every saved leaf so
        # a user's manual adjustments remain authoritative after scene changes.
        driver_names = (
            # This callback selects the active UV layer and mirrors its index
            # into the Smart Standard source/target fields. Run it before the
            # saved leaf fields so their explicit values win deterministically.
            'unwrap_map_channel',
            'unified_auto_pack_mode',
            'smart_unwrap_preset',
            'auto_unwrap_preset',
            'auto_seam_preset',
            'smart_standard_seam_profile',
            'smart_standard_unwrap_mode',
            'auto_seam_profile',
        )
        ordered_names = [name for name in driver_names if name in values]
        ordered_names.extend(name for name in values if name not in driver_names)
        for name in ordered_names:
            value = values[name]
            try:
                getattr(ws, name)
            except Exception:
                continue
            try:
                setattr(ws, name, _migrate_single_island_percent_value(name, value, migrate_single_percent))
                applied += 1
            except Exception:
                continue
    finally:
        _APPLYING_WORKSPACE = False
        _LAST_WORKSPACE_SCENE_ID = scene_id
    if migrate_single_percent:
        try:
            state['_loaded_version'] = _STATE_VERSION
            state['version'] = _STATE_VERSION
            save_state(force=True)
        except Exception:
            pass
    return applied


@persistent
def _load_pre_handler(_dummy=None):
    # Do not snapshot the WindowManager/Scene that Blender is replacing.  The
    # newly opened file recreates those RNA owners, and their short-lived
    # defaults previously overwrote the canonical common-section and workspace
    # values immediately before load_post could restore them.
    return None


@persistent
def _load_post_handler(_dummy=None):
    try:
        # Workspace, UV-editor and always-on state restoration never writes an
        # Object transform.  Avoid the old scene-wide matrix snapshot here.
        try:
            load_state(force=True)
        except Exception:
            pass
        try:
            apply_workspace(getattr(bpy, 'context', None))
        except Exception:
            pass
        try:
            apply_uv_editor(getattr(bpy, 'context', None))
        except Exception:
            pass
        try:
            _subscribe_native_uv_settings()
        except Exception:
            pass
        try:
            root = __import__(__package__, fromlist=['_sus_restore_always_on_features_from_store'])
            restore = getattr(root, '_sus_restore_always_on_features_from_store', None)
            if callable(restore):
                restore(getattr(bpy, 'context', None), startup=False)
        except Exception:
            pass
        # Legacy bake-origin markers are cleaned once at the canonical Smart UV
        # load boundary.  The other persistence handlers no longer repeat this
        # full Object scan.
        try:
            from .transform_persistence_guard import remove_stale_smart_uv_transform_markers
            remove_stale_smart_uv_transform_markers()
        except Exception:
            pass
    except Exception:
        pass


@persistent
def _save_pre_handler(_dummy=None):
    try:
        flush_all(getattr(bpy, 'context', None))
    except Exception:
        pass


def _suv_stage_001_register() -> None:
    global _REGISTERED
    if _REGISTERED:
        return
    _REGISTERED = True
    try:
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        if handlers is not None and _load_post_handler not in handlers.load_post:
            None  # 1.8.169: load_post handler disabled
        if handlers is not None and _load_pre_handler not in handlers.load_pre:
            None  # 1.8.169: load_pre handler disabled
        if handlers is not None and _save_pre_handler not in handlers.save_pre:
            None  # 1.8.169: save_pre handler disabled
    except Exception:
        pass
    try:
        load_state(force=True)
        apply_workspace(getattr(bpy, 'context', None))
        apply_uv_editor(getattr(bpy, 'context', None))
        _subscribe_native_uv_settings()
        flush_all(getattr(bpy, 'context', None))
    except Exception:
        pass
    try:
        _sync_autosave_timer()
    except Exception:
        pass



def _suv_stage_001_unregister() -> None:
    global _REGISTERED
    _REGISTERED = False
    _suv_resource.timer_unregister(_autosave_timer)
    _suv_resource.timer_unregister(_deferred_preference_save_timer)
    _suv_resource.msgbus_clear(_UV_EDITOR_MSGBUS_OWNER)
    return None


# Smart UV Suite 1.8.169 strict JSON persistence overrides.
def _sus_18166_no_duplicate_pairs(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise ValueError(f'Duplicate JSON member: {key}')
        out[key] = value
    return out


def _sus_18166_reject_constant(value):
    raise ValueError(f'invalid JSON numeric constant: {value}')


def _sus_18166_validate_state(raw: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise TypeError('state root must be an object')
    allowed = {'version','foldouts','always_on','workspace','addon_preferences','integrated_tools','uv_editor','npanel_state_save','settings'}
    unknown = set(raw) - allowed
    if unknown:
        raise ValueError('unknown state member: ' + ', '.join(sorted(unknown)))
    data = _default_state()
    for key in ('foldouts','always_on','workspace','addon_preferences','integrated_tools','uv_editor'):
        val = raw.get(key, {})
        if val is None:
            val = {}
        if not isinstance(val, dict):
            raise TypeError(f'{key} must be an object')
        data[key] = copy.deepcopy(val)
    if 'settings' in raw:
        if not isinstance(raw['settings'], dict):
            raise TypeError('settings must be an object')
        data['addon_preferences'].update(copy.deepcopy(raw['settings']))
    if 'npanel_state_save' in raw and not isinstance(raw['npanel_state_save'], bool):
        raise TypeError('npanel_state_save must be boolean')
    data['npanel_state_save'] = bool(raw.get('npanel_state_save', data['npanel_state_save']))
    if 'version' in raw:
        if not isinstance(raw['version'], int):
            raise TypeError('version must be integer')
        data['version'] = int(raw['version'])
    return data


def _read_json_file(path: Path) -> dict[str, Any]:
    raw_text = path.read_text(encoding="utf-8")
    raw = json.loads(
        raw_text,
        object_pairs_hook=_sus_18168_pairs,
        parse_constant=_sus_18168_constant,
    )
    return _sus_18168_validate_state(raw)


def _merge_state_payload(data: dict[str, Any], raw: dict[str, Any]) -> None:
    validated = _sus_18166_validate_state(raw)
    for key in ('foldouts','always_on','workspace','addon_preferences','integrated_tools','uv_editor'):
        data[key].update(copy.deepcopy(validated.get(key, {})))
    data['npanel_state_save'] = bool(validated.get('npanel_state_save', True))
    try:
        data['version'] = int(validated.get('version', _STATE_VERSION) or _STATE_VERSION)
    except Exception:
        data['version'] = _STATE_VERSION


def save_state(*, force: bool = False) -> None:
    """Strict same-directory unique-temp atomic save with readback verification."""
    global _DIRTY
    if _REGISTRATION_WRITE_GUARD_DEPTH > 0:
        return
    data = load_state()
    if (not bool(data.get('npanel_state_save', True))
            and _STATE_SAVE_SELF_COMMIT_DEPTH <= 0):
        _DIRTY = True
        return
    import tempfile
    path = state_path(create=True)
    directory = path.parent
    serializable = _sus_18169_serializable_state(dict(data, version=_STATE_VERSION))
    payload = _sus_18168_validate_state(serializable)
    serialized = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + '\n'
    try:
        if path.exists() and path.read_text(encoding='utf-8') == serialized:
            _DIRTY = False
            return
    except Exception:
        pass
    old_exists = path.exists()
    old_bytes = b''
    if old_exists:
        try:
            old_bytes = path.read_bytes()
            _read_json_file(path)
        except Exception as exc:
            _DIRTY = True
            raise ValueError('existing Smart UV N-panel state is invalid; original preserved') from exc
    fd, temp_name = tempfile.mkstemp(prefix='.' + path.name + '.', suffix='.tmp', dir=str(directory))
    temp_path = Path(temp_name)
    committed = False
    replaced = False
    try:
        with os.fdopen(fd, 'w', encoding='utf-8', newline='\n') as handle:
            handle.write(serialized)
            handle.flush()
            os.fsync(handle.fileno())
        staged = temp_path.read_text(encoding='utf-8')
        parsed = json.loads(staged, object_pairs_hook=_sus_18168_pairs, parse_constant=_sus_18168_constant)
        if _sus_18168_validate_state(parsed) != payload or staged != serialized:
            raise OSError('staged state readback mismatch')
        os.replace(str(temp_path), str(path))
        replaced = True
        _sus_18168_dir_fsync(directory)
        final_text = path.read_text(encoding='utf-8')
        final_raw = json.loads(final_text, object_pairs_hook=_sus_18168_pairs, parse_constant=_sus_18168_constant)
        if _sus_18168_validate_state(final_raw) != payload or final_text != serialized:
            raise OSError('committed state readback mismatch')
        committed = True
        _DIRTY = False
    except Exception:
        if replaced and not committed:
            try:
                if old_exists:
                    restore_fd, restore_name = tempfile.mkstemp(prefix='.' + path.name + '.restore.', suffix='.tmp', dir=str(directory))
                    restore_path = Path(restore_name)
                    try:
                        with os.fdopen(restore_fd, 'wb') as handle:
                            handle.write(old_bytes)
                            handle.flush()
                            os.fsync(handle.fileno())
                        os.replace(str(restore_path), str(path))
                        _sus_18168_dir_fsync(directory)
                    finally:
                        if restore_path.exists():
                            restore_path.unlink()
                elif path.exists():
                    path.unlink()
                    _sus_18168_dir_fsync(directory)
            except Exception:
                pass
        _DIRTY = True
        raise
    finally:
        try:
            if temp_path.exists():
                temp_path.unlink()
        except Exception:
            pass


# -----------------------------------------------------------------------------
# Smart UV Suite 1.8.169 strict idle-resource lifecycle override
# -----------------------------------------------------------------------------
def _suv_stage_002_register() -> None:  # type: ignore[no-redef]
    """Lifecycle registration without persistent handlers, msgbus, or timers."""
    global _REGISTERED
    if _REGISTERED:
        return
    _REGISTERED = True
    try:
        load_state(force=True)
        apply_workspace(getattr(bpy, 'context', None))
        apply_uv_editor(getattr(bpy, 'context', None))
    except Exception:
        pass



def _suv_stage_002_unregister() -> None:
    global _REGISTERED
    _REGISTERED = False
    _suv_resource.timer_unregister(_autosave_timer)
    _suv_resource.timer_unregister(_deferred_preference_save_timer)
    _suv_resource.msgbus_clear(_UV_EDITOR_MSGBUS_OWNER)
    return None

# -----------------------------------------------------------------------------
# Smart UV Suite 1.8.169 authoritative strict, atomic, event-driven persistence
# -----------------------------------------------------------------------------
_STATE_VERSION = 8


def _sus_18168_pairs(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise ValueError(f"duplicate JSON member: {key}")
        out[key] = value
    return out


def _sus_18168_constant(value):
    raise ValueError(f"invalid JSON numeric constant: {value}")


def _sus_18168_json_value(value: Any, path: str = "$") -> Any:
    if value is None or isinstance(value, (str, bool, int)):
        return copy.deepcopy(value)
    if isinstance(value, float):
        import math
        if not math.isfinite(value):
            raise ValueError(f"non-finite number at {path}")
        return float(value)
    if isinstance(value, list):
        return [_sus_18168_json_value(item, f"{path}[{index}]") for index, item in enumerate(value)]
    if isinstance(value, dict):
        out = {}
        for key, item in value.items():
            if not isinstance(key, str):
                raise TypeError(f"non-string member name at {path}")
            out[key] = _sus_18168_json_value(item, f"{path}.{key}")
        return out
    raise TypeError(f"unsupported JSON value at {path}: {type(value).__name__}")


def _sus_18169_validate_bool_map(value: Any, path: str) -> dict[str, bool]:
    if not isinstance(value, dict):
        raise TypeError(f'{path} must be an object')
    out: dict[str, bool] = {}
    for key, item in value.items():
        if not isinstance(key, str) or not key.strip():
            raise TypeError(f'{path} member names must be non-empty strings')
        if not isinstance(item, bool):
            raise TypeError(f'{path}.{key} must be a boolean')
        out[key] = item
    return out


def _sus_18169_serializable_state(data: dict[str, Any]) -> dict[str, Any]:
    keys = ('version', 'foldouts', 'always_on', 'workspace', 'addon_preferences', 'integrated_tools', 'uv_editor', 'npanel_state_save', 'stores')
    return {key: data[key] for key in keys if key in data}


def _sus_18169_validate_typed_map(value: Any, schema: Any, path: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise TypeError(f"{path} must be an object")
    # 1.8.230 fail-soft: unknown members are STRIPPED, never fatal.  A raise
    # here used to kill every save (capture_workspace collects members the
    # strict schema did not list, every caller swallowed the exception, so no
    # state was ever written) and to discard the ENTIRE saved file on load
    # when a stale key from a removed feature (e.g. the retired
    # operation_uv_smart_grs_keymaps_enabled) was present.  Known members are
    # still strictly type-checked.
    out: dict[str, Any] = {}
    import math
    for key, item in value.items():
        if key not in schema:
            continue
        expected = schema[key]
        location = f"{path}.{key}"
        if expected == "bool":
            if type(item) is not bool:
                raise TypeError(f"{location} must be a boolean")
        elif expected == "int":
            if type(item) is not int:
                raise TypeError(f"{location} must be an integer")
        elif expected == "number":
            if isinstance(item, bool) or not isinstance(item, (int, float)) or not math.isfinite(float(item)):
                raise TypeError(f"{location} must be a finite number")
        elif expected == "str":
            if type(item) is not str:
                raise TypeError(f"{location} must be a string")
        elif expected in {"list_bool", "list_int", "list_number"}:
            if type(item) is not list:
                raise TypeError(f"{location} must be an array")
            for index, member in enumerate(item):
                member_path = f"{location}[{index}]"
                if expected == "list_bool" and type(member) is not bool:
                    raise TypeError(f"{member_path} must be a boolean")
                if expected == "list_int" and type(member) is not int:
                    raise TypeError(f"{member_path} must be an integer")
                if expected == "list_number" and (isinstance(member, bool) or not isinstance(member, (int, float)) or not math.isfinite(float(member))):
                    raise TypeError(f"{member_path} must be a finite number")
        else:
            raise ValueError(f"unsupported schema type at {location}: {expected}")
        out[key] = copy.deepcopy(item)
    return out


def _sus_18168_validate_state(raw: Any) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise TypeError('state root must be an object')
    allowed = {
        'version', 'foldouts', 'always_on', 'workspace', 'addon_preferences',
        'integrated_tools', 'uv_editor', 'npanel_state_save', 'settings', 'stores',
    }
    unknown = set(raw) - allowed
    if unknown:
        raise ValueError('unknown state member: ' + ', '.join(sorted(unknown)))
    if 'version' in raw and (not isinstance(raw['version'], int) or isinstance(raw['version'], bool)):
        raise TypeError('version must be an integer')
    if 'npanel_state_save' in raw and not isinstance(raw['npanel_state_save'], bool):
        raise TypeError('npanel_state_save must be a boolean')
    result = _default_state()
    result['version'] = int(raw.get('version', _STATE_VERSION))
    result['npanel_state_save'] = raw.get('npanel_state_save', True)
    result['foldouts'] = _sus_18169_validate_bool_map(raw.get('foldouts', {}), '$.foldouts')
    result['always_on'] = _sus_18169_validate_bool_map(raw.get('always_on', {}), '$.always_on')
    result['integrated_tools'] = _sus_18169_validate_bool_map(raw.get('integrated_tools', {}), '$.integrated_tools')
    result['workspace'] = _sus_18169_validate_typed_map(
        raw.get('workspace', {}), _strict_schema.WORKSPACE_SCHEMA, '$.workspace'
    )
    result['addon_preferences'] = _sus_18169_validate_typed_map(
        raw.get('addon_preferences', {}), _strict_schema.ADDON_PREFERENCES_SCHEMA, '$.addon_preferences'
    )
    result['uv_editor'] = _sus_18169_validate_typed_map(
        raw.get('uv_editor', {}), _strict_schema.UV_EDITOR_SCHEMA, '$.uv_editor'
    )
    if 'settings' in raw:
        result['addon_preferences'].update(_sus_18169_validate_typed_map(
            raw['settings'], _strict_schema.ADDON_PREFERENCES_SCHEMA, '$.settings'
        ))
    stores = raw.get('stores', {})
    if not isinstance(stores, dict):
        raise TypeError('$.stores must be an object')
    result['stores'] = {}
    for store_name, store_value in stores.items():
        if not isinstance(store_name, str) or not store_name.strip():
            raise TypeError('$.stores member names must be non-empty strings')
        if not isinstance(store_value, dict):
            raise TypeError(f'$.stores.{store_name} must be an object')
        result['stores'][store_name] = _sus_18168_json_value(store_value, f'$.stores.{store_name}')
    return result



def _read_json_file(path: Path) -> dict[str, Any]:  # type: ignore[no-redef]
    raw_text = path.read_text(encoding="utf-8")
    raw = json.loads(
        raw_text,
        object_pairs_hook=_sus_18168_pairs,
        parse_constant=_sus_18168_constant,
    )
    return _sus_18168_validate_state(raw)


def load_state(force: bool = False) -> dict[str, Any]:  # type: ignore[no-redef]
    """Lifecycle/event-boundary load; corrupt originals are retained unchanged."""
    global _STATE_CACHE
    if isinstance(_STATE_CACHE, dict) and not force:
        return _STATE_CACHE
    data = _default_state()
    source = state_path(create=False)
    candidates = [source] if source.exists() else [p for p in _legacy_state_paths() if p.exists()]
    for path in candidates:
        try:
            loaded = _read_json_file(path)
        except Exception:
            # No rename/delete/overwrite.  Use defaults and retain source bytes.
            continue
        data.update(loaded)
        break
    try:
        data["_loaded_version"] = int(data.get("version", _STATE_VERSION))
    except Exception:
        data["_loaded_version"] = _STATE_VERSION
    data["version"] = _STATE_VERSION
    _STATE_CACHE = data
    return data


def _sus_18168_dir_fsync(directory: Path) -> None:
    try:
        flags = os.O_RDONLY | int(getattr(os, "O_DIRECTORY", 0) or 0)
        fd = os.open(str(directory), flags)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    except Exception:
        pass


def save_state(*, force: bool = False) -> None:
    """Strict same-directory unique-temp atomic save with readback verification."""
    global _DIRTY
    if _REGISTRATION_WRITE_GUARD_DEPTH > 0:
        return
    data = load_state()
    if (not bool(data.get('npanel_state_save', True))
            and _STATE_SAVE_SELF_COMMIT_DEPTH <= 0):
        _DIRTY = True
        return
    import tempfile
    path = state_path(create=True)
    directory = path.parent
    serializable = _sus_18169_serializable_state(dict(data, version=_STATE_VERSION))
    payload = _sus_18168_validate_state(serializable)
    serialized = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + '\n'
    try:
        if path.exists() and path.read_text(encoding='utf-8') == serialized:
            _DIRTY = False
            return
    except Exception:
        pass
    old_exists = path.exists()
    old_bytes = b''
    if old_exists:
        try:
            old_bytes = path.read_bytes()
            _read_json_file(path)
        except Exception as exc:
            _DIRTY = True
            raise ValueError('existing Smart UV N-panel state is invalid; original preserved') from exc
    fd, temp_name = tempfile.mkstemp(prefix='.' + path.name + '.', suffix='.tmp', dir=str(directory))
    temp_path = Path(temp_name)
    committed = False
    replaced = False
    try:
        with os.fdopen(fd, 'w', encoding='utf-8', newline='\n') as handle:
            handle.write(serialized)
            handle.flush()
            os.fsync(handle.fileno())
        staged = temp_path.read_text(encoding='utf-8')
        parsed = json.loads(staged, object_pairs_hook=_sus_18168_pairs, parse_constant=_sus_18168_constant)
        if _sus_18168_validate_state(parsed) != payload or staged != serialized:
            raise OSError('staged state readback mismatch')
        os.replace(str(temp_path), str(path))
        replaced = True
        _sus_18168_dir_fsync(directory)
        final_text = path.read_text(encoding='utf-8')
        final_raw = json.loads(final_text, object_pairs_hook=_sus_18168_pairs, parse_constant=_sus_18168_constant)
        if _sus_18168_validate_state(final_raw) != payload or final_text != serialized:
            raise OSError('committed state readback mismatch')
        committed = True
        _DIRTY = False
    except Exception:
        if replaced and not committed:
            try:
                if old_exists:
                    restore_fd, restore_name = tempfile.mkstemp(prefix='.' + path.name + '.restore.', suffix='.tmp', dir=str(directory))
                    restore_path = Path(restore_name)
                    try:
                        with os.fdopen(restore_fd, 'wb') as handle:
                            handle.write(old_bytes)
                            handle.flush()
                            os.fsync(handle.fileno())
                        os.replace(str(restore_path), str(path))
                        _sus_18168_dir_fsync(directory)
                    finally:
                        if restore_path.exists():
                            restore_path.unlink()
                elif path.exists():
                    path.unlink()
                    _sus_18168_dir_fsync(directory)
            except Exception:
                pass
        _DIRTY = True
        raise
    finally:
        try:
            if temp_path.exists():
                temp_path.unlink()
        except Exception:
            pass




def get_store(name: str) -> dict[str, Any] | None:
    """One named store kept inside Smart_UV_Suite.json (the product's only settings file)."""
    try:
        stores = load_state().get('stores')
        value = stores.get(str(name)) if isinstance(stores, dict) else None
        return copy.deepcopy(value) if isinstance(value, dict) else None
    except Exception:
        return None


def set_store(name: str, payload: dict[str, Any]) -> bool:
    """Put one named store into Smart_UV_Suite.json; no other member of the file is touched.

    The write goes through even while N-panel state saving is OFF, because the stores hold
    switches and preferences that were always saved regardless of that option.
    """
    try:
        clean = _sus_18168_json_value(payload)
        if not isinstance(clean, dict):
            return False
        data = load_state()
        stores = data.get('stores')
        if not isinstance(stores, dict):
            stores = {}
        if stores.get(str(name)) == clean and state_path(create=False).exists():
            return True
        stores = dict(stores)
        stores[str(name)] = clean
        data['stores'] = stores
        if bool(data.get('npanel_state_save', True)):
            save_state()
            return True
        # N-panel state saving is OFF: rewrite the file with its saved members unchanged and the new stores.
        path = state_path(create=True)
        try:
            saved = _read_json_file(path) if path.exists() else _default_state()
        except Exception:
            return False
        saved['stores'] = stores
        saved['version'] = _STATE_VERSION
        text = json.dumps(_sus_18168_validate_state(_sus_18169_serializable_state(saved)),
                          ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + '\n'
        temporary = path.with_name(path.name + '.tmp')
        temporary.write_text(text, encoding='utf-8', newline='\n')
        os.replace(str(temporary), str(path))
        return True
    except Exception:
        return False


def _sync_autosave_timer() -> None:
    _suv_resource.timer_unregister(_autosave_timer)
    _suv_resource.timer_unregister(_deferred_preference_save_timer)


def _schedule_deferred_preference_save_watch() -> None:  # type: ignore[no-redef]
    return None


def register() -> None:  # type: ignore[no-redef]
    """Load/apply at lifecycle boundary; register no timer, handler or msgbus."""
    global _REGISTERED
    if _REGISTERED:
        return
    _REGISTERED = True
    try:
        load_state(force=True)
        apply_workspace(getattr(bpy, "context", None))
        apply_uv_editor(getattr(bpy, "context", None))
    except Exception:
        pass



def unregister() -> None:
    global _REGISTERED
    _REGISTERED = False
    _suv_resource.timer_unregister(_autosave_timer)
    _suv_resource.timer_unregister(_deferred_preference_save_timer)
    _suv_resource.msgbus_clear(_UV_EDITOR_MSGBUS_OWNER)
    return None


def _peek_state_18168() -> dict[str, Any]:
    """Read-only draw snapshot; never creates directories or reads a file."""
    return _STATE_CACHE if isinstance(_STATE_CACHE, dict) else _default_state()
