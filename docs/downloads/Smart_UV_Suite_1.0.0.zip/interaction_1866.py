# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Immediate Select native transform start fix.

Final purpose:
- On an unselected UV element LEFTMOUSE/PRESS, select immediately and start
  Blender native Transform immediately.  Native Transform then owns the same
  still-held mouse drag, including Blender's standard snap, release confirm, and
  axis handling.
- Background presses are pass-through immediately and never enter modal state.
- Selected UV/gizmo presses are pass-through so normal UV selection/gizmo/tweak
  behavior is not affected by the Immediate Select feature.
"""
from __future__ import annotations

import bpy

_PG = None
_VERSION = (1, 8, 66)


def _pg(name, default=None):
    try:
        return _PG.get(name, default) if isinstance(_PG, dict) else default
    except Exception:
        return default


def _base():
    try:
        from . import interaction_1865 as b
        return b
    except Exception:
        return None


def _axis_tuple(context):
    try:
        fn = _pg("_sus_1636_axis_memory_enabled")
        if callable(fn) and not bool(fn(context)):
            return None
    except Exception:
        return None
    try:
        cap = _pg("_sus_1636_capture_axis_from_last_transform_operator")
        if callable(cap):
            cap(context)
    except Exception:
        pass
    try:
        get_axis = _pg("_sus_1636_get_axis")
        axis = str(get_axis(context) if callable(get_axis) else "FREE").upper()
    except Exception:
        axis = "FREE"
    if axis == "U":
        return (True, False, False)
    if axis == "V":
        return (False, True, False)
    return None


def _invoke_native_translate_now(context):
    """Invoke Blender Transform immediately, once, with native snap support.

    No custom snapping is performed. Blender's transform operator reads the UV
    editor snap settings exactly as a standard tweak/drag would.
    """
    axis = _axis_tuple(context)
    kwargs = {"release_confirm": True}
    if axis is not None:
        kwargs["constraint_axis"] = axis
    try:
        return bpy.ops.transform.translate('INVOKE_DEFAULT', **kwargs)
    except TypeError:
        try:
            if axis is not None:
                return bpy.ops.transform.translate('INVOKE_DEFAULT', constraint_axis=axis)
            return bpy.ops.transform.translate('INVOKE_DEFAULT')
        except Exception:
            return {"CANCELLED"}
    except Exception:
        return {"CANCELLED"}


def _instant_invoke_1866(self, context, event):
    b = _base()
    if b is None:
        return {"PASS_THROUGH"}
    try:
        if not b._instant_enabled(context):
            return {"PASS_THROUGH"}
        if str(getattr(event, "type", "")) != "LEFTMOUSE" or str(getattr(event, "value", "")) != "PRESS":
            return {"PASS_THROUGH"}
        if not b._is_uv_context(context):
            return {"PASS_THROUGH"}
        # Leave modified clicks to Blender's standard select/tweak behavior.
        if bool(getattr(event, "shift", False) or getattr(event, "ctrl", False) or getattr(event, "alt", False) or getattr(event, "oskey", False)):
            return {"PASS_THROUGH"}
        if b._event_duplicate(context, event):
            return {"PASS_THROUGH"}
        hit = b._find_hit(context, event)
        if not hit:
            # Background box-select must start without any Smart UV modal state.
            return {"PASS_THROUGH"}
        if b._hit_selected(context, hit):
            # Selected element and gizmo press behavior remains native.
            return {"PASS_THROUGH"}
        if not b._select_hit(context, hit, event):
            return {"PASS_THROUGH"}
        try:
            area = getattr(context, "area", None)
            if area is not None:
                area.tag_redraw()
        except Exception:
            pass
        # Critical change from 1.8.65: do not wait for our modal to receive the
        # drag. Start Blender native Transform immediately while the mouse press
        # is still active. This makes click-select -> direct drag behave like a
        # standard tweak and uses native snap without custom delta math.
        _invoke_native_translate_now(context)
        return {"FINISHED"}
    except Exception:
        return {"PASS_THROUGH"}


def _instant_modal_1866(self, context, event):
    return {"PASS_THROUGH"}


def _patch_instant_class():
    try:
        cls = _pg("SMARTUVSUITE_OT_instant_select_drag_move")
        if not isinstance(cls, type):
            return
        cls.bl_options = {'UNDO'}
        cls.invoke = _instant_invoke_1866
        cls.modal = _instant_modal_1866
        cls._sus1866_press_select_native_transform = True
    except Exception:
        pass


def apply_all(pkg_globals=None, context=None):
    global _PG
    if pkg_globals is not None:
        _PG = pkg_globals
    ctx = context or bpy.context
    try:
        b = _base()
        if b is not None:
            b.apply_all(pkg_globals or _PG, ctx)
    except Exception:
        pass
    _patch_instant_class()
    try:
        if isinstance(_PG, dict):
            bi = _PG.get("bl_info")
            if isinstance(bi, dict):
                bi["version"] = (1, 0, 0)
            _PG["__version__"] = '1.0.0'
            _PG["_sus_1866_press_select_native_transform"] = True
            _PG["_sus_1652_sync_keymaps_from_workspace"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1841_final_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1842_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1845_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1860_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1865_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
    except Exception:
        pass


def install(pkg_globals):
    global _PG
    _PG = pkg_globals
    apply_all(pkg_globals, bpy.context)
