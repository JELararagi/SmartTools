# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Final correction for Immediate Select Drag Move.

Fixes the 1.8.66/1.8.67 regression where native Transform was started on
PRESS and changed normal click behavior, while the 1.8.60 pass-through design
selected on PRESS but did not enter drag transform.

Final behavior:
- background PRESS: immediate PASS_THROUGH, no modal, no heavy work after miss;
- selected UV/gizmo PRESS: PASS_THROUGH, native Blender behavior untouched;
- unselected UV element PRESS: select immediately, hold only that press;
- if the same press becomes a drag: invoke Blender native transform.translate
  exactly once, so native snap/axis/release/undo handle the movement.
"""
from __future__ import annotations

import bpy

_PG = None
_VERSION = (1, 8, 68)


def _pg(name, default=None):
    try:
        return _PG.get(name, default) if isinstance(_PG, dict) else default
    except Exception:
        return default


def _base():
    try:
        from . import interaction_1865 as b
        return b
    except Exception:
        return None


def _axis_tuple(context):
    # Reuse the current axis-memory implementation without doing any custom
    # transform math.  It only supplies Blender native transform's constraint_axis.
    try:
        from . import interaction_1866 as i66
        fn = getattr(i66, "_axis_tuple", None)
        if callable(fn):
            return fn(context)
    except Exception:
        pass
    return None


def _invoke_native_translate_once(context) -> bool:
    axis = _axis_tuple(context)
    kwargs = {"release_confirm": True}
    if axis is not None:
        kwargs["constraint_axis"] = axis
    try:
        res = bpy.ops.transform.translate("INVOKE_DEFAULT", **kwargs)
        return "RUNNING_MODAL" in set(res) or "FINISHED" in set(res)
    except TypeError:
        try:
            if axis is not None:
                res = bpy.ops.transform.translate("INVOKE_DEFAULT", constraint_axis=axis)
            else:
                res = bpy.ops.transform.translate("INVOKE_DEFAULT")
            return "RUNNING_MODAL" in set(res) or "FINISHED" in set(res)
        except Exception:
            return False
    except Exception:
        return False


def _instant_invoke_1868(self, context, event):
    b = _base()
    if b is None:
        return {"PASS_THROUGH"}
    try:
        self._suv1868_active = False
        self._suv1868_started_transform = False
        if not b._instant_enabled(context):
            return {"PASS_THROUGH"}
        if str(getattr(event, "type", "")) != "LEFTMOUSE" or str(getattr(event, "value", "")) != "PRESS":
            return {"PASS_THROUGH"}
        if not b._is_uv_context(context):
            return {"PASS_THROUGH"}
        # Any modified click remains Blender-native.  This prevents changing
        # add/subtract/toggle selection and box/tweak variations.
        if bool(getattr(event, "shift", False) or getattr(event, "ctrl", False) or getattr(event, "alt", False) or getattr(event, "oskey", False)):
            return {"PASS_THROUGH"}
        if b._event_duplicate(context, event):
            return {"PASS_THROUGH"}

        hit = b._find_hit(context, event)
        if not hit:
            # Background box select must receive the original PRESS immediately.
            return {"PASS_THROUGH"}
        if b._hit_selected(context, hit):
            # Selected-element tweak/gizmo/transform is already Blender-native.
            return {"PASS_THROUGH"}
        if not b._select_hit(context, hit, event):
            return {"PASS_THROUGH"}

        try:
            area = getattr(context, "area", None)
            if area is not None:
                area.tag_redraw()
        except Exception:
            pass

        self._suv1868_start_xy = (
            int(getattr(event, "mouse_x", getattr(event, "mouse_region_x", 0)) or 0),
            int(getattr(event, "mouse_y", getattr(event, "mouse_region_y", 0)) or 0),
        )
        self._suv1868_active = True
        self._suv1868_started_transform = False
        try:
            context.window_manager.modal_handler_add(self)
            return {"RUNNING_MODAL"}
        except Exception:
            return {"FINISHED"}
    except Exception:
        return {"PASS_THROUGH"}


def _instant_modal_1868(self, context, event):
    try:
        etype = str(getattr(event, "type", "") or "")
        evalue = str(getattr(event, "value", "") or "")
        if etype in {"ESC", "RIGHTMOUSE"}:
            return {"CANCELLED"}
        if etype == "LEFTMOUSE" and evalue == "RELEASE":
            # Click-only: PRESS already selected the UV element.  No transform.
            return {"FINISHED"}
        if etype in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
            sx, sy = getattr(self, "_suv1868_start_xy", (0, 0))
            mx = int(getattr(event, "mouse_x", getattr(event, "mouse_region_x", 0)) or 0)
            my = int(getattr(event, "mouse_y", getattr(event, "mouse_region_y", 0)) or 0)
            dx = mx - int(sx)
            dy = my - int(sy)
            # Match Blender-like tweak threshold.  Until threshold, do not start
            # transform and do not pass to box select, because this is a real UV hit.
            if dx * dx + dy * dy < 9:
                return {"RUNNING_MODAL"}
            if not bool(getattr(self, "_suv1868_started_transform", False)):
                self._suv1868_started_transform = True
                _invoke_native_translate_once(context)
                return {"FINISHED"}
        return {"RUNNING_MODAL"}
    except Exception:
        return {"FINISHED"}


def _patch():
    try:
        cls = _pg("SMARTUVSUITE_OT_instant_select_drag_move")
        if not isinstance(cls, type):
            return
        cls.bl_options = {'UNDO', 'BLOCKING'}
        cls.invoke = _instant_invoke_1868
        cls.modal = _instant_modal_1868
        cls._sus1868_press_select_drag_native_transform = True
    except Exception:
        pass


def apply_all(pkg_globals=None, context=None):
    global _PG
    if pkg_globals is not None:
        _PG = pkg_globals
    ctx = context or bpy.context
    # Let the previous layer keep keymaps/gizmo-native cleanup intact, then replace
    # only the operator behavior.
    try:
        from . import interaction_1867 as prev
        prev.apply_all(pkg_globals or _PG, ctx)
    except Exception:
        pass
    _patch()
    try:
        if isinstance(_PG, dict):
            bi = _PG.get("bl_info")
            if isinstance(bi, dict):
                bi["version"] = (1, 0, 0)
            _PG["__version__"] = '1.0.0'
            _PG["_sus_1868_press_select_drag_native_transform"] = True
            _PG["_sus_1652_sync_keymaps_from_workspace"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1841_final_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1842_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1845_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1860_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1867_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
    except Exception:
        pass


def install(pkg_globals):
    global _PG
    _PG = pkg_globals
    apply_all(pkg_globals, bpy.context)
