# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import importlib
import os
from pathlib import Path
from typing import Iterable

import bpy

from . import preferences_proxy


def env_flag(name: str, default: bool = False) -> bool:
    value = str(os.environ.get(str(name or ''), '') or '').strip().lower()
    if not value:
        return bool(default)
    return value in {'1', 'true', 'yes', 'on'}


def import_relative(package_name: str, module_name: str):
    return importlib.import_module(f'.{module_name}', package_name)


def _safe_collection_get(collection, key: str):
    if collection is None:
        return None
    try:
        return collection.get(key)
    except Exception:
        try:
            return collection[key]
        except Exception:
            return None


def _package_name_candidates(package_name: str = '', module_name: str = '', file_path: str = '') -> tuple[str, ...]:
    values: list[str] = []

    def _append(candidate: object) -> None:
        text = str(candidate or '').strip().strip('.')
        if not text:
            return
        if text in {'bl_ext', 'bl_ext.user_default'}:
            return
        if text not in values:
            values.append(text)
        if text.startswith('bl_ext.'):
            short = text.rsplit('.', 1)[-1]
            if short and short not in values:
                values.append(short)
        elif '.' in text:
            short = text.rsplit('.', 1)[-1]
            if short and short not in values:
                values.append(short)
        lowered = text.lower()
        if lowered and lowered not in values:
            values.append(lowered)

    _append(package_name)
    _append(module_name)
    try:
        _append(Path(file_path).resolve().parent.name)
    except Exception:
        pass
    _append('uv_suite')
    return tuple(values)


def get_addon_preferences(context=None, package_name: str = '', module_name: str = '', file_path: str = ''):
    context = context or getattr(bpy, 'context', None)

    try:
        settings_mod = import_relative(__package__ or 'uv_suite', 'preferences')
        getter = getattr(settings_mod, 'addon_preferences', None)
        if callable(getter):
            prefs = getter(context)
            if prefs is not None:
                return prefs
    except Exception:
        pass

    for addon_id in _package_name_candidates(package_name, module_name, file_path):
        try:
            prefs = preferences_proxy.get_addon_preferences(context, addon_id)
        except Exception:
            prefs = None
        if prefs is not None:
            return prefs

    # Standard N-panel build: never use AddonPreferences as a live settings host.
    # Integrated tools use preferences_proxy; UV Suite uses preferences.addon_preferences().
    return None


def _is_within(path: object, root: Path) -> bool:
    try:
        resolved = Path(path).resolve()
    except Exception:
        return False
    try:
        return resolved == root or root in resolved.parents
    except Exception:
        return False


def _iter_stale_prefixes(package_name: str = '', module_name: str = '', file_path: str = '') -> tuple[str, ...]:
    prefixes: list[str] = []
    for value in _package_name_candidates(package_name, module_name, file_path):
        text = str(value or '').strip().strip('.')
        if text and text not in prefixes:
            prefixes.append(text)
    return tuple(prefixes)


def preflight_cleanup(package_name: str = '', module_name: str = '', file_path: str = '') -> tuple[str, ...]:
    """Compatibility no-op: lifecycle ownership is handled by the exact ledger."""
    del package_name, module_name, file_path
    return ()



__all__ = [
    'env_flag',
    'get_addon_preferences',
    'import_relative',
    'preflight_cleanup',
]
