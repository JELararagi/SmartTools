# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Undo / Redo guard for Smart UV Suite operator registration."""
from __future__ import annotations

_INTERNAL_HINTS = ("alias", "compat", "dispatcher", "dispatch", "show_help", "toggle_ui_foldout", "bridge")


def _options(value) -> set[str]:
    try:
        return {str(item) for item in (value or set()) if str(item)}
    except Exception:
        return set()


def ensure_class_undo(cls: type) -> type:
    """Ensure Smart UV Suite operator classes participate in Undo/Redo."""
    try:
        import bpy
        if not isinstance(cls, type) or not issubclass(cls, bpy.types.Operator):
            return cls
    except Exception:
        return cls
    opts = _options(getattr(cls, "bl_options", set()))
    if bool(getattr(cls, '_sms_no_undo', False)):
        opts.discard("UNDO")
        opts.discard("UNDO_GROUPED")
    else:
        opts.add("UNDO")
    blob = " ".join(str(getattr(cls, attr, "") or "").lower() for attr in ("__module__", "__name__", "bl_idname", "bl_label"))
    if any(hint in blob for hint in _INTERNAL_HINTS):
        opts.add("INTERNAL")
    else:
        opts.add("REGISTER")
    try:
        cls.bl_options = opts
    except Exception:
        pass
    return cls


def audit_registered_operator_classes():
    """Return ``(count, missing)`` for Smart UV Suite related operators."""
    try:
        import bpy
        base = bpy.types.Operator
    except Exception:
        return 0, []
    count = 0
    missing = []
    for cls in ():
        try:
            blob = " ".join(str(getattr(cls, attr, "") or "") for attr in ("__module__", "__name__", "bl_idname")).lower()
            if not ("smart_uv_suite" in blob or ".suv" in blob or "_suv" in blob):
                continue
            count += 1
            if bool(getattr(cls, '_sms_no_undo', False)):
                continue
            if "UNDO" not in _options(getattr(cls, "bl_options", set())):
                missing.append(str(getattr(cls, "bl_idname", getattr(cls, "__name__", cls))))
        except Exception:
            continue
    return count, sorted(set(missing))


def register() -> None:
    return None


def unregister() -> None:
    return None
