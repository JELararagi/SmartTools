"""Read the registered suite surface, independently of legacy class prefixes."""
from __future__ import annotations
import sys
import bpy


def iter_suite_classes(namespace):
    package = __package__
    sources = [namespace]
    sources.extend(vars(module) for name, module in tuple(sys.modules.items())
                   if name.startswith(package + '.') and module is not None)
    seen = set()
    kinds = ((bpy.types.Operator, 'OT'), (bpy.types.Panel, 'PT'),
             (bpy.types.Menu, 'MT'), (bpy.types.PropertyGroup, 'PG'),
             (bpy.types.AddonPreferences, 'AddonPreferences'))
    for source in sources:
        for cls in tuple(source.values()):
            if not isinstance(cls, type) or cls in seen:
                continue
            seen.add(cls)
            owner = getattr(cls, '__module__', '')
            if owner != package and not owner.startswith(package + '.'):
                continue
            if not getattr(cls, 'is_registered', False):
                continue
            for base, kind in kinds:
                if issubclass(cls, base):
                    suffix = cls.__name__.split('_' + kind + '_', 1)[-1]
                    yield 'SUV_' + kind + '_' + suffix, cls
                    break


def class_namespace(namespace):
    result = dict(namespace)
    result.update(iter_suite_classes(namespace))
    return result
