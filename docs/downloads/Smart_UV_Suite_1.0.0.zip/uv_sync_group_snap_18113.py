# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Smart UV Suite 1.8.113: UV Sync, grouped island distribution, and snap fixes."""
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

from collections import defaultdict
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple
import math
import sys

import bpy
from mathutils import Vector

from . import uv_room_integrity_18103 as ri
from . import uv_multi_object_18104 as mo
from . import uv_loop_group_integrity_18109 as lgi

_VERSION = (1, 8, 113)
_NS: Dict[str, Any] = {}
_PREV: Dict[str, Any] = {}
_EPS = 1.0e-12
_DIGITS = 7
_GROUP_DISTRIBUTE_ACTIONS = {"DISTRIBUTE_H_GROUP", "DISTRIBUTE_V_GROUP"}


def _s(value: Any) -> str:
    try:
        return str(value or "")
    except Exception:
        return ""


def _tr(context: Any, en: str, ja: str) -> str:
    try:
        return ri._tr(context, en, ja)
    except Exception:
        try:
            lang = str(getattr(getattr(context, "preferences", None).view, "language", "") or "")
            return ja if lang.startswith("ja") else en
        except Exception:
            return ja or en


def _report(op: Any, level: str, message: str) -> None:
    try:
        op.report({level}, message)
    except Exception:
        pass


def _tool_settings(context: Any = None) -> Any:
    ctx = context or getattr(bpy, "context", None)
    try:
        ts = getattr(ctx, "tool_settings", None)
        if ts is not None:
            return ts
    except Exception:
        pass
    try:
        return getattr(getattr(ctx, "scene", None), "tool_settings", None)
    except Exception:
        return None


def _sync_on(context: Any = None) -> bool:
    try:
        return bool(getattr(_tool_settings(context), "use_uv_select_sync", False))
    except Exception:
        return False


def _sync_aware_uv_mode(context: Any = None) -> str:
    """Return the effective UV mode, using mesh_select_mode while UV Sync is on."""
    ts = _tool_settings(context)
    if ts is not None and _sync_on(context):
        try:
            mesh_mode = tuple(bool(v) for v in getattr(ts, "mesh_select_mode", (True, False, False)))
            if len(mesh_mode) >= 3:
                if mesh_mode[2]:
                    return "FACE"
                if mesh_mode[1]:
                    return "EDGE"
                return "VERTEX"
        except Exception:
            pass
    prev = _PREV.get("ri_uv_mode")
    if callable(prev) and prev is not _sync_aware_uv_mode:
        try:
            return str(prev(context) or "VERTEX").upper()
        except Exception:
            pass
    try:
        raw = getattr(ts, "uv_select_mode", "VERTEX")
        if isinstance(raw, (set, list, tuple)):
            vals = {str(v).upper() for v in raw}
            if "FACE" in vals or "ISLAND" in vals:
                return "FACE"
            if "EDGE" in vals:
                return "EDGE"
            return "VERTEX"
        text = str(raw or "VERTEX").upper()
        if "ISLAND" in text or "FACE" in text:
            return "FACE"
        if "EDGE" in text:
            return "EDGE"
    except Exception:
        pass
    return "VERTEX"


def _sus_1810_uv_mode_sync(context: Any = None) -> str:
    return _sync_aware_uv_mode(context)


def _live_v_sync(loop: Any, uv_layer: Any) -> bool:
    try:
        if ri._live_v(loop, uv_layer):
            return True
    except Exception:
        pass
    if _sync_on(getattr(bpy, "context", None)):
        try:
            return bool(getattr(loop.vert, "select", False))
        except Exception:
            pass
    return False


def _live_e_sync(loop: Any, uv_layer: Any) -> bool:
    try:
        if ri._live_e(loop, uv_layer):
            return True
    except Exception:
        pass
    if _sync_on(getattr(bpy, "context", None)):
        try:
            return bool(getattr(loop.edge, "select", False))
        except Exception:
            pass
    return False


def _collect_uv_editor_selection_sync(obj: Any, bm: Any, uv_layer: Any, mode: str):
    mode = _s(mode).upper() or _sync_aware_uv_mode(bpy.context)
    try:
        loops, edge_loops, faces = ri._selected_sets(bpy.context, obj, bm, uv_layer, mode)
    except Exception:
        prev = _PREV.get("lgi_collect")
        if callable(prev) and prev is not _collect_uv_editor_selection_sync:
            return prev(obj, bm, uv_layer, mode)
        return [], set(), set()

    records: List[Dict[str, Any]] = []
    seen: Set[Tuple[int, int, int]] = set()

    def add(loop: Any) -> None:
        try:
            if loop is None or lgi._hidden(loop) or lgi._hidden(getattr(loop, "face", None)):
                return
            key = lgi._loop_record_key(obj, loop)
            if key in seen:
                return
            seen.add(key)
            records.append(lgi._make_record(obj, loop, uv_layer))
        except Exception:
            pass

    for loop in list(loops or set()):
        add(loop)
    if mode == "EDGE":
        for loop in list(edge_loops or set()):
            add(loop)
            try:
                add(loop.link_loop_next)
            except Exception:
                pass
    elif mode == "FACE":
        for face in list(faces or set()):
            try:
                for loop in face.loops:
                    add(loop)
            except Exception:
                pass
        for loop in list(edge_loops or set()):
            add(loop)
            try:
                add(loop.link_loop_next)
            except Exception:
                pass
    try:
        return lgi._unique_records(records), set(edge_loops or set()), set(faces or set())
    except Exception:
        return records, set(edge_loops or set()), set(faces or set())


def _live_edge_loops_sync(bm: Any, uv_layer: Any) -> Set[Any]:
    out: Set[Any] = set()
    try:
        mode = _sync_aware_uv_mode(bpy.context)
        _loops, edge_loops, _faces = ri._selected_sets(bpy.context, None, bm, uv_layer, "EDGE" if mode != "FACE" else mode)
        out.update(edge_loops or set())
    except Exception:
        pass
    if out:
        return out
    prev = _PREV.get("lgi_live_edge_loops")
    if callable(prev) and prev is not _live_edge_loops_sync:
        try:
            return set(prev(bm, uv_layer) or set())
        except Exception:
            pass
    return set()

def _apply_selection_sync_flush(context: Any, obj: Any, bm: Any, uv_layer: Any, mode: str, loops: Iterable[Any], edge_loops: Iterable[Any], faces: Iterable[Any]) -> None:
    prev = _PREV.get("ri_apply_selection")
    if callable(prev) and prev is not _apply_selection_sync_flush:
        prev(context, obj, bm, uv_layer, mode, loops, edge_loops, faces)
    else:
        # Conservative fallback matching uv_room_integrity_18103._apply_selection enough
        # to avoid leaving Blender with an empty mesh-selection overlay in Sync mode.
        loops_set = set(loops or [])
        edge_set = set(edge_loops or [])
        face_set = set(faces or [])
        try:
            ri._clear_selection(bm, uv_layer, mesh=_sync_on(context))
        except Exception:
            pass
        for face in face_set:
            try:
                face.select_set(True)
            except Exception:
                pass
            try:
                for loop in face.loops:
                    loops_set.add(loop); edge_set.add(loop)
            except Exception:
                pass
        for loop in edge_set:
            try:
                ri._set_e(loop, uv_layer, True); ri._set_v(loop, uv_layer, True)
                loop.edge.select_set(True); loop.vert.select_set(True); loop.link_loop_next.vert.select_set(True)
            except Exception:
                pass
        for loop in loops_set:
            try:
                ri._set_v(loop, uv_layer, True); loop.vert.select_set(True)
            except Exception:
                pass
    if _sync_on(context):
        try:
            bm.select_flush_mode()
        except Exception:
            pass


def _face_island_map(bm: Any, uv_layer: Any) -> Dict[Any, int]:
    try:
        faces = [f for f in bm.faces if not lgi._hidden(f)]
    except Exception:
        faces = []
    pos = {face: i for i, face in enumerate(faces)}
    parent = list(range(len(faces)))

    def find(i: int) -> int:
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    def union(a: int, b: int) -> None:
        if a < 0 or b < 0 or a >= len(parent) or b >= len(parent):
            return
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    for face in faces:
        try:
            for edge in face.edges:
                la = next((loop for loop in face.loops if loop.edge is edge), None)
                if la is None:
                    continue
                for other in edge.link_faces:
                    if other is face or other not in pos or lgi._hidden(other):
                        continue
                    lb = next((loop for loop in other.loops if loop.edge is edge), None)
                    if lb is not None and ri._same_uv_edge(la, lb, uv_layer):
                        union(pos[face], pos[other])
        except Exception:
            continue
    return {face: find(pos[face]) for face in faces}


def _group_island_key(group: Sequence[Dict[str, Any]], face_roots: Dict[Any, int]) -> Tuple[int, int, int]:
    for rec in list(group or []):
        try:
            obj = rec.get("obj")
            mesh_key = lgi._mesh_key(obj)
            face = getattr(rec.get("loop"), "face", None)
            root = face_roots.get(face)
            if root is not None:
                return (mesh_key, int(root), 0)
            return (mesh_key, -1, id(face))
        except Exception:
            pass
    return (-1, -1, id(group))




def _split_group_by_island(group: Sequence[Dict[str, Any]], face_roots: Dict[Any, int]) -> List[Tuple[Tuple[int, int, int], List[Dict[str, Any]]]]:
    """Split a selected visual group by UV island so cross-island selections are never distributed together."""
    buckets: Dict[Tuple[int, int, int], List[Dict[str, Any]]] = defaultdict(list)
    order: List[Tuple[int, int, int]] = []
    for rec in list(group or []):
        try:
            obj = rec.get("obj")
            mesh_key = lgi._mesh_key(obj)
            face = getattr(rec.get("loop"), "face", None)
            root = face_roots.get(face)
            if root is not None:
                key = (mesh_key, int(root), 0)
            else:
                key = (mesh_key, -1, id(face))
            if key not in buckets:
                order.append(key)
            buckets[key].append(rec)
        except Exception:
            key = (-1, -1, id(rec))
            if key not in buckets:
                order.append(key)
            buckets[key].append(rec)
    return [(key, lgi._unique_records(buckets.get(key) or [])) for key in order if buckets.get(key)]




def _selection_key(loop: Any) -> Tuple[int, int]:
    try:
        return (int(getattr(loop.face, "index", -1)), int(getattr(loop, "index", -1)))
    except Exception:
        return (-1, id(loop))


def _snapshot_selection_state(context: Any) -> Dict[str, Any]:
    """Capture UV/mesh selection by stable indices so align tools can restore the orange overlay."""
    data: Dict[str, Any] = {"mode": _sync_aware_uv_mode(context), "entries": [], "state": None}
    try:
        objs, state = mo._ensure_multi_edit(context)
        data["state"] = state
        if not objs:
            return data
        try:
            mo._prepare_unwrap_channel(context)
        except Exception:
            pass
        targets = mo._target_data(context)
        mode = str(data.get("mode") or _sync_aware_uv_mode(context)).upper()
        for obj, bm, uv_layer in targets:
            try:
                ri._ensure_lookup(bm)
            except Exception:
                pass
            try:
                loops, edge_loops, faces = ri._selected_sets(context, obj, bm, uv_layer, mode)
            except Exception:
                loops, edge_loops, faces = set(), set(), set()
            entry = {
                "obj": obj,
                "mesh": getattr(obj, "data", None),
                "loops": {_selection_key(loop) for loop in (loops or set())},
                "edge_loops": {_selection_key(loop) for loop in (edge_loops or set())},
                "faces": {int(getattr(face, "index", -1)) for face in (faces or set())},
                "mesh_verts": set(),
                "mesh_edges": set(),
                "mesh_faces": set(),
            }
            try:
                entry["mesh_verts"] = {int(getattr(v, "index", -1)) for v in bm.verts if bool(getattr(v, "select", False))}
            except Exception:
                pass
            try:
                entry["mesh_edges"] = {int(getattr(e, "index", -1)) for e in bm.edges if bool(getattr(e, "select", False))}
            except Exception:
                pass
            try:
                entry["mesh_faces"] = {int(getattr(f, "index", -1)) for f in bm.faces if bool(getattr(f, "select", False))}
            except Exception:
                pass
            if entry["loops"] or entry["edge_loops"] or entry["faces"] or entry["mesh_verts"] or entry["mesh_edges"] or entry["mesh_faces"]:
                data["entries"].append(entry)
    except Exception:
        pass
    return data


def _restore_selection_state(context: Any, snapshot: Dict[str, Any]) -> None:
    if not isinstance(snapshot, dict):
        return
    entries = list(snapshot.get("entries") or [])
    if not entries:
        return
    try:
        objs, _state = mo._ensure_multi_edit(context)
        if not objs:
            return
        targets = mo._target_data(context)
        by_mesh = {entry.get("mesh"): entry for entry in entries}
        mode = str(snapshot.get("mode") or _sync_aware_uv_mode(context)).upper()
        for obj, bm, uv_layer in targets:
            entry = by_mesh.get(getattr(obj, "data", None))
            if not entry:
                continue
            try:
                ri._ensure_lookup(bm)
            except Exception:
                pass
            face_by_index = {int(getattr(face, "index", -1)): face for face in bm.faces}
            loop_by_key = {}
            for face in bm.faces:
                try:
                    for loop in face.loops:
                        loop_by_key[_selection_key(loop)] = loop
                except Exception:
                    pass
            loops = {loop_by_key[key] for key in set(entry.get("loops") or set()) if key in loop_by_key}
            edge_loops = {loop_by_key[key] for key in set(entry.get("edge_loops") or set()) if key in loop_by_key}
            faces = {face_by_index[idx] for idx in set(entry.get("faces") or set()) if idx in face_by_index}
            ri._apply_selection(context, obj, bm, uv_layer, mode, loops, edge_loops, faces)
            if _sync_on(context):
                try:
                    for v in bm.verts:
                        if int(getattr(v, "index", -1)) in set(entry.get("mesh_verts") or set()):
                            v.select_set(True)
                except Exception:
                    pass
                try:
                    for e in bm.edges:
                        if int(getattr(e, "index", -1)) in set(entry.get("mesh_edges") or set()):
                            e.select_set(True)
                except Exception:
                    pass
                try:
                    for f in bm.faces:
                        if int(getattr(f, "index", -1)) in set(entry.get("mesh_faces") or set()):
                            f.select_set(True)
                except Exception:
                    pass
        mo._update_meshes(targets)
        try:
            area = getattr(context, "area", None)
            if area is not None:
                area.tag_redraw()
        except Exception:
            pass
    except Exception:
        pass


def _restore_snapshot_edit_state(context: Any, snapshot: Dict[str, Any]) -> None:
    try:
        state = snapshot.get("state") if isinstance(snapshot, dict) else None
        if isinstance(state, dict):
            mo._restore_multi_edit(context, state)
    except Exception:
        pass


def _execute_group_distribution_per_island(self: Any, context: Any):
    raw = _s(getattr(self, "action", "ALIGN_CENTER")).upper() or "ALIGN_CENTER"
    if raw not in _GROUP_DISTRIBUTE_ACTIONS:
        prev = _PREV.get("vertex_execute")
        if callable(prev) and prev is not _execute_group_distribution_per_island:
            sel_snapshot = _snapshot_selection_state(context)
            try:
                result = prev(self, context)
            finally:
                _restore_selection_state(context, sel_snapshot)
                _restore_snapshot_edit_state(context, sel_snapshot)
            return result
        return {"CANCELLED"}

    sel_snapshot = _snapshot_selection_state(context)
    snap = ri._snapshot_modes(context)
    objs, state = mo._ensure_multi_edit(context)
    if not objs:
        _report(self, "WARNING", _tr(context, "No mesh object is active.", "アクティブなメッシュオブジェクトがありません。"))
        return {"CANCELLED"}
    try:
        mo._prepare_unwrap_channel(context)
        targets = mo._target_data(context)
        if not targets:
            _report(self, "WARNING", _tr(context, "No editable UV map is available.", "編集可能なUVマップがありません。"))
            return {"CANCELLED"}
        mode = ri._uv_mode(context)
        buckets: Dict[Tuple[int, int, int], List[List[Dict[str, Any]]]] = defaultdict(list)
        all_groups: List[List[Dict[str, Any]]] = []
        for obj, bm, uv_layer in targets:
            records, edge_loops, faces = lgi._collect_uv_editor_selection(obj, bm, uv_layer, mode)
            if not records:
                continue
            face_roots = _face_island_map(bm, uv_layer)
            groups = lgi._strict_uv_groups(obj, bm, uv_layer, mode, records, edge_loops, faces)
            for group in groups:
                try:
                    clean = lgi._unique_records(group)
                except Exception:
                    clean = list(group or [])
                if not clean:
                    continue
                for island_key, island_group in _split_group_by_island(clean, face_roots):
                    if not island_group:
                        continue
                    all_groups.append(island_group)
                    buckets[island_key].append(island_group)
        if not all_groups:
            _report(self, "WARNING", _tr(context, "No UV editor element group is selected.", "UVエディターで選択されたエレメントグループがありません。"))
            return {"CANCELLED"}

        before = lgi._all_active_coords(targets)
        selected = lgi._selected_keys(all_groups)
        axis_u = raw == "DISTRIBUTE_H_GROUP"
        changed = 0
        for island_groups in buckets.values():
            prepared: List[Dict[str, Any]] = []
            for group in island_groups:
                center = lgi._group_center(group, axis_u)
                if center is not None:
                    prepared.append({"records": group, "center": float(center)})
            if len(prepared) <= 1:
                continue
            ordered = sorted(prepared, key=lambda item: float(item.get("center", 0.0)))
            start = float(ordered[0]["center"])
            end = float(ordered[-1]["center"])
            if abs(end - start) <= _EPS:
                continue
            step = (end - start) / float(max(1, len(ordered) - 1))
            for index, item in enumerate(ordered):
                target_value = start + step * index
                changed += lgi._shift_group(item.get("records") or [], axis_u, target_value - float(item.get("center", 0.0)))

        lgi._restore_unselected(targets, before, selected)
        mo._update_meshes(targets)
        try:
            area = getattr(context, "area", None)
            if area is not None:
                area.tag_redraw()
        except Exception:
            pass
        return {"FINISHED"} if changed > 0 else {"CANCELLED"}
    except Exception as exc:
        _report(self, "WARNING", _tr(context, "Grouped vertex distribution failed.", "グループ均等整列に失敗しました。") + f" {exc}")
        return {"CANCELLED"}
    finally:
        try:
            _restore_selection_state(context, sel_snapshot)
        except Exception:
            pass
        ri._restore_modes(snap)
        mo._restore_multi_edit(context, state)
        try:
            _restore_snapshot_edit_state(context, sel_snapshot)
        except Exception:
            pass


def _nice_grid_step(value: float) -> float:
    try:
        value = abs(float(value))
        if value <= 1.0e-12:
            return 1.0
        exp = math.floor(math.log10(value))
        base = 10.0 ** exp
        frac = value / base
        if frac <= 1.5:
            nice = 1.0
        elif frac <= 3.5:
            nice = 2.0
        elif frac <= 7.5:
            nice = 5.0
        else:
            nice = 10.0
        return max(nice * base, 1.0e-9)
    except Exception:
        return 1.0


def _grid_subdivisions(context: Any) -> Tuple[int, int]:
    try:
        space = getattr(context, "space_data", None)
        uv_editor = getattr(space, "uv_editor", None) if space is not None else None
        raw = getattr(uv_editor, "custom_grid_subdivisions", None) if uv_editor is not None else None
        if raw is None:
            return 10, 10
        if isinstance(raw, (tuple, list)) and len(raw) >= 2:
            return max(1, int(raw[0])), max(1, int(raw[1]))
        val = max(1, int(raw))
        return val, val
    except Exception:
        return 10, 10


def _visible_grid_step(context: Any, fallback: float = 0.125) -> Vector:
    try:
        from . import consolidated_uv_tools as cut
        return cut._visible_uv_grid_step_18113(context, fallback)
    except Exception:
        pass
    try:
        region = getattr(context, "region", None)
        v2d = getattr(region, "view2d", None)
        if v2d is not None:
            width = max(int(getattr(region, "width", 1024) or 1024), 1)
            height = max(int(getattr(region, "height", 768) or 768), 1)
            cx = max(width // 2, 1)
            cy = max(height // 2, 1)
            center = v2d.region_to_view(float(cx), float(cy))
            # Estimate one visible major grid family from screen distance, then
            # divide by Blender's minor grid count so thin sub-grid lines are valid snap targets.
            off_u = v2d.region_to_view(float(min(width - 1, cx + 64)), float(cy))
            off_v = v2d.region_to_view(float(cx), float(min(height - 1, cy + 64)))
            major_u = _nice_grid_step(abs(float(off_u[0] - center[0])))
            major_v = _nice_grid_step(abs(float(off_v[1] - center[1])))
            su, sv = _grid_subdivisions(context)
            return Vector((max(major_u / float(max(1, su)), 1.0e-9), max(major_v / float(max(1, sv)), 1.0e-9)))
    except Exception:
        pass
    step = max(1.0e-9, float(fallback or 0.125))
    return Vector((step, step))


def _scene_vertex_distance(context: Any, fallback: float = 0.001) -> float:
    for source in (getattr(context, "scene", None), getattr(getattr(context, "scene", None), "suv_workspace", None)):
        try:
            value = getattr(source, "suv_consolidated_snap_vertex_distance", None)
            if value is not None:
                return max(0.0, float(value))
        except Exception:
            pass
    return max(0.0, float(fallback or 0.001))


def _collect_snap_points(context: Any):
    objs, state = mo._ensure_multi_edit(context)
    if not objs:
        return [], [], state
    try:
        mo._prepare_unwrap_channel(context)
    except Exception:
        pass
    targets = mo._target_data(context)
    mode = ri._uv_mode(context)
    points: List[Dict[str, Any]] = []
    buckets: Dict[Tuple[Any, ...], Dict[str, Any]] = {}
    for obj, bm, uv_layer in targets:
        try:
            loops, edge_loops, faces = ri._selected_sets(context, obj, bm, uv_layer, mode)
        except Exception:
            loops, edge_loops, faces = set(), set(), set()
        if mode == "EDGE":
            for loop in list(edge_loops or set()):
                loops.add(loop)
                try:
                    loops.add(loop.link_loop_next)
                except Exception:
                    pass
        elif mode == "FACE":
            for face in list(faces or set()):
                try:
                    for loop in face.loops:
                        loops.add(loop)
                except Exception:
                    pass
        for loop in list(loops or set()):
            try:
                uv = loop[uv_layer].uv
                mesh_key = lgi._mesh_key(obj)
                try:
                    vi = int(getattr(loop.vert, "index", -1))
                except Exception:
                    vi = -1
                key = (mesh_key, vi, round(float(uv.x), _DIGITS), round(float(uv.y), _DIGITS))
                point = buckets.get(key)
                if point is None:
                    point = {"records": [], "u": float(uv.x), "v": float(uv.y)}
                    buckets[key] = point
                    points.append(point)
                point["records"].append((loop, uv_layer))
            except Exception:
                pass
    return points, targets, state


def _write_snap_point(point: Dict[str, Any], u: Optional[float] = None, v: Optional[float] = None) -> int:
    changed = 0
    for loop, uv_layer in list(point.get("records") or []):
        try:
            uv = loop[uv_layer].uv
            if u is not None:
                uv.x = float(u)
            if v is not None:
                uv.y = float(v)
            changed += 1
        except Exception:
            pass
    if u is not None:
        point["u"] = float(u)
    if v is not None:
        point["v"] = float(v)
    return changed


def _snap_grid(points: Sequence[Dict[str, Any]], step: Vector, axis: str) -> int:
    axis = _s(axis).upper() or "BOTH"
    changed = 0
    sx = max(float(getattr(step, "x", step[0] if step else 0.125)), 1.0e-9)
    sy = max(float(getattr(step, "y", step[1] if step else 0.125)), 1.0e-9)
    for point in list(points or []):
        u = float(point.get("u", 0.0)); v = float(point.get("v", 0.0))
        tu = round(u / sx) * sx
        tv = round(v / sy) * sy
        changed += _write_snap_point(point, tu if axis in {"BOTH", "U", "X"} else None, tv if axis in {"BOTH", "V", "Y"} else None)
    return changed


def _snap_vertex(points: Sequence[Dict[str, Any]], distance: float) -> int:
    points = list(points or [])
    if len(points) < 2 or float(distance) < 0.0:
        return 0
    dist = float(distance)
    if dist <= 0.0:
        dist = 1.0e-12
    d2 = dist * dist
    parent = list(range(len(points)))

    def find(i: int) -> int:
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    def union(a: int, b: int) -> None:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    cell_size = max(dist, 1.0e-12)
    cells: Dict[Tuple[int, int], List[int]] = defaultdict(list)
    for i, point in enumerate(points):
        u = float(point.get("u", 0.0)); v = float(point.get("v", 0.0))
        cu = math.floor(u / cell_size); cv = math.floor(v / cell_size)
        for du in (-1, 0, 1):
            for dv in (-1, 0, 1):
                for j in cells.get((cu + du, cv + dv), []):
                    other = points[j]
                    ou = float(other.get("u", 0.0)); ov = float(other.get("v", 0.0))
                    if (u - ou) * (u - ou) + (v - ov) * (v - ov) <= d2 + 1.0e-20:
                        union(i, j)
        cells[(cu, cv)].append(i)

    grouped: Dict[int, List[int]] = defaultdict(list)
    for i in range(len(points)):
        grouped[find(i)].append(i)

    changed = 0
    for ids in grouped.values():
        if len(ids) < 2:
            continue
        center_u = sum(float(points[i].get("u", 0.0)) for i in ids) / float(len(ids))
        center_v = sum(float(points[i].get("v", 0.0)) for i in ids) / float(len(ids))
        for i in ids:
            changed += _write_snap_point(points[i], center_u, center_v)
    return changed


def _snap_execute_18113(self: Any, context: Any):
    points, targets, state = _collect_snap_points(context)
    try:
        if not points:
            _report(self, "WARNING", _tr(context, "No selected UV element was found.", "選択中のUVエレメントがありません。"))
            return {"CANCELLED"}
        mode = _s(getattr(self, "mode", "GRID")).upper() or "GRID"
        axis = _s(getattr(self, "axis", "BOTH")).upper() or "BOTH"
        changed = 0
        if mode == "PIXEL":
            texture_size = max(1, int(getattr(self, "texture_size", 1024) or 1024))
            step = Vector((1.0 / float(texture_size), 1.0 / float(texture_size)))
            changed = _snap_grid(points, step, axis)
        elif mode == "VERTEX":
            # The panel button leaves vertex_distance unset and uses the scene value; an explicit value wins.
            if self.properties.is_property_set("vertex_distance"):
                distance = max(0.0, float(self.vertex_distance))
            else:
                distance = _scene_vertex_distance(context, getattr(self, "vertex_distance", getattr(self, "distance", 0.001)))
            changed = _snap_vertex(points, distance)
        else:
            fallback = float(getattr(self, "grid_size", 0.125) or 0.125)
            changed = _snap_grid(points, _visible_grid_step(context, fallback), axis)
        mo._update_meshes(targets)
        _report(self, "INFO", _tr(context, f"Snapped {len(points)} selected UV point(s).", f"{len(points)} 個の選択UV点をスナップしました。"))
        return {"FINISHED"} if changed else {"CANCELLED"}
    except Exception as exc:
        _report(self, "WARNING", _tr(context, "UV snap failed.", "UV吸着に失敗しました。") + f" {exc}")
        return {"CANCELLED"}
    finally:
        try:
            mo._restore_multi_edit(context, state)
        except Exception:
            pass


def _install_scene_props() -> None:
    try:
        if not hasattr(bpy.types.Scene, "suv_consolidated_snap_vertex_distance"):
            _suv_resource.register_property(bpy.types.Scene, 'suv_consolidated_snap_vertex_distance', bpy.props.FloatProperty(name='Vertex Snap Distance', description='Maximum UV-space distance for Vertex snap. Selected UV vertices inside this distance are moved to the same midpoint position.', default=0.001, min=0.0, max=10.0, precision=6))
    except Exception:
        pass


def _patch_modes(ns: Dict[str, Any]) -> None:
    if callable(getattr(ri, "_uv_mode", None)) and getattr(ri._uv_mode, "__name__", "") != "_sync_aware_uv_mode":
        _PREV.setdefault("ri_uv_mode", ri._uv_mode)
    ri._uv_mode = _sync_aware_uv_mode  # type: ignore[assignment]
    try:
        if isinstance(ns, dict):
            prev = ns.get("_sus_1810_uv_mode")
            if callable(prev) and prev is not _sus_1810_uv_mode_sync:
                _PREV.setdefault("sus_1810_uv_mode", prev)
            ns["_sus_1810_uv_mode"] = _sus_1810_uv_mode_sync
    except Exception:
        pass
    for mod_name in (
        "smart_uv_suite.uv_multi_object_18104",
        "smart_uv_suite.uv_direction_align_1892",
        "smart_uv_suite.uv_group_direction_align_1897",
        "smart_uv_suite.uv_sticky_unified_edit_1896",
        __package__ + ".uv_multi_object_18104" if __package__ else "",
        __package__ + ".uv_direction_align_1892" if __package__ else "",
        __package__ + ".uv_group_direction_align_1897" if __package__ else "",
        __package__ + ".uv_sticky_unified_edit_1896" if __package__ else "",
    ):
        if not mod_name:
            continue
        mod = sys.modules.get(mod_name)
        if mod is not None and hasattr(mod, "_uv_mode"):
            try:
                setattr(mod, "_uv_mode", _sync_aware_uv_mode)
            except Exception:
                pass


def _patch_selection_and_grouping(ns: Dict[str, Any]) -> None:
    if callable(getattr(lgi, "_live_v", None)) and lgi._live_v is not _live_v_sync:
        _PREV.setdefault("lgi_live_v", lgi._live_v)
    if callable(getattr(lgi, "_live_e", None)) and lgi._live_e is not _live_e_sync:
        _PREV.setdefault("lgi_live_e", lgi._live_e)
    if callable(getattr(lgi, "_collect_uv_editor_selection", None)) and lgi._collect_uv_editor_selection is not _collect_uv_editor_selection_sync:
        _PREV.setdefault("lgi_collect", lgi._collect_uv_editor_selection)
    if callable(getattr(lgi, "_live_edge_loops", None)) and lgi._live_edge_loops is not _live_edge_loops_sync:
        _PREV.setdefault("lgi_live_edge_loops", lgi._live_edge_loops)
    if callable(getattr(ri, "_apply_selection", None)) and ri._apply_selection is not _apply_selection_sync_flush:
        _PREV.setdefault("ri_apply_selection", ri._apply_selection)
    try:
        lgi._live_v = _live_v_sync  # type: ignore[assignment]
        lgi._live_e = _live_e_sync  # type: ignore[assignment]
        lgi._collect_uv_editor_selection = _collect_uv_editor_selection_sync  # type: ignore[assignment]
        lgi._live_edge_loops = _live_edge_loops_sync  # type: ignore[assignment]
        ri._apply_selection = _apply_selection_sync_flush  # type: ignore[assignment]
    except Exception:
        pass
    cls = ns.get("SMARTUVSUITE_OT_vertex_align_action") if isinstance(ns, dict) else None
    if isinstance(cls, type):
        cur = getattr(cls, "execute", None)
        if callable(cur) and cur is not _execute_group_distribution_per_island:
            _PREV.setdefault("vertex_execute", cur)
        cls.execute = _execute_group_distribution_per_island


def _patch_snap(ns: Dict[str, Any]) -> None:
    _install_scene_props()
    classes = []
    try:
        from . import consolidated_uv_tools as cut
        cls = getattr(cut, "SMARTUVSUITE_OT_consolidated_snap_uv", None)
        if isinstance(cls, type):
            classes.append(cls)
    except Exception:
        pass
    try:
        cls = ns.get("SMARTUVSUITE_OT_consolidated_snap_uv") if isinstance(ns, dict) else None
        if isinstance(cls, type):
            classes.append(cls)
    except Exception:
        pass
    seen: Set[int] = set()
    for cls in classes:
        if id(cls) in seen:
            continue
        seen.add(id(cls))
        cur = getattr(cls, "execute", None)
        if callable(cur) and cur is not _snap_execute_18113:
            _PREV.setdefault("snap_execute", cur)
        cls.execute = _snap_execute_18113


def _mark_version(ns: Dict[str, Any]) -> None:
    try:
        ns["__version__"] = '1.0.0'
    except Exception:
        pass
    try:
        info = ns.get("bl_info") if isinstance(ns, dict) else None
        if isinstance(info, dict):
            info["version"] = (1, 0, 0)
            info["author"] = "JELararagi"
            ns["_SUS_BL_INFO_FALLBACK"] = dict(info)
    except Exception:
        pass


def install(ns: Optional[Dict[str, Any]] = None, context: Any = None) -> None:
    global _NS
    if isinstance(ns, dict):
        _NS = ns
    source = ns if isinstance(ns, dict) else _NS
    _patch_modes(source)
    _patch_selection_and_grouping(source)
    _patch_snap(source)
    _mark_version(source)


apply_all = install


def register() -> None:
    install(_NS, bpy.context)


def unregister() -> None:
    return None


def diagnostics(context: Any = None) -> Dict[str, Any]:
    return {
        "version": _VERSION,
        "effective_mode": _sync_aware_uv_mode(context or bpy.context),
        "snap_distance_property": bool(hasattr(bpy.types.Scene, "suv_consolidated_snap_vertex_distance")),
        "group_distribution_per_island": True,
        "sync_loop_ring_mesh_mode": True,
    }
