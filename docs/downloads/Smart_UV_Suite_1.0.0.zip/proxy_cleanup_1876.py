# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Exact Smart UV-owned generated datablock cleanup.

Names and prefixes are never ownership evidence.  Cleanup considers only the
exact datablock identities recorded by the Smart UV generation ledger and
requires UUID, owner token and generation to match before removal.
"""
from __future__ import annotations
from typing import Any

try:
    import bpy  # type: ignore
except Exception:
    bpy = None  # type: ignore

from . import ownership_runtime_18168 as _ownership

_REGISTERED = False
_CLASSES: list[type] = []


def _collection_for(datablock: Any) -> Any:
    if bpy is None or datablock is None:
        return None
    # Explicit known Blender collections; no bpy.data or type-wide traversal.
    for name in ("images", "materials", "objects", "texts", "node_groups", "meshes"):
        collection = getattr(getattr(bpy, "data", None), name, None)
        try:
            candidate = collection.get(datablock.name) if collection is not None else None
            if candidate is not None and candidate.as_pointer() == datablock.as_pointer():
                return collection
        except Exception:
            continue
    return None


def cleanup_stale_proxy_data(context=None, *, reason: str = "manual") -> dict[str, int]:
    del context, reason
    stats = {"removed": 0, "skipped_foreign": 0, "failed": 0, "total": 0}
    if bpy is None:
        return stats
    for datablock, owner_uuid, generation in _ownership.owned_datablocks():
        if not _ownership.datablock_is_exact_owned(datablock, owner_uuid, generation):
            stats["skipped_foreign"] += 1
            continue
        collection = _collection_for(datablock)
        if collection is None:
            stats["failed"] += 1
            continue
        try:
            if collection is getattr(bpy.data, "objects", None):
                collection.remove(datablock, do_unlink=True)
            else:
                collection.remove(datablock)
            _ownership.retire_removed_datablock(datablock)
            stats["removed"] += 1
        except Exception:
            stats["failed"] += 1
    stats["total"] = stats["removed"]
    return stats


class SMARTUVSUITE_OT_cleanup_stale_proxy_data(bpy.types.Operator):
    bl_idname = "smart_uv_suite.cleanup_stale_proxy_data"
    bl_label = "Clean Smart UV Generated Data"
    bl_description = "Remove only generated data whose exact identity, UUID, owner token and generation are recorded by Smart UV Suite. / Smart UV Suiteが記録した同一identity・UUID・owner・generationの生成データだけを削除します。"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        del context
        return bpy is not None

    def execute(self, context):
        stats = cleanup_stale_proxy_data(context, reason="operator")
        self.report({"INFO"}, f"Smart UV generated data removed: {stats.get('removed', 0)}")
        return {"FINISHED"}


def register(namespace: dict | None = None) -> None:
    global _REGISTERED
    del namespace
    if bpy is None or _REGISTERED:
        return
    if not _ownership.register_class(SMARTUVSUITE_OT_cleanup_stale_proxy_data):
        raise RuntimeError("Smart UV cleanup operator registration failed")
    _CLASSES[:] = [SMARTUVSUITE_OT_cleanup_stale_proxy_data]
    _REGISTERED = True


def unregister() -> None:
    global _REGISTERED
    for cls in reversed(tuple(_CLASSES)):
        _ownership.unregister_class(cls)
    _CLASSES.clear()
    _REGISTERED = False
