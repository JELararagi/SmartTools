# SPDX-License-Identifier: GPL-3.0-or-later
"""Compatibility import for older Smart UV installers.

Operators are registered by the owning Smart UV modules.
"""


def register():
    return None


def unregister():
    return None
