# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Smart UV Suite canonical operator bridge.

The JELararagi build registers native ``smart_uv_suite.*`` operators through
``unified_uv_tools`` and ``consolidated_uv_tools``.  This legacy bridge is kept as
a no-op module so older imports remain harmless while reference add-on operator
IDs are not exposed or forwarded.
"""
from __future__ import annotations

_ALIAS_CLASSES: list[type] = []
_REGISTERED: list[type] = []


def register() -> None:
    _ALIAS_CLASSES.clear()
    _REGISTERED.clear()
    return None


def unregister() -> None:
    _REGISTERED.clear()
    _ALIAS_CLASSES.clear()
    return None
