"""Named presets and JSON interchange for the current UV divisions."""

import json
import math
import os
from pathlib import Path
from tempfile import NamedTemporaryFile

import bpy

_PRESETS = 'SUV_PACK_UV_LIST_PRESETS'
_FORMAT = 'smart_uv_suite.uv_list'
_VERSION = 1


def _preset_library(scene):
    return json.loads(scene.get(_PRESETS, '{}'))


def _vector(value):
    return (isinstance(value, list) and len(value) == 4
            and all(type(component) in (int, float) and math.isfinite(component) for component in value))


def _validate_layout(layout):
    records = layout.get('divisions') if isinstance(layout, dict) else None
    if not isinstance(records, list):
        raise ValueError('Missing division list')
    active = layout.get('active')
    if type(active) is not int or not -1 <= active < len(records):
        raise ValueError('Invalid active division index')
    for record in records:
        bounds = record.get('bounds') if isinstance(record, dict) else None
        if (not _vector(bounds) or bounds[0] >= bounds[2] or bounds[1] >= bounds[3]
                or not isinstance(record.get('name'), str) or not record['name'].strip()
                or not _vector(record.get('color')) or not all(0 <= v <= 1 for v in record['color'])):
            raise ValueError('Invalid division record')


def _serialize(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False)


def _write_file(path, payload):
    # Write beside the destination so replacing a previous export is atomic.
    temporary = None
    try:
        with NamedTemporaryFile(mode='w', encoding='utf8', dir=path.parent, delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(payload + '\n')
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def build_handlers(api):
    division = api.uv_repair_division

    def missing(context, op):
        api._warn(context, op, 'Choose an existing UV list preset.', '既存の UV リストプリセットを選択してください。')
        return False

    def activate(context, op):
        layout = _preset_library(context.scene).get(op.name.strip())
        if layout is None:
            return missing(context, op)
        _validate_layout(layout)
        return division._store(context, layout)

    def load_file(context, op):
        try:
            if not op.filepath:
                raise ValueError('Missing file path')
            payload = json.loads(Path(bpy.path.abspath(op.filepath)).read_text('utf-8-sig'))
            if (not isinstance(payload, dict) or payload.get('format') != _FORMAT
                    or type(payload.get('version')) is not int or payload['version'] != _VERSION):
                raise ValueError('Unsupported UV list format')
            name = payload.get('name')
            if not isinstance(name, str) or not name.strip():
                raise ValueError('Missing preset name')
            layout = payload.get('layout')
            _validate_layout(layout)
            presets = _preset_library(context.scene)
            presets[name.strip()] = layout
            stored = _serialize(presets)
            # Validate the serialized layout before changing scene state.
            _serialize(layout)
        except (OSError, ValueError, OverflowError):
            api._warn(context, op, 'Choose a valid Smart UV list JSON file.', '有効な Smart UV リストの JSON ファイルを選択してください。')
            return False
        division._store(context, layout)
        context.scene[_PRESETS] = stored
        return True

    def remove(context, op):
        presets = _preset_library(context.scene)
        name = op.name.strip()
        if name not in presets:
            return missing(context, op)
        del presets[name]
        context.scene[_PRESETS] = _serialize(presets)
        return True

    def save(context, op):
        filepath = api._file_path(op, '.json')
        if not filepath:
            api._warn(context, op, 'Choose a JSON file for the UV list.', 'UV リストの保存先 JSON ファイルを選択してください。')
            return False
        path = Path(filepath)
        layout = division._load(context.scene)
        _validate_layout(layout)
        if not layout['divisions']:
            api._warn(context, op, 'Add a UV division before saving a UV list.', 'UV リストを保存する前に UV 区画を追加してください。')
            return False
        name = op.name.strip() or path.stem
        presets = _preset_library(context.scene)
        presets[name] = layout
        stored = _serialize(presets)
        payload = _serialize(dict(format=_FORMAT, version=_VERSION, name=name, layout=layout))
        try:
            _write_file(path, payload)
        except OSError:
            api._warn(context, op, 'The UV list file could not be saved.', 'UV リストファイルを保存できませんでした。')
            return False
        context.scene[_PRESETS] = stored
        return True

    def choose_preset(context, op, event):
        if op.name:
            return op.execute(context)
        names = sorted(_preset_library(context.scene))
        if not names:
            missing(context, op)
            return {'CANCELLED'}
        op_id = op.bl_idname

        def draw(menu, _context):
            menu.layout.operator_context = 'EXEC_DEFAULT'
            for name in names:
                menu.layout.operator(op_id, text=name, translate=False).name = name

        context.window_manager.popup_menu(draw, title=api._t(context, 'UV List Presets', 'UV リストプリセット'))
        return {'FINISHED'}

    def file_picker(default_name):
        def invoke(context, op, event):
            op.filter_glob = '*.json'
            return api._file_invoke_for(default_name)(context, op, event)
        return invoke

    return {
        'smart_uv_suite.pack_load_uv_list': api.Handler(
            activate, 'Activate a saved UV division list.', '保存した UV 区画リストを有効にします。', invoke=choose_preset),
        'smart_uv_suite.pack_load_uv_list_file': api.Handler(
            load_file, 'Import and activate a UV division list from JSON.', 'JSON から UV 区画リストを読み込んで有効にします。', invoke=file_picker('')),
        'smart_uv_suite.pack_remove_uv_list': api.Handler(
            remove, 'Remove a named UV list preset from this scene.', 'このシーンから指定した UV リストプリセットを削除します。', invoke=choose_preset),
        'smart_uv_suite.pack_save_uv_list': api.Handler(
            save, 'Save the current UV divisions as a scene preset and JSON file.', '現在の UV 区画をシーンプリセットと JSON ファイルに保存します。', invoke=file_picker('uv_list.json')),
    }
