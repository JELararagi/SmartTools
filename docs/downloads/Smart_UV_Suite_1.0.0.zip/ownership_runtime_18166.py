# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Compatibility alias for the 1.8.169 exact ownership ledger."""
from .ownership_runtime_18168 import *  # noqa: F401,F403
