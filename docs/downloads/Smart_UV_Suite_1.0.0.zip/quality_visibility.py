from __future__ import annotations


def _workspace_tab(namespace: dict, context) -> str:
    ws_fn = namespace.get('_suv_ws')
    ws = ws_fn(context) if callable(ws_fn) else None
    return str(getattr(ws, 'tab', '') or '')


def _last_status(namespace: dict) -> dict:
    data = namespace.get('_suv_quality_state_last') or {}
    return dict(data) if isinstance(data, dict) else {}


def _clone_card(card: dict) -> dict:
    return {
        'id': card.get('id', ''),
        'title': card.get('title', ''),
        'buttons': list(card.get('buttons', []) or []),
    }


def _clone_section(section: dict) -> dict:
    return {
        'id': section.get('id', ''),
        'title': section.get('title', ''),
        'icon': section.get('icon', 'BOOKMARKS'),
        'cards': [_clone_card(card) for card in (section.get('cards', []) or [])],
    }


def _detect_auto_focus_mode(namespace: dict, context) -> str:
    status = _last_status(namespace)
    readiness_missing = int(status.get('readiness_missing', 0) or 0)
    tool_runtime_errors = int(status.get('tool_runtime_errors', 0) or 0)
    issue_total = int(status.get('issue_total', 0) or 0)
    doctor_actions = int(status.get('doctor_actions', 0) or 0)
    coverage_missing = int(status.get('coverage_missing', 0) or 0)
    workspace = _workspace_tab(namespace, context)
    if tool_runtime_errors > 0 or issue_total > 0 or doctor_actions > 0:
        return 'repair'
    if readiness_missing > 0:
        return 'setup'
    if coverage_missing > 0:
        return 'coverage'
    if workspace == 'ANALYZE':
        return 'analyze'
    return 'all'


def detect_focus_mode(namespace: dict, context) -> str:
    auto_mode = _detect_auto_focus_mode(namespace, context)
    focus_mod = namespace.get('_quality_focus_module')
    if focus_mod is not None and hasattr(focus_mod, 'effective_focus_mode'):
        try:
            return str(focus_mod.effective_focus_mode(namespace, context, auto_mode) or auto_mode)
        except Exception:
            pass
    return auto_mode


def _allowed_sections(focus_mode: str) -> set[str]:
    return {
        'setup': {'workflow'},
        'repair': {'workflow', 'maintenance'},
        'coverage': {'workflow', 'learning'},
        'analyze': {'learning', 'maintenance'},
        'all': {'workflow', 'learning', 'maintenance'},
    }.get(focus_mode, {'workflow', 'learning', 'maintenance'})


def _filter_cards(section_id: str, cards: list, focus_mode: str) -> list:
    keep_map = {
        'setup': {
            'workflow': {'ui.visual.quick_start', 'ui.visual.context_setup', 'ui.visual.execution_profiles'},
        },
        'repair': {
            'workflow': {'ui.visual.quick_start', 'ui.visual.context_setup', 'ui.visual.execution_profiles', 'ui.visual.doctor_card'},
            'maintenance': {'ui.visual.audit_reports', 'ui.visual.report_registry', 'ui.visual.cleanup', 'ui.visual.maintenance'},
        },
        'coverage': {
            'workflow': {'ui.visual.execution_profiles', 'ui.visual.task_playbooks'},
            'learning': {'ui.visual.coverage_guides', 'ui.visual.language_tips', 'ui.visual.help_catalog'},
        },
        'analyze': {
            'learning': {'ui.visual.coverage_guides', 'ui.visual.language_tips', 'ui.visual.help_catalog', 'ui.visual.ui_map'},
            'maintenance': {'ui.visual.audit_reports', 'ui.visual.report_registry', 'ui.visual.maintenance'},
        },
    }
    keep = keep_map.get(focus_mode, {}).get(section_id)
    if not keep:
        return cards
    return [card for card in cards if card.get('id') in keep]


def filter_sections(namespace: dict, context, sections: list) -> dict:
    copied = [_clone_section(section) for section in (sections or [])]
    total_sections = len(copied)
    total_cards = sum(len(section.get('cards', []) or []) for section in copied)
    focus_mode = detect_focus_mode(namespace, context)
    allowed = _allowed_sections(focus_mode)
    visible = []
    for section in copied:
        if section.get('id') not in allowed:
            continue
        cards = _filter_cards(str(section.get('id', '')), list(section.get('cards', []) or []), focus_mode)
        if not cards:
            continue
        section['cards'] = cards
        visible.append(section)
    visible_sections = len(visible)
    visible_cards = sum(len(section.get('cards', []) or []) for section in visible)
    visible_actions = sum(len(card.get('buttons', []) or []) for section in visible for card in (section.get('cards', []) or []))
    hidden_cards = max(0, total_cards - visible_cards)
    focus_mod = namespace.get('_quality_focus_module')
    override = 'AUTO'
    manual = False
    if focus_mod is not None and hasattr(focus_mod, 'scan_focus_control'):
        try:
            focus_info = focus_mod.scan_focus_control(namespace, context) or {}
            override = str(focus_info.get('override', 'AUTO') or 'AUTO')
            manual = bool(focus_info.get('manual', False))
        except Exception:
            pass
    data = {
        'focus_mode': focus_mode,
        'focus_override': override,
        'focus_manual': manual,
        'sections': visible,
        'total_sections': int(total_sections),
        'visible_sections': int(visible_sections),
        'total_cards': int(total_cards),
        'visible_cards': int(visible_cards),
        'hidden_cards': int(hidden_cards),
        'visible_actions': int(visible_actions),
    }
    namespace['_suv_visual_visibility_last'] = dict(data)
    return data
