"""Implement the inspect similarity public UV operations."""

import bpy


def inspect_similarity_cluster_tools(context, op):
    return 'FINISHED' in bpy.ops.uv.suv_similarity_cluster_tools(mode=op.mode or 'REPORT_SELECTED')


def build_handlers(api):
    return {

        "smart_uv_suite.inspect_similarity_cluster_tools": api.Handler(inspect_similarity_cluster_tools, 'Report, export, or select similar UV islands by cluster.', '類似UVアイランドをクラスタ別に検査・書き出し・選択します。'),

    }
