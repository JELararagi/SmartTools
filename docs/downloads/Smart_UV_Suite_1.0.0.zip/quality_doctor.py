from __future__ import annotations
from . import resource_api_18168 as _suv_resource

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None

_NAMESPACE = {}
_REGISTERED = []


def _tr(context, key: str, en: str, ja: str, **fmt) -> str:
    fn = _NAMESPACE.get('tr')
    text = None
    if callable(fn):
        try:
            text = fn(context, key, **fmt)
        except Exception:
            text = None
    if not text:
        text = en
    try:
        return text.format(**fmt)
    except Exception:
        return text


def _text_name(context) -> str:
    ws_fn = _NAMESPACE.get('_suv_ws')
    ws = ws_fn(context) if callable(ws_fn) else None
    name = getattr(ws, 'support_bundle_name', '') if ws else ''
    return (str(name).strip() or 'SUV_Support_Bundle') + '_Quality_Doctor'


def _suv_doctor_name(context):
    return _text_name(context)


def _text_block(name: str, clear=False):
    textio = _NAMESPACE.get('_quality_textio_module')
    if textio is not None and hasattr(textio, 'ensure_report_text'):
        try:
            return textio.ensure_report_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if textio is not None and hasattr(textio, 'ensure_namespace_text'):
        try:
            return textio.ensure_namespace_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if bpy is None:
        return None
    txt = bpy.data.texts.get(name)
    if txt is None:
        if not clear:
            return None
        txt = bpy.data.texts.new(name)
    elif clear:
        txt.clear()
    return txt


def _call_scan(name: str, namespace: dict, context):
    fn = namespace.get(name)
    if not callable(fn):
        return {}
    try:
        if name in {'scan_housekeeping', 'scan_report_hub', 'scan_quality_audit', 'scan_report_registry'}:
            data = fn(context)
        elif name == 'scan_language_coverage':
            data = fn(namespace)
        else:
            data = fn(namespace, context)
        return data or {}
    except Exception:
        return {}


def _add_action(actions: list, severity: str, title_en: str, title_ja: str, detail_en: str, detail_ja: str):
    actions.append({
        'severity': severity,
        'title_en': title_en,
        'title_ja': title_ja,
        'detail_en': detail_en,
        'detail_ja': detail_ja,
    })


_SEVERITY_ORDER = {'high': 0, 'medium': 1, 'low': 2}


def scan_quality_doctor(namespace: dict, context) -> dict:
    cached = dict(namespace.get('_suv_quality_doctor_last') or {})
    if bool(namespace.get('_suv_quality_doctor_scan_active', False)):
        return cached
    namespace['_suv_quality_doctor_scan_active'] = True
    try:
            readiness = _call_scan('scan_context_readiness', namespace, context)
            if bool(namespace.get('_suv_quality_audit_scan_active', False)):
                audit = dict(namespace.get('_suv_quality_audit_last') or {})
            else:
                audit = _call_scan('scan_quality_audit', namespace, context)
            matrix = _call_scan('scan_feature_matrix', namespace, context)
            language = _call_scan('scan_language_coverage', namespace, context)
            reports = _call_scan('scan_report_hub', namespace, context)
            registry = _call_scan('scan_report_registry', namespace, context)
            playbook = _call_scan('scan_task_playbook', namespace, context)
            profiles = _call_scan('scan_operator_profiles', namespace, context)
            housekeeping = _call_scan('scan_housekeeping', namespace, context)

            actions = []
            if int(readiness.get('missing', 0) or 0) > 0:
                _add_action(
                    actions, 'high',
                    'Prepare the working context first',
                    '最初に作業コンテキストを整える',
                    'Open the needed editor, confirm an active mesh, switch to Edit Mode, and make sure a UV map exists before larger UV tools run.',
                    '必要なエディターを開き、アクティブメッシュを確認し、編集モードへ切り替え、主要なUVツールの前にUVマップがあることを確認してください。',
                )
            if int(audit.get('tool_runtime_errors', 0) or 0) > 0:
                _add_action(
                    actions, 'high',
                    'Review repeated tool_runtime failures',
                    '繰り返し発生している実行時失敗を確認する',
                    'Open the tool_runtime log and fix the same failing operator paths before adding more features or workflow helpers.',
                    '機能追加や補助導線を増やす前に、実行ログを開いて同じ失敗を繰り返しているオペレーター経路を先に直してください。',
                )
            if int(profiles.get('blocked_now', 0) or 0) > 0:
                _add_action(
                    actions, 'high',
                    'Resolve blocked operator contexts',
                    '停止中オペレーターの前提を解消する',
                    'Use the execution profiles report to see which operator groups are blocked by the current editor, selection, or mode context.',
                    '実行プロファイルレポートで、現在のエディター、選択状態、モード不足でどのオペレーター群が止まっているかを確認してください。',
                )
            if int(matrix.get('missing', 0) or 0) > 0:
                _add_action(
                    actions, 'medium',
                    'Fill missing feature groups next',
                    '不足している機能グループを次に埋める',
                    'Use the feature matrix to identify broader UV tool groups that still look missing before claiming full coverage or parity.',
                    '完全網羅や上位互換を主張する前に、機能マトリクスでまだ不足しているUV機能グループを確認してください。',
                )
            untranslated = int(language.get('untranslated_labels', 0) or 0)
            weak_desc = int(language.get('weak_descriptions', 0) or 0)
            if untranslated > 0 or weak_desc > 0:
                _add_action(
                    actions, 'medium',
                    'Expand language and tooltip coverage',
                    '翻訳とツールチップの対応範囲を広げる',
                    'Write the language coverage report and prioritize untranslated labels or weak descriptions so the UI stays readable for beginners.',
                    '言語対応レポートを作成し、未翻訳ラベルや弱い説明を優先して埋め、初心者にも読みやすいUIを維持してください。',
                )
            if int(reports.get('missing', 0) or 0) > 0 or int(registry.get('missing_texts', 0) or 0) > 0:
                _add_action(
                    actions, 'medium',
                    'Refresh report-side guidance assets',
                    'レポート系ガイド資産を更新する',
                    'Write the report hub and registry again so audits, catalogs, language reports, and playbooks stay easy to find from one place.',
                    '監査、カタログ、言語対応、プレイブックを一か所から追いやすいよう、レポートハブとレジストリを再生成してください。',
                )
            if int(playbook.get('missing', 0) or 0) > 0:
                _add_action(
                    actions, 'low',
                    'Improve goal-based beginner flow guidance',
                    '目的別の初心者導線を強化する',
                    'Write the task playbook so missing workflow groups become easier to see from a user-facing flow view.',
                    'タスク別プレイブックを作成し、作業目的から見た不足ワークフローを把握しやすくしてください。',
                )
            if int(housekeeping.get('total', 0) or 0) > 0:
                _add_action(
                    actions, 'low',
                    'Clean generated helper data',
                    '生成された補助データを整理する',
                    'Run generated-data cleanup when old diagnostics or helper assets begin to pile up and make the workspace noisy.',
                    '古い診断テキストや補助資産が増えて作業空間が見づらくなってきたら、生成データのクリーンアップを実行してください。',
                )

            actions.sort(key=lambda row: (_SEVERITY_ORDER.get(row['severity'], 9), row['title_en']))
            data = {
                'total_actions': len(actions),
                'high_actions': sum(1 for row in actions if row['severity'] == 'high'),
                'medium_actions': sum(1 for row in actions if row['severity'] == 'medium'),
                'low_actions': sum(1 for row in actions if row['severity'] == 'low'),
                'actions': actions,
                'audit_score': int(audit.get('audit_score', 0) or 0),
                'readiness_score': int(readiness.get('score', 0) or 0),
                'tool_runtime_errors': int(audit.get('tool_runtime_errors', 0) or 0),
                'blocked_now': int(profiles.get('blocked_now', 0) or 0),
                'missing_groups': int(matrix.get('missing', 0) or 0),
                'cleanup_candidates': int(housekeeping.get('total', 0) or 0),
                'untranslated_labels': untranslated,
                'weak_descriptions': weak_desc,
            }
            namespace['_suv_quality_doctor_last'] = data
            return data
    finally:
        namespace['_suv_quality_doctor_scan_active'] = False


class SUV_OT_quality_write_doctor_report(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_write_doctor_report'
    bl_label = 'Write Quality Doctor'
    bl_description = 'Write a prioritized action plan that tells you what to fix next based on readiness, tool_runtime errors, blocked operator contexts, translation gaps, and missing feature groups. / 準備状況、実行時エラー、停止中オペレーター、翻訳不足、不足機能グループをもとに、次に何を直すべきか優先順で示すアクションプランを作成します。'
    bl_options = set()

    open_after_write: bpy.props.BoolProperty(
        name='Open After Write',
        description='Open the written doctor report in Blender Text Editor when possible / 可能なら書き出したドクターレポートを Blender テキストエディタで開きます',
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        data = scan_quality_doctor(_NAMESPACE, context)
        txt = None
        lines = [
            'UV Suite Quality Doctor',
            '',
            '[Summary]',
            f"Audit score: {data['audit_score']}/100",
            f"Readiness score: {data['readiness_score']}/5",
            f"Action items: {data['total_actions']} (high {data['high_actions']}, medium {data['medium_actions']}, low {data['low_actions']})",
            f"Runtime errors: {data['tool_runtime_errors']}",
            f"Blocked operators now: {data['blocked_now']}",
            f"Missing feature groups: {data['missing_groups']}",
            f"Cleanup candidates: {data['cleanup_candidates']}",
            f"Untranslated labels: {data['untranslated_labels']}",
            f"Weak descriptions: {data['weak_descriptions']}",
            '',
            '[Prioritized actions]',
        ]
        for idx, row in enumerate(data['actions'], start=1):
            lines.append(f"{idx}. [{row['severity'].upper()}] {row['title_en']}")
            lines.append(f"   {row['detail_en']}")
        lines.extend(['', '[日本語メモ]'])
        if data['actions']:
            for idx, row in enumerate(data['actions'], start=1):
                lines.append(f"{idx}. [{row['severity']}] {row['title_ja']}")
                lines.append(f"   {row['detail_ja']}")
        else:
            lines.append('現在の診断では大きな優先修正は見つかっていません。個別オペレーターの実処理改善へ進めます。')
        textio = _NAMESPACE.get('_quality_textio_module')
        writer = getattr(textio, 'write_report_lines_consistent', None) if textio is not None else None
        if callable(writer):
            txt = writer(
                _NAMESPACE, context, _text_name, lines, _text_block, self,
                open_after_write=self.open_after_write,
                failed_key='msg.quality_doctor_open_failed',
                failed_en='Could not open quality doctor report: {name}',
                failed_ja='品質ドクターレポートを開けませんでした: {name}',
            )
            if txt is None:
                return {'CANCELLED'}
        else:
            txt = _text_block(_text_name(context), clear=True)
            if txt is None:
                return {'CANCELLED'}
            if textio is not None and hasattr(textio, 'write_text_lines'):
                if textio.write_text_lines(txt, lines) is None:
                    return {'CANCELLED'}
            else:
                txt.write('\n'.join(lines))
            if self.open_after_write and textio is not None and hasattr(textio, 'open_written_text'):
                textio.open_written_text(
                    _NAMESPACE, context, txt, self,
                    failed_key='msg.quality_doctor_open_failed',
                    failed_en='Could not open quality doctor report: {name}',
                    failed_ja='品質ドクターレポートを開けませんでした: {name}',
                )
        self.report({'INFO'}, _tr(context, 'msg.quality_doctor_written', 'Quality doctor report written: {name} ({count} actions)', '品質ドクターレポートを書き出しました: {name}（{count} 件のアクション）', name=txt.name, count=data['total_actions']))
        return {'FINISHED'}


class SUV_OT_quality_open_doctor_report(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_open_doctor_report'
    bl_label = 'Open Quality Doctor'
    bl_description = 'Open the latest UV Suite quality doctor report in Blender Text Editor. / 最新の UV Suite 品質ドクターレポートを Blender のテキストエディタで開きます。'
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        textio = _NAMESPACE.get('_quality_textio_module')
        if textio is not None and hasattr(textio, 'open_named_report_text_or_fallback'):
            return textio.open_named_report_text_or_fallback(
                _NAMESPACE, context, _text_name, self, _text_block,
                missing_key='msg.quality_doctor_missing',
                missing_en='No quality doctor report exists yet.',
                missing_ja='品質ドクターレポートはまだ作成されていません。',
                opened_key='msg.quality_doctor_opened',
                opened_en='Opened quality doctor report: {name}',
                opened_ja='品質ドクターレポートを開きました: {name}',
            )
        txt = _text_block(_text_name(context), clear=False)
        if txt is None:
            self.report({'WARNING'}, _tr(context, 'msg.quality_doctor_missing', 'No quality doctor report exists yet.', '品質ドクターレポートはまだ作成されていません。'))
            return {'CANCELLED'}
        opener = _NAMESPACE.get('_suv_open_text_in_editor')
        ok = False
        if callable(opener):
            try:
                ok, _err = opener(context, txt)
            except Exception:
                ok = False
        if not ok:
            self.report({'WARNING'}, _tr(context, 'msg.quality_doctor_open_failed', 'Could not open quality doctor report: {name}', '品質ドクターレポートを開けませんでした: {name}', name=txt.name))
            return {'CANCELLED'}
        self.report({'INFO'}, _tr(context, 'msg.quality_doctor_opened', 'Opened quality doctor report: {name}', '品質ドクターレポートを開きました: {name}', name=txt.name))
        return {'FINISHED'}


def register(namespace: dict):
    global _NAMESPACE
    _NAMESPACE = namespace if isinstance(namespace, dict) else {}
    if bpy is None:
        return []
    classes = [SUV_OT_quality_write_doctor_report, SUV_OT_quality_open_doctor_report]
    reg = []
    for cls in classes:
        try:
            _suv_resource.register_class(cls)
            reg.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = reg
    return reg


def unregister(namespace: dict | None = None):
    if bpy is None:
        return []
    removed = []
    for cls in reversed(list(_REGISTERED)):
        try:
            _suv_resource.unregister_class(cls)
            removed.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = []
    return removed
