
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None

_NAMESPACE = {}
_REGISTERED = []


def _tr(context, key: str, en: str, ja: str, **kwargs) -> str:
    fn = _NAMESPACE.get('tr') if isinstance(_NAMESPACE, dict) else None
    if callable(fn):
        try:
            return fn(context, key, **kwargs)
        except Exception:
            pass
    try:
        return (ja if _lang_is_ja(context) else en).format(**kwargs)
    except Exception:
        return ja if _lang_is_ja(context) else en


def _bool_label(context, value: bool) -> str:
    return _tr(
        context,
        'ui.bool.on' if value else 'ui.bool.off',
        'On' if value else 'Off',
        'オン' if value else 'オフ',
    )


def _lang_is_ja(context) -> bool:
    prefs_fn = _NAMESPACE.get('_prefs') if isinstance(_NAMESPACE, dict) else None
    prefs = None
    if callable(prefs_fn):
        try:
            prefs = prefs_fn(context)
        except Exception:
            prefs = None
    lang = getattr(prefs, 'ui_language_mode', 'AUTO') if prefs else 'AUTO'
    return lang == 'FORCE_JA'


def _selected_mesh_objects(namespace: dict, context):
    fn = namespace.get('_selected_mesh_objects')
    if callable(fn):
        try:
            return list(fn(context) or [])
        except Exception:
            pass
    out = []
    for obj in getattr(context, 'selected_objects', []) or []:
        if getattr(obj, 'type', '') == 'MESH':
            out.append(obj)
    return out


def _find_area(context, area_type: str) -> bool:
    try:
        area = getattr(context, 'area', None)
        if area is not None and getattr(area, 'type', '') == area_type:
            return True
    except Exception:
        pass
    try:
        for window in getattr(getattr(context, 'window_manager', None), 'windows', []) or []:
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', []) or []:
                if getattr(area, 'type', '') == area_type:
                    return True
    except Exception:
        pass
    return False


def scan_context_readiness(namespace: dict, context) -> dict:
    active = getattr(context, 'active_object', None)
    selected_meshes = _selected_mesh_objects(namespace, context)
    active_mesh = bool(active is not None and getattr(active, 'type', '') == 'MESH')
    edit_mode = bool(active_mesh and str(getattr(active, 'mode', 'OBJECT') or 'OBJECT').upper() == 'EDIT')
    uv_layers = 0
    active_uv = False
    try:
        if active_mesh and getattr(active, 'data', None) is not None:
            uv = getattr(getattr(active.data, 'uv_layers', None), 'active', None)
            active_uv = uv is not None
            uv_layers = len(list(getattr(active.data, 'uv_layers', []) or []))
    except Exception:
        active_uv = False
        uv_layers = 0
    try:
        uv_sync = bool(getattr(getattr(context, 'tool_settings', None), 'use_uv_select_sync', False))
    except Exception:
        uv_sync = False
    result = {
        'active_mesh': active_mesh,
        'selected_meshes': len(selected_meshes),
        'edit_mode': edit_mode,
        'uv_editor': _find_area(context, 'IMAGE_EDITOR'),
        'view3d': _find_area(context, 'VIEW_3D'),
        'active_uv_map': active_uv,
        'uv_layers': uv_layers,
        'uv_sync': uv_sync,
    }
    score = sum(1 for key in ('active_mesh', 'edit_mode', 'uv_editor', 'view3d', 'active_uv_map') if result.get(key))
    result['score'] = score
    result['missing'] = max(0, 5 - int(score))
    namespace['_suv_quality_context_scan'] = result
    return result


def _ensure_active_mesh(namespace: dict, context):
    obj = getattr(context, 'active_object', None)
    if obj is not None and getattr(obj, 'type', '') == 'MESH':
        return obj, False
    selected = _selected_mesh_objects(namespace, context)
    if not selected:
        return None, False
    target = selected[0]
    try:
        context.view_layer.objects.active = target
        return target, True
    except Exception:
        return target, False


def _ensure_edit_mode(namespace: dict, context, obj):
    mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT').upper()
    if mode == 'EDIT':
        return True, False
    safe_mode = namespace.get('_suv_safe_mode_set')
    if callable(safe_mode):
        try:
            ok, _err = safe_mode(context, obj, 'EDIT', source='Quality Context Setup')
            return bool(ok), bool(ok)
        except Exception:
            return False, False
    if bpy is None:
        return False, False
    try:
        bpy.ops.object.mode_set(mode='EDIT')
        return True, True
    except Exception:
        return False, False


def _ensure_uv_map(namespace: dict, context):
    # Quality modules receive the package namespace, while the UV creation
    # helpers live in ui.py after the module split. Resolve their owner
    # explicitly, as the workspace repair operator does.
    from .ui import _suv_ensure_uv_maps_selected, _suv_ws
    ws = _suv_ws(context)
    uv_name = getattr(ws, 'uv_new_name', 'UVMap_SUV') if ws else 'UVMap_SUV'
    return list(_suv_ensure_uv_maps_selected(context, uv_name) or [])


class SUV_OT_quality_scan_context_readiness(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_scan_context_readiness'
    bl_label = 'Scan Context Readiness'
    bl_description = 'Check whether the current active object, mode, editors, and UV map state are ready for common UV Suite actions. / 現在のアクティブ対象、モード、エディター、UVマップ状態が UV Suite の一般的な作業に適しているか確認します。'
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        result = scan_context_readiness(_NAMESPACE, context)
        msg = _tr(
            context,
            'msg.quality_context_scan',
            'Context scan: score {score}/5, active mesh {active_mesh}, edit mode {edit_mode}, UV Editor {uv_editor}, 3D View {view3d}, active UV map {active_uv_map}, selected meshes {selected_meshes}.',
            'コンテキスト確認: スコア {score}/5、アクティブメッシュ {active_mesh}、編集モード {edit_mode}、UVエディター {uv_editor}、3Dビュー {view3d}、アクティブUVマップ {active_uv_map}、選択メッシュ数 {selected_meshes}。',
            **result,
        )
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class SUV_OT_quality_prepare_context_basics(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_prepare_context_basics'
    bl_label = 'Prepare Basic Context'
    bl_description = 'Promote a selected mesh to active, enter Edit Mode, and create a UV map when needed so common UV tools can start from a safer baseline. / 選択メッシュをアクティブ化し、必要に応じて編集モードへ入り、UVマップを作成して、一般的なUVツールをより安全な初期状態から始められるようにします。'
    bl_options = {'UNDO'}

    promote_selected: bpy.props.BoolProperty(
        name='Promote Selected Mesh',
        description='Use the first selected mesh as the active target when no active mesh exists / アクティブなメッシュがない場合は最初の選択メッシュを対象にします',
        default=True,
    )
    enter_edit_mode: bpy.props.BoolProperty(
        name='Enter Edit Mode',
        description='Switch the active mesh to Edit Mode when it is currently in Object Mode / アクティブメッシュがオブジェクトモードなら編集モードへ切り替えます',
        default=True,
    )
    create_uv_map: bpy.props.BoolProperty(
        name='Create UV Map',
        description='Create a UV map on the active mesh when none exists / UVマップが無い場合に作成します',
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        changes = {'active': False, 'edit': False, 'uv': 0}
        obj = getattr(context, 'active_object', None)
        if self.promote_selected:
            obj, promoted = _ensure_active_mesh(_NAMESPACE, context)
            changes['active'] = bool(promoted)
        if obj is None or getattr(obj, 'type', '') != 'MESH':
            self.report({'ERROR'}, _tr(context, 'msg.preflight_mesh_missing', 'Select an active mesh object before running this tool.', 'このツールを実行する前に、アクティブなメッシュオブジェクトを選択してください。'))
            return {'CANCELLED'}
        if self.enter_edit_mode:
            ok_edit, changed = _ensure_edit_mode(_NAMESPACE, context, obj)
            if not ok_edit:
                self.report({'WARNING'}, _tr(context, 'msg.preflight_need_edit', 'Switch to Edit Mode on the target mesh, then run the tool again.', '対象メッシュを編集モードに切り替えてから、もう一度このツールを実行してください。'))
            changes['edit'] = bool(changed)
        if self.create_uv_map:
            created = _ensure_uv_map(_NAMESPACE, context)
            changes['uv'] = len(created)
        _NAMESPACE['_suv_quality_context_prepare_last'] = dict(changes)
        result = scan_context_readiness(_NAMESPACE, context)
        msg = _tr(
            context,
            'msg.quality_context_prepared',
            'Prepared context: active changed {active}, edit mode changed {edit}, UV maps created {uv}. Readiness score is now {score}/5.',
            'コンテキストを準備しました: アクティブ変更 {active}、編集モード変更 {edit}、作成UVマップ {uv}。現在の準備スコアは {score}/5 です。',
            active=_bool_label(context, changes['active']),
            edit=_bool_label(context, changes['edit']),
            uv=changes['uv'],
            score=result.get('score', 0),
        )
        self.report({'INFO'}, msg)
        return {'FINISHED'}


def register(namespace: dict):
    global _NAMESPACE
    _NAMESPACE = namespace if isinstance(namespace, dict) else {}
    if bpy is None:
        return []
    classes = [SUV_OT_quality_scan_context_readiness, SUV_OT_quality_prepare_context_basics]
    reg = []
    for cls in classes:
        try:
            _suv_resource.register_class(cls)
            reg.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = reg
    return reg


def unregister(namespace: dict | None = None):
    if bpy is None:
        return []
    removed = []
    for cls in reversed(list(_REGISTERED)):
        try:
            _suv_resource.unregister_class(cls)
            removed.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = []
    return removed
