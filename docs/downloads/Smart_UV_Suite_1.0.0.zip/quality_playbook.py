from __future__ import annotations
from . import resource_api_18168 as _suv_resource
from .quality_class_inventory import class_namespace

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None

_NAMESPACE = {}
_REGISTERED = []


def _tr(context, key: str, en: str, ja: str, **fmt) -> str:
    fn = _NAMESPACE.get('tr')
    text = None
    if callable(fn):
        try:
            text = fn(context, key, **fmt)
        except Exception:
            text = None
    if not text:
        text = en
    try:
        return text.format(**fmt)
    except Exception:
        return text


def _text_name(context) -> str:
    ws_fn = _NAMESPACE.get('_suv_ws')
    ws = ws_fn(context) if callable(ws_fn) else None
    name = getattr(ws, 'support_bundle_name', '') if ws else ''
    return (str(name).strip() or 'SUV_Support_Bundle') + '_Task_Playbook'


def _suv_playbook_name(context):
    return _text_name(context)


def _text_block(name: str, clear=False):
    textio = _NAMESPACE.get('_quality_textio_module')
    if textio is not None and hasattr(textio, 'ensure_report_text'):
        try:
            return textio.ensure_report_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if textio is not None and hasattr(textio, 'ensure_namespace_text'):
        try:
            return textio.ensure_namespace_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if bpy is None:
        return None
    txt = bpy.data.texts.get(name)
    if txt is None:
        if not clear:
            return None
        txt = bpy.data.texts.new(name)
    elif clear:
        txt.clear()
    return txt


def scan_task_playbook(namespace: dict, context) -> dict:
    specs = [
        ('setup_repair', 'Setup & Repair', '準備と修復', ['SUV_OT_quality_scan_context_readiness', 'SUV_OT_quality_prepare_context_basics', 'SUV_OT_workspace_validate', 'SUV_OT_workspace_auto_repair']),
        ('unwrap_straighten', 'Unwrap & Straighten', '展開と整列', ['SUV_OT_auto_unwrap_pro', 'SUV_OT_constraint_unwrap', 'SUV_OT_smart_rectify', 'SUV_OT_smart_edge_straighten']),
        ('stack_density', 'Stack & Density', 'スタックと密度', ['SUV_OT_stack_pro', 'SUV_OT_stack_grouped', 'SUV_OT_texel_normalize', 'SUV_OT_texel_get']),
        ('pack_udim', 'Pack & UDIM', 'パックとUDIM', ['SUV_OT_pack_pro', 'SUV_OT_udim_tile_tools', 'SUV_OT_atlas_build_uv_multi', 'SUV_OT_atlas_run_all_multi']),
        ('symmetry_atlas', 'Symmetry & Atlas', '対称とアトラス', ['SUV_OT_sym_detect_pairs', 'SUV_OT_sym_mirror_uv', 'SUV_OT_sym_stack', 'SUV_OT_atlas_build_uv_multi']),
        ('inspect_reports', 'Inspect & Reports', '検査とレポート', ['SUV_OT_quality_audit_suite', 'SUV_OT_quality_scan_feature_matrix', 'SUV_OT_quality_write_language_coverage', 'SUV_OT_quality_write_report_hub']),
    ]
    rows = []
    ready = partial = missing = 0
    classes = class_namespace(namespace)
    for key, title_en, title_ja, names in specs:
        available = []
        missing_names = []
        for nm in names:
            cls = classes.get(nm)
            if isinstance(cls, type) and getattr(cls, 'bl_idname', ''):
                available.append(cls)
            else:
                missing_names.append(nm)
        total = len(names)
        have = len(available)
        if have >= max(1, total - 1):
            state = 'ready'
            ready += 1
        elif have > 0:
            state = 'partial'
            partial += 1
        else:
            state = 'missing'
            missing += 1
        rows.append({
            'key': key,
            'title_en': title_en,
            'title_ja': title_ja,
            'available': have,
            'total': total,
            'state': state,
            'available_labels': [str(getattr(cls, 'bl_label', '') or getattr(cls, 'bl_idname', '')) for cls in available],
            'missing_names': list(missing_names),
        })
    data = {'total': len(rows), 'ready': ready, 'partial': partial, 'missing': missing, 'rows': rows}
    namespace['_suv_task_playbook_last'] = data
    return data


class SUV_OT_quality_write_task_playbook(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_write_task_playbook'
    bl_label = 'Write Task Playbook'
    bl_description = 'Write a task-based playbook that groups the current UV Suite tool surface into beginner-friendly workflows such as setup, unwrap, packing, symmetry, and inspection. / 現在の UV Suite の機能面を、準備、展開、パッキング、対称、検査などの初心者向けワークフロー単位でまとめたタスク別プレイブックを書き出します。'
    bl_options = set()

    open_after_write: bpy.props.BoolProperty(
        name='Open After Write',
        description='Open the written task playbook in Blender Text Editor when possible / 可能なら書き出したタスク別プレイブックを Blender テキストエディタで開きます',
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        data = scan_task_playbook(_NAMESPACE, context)
        txt = None
        lines = [
            'UV Suite Task Playbook',
            '',
            '[Summary]',
            f"Ready workflows: {data['ready']}/{data['total']}",
            f"Partial workflows: {data['partial']}",
            f"Missing workflows: {data['missing']}",
            '',
            '[Workflow Groups]',
        ]
        for row in data['rows']:
            lines.append(f"- {row['title_en']} [{row['state']}] {row['available']}/{row['total']}")
            if row['available_labels']:
                lines.append('  available: ' + ', '.join(row['available_labels']))
            if row['missing_names']:
                lines.append('  missing refs: ' + ', '.join(row['missing_names']))
        lines.extend([
            '',
            '[Recommended beginner order]',
            '1. Setup & Repair: make sure the active mesh, Edit Mode, UV map, and editors look correct.',
            '2. Unwrap & Straighten: create or correct shell layout before stacking or packing.',
            '3. Stack & Density: align repeated shells and normalize texel density where needed.',
            '4. Pack & UDIM: finalize tile placement, pack shells, and prepare atlas output.',
            '5. Symmetry & Atlas: mirror and stack symmetric shells, then move into atlas or bake stages.',
            '6. Inspect & Reports: run audit, matrix, and language reports before shipping or sharing.',
            '',
            '[日本語メモ]',
            f"準備完了ワークフロー: {data['ready']}/{data['total']}",
            '初心者は、まず準備と修復、その次に展開と整列、続いてスタックと密度、最後にパックと検査の順で進めると迷いにくいです。',
        ])
        textio = _NAMESPACE.get('_quality_textio_module')
        writer = getattr(textio, 'write_report_lines_consistent', None) if textio is not None else None
        if callable(writer):
            txt = writer(
                _NAMESPACE, context, _text_name, lines, _text_block, self,
                open_after_write=self.open_after_write,
                failed_key='msg.quality_playbook_open_failed',
                failed_en='Could not open task playbook: {name}',
                failed_ja='タスク別プレイブックを開けませんでした: {name}',
            )
            if txt is None:
                return {'CANCELLED'}
        else:
            txt = _text_block(_text_name(context), clear=True)
            if txt is None:
                return {'CANCELLED'}
            txt.write('\n'.join(lines))
            if self.open_after_write:
                opener = _NAMESPACE.get('_suv_open_text_in_editor')
                if callable(opener):
                    try:
                        opener(context, txt)
                    except Exception:
                        pass
        msg = _tr(context, 'msg.quality_playbook_written', 'Task playbook written: {name} ({ready}/{total} ready)', 'タスク別プレイブックを書き出しました: {name}（準備完了 {ready}/{total}）', name=txt.name, ready=data['ready'], total=data['total'])
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class SUV_OT_quality_open_task_playbook(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_open_task_playbook'
    bl_label = 'Open Task Playbook'
    bl_description = 'Open the latest UV Suite task playbook in Blender Text Editor. / 最新の UV Suite タスク別プレイブックを Blender のテキストエディタで開きます。'
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        textio = _NAMESPACE.get('_quality_textio_module')
        if textio is not None and hasattr(textio, 'open_named_report_text_or_fallback'):
            return textio.open_named_report_text_or_fallback(
                _NAMESPACE, context, _text_name, self, _text_block,
                missing_key='msg.quality_playbook_missing',
                missing_en='No task playbook exists yet.',
                missing_ja='タスク別プレイブックはまだ作成されていません。',
                opened_key='msg.quality_playbook_opened',
                opened_en='Opened task playbook: {name}',
                opened_ja='タスク別プレイブックを開きました: {name}',
            )
        txt = _text_block(_text_name(context), clear=False)
        if txt is None:
            self.report({'WARNING'}, _tr(context, 'msg.quality_playbook_missing', 'No task playbook exists yet.', 'タスク別プレイブックはまだ作成されていません。'))
            return {'CANCELLED'}
        opener = _NAMESPACE.get('_suv_open_text_in_editor')
        ok = False
        if callable(opener):
            try:
                ok, _err = opener(context, txt)
            except Exception:
                ok = False
        if not ok:
            self.report({'WARNING'}, _tr(context, 'msg.quality_playbook_open_failed', 'Could not open task playbook: {name}', 'タスク別プレイブックを開けませんでした: {name}', name=txt.name))
            return {'CANCELLED'}
        msg = _tr(context, 'msg.quality_playbook_opened', 'Opened task playbook: {name}', 'タスク別プレイブックを開きました: {name}', name=txt.name)
        self.report({'INFO'}, msg)
        return {'FINISHED'}



def register(namespace: dict):
    global _NAMESPACE
    _NAMESPACE = namespace if isinstance(namespace, dict) else {}
    if bpy is None:
        return []
    classes = [SUV_OT_quality_write_task_playbook, SUV_OT_quality_open_task_playbook]
    reg = []
    for cls in classes:
        try:
            _suv_resource.register_class(cls)
            reg.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = reg
    return reg


def unregister(namespace: dict | None = None):
    if bpy is None:
        return []
    removed = []
    for cls in reversed(list(_REGISTERED)):
        try:
            _suv_resource.unregister_class(cls)
            removed.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = []
    return removed
