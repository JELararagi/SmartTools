from __future__ import annotations

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None


def _iter_classes(namespace: dict, prefixes=('SUV_OT_', 'SUV_PT_', 'SUV_MT_')):
    for name, value in list(namespace.items()):
        if not any(name.startswith(prefix) for prefix in prefixes):
            continue
        try:
            if isinstance(value, type):
                yield name, value
        except Exception:
            continue


def _log(namespace: dict, context, source: str, exc: Exception, details=None):
    try:
        fn = namespace.get('_suv_log_exception')
        if callable(fn):
            fn(context, source, exc, details or {})
    except Exception:
        pass


def _build_hint(namespace: dict, context, source: str, exc: Exception) -> str:
    text = f"{type(exc).__name__}: {exc}".lower()
    source_l = str(source or '').lower()
    key = 'msg.quality_hint.generic'
    if 'poll' in text or 'context is incorrect' in text or 'operator poll failed' in text:
        key = 'msg.quality_hint.context'
    elif 'edit mode' in text or 'editable mesh' in text or 'mesh' in text and ('active object' in text or 'selected object' in text):
        key = 'msg.quality_hint.mesh_edit'
    elif 'uv' in text and ('layer' in text or 'map' in text or 'active uv' in text):
        key = 'msg.quality_hint.uvmap'
    elif 'image editor' in text or 'space image' in text or 'uv editor' in text:
        key = 'msg.quality_hint.uv_editor'
    elif 'view3d' in text or '3d view' in text:
        key = 'msg.quality_hint.view3d'
    elif any(k in source_l for k in ('pack', 'layout', 'tile', 'udim')):
        key = 'msg.quality_hint.pack'
    elif any(k in source_l for k in ('unwrap', 'seam', 'relax', 'rectify', 'align', 'stack')):
        key = 'msg.quality_hint.selection'

    tr_fn = namespace.get('tr')
    if callable(tr_fn):
        try:
            return tr_fn(context, key)
        except Exception:
            pass
    fallbacks = {
        'msg.quality_hint.context': 'Try running this tool from the UV Editor or 3D View with a valid active mesh context.',
        'msg.quality_hint.mesh_edit': 'Select a mesh object, switch to Edit Mode, and make sure the target faces or UVs are available.',
        'msg.quality_hint.uvmap': 'Create or activate a UV map before running this tool, then retry on the intended target.',
        'msg.quality_hint.uv_editor': 'Open the UV Editor and retry so the operator has a valid UV editing area.',
        'msg.quality_hint.view3d': 'Open a 3D View and retry so the operator can access mesh-side context.',
        'msg.quality_hint.pack': 'Review selection, tile target, and UV bounds first, then retry after shells are prepared.',
        'msg.quality_hint.selection': 'Check the current face or island selection first, then retry with the intended UV target.',
        'msg.quality_hint.generic': 'Review the current selection, object mode, UV map, and active editor, then try again.',
    }
    return fallbacks.get(key, fallbacks['msg.quality_hint.generic'])


def _report_failure(namespace: dict, self, context, source: str, exc: Exception):
    try:
        report_fn = getattr(self, 'report', None)
        if callable(report_fn):
            tr_fn = namespace.get('tr')
            msg = tr_fn(context, 'msg.op_failed', e=exc) if callable(tr_fn) else f'{source} failed: {exc}'
            hint = _build_hint(namespace, context, source, exc)
            report_fn({'ERROR'}, msg)
            if hint:
                report_fn({'INFO'}, hint)
    except Exception:
        pass


def _attempt_repair_once(namespace: dict, context, source: str, exc: Exception):
    fn = namespace.get('_suv_quality_attempt_repair')
    if callable(fn):
        try:
            data = fn(namespace, context, source, exc) or {}
            if isinstance(data, dict):
                return data
        except Exception:
            pass
    return {'repaired': False, 'actions': []}


def wrap_operator_method(namespace: dict, cls, method_name: str):
    original = getattr(cls, method_name, None)
    if original is None or getattr(original, '_suv_quality_wrapped', False):
        return False

    def wrapped(self, context, *args, **kwargs):
        try:
            return original(self, context, *args, **kwargs)
        except Exception as exc:
            source = getattr(cls, 'bl_label', cls.__name__)
            repair = {'repaired': False, 'actions': []}
            if method_name in {'execute', 'invoke'}:
                repair = _attempt_repair_once(namespace, context, source, exc)
                if bool(repair.get('repaired', False)):
                    try:
                        result = original(self, context, *args, **kwargs)
                        report_fn = getattr(self, 'report', None)
                        if callable(report_fn):
                            actions = ', '.join(list(repair.get('actions') or [])[:4]) or 'context'
                            report_fn({'INFO'}, f'{source}: auto-repaired and retried ({actions})')
                        return result
                    except Exception as retry_exc:
                        exc = retry_exc
            hint = _build_hint(namespace, context, source, exc)
            _log(namespace, context, source, exc, {
                'method': method_name,
                'class': cls.__name__,
                'recovery_hint': hint,
                'repair_actions': ', '.join(list(repair.get('actions') or [])[:8]) if isinstance(repair, dict) else '',
                'repair_applied': bool(repair.get('repaired', False)) if isinstance(repair, dict) else False,
            })
            _report_failure(namespace, self, context, source, exc)
            return {'CANCELLED'}

    wrapped._suv_quality_wrapped = True
    setattr(cls, method_name, wrapped)
    return True


def _wrap_classmethod_poll(namespace: dict, cls):
    descriptor = cls.__dict__.get('poll', None)
    if descriptor is None:
        return False
    if getattr(descriptor, '_suv_quality_wrapped', False):
        return False

    if isinstance(descriptor, classmethod):
        func = descriptor.__func__
        def wrapped(inner_cls, context):
            try:
                return bool(func(inner_cls, context))
            except Exception as exc:
                hint = _build_hint(namespace, context, getattr(inner_cls, 'bl_label', inner_cls.__name__), exc)
                _log(namespace, context, getattr(inner_cls, 'bl_label', inner_cls.__name__), exc, {'method': 'poll', 'class': inner_cls.__name__, 'recovery_hint': hint})
                return False
        cm = classmethod(wrapped)
        cm._suv_quality_wrapped = True
        setattr(cls, 'poll', cm)
        return True

    if callable(descriptor):
        def wrapped(context):
            try:
                return bool(descriptor(context))
            except Exception as exc:
                hint = _build_hint(namespace, context, getattr(cls, 'bl_label', cls.__name__), exc)
                _log(namespace, context, getattr(cls, 'bl_label', cls.__name__), exc, {'method': 'poll', 'class': cls.__name__, 'recovery_hint': hint})
                return False
        wrapped._suv_quality_wrapped = True
        setattr(cls, 'poll', wrapped)
        return True
    return False


def _draw_failure_message(namespace: dict, self, context, exc: Exception, icon='ERROR'):
    try:
        layout = getattr(self, 'layout', None)
        if layout is None:
            return
        tr_fn = namespace.get('tr')
        head = tr_fn(context, 'ui.section.quality_fallback') if callable(tr_fn) else 'UI fallback'
        body = tr_fn(context, 'msg.ui_draw_failed', e=exc) if callable(tr_fn) else f'UI drawing failed: {exc}'
        hint = _build_hint(namespace, context, getattr(self, 'bl_label', self.__class__.__name__), exc)
        box = layout.box()
        col = box.column(align=True)
        col.label(text=head, icon=icon)
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        if hint:
            sub = col.row()
            sub.scale_y = 0.9
            sub.label(text=hint, icon='LIGHT')
    except Exception:
        pass


def wrap_draw_method(namespace: dict, cls, method_name='draw'):
    original = getattr(cls, method_name, None)
    if original is None or getattr(original, '_suv_quality_wrapped', False):
        return False

    def wrapped(self, context, *args, **kwargs):
        try:
            return original(self, context, *args, **kwargs)
        except Exception as exc:
            hint = _build_hint(namespace, context, getattr(cls, 'bl_label', cls.__name__), exc)
            _log(namespace, context, getattr(cls, 'bl_label', cls.__name__), exc, {'method': method_name, 'class': cls.__name__, 'recovery_hint': hint})
            _draw_failure_message(namespace, self, context, exc, icon='MENU_PANEL' if cls.__name__.startswith('SUV_PT_') else 'ERROR')
            return None

    wrapped._suv_quality_wrapped = True
    setattr(cls, method_name, wrapped)
    return True


def patch_safety(namespace: dict) -> dict:
    counts = {
        'operator_methods': 0,
        'operator_poll': 0,
        'panel_draw': 0,
        'menu_draw': 0,
        'panel_header': 0,
    }
    for _name, cls in _iter_classes(namespace, prefixes=('SUV_OT_',)):
        for method_name in ('execute', 'invoke', 'modal'):
            try:
                if wrap_operator_method(namespace, cls, method_name):
                    counts['operator_methods'] += 1
            except Exception:
                pass
        try:
            if _wrap_classmethod_poll(namespace, cls):
                counts['operator_poll'] += 1
            elif not hasattr(cls, 'poll'):
                # Operators without explicit poll still benefit from clear reporting in execute/invoke.
                pass
        except Exception:
            pass

    for _name, cls in _iter_classes(namespace, prefixes=('SUV_PT_',)):
        try:
            if wrap_draw_method(namespace, cls, 'draw'):
                counts['panel_draw'] += 1
        except Exception:
            pass
        try:
            if wrap_draw_method(namespace, cls, 'draw_header'):
                counts['panel_header'] += 1
        except Exception:
            pass

    for _name, cls in _iter_classes(namespace, prefixes=('SUV_MT_',)):
        try:
            if wrap_draw_method(namespace, cls, 'draw'):
                counts['menu_draw'] += 1
        except Exception:
            pass

    namespace['_suv_quality_safety_counts'] = counts
    return counts
