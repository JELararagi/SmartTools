# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Smart UV Suite 1.8.104 multi-object edit support layer.

This layer runs after the 1.8.103 room-integrity layer.  It keeps that layer's
state preservation, gizmo non-interference, stale-cache avoidance and crash
guards, but removes the remaining active-object-only execution paths from the
UV Editor tools that users expect to work in Blender multi-object Edit Mode.
"""
from __future__ import annotations

from collections import defaultdict, deque
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple
import inspect
import math
import inspect

import bpy

from . import uv_room_integrity_18103 as ri

_VERSION = (1, 8, 104)
_NS: Dict[str, Any] = {}
_PREV: Dict[str, Any] = {}
_INSTALLED = False
_GENERIC_PATCH_COMPLETE = False
_GROUP_ACTIONS = {"ALIGN_H_GROUP", "ALIGN_V_GROUP", "DISTRIBUTE_H_GROUP", "DISTRIBUTE_V_GROUP"}
_EPS = 1.0e-6


def _s(value: Any) -> str:
    try:
        return str(value or "")
    except Exception:
        return ""


def _report(op: Any, level: str, message: str) -> None:
    try:
        op.report({level}, message)
    except Exception:
        pass


def _tr(context: Any, en: str, ja: str) -> str:
    return ri._tr(context, en, ja)


def _active_object(context: Any) -> Any:
    try:
        return getattr(context.view_layer.objects, "active", None)
    except Exception:
        try:
            return getattr(context, "active_object", None)
        except Exception:
            return None


def _selected_mesh_objects(context: Any) -> List[Any]:
    out: List[Any] = []
    seen: Set[int] = set()

    def add(obj: Any) -> None:
        if obj is None or getattr(obj, "type", None) != "MESH":
            return
        try:
            key = int(obj.as_pointer())
        except Exception:
            key = id(obj)
        if key in seen:
            return
        seen.add(key)
        out.append(obj)

    for attr in ("objects_in_mode_unique_data", "objects_in_mode", "selected_objects"):
        try:
            for obj in getattr(context, attr, []) or []:
                add(obj)
        except Exception:
            pass
    try:
        add(getattr(context, "edit_object", None))
    except Exception:
        pass
    try:
        add(getattr(context, "active_object", None))
    except Exception:
        pass
    return out


def _edit_mesh_objects(context: Any) -> List[Any]:
    out: List[Any] = []
    seen_data: Set[int] = set()

    def add(obj: Any) -> None:
        if obj is None or getattr(obj, "type", None) != "MESH" or getattr(obj, "mode", None) != "EDIT":
            return
        try:
            key = int(obj.data.as_pointer())
        except Exception:
            key = id(getattr(obj, "data", obj))
        if key in seen_data:
            return
        seen_data.add(key)
        out.append(obj)

    for attr in ("objects_in_mode_unique_data", "objects_in_mode"):
        try:
            for obj in getattr(context, attr, []) or []:
                add(obj)
        except Exception:
            pass
    try:
        add(getattr(context, "edit_object", None))
    except Exception:
        pass
    try:
        add(getattr(context, "active_object", None))
    except Exception:
        pass
    return out


def _mode_state(context: Any) -> Dict[str, Any]:
    selected = []
    try:
        selected = list(getattr(context, "selected_objects", []) or [])
    except Exception:
        selected = []
    return {
        "active": _active_object(context),
        "selected": selected,
        "was_edit": bool(_edit_mesh_objects(context)),
        "entered_edit": False,
    }


def _ensure_multi_edit(context: Any) -> Tuple[List[Any], Dict[str, Any]]:
    state = _mode_state(context)
    objs = _edit_mesh_objects(context)
    if objs:
        return objs, state
    selected = _selected_mesh_objects(context)
    if not selected:
        return [], state
    try:
        active = _active_object(context)
        if active not in selected:
            active = selected[0]
        for obj in selected:
            try:
                obj.select_set(True)
            except Exception:
                pass
        try:
            context.view_layer.objects.active = active
        except Exception:
            pass
        if bpy.ops.object.mode_set.poll():
            bpy.ops.object.mode_set(mode="EDIT")
            state["entered_edit"] = True
    except Exception:
        pass
    return _edit_mesh_objects(context), state


def _restore_multi_edit(context: Any, state: Dict[str, Any]) -> None:
    if not isinstance(state, dict):
        return
    if state.get("entered_edit"):
        try:
            if bpy.ops.object.mode_set.poll():
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass
        # Restore object selection and active object as far as Blender allows.
        try:
            old_selected = set(state.get("selected") or [])
            for obj in bpy.context.scene.objects:
                try:
                    obj.select_set(obj in old_selected)
                except Exception:
                    pass
        except Exception:
            pass
        try:
            active = state.get("active")
            if active is not None:
                context.view_layer.objects.active = active
        except Exception:
            pass


def _prepare_unwrap_channel(context: Any) -> None:
    try:
        from . import uv_map_channels as uvc
        ws = ri._workspace(context)
        uvc.ensure_unwrap_map_channel(context, ws, None)
    except Exception:
        pass


def _target_data(context: Any) -> List[Tuple[Any, Any, Any]]:
    import bmesh
    data: List[Tuple[Any, Any, Any]] = []
    for obj in _edit_mesh_objects(context):
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            ri._ensure_lookup(bm)
            uv_layer = ri._uv_layer(bm)
            if uv_layer is not None:
                data.append((obj, bm, uv_layer))
        except Exception:
            continue
    return data


def _update_meshes(targets: Sequence[Tuple[Any, Any, Any]]) -> None:
    import bmesh
    seen: Set[int] = set()
    for obj, _bm, _uv in targets:
        try:
            mesh = obj.data
            key = int(mesh.as_pointer()) if hasattr(mesh, "as_pointer") else id(mesh)
            if key in seen:
                continue
            seen.add(key)
            try:
                bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
            except TypeError:
                bmesh.update_edit_mesh(mesh)
        except Exception:
            pass


def _execute_select_multi(self: Any, context: Any):
    action = _s(getattr(self, "action", "GROW")).upper() or "GROW"
    snap = ri._snapshot_modes(context)
    objs, state = _ensure_multi_edit(context)
    if not objs:
        _report(self, "WARNING", _tr(context, "No mesh object is active.", "アクティブなメッシュオブジェクトがありません。"))
        return {"CANCELLED"}
    try:
        _prepare_unwrap_channel(context)
        targets = _target_data(context)
        if not targets:
            _report(self, "WARNING", _tr(context, "No editable UV map is available.", "編集可能なUVマップがありません。"))
            return {"CANCELLED"}
        mode = ri._uv_mode(context)
        touched = 0
        had_seed = False
        for obj, bm, uv_layer in targets:
            loops, edge_loops, faces = ri._selected_sets(context, obj, bm, uv_layer, mode)
            if action == "NONE":
                ri._clear_selection(bm, uv_layer, mesh=ri._sync_on(context))
                touched += 1
                continue
            if action == "ALL":
                all_loops, all_edges, all_faces = ri._all_sets(bm)
                ri._apply_selection(context, obj, bm, uv_layer, mode, all_loops, all_edges, all_faces)
                touched += 1
                continue
            if not (loops or edge_loops or faces):
                continue
            had_seed = True
            if action == "GROW":
                out = ri._selection_grow(mode, bm, uv_layer, loops, edge_loops, faces, sync=ri._sync_on(context))
            elif action == "SHRINK":
                out = ri._selection_shrink(mode, bm, uv_layer, loops, edge_loops, faces, sync=ri._sync_on(context))
            elif action == "LINKED":
                out = ri._selection_linked(mode, bm, uv_layer, loops, edge_loops, faces, sync=ri._sync_on(context))
            elif action == "BORDER":
                out = ri._selection_border(mode, bm, uv_layer, loops, edge_loops, faces, sync=ri._sync_on(context))
            elif action == "INVERT":
                out = ri._selection_invert(mode, bm, loops, edge_loops, faces)
            elif action in {"LOOP", "RING"}:
                out = ri._selection_loop_ring(context, obj, bm, uv_layer, action, loops, edge_loops)
            else:
                _report(self, "WARNING", f"Unsupported selection action: {action}")
                return {"CANCELLED"}
            ri._apply_selection(context, obj, bm, uv_layer, mode, out[0], out[1], out[2])
            touched += 1
        if touched <= 0 and action not in {"ALL", "NONE"}:
            _report(self, "WARNING", _tr(context, "No UV element is selected on any edited object.", "編集中のどのオブジェクトにも選択されたUVエレメントがありません。"))
            return {"CANCELLED"}
        _update_meshes(targets)
        try:
            if getattr(context, "area", None) is not None:
                context.area.tag_redraw()
        except Exception:
            pass
        return {"FINISHED"}
    except Exception as exc:
        _report(self, "WARNING", _tr(context, "UV selection operation failed.", "UV選択処理に失敗しました。") + f" {exc}")
        return {"CANCELLED"}
    finally:
        ri._restore_modes(snap)
        _restore_multi_edit(context, state)
        ri._restore_modes(snap)


def _mesh_data_key(obj: Any) -> int:
    try:
        return int(obj.data.as_pointer())
    except Exception:
        return id(getattr(obj, "data", obj))


def _sticky_key_multi(rec_or_obj: Any, loop: Any = None, uv_layer: Any = None, sticky: str = "DISABLED") -> Any:
    if isinstance(rec_or_obj, dict):
        obj = rec_or_obj.get("obj")
        loop = rec_or_obj.get("loop")
        uv_layer = rec_or_obj.get("uv_layer")
    else:
        obj = rec_or_obj
    sticky = _s(sticky).upper()
    if loop is None or uv_layer is None:
        return ("none", id(rec_or_obj))
    if sticky == "SHARED_LOCATION":
        # Same-position sticky is a UV-editor concept. In multi-object UV editing,
        # UVs from different objects share the same editor space, so the data-key
        # must not separate identical UV coordinates.
        return ("loc", ri._uv_key(loop, uv_layer))
    if sticky == "SHARED_VERTEX":
        try:
            return ("vert", _mesh_data_key(obj), int(loop.vert.index))
        except Exception:
            return ("vert", _mesh_data_key(obj), id(loop.vert))
    try:
        return ("loop", _mesh_data_key(obj), ri._face_index(loop.face), ri._loop_index(loop))
    except Exception:
        return ("loop", id(loop))


def _make_record(obj: Any, loop: Any, uv_layer: Any, source: bool = True) -> Dict[str, Any]:
    u, v = ri._uv_xy(loop, uv_layer)
    return {"obj": obj, "mesh": getattr(obj, "data", None), "loop": loop, "uv_layer": uv_layer, "u": u, "v": v, "source": source}


def _all_followers_multi(targets: Sequence[Tuple[Any, Any, Any]], sticky: str) -> Dict[Any, List[Dict[str, Any]]]:
    out: Dict[Any, List[Dict[str, Any]]] = defaultdict(list)
    if sticky not in {"SHARED_LOCATION", "SHARED_VERTEX"}:
        return out
    for obj, bm, uv_layer in targets:
        try:
            for face in bm.faces:
                if getattr(face, "hide", False):
                    continue
                for loop in face.loops:
                    key = _sticky_key_multi(obj, loop, uv_layer, sticky)
                    out[key].append(_make_record(obj, loop, uv_layer, False))
        except Exception:
            continue
    return out


def _pointify_multi(records: Sequence[Dict[str, Any]], sticky: str, follower_index: Optional[Dict[Any, List[Dict[str, Any]]]] = None, exclude_loop_ids: Optional[Set[int]] = None) -> List[Dict[str, Any]]:
    buckets: Dict[Any, List[Dict[str, Any]]] = {}
    order: List[Any] = []
    selected_ids = {id(r.get("loop")) for r in records}
    excluded = set(exclude_loop_ids or set()) | selected_ids
    for rec in records:
        key = _sticky_key_multi(rec, sticky=sticky)
        if key not in buckets:
            buckets[key] = []
            order.append(key)
        buckets[key].append(rec)
        if follower_index and sticky in {"SHARED_LOCATION", "SHARED_VERTEX"}:
            for follower in follower_index.get(key, []) or []:
                if id(follower.get("loop")) in excluded:
                    continue
                buckets[key].append(follower)
    points: List[Dict[str, Any]] = []
    for key in order:
        recs = buckets.get(key) or []
        if not recs:
            continue
        source_recs = [r for r in recs if r.get("source")]
        base = source_recs or recs
        u = sum(float(r.get("u", 0.0)) for r in base) / max(1, len(base))
        v = sum(float(r.get("v", 0.0)) for r in base) / max(1, len(base))
        points.append({"key": key, "records": recs, "u": u, "v": v})
    return points


def _execute_vertex_align_multi(self: Any, context: Any):
    raw = _s(getattr(self, "action", "ALIGN_CENTER")).upper() or "ALIGN_CENTER"
    snap = ri._snapshot_modes(context)
    objs, state = _ensure_multi_edit(context)
    if not objs:
        _report(self, "WARNING", _tr(context, "No mesh object is active.", "アクティブなメッシュオブジェクトがありません。"))
        return {"CANCELLED"}
    try:
        _prepare_unwrap_channel(context)
        targets = _target_data(context)
        if not targets:
            _report(self, "WARNING", _tr(context, "No editable UV map is available.", "編集可能なUVマップがありません。"))
            return {"CANCELLED"}
        mode = ri._uv_mode(context)
        source_records_all: List[Dict[str, Any]] = []
        group_sources: List[List[Dict[str, Any]]] = []
        by_group = raw in _GROUP_ACTIONS
        action = raw[:-6] if by_group else raw
        for obj, bm, uv_layer in targets:
            source_records, loops, edge_loops, faces = ri._selected_anchor_records(context, obj, bm, uv_layer, mode)
            if not source_records:
                continue
            source_records_all.extend(source_records)
            if by_group:
                try:
                    groups = ri._source_groups_from_selection(context, obj, bm, uv_layer, mode, source_records, edge_loops, faces)
                    group_sources.extend(groups or [])
                except Exception:
                    group_sources.append(source_records)
        if not source_records_all:
            _report(self, "WARNING", _tr(context, "No UV element is selected on any edited object.", "編集中のどのオブジェクトにも選択されたUVエレメントがありません。"))
            return {"CANCELLED"}
        sticky = ri._sticky_mode(context)
        followers = _all_followers_multi(targets, sticky)
        all_selected_ids = {id(r.get("loop")) for r in source_records_all}
        changed = 0
        sources = group_sources if by_group else [source_records_all]
        for source_group in sources:
            points = _pointify_multi(source_group, sticky, followers, all_selected_ids if by_group else None)
            changed += ri._apply_points(points, action)
        if changed <= 0:
            _report(self, "WARNING", _tr(context, "Vertex alignment did not change the selection.", "頂点整列で変更される選択がありませんでした。"))
            return {"CANCELLED"}
        _update_meshes(targets)
        try:
            if getattr(context, "area", None) is not None:
                context.area.tag_redraw()
        except Exception:
            pass
        return {"FINISHED"}
    except Exception as exc:
        _report(self, "WARNING", _tr(context, "Vertex direction alignment failed.", "方向整列（頂点）に失敗しました。") + f" {exc}")
        return {"CANCELLED"}
    finally:
        ri._restore_modes(snap)
        _restore_multi_edit(context, state)
        ri._restore_modes(snap)


def _face_selected_for_island(context: Any, face: Any, uv_layer: Any, mode: str) -> bool:
    sync = ri._sync_on(context)
    try:
        # Without UV Sync the mesh selection says which faces the UV editor shows, and
        # Blender keeps UV flags on the faces it hides.
        if not sync and not bool(getattr(face, "select", False)):
            return False
        if mode == "FACE":
            if sync and bool(getattr(face, "select", False)):
                return True
            # Blender 5.1 BMesh face UV selection is exposed as uv_select on faces.
            if bool(getattr(face, "uv_select", False)):
                return True
            return all(ri._live_v(loop, uv_layer) for loop in face.loops)
        if mode == "EDGE":
            if all(ri._live_e(loop, uv_layer) for loop in face.loops):
                return True
            if sync and all(bool(getattr(loop.edge, "select", False)) for loop in face.loops):
                return True
            return False
        if all(ri._live_v(loop, uv_layer) for loop in face.loops):
            return True
        if sync and all(bool(getattr(loop.vert, "select", False)) for loop in face.loops):
            return True
    except Exception:
        pass
    return False


def _selected_islands(obj: Any, bm: Any, uv_layer: Any, context: Any) -> List[Dict[str, Any]]:
    mode = ri._uv_mode(context)
    faces = [f for f in bm.faces if not getattr(f, "hide", False) and _face_selected_for_island(context, f, uv_layer, mode)]
    if not faces:
        return []
    pos = {f: i for i, f in enumerate(faces)}
    parent = list(range(len(faces)))
    face_set = set(faces)
    for face in faces:
        try:
            for edge in face.edges:
                la = next((l for l in face.loops if l.edge is edge), None)
                if la is None:
                    continue
                for other in edge.link_faces:
                    if other is face or other not in face_set:
                        continue
                    lb = next((l for l in other.loops if l.edge is edge), None)
                    if lb is not None and ri._same_uv_edge(la, lb, uv_layer):
                        ri._union(parent, pos[face], pos[other])
        except Exception:
            continue
    grouped: Dict[int, List[Any]] = defaultdict(list)
    for face in faces:
        grouped[ri._find(parent, pos[face])].append(face)
    islands: List[Dict[str, Any]] = []
    for group_faces in grouped.values():
        loops: List[Any] = []
        for face in group_faces:
            try:
                loops.extend(list(face.loops))
            except Exception:
                pass
        if not loops:
            continue
        us = [ri._uv_xy(loop, uv_layer)[0] for loop in loops]
        vs = [ri._uv_xy(loop, uv_layer)[1] for loop in loops]
        islands.append({
            "obj": obj,
            "uv_layer": uv_layer,
            "faces": group_faces,
            "loops": loops,
            "min_u": min(us), "max_u": max(us), "min_v": min(vs), "max_v": max(vs),
            "center_u": (min(us) + max(us)) * 0.5,
            "center_v": (min(vs) + max(vs)) * 0.5,
            "width": max(us) - min(us),
            "height": max(vs) - min(vs),
        })
    return islands


def _move_island(island: Dict[str, Any], du: float = 0.0, dv: float = 0.0) -> None:
    uv_layer = island.get("uv_layer")
    for loop in island.get("loops") or []:
        try:
            uv = loop[uv_layer].uv
            uv.x += float(du)
            uv.y += float(dv)
        except Exception:
            pass
    for key in ("min_u", "max_u", "center_u"):
        try:
            island[key] = float(island[key]) + float(du)
        except Exception:
            pass
    for key in ("min_v", "max_v", "center_v"):
        try:
            island[key] = float(island[key]) + float(dv)
        except Exception:
            pass


def _transform_island(island: Dict[str, Any], action: str) -> None:
    uv_layer = island.get("uv_layer")
    cu = float(island.get("center_u", 0.0)); cv = float(island.get("center_v", 0.0))
    for loop in island.get("loops") or []:
        try:
            uv = loop[uv_layer].uv
            du = float(uv.x) - cu; dv = float(uv.y) - cv
            if action == "MIRROR_H":
                uv.x = cu - du
            elif action == "MIRROR_V":
                uv.y = cv - dv
            elif action == "ROTATE_CCW":
                uv.x = cu - dv; uv.y = cv + du
            elif action == "ROTATE_CW":
                uv.x = cu + dv; uv.y = cv - du
        except Exception:
            pass


def _execute_island_align_multi(self: Any, context: Any):
    action = _s(getattr(self, "action", "ALIGN_CENTER")).upper() or "ALIGN_CENTER"
    snap = ri._snapshot_modes(context)
    objs, state = _ensure_multi_edit(context)
    if not objs:
        _report(self, "WARNING", _tr(context, "No mesh object is active.", "アクティブなメッシュオブジェクトがありません。"))
        return {"CANCELLED"}
    try:
        _prepare_unwrap_channel(context)
        scope = _scope_from_operator(self)
        targets, islands = _collect_islands_multi(context, scope)
        if not islands:
            _report(self, "WARNING", _tr(context, "No fully selected UV faces are available for island alignment.", "アイランド方向整列の対象になる完全選択UV面がありません。"))
            return {"CANCELLED"}
        min_u = min(float(i["min_u"]) for i in islands); max_u = max(float(i["max_u"]) for i in islands)
        min_v = min(float(i["min_v"]) for i in islands); max_v = max(float(i["max_v"]) for i in islands)
        center_u = (min_u + max_u) * 0.5; center_v = (min_v + max_v) * 0.5
        changed = 0
        if action in {"MIRROR_H", "MIRROR_V", "ROTATE_CCW", "ROTATE_CW"}:
            for island in islands:
                _transform_island(island, action)
                changed += 1
        elif action in {"DISTRIBUTE_H", "DISTRIBUTE_V"}:
            axis_u = action == "DISTRIBUTE_H"
            key = (lambda i: float(i["center_u"])) if axis_u else (lambda i: float(i["center_v"]))
            ordered = sorted(islands, key=key)
            if len(ordered) <= 1:
                _report(self, "WARNING", _tr(context, "At least two islands are required for distribution.", "均等配置には2つ以上のアイランドが必要です。"))
                return {"CANCELLED"}
            start = key(ordered[0]); end = key(ordered[-1])
            if abs(end - start) <= 1.0e-12:
                return {"CANCELLED"}
            step = (end - start) / float(max(1, len(ordered) - 1))
            for index, island in enumerate(ordered):
                target = start + step * index
                if axis_u:
                    _move_island(island, du=target - float(island["center_u"]))
                else:
                    _move_island(island, dv=target - float(island["center_v"]))
                changed += 1
        else:
            for island in islands:
                target_u = None; target_v = None
                if action in {"ALIGN_TL", "ALIGN_LEFT", "ALIGN_BL"}:
                    target_u = min_u + float(island["width"]) * 0.5
                elif action in {"ALIGN_TR", "ALIGN_RIGHT", "ALIGN_BR"}:
                    target_u = max_u - float(island["width"]) * 0.5
                elif action in {"ALIGN_CENTER", "ALIGN_V"}:
                    target_u = center_u
                if action in {"ALIGN_TL", "ALIGN_TOP", "ALIGN_TR"}:
                    target_v = max_v - float(island["height"]) * 0.5
                elif action in {"ALIGN_BL", "ALIGN_BOTTOM", "ALIGN_BR"}:
                    target_v = min_v + float(island["height"]) * 0.5
                elif action in {"ALIGN_CENTER", "ALIGN_H"}:
                    target_v = center_v
                du = 0.0 if target_u is None else float(target_u) - float(island["center_u"])
                dv = 0.0 if target_v is None else float(target_v) - float(island["center_v"])
                if abs(du) > 1.0e-12 or abs(dv) > 1.0e-12:
                    _move_island(island, du=du, dv=dv)
                    changed += 1
        if changed <= 0:
            _report(self, "WARNING", _tr(context, "Island alignment did not change the selection.", "アイランド方向整列で変更される対象がありませんでした。"))
            return {"CANCELLED"}
        _update_meshes(targets)
        return {"FINISHED"}
    except Exception as exc:
        _report(self, "WARNING", _tr(context, "Island direction alignment failed.", "アイランド方向整列に失敗しました。") + f" {exc}")
        return {"CANCELLED"}
    finally:
        ri._restore_modes(snap)
        _restore_multi_edit(context, state)
        ri._restore_modes(snap)


def _distance_to_segment(p: Tuple[float, float], a: Tuple[float, float], b: Tuple[float, float]) -> float:
    return ri._distance_to_segment(p, a, b)


def _direct_find_uv_hit_multi(self: Any, context: Any, event: Any) -> Optional[Dict[str, Any]]:
    xy = ri._event_region_xy(event)
    uv = ri._region_to_uv(context, xy[0], xy[1])
    if uv is None:
        return None
    targets = _target_data(context)
    if not targets:
        return None
    tol = ri._uv_hit_tolerance(context, xy[0], xy[1])
    mode = ri._uv_mode(context)
    best_v = None; best_e = None; best_f = None
    for obj, bm, uv_layer in targets:
        try:
            for face in bm.faces:
                if getattr(face, "hide", False):
                    continue
                pts: List[Tuple[float, float]] = []
                loops = list(face.loops)
                for loop in loops:
                    p = ri._uv_xy(loop, uv_layer); pts.append(p)
                    d = math.hypot(p[0] - uv[0], p[1] - uv[1])
                    if d <= tol and (best_v is None or d < best_v["dist"]):
                        best_v = {"type": "VERTEX", "dist": d, "obj": obj, "face": face, "loop": loop, "uv": p, "uv_layer": uv_layer}
                for i, loop in enumerate(loops):
                    if len(pts) < 2:
                        continue
                    d = _distance_to_segment(uv, pts[i], pts[(i + 1) % len(pts)])
                    if d <= tol and (best_e is None or d < best_e["dist"]):
                        best_e = {"type": "EDGE", "dist": d, "obj": obj, "face": face, "loop": loop, "edge": loop.edge, "uv": uv, "uv_layer": uv_layer}
                if len(pts) >= 3 and ri._point_in_poly(uv, pts) and best_f is None:
                    best_f = {"type": "FACE", "dist": 0.0, "obj": obj, "face": face, "loop": loops[0] if loops else None, "uv": uv, "uv_layer": uv_layer}
        except Exception:
            continue
    if mode == "VERTEX": hit = best_v
    elif mode == "EDGE": hit = best_e or best_v
    elif mode == "FACE": hit = best_f or (dict(best_e, type="FACE") if best_e else None) or (dict(best_v, type="FACE") if best_v else None)
    else: hit = best_v or best_e or best_f
    if not hit:
        return None
    # BM element wrappers do not own their BMesh wrapper. Keep the winning
    # edit BMesh alive until the caller has consumed the live hit.
    hit['_bmesh_owner'] = next(bm for obj, bm, _uv in targets if obj == hit['obj'])
    try:
        tl, te, tf = ri._target_from_hit(hit, hit.get("uv_layer"))
        hit["target_loops"] = tl; hit["target_edges"] = te; hit["target_faces"] = tf
    except Exception:
        pass
    return hit


def _hit_is_selected_multi(context: Any, hit: Dict[str, Any]) -> bool:
    return ri._hit_is_selected(context, hit)


def _select_hit_immediate_multi(context: Any, hit: Dict[str, Any], event: Any) -> bool:
    obj = hit.get("obj") or ri._active_mesh(context)
    if obj is None:
        return False
    try:
        import bmesh
        bm = bmesh.from_edit_mesh(obj.data); ri._ensure_lookup(bm); uv_layer = hit.get("uv_layer") or ri._uv_layer(bm)
        mode = ri._uv_mode(context)
        loops, edges, faces = ri._target_from_hit(hit, uv_layer)
        if not (loops or edges or faces):
            return False
        extend = bool(getattr(event, "shift", False)); toggle = bool(getattr(event, "ctrl", False))
        targets = _target_data(context)
        if not extend and not toggle:
            for other_obj, other_bm, other_uv in targets:
                if other_obj is obj:
                    continue
                ri._clear_selection(other_bm, other_uv, mesh=ri._sync_on(context))
        if extend or toggle:
            cur_loops, cur_edges, cur_faces = ri._selected_sets(context, obj, bm, uv_layer, mode)
            if toggle:
                if _hit_is_selected_multi(context, hit):
                    loops = cur_loops - loops; edges = cur_edges - edges; faces = cur_faces - faces
                else:
                    loops = cur_loops | loops; edges = cur_edges | edges; faces = cur_faces | faces
            else:
                loops = cur_loops | loops; edges = cur_edges | edges; faces = cur_faces | faces
        ri._apply_selection(context, obj, bm, uv_layer, mode, loops, edges, faces)
        _update_meshes(targets)
        return True
    except Exception:
        return False


def _invoke_instant_multi(self: Any, context: Any, event: Any):
    try:
        if _s(getattr(event, "type", "")) != "LEFTMOUSE" or _s(getattr(event, "value", "")) != "PRESS":
            return {"PASS_THROUGH"}
        if not ri._instant_enabled(context):
            return {"PASS_THROUGH"}
        try:
            if getattr(getattr(context, "space_data", None), "type", "") != "IMAGE_EDITOR":
                return {"PASS_THROUGH"}
        except Exception:
            return {"PASS_THROUGH"}
        if ri._native_tool_should_pass(context):
            return {"PASS_THROUGH"}
        hit = _direct_find_uv_hit_multi(self, context, event)
        if not hit:
            return {"PASS_THROUGH"}
        if _hit_is_selected_multi(context, hit):
            return {"PASS_THROUGH"}
        if not _select_hit_immediate_multi(context, hit, event):
            return {"PASS_THROUGH"}
        try:
            self._drag_start_x = int(getattr(event, "mouse_x", 0) or 0)
            self._drag_start_y = int(getattr(event, "mouse_y", 0) or 0)
        except Exception:
            pass
        try:
            context.window_manager.modal_handler_add(self)
            return {"RUNNING_MODAL"}
        except Exception:
            return {"FINISHED"}
    except Exception:
        return {"PASS_THROUGH"}


def _object_targets_for_data_ops(context: Any) -> List[Any]:
    return _selected_mesh_objects(context)


def _run_uvc_per_object(context: Any, fn: Any, *args: Any, **kwargs: Any) -> Tuple[int, str, Any]:
    targets = _object_targets_for_data_ops(context)
    if not targets or not callable(fn):
        return 0, _tr(context, "No mesh object is selected.", "メッシュオブジェクトが選択されていません。"), None
    was_edit = bool(_edit_mesh_objects(context))
    old_active = _active_object(context)
    selected = list(getattr(context, "selected_objects", []) or [])
    try:
        ws = ri._workspace(context)
    except Exception:
        ws = None
    ws_snapshot: Dict[str, Any] = {}
    if ws is not None:
        for attr in ("unwrap_map_channel", "unwrap_map_channel_name", "map_channel_object_name", "map_channel_copy_source", "map_channel_copy_destination", "map_channel_new_name", "uv_new_name"):
            try:
                ws_snapshot[attr] = getattr(ws, attr)
            except Exception:
                pass
    if was_edit:
        try:
            if bpy.ops.object.mode_set.poll():
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass
    ok_count = 0; last_message = ""; last_pair = None
    try:
        for obj in targets:
            # Per-object legacy functions are allowed to update workspace values.
            # Reset the user-selected target/source before each object so a move,
            # remove, or copy performed on the first object does not retarget the
            # second object to a different UV layer.  This was the remaining
            # single-object side effect in the 1.8.104 map-channel path.
            if ws is not None:
                for attr, value in ws_snapshot.items():
                    try:
                        setattr(ws, attr, value)
                    except Exception:
                        pass
            try:
                context.view_layer.objects.active = obj
                obj.select_set(True)
            except Exception:
                pass
            try:
                ok, message, pair = fn(context, *args, **kwargs)
            except Exception as exc:
                ok, message, pair = False, str(exc), None
            if ok:
                ok_count += 1
                last_message = str(message)
                last_pair = pair
        return ok_count, last_message or f"{ok_count}", last_pair
    finally:
        try:
            for obj in bpy.context.scene.objects:
                try:
                    obj.select_set(obj in selected)
                except Exception:
                    pass
        except Exception:
            pass
        try:
            if old_active is not None:
                context.view_layer.objects.active = old_active
        except Exception:
            pass
        if was_edit:
            try:
                if bpy.ops.object.mode_set.poll():
                    bpy.ops.object.mode_set(mode="EDIT")
            except Exception:
                pass



def _execute_map_channel_select_multi(self: Any, context: Any):
    from . import uv_map_channels as uvc
    try:
        index = int(getattr(self, "index", 0) or 0)
    except Exception:
        index = 0
    # 1.8.127: map-channel controls are list-selected-object operations, not
    # bulk operations over every selected mesh.  The UI list stores the object
    # name and uvc.select_map_channel resolves that object.
    ok, message, idx = uvc.select_map_channel(context, index)
    if not ok:
        _report(self, "WARNING", str(message))
        return {"CANCELLED"}
    _report(self, "INFO", _tr(context, f"Selected UV map channel: {message}", f"UVマップチャンネルを選択しました: {message}"))
    return {"FINISHED"}


def _execute_map_channel_add_multi(self: Any, context: Any):
    from . import uv_map_channels as uvc
    try:
        name = str(getattr(self, "name", "") or "")
    except Exception:
        name = ""
    ok, message, _idx = uvc.add_map_channel(context, name)
    if not ok:
        _report(self, "WARNING", str(message))
        return {"CANCELLED"}
    _report(self, "INFO", _tr(context, f"Added UV map channel: {message}", f"UVマップチャンネルを追加しました: {message}"))
    return {"FINISHED"}


def _execute_map_channel_remove_multi(self: Any, context: Any):
    from . import uv_map_channels as uvc
    ok, message, _idx = uvc.remove_map_channel(context)
    if not ok:
        _report(self, "WARNING", str(message))
        return {"CANCELLED"}
    _report(self, "INFO", _tr(context, f"Removed UV map channel: {message}", f"UVマップチャンネルを削除しました: {message}"))
    return {"FINISHED"}


def _execute_map_channel_move_multi(self: Any, context: Any):
    from . import uv_map_channels as uvc
    try:
        direction = int(getattr(self, "direction", -1) or -1)
    except Exception:
        direction = -1
    ok, message, _pair = uvc.reorder_map_channel(context, direction)
    if not ok:
        _report(self, "WARNING", str(message))
        return {"CANCELLED"}
    _report(self, "INFO", _tr(context, f"Moved UV map channel: {message}", f"UVマップチャンネルを移動しました: {message}"))
    return {"FINISHED"}


def _execute_map_channel_copy_multi(self: Any, context: Any):
    from . import uv_map_channels as uvc
    ok, message, _pair = uvc.copy_map_channel(context)
    if not ok:
        _report(self, "WARNING", str(message))
        return {"CANCELLED"}
    _report(self, "INFO", _tr(context, f"Copied UV map channel: {message}", f"UVマップチャンネルのUV展開情報をコピーしました: {message}"))
    return {"FINISHED"}


def _execute_original_on_each_mesh(self: Any, context: Any, original: Any, label: str = "operation"):
    """Run an active-object legacy UV operation on every selected mesh object.

    This is only used for legacy operators that still own their local algorithms
    but were written before Blender multi-object Edit Mode.  The wrapper keeps
    the user's selection/sync/sticky modes intact and avoids installing any
    modal or gizmo hooks.  Operators with a dedicated multi-object backend above
    are not routed through this generic fallback.
    """
    if not callable(original):
        return {"CANCELLED"}
    targets = _selected_mesh_objects(context)
    if len(targets) <= 1:
        try:
            return original(self, context)
        except TypeError:
            return original(context)
    snap = ri._snapshot_modes(context)
    was_edit = bool(_edit_mesh_objects(context))
    old_active = _active_object(context)
    try:
        old_selected = list(getattr(context, "selected_objects", []) or [])
    except Exception:
        old_selected = list(targets)
    finished = 0
    cancelled = 0
    try:
        if was_edit:
            try:
                if bpy.ops.object.mode_set.poll():
                    bpy.ops.object.mode_set(mode="OBJECT")
            except Exception:
                pass
        for obj in targets:
            try:
                for cand in bpy.context.scene.objects:
                    try:
                        cand.select_set(cand is obj)
                    except Exception:
                        pass
                context.view_layer.objects.active = obj
                obj.select_set(True)
            except Exception:
                pass
            try:
                # Most legacy UV operations expect Edit Mode and an active mesh.
                if getattr(obj, "mode", None) != "EDIT" and bpy.ops.object.mode_set.poll():
                    bpy.ops.object.mode_set(mode="EDIT")
            except Exception:
                pass
            try:
                result = original(self, context)
            except Exception:
                result = {"CANCELLED"}
            try:
                result_set = set(result or set())
            except Exception:
                result_set = {"CANCELLED"}
            if "FINISHED" in result_set:
                finished += 1
            elif "CANCELLED" in result_set:
                cancelled += 1
            try:
                if bpy.ops.object.mode_set.poll():
                    bpy.ops.object.mode_set(mode="OBJECT")
            except Exception:
                pass
        return {"FINISHED"} if finished > 0 else {"CANCELLED"}
    finally:
        try:
            for cand in bpy.context.scene.objects:
                try:
                    cand.select_set(cand in old_selected)
                except Exception:
                    pass
        except Exception:
            pass
        try:
            if old_active is not None:
                context.view_layer.objects.active = old_active
        except Exception:
            pass
        if was_edit:
            try:
                if bpy.ops.object.mode_set.poll():
                    bpy.ops.object.mode_set(mode="EDIT")
            except Exception:
                pass
        ri._restore_modes(snap)


def _make_generic_multi_execute(original: Any, label: str):
    def _execute(self: Any, context: Any):
        return _execute_original_on_each_mesh(self, context, original, label)
    try:
        _execute._sus_18104_multi_generic = True  # type: ignore[attr-defined]
        _execute._sus_18104_multi_label = label  # type: ignore[attr-defined]
    except Exception:
        pass
    return _execute


# -----------------------------------------------------------------------------
# Multi-object UV layout / flow island operator layer.
# -----------------------------------------------------------------------------
_LAYOUT_TO_ISLAND_ACTION = {
    "ALIGN_TL": "ALIGN_TL", "ALIGN_TOP": "ALIGN_TOP", "ALIGN_TR": "ALIGN_TR",
    "ALIGN_LEFT": "ALIGN_LEFT", "ALIGN_CENTER": "ALIGN_CENTER", "ALIGN_RIGHT": "ALIGN_RIGHT",
    "ALIGN_BL": "ALIGN_BL", "ALIGN_BOTTOM": "ALIGN_BOTTOM", "ALIGN_BR": "ALIGN_BR",
    "ALIGN_H": "ALIGN_H", "ALIGN_V": "ALIGN_V",
    "DISTRIBUTE_H": "DISTRIBUTE_H", "DISTRIBUTE_V": "DISTRIBUTE_V",
    "ROTATE_CCW": "ROTATE_CCW", "ROTATE_CW": "ROTATE_CW",
    "MIRROR_H": "MIRROR_H", "MIRROR_V": "MIRROR_V",
}


def _scope_from_operator(op: Any) -> str:
    scope = _s(getattr(op, "scope", "SELECTED")).upper() or "SELECTED"
    return "ALL" if scope == "ALL" else "SELECTED"


def _selected_islands_for_scope(obj: Any, bm: Any, uv_layer: Any, context: Any, scope: str = "SELECTED") -> List[Dict[str, Any]]:
    scope = _s(scope).upper() or "SELECTED"
    if scope == "ALL":
        faces = [f for f in bm.faces if not getattr(f, "hide", False)]
    else:
        mode = ri._uv_mode(context)
        faces = [f for f in bm.faces if not getattr(f, "hide", False) and _face_selected_for_island(context, f, uv_layer, mode)]
    if not faces:
        return []
    pos = {f: i for i, f in enumerate(faces)}
    parent = list(range(len(faces)))
    face_set = set(faces)
    for face in faces:
        try:
            for edge in face.edges:
                la = next((l for l in face.loops if l.edge is edge), None)
                if la is None:
                    continue
                for other in edge.link_faces:
                    if other is face or other not in face_set:
                        continue
                    lb = next((l for l in other.loops if l.edge is edge), None)
                    if lb is not None and ri._same_uv_edge(la, lb, uv_layer):
                        ri._union(parent, pos[face], pos[other])
        except Exception:
            continue
    grouped: Dict[int, List[Any]] = defaultdict(list)
    for face in faces:
        grouped[ri._find(parent, pos[face])].append(face)
    islands: List[Dict[str, Any]] = []
    for group_faces in grouped.values():
        loops: List[Any] = []
        for face in group_faces:
            try:
                loops.extend(list(face.loops))
            except Exception:
                pass
        if not loops:
            continue
        us = [ri._uv_xy(loop, uv_layer)[0] for loop in loops]
        vs = [ri._uv_xy(loop, uv_layer)[1] for loop in loops]
        islands.append({
            "obj": obj,
            "uv_layer": uv_layer,
            "faces": group_faces,
            "loops": loops,
            "min_u": min(us), "max_u": max(us), "min_v": min(vs), "max_v": max(vs),
            "center_u": (min(us) + max(us)) * 0.5,
            "center_v": (min(vs) + max(vs)) * 0.5,
            "width": max(us) - min(us),
            "height": max(vs) - min(vs),
        })
    return islands


def _collect_islands_multi(context: Any, scope: str = "SELECTED") -> Tuple[List[Tuple[Any, Any, Any]], List[Dict[str, Any]]]:
    _prepare_unwrap_channel(context)
    targets = _target_data(context)
    islands: List[Dict[str, Any]] = []
    for obj, bm, uv_layer in targets:
        islands.extend(_selected_islands_for_scope(obj, bm, uv_layer, context, scope))
    return targets, islands


def _refresh_island_bounds(island: Dict[str, Any]) -> None:
    uv_layer = island.get("uv_layer")
    loops = list(island.get("loops") or [])
    if not uv_layer or not loops:
        return
    us: List[float] = []
    vs: List[float] = []
    for loop in loops:
        try:
            uv = loop[uv_layer].uv
            us.append(float(uv.x)); vs.append(float(uv.y))
        except Exception:
            pass
    if not us or not vs:
        return
    island["min_u"] = min(us); island["max_u"] = max(us)
    island["min_v"] = min(vs); island["max_v"] = max(vs)
    island["center_u"] = (island["min_u"] + island["max_u"]) * 0.5
    island["center_v"] = (island["min_v"] + island["max_v"]) * 0.5
    island["width"] = island["max_u"] - island["min_u"]
    island["height"] = island["max_v"] - island["min_v"]


def _bounds_multi(islands: Sequence[Dict[str, Any]]) -> Optional[Tuple[float, float, float, float]]:
    if not islands:
        return None
    try:
        return (
            min(float(i["min_u"]) for i in islands),
            min(float(i["min_v"]) for i in islands),
            max(float(i["max_u"]) for i in islands),
            max(float(i["max_v"]) for i in islands),
        )
    except Exception:
        return None


def _tile_offset_multi(islands: Sequence[Dict[str, Any]]) -> Tuple[float, float]:
    if not islands:
        return (0.0, 0.0)
    try:
        cu = sum(float(i.get("center_u", 0.0)) for i in islands) / max(1, len(islands))
        cv = sum(float(i.get("center_v", 0.0)) for i in islands) / max(1, len(islands))
        return (math.floor(cu), math.floor(cv))
    except Exception:
        return (0.0, 0.0)


def _scale_islands_to_rect(islands: Sequence[Dict[str, Any]], dst_min: Tuple[float, float], dst_max: Tuple[float, float], *, keep_aspect: bool = True, keep_tile: bool = True) -> Tuple[bool, str]:
    bounds = _bounds_multi(islands)
    if bounds is None:
        return False, "No islands"
    min_u, min_v, max_u, max_v = bounds
    tile_u, tile_v = _tile_offset_multi(islands) if keep_tile else (0.0, 0.0)
    src_min_u = min_u - tile_u; src_min_v = min_v - tile_v
    src_max_u = max_u - tile_u; src_max_v = max_v - tile_v
    src_w = src_max_u - src_min_u; src_h = src_max_v - src_min_v
    dst_w = float(dst_max[0]) - float(dst_min[0]); dst_h = float(dst_max[1]) - float(dst_min[1])
    if src_w <= 1.0e-12 or src_h <= 1.0e-12 or dst_w <= 1.0e-12 or dst_h <= 1.0e-12:
        return False, "Zero-size bounds"
    if keep_aspect:
        scale = min(dst_w / src_w, dst_h / src_h)
        sx = sy = scale
        off_u = (dst_w - src_w * sx) * 0.5
        off_v = (dst_h - src_h * sy) * 0.5
    else:
        sx = dst_w / src_w; sy = dst_h / src_h
        off_u = off_v = 0.0
    for island in islands:
        uv_layer = island.get("uv_layer")
        for loop in island.get("loops") or []:
            try:
                uv = loop[uv_layer].uv
                lu = float(uv.x) - tile_u
                lv = float(uv.y) - tile_v
                uv.x = ((lu - src_min_u) * sx) + float(dst_min[0]) + off_u + tile_u
                uv.y = ((lv - src_min_v) * sy) + float(dst_min[1]) + off_v + tile_v
            except Exception:
                pass
        _refresh_island_bounds(island)
    return True, ""


def _call_island_action(op: Any, context: Any, action: str, scope: Optional[str] = None):
    class _Proxy:
        def __init__(self, owner: Any, action_value: str, scope_value: str):
            self._owner = owner
            self.action = action_value
            self.scope = scope_value
        def report(self, levels, message):
            try:
                self._owner.report(levels, message)
            except Exception:
                pass
    proxy = _Proxy(op, action, scope or _scope_from_operator(op))
    return _execute_island_align_multi(proxy, context)


def _execute_uv_layout_action_multi(self: Any, context: Any):
    action = _s(getattr(self, "action", "")).upper()
    scope = _scope_from_operator(self)
    mapped = _LAYOUT_TO_ISLAND_ACTION.get(action)
    if mapped:
        return _call_island_action(self, context, mapped, scope)
    # Compact crop/fill/fit layout commands are also active-object-only in the
    # legacy route.  Keep their UI and options, but process every edited mesh as
    # one UV editor selection domain.
    if action in {"CROP", "FILL", "FIT"}:
        tex, pad_px = (2048, 8)
        try:
            # The package helper returns (texture_size, padding_px).  It lives in
            # the package globals, so read it from _NS if available.
            helper = _NS.get("_sus_layout_workspace_values") if isinstance(_NS, dict) else None
            if callable(helper):
                tex, pad_px = helper(context)
        except Exception:
            pass
        pad = float(pad_px) / float(max(1, tex))
        keep_aspect = action != "FILL"
        return _execute_fit_rect_multi(self, context, pad, keep_aspect=keep_aspect, keep_tile=True, scope=scope, label=action)
    old = _PREV.get("SMARTUVSUITE_OT_uv_layout_action.execute")
    if callable(old):
        return old(self, context)
    _report(self, "WARNING", _tr(context, "Unknown UV layout action.", "不明なUVレイアウト操作です。"))
    return {"CANCELLED"}


def _execute_flow_align_islands_multi(self: Any, context: Any):
    axis = _s(getattr(self, "axis", "U")).upper() or "U"
    mode = _s(getattr(self, "mode", "CENTER")).upper() or "CENTER"
    mapping = {
        ("U", "MIN"): "ALIGN_LEFT", ("U", "CENTER"): "ALIGN_V", ("U", "MAX"): "ALIGN_RIGHT",
        ("V", "MIN"): "ALIGN_BOTTOM", ("V", "CENTER"): "ALIGN_H", ("V", "MAX"): "ALIGN_TOP",
    }
    return _call_island_action(self, context, mapping.get((axis, mode), "ALIGN_CENTER"), _scope_from_operator(self))


def _execute_flow_centralize_islands_multi(self: Any, context: Any):
    scope = _scope_from_operator(self)
    snap = ri._snapshot_modes(context)
    objs, state = _ensure_multi_edit(context)
    if not objs:
        _report(self, "WARNING", _tr(context, "No mesh object is active.", "アクティブなメッシュオブジェクトがありません。"))
        return {"CANCELLED"}
    try:
        targets, islands = _collect_islands_multi(context, scope)
        if not islands:
            _report(self, "WARNING", _tr(context, "No UV island is selected on any edited object.", "編集中のどのオブジェクトにも選択されたUVアイランドがありません。"))
            return {"CANCELLED"}
        bounds = _bounds_multi(islands)
        if bounds is None:
            return {"CANCELLED"}
        min_u, min_v, max_u, max_v = bounds
        own_u = (min_u + max_u) * 0.5; own_v = (min_v + max_v) * 0.5
        tile_u, tile_v = _tile_offset_multi(islands)
        du = tile_u + 0.5 - own_u
        dv = tile_v + 0.5 - own_v
        for island in islands:
            _move_island(island, du=du, dv=dv)
        _update_meshes(targets)
        return {"FINISHED"}
    finally:
        ri._restore_modes(snap); _restore_multi_edit(context, state); ri._restore_modes(snap)


def _execute_flow_distribute_islands_multi(self: Any, context: Any):
    axis = _s(getattr(self, "axis", "H")).upper() or "H"
    if not bool(getattr(self, "auto_gap", True)):
        return _distribute_fixed_gap_multi(self, context, axis)
    return _call_island_action(self, context, "DISTRIBUTE_H" if axis == "H" else "DISTRIBUTE_V", _scope_from_operator(self))


def _distribute_fixed_gap_multi(self: Any, context: Any, axis: str):
    gap = float(getattr(self, "spacing_px", 16)) / float(max(1, int(getattr(self, "texture_size", 2048))))
    lo, hi, center = ("min_u", "max_u", "center_u") if axis == "H" else ("min_v", "max_v", "center_v")
    snap = ri._snapshot_modes(context)
    objs, state = _ensure_multi_edit(context)
    if not objs:
        _report(self, "WARNING", _tr(context, "No mesh object is active.", "アクティブなメッシュオブジェクトがありません。"))
        return {"CANCELLED"}
    try:
        targets, islands = _collect_islands_multi(context, _scope_from_operator(self))
        if len(islands) < 2:
            _report(self, "WARNING", _tr(context, "Select at least two UV islands.", "UV アイランドを 2 つ以上選んでください。"))
            return {"CANCELLED"}
        islands.sort(key=lambda island: float(island[center]))
        position = float(islands[0][lo])
        for island in islands:
            delta = position - float(island[lo])
            position += float(island[hi]) - float(island[lo]) + gap
            _move_island(island, delta if axis == "H" else 0.0, delta if axis != "H" else 0.0)
        _update_meshes(targets)
        return {"FINISHED"}
    finally:
        ri._restore_modes(snap); _restore_multi_edit(context, state); ri._restore_modes(snap)


def _execute_flow_rotate_islands_multi(self: Any, context: Any):
    try:
        angle = float(getattr(self, "angle_rad", math.radians(90.0)) or 0.0)
    except Exception:
        angle = math.radians(90.0)
    # Preserve exact arbitrary-angle rotation by implementing it directly for
    # every selected island, instead of falling back to the legacy active object.
    scope = _scope_from_operator(self)
    snap = ri._snapshot_modes(context)
    objs, state = _ensure_multi_edit(context)
    if not objs:
        _report(self, "WARNING", _tr(context, "No mesh object is active.", "アクティブなメッシュオブジェクトがありません。"))
        return {"CANCELLED"}
    try:
        targets, islands = _collect_islands_multi(context, scope)
        if not islands:
            _report(self, "WARNING", _tr(context, "No UV island is selected on any edited object.", "編集中のどのオブジェクトにも選択されたUVアイランドがありません。"))
            return {"CANCELLED"}
        # Flow's rotate operator rotates each island around its own center.
        c = math.cos(angle); s = math.sin(angle)
        for island in islands:
            cu = float(island.get("center_u", 0.0)); cv = float(island.get("center_v", 0.0))
            uv_layer = island.get("uv_layer")
            for loop in island.get("loops") or []:
                try:
                    uv = loop[uv_layer].uv
                    du = float(uv.x) - cu; dv = float(uv.y) - cv
                    uv.x = cu + du * c - dv * s
                    uv.y = cv + du * s + dv * c
                except Exception:
                    pass
            _refresh_island_bounds(island)
        _update_meshes(targets)
        return {"FINISHED"}
    finally:
        ri._restore_modes(snap); _restore_multi_edit(context, state); ri._restore_modes(snap)


def _execute_flow_flip_islands_multi(self: Any, context: Any):
    axis = _s(getattr(self, "axis", "U")).upper() or "U"
    return _call_island_action(self, context, "MIRROR_H" if axis == "U" else "MIRROR_V", _scope_from_operator(self))


def _execute_fit_rect_multi(self: Any, context: Any, pad: float, *, keep_aspect: bool, keep_tile: bool, scope: str, label: str = "FIT"):
    snap = ri._snapshot_modes(context)
    objs, state = _ensure_multi_edit(context)
    if not objs:
        _report(self, "WARNING", _tr(context, "No mesh object is active.", "アクティブなメッシュオブジェクトがありません。"))
        return {"CANCELLED"}
    try:
        targets, islands = _collect_islands_multi(context, scope)
        if not islands:
            _report(self, "WARNING", _tr(context, "No UV island is selected on any edited object.", "編集中のどのオブジェクトにも選択されたUVアイランドがありません。"))
            return {"CANCELLED"}
        pad = max(0.0, min(0.49, float(pad)))
        ok, err = _scale_islands_to_rect(islands, (pad, pad), (1.0 - pad, 1.0 - pad), keep_aspect=keep_aspect, keep_tile=keep_tile)
        if not ok:
            _report(self, "WARNING", str(err or label))
            return {"CANCELLED"}
        _update_meshes(targets)
        return {"FINISHED"}
    finally:
        ri._restore_modes(snap); _restore_multi_edit(context, state); ri._restore_modes(snap)


def _execute_flow_fit_to_bounds_multi(self: Any, context: Any):
    try:
        pad = float(getattr(self, "padding_px", 8) or 0) / float(max(1, int(getattr(self, "texture_size", 2048) or 2048)))
    except Exception:
        pad = 8.0 / 2048.0
    return _execute_fit_rect_multi(self, context, pad, keep_aspect=True, keep_tile=bool(getattr(self, "keep_tile", True)), scope=_scope_from_operator(self), label="FIT")


def _execute_flow_crop_tile_multi(self: Any, context: Any):
    try:
        pad = float(getattr(self, "padding_px", 8) or 0) / float(max(1, int(getattr(self, "texture_size", 2048) or 2048)))
    except Exception:
        pad = 8.0 / 2048.0
    return _execute_fit_rect_multi(self, context, pad, keep_aspect=True, keep_tile=bool(getattr(self, "keep_tile", True)), scope=_scope_from_operator(self), label="CROP")


def _execute_flow_fill_tile_multi(self: Any, context: Any):
    try:
        pad = float(getattr(self, "padding_px", 8) or 0) / float(max(1, int(getattr(self, "texture_size", 2048) or 2048)))
    except Exception:
        pad = 8.0 / 2048.0
    return _execute_fit_rect_multi(self, context, pad, keep_aspect=bool(getattr(self, "keep_aspect", False)), keep_tile=bool(getattr(self, "keep_tile", True)), scope=_scope_from_operator(self), label="FILL")


def _patch_layout_flow_classes(ns: Dict[str, Any]) -> None:
    # Patch the compact UV layout operator in the package namespace.
    cls = ns.get("SMARTUVSUITE_OT_uv_layout_action")
    if isinstance(cls, type):
        key = "SMARTUVSUITE_OT_uv_layout_action.execute"
        cur = getattr(cls, "execute", None)
        if callable(cur) and key not in _PREV:
            _PREV[key] = cur
        try:
            setattr(_execute_uv_layout_action_multi, "_sus_18104_multi", True)
            cls.execute = _execute_uv_layout_action_multi
        except Exception:
            pass
    # Patch flow.py operators called by the compact layout board and direct UI.
    try:
        from . import flow as flow_mod
    except Exception:
        flow_mod = None
    if flow_mod is not None:
        flow_classes = {
            "SUV_OT_align_islands": _execute_flow_align_islands_multi,
            "SUV_OT_centralize_islands": _execute_flow_centralize_islands_multi,
            "SUV_OT_distribute_islands": _execute_flow_distribute_islands_multi,
            "SUV_OT_rotate_islands": _execute_flow_rotate_islands_multi,
            "SUV_OT_flip_islands": _execute_flow_flip_islands_multi,
            "SUV_OT_fit_to_bounds": _execute_flow_fit_to_bounds_multi,
            "SUV_OT_uv_crop_tile": _execute_flow_crop_tile_multi,
            "SUV_OT_uv_fill_tile": _execute_flow_fill_tile_multi,
        }
        for name, fn in flow_classes.items():
            fcls = getattr(flow_mod, name, None)
            if not isinstance(fcls, type):
                continue
            key = f"flow.{name}.execute"
            cur = getattr(fcls, "execute", None)
            if callable(cur) and key not in _PREV:
                _PREV[key] = cur
            try:
                setattr(fn, "_sus_18104_multi", True)
                fcls.execute = fn
            except Exception:
                pass

def _patch_operator_classes(ns: Dict[str, Any]) -> None:
    mapping = {
        "SMARTUVSUITE_OT_uv_element_select_action": ("execute", _execute_select_multi),
        "SMARTUVSUITE_OT_vertex_align_action": ("execute", _execute_vertex_align_multi),
        "SMARTUVSUITE_OT_island_direction_align": ("execute", _execute_island_align_multi),
        "SMARTUVSUITE_OT_instant_select_drag_move": ("invoke", _invoke_instant_multi),
    }
    for cls_name, (attr, fn) in mapping.items():
        cls = ns.get(cls_name)
        if isinstance(cls, type):
            key = f"{cls_name}.{attr}"
            cur = getattr(cls, attr, None)
            if callable(cur) and key not in _PREV:
                _PREV[key] = cur
            try:
                setattr(fn, "_sus_18104_multi", True)
                setattr(cls, attr, fn)
                if cls_name == "SMARTUVSUITE_OT_instant_select_drag_move":
                    cls._find_uv_hit = _direct_find_uv_hit_multi
            except Exception:
                pass

    # Map channel operators live in uv_map_channels.py, not necessarily in the
    # package globals.  Patch both locations when available.
    try:
        from . import uv_map_channels as uvc
        map_classes = {
            "SMARTUVSUITE_OT_map_channel_select": _execute_map_channel_select_multi,
            "SMARTUVSUITE_OT_map_channel_add": _execute_map_channel_add_multi,
            "SMARTUVSUITE_OT_map_channel_remove": _execute_map_channel_remove_multi,
            "SMARTUVSUITE_OT_map_channel_move": _execute_map_channel_move_multi,
            "SMARTUVSUITE_OT_map_channel_copy": _execute_map_channel_copy_multi,
        }
        for name, fn in map_classes.items():
            cls = getattr(uvc, name, None) or ns.get(name)
            if isinstance(cls, type):
                key = f"uvc.{name}.execute"
                cur = getattr(cls, "execute", None)
                if callable(cur) and key not in _PREV:
                    _PREV[key] = cur
                try:
                    setattr(fn, "_sus_18104_multi", True)
                    cls.execute = fn
                except Exception:
                    pass
    except Exception:
        pass



# Operators implemented before the room-integrity layers often fetch only
# context.active_object.  The final layer keeps their own logic, but replays it
# per selected/edit mesh object when Blender is in multi-object editing or when
# multiple mesh objects are selected.  This is deliberately conservative: custom
# global multi-object implementations above are skipped, and operators that
# already iterate selected_objects / objects_in_mode_unique_data are not wrapped.
_GENERIC_SKIP_CLASS_NAMES = {
    "SMARTUVSUITE_OT_uv_element_select_action",
    "SMARTUVSUITE_OT_vertex_align_action",
    "SMARTUVSUITE_OT_island_direction_align",
    "SMARTUVSUITE_OT_instant_select_drag_move",
    "SMARTUVSUITE_OT_map_channel_select",
    "SMARTUVSUITE_OT_map_channel_add",
    "SMARTUVSUITE_OT_map_channel_remove",
    "SMARTUVSUITE_OT_map_channel_move",
    "SMARTUVSUITE_OT_map_channel_copy",
}
_GENERIC_MODULES = (
    # Modules with older operators that use only context.active_object / context.object.
    # They are imported explicitly so the final multi-object layer can wrap them even
    # when their classes are not re-exported from the package namespace yet.
    "flow",
    "legacy_operators",
    "native_stage",
    "native_unified_tools",
    "consolidated_uv_tools",
    "pro_operators",
    "selection_operators",
    "symmetry_atlas_operators",
    "unified_packing",
)
_ACTIVE_ONLY_TOKENS = (
    "_active_mesh_obj(context)",
    "context.active_object",
    "context.object",
    "context.edit_object",
    "bpy.context.object",
    "bpy.context.active_object",
)
_ALREADY_MULTI_TOKENS = (
    "_selected_mesh_objects(context)",
    "selected_objects",
    "objects_in_mode_unique_data",
    "objects_in_mode",
)


def _generic_target_objects(context: Any) -> List[Any]:
    objs = _edit_mesh_objects(context)
    if len(objs) > 1:
        return objs
    selected = _selected_mesh_objects(context)
    if len(selected) > 1:
        return selected
    return objs or selected


def _call_operator_per_object(self: Any, context: Any, original_execute: Any):
    # Use the conservative per-object runner above.  It explicitly isolates the
    # active object for each legacy call, preventing native bpy.ops.uv calls from
    # being replayed on the whole multi-edit selection multiple times.
    return _execute_original_on_each_mesh(self, context, original_execute, "generic_active_object_operator")

def _function_source_with_closure(fn: Any, depth: int = 0, seen: Optional[Set[int]] = None) -> str:
    """Return a bounded token string for active-object detection.

    Earlier builds used inspect.getsource() recursively on operator closures.  On
    the consolidated __init__.py this repeatedly read very large source blocks
    during add-on registration and could stall or terminate Blender while heavy
    edit data was already open.  The generic multi-object detector only needs to
    know whether active-object tokens occur, so code-object names/constants are
    sufficient and avoid file I/O entirely.
    """
    if seen is None:
        seen = set()
    if fn is None or depth > 4:
        return ""
    try:
        key = id(fn)
        if key in seen:
            return ""
        seen.add(key)
    except Exception:
        pass
    chunks: List[str] = []
    try:
        co = getattr(fn, "__code__", None)
        if co is not None:
            names = list(getattr(co, "co_names", ()) or ())
            names.extend(str(v) for v in (getattr(co, "co_varnames", ()) or ()))
            names.extend(str(c) for c in (getattr(co, "co_consts", ()) or ()) if isinstance(c, str))
            chunks.append(" ".join(names))
    except Exception:
        pass
    try:
        for cell in getattr(fn, "__closure__", None) or []:
            try:
                obj = cell.cell_contents
            except Exception:
                continue
            if callable(obj):
                chunks.append(_function_source_with_closure(obj, depth + 1, seen))
    except Exception:
        pass
    return "\n".join(c for c in chunks if c)


def _operator_looks_active_only(cls: type, execute_fn: Any) -> bool:
    if getattr(execute_fn, "_sus_18104_generic_multi", False):
        return False
    source = _function_source_with_closure(execute_fn)
    if not any(token in source for token in _ACTIVE_ONLY_TOKENS):
        return False
    if any(token in source for token in _ALREADY_MULTI_TOKENS):
        return False
    return True


def _patch_generic_active_object_operators(ns: Dict[str, Any]) -> None:
    global _GENERIC_PATCH_COMPLETE
    if _GENERIC_PATCH_COMPLETE:
        return
    modules: List[Any] = []
    import sys
    pkg = sys.modules.get(__package__)
    if pkg is not None:
        modules.append(pkg)
    for name in _GENERIC_MODULES:
        try:
            modules.append(__import__(f"{__package__}.{name}", fromlist=["*"]))
        except Exception:
            continue
    for mod in modules:
        try:
            items = list(vars(mod).items())
        except Exception:
            continue
        for cls_name, cls in items:
            if cls_name in _GENERIC_SKIP_CLASS_NAMES or not isinstance(cls, type):
                continue
            try:
                bl_id = str(getattr(cls, "bl_idname", "") or "")
            except Exception:
                bl_id = ""
            if not (bl_id.startswith("smart_uv_suite.") or bl_id.startswith("uv.suv_") or bl_id.startswith("mesh.suv_") or bl_id.startswith("object.suv_")):
                continue
            execute_fn = getattr(cls, "execute", None)
            if not callable(execute_fn) or not _operator_looks_active_only(cls, execute_fn):
                continue
            key = f"generic.{getattr(mod, '__name__', '')}.{cls_name}.execute"
            if key not in _PREV:
                _PREV[key] = execute_fn
            original = _PREV[key]
            def _make(orig):
                def _execute(self, context):
                    return _call_operator_per_object(self, context, orig)
                try:
                    _execute._sus_18104_generic_multi = True  # type: ignore[attr-defined]
                except Exception:
                    pass
                return _execute
            try:
                cls.execute = _make(original)
            except Exception:
                pass
    _GENERIC_PATCH_COMPLETE = True

def _mark_version(ns: Dict[str, Any]) -> None:
    try:
        info = ns.get("bl_info")
        if not isinstance(info, dict):
            info = {}; ns["bl_info"] = info
        info.update({
            "name": "Smart UV Suite",
            "author": "JELararagi",
            "version": (1, 0, 0),
            "blender": (5, 1, 0),
            "location": "View3D / UV Editor > Sidebar > Smart UV",
            "description": "Smart UV Suite exposes UV editing tools in the Smart UV sidebar.",
            "category": "Smart UV",
        })
        ns["_SUS_BL_INFO_FALLBACK"] = dict(info)
        ns["__version__"] = '1.0.0'
    except Exception:
        pass


def _wrap_sync(ns: Dict[str, Any]) -> None:
    base = ns.get("_sus_1652_sync_keymaps_from_workspace")
    if callable(base) and not getattr(base, "_sus_18104_multi_sync", False):
        _PREV["sync"] = base
    base = _PREV.get("sync")
    def _sync_18104(context=None):
        ctx = context or getattr(bpy, "context", None)
        if callable(base) and base is not _sync_18104:
            try:
                base(ctx)
            except TypeError:
                try: base()
                except Exception: pass
            except RecursionError:
                pass
            except Exception:
                pass
        try:
            apply_all(ns, ctx)
        except RecursionError:
            pass
        except Exception:
            pass
    try:
        _sync_18104._sus_18104_multi_sync = True  # type: ignore[attr-defined]
    except Exception:
        pass
    ns["_sus_1652_sync_keymaps_from_workspace"] = _sync_18104


def apply_all(ns: Optional[Dict[str, Any]] = None, context: Any = None) -> None:
    global _NS
    if isinstance(ns, dict):
        _NS = ns
    elif not _NS:
        import sys
        mod = sys.modules.get(__package__)
        if mod is not None:
            _NS = getattr(mod, "__dict__", {})
    target = _NS if isinstance(_NS, dict) else {}
    if not target:
        return
    try:
        ri.apply_all(target, context or getattr(bpy, "context", None))
    except Exception:
        pass
    _patch_operator_classes(target)
    _patch_layout_flow_classes(target)
    _patch_generic_active_object_operators(target)
    _wrap_sync(target)
    _mark_version(target)


def install(ns: Optional[Dict[str, Any]] = None, context: Any = None) -> None:
    global _INSTALLED
    apply_all(ns, context or getattr(bpy, "context", None))
    _INSTALLED = True


def unregister() -> None:
    # Keep 1.8.103 keymap cleanup policy.
    try:
        ri.unregister()
    except Exception:
        pass


def audit(context: Any = None) -> Dict[str, Any]:
    ctx = context or getattr(bpy, "context", None)
    base = {}
    try:
        base = ri.audit(ctx)
    except Exception:
        base = {}
    checks: Dict[str, Any] = dict(base)
    checks["version"] = (1, 0, 0)
    checks["multi_patch"] = {}
    for cls_name, attr in (
        ("SMARTUVSUITE_OT_uv_element_select_action", "execute"),
        ("SMARTUVSUITE_OT_vertex_align_action", "execute"),
        ("SMARTUVSUITE_OT_island_direction_align", "execute"),
        ("SMARTUVSUITE_OT_instant_select_drag_move", "invoke"),
    ):
        cls = _NS.get(cls_name) if isinstance(_NS, dict) else None
        fn = getattr(cls, attr, None) if isinstance(cls, type) else None
        ok = bool(getattr(fn, "_sus_18104_multi", False))
        checks["multi_patch"][cls_name] = ok
        if cls_name == "SMARTUVSUITE_OT_uv_element_select_action":
            checks["select_execute_multi"] = ok
        elif cls_name == "SMARTUVSUITE_OT_vertex_align_action":
            checks["vertex_execute_multi"] = ok
        elif cls_name == "SMARTUVSUITE_OT_island_direction_align":
            checks["island_execute_multi"] = ok
        elif cls_name == "SMARTUVSUITE_OT_instant_select_drag_move":
            checks["instant_invoke_multi"] = ok
    try:
        from . import uv_map_channels as uvc
        for name in ("SMARTUVSUITE_OT_map_channel_select", "SMARTUVSUITE_OT_map_channel_add", "SMARTUVSUITE_OT_map_channel_remove", "SMARTUVSUITE_OT_map_channel_move", "SMARTUVSUITE_OT_map_channel_copy"):
            cls = getattr(uvc, name, None)
            checks["multi_patch"][name] = bool(getattr(getattr(cls, "execute", None), "_sus_18104_multi", False))
    except Exception:
        pass
    try:
        cls = _NS.get("SMARTUVSUITE_OT_uv_layout_action") if isinstance(_NS, dict) else None
        checks["multi_patch"]["SMARTUVSUITE_OT_uv_layout_action"] = bool(getattr(getattr(cls, "execute", None), "_sus_18104_multi", False))
    except Exception:
        pass
    try:
        from . import flow as flow_mod
        for name in ("SUV_OT_align_islands", "SUV_OT_centralize_islands", "SUV_OT_distribute_islands", "SUV_OT_rotate_islands", "SUV_OT_flip_islands", "SUV_OT_fit_to_bounds", "SUV_OT_uv_crop_tile", "SUV_OT_uv_fill_tile"):
            cls = getattr(flow_mod, name, None)
            checks["multi_patch"][f"flow.{name}"] = bool(getattr(getattr(cls, "execute", None), "_sus_18104_multi", False))
    except Exception:
        pass
    try:
        checks["generic_multi_wrappers"] = sum(1 for k in _PREV if str(k).startswith("generic."))
    except Exception:
        checks["generic_multi_wrappers"] = 0
    try:
        checks["edit_object_count"] = len(_edit_mesh_objects(ctx)) if ctx is not None else 0
    except Exception:
        checks["edit_object_count"] = 0
    return checks
