# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Smart UV Suite 1.8.106 UV selection correctness layer.

This is the final authority for UV selection behaviour after the 1.8.105 loop
and grouped-distribution changes.  It separates three paths that must not bleed
into one another:

* normal UV edge selection: select only the clicked/target edge;
* Loop Selection: follow connected edge-loop continuity through UV-connected
  endpoints;
* Ring Selection: traverse opposite edges across quad faces.

The module also tightens the Immediate Select keymap so the add-on does not
hijack ordinary Blender click selection while still allowing drag-to-move from
UV Tweak / UV Editor drag contexts.
"""
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

from collections import defaultdict, deque
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple
import math

import bpy

from . import uv_room_integrity_18103 as ri
from . import uv_multi_object_18104 as mo

_VERSION = (1, 8, 106)
_NS: Dict[str, Any] = {}
_PREV: Dict[str, Any] = {}
_EPS = 1.0e-7
_DIGITS = 7
_INSTANT_ID = "smart_uv_suite.instant_select_drag_move"
_STICKY_PASS_ID = "smart_uv_suite.sticky_select_expand_passthrough"
_GIZMO_GRIP_ID = "smart_uv_suite.uv_gizmo_grip_fix_grab"

# Keep Immediate Select available through explicit UV-editor and Tweak-tool
# LEFTMOUSE PRESS rows.  The invoke path still passes through ordinary selected
# hits, empty/background hits, gizmos and modifier clicks, while PRESS removes
# the intermittent missed-start cases caused by waiting for Blender's drag
# recognition before the operator receives the event.
_INSTANT_KEYMAP_POLICY: Tuple[Tuple[str, str, str], ...] = (
    ("UV Editor", "IMAGE_EDITOR", "PRESS"),
    ("Image Editor Tool: Uv, Tweak", "IMAGE_EDITOR", "PRESS"),
    ("Image Editor Tool: Uv, Tweak (fallback)", "IMAGE_EDITOR", "PRESS"),
)
_REMOVE_INSTANT_MAPS: Tuple[str, ...] = (
    "Window", "Image", "Image Generic", "Generic Gizmo", "Generic Gizmo Drag",
    "Generic Gizmo Click Drag", "Generic Gizmo Maybe Drag", "Generic Gizmo Select",
    "Image Editor Tool: Uv, Move", "Image Editor Tool: Uv, Move (fallback)",
    "Image Editor Tool: Uv, Rotate", "Image Editor Tool: Uv, Rotate (fallback)",
    "Image Editor Tool: Uv, Scale", "Image Editor Tool: Uv, Scale (fallback)",
    "Image Editor Tool: Uv, Transform", "Image Editor Tool: Uv, Transform (fallback)",
    "Image Editor Tool: Uv, Cursor", "Image Editor Tool: Uv, Cursor (fallback)",
    "Image Editor Tool: Uv, Select Box", "Image Editor Tool: Uv, Select Box (fallback)",
    "Image Editor Tool: Uv, Select Lasso", "Image Editor Tool: Uv, Select Lasso (fallback)",
    "Image Editor Tool: Uv, Select Circle", "Image Editor Tool: Uv, Select Circle (fallback)",
)


def _s(value: Any) -> str:
    try:
        return str(value or "")
    except Exception:
        return ""


def _report(op: Any, level: str, message: str) -> None:
    try:
        op.report({level}, message)
    except Exception:
        pass


def _tr(context: Any, en: str, ja: str) -> str:
    return ri._tr(context, en, ja)


def _hidden(elem: Any) -> bool:
    try:
        return bool(getattr(elem, "hide", False))
    except Exception:
        return False


def _uv_key(loop: Any, uv_layer: Any) -> Tuple[float, float]:
    try:
        u, v = ri._uv_xy(loop, uv_layer)
        return (round(float(u), _DIGITS), round(float(v), _DIGITS))
    except Exception:
        return (0.0, 0.0)


def _endpoint_key(loop: Any, uv_layer: Any) -> Tuple[int, Tuple[float, float]]:
    try:
        vi = int(getattr(loop.vert, "index", -1))
    except Exception:
        vi = -1
    return (vi, _uv_key(loop, uv_layer))


def _edge_visual_key(loop: Any, uv_layer: Any) -> Tuple[Any, Any]:
    a = _endpoint_key(loop, uv_layer)
    try:
        b = _endpoint_key(loop.link_loop_next, uv_layer)
    except Exception:
        b = a
    return tuple(sorted((a, b), key=lambda x: (x[0], x[1][0], x[1][1])))  # type: ignore[return-value]


def _uv_vec_between_keys(a: Tuple[int, Tuple[float, float]], b: Tuple[int, Tuple[float, float]]) -> Tuple[float, float]:
    return (float(b[1][0]) - float(a[1][0]), float(b[1][1]) - float(a[1][1]))


def _norm2(v: Tuple[float, float]) -> float:
    return math.hypot(float(v[0]), float(v[1]))


def _unit2(v: Tuple[float, float]) -> Optional[Tuple[float, float]]:
    n = _norm2(v)
    if n <= _EPS:
        return None
    return (float(v[0]) / n, float(v[1]) / n)


def _dot2(a: Optional[Tuple[float, float]], b: Optional[Tuple[float, float]]) -> float:
    if a is None or b is None:
        return -2.0
    return float(a[0] * b[0] + a[1] * b[1])


def _same_uv_edge_loop(a: Any, b: Any, uv_layer: Any) -> bool:
    try:
        return ri._same_uv_edge(a, b, uv_layer)
    except Exception:
        return _edge_visual_key(a, uv_layer) == _edge_visual_key(b, uv_layer)


class _VisualEdge:
    __slots__ = ("key", "loops", "faces", "mesh_edges", "endpoints", "center", "length")

    def __init__(self, key: Tuple[Any, Any]):
        self.key = key
        self.loops: List[Any] = []
        self.faces: Set[Any] = set()
        self.mesh_edges: Set[Any] = set()
        self.endpoints: Tuple[Any, Any] = key  # type: ignore[assignment]
        self.center = (0.0, 0.0)
        self.length = 0.0


def _collect_visual_edges(bm: Any, uv_layer: Any) -> Tuple[Dict[Tuple[Any, Any], _VisualEdge], Dict[Any, List[_VisualEdge]]]:
    edges: Dict[Tuple[Any, Any], _VisualEdge] = {}
    by_endpoint: Dict[Any, List[_VisualEdge]] = defaultdict(list)
    try:
        faces = [f for f in bm.faces if not _hidden(f)]
    except Exception:
        faces = []
    for face in faces:
        try:
            loops = list(face.loops)
        except Exception:
            loops = []
        for loop in loops:
            try:
                if _hidden(loop.edge) or _hidden(loop.vert):
                    continue
            except Exception:
                pass
            key = _edge_visual_key(loop, uv_layer)
            rec = edges.get(key)
            if rec is None:
                rec = _VisualEdge(key)
                rec.endpoints = key  # sorted endpoints
                p0 = key[0][1]; p1 = key[1][1]
                rec.center = ((float(p0[0]) + float(p1[0])) * 0.5, (float(p0[1]) + float(p1[1])) * 0.5)
                rec.length = math.hypot(float(p1[0]) - float(p0[0]), float(p1[1]) - float(p0[1]))
                edges[key] = rec
                by_endpoint[key[0]].append(rec)
                if key[1] != key[0]:
                    by_endpoint[key[1]].append(rec)
            rec.loops.append(loop)
            try:
                rec.faces.add(face)
            except Exception:
                pass
            try:
                rec.mesh_edges.add(loop.edge)
            except Exception:
                pass
    return edges, by_endpoint


def _selected_visual_edge_keys(edge_loops: Iterable[Any], uv_layer: Any) -> Set[Tuple[Any, Any]]:
    out: Set[Tuple[Any, Any]] = set()
    for loop in list(edge_loops or []):
        try:
            if loop is None or _hidden(loop.edge):
                continue
            out.add(_edge_visual_key(loop, uv_layer))
        except Exception:
            pass
    return out


def _edge_other_endpoint(rec: _VisualEdge, endpoint: Any) -> Any:
    a, b = rec.endpoints
    return b if endpoint == a else a


def _edge_direction_from_endpoint(rec: _VisualEdge, endpoint: Any) -> Optional[Tuple[float, float]]:
    other = _edge_other_endpoint(rec, endpoint)
    try:
        return _unit2(_uv_vec_between_keys(endpoint, other))
    except Exception:
        return None


def _edge_shares_face(a: _VisualEdge, b: _VisualEdge) -> bool:
    try:
        return bool(a.faces & b.faces)
    except Exception:
        return False


def _loop_next_visual_edge(current: _VisualEdge, endpoint: Any, by_endpoint: Dict[Any, List[_VisualEdge]], visited: Set[Tuple[Any, Any]]) -> Optional[_VisualEdge]:
    candidates: List[_VisualEdge] = []
    for cand in list(by_endpoint.get(endpoint, []) or []):
        if cand.key == current.key or cand.key in visited:
            continue
        if cand.length <= _EPS:
            continue
        candidates.append(cand)
    if not candidates:
        return None

    # For actual edge loops, the continuation normally leaves a vertex through an
    # edge that does not belong to the same quad face as the incoming edge.  If no
    # such candidate exists, use the straightest connected edge so boundary loops
    # still work.  This prevents Ring-style opposite-face traversal from entering
    # the Loop path while still allowing bent connected loops.
    non_shared = [c for c in candidates if not _edge_shares_face(current, c)]
    incoming_other = _edge_other_endpoint(current, endpoint)
    incoming_dir = _unit2(_uv_vec_between_keys(incoming_other, endpoint))

    def score(cand: _VisualEdge) -> Tuple[float, float, str]:
        outgoing = _edge_direction_from_endpoint(cand, endpoint)
        straight = _dot2(incoming_dir, outgoing)
        return (straight, cand.length, repr(cand.key))

    if non_shared:
        try:
            return max(non_shared, key=score)
        except Exception:
            return non_shared[0]

    # At boundaries and poles there may be no topological opposite/non-shared
    # continuation.  Do not turn a normal loop into a border-walk or ring-like
    # sweep.  Continue only when the remaining shared-face candidate is still
    # roughly in the incoming direction.  The low threshold accepts smooth bends
    # while rejecting perpendicular 90-degree turns around the island boundary.
    try:
        best = max(candidates, key=score)
        if score(best)[0] >= 0.25:
            return best
    except Exception:
        pass
    return None


def _walk_loop_visual(seed: _VisualEdge, endpoint: Any, by_endpoint: Dict[Any, List[_VisualEdge]], out: Set[Tuple[Any, Any]], limit: int) -> None:
    current = seed
    at = endpoint
    steps = 0
    while steps < limit:
        steps += 1
        nxt = _loop_next_visual_edge(current, at, by_endpoint, out)
        if nxt is None:
            break
        out.add(nxt.key)
        at = _edge_other_endpoint(nxt, at)
        current = nxt


def _visual_loop_keys(seed_keys: Set[Tuple[Any, Any]], visual_edges: Dict[Tuple[Any, Any], _VisualEdge], by_endpoint: Dict[Any, List[_VisualEdge]]) -> Set[Tuple[Any, Any]]:
    out: Set[Tuple[Any, Any]] = set(k for k in seed_keys if k in visual_edges)
    limit = max(32, len(visual_edges) + 8)
    for key in list(out):
        rec = visual_edges.get(key)
        if rec is None:
            continue
        for endpoint in rec.endpoints:
            _walk_loop_visual(rec, endpoint, by_endpoint, out, limit)
    return out


def _opposite_visual_edge_in_face(face: Any, mesh_edge: Any, uv_layer: Any) -> Optional[Tuple[Any, Any]]:
    try:
        loops = list(face.loops)
    except Exception:
        loops = []
    if len(loops) != 4:
        return None
    idx = -1
    for i, loop in enumerate(loops):
        try:
            if loop.edge is mesh_edge:
                idx = i
                break
        except Exception:
            pass
    if idx < 0:
        return None
    try:
        return _edge_visual_key(loops[(idx + 2) % 4], uv_layer)
    except Exception:
        return None


def _visual_ring_keys(seed_keys: Set[Tuple[Any, Any]], visual_edges: Dict[Tuple[Any, Any], _VisualEdge], uv_layer: Any) -> Set[Tuple[Any, Any]]:
    out: Set[Tuple[Any, Any]] = set(k for k in seed_keys if k in visual_edges)
    q = deque(out)
    while q:
        key = q.popleft()
        rec = visual_edges.get(key)
        if rec is None:
            continue
        for face in list(rec.faces):
            for mesh_edge in list(rec.mesh_edges):
                opp = _opposite_visual_edge_in_face(face, mesh_edge, uv_layer)
                if opp is None or opp not in visual_edges or opp in out:
                    continue
                out.add(opp)
                q.append(opp)
    return out


def _edge_loops_from_visual_keys(keys: Set[Tuple[Any, Any]], visual_edges: Dict[Tuple[Any, Any], _VisualEdge]) -> Set[Any]:
    out: Set[Any] = set()
    for key in keys:
        rec = visual_edges.get(key)
        if rec is None:
            continue
        for loop in rec.loops:
            out.add(loop)
    return out


def _selection_loop_ring_18106(context: Any, obj: Any, bm: Any, uv_layer: Any, action: str, loops: Set[Any], edge_loops: Set[Any]):
    action = _s(action).upper()
    mode = ri._uv_mode(context)
    # Loop/Ring are edge-selection operations.  Do not infer seed edges from
    # endpoint vertex flags; that was the source of plain edge/vertex selections
    # expanding into loop-like selections and of loop/ring direction ambiguity.
    seed_keys = _selected_visual_edge_keys(edge_loops, uv_layer)
    if not seed_keys:
        return set(), set(), set()
    visual_edges, by_endpoint = _collect_visual_edges(bm, uv_layer)
    if not visual_edges:
        return set(), set(), set()
    selected_keys = _visual_ring_keys(seed_keys, visual_edges, uv_layer) if action == "RING" else _visual_loop_keys(seed_keys, visual_edges, by_endpoint)
    out_edges = _edge_loops_from_visual_keys(selected_keys, visual_edges)
    if mode == "FACE":
        return set(), set(), {loop.face for loop in out_edges if getattr(loop, "face", None) is not None}
    if mode == "VERTEX":
        out_loops: Set[Any] = set()
        for loop in out_edges:
            out_loops.add(loop)
            try:
                out_loops.add(loop.link_loop_next)
            except Exception:
                pass
        return out_loops, set(), set()
    return set(), out_edges, set()


# Public aliases kept for tests/audit.
strict_selection_loop_ring = _selection_loop_ring_18106


def _execute_select_multi_18106(self: Any, context: Any):
    # Mirrors 1.8.104 multi-object selection, but explicitly uses the strict
    # Loop/Ring path and refuses vertex-only seeds for those two actions.
    action = _s(getattr(self, "action", "GROW")).upper() or "GROW"
    snap = ri._snapshot_modes(context)
    objs, state = mo._ensure_multi_edit(context)
    if not objs:
        _report(self, "WARNING", _tr(context, "No mesh object is active.", "アクティブなメッシュオブジェクトがありません。"))
        return {"CANCELLED"}
    try:
        mo._prepare_unwrap_channel(context)
        targets = mo._target_data(context)
        if not targets:
            _report(self, "WARNING", _tr(context, "No editable UV map is available.", "編集可能なUVマップがありません。"))
            return {"CANCELLED"}
        mode = ri._uv_mode(context)
        touched = 0
        for obj, bm, uv_layer in targets:
            ri._sync_uv_flags_from_mesh(context, bm)
            loops, edge_loops, faces = ri._selected_sets(context, obj, bm, uv_layer, mode)
            apply_mode = mode
            if action == "NONE":
                ri._clear_selection(bm, uv_layer, mesh=ri._sync_on(context)); touched += 1; continue
            if action == "ALL":
                all_loops, all_edges, all_faces = ri._all_sets(bm)
                ri._apply_selection(context, obj, bm, uv_layer, mode, all_loops, all_edges, all_faces)
                touched += 1; continue
            if action in {"LOOP", "RING"}:
                if not edge_loops:
                    # Do not convert a normal vertex endpoint selection into an
                    # implicit edge loop.  This keeps ordinary selection stable.
                    continue
                out = _selection_loop_ring_18106(context, obj, bm, uv_layer, action, loops, edge_loops)
            else:
                if not (loops or edge_loops or faces):
                    continue
                if action == "GROW":
                    out = ri._selection_grow(mode, bm, uv_layer, loops, edge_loops, faces, sync=ri._sync_on(context))
                elif action == "SHRINK":
                    out = ri._selection_shrink(mode, bm, uv_layer, loops, edge_loops, faces, sync=ri._sync_on(context))
                elif action == "LINKED":
                    out = ri._selection_linked(mode, bm, uv_layer, loops, edge_loops, faces, sync=ri._sync_on(context))
                elif action == "BORDER":
                    out = ri._selection_border(mode, bm, uv_layer, loops, edge_loops, faces, sync=ri._sync_on(context))
                    if mode == "FACE":
                        # A border is made of edges, which face mode cannot hold or show:
                        # end in edge mode, as mesh.region_to_loop does.
                        apply_mode = "EDGE"
                        snap["uv_select_mode"] = "EDGE"
                        context.tool_settings.uv_select_mode = "EDGE"
                        if ri._sync_on(context):
                            snap["mesh_select_mode"] = (False, True, False)
                            bm.select_mode = {"EDGE"}
                        from . import uv_runtime_cleanup_1899 as _guard
                        _guard.keep_selection_modes(snap)
                elif action == "INVERT":
                    out = ri._selection_invert(mode, bm, loops, edge_loops, faces)
                else:
                    _report(self, "WARNING", f"Unsupported selection action: {action}")
                    return {"CANCELLED"}
            ri._apply_selection(context, obj, bm, uv_layer, apply_mode, out[0], out[1], out[2])
            touched += 1
        if touched <= 0 and action not in {"ALL", "NONE"}:
            _report(self, "WARNING", _tr(context, "No suitable UV edge selection is available.", "対象になるUV辺選択がありません。"))
            return {"CANCELLED"}
        mo._update_meshes(targets)
        if action in {"GROW", "SHRINK", "BORDER", "LINKED"} and not ri._sync_on(context):
            # The flags were written per element: this RNA update derives the edge and face
            # flags they imply for every edited mesh, the same as Blender's own selection.
            context.tool_settings.uv_select_mode = context.tool_settings.uv_select_mode
        try:
            if getattr(context, "area", None) is not None:
                context.area.tag_redraw()
        except Exception:
            pass
        return {"FINISHED"}
    except Exception as exc:
        _report(self, "WARNING", _tr(context, "UV selection operation failed.", "UV選択処理に失敗しました。") + f" {exc}")
        return {"CANCELLED"}
    finally:
        ri._restore_modes(snap)
        mo._restore_multi_edit(context, state)
        ri._restore_modes(snap)


def _patched_instant_invoke(self: Any, context: Any, event: Any):
    try:
        etype = _s(getattr(event, "type", ""))
        evalue = _s(getattr(event, "value", ""))
        if etype != "LEFTMOUSE" or evalue not in {"PRESS", "CLICK_DRAG"}:
            return {"PASS_THROUGH"}
        # Modifiers belong to Blender's native add/toggle/loop/ring selection.
        # Do not consume them in Immediate Select.
        if bool(getattr(event, "alt", False) or getattr(event, "oskey", False) or getattr(event, "hyper", False)):
            return {"PASS_THROUGH"}
        # Ctrl/Shift are only used when Immediate Select itself owns a drag.  On a
        # plain PRESS in the broad UV Editor map, pass through so normal native
        # extend/toggle selection remains exact.
        if evalue == "PRESS" and bool(getattr(event, "shift", False) or getattr(event, "ctrl", False)):
            return {"PASS_THROUGH"}
        if not ri._instant_enabled(context):
            return {"PASS_THROUGH"}
        try:
            space = getattr(context, "space_data", None)
            if getattr(space, "type", "") != "IMAGE_EDITOR":
                return {"PASS_THROUGH"}
        except Exception:
            return {"PASS_THROUGH"}
        if ri._native_tool_should_pass(context):
            return {"PASS_THROUGH"}
        hit = mo._direct_find_uv_hit_multi(self, context, event) if hasattr(mo, "_direct_find_uv_hit_multi") else ri._direct_find_uv_hit(self, context, event)
        if not hit:
            return {"PASS_THROUGH"}
        selected_hit = mo._hit_is_selected_multi(context, hit) if hasattr(mo, "_hit_is_selected_multi") else ri._hit_is_selected(context, hit)
        if selected_hit:
            if evalue == "CLICK_DRAG":
                try:
                    self._drag_start_x = int(getattr(event, "mouse_x", 0) or 0)
                    self._drag_start_y = int(getattr(event, "mouse_y", 0) or 0)
                except Exception:
                    pass
                try:
                    start = getattr(self, "_start_translate", None)
                    if callable(start):
                        return start(context)
                except Exception:
                    pass
                try:
                    bpy.ops.transform.translate('INVOKE_DEFAULT', release_confirm=True)
                except Exception:
                    pass
                return {"FINISHED"}
            return {"PASS_THROUGH"}
        ok = mo._select_hit_immediate_multi(context, hit, event) if hasattr(mo, "_select_hit_immediate_multi") else ri._select_hit_immediate(context, hit, event)
        if not ok:
            return {"PASS_THROUGH"}
        try:
            self._drag_start_x = int(getattr(event, "mouse_x", 0) or 0)
            self._drag_start_y = int(getattr(event, "mouse_y", 0) or 0)
        except Exception:
            pass
        if evalue == "CLICK_DRAG":
            try:
                start = getattr(self, "_start_translate", None)
                if callable(start):
                    return start(context)
            except Exception:
                pass
            return {"FINISHED"}
        try:
            context.window_manager.modal_handler_add(self)
            return {"RUNNING_MODAL"}
        except Exception:
            return {"FINISHED"}
    except Exception:
        return {"PASS_THROUGH"}


def _iter_keyconfigs() -> Iterable[Any]:
    try:
        wm = getattr(bpy.context, "window_manager", None)
        kc = getattr(getattr(wm, "keyconfigs", None), "addon", None)
        return (kc,) if kc is not None else ()
    except Exception:
        return ()


def _remove_keymap_rows(idnames: Iterable[str], names: Optional[Iterable[str]] = None) -> int:
    removed = 0
    try:
        from . import ownership_runtime_18168 as _ownership
        for idname in tuple(idnames or ()):
            removed += _ownership.remove_owned_keymaps(str(idname))
    except Exception:
        pass
    return removed


def _addon_keyconfig() -> Any:
    try:
        return bpy.context.window_manager.keyconfigs.addon
    except Exception:
        return None


def _ensure_keymap(kc: Any, name: str, space_type: str) -> Any:
    try:
        km = kc.keymaps.get(name)
        if km is None:
            km = kc.keymaps.new(name=name, space_type=space_type, region_type="WINDOW")
        return km
    except Exception:
        return None


def _instant_enabled(context: Any = None) -> bool:
    try:
        return bool(ri._instant_enabled(context or bpy.context))
    except Exception:
        try:
            return bool(getattr(ri._workspace(context or bpy.context), "operation_instant_select_enabled", False))
        except Exception:
            return False


def _ensure_instant_keymaps_18106(context: Any = None) -> None:
    try:
        from . import ownership_runtime_18168 as _ownership
    except Exception:
        return
    # Retire only exact rows created by this generation; foreign/user rows remain.
    _ownership.remove_owned_keymaps(_STICKY_PASS_ID)
    _ownership.remove_owned_keymaps(_GIZMO_GRIP_ID)
    kc = _addon_keyconfig()
    if kc is None:
        return
    active = _instant_enabled(context or bpy.context)
    for name, space, value in _INSTANT_KEYMAP_POLICY:
        km = _ensure_keymap(kc, name, space)
        if km is None:
            continue
        rows = [kmi for keymap, kmi in _ownership.owned_keymap_items(_INSTANT_ID) if keymap is km]
        if not rows:
            try:
                kmi = _ownership.new_keymap_item(km, _INSTANT_ID, type="LEFTMOUSE", value=value, head=True)
            except TypeError:
                try:
                    kmi = _ownership.new_keymap_item(km, _INSTANT_ID, type="LEFTMOUSE", value=value)
                except Exception:
                    kmi = None
            except Exception:
                kmi = None
            rows = [kmi] if kmi is not None else []
        for row in rows[1:]:
            _ownership.remove_keymap_item(km, row)
        if rows:
            kmi = rows[0]
            for prop, prop_value in (("type", "LEFTMOUSE"), ("value", value), ("shift", False), ("ctrl", False), ("alt", False), ("oskey", False), ("hyper", False), ("any", False)):
                try:
                    _suv_resource.keymap_item_set(kmi, prop, prop_value)
                except Exception:
                    pass
            _ownership.set_keymap_item_active(kmi, bool(active))


def _patch_selection(ns: Dict[str, Any]) -> None:
    try:
        ri._selection_loop_ring = _selection_loop_ring_18106  # type: ignore[attr-defined]
    except Exception:
        pass
    try:
        cls = ns.get("SMARTUVSUITE_OT_uv_element_select_action") if isinstance(ns, dict) else None
        if isinstance(cls, type):
            cur = getattr(cls, "execute", None)
            if callable(cur) and cur is not _execute_select_multi_18106 and "select_execute" not in _PREV:
                _PREV["select_execute"] = cur
            _execute_select_multi_18106._sus_18106_select = True  # type: ignore[attr-defined]
            cls.execute = _execute_select_multi_18106
    except Exception:
        pass


def _instant_keymap_counts_18106(context: Any):
    """Callers of the replaced keymap helpers unpack (created, touched)."""
    result = _ensure_instant_keymaps_18106(context)
    if isinstance(result, (tuple, list)) and len(result) >= 2:
        return result[0], result[1]
    count = int(result or 0) if isinstance(result, (int, bool)) else 0
    return count, count


def _patch_instant(ns: Dict[str, Any]) -> None:
    try:
        cls = ns.get("SMARTUVSUITE_OT_instant_select_drag_move") if isinstance(ns, dict) else None
        if isinstance(cls, type):
            cur = getattr(cls, "invoke", None)
            if callable(cur) and cur is not _patched_instant_invoke and "instant_invoke" not in _PREV:
                _PREV["instant_invoke"] = cur
            _patched_instant_invoke._sus_18106_instant = True  # type: ignore[attr-defined]
            cls.invoke = _patched_instant_invoke
            try:
                cls._find_uv_hit = mo._direct_find_uv_hit_multi
            except Exception:
                pass
    except Exception:
        pass
    try:
        ri._ensure_instant_keymaps = _ensure_instant_keymaps_18106  # type: ignore[attr-defined]
        ri._ALLOWED_INSTANT_MAPS = tuple((name, space) for name, space, _value in _INSTANT_KEYMAP_POLICY)  # type: ignore[attr-defined]
        ri._FORBIDDEN_MAPS = _REMOVE_INSTANT_MAPS  # type: ignore[attr-defined]
    except Exception:
        pass
    for key in ("_sus_1652_ensure_instant_keymaps", "_sus_1652_promote_instant_keymaps_to_head"):
        try:
            ns[key] = lambda context=None, *, active=True: _instant_keymap_counts_18106(context or bpy.context)
        except Exception:
            pass
    try:
        ns["_sus_1652_set_instant_keymaps_active"] = lambda active: _instant_keymap_counts_18106(bpy.context)
    except Exception:
        pass
    try:
        ns["_sus_1652_delete_instant_keymaps"] = lambda: _remove_keymap_rows({_INSTANT_ID})
    except Exception:
        pass


def _patch_sync(ns: Dict[str, Any]) -> None:
    cur = ns.get("_sus_1652_sync_keymaps_from_workspace")
    if callable(cur) and not getattr(cur, "_sus_18106_sync", False):
        _PREV["sync"] = cur
    base = _PREV.get("sync")
    def _sync_18106(context=None):
        ctx = context or getattr(bpy, "context", None)
        if callable(base) and base is not _sync_18106:
            try:
                base(ctx)
            except TypeError:
                try:
                    base()
                except Exception:
                    pass
            except Exception:
                pass
        try:
            apply_all(ns, ctx)
        except Exception:
            pass
    try:
        _sync_18106._sus_18106_sync = True  # type: ignore[attr-defined]
    except Exception:
        pass
    try:
        ns["_sus_1652_sync_keymaps_from_workspace"] = _sync_18106
    except Exception:
        pass


def _mark_version(ns: Dict[str, Any]) -> None:
    try:
        info = ns.get("bl_info")
        if not isinstance(info, dict):
            info = {}; ns["bl_info"] = info
        info.update({
            "name": "Smart UV Suite",
            "author": "JELararagi",
            "version": (1, 0, 0),
            "blender": (5, 1, 0),
            "location": "View3D / UV Editor > Sidebar > Smart UV",
            "description": "Smart UV Suite exposes UV editing tools in the Smart UV sidebar.",
            "category": "Smart UV",
        })
        ns["_SUS_BL_INFO_FALLBACK"] = dict(info)
        ns["__version__"] = '1.0.0'
    except Exception:
        pass


def apply_all(ns: Optional[Dict[str, Any]] = None, context: Any = None) -> None:
    global _NS
    if isinstance(ns, dict):
        _NS = ns
    elif not _NS:
        import sys
        mod = sys.modules.get(__package__)
        if mod is not None:
            _NS = getattr(mod, "__dict__", {})
    target = _NS if isinstance(_NS, dict) else {}
    if not target:
        return
    _patch_selection(target)
    _patch_instant(target)
    _ensure_instant_keymaps_18106(context or getattr(bpy, "context", None))
    _patch_sync(target)
    _mark_version(target)


def install(ns: Optional[Dict[str, Any]] = None, context: Any = None) -> None:
    apply_all(ns, context or getattr(bpy, "context", None))


def unregister() -> None:
    # Do not restore old paths; leaving the corrected final path active until the
    # add-on module unloads prevents stale keymaps from reviving during reload.
    try:
        _remove_keymap_rows({_STICKY_PASS_ID, _GIZMO_GRIP_ID})
    except Exception:
        pass


def audit(context: Any = None) -> Dict[str, Any]:
    del context
    rows = []
    try:
        from . import ownership_runtime_18168 as _ownership
        for km, kmi in _ownership.owned_keymap_items(_INSTANT_ID):
            rows.append(('addon-owned-exact', str(getattr(km, 'name', '')), str(getattr(kmi, 'type', '')), str(getattr(kmi, 'value', '')), bool(getattr(kmi, 'active', False))))
    except Exception:
        pass
    return {'version': _VERSION, 'instant_keymaps': rows, 'strict_loop_ring': True, 'foreign_keymaps_scanned': False}

