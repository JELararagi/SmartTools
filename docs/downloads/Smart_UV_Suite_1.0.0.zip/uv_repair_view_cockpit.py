from . import smart_uv_cockpit


def _apply(context, op):
    profile = (op.profile or 'PRODUCTION').strip().upper()
    return profile in smart_uv_cockpit._PROFILE_DATA and smart_uv_cockpit.apply_profile(profile, context)


def build_handlers(api):
    return {
        'smart_uv_suite.view_cockpit_apply_profile': api.Handler(_apply, 'Apply the selected cockpit quality profile to the workspace.', '選択した品質プロファイルを作業環境に適用します。'),
    }
