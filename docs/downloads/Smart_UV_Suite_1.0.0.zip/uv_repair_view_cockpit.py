# SPDX-License-Identifier: GPL-3.0-or-later
"""Select a named workspace profile for the UV cockpit."""
from . import smart_uv_cockpit


def build_handlers(api):
    def select_profile(context, operation):
        selected = (operation.profile or "PRODUCTION").strip().upper()
        if selected not in smart_uv_cockpit._PROFILE_DATA:
            return False
        return smart_uv_cockpit.apply_profile(selected, context)

    return {"smart_uv_suite.view_cockpit_apply_profile": api.Handler(
        select_profile,
        "Load the requested quality profile into the UV workspace.",
        "指定した品質プロファイルを UV の作業環境に読み込みます。",
    )}
