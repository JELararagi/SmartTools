# SPDX-License-Identifier: GPL-3.0-or-later
# UV Suite (SUV) - legacy v6.497.0 engine integrated into Smart UV Suite 1.8.150
# Blender 5.0.0 local extension
# Copyright (C) 2026 JELararagi
#
# FULL integrated build:
# - Phase0 core: selection abstraction (UV Sync ON/OFF best-effort), safe UV ops override,
#   island engine (UV continuity + seam), explicit i18n (EN/JA), robust reporting.
# - Pro Tools: Stack Pro, Pack Pro (Native/Deterministic + group-aware layout + UDIM),
#   Texel Density Pro (Get/Set/Normalize), Inspector (Scan/Select/Fix),
#   Auto Unwrap Pro (seams->unwrap->relax->pack->QA).
# - Selection & Sets: island/boundary/similar selection + save/recall/update/delete sets.
# - Symmetry: detect pairs, mirror UV, symmetry seams, symmetry stack.
# - Atlas/Material Multi: build atlas UV across selected objects with UDIM mode,
#   multi-pass bake with image mode (single/UDIM tiled), build shared material and apply.
#
# Notes:
# - Some bake types may be unavailable depending on build; skipped passes are reported.
# - This add-on is a "single-file suite" for easier distribution.

SUV_LEGACY_ENGINE_VERSION = (6, 497, 0)


bl_info = {
    "name": 'Smart UV',
    "author": "JELararagi",
    "version": (1, 0, 0),
    "blender": (5, 0, 0),
    "location": '3D View > Sidebar > Smart UV',
    "description": "Integrated UV workflow suite with split dashboard hubs, layout deck, bridge board, transfer/polish decks, export readiness, bilingual help, QA, packing, trim, atlas, role routing, diagnostics, and compatibility bridges.",
    "category": "UV",
}

import bpy

from . import tool_runtime as _tool_runtime
from . import text_translation as _text_translation
from . import rename_catalog as _rename_catalog
import bmesh
import math
import json
import copy
import os
import shutil
import time
import traceback
from collections import defaultdict
from mathutils import Vector
from mathutils.kdtree import KDTree

_SUV_WARNED = set()


def _suv_warn_once(key, *parts):
    if key not in _SUV_WARNED:
        _SUV_WARNED.add(key)
        print(' '.join(str(p) for p in parts))



try:
    import bpy.utils.previews as _bpy_previews
except Exception:
    _bpy_previews = None

SUV_ID = "SUV"
_SUV_ICON_COLLECTION = None

# ============================================================
# Cross-module runtime shims
# ============================================================
# The original UV Suite source was a single large module.  The extension build is
# split into staged modules and each later module copies symbols from the
# previous stage.  Keep these small, dependency-light helpers in the first stage
# so Pro/Selection/Symmetry/precision patch modules can call them even before the
# UI stage defines the richer implementations.

def _suv_now_str():
    try:
        return time.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return ""


def _suv_ws(context):
    try:
        scene = getattr(context, 'scene', None) if context is not None else None
        return getattr(scene, 'suv_workspace', None) if scene is not None else None
    except Exception:
        return None


def _suv_text_block(name: str, clear: bool = False):
    try:
        safe_name = str(name or '').strip() or 'SUV_Runtime_Log'
        txt = bpy.data.texts.get(safe_name)
        if txt is None:
            txt = bpy.data.texts.new(safe_name)
        elif clear:
            txt.clear()
        return txt
    except Exception:
        return None


def _suv_tool_runtime_log_name(context):
    ws = _suv_ws(context)
    try:
        name = getattr(ws, 'tool_runtime_log_name', '') if ws else ''
    except Exception:
        name = ''
    return str(name or '').strip() or 'SUV_Runtime_Log'


def _suv_batch_report_name(context):
    ws = _suv_ws(context)
    try:
        name = getattr(ws, 'batch_report_name', '') if ws else ''
    except Exception:
        name = ''
    return str(name or '').strip() or 'SUV_Batch_Report'


def _suv_support_bundle_name(context):
    ws = _suv_ws(context)
    try:
        name = getattr(ws, 'support_bundle_name', '') if ws else ''
    except Exception:
        name = ''
    return str(name or '').strip() or 'SUV_Support_Bundle'


def _suv_validation_report_name(context):
    ws = _suv_ws(context)
    try:
        name = getattr(ws, 'validation_report_name', '') if ws else ''
    except Exception:
        name = ''
    return str(name or '').strip() or 'SUV_Validation_Report'


def _suv_scan_report_name(context):
    ws = _suv_ws(context)
    try:
        name = getattr(ws, 'scan_report_name', '') if ws else ''
    except Exception:
        name = ''
    return str(name or '').strip() or 'SUV_Scan_Report'


def _suv_context_snapshot(context):
    obj = None
    selected_meshes = []
    try:
        obj = _active_mesh_obj(context)
    except Exception:
        obj = getattr(context, 'active_object', None) if context is not None else None
    try:
        selected_meshes = list(_selected_mesh_objects(context))
    except Exception:
        try:
            selected_meshes = [o for o in getattr(context, 'selected_objects', []) or [] if getattr(o, 'type', None) == 'MESH']
        except Exception:
            selected_meshes = []
    uv_name = '-'
    uv_count = 0
    try:
        data = getattr(obj, 'data', None)
        layers = getattr(data, 'uv_layers', None)
        uv_count = len(layers or [])
        active = getattr(layers, 'active', None) if layers is not None else None
        if active is not None:
            uv_name = getattr(active, 'name', '-') or '-'
    except Exception:
        pass
    return {
        'time': _suv_now_str(),
        'area': str(getattr(getattr(context, 'area', None), 'type', '') or 'UNKNOWN'),
        'region': str(getattr(getattr(context, 'region', None), 'type', '') or 'UNKNOWN'),
        'mode': str(getattr(context, 'mode', '') or getattr(obj, 'mode', '') or 'UNKNOWN'),
        'object': str(getattr(obj, 'name', '-') or '-'),
        'active_uv': uv_name,
        'selected_meshes': len(selected_meshes),
        'total_uv_maps': uv_count,
        'image_editor_count': 0,
        'view3d_count': 0,
        'uv_override_possible': False,
        'current_area_type': str(getattr(getattr(context, 'area', None), 'type', '') or 'UNKNOWN'),
        'mode_switch_possible': bool(obj is not None),
        'active_mesh_selectable': bool(obj is not None),
        'active_mesh_name': str(getattr(obj, 'name', '-') or '-'),
    }


def _suv_log_event(context, level: str, source: str, message: str, details=None):
    try:
        snap = _suv_context_snapshot(context)
        txt = _suv_text_block(_suv_tool_runtime_log_name(context), clear=False)
        if txt is not None:
            try:
                if txt.as_string().strip():
                    txt.write("\n\n")
            except Exception:
                pass
            lines = [
                f"[{snap.get('time', '')}] {level} | {source}",
                f"Message: {message}",
                f"Area: {snap.get('area', 'UNKNOWN')} / Region: {snap.get('region', 'UNKNOWN')}",
                f"Mode: {snap.get('mode', 'UNKNOWN')}",
                f"Active Object: {snap.get('object', '-')}",
                f"Active UV: {snap.get('active_uv', '-')}",
                f"Selected Meshes: {snap.get('selected_meshes', 0)}",
            ]
            if details:
                lines.append('Details:')
                if isinstance(details, dict):
                    for key, value in details.items():
                        lines.append(f"- {key}: {value}")
                elif isinstance(details, (list, tuple, set)):
                    for item in details:
                        lines.append(f"- {item}")
                else:
                    lines.append(f"- {details}")
            txt.write("\n".join(lines))
        ws = _suv_ws(context)
        if ws is not None:
            try:
                ws.health_last_operator = str(source)[:256]
                if str(level).upper() in {'WARN', 'ERROR'}:
                    ws.health_last_error = str(message)[:1024]
            except Exception:
                pass
    except Exception:
        pass


def _suv_log_exception(context, source: str, exc: Exception, details=None):
    payload = {}
    if isinstance(details, dict):
        payload.update(details)
    elif details is not None:
        payload['details'] = details
    try:
        payload['exception_type'] = type(exc).__name__
        payload['traceback'] = traceback.format_exc()
    except Exception:
        pass
    _suv_log_event(context, 'ERROR', source, f"{type(exc).__name__}: {exc}", payload)


def _suv_batch_error_policy(context):
    ws = _suv_ws(context)
    try:
        value = str(getattr(ws, 'batch_error_policy', 'CONTINUE') or 'CONTINUE').upper()
    except Exception:
        value = 'CONTINUE'
    return value if value in {'CONTINUE', 'STOP_ON_ERROR'} else 'CONTINUE'


def _suv_batch_snapshot_policy(context):
    ws = _suv_ws(context)
    try:
        value = str(getattr(ws, 'batch_snapshot_policy', 'ERROR') or 'ERROR').upper()
    except Exception:
        value = 'ERROR'
    return value if value in {'ERROR', 'WARN_ERROR', 'OFF'} else 'ERROR'


def _suv_batch_safe_name(value: str, fallback='step'):
    text = str(value or '').strip() or str(fallback or 'step')
    safe = ''.join(ch if ch.isalnum() or ch in {'_', '-'} else '_' for ch in text)
    return safe[:80] or str(fallback or 'step')


def _suv_batch_capture_snapshot(context, report, step: str, status: str):
    # Lightweight build: do not create additional snapshot datablocks from early
    # modules.  The UI stage replaces this with the full snapshot writer.
    del context, report, step, status
    return ''


def _suv_batch_should_stop(context, report):
    try:
        if report and bool(report.get('stop_requested', False)):
            return True
        if _suv_batch_error_policy(context) == 'STOP_ON_ERROR' and report and int(report.get('error', 0) or 0) > 0:
            return True
    except Exception:
        pass
    return False


def _suv_batch_begin(context, source: str, title: str = None, details=None):
    name = _suv_batch_report_name(context)
    txt = _suv_text_block(name, clear=True)
    report = {
        'source': str(source or 'Batch'),
        'name': name,
        'txt': txt,
        'steps': 0,
        'ok': 0,
        'warn': 0,
        'error': 0,
        'stop_requested': False,
    }
    if txt is not None:
        try:
            txt.write(f"UV Suite Batch Report\n")
            txt.write(f"Source: {report['source']}\n")
            if title:
                txt.write(f"Title: {title}\n")
            txt.write(f"Time: {_suv_now_str()}\n")
            if details:
                txt.write(f"Details: {details}\n")
            txt.write("\n")
        except Exception:
            pass
    _suv_log_event(context, 'INFO', report['source'], 'Batch started', details or None)
    return report


def _suv_batch_note(context, report, status: str, step: str, message: str, details=None):
    if report is None:
        return None
    status = str(status or 'INFO').upper()
    if status in {'OK', 'INFO'}:
        key = 'ok' if status == 'OK' else None
    elif status in {'WARN', 'WARNING'}:
        key = 'warn'
        status = 'WARN'
    elif status in {'ERROR', 'CANCELLED'}:
        key = 'error'
        status = 'ERROR'
    else:
        key = None
    try:
        if key:
            report[key] = int(report.get(key, 0) or 0) + 1
        txt = report.get('txt')
        if txt is not None:
            txt.write(f"[{status}] {step}: {message}\n")
            if details:
                txt.write(f"  {details}\n")
    except Exception:
        pass
    try:
        _suv_log_event(context, 'WARN' if status == 'WARN' else ('ERROR' if status == 'ERROR' else 'INFO'), report.get('source', 'Batch'), f"{step}: {message}", details)
    except Exception:
        pass
    if status == 'ERROR' and _suv_batch_error_policy(context) == 'STOP_ON_ERROR':
        try:
            report['stop_requested'] = True
        except Exception:
            pass
    return None


def _suv_batch_step(context, report, step: str, callback, *, fatal=False, details=None):
    if report is None:
        return False, {'CANCELLED'}
    try:
        report['steps'] = int(report.get('steps', 0) or 0) + 1
    except Exception:
        pass
    try:
        result = callback()
    except Exception as exc:
        _suv_log_exception(context, f"{report.get('source', 'Batch')} | {step}", exc, details)
        _suv_batch_note(context, report, 'ERROR', step, f"{type(exc).__name__}: {exc}", details)
        if fatal or _suv_batch_error_policy(context) == 'STOP_ON_ERROR':
            try:
                report['stop_requested'] = True
            except Exception:
                pass
        return False, {'CANCELLED'}
    status = _suv_result_status_set(result) if '_suv_result_status_set' in globals() else (set(result) if isinstance(result, set) else set())
    if 'CANCELLED' in status:
        _suv_batch_note(context, report, 'ERROR' if fatal else 'WARN', step, 'Step cancelled', details)
        if fatal or _suv_batch_error_policy(context) == 'STOP_ON_ERROR':
            try:
                report['stop_requested'] = True
            except Exception:
                pass
        return False, result
    _suv_batch_note(context, report, 'OK', step, 'Finished', details)
    return True, result


def _suv_batch_finish(context, report, *, operator=None):
    if report is None:
        return {'CANCELLED'}
    summary = f"steps={int(report.get('steps', 0) or 0)} ok={int(report.get('ok', 0) or 0)} warn={int(report.get('warn', 0) or 0)} error={int(report.get('error', 0) or 0)}"
    try:
        txt = report.get('txt')
        if txt is not None:
            txt.write(f"\nSummary: {summary}\n")
    except Exception:
        pass
    ws = _suv_ws(context)
    if ws is not None:
        try:
            ws.batch_last_summary = summary[:1024]
        except Exception:
            pass
    level = 'ERROR' if int(report.get('error', 0) or 0) > 0 else ('WARN' if int(report.get('warn', 0) or 0) > 0 else 'INFO')
    _suv_log_event(context, level, report.get('source', 'Batch'), 'Batch summary', {'summary': summary, 'batch_report': report.get('name', '')})
    if operator is not None:
        try:
            if int(report.get('error', 0) or 0) > 0:
                operator.report({'WARNING'}, f"Partial completion ({summary})")
            elif int(report.get('warn', 0) or 0) > 0:
                operator.report({'INFO'}, f"Completed with warnings ({summary})")
            else:
                operator.report({'INFO'}, f"Completed ({summary})")
        except Exception:
            pass
    if int(report.get('error', 0) or 0) > 0 and int(report.get('ok', 0) or 0) == 0:
        return {'CANCELLED'}
    return {'FINISHED'}


def _suv_store_scan_cache(context, scope, eps_zero, check_out, check_overlap, precise_overlap, flipped, zero, out, overlap, stretch_count=0, stretch_worst=1.0, stretch_avg=1.0):
    ws = _suv_ws(context)
    if ws is not None:
        try:
            ws.scan_has_result = True
            ws.scan_time = _suv_now_str()
            ws.scan_scope = str(scope)
            ws.scan_eps_zero = float(eps_zero)
            ws.scan_check_out = bool(check_out)
            ws.scan_check_overlap = bool(check_overlap)
            ws.scan_precise_overlap = bool(precise_overlap)
            obj = _active_mesh_obj(context)
            active_uv = getattr(getattr(getattr(obj, 'data', None), 'uv_layers', None), 'active', None) if obj is not None else None
            ws.scan_uv_name = getattr(active_uv, 'name', '') or ''
            ws.scan_mesh_count = len(_selected_mesh_objects(context))
            ws.scan_flipped = int(flipped)
            ws.scan_zero = int(zero)
            ws.scan_out = int(out)
            ws.scan_overlap = int(overlap)
            ws.scan_stretch = int(stretch_count)
            ws.scan_stretch_worst = max(1.0, float(stretch_worst or 1.0))
            ws.scan_stretch_avg = max(1.0, float(stretch_avg or 1.0))
            return
        except Exception:
            pass
    # No persistent fallback: this result is reconstructible UI/runtime state.
    # Older builds wrote ``scene['suv_scan_cache']`` here, permanently
    # contaminating saved .blend files even though no product code reads it.
    return


def _uv_loop_corner_selected(context, obj, loop):
    try:
        if _is_uv_sync(context):
            return bool(getattr(getattr(loop, 'vert', None), 'select', False))
    except Exception:
        pass
    try:
        uv = getattr(getattr(obj, 'data', None), 'uv_layers', None)
        active = getattr(uv, 'active', None) if uv is not None else None
        if active is None:
            return False
        return bool(getattr(active.data[loop.index], 'select', False))
    except Exception:
        return False


def _uv_loop_edge_selected(context, obj, loop):
    try:
        if _is_uv_sync(context):
            return bool(getattr(getattr(loop, 'edge', None), 'select', False) and getattr(getattr(loop, 'vert', None), 'select', False) and getattr(getattr(getattr(loop, 'link_loop_next', None), 'vert', None), 'select', False))
    except Exception:
        pass
    try:
        uv = getattr(getattr(obj, 'data', None), 'uv_layers', None)
        active = getattr(uv, 'active', None) if uv is not None else None
        if active is None:
            return False
        d0 = active.data[loop.index]
        d1 = active.data[loop.link_loop_next.index]
        return bool(getattr(d0, 'select_edge', False)) or (bool(getattr(d0, 'select', False)) and bool(getattr(d1, 'select', False)))
    except Exception:
        return False


# ============================================================
# Result status helpers
# ============================================================

def _suv_result_status_set(result):
    if isinstance(result, set):
        return set(result)
    if isinstance(result, dict):
        status = result.get('status', None)
        if isinstance(status, set):
            return set(status)
        if isinstance(status, (list, tuple)):
            return {str(v) for v in status if v is not None}
        if isinstance(status, str):
            return {status}
    if isinstance(result, (list, tuple)):
        return {str(v) for v in result if v is not None}
    if isinstance(result, str):
        return {result}
    try:
        return set(result)
    except Exception:
        return set()


def _suv_result_has(result, token: str) -> bool:
    try:
        return token in _suv_result_status_set(result)
    except Exception:
        return False


# ============================================================
# Property tooltip fallback bridge
# ============================================================

_SUV_PROP_TOOLTIP_LABEL_OVERRIDES = {
    'scope': 'Scope',
    'mode': 'Mode',
    'axis': 'Axis',
    'factor': 'Factor',
    'iterations': 'Iterations',
    'texture_size': 'Texture Size',
    'margin_px': 'Margin (px)',
    'padding_px': 'Padding (px)',
    'target_density': 'Target Density',
    'pack_margin_px': 'Pack Margin (px)',
    'rotation_step': 'Rotation Step',
    'offset_u': 'Offset U',
    'offset_v': 'Offset V',
    'offset_uv': 'Offset UV',
    'keep_tile': 'Keep Tile',
    'keep_aspect': 'Keep Aspect',
    'preserve_tile': 'Preserve Tile',
    'preserve_boundary': 'Preserve Boundary',
    'preserve_pins': 'Preserve Pins',
    'selected_only': 'Selected Only',
    'write_report': 'Write Report',
    'write_json': 'Write JSON',
    'validate_before_run': 'Validate Before Run',
    'restore_workspace_on_error': 'Restore Workspace on Error',
    'restore_selection_on_error': 'Restore Selection on Error',
    'restore_selection_on_finish': 'Restore Selection on Finish',
    'stop_on_error': 'Stop on Error',
    'profile': 'Profile',
    'preset': 'Preset',
    'library': 'Library',
    'target': 'Target',
    'execution_mode': 'Execution Mode',
}

_SUV_PROP_TOOLTIP_DETAIL_OVERRIDES = {
    'scope': (
        'Choose which islands or objects this tool should affect. Use Selected when you want a focused edit, or switch to All when the whole active UV map should be processed.',
        'このツールをどのアイランドやオブジェクトへ適用するかを選びます。部分的に調整したい時は Selected、アクティブUV全体を処理したい時は All を使います。',
    ),
    'mode': (
        'Choose the working mode for this tool. The mode decides the main strategy, projection style, or editing behavior used when the operator runs.',
        'このツールの動作モードを選びます。モードによって、実行時に使う主な処理方法、投影方式、編集挙動が変わります。',
    ),
    'axis': (
        'Choose which UV axis the tool uses. U is the horizontal direction and V is the vertical direction, so this setting controls the orientation of flips, sorting, alignment, and stepping operations.',
        'このツールで使うUV軸を選びます。U は横方向、V は縦方向なので、反転、整列、並べ替え、移動量の向きを決める設定です。',
    ),
    'step': (
        'Set the angle step used when snapping or testing rotations. Smaller values try more orientations and can produce a tighter result, while larger values are faster and coarser.',
        '回転をスナップしたり候補を試したりする時の角度刻みを設定します。小さい値ほど細かく試せて結果が詰まりやすくなり、大きい値ほど高速ですが粗めになります。',
    ),
    'seed': (
        'Set the random seed used by this tool. Change it when you want a different random arrangement while keeping the same overall rules.',
        'このツールが使う乱数シードを設定します。同じルールのまま別のランダム結果にしたい時に値を変えます。',
    ),
    'offset': (
        'Set how far islands may move in UV space. Larger values allow a wider spread, while smaller values keep the result closer to the original layout.',
        'UV空間でアイランドをどれだけ動かせるかを設定します。値を大きくすると散らばりが広くなり、小さくすると元の配置に近い結果を保ちます。',
    ),
    'offset_uv': (
        'Set how far islands may move in UV space. Larger values allow a wider spread, while smaller values keep the result closer to the original layout.',
        'UV空間でアイランドをどれだけ動かせるかを設定します。値を大きくすると散らばりが広くなり、小さくすると元の配置に近い結果を保ちます。',
    ),
    'rotation_step': (
        'Choose the rotation increment used when rotating, stacking, or packing islands. Finer steps allow more exact fitting, while larger steps keep the result more predictable and faster to search.',
        'アイランドを回転、スタック、パックする時の回転刻みを選びます。細かい刻みほどぴったり合わせやすくなり、大きい刻みほど結果が予測しやすく探索も軽くなります。',
    ),
    'gap': (
        'Set the spacing between islands in UV units. Increase it to separate islands more clearly, or lower it when you want a denser layout.',
        'UV単位でのアイランド間隔を設定します。値を上げると見やすく離れ、下げるとより詰まった配置になります。',
    ),
    'gap_px': (
        'Set the spacing between islands in texture pixels. This is useful when you want a layout that matches a specific bake or texture resolution.',
        'テクスチャのピクセル単位でアイランド間隔を設定します。ベイクや特定解像度に合わせた余白を決めたい時に便利です。',
    ),
    'keep_tile': (
        'Keep islands inside their current UDIM or tile while the tool runs. Enable this when you want to preserve tile assignments instead of allowing islands to move between tiles.',
        'ツール実行中も、現在のUDIMやタイル内にアイランドを保ちます。タイル割り当てを維持したい時に有効にし、別タイルへの移動を防ぎます。',
    ),
    'keep_aspect': (
        'Preserve the current aspect ratio of islands while fitting or filling. Enable this when you want to avoid stretching the UV shape.',
        'フィットや塗りつぶしの時に、現在の縦横比を維持します。UV形状を引き伸ばしたくない時に有効にします。',
    ),
    'texture_size': (
        'Set the reference texture size used when converting pixel-based margins, density, or spacing into UV units. Match it to the texture or bake size you plan to use.',
        'ピクセル基準の余白、密度、間隔をUV単位へ変換する時の基準テクスチャサイズを設定します。使う予定のテクスチャ解像度やベイク解像度に合わせてください。',
    ),
    'margin': (
        'Set the safety margin around islands. A larger margin reduces bleed risk, while a smaller margin packs more tightly.',
        'アイランドの周囲に取る安全余白を設定します。大きいほどにじみを防ぎやすく、小さいほど高密度に詰められます。',
    ),
    'margin_px': (
        'Set the safety margin around islands in pixels. Use this when you need padding that directly matches texture resolution and bake requirements.',
        'アイランド周囲の安全余白をピクセル単位で設定します。テクスチャ解像度やベイク要件に合わせた余白を直接決めたい時に使います。',
    ),
    'padding': (
        'Set the extra padding added before fitting, cropping, or layout operations. Increase it to leave more breathing room around the result.',
        'フィット、クロップ、レイアウト処理の前後で確保する追加余白を設定します。値を上げると結果の周囲に余裕を持たせられます。',
    ),
    'padding_px': (
        'Set the extra padding in pixels used before fitting, cropping, or layout operations. This is useful when your padding must match a specific texture resolution.',
        'フィット、クロップ、レイアウト処理で使う追加余白をピクセル単位で設定します。特定のテクスチャ解像度に合わせて余白を決めたい時に便利です。',
    ),
    'target_density': (
        'Set the texel density the tool should aim for. Raise it for sharper texture detail per model area, or lower it to save texture space.',
        'このツールが目標にするテクセル密度を設定します。値を上げると面積あたりのディテールが増え、下げるとテクスチャ領域を節約できます。',
    ),
    'angle_threshold': (
        'Set the angle used to decide where a seam or split should happen. Lower values create more cuts, while higher values keep larger continuous islands.',
        'シームや分割を入れる境界として使う角度を設定します。低い値ほど切れ目が増え、高い値ほど大きい連続アイランドを保ちます。',
    ),
    'angle_limit': (
        'Set the projection or unwrap angle limit used by the native Blender tool. Lower values separate steeper changes more aggressively, while higher values keep larger regions together.',
        'Blender標準の投影・展開で使う角度制限を設定します。低い値ほど急な変化を強く分離し、高い値ほど広い領域をまとめて保ちます。',
    ),
    'island_margin': (
        'Set the UV margin placed between islands by the native unwrap or projection stage. Increase it to reduce texture bleed after packing or baking.',
        '標準展開・投影の段階でアイランド間に入れるUV余白を設定します。値を上げると、後工程のパックやベイクでにじみを減らしやすくなります。',
    ),
    'follow_mode': (
        'Choose how edge lengths are preserved when following quad flow. Use Even for regular spacing, or pick a length-based mode when you want the UV to reflect edge proportions more strongly.',
        '四角形フローに沿って展開する時に、辺長をどう扱うかを選びます。均一な間隔にしたい時は Even、辺の比率をより反映したい時は長さ基準のモードを使います。',
    ),
    'relax_after': (
        'Run an additional relax pass after the main projection step. Enable this when you want to smooth distortion before continuing.',
        '主な投影処理のあとに追加のリラックス処理を行います。次工程へ進む前に歪みをならしたい時に有効にします。',
    ),
    'pack_after': (
        'Run packing automatically after the main operation completes. Enable it when you want the result arranged immediately instead of leaving islands in place.',
        '主処理が終わったあとに自動でパックを実行します。結果をその場で整理したい時に有効にし、配置を手動で残したい時は無効にします。',
    ),
    'apply_density': (
        'Normalize texel density after the main operation. Enable this when you want the result to match a specific texture resolution target.',
        '主処理のあとにテクセル密度を正規化します。特定の解像度目標へ結果を揃えたい時に有効にします。',
    ),
    'pack_margin_px': (
        'Set the packing margin in pixels used by the follow-up packing step. Increase it when you need more bleed protection around packed islands.',
        '後続のパック処理で使う余白をピクセル単位で設定します。パック後のにじみ防止を強めたい時に値を上げます。',
    ),
    'sort': (
        'Choose how islands are ordered before layout or explode operations. Sorting changes which islands are placed first and how the final arrangement reads visually.',
        'レイアウトや分離の前に、どの基準でアイランドを並べるかを選びます。並び順によって、先に置かれるアイランドや見た目の読みやすさが変わります。',
    ),
    'sort_mode': (
        'Choose how islands are ordered before layout or explode operations. Sorting changes which islands are placed first and how the final arrangement reads visually.',
        'レイアウトや分離の前に、どの基準でアイランドを並べるかを選びます。並び順によって、先に置かれるアイランドや見た目の読みやすさが変わります。',
    ),
    'selected_only': (
        'Limit the operation to the current selection. Disable it when you want the tool to inspect or clear data across the whole active UV map.',
        '現在の選択部分だけを対象にします。アクティブUV全体を調べたり消去したりしたい時は無効にします。',
    ),
    'profile': (
        'Choose a saved profile containing a reusable set of rules. Profiles let you switch between workflows without re-entering every setting manually.',
        '再利用できる設定セットをまとめたプロファイルを選びます。毎回細かい値を入れ直さずに、ワークフローを素早く切り替えられます。',
    ),
    'preset': (
        'Choose a preset prepared for a specific task or layout style. Presets are a quick starting point that you can still refine afterward.',
        '特定の作業やレイアウト向けに用意されたプリセットを選びます。プリセットは素早い出発点で、その後に微調整もできます。',
    ),
    'library': (
        'Choose which saved library entry or library source to use. Libraries store reusable presets, hotspot layouts, and workflow building blocks.',
        '使う保存ライブラリやライブラリ項目を選びます。ライブラリには、再利用できるプリセット、ホットスポット配置、ワークフロー部品などが入ります。',
    ),
    'target': (
        'Choose the compatibility target or destination this tool should follow. This is used when translating UV Suite actions into a specific external workflow style.',
        'このツールが合わせる互換ターゲットや出力先を選びます。UV Suite の操作を特定の外部ワークフロー向けに変換する時に使います。',
    ),
    'execution_mode': (
        'Choose whether the compatibility target is applied as guidance, preparation, or a fuller translated action set. Use safer modes first when testing a new workflow.',
        '互換ターゲットをガイドとして使うか、準備処理として使うか、より完全な変換動作として使うかを選びます。新しいワークフローを試す時は、まず安全なモードから使ってください。',
    ),
    'validate_before_run': (
        'Run a validation check before the main action starts. Enable this when you want the tool to stop early if the current scene state is not ready.',
        '主処理の前に検証を行います。現在のシーン状態が整っていない時に、先に止めて確認したい場合に有効です。',
    ),
    'write_report': (
        'Write a report after the operation finishes so you can review what changed, what failed, or what still needs attention.',
        '処理終了後にレポートを書き出し、何が変わったか、何が失敗したか、何をまだ確認すべきかを見直せるようにします。',
    ),
    'write_json': (
        'Write the result as JSON so it can be re-read by tools, debugging scripts, or pipeline checks.',
        '結果を JSON として書き出し、ツール、デバッグスクリプト、パイプライン検証から再利用できるようにします。',
    ),
    'restore_workspace_on_error': (
        'Restore the previous workspace state if the action fails. Enable this when you want safer recovery instead of leaving the tool half-applied.',
        '処理が失敗した時に、作業領域の状態を元へ戻します。途中まで適用されたままにしたくない時に有効です。',
    ),
    'restore_selection_on_error': (
        'Restore the previous selection if the action fails. This is useful when you need to retry the tool without rebuilding the selection manually.',
        '処理が失敗した時に、前の選択状態を復元します。手動で選択を作り直さずに再試行したい時に便利です。',
    ),
    'restore_selection_on_finish': (
        'Restore the original selection after the tool finishes. Use this when the operation needs to change selection internally but you want to keep your working context.',
        '処理終了後に元の選択状態を復元します。内部的に選択変更が必要でも、作業中の文脈を保ちたい時に使います。',
    ),
    'stop_on_error': (
        'Stop the workflow immediately when an error occurs. Enable this when later steps should never continue on a broken intermediate result.',
        'エラーが出た時点でワークフローをすぐ停止します。途中結果が壊れた状態で後続処理へ進めたくない時に有効です。',
    ),
}


def _suv_property_label_key(label) -> str:
    import re as _re
    text = str(label or '').strip().lower()
    text = _re.sub(r'[^a-z0-9]+', '_', text)
    text = _re.sub(r'_+', '_', text).strip('_')
    return text


def _suv_humanize_property_label(label) -> str:
    text = str(label or '').strip()
    if not text:
        return 'setting'
    if text in _SUV_PROP_TOOLTIP_LABEL_OVERRIDES:
        return _SUV_PROP_TOOLTIP_LABEL_OVERRIDES[text]
    normalized = text.replace('_', ' ').replace('-', ' ').strip()
    if not normalized:
        return 'setting'
    return ' '.join(part.capitalize() if part.islower() else part for part in normalized.split())


def _suv_property_tooltip_text(kind: str, label, items=None) -> str:
    pretty = _suv_humanize_property_label(label)
    key = _suv_property_label_key(label)
    kind = str(kind or 'Property')
    detail_pair = _SUV_PROP_TOOLTIP_DETAIL_OVERRIDES.get(key)
    if detail_pair:
        english, japanese = detail_pair
        if kind == 'EnumProperty' and isinstance(items, (list, tuple)):
            options = []
            for entry in items[:4]:
                if isinstance(entry, (list, tuple)) and len(entry) >= 2:
                    option_label = str(entry[1] or entry[0] or '').strip()
                    if option_label:
                        options.append(option_label)
            if options:
                english = f"{english} Available choices include: {', '.join(options)}."
                japanese = f"{japanese} 主な選択肢: {', '.join(options)}。"
        return str(_text_translation.pick(english, japanese))
    english = f"Set the {pretty} used by this tool. Adjust it to control how the operation behaves."
    if kind == 'BoolProperty':
        english = f"Turn {pretty} on or off for this tool. Enable it when you want this behavior, or disable it to keep the current result unchanged."
    elif kind == 'EnumProperty':
        options = []
        if isinstance(items, (list, tuple)):
            for entry in items[:4]:
                if isinstance(entry, (list, tuple)) and len(entry) >= 2:
                    option_label = str(entry[1] or entry[0] or '').strip()
                    if option_label:
                        options.append(option_label)
        option_text = f" Available choices include: {', '.join(options)}." if options else ''
        english = f"Choose the {pretty} option used by this tool. Switching it changes how the operation runs.{option_text}"
    elif kind in {'IntProperty', 'FloatProperty'}:
        english = f"Set the numeric value for {pretty}. Increase or decrease it to fine-tune the strength, size, spacing, or threshold used by this tool."
    elif kind in {'StringProperty'}:
        english = f"Enter the text used for {pretty}. Use this when you need to name, label, filter, or target something in the workflow."
    elif kind in {'PointerProperty', 'CollectionProperty'}:
        english = f"Store the structured data used for {pretty}. This connects the tool to Blender data or to a reusable list of settings."
    japanese = f"このツールで使う {pretty} を設定します。値や選択肢を調整して処理の挙動をコントロールします。"
    if kind == 'BoolProperty':
        japanese = f"このツールで {pretty} をオン・オフします。有効にするとその挙動を使い、無効にすると現在の結果を保ったまま進めます。"
    elif kind == 'EnumProperty':
        japanese = f"このツールで使う {pretty} の選択肢を決めます。切り替えると処理方法や結果の出し方が変わります。"
    elif kind in {'IntProperty', 'FloatProperty'}:
        japanese = f"{pretty} の数値を設定します。強さ、大きさ、間隔、しきい値などを細かく調整したい時に使います。"
    elif kind in {'StringProperty'}:
        japanese = f"{pretty} に使う文字列を入力します。名前付け、ラベル、フィルター、対象指定などに使います。"
    elif kind in {'PointerProperty', 'CollectionProperty'}:
        japanese = f"{pretty} に使う構造化データを保持します。Blender データや再利用設定のリストをこのツールへ接続します。"
    return str(_text_translation.pick(english, japanese))


def _suv_install_property_tooltip_bridge() -> None:
    # Standard N-panel build: do not monkey-patch bpy.props globally.  Property
    # descriptions must be supplied explicitly by the owning classes/operators.
    return None



_suv_install_property_tooltip_bridge()

# ============================================================
# Preferences
# ============================================================

class SUV_AddonPreferences(bpy.types.PropertyGroup):
    bl_idname = (__package__ or __name__.split(".")[0])
    bl_label = "Addon Preferences"
    bl_description = 'Addon Preferences. Global UV Suite settings for language, panel visibility, feature families, and reference-wide behavior. Open this section when you want to change how the whole add-on behaves before working in the UV tools. / アドオン設定。言語、パネル表示、機能ファミリー、有効化状態など UV Suite 全体の挙動を切り替える共通設定です。作業前にアドオン全体の振る舞いを決めたい時に開きます。'

    ui_language_mode: bpy.props.EnumProperty(
        name="UI Language",
        description="Choose whether the add-on follows Blender language or forces English/Japanese.",
        items=[
            ('AUTO', "Auto", "Follow Blender language automatically.", 0),
            ('FORCE_EN', "English", "Always show this add-on in English.", 1),
            ('FORCE_JA', "Japanese", "Always show this add-on in Japanese.", 2),
            ('0', "Auto", "Legacy saved value; normalized to Auto after load.", 100),
            ('1', "English", "Legacy saved value; normalized to English after load.", 101),
            ('2', "Japanese", "Legacy saved value; normalized to Japanese after load.", 102),
        ],
        default='AUTO'
    )
    show_in_uv_editor: bpy.props.BoolProperty(
        name="Show in UV Editor",
        description='Legacy option kept for backward compatibility. The current UI is shown in the standard UV Suite N-panel. / 互換性維持用の旧設定です。現在のUIは標準の UVスイートNパネルに表示されます。',
        default=False
    )
    show_in_3d_view: bpy.props.BoolProperty(
        name="Show in 3D View",
        description='Legacy option kept for backward compatibility. The current UI is shown in the standard UV Suite N-panel. / 互換性維持用の旧設定です。現在のUIは標準の UVスイートNパネルに表示されます。',
        default=False
    )

    enable_pro_tools: bpy.props.BoolProperty(
        name="Enable Pro Tools",
        description="Enable advanced workflow tools such as Stack, Pack, Density, Inspector and Auto Unwrap / Stack、Pack、Density、Inspector、自動展開などの高度ツールを有効にします",
        default=True
    )
    enable_sets_tools: bpy.props.BoolProperty(
        name="Enable Selection & Sets",
        description="Enable selection helpers, saved sets and reuse tools / 選択補助、保存セット、再利用ツールを有効にします",
        default=True
    )
    enable_symmetry_tools: bpy.props.BoolProperty(
        name="Enable Symmetry Tools",
        description="Enable symmetry detection, mirroring and pair-based helpers / 対称検出、ミラー、ペア補助を有効にします",
        default=True
    )
    enable_atlas_tools: bpy.props.BoolProperty(
        name="Enable Atlas/Material Tools",
        description="Enable atlas UV workflow and shared material builder tools / アトラスUVワークフローと共有マテリアル作成ツールを有効にします",
        default=True
    )

    debug_log: bpy.props.BoolProperty(
        name="Debug Log",
        description="Write additional debug information to the console for troubleshooting / トラブル解析用に追加のデバッグ情報をコンソールへ出力します",
        default=False
    )

    def draw(self, context):
        layout = self.layout
        try:
            layout.use_property_split = False
            layout.use_property_decorate = False
        except Exception:
            pass
        return


def _suv_addon_key_candidates():
    raw = str(__package__ or __name__.split(".")[0] or "uv_suite")
    candidates = [raw]
    if raw.startswith('bl_ext.'):
        short = raw.rsplit('.', 1)[-1]
        if short and short not in candidates:
            candidates.append(short)
    elif '.' in raw:
        short = raw.rsplit('.', 1)[-1]
        if short and short not in candidates:
            candidates.append(short)
    return tuple(candidates)


def _prefs(context):
    try:
        prefs = _tool_runtime.get_addon_preferences(context, __package__, __name__, __file__)
        if prefs is not None:
            return prefs
    except Exception:
        pass

    # Standard N-panel build: settings are hosted by WindowManager through
    # runtime.get_addon_preferences(); do not read AddonPreferences as a live UI host.
    return None


def _debug(context, msg: str):
    prefs = _prefs(context)
    if prefs and prefs.debug_log:
        _suv_warn_once('a106:base.py:896', f"[SUV] {msg}")


_SUV_DATA_CACHE = {}


def _suv_package_root():
    return os.path.dirname(os.path.abspath(__file__))


def _suv_extension_id() -> str:
    return str((_suv_addon_key_candidates()[-1] if _suv_addon_key_candidates() else 'uv_suite') or 'uv_suite')


def _suv_extension_user_root(create: bool = False) -> str:
    """Return the installed package for read-only bundled-resource access."""
    package_id = _suv_extension_id() or 'uv_suite'
    try:
        from . import storage as _storage
        return str(_storage.extension_user_root(package_id, create=False))
    except Exception:
        return _suv_package_root()



def _suv_bundled_data_path(*parts):
    return os.path.join(_suv_package_root(), 'data', *parts)


def _suv_user_data_dir(create: bool = False) -> str:
    """Return CONFIG-scoped editable data, never the package ``data`` folder."""
    try:
        from . import storage as _storage
        return str(_storage.addon_data_dir(create=create))
    except Exception:
        try:
            config = bpy.utils.user_resource('CONFIG', path='', create=bool(create)) or ''
        except Exception:
            config = ''
        if not config:
            config = os.path.join(os.path.expanduser('~'), '.config', 'blender', '5.1', 'config')
        data_dir = os.path.join(config, 'Smart_UV_Suite', 'user_data', 'data')
        if create:
            os.makedirs(data_dir, exist_ok=True)
        return data_dir


def _suv_seed_user_data_path(*parts) -> str:
    user_path = os.path.join(_suv_user_data_dir(create=True), *parts)
    bundled_path = _suv_bundled_data_path(*parts)
    try:
        if os.path.isfile(bundled_path) and not os.path.exists(user_path):
            os.makedirs(os.path.dirname(user_path), exist_ok=True)
            shutil.copy2(bundled_path, user_path)
    except Exception:
        pass
    return user_path


def _suv_data_path(*parts):
    if not parts:
        return _suv_user_data_dir(create=True)
    return _suv_seed_user_data_path(*parts)

def _suv_clone_data(value):
    try:
        return copy.deepcopy(value)
    except Exception:
        if isinstance(value, dict):
            return {k: _suv_clone_data(v) for k, v in value.items()}
        if isinstance(value, list):
            return [_suv_clone_data(v) for v in value]
        if isinstance(value, tuple):
            return tuple(_suv_clone_data(v) for v in value)
        return value


def _suv_load_json_data(filename: str, fallback=None, root_key: str | None = None):
    cache_key = (filename, root_key)
    if cache_key in _SUV_DATA_CACHE:
        return _suv_clone_data(_SUV_DATA_CACHE[cache_key])
    data = _suv_clone_data(fallback)
    path = _suv_data_path(filename)
    try:
        if os.path.isfile(path):
            with open(path, 'r', encoding='utf-8') as handle:
                parsed = json.load(handle)
            if root_key:
                if isinstance(parsed, dict):
                    parsed = parsed.get(root_key, _suv_clone_data(fallback))
                else:
                    parsed = _suv_clone_data(fallback)
            data = _suv_clone_data(parsed)
    except Exception:
        data = _suv_clone_data(fallback)
    if data is None:
        data = {}
    _SUV_DATA_CACHE[cache_key] = _suv_clone_data(data)
    return _suv_clone_data(data)

def _suv_invalidate_data_cache():
    _SUV_DATA_CACHE.clear()

# ============================================================
# i18n (EN/JA)
# ============================================================

_TEXT = {
    # Sections
    "ui.section.unwrap": ("Smart Unwrapping", "スマート展開"),
    "ui.section.align": ("Alignment & Transform", "アライメント＆変形"),
    "ui.section.pack": ("Packing & Layout", "パッキング＆レイアウト"),
    "ui.section.view3d": ("3D View Utils", "3Dビュー連携"),
    "ui.section.pro": ("Pro Tools", "Proツール"),
    "ui.section.inspector": ("Inspector", "検査"),
    "ui.section.auto": ("Auto Unwrap Pro", "自動展開 Pro"),
    "ui.section.sets": ("Selection & Sets", "選択＆セット"),
    "ui.section.sym": ("Symmetry", "対称"),
    "ui.section.atlas": ("Atlas / Material (Multi)", "アトラス／マテリアル（複数）"),

    # Legacy buttons
    "op.seams": ("Smart Seams", "スマート・シーム"),
    "op.tube": ("Smart Tube", "スマート・チューブ"),
    "op.relax": ("Smart Relax", "スマート・リラックス"),
    "op.straighten": ("Smart Edge Straighten", "スマート・エッジ直線化"),
    "op.rectify": ("Smart Rectify", "スマート・矩形化"),
    "op.transfer": ("3D Smart Transfer", "3Dスマート転送"),
    "op.repair": ("Repair Flipped Islands", "反転アイランド修復"),

    # Pro buttons
    "op.stack_pro": ("Stack Pro", "スタック Pro"),
    "op.pack_pro": ("Pack Pro", "パック Pro"),
    "op.texel_get": ("Get Density", "密度取得"),
    "op.texel_set": ("Set Density", "密度設定"),
    "op.texel_norm": ("Normalize Density", "密度統一"),
    "op.inspect_scan": ("Scan", "スキャン"),
    "op.inspect_select": ("Select Issue", "問題を選択"),
    "op.inspect_fix_flipped": ("Fix Flipped Islands", "反転アイランド修復"),
    "op.auto_unwrap": ("Auto Unwrap Pro", "自動展開 Pro"),

    # Sets
    "op.sel_island_active": ("Select Island (Active)", "アクティブ島を選択"),
    "op.sel_uv_boundary": ("Select UV Boundary", "UV境界を選択"),
    "op.sel_similar": ("Select Similar Islands", "類似アイランドを選択"),
    "op.set_save": ("Save Set", "セット保存"),
    "op.set_recall": ("Recall Set", "セット呼び出し"),
    "op.set_update": ("Update Set", "セット更新"),
    "op.set_delete": ("Delete Set", "セット削除"),

    # Symmetry
    "op.sym_detect": ("Detect Symmetry Pairs", "対称ペア検出"),
    "op.sym_mirror_uv": ("Mirror UV (Ref → Pair)", '参照からペアへUVミラー'),
    "op.sym_stack": ("Symmetry Stack", "対称スタック"),
    "op.sym_seams": ("Symmetry Seams", "対称シーム"),

    # Atlas
    "op.atlas_build_uv_multi": ("Build Atlas UV (Multi)", "アトラスUV作成（複数）"),
    "op.atlas_bake_multi": ("Bake Atlas (Multi)", "アトラスをベイク（複数）"),
    "op.atlas_build_mat_multi": ("Build Material & Apply (Multi)", "マテリアル生成＆適用（複数）"),
    "op.atlas_run_all_multi": ("Run All (Multi)", "全工程実行（複数）"),

    # Reports / errors
    "msg.no_active_mesh": ("No active mesh object.", "アクティブなメッシュがありません。"),
    "msg.no_selection": ("Nothing selected.", "選択がありません。"),
    "msg.need_two_islands": ("Select at least two islands.", "2つ以上のアイランドを選択してください。"),
    "msg.need_active_quad": ("Select an active quad face first.", "アクティブな四角面を選択してください。"),
    "msg.need_uv_editor_ctx": ("No UV Editor context available.", "UVエディタのコンテキストを確保できません。"),
    "msg.op_failed": ("Operation failed: {e}", "処理に失敗しました：{e}"),
    "msg.warn_pass_skip": ("Skipped pass {p}: {e}", "パス {p} をスキップ: {e}"),
    "msg.info": ("{t}", "{t}"),

    # Generic done
    "msg.seams_marked": ("Smart Seams: Marked {n} edges.", "スマート・シーム：{n} 本のエッジにシームを付けました。"),
    "msg.tube_done": ("Smart Tube: Unwrapped.", "スマート・チューブ：展開しました。"),
    "msg.relax_done": ("Smart Relax: Completed.", "スマート・リラックス：完了しました。"),
    "msg.straighten_done": ("Smart Edge Straighten: Completed.", "スマート・エッジ直線化：完了しました。"),
    "msg.rectify_done": ("Smart Rectify: Completed.", "スマート・矩形化：完了しました。"),
    "msg.transfer_done": ("3D Smart Transfer: UV transferred.", "3Dスマート転送：UVを転送しました。"),
    "msg.repair_done": ("Fixed flipped islands: {n}.", "反転アイランドを修復: {n}"),

    # Sets
    "msg.set_saved": ("Set saved: {name}", "セット保存: {name}"),
    "msg.set_missing": ("Set not found: {name}", "セットが見つかりません: {name}"),
    "msg.set_deleted": ("Set deleted: {name}", "セット削除: {name}"),
    "msg.set_recalled": ("Set recalled: {name}", "セット呼び出し: {name}"),

    # Symmetry
    "msg.sym_pairs_done": ("Symmetry pairs detected: {n}", "対称ペア検出: {n}"),
    "msg.sym_no_pair": ("No symmetry pair found for active island.", "アクティブ島の対称ペアが見つかりません。"),
    "msg.sym_mirrored": ("Mirrored UV to symmetry pair.", "対称ペアへUVをミラーコピーしました。"),
    "msg.sym_seams_done": ("Symmetry seams updated.", "対称シームを更新しました。"),
    "msg.sym_stack_done": ("Symmetry stack: stacked {n} pairs.", "対称スタック：{n} ペアを重ねました。"),

    # Pro tools
    "msg.stack_pro_done": ("Stack Pro: stacked {n} islands.", "スタックPro：{n} 個を重ねました。"),
    "msg.pack_pro_done": ("Pack Pro: packed {n} islands.", "パックPro：{n} 個を配置しました。"),
    "msg.pack_pro_all_locked": ("Pack Pro: all islands are locked/pinned.", "パックPro：全て固定/ピンのため移動しません。"),
    "msg.texel_sampled": ("Density: {d:.1f} px/m.", "密度: {d:.1f} px/m"),
    "msg.texel_norm_done": ("Normalize: processed {n} islands.", "密度統一：{n} 個を処理しました。"),
    "msg.inspect_summary": ("Flipped:{f} Zero:{z} Out:{o} Overlap:{p} Stretch:{s}.", "反転:{f} ゼロ:{z} タイル外:{o} 重なり:{p} ストレッチ:{s}"),
    "msg.auto_done": ("Auto Unwrap Pro: Done.", "自動展開Pro：完了しました。"),

    # Atlas
    "msg.atlas_need_cycles": ("Cycles required for baking.", "ベイクにはCyclesが必要です。"),
    "msg.atlas_multi_packed": ("Atlas multi packed {n} islands.", "複数アトラス：{n} アイランドを配置しました。"),
    "msg.atlas_bake_done": ("Bake done.", "ベイク完了。"),
    "msg.atlas_mat_done": ("Material built & applied.", "マテリアルを生成し適用しました。"),
    "op.inspect_select_overlap": ("Select Overlap", "重なりを選択"),
    "msg.pack_pro_tiles_done": ("Pack Pro: packed {n} islands into {t} tiles.", "パックPro：{n} 個を {t} タイルに配置しました。"),
    "msg.preflight_missing_uv": ("Missing UV maps on: {objs}", "次のオブジェクトにUVマップがありません: {objs}"),
    "msg.preflight_missing_active_uv": ("No active UV map on: {objs}", "次のオブジェクトでアクティブUVが未設定です: {objs}"),
    "msg.preflight_missing_named_uv": ("Required UV map '{name}' is missing on: {objs}", "必要なUVマップ '{name}' が次のオブジェクトにありません: {objs}"),
    "msg.preflight_temp_materials": ("Temporary bake materials were created for: {objs}", "次のオブジェクトに一時ベイク用マテリアルを作成しました: {objs}"),
    "msg.preflight_no_active": ("No active mesh object could be prepared.", "実行に使えるアクティブメッシュを準備できませんでした。"),

}

_TEXT.update({
    "msg.need_edit_mesh": ("Switch to Edit Mode on the active mesh first.", "先にアクティブなメッシュを編集モードにしてください。"),
    "op.hs_orthogonalize": ("Orthogonalize UVs", "直交化"),
    "op.hs_rectify_fit": ("Fit Rectified Shape", "矩形フィット"),
    "op.groups_to_tiles": ("Move Groups to Tiles", "グループをタイルへ移動"),
    "ui.groups_to_tiles": ("Move Groups to Tiles", "グループをタイルへ移動"),
    "op.batch_object_to_udim_tiles": ("Move Objects to UDIM Tiles", "オブジェクトをUDIMタイルへ移動"),
    "ui.menu.batch_object_to_udim_tiles": ("Move Objects to UDIM Tiles", "オブジェクトをUDIMタイルへ移動"),
    "op.inspector_scan": ("Inspector Scan", "検査スキャン"),
    "op.workspace_validate.desc": (
        "Run a UV Suite health check for workspace settings, icons and selected mesh UV readiness.",
        "ワークスペース設定、アイコン、選択メッシュのUV準備状態を点検します。",
    ),
    "ui.readiness.repair.title": ("Auto Repair Workspace", "ワークスペース自動修復"),
    "ui.menu.atlas_run_all_multi": ("Run All (Multi)", "一括実行（複数）"),
    "ui.menu.fix_flipped": ("Fix Flipped Islands", "反転アイランド修正"),
    "ui.menu.inspector_fix_flipped": ("Fix Flipped Islands", "反転アイランド修正"),
    "ui.menu.hotspot_symmetry_refill": ("Refill Symmetric Hotspots", "対称ホットスポット再充填"),
    "ui.menu.stack_symmetry_topology": ("Stack Symmetric Topology", "対称トポロジースタック"),
    "ui.menu.select_fragmented_islands": ("Select Fragmented Islands", "断片化アイランド選択"),
    "ui.menu.show_stretch_heatmap": ("Build Stretch Heatmap", "ストレッチヒートマップ作成"),
    "ui.op.sel_similar": ("Select Similar Islands", "類似アイランドを選択"),
    "ui.op.sel_identical": ("Select Identical Islands", "同一アイランド選択"),
    "ui.op.udim_crossing": ("Select UDIM Crossing", "UDIMまたぎ選択"),
    "ui.quick_unwrap": ("Auto Unwrap Pro", "自動プロ展開"),
    "ui.quick_align": ("Align Islands", "アイランド整列"),
    "ui.quick_fit": ("Fit to Bounds", "境界へフィット"),
    "ui.quick_stack": ("Stack Pro", "プロスタック"),
    "ui.section.uv_maps": ("UV Maps", "UVマップ"),
    "ui.control.obj_active": ("Active Mesh: {name}", "アクティブメッシュ: {name}"),
    "ui.control.obj_none": ("Active Mesh: none", "アクティブメッシュ: なし"),
    "ui.mode.no_mesh": ("No active mesh object.", "アクティブなメッシュがありません。"),
    "ui.visual.controls_last_reason": ("Last visual change", "直近の視覚変更"),
    "ui.visual.recommended_why": ("Why these now", "今これを勧める理由"),
    "ui.visual.reason.prepare": ("Missing setup basics", "準備不足を解消"),
    "ui.visual.reason.readiness": ("Check current readiness", "現在の準備状態を確認"),
    "ui.visual.reason.workspace": ("Repair workspace context", "ワークスペース前提を修復"),
    "ui.visual.reason.doctor": ("Review priority fixes", "優先修正を確認"),
    "ui.visual.reason.audit": ("Inspect tool_runtime issues", "実行時問題を点検"),
    "ui.visual.reason.cleanup": ("Check generated clutter", "生成データの整理候補を確認"),
    "ui.visual.reason.coverage": ("Check missing feature groups", "不足機能グループを確認"),
    "ui.visual.reason.playbook": ("Open guided task flow", "タスク別ガイドを開く"),
    "ui.visual.reason.workspace_flow": ("Suggested for this workspace", "今のワークスペース向け"),
})

def _lang_is_ja(context) -> bool:
    prefs = None
    try:
        prefs = _prefs(context or getattr(bpy, 'context', None))
    except Exception:
        prefs = None
    mode = str(getattr(prefs, 'ui_language_mode', 'AUTO') or 'AUTO').upper() if prefs is not None else 'AUTO'
    if mode == 'FORCE_JA':
        return True
    if mode == 'FORCE_EN':
        return False
    try:
        return bool(_text_translation.is_japanese(context))
    except Exception:
        try:
            loc = bpy.app.translations.locale or ""
        except Exception:
            loc = ""
        return loc.lower().startswith("ja")

def tr(context, key: str, **fmt) -> str:
    en, ja = _TEXT.get(key, (key, key))
    s = ja if _lang_is_ja(context) else en
    try:
        s = s.format(**fmt)
    except Exception:
        pass
    try:
        return _rename_catalog.apply_text_renames(_text_translation.translate_text(s, context=context), context=context)
    except Exception:
        return _rename_catalog.apply_text_renames(s, context=context)


_UI_TEXT_CUSTOM = {
    # Short labels
    "Active Role": "アクティブ役割",
    "Apply Density": "密度を適用",
    "Band Count": "バンド数",
    "Base Name": "ベース名",
    "Capture Current Hotspot": "現在のホットスポットを取得",
    "Clear Existing": "既存をクリア",
    "Compare Epsilon": "比較イプシロン",
    "Copy From": "コピー元",
    "Create Missing": "不足分を作成",
    "Create Missing Role": "不足ロールを作成",
    "Create Missing Roles": "不足ロールを作成",
    'Density Profiles Menu': '密度プロファイルメニュー',
    'External Compatibility Menu': '外部互換メニュー',
    "Face Scope": "面の範囲",
    "Fit to Tile": "タイルに合わせる",
    "Gridify": "グリッド化",
    "Import": "読み込み",
    'Inspector Profiles Menu': 'インスペクタープロファイルメニュー',
    "Left Profile Name": "左プロファイル名",
    "Margin": "マージン",
    "Mode": "モード",
    "Name": "名前",
    "Object Order": "オブジェクト順",
    'Pack Profiles Menu': 'プロファイルパックメニュー',
    'Padding Panel': "余白",
    "Preserve Existing Matching Payloads": "一致済みペイロードを保持",
    "Preset": "プリセット",
    "Profile": "プロファイル",
    "Profile Name": "プロファイル名",
    "Profile Name (blank = Latest)": "プロファイル名（空欄で最新）",
    "Profile Name Filter (optional)": "プロファイル名フィルター（任意）",
    "Remove Extra UVs": "余分なUVを削除",
    "Render Role": "レンダー役割",
    "Replace Existing Payload": "既存ペイロードを置換",
    "Reset Workspace": 'ワークスペースリセット',
    "Right Profile Name (blank = Latest)": "右プロファイル名（空欄で最新）",
    "Role": "役割",
    "Route Preset": "ルートプリセット",
    "Scope": "範囲",
    "Select Changed": "変更分を選択",
    "Select Mismatches": "不一致を選択",
    "Select Prepared": "準備済みを選択",
    "Select Processed": "処理済みを選択",
    "Select Repaired": "修復済みを選択",
    "Set Active": "アクティブに設定",
    "Set Render": "レンダーに設定",
    "Single Fallback": "単独フォールバック",
    'UV Suite UI draw fallback': 'UV Suite UI 描画フォールバック',
    "Source Profile Name": "元プロファイル名",
    "Source UV": "元UV",
    "Start U": "開始U",
    "Start V": "開始V",
    "Stop On Error": "エラーで停止",
    "Strict Topology": "厳密トポロジー",
    "Target Profile Name": "先プロファイル名",
    "Target UV": "対象UV",
    "Targets": "対象",
    "Texture Size": "テクスチャサイズ",
    "Tile Layout": "タイル配置",
    'Workflow More Menu': 'ワークフローMoreメニュー',
    'Workflow Recipes Menu': 'ワークフローレシピメニュー',
    "Export Actions CSV": "操作CSVを書き出し",
    "Export Actions File": "操作ファイルを書き出し",
    "Export Naming File": "命名ファイルを書き出し",
    "Export Rename Drift CSV": "改名差分CSVを書き出し",
    "Export Rename Drift File": "改名差分ファイルを書き出し",
    "Export Rename History CSV": "改名履歴CSVを書き出し",
    "Export Rename Plan File": "改名計画ファイルを書き出し",
    "Export Rename State File": "改名状態ファイルを書き出し",
    "Export Restore Plan File": "復元計画ファイルを書き出し",
    "Export Summary File": "要約ファイルを書き出し",
    "Select Alias Ready": "エイリアス準備済みを選択",
    "Select Alias Roles": "エイリアス役割を選択",
    "Select Duplicate Extras": "重複余剰を選択",
    "Select Fix Duplicates": "重複修正対象を選択",
    "Select Needs Rename": "改名必要を選択",
    "Select Pairable": "ペア化可能を選択",
    "Select Pairable Noisy": "ノイズ付きペア候補を選択",
    "Select Pairable Ready": "準備済みペア候補を選択",
    "Select Ready Rename": "改名準備済みを選択",
    "Select Ready to Bake": "ベイク準備済みを選択",
    "Select Rename Blocked": "改名ブロックを選択",
    "Select Rename Conflicts": "改名競合を選択",
    "Select Rename Drift Extras": "改名差分余剰を選択",
    "Select Rename Drift Restored+Extra": "改名差分の復元+余剰を選択",
    "Select Rename Drift Review": "改名差分レビューを選択",
    "Select Rename Drift Target+Extra": "改名差分の対象+余剰を選択",
    "Select Rename State Both": "改名状態の両方を選択",
    "Select Rename State Restored": "改名状態の復元済みを選択",
    "Select Rename State Target": "改名状態の対象を選択",
    "Select Restore Blocked": "復元ブロックを選択",
    "Select Restore Ready": "復元準備済みを選択",
    "Select Review": "レビュー対象を選択",
    "Select Review Manual": "手動レビュー対象を選択",
    "Select Tile": "タイルを選択",
    "Write External JSON": "外部JSONを書き出し",
    "Write JSON Report": "JSONレポートを書き出し",
    "Write Text Report": "テキストレポートを書き出し",
    'Batch Density Tools Menu': '一括密度ツールメニュー',
    'Batch UDIM Tools Menu': '一括UDIMツールメニュー',
    'Batch UV Layer Tools Menu': '一括UVレイヤーツールメニュー',

    # Long button labels / helpers
    "Activates the chosen semantic role UV on the selected meshes and can sync render/export UV to the same layer.": "選択メッシュで指定したセマンティック役割UVを有効化し、必要に応じてレンダー／書き出しUVも同じレイヤーへ同期します。",
    "Applies a common edit/render role pairing such as Atlas→Main or Main→Lightmap in one pass.": "Atlas→Main や Main→Lightmap のような一般的な編集／レンダー役割の組み合わせを一度に適用します。",
    "Applies a named saved active/render semantic UV route profile to the selected meshes.": "保存済みの名前付きアクティブ／レンダー用セマンティックUVルートプロファイルを選択メッシュへ適用します。",
    "Applies or repairs a semantic UV role stack on the selected meshes.": "選択メッシュにセマンティックUV役割スタックを適用または修復します。",
    "Applies the latest saved active/render semantic UV route profile to the selected meshes.": "最新保存のアクティブ／レンダー用セマンティックUVルートプロファイルを選択メッシュへ適用します。",
    "Archives one named saved semantic UV route profile into the Archived folder instead of deleting it outright.": "指定した保存済みセマンティックUVルートプロファイルを削除せず Archived フォルダーへ退避します。",
    "Audits selected meshes against the active mesh UV stack.": "選択メッシュをアクティブメッシュのUVスタック基準で監査します。",
    "Audits selected meshes against the chosen UV role preset.": "選択メッシュを指定したUV役割プリセット基準で監査します。",
    "Audits selected meshes against the latest saved or a named semantic UV role route profile and reports mismatches only.": "選択メッシュを最新保存または指定名のセマンティックUV役割ルートプロファイルと比較し、不一致のみ報告します。",
    "Audits the other selected meshes against the active mesh current active/render UV route and reports mismatches only.": "他の選択メッシュをアクティブメッシュ現在のアクティブ／レンダーUVルートと比較し、不一致のみ報告します。",
    "Compares current meshes against the latest UV stack snapshot.": "現在のメッシュを最新のUVスタックスナップショットと比較します。",
    "Compares one named semantic UV role route profile against the latest profile or another named profile and writes a diff report.": "指定したセマンティックUV役割ルートプロファイルを最新プロファイルまたは別名プロファイルと比較し、差分レポートを書き出します。",
    "Compares the live named semantic UV role route profile against the newest archived copy before restore.": "復元前に、ライブ中の指定セマンティックUV役割ルートプロファイルと最新のアーカイブ版を比較します。",
    "Compares the live named semantic UV role route profile against the newest disabled copy before re-enabling.": "再有効化前に、ライブ中の指定セマンティックUV役割ルートプロファイルと最新の無効化版を比較します。",
    "Copies the active mesh current active/render UV route to other selected meshes.": "アクティブメッシュ現在のアクティブ／レンダーUVルートを他の選択メッシュへコピーします。",
    "Creates restore-ready snapshots, safely applies the latest saved or a named semantic UV role route profile, and archives before/after checkpoint files.": "復元用スナップショットを作成し、最新保存または指定名のセマンティックUV役割ルートプロファイルを安全適用し、前後チェックポイントを記録します。",
    "Creates restore-ready snapshots, safely repairs saved route mismatches, and archives before/after checkpoint files.": "復元用スナップショットを作成し、保存済みルートの不一致を安全修復し、前後チェックポイントを記録します。",
    "Duplicates one named saved semantic UV role route profile into another named profile.": "指定した保存済みセマンティックUV役割ルートプロファイルを別名プロファイルへ複製します。",
    "If a live copy already exists, it is backed up into Archived/RestoreBackups first.": "ライブ中のコピーが既に存在する場合は、先に Archived/RestoreBackups へバックアップします。",
    "If a live copy already exists, it is backed up into Disabled/RestoreBackups first.": "ライブ中のコピーが既に存在する場合は、先に Disabled/RestoreBackups へバックアップします。",
    "Lists the archived semantic UV route profiles that can be compared or restored later.": "後で比較または復元できるアーカイブ済みセマンティックUVルートプロファイルを一覧表示します。",
    "Lists the currently saved named semantic UV route profiles and writes an inventory report.": "現在保存されている名前付きセマンティックUVルートプロファイルを一覧表示し、インベントリーレポートを書き出します。",
    "Lists the disabled semantic UV route profiles that can be re-enabled later.": "後で再有効化できる無効化済みセマンティックUVルートプロファイルを一覧表示します。",
    "Moves UV layers outside the chosen semantic role preset into quarantine names and keeps them behind the role stack instead of deleting them.": "選択したセマンティック役割プリセット外のUVレイヤーを削除せず隔離名へ移動し、役割スタックの後ろに保持します。",
    "Normalizes aliases, applies the chosen UV-role preset, and deduplicates identical layers in one pass.": "エイリアスを正規化し、選択したUV役割プリセットを適用し、同一レイヤーを一括で重複整理します。",
    "Normalizes aliases, applies the preset, resolves conflicts, sorts roles, and deduplicates in one safety-first pass.": "エイリアス正規化、プリセット適用、競合解決、役割並べ替え、重複整理を安全優先で一括実行します。",
    "Promotes each selected mesh's active UV layer into the chosen semantic role and keeps conflicts aside safely.": "各選択メッシュのアクティブUVレイヤーを指定したセマンティック役割へ昇格し、競合は安全に退避します。",
    "Promotes quarantined layers back into recognized semantic roles when safe, merges identical duplicates, and keeps unresolved conflicts aside.": "隔離レイヤーを安全な場合に認識済みセマンティック役割へ戻し、同一重複を統合し、未解決競合は退避したままにします。",
    "Removes UV layers that have identical payloads inside each target mesh.": "各対象メッシュ内で同一ペイロードを持つUVレイヤーを削除します。",
    "Renames one named saved semantic UV role route profile into another name and safely backs up any existing target copy first.": "指定した保存済みセマンティックUV役割ルートプロファイルを別名へ変更し、既存の同名先があれば先に安全バックアップします。",
    "Repairs only meshes that differ from the active UV stack template.": "アクティブUVスタックテンプレートと異なるメッシュのみ修復します。",
    "Repairs only meshes that differ from the active mesh UV stack.": "アクティブメッシュのUVスタックと異なるメッシュのみ修復します。",
    "Repairs only meshes that differ from the chosen UV role preset.": "指定したUV役割プリセットと異なるメッシュのみ修復します。",
    "Repairs only meshes whose active/render UV role route differs from the active mesh, validates the result, and rolls back failures.": "アクティブメッシュとアクティブ／レンダーUV役割ルートが異なるメッシュのみ修復し、結果を検証して失敗はロールバックします。",
    "Repairs only meshes whose active/render UV role route differs from the active mesh.": "アクティブメッシュとアクティブ／レンダーUV役割ルートが異なるメッシュのみ修復します。",
    "Repairs only meshes whose active/render UV role route differs from the latest saved or a named semantic route profile.": "最新保存または指定名のセマンティックルートプロファイルと異なるアクティブ／レンダーUV役割ルートのみ修復します。",
    "Resolves duplicate semantic role claims by merging identical duplicates and renaming conflicting payloads aside.": "重複するセマンティック役割主張を、同一重複の統合と競合ペイロードの退避改名によって解決します。",
    "Restores the latest UV stack snapshot onto matching meshes.": "一致するメッシュへ最新のUVスタックスナップショットを復元します。",
    "Restores the newest archived copy of one named semantic UV role route profile back into the live profile store.": "指定したセマンティックUV役割ルートプロファイルの最新アーカイブ版をライブプロファイル保管庫へ戻します。",
    "Restores the newest disabled copy of one named semantic UV role route profile back into the live profile store.": "指定したセマンティックUV役割ルートプロファイルの最新無効化版をライブプロファイル保管庫へ戻します。",
    "Routes one semantic role to active editing and another semantic role to render/export on the selected meshes.": "選択メッシュで一方のセマンティック役割を編集用アクティブに、もう一方をレンダー／書き出し用に割り当てます。",
    "Runs stabilize, validates the result, and rolls back only meshes that fail validation.": "安定化を実行し、結果を検証し、検証に失敗したメッシュだけをロールバックします。",
    "Safely applies the latest saved or a named semantic UV role route profile to the selected meshes and rolls back any mesh that fails validation.": "最新保存または指定名のセマンティックUV役割ルートプロファイルを選択メッシュへ安全適用し、検証失敗メッシュはロールバックします。",
    "Safely repairs only meshes whose active/render UV role route differs from the latest saved or a named semantic route profile.": "最新保存または指定名のセマンティックルートプロファイルと異なるアクティブ／レンダーUV役割ルートのみ安全修復します。",
    "Saves the active mesh current active/render UV route as the latest reusable route profile.": "アクティブメッシュ現在のアクティブ／レンダーUVルートを、再利用可能な最新ルートプロファイルとして保存します。",
    "Saves the active mesh current active/render UV route into a named reusable route profile and refreshes the latest profile.": "アクティブメッシュ現在のアクティブ／レンダーUVルートを、名前付き再利用ルートプロファイルへ保存し、最新プロファイルも更新します。",
    "Snapshots the current UV stack for restore, runs safe stabilize, and archives before/after checkpoint files.": "復元用に現在のUVスタックをスナップショットし、安全安定化を実行して前後チェックポイントを保存します。",
    "Sorts the current UV stack by semantic role priority and keeps unknown names at the end.": "現在のUVスタックをセマンティック役割優先度で並べ替え、未知名は末尾に保持します。",
    "Stores the latest UV stack snapshot for selected meshes.": "選択メッシュ用に最新のUVスタックスナップショットを保存します。",
    "Takes the best recommended semantic UV route profile for the active mesh current route and safely applies it to the other selected meshes.": "アクティブメッシュ現在のルートに最適な推奨セマンティックUVルートプロファイルを選び、他の選択メッシュへ安全適用します。",
    "Temporarily disables one named saved semantic UV route profile into the Disabled folder instead of permanently archiving it.": "指定した保存済みセマンティックUVルートプロファイルを恒久アーカイブせず Disabled フォルダーへ一時無効化します。",
    'Use this before restore/apply when you want UV Suite to suggest the nearest saved candidate.': '復元や適用の前に、UV Suite に最も近い保存候補を提案させたい時に使います。',
    "Use this to inspect differences before you bring a disabled profile back into the live store.": "無効化プロファイルをライブ保管庫へ戻す前に差分確認するために使います。",
    "Use this to inspect differences before you bring an archived profile back.": "アーカイブ済みプロファイルを戻す前に差分確認するために使います。",
    "Use this to inspect restore candidates before bringing them back into the live store.": "ライブ保管庫へ戻す前に復元候補を確認するために使います。",
    "Use this to inspect temporarily disabled profiles before moving them back into the live store.": "ライブ保管庫へ戻す前に一時無効化プロファイルを確認するために使います。",
    'Use this when recommendation already found the closest candidate and you want UV Suite to validate and roll back failures automatically.': '推奨機能が最も近い候補を見つけており、UV Suite に自動検証と失敗ロールバックまで任せたい時に使います。',
    'Use this when you want UV Suite to pick the best stored candidate first, then bring it back for future live use.': 'UV Suite に最適な保存候補を先に選ばせ、その後ライブ利用へ戻したい時に使います。',
    "Use this when you want the profile hidden from live use but easy to bring back later.": "ライブ利用からは隠しつつ、後で簡単に戻せる状態にしたい時に使います。",
    "Validate Workflow Assets": 'ワークフローアセット検証',
    "Writes a restore-ready UV stack snapshot, runs safe route repair, and archives before/after checkpoint files.": "復元用UVスタックスナップショットを作成し、安全ルート修復を実行して前後チェックポイントを保存します。",
    "Apply Canonical Names": "正規名を適用",
    "Bake Action Report": "ベイク操作レポート",
    "Bake Duplicate Report": "ベイク重複レポート",
    "Bake Naming Report": "ベイク命名レポート",
    "Bake Rename Drift": "ベイク改名差分",
    "Bake Rename History": "ベイク改名履歴",
    "Bake Rename Plan": "ベイク改名計画",
    "Bake Rename State": "ベイク改名状態",
    "Bake Restore Plan": "ベイク復元計画",
    "Bake Summary Report": "ベイク要約レポート",
    "Build Action Root Sets": "操作ルートセットを作成",
    "Build Rename Drift Sets": "改名差分セットを作成",
    "Build Rename State Sets": "改名状態セットを作成",
    "Build Restore Plan Sets": "復元計画セットを作成",
    "Clear Scan": "スキャン結果をクリア",
    "Density Profiles Tools": "密度プロファイルツール",
    "External Layout Profiles": "外部レイアウトプロファイル",
    "Fix All": "すべて修正",
    "Hotspot Presets": "ホットスポットプリセット",
    "Inspector Profiles Tools": "検査プロファイルツール",
    "Layout Libraries": "レイアウトライブラリ",
    "Maintenance": "メンテナンス",
    "Move to Tile": "タイルへ移動",
    'Pack Profiles Menu': 'プロファイルパックメニュー',
    "Pack Profiles Tools": "パックプロファイルツール",
    "Rescan": "再スキャン",
    "Restore Last Canonical Names": "最後の正規名へ復元",
    "UDIM Manifest": "UDIM マニフェスト",
    "Unstack Grid": "グリッド重なり解除",
    "Unstack Overlap": "重なり解除",
    'Workflow Recipes Menu': 'ワークフローレシピメニュー',
}

_UI_TEXT_TERM_CUSTOM = {
    "Density": "密度",
    "Inspector": "Inspector",
    'Layout Panel': 'レイアウトパネル',
    "Pack": 'パック',
    "Presets": "プリセット",
    "Recipes": "レシピ",
    "Seam Library": "シームライブラリ",
    "Settings (Text)": "設定（テキスト）",
    "Workflow": "ワークフロー",
    "Hotspot": "ホットスポット",
    "Changed": "変更分",
    "Mismatches": "不一致",
    "Prepared": "準備済み",
    "Processed": "処理済み",
    "Repaired": "修復済み",
    "External JSON": "外部JSON",
    "JSON Report": "JSONレポート",
    "Text Report": "テキストレポート",
}

_UI_TEXT_CACHE = {"size": -1, "map": {}}


def _suv_ui_text_map():
    size = len(_TEXT) + len(_UI_TEXT_CUSTOM) + len(_UI_TEXT_TERM_CUSTOM)
    if _UI_TEXT_CACHE.get("size") == size:
        return dict(_UI_TEXT_CACHE.get("map") or {})
    mapping = {}
    for value in _TEXT.values():
        if not isinstance(value, (list, tuple)) or len(value) != 2:
            continue
        en, ja = value
        if isinstance(en, str) and isinstance(ja, str) and en and ja:
            mapping[en] = ja
    mapping.update(_UI_TEXT_CUSTOM)
    _UI_TEXT_CACHE["size"] = size
    _UI_TEXT_CACHE["map"] = dict(mapping)
    return dict(mapping)


def _suv_split_bilingual_inline_text(raw_text: str) -> dict:
    try:
        return dict(_text_translation.split_bilingual_inline(raw_text))
    except Exception:
        text = str(raw_text or "").strip()
        if not text:
            return {"en": "", "ja": "", "found": False}
        return {"en": text, "ja": text, "found": False}


def _suv_ui_label_lookup(en_text: str) -> dict:
    text = str(en_text or "").strip()
    inline = _suv_split_bilingual_inline_text(text)
    if bool(inline.get("found")):
        return inline
    mapping = _suv_ui_text_map()
    if text in mapping:
        return {"en": text, "ja": mapping[text], "found": True}
    if text in _UI_TEXT_TERM_CUSTOM:
        return {"en": text, "ja": _UI_TEXT_TERM_CUSTOM[text], "found": True}
    for prefix, suffix in (
        ("Export ", "を書き出し"),
        ("Import ", "を読み込み"),
        ("Select ", "を選択"),
        ("Write ", "を書き出し"),
    ):
        if text.startswith(prefix):
            tail = text[len(prefix):].strip()
            tail_info = _suv_ui_label_lookup(tail)
            tail_ja = str(tail_info.get("ja") or tail or "")
            if tail_ja:
                return {"en": text, "ja": tail_ja + suffix, "found": True}
    return {"en": text, "ja": text, "found": False}


def _suv_ui_text(context_or_text=None, text: str | None = None) -> str:
    if text is None:
        context = getattr(bpy, "context", None)
        raw_text = str(context_or_text or "").strip()
    else:
        context = context_or_text
        raw_text = str(text or "").strip()
    if not raw_text:
        return ""
    if context is None:
        context = getattr(bpy, "context", None)
    try:
        localized = str(_text_translation.translate_text(raw_text, context=context))
        if localized and localized != raw_text:
            return _rename_catalog.apply_text_renames(localized, context=context)
    except Exception:
        pass
    info = _suv_ui_label_lookup(raw_text)
    if _lang_is_ja(context):
        return _rename_catalog.apply_text_renames(info.get("ja") or raw_text, context=context)
    return _rename_catalog.apply_text_renames(info.get("en") or raw_text, context=context)

# ============================================================
# Context helpers
# ============================================================

def _active_mesh_obj(context):
    candidates = []
    try:
        candidates.append(context.view_layer.objects.active)
    except Exception:
        pass
    for attr in ('object', 'active_object'):
        try:
            candidates.append(getattr(context, attr, None))
        except Exception:
            pass
    for obj in candidates:
        if obj and getattr(obj, 'type', None) == 'MESH':
            return obj
    try:
        selected = [o for o in context.selected_objects if o and getattr(o, 'type', None) == 'MESH']
        if len(selected) == 1:
            return selected[0]
    except Exception:
        pass
    return None


def _selected_mesh_objects(context):
    try:
        objs = [o for o in context.selected_objects if o and getattr(o, 'type', None) == 'MESH']
    except Exception:
        objs = []
    if objs:
        seen = set()
        out = []
        for obj in objs:
            ptr = getattr(obj, 'as_pointer', lambda: 0)()
            if ptr in seen:
                continue
            seen.add(ptr)
            out.append(obj)
        return out
    obj = _active_mesh_obj(context)
    return [obj] if obj else []


def _is_uv_sync(context) -> bool:
    ts = context.scene.tool_settings
    return bool(getattr(ts, "use_uv_select_sync", False))

def _suv_normalize_mode_name(mode: str) -> str:
    raw = str(mode or '').upper().strip()
    aliases = {
        'EDIT_MESH': 'EDIT',
        'EDIT_CURVE': 'EDIT',
        'SCULPT_CURVES': 'SCULPT',
    }
    return aliases.get(raw, raw or 'OBJECT')


def _suv_safe_mode_set(context, obj, mode: str, *, source='Mode Set'):
    target = _suv_normalize_mode_name(mode)
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return False, f'{source}: no editable mesh object'
    if not _suv_object_is_selectable(obj):
        return False, f'{source}: object not selectable ({getattr(obj, "name", "<unnamed>")})'

    try:
        previous_selected = list(getattr(context, 'selected_objects', []) or [])
    except Exception:
        previous_selected = []
    try:
        previous_active = getattr(getattr(context, 'view_layer', None), 'objects', None)
        previous_active = getattr(previous_active, 'active', None)
    except Exception:
        previous_active = None
    previous_mode = _suv_normalize_mode_name(getattr(obj, 'mode', 'OBJECT'))

    def _rollback_active_context():
        rollback_issues = []
        active_now = None
        try:
            active_now = getattr(context.view_layer.objects, 'active', None)
        except Exception:
            active_now = None
        if active_now is obj:
            current_mode = _suv_normalize_mode_name(getattr(obj, 'mode', 'OBJECT'))
            if current_mode != previous_mode:
                try:
                    bpy.ops.object.mode_set(mode=previous_mode)
                except Exception as exc:
                    rollback_issues.append(f'mode rollback failed: {exc}')
        current_selected = []
        try:
            current_selected = list(getattr(context, 'selected_objects', []) or [])
        except Exception:
            current_selected = []
        previous_set = {o for o in previous_selected if o is not None}
        for other in current_selected:
            if other is None or other in previous_set:
                continue
            if not _suv_object_is_selectable(other):
                continue
            try:
                other.select_set(False)
            except Exception as exc:
                rollback_issues.append(f'deselect rollback failed for {getattr(other, "name", "<unnamed>")}: {exc}')
        for previous in previous_selected:
            if previous is None or not _suv_object_is_selectable(previous):
                continue
            try:
                previous.select_set(True)
            except Exception as exc:
                rollback_issues.append(f'select rollback failed for {getattr(previous, "name", "<unnamed>")}: {exc}')
        if previous_active is not None and _suv_object_is_selectable(previous_active):
            try:
                previous_active.select_set(True)
            except Exception as exc:
                rollback_issues.append(f'active reselect rollback failed for {getattr(previous_active, "name", "<unnamed>")}: {exc}')
            try:
                context.view_layer.objects.active = previous_active
            except Exception as exc:
                rollback_issues.append(f'active rollback failed for {getattr(previous_active, "name", "<unnamed>")}: {exc}')
        return rollback_issues

    active_error = None
    try:
        if not bool(obj.select_get()):
            obj.select_set(True)
    except Exception as exc:
        active_error = f'select failed: {exc}'

    active_obj = None
    try:
        active_obj = getattr(context.view_layer.objects, 'active', None)
    except Exception:
        active_obj = None

    if active_obj is not obj:
        try:
            context.view_layer.objects.active = obj
        except Exception as exc:
            active_error = f'active assign failed: {exc}'
        try:
            active_obj = getattr(context.view_layer.objects, 'active', None)
        except Exception:
            active_obj = None

    if active_obj is not obj:
        try:
            if not bool(obj.select_get()):
                obj.select_set(True)
            context.view_layer.objects.active = obj
        except Exception as exc:
            active_error = f'active assign retry failed: {exc}'
        try:
            active_obj = getattr(context.view_layer.objects, 'active', None)
        except Exception:
            active_obj = None

    if active_obj is not obj:
        detail = active_error or 'active object did not switch to target'
        rollback_issues = _rollback_active_context()
        if rollback_issues:
            detail = f'{detail}; rollback: ' + '; '.join(rollback_issues)
        return False, f'{source}: {detail} ({getattr(obj, "name", "<unnamed>")})'

    current = _suv_normalize_mode_name(getattr(obj, 'mode', 'OBJECT'))
    if current == target:
        return True, None
    try:
        bpy.ops.object.mode_set(mode=target)
    except Exception as exc:
        rollback_issues = _rollback_active_context()
        detail = str(exc)
        if rollback_issues:
            detail = f'{detail}; rollback: ' + '; '.join(rollback_issues)
        return False, f'{source}: {detail}'

    active_after = None
    try:
        active_after = getattr(context.view_layer.objects, 'active', None)
    except Exception:
        active_after = None
    if active_after is not obj:
        rollback_issues = _rollback_active_context()
        detail = f'active object changed during mode set ({getattr(obj, "name", "<unnamed>")})'
        if rollback_issues:
            detail = f'{detail}; rollback: ' + '; '.join(rollback_issues)
        return False, f'{source}: {detail}'

    current = _suv_normalize_mode_name(getattr(obj, 'mode', 'OBJECT'))
    if current != target:
        rollback_issues = _rollback_active_context()
        detail = f'mode remained {current} instead of {target}'
        if rollback_issues:
            detail = f'{detail}; rollback: ' + '; '.join(rollback_issues)
        return False, f'{source}: {detail}'
    return True, None

class _TempMode:
    def __init__(self, context, obj, mode: str):
        self.context = context
        self.obj = obj
        self.target_mode = mode
        self.prev_mode = None
        self.prev_selected = None
        self._preserve = None
        self.enter_ok = True
        self.last_error = None
    def __enter__(self):
        self.enter_ok = True
        self.last_error = None
        if not self.obj:
            self.enter_ok = False
            self.last_error = 'No target object'
            return self
        try:
            self._preserve = _PreserveContextState(self.context, restore_mode=True, restore_render_engine=False)
            self._preserve.__enter__()
        except Exception:
            self._preserve = None
        self.prev_mode = getattr(self.obj, 'mode', None)
        try:
            self.prev_selected = bool(self.obj.select_get())
        except Exception:
            self.prev_selected = None
        ok, err = _suv_safe_mode_set(self.context, self.obj, self.target_mode, source='TempMode enter')
        self.enter_ok = ok
        self.last_error = err
        return self
    def __exit__(self, exc_type, exc, tb):
        try:
            if self._preserve is not None:
                return self._preserve.__exit__(exc_type, exc, tb)
            if self.obj and self.prev_mode and getattr(self.obj, 'mode', None) != self.prev_mode:
                _suv_safe_mode_set(self.context, self.obj, self.prev_mode, source='TempMode restore')
        except Exception:
            pass
        return False

def _suv_object_is_selectable(obj) -> bool:
    if obj is None:
        return False
    try:
        if getattr(obj, 'hide_get', lambda: False)():
            return False
    except Exception:
        pass
    try:
        if getattr(obj, 'hide_viewport', False):
            return False
    except Exception:
        pass
    return True


def _suv_set_active_object(context, obj):
    # Defined in core.py, which loads after this module in the namespace
    # chain; delegate lazily so calls from this module resolve at run time.
    from . import core as _core
    return _core._suv_set_active_object(context, obj)


def _suv_ensure_uv_maps_selected(context, uv_name='UVMap_SUV'):
    # Defined in ui.py (later in the namespace chain); delegate lazily.
    from . import ui as _ui
    return _ui._suv_ensure_uv_maps_selected(context, uv_name)


def _suv_select_only(context, obj) -> bool:
    if not _suv_object_is_selectable(obj):
        return False

    try:
        previous_selected = list(getattr(context, 'selected_objects', []) or [])
    except Exception:
        previous_selected = []
    try:
        previous_active = getattr(getattr(context, 'view_layer', None), 'objects', None)
        previous_active = getattr(previous_active, 'active', None)
    except Exception:
        previous_active = None

    current_active = previous_active
    current_mode = ''
    try:
        current_mode = _suv_normalize_mode_name(getattr(current_active, 'mode', 'OBJECT')) if current_active is not None else ''
    except Exception:
        current_mode = ''
    if current_active is not None and current_mode not in {'', 'OBJECT'}:
        ok_escape, _escape_err = _suv_safe_mode_set(context, current_active, 'OBJECT', source='Select Only preflight')
        if not ok_escape:
            return False

    def _rollback_selection():
        try:
            bpy.ops.object.select_all(action='DESELECT')
        except Exception:
            pass
        for previous in previous_selected:
            if previous is None or not _suv_object_is_selectable(previous):
                continue
            try:
                previous.select_set(True)
            except Exception:
                pass
        if previous_active is not None and _suv_object_is_selectable(previous_active):
            _suv_set_active_object(context, previous_active)

    try:
        bpy.ops.object.select_all(action='DESELECT')
    except Exception:
        _rollback_selection()
        return False
    try:
        remaining = list(getattr(context, 'selected_objects', []) or [])
    except Exception:
        remaining = []
    if remaining:
        _rollback_selection()
        return False

    try:
        obj.select_set(True)
    except Exception:
        _rollback_selection()
        return False
    try:
        if not bool(getattr(obj, 'select_get', lambda: False)()):
            _rollback_selection()
            return False
    except Exception:
        _rollback_selection()
        return False

    if not _suv_set_active_object(context, obj):
        _rollback_selection()
        return False

    try:
        if getattr(getattr(context, 'view_layer', None), 'objects', None).active is not obj:
            _rollback_selection()
            return False
    except Exception:
        _rollback_selection()
        return False
    return True


class _PreserveContextState:
    def __init__(self, context, *, restore_mode=True, restore_render_engine=False):
        self.context = context
        self.restore_mode = restore_mode
        self.restore_render_engine = restore_render_engine
        self.prev_active = None
        self.prev_selected = []
        self.prev_mode = None
        self.prev_engine = None
    def __enter__(self):
        try:
            self.prev_active = self.context.view_layer.objects.active
        except Exception:
            self.prev_active = None
        try:
            self.prev_selected = list(getattr(self.context, 'selected_objects', []) or [])
        except Exception:
            self.prev_selected = []
        try:
            self.prev_mode = getattr(self.prev_active, 'mode', None)
        except Exception:
            self.prev_mode = None
        if self.restore_render_engine:
            try:
                self.prev_engine = self.context.scene.render.engine
            except Exception:
                self.prev_engine = None
        return self
    def __exit__(self, exc_type, exc, tb):
        try:
            current = list(getattr(self.context, 'selected_objects', []) or [])
        except Exception:
            current = []
        targets = {}
        for obj in current + self.prev_selected:
            if obj is None:
                continue
            try:
                targets[obj.as_pointer()] = obj
            except Exception:
                pass
        for obj in targets.values():
            if not _suv_object_is_selectable(obj):
                continue
            try:
                obj.select_set(False)
            except Exception:
                pass
        for obj in self.prev_selected:
            if not _suv_object_is_selectable(obj):
                continue
            try:
                obj.select_set(True)
            except Exception:
                pass
        active_restored = False
        if self.prev_active is not None and _suv_object_is_selectable(self.prev_active):
            try:
                active_restored = bool(_suv_set_active_object(self.context, self.prev_active))
            except Exception:
                active_restored = False
        if self.restore_mode and self.prev_active is not None and self.prev_mode:
            try:
                if _suv_object_is_selectable(self.prev_active):
                    if not active_restored:
                        active_restored = bool(_suv_set_active_object(self.context, self.prev_active))
                    if active_restored:
                        _suv_safe_mode_set(self.context, self.prev_active, self.prev_mode, source='PreserveContext restore')
            except Exception:
                pass
        if self.restore_render_engine and self.prev_engine:
            try:
                self.context.scene.render.engine = self.prev_engine
            except Exception:
                pass
        return False

# ============================================================
# UV Editor override for bpy.ops.uv.*
# ============================================================

class _UVOverride:
    def __init__(self, context, require_show_uvedit=True):
        self.context = context
        self.require_show_uvedit = require_show_uvedit
        self._restore = []
        self._override_kwargs = None
        self.used_temp_area = False
        self.area_source = None

    def _remember_space(self, space):
        old_show = getattr(space, "show_uvedit", None)
        self._restore.append(("SHOW_UVEDIT", space, old_show))
        if self.require_show_uvedit and old_show is False:
            try:
                space.show_uvedit = True
            except Exception:
                pass

    def _try_area(self, win, scr, area, source_tag):
        region = next((r for r in area.regions if r.type == 'WINDOW'), None)
        if not region:
            return False
        if area.type == 'IMAGE_EDITOR':
            try:
                self._remember_space(area.spaces.active)
            except Exception:
                pass
        self._override_kwargs = {"window": win, "screen": scr, "area": area, "region": region}
        self.area_source = source_tag
        return True

    def _repurpose_area(self, win, scr, area, source_tag):
        try:
            old_type = area.type
        except Exception:
            return False
        old_ui_type = getattr(area, 'ui_type', None)
        try:
            area.type = 'IMAGE_EDITOR'
        except Exception:
            return False
        self.used_temp_area = True
        self.area_source = source_tag
        self._restore.append(("AREA_TYPE", area, old_type, old_ui_type))
        try:
            if old_ui_type is not None:
                area.ui_type = 'UV'
        except Exception:
            pass
        try:
            self._remember_space(area.spaces.active)
        except Exception:
            pass
        return self._try_area(win, scr, area, source_tag)

    def __enter__(self):
        wm = self.context.window_manager
        fallback = None
        current_window = getattr(self.context, 'window', None)
        current_screen = getattr(self.context, 'screen', None)
        current_area = getattr(self.context, 'area', None)
        if current_window and current_screen and current_area:
            fallback = (current_window, current_screen, current_area, 'current-area')
        for win in wm.windows:
            scr = win.screen
            for area in scr.areas:
                if area.type == 'IMAGE_EDITOR':
                    if self._try_area(win, scr, area, 'image-editor'):
                        return self
                elif fallback is None and area.type == 'VIEW_3D':
                    fallback = (win, scr, area, 'view3d-fallback')
        if fallback is not None:
            win, scr, area, tag = fallback
            if self._repurpose_area(win, scr, area, tag):
                return self
        self._override_kwargs = None
        return self

    def __exit__(self, exc_type, exc, tb):
        try:
            for item in reversed(self._restore):
                if not item:
                    continue
                kind = item[0]
                if kind == "SHOW_UVEDIT":
                    _, space, old_show = item
                    if old_show is not None:
                        try:
                            space.show_uvedit = old_show
                        except Exception:
                            pass
                elif kind == "AREA_TYPE":
                    _, area, old_type, old_ui_type = item
                    try:
                        area.type = old_type
                    except Exception:
                        pass
                    if old_ui_type is not None:
                        try:
                            area.ui_type = old_ui_type
                        except Exception:
                            pass
        except Exception:
            pass
        return False

    @property
    def kwargs(self):
        return self._override_kwargs


class _TextEditorOverride:
    def __init__(self, context):
        self.context = context
        self._restore = []
        self._override_kwargs = None
        self.used_temp_area = False
        self.area_source = None

    def _try_area(self, win, scr, area, source_tag):
        region = next((r for r in area.regions if r.type == 'WINDOW'), None)
        if not region:
            return False
        self._override_kwargs = {"window": win, "screen": scr, "area": area, "region": region}
        self.area_source = source_tag
        return True

    def _repurpose_area(self, win, scr, area, source_tag):
        try:
            old_type = area.type
        except Exception:
            return False
        old_ui_type = getattr(area, 'ui_type', None)
        try:
            area.type = 'TEXT_EDITOR'
        except Exception:
            return False
        self.used_temp_area = True
        self.area_source = source_tag
        self._restore.append(("AREA_TYPE", area, old_type, old_ui_type))
        return self._try_area(win, scr, area, source_tag)

    def __enter__(self):
        wm = self.context.window_manager
        fallback = None
        current_window = getattr(self.context, 'window', None)
        current_screen = getattr(self.context, 'screen', None)
        current_area = getattr(self.context, 'area', None)
        if current_window and current_screen and current_area:
            fallback = (current_window, current_screen, current_area, 'current-area')
        for win in wm.windows:
            scr = win.screen
            for area in scr.areas:
                if area.type == 'TEXT_EDITOR':
                    if self._try_area(win, scr, area, 'text-editor'):
                        return self
                elif fallback is None and area.type in {'VIEW_3D', 'IMAGE_EDITOR'}:
                    fallback = (win, scr, area, f'{area.type.lower()}-fallback')
        if fallback is not None:
            win, scr, area, tag = fallback
            if self._repurpose_area(win, scr, area, tag):
                return self
        self._override_kwargs = None
        return self

    def __exit__(self, exc_type, exc, tb):
        try:
            for item in reversed(self._restore):
                if not item:
                    continue
                kind = item[0]
                if kind == 'AREA_TYPE':
                    _, area, old_type, old_ui_type = item
                    try:
                        area.type = old_type
                    except Exception:
                        pass
                    if old_ui_type is not None:
                        try:
                            area.ui_type = old_ui_type
                        except Exception:
                            pass
        except Exception:
            pass
        return False

    @property
    def kwargs(self):
        return self._override_kwargs


def _suv_operator_debug_name(op_fn) -> str:
    for attr in ('idname_py', 'idname'):
        member = getattr(op_fn, attr, None)
        if callable(member):
            try:
                value = member()
                if value:
                    return str(value)
            except Exception:
                pass
        elif member:
            return str(member)
    name = getattr(op_fn, '__name__', None)
    if name and name != '_BPyOpsSubModOp':
        return str(name)
    return str(op_fn)

def _suv_view3d_override_kwargs(context):
    # uv.project_from_view reads the 3D view's matrices, so it cannot run from a UV Editor context.
    window = getattr(context, 'window', None)
    screen = getattr(window, 'screen', None)
    for area in getattr(screen, 'areas', []) or []:
        if area.type != 'VIEW_3D':
            continue
        for region in area.regions:
            if region.type == 'WINDOW':
                return {'window': window, 'area': area, 'region': region}
    return None


def _suv_limit_mesh_selection_to_uv(context):
    """project_from_view and lightmap_pack only read the mesh selection, so without UV Sync
    hide the faces that are not UV-selected from them. Returns what the restore needs."""
    import bmesh
    if bool(getattr(context.tool_settings, 'use_uv_select_sync', False)):
        return []
    saved = []
    for obj in getattr(context, 'objects_in_mode_unique_data', None) or []:
        if obj.type != 'MESH':
            continue
        bm = bmesh.from_edit_mesh(obj.data)
        faces = [f for f in bm.faces if f.select and all(l.uv_select_vert for l in f.loops)]
        if not faces:
            continue
        saved.append((obj, [v.select for v in bm.verts], [e.select for e in bm.edges], [f.select for f in bm.faces]))
        for f in bm.faces:
            f.select_set(False)
        for f in faces:
            f.select_set(True)
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    return saved


def _suv_restore_mesh_selection(saved) -> None:
    import bmesh
    for obj, verts, edges, faces in saved:
        bm = bmesh.from_edit_mesh(obj.data)
        for item, value in zip(bm.verts, verts):
            item.select = value
        for item, value in zip(bm.edges, edges):
            item.select = value
        for item, value in zip(bm.faces, faces):
            item.select = value
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)


def _run_uv_weld_overlapping(context, threshold=0.01):
    # uv.weld moves every selected UV to one point; a cleanup step must only merge the ones that coincide.
    return _run_uv_op(context, bpy.ops.uv.remove_doubles, threshold=threshold)


def _run_uv_op(context, op_fn, *args, **kwargs):
    source = _suv_operator_debug_name(op_fn)
    created_uv = []
    with _PreserveContextState(context, restore_mode=True, restore_render_engine=False):
        try:
            ws = _suv_ws(context)
            created_uv = _suv_ensure_uv_maps_selected(context, getattr(ws, 'uv_new_name', 'UVMap_SUV') if ws else 'UVMap_SUV')
        except Exception as exc:
            _suv_log_exception(context, f'{source} | UV Preflight', exc)
            created_uv = []
        with _UVOverride(context) as ov:
            if not ov.kwargs:
                _suv_log_event(context, 'WARN', source, 'No UV Editor context available.', {
                    'created_uv_count': len(created_uv),
                    'created_uv': ', '.join(created_uv[:8]) if created_uv else '-',
                    'override_source': ov.area_source or '-',
                    'used_temp_area': ov.used_temp_area,
                })
                return False, tr(context, 'msg.need_uv_editor_ctx')
            if ov.used_temp_area or created_uv:
                _suv_log_event(context, 'INFO', source, 'Using guarded UV override execution.', {
                    'override_source': ov.area_source or '-',
                    'used_temp_area': ov.used_temp_area,
                    'created_uv_count': len(created_uv),
                    'created_uv': ', '.join(created_uv[:8]) if created_uv else '-',
                })
            try:
                view3d_kwargs = _suv_view3d_override_kwargs(context) if 'project_from_view' in str(source) else None
                limited = _suv_limit_mesh_selection_to_uv(context) if any(name in source for name in ('project_from_view', 'lightmap_pack')) else []
                try:
                    with context.temp_override(**(view3d_kwargs or ov.kwargs)):
                        op_fn(*args, **kwargs)
                finally:
                    _suv_restore_mesh_selection(limited)
                return True, None
            except Exception as e:
                detail = str(e)
                if created_uv:
                    detail += f" | auto-created UV: {', '.join(created_uv[:4])}"
                _suv_log_exception(context, source, e, {
                    'override_source': ov.area_source or '-',
                    'used_temp_area': ov.used_temp_area,
                    'created_uv_count': len(created_uv),
                    'created_uv': ', '.join(created_uv[:8]) if created_uv else '-',
                    'kwargs': kwargs,
                })
                return False, detail

# --- Smart Tools unified user_default path patch (2026-03-27) ---
def _smart_tools_manifest_extension_id(default: str = "") -> str:
    default = str(default or "").strip()
    try:
        current = os.path.dirname(os.path.abspath(__file__))
        while True:
            manifest = os.path.join(current, "blender_manifest.toml")
            if os.path.isfile(manifest):
                with open(manifest, "r", encoding="utf-8") as handle:
                    for raw_line in handle:
                        line = raw_line.strip()
                        if not line.startswith("id"):
                            continue
                        _, _, value = line.partition("=")
                        value = str(value or "").strip().strip('"').strip("'")
                        if value:
                            return value
                break
            parent = os.path.dirname(current)
            if parent == current:
                break
            current = parent
    except Exception:
        pass
    if ".user_default." in default or default.startswith("bl_ext."):
        default = default.rsplit(".", 1)[-1]
    if "." in default:
        head = default.split(".", 1)[0].strip()
        if head:
            default = head
    return default

def _smart_tools_version_user_default_root(package_id: str, create: bool = False) -> str:
    package_id = _smart_tools_manifest_extension_id(package_id)
    utils = getattr(bpy, "utils", None)
    if utils is not None:
        ext_fn = getattr(utils, "extension_path_user", None)
        if callable(ext_fn) and package_id:
            call_variants = (
                ((package_id,), {"path": "", "create": create}),
                ((package_id, ""), {"create": create}),
                ((package_id,), {"create": create}),
                ((), {"module": package_id, "path": "", "create": create}),
                ((), {"module": package_id, "create": create}),
            )
            for args, kwargs in call_variants:
                try:
                    value = ext_fn(*args, **kwargs)
                    if value:
                        return str(value)
                except TypeError:
                    continue
                except Exception:
                    continue
        user_resource = getattr(utils, "user_resource", None)
        if callable(user_resource) and package_id:
            config_dir = ""
            try:
                config_dir = user_resource("CONFIG", create=create) or ""
            except TypeError:
                try:
                    config_dir = user_resource("CONFIG") or ""
                except Exception:
                    config_dir = ""
            except Exception:
                config_dir = ""
            if config_dir:
                version_root = os.path.dirname(os.path.normpath(str(config_dir)))
                path = os.path.join(version_root, "extensions", "user_default", package_id)
                if create:
                    os.makedirs(path, exist_ok=True)
                return path
    fallback = os.path.join(os.path.expanduser("~"), ".config", "blender", "5.1", "extensions", "user_default", package_id or _smart_tools_manifest_extension_id(default=""))
    if create:
        os.makedirs(fallback, exist_ok=True)
    return fallback

def _smart_tools_suv_extension_user_root(create: bool = False) -> str:
    package_id = _smart_tools_manifest_extension_id(_suv_extension_id()) or 'uv_suite'
    return _smart_tools_version_user_default_root(package_id, create=create)

_suv_extension_user_root = _smart_tools_suv_extension_user_root

# --- Smart Tools user_default migration patch (2026-03-27) ---
def _smart_tools_manifest_dir() -> str:
    try:
        current = os.path.dirname(os.path.abspath(__file__))
        while True:
            if os.path.isfile(os.path.join(current, "blender_manifest.toml")):
                return current
            parent = os.path.dirname(current)
            if parent == current:
                break
            current = parent
    except Exception:
        pass
    return os.path.dirname(os.path.abspath(__file__))

def _smart_tools_has_visible_entries(path: str) -> bool:
    try:
        return any(name not in {".DS_Store", "Thumbs.db"} for name in os.listdir(path))
    except Exception:
        return False

def _smart_tools_merge_tree(src: str, dst: str) -> None:
    import shutil
    os.makedirs(dst, exist_ok=True)
    for name in os.listdir(src):
        if name in {".DS_Store", "Thumbs.db"}:
            continue
        src_path = os.path.join(src, name)
        dst_path = os.path.join(dst, name)
        if os.path.isdir(src_path):
            shutil.copytree(src_path, dst_path, dirs_exist_ok=True)
        elif os.path.isfile(src_path) and not os.path.exists(dst_path):
            os.makedirs(os.path.dirname(dst_path), exist_ok=True)
            shutil.copy2(src_path, dst_path)

def _smart_tools_version_user_default_root(package_id: str, create: bool = False) -> str:
    package_id = _smart_tools_manifest_extension_id(package_id)
    target_path = ""
    config_dir = ""
    scripts_dir = ""
    utils = getattr(bpy, "utils", None)
    if utils is not None:
        ext_fn = getattr(utils, "extension_path_user", None)
        if callable(ext_fn) and package_id:
            call_variants = (
                ((package_id,), {"path": "", "create": create}),
                ((package_id, ""), {"create": create}),
                ((package_id,), {"create": create}),
                ((), {"module": package_id, "path": "", "create": create}),
                ((), {"module": package_id, "create": create}),
            )
            for args, kwargs in call_variants:
                try:
                    value = ext_fn(*args, **kwargs)
                    if value:
                        target_path = str(value)
                        break
                except TypeError:
                    continue
                except Exception:
                    continue
        user_resource = getattr(utils, "user_resource", None)
        if callable(user_resource):
            try:
                config_dir = str(user_resource("CONFIG", create=create) or "")
            except TypeError:
                try:
                    config_dir = str(user_resource("CONFIG") or "")
                except Exception:
                    config_dir = ""
            except Exception:
                config_dir = ""
            try:
                scripts_dir = str(user_resource("SCRIPTS", create=create) or "")
            except TypeError:
                try:
                    scripts_dir = str(user_resource("SCRIPTS") or "")
                except Exception:
                    scripts_dir = ""
            except Exception:
                scripts_dir = ""
    if not target_path and config_dir:
        version_root = os.path.dirname(os.path.normpath(config_dir))
        target_path = os.path.join(version_root, "extensions", "user_default", package_id)
    if not target_path:
        target_path = os.path.join(os.path.expanduser("~"), ".config", "blender", "5.1", "extensions", "user_default", package_id or _smart_tools_manifest_extension_id(default=""))

    legacy_candidates = []
    if scripts_dir and package_id:
        legacy_candidates.append(os.path.join(scripts_dir, "extensions", "user_default", package_id))
        legacy_candidates.append(os.path.join(scripts_dir, "extensions_user", package_id))
    if config_dir and package_id:
        legacy_candidates.append(os.path.join(os.path.normpath(config_dir), "extensions", "user_default", package_id))
    manifest_dir = _smart_tools_manifest_dir()
    if package_id:
        legacy_candidates.append(os.path.join(manifest_dir, "user_default", package_id))

    if create:
        os.makedirs(target_path, exist_ok=True)

    target_norm = os.path.normcase(os.path.normpath(target_path))
    if not _smart_tools_has_visible_entries(target_path):
        for legacy in legacy_candidates:
            if not legacy:
                continue
            legacy_norm = os.path.normcase(os.path.normpath(legacy))
            if legacy_norm == target_norm:
                continue
            if _smart_tools_has_visible_entries(legacy):
                try:
                    _smart_tools_merge_tree(legacy, target_path)
                except Exception:
                    pass
                break
    return target_path

# --- UV Suite unified user_default storage override (2026-04-20) ---
def _smart_tools_version_user_default_root(package_id: str, create: bool = False) -> str:
    package_id = _smart_tools_manifest_extension_id(package_id) or 'uv_suite'
    try:
        from . import storage as _storage
        return str(_storage.extension_user_root(package_id, create=False))
    except Exception:
        return _suv_package_root()


def _smart_tools_suv_extension_user_root(create: bool = False) -> str:
    package_id = _smart_tools_manifest_extension_id(_suv_extension_id()) or 'uv_suite'
    return _smart_tools_version_user_default_root(package_id, create=create)


_suv_extension_user_root = _smart_tools_suv_extension_user_root
