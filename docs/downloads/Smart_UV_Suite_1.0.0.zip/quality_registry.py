from __future__ import annotations
from . import resource_api_18168 as _suv_resource

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None

_NAMESPACE = {}
_REGISTERED = []


def _tr(context, key: str, en: str, ja: str, **fmt) -> str:
    fn = _NAMESPACE.get('tr')
    text = None
    if callable(fn):
        try:
            text = fn(context, key, **fmt)
        except Exception:
            text = None
    if not text:
        text = en
    try:
        return text.format(**fmt)
    except Exception:
        return text


def _text_name(context) -> str:
    ws_fn = _NAMESPACE.get('_suv_ws')
    ws = ws_fn(context) if callable(ws_fn) else None
    name = getattr(ws, 'support_bundle_name', '') if ws else ''
    return (str(name).strip() or 'SUV_Support_Bundle') + '_Report_Registry'


def _suv_registry_name(context):
    return _text_name(context)


def _text_block(name: str, clear=False):
    textio = _NAMESPACE.get('_quality_textio_module')
    if textio is not None and hasattr(textio, 'ensure_report_text'):
        try:
            return textio.ensure_report_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if textio is not None and hasattr(textio, 'ensure_namespace_text'):
        try:
            return textio.ensure_namespace_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if bpy is None:
        return None
    txt = bpy.data.texts.get(name)
    if txt is None:
        if not clear:
            return None
        txt = bpy.data.texts.new(name)
    elif clear:
        txt.clear()
    return txt


def _helper_count_keys() -> list[tuple[str, str]]:
    return [
        ('housekeeping', '_suv_quality_housekeeping_registered'),
        ('context', '_suv_quality_context_registered'),
        ('audit', '_suv_quality_audit_registered'),
        ('matrix', '_suv_quality_matrix_registered'),
        ('catalog', '_suv_quality_catalog_registered'),
        ('help', '_suv_quality_help_registered'),
        ('language', '_suv_quality_language_registered'),
        ('reports', '_suv_quality_reports_registered'),
        ('playbook', '_suv_quality_playbook_registered'),
        ('profiles', '_suv_quality_profiles_registered'),
        ('registry', '_suv_quality_registry_registered'),
        ('doctor', '_suv_quality_doctor_registered'),
        ('ui_map', '_suv_quality_ui_map_registered'),
        ('state', '_suv_quality_state_registered'),
        ('focus', '_suv_quality_focus_registered'),
        ('density', '_suv_quality_density_registered'),
        ('sections', '_suv_quality_sections_registered'),
        ('presets', '_suv_quality_presets_registered'),
        ('sync', '_suv_quality_sync_registered'),
        ('controls', '_suv_quality_controls_registered'),
        ('controls_report', '_suv_quality_controls_report_registered'),
    ]


def _report_rows(context):
    module_specs = [
        ('audit', 'Quality Audit', '品質監査', '_quality_audit_module'),
        ('matrix', 'Feature Matrix', '機能マトリクス', '_quality_matrix_module'),
        ('language', 'Language Coverage', '言語対応レポート', '_quality_language_module'),
        ('guided_help', 'Guided Help', 'ガイドヘルプ', '_quality_help_module'),
        ('ui_map', 'Visual UI Map', '視覚UIマップ', '_quality_ui_map_module'),
        ('catalog', 'Operator Catalog', 'オペレーターカタログ', '_quality_catalog_module'),
        ('playbook', 'Task Playbook', 'タスク別プレイブック', '_quality_playbook_module'),
        ('profiles', 'Execution Profiles', '実行プロファイル', '_quality_profiles_module'),
        ('hub', 'Report Hub', 'レポートハブ', '_quality_reports_module'),
        ('registry', 'Report Registry', 'レポートレジストリ', '_quality_registry_module'),
        ('doctor', 'Quality Doctor', '品質ドクター', '_quality_doctor_module'),
        ('controls', 'Visual Controls Report', '視覚コントロールレポート', '_quality_controls_report_module'),
    ]
    rows = []
    for key, title_en, title_ja, mod_key in module_specs:
        name = ''
        mod = _NAMESPACE.get(mod_key)
        if key == 'hub':
            fn = _NAMESPACE.get('_suv_report_hub_name')
            if callable(fn):
                try:
                    name = str(fn(context) or '')
                except Exception:
                    name = ''
        elif key == 'playbook':
            fn = _NAMESPACE.get('_suv_playbook_name')
            if callable(fn):
                try:
                    name = str(fn(context) or '')
                except Exception:
                    name = ''
        elif key == 'profiles':
            fn = _NAMESPACE.get('_suv_profile_report_name')
            if callable(fn):
                try:
                    name = str(fn(context) or '')
                except Exception:
                    name = ''
        elif key == 'registry':
            name = _text_name(context)
        elif key == 'controls':
            fn = _NAMESPACE.get('_suv_controls_report_name')
            if callable(fn):
                try:
                    name = str(fn(context) or '')
                except Exception:
                    name = ''
        elif key == 'ui_map':
            fn = _NAMESPACE.get('_suv_ui_map_name')
            if callable(fn):
                try:
                    name = str(fn(context) or '')
                except Exception:
                    name = ''
        elif mod is not None and hasattr(mod, '_text_name'):
            try:
                name = str(getattr(mod, '_text_name')(context) or '')
            except Exception:
                name = ''
        exists = bool(bpy is not None and name and bpy.data.texts.get(name) is not None)
        rows.append({
            'key': key,
            'title_en': title_en,
            'title_ja': title_ja,
            'name': name,
            'exists': exists,
        })
    return rows


def scan_report_registry(context) -> dict:
    rows = _report_rows(context)
    existing_texts = sum(1 for row in rows if row['exists'])
    helper_rows = []
    helper_total = 0
    helper_registered = 0
    for label, key in _helper_count_keys():
        helper_total += 1
        count = int(_NAMESPACE.get(key, 0) or 0)
        active = bool(count > 0)
        if active:
            helper_registered += 1
        helper_rows.append({'label': label, 'count': count, 'active': active, 'key': key})
    data = {
        'total_texts': len(rows),
        'existing_texts': existing_texts,
        'missing_texts': max(0, len(rows) - existing_texts),
        'rows': rows,
        'helper_total': helper_total,
        'helper_registered': helper_registered,
        'helper_rows': helper_rows,
    }
    _NAMESPACE['_suv_report_registry_last'] = data
    return data


class SUV_OT_quality_write_report_registry(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_write_report_registry'
    bl_label = 'Write Report Registry'
    bl_description = 'Write a compact registry that lists generated report texts and registered quality helpers so you can manage report-side assets from one place. / 生成済みレポートテキストと登録済み品質ヘルパーを一覧化したレジストリを書き出し、レポート系資産を一か所から管理しやすくします。'
    bl_options = set()

    open_after_write: bpy.props.BoolProperty(
        name='Open After Write',
        description='Open the written report registry in Blender Text Editor when possible / 可能なら書き出したレポートレジストリを Blender テキストエディタで開きます',
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        data = scan_report_registry(context)
        txt = None
        lines = [
            'UV Suite Report Registry',
            '',
            '[Summary]',
            f"Report texts: {data['existing_texts']}/{data['total_texts']}",
            f"Registered helper groups: {data['helper_registered']}/{data['helper_total']}",
            '',
            '[Report texts]',
        ]
        for row in data['rows']:
            state = 'ready' if row['exists'] else 'missing'
            lines.append(f"- {row['title_en']} [{state}]")
            lines.append(f"  name: {row['name'] or '-'}")
        lines.extend(['', '[Helper registration]'])
        for row in data['helper_rows']:
            lines.append(f"- {row['label']}: {'active' if row['active'] else 'inactive'} ({row['count']})")
        lines.extend([
            '',
            '[日本語メモ]',
            f"レポートテキスト: {data['existing_texts']}/{data['total_texts']}",
            f"登録済みヘルパー群: {data['helper_registered']}/{data['helper_total']}",
            'レポートが増えて整理しづらいときは、このレジストリを先に開くと管理しやすいです。',
        ])
        textio = _NAMESPACE.get('_quality_textio_module')
        writer = getattr(textio, 'write_report_lines_consistent', None) if textio is not None else None
        if callable(writer):
            txt = writer(
                _NAMESPACE, context, _text_name, lines, _text_block, self,
                open_after_write=self.open_after_write,
                failed_key='msg.quality_registry_open_failed',
                failed_en='Could not open report registry: {name}',
                failed_ja='レポートレジストリを開けませんでした: {name}',
            )
            if txt is None:
                return {'CANCELLED'}
        else:
            txt = _text_block(_text_name(context), clear=True)
            if txt is None:
                return {'CANCELLED'}
            if textio is not None and hasattr(textio, 'write_text_lines'):
                if textio.write_text_lines(txt, lines) is None:
                    return {'CANCELLED'}
            else:
                txt.write('\n'.join(lines))
            if self.open_after_write and textio is not None and hasattr(textio, 'open_written_text'):
                textio.open_written_text(
                    _NAMESPACE, context, txt, self,
                    failed_key='msg.quality_registry_open_failed',
                    failed_en='Could not open report registry: {name}',
                    failed_ja='レポートレジストリを開けませんでした: {name}',
                )
        self.report({'INFO'}, _tr(context, 'msg.quality_registry_written', 'Report registry written: {name} ({existing}/{total} texts ready)', 'レポートレジストリを書き出しました: {name}（利用可能 {existing}/{total}）', name=txt.name, existing=data['existing_texts'], total=data['total_texts']))
        return {'FINISHED'}


class SUV_OT_quality_open_report_registry(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_open_report_registry'
    bl_label = 'Open Report Registry'
    bl_description = 'Open the latest UV Suite report registry in Blender Text Editor. / 最新の UV Suite レポートレジストリを Blender のテキストエディタで開きます。'
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        textio = _NAMESPACE.get('_quality_textio_module')
        if textio is not None and hasattr(textio, 'open_named_report_text_or_fallback'):
            return textio.open_named_report_text_or_fallback(
                _NAMESPACE, context, _text_name, self, _text_block,
                missing_key='msg.quality_registry_missing',
                missing_en='No report registry exists yet.',
                missing_ja='レポートレジストリはまだ作成されていません。',
                opened_key='msg.quality_registry_opened',
                opened_en='Opened report registry: {name}',
                opened_ja='レポートレジストリを開きました: {name}',
            )
        txt = _text_block(_text_name(context), clear=False)
        if txt is None:
            self.report({'WARNING'}, _tr(context, 'msg.quality_registry_missing', 'No report registry exists yet.', 'レポートレジストリはまだ作成されていません。'))
            return {'CANCELLED'}
        opener = _NAMESPACE.get('_suv_open_text_in_editor')
        ok = False
        if callable(opener):
            try:
                ok, _err = opener(context, txt)
            except Exception:
                ok = False
        if not ok:
            self.report({'WARNING'}, _tr(context, 'msg.quality_registry_open_failed', 'Could not open report registry: {name}', 'レポートレジストリを開けませんでした: {name}', name=txt.name))
            return {'CANCELLED'}
        self.report({'INFO'}, _tr(context, 'msg.quality_registry_opened', 'Opened report registry: {name}', 'レポートレジストリを開きました: {name}', name=txt.name))
        return {'FINISHED'}


def register(namespace: dict):
    global _NAMESPACE
    _NAMESPACE = namespace if isinstance(namespace, dict) else {}
    if bpy is None:
        return []
    classes = [SUV_OT_quality_write_report_registry, SUV_OT_quality_open_report_registry]
    reg = []
    for cls in classes:
        try:
            _suv_resource.register_class(cls)
            reg.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = reg
    return reg


def unregister(namespace: dict | None = None):
    if bpy is None:
        return []
    removed = []
    for cls in reversed(list(_REGISTERED)):
        try:
            _suv_resource.unregister_class(cls)
            removed.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = []
    return removed
