# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Blender Extension namespace recovery for Smart UV Suite 1.8.143.

A failed or malformed installation can leave ``bl_ext.<repo>.smart_uv_suite``
in ``sys.modules`` as a namespace package with no ``__file__``. Blender then
keeps returning that cached namespace module even after a correct ``__init__.py``
has been extracted. This module removes only those file-less legacy cache entries.
"""
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

import importlib
import sys
_TIMER_REGISTERED = False
_CURRENT_PACKAGE = ''


def _legacy_candidates(current_package: str) -> tuple[str, ...]:
    current = str(current_package or '').strip('.')
    repo_prefix = current.rpartition('.')[0]
    values = []
    for value in (
        f'{repo_prefix}.smart_uv_suite' if repo_prefix else 'smart_uv_suite',
        f'{repo_prefix}.smart_uv_suite_addon' if repo_prefix else 'smart_uv_suite_addon',
        f'{repo_prefix}.smart_uv_suite_jelararagi' if repo_prefix else 'smart_uv_suite_jelararagi',
        'bl_ext.user_default.smart_uv_suite',
        'bl_ext.system.smart_uv_suite',
        'bl_ext.user_default.smart_uv_suite_addon',
        'bl_ext.system.smart_uv_suite_addon',
        'bl_ext.user_default.smart_uv_suite_jelararagi',
        'bl_ext.system.smart_uv_suite_jelararagi',
        'smart_uv_suite',
        'smart_uv_suite_addon',
        'smart_uv_suite_jelararagi',
        'uv_suite',
    ):
        value = str(value or '').strip('.')
        if value and value != current and value not in values:
            values.append(value)
    return tuple(values)


def _is_fileless_namespace(module: object) -> bool:
    if module is None:
        return False
    try:
        if getattr(module, '__file__', None) is not None:
            return False
    except Exception:
        return False
    try:
        path = getattr(module, '__path__', None)
    except Exception:
        path = None
    return path is not None



def cleanup_stale_namespace_modules(current_package: str) -> tuple[str, ...]:
    del current_package
    return ()




def prepare_legacy_addons(current_package: str) -> tuple[str, ...]:
    del current_package
    return ()


def _cleanup_stale_preferences_timer():
    global _TIMER_REGISTERED
    _TIMER_REGISTERED = False
    return None



def register(current_package: str) -> None:
    global _CURRENT_PACKAGE, _TIMER_REGISTERED
    _CURRENT_PACKAGE = str(current_package or '')
    _TIMER_REGISTERED = False
    return None



def unregister() -> None:
    global _TIMER_REGISTERED
    _TIMER_REGISTERED = False
    return None
