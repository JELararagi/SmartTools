# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Guards that prevent Smart UV Suite load/save maintenance from changing object transforms.

The add-on has several persistence handlers for UI state, language settings and
workspace visibility.  Those handlers must never modify scene object transforms.
This module snapshots object transform state around such maintenance code and
restores it before returning control to Blender.
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover - Blender-only module
    bpy = None  # type: ignore


_TRANSFORM_KEYS = (
    'location',
    'rotation_mode',
    'rotation_euler',
    'rotation_quaternion',
    'rotation_axis_angle',
    'scale',
    'matrix_basis',
    'matrix_parent_inverse',
)

_STALE_TRANSFORM_PROPS = (
    '_suv_bake_origin',
    '_suv_bake_origin_matrix',
    '_suv_bake_origin_rotation',
    '_suv_bake_origin_scale',
)


def _copy_value(value: Any) -> Any:
    try:
        return value.copy()
    except Exception:
        try:
            return tuple(value)
        except Exception:
            return value


def _snapshot_object(obj) -> dict[str, Any] | None:
    if obj is None:
        return None
    data: dict[str, Any] = {'object': obj}
    try:
        data['name'] = str(getattr(obj, 'name_full', getattr(obj, 'name', '')) or '')
    except Exception:
        data['name'] = ''
    for key in _TRANSFORM_KEYS:
        try:
            data[key] = _copy_value(getattr(obj, key))
        except Exception:
            pass
    return data


def _values_equal(a: Any, b: Any, *, eps: float = 1.0e-8) -> bool:
    try:
        seq_a = list(a)
        seq_b = list(b)
        if len(seq_a) != len(seq_b):
            return False
        return all(abs(float(x) - float(y)) <= eps for x, y in zip(seq_a, seq_b))
    except Exception:
        try:
            return bool(a == b)
        except Exception:
            return False


def _safe_set(obj, key: str, value: Any) -> bool:
    try:
        current = getattr(obj, key)
        if _values_equal(current, value):
            return False
    except Exception:
        pass
    try:
        setattr(obj, key, value)
        return True
    except Exception:
        return False


def _restore_object(snapshot: dict[str, Any]) -> bool:
    obj = snapshot.get('object')
    if obj is None:
        return False
    try:
        _ = obj.name
    except Exception:
        return False
    changed = False
    # Restore mode first so Quaternion/Euler/Axis Angle component assignment is stable.
    if 'rotation_mode' in snapshot:
        changed = _safe_set(obj, 'rotation_mode', snapshot['rotation_mode']) or changed
    # Parent inverse first, then basis; local components are fallback for objects
    # where matrix assignment is restricted.
    if 'matrix_parent_inverse' in snapshot:
        changed = _safe_set(obj, 'matrix_parent_inverse', snapshot['matrix_parent_inverse']) or changed
    if 'matrix_basis' in snapshot:
        if _safe_set(obj, 'matrix_basis', snapshot['matrix_basis']):
            changed = True
            return changed
    for key in ('location', 'rotation_euler', 'rotation_quaternion', 'rotation_axis_angle', 'scale'):
        if key in snapshot:
            changed = _safe_set(obj, key, snapshot[key]) or changed
    return changed


def snapshot_scene_object_transforms() -> list[dict[str, Any]]:
    if bpy is None:
        return []
    out: list[dict[str, Any]] = []
    try:
        objects = list(getattr(getattr(bpy, 'data', None), 'objects', []) or [])
    except Exception:
        objects = []
    for obj in objects:
        snap = _snapshot_object(obj)
        if snap:
            out.append(snap)
    return out


def restore_scene_object_transforms(snapshots: list[dict[str, Any]] | tuple[dict[str, Any], ...]) -> int:
    restored = 0
    for snap in snapshots or []:
        try:
            if _restore_object(snap):
                restored += 1
        except Exception:
            pass
    return restored


@contextmanager
def preserve_scene_object_transforms():
    snapshots = snapshot_scene_object_transforms()
    try:
        yield
    finally:
        restore_scene_object_transforms(snapshots)


def remove_stale_smart_uv_transform_markers() -> int:
    """Remove saved temporary transform markers without moving any object."""
    if bpy is None:
        return 0
    removed = 0
    try:
        objects = list(getattr(getattr(bpy, 'data', None), 'objects', []) or [])
    except Exception:
        objects = []
    for obj in objects:
        for key in _STALE_TRANSFORM_PROPS:
            try:
                if key in obj:
                    del obj[key]
                    removed += 1
            except Exception:
                pass
    return removed


def run_without_transform_side_effects(fn, *args, cleanup_stale_markers: bool = False, **kwargs):
    with preserve_scene_object_transforms():
        result = fn(*args, **kwargs)
        if cleanup_stale_markers:
            remove_stale_smart_uv_transform_markers()
        return result

try:
    from bpy.app.handlers import persistent  # type: ignore
except Exception:  # pragma: no cover
    def persistent(fn):  # type: ignore
        return fn


@persistent
def _smart_uv_transform_guard_load_post(_dummy=None):
    try:
        with preserve_scene_object_transforms():
            remove_stale_smart_uv_transform_markers()
    except Exception:
        pass


@persistent
def _smart_uv_transform_guard_save_pre(_dummy=None):
    try:
        with preserve_scene_object_transforms():
            remove_stale_smart_uv_transform_markers()
    except Exception:
        pass


def _append_once(collection, fn) -> None:
    try:
        if fn not in collection:
            collection.append(fn)
    except Exception:
        pass


def _remove_all(collection, fn) -> None:
    try:
        while fn in collection:
            collection.remove(fn)
    except Exception:
        pass


def register_handlers() -> None:
    if bpy is None:
        return
    try:
        from . import npanel_persistence as _npanel_store
        if not bool(_npanel_store.get_always_on('TRANSFORM_PERSISTENCE_GUARD', False)):
            unregister_handlers()
            return
    except Exception:
        unregister_handlers()
        return
    try:
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        if handlers is None:
            return
        _append_once(handlers.load_post, _smart_uv_transform_guard_load_post)
        _append_once(handlers.save_pre, _smart_uv_transform_guard_save_pre)
    except Exception:
        pass


def unregister_handlers() -> None:
    if bpy is None:
        return
    try:
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        if handlers is None:
            return
        _remove_all(handlers.load_post, _smart_uv_transform_guard_load_post)
        _remove_all(handlers.save_pre, _smart_uv_transform_guard_save_pre)
    except Exception:
        pass
