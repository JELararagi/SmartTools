"""Implement the inspect stage public UV operations."""

import bpy


def inspect_stage_select(context, op):
    return 'FINISHED' in bpy.ops.uv.suv_native_stage_select(mode=op.mode or 'SELECT_ZERO')


def inspect_stage_workflow(context, op):
    return 'FINISHED' in bpy.ops.uv.suv_native_stage_workflow(mode=op.mode or 'UNWRAP_SELECTED')


def clear_generated_uv_meshes(context, op):
    if context.mode != 'OBJECT':
        return False
    targets = [obj for obj in context.selected_editable_objects
               if obj.type == 'MESH' and obj.get('suv_source_object')
               and obj.get('suv_uv_mesh_kind') in {'LAYOUT', 'PATTERN'}]
    for obj in targets:
        bpy.data.objects.remove(obj, do_unlink=True)
    return bool(targets)


def build_handlers(api):
    return {
        "smart_uv_suite.island_uvmesh_control": api.Handler(
            api._run_uv_layout("suv_native_stage_mesh", namespace="mesh", defaults={"mode": "UV_MESH"}),
            "Create a planar mesh from the active UV layout.",
            "アクティブUVレイアウトから平面メッシュを作成します。"),
        "smart_uv_suite.island_uvmesh_clear": api.Handler(
            clear_generated_uv_meshes,
            "Remove selected generated UV meshes in Object Mode.",
            "オブジェクトモードで選択中の生成UVメッシュを削除します。"),

        "smart_uv_suite.inspect_stage_select": api.Handler(inspect_stage_select, 'Select islands by the requested inspection criterion.', '指定した検査条件でUVアイランドを選択します。'),

        "smart_uv_suite.inspect_stage_workflow": api.Handler(inspect_stage_workflow, 'Run the chosen core UV workflow step.', '指定した標準UVワークフロー工程を実行します。'),
        "smart_uv_suite.inspect_stage_mesh": api.Handler(
            api._run_uv_layout("suv_native_stage_mesh", namespace="mesh", mode="mode",
                               pattern_cols="columns", pattern_rows="rows"),
            "Run the chosen mesh support tool.",
            "指定したメッシュ補助ツールを実行します。"),

    }
