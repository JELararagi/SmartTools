# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None

_NAMESPACE = {}
_REGISTERED = []
_PROP = 'suv_quality_focus_override'
_FOCUS_ITEMS = (
    ('AUTO', 'Auto', 'Choose the best focus mode from the current context / 現在の状況から最適なフォーカス表示を自動選択します'),
    ('SETUP', 'Setup', 'Show setup-first cards such as context checks and preparation / コンテキスト確認や準備を優先して表示します'),
    ('REPAIR', 'Repair', 'Show repair and recovery cards first / 修復と復旧を優先して表示します'),
    ('COVERAGE', 'Calc Coverage', 'Show feature coverage, help, and comparison cards first / 対応範囲やガイドを優先して表示します'),
    ('ANALYZE', 'Analyze', 'Show analysis, reports, and maintenance cards first / 分析・レポート・保守を優先して表示します'),
    ('ALL', 'All', 'Show every section without focus filtering / すべてのセクションを絞り込みなしで表示します'),
)


def _tr(context, key: str, en: str, ja: str, **fmt) -> str:
    fn = _NAMESPACE.get('tr')
    text = None
    if callable(fn):
        try:
            text = fn(context, key, **fmt)
        except Exception:
            text = None
    if not text:
        text = en
    try:
        return text.format(**fmt)
    except Exception:
        return text


def _wm(context):
    try:
        return getattr(context, 'window_manager', None)
    except Exception:
        return None


def _norm(value: str) -> str:
    value = str(value or 'AUTO').strip().upper()
    return value if value in {'AUTO', 'SETUP', 'REPAIR', 'COVERAGE', 'ANALYZE', 'ALL'} else 'AUTO'


def get_focus_override(context) -> str:
    wm = _wm(context)
    if wm is None:
        return 'AUTO'
    try:
        return _norm(getattr(wm, _PROP, 'AUTO'))
    except Exception:
        return 'AUTO'


def set_focus_override(context, mode: str) -> str:
    wm = _wm(context)
    mode = _norm(mode)
    if wm is not None:
        try:
            setattr(wm, _PROP, mode)
        except Exception:
            pass
    return mode


def effective_focus_mode(namespace: dict, context, auto_mode: str) -> str:
    override = get_focus_override(context)
    if override == 'AUTO':
        return str(auto_mode or 'all')
    return override.lower()


def scan_focus_control(namespace: dict, context) -> dict:
    override = get_focus_override(context)
    data = {
        'override': override,
        'manual': override != 'AUTO',
        'effective': override.lower() if override != 'AUTO' else 'auto',
        'available_modes': 6,
    }
    namespace['_suv_focus_control_last'] = dict(data)
    return data


class SUV_OT_quality_set_focus_mode(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_set_focus_mode'
    bl_label = 'Set Focus Mode'
    bl_description = 'Switch the quick visual guide focus mode so only the most relevant card groups stay visible. / クイック視覚ガイドのフォーカス表示を切り替え、今必要なカード群だけを見やすくします。'
    bl_options = {'UNDO'}

    mode: bpy.props.EnumProperty(
        name='Focus Mode',
        description='Choose how the quick visual guide should be filtered / クイック視覚ガイドの絞り込み方法を選びます',
        items=_FOCUS_ITEMS,
        default='AUTO',
    )

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        mode = set_focus_override(context, self.mode)
        controls_mod = _NAMESPACE.get('_quality_controls_module')
        if controls_mod is not None and hasattr(controls_mod, 'notify_controls_changed'):
            try:
                controls_mod.notify_controls_changed(_NAMESPACE, context, reason='focus')
            except Exception:
                pass
        self.report({'INFO'}, _tr(context, 'msg.quality_focus_set', 'Focus mode set to {mode}.', 'フォーカス表示を {mode} に切り替えました。', mode=mode))
        return {'FINISHED'}


class SUV_OT_quality_cycle_focus_mode(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_cycle_focus_mode'
    bl_label = 'Cycle Focus Mode'
    bl_description = 'Cycle through the quick visual guide focus modes. / クイック視覚ガイドのフォーカス表示を順番に切り替えます。'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        order = ['AUTO', 'SETUP', 'REPAIR', 'COVERAGE', 'ANALYZE', 'ALL']
        current = get_focus_override(context)
        try:
            idx = order.index(current)
        except ValueError:
            idx = 0
        mode = order[(idx + 1) % len(order)]
        set_focus_override(context, mode)
        controls_mod = _NAMESPACE.get('_quality_controls_module')
        if controls_mod is not None and hasattr(controls_mod, 'notify_controls_changed'):
            try:
                controls_mod.notify_controls_changed(_NAMESPACE, context, reason='focus-cycle')
            except Exception:
                pass
        else:
            clear = _NAMESPACE.get('clear_quality_state_cache')
            if callable(clear):
                try:
                    clear(_NAMESPACE)
                except Exception:
                    pass
        self.report({'INFO'}, _tr(context, 'msg.quality_focus_set', 'Focus mode set to {mode}.', 'フォーカス表示を {mode} に切り替えました。', mode=mode))
        return {'FINISHED'}


def register(namespace: dict):
    global _NAMESPACE
    _NAMESPACE = namespace if isinstance(namespace, dict) else {}
    if bpy is None:
        return []
    classes = [SUV_OT_quality_set_focus_mode, SUV_OT_quality_cycle_focus_mode]
    reg = []
    for cls in classes:
        try:
            _suv_resource.register_class(cls)
            reg.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = reg
    try:
        if not hasattr(bpy.types.WindowManager, _PROP):
            _suv_resource.register_property(
                bpy.types.WindowManager,
                _PROP,
                bpy.props.EnumProperty(
                    name='Focus Mode',
                    description='Quick visual guide focus override / クイック視覚ガイドのフォーカス表示上書き',
                    items=_FOCUS_ITEMS,
                    default='AUTO',
                )
            )
    except Exception:
        pass
    return reg


def unregister(namespace: dict | None = None):
    if bpy is None:
        return []
    removed = []
    for cls in reversed(list(_REGISTERED)):
        try:
            _suv_resource.unregister_class(cls)
            removed.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = []
    try:
        _suv_resource.unregister_property(bpy.types.WindowManager, _PROP)
    except Exception:
        pass
    return removed
