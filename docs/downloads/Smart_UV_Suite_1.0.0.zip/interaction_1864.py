# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Immediate Select native transform handoff final layer.

This layer intentionally changes only the interaction handoff policy:
- On a real UV element PRESS, select immediately and keep the press.
- If the mouse is released without dragging, only the selection remains.
- If the mouse moves past a small threshold while still pressed, start Blender's
  native transform.translate once and then finish this helper operator.
- Background presses are PASS_THROUGH immediately, so box-select and ordinary
  selection tools are unaffected.
- Selected-element presses are PASS_THROUGH so native gizmos/tweak/move keep
  their standard behavior.

The direct UV transform code used by older layers is not used here.  Snap,
release commit, undo, and axis constraints are delegated to Blender's native
Transform operator.
"""
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

import time
from typing import Any

import bpy
from mathutils import Vector

_PG: dict[str, Any] | None = None
_VERSION = (1, 8, 64)

_INSTANT_ID = "smart_uv_suite.instant_select_drag_move"
_GIZMO_ID = "smart_uv_suite.uv_gizmo_grip_fix_grab"
_NATIVE_GIZMO_ID = ""

# Keep this UV/Image-only.  Do not register in Window or Generic Gizmo maps.
# Those maps delay background drags and steal native gizmo hover.
_INSTANT_KEYMAP_DEFS = (
    ("UV Editor", "EMPTY"),
    ("Image", "IMAGE_EDITOR"),
    ("Image Generic", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Tweak", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Tweak (fallback)", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Move", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Move (fallback)", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Select Box", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Select Box (fallback)", "IMAGE_EDITOR"),
)
_FORBIDDEN_INSTANT_MAPS = (
    "Window",
    "Generic Gizmo",
    "Generic Gizmo Drag",
    "Generic Gizmo Click Drag",
    "Generic Gizmo Maybe Drag",
    "Generic Gizmo Select",
)
_NATIVE_GIZMO_KEYMAP_NAMES = (
    "Generic Gizmo",
    "Generic Gizmo Drag",
    "Generic Gizmo Click Drag",
    "Generic Gizmo Maybe Drag",
    "Generic Gizmo Select",
)
_LAST_PRESS = {"area": 0, "region": 0, "x": 0, "y": 0, "t": 0.0}


def _pg(name: str, default=None):
    try:
        return _PG.get(name, default) if isinstance(_PG, dict) else default
    except Exception:
        return default


def _is_uv_context(context) -> bool:
    try:
        area = getattr(context, "area", None)
        region = getattr(context, "region", None)
        space = getattr(context, "space_data", None)
        if area is None or str(getattr(area, "type", "")) != "IMAGE_EDITOR":
            return False
        if region is None or str(getattr(region, "type", "")) != "WINDOW":
            return False
        if space is None:
            return False
        ui_type = str(getattr(space, "ui_type", "") or "").upper()
        mode = str(getattr(space, "mode", "") or "").upper()
        return ui_type in {"UV", "UV_EDITOR"} or mode in {"UV", "UV_EDITOR"}
    except Exception:
        return False


def _region_to_uv(context, event):
    try:
        x, y = context.region.view2d.region_to_view(float(event.mouse_region_x), float(event.mouse_region_y))
        return Vector((float(x), float(y)))
    except Exception:
        try:
            from . import interaction_1844 as _i44
            fn = getattr(_i44, "_region_to_uv", None)
            return fn(context, event) if callable(fn) else None
        except Exception:
            return None


def _instant_enabled(context) -> bool:
    try:
        fn = _pg("_sus_1635_immediate_enabled")
        if callable(fn):
            return bool(fn(context))
    except Exception:
        pass
    try:
        ws_fn = _pg("_sus_1652_ws")
        ws = ws_fn(context) if callable(ws_fn) else getattr(getattr(context, "scene", None), "suv_workspace", None)
        return bool(getattr(ws, "operation_instant_select_enabled", False))
    except Exception:
        return False


def _axis_enabled(context) -> bool:
    try:
        fn = _pg("_sus_1636_axis_enabled")
        if callable(fn):
            return bool(fn(context))
    except Exception:
        pass
    try:
        ws_fn = _pg("_sus_1652_ws")
        ws = ws_fn(context) if callable(ws_fn) else getattr(getattr(context, "scene", None), "suv_workspace", None)
        return bool(getattr(ws, "operation_axis_constraint_memory_enabled", False))
    except Exception:
        return False


def _get_axis(context) -> str:
    try:
        fn = _pg("_sus_1636_get_axis")
        if callable(fn):
            axis = str(fn(context) or "FREE").upper()
            return axis if axis in {"U", "V", "FREE"} else "FREE"
    except Exception:
        pass
    try:
        axis = str(_PG.get("_SUS_1636_MEMORY_AXIS", "FREE") if isinstance(_PG, dict) else "FREE").upper()
        return axis if axis in {"U", "V", "FREE"} else "FREE"
    except Exception:
        return "FREE"


def _event_duplicate(context, event) -> bool:
    """Skip duplicate operator hits from multiple Image/UV keymaps for one PRESS."""
    try:
        now = time.monotonic()
        area = id(getattr(context, "area", None))
        region = id(getattr(context, "region", None))
        x = int(getattr(event, "mouse_region_x", 0) or 0)
        y = int(getattr(event, "mouse_region_y", 0) or 0)
        if (_LAST_PRESS["area"] == area and _LAST_PRESS["region"] == region and
                _LAST_PRESS["x"] == x and _LAST_PRESS["y"] == y and
                now - float(_LAST_PRESS.get("t") or 0.0) < 0.035):
            return True
        _LAST_PRESS.update({"area": area, "region": region, "x": x, "y": y, "t": now})
    except Exception:
        pass
    return False


def _find_hit(context, event):
    """Fast UV-editor hit test.  Background misses should be cheap after cache warm-up."""
    try:
        from . import interaction_1844 as _i44
        try:
            _i44._PG = _PG
        except Exception:
            pass
        hit = _i44._find_uv_hit_fast(context, event)
        if hit is not None:
            return hit
        try:
            if getattr(_i44, "_HIT_CACHE", None):
                return None
        except Exception:
            pass
    except Exception:
        pass
    try:
        from . import interaction_1845 as _i45
        try:
            _i45._PG = _PG
        except Exception:
            pass
        fn = getattr(_i45, "_find_hit_fast_1854", None) or getattr(_i45, "_find_hit_fast", None)
        return fn(context, event) if callable(fn) else None
    except Exception:
        return None


def _hit_is_selected(context, hit) -> bool:
    try:
        from . import interaction_1845 as _i45
        try:
            _i45._PG = _PG
        except Exception:
            pass
        fn = getattr(_i45, "_hit_selected_fast", None)
        return bool(fn(context, hit)) if callable(fn) else False
    except Exception:
        return False


def _select_hit(context, hit, event) -> bool:
    # Prefer the existing direct UV-selection helper because it updates the live
    # edit-mode UV selection immediately.  Fall back to Blender's native UV select.
    try:
        from . import interaction_1845 as _i45
        try:
            _i45._PG = _PG
        except Exception:
            pass
        fn = getattr(_i45, "_select_hit_fast", None)
        if callable(fn) and bool(fn(context, hit, event)):
            return True
    except Exception:
        pass
    try:
        uv = _region_to_uv(context, event)
        if uv is None:
            return False
        res = bpy.ops.uv.select(
            'EXEC_DEFAULT',
            extend=bool(getattr(event, "shift", False)),
            deselect=False,
            toggle=bool(getattr(event, "ctrl", False)),
            deselect_all=False,
            select_passthrough=False,
            location=(float(uv.x), float(uv.y)),
        )
        return 'FINISHED' in set(res)
    except TypeError:
        try:
            uv = _region_to_uv(context, event)
            if uv is None:
                return False
            res = bpy.ops.uv.select(
                extend=bool(getattr(event, "shift", False)),
                deselect=False,
                toggle=bool(getattr(event, "ctrl", False)),
                deselect_all=False,
                select_passthrough=False,
                location=(float(uv.x), float(uv.y)),
            )
            return 'FINISHED' in set(res)
        except Exception:
            return False
    except Exception:
        return False


def _invoke_native_transform(context) -> bool:
    """Start Blender's native Transform once; native snap/commit handles the drag."""
    try:
        kwargs = {"release_confirm": True}
        if _axis_enabled(context):
            axis = _get_axis(context)
            if axis == "U":
                kwargs["constraint_axis"] = (True, False, False)
            elif axis == "V":
                kwargs["constraint_axis"] = (False, True, False)
        res = bpy.ops.transform.translate('INVOKE_DEFAULT', **kwargs)
        return not bool(set(res) & {"CANCELLED"})
    except TypeError:
        try:
            kwargs = {}
            if _axis_enabled(context):
                axis = _get_axis(context)
                if axis == "U":
                    kwargs["constraint_axis"] = (True, False, False)
                elif axis == "V":
                    kwargs["constraint_axis"] = (False, True, False)
            res = bpy.ops.transform.translate('INVOKE_DEFAULT', **kwargs)
            return not bool(set(res) & {"CANCELLED"})
        except Exception:
            return False
    except Exception:
        return False


def _instant_invoke_1864(self, context, event):
    try:
        if not _instant_enabled(context):
            return {"PASS_THROUGH"}
        if str(getattr(event, "type", "")) != "LEFTMOUSE" or str(getattr(event, "value", "")) != "PRESS":
            return {"PASS_THROUGH"}
        if not _is_uv_context(context):
            return {"PASS_THROUGH"}
        # Modifier-assisted selection, menus, and non-standard gestures are fully
        # Blender-native.  This prevents Immediate Select from changing ordinary
        # selection behavior outside its simple click-drag purpose.
        if bool(getattr(event, "shift", False) or getattr(event, "ctrl", False) or
                getattr(event, "alt", False) or getattr(event, "oskey", False)):
            return {"PASS_THROUGH"}
        if _event_duplicate(context, event):
            return {"PASS_THROUGH"}

        hit = _find_hit(context, event)
        if not hit:
            return {"PASS_THROUGH"}

        # Selected elements already have Blender-native tweak/gizmo behavior.
        # Do not intercept them; this avoids breaking ordinary move/gizmo use.
        if _hit_is_selected(context, hit):
            return {"PASS_THROUGH"}

        if not _select_hit(context, hit, event):
            return {"PASS_THROUGH"}

        self._sus1864_start_xy = (
            int(getattr(event, "mouse_region_x", 0) or 0),
            int(getattr(event, "mouse_region_y", 0) or 0),
        )
        self._sus1864_transform_started = False
        try:
            context.window_manager.modal_handler_add(self)
            return {"RUNNING_MODAL"}
        except Exception:
            return {"FINISHED"}
    except Exception:
        return {"PASS_THROUGH"}


def _instant_modal_1864(self, context, event):
    try:
        etype = str(getattr(event, "type", ""))
        value = str(getattr(event, "value", ""))
        if etype in {"ESC", "RIGHTMOUSE"}:
            return {"CANCELLED"}
        if etype == "LEFTMOUSE" and value == "RELEASE":
            return {"FINISHED"}
        if etype == "MOUSEMOVE":
            sx, sy = getattr(self, "_sus1864_start_xy", (None, None))
            if sx is None or sy is None:
                return {"FINISHED"}
            dx = int(getattr(event, "mouse_region_x", 0) or 0) - int(sx)
            dy = int(getattr(event, "mouse_region_y", 0) or 0) - int(sy)
            # Keep the threshold small so the user can click-select and drag in
            # one continuous gesture, but do not turn a still click into a move.
            if (dx * dx + dy * dy) >= 9:
                if not getattr(self, "_sus1864_transform_started", False):
                    self._sus1864_transform_started = True
                    _invoke_native_transform(context)
                return {"FINISHED"}
    except Exception:
        return {"FINISHED"}
    return {"RUNNING_MODAL"}


def _patch_instant_class():
    try:
        cls = _pg("SMARTUVSUITE_OT_instant_select_drag_move")
        if not isinstance(cls, type):
            return
        cls.bl_options = {'UNDO', 'BLOCKING'}
        cls.invoke = _instant_invoke_1864
        cls.modal = _instant_modal_1864
        cls._sus1864_native_transform_handoff = True
    except Exception:
        pass


def _addon_keyconfig():
    try:
        return bpy.context.window_manager.keyconfigs.addon
    except Exception:
        return None


def _find_kmis(km, idname: str):
    try:
        from . import ownership_runtime_18168 as _ownership
        return [kmi for keymap, kmi in _ownership.owned_keymap_items(idname) if keymap is km]
    except Exception:
        return []


def _get_keymap(kc, name: str, space_type: str):
    try:
        km = kc.keymaps.get(name)
        if km is None:
            km = kc.keymaps.new(name=name, space_type=space_type, region_type="WINDOW")
        return km
    except Exception:
        return None


def _configure_left_press(kmi, active=True):
    try:
        _suv_resource.keymap_item_set(kmi, 'type', 'LEFTMOUSE')
        _suv_resource.keymap_item_set(kmi, 'value', 'PRESS')
    except Exception:
        pass
    for name in ("shift", "ctrl", "alt", "oskey", "hyper"):
        try:
            _suv_resource.keymap_item_set(kmi, name, False)
        except Exception:
            pass
    try:
        _suv_resource.keymap_item_set(kmi, 'any', False)
    except Exception:
        pass
    try:
        __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, bool(active))
    except Exception:
        pass


def _delete_rows_for_id(idname: str) -> int:
    kc = _addon_keyconfig()
    if kc is None:
        return 0
    removed = 0
    try:
        for km in list(kc.keymaps):
            for kmi in list(_find_kmis(km, idname)):
                try:
                    __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(km, kmi)
                    removed += 1
                except Exception:
                    try:
                        __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, False)
                    except Exception:
                        pass
    except Exception:
        pass
    return removed


def _ensure_instant_keymaps(active=True):
    kc = _addon_keyconfig()
    if kc is None:
        return (0, 0)
    # Remove global/gizmo map rows.  They are the cause of hover interception and
    # background selection anomalies.
    for name in _FORBIDDEN_INSTANT_MAPS:
        try:
            km = kc.keymaps.get(name)
            if km is None:
                continue
            for kmi in list(_find_kmis(km, _INSTANT_ID)):
                try:
                    __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(km, kmi)
                except Exception:
                    try:
                        __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, False)
                    except Exception:
                        pass
        except Exception:
            pass
    created = touched = 0
    for name, space in _INSTANT_KEYMAP_DEFS:
        km = _get_keymap(kc, name, space)
        if km is None:
            continue
        items = list(_find_kmis(km, _INSTANT_ID))
        if not items:
            try:
                kmi = __import__(__package__ + '.ownership_runtime_18168', fromlist=['new_keymap_item']).new_keymap_item(km, _INSTANT_ID, type="LEFTMOUSE", value="PRESS", head=True)
            except TypeError:
                kmi = __import__(__package__ + '.ownership_runtime_18168', fromlist=['new_keymap_item']).new_keymap_item(km, _INSTANT_ID, type="LEFTMOUSE", value="PRESS")
            items = [kmi]
            created += 1
        for extra in items[1:]:
            try:
                __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(km, extra)
            except Exception:
                try:
                    __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(extra, False)
                except Exception:
                    pass
        for kmi in items[:1]:
            _configure_left_press(kmi, active=active)
            touched += 1
    return (created, touched)


def _set_instant_keymaps_active(active: bool):
    if active:
        return _ensure_instant_keymaps(True)
    kc = _addon_keyconfig()
    if kc is None:
        return (0, 0)
    touched = 0
    for name, _space in _INSTANT_KEYMAP_DEFS:
        try:
            km = kc.keymaps.get(name)
            if km is None:
                continue
            for kmi in _find_kmis(km, _INSTANT_ID):
                __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, False)
                touched += 1
        except Exception:
            pass
    return (0, touched)


def _delete_instant_keymaps():
    return _delete_rows_for_id(_INSTANT_ID)


def _ensure_native_gizmo_rows(active=True):
    # Native Blender/user gizmo keymaps are foreign resources and remain untouched.
    del active
    return (0, 0)


def _gizmo_enable_native_only():
    try:
        from . import uv_gizmo_grip_fix as _gizmo
        _gizmo.set_enabled(True)
    except Exception:
        pass
    return None


def _gizmo_disable_native_only(delete=False):
    del delete
    try:
        from . import uv_gizmo_grip_fix as _gizmo
        _gizmo.set_enabled(False)
    except Exception:
        pass
    return None


def _prewarm_hit_cache(context=None):
    ctx = context or bpy.context
    if not _is_uv_context(ctx):
        return
    try:
        from . import interaction_1844 as _i44
        try:
            _i44._PG = _PG
        except Exception:
            pass
        tol_fn = getattr(_i44, "_uv_tolerance", None)
        get_fn = getattr(_i44, "_get_hit_cache", None)
        if callable(tol_fn) and callable(get_fn):
            get_fn(ctx, float(tol_fn(ctx, 10.0)))
    except Exception:
        pass


def _apply_keymap_exports():
    if not isinstance(_PG, dict):
        return
    try:
        bi = _PG.get("bl_info")
        if isinstance(bi, dict):
            bi["version"] = (1, 0, 0)
        _PG["__version__"] = '1.0.0'
    except Exception:
        pass
    _PG["_SUS_1830_INSTANT_KEYMAP_DEFS"] = tuple(_INSTANT_KEYMAP_DEFS)
    _PG["_SUS_1832_INSTANT_KEYMAP_DEFS"] = tuple(_INSTANT_KEYMAP_DEFS)
    _PG["_SUS_1834_INSTANT_KEYMAP_DEFS"] = tuple(_INSTANT_KEYMAP_DEFS)
    _PG["_SUS_1850_GIZMO_KEYMAP_DEFS"] = tuple()
    _PG["_SUS_1853_NATIVE_GIZMO_KEYMAP_NAMES"] = tuple(_NATIVE_GIZMO_KEYMAP_NAMES)
    _PG["_sus_1830_keymap_defs"] = lambda: tuple(_INSTANT_KEYMAP_DEFS)
    _PG["_sus_1834_keymap_defs"] = lambda: tuple(_INSTANT_KEYMAP_DEFS)
    _PG["_sus_1652_ensure_instant_keymaps"] = _ensure_instant_keymaps
    _PG["_sus_1652_promote_instant_keymaps_to_head"] = _ensure_instant_keymaps
    _PG["_sus_1652_set_instant_keymaps_active"] = _set_instant_keymaps_active
    _PG["_sus_1652_delete_instant_keymaps"] = _delete_instant_keymaps
    _PG["_sus_1652_gizmo_enable"] = _gizmo_enable_native_only
    _PG["_sus_1652_gizmo_disable"] = _gizmo_disable_native_only
    _PG["_sus_1864_native_transform_handoff"] = True


def _sync(context=None):
    apply_all(_PG, context or bpy.context)


def apply_all(pkg_globals=None, context=None):
    global _PG
    if pkg_globals is not None:
        _PG = pkg_globals
    ctx = context or bpy.context
    _apply_keymap_exports()
    _patch_instant_class()
    try:
        ws_fn = _PG.get("_sus_1652_ws") if isinstance(_PG, dict) else None
        ws = ws_fn(ctx) if callable(ws_fn) else getattr(getattr(ctx, "scene", None), "suv_workspace", None)
        if ws is not None:
            if bool(getattr(ws, "operation_instant_select_enabled", False)):
                _ensure_instant_keymaps(True)
            else:
                _set_instant_keymaps_active(False)
            if bool(getattr(ws, "operation_uv_gizmo_grip_fix_enabled", False)):
                _gizmo_enable_native_only()
            else:
                _gizmo_disable_native_only(delete=False)
    except Exception:
        pass
    try:
        if isinstance(_PG, dict):
            _PG["_sus_1652_sync_keymaps_from_workspace"] = _sync
            _PG["_sus_1841_final_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1842_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1845_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1860_sync_keymaps"] = lambda context=None: apply_all(_PG, context or bpy.context)
    except Exception:
        pass
    # Best effort: make the first real click cheap after enabling.
    try:
        _suv_resource.timer_register(lambda: (_prewarm_hit_cache(ctx), None)[1], first_interval=0.01)
    except Exception:
        pass


def install(pkg_globals):
    global _PG
    _PG = pkg_globals
    apply_all(pkg_globals, bpy.context)
