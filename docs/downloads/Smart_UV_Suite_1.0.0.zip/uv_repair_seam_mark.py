"""Set seams at creases in editable UV meshes."""
from math import pi


def build_handlers(api):
    def mark_creases(context, operator):
        if context.mode != "EDIT_MESH":
            return False

        settings = api._ws(context)
        cutoff = (
            operator.angle
            if operator.properties.is_property_set("angle")
            else getattr(settings, "auto_seam_angle_threshold", pi / 3)
        )
        if not 0.0 <= cutoff <= pi:
            return False

        sync = api._sync(context)
        edited_meshes = []
        for target in api._edit_targets(context):
            _, mesh, _ = target
            selected_uv_edges = {
                corner.edge for corner in api._selected_edge_loops(context, mesh)
            } if operator.scope != "ALL" else set()
            touched = False
            for edge in mesh.edges:
                in_scope = (
                    (operator.scope == "ALL" and not edge.hide)
                    or edge in selected_uv_edges
                    or (sync and edge.select and not edge.hide)
                )
                if in_scope and not edge.seam and edge.is_manifold:
                    if edge.calc_face_angle(0.0) >= cutoff:
                        edge.seam = True
                        touched = True
            if touched:
                edited_meshes.append(target)

        api._flush(edited_meshes)
        return bool(edited_meshes)

    mark_tool = api.Handler(
        mark_creases,
        "Mark selected manifold edges above the seam angle threshold.",
        "角度しきい値以上の選択辺にシームを付けます。",
    )
    return {f"smart_uv_suite.{name}": mark_tool for name in ("seam", "seam_mark_angle_native")}
