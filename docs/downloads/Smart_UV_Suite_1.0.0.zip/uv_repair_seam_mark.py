from math import pi, radians

def build_handlers(api):
    def run(context, op):
        if context.mode != 'EDIT_MESH':
            return False
        ws = api._ws(context)
        threshold = op.angle if op.properties.is_property_set('angle') else getattr(
            ws, 'auto_seam_angle_threshold', radians(60)
        )
        if not 0 <= threshold <= pi:
            return False
        rows = api._edit_targets(context)
        changed = []
        for row in rows:
            _, bm, _ = row
            if op.scope == 'ALL':
                edges = {edge for edge in bm.edges if not edge.hide}
            else:
                edges = {loop.edge for loop in api._selected_edge_loops(context, bm)}
                if api._sync(context):
                    edges.update(edge for edge in bm.edges if edge.select and not edge.hide)
            pending = {edge for edge in edges if edge.is_manifold and not edge.seam
                       and edge.calc_face_angle(0.0) >= threshold}
            for edge in pending:
                edge.seam = True
            if pending:
                changed.append(row)
        api._flush(changed)
        return bool(changed)

    mark = api.Handler(run, 'Mark selected manifold edges above the seam angle threshold.',
                       '角度しきい値以上の選択辺にシームを付けます。')
    return {
        'smart_uv_suite.seam': mark,
        'smart_uv_suite.seam_mark_angle_native': mark,
    }
