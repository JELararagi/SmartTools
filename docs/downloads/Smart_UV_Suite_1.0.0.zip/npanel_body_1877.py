# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Legacy Smart UV N-panel route disabled in 1.8.169.

The canonical full body is provided by npanel_body_1881.py.  This compatibility
module intentionally registers no panels, timers, handlers, or draw callbacks.
"""
from __future__ import annotations

import bpy


def install(*_args, **_kwargs): return None
def uninstall(*_args, **_kwargs): return None
def cancel(*_args, **_kwargs): return None
def repair(*_args, **_kwargs): return None
def schedule(*_args, **_kwargs): return None
def refresh_standard_body(*_args, **_kwargs): return None
def preinstall(*_args, **_kwargs): return None
def begin_teardown(*_args, **_kwargs): return None
def root_classes(): return ()
def is_current_root(_cls): return False


# Public 1.8.163 Panel compatibility surface.  These explicit aliases are
# intentionally not registered; the eleven physical 1.8.169 roots are the sole
# visible N-panel owners.  No foreign class is looked up or modified.
class SMARTUVSUITE_PT_1877_VIEW3D_BODY(bpy.types.Panel):
    bl_idname = 'SMARTUVSUITE_PT_1877_view3d_body'
    bl_label = 'Smart UV Suite'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart UV'
    _smart_uv_suite_compatibility_alias = True
    _smart_uv_suite_replacement = 'SMARTUVSUITE_PT_1881_VIEW3D_BODY'

    @classmethod
    def poll(cls, context):
        del cls, context
        return False

    def draw(self, context):
        del context
        return None

class SMARTUVSUITE_PT_1877_UV_EDITOR_BODY(bpy.types.Panel):
    bl_idname = 'SMARTUVSUITE_PT_1877_uv_editor_body'
    bl_label = 'Smart UV Suite'
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart UV'
    _smart_uv_suite_compatibility_alias = True
    _smart_uv_suite_replacement = 'SMARTUVSUITE_PT_1881_IMAGE_EDITOR_BODY'

    @classmethod
    def poll(cls, context):
        del cls, context
        return False

    def draw(self, context):
        del context
        return None

