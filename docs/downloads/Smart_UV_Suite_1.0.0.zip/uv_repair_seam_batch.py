"""Public routes for batch seam profiles."""

import bpy


def apply_profile(context, op):
    options = {"profile": op.profile.upper()} if op.profile else {}
    if op.scope:
        options["scope_override"] = op.scope.upper()
    was_editing = context.mode == "EDIT_MESH"
    try:
        result = bpy.ops.uv.suv_batch_apply_seam_profile(**options)
    finally:
        if was_editing and context.mode == "OBJECT":
            bpy.ops.object.mode_set(mode="EDIT")
    return "FINISHED" in result


def invoke_profile(context, op, event):
    if op.profile or op.scope:
        return op.execute(context)
    return bpy.ops.uv.suv_batch_apply_seam_profile("INVOKE_DEFAULT")


def build_handlers(api):
    return {"smart_uv_suite.seam_batch_apply_seam_profile": api.Handler(
        apply_profile, "Apply a seam profile across the selected meshes.",
        "選択メッシュ全体にシームプロファイルを適用します。", invoke_profile)}
