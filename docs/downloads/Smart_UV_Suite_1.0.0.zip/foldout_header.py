# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Shared top-level foldout header for Smart UV Suite.

This is the single place that switches the triangle (open / closed) for the
sections drawn by the suite itself.  Callers pass a row and small callbacks;
the layout is always: triangle button, title button, small gap, help button.
"""

from __future__ import annotations


def draw_foldout_header(main, expanded, *, title='', icon='DOT', op=None, op_props=None, set_props=None,
                        data=None, prop=None, toggle_title=False, single=False, icon_value=0, draw_title=None, draw_help=None):
    ikw = {'icon_value': icon_value} if icon_value else {'icon': icon}
    tri = 'TRIA_DOWN' if expanded else 'TRIA_RIGHT'
    title_done = False
    has_prop = data is not None and bool(prop)
    if op:
        if single:
            o = main.operator(op, text=title, icon=tri, emboss=False)
            if set_props:
                set_props(o, op_props or {})
            o = main.operator(op, text='', icon=icon, emboss=False)
            if set_props:
                set_props(o, op_props or {})
            title_done = True
        else:
            o = main.operator(op, text='', icon=tri, emboss=True, depress=bool(expanded))
            if set_props:
                set_props(o, op_props or {})
            if draw_title is None:
                o = main.operator(op, text=title, emboss=False, depress=bool(expanded), **ikw)
                if set_props:
                    set_props(o, op_props or {})
                title_done = True
    elif has_prop:
        if single:
            main.prop(data, prop, text=title, icon=tri, emboss=False)
            title_done = True
        else:
            main.prop(data, prop, text='', icon=tri, emboss=True)
        if draw_title is None and not title_done:
            if toggle_title:
                main.prop(data, prop, text=title, toggle=True, emboss=False, **ikw)
            else:
                main.prop(data, prop, text=title, emboss=False, **ikw)
            title_done = True
    else:
        main.label(text='', icon=tri)
        if draw_title is None:
            main.label(text=title, **ikw)
            title_done = True
    if draw_title is not None and not title_done:
        draw_title(main)
    if draw_help is not None:
        main.separator(factor=0.35)
        draw_help(main)
