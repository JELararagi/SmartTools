import bpy


def _save(context, op):
    from . import npanel_persistence

    value = not npanel_persistence.get_state_save_enabled(True)
    npanel_persistence.set_state_save_enabled(value, context=context)
    return npanel_persistence.get_state_save_enabled(True) == value


def _pivot(context, op):
    space = context.space_data
    if context.area is None or context.area.type != 'IMAGE_EDITOR' or context.area.ui_type != 'UV':
        area = next((item for item in getattr(context.screen, 'areas', ())
                     if item.type == 'IMAGE_EDITOR' and item.ui_type == 'UV'), None)
        if area is None:
            return False
        space = area.spaces.active
    target = op.mode.strip().upper()
    if not target:
        target = 'BOUNDING_BOX_CENTER' if space.pivot_point == 'CURSOR' else 'CURSOR'
    if target not in space.bl_rna.properties['pivot_point'].enum_items.keys():
        return False
    space.pivot_point = target
    return True


def _foldout(context, op):
    return 'FINISHED' in bpy.ops.smart_uv_suite.toggle_ui_foldout(
        key=op.key, default_open=op.default_open)


def build_handlers(api):
    return {
        'smart_uv_suite.workflow_toggle_pivot': api.Handler(_pivot, 'Set or toggle the UV editor pivot.', 'UV エディターのピボットを指定または切り替えます。'),
        'smart_uv_suite.workflow_toggle_npanel_state_save': api.Handler(_save, 'Toggle automatic saving of Smart UV N-panel state.', 'Smart UV の N パネル状態の自動保存を切り替えます。'),
        'smart_uv_suite.workflow_toggle_ui_foldout': api.Handler(_foldout, 'Open or close the named Smart UV N-panel section.', '指定した Smart UV の N パネルセクションを開閉します。'),
    }
