from __future__ import annotations
from . import resource_api_18168 as _suv_resource
from .quality_class_inventory import iter_suite_classes

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None

_NAMESPACE = {}
_REGISTERED = []

_GROUPS = [
    ('unwrap_relax', 'Unwrap & Relax', '展開とリラックス', ('unwrap', 'unfold', 'relax', 'straighten', 'gridify', 'quadrify', 'rectify', 'iron')),
    ('projection_mapping', 'Projection & Mapping', '投影とマッピング', ('project', 'projection', 'camera', 'planar', 'cylinder', 'sphere', 'view', 'mapping')),
    ('seams_stitch', 'Seams & Stitch', 'シームと接続', ('seam', 'stitch', 'sew', 'cut', 'weld', 'peel', 'border seam', 'mirror seam')),
    ('layout_packing', 'Layout & Packing', 'レイアウトとパッキング', ('pack', 'layout', 'arrange', 'orient', 'fit', 'bounds', 'udim', 'tile', 'stack', 'unstack', 'randomize', 'distribute')),
    ('selection_analysis', 'Selection & Analysis', '選択と解析', ('select', 'similar', 'overlap', 'flipped', 'inspect', 'issue', 'scan', 'audit', 'diagnostic')),
    ('density_preview', 'Density & Preview', '密度とプレビュー', ('density', 'texel', 'checker', 'preview', 'overlay', 'histogram', 'visual')),
    ('uvmaps', 'UV Maps', 'UVマップ', ('uvmap', 'uv map', 'layer', 'channel', 'rename', 'duplicate', 'active uv')),
    ('symmetry_atlas', 'Symmetry & Atlas', '対称とアトラス', ('sym', 'mirror', 'pair', 'transfer', 'atlas', 'bake', 'lightmap', 'material')),
    ('maintenance', 'Maintenance & Guidance', '保守とガイダンス', ('workspace', 'repair', 'snapshot', 'report', 'support', 'cleanup', 'context', 'readiness', 'guide', 'help', 'catalog')),
]


def _tr(context, key: str, en: str, ja: str, **fmt) -> str:
    fn = _NAMESPACE.get('tr')
    text = None
    if callable(fn):
        try:
            text = fn(context, key, **fmt)
        except Exception:
            text = None
    if not text:
        text = en
    try:
        return text.format(**fmt)
    except Exception:
        return text


def _text_name(context) -> str:
    ws_fn = _NAMESPACE.get('_suv_ws')
    ws = ws_fn(context) if callable(ws_fn) else None
    name = getattr(ws, 'support_bundle_name', '') if ws else ''
    return (str(name).strip() or 'SUV_Support_Bundle') + '_Operator_Catalog'


def _text_block(name: str, clear=False):
    textio = _NAMESPACE.get('_quality_textio_module')
    if textio is not None and hasattr(textio, 'ensure_report_text'):
        try:
            return textio.ensure_report_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if textio is not None and hasattr(textio, 'ensure_namespace_text'):
        try:
            return textio.ensure_namespace_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if bpy is None:
        return None
    txt = bpy.data.texts.get(name)
    if txt is None:
        if not clear:
            return None
        txt = bpy.data.texts.new(name)
    elif clear:
        txt.clear()
    return txt


def _infer_group(text: str):
    low = (text or '').lower()
    best = _GROUPS[-1]
    best_score = 0
    for row in _GROUPS:
        score = sum(1 for kw in row[3] if kw in low)
        if score > best_score:
            best = row
            best_score = score
    return best


def scan_operator_catalog(namespace: dict) -> dict:
    rows = []
    groups = {g[0]: {'title_en': g[1], 'title_ja': g[2], 'operators': [], 'panels': [], 'menus': []} for g in _GROUPS}
    for name, value in iter_suite_classes(namespace):
        if not isinstance(value, type):
            continue
        kind = None
        if name.startswith('SUV_OT_'):
            kind = 'operators'
        elif name.startswith('SUV_PT_'):
            kind = 'panels'
        elif name.startswith('SUV_MT_'):
            kind = 'menus'
        if kind is None:
            continue
        try:
            label = str(getattr(value, 'bl_label', '') or name).strip()
            bl_idname = str(getattr(value, 'bl_idname', '') or '')
            desc = str(getattr(value, 'bl_description', '') or '').strip()
            hay = ' '.join([name, label, bl_idname, desc])
            group = _infer_group(hay)
            row = {
                'name': name,
                'kind': kind[:-1],
                'label': label,
                'idname': bl_idname,
                'description': desc,
                'group_key': group[0],
                'group_title_en': group[1],
                'group_title_ja': group[2],
            }
            rows.append(row)
            groups[group[0]][kind].append(row)
        except Exception:
            continue
    result = {
        'total': len(rows),
        'operators': sum(1 for r in rows if r['kind'] == 'operator'),
        'panels': sum(1 for r in rows if r['kind'] == 'panel'),
        'menus': sum(1 for r in rows if r['kind'] == 'menu'),
        'groups': groups,
        'rows': rows,
    }
    namespace['_suv_operator_catalog_last'] = result
    return result


class SUV_OT_quality_write_operator_catalog(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_write_operator_catalog'
    bl_label = 'Write Operator Catalog'
    bl_description = 'Write a categorized UV Suite operator and UI catalog so you can review the current tool surface by workflow group. / 現在のツール群をワークフロー別に見直せるよう、UV Suite のオペレーターと UI をカテゴリ別カタログとして書き出します。'
    bl_options = set()

    open_after_write: bpy.props.BoolProperty(
        name='Open After Write',
        description='Open the written catalog in Blender Text Editor when possible / 可能なら書き出したカタログを Blender テキストエディタで開きます',
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        data = scan_operator_catalog(_NAMESPACE)
        txt = None
        lines = [
            'UV Suite Operator Catalog',
            f"Total entries: {data['total']}",
            f"Operators: {data['operators']}",
            f"Panels: {data['panels']}",
            f"Menus: {data['menus']}",
            '',
            '[Grouped Surface]',
        ]
        for key, group in data['groups'].items():
            count = len(group['operators']) + len(group['panels']) + len(group['menus'])
            if count <= 0:
                continue
            lines.append(f"- {group['title_en']} / {group['title_ja']} [{count}]")
            for kind_name in ('operators', 'panels', 'menus'):
                entries = group[kind_name]
                if not entries:
                    continue
                lines.append(f"  {kind_name.title()}: {len(entries)}")
                for row in sorted(entries, key=lambda x: (x['label'].lower(), x['name'].lower())):
                    desc = row['description'].split(' / ', 1)[0].strip() if row['description'] else '-'
                    lines.append(f"    - {row['label']} :: {row['idname'] or row['name']}")
                    if desc and desc != '-':
                        lines.append(f"      {desc}")
            lines.append('')
        textio = _NAMESPACE.get('_quality_textio_module')
        writer = getattr(textio, 'write_report_lines_consistent', None) if textio is not None else None
        if callable(writer):
            txt = writer(
                _NAMESPACE, context, _text_name, lines, _text_block, self,
                open_after_write=self.open_after_write,
                failed_key='msg.quality_catalog_open_failed',
                failed_en='Could not open operator catalog: {name}',
                failed_ja='オペレーターカタログを開けませんでした: {name}',
            )
            if txt is None:
                return {'CANCELLED'}
        else:
            txt = _text_block(_text_name(context), clear=True)
            if txt is None:
                return {'CANCELLED'}
            txt.write('\n'.join(lines))
            if self.open_after_write:
                opener = _NAMESPACE.get('_suv_open_text_in_editor')
                if callable(opener):
                    try:
                        opener(context, txt)
                    except Exception:
                        pass
        msg = _tr(context, 'msg.quality_catalog_written', 'Operator catalog written: {name} ({total} entries)', 'オペレーターカタログを書き出しました: {name}（{total} 件）', name=txt.name, total=data['total'])
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class SUV_OT_quality_open_operator_catalog(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_open_operator_catalog'
    bl_label = 'Open Operator Catalog'
    bl_description = 'Open the latest UV Suite operator catalog text block in Blender Text Editor. / 最新の UV Suite オペレーターカタログを Blender のテキストエディタで開きます。'
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        textio = _NAMESPACE.get('_quality_textio_module')
        if textio is not None and hasattr(textio, 'open_named_report_text_or_fallback'):
            return textio.open_named_report_text_or_fallback(
                _NAMESPACE, context, _text_name, self, _text_block,
                missing_key='msg.quality_catalog_missing',
                missing_en='No operator catalog exists yet.',
                missing_ja='オペレーターカタログはまだ作成されていません。',
                opened_key='msg.quality_catalog_opened',
                opened_en='Opened operator catalog: {name}',
                opened_ja='オペレーターカタログを開きました: {name}',
            )
        txt = _text_block(_text_name(context), clear=False)
        if txt is None:
            self.report({'WARNING'}, _tr(context, 'msg.quality_catalog_missing', 'No operator catalog exists yet.', 'オペレーターカタログはまだ作成されていません。'))
            return {'CANCELLED'}
        opener = _NAMESPACE.get('_suv_open_text_in_editor')
        ok = False
        if callable(opener):
            try:
                ok, _err = opener(context, txt)
            except Exception:
                ok = False
        if not ok:
            self.report({'WARNING'}, _tr(context, 'msg.quality_catalog_open_failed', 'Could not open operator catalog: {name}', 'オペレーターカタログを開けませんでした: {name}', name=txt.name))
            return {'CANCELLED'}
        msg = _tr(context, 'msg.quality_catalog_opened', 'Opened operator catalog: {name}', 'オペレーターカタログを開きました: {name}', name=txt.name)
        self.report({'INFO'}, msg)
        return {'FINISHED'}



def register(namespace: dict):
    global _NAMESPACE
    _NAMESPACE = namespace if isinstance(namespace, dict) else {}
    if bpy is None:
        return []
    classes = [SUV_OT_quality_write_operator_catalog, SUV_OT_quality_open_operator_catalog]
    reg = []
    for cls in classes:
        try:
            _suv_resource.register_class(cls)
            reg.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = reg
    return reg


def unregister(namespace: dict | None = None):
    if bpy is None:
        return []
    removed = []
    for cls in reversed(list(_REGISTERED)):
        try:
            _suv_resource.unregister_class(cls)
            removed.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = []
    return removed
