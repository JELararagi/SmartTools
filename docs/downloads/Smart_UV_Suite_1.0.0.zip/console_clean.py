# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations
from . import resource_api_18168 as _suv_resource

# This module is intentionally defensive.  It removes stale UV Suite keymap
# artifacts left by older builds and wraps migrated N-panel draw functions so
# Blender never receives a non-None value from Panel.draw().

import sys
from typing import Iterable

import bpy

_INSTALLED = False
_LEGACY_OPERATOR_CLASSES: list[type] = []
_TIMER_TAGS: set[str] = set()

_STALE_EXTENSION_MODULES = (
    'bl_ext.user_default.smart_tools_window_prototype',
    'bl_ext.user_default.smart_tools_independent_window_shell',
    'bl_ext.user_default.view_plane_generator',
    'bl_ext.user_default.smart_tools_browser_prototype',
    'bl_ext.user_default.smart_tools_window',
    'smart_tools_window_prototype',
    'smart_tools_independent_window_shell',
    'view_plane_generator',
    'smart_tools_browser_prototype',
    'smart_tools_window',
)

_LEGACY_NPANEL_OPERATOR_IDS = (
    'wm.bl_ext_npanel_popup_menu',
    'wm.bl_ext_npanel_operator_enum_popup',
    'wm.bl_ext_npanel_call_menu_pie',
)

_STALE_OPERATOR_PREFIXES = (
    'wm.smart_tools_',
    'wm.smart_tools_window',
    'wm.smart_tools_browser',
    'wm.bl_ext_npanel_',
)

_COMPAT_PROP_NAMES = (
    'action', 'mode_to', 'mode', 'cut', 'reduce_mode', 'operator', 'operator_id',
    'menu', 'menu_id', 'pie', 'name', 'data_path', 'value', 'text', 'icon', 'addon_key',
)


def _addon_id() -> str:
    pkg = str(__package__ or __name__ or '').strip('.')
    parts = [p for p in pkg.split('.') if p]
    if 'user_default' in parts:
        idx = parts.index('user_default')
        if idx + 1 < len(parts):
            return parts[idx + 1]
    for part in reversed(parts):
        if part.startswith('smart_') and part.endswith('_suite'):
            return part
    return parts[-1] if parts else 'smart_tools'


def _suite_operator_prefixes() -> tuple[str, ...]:
    addon = _addon_id()
    base = addon[:-6] if addon.endswith('_suite') else addon
    return tuple(dict.fromkeys((
        addon + '.',
        base + '.',
        'wm.' + addon,
        'wm.' + base,
        'wm.' + addon.replace('_suite', '') + '_suite_',
    )))


def _iter_keyconfigs():
    try:
        wm = getattr(bpy.context, "window_manager", None)
        kc = getattr(getattr(wm, "keyconfigs", None), "addon", None)
        return (kc,) if kc is not None else ()
    except Exception:
        return ()


def _keymap_item_count(km) -> int:
    try:
        return len(getattr(km, 'keymap_items', ()) or ())
    except Exception:
        count = 0
        try:
            for _ in getattr(km, 'keymap_items', ()):
                count += 1
        except Exception:
            pass
        return count


def _kmi_signature(kmi):
    try:
        return (
            str(getattr(kmi, 'idname', '') or ''),
            str(getattr(kmi, 'type', '') or ''),
            str(getattr(kmi, 'value', '') or ''),
            bool(getattr(kmi, 'any', False)),
            bool(getattr(kmi, 'shift', False)),
            bool(getattr(kmi, 'ctrl', False)),
            bool(getattr(kmi, 'alt', False)),
            bool(getattr(kmi, 'oskey', False)),
            str(getattr(kmi, 'key_modifier', '') or ''),
        )
    except Exception:
        return None


def _copy_keymap_item(dst_km, src_kmi):
    # Keymap mutation is disabled.  Manual registration only.
    del dst_km, src_kmi
    return None


def _ensure_nonempty_user_interface_keymap() -> bool:
    # Do not create, repair, or remove Preferences > Keymap entries.
    return False

def _remove_empty_addon_user_interface_keymap() -> bool:
    # Do not remove Preferences > Keymap entries automatically.
    return False


def _kmi_should_remove(kmi, *, aggressive: bool = False) -> bool:
    try:
        idname = str(getattr(kmi, 'idname', '') or '')
    except Exception:
        idname = ''
    if not idname:
        return False
    if idname in _LEGACY_NPANEL_OPERATOR_IDS:
        return True
    if idname.startswith(_STALE_OPERATOR_PREFIXES):
        return True
    # User keymaps can keep stale shortcut entries for previous builds.  Removing
    # only package-owned entries avoids touching Blender defaults.
    if aggressive and any(idname.startswith(prefix) for prefix in _suite_operator_prefixes()):
        return True
    return False


def _remove_stale_keymap_items() -> bool:
    # Do not inspect, disable, or remove keymap items automatically.
    return False


def _purge_stale_addon_entries() -> bool:
    """Compatibility no-op: never remove add-ons or modules owned elsewhere."""
    return False



def clean_keymaps_and_preferences(*, save: bool = True) -> bool:
    # Disabled in the standard N-panel build.  Installing UV Suite must
    # not edit Blender keymaps, remove other add-ons, or save user preferences.
    del save
    return False


def _schedule_userpref_save() -> None:
    def _save_once():
        try:
            bpy.ops.wm.save_userpref()
        except Exception:
            pass
        return None
    try:
        None  # 1.8.169: no automatic save timer
    except Exception:
        pass


def _operator_registered(op_id: str) -> bool:
    try:
        namespace, name = str(op_id).split('.', 1)
        ops_ns = getattr(bpy.ops, namespace, None)
        op = getattr(ops_ns, name, None) if ops_ns is not None else None
        if op is None:
            return False
        op.get_rna_type()
        return True
    except Exception:
        return False


def _make_legacy_operator_class(class_name: str, bl_idname: str):
    from bpy.props import BoolProperty, FloatProperty, IntProperty, StringProperty

    def execute(self, context):
        return {'CANCELLED'}

    attrs = {
        '__module__': __name__,
        'bl_idname': bl_idname,
        'bl_label': 'UV Suite Legacy Compatibility',
        'bl_options': {'INTERNAL'},
        'execute': execute,
        'action': StringProperty(options={'SKIP_SAVE'}),
        'mode_to': StringProperty(options={'SKIP_SAVE'}),
        'mode': StringProperty(options={'SKIP_SAVE'}),
        'cut': BoolProperty(default=False, options={'SKIP_SAVE'}),
        'reduce_mode': StringProperty(options={'SKIP_SAVE'}),
        'operator': StringProperty(options={'SKIP_SAVE'}),
        'operator_id': StringProperty(options={'SKIP_SAVE'}),
        'menu': StringProperty(options={'SKIP_SAVE'}),
        'menu_id': StringProperty(options={'SKIP_SAVE'}),
        'pie': StringProperty(options={'SKIP_SAVE'}),
        'name': StringProperty(options={'SKIP_SAVE'}),
        'data_path': StringProperty(options={'SKIP_SAVE'}),
        'value': StringProperty(options={'SKIP_SAVE'}),
        'text': StringProperty(options={'SKIP_SAVE'}),
        'icon': StringProperty(options={'SKIP_SAVE'}),
        'addon_key': StringProperty(options={'SKIP_SAVE'}),
        'index': IntProperty(default=0, options={'SKIP_SAVE'}),
        'factor': FloatProperty(default=0.0, options={'SKIP_SAVE'}),
    }
    return type(class_name, (bpy.types.Operator,), attrs)


def register_legacy_operator_compatibility() -> None:
    specs = (
        ('BL_EXT_OT_npanel_popup_menu', 'wm.bl_ext_npanel_popup_menu'),
        ('BL_EXT_OT_npanel_operator_enum_popup', 'wm.bl_ext_npanel_operator_enum_popup'),
        ('BL_EXT_OT_npanel_call_menu_pie', 'wm.bl_ext_npanel_call_menu_pie'),
    )
    for class_name, op_id in specs:
        if _operator_registered(op_id):
            continue
        try:
            existing = getattr(bpy.types, class_name, None)
            if isinstance(existing, type):
                _LEGACY_OPERATOR_CLASSES.append(existing)
                continue
        except Exception:
            pass
        try:
            cls = _make_legacy_operator_class(class_name, op_id)
            _suv_resource.register_class(cls)
            _LEGACY_OPERATOR_CLASSES.append(cls)
        except Exception:
            pass


def _wrap_callable_returns_none(fn):
    if not callable(fn):
        return fn
    if getattr(fn, '_safe_panel_draw_returns_none', False):
        return fn
    def _wrapped(self, context):
        try:
            fn(self, context)
        except TypeError:
            try:
                fn(context)
            except TypeError:
                try:
                    fn(self)
                except Exception:
                    pass
            except Exception:
                pass
        except Exception:
            pass
        return None
    try:
        _wrapped.__name__ = getattr(fn, '__name__', '_wrapped_draw')
        _wrapped.__doc__ = getattr(fn, '__doc__', None)
        _wrapped._safe_panel_draw_returns_none = True
    except Exception:
        pass
    return _wrapped


def sanitize_panel_draws() -> int:
    """Compatibility no-op: Smart UV never rewrites Blender/foreign Panel methods."""
    return 0



def _timer_install(tag: str, interval: float):
    if tag in _TIMER_TAGS:
        return
    _TIMER_TAGS.add(tag)
    def _run():
        try:
            clean_keymaps_and_preferences(save=True)
        except Exception:
            pass
        try:
            sanitize_panel_draws()
        except Exception:
            pass
        return None
    try:
        None  # 1.8.169: no console cleanup polling timer
    except Exception:
        pass


def install() -> None:
    # Standard N-panel build: no install-time keymap/preference cleanup, no
    # user preference save timers, and no global Panel.draw rewriting.  Those
    # legacy SmartTools compatibility passes can stall Blender while enabling
    # the extension.
    global _INSTALLED
    _INSTALLED = True
    return None

def uninstall() -> None:
    global _INSTALLED
    _INSTALLED = False
    return None

