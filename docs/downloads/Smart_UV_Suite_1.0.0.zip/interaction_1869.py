# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""1.8.69 final Immediate Select direct-drag fix.

This layer replaces the delayed-transform gate.  The previous gate selected on
PRESS but held the original mouse press until a later MOUSEMOVE, so Blender's
native Tweak/Translate operator could miss the gesture and it could fall back to
background box-select.

Final behavior:
- background press: immediate PASS_THROUGH, no mesh scan beyond the fast UV hit;
- selected UV element / modifiers / native gizmo: PASS_THROUGH, Blender-native;
- unselected UV element press: select immediately on PRESS.  With no remembered
  U/V axis constraint, the same event is returned to Blender as PASS_THROUGH so
  native Tweak/Move owns drag, snap, release and undo.  With an active remembered
  U/V axis constraint, Blender native Translate is invoked immediately with only
  constraint_axis supplied.
"""
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

import bpy

_PG = None
_VERSION = (1, 8, 69)
_INSTANT_ID = "smart_uv_suite.instant_select_drag_move"
_GIZMO_ID = "smart_uv_suite.uv_gizmo_grip_fix_grab"
_NATIVE_GIZMO_ID = ""

# Keep the operator reachable for UV Move/Tweak workflows.  The operator itself
# rejects background, selected-element, gizmo, modifiers, and Select Box tool
# gestures immediately, so normal UV selection and box-select remain native.
_INSTANT_KEYMAP_DEFS = (
    ("UV Editor", "EMPTY"),
    ("Image Editor Tool: Uv, Tweak", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Tweak (fallback)", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Move", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Move (fallback)", "IMAGE_EDITOR"),
)
_PURGE_INSTANT_MAP_NAMES = (
    "Window",
    "Image",
    "Image Generic",
    "Generic Gizmo",
    "Generic Gizmo Drag",
    "Generic Gizmo Click Drag",
    "Generic Gizmo Maybe Drag",
    "Generic Gizmo Select",
    "Image Editor Tool: Uv, Select Box",
    "Image Editor Tool: Uv, Select Box (fallback)",
)
_NATIVE_GIZMO_KEYMAP_NAMES = (
    "Generic Gizmo",
    "Generic Gizmo Drag",
    "Generic Gizmo Click Drag",
    "Generic Gizmo Maybe Drag",
    "Generic Gizmo Select",
)


def _pg(name, default=None):
    try:
        return _PG.get(name, default) if isinstance(_PG, dict) else default
    except Exception:
        return default


def _base():
    try:
        from . import interaction_1865 as b
        return b
    except Exception:
        return None


def _is_select_box_tool(context) -> bool:
    """Do not alter Blender's box/lasso/circle select tools."""
    try:
        workspace = getattr(context, "workspace", None)
        if workspace is None:
            return False
        tools = getattr(workspace, "tools", None)
        if tools is None:
            return False
        tool = None
        for args in (("IMAGE_EDITOR", "UV"), ("IMAGE_EDITOR",), ("UV",), tuple()):
            try:
                tool = tools.from_space_image_mode(*args) if args else None
                if tool is not None:
                    break
            except TypeError:
                continue
            except Exception:
                continue
        tid = str(getattr(tool, "idname", "") or "").lower()
        if not tid:
            return False
        return any(x in tid for x in ("select_box", "select_lasso", "select_circle"))
    except Exception:
        return False


def _axis_tuple(context):
    try:
        b = _base()
        fn = getattr(b, "_axis_tuple", None) if b is not None else None
        if callable(fn):
            return fn(context)
    except Exception:
        pass
    try:
        from . import interaction_1866 as i66
        fn = getattr(i66, "_axis_tuple", None)
        if callable(fn):
            return fn(context)
    except Exception:
        pass
    return None


def _invoke_native_translate_on_press(context, axis=None):
    """Start Blender native Translate immediately while the LMB is still held.

    No snap parameters are supplied: Blender reads the UV Editor's active snap
    settings itself.  This path is used only when a remembered U/V axis must be
    forwarded; otherwise Blender gets the original PRESS via PASS_THROUGH.
    """
    kwargs = {"release_confirm": True}
    if axis is not None:
        kwargs["constraint_axis"] = axis
    try:
        res = bpy.ops.transform.translate("INVOKE_DEFAULT", **kwargs)
        return set(res) if res is not None else {"RUNNING_MODAL"}
    except TypeError:
        try:
            if axis is not None:
                res = bpy.ops.transform.translate("INVOKE_DEFAULT", constraint_axis=axis)
            else:
                res = bpy.ops.transform.translate("INVOKE_DEFAULT")
            return set(res) if res is not None else {"RUNNING_MODAL"}
        except Exception:
            return {"CANCELLED"}
    except Exception:
        return {"CANCELLED"}


def _instant_invoke_1869(self, context, event):
    b = _base()
    if b is None:
        return {"PASS_THROUGH"}
    try:
        if not b._instant_enabled(context):
            return {"PASS_THROUGH"}
        if str(getattr(event, "type", "")) != "LEFTMOUSE" or str(getattr(event, "value", "")) != "PRESS":
            return {"PASS_THROUGH"}
        if not b._is_uv_context(context):
            return {"PASS_THROUGH"}
        # Modified clicks must stay 100% Blender-native.  This preserves add,
        # subtract, toggle selection, and special tool gestures.
        if bool(getattr(event, "shift", False) or getattr(event, "ctrl", False) or getattr(event, "alt", False) or getattr(event, "oskey", False)):
            return {"PASS_THROUGH"}
        if _is_select_box_tool(context):
            return {"PASS_THROUGH"}
        if b._event_duplicate(context, event):
            return {"PASS_THROUGH"}

        # Fast miss path.  No selected collection, no gizmo-pivot calculation,
        # no BMesh-wide transform preparation: background box-select remains
        # responsive from the first drag frame.
        hit = b._find_hit(context, event)
        if not hit:
            return {"PASS_THROUGH"}

        # Existing selected elements, tweak drags, and native gizmo grabs remain
        # Blender-native.  Immediate Select only changes the unselected-element
        # press case.
        try:
            if b._hit_selected(context, hit):
                return {"PASS_THROUGH"}
        except Exception:
            pass

        if not b._select_hit(context, hit, event):
            return {"PASS_THROUGH"}

        try:
            if getattr(context, "area", None) is not None:
                context.area.tag_redraw()
        except Exception:
            pass

        # Critical fix: do not hold the original press until a later MOUSEMOVE.
        # Without a remembered U/V axis, pass the same PRESS back to Blender so
        # native Tweak/Move owns the drag and standard snap.  If axis-memory has
        # a real U/V constraint, invoke native Translate immediately with only
        # that constraint supplied.
        axis = _axis_tuple(context)
        if axis is not None:
            _invoke_native_translate_on_press(context, axis=axis)
            return {"FINISHED"}
        return {"PASS_THROUGH"}
    except Exception:
        return {"PASS_THROUGH"}


def _instant_modal_1869(self, context, event):
    return {"FINISHED"}


def _patch_instant_class():
    try:
        cls = _pg("SMARTUVSUITE_OT_instant_select_drag_move")
        if not isinstance(cls, type):
            return
        cls.bl_options = {'UNDO'}
        cls.invoke = _instant_invoke_1869
        cls.modal = _instant_modal_1869
        cls._sus1869_press_select_native_handoff = True
    except Exception:
        pass


def _addon_keyconfig():
    try:
        return bpy.context.window_manager.keyconfigs.addon
    except Exception:
        return None


def _find_kmis(km, idname: str):
    try:
        from . import ownership_runtime_18168 as _ownership
        return [kmi for keymap, kmi in _ownership.owned_keymap_items(idname) if keymap is km]
    except Exception:
        return []


def _get_keymap(kc, name: str, space_type: str):
    try:
        km = kc.keymaps.get(name)
        if km is None:
            km = kc.keymaps.new(name=name, space_type=space_type, region_type="WINDOW")
        return km
    except Exception:
        return None


def _configure_left_press(kmi, active=True):
    try:
        _suv_resource.keymap_item_set(kmi, 'type', 'LEFTMOUSE'); _suv_resource.keymap_item_set(kmi, 'value', 'PRESS')
    except Exception:
        pass
    for name in ("shift", "ctrl", "alt", "oskey", "hyper"):
        try:
            _suv_resource.keymap_item_set(kmi, name, False)
        except Exception:
            pass
    try:
        _suv_resource.keymap_item_set(kmi, 'any', False)
    except Exception:
        pass
    try:
        __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, bool(active))
    except Exception:
        pass


def _delete_rows_for_id(idname: str) -> int:
    kc = _addon_keyconfig()
    if kc is None:
        return 0
    removed = 0
    try:
        for km in list(kc.keymaps):
            for kmi in list(_find_kmis(km, idname)):
                try:
                    __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(km, kmi); removed += 1
                except Exception:
                    try: __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, False)
                    except Exception: pass
    except Exception:
        pass
    return removed


def _ensure_instant_keymaps(active=True):
    kc = _addon_keyconfig()
    if kc is None:
        return (0, 0)
    # Remove rows from broad/global/select-box maps that caused normal selection
    # and background drags to be routed through Smart UV before Blender.
    try:
        for name in _PURGE_INSTANT_MAP_NAMES:
            km = kc.keymaps.get(name)
            if km is None:
                continue
            for kmi in list(_find_kmis(km, _INSTANT_ID)):
                try: __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(km, kmi)
                except Exception:
                    try: __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, False)
                    except Exception: pass
    except Exception:
        pass
    created = touched = 0
    for name, space in _INSTANT_KEYMAP_DEFS:
        km = _get_keymap(kc, name, space)
        if km is None:
            continue
        items = list(_find_kmis(km, _INSTANT_ID))
        if not items:
            try:
                kmi = __import__(__package__ + '.ownership_runtime_18168', fromlist=['new_keymap_item']).new_keymap_item(km, _INSTANT_ID, type="LEFTMOUSE", value="PRESS", head=True)
            except TypeError:
                kmi = __import__(__package__ + '.ownership_runtime_18168', fromlist=['new_keymap_item']).new_keymap_item(km, _INSTANT_ID, type="LEFTMOUSE", value="PRESS")
            items = [kmi]; created += 1
        for extra in items[1:]:
            try: __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(km, extra)
            except Exception:
                try: __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(extra, False)
                except Exception: pass
        for kmi in items[:1]:
            _configure_left_press(kmi, active=active)
            touched += 1
    return (created, touched)


def _set_instant_keymaps_active(active: bool):
    if active:
        return _ensure_instant_keymaps(True)
    kc = _addon_keyconfig()
    if kc is None:
        return (0, 0)
    touched = 0
    for name, _space in _INSTANT_KEYMAP_DEFS:
        try:
            km = kc.keymaps.get(name)
            if km is None:
                continue
            for kmi in _find_kmis(km, _INSTANT_ID):
                __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, False); touched += 1
        except Exception:
            pass
    return (0, touched)


def _delete_instant_keymaps():
    return _delete_rows_for_id(_INSTANT_ID)


def _ensure_native_gizmo_rows(active=True):
    # Native Blender/user gizmo keymaps are foreign resources and remain untouched.
    del active
    return (0, 0)


def _gizmo_enable_native_only():
    try:
        from . import uv_gizmo_grip_fix as _gizmo
        _gizmo.set_enabled(True)
    except Exception:
        pass
    return None


def _gizmo_disable_native_only(delete=False):
    del delete
    try:
        from . import uv_gizmo_grip_fix as _gizmo
        _gizmo.set_enabled(False)
    except Exception:
        pass
    return None


def _apply_keymap_exports():
    if not isinstance(_PG, dict):
        return
    try:
        bi = _PG.get("bl_info")
        if isinstance(bi, dict):
            bi["version"] = (1, 0, 0)
        _PG["__version__"] = '1.0.0'
    except Exception:
        pass
    _PG["_SUS_1830_INSTANT_KEYMAP_DEFS"] = tuple(_INSTANT_KEYMAP_DEFS)
    _PG["_SUS_1832_INSTANT_KEYMAP_DEFS"] = tuple(_INSTANT_KEYMAP_DEFS)
    _PG["_SUS_1834_INSTANT_KEYMAP_DEFS"] = tuple(_INSTANT_KEYMAP_DEFS)
    _PG["_SUS_1850_GIZMO_KEYMAP_DEFS"] = tuple()
    _PG["_SUS_1853_NATIVE_GIZMO_KEYMAP_NAMES"] = tuple(_NATIVE_GIZMO_KEYMAP_NAMES)
    _PG["_sus_1830_keymap_defs"] = lambda: tuple(_INSTANT_KEYMAP_DEFS)
    _PG["_sus_1834_keymap_defs"] = lambda: tuple(_INSTANT_KEYMAP_DEFS)
    _PG["_sus_1652_ensure_instant_keymaps"] = _ensure_instant_keymaps
    _PG["_sus_1652_promote_instant_keymaps_to_head"] = _ensure_instant_keymaps
    _PG["_sus_1652_set_instant_keymaps_active"] = _set_instant_keymaps_active
    _PG["_sus_1652_delete_instant_keymaps"] = _delete_instant_keymaps
    _PG["_sus_1652_gizmo_enable"] = _gizmo_enable_native_only
    _PG["_sus_1652_gizmo_disable"] = _gizmo_disable_native_only
    _PG["_sus_1869_press_select_native_handoff"] = True


def apply_all(pkg_globals=None, context=None):
    global _PG
    if pkg_globals is not None:
        _PG = pkg_globals
    ctx = context or bpy.context
    _apply_keymap_exports()
    _patch_instant_class()
    try:
        ws_fn = _PG.get("_sus_1652_ws") if isinstance(_PG, dict) else None
        ws = ws_fn(ctx) if callable(ws_fn) else getattr(getattr(ctx, "scene", None), "suv_workspace", None)
        if ws is not None:
            if bool(getattr(ws, "operation_instant_select_enabled", False)):
                _ensure_instant_keymaps(True)
            else:
                _set_instant_keymaps_active(False)
            if bool(getattr(ws, "operation_uv_gizmo_grip_fix_enabled", False)):
                _gizmo_enable_native_only()
            else:
                _gizmo_disable_native_only(delete=False)
    except Exception:
        pass
    try:
        if isinstance(_PG, dict):
            _PG["_sus_1652_sync_keymaps_from_workspace"] = _sync
            _PG["_sus_1841_final_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1842_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1845_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1860_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1867_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1868_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
    except Exception:
        pass


def _sync(context=None):
    apply_all(_PG, context or bpy.context)


def install(pkg_globals):
    global _PG
    _PG = pkg_globals
    apply_all(pkg_globals, bpy.context)
