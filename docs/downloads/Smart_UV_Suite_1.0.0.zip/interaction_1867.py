# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Absolute final immediate-select override.

This file exists because older compatibility blocks can re-apply 1.8.65 after
newer modules.  It is imported after every previous interaction block and forces
the intended 1.8.66 behavior to remain active after register and keymap sync.
"""
from __future__ import annotations

import bpy

_PG = None
_VERSION = (1, 8, 67)


def _pg(name, default=None):
    try:
        return _PG.get(name, default) if isinstance(_PG, dict) else default
    except Exception:
        return default


def _impl():
    try:
        from . import interaction_1866 as i
        return i
    except Exception:
        return None


def _instant_invoke_1867(self, context, event):
    i = _impl()
    if i is None:
        return {"PASS_THROUGH"}
    return i._instant_invoke_1866(self, context, event)


def _instant_modal_1867(self, context, event):
    return {"PASS_THROUGH"}


def _patch():
    try:
        cls = _pg("SMARTUVSUITE_OT_instant_select_drag_move")
        if not isinstance(cls, type):
            return
        cls.bl_options = {'UNDO'}
        cls.invoke = _instant_invoke_1867
        cls.modal = _instant_modal_1867
        cls._sus1867_absolute_press_native_transform = True
        # Remove stale flags that make tests ambiguous; behavior is now 1.8.67.
        try: cls._sus1865_native_drag_transform = False
        except Exception: pass
    except Exception:
        pass


def apply_all(pkg_globals=None, context=None):
    global _PG
    if pkg_globals is not None:
        _PG = pkg_globals
    ctx = context or bpy.context
    try:
        i = _impl()
        if i is not None:
            i.apply_all(pkg_globals or _PG, ctx)
    except Exception:
        pass
    _patch()
    try:
        if isinstance(_PG, dict):
            bi = _PG.get("bl_info")
            if isinstance(bi, dict):
                bi["version"] = (1, 0, 0)
            _PG["__version__"] = '1.0.0'
            _PG["_sus_1867_absolute_press_native_transform"] = True
            _PG["_sus_1652_sync_keymaps_from_workspace"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1841_final_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1842_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1845_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1860_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1865_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1866_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
    except Exception:
        pass


def install(pkg_globals):
    global _PG
    _PG = pkg_globals
    apply_all(pkg_globals, bpy.context)
