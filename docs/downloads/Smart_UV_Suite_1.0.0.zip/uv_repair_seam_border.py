"""Public seam_border routing."""

import bpy


def run(context, op):
    return "FINISHED" in bpy.ops.uv.suv_auto_seam_advanced(mode="BOUNDARY", scope=(op.scope or "SELECTED").upper())


def build_handlers(api):
    return {"smart_uv_suite.seam_border": api.Handler(run, 'Mark open mesh boundary edges as seams.', '開いたメッシュ境界辺にシームを付けます。')}
