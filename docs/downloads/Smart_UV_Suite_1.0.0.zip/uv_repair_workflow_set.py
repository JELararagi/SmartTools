import bpy


def _set(context, op):
    mode = op.mode.strip().upper()
    if mode not in {'ENABLE', 'DISABLE'}:
        return False
    return 'FINISHED' in bpy.ops.smart_uv_suite.set_always_on(enabled=mode == 'ENABLE')


def build_handlers(api):
    return {
        'smart_uv_suite.workflow_set_always_on': api.Handler(_set, 'Enable or disable the Smart UV always-on setting.', 'Smart UV の常時機能設定を有効または無効にします。'),
    }
