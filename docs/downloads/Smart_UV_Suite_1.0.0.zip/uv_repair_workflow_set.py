# SPDX-License-Identifier: GPL-3.0-or-later
"""Translate the workflow's explicit action into the persistent toggle."""
import bpy


def build_handlers(api):
    def set_activity(_context, operation):
        value = {"ENABLE": True, "DISABLE": False}.get(operation.mode.strip().upper())
        if value is None:
            return False
        return "FINISHED" in bpy.ops.smart_uv_suite.set_always_on(enabled=value)

    return {"smart_uv_suite.workflow_set_always_on": api.Handler(
        set_activity,
        "Set whether Smart UV's persistent tools are active.",
        "Smart UV の常時機能を有効または無効にします。",
    )}
