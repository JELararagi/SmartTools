"""Implement the inspect straight public UV operations."""

import bpy


def inspect_straight(context, op):
    return 'FINISHED' in bpy.ops.uv.suv_straight_line()


def inspect_straight_straight(context, op):
    return 'FINISHED' in bpy.ops.uv.suv_straight_line()


def build_handlers(api):
    quadrify = api.Handler(
        api._run_uv_layout("suv_hs_quad_flow", follow_mode="mode"),
        "Regularize connected UV quads from the active face.",
        "アクティブ面を基準に連結した四角形のUVを整えます。",
    )
    return {
        "smart_uv_suite.inspect_quadrify": quadrify,
        "smart_uv_suite.pack_quadrify": quadrify,

        "smart_uv_suite.inspect_straight": api.Handler(inspect_straight, 'Straighten the selected UV chain.', '選択したUVチェーンを直線化します。'),

        "smart_uv_suite.inspect_straight_straight": api.Handler(inspect_straight_straight, 'Straighten the selected UV chain.', '選択したUVチェーンを直線化します。'),

    }
