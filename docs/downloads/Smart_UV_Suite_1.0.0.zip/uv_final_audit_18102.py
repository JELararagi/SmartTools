# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Compatibility alias for the final Smart UV Suite room integrity backend.

Older in-room validation scripts imported uv_final_audit_18102.  The active
implementation is uv_room_integrity_18103; this module intentionally forwards to
that backend so stale validation/import paths cannot revive old behavior.
"""
from .uv_room_integrity_18103 import *  # noqa: F401,F403
