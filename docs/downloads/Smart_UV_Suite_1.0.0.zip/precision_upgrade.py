from . import core as _core
from . import ui as _ui
from . import flow as _flow
from . import legacy_operators as _legacy
from . import pro_operators as _pro
from . import selection_operators as _select
from . import symmetry_atlas_operators as _sym
from . import native_stage as _stage

bpy = _core.bpy
bmesh = _core.bmesh
math = _core.math
Vector = _core.Vector

_PATCH_MODULES = [_core, _ui, _flow, _legacy, _pro, _select, _sym, _stage]


def _broadcast_attr(name, value):
    for mod in _PATCH_MODULES:
        if hasattr(mod, name):
            try:
                setattr(mod, name, value)
            except Exception:
                pass


def _norm_island_aspect(isl):
    bmin = Vector(getattr(isl, 'bbox_min', Vector((0.0, 0.0))))
    bmax = Vector(getattr(isl, 'bbox_max', Vector((0.0, 0.0))))
    w = max(1.0e-8, float(bmax.x - bmin.x))
    h = max(1.0e-8, float(bmax.y - bmin.y))
    return w / h


# -----------------------------------------------------------------------------
# Deterministic pack upgrade (MaxRects-style packing instead of simple shelves)
# -----------------------------------------------------------------------------

def _candidate_rotations(rot_step_deg, allow_rotate):
    if not allow_rotate or int(rot_step_deg) <= 0:
        return [0.0]
    step = math.radians(int(rot_step_deg))
    # Bounding boxes repeat every 180 degrees; prefer smaller absolute rotations.
    kmax = max(1, int(round(math.pi / step)))
    vals = []
    for k in range(kmax):
        ang = k * step
        if ang >= math.pi - 1.0e-8:
            continue
        vals.append(ang)
    return vals or [0.0]


def _rotation_score(ang):
    # Prefer upright rotations when fit quality is equivalent.
    ang = abs(float(ang)) % math.pi
    return min(ang, abs(math.pi - ang))


def _rect_intersects(a, b, eps=1.0e-9):
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    return not (ax + aw <= bx + eps or bx + bw <= ax + eps or ay + ah <= by + eps or by + bh <= ay + eps)


def _rect_contains(outer, inner, eps=1.0e-9):
    ox, oy, ow, oh = outer
    ix, iy, iw, ih = inner
    return ix >= ox - eps and iy >= oy - eps and ix + iw <= ox + ow + eps and iy + ih <= oy + oh + eps


def _prune_free_rects(rects, eps=1.0e-9):
    cleaned = []
    for rect in rects:
        x, y, w, h = rect
        if w <= eps or h <= eps:
            continue
        contained = False
        for other in rects:
            if rect is other:
                continue
            if _rect_contains(other, rect, eps=eps):
                contained = True
                break
        if not contained:
            cleaned.append((float(x), float(y), float(w), float(h)))
    # Stable deterministic ordering helps reproducibility.
    cleaned.sort(key=lambda r: (round(r[1], 12), round(r[0], 12), round(r[3], 12), round(r[2], 12)))
    return cleaned


def _split_free_rects(free_rects, used_rect, eps=1.0e-9):
    out = []
    ux, uy, uw, uh = used_rect
    ux2 = ux + uw
    uy2 = uy + uh
    for fr in free_rects:
        fx, fy, fw, fh = fr
        fx2 = fx + fw
        fy2 = fy + fh
        if not _rect_intersects(fr, used_rect, eps=eps):
            out.append(fr)
            continue
        if ux > fx + eps:
            out.append((fx, fy, ux - fx, fh))
        if ux2 < fx2 - eps:
            out.append((ux2, fy, fx2 - ux2, fh))
        if uy > fy + eps:
            out.append((fx, fy, fw, uy - fy))
        if uy2 < fy2 - eps:
            out.append((fx, uy2, fw, fy2 - uy2))
    return _prune_free_rects(out, eps=eps)


def _island_rotation_options(isl, margin_uv, rot_step_deg, allow_rotate):
    options = []
    for ang in _candidate_rotations(rot_step_deg, allow_rotate):
        bmin, bmax = _core._island_bbox_after_rotation(isl, ang)
        w, h = _core._bbox_size(bmin, bmax)
        options.append({
            'angle': float(ang),
            'bmin': Vector(bmin),
            'bmax': Vector(bmax),
            'w': float(w),
            'h': float(h),
            'iw': float(w) + float(margin_uv) * 2.0,
            'ih': float(h) + float(margin_uv) * 2.0,
        })
    options.sort(key=lambda it: (round(it['iw'] * it['ih'], 12), round(max(it['iw'], it['ih']), 12), round(_rotation_score(it['angle']), 12)))
    return options or [{
        'angle': 0.0,
        'bmin': Vector(getattr(isl, 'bbox_min', Vector((0.0, 0.0)))),
        'bmax': Vector(getattr(isl, 'bbox_max', Vector((0.0, 0.0)))),
        'w': max(1.0e-8, float(getattr(isl, 'bbox_max', Vector((0.0, 0.0))).x - getattr(isl, 'bbox_min', Vector((0.0, 0.0))).x)),
        'h': max(1.0e-8, float(getattr(isl, 'bbox_max', Vector((0.0, 0.0))).y - getattr(isl, 'bbox_min', Vector((0.0, 0.0))).y)),
        'iw': max(1.0e-8, float(getattr(isl, 'bbox_max', Vector((0.0, 0.0))).x - getattr(isl, 'bbox_min', Vector((0.0, 0.0))).x)) + float(margin_uv) * 2.0,
        'ih': max(1.0e-8, float(getattr(isl, 'bbox_max', Vector((0.0, 0.0))).y - getattr(isl, 'bbox_min', Vector((0.0, 0.0))).y)) + float(margin_uv) * 2.0,
    }]


def _choose_best_rect_fit(free_rects, options, tile_index=0):
    best = None
    for ridx, fr in enumerate(free_rects):
        fx, fy, fw, fh = fr
        for opt in options:
            iw = opt['iw']
            ih = opt['ih']
            if iw <= fw + 1.0e-9 and ih <= fh + 1.0e-9:
                waste = fw * fh - iw * ih
                short = min(fw - iw, fh - ih)
                long_ = max(fw - iw, fh - ih)
                score = (
                    round(tile_index, 12),
                    round(waste, 12),
                    round(short, 12),
                    round(long_, 12),
                    round(_rotation_score(opt['angle']), 12),
                    ridx,
                )
                if best is None or score < best[0]:
                    best = (score, ridx, fr, opt)
    return best


def _pack_into_single_bin(ordered_specs, margin_uv):
    free_rects = [(0.0, 0.0, 1.0, 1.0)]
    placements = {}
    for spec in ordered_specs:
        isl = spec['island']
        choice = _choose_best_rect_fit(free_rects, spec['options'], tile_index=0)
        if choice is None:
            return placements, False
        _score, _ridx, fr, opt = choice
        fx, fy, _fw, _fh = fr
        placements[isl.id] = {
            'angle': opt['angle'],
            'bmin': opt['bmin'],
            'bmax': opt['bmax'],
            'dx': (fx + margin_uv) - opt['bmin'].x,
            'dy': (fy + margin_uv) - opt['bmin'].y,
        }
        free_rects = _split_free_rects(free_rects, (fx, fy, opt['iw'], opt['ih']))
    return placements, True


def _precision_pack_shelf(islands, margin_uv: float, rot_step_deg: int, allow_rotate: bool):
    margin_uv = max(0.0, float(margin_uv))
    ordered_specs = []
    for isl in islands or []:
        options = _island_rotation_options(isl, margin_uv, rot_step_deg, allow_rotate)
        primary = options[0]
        ordered_specs.append({
            'island': isl,
            'options': options,
            'sort': (
                -round(max(primary['iw'], primary['ih']), 12),
                -round(min(primary['iw'], primary['ih']), 12),
                -round(primary['iw'] * primary['ih'], 12),
                int(getattr(isl, 'id', 0)),
            ),
        })
    ordered_specs.sort(key=lambda it: it['sort'])
    return _pack_into_single_bin(ordered_specs, margin_uv)


def _precision_pack_multi_tiles(islands, margin_uv: float, rot_step_deg: int, allow_rotate: bool):
    margin_uv = max(0.0, float(margin_uv))
    ordered_specs = []
    for isl in islands or []:
        options = _island_rotation_options(isl, margin_uv, rot_step_deg, allow_rotate)
        primary = options[0]
        ordered_specs.append({
            'island': isl,
            'options': options,
            'sort': (
                -round(max(primary['iw'], primary['ih']), 12),
                -round(min(primary['iw'], primary['ih']), 12),
                -round(primary['iw'] * primary['ih'], 12),
                int(getattr(isl, 'id', 0)),
            ),
        })
    ordered_specs.sort(key=lambda it: it['sort'])

    bins = [{'free_rects': [(0.0, 0.0, 1.0, 1.0)]}]
    placements = {}
    for spec in ordered_specs:
        isl = spec['island']
        best = None
        for tile_index, tile in enumerate(bins):
            choice = _choose_best_rect_fit(tile['free_rects'], spec['options'], tile_index=tile_index)
            if choice is None:
                continue
            if best is None or choice[0] < best[0]:
                best = choice + (tile_index,)
        if best is None:
            bins.append({'free_rects': [(0.0, 0.0, 1.0, 1.0)]})
            tile_index = len(bins) - 1
            choice = _choose_best_rect_fit(bins[-1]['free_rects'], spec['options'], tile_index=tile_index)
            if choice is None:
                # Oversize island: keep deterministic placement at the origin of a new tile.
                opt = min(spec['options'], key=lambda it: (round(it['iw'] * it['ih'], 12), round(_rotation_score(it['angle']), 12)))
                placements[isl.id] = {
                    'angle': opt['angle'],
                    'bmin': opt['bmin'],
                    'bmax': opt['bmax'],
                    'dx': margin_uv - opt['bmin'].x,
                    'dy': margin_uv - opt['bmin'].y,
                    'tile_index': tile_index,
                }
                continue
            best = choice + (tile_index,)
        _score, _ridx, fr, opt, tile_index = best
        fx, fy, _fw, _fh = fr
        placements[isl.id] = {
            'angle': opt['angle'],
            'bmin': opt['bmin'],
            'bmax': opt['bmax'],
            'dx': (fx + margin_uv) - opt['bmin'].x,
            'dy': (fy + margin_uv) - opt['bmin'].y,
            'tile_index': int(tile_index),
        }
        bins[tile_index]['free_rects'] = _split_free_rects(bins[tile_index]['free_rects'], (fx, fy, opt['iw'], opt['ih']))
    return placements


# -----------------------------------------------------------------------------
# Grouping + symmetry pairing upgrades
# -----------------------------------------------------------------------------

def _precision_group_islands_by_mode(islands, mode='SIMILAR', area_tol=0.08, aspect_tol=0.15):
    islands = [isl for isl in (islands or []) if isl is not None]
    if not islands:
        return []
    mode = str(mode or 'SIMILAR').upper()
    if mode == 'MATERIAL':
        buckets = {}
        for isl in islands:
            buckets.setdefault(_ui._dominant_material_index(isl), []).append(isl)
        return [{"label": f"MAT_{k}", "ref": v[0], "islands": v} for k, v in sorted(buckets.items(), key=lambda kv: kv[0])]

    strict = (mode == 'IDENTICAL')
    ordered = sorted(
        islands,
        key=lambda i: (
            len(getattr(i, 'faces', [])),
            len(getattr(i, 'vert_ids', set()) or set()),
            float(getattr(i, 'abs_area', 0.0)),
        ),
        reverse=True,
    )
    groups = []
    for isl in ordered:
        placed = False
        best_grp = None
        best_score = None
        area_i = max(1.0e-8, float(getattr(isl, 'abs_area', 0.0)))
        aspect_i = max(1.0e-8, _norm_island_aspect(isl))
        faces_i = len(getattr(isl, 'faces', []))
        verts_i = len(getattr(isl, 'vert_ids', set()) or set())
        for grp in groups:
            ref = grp['ref']
            area_r = max(1.0e-8, float(getattr(ref, 'abs_area', 0.0)))
            aspect_r = max(1.0e-8, _norm_island_aspect(ref))
            faces_r = len(getattr(ref, 'faces', []))
            verts_r = len(getattr(ref, 'vert_ids', set()) or set())
            area_rel = abs(area_i / area_r - 1.0)
            aspect_rel = abs(aspect_i / aspect_r - 1.0)
            face_rel = abs(faces_i - faces_r) / max(faces_i, faces_r, 1)
            vert_rel = abs(verts_i - verts_r) / max(verts_i, verts_r, 1)
            shape = float(_stage._suv_island_match_score(ref, isl))

            if strict:
                if faces_i != faces_r or verts_i != verts_r:
                    continue
                if area_rel > max(0.025, float(area_tol) * 0.5):
                    continue
                if aspect_rel > max(0.04, float(aspect_tol) * 0.5):
                    continue
                if shape > 0.18:
                    continue
            else:
                if area_rel > max(0.20, float(area_tol) * 1.5):
                    continue
                if aspect_rel > max(0.25, float(aspect_tol) * 1.5):
                    continue
                if face_rel > 0.40 or vert_rel > 0.45:
                    continue
                if shape > max(0.35, 0.18 + float(area_tol) + float(aspect_tol)):
                    continue
            score = (
                round(shape, 12),
                round(area_rel, 12),
                round(aspect_rel, 12),
                round(face_rel, 12),
                round(vert_rel, 12),
            )
            if best_score is None or score < best_score:
                best_score = score
                best_grp = grp
        if best_grp is None:
            groups.append({"label": f"{mode}_{len(groups)+1}", "ref": isl, "islands": [isl]})
        else:
            best_grp['islands'].append(isl)
    return groups


def _precision_detect_sym_pairs(islands, vmap):
    islands = [isl for isl in (islands or []) if isl is not None]
    if not islands:
        return {}
    id_by_vert = {}
    isl_by_id = {}
    for isl in islands:
        isl_by_id[isl.id] = isl
        for vid in getattr(isl, 'vert_ids', set()) or set():
            id_by_vert[vid] = isl.id

    coverage = {}
    for isl in islands:
        mapped = [vmap.get(vid, None) for vid in (getattr(isl, 'vert_ids', set()) or set())]
        mapped = [m for m in mapped if m is not None]
        counts = {}
        for m in mapped:
            other = id_by_vert.get(m, None)
            if other is None or other == isl.id:
                continue
            counts[other] = counts.get(other, 0) + 1
        denom = max(1, len(getattr(isl, 'vert_ids', set()) or set()))
        coverage[isl.id] = {other: cnt / denom for other, cnt in counts.items()}

    pair_scores = []
    seen_keys = set()
    for a_id, cand in coverage.items():
        for b_id, cov_a in cand.items():
            if a_id == b_id:
                continue
            key = tuple(sorted((a_id, b_id)))
            if key in seen_keys:
                continue
            seen_keys.add(key)
            isl_a = isl_by_id.get(a_id)
            isl_b = isl_by_id.get(b_id)
            if isl_a is None or isl_b is None:
                continue
            cov_b = coverage.get(b_id, {}).get(a_id, 0.0)
            cov_avg = 0.5 * (float(cov_a) + float(cov_b))
            shape = float(_stage._suv_island_match_score(isl_a, isl_b))
            area_a = max(1.0e-8, float(getattr(isl_a, 'abs_area', 0.0)))
            area_b = max(1.0e-8, float(getattr(isl_b, 'abs_area', 0.0)))
            area_rel = abs(area_a / area_b - 1.0)
            aspect_rel = abs(_norm_island_aspect(isl_a) / max(_norm_island_aspect(isl_b), 1.0e-8) - 1.0)
            if cov_avg < 0.25 and shape > 0.18:
                continue
            if area_rel > 0.40 or aspect_rel > 0.45:
                continue
            total = (1.0 - cov_avg) * 0.60 + shape * 0.28 + area_rel * 0.07 + aspect_rel * 0.05
            if total <= 0.70 or cov_avg >= 0.55 or shape <= 0.14:
                pair_scores.append((
                    round(total, 12),
                    -round(cov_avg, 12),
                    round(shape, 12),
                    min(a_id, b_id),
                    max(a_id, b_id),
                ))

    used = set()
    pairs = {}
    for _total, _neg_cov, _shape, a_id, b_id in sorted(pair_scores):
        if a_id in used or b_id in used:
            continue
        pairs[a_id] = b_id
        pairs[b_id] = a_id
        used.add(a_id)
        used.add(b_id)
    return pairs


# -----------------------------------------------------------------------------
# Tile + density helpers
# -----------------------------------------------------------------------------

def _precision_active_tile_offset_from_islands(islands):
    islands = [isl for isl in (islands or []) if isl is not None]
    if not islands:
        return Vector((0.0, 0.0))
    weights = {}
    for isl in islands:
        c = Vector(getattr(isl, 'uv_centroid', Vector((0.0, 0.0))))
        tile = (int(math.floor(c.x)), int(math.floor(c.y)))
        weights[tile] = weights.get(tile, 0.0) + max(1.0e-6, float(getattr(isl, 'abs_area', 0.0)))
    tile = sorted(weights.items(), key=lambda kv: (-kv[1], kv[0][1], kv[0][0]))[0][0]
    return Vector((float(tile[0]), float(tile[1])))


def _density_from_faces(obj, faces, uv_layer, texture_size, use_world_scale):
    faces = [f for f in (faces or []) if f is not None]
    if not faces:
        return 0.0
    uv_area = 0.0
    area3d = 0.0
    for face in faces:
        uv_area += abs(_core._signed_uv_area(face, uv_layer))
        if use_world_scale:
            area3d += _core._world_face_area(obj, face)
        else:
            try:
                area3d += float(face.calc_area())
            except Exception:
                pass
    if uv_area <= 1.0e-12 or area3d <= 1.0e-12:
        return 0.0
    return (math.sqrt(uv_area) * float(texture_size)) / math.sqrt(area3d)


def _density_for_island(obj, isl, uv_layer, texture_size, use_world_scale):
    return _density_from_faces(obj, getattr(isl, 'faces', []) or [], uv_layer, texture_size, use_world_scale)


# -----------------------------------------------------------------------------
# Operator upgrades
# -----------------------------------------------------------------------------

def _align_islands_execute(self, context):
    obj = _core._active_mesh_obj(context)
    if not obj:
        self.report({'WARNING'}, _flow.tr(context, 'msg.no_active_mesh'))
        return {'CANCELLED'}
    count = 0
    with _core._TempMode(context, obj, 'EDIT'):
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        islands = _flow._islands_for_scope(context, obj, bm, uv_layer, self.scope)
        if not islands:
            self.report({'WARNING'}, _flow.tr(context, 'msg.no_selection'))
            return {'CANCELLED'}
        active_face = getattr(bm.faces, 'active', None)
        ref = None
        if active_face is not None:
            for isl in islands:
                if active_face in getattr(isl, 'faces', []):
                    ref = isl
                    break
        anchors = []
        for isl in islands:
            bmin = Vector(getattr(isl, 'bbox_min', Vector((0.0, 0.0))))
            bmax = Vector(getattr(isl, 'bbox_max', Vector((0.0, 0.0))))
            anchors.append(_flow._anchor_from_bbox(bmin, bmax, self.axis, self.mode))
        if ref is not None:
            target = _flow._anchor_from_bbox(Vector(ref.bbox_min), Vector(ref.bbox_max), self.axis, self.mode)
        else:
            vals = sorted(float(v) for v in anchors)
            mid = len(vals) // 2
            target = vals[mid] if len(vals) % 2 else 0.5 * (vals[mid - 1] + vals[mid])
        for isl in islands:
            own = _flow._anchor_from_bbox(Vector(isl.bbox_min), Vector(isl.bbox_max), self.axis, self.mode)
            delta = Vector((target - own, 0.0)) if self.axis == 'U' else Vector((0.0, target - own))
            if delta.length_squared > 1.0e-18:
                _flow._translate_island(isl, uv_layer, delta)
            count += 1
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    self.report({'INFO'}, _flow.tr(context, 'msg.align_done', n=count))
    return {'FINISHED'}


def _centralize_islands_execute(self, context):
    obj = _core._active_mesh_obj(context)
    if not obj:
        self.report({'WARNING'}, _flow.tr(context, 'msg.no_active_mesh'))
        return {'CANCELLED'}
    count = 0
    with _core._TempMode(context, obj, 'EDIT'):
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        islands = _flow._islands_for_scope(context, obj, bm, uv_layer, self.scope)
        if not islands:
            self.report({'WARNING'}, _flow.tr(context, 'msg.no_selection'))
            return {'CANCELLED'}
        gmin, gmax = _flow._group_bbox(islands)
        own_u = _flow._anchor_from_bbox(gmin, gmax, axis='U', mode='CENTER')
        own_v = _flow._anchor_from_bbox(gmin, gmax, axis='V', mode='CENTER')
        tile_off = _precision_active_tile_offset_from_islands(islands)
        delta = Vector((tile_off.x + 0.5 - own_u, tile_off.y + 0.5 - own_v))
        for isl in islands:
            _flow._translate_island(isl, uv_layer, delta)
            count += 1
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    self.report({'INFO'}, _flow.tr(context, 'msg.center_done', n=count))
    return {'FINISHED'}


def _smart_seams_execute(self, context):
    obj = _core._active_mesh_obj(context)
    if not obj:
        self.report({'WARNING'}, _legacy.tr(context, 'msg.no_active_mesh'))
        return {'CANCELLED'}
    with _core._TempMode(context, obj, 'EDIT'):
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        sel_faces, _sel_loops, _active_face, _src = _core._selection_from_context(context, obj, bm, uv_layer)
        faces = sel_faces or list(bm.faces)
        if not faces:
            self.report({'WARNING'}, _legacy.tr(context, 'msg.no_selection'))
            return {'CANCELLED'}
        face_set = set(faces)
        edges = set(_stage._suv_auto_cut_edges(faces, uv_layer, angle_limit_deg=math.degrees(float(self.angle_threshold))))
        for face in faces:
            for loop in getattr(face, 'loops', []):
                edge = loop.edge
                if len(getattr(edge, 'link_faces', [])) != 2:
                    edges.add(edge)
                    continue
                linked = list(edge.link_faces)
                if any(other not in face_set for other in linked):
                    edges.add(edge)
                    continue
                try:
                    if linked[0].material_index != linked[1].material_index:
                        edges.add(edge)
                        continue
                except Exception:
                    pass
                try:
                    if getattr(edge, 'smooth', True) is False:
                        edges.add(edge)
                        continue
                except Exception:
                    pass
        seam_count = 0
        for edge in edges:
            if not getattr(edge, 'seam', False):
                edge.seam = True
                seam_count += 1
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    self.report({'INFO'}, _legacy.tr(context, 'msg.seams_marked', n=seam_count))
    return {'FINISHED'}


def _smart_edge_straighten_execute(self, context):
    obj = _core._active_mesh_obj(context)
    if not obj:
        self.report({'WARNING'}, _legacy.tr(context, 'msg.no_active_mesh'))
        return {'CANCELLED'}
    with _core._TempMode(context, obj, 'EDIT'):
        ok, msg = _flow._apply_uv_chain_line(context, even=False)
        if ok:
            self.report({'INFO'}, msg)
            return {'FINISHED'}
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        sel_faces, _sel_loops, _active_face, _src = _core._selection_from_context(context, obj, bm, uv_layer)
        if not sel_faces:
            self.report({'WARNING'}, _legacy.tr(context, 'msg.no_selection'))
            return {'CANCELLED'}
        islands = _core.build_islands(bm, uv_layer, faces_subset=sel_faces)
        changed = 0
        for isl in islands:
            if _stage._suv_straighten_island(isl, uv_layer):
                changed += 1
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    if changed:
        self.report({'INFO'}, _legacy.tr(context, 'msg.straighten_done'))
        return {'FINISHED'}
    self.report({'WARNING'}, msg)
    return {'CANCELLED'}


def _orthogonalize_execute(self, context):
    obj = _core._active_mesh_obj(context)
    if not obj:
        self.report({'WARNING'}, _flow.tr(context, 'msg.no_active_mesh'))
        return {'CANCELLED'}
    count = 0
    with _core._TempMode(context, obj, 'EDIT'):
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        islands = _flow._islands_for_scope(context, obj, bm, uv_layer, self.scope)
        if not islands:
            self.report({'WARNING'}, _flow.tr(context, 'msg.no_selection'))
            return {'CANCELLED'}
        for isl in islands:
            if _stage._suv_straighten_island(isl, uv_layer):
                count += 1
            else:
                ang = _flow._best_bbox_angle(isl, step_deg=max(1, int(getattr(self, 'step_deg', 5))))
                _flow._rotate_island(isl, uv_layer, ang)
                _flow._refresh_island_metrics(isl, uv_layer)
                count += 1
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    self.report({'INFO'}, _flow.tr(context, 'msg.ortho_done', n=count))
    return {'FINISHED'}


def _stack_pair_precise(uv_layer, ref, isl, rot_step_deg, allow_mirror):
    if ref is None or isl is None or ref is isl:
        return
    ok = False
    try:
        ok = bool(_stage._suv_match_island_to_reference(ref, isl, uv_layer, uniform=True, allow_mirror=allow_mirror))
    except Exception:
        ok = False
    if ok:
        try:
            _flow._refresh_island_metrics(isl, uv_layer)
        except Exception:
            pass
        return
    # Conservative fallback to the original simplified matcher.
    _stack_pair_original(uv_layer, ref, isl, rot_step_deg, allow_mirror)


def _texel_get_execute(self, context):
    obj = _core._active_mesh_obj(context)
    if not obj:
        self.report({'WARNING'}, _pro.tr(context, 'msg.no_active_mesh'))
        return {'CANCELLED'}
    with _core._TempMode(context, obj, 'EDIT'):
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        if self.scope == 'ALL':
            faces = list(bm.faces)
            active_face = getattr(bm.faces, 'active', None)
        else:
            faces, _sl, active_face, _src = _core._selection_from_context(context, obj, bm, uv_layer)
        if not faces:
            self.report({'WARNING'}, _pro.tr(context, 'msg.no_selection'))
            return {'CANCELLED'}
        if self.scope == 'ACTIVE' and active_face is not None:
            islands = _core.build_islands(bm, uv_layer, faces_subset=faces)
            active_isl = next((isl for isl in islands if active_face in getattr(isl, 'faces', [])), None)
            faces = list(getattr(active_isl, 'faces', []) or []) if active_isl is not None else faces
        density = _density_from_faces(obj, faces, uv_layer, self.texture_size, self.use_world_scale)
        if density <= 0.0:
            self.report({'WARNING'}, _pro.tr(context, 'msg.op_failed', e='Zero area'))
            return {'CANCELLED'}
    _core._cache_set(context.scene, 'last_density', float(density))
    self.report({'INFO'}, _pro.tr(context, 'msg.texel_sampled', d=density))
    return {'FINISHED'}


def _texel_set_execute(self, context):
    obj = _core._active_mesh_obj(context)
    if not obj:
        self.report({'WARNING'}, _pro.tr(context, 'msg.no_active_mesh'))
        return {'CANCELLED'}
    n = 0
    with _core._TempMode(context, obj, 'EDIT'):
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        if self.scope == 'ALL':
            faces = list(bm.faces)
        else:
            faces, _sl, _active_face, _src = _core._selection_from_context(context, obj, bm, uv_layer)
        if not faces:
            self.report({'WARNING'}, _pro.tr(context, 'msg.no_selection'))
            return {'CANCELLED'}
        islands = _core.build_islands(bm, uv_layer, faces_subset=faces)
        for isl in islands:
            if self.skip_pinned and getattr(isl, 'has_pin', False):
                continue
            density = _density_for_island(obj, isl, uv_layer, self.texture_size, self.use_world_scale)
            if density <= 0.0:
                continue
            scale = float(self.target_density) / float(density)
            pivot = Vector(getattr(isl, 'uv_centroid', Vector((0.0, 0.0))))
            tile = (int(math.floor(pivot.x)), int(math.floor(pivot.y)))
            tile_off = Vector((float(tile[0]), float(tile[1])))
            local_pivot = pivot - tile_off
            def _tf(u):
                uv = Vector(u)
                if self.keep_tile:
                    local = uv - tile_off
                    return tile_off + local_pivot + (local - local_pivot) * scale
                return pivot + (uv - pivot) * scale
            _core._island_apply_transform(isl, uv_layer, _tf)
            n += 1
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    self.report({'INFO'}, _pro.tr(context, 'msg.texel_norm_done', n=n))
    return {'FINISHED'}


def _texel_normalize_execute(self, context):
    obj = _core._active_mesh_obj(context)
    if not obj:
        self.report({'WARNING'}, _pro.tr(context, 'msg.no_active_mesh'))
        return {'CANCELLED'}
    n = 0
    with _core._TempMode(context, obj, 'EDIT'):
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        sel_faces, _sl, active_face, _src = _core._selection_from_context(context, obj, bm, uv_layer)
        if not sel_faces:
            self.report({'WARNING'}, _pro.tr(context, 'msg.no_selection'))
            return {'CANCELLED'}
        islands = _core.build_islands(bm, uv_layer, faces_subset=sel_faces)
        if not islands:
            self.report({'WARNING'}, _pro.tr(context, 'msg.no_selection'))
            return {'CANCELLED'}
        target = None
        if self.mode == 'VALUE':
            target = float(self.value_density)
        elif self.mode == 'ACTIVE' and active_face is not None:
            active_isl = next((isl for isl in islands if active_face in getattr(isl, 'faces', [])), None)
            if active_isl is not None:
                target = _density_for_island(obj, active_isl, uv_layer, self.texture_size, self.use_world_scale)
        elif self.mode == 'UNSELECTED':
            unselected_faces = [f for f in bm.faces if f not in set(sel_faces)]
            target = _density_from_faces(obj, unselected_faces, uv_layer, self.texture_size, self.use_world_scale)
        if target is None or target <= 0.0:
            movable_faces = []
            for isl in islands:
                if self.skip_pinned and getattr(isl, 'has_pin', False):
                    continue
                movable_faces.extend(getattr(isl, 'faces', []) or [])
            target = _density_from_faces(obj, movable_faces, uv_layer, self.texture_size, self.use_world_scale)
            if target <= 0.0:
                target = float(self.value_density)
        keep_tile = bool(getattr(self, 'keep_tile', True))
        for isl in islands:
            if self.skip_pinned and getattr(isl, 'has_pin', False):
                continue
            density = _density_for_island(obj, isl, uv_layer, self.texture_size, self.use_world_scale)
            if density <= 0.0:
                continue
            scale = float(target) / float(density)
            pivot = Vector(getattr(isl, 'uv_centroid', Vector((0.0, 0.0))))
            tile = (int(math.floor(float(pivot.x))), int(math.floor(float(pivot.y))))
            tile_off = Vector((float(tile[0]), float(tile[1])))
            local_pivot = pivot - tile_off
            def _tf(u, _p=pivot, _s=scale, _tile_off=tile_off, _local_pivot=local_pivot, _keep_tile=keep_tile):
                uv = Vector(u)
                if _keep_tile:
                    local = uv - _tile_off
                    return _tile_off + _local_pivot + (local - _local_pivot) * _s
                return _p + (uv - _p) * _s
            _core._island_apply_transform(isl, uv_layer, _tf)
            n += 1
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    self.report({'INFO'}, _pro.tr(context, 'msg.texel_norm_done', n=n))
    return {'FINISHED'}


def _island_face_orientation(isl, uv_layer, eps):
    pos = 0.0
    neg = 0.0
    zero = 0
    for face in getattr(isl, 'faces', []) or []:
        area = float(_core._signed_uv_area(face, uv_layer))
        if area > eps:
            pos += area
        elif area < -eps:
            neg += -area
        else:
            zero += 1
    return pos, neg, zero


def _inspector_scan_execute(self, context):
    obj = _core._active_mesh_obj(context)
    if not obj:
        self.report({'WARNING'}, _pro.tr(context, 'msg.no_active_mesh'))
        return {'CANCELLED'}
    with _core._TempMode(context, obj, 'EDIT'):
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        faces = list(bm.faces) if self.scope == 'ALL' else [f for f in bm.faces if f.select]
        if not faces:
            self.report({'WARNING'}, _pro.tr(context, 'msg.no_selection'))
            return {'CANCELLED'}
        islands = _core.build_islands(bm, uv_layer, faces_subset=faces)
        flipped = []
        zero = []
        out = []
        overlap = []
        stretch = []
        stretch_details = []
        stretch_scores = []
        candidate_pairs = []
        for isl in islands:
            pos_area, neg_area, zero_faces = _island_face_orientation(isl, uv_layer, float(self.eps_zero))
            total_abs = pos_area + neg_area
            if neg_area > max(float(self.eps_zero), pos_area * 1.01) and total_abs > float(self.eps_zero):
                flipped.append(isl.face_sig)
            if total_abs <= float(self.eps_zero) or zero_faces > 0:
                zero.append(isl.face_sig)
            if self.check_out_of_tile:
                tile_off = _precision_active_tile_offset_from_islands([isl])
                bmin0 = Vector(getattr(isl, 'bbox_min', Vector((0.0, 0.0)))) - tile_off
                bmax0 = Vector(getattr(isl, 'bbox_max', Vector((0.0, 0.0)))) - tile_off
                if bmin0.x < 0.0 or bmin0.y < 0.0 or bmax0.x > 1.0 or bmax0.y > 1.0:
                    out.append(isl.face_sig)
            if self.check_stretch:
                score, _ = _ui._island_stretch_score(isl, obj, uv_layer)
                stretch_scores.append(score)
                if score >= max(1.01, float(self.stretch_threshold)):
                    stretch.append(isl.face_sig)
                    stretch_details.append(round(float(score), 4))
        if self.check_overlap:
            for i, a in enumerate(islands):
                for b in islands[i + 1:]:
                    if not (
                        a.bbox_min.x <= b.bbox_max.x and a.bbox_max.x >= b.bbox_min.x and
                        a.bbox_min.y <= b.bbox_max.y and a.bbox_max.y >= b.bbox_min.y
                    ):
                        continue
                    candidate_pairs.append((a, b))
            use_precise = bool(self.precise_overlap) or len(candidate_pairs) <= 200
            if use_precise:
                for a, b in candidate_pairs:
                    try:
                        if _pro._islands_overlap_precise(a, b, uv_layer):
                            overlap.append((a.face_sig, b.face_sig))
                    except Exception as exc:
                        try:
                            _pro._debug(context, f'Precise overlap failed: {exc}')
                        except Exception:
                            pass
                        overlap.append((a.face_sig, b.face_sig))
            else:
                overlap = [(a.face_sig, b.face_sig) for a, b in candidate_pairs]
        _core._cache_set(context.scene, 'inspect_flipped', flipped)
        _core._cache_set(context.scene, 'inspect_zero', zero)
        _core._cache_set(context.scene, 'inspect_out', out)
        _core._cache_set(context.scene, 'inspect_overlap', overlap)
        _core._cache_set(context.scene, 'inspect_stretch', stretch)
        _core._cache_set(context.scene, 'inspect_stretch_detail', stretch_details)
        worst = max(stretch_scores) if stretch_scores else 1.0
        avg = (sum(stretch_scores) / len(stretch_scores)) if stretch_scores else 1.0
        _pro._suv_store_scan_cache(
            context,
            self.scope,
            self.eps_zero,
            self.check_out_of_tile,
            self.check_overlap,
            bool(self.precise_overlap) or len(candidate_pairs) <= 200,
            len(flipped),
            len(zero),
            len(out),
            len(overlap),
            stretch_count=len(stretch),
            stretch_worst=worst,
            stretch_avg=avg,
        )
    self.report({'INFO'}, _pro.tr(context, 'msg.inspect_summary', f=len(flipped), z=len(zero), o=len(out), p=len(overlap), s=len(stretch)))
    return {'FINISHED'}



def _fix_flipped_execute(self, context):
    obj = _core._active_mesh_obj(context)
    if not obj:
        self.report({'WARNING'}, _pro.tr(context, 'msg.no_active_mesh'))
        return {'CANCELLED'}
    fixed = 0
    with _core._TempMode(context, obj, 'EDIT'):
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        sel_faces, _sl, _active_face, _src = _core._selection_from_context(context, obj, bm, uv_layer)
        faces = sel_faces or list(bm.faces)
        islands = _core.build_islands(bm, uv_layer, faces_subset=faces)
        for isl in islands:
            if self.skip_pinned and getattr(isl, 'has_pin', False):
                continue
            pos_before, neg_before, _zero_faces = _island_face_orientation(isl, uv_layer, 1.0e-12)
            if neg_before <= pos_before + 1.0e-12:
                continue
            original = [(loop, Vector(loop[uv_layer].uv)) for loop in getattr(isl, 'loops', []) or []]
            pivot = Vector(getattr(isl, 'uv_centroid', Vector((0.0, 0.0))))
            best_state = list(original)
            best_pos = pos_before
            best_neg = neg_before
            improved = False
            for axis in ('X', 'Y'):
                for loop, uv in original:
                    loop[uv_layer].uv = _core._mirror_x(Vector(uv), pivot) if axis == 'X' else _core._mirror_y(Vector(uv), pivot)
                _flow._refresh_island_metrics(isl, uv_layer)
                pos_after, neg_after, _zero_after = _island_face_orientation(isl, uv_layer, 1.0e-12)
                if (neg_after < best_neg - 1.0e-12) or (abs(neg_after - best_neg) <= 1.0e-12 and pos_after > best_pos + 1.0e-12):
                    best_pos = pos_after
                    best_neg = neg_after
                    best_state = [(loop, Vector(loop[uv_layer].uv)) for loop in getattr(isl, 'loops', []) or []]
                    improved = True
                for loop, uv in original:
                    loop[uv_layer].uv = Vector(uv)
            for loop, uv in (best_state if improved else original):
                loop[uv_layer].uv = Vector(uv)
            _flow._refresh_island_metrics(isl, uv_layer)
            if improved and best_neg <= best_pos + 1.0e-12 and best_neg < neg_before - 1.0e-12:
                fixed += 1
            else:
                for loop, uv in original:
                    loop[uv_layer].uv = Vector(uv)
                _flow._refresh_island_metrics(isl, uv_layer)
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    self.report({'INFO'}, _pro.tr(context, 'msg.repair_done', n=fixed))
    return {'FINISHED'}


def _selected_unwrap_strategy(context, obj):
    with _core._TempMode(context, obj, 'EDIT'):
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        sel_faces, _sl, active_face, _src = _core._selection_from_context(context, obj, bm, uv_layer)
        if not sel_faces:
            return None
        face_count = len(sel_faces)
        quad_count = sum(1 for f in sel_faces if len(getattr(f, 'verts', [])) == 4)
        ngon_count = sum(1 for f in sel_faces if len(getattr(f, 'verts', [])) > 4)
        quad_ratio = quad_count / max(1, face_count)
        internal_angles = []
        face_set = set(sel_faces)
        for face in sel_faces:
            for edge in getattr(face, 'edges', []):
                if len(getattr(edge, 'link_faces', [])) == 2 and all(other in face_set for other in edge.link_faces):
                    try:
                        ang = math.degrees(float(edge.calc_face_angle()))
                        if math.isfinite(ang):
                            internal_angles.append(ang)
                    except Exception:
                        pass
        avg_angle = (sum(internal_angles) / len(internal_angles)) if internal_angles else 0.0
        has_active_quad = active_face is not None and active_face in face_set and len(getattr(active_face, 'verts', [])) == 4
        if has_active_quad and quad_ratio >= 0.70 and face_count >= 4:
            return {
                'strategy': 'FOLLOW_ACTIVE_QUADS',
                'quad_ratio': quad_ratio,
                'avg_angle_deg': avg_angle,
                'ngons': ngon_count,
                'has_active_quad': True,
            }
        method = 'ANGLE_BASED' if ngon_count > 0 or avg_angle >= 35.0 else 'CONFORMAL'
        return {
            'strategy': method,
            'quad_ratio': quad_ratio,
            'avg_angle_deg': avg_angle,
            'ngons': ngon_count,
            'has_active_quad': has_active_quad,
        }


def _auto_unwrap_execute(self, context):
    obj = _core._active_mesh_obj(context)
    if not obj:
        self.report({'WARNING'}, _pro.tr(context, 'msg.no_active_mesh'))
        return {'CANCELLED'}

    strategy_info = _selected_unwrap_strategy(context, obj)
    report = _pro._suv_batch_begin(context, 'Auto Unwrap Pro', details={
        'object': getattr(obj, 'name', '-'),
        'do_seams': self.do_seams,
        'do_unwrap': self.do_unwrap,
        'do_relax': self.do_relax,
        'do_pack': self.do_pack,
        'do_qa': self.do_qa,
        'strategy': (strategy_info or {}).get('strategy', 'UNKNOWN'),
        'quad_ratio': round(float((strategy_info or {}).get('quad_ratio', 0.0)), 4),
        'avg_angle_deg': round(float((strategy_info or {}).get('avg_angle_deg', 0.0)), 2),
    })

    with _core._TempMode(context, obj, 'EDIT'):
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        sel_faces, _sel_loops, _active_face, _src = _core._selection_from_context(context, obj, bm, uv_layer)
        if not sel_faces:
            _pro._suv_batch_note(context, report, 'ERROR', 'Selection Check', 'No selected faces available for unwrap', {'object': getattr(obj, 'name', '-')})
            self.report({'WARNING'}, _pro.tr(context, 'msg.no_selection'))
            return _pro._suv_batch_finish(context, report, operator=self)

    if self.do_seams:
        def _step_seams():
            with _core._TempMode(context, obj, 'EDIT'):
                bm = bmesh.from_edit_mesh(obj.data)
                uv_layer = bm.loops.layers.uv.verify()
                sel_faces, _sel_loops, _active_face, _src = _core._selection_from_context(context, obj, bm, uv_layer)
                if not sel_faces:
                    return {'CANCELLED'}
                face_set = set(sel_faces)
                edges = set(_stage._suv_auto_cut_edges(sel_faces, uv_layer, angle_limit_deg=math.degrees(float(self.angle_threshold))))
                for face in sel_faces:
                    for loop in getattr(face, 'loops', []):
                        edge = loop.edge
                        linked = list(getattr(edge, 'link_faces', []))
                        if len(linked) != 2 or any(other not in face_set for other in linked):
                            edges.add(edge)
                            continue
                        try:
                            if linked[0].material_index != linked[1].material_index:
                                edges.add(edge)
                                continue
                        except Exception:
                            pass
                        try:
                            if getattr(edge, 'smooth', True) is False:
                                edges.add(edge)
                        except Exception:
                            pass
                for edge in edges:
                    edge.seam = True
                bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
                return {'FINISHED'}
        _pro._suv_batch_step(context, report, 'Seam Suggest', _step_seams, details={'angle_threshold_deg': round(math.degrees(float(self.angle_threshold)), 3)})
        if _pro._suv_batch_should_stop(context, report):
            return _pro._suv_batch_finish(context, report, operator=self)

    if self.do_unwrap:
        unwrap_details = dict(strategy_info or {})
        def _step_unwrap():
            info = _selected_unwrap_strategy(context, obj) or {}
            unwrap_details.update(info)
            with _core._TempMode(context, obj, 'EDIT'):
                bm = bmesh.from_edit_mesh(obj.data)
                sel_faces, _sel_loops, active_face, _src = _core._selection_from_context(context, obj, bm, bm.loops.layers.uv.verify())
                if not sel_faces:
                    return {'CANCELLED'}
                if info.get('strategy') == 'FOLLOW_ACTIVE_QUADS':
                    if active_face is not None:
                        try:
                            bm.faces.active = active_face
                        except Exception:
                            pass
                        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
                    try:
                        return bpy.ops.uv.follow_active_quads('EXEC_DEFAULT', mode='LENGTH_AVERAGE')
                    except Exception:
                        pass
                method = info.get('strategy') if info.get('strategy') in {'ANGLE_BASED', 'CONFORMAL'} else 'ANGLE_BASED'
                ok, _err = _core._suv_run_unwrap_native(context, method=method, margin=0.001, fill_holes=True, correct_aspect=True, use_subsurf_data=True, margin_method='SCALED')
                return {'FINISHED'} if ok else {'CANCELLED'}
        _pro._suv_batch_step(context, report, 'Unfold Trim', _step_unwrap, fatal=False, details=unwrap_details)
        if _pro._suv_batch_should_stop(context, report):
            return _pro._suv_batch_finish(context, report, operator=self)

    if self.do_relax:
        def _step_relax():
            ok_any = False
            try:
                ok, _err = _core._suv_run_minimize_stretch_native(context, iterations=80, fill_holes=True, blend=0.0)
                ok_any = ok_any or bool(ok)
            except Exception:
                pass
            try:
                ok, _err = _core._run_uv_op(context, bpy.ops.uv.average_islands_scale)
                ok_any = ok_any or bool(ok)
            except Exception:
                pass
            try:
                ok, _err = _core._suv_run_minimize_stretch_native(context, iterations=24, fill_holes=True, blend=0.0)
                ok_any = ok_any or bool(ok)
            except Exception:
                pass
            return {'FINISHED'} if ok_any else {'CANCELLED'}
        _pro._suv_batch_step(context, report, 'Relax', _step_relax, details={'iterations': 104, 'average_islands_scale': True})
        if _pro._suv_batch_should_stop(context, report):
            return _pro._suv_batch_finish(context, report, operator=self)

    if self.do_pack:
        _pro._suv_batch_step(
            context,
            report,
            'Pack Pro',
            lambda: bpy.ops.uv.suv_pack_pro(
                'EXEC_DEFAULT',
                engine=self.pack_engine,
                scope='SELECTED',
                udim_mode=self.pack_udim_mode,
                margin_px=self.pack_margin_px,
                texture_size=self.texture_size,
                rotation_step=self.pack_rotation_step,
                lock_pinned=True,
            ),
            details={
                'engine': self.pack_engine,
                'udim_mode': self.pack_udim_mode,
                'margin_px': self.pack_margin_px,
                'texture_size': self.texture_size,
                'rotation_step': self.pack_rotation_step,
            },
        )
        if _pro._suv_batch_should_stop(context, report):
            return _pro._suv_batch_finish(context, report, operator=self)

    if self.do_qa:
        _pro._suv_batch_step(
            context,
            report,
            'Inspector Scan',
            lambda: bpy.ops.uv.suv_inspector_scan('EXEC_DEFAULT', scope='SELECTED', precise_overlap=True),
            details={'scope': 'SELECTED', 'precise_overlap': True},
        )
        if _pro._suv_batch_should_stop(context, report):
            return _pro._suv_batch_finish(context, report, operator=self)

    if report.get('error', 0) == 0 and report.get('warn', 0) == 0:
        self.report({'INFO'}, _pro.tr(context, 'msg.auto_done'))
    return _pro._suv_batch_finish(context, report, operator=self)


# -----------------------------------------------------------------------------
# Install monkey patches
# -----------------------------------------------------------------------------

_stack_pair_original = _pro.SUV_OT_stack_pro._stack_pair

_broadcast_attr('_pack_shelf', _precision_pack_shelf)
_broadcast_attr('_pack_multi_tiles', _precision_pack_multi_tiles)
_broadcast_attr('_group_islands_by_mode', _precision_group_islands_by_mode)
_broadcast_attr('_detect_sym_pairs', _precision_detect_sym_pairs)
_broadcast_attr('_active_tile_offset_from_islands', _precision_active_tile_offset_from_islands)

try:
    _flow.SUV_OT_align_islands.execute = _align_islands_execute
except Exception:
    pass
try:
    _flow.SUV_OT_centralize_islands.execute = _centralize_islands_execute
except Exception:
    pass
try:
    _flow.SUV_OT_hs_orthogonalize.execute = _orthogonalize_execute
except Exception:
    pass
try:
    _legacy.SUV_OT_smart_seams.execute = _smart_seams_execute
except Exception:
    pass
try:
    _legacy.SUV_OT_smart_edge_straighten.execute = _smart_edge_straighten_execute
except Exception:
    pass
try:
    _pro.SUV_OT_stack_pro._stack_pair = staticmethod(_stack_pair_precise)
except Exception:
    pass
try:
    _pro.SUV_OT_texel_get.execute = _texel_get_execute
except Exception:
    pass
try:
    _pro.SUV_OT_texel_set.execute = _texel_set_execute
except Exception:
    pass
try:
    _pro.SUV_OT_texel_normalize.execute = _texel_normalize_execute
except Exception:
    pass
try:
    _pro.SUV_OT_inspector_scan.execute = _inspector_scan_execute
except Exception:
    pass
try:
    _pro.SUV_OT_inspector_fix_flipped.execute = _fix_flipped_execute
except Exception:
    pass
try:
    _pro.SUV_OT_auto_unwrap_pro.execute = _auto_unwrap_execute
except Exception:
    pass
