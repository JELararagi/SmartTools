# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Reliable UV-unwrapping layer for Smart UV Suite.

This module is intentionally self-contained.  It is registered after the
legacy modules and replaces only UV-unwrapping execution paths.  The goals are:

* preserve user-marked seam topology unless automatic seams are explicitly
  enabled;
* provide deterministic rectangular and reference-line parameterizations;
* preserve UV/mesh selection, pins, seams and non-target UV coordinates;
* keep every method callable from the existing UI without changing unrelated
  panels or operators.
"""
from __future__ import annotations
from . import resource_api_18168 as _suv_resource
from . import ownership_runtime_18168 as _ownership

import inspect
import math
import re
import sys
import traceback
from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Any, Callable, Dict, Iterable, Iterator, List, Mapping, MutableMapping, Optional, Sequence, Set, Tuple

import bpy
import bmesh
from bpy.props import BoolProperty
from mathutils import Vector

try:
    import numpy as _np
except Exception:  # Blender normally bundles NumPy, but retain a safe fallback.
    _np = None

_VERSION = (1, 0, 0)
_VERSION_STR = "1.0.0"
_SCENE_PROP = "suv_unwrap_enable_auto_seams"
_PATCH_ATTR = "_suv_unwrap_rebuild_18131"
_PATCHED_CLASSES: List[type] = []
_ORIGINAL_EXECUTES: Dict[type, Callable[..., Any]] = {}
_ORIGINAL_DESCRIPTIONS: Dict[type, Any] = {}
_PANEL_CLASS: Optional[type] = None
_PANEL_DRAW: Optional[Callable[..., Any]] = None
_DYNAMIC_PANEL_CLASS: Optional[type] = None
_PANEL_HAS_EXISTING_CONTROL = False
_TIMER_RUNS = 0
_TRANSLATION_KEY = __name__

# Only these public operators are part of the UV Unwrap panel.  Never use
# label/source token heuristics to intercept read-only I/O or unrelated tools.
_TARGET_UNWRAP_OPERATOR_IDS = frozenset({
    "smart_uv_suite.unwrap_auto_action",
    "smart_uv_suite.unwrap_auto_run",
})
_UNWRAP_PATCH_EXCLUDED_IDNAMES = frozenset({
    "smart_uv_suite.export_uv_layout",
})


def _addon_package_name() -> str:
    """Return the complete package key for legacy and Blender Extension loads."""
    package = str(__package__ or "").strip()
    if package:
        return package
    module_name = str(__name__ or "")
    parent, _separator, _leaf = module_name.rpartition(".")
    return parent or "smart_uv_suite"


_EPS = 1.0e-9
_UV_EPS = 1.0e-7

_METHOD_ALIASES: Dict[str, str] = {
    "DETAILED": "DETAILED",
    "DETAIL": "DETAILED",
    "ADVANCED": "DETAILED",
    "ADVANCED_UNWRAP": "DETAILED",
    "HIGH_QUALITY": "DETAILED",
    "REFERENCE_STRAIGHTEN": "REFERENCE_STRAIGHTEN",
    "REFERENCE_LINE": "REFERENCE_STRAIGHTEN",
    "STRAIGHTEN_REFERENCE": "REFERENCE_STRAIGHTEN",
    "BASELINE_STRAIGHTEN": "REFERENCE_STRAIGHTEN",
    "STRAIGHTEN": "REFERENCE_STRAIGHTEN",
    "SQUARE": "SQUARE",
    "QUAD": "SQUARE",
    "QUADRILATERAL": "SQUARE",
    "RECTANGLE": "SQUARE",
    "RECTANGULAR": "SQUARE",
    "CIRCLE": "CIRCLE",
    "CIRCULAR": "CIRCLE",
    "FLAT": "PLANAR",
    "FLAT_MAPPING": "PLANAR",
    "PLANAR": "PLANAR",
    "PLANE": "PLANAR",
    "ANGLE": "ANGLE_BASED",
    "ANGLE_BASED": "ANGLE_BASED",
    "ANGLEBASED": "ANGLE_BASED",
    "CONFORMAL": "CONFORMAL",
    "LSCM": "CONFORMAL",
    "MINIMUM_STRETCH": "MINIMUM_STRETCH",
    "MIN_STRETCH": "MINIMUM_STRETCH",
    "MINIMUMSTRETCH": "MINIMUM_STRETCH",
    "SMART": "SMART_PROJECT",
    "SMART_PROJECT": "SMART_PROJECT",
    "SMART_UV_PROJECT": "SMART_PROJECT",
    "LIGHTMAP": "LIGHTMAP",
    "LIGHTMAP_PACK": "LIGHTMAP",
    "FOLLOW_ACTIVE_QUADS": "FOLLOW_ACTIVE_QUADS",
    "FOLLOW_QUADS": "FOLLOW_ACTIVE_QUADS",
    "ACTIVE_QUADS": "FOLLOW_ACTIVE_QUADS",
    "QUICK_PLANAR": "QUICK_PLANAR",
    "QUICK_PLANE": "QUICK_PLANAR",
    "BOX": "BOX",
    "BOX_PROJECT": "BOX",
    "CUBE": "BOX",
    "CUBE_PROJECT": "BOX",
    "CYLINDER": "CYLINDER",
    "CYLINDER_PROJECT": "CYLINDER",
    "SPHERE": "SPHERE",
    "SPHERE_PROJECT": "SPHERE",
    "VIEW": "VIEW",
    "VIEW_PROJECT": "VIEW",
    "PROJECT_FROM_VIEW": "VIEW",
    "FACE": "FACE",
    "FACES": "FACE",
    "INDIVIDUAL_FACES": "FACE",
    "FACE_PROJECT": "FACE",
    "RESET": "FACE",
    # Japanese values can occur in custom string properties.
    "基準直線化": "REFERENCE_STRAIGHTEN",
    "四角": "SQUARE",
    "円": "CIRCLE",
    "フラットマッピング": "PLANAR",
    "詳細展開": "DETAILED",
    "スマートUVプロジェクト": "SMART_PROJECT",
    "ライトマップ": "LIGHTMAP",
    "クイック平面": "QUICK_PLANAR",
    "ボックス投影": "BOX",
    "円筒投影": "CYLINDER",
    "球投影": "SPHERE",
    "ビュー投影": "VIEW",
    "面単位化": "FACE",
}

_METHOD_DESCRIPTIONS = {
    "DETAILED": (
        "Runs a seam-respecting quality unwrap using the current solver, margin, hole, aspect and iteration settings. "
        "When automatic seams are disabled, only edges explicitly marked as seams may separate UV islands.",
        "現在のソルバー、余白、穴、アスペクト、反復設定を使って高品質に展開します。自動シームが無効な場合は、明示的にシームを付けた辺だけをUVアイランド境界として扱います。",
    ),
    "REFERENCE_STRAIGHTEN": (
        "Straightens the selected reference edge chain using cumulative mesh-edge length, then smoothly propagates the displacement through the same seam-bounded island. "
        "Select a continuous UV or mesh edge chain before running it; pins, seams and selection are preserved.",
        "選択した連続基準エッジ列をメッシュ辺長の比率を保って直線化し、その移動を同じシーム境界内のアイランドへ滑らかに伝播します。実行前にUVまたはメッシュの連続エッジ列を選択してください。ピン、シーム、選択状態は維持されます。",
    ),
    "SQUARE": (
        "Maps each seam-bounded disk-like island to a rectangle. The outer boundary is divided into four sides by explicit corners or boundary curvature, side lengths are retained proportionally, and interior vertices are solved harmonically.",
        "各シーム境界内の円板状アイランドを四角形へ展開します。明示した角または外周の曲率から四辺を決定し、辺長比を保って外周を直線化した後、内部頂点を調和補間します。",
    ),
    "CIRCLE": (
        "Maps the outer boundary of each seam-bounded island to a circle according to boundary length and relaxes the interior without adding unmarked cuts.",
        "各シーム境界内アイランドの外周を周長比に従って円へ配置し、シーム未設定箇所を追加分断せずに内部を緩和します。",
    ),
    "PLANAR": (
        "Projects each seam-bounded island onto its best-fit plane. Unmarked edges remain connected when automatic seams are disabled.",
        "各シーム境界内アイランドを最適平面へ投影します。自動シームが無効な場合、シーム未設定辺は接続を維持します。",
    ),
    "ANGLE_BASED": (
        "Uses Blender's angle-based unwrap solver, suitable for organic shapes, while preserving the user's seam topology by default.",
        "有機形状に適したBlenderのAngle Basedソルバーを使い、デフォルトではユーザーが指定したシーム構造だけを境界として展開します。",
    ),
    "CONFORMAL": (
        "Uses Blender's conformal unwrap solver, suitable for hard-surface and simple geometric shapes, while preserving marked seams.",
        "ハードサーフェスや単純な幾何形状に適したBlenderのConformalソルバーを使い、指定済みシームを維持して展開します。",
    ),
    "MINIMUM_STRETCH": (
        "Uses Blender's minimum-stretch solver with the configured iteration count and no-flip option, without inventing seams when automatic seams are disabled.",
        "設定した反復回数と反転防止を使用してBlenderのMinimum Stretchソルバーで展開し、自動シームが無効な場合は新しいシーム分断を作りません。",
    ),
    "SMART_PROJECT": (
        "With automatic seams enabled, uses Smart UV Project's angle-based chart generation. With it disabled, applies a quality unwrap only to the existing seam charts so no unmarked cut is introduced.",
        "自動シーム有効時はSmart UV Projectの角度ベース自動チャート分割を使います。無効時は既存シームチャートだけを高品質展開し、シーム未設定箇所を分断しません。",
    ),
    "LIGHTMAP": (
        "With automatic seams enabled, creates lightmap-style face charts. With it disabled, packs only existing seam-bounded charts using the lightmap margin settings.",
        "自動シーム有効時はライトマップ向けの面チャートを生成します。無効時は既存シーム境界のチャートだけをライトマップ余白設定で配置します。",
    ),
    "FOLLOW_ACTIVE_QUADS": (
        "Propagates the active quad's UV layout through connected selected quads using the selected edge-length mode. Existing seams bound propagation unless automatic seams are enabled.",
        "アクティブ四角面のUV配置を、指定した辺長方式で接続する選択四角面へ伝播します。自動シームが無効な場合は既存シームを境界として扱います。",
    ),
    "QUICK_PLANAR": (
        "Quickly projects selected seam charts onto a stable best-fit plane, retaining one UV coordinate per connected chart vertex.",
        "選択したシームチャートを安定した最適平面へ素早く投影し、接続するチャート頂点ごとに1つのUV座標を維持します。",
    ),
    "BOX": (
        "Uses cube projection when automatic seams are enabled. When disabled, unfolds each existing seam chart continuously so cube-like faces do not create hidden cuts.",
        "自動シーム有効時はボックス投影を使用します。無効時は既存シームチャートを連続的に展開し、立方体状の面境界へ隠れた分断を作りません。",
    ),
    "CYLINDER": (
        "Projects around the configured cylinder axis. With automatic seams disabled, angular coordinates are unwrapped continuously across the existing seam chart instead of creating an implicit longitude cut.",
        "指定した円筒軸を基準に投影します。自動シーム無効時は暗黙の経度分断を作らず、既存シームチャート内で角度を連続化します。",
    ),
    "SPHERE": (
        "Projects by longitude and latitude. With automatic seams disabled, longitude is made continuous over each existing seam chart and no extra cut is introduced.",
        "経度・緯度で投影します。自動シーム無効時は各既存シームチャート内で経度を連続化し、追加の分断を作りません。",
    ),
    "VIEW": (
        "Projects from the current 3D view while preserving existing seam connectivity when automatic seams are disabled.",
        "現在の3Dビューから投影し、自動シーム無効時は既存シームの接続関係を維持します。",
    ),
    "FACE": (
        "With automatic seams enabled, lays out faces independently. With it disabled, unfolds adjacent faces continuously across every unmarked edge, so the explicit no-auto-seam rule is preserved.",
        "自動シーム有効時は面を個別に配置します。無効時はシーム未設定辺で隣接面を連続展開し、追加分断を禁止する設定を維持します。",
    ),
}

_TRANSLATIONS = {
    "ja_JP": {
        ("*", "Enable Automatic Seams"): "自動シームを有効",
        ("*", "UV Unwrap"): "UV展開",
        ("*", "Allow the selected unwrap method to create UV island boundaries on edges that are not marked as seams. Keep this disabled to guarantee that only user-marked seams separate islands. Methods that normally generate charts automatically will instead operate on the existing seam-bounded charts."):
            "選択した展開方法が、シームを付けていない辺にもUVアイランド境界を作ることを許可します。無効のまま使用すると、ユーザーが明示したシームだけでアイランドを分離します。通常は自動チャートを生成する方式も、既存のシーム境界内だけで処理します。",
    }
}


def _is_japanese() -> bool:
    locale = str(getattr(bpy.app.translations, "locale", "") or "")
    return locale.lower().startswith("ja")


def _localized(en: str, ja: str) -> str:
    return ja if _is_japanese() else en


def _normalize_token(value: Any) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    if text in _METHOD_ALIASES:
        return text
    text = re.sub(r"[^0-9A-Za-z_\u3040-\u30ff\u3400-\u9fff]+", "_", text).strip("_").upper()
    return text


def _canonical_method(value: Any) -> Optional[str]:
    token = _normalize_token(value)
    if not token:
        return None
    if token in _METHOD_ALIASES:
        return _METHOD_ALIASES[token]
    compact = token.replace("_", "")
    for key, result in _METHOD_ALIASES.items():
        if _normalize_token(key).replace("_", "") == compact:
            return result
    # Conservative keyword fallback.
    checks = (
        (("REFERENCE", "STRAIGHT"), "REFERENCE_STRAIGHTEN"),
        (("BASE", "LINE"), "REFERENCE_STRAIGHTEN"),
        (("SMART",), "SMART_PROJECT"),
        (("LIGHTMAP",), "LIGHTMAP"),
        (("FOLLOW", "QUAD"), "FOLLOW_ACTIVE_QUADS"),
        (("MINIMUM", "STRETCH"), "MINIMUM_STRETCH"),
        (("ANGLE",), "ANGLE_BASED"),
        (("CONFORM",), "CONFORMAL"),
        (("CYL",), "CYLINDER"),
        (("SPHERE",), "SPHERE"),
        (("BOX",), "BOX"),
        (("CUBE",), "BOX"),
        (("VIEW",), "VIEW"),
        (("CIRCLE",), "CIRCLE"),
        (("SQUARE",), "SQUARE"),
        (("QUAD",), "SQUARE"),
        (("PLAN",), "PLANAR"),
        (("FACE",), "FACE"),
        (("DETAIL",), "DETAILED"),
    )
    for words, result in checks:
        if all(word in token for word in words):
            return result
    return None


def _iter_rna_values(container: Any) -> Iterator[Tuple[str, Any, Any]]:
    if container is None:
        return
    seen: Set[str] = set()
    # Python annotations are useful before/after RNA registration.
    for name in getattr(type(container), "__annotations__", {}) or {}:
        if name.startswith("_") or name.startswith("bl_") or name in seen:
            continue
        seen.add(name)
        try:
            yield name, getattr(container, name), None
        except Exception:
            pass
    rna = getattr(container, "bl_rna", None)
    props = getattr(rna, "properties", None)
    if props is not None:
        for prop in props:
            name = getattr(prop, "identifier", "")
            if not name or name == "rna_type" or name.startswith("_") or name.startswith("bl_") or name in seen:
                continue
            seen.add(name)
            try:
                yield name, getattr(container, name), prop
            except Exception:
                continue


def _context_containers(context: Any, operator: Any = None) -> List[Any]:
    result: List[Any] = []
    seen: Set[int] = set()

    def add(value: Any) -> None:
        if value is None or id(value) in seen:
            return
        seen.add(id(value))
        result.append(value)

    add(operator)
    add(getattr(context, "scene", None))
    add(getattr(context, "tool_settings", None))
    add(getattr(context, "window_manager", None))
    add(getattr(context, "workspace", None))
    scene = getattr(context, "scene", None)
    if scene is not None:
        for name, value, prop in list(_iter_rna_values(scene)):
            ptype = str(getattr(prop, "type", ""))
            if ptype == "POINTER" or hasattr(value, "bl_rna"):
                low = name.lower()
                if any(k in low for k in ("suv", "smart", "uv", "unwrap", "workspace", "setting")):
                    add(value)
    wm = getattr(context, "window_manager", None)
    if wm is not None:
        for name, value, prop in list(_iter_rna_values(wm)):
            if hasattr(value, "bl_rna") and any(k in name.lower() for k in ("suv", "uv", "unwrap", "setting")):
                add(value)
    try:
        root = _addon_package_name()
        addon = context.preferences.addons.get(root)
        if addon:
            add(addon.preferences)
    except Exception:
        pass
    return result


def _find_value(context: Any, operator: Any, names: Sequence[str], default: Any = None, fuzzy: Sequence[str] = ()) -> Any:
    exact = {name.lower() for name in names}
    fuzzy_lower = tuple(k.lower() for k in fuzzy)
    # Exact first, respecting container priority.
    for container in _context_containers(context, operator):
        for name, value, _prop in _iter_rna_values(container):
            if name.lower() in exact:
                return value
    if fuzzy_lower:
        candidates: List[Tuple[int, Any]] = []
        for ci, container in enumerate(_context_containers(context, operator)):
            for name, value, _prop in _iter_rna_values(container):
                low = name.lower()
                if all(k in low for k in fuzzy_lower):
                    candidates.append((ci, value))
        if candidates:
            candidates.sort(key=lambda item: item[0])
            return candidates[0][1]
    return default


def _read_bool(context: Any, operator: Any, names: Sequence[str], default: bool = False, fuzzy: Sequence[str] = ()) -> bool:
    value = _find_value(context, operator, names, default, fuzzy)
    try:
        return bool(value)
    except Exception:
        return default


def _read_float(context: Any, operator: Any, names: Sequence[str], default: float, fuzzy: Sequence[str] = ()) -> float:
    value = _find_value(context, operator, names, default, fuzzy)
    try:
        return float(value)
    except Exception:
        return default


def _read_int(context: Any, operator: Any, names: Sequence[str], default: int, fuzzy: Sequence[str] = ()) -> int:
    value = _find_value(context, operator, names, default, fuzzy)
    try:
        return int(value)
    except Exception:
        return default


def _read_string(context: Any, operator: Any, names: Sequence[str], default: str = "", fuzzy: Sequence[str] = ()) -> str:
    value = _find_value(context, operator, names, default, fuzzy)
    return str(value) if value is not None else default


def _auto_seam_enabled(context: Any, operator: Any) -> bool:
    names = (
        _SCENE_PROP,
        "auto_seam",
        "use_auto_seam",
        "enable_auto_seam",
        "auto_seams",
        "use_automatic_seams",
        "unwrap_auto_seam",
        "unwrap_use_auto_seam",
    )
    accepted = {n.lower() for n in names}
    values: List[bool] = []
    for container in _context_containers(context, operator):
        for name, value, _prop in _iter_rna_values(container):
            low = name.lower()
            if low in accepted or ("auto" in low and "seam" in low):
                try: values.append(bool(value))
                except Exception: pass
    scene = getattr(context, "scene", None)
    if scene is not None:
        try: values.append(bool(getattr(scene, _SCENE_PROP, False)))
        except Exception: pass
    # All automatic-seam settings default to False.  OR semantics lets either an
    # existing legacy UI property or the guaranteed replacement property enable it.
    return any(values)


def _resolve_method(context: Any, operator: Any, default: Optional[str] = None) -> Optional[str]:
    preferred_names = (
        "mode", "method", "unwrap_method", "unwrap_mode", "projection_method",
        "action", "operation", "algorithm", "type", "unwrap_type",
    )
    for name in preferred_names:
        try:
            value = getattr(operator, name)
        except Exception:
            continue
        method = _canonical_method(value)
        if method:
            return method
    # Inspect every enum/string on the operator, then settings containers.
    for container in _context_containers(context, operator):
        ranked: List[Tuple[int, str]] = []
        for name, value, prop in _iter_rna_values(container):
            method = _canonical_method(value)
            if not method:
                continue
            low = name.lower()
            score = 0
            if "unwrap" in low:
                score += 10
            if "method" in low or "mode" in low:
                score += 5
            if "projection" in low:
                score += 3
            if container is operator:
                score += 10
            ranked.append((score, method))
        if ranked:
            ranked.sort(reverse=True)
            return ranked[0][1]
    class_default = getattr(type(operator), "_suv_rebuild_default_method", None)
    return class_default or default


@dataclass
class _ObjectSnapshot:
    obj: bpy.types.Object
    uv_layer_name: str
    uv_layer_index: int
    target_faces: Set[int]
    uv_data: Dict[Tuple[int, int], Tuple[Tuple[float, float], bool, bool, bool, Optional[bool], Optional[bool], Optional[bool]]]
    vert_select: List[bool]
    edge_select: List[bool]
    face_select: List[bool]
    edge_seams: List[bool]


def _uv_bool_layers(bm: bmesh.types.BMesh) -> Tuple[Any, Any, Any]:
    return (
        bm.loops.layers.bool.get(".uv_select_vert"),
        bm.loops.layers.bool.get(".uv_select_edge"),
        bm.loops.layers.bool.get(".uv_select_face"),
    )


def _loop_selected(loop: Any, uv_layer: Any, bool_layers: Tuple[Any, Any, Any], mode: str) -> bool:
    uv = loop[uv_layer]
    vert_layer, edge_layer, face_layer = bool_layers
    if mode == "FACE" and face_layer is not None:
        try:
            return bool(loop[face_layer])
        except Exception:
            pass
    if mode == "EDGE" and edge_layer is not None:
        try:
            return bool(loop[edge_layer])
        except Exception:
            pass
    if vert_layer is not None:
        try:
            return bool(loop[vert_layer])
        except Exception:
            pass
    if mode == "EDGE":
        return bool(getattr(uv, "select_edge", False) or getattr(uv, "select", False))
    return bool(getattr(uv, "select", False))


def _selected_face_indices(context: Any, bm: bmesh.types.BMesh, uv_layer: Any) -> Set[int]:
    sync = bool(getattr(context.scene.tool_settings, "use_uv_select_sync", False))
    mode = str(getattr(context.scene.tool_settings, "uv_select_mode", "VERTEX"))
    bool_layers = _uv_bool_layers(bm)
    selected: Set[int] = set()
    for face in bm.faces:
        if face.hide:
            continue
        if sync:
            if face.select:
                selected.add(face.index)
            continue
        values = [_loop_selected(loop, uv_layer, bool_layers, mode) for loop in face.loops]
        if mode == "FACE":
            if values and all(values):
                selected.add(face.index)
        else:
            if any(values):
                selected.add(face.index)
    if not selected:
        selected = {face.index for face in bm.faces if face.select and not face.hide}
    return selected


def _edit_mesh_objects(context: Any) -> List[bpy.types.Object]:
    objects: List[bpy.types.Object] = []
    seen: Set[int] = set()
    for obj in list(getattr(context, "objects_in_mode_unique_data", []) or []):
        if obj and obj.type == "MESH" and obj.mode == "EDIT" and id(obj.data) not in seen:
            seen.add(id(obj.data)); objects.append(obj)
    if not objects:
        obj = getattr(context, "edit_object", None) or getattr(context, "active_object", None)
        if obj and obj.type == "MESH" and obj.mode == "EDIT":
            objects.append(obj)
    return objects


def _snapshot_object(context: Any, obj: bpy.types.Object) -> Optional[_ObjectSnapshot]:
    bm = bmesh.from_edit_mesh(obj.data)
    bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
    bm.verts.index_update(); bm.edges.index_update(); bm.faces.index_update()
    uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
    if uv_layer is None:
        return None
    layer_name = str(getattr(uv_layer, "name", ""))
    try:
        layer_index = list(bm.loops.layers.uv).index(uv_layer)
    except Exception:
        layer_index = max(0, int(getattr(obj.data.uv_layers, "active_index", 0)))
    targets = _selected_face_indices(context, bm, uv_layer)
    bool_layers = _uv_bool_layers(bm)
    uv_data: Dict[Tuple[int, int], Tuple[Tuple[float, float], bool, bool, bool, Optional[bool], Optional[bool], Optional[bool]]] = {}
    for face in bm.faces:
        for li, loop in enumerate(face.loops):
            luv = loop[uv_layer]
            extras: List[Optional[bool]] = []
            for layer in bool_layers:
                try:
                    extras.append(bool(loop[layer]) if layer is not None else None)
                except Exception:
                    extras.append(None)
            uv_data[(face.index, li)] = (
                (float(luv.uv.x), float(luv.uv.y)),
                bool(getattr(luv, "select", False)),
                bool(getattr(luv, "select_edge", False)),
                bool(getattr(luv, "pin_uv", False)),
                extras[0], extras[1], extras[2],
            )
    return _ObjectSnapshot(
        obj=obj,
        uv_layer_name=layer_name,
        uv_layer_index=layer_index,
        target_faces=targets,
        uv_data=uv_data,
        vert_select=[bool(v.select) for v in bm.verts],
        edge_select=[bool(e.select) for e in bm.edges],
        face_select=[bool(f.select) for f in bm.faces],
        edge_seams=[bool(e.seam) for e in bm.edges],
    )


def _snapshot_all(context: Any) -> List[_ObjectSnapshot]:
    result: List[_ObjectSnapshot] = []
    for obj in _edit_mesh_objects(context):
        state = _snapshot_object(context, obj)
        if state and state.target_faces:
            result.append(state)
    return result


def _active_uv_layer(bm: bmesh.types.BMesh, state: _ObjectSnapshot) -> Any:
    layer = bm.loops.layers.uv.get(state.uv_layer_name) if state.uv_layer_name else None
    if layer is None:
        layers = list(bm.loops.layers.uv)
        if layers:
            layer = layers[min(state.uv_layer_index, len(layers) - 1)]
    return layer or bm.loops.layers.uv.verify()


def _restore_state(state: _ObjectSnapshot, restore_non_targets: bool = True) -> None:
    obj = state.obj
    if not obj or obj.type != "MESH" or obj.mode != "EDIT":
        return
    bm = bmesh.from_edit_mesh(obj.data)
    bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
    bm.verts.index_update(); bm.edges.index_update(); bm.faces.index_update()
    uv_layer = _active_uv_layer(bm, state)
    bool_layers = _uv_bool_layers(bm)
    for i, value in enumerate(state.vert_select):
        if i < len(bm.verts): bm.verts[i].select = value
    for i, value in enumerate(state.edge_select):
        if i < len(bm.edges): bm.edges[i].select = value
    for i, value in enumerate(state.face_select):
        if i < len(bm.faces): bm.faces[i].select = value
    for i, value in enumerate(state.edge_seams):
        if i < len(bm.edges): bm.edges[i].seam = value
    for face in bm.faces:
        for li, loop in enumerate(face.loops):
            saved = state.uv_data.get((face.index, li))
            if saved is None:
                continue
            luv = loop[uv_layer]
            if restore_non_targets and face.index not in state.target_faces:
                luv.uv = saved[0]
            try: luv.select = saved[1]
            except Exception: pass
            try: luv.select_edge = saved[2]
            except Exception: pass
            try: luv.pin_uv = saved[3]
            except Exception: pass
            for layer, value in zip(bool_layers, saved[4:7]):
                if layer is not None and value is not None:
                    try: loop[layer] = value
                    except Exception: pass
    try:
        obj.data.uv_layers.active_index = min(state.uv_layer_index, max(0, len(obj.data.uv_layers) - 1))
    except Exception:
        pass
    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)


def _prepare_native_selection(states: Sequence[_ObjectSnapshot]) -> None:
    """Make native UV operators see exactly the target faces, then restore later."""
    for state in states:
        obj = state.obj
        bm = bmesh.from_edit_mesh(obj.data)
        bm.faces.ensure_lookup_table(); bm.faces.index_update()
        uv_layer = _active_uv_layer(bm, state)
        bool_layers = _uv_bool_layers(bm)
        for face in bm.faces:
            selected = face.index in state.target_faces
            face.select = selected
            for loop in face.loops:
                luv = loop[uv_layer]
                try: luv.select = selected
                except Exception: pass
                try: luv.select_edge = selected
                except Exception: pass
                for layer in bool_layers:
                    if layer is not None:
                        try: loop[layer] = selected
                        except Exception: pass
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)


@dataclass
class _Chart:
    faces: Set[int]
    verts: Set[int]
    edges: Set[int]


def _build_charts(bm: bmesh.types.BMesh, face_ids: Set[int]) -> List[_Chart]:
    bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
    pending = set(face_ids)
    charts: List[_Chart] = []
    while pending:
        start = pending.pop()
        faces = {start}
        queue = [start]
        while queue:
            fi = queue.pop()
            face = bm.faces[fi]
            for edge in face.edges:
                if edge.seam:
                    continue
                for linked in edge.link_faces:
                    li = linked.index
                    if li in pending:
                        pending.remove(li); faces.add(li); queue.append(li)
        verts: Set[int] = set()
        edges: Set[int] = set()
        for fi in faces:
            f = bm.faces[fi]
            verts.update(v.index for v in f.verts)
            edges.update(e.index for e in f.edges)
        charts.append(_Chart(faces, verts, edges))
    return charts


def _chart_graph(bm: bmesh.types.BMesh, chart: _Chart) -> Dict[int, Set[int]]:
    graph: Dict[int, Set[int]] = {vi: set() for vi in chart.verts}
    for ei in chart.edges:
        edge = bm.edges[ei]
        if not any(f.index in chart.faces for f in edge.link_faces):
            continue
        a, b = edge.verts[0].index, edge.verts[1].index
        if a in graph and b in graph:
            graph[a].add(b); graph[b].add(a)
    return graph


def _chart_uv_by_vert(bm: bmesh.types.BMesh, uv_layer: Any, chart: _Chart) -> Dict[int, Vector]:
    accum: Dict[int, Vector] = defaultdict(lambda: Vector((0.0, 0.0)))
    count: Dict[int, int] = defaultdict(int)
    for fi in chart.faces:
        for loop in bm.faces[fi].loops:
            vi = loop.vert.index
            accum[vi] += loop[uv_layer].uv
            count[vi] += 1
    return {vi: accum[vi] / max(1, count[vi]) for vi in chart.verts}


def _assign_chart_uv(bm: bmesh.types.BMesh, uv_layer: Any, chart: _Chart, coords: Mapping[int, Sequence[float]]) -> None:
    for fi in chart.faces:
        for loop in bm.faces[fi].loops:
            value = coords.get(loop.vert.index)
            if value is not None:
                loop[uv_layer].uv = (float(value[0]), float(value[1]))


def _chart_3d(bm: bmesh.types.BMesh, chart: _Chart) -> Dict[int, Vector]:
    return {vi: bm.verts[vi].co.copy() for vi in chart.verts}


def _safe_basis(points: Mapping[int, Vector]) -> Tuple[Vector, Vector, Vector]:
    values = list(points.values())
    if not values:
        return Vector((1, 0, 0)), Vector((0, 1, 0)), Vector((0, 0, 0))
    center = sum(values, Vector()) / len(values)
    if _np is not None and len(values) >= 3:
        arr = _np.array([[p.x - center.x, p.y - center.y, p.z - center.z] for p in values], dtype=float)
        cov = arr.T @ arr
        try:
            vals, vecs = _np.linalg.eigh(cov)
            order = _np.argsort(vals)[::-1]
            x = Vector(vecs[:, order[0]].tolist()).normalized()
            y = Vector(vecs[:, order[1]].tolist()).normalized()
            if x.length > _EPS and y.length > _EPS:
                return x, y, center
        except Exception:
            pass
    # Stable geometric fallback.
    x = max((p - center for p in values), key=lambda v: v.length_squared, default=Vector((1, 0, 0)))
    if x.length < _EPS: x = Vector((1, 0, 0))
    x.normalize()
    helper = Vector((0, 0, 1)) if abs(x.z) < 0.9 else Vector((0, 1, 0))
    y = helper.cross(x)
    if y.length < _EPS: y = Vector((0, 1, 0))
    y.normalize()
    return x, y, center


def _fit_to_old(coords: Dict[int, Vector], old: Mapping[int, Vector]) -> Dict[int, Vector]:
    if not coords or not old:
        return coords
    nxs = [v.x for v in coords.values()]; nys = [v.y for v in coords.values()]
    oxs = [v.x for v in old.values()]; oys = [v.y for v in old.values()]
    nmin = Vector((min(nxs), min(nys))); nmax = Vector((max(nxs), max(nys)))
    omin = Vector((min(oxs), min(oys))); omax = Vector((max(oxs), max(oys)))
    nd = nmax - nmin; od = omax - omin
    scale_candidates = []
    if nd.x > _EPS and od.x > _EPS: scale_candidates.append(od.x / nd.x)
    if nd.y > _EPS and od.y > _EPS: scale_candidates.append(od.y / nd.y)
    scale = min(scale_candidates) if scale_candidates else 1.0
    if not math.isfinite(scale) or scale <= _EPS: scale = 1.0
    nc = (nmin + nmax) * 0.5; oc = (omin + omax) * 0.5
    return {vi: (uv - nc) * scale + oc for vi, uv in coords.items()}


def _planar_coords(bm: bmesh.types.BMesh, chart: _Chart) -> Dict[int, Vector]:
    points = _chart_3d(bm, chart)
    x, y, center = _safe_basis(points)
    return {vi: Vector(((p - center).dot(x), (p - center).dot(y))) for vi, p in points.items()}


def _boundary_edges(bm: bmesh.types.BMesh, chart: _Chart) -> Set[int]:
    result: Set[int] = set()
    for ei in chart.edges:
        edge = bm.edges[ei]
        count = sum(1 for f in edge.link_faces if f.index in chart.faces)
        if edge.seam or count <= 1:
            result.add(ei)
    return result


def _boundary_paths(bm: bmesh.types.BMesh, chart: _Chart) -> List[List[int]]:
    edge_ids = _boundary_edges(bm, chart)
    adjacency: Dict[int, List[Tuple[int, int]]] = defaultdict(list)
    for ei in edge_ids:
        edge = bm.edges[ei]
        a, b = edge.verts[0].index, edge.verts[1].index
        adjacency[a].append((b, ei)); adjacency[b].append((a, ei))
    unused = set(edge_ids)
    paths: List[List[int]] = []
    while unused:
        seed = next(iter(unused))
        edge = bm.edges[seed]
        component_vertices: Set[int] = set()
        comp_edges: Set[int] = set()
        q = [edge.verts[0].index]
        while q:
            vi = q.pop()
            if vi in component_vertices: continue
            component_vertices.add(vi)
            for nb, ei in adjacency.get(vi, []):
                if ei in unused:
                    comp_edges.add(ei)
                if nb not in component_vertices: q.append(nb)
        starts = [vi for vi in component_vertices if sum(1 for _n, ei in adjacency.get(vi, []) if ei in comp_edges) == 1]
        start = starts[0] if starts else min(component_vertices)
        path = [start]
        prev = None; current = start
        used_local: Set[int] = set()
        while True:
            options = [(nb, ei) for nb, ei in adjacency.get(current, []) if ei in comp_edges and ei not in used_local]
            if not options: break
            if prev is not None and len(options) > 1:
                nonprev = [item for item in options if item[0] != prev]
                if nonprev: options = nonprev
            nb, ei = options[0]
            used_local.add(ei); unused.discard(ei)
            prev, current = current, nb
            if current == path[0]:
                break
            path.append(current)
            if len(path) > len(comp_edges) + 2: break
        for ei in comp_edges:
            unused.discard(ei)
        if len(path) >= 2:
            paths.append(path)
    return paths


def _path_lengths(bm: bmesh.types.BMesh, path: Sequence[int], closed: bool = False) -> Tuple[List[float], float]:
    cumulative = [0.0]
    total = 0.0
    count = len(path) if closed else len(path) - 1
    for i in range(max(0, count)):
        a = bm.verts[path[i]].co; b = bm.verts[path[(i + 1) % len(path)]].co
        total += max((b - a).length, _EPS)
        cumulative.append(total)
    return cumulative, total


def _weighted_graph(bm: bmesh.types.BMesh, chart: _Chart) -> Dict[int, List[Tuple[int, float]]]:
    graph: Dict[int, List[Tuple[int, float]]] = {vi: [] for vi in chart.verts}
    for ei in chart.edges:
        edge = bm.edges[ei]
        a, b = edge.verts[0].index, edge.verts[1].index
        if a not in graph or b not in graph: continue
        length = max((edge.verts[0].co - edge.verts[1].co).length, 1.0e-8)
        w = 1.0 / length
        graph[a].append((b, w)); graph[b].append((a, w))
    return graph


def _harmonic_solve(
    bm: bmesh.types.BMesh,
    chart: _Chart,
    fixed: Mapping[int, Vector],
    initial: Optional[Mapping[int, Vector]] = None,
    iterations: int = 300,
    tolerance: float = 1.0e-8,
) -> Dict[int, Vector]:
    graph = _weighted_graph(bm, chart)
    if initial is None:
        initial = _planar_coords(bm, chart)
    result = {vi: Vector(initial.get(vi, (0.0, 0.0))) for vi in chart.verts}
    for vi, value in fixed.items():
        result[vi] = Vector(value)
    free = [vi for vi in chart.verts if vi not in fixed]
    if not free:
        return result
    iterations = max(1, min(int(iterations), 1000))
    for _ in range(iterations):
        max_delta = 0.0
        for vi in free:
            neighbors = graph.get(vi, [])
            if not neighbors: continue
            total_w = sum(w for _nb, w in neighbors)
            if total_w <= _EPS: continue
            value = sum((result[nb] * w for nb, w in neighbors), Vector()) / total_w
            delta = (value - result[vi]).length
            if delta > max_delta: max_delta = delta
            result[vi] = value
        if max_delta < tolerance:
            break
    for vi, value in fixed.items():
        result[vi] = Vector(value)
    return result


def _turning_scores(bm: bmesh.types.BMesh, path: Sequence[int]) -> List[float]:
    points = {vi: bm.verts[vi].co.copy() for vi in path}
    x, y, center = _safe_basis(points)
    p2 = [Vector(((points[vi] - center).dot(x), (points[vi] - center).dot(y))) for vi in path]
    n = len(path)
    scores: List[float] = []
    for i in range(n):
        a = p2[(i - 1) % n] - p2[i]
        b = p2[(i + 1) % n] - p2[i]
        if a.length < _EPS or b.length < _EPS:
            scores.append(0.0); continue
        a.normalize(); b.normalize()
        angle = math.acos(max(-1.0, min(1.0, a.dot(b))))
        scores.append(abs(math.pi - angle))
    return scores


def _choose_four_corners(bm: bmesh.types.BMesh, path: Sequence[int], explicit: Set[int]) -> List[int]:
    n = len(path)
    if n < 4:
        return list(range(n))
    explicit_indices = [i for i, vi in enumerate(path) if vi in explicit]
    if len(explicit_indices) == 4:
        return sorted(explicit_indices)
    cumulative, perimeter = _path_lengths(bm, path, closed=True)
    if perimeter <= _EPS:
        return [0, n // 4, n // 2, (3 * n) // 4]
    scores = _turning_scores(bm, path)
    start = max(range(n), key=lambda i: scores[i])
    # Rotate cumulative distances so start is zero.
    distances = [0.0] * n
    for offset in range(1, n):
        i_prev = (start + offset - 1) % n
        i_cur = (start + offset) % n
        distances[i_cur] = distances[i_prev] + max((bm.verts[path[i_cur]].co - bm.verts[path[i_prev]].co).length, _EPS)
    corners = [start]
    min_sep = max(1, n // 10)
    for k in range(1, 4):
        target = perimeter * k / 4.0
        candidates = []
        for i in range(n):
            cyclic_sep = min((i - c) % n for c in corners)
            reverse_sep = min((c - i) % n for c in corners)
            if min(cyclic_sep, reverse_sep) < min_sep:
                continue
            d = abs(distances[i] - target)
            objective = d / perimeter - 0.08 * scores[i]
            candidates.append((objective, i))
        if candidates:
            corners.append(min(candidates)[1])
        else:
            corners.append(min(range(n), key=lambda i: abs(distances[i] - target)))
    return sorted(set(corners))[:4]


def _path_segment(path: Sequence[int], start: int, end: int) -> List[int]:
    n = len(path)
    result = [path[start]]
    i = start
    while i != end:
        i = (i + 1) % n
        result.append(path[i])
        if len(result) > n + 1: break
    return result


def _square_chart(bm: bmesh.types.BMesh, uv_layer: Any, chart: _Chart, explicit_corners: Set[int]) -> bool:
    paths = _boundary_paths(bm, chart)
    if not paths:
        # A closed chart cannot be topologically flattened to a rectangle without a cut.
        # Preserve the no-auto-seam contract with a continuous face-tree unfolding.
        coords = _unfold_chart(bm, chart)
        old = _chart_uv_by_vert(bm, uv_layer, chart)
        _assign_chart_uv(bm, uv_layer, chart, _fit_to_old(coords, old))
        return bool(coords)
    closed_paths = sorted(paths, key=lambda p: _path_lengths(bm, p, closed=True)[1], reverse=True)
    outer = closed_paths[0]
    if len(outer) < 4:
        return False
    corner_indices = _choose_four_corners(bm, outer, explicit_corners)
    if len(corner_indices) != 4:
        return False
    corner_indices.sort()
    segments = [_path_segment(outer, corner_indices[i], corner_indices[(i + 1) % 4]) for i in range(4)]
    side_lengths = [_path_lengths(bm, seg, closed=False)[1] for seg in segments]
    width = max((side_lengths[0] + side_lengths[2]) * 0.5, _EPS)
    height = max((side_lengths[1] + side_lengths[3]) * 0.5, _EPS)
    scale = max(width, height)
    width /= scale; height /= scale
    fixed: Dict[int, Vector] = {}
    corners_uv = [Vector((0.0, 0.0)), Vector((width, 0.0)), Vector((width, height)), Vector((0.0, height))]
    for si, seg in enumerate(segments):
        cumulative, total = _path_lengths(bm, seg, closed=False)
        total = max(total, _EPS)
        a = corners_uv[si]; b = corners_uv[(si + 1) % 4]
        for j, vi in enumerate(seg):
            t = cumulative[min(j, len(cumulative) - 1)] / total
            fixed[vi] = a.lerp(b, t)
    initial = _planar_coords(bm, chart)
    # Keep inner boundaries as inset loops so holes remain valid.
    if len(closed_paths) > 1:
        xs = [v.x for v in initial.values()]; ys = [v.y for v in initial.values()]
        minv = Vector((min(xs), min(ys))); maxv = Vector((max(xs), max(ys))); span = maxv - minv
        for inner in closed_paths[1:]:
            for vi in inner:
                p = initial[vi]
                tx = (p.x - minv.x) / span.x if span.x > _EPS else 0.5
                ty = (p.y - minv.y) / span.y if span.y > _EPS else 0.5
                fixed[vi] = Vector((width * (0.2 + 0.6 * tx), height * (0.2 + 0.6 * ty)))
    solved = _harmonic_solve(bm, chart, fixed, initial, iterations=500)
    old = _chart_uv_by_vert(bm, uv_layer, chart)
    _assign_chart_uv(bm, uv_layer, chart, _fit_to_old(solved, old))
    return True


def _circle_chart(bm: bmesh.types.BMesh, uv_layer: Any, chart: _Chart) -> bool:
    paths = _boundary_paths(bm, chart)
    if not paths:
        coords = _unfold_chart(bm, chart)
        if not coords: coords = _planar_coords(bm, chart)
        old = _chart_uv_by_vert(bm, uv_layer, chart)
        _assign_chart_uv(bm, uv_layer, chart, _fit_to_old(coords, old))
        return bool(coords)
    paths.sort(key=lambda p: _path_lengths(bm, p, closed=True)[1], reverse=True)
    fixed: Dict[int, Vector] = {}
    for pi, path in enumerate(paths):
        cumulative, total = _path_lengths(bm, path, closed=True)
        radius = 1.0 if pi == 0 else max(0.1, 0.5 / (pi + 1))
        for i, vi in enumerate(path):
            t = cumulative[min(i, len(cumulative) - 1)] / max(total, _EPS)
            angle = 2.0 * math.pi * t
            fixed[vi] = Vector((math.cos(angle) * radius, math.sin(angle) * radius))
    solved = _harmonic_solve(bm, chart, fixed, _planar_coords(bm, chart), iterations=500)
    old = _chart_uv_by_vert(bm, uv_layer, chart)
    _assign_chart_uv(bm, uv_layer, chart, _fit_to_old(solved, old))
    return True


def _face_local_coords(face: bmesh.types.BMFace) -> Dict[int, Vector]:
    verts = list(face.verts)
    if len(verts) < 3:
        return {v.index: Vector((0.0, 0.0)) for v in verts}
    origin = verts[0].co
    x = None
    for v in verts[1:]:
        d = v.co - origin
        if d.length > _EPS:
            x = d.normalized(); break
    if x is None: x = Vector((1, 0, 0))
    normal = face.normal.copy()
    if normal.length < _EPS:
        normal = Vector((0, 0, 1))
    normal.normalize()
    y = normal.cross(x)
    if y.length < _EPS:
        helper = Vector((0, 0, 1)) if abs(x.z) < 0.9 else Vector((0, 1, 0))
        y = helper.cross(x)
    y.normalize()
    return {v.index: Vector(((v.co - origin).dot(x), (v.co - origin).dot(y))) for v in verts}


def _transform_child(local: Mapping[int, Vector], a: int, b: int, A: Vector, B: Vector, reflect: bool) -> Dict[int, Vector]:
    pa = Vector(local[a]); pb = Vector(local[b])
    source = pb - pa; target = B - A
    if source.length < _EPS or target.length < _EPS:
        return {vi: Vector(A) for vi in local}
    # Complex-number similarity transform; optionally reflect across local shared edge.
    sx, sy = source.x, source.y
    tx, ty = target.x, target.y
    denom = sx * sx + sy * sy
    ca = (sx * tx + sy * ty) / denom
    sa = (sx * ty - sy * tx) / denom
    result: Dict[int, Vector] = {}
    for vi, point in local.items():
        q = Vector(point) - pa
        if reflect:
            # Reflect q around the source edge direction.
            ux, uy = sx / math.sqrt(denom), sy / math.sqrt(denom)
            along = q.x * ux + q.y * uy
            perp = -q.x * uy + q.y * ux
            perp = -perp
            q = Vector((along * ux - perp * uy, along * uy + perp * ux))
        result[vi] = A + Vector((ca * q.x - sa * q.y, sa * q.x + ca * q.y))
    return result


def _signed_side(a: Vector, b: Vector, p: Vector) -> float:
    return (b.x - a.x) * (p.y - a.y) - (b.y - a.y) * (p.x - a.x)


def _unfold_chart(bm: bmesh.types.BMesh, chart: _Chart) -> Dict[int, Vector]:
    if not chart.faces:
        return {}
    local = {fi: _face_local_coords(bm.faces[fi]) for fi in chart.faces}
    root = max(chart.faces, key=lambda fi: bm.faces[fi].calc_area())
    placed_faces = {root}
    accum: Dict[int, Vector] = defaultdict(lambda: Vector((0.0, 0.0)))
    count: Dict[int, int] = defaultdict(int)
    face_coords: Dict[int, Dict[int, Vector]] = {root: local[root]}
    for vi, uv in local[root].items():
        accum[vi] += uv; count[vi] += 1
    queue = deque([root])
    while queue:
        pfi = queue.popleft()
        parent = bm.faces[pfi]
        pcoords = face_coords[pfi]
        parent_centroid = sum(pcoords.values(), Vector()) / max(1, len(pcoords))
        for edge in parent.edges:
            if edge.seam: continue
            child_faces = [f for f in edge.link_faces if f.index in chart.faces and f.index not in placed_faces]
            for child in child_faces:
                a, b = edge.verts[0].index, edge.verts[1].index
                if a not in pcoords or b not in pcoords or a not in local[child.index] or b not in local[child.index]:
                    continue
                A, B = pcoords[a], pcoords[b]
                direct = _transform_child(local[child.index], a, b, A, B, False)
                child_centroid = sum(direct.values(), Vector()) / max(1, len(direct))
                parent_side = _signed_side(A, B, parent_centroid)
                child_side = _signed_side(A, B, child_centroid)
                reflect = parent_side * child_side >= 0.0
                transformed = _transform_child(local[child.index], a, b, A, B, reflect)
                face_coords[child.index] = transformed
                placed_faces.add(child.index); queue.append(child.index)
                for vi, uv in transformed.items():
                    accum[vi] += uv; count[vi] += 1
    # Disconnected due to non-manifold details: seed remaining faces beside current bounds.
    offset_x = max((v.x for v in accum.values()), default=0.0) + 1.0
    for fi in chart.faces - placed_faces:
        coords = {vi: uv + Vector((offset_x, 0.0)) for vi, uv in local[fi].items()}
        offset_x += max((uv.x for uv in coords.values()), default=0.0) - min((uv.x for uv in coords.values()), default=0.0) + 1.0
        for vi, uv in coords.items():
            accum[vi] += uv; count[vi] += 1
    return {vi: accum[vi] / max(1, count[vi]) for vi in chart.verts}


def _axis_vector(axis: str) -> Vector:
    axis = str(axis).upper()
    if "X" in axis: return Vector((1, 0, 0))
    if "Y" in axis: return Vector((0, 1, 0))
    return Vector((0, 0, 1))


def _angular_unwrap(graph: Mapping[int, Set[int]], raw: Mapping[int, float]) -> Dict[int, float]:
    result: Dict[int, float] = {}
    for seed in graph:
        if seed in result: continue
        result[seed] = raw[seed]
        q = deque([seed])
        while q:
            vi = q.popleft()
            base = result[vi]
            for nb in graph.get(vi, ()):
                if nb in result: continue
                theta = raw[nb]
                theta += 2.0 * math.pi * round((base - theta) / (2.0 * math.pi))
                result[nb] = theta; q.append(nb)
    return result


def _cylindrical_coords(bm: bmesh.types.BMesh, chart: _Chart, axis: str = "Z") -> Dict[int, Vector]:
    points = _chart_3d(bm, chart)
    center = sum(points.values(), Vector()) / max(1, len(points))
    z = _axis_vector(axis).normalized()
    helper = Vector((0, 0, 1)) if abs(z.z) < 0.9 else Vector((0, 1, 0))
    x = helper.cross(z).normalized(); y = z.cross(x).normalized()
    raw = {vi: math.atan2((p - center).dot(y), (p - center).dot(x)) for vi, p in points.items()}
    theta = _angular_unwrap(_chart_graph(bm, chart), raw)
    return {vi: Vector((theta[vi] / (2.0 * math.pi), (p - center).dot(z))) for vi, p in points.items()}


def _spherical_coords(bm: bmesh.types.BMesh, chart: _Chart, axis: str = "Z") -> Dict[int, Vector]:
    points = _chart_3d(bm, chart)
    center = sum(points.values(), Vector()) / max(1, len(points))
    z = _axis_vector(axis).normalized()
    helper = Vector((0, 0, 1)) if abs(z.z) < 0.9 else Vector((0, 1, 0))
    x = helper.cross(z).normalized(); y = z.cross(x).normalized()
    raw: Dict[int, float] = {}
    lat: Dict[int, float] = {}
    for vi, p in points.items():
        d = p - center; r = max(d.length, _EPS)
        raw[vi] = math.atan2(d.dot(y), d.dot(x))
        lat[vi] = math.asin(max(-1.0, min(1.0, d.dot(z) / r)))
    theta = _angular_unwrap(_chart_graph(bm, chart), raw)
    return {vi: Vector((theta[vi] / (2.0 * math.pi), lat[vi] / math.pi)) for vi in points}


def _view_coords(context: Any, bm: bmesh.types.BMesh, chart: _Chart) -> Dict[int, Vector]:
    region_3d = None
    area = getattr(context, "area", None)
    if area and area.type == "VIEW_3D":
        region_3d = getattr(getattr(context, "space_data", None), "region_3d", None)
    if region_3d is None:
        window = getattr(context, "window", None)
        screen = getattr(window, "screen", None)
        if screen:
            for a in screen.areas:
                if a.type == "VIEW_3D":
                    region_3d = a.spaces.active.region_3d; break
    if region_3d is None:
        return _planar_coords(bm, chart)
    view = region_3d.view_matrix
    coords: Dict[int, Vector] = {}
    for vi in chart.verts:
        p = view @ bm.verts[vi].co.to_4d()
        coords[vi] = Vector((p.x, p.y))
    return coords


def _explicit_corner_vertices(bm: bmesh.types.BMesh, uv_layer: Any, chart: _Chart) -> Set[int]:
    selected: Set[int] = set()
    bool_layers = _uv_bool_layers(bm)
    for fi in chart.faces:
        for loop in bm.faces[fi].loops:
            if loop.vert.select or _loop_selected(loop, uv_layer, bool_layers, "VERTEX"):
                selected.add(loop.vert.index)
    return selected if len(selected) == 4 else set()


def _selected_reference_edges(bm: bmesh.types.BMesh, uv_layer: Any, chart: _Chart) -> Set[int]:
    selected: Set[int] = set()
    _vl, edge_layer, _fl = _uv_bool_layers(bm)
    for ei in chart.edges:
        edge = bm.edges[ei]
        if edge.select:
            selected.add(ei); continue
        for face in edge.link_faces:
            if face.index not in chart.faces: continue
            for loop in face.loops:
                if loop.edge.index != ei: continue
                value = bool(getattr(loop[uv_layer], "select_edge", False))
                if edge_layer is not None:
                    try: value = value or bool(loop[edge_layer])
                    except Exception: pass
                if value:
                    selected.add(ei); break
            if ei in selected: break
    # If all chart edges are selected as a side effect of face selection, it is not a reference chain.
    if len(selected) >= max(3, int(len(chart.edges) * 0.75)):
        return set()
    return selected


def _edge_components_as_paths(bm: bmesh.types.BMesh, edge_ids: Set[int]) -> List[List[int]]:
    adjacency: Dict[int, List[Tuple[int, int]]] = defaultdict(list)
    for ei in edge_ids:
        e = bm.edges[ei]; a, b = e.verts[0].index, e.verts[1].index
        adjacency[a].append((b, ei)); adjacency[b].append((a, ei))
    unused = set(edge_ids); paths: List[List[int]] = []
    while unused:
        seed = next(iter(unused)); e = bm.edges[seed]
        comp_edges: Set[int] = set(); comp_verts: Set[int] = set(); q = [e.verts[0].index]
        while q:
            vi = q.pop()
            if vi in comp_verts: continue
            comp_verts.add(vi)
            for nb, ei in adjacency[vi]:
                if ei in unused: comp_edges.add(ei)
                if nb not in comp_verts: q.append(nb)
        endpoints = [vi for vi in comp_verts if sum(1 for _n, ei in adjacency[vi] if ei in comp_edges) == 1]
        start = endpoints[0] if endpoints else min(comp_verts)
        path = [start]; current = start; prev = None; used: Set[int] = set()
        while True:
            opts = [(nb, ei) for nb, ei in adjacency[current] if ei in comp_edges and ei not in used]
            if not opts: break
            if prev is not None:
                nonprev = [o for o in opts if o[0] != prev]
                if nonprev: opts = nonprev
            nb, ei = opts[0]; used.add(ei); unused.discard(ei)
            prev, current = current, nb
            if current == path[0]: break
            path.append(current)
            if len(path) > len(comp_edges) + 2: break
        for ei in comp_edges: unused.discard(ei)
        if len(path) >= 2: paths.append(path)
    return paths


def _axis_reference_edges(context: Any, operator: Any, bm: bmesh.types.BMesh, chart: _Chart) -> Set[int]:
    axis_value = _read_string(context, operator, (
        "reference_axis", "straighten_axis", "baseline_axis", "axis", "direction_axis"
    ), "", fuzzy=("straight", "axis"))
    if not axis_value or axis_value.upper() in {"SELECTED", "SELECTION", "AUTO", "NONE"}:
        return set()
    axis = _axis_vector(axis_value)
    threshold = _read_float(context, operator, (
        "reference_threshold", "straighten_threshold", "axis_threshold", "direction_threshold"
    ), math.radians(20.0), fuzzy=("threshold",))
    if threshold > math.pi:
        threshold = math.radians(threshold)
    cos_limit = math.cos(max(0.0, min(math.pi * 0.5, threshold)))
    candidates: Set[int] = set()
    for ei in chart.edges:
        edge = bm.edges[ei]
        d = edge.verts[1].co - edge.verts[0].co
        if d.length < _EPS: continue
        if abs(d.normalized().dot(axis)) >= cos_limit:
            candidates.add(ei)
    if not candidates:
        return set()
    paths = _edge_components_as_paths(bm, candidates)
    if not paths: return set()
    longest = max(paths, key=lambda p: _path_lengths(bm, p, False)[1])
    pair_set = {frozenset((longest[i], longest[i + 1])) for i in range(len(longest) - 1)}
    return {ei for ei in candidates if frozenset((bm.edges[ei].verts[0].index, bm.edges[ei].verts[1].index)) in pair_set}


def _fallback_reference_path(bm: bmesh.types.BMesh, chart: _Chart) -> Optional[List[int]]:
    paths = _boundary_paths(bm, chart)
    if not paths: return None
    outer = max(paths, key=lambda p: _path_lengths(bm, p, True)[1])
    if len(outer) < 3: return None
    corners = _choose_four_corners(bm, outer, set())
    if len(corners) == 4:
        segments = [_path_segment(outer, corners[i], corners[(i + 1) % 4]) for i in range(4)]
        return max(segments, key=lambda p: _path_lengths(bm, p, False)[1])
    return outer[: max(3, len(outer) // 4 + 1)]


def _straighten_chart(context: Any, operator: Any, bm: bmesh.types.BMesh, uv_layer: Any, chart: _Chart) -> bool:
    edge_ids = _selected_reference_edges(bm, uv_layer, chart)
    if not edge_ids:
        edge_ids = _axis_reference_edges(context, operator, bm, chart)
    paths = _edge_components_as_paths(bm, edge_ids) if edge_ids else []
    path = max(paths, key=lambda p: _path_lengths(bm, p, False)[1]) if paths else _fallback_reference_path(bm, chart)
    if path is None or len(path) < 3:
        return False
    old = _chart_uv_by_vert(bm, uv_layer, chart)
    current = [old[vi] for vi in path]
    center = sum(current, Vector()) / len(current)
    if _np is not None:
        arr = _np.array([[p.x - center.x, p.y - center.y] for p in current], dtype=float)
        try:
            _vals, vecs = _np.linalg.eigh(arr.T @ arr)
            direction = Vector(vecs[:, int(_np.argmax(_vals))].tolist()).normalized()
        except Exception:
            direction = current[-1] - current[0]
    else:
        direction = current[-1] - current[0]
    if direction.length < _EPS:
        direction = Vector((1.0, 0.0))
    direction.normalize()
    cumulative, total_3d = _path_lengths(bm, path, False)
    projections = [(p - center).dot(direction) for p in current]
    span = max(projections) - min(projections)
    if span < _EPS:
        span = max(total_3d, 1.0)
    start = center + direction * (-span * 0.5)
    fixed_displacement: Dict[int, Vector] = {}
    targets: Dict[int, Vector] = {}
    for i, vi in enumerate(path):
        t = cumulative[min(i, len(cumulative) - 1)] / max(total_3d, _EPS)
        target = start + direction * (span * t)
        targets[vi] = target
        fixed_displacement[vi] = target - old[vi]
    # Existing pins not on the reference act as stationary constraints.
    pinned: Set[int] = set()
    for fi in chart.faces:
        for loop in bm.faces[fi].loops:
            if bool(getattr(loop[uv_layer], "pin_uv", False)):
                pinned.add(loop.vert.index)
    for vi in pinned - set(path):
        fixed_displacement[vi] = Vector((0.0, 0.0))
    zero = {vi: Vector((0.0, 0.0)) for vi in chart.verts}
    displacement = _harmonic_solve(bm, chart, fixed_displacement, zero, iterations=400)
    result = {vi: old[vi] + displacement[vi] for vi in chart.verts}
    result.update(targets)
    _assign_chart_uv(bm, uv_layer, chart, result)
    return True


def _weld_unmarked_edges(bm: bmesh.types.BMesh, uv_layer: Any, charts: Sequence[_Chart]) -> None:
    """Final safety invariant: each chart vertex owns one UV coordinate.

    This is not used as the primary parameterizer; it only removes numerical or
    native-operator discontinuities left on non-seam edges.
    """
    for chart in charts:
        coords = _chart_uv_by_vert(bm, uv_layer, chart)
        _assign_chart_uv(bm, uv_layer, chart, coords)


def _uv_face_area(face: bmesh.types.BMFace, uv_layer: Any) -> float:
    pts = [loop[uv_layer].uv for loop in face.loops]
    area = 0.0
    for i, p in enumerate(pts):
        q = pts[(i + 1) % len(pts)]
        area += p.x * q.y - q.x * p.y
    return abs(area) * 0.5


def _repair_degenerate_charts(bm: bmesh.types.BMesh, uv_layer: Any, charts: Sequence[_Chart]) -> None:
    for chart in charts:
        if chart.faces and all(_uv_face_area(bm.faces[fi], uv_layer) > 1.0e-12 for fi in chart.faces):
            continue
        old = _chart_uv_by_vert(bm, uv_layer, chart)
        coords = _unfold_chart(bm, chart)
        if not coords:
            coords = _planar_coords(bm, chart)
        _assign_chart_uv(bm, uv_layer, chart, _fit_to_old(coords, old))


def _native_uv_call(context: Any, op: Callable[..., Any], **kwargs: Any) -> Set[str]:
    try:
        result = op(**kwargs)
        return set(result) if result else {"FINISHED"}
    except TypeError:
        # Blender versions can differ by a newly added keyword. Retry only with
        # properties that exist on the operator RNA.
        try:
            rna = op.get_rna_type()
            valid = {p.identifier for p in rna.properties}
            filtered = {k: v for k, v in kwargs.items() if k in valid}
            result = op(**filtered)
            return set(result) if result else {"FINISHED"}
        except Exception:
            return {"CANCELLED"}
    except Exception:
        return {"CANCELLED"}


def _native_unwrap(context: Any, operator: Any, method: str) -> Set[str]:
    margin = max(0.0, _read_float(context, operator, ("margin", "uv_margin", "island_margin", "unwrap_margin"), 0.001, fuzzy=("margin",)))
    fill_holes = _read_bool(context, operator, ("fill_holes", "unwrap_fill_holes"), True, fuzzy=("fill", "hole"))
    correct_aspect = _read_bool(context, operator, ("correct_aspect", "use_aspect", "aspect_correction"), True, fuzzy=("aspect",))
    use_subsurf = _read_bool(context, operator, ("use_subsurf_data", "subsurf_data", "use_subdivision"), False, fuzzy=("subsurf",))
    no_flip = _read_bool(context, operator, ("no_flip", "prevent_flips", "prevent_flip"), False, fuzzy=("flip",))
    iterations = max(1, _read_int(context, operator, ("iterations", "unwrap_iterations", "min_stretch_iterations"), 10, fuzzy=("iteration",)))
    margin_method = _read_string(context, operator, ("margin_method", "unwrap_margin_method"), "SCALED", fuzzy=("margin", "method")).upper()
    if margin_method not in {"SCALED", "ADD", "FRACTION"}: margin_method = "SCALED"
    native_method = method if method in {"ANGLE_BASED", "CONFORMAL", "MINIMUM_STRETCH"} else "ANGLE_BASED"
    return _native_uv_call(
        context, bpy.ops.uv.unwrap,
        method=native_method,
        fill_holes=fill_holes,
        correct_aspect=correct_aspect,
        use_subsurf_data=use_subsurf,
        margin_method=margin_method,
        margin=margin,
        no_flip=no_flip,
        iterations=iterations,
    )


def _pack_existing_charts(context: Any, operator: Any) -> Set[str]:
    margin = max(0.0, _read_float(context, operator, ("margin", "uv_margin", "island_margin", "unwrap_margin"), 0.001, fuzzy=("margin",)))
    rotate = _read_bool(context, operator, ("rotate", "use_rotation", "allow_rotation"), True, fuzzy=("rotation",))
    scale = _read_bool(context, operator, ("scale", "use_scale", "allow_scale"), True, fuzzy=("scale",))
    return _native_uv_call(context, bpy.ops.uv.pack_islands, rotate=rotate, scale=scale, margin=margin)


def _run_custom_on_states(context: Any, operator: Any, states: Sequence[_ObjectSnapshot], method: str) -> bool:
    changed = False
    axis = _read_string(context, operator, ("axis", "projection_axis", "cylinder_axis", "sphere_axis"), "Z", fuzzy=("axis",))
    for state in states:
        obj = state.obj
        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
        bm.verts.index_update(); bm.edges.index_update(); bm.faces.index_update()
        uv_layer = _active_uv_layer(bm, state)
        charts = _build_charts(bm, state.target_faces)
        for chart in charts:
            old = _chart_uv_by_vert(bm, uv_layer, chart)
            if method == "REFERENCE_STRAIGHTEN":
                changed = _straighten_chart(context, operator, bm, uv_layer, chart) or changed
                continue
            if method == "SQUARE":
                changed = _square_chart(bm, uv_layer, chart, _explicit_corner_vertices(bm, uv_layer, chart)) or changed
                continue
            if method == "CIRCLE":
                changed = _circle_chart(bm, uv_layer, chart) or changed
                continue
            if method in {"PLANAR", "QUICK_PLANAR"}:
                coords = _planar_coords(bm, chart)
            elif method == "BOX" or method == "FACE":
                coords = _unfold_chart(bm, chart)
            elif method == "CYLINDER":
                coords = _cylindrical_coords(bm, chart, axis)
            elif method == "SPHERE":
                coords = _spherical_coords(bm, chart, axis)
            elif method == "VIEW":
                coords = _view_coords(context, bm, chart)
            else:
                coords = _unfold_chart(bm, chart)
            if coords:
                _assign_chart_uv(bm, uv_layer, chart, _fit_to_old(coords, old)); changed = True
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    return changed


def _apply_reference_postprocess(context: Any, operator: Any, states: Sequence[_ObjectSnapshot]) -> bool:
    enabled = _read_bool(
        context, operator,
        ("reference_straighten", "use_reference_straighten", "straighten_reference", "baseline_straighten"),
        False,
        fuzzy=("reference", "straight"),
    )
    if not enabled:
        return False
    return _run_custom_on_states(context, operator, states, "REFERENCE_STRAIGHTEN")


def _execute_method(context: Any, operator: Any, method: str, states: Sequence[_ObjectSnapshot]) -> Set[str]:
    auto_seam = _auto_seam_enabled(context, operator)
    native_result: Set[str] = {"CANCELLED"}

    if method in {"REFERENCE_STRAIGHTEN", "SQUARE", "CIRCLE", "PLANAR", "QUICK_PLANAR"}:
        if _run_custom_on_states(context, operator, states, method):
            return {"FINISHED"}
        return {"CANCELLED"}

    _prepare_native_selection(states)

    if method in {"ANGLE_BASED", "CONFORMAL", "MINIMUM_STRETCH", "DETAILED"}:
        solver = method if method != "DETAILED" else _canonical_method(_read_string(
            context, operator,
            ("solver", "unwrap_solver", "detailed_solver", "method_solver"),
            "ANGLE_BASED", fuzzy=("solver",),
        )) or "ANGLE_BASED"
        if solver not in {"ANGLE_BASED", "CONFORMAL", "MINIMUM_STRETCH"}:
            solver = "ANGLE_BASED"
        native_result = _native_unwrap(context, operator, solver)

    elif method == "SMART_PROJECT":
        if auto_seam:
            angle = _read_float(context, operator, ("angle_limit", "smart_angle_limit"), math.radians(66.0), fuzzy=("angle", "limit"))
            if angle > math.pi: angle = math.radians(angle)
            margin = max(0.0, _read_float(context, operator, ("island_margin", "margin", "uv_margin"), 0.001, fuzzy=("margin",)))
            area_weight = max(0.0, min(1.0, _read_float(context, operator, ("area_weight", "smart_area_weight"), 0.0, fuzzy=("area", "weight"))))
            correct = _read_bool(context, operator, ("correct_aspect", "aspect_correction"), True, fuzzy=("aspect",))
            scale_bounds = _read_bool(context, operator, ("scale_to_bounds", "smart_scale_to_bounds"), False, fuzzy=("scale", "bound"))
            native_result = _native_uv_call(
                context, bpy.ops.uv.smart_project,
                angle_limit=max(0.0, min(math.pi, angle)), island_margin=margin,
                area_weight=area_weight, correct_aspect=correct, scale_to_bounds=scale_bounds,
            )
        else:
            native_result = _native_unwrap(context, operator, "ANGLE_BASED")
            if "FINISHED" in native_result:
                _pack_existing_charts(context, operator)

    elif method == "LIGHTMAP":
        if auto_seam:
            new_layer = _read_bool(context, operator, ("new_uv_layer", "lightmap_new_uv_layer"), False, fuzzy=("new", "uv", "layer"))
            image_size = max(64, _read_int(context, operator, ("image_size", "lightmap_image_size", "resolution"), 1024, fuzzy=("image", "size")))
            box_div = max(1, _read_int(context, operator, ("box_div", "lightmap_box_div"), 12, fuzzy=("box", "div")))
            margin_div = max(0.001, _read_float(context, operator, ("margin_div", "lightmap_margin_div", "margin"), 0.1, fuzzy=("margin",)))
            native_result = _native_uv_call(
                context, bpy.ops.uv.lightmap_pack,
                PREF_CONTEXT="SEL_FACES", PREF_PACK_IN_ONE=True, PREF_NEW_UVLAYER=new_layer,
                PREF_APPLY_IMAGE=False, PREF_IMG_PX_SIZE=image_size,
                PREF_BOX_DIV=box_div, PREF_MARGIN_DIV=margin_div,
            )
        else:
            native_result = _native_unwrap(context, operator, "CONFORMAL")
            if "FINISHED" in native_result:
                _pack_existing_charts(context, operator)

    elif method == "FOLLOW_ACTIVE_QUADS":
        mode = _read_string(context, operator, ("quad_mode", "follow_mode", "edge_length_mode"), "LENGTH_AVERAGE", fuzzy=("quad", "mode")).upper()
        if mode not in {"EVEN", "LENGTH", "LENGTH_AVERAGE"}: mode = "LENGTH_AVERAGE"
        native_result = _native_uv_call(context, bpy.ops.uv.follow_active_quads, mode=mode)
        if "FINISHED" not in native_result:
            # A non-quad or missing-active-face selection still receives a useful continuous result.
            _run_custom_on_states(context, operator, states, "SQUARE")
            native_result = {"FINISHED"}

    elif method in {"BOX", "CYLINDER", "SPHERE", "VIEW", "FACE"}:
        if auto_seam:
            if method == "BOX":
                size = max(_EPS, _read_float(context, operator, ("cube_size", "box_size", "projection_size"), 1.0, fuzzy=("cube", "size")))
                native_result = _native_uv_call(
                    context, bpy.ops.uv.cube_project,
                    cube_size=size,
                    correct_aspect=_read_bool(context, operator, ("correct_aspect",), True, fuzzy=("aspect",)),
                    clip_to_bounds=_read_bool(context, operator, ("clip_to_bounds",), False, fuzzy=("clip", "bound")),
                    scale_to_bounds=_read_bool(context, operator, ("scale_to_bounds",), False, fuzzy=("scale", "bound")),
                )
            elif method == "CYLINDER":
                native_result = _native_uv_call(
                    context, bpy.ops.uv.cylinder_project,
                    direction=_read_string(context, operator, ("direction", "projection_direction"), "ALIGN_TO_OBJECT", fuzzy=("direction",)),
                    align=_read_string(context, operator, ("align", "projection_align"), "POLAR_ZX", fuzzy=("align",)),
                    radius=max(_EPS, _read_float(context, operator, ("radius", "cylinder_radius"), 1.0, fuzzy=("radius",))),
                    correct_aspect=_read_bool(context, operator, ("correct_aspect",), True, fuzzy=("aspect",)),
                    clip_to_bounds=_read_bool(context, operator, ("clip_to_bounds",), False, fuzzy=("clip", "bound")),
                    scale_to_bounds=_read_bool(context, operator, ("scale_to_bounds",), False, fuzzy=("scale", "bound")),
                )
            elif method == "SPHERE":
                native_result = _native_uv_call(
                    context, bpy.ops.uv.sphere_project,
                    direction=_read_string(context, operator, ("direction", "projection_direction"), "ALIGN_TO_OBJECT", fuzzy=("direction",)),
                    align=_read_string(context, operator, ("align", "projection_align"), "POLAR_ZX", fuzzy=("align",)),
                    correct_aspect=_read_bool(context, operator, ("correct_aspect",), True, fuzzy=("aspect",)),
                    clip_to_bounds=_read_bool(context, operator, ("clip_to_bounds",), False, fuzzy=("clip", "bound")),
                    scale_to_bounds=_read_bool(context, operator, ("scale_to_bounds",), False, fuzzy=("scale", "bound")),
                )
            elif method == "VIEW":
                native_result = _native_uv_call(
                    context, bpy.ops.uv.project_from_view,
                    orthographic=_read_bool(context, operator, ("orthographic", "view_orthographic"), False, fuzzy=("orthographic",)),
                    correct_aspect=_read_bool(context, operator, ("correct_aspect",), True, fuzzy=("aspect",)),
                    clip_to_bounds=_read_bool(context, operator, ("clip_to_bounds",), False, fuzzy=("clip", "bound")),
                    scale_to_bounds=_read_bool(context, operator, ("scale_to_bounds",), False, fuzzy=("scale", "bound")),
                )
            else:
                native_result = _native_uv_call(context, bpy.ops.uv.reset)
        else:
            _run_custom_on_states(context, operator, states, method)
            native_result = {"FINISHED"}

    else:
        # Unknown alias: retain original operator behavior by signalling cancellation to wrapper.
        return {"CANCELLED"}

    # Native operators can legitimately report success yet leave a degenerate chart
    # in an impossible topology. Repair only degenerate selected charts.
    if "FINISHED" in native_result:
        for state in states:
            bm = bmesh.from_edit_mesh(state.obj.data)
            bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
            bm.verts.index_update(); bm.edges.index_update(); bm.faces.index_update()
            uv_layer = _active_uv_layer(bm, state)
            charts = _build_charts(bm, state.target_faces)
            if not auto_seam:
                _weld_unmarked_edges(bm, uv_layer, charts)
            _repair_degenerate_charts(bm, uv_layer, charts)
            bmesh.update_edit_mesh(state.obj.data, loop_triangles=False, destructive=False)
        _apply_reference_postprocess(context, operator, states)
    return native_result


def _report(operator: Any, level: Set[str], en: str, ja: str) -> None:
    try:
        operator.report(level, _localized(en, ja))
    except Exception:
        pass


def _execute_rebuilt(operator: Any, context: Any, original: Callable[..., Any], default_method: Optional[str]) -> Set[str]:
    method = _resolve_method(context, operator, default_method)
    if method is None:
        return original(operator, context)
    if getattr(context, "mode", "") != "EDIT_MESH":
        return original(operator, context)
    states = _snapshot_all(context)
    if not states:
        _report(operator, {"WARNING"}, "Select UV faces to unwrap.", "展開するUV面を選択してください。")
        return {"CANCELLED"}
    tool_settings = context.scene.tool_settings
    sync_before = bool(tool_settings.use_uv_select_sync)
    uv_mode_before = str(tool_settings.uv_select_mode)
    mesh_mode_before = tuple(tool_settings.mesh_select_mode)
    active_before = getattr(context.view_layer.objects, "active", None)
    selected_before = [obj for obj in context.selected_objects]
    try:
        result = _execute_method(context, operator, method, states)
        if "FINISHED" not in result:
            # For a recognized method, do not silently run the known-broken legacy path.
            _report(
                operator, {"WARNING"},
                "The selected unwrap method could not process this topology. Check the face selection and required reference chain or active quad.",
                "選択した展開方法でこのトポロジーを処理できませんでした。面選択、必要な基準エッジ列、またはアクティブ四角面を確認してください。",
            )
        return result
    except Exception as exc:
        _report(operator, {"ERROR"}, f"UV unwrap failed: {exc}", f"UV展開に失敗しました: {exc}")
        return {"CANCELLED"}
    finally:
        # Keep generated UVs only on target faces, while restoring all state flags.
        for state in states:
            try: _restore_state(state, restore_non_targets=True)
            except Exception: pass
        try:
            if bool(tool_settings.use_uv_select_sync) != sync_before:
                tool_settings.use_uv_select_sync = sync_before
        except Exception: pass
        try: tool_settings.uv_select_mode = uv_mode_before
        except Exception: pass
        try: tool_settings.mesh_select_mode = mesh_mode_before
        except Exception: pass
        try:
            for obj in context.view_layer.objects:
                obj.select_set(obj in selected_before)
            context.view_layer.objects.active = active_before
        except Exception:
            pass


def _operator_subclasses() -> List[type]:
    result: List[type] = []
    seen: Set[type] = set()
    queue = list(())
    while queue:
        cls = queue.pop()
        if cls in seen: continue
        seen.add(cls); result.append(cls)
        try: queue.extend(())
        except Exception: pass
    return result


def _class_source(cls: type) -> str:
    parts: List[str] = []
    try: parts.append(inspect.getsource(cls))
    except Exception: pass
    try: parts.append(inspect.getsource(getattr(cls, "execute")))
    except Exception: pass
    return "\n".join(parts)


def _class_method_tokens(cls: type, source: str) -> Set[str]:
    tokens: Set[str] = set()
    rna = getattr(cls, "bl_rna", None)
    props = getattr(rna, "properties", None)
    if props:
        for prop in props:
            if str(getattr(prop, "type", "")) == "ENUM":
                try:
                    for item in prop.enum_items:
                        method = _canonical_method(item.identifier)
                        if method: tokens.add(method)
                except Exception:
                    pass
    for raw in re.findall(r"['\"]([A-Za-z0-9_\u3040-\u30ff\u3400-\u9fff]+)['\"]", source):
        method = _canonical_method(raw)
        if method: tokens.add(method)
    return tokens


def _default_method_from_class(cls: type, source: str, tokens: Set[str]) -> Optional[str]:
    identity = " ".join((cls.__name__, str(getattr(cls, "bl_idname", "")), str(getattr(cls, "bl_label", ""))))
    method = _canonical_method(identity)
    if method: return method
    if len(tokens) == 1: return next(iter(tokens))
    return None


def _candidate_score(cls: type, source: str, tokens: Set[str]) -> int:
    module = str(getattr(cls, "__module__", ""))
    root = _addon_package_name()
    if root not in module and "smart_uv" not in module.lower() and "suv" not in module.lower():
        return -100
    identity = " ".join((cls.__name__, str(getattr(cls, "bl_idname", "")), str(getattr(cls, "bl_label", "")), module)).lower()
    score = 0
    if "unwrap" in identity: score += 12
    if "uv" in identity: score += 2
    if len(tokens) >= 4: score += 18
    elif tokens: score += 7
    if "bpy.ops.uv" in source: score += 8
    if any(k in source for k in ("SMART_PROJECT", "FOLLOW_ACTIVE_QUADS", "ANGLE_BASED", "MINIMUM_STRETCH")): score += 8
    if "pack" in identity and "unwrap" not in identity: score -= 10
    if module == __name__: score = -100
    return score


def _make_description(original: Any, default_method: Optional[str]) -> Callable[..., str]:
    @classmethod
    def description(cls: type, context: Any, properties: Any) -> str:
        method = _resolve_method(context, properties, default_method)
        if method in _METHOD_DESCRIPTIONS:
            en, ja = _METHOD_DESCRIPTIONS[method]
            return _localized(en, ja)
        if original is not None:
            try:
                raw = original.__func__ if hasattr(original, "__func__") else original
                return raw(cls, context, properties)
            except Exception:
                pass
        return ""
    return description


def _install_operator_patches() -> int:
    patched = 0
    for cls in _operator_subclasses():
        operator_id = str(getattr(cls, "bl_idname", "") or "")
        if operator_id in _UNWRAP_PATCH_EXCLUDED_IDNAMES:
            continue
        if bool(getattr(cls, "_suv_exclude_unwrap_rebuild", False)):
            continue
        if operator_id not in _TARGET_UNWRAP_OPERATOR_IDS:
            continue
        if getattr(cls, _PATCH_ATTR, False):
            patched += 1
            continue
        source = _class_source(cls)
        tokens = _class_method_tokens(cls, source)
        original = getattr(cls, "execute", None)
        if not callable(original):
            continue
        # The action operator exposes mode directly; the run operator resolves
        # the current UV Unwrap workspace setting.  Do not infer a default from
        # the shared SmartUVSuite class-name prefix.
        default_method = None
        _ORIGINAL_EXECUTES[cls] = original
        _ORIGINAL_DESCRIPTIONS[cls] = getattr(cls, "description", None)

        def _make_execute_callback(
            captured_original: Callable[..., Any],
            captured_default: Optional[str],
        ) -> Callable[[Any, Any], Set[str]]:
            # Blender validates Operator.execute by positional arity, including
            # parameters that only have default values.  Keep the registered
            # callback strictly at ``(self, context)`` and capture state in this
            # enclosing factory instead of hidden default arguments.
            def execute(self: Any, context: Any) -> Set[str]:
                method = _resolve_method(context, self, captured_default)
                if method is None:
                    return captured_original(self, context)
                return _execute_rebuilt(self, context, captured_original, captured_default)
            return execute

        execute = _make_execute_callback(original, default_method)

        # Re-register custom operators after replacing callbacks.  Blender's RNA
        # dispatcher can retain the callback registered with the old class body;
        # explicit re-registration guarantees that UI buttons call this execute.
        was_registered = bool(getattr(cls, "is_registered", False))
        if was_registered:
            try: _suv_resource.unregister_class(cls)
            except Exception: was_registered = False
        cls.execute = execute
        cls.description = _make_description(_ORIGINAL_DESCRIPTIONS[cls], default_method)
        setattr(cls, "_suv_rebuild_default_method", default_method)
        setattr(cls, _PATCH_ATTR, True)
        if was_registered:
            _suv_resource.register_class(cls)
        _PATCHED_CLASSES.append(cls)
        patched += 1
    return patched


def _panel_subclasses() -> List[type]:
    result: List[type] = []
    seen: Set[type] = set(); queue = []
    while queue:
        cls = queue.pop()
        if cls in seen: continue
        seen.add(cls); result.append(cls)
        try: queue.extend(())
        except Exception: pass
    return result


def _install_panel_patch() -> bool:
    global _PANEL_CLASS, _PANEL_DRAW, _DYNAMIC_PANEL_CLASS, _PANEL_HAS_EXISTING_CONTROL
    if _PANEL_CLASS is not None or _DYNAMIC_PANEL_CLASS is not None or _PANEL_HAS_EXISTING_CONTROL:
        return True
    root = _addon_package_name()
    scored: List[Tuple[int, type, str]] = []
    related: List[type] = []
    for cls in _panel_subclasses():
        module = str(getattr(cls, "__module__", ""))
        if root not in module and "smart_uv" not in module.lower():
            continue
        related.append(cls)
        draw = getattr(cls, "draw", None)
        if not callable(draw): continue
        try: source = inspect.getsource(draw)
        except Exception: source = ""
        identity = " ".join((cls.__name__, str(getattr(cls, "bl_label", "")), source)).lower()
        score = 0
        if "unwrap" in identity: score += 10
        if "uv展開" in identity: score += 12
        for token in ("smart_project", "follow_active_quads", "minimum_stretch", "angle_based", "lightmap"):
            if token in identity: score += 4
        if "auto_seam" in identity or "自動シーム" in identity:
            # Existing UI already exposes a property; core reads this legacy
            # value as well as the guaranteed replacement property.
            _PANEL_HAS_EXISTING_CONTROL = True
            return True
        if score > 0: scored.append((score, cls, source))
    if scored:
        scored.sort(key=lambda item: item[0], reverse=True)
        _score, cls, _source = scored[0]
        original = cls.draw

        def _make_draw_callback(captured_original: Callable[..., Any]) -> Callable[[Any, Any], None]:
            # Keep the RNA callback signature exactly at ``(self, context)``.
            def draw(self: Any, context: Any) -> None:
                captured_original(self, context)
                scene = getattr(context, "scene", None)
                if scene is None or not hasattr(scene, _SCENE_PROP):
                    return
                layout = self.layout
                box = layout.box()
                box.prop(scene, _SCENE_PROP, text=bpy.app.translations.pgettext_iface("Enable Automatic Seams"))
            return draw

        cls.draw = _make_draw_callback(original)
        setattr(cls, _PATCH_ATTR, True)
        _PANEL_CLASS = cls; _PANEL_DRAW = original
        return True

    # Last-resort UI: create a child panel beside the add-on's existing UV
    # panels.  This path is used only when generated/dynamic panel source cannot
    # be inspected; the setting must never silently disappear.
    template = related[0] if related else None
    attrs: Dict[str, Any] = {
        "bl_idname": "SUV_PT_unwrap_seam_control_18131",
        "bl_label": "UV Unwrap",
        "bl_space_type": str(getattr(template, "bl_space_type", "IMAGE_EDITOR")),
        "bl_region_type": str(getattr(template, "bl_region_type", "UI")),
        # Always use the one canonical sidebar category.  Copying a transient
        # template category here could create a second "Smart UV Suite" tab
        # when this last-resort panel is registered during startup.
        "bl_category": "Smart UV",
        "bl_options": {"DEFAULT_CLOSED"},
        "__module__": __name__,
    }
    parent_id = str(getattr(template, "bl_idname", "")) if template else ""
    # A discovered Panel subclass can still be unregistered while add-on
    # modules are registering.  Blender rejects a child whose parent RNA is not
    # available, so attach only to a currently registered parent; otherwise
    # create the fallback as an independent panel in the same category.
    parent_is_registered = False
    if parent_id:
        try:
            parent_is_registered = getattr(bpy.types, parent_id, None) is not None
        except Exception:
            parent_is_registered = False
    if parent_is_registered:
        attrs["bl_parent_id"] = parent_id

    def draw_fallback(self: Any, context: Any) -> None:
        scene = getattr(context, "scene", None)
        if scene is not None and hasattr(scene, _SCENE_PROP):
            self.layout.prop(scene, _SCENE_PROP, text=bpy.app.translations.pgettext_iface("Enable Automatic Seams"))

    attrs["draw"] = draw_fallback
    panel_cls = type("SUV_PT_UnwrapSeamControl18131", (bpy.types.Panel,), attrs)
    try:
        _suv_resource.register_class(panel_cls)
        _DYNAMIC_PANEL_CLASS = panel_cls
        return True
    except Exception:
        return False


def _installation_complete() -> bool:
    """Return True once both target operators and one visible control exist."""
    try:
        patched_ids = {
            str(getattr(cls, 'bl_idname', '') or '')
            for cls in _PATCHED_CLASSES
            if bool(getattr(cls, _PATCH_ATTR, False))
        }
        operators_ready = _TARGET_UNWRAP_OPERATOR_IDS.issubset(patched_ids)
    except Exception:
        operators_ready = False
    panel_ready = bool(_PANEL_CLASS is not None or _DYNAMIC_PANEL_CLASS is not None or _PANEL_HAS_EXISTING_CONTROL)
    return bool(operators_ready and panel_ready)


def _ensure_runtime_version() -> None:
    root = _addon_package_name()
    module = sys.modules.get(root)
    if module is not None:
        try: module.__version__ = _VERSION_STR
        except Exception: pass
        info = getattr(module, "bl_info", None)
        if isinstance(info, dict): info["version"] = _VERSION


def _timer_install() -> Optional[float]:
    global _TIMER_RUNS
    _TIMER_RUNS += 1
    try:
        _install_operator_patches(); _install_panel_patch(); _ensure_runtime_version()
    except Exception:
        pass
    # The old timer always ran twelve times even when the two target operators
    # and the panel control were patched by the synchronous register pass.
    # Stop as soon as the complete public contract is present; if a dynamic
    # operator/panel is registered later, the bounded retry remains available.
    if _installation_complete():
        return None
    return 0.25 if _TIMER_RUNS < 12 else None


def register() -> None:
    global _TIMER_RUNS
    _TIMER_RUNS = 0
    try:
        _ownership.register_translation(_TRANSLATION_KEY, _TRANSLATIONS)
    except Exception:
        pass
    if not hasattr(bpy.types.Scene, _SCENE_PROP):
        _suv_resource.register_property(
            bpy.types.Scene,
            _SCENE_PROP,
            BoolProperty(
                name="Enable Automatic Seams",
                description=(
                    "Allow the selected unwrap method to create UV island boundaries on edges that are not marked as seams. "
                    "Keep this disabled to guarantee that only user-marked seams separate islands. Methods that normally generate charts automatically will instead operate on the existing seam-bounded charts."
                ),
                default=False,
            ),
        )
    _ensure_runtime_version()
    _install_operator_patches()
    _install_panel_patch()
    if not _installation_complete() and not _suv_resource.timer_is_registered(_timer_install):
        None  # 1.8.169: no deferred registration timer


def unregister() -> None:
    global _PANEL_CLASS, _PANEL_DRAW, _DYNAMIC_PANEL_CLASS, _PANEL_HAS_EXISTING_CONTROL, _TIMER_RUNS
    try:
        if _suv_resource.timer_is_registered(_timer_install): _suv_resource.timer_unregister(_timer_install)
    except Exception:
        pass
    if _PANEL_CLASS is not None and _PANEL_DRAW is not None:
        try: _PANEL_CLASS.draw = _PANEL_DRAW
        except Exception: pass
    _PANEL_CLASS = None; _PANEL_DRAW = None
    if _DYNAMIC_PANEL_CLASS is not None:
        try: _suv_resource.unregister_class(_DYNAMIC_PANEL_CLASS)
        except Exception: pass
    _DYNAMIC_PANEL_CLASS = None
    _PANEL_HAS_EXISTING_CONTROL = False
    for cls in reversed(_PATCHED_CLASSES):
        original = _ORIGINAL_EXECUTES.get(cls)
        was_registered = bool(getattr(cls, "is_registered", False))
        if was_registered:
            try: _suv_resource.unregister_class(cls)
            except Exception: was_registered = False
        if original is not None:
            try: cls.execute = original
            except Exception: pass
        desc = _ORIGINAL_DESCRIPTIONS.get(cls)
        try:
            if desc is None and hasattr(cls, "description"): delattr(cls, "description")
            elif desc is not None: cls.description = desc
        except Exception:
            pass
        try: delattr(cls, _PATCH_ATTR)
        except Exception: pass
        if was_registered:
            try: _suv_resource.register_class(cls)
            except Exception: pass
    _PATCHED_CLASSES.clear(); _ORIGINAL_EXECUTES.clear(); _ORIGINAL_DESCRIPTIONS.clear()
    try:
        _suv_resource.unregister_property(bpy.types.Scene, _SCENE_PROP)
    except Exception:
        pass
    try: _ownership.unregister_translation(_TRANSLATION_KEY)
    except Exception: pass
    _TIMER_RUNS = 0


# Test-facing helpers are intentionally private but stable within this release.
def _test_run(context: Any, method: str, auto_seam: bool = False) -> Set[str]:
    scene = context.scene
    setattr(scene, _SCENE_PROP, bool(auto_seam))

    class _Dummy:
        def report(self, *_args: Any, **_kwargs: Any) -> None: pass

    dummy = _Dummy()
    states = _snapshot_all(context)
    if not states: return {"CANCELLED"}
    try:
        return _execute_method(context, dummy, _canonical_method(method) or method, states)
    finally:
        for state in states: _restore_state(state, True)
