from __future__ import annotations
from . import resource_api_18168 as _suv_resource

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None

_NAMESPACE = {}
_REGISTERED = []


def _tr(context, key: str, en: str, ja: str, **fmt) -> str:
    fn = _NAMESPACE.get('tr')
    text = None
    if callable(fn):
        try:
            text = fn(context, key, **fmt)
        except Exception:
            text = None
    if not text:
        text = en
    try:
        return text.format(**fmt)
    except Exception:
        return text


def _section_state(namespace: dict, context) -> dict:
    data = {'workflow': True, 'learning': True, 'maintenance': True}
    mod = namespace.get('_quality_sections_module')
    if mod is not None and hasattr(mod, 'scan_section_controls'):
        try:
            scan = mod.scan_section_controls(namespace, context) or {}
            data.update(dict(scan.get('visibility', {}) or {}))
        except Exception:
            pass
    return {k: bool(data.get(k, True)) for k in ('workflow', 'learning', 'maintenance')}


def _current(namespace: dict, context) -> dict:
    focus = 'AUTO'
    density = 'AUTO'
    focus_mod = namespace.get('_quality_focus_module')
    if focus_mod is not None and hasattr(focus_mod, 'get_focus_override'):
        try:
            focus = str(focus_mod.get_focus_override(context) or 'AUTO').upper()
        except Exception:
            pass
    density_mod = namespace.get('_quality_density_module')
    if density_mod is not None and hasattr(density_mod, 'get_density_override'):
        try:
            density = str(density_mod.get_density_override(context) or 'AUTO').upper()
        except Exception:
            pass
    return {
        'focus': focus,
        'density': density,
        'sections': _section_state(namespace, context),
    }


def _presets(namespace: dict) -> dict:
    mod = namespace.get('_quality_presets_module')
    data = getattr(mod, '_PRESETS', None)
    return dict(data) if isinstance(data, dict) else {}


def matches_preset(namespace: dict, context, preset: str) -> bool:
    presets = _presets(namespace)
    preset = str(preset or 'AUTO').strip().upper()
    cfg = presets.get(preset)
    if not isinstance(cfg, dict):
        return False
    current = _current(namespace, context)
    cfg_sections = dict(cfg.get('sections', {}) or {})
    if str(cfg.get('focus', 'AUTO') or 'AUTO').upper() != current['focus']:
        return False
    if str(cfg.get('density', 'AUTO') or 'AUTO').upper() != current['density']:
        return False
    for sid in ('workflow', 'learning', 'maintenance'):
        if bool(cfg_sections.get(sid, True)) != bool(current['sections'].get(sid, True)):
            return False
    return True


def effective_preset(namespace: dict, context) -> dict:
    presets = _presets(namespace)
    preset_mod = namespace.get('_quality_presets_module')
    override = 'AUTO'
    if preset_mod is not None and hasattr(preset_mod, 'get_preset_override'):
        try:
            override = str(preset_mod.get_preset_override(context) or 'AUTO').upper()
        except Exception:
            pass
    current = _current(namespace, context)
    matched = matches_preset(namespace, context, override)
    effective = override if matched else 'CUSTOM'
    cfg = presets.get(override if matched else 'AUTO', {})
    if effective == 'CUSTOM':
        label = _tr(context, 'ui.visual.preset.custom', 'Custom', 'カスタム')
    elif preset_mod is not None and hasattr(preset_mod, '_preset_label'):
        try:
            label = preset_mod._preset_label(context, effective)
        except Exception:
            label = effective
    else:
        label = effective
    data = {
        'override': override,
        'effective': effective,
        'manual': override != 'AUTO',
        'matched': bool(matched),
        'label': label,
        'focus': current['focus'],
        'density': current['density'],
        'sections': dict(current['sections']),
        'available_presets': max(len(presets), 1) + 1,
    }
    namespace['_suv_dashboard_preset_effective'] = dict(data)
    return data


def notify_visual_config_changed(namespace: dict, context) -> dict:
    if namespace.get('_suv_visual_sync_in_progress'):
        data = effective_preset(namespace, context)
        namespace['_suv_dashboard_preset_last'] = dict(data)
        return data
    controls_mod = namespace.get('_quality_controls_module')
    if controls_mod is not None and hasattr(controls_mod, 'notify_controls_changed'):
        try:
            namespace['_suv_visual_sync_in_progress'] = True
            data = controls_mod.notify_controls_changed(namespace, context, reason='visual-sync') or {}
            if isinstance(data, dict) and data:
                return data
        except Exception:
            pass
        finally:
            namespace['_suv_visual_sync_in_progress'] = False
    clear = namespace.get('clear_quality_state_cache')
    if callable(clear):
        try:
            clear(namespace)
        except Exception:
            pass
    data = effective_preset(namespace, context)
    namespace['_suv_dashboard_preset_last'] = dict(data)
    return data


class SUV_OT_quality_reset_visual_controls(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_reset_visual_controls'
    bl_label = 'Reset Visual Controls'
    bl_description = 'Reset focus, density, preset, and section visibility back to the adaptive defaults. / フォーカス、表示密度、プリセット、セクション表示を自動の初期状態へ戻します。'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        focus_mod = _NAMESPACE.get('_quality_focus_module')
        density_mod = _NAMESPACE.get('_quality_density_module')
        sections_mod = _NAMESPACE.get('_quality_sections_module')
        presets_mod = _NAMESPACE.get('_quality_presets_module')
        try:
            if focus_mod is not None and hasattr(focus_mod, 'set_focus_override'):
                focus_mod.set_focus_override(context, 'AUTO')
            if density_mod is not None and hasattr(density_mod, 'set_density_override'):
                density_mod.set_density_override(context, 'AUTO')
            if sections_mod is not None and hasattr(sections_mod, 'set_section_visibility'):
                for sid in ('workflow', 'learning', 'maintenance'):
                    sections_mod.set_section_visibility(context, sid, True)
            if presets_mod is not None and hasattr(presets_mod, 'set_preset_override'):
                presets_mod.set_preset_override(context, 'AUTO')
        except Exception:
            pass
        controls_mod = _NAMESPACE.get('_quality_controls_module')
        if controls_mod is not None and hasattr(controls_mod, 'notify_controls_changed'):
            data = controls_mod.notify_controls_changed(_NAMESPACE, context, reason='visual-reset') or {}
        else:
            data = notify_visual_config_changed(_NAMESPACE, context)
        self.report({'INFO'}, _tr(context, 'msg.quality_visual_controls_reset', 'Visual controls reset to {preset}.', '視覚コントロールを {preset} に戻しました。', preset=str(data.get('label', 'Auto'))))
        return {'FINISHED'}


def register(namespace: dict):
    global _NAMESPACE
    _NAMESPACE = namespace if isinstance(namespace, dict) else {}
    if bpy is None:
        return []
    classes = [SUV_OT_quality_reset_visual_controls]
    reg = []
    for cls in classes:
        try:
            _suv_resource.register_class(cls)
            reg.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = reg
    return reg


def unregister(namespace: dict | None = None):
    if bpy is None:
        return []
    removed = []
    for cls in reversed(list(_REGISTERED)):
        try:
            _suv_resource.unregister_class(cls)
            removed.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = []
    return removed
