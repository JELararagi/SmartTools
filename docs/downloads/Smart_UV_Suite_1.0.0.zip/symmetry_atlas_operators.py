from __future__ import annotations
from . import selection_operators as _prev
_IGNORE_KEYS = {'__name__','__package__','__loader__','__spec__','__file__','__cached__','__builtins__'}
globals().update({k: v for k, v in _prev.__dict__.items() if k not in _IGNORE_KEYS})

# ============================================================
# Symmetry Operators
# ============================================================

class SUV_OT_sym_detect_pairs(bpy.types.Operator):
    bl_idname = "uv.suv_sym_detect_pairs"
    bl_label = 'Detect Symmetry Pairs'
    bl_description = "Detect symmetric UV pairs that can be mirrored, stacked or edited together. / ミラーやスタック、同時編集に使える対称UVペアを検出します。"
    bl_options = {'UNDO'}

    axis: bpy.props.EnumProperty(name="Axis", items=[('X','X',''),('Y','Y',''),('Z','Z','')], default='X')
    space: bpy.props.EnumProperty(name="Space", items=[('LOCAL','Object Local',''),('WORLD','World','')], default='LOCAL')
    offset: bpy.props.FloatProperty(name='Offset Islands', default=0.0)
    tolerance: bpy.props.FloatProperty(name="Tolerance", default=1e-4, min=1e-8, max=1e-1)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh")); return {'CANCELLED'}
        with _TempMode(context, obj, 'EDIT'):
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.verify()
            islands = build_islands(bm, uv_layer, faces_subset=list(bm.faces))
            vmap, _rev = _build_mirror_map(obj, bm, axis=self.axis, space=self.space, offset=self.offset, tol=self.tolerance)
            pairs = _detect_sym_pairs(islands, vmap)
        _cache_set(context.scene, "sym_pairs", pairs)
        self.report({'INFO'}, tr(context, "msg.sym_pairs_done", n=int(len(pairs)/2)))
        return {'FINISHED'}

class SUV_OT_sym_mirror_uv(bpy.types.Operator):
    bl_idname = "uv.suv_sym_mirror_uv"
    bl_label = 'Mirror UV (Ref -> Pair)'
    bl_description = "Mirror UVs from one side of a detected pair to the opposite side. / 検出されたペアの片側から反対側へUVをミラー転送します。"
    bl_options = {'UNDO'}

    axis: bpy.props.EnumProperty(name="Axis", items=[('X','X',''),('Y','Y',''),('Z','Z','')], default='X')
    space: bpy.props.EnumProperty(name="Space", items=[('LOCAL','Object Local',''),('WORLD','World','')], default='LOCAL')
    offset: bpy.props.FloatProperty(name='Offset Islands', default=0.0)
    tolerance: bpy.props.FloatProperty(name="Tolerance", default=1e-4, min=1e-8, max=1e-1)
    mirror_uv_axis: bpy.props.EnumProperty(name="UV Mirror Axis", items=[('U','U',''),('V','V','')], default='U')

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh")); return {'CANCELLED'}
        with _TempMode(context, obj, 'EDIT'):
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.verify()
            islands = build_islands(bm, uv_layer, faces_subset=list(bm.faces))
            active_face = getattr(bm.faces, "active", None)
            if not active_face:
                self.report({'WARNING'}, tr(context, "msg.no_selection")); return {'CANCELLED'}
            ref = next((i for i in islands if active_face in i.faces), None)
            if not ref:
                self.report({'WARNING'}, tr(context, "msg.no_selection")); return {'CANCELLED'}
            vmap, rev = _build_mirror_map(obj, bm, axis=self.axis, space=self.space, offset=self.offset, tol=self.tolerance)
            pairs = _detect_sym_pairs(islands, vmap)
            _cache_set(context.scene, "sym_pairs", pairs)
            pid = pairs.get(ref.id)
            if pid is None:
                self.report({'WARNING'}, tr(context, "msg.sym_no_pair")); return {'CANCELLED'}
            pair = next((i for i in islands if i.id == pid), None)
            if not pair:
                self.report({'WARNING'}, tr(context, "msg.sym_no_pair")); return {'CANCELLED'}

            uv_by_vid = {}
            cnt = {}
            for l in ref.loops:
                vid = l.vert.index
                uv = Vector(l[uv_layer].uv)
                uv_by_vid[vid] = uv_by_vid.get(vid, Vector((0.0, 0.0))) + uv
                cnt[vid] = cnt.get(vid, 0) + 1
            for vid in list(uv_by_vid.keys()):
                uv_by_vid[vid] /= float(cnt[vid])

            pivot = Vector(ref.uv_centroid)
            def mirror_uv(uv):
                u = Vector(uv)
                if self.mirror_uv_axis == 'U':
                    u.x = pivot.x - (u.x - pivot.x)
                else:
                    u.y = pivot.y - (u.y - pivot.y)
                return u

            mirrored_samples = []
            target_samples = []
            for l in pair.loops:
                tgt_vid = l.vert.index
                src_vid = rev.get(tgt_vid, None)
                if src_vid is None:
                    continue
                src_uv = uv_by_vid.get(src_vid, None)
                if src_uv is None:
                    continue
                mirrored_samples.append(mirror_uv(src_uv))
                target_samples.append(Vector(l[uv_layer].uv))
            if mirrored_samples and target_samples:
                src_cent = Vector((sum(p.x for p in mirrored_samples) / len(mirrored_samples), sum(p.y for p in mirrored_samples) / len(mirrored_samples)))
                dst_cent = Vector((sum(p.x for p in target_samples) / len(target_samples), sum(p.y for p in target_samples) / len(target_samples)))
                delta = dst_cent - src_cent
            else:
                delta = Vector((0.0, 0.0))

            for l in pair.loops:
                tgt_vid = l.vert.index
                src_vid = rev.get(tgt_vid, None)
                if src_vid is None:
                    continue
                src_uv = uv_by_vid.get(src_vid, None)
                if src_uv is None:
                    continue
                l[uv_layer].uv = mirror_uv(src_uv) + delta

            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)

        self.report({'INFO'}, tr(context, "msg.sym_mirrored"))
        return {'FINISHED'}

class SUV_OT_sym_seams(bpy.types.Operator):
    bl_idname = "uv.suv_sym_seams"
    bl_label = 'Symmetry Seams'
    bl_description = "Create seam suggestions that respect detected symmetry relationships. / 検出した対称関係を保ちながら使いやすいシーム候補を作成します。"
    bl_options = {'UNDO'}

    axis: bpy.props.EnumProperty(name="Axis", items=[('X','X',''),('Y','Y',''),('Z','Z','')], default='X')
    space: bpy.props.EnumProperty(name="Space", items=[('LOCAL','Object Local',''),('WORLD','World','')], default='LOCAL')
    offset: bpy.props.FloatProperty(name='Offset Islands', default=0.0)
    tolerance: bpy.props.FloatProperty(name="Tolerance", default=1e-4, min=1e-8, max=1e-1)
    mode: bpy.props.EnumProperty(name="Mode", items=[('MARK','Mark',''),('CLEAR','Clear','')], default='MARK')
    include_cross: bpy.props.BoolProperty(name="Include Cross-Plane", default=True)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh")); return {'CANCELLED'}
        idx = _axis_index(self.axis)
        with _TempMode(context, obj, 'EDIT'):
            bm = bmesh.from_edit_mesh(obj.data)
            bm.edges.ensure_lookup_table()
            for e in bm.edges:
                v0 = e.verts[0].co.copy()
                v1 = e.verts[1].co.copy()
                if self.space == 'WORLD':
                    v0 = obj.matrix_world @ v0
                    v1 = obj.matrix_world @ v1
                d0 = v0[idx] - self.offset
                d1 = v1[idx] - self.offset
                on0 = abs(d0) <= self.tolerance
                on1 = abs(d1) <= self.tolerance
                cross = ((d0 > 0 and d1 < 0) or (d0 < 0 and d1 > 0))
                if on0 and on1:
                    e.seam = (self.mode == 'MARK')
                elif self.include_cross and cross:
                    e.seam = (self.mode == 'MARK')
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        self.report({'INFO'}, tr(context, "msg.sym_seams_done"))
        return {'FINISHED'}

class SUV_OT_sym_stack(bpy.types.Operator):
    bl_idname = "uv.suv_sym_stack"
    bl_label = 'Symmetry Stack'
    bl_description = "Stack symmetric UV islands together to maximize reuse and alignment. / 対称UVアイランドを重ねて再利用性と整列性を高めます。"
    bl_options = {'UNDO'}

    axis: bpy.props.EnumProperty(name="Axis", items=[('X','X',''),('Y','Y',''),('Z','Z','')], default='X')
    space: bpy.props.EnumProperty(name="Space", items=[('LOCAL','Object Local',''),('WORLD','World','')], default='LOCAL')
    offset: bpy.props.FloatProperty(name='Offset Islands', default=0.0)
    tolerance: bpy.props.FloatProperty(name="Tolerance", default=1e-4, min=1e-8, max=1e-1)
    rotation_step: bpy.props.EnumProperty(name="Rotation Step", items=[('0',"Free",""),('90',"90°",""),('45',"45°",""),('15',"15°","")], default='15')
    allow_mirror: bpy.props.BoolProperty(name="Allow Mirror", default=True)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh")); return {'CANCELLED'}
        done = 0
        with _TempMode(context, obj, 'EDIT'):
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.verify()
            faces = [f for f in bm.faces if f.select] or list(bm.faces)
            islands = build_islands(bm, uv_layer, faces_subset=faces)
            vmap, _rev = _build_mirror_map(obj, bm, axis=self.axis, space=self.space, offset=self.offset, tol=self.tolerance)
            pairs = _detect_sym_pairs(islands, vmap)
            used = set()
            for a, b in pairs.items():
                if a in used or b in used or a == b:
                    continue
                ia = next((i for i in islands if i.id == a), None)
                ib = next((i for i in islands if i.id == b), None)
                if not ia or not ib:
                    continue
                ref, mov = (ia, ib) if ia.id < ib.id else (ib, ia)
                SUV_OT_stack_pro._stack_pair(uv_layer, ref, mov, int(self.rotation_step), self.allow_mirror)
                used.add(a); used.add(b)
                done += 1
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        self.report({'INFO'}, tr(context, "msg.sym_stack_done", n=done))
        return {'FINISHED'}

# ============================================================
# Atlas / Material Multi Operators (UDIM mode + multi-pass bake)
# ============================================================

def _ensure_uvmap(obj, name: str):
    me = obj.data
    uv = me.uv_layers.get(name)
    if uv is None:
        uv = me.uv_layers.new(name=name)
    return uv

def _copy_uvmap(obj, src_name: str, dst_name: str):
    me = obj.data
    if str(getattr(obj, 'mode', '') or '').upper() == 'EDIT':
        try:
            bm = bmesh.from_edit_mesh(me)
            src = bm.loops.layers.uv.get(src_name) if src_name else bm.loops.layers.uv.active
            dst = bm.loops.layers.uv.get(dst_name)
            if dst is None:
                dst = bm.loops.layers.uv.new(dst_name)
            if src is None or dst is None:
                return False
            for face in bm.faces:
                for loop in face.loops:
                    src_item = loop[src]
                    dst_item = loop[dst]
                    dst_item.uv = src_item.uv
                    try:
                        dst_item.pin_uv = bool(getattr(src_item, 'pin_uv', False))
                    except Exception:
                        pass
            bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
            mesh_layer = me.uv_layers.get(dst_name)
            if mesh_layer is not None:
                me.uv_layers.active = mesh_layer
            return True
        except Exception:
            return False
    src = me.uv_layers.get(src_name) if src_name else me.uv_layers.active
    dst = _ensure_uvmap(obj, dst_name)
    if not src or not dst:
        return False
    sdata = src.data
    ddata = dst.data
    n = min(len(sdata), len(ddata))
    for i in range(n):
        ddata[i].uv = sdata[i].uv
    me.uv_layers.active = dst
    return True

def _set_active_uv(obj, name: str):
    uv = obj.data.uv_layers.get(name)
    if uv:
        obj.data.uv_layers.active = uv
        return True
    return False

class SUV_OT_atlas_build_uv_multi(bpy.types.Operator):
    bl_idname = "uv.suv_atlas_build_uv_multi"
    bl_label = 'Build Atlas UV (Multi)'
    bl_description = "Build UV layout data for multi-object atlas workflows. / 複数オブジェクトをまとめるアトラス作業向けのUV配置データを作成します。"
    bl_options = {'UNDO'}

    atlas_uv_name: bpy.props.StringProperty(name="Atlas UV Name", default="SUV_Atlas")
    udim_mode: bpy.props.EnumProperty(
        name="UDIM Mode",
        items=[('SINGLE',"Single Tile (0-1)",""),('KEEP_TILES',"Keep Current Tiles","")],
        default='SINGLE'
    )
    margin_px: bpy.props.IntProperty(name="Margin (px)", default=8, min=0)
    texture_size: bpy.props.IntProperty(name="Texture Size", default=2048, min=128)
    rotation_step: bpy.props.EnumProperty(name="Rotation Step", items=[('0',"0°",""),('90',"90°",""),('45',"45°",""),('15',"15°","")], default='15')
    lock_pinned: bpy.props.BoolProperty(name="Lock Pinned Islands", default=True)

    @classmethod
    def poll(cls, context):
        return bool(_selected_mesh_objects(context))

    def execute(self, context):

        objs = _suv_preflight_mesh_objects(context, self, source='Atlas Build UV (Multi)', require_uv=True, require_active_uv=True)
        if not objs:
            return {'CANCELLED'}
        _suv_log_event(context, 'INFO', 'Atlas Build UV (Multi)', 'Starting atlas UV build', {'objects': _suv_brief_object_names(objs), 'atlas_uv': self.atlas_uv_name, 'udim_mode': self.udim_mode})
        with _PreserveContextState(context, restore_mode=True, restore_render_engine=False):
            if not _suv_ensure_object_mode(context, objs[0]):
                _suv_log_event(context, 'WARN', 'Atlas Build UV (Multi)', 'Could not switch the active mesh into Object mode', {'objects': _suv_brief_object_names(objs)})
            try:
                copy_failed = []
                usable_objs = []
                for obj in objs:
                    src = obj.data.uv_layers.active.name if obj.data.uv_layers.active else ""
                    if not _copy_uvmap(obj, src, self.atlas_uv_name):
                        copy_failed.append(obj.name)
                        continue
                    _set_active_uv(obj, self.atlas_uv_name)
                    usable_objs.append(obj)
                if copy_failed:
                    _suv_log_event(context, 'WARN', 'Atlas Build UV (Multi)', 'Skipped objects whose atlas UV could not be created', {'objects': ', '.join(copy_failed)})
                if not usable_objs:
                    self.report({'WARNING'}, tr(context, "msg.op_failed", e="UV copy failed on all selected objects"))
                    return {'CANCELLED'}

                margin_uv = float(self.margin_px) / float(self.texture_size) if self.texture_size > 0 else 0.0
                rot_step = int(self.rotation_step)

                per_obj = {}
                for obj in usable_objs:
                    with _TempMode(context, obj, 'EDIT'):
                        bm = bmesh.from_edit_mesh(obj.data)
                        uv_layer = bm.loops.layers.uv.verify()
                        islands = build_islands(bm, uv_layer, faces_subset=list(bm.faces))
                        per_obj[obj.name] = (uv_layer, islands)

                packed = 0

                if self.udim_mode == 'SINGLE':
                    pseudo = []
                    idx_map = []
                    gid = 0
                    for obj in usable_objs:
                        _uv_layer, islands = per_obj[obj.name]
                        for isl in islands:
                            if self.lock_pinned and isl.has_pin:
                                continue
                            proxy = _Island(gid)
                            proxy.uv_points = isl.uv_points
                            proxy.uv_centroid = isl.uv_centroid
                            proxy.axis = isl.axis
                            proxy.bbox_min = isl.bbox_min
                            proxy.bbox_max = isl.bbox_max
                            pseudo.append(proxy)
                            idx_map.append((obj.name, isl.face_sig))
                            gid += 1
                    placements, ok = _pack_shelf(pseudo, margin_uv, rot_step, allow_rotate=(rot_step != 0))
                    if not ok:
                        self.report({'WARNING'}, tr(context, "msg.op_failed", e="Multi pack overflow"))
                        return {'CANCELLED'}

                    for obj in usable_objs:
                        with _TempMode(context, obj, 'EDIT'):
                            bm = bmesh.from_edit_mesh(obj.data)
                            uv_layer = bm.loops.layers.uv.verify()
                            islands = build_islands(bm, uv_layer, faces_subset=list(bm.faces))
                            isl_by_sig = {i.face_sig: i for i in islands}
                            for j, (oname, sig) in enumerate(idx_map):
                                if oname != obj.name:
                                    continue
                                pl = placements.get(j)
                                if not pl:
                                    continue
                                isl = isl_by_sig.get(sig)
                                if not isl:
                                    continue
                                ang, dx, dy = pl["angle"], pl["dx"], pl["dy"]
                                pivot = isl.uv_centroid
                                def tf(u):
                                    return pivot + _rotate2(u - pivot, ang) + Vector((dx, dy))
                                _island_apply_transform(isl, uv_layer, tf)
                                packed += 1
                            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
                else:
                    by_tile = {}
                    for obj in usable_objs:
                        _uv_layer, islands = per_obj[obj.name]
                        for isl in islands:
                            if self.lock_pinned and isl.has_pin:
                                continue
                            c = isl.uv_centroid
                            tile = (int(math.floor(c.x)), int(math.floor(c.y)))
                            by_tile.setdefault(tile, []).append((obj.name, isl.face_sig))

                    for tile, items in by_tile.items():
                        tile_off = Vector((tile[0], tile[1]))
                        pseudo = []
                        idx_map = []
                        for j, (oname, sig) in enumerate(items):
                            _uv_layer, islands = per_obj[oname]
                            isl = next((i for i in islands if i.face_sig == sig), None)
                            if not isl:
                                continue
                            proxy = _Island(j)
                            proxy.uv_points = [p - tile_off for p in isl.uv_points]
                            proxy.uv_centroid = isl.uv_centroid - tile_off
                            proxy.axis = isl.axis
                            proxy.bbox_min = isl.bbox_min - tile_off
                            proxy.bbox_max = isl.bbox_max - tile_off
                            pseudo.append(proxy)
                            idx_map.append((oname, sig))
                        placements, ok = _pack_shelf(pseudo, margin_uv, rot_step, allow_rotate=(rot_step != 0))
                        if not ok:
                            self.report({'WARNING'}, tr(context, "msg.op_failed", e=f"Overflow in tile {tile}"))
                            return {'CANCELLED'}

                        for obj in usable_objs:
                            with _TempMode(context, obj, 'EDIT'):
                                bm = bmesh.from_edit_mesh(obj.data)
                                uv_layer = bm.loops.layers.uv.verify()
                                islands = build_islands(bm, uv_layer, faces_subset=list(bm.faces))
                                isl_by_sig = {i.face_sig: i for i in islands}
                                for j, (oname, sig) in enumerate(idx_map):
                                    if oname != obj.name:
                                        continue
                                    pl = placements.get(j)
                                    if not pl:
                                        continue
                                    isl = isl_by_sig.get(sig)
                                    if not isl:
                                        continue
                                    ang, dx, dy = pl["angle"], pl["dx"], pl["dy"]
                                    pivot = isl.uv_centroid - tile_off
                                    def tf(u):
                                        uu = Vector(u) - tile_off
                                        uu = pivot + _rotate2(uu - pivot, ang) + Vector((dx, dy))
                                        return uu + tile_off
                                    _island_apply_transform(isl, uv_layer, tf)
                                    packed += 1
                                bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)

                context.scene["SUV_ATLAS_IMAGES"] = json.dumps({})
                _suv_log_event(context, 'INFO', 'Atlas Build UV (Multi)', 'Atlas UV build completed', {'packed': packed, 'objects': len(usable_objs), 'atlas_uv': self.atlas_uv_name, 'skipped': len(copy_failed)})
                self.report({'INFO'}, tr(context, "msg.atlas_multi_packed", n=packed))
                return {'FINISHED'}
            except Exception as e:
                _suv_log_exception(context, 'Atlas Build UV (Multi)', e, {'atlas_uv': self.atlas_uv_name})
                self.report({'WARNING'}, tr(context, "msg.op_failed", e=str(e)))
                return {'CANCELLED'}

class SUV_OT_atlas_bake_multi(bpy.types.Operator):
    bl_idname = "uv.suv_atlas_bake_multi"
    bl_label = 'Bake Atlas (Multi)'
    bl_description = "Run the atlas bake preparation step for multiple selected objects. / 選択した複数オブジェクト向けにアトラスベイク準備を実行します。"
    bl_options = {'UNDO'}

    atlas_uv_name: bpy.props.StringProperty(name="Atlas UV Name", default="SUV_Atlas")
    image_mode: bpy.props.EnumProperty(
        name="Image Mode",
        items=[('SINGLE_IMAGE', "Single Image", ""), ('UDIM_TILED', "UDIM Tiled", "")],
        default='SINGLE_IMAGE'
    )
    resolution: bpy.props.IntProperty(name="Resolution", default=2048, min=128)

    bake_basecolor: bpy.props.BoolProperty(name="BaseColor", default=True)
    bake_normal: bpy.props.BoolProperty(name="Normal", default=False)
    bake_roughness: bpy.props.BoolProperty(name="Roughness", default=False)
    bake_metallic: bpy.props.BoolProperty(name="Metallic", default=False)
    bake_ao: bpy.props.BoolProperty(name="AO", default=False)
    bake_emission: bpy.props.BoolProperty(name="Emission", default=False)

    @classmethod
    def poll(cls, context):
        return bool(_selected_mesh_objects(context))

    def execute(self, context):

        objs = _suv_preflight_mesh_objects(context, self, source='Atlas Bake (Multi)', require_named_uv=self.atlas_uv_name)
        if not objs:
            return {'CANCELLED'}
        _suv_log_event(context, 'INFO', 'Atlas Bake (Multi)', 'Starting atlas bake', {'objects': _suv_brief_object_names(objs), 'atlas_uv': self.atlas_uv_name, 'image_mode': self.image_mode, 'resolution': self.resolution})
        with _PreserveContextState(context, restore_mode=True, restore_render_engine=True):
            if not _suv_ensure_object_mode(context, objs[0]):
                _suv_log_event(context, 'WARN', 'Atlas Bake (Multi)', 'Could not switch the active mesh into Object mode', {'objects': _suv_brief_object_names(objs)})

            for obj in objs:
                _set_active_uv(obj, self.atlas_uv_name)
            temp_mats = _suv_ensure_temp_bake_materials(objs)
            if temp_mats:
                self.report({'INFO'}, tr(context, 'msg.preflight_temp_materials', objs=_suv_brief_object_names(temp_mats)))
                _suv_log_event(context, 'INFO', 'Atlas Bake (Multi)', 'Temporary bake materials created', {'objects': _suv_brief_object_names(temp_mats)})

            scene = context.scene
            try:
                if scene.render.engine != 'CYCLES':
                    scene.render.engine = 'CYCLES'
            except Exception:
                self.report({'WARNING'}, tr(context, "msg.atlas_need_cycles"))
                return {'CANCELLED'}

            tiles = _collect_udim_tiles(objs, self.atlas_uv_name) if self.image_mode == 'UDIM_TILED' else {(0, 0)}

            passes = []
            if self.bake_basecolor: passes.append(("BaseColor", "DIFFUSE", True))
            if self.bake_normal: passes.append(("Normal", "NORMAL", False))
            if self.bake_roughness: passes.append(("Roughness", "ROUGHNESS", False))
            if self.bake_metallic: passes.append(("Metallic", "METALLIC", False))
            if self.bake_ao: passes.append(("AO", "AO", False))
            if self.bake_emission: passes.append(("Emission", "EMIT", True))
            if not passes:
                self.report({'WARNING'}, tr(context, "msg.op_failed", e="No passes enabled"))
                return {'CANCELLED'}

            images_by_pass = {}
            for key, _btype, _srgb in passes:
                alpha = key in ("BaseColor", "Emission")
                images_by_pass[key] = _create_image_for_pass(f"SUV_Atlas_{key}", self.resolution, self.resolution, alpha, self.image_mode, tiles)

            mats = _material_slots_unique(objs)
            nodes_by_mat = _build_bake_nodes(mats, images_by_pass)

            baked_objects = set()
            skipped = []
            try:
                for key, bake_type, _srgb in passes:
                    _set_active_bake_node(nodes_by_mat, key)
                    first = True
                    for obj in objs:
                        if not _suv_select_only(context, obj):
                            skipped.append(f"{obj.name}: selection failed")
                            continue
                        ok_mode, mode_err = _suv_safe_mode_set(context, obj, 'OBJECT', source='Atlas bake preflight')
                        if not ok_mode:
                            skipped.append(f"{obj.name}: {mode_err or 'object mode switch failed'}")
                            continue

                        try:
                            scene.render.bake.use_clear = bool(first)
                        except Exception:
                            pass

                        if bake_type == 'DIFFUSE':
                            try:
                                scene.render.bake.use_pass_direct = False
                                scene.render.bake.use_pass_indirect = False
                                scene.render.bake.use_pass_color = True
                            except Exception:
                                pass

                        ok, err = _try_bake(bake_type)
                        if not ok:
                            skipped.append(f"{obj.name} / {key}: {err}")
                            self.report({'WARNING'}, tr(context, "msg.warn_pass_skip", p=key, e=err))
                            _suv_log_event(context, 'WARN', 'Atlas Bake (Multi)', 'Bake pass skipped for one object', {'object': obj.name, 'pass': key, 'error': err})
                            continue
                        baked_objects.add(obj.name)
                        first = False

                context.scene["SUV_ATLAS_IMAGES"] = json.dumps({k: v.name for k, v in images_by_pass.items()})
                _suv_log_event(context, 'INFO', 'Atlas Bake (Multi)', 'Bake completed', {'passes': len(passes), 'tiles': len(tiles), 'image_mode': self.image_mode, 'baked_objects': len(baked_objects), 'skipped': len(skipped)})
                if skipped:
                    _suv_log_event(context, 'WARN', 'Atlas Bake (Multi)', 'Some atlas bake steps were skipped', {'details': '; '.join(skipped[:24])})
                if not baked_objects:
                    self.report({'WARNING'}, tr(context, "msg.op_failed", e="Bake failed on all selected objects"))
                    return {'CANCELLED'}
                self.report({'INFO'}, tr(context, "msg.atlas_bake_done"))
                return {'FINISHED'}
            except Exception as e:
                _suv_log_exception(context, 'Atlas Bake (Multi)', e, {'image_mode': self.image_mode, 'atlas_uv': self.atlas_uv_name})
                self.report({'WARNING'}, tr(context, "msg.op_failed", e=str(e)))
                return {'CANCELLED'}
            finally:
                _remove_bake_nodes(mats)

class SUV_OT_atlas_build_mat_apply_multi(bpy.types.Operator):
    bl_idname = "uv.suv_atlas_build_mat_apply_multi"
    bl_label = 'Build Material & Apply (Multi)'
    bl_description = "Create and apply atlas materials for the current multi-object atlas workflow. / 現在の複数オブジェクト向けアトラス作業に必要な材質を作成して適用します。"
    bl_options = {'UNDO'}

    atlas_uv_name: bpy.props.StringProperty(name="Atlas UV Name", default="SUV_Atlas")
    material_name: bpy.props.StringProperty(name="Material Name", default="SUV_Atlas_MAT")
    use_ao_multiply: bpy.props.BoolProperty(name="AO Multiply BaseColor", default=True)

    @classmethod
    def poll(cls, context):
        return bool(_selected_mesh_objects(context))

    def execute(self, context):

        objs = _suv_preflight_mesh_objects(context, self, source='Atlas Material Apply (Multi)')
        if not objs:
            return {'CANCELLED'}

        with _PreserveContextState(context, restore_mode=True, restore_render_engine=False):
            try:
                try:
                    cache = json.loads(context.scene.get("SUV_ATLAS_IMAGES", "") or "{}")
                except Exception:
                    cache = {}
                images_by_pass = {}
                for k, name in cache.items():
                    img = bpy.data.images.get(name)
                    if img:
                        images_by_pass[k] = img
                if not images_by_pass:
                    fallback_name = _suv_pick_image_name("SUV_Atlas_BaseColor")
                    images_by_pass["BaseColor"] = bpy.data.images.new(fallback_name, width=2048, height=2048, alpha=True)

                material_name = str(self.material_name).strip() or 'SUV_Atlas_MAT'
                old = bpy.data.materials.get(material_name)
                if old is not None and getattr(old, 'users', 0) > 0:
                    material_name = _suv_pick_material_name(material_name)
                    _suv_log_event(context, 'WARN', 'Atlas Material Apply (Multi)', 'Requested material name already in use, creating a unique material instead', {'requested': self.material_name, 'created': material_name})
                elif old is not None:
                    try:
                        bpy.data.materials.remove(old)
                    except Exception:
                        material_name = _suv_pick_material_name(material_name)

                mat = _build_material_with_images_shared(self.atlas_uv_name, images_by_pass, material_name, self.use_ao_multiply)

                applied = []
                skipped = []
                for obj in objs:
                    try:
                        if obj.material_slots:
                            for i in range(len(obj.material_slots)):
                                obj.material_slots[i].material = mat
                        else:
                            obj.data.materials.append(mat)
                        applied.append(obj.name)
                    except Exception as e:
                        skipped.append(f"{obj.name}: {e}")
                if skipped:
                    _suv_log_event(context, 'WARN', 'Atlas Material Apply (Multi)', 'Material application skipped on some objects', {'details': '; '.join(skipped[:24])})
                if not applied:
                    self.report({'WARNING'}, tr(context, "msg.op_failed", e="Could not apply atlas material to any selected object"))
                    return {'CANCELLED'}

                _suv_log_event(context, 'INFO', 'Atlas Material Apply (Multi)', 'Atlas material built and applied', {'objects': len(applied), 'material': material_name, 'atlas_uv': self.atlas_uv_name})
                self.report({'INFO'}, tr(context, "msg.atlas_mat_done"))
                return {'FINISHED'}
            except Exception as e:
                _suv_log_exception(context, 'Atlas Material Apply (Multi)', e, {'material': self.material_name, 'atlas_uv': self.atlas_uv_name})
                self.report({'WARNING'}, tr(context, "msg.op_failed", e=str(e)))
                return {'CANCELLED'}

class SUV_OT_atlas_run_all_multi(bpy.types.Operator):
    bl_idname = "uv.suv_atlas_run_all_multi"
    bl_label = 'Run All (Multi)'
    bl_description = "Run the suite's multi-object atlas workflow from layout preparation through final setup. / レイアウト準備から最終設定まで、複数オブジェクト向けアトラス工程をまとめて実行します。"
    bl_options = {'UNDO'}

    atlas_uv_name: bpy.props.StringProperty(name="Atlas UV Name", default="SUV_Atlas")

    @classmethod
    def poll(cls, context):
        return bool(_selected_mesh_objects(context))

    def execute(self, context):
        objs = _suv_preflight_mesh_objects(context, self, source='Atlas Run All (Multi)', require_uv=True, require_active_uv=True)
        if not objs:
            return {'CANCELLED'}
        report = _suv_batch_begin(context, 'Atlas Run All (Multi)', details={
            'objects': _suv_brief_object_names(objs),
            'atlas_uv': self.atlas_uv_name,
        })
        ok_build, _ = _suv_batch_step(
            context,
            report,
            'Build UV',
            lambda: bpy.ops.uv.suv_atlas_build_uv_multi('EXEC_DEFAULT', atlas_uv_name=self.atlas_uv_name),
            fatal=True,
            details={'atlas_uv': self.atlas_uv_name},
        )
        if ok_build and not _suv_batch_should_stop(context, report):
            _suv_batch_step(
                context,
                report,
                'Bake',
                lambda: bpy.ops.uv.suv_atlas_bake_multi('EXEC_DEFAULT', atlas_uv_name=self.atlas_uv_name),
                fatal=False,
                details={'atlas_uv': self.atlas_uv_name},
            )
            if not _suv_batch_should_stop(context, report):
                _suv_batch_step(
                    context,
                    report,
                    'Build Material & Apply',
                    lambda: bpy.ops.uv.suv_atlas_build_mat_apply_multi('EXEC_DEFAULT', atlas_uv_name=self.atlas_uv_name),
                    fatal=False,
                    details={'atlas_uv': self.atlas_uv_name},
                )
            else:
                _suv_batch_note(context, report, 'WARN', 'Batch Policy', 'Skipped material apply because batch policy requested an early stop', {'policy': _suv_batch_error_policy(context)})
        else:
            _suv_batch_note(context, report, 'ERROR', 'Run All', 'Skipped remaining atlas steps because Build UV did not complete', {'atlas_uv': self.atlas_uv_name})
        return _suv_batch_finish(context, report, operator=self)

class SUV_OT_auto_uv_profile(bpy.types.Operator):
    bl_idname = "uv.suv_auto_uv_profile"
    bl_label = 'Auto UV Profile'
    bl_description = "Run a merged one-click UV workflow profile that combines the strongest overlapping features into compact presets. / 重複する機能群を統合した1クリックUVワークフロープリセットを実行します。"
    bl_options = {'UNDO'}

    profile: bpy.props.EnumProperty(
        name="Profile",
        items=[
            ('ORGANIC', "Organic", "Balanced unwrap for characters and soft organic forms / キャラクターや有機形状向け"),
            ('HARDSURFACE', "Hard Surface", "Sharper seams, smart projection and rectified layout / ハードサーフェス向け"),
            ('LIGHTMAP', "Lightmap", "Overlap-free layout tuned for bake/lightmap preparation / ライトマップ・ベイク向け"),
            ('SCAN', "Scan / Noisy Mesh", "Heavier seam generation and robust cleanup for difficult meshes / スキャン・ノイジー形状向け"),
            ('UDIM', "UDIM", "Pack and distribute grouped content across tiles / グループをUDIMタイルへ整理"),
            ('TRIM', "Trim Strip", "Rectify and line islands up for trimsheet style work / トリムシート向け"),
            ('BLENDER_NATIVE', "Core Standard", "standard ABF/min-stretch/live-style unwrap bridge / 標準UV処理系の ABF・Min Stretch・Live系を意識した互換"),
            ('RIZOM_HARD', "Reference Layout Hard", "Hard-surface unwrap + rectify + pack workflow inspired by dedicated external unwrap tools / 外部専用展開ツール系の硬質向け手順"),
            ('HEADUS_RELAX', "Smart UV展開参照 Relax", "Peel plus stronger relax cleanup for dense shell refinement / Peel と強めリラックス中心の調整向け"),
            ('SMART_STANDARD_GAME', "Smart Standard Game", "One-click game/lightmap friendly unwrap and validation / ゲーム・ライトマップ向けのワンクリック展開"),
            ('MAYA_CUTSEW', "Smart UV標準DCC Cut+Sew", "Cut-sew oriented unwrap flow with seam-first cleanup / Cut/Sew 系のシーム主導ワークフロー"),
            ('MAX_PEEL_RELAX', "DCC Reference Peel", "Peel plus relax oriented workflow inspired by Unwrap UVW Peel / Unwrap UVW Peel 系の Peel+Relax ワークフロー"),
            ('MODO_PEEL', "Smart UVピール", "Peeler-style unwrap, orient and compact pack bridge / Smart UVピール 系の展開・向き補正・高密度パック"),
            ('LIGHTWAVE_HEAL', "LightWave Heal", "Heal-UV oriented cleanup, orient and pack workflow / Heal UV 系の補正・整列・パック"),
            ('COAT3D_GU', "3DCoat GU", "3DCoat GU/ABF-style organic unwrap and cleanup bridge / 3DCoat の GU/ABF 系を意識した有機展開"),
            ('ZBRUSH_MASTER', "ZBrush UV Master", "One-click organic unwrap and cleanup bridge inspired by UV Master / UV Master 系のワンクリック有機展開"),
            ('SUBSTANCE_AUTO', "Smart UVテクスチャ参照 Auto UV", "Texture-set friendly auto unwrap and bake-safe validation bridge / テクスチャセット向け自動展開＋ベイク安全監査"),
            ('UNREAL_LIGHTMAP', "Game Engine Lightmap", "Game Engine-style lightmap generation and overlap audit bridge / Game Engine 系ライトマップ生成＋重なり監査"),
            ('UNITY_PROBUILDER', "Game Engine ProBuilder", "ProBuilder-style smart project and fit workflow / ProBuilder 系スマート投影＋範囲フィット"),
            ('MARMOSET_BAKE', "Bake Reference Bake Prep", "Bake-prep bridge for toolbag-style pack, margins and QA / Toolbag系のベイク前パック・余白・QA"),
            ('UVPACKMASTER_DENSE', "Smart UV高密度パック Dense", "Dense packing-oriented workflow with similarity-aware packing and texel parity / 類似判定を使った高密度パック重視ワークフロー"),
            ('ZEN_UV_TRIM', "Smart UVレイアウト参照 Trim", "Trim-strip oriented workflow with quad flow, orientation cleanup and reuse-friendly stacking / Quad Flow と向き整理を含むトリム再利用向け"),
            ('SMART_TEXTURE_BRIDGE', "Smart UV Suite reference Bridge", "Texel-density, checker, rectify and audit oriented workflow inspired by Smart UV Suite reference / Texel Density・チェッカー・整形・監査重視の Smart UV Suite reference 系"),
            ('SMART_EDIT_EDIT', "Smart UV Suite編集支援 Edit", "Editing-focused unwrap, orient, fit and inspection workflow inspired by Smart UV Suite編集支援 style daily editing / 日常編集向けの Smart UV Suite編集支援 系ワークフロー"),
            ('HOUDINI_LABS', "DCC Reference Labs UV", "Auto-seam plus minimize-stretch and UDIM-friendly audit workflow inspired by DCC Reference Labs Auto UV / DCC Reference Labs Auto UV 系"),
            ('DCC_REFERENCE_MOF', "DCC Reference Ministry of Flat", "Automatic best-fit projection and cleanup workflow inspired by DCC Reference / Ministry of Flat 系"),
            ('SMART_SURFACE_SURFACE', "Smart UV Suite Surface", "Surface-lock, world-scale and copy-preserving UV workflow inspired by Smart UV Suite / Smart UV Suite の Texture Lock・World Scale・Copy/Preserve 系を統合した手順"),
            ('SMART_PRECISION_PRECISION', "Smart UV Precision", "Precision snap, stitch, quadrify and grid cleanup inspired by Smart UV Precision / Smart UV Precision の Quick Snap・Stitch・Quadrify 系を統合した手順"),
            ('UVFACTORY_PROCEDURAL', "Smart UV手続き補助 Procedural", "Stable projection and procedural live-UV workflow inspired by Smart UV手続き補助 / Smart UV手続き補助 の Stable Projection・手続き型ライブUVを意識した手順"),
            ('HAIR_CARD_LAYOUT', "Hair Card Layout", "Hair-card strip, hotspot and bake-prep layout inspired by Hair Tool / Hair Tool のヘアカードUV・配置・ベイク前整理を意識した手順"),
            ('BONUS_TOOLS_AUTO', "Smart UV自動補助", "Utility-driven auto unwrap route inspired by Smart UV自動補助 / Smart UV自動補助 の Auto Unwrap 系を意識した手順"),
            ('DCC_LAYOUT_REFERENCE_MAYA_BRIDGE', "Smart UV高度連携", "Bridge-style unwrap, rectify and UDIM-friendly pack flow inspired by Smart UV高度連携 / Smart UV高度連携 の往復展開と UDIM 整理を意識した手順"),
            ('RS_UV_KIT', "RS UV Kit", "UDIM pack, grid arrange and UV check flow inspired by RS UV Kit / RS UV Kit の UDIM パック・Grid Arrange・UV Checks を意識した手順"),
            ('SMART_EDIT_REFERENCE', "Malcolm341 Workflow Hub", "Gridify, planar projection and UDIM packing flow inspired by Malcolm341's UV workflow_hub / Malcolm341 系の Gridify・平面投影・UDIM パックを意識した手順"),
            ('MAX_UVTOOLS', "Max UV Tools", "Tile arrange, UDIM shift and alignment flow inspired by UV Tools by NiK / UV Tools by NiK の Arrange in Tile・UDIM Shift・整列を意識した手順"),
        ],
        default='ORGANIC'
    )
    apply_density: bpy.props.BoolProperty(name="Apply Density", default=True)
    target_density: bpy.props.FloatProperty(name="Target Density", default=1024.0, min=1.0)
    texture_size: bpy.props.IntProperty(name="Texture Size", default=2048, min=128)
    margin_px: bpy.props.IntProperty(name="Margin", default=8, min=0, max=512)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}

        ws = _suv_ws(context)
        if ws:
            self.texture_size = int(getattr(ws, 'canvas_size', self.texture_size) or self.texture_size)
            self.target_density = float(getattr(ws, 'workflow_density', self.target_density) or self.target_density)

        def _call(op, **kwargs):
            try:
                result = op('EXEC_DEFAULT', **kwargs)
                return not _suv_result_has(result, 'CANCELLED')
            except Exception:
                return False

        def _density():
            if not self.apply_density:
                return True
            return _call(
                bpy.ops.uv.suv_texel_set,
                target_density=self.target_density,
                texture_size=self.texture_size,
                scope='SELECTED'
            )

        ok = True
        if self.profile == 'ORGANIC':
            ok &= _call(bpy.ops.uv.suv_auto_seam_advanced, mode='ANGLE', angle_threshold=math.radians(55.0), scope='ALL')
            ok &= _call(bpy.ops.uv.suv_native_projection, mode='UNWRAP_ABF', relax_after=True, pack_after=True, apply_density=False, island_margin=0.01)
            ok &= _density()
        elif self.profile == 'HARDSURFACE':
            ok &= _call(bpy.ops.uv.suv_auto_seam_advanced, mode='ALL', angle_threshold=math.radians(60.0), scope='ALL')
            ok &= _call(bpy.ops.uv.suv_native_projection, mode='SMART_PROJECT', relax_after=False, pack_after=False, apply_density=False, angle_limit=math.radians(66.0), island_margin=0.015)
            ok &= _call(bpy.ops.uv.suv_hs_rectify_fit, scope='SELECTED', padding_px=self.margin_px, texture_size=self.texture_size, keep_tile=True)
            ok &= _call(bpy.ops.uv.suv_pack_pro, engine='DETERMINISTIC', scope='SELECTED', udim_mode='SINGLE', margin_px=self.margin_px, texture_size=self.texture_size, group_mode='NONE')
            ok &= _density()
        elif self.profile == 'LIGHTMAP':
            ok &= _call(bpy.ops.uv.suv_native_projection, mode='LIGHTMAP', relax_after=False, pack_after=True, apply_density=False)
            ok &= _call(bpy.ops.uv.suv_inspector_scan, scope='ALL', check_out_of_tile=True, check_overlap=True, precise_overlap=True, check_stretch=False)
        elif self.profile == 'SCAN':
            ok &= _call(bpy.ops.uv.suv_auto_seam_advanced, mode='ALL', angle_threshold=math.radians(48.0), clear_existing=False, scope='ALL')
            ok &= _call(bpy.ops.uv.suv_native_projection, mode='MIN_STRETCH', relax_after=False, pack_after=False, apply_density=False)
            ok &= _call(bpy.ops.uv.suv_pack_pro, engine='DETERMINISTIC', scope='SELECTED', udim_mode='AUTO_TILES', margin_px=self.margin_px, texture_size=self.texture_size, group_mode='SIMILAR')
            ok &= _call(bpy.ops.uv.suv_inspector_scan, scope='ALL', check_out_of_tile=True, check_overlap=True, precise_overlap=True, check_stretch=True, stretch_threshold=max(1.2, getattr(ws, 'stretch_threshold', 1.8) if ws else 1.8))
        elif self.profile == 'UDIM':
            ok &= _call(bpy.ops.uv.suv_native_projection, mode='SMART_PROJECT', relax_after=False, pack_after=False, apply_density=False, angle_limit=math.radians(60.0), island_margin=0.01)
            ok &= _density()
            ok &= _call(bpy.ops.uv.suv_groups_to_tiles, mode=getattr(ws, 'pack_group_mode', 'SIMILAR') if ws else 'SIMILAR', start_u=0, start_v=0)
            ok &= _call(bpy.ops.uv.suv_pack_pro, engine='DETERMINISTIC', scope='SELECTED', udim_mode='KEEP_TILES', margin_px=self.margin_px, texture_size=self.texture_size, group_mode='SIMILAR')
        elif self.profile == 'TRIM':
            ok &= _call(bpy.ops.uv.suv_hs_quad_flow, fit_after=False)
            ok &= _call(bpy.ops.uv.suv_trim_strip_layout, axis='H', padding_px=self.margin_px, texture_size=self.texture_size, keep_tile=True, scope='SELECTED')
            ok &= _density()
        elif self.profile == 'BLENDER_NATIVE':
            ok &= _call(bpy.ops.uv.suv_auto_seam_advanced, mode='ANGLE', angle_threshold=math.radians(55.0), scope='ALL')
            ok &= _call(bpy.ops.uv.suv_native_projection, mode='UNWRAP_ABF', relax_after=True, pack_after=False, apply_density=False, island_margin=0.01)
            ok &= _call(bpy.ops.uv.suv_cleanup_bridge, mode='RELAX_KNEAD', iterations=32)
            # Establish relative texel density before the final single-tile
            # layout. Scaling islands afterwards invalidates its bounds and gaps.
            ok &= _density()
            ok &= _call(bpy.ops.uv.suv_pack_pro, engine='DETERMINISTIC', scope='SELECTED', udim_mode='SINGLE', margin_px=self.margin_px, texture_size=self.texture_size, group_mode='NONE')
        elif self.profile == 'RIZOM_HARD':
            ok &= _call(bpy.ops.uv.suv_auto_seam_advanced, mode='ALL', angle_threshold=math.radians(52.0), scope='ALL')
            ok &= _call(bpy.ops.uv.suv_native_projection, mode='UNWRAP_ABF', relax_after=False, pack_after=False, apply_density=False, island_margin=0.008)
            ok &= _call(bpy.ops.uv.suv_hs_rectify_fit, scope='SELECTED', padding_px=self.margin_px, texture_size=self.texture_size, keep_tile=True)
            ok &= _call(bpy.ops.uv.suv_cleanup_bridge, mode='OPTIMIZE_REALTIME', iterations=48)
            ok &= _call(bpy.ops.uv.suv_pack_pro, engine='DETERMINISTIC', scope='SELECTED', udim_mode='SINGLE', margin_px=self.margin_px, texture_size=self.texture_size, group_mode='NONE')
            ok &= _density()
        elif self.profile == 'HEADUS_RELAX':
            ok &= _call(bpy.ops.uv.suv_projection_bridge, mode='PEEL', island_margin=0.01, pack_after=False)
            ok &= _call(bpy.ops.uv.suv_constraint_relax_preserve, mode='RELAX_KNEAD', scope='SELECTED', anchor_mode='EXISTING_PLUS_BORDER_CORNERS', preserve_position=False, preserve_area=True, preserve_rotation=False, keep_tile=True, temporary_anchors=True, average_scale_each_pass=True, passes=2, iterations=96, pack_after=False)
            ok &= _call(bpy.ops.uv.suv_cleanup_bridge, mode='HEAL_UV', iterations=48)
            ok &= _call(bpy.ops.uv.suv_pack_pro, engine='DETERMINISTIC', scope='SELECTED', udim_mode='SINGLE', margin_px=self.margin_px, texture_size=self.texture_size, group_mode='NONE')
            ok &= _density()
        elif self.profile == 'SMART_STANDARD_GAME':
            ok &= _call(bpy.ops.uv.suv_native_projection, mode='LIGHTMAP', relax_after=False, pack_after=True, apply_density=False)
            ok &= _call(bpy.ops.uv.suv_cleanup_bridge, mode='REMOVE_OVERLAP', iterations=32, margin=max(0.001, float(self.margin_px) / float(max(1, self.texture_size))))
            ok &= _call(bpy.ops.uv.suv_inspector_scan, scope='ALL', check_out_of_tile=True, check_overlap=True, precise_overlap=True, check_stretch=False)
        elif self.profile == 'MAYA_CUTSEW':
            ok &= _call(bpy.ops.uv.suv_auto_seam_advanced, mode='MATERIAL', angle_threshold=math.radians(60.0), scope='ALL')
            ok &= _call(bpy.ops.uv.suv_native_projection, mode='UNWRAP_ABF', relax_after=True, pack_after=False, apply_density=False, island_margin=0.01)
            ok &= _call(bpy.ops.uv.suv_cleanup_bridge, mode='HEAL_UV', iterations=48)
            ok &= _call(bpy.ops.uv.suv_native_uv_action, mode='SEAMS_FROM_ISLANDS')
            ok &= _call(bpy.ops.uv.suv_pack_pro, engine='DETERMINISTIC', scope='SELECTED', udim_mode='SINGLE', margin_px=self.margin_px, texture_size=self.texture_size, group_mode='NONE')
            ok &= _density()
        elif self.profile == 'MAX_PEEL_RELAX':
            ok &= _call(bpy.ops.uv.suv_projection_bridge, mode='PEEL', island_margin=0.01, pack_after=False)
            ok &= _call(bpy.ops.uv.suv_constraint_relax_preserve, mode='RELAX_KNEAD', scope='SELECTED', anchor_mode='EXISTING_PLUS_BORDER_CORNERS', preserve_position=False, preserve_area=True, preserve_rotation=False, keep_tile=True, temporary_anchors=True, average_scale_each_pass=True, passes=2, iterations=80, pack_after=False)
            ok &= _call(bpy.ops.uv.suv_orient_islands, mode='MIN_BBOX', step_deg=15, scope='SELECTED')
            ok &= _call(bpy.ops.uv.suv_pack_pro, engine='DETERMINISTIC', scope='SELECTED', udim_mode='SINGLE', margin_px=self.margin_px, texture_size=self.texture_size, group_mode='NONE', rotation_step='15')
            ok &= _density()
        elif self.profile == 'MODO_PEEL':
            ok &= _call(bpy.ops.uv.suv_projection_bridge, mode='PEEL', island_margin=0.01, pack_after=False)
            ok &= _call(bpy.ops.uv.suv_cleanup_bridge, mode='RELAX_KNEAD', iterations=48)
            ok &= _call(bpy.ops.uv.suv_orient_islands, mode='MIN_BBOX', step_deg=15, scope='SELECTED')
            ok &= _call(bpy.ops.uv.suv_pack_pro, engine='DETERMINISTIC', scope='SELECTED', udim_mode='SINGLE', margin_px=self.margin_px, texture_size=self.texture_size, group_mode='NONE', rotation_step='15')
            ok &= _density()
        elif self.profile == 'LIGHTWAVE_HEAL':
            ok &= _call(bpy.ops.uv.suv_native_projection, mode='UNWRAP_ABF', relax_after=True, pack_after=False, apply_density=False, island_margin=0.01)
            ok &= _call(bpy.ops.uv.suv_cleanup_bridge, mode='HEAL_UV', iterations=64)
            ok &= _call(bpy.ops.uv.suv_orient_islands, mode='MIN_BBOX', step_deg=15, scope='SELECTED')
            ok &= _call(bpy.ops.uv.suv_pack_pro, engine='DETERMINISTIC', scope='SELECTED', udim_mode='SINGLE', margin_px=self.margin_px, texture_size=self.texture_size, group_mode='NONE')
            ok &= _density()
        elif self.profile == 'COAT3D_GU':
            ok &= _call(bpy.ops.uv.suv_auto_seam_advanced, mode='ANGLE', angle_threshold=math.radians(50.0), scope='ALL')
            ok &= _call(bpy.ops.uv.suv_native_projection, mode='MIN_STRETCH', relax_after=False, pack_after=False, apply_density=False, island_margin=0.01)
            ok &= _call(bpy.ops.uv.suv_constraint_relax_preserve, mode='RELAX_KNEAD', scope='SELECTED', anchor_mode='EXISTING_PLUS_BORDER_CORNERS', preserve_position=False, preserve_area=True, preserve_rotation=False, keep_tile=True, temporary_anchors=True, average_scale_each_pass=True, passes=1, iterations=64, pack_after=False)
            ok &= _call(bpy.ops.uv.suv_pack_pro, engine='DETERMINISTIC', scope='SELECTED', udim_mode='SINGLE', margin_px=self.margin_px, texture_size=self.texture_size, group_mode='NONE')
            ok &= _density()
        elif self.profile == 'ZBRUSH_MASTER':
            ok &= _call(bpy.ops.uv.suv_auto_seam_advanced, mode='ANGLE', angle_threshold=math.radians(58.0), scope='ALL')
            ok &= _call(bpy.ops.uv.suv_native_projection, mode='UNWRAP_ABF', relax_after=True, pack_after=False, apply_density=False, island_margin=0.01)
            ok &= _call(bpy.ops.uv.suv_cleanup_bridge, mode='OPTIMIZE_REALTIME', iterations=32)
            ok &= _call(bpy.ops.uv.suv_fit_to_bounds, padding_px=self.margin_px, texture_size=self.texture_size, keep_tile=True, scope='SELECTED')
            ok &= _density()
        elif self.profile == 'SUBSTANCE_AUTO':
            ok &= _call(bpy.ops.uv.suv_native_projection, mode='SMART_PROJECT', relax_after=False, pack_after=False, apply_density=False, angle_limit=math.radians(60.0), island_margin=0.01)
            ok &= _call(bpy.ops.uv.suv_cleanup_bridge, mode='REMOVE_OVERLAP', iterations=32, margin=max(0.001, float(self.margin_px) / float(max(1, self.texture_size))))
            ok &= _call(bpy.ops.uv.suv_pack_pro, engine='DETERMINISTIC', scope='SELECTED', udim_mode='SINGLE', margin_px=max(4, int(self.margin_px)), texture_size=self.texture_size, group_mode='MATERIAL')
            ok &= _call(bpy.ops.uv.suv_inspector_scan, scope='ALL', check_out_of_tile=True, check_overlap=True, precise_overlap=True, check_stretch=False)
            ok &= _density()
        elif self.profile == 'UNREAL_LIGHTMAP':
            ok &= _call(bpy.ops.uv.suv_native_projection, mode='LIGHTMAP', relax_after=False, pack_after=True, apply_density=False)
            ok &= _call(bpy.ops.uv.suv_cleanup_bridge, mode='REMOVE_OVERLAP', iterations=24, margin=max(0.001, float(self.margin_px) / float(max(1, self.texture_size))))
            ok &= _call(bpy.ops.uv.suv_inspector_scan, scope='ALL', check_out_of_tile=True, check_overlap=True, precise_overlap=True, check_stretch=False)
        elif self.profile == 'UNITY_PROBUILDER':
            ok &= _call(bpy.ops.uv.suv_native_projection, mode='SMART_PROJECT', relax_after=False, pack_after=False, apply_density=False, angle_limit=math.radians(66.0), island_margin=0.012)
            ok &= _call(bpy.ops.uv.suv_orient_islands, mode='MIN_BBOX', step_deg=15, scope='SELECTED')
            ok &= _call(bpy.ops.uv.suv_fit_to_bounds, padding_px=self.margin_px, texture_size=self.texture_size, keep_tile=True, scope='SELECTED')
            ok &= _call(bpy.ops.uv.suv_pack_pro, engine='DETERMINISTIC', scope='SELECTED', udim_mode='SINGLE', margin_px=self.margin_px, texture_size=self.texture_size, group_mode='NONE')
            ok &= _density()
        elif self.profile == 'MARMOSET_BAKE':
            ok &= _call(bpy.ops.uv.suv_auto_seam_advanced, mode='ALL', angle_threshold=math.radians(56.0), scope='ALL')
            ok &= _call(bpy.ops.uv.suv_native_projection, mode='UNWRAP_ABF', relax_after=True, pack_after=False, apply_density=False, island_margin=0.01)
            ok &= _call(bpy.ops.uv.suv_pack_pro, engine='DETERMINISTIC', scope='SELECTED', udim_mode='SINGLE', margin_px=max(8, int(self.margin_px)), texture_size=self.texture_size, group_mode='NONE')
            ok &= _call(bpy.ops.uv.suv_inspector_scan, scope='ALL', check_out_of_tile=True, check_overlap=True, precise_overlap=True, check_stretch=False)
            ok &= _density()
        elif self.profile == 'UVPACKMASTER_DENSE':
            ok &= _call(bpy.ops.uv.suv_native_projection, mode='UNWRAP_ABF', relax_after=False, pack_after=False, apply_density=False, island_margin=0.008)
            ok &= _call(bpy.ops.uv.suv_orient_islands, mode='MIN_BBOX', step_deg=15, scope='SELECTED')
            ok &= _call(bpy.ops.uv.suv_pack_pro, engine='DETERMINISTIC', scope='SELECTED', udim_mode='SINGLE', margin_px=max(4, int(self.margin_px)), texture_size=self.texture_size, group_mode='SIMILAR', group_layout='SINGLE_TILE', rotation_step='15', group_sort='SIZE_DESC', stack_identical_groups=True)
            ok &= _density()
        elif self.profile == 'ZEN_UV_TRIM':
            ok &= _call(bpy.ops.uv.suv_hs_quad_flow, fit_after=False)
            ok &= _call(bpy.ops.uv.suv_orient_islands, mode='HORIZONTAL', step_deg=90, scope='SELECTED')
            ok &= _call(bpy.ops.uv.suv_trim_strip_layout, axis='H', padding_px=self.margin_px, texture_size=self.texture_size, keep_tile=True, scope='SELECTED')
            ok &= _call(bpy.ops.uv.suv_stack_grouped, mode='IDENTICAL', area_tol=0.03, aspect_tol=0.05, rotation_step='15', allow_mirror=True)
            ok &= _density()
        elif self.profile == 'SMART_TEXTURE_BRIDGE':
            ok &= _call(bpy.ops.object.suv_create_checker_material)
            ok &= _call(bpy.ops.uv.suv_auto_seam_advanced, mode='ALL', angle_threshold=math.radians(58.0), scope='ALL')
            ok &= _call(bpy.ops.uv.suv_native_projection, mode='UNWRAP_ABF', relax_after=True, pack_after=False, apply_density=False, island_margin=0.01)
            ok &= _call(bpy.ops.uv.suv_hs_rectify_fit, scope='SELECTED', padding_px=self.margin_px, texture_size=self.texture_size, keep_tile=True)
            ok &= _density()
            ok &= _call(bpy.ops.uv.suv_inspector_scan, scope='ALL', check_out_of_tile=True, check_overlap=True, precise_overlap=True, check_stretch=True, stretch_threshold=max(1.3, getattr(ws, 'stretch_threshold', 1.8) if ws else 1.8))
        elif self.profile == 'SMART_EDIT_EDIT':
            ok &= _call(bpy.ops.uv.suv_native_projection, mode='UNWRAP_ABF', relax_after=True, pack_after=False, apply_density=False, island_margin=0.01)
            ok &= _call(bpy.ops.uv.suv_orient_islands, mode='MIN_BBOX', step_deg=15, scope='SELECTED')
            ok &= _call(bpy.ops.uv.suv_fit_to_bounds, padding_px=self.margin_px, texture_size=self.texture_size, keep_tile=True, scope='SELECTED')
            ok &= _call(bpy.ops.uv.suv_inspector_scan, scope='SELECTED', check_out_of_tile=True, check_overlap=True, precise_overlap=True, check_stretch=True, stretch_threshold=max(1.35, getattr(ws, 'stretch_threshold', 1.8) if ws else 1.8))
            ok &= _density()
        elif self.profile == 'HOUDINI_LABS':
            ok &= _call(bpy.ops.uv.suv_auto_seam_advanced, mode='ALL', angle_threshold=math.radians(50.0), clear_existing=False, scope='ALL')
            ok &= _call(bpy.ops.uv.suv_native_projection, mode='MIN_STRETCH', relax_after=False, pack_after=False, apply_density=False)
            ok &= _call(bpy.ops.uv.suv_cleanup_bridge, mode='OPTIMIZE_REALTIME', iterations=48)
            ok &= _density()
            ok &= _call(bpy.ops.uv.suv_pack_pro, engine='DETERMINISTIC', scope='SELECTED', udim_mode='AUTO_TILES', margin_px=max(4, int(self.margin_px)), texture_size=self.texture_size, group_mode='SIMILAR', group_layout='TILES', rotation_step='15')
            ok &= _call(bpy.ops.uv.suv_inspector_scan, scope='ALL', check_out_of_tile=True, check_overlap=True, precise_overlap=True, check_stretch=True, stretch_threshold=max(1.25, getattr(ws, 'stretch_threshold', 1.8) if ws else 1.8))
        elif self.profile == 'DCC_REFERENCE_MOF':
            ok &= _call(bpy.ops.uv.suv_projection_bridge, mode='BEST_FIT', island_margin=0.01, pack_after=False)
            ok &= _call(bpy.ops.uv.suv_cleanup_bridge, mode='RELAX_KNEAD', iterations=64)
            ok &= _call(bpy.ops.uv.suv_orient_islands, mode='MIN_BBOX', step_deg=15, scope='SELECTED')
            ok &= _call(bpy.ops.uv.suv_pack_pro, engine='DETERMINISTIC', scope='SELECTED', udim_mode='SINGLE', margin_px=self.margin_px, texture_size=self.texture_size, group_mode='NONE')
            ok &= _density()
        elif self.profile == 'SMART_SURFACE_SURFACE':
            ok &= _call(bpy.ops.uv.suv_native_projection, mode='UNWRAP_ABF', relax_after=True, pack_after=False, apply_density=False, island_margin=0.01)
            ok &= _call(bpy.ops.uv.suv_match_active_preserve)
            ok &= _call(bpy.ops.uv.suv_constraint_relax_preserve, mode='RELAX_KNEAD', scope='SELECTED', anchor_mode='EXISTING_PLUS_BORDER_CORNERS', preserve_position=True, preserve_area=True, preserve_rotation=False, keep_tile=True, temporary_anchors=True, average_scale_each_pass=True, passes=1, iterations=48, pack_after=False)
            if self.apply_density:
                ok &= _call(bpy.ops.uv.suv_apply_density_profile, profile='GAME_BALANCED', run_batch=False, run_guard=True, scope='SELECTED')
            ok &= _call(bpy.ops.uv.suv_fit_to_bounds, padding_px=self.margin_px, texture_size=self.texture_size, keep_tile=True, scope='SELECTED')
        elif self.profile == 'SMART_PRECISION_PRECISION':
            ok &= _call(bpy.ops.uv.suv_hs_quad_flow, fit_after=False)
            ok &= _call(bpy.ops.uv.suv_match_stitch_active_preserve)
            ok &= _call(bpy.ops.uv.suv_hs_gridify)
            ok &= _call(bpy.ops.uv.suv_hs_rectify_fit, scope='SELECTED', padding_px=self.margin_px, texture_size=self.texture_size, keep_tile=True)
            ok &= _call(bpy.ops.uv.suv_orient_islands, mode='MIN_BBOX', step_deg=15, scope='SELECTED')
            ok &= _density()
        elif self.profile == 'UVFACTORY_PROCEDURAL':
            ok &= _call(bpy.ops.uv.suv_projection_bridge, mode='BEST_FIT', island_margin=0.01, pack_after=False)
            ok &= _call(bpy.ops.uv.suv_auto_seam_advanced, mode='ANGLE', angle_threshold=math.radians(50.0), clear_existing=False, scope='ALL')
            ok &= _call(bpy.ops.uv.suv_constraint_relax_preserve, mode='RELAX_KNEAD', scope='SELECTED', anchor_mode='EXISTING_PLUS_BORDER_CORNERS', preserve_position=True, preserve_area=True, preserve_rotation=False, keep_tile=True, temporary_anchors=True, average_scale_each_pass=True, passes=1, iterations=48, pack_after=False)
            ok &= _call(bpy.ops.uv.suv_pack_pro, engine='DETERMINISTIC', scope='SELECTED', udim_mode='SINGLE', margin_px=self.margin_px, texture_size=self.texture_size, group_mode='NONE')
            ok &= _density()
        elif self.profile == 'HAIR_CARD_LAYOUT':
            ok &= _call(bpy.ops.uv.suv_hs_quad_flow, fit_after=False)
            ok &= _call(bpy.ops.uv.suv_trim_strip_layout, axis='H', padding_px=max(2, int(self.margin_px)), texture_size=self.texture_size, keep_tile=True, scope='SELECTED')
            ok &= _call(bpy.ops.uv.suv_hotspot_grid_layout, cols=4, rows=1, texture_size=self.texture_size, padding_px=max(2, int(self.margin_px)), keep_aspect=True, sort_mode='WIDTH', fill_order='ROW')
            ok &= _call(bpy.ops.uv.suv_pack_pro, engine='DETERMINISTIC', scope='SELECTED', udim_mode='SINGLE', margin_px=max(2, int(self.margin_px)), texture_size=self.texture_size, group_mode='NONE', rotation_step='0')
            ok &= _call(bpy.ops.uv.suv_inspector_scan, scope='SELECTED', check_out_of_tile=True, check_overlap=True, precise_overlap=True, check_stretch=False)
            ok &= _density()
        elif self.profile == 'BONUS_TOOLS_AUTO':
            ok &= _call(bpy.ops.uv.suv_auto_seam_advanced, mode='ANGLE', angle_threshold=math.radians(58.0), scope='ALL')
            ok &= _call(bpy.ops.uv.suv_native_projection, mode='SMART_PROJECT', relax_after=False, pack_after=False, apply_density=False, angle_limit=math.radians(70.0), island_margin=0.015)
            ok &= _call(bpy.ops.uv.suv_cleanup_bridge, mode='OPTIMIZE_REALTIME', iterations=32)
            ok &= _call(bpy.ops.uv.suv_pack_pro, engine='DETERMINISTIC', scope='SELECTED', udim_mode='SINGLE', margin_px=self.margin_px, texture_size=self.texture_size, group_mode='NONE')
            ok &= _density()
        elif self.profile == 'DCC_LAYOUT_REFERENCE_MAYA_BRIDGE':
            ok &= _call(bpy.ops.uv.suv_auto_seam_advanced, mode='ALL', angle_threshold=math.radians(52.0), scope='ALL')
            ok &= _call(bpy.ops.uv.suv_native_projection, mode='UNWRAP_ABF', relax_after=False, pack_after=False, apply_density=False, island_margin=0.008)
            ok &= _call(bpy.ops.uv.suv_hs_rectify_fit, scope='SELECTED', padding_px=self.margin_px, texture_size=self.texture_size, keep_tile=True)
            ok &= _call(bpy.ops.uv.suv_pack_pro, engine='DETERMINISTIC', scope='SELECTED', udim_mode='AUTO_TILES', margin_px=max(4, int(self.margin_px)), texture_size=self.texture_size, group_mode='SIMILAR')
            ok &= _call(bpy.ops.uv.suv_inspector_scan, scope='ALL', check_out_of_tile=True, check_overlap=True, precise_overlap=True, check_stretch=False)
            ok &= _density()
        elif self.profile == 'RS_UV_KIT':
            ok &= _call(bpy.ops.uv.suv_native_projection, mode='UNWRAP_ABF', relax_after=True, pack_after=False, apply_density=False, island_margin=0.01)
            ok &= _call(bpy.ops.uv.suv_hs_gridify)
            ok &= _call(bpy.ops.uv.suv_pack_pro, engine='DETERMINISTIC', scope='SELECTED', udim_mode='AUTO_TILES', margin_px=max(4, int(self.margin_px)), texture_size=self.texture_size, group_mode='NONE')
            ok &= _call(bpy.ops.uv.suv_inspector_scan, scope='SELECTED', check_out_of_tile=True, check_overlap=True, precise_overlap=True, check_stretch=False)
            ok &= _density()
        elif self.profile == 'SMART_EDIT_REFERENCE':
            ok &= _call(bpy.ops.uv.suv_native_projection, mode='SMART_PROJECT', relax_after=False, pack_after=False, apply_density=False, angle_limit=math.radians(66.0), island_margin=0.012)
            ok &= _call(bpy.ops.uv.suv_hs_gridify)
            ok &= _call(bpy.ops.uv.suv_groups_to_tiles, mode='SIMILAR', start_u=0, start_v=0)
            ok &= _call(bpy.ops.uv.suv_pack_pro, engine='DETERMINISTIC', scope='SELECTED', udim_mode='KEEP_TILES', margin_px=max(4, int(self.margin_px)), texture_size=self.texture_size, group_mode='SIMILAR')
            ok &= _density()
        elif self.profile == 'MAX_UVTOOLS':
            ok &= _call(bpy.ops.uv.suv_orient_islands, mode='MIN_BBOX', step_deg=90, scope='SELECTED')
            ok &= _call(bpy.ops.uv.suv_groups_to_tiles, mode='SIMILAR', start_u=0, start_v=0)
            ok &= _call(bpy.ops.uv.suv_pack_pro, engine='DETERMINISTIC', scope='SELECTED', udim_mode='KEEP_TILES', margin_px=max(4, int(self.margin_px)), texture_size=self.texture_size, group_mode='SIMILAR')
            ok &= _call(bpy.ops.uv.suv_fit_to_bounds, padding_px=self.margin_px, texture_size=self.texture_size, keep_tile=True, scope='SELECTED')
            ok &= _density()

        if not ok:
            self.report({'WARNING'}, f"Profile finished with partial completion: {self.profile}")
            return {'CANCELLED'}
        self.report({'INFO'}, f"Auto UV profile finished: {self.profile}")
        return {'FINISHED'}


