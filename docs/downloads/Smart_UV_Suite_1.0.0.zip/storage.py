# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible storage helpers.

from __future__ import annotations

import json
import os
import shutil
from pathlib import Path
from typing import Any, Iterable

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None  # type: ignore

PACKAGE_ID = 'smart_uv_suite'
USER_DATA_DIRNAME = 'user_data'
USER_DEFAULT_REPO_NAME = 'user_default'
CONFIG_DIRNAME = 'Smart_UV_Suite'
LEGACY_PACKAGE_IDS = (
    PACKAGE_ID,
    'uv_suite',
    'smart_uv_suite_addon',
    'smart_uv_suite_jelararagi',
)


def _package_root() -> Path:
    return Path(__file__).resolve().parent


def _clean_part(value: object) -> str:
    text = str(value or '').replace('\\', '/').strip('/')
    pieces = [piece for piece in text.split('/') if piece and piece not in {'.', '..'}]
    return '/'.join(pieces)


def _clean_parts(parts: Iterable[object]) -> list[str]:
    result: list[str] = []
    for part in parts:
        cleaned = _clean_part(part)
        if cleaned:
            result.extend([piece for piece in cleaned.split('/') if piece])
    return result


def _blender_version() -> str:
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', None) if bpy is not None else None
        if version and len(version) >= 2:
            return f"{int(version[0])}.{int(version[1])}"
    except Exception:
        pass
    return '5.1'


def _installed_extension_root() -> Path | None:
    current = _package_root()
    try:
        if current.name == PACKAGE_ID and current.parent.name == USER_DEFAULT_REPO_NAME and current.parent.parent.name == 'extensions':
            return current
    except Exception:
        pass
    return None


def _is_user_default_package_path(path: Path, package_id: str) -> bool:
    try:
        resolved = path.resolve()
        parts = resolved.parts
        if resolved.name != package_id:
            return False
        for index, part in enumerate(parts[:-2]):
            if part == 'extensions' and parts[index + 1] == USER_DEFAULT_REPO_NAME and parts[index + 2] == package_id:
                return True
    except Exception:
        pass
    return False


def _accept_user_default_package_path(path: Path, package_id: str, create: bool) -> Path | None:
    try:
        candidate = Path(path).expanduser()
        if not _is_user_default_package_path(candidate, package_id):
            return None
        if create:
            candidate.mkdir(parents=True, exist_ok=True)
        return candidate
    except Exception:
        return None


def _extension_path_user_root(package_id: str, create: bool) -> Path | None:
    if bpy is None:
        return None
    fn = getattr(getattr(bpy, 'utils', None), 'extension_path_user', None)
    if not callable(fn):
        return None
    for args, kwargs in (
        ((package_id,), {'path': '', 'create': create}),
        ((package_id,), {'create': create}),
        ((package_id, ''), {'create': create}),
    ):
        try:
            value = fn(*args, **kwargs)
        except TypeError:
            continue
        except Exception:
            continue
        if value:
            accepted = _accept_user_default_package_path(Path(value), package_id, create)
            if accepted is not None:
                return accepted
    return None


def _user_resource_root(package_id: str, create: bool) -> Path | None:
    if bpy is None:
        return None
    user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
    if not callable(user_resource):
        return None
    for kind, rel in (
        ('EXTENSIONS', f'{USER_DEFAULT_REPO_NAME}/{package_id}'),
        ('EXTENSIONS', f'{USER_DEFAULT_REPO_NAME}/{PACKAGE_ID}'),
    ):
        try:
            value = user_resource(kind, path=rel, create=create)
        except Exception:
            value = ''
        if value:
            accepted = _accept_user_default_package_path(Path(value), package_id, create)
            if accepted is not None:
                return accepted
    try:
        config = user_resource('CONFIG', create=False) or ''
        if config:
            path = Path(config).resolve().parent / 'extensions' / USER_DEFAULT_REPO_NAME / package_id
            accepted = _accept_user_default_package_path(path, package_id, create)
            if accepted is not None:
                return accepted
    except Exception:
        pass
    return None


def _platform_user_default_package_root(package_id: str, create: bool) -> Path:
    version = _blender_version()
    if os.name == 'nt':
        roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        path = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'extensions' / USER_DEFAULT_REPO_NAME / package_id
    else:
        # Non-Windows fallback still mirrors Blender's versioned user_default repository.
        path = Path.home() / '.config' / 'blender' / version / 'extensions' / USER_DEFAULT_REPO_NAME / package_id
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def _config_root(create: bool = False) -> Path:
    """Return Blender's versioned CONFIG directory without touching packages."""
    if bpy is not None:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            for args, kwargs in (
                (('CONFIG',), {'path': '', 'create': bool(create)}),
                (('CONFIG',), {'create': bool(create)}),
                (('CONFIG',), {}),
            ):
                try:
                    value = user_resource(*args, **kwargs)
                except TypeError:
                    continue
                except Exception:
                    value = ''
                if value:
                    path = Path(value)
                    if create:
                        path.mkdir(parents=True, exist_ok=True)
                    return path
    version = _blender_version()
    if os.name == 'nt':
        roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        path = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'config'
    else:
        path = Path.home() / '.config' / 'blender' / version / 'config'
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def mutable_root(*parts: object, create: bool = False) -> Path:
    """Canonical root for every Smart UV generated or user-editable file.

    On Windows Blender 5.1 this is
    ``%APPDATA%/Blender Foundation/Blender/5.1/config/Smart_UV_Suite``.
    The installed Extension package is deliberately never returned here.
    """
    path = _config_root(create=create) / CONFIG_DIRNAME
    clean = _clean_parts(parts)
    if clean:
        path = path.joinpath(*clean)
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def mutable_data_dir(*parts: object, create: bool = False) -> Path:
    return mutable_root(USER_DATA_DIRNAME, *parts, create=create)


def package_id(default: object = None) -> str:
    value = str(default or PACKAGE_ID or '').strip()
    return value or PACKAGE_ID


def manifest_extension_id(default: str = PACKAGE_ID) -> str:
    return package_id(default)


def extension_user_root(package: object | None = None, *, create: bool = False) -> Path:
    """Return a read-only Extension package location.

    ``create`` remains accepted for legacy callers but is intentionally ignored:
    package directories are never a writable settings/runtime/report location.
    """
    pkg = package_id(package)
    installed = _installed_extension_root() if pkg == PACKAGE_ID else None
    if installed is not None:
        return installed
    for candidate in (_user_resource_root(pkg, False), _extension_path_user_root(pkg, False)):
        if candidate is not None:
            return candidate
    return _platform_user_default_package_root(pkg, False)


def user_default_root(*parts: object, package_id: str | None = None, create: bool = True) -> Path:
    """Legacy writable-root API redirected to the canonical CONFIG root."""
    del package_id
    root = mutable_root(create=create)
    clean = _clean_parts(parts)
    path = root.joinpath(*clean) if clean else root
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def extension_dir(create: bool = False) -> Path:
    return extension_user_root(PACKAGE_ID, create=False)


def user_data_dir(*parts: object, create: bool = False) -> Path:
    return mutable_data_dir(*parts, create=create)


def user_data_file(*parts: object, create_parent: bool = False) -> Path:
    if not parts:
        raise ValueError('user_data_file requires at least one path component')
    clean = _clean_parts(parts)
    if not clean:
        raise ValueError('user_data_file requires a non-empty filename')
    path = user_data_dir(*clean[:-1], create=create_parent) / clean[-1]
    if create_parent:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_data_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('data', *parts, create=create)


def addon_data_path(*parts: object, create: bool = True) -> Path:
    clean = _clean_parts(parts)
    if not clean:
        return addon_data_dir(create=create)
    path = addon_data_dir(*clean[:-1], create=create) / clean[-1]
    return path


def storage_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('storage', *parts, create=create)


def storage_path(filename: object, *parts: object, create: bool = True) -> Path:
    clean = _clean_parts([*parts, filename])
    if not clean:
        raise ValueError('storage_path requires a filename')
    path = storage_dir(*clean[:-1], create=create) / clean[-1]
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_storage_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('storage', *parts, create=create)


def data_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('data', *parts, create=create)


def settings_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('settings', *parts, create=create)


def runtime_dir(*parts: object, create: bool = True, package: object | None = None) -> Path:
    # Package aliases are migration inputs only; all current writes share one
    # stable CONFIG location regardless of the historical module namespace.
    del package
    root = mutable_data_dir('runtime', create=create)
    clean = _clean_parts(parts)
    if clean:
        root = root.joinpath(*clean)
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root


def settings_file(name: object, *, create: bool = True) -> Path:
    clean = _clean_part(name)
    if not clean:
        raise ValueError('settings_file requires a filename')
    path = settings_dir(create=create) / clean
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def runtime_file(filename: object, *subdirs: object, create: bool = True, package: object | None = None) -> Path:
    clean = _clean_parts([*subdirs, filename])
    if not clean:
        raise ValueError('runtime_file requires a filename')
    path = runtime_dir(*clean[:-1], create=create, package=package) / clean[-1]
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_storage_path(filename: object, *subdirs: object, package_id: str | None = None, create: bool = True) -> Path:
    clean = _clean_parts([*subdirs, filename])
    if not clean:
        raise ValueError('addon_storage_path requires a filename')
    del package_id
    root = mutable_data_dir('storage', create=create)
    if len(clean) > 1:
        root = root.joinpath(*clean[:-1])
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root / clean[-1]


def write_json(filename: object, payload: Any, subdir: str = 'reports') -> Path:
    path = user_data_file(subdir, filename, create_parent=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    return path


def read_json(path: str | Path, default: Any = None) -> Any:
    try:
        return json.loads(Path(path).read_text(encoding='utf-8'))
    except Exception:
        return default


def atomic_write_text(path: str | Path, text: str, *, encoding: str = 'utf-8') -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_name(target.name + '.tmp')
    tmp.write_text(text, encoding=encoding)
    tmp.replace(target)


def atomic_write_json(path: str | Path, data: Any, *, indent: int = 2, ensure_ascii: bool = False, sort_keys: bool = False) -> None:
    atomic_write_text(path, json.dumps(data, indent=indent, ensure_ascii=ensure_ascii, sort_keys=sort_keys, default=str), encoding='utf-8')


def legacy_package_user_data_dir(package: object | None = None, *parts: object) -> Path:
    """Return a package ``user_data`` path strictly for read-only migration."""
    path = extension_user_root(package or PACKAGE_ID, create=False) / USER_DATA_DIRNAME
    clean = _clean_parts(parts)
    return path.joinpath(*clean) if clean else path


def migrate_legacy_user_data() -> dict[str, int]:
    """Copy old package-local mutable data into CONFIG without changing source.

    Existing CONFIG files win. Symlinks, bytecode and cache directories are not
    copied. The old Extension package remains byte-for-byte untouched.
    """
    result = {'sources': 0, 'copied': 0, 'skipped': 0}
    target_root = mutable_data_dir(create=True)
    seen: set[str] = set()
    for legacy_id in LEGACY_PACKAGE_IDS:
        source_root = legacy_package_user_data_dir(legacy_id)
        try:
            source_key = str(source_root.resolve())
        except Exception:
            source_key = str(source_root)
        if source_key in seen:
            continue
        seen.add(source_key)
        try:
            if not source_root.is_dir() or source_root.is_symlink():
                continue
        except Exception:
            continue
        result['sources'] += 1
        for source in source_root.rglob('*'):
            try:
                relative = source.relative_to(source_root)
                if source.is_symlink() or not source.is_file():
                    continue
                if '__pycache__' in relative.parts or source.suffix.lower() in {'.pyc', '.pyo'}:
                    result['skipped'] += 1
                    continue
                target = target_root / relative
                if target.exists():
                    result['skipped'] += 1
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)
                result['copied'] += 1
            except Exception:
                result['skipped'] += 1
    return result


def migrate_legacy_file(legacy_path: Path | None, target_path: Path | None, *, remove_legacy: bool = False) -> bool:
    if legacy_path is None or target_path is None:
        return False
    legacy = Path(legacy_path)
    target = Path(target_path)
    try:
        if not legacy.exists() or target.exists():
            return False
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(legacy, target)
        # Package data is a read-only migration source. ``remove_legacy`` is
        # retained for API compatibility only for non-package paths.
        legacy_text = legacy.resolve().as_posix().lower()
        package_source = '/extensions/user_default/' in legacy_text
        if remove_legacy and not package_source:
            try:
                legacy.unlink()
            except Exception:
                pass
        return True
    except Exception:
        return False
