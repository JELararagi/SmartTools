# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""JELararagi UV Gizmo Grip Fix for Blender 5.1.

This add-on keeps the UV Editor transform gizmo grabbable by combining the
native gizmo keymap fix with a strict strict direct fallback transform zone around the
selected UV pivot. The fallback bypasses Blender's native gizmo hit test when it
is delayed or stolen by heavy UV selection processing. During modal operation it
stores stable face/loop indices instead of live BMesh loop references so heavy
edit-mesh redraws cannot invalidate the dragged UV records.
"""

from __future__ import annotations
from . import resource_api_18168 as _suv_resource

bl_info = {
    "name": "JELararagi UV Gizmo Grip Fix",
    "author": "JELararagi",
    "version": (1, 2, 4),
    "blender": (5, 1, 0),
    "location": "UV Editor / F3 Search",
    "description": "Keeps the UV Editor transform gizmo grabbable by fixing gizmo keymaps and adding a strict fallback grip zone that preserves background selection drag.",
    "category": "UV",
    "support": "COMMUNITY",
}

__version__ = "1.2.4"

from math import atan2, cos, sin
from typing import Iterable, Optional

import bpy
import bmesh
from mathutils import Vector

_OPERATOR_IDNAME = "smart_uv_suite.uv_gizmo_grip_fix_grab"
_APPLY_OPERATOR_IDNAME = "smart_uv_suite.uv_gizmo_grip_fix_apply"
_NATIVE_GIZMO_OPERATOR_ID = ""
_KEYMAP_ITEMS: list[tuple[object, object]] = []
# Ledgers referenced by the keymap tracking / restore layer below; their
# initializers were dropped in an earlier consolidation, which made every
# reference a NameError at run time.
_REGISTERED_KEYMAP_ITEMS: list[tuple[object, object]] = []
_ORIGINAL_KEYMAP_STATE: dict[str, object] = {}
_ORIGINAL_PREFERENCE_STATE: dict[str, object] = {}


def cancel_deferred_reapply() -> None:
    # The deferred keymap-reapply layer is defused (_deferred_reapply_timer
    # returns None and never registers a timer), so there is nothing to cancel.
    return None

_NATIVE_GIZMO_KEYMAP_NAMES = (
    "Generic Gizmo",
    "Generic Gizmo Drag",
    "Generic Gizmo Click Drag",
    "Generic Gizmo Maybe Drag",
    "Generic Gizmo Select",
)

# Pixel zones are based on Blender's default gizmo size.  The fallback operator
# runs before the normal UV selection tools, so these zones must stay tight.
# A broad area makes empty-background drags turn into transforms instead of
# Blender's standard box/select drag.
_CENTER_HIT_RADIUS_PX = 16.0
_AXIS_HANDLE_MIN_PX = 28.0
_AXIS_HANDLE_MAX_PX = 112.0
_AXIS_HIT_RADIUS_PX = 10.0
_SCALE_DIAGONAL_MIN_PX = 34.0
_SCALE_DIAGONAL_MAX_PX = 104.0
_SCALE_DIAGONAL_TOLERANCE_PX = 13.0
_ROTATE_RING_MIN_PX = 82.0
_ROTATE_RING_MAX_PX = 88.0
# Prevent accidental grabs when users begin a drag in the negative/background
# side of the pivot. Blender's 2D UV gizmo uses the visible positive-axis handle
# directions for move/scale grip targets.
_REQUIRE_POSITIVE_HANDLE_DIRECTIONS = True
_MIN_VECTOR_LENGTH = 1.0e-8
_MIN_SCALE = 1.0e-5
_MAX_SCALE = 100000.0

_LABEL_GRAB_EN = "UV Gizmo Grip Fix Grab"
_LABEL_GRAB_JA = "UVギズモつかみ修正"
_LABEL_APPLY_EN = "Apply UV Gizmo Grip Fix"
_LABEL_APPLY_JA = "UVギズモつかみ修正を適用"

_TOOLTIP_GRAB_EN = (
    "Starts a direct UV transform only when the mouse is pressed on the selected UV pivot or on the narrow visible standard gizmo handle zone. "
    "Use it by dragging the center to move, the horizontal or vertical handle to constrain movement, the diagonal handle to scale, or the thin outer ring line to rotate. "
    "This is a fallback for heavy UV data where Blender shows the gizmo but the native gizmo hit test does not reliably grab it."
)
_TOOLTIP_GRAB_JA = (
    "選択中UVのピボット、または標準ギズモの見えている細いハンドル位置で左ドラッグした時だけ、UVを直接変形します。"
    "中央は移動、横方向または縦方向のハンドルは軸固定移動、斜め方向のハンドルは拡大縮小、外側リングの細い線上は回転として使います。"
    "重いUVデータでギズモは表示されているのにBlender標準のヒット判定が安定せず掴めない場合の補助処理です。"
)
_TOOLTIP_APPLY_EN = (
    "Reapplies the UV gizmo grip fix. It restores the native gizmo activation event to left mouse press and registers the UV Editor fallback grip keymap again. "
    "Run this from search if another add-on, a keymap reload, or a file load overwrites the gizmo keymap while Blender is open."
)
_TOOLTIP_APPLY_JA = (
    "UVギズモつかみ修正を再適用します。Blender標準ギズモの起動イベントを左クリックの押下へ戻し、UVエディター用の補助グリップのキー割り当てを再登録します。"
    "Blenderを開いている間に別アドオン、キー設定の再読み込み、ファイル読み込みによってギズモ用キー割り当てが上書きされた場合に、検索から実行してください。"
)

_TRANSLATIONS = {
    "ja_JP": {
        ("Operator", _LABEL_GRAB_EN): _LABEL_GRAB_JA,
        ("*", _LABEL_GRAB_EN): _LABEL_GRAB_JA,
        ("Operator", _LABEL_APPLY_EN): _LABEL_APPLY_JA,
        ("*", _LABEL_APPLY_EN): _LABEL_APPLY_JA,
        ("Operator", _TOOLTIP_GRAB_EN): _TOOLTIP_GRAB_JA,
        ("*", _TOOLTIP_GRAB_EN): _TOOLTIP_GRAB_JA,
        ("Operator", _TOOLTIP_APPLY_EN): _TOOLTIP_APPLY_JA,
        ("*", _TOOLTIP_APPLY_EN): _TOOLTIP_APPLY_JA,
        ("*", bl_info["description"]): "ギズモ用キー設定を補正し、背景ドラッグ選択を妨げにくい細い補助グリップ範囲を追加して、UVエディターのトランスフォームギズモを掴める状態に保ちます。",
    }
}


_VERBOSE_LOGGING = False


def _log(message: str) -> None:
    if not _VERBOSE_LOGGING:
        return
    try:
        print(f"[Smart UV Suite UV Gizmo Grip Fix] {message}")
    except OSError:
        pass
    except Exception:
        pass


def _safe_translation_register() -> None:
    try:
        from . import ownership_runtime_18168 as _ownership
        _ownership.register_translation(__name__, _TRANSLATIONS)
    except Exception:
        pass



def _safe_translation_unregister() -> None:
    try:
        from . import ownership_runtime_18168 as _ownership
        _ownership.unregister_translation(__name__)
    except Exception:
        pass



def _is_uv_editor_context(context) -> bool:
    area = getattr(context, "area", None)
    region = getattr(context, "region", None)
    space = getattr(context, "space_data", None)
    if area is None or area.type != "IMAGE_EDITOR":
        return False
    if region is None or region.type != "WINDOW":
        return False
    if space is None:
        return False
    return str(getattr(space, "ui_type", "")) == "UV" or str(getattr(space, "mode", "")) == "UV"


def _iter_edit_mesh_objects(context) -> Iterable[bpy.types.Object]:
    objects = getattr(context, "objects_in_mode_unique_data", None)
    if objects:
        for obj in objects:
            if getattr(obj, "type", None) == "MESH" and getattr(obj, "mode", None) == "EDIT":
                yield obj
        return
    obj = getattr(context, "object", None)
    if obj is not None and getattr(obj, "type", None) == "MESH" and getattr(obj, "mode", None) == "EDIT":
        yield obj


def _bool_attr(obj, name: str) -> bool:
    try:
        return bool(getattr(obj, name, False))
    except Exception:
        return False


def _event_has_selection_modifier(event) -> bool:
    """Return True for modifier states used by normal selection tools.

    The fallback keymap is placed before Image Editor selection entries.
    Passing modifier drags through keeps add/subtract/toggle box selection and
    other user keymap variations from being converted into direct transforms.
    """
    return bool(
        getattr(event, "shift", False)
        or getattr(event, "ctrl", False)
        or getattr(event, "oskey", False)
        or getattr(event, "hyper", False)
    )


def _is_loop_visible(loop, face) -> bool:
    return not (
        _bool_attr(face, "hide")
        or _bool_attr(loop.vert, "hide")
        or _bool_attr(loop.edge, "hide")
    )


def _direct_uv_selected(loop, face, uv_layer) -> bool:
    luv = loop[uv_layer]
    return bool(
        _bool_attr(loop, "uv_select_vert")
        or _bool_attr(loop, "uv_select_edge")
        or _bool_attr(face, "uv_select")
        or _bool_attr(luv, "select")
        or _bool_attr(luv, "select_vert")
        or _bool_attr(luv, "select_edge")
    )


def _mesh_selection_selected(loop, face, tool_settings) -> bool:
    mesh_select_mode = tuple(getattr(tool_settings, "mesh_select_mode", (True, False, False)))
    if len(mesh_select_mode) > 2 and bool(mesh_select_mode[2]) and _bool_attr(face, "select"):
        return True
    if len(mesh_select_mode) > 1 and bool(mesh_select_mode[1]) and _bool_attr(loop.edge, "select"):
        return True
    if len(mesh_select_mode) > 0 and bool(mesh_select_mode[0]) and _bool_attr(loop.vert, "select"):
        return True
    return False


def _is_loop_uv_selected(loop, face, uv_layer, tool_settings, bm=None, *, allow_mesh_fallback: bool = False) -> bool:
    if not _is_loop_visible(loop, face):
        return False

    direct_selected = _direct_uv_selected(loop, face, uv_layer)
    use_sync = bool(getattr(tool_settings, "use_uv_select_sync", False))

    if direct_selected:
        return True

    # In UV Select Sync mode Blender's mesh-vertex selection can represent several
    # split UV vertices at different UV coordinates.  Treating that mesh selection
    # as an authoritative UV selection makes separated UV vertices transform
    # together.  Mesh fallback is therefore used only by callers that explicitly
    # request it, and the collector will isolate the nearest visible UV component
    # before a direct fallback transform starts.
    if allow_mesh_fallback:
        return _mesh_selection_selected(loop, face, tool_settings)

    if use_sync:
        return False
    return False

def _uv_layer_name(uv_layer) -> str:
    try:
        return str(getattr(uv_layer, "name", "") or "")
    except Exception:
        return ""


def _resolve_uv_layer(bm, layer_name: str):
    if layer_name:
        try:
            uv_layer = bm.loops.layers.uv.get(layer_name)
            if uv_layer is not None:
                return uv_layer
        except Exception:
            pass
    try:
        return bm.loops.layers.uv.active
    except Exception:
        return None


def _refresh_face_lookup(bm, *, update_indices: bool = False) -> None:
    try:
        bm.faces.ensure_lookup_table()
    except Exception:
        pass
    if update_indices:
        try:
            bm.faces.index_update()
        except Exception:
            pass




def _collect_selected_uv_state(context, anchor_uv: Optional[Vector] = None):
    """Collect every selected UV loop for the gizmo fallback transform.

    The selected domain follows the current UV selection mode.  This prevents
    stale face selection from making the gizmo move unselected loops, and it
    also includes both endpoints of selected UV edges so every selected element
    transforms together.
    """
    tool_settings = context.tool_settings
    try:
        raw_mode = getattr(tool_settings, "uv_select_mode", "VERTEX")
        if isinstance(raw_mode, (set, list, tuple)):
            raw_mode = " ".join(str(m) for m in raw_mode)
        mode = str(raw_mode or "VERTEX").upper()
    except Exception:
        mode = "VERTEX"
    if "ISLAND" in mode:
        mode = "ISLAND"
    elif "FACE" in mode:
        mode = "FACE"
    elif "EDGE" in mode:
        mode = "EDGE"
    else:
        mode = "VERTEX"

    def read_bool_attr(attr, length: int):
        vals = [False] * max(0, int(length))
        try:
            if attr is not None:
                for i in range(min(len(vals), len(attr.data))):
                    vals[i] = bool(getattr(attr.data[i], "value", False))
        except Exception:
            pass
        return vals

    def build_batches(records):
        batches = []
        total_count = 0
        sum_uv = Vector((0.0, 0.0))
        min_uv = Vector((float("inf"), float("inf")))
        max_uv = Vector((float("-inf"), float("-inf")))
        for record in records:
            loops = list(record.get("loops") or [])
            if not loops:
                continue
            batches.append({"mesh": record["mesh"], "uv_layer_name": record["uv_layer_name"], "loops": loops})
            for _face_index, _loop_index, uv in loops:
                sum_uv += uv
                min_uv.x = min(min_uv.x, uv.x)
                min_uv.y = min(min_uv.y, uv.y)
                max_uv.x = max(max_uv.x, uv.x)
                max_uv.y = max(max_uv.y, uv.y)
                total_count += 1
        if total_count <= 0:
            return [], None
        return batches, {"median": sum_uv / total_count, "bbox_center": Vector(((min_uv.x + max_uv.x) * 0.5, (min_uv.y + max_uv.y) * 0.5)), "count": total_count}

    direct_records = []
    fallback_records = []
    direct_count = 0
    fallback_count = 0

    for obj in _iter_edit_mesh_objects(context):
        mesh = getattr(obj, "data", None)
        if mesh is None:
            continue
        try:
            bm = bmesh.from_edit_mesh(mesh)
        except Exception:
            continue
        uv_layer = bm.loops.layers.uv.active
        if uv_layer is None:
            continue
        _refresh_face_lookup(bm, update_indices=True)
        uv_layer_name = _uv_layer_name(uv_layer)
        attrs = getattr(mesh, "attributes", None)
        vattr = attrs.get(".uv_select_vert") if attrs is not None else None
        eattr = attrs.get(".uv_select_edge") if attrs is not None else None
        fattr = attrs.get(".uv_select_face") if attrs is not None else None
        vflags = read_bool_attr(vattr, len(getattr(mesh, "loops", []) or []))
        eflags = read_bool_attr(eattr, len(getattr(mesh, "loops", []) or []))
        fflags = read_bool_attr(fattr, len(getattr(mesh, "polygons", []) or []))

        def loop_index(loop):
            try:
                return int(getattr(loop, "index", -1))
            except Exception:
                return -1

        def face_index(face):
            try:
                return int(getattr(face, "index", -1))
            except Exception:
                return -1

        def live_vert(loop):
            try:
                return bool(getattr(loop, "uv_select_vert", False))
            except Exception:
                return False

        def live_edge(loop):
            try:
                return bool(getattr(loop, "uv_select_edge", False))
            except Exception:
                return False

        def live_face(face):
            try:
                return bool(getattr(face, "uv_select", False))
            except Exception:
                return False

        def add_loop(records, seen, face, loop):
            try:
                fi = face_index(face)
                local = list(face.loops).index(loop)
                key = (fi, local)
                if key in seen:
                    return
                seen.add(key)
                records.append((fi, int(local), loop[uv_layer].uv.copy()))
            except Exception:
                pass

        recs = []
        seen = set()
        for face in bm.faces:
            if _bool_attr(face, "hide"):
                continue
            fi = face_index(face)

            if mode in {"FACE", "ISLAND"}:
                face_selected = live_face(face) or (0 <= fi < len(fflags) and fflags[fi])
                if face_selected:
                    for loop in face.loops:
                        add_loop(recs, seen, face, loop)
                continue

            for loop in face.loops:
                li = loop_index(loop)
                if mode == "EDGE":
                    edge_selected = live_edge(loop) or (0 <= li < len(eflags) and eflags[li])
                    if edge_selected:
                        add_loop(recs, seen, face, loop)
                        try:
                            add_loop(recs, seen, face, loop.link_loop_next)
                        except Exception:
                            pass
                else:
                    vert_selected = live_vert(loop) or (0 <= li < len(vflags) and vflags[li])
                    if vert_selected:
                        add_loop(recs, seen, face, loop)

        if recs:
            direct_records.append({"mesh": mesh, "uv_layer_name": uv_layer_name, "loops": recs})
            direct_count += len(recs)
            continue

        # Mesh-selection fallback is mode-aware and used only when there is no
        # UV editor selection state.  It keeps all selected elements in the
        # current selection domain so the gizmo cannot drop selected elements.
        frecs = []
        fseen = set()
        for face in bm.faces:
            if _bool_attr(face, "hide"):
                continue
            if mode in {"FACE", "ISLAND"}:
                try:
                    if bool(face.select):
                        for loop in face.loops:
                            add_loop(frecs, fseen, face, loop)
                except Exception:
                    pass
                continue
            for loop in face.loops:
                if mode == "EDGE":
                    try:
                        selected = bool(loop.edge.select)
                    except Exception:
                        selected = False
                    if selected:
                        add_loop(frecs, fseen, face, loop)
                        try:
                            add_loop(frecs, fseen, face, loop.link_loop_next)
                        except Exception:
                            pass
                else:
                    try:
                        selected = bool(loop.vert.select)
                    except Exception:
                        selected = False
                    if selected:
                        add_loop(frecs, fseen, face, loop)
        if frecs:
            fallback_records.append({"mesh": mesh, "uv_layer_name": uv_layer_name, "loops": frecs})
            fallback_count += len(frecs)

    if direct_count > 0:
        return build_batches(direct_records)
    if fallback_count > 0:
        return build_batches(fallback_records)
    return [], None


def _selected_uv_pivot(context, stats) -> Optional[Vector]:
    if not stats:
        return None
    space = getattr(context, "space_data", None)
    tool_settings = getattr(getattr(context, "scene", None), "tool_settings", None)
    pivot_mode = "MEDIAN_POINT"
    if tool_settings is not None:
        pivot_mode = str(getattr(tool_settings, "transform_pivot_point", pivot_mode))
    if space is not None and hasattr(space, "pivot_point"):
        pivot_mode = str(getattr(space, "pivot_point", pivot_mode))
    if "CURSOR" in pivot_mode and space is not None:
        cursor_location = getattr(space, "cursor_location", None)
        if cursor_location is not None and len(cursor_location) >= 2:
            return Vector((float(cursor_location[0]), float(cursor_location[1])))
        return stats["median"].copy()
    if "BOUNDING" in pivot_mode or "CENTER" in pivot_mode:
        return stats["bbox_center"].copy()
    return stats["median"].copy()




def _uv_cursor_pivot_active(context) -> bool:
    """Return True when the UV Editor transform pivot is the 2D cursor."""
    try:
        space = getattr(context, "space_data", None)
        pivot = ""
        if space is not None and hasattr(space, "pivot_point"):
            pivot = str(getattr(space, "pivot_point", "") or "")
        if not pivot:
            tool_settings = getattr(getattr(context, "scene", None), "tool_settings", None)
            pivot = str(getattr(tool_settings, "transform_pivot_point", "") or "") if tool_settings is not None else ""
        return "CURSOR" in pivot.upper()
    except Exception:
        return False


def _uv_increment_snap_active(context) -> bool:
    """Return True for UV/Grid increment snapping during translation.

    This guard is intentionally narrow.  It only changes the fallback gizmo move
    path when Blender is in UV/grid-style snapping, which is the configuration
    where native 2D-cursor-pivot transforms can recenter the selection at the
    cursor/snap point on transform start.
    """
    try:
        ts = getattr(getattr(context, "scene", None), "tool_settings", None)
        if ts is None:
            return False
        if not bool(getattr(ts, "use_snap_uv", False) or getattr(ts, "use_snap", False)):
            return False
        if hasattr(ts, "use_snap_translate") and not bool(getattr(ts, "use_snap_translate", True)):
            return False
        elements = set()
        for name in ("snap_uv_element", "snap_elements", "snap_elements_base"):
            try:
                raw = getattr(ts, name, None)
                if isinstance(raw, (set, list, tuple)):
                    elements.update(str(v).upper() for v in raw)
                elif raw is not None:
                    elements.add(str(raw).upper())
            except Exception:
                pass
        if not elements:
            return True
        return any(token in elements for token in ("INCREMENT", "GRID", "GRID_INCREMENT"))
    except Exception:
        return False


def _uv_grid_step(context) -> Vector:
    """Approximate the visible UV grid step for relative snapping.

    The UV Editor exposes custom-grid subdivisions but not the complete dynamic
    draw grid RNA.  For the problematic 2D-cursor-pivot case we only need stable
    relative increments; using the configured subdivision as 1/subdivision keeps
    deltas locked to the same grid family without ever moving the selection to
    the cursor at transform start.
    """
    step_u = 1.0
    step_v = 1.0
    try:
        space = getattr(context, "space_data", None)
        uv_editor = getattr(space, "uv_editor", None) if space is not None else None
        raw = getattr(uv_editor, "custom_grid_subdivisions", None) if uv_editor is not None else None
        if raw is not None:
            if isinstance(raw, (tuple, list)) and len(raw) >= 2:
                su = max(int(raw[0]), 1)
                sv = max(int(raw[1]), 1)
            else:
                su = sv = max(int(raw), 1)
            step_u = 1.0 / float(su)
            step_v = 1.0 / float(sv)
    except Exception:
        pass
    try:
        # The Smart UV dynamic-grid subdivision UI is no longer shown for Blender's
        # Dynamic/Pixel grid sources because those modes are internally drawn by
        # Blender.  Do not let an old saved value affect snapping there.
        space = getattr(context, "space_data", None)
        uv_editor = getattr(space, "uv_editor", None) if space is not None else None
        source = str(getattr(uv_editor, "grid_shape_source", "") or "").upper() if uv_editor is not None else ""
        if source not in {"DYNAMIC", "PIXEL"}:
            ws = getattr(getattr(context, "scene", None), "suv_workspace", None)
            subdiv = int(getattr(ws, "canvas_grid_dynamic_subdivisions", 0) or 0) if ws is not None else 0
            if subdiv > 0:
                step_u = step_v = 1.0 / float(subdiv)
    except Exception:
        pass
    return Vector((max(step_u, 1.0e-9), max(step_v, 1.0e-9)))


def _snap_uv_delta_relative_to_cursor(context, delta: Vector) -> Vector:
    """Snap a translation delta without snapping the selection origin to cursor.

    Blender's native 2D-cursor pivot + grid snap path may treat the cursor/pivot
    as the snap point and shift the selected UVs to that point at the beginning
    of a transform.  The fallback gizmo must instead keep every selected UV's
    current offset from the cursor and snap only the *movement delta*.
    """
    try:
        if not _uv_increment_snap_active(context):
            return delta
        # Snap only the movement delta.  This also restores practical grid snapping
        # in UV-select-sync OFF mode, where Blender's native UV snap can fail to
        # apply to independent UV selection flags.
        step = _uv_grid_step(context)
        du = round(float(delta.x) / float(step.x)) * float(step.x) if step.x > 0.0 else float(delta.x)
        dv = round(float(delta.y) / float(step.y)) * float(step.y) if step.y > 0.0 else float(delta.y)
        return Vector((du, dv))
    except Exception:
        return delta

def _region_to_view(region, x, y) -> Vector:
    vx, vy = region.view2d.region_to_view(float(x), float(y))
    return Vector((float(vx), float(vy)))


def _view_to_region(region, uv) -> Vector:
    rx, ry = region.view2d.view_to_region(float(uv.x), float(uv.y), clip=False)
    return Vector((float(rx), float(ry)))


def _hit_scale(context) -> float:
    scale = 1.0
    try:
        gizmo_size = float(getattr(context.preferences.view, "gizmo_size", 75.0))
        if gizmo_size > 0.0:
            scale *= gizmo_size / 75.0
    except Exception:
        pass
    try:
        ui_scale = float(getattr(context.preferences.system, "ui_scale", 0.0))
        if ui_scale > 0.0:
            scale *= ui_scale
    except Exception:
        pass
    return max(0.65, min(2.25, scale))


def _hit_test_fallback_area(context, event, pivot_region) -> Optional[str]:
    scale = _hit_scale(context)
    center_hit_radius = _CENTER_HIT_RADIUS_PX * scale
    axis_handle_min = _AXIS_HANDLE_MIN_PX * scale
    axis_handle_max = _AXIS_HANDLE_MAX_PX * scale
    axis_hit_radius = _AXIS_HIT_RADIUS_PX * scale
    scale_diagonal_min = _SCALE_DIAGONAL_MIN_PX * scale
    scale_diagonal_max = _SCALE_DIAGONAL_MAX_PX * scale
    scale_diagonal_tolerance = _SCALE_DIAGONAL_TOLERANCE_PX * scale
    rotate_ring_min = _ROTATE_RING_MIN_PX * scale
    rotate_ring_max = _ROTATE_RING_MAX_PX * scale

    dx = float(event.mouse_region_x) - float(pivot_region.x)
    dy = float(event.mouse_region_y) - float(pivot_region.y)
    abs_dx = abs(dx)
    abs_dy = abs(dy)
    radius_sq = dx * dx + dy * dy

    if radius_sq <= center_hit_radius * center_hit_radius:
        return "MOVE_XY"

    # Do not use abs() for the actual move/scale handles by default.  The
    # visible UV transform gizmo handles live on the positive X/Y side; accepting
    # the negative side makes ordinary empty-background drags around the pivot
    # look like gizmo grabs.
    x_handle_dx = dx if _REQUIRE_POSITIVE_HANDLE_DIRECTIONS else abs_dx
    y_handle_dy = dy if _REQUIRE_POSITIVE_HANDLE_DIRECTIONS else abs_dy

    if axis_handle_min <= x_handle_dx <= axis_handle_max and abs_dy <= axis_hit_radius:
        return "MOVE_X"
    if axis_handle_min <= y_handle_dy <= axis_handle_max and abs_dx <= axis_hit_radius:
        return "MOVE_Y"

    diagonal_x = dx if _REQUIRE_POSITIVE_HANDLE_DIRECTIONS else abs_dx
    diagonal_y = dy if _REQUIRE_POSITIVE_HANDLE_DIRECTIONS else abs_dy
    diagonal_hit = (
        scale_diagonal_min <= diagonal_x <= scale_diagonal_max
        and scale_diagonal_min <= diagonal_y <= scale_diagonal_max
        and abs(diagonal_x - diagonal_y) <= scale_diagonal_tolerance
    )
    if diagonal_hit:
        return "SCALE_UNIFORM"

    # Keep rotation as a narrow ring only. This avoids the previous wide halo
    # where dragging empty UV Editor background near the selected pivot could
    # incorrectly start a transform.
    radius = radius_sq ** 0.5
    if rotate_ring_min <= radius <= rotate_ring_max:
        return "ROTATE"
    return None


def _clamped_scale(value: float) -> float:
    return max(_MIN_SCALE, min(_MAX_SCALE, value))


# 1.8.229: the active-modal registry is self-healing.  It used to be a plain
# set of ids removed only on the clean CANCELLED/FINISHED returns; any
# exception escaping the modal terminated the operator WITHOUT the id being
# removed, after which _sus_18225_commit_keyconfig refused to publish forever
# and every keymap-backed feature in the suite went inert for the session.
# Entries now carry a weakref plus a monotonic timestamp; dead or stale
# entries are purged whenever the count is read, and a barriered commit is
# retried on a bounded timer.
_SUS_18224_ACTIVE_MODAL_IDS: dict[int, tuple] = {}
_SUS_18224_MODAL_STALE_SECONDS = 30.0
_SUS_18224_LAST_INVOKE_REASON = "never"
_SUS_18224_INVOKE_COUNT = 0


def _sus_18224_mark_invoke(reason: str) -> None:
    global _SUS_18224_LAST_INVOKE_REASON, _SUS_18224_INVOKE_COUNT
    _SUS_18224_LAST_INVOKE_REASON = str(reason or "")
    try:
        _SUS_18224_INVOKE_COUNT += 1
    except Exception:
        _SUS_18224_INVOKE_COUNT = 1


def _sus_18224_modal_begin(self) -> None:
    try:
        import time as _time
        import weakref as _weakref
        try:
            ref = _weakref.ref(self)
        except Exception:
            ref = None
        _SUS_18224_ACTIVE_MODAL_IDS[int(id(self))] = (ref, _time.monotonic())
    except Exception:
        pass


def _sus_18224_modal_touch(self) -> None:
    """Refresh the liveness stamp of a legitimately long-running gizmo drag."""
    try:
        import time as _time
        key = int(id(self))
        entry = _SUS_18224_ACTIVE_MODAL_IDS.get(key)
        if entry is not None:
            _SUS_18224_ACTIVE_MODAL_IDS[key] = (entry[0], _time.monotonic())
    except Exception:
        pass


def _sus_18224_modal_end(self) -> None:
    try:
        _SUS_18224_ACTIVE_MODAL_IDS.pop(int(id(self)), None)
    except Exception:
        pass
    _sus_18225_release_detach_barrier()


def _sus_18224_active_modal_count() -> int:
    try:
        import time as _time
        now = _time.monotonic()
        stale_keys = []
        for key, entry in list(_SUS_18224_ACTIVE_MODAL_IDS.items()):
            try:
                ref, stamp = entry
            except Exception:
                stale_keys.append(key)
                continue
            if ref is not None:
                try:
                    if ref() is None:
                        stale_keys.append(key)
                        continue
                except Exception:
                    pass
            if (now - float(stamp)) > _SUS_18224_MODAL_STALE_SECONDS:
                stale_keys.append(key)
        for key in stale_keys:
            _SUS_18224_ACTIVE_MODAL_IDS.pop(key, None)
        if stale_keys:
            _log(f"purged {len(stale_keys)} stale gizmo modal barrier entr(ies)")
        return len(_SUS_18224_ACTIVE_MODAL_IDS)
    except Exception:
        return 0


# --- 18225 keyconfig publication -------------------------------------------
#
# Rows created in ``wm.keyconfigs.addon`` are only a template.  Blender
# dispatches events from the active keyconfig, which is rebuilt from
# default+addon+user when the keyconfig update flag is processed.  Until that
# rebuild happens the freshly created SmartUV rows are fully valid in RNA - the
# ownership ledger, the raw ``keymap_items`` scan and the signature readback all
# agree - and completely inert at real event dispatch.  Run 11 recorded exactly
# that state: one owned, active, correctly signed Alt+LEFTMOUSE product row in
# "Image Generic" and ``_SUS_18224_INVOKE_COUNT == 0`` / reason ``never`` after a
# full press/move/release gesture on a validated grip point.  The same product
# row started dispatching later in the very same session, without being
# recreated, as soon as the diagnostic stage called ``keyconfigs.update()``.
#
# Publication is therefore an explicit, owned step after every keymap mutation
# transaction.  No RNA handle is retained across the call: callers re-resolve
# keymap items by ledger pointer afterwards.

_SUS_18225_KEYCONFIG_GENERATION = 0
_SUS_18225_LAST_COMMIT_REASON = "never"
_SUS_18225_PENDING_COMMIT_REASON = ""
_SUS_18225_DEFERRED_COMMIT = None
_SUS_18225_DEFERRED_RUNS = 0


def _sus_18225_keyconfig_generation() -> int:
    try:
        return int(_SUS_18225_KEYCONFIG_GENERATION)
    except Exception:
        return 0


def _sus_18225_commit_keyconfig(reason: str = "") -> bool:
    """Publish owned addon-keyconfig rows into the dispatching keyconfig."""
    global _SUS_18225_KEYCONFIG_GENERATION, _SUS_18225_LAST_COMMIT_REASON
    global _SUS_18225_PENDING_COMMIT_REASON
    if _sus_18224_active_modal_count() > 0:
        # Post-dispatch detach barrier.  Never rebuild the dispatching keyconfig
        # while a SmartUV modal still owns event handling; replay once the last
        # modal detaches — and keep a bounded retry running so a leaked entry
        # (purged by the stale sweep above) can never block publication forever.
        _SUS_18225_PENDING_COMMIT_REASON = str(reason or "")
        _sus_18225_schedule_deferred_commit()
        return False
    try:
        keyconfigs = getattr(getattr(bpy.context, "window_manager", None), "keyconfigs", None)
        native_update = getattr(keyconfigs, "update", None)
        if not callable(native_update):
            return False
        native_update()
    except Exception:
        _SUS_18225_PENDING_COMMIT_REASON = str(reason or "")
        return False
    _SUS_18225_PENDING_COMMIT_REASON = ""
    _SUS_18225_LAST_COMMIT_REASON = str(reason or "")
    try:
        _SUS_18225_KEYCONFIG_GENERATION += 1
    except Exception:
        _SUS_18225_KEYCONFIG_GENERATION = 1
    return True


def _sus_18225_deferred_commit():
    global _SUS_18225_DEFERRED_COMMIT
    if not _SUS_18168_ENABLED or not _sus_ownership.is_active():
        _SUS_18225_DEFERRED_COMMIT = None
        return None
    pending = str(_SUS_18225_PENDING_COMMIT_REASON or "")
    if not pending:
        _SUS_18225_DEFERRED_COMMIT = None
        return None
    if _sus_18225_commit_keyconfig(pending):
        _SUS_18225_DEFERRED_COMMIT = None
        return None
    global _SUS_18225_DEFERRED_RUNS
    _SUS_18225_DEFERRED_RUNS += 1
    if _SUS_18225_DEFERRED_RUNS >= 90:
        # Give up this round but clear the marker so the next modal detach or
        # commit attempt can schedule a fresh replay.
        _SUS_18225_DEFERRED_COMMIT = None
        return None
    # Still barriered by an attached (or not-yet-stale leaked) modal: keep the
    # bounded finite timer alive; the stale sweep clears a leak within
    # _SUS_18224_MODAL_STALE_SECONDS and the next tick then publishes.
    return 1.0


def _sus_18225_schedule_deferred_commit() -> None:
    """Queue the pending-commit replay on a bounded finite timer (once)."""
    global _SUS_18225_DEFERRED_COMMIT, _SUS_18225_DEFERRED_RUNS
    if _SUS_18225_DEFERRED_COMMIT is not None:
        return
    callback = _sus_18225_deferred_commit
    _SUS_18225_DEFERRED_COMMIT = callback
    _SUS_18225_DEFERRED_RUNS = 0
    try:
        registered = _sus_ownership.register_finite_timer(callback, first_interval=0.05, max_runs=90)
    except Exception:
        registered = None
    if registered is None:
        _SUS_18225_DEFERRED_COMMIT = None


def _sus_18225_release_detach_barrier() -> None:
    """Replay a barriered keyconfig commit once no SmartUV modal is attached."""
    if not _SUS_18225_PENDING_COMMIT_REASON:
        return
    if _sus_18224_active_modal_count() > 0:
        return
    # The modal is still on the native handler stack while ``modal`` returns, so
    # the rebuild is handed to a timer instead of running inline.
    _sus_18225_schedule_deferred_commit()


def _sus18229_record_gizmo_axis(context, mode: str, moved: bool) -> None:
    """U3: record a committed gizmo-grip drag into every axis-memory store.

    The final grip-fix authority superseded the interaction_1845 gizmo invokes
    that used to call _record_axis_from_mode on release, so gizmo drags — the
    user's primary axis gesture — stopped being remembered at all.
    interaction_1845._record_axis_from_mode gates on the real
    operation_axis_constraint_memory_enabled toggle, maps MOVE_X→U / MOVE_Y→V /
    MOVE_XY→FREE (SCALE/ROTATE leave memory untouched) and stamps its TTL so
    stale wm.operators history cannot immediately overwrite the fresh value;
    the 18228 per-window X/Y/NONE cache is synchronized alongside it.
    """
    if not moved:
        return
    m = str(mode or "").upper()
    if m not in {"MOVE_X", "MOVE_Y", "MOVE_XY", "MOVE", "FREE"}:
        return
    enabled = False
    try:
        from . import interaction_1845 as _i1845
        enabled = bool(_i1845._axis_enabled(context))
        if enabled:
            _i1845._record_axis_from_mode(context, m)
    except Exception:
        return
    if not enabled:
        return
    try:
        from . import smartuv_operation_runtime_18228 as _rt18228
        axis = {"MOVE_X": "X", "MOVE_Y": "Y"}.get(m, "NONE")
        _rt18228._set_axis(context, axis)
    except Exception:
        pass


class JELARARAGI_OT_uv_gizmo_grip_fix_grab(bpy.types.Operator):
    bl_idname = "smart_uv_suite.uv_gizmo_grip_fix_grab"
    bl_label = _LABEL_GRAB_EN
    bl_description = _TOOLTIP_GRAB_EN
    bl_options = {'UNDO', 'BLOCKING'}

    def invoke(self, context, event):
        if event.type != "LEFTMOUSE" or event.value != "PRESS":
            return {"PASS_THROUGH"}
        if _event_has_selection_modifier(event):
            return {"PASS_THROUGH"}
        if not _is_uv_editor_context(context) or not hasattr(context.region, "view2d"):
            return {"PASS_THROUGH"}

        try:
            press_uv = _region_to_view(context.region, event.mouse_region_x, event.mouse_region_y)
        except Exception:
            press_uv = None
        batches, stats = _collect_selected_uv_state(context, anchor_uv=press_uv)
        if not batches or not stats:
            return {"PASS_THROUGH"}

        pivot_uv = _selected_uv_pivot(context, stats)
        if pivot_uv is None:
            return {"PASS_THROUGH"}
        pivot_region = _view_to_region(context.region, pivot_uv)
        mode = _hit_test_fallback_area(context, event, pivot_region)
        if mode is None:
            return {"PASS_THROUGH"}

        self._area = context.area
        self._region = context.region
        self._batches = batches
        self._pivot_uv = pivot_uv
        self._mode = mode
        self._sus18229_moved = False
        self._start_mouse_view = _region_to_view(self._region, event.mouse_region_x, event.mouse_region_y)
        self._start_vector = self._start_mouse_view - self._pivot_uv
        context.window_manager.modal_handler_add(self)
        _sus_18224_modal_begin(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        # 1.8.229: the whole modal body is guarded.  An exception escaping a
        # modal terminates the operator WITHOUT a return value: Blender never
        # calls cancel() reliably in that case, the active-modal barrier entry
        # leaked, and every subsequent keyconfig publication in the suite was
        # silently refused for the rest of the session.
        try:
            return self._sus18229_modal_guarded(context, event)
        except Exception as exc:
            _log(f"gizmo modal failed safely and was cancelled: {exc}")
            try:
                self._restore_original_uvs(context)
            except Exception:
                pass
            _sus_18224_modal_end(self)
            return {"CANCELLED"}

    def _sus18229_modal_guarded(self, context, event):
        if event.type in {"ESC", "RIGHTMOUSE"}:
            self._restore_original_uvs(context)
            _sus_18224_modal_end(self)
            return {"CANCELLED"}
        if event.type == "LEFTMOUSE" and event.value == "RELEASE":
            # U3: a finished gizmo drag is the user's axis statement — record
            # MOVE_X/MOVE_Y as U/V and a free move as FREE in every store.
            _sus18229_record_gizmo_axis(
                context, getattr(self, "_mode", ""), bool(getattr(self, "_sus18229_moved", False))
            )
            self._tag_redraw(context)
            _sus_18224_modal_end(self)
            return {"FINISHED"}
        if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
            _sus_18224_modal_touch(self)
            try:
                self._apply_mode(context, _region_to_view(self._region, event.mouse_region_x, event.mouse_region_y))
                self._sus18229_moved = True
            except (ReferenceError, RuntimeError, IndexError) as exc:
                _log(f"modal cancelled because edit mesh data changed: {exc}")
                _sus_18224_modal_end(self)
                return {"CANCELLED"}
            return {"RUNNING_MODAL"}
        return {"RUNNING_MODAL"}

    def cancel(self, context):
        try:
            self._restore_original_uvs(context)
        except Exception:
            pass
        _sus_18224_modal_end(self)

    def _apply_mode(self, context, current_view: Vector) -> None:
        mode = self._mode
        if mode.startswith("MOVE"):
            delta = current_view - self._start_mouse_view
            if mode == "MOVE_X":
                delta.y = 0.0
            elif mode == "MOVE_Y":
                delta.x = 0.0
            # When the UV pivot is the 2D cursor and grid snapping is active,
            # never let the selected UV origin snap onto the cursor.  Snap the
            # translation delta itself so the selection keeps its relative offset
            # to the cursor/gizmo and begins the transform without any jump.
            delta = _snap_uv_delta_relative_to_cursor(context, delta)
            self._apply_to_uvs(context, lambda original: original + delta)
            return

        pivot = self._pivot_uv
        current_vector = current_view - pivot
        if mode == "SCALE_UNIFORM":
            start_len = max(float(self._start_vector.length), _MIN_VECTOR_LENGTH)
            current_len = max(float(current_vector.length), _MIN_VECTOR_LENGTH)
            scale = _clamped_scale(current_len / start_len)
            self._apply_to_uvs(context, lambda original: pivot + (original - pivot) * scale)
            return

        if mode == "ROTATE":
            if float(self._start_vector.length) <= _MIN_VECTOR_LENGTH or float(current_vector.length) <= _MIN_VECTOR_LENGTH:
                return
            angle = atan2(float(current_vector.y), float(current_vector.x)) - atan2(float(self._start_vector.y), float(self._start_vector.x))
            c = cos(angle)
            s = sin(angle)

            def rotated(original):
                rel = original - pivot
                return Vector((pivot.x + rel.x * c - rel.y * s, pivot.y + rel.x * s + rel.y * c))

            self._apply_to_uvs(context, rotated)

    def _apply_to_uvs(self, context, transform_func) -> None:
        for batch in self._batches:
            mesh = batch["mesh"]
            try:
                bm = bmesh.from_edit_mesh(mesh)
            except Exception:
                continue
            _refresh_face_lookup(bm)
            uv_layer = _resolve_uv_layer(bm, batch.get("uv_layer_name", ""))
            if uv_layer is None:
                continue

            changed = False
            for face_index, loop_index, original_uv in batch["loops"]:
                try:
                    face = bm.faces[int(face_index)]
                    if int(loop_index) < 0 or int(loop_index) >= len(face.loops):
                        continue
                    loop = face.loops[int(loop_index)]
                    loop[uv_layer].uv = transform_func(original_uv)
                    changed = True
                except (IndexError, ReferenceError, RuntimeError, TypeError, ValueError):
                    continue

            if changed:
                try:
                    bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
                except ReferenceError:
                    continue
        self._tag_redraw(context)

    def _restore_original_uvs(self, context) -> None:
        for batch in self._batches:
            mesh = batch["mesh"]
            try:
                bm = bmesh.from_edit_mesh(mesh)
            except Exception:
                continue
            _refresh_face_lookup(bm)
            uv_layer = _resolve_uv_layer(bm, batch.get("uv_layer_name", ""))
            if uv_layer is None:
                continue

            changed = False
            for face_index, loop_index, original_uv in batch["loops"]:
                try:
                    face = bm.faces[int(face_index)]
                    if int(loop_index) < 0 or int(loop_index) >= len(face.loops):
                        continue
                    loop = face.loops[int(loop_index)]
                    loop[uv_layer].uv = original_uv.copy()
                    changed = True
                except (IndexError, ReferenceError, RuntimeError, TypeError, ValueError):
                    continue

            if changed:
                try:
                    bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
                except ReferenceError:
                    continue
        self._tag_redraw(context)

    def _tag_redraw(self, context) -> None:
        # The retained self._area can be a dead RNA reference (area closed
        # mid-drag); a redraw request must never raise out of a modal path.
        try:
            area = getattr(self, "_area", None) or getattr(context, "area", None)
            if area is not None:
                area.tag_redraw()
        except Exception:
            pass
    # The registered invoke records indexed loops for the entire transaction.
    _apply_transaction_mode = _apply_mode
    _restore_transaction_uvs = _restore_original_uvs


class JELARARAGI_OT_uv_gizmo_grip_fix_sentinel(bpy.types.Operator):
    bl_idname = "smart_uv_suite.uv_gizmo_grip_fix_sentinel"
    bl_label = "Smart UV Gizmo Grip Fix Sentinel"
    bl_description = "Internal no-op keymap sentinel used to keep the active gizmo row reachable."
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        del context, event
        return {"PASS_THROUGH"}

    def execute(self, context):
        del context
        return {"CANCELLED"}


def _rna_has_property(obj, prop_name: str) -> bool:
    props = getattr(getattr(obj, "bl_rna", None), "properties", None)
    return bool(props and prop_name in props)


def _iter_keyconfigs():
    try:
        wm = getattr(bpy.context, "window_manager", None)
        kc = getattr(getattr(wm, "keyconfigs", None), "addon", None)
        return (kc,) if kc is not None else ()
    except Exception:
        return ()


def _prefer_native_gizmo_press() -> int:
    # Blender/user keyconfig preferences are foreign and remain unchanged.
    return False


def _configure_left_press_item(kmi, *, allow_modifiers: bool) -> None:
    try:
        __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, True)
    except Exception:
        pass

    if hasattr(kmi, "any"):
        try:
            _suv_resource.keymap_item_set(kmi, 'any', bool(allow_modifiers))
            if allow_modifiers:
                return
        except Exception:
            pass

    modifier_value = -1 if allow_modifiers else 0
    for attr in ("shift", "ctrl", "alt", "oskey", "hyper"):
        if hasattr(kmi, attr):
            try:
                _suv_resource.keymap_item_set(kmi, attr, modifier_value)
            except Exception:
                pass


def _patch_existing_native_gizmo_keymaps() -> int:
    """Native/user gizmo keymaps are foreign and must remain unchanged."""
    return 0


def _patch_existing_uv_fallback_keymaps() -> int:
    """Existing matching rows are foreign unless present in our exact ledger."""
    return 0


def _keymap_items_new(keymap, idname: str, event_type: str, value: str, *, head: bool = False):
    try:
        return __import__(__package__ + '.ownership_runtime_18168', fromlist=['new_keymap_item']).new_keymap_item(keymap, idname, type=event_type, value=value, head=head)
    except TypeError:
        return __import__(__package__ + '.ownership_runtime_18168', fromlist=['new_keymap_item']).new_keymap_item(keymap, idname, type=event_type, value=value)


def _track_keymap_item(keymap, kmi) -> None:
    item = (keymap, kmi)
    if item not in _REGISTERED_KEYMAP_ITEMS:
        _REGISTERED_KEYMAP_ITEMS.append(item)
    try:
        from . import ownership_runtime_18168 as _own
        _own.track_keymap_item(keymap, kmi, getattr(kmi, 'idname', _OPERATOR_IDNAME))
    except Exception:
        pass


def _find_addon_keymap_item(keymap, idname: str, event_type: str, value: str, *, allow_modifiers: bool):
    del allow_modifiers
    try:
        from . import ownership_runtime_18168 as _ownership
        for owned_keymap, kmi in _ownership.owned_keymap_items(str(idname)):
            if owned_keymap is not keymap:
                continue
            if getattr(kmi, 'type', '') == event_type and getattr(kmi, 'value', '') == value:
                return kmi
    except Exception:
        pass
    return None



def _ensure_addon_keymap_item(
    keyconfig,
    keymap_name: str,
    space_type: str,
    idname: str,
    *,
    allow_modifiers: bool,
) -> int:
    try:
        keymap = keyconfig.keymaps.get(keymap_name)
        if keymap is None:
            keymap = keyconfig.keymaps.new(name=keymap_name, space_type=space_type, region_type="WINDOW")
        existing = _find_addon_keymap_item(keymap, idname, "LEFTMOUSE", "PRESS", allow_modifiers=allow_modifiers)
        if existing is not None:
            # For the Smart UV fallback grip, stale addon keymap order is enough
            # to let Blender's native 2D-cursor pivot + grid-snap transform run
            # first and recenter the UV selection.  Recreate the addon-owned
            # item at the head whenever we enable the grip fix.  This touches
            # only the add-on keyconfig entry created for this operator.
            if idname == _OPERATOR_IDNAME:
                try:
                    __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(keymap, existing)
                    existing = None
                except Exception:
                    pass
            if existing is not None:
                _track_keymap_item(keymap, existing)
                return 0
        kmi = _keymap_items_new(keymap, idname, "LEFTMOUSE", "PRESS", head=True)
        _configure_left_press_item(kmi, allow_modifiers=allow_modifiers)
        _track_keymap_item(keymap, kmi)
        return 1
    except Exception as exc:
        _log(f"Failed to add keymap item {keymap_name} {idname}: {exc}")
        return 0


def _register_keymaps() -> tuple[int, int]:
    keyconfig = bpy.context.window_manager.keyconfigs.addon
    if keyconfig is None:
        return 0, 0
    native_count = 0
    uv_guard_count = 0
    for keymap_name in _NATIVE_GIZMO_KEYMAP_NAMES:
        native_count += _ensure_addon_keymap_item(
            keyconfig,
            keymap_name,
            "EMPTY",
            _NATIVE_GIZMO_OPERATOR_ID,
            allow_modifiers=True,
        )
        uv_guard_count += _ensure_addon_keymap_item(
            keyconfig,
            keymap_name,
            "EMPTY",
            _OPERATOR_IDNAME,
            allow_modifiers=False,
        )
    uv_guard_count += _ensure_addon_keymap_item(
        keyconfig,
        "Image",
        "IMAGE_EDITOR",
        _OPERATOR_IDNAME,
        allow_modifiers=False,
    )
    return native_count, uv_guard_count


def _unregister_keymaps() -> None:
    return None


def _load_post_reapply(_dummy=None):
    if not is_enabled():
        cancel_deferred_reapply()
        return None
    try:
        return _deferred_reapply_timer()
    except Exception:
        return None


def _deferred_reapply_timer():
    return None


class JELARARAGI_OT_uv_gizmo_grip_fix_apply(bpy.types.Operator):
    bl_idname = _APPLY_OPERATOR_IDNAME
    bl_label = _LABEL_APPLY_EN
    bl_description = _TOOLTIP_APPLY_EN
    bl_options = set()

    def execute(self, context):
        pref_changes = _prefer_native_gizmo_press()
        native_patches = _patch_existing_native_gizmo_keymaps()
        uv_fallback_patches = _patch_existing_uv_fallback_keymaps()
        native_count, uv_guard_count = _register_keymaps()
        message = (
            f"preference_changes={pref_changes}, native_keymap_patches={native_patches}, "
            f"uv_fallback_keymap_patches={uv_fallback_patches}, "
            f"native_keymap_items_created={native_count}, uv_guard_keymap_items_created={uv_guard_count}"
        )
        _log(message)
        self.report({"INFO"}, "UV Gizmo Grip Fix applied")
        return {"FINISHED"}


_CLASSES = (JELARARAGI_OT_uv_gizmo_grip_fix_grab, JELARARAGI_OT_uv_gizmo_grip_fix_apply)


def _suv_stage_001_register() -> None:
    return None
    # Do not enable keymaps or deferred timers on add-on install. The user toggle
    # controls runtime activation.


def _suv_stage_001_unregister() -> None:
    return None


# -----------------------------------------------------------------------------
# Smart UV Suite integration layer
# - default OFF
# - enabled only through Smart UV Suite Operation toggle
# - created add-on keymaps are removed again when disabled
# - existing preference/keymap edits are restored where Blender allows it
# -----------------------------------------------------------------------------

_ENABLED = False
_CREATED_KEYMAP_ITEMS: list[tuple[object, object]] = []
_EXISTING_KEYMAP_ORIGINALS: list[tuple[object, dict]] = []
_PREF_ORIGINALS: list[tuple[object, object]] = []
_REAPPLY_TIMER_REGISTERED = False


def _store_preference_original(prefs) -> None:
    try:
        for stored, _value in _PREF_ORIGINALS:
            if stored == prefs:
                return
        _PREF_ORIGINALS.append((prefs, getattr(prefs, 'gizmo_action', None)))
    except Exception:
        pass


def _store_keymap_original(kmi) -> None:
    # Exact owned KMI configuration requires no foreign-state snapshot.
    del kmi
    return None


def _restore_existing_keymaps() -> None:
    # No foreign KMI state was changed.
    try:
        _ORIGINAL_KEYMAP_STATE.clear()
    except Exception:
        pass
    return None


def _restore_preferences() -> None:
    # No user preference state was changed.
    try:
        _ORIGINAL_PREFERENCE_STATE.clear()
    except Exception:
        pass
    return None


def _prefer_native_gizmo_press() -> int:
    # Blender/user keyconfig preferences are foreign and remain unchanged.
    return False


def _patch_existing_native_gizmo_keymaps() -> int:
    """Native/user gizmo keymaps are foreign and must remain unchanged."""
    return 0


def _patch_existing_uv_fallback_keymaps() -> int:
    """Existing matching rows are foreign unless present in our exact ledger."""
    return 0


def _track_keymap_item(keymap, kmi) -> None:
    item = (keymap, kmi)
    if item not in _REGISTERED_KEYMAP_ITEMS:
        _REGISTERED_KEYMAP_ITEMS.append(item)
    try:
        from . import ownership_runtime_18168 as _own
        _own.track_keymap_item(keymap, kmi, getattr(kmi, 'idname', _OPERATOR_IDNAME))
    except Exception:
        pass


def _ensure_addon_keymap_item(keyconfig, keymap_name: str, space_type: str, idname: str, *, allow_modifiers: bool) -> int:
    try:
        keymap = keyconfig.keymaps.get(keymap_name)
        if keymap is None:
            keymap = keyconfig.keymaps.new(name=keymap_name, space_type=space_type, region_type='WINDOW')
        existing = _find_addon_keymap_item(keymap, idname, 'LEFTMOUSE', 'PRESS', allow_modifiers=allow_modifiers)
        if existing is not None:
            _store_keymap_original(existing)
            if idname == _OPERATOR_IDNAME:
                try:
                    __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(keymap, existing)
                    existing = None
                except Exception:
                    pass
            if existing is not None:
                _track_keymap_item(keymap, existing)
                return 0
        kmi = _keymap_items_new(keymap, idname, 'LEFTMOUSE', 'PRESS', head=True)
        _configure_left_press_item(kmi, allow_modifiers=allow_modifiers)
        _track_keymap_item(keymap, kmi)
        return 1
    except Exception as exc:
        _log(f'Failed to add keymap item {keymap_name} {idname}: {exc}')
        return 0


def _register_keymaps() -> tuple[int, int]:
    keyconfig = bpy.context.window_manager.keyconfigs.addon
    if keyconfig is None:
        return 0, 0
    native_count = 0
    uv_guard_count = 0
    for keymap_name in _NATIVE_GIZMO_KEYMAP_NAMES:
        native_count += _ensure_addon_keymap_item(keyconfig, keymap_name, 'EMPTY', _NATIVE_GIZMO_OPERATOR_ID, allow_modifiers=True)
        # Put Smart UV's narrow fallback before native gizmo tweak in the same
        # gizmo keymaps.  It passes through unless the actual selected-pivot or
        # visible handle zone is hit, but it prevents Blender's 2D-cursor-pivot
        # + grid snap path from recentering the UV selection at transform start.
        uv_guard_count += _ensure_addon_keymap_item(keyconfig, keymap_name, 'EMPTY', _OPERATOR_IDNAME, allow_modifiers=False)
    uv_guard_count += _ensure_addon_keymap_item(keyconfig, 'Image', 'IMAGE_EDITOR', _OPERATOR_IDNAME, allow_modifiers=False)
    return native_count, uv_guard_count


def _unregister_keymaps() -> None:
    return None


def _load_post_reapply(_dummy=None):
    if not is_enabled():
        cancel_deferred_reapply()
        return None
    try:
        return _deferred_reapply_timer()
    except Exception:
        return None


def _deferred_reapply_timer():
    return None


def enable() -> None:
    return None


def disable() -> None:
    return None


def set_enabled(value: bool) -> None:
    if bool(value):
        enable()
    else:
        disable()


def is_enabled() -> bool:
    return bool(_ENABLED)


class SMARTUVSUITE_OT_uv_gizmo_grip_fix_toggle(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.uv_gizmo_grip_fix_toggle'
    bl_label = 'UV Gizmo Grip Fix Toggle'
    bl_description = 'Enable or disable the integrated UV gizmo grip fix. / 統合UVギズモつかみ補助を有効または無効にします。'
    bl_options = set()

    def execute(self, context):
        value = bool(getattr(self, 'enabled', True))
        try:
            ws = getattr(getattr(context, 'scene', None), 'suv_workspace', None)
            if ws is not None and hasattr(ws, 'operation_uv_gizmo_grip_fix_enabled'):
                ws.operation_uv_gizmo_grip_fix_enabled = value
                return {'FINISHED'}
        except Exception:
            pass
        set_enabled(value)
        return {'FINISHED'}


try:
    SMARTUVSUITE_OT_uv_gizmo_grip_fix_toggle.__annotations__ = {
        'enabled': bpy.props.BoolProperty(name='Enabled', default=True),
    }
except Exception:
    pass

_CLASSES = (JELARARAGI_OT_uv_gizmo_grip_fix_grab, JELARARAGI_OT_uv_gizmo_grip_fix_apply, SMARTUVSUITE_OT_uv_gizmo_grip_fix_toggle)


def _suv_stage_002_register() -> None:
    return None
    # Do not enable keymaps or deferred timers on add-on install. The user toggle
    # controls runtime activation.


def _suv_stage_002_unregister() -> None:
    return None


# -----------------------------------------------------------------------------
# Smart UV Suite integration patch: reliable UV snap for gizmo fallback
# -----------------------------------------------------------------------------
# Keep this module self-contained.  The fallback gizmo transform now evaluates
# UV/grid snap at modal time and snaps only the translation delta, never the
# selected UV origin, so UV Select Sync ON/OFF behave the same.

def _uv_increment_snap_active(context) -> bool:
    try:
        ts = getattr(getattr(context, "scene", None), "tool_settings", None)
        if ts is None:
            return False
        if not bool(getattr(ts, "use_snap_uv", False) or getattr(ts, "use_snap", False)):
            return False
        if hasattr(ts, "use_snap_translate") and not bool(getattr(ts, "use_snap_translate", True)):
            return False
        elements = set()
        for name in ("snap_uv_element", "snap_elements", "snap_elements_base"):
            try:
                raw = getattr(ts, name, None)
                if isinstance(raw, (set, list, tuple)):
                    elements.update(str(v).upper() for v in raw)
                elif raw:
                    elements.add(str(raw).upper())
            except Exception:
                pass
        if not elements:
            return True
        return any(v in elements for v in {"INCREMENT", "GRID", "GRID_INCREMENT"})
    except Exception:
        return False


def _uv_nice_grid_step(value: float) -> float:
    try:
        import math
        value = abs(float(value))
        if value <= 1.0e-12:
            return 1.0
        exp = math.floor(math.log10(value))
        base = 10.0 ** exp
        frac = value / base
        if frac <= 1.5:
            nice = 1.0
        elif frac <= 3.5:
            nice = 2.0
        elif frac <= 7.5:
            nice = 5.0
        else:
            nice = 10.0
        return max(nice * base, 1.0e-9)
    except Exception:
        return 1.0


def _uv_grid_step(context) -> Vector:
    step_u = 1.0
    step_v = 1.0
    try:
        space = getattr(context, "space_data", None)
        uv_editor = getattr(space, "uv_editor", None) if space is not None else None
        source = str(getattr(uv_editor, "grid_shape_source", "") or "").upper() if uv_editor is not None else ""
        if source == "PIXEL":
            image = getattr(space, "image", None) if space is not None else None
            size = getattr(image, "size", None) if image is not None else None
            if size and int(size[0]) > 0 and int(size[1]) > 0:
                return Vector((1.0 / float(size[0]), 1.0 / float(size[1])))
        if uv_editor is not None and source not in {"DYNAMIC", "PIXEL"}:
            raw = getattr(uv_editor, "custom_grid_subdivisions", None)
            if raw is not None:
                if isinstance(raw, (tuple, list)) and len(raw) >= 2:
                    su = max(int(raw[0]), 1)
                    sv = max(int(raw[1]), 1)
                else:
                    su = sv = max(int(raw), 1)
                return Vector((1.0 / float(su), 1.0 / float(sv)))
    except Exception:
        pass
    try:
        region = getattr(context, "region", None)
        v2d = getattr(region, "view2d", None)
        if v2d is not None:
            x = max(int(getattr(region, "width", 1024) or 1024) // 2, 1)
            y = max(int(getattr(region, "height", 768) or 768) // 2, 1)
            center = v2d.region_to_view(float(x), float(y))
            offset = v2d.region_to_view(float(x + 64), float(y + 64))
            step_u = _uv_nice_grid_step(abs(float(offset[0] - center[0])))
            step_v = _uv_nice_grid_step(abs(float(offset[1] - center[1])))
    except Exception:
        pass
    return Vector((max(float(step_u), 1.0e-9), max(float(step_v), 1.0e-9)))


def _snap_uv_delta_relative_to_cursor(context, delta: Vector) -> Vector:
    try:
        if not _uv_increment_snap_active(context):
            return delta
        step = _uv_grid_step(context)
        du = round(float(delta.x) / float(step.x)) * float(step.x) if float(step.x) > 0.0 else float(delta.x)
        dv = round(float(delta.y) / float(step.y)) * float(step.y) if float(step.y) > 0.0 else float(delta.y)
        return Vector((du, dv))
    except Exception:
        return delta

# -----------------------------------------------------------------------------
# Smart UV Suite 1.8.20 reliable UV gizmo snap fallback
# -----------------------------------------------------------------------------
# This local fallback is used if the package-level patch is not loaded yet.

def _uv_grid_subdivisions_from_editor(context):
    try:
        space = getattr(context, "space_data", None)
        uv_editor = getattr(space, "uv_editor", None) if space is not None else None
        raw = getattr(uv_editor, "custom_grid_subdivisions", None) if uv_editor is not None else None
        if raw is None:
            return 10, 10
        if isinstance(raw, (tuple, list)) and len(raw) >= 2:
            return max(int(raw[0]), 1), max(int(raw[1]), 1)
        v = max(int(raw), 1)
        return v, v
    except Exception:
        return 10, 10


def _uv_grid_step(context) -> Vector:
    try:
        space = getattr(context, "space_data", None)
        uv_editor = getattr(space, "uv_editor", None) if space is not None else None
        source = str(getattr(uv_editor, "grid_shape_source", "") or "").upper() if uv_editor is not None else ""
        su, sv = _uv_grid_subdivisions_from_editor(context)
        if source == "PIXEL":
            image = getattr(space, "image", None) if space is not None else None
            size = getattr(image, "size", None) if image is not None else None
            if size and int(size[0]) > 0 and int(size[1]) > 0:
                return Vector((1.0 / float(size[0]), 1.0 / float(size[1])))
        if source == "DYNAMIC" or source == "PIXEL" or not source:
            try:
                region = getattr(context, "region", None)
                v2d = getattr(region, "view2d", None)
                if v2d is not None:
                    x = max(int(getattr(region, "width", 1024) or 1024) // 2, 1)
                    y = max(int(getattr(region, "height", 768) or 768) // 2, 1)
                    c = v2d.region_to_view(float(x), float(y))
                    p = v2d.region_to_view(float(x + 64), float(y + 64))
                    major_u = _uv_nice_grid_step(abs(float(p[0] - c[0])))
                    major_v = _uv_nice_grid_step(abs(float(p[1] - c[1])))
                    return Vector((max(major_u / float(su), 1.0e-9), max(major_v / float(sv), 1.0e-9)))
            except Exception:
                pass
        return Vector((1.0 / float(su), 1.0 / float(sv)))
    except Exception:
        return Vector((1.0, 1.0))


def _snap_uv_delta_relative_to_cursor(context, delta: Vector) -> Vector:
    try:
        if not _uv_increment_snap_active(context):
            return delta
        step = _uv_grid_step(context)
        du = round(float(delta.x) / float(step.x)) * float(step.x) if float(step.x) > 0.0 else float(delta.x)
        dv = round(float(delta.y) / float(step.y)) * float(step.y) if float(step.y) > 0.0 else float(delta.y)
        return Vector((du, dv))
    except Exception:
        return delta

# -----------------------------------------------------------------------------
# Smart UV Suite 1.8.35 crash-safe selection-scoped gizmo patch
# -----------------------------------------------------------------------------
# This final integration patch deliberately avoids launching Blender's native
# transform operator from the grip fallback.  It also never expands vertex/edge
# selections to whole islands unless UV island/face selection flags are actually
# the active selection domain.

_SUS_1835_KEYMAP_NAMES = (
    ("Image", "IMAGE_EDITOR"),
    ("UV Editor", "EMPTY"),
    ("Generic Gizmo", "EMPTY"),
    ("Generic Gizmo Maybe Drag", "EMPTY"),
)


def _sus_1835_uv_mode(context) -> str:
    try:
        raw = getattr(getattr(context, "tool_settings", None), "uv_select_mode", "VERTEX")
        if isinstance(raw, (set, list, tuple)):
            raw = " ".join(str(v) for v in raw)
        value = str(raw or "VERTEX").upper()
    except Exception:
        value = "VERTEX"
    if "ISLAND" in value:
        return "ISLAND"
    if "FACE" in value:
        return "FACE"
    if "EDGE" in value:
        return "EDGE"
    return "VERTEX"


def _sus_1835_luv(loop, uv_layer):
    try:
        return loop[uv_layer]
    except Exception:
        return None


def _sus_1835_get_v(loop, uv_layer) -> bool:
    try:
        if bool(getattr(loop, "uv_select_vert", False)):
            return True
    except Exception:
        pass
    luv = _sus_1835_luv(loop, uv_layer)
    if luv is not None:
        for name in ("select_vert", "select"):
            try:
                if bool(getattr(luv, name, False)):
                    return True
            except Exception:
                pass
    return False


def _sus_1835_get_e(loop, uv_layer) -> bool:
    try:
        if bool(getattr(loop, "uv_select_edge", False)):
            return True
    except Exception:
        pass
    luv = _sus_1835_luv(loop, uv_layer)
    if luv is not None:
        for name in ("select_edge",):
            try:
                if bool(getattr(luv, name, False)):
                    return True
            except Exception:
                pass
    return False


def _sus_1835_get_f(face) -> bool:
    try:
        if bool(getattr(face, "uv_select", False)):
            return True
    except Exception:
        pass
    return False


def _sus_1835_set_v(loop, uv_layer, value: bool) -> None:
    try:
        setter = getattr(loop, "uv_select_vert_set", None)
        if callable(setter):
            setter(bool(value))
    except Exception:
        pass
    luv = _sus_1835_luv(loop, uv_layer)
    if luv is not None:
        for name in ("select_vert", "select"):
            try:
                setattr(luv, name, bool(value))
            except Exception:
                pass


def _sus_1835_set_e(loop, uv_layer, value: bool) -> None:
    try:
        setter = getattr(loop, "uv_select_edge_set", None)
        if callable(setter):
            setter(bool(value))
    except Exception:
        pass
    luv = _sus_1835_luv(loop, uv_layer)
    if luv is not None:
        try:
            setattr(luv, "select_edge", bool(value))
        except Exception:
            pass


def _sus_1835_set_f(face, value: bool) -> None:
    try:
        setter = getattr(face, "uv_select_set", None)
        if callable(setter):
            setter(bool(value))
            return
    except Exception:
        pass
    try:
        setattr(face, "uv_select", bool(value))
    except Exception:
        pass


def _sus_1835_face_index(face) -> int:
    try:
        return int(getattr(face, "index", -1))
    except Exception:
        return -1


def _sus_1835_local_loop_index(face, loop) -> int:
    try:
        return list(face.loops).index(loop)
    except Exception:
        return -1


def _sus_1835_uv_close(a, b, eps=1.0e-7) -> bool:
    try:
        return abs(float(a.x) - float(b.x)) <= eps and abs(float(a.y) - float(b.y)) <= eps
    except Exception:
        return False


def _sus_1835_segment_close(a0, a1, b0, b1, eps=1.0e-7) -> bool:
    return (_sus_1835_uv_close(a0, b0, eps) and _sus_1835_uv_close(a1, b1, eps)) or (_sus_1835_uv_close(a0, b1, eps) and _sus_1835_uv_close(a1, b0, eps))


def _sus_1835_add_record(records, seen, face, loop, uv_layer) -> None:
    fi = _sus_1835_face_index(face)
    li = _sus_1835_local_loop_index(face, loop)
    if fi < 0 or li < 0:
        return
    key = (fi, li)
    if key in seen:
        return
    luv = _sus_1835_luv(loop, uv_layer)
    if luv is None:
        return
    try:
        seen.add(key)
        records.append((fi, li, luv.uv.copy()))
    except Exception:
        pass


def _sus_1835_collect_selected_uv_state(context, anchor_uv: Optional[Vector] = None):
    mode = _sus_1835_uv_mode(context)
    batches = []
    total = 0
    sum_uv = Vector((0.0, 0.0))
    min_uv = Vector((float("inf"), float("inf")))
    max_uv = Vector((float("-inf"), float("-inf")))

    for obj in _iter_edit_mesh_objects(context):
        mesh = getattr(obj, "data", None)
        if mesh is None:
            continue
        try:
            bm = bmesh.from_edit_mesh(mesh)
            bm.faces.ensure_lookup_table(); bm.faces.index_update()
            bm.edges.ensure_lookup_table(); bm.edges.index_update()
            bm.verts.ensure_lookup_table(); bm.verts.index_update()
        except Exception:
            continue
        uv_layer = bm.loops.layers.uv.active
        if uv_layer is None:
            continue
        records = []
        seen = set()
        uv_name = _uv_layer_name(uv_layer)

        if mode == "VERTEX":
            seeds = []
            for f in bm.faces:
                if _bool_attr(f, "hide"):
                    continue
                for l in f.loops:
                    if _is_loop_visible(l, f) and _sus_1835_get_v(l, uv_layer):
                        seeds.append((l.vert, l[uv_layer].uv.copy()))
            # A visual UV vertex may be represented by several loops.  Include only
            # loops sharing both the mesh vertex and the same UV position, so split
            # UVs on the same mesh vertex never move together unintentionally.
            for f in bm.faces:
                if _bool_attr(f, "hide"):
                    continue
                for l in f.loops:
                    if not _is_loop_visible(l, f):
                        continue
                    luv = _sus_1835_luv(l, uv_layer)
                    if luv is None:
                        continue
                    for v, uv in seeds:
                        if l.vert == v and _sus_1835_uv_close(luv.uv, uv):
                            _sus_1835_add_record(records, seen, f, l, uv_layer)
                            break

        elif mode == "EDGE":
            seeds = []
            for f in bm.faces:
                if _bool_attr(f, "hide"):
                    continue
                for l in f.loops:
                    if _is_loop_visible(l, f) and _sus_1835_get_e(l, uv_layer):
                        try:
                            seeds.append((l.edge, l[uv_layer].uv.copy(), l.link_loop_next[uv_layer].uv.copy()))
                        except Exception:
                            pass
            for f in bm.faces:
                if _bool_attr(f, "hide"):
                    continue
                for l in f.loops:
                    if not _is_loop_visible(l, f):
                        continue
                    try:
                        a = l[uv_layer].uv; b = l.link_loop_next[uv_layer].uv
                    except Exception:
                        continue
                    for edge, s0, s1 in seeds:
                        # Prefer the actual BMesh edge; the UV segment check keeps
                        # split/staked edges from being merged into one transform target.
                        if l.edge == edge and _sus_1835_segment_close(a, b, s0, s1):
                            _sus_1835_add_record(records, seen, f, l, uv_layer)
                            _sus_1835_add_record(records, seen, f, l.link_loop_next, uv_layer)
                            break

        else:  # FACE / ISLAND: only UV-face-selected faces, never stale vertex/edge flags.
            for f in bm.faces:
                if _bool_attr(f, "hide") or not _sus_1835_get_f(f):
                    continue
                for l in f.loops:
                    if _is_loop_visible(l, f):
                        _sus_1835_add_record(records, seen, f, l, uv_layer)

        if not records:
            continue
        batches.append({"mesh": mesh, "uv_layer_name": uv_name, "loops": records})
        for _fi, _li, uv in records:
            sum_uv += uv
            min_uv.x = min(min_uv.x, uv.x); min_uv.y = min(min_uv.y, uv.y)
            max_uv.x = max(max_uv.x, uv.x); max_uv.y = max(max_uv.y, uv.y)
            total += 1

    if total <= 0:
        return [], None
    stats = {"median": sum_uv / total, "bbox_center": Vector(((min_uv.x + max_uv.x) * 0.5, (min_uv.y + max_uv.y) * 0.5)), "count": total}
    return batches, stats


def _sus_1835_apply_to_uvs(self, context, transform_func) -> None:
    changed_meshes = []
    for batch in getattr(self, "_batches", []) or []:
        mesh = batch.get("mesh")
        if mesh is None:
            continue
        try:
            bm = bmesh.from_edit_mesh(mesh)
            bm.faces.ensure_lookup_table()
        except Exception:
            continue
        uv_layer = _resolve_uv_layer(bm, batch.get("uv_layer_name", ""))
        if uv_layer is None:
            continue
        changed = False
        for face_index, loop_index, original_uv in batch.get("loops", []) or []:
            try:
                face = bm.faces[int(face_index)]
                loops = list(face.loops)
                li = int(loop_index)
                if li < 0 or li >= len(loops):
                    continue
                loops[li][uv_layer].uv = transform_func(original_uv)
                changed = True
            except Exception:
                continue
        if changed:
            changed_meshes.append(mesh)
    for mesh in changed_meshes:
        try:
            bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        except TypeError:
            try:
                bmesh.update_edit_mesh(mesh)
            except Exception:
                pass
        except Exception:
            pass
    try:
        self._tag_redraw(context)
    except Exception:
        pass


def _sus_1835_gizmo_invoke(self, context, event):
    # 1.8.229: an exception escaping the final invoke authority must never
    # reach Blender — it would leak the modal barrier entry exactly like an
    # escaped modal exception did.
    try:
        return _sus_1835_gizmo_invoke_guarded(self, context, event)
    except Exception as exc:
        _log(f"gizmo invoke failed safely and was cancelled: {exc}")
        _sus_18224_modal_end(self)
        return {"CANCELLED"}


def _sus_1835_gizmo_invoke_guarded(self, context, event):
    if event.type != "LEFTMOUSE" or event.value != "PRESS":
        _sus_18224_mark_invoke("pass:event")
        return {"PASS_THROUGH"}
    if _event_has_selection_modifier(event):
        _sus_18224_mark_invoke("pass:selection_modifier")
        return {"PASS_THROUGH"}
    if not is_enabled():
        _sus_18224_mark_invoke("pass:disabled")
        return {"PASS_THROUGH"}
    if not _is_uv_editor_context(context) or not hasattr(context.region, "view2d"):
        _sus_18224_mark_invoke("pass:context")
        return {"PASS_THROUGH"}
    try:
        press_uv = _region_to_view(context.region, event.mouse_region_x, event.mouse_region_y)
    except Exception:
        press_uv = None
    batches, stats = _collect_selected_uv_state(context, anchor_uv=press_uv)
    if not batches or not stats:
        _sus_18224_mark_invoke("pass:no_batch")
        return {"PASS_THROUGH"}
    pivot_uv = _selected_uv_pivot(context, stats)
    if pivot_uv is None:
        _sus_18224_mark_invoke("pass:no_pivot")
        return {"PASS_THROUGH"}
    pivot_region = _view_to_region(context.region, pivot_uv)
    mode = _hit_test_fallback_area(context, event, pivot_region)
    if mode is None:
        _sus_18224_mark_invoke("pass:no_hit")
        return {"PASS_THROUGH"}
    self._area = context.area
    self._region = context.region
    self._batches = batches
    self._pivot_uv = pivot_uv
    self._mode = mode
    self._sus18229_moved = False
    self._start_mouse_view = _region_to_view(self._region, event.mouse_region_x, event.mouse_region_y)
    self._start_vector = self._start_mouse_view - self._pivot_uv
    context.window_manager.modal_handler_add(self)
    _sus_18224_modal_begin(self)
    _sus_18224_mark_invoke("running")
    return {"RUNNING_MODAL"}


def _sus_1835_register_keymaps() -> tuple[int, int]:
    keyconfig = bpy.context.window_manager.keyconfigs.addon
    if keyconfig is None:
        return 0, 0
    created = 0
    for name, space in _SUS_1835_KEYMAP_NAMES:
        created += _ensure_addon_keymap_item(keyconfig, name, space, _OPERATOR_IDNAME, allow_modifiers=False)
    return 0, created


def _sus_1835_enable() -> None:
    global _ENABLED
    _ENABLED = True
    # Do not mutate Blender's native gizmo keymaps or keyconfig preferences here.
    # The fallback operator is narrow and consumes only actual UV gizmo handles.
    _sus_1835_register_keymaps()
    _log("enabled crash-safe direct UV gizmo fallback")


def _sus_1835_disable() -> None:
    global _ENABLED
    _ENABLED = False
    _unregister_keymaps()
    _restore_existing_keymaps()
    _restore_preferences()
    _log("disabled crash-safe direct UV gizmo fallback")


def _sus_1835_apply_patch() -> None:
    global _collect_selected_uv_state, enable, disable, set_enabled
    _collect_selected_uv_state = _sus_1835_collect_selected_uv_state
    enable = _sus_1835_enable
    disable = _sus_1835_disable
    set_enabled = lambda value: _sus_1835_enable() if bool(value) else _sus_1835_disable()
    try:
        JELARARAGI_OT_uv_gizmo_grip_fix_grab.invoke = _sus_1835_gizmo_invoke
        JELARARAGI_OT_uv_gizmo_grip_fix_grab._apply_to_uvs = _sus_1835_apply_to_uvs
    except Exception:
        pass


_sus_1835_apply_patch()

# Smart UV Suite 1.8.35b: no add-on native gizmo_tweak rows.
# The direct fallback handles actual UV gizmo handles itself; native Blender
# keymaps remain untouched in the default/user keyconfig.
_NATIVE_GIZMO_KEYMAP_NAMES = ()

# -----------------------------------------------------------------------------
# Smart UV Suite 1.8.169 authoritative exact lifecycle
# -----------------------------------------------------------------------------
from . import ownership_runtime_18168 as _sus_ownership

_SUS_18168_ENABLED = False
_SUS_18168_CLASSES = []
_SUS_18168_KEYMAP_ITEMS = []
_SUS_18224_SENTINEL_KEYMAP_ITEMS = []
_SUS_18224_PRIMER_KEYMAP_ITEMS = []
_SUS_18168_DEFERRED = None
_SUS_18168_DEFERRED_RUNS = 0
_SUS_1835_KEYMAP_NAMES = ()


def _sus_18168_kmi_pointer(kmi):
    try:
        pointer = int(kmi.as_pointer())
    except Exception as exc:
        raise RuntimeError("Smart UV gizmo keymap row has no stable RNA pointer") from exc
    if not pointer:
        raise RuntimeError("Smart UV gizmo keymap row has a null RNA pointer")
    return pointer


def _sus_18168_find_kmi_by_pointer(keymap, pointer):
    try:
        for item in tuple(getattr(keymap, "keymap_items", ()) or ()):
            try:
                if int(item.as_pointer()) == int(pointer):
                    return item
            except Exception:
                continue
    except Exception:
        pass
    return None


def _sus_18201_move_kmi_to_head(keymap, pointer) -> None:
    """Best-effort priority promotion without using Blender 5.1 head kwargs."""
    try:
        items = getattr(keymap, "keymap_items", None)
        move = getattr(items, "move", None)
        if not callable(move):
            return
        rows = tuple(items or ())
        live = _sus_18168_find_kmi_by_pointer(keymap, pointer)
        if live is None:
            return
        index = -1
        for i, row in enumerate(rows):
            try:
                if int(row.as_pointer()) == int(pointer):
                    index = i
                    break
            except Exception:
                continue
        if index <= 0:
            return
        try:
            move(index, 0)
            return
        except TypeError:
            pass
        except Exception:
            return
        try:
            move(live, 0)
        except Exception:
            return
    except Exception:
        return


def _sus_18168_raw_remove(keymap, kmi) -> bool:
    """Remove one own row and report whether the row is gone.

    The callers below count removals.  Returning ``None`` made every raw
    removal count as zero, so ``removed`` totals reported by the disable path
    understated the real cleanup.
    """
    try:
        pointer = _sus_18168_kmi_pointer(kmi)
    except Exception:
        pointer = None
    live = _sus_18168_find_kmi_by_pointer(keymap, pointer) if pointer else kmi
    if live is None:
        return False
    try:
        getattr(keymap, "keymap_items").remove(live)
    except ReferenceError:
        return True
    return True


def _sus_18168_signature(kmi):
    return {
        "type": str(getattr(kmi, "type", "") or ""),
        "value": str(getattr(kmi, "value", "") or ""),
        "shift": bool(getattr(kmi, "shift", False)),
        "ctrl": bool(getattr(kmi, "ctrl", False)),
        "alt": bool(getattr(kmi, "alt", False)),
        "oskey": bool(getattr(kmi, "oskey", False)),
        "any": bool(getattr(kmi, "any", False)),
        "active": bool(getattr(kmi, "active", False)),
    }


def _sus_18168_expected_signature():
    return {
        "type": "LEFTMOUSE",
        "value": "PRESS",
        "shift": False,
        "ctrl": False,
        "alt": True,
        "oskey": False,
        "any": False,
        "active": True,
    }


def _sus_18168_configure_exact(kmi) -> None:
    expected = _sus_18168_expected_signature()
    # Blender 5.1 clears modifier flags when ``any`` is written after them.
    # The event type/value are already fixed by native keymap_items.new().
    for name, value in (
        ("any", False),
        ("shift", False),
        ("ctrl", False),
        ("alt", True),
        ("oskey", False),
        ("active", True),
    ):
        try:
            setattr(kmi, name, value)
        except Exception as exc:
            raise RuntimeError(f"Smart UV gizmo keymap RNA write failed: {name}") from exc
    actual = _sus_18168_signature(kmi)
    if actual != expected:
        raise RuntimeError(f"Smart UV gizmo keymap RNA readback mismatch: {actual!r} != {expected!r}")


def _sus_18168_existing_exact_rows():
    exact = []
    for keymap, pointer in tuple(_SUS_18168_KEYMAP_ITEMS):
        try:
            if not isinstance(pointer, int):
                pointer = _sus_18168_kmi_pointer(pointer)
            kmi = _sus_18168_find_kmi_by_pointer(keymap, pointer)
            if kmi is None:
                continue
            if (
                str(getattr(keymap, "name", "") or "") == "Image Generic"
                and _sus_18168_signature(kmi) == _sus_18168_expected_signature()
            ):
                exact.append((keymap, kmi))
        except Exception:
            pass
    return tuple(exact)


def _sus_18224_configure_sentinel(kmi) -> None:
    for name, value in (
        ("any", False),
        ("shift", False),
        ("ctrl", False),
        ("alt", False),
        ("oskey", False),
        ("active", True),
    ):
        try:
            setattr(kmi, name, value)
        except Exception as exc:
            raise RuntimeError(f"Smart UV gizmo sentinel keymap RNA write failed: {name}") from exc


def _sus_18224_remove_sentinel_rows() -> int:
    removed = 0
    for keymap, kmi in reversed(tuple(_SUS_18224_SENTINEL_KEYMAP_ITEMS)):
        try:
            if _sus_ownership.remove_keymap_item(keymap, kmi):
                removed += 1
        except Exception:
            pass
    _SUS_18224_SENTINEL_KEYMAP_ITEMS.clear()
    try:
        removed += int(_sus_ownership.remove_owned_keymaps(JELARARAGI_OT_uv_gizmo_grip_fix_sentinel.bl_idname) or 0)
    except Exception:
        pass
    return removed


def _sus_18224_remove_primer_rows() -> int:
    removed = 0
    for keymap, pointer in reversed(tuple(_SUS_18224_PRIMER_KEYMAP_ITEMS)):
        try:
            if not isinstance(pointer, int):
                pointer = _sus_18168_kmi_pointer(pointer)
            kmi = _sus_18168_find_kmi_by_pointer(keymap, pointer)
            if kmi is not None and _sus_18168_raw_remove(keymap, kmi):
                removed += 1
        except Exception:
            pass
    _SUS_18224_PRIMER_KEYMAP_ITEMS.clear()
    return removed


def _sus_18224_remove_all_product_rows() -> int:
    # 18227: drop the ledger records for this operator id first.  Only rows this
    # add-on created and recorded carry a record, so the generation ledger never
    # reaches a foreign row, and the exact native remover captured at creation is
    # used.  Without this the ledger kept stale records for rows removed raw, and
    # a re-created product row was never ledger-owned at all.
    removed = 0
    try:
        removed += int(
            _sus_ownership.remove_owned_keymaps(JELARARAGI_OT_uv_gizmo_grip_fix_grab.bl_idname) or 0
        )
    except Exception:
        pass
    try:
        keyconfig = _sus_18168_keyconfig()
        keymaps = getattr(keyconfig, "keymaps", None)
        keymap = keymaps.get("Image Generic") if keymaps is not None else None
        items = getattr(keymap, "keymap_items", None)
        if keymap is None or items is None:
            _SUS_18168_KEYMAP_ITEMS.clear()
            _SUS_18224_PRIMER_KEYMAP_ITEMS.clear()
            return removed
        for kmi in reversed(tuple(items)):
            try:
                if str(getattr(kmi, "idname", "") or "") == JELARARAGI_OT_uv_gizmo_grip_fix_grab.bl_idname:
                    try:
                        kmi.active = False
                    except Exception:
                        pass
                    if _sus_18168_raw_remove(keymap, kmi):
                        removed += 1
            except Exception:
                pass
    except Exception:
        pass
    _SUS_18168_KEYMAP_ITEMS.clear()
    _SUS_18224_PRIMER_KEYMAP_ITEMS.clear()
    return removed


def _sus_18224_create_sentinel_row(keymap):
    items = getattr(keymap, "keymap_items", None)
    native_new = getattr(items, "new", None)
    if not callable(native_new):
        raise RuntimeError("stage=create map=Image Generic sentinel: keymap_items.new unavailable")
    sentinel = native_new(JELARARAGI_OT_uv_gizmo_grip_fix_sentinel.bl_idname, "RIGHTMOUSE", "PRESS")
    _sus_18224_configure_sentinel(sentinel)
    _sus_ownership.track_keymap_item(keymap, sentinel, JELARARAGI_OT_uv_gizmo_grip_fix_sentinel.bl_idname)
    _SUS_18224_SENTINEL_KEYMAP_ITEMS[:] = [(keymap, sentinel)]
    return sentinel


def _sus_18168_keyconfig():
    try:
        wm = getattr(bpy.context, "window_manager", None)
        return getattr(getattr(wm, "keyconfigs", None), "addon", None)
    except Exception:
        return None


def _sus_18182_actual_gizmo_rows():
    return _sus_18168_existing_exact_rows()


def _sus_18182_remove_actual_gizmo_rows() -> int:
    removed = 0
    # 18227: retire the generation-ledger record for this exact operator id as
    # well, so no removal path can leave a ledger record without a live row or a
    # live row without a ledger record.  Foreign rows carry no record and are
    # never reached.
    try:
        removed += int(
            _sus_ownership.remove_owned_keymaps(JELARARAGI_OT_uv_gizmo_grip_fix_grab.bl_idname) or 0
        )
    except Exception:
        pass
    for keymap, pointer in reversed(tuple(_SUS_18168_KEYMAP_ITEMS)):
        try:
            if not isinstance(pointer, int):
                pointer = _sus_18168_kmi_pointer(pointer)
            kmi = _sus_18168_find_kmi_by_pointer(keymap, pointer)
            if kmi is None:
                continue
            if _sus_18168_raw_remove(keymap, kmi):
                removed += 1
        except Exception:
            pass
    _SUS_18168_KEYMAP_ITEMS.clear()
    return removed


def _sus_18168_register_keymap(*, _schedule_refresh: bool = True) -> None:
    # The final contract is exactly one ledger-owned Image Generic Alt+LEFTMOUSE
    # row. Do not scan unowned addon keymaps here: stale native keymap RNA can be
    # invalid during package upgrades/register failure cleanup, and foreign rows
    # are outside this resource authority.
    keyconfig = _sus_18168_keyconfig()
    if keyconfig is None:
        raise RuntimeError("stage=create map=Image Generic modifier=Alt: addon keyconfig unavailable")
    created = []
    try:
        previous_rows = tuple(_SUS_18168_KEYMAP_ITEMS)
        keymap = keyconfig.keymaps.get("Image Generic")
        if keymap is None:
            keymap = keyconfig.keymaps.new(name="Image Generic", space_type="IMAGE_EDITOR", region_type="WINDOW")
        if keymap is None:
            raise RuntimeError("stage=create map=Image Generic modifier=Alt: keymap unavailable")
        items = getattr(keymap, "keymap_items", None)
        native_new = getattr(items, "new", None)
        if not callable(native_new):
            raise RuntimeError("stage=create map=Image Generic modifier=Alt: keymap_items.new unavailable")
        _sus_18224_remove_sentinel_rows()
        _sus_18224_remove_primer_rows()
        _sus_18224_remove_all_product_rows()
        sentinel = _sus_18224_create_sentinel_row(keymap)
        created.append((keymap, sentinel))
        primer = native_new(JELARARAGI_OT_uv_gizmo_grip_fix_grab.bl_idname, "LEFTMOUSE", "PRESS")
        _sus_18168_configure_exact(primer)
        try:
            primer.active = False
        except Exception:
            pass
        primer_pointer = _sus_18168_kmi_pointer(primer)
        _SUS_18224_PRIMER_KEYMAP_ITEMS[:] = [(keymap, primer_pointer)]
        created.append((keymap, primer))
        warmup = native_new(JELARARAGI_OT_uv_gizmo_grip_fix_grab.bl_idname, "LEFTMOUSE", "PRESS")
        _sus_18168_configure_exact(warmup)
        warmup_pointer = _sus_18168_kmi_pointer(warmup)
        created.append((keymap, warmup))
        kmi = native_new(JELARARAGI_OT_uv_gizmo_grip_fix_grab.bl_idname, "LEFTMOUSE", "PRESS")
        pointer = _sus_18168_kmi_pointer(kmi)
        created.append((keymap, kmi))
        _sus_18168_configure_exact(kmi)
        try:
            warmup.active = False
        except Exception:
            pass
        if _sus_18168_find_kmi_by_pointer(keymap, warmup_pointer) is None:
            raise RuntimeError("stage=warmup map=Image Generic modifier=Alt: warmup row disappeared")
        live = _sus_18168_find_kmi_by_pointer(keymap, pointer)
        if live is None:
            raise RuntimeError("stage=readback map=Image Generic modifier=Alt: collection readback missing")
        if _sus_18168_kmi_pointer(live) != pointer:
            raise RuntimeError("stage=readback map=Image Generic modifier=Alt: collection readback pointer mismatch")
        if _sus_18168_signature(live) != _sus_18168_expected_signature():
            raise RuntimeError("stage=readback map=Image Generic modifier=Alt: collection readback mismatch")
        # Blender 5.1 dispatches this Image Generic addon row only when the
        # freshly-created row keeps its native append position.  Moving the
        # row to index 0 leaves an apparently valid KMI in the RNA collection
        # but it is bypassed by real event dispatch.
        live = _sus_18168_find_kmi_by_pointer(keymap, pointer)
        if live is None:
            raise RuntimeError("stage=priority map=Image Generic modifier=Alt: collection readback missing")
        if _sus_18168_signature(live) != _sus_18168_expected_signature():
            raise RuntimeError("stage=priority map=Image Generic modifier=Alt: collection readback mismatch")
        for old_keymap, old_pointer in previous_rows:
            try:
                if not isinstance(old_pointer, int):
                    old_pointer = _sus_18168_kmi_pointer(old_pointer)
                if old_pointer != pointer:
                    old_kmi = _sus_18168_find_kmi_by_pointer(old_keymap, old_pointer)
                    if old_kmi is not None:
                        _sus_18168_raw_remove(old_keymap, old_kmi)
            except Exception:
                pass
        _SUS_18168_KEYMAP_ITEMS[:] = [(keymap, pointer)]
        # 18227 ownership cleanup: the committed product row is an exact Smart UV
        # resource and must live in the generation ledger, not only in this
        # module list.  ``registration_manifest_18168.unregister_package`` ends
        # with ``ownership.unregister_owned_runtime()``; an untracked row could
        # therefore survive a disable - which is exactly the residue recorded in
        # gizmo_modal_crash_18226_run1 (all ledger-tracked UV G/R/S rows gone,
        # one owned Image Generic Alt+LEFTMOUSE row still active).  The ledger
        # records pointers only, never stamps the KeyMapItem RNA and never moves
        # it, so the native append position that real dispatch depends on is
        # untouched, and only rows created here are ever reachable by teardown.
        _sus_ownership.track_keymap_item(
            keymap, kmi, JELARARAGI_OT_uv_gizmo_grip_fix_grab.bl_idname
        )
        rows = _sus_18168_existing_exact_rows()
        if len(rows) != 1:
            raise RuntimeError(f"stage=commit map=Image Generic modifier=Alt: local identity mismatch {len(rows)}")
        ledger_rows = tuple(
            _sus_ownership.owned_keymap_items(JELARARAGI_OT_uv_gizmo_grip_fix_grab.bl_idname)
        )
        if len(ledger_rows) != 1:
            raise RuntimeError(
                f"stage=commit map=Image Generic modifier=Alt: ledger identity mismatch {len(ledger_rows)}"
            )
        # Publish the committed ledger row into the dispatching keyconfig.  The
        # readbacks above are already finished, so no RNA handle crosses this
        # boundary.
        _sus_18225_commit_keyconfig("gizmo_register")
        if _schedule_refresh:
            _sus_18168_schedule_once()
    except Exception as exc:
        for keymap, kmi in reversed(created):
            try:
                _sus_ownership.remove_keymap_item(keymap, kmi)
            except Exception:
                pass
        for keymap, kmi in reversed(created):
            try:
                _sus_18168_raw_remove(keymap, kmi)
            except Exception:
                pass
        _sus_18182_remove_actual_gizmo_rows()
        _sus_18224_remove_primer_rows()
        _sus_18224_remove_sentinel_rows()
        _SUS_18168_KEYMAP_ITEMS.clear()
        raise RuntimeError("Smart UV gizmo keymap transaction failed") from exc


def _sus_18168_unregister_keymap() -> None:
    for keymap, pointer in reversed(tuple(_SUS_18168_KEYMAP_ITEMS)):
        try:
            if not isinstance(pointer, int):
                pointer = _sus_18168_kmi_pointer(pointer)
            kmi = _sus_18168_find_kmi_by_pointer(keymap, pointer)
            if kmi is None:
                continue
            _sus_18168_raw_remove(keymap, kmi)
        except Exception:
            pass
    _SUS_18168_KEYMAP_ITEMS.clear()
    _sus_18224_remove_primer_rows()
    _sus_18224_remove_sentinel_rows()
    _sus_18224_remove_all_product_rows()
    _sus_18225_commit_keyconfig("gizmo_unregister")


def _sus_18168_apply_execute(self, context):
    del context
    enable()
    try:
        self.report({"INFO"}, "UV Gizmo Grip Fix applied")
    except Exception:
        pass
    return {"FINISHED"}


def _sus_18168_deferred_once():
    global _SUS_18168_DEFERRED, _SUS_18168_DEFERRED_RUNS
    if not _SUS_18168_ENABLED or not _sus_ownership.is_active():
        _SUS_18168_DEFERRED = None
        _SUS_18168_DEFERRED_RUNS = 0
        return None
    _SUS_18168_DEFERRED_RUNS += 1
    # Exact own keymap only; no native keymap, preference or global API changes.
    # One transient keyconfig failure must not abandon the repair sequence:
    # the finite-timer guard would retire the callback on a raise, so contain
    # the rebuild and retry until the existing run cap.
    try:
        _sus_18168_unregister_keymap()
        _sus_18168_register_keymap(_schedule_refresh=False)
    except Exception as exc:
        _log(f"deferred gizmo keymap repair failed; retrying: {exc}")
    if _SUS_18168_DEFERRED_RUNS >= 5:
        _SUS_18168_DEFERRED = None
        _SUS_18168_DEFERRED_RUNS = 0
        return None
    return 0.15


def _sus_18168_schedule_once() -> None:
    global _SUS_18168_DEFERRED, _SUS_18168_DEFERRED_RUNS
    if _SUS_18168_DEFERRED is not None:
        return
    callback = _sus_18168_deferred_once
    _SUS_18168_DEFERRED = callback
    _SUS_18168_DEFERRED_RUNS = 0
    registered = _sus_ownership.register_finite_timer(callback, first_interval=0.05, max_runs=5)
    if registered is None:
        _SUS_18168_DEFERRED = None
        _SUS_18168_DEFERRED_RUNS = 0


def enable() -> None:  # type: ignore[no-redef]
    global _SUS_18168_ENABLED
    _SUS_18168_ENABLED = True
    _sus_18168_register_keymap()
    _sus_18168_schedule_once()


def disable() -> None:  # type: ignore[no-redef]
    global _SUS_18168_ENABLED, _SUS_18168_DEFERRED, _SUS_18168_DEFERRED_RUNS
    global _SUS_18225_DEFERRED_COMMIT, _SUS_18225_PENDING_COMMIT_REASON
    _SUS_18168_ENABLED = False
    if _SUS_18225_DEFERRED_COMMIT is not None:
        try:
            _sus_ownership.remove_timer_callback(_SUS_18225_DEFERRED_COMMIT)
        except Exception:
            pass
        _SUS_18225_DEFERRED_COMMIT = None
    _SUS_18225_PENDING_COMMIT_REASON = ""
    if _SUS_18168_DEFERRED is not None:
        try:
            _sus_ownership.remove_timer_callback(_SUS_18168_DEFERRED)
        except Exception:
            pass
        _SUS_18168_DEFERRED = None
        _SUS_18168_DEFERRED_RUNS = 0
    _sus_18168_unregister_keymap()


def register(namespace=None) -> None:  # type: ignore[no-redef]
    del namespace
    if JELARARAGI_OT_uv_gizmo_grip_fix_sentinel not in _SUS_18168_CLASSES:
        if not _sus_ownership.register_class(JELARARAGI_OT_uv_gizmo_grip_fix_sentinel):
            raise RuntimeError("Smart UV gizmo sentinel operator registration failed")
        _SUS_18168_CLASSES.append(JELARARAGI_OT_uv_gizmo_grip_fix_sentinel)
    if JELARARAGI_OT_uv_gizmo_grip_fix_grab not in _SUS_18168_CLASSES:
        if not _sus_ownership.register_class(JELARARAGI_OT_uv_gizmo_grip_fix_grab):
            raise RuntimeError("Smart UV gizmo operator registration failed")
        _SUS_18168_CLASSES.append(JELARARAGI_OT_uv_gizmo_grip_fix_grab)
    try:
        JELARARAGI_OT_uv_gizmo_grip_fix_apply.execute = _sus_18168_apply_execute
    except Exception:
        pass


def unregister() -> None:  # type: ignore[no-redef]
    disable()
    for cls in reversed(tuple(_SUS_18168_CLASSES)):
        _sus_ownership.unregister_class(cls)
    _SUS_18168_CLASSES.clear()


def is_enabled() -> bool:
    return bool(_SUS_18168_ENABLED)


def owned_keymap_items():
    return tuple(_SUS_18168_KEYMAP_ITEMS)
