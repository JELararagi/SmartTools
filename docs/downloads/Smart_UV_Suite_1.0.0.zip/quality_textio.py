from .text_translation import is_japanese

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None

_NAMESPACE = {}


def resolve_textio(namespace: dict | None = None):
    if isinstance(namespace, dict):
        mod = namespace.get('_quality_textio_module')
        if mod is not None:
            return mod
    return globals()


def find_text_block(name: str):
    if bpy is None:
        return None
    return bpy.data.texts.get(name)

def resolve_report_name(context, name_fn) -> str:
    name = ''
    if callable(name_fn):
        try:
            name = str(name_fn(context) or '').strip()
        except Exception:
            name = ''
    return name


def write_text_body(txt, body: str | None):
    if txt is None:
        return None
    try:
        txt.write(body or '')
    except Exception:
        return None
    return txt


def write_text_lines(txt, lines):
    try:
        body = '\n'.join(list(lines) if lines is not None else [])
    except Exception:
        body = ''
    return write_text_body(txt, body)


def ensure_text_block(name: str, clear: bool = False):
    if bpy is None:
        return None
    txt = bpy.data.texts.get(name)
    if txt is None:
        if not clear:
            return None
        txt = bpy.data.texts.new(name)
    elif clear:
        txt.clear()
    return txt




def ensure_namespace_text(namespace: dict | None, name: str, clear: bool = False):
    mod = resolve_textio(namespace)
    fn = getattr(mod, 'ensure_text_block', None)
    if callable(fn):
        try:
            return fn(name, clear=clear)
        except Exception:
            pass
    if bpy is None:
        return None
    txt = bpy.data.texts.get(name)
    if txt is None:
        if not clear:
            return None
        txt = bpy.data.texts.new(name)
    elif clear:
        txt.clear()
    return txt


def ensure_report_text(namespace: dict | None, name: str, clear: bool = False):
    """Shared helper for quality/report text datablocks."""
    return ensure_namespace_text(namespace, name, clear=clear)

def ensure_named_report_text(namespace: dict | None, context, name_fn, clear: bool = False):
    name = resolve_report_name(context, name_fn)
    if not name:
        return None
    return ensure_report_text(namespace, name, clear=clear)




def write_named_report_text(namespace: dict | None, context, name_fn, body: str):
    txt = ensure_named_report_text(namespace, context, name_fn, clear=True)
    return write_text_body(txt, body)


def write_named_report_lines(namespace: dict | None, context, name_fn, lines):
    txt = ensure_named_report_text(namespace, context, name_fn, clear=True)
    return write_text_lines(txt, lines)


def resolve_fallback_text(namespace: dict | None, context, name_fn, fallback_getter, clear: bool = False):
    txt = ensure_named_report_text(namespace, context, name_fn, clear=clear)
    if txt is not None:
        return txt
    name = resolve_report_name(context, name_fn)
    if not name or not callable(fallback_getter):
        return None
    try:
        return fallback_getter(name, clear=clear)
    except Exception:
        return None


def write_named_report_lines_or_fallback(namespace: dict | None, context, name_fn, lines, fallback_getter):
    txt = resolve_fallback_text(namespace, context, name_fn, fallback_getter, clear=True)
    if txt is None:
        return None
    return write_text_lines(txt, lines)


def open_named_report_text_or_fallback(namespace: dict, context, name_fn, reporter, fallback_getter, **kwargs):
    textio = resolve_textio(namespace)
    opener = getattr(textio, 'open_named_report_text', None)
    if callable(opener):
        try:
            return opener(namespace, context, name_fn, reporter, **kwargs)
        except Exception:
            pass
    name = resolve_report_name(context, name_fn)
    if not name:
        report_message(namespace, context, reporter, 'WARNING', key=kwargs.get('missing_key', 'suv.report.missing'), en=kwargs.get('missing_en', 'No report exists yet.'), ja=kwargs.get('missing_ja', 'レポートはまだ作成されていません。'))
        return {'CANCELLED'}
    txt = None
    if callable(fallback_getter):
        try:
            txt = fallback_getter(name, clear=False)
        except Exception:
            txt = None
    if txt is None:
        report_message(namespace, context, reporter, 'WARNING', key=kwargs.get('missing_key', 'suv.report.missing'), en=kwargs.get('missing_en', 'No report exists yet.'), ja=kwargs.get('missing_ja', 'レポートはまだ作成されていません。'))
        return {'CANCELLED'}
    return open_existing_text(namespace, context, txt.name, reporter, **kwargs)

def open_named_report_text(namespace: dict, context, name_fn, reporter, **kwargs):
    name = resolve_report_name(context, name_fn)
    if not name:
        report_message(namespace, context, reporter, 'WARNING', key=kwargs.get('missing_key', 'suv.report.missing'), en=kwargs.get('missing_en', 'No report exists yet.'), ja=kwargs.get('missing_ja', 'レポートはまだ作成されていません。'))
        return {'CANCELLED'}
    return open_existing_text(namespace, context, name, reporter, **kwargs)



def write_report_lines_with_open(namespace: dict | None, context, name_fn, lines, fallback_getter, reporter, *,
                                 open_after_write: bool = False,
                                 failed_key: str = 'suv.report.open_failed',
                                 failed_en: str = 'Could not open the report in a Text Editor: {name}',
                                 failed_ja: str = 'テキストエディターでレポートを開けませんでした: {name}'):
    mod = resolve_textio(namespace)
    txt = None
    writer = getattr(mod, 'write_named_report_lines_or_fallback', None)
    if callable(writer):
        try:
            txt = writer(namespace, context, name_fn, lines, fallback_getter)
        except Exception:
            txt = None
    if txt is None:
        writer = getattr(mod, 'write_named_report_lines', None)
        if callable(writer):
            try:
                txt = writer(namespace, context, name_fn, lines)
            except Exception:
                txt = None
    if txt is None and callable(fallback_getter):
        try:
            name = resolve_report_name(context, name_fn)
            if name:
                txt = fallback_getter(name, clear=True)
                if txt is not None:
                    write_text_lines(txt, lines)
        except Exception:
            txt = None
    if txt is None:
        return None
    if open_after_write:
        try:
            open_written_text(namespace or {}, context, txt, reporter, failed_key=failed_key, failed_en=failed_en, failed_ja=failed_ja)
        except Exception:
            pass
    return txt



def write_report_lines_consistent(namespace: dict | None, context, name_fn, lines, fallback_getter, reporter, *,
                                  open_after_write: bool = False,
                                  failed_key: str = 'suv.report.open_failed',
                                  failed_en: str = 'Could not open the report in a Text Editor: {name}',
                                  failed_ja: str = 'テキストエディターでレポートを開けませんでした: {name}'):
    textio = resolve_textio(namespace)
    writer = getattr(textio, 'write_report_lines_with_open', None)
    if callable(writer):
        try:
            return writer(
                namespace, context, name_fn, lines, fallback_getter, reporter,
                open_after_write=open_after_write,
                failed_key=failed_key,
                failed_en=failed_en,
                failed_ja=failed_ja,
            )
        except Exception:
            pass

    txt = None
    writer = getattr(textio, 'write_named_report_lines_or_fallback', None)
    if callable(writer):
        try:
            txt = writer(namespace, context, name_fn, lines, fallback_getter)
        except Exception:
            txt = None
    if txt is None:
        writer = getattr(textio, 'write_named_report_lines', None)
        if callable(writer):
            try:
                txt = writer(namespace, context, name_fn, lines)
            except Exception:
                txt = None
    if txt is None:
        try:
            name = resolve_report_name(context, name_fn)
        except Exception:
            name = ''
        if not name or not callable(fallback_getter):
            return None
        try:
            txt = fallback_getter(name, clear=True)
        except Exception:
            txt = None
        if txt is None:
            return None
        if write_text_lines(txt, lines) is None:
            return None

    if open_after_write:
        opener = getattr(textio, 'open_written_text', None)
        if callable(opener):
            try:
                opener(namespace or {}, context, txt, reporter,
                       failed_key=failed_key,
                       failed_en=failed_en,
                       failed_ja=failed_ja)
            except Exception:
                pass
        else:
            opener_fn = namespace.get('_suv_open_text_in_editor') if isinstance(namespace, dict) else None
            if callable(opener_fn):
                try:
                    opener_fn(context, txt)
                except Exception:
                    pass
    return txt

def open_written_text(namespace: dict, context, txt, reporter, *,
                      failed_key: str = 'suv.report.open_failed',
                      failed_en: str = 'Could not open the report in a Text Editor: {name}',
                      failed_ja: str = 'テキストエディターでレポートを開けませんでした: {name}'):
    if txt is None:
        return False
    opener = namespace.get('_suv_open_text_in_editor') if isinstance(namespace, dict) else None
    ok = False
    if callable(opener):
        try:
            ok, _err = opener(context, txt)
        except Exception:
            ok = False
    if not ok:
        report_message(namespace, context, reporter, 'WARNING', key=failed_key, en=failed_en, ja=failed_ja, name=getattr(txt, 'name', '-'))
        return False
    return True

def report_message(namespace: dict, context, reporter, level: str, *, key: str, en: str, ja: str, **kwargs):
    tr = None
    if isinstance(namespace, dict):
        tr = namespace.get('tr') or namespace.get('_suv_tr')
    if tr is None:
        tr = globals().get('_suv_tr')

    def _tr_local(msg_key, msg_en, msg_ja, **fmt):
        if callable(tr):
            try:
                translated = tr(context, msg_key, msg_en, msg_ja, **fmt)
                if translated:
                    return translated
            except Exception:
                pass
        base = msg_ja if is_japanese(context) else msg_en
        if fmt:
            try:
                return base.format(**fmt)
            except Exception:
                return base
        return base

    if reporter is not None:
        reporter.report({level}, _tr_local(key, en, ja, **kwargs))


def open_existing_text(namespace: dict, context, name: str, reporter, *,
                       missing_key: str, missing_en: str, missing_ja: str,
                       opened_key: str, opened_en: str, opened_ja: str,
                       failed_key: str = 'suv.report.open_failed',
                       failed_en: str = 'Could not open the report in a Text Editor: {name}',
                       failed_ja: str = 'テキストエディターでレポートを開けませんでした: {name}'):
    txt = find_text_block(name)
    if txt is None:
        report_message(namespace, context, reporter, 'WARNING', key=missing_key, en=missing_en, ja=missing_ja)
        return {'CANCELLED'}

    opener = namespace.get('_suv_open_text_in_editor')
    if not callable(opener):
        from .ui import _suv_open_text_in_editor as opener
    ok = False
    if callable(opener):
        try:
            ok, _err = opener(context, txt)
        except Exception:
            ok = False

    if not ok:
        report_message(namespace, context, reporter, 'WARNING', key=failed_key, en=failed_en, ja=failed_ja, name=txt.name)
        return {'CANCELLED'}

    report_message(namespace, context, reporter, 'INFO', key=opened_key, en=opened_en, ja=opened_ja, name=txt.name)
    return {'FINISHED'}


def register(namespace: dict):
    global _NAMESPACE
    _NAMESPACE = namespace if isinstance(namespace, dict) else {}
    return []


def unregister(namespace: dict | None = None):
    return []
