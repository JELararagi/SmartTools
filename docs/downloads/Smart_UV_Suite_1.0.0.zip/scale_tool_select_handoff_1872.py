# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""1.8.72 UV Scale tool background selection handoff.

Fixes Blender UV Scale tool behavior where background left-drag does not fall
back to the selection/box-select tool while Move/Rotate/Transform tools do.
The operator is only registered in the UV Scale tool keymap and only handles
true background presses; element, selected element, modifier and gizmo events
are passed through unchanged.
"""
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

import bpy
import bmesh
from mathutils import Vector

_VERSION = (1, 8, 72)
_OP_ID = "smart_uv_suite.uv_scale_tool_background_select"
_KM_NAME = "Image Editor Tool: Uv, Scale"
_KM_SPACE = "IMAGE_EDITOR"
_PG = None
_REGISTERED = False


def _base():
    try:
        from . import interaction_1871 as b
        return b
    except Exception:
        pass
    try:
        from . import interaction_1865 as b
        return b
    except Exception:
        return None


def _is_uv_context(context) -> bool:
    try:
        return (getattr(getattr(context, "area", None), "type", None) == "IMAGE_EDITOR" and
                getattr(getattr(context, "region", None), "type", None) == "WINDOW")
    except Exception:
        return False


def _is_scale_tool(context) -> bool:
    try:
        tool = context.workspace.tools.from_space_image_mode('UV', create=False)
        return getattr(tool, "idname", "") == "builtin.scale"
    except Exception:
        try:
            tool = context.workspace.tools.from_space_image_mode('UV')
            return getattr(tool, "idname", "") == "builtin.scale"
        except Exception:
            # The keymap is already UV Scale-tool scoped, so failure here must
            # not block the fix on Blender builds where the tool API differs.
            return True



def _objects_in_edit_mode(context):
    try:
        objs = list(getattr(context, 'objects_in_mode_unique_data', []) or [])
        if objs:
            return [ob for ob in objs if getattr(ob, 'type', None) == 'MESH']
    except Exception:
        pass
    try:
        ob = getattr(context, 'edit_object', None)
        return [ob] if ob is not None and getattr(ob, 'type', None) == 'MESH' else []
    except Exception:
        return []


def _uv_under_mouse_selected_only(context, event) -> bool:
    """Cheap safety fallback for selected UVs.

    The cache-aware finder handles most cases.  This fallback exists so the
    Scale background handoff never steals a drag that starts on an already
    selected UV element when the cache has not been built yet.  It scans only
    selected UV components and exits at the first hit.
    """
    try:
        region = context.region
        v2d = getattr(region, 'view2d', None)
        if v2d is None:
            return False
        x = int(getattr(event, 'mouse_region_x', 0) or 0)
        y = int(getattr(event, 'mouse_region_y', 0) or 0)
        uv = Vector(v2d.region_to_view(x, y))
        uvx2 = Vector(v2d.region_to_view(x + 8, y))
        uvy2 = Vector(v2d.region_to_view(x, y + 8))
        radius = max((uvx2 - uv).length, (uvy2 - uv).length, 1.0e-7)
        radius2 = radius * radius
        for ob in _objects_in_edit_mode(context):
            try:
                bm = bmesh.from_edit_mesh(ob.data)
                uv_layer = bm.loops.layers.uv.active
                if uv_layer is None:
                    continue
                for f in bm.faces:
                    for l in f.loops:
                        luv = l[uv_layer]
                        selected = False
                        try: selected = selected or bool(luv.select)
                        except Exception: pass
                        try: selected = selected or bool(luv.select_edge)
                        except Exception: pass
                        try: selected = selected or bool(luv.select_vert)
                        except Exception: pass
                        try: selected = selected or bool(l.uv_select_vert)
                        except Exception: pass
                        try: selected = selected or bool(l.uv_select_edge)
                        except Exception: pass
                        if selected and (Vector(luv.uv) - uv).length_squared <= radius2:
                            return True
            except Exception:
                continue
    except Exception:
        pass
    return False


def _find_hit(context, event):
    try:
        b = _base()
        fn = getattr(b, "_find_hit", None) if b is not None else None
        if callable(fn):
            return fn(context, event)
    except Exception:
        pass
    return None


def _switch_to_uv_select_box(context):
    # Do not require this to succeed.  The select_box invoke below performs the
    # actual drag-select, while tool switching gives the same post-action state
    # as Blender's transform-tool fallback behavior.
    for name in ("builtin.select_box", "builtin.select"):
        try:
            with context.temp_override(area=context.area, region=context.region):
                bpy.ops.wm.tool_set_by_id(name=name)
            return True
        except Exception:
            try:
                bpy.ops.wm.tool_set_by_id(name=name)
                return True
            except Exception:
                continue
    return False


def _invoke_uv_select_box(context):
    # Call Blender's native box select; it owns dashed-rectangle drawing,
    # selection mode, modifier semantics and release confirmation.
    try:
        with context.temp_override(area=context.area, region=context.region):
            res = bpy.ops.uv.select_box('INVOKE_DEFAULT')
        return set(res) if res is not None else {"RUNNING_MODAL"}
    except TypeError:
        try:
            res = bpy.ops.uv.select_box('INVOKE_DEFAULT')
            return set(res) if res is not None else {"RUNNING_MODAL"}
        except Exception:
            return {"PASS_THROUGH"}
    except Exception:
        return {"PASS_THROUGH"}


class SMARTUVSUITE_OT_uv_scale_tool_background_select(bpy.types.Operator):
    bl_idname = _OP_ID
    bl_label = "UV Scale Tool Background Select Handoff"
    bl_description = "When the UV Scale tool is active, background drag starts Blender native box select without affecting element or gizmo drags. / UVスケールツール中の背景ドラッグを標準ボックス選択へ渡します。"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        try:
            if not _is_uv_context(context):
                return {'PASS_THROUGH'}
            if not _is_scale_tool(context):
                return {'PASS_THROUGH'}
            if str(getattr(event, 'type', '')) != 'LEFTMOUSE' or str(getattr(event, 'value', '')) != 'PRESS':
                return {'PASS_THROUGH'}
            # Preserve all modifier-based native behavior.
            if bool(getattr(event, 'shift', False) or getattr(event, 'ctrl', False) or getattr(event, 'alt', False) or getattr(event, 'oskey', False)):
                return {'PASS_THROUGH'}
            # Any UV hit is not background; let Scale's native transform/gizmo
            # path handle it.  Only a reliable miss is handled here.
            hit = _find_hit(context, event)
            if hit or _uv_under_mouse_selected_only(context, event):
                return {'PASS_THROUGH'}
            _switch_to_uv_select_box(context)
            return _invoke_uv_select_box(context)
        except Exception:
            return {'PASS_THROUGH'}


def _register_class():
    global _REGISTERED
    if _REGISTERED:
        return
    try:
        __import__(__package__ + '.ownership_runtime_18168', fromlist=['register_class']).register_class(SMARTUVSUITE_OT_uv_scale_tool_background_select)
        _REGISTERED = True
    except ValueError:
        _REGISTERED = True
    except Exception:
        pass


def _unregister_class():
    global _REGISTERED
    try:
        __import__(__package__ + '.ownership_runtime_18168', fromlist=['unregister_class']).unregister_class(SMARTUVSUITE_OT_uv_scale_tool_background_select)
    except Exception:
        pass
    _REGISTERED = False


def _addon_keyconfig():
    try:
        return bpy.context.window_manager.keyconfigs.addon
    except Exception:
        return None


def _get_keymap(kc):
    try:
        km = kc.keymaps.get(_KM_NAME)
        if km is None:
            km = kc.keymaps.new(name=_KM_NAME, space_type=_KM_SPACE, region_type='WINDOW')
        return km
    except Exception:
        return None


def _find_items(km, idname):
    try:
        from . import ownership_runtime_18168 as _ownership
        return [kmi for keymap, kmi in _ownership.owned_keymap_items(idname) if keymap is km]
    except Exception:
        return []


def ensure_keymap(active=True):
    kc = _addon_keyconfig()
    if kc is None:
        return (0, 0)
    km = _get_keymap(kc)
    if km is None:
        return (0, 0)
    items = _find_items(km, _OP_ID)
    created = 0
    if not items:
        try:
            kmi = __import__(__package__ + '.ownership_runtime_18168', fromlist=['new_keymap_item']).new_keymap_item(km, _OP_ID, type='LEFTMOUSE', value='PRESS', head=True)
        except TypeError:
            kmi = __import__(__package__ + '.ownership_runtime_18168', fromlist=['new_keymap_item']).new_keymap_item(km, _OP_ID, type='LEFTMOUSE', value='PRESS')
        items = [kmi]
        created = 1
    # Keep exactly one entry and place it before Scale's transform.resize item.
    for extra in items[1:]:
        try:
            __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(km, extra)
        except Exception:
            try: __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(extra, False)
            except Exception: pass
    touched = 0
    for kmi in items[:1]:
        try:
            _suv_resource.keymap_item_set(kmi, 'type', 'LEFTMOUSE'); _suv_resource.keymap_item_set(kmi, 'value', 'PRESS')
            _suv_resource.keymap_item_set(kmi, 'shift', False); _suv_resource.keymap_item_set(kmi, 'ctrl', False); _suv_resource.keymap_item_set(kmi, 'alt', False); _suv_resource.keymap_item_set(kmi, 'oskey', False)
            try: _suv_resource.keymap_item_set(kmi, 'any', False)
            except Exception: pass
            __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, bool(active))
            touched += 1
        except Exception:
            pass
    return (created, touched)


def delete_keymap():
    kc = _addon_keyconfig()
    if kc is None:
        return 0
    removed = 0
    try:
        km = kc.keymaps.get(_KM_NAME)
        if km is not None:
            for kmi in list(_find_items(km, _OP_ID)):
                try:
                    __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(km, kmi); removed += 1
                except Exception:
                    try: __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, False)
                    except Exception: pass
    except Exception:
        pass
    return removed


def apply_all(pkg_globals=None, context=None):
    global _PG
    if pkg_globals is not None:
        _PG = pkg_globals
    _register_class()
    ensure_keymap(True)
    try:
        if isinstance(_PG, dict):
            bi = _PG.get('bl_info')
            if isinstance(bi, dict):
                bi['version'] = (1, 0, 0)
            _PG['__version__'] = '1.0.0'
            _PG['_sus_1872_scale_tool_background_select_handoff'] = True
    except Exception:
        pass


def remove_all():
    delete_keymap()
    _unregister_class()


def install(pkg_globals):
    global _PG
    _PG = pkg_globals
    apply_all(pkg_globals, bpy.context)
