"""Implement the align stretch public UV operations."""


def align_stretch(context, op, api):
    direction = op.axis or ('V' if op.is_vertical else 'U')
    if direction not in {'U', 'V', 'X', 'Y'}:
        return False
    axis = 0 if direction in {'U', 'X'} else 1
    factor = op.value if op.properties.is_property_set('value') else 1.0 + op.amount
    if factor <= 0.0 or factor == 1.0:
        return False
    rows = api._edit_targets(context)
    sync = api._sync(context)
    points = [
        loop[uv].uv
        for _, bm, uv in rows
        for face in bm.faces if api._visible(face, sync)
        for loop in face.loops
        if (loop.vert.select if sync else loop.uv_select_vert) and not loop[uv].pin_uv
    ]
    if not points:
        return False
    center = (min(p[axis] for p in points) + max(p[axis] for p in points)) / 2.0
    for point in points:
        point[axis] = center + (point[axis] - center) * factor
    api._flush(rows)
    return True



def build_handlers(api):
    apply_target = api._run_uv_layout(
        "suv_apply_external_compat_target", target="key", execution_mode="mode", scope="scope")
    return {
        "smart_uv_suite.align_apply_external_target": api.Handler(
            lambda context, op: bool(op.key.strip()) and apply_target(context, op),
            "Run the requested external compatibility target.",
            "指定した外部互換ターゲットを実行します。"),

        "smart_uv_suite.align_stretch": api.Handler(lambda context, op: align_stretch(context, op, api), 'Scale the selected UVs along one axis around their bounds center.', '選択UVを範囲の中心から指定した一軸方向に拡縮します。'),

    }
