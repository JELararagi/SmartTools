# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Smart UV Suite 1.8.108 UV unwrap integrity layer.

Final runtime layer for the UV Unwrap section:
- make Run Unwrap operate on the current UV Editor selection scope only;
- keep non-selected UV loops and non-active UV map channels untouched;
- keep multi-object Edit Mode support;
- consolidate the realtime/live unwrap UI state;
- provide deterministic Square/Circle unwrap post-shape routes.
"""

from __future__ import annotations

import math
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

_PATCH_VERSION = (1, 8, 108)
_PATCH_TEXT = "1.8.108"
_ORIGINAL_RUN = None
_ORIGINAL_ACTION_EXECUTE = None
_ORIGINAL_RUN_EXECUTE = None
_INSTALLED = False


def _safe_set_version(ns: Dict[str, Any]) -> None:
    try:
        ns["__version__"] = '1.0.0'
    except Exception:
        pass
    try:
        info = ns.get("bl_info")
        if not isinstance(info, dict):
            info = {}
            ns["bl_info"] = info
        info["version"] = (1, 0, 0)
        info["author"] = "JELararagi"
        ns["_SUS_BL_INFO_FALLBACK"] = dict(info)
    except Exception:
        pass


def _context() -> Any:
    import bpy
    return bpy.context


def _ws(context: Any = None) -> Any:
    try:
        return getattr(getattr((context or _context()), "scene", None), "suv_workspace", None)
    except Exception:
        return None


def _tool_settings(context: Any = None) -> Any:
    try:
        return getattr(getattr((context or _context()), "scene", None), "tool_settings", None)
    except Exception:
        return None


def _live_unwrap_attr(ts: Any) -> str:
    for attr in ("use_edge_path_live_unwrap", "use_live_unwrap"):
        try:
            if ts is not None and hasattr(ts, attr):
                return attr
        except Exception:
            pass
    return ""


def _sync_realtime_to_native_live(context: Any = None) -> None:
    """Use one visible switch for both Smart realtime refresh and Blender Live Unwrap.

    This does not add a second UI item.  It only mirrors the single retained
    Smart UV toggle to Blender's native Live Unwrap property when that property
    exists in the current Blender build/context.
    """
    try:
        ctx = context or _context()
        ws = _ws(ctx)
        ts = _tool_settings(ctx)
        attr = _live_unwrap_attr(ts)
        if ws is None or not attr:
            return
        target = bool(getattr(ws, "smart_unwrap_realtime_preview", False))
        try:
            if bool(getattr(ts, attr)) != target:
                setattr(ts, attr, target)
        except Exception:
            pass
        # Keep the existing always-on persistence record in sync when present,
        # but do not require it for the visible toggle to be meaningful.
        try:
            from . import npanel_persistence as _npanel_store
            set_always_on = getattr(_npanel_store, "set_always_on", None)
            if callable(set_always_on):
                set_always_on("SMART_REALTIME_UNWRAP", target)
                set_always_on("BLENDER_LIVE_UNWRAP", target)
        except Exception:
            pass
    except Exception:
        pass


def _capture_modes(context: Any) -> Dict[str, Any]:
    ts = _tool_settings(context)
    data: Dict[str, Any] = {"ts": ts}
    if ts is None:
        return data
    for attr in ("use_uv_select_sync", "uv_select_mode", "uv_sticky_select_mode", "sticky_select_mode"):
        try:
            if hasattr(ts, attr):
                data[attr] = getattr(ts, attr)
        except Exception:
            pass
    try:
        data["mesh_select_mode"] = tuple(bool(v) for v in ts.mesh_select_mode)
    except Exception:
        pass
    return data


def _restore_modes(data: Dict[str, Any]) -> None:
    ts = data.get("ts")
    if ts is None:
        return
    for attr, value in list(data.items()):
        if attr in {"ts", "mesh_select_mode"}:
            continue
        try:
            if hasattr(ts, attr) and getattr(ts, attr) != value:
                setattr(ts, attr, value)
        except Exception:
            pass
    try:
        if "mesh_select_mode" in data:
            ts.mesh_select_mode = data["mesh_select_mode"]
    except Exception:
        pass


def _unique_mesh_objects(seq: Iterable[Any]) -> List[Any]:
    out: List[Any] = []
    seen: Set[str] = set()
    for obj in seq or []:
        try:
            if obj is None or getattr(obj, "type", None) != "MESH":
                continue
            key = str(getattr(obj, "name_full", None) or getattr(obj, "name", None) or id(obj))
            if key in seen:
                continue
            seen.add(key)
            out.append(obj)
        except Exception:
            pass
    return out


def _edit_mesh_objects(context: Any) -> List[Any]:
    objs: List[Any] = []
    for attr in ("objects_in_mode_unique_data", "objects_in_mode"):
        try:
            vals = [o for o in (getattr(context, attr, None) or []) if getattr(o, "type", None) == "MESH"]
            if vals:
                objs.extend(vals)
                break
        except Exception:
            pass
    if not objs:
        try:
            objs = [o for o in (getattr(context, "selected_objects", None) or []) if getattr(o, "type", None) == "MESH"]
        except Exception:
            objs = []
    active = None
    try:
        active = getattr(context, "edit_object", None) or getattr(context, "active_object", None) or getattr(context.view_layer.objects, "active", None)
    except Exception:
        active = None
    ordered: List[Any] = []
    if active is not None and getattr(active, "type", None) == "MESH":
        ordered.append(active)
    ordered.extend(objs)
    return _unique_mesh_objects(ordered)


def _ensure_edit_mode(context: Any, obj: Any) -> Tuple[Any, str, bool]:
    import bpy
    old_active = None
    try:
        old_active = context.view_layer.objects.active
    except Exception:
        pass
    old_mode = str(getattr(obj, "mode", "OBJECT") or "OBJECT")
    changed = False
    try:
        context.view_layer.objects.active = obj
    except Exception:
        pass
    try:
        obj.select_set(True)
    except Exception:
        pass
    if old_mode != "EDIT":
        try:
            bpy.ops.object.mode_set(mode="EDIT")
            changed = True
        except Exception:
            pass
    return old_active, old_mode, changed


def _restore_active_mode(context: Any, old_active: Any, old_mode: str, changed: bool) -> None:
    import bpy
    try:
        if old_active is not None:
            context.view_layer.objects.active = old_active
    except Exception:
        pass
    if changed:
        try:
            bpy.ops.object.mode_set(mode=old_mode)
        except Exception:
            try:
                bpy.ops.object.mode_set(mode="EDIT")
            except Exception:
                pass


def _unwrap_channel_index(ws: Any, obj: Any) -> Optional[int]:
    try:
        layers = getattr(getattr(obj, "data", None), "uv_layers", None)
        if layers is None or len(layers) <= 0:
            return None
        raw = str(getattr(ws, "unwrap_map_channel", "ACTIVE") or "ACTIVE").upper() if ws is not None else "ACTIVE"
        idx = None
        if raw.startswith("CHANNEL_") or raw.startswith("INDEX_"):
            idx = int(raw.split("_", 1)[1])
        elif raw.isdigit():
            idx = int(raw)
        if idx is None:
            idx = int(getattr(layers, "active_index", 0) or 0)
        idx = max(0, min(int(idx), len(layers) - 1))
        layers.active_index = idx
        return idx
    except Exception:
        return None


def _active_uv_layer(bm: Any):
    try:
        layer = bm.loops.layers.uv.active
        if layer is not None:
            return layer
    except Exception:
        pass
    try:
        return bm.loops.layers.uv.verify()
    except Exception:
        return None


def _loop_index(loop: Any) -> int:
    try:
        return int(loop.index)
    except Exception:
        return int(id(loop))


def _face_index(face: Any) -> int:
    try:
        return int(face.index)
    except Exception:
        return int(id(face))


def _layer_name(layer: Any) -> str:
    try:
        return str(layer.name)
    except Exception:
        return str(layer)


def _uv_vert_selected(loop: Any, luv: Any = None) -> bool:
    try:
        return bool(loop.uv_select_vert_get())
    except Exception:
        pass
    try:
        if hasattr(loop, "uv_select_vert"):
            return bool(getattr(loop, "uv_select_vert"))
    except Exception:
        pass
    try:
        return bool(getattr(luv, "select", False))
    except Exception:
        return False


def _uv_edge_selected(loop: Any, luv: Any = None) -> bool:
    try:
        return bool(loop.uv_select_edge_get())
    except Exception:
        pass
    try:
        if hasattr(loop, "uv_select_edge"):
            return bool(getattr(loop, "uv_select_edge"))
    except Exception:
        pass
    try:
        return bool(getattr(luv, "select_edge", False))
    except Exception:
        return False


def _uv_set_vert_selected(loop: Any, luv: Any, value: bool) -> None:
    try:
        loop.uv_select_vert_set(bool(value))
        return
    except Exception:
        pass
    try:
        if hasattr(luv, "select"):
            luv.select = bool(value)
    except Exception:
        pass


def _uv_set_edge_selected(loop: Any, luv: Any, value: bool) -> None:
    try:
        loop.uv_select_edge_set(bool(value))
        return
    except Exception:
        pass
    try:
        if hasattr(luv, "select_edge"):
            luv.select_edge = bool(value)
    except Exception:
        pass


def _hidden_bool_values(mesh: Any, name: str) -> List[bool]:
    try:
        attr = getattr(getattr(mesh, "attributes", None), "get", lambda _n: None)(name)
        if attr is None:
            return []
        return [bool(getattr(x, "value", False)) for x in (getattr(attr, "data", None) or [])]
    except Exception:
        return []





def _object_mode_uv_selection_scope(obj: Any, use_mesh_selection: bool = False) -> Dict[str, Set[int]]:
    """Read Blender hidden UV selection attributes as an exact UV-loop scope.

    Mesh vertex/edge selections are deliberately used only as a last-resort
    fallback.  In UV sync mode Blender may select shared mesh vertices/edges on
    neighboring faces; using those values unconditionally broadens a single UV
    face/edge selection into adjacent UV islands and makes 展開実行 affect
    unselected elements.
    """
    faces: Set[int] = set()
    selected_loops: Set[int] = set()
    selected_edge_loops: Set[int] = set()
    full_face_loops: Set[int] = set()
    try:
        mesh = obj.data
        uv_vert = _hidden_bool_values(mesh, ".uv_select_vert")
        uv_edge = _hidden_bool_values(mesh, ".uv_select_edge")
        uv_face = _hidden_bool_values(mesh, ".uv_select_face")
        has_uv_state = bool(any(uv_vert) or any(uv_edge) or any(uv_face))
        # Mesh selection is less precise than UV loop selection.  Use it only
        # when no UV hidden selection state exists at all.
        allow_mesh = bool(use_mesh_selection and not has_uv_state)
        mesh_vert = _hidden_bool_values(mesh, ".select_vert") if allow_mesh else []
        mesh_edge = _hidden_bool_values(mesh, ".select_edge") if allow_mesh else []
        mesh_face = _hidden_bool_values(mesh, ".select_poly") if allow_mesh else []
        polygons = list(getattr(mesh, "polygons", []) or [])
        edge_selected = {i for i, val in enumerate(mesh_edge) if val}
        vert_selected = {i for i, val in enumerate(mesh_vert) if val}
        any_mesh_face = any(mesh_face)
        any_mesh_edge = bool(edge_selected)
        for poly in polygons:
            try:
                pi = int(poly.index)
            except Exception:
                continue
            loop_indices = list(getattr(poly, "loop_indices", []) or range(int(poly.loop_start), int(poly.loop_start) + int(poly.loop_total)))
            face_has_scope = False
            explicit_full_face = False
            try:
                if 0 <= pi < len(uv_face) and uv_face[pi]:
                    explicit_full_face = True
            except Exception:
                pass
            try:
                if allow_mesh and 0 <= pi < len(mesh_face) and mesh_face[pi]:
                    explicit_full_face = True
            except Exception:
                pass
            if explicit_full_face:
                face_has_scope = True
                for li in loop_indices:
                    try:
                        li_i = int(li)
                        selected_loops.add(li_i)
                        full_face_loops.add(li_i)
                    except Exception:
                        pass
            if explicit_full_face:
                faces.add(pi)
                continue
            # If a mesh face selection exists, do not also interpret shared mesh
            # edges/vertices from that selection as neighboring UV loop hits.
            use_mesh_edges = bool(allow_mesh and not any_mesh_face and any_mesh_edge)
            use_mesh_verts = bool(allow_mesh and not any_mesh_face and not any_mesh_edge)
            for idx, li in enumerate(loop_indices):
                try:
                    li_i = int(li)
                except Exception:
                    continue
                v_hit = False
                e_hit = False
                try:
                    if 0 <= li_i < len(uv_vert) and uv_vert[li_i]:
                        v_hit = True
                except Exception:
                    pass
                try:
                    if 0 <= li_i < len(uv_edge) and uv_edge[li_i]:
                        e_hit = True
                except Exception:
                    pass
                if use_mesh_edges:
                    try:
                        ei = int(mesh.loops[li_i].edge_index)
                        if ei in edge_selected:
                            e_hit = True
                    except Exception:
                        pass
                elif use_mesh_verts:
                    try:
                        vi = int(mesh.loops[li_i].vertex_index)
                        if vi in vert_selected:
                            v_hit = True
                    except Exception:
                        pass
                if e_hit:
                    selected_edge_loops.add(li_i)
                    selected_loops.add(li_i)
                    try:
                        selected_loops.add(int(loop_indices[(idx + 1) % len(loop_indices)]))
                    except Exception:
                        pass
                    face_has_scope = True
                elif v_hit:
                    selected_loops.add(li_i)
                    face_has_scope = True
            if face_has_scope:
                faces.add(pi)
    except Exception:
        pass
    return {"faces": faces, "selected_loops": selected_loops, "selected_edge_loops": selected_edge_loops, "full_face_loops": full_face_loops}

def _capture_object_mode_uv_selection_scopes(context: Any, objs: Sequence[Any]) -> Dict[str, Dict[str, Set[int]]]:
    """Capture UV Editor selection for all target objects via object-mode attrs.

    The mode switch is local and immediately restored.  It is necessary for
    Blender 5.1's hidden UV selection attributes to become visible to Python.
    """
    import bpy
    result: Dict[str, Dict[str, Set[int]]] = {}
    if not objs:
        return result
    old_active = None
    old_selected: List[Any] = []
    old_mode = None
    try:
        old_active = context.view_layer.objects.active
        old_mode = str(getattr(old_active, "mode", "OBJECT") or "OBJECT") if old_active is not None else "OBJECT"
        old_selected = list(getattr(context, "selected_objects", []) or [])
    except Exception:
        pass
    try:
        try:
            if old_active is not None and str(getattr(old_active, "mode", "OBJECT") or "OBJECT") != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass
        use_mesh_selection = False
        try:
            ts = _tool_settings(context)
            use_mesh_selection = bool(getattr(ts, "use_uv_select_sync", False))
        except Exception:
            use_mesh_selection = False
        for obj in objs:
            if getattr(obj, "type", None) != "MESH":
                continue
            key = str(getattr(obj, "name_full", None) or getattr(obj, "name", None) or id(obj))
            result[key] = _object_mode_uv_selection_scope(obj, use_mesh_selection=use_mesh_selection)
    finally:
        try:
            for obj in getattr(context, "scene", None).objects:
                try:
                    obj.select_set(obj in old_selected)
                except Exception:
                    pass
        except Exception:
            pass
        try:
            if old_active is not None:
                context.view_layer.objects.active = old_active
        except Exception:
            pass
        try:
            if old_mode == "EDIT" and old_active is not None:
                bpy.ops.object.mode_set(mode="EDIT")
        except Exception:
            pass
    return result



def _merge_scope_selection(scope: Dict[str, Any], external: Optional[Dict[str, Set[int]]]) -> Dict[str, Any]:
    """Merge object-mode UV selection into an edit BMesh scope.

    When object-mode hidden UV attributes are available they are authoritative.
    They represent the UV Editor selection in Blender 5.1.  Live BMesh selection
    can mirror broad mesh selection and must not be unioned in, otherwise a
    one-edge/one-face UV selection can become an all-face unwrap.
    """
    if not external:
        return scope
    # Object-mode hidden UV attributes captured immediately before execution are
    # the authoritative UV Editor selection in Blender 5.1.  Use them instead of
    # broad live mesh selection so edge/vertex unwrap does not expand to every
    # loop of the containing face.
    ext_faces = set(external.get("faces") or set())
    ext_selected = set(external.get("selected_loops") or set())
    ext_edge = set(external.get("selected_edge_loops") or set())
    ext_full = set(external.get("full_face_loops") or set())
    if not ext_faces and not ext_selected and not ext_edge and not ext_full:
        return scope
    change_loops = set(ext_selected) | set(ext_full)
    if not change_loops and ext_faces:
        bm = scope.get("bm")
        try:
            for face in bm.faces:
                if _face_index(face) in ext_faces:
                    for loop in face.loops:
                        change_loops.add(_loop_index(loop))
        except Exception:
            pass
    scope["faces"] = ext_faces
    scope["selected_loops"] = ext_selected
    scope["selected_edge_loops"] = ext_edge
    scope["full_face_loops"] = ext_full
    scope["change_loops"] = change_loops
    return scope


def _selection_scope_for_object(context: Any, obj: Any) -> Dict[str, Any]:
    """Build an unwrap scope from the current UV Editor selection.

    The scope has two separate concepts:
    - faces: faces that must be temporarily selected so Blender native unwrap can run;
    - change_loops: UV loops that Smart UV Suite is allowed to leave modified.

    This separation is critical.  A selected face may require all of its loops,
    but a selected edge/vertex must not turn shared neighboring UV loops into
    edit targets merely because Blender's UV sync selected a shared mesh vertex.
    """
    import bmesh
    bm = bmesh.from_edit_mesh(obj.data)
    uv_layer = _active_uv_layer(bm)
    empty = {"obj": obj, "bm": bm, "uv_layer": uv_layer, "faces": set(), "change_loops": set(), "selected_loops": set(), "selected_edge_loops": set(), "full_face_loops": set()}
    if uv_layer is None:
        return empty
    try:
        bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
        bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
        for index, loop in enumerate(l for f in bm.faces for l in f.loops):
            loop.index = index
    except Exception:
        pass
    ts = _tool_settings(context)
    try:
        sync = bool(getattr(ts, "use_uv_select_sync", False))
    except Exception:
        sync = False
    # In live Edit Mode, trust the current BMesh/mesh selection only.
    # Hidden .uv_select_* attributes can contain stale data from an older
    # Object Mode flush and have previously caused 展開実行 to affect all UVs.
    # They are read only by _capture_object_mode_uv_selection_scopes() when no
    # live edit selection can be obtained at all.
    hidden_vert: List[bool] = []
    hidden_edge: List[bool] = []
    hidden_face: List[bool] = []
    selected_faces: Set[int] = set()
    selected_loops: Set[int] = set()
    selected_edge_loops: Set[int] = set()
    full_face_loops: Set[int] = set()

    # First pass: determine whether explicit face or edge-level selection exists.
    mesh_face_selected = False
    mesh_edge_selected = False
    for face in bm.faces:
        try:
            if bool(getattr(face, "hide", False)):
                continue
        except Exception:
            pass
        try:
            if sync and bool(face.select):
                mesh_face_selected = True
        except Exception:
            pass
        for loop in face.loops:
            try:
                if sync and bool(loop.edge.select):
                    mesh_edge_selected = True
            except Exception:
                pass
    has_hidden_uv = bool(any(hidden_vert) or any(hidden_edge) or any(hidden_face))

    for face in bm.faces:
        try:
            if bool(getattr(face, "hide", False)):
                continue
        except Exception:
            pass
        try:
            # With UV Sync off the UV Editor only shows faces selected in the mesh.
            if not sync and not bool(face.select):
                continue
        except Exception:
            pass
        fi = _face_index(face)
        loop_list = list(face.loops)
        face_has_scope = False
        explicit_full_face = False
        try:
            if 0 <= fi < len(hidden_face) and hidden_face[fi]:
                explicit_full_face = True
        except Exception:
            pass
        try:
            # Use mesh face selection as full-face scope only.  When it exists,
            # shared mesh edges/verts must not add neighboring faces.
            if sync and bool(face.select):
                explicit_full_face = True
        except Exception:
            pass
        if explicit_full_face:
            face_has_scope = True
            for loop in loop_list:
                li = _loop_index(loop)
                selected_loops.add(li)
                full_face_loops.add(li)
            selected_faces.add(fi)
            continue

        for loop in loop_list:
            li = _loop_index(loop)
            v_hit = False
            e_hit = False
            try:
                v_hit = bool(_uv_vert_selected(loop, loop[uv_layer]))
            except Exception:
                v_hit = False
            try:
                e_hit = bool(_uv_edge_selected(loop, loop[uv_layer]))
            except Exception:
                e_hit = False
            try:
                if 0 <= li < len(hidden_vert) and hidden_vert[li]:
                    v_hit = True
            except Exception:
                pass
            try:
                if 0 <= li < len(hidden_edge) and hidden_edge[li]:
                    e_hit = True
            except Exception:
                pass
            # Mesh fallback is last-resort and mode-aware.  If any explicit UV
            # hidden/live state or mesh face selection exists, do not let shared
            # mesh vertices/edges broaden the UV editor selection.
            if sync and not has_hidden_uv and not mesh_face_selected:
                try:
                    if mesh_edge_selected:
                        if bool(loop.edge.select):
                            e_hit = True
                    else:
                        if bool(loop.vert.select):
                            v_hit = True
                except Exception:
                    pass
            if e_hit:
                selected_edge_loops.add(li)
                selected_loops.add(li)
                try:
                    selected_loops.add(_loop_index(loop.link_loop_next))
                except Exception:
                    pass
                face_has_scope = True
            elif v_hit:
                selected_loops.add(li)
                face_has_scope = True
        if face_has_scope:
            selected_faces.add(fi)
    if not sync and not selected_faces:
        # Nothing picked in the UV Editor: the faces it shows are the target, the
        # same as Blender's own unwrap from the 3D View.
        for face in bm.faces:
            try:
                if bool(getattr(face, "hide", False)) or not bool(face.select):
                    continue
            except Exception:
                continue
            selected_faces.add(_face_index(face))
            for loop in face.loops:
                li = _loop_index(loop)
                selected_loops.add(li)
                full_face_loops.add(li)
    change_loops: Set[int] = set(selected_loops) | set(full_face_loops)
    if not change_loops and selected_faces:
        # Fallback only for true face selections that did not expose loop flags.
        for face in bm.faces:
            if _face_index(face) in selected_faces:
                for loop in face.loops:
                    change_loops.add(_loop_index(loop))
    return {
        "obj": obj,
        "bm": bm,
        "uv_layer": uv_layer,
        "faces": selected_faces,
        "change_loops": change_loops,
        "selected_loops": selected_loops,
        "selected_edge_loops": selected_edge_loops,
        "full_face_loops": full_face_loops,
    }

def _capture_protected_uvs(obj: Any, scope: Dict[str, Any]) -> Dict[str, Any]:
    bm = scope.get("bm")
    active = scope.get("uv_layer")
    change_loops: Set[int] = set(scope.get("selected_loops") or scope.get("change_loops") or set())
    # Key UV layers by BMesh UV-layer index, not by layer.name/string. Some
    # Blender 5.1 builds expose transient or duplicate names for BMesh UV layer
    # proxies; name-based restore can put protected non-active-map coordinates
    # back into the active map and undo selected Square/Circle/unwrap results.
    protected: Dict[Tuple[int, int], Tuple[float, float]] = {}
    selection: Dict[int, Tuple[bool, bool]] = {}
    mesh_selection: Dict[str, Dict[int, bool]] = {"faces": {}, "edges": {}, "verts": {}}
    try:
        uv_layers = list(bm.loops.layers.uv)
    except Exception:
        uv_layers = []
    try:
        active_index = uv_layers.index(active)
    except Exception:
        active_index = 0
    for face in bm.faces:
        fi = _face_index(face)
        try:
            mesh_selection["faces"][fi] = bool(face.select)
        except Exception:
            pass
        for edge in getattr(face, "edges", []) or []:
            try:
                mesh_selection["edges"][int(edge.index)] = bool(edge.select)
            except Exception:
                pass
        for vert in getattr(face, "verts", []) or []:
            try:
                mesh_selection["verts"][int(vert.index)] = bool(vert.select)
            except Exception:
                pass
        for pos, loop in enumerate(face.loops):
            li = _loop_index(loop)
            for layer_index, layer in enumerate(uv_layers):
                try:
                    uv = loop[layer].uv.copy()
                except Exception:
                    continue
                if layer_index != active_index or li not in change_loops:
                    protected[(layer_index, fi, int(pos))] = (float(uv.x), float(uv.y))
                    protected[(layer_index, li)] = (float(uv.x), float(uv.y))
            try:
                luv = loop[active]
                selection[li] = (_uv_vert_selected(loop, luv), _uv_edge_selected(loop, luv))
            except Exception:
                pass
    return {"protected": protected, "selection": selection, "mesh_selection": mesh_selection, "active_layer_index": active_index}


def _restore_protected_uvs(obj: Any, snapshot: Dict[str, Any]) -> None:
    import bmesh
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        try:
            uv_layers = list(bm.loops.layers.uv)
        except Exception:
            uv_layers = []
        protected = dict(snapshot.get("protected") or {})
        selection = dict(snapshot.get("selection") or {})
        mesh_selection = dict(snapshot.get("mesh_selection") or {})
        for face in bm.faces:
            fi = _face_index(face)
            try:
                if fi in mesh_selection.get("faces", {}):
                    face.select_set(bool(mesh_selection["faces"][fi]))
            except Exception:
                pass
            for edge in getattr(face, "edges", []) or []:
                try:
                    ei = int(edge.index)
                    if ei in mesh_selection.get("edges", {}):
                        edge.select_set(bool(mesh_selection["edges"][ei]))
                except Exception:
                    pass
            for vert in getattr(face, "verts", []) or []:
                try:
                    vi = int(vert.index)
                    if vi in mesh_selection.get("verts", {}):
                        vert.select_set(bool(mesh_selection["verts"][vi]))
                except Exception:
                    pass
            for pos, loop in enumerate(face.loops):
                li = _loop_index(loop)
                for layer_index, layer in enumerate(uv_layers):
                    key_pos = (layer_index, fi, int(pos))
                    key_idx = (layer_index, li)
                    if key_pos in protected or key_idx in protected:
                        try:
                            u, v = protected.get(key_pos, protected.get(key_idx))
                            loop[layer].uv.x = u
                            loop[layer].uv.y = v
                        except Exception:
                            pass
                try:
                    active = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
                    if li in selection:
                        sel, sel_edge = selection[li]
                        _uv_set_vert_selected(loop, loop[active], bool(sel))
                        _uv_set_edge_selected(loop, loop[active], bool(sel_edge))
                except Exception:
                    pass
        try:
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        except Exception:
            pass
    except Exception:
        pass

def _prepare_native_selection(obj: Any, scope: Dict[str, Any]) -> None:
    import bmesh
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        faces = set(scope.get("faces") or set())
        for vert in bm.verts:
            try:
                vert.select_set(False)
            except Exception:
                pass
        for edge in bm.edges:
            try:
                edge.select_set(False)
            except Exception:
                pass
        for face in bm.faces:
            hit = _face_index(face) in faces
            try:
                face.select_set(hit)
            except Exception:
                pass
            for loop in face.loops:
                try:
                    _uv_set_vert_selected(loop, loop[uv_layer], bool(hit))
                    _uv_set_edge_selected(loop, loop[uv_layer], bool(hit))
                except Exception:
                    pass
                if hit:
                    try:
                        loop.vert.select_set(True)
                    except Exception:
                        pass
                    try:
                        loop.edge.select_set(True)
                    except Exception:
                        pass
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    except Exception:
        pass


def _call_uv_op(op_name: str, **props: Any) -> bool:
    import bpy
    try:
        op = getattr(getattr(bpy.ops, "uv", None), op_name, None)
        if op is None:
            return False
        if op_name == "project_from_view" and getattr(getattr(bpy.context, "area", None), "type", "") != "VIEW_3D":
            # This operator reads the 3D view's matrices, so it needs a 3D View context.
            window = bpy.context.window
            for area in window.screen.areas:
                if area.type == "VIEW_3D":
                    region = next(r for r in area.regions if r.type == "WINDOW")
                    with bpy.context.temp_override(window=window, area=area, region=region):
                        result = op(**props)
                    return "CANCELLED" not in set(result or set())
        result = op(**props)
        return "CANCELLED" not in set(result or set())
    except TypeError:
        try:
            # Blender minor versions can differ in exact keyword support.
            stripped = dict(props)
            for key in ("margin_method", "no_flip", "iterations", "correct_aspect", "fill_holes"):
                stripped.pop(key, None)
            result = getattr(bpy.ops.uv, op_name)(**stripped)
            return "CANCELLED" not in set(result or set())
        except Exception:
            return False
    except Exception:
        return False


def _run_native_method(mode: str) -> bool:
    mode = str(mode or "BLENDER_ANGLE_BASED").upper()
    if mode in {"SMART", "DETAIL", "DETAIL_UNWRAP", "BLENDER_ANGLE_BASED", "SMART_SQUARE", "SMART_CIRCLE"}:
        ok = _call_uv_op("unwrap", method="ANGLE_BASED", margin=0.001, margin_method="SCALED", fill_holes=True, correct_aspect=True, no_flip=True)
        if mode in {"SMART", "DETAIL", "DETAIL_UNWRAP"}:
            _call_uv_op("minimize_stretch", iterations=8)
        return ok
    if mode == "BLENDER_CONFORMAL":
        return _call_uv_op("unwrap", method="CONFORMAL", margin=0.001, margin_method="SCALED", fill_holes=True, correct_aspect=True, no_flip=True)
    if mode == "BLENDER_MIN_STRETCH":
        ok = _call_uv_op("unwrap", method="ANGLE_BASED", margin=0.001, margin_method="SCALED", fill_holes=True, correct_aspect=True, no_flip=True)
        ok2 = _call_uv_op("minimize_stretch", iterations=24)
        return bool(ok or ok2)
    if mode == "BLENDER_SMART_PROJECT":
        return _call_uv_op("smart_project", angle_limit=math.radians(66.0), island_margin=0.001, area_weight=0.0, correct_aspect=True)
    if mode == "BLENDER_LIGHTMAP_PACK":
        return _call_uv_op("lightmap_pack", PREF_CONTEXT="SEL_FACES", PREF_PACK_IN_ONE=True, PREF_NEW_UVLAYER=False, PREF_MARGIN_DIV=0.1)
    if mode == "BLENDER_FOLLOW_ACTIVE_QUADS":
        return _call_uv_op("follow_active_quads", mode="LENGTH_AVERAGE")
    if mode == "BOX_PROJECT":
        return _call_uv_op("cube_project", cube_size=1.0, correct_aspect=True, clip_to_bounds=False, scale_to_bounds=True)
    if mode == "CYLINDRICAL":
        return _call_uv_op("cylinder_project", direction="ALIGN_TO_OBJECT", correct_aspect=True, clip_to_bounds=False, scale_to_bounds=True)
    if mode == "SPHERICAL":
        return _call_uv_op("sphere_project", direction="ALIGN_TO_OBJECT", correct_aspect=True, clip_to_bounds=False, scale_to_bounds=True)
    if mode == "VIEW_PROJECT":
        return _call_uv_op("project_from_view", orthographic=False, correct_aspect=True, clip_to_bounds=False, scale_to_bounds=True)
    # FLAT_MAPPING and QUICK_PLANAR are treated as selected-scope angle unwraps
    # in this final safety layer; non-selected UV data remains protected.
    return _call_uv_op("unwrap", method="ANGLE_BASED", margin=0.001, margin_method="SCALED", fill_holes=True, correct_aspect=True, no_flip=True)


def _run_detail_unwrap(context: Any, scopes: Sequence[Dict[str, Any]]) -> bool:
    """Run the Smart Standard route with its settings, one object at a time."""
    import bmesh
    from . import smart_uv_standard as _standard
    ok = False
    for scope in scopes:
        for other in scopes:
            if other is scope:
                continue
            try:
                # The native solvers act on every object in Edit Mode.
                bm = bmesh.from_edit_mesh(other["obj"].data)
                for face in bm.faces:
                    face.select_set(False)
                bmesh.update_edit_mesh(other["obj"].data, loop_triangles=False, destructive=False)
            except Exception:
                pass
        _prepare_native_selection(scope["obj"], scope)
        try:
            context.view_layer.objects.active = scope["obj"]
        except Exception:
            pass
        # The Smart Standard route reads the hidden UV selection attributes, which
        # stay stale until they are written for this scope.
        write_attrs = _ns().get("_sus_write_final_uv_face_selection_attrs")
        if callable(write_attrs):
            write_attrs(context, scope["obj"], scope.get("faces"))
        if _standard.run_standard_unwrap(context):
            ok = True
    ws = _ws(context)
    if len(scopes) > 1 and _standard._bool(ws, "smart_standard_core_auto_pack", True):
        for scope in scopes:
            _prepare_native_selection(scope["obj"], scope)
        rotate_method = _standard._enum(ws, "smart_standard_core_pack_rotate_method", "ANY")
        _standard._call_pack_islands(
            rotate_method != "NONE" and _standard._enum(ws, "smart_standard_core_baseline_axis", "NONE") == "NONE",
            rotate_method,
            _standard._float(ws, "smart_standard_core_pack_margin", 0.02, 0.0, 1.0),
            _standard._enum(ws, "smart_standard_core_pack_margin_method", "FRACTION"),
        )
    return ok


def _selected_loop_records(obj: Any, faces: Set[int]) -> List[Tuple[Any, Any, Any]]:
    import bmesh
    out: List[Tuple[Any, Any, Any]] = []
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        for face in bm.faces:
            if _face_index(face) not in faces:
                continue
            for loop in face.loops:
                out.append((loop, uv_layer, loop[uv_layer]))
    except Exception:
        return []
    return out


def _normalize_selected_uvs(obj: Any, faces: Set[int], change_loops: Optional[Set[int]] = None, *, margin: float = 0.02) -> bool:
    import bmesh
    from mathutils import Vector
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        allowed = set(change_loops or set())
        loops = []
        for face in bm.faces:
            if _face_index(face) in faces:
                for loop in face.loops:
                    if not allowed or _loop_index(loop) in allowed:
                        loops.append(loop)
        if not loops:
            return False
        pts = [loop[uv_layer].uv.copy() for loop in loops]
        minx = min(float(p.x) for p in pts); maxx = max(float(p.x) for p in pts)
        miny = min(float(p.y) for p in pts); maxy = max(float(p.y) for p in pts)
        spanx = max(1.0e-9, maxx - minx); spany = max(1.0e-9, maxy - miny)
        usable = max(0.001, 1.0 - margin * 2.0)
        for loop in loops:
            uv = loop[uv_layer].uv
            uv.x = margin + ((float(uv.x) - minx) / spanx) * usable
            uv.y = margin + ((float(uv.y) - miny) / spany) * usable
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return True
    except Exception:
        return False


def _shape_square(obj: Any, faces: Set[int], change_loops: Optional[Set[int]] = None) -> bool:
    # Square mode is deterministic: solve selected faces, then fit only selected
    # UV loops to a square canvas while preserving their normalized relative shape.
    return _normalize_selected_uvs(obj, faces, change_loops, margin=0.02)


def _shape_circle(obj: Any, faces: Set[int], change_loops: Optional[Set[int]] = None) -> bool:
    import bmesh
    from mathutils import Vector
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        allowed = set(change_loops or set())
        loops = []
        for face in bm.faces:
            if _face_index(face) in faces:
                for loop in face.loops:
                    if not allowed or _loop_index(loop) in allowed:
                        loops.append(loop)
        if not loops:
            return False
        pts = [loop[uv_layer].uv.copy() for loop in loops]
        cx = (min(float(p.x) for p in pts) + max(float(p.x) for p in pts)) * 0.5
        cy = (min(float(p.y) for p in pts) + max(float(p.y) for p in pts)) * 0.5
        maxr = max(1.0e-9, max(math.sqrt((float(p.x)-cx)**2 + (float(p.y)-cy)**2) for p in pts))
        ordered = []
        for i, loop in enumerate(loops):
            uv = loop[uv_layer].uv
            dx = float(uv.x) - cx
            dy = float(uv.y) - cy
            ang = math.atan2(dy, dx) if (abs(dx) + abs(dy)) > 1.0e-12 else (2.0 * math.pi * i / max(1, len(loops)))
            ordered.append((ang, i, loop))
        ordered.sort(key=lambda item: (item[0], item[1]))
        for rank, (_ang, _i, loop) in enumerate(ordered):
            # Circle mode means the selected UV boundary is actually circular.
            # Use an equal-radius placement and stable angular order so a
            # degenerate native unwrap still produces a valid visible circle.
            ang = 2.0 * math.pi * rank / max(1, len(ordered))
            uv = loop[uv_layer].uv
            uv.x = 0.5 + math.cos(ang) * 0.48
            uv.y = 0.5 + math.sin(ang) * 0.48
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return True
    except Exception:
        return False


def _unitize_faces(obj: Any, faces: Set[int], change_loops: Optional[Set[int]] = None) -> bool:
    import bmesh
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        for face in bm.faces:
            if _face_index(face) not in faces:
                continue
            loops = list(face.loops)
            if len(loops) == 3:
                coords = [(0.0, 0.0), (1.0, 0.0), (0.0, 1.0)]
            else:
                coords = [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)]
            allowed = set(change_loops or set())
            for i, loop in enumerate(loops):
                if allowed and _loop_index(loop) not in allowed:
                    continue
                u, v = coords[i % len(coords)]
                loop[uv_layer].uv.x = float(u)
                loop[uv_layer].uv.y = float(v)
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return True
    except Exception:
        return False


def _selected_uv_signature(scopes: Sequence[Dict[str, Any]]) -> Dict[Tuple[str, int], Tuple[float, float]]:
    import bmesh
    sig: Dict[Tuple[str, int], Tuple[float, float]] = {}
    for scope in scopes:
        obj = scope.get("obj")
        if obj is None:
            continue
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
            name = str(getattr(obj, "name_full", None) or getattr(obj, "name", None) or id(obj))
            change = set(scope.get("change_loops") or set())
            for face in bm.faces:
                for loop in face.loops:
                    li = _loop_index(loop)
                    if li in change:
                        uv = loop[uv_layer].uv
                        sig[(name, li)] = (round(float(uv.x), 8), round(float(uv.y), 8))
        except Exception:
            pass
    return sig


def _signature_changed(before: Dict[Tuple[str, int], Tuple[float, float]], after: Dict[Tuple[str, int], Tuple[float, float]]) -> bool:
    if not before or not after:
        return False
    for key, old in before.items():
        new = after.get(key)
        if new is None:
            continue
        if abs(float(old[0]) - float(new[0])) > 1.0e-7 or abs(float(old[1]) - float(new[1])) > 1.0e-7:
            return True
    return False


def _selected_uvs_flat(scopes: Sequence[Dict[str, Any]]) -> bool:
    """True when the selected UVs have no area to keep (all on a point or a line)."""
    coords = list(_selected_uv_signature(scopes).values())
    if not coords:
        return False
    us = [c[0] for c in coords]
    vs = [c[1] for c in coords]
    return (max(us) - min(us)) <= 1.0e-7 or (max(vs) - min(vs)) <= 1.0e-7


def _direct_planar_project(obj: Any, faces: Set[int], *, margin: float = 0.02) -> bool:
    import bmesh
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        selected_faces = [f for f in bm.faces if _face_index(f) in faces]
        if not selected_faces:
            return False
        # Use the dominant normal component to pick the most stable projection plane.
        nx = ny = nz = 0.0
        for f in selected_faces:
            try:
                n = f.normal
                nx += float(n.x); ny += float(n.y); nz += float(n.z)
            except Exception:
                pass
        ax = max(range(3), key=lambda i: abs((nx, ny, nz)[i]))
        def project(co):
            if ax == 0:
                return (float(co.y), float(co.z))
            if ax == 1:
                return (float(co.x), float(co.z))
            return (float(co.x), float(co.y))
        vals = []
        for f in selected_faces:
            for loop in f.loops:
                vals.append((loop, project(loop.vert.co)))
        if not vals:
            return False
        minx = min(v[0] for _l, v in vals); maxx = max(v[0] for _l, v in vals)
        miny = min(v[1] for _l, v in vals); maxy = max(v[1] for _l, v in vals)
        sx = max(1.0e-9, maxx - minx); sy = max(1.0e-9, maxy - miny)
        usable = max(0.001, 1.0 - margin * 2.0)
        scale = usable / max(sx, sy)
        offx = margin + (usable - sx * scale) * 0.5
        offy = margin + (usable - sy * scale) * 0.5
        for loop, (x, y) in vals:
            luv = loop[uv_layer]
            luv.uv.x = offx + (x - minx) * scale
            luv.uv.y = offy + (y - miny) * scale
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return True
    except Exception:
        return False


def _direct_planar_for_scopes(scopes: Sequence[Dict[str, Any]]) -> bool:
    ok = False
    for scope in scopes:
        obj = scope.get("obj")
        faces = set(scope.get("faces") or set())
        if obj is not None and faces:
            ok = _direct_planar_project(obj, faces) or ok
    return ok


def _direct_shape_after_native(mode: str, scopes: Sequence[Dict[str, Any]]) -> bool:
    ok = False
    mode = str(mode or "").upper()
    for scope in scopes:
        obj = scope.get("obj")
        faces = set(scope.get("faces") or set())
        if not obj or not faces:
            continue
        change_loops = set(scope.get("change_loops") or set())
        if mode == "SMART_SQUARE":
            ok = _shape_square(obj, faces, change_loops) or ok
        elif mode == "SMART_CIRCLE":
            ok = _shape_circle(obj, faces, change_loops) or ok
        elif mode == "UNITIZE_FACES":
            ok = _unitize_faces(obj, faces, change_loops) or ok
    return ok


def _normalise_mode(mode: str) -> str:
    m = str(mode or "BLENDER_ANGLE_BASED").upper()
    if m in {"", "DEFAULT"}:
        return "BLENDER_ANGLE_BASED"
    if m == "SQUARE":
        return "SMART_SQUARE"
    if m in {"CIRCLE", "ROUND"}:
        return "SMART_CIRCLE"
    if m in {"AUTO", "AUTO_SMART", "AUTO_HIGH", "STANDARD", "SMART_PROJECT", "PEEL", "PELT"}:
        return "SMART"
    return m


def _toggle_live_compat(context: Any) -> bool:
    try:
        ts = _tool_settings(context)
        attr = _live_unwrap_attr(ts)
        if not ts or not attr:
            return False
        setattr(ts, attr, not bool(getattr(ts, attr)))
        ws = _ws(context)
        if ws is not None and hasattr(ws, "smart_unwrap_realtime_preview"):
            try:
                ws.smart_unwrap_realtime_preview = bool(getattr(ts, attr))
            except Exception:
                pass
        return True
    except Exception:
        return False



def run_auto_unwrap_mode(ns: Dict[str, Any], context: Any, mode: str) -> bool:
    import bpy
    mode_u = _normalise_mode(mode)
    if mode_u == "LIVE_UNWRAP":
        # The visible UI is consolidated into the realtime toggle, but keep this
        # compatibility route for legacy saved data without exposing a duplicate
        # method item.
        return _toggle_live_compat(context)
    ctx = context or bpy.context
    ws = _ws(ctx)
    objs = _edit_mesh_objects(ctx)
    if not objs:
        return False

    # Capture the current live UV Editor selection before any native UV operator,
    # realtime sync, or property update can flush Blender's hidden UV attributes.
    # This prevents a one-face/one-edge selection from becoming an all-face unwrap.
    old_active = None
    old_active_mode = None
    changed_single = False
    mode_snapshot = _capture_modes(ctx)
    snapshots: List[Tuple[Any, Dict[str, Any]]] = []
    scopes: List[Dict[str, Any]] = []

    def _build_scopes_for_current_edit_objects(external_by_obj: Optional[Dict[str, Dict[str, Set[int]]]] = None) -> Tuple[List[Dict[str, Any]], List[Tuple[Any, Dict[str, Any]]]]:
        built: List[Dict[str, Any]] = []
        snaps: List[Tuple[Any, Dict[str, Any]]] = []
        for obj in (_edit_mesh_objects(ctx) or objs):
            try:
                if str(getattr(obj, "mode", "OBJECT") or "OBJECT") != "EDIT":
                    continue
                _unwrap_channel_index(ws, obj)
                scope = _selection_scope_for_object(ctx, obj)
                if external_by_obj:
                    key = str(getattr(obj, "name_full", None) or getattr(obj, "name", None) or id(obj))
                    scope = _merge_scope_selection(scope, external_by_obj.get(key))
                if scope.get("uv_layer") is None or not scope.get("faces") or not scope.get("change_loops"):
                    continue
                snaps.append((obj, _capture_protected_uvs(obj, scope)))
                built.append(scope)
            except Exception:
                pass
        return built, snaps

    try:
        try:
            old_active = ctx.view_layer.objects.active
            old_active_mode = str(getattr(old_active, "mode", "OBJECT") or "OBJECT") if old_active is not None else None
        except Exception:
            pass

        if all(str(getattr(o, "mode", "OBJECT") or "OBJECT") != "EDIT" for o in objs):
            _old_active2, _old_mode2, changed_single = _ensure_edit_mode(ctx, objs[0])
            objs = _edit_mesh_objects(ctx)

        # Live Edit Mode selection is authoritative.  Only if it is unavailable do
        # we use object-mode hidden .uv_select_* attributes as a fallback.
        scopes, snapshots = _build_scopes_for_current_edit_objects(None)
        if not scopes:
            attr_scopes = _capture_object_mode_uv_selection_scopes(ctx, objs)
            scopes, snapshots = _build_scopes_for_current_edit_objects(attr_scopes)
        if not scopes:
            return False

        _sync_realtime_to_native_live(ctx)

        for scope in scopes:
            try:
                _prepare_native_selection(scope["obj"], scope)
            except Exception:
                pass
        before_sig = _selected_uv_signature(scopes)
        if mode_u == "UNITIZE_FACES":
            ok = _direct_shape_after_native(mode_u, scopes)
        else:
            if mode_u in {"SMART", "DETAIL", "DETAIL_UNWRAP"}:
                ok = _run_detail_unwrap(ctx, scopes)
            else:
                ok = _run_native_method(mode_u)
            after_sig = _selected_uv_signature(scopes)
            if mode_u in {"SMART_SQUARE", "SMART_CIRCLE"}:
                if not _signature_changed(before_sig, after_sig):
                    _direct_planar_for_scopes(scopes)
                ok = _direct_shape_after_native(mode_u, scopes) or ok
            elif mode_u in {"SMART", "DETAIL", "DETAIL_UNWRAP", "BLENDER_ANGLE_BASED", "BLENDER_CONFORMAL", "BLENDER_MIN_STRETCH", "FLAT_MAPPING", "QUICK_PLANAR"}:
                # A solver that ran and returned the same UVs is a stable result, not a failure.
                if (not ok) or (not _signature_changed(before_sig, after_sig) and _selected_uvs_flat(scopes)):
                    ok = _direct_planar_for_scopes(scopes) or ok
        for obj, snap in snapshots:
            _restore_protected_uvs(obj, snap)
        return bool(ok)
    except Exception:
        try:
            for obj, snap in snapshots:
                _restore_protected_uvs(obj, snap)
        except Exception:
            pass
        return False
    finally:
        _restore_modes(mode_snapshot)
        try:
            for obj, snap in snapshots:
                _restore_protected_uvs(obj, snap)
        except Exception:
            pass
        try:
            if old_active is not None:
                ctx.view_layer.objects.active = old_active
        except Exception:
            pass
        try:
            if changed_single and old_active is not None and old_active_mode and old_active_mode != "EDIT":
                bpy.ops.object.mode_set(mode=old_active_mode)
        except Exception:
            pass

def _action_execute(self: Any, context: Any):
    mode = str(getattr(self, "mode", "BLENDER_ANGLE_BASED") or "BLENDER_ANGLE_BASED")
    if not run_auto_unwrap_mode(_ns(), context, mode):
        message = "選択したUV展開方式を選択中エレメントへ適用できませんでした。UVエディターで対象エレメントを選択してください。"
        try:
            translate = _ns().get("_sus_text")
            if callable(translate):
                message = translate(
                    "The selected unwrap method could not be applied to the selected elements. Select the target elements in the UV Editor.",
                    message,
                    context,
                )
        except Exception:
            pass
        try:
            self.report({"WARNING"}, message)
        except Exception:
            pass
        return {"CANCELLED"}
    return {"FINISHED"}


def _run_execute(self: Any, context: Any):
    ws = _ws(context)
    if ws is None:
        ns = _ns()
        message = "このコンテキストではSmart UVのワークスペース設定を取得できません。3DビューポートまたはUVエディターのSmart UV Nパネルから展開実行してください。"
        try:
            translate = ns.get("_sus_text")
            if callable(translate):
                message = translate(
                    "Smart UV workspace settings are not available in this context. Run Execute Unwrap from the Smart UV N-panel in the 3D Viewport or UV Editor.",
                    message,
                    context,
                )
        except Exception:
            pass
        try:
            self.report({"ERROR"}, message)
        except Exception:
            pass
        return {"CANCELLED"}
    mode = "BLENDER_ANGLE_BASED"
    try:
        mode = str(getattr(ws, "auto_unwrap_mode", "BLENDER_ANGLE_BASED") or "BLENDER_ANGLE_BASED")
        if mode.upper() == "LIVE_UNWRAP":
            mode = "BLENDER_ANGLE_BASED"
    except Exception:
        pass
    if not run_auto_unwrap_mode(_ns(), context, mode):
        try:
            translate = _ns().get("_sus_text")
            message = "展開実行に失敗しました。編集モードで展開する面を選んでから実行してください。"
            if callable(translate):
                message = translate("Run Unwrap failed. Select the faces to unwrap in Edit Mode, then run it again.", message, context)
            self.report({"WARNING"}, message)
        except Exception:
            pass
        return {"CANCELLED"}
    return {"FINISHED"}


def _ns() -> Dict[str, Any]:
    import sys
    # This module lives under the package; its parent module is the add-on module.
    parent = __name__.rsplit('.', 1)[0]
    mod = sys.modules.get(parent)
    return getattr(mod, "__dict__", {}) if mod is not None else {}


def _patch_operator_bindings(ns: Dict[str, Any]) -> None:
    global _ORIGINAL_ACTION_EXECUTE, _ORIGINAL_RUN_EXECUTE
    try:
        cls = ns.get("SMARTUVSUITE_OT_unwrap_auto_action")
        if isinstance(cls, type):
            if _ORIGINAL_ACTION_EXECUTE is None:
                _ORIGINAL_ACTION_EXECUTE = getattr(cls, "execute", None)
            cls.execute = _action_execute
            cls._run_mode = lambda self, context, mode: run_auto_unwrap_mode(ns, context, mode)
    except Exception:
        pass
    try:
        cls = ns.get("SMARTUVSUITE_OT_unwrap_auto_run")
        if isinstance(cls, type):
            if _ORIGINAL_RUN_EXECUTE is None:
                _ORIGINAL_RUN_EXECUTE = getattr(cls, "execute", None)
            cls.execute = _run_execute
    except Exception:
        pass


def _patch_mode_items(ns: Dict[str, Any]) -> None:
    items = (
        ("SMART", "詳細展開", "シーム、ピン、選択中マップチャンネルを考慮して、選択中UVエレメント範囲を詳細に展開します。"),
        ("SMART_SQUARE", "四角", "選択中UVエレメント範囲だけを展開し、選択範囲を四角形キャンバスへ収めます。"),
        ("SMART_CIRCLE", "円", "選択中UVエレメント範囲だけを展開し、選択範囲を円形レイアウトへ整えます。"),
        ("FLAT_MAPPING", "Flat", "選択範囲をフラット展開します。"),
        ("BLENDER_ANGLE_BASED", "アングルベースで展開", "Blender標準のAngle Basedで、UVエディター選択範囲だけを展開します。"),
        ("BLENDER_CONFORMAL", "等角で展開", "Blender標準のConformalで、UVエディター選択範囲だけを展開します。"),
        ("BLENDER_MIN_STRETCH", "最小ストレッチで展開", "選択範囲を展開後、最小ストレッチで補正します。"),
        ("BLENDER_SMART_PROJECT", "スマートUV投影", "Blender標準Smart UV Projectを選択範囲だけに適用します。"),
        ("BLENDER_LIGHTMAP_PACK", "ライトマップパック", "選択範囲だけをLightmap Packします。"),
        ("BLENDER_FOLLOW_ACTIVE_QUADS", "アクティブ四角形面に追従", "選択中の四角形面範囲をFollow Active Quadsで展開します。"),
        ("QUICK_PLANAR", "Planar", "選択範囲を平面基準で展開します。"),
        ("BOX_PROJECT", "キューブ投影", "選択範囲だけをキューブ投影します。"),
        ("CYLINDRICAL", "円筒状投影", "選択範囲だけを円筒状投影します。"),
        ("SPHERICAL", "球状投影", "選択範囲だけを球状投影します。"),
        ("VIEW_PROJECT", "View", "現在ビュー基準で選択範囲だけを投影します。"),
        ("UNITIZE_FACES", "Unitize", "選択面を個別に0-1タイルへ配置します。"),
    )
    try:
        ns["_SUS_AUTO_UNWRAP_MODE_ITEMS"] = items
    except Exception:
        pass
    try:
        desc = dict(ns.get("_SUS_AUTO_UNWRAP_DESC") or {})
        desc["SMART"] = ("Detailed unwrap for the current UV Editor selection only.", "現在のUVエディター選択範囲だけを対象にした詳細展開です。")
        desc["SMART_SQUARE"] = ("Square unwrap for the current UV Editor selection only.", "現在のUVエディター選択範囲だけを対象にした四角展開です。")
        desc["SMART_CIRCLE"] = ("Circle unwrap for the current UV Editor selection only.", "現在のUVエディター選択範囲だけを対象にした円展開です。")
        ns["_SUS_AUTO_UNWRAP_DESC"] = desc
    except Exception:
        pass


def _repair_workspace_defaults(context: Any = None) -> None:
    ctx = context or _context()
    ws = _ws(ctx)
    if ws is None:
        return
    allowed = {
        "SMART", "SMART_SQUARE", "SMART_CIRCLE", "FLAT_MAPPING", "BLENDER_ANGLE_BASED", "BLENDER_CONFORMAL",
        "BLENDER_MIN_STRETCH", "BLENDER_SMART_PROJECT", "BLENDER_LIGHTMAP_PACK", "BLENDER_FOLLOW_ACTIVE_QUADS",
        "QUICK_PLANAR", "BOX_PROJECT", "CYLINDRICAL", "SPHERICAL", "VIEW_PROJECT", "UNITIZE_FACES",
    }
    try:
        raw = str(getattr(ws, "auto_unwrap_mode", "") or "").upper()
        # New scenes should default to Angle Based.  Existing explicit user
        # choices are kept except the removed LIVE_UNWRAP method item.
        unset = False
        try:
            unset = hasattr(ws, "is_property_set") and not ws.is_property_set("auto_unwrap_mode")
        except Exception:
            unset = raw in {"", "LIVE_UNWRAP"}
        if unset or raw in {"", "LIVE_UNWRAP"} or raw not in allowed:
            ws.auto_unwrap_mode = "BLENDER_ANGLE_BASED"
    except Exception:
        pass
    # Do not alter Blender native Live Unwrap during add-on registration.
    # The unified toggle syncs when the user changes it, or when 展開実行 runs.


def install(ns: Dict[str, Any], context: Any = None) -> None:
    global _ORIGINAL_RUN, _INSTALLED
    if _ORIGINAL_RUN is None:
        _ORIGINAL_RUN = ns.get("_sus_run_auto_unwrap_mode")
    _patch_mode_items(ns)
    try:
        ns["_sus_run_auto_unwrap_mode"] = lambda ctx, mode: run_auto_unwrap_mode(ns, ctx, mode)
    except Exception:
        pass
    _patch_operator_bindings(ns)
    _repair_workspace_defaults(context)
    _safe_set_version(ns)
    try:
        ns["_SUS_18108_UNWRAP_INTEGRITY_VERSION"] = _PATCH_TEXT
    except Exception:
        pass
    _INSTALLED = True


def unregister() -> None:
    global _INSTALLED
    ns = _ns()
    try:
        if _ORIGINAL_RUN is not None:
            ns["_sus_run_auto_unwrap_mode"] = _ORIGINAL_RUN
    except Exception:
        pass
    try:
        cls = ns.get("SMARTUVSUITE_OT_unwrap_auto_action")
        if isinstance(cls, type) and _ORIGINAL_ACTION_EXECUTE is not None:
            cls.execute = _ORIGINAL_ACTION_EXECUTE
    except Exception:
        pass
    try:
        cls = ns.get("SMARTUVSUITE_OT_unwrap_auto_run")
        if isinstance(cls, type) and _ORIGINAL_RUN_EXECUTE is not None:
            cls.execute = _ORIGINAL_RUN_EXECUTE
    except Exception:
        pass
    _INSTALLED = False
