# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Authoritative Smart UV Suite N-panel routing.

The module owns root panels for eleven Blender spaces and the seventeen logical
editors published by Smart Tools Manager 1.5.55+.  ``Panel.poll`` and ``Panel.draw`` are
read-only.  Registration, persistence and cache preparation only occur at
explicit lifecycle/event boundaries.
"""
from __future__ import annotations

from types import MappingProxyType
from typing import Any
import sys

import bpy

from . import ownership_runtime_18168 as _ownership
from . import stable_ui as _stable_ui
from . import text_translation as _translation

CATEGORY = "Smart UV"
TOOL_KEY = "SMART_UV"
PACKAGE_GLOBALS: dict[str, Any] | None = None
TEARDOWN = False
REGISTERED: list[type] = []

# Manager 1.5.55+ exact logical editor keys -> Blender physical space types.
LOGICAL_TO_PHYSICAL = MappingProxyType({
    "VIEW_3D": "VIEW_3D",
    "IMAGE_EDITOR": "IMAGE_EDITOR",
    "UV_EDITOR": "IMAGE_EDITOR",
    "SHADER_EDITOR": "NODE_EDITOR",
    "COMPOSITOR": "NODE_EDITOR",
    "GEOMETRY_NODE_EDITOR": "NODE_EDITOR",
    "TEXTURE_NODE_EDITOR": "NODE_EDITOR",
    "VIDEO_SEQUENCER": "SEQUENCE_EDITOR",
    "MOVIE_CLIP_EDITOR": "CLIP_EDITOR",
    "DOPE_SHEET": "DOPESHEET_EDITOR",
    "GRAPH_EDITOR": "GRAPH_EDITOR",
    "DRIVERS": "GRAPH_EDITOR",
    "NLA_EDITOR": "NLA_EDITOR",
    "TEXT_EDITOR": "TEXT_EDITOR",
    "ASSET_BROWSER": "FILE_BROWSER",
    "FILE_BROWSER": "FILE_BROWSER",
    "SPREADSHEET": "SPREADSHEET",
})

PHYSICAL_ROOTS = (
    "VIEW_3D", "IMAGE_EDITOR", "NODE_EDITOR", "SEQUENCE_EDITOR",
    "CLIP_EDITOR", "DOPESHEET_EDITOR", "GRAPH_EDITOR", "NLA_EDITOR",
    "TEXT_EDITOR", "FILE_BROWSER", "SPREADSHEET",
)

CANONICAL_SECTIONS = (
    ("Basic Settings", "基本設定", "PREFERENCES"),
    ("UV Unwrap", "UV展開", "UV"),
    ("UV Align", "UV整列", "ORIENTATION_GLOBAL"),
    ("Packing", "パッキング", "PACKAGE"),
    ("Bake", "ベイク", "RESTRICT_RENDER_OFF"),
    ("Operation", "操作", "TOOL_SETTINGS"),
    ("Management", "管理", "FILE_FOLDER"),
    ("Keymap Information", "キーマップ情報", "KEYINGSET"),
)

# Only these explicit module names are inspected.  No sys.modules traversal and
# no import is performed from poll/draw.
_MANAGER_MODULES = (
    "bl_ext.user_default.smart_tools_manager",
    "bl_ext.user_default.smart_tools_manager.manager",
    "bl_ext.user_default.smart_tools_manager.runtime",
    "smart_tools_manager",
    "smart_tools_manager.manager",
    "smart_tools_manager.runtime",
)

_DRAW_SNAPSHOT: MappingProxyType = MappingProxyType({
    "core_module": None,
    "always_on_draw": None,
    "integrated_draw": None,
    "native_draw": None,
})
# Lifecycle-updated last-known decisions.  Poll only reads this immutable map.
_PLACEMENT_SNAPSHOT: MappingProxyType = MappingProxyType({})


def logical_editor_mapping() -> dict[str, str]:
    return dict(LOGICAL_TO_PHYSICAL)


def physical_root_space_types() -> tuple[str, ...]:
    return tuple(PHYSICAL_ROOTS)


def _text(value: Any) -> str:
    try:
        return str(value or "")
    except Exception:
        return ""


def _area_type(context: Any) -> str:
    try:
        return _text(getattr(getattr(context, "area", None), "type", "")).upper()
    except Exception:
        return ""


def _space(context: Any) -> Any:
    try:
        return getattr(context, "space_data", None)
    except Exception:
        return None


def _ui_values(context: Any) -> tuple[str, ...]:
    area = getattr(context, "area", None)
    space = _space(context)
    values: list[str] = []
    for owner, names in (
        (area, ("ui_type",)),
        (space, ("ui_type", "mode", "tree_type", "shader_type", "browse_mode", "view_type", "display_type")),
    ):
        for name in names:
            try:
                value = _text(getattr(owner, name, "")).upper()
            except Exception:
                value = ""
            if value:
                values.append(value)
    try:
        params = getattr(space, "params", None)
        value = _text(getattr(params, "browse_mode", "")).upper()
        if value:
            values.append(value)
    except Exception:
        pass
    return tuple(values)


def context_subtype_for_context(context: Any, physical: str) -> str:
    """Return a deterministic physical subtype without mutating Blender state."""
    physical = _text(physical).upper()
    values = _ui_values(context)
    blob = " ".join(values)
    if physical == "IMAGE_EDITOR":
        return "UV" if ("UV" in values or "UV" == _text(getattr(_space(context), "mode", "")).upper()) else "IMAGE"
    if physical == "NODE_EDITOR":
        if "GEOMETRY" in blob or "GEOMETRYNODETREE" in blob:
            return "GEOMETRY"
        if "COMPOS" in blob:
            return "COMPOSITOR"
        if "TEXTURE" in blob or "TEXTURENODETREE" in blob:
            return "TEXTURE"
        return "SHADER"
    if physical == "GRAPH_EDITOR":
        return "DRIVERS" if "DRIVER" in blob else "GRAPH"
    if physical == "FILE_BROWSER":
        return "ASSET" if "ASSET" in blob else "FILE"
    if physical == "SEQUENCE_EDITOR":
        # Blender uses one physical space for Sequencer, Preview and combined
        # modes.  All map to Manager's VIDEO_SEQUENCER cell, while this subtype
        # keeps the context classification explicit and testable.
        view_type = _text(getattr(_space(context), "view_type", "")).upper()
        ui_type = _text(getattr(getattr(context, "area", None), "ui_type", "")).upper()
        if view_type == "PREVIEW" or ui_type in {"SEQUENCE_EDITOR_PREVIEW", "PREVIEW"}:
            return "PREVIEW"
        if view_type in {"SEQUENCER_PREVIEW", "SEQUENCER_AND_PREVIEW"}:
            return "SEQUENCER_PREVIEW"
        return "SEQUENCER"
    return physical


def logical_editor_for_context(context: Any, physical: str) -> str:
    physical = _text(physical).upper()
    area_type = _area_type(context)
    if area_type and area_type != physical:
        return ""
    subtype = context_subtype_for_context(context, physical)
    if physical == "IMAGE_EDITOR":
        return "UV_EDITOR" if subtype == "UV" else "IMAGE_EDITOR"
    if physical == "NODE_EDITOR":
        return {
            "GEOMETRY": "GEOMETRY_NODE_EDITOR",
            "COMPOSITOR": "COMPOSITOR",
            "TEXTURE": "TEXTURE_NODE_EDITOR",
        }.get(subtype, "SHADER_EDITOR")
    if physical == "GRAPH_EDITOR":
        return "DRIVERS" if subtype == "DRIVERS" else "GRAPH_EDITOR"
    if physical == "FILE_BROWSER":
        return "ASSET_BROWSER" if subtype == "ASSET" else "FILE_BROWSER"
    return {
        "VIEW_3D": "VIEW_3D",
        "SEQUENCE_EDITOR": "VIDEO_SEQUENCER",
        "CLIP_EDITOR": "MOVIE_CLIP_EDITOR",
        "DOPESHEET_EDITOR": "DOPE_SHEET",
        "NLA_EDITOR": "NLA_EDITOR",
        "TEXT_EDITOR": "TEXT_EDITOR",
        "SPREADSHEET": "SPREADSHEET",
    }.get(physical, "")


def _workspace_key(context: Any) -> str:
    try:
        workspace = getattr(context, "workspace", None)
        name = _text(getattr(workspace, "name_full", "") or getattr(workspace, "name", ""))
        return name or "<workspace>"
    except Exception:
        return "<workspace>"


def _placement_callable() -> Any:
    for name in _MANAGER_MODULES:
        module = sys.modules.get(name)
        fn = getattr(module, "placement_allowed", None) if module is not None else None
        if callable(fn):
            return fn
    return None


def _query_placement(fn: Any, context: Any, logical: str) -> bool | None:
    """Call only Manager's public, memory-only placement API.

    The first form is the exact 1.5.55+ signature.  Compatibility forms are
    limited to public ``placement_allowed`` variants and never call readiness,
    registration or persistence APIs.
    """
    if not callable(fn):
        return None
    calls = (
        lambda: fn(TOOL_KEY, context, editor_key=logical),
        lambda: fn(tool_key=TOOL_KEY, context=context, editor_key=logical),
        lambda: fn(TOOL_KEY, context, logical),
        lambda: fn(context=context, tool_key=TOOL_KEY, logical_editor=logical),
    )
    for call in calls:
        try:
            value = call()
        except TypeError:
            continue
        except Exception:
            return None
        if value is None:
            return None
        if _text(value).upper() in {"NOT_READY", "UNAVAILABLE", "UNKNOWN"}:
            return None
        return bool(value)
    return None


def refresh_placement_snapshot(context: Any = None) -> MappingProxyType:
    """Refresh last-known Manager decisions at a lifecycle/event boundary."""
    global _PLACEMENT_SNAPSHOT
    context = context or getattr(bpy, "context", None)
    fn = _placement_callable()
    workspace = _workspace_key(context)
    values = dict(_PLACEMENT_SNAPSHOT)
    for logical, physical in LOGICAL_TO_PHYSICAL.items():
        result = _query_placement(fn, context, logical)
        if result is not None:
            # A logical cell can be represented by multiple physical subtypes.
            # Store the cell decision once and also under each known subtype key.
            values[(workspace, logical)] = bool(result)
            for subtype in _subtypes_for_logical(logical):
                values[(workspace, logical, subtype)] = bool(result)
    _PLACEMENT_SNAPSHOT = MappingProxyType(values)
    return _PLACEMENT_SNAPSHOT


def _subtypes_for_logical(logical: str) -> tuple[str, ...]:
    return {
        "IMAGE_EDITOR": ("IMAGE",),
        "UV_EDITOR": ("UV",),
        "SHADER_EDITOR": ("SHADER",),
        "GEOMETRY_NODE_EDITOR": ("GEOMETRY",),
        "COMPOSITOR": ("COMPOSITOR",),
        "TEXTURE_NODE_EDITOR": ("TEXTURE",),
        "GRAPH_EDITOR": ("GRAPH",),
        "DRIVERS": ("DRIVERS",),
        "FILE_BROWSER": ("FILE",),
        "ASSET_BROWSER": ("ASSET",),
        "VIDEO_SEQUENCER": ("SEQUENCER", "PREVIEW", "SEQUENCER_PREVIEW"),
    }.get(str(logical), (str(LOGICAL_TO_PHYSICAL.get(str(logical), "")),))


def _placement_allowed(context: Any, logical: str, physical: str) -> bool:
    result = _query_placement(_placement_callable(), context, logical)
    if result is not None:
        return bool(result)
    workspace = _workspace_key(context)
    subtype = context_subtype_for_context(context, physical)
    # Manager absent, NOT_READY or exception: use the immutable last-known cell.
    # With no verified state, placement alone fails open as required.
    return bool(_PLACEMENT_SNAPSHOT.get(
        (workspace, logical, subtype),
        _PLACEMENT_SNAPSHOT.get((workspace, logical), True),
    ))


def _poll(context: Any, physical: str) -> bool:
    if TEARDOWN or _area_type(context) != physical:
        return False
    logical = logical_editor_for_context(context, physical)
    return bool(logical and _placement_allowed(context, logical, physical))


def _draw_fallback(layout: Any, context: Any) -> None:
    """Draw the same canonical sections using lifecycle-precomputed UI data."""
    try:
        if _stable_ui.draw_canonical_fallback(layout, context):
            return
    except Exception:
        pass
    # Absolute last-resort UI remains a complete nine-body structure.  It does
    # not hide a failure with HIDE_HEADER or an empty root.
    japanese = bool(getattr(_stable_ui, "_DRAW_IS_JA", False))
    rows = (("Always-on Toggles", "常時機能切り替え", "TIME"),) + CANONICAL_SECTIONS
    for en, ja, icon in rows:
        try:
            box = layout.box()
            box.label(text=ja if japanese else en, icon=icon)
            body = box.column(align=True)
            body.label(
                text=("このセクションの操作は現在利用できません。" if japanese else "Controls in this section are currently unavailable."),
                icon="NONE",
            )
        except Exception:
            continue


def _draw(self: Any, context: Any) -> None:
    layout = getattr(self, "layout", None)
    if layout is None:
        return
    snapshot = _DRAW_SNAPSHOT
    try:
        ok = _stable_ui.draw(
            layout,
            context,
            core_module=snapshot.get("core_module"),
            always_on_draw=snapshot.get("always_on_draw"),
            integrated_draw=snapshot.get("integrated_draw"),
            native_draw=snapshot.get("native_draw"),
        )
    except Exception:
        ok = False
    if not ok:
        _draw_fallback(layout, context)


def _draw_root_header(self, context):
    _stable_ui._draw_help_button(self.layout, context, 'workspace_header', 'Smart UV', 'Smart UV')


def _make_root(name: str, physical: str, *, logical: str | None = None, region: str = "UI") -> type:
    def poll(cls: type, context: Any) -> bool:
        del cls
        return _poll(context, physical) and (
            logical is None or logical_editor_for_context(context, physical) == logical
        )

    logical_mapping = (logical,) if logical else tuple(
        key for key, value in LOGICAL_TO_PHYSICAL.items() if value == physical
    )
    attrs = {
        "bl_idname": f"SMARTUVSUITE_PT_1881_{name.lower()}_body",
        "bl_label": "Smart UV",
        "bl_space_type": physical,
        "bl_region_type": region,
        "bl_category": CATEGORY,
        "bl_order": -21000,
        "poll": classmethod(poll),
        "draw": _draw,
        "draw_header_preset": _draw_root_header,
        "_smart_uv_suite_owner_family": _ownership.OWNER_FAMILY,
        "_smart_uv_suite_full_body_root": True,
        "_smart_tools_manager_native_npanel_root": True,
        "_smart_tools_manager_tool_key": TOOL_KEY,
        "_smart_tools_manager_physical_space": physical,
        "_smart_tools_manager_logical_mapping": logical_mapping,
        "_smart_tools_manager_context_subtypes": MappingProxyType({key: _subtypes_for_logical(key) for key in logical_mapping}),
        "_smart_tools_manager_no_cross_editor_proxy": True,
    }
    return type(f"SMARTUVSUITE_PT_1881_{name}_BODY", (bpy.types.Panel,), attrs)


class SMARTUVSUITE_PT_1881_VIEW3D_BODY(bpy.types.Panel):
    """Public 1.8.163 View3D Panel identity retained as the canonical root."""

    draw_header_preset = _draw_root_header
    bl_idname = "SMARTUVSUITE_PT_1881_view3d_body"
    bl_label = "Smart UV"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = CATEGORY
    bl_order = -21000
    _smart_uv_suite_owner_family = _ownership.OWNER_FAMILY
    _smart_uv_suite_full_body_root = True
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_tool_key = TOOL_KEY
    _smart_tools_manager_physical_space = "VIEW_3D"
    _smart_tools_manager_logical_mapping = ("VIEW_3D",)
    _smart_tools_manager_context_subtypes = MappingProxyType({"VIEW_3D": ("VIEW_3D",)})
    _smart_tools_manager_no_cross_editor_proxy = True

    @classmethod
    def poll(cls, context: Any) -> bool:
        del cls
        return _poll(context, "VIEW_3D")

    def draw(self, context: Any) -> None:
        return _draw(self, context)


class SMARTUVSUITE_PT_1881_UV_EDITOR_BODY(bpy.types.Panel):
    """Public 1.8.163 Image/UV Panel identity retained as one physical root."""

    draw_header_preset = _draw_root_header
    bl_idname = "SMARTUVSUITE_PT_1881_uv_editor_body"
    bl_label = "Smart UV"
    bl_space_type = "IMAGE_EDITOR"
    bl_region_type = "UI"
    bl_category = CATEGORY
    bl_order = -21000
    _smart_uv_suite_owner_family = _ownership.OWNER_FAMILY
    _smart_uv_suite_full_body_root = True
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_tool_key = TOOL_KEY
    _smart_tools_manager_physical_space = "IMAGE_EDITOR"
    _smart_tools_manager_logical_mapping = ("IMAGE_EDITOR", "UV_EDITOR")
    _smart_tools_manager_context_subtypes = MappingProxyType({
        "IMAGE_EDITOR": ("IMAGE",),
        "UV_EDITOR": ("UV",),
    })
    _smart_tools_manager_no_cross_editor_proxy = True

    @classmethod
    def poll(cls, context: Any) -> bool:
        del cls
        return _poll(context, "IMAGE_EDITOR")

    def draw(self, context: Any) -> None:
        return _draw(self, context)


# One physical Image Editor root serves the two Manager logical cells while the
# public 1.8.163 Python class and bl_idname remain unchanged.
SMARTUVSUITE_PT_1881_IMAGE_EDITOR_BODY = SMARTUVSUITE_PT_1881_UV_EDITOR_BODY
PUBLIC_PANEL_ALIASES = MappingProxyType({
    "SMARTUVSUITE_PT_1881_IMAGE_EDITOR_BODY": SMARTUVSUITE_PT_1881_UV_EDITOR_BODY,
})

SMARTUVSUITE_PT_1881_NODE_EDITOR_BODY = _make_root("NODE_EDITOR", "NODE_EDITOR")
SMARTUVSUITE_PT_1881_SEQUENCE_EDITOR_BODY = _make_root("SEQUENCE_EDITOR", "SEQUENCE_EDITOR")
SMARTUVSUITE_PT_1881_CLIP_EDITOR_BODY = _make_root("CLIP_EDITOR", "CLIP_EDITOR")
SMARTUVSUITE_PT_1881_DOPESHEET_EDITOR_BODY = _make_root("DOPESHEET_EDITOR", "DOPESHEET_EDITOR")
SMARTUVSUITE_PT_1881_GRAPH_EDITOR_BODY = _make_root("GRAPH_EDITOR", "GRAPH_EDITOR")
SMARTUVSUITE_PT_1881_NLA_EDITOR_BODY = _make_root("NLA_EDITOR", "NLA_EDITOR")
SMARTUVSUITE_PT_1881_TEXT_EDITOR_BODY = _make_root("TEXT_EDITOR", "TEXT_EDITOR")
SMARTUVSUITE_PT_1881_FILE_BROWSER_BODY = _make_root(
    "FILE_BROWSER", "FILE_BROWSER", logical="FILE_BROWSER"
)
SMARTUVSUITE_PT_1881_ASSET_BROWSER_BODY = _make_root(
    "ASSET_BROWSER", "FILE_BROWSER", logical="ASSET_BROWSER", region="TOOL_PROPS"
)
SMARTUVSUITE_PT_1881_SPREADSHEET_BODY = _make_root("SPREADSHEET", "SPREADSHEET")

ROOTS = (
    SMARTUVSUITE_PT_1881_VIEW3D_BODY,
    SMARTUVSUITE_PT_1881_IMAGE_EDITOR_BODY,
    SMARTUVSUITE_PT_1881_NODE_EDITOR_BODY,
    SMARTUVSUITE_PT_1881_SEQUENCE_EDITOR_BODY,
    SMARTUVSUITE_PT_1881_CLIP_EDITOR_BODY,
    SMARTUVSUITE_PT_1881_DOPESHEET_EDITOR_BODY,
    SMARTUVSUITE_PT_1881_GRAPH_EDITOR_BODY,
    SMARTUVSUITE_PT_1881_NLA_EDITOR_BODY,
    SMARTUVSUITE_PT_1881_TEXT_EDITOR_BODY,
    SMARTUVSUITE_PT_1881_FILE_BROWSER_BODY,
    SMARTUVSUITE_PT_1881_ASSET_BROWSER_BODY,
    SMARTUVSUITE_PT_1881_SPREADSHEET_BODY,
)


def _noop(*_args: Any, **_kwargs: Any) -> None:
    return None


def _patch_package_globals() -> None:
    package_globals = PACKAGE_GLOBALS or {}
    if not package_globals:
        return
    package_globals["_sus_1881_root_classes"] = lambda: tuple(ROOTS)
    package_globals["_sus_1881_is_current_root"] = lambda cls: cls in ROOTS
    package_globals["_SUS_ROOT_NPANEL_CLASS_NAMES"] = tuple(cls.__name__ for cls in ROOTS)
    # Disable only known superseded Smart UV repair entry points.  No Manager or
    # Blender global is modified and no module inventory is scanned.
    for name in (
        "_sus_1642_repair_npanel_body", "_sus_1642_apply_panel_body_state",
        "_sus_ensure_stable_npanel_classes", "_sus_force_smart_uv_panel_body_draws",
        "_sus_disable_duplicate_smart_uv_view3d_panels", "_sus_enforce_single_public_smart_uv_root_per_space",
        "_sus_hide_legacy_source_panels", "_sus_late_disable_duplicate_smart_uv_panels",
        "_sus_schedule_npanel_repair", "_sus_schedule_image_editor_ui_mode_repair",
        "_sus_schedule_smart_tools_manager_patch",
    ):
        package_globals[name] = _noop


def preinstall(package_globals: dict[str, Any] | None = None) -> None:
    global PACKAGE_GLOBALS, _DRAW_SNAPSHOT, TEARDOWN
    if isinstance(package_globals, dict):
        PACKAGE_GLOBALS = package_globals
    source = PACKAGE_GLOBALS or {}
    _DRAW_SNAPSHOT = MappingProxyType({
        "core_module": source.get("_CORE_MODULE"),
        "always_on_draw": None,
        "integrated_draw": None,
        "native_draw": None,
    })
    TEARDOWN = False
    _patch_package_globals()
    refresh_placement_snapshot(getattr(bpy, "context", None))


def install(package_globals: dict[str, Any] | None = None) -> None:
    global PACKAGE_GLOBALS, TEARDOWN
    if isinstance(package_globals, dict):
        PACKAGE_GLOBALS = package_globals
    preinstall(PACKAGE_GLOBALS)
    TEARDOWN = False
    _stable_ui.register()
    registered_now: list[type] = []
    try:
        for cls in ROOTS:
            if not _ownership.register_class(cls):
                raise RuntimeError(f"Smart UV root registration failed: {cls.__name__}")
            if cls not in REGISTERED:
                REGISTERED.append(cls)
            registered_now.append(cls)
    except Exception:
        for cls in reversed(registered_now):
            _ownership.unregister_class(cls)
        raise


def begin_teardown() -> None:
    global TEARDOWN
    TEARDOWN = True


def uninstall() -> None:
    global PACKAGE_GLOBALS, TEARDOWN
    TEARDOWN = True
    for cls in reversed(tuple(REGISTERED)):
        _ownership.unregister_class(cls)
    REGISTERED.clear()
    _stable_ui.unregister()
    PACKAGE_GLOBALS = None


def repair() -> int:
    """Explicit lifecycle repair; never called from draw/poll or a timer."""
    before = len(REGISTERED)
    install(PACKAGE_GLOBALS)
    return max(0, len(REGISTERED) - before)


def schedule(passes: int = 1, *, immediate: bool = True) -> None:
    # Compatibility entry point.  Superseded repair scheduling is intentionally
    # inert; the authoritative manifest performs one synchronous install.
    del passes, immediate
    return None


def cancel() -> None:
    return None


def refresh_standard_body() -> None:
    if not TEARDOWN:
        refresh_placement_snapshot(getattr(bpy, "context", None))
