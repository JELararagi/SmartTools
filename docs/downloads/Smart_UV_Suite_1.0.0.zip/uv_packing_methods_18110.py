# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Smart UV Suite 1.8.119 - deterministic auto packing modes with overlap-group packing.

This runtime layer replaces the old unified-auto-pack dispatch that routed many
visible "自動パッキング方法" entries through the same AABB fallback.  Each exposed
mode now has a distinct selected-UV-face implementation, while keeping the room
requirements: multi-object edit support, selected map channel only, no 3D-view
selection dependency, no standard-gizmo/keymap changes, and no unselected UV
writes.
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import Any, Iterable

import bpy
import bmesh
from mathutils import Matrix, Vector
try:
    from mathutils.geometry import tessellate_polygon as _sus_18119_tessellate_polygon
except Exception:
    _sus_18119_tessellate_polygon = None

_INSTALLED = False
_ORIGINAL_EXECUTE = None
_ORIGINAL_MODE_ITEMS = None
_ORIGINAL_UP_PACK_ITEMS = None
_ORIGINAL_UP_CANONICAL = None
_ORIGINAL_MULTI_EXECUTE = None


def _tr(context, en: str, ja: str) -> str:
    """Select one runtime report string using Smart UV's language policy."""
    try:
        from . import text_translation
        return text_translation.pick(en, ja, context=context)
    except Exception:
        try:
            language = str(getattr(bpy.context.preferences.view, 'language', '') or '').upper()
        except Exception:
            language = ''
        return ja if language.startswith('JA') else en


_MODE_ITEMS_18110 = (
    ('PACK_STANDARD', 'パック', '選択UV面だけを現在のタイルへ標準密度でパックします。島形状を保ったまま、標準余白と標準並び順で整理します。'),
    ('SMART_DENSE', '高密度パック', '選択島を高密度に詰める決定論的パックです。必要に応じて90度回転し、標準パックより使用面積を高めます。'),
    ('FAST_NO_ROTATE', '方向維持パック', '島の現在の向きと形状を保ったまま、回転させず高速にパックします。'),
    ('DENSITY_PRIORITY', '密度優先パック', '元の3D面積に近い相対スケールへ補正してから、選択島を密度優先でパックします。'),
    ('MESH_AREA_SCALE_PACK', '3D面積基準パック', '元の3Dメッシュ面積を基準に各島を形状を崩さず再スケールし、その後パックします。'),
    ('GROUP_SIMILAR', '類似島グループパック', '面積と縦横比が近い島を近い場所にまとめて、グループ単位の棚配置でパックします。'),
    ('GROUP_MATERIAL', 'マテリアル別パック', '選択面のマテリアル番号ごとにパック領域を分け、マテリアル単位で整理します。'),
    ('GROUP_IDENTICAL', '同一島スタック+パック', '同一に近い島を同じUV位置へスタックし、代表島だけをパックします。'),
    ('UDIM_STANDARD', 'UDIMタイルパック', '指定タイル/カーソル/ゼロ基準のUDIMタイルへ、選択島を一括パックします。'),
    ('UDIM_KEEP_TILES', 'UDIM維持パック', '各島が現在属しているUDIMタイルを維持し、タイルごとに内部パックします。'),
    ('UDIM_AUTO_TILES', 'UDIM自動拡張パック', '選択島を必要に応じて複数UDIMタイルへ分配し、各タイル内でパックします。'),
    ('CHART_DISTRIBUTION', '高密度チャート分布パック', '3D面積補正、90度回転、密度重視の並び順で、チャートを高密度に分布パックします。'),
    ('BAKE_SAFE_CHART', 'ベイク安全チャートパック', 'ベイク用に通常より大きい余白を確保し、にじみを避ける安全パックを行います。'),
    ('EXISTING_CHART_REPACK', '既存チャート再パック', '既存島の相対スケールと向きをできるだけ保ち、現在のチャートを再配置します。'),
    ('LOW_DISTORTION_PACK', '低歪み補正パック', '3D面積補正を弱めに適用し、島形状を保ったまま歪みの少ない相対密度でパックします。'),
    ('LIGHTMAP', 'ライトマップパック', 'ライトマップ向けに回転なし・安全余白・グリッド寄せに近い配置で選択島をパックします。'),
    ('HOTSPOT_GRID', 'ホットスポットセル配置', '選択島をホットスポット/トリム用途のグリッドセルへ1島ずつ収めます。'),
    ('TRIM_STRIP', 'トリム帯配置', '帯状・トリムシート向けに、島を横方向のストリップへ並べて配置します。'),
)

_ALIAS_18110 = {
    'PACK': 'PACK_STANDARD',
    'PACK_PRECISION': 'SMART_DENSE',
    'PACK_UDIM': 'UDIM_STANDARD',
    'UDIM': 'UDIM_STANDARD',
    'UDIM_CURSOR': 'UDIM_STANDARD',
    'ATLAS': 'HOTSPOT_GRID',
    'ATLAS_CELL': 'HOTSPOT_GRID',
    'HOTSPOT_FIT': 'HOTSPOT_GRID',
    'NATIVE_CONCAVE': 'PACK_STANDARD',
    'NATIVE_CONVEX': 'SMART_DENSE',
    'NATIVE_AABB': 'FAST_NO_ROTATE',
    'SELECTED_SCOPE_PACK': 'PACK_STANDARD',
    'PIN_LOCKED': 'PACK_STANDARD',
    'RANDOM_SEARCH': 'SMART_DENSE',
}


def _mode_items(self=None, context=None):
    return _MODE_ITEMS_18110


def _canonical(mode: str | None) -> str:
    value = str(mode or 'PACK_STANDARD').upper()
    return _ALIAS_18110.get(value, value)


def _ws(context):
    try:
        return getattr(getattr(context, 'scene', None), 'suv_workspace', None)
    except Exception:
        return None


def _int_attr(obj: Any, name: str, default: int, min_v: int | None = None, max_v: int | None = None) -> int:
    try:
        value = int(getattr(obj, name, default))
    except Exception:
        value = int(default)
    if min_v is not None:
        value = max(int(min_v), value)
    if max_v is not None:
        value = min(int(max_v), value)
    return value


def _float_attr(obj: Any, name: str, default: float, min_v: float | None = None, max_v: float | None = None) -> float:
    try:
        value = float(getattr(obj, name, default))
    except Exception:
        value = float(default)
    if min_v is not None:
        value = max(float(min_v), value)
    if max_v is not None:
        value = min(float(max_v), value)
    return value


def _bool_attr(obj: Any, name: str, default: bool = False) -> bool:
    try:
        return bool(getattr(obj, name, default))
    except Exception:
        return bool(default)


def _str_attr(obj: Any, name: str, default: str = '') -> str:
    try:
        return str(getattr(obj, name, default) or default)
    except Exception:
        return str(default)


def _edit_mesh_objects(context) -> list:
    out = []
    seen = set()
    for seq_name in ('objects_in_mode_unique_data', 'objects_in_mode'):
        try:
            seq = getattr(context, seq_name, None) or []
        except Exception:
            seq = []
        for obj in seq:
            try:
                if obj and getattr(obj, 'type', None) == 'MESH' and str(getattr(obj, 'mode', 'OBJECT')) == 'EDIT' and id(getattr(obj, 'data', None)) not in seen:
                    out.append(obj)
                    seen.add(id(getattr(obj, 'data', None)))
            except Exception:
                pass
    if out:
        return out
    obj = getattr(context, 'edit_object', None) or getattr(context, 'active_object', None)
    if obj is not None and getattr(obj, 'type', None) == 'MESH':
        return [obj]
    return []


def _ensure_edit(context, obj) -> bool:
    try:
        if str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT') == 'EDIT':
            return True
        try:
            context.view_layer.objects.active = obj
        except Exception:
            pass
        bpy.ops.object.mode_set(mode='EDIT')
        return True
    except Exception:
        return str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT') == 'EDIT'


def _read_mesh_bool_attr_values(mesh, name: str, expected: int = 0) -> list[bool]:
    try:
        attrs = getattr(mesh, 'attributes', None)
        attr = attrs.get(name) if attrs is not None else None
        data = getattr(attr, 'data', None) if attr is not None else None
        if data is None:
            return []
        count = len(data) if int(expected or 0) <= 0 else min(int(expected), len(data))
        out = []
        for i in range(count):
            try:
                out.append(bool(getattr(data[i], 'value', False)))
            except Exception:
                out.append(False)
        if int(expected or 0) > count:
            out.extend([False] * (int(expected) - count))
        return out
    except Exception:
        return []


def _mesh_loop_index_for_bmesh_face(mesh, face, local_index: int) -> int:
    try:
        fi = int(getattr(face, 'index', -1))
        poly = getattr(mesh, 'polygons', [])[fi]
        return int(getattr(poly, 'loop_start', 0)) + int(local_index)
    except Exception:
        try:
            return int(getattr(list(face.loops)[local_index], 'index', -1))
        except Exception:
            return -1


def _expand_uv_seed_faces_to_islands(bm, uv_layer, seed_faces: list) -> list:
    seed = {f for f in seed_faces if f is not None}
    if not seed:
        return []
    try:
        islands = _build_pack_topology_islands(bm, uv_layer, list(bm.faces))
        out = []
        seen = set()
        for isl in islands:
            faces_i = list(getattr(isl, 'faces', []) or [])
            if not any(f in seed for f in faces_i):
                continue
            for face in faces_i:
                key = int(getattr(face, 'index', id(face)))
                if key in seen:
                    continue
                seen.add(key)
                out.append(face)
        return out or list(seed_faces)
    except Exception:
        return list(seed_faces)


def _selected_faces_from_uv_editor(obj, bm) -> list:
    """Return UV islands seeded by UV Editor selection, not by 3D View selection."""
    try:
        bm.faces.ensure_lookup_table(); bm.faces.index_update()
        bm.verts.ensure_lookup_table(); bm.verts.index_update()
        bm.edges.ensure_lookup_table(); bm.edges.index_update()
    except Exception:
        pass
    try:
        uv_layer = bm.loops.layers.uv.verify()
    except Exception:
        uv_layer = None
    faces = list(getattr(bm, 'faces', []) or [])
    seed_faces = []
    saw_uv_selection = False

    if uv_layer is not None:
        for face in faces:
            try:
                if bool(getattr(face, 'uv_select', False)):
                    saw_uv_selection = True
                    seed_faces.append(face)
                    continue
                face_has_uv = False
                for loop in face.loops:
                    luv = loop[uv_layer]
                    vsel = bool(getattr(loop, 'uv_select_vert', False) or getattr(luv, 'select', False))
                    esel = bool(getattr(loop, 'uv_select_edge', False) or getattr(luv, 'select_edge', False))
                    face_has_uv = face_has_uv or vsel or esel
                if face_has_uv:
                    saw_uv_selection = True
                    seed_faces.append(face)
            except Exception:
                pass
        if seed_faces:
            return _expand_uv_seed_faces_to_islands(bm, uv_layer, seed_faces)
        if saw_uv_selection:
            return []

    mesh = getattr(obj, 'data', None)
    try:
        poly_count = len(getattr(mesh, 'polygons', []) or [])
        loop_count = len(getattr(mesh, 'loops', []) or [])
    except Exception:
        poly_count = 0; loop_count = 0
    face_flags = _read_mesh_bool_attr_values(mesh, '.uv_select_face', poly_count)
    vert_flags = _read_mesh_bool_attr_values(mesh, '.uv_select_vert', loop_count)
    edge_flags = _read_mesh_bool_attr_values(mesh, '.uv_select_edge', loop_count)
    if any(face_flags) or any(vert_flags) or any(edge_flags):
        for face in faces:
            try:
                fi = int(getattr(face, 'index', -1))
                face_selected = bool(0 <= fi < len(face_flags) and face_flags[fi])
                loop_selected = False
                for local_i, _loop in enumerate(face.loops):
                    li = _mesh_loop_index_for_bmesh_face(mesh, face, local_i)
                    if (0 <= li < len(vert_flags) and vert_flags[li]) or (0 <= li < len(edge_flags) and edge_flags[li]):
                        loop_selected = True
                        break
                if face_selected or loop_selected:
                    seed_faces.append(face)
            except Exception:
                pass
        if seed_faces:
            return _expand_uv_seed_faces_to_islands(bm, uv_layer, seed_faces) if uv_layer is not None else seed_faces
        return []

    return [face for face in faces if bool(getattr(face, 'select', False))]


def _pack_merge_overlaps_enabled(ws) -> bool:
    if ws is None:
        return True
    for name in ('unified_pack_merge_overlap', 'unified_pack_overlap_as_group', 'unified_pack_merge_overlaps', 'unified_pack_merge_overlapping'):
        try:
            if hasattr(ws, name):
                return bool(getattr(ws, name))
        except Exception:
            pass
    return True

def _loop_key(loop) -> tuple[int, int]:
    try:
        face = loop.face
        return int(getattr(face, 'index', -1)), int(list(face.loops).index(loop))
    except Exception:
        return -1, id(loop)


def _uv_polygon_area(loops, uv_layer) -> float:
    pts = [Vector(loop[uv_layer].uv) for loop in loops]
    if len(pts) < 3:
        return 0.0
    area = 0.0
    for i, p in enumerate(pts):
        q = pts[(i + 1) % len(pts)]
        area += p.x * q.y - q.x * p.y
    return abs(area) * 0.5


def _world_face_area(obj, face) -> float:
    """Measure Blender's face triangles after applying the object's linear transform."""
    corners = [loop.vert.co.copy() for loop in face.loops]
    if len(corners) < 3:
        return 0.0

    triangles = [(0, 1, 2)] if len(corners) == 3 else _sus_18119_tessellate_polygon([corners])
    world_matrix = getattr(obj, 'matrix_world', None)
    if world_matrix is not None:
        linear = world_matrix.to_3x3()
        corners = [linear @ corner for corner in corners]

    def double_area(indices):
        first, middle, last = (corners[index] for index in indices)
        return (middle - first).cross(last - first).length

    return math.fsum(double_area(triangle) for triangle in triangles) * 0.5


def _bbox(points: Iterable[Vector]) -> tuple[Vector, Vector] | None:
    pts = list(points)
    if not pts:
        return None
    return Vector((min(p.x for p in pts), min(p.y for p in pts))), Vector((max(p.x for p in pts), max(p.y for p in pts)))


def _uv_layer_for_loop(data: Any, loop: Any):
    try:
        mapping = getattr(data, 'loop_uv_layers', None) or {}
        return mapping.get(id(loop), getattr(data, 'uv_layer', None))
    except Exception:
        return getattr(data, 'uv_layer', None)


def _uv_layer_for_face(data: Any, face: Any):
    try:
        mapping = getattr(data, 'face_uv_layers', None) or {}
        return mapping.get(id(face), getattr(data, 'uv_layer', None))
    except Exception:
        return getattr(data, 'uv_layer', None)


def _object_for_face(data: Any, face: Any):
    try:
        mapping = getattr(data, 'face_objects', None) or {}
        return mapping.get(id(face), getattr(data, 'obj', None))
    except Exception:
        return getattr(data, 'obj', None)


def _aabb_overlap_positive(a_min: Vector, a_max: Vector, b_min: Vector, b_max: Vector, eps: float = 1.0e-10) -> bool:
    try:
        return (min(float(a_max.x), float(b_max.x)) - max(float(a_min.x), float(b_min.x)) > eps and
                min(float(a_max.y), float(b_max.y)) - max(float(a_min.y), float(b_min.y)) > eps)
    except Exception:
        return False


def _poly_signed_area_uv(pts: list[Vector]) -> float:
    if len(pts) < 3:
        return 0.0
    area = 0.0
    for i, p in enumerate(pts):
        q = pts[(i + 1) % len(pts)]
        area += float(p.x) * float(q.y) - float(q.x) * float(p.y)
    return area * 0.5


def _orient_uv(a: Vector, b: Vector, c: Vector) -> float:
    return (float(b.x) - float(a.x)) * (float(c.y) - float(a.y)) - (float(b.y) - float(a.y)) * (float(c.x) - float(a.x))


def _on_segment_uv(p: Vector, a: Vector, b: Vector, eps: float = 1.0e-10) -> bool:
    return (abs(_orient_uv(a, b, p)) <= eps and
            min(float(a.x), float(b.x)) - eps <= float(p.x) <= max(float(a.x), float(b.x)) + eps and
            min(float(a.y), float(b.y)) - eps <= float(p.y) <= max(float(a.y), float(b.y)) + eps)


def _segments_intersect_uv(a: Vector, b: Vector, c: Vector, d: Vector, eps: float = 1.0e-10) -> bool:
    o1 = _orient_uv(a, b, c)
    o2 = _orient_uv(a, b, d)
    o3 = _orient_uv(c, d, a)
    o4 = _orient_uv(c, d, b)
    if o1 * o2 < -eps and o3 * o4 < -eps:
        return True
    return (_on_segment_uv(c, a, b, eps) or _on_segment_uv(d, a, b, eps) or
            _on_segment_uv(a, c, d, eps) or _on_segment_uv(b, c, d, eps))


def _point_in_poly_uv(pt: Vector, poly: list[Vector], eps: float = 1.0e-10) -> bool:
    if len(poly) < 3:
        return False
    inside = False
    x = float(pt.x)
    y = float(pt.y)
    j = len(poly) - 1
    for i, pi in enumerate(poly):
        pj = poly[j]
        if _on_segment_uv(pt, pj, pi, eps):
            return True
        yi = float(pi.y)
        yj = float(pj.y)
        if (yi > y) != (yj > y):
            denom = yj - yi
            if abs(denom) > eps:
                x_int = (float(pj.x) - float(pi.x)) * (y - yi) / denom + float(pi.x)
                if x <= x_int + eps:
                    inside = not inside
        j = i
    return bool(inside)


def _line_intersection_uv(a: Vector, b: Vector, c: Vector, d: Vector) -> Vector:
    ab = b - a
    cd = d - c
    denom = float(ab.x) * float(cd.y) - float(ab.y) * float(cd.x)
    if abs(denom) <= 1.0e-14:
        return Vector(((float(b.x) + float(c.x)) * 0.5, (float(b.y) + float(c.y)) * 0.5))
    t = ((float(c.x) - float(a.x)) * float(cd.y) - (float(c.y) - float(a.y)) * float(cd.x)) / denom
    return a + ab * t


def _convex_clip_uv(subject: list[Vector], clip: list[Vector], eps: float = 1.0e-10) -> list[Vector]:
    if len(subject) < 3 or len(clip) < 3:
        return []
    clip_area = _poly_signed_area_uv(clip)
    if abs(clip_area) <= eps:
        return []
    sign = 1.0 if clip_area >= 0.0 else -1.0
    output = [Vector((float(p.x), float(p.y))) for p in subject]
    for i, a in enumerate(clip):
        b = clip[(i + 1) % len(clip)]

        def inside(p: Vector) -> bool:
            return sign * _orient_uv(a, b, p) >= -eps

        input_list = output
        output = []
        if not input_list:
            break
        prev = input_list[-1]
        prev_inside = inside(prev)
        for cur in input_list:
            cur_inside = inside(cur)
            if cur_inside:
                if not prev_inside:
                    output.append(_line_intersection_uv(prev, cur, a, b))
                output.append(cur)
            elif prev_inside:
                output.append(_line_intersection_uv(prev, cur, a, b))
            prev = cur
            prev_inside = cur_inside
    return output


def _triangulate_uv_polygon(poly: list[Vector]) -> list[list[Vector]]:
    pts = [Vector((float(p.x), float(p.y))) for p in poly]
    if len(pts) < 3:
        return []
    if len(pts) == 3:
        return [pts]
    triangles: list[list[Vector]] = []
    try:
        if callable(_sus_18119_tessellate_polygon):
            indices = _sus_18119_tessellate_polygon([pts])
            for tri in indices:
                if len(tri) >= 3:
                    t = [pts[int(tri[0])], pts[int(tri[1])], pts[int(tri[2])]]
                    if abs(_poly_signed_area_uv(t)) > 1.0e-14:
                        triangles.append(t)
    except Exception:
        triangles = []
    if triangles:
        return triangles
    origin = pts[0]
    for i in range(1, len(pts) - 1):
        t = [origin, pts[i], pts[i + 1]]
        if abs(_poly_signed_area_uv(t)) > 1.0e-14:
            triangles.append(t)
    return triangles


def _triangles_overlap_area_positive(a: list[Vector], b: list[Vector], eps: float = 1.0e-10) -> bool:
    bb_a = _bbox(a)
    bb_b = _bbox(b)
    if bb_a is None or bb_b is None or not _aabb_overlap_positive(bb_a[0], bb_a[1], bb_b[0], bb_b[1], eps):
        return False
    clipped = _convex_clip_uv(a, b, eps)
    return len(clipped) >= 3 and abs(_poly_signed_area_uv(clipped)) > max(eps * eps, 1.0e-14)


def _polygons_overlap_uv(poly_a: list[Vector], poly_b: list[Vector], eps: float = 1.0e-10) -> bool:
    """Return True only when two UV face polygons overlap by positive area.

    Boundary-only contact is intentionally ignored so adjacent islands that only
    touch at an edge or a point remain independent pack units.
    """
    if len(poly_a) < 3 or len(poly_b) < 3:
        return False
    if abs(_poly_signed_area_uv(poly_a)) <= eps or abs(_poly_signed_area_uv(poly_b)) <= eps:
        return False
    bb_a = _bbox(poly_a)
    bb_b = _bbox(poly_b)
    if bb_a is None or bb_b is None or not _aabb_overlap_positive(bb_a[0], bb_a[1], bb_b[0], bb_b[1], eps):
        return False
    tris_a = _triangulate_uv_polygon(poly_a)
    tris_b = _triangulate_uv_polygon(poly_b)
    if not tris_a or not tris_b:
        return False
    if len(tris_a) > len(tris_b):
        tris_a, tris_b = tris_b, tris_a
    sorted_b = sorted(tris_b, key=lambda tri: min(float(p.x) for p in tri))
    for tri_a in tris_a:
        bb_tri_a = _bbox(tri_a)
        if bb_tri_a is None:
            continue
        for tri_b in sorted_b:
            bb_tri_b = _bbox(tri_b)
            if bb_tri_b is None:
                continue
            if float(bb_tri_b[0].x) > float(bb_tri_a[1].x) + eps:
                break
            if float(bb_tri_b[1].x) < float(bb_tri_a[0].x) - eps:
                continue
            if _triangles_overlap_area_positive(tri_a, tri_b, eps):
                return True
    return False

def _island_face_polygons(data: Any) -> list[tuple[Vector, Vector, list[Vector]]]:
    cached = getattr(data, '_suv_overlap_polygons', None)
    if cached is not None:
        return cached
    out: list[tuple[Vector, Vector, list[Vector]]] = []
    for face in list(getattr(data, 'faces', []) or []):
        try:
            layer = _uv_layer_for_face(data, face)
            if layer is None:
                continue
            pts = [Vector(loop[layer].uv) for loop in face.loops]
            if len(pts) < 3 or abs(_poly_signed_area_uv(pts)) <= 1.0e-14:
                continue
            bb = _bbox(pts)
            if bb is None:
                continue
            out.append((bb[0], bb[1], pts))
        except Exception:
            continue
    try:
        setattr(data, '_suv_overlap_polygons', out)
    except Exception:
        pass
    return out


def _island_uvs_overlap(a: Any, b: Any) -> bool:
    if not _aabb_overlap_positive(a.min_uv, a.max_uv, b.min_uv, b.max_uv):
        return False
    polys_a = _island_face_polygons(a)
    polys_b = _island_face_polygons(b)
    if not polys_a or not polys_b:
        return False
    if len(polys_a) > len(polys_b):
        polys_a, polys_b = polys_b, polys_a
    sorted_b = sorted(polys_b, key=lambda item: float(item[0].x))
    for amin, amax, apoly in polys_a:
        for bmin, bmax, bpoly in sorted_b:
            if float(bmin.x) > float(amax.x) + 1.0e-10:
                break
            if float(bmax.x) < float(amin.x) - 1.0e-10:
                continue
            if _aabb_overlap_positive(amin, amax, bmin, bmax) and _polygons_overlap_uv(apoly, bpoly):
                return True
    return False


def _merge_island_group(members: list, index: int):
    if len(members) == 1:
        data = members[0]
        data.index = index
        data.refresh()
        return data
    faces = []
    loops = []
    face_seen = set()
    loop_seen = set()
    face_uv_layers = {}
    loop_uv_layers = {}
    face_objects = {}
    for data in members:
        for face in list(getattr(data, 'faces', []) or []):
            fkey = (id(_object_for_face(data, face)), id(face))
            if fkey not in face_seen:
                face_seen.add(fkey)
                faces.append(face)
            face_uv_layers[id(face)] = _uv_layer_for_face(data, face)
            face_objects[id(face)] = _object_for_face(data, face)
        for loop in list(getattr(data, 'loops', []) or []):
            layer = _uv_layer_for_loop(data, loop)
            lkey = (id(loop), id(layer))
            if lkey in loop_seen:
                continue
            loop_seen.add(lkey)
            loops.append(loop)
            loop_uv_layers[id(loop)] = layer
    base = members[0]
    merged = IslandData(
        obj=getattr(base, 'obj', None),
        bm=getattr(base, 'bm', None),
        uv_layer=getattr(base, 'uv_layer', None),
        faces=faces,
        loops=loops,
        index=index,
        face_uv_layers=face_uv_layers,
        loop_uv_layers=loop_uv_layers,
        face_objects=face_objects,
    )
    try:
        setattr(merged, 'overlap_group_size', len(members))
    except Exception:
        pass
    merged.refresh()
    return merged


def _merge_overlapping_islands(islands: list) -> list:
    """Merge any selected UV islands that overlap in the UV editor.

    The merged unit is packed as one island while preserving member islands'
    relative UV positions.  This keeps stacked or partially-overlapping charts
    together instead of separating them during automatic packing.
    """
    if len(islands) < 2:
        return islands
    for data in islands:
        try:
            data.refresh()
            if hasattr(data, '_suv_overlap_polygons'):
                delattr(data, '_suv_overlap_polygons')
        except Exception:
            pass
    n = len(islands)
    parent = list(range(n))
    rank = [0] * n

    def find(i: int) -> int:
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    def union(a: int, b: int) -> None:
        ra = find(a)
        rb = find(b)
        if ra == rb:
            return
        if rank[ra] < rank[rb]:
            ra, rb = rb, ra
        parent[rb] = ra
        if rank[ra] == rank[rb]:
            rank[ra] += 1

    eps = 1.0e-10
    ordered = sorted(range(n), key=lambda i: (float(islands[i].min_uv.x), float(islands[i].min_uv.y), i))
    active: list[int] = []
    for ib in ordered:
        cur = islands[ib]
        active = [ia for ia in active if float(islands[ia].max_uv.x) - float(cur.min_uv.x) > eps]
        for ia in active:
            other = islands[ia]
            if _aabb_overlap_positive(other.min_uv, other.max_uv, cur.min_uv, cur.max_uv, eps) and _island_uvs_overlap(other, cur):
                union(ia, ib)
        active.append(ib)

    groups: dict[int, list] = {}
    first_index: dict[int, int] = {}
    for i, data in enumerate(islands):
        root = find(i)
        groups.setdefault(root, []).append(data)
        first_index[root] = min(first_index.get(root, i), i)
    if all(len(group) == 1 for group in groups.values()):
        for i, data in enumerate(islands):
            data.index = i
            try:
                data.refresh()
            except Exception:
                pass
        return islands
    merged = []
    for new_index, root in enumerate(sorted(groups, key=lambda r: first_index.get(r, r))):
        merged.append(_merge_island_group(sorted(groups[root], key=lambda item: getattr(item, 'index', 0)), new_index))
    return merged


@dataclass
class IslandData:
    obj: Any
    bm: Any
    uv_layer: Any
    faces: list
    loops: list
    index: int
    material_index: int = 0
    uv_area: float = 0.0
    mesh_area: float = 0.0
    min_uv: Vector = field(default_factory=lambda: Vector((0.0, 0.0)))
    max_uv: Vector = field(default_factory=lambda: Vector((0.0, 0.0)))
    tile: tuple[int, int] = (0, 0)
    rotate_90: bool = False
    stack_key: tuple = field(default_factory=tuple)
    loop_uv_layers: dict = field(default_factory=dict, repr=False)
    face_uv_layers: dict = field(default_factory=dict, repr=False)
    face_objects: dict = field(default_factory=dict, repr=False)

    def refresh(self) -> None:
        pts = []
        for loop in self.loops:
            try:
                layer = _uv_layer_for_loop(self, loop)
                if layer is not None:
                    pts.append(Vector(loop[layer].uv))
            except Exception:
                pass
        bb = _bbox(pts)
        if bb is None:
            self.min_uv = Vector((0.0, 0.0)); self.max_uv = Vector((0.0, 0.0))
        else:
            self.min_uv, self.max_uv = bb
        self.uv_area = sum(_uv_polygon_area(face.loops, _uv_layer_for_face(self, face)) for face in self.faces if _uv_layer_for_face(self, face) is not None)
        self.mesh_area = sum(_world_face_area(_object_for_face(self, face), face) for face in self.faces)
        self.material_index = int(getattr(self.faces[0], 'material_index', 0) or 0) if self.faces else 0
        self.tile = (int(math.floor(float(self.min_uv.x))), int(math.floor(float(self.min_uv.y))))
        w = max(float(self.max_uv.x - self.min_uv.x), 1.0e-10)
        h = max(float(self.max_uv.y - self.min_uv.y), 1.0e-10)
        self.stack_key = (len(self.faces), len(self.loops), round(max(w, h) / max(min(w, h), 1.0e-10), 3), round(self.uv_area / max(w * h, 1.0e-10), 3))

    @property
    def width(self) -> float:
        return max(float(self.max_uv.x - self.min_uv.x), 1.0e-10)

    @property
    def height(self) -> float:
        return max(float(self.max_uv.y - self.min_uv.y), 1.0e-10)

    @property
    def center(self) -> Vector:
        return (self.min_uv + self.max_uv) * 0.5



def _uv_edge_points_for_pack(face, edge, uv_layer):
    try:
        for loop in face.loops:
            if loop.edge == edge:
                # UV of edge.verts[0], then edge.verts[1], so two faces can be compared vertex by vertex.
                a, b = Vector(loop[uv_layer].uv), Vector(loop.link_loop_next[uv_layer].uv)
                return (a, b) if loop.vert == edge.verts[0] else (b, a)
    except Exception:
        pass
    return None, None


def _pack_uv_close(a: Vector, b: Vector, eps: float = 1.0e-5) -> bool:
    try:
        return (Vector(a) - Vector(b)).length <= float(eps)
    except Exception:
        return False


def _build_pack_topology_islands(bm, uv_layer, faces_subset) -> list:
    """Build UV islands by mesh topology and matching shared-edge UVs only.

    This deliberately does not merge islands merely because their UV polygons
    overlap.  Overlap-as-one-island is a separate Auto Pack setting and is
    applied later only when that setting is enabled.
    """
    faces = list(faces_subset or [])
    face_set = set(faces)
    visited = set()
    try:
        bm.edges.ensure_lookup_table()
    except Exception:
        pass

    class _PackIsland:
        __slots__ = ('faces',)
        def __init__(self, faces):
            self.faces = faces

    def neighbors(face):
        try:
            loops = list(face.loops)
        except Exception:
            loops = []
        for loop in loops:
            edge = getattr(loop, 'edge', None)
            if edge is None or bool(getattr(edge, 'seam', False)):
                continue
            try:
                linked = list(edge.link_faces)
            except Exception:
                linked = []
            if len(linked) != 2:
                continue
            other = linked[0] if linked[1] == face else linked[1]
            if other not in face_set:
                continue
            a0, a1 = _uv_edge_points_for_pack(face, edge, uv_layer)
            b0, b1 = _uv_edge_points_for_pack(other, edge, uv_layer)
            if a0 is None or b0 is None:
                continue
            if _pack_uv_close(a0, b0) and _pack_uv_close(a1, b1):
                yield other

    islands = []
    for face in faces:
        if face in visited:
            continue
        stack = [face]
        visited.add(face)
        group = []
        while stack:
            cur = stack.pop()
            group.append(cur)
            for nb in neighbors(cur):
                if nb not in visited:
                    visited.add(nb)
                    stack.append(nb)
        if group:
            islands.append(_PackIsland(group))
    return islands

def _collect_islands(context) -> tuple[list[IslandData], dict, dict, list]:
    objects = _edit_mesh_objects(context)
    all_islands: list[IslandData] = []
    bm_by_obj = {}
    uv_by_obj = {}
    original = {}
    selected_keys = set()
    idx = 0
    for obj in objects:
        if not _ensure_edit(context, obj):
            continue
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.verify()
            try:
                bm.faces.ensure_lookup_table(); bm.faces.index_update()
            except Exception:
                pass
            faces = _selected_faces_from_uv_editor(obj, bm)
            if not faces:
                continue
            # Snapshot every active-UV loop.  This lets the pack path restore any
            # accidental unselected write from Blender fallback code or old patches.
            for face in bm.faces:
                for loop in face.loops:
                    original[(obj, int(getattr(face, 'index', -1)), int(list(face.loops).index(loop)))] = Vector(loop[uv_layer].uv)
            try:
                islands = _build_pack_topology_islands(bm, uv_layer, faces)
            except Exception:
                islands = []
            if not islands:
                class _FaceIsland:
                    pass
                islands = []
                for face in faces:
                    isl = _FaceIsland(); isl.faces = [face]; islands.append(isl)
            for isl in islands:
                faces_i = list(getattr(isl, 'faces', []) or [])
                if not faces_i:
                    continue
                loops = []
                seen = set()
                for face in faces_i:
                    for loop in face.loops:
                        key = _loop_key(loop)
                        if key in seen:
                            continue
                        seen.add(key)
                        loops.append(loop)
                        selected_keys.add((obj, key[0], key[1]))
                if not loops:
                    continue
                data = IslandData(obj=obj, bm=bm, uv_layer=uv_layer, faces=faces_i, loops=loops, index=idx)
                data.loop_uv_layers = {id(loop): uv_layer for loop in loops}
                data.face_uv_layers = {id(face): uv_layer for face in faces_i}
                data.face_objects = {id(face): obj for face in faces_i}
                data.face_bmeshes = {id(face): bm for face in faces_i}
                data.refresh()
                all_islands.append(data)
                idx += 1
            bm_by_obj[obj] = bm
            uv_by_obj[obj] = uv_layer
        except Exception:
            continue
    return all_islands, original, selected_keys, objects


def _restore_unselected(original: dict, selected_keys: set, bm_objects: Iterable) -> None:
    for obj in bm_objects:
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.verify()
            try:
                bm.faces.ensure_lookup_table(); bm.faces.index_update()
            except Exception:
                pass
            for face in bm.faces:
                fi = int(getattr(face, 'index', -1))
                for li, loop in enumerate(face.loops):
                    key = (obj, fi, int(li))
                    if key not in selected_keys and key in original:
                        loop[uv_layer].uv = Vector(original[key])
        except Exception:
            pass


def _update_objects(objects: Iterable) -> None:
    for obj in objects:
        try:
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        except Exception:
            pass


def _rescale_to_mesh_area(islands: list[IslandData], *, strength: float = 1.0) -> None:
    if not islands:
        return
    total_mesh = sum(max(d.mesh_area, 0.0) for d in islands)
    total_uv = sum(max(d.uv_area, 0.0) for d in islands)
    if total_mesh <= 1.0e-12 or total_uv <= 1.0e-12:
        return
    strength = max(0.0, min(1.0, float(strength)))
    for data in islands:
        current = max(float(data.uv_area), 1.0e-12)
        target = max(total_uv * (max(data.mesh_area, 0.0) / total_mesh), 1.0e-12)
        factor = math.sqrt(target / current)
        if strength < 1.0:
            factor = 1.0 + (factor - 1.0) * strength
        factor = max(1.0e-8, min(factor, 1.0e8))
        center = Vector(data.center)
        for loop in data.loops:
            try:
                layer = _uv_layer_for_loop(data, loop)
                if layer is None:
                    continue
                uv = Vector(loop[layer].uv)
                loop[layer].uv = center + (uv - center) * factor
            except Exception:
                pass
    for data in islands:
        data.refresh()


def _target_tile(context, ws, mode: str) -> tuple[int, int]:
    if mode == 'UDIM_STANDARD':
        target = _str_attr(ws, 'unified_pack_target_tile', 'ZERO').upper()
        if target == 'CURSOR':
            try:
                loc = getattr(getattr(context, 'space_data', None), 'cursor_location', None)
                if loc is not None:
                    return int(math.floor(float(loc[0]))), int(math.floor(float(loc[1])))
            except Exception:
                pass
        if target == 'EXPLICIT':
            return _int_attr(ws, 'unified_pack_tile_u', 0), _int_attr(ws, 'unified_pack_tile_v', 0)
    if _str_attr(ws, 'unified_pack_target_tile', 'ZERO').upper() == 'EXPLICIT':
        return _int_attr(ws, 'unified_pack_tile_u', 0), _int_attr(ws, 'unified_pack_tile_v', 0)
    return 0, 0


def _margin(ws, *, multiplier: float = 1.0, bake_safe: bool = False) -> float:
    tex = max(1, _int_attr(ws, 'canvas_size', 2048, 1, 65536))
    margin_uv = _float_attr(ws, 'unified_pack_margin', 0.001, 0.0, 0.5)
    margin_px = _int_attr(ws, 'unified_pack_margin_px', _int_attr(ws, 'fit_padding_px', 8, 0, 512), 0, 4096)
    if bake_safe:
        margin_px = max(margin_px, 2 * _int_attr(ws, 'unified_pack_bake_padding_px', 4, 0, 2048))
    return max(0.0, min(0.45, max(margin_uv, float(margin_px) / float(tex)) * float(multiplier)))


def _pack_shelf(rects: list[dict], width: float, height: float, margin: float, *, fill: float = 0.88, sort_mode: str = 'AREA') -> list[tuple[int, float, float, float]]:
    if not rects:
        return []
    if sort_mode == 'INDEX':
        ordered = sorted(rects, key=lambda r: int(r['index']))
    elif sort_mode == 'ASPECT':
        ordered = sorted(rects, key=lambda r: (-max(r['w'], r['h']) / max(min(r['w'], r['h']), 1.0e-10), -r['w'] * r['h'], r['index']))
    elif sort_mode == 'HEIGHT':
        ordered = sorted(rects, key=lambda r: (-r['h'], -r['w'], r['index']))
    else:
        ordered = sorted(rects, key=lambda r: (-(r['w'] * r['h']), -max(r['w'], r['h']), r['index']))
    total_area = sum(max(r['w'], 1.0e-10) * max(r['h'], 1.0e-10) for r in rects)
    base = math.sqrt((max(width, 1.0e-10) * max(height, 1.0e-10) * max(0.05, min(0.98, fill))) / max(total_area, 1.0e-12))
    if not math.isfinite(base):
        base = 1.0
    base = max(1.0e-8, min(base, 1.0e8))
    scaled = [{**r, 'w': max(r['w'] * base, 1.0e-10), 'h': max(r['h'] * base, 1.0e-10)} for r in ordered]
    x = margin; y = margin; shelf_h = 0.0; max_x = margin
    placements = {}
    for r in scaled:
        w = max(float(r['w']), 1.0e-10); h = max(float(r['h']), 1.0e-10)
        if x > margin and x + w + margin > width:
            x = margin
            y += shelf_h + margin
            shelf_h = 0.0
        placements[int(r['index'])] = (x, y)
        x += w + margin
        shelf_h = max(shelf_h, h)
        max_x = max(max_x, x)
    used_w = max(max_x + margin, margin * 2.0 + 1.0e-10)
    used_h = max(y + shelf_h + margin, margin * 2.0 + 1.0e-10)
    fit = min(width / used_w, height / used_h, 1.0)
    out = []
    for r in rects:
        px, py = placements.get(int(r['index']), (margin, margin))
        out.append((int(r['index']), px * fit, py * fit, base * fit))
    return out


def _rect_for(data: IslandData, rotate: bool) -> tuple[float, float]:
    w, h = data.width, data.height
    return (h, w) if rotate else (w, h)


def _apply_placement(data: IslandData, dst_origin: Vector, scale: float, *, rotate: bool = False) -> None:
    center = Vector(data.center)
    rotated = []
    for loop in data.loops:
        try:
            layer = _uv_layer_for_loop(data, loop)
            if layer is None:
                continue
            uv = Vector(loop[layer].uv)
            if rotate:
                rel = uv - center
                uv = center + Vector((-rel.y, rel.x))
            rotated.append((loop, layer, uv))
        except Exception:
            continue
    bb = _bbox([uv for _loop, _layer, uv in rotated])
    if bb is None:
        return
    src_min, _src_max = bb
    for loop, layer, uv in rotated:
        try:
            loop[layer].uv = dst_origin + (uv - src_min) * max(float(scale), 1.0e-12)
        except Exception:
            pass


def _standard_rect_pack(islands: list[IslandData], ws, context, mode: str, *, target_tile: tuple[int, int] | None = None, margin_override: float | None = None, fill: float | None = None, sort_mode: str = 'AREA', allow_rotate: bool | None = None, force_no_rotate: bool = False) -> bool:
    if not islands:
        return False
    tile_u, tile_v = target_tile if target_tile is not None else _target_tile(context, ws, mode)
    margin = _margin(ws) if margin_override is None else max(0.0, min(0.45, float(margin_override)))
    usable_min = Vector((int(tile_u) + margin, int(tile_v) + margin))
    usable_w = max(1.0e-9, 1.0 - 2.0 * margin)
    usable_h = max(1.0e-9, 1.0 - 2.0 * margin)
    if allow_rotate is None:
        allow_rotate = _bool_attr(ws, 'unified_pack_rotate', True)
    if force_no_rotate:
        allow_rotate = False
    rects = []
    for i, data in enumerate(islands):
        rotate = False
        if allow_rotate:
            # Deterministic 90-degree only.  This is safe, visible, and avoids
            # Blender operator recursion while keeping island shape intact.
            if data.height > data.width * 1.25:
                rotate = True
        data.rotate_90 = rotate
        w, h = _rect_for(data, rotate)
        rects.append({'index': i, 'w': w, 'h': h})
    placements = _pack_shelf(rects, usable_w, usable_h, margin, fill=fill if fill is not None else 0.86, sort_mode=sort_mode)
    if not placements:
        return False
    placement_map = {idx: (x, y, sc) for idx, x, y, sc in placements}
    for i, data in enumerate(islands):
        x, y, sc = placement_map.get(i, (margin, margin, 1.0))
        _apply_placement(data, usable_min + Vector((x, y)), sc, rotate=bool(data.rotate_90))
    return True


def _pack_by_groups(islands: list[IslandData], ws, context, mode: str, key_fn, *, group_sort='KEY', margin_mult=1.0) -> bool:
    if not islands:
        return False
    groups = {}
    for data in islands:
        groups.setdefault(key_fn(data), []).append(data)
    items = sorted(groups.items(), key=lambda kv: str(kv[0]) if group_sort == 'KEY' else -sum(d.width * d.height for d in kv[1]))
    base_margin = _margin(ws, multiplier=margin_mult)
    tile_u, tile_v = _target_tile(context, ws, mode)
    n = max(1, len(items))
    band_h = max(1.0e-9, (1.0 - 2.0 * base_margin) / n)
    for row_i, (_key, subset) in enumerate(items):
        local_margin = min(base_margin, band_h * 0.25)
        usable_min = Vector((tile_u + local_margin, tile_v + base_margin + row_i * band_h + local_margin))
        usable_w = max(1.0e-9, 1.0 - 2.0 * local_margin)
        usable_h = max(1.0e-9, band_h - 2.0 * local_margin)
        rects = []
        for i, data in enumerate(subset):
            rotate = _bool_attr(ws, 'unified_pack_rotate', True) and data.height > data.width * 1.25
            data.rotate_90 = rotate
            w, h = _rect_for(data, rotate)
            rects.append({'index': i, 'w': w, 'h': h})
        placements = _pack_shelf(rects, usable_w, usable_h, local_margin, fill=0.84, sort_mode='AREA')
        for i, x, y, sc in placements:
            data = subset[int(i)]
            _apply_placement(data, usable_min + Vector((x, y)), sc, rotate=bool(data.rotate_90))
    return True


def _pack_identical_stack(islands: list[IslandData], ws, context, mode: str) -> bool:
    if not islands:
        return False
    stacks = {}
    for data in islands:
        stacks.setdefault(data.stack_key, []).append(data)
    reps = [vals[0] for _key, vals in sorted(stacks.items(), key=lambda kv: (-sum(d.width * d.height for d in kv[1]), str(kv[0])))]
    if not _standard_rect_pack(reps, ws, context, mode, fill=0.90, sort_mode='AREA'):
        return False
    for key, vals in stacks.items():
        rep = vals[0]
        # Stack every non-representative onto the representative's current bbox,
        # preserving each island shape with a uniform transform into the same box.
        dst_min, dst_max = rep.min_uv, rep.max_uv
        # Refresh rep after placement.
        rep.refresh(); dst_min, dst_max = rep.min_uv, rep.max_uv
        dst_w, dst_h = rep.width, rep.height
        for other in vals[1:]:
            other.refresh()
            scale = min(dst_w / max(other.width, 1.0e-10), dst_h / max(other.height, 1.0e-10))
            _apply_placement(other, Vector(dst_min), scale, rotate=False)
    return True


def _pack_keep_tiles(islands: list[IslandData], ws, context, mode: str) -> bool:
    if not islands:
        return False
    groups = {}
    for data in islands:
        groups.setdefault(data.tile, []).append(data)
    ok = False
    for tile, subset in groups.items():
        if _standard_rect_pack(subset, ws, context, mode, target_tile=tile, fill=0.84, sort_mode='AREA'):
            ok = True
    return ok


def _pack_auto_tiles(islands: list[IslandData], ws, context, mode: str) -> bool:
    if not islands:
        return False
    cols = max(1, _int_attr(ws, 'unified_pack_tile_columns', 10, 1, 100))
    # Distribute by accumulated source area.  This visibly differs from a single
    # tile pack and honors the automatic-UDIM meaning without relying on external
    # Pack Pro operators.
    ordered = sorted(islands, key=lambda d: (-(d.width * d.height), d.index))
    per_tile = max(1, int(math.ceil(len(ordered) / max(1, min(cols, len(ordered))))))
    ok = False
    for i in range(0, len(ordered), per_tile):
        tile_index = i // per_tile
        tile = (tile_index % cols, tile_index // cols)
        subset = ordered[i:i + per_tile]
        if _standard_rect_pack(subset, ws, context, mode, target_tile=tile, fill=0.82, sort_mode='AREA'):
            ok = True
    return ok


def _pack_hotspot_grid(islands: list[IslandData], ws, context, mode: str) -> bool:
    if not islands:
        return False
    cols = max(1, _int_attr(ws, 'hotspot_cols', 4, 1, 64))
    rows = max(1, _int_attr(ws, 'hotspot_rows', 4, 1, 64))
    margin = _margin(ws, multiplier=1.0)
    tile_u, tile_v = _target_tile(context, ws, mode)
    cell_w = max(1.0e-9, (1.0 - 2.0 * margin) / cols)
    cell_h = max(1.0e-9, (1.0 - 2.0 * margin) / rows)
    for n, data in enumerate(sorted(islands, key=lambda d: (-(d.width * d.height), d.index))):
        c = n % cols
        r = (n // cols) % rows
        cell_min = Vector((tile_u + margin + c * cell_w + margin * 0.25, tile_v + margin + r * cell_h + margin * 0.25))
        target_w = max(1.0e-9, cell_w - margin * 0.5)
        target_h = max(1.0e-9, cell_h - margin * 0.5)
        scale = min(target_w / data.width, target_h / data.height)
        _apply_placement(data, cell_min, scale, rotate=False)
    return True


def _pack_trim_strip(islands: list[IslandData], ws, context, mode: str) -> bool:
    if not islands:
        return False
    margin = _margin(ws, multiplier=1.0)
    tile_u, tile_v = _target_tile(context, ws, mode)
    # Sort strips from tall to short and give every island a consistent strip height.
    ordered = sorted(islands, key=lambda d: (-d.height, d.index))
    strips = max(1, min(8, int(math.ceil(math.sqrt(len(ordered))))))
    strip_h = max(1.0e-9, (1.0 - 2.0 * margin) / strips)
    x_by_strip = [tile_u + margin for _ in range(strips)]
    for i, data in enumerate(ordered):
        strip = i % strips
        dst_h = max(1.0e-9, strip_h - margin)
        scale = dst_h / data.height
        w = data.width * scale
        if x_by_strip[strip] + w + margin > tile_u + 1.0:
            x_by_strip[strip] = tile_u + margin
        y = tile_v + margin + strip * strip_h + margin * 0.5
        _apply_placement(data, Vector((x_by_strip[strip], y)), scale, rotate=False)
        x_by_strip[strip] += w + margin
    return True


def _run_mode(context, ws, mode: str, islands: list[IslandData]) -> bool:
    mode = _canonical(mode)
    if not islands:
        return False
    if mode in {'DENSITY_PRIORITY', 'MESH_AREA_SCALE_PACK', 'CHART_DISTRIBUTION'}:
        _rescale_to_mesh_area(islands, strength=1.0)
    elif mode == 'LOW_DISTORTION_PACK':
        _rescale_to_mesh_area(islands, strength=0.62)
    for data in islands:
        data.refresh()

    if mode == 'SMART_DENSE':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.96, sort_mode='AREA', allow_rotate=True, margin_override=_margin(ws, multiplier=0.75))
    if mode == 'FAST_NO_ROTATE':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.78, sort_mode='INDEX', allow_rotate=False, force_no_rotate=True)
    if mode == 'DENSITY_PRIORITY':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.90, sort_mode='AREA', allow_rotate=_bool_attr(ws, 'unified_pack_rotate', True))
    if mode == 'MESH_AREA_SCALE_PACK':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.88, sort_mode='AREA', allow_rotate=_bool_attr(ws, 'unified_pack_rotate', True))
    if mode == 'GROUP_SIMILAR':
        return _pack_by_groups(islands, ws, context, mode, lambda d: (round(max(d.width, d.height) / max(min(d.width, d.height), 1.0e-10), 1), round(math.log(max(d.width * d.height, 1.0e-10), 2), 0)))
    if mode == 'GROUP_MATERIAL':
        return _pack_by_groups(islands, ws, context, mode, lambda d: d.material_index, group_sort='KEY', margin_mult=1.0)
    if mode == 'GROUP_IDENTICAL':
        return _pack_identical_stack(islands, ws, context, mode)
    if mode == 'UDIM_STANDARD':
        return _standard_rect_pack(islands, ws, context, mode, target_tile=_target_tile(context, ws, mode), fill=0.86, sort_mode='AREA')
    if mode == 'UDIM_KEEP_TILES':
        return _pack_keep_tiles(islands, ws, context, mode)
    if mode == 'UDIM_AUTO_TILES':
        return _pack_auto_tiles(islands, ws, context, mode)
    if mode == 'CHART_DISTRIBUTION':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.94, sort_mode='ASPECT', allow_rotate=True, margin_override=_margin(ws, multiplier=0.8))
    if mode == 'BAKE_SAFE_CHART':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.76, sort_mode='AREA', allow_rotate=False, margin_override=_margin(ws, multiplier=1.75, bake_safe=True))
    if mode == 'EXISTING_CHART_REPACK':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.80, sort_mode='INDEX', allow_rotate=False)
    if mode == 'LOW_DISTORTION_PACK':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.82, sort_mode='HEIGHT', allow_rotate=False)
    if mode == 'LIGHTMAP':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.70, sort_mode='AREA', allow_rotate=False, margin_override=_margin(ws, multiplier=1.5, bake_safe=True))
    if mode == 'HOTSPOT_GRID':
        return _pack_hotspot_grid(islands, ws, context, mode)
    if mode == 'TRIM_STRIP':
        return _pack_trim_strip(islands, ws, context, mode)
    return _standard_rect_pack(islands, ws, context, mode, fill=0.86, sort_mode='AREA', allow_rotate=_bool_attr(ws, 'unified_pack_rotate', True))


def _execute_18110(self, context):
    ws = _ws(context)
    if ws is None:
        try:
            self.report({'WARNING'}, _tr(context, 'Smart UV workspace settings were not found.', 'Smart UVのワークスペース設定が見つかりません。'))
        except Exception:
            pass
        return {'CANCELLED'}
    mode = _canonical(_str_attr(ws, 'unified_auto_pack_mode', 'PACK_STANDARD') if bool(getattr(self, 'use_panel_settings', True)) else getattr(self, 'mode', 'PACK_STANDARD'))
    islands, original, selected_keys, objects = _collect_islands(context)
    if _pack_merge_overlaps_enabled(ws):
        try:
            islands = _merge_overlapping_islands(islands)
        except Exception:
            pass
    if not islands:
        try:
            self.report({'WARNING'}, _tr(context, 'No UV islands are selected in the UV Editor.', 'UVエディターで選択されているUVアイランドがありません。'))
        except Exception:
            pass
        return {'CANCELLED'}
    state = _state_snapshot(context)
    try:
        ok = _run_mode(context, ws, mode, islands)
        _restore_unselected(original, selected_keys, objects)
        _update_objects(objects)
        _restore_state(context, state)
        if not ok:
            try:
                self.report({'WARNING'}, _tr(context, f'Automatic packing failed: {mode}', f'自動パッキングが失敗しました: {mode}'))
            except Exception:
                pass
            return {'CANCELLED'}
        try:
            self.report({'INFO'}, _tr(context, f'Automatic packing finished: {mode}', f'自動パッキング完了: {mode}'))
        except Exception:
            pass
        return {'FINISHED'}
    except Exception as exc:
        try:
            _restore_unselected(original, selected_keys, objects)
            _update_objects(objects)
            _restore_state(context, state)
        except Exception:
            pass
        try:
            self.report({'WARNING'}, _tr(context, f'Automatic packing error: {exc}', f'自動パッキングでエラー: {exc}'))
        except Exception:
            pass
        return {'CANCELLED'}


def _state_snapshot(context) -> dict:
    state = {}
    try:
        ts = getattr(context, 'tool_settings', None)
        state['use_uv_select_sync'] = bool(getattr(ts, 'use_uv_select_sync', False))
        state['uv_select_mode'] = str(getattr(ts, 'uv_select_mode', 'FACE'))
        state['mesh_select_mode'] = tuple(bool(x) for x in getattr(ts, 'mesh_select_mode', (False, False, True)))
    except Exception:
        pass
    try:
        ws = _ws(context)
        state['sticky_mode'] = str(getattr(ws, 'sticky_select_mode', getattr(ws, 'uv_sticky_select_mode', 'DISABLED')))
        state['sticky_attr'] = 'sticky_select_mode' if hasattr(ws, 'sticky_select_mode') else ('uv_sticky_select_mode' if hasattr(ws, 'uv_sticky_select_mode') else '')
    except Exception:
        pass
    return state


def _restore_state(context, state: dict) -> None:
    try:
        ts = getattr(context, 'tool_settings', None)
        if ts is not None:
            if 'use_uv_select_sync' in state and bool(ts.use_uv_select_sync) != bool(state['use_uv_select_sync']):
                ts.use_uv_select_sync = bool(state['use_uv_select_sync'])
            if 'uv_select_mode' in state:
                ts.uv_select_mode = str(state['uv_select_mode'])
            if 'mesh_select_mode' in state:
                ts.mesh_select_mode = state['mesh_select_mode']
    except Exception:
        pass
    try:
        ws = _ws(context)
        attr = state.get('sticky_attr')
        if ws is not None and attr:
            setattr(ws, attr, state.get('sticky_mode'))
    except Exception:
        pass


def _patch_ui_enum_items() -> None:
    # The registered PropertyGroup enum comes from ui.py source.  This function
    # keeps runtime helpers aligned for any dynamic menu/operator code that uses
    # unified_packing._mode_items after registration.
    try:
        from . import unified_packing as up
        up._PACK_MODE_ITEMS = _MODE_ITEMS_18110
        up._mode_items = _mode_items
        up._canonical_pack_mode = _canonical
    except Exception:
        pass


def install(package_globals: dict | None = None, context=None) -> None:
    global _INSTALLED, _ORIGINAL_EXECUTE, _ORIGINAL_MODE_ITEMS, _ORIGINAL_UP_PACK_ITEMS, _ORIGINAL_UP_CANONICAL, _ORIGINAL_MULTI_EXECUTE
    try:
        from . import unified_packing as up
    except Exception:
        return
    _ensure_unified_auto_pack_operator_properties(up)
    cls = getattr(up, 'SMARTUVSUITE_OT_unified_auto_pack', None)
    if cls is None:
        return
    if _ORIGINAL_EXECUTE is None:
        _ORIGINAL_EXECUTE = getattr(cls, 'execute', None)
    if _ORIGINAL_UP_PACK_ITEMS is None:
        _ORIGINAL_UP_PACK_ITEMS = getattr(up, '_PACK_MODE_ITEMS', None)
    if _ORIGINAL_MODE_ITEMS is None:
        _ORIGINAL_MODE_ITEMS = getattr(up, '_mode_items', None)
    if _ORIGINAL_UP_CANONICAL is None:
        _ORIGINAL_UP_CANONICAL = getattr(up, '_canonical_pack_mode', None)
    try:
        if _ORIGINAL_MULTI_EXECUTE is None:
            _ORIGINAL_MULTI_EXECUTE = getattr(up, '_multi_execute_unified_auto_pack', None)
    except Exception:
        pass
    _patch_ui_enum_items()
    try:
        cls.execute = _execute_18110
    except Exception:
        pass
    try:
        # Avoid the old 1.8.104 multi-object path that collapsed nearly every
        # method to the same AABB pack.
        up._multi_execute_unified_auto_pack = _execute_18110
    except Exception:
        pass
    if package_globals is not None:
        try:
            package_globals['__version__'] = '1.0.0'
            package_globals['bl_info']['version'] = (1, 0, 0)
            package_globals['bl_info']['author'] = 'JELararagi'
            package_globals['_SUS_BL_INFO_FALLBACK'] = dict(package_globals.get('bl_info') or {})
        except Exception:
            pass
    _INSTALLED = True


# Keep the intermediate 1.8.121 bridge module pointed at the final 1.8.122 executor.
try:
    _execute_18121 = _execute_18110
except Exception:
    pass

def apply_all(package_globals: dict | None = None, context=None) -> None:
    install(package_globals, context)


def unregister() -> None:
    global _INSTALLED
    try:
        from . import unified_packing as up
        cls = getattr(up, 'SMARTUVSUITE_OT_unified_auto_pack', None)
        if cls is not None and callable(_ORIGINAL_EXECUTE):
            cls.execute = _ORIGINAL_EXECUTE
        if _ORIGINAL_UP_PACK_ITEMS is not None:
            up._PACK_MODE_ITEMS = _ORIGINAL_UP_PACK_ITEMS
        if callable(_ORIGINAL_MODE_ITEMS):
            up._mode_items = _ORIGINAL_MODE_ITEMS
        if callable(_ORIGINAL_UP_CANONICAL):
            up._canonical_pack_mode = _ORIGINAL_UP_CANONICAL
        if callable(_ORIGINAL_MULTI_EXECUTE):
            up._multi_execute_unified_auto_pack = _ORIGINAL_MULTI_EXECUTE
    except Exception:
        pass
    _INSTALLED = False


# -----------------------------------------------------------------------------
# Smart UV Suite 1.8.122 - panel-setting-complete auto pack execution
# -----------------------------------------------------------------------------
# The 1.8.119 implementation intentionally replaced several legacy operator
# routes with a deterministic selected-UV packer.  This final layer keeps that
# selected-scope behavior, but makes the deterministic path honor every exposed
# Auto Packing control instead of baking rotation/scale/group/UDIM choices into
# individual methods.


def _ensure_unified_auto_pack_operator_properties(up) -> None:
    """Install real Blender RNA annotations for the unified pack operator.

    unified_packing.py uses postponed annotations, so Blender 5.1 can otherwise
    see the operator properties as strings and skip `mode` / `use_panel_settings`.
    This repair runs before class registration during addon import, preserving
    the existing labels/descriptions while making scripted, UI, and panel
    execution paths use the same settings.
    """
    try:
        import bpy as _bpy
        cls = getattr(up, 'SMARTUVSUITE_OT_unified_auto_pack', None)
        if cls is None:
            return
        items = getattr(up, '_PACK_MODE_ITEMS', None) or _MODE_ITEMS_18110
        annotations = dict(getattr(cls, '__annotations__', {}) or {})
        annotations['mode'] = _bpy.props.EnumProperty(
            name='パッキング方法',
            description='一時的に実行する自動パッキング方法です。空の場合はパネルの「自動パッキング方法」を使います。',
            items=items,
            default='PACK_STANDARD',
            options={'SKIP_SAVE'},
        )
        annotations['use_panel_settings'] = _bpy.props.BoolProperty(
            name='パネル設定を使用',
            default=True,
            options={'SKIP_SAVE'},
        )
        cls.__annotations__ = annotations
    except Exception:
        pass


def _pack_rotation_step_degrees(ws) -> int:
    raw = _str_attr(ws, 'unified_pack_rotation_step', '15')
    try:
        value = int(float(raw))
    except Exception:
        value = 15
    if value <= 0:
        return 0
    if value not in {15, 45, 90}:
        if value < 30:
            return 15
        if value < 68:
            return 45
        return 90
    return value


def _pack_rotate_allowed(ws, *, method_allows: bool = True, force_no_rotate: bool = False) -> bool:
    if force_no_rotate or not bool(method_allows):
        return False
    if not _bool_attr(ws, 'unified_pack_rotate', True):
        return False
    return _pack_rotation_step_degrees(ws) > 0


def _pack_scale_allowed(ws, *, method_allows: bool = True) -> bool:
    return bool(method_allows) and _bool_attr(ws, 'unified_pack_scale', True)


def _pack_lock_pinned(ws) -> bool:
    return _bool_attr(ws, 'unified_pack_lock_pinned', True)


def _pack_chart_rescale_allowed(ws) -> bool:
    return _pack_scale_allowed(ws) and _bool_attr(ws, 'unified_pack_chart_rescale', True)


def _pin_state_for_loop(loop, uv_layer) -> bool:
    try:
        luv = loop[uv_layer]
        for attr in ('pin_uv', 'pin', 'pinned'):
            if hasattr(luv, attr) and bool(getattr(luv, attr)):
                return True
    except Exception:
        pass
    return False


def _mark_pack_setting_metadata(islands: list[IslandData]) -> None:
    for data in islands or []:
        pinned = False
        for loop in list(getattr(data, 'loops', []) or []):
            layer = _uv_layer_for_loop(data, loop)
            if layer is not None and _pin_state_for_loop(loop, layer):
                pinned = True
                break
        try:
            data.pinned = bool(pinned)
            data.rotation_angle = 0.0
            data.seed_rank = 0.0
        except Exception:
            pass


def _movable_islands(islands: list[IslandData], ws) -> list[IslandData]:
    if not _pack_lock_pinned(ws):
        return list(islands or [])
    return [data for data in list(islands or []) if not bool(getattr(data, 'pinned', False))]


def _shape_fill_factor(ws) -> float:
    shape = _str_attr(ws, 'unified_pack_shape_method', 'CONCAVE').upper()
    if shape == 'CONCAVE':
        return 1.035
    if shape == 'CONVEX':
        return 1.0
    if shape == 'AABB':
        return 0.955
    return 1.0


def _target_aspect_scale(ws) -> tuple[float, float]:
    width = max(1, _int_attr(ws, 'unified_pack_target_width', _int_attr(ws, 'canvas_size', 2048, 1, 32768), 1, 32768))
    height = max(1, _int_attr(ws, 'unified_pack_target_height', _int_attr(ws, 'canvas_size', 2048, 1, 32768), 1, 32768))
    # Keep UV width normalized to one tile and compress/expand the available V
    # space according to the atlas aspect.  This makes the width/height controls
    # visible to deterministic chart-like modes without writing outside the
    # selected UV loop set.
    aspect = float(width) / float(height)
    if not math.isfinite(aspect) or aspect <= 1.0e-12:
        aspect = 1.0
    return 1.0, max(1.0e-6, 1.0 / aspect)


def _target_tile_setting(ws) -> str:
    return _str_attr(ws, 'unified_pack_target_tile', 'ZERO').upper()


def _tile_from_linear(index: int, columns: int, fill: str) -> tuple[int, int]:
    columns = max(1, int(columns))
    index = max(0, int(index))
    fill = str(fill or 'ROW').upper()
    if fill == 'COLUMN':
        return index // columns, index % columns
    return index % columns, index // columns


def _target_tile(context, ws, mode: str) -> tuple[int, int]:
    target = _target_tile_setting(ws)
    if target == 'CURSOR':
        try:
            loc = getattr(getattr(context, 'space_data', None), 'cursor_location', None)
            if loc is not None:
                return int(math.floor(float(loc[0]))), int(math.floor(float(loc[1])))
        except Exception:
            pass
    if target == 'EXPLICIT':
        return _int_attr(ws, 'unified_pack_tile_u', 0), _int_attr(ws, 'unified_pack_tile_v', 0)
    return 0, 0


def _margin(ws, *, multiplier: float = 1.0, bake_safe: bool = False) -> float:
    tex = max(1, _int_attr(ws, 'canvas_size', 2048, 1, 65536))
    margin_uv = _float_attr(ws, 'unified_pack_margin', 0.001, 0.0, 0.5)
    margin_px = _int_attr(ws, 'unified_pack_margin_px', _int_attr(ws, 'fit_padding_px', 8, 0, 512), 0, 4096)
    if bake_safe:
        margin_px = max(margin_px, 2 * _int_attr(ws, 'unified_pack_bake_padding_px', 4, 0, 2048))
    px_uv = float(margin_px) / float(tex)
    method = _str_attr(ws, 'unified_pack_margin_method', 'SCALED').upper()
    if method == 'ADD':
        base = margin_uv + px_uv
    elif method == 'FRACTION':
        # Fraction means the explicit UV margin is the final-tile fraction.  Pixel
        # padding remains a lower safety bound because it is also exposed in this
        # section and must not be ignored.
        base = max(margin_uv, px_uv)
    else:
        # Scaled mode keeps the larger of native UV margin and pixel-derived pad.
        base = max(margin_uv, px_uv)
    return max(0.0, min(0.45, base * float(multiplier)))


def _rotated_points_for_data(data: IslandData, angle_rad: float) -> list[Vector]:
    pts = []
    c = Vector(getattr(data, 'center', Vector((0.0, 0.0))))
    ca = math.cos(float(angle_rad)); sa = math.sin(float(angle_rad))
    for loop in list(getattr(data, 'loops', []) or []):
        try:
            layer = _uv_layer_for_loop(data, loop)
            if layer is None:
                continue
            uv = Vector(loop[layer].uv)
            rel = uv - c
            pts.append(c + Vector((rel.x * ca - rel.y * sa, rel.x * sa + rel.y * ca)))
        except Exception:
            pass
    return pts


def _rect_for_angle(data: IslandData, angle_rad: float) -> tuple[float, float]:
    bb = _bbox(_rotated_points_for_data(data, angle_rad))
    if bb is None:
        return data.width, data.height
    mn, mx = bb
    return max(float(mx.x - mn.x), 1.0e-10), max(float(mx.y - mn.y), 1.0e-10)


def _candidate_rotation_angles(ws, *, method_allows: bool = True, force_no_rotate: bool = False) -> list[float]:
    if not _pack_rotate_allowed(ws, method_allows=method_allows, force_no_rotate=force_no_rotate):
        return [0.0]
    step = _pack_rotation_step_degrees(ws)
    if step <= 0:
        return [0.0]
    count = max(1, int(round(180.0 / float(step))))
    return [math.radians(step * i) for i in range(count)]


def _choose_rotation_angle(data: IslandData, ws, *, method_allows: bool = True, force_no_rotate: bool = False) -> float:
    angles = _candidate_rotation_angles(ws, method_allows=method_allows, force_no_rotate=force_no_rotate)
    if len(angles) <= 1:
        return 0.0
    best = 0.0
    best_key = None
    prefer_horizontal = data.height > data.width * 1.15
    prefer_vertical = data.width > data.height * 1.15
    # Rounded so a turn of 90 degrees, which only changes the area by floating
    # point noise, does not win and flip the island again on the next pack.
    base_area = max(float(data.width) * float(data.height), 1.0e-20)
    for angle in angles:
        w, h = _rect_for_angle(data, angle)
        # Favor the orientation that the selected rotation step makes useful for
        # shelf packing.  Tall islands prefer a lower shelf height, wide islands
        # prefer their existing direction, and near-square/diagonal islands prefer
        # smaller AABB area.  The candidate set is dictated by Rotation Step.
        if prefer_horizontal:
            key = (h, w * h, abs(math.log(max(w, 1.0e-10) / max(h, 1.0e-10))), abs(angle))
        elif prefer_vertical:
            key = (round(w * h / base_area, 6), h, abs(angle))
        else:
            key = (round(w * h / base_area, 6), round(abs(math.log(max(w, 1.0e-10) / max(h, 1.0e-10))), 6), abs(angle))
        if best_key is None or key < best_key:
            best_key = key
            best = angle
    return float(best)


def _apply_placement(data: IslandData, dst_origin: Vector, scale: float | tuple[float, float], *, rotate: bool = False, angle: float | None = None) -> None:
    angle_rad = float(angle if angle is not None else (math.pi * 0.5 if rotate else getattr(data, 'rotation_angle', 0.0) or 0.0))
    c = Vector(getattr(data, 'center', Vector((0.0, 0.0))))
    ca = math.cos(angle_rad); sa = math.sin(angle_rad)
    transformed = []
    for loop in list(getattr(data, 'loops', []) or []):
        try:
            layer = _uv_layer_for_loop(data, loop)
            if layer is None:
                continue
            uv0 = Vector(loop[layer].uv)
            rel = uv0 - c
            uv = c + Vector((rel.x * ca - rel.y * sa, rel.x * sa + rel.y * ca))
            transformed.append((loop, layer, uv))
        except Exception:
            continue
    bb = _bbox([uv for _loop, _layer, uv in transformed])
    if bb is None:
        return
    src_min, _src_max = bb
    if isinstance(scale, tuple):
        sx = max(float(scale[0]), 1.0e-12)
        sy = max(float(scale[1]), 1.0e-12)
    else:
        sx = sy = max(float(scale), 1.0e-12)
    for loop, layer, uv in transformed:
        try:
            rel = uv - src_min
            loop[layer].uv = Vector((float(dst_origin.x) + rel.x * sx, float(dst_origin.y) + rel.y * sy))
        except Exception:
            pass
    try:
        data.refresh()
    except Exception:
        pass


def _rect_for(data: IslandData, rotate: bool) -> tuple[float, float]:
    angle = math.pi * 0.5 if rotate else float(getattr(data, 'rotation_angle', 0.0) or 0.0)
    return _rect_for_angle(data, angle)


def _seed_rank_map(rects: list[dict], seed: int) -> dict[int, float]:
    rng = random.Random(int(seed))
    keys = [int(r['index']) for r in rects]
    shuffled = list(keys)
    rng.shuffle(shuffled)
    return {idx: float(i) for i, idx in enumerate(shuffled)}


def _pack_shelf(rects: list[dict], width: float, height: float, margin: float, *, fill: float = 0.88, sort_mode: str = 'AREA', allow_scale: bool = True, seed: int | None = None) -> list[tuple[int, float, float, float]]:
    if not rects:
        return []
    seed_rank = _seed_rank_map(rects, int(seed or 0)) if seed is not None else {}
    def key_for(r):
        idx = int(r['index'])
        if seed is not None:
            return (seed_rank.get(idx, float(idx)), idx)
        if sort_mode == 'INDEX':
            return (idx,)
        if sort_mode == 'ASPECT':
            return (-max(r['w'], r['h']) / max(min(r['w'], r['h']), 1.0e-10), -r['w'] * r['h'], idx)
        if sort_mode == 'HEIGHT':
            return (-r['h'], -r['w'], idx)
        if sort_mode == 'WIDTH':
            return (-r['w'], -r['h'], idx)
        return (-(r['w'] * r['h']), -max(r['w'], r['h']), idx)
    ordered = sorted(rects, key=key_for)
    total_area = sum(max(r['w'], 1.0e-10) * max(r['h'], 1.0e-10) for r in rects)
    if allow_scale:
        base = math.sqrt((max(width, 1.0e-10) * max(height, 1.0e-10) * max(0.05, min(0.98, fill))) / max(total_area, 1.0e-12))
        if not math.isfinite(base):
            base = 1.0
        base = max(1.0e-8, min(base, 1.0e8))
    else:
        base = 1.0
    # 解説書の正本と同じ並べ方：既定の倍率で棚に並べてから、その割り付けのまま枠に収まるよう島を縮める（下の fit < 1）。
    # 縮めた倍率で棚を組み直すと列と段が変わり、解説書の 2 列 3 段が 3 列 2 段になっていた（PD34C v2、手順の例 5）。
    scaled = [{**r, 'w': max(r['w'] * base, 1.0e-10), 'h': max(r['h'] * base, 1.0e-10)} for r in ordered]
    x = margin; y = margin; shelf_h = 0.0; max_x = margin
    placements = {}
    shelves = [[]]
    for r in scaled:
        w = max(float(r['w']), 1.0e-10); h = max(float(r['h']), 1.0e-10)
        if x > margin and x + w + margin > width:
            x = margin
            y += shelf_h + margin
            shelf_h = 0.0
            shelves.append([])
        placements[int(r['index'])] = (x, y)
        shelves[-1].append((int(r['index']), w, h))
        x += w + margin
        shelf_h = max(shelf_h, h)
        max_x = max(max_x, x)
    used_w = max(max_x + margin, margin * 2.0 + 1.0e-10)
    used_h = max(y + shelf_h + margin, margin * 2.0 + 1.0e-10)
    fit = min(width / used_w, height / used_h, 1.0) if allow_scale else 1.0
    if fit < 1.0:
        # 縮める時は島だけを縮め、すき間（margin）は出力の UV の単位のまま保つ（約束：設定したすき間）。
        # 棚の割り付け（どの島がどの段のどの順か）は上の既定の倍率の時のまま変えない（解説書の 2 列 3 段）。
        # 全体を同じ倍率で縮めるとすき間も fit 倍に狭まり、設定のすき間を割っていた（PD34C v3、契約 14・15・97・98）。
        caps = []
        sum_h = sum(max(h for _i, _w, h in row) for row in shelves)
        if sum_h > 0.0:
            caps.append((height - margin * (len(shelves) + 1)) / sum_h)
        for row in shelves:
            sum_w = sum(w for _i, w, _h in row)
            if sum_w > 0.0:
                caps.append((width - margin * (len(row) + 1)) / sum_w)
        keep = min(caps) if caps else 0.0
        if math.isfinite(keep) and keep > 0.0:
            keep = min(keep, 1.0)
            kept = {}
            y = margin
            for row in shelves:
                x = margin
                for i, w, h in row:
                    kept[i] = (x, y)
                    x += w * keep + margin
                y += max(h for _i, _w, h in row) * keep + margin
            return [(int(r['index']), *kept.get(int(r['index']), (margin, margin)), base * keep) for r in rects]
        # すき間だけで枠を超える時は、重ならないよう全体を同じ倍率で縮める（すき間も狭まる）。
    out = []
    for r in rects:
        px, py = placements.get(int(r['index']), (margin, margin))
        out.append((int(r['index']), px * fit, py * fit, base * fit))
    return out


def _target_aspect_enabled_for_mode(mode: str) -> bool:
    # The Auto Packing panel exposes target width/height as common settings, so
    # every auto-packing method receives the same atlas aspect envelope.
    return True


def _standard_rect_pack(islands: list[IslandData], ws, context, mode: str, *, target_tile: tuple[int, int] | None = None, margin_override: float | None = None, fill: float | None = None, sort_mode: str = 'AREA', allow_rotate: bool | None = None, force_no_rotate: bool = False, allow_scale: bool | None = None) -> bool:
    mode = _canonical(mode)
    islands = _movable_islands(islands, ws)
    if not islands:
        return True
    if target_tile is None and _target_tile_setting(ws) == 'KEEP' and mode != 'UDIM_STANDARD':
        ok_any = False
        groups = {}
        for data in islands:
            groups.setdefault(tuple(getattr(data, 'tile', (0, 0))), []).append(data)
        for tile, subset in groups.items():
            if _standard_rect_pack(subset, ws, context, mode, target_tile=tile, margin_override=margin_override, fill=fill, sort_mode=sort_mode, allow_rotate=allow_rotate, force_no_rotate=force_no_rotate, allow_scale=allow_scale):
                ok_any = True
        return ok_any
    tile_u, tile_v = target_tile if target_tile is not None else _target_tile(context, ws, mode)
    margin = _margin(ws) if margin_override is None else max(0.0, min(0.45, float(margin_override)))
    aspect_u, aspect_v = _target_aspect_scale(ws) if _target_aspect_enabled_for_mode(mode) else (1.0, 1.0)
    usable_min = Vector((int(tile_u) + margin, int(tile_v) + margin))
    usable_w = max(1.0e-9, aspect_u - 2.0 * margin)
    usable_h = max(1.0e-9, aspect_v - 2.0 * margin)
    if allow_rotate is None:
        allow_rotate = True
    rotate_ok = _pack_rotate_allowed(ws, method_allows=bool(allow_rotate), force_no_rotate=force_no_rotate)
    scale_ok = _pack_scale_allowed(ws) if allow_scale is None else _pack_scale_allowed(ws, method_allows=bool(allow_scale))
    fill_value = fill if fill is not None else 0.86
    fill_value = max(0.05, min(0.98, float(fill_value) * _shape_fill_factor(ws)))
    seed = _int_attr(ws, 'unified_pack_seed', 0) if _bool_attr(ws, 'unified_pack_use_seed', False) else None
    rects = []
    for i, data in enumerate(islands):
        angle = _choose_rotation_angle(data, ws, method_allows=rotate_ok, force_no_rotate=force_no_rotate)
        try:
            data.rotation_angle = angle
            data.rotate_90 = abs((angle % math.pi) - math.pi * 0.5) < 1.0e-8
        except Exception:
            pass
        w, h = _rect_for_angle(data, angle)
        rects.append({'index': i, 'w': w, 'h': h})
    placements = _pack_shelf(rects, usable_w, usable_h, margin, fill=fill_value, sort_mode=sort_mode, allow_scale=scale_ok, seed=seed)
    placement_map = {idx: (x, y, sc) for idx, x, y, sc in placements}
    for i, data in enumerate(islands):
        x, y, sc = placement_map.get(i, (margin, margin, 1.0))
        _apply_placement(data, usable_min + Vector((x, y)), sc if scale_ok else 1.0, angle=float(getattr(data, 'rotation_angle', 0.0) or 0.0))
    return True


def _similar_group_key(data: IslandData, ws) -> tuple[int, int]:
    area_tol = max(0.001, _float_attr(ws, 'similarity_area_tol', 0.08, 0.0, 1.0))
    aspect_tol = max(0.001, _float_attr(ws, 'similarity_aspect_tol', 0.15, 0.0, 1.0))
    area = max(float(data.width * data.height), 1.0e-12)
    aspect = max(data.width, data.height) / max(min(data.width, data.height), 1.0e-12)
    # Tolerance controls quantization: larger tolerance merges more islands.
    area_bucket = int(round(math.log(area, 2.0) / max(area_tol * 8.0, 0.001)))
    aspect_bucket = int(round(aspect / max(aspect_tol * 4.0, 0.001)))
    return aspect_bucket, area_bucket


def _identical_group_key(data: IslandData, ws) -> tuple[int, int, int]:
    area_tol = max(0.0005, _float_attr(ws, 'similarity_area_tol', 0.05, 0.0, 1.0))
    aspect_tol = max(0.0005, _float_attr(ws, 'similarity_aspect_tol', 0.15, 0.0, 1.0))
    aspect = max(data.width, data.height) / max(min(data.width, data.height), 1.0e-12)
    area = max(data.width * data.height, 1.0e-12)
    return (int(round(math.log(area, 2.0) / max(area_tol * 4.0, 0.0005))), int(round(aspect / max(aspect_tol * 2.0, 0.0005))), len(list(getattr(data, 'faces', []) or [])))


def _pack_by_groups(islands: list[IslandData], ws, context, mode: str, key_fn, *, group_sort='KEY', margin_mult=1.0) -> bool:
    islands = _movable_islands(islands, ws)
    if not islands:
        return True
    groups = {}
    for data in islands:
        groups.setdefault(key_fn(data), []).append(data)
    if _bool_attr(ws, 'unified_pack_use_seed', False):
        rng = random.Random(_int_attr(ws, 'unified_pack_seed', 0))
        items = list(groups.items())
        rng.shuffle(items)
    else:
        items = sorted(groups.items(), key=lambda kv: str(kv[0]) if group_sort == 'KEY' else -sum(d.width * d.height for d in kv[1]))
    layout = _str_attr(ws, 'pack_group_layout', 'SINGLE_TILE').upper()
    if layout == 'TILES':
        cols = _int_attr(ws, 'unified_pack_tile_columns', 10, 1, 100)
        fill = _str_attr(ws, 'unified_pack_tile_fill', 'ROW')
        base_u, base_v = _target_tile(context, ws, mode)
        ok = False
        for gi, (_key, subset) in enumerate(items):
            du, dv = _tile_from_linear(gi, cols, fill)
            if _standard_rect_pack(subset, ws, context, mode, target_tile=(base_u + du, base_v + dv), margin_override=_margin(ws, multiplier=margin_mult), fill=0.84, sort_mode='AREA'):
                ok = True
        return ok
    base_margin = _margin(ws, multiplier=margin_mult)
    tile_u, tile_v = _target_tile(context, ws, mode)
    aspect_u, aspect_v = _target_aspect_scale(ws)
    n = max(1, len(items))
    ok = False

    def _pack_group_subset(subset, usable_min, usable_w, usable_h, local_margin) -> bool:
        rotate_ok = _pack_rotate_allowed(ws)
        scale_ok = _pack_scale_allowed(ws)
        rects = []
        for i, data in enumerate(subset):
            angle = _choose_rotation_angle(data, ws, method_allows=rotate_ok)
            data.rotation_angle = angle
            w, h = _rect_for_angle(data, angle)
            rects.append({'index': i, 'w': w, 'h': h})
        seed = _int_attr(ws, 'unified_pack_seed', 0) if _bool_attr(ws, 'unified_pack_use_seed', False) else None
        placements = _pack_shelf(rects, usable_w, usable_h, local_margin, fill=0.84 * _shape_fill_factor(ws), sort_mode='AREA', allow_scale=scale_ok, seed=seed)
        placed = False
        for i, x, y, sc in placements:
            data = subset[int(i)]
            _apply_placement(data, usable_min + Vector((x, y)), sc if scale_ok else 1.0, angle=float(getattr(data, 'rotation_angle', 0.0) or 0.0))
            placed = True
        return placed

    if layout == 'COLUMNS':
        band_w = max(1.0e-9, (aspect_u - 2.0 * base_margin) / n)
        for col_i, (_key, subset) in enumerate(items):
            local_margin = min(base_margin, band_w * 0.25)
            usable_min = Vector((tile_u + base_margin + col_i * band_w + local_margin, tile_v + local_margin))
            usable_w = max(1.0e-9, band_w - 2.0 * local_margin)
            usable_h = max(1.0e-9, aspect_v - 2.0 * local_margin)
            ok = _pack_group_subset(subset, usable_min, usable_w, usable_h, local_margin) or ok
        return ok

    # SINGLE_TILE and ROWS both remain inside one tile; ROWS makes the grouping
    # direction explicit while SINGLE_TILE keeps the historical row-band layout.
    band_h = max(1.0e-9, (aspect_v - 2.0 * base_margin) / n)
    for row_i, (_key, subset) in enumerate(items):
        local_margin = min(base_margin, band_h * 0.25)
        usable_min = Vector((tile_u + local_margin, tile_v + base_margin + row_i * band_h + local_margin))
        usable_w = max(1.0e-9, aspect_u - 2.0 * local_margin)
        usable_h = max(1.0e-9, band_h - 2.0 * local_margin)
        ok = _pack_group_subset(subset, usable_min, usable_w, usable_h, local_margin) or ok
    return ok


def _pack_identical_stack(islands: list[IslandData], ws, context, mode: str) -> bool:
    islands = _movable_islands(islands, ws)
    if not islands:
        return True
    if not _bool_attr(ws, 'unified_pack_stack_identical', True):
        return _standard_rect_pack(islands, ws, context, mode, fill=0.90, sort_mode='AREA')
    stacks = {}
    for data in islands:
        stacks.setdefault(_identical_group_key(data, ws), []).append(data)
    reps = [vals[0] for _key, vals in sorted(stacks.items(), key=lambda kv: (-sum(d.width * d.height for d in kv[1]), str(kv[0])))]
    if not _standard_rect_pack(reps, ws, context, mode, fill=0.90, sort_mode='AREA'):
        return False
    if not _pack_scale_allowed(ws):
        # With scale disabled, stack by translation only onto the representative's
        # minimum coordinate so island sizes remain unchanged.
        for key, vals in stacks.items():
            rep = vals[0]; rep.refresh(); dst_min = Vector(rep.min_uv)
            for other in vals[1:]:
                other.refresh()
                _apply_placement(other, dst_min, 1.0, angle=0.0)
        return True
    for key, vals in stacks.items():
        rep = vals[0]
        rep.refresh(); dst_min, dst_max = rep.min_uv, rep.max_uv
        dst_w, dst_h = rep.width, rep.height
        for other in vals[1:]:
            other.refresh()
            scale = min(dst_w / max(other.width, 1.0e-10), dst_h / max(other.height, 1.0e-10))
            _apply_placement(other, Vector(dst_min), scale, angle=0.0)
    return True


def _pack_keep_tiles(islands: list[IslandData], ws, context, mode: str) -> bool:
    islands = _movable_islands(islands, ws)
    if not islands:
        return True
    groups = {}
    for data in islands:
        groups.setdefault(tuple(getattr(data, 'tile', (0, 0))), []).append(data)
    target_mode = _target_tile_setting(ws)
    if target_mode == 'KEEP':
        tile_map = {tile: tile for tile in groups}
    else:
        start = _target_tile(context, ws, mode)
        min_u = min(tile[0] for tile in groups)
        min_v = min(tile[1] for tile in groups)
        tile_map = {tile: (int(start[0]) + int(tile[0]) - int(min_u), int(start[1]) + int(tile[1]) - int(min_v)) for tile in groups}
    ok = False
    for tile, subset in groups.items():
        if _standard_rect_pack(subset, ws, context, mode, target_tile=tile_map.get(tile, tile), fill=0.84, sort_mode='AREA'):
            ok = True
    return ok


def _pack_auto_tiles(islands: list[IslandData], ws, context, mode: str) -> bool:
    islands = _movable_islands(islands, ws)
    if not islands:
        return True
    cols = max(1, _int_attr(ws, 'unified_pack_tile_columns', 10, 1, 100))
    fill_mode = _str_attr(ws, 'unified_pack_tile_fill', 'ROW')
    seed = _int_attr(ws, 'unified_pack_seed', 0) if _bool_attr(ws, 'unified_pack_use_seed', False) else None
    if seed is not None:
        ordered = list(islands)
        random.Random(seed).shuffle(ordered)
    else:
        ordered = sorted(islands, key=lambda d: (-(d.width * d.height), d.index))
    per_tile = max(1, int(math.ceil(len(ordered) / max(1, min(cols, len(ordered))))))
    base_u, base_v = _target_tile(context, ws, mode)
    ok = False
    for i in range(0, len(ordered), per_tile):
        tile_index = i // per_tile
        du, dv = _tile_from_linear(tile_index, cols, fill_mode)
        subset = ordered[i:i + per_tile]
        if _standard_rect_pack(subset, ws, context, mode, target_tile=(base_u + du, base_v + dv), fill=0.82, sort_mode='AREA'):
            ok = True
    return ok


def _pack_hotspot_grid(islands: list[IslandData], ws, context, mode: str) -> bool:
    islands = _movable_islands(islands, ws)
    if not islands:
        return True
    cols = max(1, _int_attr(ws, 'hotspot_cols', 4, 1, 64))
    rows = max(1, _int_attr(ws, 'hotspot_rows', 4, 1, 64))
    margin = _margin(ws, multiplier=1.0)
    tile_u, tile_v = _target_tile(context, ws, mode)
    aspect_u, aspect_v = _target_aspect_scale(ws)
    cell_w = max(1.0e-9, (aspect_u - 2.0 * margin) / cols)
    cell_h = max(1.0e-9, (aspect_v - 2.0 * margin) / rows)
    sort_mode = _str_attr(ws, 'hotspot_sort', 'AREA').upper()
    if _bool_attr(ws, 'unified_pack_use_seed', False):
        ordered = list(islands); random.Random(_int_attr(ws, 'unified_pack_seed', 0)).shuffle(ordered)
    elif sort_mode == 'WIDTH':
        ordered = sorted(islands, key=lambda d: (-d.width, -d.height, d.index))
    elif sort_mode == 'HEIGHT':
        ordered = sorted(islands, key=lambda d: (-d.height, -d.width, d.index))
    else:
        ordered = sorted(islands, key=lambda d: (-(d.width * d.height), d.index))
    fill_order = _str_attr(ws, 'hotspot_fill_order', 'ROW').upper()
    keep_aspect = _bool_attr(ws, 'hotspot_keep_aspect', True)
    scale_ok = _pack_scale_allowed(ws)
    rotate_ok = _pack_rotate_allowed(ws)
    for n, data in enumerate(ordered):
        if fill_order == 'COLUMN':
            c = (n // rows) % cols
            r = n % rows
        else:
            c = n % cols
            r = (n // cols) % rows
        angle = _choose_rotation_angle(data, ws, method_allows=rotate_ok)
        data.rotation_angle = angle
        rw, rh = _rect_for_angle(data, angle)
        cell_min = Vector((tile_u + margin + c * cell_w + margin * 0.25, tile_v + margin + r * cell_h + margin * 0.25))
        target_w = max(1.0e-9, cell_w - margin * 0.5)
        target_h = max(1.0e-9, cell_h - margin * 0.5)
        if not scale_ok:
            scale = 1.0
        elif keep_aspect:
            scale = min(target_w / rw, target_h / rh)
        else:
            scale = (target_w / rw, target_h / rh)
        _apply_placement(data, cell_min, scale, angle=angle)
    return True


def _pack_trim_strip(islands: list[IslandData], ws, context, mode: str) -> bool:
    islands = _movable_islands(islands, ws)
    if not islands:
        return True
    margin = _margin(ws, multiplier=1.0)
    tile_u, tile_v = _target_tile(context, ws, mode)
    aspect_u, aspect_v = _target_aspect_scale(ws)
    fill_order = _str_attr(ws, 'hotspot_fill_order', 'ROW').upper()
    scale_ok = _pack_scale_allowed(ws)
    rotate_ok = _pack_rotate_allowed(ws)
    ordered = sorted(islands, key=lambda d: (-d.height if fill_order != 'COLUMN' else -d.width, d.index))
    strips = max(1, min(len(ordered), _int_attr(ws, 'hotspot_rows' if fill_order != 'COLUMN' else 'hotspot_cols', 4, 1, 64)))
    if fill_order == 'COLUMN':
        strip_w = max(1.0e-9, (aspect_u - 2.0 * margin) / strips)
        y_by_strip = [tile_v + margin for _ in range(strips)]
        for i, data in enumerate(ordered):
            strip = i % strips
            angle = _choose_rotation_angle(data, ws, method_allows=rotate_ok)
            data.rotation_angle = angle
            rw, rh = _rect_for_angle(data, angle)
            dst_w = max(1.0e-9, strip_w - margin)
            scale = (dst_w / rw) if scale_ok else 1.0
            h = rh * scale
            if y_by_strip[strip] + h + margin > tile_v + aspect_v:
                y_by_strip[strip] = tile_v + margin
            x = tile_u + margin + strip * strip_w + margin * 0.5
            _apply_placement(data, Vector((x, y_by_strip[strip])), scale, angle=angle)
            y_by_strip[strip] += h + margin
    else:
        strip_h = max(1.0e-9, (aspect_v - 2.0 * margin) / strips)
        x_by_strip = [tile_u + margin for _ in range(strips)]
        for i, data in enumerate(ordered):
            strip = i % strips
            angle = _choose_rotation_angle(data, ws, method_allows=rotate_ok)
            data.rotation_angle = angle
            rw, rh = _rect_for_angle(data, angle)
            dst_h = max(1.0e-9, strip_h - margin)
            scale = (dst_h / rh) if scale_ok else 1.0
            w = rw * scale
            if x_by_strip[strip] + w + margin > tile_u + aspect_u:
                x_by_strip[strip] = tile_u + margin
            y = tile_v + margin + strip * strip_h + margin * 0.5
            _apply_placement(data, Vector((x_by_strip[strip], y)), scale, angle=angle)
            x_by_strip[strip] += w + margin
    return True


def _run_mode(context, ws, mode: str, islands: list[IslandData]) -> bool:
    mode = _canonical(mode)
    if not islands:
        return False
    _mark_pack_setting_metadata(islands)
    movable = _movable_islands(islands, ws)
    if not movable:
        return True
    if _pack_chart_rescale_allowed(ws):
        if mode in {'DENSITY_PRIORITY', 'MESH_AREA_SCALE_PACK', 'CHART_DISTRIBUTION'}:
            _rescale_to_mesh_area(movable, strength=1.0)
        elif mode == 'LOW_DISTORTION_PACK':
            _rescale_to_mesh_area(movable, strength=0.62)
    for data in islands:
        data.refresh()

    rotate_allowed = _pack_rotate_allowed(ws)
    if mode == 'SMART_DENSE':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.96, sort_mode='AREA', allow_rotate=rotate_allowed, margin_override=_margin(ws, multiplier=0.75))
    if mode == 'FAST_NO_ROTATE':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.78, sort_mode='INDEX', allow_rotate=rotate_allowed)
    if mode == 'DENSITY_PRIORITY':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.90, sort_mode='AREA', allow_rotate=rotate_allowed)
    if mode == 'MESH_AREA_SCALE_PACK':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.88, sort_mode='AREA', allow_rotate=rotate_allowed)
    if mode in {'GROUP_SIMILAR', 'GROUP_MATERIAL', 'GROUP_IDENTICAL'}:
        group_mode = _str_attr(ws, 'pack_group_mode', 'SIMILAR').upper()
        if group_mode == 'MATERIAL':
            return _pack_by_groups(islands, ws, context, mode, lambda d: d.material_index, group_sort='KEY', margin_mult=1.0)
        if group_mode == 'IDENTICAL' or _bool_attr(ws, 'unified_pack_stack_identical', False):
            return _pack_identical_stack(islands, ws, context, mode)
        return _pack_by_groups(islands, ws, context, mode, lambda d: _similar_group_key(d, ws))
    if mode == 'UDIM_STANDARD':
        return _standard_rect_pack(islands, ws, context, mode, target_tile=_target_tile(context, ws, mode), fill=0.86, sort_mode='AREA', allow_rotate=rotate_allowed)
    if mode == 'UDIM_KEEP_TILES':
        return _pack_keep_tiles(islands, ws, context, mode)
    if mode == 'UDIM_AUTO_TILES':
        return _pack_auto_tiles(islands, ws, context, mode)
    if mode == 'CHART_DISTRIBUTION':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.94, sort_mode='ASPECT', allow_rotate=rotate_allowed, margin_override=_margin(ws, multiplier=0.8))
    if mode == 'BAKE_SAFE_CHART':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.76, sort_mode='AREA', allow_rotate=rotate_allowed, margin_override=_margin(ws, multiplier=1.75, bake_safe=True))
    if mode == 'EXISTING_CHART_REPACK':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.80, sort_mode='INDEX', allow_rotate=rotate_allowed)
    if mode == 'LOW_DISTORTION_PACK':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.82, sort_mode='HEIGHT', allow_rotate=rotate_allowed)
    if mode == 'LIGHTMAP':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.70, sort_mode='AREA', allow_rotate=rotate_allowed, margin_override=_margin(ws, multiplier=1.5, bake_safe=True))
    if mode == 'HOTSPOT_GRID':
        return _pack_hotspot_grid(islands, ws, context, mode)
    if mode == 'TRIM_STRIP':
        return _pack_trim_strip(islands, ws, context, mode)
    return _standard_rect_pack(islands, ws, context, mode, fill=0.86, sort_mode='AREA', allow_rotate=rotate_allowed)


_SUS_18120_PREV_COLLECT_ISLANDS = globals().get('_collect_islands')

def _collect_islands(context) -> tuple[list[IslandData], dict, dict, list]:
    if callable(_SUS_18120_PREV_COLLECT_ISLANDS):
        islands, original, selected_keys, objects = _SUS_18120_PREV_COLLECT_ISLANDS(context)
        try:
            _mark_pack_setting_metadata(islands)
        except Exception:
            pass
        return islands, original, selected_keys, objects
    return [], {}, set(), []


_SUS_18120_PREV_INSTALL = globals().get('install')

def install(package_globals: dict | None = None, context=None) -> None:
    if callable(_SUS_18120_PREV_INSTALL):
        _SUS_18120_PREV_INSTALL(package_globals, context)
    try:
        from . import unified_packing as up
        _ensure_unified_auto_pack_operator_properties(up)
        cls = getattr(up, 'SMARTUVSUITE_OT_unified_auto_pack', None)
        if cls is not None:
            cls.execute = _execute_18110
        up._multi_execute_unified_auto_pack = _execute_18110
        up._PACK_MODE_ITEMS = _MODE_ITEMS_18110
        up._mode_items = _mode_items
        up._canonical_pack_mode = _canonical
    except Exception:
        pass
    if package_globals is not None:
        try:
            package_globals['__version__'] = '1.0.0'
            package_globals['bl_info']['version'] = (1, 0, 0)
            package_globals['bl_info']['author'] = 'JELararagi'
            package_globals['_SUS_BL_INFO_FALLBACK'] = dict(package_globals.get('bl_info') or {})
        except Exception:
            pass


def apply_all(package_globals: dict | None = None, context=None) -> None:
    install(package_globals, context)

# -----------------------------------------------------------------------------
# Smart UV Suite 1.8.122 - final auto-pack preset/settings and UV-selection fix
# -----------------------------------------------------------------------------

def _suv18121_mesh_bool_values(mesh, name: str, expected: int) -> list[bool]:
    try:
        attr = getattr(mesh, 'attributes', None).get(name)
    except Exception:
        attr = None
    if attr is None:
        return []
    try:
        data = list(getattr(attr, 'data', []) or [])
        if len(data) < expected:
            return []
        return [bool(getattr(item, 'value', False)) for item in data[:expected]]
    except Exception:
        return []


def _suv18121_bool_member(obj, *names: str) -> bool:
    for name in names:
        try:
            value = getattr(obj, name)
            if callable(value):
                value = value()
            if bool(value):
                return True
        except Exception:
            pass
        try:
            getter = getattr(obj, name + '_get')
            if callable(getter) and bool(getter()):
                return True
        except Exception:
            pass
    return False


def _suv18122_expand_seed_faces(bm, uv_layer, seed_faces: list) -> list:
    seed = {f for f in seed_faces if f is not None}
    if not seed:
        return []
    try:
        islands = _build_pack_topology_islands(bm, uv_layer, list(bm.faces))
        out = []
        seen = set()
        for isl in islands:
            faces_i = list(getattr(isl, 'faces', []) or [])
            if not any(face in seed for face in faces_i):
                continue
            for face in faces_i:
                key = int(getattr(face, 'index', id(face)))
                if key in seen:
                    continue
                seen.add(key)
                out.append(face)
        return out or list(seed_faces)
    except Exception:
        return list(seed_faces)


def _selected_faces_from_uv_editor(obj, bm) -> list:
    """Return UV-editor selected island faces in Blender 5.1.

    Blender 5.1 stores UV selection primarily in the hidden .uv_select_*
    attributes.  Auto Pack must therefore seed from those UV-domain flags and
    expand to complete UV islands instead of falling back to 3D View selection.
    """
    try:
        bm.faces.ensure_lookup_table(); bm.faces.index_update()
        bm.verts.ensure_lookup_table(); bm.verts.index_update()
        bm.edges.ensure_lookup_table(); bm.edges.index_update()
    except Exception:
        pass
    try:
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
    except Exception:
        uv_layer = None
    faces = list(getattr(bm, 'faces', []) or [])
    seed_faces = []
    saw_uv_selection = False

    if uv_layer is not None:
        for face in faces:
            try:
                loops = list(face.loops)
                if not loops:
                    continue
                face_selected = _suv18121_bool_member(face, 'uv_select')
                loop_selected = False
                for loop in loops:
                    try:
                        luv = loop[uv_layer]
                    except Exception:
                        luv = None
                    if (
                        _suv18121_bool_member(loop, 'uv_select_vert')
                        or _suv18121_bool_member(loop, 'uv_select_edge')
                        or (luv is not None and _suv18121_bool_member(luv, 'select', 'select_edge'))
                    ):
                        loop_selected = True
                        break
                if face_selected or loop_selected:
                    saw_uv_selection = True
                    seed_faces.append(face)
            except Exception:
                pass
        if seed_faces:
            return _suv18122_expand_seed_faces(bm, uv_layer, seed_faces)
        if saw_uv_selection:
            return []

    mesh = getattr(obj, 'data', None)
    try:
        poly_count = len(getattr(mesh, 'polygons', []) or [])
        loop_count = len(getattr(mesh, 'loops', []) or [])
    except Exception:
        mesh = None; poly_count = loop_count = 0
    if mesh is not None and poly_count:
        fflags = _suv18121_mesh_bool_values(mesh, '.uv_select_face', poly_count)
        vflags = _suv18121_mesh_bool_values(mesh, '.uv_select_vert', loop_count)
        eflags = _suv18121_mesh_bool_values(mesh, '.uv_select_edge', loop_count)
        if fflags or vflags or eflags:
            for face in faces:
                try:
                    fi = int(getattr(face, 'index', -1))
                    if fi < 0 or fi >= poly_count:
                        continue
                    poly = mesh.polygons[fi]
                    start = int(getattr(poly, 'loop_start', 0))
                    total = int(getattr(poly, 'loop_total', len(face.loops)))
                    idxs = range(start, start + total)
                    if (
                        (fflags and bool(fflags[fi]))
                        or (vflags and any(0 <= li < len(vflags) and vflags[li] for li in idxs))
                        or (eflags and any(0 <= li < len(eflags) and eflags[li] for li in idxs))
                    ):
                        seed_faces.append(face)
                except Exception:
                    pass
            if seed_faces:
                return _suv18122_expand_seed_faces(bm, uv_layer, seed_faces) if uv_layer is not None else seed_faces
            return []

    return [face for face in faces if bool(getattr(face, 'select', False))]


def _collect_islands(context) -> tuple[list[IslandData], dict, set, list]:
    objects = _edit_mesh_objects(context)
    all_islands: list[IslandData] = []
    original = {}
    selected_keys = set()
    idx = 0
    for obj in objects:
        if not _ensure_edit(context, obj):
            continue
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
            try:
                bm.faces.ensure_lookup_table(); bm.faces.index_update()
            except Exception:
                pass
            faces = _selected_faces_from_uv_editor(obj, bm)
            if not faces:
                continue
            for face in bm.faces:
                for pos, loop in enumerate(list(face.loops)):
                    original[(obj, int(getattr(face, 'index', -1)), int(pos))] = Vector(loop[uv_layer].uv)
            try:
                islands = _build_pack_topology_islands(bm, uv_layer, faces)
            except Exception:
                islands = []
            if not islands:
                class _FaceIsland: pass
                islands = []
                for face in faces:
                    isl = _FaceIsland(); isl.faces = [face]; islands.append(isl)
            for isl in islands:
                faces_i = list(getattr(isl, 'faces', []) or [])
                if not faces_i:
                    continue
                loops=[]; seen=set()
                for face in faces_i:
                    for pos, loop in enumerate(list(face.loops)):
                        key=(int(getattr(face,'index',-1)), int(pos))
                        if key in seen:
                            continue
                        seen.add(key); loops.append(loop); selected_keys.add((obj, key[0], key[1]))
                if not loops:
                    continue
                data = IslandData(obj=obj, bm=bm, uv_layer=uv_layer, faces=faces_i, loops=loops, index=idx)
                data.loop_uv_layers = {id(loop): uv_layer for loop in loops}
                data.face_uv_layers = {id(face): uv_layer for face in faces_i}
                data.face_objects = {id(face): obj for face in faces_i}
                data.face_bmeshes = {id(face): bm for face in faces_i}
                data.refresh(); all_islands.append(data); idx += 1
        except Exception:
            continue
    try:
        ws = _ws(context)
        if _pack_merge_overlaps_enabled(ws):
            all_islands = _merge_overlapping_islands(all_islands)
    except Exception:
        pass
    try:
        _mark_pack_setting_metadata(all_islands)
    except Exception:
        pass
    return all_islands, original, selected_keys, objects


def _run_mode(context, ws, mode: str, islands: list[IslandData]) -> bool:
    mode = _canonical(mode)
    if not islands:
        return False
    _mark_pack_setting_metadata(islands)
    movable = _movable_islands(islands, ws)
    if not movable:
        return True
    if _pack_chart_rescale_allowed(ws):
        if mode in {'DENSITY_PRIORITY', 'MESH_AREA_SCALE_PACK', 'CHART_DISTRIBUTION'}:
            _rescale_to_mesh_area(movable, strength=1.0)
        elif mode == 'LOW_DISTORTION_PACK':
            _rescale_to_mesh_area(movable, strength=0.62)
    for data in islands:
        data.refresh()

    rotate_allowed = _pack_rotate_allowed(ws)
    if mode == 'SMART_DENSE':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.96, sort_mode='AREA', allow_rotate=rotate_allowed, margin_override=_margin(ws, multiplier=0.75))
    if mode == 'FAST_NO_ROTATE':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.78, sort_mode='INDEX', allow_rotate=rotate_allowed)
    if mode == 'DENSITY_PRIORITY':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.90, sort_mode='AREA', allow_rotate=rotate_allowed)
    if mode == 'MESH_AREA_SCALE_PACK':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.88, sort_mode='AREA', allow_rotate=rotate_allowed)
    if mode in {'GROUP_SIMILAR', 'GROUP_MATERIAL', 'GROUP_IDENTICAL'}:
        group_mode = _str_attr(ws, 'pack_group_mode', 'SIMILAR').upper()
        if group_mode == 'MATERIAL':
            return _pack_by_groups(islands, ws, context, mode, lambda d: d.material_index, group_sort='KEY', margin_mult=1.0)
        if group_mode == 'IDENTICAL' or _bool_attr(ws, 'unified_pack_stack_identical', False):
            return _pack_identical_stack(islands, ws, context, mode)
        return _pack_by_groups(islands, ws, context, mode, lambda d: _similar_group_key(d, ws))
    if mode == 'UDIM_STANDARD':
        return _standard_rect_pack(islands, ws, context, mode, target_tile=_target_tile(context, ws, mode), fill=0.86, sort_mode='AREA', allow_rotate=rotate_allowed)
    if mode == 'UDIM_KEEP_TILES':
        return _pack_keep_tiles(islands, ws, context, mode)
    if mode == 'UDIM_AUTO_TILES':
        return _pack_auto_tiles(islands, ws, context, mode)
    if mode == 'CHART_DISTRIBUTION':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.94, sort_mode='ASPECT', allow_rotate=rotate_allowed, margin_override=_margin(ws, multiplier=0.8))
    if mode == 'BAKE_SAFE_CHART':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.76, sort_mode='AREA', allow_rotate=rotate_allowed, margin_override=_margin(ws, multiplier=1.75, bake_safe=True))
    if mode == 'EXISTING_CHART_REPACK':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.80, sort_mode='INDEX', allow_rotate=rotate_allowed)
    if mode == 'LOW_DISTORTION_PACK':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.82, sort_mode='HEIGHT', allow_rotate=rotate_allowed)
    if mode == 'LIGHTMAP':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.70, sort_mode='AREA', allow_rotate=rotate_allowed, margin_override=_margin(ws, multiplier=1.5, bake_safe=True))
    if mode == 'HOTSPOT_GRID':
        return _pack_hotspot_grid(islands, ws, context, mode)
    if mode == 'TRIM_STRIP':
        return _pack_trim_strip(islands, ws, context, mode)
    return _standard_rect_pack(islands, ws, context, mode, fill=0.86, sort_mode='AREA', allow_rotate=rotate_allowed)


def _execute_18121(self, context):
    ws = _ws(context)
    if ws is None:
        try: self.report({'WARNING'}, 'Smart UVのワークスペース設定が見つかりません。')
        except Exception: pass
        return {'CANCELLED'}
    mode = _canonical(_str_attr(ws, 'unified_auto_pack_mode', 'PACK_STANDARD') if bool(getattr(self, 'use_panel_settings', True)) else getattr(self, 'mode', 'PACK_STANDARD'))
    islands, original, selected_keys, objects = _collect_islands(context)
    if not islands:
        try: self.report({'WARNING'}, 'UVエディターで選択されているUVアイランドまたは面がありません。')
        except Exception: pass
        return {'CANCELLED'}
    state = _state_snapshot(context)
    try:
        ok = _run_mode(context, ws, mode, islands)
        _restore_unselected(original, selected_keys, objects); _update_objects(objects); _restore_state(context, state)
        if not ok:
            try: self.report({'WARNING'}, f'自動パッキングが失敗しました: {mode}')
            except Exception: pass
            return {'CANCELLED'}
        try: self.report({'INFO'}, f'自動パッキング完了: {mode}')
        except Exception: pass
        return {'FINISHED'}
    except Exception as exc:
        try:
            _restore_unselected(original, selected_keys, objects); _update_objects(objects); _restore_state(context, state)
        except Exception: pass
        try: self.report({'WARNING'}, f'自動パッキングでエラー: {exc}')
        except Exception: pass
        return {'CANCELLED'}

_SUS_18121_PREV_INSTALL = globals().get('install')
def install(package_globals: dict | None = None, context=None) -> None:
    if callable(_SUS_18121_PREV_INSTALL):
        _SUS_18121_PREV_INSTALL(package_globals, context)
    try:
        from . import unified_packing as up
        _ensure_unified_auto_pack_operator_properties(up)
        cls = getattr(up, 'SMARTUVSUITE_OT_unified_auto_pack', None)
        if cls is not None:
            cls.execute = _execute_18121
        up._multi_execute_unified_auto_pack = _execute_18121
        up._PACK_MODE_ITEMS = _MODE_ITEMS_18110
        up._mode_items = _mode_items
        up._canonical_pack_mode = _canonical
    except Exception:
        pass
    if package_globals is not None:
        try:
            package_globals['__version__'] = '1.0.0'
            package_globals['bl_info']['version'] = (1, 0, 0)
            package_globals['bl_info']['author'] = 'JELararagi'
            package_globals['_SUS_BL_INFO_FALLBACK'] = dict(package_globals.get('bl_info') or {})
        except Exception:
            pass

def apply_all(package_globals: dict | None = None, context=None) -> None:
    install(package_globals, context)

# -----------------------------------------------------------------------------
# Smart UV Suite 1.8.122 - Blender 5.1 live UV selection Auto Pack repair
# -----------------------------------------------------------------------------
# BMLoopUV.select / select_edge are no longer reliable in Blender 5.1.  Auto
# Pack must read the live BMesh UV selection flags and must use the visible UI
# settings at execution time.  This final layer intentionally overrides the
# older collectors without touching unrelated UV tools.


def _suv_18122_read_bool_attr(obj, name: str, default: bool = False) -> bool:
    try:
        value = getattr(obj, name, default)
        if callable(value):
            try:
                value = value()
            except TypeError:
                return bool(default)
        return bool(value)
    except Exception:
        return bool(default)


def _suv_18122_face_uv_selected(face) -> bool:
    return _suv_18122_read_bool_attr(face, 'uv_select', False)


def _suv_18122_loop_uv_selected(loop, uv_layer=None) -> bool:
    if _suv_18122_read_bool_attr(loop, 'uv_select_vert', False):
        return True
    if _suv_18122_read_bool_attr(loop, 'uv_select_edge', False):
        return True
    # Compatibility fallback for older Blender builds only.
    if uv_layer is not None:
        try:
            luv = loop[uv_layer]
            if _suv_18122_read_bool_attr(luv, 'select', False):
                return True
            if _suv_18122_read_bool_attr(luv, 'select_edge', False):
                return True
        except Exception:
            pass
    return False


def _pack_merge_overlaps_enabled(ws) -> bool:
    # Canonical 1.8.122 UI property.  Other names are retained only for saved
    # settings made by intermediate repair builds.
    for name in ('unified_pack_merge_overlap', 'unified_pack_overlap_as_group', 'unified_pack_merge_overlaps', 'unified_pack_merge_overlapping'):
        try:
            if hasattr(ws, name):
                return bool(getattr(ws, name))
        except Exception:
            pass
    return True


def _suv_18122_build_all_islands(bm, uv_layer):
    faces_all = [face for face in bm.faces if not bool(getattr(face, 'hide', False))]
    if not faces_all:
        return []
    try:
        islands = _build_pack_topology_islands(bm, uv_layer, faces_all)
        if islands:
            return islands
    except Exception:
        pass
    class _FaceIsland:
        pass
    islands = []
    for face in faces_all:
        isl = _FaceIsland(); isl.faces = [face]; islands.append(isl)
    return islands


def _collect_islands(context) -> tuple[list[IslandData], dict, set, list]:
    objects = _edit_mesh_objects(context)
    all_islands: list[IslandData] = []
    original = {}
    selected_keys: set = set()
    idx = 0
    for obj in objects:
        if not _ensure_edit(context, obj):
            continue
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.verify()
            try:
                bm.faces.ensure_lookup_table(); bm.faces.index_update()
            except Exception:
                pass

            touched_faces = set()
            saw_uv_selection = False
            for face in bm.faces:
                if bool(getattr(face, 'hide', False)):
                    continue
                face_touched = False
                if _suv_18122_face_uv_selected(face):
                    saw_uv_selection = True
                    face_touched = True
                for loop in face.loops:
                    selected = _suv_18122_loop_uv_selected(loop, uv_layer)
                    if selected:
                        saw_uv_selection = True
                        face_touched = True
                if face_touched:
                    touched_faces.add(face)

            if not saw_uv_selection:
                # Headless/script fallback.  UI execution should normally enter
                # the branch above and therefore remain UV-editor scoped.
                touched_faces = {face for face in bm.faces if bool(getattr(face, 'select', False)) and not bool(getattr(face, 'hide', False))}

            if not touched_faces:
                continue

            for face in bm.faces:
                fi = int(getattr(face, 'index', -1))
                for li, loop in enumerate(face.loops):
                    try:
                        original[(obj, fi, int(li))] = Vector(loop[uv_layer].uv)
                    except Exception:
                        pass

            islands_raw = _suv_18122_build_all_islands(bm, uv_layer)
            for isl in islands_raw:
                faces_i = list(getattr(isl, 'faces', []) or [])
                if not faces_i or not any(face in touched_faces for face in faces_i):
                    continue
                loops = []
                seen = set()
                for face in faces_i:
                    for loop in face.loops:
                        key = _loop_key(loop)
                        if key in seen:
                            continue
                        seen.add(key)
                        loops.append(loop)
                        selected_keys.add((obj, key[0], key[1]))
                if not loops:
                    continue
                data = IslandData(obj=obj, bm=bm, uv_layer=uv_layer, faces=faces_i, loops=loops, index=idx)
                data.loop_uv_layers = {id(loop): uv_layer for loop in loops}
                data.face_uv_layers = {id(face): uv_layer for face in faces_i}
                data.face_objects = {id(face): obj for face in faces_i}
                data.face_bmeshes = {id(face): bm for face in faces_i}
                data.refresh()
                all_islands.append(data)
                idx += 1
        except Exception:
            continue
    try:
        _mark_pack_setting_metadata(all_islands)
    except Exception:
        pass
    return all_islands, original, selected_keys, objects


def _execute_18110(self, context):
    ws = _ws(context)
    if ws is None:
        try:
            self.report({'WARNING'}, _tr(context, 'Smart UV workspace settings were not found.', 'Smart UVのワークスペース設定が見つかりません。'))
        except Exception:
            pass
        return {'CANCELLED'}
    try:
        use_panel_settings = bool(getattr(self, 'use_panel_settings', True))
    except Exception:
        use_panel_settings = True
    mode = _canonical(_str_attr(ws, 'unified_auto_pack_mode', 'PACK_STANDARD') if use_panel_settings else getattr(self, 'mode', 'PACK_STANDARD'))
    islands, original, selected_keys, objects = _collect_islands(context)
    if _pack_merge_overlaps_enabled(ws):
        try:
            islands = _merge_overlapping_islands(islands)
        except Exception:
            pass
    if not islands:
        try:
            self.report({'WARNING'}, _tr(context, 'No UV islands are selected in the UV Editor.', 'UVエディターで選択されているUVアイランドがありません。'))
        except Exception:
            pass
        return {'CANCELLED'}
    state = _state_snapshot(context)
    try:
        ok = _run_mode(context, ws, mode, islands)
        _restore_unselected(original, selected_keys, objects)
        _update_objects(objects)
        _restore_state(context, state)
        if not ok:
            try:
                self.report({'WARNING'}, _tr(context, f'Automatic packing failed: {mode}', f'自動パッキングが失敗しました: {mode}'))
            except Exception:
                pass
            return {'CANCELLED'}
        try:
            self.report({'INFO'}, _tr(context, f'Automatic packing finished: {mode}', f'自動パッキング完了: {mode}'))
        except Exception:
            pass
        return {'FINISHED'}
    except Exception as exc:
        try:
            _restore_unselected(original, selected_keys, objects)
            _update_objects(objects)
            _restore_state(context, state)
        except Exception:
            pass
        try:
            self.report({'WARNING'}, _tr(context, f'Automatic packing error: {exc}', f'自動パッキングでエラー: {exc}'))
        except Exception:
            pass
        return {'CANCELLED'}


def install(package_globals: dict | None = None, context=None) -> None:
    try:
        prev = globals().get('_SUS_18120_PREV_INSTALL')
        if callable(prev):
            prev(package_globals, context)
    except Exception:
        pass
    try:
        from . import unified_packing as up
        _ensure_unified_auto_pack_operator_properties(up)
        cls = getattr(up, 'SMARTUVSUITE_OT_unified_auto_pack', None)
        if cls is not None:
            cls.execute = _execute_18110
        up._multi_execute_unified_auto_pack = _execute_18110
        up._PACK_MODE_ITEMS = _MODE_ITEMS_18110
        up._mode_items = _mode_items
        up._canonical_pack_mode = _canonical
    except Exception:
        pass
    if package_globals is not None:
        try:
            package_globals['__version__'] = '1.0.0'
            package_globals['bl_info']['version'] = (1, 0, 0)
            package_globals['bl_info']['author'] = 'JELararagi'
            package_globals['_SUS_BL_INFO_FALLBACK'] = dict(package_globals.get('bl_info') or {})
        except Exception:
            pass


def apply_all(package_globals: dict | None = None, context=None) -> None:
    install(package_globals, context)


# -----------------------------------------------------------------------------
# Smart UV Suite 1.8.123 - exact setting-respecting Auto Pack final repair
# -----------------------------------------------------------------------------
# This final layer keeps the previous selected-UV-only and overlap-toggle behavior,
# but removes the remaining paths where dense/group/hotspot/trim presets could
# wrap back onto occupied cells or ignore visible common settings on complex UVs.


def _suv18123_island_bbox(islands: list[IslandData]) -> tuple[Vector, Vector] | None:
    pts = []
    for data in islands or []:
        try:
            data.refresh()
            pts.append(Vector(data.min_uv)); pts.append(Vector(data.max_uv))
        except Exception:
            pass
    return _bbox(pts)


def _suv18123_translate_islands(islands: list[IslandData], delta: Vector) -> None:
    written = set()
    for data in islands or []:
        for loop in list(getattr(data, 'loops', []) or []):
            try:
                layer = _uv_layer_for_loop(data, loop)
                if layer is None:
                    continue
                key = (id(loop), id(layer))
                if key in written:
                    continue
                written.add(key)
                loop[layer].uv = Vector(loop[layer].uv) + delta
            except Exception:
                pass
        try:
            data.refresh()
        except Exception:
            pass


def _suv18123_pack_subset_in_box(subset: list[IslandData], ws, origin: Vector, width: float, height: float, margin: float, *, fill: float = 0.86, sort_mode: str = 'AREA', allow_rotate: bool | None = None, allow_scale: bool | None = None) -> tuple[Vector, Vector] | None:
    subset = list(subset or [])
    if not subset:
        return None
    if allow_rotate is None:
        allow_rotate = _pack_rotate_allowed(ws)
    else:
        allow_rotate = _pack_rotate_allowed(ws, method_allows=bool(allow_rotate))
    if allow_scale is None:
        allow_scale = _pack_scale_allowed(ws)
    else:
        allow_scale = _pack_scale_allowed(ws, method_allows=bool(allow_scale))
    rects = []
    for i, data in enumerate(subset):
        try:
            data.refresh()
        except Exception:
            pass
        angle = _choose_rotation_angle(data, ws, method_allows=allow_rotate)
        try:
            data.rotation_angle = angle
        except Exception:
            pass
        w, h = _rect_for_angle(data, angle)
        rects.append({'index': i, 'w': w, 'h': h})
    seed = _int_attr(ws, 'unified_pack_seed', 0) if _bool_attr(ws, 'unified_pack_use_seed', False) else None
    placements = _pack_shelf(rects, max(float(width), 1.0e-9), max(float(height), 1.0e-9), max(float(margin), 0.0), fill=max(0.05, min(0.98, float(fill))), sort_mode=sort_mode, allow_scale=allow_scale, seed=seed)
    for i, x, y, sc in placements:
        data = subset[int(i)]
        _apply_placement(data, Vector(origin) + Vector((float(x), float(y))), float(sc) if allow_scale else 1.0, angle=float(getattr(data, 'rotation_angle', 0.0) or 0.0))
    return _suv18123_island_bbox(subset)


def _suv18123_pack_groups_dynamic(items: list[tuple[object, list[IslandData]]], ws, context, mode: str, *, layout: str = 'ROWS', margin_mult: float = 1.0) -> bool:
    if not items:
        return True
    base_margin = _margin(ws, multiplier=margin_mult)
    tile_u, tile_v = _target_tile(context, ws, mode)
    aspect_u, aspect_v = _target_aspect_scale(ws)
    tile_cols = _int_attr(ws, 'unified_pack_tile_columns', 10, 1, 100)
    tile_fill = _str_attr(ws, 'unified_pack_tile_fill', 'ROW')
    scale_ok = _pack_scale_allowed(ws)
    layout = str(layout or 'ROWS').upper()

    if layout == 'TILES':
        ok = False
        for gi, (_key, subset) in enumerate(items):
            du, dv = _tile_from_linear(gi, tile_cols, tile_fill)
            if _standard_rect_pack(subset, ws, context, mode, target_tile=(int(tile_u) + du, int(tile_v) + dv), margin_override=base_margin, fill=0.84, sort_mode='AREA'):
                ok = True
        return ok

    if scale_ok:
        # With scaling allowed, keep the visible ROWS/COLUMNS grouping inside the
        # requested atlas envelope.  The subset packer scales each group into its
        # own band, so groups do not overlap even on dense selections.
        n = max(1, len(items))
        ok = False
        if layout == 'COLUMNS':
            band_w = max(1.0e-9, (aspect_u - 2.0 * base_margin) / n)
            for col_i, (_key, subset) in enumerate(items):
                local_margin = min(base_margin, band_w * 0.25)
                origin = Vector((int(tile_u) + base_margin + col_i * band_w + local_margin, int(tile_v) + local_margin))
                width = max(1.0e-9, band_w - 2.0 * local_margin)
                height = max(1.0e-9, aspect_v - 2.0 * local_margin)
                ok = (_suv18123_pack_subset_in_box(subset, ws, origin, width, height, local_margin, fill=0.84 * _shape_fill_factor(ws), sort_mode='AREA') is not None) or ok
            return ok
        band_h = max(1.0e-9, (aspect_v - 2.0 * base_margin) / n)
        for row_i, (_key, subset) in enumerate(items):
            local_margin = min(base_margin, band_h * 0.25)
            origin = Vector((int(tile_u) + local_margin, int(tile_v) + base_margin + row_i * band_h + local_margin))
            width = max(1.0e-9, aspect_u - 2.0 * local_margin)
            height = max(1.0e-9, band_h - 2.0 * local_margin)
            ok = (_suv18123_pack_subset_in_box(subset, ws, origin, width, height, local_margin, fill=0.84 * _shape_fill_factor(ws), sort_mode='AREA') is not None) or ok
        return ok

    # With scale disabled the only correct behavior is to preserve island sizes
    # and expand the virtual layout instead of wrapping into occupied bands.
    ok = False
    cursor_x = int(tile_u) + base_margin
    cursor_y = int(tile_v) + base_margin
    row_h = 0.0
    for _key, subset in items:
        bbox = _suv18123_pack_subset_in_box(subset, ws, Vector((0.0, 0.0)), aspect_u, max(aspect_v, 1.0), base_margin, fill=0.84, sort_mode='AREA', allow_scale=False)
        if bbox is None:
            continue
        mn, mx = bbox
        gw = max(float(mx.x - mn.x), 1.0e-9)
        gh = max(float(mx.y - mn.y), 1.0e-9)
        if cursor_x > int(tile_u) + base_margin and cursor_x + gw + base_margin > int(tile_u) + aspect_u:
            cursor_x = int(tile_u) + base_margin
            cursor_y += row_h + base_margin
            row_h = 0.0
        _suv18123_translate_islands(subset, Vector((cursor_x, cursor_y)) - mn)
        cursor_x += gw + base_margin
        row_h = max(row_h, gh)
        ok = True
    return ok


def _pack_by_groups(islands: list[IslandData], ws, context, mode: str, key_fn, *, group_sort='KEY', margin_mult=1.0) -> bool:
    islands = _movable_islands(islands, ws)
    if not islands:
        return True
    groups = {}
    for data in islands:
        groups.setdefault(key_fn(data), []).append(data)
    if _bool_attr(ws, 'unified_pack_use_seed', False):
        items = list(groups.items())
        random.Random(_int_attr(ws, 'unified_pack_seed', 0)).shuffle(items)
    else:
        items = sorted(groups.items(), key=lambda kv: str(kv[0]) if group_sort == 'KEY' else -sum(d.width * d.height for d in kv[1]))
    layout = _str_attr(ws, 'pack_group_layout', 'SINGLE_TILE').upper()
    if layout == 'SINGLE_TILE':
        layout = 'ROWS'
    return _suv18123_pack_groups_dynamic(items, ws, context, mode, layout=layout, margin_mult=margin_mult)


def _pack_hotspot_grid(islands: list[IslandData], ws, context, mode: str) -> bool:
    islands = _movable_islands(islands, ws)
    if not islands:
        return True
    cols = max(1, _int_attr(ws, 'hotspot_cols', 4, 1, 64))
    rows = max(1, _int_attr(ws, 'hotspot_rows', 4, 1, 64))
    margin = _margin(ws, multiplier=1.0)
    base_u, base_v = _target_tile(context, ws, mode)
    aspect_u, aspect_v = _target_aspect_scale(ws)
    tile_columns = _int_attr(ws, 'unified_pack_tile_columns', 10, 1, 100)
    tile_fill = _str_attr(ws, 'unified_pack_tile_fill', 'ROW')
    cell_count = max(1, cols * rows)
    sort_mode = _str_attr(ws, 'hotspot_sort', 'AREA').upper()
    if _bool_attr(ws, 'unified_pack_use_seed', False):
        ordered = list(islands)
        random.Random(_int_attr(ws, 'unified_pack_seed', 0)).shuffle(ordered)
    elif sort_mode == 'WIDTH':
        ordered = sorted(islands, key=lambda d: (-d.width, -d.height, d.index))
    elif sort_mode == 'HEIGHT':
        ordered = sorted(islands, key=lambda d: (-d.height, -d.width, d.index))
    else:
        ordered = sorted(islands, key=lambda d: (-(d.width * d.height), d.index))
    fill_order = _str_attr(ws, 'hotspot_fill_order', 'ROW').upper()
    keep_aspect = _bool_attr(ws, 'hotspot_keep_aspect', True)
    scale_ok = _pack_scale_allowed(ws)
    rotate_ok = _pack_rotate_allowed(ws)
    max_w = max((d.width for d in ordered), default=0.0)
    max_h = max((d.height for d in ordered), default=0.0)
    base_cell_w = max(1.0e-9, (aspect_u - 2.0 * margin) / cols)
    base_cell_h = max(1.0e-9, (aspect_v - 2.0 * margin) / rows)
    cell_w = base_cell_w if scale_ok else max(base_cell_w, max_w + margin)
    cell_h = base_cell_h if scale_ok else max(base_cell_h, max_h + margin)
    for n, data in enumerate(ordered):
        tile_index = n // cell_count
        local_n = n % cell_count
        du, dv = _tile_from_linear(tile_index, tile_columns, tile_fill)
        if fill_order == 'COLUMN':
            c = (local_n // rows) % cols
            r = local_n % rows
        else:
            c = local_n % cols
            r = (local_n // cols) % rows
        tile_origin = Vector((int(base_u) + du, int(base_v) + dv))
        angle = _choose_rotation_angle(data, ws, method_allows=rotate_ok)
        data.rotation_angle = angle
        rw, rh = _rect_for_angle(data, angle)
        cell_min = tile_origin + Vector((margin + c * cell_w + margin * 0.25, margin + r * cell_h + margin * 0.25))
        target_w = max(1.0e-9, cell_w - margin * 0.5)
        target_h = max(1.0e-9, cell_h - margin * 0.5)
        if not scale_ok:
            scale = 1.0
        elif keep_aspect:
            scale = min(target_w / max(rw, 1.0e-12), target_h / max(rh, 1.0e-12))
        else:
            scale = (target_w / max(rw, 1.0e-12), target_h / max(rh, 1.0e-12))
        _apply_placement(data, cell_min, scale, angle=angle)
    return True


def _pack_trim_strip(islands: list[IslandData], ws, context, mode: str) -> bool:
    islands = _movable_islands(islands, ws)
    if not islands:
        return True
    margin = _margin(ws, multiplier=1.0)
    base_u, base_v = _target_tile(context, ws, mode)
    aspect_u, aspect_v = _target_aspect_scale(ws)
    fill_order = _str_attr(ws, 'hotspot_fill_order', 'ROW').upper()
    scale_ok = _pack_scale_allowed(ws)
    rotate_ok = _pack_rotate_allowed(ws)
    if _bool_attr(ws, 'unified_pack_use_seed', False):
        ordered = list(islands)
        random.Random(_int_attr(ws, 'unified_pack_seed', 0)).shuffle(ordered)
    else:
        ordered = sorted(islands, key=lambda d: (-d.height if fill_order != 'COLUMN' else -d.width, d.index))
    strips = max(1, min(max(len(ordered), 1), _int_attr(ws, 'hotspot_rows' if fill_order != 'COLUMN' else 'hotspot_cols', 4, 1, 64)))
    tile_columns = _int_attr(ws, 'unified_pack_tile_columns', 10, 1, 100)
    tile_fill = _str_attr(ws, 'unified_pack_tile_fill', 'ROW')
    if fill_order == 'COLUMN':
        strip_w = max(1.0e-9, (aspect_u - 2.0 * margin) / strips)
        y_by_strip = [margin for _ in range(strips)]
        tile_by_strip = [0 for _ in range(strips)]
        for idx, data in enumerate(ordered):
            strip = idx % strips
            angle = _choose_rotation_angle(data, ws, method_allows=rotate_ok)
            data.rotation_angle = angle
            rw, rh = _rect_for_angle(data, angle)
            dst_w = max(1.0e-9, strip_w - margin)
            scale = (dst_w / max(rw, 1.0e-12)) if scale_ok else 1.0
            h = rh * (scale if not isinstance(scale, tuple) else scale[1])
            if y_by_strip[strip] > margin and y_by_strip[strip] + h + margin > aspect_v:
                y_by_strip[strip] = margin
                tile_by_strip[strip] += 1
            du, dv = _tile_from_linear(tile_by_strip[strip], tile_columns, tile_fill)
            origin = Vector((int(base_u) + du, int(base_v) + dv))
            x = origin.x + margin + strip * strip_w + margin * 0.5
            y = origin.y + y_by_strip[strip]
            _apply_placement(data, Vector((x, y)), scale, angle=angle)
            y_by_strip[strip] += h + margin
    else:
        strip_h = max(1.0e-9, (aspect_v - 2.0 * margin) / strips)
        x_by_strip = [margin for _ in range(strips)]
        tile_by_strip = [0 for _ in range(strips)]
        for idx, data in enumerate(ordered):
            strip = idx % strips
            angle = _choose_rotation_angle(data, ws, method_allows=rotate_ok)
            data.rotation_angle = angle
            rw, rh = _rect_for_angle(data, angle)
            dst_h = max(1.0e-9, strip_h - margin)
            scale = (dst_h / max(rh, 1.0e-12)) if scale_ok else 1.0
            w = rw * (scale if not isinstance(scale, tuple) else scale[0])
            if x_by_strip[strip] > margin and x_by_strip[strip] + w + margin > aspect_u:
                x_by_strip[strip] = margin
                tile_by_strip[strip] += 1
            du, dv = _tile_from_linear(tile_by_strip[strip], tile_columns, tile_fill)
            origin = Vector((int(base_u) + du, int(base_v) + dv))
            x = origin.x + x_by_strip[strip]
            y = origin.y + margin + strip * strip_h + margin * 0.5
            _apply_placement(data, Vector((x, y)), scale, angle=angle)
            x_by_strip[strip] += w + margin
    return True


def _run_mode(context, ws, mode: str, islands: list[IslandData]) -> bool:
    mode = _canonical(mode)
    if not islands:
        return False
    _mark_pack_setting_metadata(islands)
    movable = _movable_islands(islands, ws)
    if not movable:
        return True
    if _pack_chart_rescale_allowed(ws):
        if mode in {'DENSITY_PRIORITY', 'MESH_AREA_SCALE_PACK', 'CHART_DISTRIBUTION'}:
            _rescale_to_mesh_area(movable, strength=1.0)
        elif mode == 'LOW_DISTORTION_PACK':
            _rescale_to_mesh_area(movable, strength=0.62)
    for data in islands:
        try:
            data.refresh()
        except Exception:
            pass
    rotate_allowed = _pack_rotate_allowed(ws)
    if mode == 'SMART_DENSE':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.96, sort_mode='AREA', allow_rotate=rotate_allowed, margin_override=_margin(ws, multiplier=0.75))
    if mode == 'FAST_NO_ROTATE':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.78, sort_mode='INDEX', allow_rotate=rotate_allowed)
    if mode == 'DENSITY_PRIORITY':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.90, sort_mode='AREA', allow_rotate=rotate_allowed)
    if mode == 'MESH_AREA_SCALE_PACK':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.88, sort_mode='AREA', allow_rotate=rotate_allowed)
    if mode in {'GROUP_SIMILAR', 'GROUP_MATERIAL', 'GROUP_IDENTICAL'}:
        group_mode = _str_attr(ws, 'pack_group_mode', 'SIMILAR').upper()
        if group_mode == 'MATERIAL':
            return _pack_by_groups(islands, ws, context, mode, lambda d: d.material_index, group_sort='KEY', margin_mult=1.0)
        if group_mode == 'IDENTICAL' or _bool_attr(ws, 'unified_pack_stack_identical', False):
            return _pack_identical_stack(islands, ws, context, mode)
        return _pack_by_groups(islands, ws, context, mode, lambda d: _similar_group_key(d, ws))
    if mode == 'UDIM_STANDARD':
        return _standard_rect_pack(islands, ws, context, mode, target_tile=_target_tile(context, ws, mode), fill=0.86, sort_mode='AREA', allow_rotate=rotate_allowed)
    if mode == 'UDIM_KEEP_TILES':
        return _pack_keep_tiles(islands, ws, context, mode)
    if mode == 'UDIM_AUTO_TILES':
        return _pack_auto_tiles(islands, ws, context, mode)
    if mode == 'CHART_DISTRIBUTION':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.94, sort_mode='ASPECT', allow_rotate=rotate_allowed, margin_override=_margin(ws, multiplier=0.8))
    if mode == 'BAKE_SAFE_CHART':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.76, sort_mode='AREA', allow_rotate=rotate_allowed, margin_override=_margin(ws, multiplier=1.75, bake_safe=True))
    if mode == 'EXISTING_CHART_REPACK':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.80, sort_mode='INDEX', allow_rotate=rotate_allowed)
    if mode == 'LOW_DISTORTION_PACK':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.82, sort_mode='HEIGHT', allow_rotate=rotate_allowed)
    if mode == 'LIGHTMAP':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.70, sort_mode='AREA', allow_rotate=rotate_allowed, margin_override=_margin(ws, multiplier=1.5, bake_safe=True))
    if mode == 'HOTSPOT_GRID':
        return _pack_hotspot_grid(islands, ws, context, mode)
    if mode == 'TRIM_STRIP':
        return _pack_trim_strip(islands, ws, context, mode)
    return _standard_rect_pack(islands, ws, context, mode, fill=0.86, sort_mode='AREA', allow_rotate=rotate_allowed)


_SUS_18123_PREV_INSTALL = globals().get('install')

def install(package_globals: dict | None = None, context=None) -> None:
    try:
        prev = globals().get('_SUS_18123_PREV_INSTALL')
        if callable(prev):
            prev(package_globals, context)
    except Exception:
        pass
    try:
        from . import unified_packing as up
        _ensure_unified_auto_pack_operator_properties(up)
        cls = getattr(up, 'SMARTUVSUITE_OT_unified_auto_pack', None)
        if cls is not None:
            cls.execute = _execute_18110
        up._multi_execute_unified_auto_pack = _execute_18110
        up._PACK_MODE_ITEMS = _MODE_ITEMS_18110
        up._mode_items = _mode_items
        up._canonical_pack_mode = _canonical
    except Exception:
        pass
    if package_globals is not None:
        try:
            package_globals['__version__'] = '1.0.0'
            package_globals['bl_info']['version'] = (1, 0, 0)
            package_globals['bl_info']['author'] = 'JELararagi'
            package_globals['_SUS_BL_INFO_FALLBACK'] = dict(package_globals.get('bl_info') or {})
        except Exception:
            pass


def apply_all(package_globals: dict | None = None, context=None) -> None:
    install(package_globals, context)

# Smart UV Suite 1.8.124 - verified Auto Pack setting bridge repair.
# Keeps every visible packing setting in the final placement path and fixes
# non-overlapping virtual-grid/strip overflow for complex UVs when scaling is disabled.

def _suv18124_sorted_islands_for_hotspot(islands: list[IslandData], ws, *, trim: bool = False) -> list[IslandData]:
    mode = _str_attr(ws, 'hotspot_sort', 'AREA').upper()
    if _bool_attr(ws, 'unified_pack_use_seed', False):
        ordered = list(islands)
        random.Random(_int_attr(ws, 'unified_pack_seed', 0)).shuffle(ordered)
        return ordered
    if mode == 'WIDTH':
        return sorted(islands, key=lambda d: (-float(getattr(d, 'width', 0.0)), -float(getattr(d, 'height', 0.0)), int(getattr(d, 'index', 0))))
    if mode == 'HEIGHT':
        return sorted(islands, key=lambda d: (-float(getattr(d, 'height', 0.0)), -float(getattr(d, 'width', 0.0)), int(getattr(d, 'index', 0))))
    if mode == 'INDEX':
        return sorted(islands, key=lambda d: int(getattr(d, 'index', 0)))
    # AREA remains the default for both grid and trim; it is deterministic and
    # makes the sort setting observable on non-uniform production UVs.
    return sorted(islands, key=lambda d: (-(float(getattr(d, 'width', 0.0)) * float(getattr(d, 'height', 0.0))), int(getattr(d, 'index', 0))))


def _suv18124_prepared_rects(islands: list[IslandData], ws, *, method_allows_rotate: bool) -> list[tuple[IslandData, float, float, float]]:
    out = []
    rotate_ok = _pack_rotate_allowed(ws, method_allows=bool(method_allows_rotate))
    for data in islands or []:
        angle = _choose_rotation_angle(data, ws, method_allows=rotate_ok)
        try:
            data.rotation_angle = angle
            data.rotate_90 = abs((angle % math.pi) - math.pi * 0.5) < 1.0e-8
        except Exception:
            pass
        rw, rh = _rect_for_angle(data, angle)
        out.append((data, float(rw), float(rh), float(angle)))
    return out


def _suv18124_logic_origin(base_u: int, base_v: int, index: int, columns: int, fill: str, stride_u: float, stride_v: float) -> Vector:
    du, dv = _tile_from_linear(index, columns, fill)
    return Vector((float(base_u) + float(du) * float(stride_u), float(base_v) + float(dv) * float(stride_v)))


def _pack_hotspot_grid(islands: list[IslandData], ws, context, mode: str) -> bool:
    islands = _movable_islands(islands, ws)
    if not islands:
        return True
    cols = max(1, _int_attr(ws, 'hotspot_cols', 4, 1, 64))
    rows = max(1, _int_attr(ws, 'hotspot_rows', 4, 1, 64))
    margin = _margin(ws, multiplier=1.0)
    base_u, base_v = _target_tile(context, ws, mode)
    aspect_u, aspect_v = _target_aspect_scale(ws)
    tile_columns = _int_attr(ws, 'unified_pack_tile_columns', 10, 1, 100)
    tile_fill = _str_attr(ws, 'unified_pack_tile_fill', 'ROW')
    cell_count = max(1, cols * rows)
    ordered = _suv18124_sorted_islands_for_hotspot(islands, ws)
    prepared = _suv18124_prepared_rects(ordered, ws, method_allows_rotate=True)
    fill_order = _str_attr(ws, 'hotspot_fill_order', 'ROW').upper()
    keep_aspect = _bool_attr(ws, 'hotspot_keep_aspect', True)
    scale_ok = _pack_scale_allowed(ws)
    max_rw = max((rw for _data, rw, _rh, _angle in prepared), default=0.0)
    max_rh = max((rh for _data, _rw, rh, _angle in prepared), default=0.0)
    base_cell_w = max(1.0e-9, (aspect_u - 2.0 * margin) / float(cols))
    base_cell_h = max(1.0e-9, (aspect_v - 2.0 * margin) / float(rows))
    # If scaling is disabled, the logical hotspot grid is allowed to become wider
    # or taller than a UDIM tile.  The stride below is then enlarged so the next
    # logical tile cannot overlap the previous one.
    cell_w = base_cell_w if scale_ok else max(base_cell_w, max_rw + margin)
    cell_h = base_cell_h if scale_ok else max(base_cell_h, max_rh + margin)
    block_w = max(aspect_u, margin * 2.0 + cell_w * float(cols))
    block_h = max(aspect_v, margin * 2.0 + cell_h * float(rows))
    stride_u = max(aspect_u, block_w)
    stride_v = max(aspect_v, block_h)
    for n, (data, rw, rh, angle) in enumerate(prepared):
        tile_index = n // cell_count
        local_n = n % cell_count
        if fill_order == 'COLUMN':
            c = (local_n // rows) % cols
            r = local_n % rows
        else:
            c = local_n % cols
            r = (local_n // cols) % rows
        origin = _suv18124_logic_origin(int(base_u), int(base_v), tile_index, tile_columns, tile_fill, stride_u, stride_v)
        cell_min = origin + Vector((margin + c * cell_w, margin + r * cell_h))
        target_w = max(1.0e-9, cell_w - margin)
        target_h = max(1.0e-9, cell_h - margin)
        if not scale_ok:
            scale = 1.0
        elif keep_aspect:
            scale = min(target_w / max(rw, 1.0e-12), target_h / max(rh, 1.0e-12))
        else:
            scale = (target_w / max(rw, 1.0e-12), target_h / max(rh, 1.0e-12))
        _apply_placement(data, cell_min, scale, angle=angle)
    return True


def _pack_trim_strip(islands: list[IslandData], ws, context, mode: str) -> bool:
    islands = _movable_islands(islands, ws)
    if not islands:
        return True
    margin = _margin(ws, multiplier=1.0)
    base_u, base_v = _target_tile(context, ws, mode)
    aspect_u, aspect_v = _target_aspect_scale(ws)
    fill_order = _str_attr(ws, 'hotspot_fill_order', 'ROW').upper()
    scale_ok = _pack_scale_allowed(ws)
    ordered = _suv18124_sorted_islands_for_hotspot(islands, ws, trim=True)
    prepared = _suv18124_prepared_rects(ordered, ws, method_allows_rotate=True)
    tile_columns = _int_attr(ws, 'unified_pack_tile_columns', 10, 1, 100)
    tile_fill = _str_attr(ws, 'unified_pack_tile_fill', 'ROW')
    max_rw = max((rw for _data, rw, _rh, _angle in prepared), default=0.0)
    max_rh = max((rh for _data, _rw, rh, _angle in prepared), default=0.0)
    if fill_order == 'COLUMN':
        strips = max(1, _int_attr(ws, 'hotspot_cols', 1, 1, 64))
        base_strip_w = max(1.0e-9, (aspect_u - 2.0 * margin) / float(strips))
        strip_w = base_strip_w if scale_ok else max(base_strip_w, max_rw + margin)
        block_w = max(aspect_u, margin * 2.0 + strip_w * float(strips))
        stride_u = max(aspect_u, block_w)
        stride_v = max(aspect_v, max_rh + margin * 2.0)
        y_by_strip = [margin for _ in range(strips)]
        tile_by_strip = [0 for _ in range(strips)]
        for idx, (data, rw, rh, angle) in enumerate(prepared):
            strip = idx % strips
            target_w = max(1.0e-9, strip_w - margin)
            scale = (target_w / max(rw, 1.0e-12)) if scale_ok else 1.0
            placed_h = rh * (scale if not isinstance(scale, tuple) else scale[1])
            # Move to the next logical tile only after the current island would
            # exceed the visible tile height.  Logical tile spacing uses the
            # enlarged stride, so a very large island cannot collide with the
            # following tile.
            if y_by_strip[strip] > margin and y_by_strip[strip] + placed_h + margin > aspect_v:
                y_by_strip[strip] = margin
                tile_by_strip[strip] += 1
            origin = _suv18124_logic_origin(int(base_u), int(base_v), tile_by_strip[strip], tile_columns, tile_fill, stride_u, stride_v)
            pos = origin + Vector((margin + strip * strip_w, y_by_strip[strip]))
            _apply_placement(data, pos, scale, angle=angle)
            y_by_strip[strip] += placed_h + margin
    else:
        strips = max(1, _int_attr(ws, 'hotspot_rows', 1, 1, 64))
        base_strip_h = max(1.0e-9, (aspect_v - 2.0 * margin) / float(strips))
        strip_h = base_strip_h if scale_ok else max(base_strip_h, max_rh + margin)
        stride_u = max(aspect_u, max_rw + margin * 2.0)
        block_h = max(aspect_v, margin * 2.0 + strip_h * float(strips))
        stride_v = max(aspect_v, block_h)
        x_by_strip = [margin for _ in range(strips)]
        tile_by_strip = [0 for _ in range(strips)]
        for idx, (data, rw, rh, angle) in enumerate(prepared):
            strip = idx % strips
            target_h = max(1.0e-9, strip_h - margin)
            scale = (target_h / max(rh, 1.0e-12)) if scale_ok else 1.0
            placed_w = rw * (scale if not isinstance(scale, tuple) else scale[0])
            if x_by_strip[strip] > margin and x_by_strip[strip] + placed_w + margin > aspect_u:
                x_by_strip[strip] = margin
                tile_by_strip[strip] += 1
            origin = _suv18124_logic_origin(int(base_u), int(base_v), tile_by_strip[strip], tile_columns, tile_fill, stride_u, stride_v)
            pos = origin + Vector((x_by_strip[strip], margin + strip * strip_h))
            _apply_placement(data, pos, scale, angle=angle)
            x_by_strip[strip] += placed_w + margin
    return True


_SUS_18124_PREV_INSTALL = globals().get('install')

def install(package_globals: dict | None = None, context=None) -> None:
    try:
        prev = globals().get('_SUS_18124_PREV_INSTALL')
        if callable(prev):
            prev(package_globals, context)
    except Exception:
        pass
    try:
        from . import unified_packing as up
        _ensure_unified_auto_pack_operator_properties(up)
        cls = getattr(up, 'SMARTUVSUITE_OT_unified_auto_pack', None)
        if cls is not None:
            cls.execute = _execute_18110
        up._multi_execute_unified_auto_pack = _execute_18110
        up._PACK_MODE_ITEMS = _MODE_ITEMS_18110
        up._mode_items = _mode_items
        up._canonical_pack_mode = _canonical
    except Exception:
        pass
    if package_globals is not None:
        try:
            package_globals['__version__'] = '1.0.0'
            package_globals['bl_info']['version'] = (1, 0, 0)
            package_globals['bl_info']['author'] = 'JELararagi'
            package_globals['_SUS_BL_INFO_FALLBACK'] = dict(package_globals.get('bl_info') or {})
        except Exception:
            pass


def apply_all(package_globals: dict | None = None, context=None) -> None:
    install(package_globals, context)

# Smart UV Suite 1.8.125 - make Group Identical obey the visible Stack Identical switch.
# The packing method selector is a preset selector; after choosing it, every
# visible setting must remain authoritative.  Therefore identical-group stacking
# is controlled only by unified_pack_stack_identical, not merely by the preset or
# the Group Mode enum value.

def _run_mode(context, ws, mode: str, islands: list[IslandData]) -> bool:
    mode = _canonical(mode)
    if not islands:
        return False
    _mark_pack_setting_metadata(islands)
    movable = _movable_islands(islands, ws)
    if not movable:
        return True
    if _pack_chart_rescale_allowed(ws):
        if mode in {'DENSITY_PRIORITY', 'MESH_AREA_SCALE_PACK', 'CHART_DISTRIBUTION'}:
            _rescale_to_mesh_area(movable, strength=1.0)
        elif mode == 'LOW_DISTORTION_PACK':
            _rescale_to_mesh_area(movable, strength=0.62)
    for data in islands:
        try:
            data.refresh()
        except Exception:
            pass
    rotate_allowed = _pack_rotate_allowed(ws)
    if mode == 'SMART_DENSE':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.96, sort_mode='AREA', allow_rotate=rotate_allowed, margin_override=_margin(ws, multiplier=0.75))
    if mode == 'FAST_NO_ROTATE':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.78, sort_mode='INDEX', allow_rotate=rotate_allowed)
    if mode == 'DENSITY_PRIORITY':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.90, sort_mode='AREA', allow_rotate=rotate_allowed)
    if mode == 'MESH_AREA_SCALE_PACK':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.88, sort_mode='AREA', allow_rotate=rotate_allowed)
    if mode in {'GROUP_SIMILAR', 'GROUP_MATERIAL', 'GROUP_IDENTICAL'}:
        group_mode = _str_attr(ws, 'pack_group_mode', 'SIMILAR').upper()
        if _bool_attr(ws, 'unified_pack_stack_identical', False):
            return _pack_identical_stack(islands, ws, context, mode)
        if group_mode == 'MATERIAL':
            return _pack_by_groups(islands, ws, context, mode, lambda d: d.material_index, group_sort='KEY', margin_mult=1.0)
        if group_mode == 'IDENTICAL' or mode == 'GROUP_IDENTICAL':
            return _pack_by_groups(islands, ws, context, mode, lambda d: _identical_group_key(d, ws), group_sort='KEY', margin_mult=1.0)
        return _pack_by_groups(islands, ws, context, mode, lambda d: _similar_group_key(d, ws), group_sort='KEY', margin_mult=1.0)
    if mode == 'UDIM_STANDARD':
        return _standard_rect_pack(islands, ws, context, mode, target_tile=_target_tile(context, ws, mode), fill=0.86, sort_mode='AREA', allow_rotate=rotate_allowed)
    if mode == 'UDIM_KEEP_TILES':
        return _pack_keep_tiles(islands, ws, context, mode)
    if mode == 'UDIM_AUTO_TILES':
        return _pack_auto_tiles(islands, ws, context, mode)
    if mode == 'CHART_DISTRIBUTION':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.94, sort_mode='ASPECT', allow_rotate=rotate_allowed, margin_override=_margin(ws, multiplier=0.8))
    if mode == 'BAKE_SAFE_CHART':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.76, sort_mode='AREA', allow_rotate=rotate_allowed, margin_override=_margin(ws, multiplier=1.75, bake_safe=True))
    if mode == 'EXISTING_CHART_REPACK':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.80, sort_mode='INDEX', allow_rotate=rotate_allowed)
    if mode == 'LOW_DISTORTION_PACK':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.82, sort_mode='HEIGHT', allow_rotate=rotate_allowed)
    if mode == 'LIGHTMAP':
        return _standard_rect_pack(islands, ws, context, mode, fill=0.70, sort_mode='AREA', allow_rotate=rotate_allowed, margin_override=_margin(ws, multiplier=1.5, bake_safe=True))
    if mode == 'HOTSPOT_GRID':
        return _pack_hotspot_grid(islands, ws, context, mode)
    if mode == 'TRIM_STRIP':
        return _pack_trim_strip(islands, ws, context, mode)
    return _standard_rect_pack(islands, ws, context, mode, fill=0.86, sort_mode='AREA', allow_rotate=rotate_allowed)


_SUS_18125_PREV_INSTALL = globals().get('install')

def install(package_globals: dict | None = None, context=None) -> None:
    try:
        prev = globals().get('_SUS_18125_PREV_INSTALL')
        if callable(prev):
            prev(package_globals, context)
    except Exception:
        pass
    try:
        from . import unified_packing as up
        _ensure_unified_auto_pack_operator_properties(up)
        cls = getattr(up, 'SMARTUVSUITE_OT_unified_auto_pack', None)
        if cls is not None:
            cls.execute = _execute_18110
        up._multi_execute_unified_auto_pack = _execute_18110
        up._PACK_MODE_ITEMS = _MODE_ITEMS_18110
        up._mode_items = _mode_items
        up._canonical_pack_mode = _canonical
    except Exception:
        pass
    if package_globals is not None:
        try:
            package_globals['__version__'] = '1.0.0'
            package_globals['bl_info']['version'] = (1, 0, 0)
            package_globals['bl_info']['author'] = 'JELararagi'
            package_globals['_SUS_BL_INFO_FALLBACK'] = dict(package_globals.get('bl_info') or {})
        except Exception:
            pass


def apply_all(package_globals: dict | None = None, context=None) -> None:
    install(package_globals, context)

# Smart UV Suite 1.8.126 - UDIM Keep Tiles overflow-safe placement.
# When scaling is disabled, a packed source UDIM group can legitimately extend
# outside a 1x1 tile.  Keep Tiles now preserves the source-tile grouping while
# spacing the resulting groups by their actual packed extents, so adjacent UDIM
# groups cannot collide.

def _pack_keep_tiles(islands: list[IslandData], ws, context, mode: str) -> bool:
    islands = _movable_islands(islands, ws)
    if not islands:
        return True
    groups: dict[tuple[int, int], list[IslandData]] = {}
    for data in islands:
        groups.setdefault(tuple(getattr(data, 'tile', (0, 0))), []).append(data)
    if not groups:
        return True
    target_mode = _target_tile_setting(ws)
    start_u, start_v = _target_tile(context, ws, mode)
    min_src_u = min(int(tile[0]) for tile in groups)
    min_src_v = min(int(tile[1]) for tile in groups)
    packed: list[tuple[tuple[int, int], list[IslandData], Vector, Vector]] = []
    ok = False
    # First pack every source-tile group in local space.  This gives the real
    # output extents for scale-off cases before we decide final group spacing.
    for tile, subset in sorted(groups.items(), key=lambda kv: (int(kv[0][1]), int(kv[0][0]))):
        if _standard_rect_pack(subset, ws, context, mode, target_tile=(0, 0), fill=0.84, sort_mode='AREA'):
            ok = True
        bb = _suv18123_island_bbox(subset)
        if bb is None:
            continue
        mn, mx = bb
        packed.append((tile, subset, Vector(mn), Vector(mx)))
    if not packed:
        return ok
    aspect_u, aspect_v = _target_aspect_scale(ws)
    margin = _margin(ws)
    if _pack_scale_allowed(ws):
        stride_u = max(aspect_u, 1.0)
        stride_v = max(aspect_v, 1.0)
    else:
        stride_u = max(aspect_u, max(float(mx.x - mn.x) for _tile, _subset, mn, mx in packed) + margin)
        stride_v = max(aspect_v, max(float(mx.y - mn.y) for _tile, _subset, mn, mx in packed) + margin)
    for tile, subset, mn, mx in packed:
        if target_mode == 'KEEP':
            rel_u = int(tile[0])
            rel_v = int(tile[1])
        else:
            rel_u = int(tile[0]) - int(min_src_u)
            rel_v = int(tile[1]) - int(min_src_v)
        dst_min = Vector((float(start_u) + float(rel_u) * stride_u + margin, float(start_v) + float(rel_v) * stride_v + margin))
        _suv18123_translate_islands(subset, dst_min - mn)
    return ok


_SUS_18126_PREV_INSTALL = globals().get('install')

def install(package_globals: dict | None = None, context=None) -> None:
    try:
        prev = globals().get('_SUS_18126_PREV_INSTALL')
        if callable(prev):
            prev(package_globals, context)
    except Exception:
        pass
    try:
        from . import unified_packing as up
        _ensure_unified_auto_pack_operator_properties(up)
        cls = getattr(up, 'SMARTUVSUITE_OT_unified_auto_pack', None)
        if cls is not None:
            cls.execute = _execute_18110
        up._multi_execute_unified_auto_pack = _execute_18110
        up._PACK_MODE_ITEMS = _MODE_ITEMS_18110
        up._mode_items = _mode_items
        up._canonical_pack_mode = _canonical
    except Exception:
        pass
    if package_globals is not None:
        try:
            package_globals['__version__'] = '1.0.0'
            package_globals['bl_info']['version'] = (1, 0, 0)
            package_globals['bl_info']['author'] = 'JELararagi'
            package_globals['_SUS_BL_INFO_FALLBACK'] = dict(package_globals.get('bl_info') or {})
        except Exception:
            pass


def apply_all(package_globals: dict | None = None, context=None) -> None:
    install(package_globals, context)
