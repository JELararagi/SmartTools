def build_handlers(api):
    backend = api._run_uv_layout(
            'suv_match_stitch_active_preserve', mode='mode', preserve_anchor='apply_mode', score_threshold='value'
        )

    def run(context, op):
        return backend(context, op)

    return {
        'smart_uv_suite.seam_match_stitch_active_preserve': api.Handler(run, 'Match selected or similar islands to the active island and stitch stacked matches.', '選択または類似アイランドをアクティブ島に合わせ、重ねた境界を縫い合わせます。'),
        'smart_uv_suite.seam_batch_match_stitch_active_preserve': api.Handler(
            api._run_uv_layout('suv_batch_match_stitch_active_preserve'),
            'Match and stitch islands against the active island of each selected mesh.',
            '選択メッシュごとにアクティブアイランドを基準としてアイランドを合わせ、縫い合わせます。'),
    }
