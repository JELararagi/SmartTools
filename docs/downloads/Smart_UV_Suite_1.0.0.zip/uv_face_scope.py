
# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Strict UV Editor full-face scope support for pack, atlas and trim tools.

This module intentionally treats only UV faces whose face-selection flag is on
and whose every UV corner is selected as the operation domain.  Partial UV
vertex/edge selections are rejected so adjacent faces sharing one vertex/edge do
not get pulled into pack/layout/atlas operations.  Mesh selection in the 3D View
is restored after scoped operations.
"""

from __future__ import annotations

import functools
from typing import Any, Callable

import bpy
import bmesh

_WRAPPED: list[tuple[type, Callable[..., Any]]] = []
_PATCHED_FUNCS: list[tuple[Any, str, Callable[..., Any]]] = []
_DEPTH = 0


def _active_mesh_object(context):
    obj = getattr(context, 'edit_object', None) or getattr(context, 'active_object', None)
    if obj is not None and getattr(obj, 'type', None) == 'MESH':
        return obj
    try:
        obj = context.view_layer.objects.active
        if obj is not None and getattr(obj, 'type', None) == 'MESH':
            return obj
    except Exception:
        pass
    return None


def _bool_values(me, name: str) -> list[bool]:
    try:
        attrs = getattr(me, 'attributes', None)
        if attrs is None:
            return []
        attr = attrs.get(name)
        if attr is None:
            return []
        return [bool(getattr(item, 'value', False)) for item in getattr(attr, 'data', [])]
    except Exception:
        return []


def _read_uv_attr_state(me) -> dict[str, list[bool]]:
    return {
        'face': _bool_values(me, '.uv_select_face'),
        'vert': _bool_values(me, '.uv_select_vert'),
        'edge': _bool_values(me, '.uv_select_edge'),
    }


def _ensure_bool_attr(me, name: str, domain: str):
    try:
        attrs = getattr(me, 'attributes', None)
        if attrs is None:
            return None
        attr = attrs.get(name)
        if attr is None:
            attr = attrs.new(name=name, type='BOOLEAN', domain=domain)
        return attr
    except Exception:
        return None


def _loop_index(loop) -> int:
    try:
        return int(getattr(loop, 'index', -1))
    except Exception:
        return -1


def _face_index(face) -> int:
    try:
        return int(getattr(face, 'index', -1))
    except Exception:
        return -1


def strict_selected_face_indices(context, obj, bm, uv_layer, attr_state: dict[str, list[bool]] | None = None) -> tuple[set[int], bool]:
    """Return complete UV-face selection indices and whether any UV selection exists."""
    me = getattr(obj, 'data', None)
    state = dict(attr_state or {})
    face_flags = list(state.get('face') or (_bool_values(me, '.uv_select_face') if me is not None else []))
    vert_flags = list(state.get('vert') or (_bool_values(me, '.uv_select_vert') if me is not None else []))
    edge_flags = list(state.get('edge') or (_bool_values(me, '.uv_select_edge') if me is not None else []))
    has_any_attr_selection = any(face_flags) or any(vert_flags) or any(edge_flags)
    selected: set[int] = set()
    try:
        bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
        bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
    except Exception:
        pass

    # Blender 5.1 UV face-selection attributes are authoritative when present.
    if face_flags:
        for face in bm.faces:
            fi = _face_index(face)
            if fi < 0 or fi >= len(face_flags) or not bool(face_flags[fi]):
                continue
            loops = list(getattr(face, 'loops', ()) or ())
            if not loops:
                continue
            all_corners = True
            for loop in loops:
                li = _loop_index(loop)
                corner_ok = False
                if vert_flags and 0 <= li < len(vert_flags):
                    corner_ok = bool(vert_flags[li])
                else:
                    try:
                        corner_ok = bool(getattr(loop[uv_layer], 'select', False))
                    except Exception:
                        corner_ok = False
                if not corner_ok:
                    all_corners = False
                    break
            if all_corners:
                selected.add(fi)
        return selected, has_any_attr_selection

    # Fallback for environments without hidden UV face attributes: accept only
    # faces whose every UV corner is selected.  A single vertex/edge selection is
    # therefore never expanded into adjacent faces.
    has_any_loop_selection = False
    for face in bm.faces:
        loops = list(getattr(face, 'loops', ()) or ())
        if not loops:
            continue
        all_corners = True
        for loop in loops:
            try:
                luv = loop[uv_layer]
                corner = bool(getattr(luv, 'select', False))
                edge = bool(getattr(luv, 'select_edge', False))
            except Exception:
                corner = False
                edge = False
            has_any_loop_selection = has_any_loop_selection or corner or edge
            if not corner:
                all_corners = False
        if all_corners:
            fi = _face_index(face)
            if fi >= 0:
                selected.add(fi)
    return selected, bool(has_any_attr_selection or has_any_loop_selection)


def _write_final_uv_selection_attrs(context, obj, selected_faces: set[int]) -> None:
    me = getattr(obj, 'data', None)
    if me is None:
        return
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed = False
    try:
        if old_mode != 'OBJECT':
            try:
                bpy.ops.object.mode_set(mode='OBJECT')
                changed = True
            except Exception:
                return
        uv_vert = _ensure_bool_attr(me, '.uv_select_vert', 'CORNER')
        uv_edge = _ensure_bool_attr(me, '.uv_select_edge', 'CORNER')
        uv_face = _ensure_bool_attr(me, '.uv_select_face', 'FACE')
        face_flags = [False] * len(getattr(me, 'polygons', []) or [])
        loop_flags = [False] * len(getattr(me, 'loops', []) or [])
        for poly in getattr(me, 'polygons', []) or []:
            try:
                flag = int(poly.index) in selected_faces
                face_flags[int(poly.index)] = bool(flag)
            except Exception:
                flag = False
            for li in list(getattr(poly, 'loop_indices', []) or []):
                try:
                    loop_flags[int(li)] = bool(flag)
                except Exception:
                    pass
        if uv_vert is not None:
            for i, flag in enumerate(loop_flags):
                if i < len(uv_vert.data):
                    try: uv_vert.data[i].value = bool(flag)
                    except Exception: pass
        if uv_edge is not None:
            for i, flag in enumerate(loop_flags):
                if i < len(uv_edge.data):
                    try: uv_edge.data[i].value = bool(flag)
                    except Exception: pass
        if uv_face is not None:
            for i, flag in enumerate(face_flags):
                if i < len(uv_face.data):
                    try: uv_face.data[i].value = bool(flag)
                    except Exception: pass
    finally:
        if changed:
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                try: bpy.ops.object.mode_set(mode='EDIT')
                except Exception: pass


class StrictUVFaceScope:
    def __init__(self, context, *, report: Callable[[set[str], str], None] | None = None):
        self.context = context
        self.report = report
        self.obj = None
        self.valid = False
        self.selected_faces: set[int] = set()
        self.had_any_uv_selection = False
        self.old_active = None
        self.old_mode = 'OBJECT'
        self.old_selected_objects: list[Any] = []
        self.mesh_select_mode = None
        self.face_state: dict[int, bool] = {}
        self.edge_state: dict[int, bool] = {}
        self.vert_state: dict[int, bool] = {}
        self.seam_state: dict[int, bool] = {}
        self.nonselected_uv_state: list[tuple[int, int, tuple[float, float], bool, bool, bool]] = []
        self.uv_attr_state: dict[str, list[bool]] = {}

    def _warn(self, text: str) -> None:
        if callable(self.report):
            try:
                self.report({'WARNING'}, text)
            except Exception:
                pass

    def __enter__(self):
        global _DEPTH
        _DEPTH += 1
        ctx = self.context
        obj = _active_mesh_object(ctx)
        self.obj = obj
        if obj is None:
            self._warn('UVエディターで完全に面選択されているメッシュ面がありません。')
            return self
        try:
            self.old_active = ctx.view_layer.objects.active
        except Exception:
            self.old_active = None
        try:
            self.old_selected_objects = [o for o in ctx.view_layer.objects if o.select_get()]
        except Exception:
            self.old_selected_objects = []
        try:
            self.mesh_select_mode = tuple(ctx.tool_settings.mesh_select_mode)
        except Exception:
            self.mesh_select_mode = None
        self.old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
        try:
            ctx.view_layer.objects.active = obj
        except Exception:
            pass
        # Blender hides .uv_select_* mesh attributes while edit data is live.
        # Switch to Object mode once to flush/read the UV Editor face-selection
        # attributes, then return to Edit mode for BMesh operations.
        try:
            if self.old_mode == 'EDIT':
                bpy.ops.object.mode_set(mode='OBJECT')
            self.uv_attr_state = _read_uv_attr_state(obj.data)
        except Exception:
            self.uv_attr_state = {}
        try:
            if str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT') != 'EDIT':
                bpy.ops.object.mode_set(mode='EDIT')
        except Exception:
            pass
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.verify()
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
            selected, had_any = strict_selected_face_indices(ctx, obj, bm, uv_layer, self.uv_attr_state)
            self.selected_faces = set(selected)
            self.had_any_uv_selection = bool(had_any)
            if not self.selected_faces:
                # Clear partial UV selections so a one-vertex/one-edge selection
                # cannot be interpreted by the called operator as a face domain.
                for face in bm.faces:
                    for loop in face.loops:
                        try: loop[uv_layer].select = False
                        except Exception: pass
                        try: loop[uv_layer].select_edge = False
                        except Exception: pass
                bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
                _write_final_uv_selection_attrs(ctx, obj, set())
                self._warn('完全に面選択されているUV面だけが対象です。部分的な頂点・辺選択は処理しません。')
                return self

            selected_set = self.selected_faces
            for f in bm.faces:
                self.face_state[_face_index(f)] = bool(getattr(f, 'select', False))
            for e in bm.edges:
                try: self.edge_state[int(e.index)] = bool(getattr(e, 'select', False))
                except Exception: pass
                try: self.seam_state[int(e.index)] = bool(getattr(e, 'seam', False))
                except Exception: pass
            for v in bm.verts:
                try: self.vert_state[int(v.index)] = bool(getattr(v, 'select', False))
                except Exception: pass

            for face in bm.faces:
                in_scope = _face_index(face) in selected_set
                loops = list(face.loops)
                for pos, loop in enumerate(loops):
                    try:
                        luv = loop[uv_layer]
                        if not in_scope:
                            self.nonselected_uv_state.append((_face_index(face), int(pos), (float(luv.uv.x), float(luv.uv.y)), bool(getattr(luv, 'select', False)), bool(getattr(luv, 'select_edge', False)), bool(getattr(luv, 'pin_uv', False))))
                        luv.select = bool(in_scope)
                        luv.select_edge = bool(in_scope)
                    except Exception:
                        pass
                try:
                    face.select_set(bool(in_scope))
                except Exception:
                    face.select = bool(in_scope)
            # Mesh edges/verts are selected only when they belong to the scoped faces;
            # they will be restored exactly afterwards.
            selected_edges = set()
            selected_verts = set()
            for face in bm.faces:
                if _face_index(face) not in selected_set:
                    continue
                for e in face.edges:
                    selected_edges.add(e)
                for v in face.verts:
                    selected_verts.add(v)
            for e in bm.edges:
                try: e.select_set(e in selected_edges)
                except Exception: pass
            for v in bm.verts:
                try: v.select_set(v in selected_verts)
                except Exception: pass
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
            _write_final_uv_selection_attrs(ctx, obj, selected_set)
            self.valid = True
        except Exception as exc:
            self._warn(f'UV面選択スコープの準備に失敗しました: {exc}')
        finally:
            try:
                if str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT') != 'EDIT':
                    bpy.ops.object.mode_set(mode='EDIT')
            except Exception:
                pass
        return self

    def __exit__(self, exc_type, exc, tb):
        global _DEPTH
        obj = self.obj
        ctx = self.context
        try:
            if obj is not None and getattr(obj, 'type', None) == 'MESH':
                try:
                    ctx.view_layer.objects.active = obj
                except Exception:
                    pass
                try:
                    if str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT') != 'EDIT':
                        bpy.ops.object.mode_set(mode='EDIT')
                except Exception:
                    pass
                bm = bmesh.from_edit_mesh(obj.data)
                uv_layer = bm.loops.layers.uv.verify()
                bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
                bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
                face_by_index = {_face_index(f): f for f in bm.faces}
                edge_by_index = {int(e.index): e for e in bm.edges}
                vert_by_index = {int(v.index): v for v in bm.verts}
                for face_i, loop_pos, uv, _sel, _sel_edge, pin in self.nonselected_uv_state:
                    face = face_by_index.get(int(face_i))
                    if face is None:
                        continue
                    loops = list(face.loops)
                    if not (0 <= int(loop_pos) < len(loops)):
                        continue
                    try:
                        luv = loops[int(loop_pos)][uv_layer]
                        luv.uv.x = float(uv[0]); luv.uv.y = float(uv[1])
                        luv.select = False
                        luv.select_edge = False
                        luv.pin_uv = bool(pin)
                    except Exception:
                        pass
                for idx, value in self.seam_state.items():
                    e = edge_by_index.get(int(idx))
                    if e is not None:
                        try: e.seam = bool(value)
                        except Exception: pass
                for idx, value in self.face_state.items():
                    f = face_by_index.get(int(idx))
                    if f is not None:
                        try: f.select_set(bool(value))
                        except Exception: f.select = bool(value)
                for idx, value in self.edge_state.items():
                    e = edge_by_index.get(int(idx))
                    if e is not None:
                        try: e.select_set(bool(value))
                        except Exception: pass
                for idx, value in self.vert_state.items():
                    v = vert_by_index.get(int(idx))
                    if v is not None:
                        try: v.select_set(bool(value))
                        except Exception: pass
                # Final visible UV selection: scoped faces only.  Unselected islands/faces
                # must not remain highlighted in the UV Editor.
                for face in bm.faces:
                    in_scope = _face_index(face) in self.selected_faces
                    for loop in face.loops:
                        try: loop[uv_layer].select = bool(in_scope)
                        except Exception: pass
                        try: loop[uv_layer].select_edge = bool(in_scope)
                        except Exception: pass
                bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
                _write_final_uv_selection_attrs(ctx, obj, self.selected_faces)
        except Exception:
            pass
        finally:
            try:
                if obj is not None:
                    if self.old_mode != str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT'):
                        bpy.ops.object.mode_set(mode=self.old_mode)
            except Exception:
                pass
            try:
                if self.mesh_select_mode is not None:
                    ctx.tool_settings.mesh_select_mode = self.mesh_select_mode
            except Exception:
                pass
            try:
                # Object selection restoration is conservative and only restores when possible.
                if self.old_selected_objects:
                    for o in ctx.view_layer.objects:
                        try: o.select_set(o in self.old_selected_objects)
                        except Exception: pass
                if self.old_active is not None:
                    ctx.view_layer.objects.active = self.old_active
            except Exception:
                pass
            _DEPTH = max(0, _DEPTH - 1)
        return False


def _strict_selection_from_context_factory(original):
    def _strict_selection_from_context(context, obj, bm, uv_layer):
        try:
            selected, had_any = strict_selected_face_indices(context, obj, bm, uv_layer)
            if selected:
                faces = [f for f in bm.faces if _face_index(f) in selected]
                loops = [l for f in faces for l in f.loops]
                active = getattr(bm.faces, 'active', None)
                if active is not None and _face_index(active) not in selected:
                    active = faces[0] if faces else None
                return faces, loops, active, 'UV_FACE_STRICT'
            if had_any:
                return [], [], None, 'UV_FACE_STRICT_EMPTY'
        except Exception:
            pass
        return original(context, obj, bm, uv_layer)
    return _strict_selection_from_context


def _strict_islands_for_scope_factory(module, original):
    def _strict_islands_for_scope(context, obj, bm, uv_layer, scope='SELECTED'):
        if str(scope or 'SELECTED').upper() == 'ALL' and _DEPTH <= 0:
            return original(context, obj, bm, uv_layer, scope)
        sel_func = getattr(module, '_selection_from_context', None)
        if not callable(sel_func):
            return original(context, obj, bm, uv_layer, scope)
        sel_faces, _sel_loops, active_face, _src = sel_func(context, obj, bm, uv_layer)
        if not sel_faces:
            return []
        try:
            islands = module.build_islands(bm, uv_layer, faces_subset=list(sel_faces))
        except Exception:
            return original(context, obj, bm, uv_layer, scope)
        if active_face is not None:
            try:
                islands.sort(key=lambda isl: (0 if active_face in isl.faces else 1, getattr(isl, 'id', 0)))
            except Exception:
                pass
        return islands
    return _strict_islands_for_scope


def _strict_faces_for_scope_factory(module, original):
    def _strict_faces_for_scope(context, obj, bm, uv_layer, scope='SELECTED'):
        if str(scope or 'SELECTED').upper() == 'ALL' and _DEPTH <= 0:
            return original(context, obj, bm, uv_layer, scope)
        sel_func = getattr(module, '_selection_from_context', None)
        if callable(sel_func):
            sel_faces, _sel_loops, _active_face, _src = sel_func(context, obj, bm, uv_layer)
            return list(sel_faces)
        return original(context, obj, bm, uv_layer, scope)
    return _strict_faces_for_scope


def _patch_module_func(module, name: str, replacement):
    try:
        old = getattr(module, name, None)
        if not callable(old) or getattr(old, '_sus_strict_uv_face_scope_patch', False):
            return
        setattr(module, name, replacement(old))
        try:
            getattr(module, name)._sus_strict_uv_face_scope_patch = True
        except Exception:
            pass
        _PATCHED_FUNCS.append((module, name, old))
    except Exception:
        pass


def patch_selection_helpers() -> None:
    modules = []
    for mod_name in ('core', 'ui', 'flow', 'pro_operators', 'symmetry_atlas_operators'):
        try:
            modules.append(__import__(f'{__package__}.{mod_name}', fromlist=['*']))
        except Exception:
            pass
    for mod in modules:
        if hasattr(mod, '_selection_from_context'):
            _patch_module_func(mod, '_selection_from_context', _strict_selection_from_context_factory)
    for mod in modules:
        if hasattr(mod, '_islands_for_scope'):
            _patch_module_func(mod, '_islands_for_scope', lambda old, mod=mod: _strict_islands_for_scope_factory(mod, old))
        if hasattr(mod, '_faces_for_scope'):
            _patch_module_func(mod, '_faces_for_scope', lambda old, mod=mod: _strict_faces_for_scope_factory(mod, old))


def _operator_should_scope(self) -> bool:
    name = self.__class__.__name__
    if name == 'SUV_OT_native_uv_action':
        try:
            return str(getattr(self, 'mode', '') or '').upper() in {'PACK'}
        except Exception:
            return False
    return True


def _wrap_single_operator_class(cls: type) -> None:
    try:
        old = getattr(cls, 'execute', None)
        if not callable(old) or getattr(old, '_sus_strict_uv_face_scope_wrapped', False):
            return
    except Exception:
        return

    @functools.wraps(old)
    def _execute(self, context):
        if _DEPTH > 0 or not _operator_should_scope(self):
            return old(self, context)
        with StrictUVFaceScope(context, report=getattr(self, 'report', None)) as scope:
            if not scope.valid:
                return {'CANCELLED'}
            old_scope = None
            had_scope = False
            try:
                if hasattr(self, 'scope'):
                    old_scope = getattr(self, 'scope')
                    had_scope = True
                    try:
                        setattr(self, 'scope', 'SELECTED')
                    except Exception:
                        pass
                result = old(self, context)
            finally:
                if had_scope:
                    try:
                        setattr(self, 'scope', old_scope)
                    except Exception:
                        pass
        return result

    try:
        _execute._sus_strict_uv_face_scope_wrapped = True
    except Exception:
        pass
    setattr(cls, 'execute', _execute)
    _WRAPPED.append((cls, old))


def _wrap_operator_class(cls: type) -> None:
    """Wrap both the module class and any already-registered stale Blender subclass."""
    candidates = []
    seen = set()
    def add(candidate):
        if isinstance(candidate, type) and id(candidate) not in seen:
            seen.add(id(candidate)); candidates.append(candidate)
    add(cls)
    try:
        target_id = str(getattr(cls, 'bl_idname', '') or '')
        target_name = str(getattr(cls, '__name__', '') or '')
        for sub in ():
            try:
                if (target_id and str(getattr(sub, 'bl_idname', '') or '') == target_id) or (target_name and str(getattr(sub, '__name__', '') or '') == target_name):
                    add(sub)
            except Exception:
                pass
    except Exception:
        pass
    for candidate in candidates:
        _wrap_single_operator_class(candidate)


def patch_layout_operator_classes() -> None:
    targets = {
        'pro_operators': (
            'SUV_OT_pack_pro',
        ),
        'flow': (
            'SUV_OT_native_uv_action',
            'SUV_OT_trim_strip_layout', 'SUV_OT_trim_band_layout', 'SUV_OT_trim_band_refill',
            'SUV_OT_priority_density_pack', 'SUV_OT_layout_autoheal', 'SUV_OT_layout_audit_relayout',
            'SUV_OT_external_layout_profile', 'SUV_OT_apply_pack_profile', 'SUV_OT_batch_layout_profile',
            'SUV_OT_hotspot_grid_layout', 'SUV_OT_hotspot_cell_tools', 'SUV_OT_hotspot_cell_refill',
            'SUV_OT_hotspot_symmetry_refill', 'SUV_OT_groups_to_tiles', 'SUV_OT_group_normalize_layout',
            'SUV_OT_unstack_groups', 'SUV_OT_unstack_overlapped',
        ),
        'symmetry_atlas_operators': (
            'SUV_OT_atlas_build_uv_multi', 'SUV_OT_atlas_run_all_multi',
        ),
    }
    for mod_name, class_names in targets.items():
        try:
            mod = __import__(f'{__package__}.{mod_name}', fromlist=['*'])
        except Exception:
            continue
        for class_name in class_names:
            cls = getattr(mod, class_name, None)
            if isinstance(cls, type):
                _wrap_operator_class(cls)
    # Package-local precision pack class lives in __init__.py.
    try:
        pkg = __import__(__package__, fromlist=['*'])
        for class_name in ('SMARTUVSUITE_OT_precision_pack', 'SMARTUVSUITE_OT_pack_hotspot_grid_layout'):
            cls = getattr(pkg, class_name, None)
            if isinstance(cls, type):
                _wrap_operator_class(cls)
    except Exception:
        pass


def auto_pack_after_unwrap(context) -> bool:
    """Run the Pack menu's Pack operation on the strict UV-face unwrap result."""
    obj = _active_mesh_object(context)
    if obj is None:
        return False
    try:
        # Pack Pro wrapper will re-validate strict full-face selection, preserve
        # 3D mesh selection and restore non-selected UVs.
        result = bpy.ops.uv.suv_pack_pro('EXEC_DEFAULT', scope='SELECTED', engine='DETERMINISTIC')
        return 'FINISHED' in set(result or [])
    except Exception:
        try:
            result = bpy.ops.uv.pack_islands(margin=0.001, rotate=True)
            return 'FINISHED' in set(result or [])
        except Exception:
            return False


def register() -> None:
    patch_selection_helpers()
    patch_layout_operator_classes()


def unregister() -> None:
    while _WRAPPED:
        cls, old = _WRAPPED.pop()
        try:
            setattr(cls, 'execute', old)
        except Exception:
            pass
    while _PATCHED_FUNCS:
        mod, name, old = _PATCHED_FUNCS.pop()
        try:
            setattr(mod, name, old)
        except Exception:
            pass
