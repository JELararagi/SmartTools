from __future__ import annotations
from . import base as _prev
_IGNORE_KEYS = {'__name__','__package__','__loader__','__spec__','__file__','__cached__','__builtins__'}
globals().update({k: v for k, v in _prev.__dict__.items() if k not in _IGNORE_KEYS})

# ============================================================
# Core UV math + island engine
# ============================================================

def _signed_uv_area(face, uv_layer) -> float:
    area = 0.0
    loops = face.loops
    n = len(loops)
    for i in range(n):
        uv1 = loops[i][uv_layer].uv
        uv2 = loops[(i + 1) % n][uv_layer].uv
        area += (uv1.x * uv2.y - uv2.x * uv1.y)
    return 0.5 * area

def _pca_axis_2d(points):
    if len(points) < 2:
        return None, None
    cx = sum(p.x for p in points) / len(points)
    cy = sum(p.y for p in points) / len(points)
    sxx = syy = sxy = 0.0
    for p in points:
        dx = p.x - cx
        dy = p.y - cy
        sxx += dx * dx
        syy += dy * dy
        sxy += dx * dy
    sxx /= len(points)
    syy /= len(points)
    sxy /= len(points)
    trace = sxx + syy
    det = sxx * syy - sxy * sxy
    disc = max(trace * trace - 4.0 * det, 0.0)
    lam1 = 0.5 * (trace + math.sqrt(disc))
    a = sxx - lam1
    b = sxy
    c = sxy
    d = syy - lam1
    if abs(a) + abs(b) > abs(c) + abs(d):
        vx, vy = -b, a
    else:
        vx, vy = -d, c
    axis = Vector((vx, vy))
    if axis.length < 1e-12:
        axis = Vector((1.0, 0.0))
    else:
        axis.normalize()
    return Vector((cx, cy)), axis

def _rotate2(v: Vector, angle_rad: float) -> Vector:
    c = math.cos(angle_rad)
    s = math.sin(angle_rad)
    return Vector((v.x * c - v.y * s, v.x * s + v.y * c))

def _mirror_x(v: Vector, pivot: Vector) -> Vector:
    return Vector((pivot.x - (v.x - pivot.x), v.y))

def _mirror_y(v: Vector, pivot: Vector) -> Vector:
    return Vector((v.x, pivot.y - (v.y - pivot.y)))

def _edge_uvs_in_face(face, edge, uv_layer):
    for l in face.loops:
        if l.edge == edge:
            # UV of edge.verts[0], then edge.verts[1], so two faces can be compared vertex by vertex.
            uv1 = Vector(l[uv_layer].uv)
            uv2 = Vector(l.link_loop_next[uv_layer].uv)
            return (uv1, uv2) if l.vert == edge.verts[0] else (uv2, uv1)
    return None, None

def _uv_close(a: Vector, b: Vector, eps: float) -> bool:
    return (a - b).length <= eps


def _face_uv_centroid(face, uv_layer):
    pts = [Vector(l[uv_layer].uv) for l in face.loops]
    n = len(pts)
    if n == 0:
        return Vector((0.0, 0.0))
    area2 = 0.0
    cx = 0.0
    cy = 0.0
    for i in range(n):
        p0 = pts[i]
        p1 = pts[(i + 1) % n]
        cross = p0.x * p1.y - p1.x * p0.y
        area2 += cross
        cx += (p0.x + p1.x) * cross
        cy += (p0.y + p1.y) * cross
    if abs(area2) > 1.0e-12:
        inv = 1.0 / (3.0 * area2)
        return Vector((cx * inv, cy * inv))
    return Vector((sum(p.x for p in pts) / n, sum(p.y for p in pts) / n))


def _unique_points_2d(points, ndigits: int = 6):
    seen = set()
    out = []
    for p in points or []:
        v = Vector(p)
        key = (round(float(v.x), ndigits), round(float(v.y), ndigits))
        if key in seen:
            continue
        seen.add(key)
        out.append(v)
    return out


def _compute_island_tool_runtime_metrics(isl: _Island, uv_layer):
    pts = []
    tiles = set()
    for l in getattr(isl, 'loops', []):
        uv = Vector(l[uv_layer].uv)
        pts.append(uv)
        tiles.add((int(math.floor(uv.x)), int(math.floor(uv.y))))
    isl.uv_points = pts
    isl.udim_tiles = tiles
    if not pts:
        isl.bbox_min = Vector((0.0, 0.0))
        isl.bbox_max = Vector((0.0, 0.0))
        isl.uv_centroid = Vector((0.0, 0.0))
        isl.axis = Vector((1.0, 0.0))
        isl.signed_area = 0.0
        isl.abs_area = 0.0
        return isl
    xs = [p.x for p in pts]
    ys = [p.y for p in pts]
    isl.bbox_min = Vector((min(xs), min(ys)))
    isl.bbox_max = Vector((max(xs), max(ys)))

    signed_area = 0.0
    abs_area = 0.0
    centroid_acc = Vector((0.0, 0.0))
    weight_total = 0.0
    try:
        for ff in isl.faces:
            fa = float(_signed_uv_area(ff, uv_layer))
            aa = abs(fa)
            signed_area += fa
            abs_area += aa
            if aa > 1.0e-12:
                centroid_acc += _face_uv_centroid(ff, uv_layer) * aa
                weight_total += aa
    except Exception:
        signed_area = 0.0
        abs_area = 0.0
        centroid_acc = Vector((0.0, 0.0))
        weight_total = 0.0
    isl.signed_area = signed_area
    isl.abs_area = abs_area
    if weight_total > 1.0e-12:
        isl.uv_centroid = centroid_acc / weight_total
    else:
        isl.uv_centroid = Vector((sum(xs) / len(xs), sum(ys) / len(ys)))

    pca_points = _unique_points_2d(pts)
    _c, axis = _pca_axis_2d(pca_points if len(pca_points) >= 2 else pts)
    isl.axis = axis if axis else Vector((1.0, 0.0))
    return isl

class _Island:
    __slots__ = ("id","faces","loops","uv_points","uv_centroid","axis",
                 "signed_area","abs_area","bbox_min","bbox_max","udim_tiles","has_pin","vert_ids","face_sig")
    def __init__(self, id_):
        self.id = id_
        self.faces = []
        self.loops = []
        self.uv_points = []
        self.uv_centroid = Vector((0.0,0.0))
        self.axis = Vector((1.0,0.0))
        self.signed_area = 0.0
        self.abs_area = 0.0
        self.bbox_min = Vector((0.0,0.0))
        self.bbox_max = Vector((0.0,0.0))
        self.udim_tiles = set()
        self.has_pin = False
        self.vert_ids = set()
        self.face_sig = ()

def build_islands(bm, uv_layer, faces_subset=None, eps=1e-5):
    if faces_subset is None:
        faces_subset = list(bm.faces)
    face_set = set(faces_subset)
    visited = set()
    islands = []
    bm.edges.ensure_lookup_table()

    def neighbors(face):
        for l in face.loops:
            e = l.edge
            if getattr(e, "seam", False):
                continue
            if len(e.link_faces) != 2:
                continue
            other = e.link_faces[0] if e.link_faces[1] == face else e.link_faces[1]
            if other not in face_set:
                continue
            a0, a1 = _edge_uvs_in_face(face, e, uv_layer)
            b0, b1 = _edge_uvs_in_face(other, e, uv_layer)
            if a0 is None or b0 is None:
                continue
            if _uv_close(a0, b0, eps) and _uv_close(a1, b1, eps):
                yield other

    island_id = 0
    for f in faces_subset:
        if f in visited:
            continue
        isl = _Island(island_id)
        island_id += 1
        stack = [f]
        visited.add(f)
        while stack:
            cur = stack.pop()
            isl.faces.append(cur)
            for l in cur.loops:
                isl.loops.append(l)
                uv = Vector(l[uv_layer].uv)
                isl.uv_points.append(uv)
                isl.udim_tiles.add((int(math.floor(uv.x)), int(math.floor(uv.y))))
                try:
                    if bool(getattr(l[uv_layer], "pin_uv", False)):
                        isl.has_pin = True
                except Exception:
                    pass
                isl.vert_ids.add(l.vert.index)
            for nb in neighbors(cur):
                if nb not in visited:
                    visited.add(nb)
                    stack.append(nb)

        if isl.uv_points:
            xs = [p.x for p in isl.uv_points]
            ys = [p.y for p in isl.uv_points]
            isl.bbox_min = Vector((min(xs), min(ys)))
            isl.bbox_max = Vector((max(xs), max(ys)))
            isl.uv_centroid = Vector((sum(xs)/len(xs), sum(ys)/len(ys)))
            _, axis = _pca_axis_2d(isl.uv_points)
            if axis:
                isl.axis = axis
        isl.signed_area = sum(_signed_uv_area(ff, uv_layer) for ff in isl.faces)
        isl.abs_area = sum(abs(_signed_uv_area(ff, uv_layer)) for ff in isl.faces)
        isl.face_sig = tuple(sorted(ff.index for ff in isl.faces))
        islands.append(isl)
    return islands


def _refresh_island_tool_runtime_metrics(isl: _Island, uv_layer):
    return _compute_island_tool_runtime_metrics(isl, uv_layer)


def _island_apply_transform(isl: _Island, uv_layer, transform_fn):
    for l in isl.loops:
        l[uv_layer].uv = transform_fn(Vector(l[uv_layer].uv))
    _refresh_island_tool_runtime_metrics(isl, uv_layer)


def _fit_islands_to_rect_core(islands, uv_layer, dst_min: Vector, dst_max: Vector, *, keep_aspect=True, tile_off=None):
    islands = list(islands or [])
    if not islands:
        return False, 'No islands'
    minx = min(float(getattr(i, 'bbox_min', Vector((0.0, 0.0))).x) for i in islands)
    miny = min(float(getattr(i, 'bbox_min', Vector((0.0, 0.0))).y) for i in islands)
    maxx = max(float(getattr(i, 'bbox_max', Vector((0.0, 0.0))).x) for i in islands)
    maxy = max(float(getattr(i, 'bbox_max', Vector((0.0, 0.0))).y) for i in islands)
    gmin = Vector((minx, miny))
    gmax = Vector((maxx, maxy))
    src_size = gmax - gmin
    if src_size.x <= 1.0e-12 or src_size.y <= 1.0e-12:
        return False, 'Zero-size bounds'
    tile = Vector(tile_off) if tile_off is not None else Vector((0.0, 0.0))
    src_min = gmin - tile
    src_max = gmax - tile
    src_size = src_max - src_min
    dst_size = Vector(dst_max) - Vector(dst_min)
    if dst_size.x <= 1.0e-12 or dst_size.y <= 1.0e-12:
        return False, 'Zero-size target'
    if keep_aspect:
        sx = dst_size.x / src_size.x
        sy = dst_size.y / src_size.y
        scale = min(sx, sy)
        used = Vector((src_size.x * scale, src_size.y * scale))
        extra = dst_size - used
        dst_min_eff = Vector(dst_min) + extra * 0.5
        scale_vec = Vector((scale, scale))
    else:
        scale_vec = Vector((dst_size.x / src_size.x, dst_size.y / src_size.y))
        dst_min_eff = Vector(dst_min)

    def tf(u):
        uu = Vector(u) - tile
        uu = uu - src_min
        uu = Vector((uu.x * scale_vec.x, uu.y * scale_vec.y)) + dst_min_eff
        return uu + tile

    for isl in islands:
        _island_apply_transform(isl, uv_layer, tf)
    return True, None


def _island_bbox_after_rotation(isl: _Island, angle: float):
    pivot = isl.uv_centroid
    pts = [pivot + _rotate2(p - pivot, angle) for p in isl.uv_points]
    xs = [p.x for p in pts]
    ys = [p.y for p in pts]
    return Vector((min(xs), min(ys))), Vector((max(xs), max(ys)))

def _bbox_size(bmin: Vector, bmax: Vector):
    return (bmax.x - bmin.x, bmax.y - bmin.y)


def _suv_operator_property_keys(op):
    try:
        props = op.get_rna_type().properties
        try:
            return {p.identifier for p in props if getattr(p, 'identifier', None) and p.identifier != 'rna_type'}
        except Exception:
            return {str(k) for k in props.keys() if str(k) != 'rna_type'}
    except Exception:
        return set()


def _suv_operator_enum_items(op, prop_name: str):
    try:
        prop = op.get_rna_type().properties.get(prop_name)
        if prop is None:
            return []
        return [str(item.identifier) for item in getattr(prop, 'enum_items', [])]
    except Exception:
        return []


def _suv_pick_enum_value(op, prop_name: str, preferred=None, fallback=None):
    items = _suv_operator_enum_items(op, prop_name)
    prefs = list(preferred or [])
    for choice in prefs:
        if choice in items:
            return choice
    if fallback is not None and fallback in items:
        return fallback
    return items[0] if items else fallback


def _suv_run_pack_islands_native(context, margin_uv=0.0, rotation_step_deg=15, lock_pinned=True, **_ignored_kwargs):
    op = bpy.ops.uv.pack_islands
    keys = _suv_operator_property_keys(op)
    kwargs = {}
    if 'margin' in keys:
        kwargs['margin'] = max(0.0, float(margin_uv))
    if 'margin_method' in keys:
        kwargs['margin_method'] = _suv_pick_enum_value(op, 'margin_method', ['SCALED', 'ADD', 'FRACTION'])
    if 'rotate' in keys:
        kwargs['rotate'] = (int(rotation_step_deg) != 0)
    if 'rotation_method' in keys:
        if int(rotation_step_deg) == 0:
            kwargs['rotation_method'] = _suv_pick_enum_value(op, 'rotation_method', ['ANY', 'CARDINAL', 'AXIS_ALIGNED'])
        elif int(rotation_step_deg) <= 15:
            kwargs['rotation_method'] = _suv_pick_enum_value(op, 'rotation_method', ['ANY', 'CARDINAL', 'AXIS_ALIGNED'])
        else:
            kwargs['rotation_method'] = _suv_pick_enum_value(op, 'rotation_method', ['CARDINAL', 'AXIS_ALIGNED', 'ANY'])
    if 'scale' in keys:
        kwargs['scale'] = True
    if 'merge_overlap' in keys:
        kwargs['merge_overlap'] = False
    if 'pin' in keys:
        items = _suv_operator_enum_items(op, 'pin')
        if lock_pinned:
            for choice in ('LOCKED', 'LOCKED_PINS', 'PINNED'):
                if choice in items:
                    kwargs['pin'] = choice
                    break
        else:
            for choice in ('DISABLED', 'OFF', 'UNLOCKED'):
                if choice in items:
                    kwargs['pin'] = choice
                    break
    if 'pin_method' in keys:
        if lock_pinned:
            kwargs['pin_method'] = _suv_pick_enum_value(op, 'pin_method', ['LOCKED', 'ROTATION_SCALE', 'ROTATION', 'SCALE'])
        else:
            kwargs['pin_method'] = _suv_pick_enum_value(op, 'pin_method', ['SCALE', 'ROTATION', 'ROTATION_SCALE', 'LOCKED'])
    if 'shape_method' in keys:
        kwargs['shape_method'] = _suv_pick_enum_value(op, 'shape_method', ['CONCAVE', 'CONVEX', 'AABB'])
    return _run_uv_op(context, op, **kwargs)


def _suv_run_unwrap_native(context, method='ANGLE_BASED', margin=0.001, fill_holes=True, correct_aspect=True, use_subsurf_data=False, margin_method='SCALED'):
    op = bpy.ops.uv.unwrap
    keys = _suv_operator_property_keys(op)
    kwargs = {}
    if 'method' in keys:
        preferred = [str(method or 'ANGLE_BASED').upper(), 'MINIMUM_STRETCH', 'ANGLE_BASED', 'CONFORMAL']
        kwargs['method'] = _suv_pick_enum_value(op, 'method', preferred)
    if 'margin_method' in keys:
        kwargs['margin_method'] = _suv_pick_enum_value(op, 'margin_method', [str(margin_method or 'SCALED').upper(), 'SCALED', 'ADD', 'FRACTION'])
    if 'margin' in keys:
        kwargs['margin'] = max(0.0, float(margin))
    if 'fill_holes' in keys:
        kwargs['fill_holes'] = bool(fill_holes)
    if 'correct_aspect' in keys:
        kwargs['correct_aspect'] = bool(correct_aspect)
    if 'use_subsurf_data' in keys:
        kwargs['use_subsurf_data'] = bool(use_subsurf_data)
    return _run_uv_op(context, op, **kwargs)


def _suv_run_minimize_stretch_native(context, iterations=100, fill_holes=True, blend=0.0):
    op = bpy.ops.uv.minimize_stretch
    keys = _suv_operator_property_keys(op)
    kwargs = {}
    if 'iterations' in keys:
        kwargs['iterations'] = max(1, int(iterations))
    if 'fill_holes' in keys:
        kwargs['fill_holes'] = bool(fill_holes)
    if 'blend' in keys:
        kwargs['blend'] = max(0.0, min(1.0, float(blend)))
    return _run_uv_op(context, op, **kwargs)


def _suv_run_align_native(context, axis_mode='ALIGN_S'):
    op = bpy.ops.uv.align
    keys = _suv_operator_property_keys(op)
    kwargs = {}
    if 'axis' in keys:
        kwargs['axis'] = _suv_pick_enum_value(op, 'axis', [str(axis_mode or 'ALIGN_S').upper(), 'ALIGN_S', 'ALIGN_AUTO'])
    return _run_uv_op(context, op, **kwargs)


def _suv_mark_smart_seams(bm, angle_threshold, faces_subset=None, include_boundary=True, include_sharp=True, include_material=True):
    face_set = set(faces_subset) if faces_subset is not None else None
    bm.edges.ensure_lookup_table()
    seam_count = 0
    for edge in bm.edges:
        linked = list(edge.link_faces)
        if face_set is not None:
            selected_linked = [f for f in linked if f in face_set]
            if not selected_linked:
                continue
        mark = False
        if len(linked) <= 1:
            mark = bool(include_boundary)
        else:
            fa, fb = linked[0], linked[1]
            a_in = (face_set is None or fa in face_set)
            b_in = (face_set is None or fb in face_set)
            if face_set is not None and (a_in ^ b_in):
                mark = bool(include_boundary)
            elif a_in and b_in:
                try:
                    angle_ok = float(edge.calc_face_angle()) >= float(angle_threshold)
                except Exception:
                    angle_ok = False
                try:
                    sharp_ok = bool(include_sharp) and (bool(getattr(edge, 'sharp', False)) or not bool(getattr(edge, 'smooth', True)))
                except Exception:
                    sharp_ok = False
                try:
                    material_ok = bool(include_material) and int(getattr(fa, 'material_index', 0)) != int(getattr(fb, 'material_index', 0))
                except Exception:
                    material_ok = False
                mark = angle_ok or sharp_ok or material_ok
        if mark:
            if not edge.seam:
                seam_count += 1
            edge.seam = True
    return seam_count


# ============================================================
# Selection abstraction (UV Sync ON/OFF best-effort)
# ============================================================

def _suv_face_selected(context, face) -> bool:
    if _is_uv_sync(context):
        return bool(face.select)
    return bool(face.select) and all(l.uv_select_vert for l in face.loops)


def _suv_face_select(context, face, value: bool) -> None:
    if _is_uv_sync(context):
        face.select = bool(value)
        return
    face.uv_select_set(bool(value))
    for l in face.loops:
        l.uv_select_vert = bool(value)
        l.uv_select_edge = bool(value)


def _suv_uv_edge_select(context, loop, value: bool) -> None:
    if _is_uv_sync(context):
        loop.edge.select = bool(value)
        return
    loop.uv_select_edge = bool(value)
    loop.uv_select_vert = bool(value)
    loop.link_loop_next.uv_select_vert = bool(value)


def _selection_from_context(context, obj, bm, uv_layer):
    uv_sync = _is_uv_sync(context)
    sel_faces = set()
    sel_loops = []
    active_face = getattr(bm.faces, "active", None)

    if uv_sync:
        for f in bm.faces:
            if f.select:
                sel_faces.add(f)
                sel_loops.extend(f.loops)
        return list(sel_faces), sel_loops, active_face, "MESH_SYNC"

    # UV Sync OFF: the UV selection is stored on the BMesh loops.
    # Blender keeps these flags on faces the mesh selection hides from the UV editor.
    for f in bm.faces:
        if f.hide or not f.select:
            continue
        for l in f.loops:
            if l.uv_select_vert or l.uv_select_edge:
                sel_loops.append(l)
                sel_faces.add(f)
    if sel_loops:
        if active_face and active_face not in sel_faces:
            active_face = next(iter(sel_faces), None)
        return list(sel_faces), sel_loops, active_face, "UV_LOOP"

    # fallback face selection
    for f in bm.faces:
        if f.select:
            sel_faces.add(f)
            sel_loops.extend(f.loops)
    if active_face and active_face not in sel_faces:
        active_face = next(iter(sel_faces), None)
    return list(sel_faces), sel_loops, active_face, "FALLBACK_FACE"

# ============================================================
# Deterministic pack (MaxRects-style) + UDIM helpers
# ============================================================

def _pack_rotation_candidates(isl: _Island, rot_step_deg: int, allow_rotate: bool):
    candidates = []
    step = math.radians(rot_step_deg) if rot_step_deg > 0 else 0.0
    if allow_rotate and step > 0.0:
        kmax = max(1, int(round((2.0 * math.pi) / step)))
        angles = [k * step for k in range(kmax)]
    else:
        angles = [0.0]

    seen = set()
    for ang in angles:
        bmin, bmax = _island_bbox_after_rotation(isl, ang)
        w, h = _bbox_size(bmin, bmax)
        area = float(w * h)
        key = (round(float(w), 8), round(float(h), 8))
        if key in seen:
            continue
        seen.add(key)
        candidates.append({
            'angle': float(ang),
            'bmin': Vector(bmin),
            'bmax': Vector(bmax),
            'w': float(w),
            'h': float(h),
            'area': area,
        })
    if not candidates:
        bmin, bmax = _island_bbox_after_rotation(isl, 0.0)
        w, h = _bbox_size(bmin, bmax)
        candidates.append({'angle': 0.0, 'bmin': Vector(bmin), 'bmax': Vector(bmax), 'w': float(w), 'h': float(h), 'area': float(w * h)})
    candidates.sort(key=lambda c: (round(c['area'], 10), round(max(c['w'], c['h']), 10), round(min(c['w'], c['h']), 10), round(c['angle'], 10)))
    return candidates


def _pack_sort_key(isl: _Island, candidate_map):
    base = candidate_map.get(isl.id, [{}])[0]
    w = float(base.get('w', 0.0))
    h = float(base.get('h', 0.0))
    area = float(base.get('area', 0.0))
    return (-area, -max(w, h), -min(w, h), int(getattr(isl, 'id', 0)))


def _rect_contains(a, b, eps=1.0e-12):
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    return ax <= bx + eps and ay <= by + eps and ax + aw >= bx + bw - eps and ay + ah >= by + bh - eps


def _split_free_rect(free_rect, used_rect, eps=1.0e-12):
    fx, fy, fw, fh = free_rect
    ux, uy, uw, uh = used_rect
    if ux >= fx + fw - eps or ux + uw <= fx + eps or uy >= fy + fh - eps or uy + uh <= fy + eps:
        return [free_rect]
    out = []
    top_h = uy - fy
    if top_h > eps:
        out.append((fx, fy, fw, top_h))
    bottom_h = (fy + fh) - (uy + uh)
    if bottom_h > eps:
        out.append((fx, uy + uh, fw, bottom_h))
    left_w = ux - fx
    if left_w > eps:
        out.append((fx, fy, left_w, fh))
    right_w = (fx + fw) - (ux + uw)
    if right_w > eps:
        out.append((ux + uw, fy, right_w, fh))
    return [r for r in out if r[2] > eps and r[3] > eps]


def _prune_free_rects(free_rects):
    pruned = []
    for rect in free_rects:
        if rect[2] <= 1.0e-12 or rect[3] <= 1.0e-12:
            continue
        skip = False
        for other in pruned:
            if _rect_contains(other, rect):
                skip = True
                break
        if skip:
            continue
        pruned = [other for other in pruned if not _rect_contains(rect, other)]
        pruned.append(rect)
    pruned.sort(key=lambda r: (round(r[1], 10), round(r[0], 10), round(r[2] * r[3], 10)))
    return pruned


def _place_in_free_rects(free_rects, used_rect):
    pieces = []
    for fr in free_rects:
        pieces.extend(_split_free_rect(fr, used_rect))
    return _prune_free_rects(pieces)


def _best_free_rect_placement(free_rects, candidates, margin_uv: float):
    best = None
    for fr in free_rects:
        fx, fy, fw, fh = fr
        for cand in candidates:
            rw = float(cand['w']) + margin_uv * 2.0
            rh = float(cand['h']) + margin_uv * 2.0
            if rw > fw + 1.0e-12 or rh > fh + 1.0e-12:
                continue
            short_side = min(fw - rw, fh - rh)
            long_side = max(fw - rw, fh - rh)
            area_fit = fw * fh - rw * rh
            # A leftover-only score favours the largest rotated bounding box, so an
            # axis-aligned square turns 45 degrees and valid layouts overflow.
            score = (
                round(rw * rh, 10),
                round(short_side, 10),
                round(long_side, 10),
                round(area_fit, 10),
                round(fy, 10),
                round(fx, 10),
                round(cand['area'], 10),
                round(cand['angle'], 10),
            )
            if best is None or score < best['score']:
                best = {
                    'score': score,
                    'free_rect': fr,
                    'used_rect': (fx, fy, rw, rh),
                    'candidate': cand,
                }
    return best


def _pack_shelf(islands, margin_uv: float, rot_step_deg: int, allow_rotate: bool):
    islands = list(islands or [])
    placements = {}
    if not islands:
        return placements, True

    candidate_map = {isl.id: _pack_rotation_candidates(isl, rot_step_deg, allow_rotate) for isl in islands}
    ordered = sorted(islands, key=lambda isl: _pack_sort_key(isl, candidate_map))
    free_rects = [(0.0, 0.0, 1.0, 1.0)]

    for isl in ordered:
        best = _best_free_rect_placement(free_rects, candidate_map.get(isl.id, []), margin_uv)
        if best is None:
            return placements, False
        cand = best['candidate']
        fx, fy, rw, rh = best['used_rect']
        target_min = Vector((fx + margin_uv, fy + margin_uv))
        delta = target_min - Vector(cand['bmin'])
        placements[isl.id] = {
            'angle': float(cand['angle']),
            'bmin': Vector(cand['bmin']),
            'bmax': Vector(cand['bmax']),
            'dx': float(delta.x),
            'dy': float(delta.y),
        }
        free_rects = _place_in_free_rects(free_rects, best['used_rect'])

    return placements, True


def _suv_shrink_islands_to_fit_tile(islands, uv_layer, margin_uv: float, rot_step_deg: int, allow_rotate: bool) -> bool:
    """Uniformly scale the islands down only as far as a complete one-tile shelf layout needs."""
    islands = list(islands or [])
    if _pack_shelf(islands, margin_uv, rot_step_deg, allow_rotate)[1]:
        return True

    def fits(scale):
        proxies = []
        for source in islands:
            proxy = _Island(source.id)
            proxy.uv_points = [Vector(p) * scale for p in source.uv_points]
            proxy.uv_centroid = Vector(source.uv_centroid) * scale
            proxy.bbox_min = Vector(source.bbox_min) * scale
            proxy.bbox_max = Vector(source.bbox_max) * scale
            proxy.axis = source.axis
            proxies.append(proxy)
        return _pack_shelf(proxies, margin_uv, rot_step_deg, allow_rotate)[1]

    upper = 1.0
    lower = 0.5
    for _ in range(20):
        if fits(lower):
            break
        upper = lower
        lower *= 0.5
    else:
        return False
    for _ in range(10):
        trial = (lower + upper) * 0.5
        if fits(trial):
            lower = trial
        else:
            upper = trial
    # The shelf layout is not monotonic in scale and UVs are stored as 32-bit floats,
    # so check the written result and step down until the real islands fit.
    scale = lower
    for _ in range(60):
        for isl in islands:
            pivot = Vector(isl.uv_centroid)
            _island_apply_transform(isl, uv_layer, lambda u, pivot=pivot, scale=scale: pivot + (Vector(u) - pivot) * scale)
        if _pack_shelf(islands, margin_uv, rot_step_deg, allow_rotate)[1]:
            return True
        scale = 0.98
    return False


def _pack_multi_tiles(islands, margin_uv: float, rot_step_deg: int, allow_rotate: bool):
    """
    Deterministic MaxRects-style pack across multiple UDIM tiles.
    Returns: placements dict: isl.id -> {angle, dx, dy, tile_index}
    tile_index is linear (0..), convert to (u,v) with (tile_index % 10, tile_index // 10)
    """
    islands = list(islands or [])
    placements = {}
    if not islands:
        return placements

    candidate_map = {isl.id: _pack_rotation_candidates(isl, rot_step_deg, allow_rotate) for isl in islands}
    ordered = sorted(islands, key=lambda isl: _pack_sort_key(isl, candidate_map))
    bins = [[(0.0, 0.0, 1.0, 1.0)]]

    for isl in ordered:
        best = None
        best_tile = None
        for tile_index, free_rects in enumerate(bins):
            placement = _best_free_rect_placement(free_rects, candidate_map.get(isl.id, []), margin_uv)
            if placement is None:
                continue
            score = (tile_index,) + placement['score']
            if best is None or score < best['global_score']:
                best = dict(placement)
                best['global_score'] = score
                best_tile = tile_index

        if best is None:
            bins.append([(0.0, 0.0, 1.0, 1.0)])
            best_tile = len(bins) - 1
            placement = _best_free_rect_placement(bins[best_tile], candidate_map.get(isl.id, []), margin_uv)
            if placement is None:
                cand = candidate_map.get(isl.id, [{}])[0]
                bmin = Vector(cand.get('bmin', Vector((0.0, 0.0))))
                placements[isl.id] = {
                    'angle': float(cand.get('angle', 0.0)),
                    'bmin': bmin,
                    'bmax': Vector(cand.get('bmax', Vector((0.0, 0.0)))),
                    'dx': float(margin_uv - bmin.x),
                    'dy': float(margin_uv - bmin.y),
                    'tile_index': int(best_tile),
                }
                continue
            best = dict(placement)

        cand = best['candidate']
        fx, fy, rw, rh = best['used_rect']
        target_min = Vector((fx + margin_uv, fy + margin_uv))
        delta = target_min - Vector(cand['bmin'])
        placements[isl.id] = {
            'angle': float(cand['angle']),
            'bmin': Vector(cand['bmin']),
            'bmax': Vector(cand['bmax']),
            'dx': float(delta.x),
            'dy': float(delta.y),
            'tile_index': int(best_tile),
        }
        bins[best_tile] = _place_in_free_rects(bins[best_tile], best['used_rect'])

    return placements


def _udim_number(tx: int, ty: int) -> int:
    return 1001 + tx + ty * 10

# ============================================================
# Scene cache
# ============================================================

def _cache_plain(value):
    """ID properties come back as IDPropertyArray/Group; callers compare plain lists and tuples."""
    if hasattr(value, "to_dict"):
        return value.to_dict()
    if hasattr(value, "to_list"):
        return value.to_list()
    if isinstance(value, (list, tuple)):
        return [_cache_plain(v) for v in value]
    return value


def _cache_get(scene, key, default=None):
    try:
        d = scene.get("SUV_CACHE", None)
        if not d:
            return default
        value = _cache_plain(d.get(key, default))
        if key == "sym_pairs" and isinstance(value, dict):
            return {int(index): int(pair) for index, pair in value.items()}
        return value
    except Exception:
        return default

def _cache_set(scene, key, value):
    try:
        d = scene.get("SUV_CACHE", None)
        if d is not None and hasattr(d, "to_dict"):
            d = d.to_dict()
        if not d or not isinstance(d, dict):
            d = {}
        if key == "sym_pairs":
            value = {str(index): pair for index, pair in value.items()}
        d[key] = value
        scene["SUV_CACHE"] = d
    except Exception:
        pass

# ============================================================
# Sets storage (object custom prop)
# ============================================================

_SETS_KEY = "SUV_SETS"
_LEGACY_SELECTION_SETS_KEY = "suv_selection_sets"
_SEAM_SETS_KEY = "SUV_SEAM_SETS"
_LAYOUT_SETS_KEY = "SUV_LAYOUT_SETS"

def _decode_json_idprop_payload(obj, key):
    if not obj:
        return {}
    val = obj.get(key, None)
    if val is None:
        return {}
    if isinstance(val, str):
        try:
            return json.loads(val)
        except Exception:
            return {}
    try:
        return dict(val)
    except Exception:
        return {}

def _encode_json_idprop_payload(obj, key, payload):
    if not obj:
        return
    obj[key] = json.dumps(payload)

def _get_sets(obj):
    legacy = _decode_json_idprop_payload(obj, _LEGACY_SELECTION_SETS_KEY)
    current = _decode_json_idprop_payload(obj, _SETS_KEY)
    sets = {}
    if isinstance(legacy, dict):
        sets.update({name: {"faces": faces} for name, faces in legacy.items() if isinstance(faces, list)})
    if isinstance(current, dict):
        sets.update(current)
    return sets

def _set_sets(obj, sets_dict):
    _encode_json_idprop_payload(obj, _SETS_KEY, sets_dict)
    if obj is not None and _LEGACY_SELECTION_SETS_KEY in obj:
        del obj[_LEGACY_SELECTION_SETS_KEY]

def _get_seam_sets(obj):
    return _decode_json_idprop_payload(obj, _SEAM_SETS_KEY)

def _set_seam_sets(obj, sets_dict):
    _encode_json_idprop_payload(obj, _SEAM_SETS_KEY, sets_dict)

def _get_layout_sets(obj):
    return _decode_json_idprop_payload(obj, _LAYOUT_SETS_KEY)

def _set_layout_sets(obj, sets_dict):
    _encode_json_idprop_payload(obj, _LAYOUT_SETS_KEY, sets_dict)

def _sets_enum_items(self, context):
    obj = _active_mesh_obj(context)
    d = _get_sets(obj)
    items = [(k, k, "") for k in sorted(d.keys())]
    if not items:
        items = [('__NONE__', "<None>", "")]
    return items

def _seam_sets_enum_items(self, context):
    obj = _active_mesh_obj(context)
    d = _get_seam_sets(obj)
    items = [(k, k, "") for k in sorted(d.keys())]
    if not items:
        items = [('__NONE__', "<None>", "")]
    return items

def _layout_sets_enum_items(self, context):
    obj = _active_mesh_obj(context)
    d = _get_layout_sets(obj)
    items = [(k, k, "") for k in sorted(d.keys())]
    if not items:
        items = [('__NONE__', "<None>", "")]
    return items

# ============================================================
# Symmetry helpers
# ============================================================

def _axis_index(axis: str) -> int:
    return {'X': 0, 'Y': 1, 'Z': 2}.get(axis, 0)

def _build_mirror_map(obj, bm, axis='X', space='LOCAL', offset=0.0, tol=1e-4):
    idx = _axis_index(axis)
    kd = KDTree(len(bm.verts))
    coords = []
    for v in bm.verts:
        co = v.co.copy()
        if space == 'WORLD':
            co = obj.matrix_world @ co
        coords.append(co)
        kd.insert(co, v.index)
    kd.balance()
    vmap = {}
    rev = {}
    for i, v in enumerate(bm.verts):
        co = coords[i]
        mirrored = co.copy()
        mirrored[idx] = (2.0 * offset) - co[idx]
        _loc, j, dist = kd.find(mirrored)
        if dist <= tol:
            vmap[v.index] = j
            rev[j] = v.index
    return vmap, rev

def _quantile_sorted_core(values, q: float):
    vals = list(values or [])
    if not vals:
        return 0.0
    if len(vals) == 1:
        return float(vals[0])
    q = max(0.0, min(1.0, float(q)))
    pos = (len(vals) - 1) * q
    lo = int(math.floor(pos))
    hi = int(math.ceil(pos))
    if lo == hi:
        return float(vals[lo])
    t = pos - lo
    return float(vals[lo]) * (1.0 - t) + float(vals[hi]) * t


def _unique_island_uv_points(isl: _Island, ndigits: int = 5):
    seen = set()
    pts = []
    for p in getattr(isl, 'uv_points', []) or []:
        v = Vector(p)
        key = (round(float(v.x), ndigits), round(float(v.y), ndigits))
        if key in seen:
            continue
        seen.add(key)
        pts.append(v)
    return pts


def _radial_signature_core(isl: _Island):
    pts = _unique_island_uv_points(isl)
    if not pts:
        return (1.0, 1.0, 1.0, 1.0, 1.0)
    center = Vector((sum(p.x for p in pts) / len(pts), sum(p.y for p in pts) / len(pts)))
    scale = max(1.0e-12, math.sqrt(max(1.0e-12, float(getattr(isl, 'abs_area', 0.0) or 0.0))))
    radii = sorted((p - center).length / scale for p in pts)
    qs = (0.05, 0.25, 0.5, 0.75, 0.95)
    return tuple(_quantile_sorted_core(radii, q) for q in qs)


def _pairwise_distance_signature_core(isl: _Island, limit: int = 48):
    pts = _unique_island_uv_points(isl)
    if len(pts) <= 1:
        return (0.0, 0.0, 0.0, 0.0, 0.0)
    if len(pts) > limit:
        stride = max(1, int(math.ceil(len(pts) / float(limit))))
        pts = pts[::stride][:limit]
    scale = max(1.0e-12, math.sqrt(max(1.0e-12, float(getattr(isl, 'abs_area', 0.0) or 0.0))))
    ds = []
    for i in range(len(pts)):
        for j in range(i + 1, len(pts)):
            ds.append((pts[j] - pts[i]).length / scale)
    if not ds:
        return (0.0, 0.0, 0.0, 0.0, 0.0)
    ds.sort()
    qs = (0.1, 0.25, 0.5, 0.75, 0.9)
    return tuple(_quantile_sorted_core(ds, q) for q in qs)


def _signature_ratio_ok(sig_a, sig_b, tol):
    for sa, sb in zip(sig_a, sig_b):
        base = max(1.0e-12, float(sa))
        if abs(float(sb) / base - 1.0) > float(tol):
            return False
    return True


def _symmetry_shape_compatible(a: _Island, b: _Island) -> bool:
    if len(a.faces) != len(b.faces):
        return False
    if len(a.vert_ids) != len(b.vert_ids):
        return False
    if len(getattr(a, 'loops', []) or []) != len(getattr(b, 'loops', []) or []):
        return False
    aw = max(1.0e-12, float(a.bbox_max.x - a.bbox_min.x))
    ah = max(1.0e-12, float(a.bbox_max.y - a.bbox_min.y))
    bw = max(1.0e-12, float(b.bbox_max.x - b.bbox_min.x))
    bh = max(1.0e-12, float(b.bbox_max.y - b.bbox_min.y))
    area_ratio = max(float(a.abs_area), float(b.abs_area)) / max(1.0e-12, min(float(a.abs_area), float(b.abs_area)))
    aspect_a = aw / ah
    aspect_b = bw / bh
    aspect_ratio = max(aspect_a, aspect_b) / max(1.0e-12, min(aspect_a, aspect_b))
    fill_a = float(a.abs_area) / max(1.0e-12, aw * ah)
    fill_b = float(b.abs_area) / max(1.0e-12, bw * bh)
    fill_ratio = max(fill_a, fill_b) / max(1.0e-12, min(fill_a, fill_b))
    sig_ok = _signature_ratio_ok(_radial_signature_core(a), _radial_signature_core(b), 0.08)
    dist_ok = _signature_ratio_ok(_pairwise_distance_signature_core(a), _pairwise_distance_signature_core(b), 0.06)
    return area_ratio <= 1.08 and aspect_ratio <= 1.10 and fill_ratio <= 1.15 and sig_ok and dist_ok


def _sym_pair_metrics(a: _Island, b: _Island, vmap, id_by_vert):
    mapped = [vmap.get(vid, None) for vid in a.vert_ids]
    mapped = [m for m in mapped if m is not None and id_by_vert.get(m, None) == b.id]
    if not mapped:
        return None
    reverse_hits = sum(1 for vid in b.vert_ids if vmap.get(vid, None) in a.vert_ids)
    coverage = len(mapped) / max(1, len(a.vert_ids))
    reverse_coverage = reverse_hits / max(1, len(b.vert_ids))
    if coverage < 0.6 or reverse_coverage < 0.6:
        return None
    sig_a = _radial_signature_core(a)
    sig_b = _radial_signature_core(b)
    sig_delta = sum(abs(float(sb) / max(1.0e-12, float(sa)) - 1.0) for sa, sb in zip(sig_a, sig_b))
    dist_a = _pairwise_distance_signature_core(a)
    dist_b = _pairwise_distance_signature_core(b)
    dist_delta = sum(abs(float(db) / max(1.0e-12, float(da)) - 1.0) for da, db in zip(dist_a, dist_b))
    area_ratio = max(float(a.abs_area), float(b.abs_area)) / max(1.0e-12, min(float(a.abs_area), float(b.abs_area)))
    return {
        'coverage': coverage,
        'reverse_coverage': reverse_coverage,
        'sig_delta': sig_delta,
        'dist_delta': dist_delta,
        'area_ratio': area_ratio,
    }


def _detect_sym_pairs(islands, vmap):
    islands = list(islands or [])
    id_by_vert = {}
    island_by_id = {isl.id: isl for isl in islands}
    for isl in islands:
        for vid in isl.vert_ids:
            id_by_vert[vid] = isl.id

    best_for = {}
    for isl in islands:
        counts = {}
        for vid in isl.vert_ids:
            mirrored = vmap.get(vid, None)
            other = id_by_vert.get(mirrored, None) if mirrored is not None else None
            if other is None or other == isl.id:
                continue
            counts[other] = counts.get(other, 0) + 1
        ranked = []
        for cand_id, hits in counts.items():
            other = island_by_id.get(cand_id)
            if other is None:
                continue
            if not _symmetry_shape_compatible(isl, other):
                continue
            metrics = _sym_pair_metrics(isl, other, vmap, id_by_vert)
            if metrics is None:
                continue
            ranked.append((
                -min(metrics['coverage'], metrics['reverse_coverage']),
                -((metrics['coverage'] + metrics['reverse_coverage']) * 0.5),
                metrics['sig_delta'],
                metrics['dist_delta'],
                metrics['area_ratio'],
                -hits,
                cand_id,
            ))
        if ranked:
            ranked.sort()
            best_for[isl.id] = ranked[0][-1]

    pairs = {}
    used = set()
    for isl_id, cand_id in sorted(best_for.items()):
        if isl_id in used or cand_id in used:
            continue
        if best_for.get(cand_id, None) != isl_id:
            continue
        pairs[isl_id] = cand_id
        pairs[cand_id] = isl_id
        used.add(isl_id)
        used.add(cand_id)
    return pairs


def _capture_island_state(islands):
    state = {}
    for isl in list(islands or []):
        face_sig = tuple(getattr(isl, 'face_sig', ()) or ())
        if not face_sig:
            continue
        centroid = Vector(getattr(isl, 'uv_centroid', Vector((0.0, 0.0))))
        state[face_sig] = {
            'centroid': centroid,
            'area': float(getattr(isl, 'abs_area', 0.0) or 0.0),
            'tile': (int(math.floor(centroid.x)), int(math.floor(centroid.y))),
        }
    return state


def _restore_island_state(islands, uv_layer, state, preserve_area=True, preserve_position=True, preserve_tile=False):
    restored = 0
    for isl in list(islands or []):
        meta = state.get(tuple(getattr(isl, 'face_sig', ()) or ()))
        if not meta:
            continue
        _refresh_island_tool_runtime_metrics(isl, uv_layer)
        if preserve_area:
            current_area = max(1.0e-12, float(getattr(isl, 'abs_area', 0.0) or 0.0))
            target_area = max(1.0e-12, float(meta.get('area', current_area) or current_area))
            ratio = target_area / current_area
            if ratio > 0.0:
                scale = math.sqrt(ratio)
                if abs(scale - 1.0) > 1.0e-5:
                    pivot = Vector(getattr(isl, 'uv_centroid', Vector((0.0, 0.0))))
                    _island_apply_transform(isl, uv_layer, lambda u, pivot=pivot, scale=scale: pivot + (Vector(u) - pivot) * scale)
                    _refresh_island_tool_runtime_metrics(isl, uv_layer)
        if preserve_position:
            target_cent = Vector(meta.get('centroid', getattr(isl, 'uv_centroid', Vector((0.0, 0.0)))))
            delta = target_cent - Vector(getattr(isl, 'uv_centroid', Vector((0.0, 0.0))))
            if delta.length > 1.0e-8:
                _island_apply_transform(isl, uv_layer, lambda u, delta=delta: Vector(u) + delta)
                _refresh_island_tool_runtime_metrics(isl, uv_layer)
        elif preserve_tile:
            cur_cent = Vector(getattr(isl, 'uv_centroid', Vector((0.0, 0.0))))
            cur_tile = (int(math.floor(cur_cent.x)), int(math.floor(cur_cent.y)))
            tgt_tile = meta.get('tile', cur_tile)
            delta = Vector((float(tgt_tile[0] - cur_tile[0]), float(tgt_tile[1] - cur_tile[1])))
            if delta.length > 1.0e-8:
                _island_apply_transform(isl, uv_layer, lambda u, delta=delta: Vector(u) + delta)
                _refresh_island_tool_runtime_metrics(isl, uv_layer)
        restored += 1
    return restored


def _suv_relax_selection_preserve(context, obj, faces_subset, iterations=100, preserve_area=True, preserve_position=True):
    if not obj:
        return False, 'No active mesh'
    faces_subset = list(faces_subset or [])
    with _TempMode(context, obj, 'EDIT'):
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        bm.faces.index_update()
        face_indices = [face.index for face in faces_subset]
        islands_before = build_islands(bm, uv_layer, faces_subset=faces_subset or list(bm.faces))
        before_state = _capture_island_state(islands_before)
    ok, err = _suv_run_minimize_stretch_native(context, iterations=iterations, fill_holes=True)
    if not ok:
        return False, err
    with _TempMode(context, obj, 'EDIT'):
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        bm.faces.ensure_lookup_table()
        live_faces = [bm.faces[index] for index in face_indices]
        islands_after = build_islands(bm, uv_layer, faces_subset=live_faces or list(bm.faces))
        # Blender's relax keeps pinned coordinates fixed. A later whole-island
        # scale or translation would move those anchors.
        unpinned_islands = [island for island in islands_after
                            if not any(loop[uv_layer].pin_uv for face in island.faces for loop in face.loops)]
        _restore_island_state(unpinned_islands, uv_layer, before_state or {}, preserve_area=preserve_area, preserve_position=preserve_position, preserve_tile=not preserve_position)
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    return True, None


# ============================================================
# Texel density helpers (island-based)
# ============================================================

def _world_face_area(obj, face):
    mw = obj.matrix_world
    verts = [mw @ v.co for v in face.verts]
    if len(verts) < 3:
        return 0.0
    area = 0.0
    o = verts[0]
    for i in range(1, len(verts) - 1):
        a = verts[i] - o
        b = verts[i + 1] - o
        area += a.cross(b).length * 0.5
    return area


def _island_density(obj, isl: _Island, uv_layer, texture_size: int, use_world_scale: bool):
    uv_area = 0.0
    try:
        uv_area = sum(abs(_signed_uv_area(f, uv_layer)) for f in isl.faces)
    except Exception:
        uv_area = max(float(getattr(isl, 'abs_area', 0.0) or 0.0), 0.0)
    uv_area = max(uv_area, 0.0)
    if uv_area <= 0.0:
        return 0.0
    if use_world_scale:
        area3d = sum(_world_face_area(obj, f) for f in isl.faces)
    else:
        area3d = sum(f.calc_area() for f in isl.faces)
    if area3d <= 0.0:
        return 0.0
    return (math.sqrt(uv_area) * float(texture_size)) / math.sqrt(area3d)

# ============================================================
# Bake helpers (multi-pass, multi-obj)
# ============================================================


def _material_slots_unique(objs):
    mats = set()
    for o in objs:
        for ms in o.material_slots:
            if ms.material:
                mats.add(ms.material)
    return list(mats)


def _suv_unique_id_name(id_collection, base: str, *, max_tries=4096):
    name = str(base or '').strip() or 'SUV_Data'
    try:
        if id_collection.get(name) is None:
            return name
    except Exception:
        return name
    for i in range(1, max_tries + 1):
        cand = f"{name}.{i:03d}"
        try:
            if id_collection.get(cand) is None:
                return cand
        except Exception:
            return cand
    return f"{name}_{int(time.time())}"


def _suv_pick_material_name(base: str):
    return _suv_unique_id_name(bpy.data.materials, base)


def _suv_pick_image_name(base: str):
    return _suv_unique_id_name(bpy.data.images, base)


def _create_image_for_pass(name: str, w: int, h: int, alpha: bool, image_mode: str, tiles: set):
    name = _suv_pick_image_name(name)
    if image_mode == 'UDIM_TILED':
        img = None
        try:
            img = bpy.data.images.new(name, width=w, height=h, alpha=alpha, tiled=True)
        except Exception:
            img = bpy.data.images.new(name, width=w, height=h, alpha=alpha)
            try:
                img.source = 'TILED'
            except Exception:
                pass
        # Create tiles
        try:
            existing = set()
            try:
                for t in img.tiles:
                    existing.add(getattr(t, "number", None))
            except Exception:
                existing = set()
            for (tx, ty) in tiles:
                num = _udim_number(tx, ty)
                if num in existing:
                    continue
                try:
                    img.tiles.new(num)
                except Exception:
                    pass
        except Exception:
            pass
        return img
    return bpy.data.images.new(name, width=w, height=h, alpha=alpha)

def _build_bake_nodes(materials, images_by_pass: dict):
    """
    Create an image node per pass per material.
    Returns dict: mat -> {pass_key: node}
    """
    nodes_by_mat = {}
    for mat in materials:
        mat.use_nodes = True
        nt = mat.node_tree
        nodes_by_mat[mat] = {}
        for key, img in images_by_pass.items():
            tex = nt.nodes.new("ShaderNodeTexImage")
            tex.name = "SUV_BAKE_TARGET"
            tex.label = f"[SUV] BAKE_TARGET_{key}"
            tex.image = img
            nodes_by_mat[mat][key] = tex
        # set a default active
        try:
            nt.nodes.active = next(iter(nodes_by_mat[mat].values()))
        except Exception:
            pass
    return nodes_by_mat

def _set_active_bake_node(nodes_by_mat: dict, pass_key: str):
    for mat, d in nodes_by_mat.items():
        nt = mat.node_tree
        node = d.get(pass_key)
        if node:
            nt.nodes.active = node

def _remove_bake_nodes(materials):
    for mat in materials:
        if not mat or not mat.node_tree:
            continue
        nt = mat.node_tree
        for n in list(nt.nodes):
            if n.name == "SUV_BAKE_TARGET" or (isinstance(n.label, str) and n.label.startswith("[SUV] BAKE_TARGET")):
                nt.nodes.remove(n)

def _try_bake(bake_type: str):
    try:
        bpy.ops.object.bake(type=bake_type)
        return True, None
    except Exception as e:
        return False, str(e)


def _suv_brief_object_names(objs, limit=8):
    names = [getattr(o, 'name', str(o)) for o in (objs or [])]
    if len(names) > limit:
        return ', '.join(names[:limit]) + f" ... (+{len(names) - limit})"
    return ', '.join(names) if names else '-'


def _suv_set_active_object(context, obj):
    if not obj or not _suv_object_is_selectable(obj):
        return False

    try:
        previous_selected = list(getattr(context, 'selected_objects', []) or [])
    except Exception:
        previous_selected = []
    try:
        previous_active = getattr(getattr(context, 'view_layer', None), 'objects', None)
        previous_active = getattr(previous_active, 'active', None)
    except Exception:
        previous_active = None

    try:
        obj.select_set(True)
    except Exception:
        return False

    try:
        context.view_layer.objects.active = obj
    except Exception:
        current_selected = []
        try:
            current_selected = list(getattr(context, 'selected_objects', []) or [])
        except Exception:
            current_selected = []
        previous_set = {o for o in previous_selected if o is not None}
        for other in current_selected:
            if other is None or other in previous_set:
                continue
            if not _suv_object_is_selectable(other):
                continue
            try:
                other.select_set(False)
            except Exception:
                pass
        for previous in previous_selected:
            if previous is None or not _suv_object_is_selectable(previous):
                continue
            try:
                previous.select_set(True)
            except Exception:
                pass
        if previous_active is not None and _suv_object_is_selectable(previous_active):
            try:
                previous_active.select_set(True)
            except Exception:
                pass
            try:
                context.view_layer.objects.active = previous_active
            except Exception:
                pass
        return False

    try:
        if getattr(context.view_layer.objects, 'active', None) is obj:
            return True
    except Exception:
        pass

    current_selected = []
    try:
        current_selected = list(getattr(context, 'selected_objects', []) or [])
    except Exception:
        current_selected = []
    previous_set = {o for o in previous_selected if o is not None}
    for other in current_selected:
        if other is None or other in previous_set:
            continue
        if not _suv_object_is_selectable(other):
            continue
        try:
            other.select_set(False)
        except Exception:
            pass
    for previous in previous_selected:
        if previous is None or not _suv_object_is_selectable(previous):
            continue
        try:
            previous.select_set(True)
        except Exception:
            pass
    if previous_active is not None and _suv_object_is_selectable(previous_active):
        try:
            previous_active.select_set(True)
        except Exception:
            pass
        try:
            context.view_layer.objects.active = previous_active
        except Exception:
            pass
    return False


def _suv_ensure_object_mode(context, obj=None):
    obj = obj or _active_mesh_obj(context)
    if not obj:
        return False
    ok, _err = _suv_safe_mode_set(context, obj, 'OBJECT', source='Ensure Object Mode')
    return bool(ok)


def _suv_preflight_mesh_objects(context, operator=None, *, source='Preflight', require_uv=False, require_active_uv=False, require_named_uv=None, make_active=True):
    objs = _selected_mesh_objects(context)
    if not objs:
        _suv_log_event(context, 'WARN', source, 'No selected mesh objects')
        if operator is not None:
            operator.report({'WARNING'}, tr(context, 'msg.no_selection'))
        return None
    if make_active and not _suv_set_active_object(context, objs[0]):
        _suv_log_event(context, 'WARN', source, 'Could not prepare an active mesh object', {'objects': _suv_brief_object_names(objs)})
        if operator is not None:
            operator.report({'WARNING'}, tr(context, 'msg.preflight_no_active'))
        return None
    missing_uv = []
    missing_active = []
    missing_named = []
    for obj in objs:
        try:
            uv_layers = obj.data.uv_layers
        except Exception:
            uv_layers = None
        if require_uv and (uv_layers is None or len(uv_layers) == 0):
            missing_uv.append(obj)
            continue
        if require_active_uv and uv_layers and uv_layers.active is None:
            missing_active.append(obj)
        if require_named_uv and (uv_layers is None or uv_layers.get(require_named_uv) is None):
            missing_named.append(obj)
    if missing_uv:
        names = _suv_brief_object_names(missing_uv)
        _suv_log_event(context, 'WARN', source, 'Missing UV maps on selected objects', {'objects': names})
        if operator is not None:
            operator.report({'WARNING'}, tr(context, 'msg.preflight_missing_uv', objs=names))
        return None
    if missing_active:
        names = _suv_brief_object_names(missing_active)
        _suv_log_event(context, 'WARN', source, 'Missing active UV map on selected objects', {'objects': names})
        if operator is not None:
            operator.report({'WARNING'}, tr(context, 'msg.preflight_missing_active_uv', objs=names))
        return None
    if missing_named:
        names = _suv_brief_object_names(missing_named)
        _suv_log_event(context, 'WARN', source, 'Required named UV map missing on selected objects', {'uv_name': require_named_uv, 'objects': names})
        if operator is not None:
            operator.report({'WARNING'}, tr(context, 'msg.preflight_missing_named_uv', name=require_named_uv, objs=names))
        return None
    return objs


def _suv_ensure_temp_bake_materials(objs, prefix='SUV_TempBake'):
    created = []
    for obj in objs or []:
        try:
            has_slot = bool(getattr(obj, 'material_slots', None)) and len(obj.material_slots) > 0
        except Exception:
            has_slot = False
        if has_slot:
            continue
        try:
            mat = bpy.data.materials.new(f"{prefix}_{obj.name}")
            mat.use_nodes = True
            obj.data.materials.append(mat)
            created.append(obj)
        except Exception:
            pass
    return created

def _collect_udim_tiles(objs, atlas_uv_name: str):
    tiles = set()
    for obj in objs:
        uv = obj.data.uv_layers.get(atlas_uv_name)
        if not uv:
            continue
        for d in uv.data:
            tiles.add((int(math.floor(d.uv.x)), int(math.floor(d.uv.y))))
    return tiles if tiles else {(0, 0)}

# ============================================================
# Material builder (shared atlas)
# ============================================================

def _build_material_with_images_shared(atlas_uv_name: str, images_by_pass: dict, mat_name: str, use_ao_multiply: bool = True):
    mat = bpy.data.materials.new(mat_name)
    mat.use_nodes = True
    nt = mat.node_tree
    nodes = nt.nodes
    links = nt.links
    nodes.clear()

    out = nodes.new("ShaderNodeOutputMaterial")
    out.location = (650, 0)
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.location = (300, 0)
    links.new(bsdf.outputs.get("BSDF"), out.inputs.get("Surface"))

    uvmap = nodes.new("ShaderNodeUVMap")
    uvmap.location = (-750, 0)
    uvmap.uv_map = atlas_uv_name

    def add_tex(pass_key, label, locy, colorspace_srgb):
        img = images_by_pass.get(pass_key)
        if not img:
            return None
        tex = nodes.new("ShaderNodeTexImage")
        tex.location = (-450, locy)
        tex.label = f"[SUV] {label}"
        tex.image = img
        try:
            tex.image.colorspace_settings.name = "sRGB" if colorspace_srgb else "Non-Color"
        except Exception:
            pass
        links.new(uvmap.outputs.get("UV"), tex.inputs.get("Vector"))
        return tex

    tex_base = add_tex("BaseColor", "BaseColor", 250, True)
    tex_ao = add_tex("AO", "AO", 80, False)
    tex_rough = add_tex("Roughness", "Roughness", -80, False)
    tex_metal = add_tex("Metallic", "Metallic", -220, False)
    tex_emit = add_tex("Emission", "Emission", 420, True)
    tex_norm = add_tex("Normal", "Normal", -380, False)

    if tex_norm:
        nmap = nodes.new("ShaderNodeNormalMap")
        nmap.location = (-140, -380)
        nmap.label = "[SUV] NormalMap"
        links.new(tex_norm.outputs.get("Color"), nmap.inputs.get("Color"))
        links.new(nmap.outputs.get("Normal"), bsdf.inputs.get("Normal"))

    if tex_rough:
        links.new(tex_rough.outputs.get("Color"), bsdf.inputs.get("Roughness"))
    if tex_metal:
        links.new(tex_metal.outputs.get("Color"), bsdf.inputs.get("Metallic"))
    if tex_emit:
        links.new(tex_emit.outputs.get("Color"), bsdf.inputs.get("Emission"))

    if tex_base and tex_ao and use_ao_multiply:
        mix_node = nodes.new("ShaderNodeMixRGB")
        mix_node.location = (40, 220)
        mix_node.blend_type = 'MULTIPLY'
        mix_node.inputs.get("Fac").default_value = 1.0
        links.new(tex_base.outputs.get("Color"), mix_node.inputs.get("Color1"))
        links.new(tex_ao.outputs.get("Color"), mix_node.inputs.get("Color2"))
        links.new(mix_node.outputs.get("Color"), bsdf.inputs.get("Base Color"))
    elif tex_base:
        links.new(tex_base.outputs.get("Color"), bsdf.inputs.get("Base Color"))

    return mat

