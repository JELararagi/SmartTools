"""Implement the inspect inspection public UV operations."""

import bpy


def inspect_inspection_update(context, op):
    return 'FINISHED' in bpy.ops.uv.suv_inspector_scan(scope=op.scope or 'SELECTED')


def build_handlers(api):
    return {
        "smart_uv_suite.batch_inspect": api.Handler(
            api._run_uv_layout("suv_native_stage_compat_tools", defaults={"mode": "BATCH_INSPECTOR_SCAN"}),
            "Scan UV issues on each selected mesh.",
            "選択した各メッシュのUVの問題を検査します。",
        ),
        "smart_uv_suite.inspect_gravity": api.Handler(
            api._run_uv_layout("inspect_orient_world", namespace="smart_uv_suite"),
            "Align the selected UVs to the world axes.",
            "選択したUVをワールド軸に整列します。",
        ),

        "smart_uv_suite.inspect_inspection_update": api.Handler(inspect_inspection_update, 'Update the UV issue inspection results.', 'UV問題の検査結果を更新します。'),
        "smart_uv_suite.inspect_cockpit_run": api.Handler(
            api._run_uv_layout('cockpit_run', namespace='smart_uv_suite', intent='mode'),
            'Run the chosen Cockpit production route.',
            '選択したコックピットの制作ルートを実行します。',
        ),
        "smart_uv_suite.inspect_excellence_action": api.Handler(
            api._run_uv_layout('excellence_action', namespace='smart_uv_suite', action='action'),
            'Run the chosen Excellence workflow and generate its report.',
            '選択したExcellenceワークフローを実行してレポートを作成します。',
        ),
        "smart_uv_suite.inspect_smart_uv_precision_action": api.Handler(
            api._run_uv_layout('smart_uv_precision_action', namespace='smart_uv_suite', action='action'),
            'Run the chosen Precision workflow and generate its report.',
            '選択した高精度ワークフローを実行してレポートを作成します。',
        ),

    }
