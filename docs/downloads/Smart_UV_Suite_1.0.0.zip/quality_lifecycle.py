from __future__ import annotations

_SUV_WARNED = set()


def _suv_warn_once(key, *parts):
    if key not in _SUV_WARNED:
        _SUV_WARNED.add(key)
        print(' '.join(str(p) for p in parts))



try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None


def _log(namespace: dict, source: str, exc: Exception, details=None):
    try:
        fn = namespace.get('_suv_log_exception')
        context = getattr(bpy, 'context', None) if bpy is not None else None
        if callable(fn):
            fn(context, source, exc, details or {})
    except Exception:
        pass
    try:
        _suv_warn_once('a106:quality_lifecycle.py:18', f"[UV Suite Quality] {source}: {type(exc).__name__}: {exc}")
    except Exception:
        pass


def register(namespace: dict, prev_register, install_layers, register_translations, extra_register=None):
    state = {
        'base_register': False,
        'quality_layers': False,
        'translations': False,
        'extra_register': False,
    }

    if callable(prev_register):
        try:
            prev_register()
            state['base_register'] = True
        except Exception as exc:
            _log(namespace, 'Addon register', exc, {'stage': 'base_register'})
    else:
        state['base_register'] = True

    try:
        install_layers()
        state['quality_layers'] = True
    except Exception as exc:
        _log(namespace, 'Quality layer install', exc, {'stage': 'quality_layers'})

    try:
        register_translations()
        state['translations'] = True
    except Exception as exc:
        _log(namespace, 'Translation register', exc, {'stage': 'translations'})

    try:
        if callable(extra_register):
            extra_register()
        state['extra_register'] = True
    except Exception as exc:
        _log(namespace, 'Extra register', exc, {'stage': 'extra_register'})

    namespace['_suv_quality_lifecycle_state'] = state
    return state


def unregister(namespace: dict, unregister_translations, prev_unregister, extra_unregister=None):
    state = {
        'translations': False,
        'base_unregister': False,
        'extra_unregister': False,
    }
    try:
        if callable(extra_unregister):
            extra_unregister()
        state['extra_unregister'] = True
    except Exception as exc:
        _log(namespace, 'Extra unregister', exc, {'stage': 'extra_unregister'})
    try:
        unregister_translations()
        state['translations'] = True
    except Exception as exc:
        _log(namespace, 'Translation unregister', exc, {'stage': 'translations'})
    try:
        if callable(prev_unregister):
            prev_unregister()
        state['base_unregister'] = True
    except Exception as exc:
        _log(namespace, 'Addon unregister', exc, {'stage': 'base_unregister'})
    namespace['_suv_quality_lifecycle_unreg_state'] = state
    return state
