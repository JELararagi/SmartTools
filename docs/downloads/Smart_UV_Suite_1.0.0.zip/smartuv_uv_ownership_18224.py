# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""SmartUV-owned UV Editor selection/transform/keymap surface.

This module is the SmartUV side of the SmartTransform UV ownership migration.
SmartOverlay keeps its 3D/UV overlay responsibilities, and SmartTransform keeps
its 3D View responsibilities.  Only UV Editor selection/transform/keymap entry
points are registered here.

SmartUV is the single owner of the UV Editor proportional-cursor rows and the
UV crossing gesture rows.  Keymap registration
is transactional: a partial failure removes every row created by that
transaction, and an unavailable keyconfig defers registration to a bounded
delayed self-repair timer instead of failing the whole add-on registration.
"""
from __future__ import annotations

import math
from typing import Any

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover - static tooling
    bpy = None  # type: ignore

from . import ownership_runtime_18168 as _ownership
from . import smartuv_uv_crossing_18360 as _crossing


UV_PROP_CURSOR_ID = "image.smart_uv_proportional_size_cursor"
UV_HOVER_CURSOR_ID = "smart_uv_suite.cursor_to_hover_uv_vertex"
UV_CROSS_EDGE_ID = "smart_uv_suite.uv_crossing_select_edges"
UV_CROSS_FACE_ID = "smart_uv_suite.uv_crossing_select_faces"
UV_CROSS_GESTURE_ID = _crossing.UV_CROSS_GESTURE_ID

# 1.8.230: the UV Smart G-R-S keymap feature was removed entirely.  The
# literal idnames stay for exactly one release as a cleanup sweep target:
# earlier builds registered these rows in the addon keyconfig and the N-panel
# told users to hand-register them in Preferences, so stale rows pointing at
# the deleted operators are removed at register()/unregister() time.
_LEGACY_UV_GRS_IDS = (
    "transform.smart_uv_grs_move",
    "transform.smart_uv_grs_rotate",
    "transform.smart_uv_grs_scale",
)
_UV_PROP_CURSOR_KEYMAPS = (
    (UV_PROP_CURSOR_ID, "PAGE_UP", 0.1),
    (UV_PROP_CURSOR_ID, "PAGE_DOWN", -0.1),
)
_UV_HOVER_CURSOR_KEYMAPS = (
    (UV_HOVER_CURSOR_ID, "F8"),
)
_UV_CROSS_GESTURE_KEYMAPS = (
    (UV_CROSS_GESTURE_ID, "B", "BOX", False),
    (UV_CROSS_GESTURE_ID, "C", "CIRCLE", False),
    (UV_CROSS_GESTURE_ID, "RIGHTMOUSE", "LASSO", True),
)
# Tool-drag entries: the normal workflow drags with the standard Select
# Box/Circle/Lasso TOOLS, which dispatch through these tool keymaps straight to
# native uv.select_* (enclosed-only semantics).  Owned LEFTMOUSE rows there let
# the exact crossing gesture intercept the drag; the operator PASS_THROUGHs to
# native whenever the feature/mode does not apply.  This mirrors the 5-map
# pattern the Immediate Select feature uses in uv_immediate_drag_stability_18112.
_UV_CROSS_TOOL_MAPS = (
    ("Image Editor Tool: Uv, Select Box", "BOX"),
    ("Image Editor Tool: Uv, Select Box (fallback)", "BOX"),
    ("Image Editor Tool: Uv, Select Circle", "CIRCLE"),
    ("Image Editor Tool: Uv, Select Circle (fallback)", "CIRCLE"),
    ("Image Editor Tool: Uv, Select Lasso", "LASSO"),
    ("Image Editor Tool: Uv, Select Lasso (fallback)", "LASSO"),
)
# Shift adds, Ctrl subtracts, Shift+Ctrl toggles: the gesture operator resolves
# the selection operation from the event modifiers, so a row must exist for
# every modifier combination or modified drags fall back to native rows.
_UV_CROSS_TOOL_MODIFIER_ROWS = (
    (False, False),
    (True, False),
    (False, True),
    (True, True),
)
_UV_OWNED_IDS = (
    UV_PROP_CURSOR_ID,
    UV_HOVER_CURSOR_ID,
    UV_CROSS_EDGE_ID,
    UV_CROSS_FACE_ID,
    UV_CROSS_GESTURE_ID,
)
_REGISTERED = False
_PACKAGE_GLOBALS: dict[str, Any] | None = None

# Bounded keyconfig self-repair.  A keyconfig-unavailable startup keeps the
# add-on registered and retries here; exhaustion is a reported terminal state.
_REPAIR_MAX_ATTEMPTS = 10
_REPAIR_FIRST_INTERVAL = 1.0
_REPAIR_BACKOFF = 1.5
_REPAIR_MAX_INTERVAL = 8.0
_REPAIR_STATE: dict[str, Any] = {"handle": None, "attempts": 0, "exhausted": False}
_KEYMAP_DESIRED: dict[str, bool] = {"prop_cursor": False, "hover_cursor": True, "crossing": False}
_LAST_PROP_CURSOR_DIAGNOSTIC: dict[str, Any] = {"sequence": 0, "phase": "idle", "result": "NONE"}
_PROP_CURSOR_SEQUENCE = 0


def _is_uv_editor_context(context: Any) -> bool:
    try:
        area = getattr(context, "area", None)
        if getattr(area, "type", "") != "IMAGE_EDITOR":
            return False
        space = getattr(context, "space_data", None)
        if getattr(space, "type", "") != "IMAGE_EDITOR":
            return False
        mode = getattr(space, "mode", None)
        if mode not in {None, "", "UV"}:
            return False
        return True
    except Exception:
        return False


def _record_prop_cursor(self: Any, phase: str, result: str, reason: str, event: Any = None, **details: Any) -> None:
    """Record the latest proportional-radius modal observation for runtime gates.

    This diagnostic is intentionally simple and side-effect free: acceptance
    harnesses can prove that the public shortcut entered the modal path without
    relying on Blender's transient operator stack.
    """
    global _PROP_CURSOR_SEQUENCE, _LAST_PROP_CURSOR_DIAGNOSTIC
    try:
        sequence = getattr(self, "_suv_prop_sequence", None)
        if sequence is None:
            _PROP_CURSOR_SEQUENCE += 1
            sequence = int(_PROP_CURSOR_SEQUENCE)
            try:
                self._suv_prop_sequence = sequence
            except Exception:
                pass
        payload: dict[str, Any] = {
            "sequence": int(sequence),
            "phase": str(phase),
            "result": str(result),
            "reason": str(reason),
            "event_type": str(getattr(event, "type", "") or ""),
            "event_value": str(getattr(event, "value", "") or ""),
            "start_radius": float(getattr(self, "_suv_prop_start_radius", 0.0) or 0.0),
            "current_radius": float(getattr(self, "_suv_prop_current_radius", 0.0) or 0.0),
            "has_draw_handle": getattr(self, "_suv_prop_draw_handle", None) is not None,
        }
        payload.update(details)
        _LAST_PROP_CURSOR_DIAGNOSTIC = payload
    except Exception:
        _LAST_PROP_CURSOR_DIAGNOSTIC = {"sequence": 0, "phase": str(phase), "result": str(result), "reason": "diagnostic_failed"}


def _proportional_size_hard_limits(settings: Any) -> tuple[float, float]:
    """Return Blender's public RNA hard range for ToolSettings.proportional_size."""
    fallback = (0.0001, 5000.0)
    try:
        prop = settings.bl_rna.properties["proportional_size"]
        hard_min = float(prop.hard_min)
        hard_max = float(prop.hard_max)
        if math.isfinite(hard_min) and math.isfinite(hard_max) and 0.0 < hard_min <= hard_max:
            return hard_min, hard_max
    except Exception:
        pass
    return fallback


def _draw_prop_cursor_overlay(self: Any) -> None:
    """Draw a small UV Editor radius guide while the modal shortcut is active."""
    try:
        if bpy is None:
            return
        import gpu  # type: ignore
        from gpu_extras.batch import batch_for_shader  # type: ignore

        region = getattr(self, "_suv_prop_region", None)
        # SpaceImageEditor draw handlers are class-wide. Restrict the guide to
        # the exact WINDOW region that originated this modal session.
        origin_ptr = getattr(self, "_suv_prop_region_ptr", None)
        active_region = getattr(bpy.context, "region", None)
        if origin_ptr is not None and (active_region is None or active_region.as_pointer() != origin_ptr):
            return
        view2d = getattr(region, "view2d", None)
        if view2d is None:
            return
        center_uv = getattr(self, "_suv_prop_center_uv", (0.0, 0.0))
        radius = float(getattr(self, "_suv_prop_current_radius", getattr(self, "_suv_prop_start_radius", 1.0)) or 1.0)
        cx, cy = view2d.view_to_region(float(center_uv[0]), float(center_uv[1]), clip=False)
        px, _py = view2d.view_to_region(float(center_uv[0]) + max(radius, 0.0001), float(center_uv[1]), clip=False)
        pixel_radius = max(5.0, min(1000.0, abs(float(px) - float(cx))))
        points = [
            (
                float(cx) + math.cos((math.tau * i) / 64.0) * pixel_radius,
                float(cy) + math.sin((math.tau * i) / 64.0) * pixel_radius,
            )
            for i in range(65)
        ]
        shader = gpu.shader.from_builtin("UNIFORM_COLOR")
        batch = batch_for_shader(shader, "LINE_STRIP", {"pos": points})
        shader.bind()
        shader.uniform_float("color", (0.35, 0.72, 1.0, 0.95))
        batch.draw(shader)
    except Exception:
        return


class IMAGE_OT_smart_uv_proportional_size_cursor(bpy.types.Operator if bpy is not None else object):  # type: ignore[misc]
    bl_idname = UV_PROP_CURSOR_ID
    bl_label = "Smart UV Proportional Size Cursor"
    bl_description = "SmartUV-owned UV Editor proportional editing size cursor entry point."
    bl_options = {"REGISTER", "BLOCKING", "GRAB_CURSOR"}

    delta: bpy.props.FloatProperty(  # type: ignore[union-attr]
        name="Delta",
        default=0.0,
        description="Optional proportional size delta for direct execution.",
    ) if bpy is not None else None

    @classmethod
    def poll(cls, context):
        return _is_uv_editor_context(context)

    def invoke(self, context, event):
        if event is None:
            return self.execute(context)
        try:
            settings = getattr(context, "tool_settings", None)
            start_radius = float(getattr(settings, "proportional_size", 1.0))
            hard_min, hard_max = _proportional_size_hard_limits(settings)
        except Exception:
            return {"CANCELLED"}
        if not math.isfinite(start_radius) or start_radius <= 0.0:
            start_radius = 1.0
        start_radius = max(hard_min, min(start_radius, hard_max))
        try:
            self._suv_prop_start_radius = float(start_radius)
            self._suv_prop_current_radius = float(start_radius)
            self._suv_prop_hard_min = float(hard_min)
            self._suv_prop_hard_max = float(hard_max)
            self._suv_prop_start_xy = (
                float(getattr(event, "mouse_region_x", 0.0) or 0.0),
                float(getattr(event, "mouse_region_y", 0.0) or 0.0),
            )
            self._suv_prop_region = getattr(context, "region", None)
            self._suv_prop_area = getattr(context, "area", None)
            self._suv_prop_window = getattr(context, "window", None)
            self._suv_prop_region_ptr = self._suv_prop_region.as_pointer() if self._suv_prop_region else None
            self._suv_prop_area_ptr = self._suv_prop_area.as_pointer() if self._suv_prop_area else None
            region = self._suv_prop_region
            if region is not None and getattr(region, "view2d", None) is not None:
                self._suv_prop_center_uv = tuple(region.view2d.region_to_view(*self._suv_prop_start_xy))
            else:
                self._suv_prop_center_uv = (0.0, 0.0)
        except Exception:
            return {"CANCELLED"}
        self._suv_prop_draw_handle = None
        self._add_draw_handler(context)
        _record_prop_cursor(self, "invoke", "RUNNING_MODAL", "started", event)
        try:
            context.window_manager.modal_handler_add(self)
        except Exception:
            self._cleanup_modal(context, restore=True)
            return {"CANCELLED"}
        return {"RUNNING_MODAL"}

    def _add_draw_handler(self, context):
        if bpy is None:
            return
        try:
            handle = bpy.types.SpaceImageEditor.draw_handler_add(
                _draw_prop_cursor_overlay,
                (self,),
                "WINDOW",
                "POST_PIXEL",
            )
            self._suv_prop_draw_handle = handle
        except Exception:
            self._suv_prop_draw_handle = None

    def _remove_draw_handler(self):
        handle = getattr(self, "_suv_prop_draw_handle", None)
        self._suv_prop_draw_handle = None
        if handle is None or bpy is None:
            return
        try:
            bpy.types.SpaceImageEditor.draw_handler_remove(handle, "WINDOW")
        except Exception:
            pass

    def _cleanup_modal(self, context, *, restore: bool):
        if restore:
            try:
                settings = getattr(context, "tool_settings", None)
                setattr(settings, "proportional_size", float(getattr(self, "_suv_prop_start_radius", 1.0)))
            except Exception:
                pass
        self._remove_draw_handler()
        try:
            area = getattr(self, "_suv_prop_area", None) or getattr(context, "area", None)
            if area is not None:
                area.tag_redraw()
        except Exception:
            pass

    def modal(self, context, event):
        etype = str(getattr(event, "type", "") or "")
        evalue = str(getattr(event, "value", "") or "")
        # Blender's event dispatch may supply a transient context wrapper whose
        # Window RNA identity is not object-identical to the invoke-time context.
        # The modal is already bound to the UV Editor region and exits via
        # explicit confirm/cancel events, so do not cancel a valid same-editor
        # radius drag solely because that wrapper identity changed.
        if etype in {"ESC", "RIGHTMOUSE"}:
            self._cleanup_modal(context, restore=True)
            _record_prop_cursor(self, "cancel", "CANCELLED", "user_cancel", event)
            return {"CANCELLED"}
        if etype in {"LEFTMOUSE", "RET", "NUMPAD_ENTER"} and evalue in {"PRESS", "RELEASE", ""}:
            self._cleanup_modal(context, restore=False)
            _record_prop_cursor(self, "confirm", "FINISHED", "confirmed", event)
            return {"FINISHED"}
        if etype in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
            try:
                sx, _sy = getattr(self, "_suv_prop_start_xy", (0.0, 0.0))
                mx = float(getattr(event, "mouse_region_x", sx) or sx)
                # Match the accepted cursor-size convention: horizontal right
                # grows and horizontal left shrinks. Vertical travel must not
                # apply a second radius adjustment.
                pixels = mx - float(sx)
                start = float(getattr(self, "_suv_prop_start_radius", 1.0))
                hard_min = float(getattr(self, "_suv_prop_hard_min", 0.0001))
                hard_max = float(getattr(self, "_suv_prop_hard_max", 5000.0))
                requested_radius = max(hard_min, min(start * math.exp(float(pixels) * 0.008), hard_max))
                settings = getattr(context, "tool_settings", None)
                setattr(settings, "proportional_size", requested_radius)
                actual_radius = float(getattr(settings, "proportional_size", requested_radius))
                self._suv_prop_current_radius = actual_radius
                _record_prop_cursor(
                    self,
                    "drag",
                    "RUNNING_MODAL",
                    "radius_changed",
                    event,
                    radius=actual_radius,
                    requested_radius=requested_radius,
                    hard_min=hard_min,
                    hard_max=hard_max,
                )
                try:
                    area = getattr(context, "area", None)
                    if area is not None:
                        area.tag_redraw()
                except Exception:
                    pass
            except Exception as exc:
                self._cleanup_modal(context, restore=True)
                _record_prop_cursor(self, "cancel", "CANCELLED", "radius_update_failed", event, exception=type(exc).__name__)
                return {"CANCELLED"}
        return {"RUNNING_MODAL"}

    def cancel(self, context):
        self._cleanup_modal(context, restore=True)

    def execute(self, context):
        try:
            settings = getattr(context, "tool_settings", None)
            current = float(getattr(settings, "proportional_size", 1.0))
            delta = float(getattr(self, "delta", 0.0) or 0.0)
            if delta:
                hard_min, hard_max = _proportional_size_hard_limits(settings)
                setattr(settings, "proportional_size", max(hard_min, min(current + delta, hard_max)))
            return {"FINISHED"}
        except Exception:
            return {"CANCELLED"}


def _dispatch_crossing_gesture(context: Any, mode: str) -> set[str]:
    """Run the exact SmartUV crossing gesture engine; never stock uv.select_*."""
    if bpy is None:
        return {"CANCELLED"}
    try:
        op_group = getattr(getattr(bpy, "ops", None), "smart_uv_suite", None)
        gesture_op = getattr(op_group, "uv_crossing_gesture", None)
        if gesture_op is None:
            return {"CANCELLED"}
        return set(gesture_op("INVOKE_DEFAULT", gesture="BOX", mode=str(mode)))
    except Exception:
        return {"CANCELLED"}


class SMARTUVSUITE_OT_uv_crossing_select_edges(bpy.types.Operator if bpy is not None else object):  # type: ignore[misc]
    bl_idname = UV_CROSS_EDGE_ID
    bl_label = "UV Crossing Select Edges"
    bl_description = "Runs the exact SmartUV UV Editor edge crossing box selection."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _is_uv_editor_context(context)

    def invoke(self, context, event):
        try:
            context.tool_settings.uv_select_mode = "EDGE"
        except Exception:
            pass
        return _dispatch_crossing_gesture(context, "EDGE")

    def execute(self, context):
        try:
            context.tool_settings.uv_select_mode = "EDGE"
        except Exception:
            pass
        return _dispatch_crossing_gesture(context, "EDGE")


class SMARTUVSUITE_OT_uv_crossing_select_faces(bpy.types.Operator if bpy is not None else object):  # type: ignore[misc]
    bl_idname = UV_CROSS_FACE_ID
    bl_label = "UV Crossing Select Faces"
    bl_description = "Runs the exact SmartUV UV Editor face crossing box selection."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _is_uv_editor_context(context)

    def invoke(self, context, event):
        try:
            context.tool_settings.uv_select_mode = "FACE"
        except Exception:
            pass
        return _dispatch_crossing_gesture(context, "FACE")

    def execute(self, context):
        try:
            context.tool_settings.uv_select_mode = "FACE"
        except Exception:
            pass
        return _dispatch_crossing_gesture(context, "FACE")


_CLASSES = (
    IMAGE_OT_smart_uv_proportional_size_cursor,
    SMARTUVSUITE_OT_uv_crossing_select_edges,
    SMARTUVSUITE_OT_uv_crossing_select_faces,
) + tuple(_crossing.CROSSING_CLASSES)


def _keyconfig():
    if bpy is None:
        return None
    try:
        wm = getattr(getattr(bpy, "context", None), "window_manager", None)
        return getattr(getattr(wm, "keyconfigs", None), "addon", None)
    except Exception:
        return None


# Addon keymaps merge into the active keyconfig only on an exact
# (name, space_type, region_type) match with the built-in keymap.  Verified
# live on this build (5.1.2 ec6e62d40fa9): the dispatching "UV Editor" keymap
# is ('UV Editor', 'EMPTY', 'WINDOW'); creating it with IMAGE_EDITOR yields a
# second, permanently inert keymap.  The "Image Editor Tool: ..." tool maps
# really are ('IMAGE_EDITOR', 'WINDOW').  Resolve the identity from Blender's
# own keymap hierarchy first, with a verified static fallback.
_KEYMAP_SPACE_TYPES = {"UV Editor": "EMPTY"}


def _keymap_space_type(name: str) -> str:
    try:
        from bl_keymap_utils import keymap_hierarchy  # type: ignore

        def _find(items: Any) -> str | None:
            for entry_name, space_type, _region_type, children in items:
                if entry_name == name:
                    return str(space_type)
                found = _find(children)
                if found is not None:
                    return found
            return None

        resolved = _find(keymap_hierarchy.generate())
        if resolved:
            return resolved
    except Exception:
        pass
    return _KEYMAP_SPACE_TYPES.get(name, "IMAGE_EDITOR")


def _named_image_keymap(name: str):
    keyconfig = _keyconfig()
    if keyconfig is None:
        return None
    space_type = _keymap_space_type(name)
    try:
        km = None
        # keymaps.get() returns the first name match regardless of space_type;
        # a stale wrong-typed keymap from an earlier build must not shadow the
        # correctly-typed one, so match the full identity explicitly.
        for candidate in keyconfig.keymaps:
            if (
                getattr(candidate, "name", "") == name
                and getattr(candidate, "space_type", "") == space_type
                and getattr(candidate, "region_type", "") == "WINDOW"
            ):
                km = candidate
                break
        if km is None:
            km = keyconfig.keymaps.new(name=name, space_type=space_type, region_type="WINDOW")
        if bool(getattr(km, "is_modal", False)):
            return None
        return km
    except Exception:
        try:
            return keyconfig.keymaps.get(name)
        except Exception:
            return None


def _uv_keymap():
    return _named_image_keymap("UV Editor")


def _kmi_pointer(kmi: Any) -> int:
    try:
        return int(kmi.as_pointer())
    except Exception:
        return 0


def _configure_keymap_item(kmi: Any, *, ctrl: bool = False, shift: bool = False) -> bool:
    try:
        # Blender 5.1 clears modifiers if any=False is written after modifier
        # properties. Write any first, then explicit modifier bits, then active.
        try:
            kmi.any = False
        except Exception:
            pass
        for name in ("alt", "oskey"):
            try:
                setattr(kmi, name, False)
            except Exception:
                pass
        try:
            kmi.shift = bool(shift)
        except Exception:
            pass
        try:
            kmi.ctrl = bool(ctrl)
        except Exception:
            pass
        try:
            kmi.active = True
        except Exception:
            pass
        return True
    except Exception:
        return False


def _commit_keyconfig(reason: str) -> bool:
    """Publish owned addon-keyconfig rows into the dispatching keyconfig.

    Keymap items created in ``wm.keyconfigs.addon`` remain inert until the
    active keyconfig is rebuilt, so the UV Editor G/R/S rows can be present,
    owned and correctly signed while no key press ever reaches them.  The
    shared implementation in :mod:`uv_gizmo_grip_fix` also carries the
    post-dispatch detach barrier; it is imported lazily to keep module import
    order unchanged.  No RNA handle is retained across this call.
    """
    try:
        from . import uv_gizmo_grip_fix as _gizmo

        return bool(_gizmo._sus_18225_commit_keyconfig(reason))
    except Exception:
        pass
    if bpy is None:
        return False
    try:
        keyconfigs = getattr(getattr(getattr(bpy, "context", None), "window_manager", None), "keyconfigs", None)
        native_update = getattr(keyconfigs, "update", None)
        if not callable(native_update):
            return False
        native_update()
    except Exception:
        return False
    return True


class SU_KeymapTxn:
    """Transactional keymap registration.

    Every row added through this transaction is removed again if any later row
    of the same transaction fails, so no partial owner state survives."""

    def __init__(self, keymap: Any) -> None:
        self.keymap = keymap
        self.created: list[dict[str, Any]] = []
        self.idnames: list[str] = []

    def add(self, idname: str, key_type: str, *, ctrl: bool = False, shift: bool = False, value: str = "PRESS", props: dict[str, Any] | None = None, keymap: Any = None) -> bool:
        target_keymap = keymap if keymap is not None else self.keymap
        native_new = getattr(getattr(target_keymap, "keymap_items", None), "new", None)
        if not callable(native_new):
            return False
        try:
            kmi = native_new(idname, key_type, value)
        except Exception:
            return False
        if kmi is None:
            return False
        _configure_keymap_item(kmi, ctrl=ctrl, shift=shift)
        if props:
            for prop_name, prop_value in props.items():
                try:
                    setattr(kmi.properties, prop_name, prop_value)
                except Exception:
                    pass
        live = _ownership.track_keymap_item(target_keymap, kmi, idname)
        pointer = _kmi_pointer(live)
        if not pointer:
            try:
                _ownership.remove_keymap_item(target_keymap, kmi)
            except Exception:
                pass
            return False
        if idname not in self.idnames:
            self.idnames.append(idname)
        self.created.append({"idname": idname, "type": key_type, "pointer": pointer})
        return True

    def rollback(self) -> int:
        removed = 0
        for idname in self.idnames:
            try:
                removed += int(_ownership.remove_owned_keymaps(idname) or 0)
            except Exception:
                pass
        self.created = []
        self.idnames = []
        return removed


def _remove_owned_keymap_ids(idnames: tuple[str, ...]) -> int:
    removed = 0
    for idname in idnames:
        try:
            removed += int(_ownership.remove_owned_keymaps(idname) or 0)
        except Exception:
            pass
    return removed


def _apply_desired_keymaps(reason: str = "") -> dict[str, Any]:
    """Bring owned keymap rows to the desired state.  Never raises.

    Single-owner invariant: existing SmartUV-owned rows for each idname are
    removed before new rows are created, so exactly one SmartUV owner exists
    for the proportional-cursor and crossing-gesture rows.
    """
    desired_prop = bool(_KEYMAP_DESIRED.get("prop_cursor", False))
    desired_hover = bool(_KEYMAP_DESIRED.get("hover_cursor", True))
    desired_crossing = bool(_KEYMAP_DESIRED.get("crossing", False))

    # Removal side is always available through the ledger.
    removed = 0
    if not desired_prop:
        removed += _remove_owned_keymap_ids((UV_PROP_CURSOR_ID,))
    if not desired_hover:
        removed += _remove_owned_keymap_ids((UV_HOVER_CURSOR_ID,))
    if not desired_crossing:
        removed += _remove_owned_keymap_ids((UV_CROSS_GESTURE_ID,))
    if not (desired_prop or desired_hover or desired_crossing):
        _commit_keyconfig("uv_owner_remove:" + str(reason or ""))
        return {"applied": True, "deferred": False, "created": [], "removed": removed, "reason": str(reason or "")}

    keymap = _uv_keymap()
    if keymap is None:
        return {
            "applied": False,
            "deferred": True,
            "created": [],
            "removed": removed,
            "reason": "keyconfig_unavailable",
        }

    txn = SU_KeymapTxn(keymap)
    ok = True
    if desired_prop:
        _remove_owned_keymap_ids((UV_PROP_CURSOR_ID,))
        for idname, key_type, delta in _UV_PROP_CURSOR_KEYMAPS:
            if not txn.add(idname, key_type, props={"delta": delta}):
                ok = False
                break
    if ok and desired_hover:
        _remove_owned_keymap_ids((UV_HOVER_CURSOR_ID,))
        for idname, key_type in _UV_HOVER_CURSOR_KEYMAPS:
            if not txn.add(idname, key_type):
                ok = False
                break
    if ok and desired_crossing:
        _remove_owned_keymap_ids((UV_CROSS_GESTURE_ID,))
        for idname, key_type, gesture, ctrl in _UV_CROSS_GESTURE_KEYMAPS:
            if not txn.add(idname, key_type, ctrl=ctrl, props={"gesture": gesture}):
                ok = False
                break
        if ok:
            for map_name, gesture in _UV_CROSS_TOOL_MAPS:
                tool_keymap = _named_image_keymap(map_name)
                if tool_keymap is None:
                    ok = False
                    break
                for shift, ctrl in _UV_CROSS_TOOL_MODIFIER_ROWS:
                    if not txn.add(
                        UV_CROSS_GESTURE_ID,
                        "LEFTMOUSE",
                        ctrl=ctrl,
                        shift=shift,
                        props={"gesture": gesture},
                        keymap=tool_keymap,
                    ):
                        ok = False
                        break
                if not ok:
                    break
    if not ok:
        txn.rollback()
        return {
            "applied": False,
            "deferred": True,
            "created": [],
            "removed": removed,
            "reason": "keymap_row_creation_failed",
        }
    published = _commit_keyconfig("uv_owner_apply:" + str(reason or ""))
    return {
        "applied": True,
        "deferred": False,
        "created": list(txn.created),
        "removed": removed,
        "published": bool(published),
        "reason": str(reason or ""),
    }


def _repair_tick() -> float | None:
    """One bounded self-repair attempt.  Returning a float reschedules."""
    _REPAIR_STATE["attempts"] = int(_REPAIR_STATE.get("attempts", 0)) + 1
    result = _apply_desired_keymaps(reason="keyconfig_self_repair")
    if not result.get("deferred"):
        _REPAIR_STATE["handle"] = None
        _REPAIR_STATE["exhausted"] = False
        return None
    if int(_REPAIR_STATE.get("attempts", 0)) >= _REPAIR_MAX_ATTEMPTS:
        _REPAIR_STATE["handle"] = None
        _REPAIR_STATE["exhausted"] = True
        try:
            print("Smart UV keymap registration could not be completed after repeated attempts")
        except Exception:
            pass
        return None
    interval = _REPAIR_FIRST_INTERVAL * (_REPAIR_BACKOFF ** int(_REPAIR_STATE.get("attempts", 0)))
    return min(_REPAIR_MAX_INTERVAL, float(interval))


def su_schedule_keyconfig_repair() -> dict[str, Any]:
    """Queue the bounded delayed self-repair.  Registration is never rolled
    back because a keyconfig is temporarily unavailable."""
    if _REPAIR_STATE.get("handle") is not None:
        return {"scheduled": True, "reason": "already_scheduled"}
    _REPAIR_STATE["attempts"] = 0
    _REPAIR_STATE["exhausted"] = False
    handle = _ownership.register_finite_timer(
        _repair_tick,
        first_interval=_REPAIR_FIRST_INTERVAL,
        max_runs=_REPAIR_MAX_ATTEMPTS,
    )
    _REPAIR_STATE["handle"] = handle
    if handle is None:
        return {"scheduled": False, "reason": "timer_unavailable"}
    return {"scheduled": True, "reason": "keyconfig_unavailable"}


def su_cancel_keyconfig_repair() -> bool:
    handle = _REPAIR_STATE.get("handle")
    _REPAIR_STATE["handle"] = None
    _REPAIR_STATE["attempts"] = 0
    if handle is None:
        return False
    try:
        return bool(_ownership.remove_timer_callback(handle))
    except Exception:
        return False


def _settings_bool(settings: Any, name: str) -> bool:
    try:
        if isinstance(settings, dict):
            return bool(settings.get(name, False))
        return bool(getattr(settings, name, False))
    except Exception:
        return False


def sync_from_settings(settings: Any = None, context: Any = None, reason: str = "") -> dict[str, Any]:
    """Apply the persisted feature toggles.  Never raises: a keyconfig that is
    temporarily unavailable defers to bounded self-repair so the surrounding
    registration transaction cannot be rolled back by a missing keymap."""
    prop_cursor_enabled = _settings_bool(settings, "operation_uv_proportional_cursor_keymap_enabled")
    edges_enabled = _settings_bool(settings, "operation_uv_crossing_select_edges_enabled")
    faces_enabled = _settings_bool(settings, "operation_uv_crossing_select_faces_enabled")
    _KEYMAP_DESIRED["prop_cursor"] = prop_cursor_enabled
    _KEYMAP_DESIRED["hover_cursor"] = True
    _KEYMAP_DESIRED["crossing"] = bool(edges_enabled or faces_enabled)
    try:
        keymaps = _apply_desired_keymaps(reason=str(reason or ""))
    except Exception as exc:  # Defensive: sync must never fail registration.
        keymaps = {"applied": False, "deferred": True, "created": [], "removed": 0, "reason": f"unexpected:{type(exc).__name__}"}
    repair: dict[str, Any] = {"scheduled": False, "reason": "not_needed"}
    if keymaps.get("deferred"):
        repair = su_schedule_keyconfig_repair()
    else:
        su_cancel_keyconfig_repair()
    # 1.8.229: the window-modal crossing watcher was retired; crossing
    # selection is dispatched exclusively through the owned keymap rows above.
    watchers = {"started": 0, "active": 0, "retired": True}
    return {
        "reason": str(reason or ""),
        "uv_proportional_cursor_keymap_enabled": bool(prop_cursor_enabled),
        "cursor_to_hover_vertex_keymap_enabled": True,
        "uv_crossing_select_edges_enabled": bool(edges_enabled),
        "uv_crossing_select_faces_enabled": bool(faces_enabled),
        "keymaps": keymaps,
        "repair": repair,
        "crossing_watchers": watchers,
    }


def _keyconfig_generation() -> int:
    try:
        from . import uv_gizmo_grip_fix as _gizmo

        return int(_gizmo._sus_18225_keyconfig_generation())
    except Exception:
        return 0


def ownership_inventory() -> dict[str, Any]:
    return {
        "smartuv_owned": tuple(_UV_OWNED_IDS),
        "keyconfig_generation": _keyconfig_generation(),
        "smarttransform_scope": "3D View only for SmartTransform; SmartOverlay remains dual-editor.",
        "repair_state": {
            "attempts": int(_REPAIR_STATE.get("attempts", 0)),
            "exhausted": bool(_REPAIR_STATE.get("exhausted", False)),
            "pending": _REPAIR_STATE.get("handle") is not None,
        },
        "keymap_rows": {
            idname: len(_ownership.owned_keymap_items(idname))
            for idname in (UV_PROP_CURSOR_ID, UV_HOVER_CURSOR_ID, UV_CROSS_GESTURE_ID)
        },
    }


def _sweep_legacy_grs_rows() -> int:
    """One-time cleanup of rows pointing at the removed UV Smart G-R-S feature.

    Earlier builds registered these rows in the addon keyconfig and the
    N-panel instructed users to hand-register the three operator ids in
    Preferences.  After the operators were deleted every such row is a dead
    entry that can never dispatch, so it is removed from the ledger and from
    the addon/user keyconfigs.  Never raises."""
    removed = _remove_owned_keymap_ids(_LEGACY_UV_GRS_IDS)
    if bpy is None:
        return removed
    legacy = set(_LEGACY_UV_GRS_IDS)
    try:
        keyconfigs = getattr(getattr(getattr(bpy, "context", None), "window_manager", None), "keyconfigs", None)
        for attr in ("addon", "user"):
            keyconfig = getattr(keyconfigs, attr, None)
            if keyconfig is None:
                continue
            for keymap in getattr(keyconfig, "keymaps", ()):
                try:
                    stale = [kmi for kmi in keymap.keymap_items if getattr(kmi, "idname", "") in legacy]
                    for kmi in stale:
                        keymap.keymap_items.remove(kmi)
                        removed += 1
                except Exception:
                    continue
    except Exception:
        pass
    return removed


def register(package_globals: dict[str, Any] | None = None) -> dict[str, Any]:
    global _REGISTERED, _PACKAGE_GLOBALS
    _PACKAGE_GLOBALS = package_globals
    if _REGISTERED:
        return {"registered": True, "classes": len(_CLASSES)}
    swept = _sweep_legacy_grs_rows()
    for cls in _CLASSES:
        if not _ownership.register_class(cls):
            raise RuntimeError(f"SmartUV UV ownership class registration failed: {getattr(cls, '__name__', cls)}")
    _REGISTERED = True
    return {"registered": True, "classes": len(_CLASSES), "legacy_grs_rows_swept": int(swept)}


def unregister() -> dict[str, Any]:
    global _REGISTERED, _PACKAGE_GLOBALS
    su_cancel_keyconfig_repair()
    removed_keymaps = _remove_owned_keymap_ids(_LEGACY_UV_GRS_IDS + (
        UV_PROP_CURSOR_ID,
        UV_HOVER_CURSOR_ID,
        UV_CROSS_GESTURE_ID,
    ))
    _commit_keyconfig("uv_owner_unregister")
    removed_classes = 0
    for cls in reversed(_CLASSES):
        try:
            if _ownership.unregister_class(cls):
                removed_classes += 1
        except Exception:
            pass
    _REGISTERED = False
    _PACKAGE_GLOBALS = None
    return {"removed_keymaps": removed_keymaps, "removed_classes": removed_classes}
