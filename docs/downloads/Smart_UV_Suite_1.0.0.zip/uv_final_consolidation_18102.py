# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Resolve legacy consolidation entry points against the current UV runtime."""

from . import uv_room_integrity_18103 as _backend

__all__ = tuple(getattr(_backend, "__all__", ()) or (key for key in vars(_backend) if not key.startswith("_")))


def __getattr__(name):
    if name in __all__:
        return getattr(_backend, name)
    raise AttributeError(name)


def __dir__():
    return sorted(set(globals()) | set(__all__))
