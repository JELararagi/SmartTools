# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Compatibility alias for the final Smart UV Suite room integrity backend."""
from .uv_room_integrity_18103 import *  # noqa: F401,F403
