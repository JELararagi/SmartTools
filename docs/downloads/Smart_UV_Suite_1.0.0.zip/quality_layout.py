from __future__ import annotations


def region_width(context) -> int:
    try:
        return int(getattr(getattr(context, 'region', None), 'width', 0) or 0)
    except Exception:
        return 0


def dashboard_columns(context, *, compact: bool = False) -> int:
    width = region_width(context)
    if width <= 0:
        return 1 if compact else 2
    if compact:
        if width < 420:
            return 1
        if width < 860:
            return 2
        return 3
    if width < 540:
        return 1
    if width < 1080:
        return 2
    return 3


def status_columns(context) -> int:
    width = region_width(context)
    if width <= 0:
        return 2
    if width < 460:
        return 1
    if width < 820:
        return 2
    if width < 1240:
        return 3
    if width < 1680:
        return 4
    return 5


def button_columns(context) -> int:
    width = region_width(context)
    if width <= 0:
        return 2
    if width < 520:
        return 1
    if width < 980:
        return 2
    return 3
