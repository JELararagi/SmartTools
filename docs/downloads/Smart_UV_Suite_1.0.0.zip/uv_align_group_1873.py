# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Final UV Direction Align group-connectivity correction.

The grouped vertex-direction actions (G-, G|, G<->, G<-> vertical) must use
selected UV elements as graph edges/faces.  In edge and face modes, vertices
that are merely adjacent through an unselected edge/face must not merge groups.
"""
from __future__ import annotations

_NS = {}


def _round_uv(uv):
    try:
        return (round(float(uv.x), 7), round(float(uv.y), 7))
    except Exception:
        try:
            return (round(float(uv[0]), 7), round(float(uv[1]), 7))
        except Exception:
            return None


def _uv_of(loop, uv_layer):
    try:
        return loop[uv_layer].uv
    except Exception:
        return None


def _uv_key(loop, uv_layer):
    return _round_uv(_uv_of(loop, uv_layer))


def _obj_key(obj):
    fn = _NS.get('_sus_1655_obj_key') or _NS.get('_sus_1653_obj_key')
    if callable(fn):
        try:
            return fn(obj)
        except Exception:
            pass
    try:
        return str(getattr(obj, 'name_full', None) or getattr(obj, 'name', None) or id(obj))
    except Exception:
        return str(id(obj))


def _uv_mode(context):
    fn = _NS.get('_sus_1655_uv_mode')
    if callable(fn):
        try:
            return str(fn(context) or 'VERTEX').upper()
        except Exception:
            pass
    for getter in (
        lambda: getattr(getattr(context, 'tool_settings', None), 'uv_select_mode', None),
        lambda: getattr(getattr(getattr(context, 'scene', None), 'tool_settings', None), 'uv_select_mode', None),
    ):
        try:
            mode = getter()
            if mode:
                return str(mode).upper()
        except Exception:
            pass
    return 'VERTEX'


def _sticky(context):
    fn = _NS.get('_sus_uv_sticky_select_mode')
    if callable(fn):
        try:
            return str(fn(context) or 'DISABLED').upper()
        except Exception:
            pass
    return 'DISABLED'


def _edit_objects(context):
    for name in ('_sus_1676a_edit_objects', '_sus_1674_edit_mesh_objects', '_sus_1658_edit_mesh_objects', '_sus_1660_edit_mesh_objects'):
        fn = _NS.get(name)
        if callable(fn):
            try:
                objs = [o for o in (fn(context) or []) if getattr(o, 'type', '') == 'MESH' and getattr(o, 'mode', '') == 'EDIT']
                if objs:
                    return objs
            except Exception:
                pass
    try:
        objs = [o for o in (getattr(context, 'objects_in_mode_unique_data', None) or []) if getattr(o, 'type', '') == 'MESH' and getattr(o, 'mode', '') == 'EDIT']
        if objs:
            return objs
    except Exception:
        pass
    obj = getattr(context, 'edit_object', None) or getattr(context, 'active_object', None)
    if obj is not None and getattr(obj, 'type', '') == 'MESH' and getattr(obj, 'mode', '') == 'EDIT':
        return [obj]
    return []


def _sync_on(context):
    try:
        return bool(getattr(getattr(context, 'tool_settings', None), 'use_uv_select_sync', False))
    except Exception:
        return False


def _loop_vert_selected(loop, uv_layer, sync=False):
    for getter in (
        lambda: getattr(loop, 'uv_select_vert', False),
        lambda: getattr(loop[uv_layer], 'select', False),
    ):
        try:
            if bool(getter()):
                return True
        except Exception:
            pass
    if sync:
        try:
            return bool(getattr(loop.vert, 'select', False))
        except Exception:
            pass
    return False


def _loop_edge_selected(loop, uv_layer, sync=False):
    for getter in (
        lambda: getattr(loop, 'uv_select_edge', False),
        lambda: getattr(loop[uv_layer], 'select_edge', False),
        lambda: getattr(loop.edge, 'select', False) if sync else False,
    ):
        try:
            if bool(getter()):
                return True
        except Exception:
            pass
    return False


def _face_selected(face, sync=False):
    for getter in (
        lambda: getattr(face, 'uv_select', False),
        lambda: getattr(face, 'select', False) if sync else False,
    ):
        try:
            if bool(getter()):
                return True
        except Exception:
            pass
    return False


def _point_key(rec, sticky, fallback):
    sticky = str(sticky or 'DISABLED').upper()
    if sticky == 'SHARED_LOCATION':
        return ('uv', rec.get('uv_key'))
    if sticky == 'SHARED_VERTEX':
        return ('vert', rec.get('obj_key'), rec.get('vertex_index'))
    return ('loop', rec.get('obj_key'), rec.get('loop_index', fallback))


def _edge_signature_for_face(rec_a, rec_b, sticky):
    """Return selected-face adjacency signature.

    Face groups connect only through a selected face's full UV edge.  With sticky
    modes, use the same logical vertex domain as the rest of UV Align.  In the
    default mode, require the same object edge plus matching UV endpoints, so
    stacked but unrelated faces do not merge merely because they overlap.
    """
    sticky = str(sticky or 'DISABLED').upper()
    if sticky == 'SHARED_LOCATION':
        a = ('uv', rec_a.get('uv_key'))
        b = ('uv', rec_b.get('uv_key'))
    elif sticky == 'SHARED_VERTEX':
        a = ('vert', rec_a.get('obj_key'), rec_a.get('vertex_index'))
        b = ('vert', rec_b.get('obj_key'), rec_b.get('vertex_index'))
    else:
        # Include mesh edge identity when available to avoid merging overlapped
        # but independent islands.  Also include UV endpoints to reject split UVs.
        edge_index = None
        try:
            edge_index = int(getattr(rec_a.get('loop').edge, 'index', -1))
        except Exception:
            edge_index = None
        a = ('uv', rec_a.get('uv_key'))
        b = ('uv', rec_b.get('uv_key'))
        return (rec_a.get('obj_key'), edge_index, tuple(sorted((a, b), key=repr)))
    return tuple(sorted((a, b), key=repr))


def _collect_domain(context, scope='SELECTED'):
    import bmesh
    mode = _uv_mode(context)
    sticky = _sticky(context)
    sync = _sync_on(context)
    scope_all = str(scope or 'SELECTED').upper() == 'ALL'

    records = []
    meshes = []
    # selected edge-mode graph: selected UV edges only.
    selected_edge_loop_pairs = []
    # selected face-mode graph: selected face components only, by shared full edge.
    selected_face_records = {}
    selected_face_edge_sigs = []
    # vertex-mode graph: live visible UV polygon adjacency between selected points.
    visible_pairs = []

    for obj in _edit_objects(context):
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
            uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        except Exception:
            continue
        obj_key = _obj_key(obj)
        meshes.append(obj.data)
        rec_by_loop = {}

        def add_record(loop, face):
            try:
                li = int(getattr(loop, 'index', -1))
                key = (obj_key, li)
                if key in rec_by_loop:
                    return rec_by_loop[key]
                uvk = _uv_key(loop, uv_layer)
                uv = _uv_of(loop, uv_layer)
                u = float(uv.x) if uv is not None else 0.0
                v = float(uv.y) if uv is not None else 0.0
                rec = {
                    'obj': obj, 'obj_key': obj_key, 'mesh': obj.data, 'bm': bm,
                    'uv_layer': uv_layer, 'loop': loop, 'face': face,
                    'loop_index': li, 'face_index': int(getattr(face, 'index', -1)),
                    'vertex_index': int(getattr(loop.vert, 'index', -1)),
                    'uv_key': uvk, 'u': u, 'v': v,
                }
                records.append(rec)
                rec_by_loop[key] = rec
                return rec
            except Exception:
                return None

        try:
            for face in bm.faces:
                if getattr(face, 'hide', False):
                    continue
                loops = list(getattr(face, 'loops', []) or [])
                if not loops:
                    continue
                fsel = bool(scope_all or _face_selected(face, sync))
                face_key = (obj_key, int(getattr(face, 'index', -1)))
                face_recs = []
                for loop in loops:
                    nloop = loop.link_loop_next
                    # Vertex-mode group actions may use visible selected-point adjacency.
                    if mode not in {'EDGE', 'FACE', 'ISLAND'}:
                        if _loop_vert_selected(loop, uv_layer, sync) or scope_all:
                            r0 = add_record(loop, face)
                            # Store visible edge only when both endpoints are selected.
                            if (_loop_vert_selected(nloop, uv_layer, sync) or scope_all):
                                r1 = add_record(nloop, face)
                                if r0 is not None and r1 is not None:
                                    visible_pairs.append((r0, r1))
                        continue

                    if mode == 'EDGE':
                        if scope_all or _loop_edge_selected(loop, uv_layer, sync):
                            r0 = add_record(loop, face)
                            r1 = add_record(nloop, face)
                            if r0 is not None and r1 is not None:
                                selected_edge_loop_pairs.append((r0, r1))
                        continue

                    # FACE / ISLAND mode.
                    if fsel:
                        rec = add_record(loop, face)
                        if rec is not None:
                            face_recs.append(rec)
                if mode in {'FACE', 'ISLAND'} and fsel:
                    # Add all selected face edges.  These connect loops inside a
                    # selected face, and connect selected faces only through a
                    # shared selected full edge.
                    selected_face_records.setdefault(face_key, []).extend(face_recs)
                    for loop in loops:
                        try:
                            r0 = rec_by_loop.get((obj_key, int(getattr(loop, 'index', -1))))
                            r1 = rec_by_loop.get((obj_key, int(getattr(loop.link_loop_next, 'index', -1))))
                            if r0 is not None and r1 is not None:
                                selected_face_edge_sigs.append((face_key, _edge_signature_for_face(r0, r1, sticky)))
                        except Exception:
                            pass
        except Exception:
            continue

    # Convert records into logical points, honoring sticky mode.
    buckets = {}
    order = []
    for i, rec in enumerate(records):
        # In FACE/ISLAND grouped actions, selected face connectivity is the
        # authority.  Do not let sticky same-location/shared-vertex buckets merge
        # two selected face components that only touch at a corner or merely
        # share a vertex without a selected face edge connection.
        if mode in {'FACE', 'ISLAND'}:
            pkey = ('face_loop', rec.get('obj_key'), rec.get('face_index'), rec.get('loop_index', i))
        else:
            pkey = _point_key(rec, sticky, i)
        if pkey not in buckets:
            buckets[pkey] = []
            order.append(pkey)
        buckets[pkey].append(rec)

    points = []
    point_by_key = {}
    rec_to_point = {}
    for pkey in order:
        group = buckets.get(pkey) or []
        if not group:
            continue
        us = [float(r.get('u', 0.0)) for r in group]
        vs = [float(r.get('v', 0.0)) for r in group]
        idx = len(points)
        point_by_key[pkey] = idx
        pt = {'key': pkey, 'records': group, 'u': sum(us) / len(us), 'v': sum(vs) / len(vs)}
        points.append(pt)
        for rec in group:
            rec_to_point[(rec.get('obj_key'), rec.get('loop_index'))] = idx

    def rec_point_index(rec):
        return rec_to_point.get((rec.get('obj_key'), rec.get('loop_index')))

    selected_edge_pairs = []
    for r0, r1 in selected_edge_loop_pairs:
        a = rec_point_index(r0); b = rec_point_index(r1)
        if a is not None and b is not None and a != b:
            selected_edge_pairs.append((a, b))

    visible_point_pairs = []
    for r0, r1 in visible_pairs:
        a = rec_point_index(r0); b = rec_point_index(r1)
        if a is not None and b is not None and a != b:
            visible_point_pairs.append((a, b))

    # Face components: union selected face IDs by shared full selected edge,
    # then collect all points belonging to each connected selected-face island.
    face_ids = list(selected_face_records.keys())
    face_parent = list(range(len(face_ids)))
    face_pos = {fk: i for i, fk in enumerate(face_ids)}

    def ffind(i):
        while face_parent[i] != i:
            face_parent[i] = face_parent[face_parent[i]]
            i = face_parent[i]
        return i

    def funion(a, b):
        if a is None or b is None:
            return
        ra, rb = ffind(a), ffind(b)
        if ra != rb:
            face_parent[rb] = ra

    by_sig = {}
    for face_key, sig in selected_face_edge_sigs:
        if sig is None:
            continue
        by_sig.setdefault(sig, []).append(face_key)
    for faces in by_sig.values():
        if len(faces) > 1:
            base = face_pos.get(faces[0])
            for other in faces[1:]:
                funion(base, face_pos.get(other))

    face_point_groups = []
    if face_ids:
        by_root = {}
        order_roots = []
        for fk in face_ids:
            root = ffind(face_pos[fk])
            if root not in by_root:
                by_root[root] = set(); order_roots.append(root)
            for rec in selected_face_records.get(fk) or []:
                pi = rec_point_index(rec)
                if pi is not None:
                    by_root[root].add(pi)
        for root in order_roots:
            vals = list(by_root.get(root) or [])
            if vals:
                face_point_groups.append(vals)

    return {
        'mode': mode,
        'points': points,
        'selected_edge_pairs': selected_edge_pairs,
        'visible_pairs': visible_point_pairs,
        'face_point_groups': face_point_groups,
        'meshes': meshes,
        'objs': _edit_objects(context),
    }


def _find(parent, i):
    while parent[i] != i:
        parent[i] = parent[parent[i]]
        i = parent[i]
    return i


def _union(parent, a, b):
    try:
        a = int(a); b = int(b)
        if a < 0 or b < 0 or a >= len(parent) or b >= len(parent):
            return
        ra = _find(parent, a); rb = _find(parent, b)
        if ra != rb:
            parent[rb] = ra
    except Exception:
        pass


def _group_points(domain, by_group):
    points = list((domain or {}).get('points') or [])
    if not by_group:
        return [points]
    mode = str((domain or {}).get('mode') or 'VERTEX').upper()
    if mode in {'FACE', 'ISLAND'}:
        groups = []
        used = set()
        for indices in (domain or {}).get('face_point_groups') or []:
            group = []
            for i in indices:
                if 0 <= int(i) < len(points):
                    group.append(points[int(i)])
                    used.add(int(i))
            if group:
                groups.append(group)
        for i, pt in enumerate(points):
            if i not in used:
                groups.append([pt])
        return groups

    parent = list(range(len(points)))
    pairs = (domain or {}).get('selected_edge_pairs') if mode == 'EDGE' else (domain or {}).get('visible_pairs')
    for a, b in pairs or []:
        _union(parent, a, b)
    grouped = {}; order = []
    for i, pt in enumerate(points):
        root = _find(parent, i)
        if root not in grouped:
            grouped[root] = []
            order.append(root)
        grouped[root].append(pt)
    return [grouped[k] for k in order if grouped.get(k)]


def apply_all(ns=None, context=None):
    global _NS
    if ns is not None:
        _NS = ns
    if not _NS:
        return
    try:
        _NS['_sus_1676a_collect_domain'] = _collect_domain
        _NS['_sus_1676a_group_points'] = _group_points
        # Some older late layers still look up these names.
        _NS['_sus_1873_collect_domain'] = _collect_domain
        _NS['_sus_1873_group_points'] = _group_points
        cls = _NS.get('SMARTUVSUITE_OT_vertex_align_action')
        exe = _NS.get('_sus_1676a_vertex_align_execute')
        if isinstance(cls, type) and callable(exe):
            cls.execute = exe
    except Exception:
        pass


def install(ns):
    global _NS
    _NS = ns
    apply_all(ns)


def unregister():
    pass
