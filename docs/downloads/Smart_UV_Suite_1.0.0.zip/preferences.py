# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations
from . import resource_api_18168 as _suv_resource

import importlib
import json
import os
import textwrap
from typing import Any

import bpy
from bpy.app.handlers import persistent
from bpy.props import BoolProperty

from . import text_translation as _text_translation


def _safe_set_operator_props(op, props: dict[str, Any]) -> None:
    try:
        if op is None or not props:
            return
        names: set[str] = set()
        rna_props = getattr(getattr(op, 'bl_rna', None), 'properties', None)
        try:
            names.update(str(k) for k in rna_props.keys())
        except Exception:
            pass
        try:
            for prop in rna_props:
                ident = str(getattr(prop, 'identifier', '') or '')
                if ident:
                    names.add(ident)
        except Exception:
            pass
        for key, value in dict(props).items():
            if str(key) not in names:
                continue
            try:
                setattr(op, str(key), value)
            except Exception:
                pass
    except Exception:
        pass


def _tag_redraw_all() -> None:
    """Refresh visible areas after preference or core-state changes."""
    window_manager = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    if window_manager is None:
        return
    for window in tuple(getattr(window_manager, 'windows', ()) or ()):
        screen = getattr(window, 'screen', None)
        if screen is None:
            continue
        for area in tuple(getattr(screen, 'areas', ()) or ()):
            try:
                area.tag_redraw()
            except Exception:
                continue


INTERNAL_TOOL_META: tuple[dict[str, str], ...] = (
    {
        'alias': 'uv_suite_core',
        'display_en': 'Smart UV',
        'display_ja': 'UV Suite 本体',
        'description_en': 'Main UV Suite host with migrated UV Suite properties, native UV workflow tools, quality layers, reports, and helper systems.',
        'description_ja': 'UV Suite 用に移植された本体ホストです。コアUV機能、品質レイヤー、各種レポート、補助システムを含みます。',
        'usage_en': 'Use this when you need the native UV Suite feature set. Status it before work, then deactivate it after use to stop background handlers and keep Blender lighter.',
        'usage_ja': 'UV Suite 本体機能を使う時に有効化します。作業前に有効化し、終わったら無効化すると、背景ハンドラを止めて Blender を軽く保てます。',
        'foldout': 'show_uv_suite',
        'kind': 'core',
    },
    {
        'alias': 'upgrade',
        'display_en': 'SUV Upgrade',
        'display_ja': 'SUV Upgrade',
        'description_en': 'Internal upgrade layer for readiness checks, planning, playbooks, postflight validation, integrity checks, glossary output, and other guided-report systems.',
        'description_ja': '準備状態確認、実行計画、プレイブック、ポストフライト検証、整合性検査、用語集出力などを担う内部アップグレード層です。',
        'usage_en': 'This module is embedded in UV Suite core. Use the related panels and operators inside the UV Suite N-panel after activating the core. It is shown separately here for overview and tool_runtime management, but it is not duplicated as an independent split add-on to avoid double registration conflicts.',
        'usage_ja': 'このモジュールは UV Suite 本体へ内包されています。本体を有効化した後、UVスイートNパネル内の関連パネルやオペレーターを使ってください。ここでは概要確認とランタイム管理のために個別表示していますが、重複登録競合を避けるため、独立した分離アドオンとしては二重登録していません。',
        'foldout': 'show_upgrade',
        'kind': 'internal',
    },
    {
        'alias': 'data_assets',
        'display_en': 'Data',
        'display_ja': 'Data',
        'description_en': 'Bundled JSON support assets used by compatibility maps, operator requirements, glossary terms, tooltips, parity tables, reports, and workflow references.',
        'description_ja': '互換マップ、オペレーター要件、用語集、ツールチップ、対応表、各種レポート、ワークフロー参照で使う同梱 JSON 支援データ群です。',
        'usage_en': 'No manual activation is needed. These assets are consumed automatically by UV Suite and SUV Upgrade when the relevant tools or reports are used.',
        'usage_ja': '手動の有効化は不要です。関連ツールやレポートを使う時に、UV Suite 本体と SUV Upgrade が自動利用します。',
        'foldout': 'show_data_assets',
        'kind': 'data',
    },
)

INTEGRATED_FOLDOUT_ATTRS: dict[str, str] = {}



def _root_addon_id() -> str:
    text = str(__package__ or '').strip()
    if text:
        return text
    name = str(__name__ or '').strip()
    if '.' in name:
        return name.rsplit('.', 1)[0]
    return name or 'uv_suite'



def _root_package_module():
    return importlib.import_module(_root_addon_id())


def _loader_module():
    return importlib.import_module(f'.loader', __package__)


def _registry_module():
    return importlib.import_module(f'.registry', __package__)



def _wrap_labels(layout, text: str, width: int = 88, icon: str = 'NONE') -> None:
    cleaned = str(text or '').strip()
    if not cleaned:
        return
    lines = textwrap.wrap(cleaned, width=max(28, int(width))) or [cleaned]
    first = True
    for line in lines:
        if first:
            layout.label(text=line, icon=icon)
            first = False
        else:
            layout.label(text=line)



def _is_ja(context=None) -> bool:
    # Preference UI text must not query this AddonPreferences instance while it
    # is being registered. Doing so can recursively evaluate the
    # ui_language_mode EnumProperty items callback and freeze Blender during
    # extension installation. Read only the saved lightweight language mode and
    # Blender's own language setting here.
    mode = 'AUTO'
    try:
        stored = getattr(_text_translation, '_stored_language_mode', None)
        if callable(stored):
            value = str(stored() or '').upper()
            if value in {'FORCE_EN', 'FORCE_JA', 'AUTO'}:
                mode = value
    except Exception:
        mode = 'AUTO'
    if mode == 'FORCE_JA':
        return True
    if mode == 'FORCE_EN':
        return False
    candidates = []
    for obj in (context, getattr(bpy, 'context', None)):
        try:
            view = getattr(getattr(obj, 'preferences', None), 'view', None)
            candidates.append(str(getattr(view, 'language', '') or ''))
        except Exception:
            pass
    try:
        candidates.append(str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or ''))
    except Exception:
        pass
    joined = ' '.join(candidates).upper()
    return any(token in joined for token in ('JA', 'JA_JP', 'JAPANESE', 'JP'))


def _tr(en: str, ja: str, context=None) -> str:
    return str(ja if _is_ja(context) else en)


def _ui_language_mode_items_static() -> tuple[tuple[str, str, str, int], ...]:
    # Static, language-independent enum list.  Do not call _is_ja(), translation
    # helpers, AddonPreferences, or context access here.  Blender 5.1 evaluates
    # AddonPreferences RNA while building enum items, and any recursive language
    # lookup can freeze registration or emit repeated RNA warnings.
    return (
        ('AUTO', 'Auto', 'Follow Blender language automatically.', 0),
        ('FORCE_EN', 'English', 'Always show this add-on in English.', 1),
        ('FORCE_JA', 'Japanese', 'Always show this add-on in Japanese.', 2),
        ('0', 'Auto', 'Legacy saved value; normalized to Auto after load.', 100),
        ('1', 'English', 'Legacy saved value; normalized to English after load.', 101),
        ('2', 'Japanese', 'Legacy saved value; normalized to Japanese after load.', 102),
        ('LEGACY_AUTO', 'Auto', 'Legacy saved value; normalized to Auto after load.', 110),
        ('LEGACY_FORCE_EN', 'English', 'Legacy saved value; normalized to English after load.', 111),
        ('LEGACY_FORCE_JA', 'Japanese', 'Legacy saved value; normalized to Japanese after load.', 112),
    )


_UI_LANGUAGE_MODE_ITEMS_STATIC = _ui_language_mode_items_static()





def _platform_supported(spec: dict[str, Any]) -> bool:
    fn = getattr(_loader_module(), '_platform_supported', None)
    if callable(fn):
        try:
            return bool(fn(str(spec.get('outer_zip') or '')))
        except Exception:
            pass
    return True



def _tool_runtime_is_loaded() -> bool:
    try:
        pkg = _root_package_module()
        tool_runtime_status = getattr(pkg, 'tool_runtime_status', None)
        if callable(tool_runtime_status):
            return str(tool_runtime_status() or '') == 'loaded'
    except Exception:
        pass
    return False



def _core_is_loaded() -> bool:
    try:
        pkg = _root_package_module()
        core_status = getattr(pkg, 'core_status', None)
        if callable(core_status):
            return str(core_status() or '') == 'loaded'
    except Exception:
        pass
    return False



def _tool_runtime_record_map() -> dict[str, dict[str, Any]]:
    if not _tool_runtime_is_loaded():
        return {}
    result: dict[str, dict[str, Any]] = {}
    for record in _loader_module().get_records():
        spec = record.get('spec') or {}
        alias = str(spec.get('alias') or '').strip()
        if alias:
            result[alias] = record
    return result



def _integrated_supported_status(spec: dict[str, Any]) -> str:
    if not bool(spec.get('load', True)):
        return 'disabled'
    if not _platform_supported(spec):
        return 'unsupported_platform'
    return 'standby'



def _status_text(status: str, context=None) -> str:
    status = str(status or '').strip()
    if status == 'loaded':
        return _tr('Loaded', '読み込み済み', context)
    if status == 'loading':
        return _tr('Loading', '読み込み中', context)
    if status == 'standby':
        return _tr('Standby', '待機中', context)
    if status == 'unsupported_platform':
        return _tr('Unsupported platform', '現在の OS・CPU では無効', context)
    if status == 'failed':
        return _tr('Load failed', '読み込み失敗', context)
    if status == 'disabled':
        return _tr('Disabled', '無効', context)
    if status == 'bundled':
        return _tr('Bundled', '同梱済み', context)
    return status or _tr('Unknown', '不明', context)



def _status_icon(status: str) -> str:
    status = str(status or '').strip()
    if status == 'loaded':
        return 'CHECKMARK'
    if status == 'loading':
        return 'TIME'
    if status == 'failed':
        return 'ERROR'
    if status == 'unsupported_platform':
        return 'CANCEL'
    if status == 'disabled':
        return 'HIDE_OFF'
    if status == 'bundled':
        return 'FILE_FOLDER'
    return 'PAUSE'



def _core_status_text() -> str:
    return 'loaded' if _core_is_loaded() else 'standby'



def _tool_record(tool: dict[str, Any], record_map: dict[str, dict[str, Any]]) -> dict[str, Any] | None:
    kind = str(tool.get('kind') or '')
    alias = str(tool.get('alias') or '')
    if kind == 'integrated':
        return record_map.get(alias)
    return None



def _tool_status(tool: dict[str, Any], record_map: dict[str, dict[str, Any]]) -> str:
    kind = str(tool.get('kind') or '')
    alias = str(tool.get('alias') or '')
    if kind == 'core':
        return _core_status_text()
    if kind == 'internal':
        if alias == 'upgrade':
            return _core_status_text()
        return 'standby'
    if kind == 'data':
        return 'bundled'
    record = record_map.get(alias)
    if isinstance(record, dict):
        return str(record.get('status') or _integrated_supported_status(tool))
    return _integrated_supported_status(tool)



def _tool_name(tool: dict[str, Any], context=None) -> str:
    return str(tool.get('display_ja') or tool.get('display_en') or tool.get('display_name') or tool.get('alias') or 'Tool') if _is_ja(context) else str(tool.get('display_en') or tool.get('display_name') or tool.get('display_ja') or tool.get('alias') or 'Tool')



def _tool_description(tool: dict[str, Any], context=None) -> str:
    return str(tool.get('description_ja') or tool.get('description_en') or '') if _is_ja(context) else str(tool.get('description_en') or tool.get('description_ja') or '')



def _tool_usage(tool: dict[str, Any], status: str, context=None) -> str:
    if str(tool.get('kind') or '') in {'core', 'internal', 'data'}:
        return str(tool.get('usage_ja') or tool.get('usage_en') or '') if _is_ja(context) else str(tool.get('usage_en') or tool.get('usage_ja') or '')

    name = _tool_name(tool, context)
    desc = _tool_description(tool, context)
    if _is_ja(context):
        if status == 'loaded':
            if desc:
                return f'機能: {name} を UV Suite Nパネル内へ移植済みです。内容: {desc}。使い方: 下の移植済みUIとコマンドを使ってください。UV Suite が有効な間は常に利用できます。'
            return f'機能: {name} を UV Suite Nパネル内へ移植済みです。使い方: 下の移植済みUIとコマンドを使ってください。UV Suite が有効な間は常に利用できます。'
        if desc:
            return f'機能: {name} を UV Suite Nパネル内へ移植済みです。内容: {desc}。使い方: UV Suite が有効な間は常に利用できます。'
        return f'機能: {name} を UV Suite Nパネル内へ移植済みです。使い方: UV Suite が有効な間は常に利用できます。'
    if status == 'loaded':
        if desc:
            return f'Function: {name} is already migrated into UV Suite. Detail: {desc}. How to use: use the migrated controls below while UV Suite is enabled.'
        return f'Function: {name} is already migrated into UV Suite. How to use: use the migrated controls below while UV Suite is enabled.'
    if desc:
        return f'Function: {name} is a load-on-demand integrated add-on. Detail: {desc}. How to use: activate it only when needed, then disable it after work.'
    return f'Function: {name} is a load-on-demand integrated add-on. How to use: activate it only when needed, then disable it after work.'



def _tool_counts_text(tool: dict[str, Any], record: dict[str, Any] | None, context=None) -> str:
    if not isinstance(record, dict) or str(record.get('status') or '') != 'loaded':
        return _tr('Counts become available after loading this tool.', 'このツールを読み込むと件数が表示されます。', context)
    panels = len(record.get('panels') or [])
    prefs = len(record.get('preferences') or [])
    menus = len(record.get('menus') or [])
    operators = len(record.get('operators') or [])
    return _tr(
        f'Migrated panels: {panels} | Preferences: {prefs} | Menus: {menus} | Operators: {operators}',
        f'移植パネル: {panels} | 設定: {prefs} | メニュー: {menus} | オペレーター: {operators}',
        context,
    )



def _integrated_tools() -> list[dict[str, Any]]:
    tools: list[dict[str, Any]] = []
    for spec in _registry_module().build_specs(force=False):
        alias = str(spec.get('alias') or '').strip()
        if not alias:
            continue
        tool = dict(spec)
        tool['kind'] = 'integrated'
        tool['display_en'] = str(spec.get('display_name') or alias)
        tool['display_ja'] = str(spec.get('display_name') or alias)
        tool['foldout'] = INTEGRATED_FOLDOUT_ATTRS.get(alias, '')
        tools.append(tool)
    return tools



def _all_tools() -> list[dict[str, Any]]:
    return [dict(item) for item in INTERNAL_TOOL_META] + _integrated_tools()



class SMARTUV_OT_preferences_core_activation(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.preferences_core_activation'
    bl_label = 'Activate Core'
    bl_options = {'INTERNAL'}

    enable: bpy.props.BoolProperty(default=True, options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        enable = bool(getattr(properties, 'enable', True))
        if enable:
            return _tr(
                'Load UV Suite core. Use this before working with the native UV Suite feature set and internal SUV Upgrade tools.',
                'UV Suite 本体を読み込みます。コア UV Suite 機能と内部 SUV Upgrade ツールを使う前に実行してください。',
                context,
            )
        return _tr(
            'Unload UV Suite core after use. This stops native handlers and keeps Blender lighter when the core is not needed.',
            'UV Suite 本体を作業後にアンロードします。コアハンドラを停止し、本体が不要な時の Blender 負荷を下げます。',
            context,
        )

    def execute(self, context):
        try:
            pkg = _root_package_module()
        except Exception as exc:
            self.report({'ERROR'}, _tr(f'Package import failed: {exc}', f'パッケージ読込に失敗しました: {exc}', context))
            return {'CANCELLED'}

        action_name = 'activate_core' if self.enable else 'deactivate_core'
        action = getattr(pkg, action_name, None)
        if not callable(action):
            self.report({'ERROR'}, _tr('Core activation API is unavailable', '本体状態 API が見つかりません', context))
            return {'CANCELLED'}

        ok = False
        try:
            ok = bool(action())
        except Exception as exc:
            self.report({'ERROR'}, _tr(f'Core state change failed: {exc}', f'本体状態変更に失敗しました: {exc}', context))
            return {'CANCELLED'}

        try:
            ensure_tool_runtime = getattr(pkg, 'ensure_tool_runtime_loaded', None)
            if callable(ensure_tool_runtime):
                ensure_tool_runtime()
        except Exception:
            pass
        _tag_redraw_all()

        if ok:
            self.report({'INFO'}, _tr('UV Suite core state updated', 'UV Suite 本体の状態を更新しました', context))
            return {'FINISHED'}

        error_text = ''
        try:
            last_error = getattr(pkg, 'core_last_error', None)
            if callable(last_error):
                error_text = str(last_error() or '')
        except Exception:
            error_text = ''
        excerpt = next((line.strip() for line in reversed(error_text.splitlines()) if line.strip()), '')
        self.report({'ERROR'}, _tr(
            f'UV Suite core state change failed ({excerpt or "unknown error"})',
            f'UV Suite 本体の状態変更に失敗しました ({excerpt or "不明なエラー"})',
            context,
        ))
        return {'CANCELLED'}


def _addon_preferences_key_candidates() -> tuple[str, ...]:
    values: list[str] = []

    def _append(candidate: object) -> None:
        text = str(candidate or '').strip().strip('.')
        if not text or text in values:
            return
        values.append(text)
        if text.startswith('bl_ext.'):
            short = text.rsplit('.', 1)[-1]
            if short and short not in values:
                values.append(short)
        elif '.' in text:
            short = text.rsplit('.', 1)[-1]
            if short and short not in values:
                values.append(short)

    _append(_root_addon_id())
    _append(__package__)
    _append(__name__.rpartition('.')[0])
    _append('uv_suite')
    return tuple(values)


_SETTINGS_WM_ATTR = "uv_suite_tool_runtime_settings_v520"
_SETTINGS_JSON_NAME = "Smart_UV_Suite.json"
_SETTINGS_CACHE: dict[str, Any] | None = None
_SETTINGS_APPLIED_KEYS: set[str] = set()
_SETTINGS_HANDLERS_REGISTERED = False
_SETTINGS_AUTOSAVE_INTERVAL = 3.0
_APPLYING_SETTINGS = False


def _settings_package_id() -> str:
    text = str(_root_addon_id() or '').strip().strip('.')
    if text.startswith('bl_ext.'):
        return text.rsplit('.', 1)[-1] or 'uv_suite'
    if '.' in text:
        return text.rsplit('.', 1)[-1] or 'uv_suite'
    return text or 'uv_suite'



def _settings_dir(create: bool = False) -> str:
    try:
        from . import npanel_persistence as _npanel_store
        return str(_npanel_store.state_path(create=create).parent)
    except Exception:
        pass
    try:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            path = user_resource('CONFIG', path='', create=bool(create))
            if path:
                target = os.path.join(str(path), 'Smart_UV_Suite')
                if create:
                    os.makedirs(target, exist_ok=True)
                return str(target)
    except Exception:
        pass
    version = '5.1'
    try:
        app_version = getattr(getattr(bpy, 'app', None), 'version', (5, 1, 0)) or (5, 1, 0)
        version = f"{int(app_version[0])}.{int(app_version[1])}"
    except Exception:
        pass
    appdata = os.environ.get('APPDATA')
    if appdata:
        target = os.path.join(appdata, 'Blender Foundation', 'Blender', version, 'config', 'Smart_UV_Suite')
    else:
        target = os.path.join(os.path.expanduser('~'), '.config', 'blender', version, 'config', 'Smart_UV_Suite')
    if create:
        try:
            os.makedirs(target, exist_ok=True)
        except Exception:
            pass
    return str(target or '')


def _settings_file_path(create: bool = False) -> str:
    try:
        from . import npanel_persistence as _npanel_store
        return str(_npanel_store.state_path(create=create))
    except Exception:
        pass
    root = _settings_dir(create=create)
    if create and root:
        os.makedirs(root, exist_ok=True)
    return os.path.join(root, _SETTINGS_JSON_NAME) if root else _SETTINGS_JSON_NAME


def _legacy_settings_file_path() -> str:
    try:
        package_id = _settings_package_id()
        from . import storage as _storage
        return os.path.join(_storage.extension_user_root(package_id, create=False), 'uv_suite_settings.json')
    except Exception:
        version = '5.1'
        try:
            app_version = getattr(getattr(bpy, 'app', None), 'version', (5, 1, 0)) or (5, 1, 0)
            version = f"{int(app_version[0])}.{int(app_version[1])}"
        except Exception:
            pass
        package_id = _settings_package_id()
        appdata = os.environ.get('APPDATA')
        if appdata:
            root = os.path.join(appdata, 'Blender Foundation', 'Blender', version, 'extensions', 'user_default', package_id)
        else:
            root = os.path.join(os.path.expanduser('~'), '.config', 'blender', version, 'extensions', 'user_default', package_id)
        return os.path.join(root, 'uv_suite_settings.json')


def _load_settings_cache() -> dict[str, Any]:
    global _SETTINGS_CACHE
    if isinstance(_SETTINGS_CACHE, dict):
        return _SETTINGS_CACHE
    data: dict[str, Any] = {}
    try:
        from . import npanel_persistence as _npanel_store
        data = dict(_npanel_store.addon_preferences_items() or {})
    except Exception:
        data = {}
    if not data:
        # Only the separate legacy file may use this compatibility reader.  The
        # canonical Smart_UV_Suite.json is accepted exclusively through the
        # strict duplicate/constant/schema validator in npanel_persistence.
        path = _legacy_settings_file_path()
        try:
            with open(path, 'r', encoding='utf-8') as handle:
                raw = json.load(handle)
            if isinstance(raw, dict):
                if isinstance(raw.get('addon_preferences'), dict):
                    data.update(dict(raw.get('addon_preferences') or {}))
                elif isinstance(raw.get('settings'), dict):
                    data.update(dict(raw.get('settings') or {}))
                else:
                    data.update(dict(raw))
        except Exception:
            pass
    if isinstance(data, dict) and 'ui_language_mode' in data:
        data['ui_language_mode'] = _normalize_language_mode_value(data.get('ui_language_mode'))
    _SETTINGS_CACHE = data
    return _SETTINGS_CACHE


def _write_settings_cache(values: dict[str, Any]) -> None:
    global _SETTINGS_CACHE
    _SETTINGS_CACHE = dict(values or {})
    # One canonical writer only.  Failure leaves the in-memory cache dirty and
    # preserves the existing configuration bytes; no shared ``.tmp`` fallback.
    try:
        from . import npanel_persistence as _npanel_store
        _npanel_store.set_addon_preferences(dict(_SETTINGS_CACHE or {}))
    except Exception:
        return None


def _settings_object(context=None):
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    if wm is None:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    if wm is None:
        return None
    return getattr(wm, _SETTINGS_WM_ATTR, None)



def _iter_persistable_property_names(data_obj, owner_cls=None) -> list[str]:
    names: list[str] = []
    seen: set[str] = set()

    def _append(name: object) -> None:
        text = str(name or '').strip()
        if not text or text in seen:
            return
        if text.startswith('_') or text in {'rna_type', 'bl_idname', 'layout'}:
            return
        seen.add(text)
        names.append(text)

    for source in (getattr(owner_cls, '__annotations__', {}) if owner_cls is not None else {}, getattr(type(data_obj), '__annotations__', {})):
        for name in dict(source or {}).keys():
            _append(name)

    try:
        props = getattr(getattr(data_obj, 'bl_rna', None), 'properties', None)
        if props is not None:
            for name in getattr(props, 'keys', lambda: [])():
                _append(name)
    except Exception:
        pass

    return names



def _json_safe_value(value: Any):
    if isinstance(value, (bool, int, float, str)):
        return value
    return None



def _normalize_language_mode_value(value: Any) -> str:
    text = str(value or '').strip().upper()
    if text in {'AUTO', 'FORCE_EN', 'FORCE_JA'}:
        return text
    # Older broken builds could persist Blender's temporary numeric enum value.
    # Normalize it before assigning to RNA so Blender does not warn that 0/1/2
    # matches no enum item.
    try:
        number = int(value)
    except Exception:
        number = 0
    return {0: 'AUTO', 1: 'FORCE_EN', 2: 'FORCE_JA'}.get(number, 'AUTO')


def _normalize_setting_value(name: str, value: Any) -> Any:
    if str(name or '') == 'ui_language_mode':
        return _normalize_language_mode_value(value)
    return value


def _capture_settings_values(prefs) -> dict[str, Any]:
    values: dict[str, Any] = {}
    if prefs is None:
        return values
    for name in _iter_persistable_property_names(prefs, type(prefs)):
        try:
            value = getattr(prefs, name)
        except Exception:
            continue
        value = _normalize_setting_value(name, value)
        safe_value = _json_safe_value(value)
        if safe_value is None and value is not None:
            continue
        values[name] = safe_value
    return values



def _apply_stored_values_to_object(prefs) -> int:
    global _APPLYING_SETTINGS
    values = dict(_load_settings_cache() or {})
    if prefs is None or not values:
        return 0
    applied = 0
    old_applying = bool(_APPLYING_SETTINGS)
    _APPLYING_SETTINGS = True
    try:
        for name, value in values.items():
            if name in _SETTINGS_APPLIED_KEYS:
                continue
            try:
                getattr(prefs, name)
            except Exception:
                continue
            try:
                value = _normalize_setting_value(name, value)
                setattr(prefs, name, value)
                _SETTINGS_APPLIED_KEYS.add(name)
                applied += 1
            except Exception:
                continue
    finally:
        _APPLYING_SETTINGS = old_applying
    return applied



def apply_stored_settings(context=None, prefs=None) -> int:
    target = prefs if prefs is not None else _settings_object(context)
    return _apply_stored_values_to_object(target)



def save_settings(context=None, prefs=None) -> dict[str, Any]:
    target = prefs if prefs is not None else _settings_object(context)
    stored = dict(_load_settings_cache() or {})
    current = _capture_settings_values(target)
    if current:
        stored.update(current)
        _SETTINGS_APPLIED_KEYS.update(current.keys())
        _write_settings_cache(stored)
    return stored


def flush_settings(context=None, prefs=None) -> dict[str, Any]:
    try:
        return save_settings(context or getattr(bpy, 'context', None), prefs)
    except Exception:
        return dict(_load_settings_cache() or {})


def _settings_autosave_timer():
    # Centralized N-panel persistence now performs periodic flushing when
    # N-panel State Save is enabled.  Keep this function as an unregisterable
    # compatibility target, but do not keep a second background timer alive.
    return None


@persistent
def _settings_load_post_handler(_dummy=None):
    global _SETTINGS_CACHE
    try:
        # This handler changes only Smart UV preference/runtime properties.  It
        # never assigns Object transforms, so copying every Object matrix around
        # it is unnecessary and scales linearly with scene size.
        _SETTINGS_CACHE = None
        _SETTINGS_APPLIED_KEYS.clear()
        cached_values = _load_settings_cache()
        try:
            _text_translation.set_stored_language_mode(
                _normalize_language_mode_value((cached_values or {}).get('ui_language_mode', 'AUTO'))
            )
        except Exception:
            pass
        apply_stored_settings(getattr(bpy, 'context', None))
        flush_settings(getattr(bpy, 'context', None))
        sync_always_on_properties_from_store(getattr(bpy, 'context', None), apply_runtime=False)
    except Exception:
        pass


@persistent
def _settings_save_pre_handler(_dummy=None):
    try:
        flush_settings(getattr(bpy, 'context', None))
    except Exception:
        pass


def _install_settings_handlers() -> None:
    global _SETTINGS_HANDLERS_REGISTERED
    if _SETTINGS_HANDLERS_REGISTERED:
        return
    try:
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        if handlers is not None:
            if _settings_load_post_handler not in handlers.load_post:
                None  # 1.8.169: settings load handler disabled
            if _settings_save_pre_handler not in handlers.save_pre:
                None  # 1.8.169: settings save handler disabled
            _SETTINGS_HANDLERS_REGISTERED = True
        # No independent settings autosave timer is registered.  Settings use
        # npanel_persistence so state-save behavior is controlled by the single
        # N-panel State Save switch.
    except Exception:
        pass



def _remove_settings_handlers() -> None:
    global _SETTINGS_HANDLERS_REGISTERED
    _suv_resource.timer_unregister(_settings_autosave_timer)
    try:
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        if handlers is not None:
            _suv_resource.handler_remove(handlers.load_post, _settings_load_post_handler)
            _suv_resource.handler_remove(handlers.save_pre, _settings_save_pre_handler)
    except Exception:
        pass
    _SETTINGS_HANDLERS_REGISTERED = False



_LANGUAGE_MODE_UPDATE_NORMALIZING = False


def _settings_update(self, context) -> None:
    global _LANGUAGE_MODE_UPDATE_NORMALIZING
    if bool(globals().get('_APPLYING_SETTINGS', False)):
        return None
    if not _LANGUAGE_MODE_UPDATE_NORMALIZING:
        try:
            current = getattr(self, 'ui_language_mode', 'AUTO')
            normalized = _normalize_language_mode_value(current)
            if str(current) != normalized:
                _LANGUAGE_MODE_UPDATE_NORMALIZING = True
                try:
                    setattr(self, 'ui_language_mode', normalized)
                finally:
                    _LANGUAGE_MODE_UPDATE_NORMALIZING = False
        except Exception:
            _LANGUAGE_MODE_UPDATE_NORMALIZING = False
    try:
        save_settings(context, self)
    except Exception:
        pass
    try:
        _text_translation.request_locale_refresh(
            context,
            mode=_normalize_language_mode_value(getattr(self, 'ui_language_mode', 'AUTO')),
        )
    except Exception:
        pass
    try:
        _tag_redraw_all()
    except Exception:
        pass



def _legacy_migration_class():
    annotations = dict(getattr(SMARTUV_AddonPreferences, '__annotations__', {}) or {})
    try:
        root_module = _root_package_module()
        build_features = getattr(root_module, '_stx_build_features', None)
        if callable(build_features):
            for feature in tuple(build_features(getattr(bpy, 'context', None)) or ()):
                prop = str((feature or {}).get('prop') or '').strip()
                if not prop or prop in annotations:
                    continue
                annotations[prop] = bpy.props.BoolProperty(
                    name=prop,
                    default=bool((feature or {}).get('default', True)),
                )
    except Exception:
        pass

    def _draw(self, _context):
        return None

    attrs: dict[str, Any] = {
        '__module__': __name__,
        '__annotations__': annotations,
        'bl_idname': _root_addon_id(),
        'bl_label': 'UV Settings Migration',
        'draw': _draw,
    }
    return type('SMARTUV_AddonPreferencesMigrationV520', (bpy.types.AddonPreferences,), attrs)



def _migrate_legacy_addon_preferences(context=None) -> bool:
    # Standard N-panel build: do not register or read AddonPreferences.
    # Settings are persisted through the WindowManager holder and JSON cache.
    return False



def runtime_preferences(context=None):
    """Return the live WindowManager settings holder without applying state.

    This accessor is safe for Panel.draw(): registration and load handlers own
    all JSON reads and state restoration, so a redraw never reaches file I/O or
    RNA assignment through the preference path.
    """
    return _settings_object(context)


def addon_preferences(context=None):
    """Compatibility accessor that also performs one-time state restoration.

    Lifecycle and explicit settings code may use this function.  UI draw code
    must use runtime_preferences() so redraw remains read-only.
    """
    prefs = _settings_object(context)
    if prefs is not None:
        try:
            _apply_stored_values_to_object(prefs)
        except Exception:
            pass
    return prefs


def draw_smart_tools_global_settings(layout, context, prefs=None) -> int:
    prefs = prefs if prefs is not None else addon_preferences(context)
    if layout is None:
        return 0

    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass

    if prefs is None:
        box = layout.box()
        box.alert = True
        box.label(text=_tr('Add-on settings could not be loaded.', 'アドオン設定を読み込めませんでした。', context), icon='ERROR')
        _wrap_labels(
            box,
            _tr(
                'Re-enable the add-on, then open the UV Suite N-panel again. The UV Suite settings holder is prepared during add-on startup, so the values cannot be edited until that tool_runtime object is available.',
                'アドオンを再有効化してから UVスイートNパネルを開き直してください。UV Suite の設定保持オブジェクトは起動時に準備されるため、そのランタイムが利用可能になるまでは編集できません。',
                context,
            ),
            width=86,
        )
        return 0

    intro_box = layout.box()
    intro_box.label(text=_tr('Add-on Settings', 'アドオン設定', context), icon='PREFERENCES')

    language_box = layout.box()
    language_box.label(text=_tr('Interface', 'インターフェース', context), icon='WORLD')
    language_box.prop(prefs, 'ui_language_mode', text=_tr('UI Language', '表示言語', context))

    feature_box = layout.box()
    feature_box.label(text=_tr('Feature Families', '機能ファミリー', context), icon='TOOL_SETTINGS')
    row = feature_box.row(align=True)
    row.prop(prefs, 'enable_pro_tools', text=_tr('Enable Pro Tools', 'Proツールを有効化', context))
    row.prop(prefs, 'enable_sets_tools', text=_tr('Enable Selection and Sets', '選択・セットを有効化', context))
    row = feature_box.row(align=True)
    row.prop(prefs, 'enable_symmetry_tools', text=_tr('Enable Symmetry Tools', '対称ツールを有効化', context))
    row.prop(prefs, 'enable_atlas_tools', text=_tr('Enable Atlas and Material Tools', 'アトラス・マテリアル系を有効化', context))

    diagnostics_box = layout.box()
    pass  # INFO-note moved to Help; no in-section info-icon explanation.
    diagnostics_box.prop(prefs, 'debug_log', text=_tr('Debug Log', 'デバッグログ', context))

    tool_runtime_box = layout.box()
    tool_runtime_box.label(text=_tr('Runtime Controls', 'ランタイム管理', context), icon='PLUGIN')
    _wrap_labels(
        tool_runtime_box,
        _tr(
            'Core activation, integrated add-on activation, and migration status are also available in the UV Suite panels below, so the old Add-on Preferences property list is no longer required.',
            '本体の状態、統合アドオンの状態、移植状態の確認も、この下の UV Suite パネルへ統合されています。旧アドオンプリファレンス側の項目一覧は不要です。',
            context,
        ),
        width=88,
        icon='QUESTION',
    )
    return 1


class SMARTUV_AddonPreferences(bpy.types.PropertyGroup):
    bl_label = _tr('UV Settings', 'UV設定')
    bl_description = _tr(
        'UV Suite global settings stored for the UV Suite N-panel.',
        'UVスイートNパネル用に保持される UV Suite 全体設定です。',
    )

    show_uv_suite: BoolProperty(name='Smart UV', default=False, update=_settings_update)
    show_upgrade: BoolProperty(name='SUV Upgrade', default=False, update=_settings_update)
    show_data_assets: BoolProperty(name='Data', default=False, update=_settings_update)

    ui_language_mode: bpy.props.EnumProperty(
        name=_tr('UI Language', '表示言語'),
        description=_tr(
            'Choose whether UV Suite follows Blender language automatically or forces a language for this add-on.',
            'UV Suite の表示言語を Blender の設定に合わせるか、このアドオンだけ固定するか選びます。',
        ),
        items=_UI_LANGUAGE_MODE_ITEMS_STATIC,
        default='AUTO',
        update=_settings_update,
    )
    show_in_uv_editor: BoolProperty(
        name=_tr('Legacy UV Editor Sidebar', '旧UVエディターサイドバー'),
        description=_tr(
            'Legacy compatibility value kept so older setting files can still be read. UV Suite now uses the standard 3D View N-panel.',
            '旧設定ファイルを読めるように残している互換値です。現在のUV Suiteは標準の3DビューNパネルを使用します。',
        ),
        default=False,
        update=_settings_update,
    )
    show_in_3d_view: BoolProperty(
        name=_tr('Legacy 3D View Sidebar', '旧3Dビューサイドバー'),
        description=_tr(
            'Legacy compatibility value kept so older setting files can still be read. UV Suite now uses the standard 3D View N-panel.',
            '旧設定ファイルを読めるように残している互換値です。現在のUV Suiteは標準の3DビューNパネルを使用します。',
        ),
        default=False,
        update=_settings_update,
    )
    enable_pro_tools: BoolProperty(
        name=_tr('Enable Pro Tools', 'Proツールを有効化'),
        description=_tr(
            'Enable advanced unwrap, packing, density, audit, and inspection tool families.',
            '高度な展開、パック、密度、監査、検査系のツール群を有効化します。',
        ),
        default=True,
        update=_settings_update,
    )
    enable_sets_tools: BoolProperty(
        name=_tr('Enable Selection and Sets', '選択・セットを有効化'),
        description=_tr(
            'Enable saved selections, reusable UV sets, and related helper tools.',
            '保存選択、再利用できる UV セット、その関連補助ツールを有効化します。',
        ),
        default=True,
        update=_settings_update,
    )
    enable_symmetry_tools: BoolProperty(
        name=_tr('Enable Symmetry Tools', '対称ツールを有効化'),
        description=_tr(
            'Enable symmetry detection, mirroring, and pair-based UV helpers.',
            '対称検出、ミラー、ペア補助を有効化します。',
        ),
        default=True,
        update=_settings_update,
    )
    enable_atlas_tools: BoolProperty(
        name=_tr('Enable Atlas and Material Tools', 'アトラス・マテリアル系を有効化'),
        description=_tr(
            'Enable atlas layout, shared material setup, and texture-set helper tools.',
            'アトラス配置、共有マテリアル設定、テクスチャセット補助を有効化します。',
        ),
        default=True,
        update=_settings_update,
    )
    debug_log: BoolProperty(
        name=_tr('Debug Log', 'デバッグログ'),
        description=_tr(
            "Write additional UV Suite debug messages to Blender's console for troubleshooting.",
            '問題解析用に UV Suite の追加デバッグ情報を Blender のコンソールへ出力します。',
        ),
        default=False,
        update=_settings_update,
    )

    def _draw_tool_card(self, layout, tool: dict[str, Any], record_map: dict[str, dict[str, Any]], context) -> None:
        kind = str(tool.get('kind') or '')
        alias = str(tool.get('alias') or '')
        status = _tool_status(tool, record_map)
        record = _tool_record(tool, record_map)
        fold_attr = str(tool.get('foldout') or '')
        is_open = bool(getattr(self, fold_attr)) if fold_attr else True
        name = _tool_name(tool, context)
        section = layout.column(align=True)
        header_box = section.box()
        header = header_box.row(align=True)
        from .foldout_header import draw_foldout_header
        draw_foldout_header(
            header, is_open, title=name, icon='PLUGIN', single=True,
            data=self if fold_attr else None, prop=fold_attr or None)
        header.label(text=_status_text(status, context), icon=_status_icon(status))

        if kind == 'integrated':
            header.label(text=_tr('Always Active', '常時有効', context), icon='CHECKMARK')
        elif kind in {'core', 'internal'}:
            op = header.operator(
                'smart_uv_suite.preferences_core_activation',
                text=_tr('Deactivate Core', '本体を無効化', context) if _core_is_loaded() else _tr('Activate Core', '本体を有効化', context),
                icon='CHECKMARK' if _core_is_loaded() else 'PLAY',
            )
            _safe_set_operator_props(op, {'enable': not _core_is_loaded()})
        else:
            header.label(text=_tr('Auto-managed', '自動管理', context), icon='FILE_FOLDER')

        if not is_open:
            return

        summary_box = section.box()
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        _wrap_labels(summary_box, _tool_description(tool, context), width=88)

        usage_box = section.box()
        usage_box.label(text=_tr('How to use', '使い方', context), icon='QUESTION')
        _wrap_labels(usage_box, _tool_usage(tool, status, context), width=88)

        if kind in {'integrated'}:
            counts_box = section.box()
            counts_box.label(text=_tr('Runtime migration state', 'ランタイム移植状態', context), icon='OUTLINER')
            _wrap_labels(counts_box, _tool_counts_text(tool, record, context), width=88)
            if status == 'failed':
                error_text = str((record or {}).get('error') or '').strip()
                if error_text:
                    err_box = section.box()
                    err_box.alert = True
                    err_box.label(text=_tr('Load error', '読み込みエラー', context), icon='ERROR')
                    _wrap_labels(err_box, error_text.splitlines()[-1], width=86)

    def draw(self, context):
        _ = context
        return


# -----------------------------------------------------------------------------
# N-panel Always-on toggle properties
# -----------------------------------------------------------------------------
_ALWAYS_ON_PROP_PREFIX = 'always_on_'
_ALWAYS_ON_SYNCING = False
_ALWAYS_ON_PROPS_INSTALLED = False


def always_on_property_name(feature_id: object) -> str:
    raw = str(feature_id or '').strip().lower()
    safe = ''.join(ch if ch.isalnum() else '_' for ch in raw).strip('_')
    while '__' in safe:
        safe = safe.replace('__', '_')
    return _ALWAYS_ON_PROP_PREFIX + (safe or 'feature')


def _always_on_root_module():
    try:
        return _root_package_module()
    except Exception:
        return None


def _always_on_features() -> tuple[dict[str, Any], ...]:
    root = _always_on_root_module()
    try:
        features = tuple(getattr(root, '_ALWAYS_ON_FEATURES', ()) or ()) if root is not None else ()
        return tuple(dict(item) for item in features if isinstance(item, dict))
    except Exception:
        return ()


def _always_on_store_get(feature_id: str, default: bool = False) -> bool:
    try:
        from . import npanel_persistence as _npanel_store
        return bool(_npanel_store.peek_always_on(str(feature_id or ''), bool(default)))
    except Exception:
        return bool(default)


def _always_on_store_has(feature_id: str) -> bool:
    try:
        from . import npanel_persistence as _npanel_store
        has = getattr(_npanel_store, 'peek_has_always_on', None)
        return bool(has(str(feature_id or ''))) if callable(has) else False
    except Exception:
        return False


def _always_on_store_set(feature_id: str, value: bool) -> None:
    try:
        from . import npanel_persistence as _npanel_store
        _npanel_store.set_always_on(str(feature_id or ''), bool(value))
    except Exception:
        pass


def _make_always_on_update(feature_id: str):
    fid = str(feature_id or '').strip().upper()
    prop_name = always_on_property_name(fid)

    def _snapshot_uv_sidebar_state(ctx):
        area = getattr(ctx, 'area', None)
        if area is None:
            return ()
        try:
            area_type = str(getattr(area, 'type', '') or '')
            area_ui_type = str(getattr(area, 'ui_type', '') or '')
            space = getattr(getattr(area, 'spaces', None), 'active', None)
            space_mode = str(getattr(space, 'mode', '') or '')
            show_region_ui = bool(getattr(space, 'show_region_ui'))
        except Exception:
            return ()
        if area_type != 'IMAGE_EDITOR' or area_ui_type != 'UV' or space_mode != 'UV' or not show_region_ui:
            return ()
        return ((area, space),)

    def _restore_uv_sidebar_state(snapshot):
        restored = 0
        for area, space in snapshot:
            try:
                if bool(getattr(space, 'show_region_ui')):
                    continue
                setattr(space, 'show_region_ui', True)
                restored += 1
            except Exception:
                continue
            try:
                area.tag_redraw()
            except Exception:
                pass
        return restored

    def _update(self, context):
        global _ALWAYS_ON_SYNCING
        # Registration/load replay sets every cached property in deterministic
        # order.  Always-on callbacks must stay completely silent during that
        # replay: saving the partly-materialized WindowManager holder would
        # capture later properties at their RNA defaults and mark them as
        # already applied.  In particular this used to replace the saved
        # ``show_always_on_toggles=True`` foldout with ``False`` at startup.
        if _ALWAYS_ON_SYNCING or bool(globals().get('_APPLYING_SETTINGS', False)):
            return None
        uv_sidebar_snapshot = _snapshot_uv_sidebar_state(context)
        try:
            desired = bool(getattr(self, prop_name))
        except Exception:
            desired = False
        _always_on_store_set(fid, desired)
        root = _always_on_root_module()
        try:
            setter = getattr(root, '_sus_set_always_on_feature', None) if root is not None else None
            if callable(setter):
                _ok, actual, _message = setter(fid, context, desired=desired)
                actual = bool(actual)
                if actual != desired:
                    try:
                        _ALWAYS_ON_SYNCING = True
                        setattr(self, prop_name, actual)
                    finally:
                        _ALWAYS_ON_SYNCING = False
        except Exception:
            pass
        try:
            _tag_redraw_all()
        except Exception:
            pass
        try:
            _restore_uv_sidebar_state(uv_sidebar_snapshot)
        except Exception:
            pass
        return None

    return _update


def _npanel_state_save_update(self, context):
    """Synchronize the shared persistence policy from its direct RNA control."""
    if bool(globals().get('_APPLYING_SETTINGS', False)) or _ALWAYS_ON_SYNCING:
        return None
    try:
        from . import npanel_persistence as _npanel_store
        _npanel_store.set_state_save_enabled(
            bool(getattr(self, 'npanel_state_save', True)),
            context=context,
            prefs=self,
        )
    except Exception:
        pass
    try:
        from . import smartuv_operation_runtime_18228 as _runtime
        _runtime._arm_persistence_timer(0.35)
    except Exception:
        pass
    try:
        _tag_redraw_all()
    except Exception:
        pass
    return None


def install_always_on_properties() -> None:
    """Install real BoolProperties used by the top N-panel Always-on group."""
    global _ALWAYS_ON_PROPS_INSTALLED
    annotations = dict(getattr(SMARTUV_AddonPreferences, '__annotations__', {}) or {})
    if 'npanel_state_save' not in annotations:
        annotations['npanel_state_save'] = bpy.props.BoolProperty(
            name=_tr('N-panel State Save', 'Nパネル状態保存'),
            description=_tr(
                'Save every Smart UV N-panel setting to Smart_UV_Suite/Smart_UV_Suite.json on change and restore it after Blender restarts or scene changes. Turning saving OFF writes that switch once, then blocks force, direct, and shutdown writes. Turning it ON commits one current snapshot.',
                'Smart UV Nパネルの全設定を変更時に Smart_UV_Suite/Smart_UV_Suite.json へ保存し、Blender再起動・シーン変更後に復元します。無効化操作自身だけを1回保存し、無効中はforce・直接保存・終了処理を含む全書き込みを停止します。再び有効にすると最新状態を一括保存します。',
            ),
            default=True,
            update=_npanel_state_save_update,
        )
    if 'show_always_on_toggles' not in annotations:
        annotations['show_always_on_toggles'] = bpy.props.BoolProperty(
            name=_tr('Always-on Toggles Group Open', '常時機能切り替えグループを開く'),
            description=_tr(
                'Open or close the clock-marked Always-on Toggles group at the top of the UV Suite N-panel. These toggles control only features that need persistent handlers, watchers, live overlays, modal helpers, or Blender live-state switches.',
                'UVスイートNパネル最上部の時計アイコン付き「常時機能切り替え」グループを開閉します。ここには、常駐ハンドラー、監視、ライブオーバーレイ、モーダル補助、Blenderライブ状態の切り替えが必要な機能だけを集約しています。',
            ),
            default=False,
            update=_settings_update,
        )
    for feature in _always_on_features():
        fid = str(feature.get('id') or '').strip().upper()
        if not fid:
            continue
        prop = always_on_property_name(fid)
        if prop in annotations:
            continue
        annotations[prop] = bpy.props.BoolProperty(
            name=str(feature.get('label_en') or fid),
            description=_tr(str(feature.get('desc_en') or ''), str(feature.get('desc_ja') or ''), None),
            default=False,
            update=_make_always_on_update(fid),
        )
    SMARTUV_AddonPreferences.__annotations__ = annotations
    _ALWAYS_ON_PROPS_INSTALLED = True


def sync_always_on_properties_from_store(context=None, prefs=None, *, apply_runtime: bool = False) -> int:
    global _ALWAYS_ON_SYNCING
    target = prefs if prefs is not None else _settings_object(context)
    if target is None:
        return 0
    settings = dict(_load_settings_cache() or {})
    changed = 0
    root = _always_on_root_module()
    setter = getattr(root, '_sus_set_always_on_feature', None) if root is not None else None
    try:
        _ALWAYS_ON_SYNCING = True
        if hasattr(target, 'npanel_state_save'):
            desired_state_save = True
            try:
                from . import npanel_persistence as _npanel_store
                desired_state_save = bool(_npanel_store.get_state_save_enabled(True))
            except Exception:
                pass
            try:
                if bool(getattr(target, 'npanel_state_save')) != desired_state_save:
                    setattr(target, 'npanel_state_save', desired_state_save)
                    changed += 1
            except Exception:
                pass
        for feature in _always_on_features():
            fid = str(feature.get('id') or '').strip().upper()
            if not fid:
                continue
            prop = always_on_property_name(fid)
            if not hasattr(target, prop):
                continue
            desired = _always_on_store_get(fid, bool(settings.get(prop, False))) if _always_on_store_has(fid) else bool(settings.get(prop)) if prop in settings else False
            try:
                current = bool(getattr(target, prop))
            except Exception:
                current = False
            if current != desired:
                try:
                    setattr(target, prop, desired)
                    changed += 1
                except Exception:
                    pass
            _always_on_store_set(fid, desired)
            if apply_runtime and callable(setter):
                try:
                    setter(fid, context, desired=desired)
                except Exception:
                    pass
    finally:
        _ALWAYS_ON_SYNCING = False
    try:
        save_settings(context, target)
    except Exception:
        pass
    return changed


classes = (
    SMARTUV_OT_preferences_core_activation,
    SMARTUV_AddonPreferences,
)



def _rna_class_ready(cls: type) -> bool:
    try:
        rna = getattr(cls, 'bl_rna', None)
        identifier = str(getattr(rna, 'identifier', '') or '')
        return bool(identifier) and identifier not in {'Operator', 'OperatorProperties', 'UnknownType', 'bpy_struct'}
    except Exception:
        return False


def _safe_register_preferences_class(cls: type) -> bool:
    """Register only the exact class through the Smart UV ownership ledger."""
    try:
        return bool(_suv_resource.register_class(cls))
    except Exception:
        return False


def _safe_unregister_preferences_class(cls: type) -> None:
    try:
        _suv_resource.unregister_class(cls)
    except Exception:
        pass

def register() -> None:
    # Read persisted settings once at the lifecycle boundary before any class
    # text is localized.  Draw code subsequently reads only the live holder.
    try:
        cached_values = _load_settings_cache()
        _text_translation.set_stored_language_mode(
            _normalize_language_mode_value((cached_values or {}).get('ui_language_mode', 'AUTO'))
        )
    except Exception:
        pass
    try:
        install_always_on_properties()
    except Exception:
        pass
    for cls in classes:
        try:
            _text_translation.sanitize_class(cls, context=getattr(bpy, 'context', None))
        except Exception:
            pass
        _safe_register_preferences_class(cls)
    if _rna_class_ready(SMARTUV_AddonPreferences):
        try:
            _suv_resource.register_property(
                bpy.types.WindowManager,
                _SETTINGS_WM_ATTR,
                bpy.props.PointerProperty(type=SMARTUV_AddonPreferences),
            )
        except Exception:
            pass
    _load_settings_cache()
    # Standard N-panel build: restore cached preference values after the
    # lightweight WindowManager holder exists.  The cache application is guarded
    # by _APPLYING_SETTINGS so update callbacks do not recursively write files
    # while Blender is enabling the extension.
    try:
        apply_stored_settings(getattr(bpy, 'context', None))
    except Exception:
        pass
    try:
        sync_always_on_properties_from_store(getattr(bpy, 'context', None), apply_runtime=False)
    except Exception:
        pass
    # Legacy AddonPreferences migration classes are intentionally not registered
    # during install.  This keeps enable-time registration small and avoids
    # conflicts with old SmartTools preference hosts.



def unregister() -> None:
    # Cleanup-only boundary: shutdown WindowManager values may already be
    # defaults and must not replace the canonical common-section state.
    try:
        _remove_settings_handlers()
    except Exception:
        pass
    try:
        _suv_resource.unregister_property(bpy.types.WindowManager, _SETTINGS_WM_ATTR)
    except Exception:
        pass
    for cls in reversed(classes):
        _safe_unregister_preferences_class(cls)
