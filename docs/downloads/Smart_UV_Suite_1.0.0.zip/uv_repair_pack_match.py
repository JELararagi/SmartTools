"""Public pack_match_active_preserve routing."""

import bpy


def run(context, op):
    return "FINISHED" in bpy.ops.uv.suv_match_active_preserve(mode=(op.mode or "AUTO").upper())


def build_handlers(api):
    return {"smart_uv_suite.pack_match_active_preserve": api.Handler(run, 'Match the active island shape while keeping each target center, tile, and area.', '対象の中心・タイル・面積を保ったままアクティブ島の形状に合わせます。')}
