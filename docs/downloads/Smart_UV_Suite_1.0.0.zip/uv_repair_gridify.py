"""Snap selected UVs to the UV Editor grid."""

import bpy


def run(context, op):
    return "FINISHED" in bpy.ops.smart_uv_suite.consolidated_snap_uv(
        mode="GRID", axis=(op.axis or "BOTH").upper())


def build_handlers(api):
    return {"smart_uv_suite.gridify": api.Handler(
        run, "Snap selected UVs to the nearest visible grid intersections.",
        "選択UVを表示中のグリッドの最寄りの交点へスナップします。")}
