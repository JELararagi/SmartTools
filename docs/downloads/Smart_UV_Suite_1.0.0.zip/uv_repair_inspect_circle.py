"""Implement the inspect circle public UV operations."""

import bpy


def inspect_circle(context, op):
    return 'FINISHED' in bpy.ops.suv.boundary_to_shape(mode='CIRCLE')


def build_handlers(api):
    return {

        "smart_uv_suite.inspect_circle": api.Handler(inspect_circle, 'Fit each selected UV boundary to a circle.', '選択したUV境界を円に整形します。'),

    }
