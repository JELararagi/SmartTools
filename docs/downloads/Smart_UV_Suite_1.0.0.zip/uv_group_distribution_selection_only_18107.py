# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Smart UV Suite 1.8.107 selected-only grouped vertex alignment.

Final runtime layer for Direction Align (Vertex) grouped operations.

G↔ / G↕ distribute selected element groups by each group's side-extreme
midpoint.  The group is moved rigidly and no unselected UV loop is added as a
sticky follower.  Grouped center-line alignment (G— / G|) uses the same
selected-only record source so unselected UV elements cannot be modified by a
grouped vertex alignment action.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence, Set

import bpy

from . import uv_room_integrity_18103 as ri
from . import uv_multi_object_18104 as mo
from . import uv_loop_group_distribute_18105 as lg

_VERSION = (1, 8, 107)
_GROUP_ACTIONS = {"ALIGN_H_GROUP", "ALIGN_V_GROUP", "DISTRIBUTE_H_GROUP", "DISTRIBUTE_V_GROUP"}
_DISTRIBUTE_GROUP_ACTIONS = {"DISTRIBUTE_H_GROUP", "DISTRIBUTE_V_GROUP"}
_NS: Dict[str, Any] = {}
_PREV: Dict[str, Any] = {}
_EPS = 1.0e-12


def _s(value: Any) -> str:
    try:
        return str(value or "")
    except Exception:
        return ""


def _tr(context: Any, en: str, ja: str) -> str:
    return ri._tr(context, en, ja)


def _report(op: Any, level: str, message: str) -> None:
    try:
        op.report({level}, message)
    except Exception:
        pass


def _hidden(elem: Any) -> bool:
    try:
        return bool(getattr(elem, "hide", False))
    except Exception:
        return False


def _unique_records(records: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Return selected source records once per BMesh loop.

    Earlier compatibility paths can provide the same loop twice for edge/face
    selection.  Moving such duplicates twice would shift selected groups by an
    incorrect amount and can look like unrelated elements moved.
    """
    out: List[Dict[str, Any]] = []
    seen: Set[int] = set()
    for rec in list(records or []):
        try:
            loop = rec.get("loop")
            uv_layer = rec.get("uv_layer")
            if loop is None or uv_layer is None:
                continue
            if _hidden(loop) or _hidden(getattr(loop, "face", None)):
                continue
            key = id(loop)
            if key in seen:
                continue
            seen.add(key)
            out.append(rec)
        except Exception:
            pass
    return out


def _record_value(rec: Dict[str, Any], axis_u: bool) -> float:
    try:
        loop = rec.get("loop")
        uv_layer = rec.get("uv_layer")
        uv = loop[uv_layer].uv
        return float(uv.x if axis_u else uv.y)
    except Exception:
        key = "u" if axis_u else "v"
        try:
            return float(rec.get(key, 0.0))
        except Exception:
            return 0.0


def _group_midpoint(records: Sequence[Dict[str, Any]], axis_u: bool) -> Optional[float]:
    vals = [_record_value(rec, axis_u) for rec in _unique_records(records)]
    if not vals:
        return None
    return (min(vals) + max(vals)) * 0.5


def _selected_points(records: Sequence[Dict[str, Any]], sticky: str) -> List[Dict[str, Any]]:
    """Create point buckets from selected records only.

    Sticky mode is used only to coalesce equivalent endpoints that are already
    selected.  This function deliberately does not append same-position/shared-
    vertex followers, because G↔ / G↕ must not modify unselected UV elements.
    """
    sticky = _s(sticky).upper()
    buckets: Dict[Any, List[Dict[str, Any]]] = {}
    order: List[Any] = []
    for rec in _unique_records(records):
        try:
            loop = rec.get("loop")
            key = mo._sticky_key_multi(rec, sticky=sticky) if sticky in {"SHARED_LOCATION", "SHARED_VERTEX"} else ("loop", id(loop))
        except Exception:
            key = ("loop", id(rec.get("loop")))
        if key not in buckets:
            buckets[key] = []
            order.append(key)
        buckets[key].append(rec)
    points: List[Dict[str, Any]] = []
    for key in order:
        recs = buckets.get(key) or []
        if not recs:
            continue
        try:
            u = sum(_record_value(r, True) for r in recs) / float(len(recs))
            v = sum(_record_value(r, False) for r in recs) / float(len(recs))
        except Exception:
            u = 0.0
            v = 0.0
        points.append({"key": key, "records": recs, "u": u, "v": v})
    return points


def _shift_selected_group(records: Sequence[Dict[str, Any]], axis_u: bool, delta: float) -> int:
    if abs(float(delta)) <= _EPS:
        return 0
    changed = 0
    for rec in _unique_records(records):
        try:
            loop = rec.get("loop")
            uv_layer = rec.get("uv_layer")
            uv = loop[uv_layer].uv
            if axis_u:
                uv.x = float(uv.x) + float(delta)
                rec["u"] = float(uv.x)
            else:
                uv.y = float(uv.y) + float(delta)
                rec["v"] = float(uv.y)
            changed += 1
        except Exception:
            pass
    return changed


def _trusted_selected_records(context: Any, obj: Any, bm: Any, uv_layer: Any, mode: str):
    """Return selected source records without adding sticky followers."""
    try:
        recs, loops, edge_loops, faces = lg._trusted_selected_anchor_records(context, obj, bm, uv_layer, mode)
        recs = _unique_records(recs)
        if recs:
            return recs, loops, edge_loops, faces
    except Exception:
        pass
    try:
        recs, loops, edge_loops, faces = ri._selected_anchor_records(context, obj, bm, uv_layer, mode)
        return _unique_records(recs), loops, edge_loops, faces
    except Exception:
        return [], set(), set(), set()


def _source_groups(context: Any, obj: Any, bm: Any, uv_layer: Any, mode: str, records: List[Dict[str, Any]], edge_loops: Set[Any], faces: Set[Any]) -> List[List[Dict[str, Any]]]:
    try:
        groups = ri._source_groups_from_selection(context, obj, bm, uv_layer, mode, records, edge_loops, faces)
    except Exception:
        groups = []
    clean = [_unique_records(group) for group in (groups or [])]
    clean = [group for group in clean if group]
    if clean:
        return clean
    recs = _unique_records(records)
    return [recs] if recs else []


def _execute_grouped_vertex_align_18107(self: Any, context: Any):
    raw = _s(getattr(self, "action", "ALIGN_CENTER")).upper() or "ALIGN_CENTER"
    if raw not in _GROUP_ACTIONS:
        prev = _PREV.get("vertex_execute")
        if callable(prev) and prev is not _execute_grouped_vertex_align_18107:
            return prev(self, context)
        return {"CANCELLED"}

    snap = ri._snapshot_modes(context)
    objs, state = mo._ensure_multi_edit(context)
    if not objs:
        _report(self, "WARNING", _tr(context, "No mesh object is active.", "アクティブなメッシュオブジェクトがありません。"))
        return {"CANCELLED"}

    try:
        mo._prepare_unwrap_channel(context)
        targets = mo._target_data(context)
        if not targets:
            _report(self, "WARNING", _tr(context, "No editable UV map is available.", "編集可能なUVマップがありません。"))
            return {"CANCELLED"}

        mode = ri._uv_mode(context)
        sticky = ri._sticky_mode(context)
        groups: List[List[Dict[str, Any]]] = []
        for obj, bm, uv_layer in targets:
            source_records, _loops, edge_loops, faces = _trusted_selected_records(context, obj, bm, uv_layer, mode)
            if not source_records:
                continue
            groups.extend(_source_groups(context, obj, bm, uv_layer, mode, source_records, edge_loops, faces))

        if not groups:
            _report(self, "WARNING", _tr(context, "No UV element group is selected.", "選択されたUVエレメントグループがありません。"))
            return {"CANCELLED"}

        changed = 0
        if raw in _DISTRIBUTE_GROUP_ACTIONS:
            axis_u = raw == "DISTRIBUTE_H_GROUP"
            prepared: List[Dict[str, Any]] = []
            for group in groups:
                clean = _unique_records(group)
                center = _group_midpoint(clean, axis_u)
                if center is not None:
                    prepared.append({"records": clean, "center": center})
            if len(prepared) <= 1:
                _report(self, "WARNING", _tr(context, "At least two selected UV groups are required for grouped distribution.", "グループごとの等間隔には2つ以上の選択UVグループが必要です。"))
                return {"CANCELLED"}
            ordered = sorted(prepared, key=lambda item: float(item.get("center", 0.0)))
            start = float(ordered[0]["center"])
            end = float(ordered[-1]["center"])
            if abs(end - start) <= _EPS:
                _report(self, "WARNING", _tr(context, "Grouped distribution needs a non-zero span between group centers.", "グループごとの等間隔にはグループ中点間の幅が必要です。"))
                return {"CANCELLED"}
            step = (end - start) / float(max(1, len(ordered) - 1))
            for index, item in enumerate(ordered):
                target = start + step * index
                current = float(item["center"])
                changed += _shift_selected_group(item.get("records") or [], axis_u, target - current)
        else:
            # G— / G|: keep the original group-center alignment semantics but
            # use selected-only point buckets, never sticky followers.
            action = raw[:-6]
            for group in groups:
                points = _selected_points(group, sticky)
                changed += ri._apply_points(points, action)

        if changed <= 0:
            _report(self, "WARNING", _tr(context, "Grouped vertex alignment did not change the selected elements.", "グループ整列で変更される選択エレメントがありませんでした。"))
            return {"CANCELLED"}

        mo._update_meshes(targets)
        try:
            area = getattr(context, "area", None)
            if area is not None:
                area.tag_redraw()
        except Exception:
            pass
        return {"FINISHED"}
    except Exception as exc:
        _report(self, "WARNING", _tr(context, "Grouped vertex alignment failed.", "グループ整列に失敗しました。") + f" {exc}")
        return {"CANCELLED"}
    finally:
        ri._restore_modes(snap)
        mo._restore_multi_edit(context, state)
        ri._restore_modes(snap)


def _patch_vertex_operator(ns: Dict[str, Any]) -> None:
    cls = ns.get("SMARTUVSUITE_OT_vertex_align_action") if isinstance(ns, dict) else None
    if not isinstance(cls, type):
        return
    cur = getattr(cls, "execute", None)
    if getattr(cur, "_sus_18107_group_selected_only", False):
        return
    if callable(cur):
        _PREV["vertex_execute"] = cur
    try:
        _execute_grouped_vertex_align_18107._sus_18107_group_selected_only = True  # type: ignore[attr-defined]
        _execute_grouped_vertex_align_18107._sus_18107_group_distribute = True  # type: ignore[attr-defined]
        _execute_grouped_vertex_align_18107._sus_18105_group_distribute = True  # type: ignore[attr-defined]
        _execute_grouped_vertex_align_18107._sus_18104_multi = True  # type: ignore[attr-defined]
    except Exception:
        pass
    try:
        cls.execute = _execute_grouped_vertex_align_18107
    except Exception:
        pass


def _mark_version(ns: Dict[str, Any]) -> None:
    try:
        info = ns.get("bl_info")
        if not isinstance(info, dict):
            info = {}
            ns["bl_info"] = info
        info.update({
            "name": "Smart UV Suite",
            "author": "JELararagi",
            "version": (1, 0, 0),
            "blender": (5, 1, 0),
            "location": "View3D / UV Editor > Sidebar > Smart UV",
            "description": "Smart UV Suite exposes UV editing tools in the Smart UV sidebar.",
            "category": "Smart UV",
        })
        ns["_SUS_BL_INFO_FALLBACK"] = dict(info)
        ns["__version__"] = '1.0.0'
    except Exception:
        pass


def _wrap_sync(ns: Dict[str, Any]) -> None:
    base = ns.get("_sus_1652_sync_keymaps_from_workspace") if isinstance(ns, dict) else None
    if callable(base) and not getattr(base, "_sus_18107_sync", False):
        _PREV["sync"] = base
    base_sync = _PREV.get("sync")

    def _sync_18107(context=None):
        ctx = context or getattr(bpy, "context", None)
        if callable(base_sync) and base_sync is not _sync_18107:
            try:
                base_sync(ctx)
            except TypeError:
                try:
                    base_sync()
                except Exception:
                    pass
            except Exception:
                pass
        try:
            apply_all(ns, ctx)
        except Exception:
            pass

    try:
        _sync_18107._sus_18107_sync = True  # type: ignore[attr-defined]
    except Exception:
        pass
    try:
        ns["_sus_1652_sync_keymaps_from_workspace"] = _sync_18107
    except Exception:
        pass


def apply_all(ns: Optional[Dict[str, Any]] = None, context: Any = None) -> None:
    global _NS
    if isinstance(ns, dict):
        _NS = ns
    elif not _NS:
        import sys
        mod = sys.modules.get(__package__)
        if mod is not None:
            _NS = getattr(mod, "__dict__", {})
    target = _NS if isinstance(_NS, dict) else {}
    if not target:
        return
    _patch_vertex_operator(target)
    _wrap_sync(target)
    _mark_version(target)


def install(ns: Optional[Dict[str, Any]] = None, context: Any = None) -> None:
    apply_all(ns, context or getattr(bpy, "context", None))


def unregister() -> None:
    # Do not restore older group handlers inside a live Blender session.  They
    # can reintroduce sticky follower writes.
    return None


def audit(context: Any = None) -> Dict[str, Any]:
    cls = _NS.get("SMARTUVSUITE_OT_vertex_align_action") if isinstance(_NS, dict) else None
    execute = getattr(cls, "execute", None) if isinstance(cls, type) else None
    return {
        "version": _VERSION,
        "selected_only_grouped_vertex_align": bool(getattr(execute, "_sus_18107_group_selected_only", False)),
        "moves_sticky_followers_for_group_distribution": False,
    }
