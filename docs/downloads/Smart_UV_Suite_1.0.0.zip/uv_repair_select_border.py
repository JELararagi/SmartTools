"""Operator descriptions and bindings for the UV selection menu."""


def build_handlers(api):
    routes = (
        ("select_border", api._select_uv_boundary,
         "Select the outer edges of the selected UV islands.",
         "選択したUVアイランドの外周辺を選択します。"),
        ("select_linked", api._native_uv_selection("select_linked"),
         "Select the UV islands linked to the current selection.",
         "現在の選択につながる UV アイランドを選びます。"),
    )
    return {
        f"smart_uv_suite.{name}": api.Handler(callback, english, japanese)
        for name, callback, english, japanese in routes
    }
