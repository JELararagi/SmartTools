def build_handlers(api):
    backend = api._select_uv_boundary

    def run(context, op):
        return backend(context, op)

    return {
        'smart_uv_suite.select_border': api.Handler(run, 'Select the outer edges of the selected UV islands.', '選択したUVアイランドの外周辺を選択します。'),
        'smart_uv_suite.select_linked': api.Handler(
            api._native_uv_selection('select_linked'),
            'Select the UV islands linked to the current selection.',
            '現在の選択につながる UV アイランドを選びます。'),
    }
