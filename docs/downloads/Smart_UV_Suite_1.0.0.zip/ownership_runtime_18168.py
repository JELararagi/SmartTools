# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Generation-aware exact ownership ledger for Smart UV Suite.

Only resources explicitly created by Smart UV Suite are recorded.  No Blender
process-global API is replaced, wrapped or searched.  Every teardown operation
uses the exact identity and native remover captured when the resource was made.
"""
from __future__ import annotations

from typing import Any, Callable
import sys
import types
import uuid

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover - static tooling
    bpy = None  # type: ignore

try:
    from bpy.app.handlers import persistent as _persistent  # type: ignore
except Exception:  # pragma: no cover - static tooling
    def _persistent(function: Any) -> Any:  # type: ignore
        return function

OWNER_FAMILY = "Smart UV Suite/JELararagi"
OWNER_TOKEN = OWNER_FAMILY + "/1.0.0"
# Keep the stable key so a newer generation can retire records made by 1.8.169.
_STORE_KEY = "_JELARARAGI_SMART_UV_SUITE_18168_LEDGER"
_FALLBACK_STORE: dict[str, Any] = {
    "owner_family": OWNER_FAMILY,
    "generation": 0,
    "active": False,
    "records": [],
}

# Blender REPLACES ``bpy.app.driver_namespace`` with a fresh dict on every file
# load (measured on 5.1.2 ec6e62d40fa9).  The 974-record ledger published at
# enable was therefore gone after one ``wm.open_mainfile``, ``_store()`` minted
# an empty one, and ``unregister_owned_runtime()`` then tore down nothing: a
# disable left 25 ``UVSUITE_MT_*`` menus, ``SMARTUV_AddonPreferences``,
# ``SUV_PG_WorkspaceSettings``, ``Scene.suv_workspace`` and
# ``WindowManager.uv_suite_tool_runtime_settings_v520`` registered, and the
# re-enable came back with 104 of 974 records (895 -> 102 classes).
#
# A synthetic ``sys.modules`` entry holds the exact ledger object for the life
# of the process: it survives file loads and this package's own submodule purge
# on live update, which removes only ``<package>.`` keys.  The store is scoped
# to this package by name; it is never a shared registry.
_ANCHOR_MODULE_NAME = "jelararagi_smart_uv_suite_runtime_anchor_v1"


def anchor_store() -> dict[str, Any]:
    """Process-lifetime dict for exact Smart UV runtime state."""
    module = sys.modules.get(_ANCHOR_MODULE_NAME)
    if not isinstance(module, types.ModuleType):
        module = types.ModuleType(_ANCHOR_MODULE_NAME)
        module.__doc__ = (
            "Smart UV Suite runtime anchor.  Keeps the exact ownership ledger "
            "reachable across Blender file loads, which replace "
            "bpy.app.driver_namespace.  Not an importable module."
        )
        module.SUV_ANCHORED = {}
        sys.modules[_ANCHOR_MODULE_NAME] = module
    store = getattr(module, "SUV_ANCHORED", None)
    if not isinstance(store, dict):
        store = {}
        module.SUV_ANCHORED = store
    return store


def _fresh_store(generation: int = 0) -> dict[str, Any]:
    return {
        "owner_family": OWNER_FAMILY,
        "generation": int(generation),
        "active": False,
        "records": [],
    }


def _store() -> dict[str, Any]:
    if bpy is not None:
        try:
            namespace = getattr(getattr(bpy, "app", None), "driver_namespace", None)
            if isinstance(namespace, dict):
                value = namespace.get(_STORE_KEY)
                if value is None:
                    # A file load replaced driver_namespace.  Every resource in
                    # the anchored ledger is process-global and still live, so
                    # the anchored object stays authoritative: re-publish it on
                    # this first touch instead of minting an empty ledger.
                    anchored = anchor_store().get(_STORE_KEY)
                    if isinstance(anchored, dict) and anchored.get("owner_family") == OWNER_FAMILY:
                        namespace[_STORE_KEY] = anchored
                        value = anchored
                if not isinstance(value, dict) or value.get("owner_family") != OWNER_FAMILY:
                    value = _fresh_store()
                    namespace[_STORE_KEY] = value
                value.setdefault("records", [])
                value.setdefault("generation", 0)
                value.setdefault("active", False)
                # Keep the anchor pointing at the exact live ledger, including
                # one published by an older generation of this suite.
                anchor_store()[_STORE_KEY] = value
                return value
        except Exception:
            pass
    return _FALLBACK_STORE


def _ledger_has_live_records(value: Any) -> bool:
    try:
        return any(
            not bool(record.get("removed"))
            for record in (value.get("records") or ())
            if isinstance(record, dict)
        )
    except Exception:
        # An unreadable ledger is treated as still guarding resources.
        return True


def release_namespace_ledger() -> dict[str, bool]:
    """Drop this suite's own ledger key once it guards nothing.

    ``bpy.app.driver_namespace`` is shared process state.  The ledger published
    at enable used to survive a disable, so a lifecycle audit saw a Smart UV key
    left behind and every later row was blocked on it.  Only the exact key this
    module publishes is removed, only when the value is this suite's own ledger
    and only when no record still guards a live resource; a ledger with live
    records is left in place because dropping it would orphan them.  No other
    key is read, compared or written, so foreign entries are untouched.
    """
    released = {"driver_namespace": False, "anchor": False}
    if bpy is not None:
        try:
            namespace = getattr(getattr(bpy, "app", None), "driver_namespace", None)
        except Exception:
            namespace = None
        if isinstance(namespace, dict):
            value = namespace.get(_STORE_KEY)
            if (isinstance(value, dict)
                    and value.get("owner_family") == OWNER_FAMILY
                    and not _ledger_has_live_records(value)):
                namespace.pop(_STORE_KEY, None)
                released["driver_namespace"] = True
    try:
        anchor = anchor_store()
    except Exception:
        anchor = None
    if isinstance(anchor, dict):
        value = anchor.get(_STORE_KEY)
        if (isinstance(value, dict)
                and value.get("owner_family") == OWNER_FAMILY
                and not _ledger_has_live_records(value)):
            anchor.pop(_STORE_KEY, None)
            released["anchor"] = True
    return released


def current_generation() -> int:
    try:
        return int(_store().get("generation", 0) or 0)
    except Exception:
        return 0


def _owner_token(generation: int | None = None) -> str:
    generation = current_generation() if generation is None else int(generation)
    return f"{OWNER_TOKEN}/generation-{generation}"


def _stamp(obj: Any, generation: int | None = None) -> bool:
    generation = current_generation() if generation is None else int(generation)
    try:
        setattr(obj, "_smart_uv_suite_owner_family", OWNER_FAMILY)
        setattr(obj, "_smart_uv_suite_owner_token", _owner_token(generation))
        setattr(obj, "_smart_uv_suite_generation", generation)
        return True
    except Exception:
        return False


def _family_owned(obj: Any) -> bool:
    try:
        return getattr(obj, "_smart_uv_suite_owner_family", None) == OWNER_FAMILY
    except Exception:
        return False


def owns_object(obj: Any, *, generation: int | None = None) -> bool:
    """Return True for exact Smart UV markers, including an older patch token."""
    try:
        if not _family_owned(obj):
            return False
        token = str(getattr(obj, "_smart_uv_suite_owner_token", "") or "")
        if not token.startswith(OWNER_FAMILY + "/") or "/generation-" not in token:
            return False
        if generation is not None and int(getattr(obj, "_smart_uv_suite_generation", -1)) != int(generation):
            return False
        return True
    except Exception:
        return False


def _records() -> list[dict[str, Any]]:
    records = _store().get("records")
    if not isinstance(records, list):
        records = []
        _store()["records"] = records
    return records


def _rna_pointer(obj: Any) -> int | None:
    try:
        pointer = int(obj.as_pointer())
    except Exception:
        return None
    return pointer if pointer else None


def _same_rna_pointer(left: Any, right: Any) -> bool:
    left_pointer = _rna_pointer(left)
    right_pointer = _rna_pointer(right)
    return bool(left_pointer is not None and left_pointer == right_pointer)


def _record_keymap_item_pointer(record: dict[str, Any]) -> int | None:
    try:
        value = record.get("meta", {}).get("kmi_pointer")
        return int(value) if value else None
    except Exception:
        return None


def _record_keymap_pointer(record: dict[str, Any]) -> int | None:
    try:
        value = record.get("meta", {}).get("keymap_pointer")
        return int(value) if value else None
    except Exception:
        return None


def _keymap_record_matches(record: dict[str, Any], identity: Any) -> bool:
    stored = _record_keymap_item_pointer(record)
    current = _rna_pointer(identity)
    if stored is not None and current is not None:
        return stored == current
    return record.get("identity") is identity


def _record_matches(record: dict[str, Any], kind: str, identity: Any, generation: int | None = None) -> bool:
    identity_matches = (
        _keymap_record_matches(record, identity)
        if str(kind) == "keymap" else record.get("identity") is identity
    )
    return (
        record.get("owner_family") == OWNER_FAMILY
        and record.get("kind") == kind
        and identity_matches
        and (generation is None or int(record.get("generation", -1)) == int(generation))
        and not bool(record.get("removed"))
    )


# Lookup index for _append_record.  Between list replacements the ledger only
# grows (every removal publishes a new list object), so the index is rebuilt
# when the list object changes or shrinks and only the new tail is indexed
# otherwise.  Every candidate is still checked with _record_matches in ledger
# order, so the index narrows the scan without changing which row is returned.
_APPEND_INDEX: dict[str, Any] = {"records": None, "count": 0, "index": {}}


def _append_index_keys(kind: Any, identity: Any, kmi_pointer: int | None) -> tuple[tuple[Any, ...], ...]:
    if kind == "keymap" and kmi_pointer is not None:
        return ((kind, "id", id(identity)), (kind, "ptr", kmi_pointer))
    return ((kind, "id", id(identity)),)


def _append_index(records: list[dict[str, Any]]) -> dict[tuple[Any, ...], list[int]]:
    cache = _APPEND_INDEX
    if cache["records"] is not records or cache["count"] > len(records):
        cache["records"] = records
        cache["count"] = 0
        cache["index"] = {}
    index = cache["index"]
    for position in range(cache["count"], len(records)):
        record = records[position]
        if not isinstance(record, dict):
            continue
        keys = _append_index_keys(record.get("kind"), record.get("identity"), _record_keymap_item_pointer(record))
        for key in keys:
            index.setdefault(key, []).append(position)
    cache["count"] = len(records)
    return index


def _append_record(
    kind: str,
    identity: Any,
    remover: Callable[..., Any] | None,
    remove_args: tuple[Any, ...] = (),
    **meta: Any,
) -> dict[str, Any]:
    generation = current_generation()
    kind_text = str(kind)
    records = _records()
    index = _append_index(records)
    lookup_pointer = _rna_pointer(identity) if kind_text == "keymap" else None
    positions: set[int] = set()
    for key in _append_index_keys(kind_text, identity, lookup_pointer):
        positions.update(index.get(key, ()))
    for position in sorted(positions):
        old = records[position]
        if _record_matches(old, kind_text, identity, generation):
            return old
    record = {
        "owner_family": OWNER_FAMILY,
        "owner_token": _owner_token(generation),
        "kind": str(kind),
        "identity": identity,
        "generation": generation,
        "remover": remover,
        "remove_args": tuple(remove_args),
        "removed": False,
        "meta": dict(meta),
    }
    _records().append(record)
    return record


def _record_owned(record: dict[str, Any]) -> bool:
    try:
        token = str(record.get("owner_token", "") or "")
        return record.get("owner_family") == OWNER_FAMILY and token.startswith(OWNER_FAMILY + "/")
    except Exception:
        return False


def _remove_record(record: dict[str, Any]) -> bool:
    if bool(record.get("removed")):
        return True
    if not _record_owned(record):
        return False
    identity = record.get("identity")
    generation = int(record.get("generation", -1))
    kind = str(record.get("kind", ""))
    # Classes and callback wrappers can carry Python markers. KeyMapItem and
    # msgbus owner RNA/Python objects may not allow custom attributes, so their
    # exact ledger identity and captured remover are authoritative.
    if kind in {"class", "timer_callback", "draw_callback"}:
        if identity is not None and not owns_object(identity, generation=generation):
            return False
    remover = record.get("remover")
    args = tuple(record.get("remove_args", ()))
    try:
        if callable(remover):
            remover(identity, *args)
        record["removed"] = True
        return True
    except ReferenceError:
        record["removed"] = True
        return True
    except KeyError:
        if kind == "preview_collection":
            record["removed"] = True
            return True
        return False
    except Exception:
        return False


def _live_keymap_item(record: dict[str, Any]) -> Any:
    if record.get("kind") != "keymap":
        return record.get("identity")
    keymap = record.get("meta", {}).get("keymap")
    expected_pointer = _record_keymap_item_pointer(record)
    if keymap is not None and expected_pointer is not None:
        try:
            for item in tuple(getattr(keymap, "keymap_items", ()) or ()):
                if _rna_pointer(item) == expected_pointer:
                    return item
        except Exception:
            pass
    return record.get("identity")


def unregister_owned_runtime(*, generation: int | None = None) -> dict[str, int]:
    result = {"removed": 0, "failed": 0, "kept": 0}
    targets = [
        record for record in tuple(_records())
        if generation is None or int(record.get("generation", -1)) == int(generation)
    ]
    for record in reversed(targets):
        if _remove_record(record):
            result["removed"] += 1
        else:
            result["failed"] += 1
    kept = [record for record in _records() if not bool(record.get("removed"))]
    _store()["records"] = kept
    _store()["active"] = False
    result["kept"] = len(kept)
    return result


def begin_generation() -> int:
    store = _store()
    store["active"] = False
    cleanup = unregister_owned_runtime()
    # Failed native removals remain guarded by the old generation.  Do not
    # silently discard their exact records.
    if cleanup["failed"]:
        raise RuntimeError(f"Smart UV exact resource teardown failed: {cleanup['failed']}")
    store = _store()
    store["generation"] = int(store.get("generation", 0) or 0) + 1
    store["active"] = False
    store["records"] = []
    # First acquisition of the new generation: the load_post re-arm itself, so
    # the handler that heals driver_namespace is tracked and removed by this
    # suite's own teardown rather than surviving as an orphan.
    install_load_post_rearm()
    return int(store["generation"])


def mark_active(value: bool = True) -> None:
    _store()["active"] = bool(value)


def is_active() -> bool:
    return bool(_store().get("active", False))


def _class_registered_exact(cls: type) -> bool:
    try:
        rna = vars(cls).get("bl_rna") if isinstance(cls, type) else None
        return bool(rna is not None and str(getattr(rna, "identifier", "") or ""))
    except Exception:
        return False


def _lookup_registered_class(cls: type):
    names = tuple(dict.fromkeys(
        str(value or "")
        for value in (
            getattr(cls, "__name__", ""),
            getattr(cls, "bl_idname", ""),
        )
        if str(value or "")
    ))
    if not names:
        return None
    for name in names:
        try:
            exposed = getattr(getattr(bpy, "types", None), name, None)
        except Exception:
            exposed = None
        if isinstance(exposed, type) and _class_registered_exact(exposed):
            return exposed
    for base_name in ("Operator", "Panel", "Menu", "UIList", "PropertyGroup", "AddonPreferences"):
        for name in names:
            try:
                base = getattr(getattr(bpy, "types", None), base_name, None)
                if not isinstance(base, type) or not issubclass(cls, base):
                    continue
                lookup = getattr(base, "bl_rna_get_subclass_py", None)
                found = lookup(name) if callable(lookup) else None
            except Exception:
                found = None
            if isinstance(found, type) and _class_registered_exact(found):
                return found
    return None


def _same_suite_class(stale: type, cls: type) -> bool:
    try:
        stale_module = str(getattr(stale, "__module__", "") or "")
        expected_id = str(getattr(cls, "bl_idname", "") or "")
        stale_id = str(getattr(stale, "bl_idname", "") or "")
        return bool(
            isinstance(stale, type)
            and str(getattr(stale, "__name__", "") or "") == str(getattr(cls, "__name__", "") or "")
            and (not expected_id or stale_id == expected_id)
            and "smart_uv_suite" in stale_module.split(".")
        )
    except Exception:
        return False


def register_class(cls: type) -> bool:
    if bpy is None or not isinstance(cls, type):
        return False
    generation = current_generation()
    native_register = getattr(getattr(bpy, "utils", None), "register_class", None)
    native_unregister = getattr(getattr(bpy, "utils", None), "unregister_class", None)
    if not callable(native_register) or not callable(native_unregister):
        return False
    already = _class_registered_exact(cls)
    if already:
        # An exact class already registered by this generation is a deterministic
        # no-op.  A stale Smart UV generation may be retired; foreign classes are
        # never claimed or removed.
        if owns_object(cls, generation=generation):
            if any(_record_matches(record, "class", cls, generation) for record in _records()):
                return True
            # Same stamp, no ledger row: an orphan left by a dead generation of
            # this suite whose generation counter restarted at the same number
            # (a pre-anchor build that lost its ledger to a file load).  ``cls``
            # is this package's own class object, so adopt it -- retire the
            # orphan registration and re-register it into this ledger.
        elif not _family_owned(cls):
            return False
        try:
            native_unregister(cls)
        except Exception:
            return False
    # Detect and retire an orphan before calling Blender's register function;
    # otherwise Blender prints an auto-replacement warning before Python can
    # recover. Class name, operator id, and package namespace must all match.
    stale = _lookup_registered_class(cls)
    if isinstance(stale, type):
        if not _same_suite_class(stale, cls):
            return False
        try:
            native_unregister(stale)
        except Exception:
            return False
    try:
        native_register(cls)
    except Exception:
        return False
    if not _stamp(cls, generation):
        try:
            native_unregister(cls)
        except Exception:
            pass
        return False

    def _remove_class(identity: type) -> None:
        if not owns_object(identity, generation=generation):
            raise RuntimeError("class ownership changed before teardown")
        if bool(getattr(identity, "is_registered", False)):
            native_unregister(identity)

    _append_record(
        "class", cls, _remove_class,
        bl_idname=str(getattr(cls, "bl_idname", "") or ""),
        name=str(getattr(cls, "__name__", "")),
    )
    return True


def unregister_class(cls: type) -> bool:
    for record in reversed(tuple(_records())):
        if _record_matches(record, "class", cls):
            ok = _remove_record(record)
            if ok:
                _store()["records"] = [item for item in _records() if item is not record]
            return ok
    return False


def registered_classes() -> tuple[type, ...]:
    return tuple(
        record.get("identity") for record in _records()
        if record.get("kind") == "class" and not bool(record.get("removed"))
        and isinstance(record.get("identity"), type)
    )


def track_keymap_item(keymap: Any, kmi: Any, idname: str = "") -> Any:
    if keymap is None or kmi is None:
        return kmi
    generation = current_generation()
    # Do not stamp KeyMapItem RNA objects.  Blender 5.1 accepts custom attrs on
    # some KMI wrappers but those rows can then remain visible in the collection
    # while being skipped by real event dispatch.  The ledger pointer below is
    # the ownership authority for keymaps.
    items = getattr(keymap, "keymap_items", None)
    native_remove = getattr(items, "remove", None)
    if not callable(native_remove):
        return kmi

    kmi_pointer = _rna_pointer(kmi)
    keymap_pointer = _rna_pointer(keymap)
    for old in _records():
        old_meta = old.get("meta", {})
        if (
            old.get("owner_family") == OWNER_FAMILY
            and old.get("kind") == "keymap"
            and int(old.get("generation", -1)) == int(generation)
            and not bool(old.get("removed"))
            and old_meta.get("kmi_pointer") == kmi_pointer
            and old_meta.get("keymap_pointer") == keymap_pointer
        ):
            return kmi

    def _remove_kmi(identity: Any) -> None:
        live = identity
        if kmi_pointer is not None:
            try:
                for item in tuple(getattr(keymap, "keymap_items", ()) or ()):
                    if _rna_pointer(item) == kmi_pointer:
                        live = item
                        break
                else:
                    return
            except Exception:
                pass
        if live is identity and not hasattr(live, "as_pointer"):
            return
        native_remove(live)

    _append_record(
        "keymap", ("keymap", keymap_pointer, kmi_pointer), _remove_kmi,
        keymap=keymap,
        idname=str(idname or ""),
        keymap_pointer=keymap_pointer,
        kmi_pointer=kmi_pointer,
        generation=generation,
    )
    return kmi


def new_keymap_item(keymap: Any, idname: str, **kwargs: Any) -> Any:
    idname = str(idname or "").strip()
    items = getattr(keymap, "keymap_items", None) if keymap is not None else None
    native_new = getattr(items, "new", None)
    if not idname or not callable(native_new):
        return None
    kmi = native_new(idname, **kwargs)
    return track_keymap_item(keymap, kmi, idname)


def owned_keymap_items(idname: str | None = None) -> tuple[tuple[Any, Any], ...]:
    target = None if idname is None else str(idname)
    out: list[tuple[Any, Any]] = []
    for record in _records():
        if record.get("kind") != "keymap" or bool(record.get("removed")) or not _record_owned(record):
            continue
        meta = record.get("meta", {})
        if target is not None and str(meta.get("idname", "")) != target:
            continue
        out.append((meta.get("keymap"), _live_keymap_item(record)))
    return tuple(out)


def keymap_item_is_owned(kmi: Any, idname: str | None = None) -> bool:
    target = None if idname is None else str(idname)
    for record in _records():
        if record.get("kind") != "keymap" or bool(record.get("removed")) or not _record_owned(record):
            continue
        if target is not None and str(record.get("meta", {}).get("idname", "")) != target:
            continue
        if _keymap_record_matches(record, kmi):
            return True
    return False


def set_keymap_item_active(kmi: Any, active: bool) -> bool:
    if not keymap_item_is_owned(kmi):
        return False
    try:
        kmi.active = bool(active)
        return True
    except Exception:
        return False


def set_owned_keymap_active(idname: str, active: bool) -> int:
    return sum(1 for _keymap, kmi in owned_keymap_items(idname) if set_keymap_item_active(kmi, active))


def remove_keymap_item(keymap: Any, kmi: Any) -> bool:
    for record in reversed(tuple(_records())):
        if record.get("kind") != "keymap" or not _keymap_record_matches(record, kmi):
            continue
        meta = record.get("meta", {})
        stored_keymap_pointer = _record_keymap_pointer(record)
        current_keymap_pointer = _rna_pointer(keymap)
        if stored_keymap_pointer is not None and current_keymap_pointer is not None:
            if stored_keymap_pointer != current_keymap_pointer:
                continue
        elif meta.get("keymap") is not keymap:
            continue
        ok = _remove_record(record)
        if ok:
            _store()["records"] = [item for item in _records() if item is not record]
        return ok
    return False


def remove_owned_keymaps(idname: str | None = None) -> int:
    target = None if idname is None else str(idname)
    removed = 0
    for record in reversed(tuple(_records())):
        if record.get("kind") != "keymap":
            continue
        if target is not None and str(record.get("meta", {}).get("idname", "")) != target:
            continue
        if _remove_record(record):
            removed += 1
    _store()["records"] = [record for record in _records() if not bool(record.get("removed"))]
    return removed


def append_handler(handler_list: Any, fn: Any) -> bool:
    if handler_list is None or not callable(fn):
        return False
    generation = current_generation()
    if any(_record_matches(record, "handler", fn, generation) and record.get("meta", {}).get("handler_list") is handler_list for record in _records()):
        return True
    try:
        if fn in handler_list:
            return False  # do not claim an unrecorded/foreign row
        handler_list.append(fn)
    except Exception:
        return False
    _stamp(fn, generation)

    def _remove_handler(identity: Any) -> None:
        if identity in handler_list:
            handler_list.remove(identity)

    _append_record("handler", fn, _remove_handler, handler_list=handler_list)
    return True


def track_handler(handler_list: Any, fn: Any) -> None:
    # Compatibility entry point: never claim an already-existing row.
    append_handler(handler_list, fn)


def remove_handler(handler_list: Any, fn: Any) -> bool:
    for record in reversed(tuple(_records())):
        if record.get("kind") == "handler" and record.get("identity") is fn and record.get("meta", {}).get("handler_list") is handler_list:
            ok = _remove_record(record)
            if ok:
                _store()["records"] = [item for item in _records() if item is not record]
            return ok
    return False


@_persistent
def _rearm_driver_namespace(*_args: Any) -> None:
    """Re-publish the anchored ledger after Blender replaces driver_namespace.

    Acquired as the first resource of every generation (see
    ``begin_generation``), so it is journaled and retired by
    ``unregister_owned_runtime()`` exactly like any other owned row.  It never
    raises: a persistent handler that fails would break foreign handlers and
    the user's own file load.
    """
    try:
        _store()
    except Exception:
        pass


def _load_post_handlers() -> Any:
    handlers = getattr(getattr(bpy, "app", None), "handlers", None) if bpy is not None else None
    load_post = getattr(handlers, "load_post", None)
    return load_post if isinstance(load_post, list) else None


def install_load_post_rearm() -> bool:
    """Attach the driver_namespace re-arm as an owned, journaled resource."""
    load_post = _load_post_handlers()
    if load_post is None:
        return False
    # Retire an unledgered leftover of this exact callback.  A generation whose
    # ledger was lost before the anchor shipped could not remove its own row,
    # and append_handler correctly refuses to claim a row it did not record.
    for _attempt in range(len(load_post) + 1):
        if _rearm_driver_namespace not in load_post:
            break
        try:
            load_post.remove(_rearm_driver_namespace)
        except Exception:
            break
    # The re-arm now runs from the product's single load_post handler (smartuv_operation_runtime_18228._load_post).
    return True


def load_post_rearm_installed() -> bool:
    load_post = _load_post_handlers()
    return bool(load_post is not None and _rearm_driver_namespace in load_post)


def register_finite_timer(
    callback: Callable[[], Any], *, first_interval: float = 0.0, max_runs: int = 1
) -> Callable[[], Any] | None:
    if bpy is None or not callable(callback) or not is_active():
        return None
    timers = getattr(getattr(bpy, "app", None), "timers", None)
    native_register = getattr(timers, "register", None)
    native_unregister = getattr(timers, "unregister", None)
    native_is_registered = getattr(timers, "is_registered", None)
    if not callable(native_register):
        return None
    generation = current_generation()
    max_runs = max(1, int(max_runs or 1))
    state = {"runs": 0, "cancelled": False}
    holder: dict[str, Any] = {"record": None}

    def _retire_record() -> None:
        record = holder.get("record")
        if isinstance(record, dict):
            record["removed"] = True
            try:
                _store()["records"] = [item for item in _records() if item is not record and not bool(item.get("removed"))]
            except Exception:
                pass

    def guarded() -> Any:
        if state["cancelled"] or current_generation() != generation or not is_active():
            _retire_record()
            return None
        state["runs"] += 1
        try:
            result = callback()
        except Exception:
            _retire_record()
            return None
        if state["runs"] >= max_runs:
            _retire_record()
            return None
        if isinstance(result, (int, float)) and float(result) >= 0.0:
            return result
        _retire_record()
        return None

    _stamp(guarded, generation)
    try:
        native_register(guarded, first_interval=max(0.0, float(first_interval)), persistent=False)
    except TypeError:
        native_register(guarded, first_interval=max(0.0, float(first_interval)))
    except Exception:
        return None

    def _remove_timer(identity: Any) -> None:
        state["cancelled"] = True
        if callable(native_is_registered) and callable(native_unregister) and native_is_registered(identity):
            native_unregister(identity)

    holder["record"] = _append_record(
        "timer_callback", guarded, _remove_timer,
        original_callback=callback,
        finite=True,
        max_runs=max_runs,
    )
    return guarded

def track_timer(fn: Any, *, finite: bool = True) -> None:
    # Compatibility: only callbacks already stamped by this generation qualify.
    if bpy is None or not callable(fn) or not owns_object(fn, generation=current_generation()):
        return
    timers = getattr(getattr(bpy, "app", None), "timers", None)
    native_unregister = getattr(timers, "unregister", None)
    native_is_registered = getattr(timers, "is_registered", None)

    def _remove_timer(identity: Any) -> None:
        if callable(native_is_registered) and callable(native_unregister) and native_is_registered(identity):
            native_unregister(identity)

    _append_record("timer_callback", fn, _remove_timer, finite=bool(finite))


def timer_is_registered(callback: Any) -> bool:
    return any(
        record.get("kind") == "timer_callback"
        and not bool(record.get("removed"))
        and (record.get("identity") is callback or record.get("meta", {}).get("original_callback") is callback)
        for record in _records()
    )


def remove_timer_callback(callback: Any) -> bool:
    for record in reversed(tuple(_records())):
        if record.get("kind") != "timer_callback":
            continue
        if record.get("identity") is not callback and record.get("meta", {}).get("original_callback") is not callback:
            continue
        ok = _remove_record(record)
        if ok:
            _store()["records"] = [item for item in _records() if item is not record]
        return ok
    return False


def register_msgbus(*, key: Any, owner: Any, args: tuple[Any, ...] = (), notify: Callable[..., Any], options: set[str] | None = None) -> bool:
    if bpy is None or owner is None or not callable(notify) or not is_active():
        return False
    msgbus = getattr(bpy, "msgbus", None)
    native_subscribe = getattr(msgbus, "subscribe_rna", None)
    native_clear = getattr(msgbus, "clear_by_owner", None)
    if not callable(native_subscribe) or not callable(native_clear):
        return False
    try:
        native_subscribe(key=key, owner=owner, args=tuple(args), notify=notify, options=set(options or ()))
    except Exception:
        return False

    def _clear(identity: Any) -> None:
        native_clear(identity)

    _append_record("msgbus", owner, _clear, key=key, notify=notify)
    return True


def clear_msgbus_owner(owner: Any) -> bool:
    for record in reversed(tuple(_records())):
        if record.get("kind") == "msgbus" and record.get("identity") is owner:
            ok = _remove_record(record)
            if ok:
                _store()["records"] = [item for item in _records() if item is not record]
            return ok
    return False


def add_draw_handler(
    space_type: Any,
    callback: Callable[..., Any],
    args: tuple[Any, ...],
    region_type: str,
    draw_type: str,
    *,
    immutable_snapshot: Any = None,
) -> Any:
    snapshot = immutable_snapshot

    def invoke_snapshot(*runtime_args: Any) -> Any:
        return callback(snapshot, *runtime_args)

    return add_draw_handler_exact(space_type, invoke_snapshot, tuple(args), region_type, draw_type)


def add_draw_handler_exact(
    space_type: Any,
    callback: Callable[..., Any],
    args: tuple[Any, ...],
    region_type: str,
    draw_type: str,
) -> Any:
    if not is_active() or not callable(callback):
        return None
    native_add = getattr(space_type, "draw_handler_add", None)
    native_remove = getattr(space_type, "draw_handler_remove", None)
    if not callable(native_add) or not callable(native_remove):
        return None
    generation = current_generation()
    captured_args = tuple(args)

    def guarded(*runtime_args: Any) -> Any:
        if current_generation() != generation or not is_active():
            return None
        return callback(*(runtime_args if runtime_args else captured_args))

    _stamp(guarded, generation)
    try:
        handle = native_add(guarded, captured_args, str(region_type), str(draw_type))
    except Exception:
        return None

    def _remove_draw(identity: Any) -> None:
        del identity
        native_remove(handle, str(region_type))

    _append_record(
        "draw_callback", guarded, _remove_draw,
        callback=callback,
        captured_args=captured_args,
        handle=handle,
        native_remove=native_remove,
        space_type=space_type,
        region_type=str(region_type),
        draw_type=str(draw_type),
    )
    return handle


def track_draw_handler(space_name: str, region_type: str, callback: Any, handle: Any, native_remove: Any) -> None:
    # Legacy direct-handler tracking is intentionally disabled.  New handlers
    # must be created through add_draw_handler_exact so creation and removal are
    # one atomic ledger operation.
    del space_name, region_type, callback, handle, native_remove
    return None


def remove_draw_handler(handle: Any) -> bool:
    for record in reversed(tuple(_records())):
        if record.get("kind") == "draw_callback" and record.get("meta", {}).get("handle") is handle:
            ok = _remove_record(record)
            if ok:
                _store()["records"] = [item for item in _records() if item is not record]
            return ok
    return False



def register_preview_collection(previews_module: Any) -> Any:
    """Create and record one exact Blender preview collection."""
    native_new = getattr(previews_module, "new", None)
    native_remove = getattr(previews_module, "remove", None)
    if not callable(native_new) or not callable(native_remove):
        return None
    try:
        collection = native_new()
    except Exception:
        return None

    def _remove_preview(identity: Any) -> None:
        native_remove(identity)

    _append_record(
        "preview_collection", collection, _remove_preview,
        native_remove=native_remove,
    )
    return collection


def unregister_preview_collection(collection: Any) -> bool:
    for record in reversed(tuple(_records())):
        if record.get("kind") == "preview_collection" and record.get("identity") is collection:
            ok = _remove_record(record)
            if ok:
                _store()["records"] = [item for item in _records() if item is not record]
            return ok
    return False


def preview_collection_is_owned(collection: Any) -> bool:
    if collection is None:
        return False
    for record in tuple(_records()):
        if (
            record.get("kind") == "preview_collection"
            and not bool(record.get("removed"))
            and record.get("identity") is collection
        ):
            return True
    return False

def register_translation(package_id: str, payload: Any) -> bool:
    if bpy is None or not str(package_id):
        return False
    translations = getattr(getattr(bpy, 'app', None), 'translations', None)
    native_register = getattr(translations, 'register', None)
    native_unregister = getattr(translations, 'unregister', None)
    if not callable(native_register) or not callable(native_unregister):
        return False
    package_id = str(package_id)
    identity = (package_id, payload)
    try:
        native_register(package_id, payload)
    except Exception:
        # Never unregister a pre-existing/foreign package registration to make room.
        return False
    def _remove_translation(_identity: Any) -> None:
        native_unregister(package_id)
    _append_record('translation', identity, _remove_translation, package_id=package_id)
    return True


def unregister_translation(package_id: str) -> bool:
    package_id = str(package_id)
    for record in reversed(tuple(_records())):
        identity = record.get('identity')
        if record.get('kind') == 'translation' and isinstance(identity, tuple) and identity and identity[0] == package_id:
            ok = _remove_record(record)
            if ok:
                _store()['records'] = [item for item in _records() if item is not record]
            return ok
    return False



_ATTRIBUTE_MISSING = object()


def _is_same_package_callable_18168(value: Any) -> bool:
    if not callable(value):
        return False
    module_name = str(getattr(value, "__module__", "") or "")
    package_root = str(__package__ or "")
    return bool(package_root and (module_name == package_root or module_name.startswith(package_root + ".")))


def _is_transaction_method_attr_18168(owner: Any, attr_name: str) -> bool:
    """Return True only for Smart UV operator transaction method slots.

    During an in-process drop-install/package reload, Blender can keep old
    SmartUV classes and ownership records alive while the new package installs
    a same-package wrapper on ``invoke``/``modal``/``cancel``.  Those method
    slots are owned lifecycle boundaries and must be idempotently recoverable.
    Foreign callables remain fail-closed.
    """
    if not isinstance(owner, type):
        return False
    if str(attr_name) not in {"invoke", "modal", "cancel"}:
        return False
    bl_idname = str(getattr(owner, "bl_idname", "") or "")
    module_name = str(getattr(owner, "__module__", "") or "")
    package_root = str(__package__ or "")
    return bool(
        bl_idname.startswith("smart_uv_suite.")
        and package_root
        and (module_name == package_root or module_name.startswith(package_root + "."))
    )


def _is_recoverable_transaction_attr_18168(owner: Any, attr_name: str, value: Any) -> bool:
    if not isinstance(owner, type):
        return False
    if not str(attr_name).startswith("_smart_uv_18168_") and not _is_transaction_method_attr_18168(owner, attr_name):
        return False
    if value is _ATTRIBUTE_MISSING or value is None or isinstance(value, bool):
        return True
    return _is_same_package_callable_18168(value)


def patch_attribute(owner: Any, name: str, value: Any) -> Any:
    """Patch one explicitly supplied owned attribute and ledger the exact value.

    Teardown restores the captured previous value only while the attribute still
    contains the exact value installed by this call.  A foreign replacement is
    never overwritten.  The returned opaque token is the sole removal key.
    """
    if owner is None or not str(name):
        return None
    attr_name = str(name)
    try:
        previous = getattr(owner, attr_name) if hasattr(owner, attr_name) else _ATTRIBUTE_MISSING
        setattr(owner, attr_name, value)
    except Exception:
        return None
    token = object()

    def _restore_attribute(_identity: Any) -> None:
        current = getattr(owner, attr_name) if hasattr(owner, attr_name) else _ATTRIBUTE_MISSING
        if current is value:
            if previous is _ATTRIBUTE_MISSING:
                delattr(owner, attr_name)
            else:
                setattr(owner, attr_name, previous)
            return
        # Another exact owned layer may already have restored this value.
        if previous is _ATTRIBUTE_MISSING and current is _ATTRIBUTE_MISSING:
            return
        if previous is not _ATTRIBUTE_MISSING and current is previous:
            return
        if (
            _is_recoverable_transaction_attr_18168(owner, attr_name, current)
            and _is_recoverable_transaction_attr_18168(owner, attr_name, value)
            and _is_recoverable_transaction_attr_18168(owner, attr_name, previous)
        ):
            if previous is _ATTRIBUTE_MISSING:
                if hasattr(owner, attr_name):
                    delattr(owner, attr_name)
            else:
                setattr(owner, attr_name, previous)
            return
        raise RuntimeError(f"attribute ownership changed before teardown: {attr_name}")

    _append_record(
        "attribute_patch", token, _restore_attribute,
        owner=owner, name=attr_name, installed=value, previous=previous,
    )
    return token


def unpatch_attribute(token: Any) -> bool:
    if token is None:
        return False
    for record in reversed(tuple(_records())):
        if record.get("kind") == "attribute_patch" and record.get("identity") is token:
            ok = _remove_record(record)
            if ok:
                _store()["records"] = [item for item in _records() if item is not record]
            return ok
    return True

def register_property(owner: Any, name: str, value: Any) -> bool:
    if owner is None or not str(name):
        return False
    name = str(name)
    try:
        if hasattr(owner, name):
            return False
        setattr(owner, name, value)
    except Exception:
        return False

    def _remove_property(identity: Any) -> None:
        prop_owner, prop_name = identity
        if hasattr(prop_owner, prop_name):
            delattr(prop_owner, prop_name)

    _append_record("property", (owner, name), _remove_property, owner=owner, name=name)
    return True


def unregister_property(owner: Any, name: str) -> bool:
    name = str(name)
    for record in reversed(tuple(_records())):
        identity = record.get("identity")
        if record.get("kind") == "property" and isinstance(identity, tuple) and len(identity) == 2 and identity[0] is owner and str(identity[1]) == name:
            ok = _remove_record(record)
            if ok:
                _store()["records"] = [item for item in _records() if item is not record]
            return ok
    return False


def new_owner_uuid() -> str:
    return uuid.uuid4().hex


def mark_datablock(datablock: Any, owner_uuid: str) -> bool:
    generation = current_generation()
    if datablock is None or not str(owner_uuid):
        return False
    for record in _records():
        if _datablock_record_matches(record, datablock, generation):
            return datablock_is_exact_owned(datablock, owner_uuid, generation)
    try:
        datablock["smart_uv_owner_family"] = OWNER_FAMILY
        datablock["smart_uv_owner_token"] = _owner_token(generation)
        datablock["smart_uv_owner_uuid"] = str(owner_uuid)
        datablock["smart_uv_generation"] = generation
    except Exception:
        return False
    _append_record("datablock", datablock, None, owner_uuid=str(owner_uuid))
    return True


def _datablock_record_matches(record: dict[str, Any], datablock: Any, generation: int) -> bool:
    return (
        record.get("kind") == "datablock"
        and not record.get("removed")
        and record.get("generation") == generation
        and _record_owned(record)
        and _same_rna_pointer(record.get("identity"), datablock)
    )


def datablock_is_exact_owned(datablock: Any, owner_uuid: str, generation: int | None = None) -> bool:
    generation = current_generation() if generation is None else int(generation)
    try:
        return (
            datablock is not None
            and datablock.get("smart_uv_owner_family") == OWNER_FAMILY
            and datablock.get("smart_uv_owner_uuid") == str(owner_uuid)
            and int(datablock.get("smart_uv_generation", -1)) == generation
            and any(
                _datablock_record_matches(record, datablock, generation)
                and record.get("meta", {}).get("owner_uuid") == str(owner_uuid)
                and record.get("owner_token") == datablock.get("smart_uv_owner_token")
                for record in _records()
            )
        )
    except Exception:
        return False


def owned_datablocks() -> tuple[tuple[Any, str, int], ...]:
    out: list[tuple[Any, str, int]] = []
    for record in _records():
        if record.get("kind") != "datablock" or bool(record.get("removed")):
            continue
        datablock = record.get("identity")
        generation = int(record.get("generation", -1))
        owner_uuid = str(record.get("meta", {}).get("owner_uuid", ""))
        if owner_uuid and datablock_is_exact_owned(datablock, owner_uuid, generation):
            out.append((datablock, owner_uuid, generation))
    return tuple(out)


def retire_removed_datablock(datablock: Any) -> None:
    for record in _records():
        if record.get("kind") == "datablock" and record.get("identity") is datablock:
            record["removed"] = True


def ledger_snapshot() -> dict[str, Any]:
    counts: dict[str, int] = {}
    for record in _records():
        if bool(record.get("removed")):
            continue
        kind = str(record.get("kind", "unknown"))
        counts[kind] = counts.get(kind, 0) + 1
    return {
        "owner_family": OWNER_FAMILY,
        "owner_token": OWNER_TOKEN,
        "generation": current_generation(),
        "active": is_active(),
        "records": counts,
        "total": sum(counts.values()),
    }
