"""Implement the inspect wand public UV operations."""

import bpy


def inspect_wand_bridge(context, op):
    return 'FINISHED' in bpy.ops.uv.suv_similarity_bridge(mode=op.mode or 'SIMILAR')


def build_handlers(api):
    return {

        "smart_uv_suite.inspect_wand_bridge": api.Handler(inspect_wand_bridge, 'Select or stack UV islands by similarity to the active island.', 'アクティブアイランドとの類似度でUVアイランドを選択・スタックします。'),

    }
