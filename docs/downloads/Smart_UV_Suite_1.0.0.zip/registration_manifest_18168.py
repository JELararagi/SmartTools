﻿# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Single authoritative Smart UV Suite 1.8.169 registration transaction."""
from __future__ import annotations

from dataclasses import dataclass
import inspect
import json
import sys
from typing import Any, Callable

import bpy

from . import ownership_runtime_18168 as ownership
from . import npanel_persistence
from . import npanel_body_1881
from . import required_runtime_access
from . import proxy_cleanup_1876
from . import uv_gizmo_grip_fix
from . import smartuv_uv_ownership_18224
from . import context_guard

STATE_INACTIVE = "INACTIVE"
STATE_REGISTERING = "REGISTERING"
STATE_ACTIVE = "ACTIVE"
STATE_UNREGISTERING = "UNREGISTERING"
STATE_FAILED = "FAILED"

_STATE = STATE_INACTIVE
_STEPS: list["Step"] = []
_PACKAGE_GLOBALS: dict[str, Any] | None = None
_LEGACY_REGISTER: Callable[[], Any] | None = None
_LEGACY_UNREGISTER: Callable[[], Any] | None = None
_FINALIZING = False
_WORKSPACE_RUNTIME_PATCH_TOKENS: list[Any] = []
_AUTHORITY_SEQUENCE = 0
_AUTHORITY_TRACE: list[dict[str, Any]] = []
_FEATURE_CACHE_KEY = "_JELARARAGI_SMART_UV_SUITE_18194_OPERATION_FEATURE_STATE"
_WM_FEATURE_CACHE_KEY = "_smart_uv_suite_18194_operation_feature_state"
_LAST_FEATURE_STATE: dict[str, bool] = {}
_SMART_UV_MIGRATED_UV_EDITOR_CLASS_NAMES = (
    "SMARTUVSUITE_OT_instant_select_drag_move",
    "SMARTUVSUITE_OT_instant_select_modal_session",
    "SMARTUVSUITE_OT_scale_tool_background_select",
    "JELARARAGI_OT_uv_gizmo_grip_fix_grab",
    "SMARTUVSUITE_OT_cursor_to_hover_uv_vertex",
    "SMARTUVSUITE_OT_vertex_align_action",
    "SMART_UV_SUITE_OT_vertex_straighten_selected",
    "SMART_UV_SUITE_OT_vertex_even_straighten_selected",
    "SMART_UV_SUITE_OT_vertex_set_flow_selected",
    # Export UV Layout is part of the owned registration boundary: the exact
    # invoke-arity workspace gate and _verify_export_uv_layout_runtime require
    # this class to be wrapped, so its absence here fails registration closed.
    "SMARTUVSUITE_OT_export_uv_layout",
)
_TRANSACTION_OPERATOR_IDS = frozenset({
    "smart_uv_suite.instant_select_drag_move",
    "smart_uv_suite.instant_select_modal_session",
    "smart_uv_suite.scale_tool_background_select",
    "smart_uv_suite.uv_gizmo_grip_fix_grab",
})
_EXPORT_UV_LAYOUT_OPERATOR_ID = "smart_uv_suite.export_uv_layout"

# 1.8.243: the public operator classes a completed register must leave
# registered on this exact package's own class objects.  ``_verify_required_
# surface()`` previously covered only the three compatibility operators in
# ``required_runtime_access`` plus the 11 root panels, so a register that
# returned without raising while the public Execute Unwrap operator was absent
# was indistinguishable from a good one.  The outer registration boundary calls
# this check only after ``smartuv_operation_runtime_18228`` has installed these
# classes.  Blender exposes custom operators through ``bpy.ops`` and their RNA
# identifier rather than the Python class name on ``bpy.types``; the exact own
# class still must report ``is_registered``.
_PUBLIC_OPERATOR_CLASS_NAMES = (
    "SMARTUVSUITE_OT_unwrap_auto_run",
    "SMARTUVSUITE_OT_unwrap_auto_action",
)


# The complete in-session feature-state key set.  Every cache reader and
# writer uses this one tuple so a key can never be stored by one layer and
# silently dropped by another (1.8.230: uv_smart_grs removed with the
# UV Smart G-R-S feature; the uv_* keys joined the legacy trio).
_FEATURE_STATE_KEYS = (
    "instant_select",
    "gizmo_grip",
    "axis_memory",
    "uv_crossing_edges",
    "uv_crossing_faces",
    "uv_prop_cursor",
)


def _driver_namespace() -> dict[str, Any] | None:
    try:
        namespace = getattr(getattr(bpy, "app", None), "driver_namespace", None)
        return namespace if isinstance(namespace, dict) else None
    except Exception:
        return None


def _feature_cache_anchor() -> dict[str, Any] | None:
    """Process-lifetime home for the feature-state cache.

    ``bpy.app.driver_namespace`` is shared process state that a lifecycle audit
    reads, so the cache is released from it at unregister (see
    ``_release_feature_state_cache``).  The same object is kept beside the
    ownership ledger's anchor, which no audit of Blender state can see, so the
    retained-settings contract loses nothing by that release.
    """
    try:
        return ownership.anchor_store()
    except Exception:
        return None


def _cached_feature_state() -> dict[str, bool]:
    value = None
    namespace = _driver_namespace()
    if namespace is not None:
        value = namespace.get(_FEATURE_CACHE_KEY)
    if not isinstance(value, dict):
        anchor = _feature_cache_anchor()
        if isinstance(anchor, dict):
            value = anchor.get(_FEATURE_CACHE_KEY)
    if not isinstance(value, dict):
        return {}
    out: dict[str, bool] = {}
    for name in _FEATURE_STATE_KEYS:
        if name in value:
            out[name] = bool(value.get(name))
    return out


def _release_feature_state_cache() -> bool:
    """Move this module's own feature-state cache out of driver_namespace.

    Only the exact key this module publishes is touched, and the value is
    carried into the process-lifetime anchor first, so every reader keeps the
    state it had.  Foreign driver_namespace entries are never read or written.
    """
    namespace = _driver_namespace()
    if namespace is None:
        return False
    value = namespace.get(_FEATURE_CACHE_KEY)
    if not isinstance(value, dict):
        return False
    anchor = _feature_cache_anchor()
    if isinstance(anchor, dict):
        anchor[_FEATURE_CACHE_KEY] = dict(value)
    namespace.pop(_FEATURE_CACHE_KEY, None)
    return True


def _last_feature_state() -> dict[str, bool]:
    try:
        return {
            name: bool(_LAST_FEATURE_STATE.get(name))
            for name in _FEATURE_STATE_KEYS
            if name in _LAST_FEATURE_STATE
        }
    except Exception:
        return {}


def _window_manager_feature_state() -> dict[str, bool]:
    try:
        wm = getattr(getattr(bpy, "context", None), "window_manager", None)
    except Exception:
        wm = None
    if wm is None:
        return {}
    try:
        raw = wm.get(_WM_FEATURE_CACHE_KEY)
    except Exception:
        raw = None
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except Exception:
            return {}
    if not isinstance(raw, dict):
        return {}
    out: dict[str, bool] = {}
    for name in _FEATURE_STATE_KEYS:
        if name in raw:
            out[name] = bool(raw.get(name))
    return out


def _persisted_feature_state() -> dict[str, bool]:
    try:
        state = npanel_persistence.load_state(force=True)
    except Exception:
        return {}
    try:
        workspace = dict(state.get("workspace", {}) or {})
    except Exception:
        return {}
    mapping = {
        "instant_select": "operation_instant_select_enabled",
        "gizmo_grip": "operation_uv_gizmo_grip_fix_enabled",
        "axis_memory": "operation_axis_constraint_memory_enabled",
        "uv_crossing_edges": "operation_uv_crossing_select_edges_enabled",
        "uv_crossing_faces": "operation_uv_crossing_select_faces_enabled",
        "uv_prop_cursor": "operation_uv_proportional_cursor_keymap_enabled",
    }
    out: dict[str, bool] = {}
    for name, key in mapping.items():
        if key in workspace:
            out[name] = bool(workspace.get(key))
    return out


def _store_feature_state(feature_state: dict[str, bool]) -> None:
    global _LAST_FEATURE_STATE
    _LAST_FEATURE_STATE = {
        name: bool(feature_state.get(name)) for name in _FEATURE_STATE_KEYS
    }
    namespace = _driver_namespace()
    if namespace is not None:
        namespace[_FEATURE_CACHE_KEY] = dict(_LAST_FEATURE_STATE)
    anchor = _feature_cache_anchor()
    if isinstance(anchor, dict):
        anchor[_FEATURE_CACHE_KEY] = dict(_LAST_FEATURE_STATE)
    try:
        wm = getattr(getattr(bpy, "context", None), "window_manager", None)
        if wm is not None:
            wm[_WM_FEATURE_CACHE_KEY] = json.dumps(
                dict(_LAST_FEATURE_STATE), sort_keys=True, separators=(",", ":")
            )
    except Exception:
        pass


def _feature_cache_store_allowed(
    *,
    reason: str,
    feature_state: dict[str, bool],
    cached: dict[str, bool],
    used_cached: bool,
) -> bool:
    """Do not let lifecycle default-false sync erase explicit UI choices."""
    if used_cached:
        return True
    if any(bool(feature_state.get(name)) for name in _FEATURE_STATE_KEYS):
        return True
    reason_text = str(reason or "")
    if reason_text.startswith("ui_") or reason_text in {"public_update", "package_sync_bridge", "compat_finalize"}:
        return True
    if any(bool(cached.get(name)) for name in _FEATURE_STATE_KEYS):
        return False
    return True


def _settings_feature_state(package_globals: dict[str, Any] | None, context: Any = None) -> dict[str, bool]:
    if not isinstance(package_globals, dict):
        return {}
    settings = _workspace_settings(package_globals, context or getattr(bpy, "context", None))
    if settings is None:
        return {}
    return {
        "instant_select": bool(getattr(settings, "operation_instant_select_enabled", False)),
        "gizmo_grip": bool(getattr(settings, "operation_uv_gizmo_grip_fix_enabled", False)),
        "axis_memory": bool(getattr(settings, "operation_axis_constraint_memory_enabled", False)),
        "uv_crossing_edges": bool(getattr(settings, "operation_uv_crossing_select_edges_enabled", False)),
        "uv_crossing_faces": bool(getattr(settings, "operation_uv_crossing_select_faces_enabled", False)),
        "uv_prop_cursor": bool(getattr(settings, "operation_uv_proportional_cursor_keymap_enabled", False)),
    }


@dataclass(frozen=True)
class Step:
    name: str
    unregister: Callable[[], Any]


def state() -> str:
    return _STATE


def _trace(event: str, **details: Any) -> None:
    global _AUTHORITY_SEQUENCE
    _AUTHORITY_SEQUENCE += 1
    _AUTHORITY_TRACE.append({
        "sequence": _AUTHORITY_SEQUENCE,
        "event": str(event),
        "state": _STATE,
        **details,
    })
    del _AUTHORITY_TRACE[:-64]


def _exception_chain(exc: BaseException) -> tuple[str, ...]:
    chain: list[str] = []
    seen: set[int] = set()
    current: BaseException | None = exc
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        chain.append(f"{type(current).__name__}: {current}")
        current = current.__cause__ or current.__context__
    return tuple(chain)


def _record(name: str, unregister: Callable[[], Any]) -> None:
    _STEPS.append(Step(str(name), unregister))


def _cleanup_preview_owner_modules() -> dict[str, Any]:
    """Unload exact Smart UV preview globals before ledger teardown.

    A failed register can abort after common/ui/stable_ui created Blender
    ImagePreviewCollection instances but before their normal unregister step
    runs.  The ownership ledger still removes exact records, but the module
    globals must also be cleared so Blender never later finalizes a live
    ImagePreviewCollection and emits ResourceWarning.
    """
    import sys

    owners = (
        ("common", "_PREVIEW_COLLECTION"),
        ("stable_ui", "_ICON_COLLECTION"),
        ("ui", "_SUV_ICON_COLLECTION"),
    )
    result: dict[str, Any] = {"owners": {}, "failures": []}
    package = str(__package__ or "")
    native_remove = None
    try:
        import bpy.utils.previews as _previews  # type: ignore
        native_remove = getattr(_previews, "remove", None)
    except Exception:
        native_remove = None
    for module_name, global_name in owners:
        module = sys.modules.get(f"{package}.{module_name}") if package else None
        if module is None:
            result["owners"][module_name] = {"loaded": False, "global": global_name}
            continue
        collection = getattr(module, global_name, None)
        before = bool(collection is not None)
        failure = None
        method = "none"
        owned_record = False
        if collection is not None:
            try:
                owned_record = bool(ownership.preview_collection_is_owned(collection))
            except Exception as exc:
                failure = f"ownership check failed: {type(exc).__name__}: {exc}"
            removed = False
            if failure is None and owned_record:
                try:
                    removed = bool(ownership.unregister_preview_collection(collection))
                    method = "ledger"
                except Exception as exc:
                    failure = f"ledger remove failed: {type(exc).__name__}: {exc}"
            if failure is None and not removed:
                if callable(native_remove):
                    try:
                        native_remove(collection)
                        removed = True
                        method = "native_exact_owner_global"
                    except ReferenceError:
                        removed = True
                        method = "native_reference_gone"
                    except KeyError:
                        removed = True
                        method = "native_already_closed"
                    except Exception as exc:
                        failure = f"native exact owner remove failed: {type(exc).__name__}: {exc}"
                else:
                    failure = "native preview remove unavailable"
            if removed:
                try:
                    setattr(module, global_name, None)
                except Exception as exc:
                    failure = f"global clear failed after {method}: {type(exc).__name__}: {exc}"
        after = bool(getattr(module, global_name, None) is not None)
        if failure or after:
            result["failures"].append({
                "module": module_name,
                "global": global_name,
                "owned_record": owned_record,
                "method": method,
                "failure": failure,
                "before": before,
                "after": after,
            })
        result["owners"][module_name] = {
            "loaded": True,
            "global": global_name,
            "before": before,
            "after": after,
            "owned_record": owned_record,
            "method": method,
            "failure": failure,
        }
    return result


def _rollback() -> None:
    step_errors: list[str] = []
    preview_cleanup_before = _cleanup_preview_owner_modules()
    for step in reversed(tuple(_STEPS)):
        try:
            step.unregister()
        except Exception as exc:
            step_errors.append(f"{step.name}: {type(exc).__name__}: {exc}")
    _STEPS.clear()
    preview_cleanup_after = _cleanup_preview_owner_modules()
    cleanup = ownership.unregister_owned_runtime()
    ownership.mark_active(False)
    preview_remaining = 0
    try:
        preview_remaining = int(ownership.ledger_snapshot().get("records", {}).get("preview_collection", 0) or 0)
    except Exception:
        preview_remaining = -1
    failures = list(step_errors)
    preview_failures = tuple(preview_cleanup_before.get("failures", ())) + tuple(preview_cleanup_after.get("failures", ()))
    if preview_failures:
        failures.append(f"preview owner cleanup failed: {preview_failures!r}")
    if int(cleanup.get("failed", 0) or 0) or preview_remaining:
        failures.append(
            f"owned runtime cleanup incomplete: cleanup={cleanup!r}, preview_remaining={preview_remaining}"
        )
    if failures:
        raise RuntimeError("Smart UV rollback cleanup failed: " + "; ".join(failures))


def verify_public_operator_surface() -> dict[str, bool]:
    """Assert Blender still exposes this package's own public operator classes.

    Blender does not publish these custom Python class names as attributes on
    ``bpy.types``.  The exact own class must instead be registered, and its
    ``bl_rna`` identifier must agree with the public ``bpy.ops`` RNA surface.
    """
    package_globals = _PACKAGE_GLOBALS if isinstance(_PACKAGE_GLOBALS, dict) else {}
    result: dict[str, bool] = {}
    for name in _PUBLIC_OPERATOR_CLASS_NAMES:
        cls = package_globals.get(name)
        try:
            op_id = str(getattr(cls, "bl_idname", "") or "")
            namespace, separator, operator = op_id.partition(".")
            ops_namespace = getattr(getattr(bpy, "ops", None), namespace, None)
            ops_callable = getattr(ops_namespace, operator, None) if separator else None
            ops_rna = ops_callable.get_rna_type() if ops_callable is not None else None
            class_rna = getattr(cls, "bl_rna", None)
            expected_identifier = str(getattr(class_rna, "identifier", "") or "")
            observed_identifier = str(getattr(ops_rna, "identifier", "") or "")
            result[name] = bool(
                isinstance(cls, type)
                and bool(getattr(cls, "is_registered", False))
                and expected_identifier
                and observed_identifier == expected_identifier
            )
        except Exception:
            result[name] = False
    missing = [name for name, ok in result.items() if not ok]
    if missing:
        raise RuntimeError(
            "Smart UV public operators unavailable after register: " + ", ".join(missing))
    return result


def _verify_required_surface() -> dict[str, Any]:
    required = required_runtime_access.verify_registered()
    roots = {}
    for cls in npanel_body_1881.ROOTS:
        try:
            roots[cls.__name__] = bool(getattr(cls, "is_registered", False))
        except Exception:
            roots[cls.__name__] = False
    missing_roots = [name for name, ok in roots.items() if not ok]
    if missing_roots:
        raise RuntimeError("Smart UV root panels unavailable: " + ", ".join(missing_roots))
    logical_mapping = {}
    for cls in npanel_body_1881.ROOTS:
        for editor in cls._smart_tools_manager_logical_mapping:
            if editor in logical_mapping:
                raise RuntimeError(f"Smart UV has duplicate root panels for {editor}")
            logical_mapping[editor] = cls.bl_space_type
    if (logical_mapping != npanel_body_1881.LOGICAL_TO_PHYSICAL
            or len(logical_mapping) != 17
            or len(set(logical_mapping.values())) != 11):
        raise RuntimeError("Smart UV 11/17 panel mapping contract is incomplete")
    return {"required_operators": required, "roots": roots}


def _patch_modal_transactions(package_globals: dict[str, Any], *, force: bool) -> tuple[str, ...]:
    from . import modal_state_18168 as modal_state
    patched = list(modal_state.install(package_globals, force=force))
    try:
        from . import interaction_1872
        cls = interaction_1872.SMARTUVSUITE_OT_scale_tool_background_select
        if modal_state.patch_operator(cls, force=force, restore_tool_on_finish=True):
            patched.append(cls.__name__)
    except Exception:
        pass
    try:
        cls = uv_gizmo_grip_fix.JELARARAGI_OT_uv_gizmo_grip_fix_grab
        if modal_state.patch_operator(cls, force=force, restore_tool_on_finish=True):
            patched.append(cls.__name__)
    except Exception:
        pass
    return tuple(dict.fromkeys(patched))


def _workspace_runtime_allowed(context: Any) -> bool:
    return bool(context_guard.smart_uv_runtime_context_allowed(context))


def _workspace_runtime_unpatch() -> bool:
    ok = True
    for token in reversed(tuple(_WORKSPACE_RUNTIME_PATCH_TOKENS)):
        if not ownership.unpatch_attribute(token):
            ok = False
    _WORKSPACE_RUNTIME_PATCH_TOKENS.clear()
    return ok


def _patch_workspace_method(cls: type, method_name: str, original: Callable[..., Any]) -> bool:
    marker_name = f"_smart_uv_18180_workspace_{method_name}"
    current_marker = getattr(cls, marker_name, None)
    if callable(current_marker) and getattr(cls, method_name, None) is current_marker:
        return True

    original_cancel = getattr(cls, "cancel", None)
    operator_id = str(getattr(cls, "bl_idname", "") or "")

    if method_name == "modal":
        def workspace_guard(self, context, event):
            if not _workspace_runtime_allowed(context):
                # Transaction-owned modals are handled by modal_state_18168,
                # which remains the outer wrapper and performs the exact UV /
                # selection rollback.  Other modal operators receive their own
                # pre-existing cancel callback exactly once.
                if not bool(getattr(type(self), "_smart_uv_18168_transactional", False)):
                    try:
                        if callable(original_cancel):
                            original_cancel(self, context)
                    except Exception:
                        pass
                return {"CANCELLED"}
            return original(self, context, event)
    elif method_name == "invoke":
        # Blender 5.1 records the callable signature of invoke callbacks.  A
        # varargs workspace wrapper can be dispatched without an event and then
        # falls into execute(), which breaks event-owned public shortcuts such
        # as Export UV Layout and cursor-to-hover-vertex.  Keep the workspace
        # gate, but expose exact invoke arity and forward the event when it is
        # present; only an explicit no-event invoke falls back to execute().
        def workspace_guard(self, context, event=None):
            if not _workspace_runtime_allowed(context):
                return {"PASS_THROUGH"}
            if event is None:
                execute = getattr(type(self), "execute", None)
                if callable(execute):
                    try:
                        return execute(self, context)
                    except TypeError:
                        return {"PASS_THROUGH"}
                return {"PASS_THROUGH"}
            return original(self, context, event)
    else:
        def workspace_guard(self, context, *args, **kwargs):
            if not _workspace_runtime_allowed(context):
                return {"CANCELLED"}
            return original(self, context, *args, **kwargs)

    workspace_guard.__name__ = f"_smart_uv_18180_{method_name}_{getattr(cls, '__name__', 'operator')}"
    workspace_guard._smart_uv_18180_workspace_runtime_gate = True
    workspace_guard._smart_uv_18180_runtime_original = original
    batch: list[Any] = []
    for name, value in ((method_name, workspace_guard), (marker_name, workspace_guard)):
        token = ownership.patch_attribute(cls, name, value)
        if token is None:
            for old in reversed(batch):
                ownership.unpatch_attribute(old)
            return False
        batch.append(token)
    _WORKSPACE_RUNTIME_PATCH_TOKENS.extend(batch)
    return True


def _verify_export_uv_layout_runtime(package_globals: dict[str, Any]) -> dict[str, Any]:
    cls = package_globals.get("SMARTUVSUITE_OT_export_uv_layout") if isinstance(package_globals, dict) else None
    if not isinstance(cls, type):
        raise RuntimeError("Smart UV export file-browser operator class unavailable")
    if str(getattr(cls, "bl_idname", "") or "") != _EXPORT_UV_LAYOUT_OPERATOR_ID:
        raise RuntimeError("Smart UV export file-browser operator id mismatch")
    invoke = getattr(cls, "invoke", None)
    original = getattr(invoke, "_smart_uv_18180_runtime_original", None)
    if not (
        callable(invoke)
        and bool(getattr(invoke, "_smart_uv_18180_workspace_runtime_gate", False))
        and callable(original)
    ):
        raise RuntimeError("Smart UV export file-browser invoke is not inside the workspace gate")
    code = getattr(invoke, "__code__", None)
    flags = int(getattr(code, "co_flags", 0) or 0) if code is not None else 0
    if code is None or int(getattr(code, "co_argcount", 0) or 0) != 3 or (flags & 0x04) or (flags & 0x08):
        raise RuntimeError("Smart UV export file-browser invoke wrapper has invalid Blender RNA arity")
    try:
        source = inspect.getsource(original)
    except Exception:
        source = ""
    if "fileselect_add" not in source or "RUNNING_MODAL" not in source:
        raise RuntimeError("Smart UV export file-browser original invoke no longer opens Blender file browser")
    if "return self.execute(context)" in source:
        raise RuntimeError("Smart UV export file-browser original invoke still has silent execute fallback")
    return {
        "operator": _EXPORT_UV_LAYOUT_OPERATOR_ID,
        "wrapper": str(getattr(invoke, "__name__", "")),
        "original_module": str(getattr(original, "__module__", "")),
        "original_qualname": str(getattr(original, "__qualname__", "")),
    }


def _exact_workspace_runtime_classes(package_globals: dict[str, Any]) -> tuple[type, ...]:
    """Return exact package-global classes that must be workspace-gated.

    The migrated UV-editor ownership surface is intentionally frozen here so
    registration can fail closed when any exact class is missing, replaced, or
    duplicated.  Do not scan bpy.types or unrelated modules.
    """
    classes: list[type] = []
    missing: list[str] = []
    for name in _SMART_UV_MIGRATED_UV_EDITOR_CLASS_NAMES:
        cls = package_globals.get(str(name)) if isinstance(package_globals, dict) else None
        if isinstance(cls, type) and all(cls is not existing for existing in classes):
            classes.append(cls)
        else:
            missing.append(str(name))
    if missing:
        raise RuntimeError("Smart UV migrated UV-editor inventory unresolved: " + ", ".join(missing))
    return tuple(classes)


def _patch_workspace_runtime_operators(package_globals: dict[str, Any] | None = None) -> dict[str, Any]:
    """Gate exact owned Smart UV Operators; never scan bpy.types or modules."""
    patched: dict[str, tuple[str, ...]] = {}
    failures: list[str] = []
    exact_classes = _exact_workspace_runtime_classes(package_globals or _PACKAGE_GLOBALS or {})
    exact_names = tuple(sorted(str(name) for name in _SMART_UV_MIGRATED_UV_EDITOR_CLASS_NAMES))
    if tuple(sorted(str(getattr(cls, "__name__", "")) for cls in exact_classes)) != exact_names:
        raise RuntimeError(
            "Smart UV migrated UV-editor inventory mismatch: "
            f"{tuple(sorted(str(getattr(cls, '__name__', '')) for cls in exact_classes))!r}"
        )
    for cls in exact_classes:
        try:
            if not isinstance(cls, type) or not issubclass(cls, bpy.types.Operator):
                continue
        except Exception:
            continue
        operator_id = str(getattr(cls, "bl_idname", "") or "")
        methods: list[str] = []
        for method_name in ("invoke", "execute", "modal"):
            original = getattr(cls, method_name, None)
            if not callable(original):
                continue
            # The transaction layer owns entry/cancel for these modal classes
            # and performs the same central context check itself.  Execute, if
            # present, is still gated here.
            if operator_id in _TRANSACTION_OPERATOR_IDS and method_name in {"invoke", "modal"}:
                continue
            if _patch_workspace_method(cls, method_name, original):
                methods.append(method_name)
            else:
                failures.append(f"{operator_id or cls.__name__}.{method_name}")
        if methods:
            patched[operator_id or cls.__name__] = tuple(methods)
    if failures:
        _workspace_runtime_unpatch()
        raise RuntimeError("Smart UV workspace runtime gate failed: " + ", ".join(failures))
    if not patched:
        raise RuntimeError("Smart UV workspace runtime gate found no owned operators")
    return {
        "operators": len(patched),
        "methods": sum(len(methods) for methods in patched.values()),
        "ids": tuple(sorted(patched)),
        "explicit_classes": tuple(sorted(str(getattr(cls, "__name__", cls)) for cls in exact_classes)),
    }


def _workspace_settings(package_globals: dict[str, Any], context: Any = None) -> Any:
    try:
        settings = getattr(getattr(context, "scene", None), "suv_workspace", None)
        if settings is not None:
            return settings
    except Exception:
        pass
    try:
        fn = package_globals.get("_sus_1652_ws")
        if callable(fn):
            return fn(context or getattr(bpy, "context", None))
    except Exception:
        pass
    try:
        return getattr(getattr(getattr(bpy, "context", None), "scene", None), "suv_workspace", None)
    except Exception:
        return None


def _synchronize_owned_runtime(package_globals: dict[str, Any], context: Any = None, *, reason: str = "public_update") -> dict[str, bool]:
    """Create exact optional resources without calling any historical sync."""
    ctx = context or getattr(bpy, "context", None)
    settings = _workspace_settings(package_globals, ctx)
    instant = bool(getattr(settings, "operation_instant_select_enabled", False)) if settings is not None else False
    gizmo = bool(getattr(settings, "operation_uv_gizmo_grip_fix_enabled", False)) if settings is not None else False
    axis = bool(getattr(settings, "operation_axis_constraint_memory_enabled", False)) if settings is not None else False
    uv_crossing_edges = bool(getattr(settings, "operation_uv_crossing_select_edges_enabled", False)) if settings is not None else False
    uv_crossing_faces = bool(getattr(settings, "operation_uv_crossing_select_faces_enabled", False)) if settings is not None else False
    uv_prop_cursor = bool(getattr(settings, "operation_uv_proportional_cursor_keymap_enabled", False)) if settings is not None else False
    cached = _cached_feature_state()
    last = _last_feature_state()
    persisted = _persisted_feature_state()
    wm_cached = _window_manager_feature_state()
    fallback = cached if any(cached.values()) else (
        last if any(last.values()) else (
            wm_cached if any(wm_cached.values()) else persisted
        )
    )
    used_cached = False
    reason_text = str(reason or "")
    lifecycle_fallback_allowed = (
        reason_text in {"register_complete", "post_register_retained_settings"}
        or reason_text.startswith("readback_retained_")
    )
    # Apply the fallback only while every live toggle reads default-False (a
    # defaulted/unavailable settings block).  The uv_* toggles take part in
    # that judgement the same way the legacy trio does, so a restored
    # uv_prop_cursor/uv_crossing state no longer depends on one of the three
    # legacy features also being enabled.
    live_any = instant or gizmo or axis or uv_crossing_edges or uv_crossing_faces or uv_prop_cursor
    if lifecycle_fallback_allowed and not live_any and any(fallback.values()):
        instant = bool(fallback.get("instant_select", False))
        gizmo = bool(fallback.get("gizmo_grip", False))
        axis = bool(fallback.get("axis_memory", False))
        uv_crossing_edges = bool(fallback.get("uv_crossing_edges", False))
        uv_crossing_faces = bool(fallback.get("uv_crossing_faces", False))
        uv_prop_cursor = bool(fallback.get("uv_prop_cursor", False))
        used_cached = True

    from . import uv_immediate_drag_stability_18112 as direct_drag

    # Keymap construction is attempted before any registered class method is
    # replaced.  A Blender RNA failure therefore leaves the previous wrapper
    # identity intact, while each helper rolls back its own partial rows.
    # Each optional subsystem is guarded independently so one failing keymap
    # transaction cannot take down the sync of the remaining features (the
    # helpers roll back their own partial rows before raising).
    try:
        direct_drag._ensure_instant_keymaps(ctx, active=instant)
    except Exception as exc:
        _trace("owned_sync_instant_keymaps_failed", error=f"{type(exc).__name__}: {exc}")

    try:
        if gizmo:
            register_exact = getattr(uv_gizmo_grip_fix, "_sus_18168_register_keymap", None)
            if callable(register_exact):
                try:
                    uv_gizmo_grip_fix._SUS_18168_ENABLED = True
                except Exception:
                    pass
                register_exact()
            else:
                uv_gizmo_grip_fix.enable()
        else:
            unregister_exact = getattr(uv_gizmo_grip_fix, "_sus_18168_unregister_keymap", None)
            remove_actual = getattr(uv_gizmo_grip_fix, "_sus_18182_remove_actual_gizmo_rows", None)
            if callable(unregister_exact):
                try:
                    uv_gizmo_grip_fix._SUS_18168_ENABLED = False
                except Exception:
                    pass
                unregister_exact()
            elif callable(remove_actual):
                remove_actual()
            else:
                uv_gizmo_grip_fix.disable()
    except Exception as exc:
        _trace("owned_sync_gizmo_keymaps_failed", error=f"{type(exc).__name__}: {exc}")

    uv_ownership_runtime = smartuv_uv_ownership_18224.sync_from_settings(
        {
            "operation_uv_crossing_select_edges_enabled": uv_crossing_edges,
            "operation_uv_crossing_select_faces_enabled": uv_crossing_faces,
            "operation_uv_proportional_cursor_keymap_enabled": uv_prop_cursor,
        },
        ctx,
        reason=reason,
    )

    # Scale background selection is independent of the optional UV drag helpers.
    try:
        from . import interaction_1872
        interaction_1872._sync_scale_background_keymaps()
    except Exception as exc:
        _trace("owned_sync_scale_background_keymaps_failed", error=f"{type(exc).__name__}: {exc}")

    axis_sync = package_globals.get("_sus_update_axis_constraint_memory_timer")
    if callable(axis_sync):
        axis_sync(ctx)

    try:
        from . import stable_ui as _stable_ui
        # Several legacy registration layers invalidate the immutable operator
        # cache after the first panel install. Rebuild it once, after every
        # public and integrated operator is final, so foldouts and nested UI do
        # not mistake live RNA for missing operators.
        _stable_ui.register()
    except Exception:
        pass
    feature_state = {
        "instant_select": instant,
        "gizmo_grip": gizmo,
        "axis_memory": axis,
        "uv_crossing_edges": uv_crossing_edges,
        "uv_crossing_faces": uv_crossing_faces,
        "uv_prop_cursor": uv_prop_cursor,
        "uv_ownership_runtime": bool(uv_ownership_runtime),
        "scale_background": bool(instant or gizmo or axis),
    }
    if _feature_cache_store_allowed(reason=str(reason or ""), feature_state=feature_state, cached=cached, used_cached=used_cached):
        _store_feature_state(feature_state)
    return feature_state


def _owned_keymap_rows(operator_id: str) -> tuple[tuple[Any, Any], ...]:
    try:
        return tuple(ownership.owned_keymap_items(str(operator_id)))
    except Exception:
        return ()


def _actual_addon_keymap_rows(operator_id: str) -> tuple[tuple[Any, Any], ...]:
    try:
        wm = getattr(getattr(bpy, "context", None), "window_manager", None)
        keyconfig = getattr(getattr(wm, "keyconfigs", None), "addon", None)
        keymaps = getattr(keyconfig, "keymaps", None)
        if keymaps is None:
            return ()
        rows: list[tuple[Any, Any]] = []
        for keymap in keymaps:
            for kmi in tuple(getattr(keymap, "keymap_items", ()) or ()):
                if str(getattr(kmi, "idname", "") or "") == str(operator_id):
                    rows.append((keymap, kmi))
        return tuple(rows)
    except Exception:
        return ()


def _keymap_signature(keymap: Any, kmi: Any) -> tuple[Any, ...]:
    return (
        str(getattr(keymap, "name", "") or ""),
        str(getattr(kmi, "type", "") or ""),
        str(getattr(kmi, "value", "") or ""),
        bool(getattr(kmi, "shift", False)),
        bool(getattr(kmi, "ctrl", False)),
        bool(getattr(kmi, "alt", False)),
        bool(getattr(kmi, "oskey", False)),
        bool(getattr(kmi, "any", False)),
        bool(getattr(kmi, "active", False)),
    )


def _is_exact_gizmo_keymap_row(keymap: Any, kmi: Any) -> bool:
    return _keymap_signature(keymap, kmi) == (
        "Image Generic",
        "LEFTMOUSE",
        "PRESS",
        False,
        False,
        True,
        False,
        False,
        True,
    )


def _keymap_item_pointer(kmi: Any) -> int:
    try:
        pointer = int(kmi.as_pointer())
    except Exception as exc:
        raise RuntimeError("Smart UV keymap row has no stable RNA pointer") from exc
    if not pointer:
        raise RuntimeError("Smart UV keymap row has a null RNA pointer")
    return pointer


def _keymap_pointer_set(rows: tuple[tuple[Any, Any], ...], label: str) -> tuple[int, ...]:
    pointers = []
    for _keymap, kmi in rows:
        try:
            pointers.append(_keymap_item_pointer(kmi))
        except Exception as exc:
            raise RuntimeError(f"Smart UV {label} keymap pointer readback failed") from exc
    return tuple(sorted(pointers))


def _verify_final_interaction_runtime(package_globals: dict[str, Any], feature_state: dict[str, bool]) -> dict[str, Any]:
    instant_rows = _owned_keymap_rows("smart_uv_suite.instant_select_drag_move")
    gizmo_rows_getter = getattr(uv_gizmo_grip_fix, "_sus_18182_actual_gizmo_rows", None)
    gizmo_rows = tuple(gizmo_rows_getter() if callable(gizmo_rows_getter) else ())
    actual_instant_rows = _actual_addon_keymap_rows("smart_uv_suite.instant_select_drag_move")
    actual_gizmo_rows = tuple(
        (keymap, kmi)
        for keymap, kmi in _actual_addon_keymap_rows("smart_uv_suite.uv_gizmo_grip_fix_grab")
        if _is_exact_gizmo_keymap_row(keymap, kmi)
    )
    expected_instant = 20 if bool(feature_state.get("instant_select")) else 0
    expected_gizmo = 1 if bool(feature_state.get("gizmo_grip")) else 0
    if len(instant_rows) != expected_instant:
        raise RuntimeError(f"Smart UV instant keymap identity mismatch: {len(instant_rows)} != {expected_instant}")
    if _keymap_pointer_set(actual_instant_rows, "instant actual") != _keymap_pointer_set(instant_rows, "instant ledger"):
        raise RuntimeError("Smart UV instant keymap ledger pointers do not match the live addon keyconfig")
    if sorted(_keymap_signature(km, kmi) for km, kmi in actual_instant_rows) != sorted(
        _keymap_signature(km, kmi) for km, kmi in instant_rows
    ):
        raise RuntimeError("Smart UV instant keymap ledger does not match the live addon keyconfig")
    if instant_rows:
        expected_maps = {
            "UV Editor",
            "Image Editor Tool: Uv, Tweak",
            "Image Editor Tool: Uv, Tweak (fallback)",
            "Image Editor Tool: Uv, Select Box",
            "Image Editor Tool: Uv, Select Box (fallback)",
        }
        expected_modifiers = {
            (False, False), (True, False), (False, True), (True, True),
        }
        signatures: dict[str, set[tuple[bool, bool]]] = {}
        for km, kmi in instant_rows:
            map_name = str(getattr(km, "name", "") or "")
            signatures.setdefault(map_name, set()).add(
                (bool(getattr(kmi, "shift", False)), bool(getattr(kmi, "ctrl", False)))
            )
            if not (
                str(getattr(kmi, "type", "") or "") == "LEFTMOUSE"
                and str(getattr(kmi, "value", "") or "") == "PRESS"
                and not bool(getattr(kmi, "alt", False))
                and not bool(getattr(kmi, "oskey", False))
                and not bool(getattr(kmi, "any", False))
                and bool(getattr(kmi, "active", False))
            ):
                raise RuntimeError("Smart UV instant keymap contains a non-exact row")
        if (
            set(signatures) != expected_maps
            or any(value != expected_modifiers for value in signatures.values())
        ):
            raise RuntimeError(
                f"Smart UV instant keymap modifiers are incomplete or duplicated: {signatures!r}"
            )
    if len(gizmo_rows) != expected_gizmo:
        raise RuntimeError(f"Smart UV gizmo keymap identity mismatch: {len(gizmo_rows)} != {expected_gizmo}")
    if _keymap_pointer_set(actual_gizmo_rows, "gizmo actual") != _keymap_pointer_set(gizmo_rows, "gizmo ledger"):
        raise RuntimeError("Smart UV gizmo keymap ledger pointers do not match the live addon keyconfig")
    if sorted(_keymap_signature(km, kmi) for km, kmi in actual_gizmo_rows) != sorted(
        _keymap_signature(km, kmi) for km, kmi in gizmo_rows
    ):
        raise RuntimeError("Smart UV gizmo keymap ledger does not match the live addon keyconfig")
    if gizmo_rows:
        km, kmi = gizmo_rows[0]
        if not (
            str(getattr(km, "name", "") or "") == "Image Generic"
            and str(getattr(kmi, "type", "") or "") == "LEFTMOUSE"
            and str(getattr(kmi, "value", "") or "") == "PRESS"
            and bool(getattr(kmi, "alt", False))
            and not bool(getattr(kmi, "shift", False))
            and not bool(getattr(kmi, "ctrl", False))
            and not bool(getattr(kmi, "oskey", False))
            and not bool(getattr(kmi, "any", False))
            and bool(getattr(kmi, "active", False))
        ):
            raise RuntimeError("Smart UV gizmo keymap is not exact Alt+LEFTMOUSE PRESS")

    instant_cls = package_globals.get("SMARTUVSUITE_OT_instant_select_drag_move")
    if not isinstance(instant_cls, type):
        raise RuntimeError("Smart UV instant operator class unavailable")
    invoke_wrapper = getattr(instant_cls, "_smart_uv_18168_wrapper_invoke", None)
    modal_wrapper = getattr(instant_cls, "_smart_uv_18168_wrapper_modal", None)
    if getattr(instant_cls, "invoke", None) is not invoke_wrapper or getattr(instant_cls, "modal", None) is not modal_wrapper:
        raise RuntimeError("Smart UV transaction wrapper is not the final registered identity")
    original_invoke = getattr(instant_cls, "_smart_uv_18168_original_invoke", None)
    original_modal = getattr(instant_cls, "_smart_uv_18168_original_modal", None)
    if not (
        callable(original_invoke)
        and callable(original_modal)
        and bool(getattr(original_invoke, "_sus_18112_instant_drag", False))
        and bool(getattr(original_modal, "_sus_18112_instant_drag", False))
    ):
        raise RuntimeError("Smart UV direct-drag implementation is not inside the transaction wrapper")

    from . import uv_group_direction_align_1897 as sticky_align

    sticky_identities: dict[str, bool] = {}
    for class_name in sticky_align._STICKY_TARGET_CLASSES:
        cls = package_globals.get(class_name)
        execute = getattr(cls, "execute", None) if isinstance(cls, type) else None
        workspace_original = getattr(execute, "_smart_uv_18180_runtime_original", None)
        sticky_identities[class_name] = bool(
            callable(execute)
            and bool(getattr(execute, "_smart_uv_18180_workspace_runtime_gate", False))
            and workspace_original is sticky_align._execute_with_sticky_postcondition
            and callable(getattr(cls, sticky_align._STICKY_PREV_ATTR, None))
        )
    if not sticky_identities or not all(sticky_identities.values()):
        raise RuntimeError(f"Smart UV sticky alignment wrapper is not inside the workspace gate: {sticky_identities!r}")
    return {
        "instant_rows": len(instant_rows),
        "instant_actual_rows": len(actual_instant_rows),
        "gizmo_rows": len(gizmo_rows),
        "gizmo_actual_rows": len(actual_gizmo_rows),
        "transaction_wrapper": True,
        "direct_drag_original": True,
        "sticky_alignment": sticky_identities,
    }


def _bind_authority_bridge(package_globals: dict[str, Any]) -> None:
    def _manifest_sync_bridge(context: Any = None):
        return synchronize_interaction_runtime(
            context=context,
            reason="package_sync_bridge",
        )

    _manifest_sync_bridge._smart_uv_18180_manifest_authority = True
    package_globals["_sus_1652_sync_keymaps_from_workspace"] = _manifest_sync_bridge


def _same_package_callable(value: Any) -> bool:
    if not callable(value):
        return False
    module_name = str(getattr(value, "__module__", "") or "")
    package_root = str(__package__ or "")
    return bool(module_name == package_root or module_name.startswith(package_root + "."))


def _prepare_transaction_uninstall(package_globals: dict[str, Any]) -> None:
    """Recover only known same-package overwrites before exact token teardown."""
    classes = [
        package_globals.get("SMARTUVSUITE_OT_instant_select_drag_move"),
        package_globals.get("SMARTUVSUITE_OT_instant_select_modal_session"),
    ]
    try:
        from . import interaction_1872
        classes.append(interaction_1872.SMARTUVSUITE_OT_scale_tool_background_select)
    except Exception:
        pass
    try:
        classes.append(uv_gizmo_grip_fix.JELARARAGI_OT_uv_gizmo_grip_fix_grab)
    except Exception:
        pass
    for cls in classes:
        if not isinstance(cls, type):
            continue
        for method_name in ("invoke", "modal", "cancel"):
            current = getattr(cls, method_name, None)
            installed = getattr(cls, f"_smart_uv_18168_wrapper_{method_name}", None)
            previous = getattr(cls, f"_smart_uv_18168_original_{method_name}", None)
            if current is installed or current is previous:
                continue
            if not _same_package_callable(current):
                raise RuntimeError(
                    f"foreign method replaced Smart UV transaction identity: {cls.__name__}.{method_name}"
                )
            if callable(installed):
                setattr(cls, method_name, installed)
            elif method_name == "cancel" and callable(previous):
                setattr(cls, method_name, previous)


def _install_final_method_layers(package_globals: dict[str, Any]) -> dict[str, Any]:
    """Install one deterministic inner-to-outer registered method chain."""
    from . import uv_immediate_drag_stability_18112 as direct_drag
    from . import uv_group_direction_align_1897 as sticky_align
    from . import modal_state_18168 as modal_state

    if not _workspace_runtime_unpatch():
        raise RuntimeError("Smart UV could not remove the previous workspace runtime gates")
    _prepare_transaction_uninstall(package_globals)
    if not modal_state.uninstall_all():
        raise RuntimeError("Smart UV could not remove the previous transaction wrappers")
    sticky_align.unregister()
    direct_drag._disable_eager_hit_cache(package_globals)
    direct_drag._patch_room_integrity()
    if not direct_drag._patch_operator(package_globals):
        raise RuntimeError("Smart UV direct-drag operator patch failed")
    sticky_align.install(package_globals, getattr(bpy, "context", None))
    try:
        gizmo_cls = uv_gizmo_grip_fix.JELARARAGI_OT_uv_gizmo_grip_fix_grab
        final_gizmo_invoke = getattr(uv_gizmo_grip_fix, "_sus_1835_gizmo_invoke", None)
        final_gizmo_apply = getattr(uv_gizmo_grip_fix, "_sus_1835_apply_to_uvs", None)
        if not callable(final_gizmo_invoke) or not callable(final_gizmo_apply):
            raise RuntimeError("final gizmo invoke/apply authority missing")
        gizmo_cls.invoke = final_gizmo_invoke
        gizmo_cls._apply_to_uvs = final_gizmo_apply
        gizmo_cls._apply_mode = gizmo_cls._apply_transaction_mode
        gizmo_cls._restore_original_uvs = gizmo_cls._restore_transaction_uvs
    except Exception as exc:
        raise RuntimeError(f"Smart UV gizmo final invoke authority failed: {exc}") from exc
    modal_names = _patch_modal_transactions(package_globals, force=True)
    workspace_runtime = _patch_workspace_runtime_operators(package_globals)
    _bind_authority_bridge(package_globals)
    return {
        "modal_transactions": modal_names,
        "workspace_runtime": workspace_runtime,
    }


def _publish_owned_keyconfig(*, reason: str) -> dict[str, Any]:
    """Publish every owned addon-keyconfig row into the dispatching keyconfig.

    Owned keymap items live in ``wm.keyconfigs.addon``.  Blender dispatches
    events from the active keyconfig, which is rebuilt from default+addon+user
    only when the keyconfig update flag is processed.  Between an Operation
    setting change and that rebuild the SmartUV rows are present, owned, active
    and correctly signed while no event ever reaches them - the "works briefly,
    then goes inert until reload" symptom.  Run 11 recorded the gizmo form of
    this: exactly one owned Alt+LEFTMOUSE product row and zero production
    invocations, with the same row dispatching later in the same session once an
    explicit keyconfig update had run.

    This is the single finalization boundary for owned resources, so it is the
    single publication point.  No RNA handle is created or retained here; the
    gizmo module owns the post-dispatch detach barrier.
    """
    published = False
    generation = 0
    barrier = "open"
    try:
        from . import uv_gizmo_grip_fix as _gizmo

        published = bool(_gizmo._sus_18225_commit_keyconfig(f"finalize:{reason}"))
        generation = int(_gizmo._sus_18225_keyconfig_generation())
        if not published and int(_gizmo._sus_18224_active_modal_count()) > 0:
            barrier = "detach_pending"
    except Exception as exc:
        return {"published": False, "generation": 0, "barrier": "error", "error": f"{type(exc).__name__}: {exc}"}
    return {"published": published, "generation": generation, "barrier": barrier}


def _authoritative_finalize(
    package_globals: dict[str, Any],
    context: Any = None,
    *,
    reason: str,
) -> dict[str, Any]:
    """Synchronize resources and method identities at one fail-closed boundary."""
    global _FINALIZING
    if _FINALIZING:
        return {"deferred": True, "reason": "authority_reentry"}
    _FINALIZING = True
    _trace("authority_begin", reason=str(reason))
    try:
        layers = _install_final_method_layers(package_globals)
        _trace("method_layers_installed", reason=str(reason))
        feature_state = _synchronize_owned_runtime(package_globals, context, reason=str(reason))
        _trace("resources_synchronized", reason=str(reason), feature_state=dict(feature_state))
        interaction = _verify_final_interaction_runtime(package_globals, feature_state)
        export_filebrowser = _verify_export_uv_layout_runtime(package_globals)
        keyconfig = _publish_owned_keyconfig(reason=str(reason))
        _trace("keyconfig_published", reason=str(reason), keyconfig=dict(keyconfig))
        result = {
            "feature_state": feature_state,
            "modal_transactions": layers["modal_transactions"],
            "workspace_runtime": layers["workspace_runtime"],
            "interaction": interaction,
            "export_filebrowser": export_filebrowser,
            "keyconfig": keyconfig,
        }
        _trace(
            "authority_pass",
            reason=str(reason),
            instant_rows=int(interaction["instant_rows"]),
            gizmo_rows=int(interaction["gizmo_rows"]),
        )
        return result
    except Exception as exc:
        _trace(
            "authority_fail",
            reason=str(reason),
            error=f"{type(exc).__name__}: {exc}",
            error_chain=_exception_chain(exc),
        )
        raise
    finally:
        _FINALIZING = False


def synchronize_interaction_runtime(context: Any = None, reason: str = "public_update") -> dict[str, Any]:
    """Public Operation-setting sync; the manifest is the only final authority."""
    if _STATE == STATE_REGISTERING:
        _trace("public_sync_deferred", reason=str(reason))
        return {"deferred": True, "reason": "registering"}
    if _STATE != STATE_ACTIVE or not isinstance(_PACKAGE_GLOBALS, dict):
        # Public (post-register) sync path: never raise out of a toggle's RNA
        # update callback.  A FAILED/INACTIVE lifecycle state would otherwise
        # turn every Operation toggle into a repeating red error until
        # restart; report the condition and defer instead.
        _trace("public_sync_unavailable", reason=str(reason), state=str(_STATE))
        return {"deferred": True, "reason": str(_STATE)}
    return _authoritative_finalize(
        _PACKAGE_GLOBALS,
        context or getattr(bpy, "context", None),
        reason=str(reason or "public_update"),
    )


def finalize_runtime_update(package_globals: dict[str, Any], context: Any = None) -> dict[str, Any]:
    """Compatibility bridge retained for old layers; never owns final state."""
    if package_globals is not _PACKAGE_GLOBALS:
        raise RuntimeError("Smart UV runtime synchronization used a foreign package namespace")
    if _STATE == STATE_REGISTERING:
        return {"deferred": True, "reason": "registering"}
    return synchronize_interaction_runtime(context=context, reason="compat_finalize")


def register_package(
    package_globals: dict[str, Any],
    legacy_register: Callable[[], Any],
    legacy_unregister: Callable[[], Any],
) -> dict[str, Any]:
    global _STATE, _PACKAGE_GLOBALS, _LEGACY_REGISTER, _LEGACY_UNREGISTER, _AUTHORITY_SEQUENCE
    if _STATE == STATE_ACTIVE:
        return _verify_required_surface()
    if _STATE in {STATE_REGISTERING, STATE_UNREGISTERING}:
        raise RuntimeError(f"Smart UV lifecycle re-entry: {_STATE}")
    _STATE = STATE_REGISTERING
    _PACKAGE_GLOBALS = package_globals
    _LEGACY_REGISTER = legacy_register
    _LEGACY_UNREGISTER = legacy_unregister
    _STEPS.clear()
    _AUTHORITY_TRACE.clear()
    _AUTHORITY_SEQUENCE = 0
    _trace("lifecycle_registering")
    pre_cleanup = _cleanup_preview_owner_modules()
    if pre_cleanup.get("failures"):
        _STATE = STATE_INACTIVE
        raise RuntimeError(f"Smart UV pre-register preview cleanup failed: {pre_cleanup.get('failures')!r}")
    ownership.begin_generation()
    from . import modal_state_18168 as _modal_state
    reset_tokens = getattr(_modal_state, "reset_ledger_tokens", None)
    if not callable(reset_tokens):
        _STATE = STATE_FAILED
        raise RuntimeError("Smart UV modal transaction token reset authority missing")
    reset_tokens()
    if int(_modal_state.checkpoint()) != 0:
        _STATE = STATE_FAILED
        raise RuntimeError("Smart UV modal transaction token reset failed")
    _WORKSPACE_RUNTIME_PATCH_TOKENS.clear()
    try:
        ui_module = sys.modules.get(str(__package__ or "") + ".ui")
        reset_read_heal = getattr(ui_module, "reset_operation_runtime_read_heal", None)
        if callable(reset_read_heal):
            reset_read_heal()
    except Exception:
        pass
    try:
        npanel_body_1881.preinstall(package_globals)
        from . import modal_state_18168 as _modal_state

        # One captured legacy surface keeps all 1.8.163 public classes and
        # properties.  It is never re-resolved by name during this transaction.
        legacy_register()
        _record("legacy_public_surface", legacy_unregister)

        from . import final_1861_checker_line as _final_checker
        _final_checker.register(package_globals)
        _record("final_checker_line", _final_checker.unregister)

        workspace_runtime = _patch_workspace_runtime_operators(package_globals)
        _record("workspace_runtime_gates", _workspace_runtime_unpatch)

        # Historical interaction layers may have replaced known own class
        # methods.  Reapply the exact transaction wrapper once at this explicit
        # lifecycle boundary; no bpy.types scan is performed.
        post_modal_checkpoint = _modal_state.checkpoint()
        modal_names = _patch_modal_transactions(package_globals, force=True)
        _record(
            "modal_transactions_post_register",
            lambda checkpoint=post_modal_checkpoint: _modal_state.uninstall_since(checkpoint),
        )

        required_runtime_access.install(package_globals)
        _record("required_runtime_access", required_runtime_access.unregister)

        uv_gizmo_grip_fix.register(package_globals)
        _record("uv_gizmo_grip_fix", uv_gizmo_grip_fix.unregister)

        smartuv_uv_ownership_18224.register(package_globals)
        _record("smartuv_uv_ownership_18224", smartuv_uv_ownership_18224.unregister)

        proxy_cleanup_1876.register(package_globals)
        _record("proxy_cleanup", proxy_cleanup_1876.unregister)

        npanel_persistence.register()
        _record("npanel_persistence", npanel_persistence.unregister)

        npanel_body_1881.install(package_globals)
        _record("canonical_npanel", npanel_body_1881.uninstall)

        result = _verify_required_surface()
        ownership.mark_active(True)
        final_runtime = _authoritative_finalize(
            package_globals,
            getattr(bpy, "context", None),
            reason="register_complete",
        )
        modal_names = tuple(dict.fromkeys((*modal_names, *final_runtime["modal_transactions"])))
        # Verify again after optional exact resources are synchronized.
        result = _verify_required_surface()
        result["modal_transactions"] = modal_names
        result["feature_state"] = final_runtime["feature_state"]
        result["interaction"] = final_runtime["interaction"]
        result["workspace_runtime_initial"] = workspace_runtime
        result["workspace_runtime"] = final_runtime["workspace_runtime"]
        _STATE = STATE_ACTIVE
        _trace("lifecycle_active")
        return result
    except Exception as register_exc:
        _STATE = STATE_FAILED
        try:
            _rollback()
        except Exception as rollback_exc:
            _STATE = STATE_INACTIVE
            raise RuntimeError(
                f"Smart UV register failed and rollback cleanup failed after "
                f"{type(register_exc).__name__}: {register_exc}"
            ) from rollback_exc
        _STATE = STATE_INACTIVE
        raise


def _release_owned_namespace_state() -> dict[str, Any]:
    """Leave no Smart UV key behind in ``bpy.app.driver_namespace`` at disable.

    Both keys this suite publishes are released here, each by its own owner and
    each only when releasing it costs no live state: the ownership ledger only
    once it guards nothing, the feature-state cache only after it has been
    carried into the process-lifetime anchor.  Nothing enumerates, compares or
    clears the namespace, so a foreign entry cannot be reached by this code.
    """
    released: dict[str, Any] = {}
    try:
        released["feature_state_cache"] = _release_feature_state_cache()
    except Exception as exc:
        released["feature_state_cache_error"] = f"{type(exc).__name__}: {exc}"
    try:
        released["ownership_ledger"] = ownership.release_namespace_ledger()
    except Exception as exc:
        released["ownership_ledger_error"] = f"{type(exc).__name__}: {exc}"
    _trace("owned_namespace_state_released", **released)
    return released


def unregister_package() -> None:
    global _STATE
    if _STATE == STATE_INACTIVE:
        preview_cleanup = _cleanup_preview_owner_modules()
        cleanup = ownership.unregister_owned_runtime()
        ownership.mark_active(False)
        preview_remaining = 0
        try:
            preview_remaining = int(ownership.ledger_snapshot().get("records", {}).get("preview_collection", 0) or 0)
        except Exception:
            preview_remaining = -1
        failures: list[str] = []
        if preview_cleanup.get("failures"):
            failures.append(f"preview owner cleanup failed: {preview_cleanup.get('failures')!r}")
        if int(cleanup.get("failed", 0) or 0) or preview_remaining:
            failures.append(f"owned runtime cleanup incomplete: cleanup={cleanup!r}, preview_remaining={preview_remaining}")
        if failures:
            raise RuntimeError("Smart UV inactive unregister cleanup failed: " + "; ".join(failures))
        _release_owned_namespace_state()
        return
    if _STATE == STATE_UNREGISTERING:
        return
    _STATE = STATE_UNREGISTERING
    _trace("lifecycle_unregistering")
    current_features = _settings_feature_state(_PACKAGE_GLOBALS, getattr(bpy, "context", None))
    if current_features:
        _store_feature_state(current_features)
    ownership.mark_active(False)
    try:
        uv_gizmo_grip_fix.disable()
    except Exception:
        pass
    try:
        _rollback()
    finally:
        _STATE = STATE_INACTIVE
        _release_owned_namespace_state()
        _trace("lifecycle_inactive")


def manifest_snapshot() -> dict[str, Any]:
    return {
        "state": _STATE,
        "steps": tuple(step.name for step in _STEPS),
        "ownership": ownership.ledger_snapshot(),
        "physical_roots": npanel_body_1881.physical_root_space_types(),
        "logical_mapping": npanel_body_1881.logical_editor_mapping(),
        "required_operator_ids": required_runtime_access.REQUIRED_OPERATOR_IDS,
        "authority_trace": tuple(dict(item) for item in _AUTHORITY_TRACE),
    }
