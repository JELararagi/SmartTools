# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Adapt the Smart UV projection selector to the installed projection operator."""

import bpy


def build_handlers(api):
    def project(context, options):
        operation = bpy.ops.uv.suv_native_projection
        identifier = (options.mode or "SMART_PROJECT").upper().strip()
        mode_property = operation.get_rna_type().properties["mode"]
        if identifier not in mode_property.enum_items or not operation.poll():
            return False
        return "FINISHED" in operation(island_margin=options.padding, mode=identifier)

    return {
        "smart_uv_suite.unwrap_projection": api.Handler(
            project,
            "Project the selection using the chosen UV projection method.",
            "選択した投影方式で UV を展開します。",
        ),
    }
