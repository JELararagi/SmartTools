import bpy


def _project(context, op):
    native = bpy.ops.uv.suv_native_projection
    mode = (op.mode or 'SMART_PROJECT').strip().upper()
    allowed = native.get_rna_type().properties['mode'].enum_items.keys()
    if mode not in allowed:
        return False
    return 'FINISHED' in native(mode=mode, island_margin=op.padding)


def build_handlers(api):
    return {
        'smart_uv_suite.unwrap_projection': api.Handler(_project, 'Run the selected Core projection method.', '選択した標準投影方式を実行します。'),
    }
