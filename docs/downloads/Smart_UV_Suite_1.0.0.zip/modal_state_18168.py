# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Transactional modal state snapshots for Smart UV interaction operators."""
from __future__ import annotations

from typing import Any

import bpy

from . import ownership_runtime_18168 as _ownership
from . import context_guard as _context_guard


def _edit_mesh_objects(context: Any) -> tuple[Any, ...]:
    values = []
    try:
        values.extend(getattr(context, "objects_in_mode_unique_data", ()) or ())
    except Exception:
        pass
    try:
        obj = getattr(context, "edit_object", None) or getattr(context, "active_object", None)
        if obj is not None:
            values.append(obj)
    except Exception:
        pass
    out = []
    seen = set()
    for obj in values:
        try:
            pointer = int(obj.as_pointer())
        except Exception:
            pointer = id(obj)
        if pointer in seen or getattr(obj, "type", "") != "MESH" or getattr(obj, "mode", "") != "EDIT":
            continue
        seen.add(pointer)
        out.append(obj)
    return tuple(out)


def _active_uv_tool(context: Any) -> str:
    try:
        tool = context.workspace.tools.from_space_image_mode("UV", create=False)
        return str(getattr(tool, "idname", "") or "")
    except Exception:
        return ""


def _restore_uv_tool(tool_id: str) -> None:
    if not tool_id:
        return
    try:
        bpy.ops.wm.tool_set_by_id(name=str(tool_id), space_type="IMAGE_EDITOR")
    except TypeError:
        try:
            bpy.ops.wm.tool_set_by_id(name=str(tool_id))
        except Exception:
            pass
    except Exception:
        pass


def _loop_uv_selected(loop: Any, luv: Any, *, edge: bool = False) -> bool:
    """Read the live edit-mode UV flag, with an old-Blender fallback.

    Blender 5.1 exposes the ``.uv_select_vert`` / ``.uv_select_edge`` CORNER
    layers through BMLoop.  BMLoopUV ``select`` fields no longer exist there,
    so they must only be consulted when the live API itself is unavailable.
    """
    live_name = "uv_select_edge" if edge else "uv_select_vert"
    legacy_name = "select_edge" if edge else "select"
    try:
        return bool(getattr(loop, live_name))
    except Exception:
        try:
            return bool(getattr(luv, legacy_name))
        except Exception:
            return False


def _set_loop_uv_selected(loop: Any, luv: Any, value: bool, *, edge: bool = False) -> bool:
    """Restore one live UV flag without creating hidden mesh attributes."""
    value = bool(value)
    live_name = "uv_select_edge" if edge else "uv_select_vert"
    setter_name = "uv_select_edge_set" if edge else "uv_select_vert_set"
    legacy_name = "select_edge" if edge else "select"
    try:
        setter = getattr(loop, setter_name, None)
        if callable(setter):
            setter(value)
            return True
    except Exception:
        pass
    try:
        getattr(loop, live_name)
        setattr(loop, live_name, value)
        return True
    except Exception:
        try:
            setattr(luv, legacy_name, value)
            return True
        except Exception:
            return False


def _face_uv_selected(face: Any, uv: Any) -> bool:
    """Read Blender 5.1's live FACE UV flag, or infer it on old Blender."""
    try:
        return bool(getattr(face, "uv_select"))
    except Exception:
        values = []
        for loop in tuple(getattr(face, "loops", ()) or ()):
            try:
                values.append(bool(getattr(loop[uv], "select")))
            except Exception:
                return False
        return bool(values) and all(values)


def _set_face_uv_selected(face: Any, value: bool) -> bool:
    """Restore Blender 5.1's live FACE UV flag when that API exists."""
    value = bool(value)
    try:
        setter = getattr(face, "uv_select_set", None)
        if callable(setter):
            setter(value)
            return True
    except Exception:
        pass
    try:
        getattr(face, "uv_select")
        setattr(face, "uv_select", value)
        return True
    except Exception:
        # Old Blender has no independent BMFace UV flag.  Its per-loop flags
        # are restored immediately below through the BMLoopUV fallback.
        return False


def _set_mesh_bool_attribute(mesh: Any, name: str, index: int, value: bool) -> bool:
    """Best-effort Blender 5.1 Mesh selection attribute fallback."""
    try:
        attrs = getattr(mesh, "attributes", None)
        attr = attrs.get(name) if attrs is not None else None
        data = getattr(attr, "data", None) if attr is not None else None
        if data is None or index < 0 or index >= len(data):
            return False
        data[index].value = bool(value)
        return True
    except Exception:
        return False


def _read_mesh_bool_attribute(mesh: Any, name: str, index: int) -> bool:
    try:
        attrs = getattr(mesh, "attributes", None)
        attr = attrs.get(name) if attrs is not None else None
        data = getattr(attr, "data", None) if attr is not None else None
        if data is None or index < 0 or index >= len(data):
            return False
        return bool(getattr(data[index], "value", False))
    except Exception:
        return False


def _mesh_loop_index_for_face_local(mesh: Any, face_index: int, local_index: int) -> int:
    try:
        polygons = getattr(mesh, "polygons", None)
        if polygons is None or face_index < 0 or face_index >= len(polygons):
            return -1
        loop_indices = list(getattr(polygons[int(face_index)], "loop_indices", ()) or ())
        if local_index < 0 or local_index >= len(loop_indices):
            return -1
        return int(loop_indices[int(local_index)])
    except Exception:
        return -1


def _restore_mesh_data_authority(mesh: Any, item: dict[str, Any]) -> None:
    """Reapply captured UV, pin, and selection directly to Mesh data.

    Blender 5.1 can normalize edit-mode UV selection when BMesh is flushed.
    Rollback therefore uses BMesh for the live edit state, then briefly writes
    the same snapshot through Mesh CORNER/FACE attributes as the final
    object-mode readback authority.
    """
    try:
        uv_layers = getattr(mesh, "uv_layers", None)
        if uv_layers is None:
            return
        uv_layer = uv_layers.get(str(item.get("uv_layer_name", ""))) or uv_layers.active
        if uv_layer is None:
            return
        for index, selected in item.get("verts", ()):
            try:
                if 0 <= int(index) < len(mesh.vertices):
                    mesh.vertices[int(index)].select = bool(selected)
            except Exception:
                pass
        for index, selected in item.get("edges", ()):
            try:
                if 0 <= int(index) < len(mesh.edges):
                    mesh.edges[int(index)].select = bool(selected)
            except Exception:
                pass
        for face_item in item.get("faces", ()):
            face_index = int(face_item.get("index", -1))
            try:
                if 0 <= face_index < len(mesh.polygons):
                    mesh.polygons[face_index].select = bool(face_item.get("select", False))
            except Exception:
                pass
            _set_mesh_bool_attribute(mesh, ".uv_select_face", face_index, bool(face_item.get("uv_select", False)))
            for loop_item in face_item.get("loops", ()):
                local_index = int(loop_item.get("local_index", -1))
                loop_index = int(loop_item.get("loop_index", -1))
                if loop_index < 0:
                    loop_index = _mesh_loop_index_for_face_local(mesh, face_index, local_index)
                if loop_index < 0:
                    continue
                try:
                    data = getattr(uv_layer, "data", None)
                    if data is not None and loop_index < len(data):
                        u, v = loop_item.get("uv", (0.0, 0.0))
                        data[loop_index].uv.x = float(u)
                        data[loop_index].uv.y = float(v)
                        try:
                            data[loop_index].pin_uv = bool(loop_item.get("pin_uv", False))
                        except Exception:
                            pass
                except Exception:
                    pass
                _set_mesh_bool_attribute(mesh, ".uv_select_vert", loop_index, bool(loop_item.get("select", False)))
                _set_mesh_bool_attribute(mesh, ".uv_select_edge", loop_index, bool(loop_item.get("select_edge", False)))
        try:
            mesh.update()
        except Exception:
            pass
    except Exception:
        return


def _mesh_active_uv_layer_name(mesh: Any) -> str:
    try:
        layers = getattr(mesh, "uv_layers", None)
        active = getattr(layers, "active", None) if layers is not None else None
        return str(getattr(active, "name", "") or "")
    except Exception:
        return ""


def _ensure_restore_edit_object(context: Any, obj: Any, mesh: Any) -> bool:
    if obj is None or mesh is None or getattr(obj, "data", None) is not mesh:
        return False
    if getattr(obj, "mode", "") == "EDIT":
        return True
    try:
        bpy.ops.object.mode_set(mode="OBJECT")
    except Exception:
        pass
    try:
        for other in getattr(getattr(context, "view_layer", None), "objects", []) or []:
            try:
                other.select_set(False)
            except Exception:
                pass
    except Exception:
        pass
    try:
        obj.select_set(True)
    except Exception:
        pass
    try:
        context.view_layer.objects.active = obj
    except Exception:
        pass
    try:
        bpy.ops.object.mode_set(mode="EDIT")
    except Exception:
        pass
    return getattr(obj, "mode", "") == "EDIT"


def capture(context: Any) -> dict[str, Any]:
    import bmesh
    objects = []
    for obj in _edit_mesh_objects(context):
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
            bm.verts.index_update(); bm.edges.index_update(); bm.faces.index_update()
            uv = bm.loops.layers.uv.active
            if uv is None:
                continue
            faces = []
            for face in bm.faces:
                loops = []
                for local_index, loop in enumerate(face.loops):
                    luv = loop[uv]
                    face_index = int(getattr(face, "index", -1))
                    # Blender 5.1 BMLoop.index is not a stable Mesh loop
                    # index even when it is non-negative.  Capture the Mesh
                    # loop index from face/local topology first so rollback
                    # writes back to the same CORNER selection attribute.
                    loop_index = _mesh_loop_index_for_face_local(obj.data, face_index, int(local_index))
                    if loop_index < 0:
                        loop_index = int(getattr(loop, "index", -1))
                    loops.append({
                        "local_index": int(local_index),
                        "loop_index": int(loop_index),
                        "uv": (float(luv.uv.x), float(luv.uv.y)),
                        "select": _loop_uv_selected(loop, luv) or _read_mesh_bool_attribute(obj.data, ".uv_select_vert", loop_index),
                        "select_edge": _loop_uv_selected(loop, luv, edge=True) or _read_mesh_bool_attribute(obj.data, ".uv_select_edge", loop_index),
                        "pin_uv": bool(getattr(luv, "pin_uv", False)),
                    })
                faces.append({
                    "index": int(face.index),
                    "select": bool(face.select),
                    "uv_select": _face_uv_selected(face, uv) or _read_mesh_bool_attribute(obj.data, ".uv_select_face", face_index),
                    "loops": tuple(loops),
                })
            active_face = getattr(getattr(bm, "faces", None), "active", None)
            objects.append({
                "object": obj,
                "mesh": obj.data,
                "uv_layer_name": _mesh_active_uv_layer_name(obj.data) or str(getattr(uv, "name", "") or ""),
                "verts": tuple((int(v.index), bool(v.select)) for v in bm.verts),
                "edges": tuple((int(e.index), bool(e.select)) for e in bm.edges),
                "faces": tuple(faces),
                "active_face": int(getattr(active_face, "index", -1)) if active_face is not None else -1,
            })
        except Exception:
            continue
    return {
        "objects": tuple(objects),
        "active_uv_tool": _active_uv_tool(context),
    }


def restore(snapshot: Any, context: Any = None) -> bool:
    if not isinstance(snapshot, dict):
        return False
    import bmesh
    restored = False
    for item in snapshot.get("objects", ()):
        try:
            obj = item.get("object")
            mesh = item.get("mesh")
            if not _ensure_restore_edit_object(context, obj, mesh):
                continue
            bm = bmesh.from_edit_mesh(mesh)
            bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
            uv = bm.loops.layers.uv.get(str(item.get("uv_layer_name", ""))) or bm.loops.layers.uv.active
            if uv is None:
                continue
            for index, selected in item.get("verts", ()):
                if 0 <= int(index) < len(bm.verts):
                    bm.verts[int(index)].select = bool(selected)
            for index, selected in item.get("edges", ()):
                if 0 <= int(index) < len(bm.edges):
                    bm.edges[int(index)].select = bool(selected)
            for face_item in item.get("faces", ()):
                face_index = int(face_item.get("index", -1))
                if face_index < 0 or face_index >= len(bm.faces):
                    continue
                face = bm.faces[face_index]
                face.select = bool(face_item.get("select", False))
                _set_face_uv_selected(face, bool(face_item.get("uv_select", False)))
                _set_mesh_bool_attribute(mesh, ".uv_select_face", face_index, bool(face_item.get("uv_select", False)))
                loops = tuple(face.loops)
                for loop_item in face_item.get("loops", ()):
                    local_index = int(loop_item.get("local_index", -1))
                    if local_index < 0 or local_index >= len(loops):
                        continue
                    luv = loops[local_index][uv]
                    u, v = loop_item.get("uv", (0.0, 0.0))
                    luv.uv.x = float(u); luv.uv.y = float(v)
                    _set_loop_uv_selected(loop=loops[local_index], luv=luv, value=bool(loop_item.get("select", False)))
                    _set_loop_uv_selected(loop=loops[local_index], luv=luv, value=bool(loop_item.get("select_edge", False)), edge=True)
                    loop_index = int(loop_item.get("loop_index", -1))
                    if loop_index < 0:
                        loop_index = _mesh_loop_index_for_face_local(mesh, face_index, local_index)
                    if loop_index < 0:
                        loop_index = int(getattr(loops[local_index], "index", -1))
                    _set_mesh_bool_attribute(mesh, ".uv_select_vert", loop_index, bool(loop_item.get("select", False)))
                    _set_mesh_bool_attribute(mesh, ".uv_select_edge", loop_index, bool(loop_item.get("select_edge", False)))
                    try: luv.pin_uv = bool(loop_item.get("pin_uv", False))
                    except Exception: pass
            active_index = int(item.get("active_face", -1))
            try:
                bm.faces.active = bm.faces[active_index] if 0 <= active_index < len(bm.faces) else None
            except Exception:
                pass
            try:
                bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
            except TypeError:
                bmesh.update_edit_mesh(mesh)
            # Blender 5.1 may rewrite CORNER selection attributes when the live
            # edit BMesh is flushed.  Reapply the captured Mesh attributes after
            # update_edit_mesh so object-mode readback and workspace-cancel
            # rollback observe the same selection authority.
            for face_item in item.get("faces", ()):
                face_index = int(face_item.get("index", -1))
                _set_mesh_bool_attribute(mesh, ".uv_select_face", face_index, bool(face_item.get("uv_select", False)))
                for loop_item in face_item.get("loops", ()):
                    local_index = int(loop_item.get("local_index", -1))
                    loop_index = int(loop_item.get("loop_index", -1))
                    if loop_index < 0:
                        loop_index = _mesh_loop_index_for_face_local(mesh, face_index, local_index)
                    _set_mesh_bool_attribute(mesh, ".uv_select_vert", loop_index, bool(loop_item.get("select", False)))
                    _set_mesh_bool_attribute(mesh, ".uv_select_edge", loop_index, bool(loop_item.get("select_edge", False)))
            try:
                if getattr(obj, "mode", "") == "EDIT":
                    bpy.ops.object.mode_set(mode="OBJECT")
                _restore_mesh_data_authority(mesh, item)
                bpy.ops.object.mode_set(mode="EDIT")
            except Exception:
                _restore_mesh_data_authority(mesh, item)
            restored = True
        except Exception:
            continue
    _restore_uv_tool(str(snapshot.get("active_uv_tool", "") or ""))
    try:
        area = getattr(context, "area", None)
        if area is not None:
            area.tag_redraw()
    except Exception:
        pass
    return restored


def _result_contains(result: Any, value: str) -> bool:
    try:
        return str(value) in set(result or ())
    except Exception:
        return False


def _restore_tool_only(snapshot: Any) -> None:
    if isinstance(snapshot, dict):
        _restore_uv_tool(str(snapshot.get("active_uv_tool", "") or ""))


def _is_escape(event: Any) -> bool:
    try:
        return str(getattr(event, "type", "") or "").upper() == "ESC"
    except Exception:
        return False


_PATCH_TOKENS: list[Any] = []


def checkpoint() -> int:
    """Return an exact patch-ledger checkpoint for lifecycle rollback."""
    return len(_PATCH_TOKENS)


def uninstall_since(index: int) -> bool:
    """Remove only patches created after *index*, in exact reverse order."""
    index = max(0, min(int(index), len(_PATCH_TOKENS)))
    tokens = tuple(_PATCH_TOKENS[index:])
    ok = True
    kept: list[Any] = []
    for token in reversed(tokens):
        if not _ownership.unpatch_attribute(token):
            ok = False
            kept.append(token)
    del _PATCH_TOKENS[index:]
    if kept:
        _PATCH_TOKENS.extend(reversed(kept))
    return ok


def uninstall_all() -> bool:
    return uninstall_since(0)


def reset_ledger_tokens() -> None:
    """Forget transaction tokens after the shared ownership ledger retires them."""
    _PATCH_TOKENS.clear()


def _patch_exact(owner: Any, name: str, value: Any, batch: list[Any]) -> bool:
    token = _ownership.patch_attribute(owner, name, value)
    if token is None:
        return False
    batch.append(token)
    return True


def patch_operator(cls: type, *, force: bool = False, restore_tool_on_finish: bool = True) -> bool:
    """Wrap one explicitly supplied Smart UV operator in an exact transaction.

    Only this known class is patched.  Every method/marker replacement receives
    an opaque ownership token and is restored in reverse order.  No ``bpy.types``
    or ``sys.modules`` traversal is performed.
    """
    if not isinstance(cls, type):
        return False
    current_invoke = getattr(cls, "invoke", None)
    current_modal = getattr(cls, "modal", None)
    current_cancel = getattr(cls, "cancel", None)
    if not callable(current_invoke):
        return False
    installed_wrapper = getattr(cls, "_smart_uv_18168_wrapper_invoke", None)
    if current_invoke is installed_wrapper:
        return True
    if bool(getattr(cls, "_smart_uv_18168_transactional", False)) and not force:
        return False

    original_invoke = current_invoke
    original_modal = current_modal if callable(current_modal) else None
    original_cancel = current_cancel if callable(current_cancel) else None

    def _rollback(self, context) -> None:
        restore(getattr(self, "_smart_uv_18168_snapshot", None), context)
        self._smart_uv_18168_snapshot = None
        self._smart_uv_18168_committed = False

    def _commit(self) -> None:
        self._smart_uv_18168_snapshot = None
        self._smart_uv_18168_committed = True

    def invoke(self, context, event):
        if not _context_guard.smart_uv_runtime_context_allowed(context):
            self._smart_uv_18168_snapshot = None
            self._smart_uv_18168_committed = False
            return {"PASS_THROUGH"}
        try:
            self._smart_uv_18168_snapshot = capture(context)
        except Exception:
            # A failed snapshot must not kill the invoke: restore() tolerates
            # None, so the transaction simply degrades to no-rollback.
            self._smart_uv_18168_snapshot = None
        self._smart_uv_18168_committed = False
        try:
            result = original_invoke(self, context, event)
        except Exception:
            _rollback(self, context)
            return {"CANCELLED"}
        if _is_escape(event) or _result_contains(result, "CANCELLED"):
            _rollback(self, context)
            return {"CANCELLED"} if _is_escape(event) else result
        if _result_contains(result, "FINISHED"):
            if restore_tool_on_finish:
                _restore_tool_only(getattr(self, "_smart_uv_18168_snapshot", None))
            _commit(self)
        elif _result_contains(result, "PASS_THROUGH"):
            _restore_tool_only(getattr(self, "_smart_uv_18168_snapshot", None))
            self._smart_uv_18168_snapshot = None
        return result

    modal_wrapper = None
    if original_modal is not None:
        def modal(self, context, event):
            if not _context_guard.smart_uv_runtime_context_allowed(context):
                _rollback(self, context)
                return {"CANCELLED"}
            try:
                result = original_modal(self, context, event)
            except Exception:
                _rollback(self, context)
                return {"CANCELLED"}
            if _is_escape(event) or _result_contains(result, "CANCELLED"):
                _rollback(self, context)
                return {"CANCELLED"} if _is_escape(event) else result
            if _result_contains(result, "FINISHED"):
                if restore_tool_on_finish:
                    _restore_tool_only(getattr(self, "_smart_uv_18168_snapshot", None))
                _commit(self)
            return result
        modal_wrapper = modal

    def cancel(self, context):
        try:
            if original_cancel is not None:
                original_cancel(self, context)
        finally:
            _rollback(self, context)

    batch: list[Any] = []
    assignments = [
        ("invoke", invoke),
        ("cancel", cancel),
        ("_smart_uv_18168_transactional", True),
        ("_smart_uv_18168_original_invoke", original_invoke),
        ("_smart_uv_18168_original_modal", original_modal),
        ("_smart_uv_18168_original_cancel", original_cancel),
        ("_smart_uv_18168_wrapper_invoke", invoke),
        ("_smart_uv_18168_wrapper_modal", modal_wrapper),
        ("_smart_uv_18168_restore_tool_on_finish", bool(restore_tool_on_finish)),
    ]
    if modal_wrapper is not None:
        assignments.insert(1, ("modal", modal_wrapper))
    for name, value in assignments:
        if not _patch_exact(cls, name, value, batch):
            for token in reversed(batch):
                _ownership.unpatch_attribute(token)
            return False
    _PATCH_TOKENS.extend(batch)
    return True


def install(package_globals: dict[str, Any], *, force: bool = False) -> tuple[str, ...]:
    patched = []
    for name in ("SMARTUVSUITE_OT_instant_select_drag_move", "SMARTUVSUITE_OT_instant_select_modal_session"):
        cls = package_globals.get(name)
        if patch_operator(cls, force=force, restore_tool_on_finish=True):
            patched.append(name)
    return tuple(patched)
