from bmesh.types import BMFace


def build_handlers(api):
    sequence_buffer = None
    sequence_sizes = ()

    def run(context, op):
        if context.mode != 'EDIT_MESH':
            return False
        if api._u._UV_COPY_BUFFER:
            return api._u._paste_uvs(context) > 0
        return api._native_uv_clipboard('paste')(context, op)

    def ordered_faces(context):
        if context.mode != 'EDIT_MESH' or not api._sync(context):
            return None, ()
        row = next((row for row in api._edit_targets(context) if row[0] == context.active_object), None)
        if row is None:
            return None, ()
        faces = tuple(face for face in row[1].select_history
                      if isinstance(face, BMFace) and face.select and not face.hide)
        return row, faces

    def copy_sequence(context, op):
        nonlocal sequence_buffer, sequence_sizes
        row, faces = ordered_faces(context)
        if not faces:
            return False
        uv = row[2]
        sequence_buffer = [tuple(loop[uv].uv) for face in faces for loop in face.loops]
        sequence_sizes = tuple(len(face.loops) for face in faces)
        api._u._UV_COPY_BUFFER = sequence_buffer
        return True

    def paste_sequence(context, op):
        row, faces = ordered_faces(context)
        if (not faces or api._u._UV_COPY_BUFFER is not sequence_buffer
                or tuple(len(face.loops) for face in faces) != sequence_sizes
                or len(sequence_buffer) != sum(sequence_sizes)):
            return False
        uv = row[2]
        for loop, point in zip((loop for face in faces for loop in face.loops), sequence_buffer):
            loop[uv].uv = point
        api._flush([row])
        return True

    return {
        'smart_uv_suite.seam_paste': api.Handler(run, 'Paste copied UV coordinates onto the UV selection.', 'コピーしたUV座標を選択範囲に貼り付けます。'),
        'smart_uv_suite.seam_set_transfer_selection_s': api.Handler(
            api._seam_set('transfer'),
            'Copy a saved seam set to the other selected meshes.',
            '保存したシームセットを他の選択メッシュへコピーします。',
        ),
        'smart_uv_suite.seam_copy_paste_uv_selseq_copy_uv': api.Handler(
            copy_sequence,
            'Copy UVs in face selection order with UV Sync Selection enabled.',
            'UV選択同期を有効にし、面を選択した順にUVをコピーします。',
        ),
        'smart_uv_suite.seam_copy_paste_uv_selseq_paste_uv': api.Handler(
            paste_sequence,
            'Paste sequence UVs onto faces selected in the desired order with UV Sync Selection enabled.',
            'UV選択同期を有効にし、貼り付け先の面を選択した順にUVを貼り付けます。',
        ),
    }
