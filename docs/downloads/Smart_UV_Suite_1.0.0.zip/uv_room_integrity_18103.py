# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Smart UV Suite 1.8.103 final room integrity consolidation.

This module is the final runtime authority for the fixes requested in this room.
It deliberately runs after the older incremental layers and neutralizes the old
routes that caused mode changes, stale selection reuse, Generic Gizmo
interception, and Immediate Select cache-only failure.
"""
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

from collections import defaultdict, deque
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Set, Tuple
import math

import bpy

_VERSION = (1, 8, 103)
_NS: Dict[str, Any] = {}
_INSTALLED = False
_PREV_SELECT_EXEC = None
_PREV_VERTEX_EXEC = None
_PREV_INSTANT_INVOKE = None
_PREV_SYNC_KEYMAPS = None

_INSTANT_ID = "smart_uv_suite.instant_select_drag_move"
_STICKY_PASS_ID = "smart_uv_suite.sticky_select_expand_passthrough"
_GIZMO_GRIP_ID = "smart_uv_suite.uv_gizmo_grip_fix_grab"
_ALLOWED_INSTANT_MAPS: Tuple[Tuple[str, str], ...] = (
    ("UV Editor", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Tweak", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Tweak (fallback)", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Select Box", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Select Box (fallback)", "IMAGE_EDITOR"),
)
_FORBIDDEN_MAPS: Tuple[str, ...] = (
    "Window", "Image", "Image Generic", "Generic Gizmo", "Generic Gizmo Drag",
    "Generic Gizmo Click Drag", "Generic Gizmo Maybe Drag", "Generic Gizmo Select",
    "Image Editor Tool: Uv, Move", "Image Editor Tool: Uv, Move (fallback)",
    "Image Editor Tool: Uv, Rotate", "Image Editor Tool: Uv, Rotate (fallback)",
    "Image Editor Tool: Uv, Scale", "Image Editor Tool: Uv, Scale (fallback)",
    "Image Editor Tool: Uv, Transform", "Image Editor Tool: Uv, Transform (fallback)",
    "Image Editor Tool: Uv, Cursor", "Image Editor Tool: Uv, Cursor (fallback)",
    "Image Editor Tool: Uv, Select Lasso", "Image Editor Tool: Uv, Select Lasso (fallback)",
    "Image Editor Tool: Uv, Select Circle", "Image Editor Tool: Uv, Select Circle (fallback)",
)
_TRANSFORM_TOOL_TOKENS = ("move", "translate", "rotate", "scale", "transform", "cursor", "annotate", "box", "lasso", "circle")
_GROUP_ACTIONS = {"ALIGN_H_GROUP", "ALIGN_V_GROUP", "DISTRIBUTE_H_GROUP", "DISTRIBUTE_V_GROUP"}
_DIGITS = 7
_EPS = 1.0e-6


def _s(value: Any) -> str:
    try:
        return str(value or "")
    except Exception:
        return ""


def _report(op: Any, level: str, message: str) -> None:
    try:
        op.report({level}, message)
    except Exception:
        pass


def _tr(context: Any, en: str, ja: str) -> str:
    fn = _NS.get("_sus_text")
    if callable(fn):
        try:
            return str(fn(en, ja, context))
        except Exception:
            pass
    try:
        lang = str(getattr(getattr(context, "preferences", None), "view", None).language or "")
        return ja if lang.startswith("ja") else en
    except Exception:
        return ja or en


def _tool_settings(context: Any = None) -> Any:
    ctx = context or getattr(bpy, "context", None)
    try:
        ts = getattr(ctx, "tool_settings", None)
        if ts is not None:
            return ts
    except Exception:
        pass
    try:
        return getattr(getattr(ctx, "scene", None), "tool_settings", None)
    except Exception:
        return None


def _workspace(context: Any = None) -> Any:
    try:
        return getattr(getattr(context or bpy.context, "scene", None), "suv_workspace", None)
    except Exception:
        return None


def _snapshot_modes(context: Any = None) -> Dict[str, Any]:
    ts = _tool_settings(context)
    ws = _workspace(context)
    snap: Dict[str, Any] = {"ts": ts, "ws": ws}
    if ts is not None:
        for attr in ("use_uv_select_sync", "uv_select_mode", "uv_sticky_select_mode"):
            try:
                snap[attr] = getattr(ts, attr)
            except Exception:
                pass
        try:
            snap["mesh_select_mode"] = tuple(bool(v) for v in getattr(ts, "mesh_select_mode", (False, False, False)))
        except Exception:
            pass
    if ws is not None:
        try:
            snap["ws_uv_sticky_select_mode"] = getattr(ws, "uv_sticky_select_mode")
        except Exception:
            pass
    return snap


def _restore_modes(snap: Dict[str, Any]) -> None:
    if not isinstance(snap, dict):
        return
    ts = snap.get("ts")
    if ts is not None:
        for attr in ("use_uv_select_sync", "uv_select_mode", "uv_sticky_select_mode"):
            if attr not in snap:
                continue
            try:
                if getattr(ts, attr) != snap[attr]:
                    setattr(ts, attr, snap[attr])
            except Exception:
                pass
        if "mesh_select_mode" in snap:
            try:
                mode = tuple(bool(v) for v in snap["mesh_select_mode"])
                if len(mode) >= 3:
                    setattr(ts, "mesh_select_mode", (mode[0], mode[1], mode[2]))
            except Exception:
                pass
    ws = snap.get("ws")
    if ws is not None and "ws_uv_sticky_select_mode" in snap:
        try:
            if getattr(ws, "uv_sticky_select_mode") != snap["ws_uv_sticky_select_mode"]:
                setattr(ws, "uv_sticky_select_mode", snap["ws_uv_sticky_select_mode"])
        except Exception:
            pass


def _uv_mode(context: Any = None) -> str:
    ts = _tool_settings(context)
    raw = "VERTEX"
    try:
        raw = getattr(ts, "uv_select_mode", "VERTEX")
    except Exception:
        raw = "VERTEX"
    try:
        if isinstance(raw, (set, list, tuple)):
            values = {str(v).upper() for v in raw}
            if "FACE" in values or "ISLAND" in values:
                return "FACE"
            if "EDGE" in values:
                return "EDGE"
            return "VERTEX"
        text = str(raw or "VERTEX").upper()
        if "ISLAND" in text or "FACE" in text:
            return "FACE"
        if "EDGE" in text:
            return "EDGE"
    except Exception:
        pass
    return "VERTEX"


def _sync_on(context: Any = None) -> bool:
    try:
        return bool(getattr(_tool_settings(context), "use_uv_select_sync", False))
    except Exception:
        return False


def _sticky_mode(context: Any = None) -> str:
    raw = "DISABLED"
    try:
        raw = getattr(_tool_settings(context), "uv_sticky_select_mode", "DISABLED")
    except Exception:
        raw = "DISABLED"
    value = str(raw or "DISABLED").upper()
    aliases = {
        "SAME_LOCATION": "SHARED_LOCATION",
        "SAME_POSITION": "SHARED_LOCATION",
        "LOCATION": "SHARED_LOCATION",
        "SHARED_POSITION": "SHARED_LOCATION",
        "VERTEX": "SHARED_VERTEX",
        "SHARED_VERT": "SHARED_VERTEX",
        "COMMON_VERTEX": "SHARED_VERTEX",
    }
    return aliases.get(value, value)


def _active_mesh(context: Any) -> Any:
    try:
        obj = getattr(context, "edit_object", None)
        if obj is not None and getattr(obj, "type", None) == "MESH":
            return obj
    except Exception:
        pass
    try:
        obj = getattr(context, "active_object", None)
        if obj is not None and getattr(obj, "type", None) == "MESH":
            return obj
    except Exception:
        pass
    return None


def _edit_objects(context: Any) -> List[Any]:
    objs: List[Any] = []
    try:
        objs = [o for o in (getattr(context, "objects_in_mode_unique_data", None) or []) if getattr(o, "type", None) == "MESH" and getattr(o, "mode", None) == "EDIT"]
    except Exception:
        objs = []
    if not objs:
        obj = _active_mesh(context)
        if obj is not None and getattr(obj, "mode", None) == "EDIT":
            objs = [obj]
    clean: List[Any] = []
    seen: Set[int] = set()
    for obj in objs:
        try:
            key = int(obj.data.as_pointer())
        except Exception:
            key = id(getattr(obj, "data", obj))
        if key in seen:
            continue
        seen.add(key)
        clean.append(obj)
    return clean


def _enter_edit(context: Any) -> Tuple[Any, str, bool]:
    obj = _active_mesh(context)
    if obj is None:
        return None, "OBJECT", False
    old_mode = _s(getattr(obj, "mode", "OBJECT")) or "OBJECT"
    changed = False
    if old_mode != "EDIT":
        try:
            context.view_layer.objects.active = obj
            obj.select_set(True)
        except Exception:
            pass
        try:
            bpy.ops.object.mode_set(mode="EDIT")
            changed = True
        except Exception:
            pass
    return obj, old_mode, changed


def _restore_edit(obj: Any, old_mode: str, changed: bool) -> None:
    if changed and obj is not None and old_mode and old_mode != "EDIT":
        try:
            bpy.ops.object.mode_set(mode=old_mode)
        except Exception:
            pass


def _ensure_lookup(bm: Any) -> None:
    try:
        bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
        bm.verts.index_update(); bm.edges.index_update(); bm.faces.index_update()
    except Exception:
        pass


def _ensure_uv_target(context: Any, obj: Any) -> None:
    try:
        from . import uv_map_channels as uvc
        uvc.ensure_unwrap_map_channel(context, _workspace(context), obj)
    except Exception:
        pass


def _uv_layer(bm: Any) -> Any:
    try:
        layer = bm.loops.layers.uv.active
        if layer is not None:
            return layer
    except Exception:
        pass
    try:
        return bm.loops.layers.uv.verify()
    except Exception:
        return None


def _loop_index(loop: Any) -> int:
    try:
        return int(getattr(loop, "index", -1))
    except Exception:
        return -1


def _face_index(face: Any) -> int:
    try:
        return int(getattr(face, "index", -1))
    except Exception:
        return -1


def _uv_xy(loop: Any, uv_layer: Any) -> Tuple[float, float]:
    try:
        uv = loop[uv_layer].uv
        return float(uv.x), float(uv.y)
    except Exception:
        return 0.0, 0.0


def _uv_key(loop: Any, uv_layer: Any) -> Tuple[float, float]:
    u, v = _uv_xy(loop, uv_layer)
    return (round(u, _DIGITS), round(v, _DIGITS))


def _close(a: Tuple[float, float], b: Tuple[float, float], eps: float = _EPS) -> bool:
    return abs(a[0] - b[0]) <= eps and abs(a[1] - b[1]) <= eps


def _same_uv_edge(a: Any, b: Any, uv_layer: Any) -> bool:
    try:
        a0 = _uv_xy(a, uv_layer); a1 = _uv_xy(a.link_loop_next, uv_layer)
        b0 = _uv_xy(b, uv_layer); b1 = _uv_xy(b.link_loop_next, uv_layer)
        return (_close(a0, b0) and _close(a1, b1)) if a.vert == b.vert else (_close(a0, b1) and _close(a1, b0))
    except Exception:
        return False


def _live_v(loop: Any, uv_layer: Any) -> bool:
    # Blender 5.1 stores UV-editor vertex selection on BMLoop.uv_select_vert.
    # Hidden mesh attributes are ignored elsewhere because they can be stale;
    # this live BMesh accessor reflects the current UV editor selection and is
    # required for UV Sync ON/OFF selection and alignment to agree.
    try:
        if bool(getattr(loop, "uv_select_vert")):
            return True
    except Exception:
        pass
    try:
        return bool(getattr(loop[uv_layer], "select", False))
    except Exception:
        return False


def _live_e(loop: Any, uv_layer: Any) -> bool:
    try:
        if bool(getattr(loop, "uv_select_edge")):
            return True
    except Exception:
        pass
    try:
        return bool(getattr(loop[uv_layer], "select_edge", False))
    except Exception:
        return False


def _set_v(loop: Any, uv_layer: Any, value: bool) -> None:
    value = bool(value)
    try:
        fn = getattr(loop, "uv_select_vert_set", None)
        if callable(fn):
            fn(value)
            return
    except Exception:
        pass
    try:
        setattr(loop, "uv_select_vert", value)
        return
    except Exception:
        pass
    try:
        setattr(loop[uv_layer], "select", value)
    except Exception:
        pass


def _set_e(loop: Any, uv_layer: Any, value: bool) -> None:
    value = bool(value)
    try:
        fn = getattr(loop, "uv_select_edge_set", None)
        if callable(fn):
            fn(value)
            return
    except Exception:
        pass
    try:
        setattr(loop, "uv_select_edge", value)
        return
    except Exception:
        pass
    try:
        setattr(loop[uv_layer], "select_edge", value)
    except Exception:
        pass


def _mesh_attrs(obj: Any) -> Tuple[List[bool], List[bool], List[bool]]:
    """Return neutral hidden UV-selection flags.

    Blender 5.1 can keep .uv_select_* mesh attributes from older selection
    states. Reading those attributes here reintroduced the all-selection bug and
    also touches RNA collection lookup paths that appeared in crash logs. The
    final 1.8.103 path therefore uses only live BMesh/mesh selection and treats
    hidden attributes as non-authoritative.
    """
    mesh = getattr(obj, "data", None)
    try:
        loop_len = len(getattr(mesh, "loops", []) or [])
        face_len = len(getattr(mesh, "polygons", []) or [])
    except Exception:
        loop_len = face_len = 0
    return [False] * loop_len, [False] * loop_len, [False] * face_len



def _reject_full_flags_18102(flags: Sequence[bool]) -> List[bool]:
    try:
        vals = list(flags or [])
        if vals and all(bool(v) for v in vals):
            return [False] * len(vals)
        return vals
    except Exception:
        return list(flags or []) if flags else []


def _sync_uv_flags_from_mesh(context: Any, bm: Any) -> None:
    """With UV Sync on and stale UV flags, the mesh selection is the selection: copy it to the UV flags."""
    if not _sync_on(context) or bool(getattr(bm, "uv_select_sync_valid", True)):
        return
    settings = _tool_settings(context)
    bm.uv_select_sync_from_mesh(sticky_select_mode=str(getattr(settings, "uv_sticky_select_mode", "SHARED_LOCATION")))


def _selected_sets(context: Any, obj: Any, bm: Any, uv_layer: Any, mode: Optional[str] = None) -> Tuple[Set[Any], Set[Any], Set[Any]]:
    """Return the current UV selection without trusting stale .uv_select_* caches.

    Blender 5.1 can keep hidden UV selection attributes in mesh data. Older
    Smart UV Suite builds also wrote those attributes directly. When those
    values are all True, a basic selection command can incorrectly see the whole
    UV map as selected. The 1.8.103 path treats live UV flags as authoritative
    only when they are not suspiciously all-selected. If they are all-selected
    while mesh selection is sparse, the sparse mesh selection is used as the
    real interactive selection. This keeps UV sync ON/OFF, UV select mode, mesh
    select mode and sticky mode unchanged while avoiding cache-driven all-select.
    """
    mode = mode or _uv_mode(context)
    sync = _sync_on(context)
    loops: Set[Any] = set(); edge_loops: Set[Any] = set(); faces: Set[Any] = set()

    face_list = [f for f in bm.faces if not getattr(f, "hide", False)]
    loop_list = [l for f in face_list for l in f.loops]
    try:
        total_loops = len(loop_list)
        total_verts = len([v for v in bm.verts if not getattr(v, "hide", False)])
        total_edges = len([e for e in bm.edges if not getattr(e, "hide", False)])
        total_faces = len(face_list)
    except Exception:
        total_loops = len(loop_list); total_verts = total_edges = total_faces = 0

    uv_v_count = 0; uv_e_count = 0; mesh_v_count = 0; mesh_e_count = 0; mesh_f_count = 0
    for loop in loop_list:
        if _live_v(loop, uv_layer):
            uv_v_count += 1
        if _live_e(loop, uv_layer):
            uv_e_count += 1
    try:
        mesh_v_count = sum(1 for v in bm.verts if not getattr(v, "hide", False) and bool(getattr(v, "select", False)))
    except Exception:
        mesh_v_count = 0
    try:
        mesh_e_count = sum(1 for e in bm.edges if not getattr(e, "hide", False) and bool(getattr(e, "select", False)))
    except Exception:
        mesh_e_count = 0
    try:
        mesh_f_count = sum(1 for f in face_list if bool(getattr(f, "select", False)))
    except Exception:
        mesh_f_count = 0

    # Stale cache signature: every UV loop/edge flag is True, but the actual
    # mesh selection is empty or sparse. This happened repeatedly in the room
    # and is the primary cause of "basic selection becomes all selection".
    v_cache_all = bool(total_loops) and uv_v_count >= total_loops
    e_cache_all = bool(total_loops) and uv_e_count >= total_loops
    # Treat all-selected UV/mesh states as non-authoritative for basic selection.
    # They commonly come from Blender Edit Mode entry or from stale hidden UV flags,
    # not from the user's current UV seed. Partial mesh selection remains a valid
    # UV Sync fallback; full mesh selection does not.
    ignore_live_v = v_cache_all
    ignore_live_e = e_cache_all
    ignore_live_f = v_cache_all
    allow_mesh_v = bool(sync and mesh_v_count > 0 and mesh_v_count < max(1, total_verts))
    allow_mesh_e = bool(sync and mesh_e_count > 0 and mesh_e_count < max(1, total_edges))
    allow_mesh_f = bool(sync and mesh_f_count > 0 and mesh_f_count < max(1, total_faces))

    for face in face_list:
        mesh_face_sel = bool(getattr(face, "select", False))
        live_face_sel = False if ignore_live_f else (mesh_face_sel and all(_live_v(l, uv_layer) for l in face.loops))
        face_selected = ((allow_mesh_f and mesh_face_sel) or live_face_sel) if sync else (False if ignore_live_f else live_face_sel)
        if mode == "FACE" and face_selected:
            faces.add(face)
            for loop in face.loops:
                loops.add(loop); edge_loops.add(loop)
            continue
        for loop in face.loops:
            try:
                mesh_vsel = bool(getattr(loop.vert, "select", False))
                live_vsel = False if ignore_live_v else _live_v(loop, uv_layer)
                vsel = ((allow_mesh_v and mesh_vsel) or live_vsel) if sync else (False if ignore_live_v else live_vsel)
            except Exception:
                vsel = False
            try:
                mesh_esel = bool(getattr(loop.edge, "select", False))
                live_esel = False if ignore_live_e else _live_e(loop, uv_layer)
                esel = ((allow_mesh_e and mesh_esel) or live_esel) if sync else (False if ignore_live_e else live_esel)
            except Exception:
                esel = False
            if mode == "EDGE":
                if esel:
                    edge_loops.add(loop)
                    loops.add(loop)
                    try: loops.add(loop.link_loop_next)
                    except Exception: pass
                elif vsel:
                    loops.add(loop)
            elif mode == "FACE":
                if vsel:
                    loops.add(loop)
                if esel:
                    edge_loops.add(loop)
                    loops.add(loop)
                    try: loops.add(loop.link_loop_next)
                    except Exception: pass
            else:
                if vsel:
                    loops.add(loop)
                if esel:
                    edge_loops.add(loop)
                    loops.add(loop)
                    try: loops.add(loop.link_loop_next)
                    except Exception: pass
    return loops, edge_loops, faces

def _all_sets(bm: Any) -> Tuple[Set[Any], Set[Any], Set[Any]]:
    loops: Set[Any] = set(); edges: Set[Any] = set(); faces: Set[Any] = set()
    for face in bm.faces:
        if getattr(face, "hide", False):
            continue
        faces.add(face)
        for loop in face.loops:
            loops.add(loop); edges.add(loop)
    return loops, edges, faces


def _clear_selection(bm: Any, uv_layer: Any, mesh: bool = False) -> None:
    for face in bm.faces:
        if mesh:
            try: face.select_set(False)
            except Exception: pass
        try: face.uv_select_set(False)
        except Exception: pass
        for loop in face.loops:
            _set_v(loop, uv_layer, False)
            _set_e(loop, uv_layer, False)
    if mesh:
        for edge in bm.edges:
            try: edge.select_set(False)
            except Exception: pass
        for vert in bm.verts:
            try: vert.select_set(False)
            except Exception: pass


def _ensure_bool_attr(mesh: Any, name: str, domain: str) -> Any:
    # Disabled in 1.8.103 final path. The add-on must not create or refresh
    # Blender's hidden UV selection attributes, because stale values there caused
    # UV整列の基本選択が全選択化する問題 and contributed to RNA lookup crashes.
    return None


def _write_hidden_selection_attrs(obj: Any, bm: Any, uv_layer: Any, loops: Set[Any], edge_loops: Set[Any], faces: Set[Any], mode: str) -> None:
    # Live BMesh selection is the source of truth. Do not write .uv_select_*
    # attributes; Blender will maintain its internal state from the live selection.
    return None


def _apply_selection(context: Any, obj: Any, bm: Any, uv_layer: Any, mode: str, loops: Iterable[Any], edge_loops: Iterable[Any], faces: Iterable[Any]) -> None:
    loops_set: Set[Any] = set(loops or [])
    edge_set: Set[Any] = set(edge_loops or [])
    face_set: Set[Any] = set(faces or [])
    mesh_sync = _sync_on(context)
    if mode == "FACE":
        for face in list(face_set):
            for loop in face.loops:
                loops_set.add(loop); edge_set.add(loop)
    elif mode == "EDGE":
        for loop in list(edge_set):
            loops_set.add(loop)
            try: loops_set.add(loop.link_loop_next)
            except Exception: pass
    _clear_selection(bm, uv_layer, mesh=mesh_sync)
    if mode == "FACE":
        for face in face_set:
            if mesh_sync:
                try: face.select_set(True)
                except Exception: pass
            try: face.uv_select_set(True)
            except Exception: pass
            for loop in face.loops:
                _set_v(loop, uv_layer, True); _set_e(loop, uv_layer, True)
                if mesh_sync:
                    try: loop.vert.select_set(True)
                    except Exception: pass
                    try: loop.edge.select_set(True)
                    except Exception: pass
    elif mode == "EDGE":
        for loop in edge_set:
            _set_e(loop, uv_layer, True)
            _set_v(loop, uv_layer, True)
            try: _set_v(loop.link_loop_next, uv_layer, True)
            except Exception: pass
            if mesh_sync:
                try: loop.edge.select_set(True)
                except Exception: pass
                try: loop.vert.select_set(True)
                except Exception: pass
                try: loop.link_loop_next.vert.select_set(True)
                except Exception: pass
        for loop in loops_set:
            try:
                _set_v(loop, uv_layer, True)
                if mesh_sync:
                    loop.vert.select_set(True)
            except Exception:
                pass
    else:
        for loop in loops_set:
            try:
                _set_v(loop, uv_layer, True)
                if mesh_sync:
                    loop.vert.select_set(True)
            except Exception:
                pass
    _write_hidden_selection_attrs(obj, bm, uv_layer, loops_set, edge_set, face_set, mode)


def _uv_face_visible(face: Any, sync: bool = True) -> bool:
    """A face is in the UV Editor only when unhidden and, without UV Sync, selected in 3D."""
    if getattr(face, "hide", False):
        return False
    return True if sync else bool(getattr(face, "select", False))


def _colocated_loops(loop: Any, uv_layer: Any, sync: bool = False) -> List[Any]:
    """Loops forming one UV vertex: same mesh vertex, same UV location, visible in the UV Editor."""
    here = _uv_xy(loop, uv_layer)
    out = [c for c in loop.vert.link_loops if _uv_face_visible(c.face, sync) and _close(_uv_xy(c, uv_layer), here)]
    return out or [loop]


def _welded_edge_loops(loop: Any, uv_layer: Any, sync: bool = False) -> List[Any]:
    """The loop plus the loops on the other side of the same UV edge (a seam separates them)."""
    out = [loop]
    for other in loop.edge.link_loops:
        if other is not loop and _uv_face_visible(other.face, sync) and _same_uv_edge(loop, other, uv_layer):
            out.append(other)
    return out


def _neighbor_faces_by_uv(face: Any, uv_layer: Any, sync: bool = True) -> Iterable[Any]:
    try:
        for edge in face.edges:
            la = next((l for l in face.loops if l.edge is edge), None)
            if la is None:
                continue
            for other in edge.link_faces:
                if other is face or not _uv_face_visible(other, sync):
                    continue
                lb = next((l for l in other.loops if l.edge is edge), None)
                if lb is not None and _same_uv_edge(la, lb, uv_layer):
                    yield other
    except Exception:
        return


def _linked_faces(seed_faces: Set[Any], uv_layer: Any, sync: bool = True) -> Set[Any]:
    seen = set(seed_faces or [])
    q = deque(seen)
    while q:
        face = q.popleft()
        for nf in _neighbor_faces_by_uv(face, uv_layer, sync):
            if nf not in seen:
                seen.add(nf); q.append(nf)
    return seen


def _selection_grow(mode: str, bm: Any, uv_layer: Any, loops: Set[Any], edge_loops: Set[Any], faces: Set[Any], *, sync: bool = True):
    if mode == "FACE":
        out = set(faces) or {l.face for l in loops} or {l.face for l in edge_loops}
        for face in list(out):
            for nf in _neighbor_faces_by_uv(face, uv_layer, sync):
                out.add(nf)
        return set(), set(), out
    if not sync:
        # Without UV Sync the selection lives on UV elements: follow UV connectivity,
        # so a seam stops the growth and faces outside the UV Editor stay untouched.
        if mode == "EDGE":
            grown: Set[Any] = set()
            for loop in (edge_loops or loops):
                for end in (loop, loop.link_loop_next):
                    for c in _colocated_loops(end, uv_layer):
                        grown.add(c)
                        grown.add(c.link_loop_prev)
            return set(), {w for l in grown for w in _welded_edge_loops(l, uv_layer)}, set()
        grown = set()
        for loop in loops:
            for c in _colocated_loops(loop, uv_layer):
                grown.add(c)
                grown.update(_colocated_loops(c.link_loop_next, uv_layer))
                grown.update(_colocated_loops(c.link_loop_prev, uv_layer))
        return grown, set(), set()
    if mode == "EDGE":
        selected_edges = {l.edge for l in edge_loops}
        if not selected_edges and loops:
            selected_edges = {l.edge for l in loops}
        out_edges = set(selected_edges)
        for edge in list(selected_edges):
            for vert in edge.verts:
                for cand in getattr(vert, "link_edges", []) or []:
                    out_edges.add(cand)
        out = {l for f in bm.faces for l in f.loops if l.edge in out_edges}
        return set(), out, set()
    selected_verts = {l.vert for l in loops}
    out_verts = set(selected_verts)
    for vert in list(selected_verts):
        for edge in getattr(vert, "link_edges", []) or []:
            try: out_verts.add(edge.other_vert(vert))
            except Exception: pass
    out = {l for f in bm.faces for l in f.loops if l.vert in out_verts}
    return out, set(), set()


def _selection_shrink(mode: str, bm: Any, uv_layer: Any, loops: Set[Any], edge_loops: Set[Any], faces: Set[Any], *, sync: bool = True):
    if mode == "FACE":
        selected = set(faces) or {l.face for l in loops} or {l.face for l in edge_loops}
        keep = set()
        for face in selected:
            border = False
            for nf in _neighbor_faces_by_uv(face, uv_layer, sync):
                if nf not in selected:
                    border = True; break
            if not border:
                keep.add(face)
        return set(), set(), keep
    if mode == "EDGE":
        # An edge survives only when no unselected edge touches either end.
        if not sync:
            chosen = {w for l in edge_loops for w in _welded_edge_loops(l, uv_layer)}
            def _inner(end: Any) -> bool:
                return all(c in chosen and c.link_loop_prev in chosen for c in _colocated_loops(end, uv_layer))
            out = {l for l in chosen if _inner(l) and _inner(l.link_loop_next)}
            return set(), out, set()
        selected_edges = {l.edge for l in edge_loops}
        keep_edges = set()
        for edge in selected_edges:
            if all(all(e in selected_edges for e in (getattr(vert, "link_edges", []) or [])) for vert in edge.verts):
                keep_edges.add(edge)
        out = {l for f in bm.faces for l in f.loops if l.edge in keep_edges}
        return set(), out, set()
    if not sync:
        def _on(loop: Any) -> bool:
            return any(c in loops for c in _colocated_loops(loop, uv_layer))
        kept: Set[Any] = set()
        for loop in loops:
            group = _colocated_loops(loop, uv_layer)
            if all(_on(c.link_loop_next) and _on(c.link_loop_prev) for c in group):
                kept.update(group)
        return kept, set(), set()
    selected_verts = {l.vert for l in loops}
    keep = set()
    for vert in selected_verts:
        linked = list(getattr(vert, "link_edges", []) or [])
        if linked and all(edge.other_vert(vert) in selected_verts for edge in linked):
            keep.add(vert)
    out = {l for f in bm.faces for l in f.loops if l.vert in keep}
    return out, set(), set()


def _selection_linked(mode: str, bm: Any, uv_layer: Any, loops: Set[Any], edge_loops: Set[Any], faces: Set[Any], *, sync: bool = True):
    seed = set(faces) or {l.face for l in loops} or {l.face for l in edge_loops}
    linked = _linked_faces(seed, uv_layer, sync)
    if mode == "FACE":
        return set(), set(), linked
    edge_out: Set[Any] = set(); loop_out: Set[Any] = set()
    for face in linked:
        for loop in face.loops:
            loop_out.add(loop); edge_out.add(loop)
    return (set(), edge_out, set()) if mode == "EDGE" else (loop_out, set(), set())


def _selection_border(mode: str, bm: Any, uv_layer: Any, loops: Set[Any], edge_loops: Set[Any], faces: Set[Any], *, sync: bool = True):
    region = set(faces)
    if not region:
        # Vertex and edge modes carry no face set: the region is what the selection encloses.
        def _enclosed(face: Any) -> bool:
            if mode == "EDGE":
                return all(any(w in edge_loops for w in _welded_edge_loops(l, uv_layer, True)) for l in face.loops)
            return all(any(c in loops for c in _colocated_loops(l, uv_layer, True)) for l in face.loops)
        region = {f for f in bm.faces if not getattr(f, "hide", False) and _enclosed(f)}
    if not region:
        region = set(_selection_linked("FACE", bm, uv_layer, loops, edge_loops, set(), sync=sync)[2])
    border: Set[Any] = set()
    for face in region:
        for loop in face.loops:
            neighbors = [f for f in loop.edge.link_faces if f is not face and f in region]
            if not neighbors:
                border.add(loop); continue
            welded = False
            for nf in neighbors:
                nl = next((l for l in nf.loops if l.edge is loop.edge), None)
                if nl is not None and _same_uv_edge(loop, nl, uv_layer):
                    welded = True; break
            if not welded:
                border.add(loop)
    if mode == "VERTEX":
        out: Set[Any] = set()
        for loop in border:
            out.add(loop)
            try: out.add(loop.link_loop_next)
            except Exception: pass
        return out, set(), set()
    if mode == "FACE":
        return set(), border, set()
    return set(), border, set()


def _selection_invert(mode: str, bm: Any, loops: Set[Any], edge_loops: Set[Any], faces: Set[Any]):
    all_loops, all_edges, all_faces = _all_sets(bm)
    if mode == "FACE":
        return set(), set(), all_faces - faces
    if mode == "EDGE":
        return set(), all_edges - edge_loops, set()
    return all_loops - loops, set(), set()


def _seed_mesh_edges(bm: Any, seed_edges: Set[Any]) -> None:
    for v in bm.verts:
        try: v.select_set(False)
        except Exception: pass
    for e in bm.edges:
        try: e.select_set(e in seed_edges)
        except Exception: pass
    for f in bm.faces:
        try: f.select_set(False)
        except Exception: pass


def _fallback_ring(seed_edges: Set[Any]) -> Set[Any]:
    out = set(seed_edges)
    q = deque(seed_edges)
    while q:
        edge = q.popleft()
        for face in getattr(edge, "link_faces", []) or []:
            if len(getattr(face, "edges", []) or []) != 4:
                continue
            edges = list(face.edges)
            try: idx = edges.index(edge)
            except Exception: continue
            opp = edges[(idx + 2) % 4]
            if opp not in out:
                out.add(opp); q.append(opp)
    return out


def _fallback_loop(seed_edges: Set[Any]) -> Set[Any]:
    # Conservative pure-Python fallback: use same-direction connected edges.
    out = set(seed_edges)
    q = deque(seed_edges)
    def direction(edge: Any) -> Optional[Tuple[float, float, float]]:
        try:
            a, b = edge.verts
            co = b.co - a.co
            length = co.length
            if length <= 1.0e-12:
                return None
            return (round(float(co.x / length), 4), round(float(co.y / length), 4), round(float(co.z / length), 4))
        except Exception:
            return None
    dirs = {edge: direction(edge) for edge in seed_edges}
    while q:
        edge = q.popleft()
        d0 = dirs.get(edge) or direction(edge)
        for vert in getattr(edge, "verts", []) or []:
            for cand in getattr(vert, "link_edges", []) or []:
                if cand in out:
                    continue
                d1 = direction(cand)
                if d0 is not None and d1 is not None:
                    dot = abs(d0[0]*d1[0] + d0[1]*d1[1] + d0[2]*d1[2])
                    if dot < 0.90:
                        continue
                out.add(cand); dirs[cand] = d1; q.append(cand)
    return out


def _selection_loop_ring(context: Any, obj: Any, bm: Any, uv_layer: Any, action: str, loops: Set[Any], edge_loops: Set[Any]):
    seed_edges = {l.edge for l in edge_loops}
    if not seed_edges:
        seed_edges = {l.edge for l in loops}
    if not seed_edges:
        return set(), set(), set()
    # Final 1.8.103 policy: do not call mesh.loop_multi_select here.  The native
    # operator changes mesh select mode and can return rebuilt BMesh edge objects,
    # which previously made Loop/Ring either alter user modes or apply stale
    # selections.  Use deterministic in-memory traversal and write only the
    # active UV selection domain.
    selected_edges = _fallback_ring(seed_edges) if action == "RING" else _fallback_loop(seed_edges)
    out = {l for f in bm.faces for l in f.loops if l.edge in selected_edges}
    return set(), out, set()


def _execute_select_18102(self: Any, context: Any):
    action = _s(getattr(self, "action", "GROW")).upper() or "GROW"
    snap = _snapshot_modes(context)
    obj, old_mode, changed = _enter_edit(context)
    if obj is None:
        _report(self, "WARNING", _tr(context, "No mesh object is active.", "アクティブなメッシュオブジェクトがありません。"))
        return {"CANCELLED"}
    try:
        _ensure_uv_target(context, obj)
        import bmesh
        bm = bmesh.from_edit_mesh(obj.data); _ensure_lookup(bm)
        uv_layer = _uv_layer(bm)
        if uv_layer is None:
            _report(self, "WARNING", _tr(context, "No UV map is available.", "使用可能なUVマップがありません。"))
            return {"CANCELLED"}
        mode = _uv_mode(context)
        loops, edge_loops, faces = _selected_sets(context, obj, bm, uv_layer, mode)
        if action == "NONE":
            _clear_selection(bm, uv_layer, mesh=_sync_on(context))
            _write_hidden_selection_attrs(obj, bm, uv_layer, set(), set(), set(), mode)
        elif action == "ALL":
            all_loops, all_edges, all_faces = _all_sets(bm)
            _apply_selection(context, obj, bm, uv_layer, mode, all_loops, all_edges, all_faces)
        else:
            if not (loops or edge_loops or faces):
                _report(self, "WARNING", _tr(context, "No UV element is selected.", "選択されたUVエレメントがありません。"))
                return {"CANCELLED"}
            if action == "GROW":
                out = _selection_grow(mode, bm, uv_layer, loops, edge_loops, faces, sync=_sync_on(context))
            elif action == "SHRINK":
                out = _selection_shrink(mode, bm, uv_layer, loops, edge_loops, faces, sync=_sync_on(context))
            elif action == "LINKED":
                out = _selection_linked(mode, bm, uv_layer, loops, edge_loops, faces, sync=_sync_on(context))
            elif action == "BORDER":
                out = _selection_border(mode, bm, uv_layer, loops, edge_loops, faces, sync=_sync_on(context))
            elif action == "INVERT":
                out = _selection_invert(mode, bm, loops, edge_loops, faces)
            elif action in {"LOOP", "RING"}:
                out = _selection_loop_ring(context, obj, bm, uv_layer, action, loops, edge_loops)
            else:
                _report(self, "WARNING", f"Unsupported selection action: {action}")
                return {"CANCELLED"}
            _apply_selection(context, obj, bm, uv_layer, mode, out[0], out[1], out[2])
        try:
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        except TypeError:
            bmesh.update_edit_mesh(obj.data)
        try:
            if getattr(context, "area", None) is not None:
                context.area.tag_redraw()
        except Exception:
            pass
        return {"FINISHED"}
    except Exception as exc:
        _report(self, "WARNING", _tr(context, "UV selection operation failed.", "UV選択処理に失敗しました。") + f" {exc}")
        return {"CANCELLED"}
    finally:
        _restore_modes(snap)
        _restore_edit(obj, old_mode, changed)
        _restore_modes(snap)


def _sticky_key(obj: Any, loop: Any, uv_layer: Any, sticky: str) -> Any:
    try:
        data_key = int(obj.data.as_pointer()) if hasattr(obj.data, "as_pointer") else id(obj.data)
    except Exception:
        data_key = id(obj)
    if sticky == "SHARED_LOCATION":
        return ("loc", data_key, _uv_key(loop, uv_layer))
    if sticky == "SHARED_VERTEX":
        try:
            return ("vert", data_key, int(loop.vert.index))
        except Exception:
            return ("vert", data_key, id(loop.vert))
    return ("loop", data_key, _face_index(loop.face), _loop_index(loop))


def _make_record(obj: Any, loop: Any, uv_layer: Any, source: bool = True) -> Dict[str, Any]:
    u, v = _uv_xy(loop, uv_layer)
    return {"obj": obj, "mesh": obj.data, "loop": loop, "uv_layer": uv_layer, "u": u, "v": v, "source": source}


def _selected_anchor_records(context: Any, obj: Any, bm: Any, uv_layer: Any, mode: str) -> Tuple[List[Dict[str, Any]], Set[Any], Set[Any], Set[Any]]:
    loops, edge_loops, faces = _selected_sets(context, obj, bm, uv_layer, mode)
    records: List[Dict[str, Any]] = []
    seen: Set[int] = set()
    def add_loop(loop: Any) -> None:
        try:
            key = id(loop)
            if key in seen:
                return
            seen.add(key)
            records.append(_make_record(obj, loop, uv_layer, True))
        except Exception:
            pass
    if mode == "FACE":
        for face in faces:
            for loop in face.loops:
                add_loop(loop)
    elif mode == "EDGE":
        for loop in edge_loops:
            add_loop(loop)
            try: add_loop(loop.link_loop_next)
            except Exception: pass
    else:
        for loop in loops:
            add_loop(loop)
    return records, loops, edge_loops, faces


def _all_loop_records_by_sticky(objs: Sequence[Any], sticky: str) -> Dict[Any, List[Dict[str, Any]]]:
    out: Dict[Any, List[Dict[str, Any]]] = defaultdict(list)
    if sticky not in {"SHARED_LOCATION", "SHARED_VERTEX"}:
        return out
    try:
        import bmesh
    except Exception:
        return out
    for obj in objs:
        try:
            _ensure_uv_target(bpy.context, obj)
            bm = bmesh.from_edit_mesh(obj.data); _ensure_lookup(bm); uv_layer = _uv_layer(bm)
        except Exception:
            continue
        for face in bm.faces:
            for loop in face.loops:
                try:
                    key = _sticky_key(obj, loop, uv_layer, sticky)
                    out[key].append(_make_record(obj, loop, uv_layer, False))
                except Exception:
                    pass
    return out


def _pointify(records: Sequence[Dict[str, Any]], sticky: str, follower_index: Optional[Dict[Any, List[Dict[str, Any]]]] = None, exclude_loop_ids: Optional[Set[int]] = None) -> List[Dict[str, Any]]:
    buckets: Dict[Any, List[Dict[str, Any]]] = {}
    order: List[Any] = []
    source_loop_ids = {id(r.get("loop")) for r in records}
    excluded = set(exclude_loop_ids or set()) | source_loop_ids
    for rec in records:
        key = _sticky_key(rec["obj"], rec["loop"], rec["uv_layer"], sticky) if sticky in {"SHARED_LOCATION", "SHARED_VERTEX"} else ("loop", id(rec["loop"]))
        if key not in buckets:
            buckets[key] = []; order.append(key)
        buckets[key].append(rec)
        if follower_index and sticky in {"SHARED_LOCATION", "SHARED_VERTEX"}:
            for follower in follower_index.get(key, []) or []:
                # In grouped alignment, sticky-equivalent endpoints from another
                # selected group must not be pulled in as followers.  Only
                # unselected sticky mates are moved with the selected endpoint.
                if id(follower.get("loop")) in excluded:
                    continue
                buckets[key].append(follower)
    points: List[Dict[str, Any]] = []
    for key in order:
        recs = buckets.get(key) or []
        if not recs:
            continue
        source_recs = [r for r in recs if r.get("source")]
        base = source_recs or recs
        u = sum(float(r.get("u", 0.0)) for r in base) / max(1, len(base))
        v = sum(float(r.get("v", 0.0)) for r in base) / max(1, len(base))
        points.append({"key": key, "records": recs, "u": u, "v": v})
    return points


def _write_point(point: Dict[str, Any], u: Optional[float] = None, v: Optional[float] = None) -> int:
    changed = 0
    for rec in list(point.get("records") or []):
        try:
            uv = rec["loop"][rec["uv_layer"]].uv
            if u is not None:
                uv.x = float(u); rec["u"] = float(u)
            if v is not None:
                uv.y = float(v); rec["v"] = float(v)
            changed += 1
        except Exception:
            pass
    if u is not None: point["u"] = float(u)
    if v is not None: point["v"] = float(v)
    return changed


def _apply_points(points: Sequence[Dict[str, Any]], action: str) -> int:
    pts = [p for p in points if p]
    if not pts:
        return 0
    us = [float(p.get("u", 0.0)) for p in pts]
    vs = [float(p.get("v", 0.0)) for p in pts]
    min_u, max_u = min(us), max(us); min_v, max_v = min(vs), max(vs)
    center_u, center_v = (min_u + max_u) * 0.5, (min_v + max_v) * 0.5
    action = str(action or "").upper()
    changed = 0
    if action == "DISTRIBUTE_H" or action == "DISTRIBUTE_V":
        axis_u = action == "DISTRIBUTE_H"
        key = (lambda p: float(p.get("u", 0.0))) if axis_u else (lambda p: float(p.get("v", 0.0)))
        ordered = sorted(pts, key=key)
        if len(ordered) <= 1:
            return 0
        start, end = key(ordered[0]), key(ordered[-1])
        if abs(end - start) <= 1.0e-12:
            return 0
        step = (end - start) / float(max(1, len(ordered) - 1))
        for i, p in enumerate(ordered):
            value = start + step * i
            changed += _write_point(p, u=value) if axis_u else _write_point(p, v=value)
        return changed
    if action in {"FLIP_H", "FLIP_V", "ROTATE_CCW", "ROTATE_CW"}:
        for p in pts:
            u = float(p.get("u", 0.0)); v = float(p.get("v", 0.0))
            if action == "FLIP_H":
                changed += _write_point(p, u=center_u - (u - center_u))
            elif action == "FLIP_V":
                changed += _write_point(p, v=center_v - (v - center_v))
            elif action == "ROTATE_CCW":
                changed += _write_point(p, u=center_u - (v - center_v), v=center_v + (u - center_u))
            elif action == "ROTATE_CW":
                changed += _write_point(p, u=center_u + (v - center_v), v=center_v - (u - center_u))
        return changed
    set_u = None; set_v = None
    if action in {"ALIGN_TL", "ALIGN_LEFT", "ALIGN_BL"}: set_u = min_u
    elif action in {"ALIGN_TR", "ALIGN_RIGHT", "ALIGN_BR"}: set_u = max_u
    elif action in {"ALIGN_CENTER", "ALIGN_V"}: set_u = center_u
    if action in {"ALIGN_TL", "ALIGN_TOP", "ALIGN_TR"}: set_v = max_v
    elif action in {"ALIGN_BL", "ALIGN_BOTTOM", "ALIGN_BR"}: set_v = min_v
    elif action in {"ALIGN_CENTER", "ALIGN_H"}: set_v = center_v
    if set_u is None and set_v is None:
        return 0
    for p in pts:
        changed += _write_point(p, u=set_u, v=set_v)
    return changed


def _records_for_loop(records: Sequence[Dict[str, Any]]) -> Dict[int, int]:
    return {id(r.get("loop")): i for i, r in enumerate(records)}


def _source_groups_from_selection(context: Any, obj: Any, bm: Any, uv_layer: Any, mode: str, records: List[Dict[str, Any]], edge_loops: Set[Any], faces: Set[Any]) -> List[List[Dict[str, Any]]]:
    if not records:
        return []
    if mode == "VERTEX":
        parent = list(range(len(records)))
        index = _records_for_loop(records)
        by_vert: Dict[Any, List[int]] = defaultdict(list)
        for i, rec in enumerate(records):
            try: by_vert[rec["loop"].vert].append(i)
            except Exception: pass
        selected_verts = set(by_vert.keys())
        for edge in bm.edges:
            try:
                if edge.verts[0] in selected_verts and edge.verts[1] in selected_verts:
                    a = by_vert[edge.verts[0]][0]; b = by_vert[edge.verts[1]][0]
                    _union(parent, a, b)
            except Exception:
                pass
        return _records_by_parent(records, parent)
    if mode == "EDGE":
        selected_edges = {l.edge for l in edge_loops}
        edge_to_indices: Dict[Any, List[int]] = defaultdict(list)
        for i, rec in enumerate(records):
            try:
                loop = rec["loop"]
                if loop.edge in selected_edges:
                    edge_to_indices[loop.edge].append(i)
                # endpoint from next loop belongs to the same selected edge.
                for sl in edge_loops:
                    if sl.link_loop_next is loop:
                        edge_to_indices[sl.edge].append(i)
            except Exception:
                pass
        edge_list = list(selected_edges)
        edge_parent = list(range(len(edge_list)))
        pos = {e: i for i, e in enumerate(edge_list)}
        endpoints: Dict[Tuple[Any, Tuple[float, float]], List[Any]] = defaultdict(list)
        for edge in edge_list:
            for loop in edge_loops:
                if loop.edge is not edge:
                    continue
                try:
                    endpoints[(loop.vert, _uv_key(loop, uv_layer))].append(edge)
                    endpoints[(loop.link_loop_next.vert, _uv_key(loop.link_loop_next, uv_layer))].append(edge)
                except Exception:
                    pass
        for edges in endpoints.values():
            for e in edges[1:]:
                _union(edge_parent, pos[edges[0]], pos[e])
        groups: Dict[int, List[Dict[str, Any]]] = defaultdict(list)
        for edge in edge_list:
            root = _find(edge_parent, pos[edge])
            for idx in edge_to_indices.get(edge, []) or []:
                rec = records[idx]
                if rec not in groups[root]:
                    groups[root].append(rec)
        return [g for g in groups.values() if g]
    # FACE mode: selected faces are connected only by shared, welded UV edges.
    face_list = list(faces)
    if not face_list:
        face_list = list({r["loop"].face for r in records})
    face_parent = list(range(len(face_list)))
    fpos = {f: i for i, f in enumerate(face_list)}
    face_set = set(face_list)
    for face in face_list:
        for edge in face.edges:
            la = next((l for l in face.loops if l.edge is edge), None)
            if la is None:
                continue
            for other in edge.link_faces:
                if other is face or other not in face_set:
                    continue
                lb = next((l for l in other.loops if l.edge is edge), None)
                if lb is not None and _same_uv_edge(la, lb, uv_layer):
                    _union(face_parent, fpos[face], fpos[other])
    groups: Dict[int, List[Dict[str, Any]]] = defaultdict(list)
    face_root = {face: _find(face_parent, fpos[face]) for face in face_list}
    for rec in records:
        try:
            groups[face_root[rec["loop"].face]].append(rec)
        except Exception:
            pass
    return [g for g in groups.values() if g]


def _find(parent: List[int], i: int) -> int:
    while parent[i] != i:
        parent[i] = parent[parent[i]]
        i = parent[i]
    return i


def _union(parent: List[int], a: int, b: int) -> None:
    if a < 0 or b < 0 or a >= len(parent) or b >= len(parent):
        return
    ra, rb = _find(parent, a), _find(parent, b)
    if ra != rb:
        parent[rb] = ra


def _records_by_parent(records: Sequence[Dict[str, Any]], parent: List[int]) -> List[List[Dict[str, Any]]]:
    groups: Dict[int, List[Dict[str, Any]]] = defaultdict(list)
    for i, rec in enumerate(records):
        groups[_find(parent, i)].append(rec)
    return [g for g in groups.values() if g]


def _execute_vertex_align_18102(self: Any, context: Any):
    raw = _s(getattr(self, "action", "ALIGN_CENTER")).upper() or "ALIGN_CENTER"
    snap = _snapshot_modes(context)
    obj, old_mode, changed_mode = _enter_edit(context)
    if obj is None:
        _report(self, "WARNING", _tr(context, "No mesh object is active.", "アクティブなメッシュオブジェクトがありません。"))
        return {"CANCELLED"}
    try:
        import bmesh
        _ensure_uv_target(context, obj)
        bm = bmesh.from_edit_mesh(obj.data); _ensure_lookup(bm); uv_layer = _uv_layer(bm)
        mode = _uv_mode(context)
        source_records, loops, edge_loops, faces = _selected_anchor_records(context, obj, bm, uv_layer, mode)
        if not source_records:
            _report(self, "WARNING", _tr(context, "No UV element is selected.", "選択されたUVエレメントがありません。"))
            return {"CANCELLED"}
        sticky = _sticky_mode(context)
        objs = _edit_objects(context) or [obj]
        followers = _all_loop_records_by_sticky(objs, sticky)
        by_group = raw in _GROUP_ACTIONS
        action = raw[:-6] if by_group else raw
        source_groups = _source_groups_from_selection(context, obj, bm, uv_layer, mode, source_records, edge_loops, faces) if by_group else [source_records]
        all_selected_source_loop_ids = {id(r.get("loop")) for r in source_records}
        changed = 0
        for source_group in source_groups:
            points = _pointify(source_group, sticky, followers, all_selected_source_loop_ids if by_group else None)
            changed += _apply_points(points, action)
        try:
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        except TypeError:
            bmesh.update_edit_mesh(obj.data)
        try:
            if getattr(context, "area", None) is not None:
                context.area.tag_redraw()
        except Exception:
            pass
        return {"FINISHED"}
    except Exception as exc:
        _report(self, "WARNING", _tr(context, "Vertex direction alignment failed.", "方向整列（頂点）に失敗しました。") + f" {exc}")
        return {"CANCELLED"}
    finally:
        _restore_modes(snap)
        _restore_edit(obj, old_mode, changed_mode)
        _restore_modes(snap)


def _event_region_xy(event: Any) -> Tuple[int, int]:
    return int(getattr(event, "mouse_region_x", 0) or 0), int(getattr(event, "mouse_region_y", 0) or 0)


def _region_to_uv(context: Any, x: int, y: int) -> Optional[Tuple[float, float]]:
    try:
        v2d = getattr(getattr(context, "region", None), "view2d", None)
        if v2d is None:
            return None
        u, v = v2d.region_to_view(float(x), float(y))
        return float(u), float(v)
    except Exception:
        return None


def _uv_hit_tolerance(context: Any, x: int, y: int, pixels: float = 8.0) -> float:
    c = _region_to_uv(context, x, y)
    px = _region_to_uv(context, x + int(pixels), y)
    py = _region_to_uv(context, x, y + int(pixels))
    if c is None or px is None or py is None:
        return 1.0e-3
    dx = math.hypot(px[0] - c[0], px[1] - c[1])
    dy = math.hypot(py[0] - c[0], py[1] - c[1])
    return max(dx, dy, 1.0e-8)


def _distance_to_segment(p: Tuple[float, float], a: Tuple[float, float], b: Tuple[float, float]) -> float:
    px, py = p; ax, ay = a; bx, by = b
    abx, aby = bx - ax, by - ay
    denom = abx * abx + aby * aby
    if denom <= 1.0e-20:
        return math.hypot(px - ax, py - ay)
    t = ((px - ax) * abx + (py - ay) * aby) / denom
    t = max(0.0, min(1.0, t))
    return math.hypot(px - (ax + abx * t), py - (ay + aby * t))


def _point_in_poly(p: Tuple[float, float], pts: Sequence[Tuple[float, float]]) -> bool:
    if len(pts) < 3:
        return False
    px, py = p; inside = False; j = len(pts) - 1
    for i, (xi, yi) in enumerate(pts):
        xj, yj = pts[j]
        if (yi > py) != (yj > py):
            denom = (yj - yi) if abs(yj - yi) > 1.0e-20 else 1.0e-20
            if px < (xj - xi) * (py - yi) / denom + xi:
                inside = not inside
        j = i
    return inside


def _direct_find_uv_hit(self: Any, context: Any, event: Any) -> Optional[Dict[str, Any]]:
    xy = _event_region_xy(event)
    uv = _region_to_uv(context, xy[0], xy[1])
    if uv is None:
        return None
    obj = _active_mesh(context)
    if obj is None or getattr(obj, "mode", None) != "EDIT":
        return None
    try:
        import bmesh
        _ensure_uv_target(context, obj)
        bm = bmesh.from_edit_mesh(obj.data); _ensure_lookup(bm); uv_layer = _uv_layer(bm)
    except Exception:
        return None
    if uv_layer is None:
        return None
    tol = _uv_hit_tolerance(context, xy[0], xy[1])
    mode = _uv_mode(context)
    best_v = None; best_e = None; best_f = None
    try:
        for face in bm.faces:
            if getattr(face, "hide", False):
                continue
            pts: List[Tuple[float, float]] = []
            loops = list(face.loops)
            for loop in loops:
                p = _uv_xy(loop, uv_layer); pts.append(p)
                d = math.hypot(p[0] - uv[0], p[1] - uv[1])
                if d <= tol and (best_v is None or d < best_v["dist"]):
                    best_v = {"type": "VERTEX", "dist": d, "face": face, "loop": loop, "uv": p, "uv_layer": uv_layer}
            for i, loop in enumerate(loops):
                if len(pts) < 2:
                    continue
                d = _distance_to_segment(uv, pts[i], pts[(i + 1) % len(pts)])
                if d <= tol and (best_e is None or d < best_e["dist"]):
                    best_e = {"type": "EDGE", "dist": d, "face": face, "loop": loop, "edge": loop.edge, "uv": uv, "uv_layer": uv_layer}
            if len(pts) >= 3 and _point_in_poly(uv, pts) and best_f is None:
                best_f = {"type": "FACE", "dist": 0.0, "face": face, "loop": loops[0] if loops else None, "uv": uv, "uv_layer": uv_layer}
    except Exception:
        return None
    hit = None
    if mode == "VERTEX": hit = best_v
    elif mode == "EDGE": hit = best_e or best_v
    elif mode == "FACE": hit = best_f or (dict(best_e, type="FACE") if best_e else None) or (dict(best_v, type="FACE") if best_v else None)
    else: hit = best_v or best_e or best_f
    if not hit:
        return None
    # Keep live BMFace/BMLoop wrappers valid across the return boundary.
    hit['_bmesh_owner'] = bm
    try:
        tl, te, tf = _target_from_hit(hit, uv_layer)
        hit["target_loops"] = tl; hit["target_edges"] = te; hit["target_faces"] = tf
    except Exception:
        pass
    return hit


def _target_from_hit(hit: Dict[str, Any], uv_layer: Any) -> Tuple[Set[Any], Set[Any], Set[Any]]:
    loops: Set[Any] = set(); edges: Set[Any] = set(); faces: Set[Any] = set()
    htype = _s(hit.get("type")).upper()
    loop = hit.get("loop"); face = hit.get("face")
    if htype == "VERTEX" and loop is not None:
        loops.add(loop)
    elif htype == "EDGE" and loop is not None:
        edges.add(loop); loops.add(loop)
        try: loops.add(loop.link_loop_next)
        except Exception: pass
    elif htype in {"FACE", "ISLAND"} and face is not None:
        face_set = _linked_faces({face}, uv_layer) if htype == "ISLAND" else {face}
        for f in face_set:
            faces.add(f)
            for l in f.loops:
                loops.add(l); edges.add(l)
    return loops, edges, faces


def _hit_is_selected(context: Any, hit: Dict[str, Any]) -> bool:
    try:
        uv_layer = hit.get("uv_layer")
        loops, edges, faces = _target_from_hit(hit, uv_layer)
        if _sync_on(context):
            # UV flags can remain selected while the synced mesh selection has
            # changed. Only the mesh owns selection in this mode.
            if faces:
                return all(bool(f.select) for f in faces)
            if edges:
                return all(bool(l.edge.select) for l in edges)
            if loops:
                return all(bool(l.vert.select) for l in loops)
            return False
        if faces:
            return all(bool(getattr(f, "select", False)) for f in faces)
        if edges:
            return all(_live_e(l, uv_layer) or bool(getattr(l.edge, "select", False)) for l in edges)
        if loops:
            return all(_live_v(l, uv_layer) or bool(getattr(l.vert, "select", False)) for l in loops)
    except Exception:
        pass
    return False


def _select_hit_immediate(context: Any, hit: Dict[str, Any], event: Any) -> bool:
    obj = _active_mesh(context)
    if obj is None:
        return False
    try:
        import bmesh
        bm = bmesh.from_edit_mesh(obj.data); _ensure_lookup(bm); uv_layer = hit.get("uv_layer") or _uv_layer(bm)
        mode = _uv_mode(context)
        loops, edges, faces = _target_from_hit(hit, uv_layer)
        if not (loops or edges or faces):
            return False
        extend = bool(getattr(event, "shift", False)); toggle = bool(getattr(event, "ctrl", False))
        if extend or toggle:
            cur_loops, cur_edges, cur_faces = _selected_sets(context, obj, bm, uv_layer, mode)
            if toggle:
                # Toggle target off only when every target is already selected.
                if _hit_is_selected(context, hit):
                    loops = cur_loops - loops; edges = cur_edges - edges; faces = cur_faces - faces
                else:
                    loops = cur_loops | loops; edges = cur_edges | edges; faces = cur_faces | faces
            else:
                loops = cur_loops | loops; edges = cur_edges | edges; faces = cur_faces | faces
        _apply_selection(context, obj, bm, uv_layer, mode, loops, edges, faces)
        try:
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        except TypeError:
            bmesh.update_edit_mesh(obj.data)
        return True
    except Exception:
        return False


def _active_tool_id(context: Any) -> str:
    try:
        tools = getattr(getattr(context, "workspace", None), "tools", None)
        if tools is None:
            return ""
        for args in (("UV",), ("IMAGE_EDITOR",), tuple()):
            try:
                tool = tools.from_space_image_mode(*args, create=False)
            except TypeError:
                try: tool = tools.from_space_image_mode(*args)
                except Exception: tool = None
            except Exception:
                tool = None
            text = _s(getattr(tool, "idname", "")).lower() if tool else ""
            if text:
                return text
    except Exception:
        pass
    return ""


def _native_tool_should_pass(context: Any) -> bool:
    tid = _active_tool_id(context)
    if tid in {"", "builtin.select", "builtin.tweak"}:
        return False
    return any(t in tid for t in _TRANSFORM_TOOL_TOKENS)


def _instant_enabled(context: Any) -> bool:
    try:
        fn = _NS.get("_sus_1635_immediate_enabled")
        if callable(fn):
            return bool(fn(context))
    except Exception:
        pass
    try:
        return bool(getattr(_workspace(context), "operation_instant_select_enabled", False))
    except Exception:
        return False


def _invoke_instant_18102(self: Any, context: Any, event: Any):
    try:
        if _s(getattr(event, "type", "")) != "LEFTMOUSE" or _s(getattr(event, "value", "")) != "PRESS":
            return {"PASS_THROUGH"}
        if not _instant_enabled(context):
            return {"PASS_THROUGH"}
        try:
            space = getattr(context, "space_data", None)
            if getattr(space, "type", "") != "IMAGE_EDITOR":
                return {"PASS_THROUGH"}
        except Exception:
            return {"PASS_THROUGH"}
        if _native_tool_should_pass(context):
            return {"PASS_THROUGH"}
        hit = _direct_find_uv_hit(self, context, event)
        if not hit:
            return {"PASS_THROUGH"}
        if _hit_is_selected(context, hit):
            return {"PASS_THROUGH"}
        if not _select_hit_immediate(context, hit, event):
            return {"PASS_THROUGH"}
        try:
            self._drag_start_x = int(getattr(event, "mouse_x", 0) or 0)
            self._drag_start_y = int(getattr(event, "mouse_y", 0) or 0)
        except Exception:
            pass
        try:
            context.window_manager.modal_handler_add(self)
            return {"RUNNING_MODAL"}
        except Exception:
            return {"FINISHED"}
    except Exception:
        return {"PASS_THROUGH"}


def _addon_keyconfig() -> Any:
    try:
        return bpy.context.window_manager.keyconfigs.addon
    except Exception:
        return None


def _iter_keyconfigs() -> Iterable[Any]:
    try:
        wm = getattr(bpy.context, "window_manager", None)
        kc = getattr(getattr(wm, "keyconfigs", None), "addon", None)
        return (kc,) if kc is not None else ()
    except Exception:
        return ()


def _remove_keymap_rows(idnames: Iterable[str], names: Optional[Iterable[str]] = None) -> int:
    removed = 0
    try:
        from . import ownership_runtime_18168 as _ownership
        for idname in tuple(idnames or ()):
            removed += _ownership.remove_owned_keymaps(str(idname))
    except Exception:
        pass
    return removed


def _ensure_keymap(kc: Any, name: str, space_type: str) -> Any:
    try:
        km = kc.keymaps.get(name)
        if km is None:
            km = kc.keymaps.new(name=name, space_type=space_type, region_type="WINDOW")
        return km
    except Exception:
        return None


def _ensure_instant_keymaps(context: Any = None) -> None:
    # Remove all broad/stale interceptors first, including ones from default/user maps.
    try:
        from . import ownership_runtime_18168 as _ownership
    except Exception:
        return
    _ownership.remove_owned_keymaps(_STICKY_PASS_ID)
    _ownership.remove_owned_keymaps(_GIZMO_GRIP_ID)
    kc = _addon_keyconfig()
    if kc is None:
        return
    active = _instant_enabled(context or bpy.context)
    for name, space in _ALLOWED_INSTANT_MAPS:
        km = _ensure_keymap(kc, name, space)
        if km is None:
            continue
        rows = [kmi for keymap, kmi in _ownership.owned_keymap_items(_INSTANT_ID) if keymap is km]
        if not rows:
            try:
                kmi = _ownership.new_keymap_item(km, _INSTANT_ID, type="LEFTMOUSE", value="PRESS", head=True)
            except TypeError:
                try:
                    kmi = _ownership.new_keymap_item(km, _INSTANT_ID, type="LEFTMOUSE", value="PRESS")
                except Exception:
                    kmi = None
            except Exception:
                kmi = None
            rows = [kmi] if kmi is not None else []
        for row in rows[1:]:
            _ownership.remove_keymap_item(km, row)
        if rows:
            kmi = rows[0]
            for prop, prop_value in (("type", "LEFTMOUSE"), ("value", "PRESS"), ("shift", False), ("ctrl", False), ("alt", False), ("oskey", False), ("hyper", False), ("any", False)):
                try:
                    _suv_resource.keymap_item_set(kmi, prop, prop_value)
                except Exception:
                    pass
            _ownership.set_keymap_item_active(kmi, bool(active))


def _patch_external_modules(ns: Dict[str, Any]) -> None:
    # Disable old sticky/gizmo preflight rows and execute wrappers so they cannot
    # return on workspace sync.  Smart UV alignment handles sticky followers in
    # this module; Blender standard gizmo/transform must remain native.
    try:
        from . import uv_sticky_unified_edit_1896 as sticky
        for fname in ("_restore_alignment_operators", "_remove_keymaps"):
            try:
                fn = getattr(sticky, fname, None)
                if callable(fn): fn()
            except Exception: pass
        try: sticky._KEYMAP_DEFS = tuple()
        except Exception: pass
        try: sticky._KEYMAP_ROWS.clear()
        except Exception: pass
        def _noop(*_a, **_k): return None
        for fname in ("_install_keymaps", "_wrap_alignment_operators", "_patch_instant_translate", "install", "apply_all"):
            try: setattr(sticky, fname, _noop)
            except Exception: pass
    except Exception:
        pass
    try:
        from . import uv_runtime_cleanup_1899 as cleanup
        fn = getattr(cleanup, "install", None)
        if callable(fn): fn(ns, bpy.context)
    except Exception:
        pass
    try:
        from . import uv_selection_state_guard_1898 as guard
        fn = getattr(guard, "install", None) or getattr(guard, "apply_all", None)
        if callable(fn): fn(ns, bpy.context)
    except Exception:
        pass
    try:
        from . import uv_stable_selection_18101 as stable
        def _neutral_hidden_attrs(obj: Any):
            mesh = getattr(obj, "data", None)
            try:
                loop_len = len(getattr(mesh, "loops", []) or [])
                face_len = len(getattr(mesh, "polygons", []) or [])
            except Exception:
                loop_len = face_len = 0
            return [False] * loop_len, [False] * loop_len, [False] * face_len
        stable._read_hidden_attrs = _neutral_hidden_attrs
    except Exception:
        pass
    # Keep old keymap helper names pointing to this final policy.
    for key in ("_sus_1652_ensure_instant_keymaps", "_sus_1652_promote_instant_keymaps_to_head"):
        try: ns[key] = lambda context=None: _ensure_instant_keymaps(context or bpy.context)
        except Exception: pass
    try: ns["_sus_1652_set_instant_keymaps_active"] = lambda active: _ensure_instant_keymaps(bpy.context)
    except Exception: pass
    try: ns["_sus_1652_delete_instant_keymaps"] = lambda: _remove_keymap_rows({_INSTANT_ID})
    except Exception: pass
    for key in ("_SUS_1830_INSTANT_KEYMAP_DEFS", "_SUS_1832_INSTANT_KEYMAP_DEFS", "_SUS_1834_INSTANT_KEYMAP_DEFS"):
        try: ns[key] = tuple(_ALLOWED_INSTANT_MAPS)
        except Exception: pass


def _patch_operator_classes(ns: Dict[str, Any]) -> None:
    global _PREV_SELECT_EXEC, _PREV_VERTEX_EXEC, _PREV_INSTANT_INVOKE
    # Force the final 1.8.103 module to be the last active implementation even
    # when an earlier 1.8.102 function set the same marker attribute.  The marker
    # name is kept only for compatibility with older audit helpers.
    cls = ns.get("SMARTUVSUITE_OT_uv_element_select_action")
    if isinstance(cls, type):
        cur = getattr(cls, "execute", None)
        if callable(cur) and cur is not _execute_select_18102 and _PREV_SELECT_EXEC is None:
            _PREV_SELECT_EXEC = cur
        try:
            _execute_select_18102._sus_18102_select = True  # type: ignore[attr-defined]
            _execute_select_18102._sus_18103_final = True  # type: ignore[attr-defined]
            cls.execute = _execute_select_18102
        except Exception:
            pass
    vcls = ns.get("SMARTUVSUITE_OT_vertex_align_action")
    if isinstance(vcls, type):
        cur = getattr(vcls, "execute", None)
        if callable(cur) and cur is not _execute_vertex_align_18102 and _PREV_VERTEX_EXEC is None:
            _PREV_VERTEX_EXEC = cur
        try:
            _execute_vertex_align_18102._sus_18102_vertex = True  # type: ignore[attr-defined]
            _execute_vertex_align_18102._sus_18103_final = True  # type: ignore[attr-defined]
            vcls.execute = _execute_vertex_align_18102
        except Exception:
            pass
    icls = ns.get("SMARTUVSUITE_OT_instant_select_drag_move")
    if isinstance(icls, type):
        cur = getattr(icls, "invoke", None)
        if callable(cur) and cur is not _invoke_instant_18102 and _PREV_INSTANT_INVOKE is None:
            _PREV_INSTANT_INVOKE = cur
        try:
            _invoke_instant_18102._sus_18102_instant = True  # type: ignore[attr-defined]
            _invoke_instant_18102._sus_18103_final = True  # type: ignore[attr-defined]
            icls.invoke = _invoke_instant_18102
            icls._find_uv_hit = _direct_find_uv_hit
        except Exception:
            pass


def _mark_version(ns: Dict[str, Any]) -> None:
    try:
        info = ns.get("bl_info")
        if not isinstance(info, dict):
            info = {}; ns["bl_info"] = info
        info.update({
            "name": "Smart UV Suite",
            "author": "JELararagi",
            "version": (1, 0, 0),
            "blender": (5, 1, 0),
            "location": "View3D / UV Editor > Sidebar > Smart UV",
            "description": "Smart UV Suite exposes UV editing tools in the Smart UV sidebar.",
            "category": "Smart UV",
        })
        ns["_SUS_BL_INFO_FALLBACK"] = dict(info)
        ns["__version__"] = '1.0.0'
    except Exception:
        pass


def _wrap_sync(ns: Dict[str, Any]) -> None:
    global _PREV_SYNC_KEYMAPS
    cur = ns.get("_sus_1652_sync_keymaps_from_workspace")
    if callable(cur) and not getattr(cur, "_sus_18102_sync", False):
        _PREV_SYNC_KEYMAPS = cur
    base = _PREV_SYNC_KEYMAPS
    def _sync_18102(context=None):
        ctx = context or getattr(bpy, "context", None)
        if callable(base) and base is not _sync_18102:
            try: base(ctx)
            except TypeError:
                try: base()
                except Exception: pass
            except RecursionError: pass
            except Exception: pass
        try: apply_all(ns, ctx)
        except RecursionError: pass
        except Exception: pass
    try: _sync_18102._sus_18102_sync = True  # type: ignore[attr-defined]
    except Exception: pass
    ns["_sus_1652_sync_keymaps_from_workspace"] = _sync_18102


def apply_all(ns: Optional[Dict[str, Any]] = None, context: Any = None) -> None:
    global _NS
    if isinstance(ns, dict):
        _NS = ns
    elif not _NS:
        import sys
        mod = sys.modules.get(__package__)
        if mod is not None:
            _NS = getattr(mod, "__dict__", {})
    target = _NS if isinstance(_NS, dict) else {}
    if not target:
        return
    _patch_external_modules(target)
    _patch_operator_classes(target)
    _ensure_instant_keymaps(context or getattr(bpy, "context", None))
    _wrap_sync(target)
    _mark_version(target)


def install(ns: Optional[Dict[str, Any]] = None, context: Any = None) -> None:
    global _INSTALLED
    apply_all(ns, context or getattr(bpy, "context", None))
    _INSTALLED = True


def unregister() -> None:
    # Add-on disable should remove only Smart UV Suite's own stale interceptors.
    try: _remove_keymap_rows({_STICKY_PASS_ID, _GIZMO_GRIP_ID})
    except Exception: pass


def audit(context: Any = None) -> Dict[str, Any]:
    del context
    rows = []
    forbidden = []
    allowed = {name for name, _space in _ALLOWED_INSTANT_MAPS}
    try:
        from . import ownership_runtime_18168 as _ownership
        for km, kmi in _ownership.owned_keymap_items():
            name = _s(getattr(km, 'name', ''))
            kid = _s(getattr(kmi, 'idname', ''))
            if kid not in {_INSTANT_ID, _STICKY_PASS_ID, _GIZMO_GRIP_ID}:
                continue
            row = (name, kid, bool(getattr(kmi, 'active', False)), _s(getattr(kmi, 'type', '')), _s(getattr(kmi, 'value', '')))
            rows.append(row)
            if kid in {_STICKY_PASS_ID, _GIZMO_GRIP_ID} or (kid == _INSTANT_ID and name not in allowed):
                forbidden.append(row)
    except Exception:
        pass
    panel_issues = []
    for name in ('SMARTUVSUITE_PT_1881_VIEW3D_BODY', 'SMARTUVSUITE_PT_1881_UV_EDITOR_BODY', 'SMARTUVSUITE_PT_1881_view3d_body', 'SMARTUVSUITE_PT_1881_uv_editor_body'):
        cls = _NS.get(name) if isinstance(_NS, dict) else None
        if isinstance(cls, type):
            try:
                if 'HIDE_HEADER' in set(getattr(cls, 'bl_options', set()) or set()):
                    panel_issues.append((name, 'HIDE_HEADER'))
            except Exception:
                pass
            if not callable(getattr(cls, 'draw_header', None)):
                panel_issues.append((name, 'draw_header'))
            if not callable(getattr(cls, 'draw_header_preset', None)):
                panel_issues.append((name, 'draw_header_preset'))
    instant_rows = [(r[0], r[2]) for r in rows if len(r) > 2 and r[1] == _INSTANT_ID]
    return {
        'version': _VERSION,
        'rows': rows,
        'keymap_rows': rows,
        'instant_rows': instant_rows,
        'forbidden_rows': forbidden,
        'forbidden_keymap_rows': forbidden,
        'panel_issues': panel_issues,
        'foreign_keymaps_scanned': False,
    }



# 1.8.103 marker: this module supersedes the 1.8.102 consolidation layer.
