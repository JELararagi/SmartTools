from . import dashboard_ext as _prev

_IGNORE_KEYS = {
    '__name__', '__package__', '__loader__', '__spec__', '__file__', '__cached__', '__builtins__'
}
globals().update({k: v for k, v in _prev.__dict__.items() if k not in _IGNORE_KEYS})

def _suv_current_build_version_tuple():
    version_text = str(globals().get('__version__') or '').strip()
    if version_text:
        try:
            parts = [int(v) for v in version_text.split('.')[:3]]
            if len(parts) == 3:
                return tuple(parts)
        except Exception:
            pass
    try:
        version = dict(globals().get('bl_info') or {}).get('version', (0, 0, 0))
        if isinstance(version, (list, tuple)) and len(version) >= 3:
            return tuple(int(v) for v in version[:3])
    except Exception:
        pass
    return (6, 481, 0)


try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
        bl_info['description'] = (
            'Integrated UV workflow suite with split dashboard hubs, layout deck, selection scope, batch pilot, library shelf, workflow pulse, finish rail, delivery gate, control center, role board, phase coach, '
            'state snapshot, guided actions, bilingual help, QA, packing, trim, atlas, and compatibility bridges.'
        )
except Exception:
    pass

_TEXT.update({
    "ui.section.uv_role_board": ("UV Role Board", "UV役割ボード"),
    "ui.uv_role_board.hint": (
        "Read working, Bake, Lightmap and Atlas role readiness from one compact board before switching maps or export helpers.",
        "マップ切替や書き出し補助へ進む前に、作業用、Bake、Lightmap、Atlas の役割準備を1つのコンパクトなボードで確認します。",
    ),
    "ui.uv_role_board.summary": ("Role Readiness", "役割準備状況"),
    "ui.uv_role_board.actions": ("Role Actions", "役割アクション"),
    "ui.uv_role_board.none": ("No active mesh object", "アクティブなメッシュオブジェクトなし"),
    "ui.uv_role_board.working.ok": ("Working UV ready", "作業用UV準備OK"),
    "ui.uv_role_board.working.todo": ("Working UV missing", "作業用UVが不足"),
    "ui.uv_role_board.bake.ok": ("Bake role looks prepared", "Bake役割は準備済み"),
    "ui.uv_role_board.bake.todo": ("Bake role not prepared yet", "Bake役割は未準備"),
    "ui.uv_role_board.light.ok": ("Lightmap role looks prepared", "Lightmap役割は準備済み"),
    "ui.uv_role_board.light.todo": ("Lightmap role not prepared yet", "Lightmap役割は未準備"),
    "ui.uv_role_board.atlas.ok": ("Atlas role looks prepared", "Atlas役割は準備済み"),
    "ui.uv_role_board.atlas.todo": ("Atlas role not prepared yet", "Atlas役割は未準備"),
    "ui.uv_role_board.active": ("Active UV: {name}", "アクティブUV: {name}"),
    "ui.uv_role_board.count": ("UV layers: {n}", "UV層数: {n}"),
    "ui.uv_role_board.names": ("Known roles: {names}", "検出役割: {names}"),
    "ui.uv_role_board.names.none": ("Known roles: none yet", "検出役割: まだなし"),
})

_TEXT.update({
    "ui.section.assisted_checklist": ("Assisted Checklist", "進行チェックリスト"),
    "ui.assisted_checklist.hint": (
        "Track the safest working order as a short visual checklist so missing setup is easier to catch before tools change the scene.",
        "ツールが状態を変える前に、不足準備を見つけやすいよう、安全寄りの作業順を短い視覚チェックリストで確認します。",
    ),
    "ui.assisted_checklist.title": ("Checklist Status", "チェック状態"),
    "ui.assisted_checklist.actions": ("Recommended Next Step", "推奨の次操作"),
    "ui.assisted_checklist.item.selection.ok": ("Selection ready", "選択準備OK"),
    "ui.assisted_checklist.item.selection.todo": ("Select a target mesh", "対象メッシュを選択"),
    "ui.assisted_checklist.item.uv.ok": ("Working UV layer available", "作業用UV層あり"),
    "ui.assisted_checklist.item.uv.todo": ("Create a working UV layer", "作業用UV層を作成"),
    "ui.assisted_checklist.item.active.ok": ("Active UV target aligned", "アクティブUVが整列"),
    "ui.assisted_checklist.item.active.todo": ("Sync the active UV target", "アクティブUVを同期"),
    "ui.assisted_checklist.item.scan.ok": ("Inspector scan completed", "検査実行済み"),
    "ui.assisted_checklist.item.scan.todo": ("Run an inspector scan", "検査を実行"),
    "ui.assisted_checklist.item.issues.ok": ("No cached issues remain", "キャッシュ済み問題なし"),
    "ui.assisted_checklist.item.issues.todo": ("Repair or review cached issues", "問題を修復または確認"),
    "ui.assisted_checklist.item.role.ok": ("Role UV stage looks ready", "役割UV段階へ進行可"),
    "ui.assisted_checklist.item.role.todo": ("Prepare Bake / Lightmap / Atlas UVs", "Bake / Lightmap / Atlas UV を準備"),
    "ui.assisted_checklist.item.finish.ok": ("Final review path is open", "最終確認へ進行可"),
    "ui.assisted_checklist.item.finish.todo": ("Open final layout review tools", "最終配置確認ツールを開く"),
})

_TEXT.update({
    "ui.section.delivery_gate": ("Delivery Gate", "最終確認ゲート"),
    "ui.delivery_gate.hint": (
        "Check whether the current UV state is safe to hand off, export or move into bake/lightmap helpers without skipping validation steps.",
        "検証手順を飛ばさずに、現在のUV状態が引き渡し、書き出し、Bake/Lightmap 補助へ安全に進めるかを確認します。",
    ),
    "ui.delivery_gate.summary": ("Handoff Readiness", "引き渡し準備"),
    "ui.delivery_gate.actions": ("Finish Actions", "仕上げアクション"),
    "ui.delivery_gate.item.selection.ok": ("Target mesh ready", "対象メッシュ準備OK"),
    "ui.delivery_gate.item.selection.todo": ("Choose a target mesh", "対象メッシュを選択"),
    "ui.delivery_gate.item.uv.ok": ("Active working UV present", "作業用UVあり"),
    "ui.delivery_gate.item.uv.todo": ("Prepare a working UV", "作業用UVを準備"),
    "ui.delivery_gate.item.scan.ok": ("Fresh scan available", "最新検査あり"),
    "ui.delivery_gate.item.scan.todo": ("Run a fresh inspector scan", "最新の検査を実行"),
    "ui.delivery_gate.item.issues.ok": ("No cached issues block finish", "仕上げを阻害する問題なし"),
    "ui.delivery_gate.item.issues.todo": ("Clear cached issues before finish", "仕上げ前に問題を解消"),
    "ui.delivery_gate.item.role.ok": ("Role UV stage available", "役割UV段階へ進行可"),
    "ui.delivery_gate.item.role.todo": ("Prepare Bake / Lightmap / Atlas roles", "Bake / Lightmap / Atlas 役割を準備"),
    "ui.delivery_gate.item.checker.ok": ("Checker review path ready", "チェッカー確認へ進行可"),
    "ui.delivery_gate.item.checker.todo": ("Run checker or final layout review", "チェッカーまたは最終配置確認を実行"),
})

_TEXT.update({
    "ui.section.polish_deck": ("Polish Deck", "仕上げ整形デッキ"),
    "ui.polish_deck.hint": (
        "Collect straighten, rectify, match-and-stitch and finish-pack routes in one compact stop before the final review phase.",
        "最終確認へ進む前に、直線化、矩形化、マッチ+ステッチ、仕上げパックの導線を1つのコンパクトな場所へまとめます。",
    ),
    "ui.polish_deck.summary": ("Cleanup Readiness", "整形準備状況"),
    "ui.polish_deck.route.straighten": ("Straighten Flow", "流れを直線化"),
    "ui.polish_deck.route.rectify": ("Rectify Panels", "パネルを矩形化"),
    "ui.polish_deck.route.match": ("Match + Stitch", "マッチ + ステッチ"),
    "ui.polish_deck.route.finish": ("Finish Pack", "仕上げパック"),
    "ui.polish_deck.action.straighten": ("Run Straighten", "直線化を実行"),
    "ui.polish_deck.action.rectify": ("Run Rectify", "矩形化を実行"),
    "ui.polish_deck.action.match": ("Match + Stitch", "マッチ + ステッチ"),
    "ui.polish_deck.action.finish": ("Pack Pro", "Pack Pro"),
    "ui.polish_deck.line.mesh.none": ("Choose a mesh before shell cleanup.", "シェル整形の前にメッシュを選択します。"),
    "ui.polish_deck.line.mesh.ready": ("Working mesh is ready for cleanup.", "整形に使える作業メッシュがあります。"),
    "ui.polish_deck.line.uv.none": ("Prepare or sync a working UV first.", "先に作業用UVを準備または同期します。"),
    "ui.polish_deck.line.uv.ready": ("Working UV is available for cleanup passes.", "整形処理に使える作業用UVがあります。"),
    "ui.polish_deck.line.issues.none": ("No cached issues are blocking finish polish.", "仕上げ整形を妨げるキャッシュ済み問題はありません。"),
    "ui.polish_deck.line.issues.some": ("Review cached issues before final polish.", "最終整形の前にキャッシュ済み問題を確認します。"),
    "ui.polish_deck.line.straighten": ("Use edge straightening for strips, trims and ribbon-like shells.", "帯状、トリム、リボン状シェルの流れを整えるときに使います。"),
    "ui.polish_deck.line.rectify": ("Rectify hard-surface shells into cleaner right-angle structure.", "ハードサーフェスのシェルをより直角寄りの構造へ整えます。"),
    "ui.polish_deck.line.match": ("Match similar islands to the active island before stitch or weld refinement.", "類似アイランドをアクティブ島へ合わせてから、ステッチやウェルドの仕上げへ進みます。"),
    "ui.polish_deck.line.finish": ("Pack after cleanup so straightened shells keep a cleaner final arrangement.", "整形後にパックすることで、直したシェルをより整った最終配置へ保ちます。"),
})

_TEXT.update({
    "ui.section.workflow_pulse": ("Workflow Pulse", "ワークフローパルス"),
    "ui.workflow_pulse.hint": (
        "Compact live summary of current tab, working phase and the most likely safe next direction.",
        "現在タブ、作業フェーズ、次に進みやすい安全寄りの方向をコンパクトに要約します。",
    ),
    "ui.workflow_pulse.state.inspect": ("Inspect First", "まず検査"),
    "ui.workflow_pulse.state.repair": ("Repair Before Finish", "仕上げ前に修復"),
    "ui.workflow_pulse.state.role": ("Role UV Ready", "役割UVへ進行可"),
    "ui.workflow_pulse.state.finish": ("Finish Layout", "配置仕上げへ"),
    "ui.workflow_pulse.state.prep": ("Prepare UV Roles", "UV役割を準備"),
    "ui.workflow_pulse.state.select": ("Select a Mesh", "メッシュを選択"),
    "ui.workflow_pulse.summary": ("Suggested Direction", "推奨方向"),
    "ui.workflow_pulse.tab_focus": ("Tab Focus", "現在タブの役割"),
    "ui.workflow_pulse.safe_path": ("Safe Path", "安全寄りの進め方"),
    "ui.workflow_pulse.line.select": (
        "Select the target mesh, validate the workspace, then create or sync the working UV slot.",
        "対象メッシュを選択し、ワークスペースを検証してから、作業用UVスロットを作成または同期します。",
    ),
    "ui.workflow_pulse.line.prep": (
        "Prepare UV layers and active targets before unwrap, layout or batch tools change the working state.",
        "展開、配置、一括処理で作業状態が変わる前に、UV層とアクティブ対象を準備します。",
    ),
    "ui.workflow_pulse.line.inspect": (
        "Run a fresh inspector pass so any repair, checker or export decision is based on visible issues.",
        "修復、チェッカー、書き出し判断を見える問題に基づいて行えるよう、新しい検査を実行します。",
    ),
    "ui.workflow_pulse.line.repair": (
        "Repair known issues first, then rescan so the finishing step starts from a cleaner state.",
        "既知の問題を先に修復し、その後に再検査して、よりクリーンな状態から仕上げへ進みます。",
    ),
    "ui.workflow_pulse.line.role": (
        "Switch to Maps or role helpers when Bake, Lightmap, Atlas or dedicated export UVs are needed.",
        "Bake、Lightmap、Atlas、専用書き出しUVが必要なときは、Maps や役割ヘルパーへ進みます。",
    ),
    "ui.workflow_pulse.line.finish": (
        "Pack, review checker coverage and verify the final working UV before handoff or export.",
        "引き渡しや書き出し前に、最終作業UVをパックし、チェッカー範囲を確認し、検証します。",
    ),
})


def _suv_workflow_pulse_payload(context):
    ws = _suv_ws(context)
    phase_payload = _suv_phase_coach_payload(context) if '_suv_phase_coach_payload' in globals() else {'phase': 'select'}
    phase = str((phase_payload or {}).get('phase', 'select') or 'select')
    current_tab = str(getattr(ws, 'main_tab', 'WORKFLOW') if ws else 'WORKFLOW').upper()
    issue_total = _suv_cached_issue_total(ws) if '_suv_cached_issue_total' in globals() else 0
    has_scan = bool(getattr(ws, 'scan_has_result', False)) if ws else False
    obj = _active_mesh_obj(context)
    uv_name = '-'
    try:
        if obj is not None and getattr(obj.data, 'uv_layers', None) is not None and obj.data.uv_layers.active:
            uv_name = obj.data.uv_layers.active.name
    except Exception:
        pass

    state_key = phase
    summary_key = f'ui.workflow_pulse.state.{state_key}'
    line_key = f'ui.workflow_pulse.line.{state_key}'
    chips = [
        ('suv_workspace', tr(context, 'ui.control.phase', name=tr(context, f'ui.phase.{phase}.short'))),
        ('suv_workflow', tr(context, 'ui.control.tab', name=_suv_tab_title(context, ws))),
        ('suv_ref_inspect', tr(context, 'ui.control.issues', n=issue_total)),
        ('suv_uvmap', tr(context, 'ui.guide.active_uv', name=uv_name)),
    ]

    tab_lines = [
        _suv_tab_desc(context, current_tab),
        tr(context, 'ui.control.scan', state=tr(context, 'ui.control.scan.ready' if has_scan else 'ui.control.scan.none')),
    ]
    safe_lines = [
        tr(context, line_key),
        tr(context, 'ui.control.actions.2'),
    ]

    if obj is None:
        actions = [
            (SUV_OT_workspace_validate.bl_idname, tr(context, 'op.workspace_validate'), 'CHECKMARK', 'suv_workspace', {}),
            ('wm.context_set_enum', tr(context, 'ui.tab.workflow'), 'UV', 'suv_workflow', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'WORKFLOW'}),
            ('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
        ]
    elif phase == 'prep':
        actions = [
            ('uv.suv_native_stage_compat_tools', tr(context, 'ui.menu.batch_ensure_active_uv'), 'ADD', 'suv_uvmap', {'mode': 'BATCH_ENSURE_ACTIVE_UV'}),
            ('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
            (SUV_OT_workspace_validate.bl_idname, tr(context, 'op.workspace_validate'), 'CHECKMARK', 'suv_workspace', {}),
        ]
    elif phase == 'inspect':
        actions = [
            (SUV_OT_inspector_scan.bl_idname, tr(context, 'ui.quick_scan'), 'VIEWZOOM', 'suv_ref_inspect', {}),
            ('object.suv_visualize_stretch_heatmap', tr(context, 'ui.menu.show_stretch_heatmap'), 'SHADING_RENDERED', 'suv_ref_inspect', {}),
            ('wm.context_set_enum', tr(context, 'ui.tab.analyze'), 'VIEWZOOM', 'suv_ref_inspect', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
        ]
    elif phase == 'repair':
        actions = [
            (SUV_OT_workspace_auto_repair.bl_idname, tr(context, 'op.workspace_repair'), 'TOOL_SETTINGS', 'suv_workspace', {}),
            (SUV_OT_inspector_fix_flipped.bl_idname, tr(context, 'ui.menu.fix_flipped'), 'MOD_MIRROR', 'suv_ref_inspect', {}),
            (SUV_OT_inspector_scan.bl_idname, tr(context, 'ui.quick_scan'), 'VIEWZOOM', 'suv_ref_inspect', {}),
        ]
    elif phase == 'role':
        actions = [
            ('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
            (SUV_OT_bake_uv_prep.bl_idname, tr(context, 'ui.menu.bake_uv_prep'), 'RENDER_STILL', 'suv_ref_bake', {'prep_mode': 'BAKE'}),
            ('mesh.suv_native_stage_uvmap', tr(context, 'ui.section.uv_maps'), 'GROUP_UVS', 'suv_uvmap', {'mode': 'SYNC_ACTIVE'}),
        ]
    else:
        actions = [
            ('wm.context_set_enum', tr(context, 'ui.tab.layout'), 'PACKAGE', 'suv_ref_pack', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'LAYOUT'}),
            (SUV_OT_pack_pro.bl_idname, tr(context, 'ui.quick_pack'), 'PACKAGE', 'suv_ref_pack', {'engine': 'DETERMINISTIC'}),
            ('object.suv_create_checker_material', tr(context, 'ui.quick_checker'), 'MATERIAL', 'suv_ref_checker', {}),
        ]

    return {
        'chips': chips,
        'summary_title': tr(context, 'ui.workflow_pulse.summary'),
        'summary_lines': [tr(context, summary_key), tr(context, line_key)],
        'tab_title': tr(context, 'ui.workflow_pulse.tab_focus'),
        'tab_lines': tab_lines,
        'safe_title': tr(context, 'ui.workflow_pulse.safe_path'),
        'safe_lines': safe_lines,
        'actions': actions,
    }


def _suv_assisted_checklist_payload(context):
    ws = _suv_ws(context)
    obj = _active_mesh_obj(context)
    current_tab = str(getattr(ws, 'main_tab', 'WORKFLOW') if ws else 'WORKFLOW').upper()
    issue_total = _suv_cached_issue_total(ws) if '_suv_cached_issue_total' in globals() else 0
    has_scan = bool(getattr(ws, 'scan_has_result', False)) if ws else False
    uv_layer_count = 0
    active_uv_name = '-'
    active_missing = 0
    try:
        if obj is not None and getattr(obj.data, 'uv_layers', None) is not None:
            uv_layer_count = len(obj.data.uv_layers)
            active = obj.data.uv_layers.active
            active_uv_name = active.name if active else '-'
    except Exception:
        pass
    try:
        active_missing = len(_suv_objects_missing_active_uv(context))
    except Exception:
        active_missing = 0

    role_ready = (
        current_tab in {'MAPS', 'ATLAS'}
        or uv_layer_count >= 2
        or any(k in str(active_uv_name).lower() for k in ('bake', 'light', 'atlas', 'lm'))
    )
    final_ready = bool(obj is not None and uv_layer_count > 0 and has_scan and issue_total <= 0)

    items = [
        (obj is not None, tr(context, 'ui.assisted_checklist.item.selection.ok'), tr(context, 'ui.assisted_checklist.item.selection.todo')),
        (uv_layer_count > 0, tr(context, 'ui.assisted_checklist.item.uv.ok'), tr(context, 'ui.assisted_checklist.item.uv.todo')),
        (active_missing <= 0 and uv_layer_count > 0, tr(context, 'ui.assisted_checklist.item.active.ok'), tr(context, 'ui.assisted_checklist.item.active.todo')),
        (has_scan, tr(context, 'ui.assisted_checklist.item.scan.ok'), tr(context, 'ui.assisted_checklist.item.scan.todo')),
        (issue_total <= 0 and has_scan, tr(context, 'ui.assisted_checklist.item.issues.ok'), tr(context, 'ui.assisted_checklist.item.issues.todo')),
        (role_ready, tr(context, 'ui.assisted_checklist.item.role.ok'), tr(context, 'ui.assisted_checklist.item.role.todo')),
        (final_ready, tr(context, 'ui.assisted_checklist.item.finish.ok'), tr(context, 'ui.assisted_checklist.item.finish.todo')),
    ]
    lines = [('✓ ' if ok else '• ') + (ok_text if ok else todo_text) for ok, ok_text, todo_text in items]

    if obj is None:
        actions = [
            (SUV_OT_workspace_validate.bl_idname, tr(context, 'op.workspace_validate'), 'CHECKMARK', 'suv_workspace', {}),
            ('wm.context_set_enum', tr(context, 'ui.tab.workflow'), 'UV', 'suv_workflow', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'WORKFLOW'}),
        ]
    elif uv_layer_count <= 0 or active_missing > 0:
        actions = [
            ('uv.suv_native_stage_compat_tools', tr(context, 'ui.menu.batch_ensure_active_uv'), 'ADD', 'suv_uvmap', {'mode': 'BATCH_ENSURE_ACTIVE_UV'}),
            ('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
        ]
    elif not has_scan:
        actions = [
            (SUV_OT_inspector_scan.bl_idname, tr(context, 'ui.quick_scan'), 'VIEWZOOM', 'suv_ref_inspect', {}),
            ('wm.context_set_enum', tr(context, 'ui.tab.analyze'), 'VIEWZOOM', 'suv_ref_inspect', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
        ]
    elif issue_total > 0:
        actions = [
            (SUV_OT_workspace_auto_repair.bl_idname, tr(context, 'op.workspace_repair'), 'TOOL_SETTINGS', 'suv_workspace', {}),
            (SUV_OT_inspector_fix_flipped.bl_idname, tr(context, 'ui.menu.fix_flipped'), 'MOD_MIRROR', 'suv_ref_inspect', {}),
        ]
    elif not role_ready:
        actions = [
            ('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
            (SUV_OT_bake_uv_prep.bl_idname, tr(context, 'ui.menu.bake_uv_prep'), 'RENDER_STILL', 'suv_ref_bake', {'prep_mode': 'BAKE'}),
        ]
    else:
        actions = [
            ('wm.context_set_enum', tr(context, 'ui.tab.layout'), 'PACKAGE', 'suv_ref_pack', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'LAYOUT'}),
            (SUV_OT_pack_pro.bl_idname, tr(context, 'ui.quick_pack'), 'PACKAGE', 'suv_ref_pack', {'engine': 'DETERMINISTIC'}),
        ]

    return {
        'title': tr(context, 'ui.assisted_checklist.title'),
        'lines': lines,
        'actions_title': tr(context, 'ui.assisted_checklist.actions'),
        'actions': actions,
    }


def _draw_assisted_checklist(layout, context):
    box, col = _create_box(layout, tr(context, 'ui.section.assisted_checklist'), 'CHECKBOX_HLT', 'suv_workspace')
    _draw_info_line(col, tr(context, 'ui.assisted_checklist.hint'), 'INFO', 'suv_workspace')
    payload = _suv_assisted_checklist_payload(context)
    _draw_dashboard_card(col, payload['title'], payload['lines'], 'suv_workspace', [])
    _draw_dashboard_card(col, payload['actions_title'], [tr(context, 'ui.control.actions.2')], 'suv_workflow', payload['actions'])
    return box



def _suv_role_board_payload(context):
    obj = _active_mesh_obj(context)
    if obj is None:
        return {
            'chips': [('suv_uvmap', tr(context, 'ui.uv_role_board.none'))],
            'summary_title': tr(context, 'ui.uv_role_board.summary'),
            'summary_lines': [tr(context, 'ui.uv_role_board.none')],
            'actions_title': tr(context, 'ui.uv_role_board.actions'),
            'actions_lines': [tr(context, 'ui.control.actions.2')],
            'actions': [
                (SUV_OT_workspace_validate.bl_idname, tr(context, 'op.workspace_validate'), 'CHECKMARK', 'suv_workspace', {}),
                ('wm.context_set_enum', tr(context, 'ui.tab.workflow'), 'UV', 'suv_workflow', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'WORKFLOW'}),
            ],
        }

    uv_names = []
    active_name = '-'
    try:
        if getattr(obj.data, 'uv_layers', None) is not None:
            uv_names = [uv.name for uv in obj.data.uv_layers]
            active = obj.data.uv_layers.active
            active_name = active.name if active else '-'
    except Exception:
        uv_names = []

    uv_count = len(uv_names)
    names_lower = [str(n).lower() for n in uv_names]
    bake_ready = any(any(k in n for k in ('bake', 'ao', 'normal')) for n in names_lower)
    light_ready = any(any(k in n for k in ('light', 'lm', 'lightmap')) for n in names_lower)
    atlas_ready = any(any(k in n for k in ('atlas', 'trim', 'tile', 'udim')) for n in names_lower)
    working_ready = uv_count > 0

    role_names = []
    if working_ready:
        role_names.append('Working')
    if bake_ready:
        role_names.append('Bake')
    if light_ready:
        role_names.append('Lightmap')
    if atlas_ready:
        role_names.append('Atlas')

    summary_lines = [
        ('✓ ' if working_ready else '• ') + tr(context, 'ui.uv_role_board.working.ok' if working_ready else 'ui.uv_role_board.working.todo'),
        ('✓ ' if bake_ready else '• ') + tr(context, 'ui.uv_role_board.bake.ok' if bake_ready else 'ui.uv_role_board.bake.todo'),
        ('✓ ' if light_ready else '• ') + tr(context, 'ui.uv_role_board.light.ok' if light_ready else 'ui.uv_role_board.light.todo'),
        ('✓ ' if atlas_ready else '• ') + tr(context, 'ui.uv_role_board.atlas.ok' if atlas_ready else 'ui.uv_role_board.atlas.todo'),
        tr(context, 'ui.uv_role_board.active', name=active_name),
        tr(context, 'ui.uv_role_board.count', n=uv_count),
        tr(context, 'ui.uv_role_board.names', names=', '.join(role_names)) if role_names else tr(context, 'ui.uv_role_board.names.none'),
    ]
    chips = [
        ('suv_uvmap', tr(context, 'ui.guide.active_uv', name=active_name)),
        ('suv_uvmap', tr(context, 'ui.control.uv_layers', n=uv_count)),
        ('suv_ref_bake', 'Bake' if bake_ready else 'Bake?'),
        ('suv_ref_pack', 'Atlas' if atlas_ready else 'Atlas?'),
    ]

    if not working_ready:
        actions = [
            ('uv.suv_native_stage_compat_tools', tr(context, 'ui.menu.batch_ensure_active_uv'), 'ADD', 'suv_uvmap', {'mode': 'BATCH_ENSURE_ACTIVE_UV'}),
            ('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
        ]
    elif not bake_ready or not light_ready:
        actions = [
            (SUV_OT_bake_uv_prep.bl_idname, tr(context, 'ui.menu.bake_uv_prep'), 'RENDER_STILL', 'suv_ref_bake', {'prep_mode': 'BAKE'}),
            ('mesh.suv_native_stage_uvmap', tr(context, 'ui.section.uv_maps'), 'GROUP_UVS', 'suv_uvmap', {'mode': 'SYNC_ACTIVE'}),
            ('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
        ]
    elif not atlas_ready:
        actions = [
            ('wm.context_set_enum', tr(context, 'ui.tab.atlas'), 'SEQ_STRIP_META', 'suv_ref_pack', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ATLAS'}),
            (SUV_OT_pack_pro.bl_idname, tr(context, 'ui.quick_pack'), 'PACKAGE', 'suv_ref_pack', {'engine': 'DETERMINISTIC', 'udim_mode': 'AUTO_TILES'}),
            (SUV_OT_batch_object_to_udim_tiles.bl_idname, tr(context, 'ui.menu.transfer_batch_objects_udim'), 'SEQ_STRIP_META', 'suv_ref_pack', {}),
        ]
    else:
        actions = [
            ('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
            (SUV_OT_workspace_validate.bl_idname, tr(context, 'op.workspace_validate'), 'CHECKMARK', 'suv_workspace', {}),
            (SUV_OT_bake_uv_prep.bl_idname, tr(context, 'ui.menu.bake_uv_prep'), 'RENDER_STILL', 'suv_ref_bake', {'prep_mode': 'LIGHTMAP'}),
        ]

    return {
        'chips': chips,
        'summary_title': tr(context, 'ui.uv_role_board.summary'),
        'summary_lines': summary_lines,
        'actions_title': tr(context, 'ui.uv_role_board.actions'),
        'actions_lines': [tr(context, 'ui.control.actions.2')],
        'actions': actions,
    }


def _draw_uv_role_board(layout, context):
    box, col = _create_box(layout, tr(context, 'ui.section.uv_role_board'), 'GROUP_UVS', 'suv_uvmap')
    _draw_info_line(col, tr(context, 'ui.uv_role_board.hint'), 'INFO', 'suv_uvmap')
    payload = _suv_role_board_payload(context)
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.12)
    _draw_dashboard_card(col, payload['summary_title'], payload['summary_lines'], 'suv_uvmap', [])
    _draw_dashboard_card(col, payload['actions_title'], payload['actions_lines'], 'suv_ref_bake', payload['actions'])
    return box


def _suv_delivery_gate_payload(context):
    ws = _suv_ws(context)
    obj = _active_mesh_obj(context)
    issue_total = _suv_cached_issue_total(ws) if '_suv_cached_issue_total' in globals() else 0
    has_scan = bool(getattr(ws, 'scan_has_result', False)) if ws else False
    uv_layer_count = 0
    active_uv_name = '-'
    try:
        if obj is not None and getattr(obj.data, 'uv_layers', None) is not None:
            uv_layer_count = len(obj.data.uv_layers)
            active = obj.data.uv_layers.active
            active_uv_name = active.name if active else '-'
    except Exception:
        pass

    role_ready = (
        uv_layer_count >= 2
        or any(k in str(active_uv_name).lower() for k in ('bake', 'light', 'atlas', 'lm', 'trim', 'tile'))
        or str(getattr(ws, 'main_tab', 'WORKFLOW')).upper() in {'MAPS', 'ATLAS'}
    )
    checker_ready = bool(obj is not None and uv_layer_count > 0 and has_scan and issue_total <= 0)

    items = [
        (obj is not None, tr(context, 'ui.delivery_gate.item.selection.ok'), tr(context, 'ui.delivery_gate.item.selection.todo')),
        (uv_layer_count > 0, tr(context, 'ui.delivery_gate.item.uv.ok'), tr(context, 'ui.delivery_gate.item.uv.todo')),
        (has_scan, tr(context, 'ui.delivery_gate.item.scan.ok'), tr(context, 'ui.delivery_gate.item.scan.todo')),
        (issue_total <= 0 and has_scan, tr(context, 'ui.delivery_gate.item.issues.ok'), tr(context, 'ui.delivery_gate.item.issues.todo')),
        (role_ready, tr(context, 'ui.delivery_gate.item.role.ok'), tr(context, 'ui.delivery_gate.item.role.todo')),
        (checker_ready, tr(context, 'ui.delivery_gate.item.checker.ok'), tr(context, 'ui.delivery_gate.item.checker.todo')),
    ]
    lines = [('✓ ' if ok else '• ') + (ok_text if ok else todo_text) for ok, ok_text, todo_text in items]
    chips = [
        ('suv_workspace', tr(context, 'ui.control.issues', n=issue_total)),
        ('suv_uvmap', tr(context, 'ui.control.uv_layers', n=uv_layer_count)),
        ('suv_ref_inspect', tr(context, 'ui.control.scan', state=tr(context, 'ui.control.scan.ready' if has_scan else 'ui.control.scan.none'))),
        ('suv_ref_checker', tr(context, 'ui.guide.active_uv', name=active_uv_name)),
    ]

    if obj is None:
        actions = [
            (SUV_OT_workspace_validate.bl_idname, tr(context, 'op.workspace_validate'), 'CHECKMARK', 'suv_workspace', {}),
            ('wm.context_set_enum', tr(context, 'ui.tab.workflow'), 'UV', 'suv_workflow', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'WORKFLOW'}),
        ]
    elif uv_layer_count <= 0:
        actions = [
            ('uv.suv_native_stage_compat_tools', tr(context, 'ui.menu.batch_ensure_active_uv'), 'ADD', 'suv_uvmap', {'mode': 'BATCH_ENSURE_ACTIVE_UV'}),
            ('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
        ]
    elif not has_scan:
        actions = [
            (SUV_OT_inspector_scan.bl_idname, tr(context, 'ui.quick_scan'), 'VIEWZOOM', 'suv_ref_inspect', {}),
            ('wm.context_set_enum', tr(context, 'ui.tab.analyze'), 'VIEWZOOM', 'suv_ref_inspect', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
        ]
    elif issue_total > 0:
        actions = [
            (SUV_OT_workspace_auto_repair.bl_idname, tr(context, 'op.workspace_repair'), 'TOOL_SETTINGS', 'suv_workspace', {}),
            (SUV_OT_inspector_fix_flipped.bl_idname, tr(context, 'ui.menu.fix_flipped'), 'MOD_MIRROR', 'suv_ref_inspect', {}),
            (SUV_OT_inspector_scan.bl_idname, tr(context, 'ui.quick_scan'), 'VIEWZOOM', 'suv_ref_inspect', {}),
        ]
    elif not role_ready:
        actions = [
            ('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
            (SUV_OT_bake_uv_prep.bl_idname, tr(context, 'ui.menu.bake_uv_prep'), 'RENDER_STILL', 'suv_ref_bake', {'prep_mode': 'BAKE'}),
            ('mesh.suv_native_stage_uvmap', tr(context, 'ui.section.uv_maps'), 'GROUP_UVS', 'suv_uvmap', {'mode': 'SYNC_ACTIVE'}),
        ]
    else:
        actions = [
            ('wm.context_set_enum', tr(context, 'ui.tab.layout'), 'PACKAGE', 'suv_ref_pack', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'LAYOUT'}),
            (SUV_OT_pack_pro.bl_idname, tr(context, 'ui.quick_pack'), 'PACKAGE', 'suv_ref_pack', {'engine': 'DETERMINISTIC'}),
            ('object.suv_create_checker_material', tr(context, 'ui.quick_checker'), 'MATERIAL', 'suv_ref_checker', {}),
        ]

    return {
        'chips': chips,
        'summary_title': tr(context, 'ui.delivery_gate.summary'),
        'summary_lines': lines,
        'actions_title': tr(context, 'ui.delivery_gate.actions'),
        'actions_lines': [tr(context, 'ui.control.actions.2')],
        'actions': actions,
    }


def _draw_delivery_gate(layout, context):
    box, col = _create_box(layout, tr(context, 'ui.section.delivery_gate'), 'EXPORT', 'suv_ref_checker')
    _draw_info_line(col, tr(context, 'ui.delivery_gate.hint'), 'INFO', 'suv_ref_checker')
    payload = _suv_delivery_gate_payload(context)
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.12)
    _draw_dashboard_card(col, payload['summary_title'], payload['summary_lines'], 'suv_ref_checker', [])
    _draw_dashboard_card(col, payload['actions_title'], payload['actions_lines'], 'suv_ref_pack', payload['actions'])
    return box


def _draw_workflow_pulse(layout, context):
    box, col = _create_box(layout, tr(context, 'ui.section.workflow_pulse'), 'SEQ_SEQUENCER', 'suv_workflow')
    _draw_info_line(col, tr(context, 'ui.workflow_pulse.hint'), 'INFO', 'suv_workflow')
    payload = _suv_workflow_pulse_payload(context)
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.12)
    _draw_dashboard_card(col, payload['summary_title'], payload['summary_lines'], 'suv_workflow', [])
    _draw_dashboard_card(col, payload['tab_title'], payload['tab_lines'], 'suv_workspace', [])
    _draw_dashboard_card(col, payload['safe_title'], payload['safe_lines'], 'suv_ref_auto', payload['actions'])
    return box


def _draw_dashboard(layout, context):
    ws = _suv_ws(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    head = col.row(align=True)
    expanded = bool(getattr(ws, 'show_dashboard', False)) if ws else False
    from .foldout_header import draw_foldout_header
    draw_foldout_header(
        head, expanded, data=ws if ws else None, prop='show_dashboard' if ws else None,
        draw_title=lambda r: _label_with_icon(r, tr(context, 'ui.toggle.dashboard'), 'IMAGE_DATA', 'suv_workspace'))
    if not expanded:
        hint = col.row(align=True)
        hint.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        col.separator(factor=0.2)
        return

    draw_order = [
        _draw_visual_guide,
        _draw_control_center,
        _draw_workflow_pulse,
        _draw_assisted_checklist,
        _draw_uv_role_board,
        _draw_delivery_gate,
        _draw_state_snapshot,
        _draw_phase_coach,
        _draw_readiness_radar,
        _draw_next_step_advisor,
        _draw_tab_mission_brief,
        _draw_goal_paths,
        _draw_issue_solver,
        _draw_production_checkpoints,
        _draw_preset_cockpit,
        _draw_focus_lanes,
        _draw_outcome_compass,
        _draw_action_guide,
        _draw_recipe_cards,
        _draw_task_navigator,
        _draw_workspace_map,
        _draw_beginner_legend,
    ]
    for draw_fn in draw_order:
        box = draw_fn(col, context)
        if box is not None:
            col.separator(factor=0.15)

    recipes = [
        ("Auto UV Pro", 'suv_ref_auto', SUV_OT_auto_uv_profile.bl_idname, "Organic", 'MOD_SMOOTH', 'suv_ref_auto', {'profile': 'ORGANIC'}, ["有機形状向けの開始プリセット", "シーム→展開→調整の起点"]),
        ("Projection Lab", 'suv_ref_projection', SUV_OT_native_projection.bl_idname, "Smart Project", 'MOD_UVPROJECT', 'suv_ref_projection', {'mode': 'SMART_PROJECT', 'pack_after': True}, ["投影系ワークフローの入口", "ビュー・法線ベース系を整理"]),
        ("Pack + UDIM", 'suv_ref_pack', SUV_OT_pack_pro.bl_idname, "Pack Pro", 'PACKAGE', 'suv_ref_pack', {'engine': 'DETERMINISTIC', 'udim_mode': 'AUTO_TILES'}, ["密度とタイル整理の仕上げ", "必要時のみ詳細設定へ"]),
        ("Inspect + Density", 'suv_ref_inspect', SUV_OT_inspector_scan.bl_idname, 'Batch Inspect', 'VIEWZOOM', 'suv_ref_inspect', {}, ["チェッカーと検査の確認用", "トラブル時の確認に使用"]),
    ]
    use_gallery = bool(getattr(ws, 'show_reference_gallery', False)) if ws else False
    if use_gallery:
        grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_visual_recipe_card(grid, title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines)
    else:
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_dashboard_card(col, title, note_lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    col.separator(factor=0.2)




# --- compact workspace rail -------------------------------------
_TEXT.update({
    "ui.section.workspace_rail": ("Workspace Rail", "ワークスペースレール"),
    "ui.workspace_rail.hint": (
        "Compact quick-access strip for switching tabs and seeing the most relevant next action for the current workspace.",
        "現在の作業空間に合った次操作を見ながらタブを素早く切り替えるための、コンパクトなクイックアクセス帯です。",
    ),
    "ui.workspace_rail.tabs": ("Quick Tabs", "クイックタブ"),
    "ui.workspace_rail.focus": ("Current Focus", "現在の注目点"),
    "ui.workspace_rail.actions": ("Fast Actions", "クイック操作"),
    "ui.workspace_rail.tab.workflow": ("Workflow", "ワークフロー"),
    "ui.workspace_rail.tab.transform": ("Transform", "変形"),
    "ui.workspace_rail.tab.layout": ('Layout Panel', 'レイアウトパネル'),
    "ui.workspace_rail.tab.analyze": ("Analyze", "解析"),
    "ui.workspace_rail.tab.maps": ("Maps", "UVマップ"),
    "ui.workspace_rail.tab.symmetry": ("Symmetry", "対称"),
    "ui.workspace_rail.tab.atlas": ("Atlas", "アトラス"),
    "ui.workspace_rail.current": ("Current: {name}", "現在: {name}"),
    "ui.workspace_rail.phase": ("Phase: {name}", "工程: {name}"),
    "ui.workspace_rail.line.workflow": (
        "Start or restart cut and unwrap decisions here before moving into repair or final packing.",
        "修復や最終パックへ進む前に、切り分けと展開の起点をここで整えます。",
    ),
    "ui.workspace_rail.line.transform": (
        "Use this area when shells already exist and the next step is straightening, fitting or relaxing them.",
        "シェルが既にあり、直線化、フィット、リラックスが次工程のときに使う領域です。",
    ),
    "ui.workspace_rail.line.layout": (
        "Use layout tools when the unwrap is usable and the next goal is packing, stacking or final checker review.",
        "展開結果が使える状態で、次の目標がパック、スタック、最終チェッカー確認のときに使います。",
    ),
    "ui.workspace_rail.line.analyze": (
        "Use Analyze when you need visible proof before changing the scene, especially for overlap, flipped areas or density drift.",
        "シーンを変更する前に可視的な根拠が必要なとき、特に重なり、反転、密度ずれの確認で使います。",
    ),
    "ui.workspace_rail.line.maps": (
        "Use Maps when the next task depends on the correct working role such as Bake, Lightmap or export-specific UV targets.",
        "Bake、Lightmap、書き出し用など、正しい作業役割が次工程に関わるときは Maps を使います。",
    ),
    "ui.workspace_rail.line.symmetry": (
        "Use Symmetry when repeated mirrored parts should be aligned, compared or reused before packing.",
        "反復・左右対称パーツをパック前に揃える、比較する、再利用するときは Symmetry を使います。",
    ),
    "ui.workspace_rail.line.atlas": (
        "Use Atlas when the goal is batched layout, tile assignment or multi-object consolidation.",
        "一括レイアウト、タイル割り当て、複数オブジェクト統合が目的のときは Atlas を使います。",
    ),
})


def _suv_workspace_rail_payload(context):
    ws = _suv_ws(context)
    current_tab = str(getattr(ws, 'main_tab', 'WORKFLOW') if ws else 'WORKFLOW').upper()
    phase_payload = _suv_phase_coach_payload(context) if '_suv_phase_coach_payload' in globals() else {'phase': 'select'}
    phase = str((phase_payload or {}).get('phase', 'select') or 'select')
    tab_actions = [
        ('wm.context_set_enum', tr(context, 'ui.workspace_rail.tab.workflow'), 'UV', 'suv_workflow', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'WORKFLOW'}),
        ('wm.context_set_enum', tr(context, 'ui.workspace_rail.tab.transform'), 'ORIENTATION_GIMBAL', 'suv_transform', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'TRANSFORM'}),
        ('wm.context_set_enum', tr(context, 'ui.workspace_rail.tab.layout'), 'PACKAGE', 'suv_ref_pack', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'LAYOUT'}),
        ('wm.context_set_enum', tr(context, 'ui.workspace_rail.tab.analyze'), 'VIEWZOOM', 'suv_ref_inspect', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
        ('wm.context_set_enum', tr(context, 'ui.workspace_rail.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
        ('wm.context_set_enum', tr(context, 'ui.workspace_rail.tab.symmetry'), 'MOD_MIRROR', 'suv_ref_symmetry', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ATLAS'}),
        ('wm.context_set_enum', tr(context, 'ui.workspace_rail.tab.atlas'), 'SEQ_STRIP_META', 'suv_ref_pack', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ATLAS'}),
    ]
    lines = [
        tr(context, 'ui.workspace_rail.current', name=_suv_tab_title(context, ws)),
        tr(context, 'ui.workspace_rail.phase', name=tr(context, f'ui.phase.{phase}.short')),
        tr(context, f'ui.workspace_rail.line.{current_tab.lower()}'),
    ]

    if current_tab == 'WORKFLOW':
        quick_actions = [
            (SUV_OT_auto_uv_profile.bl_idname, tr(context, 'ui.quick_auto'), 'MOD_SMOOTH', 'suv_ref_auto', {'profile': 'ORGANIC'}),
            (SUV_OT_smart_seams.bl_idname, tr(context, 'ui.quick_seams'), 'MOD_EDGESPLIT', 'suv_ref_auto', {}),
            (SUV_OT_auto_unwrap_pro.bl_idname, tr(context, 'ui.quick_unwrap'), 'UV_ISLANDSEL', 'suv_ref_auto', {}),
        ]
    elif current_tab == 'TRANSFORM':
        quick_actions = [
            (SUV_OT_align_islands.bl_idname, tr(context, 'ui.quick_align'), 'ANCHOR_CENTER', 'suv_ref_layout', {}),
            (SUV_OT_smart_relax.bl_idname, tr(context, 'ui.quick_relax'), 'MOD_SMOOTH', 'suv_ref_layout', {}),
            (SUV_OT_fit_to_bounds.bl_idname, tr(context, 'ui.quick_fit'), 'FULLSCREEN_ENTER', 'suv_ref_layout', {}),
        ]
    elif current_tab == 'LAYOUT':
        quick_actions = [
            (SUV_OT_pack_pro.bl_idname, tr(context, 'ui.quick_pack'), 'PACKAGE', 'suv_ref_pack', {'engine': 'DETERMINISTIC'}),
            (SUV_OT_stack_pro.bl_idname, tr(context, 'ui.quick_stack'), 'SELECT_INTERSECT', 'suv_ref_pack', {'mode': 'STACK'}),
            ('object.suv_create_checker_material', tr(context, 'ui.quick_checker'), 'MATERIAL', 'suv_ref_checker', {}),
        ]
    elif current_tab == 'ANALYZE':
        quick_actions = [
            (SUV_OT_inspector_scan.bl_idname, tr(context, 'ui.quick_scan'), 'VIEWZOOM', 'suv_ref_inspect', {}),
            (SUV_OT_workspace_auto_repair.bl_idname, tr(context, 'op.workspace_repair'), 'TOOL_SETTINGS', 'suv_workspace', {}),
            ('object.suv_visualize_stretch_heatmap', tr(context, 'ui.menu.show_stretch_heatmap'), 'SHADING_RENDERED', 'suv_ref_inspect', {}),
        ]
    elif current_tab == 'MAPS':
        quick_actions = [
            ('mesh.suv_native_stage_uvmap', tr(context, 'ui.menu.sync_active_uv'), 'GROUP_UVS', 'suv_uvmap', {'mode': 'SYNC_ACTIVE'}),
            (SUV_OT_bake_uv_prep.bl_idname, tr(context, 'ui.menu.bake_uv_prep'), 'RENDER_STILL', 'suv_ref_bake', {'prep_mode': 'BAKE'}),
            ('uv.suv_native_stage_compat_tools', tr(context, 'ui.menu.batch_ensure_active_uv'), 'ADD', 'suv_uvmap', {'mode': 'BATCH_ENSURE_ACTIVE_UV'}),
        ]
    elif current_tab == 'SYMMETRY':
        quick_actions = [
            (SUV_OT_stack_symmetry_topology.bl_idname, tr(context, 'ui.menu.stack_symmetry_topology'), 'MOD_MIRROR', 'suv_ref_symmetry', {}),
            (SUV_OT_hotspot_symmetry_refill.bl_idname, tr(context, 'ui.menu.hotspot_symmetry_refill'), 'MOD_MIRROR', 'suv_ref_symmetry', {}),
            ('wm.context_set_enum', tr(context, 'ui.tab.layout'), 'PACKAGE', 'suv_ref_pack', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'LAYOUT'}),
        ]
    else:
        quick_actions = [
            (SUV_OT_atlas_run_all_multi.bl_idname, tr(context, 'ui.menu.atlas_run_all_multi'), 'SEQ_STRIP_META', 'suv_ref_pack', {}),
            (SUV_OT_batch_object_to_udim_tiles.bl_idname, tr(context, 'ui.menu.batch_object_to_udim_tiles'), 'SEQ_SEQUENCER', 'suv_ref_pack', {}),
            (SUV_OT_pack_pro.bl_idname, tr(context, 'ui.quick_pack'), 'PACKAGE', 'suv_ref_pack', {'engine': 'DETERMINISTIC', 'udim_mode': 'AUTO_TILES'}),
        ]
    return {
        'tab_actions': tab_actions,
        'focus_lines': lines,
        'quick_actions': quick_actions,
    }


def _draw_workspace_rail(layout, context):
    box, col = _create_box(layout, tr(context, 'ui.section.workspace_rail'), 'STATUSBAR', 'suv_workspace')
    _draw_info_line(col, tr(context, 'ui.workspace_rail.hint'), 'INFO', 'suv_workspace')
    payload = _suv_workspace_rail_payload(context)
    _draw_dashboard_card(col, tr(context, 'ui.workspace_rail.tabs'), [], 'suv_workspace', payload['tab_actions'])
    _draw_dashboard_card(col, tr(context, 'ui.workspace_rail.focus'), payload['focus_lines'], 'suv_workflow', payload['quick_actions'])
    return box


_prev_draw_dashboard_v221154 = _draw_dashboard

def _draw_dashboard(layout, context):
    ws = _suv_ws(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    head = col.row(align=True)
    expanded = bool(getattr(ws, 'show_dashboard', False)) if ws else False
    from .foldout_header import draw_foldout_header
    draw_foldout_header(
        head, expanded, data=ws if ws else None, prop='show_dashboard' if ws else None,
        draw_title=lambda r: _label_with_icon(r, tr(context, 'ui.toggle.dashboard'), 'IMAGE_DATA', 'suv_workspace'))
    if not expanded:
        hint = col.row(align=True)
        hint.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        col.separator(factor=0.2)
        return

    draw_order = [
        _draw_visual_guide,
        _draw_control_center,
        _draw_workspace_rail,
        _draw_workflow_pulse,
        _draw_assisted_checklist,
        _draw_uv_role_board,
        _draw_delivery_gate,
        _draw_state_snapshot,
        _draw_phase_coach,
        _draw_readiness_radar,
        _draw_next_step_advisor,
        _draw_tab_mission_brief,
        _draw_goal_paths,
        _draw_issue_solver,
        _draw_production_checkpoints,
        _draw_preset_cockpit,
        _draw_focus_lanes,
        _draw_outcome_compass,
        _draw_action_guide,
        _draw_recipe_cards,
        _draw_task_navigator,
        _draw_workspace_map,
        _draw_beginner_legend,
    ]
    for draw_fn in draw_order:
        box = draw_fn(col, context)
        if box is not None:
            col.separator(factor=0.15)

    recipes = [
        ("Auto UV Pro", 'suv_ref_auto', SUV_OT_auto_uv_profile.bl_idname, "Organic", 'MOD_SMOOTH', 'suv_ref_auto', {'profile': 'ORGANIC'}, ["有機形状向けの開始プリセット", "シーム→展開→調整の起点"]),
        ("Projection Lab", 'suv_ref_projection', SUV_OT_native_projection.bl_idname, "Smart Project", 'MOD_UVPROJECT', 'suv_ref_projection', {'mode': 'SMART_PROJECT', 'pack_after': True}, ["投影系ワークフローの入口", "ビュー・法線ベース系を整理"]),
        ("Pack + UDIM", 'suv_ref_pack', SUV_OT_pack_pro.bl_idname, "Pack Pro", 'PACKAGE', 'suv_ref_pack', {'engine': 'DETERMINISTIC', 'udim_mode': 'AUTO_TILES'}, ["密度とタイル整理の仕上げ", "必要時のみ詳細設定へ"]),
        ("Inspect + Density", 'suv_ref_inspect', SUV_OT_inspector_scan.bl_idname, 'Batch Inspect', 'VIEWZOOM', 'suv_ref_inspect', {}, ["チェッカーと検査の確認用", "トラブル時の確認に使用"]),
    ]
    use_gallery = bool(getattr(ws, 'show_reference_gallery', False)) if ws else False
    if use_gallery:
        grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_visual_recipe_card(grid, title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines)
    else:
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_dashboard_card(col, title, note_lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    col.separator(factor=0.2)




# --- compact finish rail ----------------------------------------
_TEXT.update({
    "ui.section.finish_rail": ("Finish Rail", "仕上げレール"),
    "ui.finish_rail.hint": (
        "Compact finish-focused strip that tells you whether the current UV state is ready for final packing, checker review or role-based handoff.",
        "現在のUV状態が最終パック、チェッカー確認、役割UV引き渡しへ進めるかを短く判断できる、仕上げ重視のコンパクト導線です。",
    ),
    "ui.finish_rail.summary": ("Finish Status", "仕上げ状態"),
    "ui.finish_rail.actions": ("Finish Actions", "仕上げアクション"),
    "ui.finish_rail.scan.ready": ("Fresh scan ready", "最新検査あり"),
    "ui.finish_rail.scan.todo": ("Run a fresh scan first", "先に最新検査を実行"),
    "ui.finish_rail.issues.clear": ("No cached issues block finish", "仕上げを妨げる問題なし"),
    "ui.finish_rail.issues.todo": ("Resolve cached issues before finish", "仕上げ前に問題を解消"),
    "ui.finish_rail.roles.ready": ("Bake and Lightmap roles look prepared", "Bake と Lightmap 役割は準備済み"),
    "ui.finish_rail.roles.todo": ("Prepare Bake or Lightmap roles", "Bake または Lightmap 役割を準備"),
    "ui.finish_rail.layout.ready": ("Layout stage can move to final review", "レイアウトは最終確認へ進行可"),
    "ui.finish_rail.layout.todo": ("Go to layout review and checker", "レイアウト確認とチェッカーへ進む"),
    "ui.finish_rail.path.inspect": (
        "Inspect before finishing so the last pack is based on visible problems rather than assumptions.",
        "推測ではなく見えている問題を基に最後のパックを行えるよう、仕上げ前に検査します。",
    ),
    "ui.finish_rail.path.repair": (
        "Repair known issues first, then rescan so the final layout starts from a cleaner state.",
        "既知の問題を先に修復し、その後に再検査して、よりクリーンな状態から最終配置へ進みます。",
    ),
    "ui.finish_rail.path.roles": (
        "Prepare Bake or Lightmap helper UVs before handoff when downstream work depends on dedicated roles.",
        "下流工程が専用役割に依存する場合は、引き渡し前に Bake や Lightmap 用の補助UVを準備します。",
    ),
    "ui.finish_rail.path.finish": (
        "Pack, review checker coverage and validate the working UV before export or handoff.",
        "書き出しや引き渡し前に、作業UVをパックし、チェッカー範囲を確認し、検証します。",
    ),
})


def _suv_finish_rail_payload(context):
    ws = _suv_ws(context)
    obj = _active_mesh_obj(context)
    issue_total = _suv_cached_issue_total(ws) if '_suv_cached_issue_total' in globals() else 0
    has_scan = bool(getattr(ws, 'scan_has_result', False)) if ws else False

    uv_names = []
    active_name = '-'
    if obj is not None:
        try:
            if getattr(obj.data, 'uv_layers', None) is not None:
                uv_names = [uv.name for uv in obj.data.uv_layers]
                active = obj.data.uv_layers.active
                active_name = active.name if active else '-'
        except Exception:
            uv_names = []
    names_lower = [str(n).lower() for n in uv_names]
    bake_ready = any(any(k in n for k in ('bake', 'ao', 'normal')) for n in names_lower)
    light_ready = any(any(k in n for k in ('light', 'lm', 'lightmap')) for n in names_lower)
    working_ready = len(uv_names) > 0

    chips = [
        ('suv_workflow', tr(context, 'ui.control.scan', state=tr(context, 'ui.control.scan.ready' if has_scan else 'ui.control.scan.none'))),
        ('suv_ref_inspect', tr(context, 'ui.control.issues', n=issue_total)),
        ('suv_uvmap', tr(context, 'ui.guide.active_uv', name=active_name)),
    ]
    summary_lines = []
    if obj is None:
        summary_lines = [tr(context, 'ui.control.meshes', n=0), tr(context, 'ui.finish_rail.scan.todo')]
        actions = [
            (SUV_OT_workspace_validate.bl_idname, tr(context, 'op.workspace_validate'), 'CHECKMARK', 'suv_workspace', {}),
            ('wm.context_set_enum', tr(context, 'ui.tab.workflow'), 'UV', 'suv_workflow', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'WORKFLOW'}),
            ('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
        ]
        path_line = tr(context, 'ui.finish_rail.path.inspect')
    elif not has_scan:
        summary_lines = [
            tr(context, 'ui.finish_rail.scan.todo'),
            ('✓ ' if working_ready else '• ') + tr(context, 'ui.uv_role_board.working.ok' if working_ready else 'ui.uv_role_board.working.todo'),
            tr(context, 'ui.finish_rail.layout.todo'),
        ]
        actions = [
            (SUV_OT_inspector_scan.bl_idname, tr(context, 'ui.quick_scan'), 'VIEWZOOM', 'suv_ref_inspect', {}),
            ('wm.context_set_enum', tr(context, 'ui.tab.analyze'), 'VIEWZOOM', 'suv_ref_inspect', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
            ('object.suv_visualize_stretch_heatmap', tr(context, 'ui.menu.show_stretch_heatmap'), 'SHADING_RENDERED', 'suv_ref_inspect', {}),
        ]
        path_line = tr(context, 'ui.finish_rail.path.inspect')
    elif issue_total > 0:
        summary_lines = [
            tr(context, 'ui.finish_rail.scan.ready'),
            tr(context, 'ui.finish_rail.issues.todo'),
            tr(context, 'ui.finish_rail.layout.todo'),
        ]
        actions = [
            (SUV_OT_workspace_auto_repair.bl_idname, tr(context, 'op.workspace_repair'), 'TOOL_SETTINGS', 'suv_workspace', {}),
            ('uv.suv_inspector_fix_flipped', tr(context, 'ui.menu.inspector_fix_flipped'), 'LOOP_BACK', 'suv_ref_inspect', {}),
            (SUV_OT_inspector_scan.bl_idname, tr(context, 'ui.quick_scan'), 'VIEWZOOM', 'suv_ref_inspect', {}),
        ]
        path_line = tr(context, 'ui.finish_rail.path.repair')
    elif not (bake_ready and light_ready):
        summary_lines = [
            tr(context, 'ui.finish_rail.scan.ready'),
            tr(context, 'ui.finish_rail.issues.clear'),
            tr(context, 'ui.finish_rail.roles.todo'),
        ]
        actions = [
            ('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
            (SUV_OT_bake_uv_prep.bl_idname, tr(context, 'ui.menu.bake_uv_prep'), 'RENDER_STILL', 'suv_ref_bake', {'prep_mode': 'BAKE'}),
            (SUV_OT_bake_uv_prep.bl_idname, tr(context, 'ui.menu.lightmap_uv_prep'), 'LIGHT', 'suv_ref_bake', {'prep_mode': 'LIGHTMAP'}),
        ]
        path_line = tr(context, 'ui.finish_rail.path.roles')
    else:
        summary_lines = [
            tr(context, 'ui.finish_rail.scan.ready'),
            tr(context, 'ui.finish_rail.issues.clear'),
            tr(context, 'ui.finish_rail.roles.ready'),
            tr(context, 'ui.finish_rail.layout.ready'),
        ]
        actions = [
            ('wm.context_set_enum', tr(context, 'ui.tab.layout'), 'PACKAGE', 'suv_ref_pack', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'LAYOUT'}),
            (SUV_OT_pack_pro.bl_idname, tr(context, 'ui.quick_pack'), 'PACKAGE', 'suv_ref_pack', {'engine': 'DETERMINISTIC'}),
            ('object.suv_create_checker_material', tr(context, 'ui.quick_checker'), 'MATERIAL', 'suv_ref_checker', {}),
        ]
        path_line = tr(context, 'ui.finish_rail.path.finish')

    return {
        'chips': chips,
        'summary_title': tr(context, 'ui.finish_rail.summary'),
        'summary_lines': summary_lines,
        'actions_title': tr(context, 'ui.finish_rail.actions'),
        'actions_lines': [path_line],
        'actions': actions,
    }


def _draw_finish_rail(layout, context):
    box, col = _create_box(layout, tr(context, 'ui.section.finish_rail'), 'TRACKING', 'suv_ref_checker')
    _draw_info_line(col, tr(context, 'ui.finish_rail.hint'), 'INFO', 'suv_ref_checker')
    payload = _suv_finish_rail_payload(context)
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.12)
    _draw_dashboard_card(col, payload['summary_title'], payload['summary_lines'], 'suv_ref_checker', [])
    _draw_dashboard_card(col, payload['actions_title'], payload['actions_lines'], 'suv_ref_pack', payload['actions'])
    return box


_prev_draw_dashboard_v221155 = _draw_dashboard

def _draw_dashboard(layout, context):
    ws = _suv_ws(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    head = col.row(align=True)
    expanded = bool(getattr(ws, 'show_dashboard', False)) if ws else False
    from .foldout_header import draw_foldout_header
    draw_foldout_header(
        head, expanded, data=ws if ws else None, prop='show_dashboard' if ws else None,
        draw_title=lambda r: _label_with_icon(r, tr(context, 'ui.toggle.dashboard'), 'IMAGE_DATA', 'suv_workspace'))
    if not expanded:
        hint = col.row(align=True)
        hint.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        col.separator(factor=0.2)
        return

    draw_order = [
        _draw_visual_guide,
        _draw_control_center,
        _draw_workspace_rail,
        _draw_workflow_pulse,
        _draw_assisted_checklist,
        _draw_uv_role_board,
        _draw_finish_rail,
        _draw_delivery_gate,
        _draw_state_snapshot,
        _draw_phase_coach,
        _draw_readiness_radar,
        _draw_next_step_advisor,
        _draw_tab_mission_brief,
        _draw_goal_paths,
        _draw_issue_solver,
        _draw_production_checkpoints,
        _draw_preset_cockpit,
        _draw_focus_lanes,
        _draw_outcome_compass,
        _draw_action_guide,
        _draw_recipe_cards,
        _draw_task_navigator,
        _draw_workspace_map,
        _draw_beginner_legend,
    ]
    for draw_fn in draw_order:
        box = draw_fn(col, context)
        if box is not None:
            col.separator(factor=0.15)

    recipes = [
        ("Auto UV Pro", 'suv_ref_auto', SUV_OT_auto_uv_profile.bl_idname, "Organic", 'MOD_SMOOTH', 'suv_ref_auto', {'profile': 'ORGANIC'}, ["有機形状向けの開始プリセット", "シーム→展開→調整の起点"]),
        ("Projection Lab", 'suv_ref_projection', SUV_OT_native_projection.bl_idname, "Smart Project", 'MOD_UVPROJECT', 'suv_ref_projection', {'mode': 'SMART_PROJECT', 'pack_after': True}, ["投影系ワークフローの入口", "ビュー・法線ベース系を整理"]),
        ("Pack + UDIM", 'suv_ref_pack', SUV_OT_pack_pro.bl_idname, "Pack Pro", 'PACKAGE', 'suv_ref_pack', {'engine': 'DETERMINISTIC', 'udim_mode': 'AUTO_TILES'}, ["密度とタイル整理の仕上げ", "必要時のみ詳細設定へ"]),
        ("Inspect + Density", 'suv_ref_inspect', SUV_OT_inspector_scan.bl_idname, 'Batch Inspect', 'VIEWZOOM', 'suv_ref_inspect', {}, ["チェッカーと検査の確認用", "トラブル時の確認に使用"]),
    ]
    use_gallery = bool(getattr(ws, 'show_reference_gallery', False)) if ws else False
    if use_gallery:
        grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_visual_recipe_card(grid, title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines)
    else:
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_dashboard_card(col, title, note_lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    col.separator(factor=0.2)


__all__ = [k for k in globals().keys() if not k.startswith('_')]


# --- review ladder ----------------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
        bl_info['description'] = (
            'Integrated UV workflow suite with split dashboard hubs, review ladder, recovery dock, finish rail, workflow pulse, delivery gate, control center, role board, phase coach, '
            'state snapshot, guided actions, bilingual help, QA, packing, trim, atlas, and compatibility bridges.'
        )
except Exception:
    pass

_TEXT.update({
    "ui.section.review_ladder": ("Review Ladder", "確認ラダー"),
    "ui.review_ladder.hint": (
        "A compact stage-by-stage ladder that shows what is already safe and what still needs attention before final handoff.",
        "最終引き渡し前に、どの段階が安全に済んでいて、どこにまだ確認が必要かを段階ごとに示すコンパクトなラダーです。",
    ),
    "ui.review_ladder.summary": ("Stage Progress", "段階進行"),
    "ui.review_ladder.actions": ("Stage Actions", "段階アクション"),
    "ui.review_ladder.stage.prep.ok": ("Prep ready", "準備OK"),
    "ui.review_ladder.stage.prep.todo": ("Prep missing", "準備不足"),
    "ui.review_ladder.stage.inspect.ok": ("Inspect ready", "検査OK"),
    "ui.review_ladder.stage.inspect.todo": ("Inspect missing", "検査不足"),
    "ui.review_ladder.stage.repair.ok": ("Repair clear", "修復クリア"),
    "ui.review_ladder.stage.repair.todo": ("Repair needed", "修復必要"),
    "ui.review_ladder.stage.roles.ok": ("Role UV ready", "役割UV準備OK"),
    "ui.review_ladder.stage.roles.todo": ("Role UV missing", "役割UV不足"),
    "ui.review_ladder.stage.deliver.ok": ("Delivery path open", "最終確認へ進行可"),
    "ui.review_ladder.stage.deliver.todo": ("Delivery review needed", "最終確認が必要"),
    "ui.review_ladder.path.prep": (
        "Create or sync the working UV first so later unwrap, repair and layout actions target the intended layer.",
        "後続の展開、修復、配置が意図したUV層へ作用するよう、まず作業用UVを作成または同期します。",
    ),
    "ui.review_ladder.path.inspect": (
        "Run a fresh inspection so repair and finishing decisions are based on the current mesh state.",
        "修復や仕上げ判断を現在のメッシュ状態に基づいて行えるよう、最新の検査を実行します。",
    ),
    "ui.review_ladder.path.repair": (
        "Resolve cached issues before the last pack so flipped or overlapping areas do not travel into export.",
        "反転や重なりをそのまま書き出しへ持ち込まないよう、最後のパック前にキャッシュ済み問題を解消します。",
    ),
    "ui.review_ladder.path.roles": (
        "Prepare Bake, Lightmap or Atlas helper UVs when downstream work depends on dedicated UV roles.",
        "下流工程が専用UV役割に依存する場合は、Bake、Lightmap、Atlas 用の補助UVを準備します。",
    ),
    "ui.review_ladder.path.deliver": (
        "Pack, review checker coverage and validate the current working UV before handoff or export.",
        "引き渡しや書き出し前に、現在の作業UVをパックし、チェッカー範囲を確認し、検証します。",
    ),
})


def _suv_review_ladder_payload(context):
    ws = _suv_ws(context)
    obj = _active_mesh_obj(context)
    issue_total = _suv_cached_issue_total(ws) if '_suv_cached_issue_total' in globals() else 0
    has_scan = bool(getattr(ws, 'scan_has_result', False)) if ws else False
    uv_names = []
    active_name = '-'
    if obj is not None:
        try:
            if getattr(obj.data, 'uv_layers', None) is not None:
                uv_names = [uv.name for uv in obj.data.uv_layers]
                active = obj.data.uv_layers.active
                active_name = active.name if active else '-'
        except Exception:
            uv_names = []
    names_lower = [str(n).lower() for n in uv_names]
    prep_ready = obj is not None and len(uv_names) > 0
    roles_ready = any(any(k in n for k in ('bake', 'ao', 'normal')) for n in names_lower) and any(any(k in n for k in ('light', 'lm', 'lightmap')) for n in names_lower)
    deliver_ready = prep_ready and has_scan and issue_total == 0

    chips = [
        ('suv_workspace', tr(context, 'ui.control.meshes', n=1 if obj is not None else 0)),
        ('suv_uvmap', tr(context, 'ui.guide.active_uv', name=active_name)),
        ('suv_ref_inspect', tr(context, 'ui.control.issues', n=issue_total)),
    ]
    summary_lines = [
        ('✓ ' if prep_ready else '• ') + tr(context, 'ui.review_ladder.stage.prep.ok' if prep_ready else 'ui.review_ladder.stage.prep.todo'),
        ('✓ ' if has_scan else '• ') + tr(context, 'ui.review_ladder.stage.inspect.ok' if has_scan else 'ui.review_ladder.stage.inspect.todo'),
        ('✓ ' if issue_total == 0 and has_scan else '• ') + tr(context, 'ui.review_ladder.stage.repair.ok' if issue_total == 0 and has_scan else 'ui.review_ladder.stage.repair.todo'),
        ('✓ ' if roles_ready else '• ') + tr(context, 'ui.review_ladder.stage.roles.ok' if roles_ready else 'ui.review_ladder.stage.roles.todo'),
        ('✓ ' if deliver_ready else '• ') + tr(context, 'ui.review_ladder.stage.deliver.ok' if deliver_ready else 'ui.review_ladder.stage.deliver.todo'),
    ]

    if not prep_ready:
        actions = [
            ('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
            ('uv.suv_native_stage_compat_tools', tr(context, 'ui.menu.batch_ensure_active_uv'), 'ADD', 'suv_uvmap', {'mode': 'BATCH_ENSURE_ACTIVE_UV'}),
            (SUV_OT_workspace_validate.bl_idname, tr(context, 'op.workspace_validate'), 'CHECKMARK', 'suv_workspace', {}),
        ]
        action_lines = [tr(context, 'ui.review_ladder.path.prep')]
    elif not has_scan:
        actions = [
            ('wm.context_set_enum', tr(context, 'ui.tab.analyze'), 'VIEWZOOM', 'suv_ref_inspect', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
            (SUV_OT_inspector_scan.bl_idname, tr(context, 'ui.quick_scan'), 'VIEWZOOM', 'suv_ref_inspect', {}),
            ('object.suv_visualize_stretch_heatmap', tr(context, 'ui.menu.show_stretch_heatmap'), 'SHADING_RENDERED', 'suv_ref_inspect', {}),
        ]
        action_lines = [tr(context, 'ui.review_ladder.path.inspect')]
    elif issue_total > 0:
        actions = [
            (SUV_OT_workspace_auto_repair.bl_idname, tr(context, 'op.workspace_repair'), 'TOOL_SETTINGS', 'suv_workspace', {}),
            ('uv.suv_inspector_fix_flipped', tr(context, 'ui.menu.inspector_fix_flipped'), 'LOOP_BACK', 'suv_ref_inspect', {}),
            (SUV_OT_inspector_scan.bl_idname, tr(context, 'ui.quick_scan'), 'VIEWZOOM', 'suv_ref_inspect', {}),
        ]
        action_lines = [tr(context, 'ui.review_ladder.path.repair')]
    elif not roles_ready:
        actions = [
            ('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
            (SUV_OT_bake_uv_prep.bl_idname, tr(context, 'ui.menu.bake_uv_prep'), 'RENDER_STILL', 'suv_ref_bake', {'prep_mode': 'BAKE'}),
            (SUV_OT_bake_uv_prep.bl_idname, tr(context, 'ui.menu.lightmap_uv_prep'), 'LIGHT', 'suv_ref_bake', {'prep_mode': 'LIGHTMAP'}),
        ]
        action_lines = [tr(context, 'ui.review_ladder.path.roles')]
    else:
        actions = [
            ('wm.context_set_enum', tr(context, 'ui.tab.layout'), 'PACKAGE', 'suv_ref_pack', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'LAYOUT'}),
            (SUV_OT_pack_pro.bl_idname, tr(context, 'ui.quick_pack'), 'PACKAGE', 'suv_ref_pack', {'engine': 'DETERMINISTIC'}),
            ('object.suv_create_checker_material', tr(context, 'ui.quick_checker'), 'MATERIAL', 'suv_ref_checker', {}),
        ]
        action_lines = [tr(context, 'ui.review_ladder.path.deliver')]

    return {
        'chips': chips,
        'summary_title': tr(context, 'ui.review_ladder.summary'),
        'summary_lines': summary_lines,
        'actions_title': tr(context, 'ui.review_ladder.actions'),
        'actions_lines': action_lines,
        'actions': actions,
    }


def _draw_review_ladder(layout, context):
    box, col = _create_box(layout, tr(context, 'ui.section.review_ladder'), 'CHECKLIST', 'suv_ref_checker')
    _draw_info_line(col, tr(context, 'ui.review_ladder.hint'), 'INFO', 'suv_ref_checker')
    payload = _suv_review_ladder_payload(context)
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.12)
    _draw_dashboard_card(col, payload['summary_title'], payload['summary_lines'], 'suv_ref_checker', [])
    _draw_dashboard_card(col, payload['actions_title'], payload['actions_lines'], 'suv_ref_pack', payload['actions'])
    return box


_prev_draw_dashboard_v221156 = _draw_dashboard

def _draw_dashboard(layout, context):
    ws = _suv_ws(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    head = col.row(align=True)
    expanded = bool(getattr(ws, 'show_dashboard', False)) if ws else False
    from .foldout_header import draw_foldout_header
    draw_foldout_header(
        head, expanded, data=ws if ws else None, prop='show_dashboard' if ws else None,
        draw_title=lambda r: _label_with_icon(r, tr(context, 'ui.toggle.dashboard'), 'IMAGE_DATA', 'suv_workspace'))
    if not expanded:
        hint = col.row(align=True)
        hint.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        col.separator(factor=0.2)
        return

    draw_order = [
        _draw_visual_guide,
        _draw_control_center,
        _draw_workspace_rail,
        _draw_workflow_pulse,
        _draw_assisted_checklist,
        _draw_uv_role_board,
        _draw_finish_rail,
        _draw_review_ladder,
        _draw_delivery_gate,
        _draw_state_snapshot,
        _draw_phase_coach,
        _draw_readiness_radar,
        _draw_next_step_advisor,
        _draw_tab_mission_brief,
        _draw_goal_paths,
        _draw_issue_solver,
        _draw_production_checkpoints,
        _draw_preset_cockpit,
        _draw_focus_lanes,
        _draw_outcome_compass,
        _draw_action_guide,
        _draw_recipe_cards,
        _draw_task_navigator,
        _draw_workspace_map,
        _draw_beginner_legend,
    ]
    for draw_fn in draw_order:
        box = draw_fn(col, context)
        if box is not None:
            col.separator(factor=0.15)

    recipes = [
        ("Auto UV Pro", 'suv_ref_auto', SUV_OT_auto_uv_profile.bl_idname, "Organic", 'MOD_SMOOTH', 'suv_ref_auto', {'profile': 'ORGANIC'}, ["有機形状向けの開始プリセット", "シーム→展開→調整の起点"]),
        ("Projection Lab", 'suv_ref_projection', SUV_OT_native_projection.bl_idname, "Smart Project", 'MOD_UVPROJECT', 'suv_ref_projection', {'mode': 'SMART_PROJECT', 'pack_after': True}, ["投影系ワークフローの入口", "ビュー・法線ベース系を整理"]),
        ("Pack + UDIM", 'suv_ref_pack', SUV_OT_pack_pro.bl_idname, "Pack Pro", 'PACKAGE', 'suv_ref_pack', {'engine': 'DETERMINISTIC', 'udim_mode': 'AUTO_TILES'}, ["密度とタイル整理の仕上げ", "必要時のみ詳細設定へ"]),
        ("Inspect + Density", 'suv_ref_inspect', SUV_OT_inspector_scan.bl_idname, 'Batch Inspect', 'VIEWZOOM', 'suv_ref_inspect', {}, ["チェッカーと検査の確認用", "トラブル時の確認に使用"]),
    ]
    use_gallery = bool(getattr(ws, 'show_reference_gallery', False)) if ws else False
    if use_gallery:
        grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_visual_recipe_card(grid, title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines)
    else:
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_dashboard_card(col, title, note_lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    col.separator(factor=0.2)


# --- recovery dock ----------------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
        bl_info['description'] = (
            'Integrated UV workflow suite with split dashboard hubs, review ladder, recovery dock, finish rail, workflow pulse, delivery gate, control center, role board, phase coach, '
            'state snapshot, guided actions, bilingual help, QA, packing, trim, atlas, and compatibility bridges.'
        )
except Exception:
    pass

_TEXT.update({
    "ui.section.recovery_dock": ("Recovery Dock", "復旧ドック"),
    "ui.recovery_dock.hint": (
        "A compact recovery hub for validation, repair, diagnostics and support actions when the current state feels unclear or unstable.",
        "現在の状態が分かりにくい、または不安定に感じるときに、検証、修復、診断、サポート操作をまとめて扱えるコンパクトな復旧ハブです。",
    ),
    "ui.recovery_dock.summary": ("Recovery Summary", "復旧サマリー"),
    "ui.recovery_dock.actions": ("Recovery Actions", "復旧アクション"),
    "ui.recovery_dock.scan.ready": ("Fresh scan available", "最新検査あり"),
    "ui.recovery_dock.scan.missing": ("Fresh scan needed", "最新検査が必要"),
    "ui.recovery_dock.issues.clear": ("No cached issues blocking recovery", "復旧を阻害する問題なし"),
    "ui.recovery_dock.issues.todo": ("Cached issues still need attention", "キャッシュ済み問題の確認が必要"),
    "ui.recovery_dock.mesh.ok": ("Target mesh context available", "対象メッシュ文脈あり"),
    "ui.recovery_dock.mesh.none": ("No active mesh context", "アクティブなメッシュ文脈なし"),
    "ui.recovery_dock.path.none": (
        "Start by validating the workspace, then open diagnostics if the panel state still looks unexpected.",
        "まずワークスペースを検証し、それでも表示状態が想定外なら診断テキストを開いて確認します。",
    ),
    "ui.recovery_dock.path.scan": (
        "Validate first, then run a fresh scan so later repair and export decisions are based on current data.",
        "まず検証し、その後に最新スキャンを実行して、後続の修復や書き出し判断を現在データに基づいて行います。",
    ),
    "ui.recovery_dock.path.repair": (
        "Repair visible issues first, then write a snapshot or support bundle only if the state still looks suspicious.",
        "まず見えている問題を修復し、その後も状態に不安が残る場合にのみスナップショットやサポートバンドルを書き出します。",
    ),
    "ui.recovery_dock.path.clean": (
        "The scene looks stable enough for finishing, but diagnostics and report cleanup remain available as a safety net.",
        "シーンは仕上げへ進める程度に安定していますが、念のため診断とレポート整理を安全網として使えます。",
    ),
    "ui.recovery_dock.action.validate": ("Validate Workspace", "ワークスペースを検証"),
    "ui.recovery_dock.action.diagnostics": ("Open Diagnostics", "診断を開く"),
    "ui.recovery_dock.action.reload_icons": ("Reload Icons", "アイコン再読込"),
    "ui.recovery_dock.action.snapshot": ("Write Snapshot", "スナップショット出力"),
    "ui.recovery_dock.action.support": ("Support Bundle", "サポートバンドル"),
    "ui.recovery_dock.action.clear_reports": ("Clear Reports", "レポート消去"),
})


def _suv_recovery_dock_payload(context):
    ws = _suv_ws(context)
    obj = _active_mesh_obj(context)
    issue_total = _suv_cached_issue_total(ws) if '_suv_cached_issue_total' in globals() else 0
    has_scan = bool(getattr(ws, 'scan_has_result', False)) if ws else False
    mesh_count = 0
    try:
        mesh_count = len(list(_selected_mesh_objects(context)))
    except Exception:
        mesh_count = 0
    if mesh_count == 0 and obj is not None:
        mesh_count = 1

    active_uv_name = '-'
    try:
        if obj is not None and getattr(obj.data, 'uv_layers', None) is not None and obj.data.uv_layers.active:
            active_uv_name = obj.data.uv_layers.active.name
    except Exception:
        pass

    chips = [
        ('suv_workspace', tr(context, 'ui.control.meshes', n=mesh_count)),
        ('suv_ref_inspect', tr(context, 'ui.control.issues', n=issue_total)),
        ('suv_uvmap', tr(context, 'ui.guide.active_uv', name=active_uv_name)),
    ]

    summary_lines = [
        ('✓ ' if obj is not None else '• ') + tr(context, 'ui.recovery_dock.mesh.ok' if obj is not None else 'ui.recovery_dock.mesh.none'),
        ('✓ ' if has_scan else '• ') + tr(context, 'ui.recovery_dock.scan.ready' if has_scan else 'ui.recovery_dock.scan.missing'),
        ('✓ ' if issue_total == 0 and has_scan else '• ') + tr(context, 'ui.recovery_dock.issues.clear' if issue_total == 0 and has_scan else 'ui.recovery_dock.issues.todo'),
    ]

    if obj is None:
        action_lines = [tr(context, 'ui.recovery_dock.path.none')]
        actions = [
            (SUV_OT_workspace_validate.bl_idname, tr(context, 'ui.recovery_dock.action.validate'), 'CHECKMARK', 'suv_workspace', {}),
            (SUV_OT_open_diagnostics_text.bl_idname, tr(context, 'ui.recovery_dock.action.diagnostics'), 'TEXT', 'suv_workspace', {}),
            (SUV_OT_reload_custom_icons.bl_idname, tr(context, 'ui.recovery_dock.action.reload_icons'), 'FILE_REFRESH', 'suv_workspace', {}),
        ]
    elif not has_scan:
        action_lines = [tr(context, 'ui.recovery_dock.path.scan')]
        actions = [
            (SUV_OT_workspace_validate.bl_idname, tr(context, 'ui.recovery_dock.action.validate'), 'CHECKMARK', 'suv_workspace', {}),
            (SUV_OT_inspector_scan.bl_idname, tr(context, 'ui.quick_scan'), 'VIEWZOOM', 'suv_ref_inspect', {}),
            (SUV_OT_write_tool_runtime_snapshot.bl_idname, tr(context, 'ui.recovery_dock.action.snapshot'), 'TEXT', 'suv_workspace', {}),
        ]
    elif issue_total > 0:
        action_lines = [tr(context, 'ui.recovery_dock.path.repair')]
        actions = [
            (SUV_OT_workspace_auto_repair.bl_idname, tr(context, 'op.workspace_repair'), 'TOOL_SETTINGS', 'suv_workspace', {}),
            (SUV_OT_inspector_fix_flipped.bl_idname, tr(context, 'ui.menu.fix_flipped'), 'MOD_MIRROR', 'suv_ref_inspect', {}),
            (SUV_OT_collect_support_bundle.bl_idname, tr(context, 'ui.recovery_dock.action.support'), 'PACKAGE', 'suv_workspace', {}),
        ]
    else:
        action_lines = [tr(context, 'ui.recovery_dock.path.clean')]
        actions = [
            (SUV_OT_open_diagnostics_text.bl_idname, tr(context, 'ui.recovery_dock.action.diagnostics'), 'TEXT', 'suv_workspace', {}),
            (SUV_OT_clear_all_reports.bl_idname, tr(context, 'ui.recovery_dock.action.clear_reports'), 'TRASH', 'suv_workspace', {}),
            (SUV_OT_reload_custom_icons.bl_idname, tr(context, 'ui.recovery_dock.action.reload_icons'), 'FILE_REFRESH', 'suv_workspace', {}),
        ]

    return {
        'chips': chips,
        'summary_title': tr(context, 'ui.recovery_dock.summary'),
        'summary_lines': summary_lines,
        'actions_title': tr(context, 'ui.recovery_dock.actions'),
        'actions_lines': action_lines,
        'actions': actions,
    }


def _draw_recovery_dock(layout, context):
    box, col = _create_box(layout, tr(context, 'ui.section.recovery_dock'), 'TOOL_SETTINGS', 'suv_workspace')
    _draw_info_line(col, tr(context, 'ui.recovery_dock.hint'), 'INFO', 'suv_workspace')
    payload = _suv_recovery_dock_payload(context)
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.12)
    _draw_dashboard_card(col, payload['summary_title'], payload['summary_lines'], 'suv_workspace', [])
    _draw_dashboard_card(col, payload['actions_title'], payload['actions_lines'], 'suv_ref_inspect', payload['actions'])
    return box


_prev_draw_dashboard_v221157 = _draw_dashboard

def _draw_dashboard(layout, context):
    ws = _suv_ws(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    head = col.row(align=True)
    expanded = bool(getattr(ws, 'show_dashboard', False)) if ws else False
    from .foldout_header import draw_foldout_header
    draw_foldout_header(
        head, expanded, data=ws if ws else None, prop='show_dashboard' if ws else None,
        draw_title=lambda r: _label_with_icon(r, tr(context, 'ui.toggle.dashboard'), 'IMAGE_DATA', 'suv_workspace'))
    if not expanded:
        hint = col.row(align=True)
        hint.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        col.separator(factor=0.2)
        return

    draw_order = [
        _draw_visual_guide,
        _draw_control_center,
        _draw_workspace_rail,
        _draw_workflow_pulse,
        _draw_assisted_checklist,
        _draw_uv_role_board,
        _draw_finish_rail,
        _draw_review_ladder,
        _draw_delivery_gate,
        _draw_recovery_dock,
        _draw_state_snapshot,
        _draw_phase_coach,
        _draw_readiness_radar,
        _draw_next_step_advisor,
        _draw_tab_mission_brief,
        _draw_goal_paths,
        _draw_issue_solver,
        _draw_production_checkpoints,
        _draw_preset_cockpit,
        _draw_focus_lanes,
        _draw_outcome_compass,
        _draw_action_guide,
        _draw_recipe_cards,
        _draw_task_navigator,
        _draw_workspace_map,
        _draw_beginner_legend,
    ]
    for draw_fn in draw_order:
        box = draw_fn(col, context)
        if box is not None:
            col.separator(factor=0.15)

    recipes = [
        ("Auto UV Pro", 'suv_ref_auto', SUV_OT_auto_uv_profile.bl_idname, "Organic", 'MOD_SMOOTH', 'suv_ref_auto', {'profile': 'ORGANIC'}, ["有機形状向けの開始プリセット", "シーム→展開→調整の起点"]),
        ("Projection Lab", 'suv_ref_projection', SUV_OT_native_projection.bl_idname, "Smart Project", 'MOD_UVPROJECT', 'suv_ref_projection', {'mode': 'SMART_PROJECT', 'pack_after': True}, ["投影系ワークフローの入口", "ビュー・法線ベース系を整理"]),
        ("Pack + UDIM", 'suv_ref_pack', SUV_OT_pack_pro.bl_idname, "Pack Pro", 'PACKAGE', 'suv_ref_pack', {'engine': 'DETERMINISTIC', 'udim_mode': 'AUTO_TILES'}, ["密度とタイル整理の仕上げ", "必要時のみ詳細設定へ"]),
        ("Inspect + Density", 'suv_ref_inspect', SUV_OT_inspector_scan.bl_idname, 'Batch Inspect', 'VIEWZOOM', 'suv_ref_inspect', {}, ["チェッカーと検査の確認用", "トラブル時の確認に使用"]),
    ]
    use_gallery = bool(getattr(ws, 'show_reference_gallery', False)) if ws else False
    if use_gallery:
        grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_visual_recipe_card(grid, title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines)
    else:
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_dashboard_card(col, title, note_lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    col.separator(factor=0.2)


# --- mode guard ----------------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
        bl_info['description'] = (
            'Integrated UV workflow suite with split dashboard hubs, mode guard, review ladder, recovery dock, finish rail, workflow pulse, delivery gate, control center, role board, phase coach, '
            'state snapshot, guided actions, bilingual help, QA, packing, trim, atlas, and compatibility bridges.'
        )
except Exception:
    pass

_TEXT.update({
    "ui.section.mode_guard": ("Mode Guard", "モードガード"),
    "ui.mode_guard.hint": (
        "A compact readiness guide for selection, object mode, UV sync and editor context before running tools that are sensitive to the current workspace state.",
        "現在のワークスペース状態に敏感なツールを実行する前に、選択、オブジェクトモード、UV同期、エディター文脈をまとめて確認するコンパクトな準備ガイドです。",
    ),
    "ui.mode_guard.summary": ("Context Safety", "文脈の安全性"),
    "ui.mode_guard.actions": ("Context Actions", "文脈アクション"),
    "ui.mode_guard.mesh.ok": ("Target mesh context available", "対象メッシュ文脈あり"),
    "ui.mode_guard.mesh.none": ("No active mesh context", "アクティブなメッシュ文脈なし"),
    "ui.mode_guard.mode.ok": ("Mesh edit mode ready", "メッシュ編集モード準備OK"),
    "ui.mode_guard.mode.todo": ("Switch to mesh edit mode", "メッシュ編集モードへ切替"),
    "ui.mode_guard.sync.ok": ("UV sync selection enabled", "UV同期選択は有効"),
    "ui.mode_guard.sync.todo": ("UV sync selection is off", "UV同期選択がOFF"),
    "ui.mode_guard.editor.ok": ("Image Editor context available", "Image Editor 文脈あり"),
    "ui.mode_guard.editor.todo": ("No Image Editor open", "Image Editor が未配置"),
    "ui.mode_guard.area": ("Area: {name}", "エリア: {name}"),
    "ui.mode_guard.path.select": (
        "Choose a mesh first, then validate the workspace before unwrap or map tools start changing the scene.",
        "まずメッシュを選択し、その後でワークスペースを検証してから、展開やマップ系ツールでシーンを変更します。",
    ),
    "ui.mode_guard.path.mode": (
        "Enter mesh edit mode before seam, unwrap and checker tools so edits apply to the intended geometry state.",
        "シーム、展開、チェッカー系の操作前にメッシュ編集モードへ入り、意図したジオメトリ状態へ処理がかかるようにします。",
    ),
    "ui.mode_guard.path.sync": (
        "Enable UV sync when you want mesh and UV selections to move together more predictably during cleanup and review.",
        "クリーンアップや確認中にメッシュ選択とUV選択をより予測しやすく連動させたい場合は、UV同期を有効にします。",
    ),
    "ui.mode_guard.path.editor": (
        "Open or restore UV-facing context so map, checker and bake-role helpers are easier to verify visually.",
        "マップ、チェッカー、Bake 役割補助を視覚的に確認しやすくするため、UV向け文脈を開くか復旧します。",
    ),
    "ui.mode_guard.path.ready": (
        "The working context looks stable enough for inspect, layout or role-UV helpers, so you can move into the next task with fewer hidden assumptions.",
        "現在の作業文脈は、検査、配置、役割UV補助へ進める程度に安定しており、隠れた前提を減らしながら次工程へ進めます。",
    ),
    "ui.mode_guard.action.edit": ("Enter Edit Mode", "編集モードへ"),
    "ui.mode_guard.action.sync": ("Enable UV Sync", "UV同期を有効化"),
    "ui.mode_guard.action.maps": ("Open Maps", "Maps を開く"),
    "ui.mode_guard.action.validate": ("Validate Workspace", "ワークスペースを検証"),
})


def _suv_mode_guard_payload(context):
    ws = _suv_ws(context)
    obj = _active_mesh_obj(context)
    snap = _suv_context_snapshot(context) if '_suv_context_snapshot' in globals() else {}
    tool_settings = getattr(getattr(context, 'scene', None), 'tool_settings', None)
    uv_sync = bool(getattr(tool_settings, 'use_uv_select_sync', False)) if tool_settings else False
    current_mode = str((snap or {}).get('mode', getattr(obj, 'mode', 'UNKNOWN')) or 'UNKNOWN').upper()
    current_area = str((snap or {}).get('current_area_type', getattr(getattr(context, 'area', None), 'type', 'UNKNOWN')) or 'UNKNOWN')
    image_editor_count = int((snap or {}).get('image_editor_count', 0) or 0)
    selected_meshes = int((snap or {}).get('selected_meshes', 0) or 0)
    active_uv_name = str((snap or {}).get('active_uv', '-') or '-')

    mesh_ok = obj is not None or selected_meshes > 0
    mode_ok = mesh_ok and 'EDIT' in current_mode
    editor_ok = image_editor_count > 0 or current_area == 'IMAGE_EDITOR'

    chips = [
        ('suv_workspace', tr(context, 'ui.control.meshes', n=max(selected_meshes, 1 if obj is not None else 0))),
        ('suv_uvmap', tr(context, 'ui.guide.active_uv', name=active_uv_name)),
        ('suv_workspace', tr(context, 'ui.mode_guard.area', name=current_area)),
        ('suv_ref_inspect', tr(context, 'ui.state.sync', value='ON' if uv_sync else 'OFF')),
    ]

    summary_lines = [
        ('✓ ' if mesh_ok else '• ') + tr(context, 'ui.mode_guard.mesh.ok' if mesh_ok else 'ui.mode_guard.mesh.none'),
        ('✓ ' if mode_ok else '• ') + tr(context, 'ui.mode_guard.mode.ok' if mode_ok else 'ui.mode_guard.mode.todo'),
        ('✓ ' if uv_sync else '• ') + tr(context, 'ui.mode_guard.sync.ok' if uv_sync else 'ui.mode_guard.sync.todo'),
        ('✓ ' if editor_ok else '• ') + tr(context, 'ui.mode_guard.editor.ok' if editor_ok else 'ui.mode_guard.editor.todo'),
    ]

    if not mesh_ok:
        action_lines = [tr(context, 'ui.mode_guard.path.select')]
        actions = [
            (SUV_OT_workspace_validate.bl_idname, tr(context, 'ui.mode_guard.action.validate'), 'CHECKMARK', 'suv_workspace', {}),
            ('wm.context_set_enum', tr(context, 'ui.mode_guard.action.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
            ('wm.context_set_enum', tr(context, 'ui.tab.workflow'), 'UV', 'suv_workflow', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'WORKFLOW'}),
        ]
    elif not mode_ok:
        action_lines = [tr(context, 'ui.mode_guard.path.mode')]
        actions = [
            ('object.mode_set', tr(context, 'ui.mode_guard.action.edit'), 'EDITMODE_HLT', 'suv_workspace', {'mode': 'EDIT'}),
            ('wm.context_set_enum', tr(context, 'ui.mode_guard.action.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
            (SUV_OT_workspace_validate.bl_idname, tr(context, 'ui.mode_guard.action.validate'), 'CHECKMARK', 'suv_workspace', {}),
        ]
    elif not uv_sync:
        action_lines = [tr(context, 'ui.mode_guard.path.sync')]
        actions = [
            (SUV_OT_uv_sync_mode_toggle.bl_idname, tr(context, 'ui.mode_guard.action.sync'), 'UV_SYNC_SELECT', 'suv_uvmap', {'mode': 'ON'}),
            ('wm.context_set_enum', tr(context, 'ui.tab.analyze'), 'VIEWZOOM', 'suv_ref_inspect', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
            ('wm.context_set_enum', tr(context, 'ui.mode_guard.action.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
        ]
    elif not editor_ok:
        action_lines = [tr(context, 'ui.mode_guard.path.editor')]
        actions = [
            ('wm.context_set_enum', tr(context, 'ui.mode_guard.action.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
            (SUV_OT_workspace_validate.bl_idname, tr(context, 'ui.mode_guard.action.validate'), 'CHECKMARK', 'suv_workspace', {}),
            (SUV_OT_open_diagnostics_text.bl_idname, tr(context, 'ui.recovery_dock.action.diagnostics'), 'TEXT', 'suv_workspace', {}),
        ]
    else:
        action_lines = [tr(context, 'ui.mode_guard.path.ready')]
        actions = [
            ('wm.context_set_enum', tr(context, 'ui.tab.analyze'), 'VIEWZOOM', 'suv_ref_inspect', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
            (SUV_OT_inspector_scan.bl_idname, tr(context, 'ui.quick_scan'), 'VIEWZOOM', 'suv_ref_inspect', {}),
            ('wm.context_set_enum', tr(context, 'ui.tab.layout'), 'PACKAGE', 'suv_ref_pack', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'LAYOUT'}),
        ]

    return {
        'chips': chips,
        'summary_title': tr(context, 'ui.mode_guard.summary'),
        'summary_lines': summary_lines,
        'actions_title': tr(context, 'ui.mode_guard.actions'),
        'actions_lines': action_lines,
        'actions': actions,
    }


def _draw_mode_guard(layout, context):
    box, col = _create_box(layout, tr(context, 'ui.section.mode_guard'), 'ORIENTATION_VIEW', 'suv_workspace')
    _draw_info_line(col, tr(context, 'ui.mode_guard.hint'), 'INFO', 'suv_workspace')
    payload = _suv_mode_guard_payload(context)
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.12)
    _draw_dashboard_card(col, payload['summary_title'], payload['summary_lines'], 'suv_workspace', [])
    _draw_dashboard_card(col, payload['actions_title'], payload['actions_lines'], 'suv_ref_inspect', payload['actions'])
    return box


_prev_draw_dashboard_v221158 = _draw_dashboard

def _draw_dashboard(layout, context):
    ws = _suv_ws(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    head = col.row(align=True)
    expanded = bool(getattr(ws, 'show_dashboard', False)) if ws else False
    from .foldout_header import draw_foldout_header
    draw_foldout_header(
        head, expanded, data=ws if ws else None, prop='show_dashboard' if ws else None,
        draw_title=lambda r: _label_with_icon(r, tr(context, 'ui.toggle.dashboard'), 'IMAGE_DATA', 'suv_workspace'))
    if not expanded:
        hint = col.row(align=True)
        hint.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        col.separator(factor=0.2)
        return

    draw_order = [
        _draw_visual_guide,
        _draw_control_center,
        _draw_mode_guard,
        _draw_workspace_rail,
        _draw_workflow_pulse,
        _draw_assisted_checklist,
        _draw_uv_role_board,
        _draw_finish_rail,
        _draw_review_ladder,
        _draw_delivery_gate,
        _draw_recovery_dock,
        _draw_state_snapshot,
        _draw_phase_coach,
        _draw_readiness_radar,
        _draw_next_step_advisor,
        _draw_tab_mission_brief,
        _draw_goal_paths,
        _draw_issue_solver,
        _draw_production_checkpoints,
        _draw_preset_cockpit,
        _draw_focus_lanes,
        _draw_outcome_compass,
        _draw_action_guide,
        _draw_recipe_cards,
        _draw_task_navigator,
        _draw_workspace_map,
        _draw_beginner_legend,
    ]
    for draw_fn in draw_order:
        box = draw_fn(col, context)
        if box is not None:
            col.separator(factor=0.15)

    recipes = [
        ("Auto UV Pro", 'suv_ref_auto', SUV_OT_auto_uv_profile.bl_idname, "Organic", 'MOD_SMOOTH', 'suv_ref_auto', {'profile': 'ORGANIC'}, ["有機形状向けの開始プリセット", "シーム→展開→調整の起点"]),
        ("Projection Lab", 'suv_ref_projection', SUV_OT_native_projection.bl_idname, "Smart Project", 'MOD_UVPROJECT', 'suv_ref_projection', {'mode': 'SMART_PROJECT', 'pack_after': True}, ["投影系ワークフローの入口", "ビュー・法線ベース系を整理"]),
        ("Pack + UDIM", 'suv_ref_pack', SUV_OT_pack_pro.bl_idname, "Pack Pro", 'PACKAGE', 'suv_ref_pack', {'engine': 'DETERMINISTIC', 'udim_mode': 'AUTO_TILES'}, ["密度とタイル整理の仕上げ", "必要時のみ詳細設定へ"]),
        ("Inspect + Density", 'suv_ref_inspect', SUV_OT_inspector_scan.bl_idname, 'Batch Inspect', 'VIEWZOOM', 'suv_ref_inspect', {}, ["チェッカーと検査の確認用", "トラブル時の確認に使用"]),
    ]
    use_gallery = bool(getattr(ws, 'show_reference_gallery', False)) if ws else False
    if use_gallery:
        grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_visual_recipe_card(grid, title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines)
    else:
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_dashboard_card(col, title, note_lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    col.separator(factor=0.2)


# Dashboard extension block ----------------------------------------------------
_TEXT.update({
    "ui.section.action_matrix": ("Action Matrix", "操作マトリクス"),
    "ui.action_matrix.hint": (
        "Open the most common safe routes from one compact matrix: prepare, inspect, layout and deliver.",
        "準備、検査、配置、仕上げのよく使う安全寄りルートを、1つのコンパクトなマトリクスから開きます。",
    ),
    "ui.action_matrix.summary": ("Current Route", "現在ルート"),
    "ui.action_matrix.routes": ("Fast Routes", "クイックルート"),
    "ui.action_matrix.route.prepare": ("Prepare", "準備"),
    "ui.action_matrix.route.inspect": ('Batch Inspect', "検査"),
    "ui.action_matrix.route.layout": ('Layout Panel', "配置"),
    "ui.action_matrix.route.deliver": ("Deliver", "仕上げ"),
    "ui.action_matrix.line.prepare.mesh": ("Choose a mesh and prepare the working UV target first.", "まず対象メッシュを選び、作業用UV対象を準備します。"),
    "ui.action_matrix.line.prepare.uv": ("Create or sync the active working UV before other tools change state.", "他のツールで状態が変わる前に、作業用UVを作成または同期します。"),
    "ui.action_matrix.line.prepare.ready": ("Preparation looks ready. You can move into inspect or layout safely.", "準備は良好です。検査または配置へ安全に進めます。"),
    "ui.action_matrix.line.inspect.todo": ("Run a fresh scan so visible issues guide the next decision.", "見える問題に基づいて次判断できるよう、新しい検査を実行します。"),
    "ui.action_matrix.line.inspect.fix": ("Known issues remain. Repair or rescan before finishing.", "既知の問題が残っています。仕上げ前に修復または再検査します。"),
    "ui.action_matrix.line.inspect.ready": ("Inspection is clean enough for layout or role preparation.", "検査結果は良好で、配置または役割準備へ進めます。"),
    "ui.action_matrix.line.layout.todo": ("Open layout tools for pack, stack, fit and checker review.", "パック、スタック、フィット、チェッカー確認のために配置ツールを開きます。"),
    "ui.action_matrix.line.layout.fix": ("Repair or inspect first so layout polish starts from a cleaner state.", "よりクリーンな状態から配置仕上げを始めるため、先に修復または検査します。"),
    "ui.action_matrix.line.layout.ready": ("Layout tools are a safe next step from the current state.", "現在状態からの次操作として、配置ツールが安全寄りです。"),
    "ui.action_matrix.line.deliver.todo": ("Prepare role UVs or final review helpers before handoff.", "引き渡し前に役割UVまたは最終確認ヘルパーを準備します。"),
    "ui.action_matrix.line.deliver.ready": ("Delivery checks look open. Use role helpers, pack and checker for the last pass.", "最終確認へ進める状態です。最後の確認に役割ヘルパー、パック、チェッカーを使います。"),
})


def _suv_action_matrix_payload(context):
    ws = _suv_ws(context)
    obj = _active_mesh_obj(context)
    current_tab = str(getattr(ws, 'main_tab', 'WORKFLOW') if ws else 'WORKFLOW').upper()
    issue_total = _suv_cached_issue_total(ws) if '_suv_cached_issue_total' in globals() else 0
    has_scan = bool(getattr(ws, 'scan_has_result', False)) if ws else False
    uv_layers = 0
    active_uv = '-'
    active_missing = 0
    try:
        if obj is not None and getattr(obj.data, 'uv_layers', None) is not None:
            uv_layers = len(obj.data.uv_layers)
            if obj.data.uv_layers.active:
                active_uv = obj.data.uv_layers.active.name
    except Exception:
        pass
    try:
        active_missing = len(_suv_objects_missing_active_uv(context))
    except Exception:
        active_missing = 0

    prep_ready = bool(obj is not None and uv_layers > 0 and active_missing == 0)
    inspect_ready = bool(has_scan and issue_total <= 0)
    role_ready = bool(uv_layers >= 2 or any(k in str(active_uv).lower() for k in ('bake', 'light', 'atlas', 'lm')))
    deliver_ready = bool(prep_ready and has_scan and issue_total <= 0)

    chips = [
        ('suv_workflow', tr(context, 'ui.control.tab', name=_suv_tab_title(context, ws))),
        ('suv_uvmap', tr(context, 'ui.guide.active_uv', name=active_uv)),
        ('suv_ref_inspect', tr(context, 'ui.control.issues', n=issue_total)),
        ('suv_workspace', tr(context, 'ui.control.scan', state=tr(context, 'ui.control.scan.ready' if has_scan else 'ui.control.scan.none'))),
    ]

    if obj is None:
        prep_line = tr(context, 'ui.action_matrix.line.prepare.mesh')
        prep_action = ('wm.context_set_enum', tr(context, 'ui.tab.workflow'), 'UV', 'suv_workflow', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'WORKFLOW'})
    elif not prep_ready:
        prep_line = tr(context, 'ui.action_matrix.line.prepare.uv')
        prep_action = ('uv.suv_native_stage_compat_tools', tr(context, 'ui.menu.batch_ensure_active_uv'), 'ADD', 'suv_uvmap', {'mode': 'BATCH_ENSURE_ACTIVE_UV'})
    else:
        prep_line = tr(context, 'ui.action_matrix.line.prepare.ready')
        prep_action = ('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'})

    if not has_scan:
        inspect_line = tr(context, 'ui.action_matrix.line.inspect.todo')
        inspect_action = (SUV_OT_inspector_scan.bl_idname, tr(context, 'ui.quick_scan'), 'VIEWZOOM', 'suv_ref_inspect', {})
    elif issue_total > 0:
        inspect_line = tr(context, 'ui.action_matrix.line.inspect.fix')
        inspect_action = (SUV_OT_workspace_auto_repair.bl_idname, tr(context, 'op.workspace_repair'), 'TOOL_SETTINGS', 'suv_workspace', {})
    else:
        inspect_line = tr(context, 'ui.action_matrix.line.inspect.ready')
        inspect_action = ('wm.context_set_enum', tr(context, 'ui.tab.analyze'), 'VIEWZOOM', 'suv_ref_inspect', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'})

    if issue_total > 0 and has_scan:
        layout_line = tr(context, 'ui.action_matrix.line.layout.fix')
        layout_action = (SUV_OT_workspace_auto_repair.bl_idname, tr(context, 'op.workspace_repair'), 'TOOL_SETTINGS', 'suv_workspace', {})
    elif prep_ready:
        layout_line = tr(context, 'ui.action_matrix.line.layout.ready')
        layout_action = (SUV_OT_pack_pro.bl_idname, tr(context, 'ui.quick_pack'), 'PACKAGE', 'suv_ref_pack', {'engine': 'DETERMINISTIC'})
    else:
        layout_line = tr(context, 'ui.action_matrix.line.layout.todo')
        layout_action = ('wm.context_set_enum', tr(context, 'ui.tab.layout'), 'PACKAGE', 'suv_ref_pack', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'LAYOUT'})

    if deliver_ready and role_ready:
        deliver_line = tr(context, 'ui.action_matrix.line.deliver.ready')
        deliver_action = ('object.suv_create_checker_material', tr(context, 'ui.quick_checker'), 'MATERIAL', 'suv_ref_checker', {})
    else:
        deliver_line = tr(context, 'ui.action_matrix.line.deliver.todo')
        deliver_action = (SUV_OT_bake_uv_prep.bl_idname, tr(context, 'ui.menu.bake_uv_prep'), 'RENDER_STILL', 'suv_ref_bake', {'prep_mode': 'BAKE'})

    return {
        'chips': chips,
        'summary_lines': [
            tr(context, 'ui.action_matrix.line.prepare.ready' if prep_ready else ('ui.action_matrix.line.prepare.mesh' if obj is None else 'ui.action_matrix.line.prepare.uv')),
            tr(context, 'ui.action_matrix.line.inspect.ready' if inspect_ready else ('ui.action_matrix.line.inspect.fix' if has_scan and issue_total > 0 else 'ui.action_matrix.line.inspect.todo')),
        ],
        'cards': [
            (tr(context, 'ui.action_matrix.route.prepare'), [prep_line], prep_action, 'suv_uvmap'),
            (tr(context, 'ui.action_matrix.route.inspect'), [inspect_line], inspect_action, 'suv_ref_inspect'),
            (tr(context, 'ui.action_matrix.route.layout'), [layout_line], layout_action, 'suv_ref_pack'),
            (tr(context, 'ui.action_matrix.route.deliver'), [deliver_line], deliver_action, 'suv_ref_checker'),
        ],
    }


def _draw_action_matrix(layout, context):
    payload = _suv_action_matrix_payload(context)
    box, col = _create_box(layout, tr(context, 'ui.section.action_matrix'), 'GRID', 'suv_workflow')
    _draw_hint(col, tr(context, 'ui.action_matrix.hint'))
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.2)
    _draw_dashboard_card(col, tr(context, 'ui.action_matrix.summary'), payload['summary_lines'], 'suv_workspace', [])
    grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
    for title, lines, action, preview_icon in payload['cards']:
        op_id, op_label, fallback_icon, custom_icon, props = action
        _draw_dashboard_card(grid, title, lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    return box


_prev_draw_dashboard_v221159 = _draw_dashboard

def _draw_dashboard(layout, context):
    ws = _suv_ws(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    head = col.row(align=True)
    expanded = bool(getattr(ws, 'show_dashboard', False)) if ws else False
    from .foldout_header import draw_foldout_header
    draw_foldout_header(
        head, expanded, data=ws if ws else None, prop='show_dashboard' if ws else None,
        draw_title=lambda r: _label_with_icon(r, tr(context, 'ui.toggle.dashboard'), 'IMAGE_DATA', 'suv_workspace'))
    if not expanded:
        hint = col.row(align=True)
        hint.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        col.separator(factor=0.2)
        return

    draw_order = [
        _draw_visual_guide,
        _draw_control_center,
        _draw_mode_guard,
        _draw_workspace_rail,
        _draw_action_matrix,
        _draw_workflow_pulse,
        _draw_assisted_checklist,
        _draw_uv_role_board,
        _draw_finish_rail,
        _draw_review_ladder,
        _draw_delivery_gate,
        _draw_recovery_dock,
        _draw_state_snapshot,
        _draw_phase_coach,
        _draw_readiness_radar,
        _draw_next_step_advisor,
        _draw_tab_mission_brief,
        _draw_goal_paths,
        _draw_issue_solver,
        _draw_production_checkpoints,
        _draw_preset_cockpit,
        _draw_focus_lanes,
        _draw_outcome_compass,
        _draw_action_guide,
        _draw_recipe_cards,
        _draw_task_navigator,
        _draw_workspace_map,
        _draw_beginner_legend,
    ]
    for draw_fn in draw_order:
        box = draw_fn(col, context)
        if box is not None:
            col.separator(factor=0.15)

    recipes = [
        ("Auto UV Pro", 'suv_ref_auto', SUV_OT_auto_uv_profile.bl_idname, "Organic", 'MOD_SMOOTH', 'suv_ref_auto', {'profile': 'ORGANIC'}, ["有機形状向けの開始プリセット", "シーム→展開→調整の起点"]),
        ("Projection Lab", 'suv_ref_projection', SUV_OT_native_projection.bl_idname, "Smart Project", 'MOD_UVPROJECT', 'suv_ref_projection', {'mode': 'SMART_PROJECT', 'pack_after': True}, ["投影系ワークフローの入口", "ビュー・法線ベース系を整理"]),
        ("Pack + UDIM", 'suv_ref_pack', SUV_OT_pack_pro.bl_idname, "Pack Pro", 'PACKAGE', 'suv_ref_pack', {'engine': 'DETERMINISTIC', 'udim_mode': 'AUTO_TILES'}, ["密度とタイル整理の仕上げ", "必要時のみ詳細設定へ"]),
        ("Inspect + Density", 'suv_ref_inspect', SUV_OT_inspector_scan.bl_idname, 'Batch Inspect', 'VIEWZOOM', 'suv_ref_inspect', {}, ["チェッカーと検査の確認用", "トラブル時の確認に使用"]),
    ]
    use_gallery = bool(getattr(ws, 'show_reference_gallery', False)) if ws else False
    if use_gallery:
        grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_visual_recipe_card(grid, title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines)
    else:
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_dashboard_card(col, title, note_lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    col.separator(factor=0.2)


_TEXT.update({
    "ui.section.batch_pilot": ("Batch Pilot", "一括パイロット"),
    "ui.batch_pilot.hint": (
        "Group the most common multi-object UV preparation, layout and tile-routing actions into one compact batch hub before you switch tabs manually.",
        "よく使う複数オブジェクト向けのUV準備、レイアウト、タイル振り分け操作を、手動でタブを探す前に1つのコンパクトな一括ハブへまとめます。",
    ),
    "ui.batch_pilot.summary": ("Batch Readiness", "一括処理準備"),
    "ui.batch_pilot.route.sync": ("Sync Targets", "対象同期"),
    "ui.batch_pilot.route.profile": ("Batch Profiles", "一括プロファイル"),
    "ui.batch_pilot.route.tiles": ("Tiles / Atlas", "タイル / アトラス"),
    "ui.batch_pilot.route.review": ("Batch Review", "一括確認"),
    "ui.batch_pilot.line.mesh": (
        "Select two or more mesh objects for meaningful batch actions.",
        "一括処理の効果を出すには、2つ以上のメッシュを選択します。",
    ),
    "ui.batch_pilot.line.sync.todo": (
        "Some selected meshes still need a shared active UV target.",
        "選択メッシュの一部で共通アクティブUV対象がまだ不足しています。",
    ),
    "ui.batch_pilot.line.sync.ready": (
        "Selected meshes already share an active UV target.",
        "選択メッシュはすでに共通アクティブUV対象を共有しています。",
    ),
    "ui.batch_pilot.line.profile.todo": (
        "Run a batch seam or layout profile when repeated assets should follow the same rule set.",
        "反復アセット群を同じ規則で揃えたいときは、一括シームまたは一括レイアウトプロファイルを使います。",
    ),
    "ui.batch_pilot.line.tiles.todo": (
        "Route selected objects into UDIM or atlas tiles when each object needs a clearer tile destination.",
        "各オブジェクトに明確なタイル行き先が必要なときは、選択オブジェクトをUDIMまたはアトラスタイルへ振り分けます。",
    ),
    "ui.batch_pilot.line.review.todo": (
        "Validate and export a combined report before committing a large batch pass.",
        "大きな一括処理を確定する前に、検証して結合レポートを書き出します。",
    ),
    "ui.batch_pilot.count.meshes": ("Selected meshes: {n}", "選択メッシュ数: {n}"),
    "ui.batch_pilot.count.active_missing": ("Active UV missing: {n}", "アクティブUV不足: {n}"),
    "ui.batch_pilot.count.issues": ("Cached issues: {n}", "キャッシュ済み問題: {n}"),
})


def _suv_batch_pilot_payload(context):
    ws = _suv_ws(context)
    objs = _selected_mesh_objects(context) if '_selected_mesh_objects' in globals() else []
    mesh_count = len(objs)
    issue_total = _suv_cached_issue_total(ws) if '_suv_cached_issue_total' in globals() else 0
    active_missing = 0
    role_like = 0
    for obj in objs:
        try:
            uv_layers = getattr(getattr(obj, 'data', None), 'uv_layers', None)
            active = getattr(uv_layers, 'active', None) if uv_layers is not None else None
            if not active:
                active_missing += 1
            names = [str(uv.name).lower() for uv in (uv_layers or [])]
            if any(any(k in n for k in ('bake', 'light', 'atlas', 'udim', 'trim')) for n in names):
                role_like += 1
        except Exception:
            active_missing += 1

    prep_ready = mesh_count >= 2 and active_missing == 0
    chips = [
        ('suv_workspace', tr(context, 'ui.batch_pilot.count.meshes', n=mesh_count)),
        ('suv_uvmap', tr(context, 'ui.batch_pilot.count.active_missing', n=active_missing)),
        ('suv_ref_inspect', tr(context, 'ui.batch_pilot.count.issues', n=issue_total)),
        ('suv_ref_bake', f"Roles {role_like}/{mesh_count}" if mesh_count else "Roles 0/0"),
    ]

    sync_line = tr(context, 'ui.batch_pilot.line.sync.ready' if prep_ready else 'ui.batch_pilot.line.sync.todo')
    sync_action = (
        'uv.suv_native_stage_compat_tools',
        tr(context, 'ui.menu.batch_ensure_active_uv'),
        'ADD', 'suv_uvmap',
        {'mode': 'BATCH_ENSURE_ACTIVE_UV'}
    )

    profile_line = tr(context, 'ui.batch_pilot.line.profile.todo') if mesh_count >= 2 else tr(context, 'ui.batch_pilot.line.mesh')
    profile_action = (
        'uv.suv_batch_layout_profile',
        'Batch Layout Profile / 一括レイアウトプロファイル',
        'PACKAGE', 'suv_ref_pack',
        {}
    )

    tiles_line = tr(context, 'ui.batch_pilot.line.tiles.todo') if mesh_count >= 2 else tr(context, 'ui.batch_pilot.line.mesh')
    tiles_action = (
        'uv.suv_batch_object_to_udim_tiles',
        tr(context, 'ui.menu.transfer_batch_objects_udim'),
        'SEQ_STRIP_META', 'suv_ref_pack',
        {}
    )

    review_line = tr(context, 'ui.batch_pilot.line.review.todo') if mesh_count >= 2 else tr(context, 'ui.batch_pilot.line.mesh')
    review_action = (
        'uv.suv_native_stage_compat_tools',
        'Batch Texel Report / 一括テクセルレポート',
        'TEXT', 'suv_density',
        {'mode': 'BATCH_EXPORT_TEXEL_REPORT'}
    )

    return {
        'chips': chips,
        'summary_lines': [
            sync_line,
            tr(context, 'ui.batch_pilot.line.profile.todo') if mesh_count >= 2 else tr(context, 'ui.batch_pilot.line.mesh'),
        ],
        'cards': [
            (tr(context, 'ui.batch_pilot.route.sync'), [sync_line], sync_action, 'suv_uvmap'),
            (tr(context, 'ui.batch_pilot.route.profile'), [profile_line], profile_action, 'suv_ref_pack'),
            (tr(context, 'ui.batch_pilot.route.tiles'), [tiles_line], tiles_action, 'suv_ref_pack'),
            (tr(context, 'ui.batch_pilot.route.review'), [review_line], review_action, 'suv_ref_inspect'),
        ],
    }


def _draw_batch_pilot(layout, context):
    payload = _suv_batch_pilot_payload(context)
    box, col = _create_box(layout, tr(context, 'ui.section.batch_pilot'), 'MOD_ARRAY', 'suv_workspace')
    _draw_hint(col, tr(context, 'ui.batch_pilot.hint'))
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.2)
    _draw_dashboard_card(col, tr(context, 'ui.batch_pilot.summary'), payload['summary_lines'], 'suv_workspace', [])
    grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
    for title, lines, action, preview_icon in payload['cards']:
        op_id, op_label, fallback_icon, custom_icon, props = action
        _draw_dashboard_card(grid, title, lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    return box


_prev_draw_dashboard_v221160 = _draw_dashboard


def _draw_dashboard(layout, context):
    ws = _suv_ws(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    head = col.row(align=True)
    expanded = bool(getattr(ws, 'show_dashboard', False)) if ws else False
    from .foldout_header import draw_foldout_header
    draw_foldout_header(
        head, expanded, data=ws if ws else None, prop='show_dashboard' if ws else None,
        draw_title=lambda r: _label_with_icon(r, tr(context, 'ui.toggle.dashboard'), 'IMAGE_DATA', 'suv_workspace'))
    if not expanded:
        hint = col.row(align=True)
        hint.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        col.separator(factor=0.2)
        return

    draw_order = [
        _draw_visual_guide,
        _draw_control_center,
        _draw_mode_guard,
        _draw_workspace_rail,
        _draw_action_matrix,
        _draw_batch_pilot,
        _draw_workflow_pulse,
        _draw_assisted_checklist,
        _draw_uv_role_board,
        _draw_finish_rail,
        _draw_review_ladder,
        _draw_delivery_gate,
        _draw_recovery_dock,
        _draw_state_snapshot,
        _draw_phase_coach,
        _draw_readiness_radar,
        _draw_next_step_advisor,
        _draw_tab_mission_brief,
        _draw_goal_paths,
        _draw_issue_solver,
        _draw_production_checkpoints,
        _draw_preset_cockpit,
        _draw_focus_lanes,
        _draw_outcome_compass,
        _draw_action_guide,
        _draw_recipe_cards,
        _draw_task_navigator,
        _draw_workspace_map,
        _draw_beginner_legend,
    ]
    for draw_fn in draw_order:
        box = draw_fn(col, context)
        if box is not None:
            col.separator(factor=0.15)

    recipes = [
        ("Auto UV Pro", 'suv_ref_auto', SUV_OT_auto_uv_profile.bl_idname, "Organic", 'MOD_SMOOTH', 'suv_ref_auto', {'profile': 'ORGANIC'}, ["有機形状向けの開始プリセット", "シーム→展開→調整の起点"]),
        ("Projection Lab", 'suv_ref_projection', SUV_OT_native_projection.bl_idname, "Smart Project", 'MOD_UVPROJECT', 'suv_ref_projection', {'mode': 'SMART_PROJECT', 'pack_after': True}, ["投影系ワークフローの入口", "ビュー・法線ベース系を整理"]),
        ("Pack + UDIM", 'suv_ref_pack', SUV_OT_pack_pro.bl_idname, "Pack Pro", 'PACKAGE', 'suv_ref_pack', {'engine': 'DETERMINISTIC', 'udim_mode': 'AUTO_TILES'}, ["密度とタイル整理の仕上げ", "必要時のみ詳細設定へ"]),
        ("Inspect + Density", 'suv_ref_inspect', SUV_OT_inspector_scan.bl_idname, 'Batch Inspect', 'VIEWZOOM', 'suv_ref_inspect', {}, ["チェッカーと検査の確認用", "トラブル時の確認に使用"]),
    ]
    use_gallery = bool(getattr(ws, 'show_reference_gallery', False)) if ws else False
    if use_gallery:
        grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_visual_recipe_card(grid, title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines)
    else:
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_dashboard_card(col, title, note_lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    col.separator(factor=0.2)


# Dashboard extension block ----------------------------------------------------
_TEXT.update({
    "ui.section.library_shelf": ("Library Shelf", "ライブラリシェルフ"),
    "ui.library_shelf.hint": (
        "Read reusable selection, layout and seam library state from one compact shelf, then jump straight into save, recall or import/export helpers.",
        "再利用する選択、レイアウト、シームのライブラリ状態を1つのコンパクトな棚で確認し、そのまま保存、呼び出し、入出力ヘルパーへ進めます。",
    ),
    "ui.library_shelf.summary": ("Saved Reuse State", "保存済み再利用状態"),
    "ui.library_shelf.routes": ("Library Routes", "ライブラリルート"),
    "ui.library_shelf.route.selection": ('Selection Sets Menu', "選択セット"),
    "ui.library_shelf.route.layout": ('Layout Sets Menu', "レイアウトセット"),
    "ui.library_shelf.route.seam": ('Seam Sets Menu', "シームセット"),
    "ui.library_shelf.route.io": ("Library I/O", "ライブラリ入出力"),
    "ui.library_shelf.line.mesh": (
        "Choose an active mesh to read saved set counts and role-ready reuse data.",
        "保存セット数や役割向け再利用データを読むには、アクティブメッシュを選択します。",
    ),
    "ui.library_shelf.line.selection.none": (
        "No saved selection sets yet. Save a recurring working scope before batch edits.",
        "保存済み選択セットはまだありません。一括編集前に、反復する作業範囲を保存します。",
    ),
    "ui.library_shelf.line.selection.ready": (
        "Saved selection sets are ready for recurring object or island scope recall.",
        "保存済み選択セットがあり、反復するオブジェクトやアイランド範囲の呼び出しに使えます。",
    ),
    "ui.library_shelf.line.layout.none": (
        "No saved layout sets yet. Save a preferred shell arrangement before polishing similar assets.",
        "保存済みレイアウトセットはまだありません。類似アセットを仕上げる前に、好みの配置を保存します。",
    ),
    "ui.library_shelf.line.layout.ready": (
        "Saved layout sets are ready to restore a known shell arrangement quickly.",
        "保存済みレイアウトセットがあり、既知のシェル配置を素早く復元できます。",
    ),
    "ui.library_shelf.line.seam.none": (
        "No saved seam sets yet. Save a repeatable cut plan before copying it to similar meshes.",
        "保存済みシームセットはまだありません。類似メッシュへコピーする前に、再利用する切り分け計画を保存します。",
    ),
    "ui.library_shelf.line.seam.ready": (
        "Saved seam sets are ready to reapply a known cut plan on related meshes.",
        "保存済みシームセットがあり、関連メッシュへ既知の切り分け計画を再適用できます。",
    ),
    "ui.library_shelf.line.io.todo": (
        "Export or import reusable libraries when you want to back up, share or migrate working presets.",
        "作業プリセットをバックアップ、共有、移行したいときは、再利用ライブラリを入出力します。",
    ),
    "ui.library_shelf.count.selection": ("Selection sets: {n}", "選択セット数: {n}"),
    "ui.library_shelf.count.layout": ("Layout sets: {n}", "レイアウトセット数: {n}"),
    "ui.library_shelf.count.seam": ("Seam sets: {n}", "シームセット数: {n}"),
    "ui.library_shelf.count.layers": ("UV layers: {n}", "UV層数: {n}"),
})


def _suv_library_shelf_payload(context):
    obj = _active_mesh_obj(context)
    selection_count = layout_count = seam_count = uv_layers = 0
    active_uv_name = '-'
    if obj is not None:
        try:
            selection_count = len(_get_sets(obj) or {})
        except Exception:
            selection_count = 0
        try:
            layout_count = len(_get_layout_sets(obj) or {})
        except Exception:
            layout_count = 0
        try:
            seam_count = len(_get_seam_sets(obj) or {})
        except Exception:
            seam_count = 0
        try:
            uv_layers_ref = getattr(getattr(obj, 'data', None), 'uv_layers', None)
            uv_layers = len(uv_layers_ref or [])
            active = getattr(uv_layers_ref, 'active', None) if uv_layers_ref is not None else None
            if active:
                active_uv_name = active.name
        except Exception:
            uv_layers = 0

    chips = [
        ('suv_uvmap', tr(context, 'ui.library_shelf.count.selection', n=selection_count)),
        ('suv_ref_pack', tr(context, 'ui.library_shelf.count.layout', n=layout_count)),
        ('suv_ref_projection', tr(context, 'ui.library_shelf.count.seam', n=seam_count)),
        ('suv_ref_checker', tr(context, 'ui.library_shelf.count.layers', n=uv_layers)),
    ]
    summary_lines = [
        tr(context, 'ui.guide.active_uv', name=active_uv_name),
        tr(context, 'ui.library_shelf.line.mesh') if obj is None else tr(context, 'ui.control.obj_active', name=obj.name),
    ]

    if obj is None:
        selection_line = layout_line = seam_line = tr(context, 'ui.library_shelf.line.mesh')
        selection_action = ('wm.context_set_enum', tr(context, 'ui.tab.workflow'), 'UV', 'suv_workflow', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'WORKFLOW'})
        layout_action = ('wm.context_set_enum', tr(context, 'ui.tab.layout'), 'PACKAGE', 'suv_ref_pack', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'LAYOUT'})
        seam_action = ('wm.context_set_enum', tr(context, 'ui.tab.workflow'), 'UV', 'suv_workflow', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'WORKFLOW'})
    else:
        selection_line = tr(context, 'ui.library_shelf.line.selection.ready' if selection_count > 0 else 'ui.library_shelf.line.selection.none')
        layout_line = tr(context, 'ui.library_shelf.line.layout.ready' if layout_count > 0 else 'ui.library_shelf.line.layout.none')
        seam_line = tr(context, 'ui.library_shelf.line.seam.ready' if seam_count > 0 else 'ui.library_shelf.line.seam.none')
        selection_action = ('wm.call_menu', tr(context, 'ui.menu.selection_sets'), 'BOOKMARKS', 'suv_workspace', {'name': 'UVSUITE_MT_SELECTION_SETS'})
        layout_action = ('wm.call_menu', tr(context, 'ui.menu.layout_sets'), 'UV', 'suv_ref_pack', {'name': 'UVSUITE_MT_LAYOUT_SETS'})
        seam_action = ('wm.call_menu', tr(context, 'ui.menu.seam_sets'), 'MOD_EDGESPLIT', 'suv_ref_projection', {'name': 'UVSUITE_MT_SEAM_SETS'})

    io_action = ('uv.suv_workspace_settings_io', 'Workspace Settings I/O / ワークスペース設定入出力', 'FILEBROWSER', 'suv_workspace', {})

    return {
        'chips': chips,
        'summary_lines': summary_lines,
        'cards': [
            (tr(context, 'ui.library_shelf.route.selection'), [selection_line], selection_action, 'suv_uvmap'),
            (tr(context, 'ui.library_shelf.route.layout'), [layout_line], layout_action, 'suv_ref_pack'),
            (tr(context, 'ui.library_shelf.route.seam'), [seam_line], seam_action, 'suv_ref_projection'),
            (tr(context, 'ui.library_shelf.route.io'), [tr(context, 'ui.library_shelf.line.io.todo')], io_action, 'suv_workspace'),
        ],
    }


def _draw_library_shelf(layout, context):
    payload = _suv_library_shelf_payload(context)
    box, col = _create_box(layout, tr(context, 'ui.section.library_shelf'), 'BOOKMARKS', 'suv_workspace')
    _draw_hint(col, tr(context, 'ui.library_shelf.hint'))
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.2)
    _draw_dashboard_card(col, tr(context, 'ui.library_shelf.summary'), payload['summary_lines'], 'suv_workspace', [])
    grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
    for title, lines, action, preview_icon in payload['cards']:
        op_id, op_label, fallback_icon, custom_icon, props = action
        _draw_dashboard_card(grid, title, lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    return box


_prev_draw_dashboard_v221161 = _draw_dashboard


def _draw_dashboard(layout, context):
    ws = _suv_ws(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    head = col.row(align=True)
    expanded = bool(getattr(ws, 'show_dashboard', False)) if ws else False
    from .foldout_header import draw_foldout_header
    draw_foldout_header(
        head, expanded, data=ws if ws else None, prop='show_dashboard' if ws else None,
        draw_title=lambda r: _label_with_icon(r, tr(context, 'ui.toggle.dashboard'), 'IMAGE_DATA', 'suv_workspace'))
    if not expanded:
        hint = col.row(align=True)
        hint.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        col.separator(factor=0.2)
        return

    draw_order = [
        _draw_visual_guide,
        _draw_control_center,
        _draw_mode_guard,
        _draw_workspace_rail,
        _draw_action_matrix,
        _draw_batch_pilot,
        _draw_library_shelf,
        _draw_workflow_pulse,
        _draw_assisted_checklist,
        _draw_uv_role_board,
        _draw_finish_rail,
        _draw_review_ladder,
        _draw_delivery_gate,
        _draw_recovery_dock,
        _draw_state_snapshot,
        _draw_phase_coach,
        _draw_readiness_radar,
        _draw_next_step_advisor,
        _draw_tab_mission_brief,
        _draw_goal_paths,
        _draw_issue_solver,
        _draw_production_checkpoints,
        _draw_preset_cockpit,
        _draw_focus_lanes,
        _draw_outcome_compass,
        _draw_action_guide,
        _draw_recipe_cards,
        _draw_task_navigator,
        _draw_workspace_map,
        _draw_beginner_legend,
    ]
    for draw_fn in draw_order:
        box = draw_fn(col, context)
        if box is not None:
            col.separator(factor=0.15)

    recipes = [
        ("Auto UV Pro", 'suv_ref_auto', SUV_OT_auto_uv_profile.bl_idname, "Organic", 'MOD_SMOOTH', 'suv_ref_auto', {'profile': 'ORGANIC'}, ["有機形状向けの開始プリセット", "シーム→展開→調整の起点"]),
        ("Projection Lab", 'suv_ref_projection', SUV_OT_native_projection.bl_idname, "Smart Project", 'MOD_UVPROJECT', 'suv_ref_projection', {'mode': 'SMART_PROJECT', 'pack_after': True}, ["投影系ワークフローの入口", "ビュー・法線ベース系を整理"]),
        ("Pack + UDIM", 'suv_ref_pack', SUV_OT_pack_pro.bl_idname, "Pack Pro", 'PACKAGE', 'suv_ref_pack', {'engine': 'DETERMINISTIC', 'udim_mode': 'AUTO_TILES'}, ["密度とタイル整理の仕上げ", "必要時のみ詳細設定へ"]),
        ("Inspect + Density", 'suv_ref_inspect', SUV_OT_inspector_scan.bl_idname, 'Batch Inspect', 'VIEWZOOM', 'suv_ref_inspect', {}, ["チェッカーと検査の確認用", "トラブル時の確認に使用"]),
    ]
    use_gallery = bool(getattr(ws, 'show_reference_gallery', False)) if ws else False
    if use_gallery:
        grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_visual_recipe_card(grid, title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines)
    else:
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_dashboard_card(col, title, note_lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    col.separator(factor=0.2)


# Dashboard extension block ----------------------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
        bl_info['description'] = (
            'Integrated UV workflow suite with split dashboard hubs, role switchboard, library shelf, batch pilot, mode guard, workflow pulse, recovery dock, delivery gate, guided actions, bilingual help, QA, packing, trim, atlas, and compatibility bridges.'
        )
except Exception:
    pass

_TEXT.update({
    "ui.section.role_switchboard": ("Role Switchboard", "役割スイッチボード"),
    "ui.role_switchboard.hint": (
        "Jump into working, Bake, Lightmap and Atlas role routes from one compact switchboard so role changes stay easier to understand before delivery work.",
        "作業用、Bake、Lightmap、Atlas の役割ルートへ1つのコンパクトなスイッチボードから進み、納品前の役割切替を分かりやすくします。",
    ),
    "ui.role_switchboard.summary": ("Role Snapshot", "役割スナップショット"),
    "ui.role_switchboard.routes": ("Role Routes", "役割ルート"),
    "ui.role_switchboard.route.working": ("Working UV", "作業用UV"),
    "ui.role_switchboard.route.bake": ("Bake UV", "Bake UV"),
    "ui.role_switchboard.route.lightmap": ("Lightmap UV", "Lightmap UV"),
    "ui.role_switchboard.route.atlas": ("Atlas / UDIM", "Atlas / UDIM"),
    "ui.role_switchboard.line.none": (
        "Select an active mesh so working and role-specific UV routes can be read safely.",
        "作業用および役割別UVルートを安全に読むには、アクティブメッシュを選択します。",
    ),
    "ui.role_switchboard.line.working.ready": (
        "The working UV route looks usable. Keep the active target aligned before bigger layout changes.",
        "作業用UVルートは使える状態です。大きなレイアウト変更の前に、アクティブ対象を揃えます。",
    ),
    "ui.role_switchboard.line.working.todo": (
        "Create or sync the active working UV first so later role helpers have a stable source.",
        "後続の役割ヘルパーが安定した元UVを使えるよう、先に作業用UVを作成または同期します。",
    ),
    "ui.role_switchboard.line.bake.ready": (
        "A Bake-style role already looks present. Open Bake prep again only when you want to refresh or rename it.",
        "Bake系の役割はすでにありそうです。更新や名前整理が必要なときだけ再度 Bake 準備を開きます。",
    ),
    "ui.role_switchboard.line.bake.todo": (
        "Prepare a Bake UV role before export or shared bake work so the render target stays explicit.",
        "書き出しや共有Bake作業の前に Bake UV役割を準備し、レンダー対象を明示します。",
    ),
    "ui.role_switchboard.line.lightmap.ready": (
        "A Lightmap-style role already looks present. Reopen Lightmap prep when you need to rebuild or rename it.",
        "Lightmap系の役割はすでにありそうです。作り直しや名前整理が必要なときに Lightmap 準備を開きます。",
    ),
    "ui.role_switchboard.line.lightmap.todo": (
        "Prepare a dedicated Lightmap role when export, engine validation or channel separation needs a clearer target.",
        "書き出し、エンジン検証、チャンネル分離で明確な対象が必要なときに、専用の Lightmap 役割を準備します。",
    ),
    "ui.role_switchboard.line.atlas.ready": (
        "Atlas or tile-oriented roles look available. Use Atlas or UDIM helpers when you are ready to repack or publish shared space.",
        "Atlas またはタイル向け役割がありそうです。共有空間の再パックや公開準備をするときに Atlas / UDIM 補助を使います。",
    ),
    "ui.role_switchboard.line.atlas.todo": (
        "Open Atlas or UDIM helpers when repeated assets need shared space, tile planning or compact publish layout.",
        "反復アセットで共有空間、タイル計画、高密度公開レイアウトが必要なときに Atlas / UDIM 補助を開きます。",
    ),
    "ui.role_switchboard.layers": ("UV layers: {n}", "UV層数: {n}"),
    "ui.role_switchboard.roles": ("Detected roles: {names}", "検出役割: {names}"),
    "ui.role_switchboard.roles.none": ("Detected roles: none yet", "検出役割: まだなし"),
})


def _suv_role_switchboard_payload(context):
    obj = _active_mesh_obj(context)
    uv_layers_ref = getattr(getattr(obj, 'data', None), 'uv_layers', None) if obj is not None else None
    uv_names = []
    active_uv_name = '-'
    try:
        if uv_layers_ref is not None:
            uv_names = [str(getattr(layer, 'name', '') or '') for layer in uv_layers_ref]
            if getattr(uv_layers_ref, 'active', None):
                active_uv_name = str(uv_layers_ref.active.name or '-')
    except Exception:
        uv_names = []
    names_lower = [n.lower() for n in uv_names if n]
    has_working = bool(obj is not None and len(uv_names) > 0)
    has_bake = any('bake' in n for n in names_lower)
    has_light = any(('light' in n) or ('lm' in n) for n in names_lower)
    has_atlas = any(('atlas' in n) or ('udim' in n) or ('tile' in n) for n in names_lower)
    detected = []
    if has_working:
        detected.append('Working')
    if has_bake:
        detected.append('Bake')
    if has_light:
        detected.append('Lightmap')
    if has_atlas:
        detected.append('Atlas/UDIM')

    chips = [
        ('suv_uvmap', tr(context, 'ui.guide.active_uv', name=active_uv_name)),
        ('suv_workspace', tr(context, 'ui.role_switchboard.layers', n=len(uv_names))),
        ('suv_ref_pack', tr(context, 'ui.role_switchboard.roles', names=', '.join(detected)) if detected else tr(context, 'ui.role_switchboard.roles.none')),
        ('suv_workflow', tr(context, 'ui.control.obj_active', name=obj.name) if obj is not None else tr(context, 'ui.role_switchboard.line.none')),
    ]

    summary_lines = [
        tr(context, 'ui.guide.active_uv', name=active_uv_name),
        tr(context, 'ui.role_switchboard.roles', names=', '.join(detected)) if detected else tr(context, 'ui.role_switchboard.roles.none'),
    ]

    if obj is None:
        working_line = bake_line = light_line = atlas_line = tr(context, 'ui.role_switchboard.line.none')
    else:
        working_line = tr(context, 'ui.role_switchboard.line.working.ready' if has_working else 'ui.role_switchboard.line.working.todo')
        bake_line = tr(context, 'ui.role_switchboard.line.bake.ready' if has_bake else 'ui.role_switchboard.line.bake.todo')
        light_line = tr(context, 'ui.role_switchboard.line.lightmap.ready' if has_light else 'ui.role_switchboard.line.lightmap.todo')
        atlas_line = tr(context, 'ui.role_switchboard.line.atlas.ready' if has_atlas else 'ui.role_switchboard.line.atlas.todo')

    cards = [
        (
            tr(context, 'ui.role_switchboard.route.working'),
            [working_line],
            [
                ('uv.suv_native_stage_compat_tools', tr(context, 'ui.menu.batch_ensure_active_uv'), 'ADD', 'suv_uvmap', {'mode': 'BATCH_ENSURE_ACTIVE_UV'}),
                ('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
            ],
            'suv_uvmap',
        ),
        (
            tr(context, 'ui.role_switchboard.route.bake'),
            [bake_line],
            [
                ('mesh.suv_bake_uv_prep', tr(context, 'ui.menu.bake_uv_prep'), 'RESTRICT_RENDER_OFF', 'suv_uvmap', {'prep_mode': 'BAKE', 'target_name': 'UV_Bake'}),
                ('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
            ],
            'suv_ref_pack',
        ),
        (
            tr(context, 'ui.role_switchboard.route.lightmap'),
            [light_line],
            [
                ('mesh.suv_bake_uv_prep', tr(context, 'ui.menu.lightmap_uv_prep'), 'LIGHT', 'suv_uvmap', {'prep_mode': 'LIGHTMAP', 'target_name': 'UV_Lightmap'}),
                ('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
            ],
            'suv_ref_checker',
        ),
        (
            tr(context, 'ui.role_switchboard.route.atlas'),
            [atlas_line],
            [
                ('wm.context_set_enum', tr(context, 'ui.tab.atlas'), 'TEXTURE', 'suv_atlas', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ATLAS'}),
                ('uv.suv_batch_object_to_udim_tiles', tr(context, 'op.batch_object_to_udim_tiles'), 'PACKAGE', 'suv_atlas', {}),
            ],
            'suv_atlas',
        ),
    ]

    return {
        'chips': chips,
        'summary_lines': summary_lines,
        'cards': cards,
    }


def _draw_role_switchboard(layout, context):
    payload = _suv_role_switchboard_payload(context)
    box, col = _create_box(layout, tr(context, 'ui.section.role_switchboard'), 'UV_DATA', 'suv_uvmap')
    _draw_hint(col, tr(context, 'ui.role_switchboard.hint'))
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.2)
    _draw_dashboard_card(col, tr(context, 'ui.role_switchboard.summary'), payload['summary_lines'], 'suv_uvmap', [])
    grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
    for title, lines, actions, preview_icon in payload['cards']:
        _draw_dashboard_card(grid, title, lines, preview_icon, actions)
    return box


_prev_draw_dashboard_v221162 = _draw_dashboard


def _draw_dashboard(layout, context):
    ws = _suv_ws(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    head = col.row(align=True)
    expanded = bool(getattr(ws, 'show_dashboard', False)) if ws else False
    from .foldout_header import draw_foldout_header
    draw_foldout_header(
        head, expanded, data=ws if ws else None, prop='show_dashboard' if ws else None,
        draw_title=lambda r: _label_with_icon(r, tr(context, 'ui.toggle.dashboard'), 'IMAGE_DATA', 'suv_workspace'))
    if not expanded:
        hint = col.row(align=True)
        hint.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        col.separator(factor=0.2)
        return

    draw_order = [
        _draw_visual_guide,
        _draw_control_center,
        _draw_mode_guard,
        _draw_workspace_rail,
        _draw_action_matrix,
        _draw_batch_pilot,
        _draw_library_shelf,
        _draw_role_switchboard,
        _draw_workflow_pulse,
        _draw_assisted_checklist,
        _draw_uv_role_board,
        _draw_finish_rail,
        _draw_review_ladder,
        _draw_delivery_gate,
        _draw_recovery_dock,
        _draw_state_snapshot,
        _draw_phase_coach,
        _draw_readiness_radar,
        _draw_next_step_advisor,
        _draw_tab_mission_brief,
        _draw_goal_paths,
        _draw_issue_solver,
        _draw_production_checkpoints,
        _draw_preset_cockpit,
        _draw_focus_lanes,
        _draw_outcome_compass,
        _draw_action_guide,
        _draw_recipe_cards,
        _draw_task_navigator,
        _draw_workspace_map,
        _draw_beginner_legend,
    ]
    for draw_fn in draw_order:
        box = draw_fn(col, context)
        if box is not None:
            col.separator(factor=0.15)

    recipes = [
        ("Auto UV Pro", 'suv_ref_auto', SUV_OT_auto_uv_profile.bl_idname, "Organic", 'MOD_SMOOTH', 'suv_ref_auto', {'profile': 'ORGANIC'}, ["有機形状向けの開始プリセット", "シーム→展開→調整の起点"]),
        ("Projection Lab", 'suv_ref_projection', SUV_OT_native_projection.bl_idname, "Smart Project", 'MOD_UVPROJECT', 'suv_ref_projection', {'mode': 'SMART_PROJECT', 'pack_after': True}, ["投影系ワークフローの入口", "ビュー・法線ベース系を整理"]),
        ("Pack + UDIM", 'suv_ref_pack', SUV_OT_pack_pro.bl_idname, "Pack Pro", 'PACKAGE', 'suv_ref_pack', {'engine': 'DETERMINISTIC', 'udim_mode': 'AUTO_TILES'}, ["密度とタイル整理の仕上げ", "必要時のみ詳細設定へ"]),
        ("Inspect + Density", 'suv_ref_inspect', SUV_OT_inspector_scan.bl_idname, 'Batch Inspect', 'VIEWZOOM', 'suv_ref_inspect', {}, ["チェッカーと検査の確認用", "トラブル時の確認に使用"]),
    ]
    use_gallery = bool(getattr(ws, 'show_reference_gallery', False)) if ws else False
    if use_gallery:
        grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_visual_recipe_card(grid, title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines)
    else:
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_dashboard_card(col, title, note_lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    col.separator(factor=0.2)


# --- ------------------------------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
        bl_info['description'] = (
            'Integrated UV workflow suite with split dashboard hubs, map ledger, role switchboard, library shelf, batch pilot, mode guard, workflow pulse, recovery dock, delivery gate, guided actions, bilingual help, QA, packing, trim, atlas, and compatibility bridges.'
        )
except Exception:
    pass

_TEXT.update({
    "ui.section.map_ledger": ("Map Ledger", "UVマップ台帳"),
    "ui.map_ledger.hint": (
        "Read the current UV layers as a compact ledger so working, render and support roles are easier to understand before map switching or export helpers.",
        "現在のUV層をコンパクトな台帳として確認し、マップ切替や書き出し補助へ進む前に、作業用、レンダー用、補助用の役割を把握しやすくします。",
    ),
    "ui.map_ledger.summary": ("Layer Summary", "層サマリー"),
    "ui.map_ledger.actions": ("Map Actions", "マップ操作"),
    "ui.map_ledger.none": ("No active mesh object", "アクティブなメッシュオブジェクトなし"),
    "ui.map_ledger.active": ("Active UV: {name}", "アクティブUV: {name}"),
    "ui.map_ledger.render": ("Render UV: {name}", "レンダーUV: {name}"),
    "ui.map_ledger.count": ("UV layers: {n}", "UV層数: {n}"),
    "ui.map_ledger.status.active": ("Active working target", "アクティブ作業対象"),
    "ui.map_ledger.status.render": ("Render / export target", "レンダー / 書き出し対象"),
    "ui.map_ledger.status.active_render": ("Active + Render target", "アクティブかつレンダー対象"),
    "ui.map_ledger.status.support": ("Supporting UV layer", "補助UV層"),
    "ui.map_ledger.summary.none": (
        "Create or duplicate a UV layer first so role switching and export helpers have a visible target.",
        "役割切替や書き出し補助の対象が見えるよう、先にUV層を作成または複製します。",
    ),
    "ui.map_ledger.more": ("Additional layers: {n}", "追加の層: {n}"),
})


def _suv_map_ledger_payload(context):
    obj = _active_mesh_obj(context)
    uv_layers_ref = getattr(getattr(obj, 'data', None), 'uv_layers', None) if obj is not None else None
    uv_entries = []
    active_name = '-'
    render_name = '-'
    try:
        if uv_layers_ref is not None:
            for layer in uv_layers_ref:
                name = str(getattr(layer, 'name', '') or '')
                is_active = bool(getattr(uv_layers_ref, 'active', None) == layer)
                is_render = bool(getattr(layer, 'active_render', False))
                uv_entries.append((name, is_active, is_render))
                if is_active:
                    active_name = name or '-'
                if is_render:
                    render_name = name or '-'
    except Exception:
        uv_entries = []

    chips = [
        ('suv_uvmap', tr(context, 'ui.map_ledger.active', name=active_name)),
        ('suv_ref_bake', tr(context, 'ui.map_ledger.render', name=render_name)),
        ('suv_workspace', tr(context, 'ui.map_ledger.count', n=len(uv_entries))),
        ('suv_workflow', tr(context, 'ui.control.obj_active', name=obj.name) if obj is not None else tr(context, 'ui.map_ledger.none')),
    ]

    if not uv_entries:
        summary_lines = [
            tr(context, 'ui.map_ledger.none'),
            tr(context, 'ui.map_ledger.summary.none'),
        ]
        cards = []
    else:
        summary_lines = [
            tr(context, 'ui.map_ledger.active', name=active_name),
            tr(context, 'ui.map_ledger.render', name=render_name),
            tr(context, 'ui.map_ledger.count', n=len(uv_entries)),
        ]
        cards = []
        for name, is_active, is_render in uv_entries[:4]:
            if is_active and is_render:
                status = tr(context, 'ui.map_ledger.status.active_render')
            elif is_active:
                status = tr(context, 'ui.map_ledger.status.active')
            elif is_render:
                status = tr(context, 'ui.map_ledger.status.render')
            else:
                status = tr(context, 'ui.map_ledger.status.support')
            actions = [
                ('mesh.suv_uvmap_set_active', tr(context, 'op.uv_set_active'), 'RESTRICT_SELECT_OFF', 'suv_uvmap', {'uv_name': name}),
                ('mesh.suv_uvmap_set_render', tr(context, 'op.uv_set_render'), 'RESTRICT_RENDER_OFF', 'suv_ref_bake', {'uv_name': name}),
            ]
            cards.append((name or '-', [status], actions, 'suv_uvmap'))
        if len(uv_entries) > 4:
            cards.append((tr(context, 'ui.map_ledger.more', n=len(uv_entries) - 4), [tr(context, 'ui.tab.maps')], [('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'})], 'suv_uvmap'))

    actions = [
        ('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
        ('mesh.suv_uvmap_add', tr(context, 'op.uv_add'), 'ADD', 'suv_uvmap', {}),
        ('mesh.suv_uvmap_duplicate', tr(context, 'op.uv_duplicate'), 'DUPLICATE', 'suv_uvmap', {}),
        ('mesh.suv_uvmap_rename_active', tr(context, 'op.uv_rename_active'), 'GREASEPENCIL', 'suv_uvmap', {}),
    ]
    return {
        'chips': chips,
        'summary_lines': summary_lines,
        'cards': cards,
        'actions': actions,
    }


def _draw_map_ledger(layout, context):
    payload = _suv_map_ledger_payload(context)
    box, col = _create_box(layout, tr(context, 'ui.section.map_ledger'), 'GROUP_UVS', 'suv_uvmap')
    _draw_hint(col, tr(context, 'ui.map_ledger.hint'))
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.2)
    _draw_dashboard_card(col, tr(context, 'ui.map_ledger.summary'), payload['summary_lines'], 'suv_uvmap', [])
    if payload['cards']:
        grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
        for title, lines, actions, preview_icon in payload['cards']:
            _draw_dashboard_card(grid, title, lines, preview_icon, actions)
        col.separator(factor=0.15)
    _draw_dashboard_card(col, tr(context, 'ui.map_ledger.actions'), [tr(context, 'ui.section.uv_maps')], 'suv_uvmap', payload['actions'])
    return box


_prev_draw_dashboard_v221163 = _draw_dashboard


def _draw_dashboard(layout, context):
    ws = _suv_ws(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    head = col.row(align=True)
    expanded = bool(getattr(ws, 'show_dashboard', False)) if ws else False
    from .foldout_header import draw_foldout_header
    draw_foldout_header(
        head, expanded, data=ws if ws else None, prop='show_dashboard' if ws else None,
        draw_title=lambda r: _label_with_icon(r, tr(context, 'ui.toggle.dashboard'), 'IMAGE_DATA', 'suv_workspace'))
    if not expanded:
        hint = col.row(align=True)
        hint.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        col.separator(factor=0.2)
        return

    draw_order = [
        _draw_visual_guide,
        _draw_control_center,
        _draw_mode_guard,
        _draw_workspace_rail,
        _draw_action_matrix,
        _draw_batch_pilot,
        _draw_library_shelf,
        _draw_role_switchboard,
        _draw_map_ledger,
        _draw_workflow_pulse,
        _draw_assisted_checklist,
        _draw_uv_role_board,
        _draw_finish_rail,
        _draw_review_ladder,
        _draw_delivery_gate,
        _draw_recovery_dock,
        _draw_state_snapshot,
        _draw_phase_coach,
        _draw_readiness_radar,
        _draw_next_step_advisor,
        _draw_tab_mission_brief,
        _draw_goal_paths,
        _draw_issue_solver,
        _draw_production_checkpoints,
        _draw_preset_cockpit,
        _draw_focus_lanes,
        _draw_outcome_compass,
        _draw_action_guide,
        _draw_recipe_cards,
        _draw_task_navigator,
        _draw_workspace_map,
        _draw_beginner_legend,
    ]
    for draw_fn in draw_order:
        box = draw_fn(col, context)
        if box is not None:
            col.separator(factor=0.15)

    recipes = [
        ("Auto UV Pro", 'suv_ref_auto', SUV_OT_auto_uv_profile.bl_idname, "Organic", 'MOD_SMOOTH', 'suv_ref_auto', {'profile': 'ORGANIC'}, ["有機形状向けの開始プリセット", "シーム→展開→調整の起点"]),
        ("Projection Lab", 'suv_ref_projection', SUV_OT_native_projection.bl_idname, "Smart Project", 'MOD_UVPROJECT', 'suv_ref_projection', {'mode': 'SMART_PROJECT', 'pack_after': True}, ["投影系ワークフローの入口", "ビュー・法線ベース系を整理"]),
        ("Pack + UDIM", 'suv_ref_pack', SUV_OT_pack_pro.bl_idname, "Pack Pro", 'PACKAGE', 'suv_ref_pack', {'engine': 'DETERMINISTIC', 'udim_mode': 'AUTO_TILES'}, ["密度とタイル整理の仕上げ", "必要時のみ詳細設定へ"]),
        ("Inspect + Density", 'suv_ref_inspect', SUV_OT_inspector_scan.bl_idname, 'Batch Inspect', 'VIEWZOOM', 'suv_ref_inspect', {}, ["チェッカーと検査の確認用", "トラブル時の確認に使用"]),
    ]
    use_gallery = bool(getattr(ws, 'show_reference_gallery', False)) if ws else False
    if use_gallery:
        grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_visual_recipe_card(grid, title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines)
    else:
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_dashboard_card(col, title, note_lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    col.separator(factor=0.2)


# --- preset deck ----------------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
        bl_info['description'] = (
            'Integrated UV workflow suite with split dashboard hubs, preset deck, map ledger, role switchboard, library shelf, batch pilot, mode guard, workflow pulse, review ladder, recovery dock, delivery gate, assisted checklist, phase coach, '
            'state snapshot, guided actions, bilingual help, QA, packing, trimsheet, atlas, and compatibility bridges.'
        )
except Exception:
    pass

_TEXT.update({
    "ui.section.preset_deck": ("Preset Deck", "プリセットデッキ"),
    "ui.preset_deck.hint": (
        "A compact preset launch surface for workflow, display, line-flow and layout presets so common working modes can be recalled without digging through separate menus.",
        "ワークフロー、表示、ライン/フロー、レイアウトの各プリセットを、別々のメニューを深く辿らず呼び出せるコンパクトな起動面です。",
    ),
    "ui.preset_deck.summary": ("Preset Summary", "プリセット概要"),
    "ui.preset_deck.actions": ("Preset Actions", "プリセット操作"),
    "ui.preset_deck.route.workflow": ("Workflow Presets", "ワークフロープリセット"),
    "ui.preset_deck.route.display": ("Display Presets", "表示プリセット"),
    "ui.preset_deck.route.flow": ("Line / Flow Presets", "ライン / フロープリセット"),
    "ui.preset_deck.route.layout": ("Layout Presets", "レイアウトプリセット"),
    "ui.preset_deck.line.workflow": (
        "Switch several scene-facing workflow settings together when you want a safer starting point for unwrap, align, layout or repair work.",
        "展開、整列、配置、修復の開始点をより安全寄りに揃えたいとき、複数のワークフロー設定をまとめて切り替えます。",
    ),
    "ui.preset_deck.line.display": (
        "Change UI density and visible helper focus so the workspace exposes only the kind of controls you want to concentrate on.",
        "UI密度と補助表示の焦点を切り替え、今集中したい種類のコントロールだけを見やすくします。",
    ),
    "ui.preset_deck.line.flow": (
        "Load straightening and edge-flow oriented cleanup defaults before line-sensitive shells are rectified or annotated.",
        "直線化やエッジフロー重視の既定値を読み込み、ライン依存の強いシェルを整形・注記する前準備を整えます。",
    ),
    "ui.preset_deck.line.layout": (
        "Prepare pack, tidy or row/block arrangement defaults before the finishing pass starts pushing shells into their final structure.",
        "最終仕上げでシェルを確定構造へ寄せる前に、パック、整頓、行/ブロック配置の既定値を準備します。",
    ),
    "ui.preset_deck.path": (
        "Use presets to move the workspace into a more predictable state first, then continue with scan, pack, role-UV or atlas tasks from a cleaner baseline.",
        "まずプリセットでワークスペースをより予測しやすい状態へ寄せ、その後で検査、パック、役割UV、アトラス作業へクリーンな基準から進みます。",
    ),
    "ui.preset_deck.action.validate": ("Validate Preset Assets", "プリセット資産を検証"),
    "ui.preset_deck.action.library": ("Preset Library I/O", "プリセットライブラリI/O"),
})


def _suv_preset_deck_payload(context):
    ws = _suv_ws(context)
    obj = _active_mesh_obj(context)
    current_tab = _suv_tab_title(context, ws) if '_suv_tab_title' in globals() else str(getattr(ws, 'main_tab', 'WORKFLOW'))
    issue_total = _suv_cached_issue_total(ws) if '_suv_cached_issue_total' in globals() else 0
    active_uv = '-'
    try:
        if obj is not None and getattr(obj.data, 'uv_layers', None) is not None and obj.data.uv_layers.active:
            active_uv = obj.data.uv_layers.active.name
    except Exception:
        pass

    chips = [
        ('suv_workflow', tr(context, 'ui.control.tab', name=current_tab)),
        ('suv_uvmap', tr(context, 'ui.guide.active_uv', name=active_uv)),
        ('suv_ref_inspect', tr(context, 'ui.control.issues', n=issue_total)),
        ('suv_workspace', tr(context, 'ui.control.obj_active', name=getattr(obj, 'name', '-')) if obj is not None else tr(context, 'ui.control.obj_none')),
    ]

    summary_lines = [
        tr(context, 'ui.preset_deck.path'),
        tr(context, 'ui.action_matrix.line.inspect.fix') if issue_total > 0 else tr(context, 'ui.action_matrix.line.prepare.ready'),
    ]

    cards = [
        (
            tr(context, 'ui.preset_deck.route.workflow'),
            [tr(context, 'ui.preset_deck.line.workflow')],
            [
                ('uv.suv_apply_workflow_preset', 'Unfold Trim', 'UV', 'suv_workflow', {'preset': 'UNWRAP'}),
                ('uv.suv_apply_workflow_preset', 'Repair', 'BRUSH_DATA', 'suv_ref_inspect', {'preset': 'REPAIR'}),
            ],
            'suv_workflow',
        ),
        (
            tr(context, 'ui.preset_deck.route.display'),
            [tr(context, 'ui.preset_deck.line.display')],
            [
                ('uv.suv_apply_display_preset', 'Basic', 'WINDOW', 'suv_workspace', {'preset': 'BASIC'}),
                ('uv.suv_apply_display_preset', 'Batch Inspect', 'VIEWZOOM', 'suv_ref_inspect', {'preset': 'INSPECT'}),
            ],
            'suv_workspace',
        ),
        (
            tr(context, 'ui.preset_deck.route.flow'),
            [tr(context, 'ui.preset_deck.line.flow')],
            [
                ('uv.suv_apply_line_flow_preset', 'Straight', 'FIXED_SIZE', 'suv_ref_line', {'preset': 'STRAIGHT'}),
                ('uv.suv_apply_line_flow_preset', 'Flow', 'IPO_EASE_IN_OUT', 'suv_ref_line', {'preset': 'FLOW'}),
            ],
            'suv_ref_line',
        ),
        (
            tr(context, 'ui.preset_deck.route.layout'),
            [tr(context, 'ui.preset_deck.line.layout')],
            [
                ('uv.suv_apply_layout_preset', 'Pack', 'PACKAGE', 'suv_ref_pack', {'preset': 'PACK'}),
                ('uv.suv_apply_layout_preset', 'Tidy', 'ALIGN_JUSTIFY', 'suv_ref_pack', {'preset': 'TIDY'}),
            ],
            'suv_ref_pack',
        ),
    ]

    actions = [
        ('uv.suv_validate_workflow_assets', tr(context, 'ui.preset_deck.action.validate'), 'CHECKMARK', 'suv_workspace', {}),
        ('uv.suv_preset_library_io', tr(context, 'ui.preset_deck.action.library'), 'FILEBROWSER', 'suv_workspace', {}),
        ('wm.context_set_enum', tr(context, 'ui.tab.workflow'), 'UV', 'suv_workflow', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'WORKFLOW'}),
    ]

    return {
        'chips': chips,
        'summary_lines': summary_lines,
        'cards': cards,
        'actions': actions,
    }


def _draw_preset_deck(layout, context):
    payload = _suv_preset_deck_payload(context)
    box, col = _create_box(layout, tr(context, 'ui.section.preset_deck'), 'PRESET', 'suv_workspace')
    _draw_hint(col, tr(context, 'ui.preset_deck.hint'))
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.2)
    _draw_dashboard_card(col, tr(context, 'ui.preset_deck.summary'), payload['summary_lines'], 'suv_workspace', [])
    grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
    for title, lines, actions, preview_icon in payload['cards']:
        _draw_dashboard_card(grid, title, lines, preview_icon, actions)
    col.separator(factor=0.15)
    _draw_dashboard_card(col, tr(context, 'ui.preset_deck.actions'), [tr(context, 'ui.preset_deck.path')], 'suv_workspace', payload['actions'])
    return box


_prev_draw_dashboard_v221164 = _draw_dashboard


def _draw_dashboard(layout, context):
    ws = _suv_ws(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    head = col.row(align=True)
    expanded = bool(getattr(ws, 'show_dashboard', False)) if ws else False
    from .foldout_header import draw_foldout_header
    draw_foldout_header(
        head, expanded, data=ws if ws else None, prop='show_dashboard' if ws else None,
        draw_title=lambda r: _label_with_icon(r, tr(context, 'ui.toggle.dashboard'), 'IMAGE_DATA', 'suv_workspace'))
    if not expanded:
        hint = col.row(align=True)
        hint.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        col.separator(factor=0.2)
        return

    draw_order = [
        _draw_visual_guide,
        _draw_control_center,
        _draw_mode_guard,
        _draw_workspace_rail,
        _draw_action_matrix,
        _draw_batch_pilot,
        _draw_library_shelf,
        _draw_preset_deck,
        _draw_role_switchboard,
        _draw_map_ledger,
        _draw_workflow_pulse,
        _draw_assisted_checklist,
        _draw_uv_role_board,
        _draw_finish_rail,
        _draw_review_ladder,
        _draw_delivery_gate,
        _draw_recovery_dock,
        _draw_state_snapshot,
        _draw_phase_coach,
        _draw_readiness_radar,
        _draw_next_step_advisor,
        _draw_tab_mission_brief,
        _draw_goal_paths,
        _draw_issue_solver,
        _draw_production_checkpoints,
        _draw_preset_cockpit,
        _draw_focus_lanes,
        _draw_outcome_compass,
        _draw_action_guide,
        _draw_recipe_cards,
        _draw_task_navigator,
        _draw_workspace_map,
        _draw_beginner_legend,
    ]
    for draw_fn in draw_order:
        box = draw_fn(col, context)
        if box is not None:
            col.separator(factor=0.15)

    recipes = [
        ("Auto UV Pro", 'suv_ref_auto', SUV_OT_auto_uv_profile.bl_idname, "Organic", 'MOD_SMOOTH', 'suv_ref_auto', {'profile': 'ORGANIC'}, ["有機形状向けの開始プリセット", "シーム→展開→調整の起点"]),
        ("Projection Lab", 'suv_ref_projection', SUV_OT_native_projection.bl_idname, "Smart Project", 'MOD_UVPROJECT', 'suv_ref_projection', {'mode': 'SMART_PROJECT', 'pack_after': True}, ["投影系ワークフローの入口", "ビュー・法線ベース系を整理"]),
        ("Pack + UDIM", 'suv_ref_pack', SUV_OT_pack_pro.bl_idname, "Pack Pro", 'PACKAGE', 'suv_ref_pack', {'engine': 'DETERMINISTIC', 'udim_mode': 'AUTO_TILES'}, ["密度とタイル整理の仕上げ", "必要時のみ詳細設定へ"]),
        ("Inspect + Density", 'suv_ref_inspect', SUV_OT_inspector_scan.bl_idname, 'Batch Inspect', 'VIEWZOOM', 'suv_ref_inspect', {}, ["チェッカーと検査の確認用", "トラブル時の確認に使用"]),
    ]
    use_gallery = bool(getattr(ws, 'show_reference_gallery', False)) if ws else False
    if use_gallery:
        grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_visual_recipe_card(grid, title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines)
    else:
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_dashboard_card(col, title, note_lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    col.separator(factor=0.2)


# --- quick launchpad -----------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
        bl_info['description'] = (
            'Integrated UV workflow suite with split dashboard hubs, quick launchpad, preset deck, map ledger, role switchboard, library shelf, batch pilot, mode guard, workflow pulse, review ladder, recovery dock, delivery gate, assisted checklist, phase coach, '
            'state snapshot, guided actions, bilingual help, QA, packing, trimsheet, atlas, and compatibility bridges.'
        )
except Exception:
    pass

_TEXT.update({
    "ui.section.quick_launchpad": ("Quick Launchpad", "クイックランチパッド"),
    "ui.quick_launchpad.hint": (
        "Jump into the most-used unwrap, cleanup, inspection and role-UV actions from one compact surface after the workspace state has been checked.",
        "ワークスペース状態を確認した後、よく使う展開、整形、検査、役割UVアクションへ1つのコンパクトな面から素早く入ります。",
    ),
    "ui.quick_launchpad.summary": ("Launch Summary", "起動サマリー"),
    "ui.quick_launchpad.actions": ("Core Routes", "主要ルート"),
    "ui.quick_launchpad.route.unwrap": ("Unwrap Start", "展開開始"),
    "ui.quick_launchpad.route.clean": ("Align + Relax", "整列 + リラックス"),
    "ui.quick_launchpad.route.inspect": ("Inspect + Repair", "検査 + 修復"),
    "ui.quick_launchpad.route.roles": ("Roles + Output", "役割 + 出力"),
    "ui.quick_launchpad.line.unwrap": (
        "Start with seam-aware cutting and guided unwrap when you want a safer first pass before manual refinement.",
        "手動調整前により安全な初回パスを作りたいとき、シーム考慮の切り分けとガイド付き展開から開始します。",
    ),
    "ui.quick_launchpad.line.clean": (
        "Use alignment and relax tools when shells are already cut but still need cleaner edges and more stable spacing.",
        "シェルの切り分けは済んでいても、エッジ整理や間隔安定化がまだ必要なときに整列とリラックスを使います。",
    ),
    "ui.quick_launchpad.line.inspect": (
        "Scan first, then move into repair helpers so flipped, stretched or overlapping areas are handled from visible evidence.",
        "まず検査し、その後で修復補助へ進むことで、反転、歪み、重なりを見える根拠に基づいて扱います。",
    ),
    "ui.quick_launchpad.line.roles": (
        "Prepare Bake or Lightmap roles and switch map targets before export or downstream atlas workflows branch away from the working UV.",
        "書き出しや下流のアトラス工程が作業UVから分岐する前に、Bake / Lightmap 役割を準備し、対象マップを切り替えます。",
    ),
    "ui.quick_launchpad.path": (
        "Use this deck after mode checks, then continue into batch, preset, atlas or review sections only when the basic route is already stable.",
        "このデッキはモード確認後に使い、基本ルートが安定してから一括処理、プリセット、アトラス、確認セクションへ進みます。",
    ),
})


def _suv_quick_launchpad_payload(context):
    ws = _suv_ws(context)
    obj = _active_mesh_obj(context)
    current_tab = _suv_tab_title(context, ws) if '_suv_tab_title' in globals() else str(getattr(ws, 'main_tab', 'WORKFLOW'))
    issue_total = _suv_cached_issue_total(ws) if '_suv_cached_issue_total' in globals() else 0
    active_uv = '-'
    try:
        if obj is not None and getattr(obj.data, 'uv_layers', None) is not None and obj.data.uv_layers.active:
            active_uv = obj.data.uv_layers.active.name
    except Exception:
        pass

    chips = [
        ('suv_workflow', tr(context, 'ui.control.tab', name=current_tab)),
        ('suv_uvmap', tr(context, 'ui.guide.active_uv', name=active_uv)),
        ('suv_ref_inspect', tr(context, 'ui.control.issues', n=issue_total)),
        ('suv_workspace', tr(context, 'ui.control.obj_active', name=getattr(obj, 'name', '-')) if obj is not None else tr(context, 'ui.control.obj_none')),
    ]

    summary_lines = [
        tr(context, 'ui.quick_launchpad.path'),
        tr(context, 'ui.quick_launchpad.line.inspect') if issue_total > 0 else tr(context, 'ui.quick_launchpad.line.unwrap'),
    ]

    cards = [
        (
            tr(context, 'ui.quick_launchpad.route.unwrap'),
            [tr(context, 'ui.quick_launchpad.line.unwrap')],
            [
                (SUV_OT_smart_seams.bl_idname, tr(context, 'ui.quick_seams'), 'UV', 'suv_ref_auto', {}),
                (SUV_OT_auto_unwrap_pro.bl_idname, tr(context, 'ui.quick_unwrap'), 'MOD_UVPROJECT', 'suv_ref_auto', {}),
            ],
            'suv_ref_auto',
        ),
        (
            tr(context, 'ui.quick_launchpad.route.clean'),
            [tr(context, 'ui.quick_launchpad.line.clean')],
            [
                (SUV_OT_align_islands.bl_idname, tr(context, 'ui.quick_align'), 'ANCHOR_CENTER', 'suv_ref_align', {'mode': 'AUTO'}),
                (SUV_OT_smart_relax.bl_idname, tr(context, 'ui.quick_relax'), 'MOD_SMOOTH', 'suv_ref_relax', {}),
            ],
            'suv_ref_align',
        ),
        (
            tr(context, 'ui.quick_launchpad.route.inspect'),
            [tr(context, 'ui.quick_launchpad.line.inspect')],
            [
                (SUV_OT_inspector_scan.bl_idname, tr(context, 'ui.quick_scan'), 'VIEWZOOM', 'suv_ref_inspect', {}),
                (SUV_OT_workspace_auto_repair.bl_idname, tr(context, 'op.workspace_repair'), 'TOOL_SETTINGS', 'suv_workspace', {}),
                (SUV_OT_inspector_fix_flipped.bl_idname, tr(context, 'ui.menu.fix_flipped'), 'MOD_MIRROR', 'suv_ref_inspect', {}),
            ],
            'suv_ref_inspect',
        ),
        (
            tr(context, 'ui.quick_launchpad.route.roles'),
            [tr(context, 'ui.quick_launchpad.line.roles')],
            [
                ('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
                (SUV_OT_bake_uv_prep.bl_idname, tr(context, 'ui.menu.bake_uv_prep'), 'RENDER_STILL', 'suv_ref_bake', {'prep_mode': 'BAKE'}),
                (SUV_OT_bake_uv_prep.bl_idname, tr(context, 'ui.menu.lightmap_uv_prep'), 'LIGHT', 'suv_ref_bake', {'prep_mode': 'LIGHTMAP'}),
            ],
            'suv_ref_bake',
        ),
    ]

    return {
        'chips': chips,
        'summary_lines': summary_lines,
        'cards': cards,
    }


def _draw_quick_launchpad(layout, context):
    payload = _suv_quick_launchpad_payload(context)
    box, col = _create_box(layout, tr(context, 'ui.section.quick_launchpad'), 'PLAY', 'suv_workflow')
    _draw_hint(col, tr(context, 'ui.quick_launchpad.hint'))
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.2)
    _draw_dashboard_card(col, tr(context, 'ui.quick_launchpad.summary'), payload['summary_lines'], 'suv_workflow', [])
    grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
    for title, lines, actions, preview_icon in payload['cards']:
        _draw_dashboard_card(grid, title, lines, preview_icon, actions)
    return box


_prev_draw_dashboard_v221165 = _draw_dashboard


def _draw_dashboard(layout, context):
    ws = _suv_ws(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    head = col.row(align=True)
    expanded = bool(getattr(ws, 'show_dashboard', False)) if ws else False
    from .foldout_header import draw_foldout_header
    draw_foldout_header(
        head, expanded, data=ws if ws else None, prop='show_dashboard' if ws else None,
        draw_title=lambda r: _label_with_icon(r, tr(context, 'ui.toggle.dashboard'), 'IMAGE_DATA', 'suv_workspace'))
    if not expanded:
        hint = col.row(align=True)
        hint.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        col.separator(factor=0.2)
        return

    draw_order = [
        _draw_visual_guide,
        _draw_control_center,
        _draw_mode_guard,
        _draw_workspace_rail,
        _draw_action_matrix,
        _draw_quick_launchpad,
        _draw_batch_pilot,
        _draw_library_shelf,
        _draw_role_switchboard,
        _draw_map_ledger,
        _draw_preset_deck,
        _draw_workflow_pulse,
        _draw_assisted_checklist,
        _draw_uv_role_board,
        _draw_finish_rail,
        _draw_review_ladder,
        _draw_delivery_gate,
        _draw_recovery_dock,
        _draw_state_snapshot,
        _draw_phase_coach,
        _draw_readiness_radar,
        _draw_next_step_advisor,
        _draw_tab_mission_brief,
        _draw_goal_paths,
        _draw_issue_solver,
        _draw_production_checkpoints,
        _draw_preset_cockpit,
        _draw_focus_lanes,
        _draw_outcome_compass,
        _draw_action_guide,
        _draw_recipe_cards,
        _draw_task_navigator,
        _draw_workspace_map,
        _draw_beginner_legend,
    ]
    for draw_fn in draw_order:
        box = draw_fn(col, context)
        if box is not None:
            col.separator(factor=0.15)

    recipes = [
        ("Auto UV Pro", 'suv_ref_auto', SUV_OT_auto_uv_profile.bl_idname, "Organic", 'MOD_SMOOTH', 'suv_ref_auto', {'profile': 'ORGANIC'}, ["有機形状向けの開始プリセット", "シーム→展開→調整の起点"]),
        ("Projection Lab", 'suv_ref_projection', SUV_OT_native_projection.bl_idname, "Smart Project", 'MOD_UVPROJECT', 'suv_ref_projection', {'mode': 'SMART_PROJECT', 'pack_after': True}, ["投影系ワークフローの入口", "ビュー・法線ベース系を整理"]),
        ("Pack + UDIM", 'suv_ref_pack', SUV_OT_pack_pro.bl_idname, "Pack Pro", 'PACKAGE', 'suv_ref_pack', {'engine': 'DETERMINISTIC', 'udim_mode': 'AUTO_TILES'}, ["密度とタイル整理の仕上げ", "必要時のみ詳細設定へ"]),
        ("Inspect + Density", 'suv_ref_inspect', SUV_OT_inspector_scan.bl_idname, 'Batch Inspect', 'VIEWZOOM', 'suv_ref_inspect', {}, ["チェッカーと検査の確認用", "トラブル時の確認に使用"]),
    ]
    use_gallery = bool(getattr(ws, 'show_reference_gallery', False)) if ws else False
    if use_gallery:
        grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_visual_recipe_card(grid, title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines)
    else:
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_dashboard_card(col, title, note_lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    col.separator(factor=0.2)


# --- consistency board ---------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
        bl_info['description'] = (
            'Integrated UV workflow suite with split dashboard hubs, consistency board, quick launchpad, preset deck, map ledger, role switchboard, library shelf, batch pilot, mode guard, workflow pulse, review ladder, recovery dock, delivery gate, assisted checklist, phase coach, '
            'state snapshot, guided actions, bilingual help, QA, packing, trimsheet, atlas, and compatibility bridges.'
        )
except Exception:
    pass

_TEXT.update({
    "ui.section.consistency_board": ("Consistency Board", "整合ボード"),
    "ui.consistency_board.hint": (
        "Check whether the selected meshes agree on active and render UV targets before batch sync, role preparation or export helpers change multiple objects at once.",
        "複数オブジェクトを一度に変更する前に、選択メッシュ間でアクティブUVとレンダーUVの対象が揃っているかを確認します。",
    ),
    "ui.consistency_board.summary": ("Selection Consistency", "選択整合"),
    "ui.consistency_board.actions": ("Sync Actions", "同期アクション"),
    "ui.consistency_board.none": ("Select one or more mesh objects", "1つ以上のメッシュを選択"),
    "ui.consistency_board.single": (
        "Single-object selection is already simple. Batch alignment becomes more useful when multiple meshes must share the same working target.",
        "単体選択では管理は比較的簡単です。複数メッシュで同じ作業対象を共有するときに、一括整列の効果が高くなります。",
    ),
    "ui.consistency_board.active.same": ("Active UV aligned: {name}", "アクティブUVは一致: {name}"),
    "ui.consistency_board.active.mixed": ("Active UV differs across selection: {n} names", "アクティブUVが選択間で不一致: {n}種類"),
    "ui.consistency_board.active.missing": ("Objects missing active UV: {n}", "アクティブUV不足オブジェクト: {n}"),
    "ui.consistency_board.render.same": ("Render UV aligned: {name}", "レンダーUVは一致: {name}"),
    "ui.consistency_board.render.mixed": ("Render UV differs across selection: {n} names", "レンダーUVが選択間で不一致: {n}種類"),
    "ui.consistency_board.layers.missing": ("Objects without UV layers: {n}", "UV層なしオブジェクト: {n}"),
    "ui.consistency_board.meshes": ("Selected meshes: {n}", "選択メッシュ数: {n}"),
    "ui.consistency_board.uvcount": ("UV slots across selection: {n}", "選択全体のUVスロット数: {n}"),
    "ui.consistency_board.path": (
        "Use this board before batch tools when you need the same active slot, render slot or role-prep target across several meshes.",
        "複数メッシュで同じアクティブスロット、レンダーUV、役割準備先を揃えたいときに、このボードを一括処理前の確認に使います。",
    ),
})

_TEXT.update({
    "ui.section.selection_scope": ("Selection Scope", "選択スコープ"),
    "ui.selection_scope.hint": (
        "Read the current mesh-selection context before running selection helpers, island tools or UDIM checks so the next action matches the actual working scope.",
        "選択補助、アイランドツール、UDIM確認を実行する前に、現在のメッシュ選択文脈を把握し、次の操作が実際の作業範囲に合うようにします。",
    ),
    "ui.selection_scope.summary": ("Selection State", "選択状態"),
    "ui.selection_scope.actions": ("Selection Actions", "選択アクション"),
    "ui.selection_scope.none": ("Select or activate a mesh object", "メッシュオブジェクトを選択またはアクティブ化"),
    "ui.selection_scope.mode.object": ("Object Mode", "オブジェクトモード"),
    "ui.selection_scope.mode.edit": ("Edit Mode", "編集モード"),
    "ui.selection_scope.meshes": ("Selected meshes: {n}", "選択メッシュ数: {n}"),
    "ui.selection_scope.active": ("Active mesh: {name}", "アクティブメッシュ: {name}"),
    "ui.selection_scope.sync.on": ("UV Sync: ON", "UV同期: ON"),
    "ui.selection_scope.sync.off": ("UV Sync: OFF", "UV同期: OFF"),
    "ui.selection_scope.area": ("Area: {name}", "エリア: {name}"),
    "ui.selection_scope.verts": ("Selected verts: {n}", "選択頂点数: {n}"),
    "ui.selection_scope.edges": ("Selected edges: {n}", "選択辺数: {n}"),
    "ui.selection_scope.faces": ("Selected faces: {n}", "選択面数: {n}"),
    "ui.selection_scope.object_hint": (
        "Enter Edit Mode when you want island, boundary or seam-oriented selection helpers to work on the current mesh contents.",
        "現在メッシュ内容に対してアイランド、境界、シーム系の選択補助を使いたいときは、編集モードへ入ります。",
    ),
    "ui.selection_scope.edit_hint": (
        "Use the helper selection tools below to grow the current scope by similarity, identical shape, fragmentation or UDIM crossing state.",
        "下の補助選択ツールを使うと、類似形状、同一形状、断片化、UDIM跨ぎ状態で現在の選択範囲を広げられます。",
    ),
    "ui.selection_scope.path": (
        "Check this board first when you are unsure whether the current mode, sync state or component selection matches the next UV selection helper.",
        "次に使うUV選択補助に対して、現在のモード、同期状態、要素選択が合っているか迷ったときに、まずこのボードで確認します。",
    ),
})


def _suv_consistency_board_payload(context):
    meshes = [obj for obj in (_selected_mesh_objects(context) or []) if getattr(obj, 'type', None) == 'MESH']
    active_names = []
    render_names = []
    missing_active = 0
    missing_layers = 0
    uv_slot_total = 0
    for obj in meshes:
        try:
            layers = getattr(getattr(obj, 'data', None), 'uv_layers', None)
            layer_count = len(layers) if layers is not None else 0
            uv_slot_total += int(layer_count)
            if layer_count <= 0:
                missing_layers += 1
                missing_active += 1
                continue
            active = getattr(layers, 'active', None)
            if active is not None and getattr(active, 'name', None):
                active_names.append(active.name)
            else:
                missing_active += 1
            render_name = None
            try:
                for uv in layers:
                    if bool(getattr(uv, 'active_render', False)):
                        render_name = getattr(uv, 'name', None)
                        break
            except Exception:
                render_name = None
            if not render_name and active is not None:
                render_name = getattr(active, 'name', None)
            if render_name:
                render_names.append(str(render_name))
        except Exception:
            missing_layers += 1
            missing_active += 1

    distinct_active = sorted({str(name) for name in active_names if name})
    distinct_render = sorted({str(name) for name in render_names if name})
    active_label = distinct_active[0] if len(distinct_active) == 1 else '-'
    chips = [
        ('suv_workspace', tr(context, 'ui.consistency_board.meshes', n=len(meshes))),
        ('suv_uvmap', tr(context, 'ui.consistency_board.uvcount', n=uv_slot_total)),
        ('suv_ref_bake', tr(context, 'ui.guide.active_uv', name=active_label)),
        ('suv_ref_checker', tr(context, 'ui.control.scan', state=tr(context, 'ui.control.scan.ready' if len(meshes) else 'ui.control.scan.none'))),
    ]

    summary_lines = []
    if not meshes:
        summary_lines.append(tr(context, 'ui.consistency_board.none'))
    else:
        summary_lines.append(tr(context, 'ui.consistency_board.path'))
        if missing_layers:
            summary_lines.append(tr(context, 'ui.consistency_board.layers.missing', n=missing_layers))
        if missing_active:
            summary_lines.append(tr(context, 'ui.consistency_board.active.missing', n=missing_active))
        if len(distinct_active) == 1:
            summary_lines.append(tr(context, 'ui.consistency_board.active.same', name=distinct_active[0]))
        elif len(distinct_active) > 1:
            summary_lines.append(tr(context, 'ui.consistency_board.active.mixed', n=len(distinct_active)))
        if len(distinct_render) == 1:
            summary_lines.append(tr(context, 'ui.consistency_board.render.same', name=distinct_render[0]))
        elif len(distinct_render) > 1:
            summary_lines.append(tr(context, 'ui.consistency_board.render.mixed', n=len(distinct_render)))
        if len(meshes) == 1:
            summary_lines.append(tr(context, 'ui.consistency_board.single'))

    actions_lines = []
    if not meshes:
        actions_lines.append(tr(context, 'ui.consistency_board.none'))
    else:
        if missing_layers or missing_active or len(distinct_active) > 1:
            actions_lines.append(tr(context, 'ui.menu.batch_ensure_active_uv'))
            actions_lines.append(tr(context, 'ui.menu.batch_sync_active_uv'))
        else:
            actions_lines.append(tr(context, 'ui.menu.sync_active_uv'))
        if len(distinct_render) > 1:
            actions_lines.append(tr(context, 'ui.tab.maps'))
        actions_lines.append(tr(context, 'ui.export_texel_report'))

    actions = [
        ('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
        ('uv.suv_native_stage_compat_tools', tr(context, 'ui.menu.batch_ensure_active_uv'), 'ADD', 'suv_uvmap', {'mode': 'BATCH_ENSURE_ACTIVE_UV'}),
        ('uv.suv_native_stage_compat_tools', tr(context, 'ui.menu.batch_sync_active_uv'), 'LINKED', 'suv_uvmap', {'mode': 'BATCH_SYNC_ACTIVE_UV'}),
        ('uv.suv_native_stage_compat_tools', tr(context, 'ui.export_texel_report'), 'TEXT', 'suv_density', {'mode': 'BATCH_EXPORT_TEXEL_REPORT'}),
    ]
    return {
        'chips': chips,
        'summary_lines': summary_lines,
        'actions_lines': actions_lines,
        'actions': actions,
    }


def _draw_consistency_board(layout, context):
    payload = _suv_consistency_board_payload(context)
    box, col = _create_box(layout, tr(context, 'ui.section.consistency_board'), 'UV_SYNC_SELECT', 'suv_uvmap')
    _draw_hint(col, tr(context, 'ui.consistency_board.hint'))
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.2)
    _draw_dashboard_card(col, tr(context, 'ui.consistency_board.summary'), payload['summary_lines'], 'suv_uvmap', [])
    _draw_dashboard_card(col, tr(context, 'ui.consistency_board.actions'), payload['actions_lines'], 'suv_workspace', payload['actions'])
    return box


_prev_draw_dashboard_v221166 = _draw_dashboard


def _draw_dashboard(layout, context):
    ws = _suv_ws(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    head = col.row(align=True)
    expanded = bool(getattr(ws, 'show_dashboard', False)) if ws else False
    from .foldout_header import draw_foldout_header
    draw_foldout_header(
        head, expanded, data=ws if ws else None, prop='show_dashboard' if ws else None,
        draw_title=lambda r: _label_with_icon(r, tr(context, 'ui.toggle.dashboard'), 'IMAGE_DATA', 'suv_workspace'))
    if not expanded:
        hint = col.row(align=True)
        hint.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        col.separator(factor=0.2)
        return

    draw_order = [
        _draw_visual_guide,
        _draw_control_center,
        _draw_mode_guard,
        _draw_workspace_rail,
        _draw_action_matrix,
        _draw_consistency_board,
        _draw_selection_scope,
        _draw_quick_launchpad,
        _draw_batch_pilot,
        _draw_library_shelf,
        _draw_role_switchboard,
        _draw_map_ledger,
        _draw_preset_deck,
        _draw_workflow_pulse,
        _draw_assisted_checklist,
        _draw_uv_role_board,
        _draw_finish_rail,
        _draw_review_ladder,
        _draw_delivery_gate,
        _draw_recovery_dock,
        _draw_state_snapshot,
        _draw_phase_coach,
        _draw_readiness_radar,
        _draw_next_step_advisor,
        _draw_tab_mission_brief,
        _draw_goal_paths,
        _draw_issue_solver,
        _draw_production_checkpoints,
        _draw_preset_cockpit,
        _draw_focus_lanes,
        _draw_outcome_compass,
        _draw_action_guide,
        _draw_recipe_cards,
        _draw_task_navigator,
        _draw_workspace_map,
        _draw_beginner_legend,
    ]
    for draw_fn in draw_order:
        box = draw_fn(col, context)
        if box is not None:
            col.separator(factor=0.35)


def _suv_selection_scope_payload(context):
    obj = _active_mesh_obj(context)
    meshes = [o for o in (_selected_mesh_objects(context) or []) if getattr(o, 'type', None) == 'MESH']
    tool_settings = getattr(context, 'tool_settings', None)
    uv_sync = bool(getattr(tool_settings, 'use_uv_select_sync', False)) if tool_settings else False
    area_type = getattr(getattr(context, 'area', None), 'type', '') or '-'
    in_edit = bool(obj is not None and getattr(obj, 'mode', '') == 'EDIT')
    sel_v = sel_e = sel_f = 0
    if in_edit and obj is not None:
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            sel_v = sum(1 for v in bm.verts if v.select)
            sel_e = sum(1 for e in bm.edges if e.select)
            sel_f = sum(1 for f in bm.faces if f.select)
        except Exception:
            sel_v = sel_e = sel_f = 0
    chips = [
        ('suv_workspace', tr(context, 'ui.selection_scope.meshes', n=len(meshes))),
        ('suv_uvmap', tr(context, 'ui.selection_scope.mode.edit' if in_edit else 'ui.selection_scope.mode.object')),
        ('suv_ref_checker', tr(context, 'ui.selection_scope.sync.on' if uv_sync else 'ui.selection_scope.sync.off')),
        ('suv_workflow', tr(context, 'ui.selection_scope.area', name=area_type)),
    ]
    summary_lines = []
    if obj is None:
        summary_lines.append(tr(context, 'ui.selection_scope.none'))
    else:
        summary_lines.append(tr(context, 'ui.selection_scope.path'))
        summary_lines.append(tr(context, 'ui.selection_scope.active', name=getattr(obj, 'name', '-')))
        summary_lines.append(tr(context, 'ui.selection_scope.meshes', n=len(meshes)))
        summary_lines.append(tr(context, 'ui.selection_scope.sync.on' if uv_sync else 'ui.selection_scope.sync.off'))
        if in_edit:
            summary_lines.append(tr(context, 'ui.selection_scope.verts', n=sel_v))
            summary_lines.append(tr(context, 'ui.selection_scope.edges', n=sel_e))
            summary_lines.append(tr(context, 'ui.selection_scope.faces', n=sel_f))
            summary_lines.append(tr(context, 'ui.selection_scope.edit_hint'))
        else:
            summary_lines.append(tr(context, 'ui.selection_scope.object_hint'))
    actions_lines = []
    actions = []
    if obj is None:
        actions_lines.append(tr(context, 'ui.selection_scope.none'))
    else:
        if not in_edit:
            actions_lines.append(tr(context, 'ui.selection_scope.mode.edit'))
            actions_lines.append(tr(context, 'ui.tab.maps'))
            actions.extend([
                ('object.mode_set', tr(context, 'ui.selection_scope.mode.edit'), 'EDITMODE_HLT', 'suv_workspace', {'mode': 'EDIT'}),
                ('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
            ])
        else:
            actions_lines.extend([
                tr(context, 'ui.op.sel_similar'),
                tr(context, 'ui.op.sel_identical'),
                tr(context, 'ui.op.udim_crossing'),
                tr(context, 'ui.menu.select_fragmented_islands'),
            ])
            actions.extend([
                ('uv.suv_select_similar_islands', tr(context, 'ui.op.sel_similar'), 'RESTRICT_SELECT_OFF', 'suv_op_sel_similar', {}),
                ('uv.suv_select_identical_islands', tr(context, 'ui.op.sel_identical'), 'COPYDOWN', 'suv_op_similarity_identical', {}),
                ('uv.suv_select_udim_crossing', tr(context, 'ui.op.udim_crossing'), 'UV', 'suv_op_sel_udim', {}),
                ('uv.suv_select_fragmented_islands', tr(context, 'ui.menu.select_fragmented_islands'), 'SELECT_INTERSECT', 'suv_inspect', {}),
            ])
            if not uv_sync:
                actions_lines.insert(0, tr(context, 'ui.selection_scope.sync.on'))
                actions.insert(0, ('wm.context_toggle', tr(context, 'ui.selection_scope.sync.on'), 'UV_SYNC_SELECT', 'suv_uvmap', {'data_path': 'scene.tool_settings.use_uv_select_sync'}))
    return {
        'chips': chips,
        'summary_lines': summary_lines,
        'actions_lines': actions_lines,
        'actions': actions,
    }


def _draw_selection_scope(layout, context):
    payload = _suv_selection_scope_payload(context)
    box, col = _create_box(layout, tr(context, 'ui.section.selection_scope'), 'RESTRICT_SELECT_OFF', 'suv_workspace')
    _draw_hint(col, tr(context, 'ui.selection_scope.hint'))
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.2)
    _draw_dashboard_card(col, tr(context, 'ui.selection_scope.summary'), payload['summary_lines'], 'suv_workspace', [])
    _draw_dashboard_card(col, tr(context, 'ui.selection_scope.actions'), payload['actions_lines'], 'suv_uvmap', payload['actions'])
    return box


# --- status hub extension --------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
        bl_info['description'] = (
            'Integrated UV workflow suite with split dashboard hubs, bilingual help, export/reuse guidance, QA, packing, trim, atlas, role routing, diagnostics, and compatibility bridges.'
        )
except Exception:
    pass

_TEXT.update({
    "ui.section.reuse_deck": ("Reuse Deck", "再利用デッキ"),
    "ui.reuse_deck.hint": (
        "Summarize reusable set and preset routes in one compact deck so saving, recalling and sharing working assets is easier to reach from the dashboard.",
        "保存、呼び出し、共有の作業資産へダッシュボードから届きやすくするため、再利用セットとプリセットの経路を1つのコンパクトなデッキにまとめます。",
    ),
    "ui.reuse_deck.summary": ("Reuse Summary", "再利用概要"),
    "ui.reuse_deck.routes": ("Reuse Routes", "再利用ルート"),
    "ui.reuse_deck.count.selection": ("Selection sets: {n}", "選択セット数: {n}"),
    "ui.reuse_deck.count.layout": ("Layout sets: {n}", "レイアウトセット数: {n}"),
    "ui.reuse_deck.count.seam": ("Seam sets: {n}", "シームセット数: {n}"),
    "ui.reuse_deck.count.presets": ("Preset routes ready", "プリセット経路準備OK"),
    "ui.reuse_deck.line.selection": (
        "Save or recall recurring object and island scopes before repeating the same cleanup or export preparation.",
        "同じ整理や書き出し準備を繰り返す前に、反復するオブジェクトやアイランド範囲を保存または呼び出します。",
    ),
    "ui.reuse_deck.line.layout": (
        "Recall a trusted layout set when similar assets should inherit a known shell arrangement before final pack.",
        "類似アセットへ既知のシェル配置を引き継ぎたいときは、最終パック前に信頼できるレイアウトセットを呼び出します。",
    ),
    "ui.reuse_deck.line.seam": (
        "Reuse saved seam plans when mirrored or repeated parts should follow the same cut logic instead of being remarked by hand.",
        "ミラー部品や反復部品に同じ切り分け方針を使いたいときは、手で付け直さず保存済みシーム計画を再利用します。",
    ),
    "ui.reuse_deck.line.preset": (
        "Open preset library routes when workflow, display or layout behavior should be shared, backed up or restored.",
        "ワークフロー、表示、レイアウトの挙動を共有、バックアップ、復元したいときは、プリセットライブラリ経路を開きます。",
    ),
    "ui.reuse_deck.line.settings": (
        "Use workspace settings I/O when the broader working environment should be exported or restored together with reusable helpers.",
        "再利用ヘルパーと一緒に広い作業環境を出し入れしたいときは、ワークスペース設定入出力を使います。",
    ),
    "ui.reuse_deck.route.selection": ("Selection Route", "選択ルート"),
    "ui.reuse_deck.route.layout": ("Layout Route", "レイアウトルート"),
    "ui.reuse_deck.route.seam": ("Seam Route", "シームルート"),
    "ui.reuse_deck.route.preset": ("Preset Route", "プリセットルート"),
    "ui.reuse_deck.route.settings": ("Settings Route", "設定ルート"),
})


def _suv_reuse_deck_payload(context):
    obj = _active_mesh_obj(context)
    selection_count = layout_count = seam_count = 0
    if obj is not None:
        try:
            selection_count = len(_get_sets(obj) or {})
        except Exception:
            selection_count = 0
        try:
            layout_count = len(_get_layout_sets(obj) or {})
        except Exception:
            layout_count = 0
        try:
            seam_count = len(_get_seam_sets(obj) or {})
        except Exception:
            seam_count = 0

    chips = [
        ('suv_uvmap', tr(context, 'ui.reuse_deck.count.selection', n=selection_count)),
        ('suv_ref_pack', tr(context, 'ui.reuse_deck.count.layout', n=layout_count)),
        ('suv_ref_projection', tr(context, 'ui.reuse_deck.count.seam', n=seam_count)),
        ('suv_workspace', tr(context, 'ui.reuse_deck.count.presets')),
    ]
    summary_lines = [
        tr(context, 'ui.reuse_deck.line.selection'),
        tr(context, 'ui.reuse_deck.line.preset'),
    ]
    if obj is not None:
        summary_lines.insert(0, tr(context, 'ui.control.obj_active', name=getattr(obj, 'name', '-')))
    else:
        summary_lines.insert(0, tr(context, 'ui.mode.no_mesh'))

    cards = [
        (
            tr(context, 'ui.reuse_deck.route.selection'),
            [tr(context, 'ui.reuse_deck.line.selection')],
            ('wm.call_menu', tr(context, 'ui.menu.selection_sets'), 'BOOKMARKS', 'suv_workspace', {'name': 'UVSUITE_MT_SELECTION_SETS'}),
            'suv_uvmap',
        ),
        (
            tr(context, 'ui.reuse_deck.route.layout'),
            [tr(context, 'ui.reuse_deck.line.layout')],
            ('wm.call_menu', tr(context, 'ui.menu.layout_sets'), 'UV', 'suv_ref_pack', {'name': 'UVSUITE_MT_LAYOUT_SETS'}),
            'suv_ref_pack',
        ),
        (
            tr(context, 'ui.reuse_deck.route.seam'),
            [tr(context, 'ui.reuse_deck.line.seam')],
            ('wm.call_menu', tr(context, 'ui.menu.seam_sets'), 'MOD_EDGESPLIT', 'suv_ref_projection', {'name': 'UVSUITE_MT_SEAM_SETS'}),
            'suv_ref_projection',
        ),
        (
            tr(context, 'ui.reuse_deck.route.preset'),
            [tr(context, 'ui.reuse_deck.line.preset')],
            ('uv.suv_preset_library_io', tr(context, 'ui.preset_deck.action.library'), 'FILEBROWSER', 'suv_workspace', {}),
            'suv_workspace',
        ),
        (
            tr(context, 'ui.reuse_deck.route.settings'),
            [tr(context, 'ui.reuse_deck.line.settings')],
            ('uv.suv_workspace_settings_io', 'Workspace Settings I/O / ワークスペース設定入出力', 'FILEBROWSER', 'suv_workspace', {}),
            'suv_workspace',
        ),
    ]
    return {
        'chips': chips,
        'summary_lines': summary_lines,
        'cards': cards,
    }


def _draw_reuse_deck(layout, context):
    payload = _suv_reuse_deck_payload(context)
    box, col = _create_box(layout, tr(context, 'ui.section.reuse_deck'), 'BOOKMARKS', 'suv_workspace')
    _draw_hint(col, tr(context, 'ui.reuse_deck.hint'))
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.2)
    _draw_dashboard_card(col, tr(context, 'ui.reuse_deck.summary'), payload['summary_lines'], 'suv_workspace', [])
    grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
    for title, lines, action, preview_icon in payload['cards']:
        op_id, op_label, fallback_icon, custom_icon, props = action
        _draw_dashboard_card(grid, title, lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    return box


_prev_draw_dashboard_v221169 = _draw_dashboard


def _draw_dashboard(layout, context):
    ws = _suv_ws(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    head = col.row(align=True)
    expanded = bool(getattr(ws, 'show_dashboard', False)) if ws else False
    from .foldout_header import draw_foldout_header
    draw_foldout_header(
        head, expanded, data=ws if ws else None, prop='show_dashboard' if ws else None,
        draw_title=lambda r: _label_with_icon(r, tr(context, 'ui.toggle.dashboard'), 'IMAGE_DATA', 'suv_workspace'))
    if not expanded:
        hint = col.row(align=True)
        hint.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        col.separator(factor=0.2)
        return

    draw_order = [
        _draw_visual_guide,
        _draw_control_center,
        _draw_mode_guard,
        _draw_workspace_rail,
        _draw_action_matrix,
        _draw_consistency_board,
        _draw_selection_scope,
        _draw_quick_launchpad,
        _draw_batch_pilot,
        _draw_library_shelf,
        _draw_reuse_deck,
        _draw_role_switchboard,
        _draw_map_ledger,
        _draw_preset_deck,
        _draw_workflow_pulse,
        _draw_assisted_checklist,
        _draw_uv_role_board,
        _draw_finish_rail,
        _draw_review_ladder,
        _draw_delivery_gate,
        _draw_recovery_dock,
        _draw_state_snapshot,
        _draw_phase_coach,
        _draw_readiness_radar,
        _draw_next_step_advisor,
        _draw_tab_mission_brief,
        _draw_goal_paths,
        _draw_issue_solver,
        _draw_production_checkpoints,
        _draw_preset_cockpit,
        _draw_focus_lanes,
        _draw_outcome_compass,
        _draw_action_guide,
        _draw_recipe_cards,
        _draw_task_navigator,
        _draw_workspace_map,
        _draw_beginner_legend,
    ]
    for draw_fn in draw_order:
        box = draw_fn(col, context)
        if box is not None:
            col.separator(factor=0.35)


# --- status hub extension ---------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
        bl_info['description'] = (
            'Integrated UV workflow suite with split dashboard hubs, sync deck, reuse guidance, export readiness, bilingual help, QA, packing, trim, atlas, and compatibility bridges.'
        )
except Exception:
    pass

_TEXT.update({
    "ui.section.sync_deck": ("Sync Deck", "同期デッキ"),
    "ui.sync_deck.hint": (
        "Read active UV, render UV and batch consistency from one compact deck before sharing settings, baking or exporting several meshes together.",
        "複数メッシュをまとめて共有、Bake、書き出しする前に、アクティブUV、Render UV、一括整合を1つのコンパクトなデッキで確認します。",
    ),
    "ui.sync_deck.summary": ("Sync Summary", "同期概要"),
    "ui.sync_deck.routes": ("Sync Routes", "同期ルート"),
    "ui.sync_deck.count.meshes": ("Meshes: {n}", "メッシュ数: {n}"),
    "ui.sync_deck.count.active": ("Active names: {n}", "アクティブ名数: {n}"),
    "ui.sync_deck.count.render": ("Render names: {n}", "Render名数: {n}"),
    "ui.sync_deck.count.missing": ("Missing UV slots: {n}", "UV不足: {n}"),
    "ui.sync_deck.line.none": (
        "Select one or more mesh objects to read synchronization status.",
        "同期状態を読むには、1つ以上のメッシュオブジェクトを選択します。",
    ),
    "ui.sync_deck.line.active.same": (
        "Selected meshes already share the same active UV target.",
        "選択メッシュはすでに同じアクティブUV対象を共有しています。",
    ),
    "ui.sync_deck.line.active.mixed": (
        "Active UV targets differ across the selection.",
        "選択内でアクティブUV対象が揃っていません。",
    ),
    "ui.sync_deck.line.render.same": (
        "Render/export UV appears consistent across the selection.",
        "Render / 書き出しUVは選択内で概ね一致しています。",
    ),
    "ui.sync_deck.line.render.mixed": (
        "Render/export UV differs across the selection.",
        "Render / 書き出しUVが選択内で揃っていません。",
    ),
    "ui.sync_deck.line.missing": (
        "Some selected meshes still miss UV layers or active targets.",
        "選択メッシュの一部でUV層またはアクティブ対象がまだ不足しています。",
    ),
    "ui.sync_deck.line.review": (
        "Use a report or validation pass before committing shared export or atlas steps.",
        "共有書き出しやアトラス工程へ進む前に、レポートまたは検証を行います。",
    ),
    "ui.sync_deck.route.active": ("Active Sync", "アクティブ同期"),
    "ui.sync_deck.route.render": ("Render Review", "Render確認"),
    "ui.sync_deck.route.report": ("Reports", "レポート"),
    "ui.sync_deck.route.validate": ("Validate", "検証"),
    "ui.batch_pilot.action.profile": ("Batch Layout Profile", "一括レイアウトプロファイル"),
    "ui.batch_pilot.action.report": ("Batch Texel Report", "一括テクセルレポート"),
    "ui.action.workspace_settings_io": ("Workspace Settings I/O", "ワークスペース設定入出力"),
})


def _suv_sync_deck_payload(context):
    meshes = [obj for obj in (_selected_mesh_objects(context) or []) if getattr(obj, 'type', None) == 'MESH']
    active_names = []
    render_names = []
    missing = 0
    for obj in meshes:
        try:
            layers = getattr(getattr(obj, 'data', None), 'uv_layers', None)
            if not layers or len(layers) <= 0:
                missing += 1
                continue
            active = getattr(layers, 'active', None)
            if active is not None and getattr(active, 'name', None):
                active_names.append(str(active.name))
            else:
                missing += 1
            render_name = None
            for uv in layers:
                if bool(getattr(uv, 'active_render', False)):
                    render_name = getattr(uv, 'name', None)
                    break
            if not render_name and active is not None:
                render_name = getattr(active, 'name', None)
            if render_name:
                render_names.append(str(render_name))
        except Exception:
            missing += 1
    active_distinct = sorted({n for n in active_names if n})
    render_distinct = sorted({n for n in render_names if n})
    chips = [
        ('suv_workspace', tr(context, 'ui.sync_deck.count.meshes', n=len(meshes))),
        ('suv_uvmap', tr(context, 'ui.sync_deck.count.active', n=len(active_distinct))),
        ('suv_ref_bake', tr(context, 'ui.sync_deck.count.render', n=len(render_distinct))),
        ('suv_ref_inspect', tr(context, 'ui.sync_deck.count.missing', n=missing)),
    ]
    if not meshes:
        summary_lines = [tr(context, 'ui.sync_deck.line.none')]
    else:
        summary_lines = [
            tr(context, 'ui.sync_deck.line.active.same' if len(active_distinct) == 1 and missing == 0 else 'ui.sync_deck.line.active.mixed'),
            tr(context, 'ui.sync_deck.line.render.same' if len(render_distinct) <= 1 else 'ui.sync_deck.line.render.mixed'),
        ]
        if missing:
            summary_lines.append(tr(context, 'ui.sync_deck.line.missing'))
        summary_lines.append(tr(context, 'ui.sync_deck.line.review'))
    cards = [
        (
            tr(context, 'ui.sync_deck.route.active'),
            [tr(context, 'ui.sync_deck.line.active.same' if len(active_distinct) == 1 and missing == 0 else 'ui.sync_deck.line.active.mixed')],
            ('uv.suv_native_stage_compat_tools', tr(context, 'ui.menu.batch_sync_active_uv'), 'LINKED', 'suv_uvmap', {'mode': 'BATCH_SYNC_ACTIVE_UV'}),
            'suv_uvmap',
        ),
        (
            tr(context, 'ui.sync_deck.route.render'),
            [tr(context, 'ui.sync_deck.line.render.same' if len(render_distinct) <= 1 else 'ui.sync_deck.line.render.mixed')],
            ('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
            'suv_ref_bake',
        ),
        (
            tr(context, 'ui.sync_deck.route.report'),
            [tr(context, 'ui.sync_deck.line.review')],
            ('uv.suv_native_stage_compat_tools', tr(context, 'ui.batch_pilot.action.report'), 'TEXT', 'suv_density', {'mode': 'BATCH_EXPORT_TEXEL_REPORT'}),
            'suv_ref_inspect',
        ),
        (
            tr(context, 'ui.sync_deck.route.validate'),
            [tr(context, 'op.workspace_validate.desc')],
            ('uv.suv_workspace_validate', tr(context, 'op.workspace_validate'), 'CHECKMARK', 'suv_workspace', {}),
            'suv_workspace',
        ),
    ]
    return {'chips': chips, 'summary_lines': summary_lines, 'cards': cards}


def _draw_sync_deck(layout, context):
    payload = _suv_sync_deck_payload(context)
    box, col = _create_box(layout, tr(context, 'ui.section.sync_deck'), 'UV_SYNC_SELECT', 'suv_uvmap')
    _draw_hint(col, tr(context, 'ui.sync_deck.hint'))
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.2)
    _draw_dashboard_card(col, tr(context, 'ui.sync_deck.summary'), payload['summary_lines'], 'suv_uvmap', [])
    grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
    for title, lines, action, preview_icon in payload['cards']:
        op_id, op_label, fallback_icon, custom_icon, props = action
        _draw_dashboard_card(grid, title, lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    return box


def _suv_batch_pilot_payload(context):
    ws = _suv_ws(context)
    objs = _selected_mesh_objects(context) if '_selected_mesh_objects' in globals() else []
    mesh_count = len(objs)
    issue_total = _suv_cached_issue_total(ws) if '_suv_cached_issue_total' in globals() else 0
    active_missing = 0
    role_like = 0
    for obj in objs:
        try:
            uv_layers = getattr(getattr(obj, 'data', None), 'uv_layers', None)
            active = getattr(uv_layers, 'active', None) if uv_layers is not None else None
            if not active:
                active_missing += 1
            names = [str(uv.name).lower() for uv in (uv_layers or [])]
            if any(any(k in n for k in ('bake', 'light', 'atlas', 'udim', 'trim')) for n in names):
                role_like += 1
        except Exception:
            active_missing += 1
    role_chip = f"Roles {role_like}/{mesh_count}" if mesh_count else "Roles 0/0"
    chips = [
        ('suv_workspace', tr(context, 'ui.batch_pilot.count.meshes', n=mesh_count)),
        ('suv_uvmap', tr(context, 'ui.batch_pilot.count.active_missing', n=active_missing)),
        ('suv_ref_inspect', tr(context, 'ui.batch_pilot.count.issues', n=issue_total)),
        ('suv_ref_bake', role_chip),
    ]
    prep_ready = mesh_count >= 2 and active_missing == 0
    sync_line = tr(context, 'ui.batch_pilot.line.sync.ready' if prep_ready else 'ui.batch_pilot.line.sync.todo')
    profile_line = tr(context, 'ui.batch_pilot.line.profile.todo') if mesh_count >= 2 else tr(context, 'ui.batch_pilot.line.mesh')
    tiles_line = tr(context, 'ui.batch_pilot.line.tiles.todo') if mesh_count >= 2 else tr(context, 'ui.batch_pilot.line.mesh')
    review_line = tr(context, 'ui.batch_pilot.line.review.todo') if mesh_count >= 2 else tr(context, 'ui.batch_pilot.line.mesh')
    return {
        'chips': chips,
        'summary_lines': [sync_line, profile_line],
        'cards': [
            (tr(context, 'ui.batch_pilot.route.sync'), [sync_line], ('uv.suv_native_stage_compat_tools', tr(context, 'ui.menu.batch_ensure_active_uv'), 'ADD', 'suv_uvmap', {'mode': 'BATCH_ENSURE_ACTIVE_UV'}), 'suv_uvmap'),
            (tr(context, 'ui.batch_pilot.route.profile'), [profile_line], ('uv.suv_batch_layout_profile', tr(context, 'ui.batch_pilot.action.profile'), 'PACKAGE', 'suv_ref_pack', {}), 'suv_ref_pack'),
            (tr(context, 'ui.batch_pilot.route.tiles'), [tiles_line], ('uv.suv_batch_object_to_udim_tiles', tr(context, 'ui.menu.transfer_batch_objects_udim'), 'SEQ_STRIP_META', 'suv_ref_pack', {}), 'suv_ref_pack'),
            (tr(context, 'ui.batch_pilot.route.review'), [review_line], ('uv.suv_native_stage_compat_tools', tr(context, 'ui.batch_pilot.action.report'), 'TEXT', 'suv_density', {'mode': 'BATCH_EXPORT_TEXEL_REPORT'}), 'suv_ref_inspect'),
        ],
    }


def _suv_reuse_deck_payload(context):
    obj = _active_mesh_obj(context)
    selection_count = layout_count = seam_count = 0
    if obj is not None:
        try:
            selection_count = len(_get_sets(obj) or {})
        except Exception:
            selection_count = 0
        try:
            layout_count = len(_get_layout_sets(obj) or {})
        except Exception:
            layout_count = 0
        try:
            seam_count = len(_get_seam_sets(obj) or {})
        except Exception:
            seam_count = 0
    chips = [
        ('suv_uvmap', tr(context, 'ui.reuse_deck.count.selection', n=selection_count)),
        ('suv_ref_pack', tr(context, 'ui.reuse_deck.count.layout', n=layout_count)),
        ('suv_ref_projection', tr(context, 'ui.reuse_deck.count.seam', n=seam_count)),
        ('suv_workspace', tr(context, 'ui.reuse_deck.count.presets')),
    ]
    summary_lines = [tr(context, 'ui.reuse_deck.line.selection'), tr(context, 'ui.reuse_deck.line.preset')]
    if obj is not None:
        summary_lines.insert(0, tr(context, 'ui.control.obj_active', name=getattr(obj, 'name', '-')))
    else:
        summary_lines.insert(0, tr(context, 'ui.mode.no_mesh'))
    cards = [
        (tr(context, 'ui.reuse_deck.route.selection'), [tr(context, 'ui.reuse_deck.line.selection')], ('wm.call_menu', tr(context, 'ui.menu.selection_sets'), 'BOOKMARKS', 'suv_workspace', {'name': 'UVSUITE_MT_SELECTION_SETS'}), 'suv_uvmap'),
        (tr(context, 'ui.reuse_deck.route.layout'), [tr(context, 'ui.reuse_deck.line.layout')], ('wm.call_menu', tr(context, 'ui.menu.layout_sets'), 'UV', 'suv_ref_pack', {'name': 'UVSUITE_MT_LAYOUT_SETS'}), 'suv_ref_pack'),
        (tr(context, 'ui.reuse_deck.route.seam'), [tr(context, 'ui.reuse_deck.line.seam')], ('wm.call_menu', tr(context, 'ui.menu.seam_sets'), 'MOD_EDGESPLIT', 'suv_ref_projection', {'name': 'UVSUITE_MT_SEAM_SETS'}), 'suv_ref_projection'),
        (tr(context, 'ui.reuse_deck.route.preset'), [tr(context, 'ui.reuse_deck.line.preset')], ('uv.suv_preset_library_io', tr(context, 'ui.preset_deck.action.library'), 'FILEBROWSER', 'suv_workspace', {}), 'suv_workspace'),
        (tr(context, 'ui.reuse_deck.route.settings'), [tr(context, 'ui.reuse_deck.line.settings')], ('uv.suv_workspace_settings_io', tr(context, 'ui.action.workspace_settings_io'), 'FILEBROWSER', 'suv_workspace', {}), 'suv_workspace'),
    ]
    return {'chips': chips, 'summary_lines': summary_lines, 'cards': cards}


_prev_draw_dashboard_v221170 = _draw_dashboard


def _draw_dashboard(layout, context):
    ws = _suv_ws(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    head = col.row(align=True)
    expanded = bool(getattr(ws, 'show_dashboard', False)) if ws else False
    from .foldout_header import draw_foldout_header
    draw_foldout_header(
        head, expanded, data=ws if ws else None, prop='show_dashboard' if ws else None,
        draw_title=lambda r: _label_with_icon(r, tr(context, 'ui.toggle.dashboard'), 'IMAGE_DATA', 'suv_workspace'))
    if not expanded:
        hint = col.row(align=True)
        hint.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        col.separator(factor=0.2)
        return
    draw_order = [
        _draw_visual_guide,
        _draw_control_center,
        _draw_mode_guard,
        _draw_workspace_rail,
        _draw_action_matrix,
        _draw_consistency_board,
        _draw_sync_deck,
        _draw_selection_scope,
        _draw_quick_launchpad,
        _draw_batch_pilot,
        _draw_library_shelf,
        _draw_reuse_deck,
        _draw_role_switchboard,
        _draw_map_ledger,
        _draw_preset_deck,
        _draw_workflow_pulse,
        _draw_assisted_checklist,
        _draw_uv_role_board,
        _draw_finish_rail,
        _draw_review_ladder,
        _draw_delivery_gate,
        _draw_recovery_dock,
        _draw_state_snapshot,
        _draw_phase_coach,
        _draw_readiness_radar,
        _draw_next_step_advisor,
        _draw_tab_mission_brief,
        _draw_goal_paths,
        _draw_issue_solver,
        _draw_production_checkpoints,
        _draw_preset_cockpit,
        _draw_focus_lanes,
        _draw_outcome_compass,
        _draw_action_guide,
        _draw_recipe_cards,
        _draw_task_navigator,
        _draw_workspace_map,
        _draw_beginner_legend,
    ]
    for draw_fn in draw_order:
        box = draw_fn(col, context)
        if box is not None:
            col.separator(factor=0.35)


# --- risk flags extension ---------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
        bl_info['description'] = (
            'Integrated UV workflow suite with split dashboard hubs, risk flags, sync guidance, export readiness, bilingual help, QA, packing, trim, atlas, and compatibility bridges.'
        )
except Exception:
    pass

_TEXT.update({
    "ui.section.risk_flags": ("Risk Flags", "リスクフラグ"),
    "ui.risk_flags.hint": (
        "Read the main blockers before running tools so missing context, missing UV layers, unsynced selection or unfinished checks are visible at a glance.",
        "ツール実行前に主な阻害要因を読み取り、文脈不足、UV不足、未同期選択、未完了の検査を一目で把握できるようにします。",
    ),
    "ui.risk_flags.summary": ("Risk Summary", "リスク概要"),
    "ui.risk_flags.routes": ("Quick Routes", "クイックルート"),
    "ui.risk_flags.count.meshes": ("Meshes: {n}", "メッシュ数: {n}"),
    "ui.risk_flags.count.issues": ("Issues: {n}", "問題数: {n}"),
    "ui.risk_flags.count.missing_uv": ("Missing UV: {n}", "UV不足: {n}"),
    "ui.risk_flags.count.roles": ("Role-like UVs: {n}", "役割UV候補: {n}"),
    "ui.risk_flags.line.no_mesh": (
        "No mesh selection is available for UV operations.",
        "UV操作に使えるメッシュ選択がありません。",
    ),
    "ui.risk_flags.line.not_edit": (
        "You are not currently in Edit Mode, so selection-sensitive UV tools may not behave as expected.",
        "現在 Edit Mode ではないため、選択依存のUVツールが想定どおりに動かない場合があります。",
    ),
    "ui.risk_flags.line.sync_off": (
        "UV Sync is off, so UV-side and mesh-side selections may drift apart during review.",
        "UV Sync が OFF のため、確認中にUV側とメッシュ側の選択がずれる可能性があります。",
    ),
    "ui.risk_flags.line.missing_uv": (
        "Some selected meshes still miss a working or active UV target.",
        "選択メッシュの一部で作業用またはアクティブUV対象がまだ不足しています。",
    ),
    "ui.risk_flags.line.no_scan": (
        "No recent inspection result is cached yet.",
        "最近の検査結果がまだキャッシュされていません。",
    ),
    "ui.risk_flags.line.issues": (
        "Known UV issues are still present in the cached report.",
        "キャッシュ済みレポート上で既知のUV問題がまだ残っています。",
    ),
    "ui.risk_flags.line.roles": (
        "Bake, Lightmap or Atlas role-like UV names are still sparse across the selection.",
        "Bake、Lightmap、Atlas に見える役割UV名が選択内でまだ十分ではありません。",
    ),
    "ui.risk_flags.line.ok": (
        "No major blockers are currently obvious from the dashboard context.",
        "ダッシュボード文脈上では大きな阻害要因は今のところ目立ちません。",
    ),
    "ui.risk_flags.route.context": ("Context", "文脈"),
    "ui.risk_flags.route.uv": ("UV Prep", "UV準備"),
    "ui.risk_flags.route.inspect": ('Batch Inspect', "検査"),
    "ui.risk_flags.route.finish": ("Finish", "仕上げ"),
})


def _suv_risk_flags_payload(context):
    ws = _suv_ws(context)
    meshes = [obj for obj in (_selected_mesh_objects(context) or []) if getattr(obj, 'type', None) == 'MESH']
    mesh_count = len(meshes)
    issue_total = _suv_cached_issue_total(ws) if '_suv_cached_issue_total' in globals() else 0

    missing_uv = 0
    role_like = 0
    for obj in meshes:
        try:
            layers = getattr(getattr(obj, 'data', None), 'uv_layers', None)
            if not layers or len(layers) <= 0 or getattr(layers, 'active', None) is None:
                missing_uv += 1
            names = [str(getattr(uv, 'name', '')).lower() for uv in (layers or [])]
            if any(any(tag in n for tag in ('bake', 'light', 'atlas', 'udim')) for n in names):
                role_like += 1
        except Exception:
            missing_uv += 1

    edit_mode = str(getattr(context, 'mode', '')) == 'EDIT_MESH'
    try:
        uv_sync = bool(getattr(getattr(context, 'tool_settings', None), 'use_uv_select_sync', False))
    except Exception:
        uv_sync = False

    lines = []
    if mesh_count == 0:
        lines.append(tr(context, 'ui.risk_flags.line.no_mesh'))
    if mesh_count > 0 and not edit_mode:
        lines.append(tr(context, 'ui.risk_flags.line.not_edit'))
    if mesh_count > 0 and not uv_sync:
        lines.append(tr(context, 'ui.risk_flags.line.sync_off'))
    if missing_uv:
        lines.append(tr(context, 'ui.risk_flags.line.missing_uv'))
    if issue_total <= 0:
        lines.append(tr(context, 'ui.risk_flags.line.no_scan'))
    else:
        lines.append(tr(context, 'ui.risk_flags.line.issues'))
    if mesh_count > 0 and role_like < mesh_count:
        lines.append(tr(context, 'ui.risk_flags.line.roles'))
    if not lines:
        lines.append(tr(context, 'ui.risk_flags.line.ok'))

    chips = [
        ('suv_workspace', tr(context, 'ui.risk_flags.count.meshes', n=mesh_count)),
        ('suv_ref_inspect', tr(context, 'ui.risk_flags.count.issues', n=issue_total)),
        ('suv_uvmap', tr(context, 'ui.risk_flags.count.missing_uv', n=missing_uv)),
        ('suv_ref_bake', tr(context, 'ui.risk_flags.count.roles', n=role_like)),
    ]

    cards = [
        (
            tr(context, 'ui.risk_flags.route.context'),
            [lines[0]],
            ('uv.suv_workspace_validate', tr(context, 'op.workspace_validate'), 'CHECKMARK', 'suv_workspace', {}),
            'suv_workspace',
        ),
        (
            tr(context, 'ui.risk_flags.route.uv'),
            [tr(context, 'ui.risk_flags.line.missing_uv') if missing_uv else tr(context, 'ui.risk_flags.line.ok')],
            ('uv.suv_native_stage_compat_tools', tr(context, 'ui.menu.batch_ensure_active_uv'), 'ADD', 'suv_uvmap', {'mode': 'BATCH_ENSURE_ACTIVE_UV'}),
            'suv_uvmap',
        ),
        (
            tr(context, 'ui.risk_flags.route.inspect'),
            [tr(context, 'ui.risk_flags.line.no_scan') if issue_total <= 0 else tr(context, 'ui.risk_flags.line.issues')],
            ('uv.suv_inspector_scan', tr(context, 'op.inspector_scan'), 'VIEWZOOM', 'suv_ref_inspect', {}),
            'suv_ref_inspect',
        ),
        (
            tr(context, 'ui.risk_flags.route.finish'),
            [tr(context, 'ui.risk_flags.line.roles') if mesh_count > 0 and role_like < mesh_count else tr(context, 'ui.risk_flags.line.ok')],
            ('uv.suv_pack_pro', tr(context, 'op.pack_pro'), 'PACKAGE', 'suv_ref_pack', {}),
            'suv_ref_pack',
        ),
    ]
    return {
        'chips': chips,
        'summary_lines': lines[:4],
        'cards': cards,
    }


def _draw_risk_flags(layout, context):
    payload = _suv_risk_flags_payload(context)
    box, col = _create_box(layout, tr(context, 'ui.section.risk_flags'), 'ERROR', 'suv_workspace')
    _draw_hint(col, tr(context, 'ui.risk_flags.hint'))
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.2)
    _draw_dashboard_card(col, tr(context, 'ui.risk_flags.summary'), payload['summary_lines'], 'suv_workspace', [])
    grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
    for title, lines, action, preview_icon in payload['cards']:
        op_id, op_label, fallback_icon, custom_icon, props = action
        _draw_dashboard_card(grid, title, lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    return box


_prev_draw_dashboard_v221171 = _draw_dashboard


def _draw_dashboard(layout, context):
    ws = _suv_ws(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    head = col.row(align=True)
    expanded = bool(getattr(ws, 'show_dashboard', False)) if ws else False
    from .foldout_header import draw_foldout_header
    draw_foldout_header(
        head, expanded, data=ws if ws else None, prop='show_dashboard' if ws else None,
        draw_title=lambda r: _label_with_icon(r, tr(context, 'ui.toggle.dashboard'), 'IMAGE_DATA', 'suv_workspace'))
    if not expanded:
        hint = col.row(align=True)
        hint.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        col.separator(factor=0.2)
        return
    draw_order = [
        _draw_visual_guide,
        _draw_control_center,
        _draw_mode_guard,
        _draw_risk_flags,
        _draw_workspace_rail,
        _draw_action_matrix,
        _draw_consistency_board,
        _draw_sync_deck,
        _draw_selection_scope,
        _draw_quick_launchpad,
        _draw_batch_pilot,
        _draw_library_shelf,
        _draw_reuse_deck,
        _draw_role_switchboard,
        _draw_map_ledger,
        _draw_preset_deck,
        _draw_workflow_pulse,
        _draw_assisted_checklist,
        _draw_uv_role_board,
        _draw_finish_rail,
        _draw_review_ladder,
        _draw_delivery_gate,
        _draw_recovery_dock,
        _draw_state_snapshot,
        _draw_phase_coach,
        _draw_readiness_radar,
        _draw_next_step_advisor,
        _draw_tab_mission_brief,
        _draw_goal_paths,
        _draw_issue_solver,
        _draw_production_checkpoints,
        _draw_preset_cockpit,
        _draw_focus_lanes,
        _draw_outcome_compass,
        _draw_action_guide,
        _draw_recipe_cards,
        _draw_task_navigator,
        _draw_workspace_map,
        _draw_beginner_legend,
    ]
    for draw_fn in draw_order:
        box = draw_fn(col, context)
        if box is not None:
            col.separator(factor=0.35)


# --- transfer deck extension ------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
        bl_info['description'] = (
            'Integrated UV workflow suite with split dashboard hubs, transfer deck, risk flags, sync guidance, export readiness, bilingual help, QA, packing, trim, atlas, and compatibility bridges.'
        )
except Exception:
    pass

_TEXT.update({
    "ui.section.transfer_deck": ("Transfer Deck", "転送デッキ"),
    "ui.transfer_deck.hint": (
        "Move saved selection, layout and seam intent between meshes from one compact deck so repeated assets can inherit reusable UV decisions with fewer detours.",
        "保存済みの選択、レイアウト、シームの意図を1つのコンパクトなデッキからメッシュ間へ移し、反復アセットが再利用可能なUV判断を少ない回り道で継承できるようにします。",
    ),
    "ui.transfer_deck.summary": ("Transfer Readiness", "転送準備状況"),
    "ui.transfer_deck.routes": ("Transfer Routes", "転送ルート"),
    "ui.transfer_deck.count.meshes": ("Meshes: {n}", "メッシュ数: {n}"),
    "ui.transfer_deck.count.selection": ("Selection Sets: {n}", "選択セット数: {n}"),
    "ui.transfer_deck.count.layout": ("Layout Sets: {n}", "レイアウトセット数: {n}"),
    "ui.transfer_deck.count.seam": ("Seam Sets: {n}", "シームセット数: {n}"),
    "ui.transfer_deck.line.mesh.none": (
        "No active mesh is available for transfer helpers yet.",
        "転送補助を使うためのアクティブメッシュがまだありません。",
    ),
    "ui.transfer_deck.line.mesh.single": (
        "Select another mesh when you want to transfer saved intent between assets.",
        "保存済みの意図をアセット間で転送したい場合は、別のメッシュも選択してください。",
    ),
    "ui.transfer_deck.line.mesh.ready": (
        "Multiple meshes are selected, so transfer routes can be used directly.",
        "複数メッシュが選択されているため、転送ルートをそのまま使えます。",
    ),
    "ui.transfer_deck.line.selection.ready": (
        "Saved selection sets are available for transfer.",
        "転送に使える保存済み選択セットがあります。",
    ),
    "ui.transfer_deck.line.selection.none": (
        "No saved selection set exists yet on the active mesh.",
        "アクティブメッシュ上に保存済み選択セットがまだありません。",
    ),
    "ui.transfer_deck.line.layout.ready": (
        "Saved layout sets are available for transfer.",
        "転送に使える保存済みレイアウトセットがあります。",
    ),
    "ui.transfer_deck.line.layout.none": (
        "No saved layout set exists yet on the active mesh.",
        "アクティブメッシュ上に保存済みレイアウトセットがまだありません。",
    ),
    "ui.transfer_deck.line.seam.ready": (
        "Saved seam sets are available for transfer.",
        "転送に使える保存済みシームセットがあります。",
    ),
    "ui.transfer_deck.line.seam.none": (
        "No saved seam set exists yet on the active mesh.",
        "アクティブメッシュ上に保存済みシームセットがまだありません。",
    ),
    "ui.transfer_deck.line.bridge": (
        "Use 3D transfer when shell intent should be copied from a related source mesh.",
        "関連するソースメッシュからシェルの意図をコピーしたい場合は 3D 転送を使います。",
    ),
    "ui.transfer_deck.route.selection": ("Selection Transfer", "選択転送"),
    "ui.transfer_deck.route.layout": ("Layout Transfer", "レイアウト転送"),
    "ui.transfer_deck.route.seam": ("Seam Transfer", "シーム転送"),
    "ui.transfer_deck.route.bridge": ("3D Bridge", "3Dブリッジ"),
    "ui.transfer_deck.action.selection": ("Transfer Selection Set", "選択セットを転送"),
    "ui.transfer_deck.action.layout": ("Transfer Layout Set", "レイアウトセットを転送"),
    "ui.transfer_deck.action.seam": ("Transfer Seam Set", "シームセットを転送"),
    "ui.transfer_deck.action.bridge": ("Smart 3D Transfer", "Smart 3D転送"),
})


def _suv_transfer_deck_payload(context):
    obj = _active_mesh_obj(context)
    meshes = [o for o in (_selected_mesh_objects(context) or []) if getattr(o, 'type', None) == 'MESH']
    mesh_count = len(meshes)
    selection_count = layout_count = seam_count = 0
    if obj is not None:
        try:
            selection_count = len(_get_sets(obj) or {})
        except Exception:
            selection_count = 0
        try:
            layout_count = len(_get_layout_sets(obj) or {})
        except Exception:
            layout_count = 0
        try:
            seam_count = len(_get_seam_sets(obj) or {})
        except Exception:
            seam_count = 0

    chips = [
        ('suv_workspace', tr(context, 'ui.transfer_deck.count.meshes', n=mesh_count)),
        ('suv_uvmap', tr(context, 'ui.transfer_deck.count.selection', n=selection_count)),
        ('suv_ref_pack', tr(context, 'ui.transfer_deck.count.layout', n=layout_count)),
        ('suv_ref_projection', tr(context, 'ui.transfer_deck.count.seam', n=seam_count)),
    ]

    summary_lines = []
    if obj is None:
        summary_lines.append(tr(context, 'ui.transfer_deck.line.mesh.none'))
    elif mesh_count < 2:
        summary_lines.append(tr(context, 'ui.transfer_deck.line.mesh.single'))
    else:
        summary_lines.append(tr(context, 'ui.transfer_deck.line.mesh.ready'))
    summary_lines.append(tr(context, 'ui.transfer_deck.line.selection.ready' if selection_count > 0 else 'ui.transfer_deck.line.selection.none'))
    summary_lines.append(tr(context, 'ui.transfer_deck.line.layout.ready' if layout_count > 0 else 'ui.transfer_deck.line.layout.none'))
    summary_lines.append(tr(context, 'ui.transfer_deck.line.seam.ready' if seam_count > 0 else 'ui.transfer_deck.line.seam.none'))
    summary_lines.append(tr(context, 'ui.transfer_deck.line.bridge'))

    cards = [
        (
            tr(context, 'ui.transfer_deck.route.selection'),
            [tr(context, 'ui.transfer_deck.line.selection.ready' if selection_count > 0 else 'ui.transfer_deck.line.selection.none')],
            ('uv.suv_set_transfer', tr(context, 'ui.transfer_deck.action.selection'), 'DUPLICATE', 'suv_uvmap', {}),
            'suv_uvmap',
        ),
        (
            tr(context, 'ui.transfer_deck.route.layout'),
            [tr(context, 'ui.transfer_deck.line.layout.ready' if layout_count > 0 else 'ui.transfer_deck.line.layout.none')],
            ('uv.suv_layout_set_transfer', tr(context, 'ui.transfer_deck.action.layout'), 'UV', 'suv_ref_pack', {}),
            'suv_ref_pack',
        ),
        (
            tr(context, 'ui.transfer_deck.route.seam'),
            [tr(context, 'ui.transfer_deck.line.seam.ready' if seam_count > 0 else 'ui.transfer_deck.line.seam.none')],
            ('uv.suv_seam_set_transfer', tr(context, 'ui.transfer_deck.action.seam'), 'MOD_EDGESPLIT', 'suv_ref_projection', {}),
            'suv_ref_projection',
        ),
        (
            tr(context, 'ui.transfer_deck.route.bridge'),
            [tr(context, 'ui.transfer_deck.line.bridge')],
            ('uv.suv_smart_3d_transfer', tr(context, 'ui.transfer_deck.action.bridge'), 'MOD_DATA_TRANSFER', 'suv_workspace', {}),
            'suv_workspace',
        ),
    ]

    return {
        'chips': chips,
        'summary_lines': summary_lines,
        'cards': cards,
    }



def _suv_polish_deck_payload(context):
    ws = _suv_ws(context)
    obj = _active_mesh_obj(context)
    mesh_count = 0
    try:
        mesh_count = len(_selected_mesh_objects(context))
    except Exception:
        mesh_count = 0
    issue_total = _suv_cached_issue_total(ws) if '_suv_cached_issue_total' in globals() else 0
    uv_name = '-'
    try:
        if obj is not None and getattr(obj.data, 'uv_layers', None) is not None and obj.data.uv_layers.active:
            uv_name = obj.data.uv_layers.active.name
    except Exception:
        pass

    chips = [
        ('suv_workspace', tr(context, 'ui.control.tab', name=_suv_tab_title(context, ws))),
        ('suv_ref_projection', tr(context, 'ui.control.meshes', n=mesh_count)),
        ('suv_ref_inspect', tr(context, 'ui.control.issues', n=issue_total)),
        ('suv_uvmap', tr(context, 'ui.guide.active_uv', name=uv_name)),
    ]

    summary_lines = []
    summary_lines.append(tr(context, 'ui.polish_deck.line.mesh.ready' if obj is not None else 'ui.polish_deck.line.mesh.none'))
    summary_lines.append(tr(context, 'ui.polish_deck.line.uv.ready' if uv_name != '-' else 'ui.polish_deck.line.uv.none'))
    summary_lines.append(tr(context, 'ui.polish_deck.line.issues.some' if issue_total else 'ui.polish_deck.line.issues.none'))
    summary_lines.append(tr(context, 'ui.polish_deck.line.finish'))

    cards = [
        (
            tr(context, 'ui.polish_deck.route.straighten'),
            [tr(context, 'ui.polish_deck.line.straighten')],
            ('uv.suv_smart_edge_straighten', tr(context, 'ui.polish_deck.action.straighten'), 'IPO_LINEAR', 'suv_ref_projection', {}),
            'suv_ref_projection',
        ),
        (
            tr(context, 'ui.polish_deck.route.rectify'),
            [tr(context, 'ui.polish_deck.line.rectify')],
            ('uv.suv_smart_rectify', tr(context, 'ui.polish_deck.action.rectify'), 'MESH_GRID', 'suv_ref_pack', {}),
            'suv_ref_pack',
        ),
        (
            tr(context, 'ui.polish_deck.route.match'),
            [tr(context, 'ui.polish_deck.line.match')],
            ('uv.suv_match_stitch_active_preserve', tr(context, 'ui.polish_deck.action.match'), 'MOD_DATA_TRANSFER', 'suv_workspace', {}),
            'suv_workspace',
        ),
        (
            tr(context, 'ui.polish_deck.route.finish'),
            [tr(context, 'ui.polish_deck.line.finish')],
            ('uv.suv_pack_pro', tr(context, 'ui.polish_deck.action.finish'), 'PACKAGE', 'suv_ref_pack', {}),
            'suv_ref_pack',
        ),
    ]
    return {
        'chips': chips,
        'summary_lines': summary_lines,
        'cards': cards,
    }


def _draw_polish_deck(layout, context):
    payload = _suv_polish_deck_payload(context)
    box, col = _create_box(layout, tr(context, 'ui.section.polish_deck'), 'MOD_BEVEL', 'suv_ref_pack')
    _draw_hint(col, tr(context, 'ui.polish_deck.hint'))
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.2)
    _draw_dashboard_card(col, tr(context, 'ui.polish_deck.summary'), payload['summary_lines'], 'suv_ref_pack', [])
    grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
    for title, lines, action, preview_icon in payload['cards']:
        op_id, op_label, fallback_icon, custom_icon, props = action
        _draw_dashboard_card(grid, title, lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    return box


def _draw_transfer_deck(layout, context):
    payload = _suv_transfer_deck_payload(context)
    box, col = _create_box(layout, tr(context, 'ui.section.transfer_deck'), 'MOD_DATA_TRANSFER', 'suv_workspace')
    _draw_hint(col, tr(context, 'ui.transfer_deck.hint'))
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.2)
    _draw_dashboard_card(col, tr(context, 'ui.transfer_deck.summary'), payload['summary_lines'], 'suv_workspace', [])
    grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
    for title, lines, action, preview_icon in payload['cards']:
        op_id, op_label, fallback_icon, custom_icon, props = action
        _draw_dashboard_card(grid, title, lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    return box


_prev_draw_dashboard_v221172 = _draw_dashboard


def _draw_dashboard(layout, context):
    ws = _suv_ws(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    head = col.row(align=True)
    expanded = bool(getattr(ws, 'show_dashboard', False)) if ws else False
    from .foldout_header import draw_foldout_header
    draw_foldout_header(
        head, expanded, data=ws if ws else None, prop='show_dashboard' if ws else None,
        draw_title=lambda r: _label_with_icon(r, tr(context, 'ui.toggle.dashboard'), 'IMAGE_DATA', 'suv_workspace'))
    if not expanded:
        hint = col.row(align=True)
        hint.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        col.separator(factor=0.2)
        return
    draw_order = [
        _draw_visual_guide,
        _draw_control_center,
        _draw_mode_guard,
        _draw_risk_flags,
        _draw_workspace_rail,
        _draw_action_matrix,
        _draw_consistency_board,
        _draw_sync_deck,
        _draw_selection_scope,
        _draw_quick_launchpad,
        _draw_batch_pilot,
        _draw_library_shelf,
        _draw_reuse_deck,
        _draw_transfer_deck,
        _draw_polish_deck,
        _draw_role_switchboard,
        _draw_map_ledger,
        _draw_preset_deck,
        _draw_workflow_pulse,
        _draw_assisted_checklist,
        _draw_uv_role_board,
        _draw_finish_rail,
        _draw_review_ladder,
        _draw_delivery_gate,
        _draw_recovery_dock,
        _draw_state_snapshot,
        _draw_phase_coach,
        _draw_readiness_radar,
        _draw_next_step_advisor,
        _draw_tab_mission_brief,
        _draw_goal_paths,
        _draw_issue_solver,
        _draw_production_checkpoints,
        _draw_preset_cockpit,
        _draw_focus_lanes,
        _draw_outcome_compass,
        _draw_action_guide,
        _draw_recipe_cards,
        _draw_task_navigator,
        _draw_workspace_map,
        _draw_beginner_legend,
    ]
    for draw_fn in draw_order:
        box = draw_fn(col, context)
        if box is not None:
            col.separator(factor=0.35)


# --- bridge board extension -------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
        bl_info['description'] = (
            'Integrated UV workflow suite with split dashboard hubs, bridge board, transfer/polish routes, bilingual help, QA, packing, trim, atlas, diagnostics, and compatibility bridges.'
        )
except Exception:
    pass

_TEXT.update({
    "ui.section.bridge_board": ("Bridge Board", "ブリッジボード"),
    "ui.bridge_board.hint": (
        "Collect projection, cleanup, similarity and 3D transfer bridge routes in one compact board so cross-workflow helpers are easier to reach from the dashboard.",
        "投影、補正、類似判定、3D転送のブリッジ経路を1つのコンパクトなボードへ集め、ワークフロー横断ヘルパーへダッシュボードから届きやすくします。",
    ),
    "ui.bridge_board.summary": ("Bridge Summary", "ブリッジ概要"),
    "ui.bridge_board.route.project": ("Projection Bridge", "投影ブリッジ"),
    "ui.bridge_board.route.cleanup": ("Cleanup Bridge", "補正ブリッジ"),
    "ui.bridge_board.route.magic": ("Smart Similarity Bridge", "類似判定ブリッジ"),
    "ui.bridge_board.route.transfer": ("3D Transfer", "3D転送"),
    "ui.bridge_board.line.project": (
        "Open projection-style helpers when the current shell should start from camera, normal, peel, pelt or scan-safe logic.",
        "現在のシェルをカメラ、法線、自動、Peel、Pelt、スキャン安全系のロジックから始めたいときに、投影系ブリッジを開きます。",
    ),
    "ui.bridge_board.line.cleanup": (
        "Run cleanup-style helpers when overlapping, rough borders or dense organic shells need faster heal, weld or relax passes.",
        "重なり、荒れた境界、密な有機シェルに対して、修復、ウェルド、リラックス系の補正を素早く行いたいときに使います。",
    ),
    "ui.bridge_board.line.magic": (
        "Use similarity bridges when repeated islands should be found, matched or stacked before the next layout pass.",
        "反復アイランドを次のレイアウト処理前に見つける、合わせる、重ねるときに類似判定ブリッジを使います。",
    ),
    "ui.bridge_board.line.transfer": (
        "Transfer shell intent from a related source mesh when another asset should inherit the same general UV direction in 3D space.",
        "別アセットへ3D空間基準で同じUVの大まかな方向性を継承したいときに、関連ソースメッシュからシェル意図を転送します。",
    ),
    "ui.bridge_board.count.meshes": ("Meshes: {n}", "メッシュ数: {n}"),
    "ui.bridge_board.count.issues": ("Issues: {n}", "問題数: {n}"),
    "ui.bridge_board.count.uv": ("UV Layers: {n}", "UV層数: {n}"),
    "ui.bridge_board.count.mode": ("Mode: {name}", "モード: {name}"),
})


def _suv_bridge_board_payload(context):
    ws = _suv_ws(context)
    obj = _active_mesh_obj(context)
    meshes = [o for o in (_selected_mesh_objects(context) or []) if getattr(o, 'type', None) == 'MESH']
    issue_total = _suv_cached_issue_total(ws) if '_suv_cached_issue_total' in globals() else 0
    uv_count = 0
    if obj is not None:
        try:
            uv_count = len(getattr(getattr(obj, 'data', None), 'uv_layers', []) or [])
        except Exception:
            uv_count = 0
    chips = [
        ('suv_workspace', tr(context, 'ui.bridge_board.count.meshes', n=len(meshes))),
        ('suv_ref_inspect', tr(context, 'ui.bridge_board.count.issues', n=issue_total)),
        ('suv_uvmap', tr(context, 'ui.bridge_board.count.uv', n=uv_count)),
        ('suv_workflow', tr(context, 'ui.bridge_board.count.mode', name=str(getattr(context, 'mode', 'OBJECT')))),
    ]
    summary_lines = []
    if obj is None:
        summary_lines.append(tr(context, 'ui.mode.no_mesh'))
    else:
        summary_lines.append(tr(context, 'ui.control.obj_active', name=getattr(obj, 'name', '-')))
        summary_lines.append(tr(context, 'ui.bridge_board.line.project'))
        if issue_total > 0:
            summary_lines.append(tr(context, 'ui.bridge_board.line.cleanup'))
        else:
            summary_lines.append(tr(context, 'ui.bridge_board.line.magic'))
    cards = [
        (
            tr(context, 'ui.bridge_board.route.project'),
            [tr(context, 'ui.bridge_board.line.project')],
            ('uv.suv_projection_bridge', tr(context, 'ui.bridge_board.route.project'), 'MOD_UVPROJECT', 'suv_ref_projection', {'mode': 'BEST_FIT'}),
            'suv_ref_projection',
        ),
        (
            tr(context, 'ui.bridge_board.route.cleanup'),
            [tr(context, 'ui.bridge_board.line.cleanup')],
            ('uv.suv_cleanup_bridge', tr(context, 'ui.bridge_board.route.cleanup'), 'BRUSH_DATA', 'suv_inspector', {'mode': 'HEAL_UV'}),
            'suv_inspector',
        ),
        (
            tr(context, 'ui.bridge_board.route.magic'),
            [tr(context, 'ui.bridge_board.line.magic')],
            ('uv.suv_similarity_bridge', tr(context, 'ui.bridge_board.route.magic'), 'RESTRICT_SELECT_OFF', 'suv_selection', {'mode': 'SIMILAR'}),
            'suv_selection',
        ),
        (
            tr(context, 'ui.bridge_board.route.transfer'),
            [tr(context, 'ui.bridge_board.line.transfer')],
            ('uv.suv_smart_3d_transfer', tr(context, 'op.transfer'), 'MOD_DATA_TRANSFER', 'suv_workspace', {}),
            'suv_workspace',
        ),
    ]
    return {'chips': chips, 'summary_lines': summary_lines, 'cards': cards}


def _draw_bridge_board(layout, context):
    payload = _suv_bridge_board_payload(context)
    box, col = _create_box(layout, tr(context, 'ui.section.bridge_board'), 'MOD_DATA_TRANSFER', 'suv_workspace')
    _draw_hint(col, tr(context, 'ui.bridge_board.hint'))
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.2)
    _draw_dashboard_card(col, tr(context, 'ui.bridge_board.summary'), payload['summary_lines'], 'suv_workspace', [])
    grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
    for title, lines, action, preview_icon in payload['cards']:
        op_id, op_label, fallback_icon, custom_icon, props = action
        _draw_dashboard_card(grid, title, lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    return box


_prev_draw_dashboard_v221173 = _draw_dashboard


def _draw_dashboard(layout, context):
    ws = _suv_ws(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    head = col.row(align=True)
    expanded = bool(getattr(ws, 'show_dashboard', False)) if ws else False
    from .foldout_header import draw_foldout_header
    draw_foldout_header(
        head, expanded, data=ws if ws else None, prop='show_dashboard' if ws else None,
        draw_title=lambda r: _label_with_icon(r, tr(context, 'ui.toggle.dashboard'), 'IMAGE_DATA', 'suv_workspace'))
    if not expanded:
        hint = col.row(align=True)
        hint.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        col.separator(factor=0.2)
        return
    draw_order = [
        _draw_visual_guide,
        _draw_control_center,
        _draw_mode_guard,
        _draw_risk_flags,
        _draw_workspace_rail,
        _draw_action_matrix,
        _draw_consistency_board,
        _draw_sync_deck,
        _draw_selection_scope,
        _draw_quick_launchpad,
        _draw_batch_pilot,
        _draw_library_shelf,
        _draw_reuse_deck,
        _draw_transfer_deck,
        _draw_bridge_board,
        _draw_polish_deck,
        _draw_role_switchboard,
        _draw_map_ledger,
        _draw_preset_deck,
        _draw_workflow_pulse,
        _draw_assisted_checklist,
        _draw_uv_role_board,
        _draw_finish_rail,
        _draw_review_ladder,
        _draw_delivery_gate,
        _draw_recovery_dock,
        _draw_state_snapshot,
        _draw_phase_coach,
        _draw_readiness_radar,
        _draw_next_step_advisor,
        _draw_tab_mission_brief,
        _draw_goal_paths,
        _draw_issue_solver,
        _draw_production_checkpoints,
        _draw_preset_cockpit,
        _draw_focus_lanes,
        _draw_outcome_compass,
        _draw_action_guide,
        _draw_recipe_cards,
        _draw_task_navigator,
        _draw_workspace_map,
        _draw_beginner_legend,
    ]
    for draw_fn in draw_order:
        box = draw_fn(col, context)
        if box is not None:
            col.separator(factor=0.35)


# --- audit deck extension ---------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
        bl_info['description'] = (
            'Integrated UV workflow suite with split dashboard hubs, audit deck, bridge/transfer/polish routes, bilingual help, QA, packing, trim, atlas, diagnostics, and compatibility bridges.'
        )
except Exception:
    pass

_TEXT.update({
    "ui.section.audit_deck": ("Audit Deck", "監査デッキ"),
    "ui.audit_deck.hint": (
        "Collect checker, stretch, issue-audit and overlay review routes in one compact board so final inspection is easier to start without hunting across tabs.",
        "チェッカー、ストレッチ、問題監査、オーバーレイ確認の導線を1つのコンパクトなボードへ集め、タブを探し回らずに最終確認を始めやすくします。",
    ),
    "ui.audit_deck.summary": ("Audit Readiness", "監査準備状況"),
    "ui.audit_deck.route.checker": ("Checker Review", "チェッカー確認"),
    "ui.audit_deck.route.stretch": ("Stretch Heatmap", "ストレッチヒートマップ"),
    "ui.audit_deck.route.audit": ("Issue Audit", "問題監査"),
    "ui.audit_deck.route.overlay": ("Issue Overlay", "問題オーバーレイ"),
    "ui.audit_deck.action.checker": ("Apply Checker", "チェッカー適用"),
    "ui.audit_deck.action.stretch": ("Show Heatmap", "ヒートマップ表示"),
    "ui.audit_deck.action.audit": ("Run Issue Audit", "問題監査を実行"),
    "ui.audit_deck.action.overlay": ("Show Overlay", "オーバーレイ表示"),
    "ui.audit_deck.line.checker": (
        "Use a checker preview to spot scale mismatch, seam readability and obvious shell distortion before export or bake.",
        "書き出しやベイク前に、スケール差、シームの見やすさ、明らかなシェル歪みを見つけるためにチェッカープレビューを使います。",
    ),
    "ui.audit_deck.line.stretch": (
        "Show stretch heatmap colors when the current shells need a quicker distortion pass before relax, rectify or repack work.",
        "リラックス、矩形化、再パック前に、現在シェルの歪みを素早く確認したいときにストレッチヒートマップを表示します。",
    ),
    "ui.audit_deck.line.audit": (
        "Run issue audit when overlap, flip, UDIM crossing, fragmentation or stretch severity should be summarized into a readable report.",
        "重なり、反転、UDIM跨ぎ、断片化、ストレッチの重大度を読みやすいレポートにまとめたいときに問題監査を実行します。",
    ),
    "ui.audit_deck.line.overlay": (
        "Overlay severity colors directly on the meshes when suspicious islands should be seen in-place before repair or handoff.",
        "修復や引き渡し前に、疑わしいアイランドをその場で見たいときに重大度カラーをメッシュ上へ重ねて表示します。",
    ),
    "ui.audit_deck.count.meshes": ("Meshes: {n}", "メッシュ数: {n}"),
    "ui.audit_deck.count.issues": ("Issues: {n}", "問題数: {n}"),
    "ui.audit_deck.count.uv": ("UV Layers: {n}", "UV層数: {n}"),
    "ui.audit_deck.count.mode": ("Mode: {name}", "モード: {name}"),
})


def _suv_audit_deck_payload(context):
    ws = _suv_ws(context)
    obj = _active_mesh_obj(context)
    meshes = [o for o in (_selected_mesh_objects(context) or []) if getattr(o, 'type', None) == 'MESH']
    issue_total = _suv_cached_issue_total(ws) if '_suv_cached_issue_total' in globals() else 0
    uv_count = 0
    if obj is not None:
        try:
            uv_count = len(getattr(getattr(obj, 'data', None), 'uv_layers', []) or [])
        except Exception:
            uv_count = 0
    chips = [
        ('suv_workspace', tr(context, 'ui.audit_deck.count.meshes', n=len(meshes))),
        ('suv_ref_inspect', tr(context, 'ui.audit_deck.count.issues', n=issue_total)),
        ('suv_uvmap', tr(context, 'ui.audit_deck.count.uv', n=uv_count)),
        ('suv_workflow', tr(context, 'ui.audit_deck.count.mode', name=str(getattr(context, 'mode', 'OBJECT')))),
    ]
    summary_lines = []
    if obj is None:
        summary_lines.append(tr(context, 'ui.mode.no_mesh'))
    else:
        summary_lines.append(tr(context, 'ui.control.obj_active', name=getattr(obj, 'name', '-')))
        summary_lines.append(tr(context, 'ui.audit_deck.line.checker'))
        summary_lines.append(tr(context, 'ui.audit_deck.line.audit' if issue_total else 'ui.audit_deck.line.stretch'))

    cards = [
        (
            tr(context, 'ui.audit_deck.route.checker'),
            [tr(context, 'ui.audit_deck.line.checker')],
            ('object.suv_create_checker_material', tr(context, 'ui.audit_deck.action.checker'), 'TEXTURE', 'suv_op_checker', {}),
            'suv_op_checker',
        ),
        (
            tr(context, 'ui.audit_deck.route.stretch'),
            [tr(context, 'ui.audit_deck.line.stretch')],
            ('object.suv_visualize_stretch_heatmap', tr(context, 'ui.audit_deck.action.stretch'), 'SHADING_RENDERED', 'suv_inspect', {'assign_material': True}),
            'suv_inspect',
        ),
        (
            tr(context, 'ui.audit_deck.route.audit'),
            [tr(context, 'ui.audit_deck.line.audit')],
            ('uv.suv_issue_audit_tools', tr(context, 'ui.audit_deck.action.audit'), 'VIEWZOOM', 'suv_ref_inspect', {'mode': 'REPORT_SELECTED'}),
            'suv_ref_inspect',
        ),
        (
            tr(context, 'ui.audit_deck.route.overlay'),
            [tr(context, 'ui.audit_deck.line.overlay')],
            ('uv.suv_issue_overlay_tools', tr(context, 'ui.audit_deck.action.overlay'), 'SHADING_RENDERED', 'suv_inspect', {'mode': 'BUILD_SELECTED', 'overlay_mode': 'SEVERITY', 'assign_material': True}),
            'suv_inspect',
        ),
    ]
    return {'chips': chips, 'summary_lines': summary_lines, 'cards': cards}


def _draw_audit_deck(layout, context):
    payload = _suv_audit_deck_payload(context)
    box, col = _create_box(layout, tr(context, 'ui.section.audit_deck'), 'VIEWZOOM', 'suv_ref_inspect')
    _draw_hint(col, tr(context, 'ui.audit_deck.hint'))
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.2)
    _draw_dashboard_card(col, tr(context, 'ui.audit_deck.summary'), payload['summary_lines'], 'suv_ref_inspect', [])
    grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
    for title, lines, action, preview_icon in payload['cards']:
        op_id, op_label, fallback_icon, custom_icon, props = action
        _draw_dashboard_card(grid, title, lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    return box


_prev_draw_dashboard_v221174 = _draw_dashboard


def _draw_dashboard(layout, context):
    ws = _suv_ws(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    head = col.row(align=True)
    expanded = bool(getattr(ws, 'show_dashboard', False)) if ws else False
    from .foldout_header import draw_foldout_header
    draw_foldout_header(
        head, expanded, data=ws if ws else None, prop='show_dashboard' if ws else None,
        draw_title=lambda r: _label_with_icon(r, tr(context, 'ui.toggle.dashboard'), 'IMAGE_DATA', 'suv_workspace'))
    if not expanded:
        hint = col.row(align=True)
        hint.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        col.separator(factor=0.2)
        return
    draw_order = [
        _draw_visual_guide,
        _draw_control_center,
        _draw_mode_guard,
        _draw_risk_flags,
        _draw_workspace_rail,
        _draw_action_matrix,
        _draw_consistency_board,
        _draw_sync_deck,
        _draw_selection_scope,
        _draw_quick_launchpad,
        _draw_batch_pilot,
        _draw_library_shelf,
        _draw_reuse_deck,
        _draw_transfer_deck,
        _draw_bridge_board,
        _draw_polish_deck,
        _draw_audit_deck,
        _draw_role_switchboard,
        _draw_map_ledger,
        _draw_preset_deck,
        _draw_workflow_pulse,
        _draw_assisted_checklist,
        _draw_uv_role_board,
        _draw_finish_rail,
        _draw_review_ladder,
        _draw_delivery_gate,
        _draw_recovery_dock,
        _draw_state_snapshot,
        _draw_phase_coach,
        _draw_readiness_radar,
        _draw_next_step_advisor,
        _draw_tab_mission_brief,
        _draw_goal_paths,
        _draw_issue_solver,
        _draw_production_checkpoints,
        _draw_preset_cockpit,
        _draw_focus_lanes,
        _draw_outcome_compass,
        _draw_action_guide,
        _draw_recipe_cards,
        _draw_task_navigator,
        _draw_workspace_map,
        _draw_beginner_legend,
    ]
    for draw_fn in draw_order:
        box = draw_fn(col, context)
        if box is not None:
            col.separator(factor=0.35)


_TEXT.update({
    "ui.section.export_compass": ("Export Compass", "書き出しコンパス"),
    "ui.export_compass.hint": (
        "Read active UV, render UV, issue state and role readiness together so export or handoff decisions are easier to make without bouncing across tabs.",
        "アクティブUV、レンダーUV、問題状態、役割準備をまとめて確認し、タブを行き来せずに書き出しや引き渡し判断をしやすくします。",
    ),
    "ui.export_compass.summary": ("Export Readiness", "書き出し準備状況"),
    "ui.export_compass.route.maps": ("Review UV Maps", "UVマップ確認"),
    "ui.export_compass.route.roles": ("Prepare Role UVs", "役割UVを準備"),
    "ui.export_compass.route.pack": ("Finalize Packing", "最終パック"),
    "ui.export_compass.route.verify": ("Verify + Report", "検証 + レポート"),
    "ui.export_compass.action.maps": ("Open Maps", "Maps を開く"),
    "ui.export_compass.action.roles": ("Bake / Lightmap Prep", "Bake / Lightmap 準備"),
    "ui.export_compass.action.pack": ("Pack Pro", "Pack Pro"),
    "ui.export_compass.action.verify": ("Run Report", "レポート実行"),
    "ui.export_compass.line.maps": (
        "Check which UV layer is active and which UV layer is marked for render or export before the final handoff.",
        "最終引き渡し前に、どのUV層がアクティブで、どのUV層がレンダー・書き出し対象かを確認します。",
    ),
    "ui.export_compass.line.roles": (
        "Prepare dedicated Bake or Lightmap UVs when downstream tools need a role-specific layout instead of the working layer.",
        "下流ツールで役割専用レイアウトが必要なときは、作業層とは別に Bake / Lightmap UV を準備します。",
    ),
    "ui.export_compass.line.pack": (
        "Finish packing only after repair and role preparation so the final arrangement reflects the intended output layer.",
        "修復と役割準備の後に最終パックを行い、意図した出力層を反映した最終配置にします。",
    ),
    "ui.export_compass.line.verify": (
        "Create a texel report or rerun validation when export quality should be checked before the asset leaves the scene.",
        "アセットをシーン外へ出す前に品質確認したいときは、テクセルレポート作成や再検証を行います。",
    ),
    "ui.export_compass.count.active": ("Active UV: {name}", "アクティブUV: {name}"),
    "ui.export_compass.count.render": ("Render UV: {name}", "レンダーUV: {name}"),
    "ui.export_compass.count.issues": ("Issues: {n}", "問題数: {n}"),
    "ui.export_compass.count.roles": ("Role Slots: {n}", "役割スロット数: {n}"),
})


def _suv_export_compass_payload(context):
    ws = _suv_ws(context)
    obj = _active_mesh_obj(context)
    issue_total = _suv_cached_issue_total(ws) if '_suv_cached_issue_total' in globals() else 0
    active_name = '-'
    render_name = '-'
    uv_names = []
    try:
        if obj is not None and getattr(getattr(obj, 'data', None), 'uv_layers', None) is not None:
            uv_layers = obj.data.uv_layers
            uv_names = [uv.name for uv in uv_layers]
            if uv_layers.active:
                active_name = uv_layers.active.name
            render_uv = None
            for uv in uv_layers:
                if getattr(uv, 'active_render', False):
                    render_uv = uv
                    break
            if render_uv:
                render_name = render_uv.name
    except Exception:
        pass
    role_count = 0
    for n in uv_names:
        low = str(n).lower()
        if any(tok in low for tok in ('bake', 'light', 'atlas', 'udim')):
            role_count += 1
    chips = [
        ('suv_uvmap', tr(context, 'ui.export_compass.count.active', name=active_name)),
        ('suv_ref_bake', tr(context, 'ui.export_compass.count.render', name=render_name)),
        ('suv_ref_inspect', tr(context, 'ui.export_compass.count.issues', n=issue_total)),
        ('suv_workspace', tr(context, 'ui.export_compass.count.roles', n=role_count)),
    ]
    summary_lines = []
    if obj is None:
        summary_lines.append(tr(context, 'ui.mode.no_mesh'))
    else:
        summary_lines.append(tr(context, 'ui.control.obj_active', name=getattr(obj, 'name', '-')))
        summary_lines.append(tr(context, 'ui.export_compass.line.maps'))
        if issue_total:
            summary_lines.append(tr(context, 'ui.workflow_pulse.line.repair'))
        elif role_count <= 0:
            summary_lines.append(tr(context, 'ui.export_compass.line.roles'))
        else:
            summary_lines.append(tr(context, 'ui.export_compass.line.pack'))

    cards = [
        (
            tr(context, 'ui.export_compass.route.maps'),
            [tr(context, 'ui.export_compass.line.maps')],
            ('wm.context_set_enum', tr(context, 'ui.export_compass.action.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
            'suv_uvmap',
        ),
        (
            tr(context, 'ui.export_compass.route.roles'),
            [tr(context, 'ui.export_compass.line.roles')],
            (SUV_OT_bake_uv_prep.bl_idname, tr(context, 'ui.export_compass.action.roles'), 'RENDER_STILL', 'suv_ref_bake', {'prep_mode': 'BAKE'}),
            'suv_ref_bake',
        ),
        (
            tr(context, 'ui.export_compass.route.pack'),
            [tr(context, 'ui.export_compass.line.pack')],
            (SUV_OT_pack_pro.bl_idname, tr(context, 'ui.export_compass.action.pack'), 'PACKAGE', 'suv_ref_pack', {'engine': 'DETERMINISTIC'}),
            'suv_ref_pack',
        ),
        (
            tr(context, 'ui.export_compass.route.verify'),
            [tr(context, 'ui.export_compass.line.verify')],
            ('uv.suv_native_stage_compat_tools', tr(context, 'ui.export_compass.action.verify'), 'CHECKMARK', 'suv_ref_inspect', {'mode': 'BATCH_TEXEL_REPORT'}),
            'suv_ref_inspect',
        ),
    ]
    return {'chips': chips, 'summary_lines': summary_lines, 'cards': cards}


def _draw_export_compass(layout, context):
    payload = _suv_export_compass_payload(context)
    box, col = _create_box(layout, tr(context, 'ui.section.export_compass'), 'EXPORT', 'suv_ref_bake')
    _draw_hint(col, tr(context, 'ui.export_compass.hint'))
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.2)
    _draw_dashboard_card(col, tr(context, 'ui.export_compass.summary'), payload['summary_lines'], 'suv_ref_bake', [])
    grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
    for title, lines, action, preview_icon in payload['cards']:
        op_id, op_label, fallback_icon, custom_icon, props = action
        _draw_dashboard_card(grid, title, lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    return box


_prev_draw_dashboard_v221176 = _draw_dashboard


def _draw_dashboard(layout, context):
    ws = _suv_ws(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    head = col.row(align=True)
    expanded = bool(getattr(ws, 'show_dashboard', False)) if ws else False
    from .foldout_header import draw_foldout_header
    draw_foldout_header(
        head, expanded, data=ws if ws else None, prop='show_dashboard' if ws else None,
        draw_title=lambda r: _label_with_icon(r, tr(context, 'ui.toggle.dashboard'), 'IMAGE_DATA', 'suv_workspace'))
    if not expanded:
        hint = col.row(align=True)
        hint.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        col.separator(factor=0.2)
        return
    draw_order = [
        _draw_visual_guide,
        _draw_control_center,
        _draw_mode_guard,
        _draw_risk_flags,
        _draw_workspace_rail,
        _draw_action_matrix,
        _draw_consistency_board,
        _draw_sync_deck,
        _draw_selection_scope,
        _draw_quick_launchpad,
        _draw_batch_pilot,
        _draw_library_shelf,
        _draw_reuse_deck,
        _draw_transfer_deck,
        _draw_bridge_board,
        _draw_polish_deck,
        _draw_audit_deck,
        _draw_export_compass,
        _draw_role_switchboard,
        _draw_map_ledger,
        _draw_preset_deck,
        _draw_workflow_pulse,
        _draw_assisted_checklist,
        _draw_uv_role_board,
        _draw_finish_rail,
        _draw_review_ladder,
        _draw_delivery_gate,
        _draw_recovery_dock,
        _draw_state_snapshot,
        _draw_phase_coach,
        _draw_readiness_radar,
        _draw_next_step_advisor,
        _draw_tab_mission_brief,
        _draw_goal_paths,
        _draw_issue_solver,
        _draw_production_checkpoints,
        _draw_preset_cockpit,
        _draw_focus_lanes,
        _draw_outcome_compass,
        _draw_action_guide,
        _draw_recipe_cards,
        _draw_task_navigator,
        _draw_workspace_map,
        _draw_beginner_legend,
    ]
    for draw_fn in draw_order:
        box = draw_fn(col, context)
        if box is not None:
            col.separator(factor=0.35)


_TEXT.update({
    "ui.section.correction_deck": ("Correction Deck", "修正デッキ"),
    "ui.correction_deck.hint": (
        "Open the most common correction routes from one compact deck so scan, repair, flipped-fix and cleanup actions are easier to reach after you spot a problem.",
        "問題を見つけたあとに、検査、修復、反転修正、クリーンアップへ素早く進めるよう、よく使う修正ルートを1つのコンパクトなデッキにまとめます。",
    ),
    "ui.correction_deck.summary": ("Repair Routes", "修正ルート"),
    "ui.correction_deck.count.issues": ("Issues: {n}", "問題数: {n}"),
    "ui.correction_deck.count.mode": ("Mode: {name}", "モード: {name}"),
    "ui.correction_deck.count.uv": ("UV Layers: {n}", "UV層数: {n}"),
    "ui.correction_deck.count.meshes": ("Meshes: {n}", "メッシュ数: {n}"),
    "ui.correction_deck.route.scan": ("Scan + Report", "検査 + レポート"),
    "ui.correction_deck.route.repair": ("Auto Repair", "自動修復"),
    "ui.correction_deck.route.flipped": ("Fix Flipped", "反転修正"),
    "ui.correction_deck.route.cleanup": ("Cleanup Bridge", "クリーンアップ"),
    "ui.correction_deck.action.scan": ("Inspector Scan", "検査を実行"),
    "ui.correction_deck.action.repair": ("Workspace Auto Repair", "ワークスペース自動修復"),
    "ui.correction_deck.action.flipped": ("Fix Flipped", "反転を修正"),
    "ui.correction_deck.action.cleanup": ("Heal UV Cleanup", "Heal UV クリーンアップ"),
    "ui.correction_deck.line.scan": (
        "Run a fresh inspector scan before repair so the current issue state is read from the latest UV layout.",
        "修復前に最新の検査を行い、現在のUVレイアウトから問題状態を読み直します。",
    ),
    "ui.correction_deck.line.repair": (
        "Use automated repair when cached issues remain and you want the suite to apply its safer fix routines first.",
        "キャッシュ済み問題が残っているときに、まずツールセットの安全寄り修復ルーチンを適用したい場合に使います。",
    ),
    "ui.correction_deck.line.flipped": (
        "Fix flipped islands when mirrored or reversed UV faces remain after unwrap, transfer or pack adjustments.",
        "展開、転送、パック調整のあとに、反転またはミラーずれしたUV面が残っている場合に修正します。",
    ),
    "ui.correction_deck.line.cleanup": (
        "Open cleanup bridge tools when you need heal-oriented cleanup after inspection, transfer or batch operations.",
        "検査、転送、一括処理のあとに、Heal 系クリーンアップが必要なときに使います。",
    ),
    "ui.correction_deck.line.ready": ("Cached issues suggest repair flow is useful now.", "キャッシュ済み問題があるため、今は修復フローが有効です。"),
    "ui.correction_deck.line.clean": ("No cached issues are blocking the current UV state.", "現在のUV状態を阻害するキャッシュ済み問題はありません。"),
})


def _suv_correction_deck_payload(context):
    ws = _suv_ws(context)
    obj = _active_mesh_obj(context)
    meshes = [o for o in (_selected_mesh_objects(context) or []) if getattr(o, 'type', None) == 'MESH']
    issue_total = _suv_cached_issue_total(ws) if '_suv_cached_issue_total' in globals() else 0
    uv_count = 0
    if obj is not None:
        try:
            uv_count = len(getattr(getattr(obj, 'data', None), 'uv_layers', []) or [])
        except Exception:
            uv_count = 0
    chips = [
        ('suv_ref_inspect', tr(context, 'ui.correction_deck.count.issues', n=issue_total)),
        ('suv_workflow', tr(context, 'ui.correction_deck.count.mode', name=str(getattr(context, 'mode', 'OBJECT')))),
        ('suv_uvmap', tr(context, 'ui.correction_deck.count.uv', n=uv_count)),
        ('suv_workspace', tr(context, 'ui.correction_deck.count.meshes', n=len(meshes))),
    ]
    summary_lines = []
    if obj is None:
        summary_lines.append(tr(context, 'ui.mode.no_mesh'))
    else:
        summary_lines.append(tr(context, 'ui.control.obj_active', name=getattr(obj, 'name', '-')))
        summary_lines.append(tr(context, 'ui.correction_deck.line.ready' if issue_total else 'ui.correction_deck.line.clean'))
        summary_lines.append(tr(context, 'ui.correction_deck.line.scan'))

    cards = [
        (
            tr(context, 'ui.correction_deck.route.scan'),
            [tr(context, 'ui.correction_deck.line.scan')],
            ('uv.suv_inspector_scan', tr(context, 'ui.correction_deck.action.scan'), 'VIEWZOOM', 'suv_ref_inspect', {'include_overlap': True}),
            'suv_ref_inspect',
        ),
        (
            tr(context, 'ui.correction_deck.route.repair'),
            [tr(context, 'ui.correction_deck.line.repair')],
            ('uv.suv_workspace_auto_repair', tr(context, 'ui.correction_deck.action.repair'), 'TOOL_SETTINGS', 'suv_workspace', {}),
            'suv_workspace',
        ),
        (
            tr(context, 'ui.correction_deck.route.flipped'),
            [tr(context, 'ui.correction_deck.line.flipped')],
            ('uv.suv_inspector_fix_flipped', tr(context, 'ui.correction_deck.action.flipped'), 'FILE_REFRESH', 'suv_ref_inspect', {}),
            'suv_ref_inspect',
        ),
        (
            tr(context, 'ui.correction_deck.route.cleanup'),
            [tr(context, 'ui.correction_deck.line.cleanup')],
            ('uv.suv_cleanup_bridge', tr(context, 'ui.correction_deck.action.cleanup'), 'BRUSH_DATA', 'suv_inspector', {'mode': 'HEAL_UV'}),
            'suv_inspector',
        ),
    ]
    return {'chips': chips, 'summary_lines': summary_lines, 'cards': cards}


def _draw_correction_deck(layout, context):
    payload = _suv_correction_deck_payload(context)
    box, col = _create_box(layout, tr(context, 'ui.section.correction_deck'), 'TOOL_SETTINGS', 'suv_ref_inspect')
    _draw_hint(col, tr(context, 'ui.correction_deck.hint'))
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.2)
    _draw_dashboard_card(col, tr(context, 'ui.correction_deck.summary'), payload['summary_lines'], 'suv_ref_inspect', [])
    grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
    for title, lines, action, preview_icon in payload['cards']:
        op_id, op_label, fallback_icon, custom_icon, props = action
        _draw_dashboard_card(grid, title, lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    return box


_prev_draw_dashboard_v221177 = _draw_dashboard


def _draw_dashboard(layout, context):
    ws = _suv_ws(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    head = col.row(align=True)
    expanded = bool(getattr(ws, 'show_dashboard', False)) if ws else False
    from .foldout_header import draw_foldout_header
    draw_foldout_header(
        head, expanded, data=ws if ws else None, prop='show_dashboard' if ws else None,
        draw_title=lambda r: _label_with_icon(r, tr(context, 'ui.toggle.dashboard'), 'IMAGE_DATA', 'suv_workspace'))
    if not expanded:
        hint = col.row(align=True)
        hint.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        col.separator(factor=0.2)
        return
    draw_order = [
        _draw_visual_guide,
        _draw_control_center,
        _draw_mode_guard,
        _draw_risk_flags,
        _draw_workspace_rail,
        _draw_action_matrix,
        _draw_consistency_board,
        _draw_sync_deck,
        _draw_selection_scope,
        _draw_quick_launchpad,
        _draw_batch_pilot,
        _draw_library_shelf,
        _draw_reuse_deck,
        _draw_transfer_deck,
        _draw_bridge_board,
        _draw_polish_deck,
        _draw_audit_deck,
        _draw_correction_deck,
        _draw_export_compass,
        _draw_role_switchboard,
        _draw_map_ledger,
        _draw_preset_deck,
        _draw_workflow_pulse,
        _draw_assisted_checklist,
        _draw_uv_role_board,
        _draw_finish_rail,
        _draw_review_ladder,
        _draw_delivery_gate,
        _draw_recovery_dock,
        _draw_state_snapshot,
        _draw_phase_coach,
        _draw_readiness_radar,
        _draw_next_step_advisor,
        _draw_tab_mission_brief,
        _draw_goal_paths,
        _draw_issue_solver,
        _draw_production_checkpoints,
        _draw_preset_cockpit,
        _draw_focus_lanes,
        _draw_outcome_compass,
        _draw_action_guide,
        _draw_recipe_cards,
        _draw_task_navigator,
        _draw_workspace_map,
        _draw_beginner_legend,
    ]
    for draw_fn in draw_order:
        box = draw_fn(col, context)
        if box is not None:
            col.separator(factor=0.35)


_TEXT.update({
    "ui.section.layout_deck": ("Layout Deck", "レイアウトデッキ"),
    "ui.layout_deck.hint": (
        "Open the main packing, stacking and relayout routes from one compact deck so final arrangement work is easier to reach after unwrap or repair.",
        "展開や修復のあとに、主要なパック、スタック、再レイアウトのルートへ素早く進めるよう、最終配置作業を1つのコンパクトなデッキへまとめます。",
    ),
    "ui.layout_deck.summary": ("Layout Routes", "レイアウトルート"),
    "ui.layout_deck.count.issues": ("Issues: {n}", "問題数: {n}"),
    "ui.layout_deck.count.meshes": ("Meshes: {n}", "メッシュ数: {n}"),
    "ui.layout_deck.count.uv": ("UV Layers: {n}", "UV層数: {n}"),
    "ui.layout_deck.route.pack": ("Pack Pro", "Pack Pro"),
    "ui.layout_deck.route.stack": ("Stack Groups", "グループをスタック"),
    "ui.layout_deck.route.density": ("Density Pack", "密度優先パック"),
    "ui.layout_deck.route.relayout": ("Audit Relayout", "監査結果から再配置"),
    "ui.layout_deck.action.pack": ("Run Pack Pro", "Pack Pro を実行"),
    "ui.layout_deck.action.stack": ("Stack Grouped", "グループスタックを実行"),
    "ui.layout_deck.action.density": ("Priority Density Pack", "密度優先パックを実行"),
    "ui.layout_deck.action.relayout": ("Relayout From Audit", "監査結果から再配置"),
    "ui.layout_deck.line.pack": (
        "Use Pack Pro when shells are ready for a tighter final arrangement with current roles and spacing preserved as much as possible.",
        "現在の役割や余白をできるだけ保ちながらシェルをより詰めた最終配置へ整えたいときに Pack Pro を使います。",
    ),
    "ui.layout_deck.line.stack": (
        "Use grouped stacking when repeated or mirrored islands should share the same footprint before the last pack pass.",
        "反復アイランドやミラーアイランドを最終パック前に同じ配置へ重ねたいときに、グループスタックを使います。",
    ),
    "ui.layout_deck.line.density": (
        "Use density-aware pack when resolution priority matters and important shells should keep more texel weight during layout optimization.",
        "解像度優先度が重要で、配置最適化中も重要シェルへより多くのテクセル比重を残したいときに密度優先パックを使います。",
    ),
    "ui.layout_deck.line.relayout": (
        "Relayout from the latest audit when you want the next arrangement to start from detected issue context instead of older assumptions.",
        "古い前提ではなく最新の監査結果を基に次の配置を始めたいときに、監査結果から再配置を行います。",
    ),
    "ui.layout_deck.line.ready": ("Layout routes are ready for final arrangement work.", "最終配置へ進むレイアウトルートが利用できます。"),
    "ui.layout_deck.line.warn": ("Cached issues remain, so review scan or repair before committing the last layout pass.", "キャッシュ済み問題が残っているため、最後のレイアウト調整前に検査や修復を確認します。"),
})


def _suv_layout_deck_payload(context):
    ws = _suv_ws(context)
    obj = _active_mesh_obj(context)
    meshes = [o for o in (_selected_mesh_objects(context) or []) if getattr(o, 'type', None) == 'MESH']
    issue_total = _suv_cached_issue_total(ws) if '_suv_cached_issue_total' in globals() else 0
    uv_count = 0
    if obj is not None:
        try:
            uv_count = len(getattr(getattr(obj, 'data', None), 'uv_layers', []) or [])
        except Exception:
            uv_count = 0
    chips = [
        ('suv_ref_inspect', tr(context, 'ui.layout_deck.count.issues', n=issue_total)),
        ('suv_workspace', tr(context, 'ui.layout_deck.count.meshes', n=len(meshes))),
        ('suv_uvmap', tr(context, 'ui.layout_deck.count.uv', n=uv_count)),
    ]
    summary_lines = []
    if obj is None:
        summary_lines.append(tr(context, 'ui.mode.no_mesh'))
    else:
        summary_lines.append(tr(context, 'ui.control.obj_active', name=getattr(obj, 'name', '-')))
        summary_lines.append(tr(context, 'ui.layout_deck.line.warn' if issue_total else 'ui.layout_deck.line.ready'))
    cards = [
        (
            tr(context, 'ui.layout_deck.route.pack'),
            [tr(context, 'ui.layout_deck.line.pack')],
            ('uv.suv_pack_pro', tr(context, 'ui.layout_deck.action.pack'), 'PACKAGE', 'suv_ref_pack', {}),
            'suv_ref_pack',
        ),
        (
            tr(context, 'ui.layout_deck.route.stack'),
            [tr(context, 'ui.layout_deck.line.stack')],
            ('uv.suv_stack_grouped', tr(context, 'ui.layout_deck.action.stack'), 'DUPLICATE', 'suv_ref_pack', {}),
            'suv_ref_pack',
        ),
        (
            tr(context, 'ui.layout_deck.route.density'),
            [tr(context, 'ui.layout_deck.line.density')],
            ('uv.suv_priority_density_pack', tr(context, 'ui.layout_deck.action.density'), 'MOD_UVPROJECT', 'suv_ref_pack', {}),
            'suv_ref_pack',
        ),
        (
            tr(context, 'ui.layout_deck.route.relayout'),
            [tr(context, 'ui.layout_deck.line.relayout')],
            ('uv.suv_layout_audit_relayout', tr(context, 'ui.layout_deck.action.relayout'), 'FILE_REFRESH', 'suv_ref_pack', {}),
            'suv_ref_pack',
        ),
    ]
    return {'chips': chips, 'summary_lines': summary_lines, 'cards': cards}


def _draw_layout_deck(layout, context):
    payload = _suv_layout_deck_payload(context)
    box, col = _create_box(layout, tr(context, 'ui.section.layout_deck'), 'PACKAGE', 'suv_ref_pack')
    _draw_hint(col, tr(context, 'ui.layout_deck.hint'))
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.2)
    _draw_dashboard_card(col, tr(context, 'ui.layout_deck.summary'), payload['summary_lines'], 'suv_ref_pack', [])
    grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
    for title, lines, action, preview_icon in payload['cards']:
        op_id, op_label, fallback_icon, custom_icon, props = action
        _draw_dashboard_card(grid, title, lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    return box


_prev_draw_dashboard_v221178 = _draw_dashboard


def _draw_dashboard(layout, context):
    ws = _suv_ws(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    head = col.row(align=True)
    expanded = bool(getattr(ws, 'show_dashboard', False)) if ws else False
    from .foldout_header import draw_foldout_header
    draw_foldout_header(
        head, expanded, data=ws if ws else None, prop='show_dashboard' if ws else None,
        draw_title=lambda r: _label_with_icon(r, tr(context, 'ui.toggle.dashboard'), 'IMAGE_DATA', 'suv_workspace'))
    if not expanded:
        hint = col.row(align=True)
        hint.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        col.separator(factor=0.2)
        return
    draw_order = [
        _draw_visual_guide,
        _draw_control_center,
        _draw_mode_guard,
        _draw_risk_flags,
        _draw_workspace_rail,
        _draw_action_matrix,
        _draw_consistency_board,
        _draw_sync_deck,
        _draw_selection_scope,
        _draw_quick_launchpad,
        _draw_batch_pilot,
        _draw_library_shelf,
        _draw_reuse_deck,
        _draw_transfer_deck,
        _draw_bridge_board,
        _draw_polish_deck,
        _draw_layout_deck,
        _draw_audit_deck,
        _draw_correction_deck,
        _draw_export_compass,
        _draw_role_switchboard,
        _draw_map_ledger,
        _draw_preset_deck,
        _draw_workflow_pulse,
        _draw_assisted_checklist,
        _draw_uv_role_board,
        _draw_finish_rail,
        _draw_review_ladder,
        _draw_delivery_gate,
        _draw_recovery_dock,
        _draw_state_snapshot,
        _draw_phase_coach,
        _draw_readiness_radar,
        _draw_next_step_advisor,
        _draw_tab_mission_brief,
        _draw_goal_paths,
        _draw_issue_solver,
        _draw_production_checkpoints,
        _draw_preset_cockpit,
        _draw_focus_lanes,
        _draw_outcome_compass,
        _draw_action_guide,
        _draw_recipe_cards,
        _draw_task_navigator,
        _draw_workspace_map,
        _draw_beginner_legend,
    ]
    for draw_fn in draw_order:
        box = draw_fn(col, context)
        if box is not None:
            col.separator(factor=0.35)


# --- symmetry deck extension ------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
        bl_info['description'] = (
            'Integrated UV workflow suite with split dashboard hubs, symmetry deck, bridge/layout/correction guidance, bilingual help, QA, packing, trim, atlas, and compatibility bridges.'
        )
except Exception:
    pass

_TEXT.update({
    "ui.section.symmetry_deck": ("Symmetry Deck", "対称デッキ"),
    "ui.symmetry_deck.hint": (
        "Collect symmetry detection, UV mirroring, symmetry stacking and hotspot refill helpers in one compact stop before final cleanup or export review.",
        "最終整形や書き出し確認の前に、対称検出、UVミラー、対称スタック、ホットスポット再充填を1つのコンパクトな場所へまとめます。",
    ),
    "ui.symmetry_deck.summary": ("Symmetry Readiness", "対称準備状況"),
    "ui.symmetry_deck.count.meshes": ("Meshes: {n}", "メッシュ数: {n}"),
    "ui.symmetry_deck.count.issues": ("Issues: {n}", "問題数: {n}"),
    "ui.symmetry_deck.count.uv": ("UV Layers: {n}", "UV層数: {n}"),
    "ui.symmetry_deck.count.active": ("Active UV: {name}", "アクティブUV: {name}"),
    "ui.symmetry_deck.route.detect": ("Detect Pairs", "ペア検出"),
    "ui.symmetry_deck.route.mirror": ("Mirror UV", "UVミラー"),
    "ui.symmetry_deck.route.stack": ("Stack Symmetry", "対称スタック"),
    "ui.symmetry_deck.route.refill": ("Hotspot Refill", "ホットスポット再充填"),
    "ui.symmetry_deck.action.detect": ("Detect Symmetry", "対称を検出"),
    "ui.symmetry_deck.action.mirror": ("Mirror UV", 'ミラーUV'),
    "ui.symmetry_deck.action.stack": ("Stack by Symmetry", "対称でスタック"),
    "ui.symmetry_deck.action.refill": ("Refill Symmetry", "対称を再充填"),
    "ui.symmetry_deck.line.mesh.none": (
        "Choose a mesh before running symmetry helpers.",
        "対称補助を使う前にメッシュを選択します。",
    ),
    "ui.symmetry_deck.line.mesh.ready": (
        "A working mesh is available for symmetry helpers.",
        "対称補助に使える作業メッシュがあります。",
    ),
    "ui.symmetry_deck.line.uv.none": (
        "Prepare or sync a working UV before symmetry cleanup.",
        "対称整理の前に作業用UVを準備または同期します。",
    ),
    "ui.symmetry_deck.line.uv.ready": (
        "Working UV is ready for symmetry passes.",
        "対称処理に使える作業用UVがあります。",
    ),
    "ui.symmetry_deck.line.warn": (
        "Cached issues remain, so review scan or repair before final symmetry polish.",
        "キャッシュ済み問題が残っているため、最終的な対称整形の前に検査や修復を確認します。",
    ),
    "ui.symmetry_deck.line.ready": (
        "Symmetry routes are ready for cleanup and reuse work.",
        "対称ルートは整形や再利用作業へ進める状態です。",
    ),
    "ui.symmetry_deck.line.detect": (
        "Find likely mirrored partners first when repeated left-right shells should be aligned by relationship rather than by eye.",
        "左右で対応する反復シェルを目視ではなく関係性から揃えたいときに、まず候補ペアを検出します。",
    ),
    "ui.symmetry_deck.line.mirror": (
        "Mirror the active UV relationship when one side already represents the cleaner or approved shell state.",
        "片側がすでにより整った、または承認済みのシェル状態を表しているときに、その関係をUVへミラーします。",
    ),
    "ui.symmetry_deck.line.stack": (
        "Use symmetry-based stacking when mirrored shells should share the same footprint before the final pack.",
        "最終パック前にミラーシェルを同じ配置へ重ねたいときに、対称ベースのスタックを使います。",
    ),
    "ui.symmetry_deck.line.refill": (
        "Refill hotspot symmetry when mirrored trim or hotspot cells should regain a balanced reusable layout.",
        "ミラーされたトリムやホットスポットセルの再利用配置バランスを戻したいときに、対称再充填を使います。",
    ),
})


def _suv_symmetry_deck_payload(context):
    ws = _suv_ws(context)
    obj = _active_mesh_obj(context)
    meshes = [o for o in (_selected_mesh_objects(context) or []) if getattr(o, 'type', None) == 'MESH']
    issue_total = _suv_cached_issue_total(ws) if '_suv_cached_issue_total' in globals() else 0
    uv_name = '-'
    uv_count = 0
    if obj is not None:
        try:
            layers = getattr(getattr(obj, 'data', None), 'uv_layers', []) or []
            uv_count = len(layers)
            active = getattr(layers, 'active', None)
            if active is not None:
                uv_name = getattr(active, 'name', '-') or '-'
        except Exception:
            uv_count = 0
            uv_name = '-'
    chips = [
        ('suv_workspace', tr(context, 'ui.symmetry_deck.count.meshes', n=len(meshes))),
        ('suv_ref_inspect', tr(context, 'ui.symmetry_deck.count.issues', n=issue_total)),
        ('suv_uvmap', tr(context, 'ui.symmetry_deck.count.uv', n=uv_count)),
        ('suv_ref_symmetry', tr(context, 'ui.symmetry_deck.count.active', name=uv_name)),
    ]
    summary_lines = []
    summary_lines.append(tr(context, 'ui.symmetry_deck.line.mesh.ready' if obj is not None else 'ui.symmetry_deck.line.mesh.none'))
    summary_lines.append(tr(context, 'ui.symmetry_deck.line.uv.ready' if uv_name != '-' else 'ui.symmetry_deck.line.uv.none'))
    summary_lines.append(tr(context, 'ui.symmetry_deck.line.warn' if issue_total else 'ui.symmetry_deck.line.ready'))
    cards = [
        (
            tr(context, 'ui.symmetry_deck.route.detect'),
            [tr(context, 'ui.symmetry_deck.line.detect')],
            ('uv.suv_sym_detect_pairs', tr(context, 'ui.symmetry_deck.action.detect'), 'MOD_MIRROR', 'suv_ref_symmetry', {}),
            'suv_ref_symmetry',
        ),
        (
            tr(context, 'ui.symmetry_deck.route.mirror'),
            [tr(context, 'ui.symmetry_deck.line.mirror')],
            ('uv.suv_sym_mirror_uv', tr(context, 'ui.symmetry_deck.action.mirror'), 'MOD_MIRROR', 'suv_ref_symmetry', {}),
            'suv_ref_symmetry',
        ),
        (
            tr(context, 'ui.symmetry_deck.route.stack'),
            [tr(context, 'ui.symmetry_deck.line.stack')],
            ('uv.suv_stack_symmetry_topology', tr(context, 'ui.symmetry_deck.action.stack'), 'DUPLICATE', 'suv_ref_symmetry', {}),
            'suv_ref_symmetry',
        ),
        (
            tr(context, 'ui.symmetry_deck.route.refill'),
            [tr(context, 'ui.symmetry_deck.line.refill')],
            ('uv.suv_hotspot_symmetry_refill', tr(context, 'ui.symmetry_deck.action.refill'), 'FILE_REFRESH', 'suv_ref_symmetry', {}),
            'suv_ref_symmetry',
        ),
    ]
    return {'chips': chips, 'summary_lines': summary_lines, 'cards': cards}


def _draw_symmetry_deck(layout, context):
    payload = _suv_symmetry_deck_payload(context)
    box, col = _create_box(layout, tr(context, 'ui.section.symmetry_deck'), 'MOD_MIRROR', 'suv_ref_symmetry')
    _draw_hint(col, tr(context, 'ui.symmetry_deck.hint'))
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.0)
    col.separator(factor=0.2)
    _draw_dashboard_card(col, tr(context, 'ui.symmetry_deck.summary'), payload['summary_lines'], 'suv_ref_symmetry', [])
    grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
    for title, lines, action, preview_icon in payload['cards']:
        op_id, op_label, fallback_icon, custom_icon, props = action
        _draw_dashboard_card(grid, title, lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    return box


_prev_draw_dashboard_v221179 = _draw_dashboard


def _draw_dashboard(layout, context):
    ws = _suv_ws(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    head = col.row(align=True)
    expanded = bool(getattr(ws, 'show_dashboard', False)) if ws else False
    from .foldout_header import draw_foldout_header
    draw_foldout_header(
        head, expanded, data=ws if ws else None, prop='show_dashboard' if ws else None,
        draw_title=lambda r: _label_with_icon(r, tr(context, 'ui.toggle.dashboard'), 'IMAGE_DATA', 'suv_workspace'))
    if not expanded:
        hint = col.row(align=True)
        hint.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        col.separator(factor=0.2)
        return
    draw_order = [
        _draw_visual_guide,
        _draw_control_center,
        _draw_mode_guard,
        _draw_risk_flags,
        _draw_workspace_rail,
        _draw_action_matrix,
        _draw_consistency_board,
        _draw_sync_deck,
        _draw_selection_scope,
        _draw_quick_launchpad,
        _draw_batch_pilot,
        _draw_library_shelf,
        _draw_reuse_deck,
        _draw_transfer_deck,
        _draw_bridge_board,
        _draw_polish_deck,
        _draw_symmetry_deck,
        _draw_layout_deck,
        _draw_audit_deck,
        _draw_correction_deck,
        _draw_export_compass,
        _draw_role_switchboard,
        _draw_map_ledger,
        _draw_preset_deck,
        _draw_workflow_pulse,
        _draw_assisted_checklist,
        _draw_uv_role_board,
        _draw_finish_rail,
        _draw_review_ladder,
        _draw_delivery_gate,
        _draw_recovery_dock,
        _draw_state_snapshot,
        _draw_phase_coach,
        _draw_readiness_radar,
        _draw_next_step_advisor,
        _draw_tab_mission_brief,
        _draw_goal_paths,
        _draw_issue_solver,
        _draw_production_checkpoints,
        _draw_preset_cockpit,
        _draw_focus_lanes,
        _draw_outcome_compass,
        _draw_action_guide,
        _draw_recipe_cards,
        _draw_task_navigator,
        _draw_workspace_map,
        _draw_beginner_legend,
    ]
    for draw_fn in draw_order:
        box = draw_fn(col, context)
        if box is not None:
            col.separator(factor=0.35)
