# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations
from . import resource_api_18168 as _suv_resource

import importlib.util
import platform
import sys
import traceback
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

import bpy
from . import feature_toggle as _feature_toggle

from . import preferences_proxy, registry

_RECORDS: list[dict[str, Any]] = []
_HIDDEN_PANEL_POLLS: dict[type, object] = {}
_DETACHED_PANELS: set[type] = set()
_MISSING_POLL = object()


def clear_records() -> None:
    _RECORDS.clear()



def get_records() -> list[dict[str, Any]]:
    return list(_RECORDS)



def get_record(alias: str) -> dict[str, Any] | None:
    alias = str(alias or '').strip()
    if not alias:
        return None
    for record in _RECORDS:
        spec = record.get('spec') or {}
        if str(spec.get('alias') or '').strip() == alias:
            return record
    return None



def _root_module_prefix() -> str:
    package = str(__package__ or '').strip()
    return package or 'uv_suite'



def _platform_supported(outer_zip: str) -> bool:
    text = str(outer_zip or '').lower()
    system = platform.system().lower()
    machine = platform.machine().lower()
    if 'windows-x64' in text:
        return system == 'windows' and machine in {'amd64', 'x86_64'}
    if 'linux-x64' in text:
        return system == 'linux' and machine in {'amd64', 'x86_64'}
    if 'macos-arm64' in text:
        return system == 'darwin' and machine in {'arm64', 'aarch64'}
    if 'macos-x64' in text:
        return system == 'darwin' and machine in {'amd64', 'x86_64'}
    return True



def _module_name_for_spec(spec: dict[str, Any]) -> str:
    prefix = _root_module_prefix()
    alias = str(spec.get('alias') or 'addon').strip()
    return f'{prefix}.{alias}'


def _purge_module_tree(module_name: str) -> None:
    """Compatibility no-op: integrated modules are replaced only at their exact key."""
    del module_name
    return None



def _spec_import_paths(spec: dict[str, Any]) -> tuple[str, str, Path]:
    src_dir = Path(str(spec.get('src_dir') or ''))
    init_relpath = Path(str(spec.get('init_relpath') or ''))
    init_path = (src_dir / init_relpath).resolve() if src_dir and init_relpath else Path()
    module_name = _module_name_for_spec(spec)
    package_dir = init_path.parent if init_path.name == '__init__.py' else src_dir
    return module_name, str(init_path), package_dir



def _load_module_from_spec(spec: dict[str, Any]):
    module_name, init_path_str, package_dir = _spec_import_paths(spec)
    if not init_path_str:
        raise FileNotFoundError('init_relpath is empty')
    init_path = Path(init_path_str)
    if not init_path.exists():
        raise FileNotFoundError(f'Missing init file: {init_path}')

    _purge_module_tree(module_name)
    spec_obj = importlib.util.spec_from_file_location(
        module_name,
        str(init_path),
        submodule_search_locations=[str(package_dir)],
    )
    if spec_obj is None or spec_obj.loader is None:
        raise ImportError(f'Failed to create module spec for {init_path}')
    module = importlib.util.module_from_spec(spec_obj)
    sys.modules[module_name] = module

    spec_obj.loader.exec_module(module)
    return module



def _legacy_ui_noop(*_args, **_kwargs):
    return None



def _iter_legacy_ui_owners() -> list[type]:
    """Legacy UI hook suppression was removed to avoid process-global patches."""
    return []




def _patch_callable_attr(owner: object, attr_name: str, replacement, patched: list[tuple[object, str, object]]) -> None:
    del owner, attr_name, replacement, patched
    return None


@contextmanager
def _suppress_legacy_ui_hooks() -> Iterator[None]:
    yield



def _capture_registered_classes(callable_obj):
    """Call the tool register function and collect classes defined by its module.

    This avoids replacing bpy.utils.register_class.  Integrated tools that need
    registration are expected to expose normal classes in their module globals.
    """
    module_name = str(getattr(callable_obj, '__module__', '') or '')
    module = sys.modules.get(module_name)
    before = set()
    try:
        before = {id(v) for v in vars(module).values() if isinstance(v, type)} if module is not None else set()
    except Exception:
        before = set()
    callable_obj()
    captured: list[type] = []
    try:
        values = tuple(vars(module).values()) if module is not None else ()
    except Exception:
        values = ()
    for value in values:
        if not isinstance(value, type):
            continue
        try:
            if str(getattr(value, '__module__', '') or '') != module_name:
                continue
        except Exception:
            continue
        try:
            from . import text_translation as _text_translation
            sanitize_class = getattr(_text_translation, 'sanitize_class', None)
            if callable(sanitize_class):
                sanitize_class(value, context=getattr(bpy, 'context', None))
        except Exception:
            pass
        captured.append(value)
    return captured



def _categorize_classes(classes: list[type]) -> tuple[list[type], list[type], list[type], list[type]]:
    panels: list[type] = []
    operators: list[type] = []
    menus: list[type] = []
    prefs: list[type] = []
    panel_base = getattr(bpy.types, 'Panel', None)
    operator_base = getattr(bpy.types, 'Operator', None)
    menu_base = getattr(bpy.types, 'Menu', None)
    prefs_base = getattr(bpy.types, 'AddonPreferences', None)
    for cls in classes:
        try:
            if panel_base is not None and isinstance(cls, type) and issubclass(cls, panel_base):
                panels.append(cls)
                continue
        except Exception:
            pass
        try:
            if operator_base is not None and isinstance(cls, type) and issubclass(cls, operator_base):
                operators.append(cls)
                continue
        except Exception:
            pass
        try:
            if menu_base is not None and isinstance(cls, type) and issubclass(cls, menu_base):
                menus.append(cls)
                continue
        except Exception:
            pass
        try:
            if prefs_base is not None and isinstance(cls, type) and issubclass(cls, prefs_base):
                prefs.append(cls)
                continue
        except Exception:
            pass
    return panels, operators, menus, prefs



def _hide_original_panels(panels: list[type]) -> None:
    # Never replace Panel.poll on a class not explicitly owned by this ledger.
    del panels
    return None


def _restore_hidden_panels() -> None:
    _HIDDEN_PANEL_POLLS.clear()
    return None


def _safe_unregister_class_tool_runtime(cls: type) -> bool:
    try:
        removed = bool(_suv_resource.unregister_class(cls))
    except Exception:
        removed = False
    if removed:
        _DETACHED_PANELS.add(cls)
    return removed



def _detach_original_panels(panels: list[type]) -> None:
    # Exact identity only.  Classes that were not created through the Smart UV
    # ownership ledger remain untouched and visible to their original owner.
    for cls in reversed(tuple(panels)):
        if cls not in _DETACHED_PANELS:
            _safe_unregister_class_tool_runtime(cls)


def _call_unregister_safely(callable_obj):
    try:
        return callable_obj()
    except Exception:
        return None



def _supported_status_for_spec(spec: dict[str, Any]) -> str:
    load_flag = bool(spec.get('load', True))
    if not load_flag:
        return 'disabled'
    if not _platform_supported(str(spec.get('outer_zip') or '')):
        return 'unsupported_platform'
    return 'standby'



def _blank_record(spec: dict[str, Any]) -> dict[str, Any]:
    return {
        'spec': spec,
        'status': _supported_status_for_spec(spec),
        'module': None,
        'registered_classes': [],
        'proxy_panels': [],
        'panels': [],
        'operators': [],
        'menus': [],
        'preferences': [],
        'error': '',
    }



def _reset_tool_runtime_payload(record: dict[str, Any]) -> None:
    record['module'] = None
    record['registered_classes'] = []
    record['proxy_panels'] = []
    record['panels'] = []
    record['operators'] = []
    record['menus'] = []
    record['preferences'] = []
    record['error'] = ''



def register_all(*, autoload: bool = False) -> list[dict[str, Any]]:
    """Build the integrated-tool registry without loading tools by default.

    Non-persistent integrated tools stay in a UI-only standby state until the
    user explicitly initializes or runs them. This keeps Blender startup and
    N-panel drawing light while preserving the full tool surface.
    """
    try:
        _feature_toggle.register_ui()
    except Exception:
        pass
    specs = registry.build_specs(force=False)
    existing_by_alias: dict[str, dict[str, Any]] = {}
    for record in list(_RECORDS):
        spec = record.get('spec') or {}
        alias = str(spec.get('alias') or '').strip()
        if alias:
            existing_by_alias[alias] = record

    next_records: list[dict[str, Any]] = []
    for spec in specs:
        alias = str(spec.get('alias') or '').strip()
        record = existing_by_alias.get(alias)
        if isinstance(record, dict):
            record['spec'] = dict(spec)
            if str(record.get('status') or '').strip() in {'', 'disabled', 'unsupported_platform'}:
                record['status'] = _supported_status_for_spec(spec)
            next_records.append(record)
        else:
            next_records.append(_blank_record(spec))

    _RECORDS[:] = next_records
    if autoload:
        for record in list(_RECORDS):
            alias = str((record.get('spec') or {}).get('alias') or '')
            if alias:
                load_record(alias)
    return get_records()

def load_record(alias: str) -> dict[str, Any] | None:
    record = get_record(alias)
    if record is None:
        return None

    status = str(record.get('status') or '')
    if status == 'loaded':
        return record
    if status in {'disabled', 'unsupported_platform'}:
        return record

    spec = record.get('spec') or {}
    _reset_tool_runtime_payload(record)
    record['status'] = 'loading'
    module = None
    captured: list[type] = []
    try:
        module = _load_module_from_spec(spec)
        record['module'] = module
        register_fn = getattr(module, 'register', None)
        _ft_alias = str((spec.get('alias') if isinstance(spec, dict) else '') or globals().get('alias', '') or 'integrated_tool').strip()
        _ft_label = str((spec.get('display_name') if isinstance(spec, dict) else '') or _ft_alias or 'Integrated Tool').strip()
        with _feature_toggle.capture_tool_runtime(_ft_alias, _ft_label):
            if callable(register_fn):
                captured = _capture_registered_classes(register_fn)
        panels, operators, menus, prefs = _categorize_classes(captured)
        record['registered_classes'] = list(captured)
        record['panels'] = list(panels)
        record['operators'] = list(operators)
        record['menus'] = list(menus)
        record['preferences'] = list(prefs)
        try:
            preferences_proxy.ensure_proxies_for_classes(prefs)
        except Exception:
            pass
        _detach_original_panels(panels)
        record['status'] = 'loaded'
        return record
    except Exception as exc:
        record['status'] = 'failed'
        record['error'] = f'{exc}\n{traceback.format_exc()}'
        if module is not None:
            try:
                unregister_fn = getattr(module, 'unregister', None)
                if callable(unregister_fn):
                    _call_unregister_safely(unregister_fn)
            except Exception:
                pass
        record['module'] = None
        return record



def unload_record(alias: str) -> dict[str, Any] | None:
    record = get_record(alias)
    if record is None:
        return None

    module = record.get('module')
    if module is not None:
        try:
            unregister_fn = getattr(module, 'unregister', None)
            if callable(unregister_fn):
                _call_unregister_safely(unregister_fn)
        except Exception:
            pass

    _reset_tool_runtime_payload(record)
    record['status'] = _supported_status_for_spec(record.get('spec') or {})
    return record



def unregister_all() -> None:
    try:
        preferences_proxy.save_all_proxy_values(getattr(bpy, 'context', None))
    except Exception:
        pass
    try:
        _feature_toggle.unregister_all()
    except Exception:
        pass
    for record in reversed(_RECORDS):
        spec = record.get('spec') or {}
        alias = str(spec.get('alias') or '').strip()
        if alias:
            try:
                unload_record(alias)
            except Exception:
                pass
    _restore_hidden_panels()
    _DETACHED_PANELS.clear()
    clear_records()
    registry.clear_cache()
