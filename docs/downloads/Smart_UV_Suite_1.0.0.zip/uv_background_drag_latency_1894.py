# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Latency-free UV Editor background drag handoff.

Smart UV Suite's Immediate Select uses LEFTMOUSE/PRESS so it can select an
unselected UV element before the held drag starts.  That operator must not run a
BMesh hit scan when the user is starting a Blender-native background drag such as
UV Cursor movement, Select Box, Lasso Select, Circle Select, or a transform tool
background gesture.  This layer removes Immediate Select from those native tool
keymaps, keeps it only in the UV Tweak keymap, and adds a no-build cache guard so
any stale/broad keymap row passes through without blocking the press.
"""
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

from typing import Any, Callable
import math
import time

import bpy

_VERSION = (1, 8, 94)
_INSTANT_ID = "smart_uv_suite.instant_select_drag_move"
_PG: dict[str, Any] | None = None
_INSTALLED = False
_REFRESH_PENDING = False
_LAST_REFRESH_REQUEST = 0.0
_LAST_BUILD = 0.0
_MIN_BUILD_INTERVAL = 0.20

_TWEAK_KEYMAP_DEFS: tuple[tuple[str, str], ...] = (
    ("Image Editor Tool: Uv, Tweak", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Tweak (fallback)", "IMAGE_EDITOR"),
)

_PURGE_KEYMAP_NAMES: tuple[str, ...] = (
    "Window",
    "Image",
    "Image Generic",
    "UV Editor",
    "Generic Gizmo",
    "Generic Gizmo Drag",
    "Generic Gizmo Click Drag",
    "Generic Gizmo Maybe Drag",
    "Generic Gizmo Select",
    "Image Editor Tool: Uv, Move",
    "Image Editor Tool: Uv, Move (fallback)",
    "Image Editor Tool: Uv, Rotate",
    "Image Editor Tool: Uv, Rotate (fallback)",
    "Image Editor Tool: Uv, Scale",
    "Image Editor Tool: Uv, Scale (fallback)",
    "Image Editor Tool: Uv, Transform",
    "Image Editor Tool: Uv, Transform (fallback)",
    "Image Editor Tool: Uv, Cursor",
    "Image Editor Tool: Uv, Cursor (fallback)",
    "Image Editor Tool: Uv, Select Box",
    "Image Editor Tool: Uv, Select Box (fallback)",
    "Image Editor Tool: Uv, Select Lasso",
    "Image Editor Tool: Uv, Select Lasso (fallback)",
    "Image Editor Tool: Uv, Select Circle",
    "Image Editor Tool: Uv, Select Circle (fallback)",
)

_NATIVE_BACKGROUND_TOOL_IDS: set[str] = {
    "builtin.cursor",
    "builtin.select_box",
    "builtin.select_lasso",
    "builtin.select_circle",
    "builtin.move",
    "builtin.rotate",
    "builtin.scale",
    "builtin.transform",
    "builtin.annotate",
    "builtin.annotate_line",
    "builtin.annotate_polygon",
    "builtin.annotate_eraser",
}
_NATIVE_BACKGROUND_TOOL_TOKENS: tuple[str, ...] = (
    "cursor",
    "select_box",
    "select_lasso",
    "select_circle",
    "move",
    "rotate",
    "scale",
    "transform",
    "annotate",
)
_ALLOWED_IMMEDIATE_TOOL_IDS: set[str] = {"builtin.select", "builtin.tweak"}
_ORIGINAL_INVOKES: dict[type, Callable[..., Any]] = {}
_ORIGINAL_FINDERS: dict[str, Callable[..., Any] | None] = {}
_ORIGINAL_REAPPLY_HOOKS: dict[str, Callable[..., Any]] = {}


def _as_text(value: Any) -> str:
    try:
        return str(value or "")
    except Exception:
        return ""


def _addon_keyconfig():
    try:
        return bpy.context.window_manager.keyconfigs.addon
    except Exception:
        return None


def _find_kmis(km: Any, idname: str) -> list[Any]:
    try:
        from . import ownership_runtime_18168 as _ownership
        return [kmi for keymap, kmi in _ownership.owned_keymap_items(idname) if keymap is km]
    except Exception:
        return []


def _get_keymap(kc: Any, name: str, space_type: str):
    try:
        km = kc.keymaps.get(name)
        if km is None:
            km = kc.keymaps.new(name=name, space_type=space_type, region_type="WINDOW")
        return km
    except Exception:
        return None


def _configure_left_press(kmi: Any, active: bool = True) -> None:
    try:
        _suv_resource.keymap_item_set(kmi, 'type', 'LEFTMOUSE')
        _suv_resource.keymap_item_set(kmi, 'value', 'PRESS')
    except Exception:
        pass
    for name in ("shift", "ctrl", "alt", "oskey", "hyper"):
        try:
            _suv_resource.keymap_item_set(kmi, name, False)
        except Exception:
            pass
    try:
        _suv_resource.keymap_item_set(kmi, 'any', False)
    except Exception:
        pass
    try:
        __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, bool(active))
    except Exception:
        pass


def _delete_rows_for_id_from_maps(idname: str, map_names: tuple[str, ...] | list[str] | set[str]) -> int:
    kc = _addon_keyconfig()
    if kc is None:
        return 0
    removed = 0
    for name in tuple(map_names):
        try:
            km = kc.keymaps.get(name)
            if km is None:
                continue
            for kmi in list(_find_kmis(km, idname)):
                try:
                    __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(km, kmi)
                    removed += 1
                except Exception:
                    try:
                        __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, False)
                    except Exception:
                        pass
        except Exception:
            continue
    return removed


def _delete_rows_for_id_all(idname: str) -> int:
    kc = _addon_keyconfig()
    if kc is None:
        return 0
    removed = 0
    try:
        for km in list(kc.keymaps):
            for kmi in list(_find_kmis(km, idname)):
                try:
                    __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(km, kmi)
                    removed += 1
                except Exception:
                    try:
                        __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, False)
                    except Exception:
                        pass
    except Exception:
        pass
    return removed


def _instant_enabled(context: Any | None = None) -> bool:
    ctx = context or getattr(bpy, "context", None)
    try:
        if isinstance(_PG, dict):
            fn = _PG.get("_sus_1635_immediate_enabled")
            if callable(fn):
                return bool(fn(ctx))
    except Exception:
        pass
    try:
        ws = None
        if isinstance(_PG, dict):
            ws_fn = _PG.get("_sus_1652_ws")
            if callable(ws_fn):
                ws = ws_fn(ctx)
        if ws is None:
            ws = getattr(getattr(ctx, "scene", None), "suv_workspace", None)
        return bool(getattr(ws, "operation_instant_select_enabled", False))
    except Exception:
        return False


def _ensure_latency_free_keymaps(active: bool = True) -> tuple[int, int]:
    kc = _addon_keyconfig()
    if kc is None:
        return 0, 0
    _delete_rows_for_id_from_maps(_INSTANT_ID, _PURGE_KEYMAP_NAMES)
    created = 0
    touched = 0
    for name, space_type in _TWEAK_KEYMAP_DEFS:
        km = _get_keymap(kc, name, space_type)
        if km is None:
            continue
        items = list(_find_kmis(km, _INSTANT_ID))
        if not items:
            kmi = None
            try:
                kmi = __import__(__package__ + '.ownership_runtime_18168', fromlist=['new_keymap_item']).new_keymap_item(km, _INSTANT_ID, type="LEFTMOUSE", value="PRESS", head=True)
            except TypeError:
                try:
                    kmi = __import__(__package__ + '.ownership_runtime_18168', fromlist=['new_keymap_item']).new_keymap_item(km, _INSTANT_ID, type="LEFTMOUSE", value="PRESS")
                except Exception:
                    kmi = None
            if kmi is not None:
                items = [kmi]
                created += 1
        for extra in items[1:]:
            try:
                __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(km, extra)
            except Exception:
                try:
                    __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(extra, False)
                except Exception:
                    pass
        for kmi in items[:1]:
            _configure_left_press(kmi, active=active)
            touched += 1
    return created, touched


def _set_latency_keymaps_active(active: bool, context: Any | None = None) -> tuple[int, int]:
    if active:
        return _ensure_latency_free_keymaps(True)
    _delete_rows_for_id_from_maps(_INSTANT_ID, _PURGE_KEYMAP_NAMES)
    touched = 0
    kc = _addon_keyconfig()
    if kc is None:
        return 0, 0
    for name, _space_type in _TWEAK_KEYMAP_DEFS:
        try:
            km = kc.keymaps.get(name)
            if km is None:
                continue
            for kmi in _find_kmis(km, _INSTANT_ID):
                try:
                    __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, False)
                    touched += 1
                except Exception:
                    pass
        except Exception:
            continue
    return 0, touched


def _delete_latency_keymaps() -> int:
    return _delete_rows_for_id_all(_INSTANT_ID)


def _is_uv_context(context: Any) -> bool:
    try:
        area = getattr(context, "area", None)
        region = getattr(context, "region", None)
        space = getattr(context, "space_data", None)
        if _as_text(getattr(area, "type", "")) != "IMAGE_EDITOR":
            return False
        if _as_text(getattr(region, "type", "")) != "WINDOW":
            return False
        mode = _as_text(getattr(space, "ui_type", "") or getattr(space, "mode", "")).upper() if space is not None else ""
        return mode in {"UV", "UV_EDITOR", ""} or _as_text(getattr(space, "mode", "")).upper() == "UV"
    except Exception:
        return False


def _active_uv_tool_id(context: Any) -> str:
    for ctx in (context, getattr(bpy, "context", None)):
        try:
            workspace = getattr(ctx, "workspace", None)
            tools = getattr(workspace, "tools", None) if workspace is not None else None
            if tools is None:
                continue
            for args, kwargs in ((("UV",), {"create": False}), (("IMAGE_EDITOR",), {"create": False}), (("UV",), {}), ((), {})):
                try:
                    tool = tools.from_space_image_mode(*args, **kwargs)
                except TypeError:
                    try:
                        tool = tools.from_space_image_mode(*args)
                    except Exception:
                        tool = None
                except Exception:
                    tool = None
                tid = _as_text(getattr(tool, "idname", "")) if tool is not None else ""
                if tid:
                    return tid
        except Exception:
            continue
    return ""


def _native_background_tool_active(context: Any) -> bool:
    tid = _active_uv_tool_id(context).strip().lower()
    if not tid or tid in _ALLOWED_IMMEDIATE_TOOL_IDS:
        return False
    if tid in _NATIVE_BACKGROUND_TOOL_IDS:
        return True
    return any(token in tid for token in _NATIVE_BACKGROUND_TOOL_TOKENS)


def _should_pass_native_without_hit_scan(context: Any, event: Any) -> bool:
    try:
        if _as_text(getattr(event, "type", "")) != "LEFTMOUSE":
            return False
        if _as_text(getattr(event, "value", "")) != "PRESS":
            return False
        if not _is_uv_context(context):
            return False
        if bool(getattr(event, "shift", False) or getattr(event, "ctrl", False) or getattr(event, "alt", False) or getattr(event, "oskey", False)):
            return True
        return _native_background_tool_active(context)
    except Exception:
        return False


def _i44():
    try:
        from . import interaction_1844 as module
        if isinstance(_PG, dict):
            try:
                module._PG = _PG
            except Exception:
                pass
        return module
    except Exception:
        return None


def _i45():
    try:
        from . import interaction_1845 as module
        if isinstance(_PG, dict):
            try:
                module._PG = _PG
            except Exception:
                pass
        return module
    except Exception:
        return None


def _is_finite_positive(value: Any) -> bool:
    try:
        value = float(value)
        return math.isfinite(value) and value > 0.0
    except Exception:
        return False


def _safe_positive(value: Any, fallback: float = 1.0e-3) -> float:
    try:
        value = float(value)
        if math.isfinite(value) and value > 0.0:
            return value
    except Exception:
        pass
    return float(fallback)


def _uv_tolerance(context: Any, pixels: float = 10.0) -> float:
    for module in (_i44(), _i45()):
        fn = getattr(module, "_uv_tolerance", None) if module is not None else None
        try:
            if callable(fn):
                value = float(fn(context, pixels))
                if math.isfinite(value) and value > 0.0:
                    return value
        except Exception:
            pass
    try:
        region = getattr(context, "region", None)
        view2d = getattr(region, "view2d", None)
        if view2d is not None:
            x0, y0 = view2d.region_to_view(0.0, 0.0)
            x1, y1 = view2d.region_to_view(float(pixels), float(pixels))
            value = max(abs(float(x1) - float(x0)), abs(float(y1) - float(y0)), 1.0e-8)
            if math.isfinite(value) and value > 0.0:
                return value
    except Exception:
        pass
    return 1.0e-3


def _cache_signature(context: Any, cell: float):
    module = _i44()
    fn = getattr(module, "_cache_signature", None) if module is not None else None
    try:
        return fn(context, cell) if callable(fn) else None
    except Exception:
        return None


def _cache_is_ready(context: Any) -> bool:
    module = _i44()
    if module is None:
        return False
    try:
        cache = getattr(module, "_HIT_CACHE", None)
        if not isinstance(cache, dict) or not cache:
            return False
        if getattr(module, "_DIRTY_MESH_IDS", set()):
            return False
        tol = _uv_tolerance(context, 10.0)
        cell = max(_safe_positive(tol, 1.0e-3) * 4.0, 1.0e-5)
        cached_cell = float(cache.get("cell", -1.0))
        if not math.isfinite(cached_cell) or not math.isfinite(cell) or cell <= 0.0:
            return False
        if abs(cached_cell - cell) > max(1.0e-8, abs(cell) * 1.0e-5):
            return False
        sig = _cache_signature(context, cell)
        return sig is not None and cache.get("sig") == sig
    except Exception:
        return False


def _find_hit_cached_only(context: Any, event: Any):
    if not _is_uv_context(context):
        return None
    if not _cache_is_ready(context):
        _schedule_cache_refresh(0.18)
        return None
    module = _i44()
    if module is None:
        return None
    fn = _ORIGINAL_FINDERS.get(f"{module.__name__}._find_uv_hit_fast")
    if not callable(fn) or fn is _find_hit_cached_only:
        fn = getattr(module, "_find_uv_hit_fast", None)
    if not callable(fn) or fn is _find_hit_cached_only:
        return None
    try:
        return fn(context, event)
    except Exception:
        return None


def _iter_uv_editor_overrides():
    try:
        wm = getattr(bpy.context, "window_manager", None)
        windows = list(getattr(wm, "windows", []) or []) if wm is not None else []
    except Exception:
        windows = []
    for window in windows:
        try:
            screen = getattr(window, "screen", None)
            areas = list(getattr(screen, "areas", []) or []) if screen is not None else []
        except Exception:
            continue
        for area in areas:
            try:
                if _as_text(getattr(area, "type", "")) != "IMAGE_EDITOR":
                    continue
                region = None
                for r in list(getattr(area, "regions", []) or []):
                    if _as_text(getattr(r, "type", "")) == "WINDOW":
                        region = r
                        break
                if region is None:
                    continue
                space = getattr(getattr(area, "spaces", None), "active", None)
                if space is None or _as_text(getattr(space, "type", "")) != "IMAGE_EDITOR":
                    continue
                mode = _as_text(getattr(space, "ui_type", "") or getattr(space, "mode", "")).upper()
                if mode not in {"UV", "UV_EDITOR", ""} and _as_text(getattr(space, "mode", "")).upper() != "UV":
                    continue
                yield window, screen, area, region, space
            except Exception:
                continue


def _has_edit_mesh(context: Any) -> bool:
    try:
        objs = getattr(context, "objects_in_mode_unique_data", None)
        if objs:
            return any(getattr(obj, "type", None) == "MESH" and getattr(obj, "mode", None) == "EDIT" for obj in objs)
    except Exception:
        pass
    try:
        obj = getattr(context, "edit_object", None) or getattr(context, "object", None)
        return bool(obj is not None and getattr(obj, "type", None) == "MESH" and getattr(obj, "mode", None) == "EDIT")
    except Exception:
        return False


def _smartuv_native_transform_modal_active_1894(context: Any | None = None) -> bool:
    """Return True while Blender's native transform modal is the live WM owner.

    The background-hit cache is useful before an Immediate Select press, but it
    must not rebuild edit BMesh data while Blender owns an active native
    G/R/S transform modal.  ``WindowManager.operators`` is append-only enough to
    retain historical transform entries, so only the current tail run is
    considered active; a later non-transform operator releases the guard and the
    next normal selection path may schedule a fresh cache rebuild.
    """
    for ctx in (context, getattr(bpy, "context", None)):
        try:
            wm = getattr(ctx, "window_manager", None)
            operators = list(getattr(wm, "operators", []) or []) if wm is not None else []
        except Exception:
            operators = []
        if not operators:
            continue
        try:
            last = operators[-1]
            ident = _as_text(getattr(last, "bl_idname", "") or getattr(last, "idname", "") or type(last).__name__)
            return ident.startswith("TRANSFORM_OT_")
        except Exception:
            continue
    return False


def _build_cache_for_context(context: Any) -> bool:
    global _LAST_BUILD
    module = _i44()
    if module is None or not _is_uv_context(context) or not _has_edit_mesh(context):
        return False
    if _smartuv_native_transform_modal_active_1894(context):
        return False
    now = time.monotonic()
    if now - float(_LAST_BUILD) < _MIN_BUILD_INTERVAL and _cache_is_ready(context):
        return True
    try:
        fn = getattr(module, "_get_hit_cache", None)
        if not callable(fn):
            return False
        tol = _safe_positive(_uv_tolerance(context, 10.0), 1.0e-3)
        fn(context, tol)
        _LAST_BUILD = now
        return _cache_is_ready(context)
    except Exception:
        return False


def _refresh_cache_timer():
    global _REFRESH_PENDING
    _REFRESH_PENDING = False
    if _smartuv_native_transform_modal_active_1894(bpy.context):
        return None
    try:
        for window, screen, area, region, space in _iter_uv_editor_overrides():
            try:
                with bpy.context.temp_override(window=window, screen=screen, area=area, region=region, space_data=space):
                    if _smartuv_native_transform_modal_active_1894(bpy.context):
                        continue
                    if _build_cache_for_context(bpy.context):
                        return None
            except Exception:
                continue
        try:
            _build_cache_for_context(bpy.context)
        except Exception:
            pass
    except Exception:
        pass
    return None


def _schedule_cache_refresh(delay: float = 0.12) -> None:
    global _REFRESH_PENDING, _LAST_REFRESH_REQUEST
    now = time.monotonic()
    if _REFRESH_PENDING and now - float(_LAST_REFRESH_REQUEST) < 0.75:
        return
    _REFRESH_PENDING = True
    _LAST_REFRESH_REQUEST = now
    try:
        timers = getattr(getattr(bpy, "app", None), "timers", None)
        if timers is not None and hasattr(timers, "is_registered") and timers.is_registered(_refresh_cache_timer):
            return
        _suv_resource.timer_register(_refresh_cache_timer, first_interval=max(0.05, float(delay)))
    except Exception:
        _REFRESH_PENDING = False


def _make_latency_guarded_invoke(original: Callable[..., Any]) -> Callable[..., Any]:
    def _instant_invoke_latency_guard_1894(self, context, event):
        try:
            if _should_pass_native_without_hit_scan(context, event):
                return {"PASS_THROUGH"}
            if _as_text(getattr(event, "type", "")) == "LEFTMOUSE" and _as_text(getattr(event, "value", "")) == "PRESS" and _is_uv_context(context):
                if not _cache_is_ready(context):
                    _schedule_cache_refresh(0.18)
                    return {"PASS_THROUGH"}
        except Exception:
            return {"PASS_THROUGH"}
        try:
            return original(self, context, event)
        except Exception:
            return {"PASS_THROUGH"}

    try:
        _instant_invoke_latency_guard_1894._sus_1894_latency_guard = True
        _instant_invoke_latency_guard_1894._sus_1894_original = original
    except Exception:
        pass
    return _instant_invoke_latency_guard_1894


def _patch_instant_class(package_globals: dict[str, Any] | None = None) -> None:
    cls = None
    try:
        if isinstance(package_globals, dict):
            cls = package_globals.get("SMARTUVSUITE_OT_instant_select_drag_move")
    except Exception:
        cls = None
    if not isinstance(cls, type):
        try:
            import sys
            pkg = sys.modules.get(__package__)
            cls = getattr(pkg, "SMARTUVSUITE_OT_instant_select_drag_move", None)
        except Exception:
            cls = None
    if not isinstance(cls, type):
        return
    try:
        current = getattr(cls, "invoke", None)
        if getattr(current, "_sus_1894_latency_guard", False):
            return
        if callable(current):
            _ORIGINAL_INVOKES.setdefault(cls, current)
            cls.invoke = _make_latency_guarded_invoke(current)
            cls._sus1894_background_drag_latency_guard = True
    except Exception:
        pass



def _infer_context_from_call(args: tuple[Any, ...], kwargs: dict[str, Any]) -> Any:
    for key in ("context", "ctx"):
        ctx = kwargs.get(key)
        if ctx is not None:
            return ctx
    for value in args[1:]:
        try:
            if hasattr(value, "window_manager") or hasattr(value, "scene") or hasattr(value, "area"):
                return value
        except Exception:
            continue
    return getattr(bpy, "context", None)


def _infer_package_globals_from_call(args: tuple[Any, ...], fallback: dict[str, Any] | None = None) -> dict[str, Any] | None:
    if args and isinstance(args[0], dict):
        return args[0]
    if isinstance(fallback, dict):
        return fallback
    if isinstance(_PG, dict):
        return _PG
    try:
        import sys
        pkg = sys.modules.get(__package__)
        dct = getattr(pkg, "__dict__", None)
        return dct if isinstance(dct, dict) else None
    except Exception:
        return None


def _reassert_latency_after_legacy(package_globals: dict[str, Any] | None = None, context: Any | None = None) -> None:
    """Restore the 1.8.94 event path after older interaction layers reapply.

    Several historical interaction modules still expose apply/sync functions that
    rewrite the Immediate Select invoke handler and broad keymap rows.  This
    function is deliberately small and non-recursive: it restores cached-only hit
    lookup, the guarded invoke callback, the Tweak-only keymaps, and the package
    sync export without calling those legacy apply functions again.
    """
    global _PG
    if isinstance(package_globals, dict):
        _PG = package_globals
    pg = package_globals if isinstance(package_globals, dict) else _PG
    ctx = context or getattr(bpy, "context", None)
    try:
        # Re-apply module level exports/finder replacements.  This routine also
        # leaves already wrapped apply/sync hooks untouched.
        _patch_interaction_modules(pg)
    except RecursionError:
        pass
    except Exception:
        pass
    try:
        _patch_instant_class(pg)
    except Exception:
        pass
    try:
        _set_latency_keymaps_active(_instant_enabled(ctx), ctx)
    except Exception:
        pass
    try:
        if isinstance(pg, dict):
            _patch_keymap_sync(pg)
    except Exception:
        pass
    try:
        _mark_version(pg)
    except Exception:
        pass


def _wrap_legacy_reapply_function(mod: Any, attr: str, package_globals: dict[str, Any] | None = None) -> None:
    try:
        current = getattr(mod, attr, None)
    except Exception:
        return
    if not callable(current) or getattr(current, "_sus_1894_reapply_hook", False):
        return
    key = f"{getattr(mod, '__name__', repr(mod))}.{attr}"
    _ORIGINAL_REAPPLY_HOOKS.setdefault(key, current)

    def _wrapped_legacy_reapply_1894(*args, **kwargs):
        result = None
        exc: BaseException | None = None
        try:
            result = current(*args, **kwargs)
        except BaseException as error:  # keep Blender's original error behavior
            exc = error
        try:
            pg = _infer_package_globals_from_call(args, package_globals)
            ctx = _infer_context_from_call(args, kwargs)
            _reassert_latency_after_legacy(pg, ctx)
        except Exception:
            pass
        if exc is not None:
            raise exc
        return result

    try:
        _wrapped_legacy_reapply_1894._sus_1894_reapply_hook = True
        _wrapped_legacy_reapply_1894._sus_1894_original = current
    except Exception:
        pass
    try:
        setattr(mod, attr, _wrapped_legacy_reapply_1894)
    except Exception:
        pass


def _patch_legacy_reapply_hooks(mod: Any, package_globals: dict[str, Any] | None = None) -> None:
    for attr in ("apply_all", "_sync"):
        _wrap_legacy_reapply_function(mod, attr, package_globals)

def _patch_interaction_modules(package_globals: dict[str, Any] | None = None) -> None:
    for modname in ("interaction_1871", "interaction_1865", "interaction_1845", "interaction_1844"):
        try:
            mod = __import__(f"{__package__}.{modname}", fromlist=["dummy"])
        except Exception:
            continue
        _patch_legacy_reapply_hooks(mod, package_globals)
        for attr, value in (
            ("_INSTANT_KEYMAP_DEFS", tuple(_TWEAK_KEYMAP_DEFS)),
            ("_INSTANT_KEYMAP_DEFS_1859", tuple(_TWEAK_KEYMAP_DEFS)),
            ("_INSTANT_KEYMAP_DEFS_1854", tuple(_TWEAK_KEYMAP_DEFS)),
            ("_PURGE_INSTANT_MAP_NAMES", tuple(_PURGE_KEYMAP_NAMES)),
            ("_FORBIDDEN_INSTANT_MAPS", tuple(_PURGE_KEYMAP_NAMES)),
            ("_FORBIDDEN_INSTANT_KEYMAPS", tuple(_PURGE_KEYMAP_NAMES)),
        ):
            try:
                setattr(mod, attr, value)
            except Exception:
                pass
        finder_names = ("_find_hit", "_find_hit_fast_1854", "_find_hit_fast", "_find_uv_hit_fast")
        if modname == "interaction_1844":
            # Keep the real spatial-cache finder intact.  The latency wrapper uses
            # it only after confirming the cache is already warm; replacing it would
            # create a recursive finder path.
            finder_names = ()
            try:
                if hasattr(mod, "_find_uv_hit_fast"):
                    _ORIGINAL_FINDERS.setdefault(f"{mod.__name__}._find_uv_hit_fast", getattr(mod, "_find_uv_hit_fast", None))
            except Exception:
                pass
        for finder_name in finder_names:
            try:
                if hasattr(mod, finder_name):
                    current_finder = getattr(mod, finder_name, None)
                    _ORIGINAL_FINDERS.setdefault(f"{mod.__name__}.{finder_name}", current_finder)
                    if current_finder is not _find_hit_cached_only:
                        setattr(mod, finder_name, _find_hit_cached_only)
            except Exception:
                pass
    try:
        from . import interaction_1871 as i1871
        i1871._ensure_instant_keymaps = _ensure_latency_free_keymaps
        i1871._set_instant_keymaps_active = lambda active: _set_latency_keymaps_active(bool(active))
        i1871._delete_instant_keymaps = _delete_latency_keymaps
    except Exception:
        pass
    try:
        from . import interaction_1865 as i1865
        i1865._ensure_instant_keymaps = _ensure_latency_free_keymaps
        i1865._set_instant_keymaps_active = lambda active: _set_latency_keymaps_active(bool(active))
        i1865._delete_instant_keymaps = _delete_latency_keymaps
    except Exception:
        pass
    try:
        from . import scale_tool_select_handoff_1872 as scale_handoff
        _ORIGINAL_FINDERS.setdefault(f"{scale_handoff.__name__}._find_hit", getattr(scale_handoff, "_find_hit", None))
        scale_handoff._find_hit = _find_hit_cached_only
    except Exception:
        pass
    try:
        if isinstance(package_globals, dict):
            package_globals["_SUS_1830_INSTANT_KEYMAP_DEFS"] = tuple(_TWEAK_KEYMAP_DEFS)
            package_globals["_SUS_1832_INSTANT_KEYMAP_DEFS"] = tuple(_TWEAK_KEYMAP_DEFS)
            package_globals["_SUS_1834_INSTANT_KEYMAP_DEFS"] = tuple(_TWEAK_KEYMAP_DEFS)
            package_globals["_sus_1830_keymap_defs"] = lambda: tuple(_TWEAK_KEYMAP_DEFS)
            package_globals["_sus_1834_keymap_defs"] = lambda: tuple(_TWEAK_KEYMAP_DEFS)
            package_globals["_sus_1652_ensure_instant_keymaps"] = _ensure_latency_free_keymaps
            package_globals["_sus_1652_promote_instant_keymaps_to_head"] = _ensure_latency_free_keymaps
            package_globals["_sus_1652_set_instant_keymaps_active"] = lambda active: _set_latency_keymaps_active(bool(active))
            package_globals["_sus_1652_delete_instant_keymaps"] = _delete_latency_keymaps
            package_globals["_sus_1835_find_uv_hit"] = _find_hit_cached_only
            package_globals["_sus_1894_active_uv_tool_id"] = _active_uv_tool_id
            package_globals["_sus_1894_should_pass_native_without_hit_scan"] = _should_pass_native_without_hit_scan
            package_globals["_sus_1894_background_drag_latency_fix"] = True
    except Exception:
        pass


def _patch_keymap_sync(package_globals: dict[str, Any] | None = None) -> None:
    if not isinstance(package_globals, dict):
        return
    old_sync = package_globals.get("_sus_1652_sync_keymaps_from_workspace")
    if getattr(old_sync, "_sus_1894_latency_sync", False):
        return

    def _sync_1894(context=None):
        ctx = context or bpy.context
        try:
            if callable(old_sync):
                old_sync(ctx)
        except RecursionError:
            pass
        except Exception:
            pass
        try:
            apply_all(package_globals, ctx)
        except Exception:
            pass

    try:
        _sync_1894._sus_1894_latency_sync = True
    except Exception:
        pass
    package_globals["_sus_1652_sync_keymaps_from_workspace"] = _sync_1894


def _mark_version(package_globals: dict[str, Any] | None = None) -> None:
    try:
        if isinstance(package_globals, dict):
            info = package_globals.get("bl_info")
            if isinstance(info, dict):
                info.update({
                    "name": "Smart UV Suite",
                    "author": "JELararagi",
                    "version": (1, 0, 0),
                    "blender": (5, 1, 0),
                    "location": "View3D / UV Editor > Sidebar > Smart UV",
                    "description": "Smart UV Suite exposes UV editing tools in the Smart UV sidebar.",
                    "category": "Smart UV",
                })
                package_globals["_SUS_BL_INFO_FALLBACK"] = dict(info)
            package_globals["__version__"] = '1.0.0'
    except Exception:
        pass


def apply_all(package_globals: dict[str, Any] | None = None, context: Any | None = None) -> None:
    global _PG
    if isinstance(package_globals, dict):
        _PG = package_globals
    ctx = context or getattr(bpy, "context", None)
    _patch_interaction_modules(package_globals)
    _patch_instant_class(package_globals)
    active = _instant_enabled(ctx)
    _set_latency_keymaps_active(active, ctx)
    if active:
        _schedule_cache_refresh(0.10)
    _patch_keymap_sync(package_globals)
    _mark_version(package_globals)


def install(package_globals: dict[str, Any] | None = None, context: Any | None = None) -> None:
    global _PG, _INSTALLED
    if isinstance(package_globals, dict):
        _PG = package_globals
    apply_all(package_globals, context or getattr(bpy, "context", None))
    _INSTALLED = True



def unregister() -> None:
    _suv_resource.timer_unregister(_refresh_cache_timer)
    return None
