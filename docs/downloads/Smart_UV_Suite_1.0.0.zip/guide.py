# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

HELP_GROUPS = {
    "overview": {
        "title_en": "Smart UV Suite",
        "title_ja": "Smart UV Suite",
        "overview_en": [
            "Smart UV Suite consolidates unwrap, seam, alignment, packing, inspection, texel-density, checker, UV-map, bake-prep, and export workflows into one N-panel.",
            "The compact hubs expose the highest-level actions first. Detailed behavior is chosen by the hub action menus and Smart unwrap settings.",
        ],
        "overview_ja": [
            "Smart UV Suite は、展開、シーム、整列、パック、検査、テクセル密度、チェッカー、UVマップ、ベイク準備、書き出しを1つのNパネルへ集約します。",
            "コンパクトハブでは上位互換の主要操作だけを先に出し、詳細動作は各ハブのアクションメニューとスマート展開設定で選びます。",
        ],
        "usage_en": [
            "Open the Smart UV tab, choose the section that matches the current task, then run the compact hub action.",
            "Use Smart unwrap when you want automatic seam-aware unfold, cleanup, packing, and island orientation in one step.",
        ],
        "usage_ja": [
            "Smart UV タブを開き、現在の作業に合うセクションを選んでコンパクトハブのアクションを実行します。",
            "自動シーム判断、展開、整理、パック、アイランド方向補正をまとめて行う場合はスマート展開を使います。",
        ],
    },
    "smart_unwrap": {
        "title_en": "Smart Unwrap",
        "title_ja": "スマート展開",
        "overview_en": [
            "Uses Smart UV Suite settings to preserve connected meshes when possible, add temporary cuts only when needed, unwrap, relax, pack, and orient islands.",
        ],
        "overview_ja": [
            "可能な限りメッシュのつながりを保ち、必要な場合だけ一時カットを使って展開、リラックス、パック、方向補正を行います。",
        ],
    },
}

def get_group(topic: str | None = None) -> dict:
    key = str(topic or "overview")
    return HELP_GROUPS.get(key) or HELP_GROUPS["overview"]

def all_topics() -> list[str]:
    return sorted(HELP_GROUPS.keys())
