from __future__ import annotations

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None

_SKIP_TOKENS = (
    'workspace', 'diagnostic', 'snapshot', 'report', 'support', 'log', 'clear', 'copy', 'open', 'reload', 'validate', 'repair',
)
_MESH_TOKENS = (
    'unwrap', 'seam', 'relax', 'pack', 'layout', 'stack', 'align', 'rectify', 'grid', 'straight', 'checker', 'texel', 'density',
    'uvmap', 'uv map', 'select', 'inspect', 'scan', 'flipped', 'overlap', 'zero', 'similar', 'sym', 'mirror', 'atlas', 'bake',
    'projection', 'cleanup', 'peel', 'iron', 'stitch', 'weld', 'island', 'shell', 'trim', 'hotspot', 'udim',
)
_EDIT_TOKENS = (
    'unwrap', 'seam', 'relax', 'pack', 'layout', 'stack', 'align', 'rectify', 'grid', 'straight', 'select', 'inspect', 'scan',
    'flipped', 'overlap', 'zero', 'similar', 'sym', 'mirror', 'projection', 'cleanup', 'peel', 'iron', 'stitch', 'weld',
    'island', 'shell', 'trim', 'hotspot', 'udim',
)
_UV_TOKENS = (
    'unwrap', 'seam', 'relax', 'pack', 'layout', 'stack', 'align', 'rectify', 'grid', 'straight', 'checker', 'texel', 'density',
    'uvmap', 'uv map', 'select', 'inspect', 'scan', 'flipped', 'overlap', 'zero', 'similar', 'sym', 'mirror', 'atlas',
    'projection', 'cleanup', 'peel', 'iron', 'stitch', 'weld', 'island', 'shell', 'trim', 'hotspot', 'udim',
)


def _meta(cls) -> str:
    values = [
        getattr(cls, 'bl_idname', ''),
        getattr(cls, 'bl_label', ''),
        getattr(cls, 'bl_description', ''),
        getattr(cls, '__name__', ''),
    ]
    return ' '.join(str(v or '') for v in values).lower()


def _needs(meta: str, tokens: tuple[str, ...]) -> bool:
    return any(tok in meta for tok in tokens)


def _should_skip(meta: str) -> bool:
    return any(tok in meta for tok in _SKIP_TOKENS)


def _selected_mesh_objects(namespace: dict, context):
    fn = namespace.get('_selected_mesh_objects')
    if callable(fn):
        try:
            return list(fn(context) or [])
        except Exception:
            pass
    out = []
    for obj in getattr(context, 'selected_objects', []) or []:
        if getattr(obj, 'type', '') == 'MESH':
            out.append(obj)
    return out


def _ensure_active_mesh(namespace: dict, context):
    obj = getattr(context, 'active_object', None)
    if obj is not None and getattr(obj, 'type', '') == 'MESH':
        return obj, False
    selected = _selected_mesh_objects(namespace, context)
    if not selected:
        return None, False
    target = selected[0]
    try:
        context.view_layer.objects.active = target
        return target, True
    except Exception:
        return target, False


def _report(namespace: dict, self, context, level: set[str], key: str, fallback: str, **kwargs):
    fn = getattr(self, 'report', None)
    if not callable(fn):
        return
    tr = namespace.get('tr')
    try:
        msg = tr(context, key, **kwargs) if callable(tr) else fallback.format(**kwargs)
    except Exception:
        msg = fallback.format(**kwargs)
    try:
        fn(level, msg)
    except Exception:
        pass



def _report_once(namespace: dict, self, context, level: set[str], cache_key: str, key: str, fallback: str, **kwargs):
    tr = namespace.get('tr')
    try:
        msg = tr(context, key, **kwargs) if callable(tr) else fallback.format(**kwargs)
    except Exception:
        msg = fallback.format(**kwargs)
    fn = namespace.get('report_once')
    if callable(fn):
        try:
            return bool(fn(namespace, self, context, level, cache_key, msg))
        except Exception:
            pass
    return _report(namespace, self, context, level, key, fallback, **kwargs)


def _log(namespace: dict, context, source: str, message: str, details=None, level='INFO'):
    fn = namespace.get('_suv_log_event')
    if callable(fn):
        try:
            fn(context, level, source, message, details or {})
        except Exception:
            pass


def _ensure_edit_mode(namespace: dict, context, obj) -> tuple[bool, bool]:
    mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT').upper()
    if mode == 'EDIT':
        return True, False
    safe_mode = namespace.get('_suv_safe_mode_set')
    if callable(safe_mode):
        try:
            ok, _err = safe_mode(context, obj, 'EDIT', source='Quality Preflight')
            return bool(ok), bool(ok)
        except Exception:
            return False, False
    try:
        bpy.ops.object.mode_set(mode='EDIT')
        return True, True
    except Exception:
        return False, False


def _ensure_uv_maps(namespace: dict, context):
    ensure = namespace.get('_suv_ensure_uv_maps_selected')
    if callable(ensure):
        try:
            ws_fn = namespace.get('_suv_ws')
            ws = ws_fn(context) if callable(ws_fn) else None
            uv_name = getattr(ws, 'uv_new_name', 'UVMap_SUV') if ws else 'UVMap_SUV'
            return list(ensure(context, uv_name) or [])
        except Exception:
            return []
    return []


def attempt_repair(namespace: dict, context, source: str, exc: Exception | str):
    text = ' '.join([str(source or ''), str(exc or '')]).lower()
    actions = []
    repaired = False
    obj = None
    promoted = False

    try:
        obj, promoted = _ensure_active_mesh(namespace, context)
    except Exception:
        obj, promoted = None, False
    if obj is not None and promoted:
        repaired = True
        actions.append('active_mesh')
        _log(namespace, context, str(source or 'Quality Repair'), 'Promoted selected mesh during repair retry.', {'object': getattr(obj, 'name', '-')}, level='INFO')

    needs_edit = any(tok in text for tok in (
        'edit mode', 'editable mesh', 'mesh', 'context is incorrect', 'operator poll failed',
        'selected face', 'selected edge', 'island', 'shell', 'unwrap', 'seam', 'pack', 'tile',
    ))
    if obj is not None and needs_edit:
        ok_edit, changed_edit = _ensure_edit_mode(namespace, context, obj)
        if ok_edit and changed_edit:
            repaired = True
            actions.append('edit_mode')
            _log(namespace, context, str(source or 'Quality Repair'), 'Prepared Edit Mode during repair retry.', {'object': getattr(obj, 'name', '-')}, level='INFO')

    needs_uv = any(tok in text for tok in (
        'uv', 'layer', 'map', 'image editor', 'uv editor', 'unwrap', 'seam', 'pack', 'tile',
        'checker', 'density', 'texel', 'stretch', 'overlay',
    ))
    if needs_uv:
        created = list(_ensure_uv_maps(namespace, context) or [])
        if created:
            repaired = True
            actions.append('uv_maps')
            _log(namespace, context, str(source or 'Quality Repair'), 'Prepared missing UV maps during repair retry.', {'created_objects': ', '.join(created[:16]), 'count': len(created)}, level='INFO')

    return {
        'repaired': bool(repaired),
        'actions': actions,
        'active_object': getattr(obj, 'name', '-') if obj is not None else '-',
    }


def wrap_operator_preflight(namespace: dict, cls, method_name: str):
    original = getattr(cls, method_name, None)
    if original is None or getattr(original, '_suv_preflight_wrapped', False):
        return False

    meta = _meta(cls)
    if _should_skip(meta):
        return False
    need_mesh = _needs(meta, _MESH_TOKENS)
    need_edit = _needs(meta, _EDIT_TOKENS)
    need_uv = _needs(meta, _UV_TOKENS)
    if not (need_mesh or need_edit or need_uv):
        return False

    def wrapped(self, context, *args, **kwargs):
        obj = None
        promoted = False
        if need_mesh or need_edit or need_uv:
            obj, promoted = _ensure_active_mesh(namespace, context)
            if obj is None:
                _report(namespace, self, context, {'ERROR'}, 'msg.preflight_mesh_missing', 'Select an active mesh object before running this tool.')
                return {'CANCELLED'}
            if promoted:
                _report_once(namespace, self, context, {'INFO'}, f'preflight_active:{cls.__name__}', 'msg.preflight_set_active', 'The first selected mesh was promoted to the active object for this tool.')
                _log(namespace, context, getattr(cls, 'bl_label', cls.__name__), 'Promoted selected mesh to active target during preflight.', {'class': cls.__name__, 'object': getattr(obj, 'name', '-')})
        if need_edit and obj is not None:
            ok_edit, changed_edit = _ensure_edit_mode(namespace, context, obj)
            if not ok_edit:
                _report(namespace, self, context, {'ERROR'}, 'msg.preflight_need_edit', 'Switch to Edit Mode on the target mesh, then run the tool again.')
                return {'CANCELLED'}
            if changed_edit:
                _report_once(namespace, self, context, {'INFO'}, f'preflight_edit:{cls.__name__}:{getattr(obj, "name", "-")}', 'msg.preflight_edit_mode', 'Edit Mode was prepared automatically for this tool.')
                _log(namespace, context, getattr(cls, 'bl_label', cls.__name__), 'Prepared Edit Mode during preflight.', {'class': cls.__name__, 'object': getattr(obj, 'name', '-')})
        if need_uv:
            created = _ensure_uv_maps(namespace, context)
            if created:
                _report_once(namespace, self, context, {'INFO'}, f'preflight_uv:{cls.__name__}:{len(created)}', 'msg.preflight_uv_created', 'Created missing UV maps for {count} object(s).', count=len(created))
                _log(namespace, context, getattr(cls, 'bl_label', cls.__name__), 'Prepared missing UV maps during preflight.', {'class': cls.__name__, 'created_objects': ', '.join(created[:16]), 'created_count': len(created)})
        return original(self, context, *args, **kwargs)

    wrapped._suv_preflight_wrapped = True
    setattr(cls, method_name, wrapped)
    return True


def patch_preflight(namespace: dict) -> dict:
    counts = {'operator_methods': 0}
    for name, value in list(namespace.items()):
        if not name.startswith('SUV_OT_') or not isinstance(value, type):
            continue
        for method_name in ('execute', 'invoke'):
            try:
                if wrap_operator_preflight(namespace, value, method_name):
                    counts['operator_methods'] += 1
            except Exception:
                pass
    namespace['_suv_quality_preflight_counts'] = counts
    return counts
