import bpy

def build_handlers(api):
    def run(context, op):
        if context.mode != 'EDIT_MESH':
            return False
        return 'FINISHED' in bpy.ops.smart_uv_suite.stitch_action(
            mode='ISLAND_CONNECTED_TO_SELECTED'
        )

    stitch = api.Handler(
        run,
        'Stitch selected boundaries to corresponding connected island edges.',
        '選択した境界を対応する連結アイランドの境界辺に縫い合わせます。',
    )
    return {
        'smart_uv_suite.stitch': stitch,
        'smart_uv_suite.stitch_stitch_and_weld': stitch,
    }
