from __future__ import annotations
from . import resource_api_18168 as _suv_resource

import time

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None

_NAMESPACE = {}
_REGISTERED = []
_CACHE_TTL = 0.35


def _tr(context, key: str, fallback_en: str, fallback_ja: str, **fmt) -> str:
    fn = _NAMESPACE.get('tr')
    text = None
    if callable(fn):
        try:
            text = fn(context, key, **fmt)
        except Exception:
            text = None
    if not text:
        text = fallback_en
    try:
        return text.format(**fmt)
    except Exception:
        return text


def _selected_mesh_count(context) -> int:
    try:
        return sum(1 for obj in (getattr(context, 'selected_objects', None) or []) if getattr(obj, 'type', '') == 'MESH')
    except Exception:
        return 0


def _workspace_tab(namespace: dict, context) -> str:
    ws_fn = namespace.get('_suv_ws')
    ws = ws_fn(context) if callable(ws_fn) else None
    return str(getattr(ws, 'tab', '') or '')


def _cached_visual_controls(namespace: dict, context) -> dict:
    cached = namespace.get('_suv_visual_controls_last') or {}
    revision = int(namespace.get('_suv_visual_controls_revision', 0) or 0)
    if isinstance(cached, dict) and int(cached.get('revision', -1) or -1) == revision and cached:
        return dict(cached)
    controls_mod = namespace.get('_quality_controls_module')
    if controls_mod is not None and hasattr(controls_mod, 'scan_visual_controls'):
        try:
            data = controls_mod.scan_visual_controls(namespace, context) or {}
            if isinstance(data, dict):
                return dict(data)
        except Exception:
            pass
    return dict(cached) if isinstance(cached, dict) else {}



def _context_signature(namespace: dict, context):
    obj = getattr(context, 'active_object', None)
    obj_name = getattr(obj, 'name', '') if obj else ''
    obj_type = getattr(obj, 'type', '') if obj else ''
    obj_mode = getattr(obj, 'mode', '') if obj else ''
    try:
        uv_sync = bool(getattr(getattr(context, 'tool_settings', None), 'use_uv_select_sync', False))
    except Exception:
        uv_sync = False
    try:
        issue_total_fn = namespace.get('_suv_issue_cache_total')
        issue_total = int(issue_total_fn(context)) if callable(issue_total_fn) else 0
    except Exception:
        issue_total = 0
    region_width = 0
    layout_mod = namespace.get('_quality_layout_module')
    if layout_mod is not None and hasattr(layout_mod, 'region_width'):
        try:
            region_width = int(layout_mod.region_width(context) or 0)
        except Exception:
            region_width = 0
    focus_override = 'AUTO'
    focus_manual = False
    density_override = 'AUTO'
    density_manual = False
    section_visibility = {'workflow': True, 'learning': True, 'maintenance': True}
    preset_override = 'AUTO'
    preset_effective = 'AUTO'
    preset_matched = True
    controls_revision = 0
    try:
        controls_data = _cached_visual_controls(namespace, context)
        focus_override = str(controls_data.get('focus_override', focus_override) or focus_override)
        focus_manual = bool(controls_data.get('focus_manual', focus_manual))
        density_override = str(controls_data.get('density_override', density_override) or density_override)
        density_manual = bool(controls_data.get('density_manual', density_manual))
        section_visibility = dict(controls_data.get('section_visibility', {}) or section_visibility)
        preset_override = str(controls_data.get('preset_override', preset_override) or preset_override)
        preset_effective = str(controls_data.get('preset_effective', preset_effective) or preset_effective)
        preset_matched = bool(controls_data.get('preset_matched', preset_matched))
        controls_revision = int(controls_data.get('revision', 0) or 0)
    except Exception:
        pass
    return (
        obj_name,
        obj_type,
        obj_mode,
        int(_selected_mesh_count(context)),
        int(uv_sync),
        _workspace_tab(namespace, context),
        issue_total,
        int(region_width),
        focus_override,
        int(focus_manual),
        density_override,
        int(density_manual),
        int(bool(section_visibility.get('workflow', True))),
        int(bool(section_visibility.get('learning', True))),
        int(bool(section_visibility.get('maintenance', True))),
        preset_override,
        preset_effective,
        int(bool(preset_matched)),
        int(controls_revision),
    )


def _scan(namespace: dict, context) -> dict:
    obj = getattr(context, 'active_object', None)
    obj_name = getattr(obj, 'name', '') if obj else 'None'
    ws_fn = namespace.get('_suv_ws')
    ws = ws_fn(context) if callable(ws_fn) else None
    try:
        issue_total_fn = namespace.get('_suv_issue_cache_total')
        issue_total = int(issue_total_fn(context)) if callable(issue_total_fn) else 0
    except Exception:
        issue_total = 0
    try:
        uv_sync = bool(getattr(getattr(context, 'tool_settings', None), 'use_uv_select_sync', False))
    except Exception:
        uv_sync = False

    guard_total = 0
    preflight_total = 0
    restore_total = 0
    cleanup_total = 0
    readiness_score = 0
    readiness_missing = 0
    tool_runtime_errors = 0
    coverage_supported = 0
    coverage_total = 0
    coverage_missing = 0
    translated_labels = 0
    tooltip_rich = 0
    language_total = 0
    report_existing = 0
    report_total = 0
    playbook_ready = 0
    playbook_total = 0
    profiled_total = 0
    profile_blocked = 0
    registry_existing = 0
    registry_total = 0
    doctor_actions = 0
    visible_sections = 0
    hidden_sections = 0
    visible_cards = 0
    hidden_cards = 0
    visible_actions = 0
    section_hidden_cards = 0
    focus_mode = 'all'
    total_card_sections = 0
    total_visual_cards = 0
    ui_map_sections = 0
    ui_map_cards = 0
    ui_map_actions = 0
    recommended_actions = 0
    recommended_reasons = []
    manual_controls = 0
    manual_item_labels = []
    controls_custom = False
    controls_summary = ''
    focus_override_label = 'AUTO'
    focus_effective_label = 'AUTO'
    density_override_label = 'AUTO'
    density_effective_label = 'FULL'
    preset_override_label = 'Auto'
    preset_effective_label = 'Auto'
    preset_display_label = 'Auto'
    section_labels = {'workflow': 'Workflow', 'learning': 'Guides', 'maintenance': 'Reports'}
    section_state_labels = {'workflow': 'shown', 'learning': 'shown', 'maintenance': 'shown'}
    focus_override = 'AUTO'
    focus_manual = False
    density_override = 'AUTO'
    density_manual = False
    density_mode = 'FULL'
    section_visibility = {'workflow': True, 'learning': True, 'maintenance': True}
    dashboard_preset = 'AUTO'
    dashboard_preset_effective = 'AUTO'
    dashboard_preset_label = 'AUTO'
    dashboard_preset_manual = False
    dashboard_preset_matched = True
    controls_last_reason = ''
    controls_revision = 0

    guard_counts = namespace.get('_suv_quality_safety_counts', {})
    preflight_counts = namespace.get('_suv_quality_preflight_counts', {})
    restore_counts = namespace.get('_suv_quality_restore_counts', {})
    if isinstance(guard_counts, dict):
        try:
            guard_total = sum(int(v) for v in guard_counts.values())
        except Exception:
            guard_total = 0
    if isinstance(preflight_counts, dict):
        try:
            preflight_total = sum(int(v) for v in preflight_counts.values())
        except Exception:
            preflight_total = 0
    if isinstance(restore_counts, dict):
        try:
            restore_total = sum(int(v) for v in restore_counts.values())
        except Exception:
            restore_total = 0

    scanners = [
        ('scan_context_readiness', lambda data: (int(data.get('score', 0) or 0), int(data.get('missing', 0) or 0))),
        ('scan_housekeeping', lambda data: int(data.get('total', 0) or 0)),
        ('scan_feature_matrix', lambda data: (int(data.get('supported', 0) or 0), int(data.get('total', 0) or 0), int(data.get('missing', 0) or 0))),
        ('scan_language_coverage', lambda data: (int(data.get('translated_labels', 0) or 0), int(data.get('tooltip_rich', 0) or 0), int(data.get('total', 0) or 0))),
        ('scan_report_hub', lambda data: (int(data.get('existing', 0) or 0), int(data.get('total', 0) or 0))),
        ('scan_task_playbook', lambda data: (int(data.get('ready', 0) or 0), int(data.get('total', 0) or 0))),
        ('scan_operator_profiles', lambda data: (int(data.get('profiled', 0) or 0), int(data.get('blocked_now', 0) or 0))),
        ('scan_quality_audit', lambda data: int(data.get('tool_runtime_errors', 0) or 0)),
        ('scan_report_registry', lambda data: (int(data.get('existing_texts', 0) or 0), int(data.get('total_texts', 0) or 0))),
        ('scan_quality_doctor', lambda data: int(data.get('total_actions', 0) or 0)),
        ('scan_visual_cards', lambda data: (int(data.get('visible_sections', 0) or 0), int(data.get('hidden_sections', 0) or 0), int(data.get('visible_cards', 0) or 0), int(data.get('hidden_cards', 0) or 0), int(data.get('visible_actions', 0) or 0))),
        ('scan_section_controls', lambda data: (int(data.get('visible_sections', 0) or 0), int(data.get('hidden_sections', 0) or 0), int(data.get('hidden_cards', 0) or 0), dict(data.get('visibility', {}) or {}))),
        ('scan_ui_map', lambda data: (int(data.get('sections', 0) or 0), int(data.get('cards', 0) or 0), int(data.get('actions', 0) or 0))),
        ('scan_visual_controls', lambda data: (int(data.get('manual_controls', 0) or 0), bool(data.get('custom_active', False)), str(data.get('summary', '') or ''), int(data.get('hidden_sections', 0) or 0), int(data.get('visible_sections', 0) or 0), str(data.get('last_reason', '') or ''), int(data.get('revision', 0) or 0), list(data.get('manual_item_labels', []) or []))),
        ('scan_focus_control', lambda data: (str(data.get('override', 'AUTO') or 'AUTO'), bool(data.get('manual', False)))),
        ('scan_density_control', lambda data: (str(data.get('override', 'AUTO') or 'AUTO'), bool(data.get('manual', False)), str(data.get('effective', 'FULL') or 'FULL'))),
        ('scan_dashboard_preset', lambda data: (str(data.get('override', 'AUTO') or 'AUTO'), str(data.get('effective', data.get('override', 'AUTO')) or 'AUTO'), str(data.get('label', data.get('effective', data.get('override', 'AUTO'))) or 'AUTO'), bool(data.get('manual', False)), bool(data.get('matched', True)))),
    ]

    namespace['_suv_quality_state_scanning'] = True
    try:
        for name, parser in scanners:
            fn = namespace.get(name)
            if not callable(fn):
                continue
            try:
                if name == 'scan_visual_controls':
                    data = _cached_visual_controls(namespace, context) or {}
                elif name in {'scan_housekeeping', 'scan_report_hub', 'scan_quality_audit', 'scan_report_registry'}:
                    data = fn(context) or {}
                elif name == 'scan_language_coverage':
                    data = fn(namespace) or {}
                else:
                    data = fn(namespace, context) or {}
            except Exception:
                continue
            try:
                parsed = parser(data)
            except Exception:
                continue
            if name == 'scan_context_readiness':
                readiness_score, readiness_missing = parsed
            elif name == 'scan_housekeeping':
                cleanup_total = parsed
            elif name == 'scan_feature_matrix':
                coverage_supported, coverage_total, coverage_missing = parsed
            elif name == 'scan_language_coverage':
                translated_labels, tooltip_rich, language_total = parsed
            elif name == 'scan_report_hub':
                report_existing, report_total = parsed
            elif name == 'scan_task_playbook':
                playbook_ready, playbook_total = parsed
            elif name == 'scan_operator_profiles':
                profiled_total, profile_blocked = parsed
            elif name == 'scan_quality_audit':
                tool_runtime_errors = parsed
            elif name == 'scan_report_registry':
                registry_existing, registry_total = parsed
            elif name == 'scan_quality_doctor':
                doctor_actions = parsed
            elif name == 'scan_visual_cards':
                if isinstance(data, dict):
                    focus_mode = str(data.get('focus_mode', focus_mode) or focus_mode)
                    focus_override = str(data.get('focus_override', focus_override) or focus_override)
                    focus_manual = bool(data.get('focus_manual', focus_manual))
                    total_card_sections = int(data.get('total_sections', total_card_sections) or total_card_sections)
                    total_visual_cards = int(data.get('total_cards', total_visual_cards) or total_visual_cards)
                    section_visibility = dict(data.get('section_visibility', {}) or section_visibility)
                visible_sections, hidden_sections, visible_cards, hidden_cards, visible_actions = parsed
            elif name == 'scan_section_controls':
                sec_visible, sec_hidden, section_hidden_cards, sec_visibility = parsed
                if hidden_sections <= 0:
                    hidden_sections = sec_hidden
                if visible_sections <= 0:
                    visible_sections = sec_visible
                if section_hidden_cards > hidden_cards:
                    hidden_cards = section_hidden_cards
                section_visibility = dict(sec_visibility or section_visibility)
            elif name == 'scan_ui_map':
                ui_map_sections, ui_map_cards, ui_map_actions = parsed
            elif name == 'scan_visual_controls':
                manual_controls, controls_custom, controls_summary, ctrl_hidden_sections, ctrl_visible_sections, controls_last_reason, controls_revision, manual_item_labels = parsed
                if hidden_sections <= 0:
                    hidden_sections = ctrl_hidden_sections
                if visible_sections <= 0:
                    visible_sections = ctrl_visible_sections
                if isinstance(data, dict):
                    section_visibility = dict(data.get('section_visibility', {}) or section_visibility)
                    section_labels = dict(data.get('section_labels', {}) or section_labels)
                    section_state_labels = dict(data.get('section_state_labels', {}) or section_state_labels)
                    focus_override_label = str(data.get('focus_override_label', focus_override_label) or focus_override_label)
                    focus_effective_label = str(data.get('focus_effective_label', focus_effective_label) or focus_effective_label)
                    density_override_label = str(data.get('density_override_label', density_override_label) or density_override_label)
                    density_effective_label = str(data.get('density_effective_label', density_effective_label) or density_effective_label)
                    preset_override_label = str(data.get('preset_override_label', preset_override_label) or preset_override_label)
                    preset_effective_label = str(data.get('preset_effective_label', preset_effective_label) or preset_effective_label)
                    preset_display_label = str(data.get('preset_display_label', preset_display_label) or preset_display_label)
            elif name == 'scan_focus_control':
                focus_override, focus_manual = parsed
            elif name == 'scan_density_control':
                density_override, density_manual, density_mode = parsed
            elif name == 'scan_dashboard_preset':
                dashboard_preset, dashboard_preset_effective, dashboard_preset_label, dashboard_preset_manual, dashboard_preset_matched = parsed
    finally:
        namespace['_suv_quality_state_scanning'] = False

    data = {
        'target_name': obj_name or 'None',
        'uv_sync': bool(uv_sync),
        'issue_total': int(issue_total),
        'workspace': ws,
        'guard_total': int(guard_total),
        'preflight_total': int(preflight_total),
        'restore_total': int(restore_total),
        'cleanup_total': int(cleanup_total),
        'readiness_score': int(readiness_score),
        'readiness_missing': int(readiness_missing),
        'tool_runtime_errors': int(tool_runtime_errors),
        'coverage_supported': int(coverage_supported),
        'coverage_total': int(coverage_total),
        'coverage_missing': int(coverage_missing),
        'translated_labels': int(translated_labels),
        'tooltip_rich': int(tooltip_rich),
        'language_total': int(language_total),
        'report_existing': int(report_existing),
        'report_total': int(report_total),
        'playbook_ready': int(playbook_ready),
        'playbook_total': int(playbook_total),
        'profiled_total': int(profiled_total),
        'profile_blocked': int(profile_blocked),
        'registry_existing': int(registry_existing),
        'registry_total': int(registry_total),
        'doctor_actions': int(doctor_actions),
        'visible_sections': int(visible_sections),
        'hidden_sections': int(hidden_sections),
        'visible_cards': int(visible_cards),
        'hidden_cards': int(hidden_cards),
        'visible_actions': int(visible_actions),
        'section_visibility': dict(section_visibility),
        'focus_mode': str(focus_mode or 'all'),
        'total_card_sections': int(total_card_sections),
        'total_visual_cards': int(total_visual_cards),
        'ui_map_sections': int(ui_map_sections),
        'ui_map_cards': int(ui_map_cards),
        'ui_map_actions': int(ui_map_actions),
        'recommended_actions': int(recommended_actions),
        'recommended_reasons': list(recommended_reasons),
        'recommended_payload': {'count': int(recommended_actions), 'buttons': [], 'reasons': list(recommended_reasons)},
        'manual_controls': int(manual_controls),
        'manual_item_labels': list(manual_item_labels),
        'controls_custom': bool(controls_custom),
        'controls_summary': str(controls_summary or ''),
        'focus_override_label': str(focus_override_label or 'AUTO'),
        'focus_effective_label': str(focus_effective_label or 'AUTO'),
        'density_override_label': str(density_override_label or 'AUTO'),
        'density_effective_label': str(density_effective_label or 'FULL'),
        'preset_override_label': str(preset_override_label or 'Auto'),
        'preset_effective_label': str(preset_effective_label or 'Auto'),
        'preset_display_label': str(preset_display_label or 'Auto'),
        'section_labels': dict(section_labels),
        'section_state_labels': dict(section_state_labels),
        'controls_last_reason': str(controls_last_reason or ''),
        'controls_revision': int(controls_revision),
        'focus_override': str(focus_override),
        'focus_manual': bool(focus_manual),
        'density_override': str(density_override),
        'density_manual': bool(density_manual),
        'density_mode': str(locals().get('density_mode', 'FULL') or 'FULL'),
        'dashboard_preset': str(dashboard_preset),
        'dashboard_preset_effective': str(dashboard_preset_effective),
        'dashboard_preset_label': str(dashboard_preset_label),
        'dashboard_preset_manual': bool(dashboard_preset_manual),
        'dashboard_preset_matched': bool(dashboard_preset_matched),
    }
    recommended_fn = namespace.get('scan_recommended_actions')
    if callable(recommended_fn):
        try:
            recommended_data = recommended_fn(namespace, context, status=dict(data)) or {}
        except TypeError:
            try:
                recommended_data = recommended_fn(namespace, context) or {}
            except Exception:
                recommended_data = {}
        except Exception:
            recommended_data = {}
        if isinstance(recommended_data, dict):
            data['recommended_actions'] = int(recommended_data.get('count', 0) or 0)
            data['recommended_reasons'] = list(recommended_data.get('reasons', []) or [])
            data['recommended_payload'] = dict(recommended_data)

    namespace['_suv_quality_state_last'] = dict(data)
    return data


def collect_status(namespace: dict, context):
    cache = namespace.setdefault('_suv_quality_state_cache', {})
    if namespace.get('_suv_quality_state_scanning'):
        data = cache.get('data') or namespace.get('_suv_quality_state_last') or {}
        return dict(data) if isinstance(data, dict) else {}
    now = time.monotonic()
    sig = _context_signature(namespace, context)
    data = cache.get('data')
    if data is not None and cache.get('signature') == sig and (now - float(cache.get('stamp', 0.0) or 0.0)) <= _CACHE_TTL:
        cache['hits'] = int(cache.get('hits', 0) or 0) + 1
    else:
        data = _scan(namespace, context)
        cache['data'] = data
        cache['signature'] = sig
        cache['stamp'] = now
        cache['misses'] = int(cache.get('misses', 0) or 0) + 1
    namespace['_suv_quality_state_cache_hits'] = int(cache.get('hits', 0) or 0)
    namespace['_suv_quality_state_cache_misses'] = int(cache.get('misses', 0) or 0)
    return dict(data)


def collect_status_tuple(namespace: dict, context):
    data = collect_status(namespace, context)
    return (
        data.get('target_name', 'None'),
        bool(data.get('uv_sync', False)),
        int(data.get('issue_total', 0) or 0),
        data.get('workspace'),
        int(data.get('guard_total', 0) or 0),
        int(data.get('preflight_total', 0) or 0),
        int(data.get('restore_total', 0) or 0),
        int(data.get('cleanup_total', 0) or 0),
        int(data.get('readiness_score', 0) or 0),
        int(data.get('readiness_missing', 0) or 0),
        int(data.get('tool_runtime_errors', 0) or 0),
        int(data.get('coverage_supported', 0) or 0),
        int(data.get('coverage_total', 0) or 0),
        int(data.get('coverage_missing', 0) or 0),
        int(data.get('translated_labels', 0) or 0),
        int(data.get('tooltip_rich', 0) or 0),
        int(data.get('language_total', 0) or 0),
        int(data.get('report_existing', 0) or 0),
        int(data.get('report_total', 0) or 0),
        int(data.get('playbook_ready', 0) or 0),
        int(data.get('playbook_total', 0) or 0),
        int(data.get('profiled_total', 0) or 0),
        int(data.get('profile_blocked', 0) or 0),
        int(data.get('registry_existing', 0) or 0),
        int(data.get('registry_total', 0) or 0),
        int(data.get('doctor_actions', 0) or 0),
        int(data.get('visible_sections', 0) or 0),
        int(data.get('hidden_sections', 0) or 0),
        int(data.get('visible_cards', 0) or 0),
        int(data.get('hidden_cards', 0) or 0),
        int(data.get('visible_actions', 0) or 0),
    )


def clear_quality_state_cache(namespace: dict | None = None):
    ns = namespace if isinstance(namespace, dict) else _NAMESPACE
    ns['_suv_quality_state_cache'] = {}
    ns['_suv_quality_state_cache_hits'] = 0
    ns['_suv_quality_state_cache_misses'] = 0
    ns['_suv_quality_state_last'] = {}
    ns['_suv_recommended_actions_last'] = {}
    return True


class SUV_OT_quality_clear_status_cache(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_clear_status_cache'
    bl_label = 'Clear Status Cache'
    bl_description = 'Clear the cached visual status snapshot so the dashboard recomputes state immediately. / 視覚ステータスのキャッシュ済みスナップショットを消去し、ダッシュボード状態をすぐ再計算できるようにします。'
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        clear_quality_state_cache(_NAMESPACE)
        self.report({'INFO'}, _tr(context, 'msg.quality_state_cache_cleared', 'Visual status cache cleared.', '視覚状態キャッシュを消去しました。'))
        return {'FINISHED'}


def register(namespace: dict) -> list[type]:
    global _NAMESPACE
    _NAMESPACE = namespace
    clear_quality_state_cache(namespace)
    if bpy is None:
        return []
    classes = [SUV_OT_quality_clear_status_cache]
    registered = []
    for cls in classes:
        try:
            _suv_resource.register_class(cls)
            registered.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = registered
    return registered


def unregister(namespace: dict | None = None) -> list[type]:
    clear_quality_state_cache(namespace if isinstance(namespace, dict) else _NAMESPACE)
    if bpy is None:
        return []
    removed = []
    for cls in reversed(_REGISTERED):
        try:
            _suv_resource.unregister_class(cls)
            removed.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = []
    return removed
