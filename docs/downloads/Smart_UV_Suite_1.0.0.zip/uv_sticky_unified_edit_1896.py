# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Sticky UV endpoint unification for Smart UV Suite 1.8.96.

When Blender's UV Sticky Selection mode is set to Shared Location or Shared
Vertex, selected UV endpoints must behave as one editable point not only in
vertex mode but also while editing edges/faces and while using Blender-native
UV transform/gizmo tools.  This module expands the live UV selection to the
sticky-equivalent endpoints before Smart UV alignment operators and before
native UV transform/gizmo events.  It does not change Blender themes, tools,
Region Overlap, or any non-UV-editor UI.
"""
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Set, Tuple

import bpy

_VERSION = (1, 8, 96)
_OP_ID = "smart_uv_suite.sticky_select_expand_passthrough"
_DIGITS = 7
_NS: Dict[str, Any] = {}
_INSTALLED = False
_REGISTERED_CLASSES: List[type] = []
_KEYMAP_ROWS: List[Tuple[Any, Any]] = []
_WRAPPED_EXECUTES: Dict[type, Callable[..., Any]] = {}
_ORIGINAL_INVOKE_TRANSLATE: Optional[Callable[..., Any]] = None
_ORIGINAL_1892_COLLECT: Optional[Callable[..., Any]] = None
_ORIGINAL_1892_POINT_KEY: Optional[Callable[..., Any]] = None

_KEYMAP_DEFS: Tuple[Tuple[str, str, str, str], ...] = (
    ("Image Editor Tool: Uv, Move", "IMAGE_EDITOR", "LEFTMOUSE", "PRESS"),
    ("Image Editor Tool: Uv, Move (fallback)", "IMAGE_EDITOR", "LEFTMOUSE", "PRESS"),
    ("Image Editor Tool: Uv, Rotate", "IMAGE_EDITOR", "LEFTMOUSE", "PRESS"),
    ("Image Editor Tool: Uv, Rotate (fallback)", "IMAGE_EDITOR", "LEFTMOUSE", "PRESS"),
    ("Image Editor Tool: Uv, Scale", "IMAGE_EDITOR", "LEFTMOUSE", "PRESS"),
    ("Image Editor Tool: Uv, Scale (fallback)", "IMAGE_EDITOR", "LEFTMOUSE", "PRESS"),
    ("Image Editor Tool: Uv, Transform", "IMAGE_EDITOR", "LEFTMOUSE", "PRESS"),
    ("Image Editor Tool: Uv, Transform (fallback)", "IMAGE_EDITOR", "LEFTMOUSE", "PRESS"),
    ("Image Editor Tool: Uv, Tweak", "IMAGE_EDITOR", "LEFTMOUSE", "PRESS"),
    ("Image Editor Tool: Uv, Tweak (fallback)", "IMAGE_EDITOR", "LEFTMOUSE", "PRESS"),
    ("Generic Gizmo", "EMPTY", "LEFTMOUSE", "PRESS"),
    ("Generic Gizmo Drag", "EMPTY", "LEFTMOUSE", "PRESS"),
    ("Generic Gizmo Click Drag", "EMPTY", "LEFTMOUSE", "PRESS"),
    ("Generic Gizmo Maybe Drag", "EMPTY", "LEFTMOUSE", "PRESS"),
    ("Generic Gizmo Select", "EMPTY", "LEFTMOUSE", "PRESS"),
    ("UV Editor", "IMAGE_EDITOR", "G", "PRESS"),
    ("UV Editor", "IMAGE_EDITOR", "R", "PRESS"),
    ("UV Editor", "IMAGE_EDITOR", "S", "PRESS"),
)

_ALIGN_ID_TOKENS: Tuple[str, ...] = (
    "align",
    "distribute",
    "direction",
    "centralize",
    "straighten",
    "space",
    "grid",
)


def _txt(context: Any, en: str, ja: str) -> str:
    fn = _NS.get("_sus_text")
    if callable(fn):
        try:
            return str(fn(en, ja, context))
        except Exception:
            pass
    try:
        lang = str(getattr(getattr(context, "preferences", None), "view", None).language or "")
        if lang.startswith("ja"):
            return ja
    except Exception:
        pass
    return ja or en


def _is_uv_context(context: Any) -> bool:
    try:
        space = getattr(context, "space_data", None)
        if getattr(space, "type", "") != "IMAGE_EDITOR":
            # Generic Gizmo maps can run with a broader context.  Allow them if
            # the active screen has a UV editor and an edit mesh exists.
            has_uv_area = False
            screen = getattr(context, "screen", None)
            for area in getattr(screen, "areas", []) or []:
                try:
                    if getattr(area, "type", "") != "IMAGE_EDITOR":
                        continue
                    for sp in getattr(area, "spaces", []) or []:
                        ui = str(getattr(sp, "ui_type", "") or "").upper()
                        mode = str(getattr(sp, "mode", "") or "").upper()
                        if ui == "UV" or mode == "UV":
                            has_uv_area = True
                            break
                    if has_uv_area:
                        break
                except Exception:
                    pass
            if not has_uv_area:
                return False
        else:
            ui = str(getattr(space, "ui_type", "") or "").upper()
            mode = str(getattr(space, "mode", "") or "").upper()
            if ui and ui != "UV" and mode != "UV":
                return False
            if (not ui) and mode and mode != "UV":
                return False
    except Exception:
        return False
    try:
        obj = getattr(context, "edit_object", None) or getattr(context, "active_object", None)
        return obj is not None and getattr(obj, "type", "") == "MESH"
    except Exception:
        return False


def _sticky(context: Any) -> str:
    try:
        ts = getattr(context, "tool_settings", None) or getattr(getattr(context, "scene", None), "tool_settings", None)
        mode = str(getattr(ts, "uv_sticky_select_mode", "DISABLED") or "DISABLED").upper()
    except Exception:
        mode = "DISABLED"
    aliases = {
        "SAME_LOCATION": "SHARED_LOCATION",
        "SAME_POSITION": "SHARED_LOCATION",
        "LOCATION": "SHARED_LOCATION",
        "SHARED_POSITION": "SHARED_LOCATION",
        "VERTEX": "SHARED_VERTEX",
        "SHARED_VERT": "SHARED_VERTEX",
        "COMMON_VERTEX": "SHARED_VERTEX",
    }
    return aliases.get(mode, mode)


def _uv_mode(context: Any) -> str:
    fn = _NS.get("_sus_1655_uv_mode") or _NS.get("_sus_uv_select_mode")
    if callable(fn):
        try:
            raw = fn(context)
            if raw:
                return _normalize_mode(raw)
        except Exception:
            pass
    try:
        raw = getattr(getattr(context, "tool_settings", None), "uv_select_mode", "VERTEX")
    except Exception:
        raw = "VERTEX"
    return _normalize_mode(raw)


def _normalize_mode(raw: Any) -> str:
    try:
        if isinstance(raw, (set, list, tuple)):
            vals = {str(v).upper() for v in raw}
            if "FACE" in vals or "ISLAND" in vals:
                return "FACE"
            if "EDGE" in vals:
                return "EDGE"
            return "VERTEX"
        value = str(raw or "VERTEX").upper()
        if "FACE" in value or "ISLAND" in value:
            return "FACE"
        if "EDGE" in value:
            return "EDGE"
        return "VERTEX"
    except Exception:
        return "VERTEX"


def _sync(context: Any) -> bool:
    try:
        return bool(getattr(getattr(context, "tool_settings", None), "use_uv_select_sync", False))
    except Exception:
        return False


def _edit_objects(context: Any) -> List[Any]:
    out: List[Any] = []
    try:
        out = [o for o in (getattr(context, "objects_in_mode_unique_data", None) or []) if getattr(o, "type", "") == "MESH" and getattr(o, "mode", "") == "EDIT"]
    except Exception:
        out = []
    if not out:
        try:
            obj = getattr(context, "edit_object", None) or getattr(context, "active_object", None)
            if obj is not None and getattr(obj, "type", "") == "MESH" and getattr(obj, "mode", "") == "EDIT":
                out = [obj]
        except Exception:
            pass
    seen: Set[int] = set()
    clean: List[Any] = []
    for obj in out:
        try:
            key = int(getattr(obj, "data", obj).as_pointer()) if hasattr(getattr(obj, "data", obj), "as_pointer") else id(getattr(obj, "data", obj))
        except Exception:
            key = id(obj)
        if key in seen:
            continue
        seen.add(key)
        clean.append(obj)
    return clean


def _ensure_target(context: Any, obj: Any) -> None:
    try:
        from . import uv_map_channels as _uvc
        ws = getattr(getattr(context, "scene", None), "suv_workspace", None)
        _uvc.ensure_unwrap_map_channel(context, ws, obj)
    except Exception:
        pass


def _uv_layer_for_bmesh(bm: Any):
    try:
        layer = bm.loops.layers.uv.active
        if layer is not None:
            return layer
    except Exception:
        pass
    try:
        return bm.loops.layers.uv.verify()
    except Exception:
        return None


def _loop_index(loop: Any) -> int:
    try:
        return int(getattr(loop, "index", -1))
    except Exception:
        return -1


def _face_index(face: Any) -> int:
    try:
        return int(getattr(face, "index", -1))
    except Exception:
        return -1


def _obj_key(obj: Any) -> str:
    for name in ("_sus_1655_obj_key", "_sus_1653_obj_key"):
        fn = _NS.get(name)
        if callable(fn):
            try:
                return str(fn(obj))
            except Exception:
                pass
    try:
        return str(getattr(obj, "name_full", None) or getattr(obj, "name", None) or id(obj))
    except Exception:
        return str(id(obj))


def _uv_key(loop: Any, uv_layer: Any) -> Optional[Tuple[float, float]]:
    try:
        uv = loop[uv_layer].uv
        return (round(float(uv.x), _DIGITS), round(float(uv.y), _DIGITS))
    except Exception:
        return None


def _point_key(obj: Any, loop: Any, uv_layer: Any, sticky: str) -> Optional[Tuple[Any, ...]]:
    sticky = str(sticky or "DISABLED").upper()
    if sticky == "SHARED_LOCATION":
        key = _uv_key(loop, uv_layer)
        if key is None:
            return None
        return ("uv", key[0], key[1])
    if sticky == "SHARED_VERTEX":
        try:
            return ("vert", _obj_key(obj), int(getattr(loop.vert, "index", -1)))
        except Exception:
            return None
    return None


def _luv(loop: Any, uv_layer: Any):
    try:
        return loop[uv_layer]
    except Exception:
        return None


def _get_v(loop: Any, uv_layer: Any, sync: bool = False) -> bool:
    for getter in (
        lambda: getattr(loop, "uv_select_vert", False),
        lambda: getattr(loop[uv_layer], "select_vert", False),
        lambda: getattr(loop[uv_layer], "select", False),
    ):
        try:
            if bool(getter()):
                return True
        except Exception:
            pass
    if sync:
        try:
            return bool(getattr(loop.vert, "select", False))
        except Exception:
            pass
    return False


def _get_e(loop: Any, uv_layer: Any, sync: bool = False) -> bool:
    for getter in (
        lambda: getattr(loop, "uv_select_edge", False),
        lambda: getattr(loop[uv_layer], "select_edge", False),
    ):
        try:
            if bool(getter()):
                return True
        except Exception:
            pass
    if sync:
        try:
            return bool(getattr(loop.edge, "select", False))
        except Exception:
            pass
    return False


def _get_f(face: Any, sync: bool = False) -> bool:
    try:
        if bool(getattr(face, "uv_select", False)):
            return True
    except Exception:
        pass
    if sync:
        try:
            return bool(getattr(face, "select", False))
        except Exception:
            pass
    return False


def _set_v(loop: Any, uv_layer: Any, value: bool = True) -> None:
    value = bool(value)
    try:
        setter = getattr(loop, "uv_select_vert_set", None)
        if callable(setter):
            setter(value)
    except Exception:
        pass
    luv = _luv(loop, uv_layer)
    if luv is not None:
        for name in ("select_vert", "select"):
            try:
                setattr(luv, name, value)
            except Exception:
                pass
    try:
        loop.vert.select_set(value)
    except Exception:
        pass


def _set_e(loop: Any, uv_layer: Any, value: bool = True) -> None:
    value = bool(value)
    try:
        setter = getattr(loop, "uv_select_edge_set", None)
        if callable(setter):
            setter(value)
    except Exception:
        pass
    luv = _luv(loop, uv_layer)
    if luv is not None:
        try:
            setattr(luv, "select_edge", value)
        except Exception:
            pass
    try:
        loop.edge.select_set(value)
    except Exception:
        pass


def _set_f(face: Any, value: bool = True) -> None:
    value = bool(value)
    try:
        setter = getattr(face, "uv_select_set", None)
        if callable(setter):
            setter(value)
            return
    except Exception:
        pass
    try:
        setattr(face, "uv_select", value)
    except Exception:
        pass
    try:
        face.select_set(value)
    except Exception:
        pass


def _read_attr(mesh: Any, name: str) -> List[bool]:
    try:
        attr = getattr(mesh, "attributes", None).get(name)
        if attr is None:
            return []
        return [bool(getattr(item, "value", False)) for item in getattr(attr, "data", []) or []]
    except Exception:
        return []


def _write_attr_true(mesh: Any, name: str, indices: Iterable[int]) -> None:
    try:
        attr = getattr(mesh, "attributes", None).get(name)
        if attr is None:
            return
        data = getattr(attr, "data", []) or []
        for idx in indices:
            try:
                i = int(idx)
                if 0 <= i < len(data):
                    data[i].value = True
            except Exception:
                pass
    except Exception:
        pass


def _has_live_selection(bm: Any, uv_layer: Any, mode: str, sync: bool) -> bool:
    try:
        for face in bm.faces:
            if mode == "FACE" and _get_f(face, sync):
                return True
            for loop in face.loops:
                if _get_v(loop, uv_layer, sync) or _get_e(loop, uv_layer, sync):
                    return True
    except Exception:
        pass
    return False


def _selected_endpoint_keys_for_mesh(obj: Any, mesh: Any, bm: Any, uv_layer: Any, mode: str, sticky: str, sync: bool) -> Tuple[Set[Tuple[Any, ...]], Set[int], Set[int], Set[int]]:
    keys: Set[Tuple[Any, ...]] = set()
    selected_loop_indices: Set[int] = set()
    selected_edge_loop_indices: Set[int] = set()
    selected_face_indices: Set[int] = set()
    live_any = _has_live_selection(bm, uv_layer, mode, sync)
    v_attr = [] if live_any else _read_attr(mesh, ".uv_select_vert")
    e_attr = [] if live_any else _read_attr(mesh, ".uv_select_edge")
    f_attr = [] if live_any else _read_attr(mesh, ".uv_select_face")

    def add_loop(loop: Any) -> None:
        key = _point_key(obj, loop, uv_layer, sticky)
        if key is not None:
            keys.add(key)
        li = _loop_index(loop)
        if li >= 0:
            selected_loop_indices.add(li)

    def loop_attr(flag_list: Sequence[bool], loop: Any) -> bool:
        li = _loop_index(loop)
        return 0 <= li < len(flag_list) and bool(flag_list[li])

    for face in bm.faces:
        try:
            if getattr(face, "hide", False):
                continue
            loops = list(face.loops)
        except Exception:
            continue
        if not loops:
            continue
        fi = _face_index(face)
        face_selected = False
        if mode == "FACE":
            face_selected = _get_f(face, sync) or (not live_any and 0 <= fi < len(f_attr) and bool(f_attr[fi]))
        if face_selected:
            if fi >= 0:
                selected_face_indices.add(fi)
            for loop in loops:
                add_loop(loop)
        for loop in loops:
            li = _loop_index(loop)
            if mode == "EDGE":
                edge_selected = _get_e(loop, uv_layer, sync) or (not live_any and 0 <= li < len(e_attr) and bool(e_attr[li]))
                if edge_selected:
                    if li >= 0:
                        selected_edge_loop_indices.add(li)
                    add_loop(loop)
                    try:
                        add_loop(loop.link_loop_next)
                    except Exception:
                        pass
            elif mode != "FACE":
                vert_selected = _get_v(loop, uv_layer, sync) or (not live_any and 0 <= li < len(v_attr) and bool(v_attr[li]))
                if vert_selected:
                    add_loop(loop)
            else:
                # In face mode Blender can still have edge/vertex flags from a
                # partial UV selection.  Preserve them as selected endpoints.
                if _get_v(loop, uv_layer, sync) or loop_attr(v_attr, loop):
                    add_loop(loop)
                if _get_e(loop, uv_layer, sync) or loop_attr(e_attr, loop):
                    add_loop(loop)
                    try:
                        add_loop(loop.link_loop_next)
                    except Exception:
                        pass
    return keys, selected_loop_indices, selected_edge_loop_indices, selected_face_indices


def expand_sticky_uv_selection(context: Any = None, *, mode_hint: Any = None, force: bool = False) -> int:
    """Expand the current UV endpoint selection to sticky-equivalent loops.

    The function never deselects anything.  It only adds equivalent endpoints
    when ToolSettings.uv_sticky_select_mode is Shared Location or Shared Vertex.
    That matches Blender's vertex-edit sticky behavior and keeps edge/face
    editing from tearing overlapped endpoints apart.
    """
    ctx = context or getattr(bpy, "context", None)
    if ctx is None:
        return 0
    sticky = _sticky(ctx)
    if sticky not in {"SHARED_LOCATION", "SHARED_VERTEX"}:
        return 0
    if (not force) and (not _is_uv_context(ctx)):
        # Smart alignment operators can call with force=True outside an active
        # IMAGE_EDITOR context; pass-through keymaps stay constrained to UV UI.
        return 0
    mode = _normalize_mode(mode_hint) if mode_hint is not None else _uv_mode(ctx)
    sync = _sync(ctx)
    total_changed = 0
    try:
        import bmesh
    except Exception:
        return 0
    for obj in _edit_objects(ctx):
        try:
            _ensure_target(ctx, obj)
            mesh = getattr(obj, "data", None)
            if mesh is None:
                continue
            bm = bmesh.from_edit_mesh(mesh)
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
            uv_layer = _uv_layer_for_bmesh(bm)
            if uv_layer is None:
                continue
        except Exception:
            continue
        keys, _sel_loops, _sel_edges, _sel_faces = _selected_endpoint_keys_for_mesh(obj, mesh, bm, uv_layer, mode, sticky, sync)
        if not keys:
            continue
        add_loop_indices: Set[int] = set()
        add_edge_indices: Set[int] = set()
        add_face_indices: Set[int] = set()
        endpoint_selected: Set[Tuple[int, int]] = set()
        for face in bm.faces:
            try:
                if getattr(face, "hide", False):
                    continue
                loops = list(face.loops)
            except Exception:
                continue
            for loop in loops:
                key = _point_key(obj, loop, uv_layer, sticky)
                if key is None or key not in keys:
                    continue
                before = _get_v(loop, uv_layer, sync)
                _set_v(loop, uv_layer, True)
                li = _loop_index(loop)
                if li >= 0:
                    add_loop_indices.add(li)
                try:
                    endpoint_selected.add((_face_index(face), int(tuple(face.loops).index(loop))))
                except Exception:
                    pass
                if not before:
                    total_changed += 1
        # If an entire UV edge or face became selected by endpoint unification,
        # mirror that into the edge/face selection flags.  Partial matching
        # remains vertex-only so an unrelated edge does not get fully selected.
        for face in bm.faces:
            try:
                loops = list(face.loops)
            except Exception:
                continue
            if not loops:
                continue
            full_face = True
            for loop in loops:
                if not _get_v(loop, uv_layer, sync):
                    full_face = False
                    break
            if full_face and mode == "FACE":
                before = _get_f(face, sync)
                _set_f(face, True)
                fi = _face_index(face)
                if fi >= 0:
                    add_face_indices.add(fi)
                if not before:
                    total_changed += 1
            for loop in loops:
                try:
                    if _get_v(loop, uv_layer, sync) and _get_v(loop.link_loop_next, uv_layer, sync):
                        if mode == "EDGE" and (loop.edge.select or _get_e(loop, uv_layer, sync)):
                            # Preserve selected edges.  Do not promote every
                            # newly matched partial edge to selected because the
                            # request is specifically endpoint unification.
                            before = _get_e(loop, uv_layer, sync)
                            _set_e(loop, uv_layer, True)
                            li = _loop_index(loop)
                            if li >= 0:
                                add_edge_indices.add(li)
                            if not before:
                                total_changed += 1
                except Exception:
                    pass
        try:
            _write_attr_true(mesh, ".uv_select_vert", add_loop_indices)
            _write_attr_true(mesh, ".uv_select_edge", add_edge_indices)
            _write_attr_true(mesh, ".uv_select_face", add_face_indices)
        except Exception:
            pass
        try:
            bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        except TypeError:
            try:
                bmesh.update_edit_mesh(mesh)
            except Exception:
                pass
        except Exception:
            pass
    return int(total_changed)


class SMARTUVSUITE_OT_sticky_select_expand_passthrough(bpy.types.Operator):
    bl_idname = _OP_ID
    bl_label = "Sticky UV Selection Preflight"
    bl_description = "Before a native UV transform or gizmo edit starts, expand selected edge/face endpoints to the current UV Sticky Selection mode so shared-position or shared-vertex UVs move together. / 標準UV変形やギズモ編集の開始前に、吸着選択モードに合わせて同じ位置・共通頂点のUV端点を同一扱いにします。"
    bl_options = {"INTERNAL"}

    def invoke(self, context, event):
        try:
            if _is_uv_context(context):
                expand_sticky_uv_selection(context, force=False)
        except Exception:
            pass
        return {"PASS_THROUGH"}


def _addon_keyconfig() -> Any:
    try:
        return bpy.context.window_manager.keyconfigs.addon
    except Exception:
        return None


def _keymap_get_or_new(kc: Any, name: str, space_type: str) -> Any:
    try:
        km = kc.keymaps.get(name)
        if km is None:
            km = kc.keymaps.new(name=name, space_type=space_type, region_type="WINDOW")
        return km
    except Exception:
        return None


def _configure_kmi(kmi: Any, typ: str, value: str) -> None:
    for name, val in (("type", typ), ("value", value), ("shift", False), ("ctrl", False), ("alt", False), ("oskey", False), ("any", False)):
        try:
            _suv_resource.keymap_item_set(kmi, name, val)
        except Exception:
            pass
    try:
        from . import ownership_runtime_18168 as _ownership
        _ownership.set_keymap_item_active(kmi, True)
    except Exception:
        pass


def _install_keymaps() -> None:
    kc = _addon_keyconfig()
    if kc is None:
        return
    try:
        from . import ownership_runtime_18168 as _ownership
    except Exception:
        return
    for name, space_type, typ, value in _KEYMAP_DEFS:
        km = _keymap_get_or_new(kc, name, space_type)
        if km is None:
            continue
        rows = [kmi for keymap, kmi in _ownership.owned_keymap_items(_OP_ID) if keymap is km]
        if rows:
            _configure_kmi(rows[0], typ, value)
            if (km, rows[0]) not in _KEYMAP_ROWS:
                _KEYMAP_ROWS.append((km, rows[0]))
            continue
        try:
            kmi = _ownership.new_keymap_item(km, _OP_ID, type=typ, value=value, head=True)
        except TypeError:
            try:
                kmi = _ownership.new_keymap_item(km, _OP_ID, type=typ, value=value)
            except Exception:
                kmi = None
        except Exception:
            kmi = None
        if kmi is not None:
            _configure_kmi(kmi, typ, value)
            _KEYMAP_ROWS.append((km, kmi))


def _remove_keymaps() -> None:
    try:
        from . import ownership_runtime_18168 as _ownership
        _ownership.remove_owned_keymaps(_OP_ID)
    except Exception:
        pass
    _KEYMAP_ROWS.clear()
    return None


def _should_wrap_operator(cls: type) -> bool:
    try:
        bl_id = str(getattr(cls, "bl_idname", "") or "").lower()
        label = str(getattr(cls, "bl_label", "") or "").lower()
    except Exception:
        return False
    if not bl_id and not label:
        return False
    if any(tok in bl_id for tok in _ALIGN_ID_TOKENS):
        return True
    if "align" in label or "整列" in label:
        return True
    return False


def _wrap_execute(cls: type) -> None:
    if cls in _WRAPPED_EXECUTES:
        return
    old = getattr(cls, "execute", None)
    if not callable(old):
        return

    def _wrapped(self, context, _old=old):
        try:
            expand_sticky_uv_selection(context, force=True)
        except Exception:
            pass
        return _old(self, context)

    try:
        cls.execute = _wrapped
        _WRAPPED_EXECUTES[cls] = old
    except Exception:
        pass


def _wrap_alignment_operators(ns: Dict[str, Any]) -> None:
    try:
        for value in list(ns.values()):
            if isinstance(value, type) and _should_wrap_operator(value):
                _wrap_execute(value)
    except Exception:
        pass


def _restore_alignment_operators() -> None:
    for cls, old in list(_WRAPPED_EXECUTES.items()):
        try:
            cls.execute = old
        except Exception:
            pass
    _WRAPPED_EXECUTES.clear()


def _patch_instant_translate() -> None:
    global _ORIGINAL_INVOKE_TRANSLATE
    try:
        from . import interaction_1871 as inter
    except Exception:
        return
    try:
        cur = getattr(inter, "_invoke_native_translate_once", None)
        if not callable(cur) or cur is _invoke_native_translate_once_1896:
            return
        _ORIGINAL_INVOKE_TRANSLATE = cur
        inter._invoke_native_translate_once = _invoke_native_translate_once_1896
    except Exception:
        pass


def _invoke_native_translate_once_1896(context, axis=None) -> set:
    try:
        expand_sticky_uv_selection(context, force=True)
    except Exception:
        pass
    if callable(_ORIGINAL_INVOKE_TRANSLATE):
        try:
            return _ORIGINAL_INVOKE_TRANSLATE(context, axis=axis)
        except TypeError:
            try:
                return _ORIGINAL_INVOKE_TRANSLATE(context)
            except Exception:
                return {"CANCELLED"}
        except Exception:
            return {"CANCELLED"}
    try:
        kwargs = {"release_confirm": True}
        if axis is not None:
            kwargs["constraint_axis"] = axis
        res = bpy.ops.transform.translate("INVOKE_DEFAULT", **kwargs)
        return set(res) if res is not None else {"RUNNING_MODAL"}
    except Exception:
        return {"CANCELLED"}


def _unpatch_instant_translate() -> None:
    global _ORIGINAL_INVOKE_TRANSLATE
    try:
        from . import interaction_1871 as inter
        if _ORIGINAL_INVOKE_TRANSLATE is not None and getattr(inter, "_invoke_native_translate_once", None) is _invoke_native_translate_once_1896:
            inter._invoke_native_translate_once = _ORIGINAL_INVOKE_TRANSLATE
    except Exception:
        pass
    _ORIGINAL_INVOKE_TRANSLATE = None


def _patch_direction_align_1892() -> None:
    """Patch 1.8.92 backend so sticky points move together without merging groups.

    The existing 1.8.92 backend groups records by sticky key before component
    construction.  In group actions that can accidentally connect disconnected
    selected edges through a coincident endpoint.  The patch keeps component
    construction based on actual selected edge/face connectivity and lets sticky
    equivalents ride along as extra records attached to each point.
    """
    global _ORIGINAL_1892_COLLECT
    try:
        from . import uv_direction_align_1892 as d
    except Exception:
        return
    try:
        cur = getattr(d, "_collect_vertex_domain", None)
        if not callable(cur) or getattr(cur, "_suv1896_patched", False):
            return
        _ORIGINAL_1892_COLLECT = cur
    except Exception:
        return

    def _collect_vertex_domain_1896(context: Any, scope: str = "SELECTED") -> Dict[str, Any]:
        import bmesh
        mode = _normalize_mode(getattr(d, "_uv_mode", _uv_mode)(context))
        sync = bool(getattr(d, "_sync", _sync)(context))
        sticky = _sticky(context)
        scope_all = str(scope or "SELECTED").upper() == "ALL"
        records: List[Dict[str, Any]] = []
        pairs: List[Tuple[int, int]] = []
        meshes: List[Any] = []

        for obj in _edit_objects(context):
            try:
                _ensure_target(context, obj)
                mesh = getattr(obj, "data", None)
                bm = bmesh.from_edit_mesh(mesh)
                bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
                bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
                uv_layer = _uv_layer_for_bmesh(bm)
                if uv_layer is None:
                    continue
            except Exception:
                continue
            meshes.append(mesh)
            live_any = _has_live_selection(bm, uv_layer, mode, sync)
            v_attr = [] if live_any else _read_attr(mesh, ".uv_select_vert")
            e_attr = [] if live_any else _read_attr(mesh, ".uv_select_edge")
            f_attr = [] if live_any else _read_attr(mesh, ".uv_select_face")
            obj_key = _obj_key(obj)
            selected_keys, _sel_loops, _sel_edges, _sel_faces = _selected_endpoint_keys_for_mesh(obj, mesh, bm, uv_layer, mode, sticky, sync)
            rec_by_loop: Dict[int, int] = {}

            def make(face: Any, loop: Any, local_i: int, *, selected_source: bool = False) -> Optional[int]:
                try:
                    li = _loop_index(loop)
                    if li in rec_by_loop:
                        idx = rec_by_loop[li]
                        if selected_source:
                            records[idx]["selected_source"] = True
                        return idx
                    u, v = d._uv_xy(loop, uv_layer) if hasattr(d, "_uv_xy") else (float(loop[uv_layer].uv.x), float(loop[uv_layer].uv.y))
                    rec = {
                        "obj": obj,
                        "obj_key": obj_key,
                        "mesh": mesh,
                        "bm": bm,
                        "uv_layer": uv_layer,
                        "face": face,
                        "loop": loop,
                        "face_index": _face_index(face),
                        "face_loop_index": int(local_i),
                        "loop_index": li,
                        "vertex_index": int(getattr(getattr(loop, "vert", None), "index", -1)),
                        "edge_index": int(getattr(getattr(loop, "edge", None), "index", -1)),
                        "record_id": (obj_key, _face_index(face), int(local_i), li),
                        "uv_key": _uv_key(loop, uv_layer),
                        "sticky_key": _point_key(obj, loop, uv_layer, sticky),
                        "u": u,
                        "v": v,
                        "selected_source": bool(selected_source),
                    }
                    rec_by_loop[li] = len(records)
                    records.append(rec)
                    return len(records) - 1
                except Exception:
                    return None

            def attr_loop(flag_list: Sequence[bool], loop: Any) -> bool:
                li = _loop_index(loop)
                return 0 <= li < len(flag_list) and bool(flag_list[li])

            for face in bm.faces:
                try:
                    if getattr(face, "hide", False):
                        continue
                    loops = list(face.loops)
                except Exception:
                    continue
                if not loops:
                    continue
                fi = _face_index(face)
                face_selected = bool(scope_all)
                if not face_selected and mode == "FACE":
                    face_selected = _get_f(face, sync) or (not live_any and 0 <= fi < len(f_attr) and bool(f_attr[fi]))
                first_idx: Optional[int] = None
                prev_idx: Optional[int] = None
                for i, loop in enumerate(loops):
                    nloop = loop.link_loop_next
                    selected = bool(scope_all)
                    if not selected:
                        if mode == "EDGE":
                            selected = _get_e(loop, uv_layer, sync) or attr_loop(e_attr, loop)
                        elif mode == "FACE":
                            selected = face_selected
                        else:
                            selected = _get_v(loop, uv_layer, sync) or attr_loop(v_attr, loop)
                    if selected:
                        a = make(face, loop, i, selected_source=True)
                        if mode == "EDGE":
                            b = make(face, nloop, (i + 1) % len(loops), selected_source=True)
                            if a is not None and b is not None and a != b:
                                pairs.append((a, b))
                        elif mode == "FACE":
                            b = make(face, nloop, (i + 1) % len(loops), selected_source=True)
                            if a is not None and b is not None and a != b:
                                pairs.append((a, b))
                        else:
                            try:
                                next_selected = _get_v(nloop, uv_layer, sync) or attr_loop(v_attr, nloop)
                                if next_selected:
                                    b = make(face, nloop, (i + 1) % len(loops), selected_source=True)
                                    if a is not None and b is not None and a != b:
                                        pairs.append((a, b))
                            except Exception:
                                pass
                    # Add sticky-equivalent, not necessarily selected, endpoints
                    # as riders.  They are not used to create component pairs.
                    if sticky in {"SHARED_LOCATION", "SHARED_VERTEX"}:
                        key = _point_key(obj, loop, uv_layer, sticky)
                        if key is not None and key in selected_keys:
                            make(face, loop, i, selected_source=False)
            # Attach unselected sticky-equivalent rider endpoints to one selected
            # endpoint with the same sticky key.  This makes the rider move with
            # the group during G- / G| operations without using sticky keys as
            # global component-union keys.
            sticky_source: Dict[Any, int] = {}
            for i, rec in enumerate(records):
                try:
                    if rec.get("mesh") is mesh and rec.get("selected_source"):
                        key = rec.get("sticky_key")
                        if key is not None and key not in sticky_source:
                            sticky_source[key] = i
                except Exception:
                    pass
            for i, rec in enumerate(records):
                try:
                    if rec.get("mesh") is mesh or rec.get("selected_source"):
                        continue
                    key = rec.get("sticky_key")
                    src = sticky_source.get(key)
                    if src is not None and src != i:
                        pairs.append((src, i))
                except Exception:
                    pass
            # Build welded-face connectivity only from selected-source records.
            if mode == "FACE":
                edge_sig: Dict[Any, List[int]] = {}
                for i, rec in enumerate(records):
                    try:
                        if rec.get("mesh") is not mesh or not rec.get("selected_source"):
                            continue
                        loop = rec.get("loop")
                        a = _uv_key(loop, uv_layer)
                        b = _uv_key(loop.link_loop_next, uv_layer)
                        if a is None or b is None:
                            continue
                        sig = (obj_key, int(getattr(loop.edge, "index", -1)), tuple(sorted((a, b))))
                        edge_sig.setdefault(sig, []).append(i)
                    except Exception:
                        pass
                for idxs in edge_sig.values():
                    if len(idxs) > 1:
                        base = idxs[0]
                        for other in idxs[1:]:
                            pairs.append((base, other))
        return {"mode": mode, "sticky": "DISABLED", "points": _records_to_points_no_merge(records), "pairs": pairs, "meshes": meshes}

    def _records_to_points_no_merge(records: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
        points: List[Dict[str, Any]] = []
        for rec in records or []:
            try:
                points.append({"key": rec.get("record_id"), "records": [rec], "u": float(rec.get("u", 0.0)), "v": float(rec.get("v", 0.0))})
            except Exception:
                pass
        return points

    try:
        _collect_vertex_domain_1896._suv1896_patched = True  # type: ignore[attr-defined]
        d._collect_vertex_domain = _collect_vertex_domain_1896
    except Exception:
        pass


def _unpatch_direction_align_1892() -> None:
    global _ORIGINAL_1892_COLLECT
    try:
        from . import uv_direction_align_1892 as d
        if _ORIGINAL_1892_COLLECT is not None and getattr(d, "_collect_vertex_domain", None) is not _ORIGINAL_1892_COLLECT:
            d._collect_vertex_domain = _ORIGINAL_1892_COLLECT
    except Exception:
        pass
    _ORIGINAL_1892_COLLECT = None


def _register_classes() -> None:
    cls = SMARTUVSUITE_OT_sticky_select_expand_passthrough
    try:
        _suv_resource.register_class(cls)
        _REGISTERED_CLASSES.append(cls)
    except ValueError:
        _REGISTERED_CLASSES.append(cls)
    except Exception:
        pass


def _unregister_classes() -> None:
    for cls in reversed(_REGISTERED_CLASSES):
        try:
            _suv_resource.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED_CLASSES.clear()


def install(ns: Dict[str, Any], context: Any = None) -> None:
    """Compatibility-only install for the final Smart UV Suite runtime.

    The original 1.8.96 module installed pass-through keymaps and execute
    wrappers around alignment/transform operations.  Later requirements changed
    the policy: native Blender gizmos and transforms must not be intercepted by
    this add-on, and grouped alignment must compute sticky followers without
    merging selected groups.  Therefore this module now only exposes its helper
    function for older imports and actively removes its old runtime hooks.
    """
    global _NS, _INSTALLED
    _NS = ns
    try: _remove_keymaps()
    except Exception: pass
    try: _restore_alignment_operators()
    except Exception: pass
    try: _unpatch_instant_translate()
    except Exception: pass
    try: _unpatch_direction_align_1892()
    except Exception: pass
    try:
        ns["_sus_1896_expand_sticky_uv_selection"] = expand_sticky_uv_selection
    except Exception:
        pass
    _INSTALLED = True


def apply_all(ns: Dict[str, Any], context: Any = None) -> None:
    install(ns, context)


def unregister() -> None:
    global _INSTALLED
    _unpatch_direction_align_1892()
    _unpatch_instant_translate()
    _restore_alignment_operators()
    _remove_keymaps()
    _unregister_classes()
    _INSTALLED = False
