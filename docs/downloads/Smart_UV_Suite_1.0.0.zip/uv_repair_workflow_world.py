import bpy


def _measure(context, op):
    ws = getattr(context.scene, 'suv_workspace', None)
    size = op.texture_size if op.properties.is_property_set('texture_size') else getattr(ws, 'canvas_size', 2048)
    if size < 128:
        return False
    return 'FINISHED' in bpy.ops.uv.suv_texel_get(
        scope='SELECTED', texture_size=size, use_world_scale=True)


def _apply_manual_world_density(context, op):
    from .panel_tools import _warn

    ws = getattr(context.scene, 'suv_workspace', None)
    size = op.texture_size if op.properties.is_property_set('texture_size') else getattr(ws, 'canvas_size', 0)
    density = getattr(ws, 'workflow_density', 0.0)
    if size < 128 or density < 1.0:
        _warn(context, op, 'Set a texture size of at least 128 px and a target density of at least 1 px per world unit.',
              'テクスチャサイズを 128 px 以上、目標密度をワールド単位あたり 1 px 以上に設定してください。')
        return False
    return 'FINISHED' in bpy.ops.uv.suv_texel_set(
        scope='SELECTED', target_density=density, texture_size=size, use_world_scale=True)


def _process_density_preset(context, op):
    from .panel_tools import _warn

    mode = (op.mode or 'APPLY').upper()
    if mode == 'APPLY' and op.profile:
        return 'FINISHED' in bpy.ops.uv.suv_apply_density_profile(profile=op.profile)
    if mode == 'CAPTURE_CURRENT' and op.key.strip():
        return 'FINISHED' in bpy.ops.uv.suv_preset_library_io(
            mode='CAPTURE_CURRENT', library_kind='DENSITY', entry_key=op.key,
            entry_label=op.title_en, entry_label_ja=op.title_ja)
    _warn(context, op, 'Choose a density profile to apply or a named preset to capture.',
          '適用する密度プロファイル、または保存するプリセットの名前を指定してください。')
    return False


def _invoke_density_preset(context, op, event):
    if op.mode or op.profile or op.key:
        return op.execute(context)
    menu = bpy.ops.wm.call_menu
    if not bpy.app.background and menu.poll():
        return menu(name='UVSUITE_MT_DENSITY_PROFILES')
    return {'CANCELLED'}


def _lock_texture(context, op):
    context.scene.tool_settings.use_transform_correct_face_attributes = True
    return True


def _unlock_texture(context, op):
    context.scene.tool_settings.use_transform_correct_face_attributes = False
    return True


def _texture_transform_requires_view(context, op):
    from .panel_tools import _warn

    _warn(context, op, 'Invoke texture-locked movement in a 3D View while editing a mesh.',
          'メッシュの編集中に 3D ビューでテクスチャを固定した移動を起動してください。')
    return False


def _invoke_texture_transform(context, op, event):
    area = context.area
    if area is None or area.type != 'VIEW_3D':
        views = [item for item in getattr(context.screen, 'areas', ()) if item.type == 'VIEW_3D']
        area = views[0] if len(views) == 1 else None
    region = next((item for item in area.regions if item.type == 'WINDOW'), None) if area else None
    if bpy.app.background or context.mode != 'EDIT_MESH' or region is None:
        _texture_transform_requires_view(context, op)
        return {'CANCELLED'}
    settings = context.scene.tool_settings
    before = settings.use_transform_correct_face_attributes
    with context.temp_override(area=area, region=region):
        translate = bpy.ops.transform.translate
        if not translate.poll():
            _texture_transform_requires_view(context, op)
            return {'CANCELLED'}
        settings.use_transform_correct_face_attributes = True
        try:
            result = translate('INVOKE_DEFAULT')
        except RuntimeError:
            settings.use_transform_correct_face_attributes = before
            _texture_transform_requires_view(context, op)
            return {'CANCELLED'}
        if 'RUNNING_MODAL' not in result:
            settings.use_transform_correct_face_attributes = before
    return result


def build_handlers(api):
    return {
        'smart_uv_suite.workflow_world_scale_uv_measure': api.Handler(_measure, 'Measure and store texel density in pixels per world unit.', 'ワールド単位あたりのテクセル密度を測定して保存します。'),
        'smart_uv_suite.workflow_world_scale_uv_apply_manual': api.Handler(
            _apply_manual_world_density, 'Apply the configured pixels per world unit to the selected UVs.',
            '指定したワールド単位あたりのピクセル数を選択 UV に適用します。'),
        'smart_uv_suite.workflow_td_presets_processing': api.Handler(
            _process_density_preset, 'Capture current density settings as a preset or apply a saved density profile.',
            '現在の密度設定をプリセットとして保存するか、保存済みの密度プロファイルを適用します。',
            invoke=_invoke_density_preset),
        'smart_uv_suite.workflow_texture_lock_lock': api.Handler(
            _lock_texture, 'Keep textures in place during mesh transforms in this scene until unlocked.',
            '固定を解除するまで、このシーンのメッシュ変形時にテクスチャの位置を保ちます。'),
        'smart_uv_suite.workflow_texture_lock_unlock': api.Handler(
            _unlock_texture, 'Turn off texture correction for subsequent mesh transforms in this scene.',
            'このシーンで以降のメッシュ変形時のテクスチャ補正を無効にします。'),
        'smart_uv_suite.workflow_texture_lock_intr': api.Handler(
            _texture_transform_requires_view, 'Enable Texture Lock and start moving the selected mesh elements.',
            'テクスチャを固定し、選択したメッシュ要素の移動を開始します。',
            invoke=_invoke_texture_transform),
    }
