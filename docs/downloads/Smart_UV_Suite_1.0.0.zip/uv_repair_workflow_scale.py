# SPDX-License-Identifier: GPL-3.0-or-later
"""Apply the world-area matching rule to selected faces in each edit mesh."""
from .uv_area_scale import match_selected_island_scale_to_mesh_area


def build_handlers(api):
    def scale_islands(context, _operation):
        if context.mode != "EDIT_MESH":
            return False
        sync = api._sync(context)
        results = []
        for obj, edit_mesh, _layer in api._edit_targets(context):
            edit_mesh.faces.index_update()
            selected = [item.index for item in edit_mesh.faces if api._face_selected(item, sync)]
            if selected:
                results.append(match_selected_island_scale_to_mesh_area(context, obj, selected_faces=selected))
        return any(results)

    return {"smart_uv_suite.workflow_scale_uv_to_mesh": api.Handler(
        scale_islands,
        "Balance the areas of selected UV islands according to their 3D mesh areas.",
        "選択した UV アイランドの面積を、対応するワールド空間の面積に合わせます。",
    )}
