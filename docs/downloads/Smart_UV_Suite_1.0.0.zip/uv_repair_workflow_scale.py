from .uv_area_scale import match_selected_island_scale_to_mesh_area


def build_handlers(api):
    def scale(context, op):
        if context.mode != 'EDIT_MESH':
            return False
        synced = api._sync(context)
        changed = False
        for obj, bm, _ in api._edit_targets(context):
            bm.faces.index_update()
            faces = [face.index for face in bm.faces if api._face_selected(face, synced)]
            if faces:
                changed |= match_selected_island_scale_to_mesh_area(context, obj, selected_faces=faces)
        return changed

    return {
        'smart_uv_suite.workflow_scale_uv_to_mesh': api.Handler(scale, 'Make selected UV island areas proportional to their world-space mesh areas.', '選択 UV アイランドの面積をワールド空間のメッシュ面積に比例させます。'),
    }
