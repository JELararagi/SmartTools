# SPDX-License-Identifier: GPL-3.0-or-later
"""Expose new UV channels through the workflow operator catalog."""
from .uv_map_channels import add_map_channel


def build_handlers(api):
    def add_channel(context, operation):
        result = add_map_channel(context, name=operation.name)
        return bool(result[0])

    return {"smart_uv_suite.workflow_add": api.Handler(
        add_channel,
        "Create a new UV map and activate it for editing.",
        "UV マップを追加し、編集対象に切り替えます。",
    )}
