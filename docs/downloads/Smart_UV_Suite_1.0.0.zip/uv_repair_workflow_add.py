from .uv_map_channels import add_map_channel


def _add(context, op):
    ok, _, _ = add_map_channel(context, name=op.name)
    return ok


def build_handlers(api):
    return {
        'smart_uv_suite.workflow_add': api.Handler(_add, 'Add a UV map channel and make it the active editing target.', 'UV マップチャンネルを追加してアクティブな編集対象にします。'),
    }
