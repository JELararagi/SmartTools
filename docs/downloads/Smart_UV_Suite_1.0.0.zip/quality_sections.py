# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None

_NAMESPACE = {}
_REGISTERED = []
_PROPS = {
    'workflow': 'suv_quality_show_section_workflow',
    'learning': 'suv_quality_show_section_learning',
    'maintenance': 'suv_quality_show_section_maintenance',
}
_LABELS = {
    'workflow': ('Workflow', 'ワークフロー'),
    'learning': ('Guides', 'ガイド'),
    'maintenance': ('Reports', 'レポート'),
}


def _tr(context, key: str, en: str, ja: str, **fmt) -> str:
    fn = _NAMESPACE.get('tr')
    text = None
    if callable(fn):
        try:
            text = fn(context, key, **fmt)
        except Exception:
            text = None
    if not text:
        text = en
    try:
        return text.format(**fmt)
    except Exception:
        return text


def _wm(context):
    try:
        return getattr(context, 'window_manager', None)
    except Exception:
        return None


def _normalize_section(section_id: str) -> str:
    section_id = str(section_id or '').strip().lower()
    return section_id if section_id in _PROPS else 'workflow'


def get_section_visibility(context, section_id: str) -> bool:
    wm = _wm(context)
    key = _PROPS.get(_normalize_section(section_id))
    if wm is None or not key:
        return True
    try:
        return bool(getattr(wm, key, True))
    except Exception:
        return True



def set_section_visibility(context, section_id: str, value: bool) -> bool:
    wm = _wm(context)
    key = _PROPS.get(_normalize_section(section_id))
    if wm is None or not key:
        return bool(value)
    try:
        setattr(wm, key, bool(value))
    except Exception:
        pass
    return bool(value)



def _count_section_cards(sections, section_id: str) -> int:
    total = 0
    for section in sections or []:
        if str(section.get('id', '') or '') != section_id:
            continue
        total += len(section.get('cards', []) or [])
    return int(total)



def apply_section_visibility(namespace: dict, context, sections: list[dict]) -> dict:
    visible_sections = []
    total = len(sections or [])
    hidden = 0
    visible_card_total = 0
    hidden_card_total = 0
    visibility = {}
    for section in sections or []:
        sid = str(section.get('id', '') or '')
        shown = get_section_visibility(context, sid)
        visibility[sid] = bool(shown)
        card_count = len(section.get('cards', []) or [])
        if shown:
            visible_sections.append(section)
            visible_card_total += card_count
        else:
            hidden += 1
            hidden_card_total += card_count
    data = {
        'sections': visible_sections,
        'visibility': visibility,
        'total_sections': int(total),
        'visible_sections': int(len(visible_sections)),
        'hidden_sections': int(hidden),
        'hidden_cards_by_section': int(hidden_card_total),
        'visible_cards_by_section': int(visible_card_total),
    }
    namespace['_suv_section_visibility_last'] = dict(data)
    return data



def scan_section_controls(namespace: dict, context) -> dict:
    cards_mod = namespace.get('_quality_cards_module')
    translate = namespace.get('_quality_visual_translate')
    if not callable(translate):
        translate = lambda ctx, key, en, ja: en
    raw_sections = []
    if cards_mod is not None and hasattr(cards_mod, '_raw_sections'):
        try:
            raw_sections = cards_mod._raw_sections(namespace, context, translate) or []
        except Exception:
            raw_sections = []
    visibility = {sid: get_section_visibility(context, sid) for sid in _PROPS}
    visible = int(sum(1 for value in visibility.values() if value))
    hidden = int(len(_PROPS) - visible)
    total_cards = int(sum(_count_section_cards(raw_sections, sid) for sid in _PROPS))
    hidden_cards = int(sum(_count_section_cards(raw_sections, sid) for sid, shown in visibility.items() if not shown))
    data = {
        'visibility': visibility,
        'visible_sections': visible,
        'hidden_sections': hidden,
        'total_sections': len(_PROPS),
        'total_cards': total_cards,
        'hidden_cards': hidden_cards,
    }
    namespace['_suv_section_visibility_scan_last'] = dict(data)
    return data


class SUV_OT_quality_set_section_visibility(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_set_section_visibility'
    bl_label = 'Set Section Visibility'
    bl_description = 'Show or hide a dashboard section to keep the quick guide compact. / ダッシュボードのセクション表示を切り替えて、クイックガイドをコンパクトに保ちます。'
    bl_options = set()

    section_id: bpy.props.EnumProperty(
        name='Section',
        description='Section to control / 表示を切り替えるセクション',
        items=(
            ('workflow', 'Workflow', 'Workflow and setup section / ワークフローと準備セクション'),
            ('learning', 'Guides', 'Guides and language section / ガイドと言語セクション'),
            ('maintenance', 'Reports', 'Reports and maintenance section / レポートと保守セクション'),
            ('all', 'All', 'Affect every section / 全セクションに適用'),
        ),
        default='workflow',
    )
    visible: bpy.props.BoolProperty(
        name='Visible',
        description='Whether the section should stay visible / セクションを表示状態にするかどうか',
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        targets = list(_PROPS) if self.section_id == 'all' else [_normalize_section(self.section_id)]
        for sid in targets:
            set_section_visibility(context, sid, self.visible)
        controls_mod = _NAMESPACE.get('_quality_controls_module')
        if controls_mod is not None and hasattr(controls_mod, 'notify_controls_changed'):
            try:
                controls_mod.notify_controls_changed(_NAMESPACE, context, reason='section-toggle')
            except Exception:
                pass
        label_en, label_ja = _LABELS.get(_normalize_section(targets[0]), ('All', '全体')) if len(targets) == 1 else ('All', '全体')
        state_en = 'shown' if self.visible else 'hidden'
        state_ja = '表示' if self.visible else '非表示'
        self.report({'INFO'}, _tr(context, 'msg.quality_section_visibility_set', 'Section {section} is now {state}.', 'セクション {section} を {state} にしました。', section=_tr(context, f'ui.visual.section_toggle.{targets[0] if len(targets)==1 else "all"}', label_en, label_ja), state=_tr(context, f'ui.visual.section_state.{"shown" if self.visible else "hidden"}', state_en, state_ja)))
        return {'FINISHED'}


class SUV_OT_quality_reset_section_visibility(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_reset_section_visibility'
    bl_label = 'Reset Section Visibility'
    bl_description = 'Show every dashboard section again. / 非表示にしたダッシュボードセクションをすべて再表示します。'
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        for sid in _PROPS:
            set_section_visibility(context, sid, True)
        controls_mod = _NAMESPACE.get('_quality_controls_module')
        if controls_mod is not None and hasattr(controls_mod, 'notify_controls_changed'):
            try:
                controls_mod.notify_controls_changed(_NAMESPACE, context, reason='section-reset')
            except Exception:
                pass
        self.report({'INFO'}, _tr(context, 'msg.quality_section_visibility_reset', 'All dashboard sections are visible again.', 'ダッシュボードの全セクションを再表示しました。'))
        return {'FINISHED'}



def register(namespace: dict):
    global _NAMESPACE
    _NAMESPACE = namespace if isinstance(namespace, dict) else {}
    if bpy is None:
        return []
    classes = [SUV_OT_quality_set_section_visibility, SUV_OT_quality_reset_section_visibility]
    reg = []
    for cls in classes:
        try:
            _suv_resource.register_class(cls)
            reg.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = reg
    try:
        for sid, prop_name in _PROPS.items():
            if not hasattr(bpy.types.WindowManager, prop_name):
                en, ja = _LABELS[sid]
                _suv_resource.register_property(
                    bpy.types.WindowManager,
                    prop_name,
                    bpy.props.BoolProperty(
                        name=en,
                        description=f'{en} section visibility / {ja}セクションの表示',
                        default=True,
                    )
                )
    except Exception:
        pass
    return reg



def unregister(namespace: dict | None = None):
    if bpy is None:
        return []
    removed = []
    for cls in reversed(list(_REGISTERED)):
        try:
            _suv_resource.unregister_class(cls)
            removed.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = []
    try:
        for prop_name in _PROPS.values():
            _suv_resource.unregister_property(bpy.types.WindowManager, prop_name)
    except Exception:
        pass
    return removed
