from . import _sus_direct_normal_projection
from .core import _selection_from_context
import bmesh


def _project(context, op):
    if context.mode != 'EDIT_MESH':
        return False
    changed = False
    for obj in context.objects_in_mode_unique_data:
        bm = bmesh.from_edit_mesh(obj.data)
        layer = bm.loops.layers.uv.active
        if layer is None:
            continue
        bm.faces.index_update()
        bm.normal_update()
        faces, _, _, _ = _selection_from_context(context, obj, bm, layer)
        indices = {face.index for face in faces if not face.hide}
        if indices:
            changed |= _sus_direct_normal_projection(context, obj, {'selected_faces': indices})
    return changed


def build_handlers(api):
    return {
        'smart_uv_suite.unwrap_project': api.Handler(_project, 'Project selected faces onto the plane facing their dominant normal.', '選択面を主法線に対応する平面へ投影します。'),
    }
