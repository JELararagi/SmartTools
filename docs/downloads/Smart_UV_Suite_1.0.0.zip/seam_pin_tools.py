# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Seam / Pin upgrades for Smart UV Suite.

This module keeps Blender-standard mesh seam flags at the center of seam work.
It provides:
- 3D View selected-edge Mark Seam / Clear Seam operators callable from the UV UI.
- Advanced automatic seam scoring, including cylinder/tube longitudinal cuts.
- Optional post-unwrap compliance that writes UV island borders back to mesh
  seam flags and re-unwraps from those marks so the final split graph matches
  Blender's Mark Seam concept.
"""
from . import resource_api_18168 as _suv_resource
import heapq
import json
import math
from pathlib import Path
from typing import Any, Iterable

import bpy
import bmesh
from mathutils import Vector

_REGISTERED: list[type] = []
_EPS = 1.0e-7


def _ws(context=None):
    try:
        return getattr(getattr((context or bpy.context), 'scene', None), 'suv_workspace', None)
    except Exception:
        return None


def _is_ja(context=None) -> bool:
    try:
        view = getattr(getattr(context or bpy.context, 'preferences', None), 'view', None)
        if view is not None and not bool(getattr(view, 'use_translate_interface', True)):
            return False
        language = str(getattr(view, 'language', '') or '') if view is not None else ''
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '')
        raw = (locale or language).lower()
        return raw.startswith('ja') or raw == 'default_japanese' or 'japanese' in raw
    except Exception:
        return False


def _t(context, en: str, ja: str) -> str:
    return ja if _is_ja(context) else en


def _active_mesh(context=None):
    ctx = context or bpy.context
    for attr in ('edit_object', 'active_object', 'object'):
        obj = getattr(ctx, attr, None)
        if obj is not None and getattr(obj, 'type', '') == 'MESH':
            return obj
    try:
        obj = ctx.view_layer.objects.active
        if obj is not None and getattr(obj, 'type', '') == 'MESH':
            return obj
    except Exception:
        pass
    return None


def _set_active(context, obj) -> None:
    if obj is None:
        return
    try:
        context.view_layer.objects.active = obj
    except Exception:
        pass
    try:
        obj.select_set(True)
    except Exception:
        pass


def _mode_set(mode: str) -> bool:
    try:
        if getattr(bpy.context.object, 'mode', '') != mode:
            bpy.ops.object.mode_set(mode=mode)
        return True
    except Exception:
        return False


def _mesh_bool_values(me, name: str) -> list[bool]:
    try:
        attrs = getattr(me, 'attributes', None)
        if attrs is None:
            return []
        attr = attrs.get(name)
        if attr is None:
            return []
        return [bool(getattr(item, 'value', False)) for item in getattr(attr, 'data', [])]
    except Exception:
        return []


def _ensure_bool_attr(me, name: str, domain: str):
    try:
        attrs = getattr(me, 'attributes', None)
        if attrs is None:
            return None
        attr = attrs.get(name)
        if attr is None:
            attr = attrs.new(name=name, type='BOOLEAN', domain=domain)
        return attr
    except Exception:
        return None


def _read_uv_select_attrs_object_mode(context, obj) -> dict[str, list[bool]]:
    me = getattr(obj, 'data', None)
    if me is None:
        return {'face': [], 'vert': [], 'edge': []}
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed = False
    try:
        if old_mode != 'OBJECT':
            try:
                bpy.ops.object.mode_set(mode='OBJECT')
                changed = True
            except Exception:
                pass
        return {
            'face': _mesh_bool_values(me, '.uv_select_face'),
            'vert': _mesh_bool_values(me, '.uv_select_vert'),
            'edge': _mesh_bool_values(me, '.uv_select_edge'),
        }
    finally:
        if changed:
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                try:
                    bpy.ops.object.mode_set(mode='EDIT')
                except Exception:
                    pass


def _write_uv_selection_attrs_object_mode(context, obj, selected_faces: set[int]) -> None:
    me = getattr(obj, 'data', None)
    if me is None:
        return
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed = False
    try:
        if old_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
            changed = True
        uv_vert = _ensure_bool_attr(me, '.uv_select_vert', 'CORNER')
        uv_edge = _ensure_bool_attr(me, '.uv_select_edge', 'CORNER')
        uv_face = _ensure_bool_attr(me, '.uv_select_face', 'FACE')
        face_flags = [False] * len(getattr(me, 'polygons', []) or [])
        loop_flags = [False] * len(getattr(me, 'loops', []) or [])
        selected_faces = {int(i) for i in selected_faces}
        for poly in getattr(me, 'polygons', []) or []:
            try:
                flag = int(poly.index) in selected_faces
                face_flags[int(poly.index)] = bool(flag)
            except Exception:
                flag = False
            for li in list(getattr(poly, 'loop_indices', []) or []):
                if 0 <= int(li) < len(loop_flags):
                    loop_flags[int(li)] = bool(flag)
        if uv_vert is not None:
            for i, flag in enumerate(loop_flags):
                if i < len(uv_vert.data):
                    try:
                        uv_vert.data[i].value = bool(flag)
                    except Exception:
                        pass
        if uv_edge is not None:
            for i, flag in enumerate(loop_flags):
                if i < len(uv_edge.data):
                    try:
                        uv_edge.data[i].value = bool(flag)
                    except Exception:
                        pass
        if uv_face is not None:
            for i, flag in enumerate(face_flags):
                if i < len(uv_face.data):
                    try:
                        uv_face.data[i].value = bool(flag)
                    except Exception:
                        pass
    except Exception:
        pass
    finally:
        if changed:
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                try:
                    bpy.ops.object.mode_set(mode='EDIT')
                except Exception:
                    pass


def _selected_uv_face_indices(context, obj, bm, uv_layer, *, fallback_mesh_selection: bool = True) -> set[int]:
    attrs = _read_uv_select_attrs_object_mode(context, obj)
    face_flags = list(attrs.get('face') or [])
    vert_flags = list(attrs.get('vert') or [])
    selected: set[int] = set()
    try:
        bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
        bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
    except Exception:
        pass
    if face_flags and any(face_flags):
        for face in bm.faces:
            fi = int(getattr(face, 'index', -1))
            if fi < 0 or fi >= len(face_flags) or not bool(face_flags[fi]):
                continue
            loops = list(getattr(face, 'loops', ()) or ())
            if not loops:
                continue
            if vert_flags:
                all_corners = True
                for loop in loops:
                    li = int(getattr(loop, 'index', -1))
                    if li < 0 or li >= len(vert_flags) or not bool(vert_flags[li]):
                        all_corners = False
                        break
                if not all_corners:
                    continue
            selected.add(fi)
        return selected

    # Fallback when hidden attributes are unavailable: require every UV corner.
    for face in bm.faces:
        loops = list(getattr(face, 'loops', ()) or ())
        if not loops:
            continue
        all_corners = True
        any_corner = False
        for loop in loops:
            try:
                luv = loop[uv_layer]
                corner = bool(getattr(luv, 'select', False))
                any_corner = any_corner or corner or bool(getattr(luv, 'select_edge', False))
                if not corner:
                    all_corners = False
            except Exception:
                all_corners = False
        if all_corners and any_corner:
            selected.add(int(getattr(face, 'index', -1)))
    if selected or not fallback_mesh_selection:
        return selected
    for face in bm.faces:
        try:
            if bool(getattr(face, 'select', False)):
                selected.add(int(getattr(face, 'index', -1)))
        except Exception:
            pass
    return selected


def _capture_mesh_selection(bm) -> dict[str, dict[int, bool]]:
    try:
        return {
            'face': {int(f.index): bool(getattr(f, 'select', False)) for f in bm.faces},
            'edge': {int(e.index): bool(getattr(e, 'select', False)) for e in bm.edges},
            'vert': {int(v.index): bool(getattr(v, 'select', False)) for v in bm.verts},
        }
    except Exception:
        return {'face': {}, 'edge': {}, 'vert': {}}


def _restore_mesh_selection(bm, state: dict[str, dict[int, bool]]) -> None:
    try:
        f_map = {int(f.index): f for f in bm.faces}
        e_map = {int(e.index): e for e in bm.edges}
        v_map = {int(v.index): v for v in bm.verts}
        for idx, flag in dict(state.get('face') or {}).items():
            f = f_map.get(int(idx))
            if f is not None:
                try: f.select_set(bool(flag))
                except Exception: f.select = bool(flag)
        for idx, flag in dict(state.get('edge') or {}).items():
            e = e_map.get(int(idx))
            if e is not None:
                try: e.select_set(bool(flag))
                except Exception: e.select = bool(flag)
        for idx, flag in dict(state.get('vert') or {}).items():
            v = v_map.get(int(idx))
            if v is not None:
                try: v.select_set(bool(flag))
                except Exception: v.select = bool(flag)
    except Exception:
        pass


def _loop_for_edge(face, edge):
    try:
        for loop in face.loops:
            if loop.edge == edge:
                return loop
    except Exception:
        pass
    return None


def _edge_uv_segment(face, edge, uv_layer):
    loop = _loop_for_edge(face, edge)
    if loop is None:
        return None
    try:
        # UV of edge.verts[0], then edge.verts[1], so two faces can be compared vertex by vertex.
        a, b = loop[uv_layer].uv.copy(), loop.link_loop_next[uv_layer].uv.copy()
        return (a, b) if loop.vert == edge.verts[0] else (b, a)
    except Exception:
        return None


def _segments_match(seg_a, seg_b, eps: float = 1.0e-5) -> bool:
    if seg_a is None or seg_b is None:
        return False
    a0, a1 = seg_a
    b0, b1 = seg_b
    try:
        return bool((a0 - b0).length <= eps and (a1 - b1).length <= eps)
    except Exception:
        return False


def mark_mesh_seams_from_current_uv_islands(context=None, *, selected_faces: set[int] | None = None, margin_method: str = 'ANGLE_BASED', clear_internal: bool = True) -> int:
    """Synchronize mesh seam flags to current UV island borders in selected scope."""
    ctx = context or bpy.context
    obj = _active_mesh(ctx)
    if obj is None:
        return 0
    _set_active(ctx, obj)
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed = False
    if old_mode != 'EDIT':
        if not _mode_set('EDIT'):
            return 0
        changed = True
    count = 0
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        try:
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
        except Exception:
            pass
        if selected_faces is None:
            selected_faces = _selected_uv_face_indices(ctx, obj, bm, uv_layer, fallback_mesh_selection=True)
        selected_faces = {int(i) for i in (selected_faces or set())}
        if not selected_faces:
            return 0
        face_map = {int(f.index): f for f in bm.faces}
        for edge in bm.edges:
            linked = [f for f in getattr(edge, 'link_faces', []) or [] if int(getattr(f, 'index', -1)) in selected_faces]
            if not linked:
                continue
            new_flag = False
            if len(linked) == 1:
                # Detach selected UV domain from unselected neighbours and open boundaries.
                new_flag = True
            else:
                # If any selected face pair is UV-discontinuous, that mesh edge is a seam.
                base = linked[0]
                for other in linked[1:]:
                    if not _segments_match(_edge_uv_segment(base, edge, uv_layer), _edge_uv_segment(other, edge, uv_layer)):
                        new_flag = True
                        break
            old_flag = bool(getattr(edge, 'seam', False))
            try:
                clear_internal = True
                try:
                    ws = _ws(ctx)
                    if ws is not None and hasattr(ws, 'seam_mark_compliance_clear_internal'):
                        clear_internal = bool(getattr(ws, 'seam_mark_compliance_clear_internal'))
                except Exception:
                    clear_internal = True
                target_flag = bool(new_flag) or (old_flag and not clear_internal)
                edge.seam = bool(target_flag)
                if old_flag != bool(target_flag):
                    count += 1
            except Exception:
                pass
        try:
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        except Exception:
            pass
        return int(count)
    finally:
        if changed and old_mode != 'EDIT':
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                pass


def marked_seam_compliance_enabled(context=None) -> bool:
    ws = _ws(context)
    try:
        # Current public setting name.  The older unwrap_marked_seam_compliance
        # name is kept only for compatibility with intermediate builds.
        if ws is not None and hasattr(ws, 'suv_seam_mark_compliance'):
            return bool(getattr(ws, 'suv_seam_mark_compliance'))
        if ws is not None and hasattr(ws, 'seam_mark_compliant_unwrap'):
            return bool(getattr(ws, 'seam_mark_compliant_unwrap'))
        if ws is not None and hasattr(ws, 'unwrap_marked_seam_compliance'):
            return bool(getattr(ws, 'unwrap_marked_seam_compliance'))
    except Exception:
        pass
    return True


def apply_marked_seam_compliance(context=None, *, method: str = 'ANGLE_BASED', margin: float = 0.001, force: bool = False, selected_faces: set[int] | None = None) -> bool:
    """Make the final unwrap agree with Blender mesh seam flags.

    The current UV islands inside the strict UV-face selection are converted to
    mesh seam flags, then the same selected faces are unwrapped from those marks.
    3D View mesh selection is restored afterward.
    """
    ctx = context or bpy.context
    if not force and not marked_seam_compliance_enabled(ctx):
        return False
    obj = _active_mesh(ctx)
    if obj is None:
        return False
    _set_active(ctx, obj)
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed = False
    if old_mode != 'EDIT':
        if not _mode_set('EDIT'):
            return False
        changed = True
    mesh_state = None
    selected_faces: set[int] = set()
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        try:
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
        except Exception:
            pass
        if selected_faces is None:
            selected_faces = _selected_uv_face_indices(ctx, obj, bm, uv_layer, fallback_mesh_selection=True)
        selected_faces = {int(i) for i in (selected_faces or set())}
        if not selected_faces:
            return False
        mesh_state = _capture_mesh_selection(bm)
        # Write seam marks from the actual UV island discontinuities in scope.
        mark_mesh_seams_from_current_uv_islands(ctx, selected_faces=selected_faces, clear_internal=marked_seam_clear_internal_enabled(ctx))
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        try:
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
        except Exception:
            pass
        selected_verts = set()
        selected_edges = set()
        for face in bm.faces:
            in_scope = int(getattr(face, 'index', -1)) in selected_faces
            try: face.select_set(bool(in_scope))
            except Exception: face.select = bool(in_scope)
            for loop in face.loops:
                try:
                    loop[uv_layer].select = bool(in_scope)
                    loop[uv_layer].select_edge = bool(in_scope)
                except Exception:
                    pass
            if in_scope:
                selected_verts.update(face.verts)
                selected_edges.update(face.edges)
        for edge in bm.edges:
            try: edge.select_set(edge in selected_edges)
            except Exception: edge.select = edge in selected_edges
        for vert in bm.verts:
            try: vert.select_set(vert in selected_verts)
            except Exception: vert.select = vert in selected_verts
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        attempts = (
            dict(method=str(method or 'ANGLE_BASED').upper(), margin=float(margin), fill_holes=True, correct_aspect=True),
            dict(method=str(method or 'ANGLE_BASED').upper(), margin=float(margin)),
            dict(method=str(method or 'ANGLE_BASED').upper()),
        )
        ok = False
        for kwargs in attempts:
            try:
                result = bpy.ops.uv.unwrap(**kwargs)
                ok = 'FINISHED' in set(result or set())
                if ok:
                    break
            except TypeError:
                continue
            except Exception:
                continue
        # Re-write seam flags once more because native unwrap can merge/normalize.
        try:
            mark_mesh_seams_from_current_uv_islands(ctx, selected_faces=selected_faces, clear_internal=marked_seam_clear_internal_enabled(ctx))
        except Exception:
            pass
        # Restore 3D selection and leave only the UV-face scope selected.
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        try:
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
        except Exception:
            pass
        if mesh_state is not None:
            _restore_mesh_selection(bm, mesh_state)
        for face in bm.faces:
            in_scope = int(getattr(face, 'index', -1)) in selected_faces
            for loop in face.loops:
                try:
                    loop[uv_layer].select = bool(in_scope)
                    loop[uv_layer].select_edge = bool(in_scope)
                except Exception:
                    pass
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        _write_uv_selection_attrs_object_mode(ctx, obj, selected_faces)
        return bool(ok)
    finally:
        if changed and old_mode != 'EDIT':
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                pass


def _edge_direction(edge) -> Vector:
    try:
        verts = list(edge.verts)
        if len(verts) >= 2:
            vec = Vector(verts[1].co) - Vector(verts[0].co)
            if vec.length > _EPS:
                return vec.normalized()
    except Exception:
        pass
    return Vector((0.0, 0.0, 0.0))


def _edge_length(edge) -> float:
    try:
        return float(edge.calc_length())
    except Exception:
        try:
            return float((edge.verts[1].co - edge.verts[0].co).length)
        except Exception:
            return 0.0


def _edge_midpoint(edge) -> Vector:
    try:
        return (Vector(edge.verts[0].co) + Vector(edge.verts[1].co)) * 0.5
    except Exception:
        return Vector((0.0, 0.0, 0.0))


def _bounds_axis_for_faces(faces: Iterable) -> tuple[Vector, int]:
    coords = []
    for face in faces:
        for vert in getattr(face, 'verts', []) or []:
            coords.append(Vector(vert.co))
    if not coords:
        return Vector((0.0, 0.0, 1.0)), 2
    mins = Vector((min(v.x for v in coords), min(v.y for v in coords), min(v.z for v in coords)))
    maxs = Vector((max(v.x for v in coords), max(v.y for v in coords), max(v.z for v in coords)))
    span = maxs - mins
    axis_idx = max(((abs(span.x), 0), (abs(span.y), 1), (abs(span.z), 2)), key=lambda x: x[0])[1]
    return (Vector((1, 0, 0)) if axis_idx == 0 else Vector((0, 1, 0)) if axis_idx == 1 else Vector((0, 0, 1))), axis_idx


def _axis_from_settings(settings: dict[str, Any], faces: Iterable) -> tuple[Vector, int]:
    mode = str(settings.get('cylinder_axis', 'AUTO') or 'AUTO').upper()
    if mode == 'X':
        return Vector((1, 0, 0)), 0
    if mode == 'Y':
        return Vector((0, 1, 0)), 1
    if mode == 'Z':
        return Vector((0, 0, 1)), 2
    return _bounds_axis_for_faces(faces)


def _radial_basis(axis_idx: int) -> tuple[Vector, Vector]:
    if axis_idx == 0:
        return Vector((0, 1, 0)), Vector((0, 0, 1))
    if axis_idx == 1:
        return Vector((1, 0, 0)), Vector((0, 0, 1))
    return Vector((1, 0, 0)), Vector((0, 1, 0))


def _angle_wrap_delta(a: float, b: float) -> float:
    d = abs(float(a) - float(b)) % (math.tau)
    return min(d, math.tau - d)


def _loop_continuity_score(edge, candidate_set: set, axis: Vector | None = None) -> float:
    dirs = []
    d = _edge_direction(edge)
    if d.length <= _EPS:
        return 0.0
    for vert in getattr(edge, 'verts', []) or []:
        best = 0.0
        for other in getattr(vert, 'link_edges', []) or []:
            if other == edge or other not in candidate_set:
                continue
            od = _edge_direction(other)
            if od.length <= _EPS:
                continue
            align = abs(float(d.dot(od)))
            if axis is not None and axis.length > _EPS:
                # On tubes, reward continuations along the cylinder length.
                align = max(align, abs(float(od.dot(axis.normalized()))))
            best = max(best, align)
        dirs.append(best)
    if not dirs:
        return 0.0
    return max(0.0, min(100.0, 100.0 * sum(dirs) / max(1, len(dirs))))


def _edge_basic_features(edge, angle_threshold: float) -> dict[str, float | bool]:
    faces = list(getattr(edge, 'link_faces', []) or [])
    boundary = len(faces) < 2
    nonmanifold = len(faces) != 2
    angle = 0.0
    angle_score = 0.0
    material = False
    planarity_score = 0.0
    density_score = 0.0
    if len(faces) == 2:
        try:
            angle = float(edge.calc_face_angle(0.0))
        except Exception:
            angle = 0.0
        threshold = max(1.0e-6, float(angle_threshold))
        angle_score = max(0.0, min(100.0, 100.0 * angle / threshold))
        planarity_score = max(0.0, min(100.0, 100.0 * angle / math.pi))
        try:
            material = int(faces[0].material_index) != int(faces[1].material_index)
        except Exception:
            material = False
        try:
            a0 = max(1.0e-12, float(faces[0].calc_area()))
            a1 = max(1.0e-12, float(faces[1].calc_area()))
            ratio = max(a0 / a1, a1 / a0)
            density_score = max(0.0, min(100.0, (ratio - 1.0) * 38.0))
        except Exception:
            density_score = 0.0
    sharp = False
    try:
        sharp = not bool(getattr(edge, 'smooth', True))
    except Exception:
        sharp = False
    return {
        'boundary': boundary,
        'nonmanifold': nonmanifold,
        'angle': angle,
        'angle_score': angle_score,
        'material': material,
        'sharp': sharp,
        'planarity_score': planarity_score,
        'density_score': density_score,
        'existing': bool(getattr(edge, 'seam', False)),
    }


def _settings_float(ws, names: tuple[str, ...], default: float, lo: float | None = None, hi: float | None = None) -> float:
    for name in names:
        try:
            if ws is not None and hasattr(ws, name):
                v = float(getattr(ws, name))
                if v == v:
                    if lo is not None:
                        v = max(float(lo), v)
                    if hi is not None:
                        v = min(float(hi), v)
                    return v
        except Exception:
            pass
    return float(default)


def _settings_bool(ws, names: tuple[str, ...], default: bool) -> bool:
    for name in names:
        try:
            if ws is not None and hasattr(ws, name):
                return bool(getattr(ws, name))
        except Exception:
            pass
    return bool(default)


def _settings_enum(ws, names: tuple[str, ...], default: str) -> str:
    for name in names:
        try:
            if ws is not None and hasattr(ws, name):
                return str(getattr(ws, name) or default).upper()
        except Exception:
            pass
    return str(default).upper()


def _angle_threshold_radians(ws, operator=None) -> float:
    """Read public angle settings.  Newer UI stores radians; legacy profile UI stores degrees."""
    try:
        if ws is not None and hasattr(ws, 'auto_seam_angle_threshold'):
            raw = float(getattr(ws, 'auto_seam_angle_threshold'))
            if raw == raw:
                return max(0.0, min(math.pi, raw if raw <= math.pi + 1.0e-6 else math.radians(raw)))
    except Exception:
        pass
    try:
        if ws is not None and hasattr(ws, 'auto_seam_angle_threshold_deg'):
            return math.radians(max(0.0, min(180.0, float(getattr(ws, 'auto_seam_angle_threshold_deg')))))
    except Exception:
        pass
    try:
        if ws is not None and hasattr(ws, 'suv_auto_seam_angle_threshold'):
            raw = float(getattr(ws, 'suv_auto_seam_angle_threshold'))
            return math.radians(max(0.0, min(180.0, raw)))
    except Exception:
        pass
    try:
        raw = float(getattr(operator, 'angle_threshold', math.radians(60.0))) if operator is not None else math.radians(60.0)
        return max(0.0, min(math.pi, raw if raw <= math.pi + 1.0e-6 else math.radians(raw)))
    except Exception:
        return math.radians(60.0)



def _settings_angle_radians(ws, degree_names: tuple[str, ...], radian_names: tuple[str, ...], default_deg: float) -> float:
    for name in degree_names:
        try:
            if ws is not None and hasattr(ws, name):
                return math.radians(max(0.0, min(180.0, float(getattr(ws, name)))))
        except Exception:
            pass
    for name in radian_names:
        try:
            if ws is not None and hasattr(ws, name):
                value = float(getattr(ws, name))
                if value <= math.pi + 1.0e-6:
                    return max(0.0, min(math.pi, value))
                return math.radians(max(0.0, min(180.0, value)))
        except Exception:
            pass
    return math.radians(max(0.0, min(180.0, float(default_deg))))


def _settings_preset(ws) -> str:
    """Resolve new and legacy auto-seam preset properties without losing either UI path.

    The current stable UI exposes suv_auto_seam_profile, while older builds and
    some native paths still write auto_seam_preset.  If either one is set to a
    non-default preset, that explicit value wins; otherwise BALANCED is used.
    """
    auto_raw = None
    suv_raw = None
    try:
        if ws is not None and hasattr(ws, 'auto_seam_preset'):
            auto_raw = str(getattr(ws, 'auto_seam_preset') or '').upper()
    except Exception:
        auto_raw = None
    try:
        if ws is not None and hasattr(ws, 'suv_auto_seam_profile'):
            suv_raw = str(getattr(ws, 'suv_auto_seam_profile') or '').upper()
    except Exception:
        suv_raw = None
    explicit_auto = auto_raw and auto_raw not in {'MANUAL', 'CUSTOM', 'BALANCED'}
    explicit_suv = suv_raw and suv_raw not in {'CUSTOM', 'BALANCED'}
    if explicit_auto:
        preset = auto_raw
    elif explicit_suv:
        preset = suv_raw
    else:
        preset = suv_raw or auto_raw or 'BALANCED'
    mapping = {
        'CYLINDER': 'CYLINDER_TUBE',
        'CYLINDER_SINGLE': 'CYLINDER_TUBE',
        'MARK_SEAM_COMPLIANT': 'BALANCED',
        'MANUAL': 'CUSTOM',
    }
    return mapping.get(str(preset or 'BALANCED').upper(), str(preset or 'BALANCED').upper())

def auto_seam_settings(context=None, operator=None) -> dict[str, Any]:
    ws = _ws(context)
    angle_default = math.degrees(float(getattr(operator, 'angle_threshold', math.radians(60.0)))) if operator is not None else 60.0
    preset = _settings_preset(ws)
    scope_default = str(getattr(operator, 'scope', 'SELECTED') if operator is not None else 'SELECTED')
    clear_default = bool(getattr(operator, 'clear_existing', False) if operator is not None else False)
    settings = {
        'preset': preset,
        'scope': _settings_enum(ws, ('auto_seam_scope',), scope_default),
        'clear_existing': _settings_bool(ws, ('suv_auto_seam_clear_existing', 'auto_seam_clear_existing'), clear_default),
        'angle_threshold': _settings_angle_radians(ws, ('suv_auto_seam_angle_threshold', 'auto_seam_angle_threshold_deg'), ('auto_seam_angle_threshold',), angle_default),
        'score_threshold': _settings_float(ws, ('suv_auto_seam_min_score', 'auto_seam_mark_threshold', 'auto_seam_score_threshold'), 54.0, 0.0, 100.0),
        'angle_weight': _settings_float(ws, ('suv_auto_seam_angle_weight', 'auto_seam_angle_weight'), 70.0, 0.0, 100.0),
        'sharp_weight': _settings_float(ws, ('suv_auto_seam_sharp_weight', 'auto_seam_sharp_weight'), 45.0, 0.0, 100.0),
        'material_weight': _settings_float(ws, ('suv_auto_seam_material_weight', 'auto_seam_material_weight'), 35.0, 0.0, 100.0),
        'boundary_weight': _settings_float(ws, ('suv_auto_seam_boundary_weight', 'auto_seam_boundary_weight', 'auto_seam_nonmanifold_weight'), 35.0, 0.0, 100.0),
        'loop_weight': _settings_float(ws, ('suv_auto_seam_loop_weight', 'auto_seam_loop_weight'), 45.0, 0.0, 100.0),
        'cylinder_strength': _settings_float(ws, ('suv_auto_seam_tube_weight', 'auto_seam_cylinder_weight', 'auto_seam_cylinder_strength'), 0.0, 0.0, 100.0),
        'tube_angle_window': _settings_float(ws, ('suv_auto_seam_tube_angle_window',), 22.0, 2.0, 90.0),
        'stretch_weight': _settings_float(ws, ('suv_auto_seam_stretch_weight', 'auto_seam_stretch_weight'), 48.0, 0.0, 100.0),
        'planarity_weight': _settings_float(ws, ('auto_seam_planarity_weight',), 45.0, 0.0, 100.0),
        'existing_weight': _settings_float(ws, ('auto_seam_existing_weight',), 70.0, 0.0, 100.0),
        'small_island_weight': _settings_float(ws, ('auto_seam_small_island_weight',), 30.0, 0.0, 100.0),
        'nonmanifold_weight': _settings_float(ws, ('auto_seam_nonmanifold_weight', 'suv_auto_seam_boundary_weight'), 80.0, 0.0, 100.0),
        'cylinder_axis': _settings_enum(ws, ('suv_auto_seam_tube_axis', 'auto_seam_cylinder_axis'), 'AUTO'),
        'cylinder_cut_count': int(round(_settings_float(ws, ('suv_auto_seam_tube_cut_count', 'auto_seam_cylinder_cut_count'), 1.0, 1.0, 8.0))),
        'min_loop_length': int(round(_settings_float(ws, ('auto_seam_min_loop_length',), 3.0, 1.0, 512.0))),
        'mark_boundaries': _settings_bool(ws, ('suv_auto_seam_mark_boundaries',), True),
    }
    if not bool(settings.get('mark_boundaries', True)):
        settings['boundary_weight'] = 0.0
        settings['nonmanifold_weight'] = 0.0
    if preset == 'CYLINDER_TUBE':
        settings['cylinder_strength'] = max(float(settings['cylinder_strength']), 92.0)
        settings['loop_weight'] = max(float(settings['loop_weight']), 82.0)
        settings['boundary_weight'] = max(float(settings['boundary_weight']), 80.0)
        settings['cylinder_cut_count'] = max(1, int(settings['cylinder_cut_count']))
    elif preset == 'SINGLE_ISLAND':
        settings['score_threshold'] = max(float(settings['score_threshold']), 88.0)
        settings['angle_weight'] = min(float(settings['angle_weight']), 25.0)
        settings['material_weight'] = min(float(settings['material_weight']), 15.0)
        settings['sharp_weight'] = min(float(settings['sharp_weight']), 20.0)
        settings['cylinder_strength'] = max(float(settings['cylinder_strength']), 90.0)
    # A value the caller set explicitly on the operator outranks the panel setting.
    angle_override = getattr(operator, 'angle_override', None) if operator is not None else None
    if angle_override is None and operator is not None:
        # 操作に明示された angle_threshold は N パネルの設定より優先する（既定値では上書きしない）
        props = getattr(operator, 'properties', None)
        if props is not None and 'angle_threshold' in props.bl_rna.properties and props.is_property_set('angle_threshold'):
            angle_override = getattr(operator, 'angle_threshold', None)
        if props is not None:
            for _key in ('scope', 'clear_existing'):
                if _key in props.bl_rna.properties and props.is_property_set(_key):
                    settings[_key] = getattr(operator, _key)
    if angle_override is not None:
        settings['angle_threshold'] = max(0.0, min(math.pi, float(angle_override)))
    return settings

def _candidate_edges_from_scope(bm, scope: str) -> tuple[list, set]:
    scope = str(scope or 'SELECTED').upper()
    face_scope = [f for f in bm.faces if bool(getattr(f, 'select', False))] if scope == 'SELECTED' else list(bm.faces)
    face_set = set(face_scope)
    candidate_edges = []
    seen = set()
    for face in face_scope:
        for edge in getattr(face, 'edges', []) or []:
            idx = int(getattr(edge, 'index', -1))
            if idx in seen:
                continue
            seen.add(idx)
            candidate_edges.append(edge)
    if scope == 'ALL' and not candidate_edges:
        candidate_edges = list(bm.edges)
    return candidate_edges, face_set


def _cylinder_scores(candidate_edges: list, face_scope: Iterable, settings: dict[str, Any]) -> dict[int, float]:
    strength = float(settings.get('cylinder_strength', 0.0) or 0.0)
    if strength <= 0.0 or not candidate_edges:
        return {}
    axis, axis_idx = _axis_from_settings(settings, face_scope)
    if axis.length <= _EPS:
        return {}
    axis = axis.normalized()
    basis_u, basis_v = _radial_basis(axis_idx)
    mids = [_edge_midpoint(e) for e in candidate_edges]
    if not mids:
        return {}
    center = Vector((sum(p.x for p in mids) / len(mids), sum(p.y for p in mids) / len(mids), sum(p.z for p in mids) / len(mids)))
    parallel_edges = []
    for edge in candidate_edges:
        direction = _edge_direction(edge)
        align = abs(float(direction.dot(axis))) if direction.length > _EPS else 0.0
        if align < 0.58:
            continue
        p = _edge_midpoint(edge) - center
        x = float(p.dot(basis_u))
        y = float(p.dot(basis_v))
        if abs(x) < _EPS and abs(y) < _EPS:
            continue
        angle = math.atan2(y, x) % math.tau
        length = _edge_length(edge)
        parallel_edges.append((edge, angle, align, length))
    if not parallel_edges:
        return {}
    # Edges of a flat sheet lie on one line through the centre, on two opposite
    # sides of the axis.  A tube has them all the way round.
    total = sum(max(0.0001, length) for _e, _a, _al, length in parallel_edges)
    spread_x = sum(max(0.0001, length) * math.cos(2.0 * angle) for _e, angle, _al, length in parallel_edges)
    spread_y = sum(max(0.0001, length) * math.sin(2.0 * angle) for _e, angle, _al, length in parallel_edges)
    if math.hypot(spread_x, spread_y) > 0.8 * total:
        return {}
    bin_count = 36
    bins = [0.0] * bin_count
    for _edge, angle, align, length in parallel_edges:
        idx = int(round((angle / math.tau) * bin_count)) % bin_count
        bins[idx] += max(0.0001, length) * align
    cut_count = max(1, min(int(settings.get('cylinder_cut_count', 1) or 1), 8, bin_count))
    chosen = []
    work = list(bins)
    for _ in range(cut_count):
        idx = max(range(bin_count), key=lambda i: work[i])
        if work[idx] <= 0.0:
            break
        chosen.append((idx + 0.5) * math.tau / bin_count)
        # Suppress neighbouring bins so multiple cuts are distributed.
        for off in range(-max(1, bin_count // max(6, cut_count * 3)), max(1, bin_count // max(6, cut_count * 3)) + 1):
            work[(idx + off) % bin_count] = -1.0
    if not chosen:
        return {}
    window = math.radians(max(2.0, min(90.0, float(settings.get('tube_angle_window', 22.0) or 22.0))))
    scores: dict[int, float] = {}
    for edge, angle, align, _length in parallel_edges:
        dist = min(_angle_wrap_delta(angle, c) for c in chosen)
        if dist > window:
            score = 0.0
        else:
            score = 100.0 * (1.0 - dist / max(window, 1.0e-6)) * align
        if score > 0.0:
            scores[int(getattr(edge, 'index', -1))] = max(0.0, min(100.0, score))
    return scores


def _edge_score(edge, candidate_set: set, face_scope: Iterable, settings: dict[str, Any], cyl_scores: dict[int, float], axis: Vector) -> float:
    feat = _edge_basic_features(edge, float(settings.get('angle_threshold', math.radians(60.0)) or math.radians(60.0)))
    values = {
        'angle_weight': float(feat.get('angle_score', 0.0) or 0.0),
        'sharp_weight': 100.0 if bool(feat.get('sharp')) else 0.0,
        'material_weight': 100.0 if bool(feat.get('material')) else 0.0,
        'boundary_weight': 100.0 if bool(feat.get('boundary')) else 0.0,
        'nonmanifold_weight': 100.0 if bool(feat.get('nonmanifold')) else 0.0,
        'loop_weight': _loop_continuity_score(edge, candidate_set, axis),
        'cylinder_strength': float(cyl_scores.get(int(getattr(edge, 'index', -1)), 0.0) or 0.0),
        'stretch_weight': float(feat.get('density_score', 0.0) or 0.0),
        'planarity_weight': float(feat.get('planarity_score', 0.0) or 0.0),
        'existing_weight': 100.0 if bool(feat.get('existing')) else 0.0,
        'small_island_weight': 35.0 if bool(feat.get('boundary')) else 0.0,
    }
    total_w = 0.0
    total = 0.0
    for key, value in values.items():
        w = max(0.0, min(100.0, float(settings.get(key, 0.0) or 0.0)))
        if w <= 0.0:
            continue
        total_w += w
        total += w * max(0.0, min(100.0, float(value)))
    if total_w <= 0.0:
        return 0.0
    return max(0.0, min(100.0, total / total_w))


def _seam_face_components(faces: Iterable) -> list[list]:
    """Faces connected through edges that are not marked as seams."""
    remaining = set(faces)
    components = []
    while remaining:
        start = remaining.pop()
        component = [start]
        stack = [start]
        while stack:
            for edge in stack.pop().edges:
                if edge.seam:
                    continue
                for other in edge.link_faces:
                    if other in remaining:
                        remaining.discard(other)
                        component.append(other)
                        stack.append(other)
        components.append(component)
    return components


def _seam_edge_pieces(edges: Iterable, slits: dict | None = None) -> list[tuple[float, set]]:
    """Connected pieces of an edge set as (opening length, vertices), longest first.
    An edge with a face on both sides opens by twice its length."""
    by_vert: dict[Any, list] = {}
    for edge in edges:
        for vert in edge.verts:
            by_vert.setdefault(vert, []).append(edge)
    seen = set()
    pieces = []
    for vert in by_vert:
        if vert in seen:
            continue
        seen.add(vert)
        stack = [vert]
        verts = {vert}
        piece_edges = set()
        while stack:
            for edge in by_vert[stack.pop()]:
                piece_edges.add(edge)
                for candidate in edge.verts:
                    if candidate not in seen:
                        seen.add(candidate)
                        verts.add(candidate)
                        stack.append(candidate)
        pieces.append((sum(_edge_length(e) * (2.0 if slits and slits.get(e) == 2 else 1.0) for e in piece_edges), verts))
    pieces.sort(key=lambda item: -item[0])
    return pieces


def _seam_shortest_paths(sources: Iterable, by_vert: dict, cost: dict, *, stop: set | None = None) -> tuple[dict, dict, Any]:
    """Dijkstra over edges.  Returns distances, the edge each vertex was reached by, and the stop vertex hit."""
    dist = {}
    via = {}
    heap = []
    for vert in sources:
        dist[vert] = 0.0
        heap.append((0.0, vert.index, vert))
    heapq.heapify(heap)
    done = set()
    while heap:
        d, _index, vert = heapq.heappop(heap)
        if vert in done:
            continue
        done.add(vert)
        if stop and vert in stop and vert in via:
            return dist, via, vert
        for edge in by_vert.get(vert, ()):
            other = edge.other_vert(vert)
            nd = d + cost[edge]
            if nd < dist.get(other, math.inf):
                dist[other] = nd
                via[other] = edge
                heapq.heappush(heap, (nd, other.index, other))
    return dist, via, None


def _seam_walk_back(vert, via: dict) -> set:
    path = set()
    while vert in via:
        edge = via[vert]
        if edge in path:
            break
        path.add(edge)
        vert = edge.other_vert(vert)
    return path


def _seam_handle_cuts(faces: list, walkable: set, by_vert: dict, cost: dict, sources: set) -> set:
    """Shortest cuts that open the handles of a surface: edges left over by a
    shortest path tree and a dual spanning tree, joined back through the tree."""
    dist, via, _stop = _seam_shortest_paths(sources, by_vert, cost)
    tree = set(via.values())
    parent = {face: face for face in faces}

    def find(face):
        while parent[face] is not face:
            parent[face] = parent[parent[face]]
            face = parent[face]
        return face

    def weight(edge):
        a, b = edge.verts
        return dist.get(a, 0.0) + cost[edge] + dist.get(b, 0.0)

    cuts = set()
    for edge in sorted(walkable - tree, key=weight, reverse=True):
        a, b = [f for f in edge.link_faces if f in parent]
        ra, rb = find(a), find(b)
        if ra is not rb:
            parent[ra] = rb
            continue
        cuts.add(edge)
        for vert in edge.verts:
            cuts |= _seam_walk_back(vert, via)
    return cuts


# A seam set made only of fold evidence can leave an island that no unwrap can
# flatten: a closed shape, a shape far beyond a hemisphere with only a small
# opening, a shape with handles, or a tube, which opens as a squashed ring.  These
# are the fewest cuts that make the island flatten; existing seams are kept and
# islands are not split further.
def _component_opening_edges(faces: list, settings: dict[str, Any], cyl_scores: dict[int, float]) -> set:
    if len(faces) < 2:
        return set()
    face_set = set(faces)
    edges = {edge for face in faces for edge in face.edges}
    verts = {vert for edge in edges for vert in edge.verts}
    linked = {edge: sum(1 for face in edge.link_faces if face in face_set) for edge in edges}
    if any(count > 2 for count in linked.values()):
        return set()
    # Prefer the line the tube score chose when several paths are about as short.
    cost = {edge: max(_edge_length(edge), 1.0e-9) * (1.0 - 0.005 * min(100.0, float(cyl_scores.get(int(edge.index), 0.0) or 0.0))) for edge in edges}
    cut_edges = {edge for edge in edges if edge.seam or linked[edge] != 2}
    walkable = edges - cut_edges
    all_by_vert: dict[Any, list] = {}
    by_vert: dict[Any, list] = {}
    for edge in edges:
        for vert in edge.verts:
            all_by_vert.setdefault(vert, []).append(edge)
            if edge in walkable:
                by_vert.setdefault(vert, []).append(edge)
    first = min(verts, key=lambda vert: vert.index)
    holes = len(_seam_edge_pieces(edge for edge in edges if linked[edge] == 1))
    handles = (2 - holes - (len(verts) - len(edges) + len(faces))) // 2
    pieces = _seam_edge_pieces(cut_edges, linked)
    if handles > 0:
        sources = {vert for edge in cut_edges for vert in edge.verts} or {first}
        return _seam_handle_cuts(faces, walkable, by_vert, cost, sources)
    area = sum(face.calc_area() for face in faces)
    if not pieces:
        dist, _via, _stop = _seam_shortest_paths([first], all_by_vert, cost)
        dist, via, _stop = _seam_shortest_paths([max(dist, key=lambda vert: dist[vert])], all_by_vert, cost)
        return _seam_walk_back(max(dist, key=lambda vert: dist[vert]), via)
    # 1.0 for a flat disc, 0.5 for a hemisphere, 0.25 for a sphere with one seam
    # from pole to pole.
    openness = pieces[0][0] ** 2 / max(4.0 * math.pi * area, 1.0e-12)
    tube_cut = float(settings.get('cylinder_strength', 0.0) or 0.0) > 0.0 and len(pieces) >= 2 and pieces[1][0] >= 0.5 * pieces[0][0]
    if tube_cut:
        facing = Vector((0.0, 0.0, 0.0))
        for face in faces:
            facing += face.normal * face.calc_area()
        tube_cut = facing.length <= 0.5 * area
    if not tube_cut:
        if openness >= 0.18:
            return set()
        dist, via, _stop = _seam_shortest_paths(pieces[0][1], by_vert, cost)
        return _seam_walk_back(max(dist, key=lambda vert: dist[vert]), via)
    cuts = set()
    sources = set(pieces[0][1])
    for length, piece_verts in pieces[1:]:
        if length < 0.5 * pieces[0][0]:
            break
        _dist, via, hit = _seam_shortest_paths(sources, by_vert, cost, stop=piece_verts)
        if hit is None:
            continue
        path = _seam_walk_back(hit, via)
        cuts |= path
        sources |= piece_verts
        sources |= {vert for edge in path for vert in edge.verts}
    return cuts


def run_advanced_auto_seams(context=None, operator=None) -> dict[str, Any]:
    ctx = context or bpy.context
    obj = _active_mesh(ctx)
    if obj is None:
        return {'ok': False, 'marked': 0, 'status': 'NO_ACTIVE_MESH'}
    _set_active(ctx, obj)
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed = False
    if old_mode != 'EDIT':
        if not _mode_set('EDIT'):
            return {'ok': False, 'marked': 0, 'status': 'NO_EDIT_MODE'}
        changed = True
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        try:
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
        except Exception:
            pass
        settings = auto_seam_settings(ctx, operator)
        mode = str(getattr(operator, 'mode', 'ADVANCED') if operator is not None else 'ADVANCED').upper()
        scope = str(settings.get('scope', 'SELECTED') or 'SELECTED').upper()
        candidate_edges, face_set = _candidate_edges_from_scope(bm, scope)
        if scope == 'SELECTED' and not face_set:
            return {'ok': False, 'marked': 0, 'status': 'NO_SELECTION'}
        if bool(settings.get('clear_existing')):
            for edge in candidate_edges:
                try:
                    edge.seam = False
                except Exception:
                    pass
        if not candidate_edges:
            return {'ok': True, 'marked': 0, 'status': 'OK'}
        axis, _axis_idx = _axis_from_settings(settings, face_set or bm.faces)
        axis = axis.normalized() if axis.length > _EPS else Vector((0.0, 0.0, 1.0))
        cyl_scores = _cylinder_scores(candidate_edges, face_set or bm.faces, settings)
        candidate_set = set(candidate_edges)
        threshold = max(0.0, min(100.0, float(settings.get('score_threshold', 54.0))))
        marked = 0
        for edge in candidate_edges:
            if scope == 'SELECTED' and not any(f in face_set for f in getattr(edge, 'link_faces', []) or []):
                continue
            feat = _edge_basic_features(edge, float(settings.get('angle_threshold', math.radians(60.0)) or math.radians(60.0)))
            should = False
            if mode == 'ANGLE':
                should = float(feat.get('angle_score', 0.0) or 0.0) >= 100.0
            elif mode == 'SHARP':
                should = bool(feat.get('sharp'))
            elif mode == 'MATERIAL':
                should = bool(feat.get('material'))
            elif mode == 'BOUNDARY':
                should = bool(feat.get('boundary'))
            else:
                score = _edge_score(edge, candidate_set, face_set or bm.faces, settings, cyl_scores, axis)
                cyl_score = float(cyl_scores.get(int(getattr(edge, 'index', -1)), 0.0) or 0.0)
                # Cylinder/tube mode must be able to mark one clean lengthwise cut
                # even when other weights are low, otherwise the weighted average
                # can dilute the cylinder evidence too much.
                if mode in {'CYLINDER_TUBE', 'CYLINDER', 'TUBE'}:
                    should = cyl_score >= max(12.0, threshold * 0.42) or score >= threshold
                else:
                    should = score >= threshold
                # Tube/cylinder mode must reliably create a lengthwise opening
                # seam.  The global weighted average can otherwise dilute a
                # good longitudinal candidate with angle/material/stretch terms.
                cyl_score = float(cyl_scores.get(int(getattr(edge, 'index', -1)), 0.0) or 0.0)
                if float(settings.get('cylinder_strength', 0.0) or 0.0) >= 70.0 and cyl_score >= max(18.0, threshold * 0.28):
                    should = True
                if bool(feat.get('boundary')) and float(settings.get('boundary_weight', 0.0) or 0.0) >= 70.0:
                    should = True
            if should and not bool(getattr(edge, 'seam', False)):
                try:
                    edge.seam = True
                    marked += 1
                except Exception:
                    pass
        if mode not in {'ANGLE', 'SHARP', 'MATERIAL', 'BOUNDARY'}:
            for component in _seam_face_components(face_set or bm.faces):
                for edge in _component_opening_edges(component, settings, cyl_scores):
                    if not edge.seam:
                        edge.seam = True
                        marked += 1
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return {'ok': True, 'marked': int(marked), 'status': 'OK'}
    finally:
        if changed and old_mode != 'EDIT':
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                pass


def standard_mark_seam_selected_edges(context=None, *, clear: bool = False) -> int:
    """Blender-standard Mark Seam/Clear Seam on the 3D View selected mesh edges."""
    ctx = context or bpy.context
    obj = _active_mesh(ctx)
    if obj is None:
        return -1
    _set_active(ctx, obj)
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed = False
    if old_mode != 'EDIT':
        if not _mode_set('EDIT'):
            return -1
        changed = True
    count = 0
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        try:
            bm.edges.ensure_lookup_table()
        except Exception:
            pass
        target = not bool(clear)
        for edge in bm.edges:
            try:
                if not bool(getattr(edge, 'select', False)):
                    continue
                if bool(getattr(edge, 'seam', False)) != target:
                    edge.seam = target
                    count += 1
            except Exception:
                pass
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return int(count)
    finally:
        if changed and old_mode != 'EDIT':
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                pass


def enhanced_auto_seam(context=None, *, mode: str = 'ALL', scope: str | None = None, angle_threshold=None, clear_existing=None) -> int:
    """Compatibility entry point used by native_unified_tools/flow/precision_patch."""
    class _Op:
        pass
    op = _Op()
    op.mode = str(mode or 'ALL').upper()
    if scope is not None:
        op.scope = scope
    if angle_threshold is not None:
        op.angle_threshold = angle_threshold
    if clear_existing is not None:
        op.clear_existing = clear_existing
    result = run_advanced_auto_seams(context or bpy.context, op)
    if not bool(result.get('ok')):
        return -1
    return int(result.get('marked', 0) or 0)


def sync_after_unwrap_if_enabled(context=None, obj=None, *, selected_faces: set[int] | None = None, method: str = 'ANGLE_BASED', margin: float = 0.001) -> bool:
    """Post-unwrap seam-mark compliance hook used by all unwrap routes."""
    if obj is not None:
        try:
            ctx = context or bpy.context
            ctx.view_layer.objects.active = obj
        except Exception:
            pass
    return bool(apply_marked_seam_compliance(context or bpy.context, method=method, margin=margin, selected_faces=selected_faces))



def standard_mark_seam_selected_edges(context=None, *, clear: bool = False) -> int:
    """Blender-standard Mark Seam/Clear Seam on the 3D View selected mesh edges.

    This intentionally reads BMEdge.select instead of UV selection so it behaves
    like Blender's Mesh > Edges > Mark Seam / Clear Seam even when invoked from
    the UV Editor sidebar.
    """
    ctx = context or bpy.context
    obj = _active_mesh(ctx)
    if obj is None:
        return -1
    _set_active(ctx, obj)
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed = False
    if old_mode != 'EDIT':
        if not _mode_set('EDIT'):
            return -1
        changed = True
    count = 0
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        try:
            bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            bm.edges.index_update(); bm.faces.index_update(); bm.verts.index_update()
        except Exception:
            pass
        mesh_state = _capture_mesh_selection(bm)
        target = not bool(clear)
        for edge in bm.edges:
            try:
                if not bool(getattr(edge, 'select', False)):
                    continue
                if bool(getattr(edge, 'seam', False)) != target:
                    edge.seam = target
                    count += 1
            except Exception:
                pass
        try:
            _restore_mesh_selection(bm, mesh_state)
        except Exception:
            pass
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return int(count)
    finally:
        if changed and old_mode != 'EDIT':
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                pass


def enhanced_auto_seam(context=None, *, mode: str = 'AUTO', scope: str | None = None, angle_threshold=None, clear_existing=None) -> int:
    """Compatibility entry point used by native_unified_tools/flow/precision_patch."""
    class _Op:
        pass
    op = _Op()
    m = str(mode or 'AUTO').upper()
    if m in {'ALL', 'AUTO', 'AUTO_SEAM', 'SMART'}:
        op.mode = 'ADVANCED'
    elif m in {'ANGLE', 'BOUNDARY', 'MATERIAL', 'SHARP'}:
        op.mode = m
    else:
        op.mode = 'ADVANCED'
    if scope is not None:
        op.scope = scope
    if angle_threshold is not None:
        op.angle_threshold = angle_threshold
    if clear_existing is not None:
        op.clear_existing = clear_existing
    result = run_advanced_auto_seams(context or bpy.context, op)
    if not bool(result.get('ok')):
        return -1
    return int(result.get('marked', 0) or 0)


def sync_after_unwrap_if_enabled(context=None, obj=None, *, selected_faces: set[int] | None = None, method: str = 'ANGLE_BASED', margin: float = 0.001) -> bool:
    """Post-unwrap seam-mark compliance hook used by all unwrap routes."""
    ctx = context or bpy.context
    if obj is not None:
        try:
            ctx.view_layer.objects.active = obj
        except Exception:
            pass
    return bool(apply_marked_seam_compliance(ctx, method=method, margin=margin, selected_faces=selected_faces, force=False))


# ---------------------------------------------------------------------------
# Persistent Mark Seam snapshots and Blender-standard UV pin operations
# ---------------------------------------------------------------------------
_SEAM_SCENE_KEY = "Smart_UV_Suite.seam_snapshots"
_DEFAULT_SNAPSHOT_NAME = "Default"


def _selected_mesh_objects(context=None) -> list:
    ctx = context or bpy.context
    result = []
    try:
        for obj in list(getattr(ctx, 'selected_objects', []) or []):
            if obj is not None and getattr(obj, 'type', '') == 'MESH':
                result.append(obj)
    except Exception:
        pass
    active = _active_mesh(ctx)
    if active is not None and active not in result:
        result.insert(0, active)
    # Deterministic order, active first.
    seen = set()
    out = []
    for obj in result:
        ident = id(obj)
        if ident in seen:
            continue
        seen.add(ident)
        out.append(obj)
    return out


def _default_snapshot_name(context=None) -> str:
    try:
        ws = _ws(context)
        name = str(getattr(ws, 'seam_snapshot_name', '') or '').strip()
        if name:
            return name
    except Exception:
        pass
    return _DEFAULT_SNAPSHOT_NAME


def _default_snapshot_filepath(context=None, name: str | None = None) -> str:
    try:
        ws = _ws(context)
        raw = str(getattr(ws, 'seam_snapshot_filepath', '') or '').strip()
        if raw:
            return bpy.path.abspath(raw)
    except Exception:
        pass
    safe_name = ''.join(ch if ch.isalnum() or ch in {'_', '-', '.'} else '_' for ch in str(name or _default_snapshot_name(context))) or _DEFAULT_SNAPSHOT_NAME
    if not safe_name.lower().endswith('.json'):
        safe_name += '.json'
    try:
        from . import storage as _storage
        return str(_storage.storage_path(safe_name, 'seam_snapshots', create=True))
    except Exception:
        return str(Path.home() / safe_name)


def _set_workspace_snapshot_filepath(context, filepath: str) -> None:
    try:
        ws = _ws(context)
        if ws is not None and hasattr(ws, 'seam_snapshot_filepath'):
            setattr(ws, 'seam_snapshot_filepath', str(filepath or ''))
    except Exception:
        pass


def _object_seam_payload(obj) -> dict[str, Any]:
    me = getattr(obj, 'data', None)
    if me is None:
        return {}
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed = False
    try:
        if old_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
            changed = True
    except Exception:
        changed = False
    try:
        vertices = len(getattr(me, 'vertices', []) or [])
        edges_payload = []
        seam_indices = []
        for edge in getattr(me, 'edges', []) or []:
            try:
                idx = int(edge.index)
                v = tuple(int(i) for i in getattr(edge, 'vertices', [])[:])
                flag = bool(getattr(edge, 'use_seam', False))
                edges_payload.append({'index': idx, 'vertices': list(v), 'seam': flag})
                if flag:
                    seam_indices.append(idx)
            except Exception:
                pass
        return {
            'schema': 'Smart_UV_Suite.MarkSeamSnapshot',
            'version': 1,
            'object_name': str(getattr(obj, 'name', '') or ''),
            'mesh_name': str(getattr(me, 'name', '') or ''),
            'vertex_count': int(vertices),
            'edge_count': int(len(getattr(me, 'edges', []) or [])),
            'seam_indices': seam_indices,
            'edges': edges_payload,
        }
    finally:
        if changed:
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                try:
                    bpy.ops.object.mode_set(mode='EDIT')
                except Exception:
                    pass


def _apply_object_seam_payload(context, obj, payload: dict[str, Any], *, clear_missing: bool = True) -> int:
    me = getattr(obj, 'data', None)
    if me is None or not isinstance(payload, dict):
        return -1
    old_active = None
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed = False
    try:
        old_active = getattr(context.view_layer.objects, 'active', None)
    except Exception:
        old_active = None
    try:
        context.view_layer.objects.active = obj
        obj.select_set(True)
    except Exception:
        pass
    try:
        if old_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
            changed = True
    except Exception:
        pass
    count = 0
    try:
        edge_data = list(payload.get('edges') or [])
        seam_indices = {int(i) for i in (payload.get('seam_indices') or [])}
        by_vertices = {}
        for item in edge_data:
            try:
                verts = tuple(sorted(int(v) for v in (item.get('vertices') or [])))
                if len(verts) == 2:
                    by_vertices[verts] = bool(item.get('seam', False))
            except Exception:
                pass
        for edge in getattr(me, 'edges', []) or []:
            try:
                idx = int(edge.index)
                verts = tuple(sorted(int(v) for v in getattr(edge, 'vertices', [])[:]))
                if idx in seam_indices:
                    target = True
                elif verts in by_vertices:
                    target = bool(by_vertices[verts])
                else:
                    target = False if clear_missing else bool(getattr(edge, 'use_seam', False))
                if bool(getattr(edge, 'use_seam', False)) != bool(target):
                    edge.use_seam = bool(target)
                    count += 1
            except Exception:
                pass
        try:
            me.update()
        except Exception:
            pass
        return int(count)
    finally:
        if changed:
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                try:
                    bpy.ops.object.mode_set(mode='EDIT')
                except Exception:
                    pass
        if old_active is not None:
            try:
                context.view_layer.objects.active = old_active
            except Exception:
                pass


def _scene_snapshot_store(context=None) -> dict[str, Any]:
    ctx = context or bpy.context
    scene = getattr(ctx, 'scene', None)
    if scene is None:
        return {'schema': 'Smart_UV_Suite.SceneSeamSnapshots', 'version': 1, 'snapshots': {}}
    raw = ''
    try:
        raw = str(scene.get(_SEAM_SCENE_KEY, '') or '')
    except Exception:
        raw = ''
    try:
        data = json.loads(raw) if raw else {}
    except Exception:
        data = {}
    if not isinstance(data, dict):
        data = {}
    data.setdefault('schema', 'Smart_UV_Suite.SceneSeamSnapshots')
    data.setdefault('version', 1)
    data.setdefault('snapshots', {})
    if not isinstance(data.get('snapshots'), dict):
        data['snapshots'] = {}
    return data


def _write_scene_snapshot_store(context, data: dict[str, Any]) -> None:
    scene = getattr(context or bpy.context, 'scene', None)
    if scene is None:
        return
    try:
        scene[_SEAM_SCENE_KEY] = json.dumps(data, ensure_ascii=False, separators=(',', ':'))
    except Exception:
        pass


def save_scene_seam_snapshot(context=None, name: str | None = None) -> int:
    ctx = context or bpy.context
    name = str(name or _default_snapshot_name(ctx)).strip() or _DEFAULT_SNAPSHOT_NAME
    objects = _selected_mesh_objects(ctx)
    if not objects:
        return -1
    data = _scene_snapshot_store(ctx)
    snapshot = {
        'schema': 'Smart_UV_Suite.MarkSeamSceneSnapshot',
        'version': 1,
        'name': name,
        'objects': {},
    }
    for obj in objects:
        payload = _object_seam_payload(obj)
        if not payload:
            continue
        snapshot['objects'][str(getattr(obj, 'name', '') or '')] = payload
    data['snapshots'][name] = snapshot
    data['active'] = name
    _write_scene_snapshot_store(ctx, data)
    return len(snapshot['objects'])


def load_scene_seam_snapshot(context=None, name: str | None = None) -> int:
    ctx = context or bpy.context
    name = str(name or _default_snapshot_name(ctx)).strip() or _DEFAULT_SNAPSHOT_NAME
    objects = _selected_mesh_objects(ctx)
    if not objects:
        return -1
    data = _scene_snapshot_store(ctx)
    snapshots = dict(data.get('snapshots') or {})
    snapshot = snapshots.get(name)
    if snapshot is None and snapshots:
        active = str(data.get('active') or '')
        snapshot = snapshots.get(active) or next(iter(snapshots.values()))
    if not isinstance(snapshot, dict):
        return -1
    payloads = dict(snapshot.get('objects') or {})
    changed_objects = 0
    for obj in objects:
        payload = payloads.get(str(getattr(obj, 'name', '') or ''))
        if payload is None:
            # Fallback by mesh datablock name; useful when object was renamed.
            mesh_name = str(getattr(getattr(obj, 'data', None), 'name', '') or '')
            for candidate in payloads.values():
                if isinstance(candidate, dict) and str(candidate.get('mesh_name') or '') == mesh_name:
                    payload = candidate
                    break
        if isinstance(payload, dict):
            if _apply_object_seam_payload(ctx, obj, payload, clear_missing=True) >= 0:
                changed_objects += 1
    return int(changed_objects)


def _external_seam_payload(context=None) -> dict[str, Any]:
    ctx = context or bpy.context
    objects = _selected_mesh_objects(ctx)
    return {
        'schema': 'Smart_UV_Suite.MarkSeamExternalSnapshot',
        'version': 1,
        'objects': {str(getattr(obj, 'name', '') or ''): _object_seam_payload(obj) for obj in objects},
    }


def save_external_seam_snapshot(context=None, filepath: str | None = None) -> str:
    ctx = context or bpy.context
    path = Path(filepath or _default_snapshot_filepath(ctx))
    if not str(path):
        return ''
    if path.suffix.lower() != '.json':
        path = path.with_suffix('.json')
    payload = _external_seam_payload(ctx)
    if not payload.get('objects'):
        return ''
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
        _set_workspace_snapshot_filepath(ctx, str(path))
        return str(path)
    except Exception:
        return ''


def load_external_seam_snapshot(context=None, filepath: str | None = None) -> int:
    ctx = context or bpy.context
    path = Path(filepath or _default_snapshot_filepath(ctx))
    try:
        payload = json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        return -1
    if not isinstance(payload, dict):
        return -1
    payloads = dict(payload.get('objects') or {})
    objects = _selected_mesh_objects(ctx)
    if not objects:
        return -1
    changed_objects = 0
    for obj in objects:
        item = payloads.get(str(getattr(obj, 'name', '') or ''))
        if item is None:
            mesh_name = str(getattr(getattr(obj, 'data', None), 'name', '') or '')
            for candidate in payloads.values():
                if isinstance(candidate, dict) and str(candidate.get('mesh_name') or '') == mesh_name:
                    item = candidate
                    break
        if isinstance(item, dict):
            if _apply_object_seam_payload(ctx, obj, item, clear_missing=True) >= 0:
                changed_objects += 1
    _set_workspace_snapshot_filepath(ctx, str(path))
    return int(changed_objects)


def _selected_uv_loops_for_pin(context, obj, bm, uv_layer, *, include_all_if_empty: bool = False, attrs: dict | None = None) -> list:
    if attrs is None:
        # This helper may be called after a live BMesh has been acquired.
        # Switching modes at that point invalidates BMesh handles, so callers
        # should normally pass Blender 5.1 UV-selection attributes captured
        # before bmesh.from_edit_mesh().  The fallback is kept only for older
        # call paths that do not pass attrs.
        try:
            attrs = _read_uv_select_attrs_object_mode(context, obj)
        except Exception:
            attrs = {}
    attrs = attrs or {}
    face_flags = list((attrs or {}).get('face') or [])
    vert_flags = list((attrs or {}).get('vert') or [])
    edge_flags = list((attrs or {}).get('edge') or [])
    prefer_attrs = bool(any(face_flags) or any(vert_flags) or any(edge_flags))
    loops = []
    seen = set()
    try:
        bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
        bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
    except Exception:
        pass
    for face in getattr(bm, 'faces', []) or []:
        fi = int(getattr(face, 'index', -1))
        face_selected = prefer_attrs and 0 <= fi < len(face_flags) and bool(face_flags[fi])
        for loop in getattr(face, 'loops', []) or []:
            try:
                li = int(getattr(loop, 'index', -1))
            except Exception:
                li = -1
            selected = False
            if prefer_attrs:
                selected = bool(face_selected)
                if not selected and 0 <= li < len(vert_flags):
                    selected = bool(vert_flags[li])
                if not selected and 0 <= li < len(edge_flags):
                    selected = bool(edge_flags[li])
            else:
                try:
                    luv = loop[uv_layer]
                    selected = bool(getattr(luv, 'select', False) or getattr(luv, 'select_edge', False))
                except Exception:
                    selected = False
            if selected:
                key = (int(getattr(face, 'index', -1)), int(list(face.loops).index(loop)))
                if key not in seen:
                    seen.add(key)
                    loops.append(loop)
    if not loops and include_all_if_empty:
        for face in getattr(bm, 'faces', []) or []:
            for loop in getattr(face, 'loops', []) or []:
                loops.append(loop)
    return loops


def pin_uv_selection(context=None, *, action: str = 'PIN') -> int:
    """Run Blender-standard UV pin actions on the current UV Editor selection.

    action: PIN, UNPIN/CLEAR_PINS, INVERT/INVERT_PINS.  Mesh selection is restored
    after changing only UV pin flags.  Hidden Blender 5.1 UV selection attributes
    are used first so UV Editor selection, not 3D View selection, is authoritative.
    """
    ctx = context or bpy.context
    obj = _active_mesh(ctx)
    if obj is None:
        return -1
    _set_active(ctx, obj)
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    # Capture Blender 5.1 UV Editor selection attributes before acquiring a
    # BMesh.  The reader temporarily changes object/edit mode, which must not
    # happen while a BMesh handle is live.
    try:
        uv_attrs = _read_uv_select_attrs_object_mode(ctx, obj)
    except Exception:
        uv_attrs = {}
    changed = False
    if old_mode != 'EDIT':
        if not _mode_set('EDIT'):
            return -1
        changed = True
    action_u = str(action or 'PIN').upper()
    if action_u in {'CLEAR_PINS', 'CLEAR', 'UNPIN'}:
        mode = 'UNPIN'
    elif action_u in {'INVERT_PINS', 'INVERT', 'TOGGLE'}:
        mode = 'INVERT'
    else:
        mode = 'PIN'
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        mesh_state = _capture_mesh_selection(bm)
        include_all = mode == 'UNPIN'
        loops = _selected_uv_loops_for_pin(ctx, obj, bm, uv_layer, include_all_if_empty=include_all, attrs=uv_attrs)
        if not loops:
            _restore_mesh_selection(bm, mesh_state)
            return -1
        count = 0
        for loop in loops:
            try:
                luv = loop[uv_layer]
                old = bool(getattr(luv, 'pin_uv', False))
                if mode == 'PIN':
                    new = True
                elif mode == 'UNPIN':
                    new = False
                else:
                    new = not old
                if old != new:
                    count += 1
                luv.pin_uv = bool(new)
            except Exception:
                pass
        _restore_mesh_selection(bm, mesh_state)
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return int(count)
    finally:
        if changed and old_mode != 'EDIT':
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                pass


class SMARTUVSUITE_OT_seam_snapshot_action(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.seam_snapshot_action'
    bl_label = 'シーム設定保存/読み込み'
    bl_description = '「シームをマーク」で作成した実メッシュシームをシーン内または外部JSONへ保存し、必要時に読み込みます。UV展開で使う既存シームを解除せず維持するための管理機能です。'
    bl_options = {'UNDO'}

    action: bpy.props.EnumProperty(
        name='Action',
        items=(
            ('SAVE_SCENE', 'シーン内保存', '現在の選択メッシュのシーム設定をシーン内の一時スナップショットへ保存します。'),
            ('LOAD_SCENE', 'シーン内読み込み', 'シーン内スナップショットから現在の選択メッシュへシーム設定を読み込みます。'),
            ('SAVE_FILE', '外部保存', '現在の選択メッシュのシーム設定を外部JSONファイルへ保存します。'),
            ('LOAD_FILE', '外部読み込み', '外部JSONファイルから現在の選択メッシュへシーム設定を読み込みます。'),
        ),
        default='SAVE_SCENE',
        options={'SKIP_SAVE'},
    )
    filepath: bpy.props.StringProperty(name='File Path', subtype='FILE_PATH', default='', options={'SKIP_SAVE'})

    def invoke(self, context, event):
        action = str(getattr(self, 'action', 'SAVE_SCENE') or 'SAVE_SCENE').upper()
        if action in {'SAVE_FILE', 'LOAD_FILE'} and not str(getattr(self, 'filepath', '') or '').strip():
            try:
                self.filepath = _default_snapshot_filepath(context)
            except Exception:
                self.filepath = ''
            try:
                wm = getattr(context, 'window_manager', None)
                if wm is not None:
                    wm.fileselect_add(self)
                    return {'RUNNING_MODAL'}
            except Exception:
                pass
        return self.execute(context)

    def execute(self, context):
        action = str(getattr(self, 'action', 'SAVE_SCENE') or 'SAVE_SCENE').upper()
        name = _default_snapshot_name(context)
        if action == 'SAVE_SCENE':
            count = save_scene_seam_snapshot(context, name)
            if count < 0:
                self.report({'WARNING'}, _t(context, 'No mesh object available for seam snapshot.', 'シーム設定を保存できるメッシュがありません。'))
                return {'CANCELLED'}
            self.report({'INFO'}, _t(context, f'Saved seam snapshot in scene: {name} ({count} object(s)).', f'シーン内にシーム設定を保存しました: {name}（{count}オブジェクト）'))
            return {'FINISHED'}
        if action == 'LOAD_SCENE':
            count = load_scene_seam_snapshot(context, name)
            if count <= 0:
                self.report({'WARNING'}, _t(context, 'No scene seam snapshot could be loaded.', '読み込めるシーン内シーム設定がありません。'))
                return {'CANCELLED'}
            self.report({'INFO'}, _t(context, f'Loaded scene seam snapshot: {name} ({count} object(s)).', f'シーン内シーム設定を読み込みました: {name}（{count}オブジェクト）'))
            return {'FINISHED'}
        if action == 'SAVE_FILE':
            path = save_external_seam_snapshot(context, getattr(self, 'filepath', '') or None)
            if not path:
                self.report({'WARNING'}, _t(context, 'External seam snapshot could not be saved.', '外部シーム設定を保存できませんでした。'))
                return {'CANCELLED'}
            self.report({'INFO'}, _t(context, f'Saved seam snapshot file: {path}', f'外部シーム設定を保存しました: {path}'))
            return {'FINISHED'}
        if action == 'LOAD_FILE':
            count = load_external_seam_snapshot(context, getattr(self, 'filepath', '') or None)
            if count <= 0:
                self.report({'WARNING'}, _t(context, 'External seam snapshot could not be loaded.', '外部シーム設定を読み込めませんでした。'))
                return {'CANCELLED'}
            self.report({'INFO'}, _t(context, f'Loaded seam snapshot file ({count} object(s)).', f'外部シーム設定を読み込みました（{count}オブジェクト）。'))
            return {'FINISHED'}
        return {'CANCELLED'}


class SMARTUVSUITE_OT_mark_clear_seam_3d_selection(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.mark_clear_seam_3d_selection'
    bl_label = 'シームをマーク・クリア'
    bl_description = 'UVエディター側パネルから実行した場合も、3Dビューで選択しているメッシュ辺を対象に、Blender標準相当のシームをマークまたはクリアします。'
    bl_options = {'UNDO'}

    action: bpy.props.EnumProperty(
        name='処理',
        items=(
            ('MARK', 'シームをマーク', '3Dビューで選択しているメッシュ辺にシームを設定します。'),
            ('CLEAR', 'シームをクリア', '3Dビューで選択しているメッシュ辺のシームを解除します。'),
        ),
        default='MARK',
    )

    @classmethod
    def poll(cls, context):
        return _active_mesh(context) is not None

    def execute(self, context):
        obj = _active_mesh(context)
        if obj is None:
            self.report({'WARNING'}, _t(context, 'No active mesh.', 'アクティブなメッシュがありません。'))
            return {'CANCELLED'}
        _set_active(context, obj)
        old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
        changed = False
        if old_mode != 'EDIT':
            if not _mode_set('EDIT'):
                self.report({'WARNING'}, _t(context, 'Could not enter Edit Mode.', '編集モードへ切り替えられません。'))
                return {'CANCELLED'}
            changed = True
        count = 0
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            try:
                bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            except Exception:
                pass
            target = self.action == 'MARK'
            for edge in bm.edges:
                try:
                    selected = bool(getattr(edge, 'select', False))
                except Exception:
                    selected = False
                if not selected:
                    continue
                try:
                    if bool(getattr(edge, 'seam', False)) != target:
                        edge.seam = bool(target)
                        count += 1
                except Exception:
                    pass
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        finally:
            if changed and old_mode != 'EDIT':
                try:
                    bpy.ops.object.mode_set(mode=old_mode)
                except Exception:
                    pass
        self.report({'INFO'}, _t(context, f'{self.action.title()} Seam: {count} edges.', f'{"シームをマーク" if target else "シームをクリア"}: {count} 本'))
        return {'FINISHED'}


def patch_flow_auto_seam_execute() -> bool:
    try:
        from . import flow as _flow
    except Exception:
        return False
    cls = getattr(_flow, 'SUV_OT_auto_seam_advanced', None)
    if cls is None:
        return False

    def _execute(self, context):
        result = run_advanced_auto_seams(context, self)
        if not bool(result.get('ok')):
            status = str(result.get('status', 'FAILED'))
            msg = '選択面がありません。' if status == 'NO_SELECTION' else f'自動シームに失敗しました: {status}'
            try:
                self.report({'WARNING'}, msg)
            except Exception:
                pass
            return {'CANCELLED'}
        marked = int(result.get('marked', 0) or 0)
        try:
            self.report({'INFO'}, _t(context, f'Auto Seam: marked {marked} edges.', f'自動シーム: {marked} 本の辺にシームを設定しました。'))
        except Exception:
            pass
        return {'FINISHED'}

    try:
        cls.execute = _execute
        return True
    except Exception:
        return False


def _suv_stage_001_register() -> None:
    patch_flow_auto_seam_execute()
    for cls in (SMARTUVSUITE_OT_mark_clear_seam_3d_selection, SMARTUVSUITE_OT_seam_snapshot_action):
        try:
            _suv_resource.register_class(cls)
            _REGISTERED.append(cls)
        except ValueError:
            pass
        except Exception:
            pass


def _suv_stage_001_unregister() -> None:
    for cls in reversed(_REGISTERED):
        try:
            _suv_resource.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED.clear()

# ---------------------------------------------------------------------------
# 1.6.22 final seam/pin integration overrides
# ---------------------------------------------------------------------------

def marked_seam_compliance_enabled(context=None) -> bool:
    ws = _ws(context)
    if ws is None:
        return True
    for name in ('suv_seam_mark_compliance', 'seam_mark_compliant_unwrap', 'unwrap_marked_seam_compliance'):
        try:
            if hasattr(ws, name):
                return bool(getattr(ws, name))
        except Exception:
            pass
    return True


def marked_seam_clear_internal_enabled(context=None) -> bool:
    ws = _ws(context)
    if ws is None:
        return True
    for name in ('seam_mark_compliance_clear_internal', 'suv_seam_mark_compliance_clear_internal'):
        try:
            if hasattr(ws, name):
                return bool(getattr(ws, name))
        except Exception:
            pass
    return True


def _selected_uv_faces_from_attrs_or_bmesh(obj, bm, uv_layer, attrs=None, *, fallback_mesh_selection: bool = True) -> set[int]:
    attrs = attrs or {'face': [], 'vert': [], 'edge': []}
    face_flags = list(attrs.get('face') or [])
    vert_flags = list(attrs.get('vert') or [])
    selected: set[int] = set()
    try:
        bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
        bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
    except Exception:
        pass
    if face_flags and any(face_flags):
        for face in bm.faces:
            fi = int(getattr(face, 'index', -1))
            if fi < 0 or fi >= len(face_flags) or not bool(face_flags[fi]):
                continue
            loops = list(getattr(face, 'loops', ()) or ())
            if not loops:
                continue
            if vert_flags:
                ok = True
                for loop in loops:
                    li = int(getattr(loop, 'index', -1))
                    if li < 0 or li >= len(vert_flags) or not bool(vert_flags[li]):
                        ok = False
                        break
                if not ok:
                    continue
            selected.add(fi)
        return selected
    # Fallback: require every UV corner of the face to be selected; a single
    # vertex/edge selection must not pull adjacent faces into the unwrap/seam scope.
    for face in bm.faces:
        loops = list(getattr(face, 'loops', ()) or ())
        if not loops:
            continue
        any_corner = False
        all_corners = True
        for loop in loops:
            try:
                luv = loop[uv_layer]
                flag = bool(getattr(luv, 'select', False))
                any_corner = any_corner or flag
                if not flag:
                    all_corners = False
            except Exception:
                all_corners = False
        if any_corner and all_corners:
            selected.add(int(getattr(face, 'index', -1)))
    if selected or not fallback_mesh_selection:
        return selected
    for face in bm.faces:
        try:
            if bool(getattr(face, 'select', False)):
                selected.add(int(getattr(face, 'index', -1)))
        except Exception:
            pass
    return selected


def mark_mesh_seams_from_current_uv_islands(context=None, *, selected_faces: set[int] | None = None, margin_method: str = 'ANGLE_BASED', clear_internal: bool = True) -> int:
    """Synchronize mesh seam flags to the current UV island borders.

    The sync operates only inside the strict selected UV-face scope when that
    scope exists.  Edges between selected and protected non-selected faces are
    marked as seams so the selected UV domain is explicitly cut away from the
    rest of the mesh.  Internal seams whose UV side is continuous are cleared
    when clear_internal is enabled, giving a Blender Mark Seam compliant graph.
    """
    ctx = context or bpy.context
    obj = _active_mesh(ctx)
    if obj is None:
        return 0
    _set_active(ctx, obj)
    attrs = None
    if selected_faces is None:
        try:
            attrs = _read_uv_select_attrs_object_mode(ctx, obj)
        except Exception:
            attrs = None
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed = False
    if old_mode != 'EDIT':
        if not _mode_set('EDIT'):
            return 0
        changed = True
    count = 0
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        try:
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
        except Exception:
            pass
        if selected_faces is None:
            selected = _selected_uv_faces_from_attrs_or_bmesh(obj, bm, uv_layer, attrs, fallback_mesh_selection=True)
        else:
            selected = {int(i) for i in (selected_faces or set())}
        if not selected:
            return 0
        for edge in bm.edges:
            linked_scope = [f for f in getattr(edge, 'link_faces', []) or [] if int(getattr(f, 'index', -1)) in selected]
            if not linked_scope:
                continue
            new_flag = False
            # Selected-domain border, open border, or UV island break.
            all_linked = list(getattr(edge, 'link_faces', []) or [])
            if len(linked_scope) != len(all_linked) or len(linked_scope) <= 1:
                new_flag = True
            else:
                base = linked_scope[0]
                for other in linked_scope[1:]:
                    if not _segments_match(_edge_uv_segment(base, edge, uv_layer), _edge_uv_segment(other, edge, uv_layer)):
                        new_flag = True
                        break
            old_flag = bool(getattr(edge, 'seam', False))
            target = bool(new_flag) or (old_flag and not bool(clear_internal))
            try:
                edge.seam = bool(target)
                if old_flag != bool(target):
                    count += 1
            except Exception:
                pass
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return int(count)
    finally:
        if changed and old_mode != 'EDIT':
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                pass


def apply_marked_seam_compliance(context=None, *, method: str = 'ANGLE_BASED', margin: float = 0.001, force: bool = False, selected_faces: set[int] | None = None) -> bool:
    ctx = context or bpy.context
    if not force and not marked_seam_compliance_enabled(ctx):
        return False
    obj = _active_mesh(ctx)
    if obj is None:
        return False
    _set_active(ctx, obj)
    attrs = None
    if selected_faces is None:
        try:
            attrs = _read_uv_select_attrs_object_mode(ctx, obj)
        except Exception:
            attrs = None
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed = False
    if old_mode != 'EDIT':
        if not _mode_set('EDIT'):
            return False
        changed = True
    mesh_state = None
    selected: set[int] = set()
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        try:
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
        except Exception:
            pass
        if selected_faces is None:
            selected = _selected_uv_faces_from_attrs_or_bmesh(obj, bm, uv_layer, attrs, fallback_mesh_selection=True)
        else:
            selected = {int(i) for i in (selected_faces or set())}
        if not selected:
            return False
        mesh_state = _capture_mesh_selection(bm)
        mark_mesh_seams_from_current_uv_islands(ctx, selected_faces=selected, clear_internal=marked_seam_clear_internal_enabled(ctx))
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        try:
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
        except Exception:
            pass
        selected_edges = set()
        selected_verts = set()
        for face in bm.faces:
            in_scope = int(getattr(face, 'index', -1)) in selected
            try: face.select_set(bool(in_scope))
            except Exception: face.select = bool(in_scope)
            for loop in face.loops:
                try:
                    loop[uv_layer].select = bool(in_scope)
                    loop[uv_layer].select_edge = bool(in_scope)
                except Exception:
                    pass
            if in_scope:
                selected_edges.update(face.edges)
                selected_verts.update(face.verts)
        for edge in bm.edges:
            try: edge.select_set(edge in selected_edges)
            except Exception: edge.select = edge in selected_edges
        for vert in bm.verts:
            try: vert.select_set(vert in selected_verts)
            except Exception: vert.select = vert in selected_verts
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        ok = False
        attempts = (
            dict(method=str(method or 'ANGLE_BASED').upper(), margin=float(margin), fill_holes=True, correct_aspect=True),
            dict(method=str(method or 'ANGLE_BASED').upper(), margin=float(margin)),
            dict(method=str(method or 'ANGLE_BASED').upper()),
        )
        for kwargs in attempts:
            try:
                result = bpy.ops.uv.unwrap(**kwargs)
                ok = 'FINISHED' in set(result or set())
                if ok:
                    break
            except TypeError:
                continue
            except Exception:
                continue
        try:
            mark_mesh_seams_from_current_uv_islands(ctx, selected_faces=selected, clear_internal=marked_seam_clear_internal_enabled(ctx))
        except Exception:
            pass
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        try:
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
        except Exception:
            pass
        if mesh_state is not None:
            _restore_mesh_selection(bm, mesh_state)
        for face in bm.faces:
            in_scope = int(getattr(face, 'index', -1)) in selected
            for loop in face.loops:
                try:
                    loop[uv_layer].select = bool(in_scope)
                    loop[uv_layer].select_edge = bool(in_scope)
                except Exception:
                    pass
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        _write_uv_selection_attrs_object_mode(ctx, obj, selected)
        return bool(ok)
    finally:
        if changed and old_mode != 'EDIT':
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                pass


def standard_mark_seam_selected_edges(context=None, *, clear: bool = False) -> int:
    ctx = context or bpy.context
    obj = _active_mesh(ctx)
    if obj is None:
        return -1
    _set_active(ctx, obj)
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed = False
    if old_mode != 'EDIT':
        if not _mode_set('EDIT'):
            return -1
        changed = True
    count = 0
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        try:
            bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            bm.edges.index_update(); bm.faces.index_update(); bm.verts.index_update()
        except Exception:
            pass
        mesh_state = _capture_mesh_selection(bm)
        target = not bool(clear)
        for edge in bm.edges:
            try:
                if not bool(getattr(edge, 'select', False)):
                    continue
                if bool(getattr(edge, 'seam', False)) != target:
                    edge.seam = bool(target)
                    count += 1
            except Exception:
                pass
        _restore_mesh_selection(bm, mesh_state)
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return int(count)
    finally:
        if changed and old_mode != 'EDIT':
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                pass


def enhanced_auto_seam(context=None, *, mode: str = 'AUTO', scope: str | None = None, angle_threshold=None, clear_existing=None, angle_override=None) -> int:
    class _Op:
        pass
    op = _Op()
    m = str(mode or 'AUTO').upper()
    op.mode = 'ADVANCED' if m in {'ALL', 'AUTO', 'AUTO_SEAM', 'SMART'} else m
    if scope is not None:
        op.scope = scope
    if angle_threshold is not None:
        op.angle_threshold = angle_threshold
    if clear_existing is not None:
        op.clear_existing = clear_existing
    if angle_override is not None:
        op.angle_override = angle_override
    result = run_advanced_auto_seams(context or bpy.context, op)
    if not bool(result.get('ok')):
        return -1
    return int(result.get('marked', 0) or 0)


def sync_after_unwrap_if_enabled(context=None, obj=None, *, selected_faces: set[int] | None = None, method: str = 'ANGLE_BASED', margin: float = 0.001) -> bool:
    ctx = context or bpy.context
    if obj is not None:
        try:
            ctx.view_layer.objects.active = obj
        except Exception:
            pass
    return bool(apply_marked_seam_compliance(ctx, method=method, margin=margin, force=False, selected_faces=selected_faces))


_ORIGINAL_CORE_SEAM_EXECUTE = None


def patch_core_seam_settings_execute() -> bool:
    global _ORIGINAL_CORE_SEAM_EXECUTE
    import sys
    pkg = sys.modules.get(__package__)
    cls = getattr(pkg, 'SMARTUVSUITE_OT_seam_settings_action', None) if pkg is not None else None
    if cls is None:
        return False
    if _ORIGINAL_CORE_SEAM_EXECUTE is None:
        _ORIGINAL_CORE_SEAM_EXECUTE = getattr(cls, 'execute', None)
    old = _ORIGINAL_CORE_SEAM_EXECUTE

    def _execute(self, context):
        action = str(getattr(self, 'action', 'AUTO') or 'AUTO').upper()
        if action == 'MARK_SELECTED':
            count = standard_mark_seam_selected_edges(context, clear=False)
            if count < 0:
                try: self.report({'WARNING'}, _t(context, 'No 3D View selected mesh edges.', '3Dビュー側で選択中のメッシュ辺がありません。'))
                except Exception: pass
                return {'CANCELLED'}
            try: self.report({'INFO'}, _t(context, f'Mark Seam: {count} edges.', f'シームをマーク: {count} 本'))
            except Exception: pass
            return {'FINISHED'}
        if action == 'CLEAR_SELECTED':
            count = standard_mark_seam_selected_edges(context, clear=True)
            if count < 0:
                try: self.report({'WARNING'}, _t(context, 'No 3D View selected mesh edges.', '3Dビュー側で選択中のメッシュ辺がありません。'))
                except Exception: pass
                return {'CANCELLED'}
            try: self.report({'INFO'}, _t(context, f'Clear Seam: {count} edges.', f'シームをクリア: {count} 本'))
            except Exception: pass
            return {'FINISHED'}
        if action in {'PIN', 'CLEAR_PINS', 'UNPIN', 'INVERT_PINS'}:
            count = pin_uv_selection(context, action=action)
            if count < 0:
                try: self.report({'WARNING'}, _t(context, 'No UV Editor selection was found for pin operation.', 'ピン操作対象のUVエディター選択がありません。'))
                except Exception: pass
                return {'CANCELLED'}
            label = {'PIN': 'Pin', 'CLEAR_PINS': 'Unpin', 'UNPIN': 'Unpin', 'INVERT_PINS': 'Invert Pins'}.get(action, 'Pin')
            label_ja = {'PIN': 'ピン', 'CLEAR_PINS': 'ピン解除', 'UNPIN': 'ピン解除', 'INVERT_PINS': 'ピン反転'}.get(action, 'ピン')
            try: self.report({'INFO'}, _t(context, f'{label}: {count} UV loop(s).', f'{label_ja}: {count} UVループ'))
            except Exception: pass
            return {'FINISHED'}
        if action in {'AUTO', 'SMART', 'ANGLE', 'BOUNDARY'}:
            mode = 'AUTO' if action in {'AUTO', 'SMART'} else action
            # The buttons leave `angle` unset and use the panel threshold; an explicit value wins.
            angle_set = self.properties.is_property_set('angle')
            count = enhanced_auto_seam(context, mode=mode, angle_override=math.radians(float(self.angle)) if angle_set else None)
            if count >= 0:
                try: self.report({'INFO'}, _t(context, f'Auto Seam: {count} edges.', f'自動シーム: {count} 本'))
                except Exception: pass
                return {'FINISHED'}
        if callable(old):
            return old(self, context)
        return {'CANCELLED'}

    try:
        cls.execute = _execute
        return True
    except Exception:
        return False


# Register wrapper override: keep previous operator registration behavior and add
# the core seam-settings patch so UV Editor UI buttons target 3D View selection.
_PREVIOUS_REGISTER = _suv_stage_001_register
_PREVIOUS_UNREGISTER = _suv_stage_001_unregister

def register() -> None:
    try:
        if callable(_PREVIOUS_REGISTER):
            _PREVIOUS_REGISTER()
    except Exception:
        pass
    try:
        patch_core_seam_settings_execute()
    except Exception:
        pass


def unregister() -> None:
    try:
        global _ORIGINAL_CORE_SEAM_EXECUTE
        import sys
        pkg = sys.modules.get(__package__)
        cls = getattr(pkg, 'SMARTUVSUITE_OT_seam_settings_action', None) if pkg is not None else None
        if cls is not None and _ORIGINAL_CORE_SEAM_EXECUTE is not None:
            cls.execute = _ORIGINAL_CORE_SEAM_EXECUTE
        _ORIGINAL_CORE_SEAM_EXECUTE = None
    except Exception:
        pass
    try:
        if callable(_PREVIOUS_UNREGISTER):
            _PREVIOUS_UNREGISTER()
    except Exception:
        pass

# Override AUTO cylinder-axis detection with edge-direction voting.  Bounding-box
# ties on short cylinders can otherwise choose X/Y and produce cap-ring seams but
# no longitudinal tube cut.
def _axis_from_settings(settings: dict[str, Any], faces: Iterable) -> tuple[Vector, int]:
    mode = str(settings.get('cylinder_axis', 'AUTO') or 'AUTO').upper()
    if mode == 'X':
        return Vector((1, 0, 0)), 0
    if mode == 'Y':
        return Vector((0, 1, 0)), 1
    if mode == 'Z':
        return Vector((0, 0, 1)), 2
    axes = (Vector((1, 0, 0)), Vector((0, 1, 0)), Vector((0, 0, 1)))
    scores = [0.0, 0.0, 0.0]
    seen = set()
    try:
        for face in faces:
            for edge in getattr(face, 'edges', []) or []:
                idx = int(getattr(edge, 'index', -1))
                if idx in seen:
                    continue
                seen.add(idx)
                direction = _edge_direction(edge)
                length = _edge_length(edge)
                if direction.length <= _EPS or length <= _EPS:
                    continue
                for i, axis in enumerate(axes):
                    a = abs(float(direction.dot(axis)))
                    scores[i] += length * (a ** 4)
    except Exception:
        pass
    if max(scores) > _EPS:
        idx = max(range(3), key=lambda i: scores[i])
        return axes[idx], idx
    return _bounds_axis_for_faces(faces)

# Use additive weighted evidence rather than averaging against unrelated zero
# features.  This lets a strong angle, tube, sharp, material or boundary signal
# mark a seam on its own.  An angle well below the limit counts for little, and
# loop continuity and stretch only reinforce an edge that already has evidence:
# nearly every edge of a quad mesh continues a loop, so they cannot be a reason
# to cut by themselves.
def _edge_score(edge, candidate_set: set, face_scope: Iterable, settings: dict[str, Any], cyl_scores: dict[int, float], axis: Vector) -> float:
    angle_limit = float(settings.get('angle_threshold', math.radians(60.0)) or math.radians(60.0))
    feat = _edge_basic_features(edge, angle_limit)
    angle_ratio = max(0.0, min(1.0, float(feat.get('angle', 0.0) or 0.0) / max(angle_limit, 1.0e-6)))

    def weighted(values: dict[str, float]) -> float:
        total = 0.0
        for key, value in values.items():
            w = max(0.0, min(100.0, float(settings.get(key, 0.0) or 0.0)))
            total += w * max(0.0, min(100.0, float(value))) / 100.0
        return total

    evidence = weighted({
        'angle_weight': 100.0 * angle_ratio ** 3,
        'sharp_weight': 100.0 if bool(feat.get('sharp')) else 0.0,
        'material_weight': 100.0 if bool(feat.get('material')) else 0.0,
        'boundary_weight': 100.0 if bool(feat.get('boundary')) else 0.0,
        'cylinder_strength': float(cyl_scores.get(int(getattr(edge, 'index', -1)), 0.0) or 0.0),
    })
    support = weighted({
        'loop_weight': _loop_continuity_score(edge, candidate_set, axis),
        'stretch_weight': float(feat.get('density_score', 0.0) or 0.0),
    })
    threshold = max(1.0e-6, float(settings.get('score_threshold', 54.0) or 0.0))
    return max(0.0, min(100.0, evidence + support * min(1.0, evidence / threshold)))

# ---------------------------------------------------------------------------
# 1.6.23 Pre-unwrap Mark Seam component compliance
# ---------------------------------------------------------------------------
# The previous compliance hook converted UV islands back to mesh seams after an
# unwrap.  The active contract is the opposite: existing Blender mesh seam marks
# are authoritative before the unwrap.  Selected UV faces are split into 3D face
# components through non-seam edges, each component is unwrapped separately, and
# the full selected UV-face scope is restored for the final pack step.

def marked_seam_pre_split_enabled(context=None) -> bool:
    return bool(marked_seam_compliance_enabled(context))


def _edge_is_marked_for_pre_split(edge, seam_layer=None) -> bool:
    try:
        if seam_layer is not None:
            return bool(int(edge[seam_layer]))
    except Exception:
        pass
    try:
        return bool(getattr(edge, 'seam', False))
    except Exception:
        return False


def marked_seam_face_components(context=None, obj=None, *, selected_faces: set[int] | None = None, use_original_layer: bool = True) -> list[set[int]]:
    """Return selected face components separated by Blender mesh seam marks.

    Connectivity crosses only edges that are *not* marked as seams.  Selection is
    still the strict complete UV-face scope; partial UV vertex/edge selections do
    not become unwrap components.
    """
    ctx = context or bpy.context
    obj = obj or _active_mesh(ctx)
    if obj is None or getattr(obj, 'type', '') != 'MESH':
        return []
    _set_active(ctx, obj)
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed = False
    if old_mode != 'EDIT':
        if not _mode_set('EDIT'):
            return []
        changed = True
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        try:
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
        except Exception:
            pass
        if selected_faces is None:
            selected_faces = _selected_uv_face_indices(ctx, obj, bm, uv_layer, fallback_mesh_selection=True)
        selected = {int(i) for i in (selected_faces or set())}
        selected = {i for i in selected if 0 <= i < len(bm.faces)}
        if not selected:
            return []
        seam_layer = None
        if use_original_layer:
            try:
                seam_layer = bm.edges.layers.int.get('suv_original_seam')
            except Exception:
                seam_layer = None
        face_by_index = {int(f.index): f for f in bm.faces if int(f.index) in selected}
        remaining = set(face_by_index.keys())
        components: list[set[int]] = []
        while remaining:
            start = remaining.pop()
            comp = {start}
            queue = [face_by_index[start]]
            while queue:
                face = queue.pop(0)
                for edge in getattr(face, 'edges', []) or []:
                    if _edge_is_marked_for_pre_split(edge, seam_layer):
                        continue
                    for other in getattr(edge, 'link_faces', []) or []:
                        oi = int(getattr(other, 'index', -1))
                        if oi not in remaining:
                            continue
                        remaining.remove(oi)
                        comp.add(oi)
                        queue.append(other)
            components.append(comp)
        components.sort(key=lambda c: (min(c) if c else 10**12, len(c)))
        return components
    finally:
        if changed and old_mode != 'EDIT':
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                pass


def select_uv_face_component_for_native_ops(context=None, obj=None, face_indices: set[int] | list[int] | tuple[int, ...] | None = None) -> bool:
    """Temporarily select exactly one complete UV-face component for native UV ops."""
    ctx = context or bpy.context
    obj = obj or _active_mesh(ctx)
    if obj is None or getattr(obj, 'type', '') != 'MESH':
        return False
    selected = {int(i) for i in (face_indices or set())}
    if not selected:
        return False
    _set_active(ctx, obj)
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed = False
    if old_mode != 'EDIT':
        if not _mode_set('EDIT'):
            return False
        changed = True
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        try:
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
        except Exception:
            pass
        selected_edges = set()
        selected_verts = set()
        for face in bm.faces:
            in_scope = int(getattr(face, 'index', -1)) in selected
            try:
                face.select_set(bool(in_scope))
            except Exception:
                try: face.select = bool(in_scope)
                except Exception: pass
            if in_scope:
                try: selected_edges.update(face.edges)
                except Exception: pass
                try: selected_verts.update(face.verts)
                except Exception: pass
            for loop in getattr(face, 'loops', []) or []:
                try:
                    luv = loop[uv_layer]
                    if hasattr(luv, 'select'):
                        luv.select = bool(in_scope)
                    if hasattr(luv, 'select_edge'):
                        luv.select_edge = bool(in_scope)
                except Exception:
                    pass
        for edge in bm.edges:
            try:
                edge.select_set(edge in selected_edges)
            except Exception:
                try: edge.select = edge in selected_edges
                except Exception: pass
        for vert in bm.verts:
            try:
                vert.select_set(vert in selected_verts)
            except Exception:
                try: vert.select = vert in selected_verts
                except Exception: pass
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        _write_uv_selection_attrs_object_mode(ctx, obj, selected)
        return True
    finally:
        if changed and old_mode != 'EDIT':
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                pass


def restore_full_uv_face_scope_for_native_ops(context=None, obj=None, selected_faces: set[int] | list[int] | tuple[int, ...] | None = None) -> bool:
    return select_uv_face_component_for_native_ops(context, obj, set(selected_faces or set()))


# Post-unwrap seam conversion is intentionally disabled in 1.6.23.  All routes
# now consume mesh seam marks before unwrapping instead of rewriting/re-unwrapping
# from UV islands afterward.
def sync_after_unwrap_if_enabled(context=None, obj=None, *, selected_faces: set[int] | None = None, method: str = 'ANGLE_BASED', margin: float = 0.001) -> bool:  # noqa: D401
    return False


# ---------------------------------------------------------------------------
# 1.6.26 Robust seam/pin persistence helpers, strict face-scope baseline support
# ---------------------------------------------------------------------------
def strict_uv_face_selection_indices(context=None, obj=None, *, fallback_mesh_selection: bool = False) -> set[int]:
    """Return only UV Editor complete face selections.

    A face is accepted only when Blender's UV-face flag is selected and every UV
    corner is selected.  Partial vertex/edge selections and adjacent faces sharing
    only a vertex are deliberately ignored.
    """
    ctx = context or bpy.context
    obj = obj or _active_mesh(ctx)
    if obj is None or getattr(obj, 'type', '') != 'MESH':
        return set()
    _set_active(ctx, obj)
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed = False
    try:
        attrs = _read_uv_select_attrs_object_mode(ctx, obj)
    except Exception:
        attrs = {}
    if old_mode != 'EDIT':
        if not _mode_set('EDIT'):
            return set()
        changed = True
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        return set(_selected_uv_face_indices(ctx, obj, bm, uv_layer, fallback_mesh_selection=fallback_mesh_selection))
    finally:
        if changed and old_mode != 'EDIT':
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                pass


def _current_baseline_settings(context=None, baseline_axis=None, threshold=None) -> tuple[str, float]:
    ws = _ws(context)
    if baseline_axis is None:
        baseline_axis = _settings_enum(ws, ('smart_standard_core_baseline_axis', 'baseline_axis'), 'NONE')
    axis = str(baseline_axis or 'NONE').upper()
    if threshold is None:
        threshold = _settings_float(ws, ('smart_standard_core_baseline_threshold', 'baseline_threshold'), 0.001, 0.0, 10.0)
    try:
        threshold = float(threshold)
    except Exception:
        threshold = 0.001
    return axis, max(0.0, threshold)


def _baseline_pairs_to_loop_groups(bm, face_by_index: dict[int, object], baseline_pairs) -> list[list]:
    """Build selected UV edge/strand loop groups from stored face/loop positions."""
    pair_records = []
    for item in baseline_pairs or []:
        try:
            fi = int(item[0]); pos_a = int(item[1]); pos_b = int(item[2])
            face = face_by_index.get(fi)
            loops = list(getattr(face, 'loops', []) or []) if face is not None else []
            if not loops:
                continue
            la = loops[pos_a % len(loops)]
            lb = loops[pos_b % len(loops)]
            pair_records.append((la, lb))
        except Exception:
            continue
    if not pair_records:
        return []
    node_index = {}
    nodes = []
    def key_for_loop(loop):
        try:
            # A selected UV strand should keep coincident UV loops on the same mesh
            # vertex together, but avoid merging unrelated stacked islands by face id.
            return (int(loop.vert.index), round(float(loop.link_loop_next[loop.face.loops.layers.uv.active].uv.x), 6))
        except Exception:
            return (id(loop),)
    # Use object identity for graph endpoints, then expand by shared mesh vertex so
    # two selected edges meeting at the same vertex remain in one strand.
    vert_to_nodes = {}
    for la, lb in pair_records:
        for loop in (la, lb):
            k = id(loop)
            if k not in node_index:
                node_index[k] = len(nodes)
                nodes.append(loop)
                try:
                    vert_to_nodes.setdefault(int(loop.vert.index), []).append(node_index[k])
                except Exception:
                    pass
    adj = {i: set() for i in range(len(nodes))}
    for la, lb in pair_records:
        ia = node_index.get(id(la)); ib = node_index.get(id(lb))
        if ia is None or ib is None:
            continue
        adj[ia].add(ib); adj[ib].add(ia)
    for inds in vert_to_nodes.values():
        if len(inds) <= 1:
            continue
        first = inds[0]
        for idx in inds[1:]:
            adj[first].add(idx); adj[idx].add(first)
    visited = set(); groups = []
    for i in range(len(nodes)):
        if i in visited:
            continue
        visited.add(i); q=[i]; comp=[]
        while q:
            cur=q.pop(0); comp.append(nodes[cur])
            for nb in adj.get(cur, ()): 
                if nb not in visited:
                    visited.add(nb); q.append(nb)
        if comp:
            groups.append(comp)
    return groups


def apply_baseline_straightening_to_uv_scope(context=None, obj=None, *, selected_faces: set[int] | None = None, baseline_axis=None, threshold=None, baseline_pairs=None) -> bool:
    """Apply the Smart UV baseline straightening rule to the strict UV-face scope.

    This is intentionally lightweight and is used after Blender-native unwraps so
    the same 基準直線化 setting affects Angle Based, Conformal, Min Stretch,
    Smart Project, Lightmap, Follow Quads and projection modes.  Mesh selection,
    user seams and user pins are restored; only selected UV-face coordinates are
    adjusted.
    """
    ctx = context or bpy.context
    obj = obj or _active_mesh(ctx)
    if obj is None or getattr(obj, 'type', '') != 'MESH':
        return False
    axis, threshold = _current_baseline_settings(ctx, baseline_axis, threshold)
    if axis in {'', 'NONE', 'OFF'}:
        return False
    _set_active(ctx, obj)
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed = False
    if old_mode != 'EDIT':
        if not _mode_set('EDIT'):
            return False
        changed = True
    changed_uv = False
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        try:
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
        except Exception:
            pass
        if selected_faces is None:
            selected_faces = _selected_uv_face_indices(ctx, obj, bm, uv_layer, fallback_mesh_selection=False)
        selected = {int(i) for i in (selected_faces or set())}
        if not selected:
            return False
        mesh_state = _capture_mesh_selection(bm)
        seam_state = {int(e.index): bool(getattr(e, 'seam', False)) for e in bm.edges}
        pin_state = {}
        for face in bm.faces:
            for pos, loop in enumerate(list(face.loops)):
                try:
                    pin_state[(int(face.index), int(pos))] = bool(getattr(loop[uv_layer], 'pin_uv', False))
                except Exception:
                    pass
        face_by_index = {int(f.index): f for f in bm.faces}
        selected_face_objs = [f for f in bm.faces if int(f.index) in selected]
        if axis == 'SELECTED':
            groups = _baseline_pairs_to_loop_groups(bm, face_by_index, baseline_pairs)
        else:
            axis_idx = {'X': 0, 'Y': 1, 'Z': 2}.get(axis)
            if axis_idx is None:
                return False
            scoped_edges = set()
            scoped_verts = set()
            for face in selected_face_objs:
                scoped_verts.update(list(face.verts))
                scoped_edges.update(list(face.edges))
            target_verts = {v for v in scoped_verts if abs(float(v.co[axis_idx])) <= threshold}
            unvisited = set(target_verts)
            groups = []
            while unvisited:
                v = unvisited.pop()
                comp = {v}; q=[v]
                while q:
                    cur = q.pop(0)
                    for edge in getattr(cur, 'link_edges', []) or []:
                        if edge not in scoped_edges:
                            continue
                        other = edge.other_vert(cur)
                        if other in unvisited:
                            unvisited.remove(other); comp.add(other); q.append(other)
                loops = []
                for vert in comp:
                    for loop in getattr(vert, 'link_loops', []) or []:
                        try:
                            if int(loop.face.index) in selected:
                                loops.append(loop)
                        except Exception:
                            pass
                if loops:
                    groups.append(loops)
        for loops in groups:
            if len(loops) < 2:
                continue
            u_coords = [] ; v_coords = []
            for loop in loops:
                try:
                    uv = loop[uv_layer].uv
                    u_coords.append(float(uv.x)); v_coords.append(float(uv.y))
                except Exception:
                    pass
            if len(u_coords) < 2:
                continue
            avg_u = sum(u_coords) / len(u_coords)
            avg_v = sum(v_coords) / len(v_coords)
            var_u = sum((u - avg_u) ** 2 for u in u_coords)
            var_v = sum((v - avg_v) ** 2 for v in v_coords)
            vertical = var_u < var_v
            for loop in loops:
                try:
                    if vertical:
                        loop[uv_layer].uv.x = avg_u
                    else:
                        loop[uv_layer].uv.y = avg_v
                    changed_uv = True
                except Exception:
                    pass
        for edge in bm.edges:
            try:
                edge.seam = bool(seam_state.get(int(edge.index), bool(getattr(edge, 'seam', False))))
            except Exception:
                pass
        for face in bm.faces:
            for pos, loop in enumerate(list(face.loops)):
                key = (int(face.index), int(pos))
                if key in pin_state:
                    try:
                        loop[uv_layer].pin_uv = bool(pin_state[key])
                    except Exception:
                        pass
            in_scope = int(face.index) in selected
            for loop in face.loops:
                try:
                    loop[uv_layer].select = bool(in_scope)
                    loop[uv_layer].select_edge = bool(in_scope)
                except Exception:
                    pass
        _restore_mesh_selection(bm, mesh_state)
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        if changed_uv:
            _write_uv_selection_attrs_object_mode(ctx, obj, selected)
        return bool(changed_uv)
    finally:
        if changed and old_mode != 'EDIT':
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                pass


def force_strict_uv_face_selection_after_operation(context=None, obj=None, *, selected_faces: set[int] | None = None) -> bool:
    ctx = context or bpy.context
    obj = obj or _active_mesh(ctx)
    if obj is None or getattr(obj, 'type', '') != 'MESH':
        return False
    if selected_faces is None:
        selected_faces = strict_uv_face_selection_indices(ctx, obj, fallback_mesh_selection=False)
    selected = {int(i) for i in (selected_faces or set())}
    if not selected:
        return False
    _write_uv_selection_attrs_object_mode(ctx, obj, selected)
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed = False
    if old_mode != 'EDIT':
        if not _mode_set('EDIT'):
            return False
        changed = True
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        for face in bm.faces:
            in_scope = int(getattr(face, 'index', -1)) in selected
            for loop in face.loops:
                try:
                    loop[uv_layer].select = bool(in_scope)
                    loop[uv_layer].select_edge = bool(in_scope)
                except Exception:
                    pass
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return True
    finally:
        if changed and old_mode != 'EDIT':
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                pass

# ---------------------------------------------------------------------------
# 1.6.26 final seam/pin compliance overrides
# ---------------------------------------------------------------------------
# These definitions intentionally appear last.  Earlier compatibility blocks in
# this add-on are kept for saved-file compatibility, but the final behavior is:
# - Blender mesh Mark Seam is consumed before unwrapping and is never rewritten
#   from UV islands afterward.
# - Mark/Clear Seam always targets the 3D View selected mesh edges, even when
#   the button is invoked from the UV Editor N-panel.
# - Pin/Unpin/Invert Pin uses the UV Editor selection attributes and preserves
#   the 3D mesh selection.


def _suv_1626_loop_flag(flags, idx: int) -> bool:
    try:
        return 0 <= int(idx) < len(flags) and bool(flags[int(idx)])
    except Exception:
        return False


def _suv_1626_selected_uv_loop_indices(context=None, obj=None) -> set[int]:
    ctx = context or bpy.context
    obj = obj or _active_mesh(ctx)
    selected: set[int] = set()
    if obj is None or getattr(obj, 'type', '') != 'MESH':
        return selected
    attrs = _read_uv_select_attrs_object_mode(ctx, obj)
    vflags = list(attrs.get('vert') or [])
    eflags = list(attrs.get('edge') or [])
    fflags = list(attrs.get('face') or [])
    try:
        old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
        changed = False
        if old_mode != 'EDIT':
            _set_active(ctx, obj)
            if _mode_set('EDIT'):
                changed = True
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
            try:
                bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
                bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
            except Exception:
                pass
            for face in bm.faces:
                face_flag = _suv_1626_loop_flag(fflags, int(getattr(face, 'index', -1)))
                for loop in face.loops:
                    li = int(getattr(loop, 'index', -1))
                    try:
                        luv = loop[uv_layer]
                        lsel = bool(getattr(luv, 'select', False)) or bool(getattr(luv, 'select_edge', False))
                    except Exception:
                        lsel = False
                    if face_flag or _suv_1626_loop_flag(vflags, li) or _suv_1626_loop_flag(eflags, li) or lsel:
                        selected.add(li)
            return selected
        finally:
            if changed and old_mode != 'EDIT':
                try:
                    bpy.ops.object.mode_set(mode=old_mode)
                except Exception:
                    pass
    except Exception:
        return selected


def standard_mark_seam_selected_edges(context=None, clear: bool = False) -> int:  # noqa: D401
    """Blender-standard Mark/Clear Seam using the 3D View mesh-edge selection."""
    ctx = context or bpy.context
    obj = _active_mesh(ctx)
    if obj is None or getattr(obj, 'type', '') != 'MESH':
        return -1
    _set_active(ctx, obj)
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed_mode = False
    if old_mode != 'EDIT':
        if not _mode_set('EDIT'):
            return -1
        changed_mode = True
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        try:
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
        except Exception:
            pass
        mesh_state = _capture_mesh_selection(bm)
        selected_edges = [e for e in bm.edges if bool(getattr(e, 'select', False))]
        if not selected_edges:
            # Match the command intent requested by the user: the N-panel button
            # still operates on the 3D View edge selection.  No selected edge
            # means no implicit UV-based fallback and no accidental full clear.
            return -1
        for edge in selected_edges:
            try:
                edge.seam = not bool(clear)
            except Exception:
                pass
        _restore_mesh_selection(bm, mesh_state)
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return len(selected_edges)
    finally:
        if changed_mode and old_mode != 'EDIT':
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                pass


def pin_uv_selection(context=None, action: str = 'PIN') -> int:  # noqa: D401
    """Pin, unpin, or invert UV pins using the UV Editor selection."""
    ctx = context or bpy.context
    obj = _active_mesh(ctx)
    if obj is None or getattr(obj, 'type', '') != 'MESH':
        return -1
    action_u = str(action or 'PIN').upper()
    if action_u in {'CLEAR', 'CLEAR_PINS', 'UNPIN', 'UNPIN_SELECTED'}:
        action_u = 'UNPIN'
    elif action_u in {'INVERT', 'INVERT_PINS', 'PIN_INVERT'}:
        action_u = 'INVERT'
    else:
        action_u = 'PIN'
    if ctx.scene.tool_settings.use_uv_select_sync:
        # Sync mode uses mesh selection, not the independent UV selection
        # attributes. Let Blender resolve its vertex/edge/face semantics.
        _set_active(ctx, obj)
        old_mode = obj.mode
        if old_mode != 'EDIT' and not _mode_set('EDIT'):
            return -1
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
            before = [loop[uv_layer].pin_uv for face in bm.faces for loop in face.loops]
            bpy.ops.uv.pin('EXEC_DEFAULT', clear=action_u == 'UNPIN', invert=action_u == 'INVERT')
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.active
            after = [loop[uv_layer].pin_uv for face in bm.faces for loop in face.loops]
            return sum(a != b for a, b in zip(before, after))
        finally:
            if old_mode != 'EDIT':
                bpy.ops.object.mode_set(mode=old_mode)
    selected_loop_indices = _suv_1626_selected_uv_loop_indices(ctx, obj)
    _set_active(ctx, obj)
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed_mode = False
    if old_mode != 'EDIT':
        if not _mode_set('EDIT'):
            return -1
        changed_mode = True
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        try:
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
        except Exception:
            pass
        mesh_state = _capture_mesh_selection(bm)
        if not selected_loop_indices and action_u == 'UNPIN':
            # Native Unpin clears all UV pins when nothing is selected.
            selected_loop_indices = {int(getattr(loop, 'index', -1)) for face in bm.faces for loop in face.loops if int(getattr(loop, 'index', -1)) >= 0}
        if not selected_loop_indices:
            return 0
        count = 0
        for face in bm.faces:
            for loop in face.loops:
                li = int(getattr(loop, 'index', -1))
                if li not in selected_loop_indices:
                    continue
                try:
                    luv = loop[uv_layer]
                    if action_u == 'UNPIN':
                        luv.pin_uv = False
                    elif action_u == 'INVERT':
                        luv.pin_uv = not bool(getattr(luv, 'pin_uv', False))
                    else:
                        luv.pin_uv = True
                    count += 1
                except Exception:
                    pass
        _restore_mesh_selection(bm, mesh_state)
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return count
    finally:
        if changed_mode and old_mode != 'EDIT':
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                pass


def marked_seam_face_components(context=None, obj=None, selected_faces: set[int] | list[int] | tuple[int, ...] | None = None, *, use_original_layer: bool = True) -> list[set[int]]:  # noqa: D401
    """Split the strict selected UV-face scope by Blender mesh Mark Seam edges."""
    ctx = context or bpy.context
    obj = obj or _active_mesh(ctx)
    if obj is None or getattr(obj, 'type', '') != 'MESH':
        return []
    _set_active(ctx, obj)
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed = False
    if old_mode != 'EDIT':
        if not _mode_set('EDIT'):
            return []
        changed = True
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        try:
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
        except Exception:
            pass
        if selected_faces is None:
            selected_faces = _selected_uv_face_indices(ctx, obj, bm, uv_layer, fallback_mesh_selection=False)
        selected = {int(i) for i in (selected_faces or set())}
        selected = {i for i in selected if 0 <= i < len(bm.faces)}
        if not selected:
            return []
        seam_layer = None
        if use_original_layer:
            try:
                seam_layer = bm.edges.layers.int.get('suv_original_seam')
            except Exception:
                seam_layer = None
        face_by_index = {int(f.index): f for f in bm.faces if int(f.index) in selected}
        remaining = set(face_by_index.keys())
        components: list[set[int]] = []
        while remaining:
            start = remaining.pop()
            comp = {start}
            queue = [face_by_index[start]]
            while queue:
                face = queue.pop(0)
                for edge in getattr(face, 'edges', []) or []:
                    if _edge_is_marked_for_pre_split(edge, seam_layer):
                        continue
                    for other in getattr(edge, 'link_faces', []) or []:
                        oi = int(getattr(other, 'index', -1))
                        if oi not in remaining:
                            continue
                        remaining.remove(oi)
                        comp.add(oi)
                        queue.append(other)
            components.append(comp)
        components.sort(key=lambda c: (min(c) if c else 10**12, len(c)))
        return components
    finally:
        if changed and old_mode != 'EDIT':
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                pass


def apply_marked_seam_compliance(context=None, obj=None, *, selected_faces=None, method: str = 'ANGLE_BASED', margin: float = 0.001) -> bool:  # noqa: D401
    return False


def sync_after_unwrap_if_enabled(context=None, obj=None, *, selected_faces: set[int] | None = None, method: str = 'ANGLE_BASED', margin: float = 0.001) -> bool:  # noqa: D401
    return False


# ---------------------------------------------------------------------------
# 1.6.45 Crease value to Mark Seam
# ---------------------------------------------------------------------------

def _edge_crease_float_layer(bm):
    """Return the active Blender 4/5 edge crease custom-data layer when present."""
    try:
        layers = getattr(getattr(bm, 'edges', None), 'layers', None)
        if layers is None:
            return None
        # Blender 4.x/5.x stores edge creases as the generic EDGE float attribute
        # named "crease_edge".  Older or imported files can expose legacy names;
        # keep the lookup tolerant without creating a new layer.
        float_layers = getattr(layers, 'float', None)
        if float_layers is not None:
            for name in ('crease_edge', 'Crease', 'crease', 'edge_crease'):
                try:
                    layer = float_layers.get(name)
                except Exception:
                    layer = None
                if layer is not None:
                    return layer
        # Very old BMesh builds exposed a dedicated crease collection.
        crease_layers = getattr(layers, 'crease', None)
        if crease_layers is not None:
            for name in ('crease_edge', 'Crease', 'crease'):
                try:
                    layer = crease_layers.get(name)
                except Exception:
                    layer = None
                if layer is not None:
                    return layer
            try:
                return crease_layers.active
            except Exception:
                return None
    except Exception:
        return None
    return None


def _mesh_edge_crease_values_object_mode(context, obj) -> tuple[dict[int, float], bool]:
    """Read object-mode crease_edge values as a fallback for unsynchronized builds."""
    ctx = context or bpy.context
    if obj is None or getattr(obj, 'type', '') != 'MESH':
        return {}, False
    me = getattr(obj, 'data', None)
    if me is None:
        return {}, False
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed = False
    try:
        if old_mode != 'OBJECT':
            try:
                _set_active(ctx, obj)
                bpy.ops.object.mode_set(mode='OBJECT')
                changed = True
            except Exception:
                return {}, False
        attrs = getattr(me, 'attributes', None)
        if attrs is None:
            return {}, False
        attr = None
        for name in ('crease_edge', 'Crease', 'crease', 'edge_crease'):
            try:
                cand = attrs.get(name)
            except Exception:
                cand = None
            if cand is not None:
                try:
                    if str(getattr(cand, 'domain', '') or '').upper() not in {'EDGE', ''}:
                        continue
                except Exception:
                    pass
                attr = cand
                break
        if attr is None:
            return {}, False
        values: dict[int, float] = {}
        for i, item in enumerate(getattr(attr, 'data', []) or []):
            try:
                values[int(i)] = float(getattr(item, 'value', 0.0) or 0.0)
            except Exception:
                values[int(i)] = 0.0
        return values, True
    finally:
        if changed:
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                try:
                    bpy.ops.object.mode_set(mode='EDIT')
                except Exception:
                    pass


def mark_seams_by_edge_crease_value(context=None, *, crease_value: float = 1.0, tolerance: float = 0.001, apply_mode: str = 'ADD') -> int:
    """Mark mesh seams on edges whose Edge Crease equals the requested value.

    apply_mode='ADD' keeps existing seams and adds matching edges.
    apply_mode='REPLACE' clears every existing seam first, then marks only matches.
    The operation is mesh-side, uses the active object's edge crease data, and
    restores the 3D View mesh selection state after writing seam flags.
    """
    ctx = context or bpy.context
    obj = _active_mesh(ctx)
    if obj is None or getattr(obj, 'type', '') != 'MESH':
        return -1
    target = max(0.0, min(1.0, float(crease_value if crease_value is not None else 1.0)))
    tol = max(0.0, float(tolerance if tolerance is not None else 0.0))
    mode = str(apply_mode or 'ADD').upper()
    if mode not in {'ADD', 'REPLACE', 'CLEAR_FIRST'}:
        mode = 'ADD'
    object_values, object_values_found = _mesh_edge_crease_values_object_mode(ctx, obj)
    _set_active(ctx, obj)
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed_mode = False
    if old_mode != 'EDIT':
        if not _mode_set('EDIT'):
            return -1
        changed_mode = True
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        try:
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
        except Exception:
            pass
        mesh_state = _capture_mesh_selection(bm)
        crease_layer = _edge_crease_float_layer(bm)
        has_crease_data = bool(crease_layer is not None or object_values_found)
        if not has_crease_data:
            return -2
        if mode in {'REPLACE', 'CLEAR_FIRST'}:
            for edge in bm.edges:
                try:
                    edge.seam = False
                except Exception:
                    pass
        matched = 0
        for edge in bm.edges:
            try:
                ei = int(getattr(edge, 'index', -1))
            except Exception:
                ei = -1
            value = 0.0
            got_value = False
            if crease_layer is not None:
                try:
                    value = float(edge[crease_layer] or 0.0)
                    got_value = True
                except Exception:
                    got_value = False
            if not got_value and object_values_found:
                try:
                    value = float(object_values.get(ei, 0.0) or 0.0)
                    got_value = True
                except Exception:
                    got_value = False
            if not got_value:
                continue
            if abs(float(value) - target) <= tol:
                try:
                    edge.seam = True
                    matched += 1
                except Exception:
                    pass
        _restore_mesh_selection(bm, mesh_state)
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return matched
    finally:
        if changed_mode and old_mode != 'EDIT':
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                pass

# ---------------------------------------------------------------------------
# 1.6.44 Baseline constrained low-distortion relaxation
# ---------------------------------------------------------------------------
# Previous baseline handling made only the baseline loops straight after the
# unwrap.  That produced a visible failure mode where the strand itself became a
# line but the surrounding UV vertices kept the old solve and distorted around
# the constraint.  This replacement treats the straightened baseline as a fixed
# constraint, then solves a smooth displacement field over the whole selected UV
# island and applies a bounded edge-length relaxation.  The original unwrap from
# the selected mode remains the initial solution, so Smart Project, Angle Based,
# Conformal, projections, etc. keep their characteristic layout while the
# baseline constraint is propagated through the chart.


def _sus_1644_v2(value) -> Vector:
    try:
        return Vector((float(value[0]), float(value[1])))
    except Exception:
        return Vector((0.0, 0.0))


def _sus_1644_loop_key(loop, uv_layer, precision: int = 7):
    try:
        uv = loop[uv_layer].uv
        return (int(loop.vert.index), round(float(uv.x), precision), round(float(uv.y), precision))
    except Exception:
        return (id(loop),)


def _sus_1644_world_edge_length(obj, edge) -> float:
    try:
        mw = getattr(obj, 'matrix_world', None)
        a = edge.verts[0].co.copy(); b = edge.verts[1].co.copy()
        if mw is not None:
            a = mw @ a; b = mw @ b
        return float((b - a).length)
    except Exception:
        return 0.0


def _sus_1644_signed_area_for_node_loop(face, uv_layer, node_by_loop_id: dict[int, int], coords: dict[int, Vector]) -> float:
    loops = list(getattr(face, 'loops', ()) or ())
    if len(loops) < 3:
        return 0.0
    pts = []
    for loop in loops:
        nid = node_by_loop_id.get(id(loop))
        if nid is None:
            return 0.0
        pts.append(coords.get(nid, _sus_1644_v2(loop[uv_layer].uv)))
    area = 0.0
    for i, p in enumerate(pts):
        q = pts[(i + 1) % len(pts)]
        area += float(p.x * q.y - q.x * p.y)
    return area * 0.5


def _sus_1644_build_uv_graph(obj, bm, uv_layer, selected: set[int]):
    """Return node graph for selected UV faces.

    Nodes are UV vertices, not mesh vertices: coincident UV loops on the same
    mesh vertex are grouped, while seam-separated loops remain independent when
    their UV positions differ.  Edges are face boundary edges in UV space.
    """
    node_by_key: dict[tuple, int] = {}
    node_by_loop_id: dict[int, int] = {}
    loops_by_node: dict[int, list] = {}
    coords: dict[int, Vector] = {}
    faces = []
    try:
        bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
        bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
    except Exception:
        pass
    for face in bm.faces:
        fi = int(getattr(face, 'index', -1))
        if fi not in selected:
            continue
        faces.append(face)
        for loop in getattr(face, 'loops', ()) or ():
            key = _sus_1644_loop_key(loop, uv_layer)
            nid = node_by_key.get(key)
            if nid is None:
                nid = len(node_by_key)
                node_by_key[key] = nid
                loops_by_node[nid] = []
                coords[nid] = _sus_1644_v2(loop[uv_layer].uv)
            loops_by_node[nid].append(loop)
            node_by_loop_id[id(loop)] = nid
    edge_map: dict[tuple[int, int], dict[str, float]] = {}
    adjacency: dict[int, set[int]] = {nid: set() for nid in coords}
    for face in faces:
        loops = list(getattr(face, 'loops', ()) or ())
        n = len(loops)
        if n < 2:
            continue
        for i, la in enumerate(loops):
            lb = loops[(i + 1) % n]
            na = node_by_loop_id.get(id(la)); nb = node_by_loop_id.get(id(lb))
            if na is None or nb is None or na == nb:
                continue
            key = (na, nb) if na < nb else (nb, na)
            uv_len = float((coords[na] - coords[nb]).length)
            mesh_len = _sus_1644_world_edge_length(obj, getattr(la, 'edge', None))
            rec = edge_map.get(key)
            if rec is None:
                edge_map[key] = {'uv': max(uv_len, _EPS), 'mesh': max(mesh_len, _EPS), 'count': 1.0}
            else:
                rec['uv'] += max(uv_len, _EPS)
                rec['mesh'] += max(mesh_len, _EPS)
                rec['count'] += 1.0
            adjacency.setdefault(na, set()).add(nb)
            adjacency.setdefault(nb, set()).add(na)
    edges: list[tuple[int, int, float, float]] = []
    for (a, b), rec in edge_map.items():
        count = max(1.0, float(rec.get('count', 1.0)))
        edges.append((a, b, float(rec.get('uv', _EPS)) / count, float(rec.get('mesh', _EPS)) / count))
    return faces, node_by_loop_id, loops_by_node, coords, adjacency, edges


def _sus_1644_connected_components(nodes: set[int], adjacency: dict[int, set[int]]) -> list[set[int]]:
    remaining = set(nodes)
    comps: list[set[int]] = []
    while remaining:
        root = remaining.pop()
        comp = {root}
        stack = [root]
        while stack:
            cur = stack.pop()
            for nb in adjacency.get(cur, ()):
                if nb in remaining:
                    remaining.remove(nb); comp.add(nb); stack.append(nb)
        comps.append(comp)
    return comps


def _sus_1644_axis_loop_groups(bm, selected: set[int], axis: str, threshold: float) -> list[list]:
    axis_idx = {'X': 0, 'Y': 1, 'Z': 2}.get(str(axis or '').upper())
    if axis_idx is None:
        return []
    selected_face_objs = [f for f in bm.faces if int(getattr(f, 'index', -1)) in selected]
    scoped_edges = set(); scoped_verts = set()
    for face in selected_face_objs:
        scoped_edges.update(list(getattr(face, 'edges', ()) or ()))
        scoped_verts.update(list(getattr(face, 'verts', ()) or ()))
    target_verts = {v for v in scoped_verts if abs(float(v.co[axis_idx])) <= threshold}
    groups = []
    unvisited = set(target_verts)
    while unvisited:
        v = unvisited.pop()
        comp = {v}; queue = [v]
        while queue:
            cur = queue.pop(0)
            for edge in getattr(cur, 'link_edges', ()) or ():
                if edge not in scoped_edges:
                    continue
                other = edge.other_vert(cur)
                if other in unvisited:
                    unvisited.remove(other); comp.add(other); queue.append(other)
        loops = []
        for vert in comp:
            for loop in getattr(vert, 'link_loops', ()) or ():
                try:
                    if int(loop.face.index) in selected:
                        loops.append(loop)
                except Exception:
                    pass
        if loops:
            groups.append(loops)
    return groups


def _sus_1644_anchor_targets_from_loop_groups(loop_groups: list[list], node_by_loop_id: dict[int, int], base_coords: dict[int, Vector]) -> dict[int, Vector]:
    accum: dict[int, list[Vector]] = {}
    for loops in loop_groups or []:
        seen = set(); nids = []
        for loop in loops:
            nid = node_by_loop_id.get(id(loop))
            if nid is None or nid in seen or nid not in base_coords:
                continue
            seen.add(nid); nids.append(nid)
        if len(nids) < 2:
            continue
        pts = [base_coords[nid] for nid in nids]
        avg_u = sum(float(p.x) for p in pts) / float(len(pts))
        avg_v = sum(float(p.y) for p in pts) / float(len(pts))
        var_u = sum((float(p.x) - avg_u) ** 2 for p in pts)
        var_v = sum((float(p.y) - avg_v) ** 2 for p in pts)
        vertical = var_u < var_v
        for nid in nids:
            p = base_coords[nid]
            target = Vector((avg_u, float(p.y))) if vertical else Vector((float(p.x), avg_v))
            accum.setdefault(nid, []).append(target)
    out: dict[int, Vector] = {}
    for nid, values in accum.items():
        if not values:
            continue
        acc = Vector((0.0, 0.0))
        for v in values:
            acc += v
        out[nid] = acc / float(len(values))
    return out


def _sus_1644_relax_component(comp: set[int], comp_edges: list[tuple[int, int, float, float]], adjacency: dict[int, set[int]], base_coords: dict[int, Vector], anchors: dict[int, Vector], comp_faces: list, uv_layer, node_by_loop_id: dict[int, int]) -> dict[int, Vector]:
    comp_anchors = {nid: anchors[nid].copy() for nid in comp if nid in anchors}
    if not comp_anchors:
        return {nid: base_coords[nid].copy() for nid in comp}

    # Component-scale mesh length target.  This keeps the selected unwrap mode as
    # the dominant source while using original mesh lengths as a mild geometric
    # regularizer to avoid local collapse around the straight baseline.
    sum_uv_mesh = 0.0; sum_mesh_sq = 0.0
    for _a, _b, uv_len, mesh_len in comp_edges:
        sum_uv_mesh += max(_EPS, uv_len) * max(_EPS, mesh_len)
        sum_mesh_sq += max(_EPS, mesh_len) ** 2
    mesh_to_uv = (sum_uv_mesh / sum_mesh_sq) if sum_mesh_sq > _EPS else 1.0

    # 1) Harmonic displacement field with fixed baseline displacement.
    disp: dict[int, Vector] = {}
    for nid in comp:
        if nid in comp_anchors:
            disp[nid] = comp_anchors[nid] - base_coords[nid]
        else:
            disp[nid] = Vector((0.0, 0.0))
    iterations = max(35, min(140, 45 + len(comp) // 8))
    for _ in range(iterations):
        new_disp = dict(disp)
        for nid in comp:
            if nid in comp_anchors:
                continue
            total = Vector((0.0, 0.0)); weight_sum = 0.0
            for nb in adjacency.get(nid, ()):
                if nb not in comp:
                    continue
                edge_len = max(_EPS, (base_coords[nid] - base_coords[nb]).length)
                w = 1.0 / edge_len
                total += disp.get(nb, Vector((0.0, 0.0))) * w
                weight_sum += w
            if weight_sum > _EPS:
                new_disp[nid] = total / weight_sum
        disp = new_disp
        for nid, target in comp_anchors.items():
            disp[nid] = target - base_coords[nid]

    coords = {nid: base_coords[nid] + disp.get(nid, Vector((0.0, 0.0))) for nid in comp}
    harmonic_coords = {nid: coords[nid].copy() for nid in comp}
    for nid, target in comp_anchors.items():
        coords[nid] = target.copy()
        harmonic_coords[nid] = target.copy()

    # 2) Bounded spring relaxation.  Targets blend the selected unwrap's UV edge
    # lengths with normalized mesh edge lengths.  Anchors stay exact; non-anchor
    # points absorb the baseline straightening smoothly.
    spring_iterations = max(18, min(90, 28 + len(comp_edges) // 12))
    target_lengths = []
    for a, b, uv_len, mesh_len in comp_edges:
        mesh_uv_len = max(_EPS, mesh_len * mesh_to_uv)
        target = 0.82 * max(_EPS, uv_len) + 0.18 * mesh_uv_len
        target_lengths.append((a, b, target))
    for it in range(spring_iterations):
        stiffness = 0.34 if it < spring_iterations * 0.6 else 0.22
        for a, b, target in target_lengths:
            pa = coords.get(a); pb = coords.get(b)
            if pa is None or pb is None:
                continue
            delta = pb - pa
            length = float(delta.length)
            if length <= _EPS:
                continue
            unit = delta / length
            err = length - target
            if abs(err) <= 1.0e-8:
                continue
            a_fixed = a in comp_anchors; b_fixed = b in comp_anchors
            if a_fixed and b_fixed:
                continue
            if not a_fixed and not b_fixed:
                corr = unit * (err * 0.5 * stiffness)
                coords[a] = pa + corr
                coords[b] = pb - corr
            elif a_fixed:
                coords[b] = pb - unit * (err * stiffness)
            else:
                coords[a] = pa + unit * (err * stiffness)
        # Mild native-result tether prevents spring drift and keeps the selected
        # unwrap algorithm visible in the final layout.
        tether = 0.035 if it < spring_iterations * 0.7 else 0.055
        for nid in comp:
            if nid in comp_anchors:
                coords[nid] = comp_anchors[nid].copy()
            else:
                coords[nid] = coords[nid].lerp(harmonic_coords[nid], tether)

    # 3) Flip safeguard.  If a chart would invert, progressively fall back to the
    # harmonic field while keeping the baseline anchors exact.
    face_original = {}
    for face in comp_faces:
        try:
            area = _sus_1644_signed_area_for_node_loop(face, uv_layer, node_by_loop_id, base_coords)
            if abs(area) > 1.0e-10:
                face_original[int(face.index)] = area
        except Exception:
            pass
    def has_bad_flip(candidate: dict[int, Vector]) -> bool:
        for face in comp_faces:
            fi = int(getattr(face, 'index', -1))
            original = face_original.get(fi)
            if original is None:
                continue
            now = _sus_1644_signed_area_for_node_loop(face, uv_layer, node_by_loop_id, candidate)
            if abs(now) <= max(1.0e-12, abs(original) * 0.015):
                return True
            if (now > 0.0) != (original > 0.0):
                return True
        return False
    if has_bad_flip(coords):
        safe = {nid: harmonic_coords[nid].copy() for nid in comp}
        for nid, target in comp_anchors.items():
            safe[nid] = target.copy()
        # If even the harmonic field flips, reduce the non-anchor displacement.
        if has_bad_flip(safe):
            for factor in (0.75, 0.55, 0.35, 0.2, 0.1):
                trial = {}
                for nid in comp:
                    if nid in comp_anchors:
                        trial[nid] = comp_anchors[nid].copy()
                    else:
                        trial[nid] = base_coords[nid] + (harmonic_coords[nid] - base_coords[nid]) * factor
                if not has_bad_flip(trial):
                    safe = trial; break
        coords = safe
    return coords


# Keep a reference to the older implementation for emergency fallback only.
try:
    _SUS_1644_PREVIOUS_BASELINE_STRAIGHTEN = apply_baseline_straightening_to_uv_scope
except Exception:
    _SUS_1644_PREVIOUS_BASELINE_STRAIGHTEN = None


def apply_baseline_straightening_to_uv_scope(context=None, obj=None, *, selected_faces: set[int] | None = None, baseline_axis=None, threshold=None, baseline_pairs=None) -> bool:
    """Constrained low-distortion Baseline Straightening for selected UV faces.

    The baseline strand is first converted to a straight constraint.  Instead of
    moving only those vertices, Smart UV Suite now solves a smooth displacement
    over every selected UV island and then restores edge lengths with fixed
    anchors.  This keeps the current unwrap/projection result as the native
    initial solution while distributing the constraint through the whole chart.
    """
    ctx = context or bpy.context
    obj = obj or _active_mesh(ctx)
    if obj is None or getattr(obj, 'type', '') != 'MESH':
        return False
    axis, threshold = _current_baseline_settings(ctx, baseline_axis, threshold)
    if axis in {'', 'NONE', 'OFF'}:
        return False
    _set_active(ctx, obj)
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed_mode = False
    if old_mode != 'EDIT':
        if not _mode_set('EDIT'):
            return False
        changed_mode = True
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        try:
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
        except Exception:
            pass
        if selected_faces is None:
            selected_faces = _selected_uv_face_indices(ctx, obj, bm, uv_layer, fallback_mesh_selection=False)
        selected = {int(i) for i in (selected_faces or set()) if int(i) >= 0}
        if not selected:
            return False

        mesh_state = _capture_mesh_selection(bm)
        seam_state = {int(e.index): bool(getattr(e, 'seam', False)) for e in bm.edges}
        pin_state = {}
        uv_select_state = {}
        for face in bm.faces:
            for pos, loop in enumerate(list(getattr(face, 'loops', ()) or ())):
                key = (int(getattr(face, 'index', -1)), int(pos))
                try:
                    pin_state[key] = bool(getattr(loop[uv_layer], 'pin_uv', False))
                except Exception:
                    pass
                try:
                    luv = loop[uv_layer]
                    uv_select_state[key] = (bool(getattr(luv, 'select', False)), bool(getattr(luv, 'select_edge', False)))
                except Exception:
                    pass

        faces, node_by_loop_id, loops_by_node, base_coords, adjacency, edges = _sus_1644_build_uv_graph(obj, bm, uv_layer, selected)
        if not faces or not base_coords or not edges:
            return False
        face_by_index = {int(f.index): f for f in bm.faces}
        if axis == 'SELECTED':
            loop_groups = _baseline_pairs_to_loop_groups(bm, face_by_index, baseline_pairs)
            if not loop_groups:
                # Direct Smart Standard execution stores selected baseline strands
                # in uv_sel_tag instead of the wrapper's baseline_pairs list.
                # Use those strand ids as the selected-edge baseline source.
                try:
                    tag = bm.loops.layers.int.get('uv_sel_tag')
                except Exception:
                    tag = None
                if tag is not None:
                    strand_dict = {}
                    for face in bm.faces:
                        if int(getattr(face, 'index', -1)) not in selected:
                            continue
                        for loop in getattr(face, 'loops', ()) or ():
                            try:
                                sid = int(loop[tag])
                            except Exception:
                                sid = 0
                            if sid > 0:
                                strand_dict.setdefault(sid, []).append(loop)
                    loop_groups = [loops for _sid, loops in sorted(strand_dict.items()) if len(loops) >= 2]
        else:
            loop_groups = _sus_1644_axis_loop_groups(bm, selected, axis, float(threshold))
        anchors = _sus_1644_anchor_targets_from_loop_groups(loop_groups, node_by_loop_id, base_coords)
        if len(anchors) < 2:
            return False

        components = _sus_1644_connected_components(set(base_coords), adjacency)
        edge_by_component: dict[int, list[tuple[int, int, float, float]]] = {i: [] for i in range(len(components))}
        node_to_comp = {}
        for ci, comp in enumerate(components):
            for nid in comp:
                node_to_comp[nid] = ci
        for edge in edges:
            ci = node_to_comp.get(edge[0])
            if ci is not None and node_to_comp.get(edge[1]) == ci:
                edge_by_component.setdefault(ci, []).append(edge)
        faces_by_comp: dict[int, list] = {i: [] for i in range(len(components))}
        for face in faces:
            comp_votes = {}
            for loop in getattr(face, 'loops', ()) or ():
                nid = node_by_loop_id.get(id(loop))
                ci = node_to_comp.get(nid)
                if ci is not None:
                    comp_votes[ci] = comp_votes.get(ci, 0) + 1
            if comp_votes:
                ci = max(comp_votes.items(), key=lambda item: item[1])[0]
                faces_by_comp.setdefault(ci, []).append(face)

        new_coords = {nid: base_coords[nid].copy() for nid in base_coords}
        changed_any = False
        for ci, comp in enumerate(components):
            if not any(nid in anchors for nid in comp):
                continue
            comp_edges = edge_by_component.get(ci, [])
            if not comp_edges:
                continue
            solved = _sus_1644_relax_component(comp, comp_edges, adjacency, base_coords, anchors, faces_by_comp.get(ci, []), uv_layer, node_by_loop_id)
            for nid, value in solved.items():
                if (value - base_coords[nid]).length > 1.0e-9:
                    changed_any = True
                new_coords[nid] = value

        if not changed_any:
            return False
        for nid, loops in loops_by_node.items():
            target = new_coords.get(nid)
            if target is None:
                continue
            for loop in loops:
                try:
                    loop[uv_layer].uv = target
                except Exception:
                    pass

        for edge in bm.edges:
            try:
                edge.seam = bool(seam_state.get(int(edge.index), bool(getattr(edge, 'seam', False))))
            except Exception:
                pass
        for face in bm.faces:
            in_scope = int(getattr(face, 'index', -1)) in selected
            for pos, loop in enumerate(list(getattr(face, 'loops', ()) or ())):
                key = (int(getattr(face, 'index', -1)), int(pos))
                if key in pin_state:
                    try:
                        loop[uv_layer].pin_uv = bool(pin_state[key])
                    except Exception:
                        pass
                try:
                    luv = loop[uv_layer]
                    # Keep final strict UV-face scope visible: selected faces are
                    # selected, unselected faces are not.  This matches the rest
                    # of Smart UV Suite's unwrap/pack rules.
                    luv.select = bool(in_scope)
                    luv.select_edge = bool(in_scope)
                except Exception:
                    pass
        _restore_mesh_selection(bm, mesh_state)
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        _write_uv_selection_attrs_object_mode(ctx, obj, selected)
        return True
    except Exception:
        # Fallback to older lightweight behavior rather than failing the unwrap.
        old = globals().get('_SUS_1644_PREVIOUS_BASELINE_STRAIGHTEN')
        if callable(old) and old is not apply_baseline_straightening_to_uv_scope:
            try:
                return bool(old(ctx, obj, selected_faces=selected_faces, baseline_axis=baseline_axis, threshold=threshold, baseline_pairs=baseline_pairs))
            except Exception:
                return False
        return False
    finally:
        if changed_mode and old_mode != 'EDIT':
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                pass
