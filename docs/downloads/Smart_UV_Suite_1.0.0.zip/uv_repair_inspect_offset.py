"""Implement the inspect offset public UV operations."""


def inspect_offset(context, op, api):
    axis = op.axis or ('V' if op.is_vertical else 'U')
    if axis not in {'U', 'V', 'X', 'Y'}:
        return False
    rows = api._edit_targets(context)
    sync = api._sync(context)
    selected = [
        (uv, island) for _, _, uv, island in api._all_islands(context, rows)
        if any(api._face_selected(face, sync) for face in island.faces)
    ]
    for uv, island in selected:
        du, dv = (op.amount, 0.0) if axis in {'U', 'X'} else (0.0, op.amount)
        api._move_island(island.faces, uv, du, dv)
    if selected and op.amount:
        api._flush(rows)
    return bool(selected and op.amount)



def build_handlers(api):
    return {

        "smart_uv_suite.inspect_offset": api.Handler(lambda context, op: inspect_offset(context, op, api), 'Translate selected islands along U or V without changing their shape.', '選択アイランドの形を保ったままUまたはV方向へ移動します。'),

    }
