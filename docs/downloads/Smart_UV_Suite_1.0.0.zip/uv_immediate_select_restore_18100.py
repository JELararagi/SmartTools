# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Smart UV Suite 1.8.100 Immediate Select drag-move restoration.

The 1.8.99 cleanup correctly removed the old Generic Gizmo and native-transform
interceptors, but the Immediate Select drag operator became limited too narrowly
to the UV Tweak keymaps.  On many Blender 5.1 UV Editor layouts the active tool
is Select Box / the generic UV Editor keymap, so the operator no longer receives
LEFTMOUSE/PRESS and cannot select an unselected UV before the drag starts.

This layer restores Immediate Select only on safe UV-selection keymaps.  It does
not install any rows in Generic Gizmo or native Move/Rotate/Scale/Transform
keymaps.  Background clicks still pass through without building hit caches; when
an already-warm cache says the press is over a UV element, the original Immediate
Select operator is allowed to run.
"""
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

from typing import Any, Callable, Dict, Iterable, Optional, Tuple
import math
import time

import bpy

_VERSION = (1, 8, 100)
_PG: Optional[Dict[str, Any]] = None
_INSTALLED = False
_ORIGINAL_INVOKE: Optional[Callable[..., Any]] = None

_INSTANT_ID = "smart_uv_suite.instant_select_drag_move"
_STICKY_ID = "smart_uv_suite.sticky_select_expand_passthrough"
_GIZMO_ID = "smart_uv_suite.uv_gizmo_grip_fix_grab"
_NATIVE_GIZMO_ID = ""

# Rows allowed for Immediate Select.  These are selection-context maps only.
# No Generic Gizmo or native Transform keymaps are used.
_ALLOWED_KEYMAP_DEFS: Tuple[Tuple[str, str], ...] = (
    ("UV Editor", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Tweak", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Tweak (fallback)", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Select Box", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Select Box (fallback)", "IMAGE_EDITOR"),
)

# Maps where this operator must never remain.  This preserves Blender's standard
# gizmos, native transforms and background-selection tools.
_FORBIDDEN_MAP_NAMES: Tuple[str, ...] = (
    "Window",
    "Image",
    "Image Generic",
    "Generic Gizmo",
    "Generic Gizmo Drag",
    "Generic Gizmo Click Drag",
    "Generic Gizmo Maybe Drag",
    "Generic Gizmo Select",
    "Image Editor Tool: Uv, Move",
    "Image Editor Tool: Uv, Move (fallback)",
    "Image Editor Tool: Uv, Rotate",
    "Image Editor Tool: Uv, Rotate (fallback)",
    "Image Editor Tool: Uv, Scale",
    "Image Editor Tool: Uv, Scale (fallback)",
    "Image Editor Tool: Uv, Transform",
    "Image Editor Tool: Uv, Transform (fallback)",
    "Image Editor Tool: Uv, Cursor",
    "Image Editor Tool: Uv, Cursor (fallback)",
    "Image Editor Tool: Uv, Select Lasso",
    "Image Editor Tool: Uv, Select Lasso (fallback)",
    "Image Editor Tool: Uv, Select Circle",
    "Image Editor Tool: Uv, Select Circle (fallback)",
)

# Tools that should never be intercepted, even through the broad UV Editor map.
_STRICT_NATIVE_TOOL_IDS = {
    "builtin.cursor",
    "builtin.select_lasso",
    "builtin.select_circle",
    "builtin.move",
    "builtin.rotate",
    "builtin.scale",
    "builtin.transform",
    "builtin.annotate",
    "builtin.annotate_line",
    "builtin.annotate_polygon",
    "builtin.annotate_eraser",
}
_STRICT_NATIVE_TOKENS = (
    "cursor",
    "select_lasso",
    "select_circle",
    "move",
    "rotate",
    "scale",
    "transform",
    "annotate",
)

_SELECT_TOOL_IDS = {"builtin.select", "builtin.tweak", "builtin.select_box", ""}

_LAST_CACHE_BUILD = 0.0
_CACHE_BUILD_INTERVAL = 0.20


def _text(value: Any) -> str:
    try:
        return str(value or "")
    except Exception:
        return ""


def _addon_keyconfig() -> Any:
    try:
        return bpy.context.window_manager.keyconfigs.addon
    except Exception:
        return None


def _get_keymap(kc: Any, name: str, space_type: str) -> Any:
    try:
        km = kc.keymaps.get(name)
        if km is None:
            km = kc.keymaps.new(name=name, space_type=space_type, region_type="WINDOW")
        return km
    except Exception:
        return None


def _iter_keymap_items(km: Any, idname: str) -> Iterable[Any]:
    try:
        from . import ownership_runtime_18168 as _ownership
        return [kmi for keymap, kmi in _ownership.owned_keymap_items(idname) if keymap is km]
    except Exception:
        return []


def _configure_press(kmi: Any, active: bool) -> None:
    try:
        _suv_resource.keymap_item_set(kmi, 'type', 'LEFTMOUSE')
        _suv_resource.keymap_item_set(kmi, 'value', 'PRESS')
    except Exception:
        pass
    for prop in ("shift", "ctrl", "alt", "oskey", "hyper"):
        try:
            _suv_resource.keymap_item_set(kmi, prop, False)
        except Exception:
            pass
    try:
        _suv_resource.keymap_item_set(kmi, 'any', False)
    except Exception:
        pass
    try:
        __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, bool(active))
    except Exception:
        pass


def _remove_rows_from_maps(idname: str, names: Iterable[str]) -> int:
    kc = _addon_keyconfig()
    if kc is None:
        return 0
    removed = 0
    for name in tuple(names):
        try:
            km = kc.keymaps.get(name)
        except Exception:
            km = None
        if km is None:
            continue
        for kmi in list(_iter_keymap_items(km, idname)):
            try:
                __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(km, kmi)
                removed += 1
            except Exception:
                try:
                    __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, False)
                    removed += 1
                except Exception:
                    pass
    return removed


def _remove_forbidden_rows() -> None:
    _remove_rows_from_maps(_INSTANT_ID, _FORBIDDEN_MAP_NAMES)
    _remove_rows_from_maps(_STICKY_ID, tuple(name for name, _space in _ALLOWED_KEYMAP_DEFS) + _FORBIDDEN_MAP_NAMES)
    _remove_rows_from_maps(_GIZMO_ID, tuple(name for name, _space in _ALLOWED_KEYMAP_DEFS) + _FORBIDDEN_MAP_NAMES)


def _instant_enabled(context: Any = None) -> bool:
    ctx = context or getattr(bpy, "context", None)
    try:
        if isinstance(_PG, dict):
            fn = _PG.get("_sus_1635_immediate_enabled")
            if callable(fn):
                return bool(fn(ctx))
    except Exception:
        pass
    try:
        ws = None
        if isinstance(_PG, dict):
            ws_fn = _PG.get("_sus_1652_ws")
            if callable(ws_fn):
                ws = ws_fn(ctx)
        if ws is None:
            ws = getattr(getattr(ctx, "scene", None), "suv_workspace", None)
        return bool(getattr(ws, "operation_instant_select_enabled", False))
    except Exception:
        return False


def ensure_keymaps(active: bool = True, context: Any = None) -> Tuple[int, int]:
    kc = _addon_keyconfig()
    if kc is None:
        return (0, 0)
    _remove_forbidden_rows()
    created = 0
    touched = 0
    for name, space_type in _ALLOWED_KEYMAP_DEFS:
        km = _get_keymap(kc, name, space_type)
        if km is None:
            continue
        items = list(_iter_keymap_items(km, _INSTANT_ID))
        if not items:
            kmi = None
            try:
                kmi = __import__(__package__ + '.ownership_runtime_18168', fromlist=['new_keymap_item']).new_keymap_item(km, _INSTANT_ID, type="LEFTMOUSE", value="PRESS", head=True)
            except TypeError:
                try:
                    kmi = __import__(__package__ + '.ownership_runtime_18168', fromlist=['new_keymap_item']).new_keymap_item(km, _INSTANT_ID, type="LEFTMOUSE", value="PRESS")
                except Exception:
                    kmi = None
            if kmi is not None:
                items = [kmi]
                created += 1
        for extra in items[1:]:
            try:
                __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(km, extra)
            except Exception:
                try:
                    __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(extra, False)
                except Exception:
                    pass
        if items:
            _configure_press(items[0], bool(active))
            touched += 1
    return (created, touched)


def set_keymaps_active(active: bool, context: Any = None) -> Tuple[int, int]:
    if active:
        return ensure_keymaps(True, context)
    _remove_forbidden_rows()
    touched = 0
    kc = _addon_keyconfig()
    if kc is None:
        return (0, 0)
    for name, _space_type in _ALLOWED_KEYMAP_DEFS:
        try:
            km = kc.keymaps.get(name)
        except Exception:
            km = None
        if km is None:
            continue
        for kmi in list(_iter_keymap_items(km, _INSTANT_ID)):
            try:
                __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, False)
                touched += 1
            except Exception:
                pass
    return (0, touched)


def _is_uv_context(context: Any) -> bool:
    try:
        area = getattr(context, "area", None)
        region = getattr(context, "region", None)
        space = getattr(context, "space_data", None)
        if _text(getattr(area, "type", "")) != "IMAGE_EDITOR":
            return False
        if _text(getattr(region, "type", "")) != "WINDOW":
            return False
        if _text(getattr(space, "type", "")) != "IMAGE_EDITOR":
            return False
        mode = _text(getattr(space, "ui_type", "") or getattr(space, "mode", "")).upper()
        return mode in {"", "UV", "UV_EDITOR"} or _text(getattr(space, "mode", "")).upper() == "UV"
    except Exception:
        return False


def _active_uv_tool_id(context: Any) -> str:
    for ctx in (context, getattr(bpy, "context", None)):
        try:
            workspace = getattr(ctx, "workspace", None)
            tools = getattr(workspace, "tools", None) if workspace is not None else None
            if tools is None:
                continue
            for args, kwargs in ((("UV",), {"create": False}), (("IMAGE_EDITOR",), {"create": False}), (("UV",), {}), ((), {})):
                try:
                    tool = tools.from_space_image_mode(*args, **kwargs)
                except TypeError:
                    try:
                        tool = tools.from_space_image_mode(*args)
                    except Exception:
                        tool = None
                except Exception:
                    tool = None
                tid = _text(getattr(tool, "idname", "")) if tool is not None else ""
                if tid:
                    return tid.strip().lower()
        except Exception:
            continue
    return ""


def _tool_must_pass_native(context: Any) -> bool:
    tid = _active_uv_tool_id(context)
    if tid in _SELECT_TOOL_IDS:
        return False
    if tid in _STRICT_NATIVE_TOOL_IDS:
        return True
    return any(token in tid for token in _STRICT_NATIVE_TOKENS)


def _i44() -> Any:
    try:
        from . import interaction_1844 as module
        if isinstance(_PG, dict):
            try:
                module._PG = _PG
            except Exception:
                pass
        return module
    except Exception:
        return None


def _uv_tolerance(context: Any, pixels: float = 10.0) -> float:
    try:
        from . import uv_background_drag_latency_1894 as bg
        fn = getattr(bg, "_uv_tolerance", None)
        if callable(fn):
            value = float(fn(context, pixels))
            if math.isfinite(value) and value > 0.0:
                return value
    except Exception:
        pass
    try:
        region = getattr(context, "region", None)
        view2d = getattr(region, "view2d", None)
        if view2d is not None:
            x0, y0 = view2d.region_to_view(0.0, 0.0)
            x1, y1 = view2d.region_to_view(float(pixels), float(pixels))
            return max(abs(float(x1) - float(x0)), abs(float(y1) - float(y0)), 1.0e-8)
    except Exception:
        pass
    return 1.0e-3


def _cache_signature(context: Any, cell: float) -> Any:
    module = _i44()
    fn = getattr(module, "_cache_signature", None) if module is not None else None
    try:
        return fn(context, cell) if callable(fn) else None
    except Exception:
        return None


def cache_is_ready(context: Any) -> bool:
    module = _i44()
    if module is None:
        return False
    try:
        cache = getattr(module, "_HIT_CACHE", None)
        if not isinstance(cache, dict) or not cache:
            return False
        if getattr(module, "_DIRTY_MESH_IDS", set()):
            return False
        tol = _uv_tolerance(context, 10.0)
        cell = max(float(tol) * 4.0, 1.0e-5)
        cached_cell = float(cache.get("cell", -1.0))
        if not math.isfinite(cached_cell) or abs(cached_cell - cell) > max(1.0e-8, abs(cell) * 1.0e-5):
            return False
        sig = _cache_signature(context, cell)
        return sig is not None and cache.get("sig") == sig
    except Exception:
        return False


def _has_edit_mesh(context: Any) -> bool:
    try:
        objs = getattr(context, "objects_in_mode_unique_data", None)
        if objs:
            return any(getattr(obj, "type", None) == "MESH" and getattr(obj, "mode", None) == "EDIT" for obj in objs)
    except Exception:
        pass
    try:
        obj = getattr(context, "edit_object", None) or getattr(context, "object", None)
        return bool(obj is not None and getattr(obj, "type", None) == "MESH" and getattr(obj, "mode", None) == "EDIT")
    except Exception:
        return False


def _build_cache(context: Any) -> bool:
    global _LAST_CACHE_BUILD
    if not _is_uv_context(context) or not _has_edit_mesh(context):
        return False
    now = time.monotonic()
    if now - _LAST_CACHE_BUILD < _CACHE_BUILD_INTERVAL and cache_is_ready(context):
        return True
    module = _i44()
    fn = getattr(module, "_get_hit_cache", None) if module is not None else None
    if not callable(fn):
        return False
    try:
        fn(context, _uv_tolerance(context, 10.0))
        _LAST_CACHE_BUILD = now
        return cache_is_ready(context)
    except Exception:
        return False


def _iter_uv_overrides() -> Iterable[Tuple[Any, Any, Any, Any, Any]]:
    try:
        windows = list(getattr(bpy.context.window_manager, "windows", []) or [])
    except Exception:
        windows = []
    for window in windows:
        try:
            screen = window.screen
            areas = list(screen.areas)
        except Exception:
            continue
        for area in areas:
            try:
                if _text(area.type) != "IMAGE_EDITOR":
                    continue
                region = next((r for r in area.regions if _text(r.type) == "WINDOW"), None)
                space = area.spaces.active
                if region is None or space is None or _text(space.type) != "IMAGE_EDITOR":
                    continue
                mode = _text(getattr(space, "ui_type", "") or getattr(space, "mode", "")).upper()
                if mode not in {"", "UV", "UV_EDITOR"} and _text(getattr(space, "mode", "")).upper() != "UV":
                    continue
                yield window, screen, area, region, space
            except Exception:
                continue


def _refresh_cache_timer():
    try:
        for window, screen, area, region, space in _iter_uv_overrides():
            try:
                with bpy.context.temp_override(window=window, screen=screen, area=area, region=region, space_data=space):
                    if _build_cache(bpy.context):
                        return None
            except Exception:
                continue
    except Exception:
        pass
    return None



def schedule_cache_refresh(delay: float = 0.08) -> None:
    try:
        if not _suv_resource.timer_is_registered(_refresh_cache_timer):
            _suv_resource.timer_register(_refresh_cache_timer, first_interval=max(0.03, float(delay)))
    except Exception:
        pass


def cached_hit(context: Any, event: Any) -> Any:
    if not _is_uv_context(context):
        return None
    if not cache_is_ready(context):
        schedule_cache_refresh(0.08)
        return None
    module = _i44()
    if module is None:
        return None
    fn = getattr(module, "_find_uv_hit_fast", None)
    try:
        # uv_background_drag_latency_1894 intentionally preserved this finder as
        # the real cache lookup.  It must already be non-recursive by 1.8.94+.
        if callable(fn):
            return fn(context, event)
    except Exception:
        return None
    return None


def _base_invoke_from_current(current: Callable[..., Any]) -> Callable[..., Any]:
    seen = set()
    fn = current
    for attr in ("_sus_1900_original", "_sus_1894_original", "_sus_1894_original", "_sus_1894_original"):
        try:
            candidate = getattr(fn, attr, None)
            if callable(candidate) and id(candidate) not in seen:
                seen.add(id(fn))
                fn = candidate
        except Exception:
            pass
    return fn


def _make_invoke(current: Callable[..., Any]) -> Callable[..., Any]:
    base = _base_invoke_from_current(current)

    def _instant_invoke_restore_18100(self, context, event):
        try:
            if _text(getattr(event, "type", "")) != "LEFTMOUSE" or _text(getattr(event, "value", "")) != "PRESS":
                return base(self, context, event)
            if not _instant_enabled(context):
                return {"PASS_THROUGH"}
            if not _is_uv_context(context):
                return {"PASS_THROUGH"}
            if _tool_must_pass_native(context):
                return {"PASS_THROUGH"}
            hit = cached_hit(context, event)
            if not hit:
                # Background press or cold cache: pass directly to Blender so box
                # selection/cursor/background drag stays immediate.
                return {"PASS_THROUGH"}
            # Keep the hit for any old helper that checks _sus_18100_cached_hit.
            try:
                self._sus_18100_cached_hit = hit
            except Exception:
                pass
            return base(self, context, event)
        except Exception:
            return {"PASS_THROUGH"}

    try:
        _instant_invoke_restore_18100._sus_1900_restore = True  # type: ignore[attr-defined]
        _instant_invoke_restore_18100._sus_1900_original = base  # type: ignore[attr-defined]
    except Exception:
        pass
    return _instant_invoke_restore_18100


def _patch_class(package_globals: Optional[Dict[str, Any]] = None) -> None:
    global _ORIGINAL_INVOKE
    cls = None
    try:
        if isinstance(package_globals, dict):
            cls = package_globals.get("SMARTUVSUITE_OT_instant_select_drag_move")
    except Exception:
        cls = None
    if not isinstance(cls, type):
        try:
            import sys
            pkg = sys.modules.get(__package__)
            cls = getattr(pkg, "SMARTUVSUITE_OT_instant_select_drag_move", None)
        except Exception:
            cls = None
    if not isinstance(cls, type):
        return
    try:
        current = getattr(cls, "invoke", None)
        if not callable(current):
            return
        if getattr(current, "_sus_1900_restore", False):
            return
        _ORIGINAL_INVOKE = current
        cls.invoke = _make_invoke(current)
        # Force class-level hit lookup to the cache-only path to avoid the old
        # synchronous BMesh scan on background presses.
        cls._find_uv_hit = lambda self, context, event: cached_hit(context, event)
    except Exception:
        pass


def _patch_background_module() -> None:
    try:
        from . import uv_background_drag_latency_1894 as bg
        bg._TWEAK_KEYMAP_DEFS = tuple(_ALLOWED_KEYMAP_DEFS)
        # Select Box is no longer a blanket pass-through tool.  The 1.8.100
        # wrapper checks the warm hit cache first; if no element is under the
        # cursor, the press still passes through without lag.
        try:
            ids = set(getattr(bg, "_NATIVE_BACKGROUND_TOOL_IDS", set()) or set())
            ids.discard("builtin.select_box")
            ids.discard("builtin.select")
            ids.discard("builtin.tweak")
            bg._NATIVE_BACKGROUND_TOOL_IDS = ids
        except Exception:
            pass
        try:
            tokens = tuple(t for t in getattr(bg, "_NATIVE_BACKGROUND_TOOL_TOKENS", tuple()) if t not in {"select_box"})
            bg._NATIVE_BACKGROUND_TOOL_TOKENS = tokens
        except Exception:
            pass
        bg._ensure_latency_free_keymaps = ensure_keymaps
        bg._set_latency_keymaps_active = lambda active, context=None: set_keymaps_active(bool(active), context)
        bg._delete_latency_keymaps = lambda: _remove_rows_from_maps(_INSTANT_ID, tuple(name for name, _s in _ALLOWED_KEYMAP_DEFS) + _FORBIDDEN_MAP_NAMES)
        bg._find_hit_cached_only = cached_hit
        bg._cache_is_ready = cache_is_ready
        bg._schedule_cache_refresh = schedule_cache_refresh
    except Exception:
        pass


def _patch_interaction_modules(package_globals: Optional[Dict[str, Any]] = None) -> None:
    for modname in ("interaction_1871", "interaction_1865", "interaction_1845", "interaction_1844"):
        try:
            mod = __import__(f"{__package__}.{modname}", fromlist=["dummy"])
        except Exception:
            continue
        for attr in ("_INSTANT_KEYMAP_DEFS", "_INSTANT_KEYMAP_DEFS_1859", "_INSTANT_KEYMAP_DEFS_1854"):
            try:
                setattr(mod, attr, tuple(_ALLOWED_KEYMAP_DEFS))
            except Exception:
                pass
        for name, value in (
            ("_ensure_instant_keymaps", ensure_keymaps),
            ("_set_instant_keymaps_active", lambda active: set_keymaps_active(bool(active))),
            ("_delete_instant_keymaps", lambda: _remove_rows_from_maps(_INSTANT_ID, tuple(name for name, _s in _ALLOWED_KEYMAP_DEFS) + _FORBIDDEN_MAP_NAMES)),
        ):
            try:
                setattr(mod, name, value)
            except Exception:
                pass
    if isinstance(package_globals, dict):
        try:
            package_globals["_sus_1652_ensure_instant_keymaps"] = ensure_keymaps
            package_globals["_sus_1652_promote_instant_keymaps_to_head"] = ensure_keymaps
            package_globals["_sus_1652_set_instant_keymaps_active"] = lambda active: set_keymaps_active(bool(active))
            package_globals["_sus_1652_delete_instant_keymaps"] = lambda: _remove_rows_from_maps(_INSTANT_ID, tuple(name for name, _s in _ALLOWED_KEYMAP_DEFS) + _FORBIDDEN_MAP_NAMES)
            package_globals["_SUS_1830_INSTANT_KEYMAP_DEFS"] = tuple(_ALLOWED_KEYMAP_DEFS)
            package_globals["_SUS_1832_INSTANT_KEYMAP_DEFS"] = tuple(_ALLOWED_KEYMAP_DEFS)
            package_globals["_SUS_1834_INSTANT_KEYMAP_DEFS"] = tuple(_ALLOWED_KEYMAP_DEFS)
        except Exception:
            pass


def _wrap_sync(package_globals: Optional[Dict[str, Any]]) -> None:
    if not isinstance(package_globals, dict):
        return
    current = package_globals.get("_sus_1652_sync_keymaps_from_workspace")
    if not callable(current) or getattr(current, "_sus_18100_sync", False):
        return

    def _sync_18100(context=None, _base=current):
        ctx = context or getattr(bpy, "context", None)
        try:
            _base(ctx)
        except TypeError:
            try:
                _base()
            except Exception:
                pass
        except RecursionError:
            pass
        except Exception:
            pass
        try:
            apply_all(package_globals, ctx)
        except Exception:
            pass

    try:
        _sync_18100._sus_18100_sync = True  # type: ignore[attr-defined]
    except Exception:
        pass
    package_globals["_sus_1652_sync_keymaps_from_workspace"] = _sync_18100


def _mark_version(package_globals: Optional[Dict[str, Any]]) -> None:
    try:
        if isinstance(package_globals, dict):
            info = package_globals.get("bl_info")
            if isinstance(info, dict):
                info.update({
                    "name": "Smart UV Suite",
                    "author": "JELararagi",
                    "version": (1, 0, 0),
                    "blender": (5, 1, 0),
                    "location": "View3D / UV Editor > Sidebar > Smart UV",
                    "description": "Smart UV Suite exposes UV editing tools in the Smart UV sidebar.",
                    "category": "Smart UV",
                })
                package_globals["_SUS_BL_INFO_FALLBACK"] = dict(info)
            package_globals["__version__"] = '1.0.0'
    except Exception:
        pass


def apply_all(package_globals: Optional[Dict[str, Any]] = None, context: Any = None) -> None:
    global _PG
    if isinstance(package_globals, dict):
        _PG = package_globals
    ctx = context or getattr(bpy, "context", None)
    _patch_background_module()
    _patch_interaction_modules(package_globals)
    _patch_class(package_globals)
    active = _instant_enabled(ctx)
    set_keymaps_active(active, ctx)
    if active:
        schedule_cache_refresh(0.06)
    _wrap_sync(package_globals)
    _mark_version(package_globals)


def install(package_globals: Optional[Dict[str, Any]] = None, context: Any = None) -> None:
    global _INSTALLED, _PG
    if isinstance(package_globals, dict):
        _PG = package_globals
    apply_all(package_globals, context or getattr(bpy, "context", None))
    _INSTALLED = True


def unregister() -> None:
    # Remove only forbidden stale rows.  Allowed Immediate Select rows are addon
    # keymaps and will disappear with the extension keyconfig on disable.
    try:
        _remove_forbidden_rows()
    except Exception:
        pass


def audit(context: Any = None) -> Dict[str, Any]:
    rows = []
    try:
        from . import ownership_runtime_18168 as _ownership
        for km, kmi in _ownership.owned_keymap_items():
            kid = _text(getattr(kmi, 'idname', ''))
            if kid in {_INSTANT_ID, _STICKY_ID, _GIZMO_ID}:
                rows.append((getattr(km, 'name', ''), kid, bool(getattr(kmi, 'active', False)), getattr(kmi, 'type', ''), getattr(kmi, 'value', '')))
    except Exception:
        pass
    return {
        'version': _VERSION,
        'instant_enabled': _instant_enabled(context),
        'rows': rows,
        'cache_ready': cache_is_ready(context or getattr(bpy, 'context', None)),
        'foreign_keymaps_scanned': False,
    }

