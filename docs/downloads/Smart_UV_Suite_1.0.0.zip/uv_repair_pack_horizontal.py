"""Rotate each chosen island to a horizontal axis."""

import bpy


def run(context, op):
    return "FINISHED" in bpy.ops.uv.suv_orient_islands(
        mode="HORIZONTAL", scope=(op.scope or "SELECTED").upper(), step_deg=1)


def build_handlers(api):
    return {"smart_uv_suite.pack_horizontal_orient": api.Handler(
        run, "Rotate the major axis of each selected island horizontally.", "選択島の長軸を水平に回転します。")}
