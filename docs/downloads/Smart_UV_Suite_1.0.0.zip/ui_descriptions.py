# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Per-button tooltip and help detail text for Smart UV Suite.

This module is intentionally data-only/lightweight.  It is loaded after the core
operators are registered so shared wrapper operators can expose dynamic
``description(context, properties)`` text that changes per button action.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable
import inspect
import json
import sys

try:  # pragma: no cover - available inside Blender only
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None  # type: ignore

_PATCHED_CLASSES: set[tuple[str, str]] = set()
_ORIGINAL_DESCRIPTIONS: dict[tuple[str, str], Any] = {}
_TOOLTIP_DATA: dict[str, Any] | None = None
_STATIC_HELP_DATA: dict[str, Any] | None = None
_EXTRACTED_OPERATOR_DETAILS: dict[tuple[str, tuple[tuple[str, str], ...]], dict[str, str]] = {}

_PROP_KEYS = (
    'action', 'mode', 'target', 'axis', 'issue', 'apply_mode', 'auto_scan', 'direction', 'operation', 'intent',
    'profile', 'preset', 'target_mode', 'type', 'key', 'text', 'help_id',
)


def _locale_mod():
    try:
        from . import text_translation as _tlr
        return _tlr
    except Exception:
        return None


def is_japanese(context=None) -> bool:
    mod = _locale_mod()
    try:
        if mod is not None:
            return bool(mod.is_japanese(context))
    except Exception:
        pass
    try:
        prefs = getattr(context, 'preferences', None) or getattr(getattr(bpy, 'context', None), 'preferences', None)
        lang = str(getattr(getattr(prefs, 'view', None), 'language', '') or '').lower()
        return lang.startswith('ja')
    except Exception:
        return False


def pick(en: str, ja: str, context=None) -> str:
    mod = _locale_mod()
    try:
        if mod is not None:
            return str(mod.pick(str(en or ''), str(ja or ''), context=context))
    except Exception:
        pass
    return str(ja if is_japanese(context) else en)


def _clean(value: Any) -> str:
    return ' '.join(str(value or '').strip().split())


def _norm_op(op_id: Any) -> str:
    return _clean(op_id)


def _props_dict(properties: Any) -> dict[str, str]:
    if properties is None:
        return {}
    if isinstance(properties, dict):
        return {str(k): str(v) for k, v in properties.items() if v is not None}
    result: dict[str, str] = {}
    for name in _PROP_KEYS:
        try:
            value = getattr(properties, name)
        except Exception:
            continue
        if value is not None:
            result[str(name)] = str(value)
    return result




def _props_key(properties: Any) -> tuple[tuple[str, str], ...]:
    return tuple(sorted((str(k), str(v)) for k, v in _props_dict(properties).items() if v is not None))


def _load_static_help_data() -> dict[str, Any]:
    global _STATIC_HELP_DATA
    if _STATIC_HELP_DATA is not None:
        return _STATIC_HELP_DATA
    path = Path(__file__).resolve().parent / 'data' / 'ui_help_items.json'
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        data = {}
    _STATIC_HELP_DATA = data if isinstance(data, dict) else {}
    return _STATIC_HELP_DATA


def _static_detail_for_label(op_id: str, props: dict[str, str], label_en: str = '', label_ja: str = '') -> dict[str, str]:
    label_en = str(label_en or '').strip() or op_id.rsplit('.', 1)[-1].replace('_', ' ').title()
    label_ja = str(label_ja or '').strip() or label_en
    try:
        from . import panel_tools as _panel_tools
        handler = _panel_tools.HANDLERS.get(op_id)
    except Exception:
        handler = None
    if handler is not None:
        return _detail(
            label_en, label_ja, handler.tip_en, handler.tip_ja,
            f'Prepare the selection or settings, then press "{label_en}".',
            f'選択や設定を用意してから「{label_ja}」を押します。',
        )
    prop_bits = []
    for key in ('action', 'mode', 'target', 'axis', 'issue', 'apply_mode'):
        value = props.get(key)
        if value:
            prop_bits.append(f'{key}={value}')
    op_note_en = f" The internal operation key is {', '.join(prop_bits)}." if prop_bits else ''
    op_note_ja = f" 内部処理キーは{', '.join(prop_bits)}です。" if prop_bits else ''
    return _detail(
        label_en,
        label_ja,
        f'Runs the "{label_en}" button in this Smart UV Suite item. It applies only this button\'s assigned operation to the current UV selection, using the settings shown in the same item.{op_note_en}',
        f'このSmart UV Suite項目内の「{label_ja}」ボタンを実行します。現在のUV選択に対して、このボタンに割り当てられた処理だけを、同じ項目内に表示されている設定を使って適用します。{op_note_ja}',
        f'Select the target UV elements, confirm the related settings in this item, then press "{label_en}".',
        f'対象のUV要素を選択し、この項目内の関連設定を確認してから「{label_ja}」を押します。',
    )


def _extracted_operator_detail(op_id: str, properties: Any) -> dict[str, str] | None:
    key = (str(op_id or '').strip(), _props_key(properties))
    detail = _EXTRACTED_OPERATOR_DETAILS.get(key)
    if detail:
        return detail
    # Some UI paths pass only a subset of properties.  Fall back to the first
    # label captured for the same operator only when there is a single candidate.
    candidates = [value for (known_op, _known_props), value in _EXTRACTED_OPERATOR_DETAILS.items() if known_op == key[0]]
    if len(candidates) == 1:
        return candidates[0]
    return None

def _load_tooltip_data() -> dict[str, Any]:
    global _TOOLTIP_DATA
    if _TOOLTIP_DATA is not None:
        return _TOOLTIP_DATA
    path = Path(__file__).resolve().parent / 'data' / 'operator_tooltips.json'
    try:
        raw = json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        raw = {}
    if isinstance(raw, dict) and isinstance(raw.get('tooltips'), dict):
        raw = raw.get('tooltips')
    _TOOLTIP_DATA = dict(raw or {}) if isinstance(raw, dict) else {}
    return _TOOLTIP_DATA


def _data_tooltip(op_id: str, context=None) -> str:
    raw = str(op_id or '').strip()
    if not raw:
        return ''
    keys = [raw]
    if '.' in raw:
        prefix, suffix = raw.split('.', 1)
        keys.extend((f'{prefix.upper()}_OT_{suffix}', f'{prefix}_OT_{suffix}', suffix))
    data = _load_tooltip_data()
    for key in dict.fromkeys(keys):
        value = data.get(key)
        if isinstance(value, str):
            return value
        if isinstance(value, dict):
            if is_japanese(context):
                for k in ('ja', 'description_ja', 'tooltip_ja', 'body_ja'):
                    if value.get(k):
                        return str(value[k])
            for k in ('en', 'description_en', 'tooltip_en', 'description', 'tooltip', 'summary', 'body'):
                if value.get(k):
                    return str(value[k])
    return ''


def _detail(en_label: str, ja_label: str, en_desc: str, ja_desc: str, en_usage: str, ja_usage: str) -> dict[str, str]:
    return {
        'label_en': en_label,
        'label_ja': ja_label,
        'desc_en': en_desc,
        'desc_ja': ja_desc,
        'usage_en': en_usage,
        'usage_ja': ja_usage,
    }


ALIGN_ACTIONS: dict[str, dict[str, str]] = {
    'ALIGN_TL': _detail('Upper Left', '左上', 'Moves the current UV selection so the left edge and top edge of its bounds align to the reference side. Vertex target moves selected UV vertices; Island target moves each selected island as a shell.', '現在のUV選択を、選択範囲の左端と上端が基準側へ揃う位置に移動します。対象が頂点の場合は選択UV頂点を動かし、対象がアイランドの場合は選択アイランドを形状ごと移動します。', 'Select UV vertices or islands, choose the Target button, then press the upper-left arrow.', 'UV頂点またはアイランドを選択し、対象ボタンを選んでから左上矢印を押します。'),
    'ALIGN_LEFT': _detail('Left', '左', 'Aligns the left bound of the selected UV vertices or islands to the left reference line without changing the opposite side shape.', '選択UV頂点またはアイランドの左端を左側の基準線へ揃えます。反対側の形状は拡大縮小せず、位置だけを調整します。', 'Select the elements to align and press the left arrow.', '整列したい要素を選択して左矢印を押します。'),
    'ALIGN_BL': _detail('Lower Left', '左下', 'Moves the selected UV bounds to the lower-left reference corner while preserving the local shape of the selected vertices or islands.', '選択UVの境界を左下の基準角へ移動します。選択頂点またはアイランドの局所形状は保持します。', 'Select the elements to align and press the lower-left arrow.', '整列したい要素を選択して左下矢印を押します。'),
    'ALIGN_TOP': _detail('Top', '上', 'Aligns the top bound of the selected UV vertices or islands to the upper reference line.', '選択UV頂点またはアイランドの上端を上側の基準線へ揃えます。', 'Select the elements to align and press the up arrow.', '整列したい要素を選択して上矢印を押します。'),
    'ALIGN_CENTER': _detail('Center', '中央', 'Moves the selected UV vertices or islands so the horizontal and vertical center of the selection matches the reference center.', '選択UV頂点またはアイランドの横方向と縦方向の中心が基準中心に合うように移動します。', 'Select the elements to align and press the center button.', '整列したい要素を選択して中央ボタンを押します。'),
    'ALIGN_BOTTOM': _detail('Bottom', '下', 'Aligns the bottom bound of the selected UV vertices or islands to the lower reference line.', '選択UV頂点またはアイランドの下端を下側の基準線へ揃えます。', 'Select the elements to align and press the down arrow.', '整列したい要素を選択して下矢印を押します。'),
    'ALIGN_TR': _detail('Upper Right', '右上', 'Moves the selected UV bounds to the upper-right reference corner while preserving island or vertex shape.', '選択UVの境界を右上の基準角へ移動します。アイランドまたは頂点選択の形状は保持します。', 'Select the elements to align and press the upper-right arrow.', '整列したい要素を選択して右上矢印を押します。'),
    'ALIGN_RIGHT': _detail('Right', '右', 'Aligns the right bound of the selected UV vertices or islands to the right reference line.', '選択UV頂点またはアイランドの右端を右側の基準線へ揃えます。', 'Select the elements to align and press the right arrow.', '整列したい要素を選択して右矢印を押します。'),
    'ALIGN_BR': _detail('Lower Right', '右下', 'Moves the selected UV bounds to the lower-right reference corner while keeping selected shapes intact.', '選択UVの境界を右下の基準角へ移動します。選択形状は崩さずに位置を調整します。', 'Select the elements to align and press the lower-right arrow.', '整列したい要素を選択して右下矢印を押します。'),
    'ALIGN_H': _detail('Horizontal Center', '横中央', 'Aligns the horizontal center of the selected UV vertices or islands to the reference center line.', '選択UV頂点またはアイランドの横方向中心を基準中心線へ揃えます。', 'Use this when only the U direction center should be matched.', 'U方向の中心だけを合わせたい場合に使います。'),
    'ALIGN_V': _detail('Vertical Center', '縦中央', 'Aligns the vertical center of the selected UV vertices or islands to the reference center line.', '選択UV頂点またはアイランドの縦方向中心を基準中心線へ揃えます。', 'Use this when only the V direction center should be matched.', 'V方向の中心だけを合わせたい場合に使います。'),
    'ALIGN_H_GROUP': _detail('Horizontal Center by Group', '横中央 グループ', 'Detects separated selected vertex groups per UV island and aligns each group to that island group reference on the U axis. Multiple islands are processed independently.', 'UVアイランドごとに分離した選択頂点グループを検出し、各アイランド内のグループ基準だけを使ってU軸方向の中心を揃えます。複数アイランド選択時もアイランドごとに独立した別処理として扱います。', 'Select vertex groups in one or more islands and press G—.', '1つ以上のアイランド内で頂点グループを選択し、G—を押します。'),
    'ALIGN_V_GROUP': _detail('Vertical Center by Group', '縦中央 グループ', 'Detects separated selected vertex groups per UV island and aligns each group to that island group reference on the V axis. Multiple islands are processed independently.', 'UVアイランドごとに分離した選択頂点グループを検出し、各アイランド内のグループ基準だけを使ってV軸方向の中心を揃えます。複数アイランド選択時もアイランドごとに独立した別処理として扱います。', 'Select vertex groups in one or more islands and press G|.', '1つ以上のアイランド内で頂点グループを選択し、G|を押します。'),
    'DISTRIBUTE_H': _detail('Distribute Horizontal', '横均等', 'Distributes the selected UV vertices or islands evenly along the U axis between the outermost selected bounds.', '選択UV頂点またはアイランドを、選択範囲の左右端の間でU軸方向に均等配置します。', 'Select at least three elements or islands and press the horizontal distribute button.', '3つ以上の要素またはアイランドを選択して横均等ボタンを押します。'),
    'DISTRIBUTE_V': _detail('Distribute Vertical', '縦均等', 'Distributes the selected UV vertices or islands evenly along the V axis between the outermost selected bounds.', '選択UV頂点またはアイランドを、選択範囲の上下端の間でV軸方向に均等配置します。', 'Select at least three elements or islands and press the vertical distribute button.', '3つ以上の要素またはアイランドを選択して縦均等ボタンを押します。'),
    'DISTRIBUTE_H_GROUP': _detail('Distribute Horizontal by Group', '横均等 グループ', 'Treats separated selected vertex groups as individual units inside each UV island and spaces those groups evenly along U. Groups from different islands are never mixed into one distribution.', '複数アイランドをまたぐ選択でも、各UVアイランド内の分離した選択頂点グループを個別単位として扱い、U軸方向へ均等配置します。別アイランドのグループを1つの分配基準へ混ぜません。', 'Select multiple vertex groups across one or more islands and press G┉.', '1つ以上のアイランドで複数の頂点グループを選択し、G┉を押します。'),
    'DISTRIBUTE_V_GROUP': _detail('Distribute Vertical by Group', '縦均等 グループ', 'Treats separated selected vertex groups as individual units inside each UV island and spaces those groups evenly along V. Groups from different islands are processed separately.', '複数アイランドをまたぐ選択でも、各UVアイランド内の分離した選択頂点グループを個別単位として扱い、V軸方向へ均等配置します。別アイランドのグループは別処理になります。', 'Select multiple vertex groups across one or more islands and press G┋.', '1つ以上のアイランドで複数の頂点グループを選択し、G┋を押します。'),
    'FLIP_H': _detail('Flip Horizontal', '左右反転', 'Flips the selected UV vertices around the selection center in the U direction.', '選択UV頂点を選択範囲の中心を基準にU方向へ左右反転します。', 'Select vertices and press the horizontal flip button.', '頂点を選択して左右反転ボタンを押します。'),
    'FLIP_V': _detail('Flip Vertical', '上下反転', 'Flips the selected UV vertices around the selection center in the V direction.', '選択UV頂点を選択範囲の中心を基準にV方向へ上下反転します。', 'Select vertices and press the vertical flip button.', '頂点を選択して上下反転ボタンを押します。'),
    'MIRROR_H': _detail('Mirror Horizontal', '左右ミラー', 'Mirrors selected islands horizontally around their combined center while preserving each island shape.', '選択アイランドを全体中心を基準に左右ミラーします。各アイランドの形状は保持します。', 'Choose Island target, select islands, and press the horizontal mirror button.', '対象をアイランドにし、アイランドを選択して左右ミラーボタンを押します。'),
    'MIRROR_V': _detail('Mirror Vertical', '上下ミラー', 'Mirrors selected islands vertically around their combined center while preserving each island shape.', '選択アイランドを全体中心を基準に上下ミラーします。各アイランドの形状は保持します。', 'Choose Island target, select islands, and press the vertical mirror button.', '対象をアイランドにし、アイランドを選択して上下ミラーボタンを押します。'),
    'ROTATE_CCW': _detail('Rotate 90° Counterclockwise', '90°左回転', 'Rotates the selected UV vertices or islands 90 degrees counterclockwise around the selection center.', '選択UV頂点またはアイランドを、選択範囲の中心を基準に90度左回転します。', 'Select vertices or islands and press 90L.', '頂点またはアイランドを選択して90Lを押します。'),
    'ROTATE_CW': _detail('Rotate 90° Clockwise', '90°右回転', 'Rotates the selected UV vertices or islands 90 degrees clockwise around the selection center.', '選択UV頂点またはアイランドを、選択範囲の中心を基準に90度右回転します。', 'Select vertices or islands and press 90R.', '頂点またはアイランドを選択して90Rを押します。'),
}

TARGET_DESCRIPTIONS = {
    'VERTEX': _detail('Vertex', '頂点', 'Sets Direction Align to vertex mode. The direction buttons move or transform only the selected UV vertices and keep the current UV selection scope.', '方向整列の対象を頂点にします。方向ボタンは選択UV頂点だけを移動または変形し、現在のUV選択範囲を保持します。', 'Press this before using the direction pad when vertex-level editing is needed.', '頂点単位で整列したい場合、方向パッドを使う前に押します。'),
    'ISLAND': _detail('Island', 'アイランド', 'Sets Direction Align to island mode. The direction buttons move or transform selected UV islands as whole shells without changing their internal shape.', '方向整列の対象をアイランドにします。方向ボタンは選択UVアイランドをシェル単位で移動または変形し、内部形状は変えません。', 'Press this before using the direction pad when island-level placement is needed.', 'アイランド単位で配置したい場合、方向パッドを使う前に押します。'),
}

SNAP_MODES = {
    'GRID': _detail('Grid Snap', 'グリッド吸着', 'Snaps selected UV vertices to the nearest UV Editor grid line. When the view is zoomed in and Blender displays thin subdivided grid lines, those visible subdivisions are also treated as snap targets.', '選択UV頂点をUVエディター表示上の最寄りグリッド線へ吸着します。ズーム時にBlenderが薄い細分化グリッドを表示している場合、その細分化線も吸着対象として扱います。', 'Select UV vertices, zoom to the grid scale you want to use, then press Grid.', 'UV頂点を選択し、使いたいグリッド幅が見える倍率までズームしてから「グリッド」を押します。'),
    'PIXEL': _detail('Pixel Snap', 'ピクセル吸着', 'Snaps selected UV vertices to the current image or texture pixel grid using the existing Smart UV Suite pixel snapping behavior.', '選択UV頂点を現在の画像またはテクスチャのピクセルグリッドへ吸着します。既存のSmart UV Suiteピクセル吸着挙動を維持します。', 'Set the image or canvas size first, select UV vertices, then press Pixel.', '先に画像またはキャンバスサイズを確認し、UV頂点を選択してから「ピクセル」を押します。'),
    'VERTEX': _detail('Vertex Snap', '頂点吸着', 'Finds selected UV vertices that are within the configured distance of each other and moves every proximity group to the same midpoint position.', '設定距離内にある選択UV頂点同士を検出し、近接グループごとの中点へ同じ位置に揃えます。', 'Set Distance, select the vertices to merge by position, then press Vertex.', '「距離」を設定し、位置を揃えたい頂点を選択してから「頂点」を押します。'),
}

SELECT_ACTIONS = {
    'GROW': _detail('Grow Selection', 'グロー選択', 'Expands the current UV selection to directly connected neighboring UV elements. It preserves Blender selection-sync state and refreshes the UV overlay.', '現在のUV選択を、直接つながる隣接UV要素へ拡張します。Blenderの選択同期状態を保ち、UV選択オーバーレイも更新します。', 'Select a starting UV element and press Grow.', '起点になるUV要素を選択して「グロー選択」を押します。'),
    'SHRINK': _detail('Shrink Selection', 'シュリンク選択', 'Reduces the current UV selection from the boundary inward while preserving the remaining selected UV elements.', '現在のUV選択を境界側から内側へ縮小し、残ったUV要素の選択を保持します。', 'Use after Grow or broad selection when the outer ring should be removed.', 'グロー選択後や広めの選択から外周を外したい場合に使います。'),
    'LOOP': _detail('Loop Selection', 'ループ選択', 'Selects a UV loop from the current edge or vertex selection. It is designed to behave the same with UV selection sync enabled or disabled.', '現在の辺または頂点選択を起点にUVループを選択します。UVの選択同期が有効でも無効でも同じ挙動になるように処理します。', 'Select a UV edge or vertex on the intended loop and press Loop.', '目的のループ上のUV辺または頂点を選択して「ループ選択」を押します。'),
    'RING': _detail('Ring Selection', 'リング選択', 'Selects a UV ring across neighboring quads from the current edge selection and restores the orange UV selection overlay when sync is enabled.', '現在の辺選択を起点に、隣接四角面をまたぐUVリングを選択します。同期ON時もオレンジのUV選択オーバーレイを復元します。', 'Select a UV edge on the intended ring and press Ring.', '目的のリング上のUV辺を選択して「リング選択」を押します。'),
    'LINKED': _detail('Linked Selection', '連結選択', 'Selects UV elements connected to the current selection inside the same UV island.', '現在の選択と同じUVアイランド内で連結しているUV要素を選択します。', 'Select one UV element in the island and press Linked.', 'アイランド内のUV要素を1つ選択して「連結選択」を押します。'),
    'BORDER': _detail('Border Selection', '境界選択', 'Selects boundary UV edges or vertices around the current UV island or selected region.', '現在のUVアイランドまたは選択領域の境界にあるUV辺または頂点を選択します。', 'Select an island or region and press Border.', 'アイランドまたは領域を選択して「境界選択」を押します。'),
    'ALL': _detail('Select All', '全選択', 'Selects all editable UV elements in the active UV context.', '現在編集可能なUV要素をすべて選択します。', 'Press when the next operation should affect the entire editable UV set.', '次の操作を編集可能なUV全体へ適用したい場合に押します。'),
    'NONE': _detail('Clear Selection', '選択解除', 'Clears the current UV selection without changing UV coordinates.', 'UV座標は変更せず、現在のUV選択だけを解除します。', 'Press when you need to restart selection from an empty state.', '選択を空の状態からやり直したい場合に押します。'),
    'INVERT': _detail('Invert Selection', '反転選択', 'Inverts selected and unselected UV elements inside the current editable UV context.', '現在編集可能なUV範囲で、選択済みと未選択のUV要素を入れ替えます。', 'Use after a partial selection when the opposite set is needed.', '一部を選んだ後、反対側の集合を選びたい場合に使います。'),
}

STITCH_MODES = {
    'ISLAND_CONNECTED_TO_SELECTED': _detail('Connected Island to Selected', '島を選択側へ', 'Moves the connected matching island border to the selected island border and stitches the islands at the corresponding UV edge positions.', '連結している対応アイランド境界を選択側のアイランド境界へ移動し、対応UV辺位置でスティッチします。', 'Select the receiving island border first, then run this command.', '受け側にしたいアイランド境界を選択してから実行します。'),
    'ISLAND_SELECTED_TO_CONNECTED': _detail('Selected Island to Connected', '選択側を島へ', 'Moves the selected island border to the connected matching island border and stitches the islands at the corresponding UV edge positions.', '選択側アイランド境界を連結先の対応アイランド境界へ移動し、対応UV辺位置でスティッチします。', 'Select the island border that should move, then run this command.', '移動させたいアイランド境界を選択してから実行します。'),
    'ISLAND_AVERAGE': _detail('Both Islands to Middle', '島を中間へ', 'Moves both matching island borders to their midpoint so neither side acts as the sole fixed target.', '対応する両方のアイランド境界を中点へ移動し、片側だけを固定基準にしない形でスティッチします。', 'Select matching borders from the islands and press the middle stitch button.', '対応するアイランド境界を選択して中間スティッチボタンを押します。'),
    'EDGE_CONNECTED_TO_SELECTED': _detail('Connected Edge to Selected', '辺を選択側へ', 'Moves the connected matching UV edge to the selected UV edge position.', '連結している対応UV辺を選択UV辺の位置へ移動します。', 'Select the receiving UV edge first, then run this command.', '受け側にしたいUV辺を選択してから実行します。'),
    'EDGE_SELECTED_TO_CONNECTED': _detail('Selected Edge to Connected', '選択辺を連結側へ', 'Moves the selected UV edge to the connected matching UV edge position.', '選択UV辺を連結先の対応UV辺位置へ移動します。', 'Select the UV edge that should move, then run this command.', '移動させたいUV辺を選択してから実行します。'),
    'EDGE_AVERAGE': _detail('Both Edges to Middle', '辺を中間へ', 'Moves both matching UV edges to their midpoint.', '対応する両方のUV辺を中点へ移動します。', 'Select matching UV edges and press the middle edge stitch button.', '対応するUV辺を選択して辺中間ボタンを押します。'),
}

GENERIC_ACTIONS: dict[str, dict[str, str]] = {
    'CHECKER_CREATE': _detail('Checker', 'チェッカー', 'Creates or updates a checker texture or checker preview used to inspect UV scale, stretching, and orientation.', 'UVスケール、歪み、向きの確認に使うチェッカーテクスチャまたはチェッカープレビューを作成・更新します。', 'Set texture size or checker count first, then press Checker.', 'テクスチャサイズまたはチェッカー数を設定してから「チェッカー」を押します。'),
    'FOCUS_VIEW': _detail('Focus View', '表示調整', 'Frames the active UV selection or editable UV range in the UV Editor for easier inspection.', 'UVエディター上でアクティブなUV選択または編集可能なUV範囲を見やすく表示します。', 'Press when the target UVs are off-screen or too small to inspect.', '対象UVが画面外または小さすぎる場合に押します。'),
    'SNAP_GRID': _detail('Snap Grid', 'グリッド吸着', 'Snaps selected UV vertices to the UV Editor grid using the current grid display scale.', '現在のUVエディターのグリッド表示幅を基準に、選択UV頂点をグリッドへ吸着します。', 'Select UV vertices and press Snap Grid.', 'UV頂点を選択して「グリッド吸着」を押します。'),
    'MARK_SEAM': _detail('Mark Seam', 'シームをマーク', 'Marks the selected mesh edges as seams for later unwrap operations.', '選択メッシュ辺を、後のUV展開で使うシームとしてマークします。', 'Select mesh edges in Edit Mode and press Mark Seam.', '編集モードでメッシュ辺を選択し、「シームをマーク」を押します。'),
    'CLEAR_SEAM': _detail('Clear Seam', 'シーム解除', 'Removes seam marks from the selected mesh edges.', '選択メッシュ辺からシーム指定を解除します。', 'Select seam edges and press Clear Seam.', '解除したいシーム辺を選択して「シーム解除」を押します。'),
    'SEAM_FROM_SHARP': _detail('Sharp to Seam', 'シャープからシーム', 'Converts selected or detected sharp edges into seam edges for unwrapping.', '選択または検出されたシャープ辺をUV展開用のシーム辺へ変換します。', 'Prepare sharp edges, then press this button before unwrapping.', 'シャープ辺を準備し、展開前にこのボタンを押します。'),
    'SEAM_FROM_ANGLE': _detail('Angle to Seam', '角度からシーム', 'Marks seams on edges whose face angle exceeds the configured seam angle threshold.', '面角度が設定したシーム角度しきい値を超える辺にシームを設定します。', 'Adjust the angle threshold, then run this command.', '角度しきい値を調整してから実行します。'),
    'AUTO_SEAM': _detail('Auto Seam', '自動シーム', 'Scores candidate mesh edges from the auto-seam settings and marks suitable seams for unwrapping. Angle, sharp, material, boundary and tube cuts are the reasons to cut; loop and stretch only reinforce them, and angles well below the limit count for little. A closed shape, a shape with a hole through it, or a tube also gets the fewest cuts it needs to flatten.', '自動シーム設定に基づいて候補辺を評価し、UV展開に適したシームをマークします。切る根拠は角度・シャープ・マテリアル・境界・筒状カットで、ループと引張はそれを後押しするだけです。しきい値より十分小さい角度はほとんど数えません。閉じた形・穴の貫通した形・筒には、平らに開くのに要る最小限の切れ目も足します。', 'Set the auto-seam preset and weights, then press Auto Seam.', '自動シームのプリセットと重みを設定してから「自動シーム」を押します。'),
    'PIN': _detail('Pin', 'ピン', 'Pins the selected UV vertices so supported unwrap and pack operations can keep them fixed.', '選択UV頂点をピン留めし、対応する展開やパック処理で固定点として扱えるようにします。', 'Select UV vertices and press Pin.', 'UV頂点を選択して「ピン」を押します。'),
    'UNPIN': _detail('Unpin', 'ピン解除', 'Removes pin status from the selected UV vertices.', '選択UV頂点のピン留め状態を解除します。', 'Select pinned UV vertices and press Unpin.', 'ピン留め済みUV頂点を選択して「ピン解除」を押します。'),
    'PIN_INVERT': _detail('Invert Pins', 'ピン反転', 'Inverts pinned and unpinned status for the editable UV vertices.', '編集可能なUV頂点のピン留め状態と非ピン状態を入れ替えます。', 'Use when the current fixed set should become the movable set.', '現在固定している頂点群を可動側へ入れ替えたい場合に使います。'),
    'SAVE_SCENE': _detail('Save Scene Seam Set', 'シーン保存', 'Saves the current seam state into the scene using the configured snapshot name.', '現在のシーム状態を、設定したスナップショット名でシーン内へ保存します。', 'Enter a scene save name and press Save Scene.', 'シーン内保存名を入力して「シーン保存」を押します。'),
    'LOAD_SCENE': _detail('Load Scene Seam Set', 'シーン読込', 'Loads a seam snapshot stored in the scene and applies it to the active mesh.', 'シーン内に保存したシームスナップショットを読み込み、アクティブメッシュへ適用します。', 'Choose the saved name and press Load Scene.', '保存名を指定して「シーン読込」を押します。'),
    'SAVE_FILE': _detail('Save Seam JSON', '外部保存', 'Exports the current seam state to the configured external JSON file.', '現在のシーム状態を指定した外部JSONファイルへ書き出します。', 'Set the JSON path and press Save JSON.', 'JSONパスを設定して「外部保存」を押します。'),
    'LOAD_FILE': _detail('Load Seam JSON', '外部読込', 'Loads seam data from the configured external JSON file and applies it to the active mesh.', '指定した外部JSONファイルからシームデータを読み込み、アクティブメッシュへ適用します。', 'Set the JSON path and press Load JSON.', 'JSONパスを設定して「外部読込」を押します。'),
    'FIT': _detail('Fit', 'フィット', 'Fits the selected UV islands into the target tile or working area using the active padding settings.', '選択UVアイランドを、現在の余白設定を使って対象タイルまたは作業領域へ収めます。', 'Select islands, set padding, then press Fit.', 'アイランドを選択し、余白を設定してから「フィット」を押します。'),
    'STRAIGHTEN': _detail('Straighten', '直線化', 'Straightens the selected UV edge chain or vertex line while preserving the intended chain direction.', '選択UV辺チェーンまたは頂点列を、意図したチェーン方向を保ちながら直線化します。', 'Select a UV line or edge chain and press Straighten.', 'UVラインまたは辺チェーンを選択して「直線化」を押します。'),
    'GRIDIFY': _detail('Gridify', 'グリッド化', 'Reshapes the selected UV area toward a regular grid layout when the topology supports it.', 'トポロジーが対応している選択UV領域を、規則的なグリッド形状へ整えます。', 'Select a quad-like UV region and press Grid.', '四角面ベースのUV領域を選択して「グリッド化」を押します。'),
    'RELAX': _detail('Relax', 'リラックス', 'Relaxes selected UV vertices to reduce distortion while attempting to preserve the surrounding shape.', '周囲形状を保ちつつ、選択UV頂点を緩和して歪みを減らします。', 'Set relax iterations, select UVs, then press Relax.', 'リラックス回数を設定し、UVを選択してから「リラックス」を押します。'),
    'ROTATE_90': _detail('Rotate', '回転', 'Rotates the selected UV islands or UV elements by 90 degrees.', '選択UVアイランドまたはUV要素を90度回転します。', 'Select the target UVs and press Rotate.', '対象UVを選択して「回転」を押します。'),
    'FLIP_U': _detail('Flip U', 'U反転', 'Flips the selected UVs across the U axis direction.', '選択UVをU方向基準で反転します。', 'Select UVs and press Flip U.', 'UVを選択して「U反転」を押します。'),
    'FLIP_V': _detail('Flip V', 'V反転', 'Flips the selected UVs across the V axis direction.', '選択UVをV方向基準で反転します。', 'Select UVs and press Flip V.', 'UVを選択して「V反転」を押します。'),
    'SNAP_PIXEL': _detail('Snap', '吸着', 'Snaps selected UVs using the native compact snap route, usually to a pixel-based target.', '標準連携パネルの吸着経路で選択UVを吸着します。通常はピクセル基準の吸着に使います。', 'Select UVs and press Snap.', 'UVを選択して「吸着」を押します。'),
    'STITCH_WELD': _detail('Stitch/Weld', '結合', 'Stitches or welds matching selected UV edges so separated UV pieces meet at the same coordinate.', '対応する選択UV辺をスティッチまたはウェルドし、分離したUV片が同じ座標で接するようにします。', 'Select matching UV edges and press Stitch/Weld.', '対応するUV辺を選択して「結合」を押します。'),
    'BAKE_PREP': _detail('Bake Prep', 'ベイク準備', 'Prepares UV-related bake settings such as padding and target density for texture baking.', 'テクスチャベイクに向けて、余白や目標密度などUV関連のベイク設定を準備します。', 'Set texture size and padding, then press Bake Prep.', 'テクスチャサイズと余白を設定してから「ベイク準備」を押します。'),
    'DENSITY_GET': _detail('Get Density', '密度取得', 'Reads texel density from the current UV selection and stores it as the working target density.', '現在のUV選択からテクセル密度を読み取り、作業用の目標密度として保存します。', 'Select a reference UV island and press Density.', '基準にするUVアイランドを選択して「密度取得」を押します。'),
    'DENSITY_NORMALIZE': _detail('Normalize Density', '密度正規化', 'Scales selected UV islands so their texel density moves toward the stored target density.', '保存済みの目標密度へ近づくように、選択UVアイランドをスケール調整します。', 'Get or enter a target density, select islands, then press Normalize.', '目標密度を取得または入力し、アイランドを選択して「密度正規化」を押します。'),
    'COLOR_ID_OBJECTS': _detail('Object IDs', 'オブジェクトID', 'Creates object-based color ID data for bake or material identification workflows.', 'ベイクまたはマテリアル識別用に、オブジェクト単位のカラーIDデータを作成します。', 'Select the target objects and press Object IDs.', '対象オブジェクトを選択して「オブジェクトID」を押します。'),
    'COLOR_ID_FACES': _detail('Face IDs', '面ID', 'Creates face-based color ID data for bake or selection-identification workflows.', 'ベイクまたは選択識別用に、面単位のカラーIDデータを作成します。', 'Select the target mesh faces and press Face IDs.', '対象メッシュ面を選択して「面ID」を押します。'),
    'UVMAP_ADD': _detail('Add UV Map', 'UVマップ追加', 'Adds a new UV map to the selected mesh object using the configured UV name.', '設定したUV名を使って、選択メッシュオブジェクトへ新しいUVマップを追加します。', 'Enter the UV name and press Add.', 'UV名を入力して「追加」を押します。'),
    'UVMAP_DUPLICATE': _detail('Duplicate UV Map', 'UVマップ複製', 'Duplicates the active UV map so the current UV coordinates can be edited as a separate channel.', 'アクティブUVマップを複製し、現在のUV座標を別チャンネルとして編集できるようにします。', 'Activate the source UV map and press Duplicate.', '複製元UVマップをアクティブにして「複製」を押します。'),
    'UVMAP_REMOVE': _detail('Remove UV Map', 'UVマップ削除', 'Removes the active or configured UV map from the selected mesh object.', '選択メッシュオブジェクトから、アクティブまたは設定対象のUVマップを削除します。', 'Confirm the active UV map, then press Remove.', 'アクティブUVマップを確認してから「削除」を押します。'),
    'UVMAP_COPY': _detail('Copy UV Map', 'UVマップコピー', 'Copies UV coordinates from one UV channel to another while keeping mesh selection and other channels intact.', 'メッシュ選択状態と他チャンネルを保持したまま、1つのUVチャンネルから別チャンネルへUV座標をコピーします。', 'Set source and target UV channels, then press Copy.', 'コピー元とコピー先のUVチャンネルを設定してから「コピー」を押します。'),
    'SELECT_ZERO': _detail('Select Zero Area', 'ゼロ選択', 'Selects UV islands or faces whose UV area is effectively zero.', 'UV面積が実質ゼロのアイランドまたは面を選択します。', 'Press before repair or manual cleanup.', '修復または手動整理の前に押します。'),
    'SELECT_FLIPPED': _detail('Select Flipped', '反転選択', 'Selects UV faces or islands whose UV winding is flipped.', 'UVの向きが反転している面またはアイランドを選択します。', 'Press after unwrap or mirror operations to find reversed UVs.', '展開後やミラー後に反転UVを探す場合に押します。'),
    'SELECT_OVERLAP': _detail('Select Overlap', '重なり選択', 'Selects UV elements that overlap other UV elements in the editable UV set.', '編集可能なUV内で他のUV要素と重なっている要素を選択します。', 'Press before packing or cleanup to find overlaps.', 'パックや整理前に重なりを探す場合に押します。'),
    'SELECT_UDIM': _detail('Select UDIM Crossing', 'UDIM選択', 'Selects UV islands that cross UDIM tile boundaries.', 'UDIMタイル境界をまたいでいるUVアイランドを選択します。', 'Press before UDIM packing or export checks.', 'UDIMパックや書き出し確認の前に押します。'),
    'AUTO_REPAIR': _detail('Auto Repair', '自動修復', 'Runs context-safe cleanup for detected UV issues such as zero-area or invalid generated data where supported.', '対応可能な範囲で、ゼロ面積や不正な生成データなど検出済みUV問題を安全に整理します。', 'Run issue selection first if you need to inspect the targets, then press Auto Repair.', '対象を確認したい場合は先に問題選択を実行し、その後「自動修復」を押します。'),
    'SELECT_INVERT': _detail('Invert Issue Selection', '反転選択', 'Inverts the current issue-selection result inside the editable UV context.', '編集可能なUV範囲で、現在の問題選択結果を反転します。', 'Use after an issue selection when you want the non-issue set.', '問題選択後、問題ではない側を選びたい場合に使います。'),
    'CLEAN_GENERATED': _detail('Clean Generated Data', 'データ整理', 'Deletes or resets generated Smart UV Suite support data that is safe to recreate.', '再生成可能なSmart UV Suite補助データを削除または初期化します。', 'Use when reports, previews, or generated helper data should be cleaned.', 'レポート、プレビュー、生成補助データを整理したい場合に使います。'),
    'EXPORT_SETTINGS': _detail('Export Settings', '設定出力', 'Writes current Smart UV Suite settings to a support or audit output file.', '現在のSmart UV Suite設定をサポートまたは監査用の出力ファイルへ書き出します。', 'Press when you need a settings record for backup or issue reporting.', 'バックアップや不具合報告用に設定記録が必要な場合に押します。'),
    'WRITE_REPORT': _detail('Write Report', 'レポート出力', 'Writes the current Smart UV Suite diagnostic or workflow report.', '現在のSmart UV Suite診断またはワークフローレポートを書き出します。', 'Run after inspection, cleanup, or before sending a support report.', '検査や整理後、またはサポート報告前に実行します。'),
    'ENABLE': _detail('Enable Keymap', 'キーマップ有効', 'Enables the selected Smart UV Suite keymap entry without recreating it.', '選択したSmart UV Suiteキーマップ項目を、再作成せず有効化します。', 'Use when the row exists but is disabled.', '項目が存在するが無効になっている場合に使います。'),
    'DISABLE': _detail('Disable Keymap', 'キーマップ無効', 'Disables the selected Smart UV Suite keymap entry while keeping it registered.', '選択したSmart UV Suiteキーマップ項目を登録済みのまま無効化します。', 'Use when you want to stop the shortcut temporarily.', 'ショートカットを一時的に止めたい場合に使います。'),
    'DELETE': _detail('Delete Keymap', 'キーマップ削除', 'Deletes the selected Smart UV Suite keymap entry from Blender preferences.', '選択したSmart UV Suiteキーマップ項目をBlenderプリファレンスから削除します。', 'Use before recreating a broken or unwanted shortcut.', '破損または不要なショートカットを作り直す前に使います。'),
    'REGISTER': _detail('Re-register Keymap', 'キーマップ再登録', 'Creates the selected Smart UV Suite keymap entry again using the add-on default definition.', 'アドオンの既定定義を使って、選択したSmart UV Suiteキーマップ項目を再作成します。', 'Use after Delete or when a shortcut is missing.', '削除後またはショートカットが見つからない場合に使います。'),
}

SIMPLE_OPERATOR_DESCRIPTIONS: dict[str, dict[str, str]] = {
    'smart_uv_suite.unified_auto_pack': _detail('Run Auto Pack', '自動パック実行', 'Runs the selected automatic packing method with the current margin, tile, rotation, scale, pin, stack, density, and bake-safe options.', '現在の余白、タイル、回転、スケール、ピン、スタック、密度、ベイク安全設定を使って、選択中の自動パッキング方式を実行します。', 'Select fully face-selected UV islands, set the packing options, then run Auto Pack.', 'UVエディターで面選択済みアイランドを用意し、パック設定を確認してから自動パックを実行します。'),
    'smart_uv_suite.unwrap_auto_run': _detail('Run Unwrap', '展開実行', 'Runs the unwrap method currently selected in Method and applies the visible method settings.', '「方式」で選択しているUV展開方式を、現在表示されている方式別設定で実行します。', 'Select mesh faces or edges as required by the method, choose Method, then press Run Unwrap.', '方式に応じてメッシュ面または辺を選択し、「方式」を選んでから「展開実行」を押します。'),
    'smart_uv_suite.instant_select_drag_move': _detail('Immediate Select Drag Move', '即時選択ドラッグ移動', 'When triggered from the UV Editor, selects the UV element under the mouse at press time and moves it during the same drag.', 'UVエディター上で起動すると、押下時点でマウス下のUV要素を選択し、そのまま同じドラッグで移動します。', 'Enable the operation option and use the configured mouse drag in the UV Editor.', '操作項目で有効化し、UVエディター上で設定済みのマウスドラッグを使います。'),
    'smart_uv_suite.cursor_to_hover_uv_vertex': _detail('2D Cursor to Hover Vertex', 'ホバー頂点へ2Dカーソル', 'Moves the UV Editor 2D cursor to the UV vertex currently under the mouse pointer.', 'UVエディター上でマウスが乗っているUV頂点へ2Dカーソルを移動します。', 'Register the operator in the UV Editor keymap and run it while hovering a UV vertex.', 'UVエディターのキーマップへ登録し、UV頂点にマウスを乗せた状態で実行します。'),
    'smart_uv_suite.copy_operator_id': _detail('Copy Operator ID', 'IDコピー', 'Copies the displayed operator identifier to the clipboard for keymap setup or reporting.', '表示されているオペレーターIDを、キーマップ設定や報告用にクリップボードへコピーします。', 'Press Copy next to the operator ID.', 'オペレーターID横の「コピー」を押します。'),
    'smart_uv_suite.select_pick': _detail('Pick Selection', 'ピック選択', 'Runs the Smart UV pick-selection helper for choosing UV elements from the current editor context.', '現在のエディター状態からUV要素を選ぶSmart UVのピック選択補助を実行します。', 'Use when direct element picking is needed from the panel.', 'パネルから直接要素選択を行いたい場合に使います。'),
    'smart_uv_suite.select_mode': _detail('Selection Mode', '選択モード', 'Switches or opens the UV selection-mode helper so subsequent selection tools use the intended element type.', 'UV選択モード補助を切り替えまたは表示し、以後の選択ツールが意図した要素種別を使えるようにします。', 'Run before selection operations when vertex, edge, face, or island scope must be changed.', '頂点、辺、面、アイランドの対象範囲を変えたい場合、選択操作の前に実行します。'),
    'smart_uv_suite.map_channel_object_select': _detail('Object Row', 'オブジェクト行', 'Selects the mesh object row whose map channels are edited by the controls below the object list.', 'リスト下の操作でマップチャンネルを編集するメッシュオブジェクト行を選択します。', 'Click the object row first, then choose its unwrap map channel, rename, add, remove, or move channels.', '先にオブジェクト行をクリックし、そのオブジェクトの展開使用マップチャンネル選択、名称変更、追加、削除、移動を実行します。'),
    'smart_uv_suite.map_channel_rename': _detail('Rename Map Channel', 'チャンネル名変更', 'Renames the unwrap map channel selected on the object selected in the map-channel object list.', 'マップチャンネルのオブジェクトリストで選択中のオブジェクトにある展開使用マップチャンネルの名前を変更します。', 'Press Rename Channel, enter the new name in the popup, then confirm. Other selected objects are not changed.', '「チャンネル名変更」を押し、ポップアップで新しい名前を入力して確定します。他の選択オブジェクトは変更しません。'),
    'smart_uv_suite.map_channel_add': _detail('Add Map Channel', 'チャンネル追加', 'Adds a UV map channel to the object selected in the map-channel object list and makes it that object\'s unwrap/edit target.', 'マップチャンネルのオブジェクトリストで選択中のオブジェクトへUVマップチャンネルを追加し、そのオブジェクトの展開/編集対象にします。', 'Press Add, enter the new map name in the popup, then confirm. Other selected objects are not changed.', '「追加」を押し、ポップアップで新しいマップ名を入力して確定します。他の選択オブジェクトは変更しません。'),
    'smart_uv_suite.map_channel_remove': _detail('Remove Map Channel', 'チャンネル削除', 'Removes the unwrap target UV map channel from the object selected in the map-channel object list.', 'マップチャンネルのオブジェクトリストで選択中のオブジェクトから、展開対象UVマップチャンネルを削除します。', 'Select the object row and target channel, then press Remove Target.', 'オブジェクト行と対象チャンネルを選択してから「展開対象を削除」を押します。'),
    'smart_uv_suite.map_channel_move': _detail('Move Map Channel', 'チャンネル移動', 'Moves the unwrap target UV map channel up or down on the object selected in the map-channel object list.', 'マップチャンネルのオブジェクトリストで選択中のオブジェクト上で、展開対象UVマップチャンネルを上または下へ移動します。', 'Select the object row and target channel, then press Move Up or Move Down.', 'オブジェクト行と対象チャンネルを選択してから「上へ移動」または「下へ移動」を押します。'),
    'smart_uv_suite.map_channel_copy': _detail('Copy Map Channel', 'チャンネルコピー', 'Copies UV coordinates from the source UV channel to the unwrap target channel on the object selected in the map-channel object list.', 'マップチャンネルのオブジェクトリストで選択中のオブジェクト上で、コピー元UVチャンネルから展開対象チャンネルへUV座標をコピーします。', 'Set source and target channels for the selected object row, then press Copy.', '選択中のオブジェクト行でコピー元と展開対象を設定してからコピーを押します。'),
}

PROPERTY_DESCRIPTIONS: dict[str, dict[str, str]] = {
    'uv_direction_align_target': _detail('Direction Align Target', '方向整列対象', 'Chooses whether the direction pad edits selected UV vertices or selected UV islands.', '方向パッドが選択UV頂点を編集するか、選択UVアイランドを編集するかを選びます。', 'Switch this before pressing any direction-align button.', '方向整列ボタンを押す前に切り替えます。'),
    'suv_consolidated_snap_vertex_distance': _detail('Vertex Snap Distance', '頂点吸着距離', 'Sets the maximum UV distance used by Vertex snap when searching for selected vertices that should be moved to a common midpoint.', '頂点吸着で、同じ中点へ揃える候補頂点を探す最大UV距離を設定します。', 'Increase this only when nearby vertices are not being grouped; decrease it when unrelated vertices are pulled together.', '近い頂点がまとまらない場合は増やし、無関係な頂点まで吸着される場合は減らします。'),
    'operation_instant_select_enabled': _detail('Enable Instant Select Drag Move', '即時選択ドラッグ移動', 'Enables the UV Editor helper that selects the clicked UV element immediately and lets the same drag move it.', 'クリックしたUV要素を即時選択し、同じドラッグで移動できるUVエディター補助を有効にします。', 'Turn on for click-select-to-drag editing. Turn off to rely only on Blender standard selection behavior.', 'クリック選択からドラッグ移動へ直結したい場合はONにします。Blender標準選択だけを使う場合はOFFにします。'),
    'operation_axis_constraint_memory_enabled': _detail('Remember Axis Constraint', '軸拘束の記憶', 'Stores the last UV translate axis constraint and reuses it when Immediate Select starts a drag move.', '直前のUV移動で使った軸拘束を記憶し、即時選択がドラッグ移動を始める時に再利用します。', 'Enable when repeated U-only or V-only drag moves are common.', 'U方向のみ、V方向のみのドラッグ移動を繰り返す場合に有効化します。'),
    'operation_uv_gizmo_grip_fix_enabled': _detail('Enable UV Gizmo Grip Fix', 'UVギズモつかみ補助', 'Keeps UV gizmo grip behavior stable by helping the mouse input route avoid losing the intended gizmo target.', 'マウス入力経路が意図したギズモ対象を失いにくくなるよう補助し、UVギズモのつかみ操作を安定させます。', 'Enable when the UV gizmo sometimes fails to start dragging from its handle.', 'UVギズモのハンドルからドラッグが始まらないことがある場合に有効化します。'),
    'operation_uv_crossing_select_edges_enabled': _detail('Crossing Selection: Edges', '交差選択：辺', 'Includes UV edges that cross a box, circle, or lasso selection boundary even when both edge endpoints are outside the selection region.', 'ボックス・円・投げ縄の選択領域を横切るUV辺を、両端点が領域外にある場合でも選択対象に含めます。', 'Enable it, switch to UV edge selection, then use the crossing box, circle, or lasso gesture. This affects only the UV Editor.', '有効にしてUV辺選択モードへ切り替え、交差ボックス・円・投げ縄ジェスチャーを使います。UVエディターだけに作用します。'),
    'operation_uv_crossing_select_faces_enabled': _detail('Crossing Selection: Faces', '交差選択：面', 'Includes UV faces whose polygon overlaps, crosses, contains, or is contained by a box, circle, or lasso selection region.', 'UV面ポリゴンがボックス・円・投げ縄の選択領域と交差、重なり、包含関係になる場合に選択対象へ含めます。', 'Enable it, switch to UV face selection, then use the crossing box, circle, or lasso gesture. Face-center position alone is not used.', '有効にしてUV面選択モードへ切り替え、交差ボックス・円・投げ縄ジェスチャーを使います。面中心だけでは判定しません。'),
    'operation_uv_proportional_cursor_keymap_enabled': _detail('UV Proportional Cursor Entry', 'UVプロポーショナル編集カーソル入力', 'Registers the Smart UV Suite entry used to adjust the UV proportional-editing influence-size cursor reliably.', 'UVプロポーショナル編集の影響範囲サイズを安定して調整するためのSmart UV Suite入力経路を登録します。', 'Enable it, turn on proportional editing in the UV Editor, and adjust the influence radius with the registered cursor-size input or the native transform wheel.', '有効にしてUVエディターのプロポーショナル編集をONにし、登録されたカーソルサイズ入力または標準変形中のホイールで影響半径を調整します。'),
    'auto_unwrap_mode': _detail('Unwrap Method', '展開方式', 'Selects which unwrap algorithm or route Run Unwrap will execute.', '「展開実行」が使用するUV展開アルゴリズムまたは経路を選びます。', 'Choose the method before pressing Run Unwrap.', '「展開実行」を押す前に方式を選びます。'),
    'smart_unwrap_realtime_preview': _detail('Live Unwrap', 'ライブ展開', 'Enables preview-oriented unwrap updating where supported by the selected method.', '選択方式が対応している場合に、プレビュー向けの展開更新を有効にします。', 'Turn on while adjusting settings; turn off if heavy meshes become slow.', '設定調整中はONにし、重いメッシュで遅い場合はOFFにします。'),
    'canvas_size': _detail('Texture Size', 'テクスチャサイズ', 'Sets the working texture size used by fit, checker, density, and bake-safe calculations.', 'フィット、チェッカー、密度、ベイク安全余白計算で使う作業テクスチャサイズを設定します。', 'Set this to the texture resolution planned for export or baking.', '書き出しまたはベイク予定のテクスチャ解像度に合わせます。'),
    'fit_padding_px': _detail('Padding', '余白', 'Sets pixel padding used when fitting or preparing UVs for packing and bake safety.', 'フィット、パック準備、ベイク安全処理で使うピクセル余白を設定します。', 'Increase it when islands need more separation; reduce it when space is tight.', 'アイランド間隔を広げたい場合は増やし、スペースが厳しい場合は減らします。'),
    'checker_size_width': _detail('Checker Width', '画像解像度 横', 'Sets the checker or preview image width used by the basic checker helper.', '基本チェッカー補助で使うチェッカーまたはプレビュー画像の横解像度を設定します。', 'Match this to the texture width you want to inspect.', '確認したいテクスチャ横解像度に合わせます。'),
    'checker_size_height': _detail('Checker Height', '画像解像度 縦', 'Sets the checker or preview image height used by the basic checker helper.', '基本チェッカー補助で使うチェッカーまたはプレビュー画像の縦解像度を設定します。', 'Match this to the texture height you want to inspect.', '確認したいテクスチャ縦解像度に合わせます。'),
    'checker_tile_count_u': _detail('Checker Tiles U', 'チェックサイズ 横', 'Sets how many checker tiles are shown across the U direction.', 'U方向に表示するチェッカータイル数を設定します。', 'Increase for finer distortion inspection.', 'より細かい歪み確認をしたい場合は増やします。'),
    'checker_tile_count_v': _detail('Checker Tiles V', 'チェックサイズ 縦', 'Sets how many checker tiles are shown across the V direction.', 'V方向に表示するチェッカータイル数を設定します。', 'Increase for finer distortion inspection.', 'より細かい歪み確認をしたい場合は増やします。'),
    'suv_native_grid_divisions': _detail('Grid Divisions', 'グリッド分割', 'Sets the helper grid subdivision count used by native compact grid and snap actions.', '標準連携のグリッド表示や吸着操作で使う補助グリッド分割数を設定します。', 'Adjust before grid-related buttons if a different subdivision is needed.', 'グリッド関連ボタンを使う前に、必要な分割数へ調整します。'),
    'unified_auto_pack_mode': _detail('Packing Preset', 'パッキングプリセット', 'Chooses the automatic packing route used by Run Auto Pack.', '「自動パック実行」で使う自動パッキング経路を選びます。', 'Select the method that matches the current layout goal before packing.', '現在の配置目的に合う方式を選んでからパックします。'),
    'unified_pack_merge_overlap': _detail('Treat Overlaps as One Island', '重なり島を複合島にする', 'Treats selected UV islands that overlap by visible area as one compound packing unit.', 'UVエディター上で面積が重なる選択アイランドを、1つの複合パック単位として扱います。', 'Turn it on to preserve stacked or intentionally overlapping islands; turn it off to pack every island separately.', '重ね配置や意図した重なりを保つ場合はON、重なっていても個別に並べ直す場合はOFFにします。'),
    'unified_pack_margin_px': _detail('Margin px', '余白px', 'Sets the pixel margin used by Smart UV auto packing routes.', 'Smart UV自動パック経路で使うピクセル余白を設定します。', 'Use this when margin should be specified in pixels.', '余白をピクセル単位で指定したい場合に使います。'),
    'unified_pack_margin': _detail('Native Margin', '標準余白', 'Sets the Blender-native UV margin value used by native pack routes.', '標準Blenderパック経路で使うUV余白値を設定します。', 'Use this when the selected method relies on Blender native packing.', '選択方式がBlender標準パックを使う場合に設定します。'),
    'unified_pack_margin_method': _detail('Margin Method', '余白方式', 'Chooses how the packer interprets the margin value.', 'パッカーが余白値をどの方式で解釈するかを選びます。', 'Confirm this before packing when switching between pixel and scaled margins.', 'ピクセル余白とスケール余白を切り替える場合、パック前に確認します。'),
    'unified_pack_shape_method': _detail('Shape Method', '形状方式', 'Chooses the shape approximation used when arranging islands.', 'アイランド配置時に使う形状近似方式を選びます。', 'Use tighter methods for better occupancy and simpler methods for speed.', '充填率を重視する場合は精密寄り、速度重視なら単純寄りを選びます。'),
    'unified_pack_rotation_step': _detail('Rotation Step', '回転刻み', 'Sets the angle increment allowed when the packer rotates islands.', 'パッカーがアイランド回転を許可する場合の角度刻みを設定します。', 'Use smaller steps for denser packing and larger steps for more consistent orientation.', '高密度配置なら小さめ、向きを揃えたい場合は大きめにします。'),
    'unified_pack_rotate': _detail('Allow Rotation', '回転を許可', 'Allows the packer to rotate islands while searching for a layout.', 'パッカーが配置探索中にアイランドを回転できるようにします。', 'Turn off when island orientation must remain fixed.', 'アイランドの向きを固定したい場合はOFFにします。'),
    'unified_pack_scale': _detail('Allow Scale', 'スケールを許可', 'Allows the packer to scale selected islands when the selected packing method supports it.', '選択中のパック方式が対応している場合、選択アイランドのスケール変更を許可します。', 'Turn off when texel scale must be preserved exactly.', 'テクセルスケールを厳密に保持したい場合はOFFにします。'),
    'unified_pack_lock_pinned': _detail('Lock Pinned', 'ピン固定', 'Keeps pinned UV vertices or islands from being moved by supported pack routes.', '対応パック経路で、ピン留めされたUV頂点またはアイランドを移動しないようにします。', 'Enable when manually placed pinned UVs must stay in place.', '手動配置したピン留めUVを固定したい場合にONにします。'),
    'unified_pack_use_seed': _detail('Seed Search', 'Seed探索', 'Enables seed-based layout search to try alternative packing results.', 'Seed値を使った配置探索を有効にし、別パターンのパック結果を試します。', 'Enable when the first pack result leaves too much unused space.', '最初のパック結果に空きが多い場合に有効化します。'),
    'unified_pack_seed': _detail('Seed', 'Seed', 'Sets the seed value used by seed-based packing search.', 'Seed探索で使うSeed値を設定します。', 'Change this to get a different deterministic pack result.', '決定的に別のパック結果を得たい場合に変更します。'),
    'unified_pack_stack_identical': _detail('Stack Identical', '同一島を重ねる', 'Stacks identical or near-identical islands when the selected packing method supports stacking.', '選択中のパック方式が対応している場合、同一またはほぼ同一形状のアイランドを重ねます。', 'Enable for mirrored or duplicated parts that may share texture space.', 'ミラー部品や複製部品でテクスチャ領域を共有したい場合にONにします。'),
    'unified_pack_chart_rescale': _detail('Chart Rescale', 'チャート密度再正規化', 'Rescales charts to normalize density before or during packing when supported.', '対応する場合、パック前またはパック中にチャートを再スケールして密度を整えます。', 'Use when selected islands have inconsistent density before packing.', 'パック前のアイランド密度がばらついている場合に使います。'),
    'pack_group_mode': _detail('Group Mode', 'グループ方式', 'Chooses how islands are grouped before packing or sorting.', 'パックまたは並べ替え前に、アイランドをどの単位でグループ化するかを選びます。', 'Set before packing grouped materials, objects, or similar islands.', '材質、オブジェクト、類似アイランドをグループパックする前に設定します。'),
    'pack_group_layout': _detail('Group Layout', 'グループ配置', 'Chooses how pack groups are arranged relative to each other.', 'パックグループ同士をどのように配置するかを選びます。', 'Adjust when groups should be placed by row, column, or tile logic.', 'グループを行、列、タイル単位で配置したい場合に調整します。'),
    'smart_margin_strategy': _detail('Margin Strategy', '余白方針', 'Chooses how Detail Unwrap decides its margins.', '「詳細展開」の余白の決め方を選びます。', 'Choose a value before running Detail Unwrap.', '「詳細展開」を実行する前に選びます。'),
    'smart_sliver_protection': _detail('Sliver Protection', '細片保護', 'Protects thin faces during Detail Unwrap.', '「詳細展開」で細い面を守ります。', 'Turn it on when thin faces collapse.', '細い面がつぶれる時にオンにします。'),
    'smart_lock_overlaps': _detail('Preserve Overlap', '重なり保持', 'When on, Fix Issues does not move overlapping islands apart.', 'オンにすると、「問題修復」は重なりを離しません。', 'Turn it on when islands are stacked on purpose.', 'わざと重ねているアイランドがある時にオンにします。'),
    'workflow_density': _detail('Target Density', '目標密度', 'Stores the target texel density. Density from Texture puts its measured value here.', '目標のテクセル密度の値です。「テクスチャから密度」が測った値もここに入ります。', 'Enter the desired value, or press Density from Texture.', '目的の値を入力するか、「テクスチャから密度」を押します。'),
    'suv_native_target_density': _detail('Native Density', '統合密度', 'Stores the compact native panel target texel density.', '標準連携パネルで使う目標テクセル密度を保存します。', 'Set before native density normalization.', '標準連携の密度正規化前に設定します。'),
    'uv_new_name': _detail('UV Name', 'UV名', 'Sets the name used when creating a new UV map.', '新規UVマップを作成するときの名前を設定します。', 'Enter a clear channel name before pressing Add.', '追加を押す前に分かりやすいチャンネル名を入力します。'),
    'suv_native_uv_name': _detail('Native UV Name', '統合UV名', 'Sets the UV map name used by native compact UV map operations.', '標準連携UVマップ操作で使うUVマップ名を設定します。', 'Enter the target name before add, copy, or related UV map actions.', '追加、コピー、関連UVマップ操作の前に対象名を入力します。'),
    'stretch_threshold': _detail('Stretch Limit', '歪み許容値', 'Sets the distortion threshold used by cleanup and inspection actions.', '整理・検査操作で使う歪み検出しきい値を設定します。', 'Lower it to catch smaller distortion; raise it to ignore minor variation.', '小さな歪みも検出したい場合は下げ、軽微な差を無視したい場合は上げます。'),
    'scan_report_name': _detail('Report Name', 'レポート名', 'Sets the output name used for cleanup or inspection reports.', '整理または検査レポートの出力名を設定します。', 'Enter a readable name before writing a report.', 'レポート出力前に分かりやすい名前を入力します。'),
}


def _fallback_operator_desc(op_id: str, context=None) -> str:
    ident = _norm_op(op_id)
    tail = ident.split('.', 1)[-1].replace('_', ' ') if ident else 'tool'
    return pick(
        f'Runs the {tail} command using the current UV selection and the settings in the same item. Check the selection before executing because this button changes the current UV workflow state or result.',
        f'現在のUV選択と同じ項目内の設定を使って「{tail}」コマンドを実行します。現在のUV作業状態または結果を変更するため、実行前に選択範囲を確認してください。',
        context,
    )


def _detail_text(detail: dict[str, str], context=None) -> str:
    return pick(detail.get('desc_en', ''), detail.get('desc_ja', ''), context)


def _usage_text(detail: dict[str, str], context=None) -> str:
    return pick(detail.get('usage_en', ''), detail.get('usage_ja', ''), context)


def detail_label(detail: dict[str, str], context=None) -> str:
    return pick(detail.get('label_en', ''), detail.get('label_ja', ''), context)




def _known_operator_detail(op_id: str, properties: Any, context=None) -> dict[str, str] | None:
    op_id = _norm_op(op_id)
    props = _props_dict(properties)
    action = props.get('action', '')
    mode = props.get('mode', '')
    target = props.get('target', '')
    if op_id == 'smart_uv_suite.direction_align_mode' and target:
        return TARGET_DESCRIPTIONS.get(target)
    if op_id in {'smart_uv_suite.direction_align', 'smart_uv_suite.direction_align_action', 'smart_uv_suite.vertex_align_action', 'smart_uv_suite.island_direction_align', 'smart_uv_suite.uv_layout_action', 'smart_uv_suite.pack_layout_action'} and action in ALIGN_ACTIONS:
        return ALIGN_ACTIONS.get(action)
    if op_id == 'smart_uv_suite.consolidated_snap_uv' and mode:
        return SNAP_MODES.get(mode)
    if op_id == 'smart_uv_suite.uv_element_select_action' and action:
        return SELECT_ACTIONS.get(action)
    if op_id == 'smart_uv_suite.stitch_action' and mode:
        return STITCH_MODES.get(mode)
    if action and action in GENERIC_ACTIONS:
        return GENERIC_ACTIONS.get(action)
    if op_id in SIMPLE_OPERATOR_DESCRIPTIONS:
        return SIMPLE_OPERATOR_DESCRIPTIONS[op_id]
    return _extracted_operator_detail(op_id, props)


def describe_operator_with_label(op_id: str, properties: Any = None, label_en: str = '', label_ja: str = '', context=None) -> str:
    detail = _known_operator_detail(op_id, properties, context)
    if detail:
        return _detail_text(detail, context)
    data = _data_tooltip(_norm_op(op_id), context)
    if data:
        return data
    return _detail_text(_static_detail_for_label(_norm_op(op_id), _props_dict(properties), label_en, label_ja), context)


def usage_for_operator_with_label(op_id: str, properties: Any = None, label_en: str = '', label_ja: str = '', context=None) -> str:
    detail = _known_operator_detail(op_id, properties, context)
    if detail:
        return _usage_text(detail, context)
    return _usage_text(_static_detail_for_label(_norm_op(op_id), _props_dict(properties), label_en, label_ja), context)

def describe_operator(op_id: str, properties: Any = None, context=None) -> str:
    op_id = _norm_op(op_id)
    detail = _known_operator_detail(op_id, properties, context)
    if detail:
        return _detail_text(detail, context)
    data = _data_tooltip(op_id, context)
    if data:
        return data
    return _fallback_operator_desc(op_id, context)

def usage_for_operator(op_id: str, properties: Any = None, context=None) -> str:
    detail = _known_operator_detail(op_id, properties, context)
    if detail:
        return _usage_text(detail, context)
    return pick('Prepare the required selection and settings, then run this individual button from the same UI item.', '必要な選択範囲と設定を準備し、同じUI項目内のこの個別ボタンを実行します。', context)

def operator_label(op_id: str, properties: Any = None, context=None, fallback_en: str = '', fallback_ja: str = '') -> str:
    detail = _known_operator_detail(op_id, properties, context)
    if detail:
        return detail_label(detail, context)
    if fallback_en or fallback_ja:
        return pick(fallback_en or fallback_ja, fallback_ja or fallback_en, context)
    return _norm_op(op_id)

def property_description_pair(prop_name: str, prop_type: str = '', label: str | None = None) -> tuple[str, str]:
    prop_name = str(prop_name or '')
    detail = PROPERTY_DESCRIPTIONS.get(prop_name)
    if detail:
        return str(detail.get('desc_en') or ''), str(detail.get('desc_ja') or '')
    label_text = str(label or prop_name).replace('_', ' ').strip() or prop_name
    ptype = str(prop_type or '').upper()
    if 'BOOL' in ptype:
        return (
            f'Enables or disables the {label_text} option for the related tool in this item.',
            f'この項目内の関連ツールで使う「{label_text}」オプションを有効または無効にします。',
        )
    if 'ENUM' in ptype:
        return (
            f'Chooses the {label_text} mode used by the matching button in this item.',
            f'この項目内の対応ボタンで使う「{label_text}」の方式を選びます。',
        )
    if any(token in ptype for token in ('FLOAT', 'INT')):
        return (
            f'Sets the numeric {label_text} value used by the matching button in this item.',
            f'この項目内の対応ボタンで使う「{label_text}」の数値を設定します。',
        )
    return (
        f'Sets the {label_text} value used by the matching button in this item.',
        f'この項目内の対応ボタンで使う「{label_text}」を設定します。',
    )


def property_description(prop_name: str, prop_type: str = '', label: str | None = None, context=None) -> str:
    en, ja = property_description_pair(prop_name, prop_type, label)
    return pick(en, ja, context)

def property_usage(prop_name: str, prop_type: str = '', label: str | None = None, context=None) -> str:
    detail = PROPERTY_DESCRIPTIONS.get(str(prop_name or ''))
    if detail:
        return _usage_text(detail, context)
    return pick('Adjust this before pressing the related execution button.', '関連する実行ボタンを押す前に調整します。', context)


def _op(op_id: str, en: str, ja: str, **props: Any) -> dict[str, Any]:
    return {'type': 'operator', 'op_id': op_id, 'label_en': en, 'label_ja': ja, 'props': {k: str(v) for k, v in props.items() if v is not None}}


def _prop(prop_name: str, en: str, ja: str, prop_type: str = '') -> dict[str, Any]:
    return {'type': 'property', 'property': prop_name, 'label_en': en, 'label_ja': ja, 'prop_type': prop_type}


def _note(en: str, ja: str, desc_en: str, desc_ja: str, usage_en: str = '', usage_ja: str = '') -> dict[str, Any]:
    return {'type': 'note', 'label_en': en, 'label_ja': ja, 'desc_en': desc_en, 'desc_ja': desc_ja, 'usage_en': usage_en, 'usage_ja': usage_ja}


_ALIGN_CONTROLS = [
    _op('smart_uv_suite.direction_align_mode', 'Vertex', '頂点', target='VERTEX'),
    _op('smart_uv_suite.direction_align_mode', 'Island', 'アイランド', target='ISLAND'),
] + [_op('smart_uv_suite.direction_align', detail['label_en'], detail['label_ja'], action=action) for action, detail in ALIGN_ACTIONS.items()]

SECTION_CONTROLS: dict[str, list[dict[str, Any]]] = {
    'uv_direction_align_unified_pad': _ALIGN_CONTROLS,
    'uv_vertex_align_pad': _ALIGN_CONTROLS,
    'uv_layout_align_pad': _ALIGN_CONTROLS,
    'align_selection': [
        _op('smart_uv_suite.uv_element_select_action', 'Grow', 'グロー選択', action='GROW'),
        _op('smart_uv_suite.uv_element_select_action', 'Shrink', 'シュリンク選択', action='SHRINK'),
        _op('smart_uv_suite.uv_element_select_action', 'Loop', 'ループ選択', action='LOOP'),
        _op('smart_uv_suite.uv_element_select_action', 'Ring', 'リング選択', action='RING'),
        _op('smart_uv_suite.uv_element_select_action', 'Linked', '連結選択', action='LINKED'),
        _op('smart_uv_suite.uv_element_select_action', 'Border', '境界選択', action='BORDER'),
        _op('smart_uv_suite.uv_element_select_action', 'All', '全選択', action='ALL'),
        _op('smart_uv_suite.uv_element_select_action', 'Clear', '選択解除', action='NONE'),
        _op('smart_uv_suite.uv_element_select_action', 'Invert', '反転選択', action='INVERT'),
        _op('smart_uv_suite.select_pick', 'Pick', 'ピック選択'),
        _op('smart_uv_suite.select_mode', 'Selection Mode', '選択モード'),
        _op('smart_uv_suite.select_island_active', 'Active Island', 'アクティブ島'),
        _op('smart_uv_suite.select_stacked', 'Stacked', 'スタック'),
        _op('smart_uv_suite.select_similar_islands', 'Similar Islands', '類似アイランド'),
        _op('smart_uv_suite.select_identical_islands', 'Identical Islands', '同一アイランド'),
        _op('smart_uv_suite.select_square_island', 'Square Island', '矩形アイランド'),
        _op('smart_uv_suite.select_by_area', 'Select by Area', '面積で選択'),
        _op('smart_uv_suite.select_texel_density', 'Texel Density', '密度で選択'),
        _op('smart_uv_suite.select_by_cursor', 'By Cursor', 'カーソルで選択'),
        _op('smart_uv_suite.select_mirror3d', 'Mirrored 3D', '3Dミラー選択'),
        _op('smart_uv_suite.select_uv_select_overlapped', 'Overlap', '重なり'),
        _op('smart_uv_suite.select_uv_select_flipped', 'Flipped', '反転UV'),
        _op('smart_uv_suite.select_zero_islands', 'Zero Area', 'ゼロ面積'),
        _op('smart_uv_suite.select_uv_boundary', 'UV Boundary', 'UV境界'),
        _op('smart_uv_suite.select_edge', 'Directional Edges', '方向エッジ'),
        _op('smart_uv_suite.select_half', 'Half', '半分選択'),
        _op('smart_uv_suite.select_flipped_faces', 'Flipped Faces', '反転面'),
        _op('smart_uv_suite.select_fragmented_islands', 'Fragmented Islands', '分断アイランド'),
        _op('smart_uv_suite.select_zero', 'Zero Region', 'ゼロ領域'),
        _op('smart_uv_suite.select_udim_crossing', 'UDIM Crossing', 'UDIM跨ぎ'),
        _op('smart_uv_suite.inspect_inspector_select_all', 'All Issues', '全問題選択'),
    ],
    'uv_vertex_line_flow': [
        _op('smart_uv_suite.align_edges', 'Align Edge', '辺を整列'),
        _op('smart_uv_suite.inspect_orient_world', 'World Align', 'ワールド軸整列'),
        _op('smart_uv_suite.vertex_straighten_selected', 'Straighten', '直線化'),
        _op('smart_uv_suite.vertex_even_straighten_selected', 'Even Straighten', '均等直線化'),
        _op('smart_uv_suite.seam_rectify', 'Rectify', '矩形補正'),
        _op('smart_uv_suite.align_uv_circle', 'Circularize', '円形化'),
        _op('smart_uv_suite.align_normalize', 'Normalize', '正規化'),
        _op('smart_uv_suite.align_relax', 'Relax', 'リラックス'),
        _prop('smart_relax_iterations', 'Relax Iterations', 'リラックス反復', 'INT'),
        _op('smart_uv_suite.vertex_set_flow_selected', 'Set Flow', 'フロー設定'),
        _prop('uv_flow_strength', 'Flow Strength', 'フロー強度', 'FLOAT'),
    ],
    'uv_vertex_snap_ops': [
        _prop('suv_consolidated_snap_vertex_distance', 'Distance', '距離', 'FLOAT'),
        _op('smart_uv_suite.consolidated_snap_uv', 'Grid', 'グリッド', mode='GRID'),
        _op('smart_uv_suite.consolidated_snap_uv', 'Pixel', 'ピクセル', mode='PIXEL'),
        _op('smart_uv_suite.consolidated_snap_uv', 'Vertex', '頂点', mode='VERTEX'),
    ],
    'align_stitch_suite': [
        _op('smart_uv_suite.stitch_action', 'Connected Island to Selected', '島→選', mode='ISLAND_CONNECTED_TO_SELECTED'),
        _op('smart_uv_suite.stitch_action', 'Selected Island to Connected', '選→島', mode='ISLAND_SELECTED_TO_CONNECTED'),
        _op('smart_uv_suite.stitch_action', 'Both Islands to Middle', '島中間', mode='ISLAND_AVERAGE'),
        _op('smart_uv_suite.stitch_action', 'Connected Edge to Selected', '辺→選', mode='EDGE_CONNECTED_TO_SELECTED'),
        _op('smart_uv_suite.stitch_action', 'Selected Edge to Connected', '選→辺', mode='EDGE_SELECTED_TO_CONNECTED'),
        _op('smart_uv_suite.stitch_action', 'Both Edges to Middle', '辺中間', mode='EDGE_AVERAGE'),
    ],
    'native_basic_settings': [
        _prop('canvas_size', 'Texture Size', 'テクスチャサイズ', 'INT'),
        _prop('fit_padding_px', 'Fit Padding', 'フィット余白', 'INT'),
        _prop('checker_size_width', 'Checker Width', '画像解像度 横', 'INT'),
        _prop('checker_size_height', 'Checker Height', '画像解像度 縦', 'INT'),
        _prop('checker_tile_count_u', 'Checker Tiles U', 'チェックサイズ 横', 'INT'),
        _prop('checker_tile_count_v', 'Checker Tiles V', 'チェックサイズ 縦', 'INT'),
        _prop('suv_native_grid_divisions', 'Grid Divisions', 'グリッド分割', 'INT'),
        _op('smart_uv_suite.native_basic_action', 'Checker', 'チェッカー', action='CHECKER_CREATE'),
        _op('smart_uv_suite.native_basic_action', 'Focus', '表示調整', action='FOCUS_VIEW'),
        _op('smart_uv_suite.native_basic_action', 'Snap Grid', 'グリッド吸着', action='SNAP_GRID'),
    ],
    'basic_map_channels': [
        _prop('unwrap_map_channel', 'Active UV Channel', '使用UVチャンネル', 'ENUM'),
        _prop('map_channel_add_name', 'New UV Name', '新規UV名', 'STRING'),
        _prop('map_channel_copy_source', 'Copy Source', 'コピー元', 'ENUM'),
        _prop('map_channel_copy_target', 'Copy Target', 'コピー先', 'ENUM'),
        _op('smart_uv_suite.map_channel_add', 'Add', '追加'),
        _op('smart_uv_suite.map_channel_remove', 'Remove', '削除'),
        _op('smart_uv_suite.map_channel_move', 'Move', '移動'),
        _op('smart_uv_suite.map_channel_copy', 'Copy', 'コピー'),
    ],
    'native_basic_map_channels': [],
    'native_unwrap_hub': [
        _prop('auto_unwrap_mode', 'Method', '方式', 'ENUM'),
        _prop('smart_unwrap_realtime_preview', 'Live Unwrap', 'ライブ展開', 'BOOL'),
        _op('smart_uv_suite.unwrap_auto_run', 'Run Unwrap', '展開実行'),
    ],
    'native_unwrap_quick': [
        _op('smart_uv_suite.native_seam_action', 'Mark Seam', 'シームをマーク', action='MARK_SEAM'),
        _op('smart_uv_suite.native_seam_action', 'Clear Seam', 'シーム解除', action='CLEAR_SEAM'),
        _op('smart_uv_suite.native_seam_action', 'Sharp to Seam', 'シャープからシーム', action='SEAM_FROM_SHARP'),
        _op('smart_uv_suite.native_seam_action', 'Angle to Seam', '角度からシーム', action='SEAM_FROM_ANGLE'),
        _op('smart_uv_suite.native_seam_action', 'Pin', 'ピン', action='PIN'),
        _op('smart_uv_suite.native_seam_action', 'Unpin', 'ピン解除', action='UNPIN'),
        _op('smart_uv_suite.native_seam_action', 'Invert Pins', 'ピン反転', action='PIN_INVERT'),
        _op('smart_uv_suite.seam_snapshot_action', 'Save Scene', 'シーン保存', action='SAVE_SCENE'),
        _op('smart_uv_suite.seam_snapshot_action', 'Load Scene', 'シーン読込', action='LOAD_SCENE'),
        _op('smart_uv_suite.seam_snapshot_action', 'Save JSON', '外部保存', action='SAVE_FILE'),
        _op('smart_uv_suite.seam_snapshot_action', 'Load JSON', '外部読込', action='LOAD_FILE'),
        _op('smart_uv_suite.native_seam_action', 'Auto Seam', '自動シーム', action='AUTO_SEAM'),
    ],
    'native_align_hub': [
        _prop('uv_chain_axis_mode', 'Axis Basis', '軸基準', 'ENUM'),
        _prop('uv_chain_group_mode', 'Scope', '対象範囲', 'ENUM'),
        _prop('uv_flow_strength', 'Flow', 'フロー', 'FLOAT'),
        _prop('smart_relax_iterations', 'Relax', 'リラックス回数', 'INT'),
        _op('smart_uv_suite.native_align_action', 'Fit', 'フィット', action='FIT'),
        _op('smart_uv_suite.native_align_action', 'Straight', '直線化', action='STRAIGHTEN'),
        _op('smart_uv_suite.native_align_action', 'Grid', 'グリッド化', action='GRIDIFY'),
        _op('smart_uv_suite.native_align_action', 'Relax', 'リラックス', action='RELAX'),
        _op('smart_uv_suite.native_align_action', 'Rotate', '回転', action='ROTATE_90'),
        _op('smart_uv_suite.native_align_action', 'Flip U', 'U反転', action='FLIP_U'),
        _op('smart_uv_suite.native_align_action', 'Flip V', 'V反転', action='FLIP_V'),
        _op('smart_uv_suite.native_align_action', 'Snap', '吸着', action='SNAP_PIXEL'),
    ],
    'native_align_stitch': [
        _op('smart_uv_suite.native_align_action', 'Stitch/Weld', '結合', action='STITCH_WELD'),
        _op('smart_uv_suite.native_seam_action', 'Pin', 'ピン', action='PIN'),
        _op('smart_uv_suite.native_seam_action', 'Unpin', 'ピン解除', action='UNPIN'),
    ],
    'native_auto_packing': [
        _prop('unified_auto_pack_mode', 'Packing Preset', 'パッキングプリセット', 'ENUM'),
        _prop('unified_pack_margin_px', 'Margin px', '余白px', 'INT'),
        _prop('unified_pack_margin', 'Native Margin', '標準余白', 'FLOAT'),
        _prop('unified_pack_margin_method', 'Margin Method', '余白方式', 'ENUM'),
        _prop('unified_pack_shape_method', 'Shape Method', '形状方式', 'ENUM'),
        _prop('unified_pack_rotation_step', 'Rotation Step', '回転刻み', 'FLOAT'),
        _prop('unified_pack_rotate', 'Allow Rotation', '回転を許可', 'BOOL'),
        _prop('unified_pack_scale', 'Allow Scale', 'スケールを許可', 'BOOL'),
        _prop('unified_pack_lock_pinned', 'Lock Pinned', 'ピン固定', 'BOOL'),
        _prop('unified_pack_use_seed', 'Seed Search', 'Seed探索', 'BOOL'),
        _prop('unified_pack_seed', 'Seed', 'Seed', 'INT'),
        _prop('unified_pack_stack_identical', 'Stack Identical', '同一島を重ねる', 'BOOL'),
        _prop('unified_pack_merge_overlap', 'Treat Overlaps as One Island', '重なり島を複合島にする', 'BOOL'),
        _prop('unified_pack_chart_rescale', 'Chart Rescale', 'チャート密度再正規化', 'BOOL'),
        _prop('pack_group_mode', 'Group Mode', 'グループ方式', 'ENUM'),
        _prop('pack_group_layout', 'Group Layout', 'グループ配置', 'ENUM'),
        _op('smart_uv_suite.unified_auto_pack', 'Run Auto Pack', '自動パック実行'),
    ],
    'native_bake_hub': [
        _prop('canvas_size', 'Texture Size', 'テクスチャサイズ', 'INT'),
        _prop('fit_padding_px', 'Padding', '余白', 'INT'),
        _prop('workflow_density', 'Target Density', '目標密度', 'FLOAT'),
        _prop('suv_native_target_density', 'Native Density', '統合密度', 'FLOAT'),
        _op('smart_uv_suite.native_bake_action', 'Bake Prep', 'ベイク準備', action='BAKE_PREP'),
        _op('smart_uv_suite.native_bake_action', 'Density', '密度取得', action='DENSITY_GET'),
        _op('smart_uv_suite.native_bake_action', 'Normalize', '密度正規化', action='DENSITY_NORMALIZE'),
        _op('smart_uv_suite.native_bake_action', 'Checker', 'チェッカー', action='CHECKER_CREATE'),
        _op('smart_uv_suite.native_bake_action', 'Object IDs', 'オブジェクトID', action='COLOR_ID_OBJECTS'),
        _op('smart_uv_suite.native_bake_action', 'Face IDs', '面ID', action='COLOR_ID_FACES'),
    ],
    'native_id_hub': [
        _prop('uv_new_name', 'UV Name', 'UV名', 'STRING'),
        _prop('suv_native_uv_name', 'Native UV Name', '統合UV名', 'STRING'),
        _op('smart_uv_suite.native_id_action', 'Add', '追加', action='UVMAP_ADD'),
        _op('smart_uv_suite.native_id_action', 'Duplicate', '複製', action='UVMAP_DUPLICATE'),
        _op('smart_uv_suite.native_id_action', 'Remove', '削除', action='UVMAP_REMOVE'),
        _op('smart_uv_suite.native_id_action', 'Copy', 'コピー', action='UVMAP_COPY'),
    ],
    'native_cleanup_hub': [
        _prop('stretch_threshold', 'Stretch Limit', '歪み許容値', 'FLOAT'),
        _prop('scan_report_name', 'Report Name', 'レポート名', 'STRING'),
        _prop('smart_sliver_protection', 'Sliver Protection', '細片保護', 'BOOL'),
        _prop('smart_lock_overlaps', 'Preserve Overlap', '重なり保持', 'BOOL'),
        _op('smart_uv_suite.native_cleanup_action', 'Zero', 'ゼロ', action='SELECT_ZERO'),
        _op('smart_uv_suite.native_cleanup_action', 'Flipped', '反転', action='SELECT_FLIPPED'),
        _op('smart_uv_suite.native_cleanup_action', 'Overlap', '重なり', action='SELECT_OVERLAP'),
        _op('smart_uv_suite.native_cleanup_action', 'UDIM', 'UDIM', action='SELECT_UDIM'),
        _op('smart_uv_suite.native_cleanup_action', 'Auto Repair', '自動修復', action='AUTO_REPAIR'),
        _op('smart_uv_suite.native_cleanup_action', 'Invert', '反転選択', action='SELECT_INVERT'),
        _op('smart_uv_suite.native_cleanup_action', 'Clean Data', 'データ整理', action='CLEAN_GENERATED'),
    ],
    'native_io_hub': [
        _op('smart_uv_suite.native_io_action', 'Settings', '設定出力', action='EXPORT_SETTINGS'),
        _op('smart_uv_suite.native_io_action', 'Report', 'レポート', action='WRITE_REPORT'),
        _op('smart_uv_suite.native_io_action', 'Clean', '整理', action='CLEAN_GENERATED'),
    ],
    'operation_immediate_select': [
        _prop('operation_instant_select_enabled', 'Enable Instant Select Drag Move', '即時選択ドラッグ移動', 'BOOL'),
        _op('smart_uv_suite.instant_select_drag_move', 'Immediate Select Drag Move', '即時選択ドラッグ移動'),
    ],
    'operation_axis_constraint_memory': [
        _prop('operation_axis_constraint_memory_enabled', 'Remember Axis Constraint', '軸拘束の記憶', 'BOOL'),
        _op('smart_uv_suite.instant_select_drag_move', 'Drag Move Axis Reuse', 'ドラッグ移動の軸再利用'),
    ],
    'operation_cursor_to_hover_vertex': [
        _op('smart_uv_suite.cursor_to_hover_uv_vertex', '2D Cursor to Hover Vertex', 'ホバー頂点へ2Dカーソル'),
        _op('smart_uv_suite.copy_operator_id', 'Copy ID', 'IDコピー'),
    ],
    'operation_uv_gizmo_grip_fix': [
        _prop('operation_uv_gizmo_grip_fix_enabled', 'Enable UV Gizmo Grip Fix', 'UVギズモつかみ補助', 'BOOL'),
    ],
    'operation_uv_editor_ownership': [
        _prop('operation_uv_crossing_select_edges_enabled', 'Crossing Selection: Edges', '交差選択：辺', 'BOOL'),
        _prop('operation_uv_crossing_select_faces_enabled', 'Crossing Selection: Faces', '交差選択：面', 'BOOL'),
        _prop('operation_uv_proportional_cursor_keymap_enabled', 'UV Proportional Cursor Entry', 'UVプロポーショナル編集カーソル入力', 'BOOL'),
    ],
    'keymap_info': [
        _op('smart_uv_suite.keymap_info_action', 'Enable', '有効', action='ENABLE'),
        _op('smart_uv_suite.keymap_info_action', 'Disable', '無効', action='DISABLE'),
        _op('smart_uv_suite.keymap_info_action', 'Delete', '削除', action='DELETE'),
        _op('smart_uv_suite.keymap_info_action', 'Re-register', '再登録', action='REGISTER'),
        _op('smart_uv_suite.copy_operator_id', 'Copy Operator ID', '登録IDコピー'),
    ],
}
SECTION_CONTROLS['native_basic_map_channels'] = SECTION_CONTROLS['basic_map_channels']
SECTION_CONTROLS['pack_auto_packing'] = SECTION_CONTROLS['native_auto_packing']
SECTION_CONTROLS['manage_id'] = SECTION_CONTROLS['native_id_hub']
SECTION_CONTROLS['manage_cleanup'] = SECTION_CONTROLS['native_cleanup_hub']
SECTION_CONTROLS['manage_io'] = SECTION_CONTROLS['native_io_hub']



def _property_control_from_name(prop_name: Any) -> dict[str, Any]:
    name = str(prop_name or '').strip()
    detail = PROPERTY_DESCRIPTIONS.get(name)
    if detail:
        return _prop(name, detail.get('label_en', name), detail.get('label_ja', detail.get('label_en', name)), '')
    label = name.replace('_', ' ').strip().title() or name
    return _prop(name, label, label, '')


def _merge_static_help_data() -> None:
    data = _load_static_help_data()
    items = data.get('items') if isinstance(data, dict) else None
    settings = data.get('settings') if isinstance(data, dict) else None
    if not isinstance(items, dict) and not isinstance(settings, dict):
        return
    def _marker(control: dict[str, Any]) -> tuple[str, str, tuple[tuple[str, str], ...], str, str]:
        props = tuple(sorted((str(k), str(v)) for k, v in dict(control.get('props') or {}).items()))
        return (str(control.get('type') or ''), str(control.get('op_id') or control.get('property') or ''), props, str(control.get('label_en') or ''), str(control.get('label_ja') or ''))
    if isinstance(items, dict):
        for help_id, rows in items.items():
            key = str(help_id or '')
            if not key or not isinstance(rows, list):
                continue
            target = SECTION_CONTROLS.setdefault(key, [])
            seen = {_marker(c) for c in target if isinstance(c, dict)}
            for row in rows:
                if not isinstance(row, dict):
                    continue
                op_id = str(row.get('op_id') or '').strip()
                if not op_id:
                    continue
                props = row.get('props') if isinstance(row.get('props'), dict) else {}
                props = {str(k): str(v) for k, v in dict(props).items() if v is not None}
                label_en = str(row.get('label_en') or row.get('label') or op_id).strip()
                label_ja = str(row.get('label_ja') or label_en).strip()
                control = _op(op_id, label_en, label_ja, **props)
                if not props:
                    duplicate_labeled_operator = any(
                        isinstance(existing, dict)
                        and str(existing.get('type') or '') == 'operator'
                        and str(existing.get('op_id') or '') == op_id
                        and (str(existing.get('label_en') or '') == label_en or str(existing.get('label_ja') or '') == label_ja)
                        for existing in target
                    )
                    if duplicate_labeled_operator:
                        continue
                m = _marker(control)
                if m not in seen:
                    target.append(control)
                    seen.add(m)
                dkey = (op_id, tuple(sorted(props.items())))
                if dkey not in _EXTRACTED_OPERATOR_DETAILS:
                    _EXTRACTED_OPERATOR_DETAILS[dkey] = _static_detail_for_label(op_id, props, label_en, label_ja)
    if isinstance(settings, dict):
        for help_id, names in settings.items():
            key = str(help_id or '')
            if not key or not isinstance(names, list):
                continue
            target = SECTION_CONTROLS.setdefault(key, [])
            seen = {_marker(c) for c in target if isinstance(c, dict)}
            for name in names:
                control = _property_control_from_name(name)
                m = _marker(control)
                if m not in seen:
                    target.append(control)
                    seen.add(m)


_merge_static_help_data()

SECTION_ALIASES: dict[str, tuple[str, ...]] = {
    'category_workflow': ('native_basic_settings', 'basic_map_channels'),
    'category_unwrap': ('native_unwrap_hub', 'native_unwrap_quick'),
    'category_align': ('align_selection', 'uv_direction_align_unified_pad', 'uv_vertex_line_flow', 'uv_vertex_snap_ops', 'align_stitch_suite'),
    'category_pack': ('native_auto_packing',),
    'category_texel': ('native_bake_hub',),
    'category_operation': ('operation_immediate_select', 'operation_axis_constraint_memory', 'operation_cursor_to_hover_vertex', 'operation_uv_gizmo_grip_fix', 'operation_uv_editor_ownership'),
    'native_align_hub': ('native_align_hub', 'native_align_stitch'),
}


def section_controls(help_id: str, entry: Any = None, context=None) -> list[dict[str, Any]]:
    help_id = str(help_id or '')
    controls: list[dict[str, Any]] = []
    keys = SECTION_ALIASES.get(help_id, (help_id,))
    seen: set[tuple[str, str, tuple[tuple[str, str], ...]]] = set()
    for key in keys:
        for control in SECTION_CONTROLS.get(str(key), ()):  # type: ignore[arg-type]
            props = tuple(sorted((str(k), str(v)) for k, v in dict(control.get('props') or {}).items()))
            marker = (str(control.get('type') or ''), str(control.get('op_id') or control.get('property') or control.get('label_en') or ''), props, str(control.get('label_en') or ''), str(control.get('label_ja') or ''))
            if marker in seen:
                continue
            seen.add(marker)
            controls.append(dict(control))
    if not controls and entry is not None:
        try:
            for op_id in tuple(getattr(entry, 'operators', ()) or ()):  # fallback for older help groups
                controls.append(_op(str(op_id), str(op_id), str(op_id)))
        except Exception:
            pass
    return controls


def control_label(control: dict[str, Any], context=None) -> str:
    ctype = str(control.get('type') or '')
    if ctype == 'operator':
        return operator_label(str(control.get('op_id') or ''), control.get('props') or {}, context, str(control.get('label_en') or ''), str(control.get('label_ja') or ''))
    return pick(str(control.get('label_en') or control.get('property') or ''), str(control.get('label_ja') or control.get('label_en') or control.get('property') or ''), context)


def describe_control(control: dict[str, Any], context=None) -> str:
    ctype = str(control.get('type') or '')
    if ctype == 'operator':
        return describe_operator_with_label(str(control.get('op_id') or ''), control.get('props') or {}, str(control.get('label_en') or ''), str(control.get('label_ja') or ''), context)
    if ctype == 'property':
        return property_description(str(control.get('property') or ''), str(control.get('prop_type') or ''), control_label(control, context), context)
    return pick(str(control.get('desc_en') or ''), str(control.get('desc_ja') or ''), context)


def control_usage(control: dict[str, Any], context=None) -> str:
    ctype = str(control.get('type') or '')
    if ctype == 'operator':
        return usage_for_operator_with_label(str(control.get('op_id') or ''), control.get('props') or {}, str(control.get('label_en') or ''), str(control.get('label_ja') or ''), context)
    if ctype == 'property':
        return property_usage(str(control.get('property') or ''), str(control.get('prop_type') or ''), control_label(control, context), context)
    return pick(str(control.get('usage_en') or ''), str(control.get('usage_ja') or ''), context)


def _make_description(op_id: str):
    @classmethod
    def _description(cls, context, properties):  # noqa: ANN001 - Blender signature
        return describe_operator(op_id, properties, context)
    return _description


def _iter_package_classes(package_name: str):
    prefix = package_name + '.'
    seen: set[tuple[str, str]] = set()
    for module_name, module in ():
        if module is None:
            continue
        if module_name != package_name and not module_name.startswith(prefix):
            continue
        try:
            members = inspect.getmembers(module, inspect.isclass)
        except Exception:
            continue
        for class_name, cls in members:
            try:
                owner = str(getattr(cls, '__module__', '') or '')
                if owner != module_name and not owner.startswith(prefix):
                    continue
            except Exception:
                continue
            key = (owner or module_name, str(class_name))
            if key in seen:
                continue
            seen.add(key)
            yield key, cls


def apply(package_name: str = 'smart_uv_suite') -> int:
    if bpy is None:
        return 0
    count = 0
    for key, cls in _iter_package_classes(package_name):
        try:
            if not issubclass(cls, bpy.types.Operator):
                continue
        except Exception:
            continue
        op_id = _norm_op(getattr(cls, 'bl_idname', ''))
        if not op_id or op_id.startswith('wm.uv_suite_') or op_id in {'smart_uv_suite.show_help'}:
            continue
        if key not in _ORIGINAL_DESCRIPTIONS:
            try:
                _ORIGINAL_DESCRIPTIONS[key] = getattr(cls, 'bl_description', '')
            except Exception:
                _ORIGINAL_DESCRIPTIONS[key] = ''
        try:
            setattr(cls, 'description', _make_description(op_id))
            base = describe_operator(op_id, {}, None)
            if base:
                setattr(cls, 'bl_description', base)
            _PATCHED_CLASSES.add(key)
            count += 1
        except Exception:
            continue
    return count


def clear() -> None:
    for key in list(_PATCHED_CLASSES):
        module_name, class_name = key
        module = sys.modules.get(module_name)
        cls = getattr(module, class_name, None) if module is not None else None
        if cls is not None and key in _ORIGINAL_DESCRIPTIONS:
            try:
                setattr(cls, 'bl_description', _ORIGINAL_DESCRIPTIONS[key])
            except Exception:
                pass
    _PATCHED_CLASSES.clear()
    _ORIGINAL_DESCRIPTIONS.clear()
