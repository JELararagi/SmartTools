# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None

_NAMESPACE = {}
_REGISTERED = []
_PROP = 'suv_quality_dashboard_density'
_ITEMS = (
    ('AUTO', 'Auto', 'Choose the dashboard density automatically from the current region width. / 現在の領域幅に応じてダッシュボード密度を自動選択します。'),
    ('ESSENTIAL', 'Essential', 'Show the most important dashboard chips first for a compact view. / 重要な情報を優先してコンパクトに表示します。'),
    ('FULL', 'Full', 'Show the full dashboard status set. / ダッシュボードの状態項目をすべて表示します。'),
)


def _tr(context, key: str, en: str, ja: str, **fmt) -> str:
    fn = _NAMESPACE.get('tr')
    text = None
    if callable(fn):
        try:
            text = fn(context, key, **fmt)
        except Exception:
            text = None
    if not text:
        text = en
    try:
        return text.format(**fmt)
    except Exception:
        return text


def _wm(context):
    try:
        return getattr(context, 'window_manager', None)
    except Exception:
        return None


def _norm(value: str) -> str:
    value = str(value or 'AUTO').strip().upper()
    return value if value in {'AUTO', 'ESSENTIAL', 'FULL'} else 'AUTO'


def get_density_override(context) -> str:
    wm = _wm(context)
    if wm is None:
        return 'AUTO'
    try:
        return _norm(getattr(wm, _PROP, 'AUTO'))
    except Exception:
        return 'AUTO'


def set_density_override(context, mode: str) -> str:
    wm = _wm(context)
    mode = _norm(mode)
    if wm is not None:
        try:
            setattr(wm, _PROP, mode)
        except Exception:
            pass
    return mode


def effective_density(namespace: dict, context) -> str:
    override = get_density_override(context)
    if override != 'AUTO':
        return override
    layout_mod = namespace.get('_quality_layout_module')
    width = 0
    if layout_mod is not None and hasattr(layout_mod, 'region_width'):
        try:
            width = int(layout_mod.region_width(context) or 0)
        except Exception:
            width = 0
    if width <= 0:
        return 'FULL'
    if width < 1180:
        return 'ESSENTIAL'
    return 'FULL'


def scan_density_control(namespace: dict, context) -> dict:
    override = get_density_override(context)
    effective = effective_density(namespace, context)
    data = {
        'override': override,
        'manual': override != 'AUTO',
        'effective': effective,
        'available_modes': 3,
    }
    namespace['_suv_density_control_last'] = dict(data)
    return data


class SUV_OT_quality_set_density_mode(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_set_density_mode'
    bl_label = 'Set Dashboard Density'
    bl_description = 'Switch how compact the dashboard status chips should be. / ダッシュボードの状態表示をどの程度コンパクトにするか切り替えます。'
    bl_options = set()

    mode: bpy.props.EnumProperty(
        name='Dashboard Density',
        description='Choose how compact the dashboard should be / ダッシュボードの表示密度を選びます',
        items=_ITEMS,
        default='AUTO',
    )

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        mode = set_density_override(context, self.mode)
        controls_mod = _NAMESPACE.get('_quality_controls_module')
        if controls_mod is not None and hasattr(controls_mod, 'notify_controls_changed'):
            try:
                controls_mod.notify_controls_changed(_NAMESPACE, context, reason='density')
            except Exception:
                pass
        self.report({'INFO'}, _tr(context, 'msg.quality_density_set', 'Dashboard density set to {mode}.', 'ダッシュボード密度を {mode} に切り替えました。', mode=mode))
        return {'FINISHED'}


def register(namespace: dict):
    global _NAMESPACE
    _NAMESPACE = namespace if isinstance(namespace, dict) else {}
    if bpy is None:
        return []
    classes = [SUV_OT_quality_set_density_mode]
    reg = []
    for cls in classes:
        try:
            _suv_resource.register_class(cls)
            reg.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = reg
    try:
        if not hasattr(bpy.types.WindowManager, _PROP):
            _suv_resource.register_property(
                bpy.types.WindowManager,
                _PROP,
                bpy.props.EnumProperty(
                    name='Dashboard Density',
                    description='Quick visual dashboard density override / クイック視覚ダッシュボードの表示密度を上書きします',
                    items=_ITEMS,
                    default='AUTO',
                )
            )
    except Exception:
        pass
    return reg


def unregister(namespace: dict | None = None):
    if bpy is None:
        return []
    removed = []
    for cls in reversed(list(_REGISTERED)):
        try:
            _suv_resource.unregister_class(cls)
            removed.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = []
    try:
        _suv_resource.unregister_property(bpy.types.WindowManager, _PROP)
    except Exception:
        pass
    return removed
