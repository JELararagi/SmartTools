# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Compatibility shim for the retired 1.8.102 consolidation layer.

The final runtime authority is :mod:`uv_room_integrity_18103`.  This file keeps
old imports and older incremental register hooks from failing, while preventing
the removed 1.8.102 implementation from remaining as a separate execution path.
"""
from __future__ import annotations

from typing import Any, Dict, Optional

_VERSION = (1, 8, 103)


def _impl():
    from . import uv_room_integrity_18103 as impl
    return impl


def apply_all(ns: Optional[Dict[str, Any]] = None, context: Any = None) -> None:
    return _impl().apply_all(ns, context)


def install(ns: Optional[Dict[str, Any]] = None, context: Any = None) -> None:
    return _impl().install(ns, context)


def unregister() -> None:
    return _impl().unregister()


def audit(context: Any = None) -> Dict[str, Any]:
    return _impl().audit(context)
