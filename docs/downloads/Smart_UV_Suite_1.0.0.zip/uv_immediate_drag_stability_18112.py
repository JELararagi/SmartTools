# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Smart UV Suite 1.8.112 Immediate Select drag stability layer.

The final Immediate Select route owns the entire press-to-drag path when a UV
hit is found.  It no longer waits for Blender's native translate invoke and does
not build an eager UV hit cache at add-on registration time, which keeps startup
stable on large edit meshes.
"""
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple
import math

import bpy
from mathutils import Vector

from . import uv_room_integrity_18103 as ri
from . import uv_multi_object_18104 as mo

_VERSION = (1, 8, 181)
_NS: Dict[str, Any] = {}
_PREV: Dict[str, Any] = {}
_INSTANT_ID = "smart_uv_suite.instant_select_drag_move"
_STICKY_PASS_ID = "smart_uv_suite.sticky_select_expand_passthrough"
_GIZMO_GRIP_ID = "smart_uv_suite.uv_gizmo_grip_fix_grab"
_ALLOWED_INSTANT_MAPS: Tuple[Tuple[str, str], ...] = (
    ("UV Editor", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Tweak", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Tweak (fallback)", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Select Box", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Select Box (fallback)", "IMAGE_EDITOR"),
)
_INSTANT_MODIFIER_ROWS: Tuple[Tuple[bool, bool], ...] = (
    (False, False),
    (True, False),
    (False, True),
    (True, True),
)
_FORBIDDEN_INSTANT_MAPS: Tuple[str, ...] = (
    "Window", "Image", "Image Generic",
    "Generic Gizmo", "Generic Gizmo Drag", "Generic Gizmo Click Drag",
    "Generic Gizmo Maybe Drag", "Generic Gizmo Select",
    "Image Editor Tool: Uv, Move", "Image Editor Tool: Uv, Move (fallback)",
    "Image Editor Tool: Uv, Rotate", "Image Editor Tool: Uv, Rotate (fallback)",
    "Image Editor Tool: Uv, Scale", "Image Editor Tool: Uv, Scale (fallback)",
    "Image Editor Tool: Uv, Transform", "Image Editor Tool: Uv, Transform (fallback)",
    "Image Editor Tool: Uv, Cursor", "Image Editor Tool: Uv, Cursor (fallback)",
    "Image Editor Tool: Uv, Select Lasso", "Image Editor Tool: Uv, Select Lasso (fallback)",
    "Image Editor Tool: Uv, Select Circle", "Image Editor Tool: Uv, Select Circle (fallback)",
)
_REAL_TRANSFORM_TOOL_TOKENS = (
    "move", "translate", "rotate", "scale", "transform", "cursor", "annotate", "lasso", "circle",
)
_SELECT_TOOL_IDS = {
    "", "builtin.select", "builtin.tweak", "builtin.select_box", "builtin.box_select", "builtin.selectbox",
}
_EPS = 1.0e-8
_GESTURE_SEQUENCE = 0
_LAST_GESTURE_DIAGNOSTIC: Dict[str, Any] = {
    "sequence": 0,
    "phase": "idle",
    "result": "NONE",
    "reason": "not_invoked",
}


def _s(value: Any) -> str:
    try:
        return str(value or "")
    except Exception:
        return ""


def _context_or_bpy(context: Any = None) -> Any:
    return context or getattr(bpy, "context", None)


def _uv_context(context: Any) -> bool:
    try:
        area = getattr(context, "area", None)
        region = getattr(context, "region", None)
        space = getattr(context, "space_data", None)
        if getattr(area, "type", None) != "IMAGE_EDITOR":
            return False
        if region is not None and getattr(region, "type", "WINDOW") != "WINDOW":
            return False
        if space is not None and getattr(space, "type", "IMAGE_EDITOR") != "IMAGE_EDITOR":
            return False
        return True
    except Exception:
        return False


def _instant_enabled(context: Any) -> bool:
    try:
        return bool(ri._instant_enabled(context))
    except Exception:
        pass
    try:
        ws = ri._workspace(context)
        return bool(getattr(ws, "operation_instant_select_enabled", False))
    except Exception:
        return False


def _active_tool_id(context: Any) -> str:
    try:
        return ri._active_tool_id(context)
    except Exception:
        pass
    try:
        tools = getattr(getattr(context, "workspace", None), "tools", None)
        if tools is None:
            return ""
        for args in (("UV",), ("IMAGE_EDITOR",), tuple()):
            try:
                tool = tools.from_space_image_mode(*args, create=False)
            except TypeError:
                try:
                    tool = tools.from_space_image_mode(*args)
                except Exception:
                    tool = None
            except Exception:
                tool = None
            tid = _s(getattr(tool, "idname", "")).lower() if tool else ""
            if tid:
                return tid
    except Exception:
        pass
    return ""


def _native_tool_should_pass(context: Any) -> bool:
    tid = _active_tool_id(context).lower()
    if tid in _SELECT_TOOL_IDS:
        return False
    # Select Box must remain a selection tool.  Older layers searched for the
    # token "box" and therefore disabled Immediate Select while Select Box was
    # active; that is the intermittent non-start route this layer removes.
    if "select_box" in tid or tid.endswith(".box_select") or tid.endswith(".selectbox"):
        return False
    return any(token in tid for token in _REAL_TRANSFORM_TOOL_TOKENS)


def _event_xy(event: Any) -> Tuple[int, int]:
    try:
        return int(getattr(event, "mouse_region_x", getattr(event, "mouse_x", 0)) or 0), int(getattr(event, "mouse_region_y", getattr(event, "mouse_y", 0)) or 0)
    except Exception:
        return 0, 0


def _configured_drag_threshold(context: Any, event: Any = None) -> Tuple[int, str]:
    """Return Blender's active mouse/tablet drag threshold in pixels."""
    source = "fallback"
    value: Any = 3
    try:
        inputs = getattr(getattr(context, "preferences", None), "inputs", None)
        tablet = bool(getattr(event, "is_tablet", False)) if event is not None else False
        source = "drag_threshold_tablet" if tablet else "drag_threshold_mouse"
        if inputs is not None and hasattr(inputs, source):
            value = getattr(inputs, source)
        elif inputs is not None and hasattr(inputs, "drag_threshold"):
            source = "drag_threshold"
            value = getattr(inputs, source)
        else:
            source = "fallback"
    except Exception:
        source = "fallback"
        value = 3
    try:
        return max(1, int(round(float(value)))), source
    except Exception:
        return 3, "fallback"


def _record_gesture(
    self: Any,
    phase: str,
    result: str,
    reason: str,
    event: Any = None,
    **details: Any,
) -> None:
    """Keep one quiet, probe-readable diagnostic for the public gesture."""
    global _GESTURE_SEQUENCE, _LAST_GESTURE_DIAGNOSTIC
    sequence = getattr(self, "_sus18178_sequence", None)
    if sequence is None:
        _GESTURE_SEQUENCE += 1
        sequence = _GESTURE_SEQUENCE
        try:
            self._sus18178_sequence = sequence
        except Exception:
            pass
    payload: Dict[str, Any] = {
        "sequence": int(sequence),
        "phase": _s(phase),
        "result": _s(result),
        "reason": _s(reason),
        "event_type": _s(getattr(event, "type", "")) if event is not None else "",
        "event_value": _s(getattr(event, "value", "")) if event is not None else "",
        "dragging": bool(getattr(self, "_sus18112_dragging", False)),
    }
    for key, value in details.items():
        if isinstance(value, (str, int, float, bool)) or value is None:
            payload[_s(key)] = value
    _LAST_GESTURE_DIAGNOSTIC = payload
    try:
        self._sus18178_failure_reason = _s(reason)
    except Exception:
        pass


def _transaction_snapshot_present(self: Any) -> bool:
    """Report the existing 1.8.168 wrapper snapshot without duplicating it."""
    return isinstance(getattr(self, "_smart_uv_18168_snapshot", None), dict)


def _restore_direct_drag_fallback(self: Any, context: Any) -> bool:
    """Restore only direct UV records when called without the public wrapper.

    Production registration wraps this operator with ``modal_state_18168``.
    That wrapper owns the single full selection/UV snapshot and restores it on
    ``CANCELLED``.  The fallback is deliberately skipped when that snapshot is
    present, avoiding a second full or partial restore on every public cancel.
    """
    if _transaction_snapshot_present(self):
        return False
    had_batches = bool(getattr(self, "_sus18112_batches", None))
    if not had_batches:
        return False
    try:
        _restore_original(self, context)
        return True
    except Exception:
        return False


def _gizmo_should_own_press(self: Any, context: Any, event: Any) -> bool:
    """Defer only an enabled, exact Smart UV gizmo handle zone."""
    try:
        ws = getattr(getattr(context, "scene", None), "suv_workspace", None)
        if not bool(getattr(ws, "operation_uv_gizmo_grip_fix_enabled", False)):
            return False
    except Exception:
        return False
    try:
        from . import uv_gizmo_grip_fix as grip
        if not bool(getattr(grip, "is_enabled", lambda: False)()):
            return False
    except Exception:
        return False
    try:
        checker = getattr(self, "_integrated_uv_gizmo_grip_should_own_press", None)
        return bool(checker(context, event)) if callable(checker) else False
    except Exception:
        return False


def _region_to_uv_vec(context: Any, xy: Tuple[int, int]) -> Optional[Vector]:
    try:
        p = ri._region_to_uv(context, int(xy[0]), int(xy[1]))
        if p is None:
            return None
        return Vector((float(p[0]), float(p[1])))
    except Exception:
        return None


def _edit_targets(context: Any) -> List[Tuple[Any, Any, Any]]:
    try:
        return list(mo._target_data(context))
    except Exception:
        pass
    try:
        import bmesh
        obj = getattr(context, "edit_object", None) or getattr(context, "active_object", None) or getattr(context, "object", None)
        if obj is None or getattr(obj, "type", None) != "MESH" or getattr(obj, "mode", None) != "EDIT":
            return []
        bm = bmesh.from_edit_mesh(obj.data)
        ri._ensure_lookup(bm)
        uv_layer = ri._uv_layer(bm)
        return [(obj, bm, uv_layer)] if uv_layer is not None else []
    except Exception:
        return []


def _update_meshes(targets: Sequence[Tuple[Any, Any, Any]]) -> None:
    try:
        mo._update_meshes(targets)
        return
    except Exception:
        pass
    try:
        import bmesh
        seen: Set[int] = set()
        for obj, _bm, _uv_layer in targets:
            mesh = getattr(obj, "data", None)
            if mesh is None:
                continue
            try:
                key = int(mesh.as_pointer())
            except Exception:
                key = id(mesh)
            if key in seen:
                continue
            seen.add(key)
            try:
                bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
            except TypeError:
                bmesh.update_edit_mesh(mesh)
            except Exception:
                pass
    except Exception:
        pass


def _find_hit(context: Any, event: Any) -> Optional[Dict[str, Any]]:
    try:
        hit = mo._direct_find_uv_hit_multi(None, context, event)
        if hit:
            return _annotate_hit_for_stable_records(context, hit)
    except Exception:
        pass
    try:
        hit = ri._direct_find_uv_hit(None, context, event)
        return _annotate_hit_for_stable_records(context, hit) if hit else None
    except Exception:
        return None


def _hit_selected(context: Any, hit: Dict[str, Any]) -> bool:
    """Return whether the pressed UV target is selected.

    With UV Select Sync disabled, only the live UV selection flags are trusted.
    Mesh vertex/edge/face selection is intentionally ignored there because edit
    meshes often keep all geometry selected while the UV selection is smaller;
    treating the mesh selection as UV selection made presses on other UV elements
    look selected and prevented the press-to-drag path from starting.

    With UV Select Sync enabled, Blender's mesh selection is the authoritative
    selection state, so the existing room-integrity/multi-object helpers are used.
    """
    if not hit:
        return False
    try:
        if ri._sync_on(context):
            try:
                return bool(mo._hit_is_selected_multi(context, hit))
            except Exception:
                pass
            try:
                return bool(ri._hit_is_selected(context, hit))
            except Exception:
                return False
    except Exception:
        pass
    try:
        uv_layer = hit.get("uv_layer")
        if uv_layer is None:
            return False
        loops = set(hit.get("target_loops") or [])
        edges = set(hit.get("target_edges") or [])
        faces = set(hit.get("target_faces") or [])
        if not loops and not edges and not faces:
            tl, te, tf = ri._target_from_hit(hit, uv_layer)
            loops, edges, faces = set(tl or []), set(te or []), set(tf or [])
        mode = ri._uv_mode(context)
        if mode == "FACE" and faces:
            for face in list(faces or []):
                face_loops = list(getattr(face, "loops", []) or [])
                if not face_loops:
                    return False
                for loop in face_loops:
                    if not ri._live_v(loop, uv_layer):
                        return False
            return True
        if mode == "EDGE" and edges:
            return bool(edges) and all(ri._live_e(loop, uv_layer) for loop in list(edges or []))
        if loops:
            return bool(loops) and all(ri._live_v(loop, uv_layer) for loop in list(loops or []))
        if edges:
            return bool(edges) and all(ri._live_e(loop, uv_layer) for loop in list(edges or []))
        if faces:
            for face in list(faces or []):
                for loop in list(getattr(face, "loops", []) or []):
                    if not ri._live_v(loop, uv_layer):
                        return False
            return True
    except Exception:
        pass
    return False


def _select_hit(context: Any, hit: Dict[str, Any], event: Any) -> bool:
    try:
        return bool(mo._select_hit_immediate_multi(context, hit, event))
    except Exception:
        pass
    try:
        return bool(ri._select_hit_immediate(context, hit, event))
    except Exception:
        return False




def _loop_record(loop: Any, uv_layer: Any) -> Optional[Tuple[int, int, Vector]]:
    try:
        face = loop.face
        fi = int(getattr(face, "index", -1))
        loops = tuple(face.loops)
        li = loops.index(loop)
        return (fi, li, loop[uv_layer].uv.copy())
    except Exception:
        return None


def _add_record(records: List[Tuple[int, int, Vector]], seen: Set[Tuple[int, int]], loop: Any, uv_layer: Any) -> None:
    rec = _loop_record(loop, uv_layer)
    if rec is None:
        return
    key = (int(rec[0]), int(rec[1]))
    if key in seen:
        return
    seen.add(key)
    records.append(rec)


def _annotate_hit_for_stable_records(context: Any, hit: Dict[str, Any]) -> Dict[str, Any]:
    try:
        face = hit.get("face")
        loop = hit.get("loop")
        uv_layer = hit.get("uv_layer")
        if face is not None:
            hit["_sus18112_face_index"] = int(getattr(face, "index", -1))
        if loop is not None:
            try:
                hit["_sus18112_local_index"] = tuple(loop.face.loops).index(loop)
            except Exception:
                pass
            try:
                hit["_sus18112_vert_index"] = int(getattr(loop.vert, "index", -1))
            except Exception:
                pass
            try:
                hit["_sus18112_edge_index"] = int(getattr(loop.edge, "index", -1))
            except Exception:
                pass
        if uv_layer is not None:
            try:
                hit["_sus18112_uv_layer_name"] = str(getattr(uv_layer, "name", "") or "")
            except Exception:
                pass
        try:
            if hit.get("obj") is None:
                obj = getattr(context, "edit_object", None) or getattr(context, "active_object", None) or getattr(context, "object", None)
                if obj is not None and getattr(obj, "type", None) == "MESH":
                    hit["obj"] = obj
            if hit.get("mesh") is None and hit.get("obj") is not None:
                hit["mesh"] = getattr(hit.get("obj"), "data", None)
        except Exception:
            pass
        try:
            hit["_sus18112_mode"] = ri._uv_mode(context)
        except Exception:
            hit["_sus18112_mode"] = _s(hit.get("type") or "VERTEX").upper()
        try:
            uv = hit.get("uv")
            if isinstance(uv, Vector):
                hit["_sus18112_uv"] = (float(uv.x), float(uv.y))
            elif isinstance(uv, (tuple, list)) and len(uv) >= 2:
                hit["_sus18112_uv"] = (float(uv[0]), float(uv[1]))
        except Exception:
            pass
        try:
            a = hit.get("a")
            b = hit.get("b")
            if isinstance(a, Vector):
                hit["_sus18112_edge_a"] = (float(a.x), float(a.y))
            elif isinstance(a, (tuple, list)) and len(a) >= 2:
                hit["_sus18112_edge_a"] = (float(a[0]), float(a[1]))
            if isinstance(b, Vector):
                hit["_sus18112_edge_b"] = (float(b.x), float(b.y))
            elif isinstance(b, (tuple, list)) and len(b) >= 2:
                hit["_sus18112_edge_b"] = (float(b[0]), float(b[1]))
        except Exception:
            pass
    except Exception:
        pass
    return hit


def _uv_vec2(loop: Any, uv_layer: Any) -> Tuple[float, float]:
    try:
        uv = loop[uv_layer].uv
        return (float(uv.x), float(uv.y))
    except Exception:
        return (0.0, 0.0)


def _uv_pair_18193(value: Any) -> Optional[Tuple[float, float]]:
    if value is None:
        return None
    try:
        return (float(value[0]), float(value[1]))
    except Exception:
        pass
    try:
        return (float(value.x), float(value.y))
    except Exception:
        return None


def _pt_close(a: Tuple[float, float], b: Tuple[float, float], eps: float = 1.0e-7) -> bool:
    try:
        return abs(float(a[0]) - float(b[0])) <= eps and abs(float(a[1]) - float(b[1])) <= eps
    except Exception:
        return False


def _seg_close(a0: Tuple[float, float], b0: Tuple[float, float], a1: Tuple[float, float], b1: Tuple[float, float]) -> bool:
    return (_pt_close(a0, a1) and _pt_close(b0, b1)) or (_pt_close(a0, b1) and _pt_close(b0, a1))


def _stable_batch_from_hit(context: Any, hit: Dict[str, Any]) -> List[Dict[str, Any]]:
    try:
        import bmesh
        obj = hit.get("obj")
        mesh = getattr(obj, "data", None) or hit.get("mesh")
        if mesh is None:
            return []
        if obj is None:
            for cand, _bm0, _uv0 in _edit_targets(context):
                if getattr(cand, "data", None) is mesh:
                    obj = cand
                    break
        bm = bmesh.from_edit_mesh(mesh)
        ri._ensure_lookup(bm)
        uv_name = _s(hit.get("_sus18112_uv_layer_name") or "")
        uv_layer = bm.loops.layers.uv.get(uv_name) if uv_name else None
        if uv_layer is None:
            uv_layer = ri._uv_layer(bm)
        if uv_layer is None:
            return []
        fi = int(hit.get("_sus18112_face_index", -1))
        li = int(hit.get("_sus18112_local_index", 0))
        mode = _s(hit.get("_sus18112_mode") or hit.get("type") or ri._uv_mode(context)).upper()
        htype = _s(hit.get("type") or mode).upper()
        records: List[Tuple[int, int, Vector]] = []
        seen: Set[Tuple[int, int]] = set()
        hit_uv = _uv_pair_18193(hit.get("_sus18112_uv")) or _uv_pair_18193(hit.get("uv"))
        if fi < 0 or fi >= len(bm.faces):
            if hit_uv is None:
                return []
            edge_a = _uv_pair_18193(hit.get("_sus18112_edge_a"))
            edge_b = _uv_pair_18193(hit.get("_sus18112_edge_b"))
            for f in bm.faces:
                if getattr(f, "hide", False):
                    continue
                for l in f.loops:
                    try:
                        l_uv = _uv_vec2(l, uv_layer)
                        n_uv = _uv_vec2(l.link_loop_next, uv_layer)
                        if mode == "EDGE" or htype == "EDGE":
                            if edge_a is not None and edge_b is not None:
                                if not _seg_close(l_uv, n_uv, edge_a, edge_b):
                                    continue
                            elif not (_pt_close(l_uv, hit_uv) or _pt_close(n_uv, hit_uv)):
                                continue
                            _add_record(records, seen, l, uv_layer)
                            _add_record(records, seen, l.link_loop_next, uv_layer)
                        elif mode in {"FACE", "ISLAND"} or htype in {"FACE", "ISLAND"}:
                            if not _pt_close(l_uv, hit_uv):
                                continue
                            for fl in f.loops:
                                _add_record(records, seen, fl, uv_layer)
                            if mode != "ISLAND" and htype != "ISLAND":
                                break
                        else:
                            if _pt_close(l_uv, hit_uv):
                                _add_record(records, seen, l, uv_layer)
                    except Exception:
                        continue
            if not records:
                return []
            return [{"obj": obj, "mesh": mesh, "uv_layer_name": str(getattr(uv_layer, "name", "") or ""), "records": records, "refs": []}]
        face = bm.faces[fi]
        loops = tuple(face.loops)
        if not loops:
            return []
        li = max(0, min(li, len(loops) - 1))
        loop = loops[li]
        if mode == "EDGE" or htype == "EDGE":
            edge_index = int(hit.get("_sus18112_edge_index", getattr(loop.edge, "index", -1)))
            ea = hit.get("_sus18112_edge_a") or _uv_vec2(loop, uv_layer)
            eb = hit.get("_sus18112_edge_b") or _uv_vec2(loop.link_loop_next, uv_layer)
            for f in bm.faces:
                if getattr(f, "hide", False):
                    continue
                for l in f.loops:
                    try:
                        if int(getattr(l.edge, "index", -2)) != edge_index:
                            continue
                        if not _seg_close(_uv_vec2(l, uv_layer), _uv_vec2(l.link_loop_next, uv_layer), ea, eb):
                            continue
                        _add_record(records, seen, l, uv_layer)
                        _add_record(records, seen, l.link_loop_next, uv_layer)
                    except Exception:
                        continue
        elif mode in {"FACE", "ISLAND"} or htype in {"FACE", "ISLAND"}:
            faces = {face}
            if mode == "ISLAND" or htype == "ISLAND":
                try:
                    faces = set(ri._linked_faces({face}, uv_layer))
                except Exception:
                    faces = {face}
            for f in faces:
                if getattr(f, "hide", False):
                    continue
                for l in f.loops:
                    _add_record(records, seen, l, uv_layer)
        else:
            vert_index = int(hit.get("_sus18112_vert_index", getattr(loop.vert, "index", -1)))
            target_uv = hit.get("_sus18112_uv") or _uv_vec2(loop, uv_layer)
            for f in bm.faces:
                if getattr(f, "hide", False):
                    continue
                for l in f.loops:
                    try:
                        if int(getattr(l.vert, "index", -2)) == vert_index and _pt_close(_uv_vec2(l, uv_layer), target_uv):
                            _add_record(records, seen, l, uv_layer)
                    except Exception:
                        continue
        if not records:
            return []
        return [{"obj": obj, "mesh": mesh, "uv_layer_name": str(getattr(uv_layer, "name", "") or ""), "records": records, "refs": []}]
    except Exception:
        return []


def _set_uv_selection_18193(loop: Any, uv_layer: Any, mode: str, sync: bool, value: bool) -> None:
    mode = _s(mode or "VERTEX").upper()
    value = bool(value)
    if sync:
        try:
            if mode == "EDGE":
                loop.edge.select_set(value)
            elif mode == "FACE":
                loop.face.select_set(value)
            else:
                loop.vert.select_set(value)
        except Exception:
            pass
        return
    try:
        if mode == "EDGE":
            setattr(loop, "uv_select_edge", value)
        elif mode == "FACE":
            setattr(loop.face, "uv_select", value)
        else:
            setattr(loop, "uv_select_vert", value)
    except Exception:
        pass
    try:
        luv = loop[uv_layer]
        if mode == "EDGE":
            setattr(luv, "select_edge", value)
        elif mode == "VERTEX":
            setattr(luv, "select", value)
    except Exception:
        pass


def _clear_uv_selection_18193(context: Any, mode: str, sync: bool) -> None:
    for _obj, bm, uv_layer in _edit_targets(context):
        try:
            for face in bm.faces:
                try:
                    if sync and mode == "FACE":
                        face.select_set(False)
                    setattr(face, "uv_select", False)
                except Exception:
                    pass
                for loop in face.loops:
                    if sync:
                        try:
                            loop.vert.select_set(False)
                        except Exception:
                            pass
                        try:
                            loop.edge.select_set(False)
                        except Exception:
                            pass
                    _set_uv_selection_18193(loop, uv_layer, "VERTEX", False, False)
                    _set_uv_selection_18193(loop, uv_layer, "EDGE", False, False)
        except Exception:
            continue


def _ensure_hit_selected_18193(context: Any, hit: Dict[str, Any], event: Any, was_selected: bool) -> bool:
    stable = _stable_batch_from_hit(context, hit)
    if not stable:
        return True
    mode = _s(hit.get("_sus18112_mode") or hit.get("type") or ri._uv_mode(context)).upper()
    if mode not in {"VERTEX", "EDGE", "FACE", "ISLAND"}:
        mode = ri._uv_mode(context)
    if mode == "ISLAND":
        mode = "FACE"
    sync = bool(getattr(getattr(context, "tool_settings", None), "use_uv_select_sync", False))
    shift = bool(getattr(event, "shift", False))
    ctrl = bool(getattr(event, "ctrl", False))
    if not shift and not ctrl:
        _clear_uv_selection_18193(context, mode, sync)
        target_value = True
    elif ctrl:
        # Match Blender's unmodified subtract semantics for the public
        # Immediate Select contract: Ctrl always removes the hit component from
        # the current UV selection.  Earlier helper layers toggled selected
        # hits off but toggled unselected hits on; keep this final authority
        # subtract-only so a held Ctrl gesture can continue with the remaining
        # selected set.
        target_value = False
    else:
        target_value = True
    touched: List[Any] = []
    for batch in stable:
        try:
            import bmesh
            mesh = batch.get("mesh") or getattr(batch.get("obj"), "data", None)
            if mesh is None:
                continue
            bm = bmesh.from_edit_mesh(mesh)
            ri._ensure_lookup(bm)
            uv_name = _s(batch.get("uv_layer_name") or hit.get("_sus18112_uv_layer_name") or "")
            uv_layer = bm.loops.layers.uv.get(uv_name) if uv_name else None
            if uv_layer is None:
                uv_layer = ri._uv_layer(bm)
            if uv_layer is None:
                continue
            for fi, li, _uv in batch.get("records") or ():
                try:
                    face = bm.faces[int(fi)]
                    loops = tuple(face.loops)
                    if not loops:
                        continue
                    loop = loops[max(0, min(int(li), len(loops) - 1))]
                    _set_uv_selection_18193(loop, uv_layer, mode, sync, target_value)
                except Exception:
                    continue
            touched.append(mesh)
        except Exception:
            continue
    for mesh in touched:
        try:
            import bmesh
            bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        except Exception:
            pass
    return True


def _target_loops_from_hit(hit: Dict[str, Any]) -> List[Tuple[Any, Any, Any]]:
    out: List[Tuple[Any, Any, Any]] = []
    seen: Set[int] = set()
    try:
        obj = hit.get("obj") or None
        uv_layer = hit.get("uv_layer")
        loops = set(hit.get("target_loops") or [])
        edges = set(hit.get("target_edges") or [])
        faces = set(hit.get("target_faces") or [])
        if not loops and not edges and not faces:
            tl, te, tf = ri._target_from_hit(hit, uv_layer)
            loops, edges, faces = set(tl or []), set(te or []), set(tf or [])
        for loop in list(edges):
            try:
                loops.add(loop)
                loops.add(loop.link_loop_next)
            except Exception:
                pass
        for face in list(faces):
            try:
                for loop in face.loops:
                    loops.add(loop)
            except Exception:
                pass
        for loop in loops:
            if loop is None:
                continue
            try:
                key = int(loop.index)
            except Exception:
                key = id(loop)
            # Loop indices are local to a mesh. Include layer/object identity to
            # avoid accidental deduplication across multi-object edit mode.
            try:
                key = hash((key, id(uv_layer), id(obj)))
            except Exception:
                key = id(loop)
            if key in seen:
                continue
            seen.add(key)
            out.append((obj, loop, uv_layer))
    except Exception:
        pass
    return out


def _loops_for_selected_mode(context: Any, obj: Any, bm: Any, uv_layer: Any, mode: str) -> List[Any]:
    loops_out: List[Any] = []
    seen: Set[int] = set()

    def add(loop: Any) -> None:
        if loop is None:
            return
        try:
            key = int(loop.index)
        except Exception:
            key = id(loop)
        if key in seen:
            return
        seen.add(key)
        loops_out.append(loop)

    try:
        loops, edge_loops, faces = ri._selected_sets(context, obj, bm, uv_layer, mode)
    except Exception:
        loops, edge_loops, faces = set(), set(), set()
    if mode == "FACE":
        for face in list(faces or []):
            try:
                for loop in face.loops:
                    add(loop)
            except Exception:
                pass
        for loop in list(loops or []):
            add(loop)
        for loop in list(edge_loops or []):
            add(loop)
            try:
                add(loop.link_loop_next)
            except Exception:
                pass
    elif mode == "EDGE":
        for loop in list(edge_loops or []):
            add(loop)
            try:
                add(loop.link_loop_next)
            except Exception:
                pass
        for loop in list(loops or []):
            add(loop)
    else:
        for loop in list(loops or []):
            add(loop)
        for loop in list(edge_loops or []):
            add(loop)
            try:
                add(loop.link_loop_next)
            except Exception:
                pass
    return loops_out


def _collect_selected_batches(context: Any, hit: Optional[Dict[str, Any]] = None, hit_only: bool = False) -> List[Dict[str, Any]]:
    targets = _edit_targets(context)
    mode = ri._uv_mode(context)
    by_mesh: Dict[int, Dict[str, Any]] = {}

    def mesh_key(obj: Any) -> int:
        mesh = getattr(obj, "data", None)
        try:
            return int(mesh.as_pointer())
        except Exception:
            return id(mesh)

    def add_ref(obj: Any, loop: Any, uv_layer: Any) -> None:
        if obj is None or loop is None or uv_layer is None:
            return
        key = mesh_key(obj)
        rec = by_mesh.get(key)
        if rec is None:
            rec = {"obj": obj, "mesh": getattr(obj, "data", None), "uv_layer_name": str(getattr(uv_layer, "name", "") or ""), "refs": [], "records": [], "seen": set()}
            by_mesh[key] = rec
        seen = rec["seen"]
        try:
            lkey = int(loop.index)
        except Exception:
            lkey = id(loop)
        try:
            lkey = hash((lkey, id(uv_layer)))
        except Exception:
            pass
        if lkey in seen:
            return
        seen.add(lkey)
        try:
            uv = loop[uv_layer].uv.copy()
        except Exception:
            return
        stable_rec = _loop_record(loop, uv_layer)
        if stable_rec is not None:
            rec["records"].append(stable_rec)
        rec["refs"].append((loop, uv_layer, uv))

    if hit_only and hit is not None:
        stable = _stable_batch_from_hit(context, hit)
        if stable:
            return stable
        for obj, loop, uv_layer in _target_loops_from_hit(hit):
            if obj is None:
                obj = hit.get("obj")
            add_ref(obj, loop, uv_layer)
    else:
        for obj, bm, uv_layer in targets:
            try:
                for loop in _loops_for_selected_mode(context, obj, bm, uv_layer, mode):
                    add_ref(obj, loop, uv_layer)
            except Exception:
                continue
        if not any(rec.get("refs") for rec in by_mesh.values()) and hit is not None:
            for obj, loop, uv_layer in _target_loops_from_hit(hit):
                if obj is None:
                    obj = hit.get("obj")
                add_ref(obj, loop, uv_layer)

    batches: List[Dict[str, Any]] = []
    for rec in by_mesh.values():
        if rec.get("refs"):
            rec.pop("seen", None)
            batches.append(rec)
    return batches


def _apply_axis_snap(ns: Dict[str, Any], context: Any, delta: Vector) -> Vector:
    out = Vector((float(delta.x), float(delta.y)))
    try:
        fn = ns.get("_sus_1674_snap_delta") if isinstance(ns, dict) else None
        if callable(fn):
            v = fn(context, out.copy())
            if v is not None:
                out = Vector((float(v[0]), float(v[1])))
    except Exception:
        pass
    try:
        fn = ns.get("_sus_1674_apply_axis_memory") if isinstance(ns, dict) else None
        if callable(fn):
            v = fn(context, out.copy())
            if v is not None:
                out = Vector((float(v[0]), float(v[1])))
    except Exception:
        pass
    return out


def _apply_delta(self: Any, context: Any, delta: Vector) -> bool:
    try:
        batches = list(getattr(self, "_sus18112_batches", []) or [])
    except Exception:
        batches = []
    if not batches:
        return False
    key = (round(float(delta.x), 9), round(float(delta.y), 9))
    if getattr(self, "_sus18112_last_delta", None) == key:
        return True
    try:
        self._sus18112_last_delta = key
    except Exception:
        pass
    changed = False
    changed_objs = []
    try:
        import bmesh
    except Exception:
        bmesh = None
    for batch in batches:
        records = list(batch.get("records", []) or []) if isinstance(batch, dict) else []
        if records and bmesh is not None:
            mesh = batch.get("mesh")
            try:
                bm = bmesh.from_edit_mesh(mesh)
                ri._ensure_lookup(bm)
                uv_name = _s(batch.get("uv_layer_name") or "")
                uv_layer = bm.loops.layers.uv.get(uv_name) if uv_name else None
                if uv_layer is None:
                    uv_layer = ri._uv_layer(bm)
            except Exception:
                uv_layer = None
            if uv_layer is not None:
                for fi, li, start_uv in records:
                    try:
                        face = bm.faces[int(fi)]
                        loops = tuple(face.loops)
                        idx = int(li)
                        if idx < 0 or idx >= len(loops):
                            continue
                        loops[idx][uv_layer].uv = start_uv + delta
                        changed = True
                    except Exception:
                        continue
                if changed and batch.get("obj") is not None:
                    changed_objs.append(batch.get("obj"))
                continue
        for loop, uv_layer, start_uv in list(batch.get("refs", []) or []):
            try:
                loop[uv_layer].uv = start_uv + delta
                changed = True
            except Exception:
                pass
        if changed and isinstance(batch, dict) and batch.get("obj") is not None:
            changed_objs.append(batch.get("obj"))
    if changed:
        try:
            targets = [(obj, None, None) for obj in changed_objs if obj is not None]
            _update_meshes(targets)
        except Exception:
            pass
        try:
            area = getattr(context, "area", None)
            if area is not None:
                area.tag_redraw()
        except Exception:
            pass
    return changed


def _restore_original(self: Any, context: Any) -> None:
    try:
        batches = list(getattr(self, "_sus18112_batches", []) or [])
    except Exception:
        batches = []
    changed = False
    changed_objs = []
    try:
        import bmesh
    except Exception:
        bmesh = None
    for batch in batches:
        records = list(batch.get("records", []) or []) if isinstance(batch, dict) else []
        if records and bmesh is not None:
            mesh = batch.get("mesh")
            try:
                bm = bmesh.from_edit_mesh(mesh)
                ri._ensure_lookup(bm)
                uv_name = _s(batch.get("uv_layer_name") or "")
                uv_layer = bm.loops.layers.uv.get(uv_name) if uv_name else None
                if uv_layer is None:
                    uv_layer = ri._uv_layer(bm)
            except Exception:
                uv_layer = None
            if uv_layer is not None:
                for fi, li, start_uv in records:
                    try:
                        face = bm.faces[int(fi)]
                        loops = tuple(face.loops)
                        idx = int(li)
                        if idx < 0 or idx >= len(loops):
                            continue
                        loops[idx][uv_layer].uv = start_uv.copy()
                        changed = True
                    except Exception:
                        continue
                if changed and batch.get("obj") is not None:
                    changed_objs.append(batch.get("obj"))
                continue
        for loop, uv_layer, start_uv in list(batch.get("refs", []) or []):
            try:
                loop[uv_layer].uv = start_uv.copy()
                changed = True
            except Exception:
                pass
        if changed and isinstance(batch, dict) and batch.get("obj") is not None:
            changed_objs.append(batch.get("obj"))
    if changed:
        try:
            targets = [(obj, None, None) for obj in changed_objs if obj is not None]
            _update_meshes(targets)
        except Exception:
            pass


def _sus18229_notify_uv_selection_changed(context: Any, uv: Any) -> bool:
    """U2: emit the native selection-change notifier after direct flag writes.

    Every live press-select path writes bmesh UV selection flags directly and
    then calls ``bmesh.update_edit_mesh``; that redraws the editor but never
    emits the selection-change notification the Image editor's 2D transform
    gizmo re-anchors on, so the gizmo stayed on the OLD pivot after a click
    until some native operator ran.  An idempotent ``extend`` re-select of the
    already-selected element at the hit location is the cheapest native
    notifier source and cannot lose the flag-written selection.
    """
    pair = _uv_pair_18193(uv)
    if pair is None:
        return False
    try:
        result = bpy.ops.uv.select(
            "EXEC_DEFAULT",
            extend=True,
            deselect=False,
            toggle=False,
            deselect_all=False,
            select_passthrough=False,
            location=(float(pair[0]), float(pair[1])),
        )
        return "FINISHED" in set(result or ())
    except Exception:
        return False


def _sus18229_notify_release_reanchor(self: Any, context: Any, dragged: bool) -> None:
    """Belt-and-braces gizmo re-anchor on LMB release.

    After a committed direct drag the selection is unchanged but its pivot
    moved; re-select at the element's NEW location (press UV plus the applied
    delta) so the gizmo follows.  Skipped for subtract gestures, where an
    extend re-select would undo the deselection."""
    try:
        if not bool(getattr(self, "_sus18229_notify_ok", False)):
            return
        pair = _uv_pair_18193(getattr(self, "_sus18229_hit_uv", None))
        if pair is None:
            return
        if dragged:
            delta = getattr(self, "_sus18112_last_delta", None)
            if isinstance(delta, tuple) and len(delta) >= 2:
                pair = (float(pair[0]) + float(delta[0]), float(pair[1]) + float(delta[1]))
        _sus18229_notify_uv_selection_changed(context, pair)
    except Exception:
        pass


def _sus18229_record_axis_after_drag(context: Any) -> None:
    """U3: re-stamp the axis actually applied by a committed instant drag.

    The apply chain reads the remembered axis; recording it back on release
    refreshes interaction_1845's TTL stamp (so stale wm.operators history
    cannot immediately overwrite a fresh gesture) and keeps the 18228
    per-window X/Y/NONE cache in agreement with the package U/V/FREE cache.
    """
    try:
        ns = _NS if isinstance(_NS, dict) else {}
        enabled_fn = ns.get("_sus_1636_axis_memory_enabled")
        if not (callable(enabled_fn) and enabled_fn(context)):
            return
        get_fn = ns.get("_sus_1636_get_axis")
        axis = str(get_fn(context) if callable(get_fn) else "FREE").upper()
        if axis not in {"U", "V", "FREE"}:
            axis = "FREE"
        try:
            from . import interaction_1845 as _i1845
            _i1845._set_axis(axis, context)
        except Exception:
            pass
        try:
            from . import smartuv_operation_runtime_18228 as _rt18228
            _rt18228._set_axis(context, {"U": "X", "V": "Y", "FREE": "NONE"}[axis])
        except Exception:
            pass
    except Exception:
        pass


def _modal_instant_18112(self: Any, context: Any, event: Any):
    try:
        etype = _s(getattr(event, "type", ""))
        evalue = _s(getattr(event, "value", ""))
        if etype in {"ESC", "RIGHTMOUSE"}:
            fallback_restored = _restore_direct_drag_fallback(self, context)
            _record_gesture(
                self,
                "cancel",
                "CANCELLED",
                "user_cancel",
                event,
                transaction_snapshot=_transaction_snapshot_present(self),
                fallback_restored=fallback_restored,
            )
            return {"CANCELLED"}
        if etype == "LEFTMOUSE" and evalue == "RELEASE":
            dragged = bool(getattr(self, "_sus18112_dragging", False))
            if dragged:
                _sus18229_record_axis_after_drag(context)
            _sus18229_notify_release_reanchor(self, context, dragged)
            _record_gesture(
                self,
                "release",
                "FINISHED",
                "drag_committed" if dragged else "selection_only_committed",
                event,
            )
            return {"FINISHED"}
        if etype not in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
            return {"RUNNING_MODAL"}
        sx, sy = getattr(self, "_sus18112_start_xy", (0, 0))
        mx, my = _event_xy(event)
        dx, dy = int(mx) - int(sx), int(my) - int(sy)
        threshold = max(1, int(getattr(self, "_sus18178_drag_threshold_px", 3) or 3))
        if dx * dx + dy * dy < threshold * threshold:
            _record_gesture(
                self,
                "threshold",
                "RUNNING_MODAL",
                "below_drag_threshold",
                event,
                threshold_px=threshold,
            )
            return {"RUNNING_MODAL"}
        start_uv = getattr(self, "_sus18112_start_uv", None)
        current_uv = _region_to_uv_vec(context, (mx, my))
        if start_uv is None or current_uv is None:
            fallback_restored = _restore_direct_drag_fallback(self, context)
            _record_gesture(
                self,
                "drag",
                "CANCELLED",
                "uv_coordinate_unavailable",
                event,
                transaction_snapshot=_transaction_snapshot_present(self),
                fallback_restored=fallback_restored,
            )
            return {"CANCELLED"}
        delta = current_uv - start_uv
        ns = getattr(self, "_sus18112_ns", None) or _NS
        delta = _apply_axis_snap(ns if isinstance(ns, dict) else {}, context, delta)
        applied = bool(_apply_delta(self, context, delta))
        if not applied:
            fallback_restored = _restore_direct_drag_fallback(self, context)
            _record_gesture(
                self,
                "drag",
                "CANCELLED",
                "uv_apply_failed",
                event,
                transaction_snapshot=_transaction_snapshot_present(self),
                fallback_restored=fallback_restored,
            )
            return {"CANCELLED"}
        try:
            self._sus18112_dragging = True
        except Exception:
            pass
        _record_gesture(
            self,
            "drag",
            "RUNNING_MODAL",
            "uv_apply_succeeded",
            event,
            threshold_px=threshold,
            delta_u=float(delta.x),
            delta_v=float(delta.y),
        )
        return {"RUNNING_MODAL"}
    except Exception as exc:
        fallback_restored = _restore_direct_drag_fallback(self, context)
        _record_gesture(
            self,
            "modal_exception",
            "CANCELLED",
            "modal_exception",
            event,
            transaction_snapshot=_transaction_snapshot_present(self),
            fallback_restored=fallback_restored,
            exception_type=type(exc).__name__,
        )
        return {"CANCELLED"}


def _invoke_instant_18112(self: Any, context: Any, event: Any):
    try:
        self._sus18112_batches = []
        self._sus18112_dragging = False
        self._sus18112_last_delta = None
        self._sus18229_hit_uv = None
        self._sus18229_notify_ok = False
        self._sus18112_ns = _NS
        threshold, threshold_source = _configured_drag_threshold(context, event)
        self._sus18178_drag_threshold_px = threshold
        self._sus18178_drag_threshold_source = threshold_source
        etype = _s(getattr(event, "type", ""))
        evalue = _s(getattr(event, "value", ""))
        if etype != "LEFTMOUSE" or evalue not in {"PRESS", "CLICK_DRAG"}:
            _record_gesture(self, "invoke", "PASS_THROUGH", "unsupported_event", event)
            return {"PASS_THROUGH"}
        if not _instant_enabled(context):
            _record_gesture(self, "invoke", "PASS_THROUGH", "feature_disabled", event)
            return {"PASS_THROUGH"}
        if not _uv_context(context):
            _record_gesture(self, "invoke", "PASS_THROUGH", "not_uv_editor", event)
            return {"PASS_THROUGH"}
        if bool(getattr(event, "alt", False) or getattr(event, "oskey", False) or getattr(event, "hyper", False)):
            _record_gesture(self, "invoke", "PASS_THROUGH", "native_modifier", event)
            return {"PASS_THROUGH"}
        if _native_tool_should_pass(context):
            _record_gesture(self, "invoke", "PASS_THROUGH", "native_tool_priority", event)
            return {"PASS_THROUGH"}

        hit = _find_hit(context, event)
        if not hit:
            _record_gesture(self, "invoke", "PASS_THROUGH", "background_native", event)
            return {"PASS_THROUGH"}
        was_selected = _hit_selected(context, hit)
        if was_selected and _gizmo_should_own_press(self, context, event):
            _record_gesture(self, "invoke", "PASS_THROUGH", "gizmo_handle_priority", event)
            return {"PASS_THROUGH"}
        shift = bool(getattr(event, "shift", False))
        ctrl = bool(getattr(event, "ctrl", False))
        hit_only = False
        selection_applied = False
        if was_selected and not ctrl:
            # Selected hit: keep the current UV selection and let the held click
            # drag that selection directly.  Do not pass through to the old
            # native-transform path, because that was the unstable route.
            hit_only = False
        else:
            if not _select_hit(context, hit, event):
                _record_gesture(
                    self,
                    "select",
                    "CANCELLED",
                    "selection_apply_failed",
                    event,
                    transaction_snapshot=_transaction_snapshot_present(self),
                )
                return {"CANCELLED"}
            if not _ensure_hit_selected_18193(context, hit, event, was_selected):
                _record_gesture(
                    self,
                    "select",
                    "CANCELLED",
                    "selection_readback_failed",
                    event,
                    transaction_snapshot=_transaction_snapshot_present(self),
                )
                return {"CANCELLED"}
            selection_applied = True
            # Plain click on another element replaces the selection, so moving
            # the just-hit target is both faster and avoids stale all-select data.
            hit_only = not bool(shift or ctrl)
        # U2: the direct flag writes above never emit a selection-change
        # notifier, so the transform gizmo stays anchored on the old pivot.
        # Re-select the (already selected) hit element through the native
        # operator so the gizmo snaps to the new selection at press time.
        hit_uv = _uv_pair_18193(hit.get("_sus18112_uv")) or _uv_pair_18193(hit.get("uv"))
        try:
            self._sus18229_hit_uv = hit_uv
            self._sus18229_notify_ok = not ctrl
        except Exception:
            pass
        if not ctrl:
            _sus18229_notify_uv_selection_changed(context, hit_uv)
        batches = _collect_selected_batches(context, hit=hit, hit_only=hit_only)
        if not batches:
            if selection_applied:
                _record_gesture(
                    self,
                    "select",
                    "FINISHED",
                    "selection_only_no_transform_targets",
                    event,
                    transaction_snapshot=_transaction_snapshot_present(self),
                )
                return {"FINISHED"}
            _record_gesture(
                self,
                "prepare",
                "CANCELLED",
                "no_transform_targets",
                event,
                transaction_snapshot=_transaction_snapshot_present(self),
            )
            return {"CANCELLED"}
        start_xy = _event_xy(event)
        start_uv = _region_to_uv_vec(context, start_xy)
        if start_uv is None:
            _record_gesture(
                self,
                "prepare",
                "CANCELLED",
                "start_uv_unavailable",
                event,
                transaction_snapshot=_transaction_snapshot_present(self),
            )
            return {"CANCELLED"}
        self._sus18112_batches = batches
        self._sus18112_start_xy = start_xy
        self._sus18112_start_uv = start_uv
        _record_gesture(
            self,
            "press",
            "RUNNING_MODAL",
            "selected_hit_ready" if was_selected else "selection_changed_ready",
            event,
            threshold_px=threshold,
            threshold_source=threshold_source,
            snapshot_captured=_transaction_snapshot_present(self),
            batch_count=len(batches),
        )
        if evalue == "CLICK_DRAG":
            # Keymap rows normally use PRESS.  This branch keeps old user keymap
            # rows safe if they still dispatch CLICK_DRAG after an update.
            try:
                context.window_manager.modal_handler_add(self)
            except Exception as exc:
                _record_gesture(
                    self,
                    "prepare",
                    "CANCELLED",
                    "modal_handler_failed",
                    event,
                    transaction_snapshot=_transaction_snapshot_present(self),
                    exception_type=type(exc).__name__,
                )
                return {"CANCELLED"}
            return _modal_instant_18112(self, context, event)
        try:
            context.window_manager.modal_handler_add(self)
            return {"RUNNING_MODAL"}
        except Exception as exc:
            _record_gesture(
                self,
                "prepare",
                "CANCELLED",
                "modal_handler_failed",
                event,
                transaction_snapshot=_transaction_snapshot_present(self),
                exception_type=type(exc).__name__,
            )
            return {"CANCELLED"}
    except Exception as exc:
        _record_gesture(
            self,
            "invoke_exception",
            "CANCELLED",
            "invoke_exception",
            event,
            transaction_snapshot=_transaction_snapshot_present(self),
            exception_type=type(exc).__name__,
        )
        return {"CANCELLED"}


def _addon_keyconfig() -> Any:
    try:
        return bpy.context.window_manager.keyconfigs.addon
    except Exception:
        return None


def _iter_keyconfigs() -> Iterable[Any]:
    try:
        wm = getattr(bpy.context, "window_manager", None)
        kc = getattr(getattr(wm, "keyconfigs", None), "addon", None)
        return (kc,) if kc is not None else ()
    except Exception:
        return ()


def _find_kmis(km: Any, idname: str) -> List[Any]:
    try:
        from . import ownership_runtime_18168 as _ownership
        return [kmi for keymap, kmi in _ownership.owned_keymap_items(idname) if keymap is km]
    except Exception:
        return []


def _remove_keymap_rows(idnames: Iterable[str], names: Optional[Iterable[str]] = None) -> int:
    del names
    removed = 0
    try:
        from . import ownership_runtime_18168 as _ownership
        for idname in tuple(idnames or ()):
            removed += _ownership.remove_owned_keymaps(str(idname))
    except Exception:
        pass
    return removed


def _actual_instant_keymap_rows() -> Tuple[Tuple[Any, Any], ...]:
    """Return live addon-keyconfig rows for the exact Immediate Select id.

    Failed install-over-active attempts can leave native rows in
    ``wm.keyconfigs.addon`` after their generation ledger has already been
    discarded.  They are not user keymap customizations: the user keyconfig is
    intentionally never scanned here.
    """
    keyconfig = _addon_keyconfig()
    keymaps = getattr(keyconfig, "keymaps", None) if keyconfig is not None else None
    if keymaps is None:
        return ()
    rows: List[Tuple[Any, Any]] = []
    try:
        for keymap in tuple(keymaps):
            for kmi in _iter_keymap_items(keymap):
                try:
                    if _s(getattr(kmi, "idname", "")) == _INSTANT_ID:
                        rows.append((keymap, kmi))
                except Exception:
                    continue
    except Exception:
        return ()
    return tuple(rows)


def _purge_unledgered_instant_keymap_rows(owned_rows: Iterable[Tuple[Any, Any]] = ()) -> int:
    """Remove only stale addon-keyconfig rows absent from this generation.

    Blender preserves addon-keyconfig rows across some interrupted upgrades.
    The authoritative Smart UV ledger then owns the replacement 20 rows while
    the live addon keyconfig contains both generations, which caused the exact
    ``ledger pointers do not match`` registration failure.  Pointer matching is
    used because Blender may return a fresh Python wrapper for the same KMI.
    """
    owned_pointers: Set[int] = set()
    for _keymap, kmi in tuple(owned_rows or ()):
        try:
            owned_pointers.add(_kmi_pointer(kmi))
        except Exception:
            continue
    removed = 0
    for keymap, kmi in reversed(_actual_instant_keymap_rows()):
        try:
            pointer = _kmi_pointer(kmi)
        except Exception:
            pointer = None
        if pointer is not None and pointer in owned_pointers:
            continue
        try:
            _raw_remove_kmi(keymap, kmi)
            removed += 1
        except Exception:
            continue
    return removed


def _ensure_keymap(kc: Any, name: str, space_type: str) -> Any:
    try:
        km = kc.keymaps.get(name)
        if km is None:
            km = kc.keymaps.new(name=name, space_type=space_type, region_type="WINDOW")
        if (
            _s(getattr(km, "name", "")) != _s(name)
            or _s(getattr(km, "space_type", "")) != _s(space_type)
            or _s(getattr(km, "region_type", "")) != "WINDOW"
            or bool(getattr(km, "is_modal", False))
        ):
            return None
        return km
    except Exception:
        return None


def _keymap_identity_matches(km: Any, name: str, space_type: str) -> bool:
    try:
        return (
            _s(getattr(km, "name", "")) == _s(name)
            and _s(getattr(km, "space_type", "")) == _s(space_type)
            and _s(getattr(km, "region_type", "")) == "WINDOW"
            and not bool(getattr(km, "is_modal", False))
        )
    except Exception:
        return False


def _kmi_pointer(kmi: Any) -> int:
    try:
        pointer = int(kmi.as_pointer())
    except Exception as exc:
        raise RuntimeError("Smart UV keymap row has no stable RNA pointer") from exc
    if not pointer:
        raise RuntimeError("Smart UV keymap row has a null RNA pointer")
    return pointer


def _iter_keymap_items(km: Any) -> Tuple[Any, ...]:
    try:
        return tuple(getattr(km, "keymap_items", ()) or ())
    except Exception:
        return ()


def _find_kmi_by_pointer(km: Any, pointer: int) -> Any:
    for item in _iter_keymap_items(km):
        try:
            if int(item.as_pointer()) == int(pointer):
                return item
        except Exception:
            continue
    return None


def _raw_remove_kmi(km: Any, kmi: Any) -> None:
    try:
        pointer = _kmi_pointer(kmi)
    except Exception:
        pointer = None
    live = _find_kmi_by_pointer(km, pointer) if pointer else kmi
    if live is None:
        return
    try:
        getattr(km, "keymap_items").remove(live)
    except ReferenceError:
        pass


def _raw_remove_kmis(rows: Iterable[Tuple[Any, Any]]) -> None:
    for km, kmi in reversed(tuple(rows or ())):
        try:
            _raw_remove_kmi(km, kmi)
        except Exception:
            pass


def _kmi_expected_signature(*, shift: bool, ctrl: bool, active: bool = True) -> Dict[str, Any]:
    return {
        "type": "LEFTMOUSE",
        "value": "PRESS",
        "shift": bool(shift),
        "ctrl": bool(ctrl),
        "alt": False,
        "oskey": False,
        "any": False,
        "active": bool(active),
    }


def _kmi_signature(kmi: Any) -> Dict[str, Any]:
    return {
        "type": _s(getattr(kmi, "type", "")),
        "value": _s(getattr(kmi, "value", "")),
        "shift": bool(getattr(kmi, "shift", False)),
        "ctrl": bool(getattr(kmi, "ctrl", False)),
        "alt": bool(getattr(kmi, "alt", False)),
        "oskey": bool(getattr(kmi, "oskey", False)),
        "any": bool(getattr(kmi, "any", False)),
        "active": bool(getattr(kmi, "active", False)),
    }


def _configure_raw_kmi(kmi: Any, *, shift: bool, ctrl: bool, active: bool = True) -> None:
    expected = _kmi_expected_signature(shift=shift, ctrl=ctrl, active=active)
    # Blender 5.1 normalizes modifier flags when ``any`` is written.  It must be
    # set before shift/ctrl/alt/oskey, and type/value are already fixed by
    # keymap_items.new(idname, "LEFTMOUSE", "PRESS").
    for name, val in (
        ("any", False),
        ("shift", bool(shift)),
        ("ctrl", bool(ctrl)),
        ("alt", False),
        ("oskey", False),
        ("active", bool(active)),
    ):
        try:
            setattr(kmi, name, val)
        except Exception as exc:
            raise RuntimeError(f"Smart UV keymap RNA write failed: {name}") from exc
    actual = _kmi_signature(kmi)
    if actual != expected:
        raise RuntimeError(f"Smart UV keymap RNA readback mismatch: {actual!r} != {expected!r}")


def _create_exact_kmi(km: Any, *, map_name: str, shift: bool, ctrl: bool) -> Any:
    items = getattr(km, "keymap_items", None)
    native_new = getattr(items, "new", None)
    if not callable(native_new):
        raise RuntimeError(f"stage=create map={map_name} modifier={(shift, ctrl)!r}: keymap_items.new unavailable")
    try:
        # Keep creation on Blender's stable positional API.  Runtime reachability
        # is synchronized once per keymap transaction instead of relying on
        # undocumented ordering kwargs.
        row = native_new(_INSTANT_ID, "LEFTMOUSE", "PRESS")
    except Exception as exc:
        raise RuntimeError(f"stage=create map={map_name} modifier={(shift, ctrl)!r}: native new failed") from exc
    pointer = _kmi_pointer(row)
    try:
        _configure_raw_kmi(row, shift=shift, ctrl=ctrl, active=True)
        live = _find_kmi_by_pointer(km, pointer)
        if live is None:
            raise RuntimeError("collection readback missing")
        if _kmi_pointer(live) != pointer:
            raise RuntimeError("collection readback pointer mismatch")
        if _kmi_signature(live) != _kmi_expected_signature(shift=shift, ctrl=ctrl, active=True):
            raise RuntimeError(
                f"collection readback mismatch: {_kmi_signature(live)!r}"
            )
        return live
    except Exception as exc:
        _raw_remove_kmi(km, row)
        raise RuntimeError(f"stage=readback map={map_name} modifier={(shift, ctrl)!r}: {exc}") from exc


def _ensure_instant_keymaps(context: Any = None, active: Optional[bool] = None) -> None:
    ctx = _context_or_bpy(context)
    is_active = _instant_enabled(ctx) if active is None else bool(active)
    # Immediate Select owns only its own row.  The independently toggled gizmo
    # fallback must not disappear when this workspace property is synchronized.
    _remove_keymap_rows({_STICKY_PASS_ID})
    try:
        from . import ownership_runtime_18168 as _ownership
    except Exception:
        return
    if not is_active:
        _remove_keymap_rows({_INSTANT_ID})
        _purge_unledgered_instant_keymap_rows(())
        return
    kc = _addon_keyconfig()
    if kc is None:
        return
    allowed_names = {name for name, _space in _ALLOWED_INSTANT_MAPS}
    expected_spaces = {name: space for name, space in _ALLOWED_INSTANT_MAPS}
    existing_rows = tuple(_ownership.owned_keymap_items(_INSTANT_ID))
    _purge_unledgered_instant_keymap_rows(existing_rows)
    valid_rows: List[Tuple[Any, Any]] = []
    for km, row in existing_rows:
        map_name = _s(getattr(km, "name", ""))
        expected_space = expected_spaces.get(map_name)
        if expected_space is None or not _keymap_identity_matches(km, map_name, expected_space):
            # Do not read KeyMapItem.type/value while purging stale owned rows;
            # invalid enum values can warn during failed upgrade cleanup.
            try:
                _ownership.remove_keymap_item(km, row)
            except Exception:
                pass
            continue
        valid_rows.append((km, row))
    if len(valid_rows) == 20:
        try:
            expected_signatures = set(_INSTANT_MODIFIER_ROWS)
            signatures: Dict[str, Set[Tuple[bool, bool]]] = {}
            pointer_set: Set[int] = set()
            all_exact = True
            for km, row in valid_rows:
                map_name = _s(getattr(km, "name", ""))
                signatures.setdefault(map_name, set()).add(
                    (bool(getattr(row, "shift", False)), bool(getattr(row, "ctrl", False)))
                )
                pointer = _kmi_pointer(row)
                if pointer in pointer_set:
                    all_exact = False
                pointer_set.add(pointer)
                if _kmi_signature(row) != _kmi_expected_signature(
                    shift=bool(getattr(row, "shift", False)),
                    ctrl=bool(getattr(row, "ctrl", False)),
                    active=True,
                ):
                    all_exact = False
            if (
                all_exact
                and set(signatures) == allowed_names
                and all(value == expected_signatures for value in signatures.values())
            ):
                return
        except Exception:
            pass
    created: List[Tuple[Any, Any]] = []
    try:
        # Build the replacement set first, without committing it to the Smart UV
        # ownership ledger.  Blender RNA wrappers are not stable Python
        # identities across keymap collection reads, so the returned row and the
        # collection row must match by as_pointer() before commit.
        for name, space_type in _ALLOWED_INSTANT_MAPS:
            km = _ensure_keymap(kc, name, space_type)
            if km is None:
                raise RuntimeError(f"invalid Smart UV keymap identity: {name}")
            for shift, ctrl in _INSTANT_MODIFIER_ROWS:
                row = _create_exact_kmi(km, map_name=name, shift=shift, ctrl=ctrl)
                created.append((km, row))
        previous_rows = tuple(_ownership.owned_keymap_items(_INSTANT_ID))
        for km, row in created:
            _ownership.track_keymap_item(km, row, _INSTANT_ID)
        for km, row in previous_rows:
            _ownership.remove_keymap_item(km, row)
        audit_rows = tuple(_ownership.owned_keymap_items(_INSTANT_ID))
        signatures: Dict[str, Set[Tuple[bool, bool]]] = {}
        for km, row in audit_rows:
            map_name = _s(getattr(km, "name", ""))
            signatures.setdefault(map_name, set()).add(
                (bool(getattr(row, "shift", False)), bool(getattr(row, "ctrl", False)))
            )
        expected_signatures = set(_INSTANT_MODIFIER_ROWS)
        if (
            len(created) != 20
            or len(audit_rows) != 20
            or set(signatures) != allowed_names
            or any(value != expected_signatures for value in signatures.values())
            ):
            raise RuntimeError(
                f"Smart UV instant keymap final identity mismatch: {signatures!r}"
            )
    except Exception as exc:
        for km, row in created:
            try:
                _ownership.remove_keymap_item(km, row)
            except Exception:
                pass
        _raw_remove_kmis(created)
        raise RuntimeError("Smart UV instant keymap transaction failed") from exc
    for km, kmi in tuple(_ownership.owned_keymap_items(_INSTANT_ID)):
        if _s(getattr(km, 'name', '')) not in allowed_names:
            _ownership.remove_keymap_item(km, kmi)
    _purge_unledgered_instant_keymap_rows(
        tuple(_ownership.owned_keymap_items(_INSTANT_ID))
    )



def _set_instant_keymaps_active(active: bool) -> None:
    _ensure_instant_keymaps(bpy.context, active=bool(active))


def _delete_instant_keymaps() -> int:
    return _remove_keymap_rows({_INSTANT_ID})



def _disable_eager_hit_cache(package_globals: dict[str, Any] | None = None) -> None:
    """Disable legacy eager cache refresh and cancel exact owned callbacks."""
    global _CACHE_READY, _CACHE_BUILDING
    _CACHE_READY = False
    _CACHE_BUILDING = False
    if isinstance(package_globals, dict):
        for name in ('_sus_18100_refresh_cache_timer', '_refresh_cache_timer'):
            callback = package_globals.get(name)
            if callable(callback):
                _suv_resource.timer_unregister(callback)


def _patch_room_integrity() -> None:
    try:
        ri._TRANSFORM_TOOL_TOKENS = _REAL_TRANSFORM_TOOL_TOKENS  # type: ignore[attr-defined]
        ri._native_tool_should_pass = _native_tool_should_pass  # type: ignore[attr-defined]
        ri._ALLOWED_INSTANT_MAPS = _ALLOWED_INSTANT_MAPS  # type: ignore[attr-defined]
        ri._FORBIDDEN_MAPS = _FORBIDDEN_INSTANT_MAPS  # type: ignore[attr-defined]
        ri._ensure_instant_keymaps = lambda context=None: _ensure_instant_keymaps(context or bpy.context)  # type: ignore[attr-defined]
        ri._set_instant_keymaps_active = lambda active: _set_instant_keymaps_active(bool(active))  # type: ignore[attr-defined]
        ri._delete_instant_keymaps = _delete_instant_keymaps  # type: ignore[attr-defined]
    except Exception:
        pass


def _patch_operator(ns: Dict[str, Any]) -> bool:
    cls = ns.get("SMARTUVSUITE_OT_instant_select_drag_move") if isinstance(ns, dict) else None
    if not isinstance(cls, type):
        return False
    cur_invoke = getattr(cls, "invoke", None)
    cur_modal = getattr(cls, "modal", None)
    if callable(cur_invoke) and cur_invoke is not _invoke_instant_18112 and "invoke" not in _PREV:
        _PREV["invoke"] = cur_invoke
    if callable(cur_modal) and cur_modal is not _modal_instant_18112 and "modal" not in _PREV:
        _PREV["modal"] = cur_modal
    cls.bl_options = {'UNDO', 'BLOCKING'}
    _invoke_instant_18112._sus_18112_instant_drag = True  # type: ignore[attr-defined]
    _modal_instant_18112._sus_18112_instant_drag = True  # type: ignore[attr-defined]
    cls.invoke = _invoke_instant_18112
    cls.modal = _modal_instant_18112
    cls._find_uv_hit = lambda self, context, event: _find_hit(context, event)
    cls._sus18112_press_to_direct_drag = True
    return bool(cls.invoke is _invoke_instant_18112 and cls.modal is _modal_instant_18112)


def _patch_sync(ns: Dict[str, Any]) -> None:
    cur = ns.get("_sus_1652_sync_keymaps_from_workspace") if isinstance(ns, dict) else None
    if callable(cur) and not getattr(cur, "_sus_18112_sync", False):
        _PREV["sync"] = cur
    base = _PREV.get("sync")

    def _sync_18112(context: Any = None):
        ctx = context or getattr(bpy, "context", None)
        # Public setting changes are owned by the final registration manifest.
        # Never reinstall the direct methods here: doing so can peel the
        # transaction wrapper after registration or after a failed keymap sync.
        from . import registration_manifest_18168 as _manifest
        return _manifest.synchronize_interaction_runtime(
            context=ctx,
            reason="legacy_sync_bridge",
        )

    try:
        _sync_18112._sus_18112_sync = True  # type: ignore[attr-defined]
    except Exception:
        pass
    try:
        ns["_sus_1652_sync_keymaps_from_workspace"] = _sync_18112
        ns["_sus_1652_ensure_instant_keymaps"] = lambda context=None: _ensure_instant_keymaps(context or bpy.context)
        ns["_sus_1652_promote_instant_keymaps_to_head"] = lambda active=True, context=None: _ensure_instant_keymaps(context or bpy.context, active=bool(active))
        ns["_sus_1652_set_instant_keymaps_active"] = lambda active: _set_instant_keymaps_active(bool(active))
        ns["_sus_1652_delete_instant_keymaps"] = _delete_instant_keymaps
    except Exception:
        pass


def _mark_version(ns: Dict[str, Any]) -> None:
    try:
        info = ns.get("bl_info")
        if not isinstance(info, dict):
            info = {}
            ns["bl_info"] = info
        info.update({
            "name": "Smart UV Suite",
            "author": "JELararagi",
            "version": (1, 0, 0),
            "blender": (5, 1, 0),
            "location": "View3D / UV Editor > Sidebar > Smart UV",
            "description": "Smart UV Suite exposes UV editing tools in the Smart UV sidebar.",
            "category": "Smart UV",
        })
        ns["_SUS_BL_INFO_FALLBACK"] = dict(info)
        ns["__version__"] = '1.0.0'
    except Exception:
        pass


def apply_all(ns: Optional[Dict[str, Any]] = None, context: Any = None) -> None:
    global _NS
    if isinstance(ns, dict):
        _NS = ns
    elif not _NS:
        import sys
        mod = sys.modules.get(__package__)
        if mod is not None:
            _NS = getattr(mod, "__dict__", {})
    target = _NS if isinstance(_NS, dict) else {}
    if not target:
        return
    _disable_eager_hit_cache()
    _patch_room_integrity()
    _patch_operator(target)
    _patch_sync(target)
    _mark_version(target)


def install(ns: Optional[Dict[str, Any]] = None, context: Any = None) -> None:
    apply_all(ns, context or getattr(bpy, "context", None))


def unregister() -> None:
    try:
        _remove_keymap_rows({_INSTANT_ID, _STICKY_PASS_ID})
    except Exception:
        pass


def audit(context: Any = None) -> Dict[str, Any]:
    del context
    rows = []
    try:
        from . import ownership_runtime_18168 as _ownership
        for km, kmi in _ownership.owned_keymap_items(_INSTANT_ID):
            rows.append({
                'keyconfig': 'addon-owned-exact',
                'map': _s(getattr(km, 'name', '')),
                'type': _s(getattr(kmi, 'type', '')),
                'value': _s(getattr(kmi, 'value', '')),
                'shift': bool(getattr(kmi, 'shift', False)),
                'ctrl': bool(getattr(kmi, 'ctrl', False)),
                'alt': bool(getattr(kmi, 'alt', False)),
                'oskey': bool(getattr(kmi, 'oskey', False)),
                'any': bool(getattr(kmi, 'any', False)),
                'active': bool(getattr(kmi, 'active', False)),
            })
    except Exception:
        pass
    return {
        'version': _VERSION,
        'rows': rows,
        'allowed_maps': [name for name, _space in _ALLOWED_INSTANT_MAPS],
        'forbidden_maps': list(_FORBIDDEN_INSTANT_MAPS),
        'foreign_keymaps_scanned': False,
        'last_gesture': dict(_LAST_GESTURE_DIAGNOSTIC),
    }
