# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Smart UV Suite standard unwrap core integrated into Smart UV Suite.

This module ports the staged Smart UV Standard flow from the supplied ``test.py``
into the Smart UV Suite namespace.  The implementation keeps Smart UV Suite
operator/property IDs, supports the updated SELECTED baseline mode, and preserves Blender-standard user seam and UV pin state while scoped
unwrap, optimization, and packing run on the selected UV-face set.
"""
from __future__ import annotations

import math
from typing import Any

import bpy
import bmesh


_EPS = 1.0e-7
_ORIGINAL_SEAM_LAYER = "suv_original_seam"
_SCOPE_FACE_LAYER = "suv_uv_scope_face"
_SCOPE_LOOP_LAYER = "suv_uv_scope_loop"
_SCOPE_ORIG_U_LAYER = "suv_uv_scope_orig_u"
_SCOPE_ORIG_V_LAYER = "suv_uv_scope_orig_v"
_SCOPE_ORIG_PIN_LAYER = "suv_uv_scope_orig_pin"
_SCOPE_ORIG_SEL_LAYER = "suv_uv_scope_orig_sel"
_SCOPE_ORIG_EDGE_SEL_LAYER = "suv_uv_scope_orig_edge_sel"
_SCOPE_ORIG_FACE_SEL_LAYER = "suv_uv_scope_orig_face_sel"
_SCOPE_ORIG_EDGE_SEAM_LAYER = "suv_uv_scope_orig_edge_seam"
_SCOPE_ORIG_MESH_VERT_SEL_LAYER = "suv_uv_scope_orig_mesh_vert_sel"
_SCOPE_ORIG_MESH_EDGE_SEL_LAYER = "suv_uv_scope_orig_mesh_edge_sel"
_SCOPE_ORIG_MESH_FACE_SEL_LAYER = "suv_uv_scope_orig_mesh_face_sel"


_TARGET_UV_LAYER_NAME = ""


def _ws(context):
    return getattr(getattr(context, 'scene', None), 'suv_workspace', None)


def _enum(ws, name: str, default: str) -> str:
    try:
        v = str(getattr(ws, name, default) or default).upper()
    except Exception:
        v = default
    return v


def _float(ws, name: str, default: float, lo: float | None = None, hi: float | None = None) -> float:
    try:
        v = float(getattr(ws, name, default))
    except Exception:
        v = float(default)
    if v != v:
        v = float(default)
    if lo is not None:
        v = max(float(lo), v)
    if hi is not None:
        v = min(float(hi), v)
    return v


def _int(ws, name: str, default: int, lo: int | None = None, hi: int | None = None) -> int:
    try:
        v = int(round(float(getattr(ws, name, default))))
    except Exception:
        v = int(default)
    if lo is not None:
        v = max(int(lo), v)
    if hi is not None:
        v = min(int(hi), v)
    return v


def _bool(ws, name: str, default: bool) -> bool:
    try:
        return bool(getattr(ws, name, default))
    except Exception:
        return bool(default)


def _active_uv_layer(bm):
    try:
        target_name = str(globals().get('_TARGET_UV_LAYER_NAME', '') or '')
        if target_name:
            layer = bm.loops.layers.uv.get(target_name)
            if layer is not None:
                return layer
    except Exception:
        pass
    try:
        layer = bm.loops.layers.uv.active
        if layer is not None:
            return layer
    except Exception:
        pass
    return bm.loops.layers.uv.verify()


def _call_uv_select_all(action: str = 'SELECT') -> None:
    try:
        bpy.ops.uv.select_all(action=action)
    except Exception:
        pass


def _call_mesh_select_all(action: str = 'SELECT') -> None:
    try:
        bpy.ops.mesh.select_all(action=action)
    except Exception:
        pass


def _call_smart_project(angle_limit: float, island_margin: float, area_weight: float):
    attempts = (
        dict(angle_limit=angle_limit, island_margin=island_margin, area_weight=area_weight, correct_aspect=True),
        dict(angle_limit=angle_limit, island_margin=island_margin, area_weight=area_weight),
        dict(angle_limit=angle_limit, island_margin=island_margin),
    )
    for kwargs in attempts:
        try:
            return bpy.ops.uv.smart_project(**kwargs)
        except TypeError:
            continue
        except Exception:
            continue
    return None


def _call_unwrap(method: str, margin: float):
    attempts = (
        dict(method=method, margin=margin, fill_holes=True, correct_aspect=True),
        dict(method=method, margin=margin),
        dict(method=method),
    )
    for kwargs in attempts:
        try:
            return bpy.ops.uv.unwrap(**kwargs)
        except TypeError:
            continue
        except Exception:
            continue
    return None


def _call_minimize_stretch(iterations: int, blend: float):
    if iterations <= 0 or blend <= 0.0:
        return None
    # Keep the public range but cap native repetitions during scripted tests.
    it = max(0, min(int(iterations), 512))
    attempts = (
        dict(iterations=it, blend=max(0.0, min(1.0, float(blend)))),
        dict(iterations=it),
    )
    for kwargs in attempts:
        try:
            return bpy.ops.uv.minimize_stretch(**kwargs)
        except TypeError:
            continue
        except Exception:
            continue
    return None


def _call_pack_islands(rotate: bool, rotate_method: str, margin: float, margin_method: str):
    safe_rot_method = str(rotate_method or 'ANY').upper()
    if safe_rot_method == 'NONE':
        safe_rot_method = 'ANY'
    safe_margin_method = str(margin_method or 'FRACTION').upper()
    attempts = (
        dict(rotate=bool(rotate), rotate_method=safe_rot_method, margin=float(margin), margin_method=safe_margin_method),
        dict(rotate=bool(rotate), margin=float(margin), margin_method=safe_margin_method),
        dict(rotate=bool(rotate), margin=float(margin)),
    )
    for kwargs in attempts:
        try:
            return bpy.ops.uv.pack_islands(**kwargs)
        except TypeError:
            continue
        except Exception:
            continue
    return None




def _read_uv_selection_attributes_from_mesh(me) -> tuple[dict[str, list[bool]], bool]:
    """Read Blender 5.1 hidden UV Editor selection attributes without changing modes."""
    out: dict[str, list[bool]] = {}
    has_any = False
    try:
        attrs = getattr(me, 'attributes', None)
        if attrs is None:
            return out, False
        for attr_name, key in (('.uv_select_vert', 'vert'), ('.uv_select_edge', 'edge'), ('.uv_select_face', 'face')):
            attr = attrs.get(attr_name)
            if attr is None:
                continue
            vals = []
            for item in getattr(attr, 'data', []) or []:
                try:
                    vals.append(bool(getattr(item, 'value', False)))
                except Exception:
                    vals.append(False)
            out[key] = vals
            has_any = has_any or any(vals)
    except Exception:
        return out, False
    return out, bool(has_any)


def _apply_uv_attribute_snapshot_values(snap: dict, attr_values: dict[str, list[bool]], attr_has_any: bool) -> bool:
    """Install hidden UV-selection values into a snapshot when they are authoritative."""
    if not attr_has_any:
        return False
    for key in ('vert', 'edge', 'face'):
        snap[key] = list(attr_values.get(key) or [])
    snap['has_any'] = True
    snap['prefer_attrs'] = True
    return True

def _uv_attribute_snapshot_for_active(context, obj=None) -> dict:
    """Read UV Editor selection flags and Blender 5.1 hidden selection attributes."""
    snap = {'vert': [], 'edge': [], 'face': [], 'has_any': False, 'sync': False, 'prefer_attrs': False}
    try:
        if obj is None:
            obj = getattr(context, 'edit_object', None) or getattr(context, 'active_object', None)
        if obj is None or getattr(obj, 'type', '') != 'MESH':
            return snap
        try:
            tool_settings = getattr(context, 'tool_settings', None) or getattr(getattr(context, 'scene', None), 'tool_settings', None)
            snap['sync'] = bool(getattr(tool_settings, 'use_uv_select_sync', False))
        except Exception:
            snap['sync'] = False
        pre_attr_values, pre_attr_has_any = _read_uv_selection_attributes_from_mesh(getattr(obj, 'data', None))
        if _apply_uv_attribute_snapshot_values(snap, pre_attr_values, pre_attr_has_any):
            return snap
        old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
        if old_mode == 'EDIT':
            try:
                bm = bmesh.from_edit_mesh(obj.data)
                uv_layer = _active_uv_layer(bm)
                bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
                bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
                max_loop = -1
                max_face = -1
                for face in bm.faces:
                    max_face = max(max_face, int(getattr(face, 'index', -1)))
                    for loop in face.loops:
                        max_loop = max(max_loop, int(getattr(loop, 'index', -1)))
                vert_flags = [False] * (max_loop + 1 if max_loop >= 0 else 0)
                edge_flags = [False] * (max_loop + 1 if max_loop >= 0 else 0)
                face_flags = [False] * (max_face + 1 if max_face >= 0 else 0)
                for face in bm.faces:
                    loop_count = 0
                    selected_count = 0
                    for loop in face.loops:
                        loop_count += 1
                        li = int(getattr(loop, 'index', -1))
                        try:
                            luv = loop[uv_layer]
                            vsel = bool(getattr(luv, 'select', False))
                            esel = bool(getattr(luv, 'select_edge', False))
                        except Exception:
                            vsel = False
                            esel = False
                        if li >= 0 and li < len(vert_flags):
                            vert_flags[li] = vert_flags[li] or vsel
                        if li >= 0 and li < len(edge_flags):
                            edge_flags[li] = edge_flags[li] or esel
                        if vsel:
                            selected_count += 1
                    fi = int(getattr(face, 'index', -1))
                    if fi >= 0 and fi < len(face_flags) and loop_count > 0 and selected_count == loop_count:
                        face_flags[fi] = True
                snap['vert'] = vert_flags
                snap['edge'] = edge_flags
                snap['face'] = face_flags
                snap['has_any'] = any(any(snap.get(k) or []) for k in ('vert', 'edge', 'face'))
            except Exception:
                pass
        changed = False
        if old_mode == 'EDIT':
            try:
                bpy.ops.object.mode_set(mode='OBJECT')
                changed = True
            except Exception:
                changed = False
        try:
            attrs = getattr(getattr(obj, 'data', None), 'attributes', None)
            if attrs is not None:
                attr_values = {}
                attr_has_any = False
                for attr_name, key in (('.uv_select_vert', 'vert'), ('.uv_select_edge', 'edge'), ('.uv_select_face', 'face')):
                    attr = attrs.get(attr_name)
                    if attr is None:
                        continue
                    vals = []
                    for item in getattr(attr, 'data', []) or []:
                        try:
                            vals.append(bool(getattr(item, 'value', False)))
                        except Exception:
                            vals.append(False)
                    attr_values[key] = vals
                    attr_has_any = attr_has_any or any(vals)
                if attr_has_any:
                    # Blender 5.1 stores the actual UV Editor selection in these
                    # hidden attributes.  When UV sync is off, BMesh element
                    # selection may still reflect the 3D View selection, so do
                    # not OR it into the UV scope; use the UV attributes as the
                    # authoritative source.
                    for key in ('vert', 'edge', 'face'):
                        if key in attr_values:
                            snap[key] = list(attr_values.get(key) or [])
                        elif key not in snap or snap.get(key) is None:
                            snap[key] = []
                    snap['has_any'] = True
                    snap['prefer_attrs'] = True
                else:
                    snap['has_any'] = any(snap.get(k) and any(snap.get(k) or []) for k in ('vert', 'edge', 'face'))
        finally:
            if changed:
                try:
                    bpy.ops.object.mode_set(mode='EDIT')
                except Exception:
                    pass
    except Exception:
        pass
    return snap


def _uv_attr_value(uv_attr_state: dict | None, key: str, index: int) -> bool:
    try:
        vals = (uv_attr_state or {}).get(str(key), []) or []
        idx = int(index)
        return idx >= 0 and idx < len(vals) and bool(vals[idx])
    except Exception:
        return False


def _loop_uv_vertex_selected(loop, face, uv_layer, uv_attr_state) -> bool:
    prefer_attrs = bool((uv_attr_state or {}).get('prefer_attrs'))
    if prefer_attrs:
        try:
            if _uv_attr_value(uv_attr_state, 'vert', int(getattr(loop, 'index', -1))):
                return True
        except Exception:
            pass
        try:
            if _uv_attr_value(uv_attr_state, 'face', int(getattr(face, 'index', -1))):
                return True
        except Exception:
            pass
        return False
    try:
        luv = loop[uv_layer]
        if bool(getattr(luv, 'select', False)):
            return True
    except Exception:
        pass
    try:
        if _uv_attr_value(uv_attr_state, 'vert', int(getattr(loop, 'index', -1))):
            return True
    except Exception:
        pass
    try:
        if _uv_attr_value(uv_attr_state, 'face', int(getattr(face, 'index', -1))):
            return True
    except Exception:
        pass
    try:
        if bool((uv_attr_state or {}).get('sync')):
            return bool(getattr(loop.vert, 'select', False)) or bool(getattr(face, 'select', False))
    except Exception:
        pass
    return False


def _loop_uv_edge_selected(loop, face, uv_layer, uv_attr_state) -> bool:
    prefer_attrs = bool((uv_attr_state or {}).get('prefer_attrs'))
    if prefer_attrs:
        try:
            if _uv_attr_value(uv_attr_state, 'edge', int(getattr(loop, 'index', -1))):
                return True
        except Exception:
            pass
        try:
            if _uv_attr_value(uv_attr_state, 'face', int(getattr(face, 'index', -1))):
                return True
        except Exception:
            pass
        return False
    try:
        luv = loop[uv_layer]
        if bool(getattr(luv, 'select_edge', False)):
            return True
    except Exception:
        pass
    try:
        if _uv_attr_value(uv_attr_state, 'edge', int(getattr(loop, 'index', -1))):
            return True
    except Exception:
        pass
    try:
        if _uv_attr_value(uv_attr_state, 'face', int(getattr(face, 'index', -1))):
            return True
    except Exception:
        pass
    try:
        if bool((uv_attr_state or {}).get('sync')):
            return bool(getattr(loop.edge, 'select', False)) or bool(getattr(face, 'select', False))
    except Exception:
        pass
    return False


def _scope_is_active(scope: dict | None) -> bool:
    try:
        if not scope:
            return False
        if bool(scope.get('active')):
            return True
        # Harden against Blender/script contexts where UV-face attributes are
        # present but the live-selection summary was not flagged.  A partial
        # complete-face scope must still be treated as active so unselected faces
        # are restored and explicitly deselected after the unwrap.
        selected = int(scope.get('selected_faces', 0) or 0)
        total = int(scope.get('total_faces', 0) or 0)
        return bool(0 < selected < total)
    except Exception:
        return False


def _scope_face_layer(bm):
    try:
        return bm.faces.layers.int.get(_SCOPE_FACE_LAYER)
    except Exception:
        return None


def _scope_loop_layer(bm):
    try:
        return bm.loops.layers.int.get(_SCOPE_LOOP_LAYER)
    except Exception:
        return None


def _face_in_uv_scope(face, scope: dict | None, face_layer=None) -> bool:
    if not _scope_is_active(scope):
        return True
    try:
        if face_layer is None:
            face_layer = face.id_data.faces.layers.int.get(_SCOPE_FACE_LAYER)
    except Exception:
        pass
    try:
        return face_layer is not None and bool(int(face[face_layer]))
    except Exception:
        return False


def _loop_in_uv_scope(loop, scope: dict | None, loop_layer=None) -> bool:
    if not _scope_is_active(scope):
        return True
    try:
        if loop_layer is None:
            loop_layer = loop.id_data.loops.layers.int.get(_SCOPE_LOOP_LAYER)
    except Exception:
        pass
    try:
        return loop_layer is not None and bool(int(loop[loop_layer]))
    except Exception:
        return False


def _edge_has_scope_face(edge, scope: dict | None, face_layer=None) -> bool:
    if not _scope_is_active(scope):
        return True
    for face in getattr(edge, 'link_faces', []) or []:
        if _face_in_uv_scope(face, scope, face_layer):
            return True
    return False




def _scope_selected_face_indices(me, scope: dict | None) -> set[int]:
    try:
        bm = bmesh.from_edit_mesh(me)
        face_layer = _scope_face_layer(bm)
        out = set()
        for face in bm.faces:
            if _face_in_uv_scope(face, scope, face_layer):
                out.add(int(getattr(face, 'index', -1)))
        return out
    except Exception:
        return set()


def _edge_all_linked_faces_in_scope(edge, scope: dict | None, face_layer=None) -> bool:
    if not _scope_is_active(scope):
        return True
    linked = list(getattr(edge, 'link_faces', []) or [])
    if not linked:
        return False
    for face in linked:
        if not _face_in_uv_scope(face, scope, face_layer):
            return False
    return True


def _face_uv_corners_all_selected(face, uv_layer, uv_attr_state: dict | None = None) -> bool:
    loops = list(getattr(face, 'loops', []) or [])
    if not loops:
        return False
    vert_flags = list((uv_attr_state or {}).get('vert') or [])
    has_vert_attr = bool(vert_flags)
    for loop in loops:
        selected = False
        try:
            if has_vert_attr:
                selected = _uv_attr_value(uv_attr_state, 'vert', int(getattr(loop, 'index', -1)))
            else:
                selected = bool(getattr(loop[uv_layer], 'select', False))
        except Exception:
            selected = False
        if not selected:
            return False
    return True


def _face_uv_selected_for_scope(face, uv_layer, uv_attr_state: dict | None = None) -> bool:
    """Return True only for a complete UV-face selection.

    Partial vertex/edge selections must not pull neighbouring faces into the
    unwrap domain.  A face is accepted only when it is in UV face selection and
    all of its UV corners are selected.  When the hidden face attribute is not
    available, the fallback is all UV corners selected.
    """
    try:
        fi = int(getattr(face, 'index', -1))
    except Exception:
        fi = -1
    face_flags = list((uv_attr_state or {}).get('face') or [])
    if fi >= 0 and fi < len(face_flags):
        return bool(face_flags[fi]) and _face_uv_corners_all_selected(face, uv_layer, uv_attr_state)
    return _face_uv_corners_all_selected(face, uv_layer, uv_attr_state)

def _has_any_uv_element_selection_for_scope(bm, uv_layer, uv_attr_state: dict | None = None) -> bool:
    try:
        if bool((uv_attr_state or {}).get('has_any')):
            return True
    except Exception:
        pass
    try:
        for face in bm.faces:
            for loop in face.loops:
                try:
                    luv = loop[uv_layer]
                    if bool(getattr(luv, 'select', False)) or bool(getattr(luv, 'select_edge', False)):
                        return True
                except Exception:
                    pass
    except Exception:
        pass
    return False


def _ensure_uv_selection_scope(context, obj, me) -> tuple[dict, dict]:
    """Capture the UV Editor selection and mark the selected unwrap domain.

    The Smart Standard unwrap core used to call mesh/UV select-all before every
    native unwrap/pack step.  This helper records the current UV Editor selection
    first, stores original UV coordinates and selection state, and writes custom
    BMesh layers that define the temporary unwrap scope.  When only part of the
    UV layout is selected, every later solver pass uses only these marked faces as
    its complete working set; unmarked loops are restored at the end.
    """
    uv_attr_state = _uv_attribute_snapshot_for_active(context, obj)
    scope = {
        'active': False,
        'selected_faces': 0,
        'total_faces': 0,
        'uv_attr_state': uv_attr_state,
        'has_uv_selection': bool((uv_attr_state or {}).get('has_any')),
    }
    try:
        bm = bmesh.from_edit_mesh(me)
        uv_layer = _active_uv_layer(bm)
        bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
        bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
        face_layer = bm.faces.layers.int.get(_SCOPE_FACE_LAYER) or bm.faces.layers.int.new(_SCOPE_FACE_LAYER)
        face_orig_sel_layer = bm.faces.layers.int.get(_SCOPE_ORIG_FACE_SEL_LAYER) or bm.faces.layers.int.new(_SCOPE_ORIG_FACE_SEL_LAYER)
        loop_layer = bm.loops.layers.int.get(_SCOPE_LOOP_LAYER) or bm.loops.layers.int.new(_SCOPE_LOOP_LAYER)
        loop_orig_u = bm.loops.layers.float.get(_SCOPE_ORIG_U_LAYER) or bm.loops.layers.float.new(_SCOPE_ORIG_U_LAYER)
        loop_orig_v = bm.loops.layers.float.get(_SCOPE_ORIG_V_LAYER) or bm.loops.layers.float.new(_SCOPE_ORIG_V_LAYER)
        loop_orig_pin = bm.loops.layers.int.get(_SCOPE_ORIG_PIN_LAYER) or bm.loops.layers.int.new(_SCOPE_ORIG_PIN_LAYER)
        loop_orig_sel = bm.loops.layers.int.get(_SCOPE_ORIG_SEL_LAYER) or bm.loops.layers.int.new(_SCOPE_ORIG_SEL_LAYER)
        loop_orig_edge_sel = bm.loops.layers.int.get(_SCOPE_ORIG_EDGE_SEL_LAYER) or bm.loops.layers.int.new(_SCOPE_ORIG_EDGE_SEL_LAYER)
        edge_orig_seam = bm.edges.layers.int.get(_SCOPE_ORIG_EDGE_SEAM_LAYER) or bm.edges.layers.int.new(_SCOPE_ORIG_EDGE_SEAM_LAYER)

        selected_face_count = 0
        total_faces = 0
        has_any_live_selection = _has_any_uv_element_selection_for_scope(bm, uv_layer, uv_attr_state)
        selected_faces = set()
        selected_loops = set()
        for face in bm.faces:
            total_faces += 1
            face_attr_selected = _uv_attr_value(uv_attr_state, 'face', int(getattr(face, 'index', -1)))
            try:
                # Store the original UV-face selection, not mesh face selection.
                # Blender 5.1 may keep all mesh faces selected while only a UV
                # subset is selected in the UV Editor.
                face[face_orig_sel_layer] = 1 if bool(face_attr_selected) else 0
            except Exception:
                pass
            face_fully_selected = _face_uv_selected_for_scope(face, uv_layer, uv_attr_state)
            for loop in face.loops:
                try:
                    luv = loop[uv_layer]
                    loop[loop_orig_u] = float(luv.uv.x)
                    loop[loop_orig_v] = float(luv.uv.y)
                    loop[loop_orig_pin] = 1 if bool(getattr(luv, 'pin_uv', False)) else 0
                    if bool((uv_attr_state or {}).get('prefer_attrs')):
                        loop[loop_orig_sel] = 1 if _loop_uv_vertex_selected(loop, face, uv_layer, uv_attr_state) else 0
                        loop[loop_orig_edge_sel] = 1 if _loop_uv_edge_selected(loop, face, uv_layer, uv_attr_state) else 0
                    else:
                        loop[loop_orig_sel] = 1 if bool(getattr(luv, 'select', False)) else 0
                        loop[loop_orig_edge_sel] = 1 if bool(getattr(luv, 'select_edge', False)) else 0
                except Exception:
                    pass
                try:
                    if _loop_uv_vertex_selected(loop, face, uv_layer, uv_attr_state) or _loop_uv_edge_selected(loop, face, uv_layer, uv_attr_state):
                        has_any_live_selection = True
                except Exception:
                    pass
            if face_fully_selected:
                selected_faces.add(face)
                for loop in face.loops:
                    selected_loops.add(loop)
            for loop in face.loops:
                try:
                    loop[loop_layer] = 0
                except Exception:
                    pass
        for edge in bm.edges:
            try:
                edge[edge_orig_seam] = 1 if bool(edge.seam) else 0
            except Exception:
                pass

        # Do not promote partial UV vertex/edge selections into face scope.
        # If no complete UV face is selected, the unwrap operator cancels without
        # changing UVs or the user's 3D View mesh selection.
        selected_face_count = len(selected_faces)
        active = bool(has_any_live_selection and 0 < selected_face_count < total_faces)
        scope['active'] = active
        scope['selected_faces'] = selected_face_count
        scope['total_faces'] = total_faces
        scope['has_uv_selection'] = bool(has_any_live_selection)
        scope['has_full_face_selection'] = bool(selected_face_count > 0)
        for face in bm.faces:
            in_scope = face in selected_faces
            try:
                face[face_layer] = 1 if in_scope else 0
            except Exception:
                pass
            if in_scope:
                for loop in face.loops:
                    try:
                        loop[loop_layer] = 1
                    except Exception:
                        pass
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
    except Exception:
        scope['active'] = False
    return scope, uv_attr_state


def _apply_uv_scope_selection_to_bmesh(bm, uv_layer, scope: dict | None, *, clear_pins: bool = False, select_uv: bool = True) -> None:
    """Select only the scoped faces/UVs for native Blender UV operators."""
    face_layer = _scope_face_layer(bm)
    for vert in getattr(bm, 'verts', []) or []:
        try:
            vert.select = False
        except Exception:
            pass
    for edge in getattr(bm, 'edges', []) or []:
        in_scope = _edge_has_scope_face(edge, scope, face_layer)
        try:
            edge.select = bool(in_scope)
        except Exception:
            pass
    for face in getattr(bm, 'faces', []) or []:
        in_scope = _face_in_uv_scope(face, scope, face_layer)
        try:
            face.select = bool(in_scope)
        except Exception:
            pass
        for loop in getattr(face, 'loops', []) or []:
            try:
                loop.vert.select = bool(in_scope)
            except Exception:
                pass
            if clear_pins:
                try:
                    loop[uv_layer].pin_uv = False
                except Exception:
                    pass
            if select_uv:
                try:
                    loop[uv_layer].select = bool(in_scope)
                    loop[uv_layer].select_edge = bool(in_scope)
                except Exception:
                    pass


def _select_uv_scope_for_ops(me, scope: dict | None, *, clear_pins: bool = False) -> None:
    try:
        bm = bmesh.from_edit_mesh(me)
        uv_layer = _active_uv_layer(bm)
        bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
        _apply_uv_scope_selection_to_bmesh(bm, uv_layer, scope, clear_pins=clear_pins, select_uv=True)
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
        _sync_uv_scope_selection_attributes_for_blender_51(me, scope)
    except Exception:
        if not _scope_is_active(scope):
            _call_mesh_select_all('SELECT')
            _call_uv_select_all('SELECT')


def _mesh_bool_attribute(me, name: str, domain: str, *, create: bool = False):
    try:
        attr = me.attributes.get(name)
    except Exception:
        attr = None
    if attr is None and create:
        try:
            attr = me.attributes.new(name, 'BOOLEAN', domain)
        except Exception:
            attr = None
    return attr


def _sync_uv_scope_selection_attributes_for_blender_51(me, scope: dict | None) -> None:
    """Write Blender 5.1 UV-selection attributes from the scoped face mask.

    Blender 5.1 stores UV Editor selections in hidden mesh attributes such as
    ``.uv_select_vert`` instead of writable ``BMLoopUV.select`` members.  Native
    UV operators read those attributes, so scoped unwrap must update them before
    every operator call.
    """
    obj = None
    try:
        active = bpy.context.edit_object or bpy.context.active_object
        if active is not None and getattr(active, 'data', None) is me:
            obj = active
    except Exception:
        obj = None
    if obj is None:
        try:
            obj = next((candidate for candidate in bpy.data.objects if getattr(candidate, 'data', None) is me), None)
        except Exception:
            obj = None
    if obj is None:
        return
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    try:
        if old_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
    except Exception:
        return
    try:
        uv_vert = _mesh_bool_attribute(me, '.uv_select_vert', 'CORNER', create=True)
        uv_edge = _mesh_bool_attribute(me, '.uv_select_edge', 'CORNER', create=True)
        uv_face = _mesh_bool_attribute(me, '.uv_select_face', 'FACE', create=True)
        mesh_face_sel = _mesh_bool_attribute(me, '.select_poly', 'FACE', create=False)
        mesh_vert_sel = _mesh_bool_attribute(me, '.select_vert', 'POINT', create=False)
        mesh_edge_sel = _mesh_bool_attribute(me, '.select_edge', 'EDGE', create=False)
        if not all((uv_vert, uv_edge, uv_face)):
            return
        active_scope = _scope_is_active(scope)
        face_scope_attr = me.attributes.get(_SCOPE_FACE_LAYER) if active_scope else None
        loop_scope_attr = me.attributes.get(_SCOPE_LOOP_LAYER) if active_scope else None
        face_flags = []
        for poly in me.polygons:
            flag = True
            if active_scope:
                try:
                    flag = bool(int(face_scope_attr.data[poly.index].value)) if face_scope_attr is not None else False
                except Exception:
                    flag = False
            face_flags.append(flag)
        loop_flags = [False] * len(me.loops)
        for poly in me.polygons:
            face_flag = face_flags[poly.index] if poly.index < len(face_flags) else False
            for li in poly.loop_indices:
                flag = face_flag
                if active_scope and loop_scope_attr is not None:
                    try:
                        flag = bool(int(loop_scope_attr.data[li].value))
                    except Exception:
                        flag = face_flag
                if li < len(loop_flags):
                    loop_flags[li] = bool(flag)
        for i, flag in enumerate(loop_flags):
            try:
                uv_vert.data[i].value = bool(flag)
                uv_edge.data[i].value = bool(flag)
            except Exception:
                pass
        for i, flag in enumerate(face_flags):
            try:
                uv_face.data[i].value = bool(flag)
            except Exception:
                pass
            try:
                if mesh_face_sel is not None:
                    mesh_face_sel.data[i].value = bool(flag)
            except Exception:
                pass
        vert_flags = [False] * len(me.vertices)
        edge_flags = [False] * len(me.edges)
        edge_lookup = {}
        try:
            for edge in me.edges:
                edge_lookup[tuple(sorted((int(edge.vertices[0]), int(edge.vertices[1]))))] = int(edge.index)
        except Exception:
            edge_lookup = {}
        for poly in me.polygons:
            face_flag = face_flags[poly.index] if poly.index < len(face_flags) else False
            if not face_flag:
                continue
            verts = list(poly.vertices)
            for vi in verts:
                if 0 <= int(vi) < len(vert_flags):
                    vert_flags[int(vi)] = True
            for i, va in enumerate(verts):
                vb = verts[(i + 1) % len(verts)]
                ei = edge_lookup.get(tuple(sorted((int(va), int(vb)))))
                if ei is not None and 0 <= ei < len(edge_flags):
                    edge_flags[ei] = True
        if mesh_vert_sel is not None:
            for i, flag in enumerate(vert_flags):
                try:
                    mesh_vert_sel.data[i].value = bool(flag)
                except Exception:
                    pass
        if mesh_edge_sel is not None:
            for i, flag in enumerate(edge_flags):
                try:
                    mesh_edge_sel.data[i].value = bool(flag)
                except Exception:
                    pass
    finally:
        try:
            if old_mode == 'EDIT':
                bpy.ops.object.mode_set(mode='EDIT')
        except Exception:
            pass


def _restore_original_uv_selection_attributes_for_blender_51(me) -> None:
    """Restore Blender 5.1 hidden UV-selection attributes from saved layers."""
    obj = None
    try:
        active = bpy.context.edit_object or bpy.context.active_object
        if active is not None and getattr(active, 'data', None) is me:
            obj = active
    except Exception:
        obj = None
    if obj is None:
        try:
            obj = next((candidate for candidate in bpy.data.objects if getattr(candidate, 'data', None) is me), None)
        except Exception:
            obj = None
    if obj is None:
        return
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    try:
        if old_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
    except Exception:
        return
    try:
        uv_vert = _mesh_bool_attribute(me, '.uv_select_vert', 'CORNER', create=True)
        uv_edge = _mesh_bool_attribute(me, '.uv_select_edge', 'CORNER', create=True)
        uv_face = _mesh_bool_attribute(me, '.uv_select_face', 'FACE', create=True)
        orig_vert = me.attributes.get(_SCOPE_ORIG_SEL_LAYER)
        orig_edge = me.attributes.get(_SCOPE_ORIG_EDGE_SEL_LAYER)
        orig_face = me.attributes.get(_SCOPE_ORIG_FACE_SEL_LAYER)
        if uv_vert is not None and orig_vert is not None:
            for i in range(min(len(uv_vert.data), len(orig_vert.data))):
                try:
                    uv_vert.data[i].value = bool(int(orig_vert.data[i].value))
                except Exception:
                    pass
        if uv_edge is not None and orig_edge is not None:
            for i in range(min(len(uv_edge.data), len(orig_edge.data))):
                try:
                    uv_edge.data[i].value = bool(int(orig_edge.data[i].value))
                except Exception:
                    pass
        if uv_face is not None and orig_face is not None:
            for i in range(min(len(uv_face.data), len(orig_face.data))):
                try:
                    uv_face.data[i].value = bool(int(orig_face.data[i].value))
                except Exception:
                    pass
    finally:
        try:
            if old_mode == 'EDIT':
                bpy.ops.object.mode_set(mode='EDIT')
        except Exception:
            pass




def _force_final_uv_scope_selection_only(me, scope: dict | None) -> None:
    """Leave only the processed UV face scope selected in the UV Editor.

    Native unwrap/pack operators temporarily select the working scope and may
    leave hidden Blender 5.1 UV-selection attributes expanded.  The 3D View mesh
    selection is restored separately, so this helper writes only UV selection
    flags and never touches ``.select_vert/.select_edge/.select_poly`` mesh
    attributes.  Non-scoped islands/faces therefore end the operation fully
    deselected in the UV Editor while the user's 3D mesh selection remains intact.
    """
    if not _scope_is_active(scope):
        return
    face_flags: list[bool] = []
    loop_flags: list[bool] = []
    obj = None
    try:
        active = bpy.context.edit_object or bpy.context.active_object
        if active is not None and getattr(active, 'data', None) is me:
            obj = active
    except Exception:
        obj = None
    if obj is None:
        try:
            obj = next((candidate for candidate in bpy.data.objects if getattr(candidate, 'data', None) is me), None)
        except Exception:
            obj = None
    try:
        bm = bmesh.from_edit_mesh(me)
        uv_layer = _active_uv_layer(bm)
        bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
        bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
        face_layer = bm.faces.layers.int.get(_SCOPE_FACE_LAYER)
        loop_layer = bm.loops.layers.int.get(_SCOPE_LOOP_LAYER)
        max_face = -1
        max_loop = -1
        for face in bm.faces:
            max_face = max(max_face, int(getattr(face, 'index', -1)))
            for loop in face.loops:
                max_loop = max(max_loop, int(getattr(loop, 'index', -1)))
        face_flags = [False] * (max_face + 1 if max_face >= 0 else 0)
        loop_flags = [False] * (max_loop + 1 if max_loop >= 0 else 0)
        for face in bm.faces:
            try:
                fi = int(getattr(face, 'index', -1))
            except Exception:
                fi = -1
            in_scope = _face_in_uv_scope(face, scope, face_layer)
            if fi >= 0 and fi < len(face_flags):
                face_flags[fi] = bool(in_scope)
            for loop in face.loops:
                try:
                    li = int(getattr(loop, 'index', -1))
                except Exception:
                    li = -1
                loop_scoped = bool(in_scope)
                if loop_layer is not None:
                    try:
                        loop_scoped = bool(int(loop[loop_layer]))
                    except Exception:
                        loop_scoped = bool(in_scope)
                if li >= 0 and li < len(loop_flags):
                    loop_flags[li] = bool(loop_scoped)
                try:
                    loop[uv_layer].select = bool(loop_scoped)
                    loop[uv_layer].select_edge = bool(loop_scoped)
                except Exception:
                    pass
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
    except Exception:
        return
    if obj is None:
        return
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    try:
        if old_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
    except Exception:
        return
    try:
        uv_vert = _mesh_bool_attribute(me, '.uv_select_vert', 'CORNER', create=True)
        uv_edge = _mesh_bool_attribute(me, '.uv_select_edge', 'CORNER', create=True)
        uv_face = _mesh_bool_attribute(me, '.uv_select_face', 'FACE', create=True)
        if uv_vert is not None:
            for i in range(min(len(uv_vert.data), len(loop_flags))):
                try:
                    uv_vert.data[i].value = bool(loop_flags[i])
                except Exception:
                    pass
            for i in range(len(loop_flags), len(uv_vert.data)):
                try:
                    uv_vert.data[i].value = False
                except Exception:
                    pass
        if uv_edge is not None:
            for i in range(min(len(uv_edge.data), len(loop_flags))):
                try:
                    uv_edge.data[i].value = bool(loop_flags[i])
                except Exception:
                    pass
            for i in range(len(loop_flags), len(uv_edge.data)):
                try:
                    uv_edge.data[i].value = False
                except Exception:
                    pass
        if uv_face is not None:
            for i in range(min(len(uv_face.data), len(face_flags))):
                try:
                    uv_face.data[i].value = bool(face_flags[i])
                except Exception:
                    pass
            for i in range(len(face_flags), len(uv_face.data)):
                try:
                    uv_face.data[i].value = False
                except Exception:
                    pass
    finally:
        try:
            if old_mode == 'EDIT':
                bpy.ops.object.mode_set(mode='EDIT')
        except Exception:
            pass

def _set_bmesh_element_selected(elem, value: bool) -> None:
    """Set a BMesh element selection flag without changing other domains."""
    try:
        elem.select_set(bool(value))
    except Exception:
        try:
            elem.select = bool(value)
        except Exception:
            pass


def _capture_3d_mesh_selection_state(context, obj, me) -> dict:
    """Store the current 3D View mesh-selection state before scoped UV unwrap.

    Scoped UV unwrap must temporarily select the UV working domain so Blender's
    native unwrap/pack operators act only on UV Editor selected elements.  Those
    temporary mesh selections must not leak back to the user's 3D View.  This
    stores vertex, edge, and face selection in BMesh custom layers and also keeps
    the current mesh select mode for restoration after the UV solve.
    """
    state = {'active': False, 'mesh_select_mode': None}
    try:
        ts = getattr(context, 'tool_settings', None) or getattr(getattr(context, 'scene', None), 'tool_settings', None)
        if ts is not None:
            state['mesh_select_mode'] = tuple(bool(v) for v in getattr(ts, 'mesh_select_mode', (True, False, False)))
    except Exception:
        state['mesh_select_mode'] = None
    try:
        if obj is None or getattr(obj, 'type', '') != 'MESH':
            return state
        if str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT') != 'EDIT':
            return state
        bm = bmesh.from_edit_mesh(me)
        bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
        bm.verts.index_update(); bm.edges.index_update(); bm.faces.index_update()
        vert_layer = bm.verts.layers.int.get(_SCOPE_ORIG_MESH_VERT_SEL_LAYER) or bm.verts.layers.int.new(_SCOPE_ORIG_MESH_VERT_SEL_LAYER)
        edge_layer = bm.edges.layers.int.get(_SCOPE_ORIG_MESH_EDGE_SEL_LAYER) or bm.edges.layers.int.new(_SCOPE_ORIG_MESH_EDGE_SEL_LAYER)
        face_layer = bm.faces.layers.int.get(_SCOPE_ORIG_MESH_FACE_SEL_LAYER) or bm.faces.layers.int.new(_SCOPE_ORIG_MESH_FACE_SEL_LAYER)
        for vert in bm.verts:
            try:
                vert[vert_layer] = 1 if bool(getattr(vert, 'select', False)) else 0
            except Exception:
                pass
        for edge in bm.edges:
            try:
                edge[edge_layer] = 1 if bool(getattr(edge, 'select', False)) else 0
            except Exception:
                pass
        for face in bm.faces:
            try:
                face[face_layer] = 1 if bool(getattr(face, 'select', False)) else 0
            except Exception:
                pass
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
        state['active'] = True
    except Exception:
        state['active'] = False
    return state


def _restore_original_mesh_selection_attributes_for_blender_51(me) -> None:
    """Restore Blender 5.1 hidden mesh-selection attributes from saved layers."""
    obj = None
    try:
        active = bpy.context.edit_object or bpy.context.active_object
        if active is not None and getattr(active, 'data', None) is me:
            obj = active
    except Exception:
        obj = None
    if obj is None:
        try:
            obj = next((candidate for candidate in bpy.data.objects if getattr(candidate, 'data', None) is me), None)
        except Exception:
            obj = None
    if obj is None:
        return
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    try:
        if old_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
    except Exception:
        return
    try:
        mesh_vert = _mesh_bool_attribute(me, '.select_vert', 'POINT', create=False)
        mesh_edge = _mesh_bool_attribute(me, '.select_edge', 'EDGE', create=False)
        mesh_face = _mesh_bool_attribute(me, '.select_poly', 'FACE', create=False)
        orig_vert = me.attributes.get(_SCOPE_ORIG_MESH_VERT_SEL_LAYER)
        orig_edge = me.attributes.get(_SCOPE_ORIG_MESH_EDGE_SEL_LAYER)
        orig_face = me.attributes.get(_SCOPE_ORIG_MESH_FACE_SEL_LAYER)
        if mesh_vert is not None and orig_vert is not None:
            for i in range(min(len(mesh_vert.data), len(orig_vert.data))):
                try:
                    mesh_vert.data[i].value = bool(int(orig_vert.data[i].value))
                except Exception:
                    pass
        if mesh_edge is not None and orig_edge is not None:
            for i in range(min(len(mesh_edge.data), len(orig_edge.data))):
                try:
                    mesh_edge.data[i].value = bool(int(orig_edge.data[i].value))
                except Exception:
                    pass
        if mesh_face is not None and orig_face is not None:
            for i in range(min(len(mesh_face.data), len(orig_face.data))):
                try:
                    mesh_face.data[i].value = bool(int(orig_face.data[i].value))
                except Exception:
                    pass
    finally:
        try:
            if old_mode == 'EDIT':
                bpy.ops.object.mode_set(mode='EDIT')
        except Exception:
            pass


def _restore_3d_mesh_selection_state(context, obj, me, state: dict | None) -> None:
    """Restore the user's 3D View vertex/edge/face selection after UV unwrap."""
    if not state or not bool(state.get('active')):
        return
    try:
        if obj is not None and getattr(obj, 'type', '') == 'MESH' and str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT') != 'EDIT':
            try:
                bpy.context.view_layer.objects.active = obj
            except Exception:
                pass
            try:
                bpy.ops.object.mode_set(mode='EDIT')
            except Exception:
                pass
        bm = bmesh.from_edit_mesh(me)
        bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
        bm.verts.index_update(); bm.edges.index_update(); bm.faces.index_update()
        vert_layer = bm.verts.layers.int.get(_SCOPE_ORIG_MESH_VERT_SEL_LAYER)
        edge_layer = bm.edges.layers.int.get(_SCOPE_ORIG_MESH_EDGE_SEL_LAYER)
        face_layer = bm.faces.layers.int.get(_SCOPE_ORIG_MESH_FACE_SEL_LAYER)
        if vert_layer is not None:
            for vert in bm.verts:
                try:
                    _set_bmesh_element_selected(vert, bool(int(vert[vert_layer])))
                except Exception:
                    pass
        if edge_layer is not None:
            for edge in bm.edges:
                try:
                    _set_bmesh_element_selected(edge, bool(int(edge[edge_layer])))
                except Exception:
                    pass
        if face_layer is not None:
            for face in bm.faces:
                try:
                    _set_bmesh_element_selected(face, bool(int(face[face_layer])))
                except Exception:
                    pass
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
        _restore_original_mesh_selection_attributes_for_blender_51(me)
    except Exception:
        pass
    try:
        mode = state.get('mesh_select_mode')
        if mode is not None:
            ts = getattr(context, 'tool_settings', None) or getattr(getattr(context, 'scene', None), 'tool_settings', None)
            if ts is not None:
                ts.mesh_select_mode = tuple(bool(v) for v in mode)
    except Exception:
        pass

def _restore_unselected_uv_scope(me, scope: dict | None) -> None:
    """Restore UVs, selection and seams outside the selected unwrap scope."""
    if not _scope_is_active(scope):
        return
    try:
        bm = bmesh.from_edit_mesh(me)
        uv_layer = _active_uv_layer(bm)
        face_layer = bm.faces.layers.int.get(_SCOPE_FACE_LAYER)
        face_orig_sel_layer = bm.faces.layers.int.get(_SCOPE_ORIG_FACE_SEL_LAYER)
        loop_layer = bm.loops.layers.int.get(_SCOPE_LOOP_LAYER)
        loop_orig_u = bm.loops.layers.float.get(_SCOPE_ORIG_U_LAYER)
        loop_orig_v = bm.loops.layers.float.get(_SCOPE_ORIG_V_LAYER)
        loop_orig_pin = bm.loops.layers.int.get(_SCOPE_ORIG_PIN_LAYER)
        loop_orig_sel = bm.loops.layers.int.get(_SCOPE_ORIG_SEL_LAYER)
        loop_orig_edge_sel = bm.loops.layers.int.get(_SCOPE_ORIG_EDGE_SEL_LAYER)
        edge_orig_seam = bm.edges.layers.int.get(_SCOPE_ORIG_EDGE_SEAM_LAYER)
        for face in bm.faces:
            in_scope = _face_in_uv_scope(face, scope, face_layer)
            try:
                # 3D mesh selection is restored by _restore_3d_mesh_selection_state.
                # During UV restore, keep the visible UV selection constrained to scope.
                face.select = bool(in_scope)
            except Exception:
                pass
            for loop in face.loops:
                loop_scoped = _loop_in_uv_scope(loop, scope, loop_layer)
                try:
                    if not loop_scoped and loop_orig_u is not None and loop_orig_v is not None:
                        loop[uv_layer].uv.x = float(loop[loop_orig_u])
                        loop[uv_layer].uv.y = float(loop[loop_orig_v])
                    if loop_orig_pin is not None:
                        loop[uv_layer].pin_uv = bool(int(loop[loop_orig_pin]))
                    loop[uv_layer].select = bool(loop_scoped)
                    loop[uv_layer].select_edge = bool(loop_scoped)
                except Exception:
                    pass
        for edge in bm.edges:
            try:
                if edge_orig_seam is not None and not _edge_all_linked_faces_in_scope(edge, scope, face_layer):
                    edge.seam = bool(int(edge[edge_orig_seam]))
            except Exception:
                pass
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
        _force_final_uv_scope_selection_only(me, scope)
    except Exception:
        pass


def _restore_original_user_pins_and_mesh_seams(me) -> None:
    """Restore user UV pins and Blender mesh seam marks captured before unwrap.

    Smart UV Suite may create temporary baseline pins and temporary seam graphs
    while solving Single アイランド, Mark Seam component splits, and packing.
    Those temporary edits must never replace the user's Blender-standard
    ``シームをマーク`` or UV pin state.  This function restores the captured
    values for every loop/edge before scope cleanup, so pins continue to work
    like Blender's native Pin/Unpin and seams remain until the user explicitly
    runs ``シームをクリア``.
    """
    try:
        bm = bmesh.from_edit_mesh(me)
        uv_layer = _active_uv_layer(bm)
        loop_orig_pin = bm.loops.layers.int.get(_SCOPE_ORIG_PIN_LAYER)
        edge_orig_scope = bm.edges.layers.int.get(_SCOPE_ORIG_EDGE_SEAM_LAYER)
        edge_orig_single = bm.edges.layers.int.get(_ORIGINAL_SEAM_LAYER)
        if loop_orig_pin is not None:
            loop_orig_u = bm.loops.layers.float.get(_SCOPE_ORIG_U_LAYER)
            loop_orig_v = bm.loops.layers.float.get(_SCOPE_ORIG_V_LAYER)
            for face in getattr(bm, 'faces', []) or []:
                for loop in getattr(face, 'loops', []) or []:
                    try:
                        was_pinned = bool(int(loop[loop_orig_pin]))
                        # Blender-standard pinned UVs are treated as fixed anchors.
                        # Smart UV Suite uses temporary pins internally for baseline
                        # solving, so restore both the user's original pin flag and
                        # the original pinned coordinate before cleanup.
                        if was_pinned and loop_orig_u is not None and loop_orig_v is not None:
                            loop[uv_layer].uv.x = float(loop[loop_orig_u])
                            loop[uv_layer].uv.y = float(loop[loop_orig_v])
                        loop[uv_layer].pin_uv = was_pinned
                    except Exception:
                        pass
        seam_layer = edge_orig_scope or edge_orig_single
        if seam_layer is not None:
            for edge in getattr(bm, 'edges', []) or []:
                try:
                    edge.seam = bool(int(edge[seam_layer]))
                except Exception:
                    pass
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
    except Exception:
        pass


def _cleanup_uv_selection_scope_layers(me) -> None:
    """Remove temporary BMesh custom data layers used by scoped unwrap."""
    try:
        bm = bmesh.from_edit_mesh(me)
        for name in (_SCOPE_FACE_LAYER, _SCOPE_ORIG_FACE_SEL_LAYER):
            try:
                layer = bm.faces.layers.int.get(name)
                if layer is not None:
                    bm.faces.layers.int.remove(layer)
            except Exception:
                pass
        for name in (_SCOPE_LOOP_LAYER, _SCOPE_ORIG_PIN_LAYER, _SCOPE_ORIG_SEL_LAYER, _SCOPE_ORIG_EDGE_SEL_LAYER):
            try:
                layer = bm.loops.layers.int.get(name)
                if layer is not None:
                    bm.loops.layers.int.remove(layer)
            except Exception:
                pass
        for name in (_SCOPE_ORIG_U_LAYER, _SCOPE_ORIG_V_LAYER):
            try:
                layer = bm.loops.layers.float.get(name)
                if layer is not None:
                    bm.loops.layers.float.remove(layer)
            except Exception:
                pass
        try:
            layer = bm.edges.layers.int.get(_SCOPE_ORIG_EDGE_SEAM_LAYER)
            if layer is not None:
                bm.edges.layers.int.remove(layer)
        except Exception:
            pass
        try:
            layer = bm.verts.layers.int.get(_SCOPE_ORIG_MESH_VERT_SEL_LAYER)
            if layer is not None:
                bm.verts.layers.int.remove(layer)
        except Exception:
            pass
        try:
            layer = bm.edges.layers.int.get(_SCOPE_ORIG_MESH_EDGE_SEL_LAYER)
            if layer is not None:
                bm.edges.layers.int.remove(layer)
        except Exception:
            pass
        try:
            layer = bm.faces.layers.int.get(_SCOPE_ORIG_MESH_FACE_SEL_LAYER)
            if layer is not None:
                bm.faces.layers.int.remove(layer)
        except Exception:
            pass
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
    except Exception:
        pass


def _uv_key(uv, eps: float = 1.0e-4) -> tuple[int, int]:
    return (int(round(float(uv.x) / eps)), int(round(float(uv.y) / eps)))


def _capture_selected_baseline_strands(bm, uv_layer, uv_attr_state) -> object | None:
    """Tag UV selected edge/vertex strands before the initial unwrap overwrites UVs."""
    uv_sel_tag = bm.loops.layers.int.get('uv_sel_tag') or bm.loops.layers.int.new('uv_sel_tag')
    for face in bm.faces:
        for loop in face.loops:
            loop[uv_sel_tag] = 0

    target_set = set()
    selected_edge_starts = []
    for face in bm.faces:
        for loop in face.loops:
            if _loop_uv_vertex_selected(loop, face, uv_layer, uv_attr_state):
                target_set.add(loop)
            if _loop_uv_edge_selected(loop, face, uv_layer, uv_attr_state):
                selected_edge_starts.append(loop)
                target_set.add(loop)
                try:
                    target_set.add(loop.link_loop_next)
                except Exception:
                    pass

    if not target_set:
        return uv_sel_tag

    # Do not use UV pin flags as temporary selection storage here.
    # User-created pins must remain available to Blender's unwrap solvers.

    valid_edges = []
    visited_edges = set()
    sum_du = 0.0
    sum_dv = 0.0
    for face in bm.faces:
        for loop in face.loops:
            nxt = loop.link_loop_next
            if loop not in target_set or nxt not in target_set:
                continue
            # Prefer explicitly selected edge starts, but allow vertex-mode chains
            # when both endpoints are selected.
            explicit = loop in selected_edge_starts or _loop_uv_edge_selected(loop, face, uv_layer, uv_attr_state)
            if selected_edge_starts and not explicit:
                continue
            try:
                edge_key = tuple(sorted((int(loop.vert.index), int(nxt.vert.index))))
            except Exception:
                edge_key = (id(loop.vert), id(nxt.vert))
            if edge_key in visited_edges:
                continue
            visited_edges.add(edge_key)
            try:
                du = float(nxt[uv_layer].uv.x - loop[uv_layer].uv.x)
                dv = float(nxt[uv_layer].uv.y - loop[uv_layer].uv.y)
            except Exception:
                du = dv = 0.0
            valid_edges.append((loop, nxt, du, dv))
            sum_du += abs(du)
            sum_dv += abs(dv)

    is_vertical = sum_dv > sum_du
    loop_to_idx = {}
    uv_verts = []
    target_loops = list(target_set)
    for loop in target_loops:
        if loop in loop_to_idx:
            continue
        idx = len(uv_verts)
        cluster = []
        try:
            base_key = _uv_key(loop[uv_layer].uv)
        except Exception:
            base_key = None
        try:
            linked = list(loop.vert.link_loops)
        except Exception:
            linked = [loop]
        for other in linked:
            if other not in target_set:
                continue
            try:
                same_pos = base_key is None or _uv_key(other[uv_layer].uv) == base_key
            except Exception:
                same_pos = False
            if same_pos:
                cluster.append(other)
                loop_to_idx[other] = idx
        if not cluster:
            cluster = [loop]
            loop_to_idx[loop] = idx
        uv_verts.append(cluster)

    adj = {i: set() for i in range(len(uv_verts))}
    tolerance = 0.5
    for loop, nxt, du, dv in valid_edges:
        a = loop_to_idx.get(loop)
        b = loop_to_idx.get(nxt)
        if a is None or b is None or a == b:
            continue
        if is_vertical and abs(dv) >= abs(du) * tolerance:
            adj[a].add(b); adj[b].add(a)
        elif not is_vertical and abs(du) >= abs(dv) * tolerance:
            adj[a].add(b); adj[b].add(a)

    visited = set()
    groups = []
    for i in range(len(uv_verts)):
        if i in visited:
            continue
        comp = set()
        queue = [i]
        visited.add(i)
        while queue:
            curr = queue.pop(0)
            comp.add(curr)
            for neighbor in adj[curr]:
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(neighbor)
        groups.append(comp)

    for strand_idx, comp in enumerate(groups):
        for idx in comp:
            for loop in uv_verts[idx]:
                try:
                    loop[uv_sel_tag] = strand_idx + 1
                except Exception:
                    pass
    return uv_sel_tag


_SUS_SMART_STANDARD_ACTUAL_UNWRAP_MODES = {'SMART_STANDARD_HARD', 'SMART_STANDARD_ORGANIC', 'SMART', 'NORMAL'}
_SUS_SMART_STANDARD_PRESET_TO_ACTUAL_MODE = {
    'HARD_SURFACE': 'SMART_STANDARD_HARD',
    'ORGANIC': 'SMART_STANDARD_ORGANIC',
    'STANDARD_SMART': 'SMART',
    'NORMAL_UNWRAP': 'NORMAL',
    'STANDARD_KEEP': 'SMART_STANDARD_HARD',
    'BALANCED': 'SMART_STANDARD_HARD',
    'LOW_STRETCH': 'SMART_STANDARD_ORGANIC',
    'LOOP_SAFE': 'SMART_STANDARD_HARD',
    'AREA_ACCURATE': 'SMART',
    'QUALITY_OPTIMIZE': 'SMART_STANDARD_ORGANIC',
    'CLEAN_MERGE': 'SMART_STANDARD_ORGANIC',
    'PACK_STABLE': 'SMART',
    'HARD_CHART_PRECISION': 'SMART_STANDARD_HARD',
    'ORGANIC_LOW_DISTORTION_PRECISION': 'SMART_STANDARD_ORGANIC',
    'SELECTED_SCOPE_LOW_DISTORTION': 'SMART_STANDARD_ORGANIC',
}


def _resolved_smart_standard_core_unwrap_mode(ws, raw_mode: str) -> str:
    mode = str(raw_mode or 'SMART_STANDARD_HARD').upper()
    if mode in _SUS_SMART_STANDARD_ACTUAL_UNWRAP_MODES:
        return mode
    if mode in {'CUSTOM', 'SINGLE_ISLAND'}:
        for attr in ('smart_standard_core_resolved_unwrap_mode', 'smart_standard_core_last_actual_unwrap_mode'):
            try:
                stored = str(getattr(ws, attr, '') or '').upper()
            except Exception:
                stored = ''
            if stored in _SUS_SMART_STANDARD_ACTUAL_UNWRAP_MODES:
                return stored
    return _SUS_SMART_STANDARD_PRESET_TO_ACTUAL_MODE.get(mode, 'SMART_STANDARD_HARD')


def _single_island_strength_for_mode(ws, unwrap_mode: str) -> float:
    """Return the seam-analysis island merge strength normalized from the UI 0..100 percentage.

    The old per-mode "Single アイランド" sliders are intentionally ignored.
    Island merging is now driven by the Singleアイランド・シーム解析 section so
    the preset, merge amount, seam-protection weights, unwrap parameters and
    quality optimizer remain one coordinated setup.
    """
    return _float(ws, 'smart_standard_core_seam_merge_strength', 0.0, 0.0, 100.0) / 100.0


def _smooth_single_island_strength(value: float) -> float:
    """Normalize the Single Island blend value. The UI value is percentage-based; seam reduction is linear."""
    try:
        x = max(0.0, min(1.0, float(value)))
    except Exception:
        x = 0.0
    if x <= _EPS:
        return 0.0
    if x >= 1.0 - _EPS:
        return 1.0
    return x


def _seam_priority_for_single_island(edge) -> float:
    """Lower-priority seams are removed earlier while important fold cuts remain longer."""
    score = 0.0
    try:
        if len(edge.link_faces) < 2:
            score += 10000.0
    except Exception:
        pass
    try:
        if len(edge.link_faces) >= 2:
            n0 = edge.link_faces[0].normal
            n1 = edge.link_faces[1].normal
            dot = max(-1.0, min(1.0, float(n0.dot(n1))))
            score += math.acos(dot) * 100.0
    except Exception:
        pass
    try:
        # Longer seams often carry more visible layout structure, so keep them a little longer.
        score += float(edge.calc_length()) * 0.01
    except Exception:
        pass
    return score


def _tag_original_seams_for_single_island(bm) -> object | None:
    """Remember pre-unwrap/manual seam flags before Smart Project rewrites seams."""
    try:
        layer = bm.edges.layers.int.get(_ORIGINAL_SEAM_LAYER) or bm.edges.layers.int.new(_ORIGINAL_SEAM_LAYER)
        for edge in getattr(bm, 'edges', []) or []:
            try:
                edge[layer] = 1 if bool(edge.seam) else 0
            except Exception:
                pass
        return layer
    except Exception:
        return None


def _original_seam_layer(bm):
    try:
        return bm.edges.layers.int.get(_ORIGINAL_SEAM_LAYER)
    except Exception:
        return None


def _edge_original_seam_score(edge, layer) -> float:
    if layer is None:
        return 0.0
    try:
        return 1.0 if int(edge[layer]) else 0.0
    except Exception:
        return 0.0


def _safe_norm3(vec) -> tuple[float, float, float]:
    try:
        x, y, z = float(vec[0]), float(vec[1]), float(vec[2])
    except Exception:
        try:
            x, y, z = float(vec.x), float(vec.y), float(vec.z)
        except Exception:
            return (0.0, 0.0, 1.0)
    length = math.sqrt(x * x + y * y + z * z)
    if length <= _EPS:
        return (0.0, 0.0, 1.0)
    return (x / length, y / length, z / length)


def _dot3(a: tuple[float, float, float], b: tuple[float, float, float]) -> float:
    return float(a[0]) * float(b[0]) + float(a[1]) * float(b[1]) + float(a[2]) * float(b[2])



def _single_island_seam_weight_settings(ws) -> dict[str, float | str]:
    """Read user-facing 0..100 seam-analysis weights for partial Single Island merges."""
    def pct(new_name: str, old_name: str | None, default: float) -> float:
        fallback = default
        if old_name:
            fallback = _float(ws, old_name, default, 0.0, 100.0)
        return _float(ws, new_name, fallback, 0.0, 100.0) / 100.0

    profile = _enum(ws, 'smart_standard_core_single_seam_profile', 'BALANCED')
    settings: dict[str, float | str] = {
        'profile': profile,
        'angle': pct('smart_standard_core_single_angle_weight', 'smart_standard_core_single_seam_angle_weight', 72.0),
        'stretch': pct('smart_standard_core_single_stretch_weight', 'smart_standard_core_single_seam_stretch_weight', 72.0),
        'loop': pct('smart_standard_core_single_loop_weight', 'smart_standard_core_single_seam_loop_weight', 62.0),
        'planarity': pct('smart_standard_core_single_planarity_weight', None, 55.0),
        'density': pct('smart_standard_core_single_density_weight', 'smart_standard_core_single_seam_area_weight', 55.0),
        'existing': pct('smart_standard_core_single_user_seam_weight', None, 80.0),
        'shared': pct('smart_standard_core_single_boundary_weight', 'smart_standard_core_single_seam_shared_boundary_weight', 46.0),
        'cleanup': pct('smart_standard_core_single_small_island_merge', 'smart_standard_core_single_seam_jagged_cleanup_weight', 42.0),
    }
    # Presets now write the exposed numeric values directly.  Do not apply hidden
    # profile multipliers here; otherwise the UI values and actual solver weights
    # would diverge, which made the seam-analysis controls appear nonfunctional.
    # The dynamic chart-area guard reuses density so old call-sites still work.
    settings['area'] = max(0.0, min(1.0, float(settings.get('density', 0.55))))
    return settings


def _safe_ratio_log_error(value: float, target: float, scale: float = 0.5) -> float:
    """Return a stable 0..1 logarithmic ratio error."""
    try:
        value = max(_EPS, float(value))
        target = max(_EPS, float(target))
        err = abs(math.log(value / target)) * float(scale)
    except Exception:
        return 0.0
    if not math.isfinite(err):
        return 1.0
    return max(0.0, min(1.0, err))


def _edge_3d_length(edge) -> float:
    try:
        return max(_EPS, float(edge.calc_length()))
    except Exception:
        try:
            return max(_EPS, float((edge.verts[0].co - edge.verts[1].co).length))
        except Exception:
            return _EPS


def _edge_dihedral_ratio(edge) -> float:
    """Return a normalized fold angle: 0 for coplanar, 1 for a 180-degree fold."""
    try:
        faces = list(getattr(edge, 'link_faces', []) or [])
        if len(faces) < 2:
            return 0.0
        best = 0.0
        for i in range(len(faces)):
            for j in range(i + 1, len(faces)):
                dot = max(-1.0, min(1.0, float(faces[i].normal.dot(faces[j].normal))))
                best = max(best, math.acos(dot) / math.pi)
        return max(0.0, min(1.0, best))
    except Exception:
        return 0.0


def _uv_edge_length_from_loop(loop, uv_layer) -> float:
    try:
        a = loop[uv_layer].uv
        b = loop.link_loop_next[uv_layer].uv
        return math.hypot(float(b.x) - float(a.x), float(b.y) - float(a.y))
    except Exception:
        return 0.0


def _face_uv_edge_stretch_score(face, uv_layer, density: float) -> float:
    """Estimate current UV tension using edge-length and face-area density errors."""
    try:
        loops = list(getattr(face, 'loops', []) or [])
    except Exception:
        loops = []
    if len(loops) < 3:
        return 0.0
    length_density = math.sqrt(max(_EPS, float(density)))
    edge_errors = []
    for loop in loops:
        try:
            uv_len = _uv_edge_length_from_loop(loop, uv_layer)
            mesh_len = max(_EPS, float((loop.vert.co - loop.link_loop_next.vert.co).length))
            edge_errors.append(_safe_ratio_log_error(uv_len, mesh_len * length_density, 0.45))
        except Exception:
            pass
    mesh_area = _face_mesh_area(face)
    uv_area = _face_uv_area(face, uv_layer)
    area_err = _safe_ratio_log_error(uv_area, mesh_area * max(_EPS, float(density)), 0.42) if mesh_area > _EPS else 0.0
    if edge_errors:
        edge_err = sum(edge_errors) / float(len(edge_errors))
        return max(0.0, min(1.0, 0.58 * edge_err + 0.42 * area_err))
    return max(0.0, min(1.0, area_err))


def _boundary_loop_continuity_scores(boundary_edges: set) -> dict:
    """Score edges that form long, straight edge-loop-like UV boundaries."""
    if not boundary_edges:
        return {}
    vertex_edges: dict[object, list] = {}
    for edge in boundary_edges:
        try:
            vertex_edges.setdefault(edge.verts[0], []).append(edge)
            vertex_edges.setdefault(edge.verts[1], []).append(edge)
        except Exception:
            pass
    visited = set()
    component_by_edge = {}
    for start in list(boundary_edges):
        if start in visited:
            continue
        comp = set()
        stack = [start]
        visited.add(start)
        while stack:
            edge = stack.pop()
            comp.add(edge)
            for vert in getattr(edge, 'verts', []) or []:
                for other in vertex_edges.get(vert, ()):
                    if other not in visited:
                        visited.add(other)
                        stack.append(other)
        for edge in comp:
            component_by_edge[edge] = comp

    def straightness_at(edge, vert) -> float:
        try:
            others = [e for e in vertex_edges.get(vert, ()) if e is not edge]
            if not others:
                return 0.0
            other_vert = edge.other_vert(vert)
            base = other_vert.co - vert.co
            base_len = float(base.length)
            if base_len <= _EPS:
                return 0.0
            best = 0.0
            for other in others:
                ov = other.other_vert(vert)
                vec = ov.co - vert.co
                vec_len = float(vec.length)
                if vec_len <= _EPS:
                    continue
                dot = max(-1.0, min(1.0, float(base.dot(vec) / (base_len * vec_len))))
                # Both vectors start at the vertex; a straight continuation points opposite.
                best = max(best, (1.0 - dot) * 0.5)
            return best
        except Exception:
            return 0.0

    scores = {}
    for edge in boundary_edges:
        comp = component_by_edge.get(edge) or {edge}
        comp_len_score = max(0.0, min(1.0, math.log1p(float(len(comp))) / math.log1p(24.0)))
        svals = []
        for vert in getattr(edge, 'verts', []) or []:
            deg = len(vertex_edges.get(vert, ()))
            if deg == 2:
                svals.append(straightness_at(edge, vert))
            elif deg > 2:
                svals.append(0.20)
            else:
                svals.append(0.0)
        straight = sum(svals) / float(len(svals)) if svals else 0.0
        scores[edge] = max(0.0, min(1.0, 0.48 * comp_len_score + 0.52 * straight))
    return scores


def _build_single_island_merge_infos(bm, uv_layer, labels: dict, island_count: int, settings: dict[str, float], strength: float, scope: dict | None = None) -> tuple[list[dict[str, object]], dict[int, float], float]:
    """Analyze chart-boundary pairs for partial Single Island seam removal.

    Lower merge costs are removed first.  The cost combines hard-angle retention,
    current UV stretch/tension, edge-loop continuity, shared-boundary compatibility,
    cleanup of fragmented borders, and later a dynamic chart-area term.
    """
    try:
        mesh_total, _uv_total, density = _mesh_uv_area_density(bm, uv_layer, labels, scope)
    except Exception:
        mesh_total, density = 0.0, 0.0
    if density <= _EPS:
        density = 1.0
    island_area = {i: 0.0 for i in range(max(0, int(island_count)))}
    island_uv_area = {i: 0.0 for i in range(max(0, int(island_count)))}
    island_normal_sum = {i: [0.0, 0.0, 0.0] for i in range(max(0, int(island_count)))}
    face_stretch = {}
    for face in getattr(bm, 'faces', []) or []:
        label = labels.get(face)
        if label is None:
            continue
        label = int(label)
        area = _face_mesh_area(face)
        island_area[label] = island_area.get(label, 0.0) + area
        island_uv_area[label] = island_uv_area.get(label, 0.0) + _face_uv_area(face, uv_layer)
        try:
            n = face.normal
            row = island_normal_sum.setdefault(label, [0.0, 0.0, 0.0])
            row[0] += float(n.x) * max(area, _EPS)
            row[1] += float(n.y) * max(area, _EPS)
            row[2] += float(n.z) * max(area, _EPS)
        except Exception:
            pass
        face_stretch[face] = _face_uv_edge_stretch_score(face, uv_layer, density)
    island_normals = {idx: _safe_norm3(vals) for idx, vals in island_normal_sum.items()}
    original_seam_layer = _original_seam_layer(bm)
    if mesh_total <= _EPS:
        mesh_total = sum(island_area.values()) or 1.0

    boundary_edges = set()
    pair_edges: dict[tuple[int, int], set] = {}
    edge_face_pairs: dict[object, list[tuple[object, object]]] = {}
    for edge in getattr(bm, 'edges', []) or []:
        linked_faces = list(getattr(edge, 'link_faces', []) or [])
        if len(linked_faces) < 2:
            continue
        for i in range(len(linked_faces)):
            for j in range(i + 1, len(linked_faces)):
                a = labels.get(linked_faces[i])
                b = labels.get(linked_faces[j])
                if a is None or b is None or a == b:
                    continue
                pair = tuple(sorted((int(a), int(b))))
                pair_edges.setdefault(pair, set()).add(edge)
                edge_face_pairs.setdefault(edge, []).append((linked_faces[i], linked_faces[j]))
                boundary_edges.add(edge)
    if not pair_edges:
        return [], island_area, float(mesh_total)

    loop_scores = _boundary_loop_continuity_scores(boundary_edges)
    angle_w = float(settings.get('angle', 0.72))
    stretch_w = float(settings.get('stretch', 0.72))
    loop_w = float(settings.get('loop', 0.62))
    planarity_w = float(settings.get('planarity', 0.55))
    density_w = float(settings.get('density', 0.55))
    existing_w = float(settings.get('existing', 0.80))
    shared_w = float(settings.get('shared', 0.46))
    cleanup_w = float(settings.get('cleanup', 0.42))
    amount = max(0.0, min(1.0, float(strength)))
    infos = []
    for pair, edges in pair_edges.items():
        if not edges:
            continue
        weighted_len = 0.0
        angle_sum = 0.0
        stretch_sum = 0.0
        loop_sum = 0.0
        original_sum = 0.0
        length_sum = 0.0
        for edge in edges:
            length = _edge_3d_length(edge)
            weighted_len += length
            length_sum += length
            angle_sum += _edge_dihedral_ratio(edge) * length
            loop_sum += float(loop_scores.get(edge, 0.0)) * length
            original_sum += _edge_original_seam_score(edge, original_seam_layer) * length
            local_stretch_vals = []
            for f0, f1 in edge_face_pairs.get(edge, ()):
                local_stretch_vals.append(float(face_stretch.get(f0, 0.0)))
                local_stretch_vals.append(float(face_stretch.get(f1, 0.0)))
            if local_stretch_vals:
                stretch_sum += (sum(local_stretch_vals) / float(len(local_stretch_vals))) * length
        denom = max(_EPS, weighted_len)
        angle_score = max(0.0, min(1.0, angle_sum / denom))
        stretch_score = max(0.0, min(1.0, stretch_sum / denom))
        loop_score = max(0.0, min(1.0, loop_sum / denom))
        original_score = max(0.0, min(1.0, original_sum / denom))
        area_pair = max(_EPS, island_area.get(pair[0], 0.0) + island_area.get(pair[1], 0.0))
        shared_bonus = max(0.0, min(1.0, length_sum / max(_EPS, math.sqrt(area_pair))))
        try:
            na = island_normals.get(pair[0], (0.0, 0.0, 1.0))
            nb = island_normals.get(pair[1], (0.0, 0.0, 1.0))
            planarity_score = max(0.0, min(1.0, math.acos(max(-1.0, min(1.0, _dot3(na, nb)))) / math.radians(92.0)))
        except Exception:
            planarity_score = 0.0
        try:
            ma = max(_EPS, float(island_area.get(pair[0], 0.0)))
            mb = max(_EPS, float(island_area.get(pair[1], 0.0)))
            da = max(_EPS, float(island_uv_area.get(pair[0], 0.0)) / ma)
            db = max(_EPS, float(island_uv_area.get(pair[1], 0.0)) / mb)
            density_score = max(0.0, min(1.0, abs(math.log(da / db)) / 2.25))
        except Exception:
            density_score = 0.0
        ragged_bonus = 1.0 - loop_score
        small_fragment_bonus = max(0.0, min(1.0, 1.0 - (min(max(_EPS, island_area.get(pair[0], 0.0)), max(_EPS, island_area.get(pair[1], 0.0))) / max(max(_EPS, island_area.get(pair[0], 0.0)), max(_EPS, island_area.get(pair[1], 0.0))))))
        compatible_bonus = max(0.0, 1.0 - max(angle_score, planarity_score))
        base_cost = 0.03
        base_cost += angle_w * 1.45 * angle_score
        base_cost += stretch_w * 1.18 * stretch_score
        base_cost += loop_w * 0.98 * loop_score
        base_cost += planarity_w * 0.92 * planarity_score
        base_cost += density_w * 0.62 * density_score
        base_cost += existing_w * 1.30 * original_score
        base_cost -= shared_w * (0.52 + 0.22 * amount) * shared_bonus * (1.0 - 0.35 * original_score)
        base_cost -= cleanup_w * 0.36 * ragged_bonus * (1.0 - 0.55 * original_score)
        base_cost -= cleanup_w * 0.28 * small_fragment_bonus * compatible_bonus * (1.0 - loop_score * loop_w) * (1.0 - original_score)
        infos.append({
            'pair': pair,
            'edges': edges,
            'base_cost': float(base_cost),
            'angle': angle_score,
            'stretch': stretch_score,
            'loop': loop_score,
            'planarity': planarity_score,
            'density': density_score,
            'existing': original_score,
            'shared': shared_bonus,
            'length': length_sum,
        })
    infos.sort(key=lambda row: (float(row.get('base_cost', 0.0)), row.get('pair', (0, 0))))
    return infos, island_area, float(mesh_total)

def _apply_minimal_single_island_cut(bm, preferred_edges=None) -> int:
    """Clear island-splitting seams and add non-separating solve cuts when needed.

    Closed components need a slit for Blender's unwrap solver, but that slit must
    not split the UV into multiple islands.  A short-to-long vertex path across the
    component creates a usable opening while keeping the face graph connected.
    """
    try:
        bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
        bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
    except Exception:
        pass
    for edge in bm.edges:
        try:
            edge.seam = False
            edge.smooth = True
        except Exception:
            pass
    faces = list(getattr(bm, 'faces', []) or [])
    if not faces:
        return 0

    def mark_path_for_component(component_edges: set) -> int:
        verts = set()
        for edge in component_edges:
            try:
                verts.add(edge.verts[0]); verts.add(edge.verts[1])
            except Exception:
                pass
        verts = [v for v in verts if v is not None]
        if len(verts) < 2:
            return 0
        try:
            spans = []
            for axis in range(3):
                vals = [float(v.co[axis]) for v in verts]
                spans.append(max(vals) - min(vals))
            axis = max(range(3), key=lambda i: spans[i])
            start_vert = min(verts, key=lambda v: float(v.co[axis]))
            end_vert = max(verts, key=lambda v: float(v.co[axis]))
        except Exception:
            start_vert = verts[0]
            end_vert = verts[-1]
        if start_vert is end_vert:
            return 0
        allowed = set(component_edges)
        queue = [start_vert]
        visited = {start_vert}
        previous = {}
        while queue:
            current = queue.pop(0)
            if current is end_vert:
                break
            for edge in getattr(current, 'link_edges', []) or []:
                if edge not in allowed:
                    continue
                try:
                    other = edge.other_vert(current)
                except Exception:
                    continue
                if other in visited:
                    continue
                visited.add(other)
                previous[other] = (current, edge)
                queue.append(other)
        marked = 0
        if end_vert in visited:
            current = end_vert
            while current is not start_vert:
                prev = previous.get(current)
                if prev is None:
                    break
                current, edge = prev
                try:
                    edge.seam = True
                    edge.smooth = True
                    marked += 1
                except Exception:
                    pass
        if marked <= 0:
            try:
                cut_edge = min(component_edges, key=_seam_priority_for_single_island)
                cut_edge.seam = True
                cut_edge.smooth = True
                marked = 1
            except Exception:
                marked = 0
        return marked

    marked_total = 0
    visited = set()
    for start_face in faces:
        if start_face in visited:
            continue
        component_edges = set()
        has_boundary = False
        queue = [start_face]
        visited.add(start_face)
        while queue:
            face = queue.pop(0)
            for edge in face.edges:
                component_edges.add(edge)
                linked = list(getattr(edge, 'link_faces', []) or [])
                if len(linked) < 2:
                    has_boundary = True
                for other in linked:
                    if other is face or other in visited:
                        continue
                    visited.add(other)
                    queue.append(other)
        if has_boundary:
            continue
        marked_total += mark_path_for_component(component_edges)
    return marked_total


def _uv_key_for_single_island(uv, eps: float = 1.0e-5) -> tuple[int, int]:
    try:
        return (int(round(float(uv.x) / eps)), int(round(float(uv.y) / eps)))
    except Exception:
        return (0, 0)


def _edge_loops_share_uv_edge(loop_a, loop_b, uv_layer, eps: float = 1.0e-5) -> bool:
    """Return True when two face loops are welded on the same UV edge."""
    try:
        a0 = int(loop_a.vert.index)
        a1 = int(loop_a.link_loop_next.vert.index)
        b0 = int(loop_b.vert.index)
        b1 = int(loop_b.link_loop_next.vert.index)
        a_uv = {
            a0: _uv_key_for_single_island(loop_a[uv_layer].uv, eps),
            a1: _uv_key_for_single_island(loop_a.link_loop_next[uv_layer].uv, eps),
        }
        b_uv = {
            b0: _uv_key_for_single_island(loop_b[uv_layer].uv, eps),
            b1: _uv_key_for_single_island(loop_b.link_loop_next[uv_layer].uv, eps),
        }
        shared = set(a_uv).intersection(b_uv)
        return len(shared) == 2 and all(a_uv[v] == b_uv[v] for v in shared)
    except Exception:
        return False


def _build_uv_face_island_labels(bm, uv_layer, scope: dict | None = None) -> tuple[dict, int]:
    """Label faces by current UV connectivity before any Single Island seam changes."""
    try:
        bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
        bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
    except Exception:
        pass
    face_layer = _scope_face_layer(bm)
    faces = [face for face in (getattr(bm, 'faces', []) or []) if _face_in_uv_scope(face, scope, face_layer)]
    adjacency = {face: set() for face in faces}
    face_set = set(faces)
    for edge in getattr(bm, 'edges', []) or []:
        loops = list(getattr(edge, 'link_loops', []) or [])
        if len(loops) < 2:
            continue
        for i in range(len(loops)):
            for j in range(i + 1, len(loops)):
                a = loops[i]
                b = loops[j]
                if a.face is b.face or a.face not in face_set or b.face not in face_set:
                    continue
                if _edge_loops_share_uv_edge(a, b, uv_layer):
                    adjacency.setdefault(a.face, set()).add(b.face)
                    adjacency.setdefault(b.face, set()).add(a.face)
    labels = {}
    visited = set()
    label = 0
    for face in faces:
        if face in visited:
            continue
        stack = [face]
        visited.add(face)
        while stack:
            current = stack.pop()
            labels[current] = label
            for other in adjacency.get(current, ()):
                if other not in visited:
                    visited.add(other)
                    stack.append(other)
        label += 1
    return labels, label


def _uv_polygon_signed_area(coords: list[tuple[float, float]]) -> float:
    """Signed 2D polygon area in UV space."""
    if len(coords) < 3:
        return 0.0
    area2 = 0.0
    prev_u, prev_v = coords[-1]
    for u, v in coords:
        area2 += prev_u * v - u * prev_v
        prev_u, prev_v = u, v
    return area2 * 0.5


def _face_uv_area(face, uv_layer) -> float:
    """Absolute UV polygon area for a BMesh face."""
    try:
        coords = [(float(loop[uv_layer].uv.x), float(loop[uv_layer].uv.y)) for loop in face.loops]
        return abs(_uv_polygon_signed_area(coords))
    except Exception:
        return 0.0


def _face_mesh_area(face) -> float:
    """Original mesh-space face area used as the authoritative texel-density source."""
    try:
        return max(0.0, float(face.calc_area()))
    except Exception:
        return 0.0


def _mesh_uv_area_density(bm, uv_layer, labels: dict | None = None, scope: dict | None = None) -> tuple[float, float, float]:
    """Return (mesh area total, UV area total, target UV area per mesh-area unit)."""
    mesh_total = 0.0
    uv_total = 0.0
    face_layer = _scope_face_layer(bm)
    for face in getattr(bm, 'faces', []) or []:
        if labels is not None and face not in labels:
            continue
        if labels is None and not _face_in_uv_scope(face, scope, face_layer):
            continue
        mesh_total += _face_mesh_area(face)
        uv_total += _face_uv_area(face, uv_layer)
    if mesh_total <= _EPS:
        density = 1.0
    elif uv_total <= _EPS:
        density = 1.0 / mesh_total
    else:
        density = uv_total / mesh_total
    return mesh_total, uv_total, density


def _scale_uv_islands_to_mesh_area_ratio(bm, uv_layer, *, strength: float = 1.0, scope: dict | None = None) -> bool:
    """Scale UV islands toward mesh-area-correct texel density.

    ``strength`` is 0..1. 0 keeps the native unwrap result unchanged; 1 fully
    normalizes each island so its UV area follows the source mesh area ratio.
    Only uniform island scaling is applied here, so this pass corrects chart
    ratios without twisting the chart internals.
    """
    try:
        strength = max(0.0, min(1.0, float(strength)))
    except Exception:
        strength = 1.0
    if strength <= _EPS:
        return False
    try:
        labels, count = _build_uv_face_island_labels(bm, uv_layer, scope)
    except Exception:
        return False
    if count <= 0:
        return False
    _mesh_total, _uv_total, density = _mesh_uv_area_density(bm, uv_layer, labels, scope)
    islands: dict[int, dict[str, object]] = {}
    for face, label in labels.items():
        entry = islands.setdefault(int(label), {'faces': [], 'loops': set(), 'mesh_area': 0.0, 'uv_area': 0.0})
        entry['faces'].append(face)
        entry['loops'].update(list(getattr(face, 'loops', []) or []))
        entry['mesh_area'] = float(entry['mesh_area']) + _face_mesh_area(face)
        entry['uv_area'] = float(entry['uv_area']) + _face_uv_area(face, uv_layer)
    changed = False
    for entry in islands.values():
        mesh_area = float(entry.get('mesh_area') or 0.0)
        uv_area = float(entry.get('uv_area') or 0.0)
        loops = list(entry.get('loops') or [])
        if mesh_area <= _EPS or uv_area <= _EPS or not loops:
            continue
        target_uv_area = mesh_area * density
        if target_uv_area <= _EPS:
            continue
        full_scale = math.sqrt(max(_EPS, target_uv_area) / max(_EPS, uv_area))
        if not math.isfinite(full_scale):
            continue
        scale = 1.0 + (max(0.02, min(50.0, float(full_scale))) - 1.0) * strength
        if abs(scale - 1.0) <= 1.0e-6:
            continue
        sum_u = 0.0
        sum_v = 0.0
        for loop in loops:
            sum_u += float(loop[uv_layer].uv.x)
            sum_v += float(loop[uv_layer].uv.y)
        center_u = sum_u / max(1, len(loops))
        center_v = sum_v / max(1, len(loops))
        for loop in loops:
            luv = loop[uv_layer].uv
            luv.x = (float(luv.x) - center_u) * scale + center_u
            luv.y = (float(luv.y) - center_v) * scale + center_v
        changed = True
    return changed

def _relax_uv_faces_to_mesh_area(bm, uv_layer, *, iterations: int = 18, blend: float = 0.32, scope: dict | None = None) -> bool:
    """Iteratively reduce per-face UV area error using original mesh face areas.

    This is an area-gradient correction, not a coordinate blend.  Each face keeps
    its current orientation and receives a damped least-squares update toward
    ``mesh_face_area * global_uv_density``.  Updates are accumulated on welded
    UV-vertex groups per island, so connected charts remain connected while the
    face-area ratios move toward the source mesh area ratios.
    """
    try:
        labels, count = _build_uv_face_island_labels(bm, uv_layer, scope)
    except Exception:
        return False
    if count <= 0:
        return False
    _mesh_total, _uv_total, density = _mesh_uv_area_density(bm, uv_layer, labels, scope)
    if density <= _EPS:
        return False
    groups: dict[tuple[int, int, int, int], dict[str, object]] = {}
    face_entries = []
    eps = 1.0e-7
    for face in getattr(bm, 'faces', []) or []:
        label = int(labels.get(face, -1))
        if label < 0:
            continue
        keys = []
        for loop in getattr(face, 'loops', []) or []:
            try:
                uv = loop[uv_layer].uv
                key = (label, int(loop.vert.index), int(round(float(uv.x) / eps)), int(round(float(uv.y) / eps)))
            except Exception:
                continue
            entry = groups.setdefault(key, {'loops': [], 'u': 0.0, 'v': 0.0, 'count': 0})
            entry['loops'].append(loop)
            entry['u'] = float(entry['u']) + float(loop[uv_layer].uv.x)
            entry['v'] = float(entry['v']) + float(loop[uv_layer].uv.y)
            entry['count'] = int(entry['count']) + 1
            keys.append(key)
        mesh_area = _face_mesh_area(face)
        if len(keys) >= 3 and mesh_area > _EPS:
            coords = []
            for key in keys:
                entry = groups.get(key)
                if entry is None:
                    continue
                c = max(1, int(entry.get('count') or 1))
                coords.append((float(entry.get('u') or 0.0) / c, float(entry.get('v') or 0.0) / c))
            signed = _uv_polygon_signed_area(coords) if len(coords) >= 3 else 0.0
            orientation = -1.0 if signed < 0.0 else 1.0
            face_entries.append((keys, mesh_area, orientation))
    if not groups or not face_entries:
        return False
    coords_by_key: dict[tuple[int, int, int, int], list[float]] = {}
    for key, entry in groups.items():
        c = max(1, int(entry.get('count') or 1))
        coords_by_key[key] = [float(entry.get('u') or 0.0) / c, float(entry.get('v') or 0.0) / c]
    iterations = max(0, min(160, int(iterations)))
    blend = max(0.0, min(1.0, float(blend)))
    if iterations <= 0 or blend <= _EPS:
        return False
    changed = False
    for _ in range(iterations):
        accum: dict[tuple[int, int, int, int], list[float]] = {}
        for keys, mesh_area, orientation in face_entries:
            pts = [coords_by_key.get(key) for key in keys]
            if len(pts) < 3 or any(pt is None for pt in pts):
                continue
            coords = [(float(pt[0]), float(pt[1])) for pt in pts]
            signed_area = _uv_polygon_signed_area(coords)
            target_area = float(orientation) * max(_EPS, float(mesh_area) * density)
            error = signed_area - target_area
            if abs(error) <= max(1.0e-10, abs(target_area) * 1.0e-5):
                continue
            n = len(coords)
            grads = []
            denom = 0.0
            for i in range(n):
                prev_u, prev_v = coords[(i - 1) % n]
                next_u, next_v = coords[(i + 1) % n]
                # d(signed polygon area)/d(u_i, v_i)
                gx = 0.5 * (next_v - prev_v)
                gy = 0.5 * (prev_u - next_u)
                grads.append((gx, gy))
                denom += gx * gx + gy * gy
            if denom <= _EPS:
                continue
            # Least-squares area correction, damped and clamped by face size.
            factor = -blend * error / denom
            us = [p[0] for p in coords]
            vs = [p[1] for p in coords]
            diag = math.hypot(max(us) - min(us), max(vs) - min(vs))
            max_step = max(1.0e-6, diag * 0.12)
            raw_steps = [(factor * gx, factor * gy) for gx, gy in grads]
            biggest = max((math.hypot(du, dv) for du, dv in raw_steps), default=0.0)
            if biggest > max_step:
                scale = max_step / max(biggest, _EPS)
                raw_steps = [(du * scale, dv * scale) for du, dv in raw_steps]
            for key, (du, dv) in zip(keys, raw_steps):
                row = accum.setdefault(key, [0.0, 0.0, 0.0])
                row[0] += du
                row[1] += dv
                row[2] += 1.0
        if not accum:
            break
        max_delta = 0.0
        for key, row in accum.items():
            denom = max(1.0, float(row[2]))
            du = row[0] / denom
            dv = row[1] / denom
            coords_by_key[key][0] += du
            coords_by_key[key][1] += dv
            max_delta = max(max_delta, abs(du), abs(dv))
        changed = True
        if max_delta <= 1.0e-9:
            break
    if not changed:
        return False
    for key, entry in groups.items():
        coord = coords_by_key.get(key)
        if coord is None:
            continue
        for loop in entry.get('loops') or []:
            try:
                loop[uv_layer].uv.x = float(coord[0])
                loop[uv_layer].uv.y = float(coord[1])
            except Exception:
                pass
    return True


def _sus_uv_opt_key(loop, label: int, uv_layer, eps: float = 1.0e-7) -> tuple[int, int, int, int]:
    """Stable welded-UV key used by the post-unwrap optimizer."""
    try:
        uv = loop[uv_layer].uv
        return (int(label), int(loop.vert.index), int(round(float(uv.x) / eps)), int(round(float(uv.y) / eps)))
    except Exception:
        return (int(label), -1, 0, 0)


def _signed_uv_area_from_key_coords(keys, coords_by_key) -> float:
    coords = []
    for key in keys:
        pt = coords_by_key.get(key)
        if pt is None:
            return 0.0
        coords.append((float(pt[0]), float(pt[1])))
    return _uv_polygon_signed_area(coords)


def _build_area_shape_optimization_data(bm, uv_layer, scope: dict | None = None):
    """Build welded vertices, face targets and edge/diagonal length targets.

    This is a lightweight local/global-style post process inspired by ARAP and
    minimum-stretch UV workflows: native Blender unwrap supplies the initial
    coordinates, then source mesh edge lengths and face areas become soft goals.
    """
    labels, count = _build_uv_face_island_labels(bm, uv_layer, scope)
    if count <= 0:
        return None
    mesh_total, uv_total, density = _mesh_uv_area_density(bm, uv_layer, labels, scope)
    if mesh_total <= _EPS or density <= _EPS:
        return None
    length_density = math.sqrt(max(_EPS, density))
    groups: dict[tuple[int, int, int, int], dict[str, object]] = {}
    face_entries = []
    edge_accum: dict[tuple[tuple[int, int, int, int], tuple[int, int, int, int]], list[float]] = {}

    def add_group(loop, label: int):
        key = _sus_uv_opt_key(loop, label, uv_layer)
        entry = groups.setdefault(key, {'loops': [], 'u': 0.0, 'v': 0.0, 'count': 0})
        entry['loops'].append(loop)
        entry['u'] = float(entry['u']) + float(loop[uv_layer].uv.x)
        entry['v'] = float(entry['v']) + float(loop[uv_layer].uv.y)
        entry['count'] = int(entry['count']) + 1
        return key

    def add_edge_goal(k1, k2, target_length: float, weight: float):
        if k1 == k2 or target_length <= _EPS or weight <= _EPS:
            return
        pair = (k1, k2) if k1 < k2 else (k2, k1)
        row = edge_accum.setdefault(pair, [0.0, 0.0])
        row[0] += float(target_length) * float(weight)
        row[1] += float(weight)

    for face in getattr(bm, 'faces', []) or []:
        label = int(labels.get(face, -1))
        if label < 0:
            continue
        loops = list(getattr(face, 'loops', []) or [])
        if len(loops) < 3:
            continue
        keys = [add_group(loop, label) for loop in loops]
        mesh_area = _face_mesh_area(face)
        if mesh_area > _EPS:
            coords = [(float(loop[uv_layer].uv.x), float(loop[uv_layer].uv.y)) for loop in loops]
            signed = _uv_polygon_signed_area(coords)
            orientation = -1.0 if signed < 0.0 else 1.0
            face_entries.append((keys, mesh_area, orientation))
        n = len(loops)
        # Boundary/perimeter edges preserve local length flow.
        for i in range(n):
            a = loops[i]
            b = loops[(i + 1) % n]
            try:
                length3d = float((a.vert.co - b.vert.co).length)
            except Exception:
                length3d = 0.0
            add_edge_goal(keys[i], keys[(i + 1) % n], length3d * length_density, 1.0)
        # Short diagonals suppress quad/shear collapse without forcing full rigidity
        # on very high-valence n-gons.
        if 4 <= n <= 8:
            for i in range(n):
                for j in range(i + 2, n):
                    if i == 0 and j == n - 1:
                        continue
                    try:
                        length3d = float((loops[i].vert.co - loops[j].vert.co).length)
                    except Exception:
                        length3d = 0.0
                    add_edge_goal(keys[i], keys[j], length3d * length_density, 0.35)
    if not groups or not face_entries:
        return None
    coords_by_key: dict[tuple[int, int, int, int], list[float]] = {}
    original_by_key: dict[tuple[int, int, int, int], tuple[float, float]] = {}
    for key, entry in groups.items():
        c = max(1, int(entry.get('count') or 1))
        u = float(entry.get('u') or 0.0) / c
        v = float(entry.get('v') or 0.0) / c
        coords_by_key[key] = [u, v]
        original_by_key[key] = (u, v)
    edge_entries = []
    for (k1, k2), row in edge_accum.items():
        weight = max(_EPS, float(row[1]))
        edge_entries.append((k1, k2, float(row[0]) / weight, min(4.0, weight)))
    return {
        'labels': labels,
        'count': count,
        'density': density,
        'groups': groups,
        'coords': coords_by_key,
        'original': original_by_key,
        'faces': face_entries,
        'edges': edge_entries,
    }


def _optimize_uv_area_shape_layout(
    bm,
    uv_layer,
    *,
    iterations: int = 32,
    quality_strength: float = 0.65,
    area_strength: float = 0.65,
    shape_strength: float = 0.45,
    original_preserve: float = 0.25,
    scope: dict | None = None,
) -> bool:
    """Weighted area/shape optimizer run after Blender's native unwrap.

    The native UV result is retained as an anchor.  ``quality_strength`` controls
    how far the result may move away from the original unwrap; ``area_strength``
    controls source-face-area matching; ``shape_strength`` controls 3D edge-length
    matching.  This avoids the previous area-only correction that could make UVs
    messy by pulling faces without any shape constraint.
    """
    try:
        q = max(0.0, min(1.0, float(quality_strength)))
        area_w = max(0.0, min(1.0, float(area_strength)))
        shape_w = max(0.0, min(1.0, float(shape_strength)))
        keep_w = max(0.0, min(1.0, float(original_preserve)))
        iterations = max(0, min(240, int(iterations)))
    except Exception:
        return False
    if q <= _EPS or iterations <= 0 or (area_w <= _EPS and shape_w <= _EPS):
        return False
    data = _build_area_shape_optimization_data(bm, uv_layer, scope)
    if not data:
        return False
    coords_by_key = data['coords']
    original_by_key = data['original']
    groups = data['groups']
    face_entries = data['faces']
    edge_entries = data['edges']
    density = float(data['density'])
    if density <= _EPS:
        return False

    area_step = 0.34 * q * area_w
    shape_step = 0.46 * q * shape_w
    # The anchor is deliberately soft.  Final blending below gives the exact
    # user-facing "keep native result" percentage, while this only prevents drift.
    anchor_step = 0.04 + 0.16 * keep_w + 0.08 * (1.0 - q)
    changed = False
    for _iter in range(iterations):
        accum: dict[tuple[int, int, int, int], list[float]] = {}

        if shape_step > _EPS:
            for k1, k2, target_len, weight in edge_entries:
                p1 = coords_by_key.get(k1)
                p2 = coords_by_key.get(k2)
                if p1 is None or p2 is None:
                    continue
                dx = float(p2[0]) - float(p1[0])
                dy = float(p2[1]) - float(p1[1])
                cur_len = math.hypot(dx, dy)
                if cur_len <= 1.0e-10 or target_len <= _EPS:
                    continue
                err = cur_len - float(target_len)
                ux = dx / cur_len
                uy = dy / cur_len
                step = max(-cur_len * 0.20, min(cur_len * 0.20, err * 0.5 * shape_step * max(0.25, min(2.0, float(weight)))))
                row = accum.setdefault(k1, [0.0, 0.0, 0.0])
                row[0] += ux * step
                row[1] += uy * step
                row[2] += 1.0
                row = accum.setdefault(k2, [0.0, 0.0, 0.0])
                row[0] -= ux * step
                row[1] -= uy * step
                row[2] += 1.0

        if area_step > _EPS:
            for keys, mesh_area, orientation in face_entries:
                pts = [coords_by_key.get(key) for key in keys]
                if len(pts) < 3 or any(pt is None for pt in pts):
                    continue
                coords = [(float(pt[0]), float(pt[1])) for pt in pts]
                signed_area = _uv_polygon_signed_area(coords)
                target_area = float(orientation) * max(_EPS, float(mesh_area) * density)
                error = signed_area - target_area
                if abs(error) <= max(1.0e-10, abs(target_area) * 1.0e-4):
                    continue
                denom = 0.0
                grads = []
                n = len(coords)
                for i in range(n):
                    prev_u, prev_v = coords[(i - 1) % n]
                    next_u, next_v = coords[(i + 1) % n]
                    gx = 0.5 * (next_v - prev_v)
                    gy = 0.5 * (prev_u - next_u)
                    grads.append((gx, gy))
                    denom += gx * gx + gy * gy
                if denom <= _EPS:
                    continue
                factor = -area_step * error / denom
                us = [p[0] for p in coords]
                vs = [p[1] for p in coords]
                diag = math.hypot(max(us) - min(us), max(vs) - min(vs))
                max_step = max(1.0e-6, diag * (0.035 + 0.045 * q))
                raw_steps = [(factor * gx, factor * gy) for gx, gy in grads]
                biggest = max((math.hypot(du, dv) for du, dv in raw_steps), default=0.0)
                if biggest > max_step:
                    scale = max_step / max(biggest, _EPS)
                    raw_steps = [(du * scale, dv * scale) for du, dv in raw_steps]
                for key, (du, dv) in zip(keys, raw_steps):
                    row = accum.setdefault(key, [0.0, 0.0, 0.0])
                    row[0] += du
                    row[1] += dv
                    row[2] += 1.0

        # Gentle attraction to the native unwrap keeps the original feature state
        # recoverable and prevents area-only folds on difficult non-developable parts.
        if anchor_step > _EPS:
            for key, orig in original_by_key.items():
                cur = coords_by_key.get(key)
                if cur is None:
                    continue
                du = (float(orig[0]) - float(cur[0])) * anchor_step
                dv = (float(orig[1]) - float(cur[1])) * anchor_step
                row = accum.setdefault(key, [0.0, 0.0, 0.0])
                row[0] += du
                row[1] += dv
                row[2] += 1.0

        if not accum:
            break
        max_delta = 0.0
        for key, row in accum.items():
            denom = max(1.0, float(row[2]))
            du = float(row[0]) / denom
            dv = float(row[1]) / denom
            cur = coords_by_key.get(key)
            if cur is None:
                continue
            cur[0] += du
            cur[1] += dv
            max_delta = max(max_delta, abs(du), abs(dv))
        changed = True
        if max_delta <= 1.0e-9:
            break
    if not changed:
        return False

    final_alpha = max(0.0, min(1.0, q * (1.0 - keep_w)))
    if final_alpha <= _EPS:
        return False
    # The solver steps have no fold check.  Each island backs off toward the native
    # result until none of its faces has turned over.
    faces_by_island: dict[int, list] = {}
    for keys, _mesh_area, _orientation in face_entries:
        faces_by_island.setdefault(int(keys[0][0]), []).append(keys)

    def _blend(key, alpha: float) -> tuple[float, float]:
        orig = original_by_key[key]
        coord = coords_by_key[key]
        return (float(orig[0]) * (1.0 - alpha) + float(coord[0]) * alpha,
                float(orig[1]) * (1.0 - alpha) + float(coord[1]) * alpha)

    def _keeps_orientation(faces, alpha: float) -> bool:
        for keys in faces:
            before = _uv_polygon_signed_area([original_by_key[key] for key in keys])
            if abs(before) > 1.0e-12 and before * _uv_polygon_signed_area([_blend(key, alpha) for key in keys]) <= 0.0:
                return False
        return True

    island_alpha: dict[int, float] = {}
    for label, faces in faces_by_island.items():
        alpha = final_alpha
        for _ in range(5):
            if _keeps_orientation(faces, alpha):
                break
            alpha *= 0.5
        else:
            alpha = 0.0
        island_alpha[label] = alpha
    for key, entry in groups.items():
        if key not in coords_by_key or key not in original_by_key:
            continue
        out_u, out_v = _blend(key, island_alpha.get(int(key[0]), final_alpha))
        for loop in entry.get('loops') or []:
            try:
                loop[uv_layer].uv.x = out_u
                loop[uv_layer].uv.y = out_v
            except Exception:
                pass
    return True


def _apply_mesh_area_preserving_uv_layout(
    me,
    *,
    iterations: int = 32,
    blend: float = 0.32,
    quality_strength: float = 0.65,
    area_strength: float = 0.65,
    shape_strength: float = 0.45,
    original_preserve: float = 0.25,
    scope: dict | None = None,
) -> bool:
    """Apply weighted quality passes to the active edit mesh.

    0% quality keeps the native unwrap result.  Higher values use a balanced
    sequence: island texel-density correction, edge-length/area local optimization,
    and a second density correction.  Area and shape are separate strengths so the
    user can choose between real-scale UVs and a less modified native layout.
    """
    try:
        q = max(0.0, min(1.0, float(quality_strength)))
        area_w = max(0.0, min(1.0, float(area_strength)))
        shape_w = max(0.0, min(1.0, float(shape_strength)))
        keep_w = max(0.0, min(1.0, float(original_preserve)))
        iterations = max(0, min(240, int(iterations)))
    except Exception:
        return False
    if q <= _EPS or iterations <= 0 or (area_w <= _EPS and shape_w <= _EPS):
        return False
    try:
        bm = bmesh.from_edit_mesh(me)
        uv_layer = _active_uv_layer(bm)
        bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
        bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
        changed = False
        # Local/global-style edge and area goals improve face quality while the
        # native unwrap remains the anchor. Run this before chart scaling so
        # "標準結果維持" preserves the actual Blender unwrap result.
        changed = _optimize_uv_area_shape_layout(
            bm,
            uv_layer,
            iterations=iterations,
            quality_strength=q,
            area_strength=area_w,
            shape_strength=shape_w,
            original_preserve=keep_w,
            scope=scope,
        ) or changed
        # Chart-level texel-density correction after optimization fixes island
        # size ratios without twisting the chart internals.  It is also governed
        # by Native Result Keep, so 100% keep returns to the original layout.
        density_strength = q * area_w * (1.0 - keep_w)
        changed = _scale_uv_islands_to_mesh_area_ratio(bm, uv_layer, strength=density_strength, scope=scope) or changed
        if changed:
            bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
        return bool(changed)
    except Exception:
        return False

def _single_island_face_components(bm, scope: dict | None = None) -> list[tuple[set, set, bool]]:
    """Return mesh face components as (faces, edges, has_open_boundary)."""
    try:
        bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
        bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
    except Exception:
        pass
    visited = set()
    components = []
    face_layer = _scope_face_layer(bm)
    scoped_faces = {face for face in (getattr(bm, 'faces', []) or []) if _face_in_uv_scope(face, scope, face_layer)}
    for start in list(scoped_faces):
        if start in visited:
            continue
        faces = {start}
        edges = set()
        has_boundary = False
        queue = [start]
        visited.add(start)
        while queue:
            face = queue.pop(0)
            for edge in getattr(face, 'edges', []) or []:
                edges.add(edge)
                linked = list(getattr(edge, 'link_faces', []) or [])
                if len(linked) < 2:
                    has_boundary = True
                for other in linked:
                    if other not in scoped_faces:
                        continue
                    if other is face or other in visited:
                        continue
                    visited.add(other)
                    faces.add(other)
                    queue.append(other)
        components.append((faces, edges, has_boundary))
    return components


def _single_island_target_seams(bm, scope: dict | None = None) -> set:
    """Create a solver-safe seam target for the 100% Single アイランド state.

    Simply clearing every seam makes closed meshes collapse or unwrap into a line.
    For closed components this keeps a connected spanning tree of face adjacencies
    welded, and marks the remaining internal edges as cuts.  The UV face graph
    remains connected, so the result is one clean island per mesh component.
    """
    target = set()
    for faces, edges, has_boundary in _single_island_face_components(bm, scope):
        internal_edges = [edge for edge in edges if len(list(getattr(edge, 'link_faces', []) or [])) >= 2]
        if not internal_edges:
            continue
        if has_boundary:
            # Open components already have a physical chart boundary.  Removing
            # internal seams lets them unwrap as one island without adding cuts.
            continue
        start = next(iter(faces), None)
        if start is None:
            continue
        connected = {start}
        tree_edges = set()
        candidates = []
        def add_candidates(face):
            for edge in getattr(face, 'edges', []) or []:
                linked = [f for f in (getattr(edge, 'link_faces', []) or []) if f in faces]
                if len(linked) < 2:
                    continue
                other = linked[0] if linked[1] is face else linked[1]
                if other in connected:
                    continue
                candidates.append((_seam_priority_for_single_island(edge), int(getattr(edge, 'index', 0)), edge, other))
        add_candidates(start)
        while len(connected) < len(faces) and candidates:
            candidates.sort(key=lambda item: (item[0], item[1]))
            _priority, _idx, edge, other = candidates.pop(0)
            if other in connected:
                continue
            connected.add(other)
            tree_edges.add(edge)
            add_candidates(other)
        for edge in internal_edges:
            if edge not in tree_edges:
                target.add(edge)
    return target


def _apply_clean_single_island_target_seams(bm, scope: dict | None = None) -> int:
    """Apply the 100% Single アイランド seam target and return changed edge count.

    Closed components keep a connected non-seam face graph and receive only the
    solver cuts needed for a valid flattening.  This avoids the previous all-seam
    or no-seam extremes while still aiming at a single visible UV island.
    """
    target = _single_island_target_seams(bm, scope)
    changed = 0
    face_layer = _scope_face_layer(bm)
    for edge in list(getattr(bm, 'edges', []) or []):
        if not _edge_has_scope_face(edge, scope, face_layer):
            continue
        try:
            new_value = edge in target
            if bool(edge.seam) != bool(new_value):
                changed += 1
            edge.seam = bool(new_value)
            if not new_value:
                edge.smooth = True
        except Exception:
            pass
    return changed


def _apply_progressive_single_island_seams(bm, uv_layer, strength: float, settings: dict[str, float] | None = None, scope: dict | None = None) -> int:
    """Merge UV island boundary groups with weighted seam-quality analysis.

    The initial unwrap is treated as a chart graph.  For each boundary between
    UV islands, the algorithm evaluates hard-angle importance, current UV
    stretch/tension, loop continuity, shared-border compatibility, fragmented
    boundary cleanup, and dynamic chart-area growth.  The Single アイランド
    percentage controls how many charts are merged; the exposed weights control
    which seams are removed first.
    """
    amount = _smooth_single_island_strength(strength)
    if amount <= _EPS:
        return 0
    if settings is None:
        settings = {}
    labels, island_count = _build_uv_face_island_labels(bm, uv_layer, scope)
    boundary_edges = set()
    face_layer = _scope_face_layer(bm)
    for edge in getattr(bm, 'edges', []) or []:
        linked_faces = [face for face in (getattr(edge, 'link_faces', []) or []) if face in labels]
        if not linked_faces:
            continue
        if len(linked_faces) < 2:
            try:
                # A selected face touching unselected geometry is a temporary
                # chart boundary for this scoped solve.
                edge.seam = True if _scope_is_active(scope) and _edge_has_scope_face(edge, scope, face_layer) else False
            except Exception:
                pass
            continue
        found_boundary = False
        for i in range(len(linked_faces)):
            for j in range(i + 1, len(linked_faces)):
                a = labels.get(linked_faces[i])
                b = labels.get(linked_faces[j])
                if a is None or b is None or a == b:
                    continue
                found_boundary = True
                boundary_edges.add(edge)
        try:
            edge.seam = bool(found_boundary)
        except Exception:
            pass
    if not boundary_edges or island_count <= 1:
        if amount >= 1.0 - _EPS:
            return _apply_clean_single_island_target_seams(bm, scope)
        return 0
    if amount >= 1.0 - _EPS:
        return _apply_clean_single_island_target_seams(bm, scope)

    # Use a smooth, non-abrupt easing so the middle range visibly joins charts
    # instead of looking unchanged until values near 100%.
    merge_amount = 1.0 - (1.0 - amount) * (1.0 - amount)
    target_count = int(math.floor((1.0 + (float(island_count) - 1.0) * (1.0 - merge_amount)) + 0.5))
    target_count = max(1, min(island_count, target_count))
    if target_count >= island_count:
        return 0
    if target_count <= 1:
        return _apply_clean_single_island_target_seams(bm, scope)

    merge_infos, island_area, mesh_total = _build_single_island_merge_infos(bm, uv_layer, labels, island_count, settings, amount, scope)
    if not merge_infos:
        return 0
    parent = list(range(island_count))
    group_area = {idx: max(_EPS, float(island_area.get(idx, 0.0))) for idx in range(island_count)}

    def find(idx: int) -> int:
        idx = int(idx)
        while parent[idx] != idx:
            parent[idx] = parent[parent[idx]]
            idx = parent[idx]
        return idx

    def union(a: int, b: int) -> bool:
        ra = find(a)
        rb = find(b)
        if ra == rb:
            return False
        if group_area.get(rb, 0.0) > group_area.get(ra, 0.0):
            ra, rb = rb, ra
        parent[rb] = ra
        group_area[ra] = max(_EPS, group_area.get(ra, 0.0) + group_area.get(rb, 0.0))
        return True

    area_w = max(0.0, min(1.0, float(settings.get('area', 0.50))))
    area_guard = area_w * (1.0 - 0.68 * amount)
    current_count = island_count
    merge_steps = 0
    max_steps = max(0, island_count - target_count)
    while current_count > target_count and merge_steps < max_steps:
        best = None
        for info in merge_infos:
            pair = info.get('pair')
            if not pair:
                continue
            a, b = int(pair[0]), int(pair[1])
            ra = find(a)
            rb = find(b)
            if ra == rb:
                continue
            merged_area = max(_EPS, group_area.get(ra, 0.0) + group_area.get(rb, 0.0))
            merged_fraction = max(0.0, min(1.0, math.sqrt(merged_area / max(_EPS, mesh_total))))
            balance = abs(group_area.get(ra, 0.0) - group_area.get(rb, 0.0)) / max(_EPS, merged_area)
            dynamic_area_cost = area_guard * (0.70 * merged_fraction + 0.30 * balance)
            cost = float(info.get('base_cost', 0.0)) + dynamic_area_cost
            key = (cost, -float(info.get('shared', 0.0)), int(min(a, b)), int(max(a, b)))
            if best is None or key < best[0]:
                best = (key, a, b)
        if best is None:
            break
        _key, a, b = best
        if union(a, b):
            current_count -= 1
            merge_steps += 1
        else:
            break

    removed_edges = 0
    for edge in getattr(bm, 'edges', []) or []:
        linked_faces = [face for face in (getattr(edge, 'link_faces', []) or []) if face in labels]
        if not linked_faces:
            continue
        keep_seam = False
        if len(linked_faces) >= 2:
            for i in range(len(linked_faces)):
                for j in range(i + 1, len(linked_faces)):
                    a = labels.get(linked_faces[i])
                    b = labels.get(linked_faces[j])
                    if a is None or b is None or a == b:
                        continue
                    if find(int(a)) != find(int(b)):
                        keep_seam = True
        try:
            if bool(edge.seam) and not keep_seam:
                removed_edges += 1
            edge.seam = bool(keep_seam)
            if not keep_seam:
                edge.smooth = True
        except Exception:
            pass
    return int(removed_edges)


def _weld_uvs_along_non_seam_edges(me, passes: int = 2, scope: dict | None = None) -> bool:
    """Force UV vertices to stay welded on every non-seam mesh edge.

    This builds connected loop groups per mesh vertex through the non-seam edge
    graph, then writes one averaged UV coordinate to each group.  It is stronger
    than pairwise edge averaging and avoids leaving tiny sub-islands on open or
    non-manifold meshes after partial Single アイランド seam rebuilding.
    """
    try:
        bm = bmesh.from_edit_mesh(me)
        uv_layer = _active_uv_layer(bm)
        bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
        bm.edges.index_update(); bm.verts.index_update(); bm.faces.index_update()
        face_layer = _scope_face_layer(bm)
    except Exception:
        return False
    loop_by_id: dict[int, object] = {}
    parent: dict[int, int] = {}

    def lid(loop) -> int:
        ident = id(loop)
        loop_by_id[ident] = loop
        parent.setdefault(ident, ident)
        return ident

    def find(ident: int) -> int:
        parent.setdefault(ident, ident)
        while parent[ident] != ident:
            parent[ident] = parent[parent[ident]]
            ident = parent[ident]
        return ident

    def union(a: int, b: int) -> None:
        ra = find(a)
        rb = find(b)
        if ra != rb:
            parent[rb] = ra

    def edge_endpoint_loops(edge) -> dict[int, list]:
        endpoints: dict[int, list] = {}
        for face in getattr(edge, 'link_faces', []) or []:
            if not _face_in_uv_scope(face, scope, face_layer):
                continue
            for loop in getattr(face, 'loops', []) or []:
                try:
                    if loop.edge is edge:
                        endpoints.setdefault(int(loop.vert.index), []).append(loop)
                        nxt = loop.link_loop_next
                        endpoints.setdefault(int(nxt.vert.index), []).append(nxt)
                    elif loop.link_loop_prev.edge is edge:
                        prev = loop.link_loop_prev
                        endpoints.setdefault(int(prev.vert.index), []).append(prev)
                        endpoints.setdefault(int(loop.vert.index), []).append(loop)
                except Exception:
                    pass
        return endpoints

    for edge in getattr(bm, 'edges', []) or []:
        try:
            linked_scope_faces = [face for face in (getattr(edge, 'link_faces', []) or []) if _face_in_uv_scope(face, scope, face_layer)]
            if bool(edge.seam) or len(linked_scope_faces) < 2:
                continue
            endpoints = edge_endpoint_loops(edge)
            for loops in endpoints.values():
                if len(loops) < 2:
                    continue
                first = lid(loops[0])
                for loop in loops[1:]:
                    union(first, lid(loop))
        except Exception:
            pass
    if not parent:
        return False
    comps: dict[int, list] = {}
    for ident in list(parent):
        comps.setdefault(find(ident), []).append(loop_by_id[ident])
    changed = False
    for loops in comps.values():
        if len(loops) < 2:
            continue
        try:
            avg_u = sum(float(loop[uv_layer].uv.x) for loop in loops) / float(len(loops))
            avg_v = sum(float(loop[uv_layer].uv.y) for loop in loops) / float(len(loops))
        except Exception:
            continue
        for loop in loops:
            try:
                luv = loop[uv_layer].uv
                if abs(float(luv.x) - avg_u) > 1.0e-8 or abs(float(luv.y) - avg_v) > 1.0e-8:
                    luv.x = avg_u
                    luv.y = avg_v
                    changed = True
            except Exception:
                pass
    if changed:
        try:
            bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
        except Exception:
            pass
    return changed



def _force_merge_uv_islands_along_mesh_edges(me, passes: int = 6, scope: dict | None = None) -> bool:
    """Last-resort Single Island welding for non-manifold or solver-fragmented charts.

    Blender can keep extra UV splits on non-manifold edges even when the requested
    seam graph is a single chart.  For the 100% Single アイランド state only, weld
    UV endpoints on mesh edges whose adjacent faces still belong to different UV
    islands.  This keeps the operation deterministic and avoids changing the
    intermediate 0..99% seam-analysis result.
    """
    try:
        passes = max(1, min(12, int(passes)))
    except Exception:
        passes = 6
    changed_any = False
    try:
        bm = bmesh.from_edit_mesh(me)
        uv_layer = _active_uv_layer(bm)
    except Exception:
        return False
    for _ in range(passes):
        try:
            bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
            bm.edges.index_update(); bm.verts.index_update(); bm.faces.index_update()
            labels, count = _build_uv_face_island_labels(bm, uv_layer, scope)
        except Exception:
            break
        if count <= 1:
            break
        groups: dict[tuple[int, int], list] = {}
        for edge in getattr(bm, 'edges', []) or []:
            try:
                face_labels = {int(labels.get(face, -1)) for face in (getattr(edge, 'link_faces', []) or []) if labels.get(face, -1) is not None}
                face_labels.discard(-1)
                if len(face_labels) < 2:
                    continue
                edge_index = int(edge.index)
                for loop in getattr(edge, 'link_loops', []) or []:
                    groups.setdefault((edge_index, int(loop.vert.index)), []).append(loop)
                    nxt = loop.link_loop_next
                    groups.setdefault((edge_index, int(nxt.vert.index)), []).append(nxt)
            except Exception:
                pass
        if not groups:
            break
        pass_changed = False
        for loops in groups.values():
            if len(loops) < 2:
                continue
            try:
                avg_u = sum(float(loop[uv_layer].uv.x) for loop in loops) / float(len(loops))
                avg_v = sum(float(loop[uv_layer].uv.y) for loop in loops) / float(len(loops))
            except Exception:
                continue
            for loop in loops:
                try:
                    luv = loop[uv_layer].uv
                    if abs(float(luv.x) - avg_u) > 1.0e-8 or abs(float(luv.y) - avg_v) > 1.0e-8:
                        luv.x = avg_u
                        luv.y = avg_v
                        pass_changed = True
                except Exception:
                    pass
        changed_any = changed_any or pass_changed
        if pass_changed:
            try:
                bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
            except Exception:
                pass
        else:
            break
    return changed_any


def _apply_baseline_pins_from_current_uvs(bm, uv_layer, baseline_axis: str, baseline_threshold: float, uv_sel_tag=None, scope: dict | None = None) -> None:
    """Reapply baseline pins to the current UVs before the Single Island target unwrap."""
    mode = str(baseline_axis or 'NONE').upper()
    if mode == 'NONE':
        return
    face_layer = _scope_face_layer(bm)
    # Keep user pins active.  Baseline pins are added temporarily and restored
    # after unwrap from the captured pre-operation pin layer.
    if mode == 'SELECTED':
        strand_dict = {}
        if uv_sel_tag is not None:
            for face in bm.faces:
                if not _face_in_uv_scope(face, scope, face_layer):
                    continue
                for loop in face.loops:
                    try:
                        sid = int(loop[uv_sel_tag])
                    except Exception:
                        sid = 0
                    if sid > 0:
                        strand_dict.setdefault(sid, []).append(loop)
        for loops in strand_dict.values():
            if not loops:
                continue
            u_coords = [float(loop[uv_layer].uv.x) for loop in loops]
            v_coords = [float(loop[uv_layer].uv.y) for loop in loops]
            avg_u = sum(u_coords) / max(1, len(u_coords))
            avg_v = sum(v_coords) / max(1, len(v_coords))
            var_u = sum((u - avg_u) ** 2 for u in u_coords)
            var_v = sum((v - avg_v) ** 2 for v in v_coords)
            is_vert = var_u < var_v
            for loop in loops:
                try:
                    if is_vert:
                        loop[uv_layer].uv.x = avg_u
                    else:
                        loop[uv_layer].uv.y = avg_v
                    loop[uv_layer].pin_uv = True
                except Exception:
                    pass
        return
    if mode not in {'X', 'Y', 'Z'}:
        return
    axis_idx = {'X': 0, 'Y': 1, 'Z': 2}[mode]
    try:
        scoped_verts = {loop.vert for face in bm.faces if _face_in_uv_scope(face, scope, face_layer) for loop in face.loops}
        target_verts = {v for v in scoped_verts if abs(float(v.co[axis_idx])) <= float(baseline_threshold)}
    except Exception:
        target_verts = set()
    groups = []
    unvisited = set(target_verts)
    while unvisited:
        vert = unvisited.pop()
        group = {vert}
        queue = [vert]
        while queue:
            curr = queue.pop(0)
            for edge in curr.link_edges:
                other = edge.other_vert(curr)
                if other in unvisited:
                    unvisited.remove(other)
                    group.add(other)
                    queue.append(other)
        groups.append(group)
    for group in groups:
        group_loops = [loop for vert in group for loop in vert.link_loops if _face_in_uv_scope(loop.face, scope, face_layer)]
        if not group_loops:
            continue
        u_coords = [float(loop[uv_layer].uv.x) for loop in group_loops]
        v_coords = [float(loop[uv_layer].uv.y) for loop in group_loops]
        avg_u = sum(u_coords) / max(1, len(u_coords))
        avg_v = sum(v_coords) / max(1, len(v_coords))
        var_u = sum((u - avg_u) ** 2 for u in u_coords)
        var_v = sum((v - avg_v) ** 2 for v in v_coords)
        is_vertical = var_u < var_v
        for loop in group_loops:
            try:
                if is_vertical:
                    loop[uv_layer].uv.x = avg_u
                else:
                    loop[uv_layer].uv.y = avg_v
                loop[uv_layer].pin_uv = True
            except Exception:
                pass


def _apply_single_island_gradation(context, me, strength: float, unwrap_math: str, pack_margin: float, baseline_axis: str, baseline_threshold: float, scope: dict | None = None) -> None:
    """Rebuild seams according to Single Island strength and unwrap the merged islands cleanly.

    The 0% unwrap is first converted to seam boundaries.  A strength-dependent
    fraction of those boundaries is then removed, so neighbouring islands become
    larger unwrap groups.  The UVs are not coordinate-blended: the mesh is fully
    re-unwrapped with the updated seams, then the normal final pack stage lays out
    the resulting islands.
    """
    amount = _smooth_single_island_strength(strength)
    if amount <= _EPS:
        return
    _select_uv_scope_for_ops(me, scope)
    try:
        bpy.ops.uv.seams_from_islands()
    except Exception:
        pass
    bm = bmesh.from_edit_mesh(me)
    uv_layer = _active_uv_layer(bm)
    bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
    bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
    face_layer = _scope_face_layer(bm)
    uv_sel_tag = bm.loops.layers.int.get('uv_sel_tag')
    for face in bm.faces:
        in_scope = _face_in_uv_scope(face, scope, face_layer)
        face.select = bool(in_scope)
        for loop in face.loops:
            try:
                loop[uv_layer].select = bool(in_scope)
                loop[uv_layer].select_edge = bool(in_scope)
            except Exception:
                pass
    seam_settings = _single_island_seam_weight_settings(_ws(context))
    _apply_progressive_single_island_seams(bm, uv_layer, strength, seam_settings, scope)
    _apply_baseline_pins_from_current_uvs(bm, uv_layer, baseline_axis, baseline_threshold, uv_sel_tag, scope)
    bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
    _select_uv_scope_for_ops(me, scope)
    _call_unwrap(unwrap_math, pack_margin)
    _weld_uvs_along_non_seam_edges(me, passes=3 if amount >= 1.0 - _EPS else 2, scope=scope)
    if amount >= 1.0 - _EPS:
        _force_merge_uv_islands_along_mesh_edges(me, passes=8, scope=scope)


def _safe_pack_islands_bmesh(me, margin: float, rotate: bool = True, scope: dict | None = None) -> bool:
    """Small deterministic AABB packer used by Smart Standard core.

    Blender 5.1 native ``uv.pack_islands`` can stall on some freshly joined
    partial Single アイランド layouts.  This packer keeps the operation inside
    BMesh, packs current UV islands into 0-1 with a shelf layout, and avoids
    rewriting the unwrap topology.
    """
    try:
        bm = bmesh.from_edit_mesh(me)
        uv_layer = _active_uv_layer(bm)
        labels, count = _build_uv_face_island_labels(bm, uv_layer, scope)
        if count <= 0:
            return False
        islands = {}
        for face, label in labels.items():
            islands.setdefault(label, set()).update(list(getattr(face, 'loops', []) or []))
        margin = max(0.0, min(0.25, float(margin)))
        packed = []
        for label, loop_set in islands.items():
            loops = list(loop_set)
            if not loops:
                continue
            # Optional 90-degree rotation for tall islands.
            us = [float(loop[uv_layer].uv.x) for loop in loops]
            vs = [float(loop[uv_layer].uv.y) for loop in loops]
            min_u, max_u = min(us), max(us)
            min_v, max_v = min(vs), max(vs)
            width = max(max_u - min_u, _EPS)
            height = max(max_v - min_v, _EPS)
            if rotate and height > width * 1.15:
                cu = (min_u + max_u) * 0.5
                cv = (min_v + max_v) * 0.5
                for loop in loops:
                    u = float(loop[uv_layer].uv.x) - cu
                    v = float(loop[uv_layer].uv.y) - cv
                    loop[uv_layer].uv.x = cu - v
                    loop[uv_layer].uv.y = cv + u
                us = [float(loop[uv_layer].uv.x) for loop in loops]
                vs = [float(loop[uv_layer].uv.y) for loop in loops]
                min_u, max_u = min(us), max(us)
                min_v, max_v = min(vs), max(vs)
                width = max(max_u - min_u, _EPS)
                height = max(max_v - min_v, _EPS)
            packed.append({'label': label, 'loops': loops, 'min_u': min_u, 'min_v': min_v, 'w': width, 'h': height})
        if not packed:
            return False
        packed.sort(key=lambda item: (-item['h'], -item['w'], item['label']))

        def layout(scale: float):
            x = margin
            y = margin
            row_h = 0.0
            positions = []
            max_x = margin
            usable_w = max(_EPS, 1.0 - margin)
            for item in packed:
                w = item['w'] * scale
                h = item['h'] * scale
                if x > margin + _EPS and x + w > usable_w:
                    x = margin
                    y += row_h + margin
                    row_h = 0.0
                positions.append((item, x, y, w, h))
                x += w + margin
                row_h = max(row_h, h)
                max_x = max(max_x, x)
            total_h = y + row_h + margin
            return positions, max_x, total_h

        # Largest scale whose shelves still fit the 0-1 square.
        low = 0.0
        high = 1.0 / max(_EPS, max(max(item['w'], item['h']) for item in packed))
        for _ in range(24):
            scale = (low + high) * 0.5
            _positions, max_x, total_h = layout(scale)
            if max(max_x, total_h) <= 1.0 + _EPS:
                low = scale
            else:
                high = scale
        scale = low
        positions, _max_x, _total_h = layout(scale)
        for item, dst_x, dst_y, _w, _h in positions:
            src_min_u = item['min_u']
            src_min_v = item['min_v']
            for loop in item['loops']:
                loop[uv_layer].uv.x = (float(loop[uv_layer].uv.x) - src_min_u) * scale + dst_x
                loop[uv_layer].uv.y = (float(loop[uv_layer].uv.y) - src_min_v) * scale + dst_y
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
        return True
    except Exception:
        return False


def _clear_all_pins_bmesh(me, scope: dict | None = None) -> None:
    try:
        bm = bmesh.from_edit_mesh(me)
        uv_layer = _active_uv_layer(bm)
        face_layer = _scope_face_layer(bm)
        for face in bm.faces:
            if not _face_in_uv_scope(face, scope, face_layer):
                continue
            for loop in face.loops:
                try:
                    loop[uv_layer].pin_uv = False
                except Exception:
                    pass
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
    except Exception:
        try:
            bpy.ops.uv.pin(clear=True)
        except Exception:
            pass



# ---------------------------------------------------------------------------
# Reference-tool-inspired Smart chart refinement
# ---------------------------------------------------------------------------
def _reference_refine_settings(ws) -> dict[str, float | str | bool]:
    """Read high-precision Smart chart refinement settings.

    The attached reference binaries expose concepts such as allowed stretch,
    concave/convex seam thresholds, existing-seam reuse, polygon/triangle chart
    border policy and chart distribution.  This function maps those concepts to
    local Smart UV Suite weights without copying third-party code.
    """
    def pct(name: str, default: float) -> float:
        return max(0.0, min(1.0, _float(ws, name, default, 0.0, 100.0) / 100.0))
    profile = _enum(ws, 'smart_standard_core_reference_profile', 'BALANCED')
    enabled = _bool(ws, 'smart_standard_core_reference_refine_enabled', True)
    strength = pct('smart_standard_core_reference_strength', 55.0)
    # Preset multipliers keep the user-facing values meaningful while changing
    # the weighting style between hard, organic and low-stretch workflows.
    mul = {
        'BALANCED': (1.0, 1.0, 1.0, 1.0),
        'HARD_SURFACE_CHART': (1.28, 0.88, 1.20, 0.82),
        'ORGANIC_LOW_DISTORTION': (0.72, 1.32, 0.82, 1.28),
        'SELECTED_SCOPE_LOW_STRETCH': (0.82, 1.52, 0.86, 0.72),
        'PACK_FRIENDLY': (0.92, 1.05, 1.10, 1.18),
    }.get(profile, (1.0, 1.0, 1.0, 1.0))
    return {
        'enabled': bool(enabled and strength > _EPS),
        'profile': profile,
        'strength': strength,
        'allowed_stretch': pct('smart_standard_core_reference_allowed_stretch', 24.0),
        'concave_angle': math.radians(_float(ws, 'smart_standard_core_reference_concave_angle', 55.0, 0.0, 180.0)),
        'convex_angle': math.radians(_float(ws, 'smart_standard_core_reference_convex_angle', 45.0, 0.0, 180.0)),
        'existing': pct('smart_standard_core_reference_existing_seam_weight', 85.0),
        'fewer_charts': pct('smart_standard_core_reference_fewer_charts', 50.0),
        'loop': pct('smart_standard_core_reference_loop_weight', 60.0),
        'triangle': pct('smart_standard_core_reference_triangle_border', 10.0),
        'cylinder': pct('smart_standard_core_reference_cylindrical_loop', 50.0),
        'angle_mul': float(mul[0]),
        'stretch_mul': float(mul[1]),
        'loop_mul': float(mul[2]),
        'chart_mul': float(mul[3]),
    }


def _edge_signed_angle(edge) -> float:
    try:
        return float(edge.calc_face_angle_signed(0.0))
    except Exception:
        pass
    try:
        faces = list(getattr(edge, 'link_faces', []) or [])
        if len(faces) >= 2:
            n0 = faces[0].normal
            n1 = faces[1].normal
            dot = max(-1.0, min(1.0, float(n0.dot(n1))))
            return math.acos(dot)
    except Exception:
        pass
    return 0.0


def _edge_loop_continuity_score(edge) -> float:
    """Estimate whether an edge belongs to a stable long loop/border."""
    try:
        verts = list(getattr(edge, 'verts', []) or [])
        if len(verts) != 2:
            return 0.0
        valence_score = 0.0
        for vert in verts:
            val = len(list(getattr(vert, 'link_edges', []) or []))
            if val == 4:
                valence_score += 0.5
            elif val in {3, 5}:
                valence_score += 0.28
        length = max(_EPS, float(edge.calc_length()))
        near = []
        for vert in verts:
            for other in getattr(vert, 'link_edges', []) or []:
                if other is edge:
                    continue
                try:
                    near.append(float(other.calc_length()))
                except Exception:
                    pass
        if near:
            avg = sum(near) / float(len(near))
            length_score = 1.0 - min(1.0, abs(length - avg) / max(length, avg, _EPS))
        else:
            length_score = 0.0
        return max(0.0, min(1.0, 0.62 * valence_score + 0.38 * length_score))
    except Exception:
        return 0.0


def _edge_stretch_predict_score(edge) -> float:
    """Predict future UV tension from adjacent face area and edge-length mismatch."""
    try:
        faces = list(getattr(edge, 'link_faces', []) or [])
        if len(faces) < 2:
            return 0.0
        a0 = max(_EPS, _face_mesh_area(faces[0]))
        a1 = max(_EPS, _face_mesh_area(faces[1]))
        area_balance = abs(math.log(a0 / a1)) / 2.4
        area_balance = max(0.0, min(1.0, area_balance))
        length = max(_EPS, float(edge.calc_length()))
        local = []
        for face in faces[:2]:
            for e in getattr(face, 'edges', []) or []:
                try:
                    local.append(float(e.calc_length()))
                except Exception:
                    pass
        if local:
            avg_len = sum(local) / float(len(local))
            len_score = abs(math.log(length / max(_EPS, avg_len))) / 1.4
            len_score = max(0.0, min(1.0, len_score))
        else:
            len_score = 0.0
        return max(0.0, min(1.0, 0.58 * area_balance + 0.42 * len_score))
    except Exception:
        return 0.0


def _edge_cylindrical_candidate_score(edge) -> float:
    """Prefer one readable longitudinal cut on tube-like rows without exploding charts."""
    try:
        faces = list(getattr(edge, 'link_faces', []) or [])
        if len(faces) != 2:
            return 0.0
        # In a tube side wall, adjacent face normals rotate but face areas and
        # edge lengths are usually regular.  Boundary loops/caps are handled by
        # angle and boundary terms; this score identifies regular side loops.
        angle = abs(_edge_signed_angle(edge))
        loop_score = _edge_loop_continuity_score(edge)
        stretch_score = 1.0 - _edge_stretch_predict_score(edge)
        regular = max(0.0, min(1.0, 0.55 * loop_score + 0.45 * stretch_score))
        if angle < math.radians(4.0):
            angle_part = 0.10
        else:
            angle_part = max(0.0, min(1.0, angle / math.radians(90.0)))
        return max(0.0, min(1.0, 0.35 * angle_part + 0.65 * regular))
    except Exception:
        return 0.0


def _apply_reference_smart_chart_refinement(context, bm, uv_layer, scope: dict | None, unwrap_mode: str) -> bool:
    """Add temporary pre-unwrap seam candidates to improve Smart unwrap charts.

    These seams are intentionally temporary.  ``_restore_original_user_pins_and_mesh_seams``
    restores the user's real Mark Seam state after unwrap, so the feature refines
    chart solving without silently changing authoring seams.
    """
    ws = _ws(context)
    settings = _reference_refine_settings(ws)
    if not bool(settings.get('enabled')):
        return False
    strength = float(settings.get('strength', 0.0))
    face_layer = _scope_face_layer(bm)
    try:
        selected_faces = [f for f in bm.faces if _face_in_uv_scope(f, scope, face_layer)]
    except Exception:
        selected_faces = list(getattr(bm, 'faces', []) or [])
    if not selected_faces:
        return False
    selected_set = set(selected_faces)
    concave_threshold = max(math.radians(1.0), float(settings.get('concave_angle', math.radians(55.0))))
    convex_threshold = max(math.radians(1.0), float(settings.get('convex_angle', math.radians(45.0))))
    allowed_stretch = float(settings.get('allowed_stretch', 0.24))
    fewer = float(settings.get('fewer_charts', 0.50))
    existing_w = float(settings.get('existing', 0.85))
    loop_w = float(settings.get('loop', 0.60)) * float(settings.get('loop_mul', 1.0))
    cyl_w = float(settings.get('cylinder', 0.50))
    tri_allow = float(settings.get('triangle', 0.10))
    angle_mul = float(settings.get('angle_mul', 1.0))
    stretch_mul = float(settings.get('stretch_mul', 1.0))
    chart_mul = float(settings.get('chart_mul', 1.0))
    added = 0
    candidates: list[tuple[float, int, object]] = []
    for edge in getattr(bm, 'edges', []) or []:
        try:
            linked = [face for face in (getattr(edge, 'link_faces', []) or []) if face in selected_set]
            if not linked:
                continue
            if len(linked) < 2:
                # Selected/open boundary remains a boundary; it is not a destructive user seam.
                if not bool(edge.seam):
                    edge.seam = True
                    added += 1
                continue
            signed = _edge_signed_angle(edge)
            abs_angle = abs(signed)
            # Signed angle direction differs between triangulations.  Use the
            # lower threshold as a fallback and bias by the explicit side when available.
            if signed < 0.0:
                angle_threshold = concave_threshold
            else:
                angle_threshold = convex_threshold
            angle_score = max(0.0, min(1.0, abs_angle / max(_EPS, angle_threshold)))
            strong_angle = abs_angle >= angle_threshold
            stretch_score = _edge_stretch_predict_score(edge)
            stretch_excess = max(0.0, stretch_score - allowed_stretch) / max(_EPS, 1.0 - allowed_stretch)
            loop_score = _edge_loop_continuity_score(edge)
            cylinder_score = _edge_cylindrical_candidate_score(edge)
            # Triangle-border allowance lets detailed triangulated meshes receive
            # extra seams; low values keep chart borders closer to polygonal flow.
            triangle_bonus = tri_allow * 0.22 if len(linked) == 2 else 0.0
            score = (
                0.42 * angle_mul * angle_score +
                0.33 * stretch_mul * stretch_excess +
                0.17 * loop_w * loop_score +
                0.08 * cyl_w * cylinder_score +
                triangle_bonus
            )
            if bool(edge.seam):
                score = max(score, 0.55 + 0.45 * existing_w)
            # Fewer-charts raises the cut threshold.  Strong angles and explicit
            # user seams still survive so hard edges and authored seams remain reliable.
            threshold = (0.36 + 0.40 * fewer) / max(_EPS, (0.55 + 0.45 * strength) * chart_mul)
            if bool(edge.seam) or strong_angle or score >= threshold:
                candidates.append((score, int(getattr(edge, 'index', 0)), edge))
        except Exception:
            continue
    if not candidates:
        return bool(added)
    # Avoid covering the entire model with seams.  The cap scales with strength
    # and fewer-chart preference, giving a smooth quality improvement without
    # changing the user's Mark Seam data.
    max_edges = max(1, int(round(len(candidates) * max(0.12, min(1.0, strength * (1.0 - 0.55 * fewer) + 0.18)))))
    candidates.sort(key=lambda row: (-row[0], row[1]))
    for _score, _idx, edge in candidates[:max_edges]:
        try:
            if not bool(edge.seam):
                added += 1
            edge.seam = True
        except Exception:
            pass
    return bool(added > 0)


def run_standard_unwrap(context: Any) -> bool:
    obj = getattr(context, 'edit_object', None)
    if not obj or getattr(obj, 'type', None) != 'MESH':
        obj = getattr(context, 'active_object', None)
        if obj and getattr(obj, 'type', None) == 'MESH' and getattr(obj, 'mode', '') != 'EDIT':
            try:
                context.view_layer.objects.active = obj
                obj.select_set(True)
                bpy.ops.object.mode_set(mode='EDIT')
            except Exception:
                pass
    if not obj or getattr(obj, 'type', None) != 'MESH':
        return False
    if getattr(obj, 'mode', '') != 'EDIT':
        try:
            bpy.ops.object.mode_set(mode='EDIT')
        except Exception:
            return False

    ws = _ws(context)
    global _TARGET_UV_LAYER_NAME
    try:
        from . import uv_map_channels as _uvc
        _TARGET_UV_LAYER_NAME = str(_uvc.ensure_unwrap_map_channel(context, ws) or '')
    except Exception:
        _TARGET_UV_LAYER_NAME = ''
    me = obj.data
    raw_unwrap_mode = _enum(ws, 'smart_standard_core_unwrap_mode', 'SMART_STANDARD_HARD')
    unwrap_mode = _resolved_smart_standard_core_unwrap_mode(ws, raw_unwrap_mode)
    unwrap_math = _enum(ws, 'smart_standard_core_unwrap_math', 'ANGLE_BASED')
    smart_angle = _float(ws, 'smart_standard_core_smart_angle', math.radians(66.0), 0.0, math.pi)
    smart_area_weight = _float(ws, 'smart_standard_core_smart_area_weight', 0.0, 0.0, 1.0)
    baseline_axis = _enum(ws, 'smart_standard_core_baseline_axis', 'NONE')
    baseline_threshold = _float(ws, 'smart_standard_core_baseline_threshold', 0.001, 0.0, 10.0)
    stretch_iterations = _int(ws, 'smart_standard_core_stretch_iterations', 100, 0, 2000)
    stretch_blend = _float(ws, 'smart_standard_core_stretch_blend', 1.0, 0.0, 1.0)
    auto_pack = _bool(ws, 'smart_standard_core_auto_pack', True)
    pack_margin = _float(ws, 'smart_standard_core_pack_margin', 0.02, 0.0, 1.0)
    pack_margin_method = _enum(ws, 'smart_standard_core_pack_margin_method', 'FRACTION')
    pack_rotate_method = _enum(ws, 'smart_standard_core_pack_rotate_method', 'ANY')
    pre_fix_mesh = _bool(ws, 'smart_standard_core_pre_fix_mesh', False)
    merge_distance = _float(ws, 'smart_standard_core_merge_distance', 0.0001, 0.0, 0.1)
    quality_strength = _float(ws, 'smart_standard_core_quality_strength', 65.0, 0.0, 100.0) / 100.0
    area_preserve_strength = _float(ws, 'smart_standard_core_area_preserve_strength', 70.0, 0.0, 100.0) / 100.0
    shape_preserve_strength = _float(ws, 'smart_standard_core_shape_preserve_strength', 55.0, 0.0, 100.0) / 100.0
    native_result_preserve = _float(ws, 'smart_standard_core_native_result_preserve', 25.0, 0.0, 100.0) / 100.0
    quality_iterations = _int(ws, 'smart_standard_core_quality_iterations', 36, 0, 240)
    legacy_single_mode = unwrap_mode == 'SINGLE'
    if legacy_single_mode:
        unwrap_mode = 'NORMAL'
    single_island_strength = 1.0 if legacy_single_mode else _single_island_strength_for_mode(ws, unwrap_mode)
    marked_seam_pre_split = _suv_1623_marked_seam_pre_split_enabled(context)

    mesh_selection_state = _capture_3d_mesh_selection_state(context, obj, me)
    scope, uv_attr_state = _ensure_uv_selection_scope(context, obj, me)
    if (not bool((scope or {}).get('has_uv_selection'))) or (not bool((scope or {}).get('has_full_face_selection'))):
        _restore_unselected_uv_scope(me, scope)
        _restore_original_uv_selection_attributes_for_blender_51(me)
        _restore_3d_mesh_selection_state(context, obj, me, mesh_selection_state)
        _cleanup_uv_selection_scope_layers(me)
        return False

    # STAGE 1/2: selection topology capture and mesh pre-processing.
    bm = bmesh.from_edit_mesh(me)
    uv_layer = _active_uv_layer(bm)
    bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
    bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
    _tag_original_seams_for_single_island(bm)
    reference_refine_active = _apply_reference_smart_chart_refinement(context, bm, uv_layer, scope, unwrap_mode)
    uv_sel_tag = bm.loops.layers.int.get('uv_sel_tag') or bm.loops.layers.int.new('uv_sel_tag')
    for face in bm.faces:
        for loop in face.loops:
            loop[uv_sel_tag] = 0
    if baseline_axis == 'SELECTED':
        uv_sel_tag = _capture_selected_baseline_strands(bm, uv_layer, uv_attr_state)

    _apply_uv_scope_selection_to_bmesh(bm, uv_layer, scope, clear_pins=False, select_uv=True)

    if pre_fix_mesh:
        if not _scope_is_active(scope):
            try:
                bmesh.ops.remove_doubles(bm, verts=list(bm.verts), dist=merge_distance)
            except Exception:
                pass
        try:
            repair_faces = [face for face in bm.faces if _face_in_uv_scope(face, scope, _scope_face_layer(bm))]
            bmesh.ops.recalc_face_normals(bm, faces=repair_faces)
        except Exception:
            pass
        try:
            bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
        except Exception:
            pass
    for edge in bm.edges:
        if not _edge_has_scope_face(edge, scope, _scope_face_layer(bm)):
            continue
        try:
            edge.select = True
        except Exception:
            pass
        if unwrap_mode == 'SMART_STANDARD_ORGANIC' and baseline_axis != 'SELECTED':
            try:
                # Preserve Blender-standard manual seam marks.  Organic mode may
                # relax smoothing, but it must not clear user seams; marked-seam
                # component splitting reads those seams before every unwrap.
                edge.smooth = True
            except Exception:
                pass
    bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)

    # STAGE 3: initial unwrap.
    # When Mark Seam compliance is enabled, the existing Blender mesh seam marks
    # are the split graph before the unwrap.  Each seam-separated 3D face group is
    # unwrapped one by one; only after every selected group is solved does the
    # final pack operate on the whole selected UV-face scope.
    _suv_1623_run_initial_unwrap_with_marked_seam_components(
        context, obj, me, scope, unwrap_mode, unwrap_math, smart_angle,
        smart_area_weight, pack_margin, marked_seam_pre_split or reference_refine_active,
        use_original_layer=not bool(reference_refine_active),
    )

    # STAGE 4: baseline pinning, including the updated SELECTED strand mode.
    if baseline_axis != 'NONE':
        if unwrap_mode in {'SMART_STANDARD_HARD', 'SMART_STANDARD_ORGANIC', 'SMART'}:
            _select_uv_scope_for_ops(me, scope)
            try:
                bpy.ops.uv.seams_from_islands()
            except Exception:
                pass
        bm = bmesh.from_edit_mesh(me)
        uv_layer = _active_uv_layer(bm)
        bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
        face_layer = _scope_face_layer(bm)
        if baseline_axis == 'SELECTED':
            uv_sel_tag = bm.loops.layers.int.get('uv_sel_tag')
            strand_dict = {}
            if uv_sel_tag is not None:
                for face in bm.faces:
                    if not _face_in_uv_scope(face, scope, face_layer):
                        continue
                    for loop in face.loops:
                        try:
                            sid = int(loop[uv_sel_tag])
                        except Exception:
                            sid = 0
                        if sid > 0:
                            strand_dict.setdefault(sid, []).append(loop)
            for loops in strand_dict.values():
                if not loops:
                    continue
                u_coords = [float(loop[uv_layer].uv.x) for loop in loops]
                v_coords = [float(loop[uv_layer].uv.y) for loop in loops]
                avg_u = sum(u_coords) / max(1, len(u_coords))
                avg_v = sum(v_coords) / max(1, len(v_coords))
                var_u = sum((u - avg_u) ** 2 for u in u_coords)
                var_v = sum((v - avg_v) ** 2 for v in v_coords)
                is_vert = var_u < var_v
                for loop in loops:
                    if is_vert:
                        loop[uv_layer].uv.x = avg_u
                    else:
                        loop[uv_layer].uv.y = avg_v
                    loop[uv_layer].pin_uv = True
        elif baseline_axis in {'X', 'Y', 'Z'}:
            axis_idx = {'X': 0, 'Y': 1, 'Z': 2}[baseline_axis]
            scoped_verts = {loop.vert for face in bm.faces if _face_in_uv_scope(face, scope, face_layer) for loop in face.loops}
            target_verts = {v for v in scoped_verts if abs(float(v.co[axis_idx])) <= baseline_threshold}
            groups = []
            unvisited = set(target_verts)
            while unvisited:
                v = unvisited.pop()
                group = {v}
                queue = [v]
                while queue:
                    curr = queue.pop(0)
                    for edge in curr.link_edges:
                        other = edge.other_vert(curr)
                        if other in unvisited:
                            unvisited.remove(other)
                            group.add(other)
                            queue.append(other)
                groups.append(group)
            for group in groups:
                group_loops = [loop for vert in group for loop in vert.link_loops if _face_in_uv_scope(loop.face, scope, face_layer)]
                if not group_loops:
                    continue
                u_coords = [float(loop[uv_layer].uv.x) for loop in group_loops]
                v_coords = [float(loop[uv_layer].uv.y) for loop in group_loops]
                avg_u = sum(u_coords) / max(1, len(u_coords))
                avg_v = sum(v_coords) / max(1, len(v_coords))
                var_u = sum((u - avg_u) ** 2 for u in u_coords)
                var_v = sum((v - avg_v) ** 2 for v in v_coords)
                is_vertical = var_u < var_v
                for loop in group_loops:
                    if is_vertical:
                        loop[uv_layer].uv.x = avg_u
                    else:
                        loop[uv_layer].uv.y = avg_v
                    loop[uv_layer].pin_uv = True
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
        _select_uv_scope_for_ops(me, scope)
        _call_unwrap(unwrap_math, pack_margin)

    if single_island_strength > _EPS:
        if marked_seam_pre_split:
            _suv_1623_apply_single_island_per_marked_component(context, obj, me, scope, single_island_strength, unwrap_math, pack_margin, baseline_axis, baseline_threshold)
        else:
            _apply_single_island_gradation(context, me, single_island_strength, unwrap_math, pack_margin, baseline_axis, baseline_threshold, scope)

    # STAGE 5: keep user pins/seams intact, force scoped selection, relax and pack.
    _select_uv_scope_for_ops(me, scope)
    if unwrap_mode in {'SMART_STANDARD_HARD', 'SMART_STANDARD_ORGANIC'}:
        _call_minimize_stretch(stretch_iterations, stretch_blend)
    # Area preservation is applied to every Smart Standard unwrap mode.  It uses
    # the original mesh face areas, so partial Single アイランド values keep
    # correct island size ratios after the joined charts are re-unwrapped.
    _apply_mesh_area_preserving_uv_layout(
        me,
        iterations=quality_iterations,
        quality_strength=quality_strength,
        area_strength=area_preserve_strength,
        shape_strength=shape_preserve_strength,
        original_preserve=native_result_preserve,
        scope=scope,
    )
    try:
        from . import seam_pin_tools as _spt
        _spt.sync_after_unwrap_if_enabled(context, obj, selected_faces=_scope_selected_face_indices(me, scope), method=unwrap_math, margin=pack_margin)
    except Exception:
        pass
    if auto_pack:
        # Charts solved one by one come back at unrelated sizes.
        try:
            bm = bmesh.from_edit_mesh(me)
            _scale_uv_islands_to_mesh_area_ratio(bm, _active_uv_layer(bm), strength=1.0, scope=scope)
            bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
        except Exception:
            pass
        do_rotate = False if (baseline_axis != 'NONE' or pack_rotate_method == 'NONE') else True
        if not _safe_pack_islands_bmesh(me, pack_margin, do_rotate, scope):
            # Last-resort fallback for unexpected BMesh failures only.  The normal
            # path avoids native pack_islands because Blender 5.1 can stall on
            # partial Single アイランド layouts.
            safe_rot_method = pack_rotate_method if pack_rotate_method != 'NONE' else 'ANY'
            _call_pack_islands(do_rotate, safe_rot_method, pack_margin, pack_margin_method)
    # Final baseline refinement for direct Smart Standard execution.  The old
    # pin-and-unwrap stage gives Blender's solver a good constrained initial
    # solution, but later area optimization and packing can bend the baseline.
    # Re-run the shared constrained low-distortion baseline pass so the final UV
    # keeps the straight baseline while all chart vertices are relaxed around it.
    if baseline_axis != 'NONE':
        try:
            from . import seam_pin_tools as _spt
            _spt.apply_baseline_straightening_to_uv_scope(
                context, obj,
                selected_faces=_scope_selected_face_indices(me, scope),
                baseline_axis=baseline_axis,
                threshold=baseline_threshold,
                baseline_pairs=None,
            )
        except Exception:
            pass
    _restore_original_user_pins_and_mesh_seams(me)
    _restore_unselected_uv_scope(me, scope)
    _restore_3d_mesh_selection_state(context, obj, me, mesh_selection_state)
    _force_final_uv_scope_selection_only(me, scope)
    _cleanup_uv_selection_scope_layers(me)
    return True


# ---------------------------------------------------------------------------
# 1.6.23 Pre-unwrap Mark Seam component compliance for Smart Standard core
# ---------------------------------------------------------------------------
def _suv_1623_marked_seam_pre_split_enabled(context) -> bool:
    try:
        from . import seam_pin_tools as _spt
        return bool(_spt.marked_seam_pre_split_enabled(context))
    except Exception:
        return False


def _suv_1623_scope_total_face_count(me, scope: dict | None) -> int:
    try:
        total = int((scope or {}).get('total_faces', 0) or 0)
        if total > 0:
            return total
    except Exception:
        pass
    try:
        bm = bmesh.from_edit_mesh(me)
        return len(list(getattr(bm, 'faces', []) or []))
    except Exception:
        return 0


def _suv_1623_set_scope_mask_for_faces(me, face_indices: set[int] | list[int] | tuple[int, ...]) -> None:
    selected = {int(i) for i in (face_indices or set())}
    try:
        bm = bmesh.from_edit_mesh(me)
        uv_layer = _active_uv_layer(bm)
        bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
        bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
        face_layer = bm.faces.layers.int.get(_SCOPE_FACE_LAYER) or bm.faces.layers.int.new(_SCOPE_FACE_LAYER)
        loop_layer = bm.loops.layers.int.get(_SCOPE_LOOP_LAYER) or bm.loops.layers.int.new(_SCOPE_LOOP_LAYER)
        for face in bm.faces:
            in_scope = int(getattr(face, 'index', -1)) in selected
            try:
                face[face_layer] = 1 if in_scope else 0
            except Exception:
                pass
            for loop in getattr(face, 'loops', []) or []:
                try:
                    loop[loop_layer] = 1 if in_scope else 0
                except Exception:
                    pass
                try:
                    loop[uv_layer].select = bool(in_scope)
                    loop[uv_layer].select_edge = bool(in_scope)
                except Exception:
                    pass
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
    except Exception:
        pass


def _suv_1623_component_scope(base_scope: dict | None, me, faces: set[int]) -> dict:
    scope = dict(base_scope or {})
    total = _suv_1623_scope_total_face_count(me, base_scope)
    scope['active'] = bool(0 < len(faces) < max(1, total))
    scope['selected_faces'] = int(len(faces))
    scope['total_faces'] = int(max(total, len(faces)))
    scope['has_uv_selection'] = bool(faces)
    scope['has_full_face_selection'] = bool(faces)
    return scope


def _suv_1623_marked_components_for_scope(context, obj, me, scope: dict | None, *, use_original_layer: bool = True) -> tuple[set[int], list[set[int]]]:
    selected = set(_scope_selected_face_indices(me, scope))
    if not selected:
        return set(), []
    try:
        from . import seam_pin_tools as _spt
        comps = _spt.marked_seam_face_components(context, obj, selected_faces=selected, use_original_layer=use_original_layer)
    except Exception:
        comps = []
    comps = [set(int(i) for i in c if int(i) in selected) for c in (comps or [])]
    comps = [c for c in comps if c]
    if not comps:
        comps = [set(selected)]
    return selected, comps


def _suv_1623_call_initial_unwrap_once(unwrap_mode: str, unwrap_math: str, smart_angle: float, smart_area_weight: float, pack_margin: float) -> bool:
    try:
        if unwrap_mode == 'SMART_STANDARD_HARD':
            _call_smart_project(smart_angle, pack_margin, smart_area_weight)
        elif unwrap_mode == 'SMART_STANDARD_ORGANIC':
            _call_smart_project(math.radians(89.0), pack_margin, smart_area_weight)
        elif unwrap_mode == 'SMART':
            _call_smart_project(smart_angle, pack_margin, smart_area_weight)
        elif unwrap_mode == 'NORMAL':
            _call_unwrap(unwrap_math, pack_margin)
        else:
            _call_unwrap(unwrap_math, pack_margin)
        return True
    except Exception:
        return False


def _suv_1623_run_initial_unwrap_with_marked_seam_components(context, obj, me, scope: dict | None, unwrap_mode: str, unwrap_math: str, smart_angle: float, smart_area_weight: float, pack_margin: float, enabled: bool, *, use_original_layer: bool = True) -> bool:
    selected, comps = _suv_1623_marked_components_for_scope(context, obj, me, scope, use_original_layer=use_original_layer)
    if (not enabled) or len(comps) <= 1:
        _suv_1623_set_scope_mask_for_faces(me, selected)
        _select_uv_scope_for_ops(me, scope)
        return _suv_1623_call_initial_unwrap_once(unwrap_mode, unwrap_math, smart_angle, smart_area_weight, pack_margin)
    ok = True
    for comp in comps:
        comp_scope = _suv_1623_component_scope(scope, me, comp)
        _suv_1623_set_scope_mask_for_faces(me, comp)
        _select_uv_scope_for_ops(me, comp_scope)
        ok = _suv_1623_call_initial_unwrap_once(unwrap_mode, unwrap_math, smart_angle, smart_area_weight, pack_margin) and ok
    # Restore the complete selected UV-face scope before baseline, optimization,
    # and final packing.  This keeps unselected UV islands out of the operation.
    _suv_1623_set_scope_mask_for_faces(me, selected)
    _select_uv_scope_for_ops(me, scope)
    return bool(ok)


def _suv_1623_apply_single_island_per_marked_component(context, obj, me, scope: dict | None, strength: float, unwrap_math: str, pack_margin: float, baseline_axis: str, baseline_threshold: float) -> bool:
    selected, comps = _suv_1623_marked_components_for_scope(context, obj, me, scope)
    if not comps:
        return False
    if len(comps) <= 1:
        _suv_1623_set_scope_mask_for_faces(me, selected)
        _apply_single_island_gradation(context, me, strength, unwrap_math, pack_margin, baseline_axis, baseline_threshold, scope)
        return True
    ok = True
    for comp in comps:
        comp_scope = _suv_1623_component_scope(scope, me, comp)
        _suv_1623_set_scope_mask_for_faces(me, comp)
        try:
            _apply_single_island_gradation(context, me, strength, unwrap_math, pack_margin, baseline_axis, baseline_threshold, comp_scope)
        except Exception:
            ok = False
    _suv_1623_set_scope_mask_for_faces(me, selected)
    _select_uv_scope_for_ops(me, scope)
    return bool(ok)
