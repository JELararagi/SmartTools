"""Directional alignment menu for the Smart UV Editor."""

import bpy

from . import resource_api_18168
from .uv_direction_align_unified_18111 import _tr


_MENU_ID = 'SMARTUV_MT_align_pie'
_DIRECTIONS = (
    ('LEFT', 'Left', '左'),
    ('RIGHT', 'Right', '右'),
    ('BOTTOM', 'Bottom', '下'),
    ('TOP', 'Top', '上'),
    ('TL', 'Top Left', '左上'),
    ('TR', 'Top Right', '右上'),
    ('BL', 'Bottom Left', '左下'),
    ('BR', 'Bottom Right', '右下'),
)


class SMARTUV_MT_align_pie(bpy.types.Menu):
    bl_idname = _MENU_ID
    bl_label = 'Align Pie'

    def draw(self, context):
        pie = self.layout.menu_pie()
        pie.operator_context = 'EXEC_REGION_WIN'
        for direction, english, japanese in _DIRECTIONS:
            entry = pie.operator('smart_uv_suite.direction_align', text=_tr(context, english, japanese))
            entry.action = f'ALIGN_{direction}'


def _valid_editor(context):
    if bpy.app.background or context.window is None or context.mode != 'EDIT_MESH':
        return False
    area = context.area
    return area is not None and (area.type, area.ui_type) == ('IMAGE_EDITOR', 'UV')


def _dispatch(context, operator):
    if not _valid_editor(context):
        message = _tr(context, 'Open Align Pie in the UV Editor in Edit Mode.',
                      '編集モードの UV エディターで整列パイを開いてください。')
        operator.report({'WARNING'}, message)
        return False
    if not resource_api_18168.register_class(SMARTUV_MT_align_pie):
        return False
    statuses = bpy.ops.wm.call_menu_pie('INVOKE_DEFAULT', name=_MENU_ID)
    return not statuses.isdisjoint({'FINISHED', 'INTERFACE', 'RUNNING_MODAL'})


def build_handlers(api):
    handler = api.Handler(
        _dispatch,
        'Open the directional alignment pie in the UV Editor. Choose a direction to align the selection.',
        'UV エディターで方向整列のパイメニューを開きます。方向を選ぶと選択した UV が整列します。',
    )
    return {'smart_uv_suite.align_pie': handler}
