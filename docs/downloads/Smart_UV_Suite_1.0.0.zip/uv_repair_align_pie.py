"""Alignment choices for the Smart UV Editor."""
from __future__ import annotations

import bpy

from . import resource_api_18168
from .uv_direction_align_unified_18111 import _tr


# Blender places pie entries west, east, south, north, then the diagonals.
_DIRECTIONS = (
    ("ALIGN_LEFT", "Left", "左"),
    ("ALIGN_RIGHT", "Right", "右"),
    ("ALIGN_BOTTOM", "Bottom", "下"),
    ("ALIGN_TOP", "Top", "上"),
    ("ALIGN_TL", "Top Left", "左上"),
    ("ALIGN_TR", "Top Right", "右上"),
    ("ALIGN_BL", "Bottom Left", "左下"),
    ("ALIGN_BR", "Bottom Right", "右下"),
)


class SMARTUV_MT_align_pie(bpy.types.Menu):
    bl_idname = "SMARTUV_MT_align_pie"
    bl_label = "Align Pie"

    def draw(self, context):
        pie = self.layout.menu_pie()
        pie.operator_context = "EXEC_REGION_WIN"
        for action, en, ja in _DIRECTIONS:
            button = pie.operator("smart_uv_suite.direction_align", text=_tr(context, en, ja))
            button.action = action


def _open_pie(context, op):
    area = context.area
    if (bpy.app.background or context.window is None or area is None
            or area.type != "IMAGE_EDITOR" or area.ui_type != "UV"
            or context.mode != "EDIT_MESH"):
        op.report({"WARNING"}, _tr(
            context, "Open Align Pie in the UV Editor in Edit Mode.",
            "編集モードの UV エディターで整列パイを開いてください。",
        ))
        return False

    if not resource_api_18168.register_class(SMARTUV_MT_align_pie):
        return False
    result = bpy.ops.wm.call_menu_pie("INVOKE_DEFAULT", name=SMARTUV_MT_align_pie.bl_idname)
    return bool(result & {"FINISHED", "INTERFACE", "RUNNING_MODAL"})


def build_handlers(api):
    return {
        "smart_uv_suite.align_pie": api.Handler(
            _open_pie,
            "Open the directional alignment pie in the UV Editor. Choose a direction to align the selection.",
            "UV エディターで方向整列のパイメニューを開きます。方向を選ぶと選択した UV が整列します。",
        ),
    }
