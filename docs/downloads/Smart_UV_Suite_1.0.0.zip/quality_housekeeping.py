from __future__ import annotations
from . import resource_api_18168 as _suv_resource

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None

_NAMESPACE = {}
_REGISTERED = []

_TEXT_PREFIXES = ('SUV_', 'Smart UV')
_IMAGE_PREFIXES = ('SUV_', 'Smart UV')
_MATERIAL_PREFIXES = ('SUV_', 'Smart UV')
_TEXT_HINTS = ('tool_runtime', 'batch', 'support', 'validation', 'scan', 'snapshot', 'report', 'diagnostic', 'manifest', 'history', 'action', 'pipeline', 'texel', 'udim', 'audit', 'matrix', 'coverage', 'feature', 'catalog', 'help', 'guided', 'workflow', 'language', 'translation', 'tooltip', 'localization', 'hub', 'index', 'playbook', 'task', 'flow', 'profile', 'execution', 'registry', 'visual', 'card', 'navigator', 'ui map', 'controls')


def _tr(context, key: str, en: str, ja: str) -> str:
    fn = _NAMESPACE.get('tr') if isinstance(_NAMESPACE, dict) else None
    if callable(fn):
        try:
            return fn(context, key)
        except Exception:
            pass
    prefs_fn = _NAMESPACE.get('_prefs') if isinstance(_NAMESPACE, dict) else None
    prefs = None
    if callable(prefs_fn):
        try:
            prefs = prefs_fn(context)
        except Exception:
            prefs = None
    lang = getattr(prefs, 'ui_language_mode', 'AUTO') if prefs else 'AUTO'
    return ja if lang == 'FORCE_JA' else en


def _bool_label(context, value: bool) -> str:
    return _tr(
        context,
        'ui.bool.on' if value else 'ui.bool.off',
        'On' if value else 'Off',
        'オン' if value else 'オフ',
    )


def _call(name: str, *args, **kwargs):
    fn = _NAMESPACE.get(name) if isinstance(_NAMESPACE, dict) else None
    if callable(fn):
        try:
            return fn(*args, **kwargs)
        except Exception:
            return None
    return None


def _preserve_text_names(context) -> set[str]:
    keep = set()
    for helper in ('_suv_tool_runtime_log_name', '_suv_batch_report_name', '_suv_support_bundle_name', '_suv_validation_report_name', '_suv_scan_report_name', '_suv_report_hub_name', '_suv_playbook_name', '_suv_profile_report_name', '_suv_registry_name', '_suv_doctor_name', '_suv_ui_map_name', '_suv_controls_report_name'):
        try:
            name = _call(helper, context)
            if name:
                keep.add(str(name))
        except Exception:
            pass
    try:
        ws = _call('_suv_ws', context)
    except Exception:
        ws = None
    if ws is not None:
        for attr in ('last_snapshot_name', 'tool_runtime_log_name', 'batch_report_name', 'support_bundle_name', 'validation_report_name', 'scan_report_name'):
            try:
                name = str(getattr(ws, attr, '') or '').strip()
                if name:
                    keep.add(name)
            except Exception:
                pass
    return keep


def _looks_generated_text(name: str) -> bool:
    low = str(name or '').lower()
    if not low:
        return False
    if any(str(name).startswith(prefix) for prefix in _TEXT_PREFIXES):
        return True
    return ('smart uv suite' in low) or any(tok in low for tok in _TEXT_HINTS) and low.startswith('suv_')


def _looks_generated_image(name: str) -> bool:
    nm = str(name or '')
    return bool(nm) and any(nm.startswith(prefix) for prefix in _IMAGE_PREFIXES)


def _looks_generated_material(name: str) -> bool:
    nm = str(name or '')
    return bool(nm) and any(nm.startswith(prefix) for prefix in _MATERIAL_PREFIXES)



def _looks_generated_node_group(name: str) -> bool:
    nm = str(name or '')
    return bool(nm) and (nm.startswith('SUV_') or nm.startswith('Smart UV'))


def _looks_generated_mesh(name: str) -> bool:
    nm = str(name or '')
    return bool(nm) and (nm.startswith('SUV_') or nm.startswith('Smart UV'))


def scan_housekeeping(context) -> dict:
    result = {
        'texts': 0,
        'images': 0,
        'materials': 0,
        'node_groups': 0,
        'meshes': 0,
        'total': 0,
    }
    if bpy is None:
        return result
    preserve = _preserve_text_names(context)
    try:
        for txt in list(getattr(bpy.data, 'texts', []) or []):
            name = getattr(txt, 'name', '')
            if name in preserve:
                continue
            if _looks_generated_text(name):
                result['texts'] += 1
    except Exception:
        pass
    try:
        for img in list(getattr(bpy.data, 'images', []) or []):
            name = getattr(img, 'name', '')
            users = int(getattr(img, 'users', 0) or 0)
            if users <= 0 and _looks_generated_image(name):
                result['images'] += 1
    except Exception:
        pass
    try:
        for mat in list(getattr(bpy.data, 'materials', []) or []):
            name = getattr(mat, 'name', '')
            users = int(getattr(mat, 'users', 0) or 0)
            if users <= 0 and _looks_generated_material(name):
                result['materials'] += 1
    except Exception:
        pass
    try:
        for grp in list(getattr(bpy.data, 'node_groups', []) or []):
            name = getattr(grp, 'name', '')
            users = int(getattr(grp, 'users', 0) or 0)
            if users <= 0 and _looks_generated_node_group(name):
                result['node_groups'] += 1
    except Exception:
        pass
    try:
        for mesh in list(getattr(bpy.data, 'meshes', []) or []):
            name = getattr(mesh, 'name', '')
            users = int(getattr(mesh, 'users', 0) or 0)
            if users <= 0 and _looks_generated_mesh(name):
                result['meshes'] += 1
    except Exception:
        pass
    result['total'] = int(result['texts']) + int(result['images']) + int(result['materials']) + int(result['node_groups']) + int(result['meshes'])
    return result


class SUV_OT_quality_cleanup_generated_data(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_cleanup_generated_data'
    bl_label = 'Cleanup Generated Data'
    bl_description = 'Remove stale UV Suite text reports and orphan helper images or materials that are no longer referenced. / 参照されていない UV Suite の古いテキストレポートや不要な補助画像・マテリアルを削除します。'
    bl_options = {'UNDO'}

    clear_scan_cache: bpy.props.BoolProperty(
        name='Clear Issue Cache',
        description='Also clear cached scan issues before the next validation pass / 次回の検証前にキャッシュされたスキャン問題も消去します',
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        preserve = _preserve_text_names(context)
        removed = {'texts': 0, 'images': 0, 'materials': 0, 'node_groups': 0, 'meshes': 0}
        try:
            for txt in list(bpy.data.texts):
                name = getattr(txt, 'name', '')
                if name in preserve or not _looks_generated_text(name):
                    continue
                bpy.data.texts.remove(txt)
                removed['texts'] += 1
        except Exception as exc:
            self.report({'WARNING'}, f'Cleanup text pass skipped: {exc}')
        try:
            for img in list(bpy.data.images):
                name = getattr(img, 'name', '')
                if int(getattr(img, 'users', 0) or 0) > 0 or not _looks_generated_image(name):
                    continue
                bpy.data.images.remove(img)
                removed['images'] += 1
        except Exception as exc:
            self.report({'WARNING'}, f'Cleanup image pass skipped: {exc}')
        try:
            for mat in list(bpy.data.materials):
                name = getattr(mat, 'name', '')
                if int(getattr(mat, 'users', 0) or 0) > 0 or not _looks_generated_material(name):
                    continue
                bpy.data.materials.remove(mat)
                removed['materials'] += 1
        except Exception as exc:
            self.report({'WARNING'}, f'Cleanup material pass skipped: {exc}')
        try:
            for grp in list(getattr(bpy.data, 'node_groups', []) or []):
                name = getattr(grp, 'name', '')
                if int(getattr(grp, 'users', 0) or 0) > 0 or not _looks_generated_node_group(name):
                    continue
                bpy.data.node_groups.remove(grp)
                removed['node_groups'] += 1
        except Exception as exc:
            self.report({'WARNING'}, f'Cleanup node-group pass skipped: {exc}')
        try:
            for mesh in list(getattr(bpy.data, 'meshes', []) or []):
                name = getattr(mesh, 'name', '')
                if int(getattr(mesh, 'users', 0) or 0) > 0 or not _looks_generated_mesh(name):
                    continue
                bpy.data.meshes.remove(mesh)
                removed['meshes'] += 1
        except Exception as exc:
            self.report({'WARNING'}, f'Cleanup mesh pass skipped: {exc}')
        cache_cleared = False
        if self.clear_scan_cache:
            try:
                _call('_suv_clear_scan_cache', context)
                cache_cleared = True
            except Exception:
                cache_cleared = False
        total = int(removed['texts']) + int(removed['images']) + int(removed['materials']) + int(removed['node_groups']) + int(removed['meshes'])
        if isinstance(_NAMESPACE, dict):
            _NAMESPACE['_suv_quality_housekeeping_last'] = dict(removed, total=total, cache_cleared=cache_cleared)
        msg = _tr(context, 'msg.quality_cleanup_done', 'Cleanup finished. Removed {total} item(s): texts {texts}, images {images}, materials {materials}, node groups {node_groups}, meshes {meshes}. Cache cleared: {cache}.', 'クリーンアップが完了しました。削除: 合計 {total} 件（テキスト {texts}、画像 {images}、マテリアル {materials}、ノードグループ {node_groups}、メッシュ {meshes}）。キャッシュ消去: {cache}')
        self.report({'INFO'}, msg.format(total=total, texts=removed['texts'], images=removed['images'], materials=removed['materials'], node_groups=removed['node_groups'], meshes=removed['meshes'], cache=_bool_label(context, cache_cleared)))
        return {'FINISHED'}


class SUV_OT_quality_scan_generated_data(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_scan_generated_data'
    bl_label = 'Scan Generated Data'
    bl_description = 'Count stale UV Suite helper data so you can see how much generated cleanup is available before deleting anything. / 生成済みの UV Suite 補助データを数え、削除前にどれだけクリーンアップ対象があるか確認します。'
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        counts = scan_housekeeping(context)
        if isinstance(_NAMESPACE, dict):
            _NAMESPACE['_suv_quality_housekeeping_last'] = dict(counts)
        msg = _tr(context, 'msg.quality_cleanup_scan', 'Cleanup scan found {total} candidate(s): texts {texts}, images {images}, materials {materials}, node groups {node_groups}, meshes {meshes}.', 'クリーンアップ候補を {total} 件検出しました（テキスト {texts}、画像 {images}、マテリアル {materials}、ノードグループ {node_groups}、メッシュ {meshes}）。')
        self.report({'INFO'}, msg.format(**counts))
        return {'FINISHED'}


def register(namespace: dict):
    global _NAMESPACE
    _NAMESPACE = namespace if isinstance(namespace, dict) else {}
    if bpy is None:
        return []
    classes = [SUV_OT_quality_cleanup_generated_data, SUV_OT_quality_scan_generated_data]
    reg = []
    for cls in classes:
        try:
            _suv_resource.register_class(cls)
            reg.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = reg
    return reg


def unregister(namespace: dict | None = None):
    if bpy is None:
        return []
    removed = []
    for cls in reversed(list(_REGISTERED)):
        try:
            _suv_resource.unregister_class(cls)
            removed.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = []
    return removed
