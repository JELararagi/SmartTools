# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import hashlib
import json
import os
import pickle
import re
import sys
import zlib
from functools import lru_cache
from typing import Any, Iterable

import bpy

_REGISTER_SANITIZER_INSTALLED = False
_ORIGINAL_REGISTER_CLASS = None
_ORIGINAL_LAYOUT_METHODS: dict[str, object] = {}
_ORIGINAL_PROP_CONSTRUCTORS: dict[str, object] = {}
_ORIGINAL_OPERATOR_REPORT = None
_TRANSLATIONS_REGISTERED = False
_TRANSLATION_CACHE: dict[str, str] | None = None
_REVERSE_TRANSLATION_CACHE: dict[str, str] | None = None
_LOCALIZED_CLASSES: set[type] = set()
_PROP_CONSTRUCTOR_SOURCE_BY_ID: dict[int, dict] = {}
_STORED_LANGUAGE_MODE: str | None = None
_ENUM_ITEMS_CALLBACK_DEPTH = 0
_ENUM_ITEMS_FALLBACK_CACHE: dict[int, tuple] = {}
_DEFERRED_SANITIZE_CACHE: dict[int, tuple[object, str, str, tuple]] = {}
_CLASS_MATERIALIZE_CACHE: dict[int, tuple[object, tuple]] = {}
_CLASS_SANITIZE_CACHE: dict[int, tuple[object, str, tuple]] = {}
_LANGUAGE_STATE_CACHE: tuple[tuple[str, str, str, str], bool] | None = None
_STATIC_PROPERTY_CATALOG: dict[str, tuple] | None = None
_STATIC_PROPERTY_CATALOG_FAILED = False

_JA_RE = re.compile(r"[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uff66-\uff9f]")
_WORD_RE = re.compile(r"[A-Za-z][A-Za-z0-9+_.-]*")

_MANUAL_EN_JA: dict[str, str] = {
    'Scales how strongly edges predicted to stretch after unwrapping (from edge length, face area and thinness) reinforce edges that already have evidence such as a fold angle. This alone does not make a seam.': '辺長、隣接面面積、細長さから展開時に伸びやすい箇所を予測し、折れ角などの根拠がある辺を後押しする強度です。これだけではシームになりません。',
    'Scales how strongly long continuous edge loops and cuts along the model flow are kept. It reinforces edges that already have evidence such as a fold angle; higher values give less broken seams. This alone does not make a seam.': '長く連続したエッジループやモデルの流れに沿った切れ目を維持する強度です。折れ角などの根拠がある辺を後押しし、高くすると途切れにくいシームになります。これだけではシームになりません。',
    'Predicts edges likely to stretch after unwrapping from uneven lengths and fold angles, and reinforces edges that already have evidence such as a fold angle. This alone does not make a seam.': '長さの偏りや折れ角から展開後に伸びやすい辺を予測し、折れ角などの根拠がある辺を後押しする強度です。これだけではシームになりません。',
    'Keeps continuous edge loops and long cuts. It reinforces edges that already have evidence such as a fold angle. This alone does not make a seam.': '連続したエッジループや長い切れ目を維持する強度です。折れ角などの根拠がある辺を後押しします。これだけではシームになりません。',
    'For organic shapes: a looser fold-angle limit keeps large continuous surfaces from being cut.': '折れ角のしきい値を緩め、大きな連続面を切りにくくする有機形状向け設定です。',
    'Strengthens the stretch prediction so edges with evidence such as a fold angle are cut more readily, reducing distortion.': '引張予測を強め、折れ角などの根拠がある辺を切りやすくして歪みを抑えます。',
    # 1.8.233: pairs for raw-JA bl_label/bl_description strings so the EN
    # locale shows English (sanitize_class reverse lookup) instead of raw JA.
    'Delete Checker': 'チェッカー削除',
    'Toggle Checker Material': 'チェッカーマテリアル切替',
    'Generate a checker map from the configured image resolution, check size, and colors. Update it with the current settings when it already exists.': '設定した画像解像度・チェックサイズ・カラーからチェッカーマップを生成します。既に作成済みの場合は現在の設定で更新します。',
    'Delete the created checker map and the checker display material, and hide them from the UV Editor.': '作成したチェッカーマップとチェッカー表示用マテリアルを削除し、UVエディターから非表示にします。',
    'Temporarily switch the selected objects to the checker material and restore the original materials when run again.': '選択オブジェクトのマテリアルを一時的にチェッカー表示へ切り替え、再実行で元マテリアルへ戻します。',
    'Save/Load Seam Settings': 'シーム設定保存/読み込み',
    'Mark/Clear Seams': 'シームをマーク・クリア',
    'Auto Packing': '自動パッキング',
    'Reopen Smart UV': 'スマート UV を再表示',
    'Smart UV': 'Smart UV',
    'Smart UV': 'Smart UV',
    'Smart Tools': 'Smart Tools',
    'Addon Preferences': 'アドオン設定',
    'Add-on Preferences': 'アドオン設定',
    'Preferences': '設定',
    'Settings': '設定',
    'Workspace Settings': 'ワークスペース設定',
    'UI Language': '表示言語',
    'Auto': '自動',
    'English': '英語',
    'Japanese': '日本語',
    'English only': '英語のみ',
    'Japanese only': '日本語のみ',
    'Follow Blender': 'Blenderに追従',
    'Auto (Follow Blender)': '自動（Blenderに追従）',
    'Force English': '英語に固定',
    'Force Japanese': '日本語に固定',
    'Follow Blender language automatically.': 'Blenderの言語設定に自動追従します。',
    'Always show only English in this add-on.': 'このアドオンでは常に英語だけを表示します。',
    'Always show only Japanese in this add-on.': 'このアドオンでは常に日本語だけを表示します。',
    'Choose whether UV Suite follows Blender language automatically or forces a language for this add-on.': 'UV Suite の表示言語を Blender の設定に合わせるか、このアドオンだけ固定するか選びます。',
    'UV Settings': 'UV設定',
    'Detailed Unwrap': '詳細展開',
    'Activate Core': '本体を有効化',
    'Deactivate Core': '本体を無効化',
    'Status Core': '本体状態',
    'Activate Core': 'UV Suite 本体の有効化',
    'Open Smart Tools and load the tool_runtime only when this window is actually requested.': 'Smart Toolsを開き、このウィンドウが実際に必要になった時だけランタイムを読み込みます。',
    'Create and assign checker material for the selected objects': '選択中のオブジェクト用にチェッカーマテリアルを作成して割り当てます。',
    'Move Up UV Layer \nAlt+Click - Moves only the UV layer, keeping name in place.': 'UVレイヤーを上へ移動します。Alt+クリックでは名前の位置を保ったまま、UVレイヤーだけを移動します。',
    'Align Verts or UV Islands': '頂点またはUVアイランドを整列します。',
    'Open': '開く', 'Close': '閉じる', 'Apply': '適用', 'Reset': 'スケールリセット', 'Clear': 'クリア',
    'Delete': '削除', 'Remove from Trim List': '削除', 'Add': '追加', 'Create': '作成', 'Write': '書き出し',
    'Save': '保存', 'Load': '読込', 'Import': 'インポート', 'Export': 'エクスポート', 'Run': '実行',
    'Update': '更新', 'Refresh': '更新', 'Copy': 'コピー', 'Paste': '貼り付け', 'Select Panel': '選択',
    'Deselect': '選択解除', 'Batch Inspect': '検査', 'Scan': 'スキャン', 'Validate': '検証', 'Repair': '修復',
    'Fix': '修正', 'Toggle': '切替', 'Enable': '有効化', 'Disable': '無効化', 'Show': '表示',
    'Hide': '非表示', 'Move': '移動', 'Rotate': '回転', 'Scale': 'スケール', 'Fit': 'フィット',
    'Align': '整列', 'Orient': '方向合わせ', 'Straighten': '直線化', 'Straight': '直線化',
    'Rectify': '矩形化', 'Unfold Trim': '展開', 'Pack': 'パック', 'Stack': 'スタック',
    'Unstack': 'スタック解除', 'Select Mirrored 3D': 'ミラー', 'Flip': '反転', 'Randomize': 'ランダム化',
    'Projection': '投影', 'Project': '投影', 'Bake': 'ベイク', 'Find': '検索', 'Prepare': '準備',
    'And': 'と', 'Or': 'または', 'From': 'から', 'To': 'へ', 'In': '内', 'On': 'オン',
    'Off': 'オフ', 'By': 'で', 'With': '付き', 'For': '用', 'Of': 'の', 'All': 'すべて',
    'Each': '各', 'Up': '上へ', 'Down': '下へ', 'Previous': '前へ', 'Next': '次へ', 'Only': 'のみ',
    'Name': '名前', 'Place': '位置', 'Assign': '割り当て', 'Current': '現在',
    'UV': 'UV', 'UVs': 'UV', 'UDIM': 'UDIM', 'TD': 'TD', 'ID': 'ID', 'Map': 'マップ', 'Maps': 'マップ',
    'Layer': 'レイヤー', 'Layers': 'レイヤー', 'Channel': 'チャンネル', 'Channels': 'チャンネル',
    'Island': 'アイランド', 'Islands': 'アイランド', 'Shell': 'シェル', 'Shells': 'シェル',
    'Face': '面', 'Faces': '面', 'Edge': 'エッジ', 'Edges': 'エッジ', 'Vert': '頂点', 'Verts': '頂点',
    'Vertex': '頂点', 'Vertices': '頂点', 'Boundary': '境界', 'Seam': 'シーム', 'Seams': 'シーム',
    'Pin': 'ピン', 'Pins': 'ピン', 'Tile': 'タイル', 'Tiles': 'タイル', 'Texture': 'テクスチャ',
    'Textures': 'テクスチャ', 'Texel': 'テクセル', 'Density': '密度', 'Margin': 'マージン',
    'Padding Panel': '余白', 'Spacing': '間隔', 'Size': 'サイズ', 'Angle': '角度', 'Axis': '軸',
    'Horizontal': '水平', 'Vertical': '垂直', 'Active': 'アクティブ', 'Selected': '選択中',
    'Selection': '選択', 'Set': 'セット', 'Sets': 'セット', 'Group': 'グループ', 'Groups': 'グループ',
    'Batch': '一括', 'Multi': '複数', 'Object': 'オブジェクト', 'Objects': 'オブジェクト',
    'Mesh': 'メッシュ', 'Material': 'マテリアル', 'Materials': 'マテリアル', 'Atlas': 'アトラス',
    'Color': 'カラー', 'Colors': 'カラー', 'Checker': 'チェッカー', 'Preview': 'プレビュー',
    'View': 'ビュー', 'Viewport': 'ビューポート', 'Editor': 'エディター', '3D View': '3Dビュー',
    'Sidebar': 'サイドバー', 'N-panel': 'Nパネル', 'Panel': 'パネル',
    'Panels': 'パネル', 'Menu': 'メニュー', 'Pie': 'パイ', 'Tool': 'ツール', 'Tools': 'ツール',
    'More': 'その他', 'Quick': 'クイック', 'Basic': '基本', 'Advanced': '高度', 'Native': 'コア',
    'Stage': 'ステージ', 'Compatibility': '互換', 'External': '外部', 'Layout Panel': 'レイアウトパネル',
    'Transform': '変形', 'Mapping': 'マッピング', 'Inspector': '検査', 'Inspection': '検査',
    'Issue': '問題', 'Issues': '問題', 'Overlay': 'オーバーレイ', 'Heatmap': 'ヒートマップ',
    'Stretch': 'ストレッチ', 'Overlap': '重なり', 'Overlapped': '重なり', 'Check Flipped': '反転',
    'Identical': '同一', 'Similar': '類似', 'Symmetry': '対称', 'Symmetric': '対称',
    'Topology': 'トポロジー', 'Trim': 'トリム', 'Trims': 'トリム', 'TrimSheet': 'トリムシート',
    'Trimsheet': 'トリムシート', 'Hotspot': 'ホットスポット', 'Report': 'レポート', 'Reports': 'レポート',
    'Profile': 'プロファイル', 'Profiles': 'プロファイル', 'Recipe': 'レシピ', 'Recipes': 'レシピ',
    'Workflow': 'ワークフロー', 'Workflows': 'ワークフロー', 'Library': 'ライブラリ', 'Libraries': 'ライブラリ',
    'UV Crossing Gesture Select': 'UV交差ジェスチャ選択',
    'Runs an exact UV Editor box, circle or lasso crossing selection owned by Smart UV Suite.': 'Smart UV Suite が所有する、UVエディター専用の正確なボックス、円、または投げ縄の交差選択を実行します。',
    'Gesture': 'ジェスチャ',
    'UV crossing gesture shape used for this selection.': 'この選択で使用するUV交差ジェスチャの形状です。',
    'Box': 'ボックス',
    'Axis-aligned UV crossing box selection.': '軸に揃えたUV交差ボックス選択です。',
    'Circle': '円',
    'UV crossing circle selection.': 'UV交差円選択です。',
    'Lasso': '投げ縄',
    'UV crossing lasso selection.': 'UV交差投げ縄選択です。',
    'Mode': 'モード',
    'UV element mode for this crossing selection.': 'この交差選択で使用するUV要素モードです。',
    'Follow the current UV or mesh select mode.': '現在のUVまたはメッシュ選択モードに従います。',
    'UV vertex crossing selection.': 'UV頂点の交差選択です。',
    'UV edge crossing selection.': 'UV辺の交差選択です。',
    'UV face crossing selection.': 'UV面の交差選択です。',
    'Selection Operation': '選択操作',
    'How the UV crossing set combines with the pre-gesture selection.': 'UV交差セットをジェスチャ開始前の選択とどのように組み合わせるかを指定します。',
    'Shift adds, Ctrl subtracts, Shift+Ctrl toggles.': 'Shiftで追加、Ctrlで減算、Shift+Ctrlで切り替えます。',
    'Replace': '置換',
    'Replace the selection with the crossing set.': '選択を交差セットで置き換えます。',
    'Add the crossing set to the selection.': '交差セットを選択に追加します。',
    'Subtract': '減算',
    'Remove the crossing set from the selection.': '交差セットを選択から除外します。',
    'Toggle the crossing set relative to the selection.': '選択に対して交差セットを切り替えます。',
    'Smart UV crossing selection requires an editable UV mesh in Edit Mode': 'Smart UV交差選択には、編集モードの編集可能なUVメッシュが必要です',
    'Smart UV crossing selection for edges is disabled in settings': 'Smart UVの辺交差選択は設定で無効になっています',
    'Smart UV crossing selection for faces is disabled in settings': 'Smart UVの面交差選択は設定で無効になっています',
    'Smart UV crossing selection cancelled; previous UV selection restored': 'Smart UV交差選択をキャンセルしました。以前のUV選択を復元しました',
    'Smart UV crossing selection selected {count} UV elements': 'Smart UV交差選択で {count} 個のUV要素を選択しました',
    'Smart UV Proportional Size Cursor': 'Smart UV のプロポーショナルのサイズカーソル',
    'SmartUV-owned UV Editor proportional editing size cursor entry point.': 'SmartUVが所有する、UVエディターのプロポーショナル編集サイズカーソルのエントリーポイントです。',
    'Delta': '差分',
    'Optional proportional size delta for direct execution.': '直接実行時に使用する任意のプロポーショナルサイズ差分です。',
    'UV Crossing Select Edges': 'UV の交差で辺を選択',
    'Runs the exact SmartUV UV Editor edge crossing box selection.': 'SmartUVのUVエディター専用の正確な辺交差ボックス選択を実行します。',
    'UV Crossing Select Faces': 'UV の交差で面を選択',
    'Runs the exact SmartUV UV Editor face crossing box selection.': 'SmartUVのUVエディター専用の正確な面交差ボックス選択を実行します。',
    'UV Editor Ownership': 'UVエディター操作の管理',
    'Crossing Selection: Edges': '交差選択：辺',
    'Crossing Selection: Faces': '交差選択：面',
    'UV Crossing Selection: Edges': 'UV交差選択：辺',
    'UV Crossing Selection: Faces': 'UV交差選択：面',
    'UV Proportional Cursor Entry': 'UVプロポーショナル編集カーソル入力',
    'SmartUV owns UV Editor edge crossing selection behavior migrated from SmartTransform. SmartTransform keeps its 3D View crossing selection.': 'SmartUVがUVエディターの辺交差選択を担当します。SmartTransformは3Dビューの交差選択だけを引き続き担当します。',
    'SmartUV owns UV Editor face crossing selection behavior migrated from SmartTransform. SmartTransform keeps its 3D View crossing selection.': 'SmartUVがUVエディターの面交差選択を担当します。SmartTransformは3Dビューの交差選択だけを引き続き担当します。',
    "Expose the SmartUV-owned UV Editor proportional editing size cursor entry point migrated from SmartTransform's UV surface.": 'SmartUVが担当するUVエディター専用のプロポーショナル編集サイズカーソル入力を有効にします。SmartTransformのUV操作面から移管された機能です。',
    'Smart UV Crossing Selection Watch': 'Smart UV交差選択監視',
    'Preferences > Keymap > Image Editor > UV Editor': 'プリファレンス > キーマップ > 画像エディター > UVエディター',
    'Preferences > Keymap > Image > UV Editor': 'プリファレンス > キーマップ > 画像 > UVエディター',
    'Page Up / Page Down (Delta 0.1 / -0.1)': 'Page Up / Page Down（Delta 0.1 / -0.1）',
    'Image Editor / UV Editor tool maps': '画像エディター / UVエディター系ツールマップ',
    'Image Editor tool maps': '画像エディター系ツールマップ',
    'Image Editor Scale tool maps': '画像エディターのスケールツール系マップ',
}

_PHRASE_EN_JA: tuple[tuple[str, str], ...] = tuple(sorted({
    'Create and assign': '作成して割り当て',
    'for the selected objects': '選択中のオブジェクト用',
    'selected objects': '選択中のオブジェクト',
    'UV Sync Selection': 'UV同期選択',
    'UV Editor': 'UVエディター',
    'User Interface': 'ユーザーインターフェース',
    'Add-on settings': 'アドオン設定',
    'Addon settings': 'アドオン設定',
    'Texture Projection Menu': 'テクスチャ投影',
    'Texture Lock Menu': 'テクスチャロック',
    'Texture Wrap Menu': 'テクスチャラップ',
    'World Scale UV Menu': 'ワールドスケールUV',
    'Copy/Paste UV Menu': '貼り付けUVコピーメニュー',
    'Selection Set': '選択セット',
    'Seam Set': 'シームセット',
    'Layout Set': 'レイアウトセット',
    'Density Panel': 'テクセル密度',
    'Color IDs': 'カラーID',
    'ID Map': 'IDマップ',
    'Checker Material': 'チェッカーマテリアル',
    'Quality Audit': '品質監査',
    'Quality Doctor': '品質ドクター',
    'Feature Matrix': '機能マトリクス',
    'Report Hub': 'レポートハブ',
    'Language Coverage': '言語対応レポート',
    'Visual UI Map': '視覚UIマップ',
    'Execution Profiles': '実行プロファイル',
    'Admission Gate': '受入ゲート',
    'Route Advisor': 'ルートアドバイザー',
    'Guided Workflow': 'ガイド付きワークフロー',
    'Core Stage': 'コアステージ',
    'Hard Surface': 'ハードサーフェス',
    'UV Seam': 'UVシーム',
    'UV Map': 'UVマップ',
    'UV Maps': 'UVマップ',
}.items(), key=lambda item: len(item[0]), reverse=True))

_VERB_TEMPLATES: tuple[tuple[str, str], ...] = (
    ('Open ', '{rest}を開きます。'), ('Write ', '{rest}を書き出します。'), ('Create ', '{rest}を作成します。'),
    ('Add ', '{rest}を追加します。'), ('Remove ', '{rest}を削除します。'), ('Delete ', '{rest}を削除します。'),
    ('Clear ', '{rest}をクリアします。'), ('Reset ', '{rest}をリセットします。'), ('Apply ', '{rest}を適用します。'),
    ('Run ', '{rest}を実行します。'), ('Select ', '{rest}を選択します。'), ('Deselect ', '{rest}の選択を解除します。'),
    ('Scan ', '{rest}をスキャンします。'), ('Validate ', '{rest}を検証します。'), ('Prepare ', '{rest}を準備します。'),
    ('Toggle ', '{rest}を切り替えます。'), ('Enable ', '{rest}を有効化します。'), ('Disable ', '{rest}を無効化します。'),
    ('Copy ', '{rest}をコピーします。'), ('Paste ', '{rest}を貼り付けます。'), ('Load ', '{rest}を読み込みます。'),
    ('Save ', '{rest}を保存します。'), ('Import ', '{rest}をインポートします。'), ('Export ', '{rest}をエクスポートします。'),
    ('Move ', '{rest}を移動します。'), ('Rotate ', '{rest}を回転します。'), ('Scale ', '{rest}をスケールします。'),
    ('Align ', '{rest}を整列します。'), ('Fit ', '{rest}に合わせます。'), ('Find ', '{rest}を検索します。'),
    ('Refresh ', '{rest}を更新します。'),
)

_LABEL_VERB_TEMPLATES: tuple[tuple[str, str], ...] = (
    ('Open ', '{rest}を開く'), ('Write ', '{rest}を書き出し'), ('Create ', '{rest}作成'), ('Add ', '{rest}追加'),
    ('Remove ', '{rest}削除'), ('Delete ', '{rest}削除'), ('Clear ', '{rest}クリア'), ('Reset ', '{rest}リセット'),
    ('Apply ', '{rest}適用'), ('Run ', '{rest}実行'), ('Select ', '{rest}選択'), ('Scan ', '{rest}スキャン'),
    ('Validate ', '{rest}検証'), ('Prepare ', '{rest}準備'), ('Toggle ', '{rest}切替'), ('Enable ', '{rest}有効化'),
    ('Disable ', '{rest}無効化'), ('Copy ', '{rest}コピー'), ('Paste ', '{rest}貼り付け'), ('Load ', '{rest}読込'),
    ('Save ', '{rest}保存'), ('Import ', '{rest}インポート'), ('Export ', '{rest}エクスポート'),
    ('Move Up ', '{rest}を上へ移動'), ('Move Down ', '{rest}を下へ移動'), ('Move ', '{rest}移動'),
    ('Rotate ', '{rest}回転'), ('Scale ', '{rest}スケール'), ('Align ', '{rest}整列'), ('Fit ', '{rest}フィット'),
    ('Find ', '{rest}検索'), ('Refresh ', '{rest}更新'),
)

_TOOLTIP_RULES: tuple[tuple[tuple[str, ...], str, str, str], ...] = (
    (('unwrap', 'unfold', 'projection', 'project', 'flatten'), '現在の選択やアクティブメッシュからUVを作成・再展開するツールです。', '対象の面やアイランドを選択してから実行し、結果をチェッカー表示や歪み確認で見直します。', '展開の開始時や、既存UVを作り直したい時に使います。'),
    (('seam', 'cut', 'stitch', 'weld', 'border'), 'UVシェルの分割位置や接続状態を編集するツールです。', '対象エッジやアイランドを選び、シーム付与・解除・縫合結果を境界表示で確認します。', '展開前の切れ目作成、重なり修正後の再接続、境界整理に使います。'),
    (('align', 'orient', 'straight', 'rectify', 'quadrify', 'grid'), 'UVの向き、直線性、矩形性を整えるツールです。', '基準にしたい辺・頂点・アイランドを選択して実行し、回転方向と形状の崩れを確認します。', 'トリム、帯状パーツ、ハードサーフェスの整ったUVが必要な時に使います。'),
    (('pack', 'layout', 'fit', 'tile', 'udim', 'bounds'), 'UVアイランドをタイルや指定範囲へ配置するツールです。', '先にアイランド形状を整え、余白、重なり、UDIM位置を確認しながら実行します。', '最終配置、ベイク前、書き出し前のレイアウト整理に使います。'),
    (('stack', 'match', 'similar', 'identical', 'group'), '似た形状や関連アイランドを比較・重ね合わせるツールです。', '基準アイランドや繰り返しパーツを選び、向きとスケールが揃っているか確認します。', '左右対称、反復パーツ、トリム再利用のUVを整理したい時に使います。'),
    (('checker', 'preview', 'overlay', 'heatmap', 'color', 'visual'), 'UV状態を見やすく確認するための表示・補助ツールです。', '表示を有効にして、歪み、密度、重なり、色分けの状態を比較します。', '問題箇所を視覚的に見つけたい確認作業で使います。'),
    (('select', 'find', 'inspect', 'scan', 'issue', 'flipped', 'overlap', 'zero'), '条件に合うUVや問題箇所を検出・選択するツールです。', 'スキャン後に選択結果を確認し、必要な修正ツールへ進みます。', '修復、パック、ベイク、書き出しの前に状態確認したい時に使います。'),
    (('density', 'texel', 'td'), 'テクセル密度やテクスチャスケールを測定・調整するツールです。', '基準密度を取得または目標値を設定し、複数アイランド間の見た目のスケールを揃えます。', '複数素材や複数オブジェクトで解像感を統一したい時に使います。'),
    (('uv map', 'uvmap', 'layer', 'channel'), 'UVマップやUVレイヤーを管理するツールです。', '対象オブジェクトを選び、作成、削除、名前変更、順序変更、アクティブ化を行います。', 'ベイク用、ライトマップ用、書き出し用など複数UVを扱う時に使います。'),
    (('sym', 'symmetry', 'symmetric', 'mirror'), '対称関係のあるUVを揃えるツールです。', '基準側を決めてから、ミラー、転送、スタック結果を反対側で確認します。', '左右対称メッシュや対称パーツの配置・シームを揃えたい時に使います。'),
    (('atlas', 'bake', 'material'), 'アトラス、ベイク、マテリアル出力を準備するツールです。', 'UV配置と名前を確認してから生成・ベイクを行い、出力結果をレビューします。', '複数オブジェクトをまとめた公開前データやテクスチャ作成で使います。'),
    (('preset', 'profile', 'recipe', 'workflow', 'library'), '再利用できる設定やワークフローを読み込み・保存・適用するツールです。', '目的に合うプリセットを選び、適用後に必要な項目だけ調整します。', '同じUV作業を安定して繰り返したい時に使います。'),
    (('trim', 'hotspot', 'division', 'cell', 'band'), 'トリムシートやホットスポット用の配置を補助するツールです。', 'セル、帯、分割範囲を先に用意し、アイランドをその領域へ合わせます。', '反復パーツを既存テクスチャ領域へ効率よく割り当てたい時に使います。'),
    (('report', 'audit', 'doctor', 'catalog', 'matrix', 'readiness', 'diagnostic', 'registry', 'glossary', 'handbook'), 'UV Suite の状態や対応範囲を確認するレポート系ツールです。', '実行後に生成されたテキストを読み、次に必要な修正や確認へ進みます。', 'トラブルシュート、品質確認、共有前チェックに使います。'),
)


def _safe_collection_get(collection, key: str):
    if collection is None:
        return None
    try:
        return collection.get(key)
    except Exception:
        try:
            return collection[key]
        except Exception:
            return None


def _root_addon_id_candidates() -> tuple[str, ...]:
    values: list[str] = []
    def _append(candidate: object) -> None:
        text = str(candidate or '').strip().strip('.')
        if text and text not in values:
            values.append(text)
        if text.startswith('bl_ext.'):
            short = text.rsplit('.', 1)[-1]
            if short and short not in values:
                values.append(short)
        elif '.' in text:
            short = text.rsplit('.', 1)[-1]
            if short and short not in values:
                values.append(short)
    _append(__package__)
    _append(__name__.rpartition('.')[0])
    _append('uv_suite')
    return tuple(values)


def _addon_module_prefixes() -> tuple[str, ...]:
    values: list[str] = []
    def _append(value: object) -> None:
        text = str(value or '').strip().strip('.')
        if not text:
            return
        if text not in values:
            values.append(text)
        if text.startswith('bl_ext.'):
            short = text.rsplit('.', 1)[-1]
            if short and short not in values:
                values.append(short)
    for candidate in _root_addon_id_candidates():
        _append(candidate)
    _append('uv_suite')
    return tuple(values)


def _module_is_this_addon(module_name: object) -> bool:
    name = str(module_name or '').strip()
    if not name or name == __name__:
        return False
    for prefix in _addon_module_prefixes():
        if name == prefix or name.startswith(prefix + '.'):
            return True
    return False


def _class_belongs_to_this_addon(cls: object) -> bool:
    try:
        return _module_is_this_addon(getattr(cls, '__module__', ''))
    except Exception:
        return False


def _stack_has_this_addon_caller(max_depth: int = 18) -> bool:
    try:
        frame = sys._getframe(2)
    except Exception:
        return True
    depth = 0
    while frame is not None and depth < max_depth:
        try:
            module_name = frame.f_globals.get('__name__', '')
            if _module_is_this_addon(module_name):
                return True
        except Exception:
            pass
        frame = frame.f_back
        depth += 1
    return False


def _language_key(context=None) -> str:
    return 'JA' if is_japanese(context) else 'EN'


def addon_preferences(context=None):
    context = context or getattr(bpy, 'context', None)
    try:
        from . import tool_runtime as _tool_runtime
        prefs = _tool_runtime.get_addon_preferences(context, __package__, __name__, __file__)
        if prefs is not None:
            return prefs
    except Exception:
        pass
    prefs = getattr(context, 'preferences', None) if context is not None else getattr(getattr(bpy, 'context', None), 'preferences', None)
    addons = getattr(prefs, 'addons', None)
    if addons is None:
        return None
    for key in _root_addon_id_candidates():
        addon = _safe_collection_get(addons, key)
        obj = getattr(addon, 'preferences', None) if addon is not None else None
        if obj is not None:
            return obj
    return None


def _settings_package_id() -> str:
    for candidate in _root_addon_id_candidates():
        text = str(candidate or '').strip().strip('.')
        if not text:
            continue
        if text.startswith('bl_ext.') or '.' in text:
            text = text.rsplit('.', 1)[-1]
        return text or 'uv_suite'
    return 'uv_suite'


def _settings_file_path(create: bool = False) -> str:
    try:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            path = user_resource('CONFIG', path='', create=bool(create))
            if path:
                target = os.path.join(path, 'Smart_UV_Suite')
                if create:
                    os.makedirs(target, exist_ok=True)
                return os.path.join(target, 'Smart_UV_Suite.json')
    except Exception:
        pass
    version = '5.1'
    try:
        app_version = getattr(getattr(bpy, 'app', None), 'version', (5, 1, 0)) or (5, 1, 0)
        version = f"{int(app_version[0])}.{int(app_version[1])}"
    except Exception:
        pass
    appdata = os.environ.get('APPDATA')
    if appdata:
        target = os.path.join(appdata, 'Blender Foundation', 'Blender', version, 'config')
    else:
        target = os.path.join(os.path.expanduser('~'), '.config', 'blender', version, 'config')
    if create:
        os.makedirs(os.path.join(target, 'Smart_UV_Suite'), exist_ok=True)
    return os.path.join(target, 'Smart_UV_Suite', 'Smart_UV_Suite.json')


def set_stored_language_mode(mode: object) -> str:
    """Update the in-memory language selector without reading persistence.

    File access belongs to preferences.register()/load handlers.  Keeping this
    cache explicit prevents Panel.draw() and enum callbacks from reaching open().
    """
    global _STORED_LANGUAGE_MODE, _LANGUAGE_STATE_CACHE
    value = str(mode or '').strip().upper()
    if value not in {'FORCE_EN', 'FORCE_JA', 'AUTO'}:
        value = 'AUTO'
    _STORED_LANGUAGE_MODE = value
    _LANGUAGE_STATE_CACHE = None
    return value


def _stored_language_mode() -> str:
    value = str(_STORED_LANGUAGE_MODE or '').strip().upper()
    return value if value in {'FORCE_EN', 'FORCE_JA', 'AUTO'} else 'AUTO'


def language_mode(context=None) -> str:
    # Do not query AddonPreferences here. Enum item callbacks may call the
    # translation layer while the AddonPreferences RNA is being evaluated; asking
    # the same preferences object for ui_language_mode at that point recurses.
    # The N-panel build follows Blender's language setting, with optional forced
    # mode read only from the lightweight saved runtime value.
    stored = _stored_language_mode()
    if stored in {'FORCE_EN', 'FORCE_JA'}:
        return stored
    return 'AUTO'


def is_japanese(context=None) -> bool:
    """Return the active add-on language without rebuilding state per UI item.

    Property and enum sanitization asks for the language thousands of times while
    Smart UV is registered.  The relevant Blender values are immutable for that
    registration pass, so cache the result by the exact saved-mode / UI-language /
    translation-locale signature.  A Blender language change or an add-on language
    change produces a different signature and therefore refreshes automatically.
    """
    global _LANGUAGE_STATE_CACHE
    mode = language_mode(context)
    if mode == 'FORCE_JA':
        return True
    if mode == 'FORCE_EN':
        return False

    ctx = context or getattr(bpy, 'context', None)
    fallback_ctx = getattr(bpy, 'context', None)
    primary_language = ''
    fallback_language = ''
    locale = ''
    try:
        view = getattr(getattr(ctx, 'preferences', None), 'view', None)
        primary_language = str(getattr(view, 'language', '') or '')
    except Exception:
        pass
    if fallback_ctx is not ctx:
        try:
            view = getattr(getattr(fallback_ctx, 'preferences', None), 'view', None)
            fallback_language = str(getattr(view, 'language', '') or '')
        except Exception:
            pass
    try:
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '')
    except Exception:
        pass
    signature = (str(mode), primary_language, fallback_language, locale)
    cached = _LANGUAGE_STATE_CACHE
    if cached is not None and cached[0] == signature:
        return bool(cached[1])
    joined = ' '.join(signature[1:]).upper()
    result = any(token in joined for token in ('JA', 'JA_JP', 'JAPANESE', 'JP'))
    _LANGUAGE_STATE_CACHE = (signature, bool(result))
    return bool(result)


def pick(en: str, ja: str, context=None) -> str:
    return str(ja if is_japanese(context) else en)


def contains_japanese(text: object) -> bool:
    return bool(_JA_RE.search(str(text or '')))


@lru_cache(maxsize=4096)
def _split_bilingual_inline_cached(raw: str) -> tuple[str, str, bool]:
    """Return an immutable English/Japanese pair for one normalized string."""
    if not raw:
        return raw, raw, False

    candidates: list[tuple[int, int, str, str]] = []
    for match in re.finditer(r'\s*(?:/|／|\||｜)\s*', raw):
        left = raw[:match.start()].strip()
        right = raw[match.end():].strip()
        if not left or not right:
            continue
        left_ja = contains_japanese(left)
        right_ja = contains_japanese(right)
        if left_ja == right_ja:
            continue
        en = right if left_ja else left
        ja = left if left_ja else right
        en_has_latin = bool(_WORD_RE.search(en))
        ja_has_latin = bool(_WORD_RE.search(ja))
        en_looks_phrase = (' ' in en) or len(en) >= 18 or any(ch in en for ch in ('.', ':', ';', ',', '(', ')'))
        if ja_has_latin and not en_looks_phrase:
            continue
        score = 0
        if en_has_latin:
            score += 2
        if not ja_has_latin:
            score += 4
        if en_looks_phrase:
            score += 1
        score += min(match.start(), 9999)
        candidates.append((score, match.start(), en, ja))
    if not candidates:
        m = re.fullmatch(r'([^\u3040-\u30ff\u3400-\u9fff]+?)\s*[（(]\s*([\u3040-\u30ff\u3400-\u9fff].*?)\s*[）)]', raw)
        if m:
            en = m.group(1).strip()
            ja = m.group(2).strip()
            if en and ja:
                return en, ja, True
        return raw, raw, False
    _score, _position, en, ja = sorted(candidates, key=lambda row: (row[0], row[1]))[-1]
    return en, ja, True


def split_bilingual_inline(text: object) -> dict[str, object]:
    """Return one English/Japanese pair from an inline bilingual UI string.

    The add-on contains historical forms such as ``English / 日本語``,
    ``English/日本語`` and reverse-order variants. A slash is accepted only
    when it separates a real English side from a real Japanese side.
    """
    raw = str(text or '').strip()
    en, ja, found = _split_bilingual_inline_cached(raw)
    return {'en': en, 'ja': ja, 'found': found}

def _load_generated_pairs() -> dict[str, str]:
    data: dict[str, str] = {}
    try:
        from . import text_translation_generated as _generated
        raw = getattr(_generated, 'TRANSLATIONS_EN_JA', {})
        if isinstance(raw, dict):
            for key, value in raw.items():
                en = str(key or '').strip()
                ja = str(value or '').strip()
                if en and ja:
                    data[en] = ja
    except Exception:
        pass
    return data


def translation_map() -> dict[str, str]:
    global _TRANSLATION_CACHE
    if _TRANSLATION_CACHE is not None:
        return _TRANSLATION_CACHE
    data: dict[str, str] = {}
    data.update(_load_generated_pairs())
    data.update(_MANUAL_EN_JA)
    try:
        from .text_translation_curated import CURATED_EN_JA
        data.update(CURATED_EN_JA)
    except Exception:
        pass
    extras: dict[str, str] = {}
    for en, ja in data.items():
        if ' -> ' in en:
            extras.setdefault(en.replace(' -> ', ' → '), ja.replace(' -> ', ' → '))
        if ' → ' in en:
            extras.setdefault(en.replace(' → ', ' -> '), ja.replace(' → ', ' -> '))
    data.update(extras)
    _TRANSLATION_CACHE = data
    return data


def reverse_translation_map() -> dict[str, str]:
    global _REVERSE_TRANSLATION_CACHE
    if _REVERSE_TRANSLATION_CACHE is not None:
        return _REVERSE_TRANSLATION_CACHE
    rev: dict[str, str] = {}
    for en, ja in translation_map().items():
        if en and ja and ja not in rev:
            rev[ja] = en
    _REVERSE_TRANSLATION_CACHE = rev
    return rev


@lru_cache(maxsize=4096)
def _normalize_key(text: str) -> str:
    return ' '.join(str(text or '').replace('\u3000', ' ').split()).strip()


@lru_cache(maxsize=4096)
def _lookup_en_to_ja(text: str) -> str:
    raw = str(text or '').strip()
    if not raw:
        return raw
    data = translation_map()
    for key in (raw, _normalize_key(raw), raw.rstrip(' .。'), raw.rstrip(' .。') + '.', raw.rstrip(' .。') + '。'):
        if key in data:
            return data[key]
    return ''


@lru_cache(maxsize=4096)
def _lookup_ja_to_en(text: str) -> str:
    raw = str(text or '').strip()
    if not raw:
        return raw
    data = reverse_translation_map()
    keys = (raw, _normalize_key(raw), raw.rstrip(' .。'), raw.rstrip(' .。') + '.', raw.rstrip(' .。') + '。')
    for key in keys:
        if key in data:
            return data[key]
    # 逆引き表に無い日本語の文は、en_US に登録している日本語→英語の辞書（JA_EN）でも引く。
    # Blender が自分で描く文（A の道）と、アドオンが組む文（B の道）で英訳を揃えるため。
    try:
        from .locale_fallback_data import JA_EN as _fallback_ja_en
    except Exception:
        _fallback_ja_en = {}
    for key in keys:
        value = _fallback_ja_en.get(key) if isinstance(_fallback_ja_en, dict) else None
        if value:
            return value
    return ''


@lru_cache(maxsize=4096)
def _translate_english_words_to_ja(text: str) -> str:
    out = str(text or '')
    for en, ja in _PHRASE_EN_JA:
        out = re.sub(r'(?<![A-Za-z0-9_])' + re.escape(en) + r'(?![A-Za-z0-9_])', ja, out)
    def repl(match: re.Match) -> str:
        word = match.group(0)
        if word in _MANUAL_EN_JA:
            return _MANUAL_EN_JA[word]
        title = word[:1].upper() + word[1:].lower() if word else word
        if title in _MANUAL_EN_JA:
            return _MANUAL_EN_JA[title]
        upper = word.upper()
        if upper in _MANUAL_EN_JA:
            return _MANUAL_EN_JA[upper]
        if '_' in word or '.' in word or word.isupper():
            return word
        return word
    out = _WORD_RE.sub(repl, out)
    return re.sub(r'\s+', ' ', out).strip()


@lru_cache(maxsize=4096)
def _looks_like_short_label(text: str) -> bool:
    raw = str(text or '').strip()
    if not raw or '\n' in raw:
        return False
    if any(mark in raw for mark in ('.', '。', '!', '?')):
        return False
    return len(raw) <= 80


@lru_cache(maxsize=4096)
def _label_en_to_ja(text: str) -> str:
    raw = str(text or '').strip()
    if not raw:
        return raw
    found = _lookup_en_to_ja(raw)
    if found:
        return found
    for prefix, template in _LABEL_VERB_TEMPLATES:
        if raw.startswith(prefix) and len(raw) > len(prefix):
            rest_ja = _lookup_en_to_ja(raw[len(prefix):].strip())
            if rest_ja:
                return template.format(rest=rest_ja)
    return raw


@lru_cache(maxsize=4096)
def _heuristic_en_to_ja(text: str) -> str:
    raw = str(text or '').strip()
    if not raw or contains_japanese(raw):
        return raw
    if _looks_like_short_label(raw):
        return _label_en_to_ja(raw)
    for prefix, template in _VERB_TEMPLATES:
        if raw.startswith(prefix) and len(raw) > len(prefix):
            rest_ja = _lookup_en_to_ja(raw[len(prefix):].strip())
            if rest_ja:
                return template.format(rest=rest_ja)
    return raw


@lru_cache(maxsize=4096)
def _heuristic_ja_to_en(text: str) -> str:
    raw = str(text or '').strip()
    if not raw:
        return raw
    return _lookup_ja_to_en(raw) or raw


@lru_cache(maxsize=4096)
def _translate_text_for_language(raw: str, language_key: str) -> str:
    en, ja, found_inline = _split_bilingual_inline_cached(raw)
    if found_inline:
        return ja if language_key == 'JA' else en
    if language_key == 'JA':
        found = _lookup_en_to_ja(raw)
        if found:
            return found
        return raw if contains_japanese(raw) else _heuristic_en_to_ja(raw)
    if contains_japanese(raw):
        found = _lookup_ja_to_en(raw)
        if found:
            return found
        return _heuristic_ja_to_en(raw)
    return raw


def translate_text(value: Any, context=None) -> Any:
    if not isinstance(value, str):
        return value
    raw = value.strip()
    if not raw:
        return value
    return _translate_text_for_language(raw, _language_key(context))

def inline(text: object, context=None) -> str:
    return str(translate_text(str(text or ''), context=context))


def sanitize_text(value: Any, context=None):
    return translate_text(value, context=context)


def _sanitize_text_for_language(value: Any, language_key: str):
    """Internal sanitize_text variant for a language already resolved once."""
    if not isinstance(value, str):
        return value
    raw = value.strip()
    if not raw:
        return value
    return _translate_text_for_language(raw, str(language_key or 'EN'))


@lru_cache(maxsize=4096)
def _hay_matches_tooltip_key(hay: str, key: str) -> bool:
    token = str(key or '').lower().strip()
    if not token:
        return False
    if ' ' in token:
        return token in hay
    return re.search(r'(?<![a-z0-9])' + re.escape(token) + r'(?![a-z0-9])', hay) is not None


@lru_cache(maxsize=4096)
def _generic_tooltip_ja(label: str, hint: str = '') -> str:
    label_ja = _lookup_en_to_ja(label)
    if not label_ja or not contains_japanese(label_ja):
        return ''
    hay = f'{label} {hint}'.lower()
    for keys, what, how, when in _TOOLTIP_RULES:
        if any(_hay_matches_tooltip_key(hay, key) for key in keys):
            return f'{label_ja}。{what} {how} {when}'
    return ''


@lru_cache(maxsize=4096)
def _localized_description_for_language(raw: str, label_text: str, language_key: str, property_text: bool) -> str:
    en, ja, found_inline = _split_bilingual_inline_cached(raw)
    japanese = language_key == 'JA'
    if property_text:
        if found_inline:
            return ja if japanese else en
        if japanese:
            if contains_japanese(raw):
                return raw
            translated = _lookup_en_to_ja(raw)
            if translated:
                return translated
            return ''
        if contains_japanese(raw):
            return _lookup_ja_to_en(raw)
        return raw if raw != label_text else ''
    if found_inline:
        return ja if japanese else en
    if not japanese:
        if contains_japanese(raw):
            found = _lookup_ja_to_en(raw)
            return found or _heuristic_ja_to_en(raw)
        return raw
    found = _lookup_en_to_ja(raw)
    if found:
        return found
    if contains_japanese(raw):
        return raw
    return _generic_tooltip_ja(label_text, raw)


def localized_description_text(description: str, label: str = '', context=None, *, property_text: bool = False) -> str:
    raw = str(description or '').strip()
    if not raw:
        return ''
    label_text = str(label or '').strip() or raw.split('.', 1)[0].strip()
    return _localized_description_for_language(raw, label_text, _language_key(context), bool(property_text))


def _localized_description_text_for_language(
    description: str,
    label: str,
    language_key: str,
    *,
    property_text: bool = False,
) -> str:
    """Internal localized_description_text variant with a pre-resolved language."""
    raw = str(description or '').strip()
    if not raw:
        return ''
    label_text = str(label or '').strip() or raw.split('.', 1)[0].strip()
    return _localized_description_for_language(
        raw,
        label_text,
        str(language_key or 'EN'),
        bool(property_text),
    )


@lru_cache(maxsize=4096)
def _sanitize_enum_items_sequence_for_language(source_items: tuple, language_key: str):
    """Sanitize one immutable enum definition once per active language."""
    changed = False
    normalized = []
    for item in source_items:
        if not isinstance(item, (list, tuple)):
            normalized.append(item)
            continue
        row = list(item)
        try:
            if len(row) >= 2 and isinstance(row[1], str):
                new_name = _sanitize_text_for_language(row[1], language_key)
                changed = changed or (new_name != row[1])
                row[1] = new_name
            if len(row) >= 3 and isinstance(row[2], str):
                label_source = row[1] if len(row) >= 2 and isinstance(row[1], str) else ''
                new_desc = _localized_description_text_for_language(
                    row[2],
                    label_source,
                    language_key,
                )
                changed = changed or (new_desc != row[2])
                row[2] = new_desc
        except RecursionError:
            row = list(item)
        except Exception:
            row = list(item)
        normalized.append(tuple(row))
    return tuple(normalized), bool(changed)

def _sanitize_enum_items_sequence(items: Iterable[Any], context=None):
    try:
        source_items = tuple(tuple(item) if isinstance(item, list) else item for item in tuple(items or ()))
    except Exception:
        source_items = tuple()
    language_key = _language_key(context)
    try:
        hash(source_items)
    except Exception:
        # Rare dynamic definitions can contain unhashable custom values. Preserve
        # the exact prior behavior for those definitions instead of caching them.
        changed = False
        normalized = []
        for item in source_items:
            if not isinstance(item, (list, tuple)):
                normalized.append(item)
                continue
            row = list(item)
            try:
                if len(row) >= 2 and isinstance(row[1], str):
                    new_name = _sanitize_text_for_language(row[1], language_key)
                    changed = changed or (new_name != row[1])
                    row[1] = new_name
                if len(row) >= 3 and isinstance(row[2], str):
                    label_source = row[1] if len(row) >= 2 and isinstance(row[1], str) else ''
                    new_desc = _localized_description_text_for_language(row[2], label_source, language_key)
                    changed = changed or (new_desc != row[2])
                    row[2] = new_desc
            except RecursionError:
                row = list(item)
            except Exception:
                row = list(item)
            normalized.append(tuple(row))
        return tuple(normalized), bool(changed)
    return _sanitize_enum_items_sequence_for_language(source_items, language_key)


def _call_enum_items_source(items_callable, self, context):
    # Blender validates dynamic EnumProperty item callbacks by positional
    # argument count before registration. The callback exposed to Blender must
    # be declared exactly as (self, context); a *args/**kwargs wrapper is
    # interpreted by Blender 5.1 as a zero-argument callback and registration
    # fails before the UV Suite N-panel can appear.
    attempts = (
        ((self, context), {}),
        ((self,), {}),
        ((), {'context': context}),
        ((), {}),
    )
    last_error = None
    for call_args, call_kwargs in attempts:
        try:
            return items_callable(*call_args, **call_kwargs)
        except TypeError as exc:
            last_error = exc
            continue
    if last_error is not None:
        raise last_error
    return items_callable(self, context)


def _wrap_enum_items_callable(items_callable):
    if not callable(items_callable) or getattr(items_callable, '_smart_uv_locale_wrapped', False):
        return items_callable

    def _wrapped(self, context):
        global _ENUM_ITEMS_CALLBACK_DEPTH
        cache_key = id(items_callable)
        try:
            result = _call_enum_items_source(items_callable, self, context)
        except RecursionError:
            return _ENUM_ITEMS_FALLBACK_CACHE.get(cache_key, tuple())
        if not isinstance(result, (list, tuple)):
            return result
        result_tuple = tuple(result)
        try:
            _ENUM_ITEMS_FALLBACK_CACHE[cache_key] = result_tuple
        except Exception:
            pass
        if _ENUM_ITEMS_CALLBACK_DEPTH > 0:
            return result_tuple
        try:
            _ENUM_ITEMS_CALLBACK_DEPTH += 1
            sanitized, _changed = _sanitize_enum_items_sequence(result_tuple, context=context)
            try:
                _ENUM_ITEMS_FALLBACK_CACHE[cache_key] = tuple(sanitized)
            except Exception:
                pass
            return sanitized
        except RecursionError:
            return _ENUM_ITEMS_FALLBACK_CACHE.get(cache_key, result_tuple)
        finally:
            try:
                _ENUM_ITEMS_CALLBACK_DEPTH = max(0, _ENUM_ITEMS_CALLBACK_DEPTH - 1)
            except Exception:
                _ENUM_ITEMS_CALLBACK_DEPTH = 0

    try:
        _wrapped.__name__ = getattr(items_callable, '__name__', 'wrapped_enum_items')
    except Exception:
        pass
    try:
        _wrapped.__doc__ = getattr(items_callable, '__doc__', None)
    except Exception:
        pass
    try:
        _wrapped._smart_uv_locale_wrapped = True
        _wrapped._smart_uv_locale_original_items = items_callable
    except Exception:
        pass
    return _wrapped

def _make_static_enum_items_callback(items: Iterable[Any]):
    source = tuple(tuple(item) if isinstance(item, list) else item for item in tuple(items or ()))
    cache: dict[str, tuple] = {}

    def _items(_self, context):
        # Exact two-argument callback signature required by Blender 5.x.
        key = _language_key(context)
        if key not in cache:
            sanitized, _changed = _sanitize_enum_items_sequence(source, context=context)
            cache[key] = tuple(sanitized)
        return cache[key]

    try:
        _items.__name__ = 'uv_suite_localized_enum_items'
    except Exception:
        pass
    try:
        _items._smart_uv_locale_wrapped = True
        _items._smart_uv_locale_static_items = source
    except Exception:
        pass
    return _items


_CACHE_MISSING = ('__SMART_UV_CACHE_MISSING__',)


def _freeze_localization_value(value):
    """Return a hashable immutable copy for static RNA localization data.

    Callable enum providers intentionally return ``None`` and stay on the dynamic
    path because wrapping one provider is class-specific and must not be shared by
    unrelated RNA properties.
    """
    if callable(value):
        return None
    if isinstance(value, dict):
        rows = []
        for key, item in sorted(value.items(), key=lambda pair: str(pair[0])):
            frozen = _freeze_localization_value(item)
            if frozen is None and item is not None:
                return None
            rows.append((str(key), frozen))
        return ('dict', tuple(rows))
    if isinstance(value, (list, tuple)):
        rows = []
        for item in value:
            frozen = _freeze_localization_value(item)
            if frozen is None and item is not None:
                return None
            rows.append(frozen)
        return ('seq', tuple(rows))
    try:
        hash(value)
    except Exception:
        return None
    return ('atom', value)


def _thaw_localization_value(value):
    if value is _CACHE_MISSING or value == _CACHE_MISSING:
        return _CACHE_MISSING
    if not isinstance(value, tuple) or not value:
        return value
    kind = value[0]
    if kind == 'atom':
        return value[1]
    if kind == 'seq':
        return tuple(_thaw_localization_value(item) for item in value[1])
    if kind == 'dict':
        return {key: _thaw_localization_value(item) for key, item in value[1]}
    return value


def _catalog_tuple(value):
    if isinstance(value, list):
        return tuple(_catalog_tuple(item) for item in value)
    if isinstance(value, dict):
        return {str(key): _catalog_tuple(item) for key, item in value.items()}
    return value


def _static_property_catalog() -> dict[str, tuple]:
    """Load the generated immutable localization catalog once.

    The compressed catalog contains only results generated from this source
    version.  Missing, damaged, or future property definitions automatically use
    the normal localization code below, so it is an optimization rather than a
    functional dependency.
    """
    global _STATIC_PROPERTY_CATALOG, _STATIC_PROPERTY_CATALOG_FAILED
    if _STATIC_PROPERTY_CATALOG is not None:
        return _STATIC_PROPERTY_CATALOG
    if _STATIC_PROPERTY_CATALOG_FAILED:
        return {}
    try:
        path = os.path.join(os.path.dirname(__file__), 'text_translation_property_catalog.pickle.zlib')
        with open(path, 'rb') as handle:
            # The file is generated and shipped with this Extension, just like a
            # compiled Python constant table. Pickle preserves nested tuples and
            # avoids rebuilding tens of thousands of enum rows at every startup.
            payload = pickle.loads(zlib.decompress(handle.read()))
        raw_entries = payload.get('entries') if isinstance(payload, dict) else None
        if not isinstance(raw_entries, dict):
            raise ValueError('Smart UV property catalog has no entries mapping')
        _STATIC_PROPERTY_CATALOG = {str(key): value for key, value in raw_entries.items()}
    except Exception:
        _STATIC_PROPERTY_CATALOG_FAILED = True
        _STATIC_PROPERTY_CATALOG = {}
    return _STATIC_PROPERTY_CATALOG


def _static_property_catalog_key(
    language_key: str,
    prop_name: str,
    frozen_name,
    frozen_description,
    frozen_items,
) -> str:
    source_key = repr((str(prop_name or ''), frozen_name, frozen_description, frozen_items))
    digest = hashlib.sha256(source_key.encode('utf-8')).hexdigest()
    return f'{str(language_key or "EN")}:{digest}'


@lru_cache(maxsize=4096)
def _localized_static_property_overlay(
    language_key: str,
    prop_name: str,
    frozen_name,
    frozen_description,
    frozen_items,
) -> tuple:
    """Build the localized mutable-field overlay for repeated static properties."""
    try:
        generated = _static_property_catalog().get(
            _static_property_catalog_key(
                language_key,
                prop_name,
                frozen_name,
                frozen_description,
                frozen_items,
            )
        )
        if isinstance(generated, tuple):
            return generated
    except Exception:
        pass
    name = _thaw_localization_value(frozen_name)
    description = _thaw_localization_value(frozen_description)
    items = _thaw_localization_value(frozen_items)
    source_name = name if name is not _CACHE_MISSING else str(prop_name or '')
    overlay: list[tuple[str, object]] = []
    if name is not _CACHE_MISSING and isinstance(name, str):
        overlay.append(('name', _sanitize_text_for_language(name, language_key)))
    desc_source = description if isinstance(description, str) else ''
    if desc_source.strip():
        overlay.append((
            'description',
            _localized_description_text_for_language(
                desc_source,
                str(source_name or prop_name or ''),
                language_key,
                property_text=True,
            ),
        ))
    elif str(prop_name or source_name or '').strip():
        label = str(source_name or prop_name or '')
        overlay.append((
            'description',
            _localized_description_text_for_language(
                label,
                label,
                language_key,
                property_text=True,
            ),
        ))
    if items is not _CACHE_MISSING:
        sanitized, _changed = _sanitize_enum_items_sequence_for_language(tuple(items or ()), language_key)
        overlay.append(('items', sanitized))
    return tuple(overlay)


def _localized_property_keywords(
    keywords: dict,
    context=None,
    *,
    prop_name: str = '',
    original_source: dict | None = None,
    language_key: str | None = None,
) -> dict:
    original_source = dict(original_source or {})
    source = {key: original_source.get(key, keywords.get(key)) for key in ('name', 'description', 'items') if key in keywords or key in original_source}
    result = dict(keywords)
    language_key = str(language_key or _language_key(context))

    # Most Smart UV tools reuse the same standard properties (Scope, Texture
    # Size, action, mode, and common enum lists).  Localize those immutable
    # definitions once by content while keeping a fresh result dict per RNA
    # property so Blender-specific callbacks/defaults are never shared.
    if not callable(source.get('items')):
        frozen_name = _freeze_localization_value(source['name']) if 'name' in source else _CACHE_MISSING
        frozen_description = _freeze_localization_value(source['description']) if 'description' in source else _CACHE_MISSING
        frozen_items = _freeze_localization_value(source['items']) if 'items' in source else _CACHE_MISSING
        if frozen_name is not None and frozen_description is not None and frozen_items is not None:
            try:
                overlay = _localized_static_property_overlay(
                    language_key,
                    str(prop_name or ''),
                    frozen_name,
                    frozen_description,
                    frozen_items,
                )
                for key, value in overlay:
                    result[key] = value
                return result
            except Exception:
                pass

    source_name = source.get('name', result.get('name', prop_name))
    if isinstance(source.get('name'), str):
        result['name'] = _sanitize_text_for_language(source.get('name'), language_key)
    desc_source = source.get('description') if isinstance(source.get('description'), str) else ''
    if isinstance(desc_source, str) and desc_source.strip():
        result['description'] = _localized_description_text_for_language(
            str(desc_source or ''),
            str(source_name or prop_name or ''),
            language_key,
            property_text=True,
        )
    elif str(prop_name or source_name or '').strip():
        result['description'] = _localized_description_text_for_language(
            str(source_name or prop_name or ''),
            str(source_name or prop_name or ''),
            language_key,
            property_text=True,
        )
    if 'items' in source or 'items' in result:
        items = source.get('items', result.get('items'))
        if callable(items):
            if str(prop_name or '') == 'ui_language_mode':
                result['items'] = items
                result.setdefault('default', 'AUTO')
            else:
                result['items'] = _wrap_enum_items_callable(items)
                # Blender cannot register EnumProperty defaults when the item list
                # is provided by a dynamic callback.  Leaving a string default here
                # aborts add-on registration before the UV Suite N-panel can appear.
                if isinstance(result.get('default'), str):
                    result.pop('default', None)
        elif isinstance(items, (list, tuple)):
            # Keep static enum lists static.  Earlier builds converted every
            # static list into a callback to make enum item labels refresh on
            # language changes, but that also turned valid ``default='VALUE'``
            # declarations into invalid dynamic-enum defaults.  Static enums are
            # sanitized at registration time and retain their original defaults.
            sanitized, _changed = _sanitize_enum_items_sequence_for_language(
                tuple(tuple(item) if isinstance(item, list) else item for item in tuple(items or ())),
                language_key,
            )
            result['items'] = sanitized
    return result




def _wrap_update_callback_for_blender51(callback):
    """Return a Blender 5.x compatible two-argument update callback."""
    if not callable(callback):
        return callback
    if getattr(callback, '_smart_uv_update_wrapper_2args', False):
        return callback
    original = callback

    def _smart_uv_update_wrapper(self, context):
        for args in ((self, context), (self,), tuple()):
            try:
                return original(*args)
            except TypeError:
                continue
            except Exception:
                return None
        return None

    try:
        _smart_uv_update_wrapper.__name__ = getattr(original, '__name__', 'smart_uv_update_wrapper')
    except Exception:
        pass
    try:
        _smart_uv_update_wrapper._smart_uv_update_wrapper_2args = True
        _smart_uv_update_wrapper._smart_uv_update_original = original
    except Exception:
        pass
    return _smart_uv_update_wrapper


def _sanitize_update_keyword_for_blender51(value) -> None:
    try:
        keywords = getattr(value, 'keywords', None)
    except Exception:
        keywords = None
    if not isinstance(keywords, dict):
        return
    callback = keywords.get('update')
    wrapped = _wrap_update_callback_for_blender51(callback)
    if wrapped is callback:
        return
    try:
        keywords['update'] = wrapped
    except Exception:
        pass


def _materialize_property_annotation(cls: type, prop_name: str, value, context=None):
    """Evaluate postponed bpy.props annotations created by future annotations.

    Blender's RNA registration expects annotation values to be property-deferred
    objects, not strings.  Python's ``from __future__ import annotations`` stores
    ``name: bpy.props.XProperty(...)`` as text, which otherwise registers an
    operator without its RNA properties and then produces OperatorProperties
    warnings when UI code assigns ``mode`` or ``action``.
    """
    if not isinstance(value, str):
        return value
    expr = value.strip()
    if 'Property' not in expr or '(' not in expr:
        return value
    module = sys.modules.get(str(getattr(cls, '__module__', '') or ''))
    namespace = {}
    if module is not None:
        try:
            namespace.update(getattr(module, '__dict__', {}) or {})
        except Exception:
            pass
    namespace.setdefault('bpy', bpy)

    def _smart_uv_safe_prop_constructor(constructor):
        def _wrapper(*args, **kwargs):
            local_kwargs = dict(kwargs or {})
            if 'update' in local_kwargs:
                local_kwargs['update'] = _wrap_update_callback_for_blender51(local_kwargs.get('update'))
            return constructor(*args, **local_kwargs)
        return _wrapper

    try:
        _safe_props = {
            'BoolProperty': _smart_uv_safe_prop_constructor(bpy.props.BoolProperty),
            'BoolVectorProperty': _smart_uv_safe_prop_constructor(bpy.props.BoolVectorProperty),
            'CollectionProperty': _smart_uv_safe_prop_constructor(bpy.props.CollectionProperty),
            'EnumProperty': _smart_uv_safe_prop_constructor(bpy.props.EnumProperty),
            'FloatProperty': _smart_uv_safe_prop_constructor(bpy.props.FloatProperty),
            'FloatVectorProperty': _smart_uv_safe_prop_constructor(bpy.props.FloatVectorProperty),
            'IntProperty': _smart_uv_safe_prop_constructor(bpy.props.IntProperty),
            'IntVectorProperty': _smart_uv_safe_prop_constructor(bpy.props.IntVectorProperty),
            'PointerProperty': _smart_uv_safe_prop_constructor(bpy.props.PointerProperty),
            'StringProperty': _smart_uv_safe_prop_constructor(bpy.props.StringProperty),
        }
        # Always override imported bpy.props constructor aliases while evaluating
        # postponed annotations.  Some integrated modules use
        # ``from bpy.props import BoolProperty``; keeping that original callable
        # bypasses the update-callback wrapper and Blender 5.1 rejects 0/1/3-arg
        # callbacks during RNA registration.
        namespace.update(_safe_props)
    except Exception:
        pass
    try:
        namespace.update({k: v for k, v in getattr(cls, '__dict__', {}).items() if not k.startswith('__')})
    except Exception:
        pass
    eval_expr = expr.replace('bpy.props.', '')
    try:
        evaluated = eval(eval_expr, namespace, namespace)
    except Exception:
        return value
    try:
        annotations = dict(getattr(cls, '__annotations__', {}) or {})
        annotations[str(prop_name)] = evaluated
        setattr(cls, '__annotations__', annotations)
    except Exception:
        pass
    return evaluated


def _annotation_identity_signature(cls: type) -> tuple:
    try:
        annotations = dict(getattr(cls, '__annotations__', {}) or {})
    except Exception:
        return ()
    try:
        return tuple(sorted((str(name), id(value)) for name, value in annotations.items()))
    except Exception:
        return ()


def _deferred_keyword_signature(keywords: dict) -> tuple:
    try:
        return (
            keywords.get('name'),
            keywords.get('description'),
            id(keywords.get('items')),
            id(keywords.get('update')),
            tuple(sorted(str(key) for key in keywords.keys())),
        )
    except Exception:
        return ()


def materialize_class_property_annotations(cls: type, context=None) -> type:
    if not isinstance(cls, type):
        return cls
    before_signature = _annotation_identity_signature(cls)
    cached = _CLASS_MATERIALIZE_CACHE.get(id(cls))
    if cached is not None and cached[0] is cls and cached[1] == before_signature:
        return cls
    try:
        annotations = dict(getattr(cls, '__annotations__', {}) or {})
    except Exception:
        return cls
    changed = False
    for prop_name, value in list(annotations.items()):
        materialized = _materialize_property_annotation(cls, str(prop_name), value, context=context)
        if materialized is not value:
            annotations[str(prop_name)] = materialized
            changed = True
        try:
            _sanitize_update_keyword_for_blender51(materialized)
        except Exception:
            pass
    if changed:
        try:
            setattr(cls, '__annotations__', annotations)
        except Exception:
            pass
    try:
        _CLASS_MATERIALIZE_CACHE[id(cls)] = (cls, _annotation_identity_signature(cls))
    except Exception:
        pass
    return cls

def sanitize_deferred_property(
    value,
    context=None,
    source_store: dict | None = None,
    prop_name: str = '',
    original_source: dict | None = None,
    *,
    language_key: str | None = None,
) -> None:
    keywords = getattr(value, 'keywords', None)
    if not isinstance(keywords, dict):
        return
    try:
        mode = str(language_key or _language_key(context))
    except Exception:
        mode = ''
    current_signature = _deferred_keyword_signature(keywords)
    cached = _DEFERRED_SANITIZE_CACHE.get(id(value))
    if (cached is not None and cached[0] is value and cached[1] == mode
            and cached[2] == str(prop_name or '') and cached[3] == current_signature):
        if source_store is not None and prop_name and original_source is not None:
            source_store[str(prop_name)] = dict(original_source)
        return
    try:
        _sanitize_update_keyword_for_blender51(value)
    except Exception:
        pass
    if original_source is None:
        try:
            original_source = _PROP_CONSTRUCTOR_SOURCE_BY_ID.get(id(value))
        except Exception:
            original_source = None
    original = dict(original_source or {key: keywords.get(key) for key in ('name', 'description', 'items') if key in keywords})
    if source_store is not None and prop_name:
        source_store[prop_name] = original
    localized = _localized_property_keywords(
        keywords,
        context=context,
        prop_name=prop_name,
        original_source=original,
        language_key=mode,
    )
    keywords.clear()
    keywords.update(localized)
    try:
        _DEFERRED_SANITIZE_CACHE[id(value)] = (
            value, mode, str(prop_name or ''), _deferred_keyword_signature(keywords)
        )
    except Exception:
        pass


def _class_text_source(cls: type, attr_name: str) -> str:
    store = getattr(cls, '_smart_uv_locale_class_text', None)
    if isinstance(store, dict) and attr_name in store:
        return str(store.get(attr_name) or '')
    return str(getattr(cls, attr_name, '') or '')


_SMART_UV_ENUM_TOOLTIP_PROPS = (
    'action', 'mode', 'preset', 'profile', 'target', 'target_mode',
    'apply_mode', 'execution_mode', 'scope', 'axis', 'direction', 'issue',
    'prep_mode', 'source_mode', 'library_kind', 'merge_mode', 'tile_mode',
    'group_mode', 'sort_mode', 'layout_mode', 'pack_mode', 'snap_mode',
)


def _enum_item_from_rna(cls: type, prop_name: str, ident: str):
    try:
        rna = getattr(cls, 'bl_rna', None)
        props = getattr(rna, 'properties', None)
        prop = props.get(prop_name) if props is not None else None
        enum_items = getattr(prop, 'enum_items', None) if prop is not None else None
        if enum_items is None:
            return None
        try:
            item = enum_items.get(ident)
            if item is not None:
                return item
        except Exception:
            pass
        for item in enum_items:
            try:
                if str(getattr(item, 'identifier', '') or '') == str(ident or ''):
                    return item
            except Exception:
                continue
    except Exception:
        pass
    return None


def _enum_item_from_original_source(cls: type, prop_name: str, ident: str):
    try:
        store = getattr(cls, '_smart_uv_locale_prop_text', None)
        if not isinstance(store, dict):
            return None
        source = store.get(prop_name)
        if not isinstance(source, dict):
            return None
        items = source.get('items')
        if callable(items):
            return None
        for row in tuple(items or ()):  # static enum source rows
            if not isinstance(row, (list, tuple)) or len(row) < 2:
                continue
            if str(row[0] or '') != str(ident or ''):
                continue
            name = str(row[1] or ident)
            desc = str(row[2] or '') if len(row) >= 3 else ''
            return {'identifier': str(row[0] or ''), 'name': name, 'description': desc}
    except Exception:
        pass
    return None


def _enum_choice_detail(cls: type, properties, context=None) -> dict[str, str]:
    if properties is None:
        return {}
    for prop_name in _SMART_UV_ENUM_TOOLTIP_PROPS:
        try:
            value = getattr(properties, prop_name)
        except Exception:
            continue
        ident = str(value or '').strip()
        if not ident:
            continue
        item = _enum_item_from_rna(cls, prop_name, ident) or _enum_item_from_original_source(cls, prop_name, ident)
        name = ident.replace('_', ' ').title()
        desc = ''
        if item is not None:
            if isinstance(item, dict):
                try:
                    name = str(item.get('name') or name)
                    desc = str(item.get('description') or '')
                except Exception:
                    pass
            else:
                try:
                    name = str(getattr(item, 'name', '') or name)
                    desc = str(getattr(item, 'description', '') or '')
                except Exception:
                    pass
        label = sanitize_text(name, context=context)
        detail = localized_description_text(desc, label, context=context) if desc else ''
        return {'prop': prop_name, 'value': ident, 'name': str(label or name), 'description': str(detail or '')}
    return {}


def _operator_usage_suffix(label: str, detail: dict[str, str], context=None) -> str:
    prop = str(detail.get('prop') or '')
    value = str(detail.get('value') or '')
    if is_japanese(context):
        if prop and value:
            return f"このボタンは {prop}={value} として登録された個別処理だけを実行します。対象のメッシュ、UV選択、アクティブUVマップ、関連設定を確認してから押してください。実行後は選択状態、UV位置、レポート出力を確認し、必要ならUndoで戻せます。"
        return 'このボタンは表示名の処理を実行します。対象のメッシュ、UV選択、アクティブUVマップ、関連設定を確認してから押してください。実行後は選択状態、UV位置、レポート出力を確認し、必要ならUndoで戻せます。'
    if prop and value:
        return f"This button runs only the individual operation registered as {prop}={value}. Prepare the mesh, UV selection, active UV map, and related settings before pressing it. After execution, review selection state, UV positions, or generated reports; use Undo when needed."
    return 'This button runs the operation named on the UI. Prepare the mesh, UV selection, active UV map, and related settings before pressing it. After execution, review selection state, UV positions, or generated reports; use Undo when needed.'


def _call_original_operator_description(cls: type, context=None, properties=None) -> str:
    """Return a class-specific description that existed before locale wrapping.

    Several Smart UV Suite operators already provide action-aware descriptions.
    The locale wrapper keeps those descriptions and appends explicit per-button
    usage instead of replacing them with a generic operator-level explanation.
    """
    original = getattr(cls, '_smart_uv_locale_original_description', None)
    if original is None:
        return ''
    try:
        if isinstance(original, classmethod):
            result = original.__func__(cls, context, properties)
        elif isinstance(original, staticmethod):
            func = original.__func__
            try:
                result = func(context, properties)
            except TypeError:
                result = func(cls, context, properties)
        elif callable(original):
            attempts = (
                (cls, context, properties),
                (context, properties),
                (properties,),
                (),
            )
            result = ''
            for args in attempts:
                try:
                    result = original(*args)
                    break
                except TypeError:
                    continue
        else:
            result = ''
    except RecursionError:
        return ''
    except Exception:
        return ''
    text = str(result or '').strip()
    if not text:
        return ''
    # Avoid returning an already wrapped generic string from a prior locale pass.
    if text.startswith(('Function: Function:', '機能: 機能:', 'Function: 機能:', '機能: Function:')):
        return ''
    label_src = _class_text_source(cls, 'bl_label')
    return localized_description_text(text, label_src, context=context)


def _operator_dynamic_description_text(cls: type, original_desc: str, context=None, properties=None) -> str:
    label_src = _class_text_source(cls, 'bl_label')
    original_detail = _call_original_operator_description(cls, context=context, properties=properties)
    detail = _enum_choice_detail(cls, properties, context=context)
    japanese = is_japanese(context)
    fallback = _class_text_source(cls, 'bl_description') or original_desc or label_src
    if detail:
        choice = str(detail.get('name') or detail.get('value') or '').strip()
        body = str(detail.get('description') or original_detail or '').strip()
        body = body or localized_description_text(fallback, label_src, context=context)
        text = f'{choice}。{body}' if japanese else f'{choice}. {body}'
        text = text if body else choice
    else:
        src = original_detail or fallback
        text = str(localized_description_text(src, label_src, context=context))
    text = str(text).strip()
    if not japanese and contains_japanese(text):
        return ''
    return text


def _install_dynamic_operator_description(cls: type, original_desc: str) -> None:
    try:
        if not issubclass(cls, bpy.types.Operator):
            return
    except Exception:
        return
    existing = cls.__dict__.get('description') if hasattr(cls, '__dict__') else None
    try:
        existing_func = getattr(existing, '__func__', existing)
    except Exception:
        existing_func = existing
    is_ours = bool(getattr(existing, '_smart_uv_locale_dynamic', False) or getattr(existing_func, '_smart_uv_locale_dynamic', False))
    if is_ours and getattr(cls, '_smart_uv_locale_detailed_description', False):
        return
    try:
        if existing is not None and not is_ours:
            # Preserve action/mode-aware descriptions installed by other Smart UV
            # helpers, then wrap them with explicit Function/Usage wording.
            setattr(cls, '_smart_uv_locale_original_description', existing)
    except Exception:
        pass
    def _description(local_cls, context, properties):
        return str(_operator_dynamic_description_text(local_cls, original_desc, context=context, properties=properties))
    try:
        setattr(_description, '_smart_uv_locale_dynamic', True)
    except Exception:
        pass
    method = classmethod(_description)
    try:
        setattr(method, '_smart_uv_locale_dynamic', True)
    except Exception:
        pass
    try:
        setattr(cls, 'description', method)
        setattr(cls, '_smart_uv_locale_dynamic_description', True)
        setattr(cls, '_smart_uv_locale_detailed_description', True)
    except Exception:
        pass


def sanitize_class(cls: type, context=None) -> type:
    if not isinstance(cls, type):
        return cls
    try:
        mode = str(_language_key(context))
    except Exception:
        mode = ''
    try:
        current_signature = (
            str(getattr(cls, 'bl_label', '') or ''),
            str(getattr(cls, 'bl_description', '') or ''),
            _annotation_identity_signature(cls),
        )
    except Exception:
        current_signature = ()
    cached = _CLASS_SANITIZE_CACHE.get(id(cls))
    if cached is not None and cached[0] is cls and cached[1] == mode and cached[2] == current_signature:
        return cls
    originals = getattr(cls, '_smart_uv_locale_class_text', None)
    if not isinstance(originals, dict):
        originals = {}
        for attr_name in ('bl_label', 'bl_description', 'bl_category'):
            value = getattr(cls, attr_name, None)
            if isinstance(value, str):
                originals[attr_name] = value
        try:
            setattr(cls, '_smart_uv_locale_class_text', originals)
        except Exception:
            pass
    label_source = str(originals.get('bl_label', getattr(cls, 'bl_label', '') or '') or '')
    for attr_name in ('bl_label', 'bl_description'):
        value = originals.get(attr_name, getattr(cls, attr_name, None))
        if isinstance(value, str):
            try:
                if attr_name == 'bl_description':
                    setattr(
                        cls,
                        attr_name,
                        _localized_description_text_for_language(value, label_source, mode),
                    )
                else:
                    setattr(cls, attr_name, _sanitize_text_for_language(value, mode))
            except Exception:
                pass
    # Keep Blender sidebar/category identifiers stable. Rewriting bl_category at
    # tool_runtime can move panels to a different sidebar tab or make the expected
    # UV Suite tab disappear after a language refresh.
    value = originals.get('bl_category', getattr(cls, 'bl_category', None))
    if isinstance(value, str):
        try:
            setattr(cls, 'bl_category', value)
        except Exception:
            pass
    try:
        _install_dynamic_operator_description(cls, str(originals.get('bl_description', '') or ''))
    except Exception:
        pass
    try:
        materialize_class_property_annotations(cls, context=context)
    except Exception:
        pass
    annotations = dict(getattr(cls, '__annotations__', {}) or {})
    prop_sources: dict[str, dict] = {}
    existing_sources = getattr(cls, '_smart_uv_locale_prop_text', None)
    if not isinstance(existing_sources, dict):
        existing_sources = {}
    for prop_name, value in annotations.items():
        try:
            key = str(prop_name)
            sanitize_deferred_property(
                value,
                context=context,
                source_store=prop_sources,
                prop_name=key,
                original_source=existing_sources.get(key),
                language_key=mode,
            )
        except Exception:
            pass
    if prop_sources:
        try:
            merged = dict(existing_sources)
            for key, source in prop_sources.items():
                if key not in merged:
                    merged[key] = source
            setattr(cls, '_smart_uv_locale_prop_text', merged)
        except Exception:
            pass
    try:
        _LOCALIZED_CLASSES.add(cls)
    except Exception:
        pass
    try:
        final_signature = (
            str(getattr(cls, 'bl_label', '') or ''),
            str(getattr(cls, 'bl_description', '') or ''),
            _annotation_identity_signature(cls),
        )
        _CLASS_SANITIZE_CACHE[id(cls)] = (cls, mode, final_signature)
    except Exception:
        pass
    return cls


def _registered_class_for_operator(idname: str):
    target = str(idname or '').strip()
    if not target:
        return None
    for cls in () + tuple(_LOCALIZED_CLASSES):
        try:
            if isinstance(cls, type) and str(getattr(cls, 'bl_idname', '') or '') == target:
                return cls
        except Exception:
            continue
    return None


def _property_label_source(data: object, prop_name: str) -> str:
    name = str(prop_name or '')
    if not name:
        return ''
    try:
        store = getattr(type(data), '_smart_uv_locale_prop_text', None)
        if isinstance(store, dict):
            row = store.get(name)
            if isinstance(row, dict):
                value = row.get('name')
                if isinstance(value, str) and value.strip():
                    return value
    except Exception:
        pass
    try:
        rna = getattr(data, 'bl_rna', None)
        props = getattr(rna, 'properties', None)
        prop = props.get(name) if props is not None else None
        value = getattr(prop, 'name', '') if prop is not None else ''
        if value:
            return str(value)
    except Exception:
        pass
    return name.replace('_', ' ').title()


def _sanitize_layout_text_arg(method_name: str, args: tuple, kwargs: dict, context=None) -> tuple[tuple, dict]:
    if not _stack_has_this_addon_caller():
        return args, kwargs
    local_args = list(args)
    local_kwargs = dict(kwargs or {})

    def _set_pos(index: int) -> None:
        if len(local_args) > index and isinstance(local_args[index], str):
            local_args[index] = sanitize_text(local_args[index], context=context)

    for key in ('text', 'heading', 'placeholder'):
        if isinstance(local_kwargs.get(key), str):
            local_kwargs[key] = sanitize_text(local_kwargs.get(key), context=context)

    # Prevent Blender's global translation pass from re-translating text that
    # was already selected by this add-on's own language mode.
    if method_name in {
        'label', 'operator', 'menu', 'popover', 'prop', 'prop_enum',
        'prop_menu_enum', 'operator_menu_enum', 'prop_search',
    }:
        local_kwargs.setdefault('translate', False)

    if method_name == 'label':
        _set_pos(0)
    elif method_name in {'operator', 'menu', 'popover'}:
        _set_pos(1)
    elif method_name == 'prop':
        _set_pos(2)
        if 'text' not in local_kwargs and len(local_args) >= 2:
            label = _property_label_source(local_args[0], str(local_args[1]))
            if label:
                local_kwargs['text'] = sanitize_text(label, context=context)
    elif method_name == 'prop_enum':
        _set_pos(3)
    elif method_name in {'prop_menu_enum', 'operator_menu_enum'}:
        _set_pos(2)
    elif method_name == 'prop_search':
        _set_pos(4)

    if method_name == 'operator' and 'text' not in local_kwargs and len(local_args) >= 1:
        cls = _registered_class_for_operator(str(local_args[0]))
        label = _class_text_source(cls, 'bl_label') if cls is not None else ''
        if label:
            local_kwargs['text'] = sanitize_text(label, context=context)
    return tuple(local_args), local_kwargs



def install_ui_layout_text_sanitizer() -> None:
    return None



def uninstall_ui_layout_text_sanitizer() -> None:
    _ORIGINAL_LAYOUT_METHODS.clear()
    return None


def _source_from_property_keywords(kwargs: dict) -> dict:
    return {key: kwargs.get(key) for key in ('name', 'description', 'items') if key in kwargs}


def _sanitize_property_constructor_call(prop_name: str, args: tuple, kwargs: dict, context=None) -> tuple[tuple, dict, dict | None]:
    if not _stack_has_this_addon_caller():
        return args, kwargs, None
    local_kwargs = dict(kwargs or {})
    original_source = _source_from_property_keywords(local_kwargs)
    try:
        local_kwargs = _localized_property_keywords(local_kwargs, context=context, prop_name=prop_name, original_source=original_source)
    except Exception:
        pass
    return args, local_kwargs, original_source


def _unwrap_prior_smart_uv_prop_wrapper(fn):
    'Return the real bpy.props constructor behind an older UV Suite wrapper.\n\n    A failed registration from an earlier build can leave bpy.props.EnumProperty\n    patched in the current Blender session.  Wrapping that stale wrapper again\n    would preserve the old dynamic-enum/default bug, so unwrap by inspecting the\n    closure where the original constructor was stored.\n    '
    current = fn
    seen: set[int] = set()
    while callable(current) and getattr(current, '_smart_uv_locale_prop_wrapper', False):
        ident = id(current)
        if ident in seen:
            break
        seen.add(ident)
        replacement = None
        try:
            stored = getattr(current, '_smart_uv_locale_original_constructor', None)
            if callable(stored) and stored is not current:
                replacement = stored
        except Exception:
            replacement = None
        if replacement is None:
            try:
                closure = getattr(current, '__closure__', None) or ()
                for cell in closure:
                    try:
                        value = cell.cell_contents
                    except Exception:
                        continue
                    if callable(value) and value is not current:
                        replacement = value
                        break
            except Exception:
                replacement = None
        if replacement is None:
            break
        current = replacement
    return current



def install_props_constructor_sanitizer() -> None:
    return None



def uninstall_props_constructor_sanitizer() -> None:
    _ORIGINAL_PROP_CONSTRUCTORS.clear()
    return None



def install_operator_report_sanitizer() -> None:
    return None



def uninstall_operator_report_sanitizer() -> None:
    global _ORIGINAL_OPERATOR_REPORT
    _ORIGINAL_OPERATOR_REPORT = None
    return None


def _translation_entry_is_safe(en: str) -> bool:
    raw = str(en or '').strip()
    if not raw:
        return False
    low = raw.lower()
    uv_tokens = (
        'uv', 'udim', 'texel', 'island', 'seam', 'unwrap', 'pack', 'checker',
        'atlas', 'trim', 'hotspot', 'smart uv', 'smart tools', 'density',
        'overlap', 'flipped', 'shell', 'symmetry', 'lightmap', 'trimsheet',
    )
    if any(token in low for token in uv_tokens):
        return True
    # Avoid registering generic global UI words such as Add, Remove, Open,
    # because Blender applies registered translations process-wide.  The
    # tool_runtime wrappers handle those words inside UV Suite only.
    return len(raw) >= 28 and (' ' in raw or '.' in raw or ':' in raw)


def register_addon_translations() -> None:
    global _TRANSLATIONS_REGISTERED
    translations = getattr(getattr(bpy, 'app', None), 'translations', None)
    if translations is None:
        return
    try:
        translations.unregister(__name__)
    except Exception:
        pass
    data = {'ja_JP': {}}
    for en, ja in translation_map().items():
        if not en or not ja or en == ja:
            continue
        if not _translation_entry_is_safe(en):
            continue
        for ctx in ('*', 'Operator', 'Menu', 'Panel', 'Property'):
            data['ja_JP'][(ctx, en)] = ja
    try:
        translations.register(__name__, data)
        _TRANSLATIONS_REGISTERED = True
    except Exception:
        _TRANSLATIONS_REGISTERED = False


def unregister_addon_translations() -> None:
    global _TRANSLATIONS_REGISTERED
    translations = getattr(getattr(bpy, 'app', None), 'translations', None)
    if translations is None:
        return
    try:
        translations.unregister(__name__)
    except Exception:
        pass
    _TRANSLATIONS_REGISTERED = False


def relocalize_registered_classes(context=None) -> int:
    total = 0
    values: list[type] = []
    try:
        values.extend(cls for cls in () if isinstance(cls, type))
    except Exception:
        pass
    try:
        values.extend(cls for cls in tuple(_LOCALIZED_CLASSES) if isinstance(cls, type))
    except Exception:
        pass
    seen: set[type] = set()
    for cls in values:
        if cls in seen:
            continue
        seen.add(cls)
        if not hasattr(cls, '_smart_uv_locale_class_text'):
            continue
        try:
            sanitize_class(cls, context=context)
            total += 1
        except Exception:
            pass
    return total


def tag_redraw_all() -> None:
    wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    if wm is None:
        return
    for window in getattr(wm, 'windows', ()) or ():
        screen = getattr(window, 'screen', None)
        if screen is None:
            continue
        for area in getattr(screen, 'areas', ()) or ():
            try:
                area.tag_redraw()
            except Exception:
                pass


def request_locale_refresh(context=None, *, mode: object | None = None) -> None:
    global _LANGUAGE_STATE_CACHE
    if mode is not None:
        set_stored_language_mode(mode)
    else:
        # Keep the last lifecycle-loaded value.  Refreshing UI must never turn a
        # later redraw into a persistence read.
        _LANGUAGE_STATE_CACHE = None
    # Standard N-panel build: update only the stable UI's finite language
    # snapshot. Do not walk bpy.types or re-register RNA from this callback.
    try:
        stable_module = sys.modules.get(f'{__package__}.stable_ui')
        refresh = getattr(stable_module, 'refresh_event_snapshot', None) if stable_module is not None else None
        if callable(refresh):
            refresh(context or getattr(bpy, 'context', None))
    except Exception:
        pass
    try:
        tag_redraw_all()
    except Exception:
        pass



def _unwrap_smart_uv_closure_wrapper(fn):
    current = fn
    seen: set[int] = set()
    while callable(current):
        ident = id(current)
        if ident in seen:
            break
        seen.add(ident)
        marked = False
        try:
            marked = bool(getattr(current, '_smart_uv_locale_prop_wrapper', False)) or bool(getattr(current, '_smart_uv_locale_register_wrapper', False))
        except Exception:
            marked = False
        try:
            module_name = str(getattr(current, '__module__', '') or '')
            if module_name.endswith('text_translation'):
                marked = True
        except Exception:
            pass
        if not marked:
            break
        replacement = None
        for attr in ('_smart_uv_locale_original_constructor', '_smart_uv_locale_original_register_class'):
            try:
                value = getattr(current, attr, None)
                if callable(value) and value is not current:
                    replacement = value
                    break
            except Exception:
                pass
        if replacement is None:
            try:
                for cell in getattr(current, '__closure__', None) or ():
                    try:
                        value = cell.cell_contents
                    except Exception:
                        continue
                    if callable(value) and value is not current:
                        value_module = str(getattr(value, '__module__', '') or '')
                        if not value_module.endswith('text_translation') or value is not current:
                            replacement = value
                            break
            except Exception:
                replacement = None
        if replacement is None:
            break
        current = replacement
    return current



def restore_global_hooks_safely() -> None:
    """Local teardown only; never write Blender process-global callables."""
    try:
        unregister_addon_translations()
    except Exception:
        pass
    _ORIGINAL_LAYOUT_METHODS.clear()
    _ORIGINAL_PROP_CONSTRUCTORS.clear()
    return None

def _unwrap_prior_smart_uv_register_class(fn):
    current = fn
    seen: set[int] = set()
    while callable(current):
        try:
            marked = bool(getattr(current, '_smart_uv_locale_register_wrapper', False))
            if not marked:
                marked = (
                    getattr(current, '__name__', '') == '_register_class_wrapper'
                    and str(getattr(current, '__module__', '')).endswith('text_translation')
                )
        except Exception:
            marked = False
        if not marked:
            break
        ident = id(current)
        if ident in seen:
            break
        seen.add(ident)
        replacement = None
        try:
            stored = getattr(current, '_smart_uv_locale_original_register_class', None)
            if callable(stored) and stored is not current:
                replacement = stored
        except Exception:
            replacement = None
        if replacement is None:
            try:
                closure = getattr(current, '__closure__', None) or ()
                for cell in closure:
                    try:
                        value = cell.cell_contents
                    except Exception:
                        continue
                    if callable(value) and value is not current:
                        replacement = value
                        break
            except Exception:
                replacement = None
        if replacement is None:
            break
        current = replacement
    return current



def disable_global_sanitizers() -> None:
    """Clear only Smart UV local translation state."""
    try:
        unregister_addon_translations()
    except Exception:
        pass
    _ORIGINAL_LAYOUT_METHODS.clear()
    _ORIGINAL_PROP_CONSTRUCTORS.clear()
    return None



def install_register_class_sanitizer(context=None) -> None:
    del context
    return None


def uninstall_register_class_sanitizer() -> None:
    global _REGISTER_SANITIZER_INSTALLED, _ORIGINAL_REGISTER_CLASS, _LANGUAGE_STATE_CACHE
    try:
        unregister_addon_translations()
    except Exception:
        pass
    for _cached in (
        _split_bilingual_inline_cached, _normalize_key, _lookup_en_to_ja,
        _lookup_ja_to_en, _translate_english_words_to_ja, _looks_like_short_label,
        _label_en_to_ja, _heuristic_en_to_ja, _heuristic_ja_to_en,
        _translate_text_for_language, _hay_matches_tooltip_key, _generic_tooltip_ja,
        _localized_description_for_language, _sanitize_enum_items_sequence_for_language,
        _localized_static_property_overlay,
    ):
        try:
            _cached.cache_clear()
        except Exception:
            pass
    _ENUM_ITEMS_FALLBACK_CACHE.clear()
    _DEFERRED_SANITIZE_CACHE.clear()
    _CLASS_MATERIALIZE_CACHE.clear()
    _CLASS_SANITIZE_CACHE.clear()
    _PROP_CONSTRUCTOR_SOURCE_BY_ID.clear()
    _LOCALIZED_CLASSES.clear()
    _LANGUAGE_STATE_CACHE = None
    _REGISTER_SANITIZER_INSTALLED = False
    _ORIGINAL_REGISTER_CLASS = None
    _ORIGINAL_LAYOUT_METHODS.clear()
    _ORIGINAL_PROP_CONSTRUCTORS.clear()


__all__ = [
    'addon_preferences', 'contains_japanese', 'disable_global_sanitizers', 'inline', 'install_register_class_sanitizer',
    'is_japanese', 'language_mode', 'pick', 'request_locale_refresh', 'set_stored_language_mode', 'sanitize_class',
    'sanitize_text', 'split_bilingual_inline', 'translate_text', 'restore_global_hooks_safely', 'uninstall_register_class_sanitizer',
]
