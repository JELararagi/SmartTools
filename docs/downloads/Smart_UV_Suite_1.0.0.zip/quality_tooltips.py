from __future__ import annotations

from . import text_translation as _text_translation

import re

_RULES = [
    dict(
        keywords=("unwrap", "unfold", "peel", "pelt"),
        what=(
            "Create or improve UV shells from the current selection.",
            "現在の選択からUVシェルを作成または改善します。",
        ),
        how=(
            "Select the target faces or islands first, run the tool, then inspect distortion and seam flow before moving on.",
            "最初に対象の面やアイランドを選択してから実行し、その後に歪みやシームの流れを確認して次へ進みます。",
        ),
        when=(
            "Use this near the start of the workflow or when a shell needs a cleaner restart.",
            "作業の初期段階や、シェルをきれいにやり直したい時に向いています。",
        ),
    ),
    dict(
        keywords=("seam", "stitch", "weld", "cut", "sew"),
        what=(
            "Edit where UV shells split or reconnect.",
            "UVシェルをどこで分割・再接続するかを編集します。",
        ),
        how=(
            "Mark or clear the target edges, then unwrap or restitch and review the shell borders.",
            "対象エッジに対してシーム付与・解除を行い、展開や再接続のあとに境界を確認します。",
        ),
        when=(
            "Use this before unwrap, after overlap cleanup, or when shell borders are in the wrong place.",
            "展開前、重なり整理後、またはシェル境界の位置が不適切な時に使います。",
        ),
    ),
    dict(
        keywords=("relax", "smooth", "optimize", "heal"),
        what=(
            "Reduce visible UV distortion while trying to keep the shell readable.",
            "シェルの見やすさを保ちながら、目立つUVの歪みを減らします。",
        ),
        how=(
            "Run it after an initial unwrap or after strong manual edits, then compare the result with checker or stretch views.",
            "初回展開の後や大きな手動編集の後に実行し、チェッカーやストレッチ表示で結果を比較します。",
        ),
        when=(
            "Use this during cleanup when shell shape is close but not stable enough yet.",
            "シェル形状は近いものの、まだ安定していない整理段階で有効です。",
        ),
    ),
    dict(
        keywords=("pack", "layout", "fit", "bounds", "tile", "udim", "fill"),
        what=(
            "Arrange shells into a cleaner layout, tile, or target area.",
            "シェルを見やすいレイアウト、タイル、または目標範囲へ配置します。",
        ),
        how=(
            "Prepare shell shape first, then run the tool and review spacing, margins, and tile placement.",
            "先にシェル形状を整えてから実行し、間隔、余白、タイル配置を確認します。",
        ),
        when=(
            "Use this in the middle to late stages once shell shape is mostly settled.",
            "シェル形状が概ね固まった中盤から終盤で使うのに向いています。",
        ),
    ),
    dict(
        keywords=("stack", "similar", "match", "group"),
        what=(
            "Compare, group, or stack related shells so repeated parts can share placement or be reviewed together.",
            "関連するシェルを比較、グループ化、または重ね、反復部品を同じ配置で共有したり一緒に確認したりできるようにします。",
        ),
        how=(
            "Select repeated parts or a reference island first, then run the stack or match pass and check orientation afterward.",
            "繰り返し部品や基準アイランドを先に選択してから実行し、その後に向きや面積感を確認します。",
        ),
        when=(
            "Use this for mirrored parts, repeated details, trims, and reuse workflows.",
            "左右対称部品、繰り返しディテール、トリム、再利用前提の作業で有効です。",
        ),
    ),
    dict(
        keywords=("align", "orient", "rectify", "straight", "orthogonal", "square", "grid"),
        what=(
            "Clean up shell direction or shape so edges become easier to read and place.",
            "シェルの向きや形状を整え、辺の流れを読みやすく配置しやすくします。",
        ),
        how=(
            "Select the shells or edges that define the direction, run the tool, then review straightness and rotation afterward.",
            "方向の基準になるシェルや辺を選んで実行し、その後に直線性や回転結果を確認します。",
        ),
        when=(
            "Use this for trims, hard-surface panels, strips, and other shape-sensitive layouts.",
            "トリム、ハードサーフェスのパネル、帯状パーツなど、形を重視するレイアウトに向いています。",
        ),
    ),
    dict(
        keywords=("select", "inspect", "audit", "scan", "issue", "diagnostic", "doctor"),
        what=(
            "Inspect the current UV state or select shells that match a condition.",
            "現在のUV状態を検査したり、条件に合うシェルを選択したりします。",
        ),
        how=(
            "Run the scan first when available, then use the selection or report tools to focus on the affected areas.",
            "利用可能なら最初にスキャンを行い、その後に選択ツールやレポートで問題箇所へ絞り込みます。",
        ),
        when=(
            "Use this before repair, packing, baking, export, or when something feels wrong.",
            "修復、パック、ベイク、書き出しの前や、違和感がある時の確認に使います。",
        ),
    ),
    dict(
        keywords=("checker", "preview", "heatmap", "overlay", "histogram", "visual"),
        what=(
            "Show a visual aid for checking distortion, density, or shell state.",
            "歪み、密度、シェル状態を確認するための視覚補助を表示します。",
        ),
        how=(
            "Turn the view on, compare shell areas or colors, then return to editing once the problem spots are clear.",
            "表示を有効にしてシェルの面積感や色差を比較し、問題位置が分かったら編集へ戻ります。",
        ),
        when=(
            "Use this during review when color or pattern cues make issues easier to spot.",
            "色やパターンの手掛かりで問題を見つけやすくしたい確認時に向いています。",
        ),
    ),
    dict(
        keywords=("density", "texel"),
        what=(
            "Measure or adjust texel density so selected shells follow a shared texture scale.",
            "選択シェルのテクセル密度を測定または調整し、共通のテクスチャスケールへ揃えます。",
        ),
        how=(
            "Sample a reference density or set a target value, then review consistency before the final pack.",
            "基準密度を取得するか目標値を設定し、最終パック前に一貫性を確認します。",
        ),
        when=(
            "Use this when multiple assets or materials must feel evenly scaled.",
            "複数アセットや複数マテリアルでスケール感を揃えたい時に有効です。",
        ),
    ),
    dict(
        keywords=("uvmap", "uv map", "layer", "channel"),
        what=(
            "Manage which UV layer is created, duplicated, renamed, reordered, or used as the working target.",
            "作成、複製、名前変更、順序変更、作業対象化するUVレイヤーを管理します。",
        ),
        how=(
            "Choose the target objects first, then create or switch the layer that matches bake, trim, lightmap, or export needs.",
            "最初に対象オブジェクトを決めてから、ベイク、トリム、ライトマップ、書き出しに合うレイヤーを作成または切り替えます。",
        ),
        when=(
            "Use this when one object needs multiple UV roles or when shared naming must stay consistent.",
            "1つのオブジェクトに複数のUV役割が必要な時や、名称管理を揃えたい時に使います。",
        ),
    ),
    dict(
        keywords=("sym", "mirror"),
        what=(
            "Work with mirrored relationships so left-right parts stay consistent.",
            "左右対称の関係を扱い、パーツ同士の整合性を保ちます。",
        ),
        how=(
            "Detect or define the reference side first, then mirror, stack, or transfer the result to the paired side.",
            "最初に基準側を検出または指定し、その後にミラー、スタック、転送を行います。",
        ),
        when=(
            "Use this when symmetrical meshes should share seams, placement, or shell structure.",
            "対称メッシュでシーム、配置、シェル構造を揃えたい時に向いています。",
        ),
    ),
    dict(
        keywords=("atlas", "bake", "material", "color"),
        what=(
            "Prepare shared atlas, bake, color-ID, or material-oriented output from the current objects.",
            "現在のオブジェクトから、共有アトラス、ベイク、カラーID、マテリアル向け出力を準備します。",
        ),
        how=(
            "Prepare naming and layout first, then run the build or bake pass and review the generated result before export.",
            "先に命名やレイアウトを整えてから生成・ベイクを実行し、書き出し前に結果を確認します。",
        ),
        when=(
            "Use this near the end of production when multiple assets need a combined or publish-ready result.",
            "複数アセットをまとめて仕上げる終盤工程や、公開前の準備で使います。",
        ),
    ),
    dict(
        keywords=("preset", "profile", "recipe", "bundle", "workflow"),
        what=(
            "Load, apply, or save a reusable workflow setting set.",
            "再利用できるワークフロー設定を読み込み、適用、保存します。",
        ),
        how=(
            "Choose the goal first, apply the preset or recipe, then fine-tune only the parts that need a custom override.",
            "最初に目的を決めてからプリセットやレシピを適用し、必要な部分だけ後から微調整します。",
        ),
        when=(
            "Use this when you want stable repeatability instead of rebuilding the same setup by hand every time.",
            "毎回同じ設定を手で組み直すのではなく、安定して再現したい時に使います。",
        ),
    ),
    dict(
        keywords=("hotspot", "trim"),
        what=(
            "Arrange shells for trimsheet or hotspot-style reuse.",
            "トリムシートやホットスポット再利用向けにシェルを配置します。",
        ),
        how=(
            "Prepare the bands or cells first, then place repeated parts into those slots and review scale matching afterward.",
            "先に帯やセルを準備してから反復部品を収め、最後にスケールの整合性を確認します。",
        ),
        when=(
            "Use this when repeated parts should snap into prepared cells instead of a freeform layout.",
            "自由配置ではなく、用意したセルや帯へ部品を合わせたい反復作業に向いています。",
        ),
    ),
    dict(
        keywords=("pin", "freeze", "lock"),
        what=(
            "Pin or freeze important UV points so later edits keep critical areas in place.",
            "重要なUV点を固定し、後続編集で崩れないようにします。",
        ),
        how=(
            "Pin the points you must protect first, then unwrap, relax, or transform around them and review the anchor stability afterward.",
            "最初に守りたい点を固定し、その周囲で展開・リラックス・変形を行ってからアンカーの安定性を確認します。",
        ),
        when=(
            "Use this before broader shell edits when a few anchors must stay stable.",
            "少数の基準点を保ったまま大きく編集したい時に先に使います。",
        ),
    ),
    dict(
        keywords=("project", "camera", "planar", "cyl", "sphere", "view", "projection"),
        what=(
            "Project UVs from a direction, camera, or primitive projection shape.",
            "方向、カメラ、または基本形状投影からUVを作成します。",
        ),
        how=(
            "Choose the projection direction first, apply the projection, then clean seams and packing afterward.",
            "先に投影方向を決めて投影を適用し、その後でシーム整理やパックへ進みます。",
        ),
        when=(
            "Use this when you need a fast starting layout before deeper cleanup or packing.",
            "より詳細な整理やパックの前に、素早い初期配置が欲しい時に向いています。",
        ),
    ),
    dict(
        keywords=("flip", "rotate", "scale", "move", "transform"),
        what=(
            "Transform the selected UVs without changing shell membership.",
            "シェルの所属は変えずに選択UVを変形します。",
        ),
        how=(
            "Select the shells to adjust, run the transform, then verify orientation, coverage, and overlap afterward.",
            "調整したいシェルを選んで変形を実行し、その後に向き、面積、重なりを確認します。",
        ),
        when=(
            "Use this after shells already exist and only placement or orientation needs correction.",
            "既にシェルがあり、配置や向きだけを直したい時に使います。",
        ),
    ),
    dict(
        keywords=("context", "setup", "prepare", "readiness", "validate", "workspace", "registry", "catalog", "report", "guide", "parity"),
        what=(
            "Check, generate, or review helper information that keeps the workspace easier to understand and safer to use.",
            "ワークスペースを理解しやすく安全に使うための補助情報を確認、生成、またはレビューします。",
        ),
        how=(
            "Run the scan or report first, read the summary, then return to the matching tool group with a clearer next action.",
            "最初にスキャンやレポートを実行して要約を確認し、次に触るべきツール群へ戻ります。",
        ),
        when=(
            "Use this when troubleshooting, onboarding, auditing parity, or preparing a cleaner next pass.",
            "トラブルシュート、導入教育、対応監査、次の作業を整理したい時に向いています。",
        ),
    ),
]

_JA_RE = re.compile(r'[\u3040-\u30ff\u4e00-\u9fff]')


def _load_tooltip_overrides(namespace: dict) -> dict:
    loader = namespace.get('_suv_load_json_data')
    if callable(loader):
        try:
            data = loader('operator_tooltips.json', fallback={}, root_key='tooltips')
            if isinstance(data, dict):
                return data
        except Exception:
            pass
    return {}


def _override_text(namespace: dict, key: str, class_name: str):
    data = _load_tooltip_overrides(namespace)
    for lookup in (key, class_name):
        if not lookup:
            continue
        row = data.get(str(lookup), None)
        en = ''
        ja = ''
        if isinstance(row, dict):
            en = str(row.get('en', '') or '').strip()
            ja = str(row.get('ja', '') or '').strip()
        elif isinstance(row, str):
            parts = [part.strip() for part in row.split(' / ', 1)]
            if len(parts) == 2:
                en, ja = parts[0], parts[1]
        if en and ja:
            fn = namespace.get('_suv_bilingual_desc')
            if callable(fn):
                try:
                    return fn(en, ja)
                except Exception:
                    pass
            return str(_text_translation.pick(en, ja))
    return ''


def _pick_rule(text: str):
    lower = str(text or '').lower()
    for rule in _RULES:
        if any(key in lower for key in tuple(rule.get('keywords') or ())):
            return rule
    return None


def build_bilingual_description(namespace: dict, label: str, *, idname: str = '', class_name: str = '', desc_hint: str = '') -> str:
    label = str(label or "Tool").strip() or "Tool"
    override = _override_text(namespace, idname, class_name)
    if override:
        return override
    hay = ' '.join([label, idname, desc_hint]).strip()
    chosen = _pick_rule(hay)
    if chosen is None:
        chosen = dict(
            what=(
                "Run this tool on the current UV selection or active mesh target.",
                "現在のUV選択またはアクティブメッシュに対してこのツールを実行します。",
            ),
            how=(
                "Review the result immediately after the run, then adjust options in the redo panel when needed.",
                "実行直後に結果を確認し、必要に応じて再実行パネルでオプションを調整します。",
            ),
            when=(
                "Use it in the stage that matches its name and current selection.",
                "ツール名と現在の選択内容に合う段階で使います。",
            ),
        )
    en = f"{label}. {chosen['what'][0]} {chosen['how'][0]} {chosen['when'][0]}"
    ja = f"{label}。{chosen['what'][1]} {chosen['how'][1]} {chosen['when'][1]}"
    fn = namespace.get('_suv_bilingual_desc')
    if callable(fn):
        try:
            return fn(en, ja)
        except Exception:
            pass
    return str(_text_translation.pick(en, ja))


def patch_operator_descriptions(namespace: dict) -> int:
    patched = 0
    for name, value in list(namespace.items()):
        if not isinstance(value, type):
            continue
        is_op = name.startswith('SUV_OT_')
        is_ui = name.startswith('SUV_PT_') or name.startswith('SUV_MT_')
        if not (is_op or is_ui):
            continue
        try:
            desc = getattr(value, 'bl_description', None)
            prefix = 'SUV_OT_' if is_op else ('SUV_PT_' if name.startswith('SUV_PT_') else 'SUV_MT_')
            label = str(getattr(value, 'bl_label', '') or '').strip() or name.replace(prefix, '').replace('_', ' ').title()
            idname = str(getattr(value, 'bl_idname', '') or '').strip()
            desc_text = desc.strip() if isinstance(desc, str) else ''
            override = _override_text(namespace, idname, name)
            weak = (not desc_text) or (desc_text == label) or (len(desc_text) < 24)
            generic = 'Run this tool on the current UV selection' in desc_text or 'Uses the current UV selection' in desc_text
            not_bilingual = desc_text and (' / ' not in desc_text) and (_JA_RE.search(desc_text) is None)
            if override:
                setattr(value, 'bl_description', override)
                patched += 1
            elif weak or generic or not_bilingual:
                setattr(value, 'bl_description', build_bilingual_description(namespace, label, idname=idname, class_name=name, desc_hint=desc_text))
                patched += 1
        except Exception:
            continue
    return patched
