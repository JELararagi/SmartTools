def build_handlers(api):
    backend = api._flatten_shape_key

    def run(context, op):
        return backend(context, op)

    return {
        'smart_uv_suite.texel_flatten': api.Handler(run, 'Create a mesh shape key from its active UV coordinates.', 'アクティブUV座標からメッシュのシェイプキーを作成します。'),
    }
