import bpy
import math


def _apply(context, op):
    ws = getattr(context.scene, 'suv_workspace', None)
    target = op.value if op.properties.is_property_set('value') else getattr(ws, 'workflow_density', 1024.0)
    size = op.texture_size if op.properties.is_property_set('texture_size') else getattr(ws, 'canvas_size', 2048)
    if target < 1 or size < 128:
        return False
    return 'FINISHED' in bpy.ops.uv.suv_texel_set(
        scope='SELECTED', target_density=target, texture_size=size, use_world_scale=True,
        skip_pinned=True, keep_tile=True)


def build_handlers(api):
    def texture_size(context, op):
        if op.properties.is_property_set('texture_size'):
            return op.texture_size
        return getattr(api._ws(context), 'canvas_size', op.texture_size)

    def density_from_physical(context, op):
        width = op.physical_width_m
        height = op.physical_height_m or width
        if not math.isfinite(width) or not math.isfinite(height) or width <= 0 or height <= 0:
            api._warn(context, op, 'Enter a positive physical texture width in metres.',
                      'テクスチャの実寸幅を正のメートル値で入力してください。')
            return False
        resolution = texture_size(context, op)
        u_density, v_density = resolution / width, resolution / height
        api._info(context, op, f'Texel density: {u_density:.3f} × {v_density:.3f} px/m',
                  f'テクセル密度: {u_density:.3f} × {v_density:.3f} px/m')
        return True

    def invoke_physical(context, op, event):
        if op.properties.is_property_set('physical_width_m'):
            return op.execute(context)
        op.texture_size = texture_size(context, op)
        return context.window_manager.invoke_props_dialog(op)

    def draw_physical(op, context):
        op.layout.prop(op, 'texture_size', text=api._t(context, 'Texture Size', 'テクスチャサイズ'))
        op.layout.prop(op, 'physical_width_m', text=api._t(context, 'Width (m)', '幅 (m)'))
        op.layout.prop(op, 'physical_height_m', text=api._t(context, 'Height (m)', '高さ (m)'))

    return {
        'smart_uv_suite.texel_world_scale_uv_apply_scaling_density': api.Handler(_apply, 'Scale selected UV islands to the world-space target texel density.', '選択 UV アイランドをワールド空間の目標テクセル密度に合わせます。'),
        'smart_uv_suite.texel_density_from_physical_size': api.Handler(
            density_from_physical, 'Calculate texel density in pixels per metre from the texture size and physical dimensions.',
            'テクスチャの解像度と実寸から、メートルあたりのテクセル密度を計算します。',
            invoke=invoke_physical, draw=draw_physical),
    }
