from .uv_map_channels import CHANNEL_PREFIX, map_channel_object_from_context, remove_map_channel, uv_layers


def _remove(context, op):
    if not op.name and not op.properties.is_property_set('index'):
        ok, _, _ = remove_map_channel(context)
        return ok
    obj = map_channel_object_from_context(context)
    layers = uv_layers(obj)
    if layers is None:
        return False
    index = layers.find(op.name) if op.name else op.index
    if not 0 <= index < len(layers):
        return False
    ok, _, _ = remove_map_channel(context, value=CHANNEL_PREFIX + str(index), obj=obj)
    return ok


def build_handlers(api):
    return {
        'smart_uv_suite.workflow_remove': api.Handler(_remove, 'Remove the specified or active UV map channel.', '指定した UV マップまたはアクティブな UV マップを削除します。'),
    }
