# SPDX-License-Identifier: GPL-3.0-or-later
"""Resolve the workflow's UV channel selection before removing it."""
from . import uv_map_channels


def build_handlers(api):
    def remove_channel(context, operation):
        chosen = {}
        if operation.name or operation.properties.is_property_set("index"):
            mesh = uv_map_channels.map_channel_object_from_context(context)
            maps = uv_map_channels.uv_layers(mesh)
            if maps is None:
                return False
            requested = maps.find(operation.name) if operation.name else operation.index
            if requested not in range(len(maps)):
                return False
            chosen = {"value": f"{uv_map_channels.CHANNEL_PREFIX}{requested}", "obj": mesh}
        return bool(uv_map_channels.remove_map_channel(context, **chosen)[0])

    return {"smart_uv_suite.workflow_remove": api.Handler(
        remove_channel,
        "Delete a named, numbered, or active UV map.",
        "名前、番号、または現在の編集対象で指定した UV マップを削除します。",
    )}
