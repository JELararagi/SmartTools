def build_handlers(api):
    backend = api._run_uv_layout(
            'suv_priority_density_pack', scope='scope', group_mode='mode', tier_mode='apply_mode',
            texture_size='texture_size', margin_px='margin_px'
        )

    def run(context, op):
        return backend(context, op)

    return {
        'smart_uv_suite.texel_priority_density_pack': api.Handler(run, 'Apply hero, secondary, and filler density tiers before packing.', '主役、準主役、補助の密度を設定してからパックします。'),
    }
