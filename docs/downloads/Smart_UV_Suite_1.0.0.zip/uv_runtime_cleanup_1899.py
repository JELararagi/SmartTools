# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Smart UV Suite 1.8.99 runtime cleanup and input-state consolidation.

This module removes obsolete event-interception layers that were added by older
incremental fixes.  The important policy for this build is:

* never install Smart UV Suite keymap rows in Blender's Generic Gizmo maps;
* never install the sticky preflight pass-through operator before native UV
  Move/Rotate/Scale/Transform tools;
* keep UV Sync Selection, UV selection mode, mesh selection mode and Sticky
  Selection mode exactly as the user set them unless an explicit mode-toggle
  operator is being executed;
* keep the alignment backends and loop/ring state guard active.

The cleanup is intentionally runtime-only: it does not edit user preferences,
Blender themes, Region Overlap, native toolbars, or default keymaps.
"""
from __future__ import annotations

from typing import Any, Callable, Dict, Iterable, Optional, Set, Tuple

import bpy

_VERSION = (1, 8, 99)
_NS: Dict[str, Any] = {}
_INSTALLED = False
_ORIGINALS: Dict[Tuple[type, str], Callable[..., Any]] = {}
_BASE_SYNC: Optional[Callable[..., Any]] = None

_STICKY_PASSTHROUGH_ID = "smart_uv_suite.sticky_select_expand_passthrough"
_GIZMO_FALLBACK_ID = "smart_uv_suite.uv_gizmo_grip_fix_grab"
_INSTANT_SELECT_ID = "smart_uv_suite.instant_select_drag_move"
_NATIVE_GIZMO_ID = ""

_MODE_STATE_FIELDS = (
    "use_uv_select_sync",
    "uv_select_mode",
    "uv_sticky_select_mode",
    "mesh_select_mode",
)

# Operators that are expected to preserve global selection settings.  Explicit
# setting/toggle operators are deliberately excluded.
_PRESERVE_STATE_IDS = {
    "smart_uv_suite.vertex_align_action",
    "smart_uv_suite.island_direction_align",
    "smart_uv_suite.uv_element_select_action",
    "smart_uv_suite.select_pick",
    "smart_uv_suite.select_island_active",
    "smart_uv_suite.select_similar_islands",
    "smart_uv_suite.select_identical_islands",
    "smart_uv_suite.select_uv_select_flipped",
    "smart_uv_suite.select_zero_islands",
    "smart_uv_suite.select_uv_select_overlapped",
    "smart_uv_suite.operation_instant_select",
}

# Own keymap rows that are allowed to exist after cleanup.  The immediate-select
# drag tool is intentionally limited by the 1.8.94 layer to UV Tweak maps.
_ALLOWED_OWN_KEYMAP_IDS = {
    _INSTANT_SELECT_ID,
}


def _tool_settings(context: Any = None) -> Any:
    try:
        ctx = context or bpy.context
    except Exception:
        ctx = context
    try:
        ts = getattr(ctx, "tool_settings", None)
        if ts is not None:
            return ts
    except Exception:
        pass
    try:
        return getattr(getattr(ctx, "scene", None), "tool_settings", None)
    except Exception:
        return None


def _workspace(context: Any = None) -> Any:
    try:
        ctx = context or bpy.context
        return getattr(getattr(ctx, "scene", None), "suv_workspace", None)
    except Exception:
        try:
            return getattr(getattr(context, "scene", None), "suv_workspace", None)
        except Exception:
            return None


def capture_selection_state(context: Any = None) -> Dict[str, Any]:
    ts = _tool_settings(context)
    ws = _workspace(context)
    state: Dict[str, Any] = {}
    if ts is not None:
        for name in ("use_uv_select_sync", "uv_select_mode", "uv_sticky_select_mode"):
            try:
                state[name] = getattr(ts, name)
            except Exception:
                pass
        try:
            state["mesh_select_mode"] = tuple(bool(v) for v in getattr(ts, "mesh_select_mode"))
        except Exception:
            pass
    if ws is not None:
        try:
            state["workspace_uv_sticky_select_mode"] = getattr(ws, "uv_sticky_select_mode")
        except Exception:
            pass
    return state


_ACTIVE_STATES: list = []


def keep_selection_modes(modes: Dict[str, Any]) -> None:
    """Let an operator's chosen select mode outlast the guards wrapped around it."""
    for state in _ACTIVE_STATES:
        for name in ("uv_select_mode", "mesh_select_mode"):
            if name in modes and name in state:
                state[name] = modes[name]


def restore_selection_state(context: Any = None, state: Optional[Dict[str, Any]] = None) -> None:
    if not state:
        return
    ts = _tool_settings(context)
    if ts is not None:
        try:
            if (
                "use_uv_select_sync" in state
                and hasattr(ts, "use_uv_select_sync")
                and bool(ts.use_uv_select_sync) != bool(state["use_uv_select_sync"])
            ):
                # Writing the same value still re-selects every UV in Blender 5.1.
                setattr(ts, "use_uv_select_sync", bool(state["use_uv_select_sync"]))
        except Exception:
            pass
        try:
            if "uv_select_mode" in state and hasattr(ts, "uv_select_mode"):
                setattr(ts, "uv_select_mode", state["uv_select_mode"])
        except Exception:
            pass
        try:
            if "uv_sticky_select_mode" in state and hasattr(ts, "uv_sticky_select_mode"):
                setattr(ts, "uv_sticky_select_mode", state["uv_sticky_select_mode"])
        except Exception:
            pass
        try:
            if "mesh_select_mode" in state and hasattr(ts, "mesh_select_mode"):
                mode = tuple(bool(v) for v in state["mesh_select_mode"])
                if len(mode) >= 3:
                    setattr(ts, "mesh_select_mode", (mode[0], mode[1], mode[2]))
        except Exception:
            pass
    ws = _workspace(context)
    if ws is not None:
        try:
            if "workspace_uv_sticky_select_mode" in state and hasattr(ws, "uv_sticky_select_mode"):
                setattr(ws, "uv_sticky_select_mode", state["workspace_uv_sticky_select_mode"])
        except Exception:
            pass


def _addon_keyconfig() -> Any:
    try:
        return bpy.context.window_manager.keyconfigs.addon
    except Exception:
        return None


def _all_keyconfigs() -> Iterable[Any]:
    # Foreign/default/user keyconfigs are never inspected by Smart UV cleanup.
    return iter(())


def _remove_keymap_rows(idnames: Iterable[str], *, addon_only: bool = False) -> int:
    del addon_only
    try:
        from . import ownership_runtime_18168 as ownership
        return sum(ownership.remove_owned_keymaps(str(idname)) for idname in tuple(idnames or ()) if str(idname or ''))
    except Exception:
        return 0


def _has_keymap_row(idname: str) -> bool:
    try:
        from . import ownership_runtime_18168 as ownership
        return bool(ownership.owned_keymap_items(str(idname or '')))
    except Exception:
        return False

def _is_gizmo_fallback_enabled(context: Any = None) -> bool:
    ws = _workspace(context)
    try:
        return bool(getattr(ws, "operation_uv_gizmo_grip_fix_enabled", False))
    except Exception:
        return False


def _neutralize_sticky_passthrough_keymaps() -> None:
    """Remove only the exact Smart UV-owned sticky rows in this generation."""
    _remove_keymap_rows({_STICKY_PASSTHROUGH_ID}, addon_only=True)


def _neutralize_gizmo_fallback_when_disabled(context: Any = None) -> None:
    if _is_gizmo_fallback_enabled(context):
        return
    try:
        from . import uv_gizmo_grip_fix as grip
        grip.disable()
    except Exception:
        pass
    _remove_keymap_rows({_GIZMO_FALLBACK_ID}, addon_only=True)

def _disable_legacy_mode_mutators(ns: Dict[str, Any]) -> None:
    """Replace old helper functions that forced UV sync OFF or EDGE mode."""
    def _noop(*args: Any, **kwargs: Any) -> None:
        return None

    for name in (
        "_sus_1644_set_uv_edge_select_mode",
        "_sus_1654_disable_uv_sync_for_uv_only_ops",
        "_sus_1655_disable_sync",
    ):
        try:
            if name in ns:
                ns[name] = _noop
        except Exception:
            pass


def _should_preserve_class(cls: type) -> bool:
    try:
        bid = str(getattr(cls, "bl_idname", "") or "")
    except Exception:
        bid = ""
    if bid in _PRESERVE_STATE_IDS:
        return True
    try:
        label = str(getattr(cls, "bl_label", "") or "").lower()
        if bid.startswith("smart_uv_suite.") and ("loop" in label or "ring" in label or "整列" in label or "align" in label):
            if bid not in {"smart_uv_suite.select_mode", "smart_uv_suite.uv_sync_mode_toggle"}:
                return True
    except Exception:
        pass
    return False


def _wrap_method_preserve_state(cls: type, method_name: str) -> None:
    key = (cls, method_name)
    if key in _ORIGINALS:
        return
    old = getattr(cls, method_name, None)
    if not callable(old):
        return
    # The sticky wrapper restores the context itself and must stay the outermost
    # execute: if it were wrapped here, re-installing it would make the two
    # wrappers call each other forever.
    if getattr(old, "__name__", "") == "_execute_with_sticky_postcondition":
        return

    def _wrapped(self: Any, context: Any, *args: Any, _old: Callable[..., Any] = old, **kwargs: Any) -> Any:
        state = capture_selection_state(context)
        _ACTIVE_STATES.append(state)
        try:
            return _old(self, context, *args, **kwargs)
        finally:
            _ACTIVE_STATES.remove(state)
            restore_selection_state(context, state)
            try:
                _neutralize_sticky_passthrough_keymaps()
                _neutralize_gizmo_fallback_when_disabled(context)
            except Exception:
                pass

    try:
        setattr(cls, method_name, _wrapped)
        _ORIGINALS[key] = old
    except Exception:
        pass


def _install_operator_state_guards(ns: Dict[str, Any]) -> None:
    for value in list(ns.values()):
        if not isinstance(value, type):
            continue
        if not _should_preserve_class(value):
            continue
        # execute is the main path. invoke is guarded only for operators that
        # do not run modal editing; modal transforms must not be wrapped because
        # restoring state on every mouse event would break native dragging.
        _wrap_method_preserve_state(value, "execute")


def _uninstall_operator_state_guards() -> None:
    for (cls, method_name), old in list(_ORIGINALS.items()):
        try:
            setattr(cls, method_name, old)
        except Exception:
            pass
    _ORIGINALS.clear()


def cleanup_runtime_keymaps(context: Any = None) -> None:
    _neutralize_sticky_passthrough_keymaps()
    _neutralize_gizmo_fallback_when_disabled(context)


def _wrap_sync_function(ns: Dict[str, Any]) -> None:
    global _BASE_SYNC
    try:
        cur = ns.get("_sus_1652_sync_keymaps_from_workspace")
    except Exception:
        cur = None
    if not callable(cur) or getattr(cur, "_suv1899_wrapped", False):
        return
    _BASE_SYNC = cur

    def _sync_1899(context: Any = None, _base: Callable[..., Any] = cur) -> Any:
        result = None
        try:
            result = _base(context or bpy.context)
        except TypeError:
            try:
                result = _base()
            except Exception:
                result = None
        except RecursionError:
            result = None
        except Exception:
            result = None
        try:
            install(ns, context or bpy.context)
        except Exception:
            pass
        return result

    try:
        _sync_1899._suv1899_wrapped = True  # type: ignore[attr-defined]
    except Exception:
        pass
    try:
        ns["_sus_1652_sync_keymaps_from_workspace"] = _sync_1899
    except Exception:
        pass


def install(ns: Dict[str, Any], context: Any = None) -> None:
    global _NS, _INSTALLED
    _NS = ns
    _disable_legacy_mode_mutators(ns)
    _install_operator_state_guards(ns)
    cleanup_runtime_keymaps(context or bpy.context)
    _wrap_sync_function(ns)
    _INSTALLED = True


def unregister() -> None:
    _neutralize_sticky_passthrough_keymaps()
    if not _is_gizmo_fallback_enabled(None):
        _neutralize_gizmo_fallback_when_disabled(None)
    _uninstall_operator_state_guards()


def audit_summary(context: Any = None) -> Dict[str, Any]:
    return {
        "sticky_passthrough_keymaps_present": _has_keymap_row(_STICKY_PASSTHROUGH_ID),
        "gizmo_fallback_keymaps_present": _has_keymap_row(_GIZMO_FALLBACK_ID),
        "gizmo_fallback_enabled": _is_gizmo_fallback_enabled(context),
    }
