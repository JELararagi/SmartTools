"""Random offsets for UV islands and groups of stacked islands."""

import random


def build_handlers(api):
    def selected(context):
        rows = api._edit_targets(context)
        sync = api._sync(context)
        islands = [(uv, info) for _, _, uv, info in api._all_islands(context, rows)
                   if any(api._face_selected(face, sync) for face in info.faces)]
        return rows, islands

    def randomize_u(context, op):
        rows, islands = selected(context)
        rng = random.Random(op.index if op.properties.is_property_set("index") else None)
        for uv, info in islands:
            api._move_island(info.faces, uv, rng.uniform(-op.amount, op.amount), 0.0)
        api._flush(rows)
        return bool(islands) and op.amount > 0

    def randomize_groups(context, op):
        rows, islands = selected(context)
        rng = random.Random(op.index if op.properties.is_property_set("index") else None)
        offsets = {}
        for uv, info in islands:
            footprint = tuple(sorted({tuple(round(value, 6) for value in loop[uv].uv)
                                      for face in info.faces for loop in face.loops}))
            if footprint not in offsets:
                offsets[footprint] = (rng.uniform(-op.amount, op.amount), rng.uniform(-op.amount, op.amount))
            api._move_island(info.faces, uv, *offsets[footprint])
        api._flush(rows)
        return bool(islands) and op.amount > 0

    return {
        "smart_uv_suite.pack_randomize_u_position": api.Handler(
            randomize_u, "Randomly offset selected islands along U.", "選択島をU方向にランダム移動します。"),
        "smart_uv_suite.pack_randomize_group_layout": api.Handler(
            randomize_groups, "Randomly offset selected islands while keeping stacked islands together.",
            "重ねたアイランドを一緒に保ち、選択島の位置をランダムに移動します。"),
    }
