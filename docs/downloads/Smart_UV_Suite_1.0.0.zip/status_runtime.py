# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Smart UV Suite status facade.

This module intentionally performs no process-global monkeypatching.  Historical
versions wrapped bpy.utils.register_class, bpy.app.timers, msgbus, draw handlers,
property callbacks and persistent handlers while add-ons were registering.  That
is forbidden for Smart UV Suite 1.8.169.  The public names remain so older call
sites can execute, but every registration/capture boundary is state-neutral and
self-contained.
"""
from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Callable

_STATE: dict[str, dict[str, Any]] = {}


def set_transient(suite_id: str, text: str, *, severity: str = 'INFO', ttl: float | None = None, workspace: str | None = None) -> None:
    _STATE[str(suite_id or '')] = {'text': str(text or ''), 'severity': str(severity or 'INFO'), 'ttl': ttl, 'workspace': workspace}


def set_service(suite_id: str, text: str, *, severity: str = 'INFO', workspace: str | None = None) -> None:
    set_transient(suite_id, text, severity=severity, ttl=None, workspace=workspace)


def begin_task(suite_id: str, task_id: str, text: str, *, severity: str = 'INFO', workspace: str | None = None) -> None:
    set_transient(f'{suite_id}:{task_id}', text, severity=severity, ttl=None, workspace=workspace)


def update_task(suite_id: str, task_id: str, text: str | None = None, *, severity: str | None = None, progress: float | None = None, workspace: str | None = None) -> None:
    key = f'{suite_id}:{task_id}'
    rec = dict(_STATE.get(key, {}))
    if text is not None:
        rec['text'] = str(text)
    if severity is not None:
        rec['severity'] = str(severity)
    if progress is not None:
        rec['progress'] = float(progress)
    if workspace is not None:
        rec['workspace'] = workspace
    _STATE[key] = rec


def finish_task(suite_id: str, task_id: str, text: str | None = None, *, severity: str = 'INFO', ttl: float | None = None, workspace: str | None = None) -> None:
    key = f'{suite_id}:{task_id}'
    if text is None:
        _STATE.pop(key, None)
    else:
        set_transient(key, text, severity=severity, ttl=ttl, workspace=workspace)


def clear(suite_id: str, task_id: str | None = None) -> None:
    if task_id is None:
        _STATE.pop(str(suite_id or ''), None)
    else:
        _STATE.pop(f'{suite_id}:{task_id}', None)


def clear_prefix(prefix: str) -> None:
    prefix = str(prefix or '')
    for key in tuple(_STATE):
        if key.startswith(prefix):
            _STATE.pop(key, None)


def clear_all() -> None:
    _STATE.clear()


def snapshot(*args: Any, **kwargs: Any) -> dict[str, dict[str, Any]]:
    return {k: dict(v) for k, v in _STATE.items()}


@contextmanager
def task_scope(suite_id: str, task_id: str, text: str, **kwargs: Any):
    begin_task(suite_id, task_id, text, **kwargs)
    try:
        yield
    finally:
        finish_task(suite_id, task_id)


def instrument_operator_class(cls: type, suite_id: str, suite_label: str) -> type:
    return cls


def instrument_loaded_package_operators(suite_id: str, package_name: str, suite_label: str) -> int:
    return 0


def instrument_loaded_package_handlers(suite_id: str, package_name: str, suite_label: str) -> int:
    return 0


def restore_package_handlers(suite_id: str) -> int:
    return 0


@contextmanager
def capture_registration_callbacks(suite_id: str, suite_label: str):
    yield


@contextmanager
def capture_runtime_resources(suite_id: str, suite_label: str):
    yield


def prune_orphan_persistent_handler_markers() -> int:
    return 0


def _ensure_global_persistent_handler_prune_callback() -> None:
    return None


def _remove_global_persistent_handler_prune_if_unused() -> None:
    return None

__all__ = [
    'set_transient', 'set_service', 'begin_task', 'update_task', 'finish_task',
    'clear', 'clear_prefix', 'clear_all', 'snapshot', 'task_scope',
    'instrument_operator_class', 'instrument_loaded_package_operators',
    'instrument_loaded_package_handlers', 'restore_package_handlers',
    'capture_registration_callbacks', 'capture_runtime_resources',
    'prune_orphan_persistent_handler_markers',
]
