# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Smart UV Suite 1.8.117: preserve UV Editor selection after Sync-ON UV alignment.

Alignment tools edit UV coordinates only.  When Blender's UV Select Sync is on,
some legacy/native alignment paths temporarily rebuild mesh selection and can
leave the UV Editor's orange selection overlay deselected after the operator
returns.  This layer snapshots the UV Editor selection before alignment and
restores that UV-domain selection after alignment without accepting unrelated
3D View-only mesh selections as UV alignment state.
"""
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

from typing import Any, Callable, Dict, List, Optional, Sequence, Set, Tuple
from functools import lru_cache

import bpy

_VERSION = (1, 8, 117)
_NS: Dict[str, Any] = {}
_PREV: Dict[str, Any] = {}
_MARK = "_suv_18117_selection_preserve"

_DIRECT_CLASS_NAMES: Set[str] = {
    "SMARTUVSUITE_OT_vertex_align_action",
    "SMARTUVSUITE_OT_island_direction_align",
    "SMARTUVSUITE_OT_uv_layout_action",
    "SMARTUVSUITE_OT_direction_align",
    "SMARTUVSUITE_OT_direction_align_action",
}
_FLOW_ALIGN_CLASS_NAMES: Set[str] = {
    "SUV_OT_align_islands",
    "SUV_OT_centralize_islands",
    "SUV_OT_distribute_islands",
    "SUV_OT_rotate_islands",
    "SUV_OT_flip_islands",
    "SUV_OT_uv_straight_line",
    "SUV_OT_uv_set_flow",
    "SUV_OT_hs_gridify",
    "SUV_OT_hs_rectify_fit",
    "SUV_OT_hs_rectify_constrained",
    "SUV_OT_hs_quad_flow",
    "SUV_OT_apply_line_flow_preset",
}
_NATIVE_ALIGN_ACTIONS: Set[str] = {
    "FIT", "FILL", "CROP", "ALIGN_CENTER", "ALIGN_LEFT", "ALIGN_RIGHT", "ALIGN_TOP", "ALIGN_BOTTOM",
    "ROTATE_90", "ROTATE_CCW", "ROTATE_CW", "FLIP_U", "FLIP_V", "STRAIGHTEN", "GRIDIFY", "CIRCLE", "RELAX",
    "RANDOMIZE", "SNAP_GRID", "SNAP_PIXEL", "SNAP_VERTEX",
}
_LAYOUT_PRESERVE_ACTIONS: Set[str] = {
    "ALIGN_TL", "ALIGN_TOP", "ALIGN_TR", "ALIGN_LEFT", "ALIGN_CENTER", "ALIGN_RIGHT",
    "ALIGN_BL", "ALIGN_BOTTOM", "ALIGN_BR", "ALIGN_H", "ALIGN_V",
    "DISTRIBUTE_H", "DISTRIBUTE_V", "ALIGN_H_GROUP", "ALIGN_V_GROUP",
    "DISTRIBUTE_H_GROUP", "DISTRIBUTE_V_GROUP",
    "ROTATE_CCW", "ROTATE_CW", "MIRROR_H", "MIRROR_V", "FLIP_H", "FLIP_V",
    "ORIENT_BBOX", "ORIENT_EDGE", "STRAIGHT", "RECTIFY", "GRIDIFY", "SQUAREIFY",
    "CROP", "FILL", "FIT", "RELAX",
}
_STAGE_LAYOUT_PRESERVE_MODES: Set[str] = {
    "FIT", "FILL", "CROP", "CENTER", "ALIGN_CENTER", "ALIGN_LEFT", "ALIGN_RIGHT", "ALIGN_TOP", "ALIGN_BOTTOM",
    "DISTRIBUTE_H", "DISTRIBUTE_V", "ROTATE_90", "FLIP_U", "FLIP_V", "GRIDIFY", "RECTIFY", "STRAIGHTEN",
}
_STAGE_WORKFLOW_PRESERVE_MODES: Set[str] = {
    "ALIGN", "ALIGN_LEFT", "ALIGN_RIGHT", "ALIGN_TOP", "ALIGN_BOTTOM", "ALIGN_CENTER",
    "STRAIGHTEN", "RECTIFY", "GRIDIFY", "RELAX", "DISTRIBUTE_H", "DISTRIBUTE_V",
}
_REGISTERED_ALIGN_TOKENS = (
    ".align", "_align", "align_", "straight", "rectify", "gridify", "circle",
    "centralize", "distribute", "orient", "rotate_islands", "flip_islands",
    "set_flow", "line_flow_preset",
)
_REGISTERED_EXCLUDE_TOKENS = ("select_", ".select", "_select", "selection", "sync_mode_toggle")
_REGISTERED_DIRECT_CLASS_NAMES_LOWER = frozenset(
    name.lower() for name in (_DIRECT_CLASS_NAMES | _FLOW_ALIGN_CLASS_NAMES)
)



def _tool_settings(context: Any = None) -> Any:
    ctx = context or getattr(bpy, "context", None)
    try:
        ts = getattr(ctx, "tool_settings", None)
        if ts is not None:
            return ts
    except Exception:
        pass
    try:
        return getattr(getattr(ctx, "scene", None), "tool_settings", None)
    except Exception:
        return None


def _sync_on(context: Any = None) -> bool:
    try:
        return bool(getattr(_tool_settings(context), "use_uv_select_sync", False))
    except Exception:
        return False


def _snapshot_tool_state(context: Any = None) -> Dict[str, Any]:
    ts = _tool_settings(context)
    state: Dict[str, Any] = {}
    if ts is None:
        return state
    for name in ("use_uv_select_sync", "mesh_select_mode", "uv_select_mode", "uv_sticky_select_mode"):
        try:
            value = getattr(ts, name)
            if name == "mesh_select_mode":
                try:
                    value = tuple(bool(v) for v in value)
                except Exception:
                    pass
            state[name] = value
        except Exception:
            pass
    return state


def _restore_tool_state(context: Any = None, state: Optional[Dict[str, Any]] = None) -> None:
    if not state:
        return
    ts = _tool_settings(context)
    if ts is None:
        return
    # Sync must be restored before writing BMesh UV selection flags; otherwise
    # Blender may flush the UV overlay from the mesh-domain selection state.
    for name in ("use_uv_select_sync", "mesh_select_mode", "uv_select_mode", "uv_sticky_select_mode"):
        if name not in state:
            continue
        try:
            setattr(ts, name, state[name])
        except Exception:
            pass


def _effective_selection_mode(context: Any = None) -> str:
    ts = _tool_settings(context)
    try:
        if ts is not None and bool(getattr(ts, "use_uv_select_sync", False)):
            mode = tuple(bool(v) for v in getattr(ts, "mesh_select_mode", (True, False, False)))
            if len(mode) >= 3:
                if mode[2]:
                    return "FACE"
                if mode[1]:
                    return "EDGE"
                return "VERTEX"
    except Exception:
        pass
    try:
        raw = getattr(ts, "uv_select_mode", "VERTEX") if ts is not None else "VERTEX"
        if isinstance(raw, (set, list, tuple)):
            vals = {str(v).upper() for v in raw}
            if "FACE" in vals or "ISLAND" in vals:
                return "FACE"
            if "EDGE" in vals:
                return "EDGE"
            return "VERTEX"
        text = str(raw or "VERTEX").upper()
        if "FACE" in text or "ISLAND" in text:
            return "FACE"
        if "EDGE" in text:
            return "EDGE"
    except Exception:
        pass
    return "VERTEX"


def _edit_objects(context: Any = None) -> List[Any]:
    ctx = context or getattr(bpy, "context", None)
    objs: List[Any] = []
    try:
        objs = [o for o in (getattr(ctx, "objects_in_mode_unique_data", None) or []) if getattr(o, "type", "") == "MESH" and getattr(o, "mode", "") == "EDIT"]
    except Exception:
        objs = []
    if not objs:
        try:
            obj = getattr(ctx, "edit_object", None) or getattr(ctx, "active_object", None)
            if obj is not None and getattr(obj, "type", "") == "MESH" and getattr(obj, "mode", "") == "EDIT":
                objs = [obj]
        except Exception:
            pass
    out: List[Any] = []
    seen: Set[int] = set()
    for obj in objs:
        try:
            key = int(obj.data.as_pointer()) if hasattr(obj.data, "as_pointer") else id(obj.data)
        except Exception:
            key = id(getattr(obj, "data", obj))
        if key in seen:
            continue
        seen.add(key)
        out.append(obj)
    return out


def _idx(elem: Any) -> int:
    try:
        return int(getattr(elem, "index", -1))
    except Exception:
        return -1


def _ensure_lookup(bm: Any) -> None:
    for seq in (getattr(bm, "verts", None), getattr(bm, "edges", None), getattr(bm, "faces", None)):
        try:
            seq.ensure_lookup_table()
        except Exception:
            pass
        try:
            seq.index_update()
        except Exception:
            pass


def _uv_layer_for_bmesh(bm: Any) -> Any:
    try:
        layer = bm.loops.layers.uv.active
        if layer is not None:
            return layer
    except Exception:
        pass
    try:
        return bm.loops.layers.uv.verify()
    except Exception:
        return None


def _get_loop_uv_vert(loop: Any, luv: Any) -> bool:
    for getter in (
        lambda: getattr(loop, "uv_select_vert", False),
        lambda: getattr(luv, "select", False),
    ):
        try:
            if bool(getter()):
                return True
        except Exception:
            pass
    return False


def _get_loop_uv_edge(loop: Any, luv: Any) -> bool:
    for getter in (
        lambda: getattr(loop, "uv_select_edge", False),
        lambda: getattr(luv, "select_edge", False),
    ):
        try:
            if bool(getter()):
                return True
        except Exception:
            pass
    return False


def _set_loop_uv_vert(loop: Any, luv: Any, value: bool) -> None:
    if not value:
        return
    try:
        loop.uv_select_vert_set(True)
    except Exception:
        try:
            setattr(loop, "uv_select_vert", True)
        except Exception:
            pass
    try:
        setattr(luv, "select", True)
    except Exception:
        pass


def _set_loop_uv_edge(loop: Any, luv: Any, value: bool) -> None:
    if not value:
        return
    try:
        loop.uv_select_edge_set(True)
    except Exception:
        try:
            setattr(loop, "uv_select_edge", True)
        except Exception:
            pass
    try:
        setattr(luv, "select_edge", True)
    except Exception:
        pass


def _clear_loop_uv_vert(loop: Any, luv: Any = None) -> None:
    try:
        loop.uv_select_vert_set(False)
    except Exception:
        try:
            setattr(loop, "uv_select_vert", False)
        except Exception:
            pass
    if luv is not None:
        try:
            setattr(luv, "select", False)
        except Exception:
            pass


def _clear_loop_uv_edge(loop: Any, luv: Any = None) -> None:
    try:
        loop.uv_select_edge_set(False)
    except Exception:
        try:
            setattr(loop, "uv_select_edge", False)
        except Exception:
            pass
    if luv is not None:
        try:
            setattr(luv, "select_edge", False)
        except Exception:
            pass


def _set_face_uv(face: Any, value: bool) -> None:
    try:
        fn = getattr(face, "uv_select_set", None)
        if callable(fn):
            fn(bool(value))
            return
    except Exception:
        pass
    try:
        setattr(face, "uv_select", bool(value))
    except Exception:
        pass


def _sync_uv_flags_from_mesh(context: Any, bm: Any) -> None:
    """With UV Sync on and stale UV flags, the mesh selection is the selection: copy it to the UV flags."""
    settings = getattr(context, "tool_settings", None)
    if settings is None or not bool(getattr(settings, "use_uv_select_sync", False)):
        return
    if bool(getattr(bm, "uv_select_sync_valid", True)):
        return
    bm.uv_select_sync_from_mesh(sticky_select_mode=str(getattr(settings, "uv_sticky_select_mode", "SHARED_LOCATION")))


def _snapshot_alignment_selection(context: Any = None) -> List[Dict[str, Any]]:
    ctx = context or getattr(bpy, "context", None)
    if ctx is None:
        return []
    try:
        import bmesh
    except Exception:
        return []
    mode = _effective_selection_mode(ctx)
    out: List[Dict[str, Any]] = []
    for obj in _edit_objects(ctx):
        try:
            mesh = getattr(obj, "data", None)
            if mesh is None:
                continue
            bm = bmesh.from_edit_mesh(mesh)
            _ensure_lookup(bm)
            _sync_uv_flags_from_mesh(ctx, bm)
            uv_layer = _uv_layer_for_bmesh(bm)
            if uv_layer is None:
                continue
            item: Dict[str, Any] = {
                "obj": obj,
                "mesh": mesh,
                "mode": mode,
                "sync": _sync_on(ctx),
                "tool_state": _snapshot_tool_state(ctx),
                "verts": {},
                "edges": {},
                "faces": {},
                "loops": {},
                "uv_only_verts": set(),
                "uv_only_edges": set(),
                "uv_only_faces": set(),
            }
            for vert in bm.verts:
                item["verts"][_idx(vert)] = bool(getattr(vert, "select", False))
            for edge in bm.edges:
                item["edges"][_idx(edge)] = bool(getattr(edge, "select", False))
            for face in bm.faces:
                fidx = _idx(face)
                face_uv = False
                try:
                    face_uv = bool(getattr(face, "uv_select", False))
                except Exception:
                    pass
                item["faces"][fidx] = {"mesh": bool(getattr(face, "select", False)), "uv": face_uv}
                try:
                    loops = list(face.loops)
                except Exception:
                    loops = []
                loop_face_selected = False
                loop_states: List[Tuple[Any, int, int, bool, bool, bool, bool]] = []
                for loop in loops:
                    try:
                        luv = loop[uv_layer]
                    except Exception:
                        continue
                    uv_vert = _get_loop_uv_vert(loop, luv)
                    uv_edge = _get_loop_uv_edge(loop, luv)
                    luv_select = False
                    luv_select_edge = False
                    try:
                        luv_select = bool(getattr(luv, "select", False))
                    except Exception:
                        pass
                    try:
                        luv_select_edge = bool(getattr(luv, "select_edge", False))
                    except Exception:
                        pass
                    li = _idx(loop)
                    vi = _idx(getattr(loop, "vert", None))
                    ei = _idx(getattr(loop, "edge", None))
                    nvi = -1
                    try:
                        nvi = _idx(loop.link_loop_next.vert)
                    except Exception:
                        pass
                    item["loops"][li] = {
                        "uv_vert": bool(uv_vert),
                        "uv_edge": bool(uv_edge),
                        "luv_select": bool(luv_select or uv_vert),
                        "luv_select_edge": bool(luv_select_edge or uv_edge),
                        "vert": vi,
                        "next_vert": nvi,
                        "edge": ei,
                        "face": fidx,
                    }
                    loop_states.append((loop, vi, ei, uv_vert, uv_edge, luv_select, luv_select_edge))
                    if uv_vert or luv_select:
                        item["uv_only_verts"].add(vi)
                    if uv_edge or luv_select_edge:
                        item["uv_only_edges"].add(ei)
                        if vi >= 0:
                            item["uv_only_verts"].add(vi)
                        if nvi >= 0:
                            item["uv_only_verts"].add(nvi)
                        loop_face_selected = True
                if mode == "FACE":
                    if face_uv or (loops and all(bool(item["loops"].get(_idx(loop), {}).get("uv_vert", False)) for loop in loops)):
                        item["uv_only_faces"].add(fidx)
                        for loop in loops:
                            try:
                                item["uv_only_verts"].add(_idx(loop.vert))
                                item["uv_only_edges"].add(_idx(loop.edge))
                            except Exception:
                                pass
                    elif loop_face_selected:
                        item["uv_only_faces"].add(fidx)
            item["uv_only_verts"] = sorted(v for v in item["uv_only_verts"] if isinstance(v, int) and v >= 0)
            item["uv_only_edges"] = sorted(e for e in item["uv_only_edges"] if isinstance(e, int) and e >= 0)
            item["uv_only_faces"] = sorted(f for f in item["uv_only_faces"] if isinstance(f, int) and f >= 0)
            out.append(item)
        except Exception:
            continue
    return out


def _clear_all_selection(bm: Any, uv_layer: Any) -> None:
    # Clear UV flags before rebuilding the snapshot.  All writes are False here;
    # selected UV flags are re-applied later without writing False over them.
    for face in bm.faces:
        try:
            _set_face_uv(face, False)
        except Exception:
            pass
        try:
            for loop in list(face.loops):
                try:
                    luv = loop[uv_layer]
                except Exception:
                    luv = None
                _clear_loop_uv_edge(loop, luv)
                _clear_loop_uv_vert(loop, luv)
        except Exception:
            pass
    for face in bm.faces:
        try:
            face.select_set(False)
        except Exception:
            try:
                face.select = False
            except Exception:
                pass
    for edge in bm.edges:
        try:
            edge.select_set(False)
        except Exception:
            try:
                edge.select = False
            except Exception:
                pass
    for vert in bm.verts:
        try:
            vert.select_set(False)
        except Exception:
            try:
                vert.select = False
            except Exception:
                pass


def _restore_mesh_flags_sync_off(bm: Any, item: Dict[str, Any]) -> None:
    verts = item.get("verts") or {}
    edges = item.get("edges") or {}
    faces = item.get("faces") or {}
    for vert in bm.verts:
        try:
            vert.select_set(bool(verts.get(_idx(vert), False)))
        except Exception:
            pass
    for edge in bm.edges:
        try:
            edge.select_set(bool(edges.get(_idx(edge), False)))
        except Exception:
            pass
    for face in bm.faces:
        state = faces.get(_idx(face), {})
        try:
            face.select_set(bool(state.get("mesh", False)))
        except Exception:
            pass


def _restore_mesh_support_from_uv(bm: Any, item: Dict[str, Any]) -> None:
    selected_verts = set(int(v) for v in (item.get("uv_only_verts") or []))
    selected_edges = set(int(e) for e in (item.get("uv_only_edges") or []))
    selected_faces = set(int(f) for f in (item.get("uv_only_faces") or []))
    mode = str(item.get("mode") or "VERTEX").upper()
    if mode == "FACE":
        for face in bm.faces:
            if _idx(face) in selected_faces:
                try:
                    face.select_set(True)
                except Exception:
                    pass
                try:
                    for loop in face.loops:
                        loop.vert.select_set(True)
                        loop.edge.select_set(True)
                except Exception:
                    pass
    elif mode == "EDGE":
        for edge in bm.edges:
            if _idx(edge) in selected_edges:
                try:
                    edge.select_set(True)
                except Exception:
                    pass
                try:
                    for vert in edge.verts:
                        vert.select_set(True)
                except Exception:
                    pass
        for vert in bm.verts:
            if _idx(vert) in selected_verts:
                try:
                    vert.select_set(True)
                except Exception:
                    pass
    else:
        for vert in bm.verts:
            if _idx(vert) in selected_verts:
                try:
                    vert.select_set(True)
                except Exception:
                    pass


def _restore_uv_true_flags(bm: Any, uv_layer: Any, item: Dict[str, Any]) -> None:
    mode = str(item.get("mode") or "VERTEX").upper()
    loops_state: Dict[int, Dict[str, Any]] = dict(item.get("loops") or {})
    selected_faces = set(int(f) for f in (item.get("uv_only_faces") or []))
    if mode == "FACE":
        for face in bm.faces:
            if _idx(face) in selected_faces:
                _set_face_uv(face, True)
    if mode == "EDGE":
        # Edge flags first, then endpoint vertex flags.  Do not write False over
        # vertex flags: Blender can clear an edge/vertex pair as a side effect.
        for face in bm.faces:
            for loop in list(face.loops):
                state = loops_state.get(_idx(loop), {})
                if bool(state.get("uv_edge", False) or state.get("luv_select_edge", False)):
                    try:
                        _set_loop_uv_edge(loop, loop[uv_layer], True)
                    except Exception:
                        pass
        for face in bm.faces:
            for loop in list(face.loops):
                state = loops_state.get(_idx(loop), {})
                if bool(state.get("uv_vert", False) or state.get("luv_select", False) or state.get("uv_edge", False) or state.get("luv_select_edge", False)):
                    try:
                        _set_loop_uv_vert(loop, loop[uv_layer], True)
                    except Exception:
                        pass
    elif mode == "FACE":
        for face in bm.faces:
            for loop in list(face.loops):
                state = loops_state.get(_idx(loop), {})
                try:
                    luv = loop[uv_layer]
                except Exception:
                    continue
                if bool(state.get("uv_edge", False) or state.get("luv_select_edge", False)):
                    _set_loop_uv_edge(loop, luv, True)
                if bool(state.get("uv_vert", False) or state.get("luv_select", False)):
                    _set_loop_uv_vert(loop, luv, True)
    else:
        for face in bm.faces:
            for loop in list(face.loops):
                state = loops_state.get(_idx(loop), {})
                if bool(state.get("uv_vert", False) or state.get("luv_select", False)):
                    try:
                        _set_loop_uv_vert(loop, loop[uv_layer], True)
                    except Exception:
                        pass


def _finalize_vertex_sync_exact(mesh: Any, item: Dict[str, Any], context: Any = None) -> None:
    if str(item.get("mode") or "VERTEX").upper() != "VERTEX" or not bool(item.get("sync", False)):
        return
    ts = _tool_settings(context)
    if ts is None:
        return
    try:
        import bmesh
    except Exception:
        return
    old_sync = None
    try:
        old_sync = bool(getattr(ts, "use_uv_select_sync", False))
        setattr(ts, "use_uv_select_sync", False)
    except Exception:
        old_sync = None
    try:
        bm = bmesh.from_edit_mesh(mesh)
        _ensure_lookup(bm)
        uv_layer = _uv_layer_for_bmesh(bm)
        if uv_layer is None:
            return
        loops_state: Dict[int, Dict[str, Any]] = dict(item.get("loops") or {})
        for face in bm.faces:
            for loop in list(face.loops):
                try:
                    luv = loop[uv_layer]
                except Exception:
                    luv = None
                _clear_loop_uv_edge(loop, luv)
                _clear_loop_uv_vert(loop, luv)
        for face in bm.faces:
            for loop in list(face.loops):
                state = loops_state.get(_idx(loop), {})
                if bool(state.get("uv_vert", False) or state.get("luv_select", False)):
                    try:
                        _set_loop_uv_vert(loop, loop[uv_layer], True)
                    except Exception:
                        pass
        try:
            bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        except TypeError:
            bmesh.update_edit_mesh(mesh)
        except Exception:
            pass
    finally:
        try:
            if old_sync is not None:
                setattr(ts, "use_uv_select_sync", old_sync)
        except Exception:
            pass
    # Do not force another edit-mesh flush after re-enabling Sync here.
    # The UV flags were written while Sync was temporarily off; a final flush can
    # derive an edge flag from adjacent selected vertices in vertex mode.


def _restore_item(item: Dict[str, Any], context: Any = None) -> None:
    try:
        import bmesh
    except Exception:
        return
    obj = item.get("obj")
    mesh = item.get("mesh") or getattr(obj, "data", None)
    if obj is None or mesh is None or getattr(obj, "mode", "") != "EDIT":
        return
    _restore_tool_state(context, item.get("tool_state") if isinstance(item.get("tool_state"), dict) else {})
    try:
        bm = bmesh.from_edit_mesh(mesh)
        _ensure_lookup(bm)
        uv_layer = _uv_layer_for_bmesh(bm)
        if uv_layer is None:
            return
        item_sync = bool(item.get("sync", _sync_on(context)))
        _clear_all_selection(bm, uv_layer)
        if item_sync:
            _restore_mesh_support_from_uv(bm, item)
        else:
            _restore_mesh_flags_sync_off(bm, item)
        _restore_uv_true_flags(bm, uv_layer, item)
        try:
            bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        except TypeError:
            bmesh.update_edit_mesh(mesh)
        except Exception:
            pass
        # Re-apply once after Blender's Sync rebuild to counter the final overlay
        # flush performed by several alignment paths.
        bm = bmesh.from_edit_mesh(mesh)
        _ensure_lookup(bm)
        uv_layer = _uv_layer_for_bmesh(bm)
        if uv_layer is not None:
            if item_sync:
                _restore_mesh_support_from_uv(bm, item)
            _restore_uv_true_flags(bm, uv_layer, item)
            try:
                bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
            except TypeError:
                bmesh.update_edit_mesh(mesh)
            except Exception:
                pass
    except Exception:
        return
    finally:
        _restore_tool_state(context, item.get("tool_state") if isinstance(item.get("tool_state"), dict) else {})
        try:
            _finalize_vertex_sync_exact(mesh, item, context)
        except Exception:
            pass


def _restore_alignment_selection(snapshot: Sequence[Dict[str, Any]], context: Any = None) -> None:
    if not snapshot:
        return
    ctx = context or getattr(bpy, "context", None)
    for item in list(snapshot or []):
        try:
            if isinstance(item, dict):
                _restore_item(item, ctx)
        except Exception:
            continue


def _schedule_deferred_alignment_restore(snapshot: Sequence[Dict[str, Any]]) -> None:
    if not snapshot:
        return
    try:
        snap = list(snapshot)
    except Exception:
        return
    try:
        state = {"count": 0}
        def _restore_after_operator_flush() -> Optional[float]:
            try:
                _restore_alignment_selection(snap, bpy.context)
            except Exception:
                pass
            state["count"] = int(state.get("count", 0)) + 1
            if state["count"] < 2:
                return 0.02
            return None
        _suv_resource.timer_register(_restore_after_operator_flush, first_interval=0.0)
    except Exception:
        pass


def _mark_version(ns: Optional[Dict[str, Any]] = None) -> None:
    source = ns if isinstance(ns, dict) else _NS
    try:
        if isinstance(source, dict):
            source["__version__"] = '1.0.0'
            info = source.get("bl_info")
            if isinstance(info, dict):
                info["version"] = (1, 0, 0)
                info["author"] = "JELararagi"
                source["_SUS_BL_INFO_FALLBACK"] = dict(info)
    except Exception:
        pass


def _should_preserve(self_obj: Any, filter_kind: Optional[str]) -> bool:
    if filter_kind == "native_action":
        try:
            action = str(getattr(self_obj, "action", getattr(self_obj, "mode", "")) or "").upper()
            return action in _NATIVE_ALIGN_ACTIONS or action.startswith("ALIGN_")
        except Exception:
            return False
    if filter_kind == "layout_action":
        try:
            action = str(getattr(self_obj, "action", "") or "").upper()
            return action in _LAYOUT_PRESERVE_ACTIONS or action.startswith("ALIGN_") or action.startswith("DISTRIBUTE_")
        except Exception:
            return False
    if filter_kind == "stage_layout":
        try:
            mode = str(getattr(self_obj, "mode", "") or "").upper()
            return mode in _STAGE_LAYOUT_PRESERVE_MODES or mode.startswith("ALIGN_")
        except Exception:
            return False
    if filter_kind == "stage_workflow":
        try:
            mode = str(getattr(self_obj, "mode", "") or "").upper()
            return mode in _STAGE_WORKFLOW_PRESERVE_MODES or mode.startswith("ALIGN_")
        except Exception:
            return False
    return True


def _wrap_execute(cls: Any, key: str, filter_kind: Optional[str] = None) -> None:
    try:
        if not isinstance(cls, type):
            return
        cur = getattr(cls, "execute", None)
        if not callable(cur) or getattr(cur, _MARK, False):
            return
        _PREV.setdefault(key, cur)

        def execute_preserving_selection(self: Any, context: Any, *args: Any, _old: Callable = cur, _filter: Optional[str] = filter_kind, **kwargs: Any):
            if not _sync_on(context) or not _should_preserve(self, _filter):
                return _old(self, context, *args, **kwargs)
            snapshot = _snapshot_alignment_selection(context)
            try:
                return _old(self, context, *args, **kwargs)
            finally:
                _restore_alignment_selection(snapshot, context)
                _schedule_deferred_alignment_restore(snapshot)

        setattr(execute_preserving_selection, _MARK, True)
        setattr(execute_preserving_selection, "_suv_18117_previous_execute", cur)
        cls.execute = execute_preserving_selection
    except Exception:
        pass


def _patch_direct_classes(ns: Dict[str, Any]) -> None:
    for name in _DIRECT_CLASS_NAMES:
        try:
            _wrap_execute(ns.get(name), f"ns.{name}.execute", "layout_action" if name == "SMARTUVSUITE_OT_uv_layout_action" else None)
        except Exception:
            pass


def _patch_direction_module() -> None:
    try:
        from . import uv_direction_align_unified_18111 as uni
    except Exception:
        return
    for name in ("SMARTUVSUITE_OT_direction_align", "SMARTUVSUITE_OT_direction_align_action"):
        try:
            _wrap_execute(getattr(uni, name, None), f"direction.{name}.execute")
        except Exception:
            pass


def _patch_flow_module(ns: Dict[str, Any]) -> None:
    modules: List[Any] = []
    try:
        from . import flow as flow_mod
        modules.append(flow_mod)
    except Exception:
        pass
    for name in _FLOW_ALIGN_CLASS_NAMES:
        try:
            _wrap_execute(ns.get(name), f"ns.{name}.execute")
        except Exception:
            pass
        for mod in modules:
            try:
                _wrap_execute(getattr(mod, name, None), f"{getattr(mod, '__name__', 'flow')}.{name}.execute")
            except Exception:
                pass


def _patch_native_modules(ns: Dict[str, Any]) -> None:
    try:
        from . import native_unified_tools as nut
    except Exception:
        nut = None
    if nut is not None:
        for name in ("SMARTUVSUITE_OT_native_align_action", "SMARTUVSUITE_OT_native_hub_action"):
            try:
                _wrap_execute(getattr(nut, name, None), f"native.{name}.execute", "native_action")
            except Exception:
                pass
            try:
                _wrap_execute(ns.get(name), f"ns.{name}.execute", "native_action")
            except Exception:
                pass
    try:
        from . import native_stage as stage
    except Exception:
        stage = None
    if stage is not None:
        try:
            _wrap_execute(getattr(stage, "SUV_OT_native_stage_layout", None), "stage.SUV_OT_native_stage_layout.execute", "stage_layout")
        except Exception:
            pass
        try:
            _wrap_execute(getattr(stage, "SUV_OT_native_stage_workflow", None), "stage.SUV_OT_native_stage_workflow.execute", "stage_workflow")
        except Exception:
            pass


@lru_cache(maxsize=2048)
def _registered_operator_tokens_are_align(blid: str, name: str) -> bool:
    """Classify stable RNA identifiers once per loaded operator class."""
    if not blid.startswith(("smart_uv_suite.", "uv.suv_")):
        return False
    if any(token in blid or token in name for token in _REGISTERED_EXCLUDE_TOKENS):
        return False
    if name in _REGISTERED_DIRECT_CLASS_NAMES_LOWER:
        return True
    if blid.startswith("smart_uv_suite.align"):
        return True
    if blid in {
        "smart_uv_suite.seam_rectify",
        "smart_uv_suite.inspect_orient_world",
        "smart_uv_suite.inspect_circle",
        "smart_uv_suite.inspect_straight",
        "smart_uv_suite.inspect_orient",
        "smart_uv_suite.inspect_apply_line_flow_preset",
    }:
        return True
    if blid.startswith("smart_uv_suite."):
        return False
    if blid.startswith(("uv.suv_texel", "uv.suv_density", "uv.suv_group_normalize_layout", "uv.suv_constraint_relax_preserve")):
        return False
    text = name + " " + blid
    return any(token in text for token in _REGISTERED_ALIGN_TOKENS)


def _registered_operator_is_align(cls: Any) -> bool:
    try:
        blid = str(getattr(cls, "bl_idname", "") or "").lower()
        name = str(getattr(cls, "__name__", "") or "").lower()
    except Exception:
        return False
    return _registered_operator_tokens_are_align(blid, name)


def _filter_for_registered_operator(cls: Any) -> Optional[str]:
    try:
        blid = str(getattr(cls, "bl_idname", "") or "").lower()
    except Exception:
        blid = ""
    if "native_hub_action" in blid or "native_align_action" in blid:
        return "native_action"
    if "native_stage_layout" in blid:
        return "stage_layout"
    if "native_stage_workflow" in blid:
        return "stage_workflow"
    try:
        if str(getattr(cls, "__name__", "") or "") == "SMARTUVSUITE_OT_uv_layout_action":
            return "layout_action"
    except Exception:
        pass
    return None


def _patch_registered_align_classes() -> None:
    try:
        classes = list(())
    except Exception:
        classes = []
    for cls in classes:
        try:
            if _registered_operator_is_align(cls):
                _wrap_execute(cls, f"registered.{getattr(cls, 'bl_idname', '')}.execute", _filter_for_registered_operator(cls))
        except Exception:
            pass


def install(ns: Optional[Dict[str, Any]] = None, context: Any = None) -> None:
    global _NS
    if isinstance(ns, dict):
        _NS = ns
    source = ns if isinstance(ns, dict) else _NS
    if not isinstance(source, dict):
        return
    _patch_direct_classes(source)
    _patch_direction_module()
    _patch_flow_module(source)
    _patch_native_modules(source)
    _patch_registered_align_classes()
    _mark_version(source)


apply_all = install


def register() -> None:
    install(_NS, bpy.context)


def unregister() -> None:
    return None


def diagnostics(context: Any = None) -> Dict[str, Any]:
    return {
        "version": _VERSION,
        "preserves_selection_after_align": True,
        "uv_sync_selection_restored_from_uv_editor": True,
        "sync_on": _sync_on(context or getattr(bpy, "context", None)),
    }


# In face select mode, Blender's operator finalizer can re-derive UV face
# selection from stale 3D View face selection after execute() returns.  Keep the
# mesh mode temporarily non-face for that finalizer, then restore the user's
# original ToolSettings in the deferred repair pass.
_RESTORE_ALIGNMENT_SELECTION_BASE_18117 = _restore_alignment_selection

def _restore_alignment_selection(snapshot: Sequence[Dict[str, Any]], context: Any = None) -> None:  # type: ignore[override]
    _RESTORE_ALIGNMENT_SELECTION_BASE_18117(snapshot, context)
    try:
        ctx = context or getattr(bpy, "context", None)
        if not snapshot or not _sync_on(ctx):
            return
        has_face = any(str((item or {}).get("mode") or "").upper() == "FACE" for item in list(snapshot or []))
        if not has_face:
            return
        ts = _tool_settings(ctx)
        if ts is not None and hasattr(ts, "mesh_select_mode"):
            ts.mesh_select_mode = (True, False, False)
    except Exception:
        pass

def _schedule_deferred_alignment_restore(snapshot: Sequence[Dict[str, Any]], restore_sync: bool = False) -> None:  # type: ignore[override]
    if not snapshot:
        return
    try:
        snap = list(snapshot)
    except Exception:
        return
    try:
        tool_state = None
        for item in snap:
            if isinstance(item, dict) and isinstance(item.get("tool_state"), dict):
                tool_state = dict(item.get("tool_state") or {})
                break
        state = {"count": 0}

        def _restore_after_operator_flush() -> Optional[float]:
            try:
                _RESTORE_ALIGNMENT_SELECTION_BASE_18117(snap, bpy.context)
                if tool_state:
                    _restore_tool_state(bpy.context, tool_state)
                _RESTORE_ALIGNMENT_SELECTION_BASE_18117(snap, bpy.context)
                if tool_state:
                    _restore_tool_state(bpy.context, tool_state)
            except Exception:
                pass
            state["count"] = int(state.get("count", 0)) + 1
            if state["count"] < 3:
                return 0.02
            return None

        _suv_resource.timer_register(_restore_after_operator_flush, first_interval=0.01)
    except Exception:
        pass

# 1.8.117 finalization: the direction-align guard now removes stale 3D-only
# selections before Blender's Sync flush, so ToolSettings no longer need a
# temporary mesh-mode guard.  Keep the user's selection mode unchanged.
def _restore_alignment_selection(snapshot: Sequence[Dict[str, Any]], context: Any = None) -> None:  # type: ignore[override]
    try:
        _RESTORE_ALIGNMENT_SELECTION_BASE_18117(snapshot, context)
    except NameError:
        try:
            return None
        except Exception:
            pass


def _schedule_deferred_alignment_restore(snapshot: Sequence[Dict[str, Any]], restore_sync: bool = False) -> None:  # type: ignore[override]
    if not snapshot:
        return
    try:
        snap = list(snapshot)
    except Exception:
        return
    try:
        tool_state = None
        for item in snap:
            if isinstance(item, dict) and isinstance(item.get("tool_state"), dict):
                tool_state = dict(item.get("tool_state") or {})
                break
        state = {"count": 0}

        def _restore_after_operator_flush() -> Optional[float]:
            try:
                _restore_alignment_selection(snap, bpy.context)
                if tool_state:
                    _restore_tool_state(bpy.context, tool_state)
            except Exception:
                pass
            state["count"] = int(state.get("count", 0)) + 1
            if state["count"] < 3:
                return 0.02
            return None

        _suv_resource.timer_register(_restore_after_operator_flush, first_interval=0.01)
    except Exception:
        pass

# 1.8.117 UV-only target scope supplement.  Alignment/Layout operators must not
# derive their working scope from 3D View mesh selection while UV Select Sync is
# enabled.  The target set is taken from the UV Editor selection snapshot that
# exists at operator entry, then restored after the operation.
_UV_ONLY_ALIGN_SCOPE_DEPTH_18117 = 0
_UV_ONLY_ALIGN_SNAPSHOT_STACK_18117: List[Sequence[Dict[str, Any]]] = []
_SELECTION_PATCH_MARK_18117 = "_suv_18117_uv_only_selection_from_context"


def _uv_only_align_scope_push(snapshot: Optional[Sequence[Dict[str, Any]]] = None) -> None:
    global _UV_ONLY_ALIGN_SCOPE_DEPTH_18117
    _UV_ONLY_ALIGN_SCOPE_DEPTH_18117 += 1
    try:
        _UV_ONLY_ALIGN_SNAPSHOT_STACK_18117.append(list(snapshot or []))
    except Exception:
        _UV_ONLY_ALIGN_SNAPSHOT_STACK_18117.append([])


def _uv_only_align_scope_pop() -> None:
    global _UV_ONLY_ALIGN_SCOPE_DEPTH_18117
    try:
        if _UV_ONLY_ALIGN_SNAPSHOT_STACK_18117:
            _UV_ONLY_ALIGN_SNAPSHOT_STACK_18117.pop()
    except Exception:
        pass
    _UV_ONLY_ALIGN_SCOPE_DEPTH_18117 = max(0, int(_UV_ONLY_ALIGN_SCOPE_DEPTH_18117) - 1)


def _uv_only_align_scope_active() -> bool:
    try:
        return int(_UV_ONLY_ALIGN_SCOPE_DEPTH_18117) > 0
    except Exception:
        return False


def _snapshot_item_for_mesh(obj: Any, mesh: Any) -> Optional[Dict[str, Any]]:
    try:
        stack = list(_UV_ONLY_ALIGN_SNAPSHOT_STACK_18117)
    except Exception:
        stack = []
    for snapshot in reversed(stack):
        try:
            for item in list(snapshot or []):
                if not isinstance(item, dict):
                    continue
                item_mesh = item.get("mesh") or getattr(item.get("obj"), "data", None)
                if item_mesh is mesh or item.get("obj") is obj:
                    return item
        except Exception:
            continue
    return None


def _loop_selected_from_current_uv(loop: Any, luv: Any, mode: str) -> Tuple[bool, bool, bool]:
    uv_vert = _get_loop_uv_vert(loop, luv)
    uv_edge = _get_loop_uv_edge(loop, luv)
    if mode == "FACE":
        return bool(uv_vert), bool(uv_edge), bool(uv_vert or uv_edge)
    if mode == "EDGE":
        return bool(uv_vert or uv_edge), bool(uv_edge), bool(uv_edge)
    return bool(uv_vert), False, bool(uv_vert)


def _selection_from_snapshot_item(obj: Any, bm: Any, uv_layer: Any, item: Dict[str, Any]) -> Tuple[List[Any], List[Any], Any, str]:
    mode = str(item.get("mode") or _effective_selection_mode(getattr(bpy, "context", None))).upper()
    selected_faces_idx = set(int(v) for v in (item.get("uv_only_faces") or []) if isinstance(v, int) or str(v).isdigit())
    loops_state: Dict[int, Dict[str, Any]] = dict(item.get("loops") or {})
    sel_faces: Set[Any] = set()
    sel_loops: List[Any] = []
    active_face = getattr(getattr(bm, "faces", None), "active", None)
    for face in bm.faces:
        face_selected = _idx(face) in selected_faces_idx
        try:
            loops = list(face.loops)
        except Exception:
            loops = []
        if mode == "FACE" and face_selected:
            sel_faces.add(face)
            sel_loops.extend(loops)
            continue
        for loop in loops:
            state = loops_state.get(_idx(loop), {})
            loop_selected = False
            if mode == "EDGE":
                loop_selected = bool(state.get("uv_edge", False) or state.get("luv_select_edge", False))
            elif mode == "FACE":
                loop_selected = bool(state.get("uv_vert", False) or state.get("luv_select", False) or state.get("uv_edge", False) or state.get("luv_select_edge", False))
            else:
                loop_selected = bool(state.get("uv_vert", False) or state.get("luv_select", False))
            if loop_selected:
                sel_faces.add(face)
                sel_loops.append(loop)
        if mode == "FACE" and face_selected and face not in sel_faces:
            sel_faces.add(face)
            sel_loops.extend(loops)
    if active_face not in sel_faces:
        active_face = next(iter(sel_faces), None)
    return list(sel_faces), sel_loops, active_face, "UV_EDITOR_SYNC_SNAPSHOT"


def _selection_from_current_uv_only(context: Any, obj: Any, bm: Any, uv_layer: Any) -> Tuple[List[Any], List[Any], Any, str]:
    mode = _effective_selection_mode(context)
    sel_faces: Set[Any] = set()
    sel_loops: List[Any] = []
    active_face = getattr(getattr(bm, "faces", None), "active", None)
    for face in bm.faces:
        try:
            face_uv = bool(getattr(face, "uv_select", False))
        except Exception:
            face_uv = False
        try:
            loops = list(face.loops)
        except Exception:
            loops = []
        face_loop_hit = False
        for loop in loops:
            try:
                luv = loop[uv_layer]
            except Exception:
                continue
            uv_vert, uv_edge, loop_selected = _loop_selected_from_current_uv(loop, luv, mode)
            if loop_selected:
                face_loop_hit = True
                sel_faces.add(face)
                sel_loops.append(loop)
        if mode == "FACE" and (face_uv or (loops and all(_get_loop_uv_vert(l, l[uv_layer]) for l in loops)) or face_loop_hit):
            sel_faces.add(face)
            if not any(l in sel_loops for l in loops):
                sel_loops.extend(loops)
    if active_face not in sel_faces:
        active_face = next(iter(sel_faces), None)
    return list(sel_faces), sel_loops, active_face, "UV_EDITOR_SYNC_CURRENT"


def _selection_from_context_uv_editor_only(context: Any, obj: Any, bm: Any, uv_layer: Any) -> Tuple[List[Any], List[Any], Any, str]:
    try:
        item = _snapshot_item_for_mesh(obj, getattr(obj, "data", None))
        if isinstance(item, dict):
            return _selection_from_snapshot_item(obj, bm, uv_layer, item)
    except Exception:
        pass
    return _selection_from_current_uv_only(context, obj, bm, uv_layer)


def _patch_selection_from_context_uv_only(ns: Optional[Dict[str, Any]] = None) -> None:
    modules: List[Any] = []
    for mod_name in ("core", "ui", "flow"):
        try:
            modules.append(__import__(f"{__package__}.{mod_name}", fromlist=[mod_name]))
        except Exception:
            pass
    for mod in modules:
        try:
            cur = getattr(mod, "_selection_from_context", None)
            if not callable(cur) or getattr(cur, _SELECTION_PATCH_MARK_18117, False):
                continue
            _PREV.setdefault(f"{getattr(mod, '__name__', 'module')}._selection_from_context", cur)

            def _uv_only_selection_proxy(context: Any, obj: Any, bm: Any, uv_layer: Any, _old: Callable = cur):
                try:
                    if _uv_only_align_scope_active() and _sync_on(context):
                        return _selection_from_context_uv_editor_only(context, obj, bm, uv_layer)
                except Exception:
                    pass
                return _old(context, obj, bm, uv_layer)

            setattr(_uv_only_selection_proxy, _SELECTION_PATCH_MARK_18117, True)
            setattr(_uv_only_selection_proxy, "_suv_18117_previous_selection_from_context", cur)
            setattr(mod, "_selection_from_context", _uv_only_selection_proxy)
        except Exception:
            pass
    if isinstance(ns, dict):
        try:
            cur = ns.get("_selection_from_context")
            if callable(cur) and not getattr(cur, _SELECTION_PATCH_MARK_18117, False):
                _PREV.setdefault("ns._selection_from_context", cur)

                def _ns_uv_only_selection_proxy(context: Any, obj: Any, bm: Any, uv_layer: Any, _old: Callable = cur):
                    try:
                        if _uv_only_align_scope_active() and _sync_on(context):
                            return _selection_from_context_uv_editor_only(context, obj, bm, uv_layer)
                    except Exception:
                        pass
                    return _old(context, obj, bm, uv_layer)

                setattr(_ns_uv_only_selection_proxy, _SELECTION_PATCH_MARK_18117, True)
                setattr(_ns_uv_only_selection_proxy, "_suv_18117_previous_selection_from_context", cur)
                ns["_selection_from_context"] = _ns_uv_only_selection_proxy
        except Exception:
            pass


# Replace the wrapping function after defining the UV-only scope helpers.  Fresh
# add-on imports call install() only after this module has finished loading, so
# alignment/layout classes receive this final wrapper.
def _wrap_execute(cls: Any, key: str, filter_kind: Optional[str] = None) -> None:  # type: ignore[override]
    try:
        if not isinstance(cls, type):
            return
        cur = getattr(cls, "execute", None)
        if not callable(cur) or getattr(cur, _MARK, False):
            return
        _PREV.setdefault(key, cur)

        def execute_preserving_selection(self: Any, context: Any, *args: Any, _old: Callable = cur, _filter: Optional[str] = filter_kind, **kwargs: Any):
            if not _sync_on(context) or not _should_preserve(self, _filter):
                return _old(self, context, *args, **kwargs)
            snapshot = _snapshot_alignment_selection(context)
            _uv_only_align_scope_push(snapshot)
            try:
                return _old(self, context, *args, **kwargs)
            finally:
                _uv_only_align_scope_pop()
                _restore_alignment_selection(snapshot, context)
                _schedule_deferred_alignment_restore(snapshot)

        setattr(execute_preserving_selection, _MARK, True)
        setattr(execute_preserving_selection, "_suv_18117_previous_execute", cur)
        cls.execute = execute_preserving_selection
    except Exception:
        pass


_INSTALL_BASE_18117_UV_ONLY_SCOPE = install


def install(ns: Optional[Dict[str, Any]] = None, context: Any = None) -> None:  # type: ignore[override]
    try:
        _INSTALL_BASE_18117_UV_ONLY_SCOPE(ns, context)
    except Exception:
        pass
    try:
        _patch_selection_from_context_uv_only(ns if isinstance(ns, dict) else _NS)
    except Exception:
        pass
    try:
        _mark_version(ns if isinstance(ns, dict) else _NS)
    except Exception:
        pass


apply_all = install
