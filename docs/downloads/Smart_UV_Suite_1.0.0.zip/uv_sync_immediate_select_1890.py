# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""UV Select Sync support for Immediate Select drag move.

Blender's UV Select Sync mode exposes the active UV Editor selection through
mesh vertex/edge/face selection.  The Immediate Select helper previously wrote
only UV-loop selection flags before handing the drag to Blender's native
Transform.  In Sync mode that leaves native Transform with no mesh selection,
so the held drag can become a no-op.  This module adds the matching mesh
selection write only for the Immediate Select hit path, without changing
Blender's global Sync setting or the user's theme/keymap/UI settings.
"""
from __future__ import annotations

from typing import Any

import bpy

_VERSION = (1, 8, 90)
_INSTANT_ID = 'smart_uv_suite.instant_select_drag_move'
_ORIGINALS: dict[str, Any] = {}
_INSTALLED = False


def _sync_enabled(context: Any) -> bool:
    try:
        ts = getattr(context, 'tool_settings', None)
        return bool(getattr(ts, 'use_uv_select_sync', False)) if ts is not None else False
    except Exception:
        return False


def _i45():
    try:
        from . import interaction_1845 as module
        return module
    except Exception:
        return None


def _uv_mode(context: Any) -> str:
    module = _i45()
    try:
        fn = getattr(module, '_uv_mode', None) if module is not None else None
        if callable(fn):
            return str(fn(context) or 'VERTEX').upper()
    except Exception:
        pass
    try:
        raw = getattr(getattr(context, 'tool_settings', None), 'uv_select_mode', 'VERTEX')
        if isinstance(raw, (set, list, tuple)):
            raw = ' '.join(str(v) for v in raw)
        raw = str(raw or 'VERTEX').upper()
    except Exception:
        raw = 'VERTEX'
    if 'FACE' in raw or 'ISLAND' in raw:
        return 'FACE'
    if 'EDGE' in raw:
        return 'EDGE'
    return 'VERTEX'


def _edit_mesh_objects(context: Any):
    module = _i45()
    try:
        fn = getattr(module, '_iter_edit_mesh_objects', None) if module is not None else None
        if callable(fn):
            yield from fn(context)
            return
    except Exception:
        pass
    try:
        objs = getattr(context, 'objects_in_mode_unique_data', None)
        if objs:
            for obj in objs:
                try:
                    if getattr(obj, 'type', None) == 'MESH' and getattr(obj, 'mode', None) == 'EDIT':
                        yield obj
                except Exception:
                    pass
            return
    except Exception:
        pass
    try:
        obj = getattr(context, 'edit_object', None) or getattr(context, 'object', None)
        if obj is not None and getattr(obj, 'type', None) == 'MESH' and getattr(obj, 'mode', None) == 'EDIT':
            yield obj
    except Exception:
        return


def _mesh_key(mesh: Any) -> int:
    try:
        return int(mesh.as_pointer())
    except Exception:
        return id(mesh)


def _bmesh_update(mesh: Any) -> None:
    try:
        import bmesh
        bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
    except TypeError:
        try:
            import bmesh
            bmesh.update_edit_mesh(mesh)
        except Exception:
            pass
    except Exception:
        pass


def _clear_sync_mesh_selection(context: Any) -> None:
    """Clear mesh selection used by UV Select Sync before selecting the hit."""
    try:
        import bmesh
    except Exception:
        return
    touched: dict[int, Any] = {}
    for obj in _edit_mesh_objects(context):
        mesh = getattr(obj, 'data', None)
        if mesh is None:
            continue
        try:
            bm = bmesh.from_edit_mesh(mesh)
            for face in bm.faces:
                try:
                    face.select_set(False)
                except Exception:
                    try:
                        face.select = False
                    except Exception:
                        pass
            for edge in bm.edges:
                try:
                    edge.select_set(False)
                except Exception:
                    try:
                        edge.select = False
                    except Exception:
                        pass
            for vert in bm.verts:
                try:
                    vert.select_set(False)
                except Exception:
                    try:
                        vert.select = False
                    except Exception:
                        pass
            touched[_mesh_key(mesh)] = mesh
        except Exception:
            continue
    for mesh in touched.values():
        _bmesh_update(mesh)


def _face_loop_from_hit(hit: dict[str, Any]):
    try:
        import bmesh
    except Exception:
        return None, None, None, None
    try:
        mesh = hit.get('mesh')
        if mesh is None:
            return None, None, None, None
        bm = bmesh.from_edit_mesh(mesh)
        try:
            bm.faces.ensure_lookup_table()
        except Exception:
            pass
        face = bm.faces[int(hit.get('face', -1))]
        loops = tuple(face.loops)
        if not loops:
            return bm, mesh, face, None
        loop = loops[int(hit.get('local', 0)) % len(loops)]
        return bm, mesh, face, loop
    except Exception:
        return None, None, None, None


def _select_sync_mesh_hit(context: Any, hit: Any) -> bool:
    """Write Blender mesh selection for the hit element while UV Select Sync is ON."""
    if not isinstance(hit, dict):
        return False
    bm, mesh, face, loop = _face_loop_from_hit(hit)
    if bm is None or mesh is None or face is None or loop is None:
        return False
    mode = str(hit.get('mode') or _uv_mode(context) or 'VERTEX').upper()
    changed = False

    try:
        if mode == 'EDGE':
            try:
                loop.edge.select_set(True)
                changed = True
            except Exception:
                try:
                    loop.edge.select = True
                    changed = True
                except Exception:
                    pass
            for vert in (getattr(loop, 'vert', None), getattr(getattr(loop, 'link_loop_next', None), 'vert', None)):
                if vert is None:
                    continue
                try:
                    vert.select_set(True)
                    changed = True
                except Exception:
                    try:
                        vert.select = True
                        changed = True
                    except Exception:
                        pass
        elif mode in {'FACE', 'ISLAND'}:
            try:
                face.select_set(True)
                changed = True
            except Exception:
                try:
                    face.select = True
                    changed = True
                except Exception:
                    pass
            # Keep the vertices/edges selected as well.  This makes the native
            # UV transform target stable across Blender/keymap variants while the
            # visible selection mode remains the user's current mode.
            try:
                for edge in face.edges:
                    try:
                        edge.select_set(True)
                    except Exception:
                        edge.select = True
                for vert in face.verts:
                    try:
                        vert.select_set(True)
                    except Exception:
                        vert.select = True
            except Exception:
                pass
        else:
            try:
                loop.vert.select_set(True)
                changed = True
            except Exception:
                try:
                    loop.vert.select = True
                    changed = True
                except Exception:
                    pass
    except Exception:
        pass

    try:
        bm.select_flush_mode()
    except Exception:
        pass
    if changed:
        _bmesh_update(mesh)
        try:
            area = getattr(context, 'area', None)
            if area is not None:
                area.tag_redraw()
        except Exception:
            pass
    return bool(changed)


def _hit_selected_sync(context: Any, hit: Any) -> bool:
    if not isinstance(hit, dict):
        return False
    bm, _mesh, face, loop = _face_loop_from_hit(hit)
    if bm is None or face is None or loop is None:
        return False
    mode = str(hit.get('mode') or _uv_mode(context) or 'VERTEX').upper()
    try:
        if mode == 'EDGE':
            return bool(getattr(loop.edge, 'select', False))
        if mode in {'FACE', 'ISLAND'}:
            return bool(getattr(face, 'select', False))
        return bool(getattr(loop.vert, 'select', False))
    except Exception:
        return False


def _make_select_wrapper(original_select, original_target, original_clear):
    def _select_hit_fast_1890(context, hit, event=None):
        if not _sync_enabled(context):
            try:
                return bool(original_select(context, hit, event))
            except Exception:
                return False
        if not hit:
            return False
        additive = False
        try:
            additive = bool(getattr(event, 'shift', False) or getattr(event, 'ctrl', False)) if event is not None else False
        except Exception:
            additive = False
        if not additive:
            try:
                if callable(original_clear):
                    original_clear(context)
            except Exception:
                pass
            _clear_sync_mesh_selection(context)
        uv_ok = False
        try:
            if callable(original_target):
                uv_ok = bool(original_target(context, hit, select=True))
            elif callable(original_select):
                uv_ok = bool(original_select(context, hit, event))
        except Exception:
            uv_ok = False
        mesh_ok = _select_sync_mesh_hit(context, hit)
        return bool(uv_ok or mesh_ok)
    try:
        _select_hit_fast_1890._sus_1890_uv_sync_immediate = True
    except Exception:
        pass
    return _select_hit_fast_1890


def _make_hit_selected_wrapper(original_hit_selected):
    def _hit_selected_fast_1890(context, hit):
        if _sync_enabled(context):
            try:
                return bool(_hit_selected_sync(context, hit))
            except Exception:
                pass
        try:
            return bool(original_hit_selected(context, hit))
        except Exception:
            return False
    try:
        _hit_selected_fast_1890._sus_1890_uv_sync_immediate = True
    except Exception:
        pass
    return _hit_selected_fast_1890


def _patch_interaction_1845() -> None:
    module = _i45()
    if module is None:
        return
    try:
        current = getattr(module, '_select_hit_fast_1857', None)
        if getattr(current, '_sus_1890_uv_sync_immediate', False):
            return
    except Exception:
        pass
    original_select = getattr(module, '_select_hit_fast_1857', None) or getattr(module, '_select_hit_fast', None)
    original_target = getattr(module, '_target_records_from_hit_1857', None) or getattr(module, '_target_records_from_hit', None)
    original_clear = getattr(module, '_clear_uv_selection_fast', None)
    original_hit_selected = getattr(module, '_hit_selected_fast', None)
    if callable(original_select):
        _ORIGINALS.setdefault('interaction_1845._select_hit_fast_1857', getattr(module, '_select_hit_fast_1857', None))
        _ORIGINALS.setdefault('interaction_1845._select_hit_fast', getattr(module, '_select_hit_fast', None))
        wrapper = _make_select_wrapper(original_select, original_target, original_clear)
        try:
            module._select_hit_fast_1857 = wrapper
        except Exception:
            pass
        try:
            module._select_hit_fast = wrapper
        except Exception:
            pass
    if callable(original_hit_selected):
        _ORIGINALS.setdefault('interaction_1845._hit_selected_fast', original_hit_selected)
        hit_wrapper = _make_hit_selected_wrapper(original_hit_selected)
        try:
            module._hit_selected_fast = hit_wrapper
        except Exception:
            pass


def _exclude_immediate_from_uv_channel_isolation() -> None:
    try:
        from . import uv_channel_isolation as isolation
        ids = set(getattr(isolation, '_EXCLUDED_OPERATOR_IDS', set()) or set())
        ids.add(_INSTANT_ID)
        isolation._EXCLUDED_OPERATOR_IDS = ids
    except Exception:
        pass


def _unwrap_immediate_select_isolation(package_globals: dict[str, Any] | None = None) -> None:
    try:
        cls = None
        if isinstance(package_globals, dict):
            cls = package_globals.get('SMARTUVSUITE_OT_instant_select_drag_move')
        if not isinstance(cls, type):
            import sys
            pkg = sys.modules.get(__package__)
            cls = getattr(pkg, 'SMARTUVSUITE_OT_instant_select_drag_move', None)
        if not isinstance(cls, type):
            return
        for name in ('invoke', 'modal'):
            current = getattr(cls, name, None)
            original = getattr(cls, '_sus_1889_original_' + name, None)
            if callable(original) and getattr(current, '_sus_1889_uv_channel_isolated', False):
                try:
                    setattr(cls, name, original)
                except Exception:
                    pass
    except Exception:
        pass


def install(package_globals: dict[str, Any] | None = None, context: Any | None = None) -> None:
    global _INSTALLED
    _exclude_immediate_from_uv_channel_isolation()
    _unwrap_immediate_select_isolation(package_globals)
    _patch_interaction_1845()
    _INSTALLED = True
    try:
        if isinstance(package_globals, dict):
            info = package_globals.get('bl_info')
            if isinstance(info, dict):
                info['version'] = (1, 0, 0)
            package_globals['__version__'] = '1.0.0'
            package_globals['_sus_1890_uv_sync_immediate_select'] = True
    except Exception:
        pass


def unregister() -> None:
    # Do not restore the old functions on normal unregister.  Blender may still be
    # tearing down keymaps and modal state, and leaving the safe wrappers in the
    # unloading module is harmless.  A fresh enable imports a fresh module object.
    return None
