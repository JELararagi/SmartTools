import bpy


def _project(context, op):
    area = context.area
    if area is None or area.type != 'VIEW_3D':
        area = next((item for item in getattr(context.screen, 'areas', ()) if item.type == 'VIEW_3D'), None)
    region = next((item for item in getattr(area, 'regions', ()) if item.type == 'WINDOW'), None)
    if context.mode != 'EDIT_MESH' or region is None:
        return False
    with context.temp_override(area=area, region=region):
        native = bpy.ops.uv.project_from_view
        return native.poll() and 'FINISHED' in native(correct_aspect=True)


def build_handlers(api):
    return {
        'smart_uv_suite.unwrap_view_project': api.Handler(_project, 'Project the selected faces from the current 3D view.', '現在の 3D ビューから選択面を投影します。'),
    }
