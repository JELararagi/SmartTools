# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Project selected mesh faces using a usable 3D View region."""

import bpy


def _window_region(area):
    if area and area.type == "VIEW_3D":
        return next((region for region in area.regions if region.type == "WINDOW"), None)
    return None


def build_handlers(api):
    def project(context, options):
        if context.mode != "EDIT_MESH":
            return False
        area = context.area
        if not area or area.type != "VIEW_3D":
            screen_areas = context.screen.areas if context.screen else ()
            area = next((editor for editor in screen_areas if editor.type == "VIEW_3D"), None)
        window = _window_region(area)
        if window is None:
            return False
        with context.temp_override(area=area, region=window):
            command = bpy.ops.uv.project_from_view
            if command.poll():
                return "FINISHED" in command(correct_aspect=True)
        return False

    return {
        "smart_uv_suite.unwrap_view_project": api.Handler(
            project,
            "Project the selected faces from the 3D View with aspect correction.",
            "選択面を 3D ビューから縦横比を補正して投影します。",
        ),
    }
