# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Explicit resource creation API used by Smart UV Suite modules.

Every function is package-local.  Blender's global API objects are never
assigned, replaced or monkeypatched.
"""
from __future__ import annotations
from typing import Any, Callable

from . import ownership_runtime_18168 as ownership


def timer_register(callback: Callable[[], Any], *, first_interval: float = 0.0, persistent: bool = False, **_kwargs: Any) -> Any:
    del persistent
    if not ownership.is_active():
        return None
    return ownership.register_finite_timer(callback, first_interval=first_interval, max_runs=1)


def timer_unregister(callback: Any) -> bool:
    return ownership.remove_timer_callback(callback)


def timer_is_registered(callback: Any) -> bool:
    return ownership.timer_is_registered(callback)


def handler_append(handler_list: Any, callback: Any) -> bool:
    if not ownership.is_active():
        return False
    return ownership.append_handler(handler_list, callback)


def handler_remove(handler_list: Any, callback: Any) -> bool:
    return ownership.remove_handler(handler_list, callback)


def msgbus_subscribe(*args: Any, **kwargs: Any) -> bool:
    if not ownership.is_active():
        return False
    if args:
        raise TypeError("Smart UV msgbus subscription requires keyword arguments")
    return ownership.register_msgbus(
        key=kwargs.get("key"),
        owner=kwargs.get("owner"),
        args=tuple(kwargs.get("args", ())),
        notify=kwargs.get("notify"),
        options=set(kwargs.get("options", ())),
    )


def msgbus_clear(owner: Any) -> bool:
    return ownership.clear_msgbus_owner(owner)


def draw_handler_add(space_type: Any, callback: Any, args: Any, region_type: str, draw_type: str) -> Any:
    if not ownership.is_active() or not callable(callback):
        return None
    captured_args = tuple(args or ())
    def gpu_guarded(*runtime_args: Any) -> Any:
        state_values = {}
        gpu_module = None
        matrix_pushed = False
        try:
            import gpu as gpu_module  # type: ignore
            state = getattr(gpu_module, "state", None)
            for name in ("blend", "depth_test", "face_culling", "line_width", "point_size", "depth_mask", "scissor", "viewport"):
                getter = getattr(state, name + "_get", None)
                if callable(getter):
                    try:
                        state_values[name] = getter()
                    except Exception:
                        pass
            matrix = getattr(gpu_module, "matrix", None)
            push = getattr(matrix, "push", None)
            if callable(push):
                push(); matrix_pushed = True
        except Exception:
            gpu_module = None
        try:
            return callback(*(runtime_args if runtime_args else captured_args))
        finally:
            if gpu_module is not None:
                try:
                    matrix = getattr(gpu_module, "matrix", None)
                    pop = getattr(matrix, "pop", None)
                    if matrix_pushed and callable(pop):
                        pop()
                except Exception:
                    pass
                state = getattr(gpu_module, "state", None)
                for name, value in state_values.items():
                    setter = getattr(state, name + "_set", None)
                    if callable(setter):
                        try:
                            if isinstance(value, tuple):
                                setter(*value)
                            else:
                                setter(value)
                        except Exception:
                            pass
    return ownership.add_draw_handler_exact(space_type, gpu_guarded, captured_args, region_type, draw_type)


def remove_owned_draw_handler(space_type: Any, handle: Any, region_type: str) -> bool:
    del space_type, region_type
    return ownership.remove_draw_handler(handle)


def keymap_item_new(keymap: Any, *args: Any, **kwargs: Any) -> Any:
    idname = str(args[0] if args else kwargs.get("idname", "") or "").strip()
    if not idname:
        return None
    items = getattr(keymap, "keymap_items", None)
    new = getattr(items, "new", None)
    if not callable(new):
        return None
    kmi = new(*args, **kwargs)
    return ownership.track_keymap_item(keymap, kmi, idname)


def keymap_item_new_modal(keymap: Any, *args: Any, **kwargs: Any) -> Any:
    propvalue = str(args[0] if args else kwargs.get("propvalue", "") or "").strip()
    if not propvalue:
        return None
    items = getattr(keymap, "keymap_items", None)
    new = getattr(items, "new_modal", None)
    if not callable(new):
        return None
    kmi = new(*args, **kwargs)
    return ownership.track_keymap_item(keymap, kmi, propvalue)


def keymap_item_remove(keymap: Any, kmi: Any) -> bool:
    return ownership.remove_keymap_item(keymap, kmi)


def keymap_item_set(kmi: Any, name: str, value: Any) -> bool:
    if not ownership.keymap_item_is_owned(kmi):
        return False
    try:
        setattr(kmi, str(name), value)
        return True
    except Exception:
        return False


def keymap_item_set_property(kmi: Any, name: str, value: Any) -> bool:
    if not ownership.keymap_item_is_owned(kmi):
        return False
    try:
        setattr(kmi.properties, str(name), value)
        return True
    except Exception:
        return False


def register_class(cls: type) -> bool:
    return ownership.register_class(cls)


def unregister_class(cls: type) -> bool:
    return ownership.unregister_class(cls)


def register_classes_factory(classes: Any):
    ordered = tuple(classes or ())
    def _register():
        done = []
        try:
            for cls in ordered:
                if not ownership.register_class(cls):
                    raise RuntimeError(f"Smart UV class registration failed: {getattr(cls, '__name__', cls)!s}")
                done.append(cls)
        except Exception:
            for cls in reversed(done):
                ownership.unregister_class(cls)
            raise
    def _unregister():
        for cls in reversed(ordered):
            ownership.unregister_class(cls)
    return _register, _unregister


def register_property(owner: Any, name: str, value: Any) -> bool:
    return ownership.register_property(owner, str(name), value)


def unregister_property(owner: Any, name: str) -> bool:
    return ownership.unregister_property(owner, str(name))


def register_preview_collection(previews_module: Any) -> Any:
    return ownership.register_preview_collection(previews_module)


def unregister_preview_collection(collection: Any) -> bool:
    return ownership.unregister_preview_collection(collection)


def undo_boundary() -> None:
    """Blender's REGISTER/UNDO operator boundary is authoritative; no extra push."""
    return None
