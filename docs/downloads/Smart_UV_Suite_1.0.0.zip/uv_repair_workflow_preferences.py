import bpy


_previous_workspaces = {}


def _current_uv_area(context):
    if getattr(context.area, 'ui_type', None) == 'UV':
        return context.area
    areas = [item for item in getattr(context.screen, 'areas', ()) if item.ui_type == 'UV']
    return areas[0] if len(areas) == 1 else None


def _panel_pointer_required(context, op):
    from .panel_tools import _warn

    _warn(context, op, 'Place the pointer over the UV Editor or 3D View and invoke the command.',
          'UV エディターまたは 3D ビューにポインターを置いて実行してください。')
    return False


def _toggle_panel_at_pointer(context, op, event):
    area = context.area
    if (area is None or area.ui_type not in {'UV', 'VIEW_3D'}
            or not (area.x <= event.mouse_x < area.x + area.width
                    and area.y <= event.mouse_y < area.y + area.height)):
        _panel_pointer_required(context, op)
        return {'CANCELLED'}
    space = area.spaces.active
    if event.mouse_x - area.x < area.width / 2:
        space.show_region_toolbar = not space.show_region_toolbar
    else:
        space.show_region_ui = not space.show_region_ui
    area.tag_redraw()
    return {'FINISHED'}


def _toggle_uv_workspace(context, op):
    from .panel_tools import _warn

    window = context.window
    if bpy.app.background or window is None:
        return False

    uv_workspace = bpy.data.workspaces.get('UV Editing')
    if uv_workspace is None:
        _warn(context, op, 'The UV Editing workspace is unavailable.',
              'UV Editing ワークスペースが見つかりません。')
        return False

    for key in _previous_workspaces.keys() - {item.as_pointer() for item in context.window_manager.windows}:
        del _previous_workspaces[key]
    key = window.as_pointer()
    if window.workspace == uv_workspace:
        previous = _previous_workspaces.get(key)
        target = next((item for item in bpy.data.workspaces if item.as_pointer() == previous), None)
        if target is None or target == uv_workspace:
            _warn(context, op, 'There is no previous workspace to restore in this window.',
                  'このウィンドウで復元できるワークスペースがありません。')
            return False
        window.workspace = target
        del _previous_workspaces[key]
    else:
        previous = window.workspace.as_pointer()
        window.workspace = uv_workspace
        _previous_workspaces[key] = previous
    return True


def _activate(context, op):
    mode = (op.mode or 'ENABLE').strip().upper()
    if mode not in {'ENABLE', 'DISABLE'}:
        return False
    return 'FINISHED' in bpy.ops.smart_uv_suite.preferences_core_activation(enable=mode == 'ENABLE')


def _open_help(context, op, event=None):
    # 窓（popup）は入れ子の open_help が持つ。外側は modal の受け手を置かないので、
    # RUNNING_MODAL をそのまま返さず FINISHED で終える（返すと GUI で終了時に落ちる。PD34C v2 ④）
    result = bpy.ops.smart_uv_suite.open_help('INVOKE_DEFAULT', topic=op.key or 'overview')
    if 'RUNNING_MODAL' in result or 'FINISHED' in result:
        return {'FINISHED'}
    return result


def _open_pack_tutorial(context, op, event=None):
    if bpy.app.background or context.window is None or context.area is None:
        from .panel_tools import _warn
        _warn(context, op, 'Open the packing tutorial from a Blender editor.',
              'Blender のエディターからパックのチュートリアルを開いてください。')
        return {'CANCELLED'}
    return bpy.ops.smart_uv_suite.show_help('INVOKE_DEFAULT', help_id='layout_pack')


def _auto_uv_sync(context, op):
    return 'FINISHED' in bpy.ops.smart_uv_suite.toggle_always_on_feature(feature_id='SMART_AUTO_UV_SYNC')


def _show_addon_preferences(context, op):
    if bpy.app.background or context.screen is None or __package__ not in context.preferences.addons:
        return False
    return 'FINISHED' in bpy.ops.preferences.addon_show(module=__package__)


def _show_keymap_preferences(context, op):
    native = bpy.ops.screen.userpref_show
    if bpy.app.background or context.window is None or not native.poll():
        from .panel_tools import _warn
        _warn(context, op, 'Open Keymap preferences from a Blender window.',
              'Blender のウィンドウからキーマップ設定を開いてください。')
        return False
    return 'FINISHED' in native(section='KEYMAP')


def _activate_uv_sculpt(context, op):
    from .panel_tools import _warn

    area = _current_uv_area(context)
    region = next((item for item in getattr(area, 'regions', ()) if item.type == 'WINDOW'), None)
    if context.mode != 'EDIT_MESH' or region is None:
        _warn(context, op, 'Open a UV Editor with a mesh in Edit Mode to use UV Sculpt.',
              'UV スカルプトを使うには、メッシュを編集モードにして UV エディターを開いてください。')
        return False
    with context.temp_override(area=area, region=region):
        tool = bpy.ops.wm.tool_set_by_id
        if not tool.poll() or 'FINISHED' not in tool(name='sculpt.uv_sculpt_grab'):
            return False
        area.spaces.active.show_region_toolbar = True
    return True


def _integrated_invoke(context, op, event=None):
    return bpy.ops.smart_uv_suite.integrated_invoke(
        addon_alias=op.name, target_kind=op.mode, target_id=op.key,
    )


def _preset_library(context, op, invoke=False):
    options = {
        'mode': op.mode,
        'library_kind': op.scope,
        'text_name': op.name,
        'filepath': op.filepath,
        'merge_mode': op.apply_mode,
        'entry_key': op.key,
        'entry_label': op.title_en,
        'entry_label_ja': op.title_ja,
    }
    return bpy.ops.uv.suv_preset_library_io(
        'INVOKE_DEFAULT' if invoke else 'EXEC_DEFAULT',
        **{name: value for name, value in options.items() if value},
    )


def build_handlers(api):
    apply_recipe = api._apply_flow_profile('suv_apply_workflow_recipe')

    def run_recipe(context, op):
        if not op.profile:
            api._warn(context, op, 'Choose a workflow recipe before running it.',
                      '実行するワークフローレシピを選択してください。')
            return False
        return apply_recipe(context, op)

    def invoke_recipe(context, op, event):
        if op.profile:
            return op.execute(context)
        menu = bpy.ops.wm.call_menu
        if not bpy.app.background and menu.poll():
            return menu(name='UVSUITE_MT_WORKFLOW_RECIPES')
        return {'CANCELLED'}

    def preview_padding(context, op):
        area = _current_uv_area(context)
        ws = api._ws(context)
        if bpy.app.background or area is None or ws is None or ws.canvas_size <= 0:
            api._warn(context, op, 'Open a UV Editor to preview fitting padding.',
                      'フィットの余白を表示するには UV エディターを開いてください。')
            return False

        islands = api._seed_islands(context, api._edit_targets(context))
        padding = ws.fit_padding_px / ws.canvas_size
        if not islands or padding <= 0.0:
            api._warn(context, op, 'Select UV islands and set positive fitting padding.',
                      'UV アイランドを選び、フィットの余白を正の値に設定してください。')
            return False

        boxes = []
        for _, _, _, island in islands:
            x0, y0, x1, y1 = island.box
            boxes.append((x0 - padding, y0 - padding, x1 + padding, y1 + padding))
        return draw_boxes(area, boxes)

    def bounding_box(context, op):
        area = _current_uv_area(context)
        if bpy.app.background or area is None:
            api._warn(context, op, 'Open a UV Editor to display the UV bounds.',
                      'UV の外接矩形を表示するには UV エディターを開いてください。')
            return False
        if context.mode != 'EDIT_MESH':
            api._warn(context, op, 'Edit a mesh and select UV islands to display their bounds.',
                      '外接矩形を表示するには、メッシュの編集モードで UV アイランドを選択してください。')
            return False
        boxes = [island.box for _, _, _, island in api._seed_islands(context, api._edit_targets(context))]
        if not boxes:
            api._warn(context, op, 'Select UV islands to display their bounds.',
                      '外接矩形を表示する UV アイランドを選択してください。')
            return False
        left, bottom, right, top = zip(*boxes)
        bounds = (min(left), min(bottom), max(right), max(top))
        if not draw_boxes(area, [bounds]):
            return False
        # 表示した外接矩形を scene に残す（表示は 5 秒で消えるので、何を描いたかを後から確かめられるようにする。PD34C v2）
        context.scene['SUV_UV_BOUNDS_PREVIEW'] = [float(v) for v in bounds]
        return True

    def draw_test(context, op):
        area = _current_uv_area(context)
        if bpy.app.background or area is None:
            api._warn(context, op, 'Open a UV Editor to run the draw test.',
                      '描画テストを実行するには UV エディターを開いてください。')
            return False
        return draw_boxes(area, [(0.25, 0.25, 0.75, 0.75)])

    def draw_boxes(area, boxes):
        from gpu import shader
        from gpu_extras.batch import batch_for_shader

        area_id = area.as_pointer()
        color = (0.0, 0.9, 0.9, 1.0)

        def draw():
            ctx = bpy.context
            if ctx.area is None or ctx.area.as_pointer() != area_id or ctx.region is None:
                return
            project = ctx.region.view2d.view_to_region
            vertices = []
            for x0, y0, x1, y1 in boxes:
                corners = ((x0, y0), (x1, y0), (x1, y1), (x0, y1))
                points = [project(*corner, clip=False) for corner in corners]
                for start, end in zip(points, points[1:] + points[:1]):
                    vertices.extend((start, end))
            program = shader.from_builtin('UNIFORM_COLOR')
            program.bind()
            program.uniform_float('color', color)
            batch_for_shader(program, 'LINES', {'pos': vertices}).draw(program)

        space = bpy.types.SpaceImageEditor
        previous = box_previews.pop(area_id, None)
        if previous is not None:
            space.draw_handler_remove(previous, 'WINDOW')
        handle = space.draw_handler_add(draw, (), 'WINDOW', 'POST_PIXEL')
        box_previews[area_id] = handle

        def clear_preview():
            if box_previews.get(area_id) is handle:
                del box_previews[area_id]
                space.draw_handler_remove(handle, 'WINDOW')
                for window in getattr(bpy.context.window_manager, 'windows', ()):
                    for live_area in window.screen.areas:
                        if live_area.as_pointer() == area_id:
                            live_area.tag_redraw()
            return None

        bpy.app.timers.register(clear_preview, first_interval=5.0, persistent=True)
        area.tag_redraw()
        return True

    box_previews = {}

    def trim_file_invoke(context, op, event):
        if op.filepath:
            return op.execute(context)
        op.filter_glob = '*.json'
        return api._file_invoke_for('trim_presets.json')(context, op, event)

    def trim_file(mode):
        def run(context, op):
            path = api._file_path(op, '.json')
            if not path:
                api._warn(context, op, 'Choose a trim preset JSON file.',
                          'トリムプリセットの JSON ファイルを選択してください。')
                return False
            return 'FINISHED' in bpy.ops.uv.suv_preset_library_io(
                mode=mode, library_kind='HOTSPOT', filepath=path,
            )
        return run

    return {
        'smart_uv_suite.workflow_integrated_invoke': api.Handler(
            lambda context, op: bool(_integrated_invoke(context, op) & {'FINISHED', 'RUNNING_MODAL', 'INTERFACE'}),
            'Open the specified integrated tool.', '指定した統合ツールを開きます。',
            invoke=_integrated_invoke),
        'smart_uv_suite.workflow_integrated_addon_info': api.Handler(
            api._run_uv_layout('integrated_addon_info', namespace='smart_uv_suite', addon_alias='key'),
            'Report the status of the specified integrated add-on.', '指定した統合アドオンの状態を報告します。'),
        'smart_uv_suite.workflow_show_addon_preferences': api.Handler(
            _show_addon_preferences, 'Open this add-on’s settings in Blender Preferences.',
            'Blenderのプリファレンスでこのアドオンの設定を開きます。'),
        'smart_uv_suite.workflow_keymaps_config': api.Handler(
            _show_keymap_preferences, 'Open the Keymap section of Blender Preferences.',
            'Blender のプリファレンスでキーマップ設定を開きます。'),
        'smart_uv_suite.workflow_workspace_toggle': api.Handler(
            _toggle_uv_workspace, 'Switch to UV Editing or return to the previous workspace in this window.',
            'UV Editing に切り替えるか、このウィンドウの直前のワークスペースに戻ります。'),
        'smart_uv_suite.view_run_guided_workflow': api.Handler(
            run_recipe, 'Choose a workflow recipe or run the specified recipe in order.',
            'ワークフローレシピを選択するか、指定したレシピを順番に実行します。', invoke=invoke_recipe),
        'smart_uv_suite.view_toggle_panels_by_cursor': api.Handler(
            _panel_pointer_required,
            'Toggle the toolbar from the left half of the editor or the sidebar from the right half.',
            'エディターの左半分でツールバー、右半分でサイドバーを切り替えます。',
            invoke=_toggle_panel_at_pointer),
        'smart_uv_suite.view_guide_padding': api.Handler(
            preview_padding, 'Preview the configured fitting padding around the selected UV islands for five seconds.',
            '選択した UV アイランドの周囲にフィットの余白を 5 秒間表示します。'),
        'smart_uv_suite.workflow_bounding_box': api.Handler(
            bounding_box, 'Show the bounding rectangle of the selected UV islands for five seconds.',
            '選択した UV アイランドの外接矩形を 5 秒間表示します。'),
        'smart_uv_suite.workflow_draw_test': api.Handler(
            draw_test, 'Show a test square from UV (0.25, 0.25) to (0.75, 0.75) for five seconds.',
            'UV (0.25, 0.25) から (0.75, 0.75) に描画テスト用の正方形を 5 秒間表示します。'),
        'smart_uv_suite.workflow_sculpt': api.Handler(
            _activate_uv_sculpt, 'Activate the Grab UV Sculpt brush and show the UV Editor toolbar.',
            'UV スカルプトのグラブブラシを有効にし、UV エディターのツールバーを表示します。'),
        'smart_uv_suite.preset_library_io': api.Handler(
            lambda context, op: 'FINISHED' in _preset_library(context, op),
            'Import, export, or capture the selected preset library.',
            '指定したプリセットライブラリを読み込み・書き出し・登録します。',
            invoke=lambda context, op, event: _preset_library(
                context, op, invoke=op.mode in {'EXPORT_FILE', 'IMPORT_FILE'} and not op.filepath)),
        'smart_uv_suite.inspect_auto_uv_sync': api.Handler(
            _auto_uv_sync, 'Toggle Smart Auto UV Sync.', 'Smart Auto UV Sync を切り替えます。'),
        'smart_uv_suite.workflow_toggle_always_on_feature': api.Handler(
            api._run_uv_layout('toggle_always_on_feature', namespace='smart_uv_suite', feature_id='feature_id'),
            'Toggle the specified always-on feature.', '指定した常時機能を切り替えます。'),
        'smart_uv_suite.workflow_preferences_core_activation': api.Handler(_activate, 'Activate or deactivate Smart UV Core.', 'Smart UV Core を有効または無効にします。'),
        'smart_uv_suite.workflow_open_smart_tools': api.Handler(
            api._run_uv_layout('open_smart_tools', namespace='smart_uv_suite'),
            'Refresh the Smart UV sidebar and restore the saved workspace settings.',
            'Smart UV サイドバーを更新し、保存済みのワークスペース設定を復元します。'),
        'smart_uv_suite.workflow_show_help': api.Handler(
            lambda context, op: bool(_open_help(context, op) & {'RUNNING_MODAL', 'FINISHED'}),
            'Open the detailed help popup for this tool group.',
            '操作グループの詳しいヘルプを開きます。',
            invoke=_open_help),
        'smart_uv_suite.pack_open_tutorial': api.Handler(
            lambda context, op: bool(_open_pack_tutorial(context, op) & {'RUNNING_MODAL', 'FINISHED'}),
            'Open the tutorial for packing, layout, stacking, and UDIM tools.',
            'パック、配置、スタック、UDIM ツールのチュートリアルを開きます。',
            invoke=_open_pack_tutorial),
        'smart_uv_suite.pack_save_trim_preset': api.Handler(
            trim_file('EXPORT_FILE'), 'Save the trim preset library as JSON.',
            'トリムプリセットライブラリを JSON ファイルに保存します。', invoke=trim_file_invoke),
        'smart_uv_suite.pack_load_trim_preset': api.Handler(
            trim_file('IMPORT_FILE'), 'Import trim presets from JSON into the current library.',
            'JSON のトリムプリセットを現在のライブラリに追加します。', invoke=trim_file_invoke),
    }
