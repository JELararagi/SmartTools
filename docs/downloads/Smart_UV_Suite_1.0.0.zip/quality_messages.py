from __future__ import annotations

QUALITY_MESSAGES = {
        'ui.section.quality': ('Quality & Safety', '品質と安全'),
        'ui.section.translation': ('Language & Help', '言語とヘルプ'),
        'msg.quality_patch_ready': ('Quality guard layer enabled.', '品質ガード層を有効化しました。'),
        'msg.translation_ready': ('Japanese translation dictionary registered.', '日本語翻訳辞書を登録しました。'),
        'ui.section.quality_fallback': ('UI fallback', 'UIフォールバック'),
        'msg.ui_draw_failed': ('A panel or menu draw step failed. The add-on kept running and showed this fallback instead. Details: {e}', 'パネルまたはメニューの描画中に問題が起きましたが、アドオンは継続し、この代替表示を出しています。詳細: {e}'),
        'msg.quality_hint.context': ('Try running this tool from the UV Editor or 3D View with a valid active mesh context.', 'UVエディターまたは3Dビューで、有効なアクティブメッシュ状態にしてから再実行してください。'),
        'msg.quality_hint.mesh_edit': ('Select a mesh object, switch to Edit Mode, and make sure the target faces or UVs are available.', 'メッシュオブジェクトを選択し、編集モードへ切り替え、対象面またはUVが存在する状態で実行してください。'),
        'msg.quality_hint.uvmap': ('Create or activate a UV map before running this tool, then retry on the intended target.', 'このツールの実行前にUVマップを作成または有効化し、対象を確認してから再試行してください。'),
        'msg.quality_hint.uv_editor': ('Open the UV Editor and retry so the operator has a valid UV editing area.', '有効なUV編集領域を確保するため、UVエディターを開いてから再試行してください。'),
        'msg.quality_hint.view3d': ('Open a 3D View and retry so the operator can access mesh-side context.', 'メッシュ側のコンテキストへアクセスできるよう、3Dビューを開いてから再試行してください。'),
        'msg.quality_hint.pack': ('Review selection, tile target, and UV bounds first, then retry after shells are prepared.', '選択状態、対象タイル、UV範囲を確認し、シェル準備後に再試行してください。'),
        'msg.quality_hint.selection': ('Check the current face or island selection first, then retry with the intended UV target.', '現在の面またはアイランド選択を確認し、意図したUV対象で再試行してください。'),
        'msg.quality_hint.generic': ('Review the current selection, object mode, UV map, and active editor, then try again.', '現在の選択、オブジェクトモード、UVマップ、アクティブなエディターを確認してから再試行してください。'),
        'msg.preflight_mesh_missing': ('Select an active mesh object before running this tool.', 'このツールを実行する前に、アクティブなメッシュオブジェクトを選択してください。'),
        'msg.preflight_set_active': ('The first selected mesh was promoted to the active object for this tool.', 'このツールのために、最初の選択メッシュをアクティブオブジェクトへ切り替えました。'),
        'msg.preflight_need_edit': ('Switch to Edit Mode on the target mesh, then run the tool again.', '対象メッシュを編集モードに切り替えてから、もう一度このツールを実行してください。'),
        'msg.preflight_edit_mode': ('Edit Mode was prepared automatically for this tool.', 'このツールのために編集モードを自動で準備しました。'),
        'msg.preflight_uv_created': ('Created missing UV maps for {count} object(s).', '{count} 個のオブジェクトに不足していたUVマップを作成しました。'),
        'ui.visual.restore_count': ('Rollback guards', 'ロールバック保護数'),
        'msg.restore_cancelled': ('Cancelled operator restored the previous work context.', 'キャンセルされた処理後に、直前の作業コンテキストを復元しました。'),
        'ui.visual.state_rollback': ('State & Rollback', '状態とロールバック'),
        'ui.visual.copy_tool_runtime': ('Copy tool_runtime log', '実行ログコピー'),
        'ui.visual.clear_all_reports': ('Clear all reports', '全レポート消去'),
        'ui.visual.readiness_score': ('Readiness', '準備スコア'),
        'ui.visual.readiness_missing': ('Missing readiness checks', '不足している準備項目'),
        'ui.visual.context_setup': ('Context & Setup', 'コンテキストと準備'),
        'ui.visual.scan_context': ('Scan context', 'コンテキスト確認'),
        'ui.visual.prepare_context': ('Prepare basics', '基本準備'),
        'ui.visual.add_uv_map': ('Add UV map', 'UVマップ追加'),
        'ui.visual.repair_workspace': ('Repair workspace', 'ワークスペース修復'),
        'msg.quality_context_scan': ('Context scan: score {score}/5, active mesh {active_mesh}, edit mode {edit_mode}, UV Editor {uv_editor}, 3D View {view3d}, active UV map {active_uv_map}, selected meshes {selected_meshes}.', 'コンテキスト確認: スコア {score}/5、アクティブメッシュ {active_mesh}、編集モード {edit_mode}、UVエディター {uv_editor}、3Dビュー {view3d}、アクティブUVマップ {active_uv_map}、選択メッシュ数 {selected_meshes}。'),
        'msg.quality_context_prepared': ('Prepared context: active changed {active}, edit mode changed {edit}, UV maps created {uv}. Readiness score is now {score}/5.', 'コンテキストを準備しました: アクティブ変更 {active}、編集モード変更 {edit}、作成UVマップ {uv}。現在の準備スコアは {score}/5 です。'),
        'ui.visual.cleanup_candidates': ('Cleanup candidates', 'クリーンアップ候補'),
        'ui.visual.housekeeping': ('Generated Data', '生成データ'),
        'ui.visual.scan_cleanup': ('Scan cleanup', 'クリーンアップ確認'),
        'ui.visual.run_cleanup': ('Run cleanup', 'クリーンアップ実行'),
        'msg.quality_cleanup_done': ('Cleanup finished. Removed {total} item(s): texts {texts}, images {images}, materials {materials}, node groups {node_groups}, meshes {meshes}. Cache cleared: {cache}.', 'クリーンアップが完了しました。削除: 合計 {total} 件（テキスト {texts}、画像 {images}、マテリアル {materials}、ノードグループ {node_groups}、メッシュ {meshes}）。キャッシュ消去: {cache}'),
        'msg.quality_cleanup_scan': ('Cleanup scan found {total} candidate(s): texts {texts}, images {images}, materials {materials}, node groups {node_groups}, meshes {meshes}.', 'クリーンアップ候補を {total} 件検出しました（テキスト {texts}、画像 {images}、マテリアル {materials}、ノードグループ {node_groups}、メッシュ {meshes}）。'),
        'ui.visual.audit_reports': ('Audit & Reports', '監査とレポート'),
        'ui.visual.run_audit': ('Run quality audit', '品質監査を実行'),
        'ui.visual.open_audit': ('Open audit report', '監査レポートを開く'),
        'ui.visual.clear_notice_cache': ('Clear notice cache', '通知キャッシュ消去'),
        'ui.visual.tool_runtime_errors': ('Runtime errors', '実行時エラー数'),
        'ui.visual.coverage_guides': ('Coverage & Guides', '対応範囲とガイド'),
        'ui.visual.run_matrix': ('Build feature matrix', '機能マトリクス作成'),
        'ui.visual.open_matrix': ('Open feature matrix', '機能マトリクスを開く'),
        'ui.visual.covered_groups': ('Covered groups', '対応済みグループ'),
        'ui.visual.missing_groups': ('Missing groups', '不足グループ'),
        'msg.quality_matrix_written': ('Feature matrix written: {name} (supported {supported}/{total})', '機能マトリクスを書き出しました: {name}（対応 {supported}/{total}）'),
        'msg.quality_matrix_opened': ('Opened feature matrix: {name}', '機能マトリクスを開きました: {name}'),
        'msg.quality_audit_written': ('Quality audit written: {name} (score {score}/100)', '品質監査レポートを書き出しました: {name}（スコア {score}/100）'),
        'msg.quality_audit_opened': ('Opened quality audit: {name}', '品質監査レポートを開きました: {name}'),
        'msg.quality_notice_cache_cleared': ('Quality notice cache cleared. Active cached notices: {total}', '品質通知キャッシュを消去しました。現在のキャッシュ件数: {total}'),
        'ui.visual.help_catalog': ('Help & Catalog', 'ヘルプとカタログ'),
        'ui.visual.write_help': ('Write guided help', 'ガイドヘルプ作成'),
        'ui.visual.open_help': ('Open guided help', 'ガイドヘルプを開く'),
        'ui.visual.write_catalog': ('Write operator catalog', 'オペレーターカタログ作成'),
        'ui.visual.open_catalog': ('Open operator catalog', 'オペレーターカタログを開く'),
        'msg.quality_help_written': ('Guided help written: {name}', 'ガイドヘルプを書き出しました: {name}'),
        'msg.quality_help_opened': ('Opened guided help: {name}', 'ガイドヘルプを開きました: {name}'),
        'msg.quality_catalog_written': ('Operator catalog written: {name} ({total} entries)', 'オペレーターカタログを書き出しました: {name}（{total} 件）'),
        'msg.quality_catalog_opened': ('Opened operator catalog: {name}', 'オペレーターカタログを開きました: {name}'),
        'ui.visual.language_tips': ('Language & Tips', '言語と説明'),
        'ui.visual.run_language': ('Write language coverage', '言語対応レポート作成'),
        'ui.visual.open_language': ('Open language coverage', '言語対応レポートを開く'),
        'ui.visual.translated_labels': ('Translated labels', '翻訳済みラベル'),
        'ui.visual.rich_tooltips': ('Rich tooltips', '詳しいツールチップ'),
        'msg.quality_language_written': ('Language coverage written: {name} ({translated}/{total} labels translated)', '言語対応レポートを書き出しました: {name}（翻訳済み {translated}/{total}）'),
        'msg.quality_language_opened': ('Opened language coverage: {name}', '言語対応レポートを開きました: {name}'),
        'ui.visual.report_hub_count': ('Reports', 'レポート数'),
        'ui.visual.report_hub': ('Reports Hub', 'レポートハブ'),
        'ui.visual.write_report_hub': ('Write report hub', 'レポートハブ作成'),
        'ui.visual.open_report_hub': ('Open report hub', 'レポートハブを開く'),
        'ui.visual.task_playbooks': ('Task Playbooks', 'タスク別プレイブック'),
        'ui.visual.write_playbook': ('Write task playbook', 'タスク別プレイブック作成'),
        'ui.visual.open_playbook': ('Open task playbook', 'タスク別プレイブックを開く'),
        'ui.visual.ready_workflows': ('Ready workflows', '準備完了ワークフロー'),
        'msg.quality_playbook_written': ('Task playbook written: {name} ({ready}/{total} ready)', 'タスク別プレイブックを書き出しました: {name}（準備完了 {ready}/{total}）'),
        'msg.quality_playbook_opened': ('Opened task playbook: {name}', 'タスク別プレイブックを開きました: {name}'),
        'msg.quality_report_hub_written': ('Report hub written: {name} ({existing}/{total} ready)', 'レポートハブを書き出しました: {name}（利用可能 {existing}/{total}）'),
        'msg.quality_report_hub_opened': ('Opened report hub: {name}', 'レポートハブを開きました: {name}'),
        'ui.visual.profiled_ops': ('Profiled ops', 'プロファイル対象数'),
        'ui.visual.profile_blocked': ('Blocked now', '現在停止候補'),
        'ui.visual.execution_profiles': ('Execution Profiles', '実行プロファイル'),
        'ui.visual.write_profiles': ('Write execution profiles', '実行プロファイル作成'),
        'ui.visual.open_profiles': ('Open execution profiles', '実行プロファイルを開く'),
        'msg.quality_profiles_written': ('Execution profiles written: {name} ({profiled}/{total} profiled)', '実行プロファイルを書き出しました: {name}（対象 {profiled}/{total}）'),
        'msg.quality_profiles_opened': ('Opened execution profiles: {name}', '実行プロファイルを開きました: {name}'),
        'msg.quality_profile_blocked': ('Blocked by execution profile: {label}. Missing: {missing}', '実行プロファイルにより停止しました: {label}。不足: {missing}'),
        'ui.visual.report_registry': ('Registry & Cleanup', 'レジストリと整理'),
        'ui.visual.write_registry': ('Write report registry', 'レポートレジストリ作成'),
        'ui.visual.open_registry': ('Open report registry', 'レポートレジストリを開く'),
        'ui.visual.registry_count': ('Registry texts', 'レジストリ数'),
        'msg.quality_registry_written': ('Report registry written: {name} ({existing}/{total} texts ready)', 'レポートレジストリを書き出しました: {name}（利用可能 {existing}/{total}）'),
        'msg.quality_registry_opened': ('Opened report registry: {name}', 'レポートレジストリを開きました: {name}'),
        'ui.visual.doctor_actions': ('Action items', 'アクション項目'),
        'ui.visual.doctor_card': ('Doctor & Actions', 'ドクターと対処'),
        'ui.visual.write_doctor': ('Write quality doctor', '品質ドクター作成'),
        'ui.visual.open_doctor': ('Open quality doctor', '品質ドクターを開く'),
        'msg.quality_doctor_written': ('Quality doctor report written: {name} ({count} actions)', '品質ドクターレポートを書き出しました: {name}（{count} 件のアクション）'),
        'msg.quality_doctor_opened': ('Opened quality doctor report: {name}', '品質ドクターレポートを開きました: {name}'),

}

# Extra keys that support the cached visual-status layer.
QUALITY_MESSAGES.update({
    'ui.visual.clear_state_cache': ('Clear status cache', '状態キャッシュ消去'),
    'msg.quality_state_cache_cleared': ('Visual status cache cleared.', '視覚状態キャッシュを消去しました。'),
    'ui.visual.section_workflow': ('Workflow & Setup', 'ワークフローと準備'),
    'ui.visual.section_learning': ('Guides & Language', 'ガイドと言語'),
    'ui.visual.section_maintenance': ('Reports & Maintenance', 'レポートと保守'),
    'ui.visual.ui_map': ('Visual UI Map', '視覚UIマップ'),
    'ui.visual.write_ui_map': ('Write visual UI map', '視覚UIマップ作成'),
    'ui.visual.open_ui_map': ('Open visual UI map', '視覚UIマップを開く'),
    'ui.visual.card_sections': ('Card sections', 'カードセクション数'),
    'ui.visual.visible_cards': ('Visible cards', '表示カード数'),
    'ui.visual.hidden_cards': ('Hidden cards', '非表示カード数'),
    'ui.visual.visible_actions': ('Visible actions', '表示アクション数'),
    'ui.visual.section_count': ('Card sections', 'カードセクション数'),
    'msg.quality_ui_map_written': ('Visual UI map written: {name} ({sections} sections)', '視覚UIマップを書き出しました: {name}（{sections} セクション）'),
    'msg.quality_ui_map_opened': ('Opened visual UI map: {name}', '視覚UIマップを開きました: {name}'),
})



QUALITY_MESSAGES.update({
    'ui.visual.recommended_actions': ('Recommended actions', 'おすすめアクション'),
    'ui.visual.recommended_hint': ('Start from these context-aware shortcuts first, then move to the full cards below when you need more control.', 'まずは状況に合ったこのショートカットから始め、より細かい操作が必要になったら下のカードへ進んでください。'),
    'ui.visual.layout_columns': ('Layout columns', 'レイアウト列数'),
    'ui.visual.button_columns': ('Button columns', 'ボタン列数'),
    'ui.visual.compact_layout': ('Compact layout', 'コンパクト配置'),
    'ui.visual.focus_mode': ('Focus mode', 'フォーカス表示'),
})


QUALITY_MESSAGES.update({
    'msg.quality_audit_missing': ('No quality audit report exists yet.', '品質監査レポートはまだ作成されていません。'),
    'msg.quality_help_missing': ('No guided help text exists yet.', 'ガイドヘルプはまだ作成されていません。'),
    'msg.quality_catalog_missing': ('No operator catalog exists yet.', 'オペレーターカタログはまだ作成されていません。'),
    'msg.quality_language_missing': ('No language coverage report exists yet.', '言語対応レポートはまだ作成されていません。'),
    'msg.quality_matrix_missing': ('No feature matrix exists yet.', '機能マトリクスはまだ作成されていません。'),
    'msg.quality_playbook_missing': ('No task playbook exists yet.', 'タスク別プレイブックはまだ作成されていません。'),
    'msg.quality_profiles_missing': ('No execution profiles report exists yet.', '実行プロファイルレポートはまだ作成されていません。'),
    'msg.quality_registry_missing': ('No report registry exists yet.', 'レポートレジストリはまだ作成されていません。'),
    'msg.quality_report_hub_missing': ('No report hub exists yet.', 'レポートハブはまだ作成されていません。'),
    'msg.quality_doctor_missing': ('No quality doctor report exists yet.', '品質ドクターレポートはまだ作成されていません。'),
    'msg.quality_ui_map_missing': ('No visual UI map exists yet.', '視覚UIマップはまだ作成されていません。'),
})

def install_quality_messages(namespace: dict) -> int:
    text_map = namespace.get('_TEXT')
    if not isinstance(text_map, dict):
        return 0
    text_map.update(QUALITY_MESSAGES)
    return len(QUALITY_MESSAGES)


QUALITY_MESSAGES.update({
    'ui.visual.focus_controls': ('Focus controls', 'フォーカス切替'),
    'ui.visual.focus_hint': ('Lock the quick guide to setup, repair, coverage, analyze, or show all cards.', 'クイックガイドを準備、修復、対応範囲、分析、または全表示に固定できます。'),
    'ui.visual.focus_override': ('Focus override', '手動フォーカス'),
    'ui.visual.focus_auto': ('AUTO', '自動'),
    'ui.visual.focus_setup': ('Setup', '準備'),
    'ui.visual.focus_repair': ('Repair', '修復'),
    'ui.visual.focus_coverage': ('Calc Coverage', '対応範囲'),
    'ui.visual.focus_analyze': ('Analyze', '分析'),
    'ui.visual.focus_all': ('All', '全表示'),
    'msg.quality_focus_set': ('Focus mode set to {mode}.', 'フォーカス表示を {mode} に切り替えました。'),
})



QUALITY_MESSAGES.update({
    'ui.visual.focus_effective': ('Effective focus', '実効フォーカス'),
    'ui.visual.focus_manual_on': ('Manual', '手動'),
    'ui.visual.focus_manual_off': ('Auto', '自動'),
})

QUALITY_MESSAGES.update({
    'ui.bool.on': ('On', 'オン'),
    'ui.bool.off': ('Off', 'オフ'),
    'ui.visual.dashboard_density': ('Dashboard density', 'ダッシュボード密度'),
    'ui.visual.density_controls': ('Density controls', '表示密度切替'),
    'ui.visual.density_hint': ('Choose AUTO for adaptive status density, ESSENTIAL for compact mode, or FULL for every status chip.', 'AUTO は自動調整、ESSENTIAL はコンパクト表示、FULL は全状態表示です。'),
    'ui.visual.density_auto': ('AUTO', '自動'),
    'ui.visual.density_essential': ('Essential', '要点'),
    'ui.visual.density_full': ('Full', '全表示'),
    'msg.quality_density_set': ('Dashboard density set to {mode}.', 'ダッシュボード密度を {mode} に切り替えました。'),
})



QUALITY_MESSAGES.update({
    'ui.visual.section_controls': ('Section controls', 'セクション切替'),
    'ui.visual.section_hint': ('Show only the dashboard sections you need right now to keep the quick guide compact.', '今必要なダッシュボードセクションだけを表示して、クイックガイドをコンパクトに保ちます。'),
    'ui.visual.hidden_sections': ('Hidden sections', '非表示セクション数'),
    'ui.visual.section_toggle.workflow': ('Workflow', 'ワークフロー'),
    'ui.visual.section_toggle.learning': ('Guides', 'ガイド'),
    'ui.visual.section_toggle.maintenance': ('Reports', 'レポート'),
    'ui.visual.section_toggle.all': ('All', '全体'),
    'ui.visual.section_state.shown': ('shown', '表示'),
    'ui.visual.section_state.hidden': ('hidden', '非表示'),
    'ui.visual.section_reset': ('Reset sections', 'セクション再表示'),
    'msg.quality_section_visibility_set': ('Section {section} is now {state}.', 'セクション {section} を {state} にしました。'),
    'msg.quality_section_visibility_reset': ('All dashboard sections are visible again.', 'ダッシュボードの全セクションを再表示しました。'),
})


QUALITY_MESSAGES.update({
    'ui.visual.dashboard_preset': ('Dashboard preset', 'ダッシュボードプリセット'),
    'ui.visual.preset_controls': ('Preset controls', 'プリセット切替'),
    'ui.visual.preset_hint': ('Apply a one-click dashboard preset that changes focus, density, and visible sections together.', 'フォーカス、表示密度、表示セクションをまとめて切り替えるワンクリックプリセットです。'),
    'ui.visual.preset.auto': ('Auto', '自動'),
    'ui.visual.preset.start': ('Starter', '入門'),
    'ui.visual.preset.repair': ('Repair', '修復'),
    'ui.visual.preset.analyze': ('Analyze', '分析'),
    'ui.visual.preset.full': ('Full', '全体'),
    'ui.visual.preset.custom': ('Custom', 'カスタム'),
    'ui.visual.preset_custom_hint': ('Manual focus, density, or section changes are active.', 'フォーカス・表示密度・セクションの手動変更が有効です。'),
    'ui.visual.reset_visual_controls': ('Reset visual controls', '視覚コントロール初期化'),
    'msg.quality_preset_applied': ('Dashboard preset applied: {preset}.', 'ダッシュボードプリセットを適用しました: {preset}。'),
    'msg.quality_visual_controls_reset': ('Visual controls reset to {preset}.', '視覚コントロールを {preset} に戻しました。'),

    'ui.visual.manual_controls': ('Manual controls', '手動コントロール数'),
    'ui.visual.controls_summary': ('Preset {preset} | Focus {focus} | Density {density} | Hidden sections {hidden}', 'プリセット {preset} | フォーカス {focus} | 密度 {density} | 非表示セクション {hidden}'),
    'ui.visual.controls_summary_label': ('Visual controls', '視覚コントロール'),
    'ui.visual.controls_custom_hint': ('Manual visual control changes are active.', '視覚コントロールの手動変更が有効です。'),
})


QUALITY_MESSAGES.update({
    'ui.visual.write_controls_report': ('Write controls report', '視覚コントロールレポート作成'),
    'ui.visual.open_controls_report': ('Open controls report', '視覚コントロールレポートを開く'),
    'ui.visual.manual_item.focus': ('Manual focus override', '手動フォーカス上書き'),
    'ui.visual.manual_item.density': ('Manual dashboard density', '手動ダッシュボード密度'),
    'ui.visual.manual_item.section': ('Hidden section: {section}', '非表示セクション: {section}'),
    'ui.visual.manual_item.preset_custom': ('Custom preset state', 'カスタムプリセット状態'),
    'ui.visual.reason.general': ('Useful next step', '次の有力候補'),
    'ui.visual.reason.controls_report': ('Review active visual control overrides', '現在の視覚コントロール上書きを確認'),
    'ui.visual.reason.reset_controls': ('Return the dashboard to a clean baseline', 'ダッシュボードを整理された初期状態へ戻す'),
    'ui.visual.controls_report_existing': ('Controls report', '視覚コントロールレポート'),
    'msg.quality_controls_report_written': ('Visual controls report written: {name}', '視覚コントロールレポートを書き出しました: {name}'),
    'msg.quality_controls_report_opened': ('Opened visual controls report: {name}', '視覚コントロールレポートを開きました: {name}'),
    'msg.quality_controls_report_missing': ('No visual controls report exists yet.', '視覚コントロールレポートはまだ作成されていません。'),
})
