from __future__ import annotations
from . import resource_api_18168 as _suv_resource

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None

_NAMESPACE = {}
_REGISTERED = []


def _tr(context, key: str, en: str, ja: str, **fmt) -> str:
    fn = _NAMESPACE.get('tr')
    text = None
    if callable(fn):
        try:
            text = fn(context, key, **fmt)
        except Exception:
            text = None
    if not text:
        text = en
    try:
        return text.format(**fmt)
    except Exception:
        return text


def _text_name(context) -> str:
    ws_fn = _NAMESPACE.get('_suv_ws')
    ws = ws_fn(context) if callable(ws_fn) else None
    name = getattr(ws, 'support_bundle_name', '') if ws else ''
    return (str(name).strip() or 'SUV_Support_Bundle') + '_Guided_Help'


def _text_block(name: str, clear=False):
    textio = _NAMESPACE.get('_quality_textio_module')
    if textio is not None and hasattr(textio, 'ensure_report_text'):
        try:
            return textio.ensure_report_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if textio is not None and hasattr(textio, 'ensure_namespace_text'):
        try:
            return textio.ensure_namespace_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if bpy is None:
        return None
    txt = bpy.data.texts.get(name)
    if txt is None:
        if not clear:
            return None
        txt = bpy.data.texts.new(name)
    elif clear:
        txt.clear()
    return txt


def build_guided_help(namespace: dict, context) -> dict:
    readiness_fn = namespace.get('scan_context_readiness')
    readiness = readiness_fn(namespace, context) if callable(readiness_fn) else {}
    audit_fn = namespace.get('scan_quality_audit')
    audit = audit_fn(context) if callable(audit_fn) else {}
    matrix_fn = namespace.get('scan_feature_matrix')
    matrix = matrix_fn(namespace, context) if callable(matrix_fn) else {}
    data = {
        'readiness': readiness or {},
        'audit': audit or {},
        'matrix': matrix or {},
    }
    namespace['_suv_guided_help_last'] = data
    return data


class SUV_OT_quality_write_guided_help(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_write_guided_help'
    bl_label = 'Write Guided Help'
    bl_description = 'Write a beginner-friendly guided help text with setup order, recommended workflows, and troubleshooting steps for the current UV Suite build. / 現在の UV Suite 用に、準備順、推奨ワークフロー、トラブルシュートをまとめた初心者向けガイドヘルプを書き出します。'
    bl_options = set()

    open_after_write: bpy.props.BoolProperty(
        name='Open After Write',
        description='Open the written help text in Blender Text Editor when possible / 可能なら書き出したヘルプテキストを Blender テキストエディタで開きます',
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        data = build_guided_help(_NAMESPACE, context)
        readiness = data.get('readiness', {})
        audit = data.get('audit', {})
        matrix = data.get('matrix', {})
        missing_groups = [g.get('title_en', '-') for g in matrix.get('groups', []) if g.get('status') == 'missing']
        partial_groups = [g.get('title_en', '-') for g in matrix.get('groups', []) if g.get('status') == 'partial']
        txt = None
        lines = [
            'UV Suite Guided Help',
            '',
            '[Current quality snapshot]',
            f"Readiness score: {readiness.get('score', 0)}/5",
            f"Missing readiness checks: {readiness.get('missing', 0)}",
            f"Audit score: {audit.get('audit_score', 0)}/100",
            f"Supported feature groups: {matrix.get('supported', 0)}/{matrix.get('total', 0)}",
            '',
            '[Before you start]',
            '1. Select the target mesh object and make sure it is the active object.',
            '2. Switch to Edit Mode before running topology-aware UV tools.',
            '3. Make sure at least one UV map exists when the tool expects UV data.',
            '4. Open UV Editor and 3D View together when checking seams, shells, or repair results.',
            '5. Run Context Scan or Prepare Basics first if the current setup is unclear.',
            '',
            '[Recommended compact workflow]',
            'A. Context & Setup -> scan the current scene context and prepare basics when needed.',
            'B. Quick Start -> unwrap, seam, relax, and pack the initial shells.',
            'C. Repair & Check -> inspect overlap, flips, and checker distortion before export.',
            'D. Maps & Output -> manage UV maps, atlas outputs, and snapshots.',
            'E. Audit & Reports -> review tool_runtime errors, audit score, and cleanup candidates.',
            '',
            '[When a tool fails]',
            '- Re-check active mesh, Edit Mode, UV map presence, and active editor type first.',
            '- Use the tool_runtime log and diagnostics text to identify repeated failing paths.',
            '- Use generated-data cleanup if old reports or helper assets are piling up.',
            '- If the same category fails often, inspect the operator catalog to find a safer alternative tool nearby.',
            '',
            '[Category guidance]',
            '- Unwrap & Relax: use for first-pass shell shape cleanup.',
            '- Projection & Mapping: use for fast starting layouts from camera or primitive directions.',
            '- Seams & Stitch: use when shell borders or cuts need to be adjusted deliberately.',
            '- Layout & Packing: use near the middle or end after shell shapes are mostly stable.',
            '- Selection & Analysis: use before repair, packing, baking, and export.',
            '- Density & Preview: use to verify consistency and visible distortion before finish.',
            '- UV Maps: use when one object needs separate bake, trim, lightmap, or export roles.',
            '- Symmetry & Atlas: use for mirrored parts and shared-output workflows.',
            '- Maintenance & Guidance: use when checking health, logs, reports, or workspace state.',
            '',
            '[Current follow-up hints]',
        ]
        hints = []
        if readiness.get('missing', 0):
            hints.append('Run Prepare Basics first so fewer tools fail on missing context.')
        if audit.get('tool_runtime_errors', 0):
            hints.append('Open the tool_runtime log and fix the highest-frequency errors before broad feature expansion.')
        if missing_groups:
            hints.append('Missing groups to design next: ' + ', '.join(missing_groups))
        if partial_groups:
            hints.append('Partial groups to deepen next: ' + ', '.join(partial_groups))
        if not hints:
            hints.append('The current guided state looks stable. Continue with operator-level fixes and workflow polish next.')
        for item in hints:
            lines.append(f'- {item}')
        lines.extend([
            '',
            '[日本語ガイド / Japanese quick guide]',
            '1. まず対象メッシュを選択し、必要ならアクティブ対象へ揃えます。',
            '2. トポロジー依存のUVツールは、編集モードで使います。',
            '3. UVマップが必要な処理では、先にUVマップを作成または有効化します。',
            '4. UVエディターと3Dビューを開いた状態で、確認系と修復系を進めます。',
            '5. 状態が不明な時は Context Scan または Prepare Basics を先に使います。',
            '6. 基本順は Context & Setup → Quick Start → Repair & Check → Maps & Output → Audit & Reports です。',
            '7. 失敗が出たら、アクティブ対象、編集モード、UVマップ、アクティブエディター、実行ログの順で確認します。',
        ])
        textio = _NAMESPACE.get('_quality_textio_module')
        writer = getattr(textio, 'write_report_lines_consistent', None) if textio is not None else None
        if callable(writer):
            txt = writer(
                _NAMESPACE, context, _text_name, lines, _text_block, self,
                open_after_write=self.open_after_write,
                failed_key='msg.quality_help_open_failed',
                failed_en='Could not open guided help: {name}',
                failed_ja='ガイドヘルプを開けませんでした: {name}',
            )
            if txt is None:
                return {'CANCELLED'}
        else:
            txt = _text_block(_text_name(context), clear=True)
            if txt is None:
                return {'CANCELLED'}
            txt.write('\n'.join(lines))
            if self.open_after_write:
                opener = _NAMESPACE.get('_suv_open_text_in_editor')
                if callable(opener):
                    try:
                        opener(context, txt)
                    except Exception:
                        pass
        msg = _tr(context, 'msg.quality_help_written', 'Guided help written: {name}', 'ガイドヘルプを書き出しました: {name}', name=txt.name)
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class SUV_OT_quality_open_guided_help(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_open_guided_help'
    bl_label = 'Open Guided Help'
    bl_description = 'Open the latest UV Suite guided-help text block in Blender Text Editor. / 最新の UV Suite ガイドヘルプテキストを Blender のテキストエディタで開きます。'
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        textio = _NAMESPACE.get('_quality_textio_module')
        if textio is not None and hasattr(textio, 'open_named_report_text_or_fallback'):
            return textio.open_named_report_text_or_fallback(
                _NAMESPACE, context, _text_name, self, _text_block,
                missing_key='msg.quality_help_missing',
                missing_en='No guided help text exists yet.',
                missing_ja='ガイドヘルプはまだ作成されていません。',
                opened_key='msg.quality_help_opened',
                opened_en='Opened guided help: {name}',
                opened_ja='ガイドヘルプを開きました: {name}',
            )
        txt = _text_block(_text_name(context), clear=False)
        if txt is None:
            self.report({'WARNING'}, _tr(context, 'msg.quality_help_missing', 'No guided help text exists yet.', 'ガイドヘルプはまだ作成されていません。'))
            return {'CANCELLED'}
        opener = _NAMESPACE.get('_suv_open_text_in_editor')
        ok = False
        if callable(opener):
            try:
                ok, _err = opener(context, txt)
            except Exception:
                ok = False
        if not ok:
            self.report({'WARNING'}, _tr(context, 'msg.quality_help_open_failed', 'Could not open guided help: {name}', 'ガイドヘルプを開けませんでした: {name}', name=txt.name))
            return {'CANCELLED'}
        msg = _tr(context, 'msg.quality_help_opened', 'Opened guided help: {name}', 'ガイドヘルプを開きました: {name}', name=txt.name)
        self.report({'INFO'}, msg)
        return {'FINISHED'}


def register(namespace: dict):
    global _NAMESPACE
    _NAMESPACE = namespace if isinstance(namespace, dict) else {}
    if bpy is None:
        return []
    classes = [SUV_OT_quality_write_guided_help, SUV_OT_quality_open_guided_help]
    reg = []
    for cls in classes:
        try:
            _suv_resource.register_class(cls)
            reg.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = reg
    return reg


def unregister(namespace: dict | None = None):
    if bpy is None:
        return []
    removed = []
    for cls in reversed(list(_REGISTERED)):
        try:
            _suv_resource.unregister_class(cls)
            removed.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = []
    return removed
