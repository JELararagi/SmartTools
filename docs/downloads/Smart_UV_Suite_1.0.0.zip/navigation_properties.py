# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations
from . import resource_api_18168 as _suv_resource

import hashlib
import sys
from typing import Iterable

import bpy

from . import text_translation as _text_translation

def _suv_ui_operator_prop_names(op) -> set[str]:
    names: set[str] = set()
    try:
        prop_defs = getattr(getattr(op, 'bl_rna', None), 'properties', None)
    except Exception:
        prop_defs = None
    try:
        names.update(str(k) for k in prop_defs.keys())
    except Exception:
        pass
    try:
        for prop in prop_defs or ():
            ident = str(getattr(prop, 'identifier', '') or '')
            if ident:
                names.add(ident)
    except Exception:
        pass
    return names


def _suv_safe_set_ui_operator_prop(op, prop_name: str, value) -> bool:
    prop_name = str(prop_name or '')
    if not op or not prop_name:
        return False
    try:
        if prop_name not in _suv_ui_operator_prop_names(op):
            return False
        setattr(op, prop_name, value)
        return True
    except Exception:
        return False



# Compatibility registry for legacy entry points.
# The active UI is a normal 3D View Sidebar N-panel: VIEW_3D + UI region +
# bl_category='Smart UV'. This module keeps old calls harmless and does not
# patch Blender regions, headers, navigation bars, or foreign panel poll functions.

_CATEGORY_OVERRIDES = {
    'smart_animation_suite': 'Smart Animation',
    'smart_cloth_suite': 'Smart Cloth',
    'smart_file_suite': 'Smart File',
    'smart_modeling_suite': 'Smart Modeling',
    'smart_modifier_suite': 'Smart Modifier',
    'smart_overlay_suite': 'Smart Overlay',
    'smart_paint_suite': 'Smart Paint',
    'smart_render_suite': 'Smart Render',
    'smart_rig_suite': 'Smart Rig',
    'smart_sculpt_suite': 'Smart Sculpt',
    'smart_selector_suite': 'Smart Selector',
    'smart_shader_suite': 'Smart Shader',
    'smart_shapekey_suite': 'Smart Shapekey',
    'smart_transform_suite': 'Smart Transform',
    'uv_suite': 'Smart UV',
    'smart_workspace_suite': 'Smart Workspace',
}

_LEGACY_OPEN_OPERATOR_IDS = {
    'smart_animation_suite': ('wm.smart_animation_suite_open_window_v250', 'wm.smart_animation_suite_open_window_light_v120'),
    'smart_cloth_suite': ('wm.smart_cloth_suite_open_window_v250', 'wm.smart_cloth_suite_boot_open_window_v360'),
    'smart_file_suite': ('wm.smart_file_suite_open_window_v250', 'wm.smart_file_suite_open_window'),
    'smart_modeling_suite': ('wm.smart_modeling_suite_open_window_v250',),
    'smart_modifier_suite': ('wm.smart_modifier_suite_open_window_v250',),
    'smart_overlay_suite': ('wm.smart_overlay_suite_open_window_v250',),
    'smart_paint_suite': ('wm.smart_paint_suite_open_window_v250',),
    'smart_render_suite': ('wm.smart_render_suite_open_window_v250',),
    'smart_rig_suite': ('wm.smart_rig_suite_open_window_v250', 'wm.smart_rig_suite_bootstrap_open_window'),
    'smart_sculpt_suite': ('wm.smart_sculpt_suite_open_window_v250',),
    'smart_selector_suite': ('wm.smart_selector_suite_open_window',),
    'smart_shader_suite': ('wm.smart_shader_suite_open_window', 'wm.smart_shader_suite_bootstrap_open'),
    'smart_shapekey_suite': ('wm.smart_shapekey_suite_open_window_v250',),
    'smart_transform_suite': ('wm.smart_transform_suite_open_window_v250',),
    'uv_suite': ('wm.uv_suite_open_window_v250',),
    'smart_workspace_suite': ('wm.smart_workspace_suite_open_window_v250', 'wm.smart_workspace_suite_bootstrap_open_window_v370'),
}

_REGISTRY = {
    'nav_entries': {},
    'panel_sources': {},
    'proxy_panels': {},
    'original_panel_polls': {},
    'launcher_callbacks': {},
    'launcher_draw_callbacks': {},
    'legacy_operators': {},
    'popup_operators': {},
    'preferred_owner': None,
    'active_owner': None,
    'shutdown': False,
    'tool_runtime_teardown': False,
}

_MISSING = object()
_STARTUP_SAFE_STUB = True



def _registry() -> dict:
    return _REGISTRY


def _safe_name(value: object, fallback: str = 'smart_tools') -> str:
    text = str(value or fallback).strip().lower()
    out = ''.join(ch if ch.isalnum() else '_' for ch in text)
    out = '_'.join(part for part in out.split('_') if part)
    return out or fallback


def _operator_safe_name(op_idname: str) -> str:
    return _safe_name(str(op_idname or '').replace('.', '_'), 'smart_tools_operator')


def _is_japanese_locale(context=None) -> bool:
    try:
        return bool(_text_translation.is_japanese(context))
    except Exception:
        pass
    try:
        prefs = getattr(context, 'preferences', None) if context is not None else None
    except Exception:
        prefs = None
    if prefs is None:
        try:
            prefs = getattr(getattr(bpy, 'context', None), 'preferences', None)
        except Exception:
            prefs = None
    try:
        language = str(getattr(getattr(prefs, 'view', None), 'language', '') or '').lower()
        if language and language != 'default':
            return language.startswith('ja')
    except Exception:
        pass
    try:
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '').lower()
        return locale.startswith('ja')
    except Exception:
        return False


def _text(en: str, ja: str, context=None) -> str:
    return str(ja if _is_japanese_locale(context) else en)




def _feature_toggle_module():
    try:
        import importlib
    except Exception:
        return None
    package = str(__package__ or __name__ or '').strip('.')
    candidates = []
    if package:
        candidates.append(package)
        if '.' in package:
            candidates.append(package.rsplit('.', 1)[0])
        parts = [part for part in package.split('.') if part]
        if 'user_default' in parts:
            idx = parts.index('user_default')
            if idx + 1 < len(parts):
                candidates.append('.'.join(parts[:idx + 2]))
        elif parts:
            candidates.append(parts[0])
    for base in candidates:
        try:
            return importlib.import_module(f'{base}.feature_toggle')
        except Exception:
            continue
    return None


def _draw_inline_feature_toggles(layout, context, addon_key: str) -> bool:
    module = _feature_toggle_module()
    draw = getattr(module, 'draw_inline_toggles', None) if module is not None else None
    if not callable(draw):
        return False
    try:
        return bool(draw(layout, context, str(addon_key or ''), compact=True))
    except Exception:
        return False


def _normalize_owner(addon_key: object) -> str:
    return str(addon_key or '').strip()


def _clean_label(value: object) -> str:
    text = str(value or '').replace('_', ' ').strip()
    while '  ' in text:
        text = text.replace('  ', ' ')
    for suffix in (' Toolset', ' suite', '_Toolset', '_suite'):
        if text.endswith(suffix):
            text = text[: -len(suffix)].strip()
    return text


def _category_for(addon_key: str, label: object = '') -> str:
    addon_key = _normalize_owner(addon_key)
    if addon_key in _CATEGORY_OVERRIDES:
        return _CATEGORY_OVERRIDES[addon_key]
    label_text = _clean_label(label)
    if label_text:
        return label_text
    if addon_key:
        return _clean_label(addon_key)
    return 'Smart Tools'


def _label_for(addon_key: str, label: object = '') -> str:
    return _category_for(addon_key, label)


def _is_registered_blender_class(cls: type) -> bool:
    if not isinstance(cls, type):
        return False
    try:
        return getattr(bpy.types, cls.__name__, None) is cls
    except Exception:
        return False


def _safe_register_class(cls: type) -> bool:
    if not isinstance(cls, type):
        return False
    try:
        existing = getattr(bpy.types, getattr(cls, '__name__', ''), None)
        if existing is cls:
            return True
        if isinstance(existing, type):
            try:
                _suv_resource.unregister_class(existing)
            except Exception:
                pass
    except Exception:
        pass
    try:
        if _is_registered_blender_class(cls):
            return True
    except Exception:
        pass
    try:
        _suv_resource.register_class(cls)
        return True
    except (RuntimeError, ValueError) as exc:
        message = str(exc).lower()
        if 'already registered' in message or 'register_class' in message:
            existing = getattr(bpy.types, cls.__name__, None)
            if isinstance(existing, type) and existing is not cls:
                try:
                    _suv_resource.unregister_class(existing)
                except Exception:
                    pass
                try:
                    _suv_resource.register_class(cls)
                    return True
                except Exception:
                    return False
            return _is_registered_blender_class(cls)
        return False
    except Exception:
        return False


def _safe_unregister_class(cls: type) -> None:
    if not isinstance(cls, type):
        return
    try:
        _suv_resource.unregister_class(cls)
    except Exception:
        pass


def _iter_valid_panel_classes(panel_classes) -> tuple[type, ...]:
    seen: set[type] = set()
    panels: list[type] = []
    base = getattr(bpy.types, 'Panel', None)
    for cls in tuple(panel_classes or ()):  # type: ignore[arg-type]
        if not isinstance(cls, type) or cls in seen:
            continue
        if base is not None:
            try:
                if not issubclass(cls, base):
                    continue
            except Exception:
                continue
        seen.add(cls)
        panels.append(cls)
    return tuple(panels)


def prepare_panel_classes(panel_classes, addon_key: str | None = None):
    del addon_key
    return _iter_valid_panel_classes(panel_classes)


def _stored_original_poll(panel_cls):
    for saved in tuple(_REGISTRY.get('original_panel_polls', {}).values()):
        if isinstance(saved, dict) and panel_cls in saved:
            return saved.get(panel_cls)
    return getattr(panel_cls, 'poll', _MISSING)


def _call_poll(raw_poll, panel_cls, context, default: bool = True) -> bool:
    if raw_poll is None or raw_poll is _MISSING:
        return bool(default)
    for call in (
        lambda: raw_poll(context),
        lambda: raw_poll(panel_cls, context),
        lambda: raw_poll.__func__(panel_cls, context),
    ):
        try:
            return bool(call())
        except TypeError:
            continue
        except Exception:
            return bool(default)
    return bool(default)


def _call_draw(draw_fn, panel_instance, context) -> bool:
    if not callable(draw_fn):
        return False
    for call in (
        lambda: draw_fn(panel_instance, context),
        lambda: draw_fn(context),
    ):
        try:
            call()
            return True
        except TypeError:
            continue
        except Exception:
            raise
    return False


def _make_panel_draw_shim(panel_cls, layout):
    shim_name = f'_SMARTTOOLS_NPANEL_SHIM_{_safe_name(getattr(panel_cls, "__name__", "panel"))}'
    attrs = {}
    for name, value in getattr(panel_cls, '__dict__', {}).items():
        if name.startswith('__'):
            continue
        if callable(value):
            attrs[name] = value
    shim_cls = type(shim_name, (), attrs)
    shim = shim_cls()
    try:
        shim.layout = layout
    except Exception:
        pass
    for name in ('bl_idname', 'bl_label', 'bl_space_type', 'bl_region_type', 'bl_context', 'bl_parent_id', 'bl_options', 'bl_category'):
        try:
            setattr(shim, name, getattr(panel_cls, name))
        except Exception:
            pass
    try:
        shim.is_popover = False
    except Exception:
        pass
    return shim


def _panel_can_draw_in_context(panel_cls, context) -> bool:
    raw_poll = _stored_original_poll(panel_cls)
    result = _call_poll(raw_poll, panel_cls, context, default=True)
    if result:
        return True
    try:
        return bool(getattr(panel_cls, '_smart_suite_npanel_proxy', False))
    except Exception:
        return False

def _draw_panel_class_fallback_contents(layout, context, panel_cls) -> bool:
    draw_fn = getattr(panel_cls, 'draw', None)
    if not callable(draw_fn):
        return False
    if not _panel_can_draw_in_context(panel_cls, context):
        return False
    try:
        col = layout.column(align=False)
    except Exception:
        col = layout
    try:
        col.use_property_split = False
        col.use_property_decorate = False
    except Exception:
        pass
    shim = _make_panel_draw_shim(panel_cls, col)
    try:
        return bool(_call_draw(draw_fn, shim, context))
    except Exception as exc:
        try:
            col.label(text=_text('Panel draw failed', 'パネル描画に失敗しました', context), icon='ERROR')
            col.label(text=str(exc)[:180], icon='BLANK1')
        except Exception:
            pass
        return False


def _ordered_panel_sources(addon_key: str) -> tuple[type, ...]:
    panels = list(_iter_valid_panel_classes(_REGISTRY.get('panel_sources', {}).get(str(addon_key), ()) or ()))
    indexed = list(enumerate(panels))
    indexed.sort(key=lambda item: (0 if not str(getattr(item[1], 'bl_parent_id', '') or '') else 1, item[0]))
    return tuple(cls for _index, cls in indexed)


def _draw_launcher_fallback_contents(layout, context, addon_key: str) -> int:
    drawn = 0
    for panel_cls in _ordered_panel_sources(addon_key):
        if drawn:
            try:
                layout.separator()
            except Exception:
                pass
        try:
            if _draw_panel_class_fallback_contents(layout, context, panel_cls):
                drawn += 1
        except Exception:
            continue
    return drawn


def _restore_original_panel_polls(addon_key: str) -> None:
    saved = _REGISTRY.get('original_panel_polls', {}).pop(str(addon_key), None)
    if not isinstance(saved, dict):
        return
    for cls, raw_poll in list(saved.items()):
        try:
            if raw_poll is _MISSING:
                try:
                    delattr(cls, 'poll')
                except Exception:
                    pass
            else:
                cls.poll = raw_poll
        except Exception:
            pass


def _hide_original_panels(addon_key: str, panel_classes) -> None:
    # Normal N-panel behavior: original panel poll functions are never replaced.
    del addon_key, panel_classes
    return None

def _release_proxy_panels(addon_key: str) -> None:
    for cls in reversed(tuple(_REGISTRY.get('proxy_panels', {}).pop(str(addon_key), ()) or ())) :
        _safe_unregister_class(cls)


def _make_draw_wrapper(orig_draw, addon_key=None, include_toggles=False):
    def _draw(self, context):
        try:
            if include_toggles:
                _draw_inline_feature_toggles(getattr(self, 'layout', None), context, str(addon_key or ''))
            _call_draw(orig_draw, self, context)
            return None
        except Exception as exc:
            layout = getattr(self, 'layout', None)
            if layout is not None:
                try:
                    layout.label(text=_text('Panel draw failed', 'パネル描画に失敗しました', context), icon='ERROR')
                    layout.label(text=str(exc)[:180], icon='BLANK1')
                except Exception:
                    pass
            return None
    return _draw


def _make_proxy_panel_classes(addon_key: str, label: str, panel_classes) -> tuple[type, ...]:
    # Legacy proxy panels are no longer generated. The real UV Suite panel is
    # registered directly as a standard 3D View Sidebar panel.
    del addon_key, label, panel_classes
    return tuple()

def _make_callback_panel_class(addon_key: str, label: str) -> type | None:
    # Callback-only host panels belonged to the removed shared host layer.
    del addon_key, label
    return None

def _rebuild_proxy_panels(addon_key: str) -> bool:
    # The suite now registers its real bpy.types.Panel classes directly in the
    # 3D View Sidebar.  Legacy proxy panels were a old shared-host bridge and
    # could inherit old shared-host behavior. They are intentionally
    # not rebuilt.
    addon_key = str(addon_key)
    _release_proxy_panels(addon_key)
    _restore_original_panel_polls(addon_key)
    _REGISTRY.setdefault('proxy_panels', {})[addon_key] = tuple()
    _tag_redraw_all_npanel_areas()
    return True

def install(addon_key: str, label: str, icon: str, operator_id: str, panel_classes, order: int = 0, **_kwargs) -> bool:
    addon_key = _normalize_owner(addon_key)
    if not addon_key:
        return False

    incoming_panels = prepare_panel_classes(panel_classes, addon_key)
    existing_panels = tuple(_REGISTRY.get('panel_sources', {}).get(addon_key, ()) or ())

    # Later compatibility wrappers sometimes call install(..., panel_classes=())
    # only to make sure the suite is present in the N-panel.  Do not let that
    # empty maintenance call overwrite a real UI tree that has already been
    # registered by the suite tool_runtime; otherwise the panel falls back to
    # "No settings are registered."
    if incoming_panels:
        panel_classes = incoming_panels
    elif existing_panels:
        panel_classes = existing_panels
    else:
        panel_classes = incoming_panels

    label = _label_for(addon_key, label)
    _REGISTRY.setdefault('panel_sources', {})[addon_key] = tuple(panel_classes)
    _REGISTRY.setdefault('nav_entries', {})[addon_key] = {
        'label': label,
        'icon': str(icon or ''),
        'operator_id': str(operator_id or ''),
        'button_operator_id': '',
        'order': int(order or 0),
        'category': _category_for(addon_key, label),
    }
    if not _REGISTRY.get('preferred_owner'):
        _REGISTRY['preferred_owner'] = addon_key
    _REGISTRY['active_owner'] = addon_key
    _REGISTRY['shutdown'] = False
    _REGISTRY['tool_runtime_teardown'] = False
    _ensure_legacy_open_operators(addon_key)
    _ensure_popup_operators()
    return _rebuild_proxy_panels(addon_key)


def refresh_tool_runtime(addon_key: str, label: str, icon: str, operator_id: str, panel_classes, order: int = 0, reopen_window: bool = False, **kwargs) -> bool:
    del reopen_window
    return install(addon_key, label, icon, operator_id, panel_classes, order=order, **kwargs)


def refresh_entry(addon_key: str, label: str, icon: str, operator_id: str, panel_classes, order: int = 0, **kwargs) -> bool:
    return install(addon_key, label, icon, operator_id, panel_classes, order=order, **kwargs)


def uninstall(addon_key: str, **_kwargs) -> bool:
    addon_key = _normalize_owner(addon_key)
    if not addon_key:
        return False
    _release_proxy_panels(addon_key)
    _restore_original_panel_polls(addon_key)
    _REGISTRY.get('nav_entries', {}).pop(addon_key, None)
    _REGISTRY.get('panel_sources', {}).pop(addon_key, None)
    _REGISTRY.get('launcher_callbacks', {}).pop(addon_key, None)
    _REGISTRY.get('launcher_draw_callbacks', {}).pop(addon_key, None)
    if _REGISTRY.get('preferred_owner') == addon_key:
        remaining = tuple(_REGISTRY.get('nav_entries', {}).keys())
        _REGISTRY['preferred_owner'] = remaining[0] if remaining else None
    if _REGISTRY.get('active_owner') == addon_key:
        _REGISTRY['active_owner'] = _REGISTRY.get('preferred_owner')
    _tag_redraw_all_npanel_areas()
    return True


def set_launcher_draw_callback(addon_key: str, callback) -> bool:
    # Retained for legacy callers. The callback is stored for compatibility but
    # is not materialized into a synthetic host/proxy panel.
    addon_key = _normalize_owner(addon_key)
    if not addon_key:
        return False
    if callable(callback):
        _REGISTRY.setdefault('launcher_callbacks', {})[addon_key] = callback
        _REGISTRY.setdefault('launcher_draw_callbacks', {})[addon_key] = callback
    else:
        _REGISTRY.setdefault('launcher_callbacks', {}).pop(addon_key, None)
        _REGISTRY.setdefault('launcher_draw_callbacks', {}).pop(addon_key, None)
    _tag_redraw_all_npanel_areas()
    return True

def clear_launcher_draw_callback(addon_key: str) -> bool:
    return set_launcher_draw_callback(addon_key, None)


def is_active(context=None, addon_key: str = '') -> bool:
    del context
    addon_key = _normalize_owner(addon_key)
    if not addon_key:
        return True
    if addon_key in _REGISTRY.get('nav_entries', {}):
        return True
    active = _normalize_owner(_REGISTRY.get('active_owner'))
    return not active or active == addon_key


def set_active_owner(context=None, addon_key: str | None = None) -> None:
    del context
    addon_key = _normalize_owner(addon_key)
    _REGISTRY['active_owner'] = addon_key or None
    if addon_key:
        _REGISTRY['preferred_owner'] = addon_key
    _tag_redraw_all_npanel_areas()


def clear_active_owner(addon_key: str = '') -> None:
    addon_key = _normalize_owner(addon_key)
    if not addon_key or _REGISTRY.get('active_owner') == addon_key:
        _REGISTRY['active_owner'] = None
    if addon_key and _REGISTRY.get('preferred_owner') == addon_key:
        _REGISTRY['preferred_owner'] = None
    _tag_redraw_all_npanel_areas()


def toggle_active(context=None, addon_key: str = '') -> None:
    set_active_owner(context, addon_key)


def tool_runtime_needs_refresh(addon_key: str = '') -> bool:
    addon_key = _normalize_owner(addon_key)
    if not addon_key:
        return not bool(_REGISTRY.get('nav_entries'))
    return addon_key not in _REGISTRY.get('nav_entries', {})

def tool_runtime_has_existing_host_candidates(addon_key: str = '') -> bool:
    del addon_key
    return False

def force_tool_runtime_refresh(preferred_owner: str | None = None, **_kwargs) -> bool:
    if preferred_owner:
        set_active_owner(getattr(bpy, 'context', None), preferred_owner)
    for owner in tuple(_REGISTRY.get('nav_entries', {}).keys()):
        _rebuild_proxy_panels(owner)
    return True


def refresh_ui_runtime(context=None, addon_key: str | None = None, activate_if_properties: bool = False, **_kwargs) -> bool:
    del activate_if_properties
    if addon_key:
        set_active_owner(context, addon_key)
    return force_tool_runtime_refresh(addon_key)


def sync_live_tool_runtime_from_prefs(context=None) -> bool:
    del context
    return force_tool_runtime_refresh()


def ensure_shared_nav_button_operators() -> bool:
    for owner in tuple(_REGISTRY.get('nav_entries', {}).keys()) or tuple(_CATEGORY_OVERRIDES.keys()):
        _ensure_legacy_open_operators(owner)
    _ensure_popup_operators()
    return True


def begin_addon_shutdown() -> None:
    _REGISTRY['shutdown'] = True


def finish_addon_shutdown() -> None:
    _REGISTRY['shutdown'] = False


def shutdown_tool_runtime() -> None:
    _REGISTRY['shutdown'] = True
    for owner in tuple(_REGISTRY.get('nav_entries', {}).keys()):
        uninstall(owner)


def is_shutting_down() -> bool:
    return bool(_REGISTRY.get('shutdown'))


def tool_runtime_is_shutdown() -> bool:
    return bool(_REGISTRY.get('shutdown'))


def _set_tool_runtime_teardown(value: bool = True) -> None:
    _REGISTRY['tool_runtime_teardown'] = bool(value)
    _REGISTRY['shutdown'] = bool(value)


def is_smart_tools_context(context=None) -> bool:
    return _is_smart_tools_context(context)


def _is_smart_tools_context(context=None) -> bool:
    context = context or getattr(bpy, 'context', None)
    area = getattr(context, 'area', None)
    region = getattr(context, 'region', None)
    if area is None:
        return True
    if str(getattr(area, 'type', '') or '') != 'VIEW_3D':
        return False
    if region is not None and str(getattr(region, 'type', '') or '') != 'UI':
        return False
    return True

def _tag_redraw_all_npanel_areas() -> None:
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    except Exception:
        wm = None
    for window in getattr(wm, 'windows', ()) if wm is not None else ():
        screen = getattr(window, 'screen', None)
        for area in getattr(screen, 'areas', ()) if screen is not None else ():
            try:
                if str(getattr(area, 'type', '') or '') == 'VIEW_3D':
                    area.tag_redraw()
            except Exception:
                pass

def _tag_redraw_all_legacy_areas() -> None:
    _tag_redraw_all_npanel_areas()


def _tag_redraw_host_windows() -> None:
    _tag_redraw_all_npanel_areas()


def _tag_redraw_window_menu_areas() -> None:
    _tag_redraw_all_npanel_areas()


def flush_redraws() -> None:
    _tag_redraw_all_npanel_areas()


def _verified_host_window_keys() -> tuple:
    return ()


def _ensure_host_watch_timer() -> bool:
    return False


def _install_window_menu_entry(*_args, **_kwargs) -> bool:
    return False


def _remove_window_menu_entry_if_unused(*_args, **_kwargs) -> None:
    return None


def _schedule_window_menu_refresh(*_args, **_kwargs) -> None:
    return None


def schedule_shared_window_menu_button_refresh(*_args, **_kwargs) -> None:
    return None


def repair_live_hosts_and_menu(context=None, *, reopen_window: bool = False) -> bool:
    del context, reopen_window
    _tag_redraw_all_npanel_areas()
    return True

def _install_header_draw_wrapper(*_args, **_kwargs):
    return False


def _install_context_header_overlay(*_args, **_kwargs):
    return False


def _install_navigation_bar_draw_wrapper(*_args, **_kwargs):
    return False


def _install_render_context_draw_wrapper(*_args, **_kwargs):
    return False


def _install_foreign_panel_hider(*_args, **_kwargs):
    return False


def _ensure_tool_runtime_hooks(*_args, **_kwargs):
    return True


def _smart_tools_light_activate_tool_runtime(context=None):
    del context
    return force_tool_runtime_refresh()


def open_smart_tools_window(context=None, preferred_owner: str | None = None, reuse_existing: bool = True) -> bool:
    # Legacy name kept for compatibility. It no longer opens or emulates a
    # old shared host; it simply focuses the normal UV Suite
    # N-panel owner and requests a redraw.
    del reuse_existing
    if preferred_owner:
        set_active_owner(context, preferred_owner)
    _tag_redraw_all_npanel_areas()
    return True

def open_or_reuse_smart_tools_window(context=None, reuse_existing: bool = True, preferred_owner: str | None = None) -> bool:
    return open_smart_tools_window(context=context, preferred_owner=preferred_owner, reuse_existing=reuse_existing)


_open_or_reuse_smart_tools_window = open_or_reuse_smart_tools_window


def invoke_props_dialog_preferred_window(operator, context, width: int = 420):
    try:
        return context.window_manager.invoke_props_dialog(operator, width=int(width or 420))
    except Exception:
        return {'CANCELLED'}


def invoke_props_dialog_outside_smart_tools(operator, context, width: int = 420):
    return invoke_props_dialog_preferred_window(operator, context, width=width)


def invoke_popup_outside_smart_tools(operator, context, width: int = 280):
    try:
        return context.window_manager.invoke_popup(operator, width=int(width or 280))
    except Exception:
        return {'CANCELLED'}


def _ensure_host_window_popup_capacity(*_args, **_kwargs) -> bool:
    return True


def _operator_callable(operator_idname: str):
    text = str(operator_idname or '').strip()
    if '.' not in text:
        return None
    group, name = text.split('.', 1)
    try:
        return getattr(getattr(bpy.ops, group), name)
    except Exception:
        return None


def _operator_enum_items(operator_idname: str, property_idname: str):
    op_fn = _operator_callable(operator_idname)
    if op_fn is None:
        return []
    try:
        rna = op_fn.get_rna_type()
    except Exception:
        rna = None
    try:
        prop_rna = rna.properties.get(str(property_idname or '')) if rna is not None else None
    except Exception:
        prop_rna = None
    out = []
    for item in getattr(prop_rna, 'enum_items', ()) or ():
        identifier = str(getattr(item, 'identifier', '') or '').strip()
        if not identifier:
            continue
        out.append({
            'identifier': identifier,
            'name': str(getattr(item, 'name', '') or identifier),
            'description': str(getattr(item, 'description', '') or ''),
        })
    return out


def _module_operator_prefix() -> str:
    package = str(__package__ or __name__ or 'smart_tools').strip('.')
    parts = [part for part in package.split('.') if part]
    if 'user_default' in parts:
        index = parts.index('user_default')
        if index + 1 < len(parts):
            return _safe_name(parts[index + 1])
    if parts and parts[0] == 'bl_ext' and len(parts) >= 3:
        return _safe_name(parts[2])
    if parts:
        return _safe_name(parts[0])
    return 'smart_tools'

def _ensure_popup_operators() -> None:
    if _REGISTRY.get('popup_operators'):
        return
    prefix = _module_operator_prefix()

    class_name = f'{prefix.upper()}_OT_npanel_popup_menu'
    menu_id = f'wm.{prefix}_npanel_popup_menu'

    def menu_invoke(self, context, event):
        del event
        try:
            return context.window_manager.invoke_popup(self, width=max(220, int(getattr(self, 'popup_width', 440) or 440)))
        except Exception:
            return {'CANCELLED'}

    def menu_draw(self, context):
        layout = self.layout
        menu_idname = str(getattr(self, 'menu_idname', '') or '')
        if not menu_idname:
            pass  # INFO-note moved to Help; no in-section info-icon explanation.
            return
        menu_contents = getattr(layout, 'menu_contents', None)
        if callable(menu_contents):
            try:
                menu_contents(menu_idname)
                return
            except Exception:
                pass
        op = layout.operator('wm.call_menu', text=str(getattr(self, 'popup_label', '') or menu_idname), icon='DOWNARROW_HLT')
        _suv_safe_set_ui_operator_prop(op, 'name', menu_idname)

    menu_cls = type(class_name, (bpy.types.Operator,), {
        '__module__': __name__,
        'bl_idname': menu_id,
        'bl_label': 'N-panel Menu',
        'bl_description': 'Open this menu from the Smart Tools N-panel.',
        'bl_options': {'INTERNAL'},
        '__annotations__': {
            'menu_idname': bpy.props.StringProperty(options={'HIDDEN'}),
            'popup_label': bpy.props.StringProperty(options={'HIDDEN'}),
            'popup_width': bpy.props.IntProperty(default=440, min=220, max=2000, options={'HIDDEN'}),
            'popup_rows': bpy.props.IntProperty(default=18, min=4, max=64, options={'HIDDEN'}),
        },
        'invoke': menu_invoke,
        'draw': menu_draw,
    })
    _safe_register_class(menu_cls)

    enum_class_name = f'{prefix.upper()}_OT_npanel_operator_enum_popup'
    enum_id = f'wm.{prefix}_npanel_operator_enum_popup'

    def enum_invoke(self, context, event):
        del event
        try:
            return context.window_manager.invoke_popup(self, width=max(220, int(getattr(self, 'popup_width', 440) or 440)))
        except Exception:
            return {'CANCELLED'}

    def enum_draw(self, context):
        layout = self.layout
        op_id = str(getattr(self, 'operator_idname', '') or '')
        prop_id = str(getattr(self, 'property_idname', '') or '')
        items = _operator_enum_items(op_id, prop_id)
        if not items:
            pass  # INFO-note moved to Help; no in-section info-icon explanation.
            return
        col = layout.column(align=True)
        for item in items:
            try:
                op = col.operator(op_id, text=str(item.get('name') or item.get('identifier') or 'Item'))
                _suv_safe_set_ui_operator_prop(op, prop_id, str(item.get('identifier') or ''))
            except Exception:
                pass  # INFO-note moved to Help; no in-section info-icon explanation.

    enum_cls = type(enum_class_name, (bpy.types.Operator,), {
        '__module__': __name__,
        'bl_idname': enum_id,
        'bl_label': 'N-panel List',
        'bl_description': 'Open operator choices from the Smart Tools N-panel.',
        'bl_options': {'INTERNAL'},
        '__annotations__': {
            'operator_idname': bpy.props.StringProperty(options={'HIDDEN'}),
            'property_idname': bpy.props.StringProperty(options={'HIDDEN'}),
            'popup_label': bpy.props.StringProperty(options={'HIDDEN'}),
            'popup_width': bpy.props.IntProperty(default=440, min=220, max=2000, options={'HIDDEN'}),
            'popup_rows': bpy.props.IntProperty(default=0, min=0, max=64, options={'HIDDEN'}),
        },
        'invoke': enum_invoke,
        'draw': enum_draw,
    })
    _safe_register_class(enum_cls)

    pie_class_name = f'{prefix.upper()}_OT_npanel_call_menu_pie'
    pie_id = f'wm.{prefix}_npanel_call_menu_pie'

    def pie_execute(self, context):
        del context
        menu_idname = str(getattr(self, 'menu_idname', '') or '')
        if not menu_idname:
            return {'CANCELLED'}
        try:
            return bpy.ops.wm.call_menu_pie('INVOKE_DEFAULT', name=menu_idname)
        except Exception:
            return {'CANCELLED'}

    pie_cls = type(pie_class_name, (bpy.types.Operator,), {
        '__module__': __name__,
        'bl_idname': pie_id,
        'bl_label': 'N-panel Pie Menu',
        'bl_description': 'Open this pie menu from the Smart Tools N-panel.',
        'bl_options': {'INTERNAL'},
        '__annotations__': {
            'menu_idname': bpy.props.StringProperty(options={'HIDDEN'}),
            'popup_label': bpy.props.StringProperty(options={'HIDDEN'}),
            'popup_width': bpy.props.IntProperty(default=640, min=220, max=2000, options={'HIDDEN'}),
            'popup_rows': bpy.props.IntProperty(default=18, min=4, max=64, options={'HIDDEN'}),
        },
        'execute': pie_execute,
    })
    _safe_register_class(pie_cls)
    _REGISTRY['popup_operators'] = {'menu': menu_cls, 'enum': enum_cls, 'pie': pie_cls}


def popup_menu_operator_id() -> str:
    _ensure_popup_operators()
    cls = _REGISTRY.get('popup_operators', {}).get('menu')
    return str(getattr(cls, 'bl_idname', '') or '')


def popup_operator_enum_operator_id() -> str:
    _ensure_popup_operators()
    cls = _REGISTRY.get('popup_operators', {}).get('enum')
    return str(getattr(cls, 'bl_idname', '') or '')


def popup_menu_pie_proxy_operator_id() -> str:
    _ensure_popup_operators()
    cls = _REGISTRY.get('popup_operators', {}).get('pie')
    return str(getattr(cls, 'bl_idname', '') or '')


def _ensure_legacy_open_operators(addon_key: str) -> None:
    addon_key = _normalize_owner(addon_key)
    ids = _LEGACY_OPEN_OPERATOR_IDS.get(addon_key, ())
    if not ids:
        return
    for operator_id in ids:
        if operator_id in _REGISTRY.get('legacy_operators', {}):
            continue
        if '.' not in operator_id:
            continue
        class_name = f'{_operator_safe_name(operator_id).upper()}_OT_npanel_compat'

        def _execute(self, context, _owner=addon_key):
            open_smart_tools_window(context=context, preferred_owner=_owner, reuse_existing=True)
            try:
                self.report({'INFO'}, _text('UV Suite settings are available in the N-panel.', 'UV Suite 設定はNパネルに表示されています。', context))
            except Exception:
                pass
            return {'FINISHED'}

        cls = type(class_name, (bpy.types.Operator,), {
            '__module__': __name__,
            'bl_idname': operator_id,
            'bl_label': _category_for(addon_key),
            'bl_description': 'Show the UV Suite settings in the N-panel.',
            'bl_options': {'INTERNAL'},
            # No RNA property is required; this compatibility operator only
            # forwards users to the standard N-panel. Avoid hidden operator
            # properties here so Blender hot-reload cannot fail on stale RNA.
            '__annotations__': {},
            'execute': _execute,
        })
        if _safe_register_class(cls):
            _REGISTRY.setdefault('legacy_operators', {})[operator_id] = cls


def is_startup_safe_stub() -> bool:
    return True


def describe_startup_behavior() -> str:
    return 'UV Suite settings are shown in the standard 3D View N-panel.'


# Bootstrap/window-menu compatibility names retained as no-ops so older callers
# do not fail while the standard N-panel registration is used.
install_window_menu_entry = lambda *args, **kwargs: ()
remove_window_menu_entry = lambda *args, **kwargs: None
remove_window_menu_entry_if_unused = lambda *args, **kwargs: None
schedule_window_menu_refresh = lambda *args, **kwargs: None


__all__ = (
    '_call_poll',
    '_draw_launcher_fallback_contents',
    '_draw_panel_class_fallback_contents',
    '_ensure_host_watch_timer',
    '_ensure_host_window_popup_capacity',
    '_is_smart_tools_context',
    '_make_panel_draw_shim',
    '_open_or_reuse_smart_tools_window',
    '_registry',
    '_set_tool_runtime_teardown',
    '_smart_tools_light_activate_tool_runtime',
    '_tag_redraw_all_legacy_areas',
    '_tag_redraw_host_windows',
    '_verified_host_window_keys',
    'begin_addon_shutdown',
    'clear_active_owner',
    'clear_launcher_draw_callback',
    'describe_startup_behavior',
    'ensure_shared_nav_button_operators',
    'finish_addon_shutdown',
    'flush_redraws',
    'force_tool_runtime_refresh',
    'install',
    'invoke_popup_outside_smart_tools',
    'invoke_props_dialog_outside_smart_tools',
    'invoke_props_dialog_preferred_window',
    'is_active',
    'is_shutting_down',
    'is_smart_tools_context',
    'is_startup_safe_stub',
    'open_or_reuse_smart_tools_window',
    'open_smart_tools_window',
    'popup_menu_operator_id',
    'popup_menu_pie_proxy_operator_id',
    'popup_operator_enum_operator_id',
    'prepare_panel_classes',
    'refresh_entry',
    'refresh_tool_runtime',
    'refresh_ui_runtime',
    'repair_live_hosts_and_menu',
    'tool_runtime_has_existing_host_candidates',
    'tool_runtime_is_shutdown',
    'tool_runtime_needs_refresh',
    'schedule_shared_window_menu_button_refresh',
    'set_active_owner',
    'set_launcher_draw_callback',
    'shutdown_tool_runtime',
    'sync_live_tool_runtime_from_prefs',
    'toggle_active',
    'uninstall',
)
