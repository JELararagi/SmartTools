from __future__ import annotations


def _button(namespace: dict, translate, context, cls_name: str, key: str, en: str, ja: str, icon: str = 'NONE', props: dict | None = None):
    cls = namespace.get(cls_name)
    if cls is None:
        return None
    bl_idname = getattr(cls, 'bl_idname', '')
    if not bl_idname:
        return None
    return {
        'cls': cls,
        'text': translate(context, key, en, ja),
        'icon': icon,
        'props': props or None,
    }


def _card(namespace: dict, translate, context, card_id: str, title_en: str, title_ja: str, buttons: list):
    filtered = [btn for btn in buttons if btn is not None]
    if not filtered:
        return None
    return {
        'id': card_id,
        'title': translate(context, card_id, title_en, title_ja),
        'buttons': filtered,
    }


def _raw_sections(namespace: dict, context, translate):
    workflow_cards = [
        _card(namespace, translate, context, 'ui.visual.quick_start', 'Quick Start', 'クイックスタート', [
            _button(namespace, translate, context, 'SUV_OT_auto_unwrap_pro', 'ui.visual.auto_unwrap', 'Auto Unwrap', '自動展開', 'MOD_UVPROJECT'),
            _button(namespace, translate, context, 'SUV_OT_apply_workflow_preset', 'ui.visual.repair_quick', 'Quick Repair', 'クイック修復', 'TOOL_SETTINGS', {'preset': 'REPAIR'}),
            _button(namespace, translate, context, 'SUV_OT_native_stage_preview', 'ui.visual.checker_preview', 'Checker Preview', 'チェッカープレビュー', 'TEXTURE', {'mode': 'CHECKER'}),
            _button(namespace, translate, context, 'SUV_OT_apply_layout_preset', 'ui.visual.pack_ready', 'Pack Ready', 'パック準備', 'PACKAGE', {'preset': 'PACK'}),
        ]),
        _card(namespace, translate, context, 'ui.visual.context_setup', 'Context & Setup', 'コンテキストと準備', [
            _button(namespace, translate, context, 'SUV_OT_quality_scan_context_readiness', 'ui.visual.scan_context', 'Scan context', 'コンテキスト確認', 'VIEWZOOM'),
            _button(namespace, translate, context, 'SUV_OT_quality_prepare_context_basics', 'ui.visual.prepare_context', 'Prepare basics', '基本準備', 'TOOL_SETTINGS'),
            _button(namespace, translate, context, 'SUV_OT_uvmap_add', 'ui.visual.add_uv_map', 'Add UV map', 'UVマップ追加', 'GROUP_UVS'),
            _button(namespace, translate, context, 'SUV_OT_workspace_auto_repair', 'ui.visual.repair_workspace', 'Repair workspace', 'ワークスペース修復', 'FILE_REFRESH'),
        ]),
        _card(namespace, translate, context, 'ui.visual.execution_profiles', 'Execution Profiles', '実行プロファイル', [
            _button(namespace, translate, context, 'SUV_OT_quality_write_execution_profiles', 'ui.visual.write_profiles', 'Write execution profiles', '実行プロファイル作成', 'LOCKVIEW_ON'),
            _button(namespace, translate, context, 'SUV_OT_quality_open_execution_profiles', 'ui.visual.open_profiles', 'Open execution profiles', '実行プロファイルを開く', 'TEXT'),
            _button(namespace, translate, context, 'SUV_OT_quality_scan_context_readiness', 'ui.visual.scan_context', 'Scan context', 'コンテキスト確認', 'VIEWZOOM'),
            _button(namespace, translate, context, 'SUV_OT_quality_prepare_context_basics', 'ui.visual.prepare_context', 'Prepare basics', '基本準備', 'TOOL_SETTINGS'),
        ]),
        _card(namespace, translate, context, 'ui.visual.task_playbooks', 'Task Playbooks', 'タスク別プレイブック', [
            _button(namespace, translate, context, 'SUV_OT_quality_write_task_playbook', 'ui.visual.write_playbook', 'Write task playbook', 'タスク別プレイブック作成', 'SEQ_SEQUENCER'),
            _button(namespace, translate, context, 'SUV_OT_quality_open_task_playbook', 'ui.visual.open_playbook', 'Open task playbook', 'タスク別プレイブックを開く', 'TEXT'),
            _button(namespace, translate, context, 'SUV_OT_quality_prepare_context_basics', 'ui.visual.prepare_context', 'Prepare basics', '基本準備', 'TOOL_SETTINGS'),
            _button(namespace, translate, context, 'SUV_OT_quality_write_guided_help', 'ui.visual.write_help', 'Write guided help', 'ガイドヘルプ作成', 'HELP'),
        ]),
        _card(namespace, translate, context, 'ui.visual.doctor_card', 'Doctor & Actions', 'ドクターと対処', [
            _button(namespace, translate, context, 'SUV_OT_quality_write_doctor_report', 'ui.visual.write_doctor', 'Write quality doctor', '品質ドクター作成', 'LIGHT'),
            _button(namespace, translate, context, 'SUV_OT_quality_open_doctor_report', 'ui.visual.open_doctor', 'Open quality doctor', '品質ドクターを開く', 'TEXT'),
            _button(namespace, translate, context, 'SUV_OT_quality_prepare_context_basics', 'ui.visual.prepare_context', 'Prepare basics', '基本準備', 'TOOL_SETTINGS'),
            _button(namespace, translate, context, 'SUV_OT_quality_scan_generated_data', 'ui.visual.scan_cleanup', 'Scan cleanup', 'クリーンアップ確認', 'VIEWZOOM'),
        ]),
    ]

    learning_cards = [
        _card(namespace, translate, context, 'ui.visual.coverage_guides', 'Coverage & Guides', '対応範囲とガイド', [
            _button(namespace, translate, context, 'SUV_OT_quality_scan_feature_matrix', 'ui.visual.run_matrix', 'Build feature matrix', '機能マトリクス作成', 'SEQ_STRIP_DUPLICATE'),
            _button(namespace, translate, context, 'SUV_OT_quality_open_feature_matrix', 'ui.visual.open_matrix', 'Open feature matrix', '機能マトリクスを開く', 'TEXT'),
            _button(namespace, translate, context, 'SUV_OT_quality_audit_suite', 'ui.visual.run_audit', 'Run quality audit', '品質監査を実行', 'FILE_TEXT'),
            _button(namespace, translate, context, 'SUV_OT_quality_open_audit_text', 'ui.visual.open_audit', 'Open audit report', '監査レポートを開く', 'TEXT'),
        ]),
        _card(namespace, translate, context, 'ui.visual.language_tips', 'Language & Tips', '言語と説明', [
            _button(namespace, translate, context, 'SUV_OT_quality_write_language_coverage', 'ui.visual.run_language', 'Write language coverage', '言語対応レポート作成', 'WORLD'),
            _button(namespace, translate, context, 'SUV_OT_quality_open_language_coverage', 'ui.visual.open_language', 'Open language coverage', '言語対応レポートを開く', 'TEXT'),
            _button(namespace, translate, context, 'SUV_OT_quality_write_guided_help', 'ui.visual.write_help', 'Write guided help', 'ガイドヘルプ作成', 'HELP'),
            _button(namespace, translate, context, 'SUV_OT_quality_write_operator_catalog', 'ui.visual.write_catalog', 'Write operator catalog', 'オペレーターカタログ作成', 'FILE_TEXT'),
        ]),
        _card(namespace, translate, context, 'ui.visual.help_catalog', 'Help & Catalog', 'ヘルプとカタログ', [
            _button(namespace, translate, context, 'SUV_OT_quality_write_guided_help', 'ui.visual.write_help', 'Write guided help', 'ガイドヘルプ作成', 'HELP'),
            _button(namespace, translate, context, 'SUV_OT_quality_open_guided_help', 'ui.visual.open_help', 'Open guided help', 'ガイドヘルプを開く', 'TEXT'),
            _button(namespace, translate, context, 'SUV_OT_quality_write_operator_catalog', 'ui.visual.write_catalog', 'Write operator catalog', 'オペレーターカタログ作成', 'FILE_TEXT'),
            _button(namespace, translate, context, 'SUV_OT_quality_open_operator_catalog', 'ui.visual.open_catalog', 'Open operator catalog', 'オペレーターカタログを開く', 'TEXT'),
        ]),
        _card(namespace, translate, context, 'ui.visual.ui_map', 'Visual UI Map', '視覚UIマップ', [
            _button(namespace, translate, context, 'SUV_OT_quality_write_ui_map', 'ui.visual.write_ui_map', 'Write visual UI map', '視覚UIマップ作成', 'MENU_PANEL'),
            _button(namespace, translate, context, 'SUV_OT_quality_open_ui_map', 'ui.visual.open_ui_map', 'Open visual UI map', '視覚UIマップを開く', 'TEXT'),
            _button(namespace, translate, context, 'SUV_OT_quality_open_guided_help', 'ui.visual.open_help', 'Open guided help', 'ガイドヘルプを開く', 'HELP'),
            _button(namespace, translate, context, 'SUV_OT_quality_open_operator_catalog', 'ui.visual.open_catalog', 'Open operator catalog', 'オペレーターカタログを開く', 'FILE_TEXT'),
        ]),
    ]

    maintenance_cards = [
        _card(namespace, translate, context, 'ui.visual.audit_reports', 'Audit & Reports', '監査とレポート', [
            _button(namespace, translate, context, 'SUV_OT_quality_audit_suite', 'ui.visual.run_audit', 'Run quality audit', '品質監査を実行', 'FILE_TEXT'),
            _button(namespace, translate, context, 'SUV_OT_quality_open_audit_text', 'ui.visual.open_audit', 'Open audit report', '監査レポートを開く', 'TEXT'),
            _button(namespace, translate, context, 'SUV_OT_quality_write_controls_report', 'ui.visual.write_controls_report', 'Write controls report', '視覚コントロールレポート作成', 'OPTIONS'),
            _button(namespace, translate, context, 'SUV_OT_quality_open_controls_report', 'ui.visual.open_controls_report', 'Open controls report', '視覚コントロールレポートを開く', 'TEXT'),
            _button(namespace, translate, context, 'SUV_OT_quality_write_report_hub', 'ui.visual.write_report_hub', 'Write report hub', 'レポートハブ作成', 'FILE_TEXT'),
            _button(namespace, translate, context, 'SUV_OT_quality_open_report_hub', 'ui.visual.open_report_hub', 'Open report hub', 'レポートハブを開く', 'TEXT'),
        ]),
        _card(namespace, translate, context, 'ui.visual.report_registry', 'Registry & Cleanup', 'レジストリと整理', [
            _button(namespace, translate, context, 'SUV_OT_quality_write_report_registry', 'ui.visual.write_registry', 'Write report registry', 'レポートレジストリ作成', 'FILE_TEXT'),
            _button(namespace, translate, context, 'SUV_OT_quality_open_report_registry', 'ui.visual.open_registry', 'Open report registry', 'レポートレジストリを開く', 'TEXT'),
            _button(namespace, translate, context, 'SUV_OT_quality_scan_generated_data', 'ui.visual.scan_cleanup', 'Scan cleanup', 'クリーンアップ確認', 'VIEWZOOM'),
            _button(namespace, translate, context, 'SUV_OT_quality_cleanup_generated_data', 'ui.visual.run_cleanup', 'Run cleanup', 'クリーンアップ実行', 'TRASH'),
            _button(namespace, translate, context, 'SUV_OT_quality_clear_status_cache', 'ui.visual.clear_state_cache', 'Clear status cache', '状態キャッシュ消去', 'FILE_REFRESH'),
        ]),
        _card(namespace, translate, context, 'ui.visual.cleanup', 'Diagnostics & Cleanup', '診断とクリーンアップ', [
            _button(namespace, translate, context, 'SUV_OT_clear_tool_runtime_log', 'ui.visual.clear_tool_runtime_log', 'Clear tool_runtime log', '実行ログ消去', 'TRASH'),
            _button(namespace, translate, context, 'SUV_OT_clear_batch_report', 'ui.visual.clear_batch_report', 'Clear batch report', 'バッチレポート消去', 'TRASH'),
            _button(namespace, translate, context, 'SUV_OT_reload_custom_icons', 'ui.visual.reload_icons', 'Reload icons', 'アイコン再読込', 'FILE_REFRESH'),
            _button(namespace, translate, context, 'SUV_OT_workspace_reset', 'ui.visual.reset_workspace', 'Reset workspace', 'ワークスペース初期化', 'LOOP_BACK'),
        ]),
        _card(namespace, translate, context, 'ui.visual.maintenance', 'Maintenance & Recovery', '保守と復旧', [
            _button(namespace, translate, context, 'SUV_OT_write_support_bundle', 'ui.visual.write_support_bundle', 'Write support bundle', 'サポートバンドル出力', 'FILE_TEXT'),
            _button(namespace, translate, context, 'SUV_OT_copy_diagnostics_text', 'ui.visual.copy_diagnostics', 'Copy diagnostics', '診断コピー', 'COPYDOWN'),
            _button(namespace, translate, context, 'SUV_OT_workspace_validate', 'ui.visual.validate_workspace', 'Validate workspace', 'ワークスペース検証', 'CHECKMARK'),
            _button(namespace, translate, context, 'SUV_OT_workspace_auto_repair', 'ui.visual.auto_repair_workspace', 'Auto repair workspace', 'ワークスペース自動修復', 'TOOL_SETTINGS'),
            _button(namespace, translate, context, 'SUV_OT_write_tool_runtime_snapshot', 'ui.visual.generate_snapshot', 'Generate snapshot', 'スナップショット生成', 'TEXT'),
            _button(namespace, translate, context, 'SUV_OT_open_diagnostics_text', 'ui.visual.open_diagnostics', 'Open diagnostics', '診断を開く', 'TEXT'),
        ]),
    ]

    return [
        {'id': 'workflow', 'title': translate(context, 'ui.visual.section_workflow', 'Workflow & Setup', 'ワークフローと準備'), 'icon': 'TOOL_SETTINGS', 'cards': [card for card in workflow_cards if card]},
        {'id': 'learning', 'title': translate(context, 'ui.visual.section_learning', 'Guides & Language', 'ガイドと言語'), 'icon': 'BOOKMARKS', 'cards': [card for card in learning_cards if card]},
        {'id': 'maintenance', 'title': translate(context, 'ui.visual.section_maintenance', 'Reports & Maintenance', 'レポートと保守'), 'icon': 'FILE_TEXT', 'cards': [card for card in maintenance_cards if card]},
    ]


def _apply_section_visibility(namespace: dict, context, sections: list[dict]) -> dict:
    section_mod = namespace.get('_quality_sections_module')
    if section_mod is not None and hasattr(section_mod, 'apply_section_visibility'):
        try:
            return section_mod.apply_section_visibility(namespace, context, sections) or {'sections': sections}
        except Exception:
            pass
    return {
        'sections': sections,
        'visibility': {},
        'total_sections': len(sections or []),
        'visible_sections': len(sections or []),
        'hidden_sections': 0,
        'hidden_cards_by_section': 0,
        'visible_cards_by_section': sum(len(section.get('cards', []) or []) for section in (sections or [])),
    }


def build_card_sections(namespace: dict, context, translate):
    raw_sections = _raw_sections(namespace, context, translate)
    sections = [section for section in raw_sections if section.get('cards')]
    vis_mod = namespace.get('_quality_visibility_module')
    if vis_mod is not None and hasattr(vis_mod, 'filter_sections'):
        try:
            filtered = vis_mod.filter_sections(namespace, context, raw_sections) or {}
            sections = list(filtered.get('sections', []) or [])
        except Exception:
            pass
    section_data = _apply_section_visibility(namespace, context, sections)
    return list(section_data.get('sections', []) or [])


def scan_visual_cards(namespace: dict, context, translate) -> dict:
    raw_sections = _raw_sections(namespace, context, translate)
    total_sections = len(raw_sections)
    total_cards = sum(len(section.get('cards', []) or []) for section in raw_sections)
    vis_mod = namespace.get('_quality_visibility_module')
    if vis_mod is not None and hasattr(vis_mod, 'filter_sections'):
        try:
            filtered = vis_mod.filter_sections(namespace, context, raw_sections) or {}
            visible_sections_src = list(filtered.get('sections', []) or [])
            section_data = _apply_section_visibility(namespace, context, visible_sections_src)
            visible_sections_list = list(section_data.get('sections', []) or [])
            visible_sections = len(visible_sections_list)
            visible_cards = sum(len(section.get('cards', []) or []) for section in visible_sections_list)
            visible_actions = sum(len(card.get('buttons', []) or []) for section in visible_sections_list for card in (section.get('cards', []) or []))
            hidden_cards = max(0, total_cards - visible_cards)
            data = {
                'focus_mode': str(filtered.get('focus_mode', 'all') or 'all'),
                'focus_override': str(filtered.get('focus_override', 'AUTO') or 'AUTO'),
                'focus_manual': bool(filtered.get('focus_manual', False)),
                'total_sections': int(filtered.get('total_sections', total_sections) or total_sections),
                'visible_sections': int(visible_sections),
                'hidden_sections': int(max(int(section_data.get('hidden_sections', 0) or 0), max(0, int(filtered.get('total_sections', total_sections) or total_sections) - visible_sections))),
                'total_cards': int(filtered.get('total_cards', total_cards) or total_cards),
                'visible_cards': int(visible_cards),
                'hidden_cards': int(hidden_cards),
                'visible_actions': int(visible_actions),
                'section_visibility': dict(section_data.get('visibility', {}) or {}),
            }
            namespace['_suv_visual_card_scan_last'] = dict(data)
            return data
        except Exception:
            pass
    sections = [section for section in raw_sections if section.get('cards')]
    section_data = _apply_section_visibility(namespace, context, sections)
    visible_sections_list = list(section_data.get('sections', []) or [])
    visible_sections = len(visible_sections_list)
    visible_cards = sum(len(section.get('cards', []) or []) for section in visible_sections_list)
    visible_actions = sum(len(card.get('buttons', []) or []) for section in visible_sections_list for card in (section.get('cards', []) or []))
    hidden_cards = max(0, total_cards - visible_cards)
    data = {
        'focus_mode': 'all',
        'focus_override': 'AUTO',
        'focus_manual': False,
        'total_sections': int(total_sections),
        'visible_sections': int(visible_sections),
        'hidden_sections': int(max(int(section_data.get('hidden_sections', 0) or 0), max(0, total_sections - visible_sections))),
        'total_cards': int(total_cards),
        'visible_cards': int(visible_cards),
        'hidden_cards': int(hidden_cards),
        'visible_actions': int(visible_actions),
        'section_visibility': dict(section_data.get('visibility', {}) or {}),
    }
    namespace['_suv_visual_card_scan_last'] = dict(data)
    return data
