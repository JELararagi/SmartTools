# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

'Defensive UI context checks for UV Suite panels.\n\nBlender 5.1 can call panel poll/draw while mode switches are still rebuilding\ncontext data. These helpers avoid touching stale or missing object/RNA pointers\nfrom panel code.\n'

from __future__ import annotations

import sys


_MANAGER_MODULES = (
    "bl_ext.user_default.smart_tools_manager",
    "bl_ext.user_default.smart_tools_manager.manager",
    "bl_ext.user_default.smart_tools_manager.runtime",
    "smart_tools_manager",
    "smart_tools_manager.manager",
    "smart_tools_manager.runtime",
)
_RUNTIME_AREA_TYPES = frozenset({"VIEW_3D", "IMAGE_EDITOR"})
_NOT_READY_VALUES = frozenset({"NOT_READY", "UNAVAILABLE", "UNKNOWN"})


def _safe_getattr(obj, name: str, default=None):
    try:
        if obj is None:
            return default
        return getattr(obj, name, default)
    except ReferenceError:
        return default
    except Exception:
        return default


def _safe_pointer(obj) -> int:
    try:
        fn = getattr(obj, 'as_pointer', None)
        if callable(fn):
            return int(fn() or 0)
    except ReferenceError:
        return 0
    except Exception:
        return 0
    return 0


def _workspace_runtime_callable():
    """Resolve Manager's public memory-only runtime API without importing it."""
    for name in _MANAGER_MODULES:
        try:
            module = sys.modules.get(name)
            fn = getattr(module, "workspace_tool_allowed", None) if module is not None else None
        except Exception:
            fn = None
        if callable(fn):
            # A reloaded extension can leave its root alias pointing at the old
            # manager module's function.  Accept that alias only when the live
            # defining module still exposes the same callable identity.
            owner_name = str(getattr(fn, "__module__", "") or "")
            owner_module = sys.modules.get(owner_name) if owner_name else None
            if owner_module is not None:
                owner_fn = getattr(owner_module, "workspace_tool_allowed", None)
                if callable(owner_fn) and owner_fn is not fn:
                    continue
            return fn
    return None


def smart_uv_workspace_runtime_allowed(context, tool_key: str = "SMART_UV") -> bool:
    """Return Manager's workspace-wide OR decision, failing open if unavailable.

    This is deliberately separate from ``Panel.poll``.  N-panel visibility stays
    cell-specific through ``placement_allowed``; only operator/runtime validity
    uses the workspace aggregate.  No Manager import, registration, persistence,
    file I/O, timer, handler or module-wide scan is performed here.
    """
    fn = _workspace_runtime_callable()
    if not callable(fn):
        return True
    if context is None or _safe_getattr(context, "workspace", None) is None:
        return True
    calls = (
        lambda: fn(str(tool_key or "SMART_UV"), context),
        lambda: fn(tool_key=str(tool_key or "SMART_UV"), context=context),
    )
    for call in calls:
        try:
            value = call()
        except TypeError:
            continue
        except Exception:
            return True
        if value is None or str(value).strip().upper() in _NOT_READY_VALUES:
            return True
        # Only Manager's explicit boolean False suppresses Suite runtime.  Any
        # stale, transitional or non-boolean result remains fail-open.
        return value is not False
    return True


def smart_uv_runtime_context_allowed(context) -> bool:
    """Gate Smart UV runtime only in its supported View3D/Image contexts."""
    area = _safe_getattr(context, "area", None)
    if area is None:
        return True
    area_type = str(_safe_getattr(area, "type", "") or "").upper()
    if area_type not in _RUNTIME_AREA_TYPES:
        return True
    return smart_uv_workspace_runtime_allowed(context, "SMART_UV")


def smart_uv_context_active_mesh(context):
    """Return a live active mesh object or ``None`` without raising."""
    obj = _safe_getattr(context, 'active_object', None)
    if obj is None:
        obj = _safe_getattr(context, 'object', None)
    if obj is None or not _safe_pointer(obj):
        return None
    if str(_safe_getattr(obj, 'type', '') or '') != 'MESH':
        return None
    try:
        select_get = getattr(obj, 'select_get', None)
        if callable(select_get) and not bool(select_get()):
            return None
    except ReferenceError:
        return None
    except Exception:
        pass
    mode = str(_safe_getattr(obj, 'mode', '') or '')
    if mode and mode not in {'OBJECT', 'EDIT', 'EDIT_MESH'}:
        return None
    data = _safe_getattr(obj, 'data', None)
    if data is None or not _safe_pointer(data):
        return None
    return obj


def smart_uv_context_area_type(context) -> str:
    area = _safe_getattr(context, 'area', None)
    return str(_safe_getattr(area, 'type', '') or '')


def smart_uv_context_region_type(context) -> str:
    region = _safe_getattr(context, 'region', None)
    return str(_safe_getattr(region, 'type', '') or '')


def smart_uv_context_space_mode(context) -> str:
    area = _safe_getattr(context, 'area', None)
    spaces = _safe_getattr(area, 'spaces', None)
    active = _safe_getattr(spaces, 'active', None)
    return str(_safe_getattr(active, 'mode', '') or '')


def smart_uv_panel_poll(
    context,
    *,
    require_mesh: bool = True,
    require_edit_mesh: bool = False,
    require_uv_space_mode: bool = False,
    allow_missing_area: bool = True,
) -> bool:
    """Safe panel poll for redraws during deselect/mode-switch transitions."""
    try:
        area = _safe_getattr(context, 'area', None)
        if area is None and not allow_missing_area:
            return False
        if _safe_getattr(context, 'window_manager', None) is None:
            return False
        obj = smart_uv_context_active_mesh(context) if (require_mesh or require_edit_mesh) else None
        if require_mesh and obj is None:
            return False
        if require_edit_mesh:
            mode = str(_safe_getattr(obj, 'mode', '') or '')
            if mode not in {'EDIT', 'EDIT_MESH'}:
                return False
        if require_uv_space_mode:
            mode = smart_uv_context_space_mode(context)
            if mode and mode != 'UV':
                return False
        return True
    except Exception:
        return False



def smart_uv_root_panel_poll(context, *, area_types={'VIEW_3D', 'IMAGE_EDITOR'}, allow_missing_area: bool = True) -> bool:
    'Return True for the visible UV Suite root Sidebar panels.\n\n    The root panels must remain visible even when no mesh is selected; otherwise\n    Blender hides the whole UV Suite N-panel tab.  Expensive mesh-specific UI is\n    gated in draw() instead.\n    '
    try:
        if _safe_getattr(context, 'window_manager', None) is None:
            return False
        area = _safe_getattr(context, 'area', None)
        if area is None:
            return bool(allow_missing_area)
        area_type = str(_safe_getattr(area, 'type', '') or '')
        return (not area_types) or area_type in set(area_types)
    except Exception:
        return False


def smart_uv_context_is_draw_ready(context) -> bool:
    'True only when the full UV Suite tool body can be safely drawn.'
    return smart_uv_context_active_mesh(context) is not None

def smart_uv_safe_draw_fallback(layout, context=None, message: str = 'UV Suite UI temporarily unavailable.'):
    try:
        col = layout.column(align=True)
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        obj = smart_uv_context_active_mesh(context)
        if obj is None:
            _hint_en = 'Select a mesh object, or switch to Object/Edit mode, to show tool controls.'
            try:
                from . import text_translation as _text_translation
                _hint = _text_translation.pick(
                    _hint_en,
                    'メッシュオブジェクトを選択するか、オブジェクト／編集モードへ切り替えると、ツール操作を表示します。',
                    context=context,
                )
            except Exception:
                _hint = _hint_en
            col.label(text=_hint, icon='MESH_DATA')
    except Exception:
        pass


def smart_uv_wrap_panel_draw(cls, message: str = 'UV Suite UI temporarily unavailable.'):
    """Wrap a Panel.draw method once so Python draw errors cannot leak outward."""
    try:
        original = getattr(cls, 'draw', None)
        if not callable(original) or getattr(cls, '_smart_uv_safe_draw_wrapped', False):
            return cls

        def _safe_draw(self, context):
            try:
                return original(self, context)
            except Exception as exc:
                try:
                    smart_uv_safe_draw_fallback(getattr(self, 'layout', None), context, f'{message}: {exc}')
                except Exception:
                    pass
                return None

        cls.draw = _safe_draw
        cls._smart_uv_safe_draw_wrapped = True
    except Exception:
        pass
    return cls
