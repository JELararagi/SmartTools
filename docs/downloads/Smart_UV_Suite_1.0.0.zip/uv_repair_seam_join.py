import bpy

def build_handlers(api):
    def run(context, op):
        active = context.active_object
        meshes = [obj for obj in context.selected_editable_objects if obj.type == 'MESH']
        if (context.mode != 'OBJECT' or active not in meshes or len(meshes) < 2
                or any(obj.type != 'MESH' for obj in context.selected_objects)):
            return False
        if not bpy.ops.object.join.poll():
            return False
        return 'FINISHED' in bpy.ops.object.join()

    return {
        'smart_uv_suite.seam_join': api.Handler(run, 'Join selected mesh objects into the active mesh, preserving their UV maps.', 'UVマップを保持して選択メッシュをアクティブメッシュに結合します。'),
    }
