"""Implement the inspect face public UV operations.

Each public button below runs the operation its label names.  Before these
handlers existed the buttons fell through to a generic inferred action
(SELECT_BOUNDARY, SMART_PROJECT, FIT, DENSITY_NORMALIZE, ...) that did not do
what the label says.
"""

import colorsys
import json
import math
import random

import bmesh
import bpy
from mathutils import Matrix, Vector

from . import uv_repair_division as _div


_FLAGS_KEY = 'SUV_INSPECT_FLAGS'
_TRIM_KEY = 'SUV_TRIMSHEETS'
_TRANSFORM_KEY = 'SUV_UV_TRANSFORM'
_UDIM_KEY = 'SUV_UDIM_TILES'
_WRAP_KEY = 'SUV_TEXTURE_WRAP'
_COLOR_LAYER = 'SUV_Island_Color'
_ICON_IMAGE = 'SUV_UV_Icon'
_PREVIEW_IMAGE = 'SUV_Texture_Preview'
_FLATTEN_PREFIX = 'Smart UV Flatten'


def inspect_face_unitize(context, op):
    return 'FINISHED' in bpy.ops.suv.face_unitize()


def _golden_color(index):
    r, g, b = colorsys.hsv_to_rgb((index * 0.618033988749895) % 1.0, 0.65, 0.95)
    return (r, g, b, 1.0)


def _union_box(islands):
    boxes = [isl.box for *_rest, isl in islands]
    return (min(b[0] for b in boxes), min(b[1] for b in boxes),
            max(b[2] for b in boxes), max(b[3] for b in boxes))


def _transform_faces(faces, uv, matrix2, pivot, offset):
    """uv' = matrix2 @ (uv - pivot) + pivot + offset for every loop of the faces."""
    for f in faces:
        for l in f.loops:
            p = l[uv].uv - pivot
            l[uv].uv = (matrix2 @ p) + pivot + offset


def _scale_faces(faces, uv, factor, pivot, offset=Vector((0.0, 0.0))):
    _transform_faces(faces, uv, Matrix(((factor, 0.0), (0.0, factor))), pivot, offset)


def _load_json(scene, key, default):
    raw = scene.get(key)
    if raw is None:
        return default
    try:
        return json.loads(raw)
    except Exception:
        return default


def _store_json(context, key, value):
    context.scene[key] = json.dumps(value, allow_nan=False, sort_keys=True)
    for area in getattr(context.screen, 'areas', ()) or ():
        if area.type in {'IMAGE_EDITOR', 'VIEW_3D'}:
            area.tag_redraw()
    return True


def _raster(context, rows, sync, name, size):
    """Draw every visible UV face of the 0-1 tile into an RGBA image, coloured by island."""
    pixels = [0.08, 0.08, 0.08, 1.0] * (size * size)
    for _obj, bm, uv in rows:
        for index, group in enumerate(_islands_of(bm, uv, sync)):
            color = _golden_color(index)
            for f in group:
                pts = [(l[uv].uv.x * size, l[uv].uv.y * size) for l in f.loops]
                for i in range(1, len(pts) - 1):
                    _fill_triangle(pixels, size, pts[0], pts[i], pts[i + 1], color)
    image = bpy.data.images.get(name)
    if image is None:
        image = bpy.data.images.new(name, size, size, alpha=True)
    elif tuple(image.size) != (size, size):
        image.scale(size, size)
    image.pixels.foreach_set(pixels)
    image.update()
    return image


_ISLANDS = None


def _islands_of(bm, uv, sync):
    return _ISLANDS(bm, uv, sync)


def _fill_triangle(pixels, size, a, b, c, color):
    min_x = max(0, int(math.floor(min(a[0], b[0], c[0]))))
    max_x = min(size - 1, int(math.ceil(max(a[0], b[0], c[0]))))
    min_y = max(0, int(math.floor(min(a[1], b[1], c[1]))))
    max_y = min(size - 1, int(math.ceil(max(a[1], b[1], c[1]))))
    den = (b[1] - c[1]) * (a[0] - c[0]) + (c[0] - b[0]) * (a[1] - c[1])
    if abs(den) <= 1.0e-12:
        return
    for y in range(min_y, max_y + 1):
        py = y + 0.5
        for x in range(min_x, max_x + 1):
            px = x + 0.5
            w0 = ((b[1] - c[1]) * (px - c[0]) + (c[0] - b[0]) * (py - c[1])) / den
            w1 = ((c[1] - a[1]) * (px - c[0]) + (a[0] - c[0]) * (py - c[1])) / den
            if w0 < 0.0 or w1 < 0.0 or (1.0 - w0 - w1) < 0.0:
                continue
            k = (y * size + x) * 4
            pixels[k:k + 4] = color


def build_handlers(api):
    global _ISLANDS
    _ISLANDS = api._islands

    def rows_or_warn(context, op):
        rows = api._edit_targets(context)
        if not rows:
            api._no_uv(context, op)
        return rows

    def scope_islands(context, rows):
        return api._seed_islands(context, rows) or api._all_islands(context, rows)

    def selected_or_warn(context, op, rows):
        seeds = api._seed_islands(context, rows)
        if not seeds:
            api._warn(context, op, 'Select one or more UV islands first.', '先に UV アイランドを選んでください。')
        return seeds

    def any_selected(context, rows):
        sync = api._sync(context)
        return any(api._face_selected(f, sync) for _o, bm, _uv in rows for f in bm.faces)

    def select_all_shown(context, rows):
        sync = api._sync(context)
        for _o, bm, _uv in rows:
            api._select_faces(context, bm, [f for f in bm.faces if api._visible(f, sync)])
        api._flush(rows)

    def density(isls):
        uv_area = sum(isl.uv_area for *_r, isl in isls)
        mesh_area = sum(isl.mesh_area for *_r, isl in isls)
        return math.sqrt(uv_area / mesh_area) if mesh_area > 1.0e-12 else 0.0

    # ------------------------------------------------------------------ inspect
    def batch_inspect_flags(context, op):
        rows = rows_or_warn(context, op)
        if not rows:
            return False
        counts = api._counts(api._scan(context, rows))
        counts['seams'] = sum(1 for _o, bm, _uv in rows for e in bm.edges if e.seam)
        _store_json(context, _FLAGS_KEY, counts)
        api._info(context, op, api._summary(context, counts), api._summary(context, counts))
        return True

    def check_non_splitted(context, op):
        rows = rows_or_warn(context, op)
        if not rows:
            return False
        sync = api._sync(context)
        found = 0
        for _o, bm, uv in rows:
            picked = set()
            for e in bm.edges:
                if not e.seam:
                    continue
                loops = [l for l in e.link_loops if api._visible(l.face, sync)]
                for i, l in enumerate(loops):
                    for other in loops[i + 1:]:
                        if api._uv_connected(l, other, uv):
                            picked.update((l.face, other.face))
            api._select_faces(context, bm, picked)
            found += len(picked)
        api._flush(rows)
        api._info(context, op, f'{found} faces sit on seams that are not split in UV.',
                  f'UV で分かれていないシームに接する面は {found} 面です。')
        return True

    def check_other(context, op):
        rows = rows_or_warn(context, op)
        if not rows:
            return False
        sync = api._sync(context)
        found = 0
        for _o, bm, uv in rows:
            bad = set()
            for f in bm.faces:
                if not api._visible(f, sync):
                    continue
                if any(not math.isfinite(c) for l in f.loops for c in l[uv].uv):
                    bad.add(f)
                elif abs(api._face_uv_area(f, uv)) <= 1.0e-8:
                    bad.add(f)
            api._select_faces(context, bm, bad)
            found += len(bad)
        api._flush(rows)
        api._info(context, op, f'{found} faces have zero-area or invalid UV coordinates.',
                  f'面積ゼロか不正な UV 座標の面は {found} 面です。')
        return True

    def paint_uv_island(context, op):
        rows = rows_or_warn(context, op)
        if not rows:
            return False
        sync = api._sync(context)
        painted = 0
        for obj, bm, uv in rows:
            layer = bm.faces.layers.float_color.get(_COLOR_LAYER) or bm.faces.layers.float_color.new(_COLOR_LAYER)
            uv = bm.loops.layers.uv.active
            for index, group in enumerate(api._islands(bm, uv, sync)):
                color = _golden_color(index)
                for f in group:
                    f[layer] = color
                painted += 1
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=True)
        api._info(context, op, f'Painted {painted} UV islands into the "{_COLOR_LAYER}" face colour.',
                  f'{painted} 個の UV アイランドを面の色「{_COLOR_LAYER}」に塗りました。')
        return True

    def random_islands(context, op):
        rows = rows_or_warn(context, op)
        if not rows:
            return False
        seeds = selected_or_warn(context, op, rows)
        if not seeds:
            return False
        amount = float(op.amount)
        if amount <= 0.0:
            api._warn(context, op, 'Set an amount above zero.', '量を 0 より大きくしてください。')
            return False
        rng = random.Random(int(op.index))
        for _o, _bm, uv, isl in seeds:
            api._move_island(isl.faces, uv, rng.uniform(-amount, amount), rng.uniform(-amount, amount))
        api._flush(rows)
        return True

    def shift_islands(context, op):
        rows = rows_or_warn(context, op)
        if not rows:
            return False
        seeds = selected_or_warn(context, op, rows)
        if not seeds:
            return False
        direction = (op.direction or 'RIGHT').strip().upper()
        if direction not in _div._DIRECTIONS:
            api._warn(context, op, 'Choose Right, Left, Up or Down.', '右・左・上・下のどれかを選んでください。')
            return False
        dx, dy = _div._DIRECTIONS[direction]
        amount = float(op.amount)
        for _o, _bm, uv, isl in seeds:
            api._move_island(isl.faces, uv, dx * amount, dy * amount)
        api._flush(rows)
        return True

    def scan_to_trim(context, op):
        rows = rows_or_warn(context, op)
        if not rows:
            return False
        divisions = []
        for _o, _bm, _uv, isl in scope_islands(context, rows):
            bounds = [round(x, 6) for x in isl.box]
            if _div._valid(bounds):
                divisions.append(_div._record(f'Island {len(divisions) + 1}', bounds))
        if not divisions:
            api._warn(context, op, 'No UV island with an area was found.', '面積のある UV アイランドが見つかりません。')
            return False
        _div._store(context, {'active': 0, 'divisions': divisions})
        api._info(context, op, f'Made {len(divisions)} divisions from the UV islands.',
                  f'UV アイランドから {len(divisions)} 個の区画を作りました。')
        return True

    def smart_scan_and_layout(context, op):
        rows = rows_or_warn(context, op)
        if not rows:
            return False
        if not any_selected(context, rows):
            select_all_shown(context, rows)
        if 'FINISHED' not in bpy.ops.uv.pack_islands(margin=float(op.padding)):
            return False
        rows = api._edit_targets(context)
        counts = api._counts(api._scan(context, rows))
        _store_json(context, _FLAGS_KEY, counts)
        api._info(context, op, api._summary(context, counts), api._summary(context, counts))
        return True

    def prepare_workflow_profile(context, op):
        key = (op.key or op.name or 'PREPARED_WORKFLOW_PROFILE').strip()
        return 'FINISHED' in bpy.ops.uv.suv_preset_library_io(
            library_kind='WORKFLOW', mode='CAPTURE_CURRENT', entry_key=key)

    # --------------------------------------------------------------- trimsheets
    def trim_state(context):
        state = _load_json(context.scene, _TRIM_KEY, None)
        if not isinstance(state, dict) or not isinstance(state.get('sheets'), list):
            state = {'active': -1, 'sheets': []}
        return state

    def active_sheet(state):
        index = state.get('active', -1)
        sheets = state['sheets']
        return sheets[index] if 0 <= index < len(sheets) else None

    def need_sheet(context, op, state):
        sheet = active_sheet(state)
        if sheet is None:
            api._warn(context, op, 'Add or activate a trim sheet first.', '先にトリムシートを追加するか有効にしてください。')
        return sheet

    def activate_trimsheet(context, op):
        state = trim_state(context)
        sheets = state['sheets']
        if not sheets:
            api._warn(context, op, 'There is no trim sheet to activate.', '有効にできるトリムシートがありません。')
            return False
        if op.name:
            names = [s.get('name') for s in sheets]
            if op.name not in names:
                api._warn(context, op, f'No trim sheet is named "{op.name}".', f'「{op.name}」という名前のトリムシートはありません。')
                return False
            index = names.index(op.name)
        elif op.properties.is_property_set('index'):
            index = int(op.index)
            if not 0 <= index < len(sheets):
                api._warn(context, op, 'That trim sheet number does not exist.', 'その番号のトリムシートはありません。')
                return False
        else:
            index = (int(state.get('active', -1)) + 1) % len(sheets)
        state['active'] = index
        return _store_json(context, _TRIM_KEY, state)

    def add_to_trim_list(context, op):
        rows = rows_or_warn(context, op)
        if not rows:
            return False
        seeds = selected_or_warn(context, op, rows)
        if not seeds:
            return False
        bounds = [round(x, 6) for x in _union_box(seeds)]
        if not _div._valid(bounds):
            api._warn(context, op, 'The selected UVs have no area.', '選んだ UV に面積がありません。')
            return False
        state = trim_state(context)
        if active_sheet(state) is None:
            state['sheets'].append({'name': 'TrimSheet', 'trims': [], 'active_trim': -1})
            state['active'] = len(state['sheets']) - 1
        sheet = active_sheet(state)
        sheet['trims'].append({'name': op.name or f"Trim {len(sheet['trims']) + 1}", 'bounds': bounds})
        sheet['active_trim'] = len(sheet['trims']) - 1
        return _store_json(context, _TRIM_KEY, state)

    def remove_from_trim_list(context, op):
        state = trim_state(context)
        sheet = need_sheet(context, op, state)
        if sheet is None:
            return False
        trims = sheet['trims']
        index = int(op.index) if op.properties.is_property_set('index') else int(sheet.get('active_trim', -1))
        if not 0 <= index < len(trims):
            api._warn(context, op, 'Choose a trim in the list first.', '先にリストのトリムを選んでください。')
            return False
        del trims[index]
        active = int(sheet.get('active_trim', -1))
        if index < active:
            active -= 1
        sheet['active_trim'] = min(active, len(trims) - 1)
        return _store_json(context, _TRIM_KEY, state)

    def clear_trim_list(context, op):
        state = trim_state(context)
        sheet = need_sheet(context, op, state)
        if sheet is None:
            return False
        sheet['trims'] = []
        sheet['active_trim'] = -1
        return _store_json(context, _TRIM_KEY, state)

    def remove_trimsheet(context, op):
        state = trim_state(context)
        sheets = state['sheets']
        index = int(op.index) if op.properties.is_property_set('index') else int(state.get('active', -1))
        if not 0 <= index < len(sheets):
            api._warn(context, op, 'Choose a trim sheet first.', '先にトリムシートを選んでください。')
            return False
        del sheets[index]
        active = int(state.get('active', -1))
        if index < active:
            active -= 1
        state['active'] = min(active, len(sheets) - 1)
        return _store_json(context, _TRIM_KEY, state)

    def active_trim_bounds(context, op):
        state = trim_state(context)
        sheet = need_sheet(context, op, state)
        if sheet is None:
            return None
        trims = sheet['trims']
        index = int(sheet.get('active_trim', -1))
        if not 0 <= index < len(trims) or not _div._valid(trims[index]['bounds']):
            api._warn(context, op, 'Choose a trim in the list first.', '先にリストのトリムを選んでください。')
            return None
        return trims[index]['bounds']

    def fit_into(seeds, bounds, padding):
        u0, v0, u1, v1 = bounds
        pad = max(0.0, float(padding))
        tw, th = (u1 - u0) - 2.0 * pad, (v1 - v0) - 2.0 * pad
        if tw <= 0.0 or th <= 0.0:
            tw, th = u1 - u0, v1 - v0
        b0, c0, b1, c1 = _union_box(seeds)
        w, h = b1 - b0, c1 - c0
        if w <= 1.0e-12 or h <= 1.0e-12:
            return False
        factor = min(tw / w, th / h)
        pivot = Vector(((b0 + b1) * 0.5, (c0 + c1) * 0.5))
        target = Vector(((u0 + u1) * 0.5, (v0 + v1) * 0.5))
        for _o, _bm, uv, isl in seeds:
            _scale_faces(isl.faces, uv, factor, pivot, target - pivot)
        return True

    def fit_to_trim(context, op):
        bounds = active_trim_bounds(context, op)
        if bounds is None:
            return False
        rows = rows_or_warn(context, op)
        if not rows:
            return False
        seeds = selected_or_warn(context, op, rows)
        if not seeds or not fit_into(seeds, bounds, op.padding):
            return False
        api._flush(rows)
        return True

    def unfold_trim(context, op):
        bounds = active_trim_bounds(context, op)
        if bounds is None:
            return False
        rows = rows_or_warn(context, op)
        if not rows:
            return False
        if not selected_or_warn(context, op, rows):
            return False
        if 'FINISHED' not in bpy.ops.uv.unwrap(method='ANGLE_BASED', margin=0.0):
            return False
        rows = api._edit_targets(context)
        seeds = api._seed_islands(context, rows)
        if not seeds or not fit_into(seeds, bounds, op.padding):
            return False
        api._flush(rows)
        return True

    # --------------------------------------------------------- UV transform copy
    def get_uv_transform(context, op):
        rows = rows_or_warn(context, op)
        if not rows:
            return False
        seeds = selected_or_warn(context, op, rows)
        if not seeds:
            return False
        u0, v0, u1, v1 = _union_box(seeds)
        size = max(u1 - u0, v1 - v0)
        if size <= 1.0e-12:
            api._warn(context, op, 'The selected UVs have no size.', '選んだ UV に大きさがありません。')
            return False
        value = {'center': [round((u0 + u1) * 0.5, 6), round((v0 + v1) * 0.5, 6)], 'size': round(size, 6)}
        _store_json(context, _TRANSFORM_KEY, value)
        api._info(context, op, f"Stored UV centre {value['center']} and size {value['size']}.",
                  f"UV の中心 {value['center']} と大きさ {value['size']} を記憶しました。")
        return True

    def set_uv_transform(context, op):
        value = _load_json(context.scene, _TRANSFORM_KEY, None)
        if not isinstance(value, dict) or 'center' not in value or not value.get('size'):
            api._warn(context, op, 'Use Get UV Transform first.', '先に「UV トランスフォームを取得」を使ってください。')
            return False
        rows = rows_or_warn(context, op)
        if not rows:
            return False
        seeds = selected_or_warn(context, op, rows)
        if not seeds:
            return False
        u0, v0, u1, v1 = _union_box(seeds)
        size = max(u1 - u0, v1 - v0)
        if size <= 1.0e-12:
            return False
        pivot = Vector(((u0 + u1) * 0.5, (v0 + v1) * 0.5))
        target = Vector(value['center'])
        for _o, _bm, uv, isl in seeds:
            _scale_faces(isl.faces, uv, float(value['size']) / size, pivot, target - pivot)
        api._flush(rows)
        return True

    def sort_transform(context, op):
        rows = rows_or_warn(context, op)
        if not rows:
            return False
        isls = scope_islands(context, rows)
        if len(isls) < 2:
            api._warn(context, op, 'Sorting needs two or more UV islands.', '並べ替えには 2 つ以上の UV アイランドが要ります。')
            return False
        u0, v0, _u1, _v1 = _union_box(isls)
        gap = max(0.0, float(op.padding))
        cursor = u0
        for _o, _bm, uv, isl in sorted(isls, key=lambda row: -row[3].uv_area):
            api._move_island(isl.faces, uv, cursor - isl.box[0], v0 - isl.box[1])
            cursor += isl.width + gap
        api._flush(rows)
        return True

    def orient_to_geometry(context, op):
        rows = rows_or_warn(context, op)
        if not rows:
            return False
        isls = scope_islands(context, rows)
        turned = 0
        for obj, _bm, uv, isl in isls:
            best = None
            for f in isl.faces:
                for l in f.loops:
                    a = obj.matrix_world @ l.vert.co
                    b = obj.matrix_world @ l.link_loop_next.vert.co
                    d3 = b - a
                    if d3.length <= 1.0e-9:
                        continue
                    d2 = l.link_loop_next[uv].uv - l[uv].uv
                    if d2.length <= 1.0e-9:
                        continue
                    score = abs(d3.z) / d3.length
                    if best is None or score > best[0]:
                        best = (score, d2 if d3.z >= 0.0 else -d2)
            if best is None or best[0] <= 1.0e-6:
                continue
            d2 = best[1]
            angle = math.atan2(d2.x, d2.y)  # rotate this direction onto +V
            c, s = math.cos(angle), math.sin(angle)
            box = isl.box
            pivot = Vector(((box[0] + box[2]) * 0.5, (box[1] + box[3]) * 0.5))
            _transform_faces(isl.faces, uv, Matrix(((c, -s), (s, c))), pivot, Vector((0.0, 0.0)))
            turned += 1
        if not turned:
            api._warn(context, op, 'No island has an edge that rises in 3D.', '3D で上下に伸びる辺を持つアイランドがありません。')
            return False
        api._flush(rows)
        return True

    # -------------------------------------------------------------------- texel
    def evaluate_texel_density(context, op):
        rows = rows_or_warn(context, op)
        if not rows:
            return False
        ws = api._ws(context)
        value = density(scope_islands(context, rows)) * float(getattr(ws, 'canvas_size', 2048))
        if value < 1.0:
            api._warn(context, op, 'The UVs have no measurable texel density.', '測れるテクセル密度がありません。')
            return False
        ws.workflow_density = value
        api._info(context, op, f'Suggested texel density: {value:.2f} px/m', f'おすすめのテクセル密度: {value:.2f} px/m')
        return True

    def calc_udims_from_3d_area(context, op):
        rows = rows_or_warn(context, op)
        if not rows:
            return False
        ws = api._ws(context)
        sync = api._sync(context)
        area = sum(f.calc_area() * api._world_area_scale(obj)
                   for obj, bm, _uv in rows for f in bm.faces if api._visible(f, sync))
        canvas = float(getattr(ws, 'canvas_size', 2048))
        target = float(getattr(ws, 'workflow_density', 1024.0))
        if area <= 0.0 or canvas <= 0.0:
            api._warn(context, op, 'The mesh has no surface area.', 'メッシュに面積がありません。')
            return False
        tiles = max(1, int(math.ceil(area * (target / canvas) ** 2 - 1.0e-9)))
        context.scene[_UDIM_KEY] = tiles
        api._info(context, op, f'{tiles} UDIM tiles are needed for {area:.4f} m² at {target:.0f} px/m.',
                  f'{area:.4f} m² を {target:.0f} px/m で並べるには UDIM タイルが {tiles} 枚要ります。')
        return True

    def density_tools_init(context, op):
        ws = api._ws(context)
        if ws is None:
            return False
        ws.workflow_density = 1024.0
        ws.canvas_size = 2048
        return True

    # ------------------------------------------------------------------- unwrap
    def unwrap_with(method, pack=False):
        def run(context, op):
            rows = rows_or_warn(context, op)
            if not rows:
                return False
            if not any(f.select and not f.hide for _o, bm, _uv in rows for f in bm.faces):
                api._warn(context, op, 'Select faces to unwrap.', '展開する面を選んでください。')
                return False
            ws = api._ws(context)
            ok = 'FINISHED' in bpy.ops.uv.unwrap(
                method=method, correct_aspect=bool(getattr(ws, 'native_unwrap_correct_aspect', True)),
                margin=float(op.padding))
            if ok and pack:
                ok = 'FINISHED' in bpy.ops.uv.pack_islands(rotate=False, margin=float(op.padding))
            return ok
        return run

    def mirrored(context, op):
        rows = rows_or_warn(context, op)
        if not rows:
            return False
        sync = api._sync(context)
        copied = 0
        for obj, bm, uv in rows:
            scope = [f for f in bm.faces if api._face_selected(f, sync)] or [f for f in bm.faces if api._visible(f, sync)]
            index = {}
            for f in bm.faces:
                key = tuple(sorted(tuple(round(c, 5) for c in v.co) for v in f.verts))
                index[key] = f
            for f in scope:
                if f.calc_center_median().x >= -1.0e-6:
                    continue
                key = tuple(sorted((round(-v.co.x, 5) + 0.0, round(v.co.y, 5), round(v.co.z, 5)) for v in f.verts))
                twin = index.get(key)
                if twin is None:
                    continue
                twin_uv = {(round(-l.vert.co.x, 5) + 0.0, round(l.vert.co.y, 5), round(l.vert.co.z, 5)): l[uv].uv.copy()
                           for l in twin.loops}
                for l in f.loops:
                    key_v = (round(l.vert.co.x, 5) + 0.0, round(l.vert.co.y, 5), round(l.vert.co.z, 5))
                    if key_v in twin_uv:
                        l[uv].uv = twin_uv[key_v]
                copied += 1
        if not copied:
            api._warn(context, op, 'No face on the -X side has a mirrored twin on the +X side.',
                      '-X 側の面に、+X 側の対になる面がありません。')
            return False
        api._flush(rows)
        api._info(context, op, f'Shared the +X UVs with {copied} mirrored faces.', f'{copied} 面に +X 側の UV を共有しました。')
        return True

    def texture_projection_project(context, op):
        from . import _sus_projection_gizmo_name
        gizmo = bpy.data.objects.get(_sus_projection_gizmo_name(context))
        if gizmo is None:
            api._warn(context, op, 'Add the projection gizmo first.', '先に投影ギズモを追加してください。')
            return False
        rows = rows_or_warn(context, op)
        if not rows:
            return False
        sync = api._sync(context)
        inv = gizmo.matrix_world.inverted()
        for obj, bm, uv in rows:
            faces = [f for f in bm.faces if api._face_selected(f, sync)] or [f for f in bm.faces if api._visible(f, sync)]
            to_gizmo = inv @ obj.matrix_world
            for f in faces:
                for l in f.loops:
                    p = to_gizmo @ l.vert.co
                    l[uv].uv = (p.x + 0.5, p.y + 0.5)
        api._flush(rows)
        return True

    # --------------------------------------------------------------------- view
    def icons_generator(context, op):
        rows = rows_or_warn(context, op)
        if not rows:
            return False
        size = max(16, min(1024, int(op.texture_size) if op.properties.is_property_set('texture_size') else 128))
        _raster(context, rows, api._sync(context), _ICON_IMAGE, size)
        api._info(context, op, f'Made the UV icon image "{_ICON_IMAGE}".', f'UV のアイコン画像「{_ICON_IMAGE}」を作りました。')
        return True

    def texture_projection(context, op):
        rows = rows_or_warn(context, op)
        if not rows:
            return False
        ws = api._ws(context)
        size = max(16, min(1024, int(getattr(ws, 'canvas_size', 2048)) // 8))
        image = _raster(context, rows, api._sync(context), _PREVIEW_IMAGE, size)
        for area in getattr(context.screen, 'areas', ()) or ():
            if area.type == 'IMAGE_EDITOR':
                area.spaces.active.image = image
                area.tag_redraw()
        api._info(context, op, f'Rendered the texture preview "{_PREVIEW_IMAGE}".', f'テクスチャのプレビュー「{_PREVIEW_IMAGE}」を描きました。')
        return True

    # ----------------------------------------------------------------- workflow
    def flatten_clean_up(context, op):
        objs = []
        active = getattr(context, 'active_object', None)
        for obj in [active] + list(getattr(context, 'selected_objects', []) or []):
            if obj is not None and obj.type == 'MESH' and obj not in objs:
                objs.append(obj)
        mode = getattr(active, 'mode', 'OBJECT')
        if mode == 'EDIT':
            bpy.ops.object.mode_set(mode='OBJECT')
        removed = 0
        try:
            for obj in objs:
                keys = getattr(obj.data, 'shape_keys', None)
                if keys is None:
                    continue
                for block in list(keys.key_blocks):
                    hit = block.name == op.name if op.name else block.name.startswith(_FLATTEN_PREFIX)
                    if hit and block != keys.reference_key:
                        obj.shape_key_remove(block)
                        removed += 1
                keys = getattr(obj.data, 'shape_keys', None)
                if keys is not None and len(keys.key_blocks) == 1 and removed:
                    obj.shape_key_remove(keys.key_blocks[0])
        finally:
            if mode == 'EDIT':
                bpy.ops.object.mode_set(mode='EDIT')
        if not removed:
            api._warn(context, op, 'There is no UV flatten shape key to remove.', '消す UV 平坦化シェイプキーがありません。')
            return False
        api._info(context, op, f'Removed {removed} UV flatten shape keys.', f'UV 平坦化シェイプキーを {removed} 個消しました。')
        return True

    def texture_wrap_refer(context, op):
        rows = rows_or_warn(context, op)
        if not rows:
            return False
        seeds = selected_or_warn(context, op, rows)
        if not seeds:
            return False
        value = density(seeds)
        if value <= 0.0:
            api._warn(context, op, 'The reference island has no texel density.', '基準のアイランドにテクセル密度がありません。')
            return False
        _store_json(context, _WRAP_KEY, {'density': value})
        api._info(context, op, f'Stored the texture wrap reference ({value:.6f}).', f'テクスチャの基準 ({value:.6f}) を記憶しました。')
        return True

    def texture_wrap_set(context, op):
        value = _load_json(context.scene, _WRAP_KEY, None)
        ref = float(value.get('density', 0.0)) if isinstance(value, dict) else 0.0
        if ref <= 0.0:
            api._warn(context, op, 'Use Set Texture Wrap Reference first.', '先に「テクスチャの基準を設定」を使ってください。')
            return False
        rows = rows_or_warn(context, op)
        if not rows:
            return False
        seeds = selected_or_warn(context, op, rows)
        if not seeds:
            return False
        for _o, _bm, uv, isl in seeds:
            if isl.density <= 0.0:
                continue
            box = isl.box
            pivot = Vector(((box[0] + box[2]) * 0.5, (box[1] + box[3]) * 0.5))
            _scale_faces(isl.faces, uv, ref / isl.density, pivot)
        api._flush(rows)
        return True

    def integrated_native(context, op):
        # 呼び出しで action を明示した時は、a158 と同じ共通の動作（_execute_action）に任せる（PD34C v2：l2 の VALUE 行は action='ROTATE_CW'）
        try:
            explicit = bool(op.properties.is_property_set('action'))
        except Exception:
            explicit = False
        if explicit and str(getattr(op, 'action', '') or '').strip():
            return 'FINISHED' in api._u._execute_action(context, op, str(op.action).strip())
        rows = rows_or_warn(context, op)
        if not rows:
            return False
        ws = api._ws(context)
        if ws is None:
            return False
        if not any(f.select and not f.hide for _o, bm, _uv in rows for f in bm.faces):
            api._warn(context, op, 'Select faces to unwrap.', '展開する面を選んでください。')
            return False
        ok = 'FINISHED' in bpy.ops.uv.unwrap(
            method='ANGLE_BASED',
            fill_holes=bool(ws.native_unwrap_fill_holes),
            correct_aspect=bool(ws.native_unwrap_correct_aspect),
            use_subsurf_data=bool(ws.native_unwrap_use_subsurf_data),
            margin_method=ws.native_unwrap_margin_method,
            margin=float(ws.native_unwrap_margin),
            no_flip=bool(ws.native_unwrap_no_flip),
            iterations=int(ws.native_unwrap_iterations),
            use_weights=bool(ws.native_unwrap_use_weights),
            weight_group=str(ws.native_unwrap_weight_group),
            weight_factor=float(ws.native_unwrap_weight_factor),
        )
        if ok and bool(getattr(ws, 'workflow_pack_after', False)):
            ok = 'FINISHED' in bpy.ops.uv.pack_islands(margin=float(ws.native_unwrap_margin))
        return ok

    def align_uv_action(context, op):
        action = str(op.action or '').strip()
        if not action:
            api._warn(context, op, 'Choose an align action first.', '先に整列の種類を選んでください。')
            return False
        return 'FINISHED' in api._u._execute_action(context, op, action)

    H = api.Handler
    p = 'smart_uv_suite.'
    return {
        p + 'inspect_face_unitize': H(inspect_face_unitize, 'Reset selected faces to individual unit UV shapes.', '選択面を個別の単位UV形状に戻します。'),
        p + 'batch_inspect_flags': H(batch_inspect_flags, 'Count overlap, flipped, zero-area, outside-tile and stretched faces and the seams, and store the counts.', '重なり・裏返り・面積ゼロ・枠の外・伸びの面とシームの数を数えて記録します。'),
        p + 'inspect_check_non_splitted': H(check_non_splitted, 'Select faces on seams whose UVs are still joined.', 'UV がつながったままのシームに接する面を選びます。'),
        p + 'inspect_check_other': H(check_other, 'Select faces with zero-area or invalid UV coordinates.', '面積ゼロか不正な UV 座標の面を選びます。'),
        p + 'inspect_inspection_paint_uv_island': H(paint_uv_island, 'Paint each UV island a different colour into a face colour attribute.', 'UV アイランドごとに違う色を面の色の属性に塗ります。'),
        p + 'inspect_random': H(random_islands, 'Move each selected island by a random offset up to the amount.', '選んだアイランドを、量までのランダムな距離だけ動かします。'),
        p + 'inspect_shift': H(shift_islands, 'Move the selected islands by the amount in the chosen direction.', '選んだアイランドを、選んだ向きへ量だけ動かします。'),
        p + 'inspect_scan_to_trim': H(scan_to_trim, 'Replace the divisions with one division per UV island.', '区画を、UV アイランドごとの区画に置き換えます。'),
        p + 'inspect_smart_scan_and_layout': H(smart_scan_and_layout, 'Pack the UV islands, then scan them for problems.', 'UV アイランドを詰めてから、問題を走査します。'),
        p + 'inspect_upgrade_prepare_workflow_profile': H(prepare_workflow_profile, 'Store the current workspace settings as a workflow profile.', '今の作業設定をワークフローのプロファイルとして登録します。'),
        p + 'pack_activate_trimsheet': H(activate_trimsheet, 'Make the named, numbered or next trim sheet the active one.', '名前・番号で選んだか次のトリムシートを有効にします。'),
        p + 'pack_add_to_trim_list': H(add_to_trim_list, 'Add the bounds of the selected UVs to the active trim sheet.', '選んだ UV の範囲を有効なトリムシートに追加します。'),
        p + 'pack_remove_from_trim_list': H(remove_from_trim_list, 'Remove the chosen trim from the active trim sheet.', '有効なトリムシートから選んだトリムを外します。'),
        p + 'pack_clear_trim_list': H(clear_trim_list, 'Remove every trim from the active trim sheet.', '有効なトリムシートのトリムを全部外します。'),
        p + 'pack_remove_trimsheet': H(remove_trimsheet, 'Delete the active trim sheet.', '有効なトリムシートを削除します。'),
        p + 'pack_fit_to_trim': H(fit_to_trim, 'Fit the selected islands inside the active trim, keeping their aspect ratio.', '選んだアイランドを、縦横比を保って有効なトリムの中に収めます。'),
        p + 'pack_unfold': H(unfold_trim, 'Unwrap the selected faces and fit them inside the active trim.', '選んだ面を展開して、有効なトリムの中に収めます。'),
        p + 'pack_get_uv_transform': H(get_uv_transform, 'Remember the centre and size of the selected UVs.', '選んだ UV の中心と大きさを記憶します。'),
        p + 'pack_set_uv_transform': H(set_uv_transform, 'Move and scale the selected UVs to the remembered centre and size.', '選んだ UV を記憶した中心と大きさに合わせます。'),
        p + 'pack_sort_transform': H(sort_transform, 'Line the islands up from largest to smallest along U.', 'アイランドを大きい順に U 方向へ並べます。'),
        p + 'pack_orient_to_geometry': H(orient_to_geometry, 'Rotate each island so its most upright 3D edge points up in V.', '3D で最も立った辺が V の上を向くように、アイランドを回します。'),
        p + 'evaluate_texel_density': H(evaluate_texel_density, 'Measure the texel density of the islands and set it as the workflow density.', 'アイランドのテクセル密度を測り、作業の密度に入れます。'),
        p + 'texel_calc_udims_from_3d_area': H(calc_udims_from_3d_area, 'Calculate how many UDIM tiles the mesh area needs at the workflow density.', '作業の密度でメッシュの面積に要る UDIM タイルの数を計算します。'),
        p + 'texel_density_tools_init': H(density_tools_init, 'Reset the workflow density and canvas size to their defaults.', '作業の密度とキャンバスの大きさを既定値に戻します。'),
        p + 'unwrap': H(unwrap_with('ANGLE_BASED'), 'Unwrap the selected faces with the angle-based method.', '選んだ面を角度ベースで展開します。'),
        p + 'unwrap_unwrap': H(unwrap_with('ANGLE_BASED'), 'Unwrap the selected faces with the angle-based method.', '選んだ面を角度ベースで展開します。'),
        p + 'unwrap_unwrap_2': H(unwrap_with('ANGLE_BASED'), 'Unwrap the selected faces with the angle-based method.', '選んだ面を角度ベースで展開します。'),
        p + 'unwrap_unfoldify': H(unwrap_with('CONFORMAL'), 'Unfold the selected faces with the conformal method.', '選んだ面を等角法で開きます。'),
        p + 'unwrap_body_preset': H(unwrap_with('ANGLE_BASED', pack=True), 'Unwrap the selected body parts and pack them upright.', '選んだ体の部位を展開し、回さずに詰めます。'),
        p + 'unwrap_mirrored': H(mirrored, 'Give faces on the -X side the same UVs as their +X twins.', '-X 側の面に、+X 側の対の面と同じ UV を与えます。'),
        p + 'unwrap_texture_projection_project': H(texture_projection_project, 'Project the selected faces through the projection gizmo.', '選んだ面を投影ギズモから投影します。'),
        p + 'view_icons_generator': H(icons_generator, 'Generate an icon image of the UV layout.', 'UV 配置のアイコン画像を作ります。'),
        p + 'view_texture_projection': H(texture_projection, 'Render a preview image of the UV islands and show it in the Image Editor.', 'UV アイランドのプレビュー画像を描き、画像エディターに表示します。'),
        p + 'workflow_flatten_clean_up': H(flatten_clean_up, 'Remove the UV flatten shape keys.', 'UV 平坦化シェイプキーを消します。'),
        p + 'workflow_texture_wrap_refer': H(texture_wrap_refer, 'Remember the texel density of the selected islands as the wrap reference.', '選んだアイランドのテクセル密度を基準として記憶します。'),
        p + 'workflow_texture_wrap_set': H(texture_wrap_set, 'Scale each selected island to the remembered reference density.', '選んだアイランドを、記憶した基準の密度に拡大縮小します。'),
        p + 'workflow_integrated_native': H(integrated_native, 'Unwrap with the native unwrap settings, then pack when Pack After is on.', 'ネイティブ展開の設定で展開し、「後でパック」が有効なら詰めます。'),
        p + 'align_uv_action': H(align_uv_action, 'Run the chosen UV align action.', '選んだ UV の整列を実行します。'),
    }
