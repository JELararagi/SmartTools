# SPDX-License-Identifier: GPL-3.0-or-later
"""Validate the tile padding, then call the native SmartUV fitting operator."""
import bpy


def _setting(operation, key, workspace, default_key, fallback):
    if operation.properties.is_property_set(key):
        return getattr(operation, key)
    return getattr(workspace, default_key, fallback)


def build_handlers(api):
    def fit_tile(context, operation):
        workspace = getattr(context.scene, "suv_workspace", None)
        size = _setting(operation, "texture_size", workspace, "canvas_size", 2048)
        padding = _setting(operation, "margin_px", workspace, "fit_padding_px", 8)
        scope = (operation.scope or "SELECTED").upper()
        if padding * 2 >= size or scope not in ("SELECTED", "ALL"):
            return False
        status = bpy.ops.uv.suv_fit_to_bounds(scope=scope, padding_px=padding, texture_size=size)
        return "FINISHED" in status

    return {"smart_uv_suite.view_fit_to_bounds": api.Handler(
        fit_tile,
        "Fit UV islands inside their tile and leave the requested pixel padding.",
        "指定したピクセル数の余白を残して、UV アイランドをタイル内に収めます。",
    )}
