import bpy


def _fit(context, op):
    ws = getattr(context.scene, 'suv_workspace', None)
    texture = op.texture_size if op.properties.is_property_set('texture_size') else getattr(ws, 'canvas_size', 2048)
    margin = op.margin_px if op.properties.is_property_set('margin_px') else getattr(ws, 'fit_padding_px', 8)
    scope = (op.scope or 'SELECTED').upper()
    if scope not in {'SELECTED', 'ALL'} or margin * 2 >= texture:
        return False
    return 'FINISHED' in bpy.ops.uv.suv_fit_to_bounds(
        padding_px=margin, texture_size=texture, scope=scope)


def build_handlers(api):
    return {
        'smart_uv_suite.view_fit_to_bounds': api.Handler(_fit, 'Fit selected UV islands into their tile with pixel padding.', 'ピクセル余白を付けて選択 UV アイランドをタイル内に収めます。'),
    }
