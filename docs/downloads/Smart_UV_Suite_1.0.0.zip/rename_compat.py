# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

from __future__ import annotations
from . import resource_api_18168 as _suv_resource
import bpy
from .rename_catalog import OPERATOR_RENAMES

_ALIAS_CLASSES: list[type] = []
_REGISTERED: list[type] = []

def _operator_exists(op_idname: str) -> bool:
    if '.' not in str(op_idname or ''):
        return False
    prefix, name = str(op_idname).split('.', 1)
    try:
        op = getattr(getattr(bpy.ops, prefix), name)
        rna = op.get_rna_type()
        ident = str(getattr(rna, 'identifier', '') or '')
        return bool(ident) and ident not in {'Operator', 'OperatorProperties', 'UnknownType', 'bpy_struct'}
    except Exception:
        return False

def _call_operator(op_idname: str, invoke: bool = False):
    if not _operator_exists(op_idname):
        return {'CANCELLED'}
    prefix, name = op_idname.split('.', 1)
    try:
        op = getattr(getattr(bpy.ops, prefix), name)
        return op('INVOKE_DEFAULT' if invoke else 'EXEC_DEFAULT')
    except TypeError:
        try:
            return op()
        except Exception:
            return {'CANCELLED'}
    except Exception:
        return {'CANCELLED'}

def _make_alias_class(old_id: str, new_id: str, label: str):
    class UVSUITE_OT_legacy_id_alias(bpy.types.Operator):
        bl_idname = old_id
        bl_label = label
        bl_description = 'Legacy UV Suite command ID. Calls the renamed canonical command ID.'
        bl_options = {'INTERNAL'}
        @classmethod
        def poll(cls, context):
            return _operator_exists(new_id)
        def execute(self, context):
            return _call_operator(new_id, invoke=False)
        def invoke(self, context, event):
            return _call_operator(new_id, invoke=True)
    UVSUITE_OT_legacy_id_alias.__name__ = 'UVSUITE_OT_legacy_alias_' + ''.join(ch if ch.isalnum() else '_' for ch in old_id)[:54]
    return UVSUITE_OT_legacy_id_alias

def register():
    """Legacy third-party operator IDs are intentionally not registered."""
    _ALIAS_CLASSES.clear()
    _REGISTERED.clear()
    return

def unregister():
    for cls in reversed(_REGISTERED):
        try:
            _suv_resource.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED.clear(); _ALIAS_CLASSES.clear()
