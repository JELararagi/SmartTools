# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
from __future__ import annotations
from . import resource_api_18168 as _suv_resource
import math
import re
from . import symmetry_atlas_operators as _prev
_IGNORE_KEYS = {'__name__','__package__','__loader__','__spec__','__file__','__cached__','__builtins__'}
globals().update({k: v for k, v in _prev.__dict__.items() if k not in _IGNORE_KEYS})

from .icon_aliases import canonical_icon_stem, iter_available_icon_paths
from . import rename_catalog as _rename_catalog

_SUV_WARNED = set()


def _suv_warn_once(key, *parts):
    if key not in _SUV_WARNED:
        _SUV_WARNED.add(key)
        print(' '.join(str(p) for p in parts))




_SUV_MOVED_ALWAYS_ON_OPERATOR_IDS = {
    'suv.toggle_live_unwrap',
    'uv.suv_uv_sync_mode_toggle',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
}


def _suv_is_moved_always_on_control(op_idname, props=None):
    op_id = str(op_idname or '').strip()
    if op_id in _SUV_MOVED_ALWAYS_ON_OPERATOR_IDS:
        return True
    try:
        props = props or {}
        if op_id == 'uv.suv_native_stage_compat_tools' and str(props.get('mode') or '') == 'BATCH_LIVE_UNWRAP':
            return True
    except Exception:
        pass
    return False

# ============================================================
# UI Panels
# ============================================================

_SUV_REPAIRED_SCENE_IDS = set()


def _suv_scene_token(scene):
    if scene is None:
        return None
    try:
        return int(scene.as_pointer())
    except Exception:
        return id(scene)


def _suv_ensure_workspace_settings(scene=None):
    if scene is None:
        return None
    # Do not mutate workspace RNA from panel draw/access paths.  Older builds
    # repaired and rewrote settings while Blender was drawing the N-panel, which
    # can re-enter redraw/update code in Blender 5.1.  Operators that need to
    # repair settings should call the repair function explicitly before work.
    try:
        return getattr(scene, 'suv_workspace', None)
    except Exception:
        return None


def _suv_ensure_custom_icons_loaded():
    if _SUV_ICON_COLLECTION is not None:
        return
    try:
        _load_custom_icons()
    except Exception:
        pass


def _load_custom_icons():
    global _SUV_ICON_COLLECTION
    if _SUV_ICON_COLLECTION is not None or _bpy_previews is None:
        return
    try:
        pcoll = _suv_resource.register_preview_collection(_bpy_previews)
        if pcoll is None:
            return
        for name, path in iter_available_icon_paths():
            try:
                pcoll.load(name, str(path), 'IMAGE')
            except Exception:
                pass
        _SUV_ICON_COLLECTION = pcoll
    except Exception:
        _SUV_ICON_COLLECTION = None


def _unload_custom_icons():
    global _SUV_ICON_COLLECTION
    if _SUV_ICON_COLLECTION is not None:
        try:
            _suv_resource.unregister_preview_collection(_SUV_ICON_COLLECTION)
        except Exception:
            pass
    _SUV_ICON_COLLECTION = None
    try:
        _SUV_REPAIRED_SCENE_IDS.clear()
    except Exception:
        pass


def _custom_icon_value(name: str) -> int:
    lookup = canonical_icon_stem(name)
    if lookup and _SUV_ICON_COLLECTION is None:
        _suv_ensure_custom_icons_loaded()
    try:
        if _SUV_ICON_COLLECTION and lookup in _SUV_ICON_COLLECTION:
            return _SUV_ICON_COLLECTION[lookup].icon_id
    except Exception:
        pass
    return 0


def _ui_label_text(value, context=None):
    text = str(value or '')
    if not text:
        return text
    fn = globals().get('_suv_ui_text')
    if callable(fn):
        try:
            return str(fn(context or getattr(bpy, 'context', None), text) or text)
        except Exception:
            return text
    return _rename_catalog.apply_text_renames(text, context=context)


def _use_standard_icon_first(fallback_icon='NONE'):
    icon = str(fallback_icon or '').strip().upper()
    return bool(icon) and icon != 'NONE'


def _resolved_icon_value(fallback_icon='NONE', custom_icon=None):
    if _use_standard_icon_first(fallback_icon):
        return 0
    return _custom_icon_value(custom_icon) if custom_icon else 0




def _smart_uv_standard_icon_for_custom(name, fallback='DOT'):
    key = str(name or '').strip().lower()
    fallback_icon = str(fallback or 'DOT').strip().upper() or 'DOT'
    if not key:
        return fallback_icon
    checks = (
        (('help', 'question'), 'QUESTION'),
        (('workspace', 'workflow', 'dashboard', 'cockpit'), 'WINDOW'),
        (('seam', 'cut', 'border'), 'MOD_EDGESPLIT'),
        (('unwrap', 'uvmap', 'uv_', 'tile', 'udim'), 'UV'),
        (('pack', 'layout', 'atlas'), 'PACKAGE'),
        (('align', 'straight', 'orient', 'rectify'), 'PIVOT_BOUNDBOX'),
        (('density', 'texel'), 'SEQ_HISTOGRAM'),
        (('inspect', 'scan', 'issue', 'score', 'quality'), 'VIEWZOOM'),
        (('checker', 'texture'), 'TEXTURE'),
        (('sym', 'mirror', 'flip'), 'MOD_MIRROR'),
        (('stack', 'duplicate'), 'MOD_MULTIRES'),
        (('transfer', 'bridge', 'link'), 'LINK_BLEND'),
        (('bake', 'camera', 'render'), 'RESTRICT_RENDER_OFF'),
        (('settings', 'preset', 'gear', 'option'), 'PREFERENCES'),
        (('save', 'add'), 'ADD'),
        (('delete', 'remove', 'clear'), 'X'),
        (('rotate', 'reset', 'refresh'), 'FILE_REFRESH'),
        (('pin',), 'PINNED'),
        (('magic', 'auto', 'smart'), 'LIGHT'),
        (('mesh', 'cube', 'hard'), 'MESH_CUBE'),
        (('select', 'selection'), 'RESTRICT_SELECT_OFF'),
        (('report', 'document'), 'TEXT'),
    )
    for needles, icon in checks:
        for needle in needles:
            if needle in key:
                return icon
    return fallback_icon


def _label_with_icon(layout, text, fallback_icon='NONE', custom_icon=None):
    text = _ui_label_text(text)
    icon_value = _resolved_icon_value(fallback_icon, custom_icon)
    if icon_value:
        layout.label(text=text, icon_value=icon_value)
    else:
        layout.label(text=text, icon=fallback_icon)


def _smart_tools_popup_bridge():
    try:
        from . import navigation_properties as _navigation_properties
        return _navigation_properties
    except Exception:
        return None


def _smart_tools_use_external_popup(context=None) -> bool:
    bridge = _smart_tools_popup_bridge()
    if bridge is None:
        return False
    fn = getattr(bridge, 'use_external_popup_ui', None)
    if not callable(fn):
        return False
    try:
        return bool(fn(context or getattr(bpy, 'context', None)))
    except Exception:
        return False


def _smart_tools_bridge_operator_id(bridge, getter_name: str) -> str:
    getter = getattr(bridge, getter_name, None) if bridge is not None else None
    if not callable(getter):
        return ''
    try:
        return str(getter() or '')
    except Exception:
        return ''




def _smart_tools_safe_set_props(operator, properties) -> int:
    """Assign the properties supported by a popup or built-in UI operator."""
    if operator is None or not isinstance(properties, dict):
        return 0
    assigned = 0
    for name, value in properties.items():
        try:
            if hasattr(operator, str(name)):
                setattr(operator, str(name), value)
                assigned += 1
        except Exception:
            continue
    return assigned


def _smart_tools_operator_exists(op_idname):
    op_idname = str(op_idname or '').strip()
    if '.' not in op_idname:
        return False
    prefix, opname = op_idname.split('.', 1)
    try:
        op = getattr(getattr(bpy.ops, prefix), opname)
    except Exception:
        return False
    try:
        rna = op.get_rna_type()
        identifier = str(getattr(rna, 'identifier', '') or '')
        return bool(identifier) and identifier not in {'Operator', 'OperatorProperties', 'UnknownType', 'bpy_struct'}
    except Exception:
        return False


def _smart_tools_menu_exists(menu_idname):
    try:
        return isinstance(getattr(bpy.types, str(menu_idname or '').strip(), None), type)
    except Exception:
        return False

def _smart_tools_menu_button(layout, menu_idname, text, fallback_icon='DOWNARROW_HLT', custom_icon=None, popup_width=440, popup_rows=18):
    label = _ui_label_text(text)
    try:
        mapped_menu_label = _rename_catalog.ui_label(menu_idname, context=getattr(bpy, 'context', None))
        if mapped_menu_label and mapped_menu_label != str(menu_idname or ''):
            label = mapped_menu_label
    except Exception:
        pass
    if not _smart_tools_menu_exists(menu_idname):
        try:
            pass  # INFO-note moved to Help; no in-section info-icon explanation.
        except Exception:
            pass
        return None
    icon_value = _resolved_icon_value(fallback_icon, custom_icon)
    if _smart_tools_use_external_popup(getattr(bpy, 'context', None)):
        bridge = _smart_tools_popup_bridge()
        op_id = _smart_tools_bridge_operator_id(bridge, 'popup_menu_operator_id')
        if op_id and _smart_tools_operator_exists(op_id):
            if icon_value:
                op = layout.operator(op_id, text=label, icon_value=icon_value)
            else:
                op = layout.operator(op_id, text=label, icon=fallback_icon)
            _smart_tools_safe_set_props(op, {'menu_idname': str(menu_idname or ''), 'popup_label': label, 'popup_width': int(popup_width or 440), 'popup_rows': int(popup_rows or 18)})
            return op
    try:
        if icon_value:
            return layout.menu(menu_idname, text=label, icon_value=icon_value)
    except Exception:
        pass
    return layout.menu(menu_idname, text=label, icon=fallback_icon)


def _smart_tools_call_menu_button(layout, menu_idname, text, fallback_icon='DOWNARROW_HLT', custom_icon=None, popup_width=440, popup_rows=18):
    label = _ui_label_text(text)
    if not _smart_tools_menu_exists(menu_idname):
        try:
            pass  # INFO-note moved to Help; no in-section info-icon explanation.
        except Exception:
            pass
        return None
    icon_value = _resolved_icon_value(fallback_icon, custom_icon)
    if _smart_tools_use_external_popup(getattr(bpy, 'context', None)):
        return _smart_tools_menu_button(layout, menu_idname, label, fallback_icon=fallback_icon, custom_icon=custom_icon, popup_width=popup_width, popup_rows=popup_rows)
    if icon_value:
        op = layout.operator('wm.call_menu', text=label, icon_value=icon_value)
    else:
        op = layout.operator('wm.call_menu', text=label, icon=fallback_icon)
    _smart_tools_safe_set_props(op, {'name': str(menu_idname or '')})
    return op


def _smart_tools_operator_enum_button(layout, operator_idname, property_idname, text, fallback_icon='NONE', custom_icon=None, popup_width=440, popup_rows=0):
    label = _ui_label_text(text)
    if not _smart_tools_operator_exists(operator_idname):
        try:
            pass  # INFO-note moved to Help; no in-section info-icon explanation.
        except Exception:
            pass
        return None
    icon_value = _resolved_icon_value(fallback_icon, custom_icon)
    if _smart_tools_use_external_popup(getattr(bpy, 'context', None)):
        bridge = _smart_tools_popup_bridge()
        op_id = _smart_tools_bridge_operator_id(bridge, 'popup_operator_enum_operator_id')
        if op_id and _smart_tools_operator_exists(op_id):
            if icon_value:
                op = layout.operator(op_id, text=label, icon_value=icon_value)
            else:
                op = layout.operator(op_id, text=label, icon=fallback_icon)
            _smart_tools_safe_set_props(op, {'operator_idname': str(operator_idname or ''), 'property_idname': str(property_idname or ''), 'popup_label': label, 'popup_width': int(popup_width or 440), 'popup_rows': int(popup_rows or 0)})
            return op
    try:
        if icon_value:
            return layout.operator_menu_enum(operator_idname, property_idname, text=label, icon_value=icon_value)
    except Exception:
        pass
    return layout.operator_menu_enum(operator_idname, property_idname, text=label, icon=fallback_icon)


def _smart_tools_call_menu_pie_button(layout, menu_idname, text, fallback_icon='PRESET', custom_icon=None, popup_width=640, popup_rows=18):
    label = _ui_label_text(text)
    if not _smart_tools_menu_exists(menu_idname):
        try:
            pass  # INFO-note moved to Help; no in-section info-icon explanation.
        except Exception:
            pass
        return None
    icon_value = _resolved_icon_value(fallback_icon, custom_icon)
    if _smart_tools_use_external_popup(getattr(bpy, 'context', None)):
        bridge = _smart_tools_popup_bridge()
        op_id = _smart_tools_bridge_operator_id(bridge, 'popup_menu_pie_proxy_operator_id')
        if op_id and _smart_tools_operator_exists(op_id):
            if icon_value:
                op = layout.operator(op_id, text=label, icon_value=icon_value)
            else:
                op = layout.operator(op_id, text=label, icon=fallback_icon)
            _smart_tools_safe_set_props(op, {'menu_idname': str(menu_idname or ''), 'popup_label': label, 'popup_width': int(popup_width or 640), 'popup_rows': int(popup_rows or 18)})
            return op
    if icon_value:
        op = layout.operator('wm.call_menu_pie', text=label, icon_value=icon_value)
    else:
        op = layout.operator('wm.call_menu_pie', text=label, icon=fallback_icon)
    _smart_tools_safe_set_props(op, {'name': str(menu_idname or '')})
    return op



# Operators moved to the single N-panel "Always-on Toggles" group.
# Keep this filter low-level so legacy menus, dashboard cards, and native-stage
# grids all lose the duplicate buttons without editing every call site.
_SUV_ALWAYS_ON_MOVED_OPERATOR_IDS = {
    'suv.toggle_live_unwrap',
    'uv.suv_uv_sync_mode_toggle',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
}
_SUV_ALWAYS_ON_MOVED_COMPAT_MODES = {
    'BATCH_LIVE_UNWRAP',
}


def _suv_is_moved_always_on_operator(op_idname, props=None) -> bool:
    text = str(op_idname or '').strip()
    if text in _SUV_ALWAYS_ON_MOVED_OPERATOR_IDS:
        return True
    try:
        mode = str((props or {}).get('mode', '') or '')
    except Exception:
        mode = ''
    if text == 'uv.suv_native_stage_compat_tools' and mode in _SUV_ALWAYS_ON_MOVED_COMPAT_MODES:
        return True
    return False


def _operator_button(layout, op_idname, label, fallback_icon='NONE', custom_icon=None, **props):
    if _suv_is_moved_always_on_operator(op_idname, props):
        return None
    label = _ui_label_text(label)
    op_idname = str(op_idname or '')
    try:
        mapped_label = _rename_catalog.operator_label(op_idname, context=getattr(bpy, 'context', None))
        if mapped_label and mapped_label != op_idname:
            label = mapped_label
    except Exception:
        pass
    if _suv_is_moved_always_on_control(op_idname, props):
        return None
    if op_idname == 'wm.call_menu':
        menu_idname = str((props or {}).get('name', '') or '')
        if menu_idname and not _smart_tools_menu_exists(menu_idname):
            try:
                pass  # INFO-note moved to Help; no in-section info-icon explanation.
            except Exception:
                pass
            return None
    elif op_idname == 'wm.call_menu_pie':
        menu_idname = str((props or {}).get('name', '') or '')
        if menu_idname and not _smart_tools_menu_exists(menu_idname):
            try:
                pass  # INFO-note moved to Help; no in-section info-icon explanation.
            except Exception:
                pass
            return None
    elif not _smart_tools_operator_exists(op_idname):
        try:
            pass  # INFO-note moved to Help; no in-section info-icon explanation.
        except Exception:
            pass
        return None
    if _smart_tools_use_external_popup(getattr(bpy, 'context', None)):
        if op_idname == 'wm.call_menu':
            menu_idname = str((props or {}).get('name', '') or '')
            if menu_idname:
                return _smart_tools_call_menu_button(layout, menu_idname, label, fallback_icon=fallback_icon, custom_icon=custom_icon)
        elif op_idname == 'wm.call_menu_pie':
            menu_idname = str((props or {}).get('name', '') or '')
            if menu_idname:
                return _smart_tools_call_menu_pie_button(layout, menu_idname, label, fallback_icon=fallback_icon, custom_icon=custom_icon)
    icon_value = _resolved_icon_value(fallback_icon, custom_icon)
    if icon_value:
        op = layout.operator(op_idname, text=label, icon_value=icon_value)
    else:
        op = layout.operator(op_idname, text=label, icon=fallback_icon)
    prop_defs = getattr(getattr(op, 'bl_rna', None), 'properties', None)
    prop_names = set()
    try:
        prop_names.update(str(k) for k in prop_defs.keys())
    except Exception:
        pass
    try:
        for prop in prop_defs or ():
            ident = str(getattr(prop, 'identifier', '') or '')
            if ident:
                prop_names.add(ident)
    except Exception:
        pass
    for k, v in (props or {}).items():
        k = str(k)
        if k not in prop_names:
            continue
        try:
            setattr(op, k, v)
        except Exception:
            pass
    return op


def _create_box(layout, title, icon='NONE', custom_icon=None):
    box = layout.box()
    col = box.column(align=True)
    row = col.row(align=True)
    row.alignment = 'LEFT'
    _label_with_icon(row, _ui_label_text(title), icon, custom_icon)
    col.separator(factor=0.35)
    return box, col



_TEXT.update({
    "ui.section.dashboard": ("Quick Start", "クイックスタート"),
    "ui.section.properties": ("Properties", "プロパティ"),
    "ui.section.unwrap_tools": ("Unwrap Tools", "展開ツール"),
    "ui.section.transform_tools": ("Arrange & Transform", "整列＆変形"),
    "ui.section.layout_tools": ("Packing & Layout", "パッキング＆レイアウト"),
    "ui.section.selection_tools": ("Selection & Sets", "選択＆セット"),
    "ui.section.density_tools": ("Density & QA", "密度＆検査"),
    "ui.section.preview_tools": ("Preview & UV Maps", "プレビュー＆UVマップ"),
    "ui.section.sym_tools": ("Symmetry & Transfer", "対称＆転送"),
    "ui.section.atlas_tools": ("Atlas & Bake", "アトラス＆ベイク"),
    "ui.label.core": ("Core", "基本"),
    "ui.label.advanced": ("Advanced", "高度"),
    "ui.label.cleanup": ("Cleanup", "クリーンアップ"),
    "ui.label.setup": ("Setup", "設定"),
    "ui.active_uv": ("Active UV: {name}", "アクティブUV: {name}"),
    "ui.mesh_count": ("Selected Meshes: {n}", "選択メッシュ数: {n}"),
    "ui.uv_maps": ("UV Maps: {n}", "UVマップ数: {n}"),
    "ui.last_density": ("Last Density: {d:.1f} px/m", "前回密度: {d:.1f} px/m"),
    "ui.quickstart_hint": ("Recommended flow: Seams → Unwrap → Relax → Pack", "おすすめ手順: シーム → 展開 → リラックス → パック"),
    "ui.unwrap_hint": ("Simple tools first, then precise tools.", "まず簡単な展開、その後に精密調整。"),
    "ui.transform_hint": ("Move islands into a clean readable layout.", "アイランドを見やすく整理します。"),
    "ui.layout_hint": ("Finish the layout with stack, distribute and pack.", "スタック・分布・パックで最終レイアウトを整えます。"),
    "ui.selection_hint": ("Fast helpers for selecting and reusing UV work sets.", "選択支援と作業セット再利用。"),
    "ui.density_hint": ("Control texel density and catch UV problems.", "テクセル密度管理とUV問題の検出。"),
    "ui.preview_hint": ("Preview checker patterns and manage UV channels.", "チェッカー確認とUVチャンネル管理。"),
    "ui.sym_hint": ("Mirror and transfer UVs for repeated shapes.", "繰り返し形状向けのミラーと転送。"),
    "ui.atlas_hint": ("Multi-object atlas workflow and baking.", "複数オブジェクト向けのアトラスとベイク。"),
    "ui.menu.maintenance": ("Maintenance", "メンテナンス"),
    "ui.menu.workflow_bundles": ('Workflow Bundles Menu', "ワークフローバンドル"),
    "ui.menu.projection_tools": ('Projection Tools Menu', "投影ツール"),
    "ui.menu.workflow_more": ('Workflow More Menu', 'ワークフローMoreメニュー'),
    "ui.menu.seam_sets": ('Seam Sets Menu', "シームセット"),
    "ui.menu.refine_cleanup": ("Refine & Cleanup", "微調整＆修復"),
    "ui.menu.transform_more": ('Transform More Menu', "変形詳細"),
    "ui.menu.hard_surface": ("Hard Surface", "ハードサーフェス"),
    "ui.menu.batch_udim": ("Batch UDIM", "一括UDIM"),
    "ui.menu.layout_sets": ('Layout Sets Menu', "レイアウトセット"),
    "ui.menu.layout_more": ('Layout More Menu', "レイアウト詳細"),
    "ui.menu.selection_more": ('Selection More Menu', "選択詳細"),
    "ui.menu.selection_sets": ('Selection Sets Menu', "選択セット"),
    "ui.menu.density_profiles": ('Density Profiles Menu', '密度プロファイルメニュー'),
    "ui.menu.inspector_profiles": ('Inspector Profiles Menu', 'インスペクタープロファイルメニュー'),
    "ui.menu.batch_density": ("Batch Density", "一括密度"),
    "ui.menu.density_more": ('Density More Menu', "密度詳細"),
    "ui.menu.uv_stack": ("UV Stack", "UVスタック"),
    "ui.menu.batch_uv_layers": ("Batch UV Layers", "一括UVレイヤー"),
    "ui.menu.uv_preview": ("UV Preview", "UVプレビュー"),
    "ui.menu.symmetry_more": ('Symmetry More Menu', "対称詳細"),
    "ui.menu.atlas_more": ('Atlas More Menu', "アトラス詳細"),
    "ui.menu.external_compat": ('External Compatibility Menu', '外部互換メニュー'),
    "ui.fit_padding": ("Fit Padding", "フィット余白"),
    "ui.checker_size": ("Checker Size", "チェッカーサイズ"),
    "ui.checker_image": ("Checker Image", "チェッカー画像"),
    "ui.checker_material": ("Checker Material", "チェッカーマテリアル"),
    "ui.new_uv_name": ("New UV Name", "新規UV名"),
    "ui.quick_checker": ("Checker", "チェッカー"),
    "ui.quick_auto": ("Auto Unwrap", "自動展開"),
    "ui.quick_pack": ("Pack", "パック"),
    "ui.quick_scan": ("Scan", "スキャン"),
    "ui.align_u_center": ("Align U Center", "U中央揃え"),
    "ui.align_v_center": ("Align V Center", "V中央揃え"),
    "ui.centralize": ('Center Islands', "中央配置"),
    "ui.orient_edge": ("Orient to Edge", "辺に整向"),
    "ui.rotate_left": ("Rotate -90°", "-90°回転"),
    "ui.rotate_right": ("Rotate 90°", "90°回転"),
    "ui.flip_u": ("Flip U", "U反転"),
    "ui.flip_v": ("Flip V", "V反転"),
    "ui.issue_flipped": ("Select Flipped", "反転を選択"),
    "ui.issue_overlap": ("Select Overlap", "重なりを選択"),
    "op.align_islands": ("Align Islands", "アイランド整列"),
    "op.centralize": ('Center Islands', "中央配置"),
    "op.sel_identical": ("Select Identical", "同一を選択"),
    "op.distribute_islands": ("Distribute Islands", "アイランド分布"),
    "op.fit_bounds": ("Fit to Bounds", "領域にフィット"),
    "op.rotate_islands": ("Rotate Islands", "アイランド回転"),
    "op.flip_islands": ("Flip Islands", "アイランド反転"),
    "op.orient_islands": ("Orient Islands", "アイランド整向"),
    "op.randomize_islands": ("Randomize Islands", "アイランドランダム化"),
    "op.clear_pins": ("Clear Pins", "ピン解除"),
    "op.clear_seams": ("Clear Seams", "シーム解除"),
    "op.udim_crossing": ("Select UDIM Crossing", "UDIM跨ぎを選択"),
    "op.checker_material": ("Checker", "チェッカー"),
    "op.uv_add": ("Add UV Map", "UVマップ追加"),
    "op.uv_duplicate": ("Duplicate UV Map", "UVマップ複製"),
    "op.uv_remove": ("Remove Active UV", "アクティブUV削除"),
    "msg.align_done": ("Aligned {n} islands.", "{n} 個のアイランドを整列しました。"),
    "msg.center_done": ("Centralized {n} islands.", "{n} 個のアイランドを中央配置しました。"),
    "msg.orient_edge_done": ("Oriented {n} islands to the selected edge.", "{n} 個のアイランドを選択辺に合わせて整向しました。"),
    "msg.sel_identical_done": ("Selected {n} identical islands.", "{n} 個の同一アイランドを選択しました。"),
    "msg.need_selected_edge": ("Select at least one UV edge.", "1本以上のUV辺を選択してください。"),
    "msg.distribute_done": ("Distributed {n} islands.", "{n} 個のアイランドを分布しました。"),
    "msg.fit_done": ("Fitted selected UVs to bounds.", "選択UVを領域にフィットしました。"),
    "msg.rotate_done": ("Rotated {n} islands.", "{n} 個のアイランドを回転しました。"),
    "msg.flip_done": ("Flipped {n} islands.", "{n} 個のアイランドを反転しました。"),
    "msg.orient_done": ("Oriented {n} islands.", "{n} 個のアイランドを整向しました。"),
    "msg.randomize_done": ("Randomized {n} islands.", "{n} 個のアイランドをランダム化しました。"),
    "msg.clear_pins_done": ("Cleared {n} pins.", "{n} 個のピンを解除しました。"),
    "msg.clear_seams_done": ("Cleared {n} seam edges.", "{n} 本のシームを解除しました。"),
    "msg.udim_crossing_done": ("Selected {n} UDIM-crossing islands.", "{n} 個のUDIM跨ぎアイランドを選択しました。"),
    "msg.checker_done": ("Checker material created and assigned.", "チェッカーマテリアルを作成して適用しました。"),
    "msg.uv_add_done": ("UV map created: {name}", "UVマップを作成: {name}"),
    "msg.uv_add_done_multi": ("Created {n} UV maps: {name}", "{n} 個のUVマップを作成: {name}"),
    "msg.uv_dup_done": ("UV map duplicated: {name}", "UVマップを複製: {name}"),
    "msg.uv_remove_done": ("Removed UV map: {name}", "UVマップを削除: {name}"),
})

_TEXT.update({
    "ui.mode.title": ("Workspace Layout", "ワークスペース表示"),
    "ui.mode.simple": ("Workflow", "ワークフロー"),
    "ui.mode.detail": ("Workflow", "ワークフロー"),
    "ui.mode.help": ("Show Help", "ヘルプ表示"),
    "ui.mode.help_hint": ("The panel shows the main UV workflow as grouped icon-first sections.", "主要なUV作業を、ジャンル別のアイコン中心セクションで表示します。"),
    "ui.mode.tab": ("Tool Tab", "ツールタブ"),
    "ui.tab.all": ("All", "全表示"),
    "ui.tab.workflow": ("Workflow", "ワークフロー"),
    "ui.tab.transform": ("Transform", "変形"),
    "ui.tab.layout": ('Layout Panel', 'レイアウトパネル'),
    "ui.tab.analyze": ("Analyze", "解析"),
    "ui.tab.maps": ("Maps", "UVマップ"),
    "ui.tab.symmetry": ("Symmetry", "対称"),
    "ui.tab.atlas": ("Atlas", "アトラス"),
    "ui.label.start": ("1. Start", "1. 開始"),
    "ui.label.refine": ("2. Refine", "2. 調整"),
    "ui.label.finish": ("3. Finish", "3. 仕上げ"),
    "ui.quick_relax": ("Relax", "リラックス"),
    "ui.quick_seams": ("Seams", "シーム"),
    "ui.auto_seam_angle": ("Angle Seams", "角度シーム"),
    "ui.auto_seam_sharp": ("Sharp Seams", "シャープシーム"),
    "ui.auto_seam_material": ("Material Seams", "マテリアルシーム"),
    "ui.auto_seam_boundary": ("Boundary Seams", "境界シーム"),
    "ui.trim_row": ("Trim Row", "トリム行配置"),
    "ui.trim_column": ("Trim Column", "トリム列配置"),
    "ui.label.auto_seams": ("Auto Seam Modes", "自動シームモード"),
    "ui.label.trim": ("Trim / Strip Layout", "トリム／ストリップ配置"),
    "op.auto_seam_advanced": ('Auto Mark Advanced Seams', "自動シーム拡張"),
    "op.trim_strip": ('Layout Trim Strip', "トリムストリップ配置"),
    "msg.auto_seam_done": ("Marked {n} seams with mode {mode}.", "{mode} モードで {n} 本のシームを付けました。"),
    "msg.trim_done": ("Arranged {n} islands into a trim strip.", "{n} 個のアイランドをトリム状に配置しました。"),
})



_TEXT.update({
    "ui.label.hardsurface": ("5. Hard Surface", "5. ハードサーフェス"),
    "ui.align_u_min": ("Align U Min", "U最小揃え"),
    "ui.align_u_max": ("Align U Max", "U最大揃え"),
    "ui.align_v_min": ("Align V Min", "V最小揃え"),
    "ui.align_v_max": ("Align V Max", "V最大揃え"),
    "ui.ortho_islands": ('Orthogonalize UVs', "直交化"),
    "ui.gridify_islands": ("Gridify", "グリッド化"),
    "ui.squareify_islands": ("Square Fit", "正方形化"),
    "ui.quad_flow": ("Quad Flow", "クアッドフロー"),
    "ui.rectify_adv": ('Fit Rectified Shape', "矩形フィット"),
    "msg.ortho_done": ("Orthogonalized {n} islands.", "{n} 個のアイランドを直交化しました。"),
    "msg.gridify_done": ("Gridified {n} islands.", "{n} 個のアイランドをグリッド化しました。"),
    "msg.squareify_done": ("Square-fitted {n} islands.", "{n} 個のアイランドを正方形化しました。"),
    "msg.quad_flow_done": ("Quad Flow finished.", "クアッドフローを実行しました。"),
    "msg.rectify_adv_done": ("Rectify Fit processed {n} islands.", "{n} 個のアイランドに矩形フィットを適用しました。"),
})

_TEXT.update({
    "ui.label.lineflow": ("4. UV Line & Flow", "4. UVライン＆フロー"),
    "ui.chain_group_mode": ("Align Scope", "整列スコープ"),
    "ui.flow_strength": ("Flow Strength", "フロー強度"),
    "ui.axis_mode": ("Axis Basis", "軸基準"),
    "ui.endpoint_mode": ("Endpoints", "端点"),
    "ui.straight_line": ('Straighten Line', "直線化"),
    "ui.distribute_even": ("Distribute Evenly", "均等配置"),
    "ui.annotate_align": ('Align to Annotation', "アノテート線に整列"),
    "ui.set_flow": ("Set Flow", "フロー設定"),
    "msg.need_uv_chain": ("Select a UV chain or a set of UV points.", "UVチェーンまたは複数のUV点を選択してください。"),
    "msg.chain_done": ("Aligned {n} UV points.", "{n} 個のUV点を整列しました。"),
    "msg.annotate_done": ("Aligned {n} UV points to the annotation.", "{n} 個のUV点をアノテート線へ整列しました。"),
    "msg.flow_done": ("Adjusted flow for {n} UV points.", "{n} 個のUV点にフロー設定を適用しました。"),
    "msg.need_annotation": ("No active annotation stroke found in the UV editor.", "UVエディター内にアクティブなアノテート線が見つかりません。"),
    "msg.need_two_uv_points": ("Select at least 2 UV points.", "2つ以上のUV点を選択してください。"),
    "msg.need_three_uv_points": ("Select at least 3 UV points.", "3つ以上のUV点を選択してください。"),
})


_TEXT.update({
    "ui.section.workflow_tools": ("Workflow Hub", "ワークフローハブ"),
    "ui.workflow_hint": ("Presets, native unwrap/project tools, stitch helpers and tile nudging in one place.", "プリセット、標準展開／投影、縫合補助、タイル移動をまとめたハブです。"),
    "ui.label.presets": ("Presets", "プリセット"),
    "ui.label.projection": ("Projection & Unwrap", "投影＆展開"),
    "ui.label.stitch": ('Stitch UVs', "縫合／ピン／シーム"),
    "ui.label.tiles": ("Tile Move", "タイル移動"),
    "ui.canvas_size": ("Canvas Size", "キャンバスサイズ"),
    "ui.workflow_density": ("Workflow Density", "ワークフロー密度"),
    "ui.workflow_pack": ("Pack After", "後でパック"),
    "ui.workflow_relax": ("Relax After", "後でリラックス"),
    "op.native_unwrap_abf": ("Unwrap ABF", "ABF で展開"),
    "op.native_unwrap_lscm": ("Unwrap LSCM", "LSCM で展開"),
    "op.native_min_stretch": ("Min Stretch", "最小ストレッチ"),
    "op.native_smart_project": ("Smart Project", "Smart Project"),
    "op.native_lightmap": ("Lightmap", "ライトマップ"),
    "op.native_follow_quads": ("Follow Active Quads", "アクティブ四角面追従"),
    "op.native_view": ("Project View", "ビュー投影"),
    "op.native_view_bounds": ("View Bounds", "ビュー境界投影"),
    "op.native_cube": ("Cube", "キューブ"),
    "op.native_cylinder": ("Cylinder", "シリンダー"),
    "op.native_sphere": ("Sphere", "スフィア"),
    "op.native_pin": ("Pin", "ピン"),
    "op.native_unpin": ("Unpin", "ピン解除"),
    "op.native_stitch": ('Stitch UVs', "ステッチ"),
    "op.native_weld": ("Weld", "ウェルド"),
    "op.native_seams_from_islands": ("Seams from Islands", "アイランドからシーム"),
    "op.native_mark_seam": ("Mark Seam", "シームを付与"),
    "op.native_clear_seam": ("Clear Seam", "シーム解除"),
    "op.udim_left": ("Tile -U", "タイル -U"),
    "op.udim_right": ("Tile +U", "タイル +U"),
    "op.udim_down": ("Tile -V", "タイル -V"),
    "op.udim_up": ("Tile +V", "タイル +V"),
    "msg.native_projection_done": ("Core UV tool finished: {name}", "標準UVツール完了: {name}"),
    "msg.native_action_done": ("Action finished: {name}", "処理完了: {name}"),
    "msg.udim_step_done": ("Moved {n} islands by tile offset ({u}, {v}).", "{n} 個のアイランドをタイルオフセット ({u}, {v}) だけ移動しました。"),
})


_TEXT.update({
    "ui.label.similarity": ("Similarity & Grouping", "類似＆グループ化"),
    "ui.group_stack_similar": ("Stack Similar", "類似をスタック"),
    "ui.group_stack_identical": ("Stack Identical", "同一をスタック"),
    "ui.group_tiles_material": ("Groups → Tiles (Material)", "グループ→タイル（マテリアル）"),
    "ui.group_tiles_similar": ("Groups → Tiles (Similar)", "グループ→タイル（類似）"),
    "ui.group_tiles_identical": ("Groups → Tiles (Identical)", "グループ→タイル（同一）"),
    "ui.scan_summary": ("Latest Scan Summary", "最新スキャン結果"),
    "ui.scan_report": ("Write Report", "レポート出力"),
    "ui.scan_select_all": ("Select All Issues", "問題を全選択"),
    "ui.pack_group_mode": ("Pack Group Mode", "パックのグループ基準"),
    "ui.pack_group_layout": ("Group Layout", "グループ配置"),
    "ui.pack_groups": ("Pack Groups", "グループをパック"),
    "ui.issue_stretch": ("Select Stretch", "ストレッチを選択"),
    "ui.stretch_threshold": ("Stretch Threshold", "ストレッチしきい値"),
    "ui.scan_worst_stretch": ("Worst Stretch", "最大ストレッチ"),
    "ui.scan_avg_stretch": ("Avg Stretch", "平均ストレッチ"),
    "ui.stack_group_mode": ("Stack Group Mode", "スタックのグループ基準"),
    "ui.sim_area_tol": ("Area Tolerance", "面積許容差"),
    "ui.sim_aspect_tol": ("Aspect Tolerance", "縦横比許容差"),
    "ui.scan_report_name": ("Report Text", "レポートテキスト名"),
    "msg.stack_group_done": ("Grouped stack finished: {g} groups, {n} islands stacked.", "グループスタック完了：{g} グループ、{n} 個をスタックしました。"),
    "msg.groups_to_tiles_done": ("Moved {g} groups into {t} tiles.", "{g} グループを {t} タイルへ配置しました。"),
    "msg.pack_groups_done": ("Packed {g} groups / {n} islands with grouped layout.", "{g} グループ / {n} 個をグループ配置でパックしました。"),
    "msg.scan_report_done": ("Inspector report written: {name}", "検査レポートを書き出しました: {name}"),
    "ui.label.hotspot": ("Hotspot / Cell Layout", "ホットスポット／セル配置"),
    "ui.hotspot_grid": ("Hotspot Grid", "ホットスポット配置"),
    "ui.hotspot_cols": ("Columns", "列数"),
    "ui.hotspot_rows": ("Rows", "行数"),
    "ui.hotspot_keep_aspect": ("Keep Aspect", "縦横比維持"),
    "ui.hotspot_sort": ("Sort", "並び順"),
    "ui.label.hotspot_presets": ("Trim / Hotspot Presets", "トリム／ホットスポットプリセット"),
    "ui.label.hotspot_named": ("Named Layout Libraries", "名前付きレイアウトライブラリ"),
    "ui.hotspot_fill": ("Fill Order", "配置順"),
    "ui.hotspot_lib_arch_basic": ("Arch Trim Basic", "建築トリム 基本"),
    "ui.hotspot_lib_arch_dense": ("Arch Trim Dense", "建築トリム 高密度"),
    "ui.hotspot_lib_sci_panel": ("Sci-Fi Panels", "SFパネル"),
    "ui.hotspot_lib_prop_balanced": ("Prop Sheet Balanced", "小物シート 標準"),
    "ui.hotspot_lib_prop_dense": ("Prop Sheet Dense", "小物シート 高密度"),
    "ui.hotspot_lib_decal_strip": ("Decal Strip Wide", "デカール帯 横長"),
    "ui.hotspot_lib_decal_column": ("Decal Column Tall", "デカール帯 縦長"),
    "ui.hotspot_lib_micro_atlas": ("Micro Atlas", "マイクロアトラス"),
    "ui.hotspot_preset_trim2": ("Trim 1×2", "トリム 1×2"),
    "ui.hotspot_preset_trim3": ("Trim 1×3", "トリム 1×3"),
    "ui.hotspot_preset_trim4": ("Trim 1×4", "トリム 1×4"),
    "ui.hotspot_preset_trim6": ("Trim 1×6", "トリム 1×6"),
    "ui.hotspot_preset_trim8": ("Trim 1×8", "トリム 1×8"),
    "ui.hotspot_preset_col4": ("Column 1×4", "縦列 1×4"),
    "ui.hotspot_preset_col6": ("Column 1×6", "縦列 1×6"),
    "ui.hotspot_preset_grid22": ("Grid 2×2", "グリッド 2×2"),
    "ui.hotspot_preset_grid24": ("Grid 2×4", "グリッド 2×4"),
    "ui.hotspot_preset_grid33": ("Grid 3×3", "グリッド 3×3"),
    "ui.hotspot_preset_grid34": ("Grid 3×4", "グリッド 3×4"),
    "ui.hotspot_preset_grid44": ("Grid 4×4", "グリッド 4×4"),
    "ui.hotspot_preset_atlas44": ("Atlas 4×4", "アトラス 4×4"),
    "ui.hotspot_preset_atlas88": ("Atlas 8×8", "アトラス 8×8"),
    "ui.label.stretch_visual": ("Stretch Visualize", "ストレッチ可視化"),
    "ui.stretch_heatmap": ("Build Heatmap", "ヒートマップ作成"),
    "ui.clear_heatmap": ("Clear Heatmap", "ヒートマップ削除"),
    "ui.heatmap_max": ("Heatmap Max", "ヒートマップ最大値"),
    "ui.heatmap_attr": ("Heatmap Attribute", "ヒートマップ属性名"),
    "ui.heatmap_material": ("Heatmap Material", "ヒートマップ材質名"),
    "msg.hotspot_done": ("Placed {n} islands into a {c}x{r} hotspot grid.", "{n} 個のアイランドを {c}x{r} のホットスポットグリッドへ配置しました。"),
    "msg.hotspot_preset_done": ("Applied hotspot preset: {name}", "ホットスポットプリセットを適用しました: {name}"),
    "msg.hotspot_library_done": ("Applied layout library: {name}", "レイアウトライブラリを適用しました: {name}"),
    "msg.heatmap_done": ("Built stretch heatmap on {o} object(s), {n} island(s).", "{o} 個のオブジェクト、{n} 個のアイランドにストレッチヒートマップを作成しました。"),
    "msg.heatmap_clear_done": ("Removed stretch heatmap from {o} object(s).", "{o} 個のオブジェクトからストレッチヒートマップを削除しました。"),
})


_TEXT.update({
    "ui.label.diagnostics": ("Diagnostics & Recovery", "診断と復旧"),
    "ui.health_status": ("Health", "状態"),
    "ui.health_checked": ("Checked", "確認日時"),
    "ui.health_icons": ("Icons", "アイコン"),
    "ui.health_cache": ("Cache Entries", "キャッシュ件数"),
    "ui.health_missing_uv": ("Missing UV Meshes", "UV未作成メッシュ数"),
    "ui.health_missing_active": ("Meshes without Active UV", "アクティブUV未設定メッシュ数"),
    "ui.health_issue_count": ("Issue Count", "問題件数"),
    "ui.health_message": ("Summary", "要約"),
    "ui.health_ok": ("OK", "正常"),
    "ui.health_warn": ("Warning", "注意"),
    "ui.health_error": ("Error", "エラー"),
    "op.workspace_validate": ("Validate Workspace", "ワークスペース検証"),
    "op.workspace_repair": ("Auto Repair Workspace", "ワークスペース自動修復"),
    "op.reload_icons": ("Reload Icons", "アイコン再読込"),
    "op.write_snapshot": ("Write Snapshot", "スナップショット出力"),
    "op.clear_tool_runtime_log": ("Clear Runtime Log", "実行ログをクリア"),
    "op.clear_batch_report": ("Clear Batch Report", "バッチレポートをクリア"),
    "op.open_tool_runtime_log": ("Open Runtime Log", "実行ログを開く"),
    "op.open_batch_report": ("Open Batch Report", "バッチレポートを開く"),
    "op.open_scan_report": ("Open Scan Report", "検査レポートを開く"),
    "op.open_last_snapshot": ("Open Last Snapshot", "最後のスナップショットを開く"),
    "op.open_support_bundle": ("Open Support Bundle", "サポートバンドルを開く"),
    "op.write_support_bundle": ("Write Support Bundle", "サポートバンドル出力"),
    "op.clear_all_reports": ("Clear All Reports", "全レポートをクリア"),
    "op.open_validation_report": ("Open Validation Report", "検証レポートを開く"),
    "op.collect_support_bundle": ("Collect Diagnostics", "診断を収集"),
    "op.copy_support_bundle": ("Copy Support Bundle", "サポートバンドルをコピー"),
    "op.copy_scan_report": ("Copy Scan Report", "検査レポートをコピー"),
    "op.copy_validation_report": ("Copy Validation Report", "検証レポートをコピー"),
    "ui.health_last_operator": ("Last Operator", "最後の実行オペレーター"),
    "ui.health_last_error": ("Last Error", "最後のエラー"),
    "ui.tool_runtime_log_name": ("Runtime Log", "実行ログ"),
    "ui.batch_report_name": ("Batch Report", "バッチレポート"),
    "ui.scan_report_name_diag": ("Scan Report", "検査レポート"),
    "ui.last_snapshot_name": ("Last Snapshot", "最後のスナップショット"),
    "ui.support_bundle_name": ("Support Bundle", "サポートバンドル"),
    "ui.validation_report_name": ("Validation Report", "検証レポート"),
    "ui.batch_last_summary": ("Last Batch", "最後のバッチ結果"),
    "ui.batch_error_policy": ("Batch Error Policy", "バッチエラー方針"),
    "ui.batch_snapshot_policy": ("Batch Snapshot Policy", "バッチスナップショット方針"),
    "msg.workspace_validate": ("Workspace check finished: {status} ({issues} issue(s))", "ワークスペース検証が完了しました: {status}（問題 {issues} 件）"),
    "msg.workspace_repair": ("Workspace repair finished. Created UVs: {uvs}, cache reset: {cache}, icons reloaded: {icons}", "ワークスペース修復が完了しました。作成UV数: {uvs}、キャッシュ初期化: {cache}、アイコン再読込: {icons}"),
    "msg.icons_reloaded": ("Custom icons reloaded ({count})", "カスタムアイコンを再読込しました（{count} 個）"),
    "msg.snapshot_written": ("Workspace snapshot written: {name}", "ワークスペーススナップショットを書き出しました: {name}"),
    "msg.tool_runtime_log_cleared": ("Runtime log cleared: {name}", "実行ログをクリアしました: {name}"),
    "msg.batch_report_cleared": ("Batch report cleared: {name}", "バッチレポートをクリアしました: {name}"),
    "msg.text_opened": ("Opened text datablock: {name}", "テキストデータを開きました: {name}"),
    "msg.report_missing": ("No diagnostics text available yet for: {name}", "まだ利用できる診断テキストがありません: {name}"),
    "msg.support_bundle_written": ("Support bundle written: {name}", "サポートバンドルを書き出しました: {name}"),
    "msg.all_reports_cleared": ("Diagnostics reports cleared.", "診断レポートをクリアしました。"),
    "msg.validation_report_written": ("Validation report written: {name}", "検証レポートを書き出しました: {name}"),
    "msg.scan_report_bundle_written": ("Scan report refreshed: {name}", "検査レポートを更新しました: {name}"),
    "msg.text_copied": ("Copied text to clipboard: {name}", "テキストをクリップボードへコピーしました: {name}"),
    "msg.collect_bundle_done": ("Diagnostics collected. Bundle: {bundle}", "診断収集が完了しました。バンドル: {bundle}"),
})



_TEXT.update({
    "ui.toggle.dashboard": ("Visual Dashboard", "ビジュアルダッシュボード"),
    "ui.toggle.gallery": ("Reference Gallery", "リファレンスギャラリー"),
    "ui.toggle.help": ("Inline Help", "インラインヘルプ"),
    "ui.section.guide": ("Visual Guide", "ビジュアルガイド"),
    "ui.guide.current_tab": ("Current Focus: {name}", "現在の重点: {name}"),
    "ui.guide.ready": ("Ready", "準備OK"),
    "ui.guide.attention": ("Attention", "要確認"),
    "ui.guide.none": ("No Mesh", "メッシュなし"),
    "ui.guide.issues": ("Issues: {n}", "問題数: {n}"),
    "ui.guide.active_uv": ("UV: {name}", "UV: {name}"),
    "ui.guide.meshes": ("Meshes: {n}", "メッシュ数: {n}"),
    "ui.guide.step_cut": ("1. Cut", "1. 切る"),
    "ui.guide.step_align": ("2. Align", "2. 整える"),
    "ui.guide.step_pack": ("3. Pack", "3. 詰める"),
    "ui.guide.step_check": ("4. Check", "4. 確認"),
    "ui.guide.cut_hint": ("Seams and unwrap basics", "シームと基本展開"),
    "ui.guide.align_hint": ("Straighten, orient and flow", "直線化・整向・フロー"),
    "ui.guide.pack_hint": ("Stack, trim, hotspot, UDIM", "スタック・トリム・ホットスポット・UDIM"),
    "ui.guide.check_hint": ("Density, checker and inspector", "密度・チェッカー・検査"),
    "ui.guide.tab.workflow.1": ("Start with presets, seams and native unwrap/project tools.", "最初にプリセット、シーム、標準展開／投影を使います。"),
    "ui.guide.tab.workflow.2": ("Use external-compat recipes when you want familiar flows from other UV tools.", "他ツール風の流れが欲しい時は外部互換レシピを使います。"),
    "ui.guide.tab.workflow.3": ("Best for first-pass layout before detailed straightening or packing.", "詳細調整や最終パック前の一次整理に向いています。"),
    "ui.guide.tab.transform.1": ("Use straightening, align and hard-surface cleanup after the first unwrap.", "一次展開の後に、直線化・整列・ハードサーフェス整形を使います。"),
    "ui.guide.tab.transform.2": ("Chain and flow tools are for strips, trims, cables and clean borders.", "チェーン／フローツールはトリム、帯、ケーブル、きれいな境界向けです。"),
    "ui.guide.tab.transform.3": ("Choose simple tools first, then move to Gridify, Rectify or Quad Flow.", "まず簡単な整列から始め、必要なら Gridify / Rectify / Quad Flow へ進みます。"),
    "ui.guide.tab.layout.1": ("Finish the UV with packing, stacking, hotspot cells and tile moves.", "パック、スタック、ホットスポット、タイル移動で仕上げます。"),
    "ui.guide.tab.layout.2": ("Grouped layout helps repeated parts, trimsheet assets and UDIM organization.", "グループ配置は反復パーツ、トリムシート、UDIM整理に向いています。"),
    "ui.guide.tab.layout.3": ("Use deterministic pack for stable repeatable results.", "安定して再現したい時は決定的パックを使います。"),
    "ui.guide.tab.analyze.1": ("Measure density, preview stretch heatmaps and run issue scans here.", "ここでは密度測定、ストレッチ可視化、問題スキャンを行います。"),
    "ui.guide.tab.analyze.2": ("Use checker first when something feels wrong, then inspector for exact selection.", "違和感がある時は先にチェッカー、その後に検査で正確に絞り込みます。"),
    "ui.guide.tab.analyze.3": ("Good final pass before export, bake or atlas work.", "書き出しやベイク、アトラス前の最終確認に向いています。"),
    "ui.guide.tab.maps.1": ("Manage checker previews, UV maps and quick texture review here.", "ここではチェッカー確認、UVマップ管理、簡易テクスチャ確認を行います。"),
    "ui.guide.tab.maps.2": ("Useful when assets need multiple channels such as texture and lightmap UVs.", "テクスチャ用とライトマップ用など複数チャンネルが必要な時に便利です。"),
    "ui.guide.tab.maps.3": ("Create, duplicate and validate maps before destructive operations.", "大きな操作の前に UV マップの作成・複製・確認を行います。"),
    "ui.guide.tab.symmetry.1": ("Find mirrored pairs and transfer, mirror or stack their UVs.", "左右対称ペアを見つけて、転送・ミラー・スタックを行います。"),
    "ui.guide.tab.symmetry.2": ("Best for characters, vehicles and repeated hard-surface elements.", "キャラクター、車両、反復ハードサーフェスに向いています。"),
    "ui.guide.tab.symmetry.3": ("Run before final packing so mirrored parts stay consistent.", "対称部品の整合性を保つため、最終パック前に実行します。"),
    "ui.guide.tab.atlas.1": ("Build shared atlas UVs and prepare batch bake flows here.", "共有アトラスUVの構築と一括ベイク準備を行います。"),
    "ui.guide.tab.atlas.2": ("Use after per-object cleanup is finished.", "各オブジェクトの整理が終わった後に使います。"),
    "ui.guide.tab.atlas.3": ("Ideal for game props, modular kits and shared materials.", "ゲーム小物、モジュラーキット、共有マテリアル向けです。"),
    "ui.guide.tab.all.1": ("All tabs are visible. Use the main tab switch when you want a smaller focused workspace.", "全タブ表示です。作業を絞りたい時はメインタブ切替を使います。"),
    "ui.guide.tab.all.2": ("Recommended order: Cut → Align → Pack → Check.", "おすすめ順は 切る → 整える → 詰める → 確認 です。"),
    "ui.guide.tab.all.3": ("Turn on Inline Help when learning a new area of the suite.", "新しい機能群を覚える時はインラインヘルプを有効にします。"),
})

_TEXT.update({
    "ui.section.bridge_tools": ("Standard Integration", "標準連携"),
    "ui.bridge_hint": ("Migrated tools that are still useful beyond the suite's native workflow.", "既存ワークフローにない有用な移植ツールです。"),
})

_TEXT.update({
    "ui.section.recipes": ("Visual Recipes", "目的別レシピ"),
    "ui.recipes.hint": ("Pick a goal and start from a compact recipe card instead of browsing the whole toolset.", "ツール全体を探す代わりに、目的に合うコンパクトなレシピカードから開始できます。"),
    "ui.recipe.organic.title": ("Organic", "有機形状"),
    "ui.recipe.organic.1": ("Good first pass for characters and soft forms", "キャラクターや柔らかい形状の最初の一手"),
    "ui.recipe.organic.2": ("Seams → unwrap → relax → pack", "シーム → 展開 → リラックス → パック"),
    "ui.recipe.hardsurface.title": ("Hard Surface", "ハードサーフェス"),
    "ui.recipe.hardsurface.1": ("For props, panels and mechanical parts", "小物、パネル、メカ部品向け"),
    "ui.recipe.hardsurface.2": ("Auto seam + rectify style cleanup", "自動シーム＋矩形整形系の流れ"),
    "ui.recipe.trim.title": ("Trim / Hotspot", "トリム／ホットスポット"),
    "ui.recipe.trim.1": ("For trimsheet, strip and repeated parts", "トリムシート、帯、反復パーツ向け"),
    "ui.recipe.trim.2": ("Quad flow + strip layout + density", "クアッドフロー＋帯配置＋密度"),
    "ui.recipe.lightmap.title": ("Lightmap", "ライトマップ"),
    "ui.recipe.lightmap.1": ("Bake-safe layout with simple validation", "ベイク安全寄りレイアウト＋簡易検証"),
    "ui.recipe.lightmap.2": ("Separate clearly and audit overlap", "分離を優先し、重なりを確認"),
    "ui.recipe.atlas.title": ("Atlas", "アトラス"),
    "ui.recipe.atlas.1": ("For shared textures across multiple objects", "複数オブジェクト共有テクスチャ向け"),
    "ui.recipe.atlas.2": ("Prepare layout, bake and material setup", "配置、ベイク、材質準備をまとめて実行"),
    "ui.recipe.qa.title": ('Batch Inspect', "検査／補正"),
    "ui.recipe.qa.1": ("Use when the layout already exists but needs checking", "レイアウトはあるが確認や補正が必要な時向け"),
    "ui.recipe.qa.2": ("Checker → scan → heal workflow", "チェッカー → 検査 → 補正 の流れ"),
    "ui.recipe.run": ("Run Recipe", "レシピ実行"),
    "ui.recipe.more": ("Open Related Tools", "関連ツールを開く"),
})


_TEXT.update({
    "ui.section.navigator": ("Task Navigator", "タスクナビゲーター"),
    "ui.navigator.hint": ("Start from a goal instead of memorizing tool names. Each card leads to the most common next actions.", "ツール名を覚える代わりに、目的から開始できます。各カードからよく使う次の操作へ進めます。"),
    "ui.navigator.quickfix.title": ("Quick Fix", "クイック修正"),
    "ui.navigator.quickfix.1": ("For layouts that mostly work but need checking", "ほぼ使えるUVを確認・微修正したい時向け"),
    "ui.navigator.quickfix.2": ("Checker → scan → fix common issues", "チェッカー → 検査 → よくある問題修正"),
    "ui.navigator.unwrap.title": ("First Unwrap", "初回展開"),
    "ui.navigator.unwrap.1": ("Good default start for new assets", "新規アセットの基本スタート向け"),
    "ui.navigator.unwrap.2": ("Seams → unwrap → relax", "シーム → 展開 → リラックス"),
    "ui.navigator.hardsurface.title": ("Hard Surface Cleanup", "ハードサーフェス整理"),
    "ui.navigator.hardsurface.1": ("For panels, trims and orthogonal parts", "パネル、トリム、直交系パーツ向け"),
    "ui.navigator.hardsurface.2": ("Orthogonalize → rectify → pack", "直交化 → 矩形整理 → パック"),
    "ui.navigator.tiles.title": ("Trim / UDIM Layout", "トリム / UDIM 配置"),
    "ui.navigator.tiles.1": ("For grouped parts, tiles and repeated pieces", "グループ部品、タイル、反復パーツ向け"),
    "ui.navigator.tiles.2": ("Group → tiles → pack / density", "グループ化 → タイル分配 → パック / 密度"),
    "ui.navigator.symmetry.title": ("Symmetry Reuse", "対称再利用"),
    "ui.navigator.symmetry.1": ("Reuse mirrored pairs before final packing", "最終パック前に左右対称を再利用"),
    "ui.navigator.symmetry.2": ("Detect pairs → stack / transfer", "ペア検出 → スタック / 転送"),
    "ui.navigator.atlas.title": ("Atlas / Batch", "アトラス / 一括"),
    "ui.navigator.atlas.1": ("For shared materials across many objects", "複数オブジェクトで材質を共有したい時向け"),
    "ui.navigator.atlas.2": ("Atlas build → bake-ready setup", "アトラス構築 → ベイク準備"),
    "ui.navigator.run": ("Run", "実行"),
    "ui.navigator.more": ("More", "詳細"),
})


def _suv_clamped_int(value, default: int, minimum: int, maximum: int) -> int:
    """Convert UI integer values while preserving valid zero values."""
    try:
        if value is None:
            value = default
        value = int(value)
    except Exception:
        value = int(default)
    return max(int(minimum), min(int(value), int(maximum)))


def _suv_sync_canvas_grid_runtime_settings(context, ws):
    """Apply canvas/grid settings to UV Editor guide/display runtime data.

    This function intentionally does not create, resize, assign or display a
    checker image.  Checker-related changes are controlled only from
    Preview / Checker so automatic unwrap and canvas/grid changes never make a
    checker appear by surprise.
    """
    if ws is None:
        return
    try:
        canvas_size = _suv_clamped_int(getattr(ws, 'canvas_size', 2048), 2048, 128, 16384)
    except Exception:
        canvas_size = 2048
    try:
        padding_px = _suv_clamped_int(getattr(ws, 'fit_padding_px', 8), 8, 0, 512)
    except Exception:
        padding_px = 8
    try:
        cols = _suv_clamped_int(getattr(ws, 'hotspot_cols', 4), 4, 1, 64)
        rows = _suv_clamped_int(getattr(ws, 'hotspot_rows', 4), 4, 1, 64)
    except Exception:
        cols, rows = 4, 4
    try:
        keep_aspect = bool(getattr(ws, 'hotspot_keep_aspect', True))
        hotspot_sort = str(getattr(ws, 'hotspot_sort', 'AREA') or 'AREA')
        fill_order = str(getattr(ws, 'hotspot_fill_order', 'ROW') or 'ROW')
    except Exception:
        keep_aspect, hotspot_sort, fill_order = True, 'AREA', 'ROW'
    try:
        scene = getattr(context, 'scene', None)
        if scene is not None:
            scene['smart_uv_suite_canvas_size'] = canvas_size
            scene['smart_uv_suite_fit_padding_px'] = padding_px
            scene['smart_uv_suite_hotspot_cols'] = cols
            scene['smart_uv_suite_hotspot_rows'] = rows
            scene['smart_uv_suite_hotspot_keep_aspect'] = keep_aspect
            scene['smart_uv_suite_hotspot_sort'] = hotspot_sort
            scene['smart_uv_suite_hotspot_fill_order'] = fill_order
    except Exception:
        pass
    # Do not write UV Editor guide-overlay RNA from the generic workspace update
    # callback.  This callback is shared by many unrelated properties, including
    # the Auto UV Unwrap method enum.  Updating those unrelated properties must
    # never reset the user's UV Editor tile grid or guide settings.  The explicit
    # smart_uv_suite.apply_canvas_grid_settings operator remains the only path
    # that mirrors guide settings across UV Editor areas.

# --- Deferred workspace JSON save -------------------------------------------------
# Every workspace property update used to capture all ~400 values and fsync
# Smart_UV_Suite.json synchronously (about 0.06-2 s per assignment on a synced
# folder).  The update callbacks now only raise a "save needed" mark and arm one
# finite (None-returning) timer; the timer, the save/load handlers and
# unregister each flush the mark with a single save.
_SUV_WS_SAVE_PENDING = False
_SUV_WS_SAVE_DELAY = 0.5


def _suv_ws_save_flush(context=None) -> bool:
    """Save once when a save is pending.  Returns True when a save was attempted."""
    global _SUV_WS_SAVE_PENDING
    if not _SUV_WS_SAVE_PENDING:
        return False
    _SUV_WS_SAVE_PENDING = False
    try:
        from . import npanel_persistence as _npanel_store
        if bool(getattr(_npanel_store, 'is_applying_workspace', lambda: False)()):
            return False
        _npanel_store.save_workspace(context or getattr(bpy, 'context', None), None)
    except Exception:
        pass
    return True


def _suv_ws_save_discard() -> None:
    """Drop a pending save without writing (used after a file load: the live
    values then belong to the newly loaded file and must not overwrite the JSON)."""
    global _SUV_WS_SAVE_PENDING
    _SUV_WS_SAVE_PENDING = False
    try:
        _suv_resource.timer_unregister(_suv_ws_save_timer)
    except Exception:
        pass


def _suv_ws_save_timer():
    try:
        _suv_ws_save_flush(getattr(bpy, 'context', None))
    except Exception:
        pass
    return None


def _suv_ws_save_mark(context=None, ws=None) -> None:
    """Raise the save-needed mark and arm exactly one finite timer."""
    global _SUV_WS_SAVE_PENDING
    try:
        from . import npanel_persistence as _npanel_store
        if bool(getattr(_npanel_store, 'is_applying_workspace', lambda: False)()):
            return
    except Exception:
        pass
    _SUV_WS_SAVE_PENDING = True
    try:
        if _suv_resource.timer_is_registered(_suv_ws_save_timer):
            return
        if _suv_resource.timer_register(_suv_ws_save_timer, first_interval=_SUV_WS_SAVE_DELAY) is None:
            _suv_ws_save_flush(context)
    except Exception:
        _suv_ws_save_flush(context)


def _suv_workspace_settings_update(self, context):
    applying_workspace = False
    try:
        from . import npanel_persistence as _npanel_store
        applying_workspace = bool(getattr(_npanel_store, 'is_applying_workspace', lambda: False)())
        if not applying_workspace:
            _suv_ws_save_mark(context, self)
    except Exception:
        pass
    try:
        # Even while a saved workspace is being restored, keep the runtime
        # canvas/grid cache and redraw state synchronized.
        # Previously this path returned early during persistence restore, so the
        # panel values could look updated while layout/grid tools still read
        # stale runtime defaults until a manual Apply click.
        _suv_sync_canvas_grid_runtime_settings(context, self)
    except Exception:
        pass
    try:
        fn = globals().get('_suv_schedule_realtime_from_update')
        if callable(fn):
            fn(self, context)
    except Exception:
        pass
    try:
        _suv_schedule_realtime_if_needed(self, context)
    except Exception:
        pass


def _suv_native_proxy_targets(context=None):
    """Yield live Image Editor spaces without retaining RNA across events."""
    ctx = context or getattr(bpy, 'context', None)
    seen = set()
    candidates = []
    try:
        candidates.append(getattr(ctx, 'space_data', None))
    except Exception:
        pass
    try:
        for area in getattr(getattr(ctx, 'screen', None), 'areas', ()) or ():
            if getattr(area, 'type', '') == 'IMAGE_EDITOR':
                candidates.extend(tuple(getattr(area, 'spaces', ()) or ()))
    except Exception:
        pass
    for space in candidates:
        try:
            if getattr(space, 'type', '') != 'IMAGE_EDITOR' or id(space) in seen:
                continue
            seen.add(id(space))
            yield space
        except Exception:
            continue


def _suv_native_proxy_update_factory(proxy_name, native_name, owner_kind='uv'):
    """Create a persisted proxy callback for Blender-owned UV display RNA.

    Blender's native Space/Image properties cannot receive add-on update
    callbacks.  Exposing scene-owned proxies keeps the N-panel values portable
    between scenes and lets each edit be written synchronously to the canonical
    JSON, while still mirroring the value to every currently visible UV editor.
    """
    def _update(self, context):
        try:
            value = getattr(self, proxy_name)
        except Exception:
            value = None
        for space in _suv_native_proxy_targets(context):
            try:
                if owner_kind == 'space':
                    owner = space
                elif owner_kind == 'image':
                    owner = getattr(space, 'image', None)
                else:
                    owner = getattr(space, 'uv_editor', None)
                if owner is None or not hasattr(owner, native_name):
                    continue
                setattr(owner, native_name, tuple(value) if hasattr(value, '__len__') and not isinstance(value, str) else value)
            except Exception:
                continue
        _suv_workspace_settings_update(self, context)
    _update.__name__ = f'_suv_update_{proxy_name}'
    return _update



_SUV_OPERATION_INSTANT_SELECT_PENDING = False
def _suv_operation_bool_get(prop_name):
    def _get(self):
        # A getter must not rebuild keymaps/handlers while Blender is reading
        # this IDProperty (including from the axis-history timer).  Explicit
        # registration and update callbacks own runtime synchronization.
        return bool(self.get(prop_name, False))
    _get.__name__ = f"_suv_get_{prop_name}"
    return _get


def _suv_operation_bool_set(prop_name):
    def _set(self, value):
        self[prop_name] = bool(value)
    _set.__name__ = f"_suv_set_{prop_name}"
    return _set


def _suv_synchronize_operation_runtime(context, reason: str):
    """Route every public Operation toggle through the lifecycle authority."""
    from . import registration_manifest_18168 as _manifest

    return _manifest.synchronize_interaction_runtime(
        context=context,
        reason=str(reason or "ui_update"),
    )


# Last runtime-sync failure diagnostic; a toggle click must never raise out of
# its RNA update callback (that leaves UI state and keymaps divergent and
# repeats on every click), so failures are recorded here and reported once.
_SUV_OPERATION_SYNC_LAST_ERROR = None
_SUV_OPERATION_SYNC_ERROR_REPORTED = False


def _suv_synchronize_operation_runtime_guarded(context, reason: str):
    """Non-throwing wrapper for property update callbacks.

    An exception inside an RNA update callback surfaces as a red error on the
    toggle and leaves the runtime out of sync with the UI; every Operation
    toggle therefore routes through this guard, which reports the first
    failure to the console and keeps the callback alive.
    """
    global _SUV_OPERATION_SYNC_LAST_ERROR, _SUV_OPERATION_SYNC_ERROR_REPORTED
    try:
        result = _suv_synchronize_operation_runtime(context, reason)
        _SUV_OPERATION_SYNC_LAST_ERROR = None
        _SUV_OPERATION_SYNC_ERROR_REPORTED = False
        return result
    except Exception as exc:
        _SUV_OPERATION_SYNC_LAST_ERROR = {
            "reason": str(reason or ""),
            "exception": type(exc).__name__,
            "message": str(exc),
        }
        if not _SUV_OPERATION_SYNC_ERROR_REPORTED:
            _SUV_OPERATION_SYNC_ERROR_REPORTED = True
            try:
                _suv_warn_once('a106:ui.py:1151', 
                    "[SmartUV] Operation runtime sync failed "
                    f"({reason}): {type(exc).__name__}: {exc}"
                )
            except Exception:
                pass
        return {"deferred": True, "reason": "sync_exception"}


def _suv_operation_instant_select_update(self, context):
    """Deprecated selection-action update kept for old saved settings.

    The current Immediate Selection feature is a UV Editor mouse workflow: left
    drag selects the element under the cursor and immediately enters move.  Old
    grow/shrink/island action settings are saved for compatibility only and are
    not executed automatically.
    """
    _suv_workspace_settings_update(self, context)


def _suv_operation_instant_select_enabled_update(self, context):
    _suv_workspace_settings_update(self, context)
    _suv_force_workspace_json_save(context, self)
    _suv_synchronize_operation_runtime_guarded(context, "ui_instant_select")


def _suv_operation_uv_ownership_update(self, context):
    _suv_workspace_settings_update(self, context)
    _suv_force_workspace_json_save(context, self)
    _suv_synchronize_operation_runtime_guarded(context, "ui_uv_ownership")


def _suv_canvas_grid_dynamic_subdivisions_update(self, context):
    try:
        value = _suv_clamped_int(getattr(self, 'canvas_grid_dynamic_subdivisions', 10), 10, 1, 5000)
        try:
            self['canvas_grid_dynamic_subdivisions'] = value
        except Exception:
            pass
        targets = []
        for scr in getattr(bpy.data, 'screens', []) or []:
            for area in getattr(scr, 'areas', []) or []:
                if getattr(area, 'type', '') != 'IMAGE_EDITOR':
                    continue
                for space in getattr(area, 'spaces', []) or []:
                    if getattr(space, 'type', '') == 'IMAGE_EDITOR' and getattr(space, 'uv_editor', None) is not None:
                        targets.append(getattr(space, 'uv_editor', None))
        seen = set()
        for uv in targets:
            try:
                key = id(uv)
                if key in seen:
                    continue
                seen.add(key)
                if hasattr(uv, 'custom_grid_subdivisions'):
                    try:
                        uv.custom_grid_subdivisions[0] = value
                        uv.custom_grid_subdivisions[1] = value
                    except Exception:
                        uv.custom_grid_subdivisions = (value, value)
            except Exception:
                pass
    except Exception:
        pass
    _suv_workspace_settings_update(self, context)


def _suv_operation_axis_constraint_memory_update(self, context):
    _suv_workspace_settings_update(self, context)
    _suv_force_workspace_json_save(context, self)
    _suv_synchronize_operation_runtime_guarded(context, "ui_axis_memory")
    try:
        from . import smartuv_operation_runtime_18228 as _runtime
        _runtime.note_panel_draw(context)
    except Exception:
        pass


def _suv_operation_uv_gizmo_grip_fix_update(self, context):
    _suv_workspace_settings_update(self, context)
    _suv_force_workspace_json_save(context, self)
    _suv_synchronize_operation_runtime_guarded(context, "ui_gizmo_grip")


def _suv_force_workspace_json_save(context=None, ws=None) -> None:
    """Persist Smart UV settings to Smart_UV_Suite.json immediately.

    N-panel State Save can defer generic panel state, but Custom Smart settings
    and always-on switches must survive Blender restarts immediately after a user
    edit.  This helper updates the same external JSON cache without scheduling
    a background watcher.
    """
    # The capture + write is deferred to one finite timer (see _suv_ws_save_mark);
    # the saved values are captured at flush time, so the file ends up identical.
    _suv_ws_save_mark(context, ws)


_SUV_PRESET_APPLY_GUARD = False


# Smart UV Suite 1.8.126 Auto Packing presets.
# The method selector is a preset selector.  It updates the visible settings below;
# the Auto Pack execution path then reads those visible/current settings.
_SUV_AUTO_PACK_PRESET_APPLYING = False

_SUV_AUTO_PACK_PRESET_BASE = {
    'unified_pack_margin_px': 8,
    'unified_pack_margin': 0.001,
    'unified_pack_margin_method': 'SCALED',
    'unified_pack_shape_method': 'CONCAVE',
    'unified_pack_rotation_step': '90',
    'unified_pack_rotate': True,
    'unified_pack_scale': True,
    'unified_pack_lock_pinned': True,
    'unified_pack_use_seed': False,
    'unified_pack_seed': 0,
    'unified_pack_stack_identical': False,
    'unified_pack_chart_rescale': False,
    'pack_group_mode': 'SIMILAR',
    'pack_group_layout': 'SINGLE_TILE',
    'similarity_area_tol': 0.08,
    'similarity_aspect_tol': 0.15,
    'unified_pack_target_tile': 'ZERO',
    'unified_pack_tile_u': 0,
    'unified_pack_tile_v': 0,
    'unified_pack_tile_columns': 10,
    'unified_pack_tile_fill': 'ROW',
    'unified_pack_target_width': 2048,
    'unified_pack_target_height': 2048,
    'unified_pack_bake_padding_px': 4,
    'canvas_size': 2048,
    'workflow_density': 1024.0,
    'hotspot_cols': 4,
    'hotspot_rows': 4,
    'hotspot_keep_aspect': True,
    'hotspot_sort': 'AREA',
    'hotspot_fill_order': 'ROW',
}

_SUV_AUTO_PACK_PRESET_OVERRIDES = {
    'PACK_STANDARD': {},
    'SMART_DENSE': {
        'unified_pack_margin_px': 4,
        'unified_pack_margin': 0.0005,
        'unified_pack_shape_method': 'CONCAVE',
        'unified_pack_rotate': True,
        'unified_pack_rotation_step': '15',
        'unified_pack_scale': True,
        'unified_pack_use_seed': True,
        'unified_pack_seed': 7,
    },
    'FAST_NO_ROTATE': {
        'unified_pack_shape_method': 'AABB',
        'unified_pack_rotate': False,
        'unified_pack_rotation_step': '0',
        'unified_pack_scale': True,
    },
    'DENSITY_PRIORITY': {
        'unified_pack_chart_rescale': True,
        'unified_pack_shape_method': 'CONCAVE',
        'unified_pack_rotation_step': '45',
    },
    'MESH_AREA_SCALE_PACK': {
        'unified_pack_chart_rescale': True,
        'unified_pack_shape_method': 'CONCAVE',
        'unified_pack_rotation_step': '45',
    },
    'GROUP_SIMILAR': {
        'pack_group_mode': 'SIMILAR',
        'pack_group_layout': 'ROWS',
        'similarity_area_tol': 0.03,
        'similarity_aspect_tol': 0.05,
        'unified_pack_shape_method': 'CONVEX',
        'unified_pack_rotation_step': '45',
    },
    'GROUP_MATERIAL': {
        'pack_group_mode': 'MATERIAL',
        'pack_group_layout': 'TILES',
        'unified_pack_shape_method': 'CONVEX',
        'unified_pack_rotation_step': '45',
    },
    'GROUP_IDENTICAL': {
        'pack_group_mode': 'IDENTICAL',
        'pack_group_layout': 'ROWS',
        'unified_pack_stack_identical': True,
        'similarity_area_tol': 0.04,
        'similarity_aspect_tol': 0.05,
        'unified_pack_shape_method': 'CONVEX',
    },
    'UDIM_STANDARD': {
        'unified_pack_target_tile': 'EXPLICIT',
        'unified_pack_tile_u': 0,
        'unified_pack_tile_v': 0,
        'unified_pack_tile_columns': 10,
        'unified_pack_tile_fill': 'ROW',
    },
    'UDIM_KEEP_TILES': {
        'unified_pack_target_tile': 'KEEP',
        'unified_pack_tile_columns': 10,
        'unified_pack_tile_fill': 'ROW',
    },
    'UDIM_AUTO_TILES': {
        'unified_pack_target_tile': 'ZERO',
        'pack_group_layout': 'TILES',
        'unified_pack_tile_columns': 4,
        'unified_pack_tile_fill': 'ROW',
    },
    'CHART_DISTRIBUTION': {
        'unified_pack_margin_px': 6,
        'unified_pack_margin': 0.00075,
        'unified_pack_chart_rescale': True,
        'unified_pack_shape_method': 'CONCAVE',
        'unified_pack_rotation_step': '45',
        'unified_pack_target_width': 2048,
        'unified_pack_target_height': 2048,
    },
    'BAKE_SAFE_CHART': {
        'unified_pack_margin_px': 16,
        'unified_pack_margin': 0.002,
        'unified_pack_margin_method': 'ADD',
        'unified_pack_bake_padding_px': 8,
        'unified_pack_shape_method': 'CONCAVE',
    },
    'EXISTING_CHART_REPACK': {
        'unified_pack_target_tile': 'KEEP',
        'unified_pack_shape_method': 'AABB',
        'unified_pack_rotate': False,
        'unified_pack_rotation_step': '0',
        'unified_pack_scale': False,
        'unified_pack_chart_rescale': False,
    },
    'LOW_DISTORTION_PACK': {
        'unified_pack_chart_rescale': True,
        'unified_pack_shape_method': 'CONVEX',
        'unified_pack_rotation_step': '45',
    },
    'LIGHTMAP': {
        'unified_pack_margin_px': 12,
        'unified_pack_margin': 0.0015,
        'unified_pack_margin_method': 'ADD',
        'unified_pack_bake_padding_px': 8,
        'unified_pack_shape_method': 'AABB',
        'unified_pack_stack_identical': False,
        'unified_pack_rotate': False,
        'unified_pack_rotation_step': '0',
    },
    'HOTSPOT_GRID': {
        'unified_pack_margin_px': 4,
        'unified_pack_margin': 0.0005,
        'unified_pack_shape_method': 'AABB',
        'unified_pack_rotate': False,
        'unified_pack_rotation_step': '0',
        'hotspot_cols': 4,
        'hotspot_rows': 4,
        'hotspot_keep_aspect': True,
        'hotspot_sort': 'AREA',
        'hotspot_fill_order': 'ROW',
    },
    'TRIM_STRIP': {
        'unified_pack_margin_px': 4,
        'unified_pack_margin': 0.0005,
        'unified_pack_shape_method': 'AABB',
        'unified_pack_rotate': False,
        'unified_pack_rotation_step': '0',
        'hotspot_cols': 1,
        'hotspot_rows': 8,
        'hotspot_keep_aspect': True,
        'hotspot_sort': 'HEIGHT',
        'hotspot_fill_order': 'COLUMN',
    },
}


def _suv_auto_pack_preset_values(mode: str) -> dict:
    values = dict(_SUV_AUTO_PACK_PRESET_BASE)
    values.update(_SUV_AUTO_PACK_PRESET_OVERRIDES.get(str(mode or 'PACK_STANDARD').upper(), {}))
    return values


def _suv_auto_pack_preset_update(self, context):
    """Apply the selected Auto Pack preset to the visible setting fields."""
    global _SUV_AUTO_PACK_PRESET_APPLYING
    if _SUV_AUTO_PACK_PRESET_APPLYING:
        return
    _SUV_AUTO_PACK_PRESET_APPLYING = True
    try:
        for prop_name, value in _suv_auto_pack_preset_values(getattr(self, 'unified_auto_pack_mode', 'PACK_STANDARD')).items():
            try:
                if hasattr(self, prop_name):
                    setattr(self, prop_name, value)
            except Exception:
                pass
    finally:
        _SUV_AUTO_PACK_PRESET_APPLYING = False
    try:
        _suv_workspace_settings_update(self, context)
    except Exception:
        pass
    try:
        _suv_force_workspace_json_save(context, self)
    except Exception:
        pass

_SUV_SMART_REALTIME_PENDING = False
_SUV_SMART_REALTIME_RUNNING = False
_SUV_SMART_REALTIME_LAST_RUN = 0.0
_SUV_REALTIME_ARMED = False
_SUV_REALTIME_ARMED_SELECTION = None
_SUV_REALTIME_LAST_SETTINGS = None
_SUV_REALTIME_LAST_REASON = ''


def _suv_realtime_active_mesh(context=None):
    try:
        import bpy
        ctx = context or bpy.context
        obj = getattr(ctx, 'active_object', None)
        if obj is None or getattr(obj, 'type', '') != 'MESH':
            return None
        # Require the object to still be selected.  This makes deselect/reselect
        # stop the armed realtime session instead of silently targeting a new mesh.
        try:
            if not bool(obj.select_get()):
                return None
        except Exception:
            pass
        return obj
    except Exception:
        return None


def _suv_realtime_selection_signature(context=None):
    try:
        import bpy
        ctx = context or bpy.context
        obj = _suv_realtime_active_mesh(ctx)
        if obj is None:
            return None
        data = getattr(obj, 'data', None)
        if data is None:
            return None
        selected_faces = []
        selected_edges = []
        selected_verts = []
        uv_selected = 0
        mode = getattr(obj, 'mode', '')
        if mode == 'EDIT':
            try:
                import bmesh
                bm = bmesh.from_edit_mesh(data)
                bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
                selected_faces = [int(f.index) for f in bm.faces if getattr(f, 'select', False)]
                selected_edges = [int(e.index) for e in bm.edges if getattr(e, 'select', False)]
                selected_verts = [int(v.index) for v in bm.verts if getattr(v, 'select', False)]
                uv_layer = bm.loops.layers.uv.active
                if uv_layer is not None:
                    for f in bm.faces:
                        for l in f.loops:
                            luv = l[uv_layer]
                            if bool(getattr(luv, 'select', False)) or bool(getattr(luv, 'select_edge', False)):
                                uv_selected += 1
            except Exception:
                pass
        else:
            try:
                selected_faces = [int(p.index) for p in data.polygons if getattr(p, 'select', False)]
                selected_edges = [int(e.index) for e in data.edges if getattr(e, 'select', False)]
                selected_verts = [int(v.index) for v in data.vertices if getattr(v, 'select', False)]
            except Exception:
                pass
        # Use compact counts plus prefix of selected indices to avoid expensive
        # signatures on large meshes while still detecting ordinary reselection.
        return (
            getattr(obj, 'name_full', getattr(obj, 'name', '')),
            id(data),
            int(len(getattr(data, 'vertices', ()) or ())),
            int(len(getattr(data, 'edges', ()) or ())),
            int(len(getattr(data, 'polygons', ()) or ())),
            tuple(selected_faces[:512]), len(selected_faces),
            tuple(selected_edges[:512]), len(selected_edges),
            tuple(selected_verts[:512]), len(selected_verts),
            int(uv_selected),
        )
    except Exception:
        return None


def _suv_realtime_settings_signature(ws):
    if ws is None:
        return None
    prefixes = (
        'auto_unwrap_mode', 'smart_standard_core_', 'smart_standard_', 'flat_mapping_', 'projection_', 'native_',
        'canvas_size', 'fit_padding_px', 'gizmo_', 'uv_projection_',
        'smart_unwrap_spring_strength', 'smart_unwrap_pull_distance', 'smart_unwrap_orientation_angle',
    )
    values = []
    prop_names = []
    seen = set()
    try:
        from . import npanel_persistence as _npanel_store
        prop_names = list(_npanel_store._iter_workspace_props(None))
    except Exception:
        try:
            cls = globals().get('SUV_PG_WorkspaceSettings')
            class_dict = type.__getattribute__(cls, '__dict__') if isinstance(cls, type) else {}
            annotations = dict(class_dict.get('__annotations__', {}) or {})
        except Exception:
            annotations = {}
        for ident in annotations.keys():
            ident = str(ident or '')
            if ident and ident not in seen:
                seen.add(ident)
                prop_names.append(ident)
    for ident in prop_names:
        if not ident or ident in {'rna_type', 'name', 'smart_unwrap_realtime_preview'}:
            continue
        if ident == 'auto_unwrap_mode' or any(ident.startswith(p) for p in prefixes if p != 'auto_unwrap_mode'):
            try:
                val = getattr(ws, ident)
                if isinstance(val, float):
                    val = round(val, 6)
                elif isinstance(val, (list, tuple)):
                    val = tuple(val)
                else:
                    val = str(val) if not isinstance(val, (int, bool, str)) else val
                values.append((ident, val))
            except Exception:
                pass
    return tuple(values)


def _suv_realtime_disarm(reason=''):
    global _SUV_REALTIME_ARMED, _SUV_REALTIME_ARMED_SELECTION, _SUV_REALTIME_LAST_SETTINGS, _SUV_REALTIME_LAST_REASON, _SUV_SMART_REALTIME_PENDING
    _SUV_REALTIME_ARMED = False
    _SUV_REALTIME_ARMED_SELECTION = None
    _SUV_REALTIME_LAST_SETTINGS = None
    _SUV_REALTIME_LAST_REASON = str(reason or '')
    _SUV_SMART_REALTIME_PENDING = False


def _suv_realtime_mark_unwrap_run(context=None):
    global _SUV_REALTIME_ARMED, _SUV_REALTIME_ARMED_SELECTION, _SUV_REALTIME_LAST_SETTINGS, _SUV_REALTIME_LAST_REASON
    try:
        import bpy
        ctx = context or bpy.context
        sig = _suv_realtime_selection_signature(ctx)
        ws = getattr(getattr(ctx, 'scene', None), 'suv_workspace', None)
        if sig is None or ws is None:
            _suv_realtime_disarm('no active selected mesh')
            return False
        _SUV_REALTIME_ARMED = True
        _SUV_REALTIME_ARMED_SELECTION = sig
        _SUV_REALTIME_LAST_SETTINGS = _suv_realtime_settings_signature(ws)
        _SUV_REALTIME_LAST_REASON = 'armed after unwrap run'
        return True
    except Exception:
        _suv_realtime_disarm('arm failed')
        return False


def _suv_realtime_is_armed_for_current_context(context=None):
    global _SUV_REALTIME_ARMED
    if not bool(_SUV_REALTIME_ARMED):
        return False
    sig = _suv_realtime_selection_signature(context)
    if sig is None or sig != _SUV_REALTIME_ARMED_SELECTION:
        _suv_realtime_disarm('mesh deselected or selection changed')
        return False
    return True


def _suv_realtime_guard_depsgraph(scene=None, depsgraph=None):
    try:
        if _SUV_SMART_REALTIME_RUNNING:
            return
        if not bool(_SUV_REALTIME_ARMED):
            return
        _suv_realtime_is_armed_for_current_context()
    except Exception:
        pass



def _suv_realtime_register_handlers() -> None:
    """Register only while the explicit realtime feature is enabled."""
    try:
        handlers = bpy.app.handlers.depsgraph_update_post
        _suv_resource.handler_append(handlers, _suv_realtime_guard_depsgraph)
    except Exception:
        pass



def _suv_realtime_unregister_handlers() -> None:
    try:
        _suv_resource.handler_remove(bpy.app.handlers.depsgraph_update_post, _suv_realtime_guard_depsgraph)
    except Exception:
        pass


def _suv_schedule_realtime_if_needed(self, context):
    global _SUV_SMART_REALTIME_PENDING
    try:
        import bpy
        ws = getattr(getattr((context or bpy.context), 'scene', None), 'suv_workspace', None)
        if ws is None or not bool(getattr(ws, 'smart_unwrap_realtime_preview', False)):
            return
        try:
            from . import npanel_persistence as _npanel_store
            if not bool(_npanel_store.get_always_on('SMART_REALTIME_UNWRAP', False)):
                return
        except Exception:
            return
        if not _suv_realtime_is_armed_for_current_context(context):
            return
        current_settings = _suv_realtime_settings_signature(ws)
        if current_settings == _SUV_REALTIME_LAST_SETTINGS:
            return
        if _SUV_SMART_REALTIME_PENDING or _SUV_SMART_REALTIME_RUNNING:
            return
        _SUV_SMART_REALTIME_PENDING = True
        _suv_resource.timer_register(_suv_smart_realtime_timer, first_interval=0.35)
    except Exception:
        _SUV_SMART_REALTIME_PENDING = False


def _suv_smart_realtime_timer():
    global _SUV_SMART_REALTIME_PENDING, _SUV_SMART_REALTIME_RUNNING, _SUV_SMART_REALTIME_LAST_RUN, _SUV_REALTIME_LAST_SETTINGS
    if _SUV_SMART_REALTIME_RUNNING:
        _SUV_SMART_REALTIME_PENDING = False
        return None
    _SUV_SMART_REALTIME_PENDING = False
    try:
        import bpy
        context = bpy.context
        ws = getattr(getattr(context, 'scene', None), 'suv_workspace', None)
        if ws is None or not bool(getattr(ws, 'smart_unwrap_realtime_preview', False)):
            return None
        try:
            from . import npanel_persistence as _npanel_store
            if not bool(_npanel_store.get_always_on('SMART_REALTIME_UNWRAP', False)):
                return None
        except Exception:
            return None
        if not _suv_realtime_is_armed_for_current_context(context):
            return None
        current_settings = _suv_realtime_settings_signature(ws)
        if current_settings == _SUV_REALTIME_LAST_SETTINGS:
            return None
        try:
            import time
            now = float(time.monotonic())
        except Exception:
            now = 0.0
        if now and now - float(_SUV_SMART_REALTIME_LAST_RUN or 0.0) < 0.45:
            _SUV_SMART_REALTIME_PENDING = True
            _suv_resource.timer_register(_suv_smart_realtime_timer, first_interval=0.45)
            return None
        _SUV_SMART_REALTIME_RUNNING = True
        try:
            bpy.ops.smart_uv_suite.unwrap_auto_run()
            _SUV_SMART_REALTIME_LAST_RUN = now
            _SUV_REALTIME_LAST_SETTINGS = _suv_realtime_settings_signature(ws)
        finally:
            _SUV_SMART_REALTIME_RUNNING = False
    except Exception:
        _SUV_SMART_REALTIME_RUNNING = False
    return None



def _suv_set_live_unwrap_from_realtime(context, enabled):
    try:
        import bpy
        ctx = context or bpy.context
        ts = getattr(getattr(ctx, 'scene', None), 'tool_settings', None) or getattr(ctx, 'tool_settings', None)
    except Exception:
        ts = None
    if ts is None:
        return
    for attr in ('use_edge_path_live_unwrap', 'use_live_unwrap'):
        try:
            getattr(ts, attr)
            setattr(ts, attr, bool(enabled))
            return
        except Exception:
            continue

_SUV_SMART_REALTIME_UPDATE_ACTIVE = False


def _suv_smart_realtime_update(self, context):
    """Update callback entry.  A nested call (the body below rewrites workspace
    properties that carry this same callback, e.g. while a saved workspace is
    re-applied) returns at once; the outermost call already runs the whole body."""
    global _SUV_SMART_REALTIME_UPDATE_ACTIVE
    if globals().get('_SUV_PRESET_APPLY_GUARD', False):
        return
    if _SUV_SMART_REALTIME_UPDATE_ACTIVE:
        return
    _SUV_SMART_REALTIME_UPDATE_ACTIVE = True
    try:
        _suv_smart_realtime_update_body(self, context)
    finally:
        _SUV_SMART_REALTIME_UPDATE_ACTIVE = False


def _suv_smart_realtime_update_body(self, context):
    try:
        enabled = bool(getattr(self, 'smart_unwrap_realtime_preview', False))
        ts = getattr(context, 'tool_settings', None) or getattr(getattr(context, 'scene', None), 'tool_settings', None)
        if ts is not None:
            if hasattr(ts, 'use_edge_path_live_unwrap'):
                ts.use_edge_path_live_unwrap = enabled
            elif hasattr(ts, 'use_live_unwrap'):
                ts.use_live_unwrap = enabled
    except Exception:
        pass
    _suv_workspace_settings_update(self, context)
    _suv_force_workspace_json_save(context, self)
    _suv_schedule_realtime_if_needed(self, context)


_SUS_SMART_STANDARD_SEAM_PRESETS = {
    'CUSTOM': {
        'label': 'カスタム',
        'description': '展開方式と各数値を自動変更せず、現在の設定をそのまま使います。変更した全項目はSmart_UV_Suite.jsonへ即時保存され、Blender再起動後も維持されます。',
    },
    'STANDARD_KEEP': {
        'mode': 'SMART_STANDARD_HARD',
        'label': '標準維持',
        'description': '既存の展開結果を最も強く維持します。結合率を0%にし、品質補正も最小限に抑えます。',
        'merge': 0.0, 'angle_deg': 66.0, 'area_weight': 0.0, 'unwrap_math': 'ANGLE_BASED',
        'quality': 0.0, 'area': 0.0, 'shape': 0.0, 'native': 100.0, 'iterations': 0,
        'stretch_iterations': 0, 'stretch_blend': 0.0,
        'angle_keep': 72.0, 'stretch_keep': 72.0, 'loop_keep': 62.0, 'planarity': 55.0,
        'density': 55.0, 'existing': 80.0, 'boundary': 46.0, 'small': 42.0,
        'auto_pack': True, 'pack_margin': 0.02, 'pack_margin_method': 'FRACTION', 'pack_rotate_method': 'ANY',
        'pre_fix_mesh': False, 'merge_distance': 0.0001,
    },
    'BALANCED': {
        'mode': 'SMART_STANDARD_HARD',
        'label': 'バランス',
        'description': '角度、引張、面積密度、既存シームを総合評価し、一般的な形状で扱いやすい統合率へ設定します。',
        'merge': 35.0, 'angle_deg': 66.0, 'area_weight': 0.20, 'unwrap_math': 'ANGLE_BASED',
        'quality': 62.0, 'area': 62.0, 'shape': 58.0, 'native': 35.0, 'iterations': 36,
        'stretch_iterations': 100, 'stretch_blend': 0.85,
        'angle_keep': 72.0, 'stretch_keep': 72.0, 'loop_keep': 62.0, 'planarity': 58.0,
        'density': 60.0, 'existing': 75.0, 'boundary': 58.0, 'small': 50.0,
        'auto_pack': True, 'pack_margin': 0.02, 'pack_margin_method': 'FRACTION', 'pack_rotate_method': 'ANY',
        'pre_fix_mesh': False, 'merge_distance': 0.0001,
    },
    'HARD_SURFACE': {
        'label': 'Smart Standard: ハードサーフェス',
        'description': 'Smart Standard: Hard Surfaceへ切り替え、硬い折れ目、直線的な稜線、既存シームを強く維持します。',
        'mode': 'SMART_STANDARD_HARD', 'merge': 24.0, 'angle_deg': 45.0, 'area_weight': 0.10, 'unwrap_math': 'CONFORMAL',
        'quality': 58.0, 'area': 46.0, 'shape': 76.0, 'native': 42.0, 'iterations': 32,
        'stretch_iterations': 80, 'stretch_blend': 0.60,
        'angle_keep': 96.0, 'stretch_keep': 62.0, 'loop_keep': 78.0, 'planarity': 84.0,
        'density': 46.0, 'existing': 92.0, 'boundary': 42.0, 'small': 38.0,
        'auto_pack': True, 'pack_margin': 0.02, 'pack_margin_method': 'FRACTION', 'pack_rotate_method': 'CARDINAL',
        'pre_fix_mesh': False, 'merge_distance': 0.0001,
    },
    'ORGANIC': {
        'label': 'Smart Standard: Organic',
        'description': 'Smart Standard: Organicへ切り替え、滑らかな曲面を広めの島へ統合し、角度より引張と平面性を優先します。',
        'mode': 'SMART_STANDARD_ORGANIC', 'merge': 55.0, 'angle_deg': 89.0, 'area_weight': 0.32, 'unwrap_math': 'ANGLE_BASED',
        'quality': 72.0, 'area': 66.0, 'shape': 58.0, 'native': 24.0, 'iterations': 48,
        'stretch_iterations': 160, 'stretch_blend': 0.95,
        'angle_keep': 42.0, 'stretch_keep': 86.0, 'loop_keep': 52.0, 'planarity': 72.0,
        'density': 66.0, 'existing': 52.0, 'boundary': 70.0, 'small': 62.0,
        'auto_pack': True, 'pack_margin': 0.02, 'pack_margin_method': 'FRACTION', 'pack_rotate_method': 'ANY',
        'pre_fix_mesh': False, 'merge_distance': 0.0001,
    },
    'STANDARD_SMART': {
        'label': 'Standard Smart投影',
        'description': 'Standard Smart Projectへ切り替え、Blender標準Smart投影に近い結果を保ちながら必要分だけ統合します。',
        'mode': 'SMART', 'merge': 18.0, 'angle_deg': 66.0, 'area_weight': 0.0, 'unwrap_math': 'ANGLE_BASED',
        'quality': 40.0, 'area': 42.0, 'shape': 42.0, 'native': 65.0, 'iterations': 20,
        'stretch_iterations': 60, 'stretch_blend': 0.45,
        'angle_keep': 78.0, 'stretch_keep': 54.0, 'loop_keep': 48.0, 'planarity': 54.0,
        'density': 42.0, 'existing': 70.0, 'boundary': 35.0, 'small': 30.0,
        'auto_pack': True, 'pack_margin': 0.02, 'pack_margin_method': 'FRACTION', 'pack_rotate_method': 'ANY',
        'pre_fix_mesh': False, 'merge_distance': 0.0001,
    },
    'NORMAL_UNWRAP': {
        'label': 'Normal Unwrap',
        'description': 'Normal Unwrapへ切り替え、現在の手動シームを尊重しながら品質補正とパッキングを行います。',
        'mode': 'NORMAL', 'merge': 0.0, 'angle_deg': 66.0, 'area_weight': 0.0, 'unwrap_math': 'ANGLE_BASED',
        'quality': 45.0, 'area': 50.0, 'shape': 50.0, 'native': 65.0, 'iterations': 24,
        'stretch_iterations': 40, 'stretch_blend': 0.35,
        'angle_keep': 70.0, 'stretch_keep': 60.0, 'loop_keep': 70.0, 'planarity': 55.0,
        'density': 55.0, 'existing': 100.0, 'boundary': 38.0, 'small': 18.0,
        'auto_pack': True, 'pack_margin': 0.02, 'pack_margin_method': 'FRACTION', 'pack_rotate_method': 'ANY',
        'pre_fix_mesh': False, 'merge_distance': 0.0001,
    },
    'LOW_STRETCH': {
        'mode': 'SMART_STANDARD_ORGANIC',
        'label': '低引張',
        'description': 'UVの伸び、面積密度差、辺長比率を強く抑え、歪みの少ない展開を優先します。',
        'merge': 30.0, 'angle_deg': 72.0, 'area_weight': 0.55, 'unwrap_math': 'ANGLE_BASED',
        'quality': 84.0, 'area': 78.0, 'shape': 82.0, 'native': 18.0, 'iterations': 72,
        'stretch_iterations': 200, 'stretch_blend': 1.0,
        'angle_keep': 58.0, 'stretch_keep': 98.0, 'loop_keep': 58.0, 'planarity': 66.0,
        'density': 92.0, 'existing': 62.0, 'boundary': 52.0, 'small': 42.0,
        'auto_pack': True, 'pack_margin': 0.02, 'pack_margin_method': 'FRACTION', 'pack_rotate_method': 'ANY',
        'pre_fix_mesh': False, 'merge_distance': 0.0001,
    },
    'LOOP_SAFE': {
        'mode': 'SMART_STANDARD_HARD',
        'label': 'ループ維持',
        'description': '長いエッジループ状の切れ目やモデルの流れに沿った境界を残し、読みやすいUVシームを優先します。',
        'merge': 26.0, 'angle_deg': 66.0, 'area_weight': 0.25, 'unwrap_math': 'ANGLE_BASED',
        'quality': 60.0, 'area': 55.0, 'shape': 70.0, 'native': 34.0, 'iterations': 40,
        'stretch_iterations': 120, 'stretch_blend': 0.75,
        'angle_keep': 74.0, 'stretch_keep': 66.0, 'loop_keep': 98.0, 'planarity': 64.0,
        'density': 54.0, 'existing': 82.0, 'boundary': 86.0, 'small': 24.0,
        'auto_pack': True, 'pack_margin': 0.02, 'pack_margin_method': 'FRACTION', 'pack_rotate_method': 'CARDINAL',
        'pre_fix_mesh': False, 'merge_distance': 0.0001,
    },
    'AREA_ACCURATE': {
        'mode': 'SMART',
        'label': '面積精度',
        'description': '元メッシュの面面積比率を強く維持し、テクセル密度のばらつきを抑える設定です。',
        'merge': 42.0, 'angle_deg': 70.0, 'area_weight': 0.85, 'unwrap_math': 'ANGLE_BASED',
        'quality': 88.0, 'area': 96.0, 'shape': 64.0, 'native': 12.0, 'iterations': 80,
        'stretch_iterations': 160, 'stretch_blend': 0.90,
        'angle_keep': 55.0, 'stretch_keep': 82.0, 'loop_keep': 52.0, 'planarity': 56.0,
        'density': 98.0, 'existing': 58.0, 'boundary': 70.0, 'small': 64.0,
        'auto_pack': True, 'pack_margin': 0.02, 'pack_margin_method': 'SCALED', 'pack_rotate_method': 'ANY',
        'pre_fix_mesh': False, 'merge_distance': 0.0001,
    },
    'QUALITY_OPTIMIZE': {
        'mode': 'SMART_STANDARD_ORGANIC',
        'label': '品質最適化',
        'description': '高品質補正を強め、面積維持と形状維持の反復を増やして、標準結果からより整ったUVへ寄せます。',
        'merge': 34.0, 'angle_deg': 70.0, 'area_weight': 0.40, 'unwrap_math': 'ANGLE_BASED',
        'quality': 100.0, 'area': 82.0, 'shape': 86.0, 'native': 8.0, 'iterations': 120,
        'stretch_iterations': 240, 'stretch_blend': 1.0,
        'angle_keep': 62.0, 'stretch_keep': 88.0, 'loop_keep': 62.0, 'planarity': 68.0,
        'density': 84.0, 'existing': 62.0, 'boundary': 58.0, 'small': 52.0,
        'auto_pack': True, 'pack_margin': 0.02, 'pack_margin_method': 'SCALED', 'pack_rotate_method': 'ANY',
        'pre_fix_mesh': False, 'merge_distance': 0.0001,
    },
    'CLEAN_MERGE': {
        'mode': 'SMART_STANDARD_ORGANIC',
        'label': '小島整理',
        'description': '細かい島や短く途切れた境界を優先して統合し、島数を減らして見やすい配置へ寄せます。',
        'merge': 68.0, 'angle_deg': 82.0, 'area_weight': 0.35, 'unwrap_math': 'ANGLE_BASED',
        'quality': 70.0, 'area': 64.0, 'shape': 58.0, 'native': 22.0, 'iterations': 52,
        'stretch_iterations': 120, 'stretch_blend': 0.80,
        'angle_keep': 48.0, 'stretch_keep': 66.0, 'loop_keep': 42.0, 'planarity': 56.0,
        'density': 62.0, 'existing': 38.0, 'boundary': 92.0, 'small': 96.0,
        'auto_pack': True, 'pack_margin': 0.018, 'pack_margin_method': 'FRACTION', 'pack_rotate_method': 'ANY',
        'pre_fix_mesh': False, 'merge_distance': 0.0001,
    },
    'PACK_STABLE': {
        'mode': 'SMART',
        'label': 'パック安定',
        'description': '統合後の島を安全にパックしやすい設定です。面積補正と標準結果維持を中程度に保ちます。',
        'merge': 38.0, 'angle_deg': 72.0, 'area_weight': 0.20, 'unwrap_math': 'CONFORMAL',
        'quality': 64.0, 'area': 70.0, 'shape': 70.0, 'native': 28.0, 'iterations': 48,
        'stretch_iterations': 100, 'stretch_blend': 0.75,
        'angle_keep': 70.0, 'stretch_keep': 70.0, 'loop_keep': 70.0, 'planarity': 70.0,
        'density': 70.0, 'existing': 70.0, 'boundary': 60.0, 'small': 50.0,
        'auto_pack': True, 'pack_margin': 0.03, 'pack_margin_method': 'FRACTION', 'pack_rotate_method': 'CARDINAL',
        'pre_fix_mesh': False, 'merge_distance': 0.0001,
    },

    'HARD_CHART_PRECISION': {
        'mode': 'SMART_STANDARD_HARD',
        'label': '高精度チャート: ハードサーフェス',
        'description': '凹凸角度、既存シーム、低ストレッチ、少ないチャート数をバランスさせるハードサーフェス向けの高精度チャート設定です。',
        'merge': 18.0, 'angle_deg': 48.0, 'area_weight': 0.18, 'unwrap_math': 'CONFORMAL',
        'quality': 72.0, 'area': 62.0, 'shape': 88.0, 'native': 24.0, 'iterations': 72,
        'stretch_iterations': 160, 'stretch_blend': 0.90,
        'angle_keep': 98.0, 'stretch_keep': 82.0, 'loop_keep': 86.0, 'planarity': 92.0,
        'density': 68.0, 'existing': 96.0, 'boundary': 74.0, 'small': 28.0,
        'auto_pack': True, 'pack_margin': 0.024, 'pack_margin_method': 'SCALED', 'pack_rotate_method': 'CARDINAL',
        'pre_fix_mesh': False, 'merge_distance': 0.0001,
        'reference_enabled': True, 'reference_profile': 'HARD_SURFACE_CHART', 'reference_strength': 78.0,
        'reference_allowed_stretch': 24.0, 'reference_concave_angle': 52.0, 'reference_convex_angle': 42.0,
        'reference_existing': 100.0, 'reference_fewer_charts': 64.0, 'reference_loop': 82.0,
        'reference_triangle': 18.0, 'reference_cylindrical': 42.0,
    },
    'ORGANIC_LOW_DISTORTION_PRECISION': {
        'mode': 'SMART_STANDARD_ORGANIC',
        'label': '高精度チャート: オーガニック低歪み',
        'description': '許容ストレッチと追加チャートカットを使い、曲面を大きく保ちながら伸びの強い部分だけを切り分けます。',
        'merge': 46.0, 'angle_deg': 86.0, 'area_weight': 0.48, 'unwrap_math': 'ANGLE_BASED',
        'quality': 86.0, 'area': 78.0, 'shape': 72.0, 'native': 12.0, 'iterations': 96,
        'stretch_iterations': 260, 'stretch_blend': 1.0,
        'angle_keep': 50.0, 'stretch_keep': 98.0, 'loop_keep': 60.0, 'planarity': 72.0,
        'density': 86.0, 'existing': 72.0, 'boundary': 72.0, 'small': 54.0,
        'auto_pack': True, 'pack_margin': 0.022, 'pack_margin_method': 'SCALED', 'pack_rotate_method': 'ANY',
        'pre_fix_mesh': False, 'merge_distance': 0.0001,
        'reference_enabled': True, 'reference_profile': 'ORGANIC_LOW_DISTORTION', 'reference_strength': 70.0,
        'reference_allowed_stretch': 18.0, 'reference_concave_angle': 78.0, 'reference_convex_angle': 78.0,
        'reference_existing': 78.0, 'reference_fewer_charts': 76.0, 'reference_loop': 48.0,
        'reference_triangle': 8.0, 'reference_cylindrical': 58.0,
    },
    'SELECTED_SCOPE_LOW_DISTORTION': {
        'mode': 'SMART_STANDARD_ORGANIC',
        'label': '選択面スコープ: 低歪み展開',
        'description': '選択面スコープ内で引張予測とリラックスを強く使い、低歪み化を優先する設定です。',
        'merge': 28.0, 'angle_deg': 72.0, 'area_weight': 0.72, 'unwrap_math': 'ANGLE_BASED',
        'quality': 96.0, 'area': 88.0, 'shape': 92.0, 'native': 6.0, 'iterations': 132,
        'stretch_iterations': 320, 'stretch_blend': 1.0,
        'angle_keep': 64.0, 'stretch_keep': 100.0, 'loop_keep': 58.0, 'planarity': 66.0,
        'density': 92.0, 'existing': 80.0, 'boundary': 66.0, 'small': 38.0,
        'auto_pack': True, 'pack_margin': 0.02, 'pack_margin_method': 'SCALED', 'pack_rotate_method': 'ANY',
        'pre_fix_mesh': False, 'merge_distance': 0.0001,
        'reference_enabled': True, 'reference_profile': 'SELECTED_SCOPE_LOW_STRETCH', 'reference_strength': 84.0,
        'reference_allowed_stretch': 12.0, 'reference_concave_angle': 66.0, 'reference_convex_angle': 60.0,
        'reference_existing': 86.0, 'reference_fewer_charts': 58.0, 'reference_loop': 56.0,
        'reference_triangle': 12.0, 'reference_cylindrical': 54.0,
    },
    'SINGLE_ISLAND': {
        'label': 'Singleアイランド',
        'description': '現在の展開方式を維持したまま結合率を100%にし、1つのUVアイランドへ到達する設定へ切り替えます。',
        'merge': 100.0, 'angle_deg': 89.0, 'area_weight': 0.50, 'unwrap_math': 'ANGLE_BASED',
        'quality': 76.0, 'area': 82.0, 'shape': 62.0, 'native': 0.0, 'iterations': 72,
        'stretch_iterations': 180, 'stretch_blend': 1.0,
        'angle_keep': 0.0, 'stretch_keep': 40.0, 'loop_keep': 0.0, 'planarity': 24.0,
        'density': 72.0, 'existing': 0.0, 'boundary': 100.0, 'small': 100.0,
        'auto_pack': True, 'pack_margin': 0.02, 'pack_margin_method': 'FRACTION', 'pack_rotate_method': 'ANY',
        'pre_fix_mesh': False, 'merge_distance': 0.0001,
    },
}


_SUS_SMART_STANDARD_ACTUAL_UNWRAP_MODES = {'SMART_STANDARD_HARD', 'SMART_STANDARD_ORGANIC', 'SMART', 'NORMAL'}
_SUS_SMART_STANDARD_UNWRAP_MODE_ORDER = (
    'CUSTOM',
    'SMART_STANDARD_HARD', 'SMART_STANDARD_ORGANIC', 'SMART', 'NORMAL',
    'STANDARD_KEEP', 'BALANCED', 'LOW_STRETCH', 'LOOP_SAFE',
    'AREA_ACCURATE', 'QUALITY_OPTIMIZE', 'CLEAN_MERGE', 'PACK_STABLE', 'HARD_CHART_PRECISION', 'ORGANIC_LOW_DISTORTION_PRECISION', 'SELECTED_SCOPE_LOW_DISTORTION', 'SINGLE_ISLAND',
)
_SUS_SMART_STANDARD_UNWRAP_MODE_LABELS = {
    'CUSTOM': ('カスタム', '展開方式と各数値を自動変更せず、現在の設定をそのまま使います。変更した全項目はSmart_UV_Suite.jsonへ即時保存され、Blender再起動後も維持されます。'),
    'SMART_STANDARD_HARD': ('Smart Standard: ハードサーフェス', '硬い折れ目、直線的な稜線、既存シームを強く維持するハードサーフェス向け設定です。'),
    'SMART_STANDARD_ORGANIC': ('Smart Standard: Organic', '滑らかな曲面を広めの島へ統合し、角度より引張と平面性を優先する有機形状向け設定です。'),
    'SMART': ('Standard Smart投影', 'Blender標準Smart投影に近い結果を保ちながら、必要分だけシーム解析と品質補正を適用します。'),
    'NORMAL': ('Normal Unwrap', '現在の手動シームを尊重しながら、品質補正とパッキングを行う通常展開設定です。'),
}
_SUS_SMART_STANDARD_MODE_TO_PRESET = {
    'SMART_STANDARD_HARD': 'HARD_SURFACE',
    'SMART_STANDARD_ORGANIC': 'ORGANIC',
    'SMART': 'STANDARD_SMART',
    'NORMAL': 'NORMAL_UNWRAP',
    'HARD_SURFACE': 'HARD_SURFACE',
    'ORGANIC': 'ORGANIC',
    'STANDARD_SMART': 'STANDARD_SMART',
    'NORMAL_UNWRAP': 'NORMAL_UNWRAP',
}


def _suv_smart_standard_seam_profile_items(self=None, context=None):
    # Compatibility RNA list for saved files created before the seam preset was
    # merged into the single visible 展開モード control.
    order = (
        'CUSTOM', 'STANDARD_KEEP', 'BALANCED', 'HARD_SURFACE', 'ORGANIC',
        'STANDARD_SMART', 'NORMAL_UNWRAP', 'LOW_STRETCH', 'LOOP_SAFE',
        'AREA_ACCURATE', 'QUALITY_OPTIMIZE', 'CLEAN_MERGE', 'PACK_STABLE', 'HARD_CHART_PRECISION', 'ORGANIC_LOW_DISTORTION_PRECISION', 'SELECTED_SCOPE_LOW_DISTORTION', 'SINGLE_ISLAND',
    )
    result = []
    for key in order:
        data = _SUS_SMART_STANDARD_SEAM_PRESETS.get(key, {})
        result.append((key, str(data.get('label', key)), str(data.get('description', ''))))
    return tuple(result)


def _suv_smart_standard_unwrap_mode_items(self=None, context=None):
    result = []
    for key in _SUS_SMART_STANDARD_UNWRAP_MODE_ORDER:
        if key in _SUS_SMART_STANDARD_UNWRAP_MODE_LABELS:
            label, desc = _SUS_SMART_STANDARD_UNWRAP_MODE_LABELS[key]
        else:
            data = _SUS_SMART_STANDARD_SEAM_PRESETS.get(key, {})
            label = str(data.get('label', key))
            desc = str(data.get('description', ''))
        result.append((key, label, desc))
    return tuple(result)


def _suv_smart_standard_preset_key(selection: str) -> str:
    key = str(selection or 'CUSTOM').upper()
    return _SUS_SMART_STANDARD_MODE_TO_PRESET.get(key, key)


def _suv_smart_standard_actual_mode_for_selection(ws, selection: str, data=None) -> str:
    key = str(selection or 'SMART_STANDARD_HARD').upper()
    if key in _SUS_SMART_STANDARD_ACTUAL_UNWRAP_MODES:
        return key
    if key in {'CUSTOM', 'SINGLE_ISLAND'}:
        for attr in ('smart_standard_core_resolved_unwrap_mode', 'smart_standard_core_last_actual_unwrap_mode'):
            try:
                value = str(getattr(ws, attr, '') or '').upper()
            except Exception:
                value = ''
            if value in _SUS_SMART_STANDARD_ACTUAL_UNWRAP_MODES:
                return value
        try:
            value = str(getattr(ws, 'smart_standard_core_unwrap_mode', '') or '').upper()
        except Exception:
            value = ''
        if value in _SUS_SMART_STANDARD_ACTUAL_UNWRAP_MODES:
            return value
    if data:
        value = str((data or {}).get('mode') or '').upper()
        if value in _SUS_SMART_STANDARD_ACTUAL_UNWRAP_MODES:
            return value
    preset_key = _suv_smart_standard_preset_key(key)
    preset_data = _SUS_SMART_STANDARD_SEAM_PRESETS.get(preset_key, {})
    value = str(preset_data.get('mode') or '').upper()
    if value in _SUS_SMART_STANDARD_ACTUAL_UNWRAP_MODES:
        return value
    return 'SMART_STANDARD_HARD'


def _suv_smart_standard_visible_value_for_profile(profile: str, actual_mode: str) -> str:
    key = str(profile or 'CUSTOM').upper()
    if key == 'HARD_SURFACE':
        return 'SMART_STANDARD_HARD'
    if key == 'ORGANIC':
        return 'SMART_STANDARD_ORGANIC'
    if key == 'STANDARD_SMART':
        return 'SMART'
    if key == 'NORMAL_UNWRAP':
        return 'NORMAL'
    if key in _SUS_SMART_STANDARD_UNWRAP_MODE_ORDER:
        return key
    actual = str(actual_mode or 'SMART_STANDARD_HARD').upper()
    return actual if actual in _SUS_SMART_STANDARD_ACTUAL_UNWRAP_MODES else 'SMART_STANDARD_HARD'


def _suv_set_workspace_value(ws, name: str, value) -> None:
    if ws is None or not hasattr(ws, name):
        return
    try:
        setattr(ws, name, value)
    except Exception:
        pass


def _suv_apply_smart_standard_seam_preset(ws, preset: str, *, update_visible_mode: bool = False) -> None:
    if ws is None:
        return
    selected_key = str(preset or 'CUSTOM').upper()
    preset_key = _suv_smart_standard_preset_key(selected_key)
    data = dict(_SUS_SMART_STANDARD_SEAM_PRESETS.get(preset_key) or {})
    actual_mode = _suv_smart_standard_actual_mode_for_selection(ws, selected_key, data)
    if selected_key == 'CUSTOM' or preset_key == 'CUSTOM' or not data:
        _suv_set_workspace_value(ws, 'smart_standard_core_resolved_unwrap_mode', actual_mode)
        _suv_set_workspace_value(ws, 'smart_standard_core_last_actual_unwrap_mode', actual_mode)
        return
    try:
        import math as _math
        angle_rad = _math.radians(float(data.get('angle_deg', 66.0)))
    except Exception:
        angle_rad = 1.1519173063162575
    scalar_map = {
        'smart_standard_core_seam_merge_strength': data.get('merge', 0.0),
        'smart_standard_core_smart_angle': angle_rad,
        'smart_standard_core_smart_area_weight': data.get('area_weight', 0.0),
        'smart_standard_core_quality_strength': data.get('quality', 0.0),
        'smart_standard_core_area_preserve_strength': data.get('area', 0.0),
        'smart_standard_core_shape_preserve_strength': data.get('shape', 0.0),
        'smart_standard_core_native_result_preserve': data.get('native', 100.0),
        'smart_standard_core_quality_iterations': int(data.get('iterations', 0)),
        'smart_standard_core_stretch_iterations': int(data.get('stretch_iterations', 0)),
        'smart_standard_core_stretch_blend': data.get('stretch_blend', 0.0),
        'smart_standard_core_single_angle_weight': data.get('angle_keep', 72.0),
        'smart_standard_core_single_stretch_weight': data.get('stretch_keep', 72.0),
        'smart_standard_core_single_loop_weight': data.get('loop_keep', 62.0),
        'smart_standard_core_single_planarity_weight': data.get('planarity', 55.0),
        'smart_standard_core_single_density_weight': data.get('density', 55.0),
        'smart_standard_core_single_user_seam_weight': data.get('existing', 80.0),
        'smart_standard_core_single_boundary_weight': data.get('boundary', 46.0),
        'smart_standard_core_single_small_island_merge': data.get('small', 42.0),
        # Legacy aliases kept in sync for saved workspaces and older code paths.
        'smart_standard_core_single_seam_angle_weight': data.get('angle_keep', 72.0),
        'smart_standard_core_single_seam_stretch_weight': data.get('stretch_keep', 72.0),
        'smart_standard_core_single_seam_loop_weight': data.get('loop_keep', 62.0),
        'smart_standard_core_single_seam_area_weight': data.get('density', 55.0),
        'smart_standard_core_single_seam_shared_boundary_weight': data.get('boundary', 46.0),
        'smart_standard_core_single_seam_jagged_cleanup_weight': data.get('small', 42.0),
        'smart_standard_core_auto_pack': data.get('auto_pack', True),
        'smart_standard_core_pack_margin': data.get('pack_margin', 0.02),
        'smart_standard_core_pre_fix_mesh': data.get('pre_fix_mesh', True),
        'smart_standard_core_merge_distance': data.get('merge_distance', 0.0001),
        'smart_standard_core_reference_refine_enabled': data.get('reference_enabled', True),
        'smart_standard_core_reference_strength': data.get('reference_strength', 0.0),
        'smart_standard_core_reference_allowed_stretch': data.get('reference_allowed_stretch', 24.0),
        'smart_standard_core_reference_concave_angle': data.get('reference_concave_angle', 55.0),
        'smart_standard_core_reference_convex_angle': data.get('reference_convex_angle', 45.0),
        'smart_standard_core_reference_existing_seam_weight': data.get('reference_existing', 85.0),
        'smart_standard_core_reference_fewer_charts': data.get('reference_fewer_charts', 50.0),
        'smart_standard_core_reference_loop_weight': data.get('reference_loop', 60.0),
        'smart_standard_core_reference_triangle_border': data.get('reference_triangle', 10.0),
        'smart_standard_core_reference_cylindrical_loop': data.get('reference_cylindrical', 50.0),
        'smart_standard_core_resolved_unwrap_mode': actual_mode,
        'smart_standard_core_last_actual_unwrap_mode': actual_mode,
    }
    for prop_name, value in scalar_map.items():
        _suv_set_workspace_value(ws, prop_name, value)
    _suv_set_workspace_value(ws, 'smart_standard_core_unwrap_math', data.get('unwrap_math', 'ANGLE_BASED'))
    _suv_set_workspace_value(ws, 'smart_standard_core_pack_margin_method', data.get('pack_margin_method', 'FRACTION'))
    _suv_set_workspace_value(ws, 'smart_standard_core_pack_rotate_method', data.get('pack_rotate_method', 'ANY'))
    _suv_set_workspace_value(ws, 'smart_standard_core_reference_profile', data.get('reference_profile', 'BALANCED'))
    _suv_set_workspace_value(ws, 'smart_standard_core_single_seam_profile', preset_key)
    if update_visible_mode:
        visible_value = _suv_smart_standard_visible_value_for_profile(preset_key, actual_mode)
        _suv_set_workspace_value(ws, 'smart_standard_core_unwrap_mode', visible_value)


def _suv_smart_standard_seam_profile_update(self, context):
    # Compatibility path for old saved workspaces. The visible preset control is
    # now smart_standard_core_unwrap_mode, so this hidden property only mirrors
    # legacy values into the unified selector.
    global _SUV_PRESET_APPLY_GUARD
    if _SUV_PRESET_APPLY_GUARD:
        return
    _SUV_PRESET_APPLY_GUARD = True
    try:
        _suv_apply_smart_standard_seam_preset(self, getattr(self, 'smart_standard_core_single_seam_profile', 'CUSTOM'), update_visible_mode=True)
    finally:
        _SUV_PRESET_APPLY_GUARD = False
    _suv_workspace_settings_update(self, context)
    _suv_force_workspace_json_save(context, self)
    _suv_schedule_realtime_if_needed(self, context)


def _suv_smart_standard_unwrap_mode_update(self, context):
    global _SUV_PRESET_APPLY_GUARD
    if _SUV_PRESET_APPLY_GUARD:
        return
    _SUV_PRESET_APPLY_GUARD = True
    try:
        _suv_apply_smart_standard_seam_preset(self, getattr(self, 'smart_standard_core_unwrap_mode', 'SMART_STANDARD_HARD'), update_visible_mode=False)
    finally:
        _SUV_PRESET_APPLY_GUARD = False
    _suv_workspace_settings_update(self, context)
    _suv_force_workspace_json_save(context, self)
    _suv_schedule_realtime_if_needed(self, context)


def _suv_apply_smart_preset_values_from_package(ws, preset: str) -> None:
    if ws is None:
        return
    try:
        import sys
        pkg = sys.modules.get(__package__) or sys.modules.get('smart_uv_suite')
        presets = getattr(pkg, '_SUS_SMART_UNWRAP_PRESETS', {}) if pkg is not None else {}
        data = dict(presets.get(preset) or presets.get('STANDARD') or {})
    except Exception:
        data = {}
    mapping = {
        'auto_cut_mode': 'smart_unwrap_auto_cut_mode',
        'preserve_no_seam_connected': 'smart_unwrap_preserve_no_seam_connected',
        'angle': 'smart_unwrap_angle_threshold',
        'pull': 'smart_unwrap_pull_distance',
        'curvature': 'smart_unwrap_curvature_sensitivity',
        'planarity': 'smart_unwrap_planarity_tolerance',
        'sliver': 'smart_unwrap_sliver_ratio',
        'margin': 'smart_unwrap_island_margin',
        'relax': 'smart_unwrap_relax_iterations',
        'method': 'smart_unwrap_solver',
        'align': 'smart_unwrap_align_mode',
        'cut_sharp': 'smart_unwrap_cut_sharp_edges',
        'cut_boundary': 'smart_unwrap_cut_boundary_edges',
        'cut_nonmanifold': 'smart_unwrap_cut_nonmanifold_edges',
        'cut_material': 'smart_unwrap_cut_material_edges',
        'cut_uv': 'smart_unwrap_cut_uv_discontinuity',
        'average': 'smart_unwrap_average_scale',
        'pack': 'smart_unwrap_pack_after',
        'peel_iterations': 'smart_unwrap_peel_iterations',
        'peel_iter': 'smart_unwrap_peel_iterations',
        'spring_strength': 'smart_unwrap_spring_strength',
        'stretch': 'smart_unwrap_spring_strength',
        'boundary_weight': 'smart_unwrap_boundary_weight',
        'boundary': 'smart_unwrap_boundary_weight',
        'area_weight': 'smart_unwrap_area_weight',
        'area': 'smart_unwrap_area_weight',
        'overlap_push': 'smart_unwrap_overlap_push',
        'overlap': 'smart_unwrap_overlap_push',
        'overlap_policy': 'smart_unwrap_overlap_policy',
        'chart_spread': 'smart_unwrap_chart_spread',
        'overlap_resolve_passes': 'smart_unwrap_overlap_resolve_passes',
        'split_tolerance': 'smart_unwrap_split_tolerance',
    }
    for key, prop in mapping.items():
        if key not in data or not hasattr(ws, prop):
            continue
        try:
            setattr(ws, prop, data[key])
        except Exception:
            pass


def _suv_apply_auto_preset_values_from_package(ws, preset: str) -> None:
    if ws is None:
        return
    try:
        import sys
        pkg = sys.modules.get(__package__) or sys.modules.get('smart_uv_suite')
        presets = getattr(pkg, '_SUS_AUTO_UNWRAP_PRESETS', {}) if pkg is not None else {}
        data = dict(presets.get(preset) or presets.get('AUTO_BALANCED') or {})
    except Exception:
        data = {}
    mapping = {
        'quality': 'auto_unwrap_quality',
        'angle_deg': 'auto_unwrap_angle_threshold',
        'curvature': 'auto_unwrap_curvature_sensitivity',
        'pull_distance': 'auto_unwrap_pull_distance',
        'margin': 'auto_unwrap_island_margin',
        'relax_iterations': 'auto_unwrap_relax_iterations',
        'pack_after': 'auto_unwrap_pack_after',
    }
    for key, prop in mapping.items():
        if key not in data or not hasattr(ws, prop):
            continue
        try:
            setattr(ws, prop, data[key])
        except Exception:
            pass


def _suv_smart_unwrap_preset_update(self, context):
    """Shape is a layout variation, not a parameter preset.

    Changing Standard / Square / Circle must not rewrite Strength, Flexibility,
    Tolerance or Orientation.  The dropdown only switches the boundary target used by the Smart
    peel solver; all numeric controls remain exactly as the user set them.
    """
    global _SUV_PRESET_APPLY_GUARD
    # Hidden compatibility shape only.  It must not rewrite the visible Method
    # because Square and Circle are now separate methods.
    _suv_smart_realtime_update(self, context)




def _suv_unwrap_realtime_combined_update(self, context):
    """Unified realtime unwrap toggle used by the UV Unwrap UI.

    The UI previously exposed both Smart realtime preview and Blender Live
    Unwrap, which made the same feature look like two separate switches.  Keep
    a single property and mirror it to Blender's live unwrap flag when that flag
    exists, while preserving the usual workspace persistence update.
    """
    try:
        ts = getattr(getattr(context, 'scene', None), 'tool_settings', None) or getattr(context, 'tool_settings', None)
        attr = ''
        if ts is not None and hasattr(ts, 'use_edge_path_live_unwrap'):
            attr = 'use_edge_path_live_unwrap'
        elif ts is not None and hasattr(ts, 'use_live_unwrap'):
            attr = 'use_live_unwrap'
        if attr:
            setattr(ts, attr, bool(getattr(self, 'smart_unwrap_realtime_preview', False)))
    except Exception:
        pass
    try:
        _suv_workspace_settings_update(self, context)
    except Exception:
        pass

def _suv_auto_unwrap_preset_update(self, context):
    global _SUV_PRESET_APPLY_GUARD
    if not _SUV_PRESET_APPLY_GUARD:
        _SUV_PRESET_APPLY_GUARD = True
        try:
            preset = str(getattr(self, 'auto_unwrap_preset', 'AUTO_BALANCED') or 'AUTO_BALANCED')
            try:
                self.auto_unwrap_mode = 'BLENDER_ANGLE_BASED'
            except Exception:
                pass
            _suv_apply_auto_preset_values_from_package(self, preset)
        finally:
            _SUV_PRESET_APPLY_GUARD = False
    _suv_workspace_settings_update(self, context)

_SUV_UNWRAP_MAP_CHANNEL_ITEMS_CACHE = {}


def _suv_unwrap_map_channel_items(self=None, context=None):
    global _SUV_UNWRAP_MAP_CHANNEL_ITEMS_CACHE
    try:
        from . import uv_map_channels as _uvc
        items = list(_uvc.map_channel_enum_items(context or bpy.context))
        # Older builds persisted bare numeric identifiers such as "1". Keep
        # only the currently stored legacy value valid long enough for the
        # registration repair to migrate it without an invalid-enum warning.
        raw = None
        try:
            raw = self.get('unwrap_map_channel') if self is not None else None
        except Exception:
            raw = None
        raw_text = str(raw).strip() if raw is not None else ''
        represented_identifiers = {
            str(item[0]) for item in items if item
        }
        if raw_text.isdigit() and raw_text not in represented_identifiers:
            channel_index = max(0, int(raw_text))
            # Legacy INT IDProperty absorption: Blender resolves a stored enum
            # IDProperty by item *value*, not identifier, so this repair item
            # must carry the raw integer itself as its explicit value.  Items
            # without an explicit value get their list position, so positions
            # 0..len(items)-1 are already taken; only a raw value outside that
            # range is unrepresented and needs absorbing.  (A mismatched value
            # here left every RNA read logging "current value '1' matches no
            # enum in 'SUV_PG_WorkspaceSettings'" on saved workspaces.)
            if channel_index >= len(items):
                items.append((
                    raw_text,
                    f'{channel_index}: Legacy UV Map',
                    'Legacy numeric UV map channel; it will be migrated automatically.',
                    0,
                    channel_index,
                ))
        result = tuple(items)
        # Blender keeps references to strings returned by dynamic EnumProperty
        # callbacks. Retain a bounded cache so legacy repair items stay alive.
        cache_key = (tuple(tuple(item) for item in result), raw_text)
        _SUV_UNWRAP_MAP_CHANNEL_ITEMS_CACHE[cache_key] = result
        while len(_SUV_UNWRAP_MAP_CHANNEL_ITEMS_CACHE) > 32:
            _SUV_UNWRAP_MAP_CHANNEL_ITEMS_CACHE.pop(next(iter(_SUV_UNWRAP_MAP_CHANNEL_ITEMS_CACHE)))
        return _SUV_UNWRAP_MAP_CHANNEL_ITEMS_CACHE[cache_key]
    except Exception:
        return (('ACTIVE', '現在のアクティブ', '現在アクティブなUVマップを展開に使用します。'),)



def _suv_map_channel_copy_source_items(self=None, context=None):
    try:
        from . import uv_map_channels as _uvc
        return _uvc.map_channel_copy_source_enum_items(context or bpy.context)
    except Exception:
        return (('ACTIVE', '現在のアクティブ', '現在アクティブなUVマップをコピー元にします。'),)


def _suv_map_channel_copy_destination_items(self=None, context=None):
    try:
        from . import uv_map_channels as _uvc
        return _uvc.map_channel_copy_destination_enum_items(context or bpy.context)
    except Exception:
        return (('TARGET_UNWRAP', '展開使用チャンネル', '展開使用マップチャンネルで選択中のチャンネルへ書き込みます。'),)

_SUV_UNWRAP_MAP_CHANNEL_UPDATE_ACTIVE = False


def _suv_unwrap_map_channel_update(self, context):
    """Update callback entry.  The body re-assigns unwrap_map_channel (normalised
    channel id), which re-enters this callback once; the outermost call already
    runs the whole body, so a nested call returns at once."""
    global _SUV_UNWRAP_MAP_CHANNEL_UPDATE_ACTIVE
    if _SUV_UNWRAP_MAP_CHANNEL_UPDATE_ACTIVE:
        return
    _SUV_UNWRAP_MAP_CHANNEL_UPDATE_ACTIVE = True
    try:
        _suv_unwrap_map_channel_update_body(self, context)
    finally:
        _SUV_UNWRAP_MAP_CHANNEL_UPDATE_ACTIVE = False


def _suv_unwrap_map_channel_update_body(self, context):
    try:
        from . import uv_map_channels as _uvc
        update_fn = getattr(_uvc, 'workspace_channel_update', None)
        if callable(update_fn):
            update_fn(context or bpy.context, self)
        else:
            _uvc.ensure_unwrap_map_channel(context or bpy.context, self)
    except Exception:
        pass
    try:
        _suv_workspace_settings_update(self, context)
    except Exception:
        pass
    try:
        _suv_schedule_realtime_if_needed(self, context)
    except Exception:
        pass



def _suv_auto_seam_preset_update(self, context):
    """Apply grouped automatic seam settings from a single preset."""
    preset = str(getattr(self, 'auto_seam_preset', 'BALANCED') or 'BALANCED').upper()
    if preset == 'MANUAL':
        _suv_workspace_settings_update(self, context)
        return
    table = {
        'BALANCED': dict(angle=60.0, threshold=45, angle_w=70, sharp_w=65, material_w=60, boundary_w=75, stretch_w=45, loop_w=55, cylinder_w=55, nonmanifold_w=100, clear=False, compliant=True, clear_internal=True),
        'HARD_SURFACE': dict(angle=48.0, threshold=38, angle_w=95, sharp_w=90, material_w=72, boundary_w=86, stretch_w=42, loop_w=52, cylinder_w=42, nonmanifold_w=100, clear=False, compliant=True, clear_internal=True),
        'ORGANIC': dict(angle=78.0, threshold=56, angle_w=50, sharp_w=30, material_w=30, boundary_w=70, stretch_w=72, loop_w=42, cylinder_w=62, nonmanifold_w=100, clear=False, compliant=True, clear_internal=True),
        'CYLINDER': dict(angle=72.0, threshold=34, angle_w=52, sharp_w=38, material_w=35, boundary_w=88, stretch_w=52, loop_w=92, cylinder_w=100, nonmanifold_w=100, clear=False, compliant=True, clear_internal=True),
        'CYLINDER_SINGLE': dict(angle=84.0, threshold=28, angle_w=38, sharp_w=20, material_w=20, boundary_w=95, stretch_w=44, loop_w=100, cylinder_w=100, nonmanifold_w=100, clear=False, compliant=True, clear_internal=True),
        'LOW_STRETCH': dict(angle=62.0, threshold=36, angle_w=74, sharp_w=52, material_w=45, boundary_w=82, stretch_w=100, loop_w=68, cylinder_w=72, nonmanifold_w=100, clear=False, compliant=True, clear_internal=True),
        'LOOP_SAFE': dict(angle=64.0, threshold=40, angle_w=62, sharp_w=45, material_w=40, boundary_w=78, stretch_w=52, loop_w=100, cylinder_w=82, nonmanifold_w=100, clear=False, compliant=True, clear_internal=True),
        'MARK_SEAM_COMPLIANT': dict(angle=60.0, threshold=45, angle_w=70, sharp_w=65, material_w=60, boundary_w=75, stretch_w=45, loop_w=55, cylinder_w=55, nonmanifold_w=100, clear=False, compliant=True, clear_internal=True),
    }
    data = table.get(preset, table['BALANCED'])
    try:
        self.auto_seam_angle_threshold = math.radians(float(data['angle']))
        self.auto_seam_mark_threshold = float(data['threshold'])
        self.auto_seam_angle_weight = float(data['angle_w'])
        self.auto_seam_sharp_weight = float(data['sharp_w'])
        self.auto_seam_material_weight = float(data['material_w'])
        self.auto_seam_boundary_weight = float(data['boundary_w'])
        self.auto_seam_stretch_weight = float(data['stretch_w'])
        self.auto_seam_loop_weight = float(data['loop_w'])
        self.auto_seam_cylinder_weight = float(data['cylinder_w'])
        self.auto_seam_nonmanifold_weight = float(data['nonmanifold_w'])
        self.auto_seam_clear_existing = bool(data['clear'])
        self.seam_mark_compliant_unwrap = bool(data['compliant'])
        self.seam_mark_compliance_clear_internal = bool(data['clear_internal'])
    except Exception:
        pass
    _suv_workspace_settings_update(self, context)



# ---------------------------------------------------------------------------
# Seam / Pin Pro settings
# ---------------------------------------------------------------------------
_SUS_AUTO_SEAM_PRESET_VALUES = {
    'CUSTOM': {},
    'BALANCED': dict(angle_threshold=60.0, min_score=58.0, angle=68.0, stretch=44.0, loop=42.0, tube=35.0, tube_window=24.0, boundary=90.0, material=78.0, sharp=72.0, clear=False, boundaries=True),
    'HARD_SURFACE': dict(angle_threshold=48.0, min_score=50.0, angle=92.0, stretch=38.0, loop=34.0, tube=25.0, tube_window=20.0, boundary=100.0, material=80.0, sharp=95.0, clear=False, boundaries=True),
    'ORGANIC': dict(angle_threshold=74.0, min_score=64.0, angle=45.0, stretch=72.0, loop=54.0, tube=42.0, tube_window=28.0, boundary=84.0, material=42.0, sharp=40.0, clear=False, boundaries=True),
    'CYLINDER_TUBE': dict(angle_threshold=58.0, min_score=50.0, angle=56.0, stretch=60.0, loop=86.0, tube=100.0, tube_window=12.0, boundary=96.0, material=55.0, sharp=52.0, clear=False, boundaries=True),
    'LOW_STRETCH': dict(angle_threshold=62.0, min_score=46.0, angle=70.0, stretch=100.0, loop=55.0, tube=58.0, tube_window=20.0, boundary=95.0, material=65.0, sharp=70.0, clear=False, boundaries=True),
    'LOOP_SAFE': dict(angle_threshold=64.0, min_score=56.0, angle=60.0, stretch=55.0, loop=100.0, tube=76.0, tube_window=16.0, boundary=90.0, material=55.0, sharp=60.0, clear=False, boundaries=True),
    'UV_ATLAS': dict(angle_threshold=56.0, min_score=52.0, angle=72.0, stretch=80.0, loop=62.0, tube=55.0, tube_window=22.0, boundary=100.0, material=70.0, sharp=75.0, clear=False, boundaries=True),
    'SINGLE_ISLAND': dict(angle_threshold=89.0, min_score=90.0, angle=15.0, stretch=15.0, loop=70.0, tube=100.0, boundary=30.0, material=0.0, sharp=10.0, clear=True, boundaries=False),
}


def _suv_auto_seam_profile_items(self=None, context=None):
    return (
        ('CUSTOM', '手動調整', '現在の自動シーム数値をそのまま使います。'),
        ('BALANCED', 'バランス', '角度、引張、境界、既存の流れを平均的に評価する汎用設定です。'),
        ('HARD_SURFACE', 'ハードサーフェス', '硬い折れ目、シャープ、マテリアル境界を強くシーム候補にします。'),
        ('ORGANIC', 'オーガニック', '折れ角のしきい値を緩め、大きな連続面を切りにくくする有機形状向け設定です。'),
        ('CYLINDER_TUBE', '筒状/パイプ', '筒状メッシュを側面1島にまとめやすいよう、縦方向のループ状切れ目を強く作ります。'),
        ('LOW_STRETCH', '低引張', '引張予測を強め、折れ角などの根拠がある辺を切りやすくして歪みを抑えます。'),
        ('LOOP_SAFE', 'ループ維持', '長い連続ループやモデルの流れに沿ったシームを維持しやすくします。'),
        ('UV_ATLAS', 'UV Atlas', 'チャート分割、引張、境界、パッキングを意識した汎用アトラス向け設定です。'),
        ('SINGLE_ISLAND', 'Singleアイランド', '内部シームを極力減らし、必要な最小切れ目だけを残す設定です。'),
    )


def _suv_auto_seam_profile_update(self, context):
    global _SUV_PRESET_APPLY_GUARD
    if _SUV_PRESET_APPLY_GUARD:
        return
    preset = str(getattr(self, 'suv_auto_seam_profile', 'CUSTOM') or 'CUSTOM').upper()
    data = dict(_SUS_AUTO_SEAM_PRESET_VALUES.get(preset) or {})
    if not data:
        try:
            _suv_workspace_settings_update(self, context)
        except Exception:
            pass
        return
    _SUV_PRESET_APPLY_GUARD = True
    try:
        mapping = {
            'suv_auto_seam_angle_threshold': data.get('angle_threshold'),
            'suv_auto_seam_min_score': data.get('min_score'),
            'suv_auto_seam_angle_weight': data.get('angle'),
            'suv_auto_seam_stretch_weight': data.get('stretch'),
            'suv_auto_seam_loop_weight': data.get('loop'),
            'suv_auto_seam_tube_weight': data.get('tube'),
            'suv_auto_seam_tube_angle_window': data.get('tube_window'),
            'suv_auto_seam_boundary_weight': data.get('boundary'),
            'suv_auto_seam_material_weight': data.get('material'),
            'suv_auto_seam_sharp_weight': data.get('sharp'),
            'suv_auto_seam_clear_existing': data.get('clear'),
            'suv_auto_seam_mark_boundaries': data.get('boundaries'),
        }
        for name, value in mapping.items():
            if value is None or not hasattr(self, name):
                continue
            try:
                setattr(self, name, value)
            except Exception:
                pass
    finally:
        _SUV_PRESET_APPLY_GUARD = False
    try:
        _suv_workspace_settings_update(self, context)
    except Exception:
        pass

class SUV_PG_WorkspaceSettings(bpy.types.PropertyGroup):
    bl_label = "Workspace Settings"
    bl_description = 'Workspace Settings. Stores UV Suite panel state, checker defaults, workflow toggles, and layout preferences so the same session can stay consistent across beginner and advanced tools. Use the panel UI to change these safely instead of editing the property group directly. / ワークスペース設定。UV Suite の表示状態、チェッカー既定値、ワークフロー切替、レイアウト設定を保持し、初心者向けツールと上級ツールの間でも同じ作業状態を保てるようにします。通常はこのプロパティグループを直接編集せず、パネルUIから安全に変更します。'
    # Persisted proxies for Blender-owned UV/Image Editor display settings.
    # Their labels match Blender's native controls; the ``native_*`` identifier
    # keeps the JSON schema unambiguous and avoids any background polling.
    native_uv_show_grid_over_image: bpy.props.BoolProperty(name='Grid Over Image', default=True, update=_suv_native_proxy_update_factory('native_uv_show_grid_over_image', 'show_grid_over_image'))
    native_uv_grid_shape_source: bpy.props.EnumProperty(name='Grid Source', items=(('DYNAMIC', 'Dynamic', ''), ('FIXED', 'Fixed', ''), ('PIXEL', 'Pixel', '')), default='DYNAMIC', update=_suv_native_proxy_update_factory('native_uv_grid_shape_source', 'grid_shape_source'))
    native_uv_tile_grid_shape: bpy.props.IntVectorProperty(name='Tile Grid', size=2, default=(1, 1), min=1, max=100, update=_suv_native_proxy_update_factory('native_uv_tile_grid_shape', 'tile_grid_shape'))
    native_uv_custom_grid_subdivisions: bpy.props.IntVectorProperty(name='Grid Subdivisions', size=2, default=(10, 10), min=1, max=5000, update=_suv_native_proxy_update_factory('native_uv_custom_grid_subdivisions', 'custom_grid_subdivisions'))
    native_uv_show_pixel_coords: bpy.props.BoolProperty(name='Pixel Coordinates', default=True, update=_suv_native_proxy_update_factory('native_uv_show_pixel_coords', 'show_pixel_coords'))
    native_uv_show_uv: bpy.props.BoolProperty(name='Display UVs', default=True, update=_suv_native_proxy_update_factory('native_uv_show_uv', 'show_uv'))
    native_uv_show_faces: bpy.props.BoolProperty(name='Display Faces', default=True, update=_suv_native_proxy_update_factory('native_uv_show_faces', 'show_faces'))
    native_uv_edge_display_type: bpy.props.EnumProperty(name='Edge Display', items=(('OUTLINE', 'Outline', ''), ('DASH', 'Dash', ''), ('BLACK', 'Black', ''), ('WHITE', 'White', '')), default='OUTLINE', update=_suv_native_proxy_update_factory('native_uv_edge_display_type', 'edge_display_type'))
    native_uv_show_modified_edges: bpy.props.BoolProperty(name='Modified Edges', default=False, update=_suv_native_proxy_update_factory('native_uv_show_modified_edges', 'show_modified_edges'))
    native_uv_show_stretch: bpy.props.BoolProperty(name='Stretch Display', default=False, update=_suv_native_proxy_update_factory('native_uv_show_stretch', 'show_stretch'))
    native_uv_display_stretch_type: bpy.props.EnumProperty(name='Stretch Type', items=(('ANGLE', 'Angle', ''), ('AREA', 'Area', '')), default='ANGLE', update=_suv_native_proxy_update_factory('native_uv_display_stretch_type', 'display_stretch_type'))
    native_uv_uv_opacity: bpy.props.FloatProperty(name='UV Opacity', default=1.0, min=0.0, max=1.0, update=_suv_native_proxy_update_factory('native_uv_uv_opacity', 'uv_opacity'))
    native_uv_uv_face_opacity: bpy.props.FloatProperty(name='Face Opacity', default=1.0, min=0.0, max=1.0, update=_suv_native_proxy_update_factory('native_uv_uv_face_opacity', 'uv_face_opacity'))
    native_uv_uv_edge_opacity: bpy.props.FloatProperty(name='Edge Opacity', default=1.0, min=0.0, max=1.0, update=_suv_native_proxy_update_factory('native_uv_uv_edge_opacity', 'uv_edge_opacity'))
    native_uv_stretch_opacity: bpy.props.FloatProperty(name='Stretch Opacity', default=1.0, min=0.0, max=1.0, update=_suv_native_proxy_update_factory('native_uv_stretch_opacity', 'stretch_opacity'))
    native_uv_pixel_round_mode: bpy.props.EnumProperty(name='Pixel Rounding', items=(('DISABLED', 'Disabled', ''), ('CORNER', 'Corner', ''), ('CENTER', 'Center', '')), default='DISABLED', update=_suv_native_proxy_update_factory('native_uv_pixel_round_mode', 'pixel_round_mode'))
    native_uv_lock_bounds: bpy.props.BoolProperty(name='Lock Bounds', default=False, update=_suv_native_proxy_update_factory('native_uv_lock_bounds', 'lock_bounds'))
    native_uv_use_live_unwrap: bpy.props.BoolProperty(name='Live Unwrap', default=False, update=_suv_native_proxy_update_factory('native_uv_use_live_unwrap', 'use_live_unwrap'))
    native_space_show_repeat: bpy.props.BoolProperty(name='Repeat Image', default=False, update=_suv_native_proxy_update_factory('native_space_show_repeat', 'show_repeat', 'space'))
    native_image_display_aspect: bpy.props.FloatVectorProperty(name='Aspect Ratio', size=2, default=(1.0, 1.0), min=0.1, update=_suv_native_proxy_update_factory('native_image_display_aspect', 'display_aspect', 'image'))
    ui_mode: bpy.props.EnumProperty(
        name="Workspace Layout",
        description="Internal compatibility setting for the fixed genre-grouped workflow layout. / ジャンル別に整理した固定ワークフローレイアウトの内部互換用設定です。",
        items=[
            ('SIMPLE', "Workflow", "Single genre-grouped workflow layout / ジャンル別に整理した単一ワークフローレイアウト"),
        ],
        default='SIMPLE',
        options={'HIDDEN', 'SKIP_SAVE'}
    )
    main_tab: bpy.props.EnumProperty(
        name="Workspace Tab",
        description='Choose which tool family is visible in the UV Suite panel / UV Suite パネルで表示するツール群を切り替えます',
        items=[
            ('ALL', "All", "Show every tool family / 全てのツール群を表示します"),
            ('WORKFLOW', "Workflow", "Show presets, unwrap and seam helpers / プリセット、展開、シーム補助を表示します"),
            ('TRANSFORM', "Transform", "Show alignment, straighten and flow tools / 整列、直線化、フローツールを表示します"),
            ('LAYOUT', 'Layout Panel', "Show packing, strip layout, stack and UDIM tools / パッキング、ストリップ配置、スタック、UDIMツールを表示します"),
            ('ANALYZE', "Analyze", "Show texel density and inspector tools / テクセル密度と検査ツールを表示します"),
            ('MAPS', "Maps", "Show checker and UV map tools / チェッカーとUVマップツールを表示します"),
            ('SYMMETRY', "Symmetry", "Show symmetry and transfer tools / 対称と転送ツールを表示します"),
            ('ATLAS', "Atlas", "Show atlas and bake tools / アトラスとベイクツールを表示します"),
        ],
        default='WORKFLOW',
    update=_suv_workspace_settings_update,)
    show_help_text: bpy.props.BoolProperty(
        name="Show Help",
        description="Show short help text inside each section / 各セクション内に短い説明を表示します",
        default=False,
    update=_suv_workspace_settings_update,)
    show_dashboard: bpy.props.BoolProperty(
        name="Show Visual Dashboard",
        description="Show the visual dashboard with large sample cards and quick-start presets / 大きなサンプルカードとクイック開始プリセットを含むビジュアルダッシュボードを表示します",
        default=False,
    update=_suv_workspace_settings_update,)
    show_reference_gallery: bpy.props.BoolProperty(
        name="Show Reference Gallery",
        description="Show larger sample preview images inside the dashboard and preview panels / ダッシュボードとプレビューパネルで大きめのサンプル画像を表示します",
        default=False,
    update=_suv_workspace_settings_update,)
    show_properties: bpy.props.BoolProperty(name="Properties", description="Show the Properties section / プロパティを表示します", default=True, update=_suv_workspace_settings_update)
    show_workflow: bpy.props.BoolProperty(name="Workflow", description="Show the Workflow section / ワークフローを表示します", default=True, update=_suv_workspace_settings_update)
    show_unwrap: bpy.props.BoolProperty(name="Cut & Unwrap", description="Show the Cut & Unwrap section / 切り分け＆展開を表示します", default=True, update=_suv_workspace_settings_update)
    show_transform: bpy.props.BoolProperty(name="Arrange & Transform", description="Show the Arrange & Transform section / 整列＆変形を表示します", default=True, update=_suv_workspace_settings_update)
    show_layout: bpy.props.BoolProperty(name="Packing & Layout", description="Show the Packing & Layout section / パッキング＆レイアウトを表示します", default=True, update=_suv_workspace_settings_update)
    show_selection: bpy.props.BoolProperty(name="Selection & Sets", description="Show the Selection & Sets section / 選択＆セットを表示します", default=True, update=_suv_workspace_settings_update)
    operation_instant_select_enabled: bpy.props.BoolProperty(
        name="即時選択",
        description="機能: UVエディターでUV頂点・辺・面などのエレメント上をクリックした場合だけ、そのエレメントを押下時に選択し、クリックしたままドラッグすると直接移動操作へ入ります。背景をドラッグした場合はBlender標準のボックス選択などをそのまま使用します。使い方: ONにすると本アドオンのキーマップ情報に従いUVエディター用の左クリックPress補助が有効になります。",
        default=False,
        get=_suv_operation_bool_get("operation_instant_select_enabled"),
        set=_suv_operation_bool_set("operation_instant_select_enabled"),
        update=_suv_operation_instant_select_enabled_update,
    )
    operation_axis_constraint_memory_enabled: bpy.props.BoolProperty(
        name="軸拘束の記憶",
        description="機能: UVエディターで直前に行った移動トランスフォームの軸拘束だけを記憶し、即時選択ドラッグ移動時にも同じU軸/V軸の拘束を再利用します。選択状態の追加変更は行わず、トランスフォーム開始時にBlender標準のconstraint_axisだけを渡します。",
        default=False,
        get=_suv_operation_bool_get("operation_axis_constraint_memory_enabled"),
        set=_suv_operation_bool_set("operation_axis_constraint_memory_enabled"),
        update=_suv_operation_axis_constraint_memory_update,
    )
    operation_uv_gizmo_grip_fix_enabled: bpy.props.BoolProperty(
        name="UVギズモつかみ補助",
        description="機能: UVエディターの標準トランスフォームギズモを掴みやすくし、重いUVデータで標準ヒット判定が不安定な場合だけ狭い補助グリップで移動・軸拘束移動・拡大縮小・回転を開始できるようにします。使い方: 有効にして、UVエディターのギズモ中心、U/Vハンドル、斜めスケールハンドル、細い回転リングを左ドラッグします。背景ドラッグや修飾キー付きドラッグはBlender標準操作へ通します。",
        default=False,
        get=_suv_operation_bool_get("operation_uv_gizmo_grip_fix_enabled"),
        set=_suv_operation_bool_set("operation_uv_gizmo_grip_fix_enabled"),
        update=_suv_operation_uv_gizmo_grip_fix_update,
    )
    operation_uv_crossing_select_edges_enabled: bpy.props.BoolProperty(
        name="UV Crossing Selection: Edges",
        description="SmartUV owns UV Editor edge crossing selection behavior migrated from SmartTransform. SmartTransform keeps its 3D View crossing selection.",
        default=False,
        get=_suv_operation_bool_get("operation_uv_crossing_select_edges_enabled"),
        set=_suv_operation_bool_set("operation_uv_crossing_select_edges_enabled"),
        update=_suv_operation_uv_ownership_update,
    )
    operation_uv_crossing_select_faces_enabled: bpy.props.BoolProperty(
        name="UV Crossing Selection: Faces",
        description="SmartUV owns UV Editor face crossing selection behavior migrated from SmartTransform. SmartTransform keeps its 3D View crossing selection.",
        default=False,
        get=_suv_operation_bool_get("operation_uv_crossing_select_faces_enabled"),
        set=_suv_operation_bool_set("operation_uv_crossing_select_faces_enabled"),
        update=_suv_operation_uv_ownership_update,
    )
    operation_uv_smart_grs_keymaps_enabled: bpy.props.BoolProperty(
        name="UV Smart G-R-S Keymaps",
        description="Register SmartUV-owned UV Editor G/R/S keymaps for move, rotate, and scale. SmartTransform keeps only 3D View G/R/S ownership.",
        default=False,
        get=_suv_operation_bool_get("operation_uv_smart_grs_keymaps_enabled"),
        set=_suv_operation_bool_set("operation_uv_smart_grs_keymaps_enabled"),
        update=_suv_operation_uv_ownership_update,
    )
    operation_uv_proportional_cursor_keymap_enabled: bpy.props.BoolProperty(
        name="UV Proportional Cursor Entry",
        description="Expose the SmartUV-owned UV Editor proportional editing size cursor entry point migrated from SmartTransform's UV surface.",
        default=False,
        get=_suv_operation_bool_get("operation_uv_proportional_cursor_keymap_enabled"),
        set=_suv_operation_bool_set("operation_uv_proportional_cursor_keymap_enabled"),
        update=_suv_operation_uv_ownership_update,
    )
    operation_axis_constraint_memory_axis: bpy.props.EnumProperty(
        name="軸拘束内部状態",
        description="軸拘束の記憶で内部的に保持している軸です。UIには表示せず、直前のBlender標準Transformから自動更新します。",
        items=(
            ('FREE', 'フリー軸', 'U/Vどちらにも固定しない内部状態です。'),
            ('U', 'U軸', 'U方向だけに拘束する内部状態です。'),
            ('V', 'V軸', 'V方向だけに拘束する内部状態です。'),
        ),
        default='FREE',
        options={'HIDDEN'},
        update=_suv_workspace_settings_update,
    )
    canvas_grid_dynamic_subdivisions: bpy.props.IntProperty(
        name="グリッド分割",
        description="機能: グリッド基準がダイナミックの時、濃いグリッド1セル内に表示される薄い補助グリッドの分割数を1値で指定します。使い方: 2なら1セルを2分割、10なら1セルを10分割としてUVエディターのガイドグリッドへ反映します。",
        default=10,
        min=1,
        max=5000,
        update=_suv_canvas_grid_dynamic_subdivisions_update,
    )
    operation_instant_select_action: bpy.props.EnumProperty(
        name="即時選択アクション",
        description="旧設定互換用です。現在の即時選択は、UVエレメント上のクリックドラッグだけを選択から移動へ直結し、背景ドラッグは標準操作へ通します。",
        items=(
            ('NONE', 'なし', '設定だけを保持し、選択操作は実行しません。'),
            ('GROW', 'グロー選択', '現在のUV選択を隣接要素へ広げます。'),
            ('SHRINK', 'シュリンク選択', '現在のUV選択の外周を外して縮小します。'),
            ('LOOP', 'ループ選択', '選択辺からUV/メッシュエッジループを選択します。'),
            ('RING', 'リング選択', '選択辺から四角面を横断するリングを選択します。'),
            ('LINKED', '連結選択', '現在の選択につながるUV要素を選択します。'),
            ('BORDER', '境界選択', '選択領域またはUV島の境界を選択します。'),
            ('INVERT', '反転選択', '現在のUV選択を反転します。'),
            ('ALL', '全選択', 'アクティブUVの全要素を選択します。'),
            ('CLEAR', '選択解除', 'UV選択を解除します。'),
            ('ACTIVE_ISLAND', 'アクティブ島', '現在の選択からアクティブ島を選択します。'),
            ('SIMILAR_ISLANDS', '類似アイランド', '条件が近いUVアイランドを選択します。'),
            ('IDENTICAL_ISLANDS', '同一アイランド', '同一形状に近いUVアイランドを選択します。'),
            ('OVERLAP', '重なり', '重なっているUVを選択します。'),
            ('FLIPPED', '反転UV', '反転しているUVを選択します。'),
            ('ZERO_AREA', 'ゼロ面積', '面積がない、または極小のUVを選択します。'),
        ),
        default='NONE',
        update=_suv_operation_instant_select_update,
    )
    operation_select_mode: bpy.props.EnumProperty(
        name="選択モード",
        description="機能: UVエディターの選択モードを切り替えます。使い方: 頂点/辺/面/島のうち、これから行うUV選択操作に合うモードを選び、「選択モード適用」を実行します。",
        items=(
            ('VERTEX', '頂点', 'UV頂点選択モードにします。'),
            ('EDGE', '辺', 'UV辺選択モードにします。'),
            ('FACE', '面', 'UV面選択モードにします。'),
            ('ISLAND', '島', 'UVアイランド選択モードにします。'),
            ('SYNC_TOGGLE', 'UV同期切替', 'UV Sync Selectionを切り替えます。'),
        ),
        default='FACE',
        update=_suv_workspace_settings_update,
    )

    uv_direction_align_target: bpy.props.EnumProperty(
        name="方向整列対象",
        description="機能: UV整列の方向整列ボタンで処理する対象を切り替えます。使い方: 頂点を選ぶとUVエディターで選択中の頂点・辺・面エレメントだけを整列し、アイランドを選ぶとUVエディターで選択中のUVアイランドを形状維持で整列します。",
        items=(
            ('VERTEX', '頂点', 'UVエディターで選択中のUV頂点・辺・面エレメントだけを方向整列します。'),
            ('ISLAND', 'アイランド', 'UVエディターで選択中のUVアイランドを、形状を保ったまま方向整列します。'),
        ),
        default='VERTEX',
        update=_suv_workspace_settings_update,
    )
    show_density: bpy.props.BoolProperty(name="Density & Inspect", description="Show the Density & Inspect section / 密度＆検査を表示します", default=True, update=_suv_workspace_settings_update)
    show_preview: bpy.props.BoolProperty(name="Preview & UV Maps", description="Show the Preview & UV Maps section / プレビュー＆UVマップを表示します", default=True, update=_suv_workspace_settings_update)
    show_symmetry: bpy.props.BoolProperty(name="Symmetry & Transfer", description="Show the Symmetry & Transfer section / 対称＆転送を表示します", default=True, update=_suv_workspace_settings_update)
    show_atlas: bpy.props.BoolProperty(name="Atlas & Bake", description="Show the Atlas & Bake section / アトラス＆ベイクを表示します", default=True, update=_suv_workspace_settings_update)
    show_bridge: bpy.props.BoolProperty(name="Standard Integration", description="Show standard integration tools / 標準連携ツールを表示します", default=True, update=_suv_workspace_settings_update)
    checker_size: bpy.props.IntProperty(name="画像解像度", description="旧設定との互換用です。新規UIでは横/縦の画像解像度を使用します。", default=2048, min=64, max=8192, update=_suv_workspace_settings_update)
    checker_size_width: bpy.props.IntProperty(name="画像解像度 横", description="生成するチェッカーマップ画像の横解像度です。既にチェッカーがある状態で「チェッカー作成」を実行した場合も、この値で更新します。", default=2048, min=16, max=16384, update=_suv_workspace_settings_update)
    checker_size_height: bpy.props.IntProperty(name="画像解像度 縦", description="生成するチェッカーマップ画像の縦解像度です。既にチェッカーがある状態で「チェッカー作成」を実行した場合も、この値で更新します。", default=2048, min=16, max=16384, update=_suv_workspace_settings_update)
    checker_tile_count: bpy.props.IntProperty(name="チェックサイズ（タイリング数）", description="旧設定との互換用です。新規UIでは横/縦のチェックサイズを使用します。", default=8, min=1, max=512, update=_suv_workspace_settings_update)
    checker_tile_count_u: bpy.props.IntProperty(name="チェックサイズ 横", description="横方向のチェッカー分割数です。", default=8, min=1, max=2048, update=_suv_workspace_settings_update)
    checker_tile_count_v: bpy.props.IntProperty(name="チェックサイズ 縦", description="縦方向のチェッカー分割数です。", default=8, min=1, max=2048, update=_suv_workspace_settings_update)
    checker_color_a: bpy.props.FloatVectorProperty(name="チェックカラー1", description="チェッカーの1色目を指定します。", subtype='COLOR', size=4, default=(0.05, 0.05, 0.05, 1.0), min=0.0, max=1.0, update=_suv_workspace_settings_update)
    checker_color_b: bpy.props.FloatVectorProperty(name="チェックカラー2", description="チェッカーの2色目を指定します。", subtype='COLOR', size=4, default=(0.85, 0.85, 0.85, 1.0), min=0.0, max=1.0, update=_suv_workspace_settings_update)
    checker_image_name: bpy.props.StringProperty(name="画像名", description="Name of the checker image datablock / チェッカー画像データブロック名", default="SUV_Checker", update=_suv_workspace_settings_update)
    checker_material_name: bpy.props.StringProperty(name="マテリアル名", description="Name of the checker material / チェッカーマテリアル名", default="SUV_Checker", update=_suv_workspace_settings_update)
    uv_new_name: bpy.props.StringProperty(name="New UV Name", description="Name used when adding a UV map / UVマップ追加時の名前", default="UVMap_SUV", update=_suv_workspace_settings_update)
    fit_padding_px: bpy.props.IntProperty(name="Fit Padding", description="Padding used by Fit to Bounds / 領域フィット時の余白", default=8, min=0, max=256, update=_suv_workspace_settings_update)

    unified_auto_pack_mode: bpy.props.EnumProperty(
        name="パッキングプリセット",
        description="自動パックで使う設定のプリセットです。選択すると下の設定項目が切り替わります。実行時はプリセット名ではなく、現在表示されている回転・スケール・余白・重なり島などの設定値を使います。",
        items=(
            ('PACK_STANDARD', 'パック', '選択UV面だけを現在のタイルへ整理する基本パックです。同じ結果になる旧アトラス/標準形状/選択面スコープ系はこの項目へ集約しています。'),
            ('SMART_DENSE', '高密度パック', 'Smart UV Pack Pro系の決定論的パックです。通常より高密度な配置を狙う場合に使います。'),
            ('FAST_NO_ROTATE', '方向維持パック', 'アイランドの向きを維持し、回転させずに選択UV面だけをパックします。'),
                    ('DENSITY_PRIORITY', '密度優先パック', 'テクセル密度を揃えてから選択範囲をパックします。'),
            ('MESH_AREA_SCALE_PACK', '3D面積基準パック', '元の3Dメッシュ面積を基準に、各アイランドの形状を崩さず再スケールしてから選択範囲をパックします。'),
            ('GROUP_SIMILAR', '類似島グループパック', '面積・比率が近い島をグループ化してパックします。'),
            ('GROUP_MATERIAL', 'マテリアル別パック', 'マテリアル境界をグループとして扱い、グループごとに整理してパックします。'),
            ('GROUP_IDENTICAL', '同一島スタック+パック', 'ほぼ同一形状の島をスタックしながらパックします。'),
            ('UDIM_STANDARD', 'UDIMタイルパック', '配置タイル設定（ゼロ/カーソル/明示指定）に従い、選択UV面だけをUDIMタイルへパックします。'),
                    ('UDIM_KEEP_TILES', 'UDIM維持パック', '現在所属しているUDIMタイルを維持して各タイル内でパックします。'),
            ('UDIM_AUTO_TILES', 'UDIM自動拡張パック', '必要に応じてUDIMタイルを増やしながら選択島をパックします。'),
            ('CHART_DISTRIBUTION', '高密度チャート分布パック', 'チャート分布、幅高さ、パディングを考慮し、選択島を密度正規化してから正確形状でパックします。'),
            ('BAKE_SAFE_CHART', 'ベイク安全チャートパック', 'ベイクパディングの2倍以上を意識した安全余白で、重なりやにじみを避けるパックです。'),
            ('EXISTING_CHART_REPACK', '既存チャート再パック', '既存チャート境界を保ち、ゼロ面積や崩れた島を避けながら再パックします。'),
            ('LOW_DISTORTION_PACK', '低歪み補正パック', '最小ストレッチと密度補正を行い、伸びを抑えてからパックします。'),
            ('LIGHTMAP', 'ライトマップパック', 'Blender標準Lightmap PackをSmart UVの選択面スコープで実行します。'),
            ('HOTSPOT_GRID', 'ホットスポットセル配置', 'グリッドセルへ選択島を自動配置します。トリム/ホットスポット用途です。'),
            ('TRIM_STRIP', 'トリム帯配置', '帯状・トリムシート向けに選択島を整理配置します。'),
        ),
        default='PACK_STANDARD',
        update=_suv_auto_pack_preset_update,
    )
    unified_pack_margin_px: bpy.props.IntProperty(
        name="パック余白(px)",
        description="Smart UV Pack Pro系、密度優先、ホットスポット、トリム系で使用するピクセル余白です。値を上げるとアイランド間の安全距離が広がり、値を下げるとUV領域をより詰めて使います。",
        default=8, min=0, max=1024,
        update=_suv_workspace_settings_update,
    )
    unified_pack_margin: bpy.props.FloatProperty(
        name="標準パック余白",
        description="Blender標準Pack Islands系で使うUV単位の余白です。Margin Methodと組み合わせて島間の距離を決めます。",
        default=0.001, min=0.0, max=1.0, precision=4,
        update=_suv_workspace_settings_update,
    )
    unified_pack_margin_method: bpy.props.EnumProperty(
        name="余白方式",
        description="Blender標準Pack Islandsの余白計算方式です。Scaledは既存スケール基準、Addは絶対追加、Fractionは最終UV領域比率で余白を扱います。",
        items=(
            ('SCALED', 'Scaled', '既存UVスケールに応じて余白を調整します。'),
            ('ADD', 'Add', '絶対値として余白を追加します。'),
            ('FRACTION', 'Fraction', '最終UV領域に対する比率として余白を指定します。'),
        ),
        default='SCALED',
        update=_suv_workspace_settings_update,
    )
    unified_pack_shape_method: bpy.props.EnumProperty(
        name="形状方式",
        description="標準Pack Islandsでアイランド形状をどう評価するかです。Concaveは最も正確、Convexは中間、AABBは高速な外接矩形方式です。",
        items=(
            ('CONCAVE', 'Concave', '凹形状を含めて正確に評価します。'),
            ('CONVEX', 'Convex', '凸包として評価し、精度と速度を両立します。'),
            ('AABB', 'AABB', '外接矩形で高速に評価します。'),
        ),
        default='CONCAVE',
        update=_suv_workspace_settings_update,
    )
    unified_pack_rotate: bpy.props.BoolProperty(
        name="回転を許可",
        description="パッキング時にUVアイランドを回転して空き領域へ詰めるかを設定します。OFFにするとテクスチャ方向を維持しやすくなります。",
        default=True,
        update=_suv_workspace_settings_update,
    )
    unified_pack_scale: bpy.props.BoolProperty(
        name="スケールを許可",
        description="Blender標準Pack Islandsでパック範囲に収まるようスケール調整を許可します。OFFでは現在の島サイズをできるだけ維持します。",
        default=True,
        update=_suv_workspace_settings_update,
    )
    unified_pack_lock_pinned: bpy.props.BoolProperty(
        name="ピン固定",
        description="ピン留めされたUVを含む島を動かさず、未ピンの選択島だけをパックします。意図的に固定したUVを保持したい場合に有効です。",
        default=True,
        update=_suv_workspace_settings_update,
    )
    unified_pack_merge_overlap: bpy.props.BoolProperty(
        name="重なり島を複合島にする",
        description="機能: UVエディター上で面積を持って一部でも重なっている選択アイランドを、自動パック時だけ1つの複合アイランドとして扱い、内部の相対位置を保ったまま配置します。使い方: 重ねたUVを崩さずまとめて配置したい場合はON、重なっていても各アイランドを個別に並べ直したい場合はOFFにします。",
        default=False,
        update=_suv_workspace_settings_update,
    )
    unified_pack_use_seed: bpy.props.BoolProperty(
        name="Seed探索",
        description="パック前に選択アイランドをSeedに基づいて一時的にシャッフルし、別の詰め方を探します。UV Toolkitのランダムパック相当の統合機能です。",
        default=False,
        update=_suv_workspace_settings_update,
    )
    unified_pack_seed: bpy.props.IntProperty(
        name="Seed",
        description="Seed探索で使用する乱数値です。同じ値なら同じ初期シャッフルになり、パッキング結果の再現性を保ちやすくなります。",
        default=0, min=0, max=999999,
        update=_suv_workspace_settings_update,
    )
    unified_pack_rotation_step: bpy.props.EnumProperty(
        name="回転刻み",
        description="Smart UV Pack Pro系の回転探索刻みです。15度は高密度、90度は方向維持、0度は回転なしに向きます。",
        items=(
            ('0', '0°', '回転しません。'),
            ('90', '90°', '90度単位で回転します。'),
            ('45', '45°', '45度単位で回転します。'),
            ('15', '15°', '15度単位で細かく回転します。'),
        ),
        default='90',
        update=_suv_workspace_settings_update,
    )
    unified_pack_stack_identical: bpy.props.BoolProperty(
        name="同一島を重ねる",
        description="同一島グループパックで、同じ形状の島を重ねて再利用配置にします。左右対称部品や反復部品のUV節約に使います。",
        default=False,
        update=_suv_workspace_settings_update,
    )
    unified_pack_target_tile: bpy.props.EnumProperty(
        name="配置タイル",
        description="パック後の選択UVをどのUDIM/UVタイルへ置くかを設定します。カーソルを選ぶとUVエディターの2Dカーソルがあるタイルへ移動します。",
        items=(
            ('ZERO', '0-1タイル', '選択範囲を標準の0-1タイルへ配置します。'),
            ('CURSOR', '2Dカーソルタイル', 'UVエディターの2DカーソルがあるUDIMタイルへ配置します。'),
            ('EXPLICIT', '指定タイル', '下のU/V番号で指定したタイルへ配置します。'),
            ('KEEP', '現在位置を維持', 'パック後にタイル移動を行いません。'),
        ),
        default='ZERO',
        update=_suv_workspace_settings_update,
    )
    unified_pack_tile_u: bpy.props.IntProperty(
        name="タイルU",
        description="配置タイルが「指定タイル」の時に使うU方向のタイル番号です。0が1001相当の基本タイルです。",
        default=0, min=-100, max=100,
        update=_suv_workspace_settings_update,
    )
    unified_pack_tile_v: bpy.props.IntProperty(
        name="タイルV",
        description="配置タイルが「指定タイル」の時に使うV方向のタイル番号です。0が1001相当の基本タイルです。",
        default=0, min=-100, max=100,
        update=_suv_workspace_settings_update,
    )
    unified_pack_tile_columns: bpy.props.IntProperty(
        name="UDIM列数",
        description="UDIM自動拡張やグループ別タイル配置で、何列ごとに次の行へ送るかを設定します。",
        default=10, min=1, max=100,
        update=_suv_workspace_settings_update,
    )
    unified_pack_tile_fill: bpy.props.EnumProperty(
        name="UDIM埋め順",
        description="複数UDIMタイルへ配置するときの埋め順です。行優先は横方向、列優先は縦方向へ先に進みます。",
        items=(
            ('ROW', '行優先', '横方向へ先に進みます。'),
            ('COLUMN', '列優先', '縦方向へ先に進みます。'),
        ),
        default='ROW',
        update=_suv_workspace_settings_update,
    )

    unified_pack_target_width: bpy.props.IntProperty(
        name="パック幅",
        description="チャート分布パックの想定UV/テクスチャ幅です。高さと異なる値にすると、アスペクト比に合わせて選択島の配置を補正します。",
        default=2048, min=64, max=32768,
        update=_suv_workspace_settings_update,
    )
    unified_pack_target_height: bpy.props.IntProperty(
        name="パック高さ",
        description="チャート分布パックの想定UV/テクスチャ高さです。幅と組み合わせて非正方形アトラスの比率を反映します。",
        default=2048, min=64, max=32768,
        update=_suv_workspace_settings_update,
    )
    unified_pack_bake_padding_px: bpy.props.IntProperty(
        name="ベイク安全余白(px)",
        description="ベイクパディング基準の安全余白です。ベイク安全チャートパックでは少なくともこの2倍相当を島間余白として確保します。",
        default=4, min=0, max=512,
        update=_suv_workspace_settings_update,
    )
    unified_pack_chart_rescale: bpy.props.BoolProperty(
        name="チャート密度再正規化",
        description="パック前に元メッシュ面積を基準に選択島のテクセル密度を揃えます。実寸密度補正としてSmart UV内で近似します。",
        default=False,
        update=_suv_workspace_settings_update,
    )

    canvas_size: bpy.props.IntProperty(
        name="Canvas Size",
        description="Shared texture/canvas size used by layout, guide grid, texel density and quick workflow tools / レイアウト、ガイドグリッド、密度、クイックワークフローで使う共通キャンバスサイズ",
        default=2048,
        min=128,
        max=16384,

    update=_suv_workspace_settings_update,)
    workflow_density: bpy.props.FloatProperty(
        name="Workflow Density",
        description="Density used by one-click projection tools when density normalization is enabled / 1クリック投影ツールで密度適用を有効にしたときに使う密度",
        default=1024.0,
        min=1.0,

    update=_suv_workspace_settings_update,)
    workflow_pack_after: bpy.props.BoolProperty(
        name="Pack After",
        description="Run Pack Pro automatically after projection/unwrapping tools / 投影・展開の後にPack Proを自動実行します",
        default=True,

    update=_suv_workspace_settings_update,)
    workflow_relax_after: bpy.props.BoolProperty(
        name="Relax After",
        description="Run a native relax pass after projection/unwrapping tools / 投影・展開後に標準リラックスを実行します",
        default=True,

    update=_suv_workspace_settings_update,)


    suv_seam_mark_compliance: bpy.props.BoolProperty(
        name="シームをマーク準拠",
        description="UV展開前に、既存の「シームをマーク」を分割境界として読み取り、選択UV面をシーム区切りの3Dメッシュグループごとに展開します。展開によって既存シームは解除されず、シームをクリアするまで保持します。",
        default=True,
        update=_suv_workspace_settings_update,
    )
    suv_crease_seam_value: bpy.props.FloatProperty(
        name="クリース値",
        description="指定したEdge Crease値と一致する辺をシームとしてマークします。0.0〜1.0の値を指定し、許容差で小さな丸め誤差を吸収します。",
        default=1.0, min=0.0, max=1.0, precision=3,
        update=_suv_workspace_settings_update,
    )
    suv_crease_seam_tolerance: bpy.props.FloatProperty(
        name="許容差",
        description="クリース値比較時の許容差です。例: クリース値1.0、許容差0.001なら0.999〜1.0付近の辺を対象にします。",
        default=0.001, min=0.0, max=0.25, precision=4,
        update=_suv_workspace_settings_update,
    )
    suv_crease_seam_apply_mode: bpy.props.EnumProperty(
        name="適用方式",
        description="加算は既存シームを保持して対象辺を追加マークします。クリア後に作成は、現在のシームを一度すべて解除してから、指定クリース値の辺だけをシーム化します。",
        items=(
            ('ADD', '加算', '既存のシームを保持したまま、指定クリース値の辺をシームとして追加します。'),
            ('REPLACE', 'クリア後に作成', '全シームを一度解除してから、指定クリース値の辺だけをシームとしてマークし直します。'),
        ),
        default='ADD',
        update=_suv_workspace_settings_update,
    )

    suv_auto_seam_profile: bpy.props.EnumProperty(
        name="自動シームプリセット",
        description="自動シームの詳細数値を用途別にまとめて切り替えます。筒状/パイプは、筒状メッシュを側面1アイランドにしやすい縦方向ループ状シームを強めます。",
        items=_suv_auto_seam_profile_items,
        default='BALANCED',
        update=_suv_auto_seam_profile_update,
    )
    suv_auto_seam_angle_threshold: bpy.props.FloatProperty(
        name="角度しきい値",
        description="隣接面の角度差をシーム候補にする基準です。低い値ほど細かく切り、高い値ほど大きなアイランドを維持します。",
        default=60.0, min=1.0, max=179.0, precision=1,
        update=_suv_workspace_settings_update,
    )
    suv_auto_seam_min_score: bpy.props.FloatProperty(
        name="シーム採用スコア",
        description="自動シーム候補を採用する最小スコアです。低い値ほど多くのシームを作り、高い値ほど重要な切れ目だけを残します。",
        default=58.0, min=0.0, max=100.0, subtype='PERCENTAGE', precision=0, step=1,
        update=_suv_workspace_settings_update,
    )
    suv_auto_seam_angle_weight: bpy.props.FloatProperty(
        name="辺角度",
        description="面の折れ角度をどれだけシーム候補として重視するかです。ハードサーフェスでは高め、有機形状では低めが向いています。",
        default=68.0, min=0.0, max=100.0, subtype='PERCENTAGE', precision=0, step=1,
        update=_suv_workspace_settings_update,
    )
    suv_auto_seam_stretch_weight: bpy.props.FloatProperty(
        name="引張予測",
        description="辺長、隣接面面積、細長さから展開時に伸びやすい箇所を予測し、折れ角などの根拠がある辺を後押しする強度です。これだけではシームになりません。",
        default=44.0, min=0.0, max=100.0, subtype='PERCENTAGE', precision=0, step=1,
        update=_suv_workspace_settings_update,
    )
    suv_auto_seam_loop_weight: bpy.props.FloatProperty(
        name="ループ維持",
        description="長く連続したエッジループやモデルの流れに沿った切れ目を維持する強度です。折れ角などの根拠がある辺を後押しし、高くすると途切れにくいシームになります。これだけではシームになりません。",
        default=42.0, min=0.0, max=100.0, subtype='PERCENTAGE', precision=0, step=1,
        update=_suv_workspace_settings_update,
    )
    suv_auto_seam_tube_weight: bpy.props.FloatProperty(
        name="筒状ループ",
        description="筒状/パイプ形状で、側面を1アイランドに開くための縦方向ループ状シームを作る強度です。高くすると円筒側面の切れ目を1本の連続ループとして優先します。",
        default=35.0, min=0.0, max=100.0, subtype='PERCENTAGE', precision=0, step=1,
        update=_suv_workspace_settings_update,
    )
    suv_auto_seam_tube_angle_window: bpy.props.FloatProperty(
        name="筒状角度幅",
        description="筒状ループシームを1本に絞るための円周方向の許容幅です。小さい値ほど細い切れ目、大きい値ほど周辺の連続辺も含めます。",
        default=22.0, min=2.0, max=90.0, precision=1,
        update=_suv_workspace_settings_update,
    )
    suv_auto_seam_tube_axis: bpy.props.EnumProperty(
        name="筒状軸",
        description="筒状メッシュの長手方向を指定します。自動では選択範囲またはメッシュ全体のバウンディングボックスで最も長い軸を使います。",
        items=(('AUTO', '自動', '最も長い軸を筒状の長手方向として扱います。'), ('X', 'X', 'X軸を筒状の長手方向として扱います。'), ('Y', 'Y', 'Y軸を筒状の長手方向として扱います。'), ('Z', 'Z', 'Z軸を筒状の長手方向として扱います。')),
        default='AUTO',
        update=_suv_workspace_settings_update,
    )
    suv_auto_seam_tube_cut_count: bpy.props.IntProperty(
        name="筒状カット本数",
        description="筒状メッシュ側面に作る長手方向の切れ目本数です。通常は1本にすると側面が1枚のアイランドとして開きやすくなります。",
        default=1, min=1, max=8,
        update=_suv_workspace_settings_update,
    )
    suv_auto_seam_boundary_weight: bpy.props.FloatProperty(
        name="境界/非多様体",
        description="開いた境界や非多様体辺をシーム候補にする強度です。開口部、穴、壊れた境界を展開起点にしたい場合は高くします。",
        default=90.0, min=0.0, max=100.0, subtype='PERCENTAGE', precision=0, step=1,
        update=_suv_workspace_settings_update,
    )
    suv_auto_seam_material_weight: bpy.props.FloatProperty(
        name="マテリアル境界",
        description="隣接面のマテリアルが異なる辺をシーム候補にする強度です。素材境界をUV境界にしたい場合は高くします。",
        default=78.0, min=0.0, max=100.0, subtype='PERCENTAGE', precision=0, step=1,
        update=_suv_workspace_settings_update,
    )
    suv_auto_seam_sharp_weight: bpy.props.FloatProperty(
        name="シャープ辺",
        description="シャープ設定された辺をシーム候補にする強度です。法線ハードエッジとUV境界を揃えたい場合は高くします。",
        default=72.0, min=0.0, max=100.0, subtype='PERCENTAGE', precision=0, step=1,
        update=_suv_workspace_settings_update,
    )
    suv_auto_seam_clear_existing: bpy.props.BoolProperty(
        name="既存シームを先にクリア",
        description="自動シーム実行前に対象範囲の既存シームを解除します。新しい自動シーム計画へ作り直したい場合に有効にします。",
        default=False,
        update=_suv_workspace_settings_update,
    )
    suv_auto_seam_mark_boundaries: bpy.props.BoolProperty(
        name="開口境界をシーム",
        description="開いた境界、穴、非多様体辺を自動シーム候補として扱います。筒状の開口部や切断面を明示的にUV境界にしたい場合に有効です。",
        default=True,
        update=_suv_workspace_settings_update,
    )

    unwrap_map_channel: bpy.props.EnumProperty(
        name="展開使用マップチャンネル",
        description="UV展開で使用するマップチャンネルを選択します。選択したチャンネルは展開前にアクティブ化され、スマート展開、四角展開、円展開、投影系展開、選択UVスコープ、品質最適化、パッキングの対象になります。未選択のUVエレメントや他のUVマップチャンネルは、展開対象に選ばない限り書き換えません。",
        items=_suv_unwrap_map_channel_items,
        default='ACTIVE',
        update=_suv_unwrap_map_channel_update,
    )
    unwrap_map_channel_name: bpy.props.StringProperty(
        name="展開使用マップチャンネル名",
        description="最後に展開対象として解決されたUVマップ名です。UI表示と保存互換用の内部値です。",
        default='',
        options={'HIDDEN'},
    )
    map_channel_object_name: bpy.props.StringProperty(
        name="マップチャンネル編集オブジェクト",
        description="基本設定のマップチャンネルリストで選択しているメッシュオブジェクト名です。このオブジェクトの展開使用マップチャンネル、名称変更、追加、削除、並び替えを編集します。",
        default='',
        options={'HIDDEN'},
    )

    map_channel_new_name: bpy.props.StringProperty(
        name="新規マップ名",
        description="基本設定のマップチャンネル追加で作成するUVマップ名です。空欄の場合はUVMapを基準名として使い、同名がある場合は自動的に連番を付けます。",
        default="UVMap_SUV",
        update=_suv_workspace_settings_update,
    )
    map_channel_copy_source: bpy.props.EnumProperty(
        name="コピー元",
        description="UV展開情報をコピーする元のマップチャンネルです。現在アクティブなUVマップ、または選択オブジェクトの具体的なUVマップチャンネルを指定できます。",
        items=_suv_map_channel_copy_source_items,
        default='ACTIVE',
        update=_suv_workspace_settings_update,
    )
    map_channel_copy_destination: bpy.props.EnumProperty(
        name="展開使用マップチャンネル",
        description="互換性維持用の内部プロパティです。基本設定では個別のコピー先を表示せず、UV展開情報のコピー書き込み先は常に「展開使用マップチャンネル」で選択中のチャンネルになります。",
        items=_suv_map_channel_copy_destination_items,
        default='TARGET_UNWRAP',
        options={'HIDDEN'},
        update=_suv_workspace_settings_update,
    )

    seam_mark_compliant_unwrap: bpy.props.BoolProperty(
        name="シームマーク準拠展開",
        description="UV展開前に、既存のBlender標準「シームをマーク」を読み取り、選択UV面を3Dメッシュ上のシーム区切りグループへ分割してから各グループを展開します。展開処理では既存シームを解除せず、「シームをクリア」を実行するまで永続的に保持します。",
        default=True,
        update=_suv_workspace_settings_update,
    )
    seam_mark_compliance_clear_internal: bpy.props.BoolProperty(
        name="内部シームを同期クリア",
        description="シームマーク準拠展開時に、選択UV面スコープ内でUVが連続している辺の既存シームを解除します。有効にするとUVアイランド境界だけがシームとして残り、無効にすると既存の手動シームを追加で保持します。",
        default=True,
        update=_suv_workspace_settings_update,
    )
    seam_snapshot_name: bpy.props.StringProperty(
        name="シーム保存名",
        description="シーン内に一時保存するシーム設定の名前です。複数のシーム構成を名前別に保存し、必要に応じて読み込めます。外部保存時の初期ファイル名にも使います。",
        default="Default",
        update=_suv_workspace_settings_update,
    )
    seam_snapshot_filepath: bpy.props.StringProperty(
        name="外部シームJSON",
        description="シーム設定を外部JSONへ保存・読み込みするファイルパスです。空欄の場合は Blender config 内の Smart_UV_Suite を既定保存先として使います。",
        default="",
        subtype='FILE_PATH',
        update=_suv_workspace_settings_update,
    )

    auto_seam_preset: bpy.props.EnumProperty(
        name="自動シームプリセット",
        description="自動シームの判定設定をまとめて切り替えます。角度、境界、シャープ、材質、引張予測、ループ維持、筒状メッシュの長手方向カット、シームマーク準拠展開を一括管理します。手動調整を選ぶと現在の数値を保持します。",
        items=(
            ('MANUAL', '手動調整', '現在の自動シーム数値を保持して直接調整します。'),
            ('BALANCED', 'バランス', '一般的なモデル向けに角度、境界、引張、筒状カットを均衡させます。'),
            ('HARD_SURFACE', 'ハードサーフェス', '硬い折れ目、シャープ、材質境界を強めにシーム化します。'),
            ('ORGANIC', 'オーガニック', '有機的な面を大きく保ち、伸びやすい箇所と必要な境界を優先します。'),
            ('CYLINDER', '筒状メッシュ', 'パイプや円柱で、キャップ境界と長手方向の1本の切れ目を作る傾向を強めます。'),
            ('CYLINDER_SINGLE', '筒状Singleアイランド', '筒状側面を1枚のアイランドへ開きやすいよう、長手方向ループシームを特に強くします。'),
            ('LOW_STRETCH', '低引張', '展開後に伸びやすい境界を残し、ストレッチ低減を優先します。'),
            ('LOOP_SAFE', 'ループ維持', '連続したループ状のシーム候補を壊しにくくします。'),
            ('MARK_SEAM_COMPLIANT', 'シーム準拠', '展開後のUV境界を実メッシュシームへ同期する運用を優先します。'),
        ),
        default='BALANCED',
        update=_suv_auto_seam_preset_update,
    )
    auto_seam_scope: bpy.props.EnumProperty(
        name="自動シーム範囲",
        description="自動シームを3Dビューで選択中の面だけに適用するか、アクティブメッシュ全体に適用するかを選びます。UV編集ワークスペース内から実行しても、判定対象は3Dビュー側のメッシュ選択です。",
        items=(('SELECTED', '選択面', '3Dビューで選択中の面だけを対象にします。'), ('ALL', '全体', 'アクティブメッシュ全体を対象にします。')),
        default='SELECTED',
        update=_suv_workspace_settings_update,
    )
    auto_seam_angle_threshold: bpy.props.FloatProperty(
        name="自動シーム角度",
        description="隣接面の折れ角がこの値以上の場合にシーム候補にします。低い値ほど切れ目が増え、高い値ほどアイランドを大きく保ちます。",
        default=math.radians(60.0), min=0.0, max=math.pi, subtype='ANGLE', update=_suv_workspace_settings_update,
    )
    auto_seam_mark_threshold: bpy.props.FloatProperty(
        name="シーム判定しきい値",
        description="角度、境界、引張、ループ、筒状カットなどの総合スコアがこの値を超えた辺をシームにします。低い値ほど多くのシームを作り、高い値ほど必要なシームだけに絞ります。",
        default=45.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_workspace_settings_update,
    )
    auto_seam_angle_weight: bpy.props.FloatProperty(name="辺角度", description="隣接面の角度差を自動シーム判定でどれだけ重視するかを設定します。ハードサーフェスでは高めにすると角で切れやすくなります。", default=70.0, min=0.0, max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_workspace_settings_update)
    auto_seam_sharp_weight: bpy.props.FloatProperty(name="シャープ", description="Blenderのシャープエッジ指定を自動シーム候補として重視する強度です。", default=65.0, min=0.0, max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_workspace_settings_update)
    auto_seam_material_weight: bpy.props.FloatProperty(name="材質境界", description="隣接面のマテリアルが異なる辺をシーム候補として重視する強度です。", default=60.0, min=0.0, max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_workspace_settings_update)
    auto_seam_boundary_weight: bpy.props.FloatProperty(name="開放境界", description="開いた境界や選択範囲の外周をシームとして扱う強度です。部分選択で未選択面から切り離したい場合は高めにします。", default=75.0, min=0.0, max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_workspace_settings_update)
    auto_seam_stretch_weight: bpy.props.FloatProperty(name="引張予測", description="長さの偏りや折れ角から展開後に伸びやすい辺を予測し、折れ角などの根拠がある辺を後押しする強度です。これだけではシームになりません。", default=45.0, min=0.0, max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_workspace_settings_update)
    auto_seam_loop_weight: bpy.props.FloatProperty(name="ループ維持", description="連続したエッジループや長い切れ目を維持する強度です。折れ角などの根拠がある辺を後押しします。これだけではシームになりません。", default=55.0, min=0.0, max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_workspace_settings_update)
    auto_seam_cylinder_weight: bpy.props.FloatProperty(name="筒状カット", description="円柱、パイプ、チューブのような筒状形状で、キャップ境界と長手方向の1本の切れ目を作る強度です。高くすると筒状側面を1枚のアイランドへ開きやすくなります。", default=55.0, min=0.0, max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_workspace_settings_update)
    auto_seam_nonmanifold_weight: bpy.props.FloatProperty(name="非多様体", description="非多様体エッジや特殊な境界を安全側でシームにする強度です。", default=100.0, min=0.0, max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_workspace_settings_update)
    auto_seam_clear_existing: bpy.props.BoolProperty(
        name="既存シームを先に解除",
        description="自動シーム実行前に対象範囲の既存シームを解除し、現在の設定だけでシームを作り直します。既存の手動シームを残したい場合は無効にしてください。",
        default=False,
        update=_suv_workspace_settings_update,
    )

    auto_unwrap_mode: bpy.props.EnumProperty(
        name="Unwrap Method",
        description="Choose the unwrap/projection method. Detailed Unwrap is the refined Smart UV route; Blender 5.1 standard unwrap and projection tools are collected here and run on the current UV Editor selection only. / 展開方式を選択します。詳細展開は調整付きのSmart UVルートです。Blender 5.1標準の展開・投影機能もここへ集約し、現在UVエディターで選択中のエレメントだけに実行します。",
        items=(
            ('SMART', '詳細展開', '詳細展開です。Smart標準系の公開仕様に基づく設定を使って、展開・リラックス・パックを一括実行します。'),
            ('SMART_SQUARE', '四角', '外周をUVキャンバスの四辺へ合わせる四角展開方式です。'),
            ('SMART_CIRCLE', '円', '外周を円形へ広げる円形展開方式です。'),
            ('FLAT_MAPPING', 'Flat', 'Flatten Mapping style angle-cluster unwrap with spacing, normalization and optional packing.'),
            ('BLENDER_ANGLE_BASED', 'アングルベースで展開', 'Blender標準のAngle Based Unwrapを、Smart UVの選択スコープ・シーム準拠・ピン維持・自動パック付きで実行します。'),
            ('BLENDER_CONFORMAL', '等角で展開', 'Blender標準のConformal Unwrapを、Smart UVの選択スコープ・シーム準拠・ピン維持・自動パック付きで実行します。'),
            ('BLENDER_MIN_STRETCH', '最小ストレッチで展開', 'Blender 5.1標準のMinimum Stretch Unwrapを使い、必要に応じてMinimize Stretchで仕上げます。'),
            ('BLENDER_SMART_PROJECT', 'スマートUV投影', 'Blender標準Smart UV Projectを、Smart UVの厳格な選択範囲で実行します。'),
            ('BLENDER_LIGHTMAP_PACK', 'ライトマップパック', 'Blender標準Lightmap Packを選択UV面だけに適用します。'),
            ('BLENDER_FOLLOW_ACTIVE_QUADS', 'アクティブ四角形面に追従', 'Blender標準Follow Active Quadsを、選択された四角形面の範囲だけに適用します。'),
            ('QUICK_PLANAR', 'Planar', 'Specialized planar projection from the projection gizmo or dominant selected-face direction.'),
            ('BOX_PROJECT', 'キューブ投影', 'Blender標準Cube Projectionを基本に、投影ギズモ有効時はSmart UVのUVW Map Box投影として実行します。'),
            ('CYLINDRICAL', '円筒状投影', 'Blender標準Cylindrical Projectionを基本に、投影ギズモ有効時はSmart UVの円柱UVW投影として実行します。'),
            ('SPHERICAL', '球状投影', 'Blender標準Spherical Projectionを基本に、投影ギズモ有効時はSmart UVの球UVW投影として実行します。'),
            ('VIEW_PROJECT', 'View', 'Specialized projection from the current view or projection gizmo for decals or paint guides.'),
            ('UNITIZE_FACES', 'Unitize', 'Specialized per-face normalized tile mapping for ID, trim or debug layouts.'),
        ),
        default='BLENDER_ANGLE_BASED',
        update=_suv_workspace_settings_update,
    )


    native_unwrap_fill_holes: bpy.props.BoolProperty(
        name="Fill Holes",
        description="Blender標準のUnwrap設定です。選択されたUV面スコープ内で穴のある領域も展開計算に含めます。アングルベース、等角、最小ストレッチの展開前分割グループごとに反映されます。",
        default=False,
        update=_suv_workspace_settings_update,
    )
    native_unwrap_correct_aspect: bpy.props.BoolProperty(
        name="Correct Aspect",
        description="Blender標準のUnwrap設定です。画像や表示のアスペクト比を考慮してUVを展開します。テクスチャ比率を保ちたい場合に有効です。",
        default=True,
        update=_suv_workspace_settings_update,
    )
    native_unwrap_use_subsurf_data: bpy.props.BoolProperty(
        name="Use Subsurf Data",
        description="Blender標準のUnwrap設定です。サブディビジョン由来の形状データを展開に利用します。Subdivision Surfaceを使うモデルで、滑らかな形状に近いUVを作りたい場合に有効です。",
        default=False,
        update=_suv_workspace_settings_update,
    )
    native_unwrap_margin_method: bpy.props.EnumProperty(
        name="Margin Method",
        description="Blender標準のUnwrap余白方式です。Scaledは既存UVスケールに応じて余白を変え、Addは絶対値を足し、Fractionは最終UV領域に対する割合として扱います。",
        items=(
            ('SCALED', 'Scaled', '既存UVのスケールを基準に余白を掛けます。'),
            ('ADD', 'Add', 'UVスケールを無視して指定値の余白を加えます。'),
            ('FRACTION', 'Fraction', '最終UV出力に対する割合として余白を指定します。'),
        ),
        default='SCALED',
        update=_suv_workspace_settings_update,
    )
    native_unwrap_margin: bpy.props.FloatProperty(
        name="Margin",
        description="Blender標準のUnwrap余白です。シームで分割された各グループ展開後、選択UV面のみを最終パックする前の展開余白として使用します。",
        default=0.001,
        min=0.0,
        max=1.0,
        subtype='FACTOR',
        precision=4,
        update=_suv_workspace_settings_update,
    )
    native_unwrap_no_flip: bpy.props.BoolProperty(
        name="No Flip",
        description="Blender標準のUnwrap設定です。展開中にUV面が反転する結果を避けます。反転しやすい複雑形状で安全側にしたい場合に有効です。",
        default=False,
        update=_suv_workspace_settings_update,
    )
    native_unwrap_iterations: bpy.props.IntProperty(
        name="Iterations",
        description="Blender標準のMinimum Stretch Unwrap反復数です。最小ストレッチで展開するときに使用され、値を上げるほど伸びの低減を試みます。",
        default=10,
        min=0,
        max=10000,
        soft_min=1,
        soft_max=30,
        update=_suv_workspace_settings_update,
    )
    native_unwrap_use_weights: bpy.props.BoolProperty(
        name="Use Weights",
        description="Blender標準のUnwrap設定です。指定した頂点グループをUV展開の重要度ウェイトとして使用します。重要な部分のUV変化を抑えたい場合に有効です。",
        default=False,
        update=_suv_workspace_settings_update,
    )
    native_unwrap_weight_group: bpy.props.StringProperty(
        name="Weight Group",
        description="Blender標準のUnwrapで使用するウェイト用頂点グループ名です。Use Weightsを有効にした場合に、この名前の頂点グループを参照します。",
        default="uv_importance",
        update=_suv_workspace_settings_update,
    )
    native_unwrap_weight_factor: bpy.props.FloatProperty(
        name="Weight Factor",
        description="Blender標準のUnwrapウェイト係数です。正の値ではウェイト領域をより強く維持し、負の値では影響方向を反転させます。",
        default=1.0,
        min=-10000.0,
        max=10000.0,
        soft_min=-10.0,
        soft_max=10.0,
        precision=3,
        update=_suv_workspace_settings_update,
    )
    native_minimize_stretch_after: bpy.props.BoolProperty(
        name="Run Minimize Stretch",
        description="最小ストレッチで展開後、Blender標準のMinimize Stretch処理を追加で実行します。標準Unwrapの結果を保ちたい場合はOFF、展開後の伸びをさらに減らしたい場合はONにします。",
        default=False,
        update=_suv_workspace_settings_update,
    )
    native_minimize_stretch_fill_holes: bpy.props.BoolProperty(
        name="Minimize Fill Holes",
        description="Blender標準Minimize StretchのFill Holes設定です。追加ストレッチ軽減時に穴のある領域も考慮します。",
        default=True,
        update=_suv_workspace_settings_update,
    )
    native_minimize_stretch_blend: bpy.props.FloatProperty(
        name="Minimize Blend",
        description="Blender標準Minimize Stretchの適用強度です。0では追加補正なし、1では補正を最大反映します。",
        default=0.0,
        min=0.0,
        max=1.0,
        subtype='FACTOR',
        update=_suv_workspace_settings_update,
    )
    native_minimize_stretch_iterations: bpy.props.IntProperty(
        name="Minimize Iterations",
        description="Blender標準Minimize Stretchの反復回数です。追加ストレッチ軽減を有効にした場合に使用します。",
        default=0,
        min=0,
        max=10000,
        soft_min=0,
        soft_max=100,
        update=_suv_workspace_settings_update,
    )
    native_smart_project_angle_limit: bpy.props.FloatProperty(
        name="Angle Limit",
        description="Blender標準Smart UV Projectの角度制限です。小さい値ほど角度差で細かく分割し、大きい値ほど大きなアイランドを作ります。",
        default=1.1519173063162575,
        min=0.0,
        max=1.5707963705062866,
        soft_min=0.0,
        soft_max=1.5533430576324463,
        subtype='ANGLE',
        update=_suv_workspace_settings_update,
    )
    native_smart_project_margin_method: bpy.props.EnumProperty(
        name="Margin Method",
        description="Blender標準Smart UV Projectの余白方式です。Smart UVの厳格UV面選択スコープ内で、島間余白の解釈に反映されます。",
        items=(
            ('SCALED', 'Scaled', '既存UVのスケールを基準に余白を掛けます。'),
            ('ADD', 'Add', 'UVスケールを無視して指定値の余白を加えます。'),
            ('FRACTION', 'Fraction', '最終UV出力に対する割合として余白を指定します。'),
        ),
        default='SCALED',
        update=_suv_workspace_settings_update,
    )
    native_smart_project_rotate_method: bpy.props.EnumProperty(
        name="Rotate Method",
        description="Blender標準Smart UV Projectの島回転方式です。軸整列、横方向軸整列、縦方向軸整列のいずれで島の向きを決めるかを指定します。",
        items=(
            ('AXIS_ALIGNED', 'Axis-aligned', '島を水平または垂直の最小矩形へ軸整列します。'),
            ('AXIS_ALIGNED_X', 'Axis-aligned (Horizontal)', '島を横方向へ軸整列します。'),
            ('AXIS_ALIGNED_Y', 'Axis-aligned (Vertical)', '島を縦方向へ軸整列します。'),
        ),
        default='AXIS_ALIGNED_Y',
        update=_suv_workspace_settings_update,
    )
    native_smart_project_island_margin: bpy.props.FloatProperty(
        name="Island Margin",
        description="Blender標準Smart UV Projectの島間余白です。展開直後の島配置に使われ、最後にSmart UVの選択範囲パックも実行されます。",
        default=0.0,
        min=0.0,
        max=1.0,
        precision=4,
        update=_suv_workspace_settings_update,
    )
    native_smart_project_area_weight: bpy.props.FloatProperty(
        name="Area Weight",
        description="Blender標準Smart UV Projectの面積ウェイトです。0では角度優先、1では元メッシュ面積をより重視した分割になります。",
        default=0.0,
        min=0.0,
        max=1.0,
        subtype='FACTOR',
        update=_suv_workspace_settings_update,
    )
    native_smart_project_correct_aspect: bpy.props.BoolProperty(
        name="Correct Aspect",
        description="Blender標準Smart UV Projectで画像アスペクトを考慮します。非正方形テクスチャを想定する場合に有効です。",
        default=True,
        update=_suv_workspace_settings_update,
    )
    native_smart_project_scale_to_bounds: bpy.props.BoolProperty(
        name="Scale To Bounds",
        description="Blender標準Smart UV Projectで展開結果をUV境界内へスケールします。最後の選択範囲パック前に、Smart Project結果を0-1範囲へ寄せたい場合に有効です。",
        default=False,
        update=_suv_workspace_settings_update,
    )
    native_lightmap_context: bpy.props.EnumProperty(
        name="Context",
        description="Blender標準Lightmap Packの対象指定です。Smart UVでは未選択UV保護を併用し、実際の最終変更範囲は完全にUV面選択された面だけに制限します。",
        items=(
            ('SEL_FACES', 'Selected Faces', '選択面だけをパックします。Smart UVの推奨設定です。'),
            ('ALL_FACES', 'All Faces', '標準仕様の全方面指定です。Smart UVでは未選択UVを復元して保護します。'),
        ),
        default='SEL_FACES',
        update=_suv_workspace_settings_update,
    )
    native_lightmap_pack_in_one: bpy.props.BoolProperty(
        name="Pack In One",
        description="Blender標準Lightmap Packの設定です。複数オブジェクトや複数面のライトマップを1つのUV領域へまとめて配置します。",
        default=True,
        update=_suv_workspace_settings_update,
    )
    native_lightmap_new_uvlayer: bpy.props.BoolProperty(
        name="New UV Layer",
        description="Blender標準Lightmap Packの新規UVレイヤー作成設定です。OFFでは現在の展開使用マップチャンネルへ書き込みます。ONではBlender標準挙動に従って新規UVを作成します。",
        default=False,
        update=_suv_workspace_settings_update,
    )
    native_lightmap_box_div: bpy.props.IntProperty(
        name="Box Divisions",
        description="Blender標準Lightmap Packのボックス分割数です。値を上げると配置探索が細かくなります。",
        default=12,
        min=1,
        max=48,
        update=_suv_workspace_settings_update,
    )
    native_lightmap_margin_div: bpy.props.FloatProperty(
        name="Margin Division",
        description="Blender標準Lightmap Packの余白分割値です。小さい値ほど余白が小さく、大きい値ほど島間の安全余白が広がります。",
        default=0.1,
        min=0.001,
        max=1.0,
        precision=4,
        update=_suv_workspace_settings_update,
    )
    native_follow_quads_mode: bpy.props.EnumProperty(
        name="Follow Mode",
        description="Blender標準Follow Active Quadsの展開方式です。Evenは等間隔、Lengthは辺長に基づき、Length Averageは辺長平均に基づいてUVを整列展開します。",
        items=(
            ('EVEN', 'Even', 'UVを均等間隔で配置します。'),
            ('LENGTH', 'Length', '各ループの辺長を使って間隔を決めます。'),
            ('LENGTH_AVERAGE', 'Length Average', '各ループの辺長平均を使って間隔を決めます。'),
        ),
        default='LENGTH_AVERAGE',
        update=_suv_workspace_settings_update,
    )
    native_cube_size: bpy.props.FloatProperty(
        name="Cube Size",
        description="Blender標準Cube Projectionの投影キューブサイズです。投影ギズモを使わない場合に、選択UV面スコープへ反映されます。",
        default=1.0,
        min=0.0,
        soft_min=0.001,
        soft_max=100.0,
        precision=4,
        update=_suv_workspace_settings_update,
    )
    native_cube_correct_aspect: bpy.props.BoolProperty(name="Correct Aspect", description="Blender標準Cube Projectionで画像アスペクトを考慮します。", default=True, update=_suv_workspace_settings_update)
    native_cube_clip_to_bounds: bpy.props.BoolProperty(name="Clip To Bounds", description="Blender標準Cube ProjectionでUVを境界内へクリップします。", default=False, update=_suv_workspace_settings_update)
    native_cube_scale_to_bounds: bpy.props.BoolProperty(name="Scale To Bounds", description="Blender標準Cube ProjectionでUVを境界内へスケールします。", default=False, update=_suv_workspace_settings_update)
    native_cylinder_direction: bpy.props.EnumProperty(
        name="Direction",
        description="Blender標準Cylindrical Projectionの投影方向です。ビュー基準、ポールビュー基準、オブジェクト変換基準から選択します。",
        items=(('VIEW_ON_EQUATOR', 'View on Equator', '3Dビューを赤道側として扱います。'), ('VIEW_ON_POLES', 'View on Poles', '3Dビューを極側として扱います。'), ('ALIGN_TO_OBJECT', 'Align to Object', 'オブジェクト変換に合わせて投影します。')),
        default='VIEW_ON_EQUATOR', update=_suv_workspace_settings_update,
    )
    native_cylinder_align: bpy.props.EnumProperty(name="Align", description="Blender標準Cylindrical Projectionの極座標開始軸です。", items=(('POLAR_ZX', 'Polar ZX', 'Z-X方向を基準にします。'), ('POLAR_ZY', 'Polar ZY', 'Z-Y方向を基準にします。')), default='POLAR_ZX', update=_suv_workspace_settings_update)
    native_cylinder_pole: bpy.props.EnumProperty(name="Pole", description="Blender標準Cylindrical Projectionの極の処理です。Pinchは極に集約し、Fanは扇状に展開します。", items=(('PINCH', 'Pinch', '極を集約します。'), ('FAN', 'Fan', '極を扇状に展開します。')), default='PINCH', update=_suv_workspace_settings_update)
    native_cylinder_seam: bpy.props.BoolProperty(name="Seam", description="Blender標準Cylindrical Projectionでシームを使用します。筒状展開の切れ目を標準投影側で作る場合に有効です。", default=False, update=_suv_workspace_settings_update)
    native_cylinder_radius: bpy.props.FloatProperty(name="Radius", description="Blender標準Cylindrical Projectionの半径です。投影ギズモを使わない場合の円筒投影サイズに反映されます。", default=1.0, min=0.0, soft_min=0.0001, soft_max=100.0, precision=4, update=_suv_workspace_settings_update)
    native_cylinder_correct_aspect: bpy.props.BoolProperty(name="Correct Aspect", description="Blender標準Cylindrical Projectionで画像アスペクトを考慮します。", default=True, update=_suv_workspace_settings_update)
    native_cylinder_clip_to_bounds: bpy.props.BoolProperty(name="Clip To Bounds", description="Blender標準Cylindrical ProjectionでUVを境界内へクリップします。", default=False, update=_suv_workspace_settings_update)
    native_cylinder_scale_to_bounds: bpy.props.BoolProperty(name="Scale To Bounds", description="Blender標準Cylindrical ProjectionでUVを境界内へスケールします。", default=False, update=_suv_workspace_settings_update)
    native_sphere_direction: bpy.props.EnumProperty(
        name="Direction",
        description="Blender標準Spherical Projectionの投影方向です。ビュー基準、ポールビュー基準、オブジェクト変換基準から選択します。",
        items=(('VIEW_ON_EQUATOR', 'View on Equator', '3Dビューを赤道側として扱います。'), ('VIEW_ON_POLES', 'View on Poles', '3Dビューを極側として扱います。'), ('ALIGN_TO_OBJECT', 'Align to Object', 'オブジェクト変換に合わせて投影します。')),
        default='VIEW_ON_EQUATOR', update=_suv_workspace_settings_update,
    )
    native_sphere_align: bpy.props.EnumProperty(name="Align", description="Blender標準Spherical Projectionの極座標開始軸です。", items=(('POLAR_ZX', 'Polar ZX', 'Z-X方向を基準にします。'), ('POLAR_ZY', 'Polar ZY', 'Z-Y方向を基準にします。')), default='POLAR_ZX', update=_suv_workspace_settings_update)
    native_sphere_pole: bpy.props.EnumProperty(name="Pole", description="Blender標準Spherical Projectionの極の処理です。Pinchは極に集約し、Fanは扇状に展開します。", items=(('PINCH', 'Pinch', '極を集約します。'), ('FAN', 'Fan', '極を扇状に展開します。')), default='PINCH', update=_suv_workspace_settings_update)
    native_sphere_seam: bpy.props.BoolProperty(name="Seam", description="Blender標準Spherical Projectionでシームを使用します。球状投影の切れ目を標準投影側で作る場合に有効です。", default=False, update=_suv_workspace_settings_update)
    native_sphere_correct_aspect: bpy.props.BoolProperty(name="Correct Aspect", description="Blender標準Spherical Projectionで画像アスペクトを考慮します。", default=True, update=_suv_workspace_settings_update)
    native_sphere_clip_to_bounds: bpy.props.BoolProperty(name="Clip To Bounds", description="Blender標準Spherical ProjectionでUVを境界内へクリップします。", default=False, update=_suv_workspace_settings_update)
    native_sphere_scale_to_bounds: bpy.props.BoolProperty(name="Scale To Bounds", description="Blender標準Spherical ProjectionでUVを境界内へスケールします。", default=False, update=_suv_workspace_settings_update)

    smart_unwrap_preset: bpy.props.EnumProperty(
        name="Hidden Smart Shape",
        description="Internal compatibility value. The visible UI no longer exposes Shape; Square and Circle are independent unwrap methods.",
        items=(
            ('STANDARD', '標準', 'Internal standard route.'),
            ('SQUARE', '四角', 'Internal square route.'),
            ('CIRCLE', '円', 'Internal circle route.'),
        ),
        default='STANDARD',
        options={'HIDDEN'},
        update=_suv_smart_unwrap_preset_update,
    )
    smart_unwrap_algorithm: bpy.props.EnumProperty(
        name="Internal Smart Route",
        description="Hidden compatibility value. Smart Standard derives the internal route from Smart Standard settings; this is not shown in the UI.",
        items=(
            ('HARD_SURFACE', 'ハードサーフェス', '折れ角度・硬い稜線・長辺変化を重視して分割と展開を行います。'),
            ('ORGANIC', 'オーガニック', '滑らかな面を大きめのチャートで保ち、リラックスと形状保持を重視します。'),
            ('MOSAIC', 'モザイク', '複雑形状やスキャン形状を安全な小チャートへ分け、重なり回避を重視します。'),
            ('PROJECTION', '投影', '投影ベースの大きなチャートを作り、投影後に整列・パックします。'),
        ),
        default='ORGANIC',
        options={'HIDDEN'},
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_realtime_preview: bpy.props.BoolProperty(
        name="ライブ展開",
        description="リアルタイム反映とBlender標準ライブ展開をこの1項目に集約します。ONにすると、手動の展開実行後、同じ選択メッシュの展開設定変更時だけ選択範囲へ再反映します。",
        default=False,
        update=_suv_smart_realtime_update,
    )


    smart_standard_core_unwrap_mode: bpy.props.EnumProperty(
        name="展開モード",
        description="Smart標準展開の方式とシーム解析プリセットを1つに統合した項目です。選択すると角度制限、面積ウェイト、品質最適化、Singleアイランド・シーム解析、ストレッチ軽減、パッキング設定をまとめて切り替えます。手動調整は現在の数値を保持します。",
        items=_suv_smart_standard_unwrap_mode_items,
        default='SMART_STANDARD_HARD',
        update=_suv_smart_standard_unwrap_mode_update,
    )
    smart_standard_core_resolved_unwrap_mode: bpy.props.EnumProperty(
        name="Resolved Smart Standard Mode",
        description="統合された展開モードから解決された内部展開方式です。UIには表示せず、実行時のSmart Standard: Hard/Organic、Smart Project、Normal Unwrapの判定に使用します。",
        items=(
            ('SMART_STANDARD_HARD', 'Smart Standard: Hard Surface', '無機物向け。角度で分割し、歪みを抑えます。'),
            ('SMART_STANDARD_ORGANIC', 'Smart Standard: Organic', '有機物向け。シームを抑えつつ歪みを均します。'),
            ('SMART', 'Standard Smart Project', '標準の角度ベース分割です。'),
            ('NORMAL', 'Normal Unwrap', '手動シームを基準に通常展開します。'),
        ),
        default='SMART_STANDARD_HARD',
        options={'HIDDEN'},
    )
    smart_standard_core_last_actual_unwrap_mode: bpy.props.EnumProperty(
        name="Last Actual Smart Standard Mode",
        description="Singleアイランドなどの統合プリセットを選ぶ前に使っていた内部展開方式を保持します。",
        items=(
            ('SMART_STANDARD_HARD', 'Smart Standard: Hard Surface', '無機物向け。角度で分割し、歪みを抑えます。'),
            ('SMART_STANDARD_ORGANIC', 'Smart Standard: Organic', '有機物向け。シームを抑えつつ歪みを均します。'),
            ('SMART', 'Standard Smart Project', '標準の角度ベース分割です。'),
            ('NORMAL', 'Normal Unwrap', '手動シームを基準に通常展開します。'),
        ),
        default='SMART_STANDARD_HARD',
        options={'HIDDEN'},
    )
    smart_standard_core_unwrap_math: bpy.props.EnumProperty(
        name="Unwrap Math",
        description="Normal Unwrapとシーム解析後の再展開で使う計算方式です。Angle Basedは曲面向け、Conformalは硬い形状向けです。",
        items=(
            ('ANGLE_BASED', 'Angle Based', '有機物や曲面向けの角度ベース展開です。'),
            ('CONFORMAL', 'Conformal', 'ハードサーフェスや直角が多い形状向けの等角展開です。'),
        ),
        default='ANGLE_BASED',
        update=_suv_smart_realtime_update,
    )
    smart_standard_core_smart_angle: bpy.props.FloatProperty(
        name="Angle Limit",
        description="Angle threshold for Smart Project based modes. / Smart Project系モードの角度しきい値です。",
        default=1.1519173063162575, min=0.0, max=3.141592653589793, subtype='ANGLE', update=_suv_smart_realtime_update,
    )
    smart_standard_core_smart_area_weight: bpy.props.FloatProperty(
        name="Area Weight",
        description="Smart Project系展開で面積をどれだけ重視するかを指定します。0は角度優先、1は面積優先です。",
        default=0.0, min=0.0, max=1.0, subtype='FACTOR', update=_suv_smart_realtime_update,
    )
    smart_standard_core_single_seam_profile: bpy.props.EnumProperty(
        name="互換プリセット",
        description="旧バージョン互換用の非表示プロパティです。現在は展開モードに統合され、UIには表示しません。",
        items=_suv_smart_standard_seam_profile_items,
        default='STANDARD_KEEP',
        options={'HIDDEN'},
        update=_suv_smart_standard_seam_profile_update,
    )
    smart_standard_core_seam_merge_strength: bpy.props.FloatProperty(
        name="アイランド結合率",
        description="Singleアイランド・シーム解析で使う島の結合率です。0%では現在の展開方式の分割を維持し、数値を上げるほど解析スコアに基づいて隣接アイランドを統合してから再展開します。100%ではSingleアイランドプリセットと同じく1つのUVアイランドを目標にします。",
        default=0.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_smart_realtime_update,
    )
    smart_standard_core_single_angle_weight: bpy.props.FloatProperty(
        name="辺角度維持",
        description="Single アイランドが中間値のとき、鋭い辺角度や硬い折れ目のシームをどれだけ残すかを設定します。高くするとハードサーフェスの角や稜線でシームを維持しやすくします。",
        default=72.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_smart_realtime_update,
    )
    smart_standard_core_single_stretch_weight: bpy.props.FloatProperty(
        name="引張予測",
        description="Single アイランドが中間値のとき、UVの辺長比率や面積比率から結合後の引張を予測し、伸びやすい境界を残す強度です。高くすると崩れやすい結合を後回しにします。",
        default=72.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_smart_realtime_update,
    )
    smart_standard_core_single_loop_weight: bpy.props.FloatProperty(
        name="ループ辺維持",
        description="Single アイランドが中間値のとき、長く連続したエッジループ状のシームをどれだけ維持するかを設定します。高くするとモデルの流れに沿った切れ目を残しやすくします。",
        default=62.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_smart_realtime_update,
    )
    smart_standard_core_single_planarity_weight: bpy.props.FloatProperty(
        name="平面性維持",
        description="Single アイランドが中間値のとき、法線方向が大きく違うアイランド同士を無理に統合しない強度です。高くすると平面性の近い領域から優先して統合します。",
        default=55.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_smart_realtime_update,
    )
    smart_standard_core_single_density_weight: bpy.props.FloatProperty(
        name="面積密度維持",
        description="Single アイランドが中間値のとき、隣接アイランドの元メッシュ面積とUV面積の密度差を評価し、密度差の大きい境界を残す強度です。高くすると統合後のサイズ比率が安定します。",
        default=55.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_smart_realtime_update,
    )
    smart_standard_core_single_user_seam_weight: bpy.props.FloatProperty(
        name="既存シーム維持",
        description="Single アイランドが中間値のとき、展開前に存在していた手動シームや既存シームをどれだけ尊重するかを設定します。高くするとユーザーが意図した切れ目を残しやすくします。",
        default=80.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_smart_realtime_update,
    )
    smart_standard_core_single_boundary_weight: bpy.props.FloatProperty(
        name="境界連続性",
        description="Single アイランドが中間値のとき、長い共有境界や連続した境界を評価する強度です。高くすると、同一面上で分割されたような共有境界を早めに統合し、残るシームを整理します。",
        default=46.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_smart_realtime_update,
    )
    smart_standard_core_single_small_island_merge: bpy.props.FloatProperty(
        name="小島統合",
        description="Single アイランドが中間値のとき、小さなアイランドや細切れの境界を優先して統合する強度です。高くすると孤立した小島を周囲へ早めに吸収します。",
        default=42.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_smart_realtime_update,
    )
    smart_standard_core_single_seam_angle_weight: bpy.props.FloatProperty(
        name="辺角度維持",
        description="Single アイランドが中間値のとき、鋭い角度や硬い折れ目の境界をどれだけシームとして残すかを設定します。0%では角度を重視せず、100%では急角度の辺を最後まで残しやすくします。",
        default=85.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_smart_realtime_update,
    )
    smart_standard_core_single_seam_stretch_weight: bpy.props.FloatProperty(
        name="引張強度維持",
        description="Single アイランドが中間値のとき、現在のUVで伸びや面積差が強い境界をどれだけシームとして残すかを設定します。高くすると、結合後に伸びやすい境界を後回しにします。",
        default=70.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_smart_realtime_update,
    )
    smart_standard_core_single_seam_loop_weight: bpy.props.FloatProperty(
        name="ループ辺維持",
        description="Single アイランドが中間値のとき、長く連続したエッジループ状のシームをどれだけ維持するかを設定します。高くすると、モデルの流れに沿った綺麗なループ境界を残しやすくします。",
        default=60.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_smart_realtime_update,
    )
    smart_standard_core_single_seam_area_weight: bpy.props.FloatProperty(
        name="島面積均衡",
        description="Single アイランドが中間値のとき、結合後のアイランドが大きくなり過ぎたり面積差が偏り過ぎたりしないようにする強度です。高くすると、段階的に面積バランスの良い島へ統合します。",
        default=50.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_smart_realtime_update,
    )
    smart_standard_core_single_seam_shared_boundary_weight: bpy.props.FloatProperty(
        name="共有境界統合",
        description="Single アイランドが中間値のとき、長い共有境界を持つ隣接アイランドを優先的に統合する強度です。高くすると、同じ面の途中で分かれたような境界を早めに消しやすくします。",
        default=55.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_smart_realtime_update,
    )
    smart_standard_core_single_seam_jagged_cleanup_weight: bpy.props.FloatProperty(
        name="ジグザグ整理",
        description="Single アイランドが中間値のとき、短く途切れた境界やジグザグした境界を早めに統合する強度です。高くすると、残るシームをより単純で読みやすい境界へ整理します。",
        default=35.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_smart_realtime_update,
    )
    smart_standard_core_quality_strength: bpy.props.FloatProperty(
        name="高品質最適化",
        description="Blender標準展開の結果を初期解として、後段の面積維持・形状維持アルゴリズムをどれだけ反映するかを設定します。0%では標準展開結果を変更せず、100%では面積と形状の補正を最大限反映します。",
        default=0.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_smart_realtime_update,
    )
    smart_standard_core_area_preserve_strength: bpy.props.FloatProperty(
        name="面積維持",
        description="元メッシュの面面積を基準に、UVアイランドのサイズ比率と各面の面積密度を補正する強度です。0%では面積補正を行わず、100%では元メッシュ面積に最も近いテクセル密度へ寄せます。",
        default=0.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_smart_realtime_update,
    )
    smart_standard_core_shape_preserve_strength: bpy.props.FloatProperty(
        name="形状維持",
        description="元メッシュの辺長とフェイス形状を基準に、UVが伸び過ぎたり潰れたりしないように補正する強度です。面積だけを合わせて崩れる状態を防ぎます。",
        default=0.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_smart_realtime_update,
    )
    smart_standard_core_native_result_preserve: bpy.props.FloatProperty(
        name="標準結果維持",
        description="Smart ProjectやNormal Unwrapなど、元の標準展開結果をどれだけ保持するかを設定します。0%では補正結果を優先し、100%では後段最適化を実質的に反映せず標準展開結果へ戻します。",
        default=100.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1, update=_suv_smart_realtime_update,
    )
    smart_standard_core_quality_iterations: bpy.props.IntProperty(
        name="最適化反復",
        description="面積維持・形状維持の反復回数です。値を上げるほど補正が安定しますが、重いメッシュでは処理時間が増えます。",
        default=0, min=0, max=240, update=_suv_smart_realtime_update,
    )
    smart_standard_core_baseline_axis: bpy.props.EnumProperty(
        name="Baseline Axis",
        description="Local-axis baseline pinning target. Vertices near the local zero plane are straightened and pinned before the final unwrap. / ローカル軸の0付近にある頂点を直線化してピン留めします。",
        items=(
            ('NONE', 'None', '基準直線を使いません。'),
            ('X', 'Local X', 'ローカルX軸を基準にします。'),
            ('Y', 'Local Y', 'ローカルY軸を基準にします。'),
            ('Z', 'Local Z', 'ローカルZ軸を基準にします。'),
            ('SELECTED', 'UV Selected', 'UVエディターで選択した辺列を基準にします。'),
        ),
        default='NONE', update=_suv_smart_realtime_update,
    )
    smart_standard_core_baseline_threshold: bpy.props.FloatProperty(
        name="Axis Threshold",
        description="Distance tolerance from the selected local axis zero plane. / ローカル軸0平面からの許容距離です。",
        default=0.001, min=0.0, max=10.0, precision=4, update=_suv_smart_realtime_update,
    )
    smart_standard_core_stretch_iterations: bpy.props.IntProperty(
        name="Stretch Iterations",
        description="Stretch minimization iterations for Smart Standard hard/organic modes. / Smart Standard Hard/Organicで使う歪み軽減反復数です。",
        default=100, min=0, max=2000, update=_suv_smart_realtime_update,
    )
    smart_standard_core_stretch_blend: bpy.props.FloatProperty(
        name="Stretch Blend",
        description="Strength of stretch minimization. / 歪み軽減の適用強度です。",
        default=1.0, min=0.0, max=1.0, subtype='FACTOR', update=_suv_smart_realtime_update,
    )
    smart_standard_core_auto_pack: bpy.props.BoolProperty(
        name="Auto Pack Islands",
        description="Average island scale and pack after unwrap. / 展開後に平均スケールとパックを行います。",
        default=True, update=_suv_smart_realtime_update,
    )
    smart_standard_core_pack_margin: bpy.props.FloatProperty(
        name="Island Margin",
        description="Packing margin in UV space. / パッキング余白です。",
        default=0.02, min=0.0, max=1.0, precision=4, update=_suv_smart_realtime_update,
    )
    smart_standard_core_pack_margin_method: bpy.props.EnumProperty(
        name="Margin Method",
        description="Margin interpretation for Blender pack islands. / パッキング余白の扱いです。",
        items=(
            ('FRACTION', 'Fraction', 'UV空間全体に対する割合で余白を設定します。'),
            ('SCALED', 'Scaled', 'UV島のスケールに依存した余白を設定します。'),
            ('ADD', 'Add', '絶対値で余白を追加します。'),
        ),
        default='FRACTION', update=_suv_smart_realtime_update,
    )
    smart_standard_core_pack_rotate_method: bpy.props.EnumProperty(
        name="Rotation Method",
        description="Rotation policy for packing. Baseline pinning disables rotation automatically. / パック時の回転方式です。基準直線化中は自動で回転なしになります。",
        items=(
            ('ANY', 'Any', '最も効率よく詰まる任意角度で回転します。'),
            ('CARDINAL', 'Cardinal', '90度単位で回転します。'),
            ('AXIS_ALIGNED', 'Axis Aligned', 'バウンディングボックスに合わせて回転します。'),
            ('NONE', 'None', '回転しません。'),
        ),
        default='ANY', update=_suv_smart_realtime_update,
    )
    smart_standard_core_pre_fix_mesh: bpy.props.BoolProperty(
        name="Auto Fix Mesh",
        description="Remove doubles and recalculate normals before unwrapping. / 展開前に重複頂点削除と法線再計算を行います。",
        default=False, update=_suv_smart_realtime_update,
    )
    smart_standard_core_merge_distance: bpy.props.FloatProperty(
        name="Merge Distance",
        description="Merge distance used by Auto Fix Mesh. / Auto Fix Meshで使う結合距離です。",
        default=0.0001, min=0.0, max=0.1, step=0.01, precision=4, update=_suv_smart_realtime_update,
    )

    smart_standard_core_reference_refine_enabled: bpy.props.BoolProperty(
        name="高精度チャート解析",
        description="展開前に一時シーム候補を解析し、選択UV面スコープ内のチャート分割を高精度化します。ユーザーの「シームをマーク」は消さず、処理後も維持します。",
        default=True,
        update=_suv_smart_realtime_update,
    )
    smart_standard_core_reference_profile: bpy.props.EnumProperty(
        name="解析プロファイル",
        description="展開前チャート解析の重み付けです。ハード向けはチャート数・ストレッチ・凹凸シームを重視し、選択面低歪み向けは選択範囲内の低歪みとリラックスを重視します。",
        items=(
            ('BALANCED', 'バランス', '通常形状向けに角度、伸び、既存シームを均衡させます。'),
            ('HARD_SURFACE_CHART', 'ハードサーフェス精密', '硬い折れ目、凹凸角度、既存シーム、ポリゴン境界を強く尊重します。'),
            ('ORGANIC_LOW_DISTORTION', 'オーガニック低歪み', '許容ストレッチを中心に、曲面を大きなチャートとして保ちます。'),
            ('SELECTED_SCOPE_LOW_STRETCH', '選択面低歪み', '選択面スコープの低歪み化を優先し、リラックスしやすい分割へ寄せます。'),
            ('PACK_FRIENDLY', 'Pack Friendly', 'パッキングしやすい縦横比とチャートサイズを優先します。'),
        ),
        default='BALANCED',
        update=_suv_smart_realtime_update,
    )
    smart_standard_core_reference_strength: bpy.props.FloatProperty(
        name="解析強度",
        description="高精度チャート解析の適用度です。0%では従来のSmart UV Suite展開に近く、100%では展開前チャート分割を強く反映します。",
        default=55.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1,
        update=_suv_smart_realtime_update,
    )
    smart_standard_core_reference_allowed_stretch: bpy.props.FloatProperty(
        name="許容ストレッチ",
        description="展開前のシーム候補評価で、辺長差や面積差から推定される引張をどこまで許容するかです。低いほど追加カットを増やし、高いほど大きな島を保ちます。",
        default=24.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1,
        update=_suv_smart_realtime_update,
    )
    smart_standard_core_reference_concave_angle: bpy.props.FloatProperty(
        name="凹角度シーム",
        description="溝・内側折れ目に相当する凹角度の自動シームしきい値です。値を下げるほど凹部でチャートを分けやすくします。",
        default=55.0, min=0.0, max=180.0, precision=1,
        update=_suv_smart_realtime_update,
    )
    smart_standard_core_reference_convex_angle: bpy.props.FloatProperty(
        name="凸角度シーム",
        description="稜線・外側折れ目に相当する凸角度の自動シームしきい値です。値を下げるほどハードエッジでチャートを分けやすくします。",
        default=45.0, min=0.0, max=180.0, precision=1,
        update=_suv_smart_realtime_update,
    )
    smart_standard_core_reference_existing_seam_weight: bpy.props.FloatProperty(
        name="既存シーム保持",
        description="ユーザーが「シームをマーク」した辺や既存シームを、展開前のチャート分割でどれだけ強く尊重するかです。100%ではユーザーシームを最優先します。",
        default=85.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1,
        update=_suv_smart_realtime_update,
    )
    smart_standard_core_reference_fewer_charts: bpy.props.FloatProperty(
        name="少チャート優先",
        description="少ないチャート数を狙う代替計算の強度です。高いほど追加シームを抑えて大きな島を保ちます。",
        default=50.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1,
        update=_suv_smart_realtime_update,
    )
    smart_standard_core_reference_loop_weight: bpy.props.FloatProperty(
        name="ループ境界維持",
        description="連続したエッジループや長い境界をシーム候補として残す強度です。筒状・帯状メッシュの読みやすい切れ目を作るときに上げます。",
        default=60.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1,
        update=_suv_smart_realtime_update,
    )
    smart_standard_core_reference_triangle_border: bpy.props.FloatProperty(
        name="三角境界許容",
        description="ポリゴン境界だけでなく、三角化に近い細かい境界を許容する強度です。高いほど細かいカットを許し、低いほどポリゴン境界を維持します。",
        default=10.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1,
        update=_suv_smart_realtime_update,
    )
    smart_standard_core_reference_cylindrical_loop: bpy.props.FloatProperty(
        name="筒状ループ補助",
        description="筒状・パイプ状の面群で、側面を一つの島にまとめやすくし、長手方向の切れ目を作りやすくする強度です。",
        default=50.0, min=0.0, max=100.0, soft_min=0.0, soft_max=100.0, subtype='PERCENTAGE', precision=0, step=1,
        update=_suv_smart_realtime_update,
    )

    smart_standard_unwrap_mode: bpy.props.EnumProperty(
        name="Unwrapping Mode",
        description="Smart UV Auto-style unwrapping mode. Geometrical analyzes real mesh folds and edge lengths; Polygonal keeps broader polygonal charts. / Smart UV Auto系の展開モードです。Geometricalは実メッシュの折れ・辺長を解析し、Polygonalはポリゴン単位の大きめチャートを優先します。",
        items=(
            ('GEOMETRICAL','Geometrical','Use geometry fold and edge analysis.'),
            ('POLYGONAL','Polygonal','Use polygonal chart flow with fewer forced cuts.'),
        ),
        default='GEOMETRICAL',
        update=_suv_workspace_settings_update,
    )

    smart_standard_selection: bpy.props.BoolProperty(
        name="Selection",
        description="Unwrap only the selected faces when possible. When disabled, Smart Standard unwraps all visible faces on the active mesh.",
        default=True,
        update=_suv_workspace_settings_update,
    )
    smart_standard_combine: bpy.props.BoolProperty(
        name="Combine",
        description="Pack charts as one combined texture set. For a single active mesh this keeps all generated islands in one UV canvas.",
        default=True,
        update=_suv_workspace_settings_update,
    )
    smart_standard_keep_borders: bpy.props.BoolProperty(
        name="Keep Borders",
        description="Prioritize existing UV island borders and avoid disrupting the current UV layout unless distortion makes extra cuts necessary.",
        default=False,
        update=_suv_workspace_settings_update,
    )
    smart_standard_use_marks: bpy.props.BoolProperty(
        name="Use Marks",
        description="Respect mesh seam marks as user-guided cuts during Smart Standard unwrap.",
        default=True,
        update=_suv_workspace_settings_update,
    )
    smart_standard_stretch: bpy.props.FloatProperty(
        name="Stretch",
        description="Allowed UV stretching for Organic and Mosaic style algorithms. 0 is stricter and creates more cuts; 1 allows more stretch to keep larger charts.",
        default=0.35,
        min=0.0,
        max=1.0,
        precision=3,
        update=_suv_workspace_settings_update,
    )
    smart_standard_hard_surface_angle: bpy.props.FloatProperty(
        name="Hard Surface Angle",
        description="Maximum bend angle allowed before Hard Surface Smart Standard creates additional chart cuts.",
        default=60.0,
        min=1.0,
        max=179.0,
        precision=1,
        update=_suv_workspace_settings_update,
    )
    smart_standard_cut_grooves: bpy.props.BoolProperty(
        name="Cut Grooves",
        description="Create cut hints on inward groove-like folds when their normal angle exceeds the threshold.",
        default=True,
        update=_suv_workspace_settings_update,
    )
    smart_standard_groove_angle: bpy.props.FloatProperty(
        name="Groove Angle",
        description="Angle threshold used by Cut Grooves.",
        default=58.0,
        min=1.0,
        max=179.0,
        precision=1,
        update=_suv_workspace_settings_update,
    )
    smart_standard_cut_ridges: bpy.props.BoolProperty(
        name="Cut Ridges",
        description="Create cut hints on outward ridge-like folds when their normal angle exceeds the threshold.",
        default=True,
        update=_suv_workspace_settings_update,
    )
    smart_standard_ridge_angle: bpy.props.FloatProperty(
        name="Ridge Angle",
        description="Angle threshold used by Cut Ridges.",
        default=58.0,
        min=1.0,
        max=179.0,
        precision=1,
        update=_suv_workspace_settings_update,
    )
    smart_standard_cut_holes: bpy.props.BoolProperty(
        name="Cut Holes",
        description="Detect open holes and add temporary cut hints outward from them so the chart can relax more safely.",
        default=True,
        update=_suv_workspace_settings_update,
    )
    smart_standard_source_channel: bpy.props.IntProperty(
        name="Source Channel",
        description="UV channel index used as source guidance when preserving existing borders.",
        default=1,
        min=1,
        max=32,
        update=_suv_workspace_settings_update,
    )
    smart_standard_target_channel: bpy.props.IntProperty(
        name="Target Channel",
        description="UV channel index where Smart Standard writes or updates UVs.",
        default=1,
        min=1,
        max=32,
        update=_suv_workspace_settings_update,
    )
    smart_standard_pack: bpy.props.BoolProperty(
        name="Pack",
        description="Pack UV islands after Smart Standard unwrap.",
        default=True,
        update=_suv_workspace_settings_update,
    )
    smart_standard_quick_pack: bpy.props.BoolProperty(
        name="Quick Pack",
        description="Repack existing charts quickly after unwrapping without changing the selected unwrap algorithm.",
        default=False,
        update=_suv_workspace_settings_update,
    )
    smart_standard_padding_px: bpy.props.IntProperty(
        name="Padding",
        description="Target island padding in pixels for the Smart Standard pack pass.",
        default=8,
        min=0,
        max=256,
        update=_suv_workspace_settings_update,
    )
    smart_standard_uv_tiles: bpy.props.BoolProperty(
        name="UV Tiles",
        description="Allow Smart Standard packing to use multiple UV tiles when the packer requires extra space.",
        default=False,
        update=_suv_workspace_settings_update,
    )
    smart_standard_tile_count: bpy.props.IntProperty(
        name="Tile Count",
        description="Number of UV tiles available when UV Tiles is enabled.",
        default=1,
        min=1,
        max=64,
        update=_suv_workspace_settings_update,
    )

    smart_standard_keep_seams: bpy.props.BoolProperty(
        name="Keep Seams",
        description="Keeps imported or user-created UV seam intent as the primary chart plan. Additional temporary seams may still be added only when needed to reduce severe stretching. / 既存またはユーザー作成のシームをチャート計画として優先します。強い伸びを抑える必要がある場合のみ一時シームを追加します。",
        default=True,
        update=_suv_workspace_settings_update,
    )
    smart_standard_stretch: bpy.props.FloatProperty(
        name="Stretch",
        description="Allowed UV stretching for Smart Standard. 0 cuts more to avoid stretching; 1 allows more stretching to keep larger charts. / スマート標準で許容するUV伸び量です。0は伸び回避のため細かく切り、1は大きなチャートを保つため伸びを許容します。",
        default=0.35, min=0.0, max=1.0, precision=3, update=_suv_workspace_settings_update,
    )
    smart_standard_cut_grooves: bpy.props.BoolProperty(
        name="Cut Grooves",
        description="Adds temporary seam candidates to recessed or strongly folded groove-like edges. / 溝状または強く折れた辺を一時シーム候補にします。",
        default=True, update=_suv_workspace_settings_update,
    )
    smart_standard_groove_angle: bpy.props.FloatProperty(
        name="Groove Angle",
        description="Angle threshold used by Cut Grooves. Lower values create more seam candidates. / 溝カットの角度しきい値です。低いほどシーム候補が増えます。",
        default=55.0, min=1.0, max=179.0, precision=1, update=_suv_workspace_settings_update,
    )
    smart_standard_cut_ridges: bpy.props.BoolProperty(
        name="Cut Ridges",
        description="Adds temporary seam candidates to raised hard ridge edges. / 盛り上がった硬い稜線を一時シーム候補にします。",
        default=True, update=_suv_workspace_settings_update,
    )
    smart_standard_ridge_angle: bpy.props.FloatProperty(
        name="Ridge Angle",
        description="Angle threshold used by Cut Ridges. Lower values create more seam candidates. / 稜線カットの角度しきい値です。低いほどシーム候補が増えます。",
        default=65.0, min=1.0, max=179.0, precision=1, update=_suv_workspace_settings_update,
    )
    smart_standard_cut_holes: bpy.props.BoolProperty(
        name="Cut Holes",
        description="Uses open borders and holes as UV seam starts so charts can relax outward cleanly. / 開口部や穴の境界を展開起点として使い、チャートを外側へきれいに緩和します。",
        default=True, update=_suv_workspace_settings_update,
    )
    smart_standard_pack_mode: bpy.props.EnumProperty(
        name="Pack Mode",
        description="Pack changes layout and arranges charts; Keep preserves existing chart placement as much as possible after unwrapping. / Packはチャートを配置し直し、Keepは既存配置を可能な限り維持します。",
        items=(('PACK','Pack','Pack generated charts.'),('KEEP','Keep','Keep chart placement as much as possible.')),
        default='PACK', update=_suv_workspace_settings_update,
    )
    smart_standard_pack_quality: bpy.props.EnumProperty(
        name="Packing Quality",
        description="Packing quality/speed tradeoff. Efficient is balanced, High Quality tests more rotations, Turbo is fastest. / パック品質と速度のバランスです。Efficientは標準、High Qualityは回転候補を増やし、Turboは最速です。",
        items=(('EFFICIENT','Efficient','Balanced speed and quality.'),('HIGH','High Quality','More rotation candidates and denser fitting.'),('TURBO','Turbo','Fast conservative packing.')),
        default='HIGH', update=_suv_workspace_settings_update,
    )
    smart_standard_texture_size: bpy.props.IntProperty(
        name="Texture Size",
        description="Texture size reference used to convert pixel padding into UV distance. / ピクセル余白をUV距離へ変換するためのテクスチャサイズ基準です。",
        default=2048, min=128, max=16384, update=_suv_workspace_settings_update,
    )
    smart_standard_padding: bpy.props.FloatProperty(
        name="Padding",
        description="Padding between UV charts in pixels at the selected texture size. / 選択テクスチャサイズ基準のチャート間余白ピクセルです。",
        default=8.0, min=0.0, max=512.0, precision=2, update=_suv_workspace_settings_update,
    )
    smart_standard_pre_rotate: bpy.props.BoolProperty(
        name="Pre-Rotate",
        description="Rotates each chart to a better starting orientation before packing. / パック前に各チャートをより良い初期向きへ回転します。",
        default=True, update=_suv_workspace_settings_update,
    )
    smart_standard_full_rotation: bpy.props.BoolProperty(
        name="Full Rotation",
        description="Allows fine rotation candidates during packing instead of only orthogonal rotation. / 直角回転だけでなく細かい回転候補を許可します。",
        default=True, update=_suv_workspace_settings_update,
    )
    smart_standard_combine: bpy.props.BoolProperty(
        name="Combine",
        description="Combines eligible charts into one packed UV layout for the active operation. / 対象チャートを1つのパック済みUVレイアウトへまとめます。",
        default=True, update=_suv_workspace_settings_update,
    )
    smart_standard_rescale_charts: bpy.props.BoolProperty(
        name="Rescale UV Charts",
        description="Normalizes chart scale before packing to keep texel density consistent. / パック前にチャートスケールを正規化し、テクセル密度を揃えます。",
        default=True, update=_suv_workspace_settings_update,
    )
    smart_standard_texel_density_enable: bpy.props.BoolProperty(
        name="Texel Density",
        description="Uses the target texel-density value when scaling charts before packing. / パック前のチャートスケールに目標テクセル密度を使います。",
        default=False, update=_suv_workspace_settings_update,
    )
    smart_standard_texel_density: bpy.props.FloatProperty(
        name="Density Value",
        description="Target texel density value used when Texel Density is enabled. / Texel Density有効時に使う目標テクセル密度です。",
        default=1024.0, min=1.0, max=65536.0, precision=2, update=_suv_workspace_settings_update,
    )
    smart_standard_tile_uvs: bpy.props.BoolProperty(
        name="Tile UVs",
        description="Packs charts across UV tiles/UDIM-style tiles instead of only the 1001 tile. / 1001タイルだけでなくUVタイル/UDIM風タイルへチャートを分散配置します。",
        default=False, update=_suv_workspace_settings_update,
    )
    smart_standard_tile_columns: bpy.props.IntProperty(
        name="Tile Columns",
        description="Number of tile columns used when Tile UVs is enabled. / Tile UVs有効時のタイル列数です。",
        default=10, min=1, max=32, update=_suv_workspace_settings_update,
    )
    smart_standard_tile_rows: bpy.props.IntProperty(
        name="Tile Rows",
        description="Maximum tile rows used when Tile UVs is enabled. / Tile UVs有効時の最大タイル行数です。",
        default=1, min=1, max=32, update=_suv_workspace_settings_update,
    )
    smart_standard_source_channel: bpy.props.IntProperty(
        name="Source Channel",
        description="Source UV channel index used as the input layout reference. / 入力レイアウト参照として使うソースUVチャンネル番号です。",
        default=0, min=0, max=7, update=_suv_workspace_settings_update,
    )
    smart_standard_target_channel: bpy.props.IntProperty(
        name="Target Channel",
        description="Target UV channel index that receives the generated UV layout. / 生成UVレイアウトを書き込むターゲットUVチャンネル番号です。",
        default=0, min=0, max=7, update=_suv_workspace_settings_update,
    )
    smart_standard_object_scope: bpy.props.EnumProperty(
        name="Objects",
        description="Selects whether the operation is intended for selected meshes or the entire scene. The Blender execution stays scoped to editable selected objects for safety. / 選択メッシュ向けかシーン全体向けかの設定です。Blender実行は安全のため編集対象の選択オブジェクトに限定します。",
        items=(('SELECTED','Selected','Use selected/editable objects.'),('SCENE','Scene','Scene-wide intent; editable selected objects are processed safely.')),
        default='SELECTED', update=_suv_workspace_settings_update,
    )


    smart_standard_unwrap_type: bpy.props.EnumProperty(
        name="Unwrap As",
        description="Smart UV Auto-style output topology for UV chart planning. Polygons keeps polygon charts; Triangles makes safer granular charts for complex topology. / Smart UV Auto系の出力単位です。Polygonsはポリゴンチャートを保持し、Trianglesは複雑形状で安全な細分チャートを作ります。",
        items=(('POLYGONS','Polygons','Keep polygonal charts.'),('TRIANGLES','Triangles','Use granular triangle-safe charts.')),
        default='POLYGONS', update=_suv_workspace_settings_update,
    )
    smart_standard_adjacency_method: bpy.props.EnumProperty(
        name="Adjacency Method",
        description="Controls how neighboring faces are treated while charts are planned. / チャート生成時の隣接面判定方法です。",
        items=(('GEOMETRICAL','Geometrical','Use mesh geometry.'),('POLYGONAL','Polygonal','Use polygon flow.')),
        default='GEOMETRICAL', update=_suv_workspace_settings_update,
    )
    smart_standard_epsilon: bpy.props.FloatProperty(
        name="Epsilon", description="Small tolerance used for chart adjacency and seam decisions. / 隣接判定とシーム判定に使う微小許容値です。",
        default=0.0001, min=0.0, max=1.0, precision=5, update=_suv_workspace_settings_update,
    )
    smart_standard_texture_width: bpy.props.IntProperty(
        name="Texture Width", description="Texture width used by padding and aspect calculations. / 余白とアスペクト計算に使うテクスチャ横幅です。",
        default=2048, min=128, max=16384, update=_suv_workspace_settings_update,
    )
    smart_standard_texture_height: bpy.props.IntProperty(
        name="Texture Height", description="Texture height used by padding and aspect calculations. / 余白とアスペクト計算に使うテクスチャ縦幅です。",
        default=2048, min=128, max=16384, update=_suv_workspace_settings_update,
    )
    smart_standard_aspect_lock: bpy.props.BoolProperty(
        name="Lock Aspect", description="Use Texture Width and Height as an aspect ratio during final fitting. / 最終フィット時にテクスチャ横縦比を使います。",
        default=False, update=_suv_workspace_settings_update,
    )
    smart_standard_aspect: bpy.props.FloatProperty(
        name="Aspect Ratio", description="Manual aspect ratio used when Lock Aspect is enabled. / アスペクトロック時に使う手動比率です。",
        default=1.0, min=0.001, max=1000.0, precision=4, update=_suv_workspace_settings_update,
    )
    smart_standard_high_quality: bpy.props.BoolProperty(
        name="High Quality", description="Use higher iteration counts for unwrap and relaxation. / 展開とリラックスの反復を増やします。",
        default=True, update=_suv_workspace_settings_update,
    )
    smart_standard_preview: bpy.props.BoolProperty(
        name="Preview", description="Preview intent flag for Smart UV Auto-style workflow. In Blender this keeps result metadata updated after unwrap. / Smart UV Auto系のプレビュー意図です。Blenderでは展開後メタデータ更新に使います。",
        default=True, update=_suv_workspace_settings_update,
    )
    smart_standard_show_activity: bpy.props.BoolProperty(
        name="Show Activity", description="Show activity/result intent for the Smart UV Auto-style operation. / Smart UV Auto系処理の進行・結果表示意図です。",
        default=True, update=_suv_workspace_settings_update,
    )
    smart_standard_create_material_ids: bpy.props.BoolProperty(
        name="Create Material IDs", description="Assign generated chart groups to material IDs after unwrap. / 展開後、生成チャートへマテリアルIDを割り当てます。",
        default=False, update=_suv_workspace_settings_update,
    )
    smart_standard_tile_mode: bpy.props.EnumProperty(
        name="UV Tile Mode", description="Smart UV Auto-style distribution mode for multiple UV tiles. / 複数UVタイル使用時の分散方式です。",
        items=(('CHARTS','Distribute by Charts','Distribute charts across tiles.'),('MATERIAL_ID','Distribute by Material ID','Distribute by material IDs.')),
        default='CHARTS', update=_suv_workspace_settings_update,
    )
    smart_standard_max_tiles: bpy.props.IntProperty(
        name="Max Number", description="Maximum number of UV tiles allowed by the Smart UV Auto-style tile packer. / UVタイル分散で許可する最大タイル数です。",
        default=1, min=1, max=64, update=_suv_workspace_settings_update,
    )
    smart_standard_color_background: bpy.props.FloatVectorProperty(
        name="Background Color", description="Preview background color metadata. / プレビュー背景色メタデータです。",
        subtype='COLOR', size=4, min=0.0, max=1.0, default=(0.05,0.05,0.05,1.0), update=_suv_workspace_settings_update,
    )
    smart_standard_color_edge_normal: bpy.props.FloatVectorProperty(
        name="Normal Edges", description="Preview color for normal edges. / 通常エッジのプレビュー色です。",
        subtype='COLOR', size=4, min=0.0, max=1.0, default=(0.55,0.75,1.0,1.0), update=_suv_workspace_settings_update,
    )
    smart_standard_color_edge_false: bpy.props.FloatVectorProperty(
        name="False Edges", description="Preview color for false/problem edges. / 問題エッジのプレビュー色です。",
        subtype='COLOR', size=4, min=0.0, max=1.0, default=(1.0,0.35,0.2,1.0), update=_suv_workspace_settings_update,
    )
    smart_standard_color_seam_old: bpy.props.FloatVectorProperty(
        name="Original Seams", description="Preview color for original seams. / 元シームのプレビュー色です。",
        subtype='COLOR', size=4, min=0.0, max=1.0, default=(1.0,0.8,0.1,1.0), update=_suv_workspace_settings_update,
    )
    smart_standard_color_seam_new: bpy.props.FloatVectorProperty(
        name="New Seams", description="Preview color for newly generated seam candidates. / 新規シーム候補のプレビュー色です。",
        subtype='COLOR', size=4, min=0.0, max=1.0, default=(0.2,1.0,0.35,1.0), update=_suv_workspace_settings_update,
    )

    smart_unwrap_keep_borders: bpy.props.BoolProperty(
        name="Keep Borders",
        description="Preserve existing UV island borders while optimizing the layout. Use this to refine UVs without destroying current island boundaries. / 既存UVアイランド境界を保持しながらレイアウトを最適化します。既存の島境界を崩さず調整したい場合に使います。",
        default=False,
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_use_marks: bpy.props.BoolProperty(
        name="Use Marks",
        description="Use existing marked mesh seams as the primary unwrap guide. Additional cuts are added only when needed to reduce excessive stretching. / 既存のメッシュシームを主な展開ガイドとして使用します。過度な伸びを抑える必要がある場合のみ補助カットを追加します。",
        default=True,
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_stretch_factor: bpy.props.FloatProperty(
        name="Stretch",
        description="Allowed UV stretching for Organic and Mosaic style unwrap. 0 strongly rejects stretching; 1 allows more stretching to keep charts larger. / Organic・Mosaic系展開で許容するUV伸びです。0は伸びを強く拒否し、1は大きなチャート維持のため伸びを許容します。",
        default=0.5,
        min=0.0,
        max=1.0,
        precision=3,
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_hard_surface_angle: bpy.props.FloatProperty(
        name="Hard Surface Angle",
        description="Maximum bend angle allowed inside a hard-surface chart. Smaller values create more charts with less stretching; larger values keep broader hard surfaces together. / ハードサーフェスチャート内で許容する最大折れ角度です。小さい値ほど伸びを抑えてチャート数が増え、大きい値ほど広い硬質面をまとめます。",
        default=60.0,
        min=1.0,
        max=179.0,
        precision=1,
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_cut_grooves: bpy.props.BoolProperty(
        name="Cut Grooves",
        description="Automatically add temporary seams to recessed groove-like edges detected from face-normal changes. / 面法線変化から検出した溝状エッジへ一時シームを自動追加します。",
        default=True,
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_cut_ridges: bpy.props.BoolProperty(
        name="Cut Ridges",
        description="Automatically add temporary seams to raised ridge-like edges detected from face-normal changes. / 面法線変化から検出した稜線状エッジへ一時シームを自動追加します。",
        default=True,
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_cut_holes: bpy.props.BoolProperty(
        name="Cut Holes",
        description="Detect open holes and add cut paths that help the surrounding chart relax cleanly. / 開口部を検出し、その周辺チャートを自然に緩和しやすくするカット経路を追加します。",
        default=True,
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_combine: bpy.props.BoolProperty(
        name="Combine",
        description="Pack selected objects or charts together into one shared UV space when the surrounding workflow supports multi-object processing. / 複数オブジェクトまたはチャートを共有UV空間へまとめてパックします。",
        default=True,
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_selection_only: bpy.props.BoolProperty(
        name="Selection",
        description="Process only selected faces or selected objects. When disabled and nothing is selected, the active mesh is processed as a whole. / 選択面または選択オブジェクトのみ処理します。無効で選択がない場合はアクティブメッシュ全体を処理します。",
        default=True,
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_pack_mode: bpy.props.EnumProperty(
        name="Pack Mode",
        description="Choose whether Smart unwrap packs the result or keeps the existing chart layout after unwrapping. / スマート展開後にパックするか、既存チャート配置を維持するかを選びます。",
        items=(
            ('PACK', 'Pack', 'Unwrap and pack charts into the UV canvas.'),
            ('KEEP', 'Keep', 'Keep existing UV chart placement as much as possible after unwrapping.'),
        ),
        default='PACK',
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_source_channel: bpy.props.IntProperty(
        name="Source Channel",
        description="UV channel index used as the source when preserving or copying existing UV data. Blender stores these as UV map slots. / 既存UVを保持・コピーする際のソースUVチャンネル番号です。BlenderではUVマップスロットとして扱います。",
        default=0,
        min=0,
        max=99,
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_target_channel: bpy.props.IntProperty(
        name="Target Channel",
        description="UV channel index where the generated unwrap is stored when channel routing is used. / チャンネル経路を使う場合に生成UVを格納するターゲットUVチャンネル番号です。",
        default=0,
        min=0,
        max=99,
        update=_suv_workspace_settings_update,
    )
    smart_pack_texture_size: bpy.props.IntProperty(
        name="Texture Size",
        description="Reference texture size for converting pixel padding and texel-density values into UV distances. / ピクセル余白やテクセル密度をUV距離へ変換する基準テクスチャサイズです。",
        default=2048,
        min=128,
        max=65536,
        update=_suv_workspace_settings_update,
    )
    smart_pack_padding_px: bpy.props.IntProperty(
        name="Padding",
        description="Padding between UV charts in pixels relative to Texture Size. / Texture Sizeを基準にしたUVチャート間のピクセル余白です。",
        default=8,
        min=0,
        max=512,
        update=_suv_workspace_settings_update,
    )
    smart_pack_pre_rotate: bpy.props.BoolProperty(
        name="Pre-Rotate",
        description="Rotate each chart to an efficient starting orientation before packing. / パック前に各チャートを効率のよい初期向きへ回転します。",
        default=True,
        update=_suv_workspace_settings_update,
    )
    smart_pack_rescale_charts: bpy.props.BoolProperty(
        name="Rescale UV Charts",
        description="Rescale charts based on covered mesh area to improve consistent pixel distribution. / メッシュ面積に基づいてチャートを再スケールし、ピクセル分布を均一化します。",
        default=True,
        update=_suv_workspace_settings_update,
    )
    smart_pack_texel_density: bpy.props.FloatProperty(
        name="Texel Density",
        description="Target texel-density reference used by Smart UV packing and density-aware scaling. / スマートUVパックと密度考慮スケールで使う目標テクセル密度です。",
        default=1024.0,
        min=1.0,
        max=65536.0,
        precision=2,
        update=_suv_workspace_settings_update,
    )
    smart_pack_full_rotation: bpy.props.BoolProperty(
        name="Full Rotation",
        description="Allow full-circle rotation candidates during high-quality packing. This can improve fit but costs more time. / 高品質パック中に全周回転候補を許可します。収まりが改善する場合がありますが処理時間は増えます。",
        default=False,
        update=_suv_workspace_settings_update,
    )

    smart_unwrap_auto_cut_mode: bpy.props.EnumProperty(
        name="Auto Cut Mode",
        description="Controls how strongly Smart may create temporary seams. Preserve keeps a no-seam mesh connected. Conservative, Balanced and Aggressive progressively allow more automatic splitting.",
        items=(
            ('PRESERVE', 'Preserve', 'Keep user seam structure. No extra cuts are added.'),
            ('CONSERVATIVE', 'Conservative', 'Add only safer temporary cuts.'),
            ('BALANCED', 'Balanced', 'Use balanced production cuts.'),
            ('AGGRESSIVE', 'Aggressive', 'Allow stronger cleanup cuts for difficult topology.'),
        ),
        default='BALANCED',
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_solver: bpy.props.EnumProperty(
        name="Solver",
        description="Unwrap solver used by Smart. Angle Based favors mixed hard/organic production meshes. Conformal favors smooth organic forms.",
        items=(
            ('ANGLE_BASED', 'Angle Based', 'General-purpose Blender unwrap solver.'),
            ('CONFORMAL', 'Conformal', 'Conformal unwrap solver for smoother organic forms.'),
        ),
        default='ANGLE_BASED',
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_align_mode: bpy.props.EnumProperty(
        name="Island Align",
        description="Post-unwrap island alignment. None leaves the result untouched. Center recenters islands. Bounding Box orients islands for readability. Pack also runs packing.",
        items=(
            ('NONE', 'None', 'Do not align islands after unwrap.'),
            ('CENTER', 'Center', 'Center selected islands after unwrap.'),
            ('BBOX', 'Bounding Box', 'Orient islands by bounding box for readable layout.'),
            ('PACK', 'Pack', 'Orient and pack islands after unwrap.'),
        ),
        default='PACK',
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_preserve_no_seam_connected: bpy.props.BoolProperty(
        name="Keep No-Seam Connected",
        description="When enabled, Smart keeps meshes without user seams as one connected unwrap base unless Auto Cut Mode or a preset explicitly allows temporary cuts.",
        default=False,
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_angle_threshold: bpy.props.FloatProperty(
        name="Fold Angle",
        description="Angle threshold in degrees for temporary Smart cuts. Lower values split more hard folds. Higher values keep the mesh connected longer.",
        default=60.0,
        min=1.0,
        max=179.0,
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_pull_distance: bpy.props.FloatProperty(
        name="Strength",
        description="Visible Strength for the Circle Smart shape. 0.5 matches the former maximum strength; values above 0.5 use an overdrive range.",
        default=0.5,
        min=0.0,
        max=1.0,
        precision=3,
        update=_suv_smart_realtime_update,
    )
    smart_unwrap_split_tolerance: bpy.props.FloatProperty(
        name="Strength",
        description="Visible Strength for the Standard Smart shape. 0.5 matches the former maximum strength; values above 0.5 use an overdrive range while keeping no-seam meshes connected.",
        default=0.5,
        min=0.0,
        max=1.0,
        precision=3,
        update=_suv_smart_realtime_update,
    )
    smart_unwrap_orientation_angle: bpy.props.FloatProperty(
        name="Orientation",
        description="Manual Smart unwrap direction in degrees. Square reflows the outline to the four UV canvas sides after the angle changes. Standard rotates each island individually and refreshes packing to the canvas.",
        default=0.0,
        min=0.0,
        max=360.0,
        precision=1,
        update=_suv_smart_realtime_update,
    )
    smart_unwrap_curvature_sensitivity: bpy.props.FloatProperty(
        name="Curvature",
        description="Curvature sensitivity for Smart temporary cuts. Higher values allow more cuts across bent areas; lower values keep organic shapes connected.",
        default=0.52,
        min=0.0,
        max=1.0,
        precision=3,
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_planarity_tolerance: bpy.props.FloatProperty(
        name="Planarity",
        description="Planarity tolerance used by aggressive cleanup. Lower values treat small normal changes as split candidates; higher values preserve broad surfaces.",
        default=0.05,
        min=0.0,
        max=1.0,
        precision=3,
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_sliver_ratio: bpy.props.FloatProperty(
        name="Sliver Ratio",
        description="Thin-face detection threshold. Higher values let Smart isolate thin stressed faces; zero disables this condition.",
        default=0.018,
        min=0.0,
        max=0.5,
        precision=4,
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_island_margin: bpy.props.FloatProperty(
        name="Island Margin",
        description="UV margin used by Smart unwrap and optional packing. Use larger values for bake or lightmap workflows.",
        default=0.014,
        min=0.0,
        max=0.2,
        precision=4,
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_relax_iterations: bpy.props.IntProperty(
        name="Relax Iterations",
        description="Number of stretch-minimization iterations after Smart unwrap. Zero disables Smart-only relax unless Relax After is enabled.",
        default=24,
        min=0,
        max=96,
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_cut_sharp_edges: bpy.props.BoolProperty(name="Sharp Edges", description="Allow Smart to use mesh sharp edges as temporary cut candidates.", default=True, update=_suv_workspace_settings_update)
    smart_unwrap_cut_boundary_edges: bpy.props.BoolProperty(name="Boundary", description="Allow Smart to use open boundary edges as temporary cut candidates.", default=True, update=_suv_workspace_settings_update)
    smart_unwrap_cut_nonmanifold_edges: bpy.props.BoolProperty(name="Non-Manifold", description="Allow Smart to use non-manifold edges as temporary cut candidates.", default=True, update=_suv_workspace_settings_update)
    smart_unwrap_cut_material_edges: bpy.props.BoolProperty(name="Material Border", description="Allow Smart to split across material-index borders.", default=False, update=_suv_workspace_settings_update)
    smart_unwrap_cut_uv_discontinuity: bpy.props.BoolProperty(name="UV Discontinuity", description="Allow Smart to consider existing UV/material discontinuity hints while building temporary cuts.", default=True, update=_suv_workspace_settings_update)
    smart_unwrap_average_scale: bpy.props.BoolProperty(name="Average Scale", description="Run average island scale after Smart unwrap so islands are more consistent before layout.", default=True, update=_suv_workspace_settings_update)
    smart_unwrap_pack_after: bpy.props.BoolProperty(name="Pack After Smart", description="Run packing after Smart unwrap regardless of the general Pack After toggle.", default=True, update=_suv_workspace_settings_update)
    smart_unwrap_peel_iterations: bpy.props.IntProperty(
        name="Peel Iterations",
        description="Number of connected peel spring-relaxation passes used when Smart keeps a no-seam mesh connected. Higher values preserve edge length more accurately but cost more time.",
        default=224,
        min=0,
        max=256,
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_spring_strength: bpy.props.FloatProperty(
        name="Strength",
        description="Visible Strength for the Square Smart shape. 0.5 matches the former maximum strength; values above 0.5 use an overdrive range.",
        default=0.5,
        min=0.0,
        max=1.0,
        precision=3,
        update=_suv_smart_realtime_update,
    )
    smart_unwrap_boundary_weight: bpy.props.FloatProperty(
        name="Boundary Weight",
        description="How strongly open boundary vertices resist spring movement during connected Smart peel. Use higher values to keep open cloth or panels stable.",
        default=0.35,
        min=0.0,
        max=10.0,
        precision=3,
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_area_weight: bpy.props.FloatProperty(
        name="Area Weight",
        description="Balances face-area preservation during connected Smart peel. Higher values protect large faces from being compressed by small dense topology.",
        default=0.85,
        min=0.0,
        max=2.0,
        precision=3,
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_overlap_push: bpy.props.FloatProperty(
        name="Overlap Push",
        description="Small repulsion amount used by connected Smart peel to separate very close UV vertices after edge-length relaxation. Set to zero for the most literal connected peel.",
        default=0.220,
        min=0.0,
        max=0.5,
        precision=4,
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_chart_spread: bpy.props.FloatProperty(
        name="Peel Spread",
        description="Extra spacing multiplier used when Smart tests peel chart candidates. Higher values spread difficult closed surfaces more aggressively before final overlap checking.",
        default=4.00,
        min=0.25,
        max=16.0,
        precision=3,
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_overlap_resolve_passes: bpy.props.IntProperty(
        name="Overlap Passes",
        description="Maximum number of local overlap-resolve passes used by Smart before it falls back to deterministic non-overlap face packing. Higher values are slower but safer.",
        default=96,
        min=0,
        max=256,
        update=_suv_workspace_settings_update,
    )
    smart_unwrap_overlap_policy: bpy.props.EnumProperty(
        name="Overlap Policy",
        description="Controls how Smart resolves risky connected layouts. Prevent Overlap uses temporary peel-tree cuts and overlap checking; Strict Connected keeps every shared vertex connected even when overlap may remain; Pack Split allows stronger separation for difficult meshes.",
        items=(
            ('PREVENT', 'Prevent Overlap', 'Use temporary peel-tree cuts, overlap checks and fallback packing to prevent UV face overlap.'),
            ('ALLOW_CONNECTED', 'Strict Connected', 'Keep every shared vertex connected. Use only when connection is more important than avoiding overlap.'),
            ('PACK_SPLIT', 'Pack Split', 'Allow stronger temporary splitting and packing for difficult meshes that cannot be embedded cleanly as one chart.'),
        ),
        default='PREVENT',
        update=_suv_workspace_settings_update,
    )

    auto_unwrap_preset: bpy.props.EnumProperty(
        name="Auto Preset",
        description="Preset for the high-quality Auto unwrap route. Selecting an item immediately applies its numeric settings; run the single unwrap button afterward.",
        items=(
            ('AUTO_BALANCED', 'Balanced Auto', 'General production-friendly automatic unwrap.'),
            ('AUTO_HARD_SURFACE', 'Hard Surface Auto', 'Sharper fold cuts and compact packing for mechanical forms.'),
            ('AUTO_ORGANIC', 'Organic Auto', 'Smoother conformal unwrap with conservative cuts and stronger relax.'),
            ('AUTO_GAME_ASSET', 'Game Asset Auto', 'Compact real-time asset unwrap with scale normalization and packing.'),
            ('AUTO_LIGHTMAP', 'Lightmap Auto', 'Higher spacing and safer layout for secondary UVs.'),
            ('AUTO_SCAN', 'Scan Cleanup Auto', 'Aggressive cleanup for noisy scans and uneven topology.'),
            ('AUTO_CYLINDER', 'Cylinder/Pipe Auto', 'Tube-like objects with a controlled length seam.'),
            ('AUTO_CLOTH', 'Cloth/Open Surface Auto', 'Open surfaces with boundary stability and reduced fragmentation.'),
        ),
        default='AUTO_BALANCED',
        update=_suv_auto_unwrap_preset_update,
    )
    auto_unwrap_quality: bpy.props.IntProperty(name="Auto Quality", description="Overall Auto quality level. Higher values increase relax/cleanup passes and favor more careful cut decisions.", default=4, min=1, max=5, update=_suv_workspace_settings_update)
    auto_unwrap_angle_threshold: bpy.props.FloatProperty(name="Auto Fold Angle", description="Fold-angle threshold for Auto temporary seams. Lower values create more islands; higher values keep broader surfaces together.", default=58.0, min=1.0, max=179.0, update=_suv_workspace_settings_update)
    auto_unwrap_curvature_sensitivity: bpy.props.FloatProperty(name="Auto Curvature", description="Curvature sensitivity for Auto seam detection. Higher values split difficult bends more readily.", default=0.58, min=0.0, max=1.0, precision=3, update=_suv_workspace_settings_update)
    auto_unwrap_pull_distance: bpy.props.FloatProperty(name="Auto Pull Distance", description="Normalized long-edge and stretch hint for Auto seam placement. Zero disables this condition.", default=0.12, min=0.0, max=1.0, precision=3, update=_suv_workspace_settings_update)
    auto_unwrap_island_margin: bpy.props.FloatProperty(name="Auto Margin", description="UV island spacing used by Auto unwrap and Auto pack.", default=0.014, min=0.0, max=0.2, precision=4, update=_suv_workspace_settings_update)
    auto_unwrap_relax_iterations: bpy.props.IntProperty(name="Auto Relax", description="Stretch-minimization iterations after Auto unwrap. Values are capped to keep the run time practical.", default=18, min=0, max=96, update=_suv_workspace_settings_update)
    auto_unwrap_pack_after: bpy.props.BoolProperty(name="Auto Pack", description="Pack islands after Auto unwrap.", default=True, update=_suv_workspace_settings_update)

    flat_mapping_angle_threshold: bpy.props.FloatProperty(name="Flat Angle", description="Face-normal angle threshold for Flatten Mapping. Lower values create more clusters; higher values keep more faces in the same cluster.", default=45.0, min=1.0, max=179.0, update=_suv_workspace_settings_update)
    flat_mapping_spacing: bpy.props.FloatProperty(name="Flat Spacing", description="Spacing between Flatten Mapping clusters inside the UV tile.", default=0.018, min=0.0, max=0.2, precision=4, update=_suv_workspace_settings_update)
    flat_mapping_area_weight: bpy.props.FloatProperty(name="Flat Area Weight", description="Area weighting hint for Flatten Mapping normalization and packing. Higher values protect large faces from becoming too small.", default=0.70, min=0.0, max=2.0, precision=3, update=_suv_workspace_settings_update)
    flat_mapping_pack_after: bpy.props.BoolProperty(name="Flat Pack", description="Pack and average scale after Flatten Mapping.", default=True, update=_suv_workspace_settings_update)

    projection_gizmo_use: bpy.props.BoolProperty(name="Use UVW Gizmo", description="Use a 3D viewport Empty object as the projection gizmo for Planar, Box, Cylindrical, Spherical and View projection modes. Move, rotate or scale the gizmo in the viewport to change the mapping basis.", default=True, update=_suv_workspace_settings_update)
    projection_gizmo_object_name: bpy.props.StringProperty(name="Gizmo Object", description="Name of the Empty object used as the projection gizmo. Create or reset it from the projection gizmo buttons.", default="Smart UV Projection Gizmo", update=_suv_workspace_settings_update)
    projection_gizmo_normalize: bpy.props.BoolProperty(name="Normalize Gizmo UV", description="Normalize projection coordinates into the 0-1 tile after using the gizmo. Disable it to let the gizmo scale work like a UVW Map modifier.", default=False, update=_suv_workspace_settings_update)
    projection_gizmo_tile_scale: bpy.props.FloatProperty(name="Tile Scale", description="Additional UV scale multiplier for projection-gizmo coordinates. Values above 1 tile the projection; values below 1 enlarge it.", default=1.0, min=0.001, max=100.0, precision=3, update=_suv_workspace_settings_update)
    projection_gizmo_cylinder_offset: bpy.props.FloatProperty(name="Seam Offset", description="Angular seam offset in degrees for cylindrical and spherical gizmo projection.", default=0.0, min=-360.0, max=360.0, update=_suv_workspace_settings_update)


    export_uv_layout_format: bpy.props.EnumProperty(
        name="Layout Format",
        description="File format for UV layout export. SVG and EPS are vector formats; JSON and CSV expose detailed UV records for other tools. / UV配置エクスポート形式です。SVG/EPSはベクター形式、JSON/CSVは他ツール向けの詳細UVデータです。",
        items=(
            ('SVG', 'SVG', 'Vector outline and optional face fills.'),
            ('EPS', 'EPS', 'PostScript vector outline.'),
            ('PNG', 'PNG', 'Bitmap image for paint guides and screenshots.'),
            ('JSON', 'JSON', 'Structured UV data for tools and scripts.'),
            ('CSV', 'CSV', 'Spreadsheet-friendly UV coordinate records.'),
        ),
        default='SVG',
        update=_suv_workspace_settings_update,
    )
    export_uv_layout_profile: bpy.props.EnumProperty(
        name="Export Profile",
        description="Preset intent for UV layout export. It is written to data exports and helps choose which elements to enable. / UV配置エクスポートの用途プロファイルです。データ出力へ記録され、必要な要素選択の目安になります。",
        items=(
            ('GENERAL', 'General', 'General UV review.'),
            ('TEXTURE_PAINT', 'Texture Paint', 'Texture painting and mask reference.'),
            ('UDIM_REVIEW', 'UDIM Review', 'Multi-tile or UDIM checking.'),
            ('GAME_ENGINE', 'Game Engine', 'Game-engine import review.'),
            ('DEBUG_DATA', 'Debug Data', 'Maximum coordinate/detail export.'),
        ),
        default='GENERAL',
        update=_suv_workspace_settings_update,
    )
    export_uv_layout_scope: bpy.props.EnumProperty(
        name="Export Scope",
        description="Choose whether to export every UV face or only selected faces. / 全UV面を書き出すか、選択面だけを書き出すかを選びます。",
        items=(('SELECTED', 'Selected', 'Selected faces only.'), ('ALL', 'All', 'All UV faces.')),
        default='ALL',
        update=_suv_workspace_settings_update,
    )
    export_uv_layout_tiles: bpy.props.EnumProperty(
        name="Tile Naming",
        description="Choose single-tile export or per-tile naming using UDIM or UV tile conventions. / 単一タイル書き出し、UDIM番号、UVタイル名のどれで出力するかを選びます。",
        items=(('NONE', 'Single 0-1 Tile', 'Export only the base tile.'), ('UDIM', 'UDIM', 'Use 1001-style tile suffixes.'), ('UV', 'UV Tile', 'Use u1_v1-style suffixes.')),
        default='NONE',
        update=_suv_workspace_settings_update,
    )
    export_uv_layout_width: bpy.props.IntProperty(
        name="Export Width",
        description="Width of SVG/EPS canvas or reference size for data exports. / SVG/EPSのキャンバス幅、またはデータ出力の基準幅です。",
        default=2048, min=8, max=32768, update=_suv_workspace_settings_update,
    )
    export_uv_layout_height: bpy.props.IntProperty(
        name="Export Height",
        description="Height of SVG/EPS canvas or reference size for data exports. / SVG/EPSのキャンバス高さ、またはデータ出力の基準高さです。",
        default=2048, min=8, max=32768, update=_suv_workspace_settings_update,
    )
    export_uv_layout_opacity: bpy.props.FloatProperty(
        name="Face Opacity",
        description="Opacity for exported face fills. Set 0 to output outlines only. / 書き出す面塗りの不透明度です。0にすると輪郭だけを書き出します。",
        default=0.25, min=0.0, max=1.0, update=_suv_workspace_settings_update,
    )
    export_uv_layout_modified: bpy.props.BoolProperty(
        name="Use Modified Mesh",
        description="Export UVs from the evaluated mesh after modifiers where available. / 可能な場合、モディファイア評価後メッシュからUVを書き出します。",
        default=False, update=_suv_workspace_settings_update,
    )
    export_uv_layout_faces: bpy.props.BoolProperty(name="Faces", description="Export UV face polygons and optional face fills. / UV面ポリゴンと面塗りを書き出します。", default=True, update=_suv_workspace_settings_update)
    export_uv_layout_edges: bpy.props.BoolProperty(name="Edges", description="Export UV edge outlines. / UVエッジ輪郭を書き出します。", default=True, update=_suv_workspace_settings_update)
    export_uv_layout_vertices: bpy.props.BoolProperty(name="Vertices", description="Export UV vertex points. / UV頂点点を書き出します。", default=False, update=_suv_workspace_settings_update)
    export_uv_layout_islands: bpy.props.BoolProperty(name="Islands", description="Include an island index for data exports and grouped review. / データ出力とグループ確認用にアイランド番号を含めます。", default=True, update=_suv_workspace_settings_update)
    export_uv_layout_materials: bpy.props.BoolProperty(name="Materials", description="Export material names and material colors where available. / 利用可能なマテリアル名と色を書き出します。", default=True, update=_suv_workspace_settings_update)
    export_uv_layout_grid: bpy.props.BoolProperty(name="Guide Grid", description="Export the visible UV guide grid as reference lines. / UVガイドグリッドを参照線として書き出します。", default=True, update=_suv_workspace_settings_update)
    export_uv_layout_tile_labels: bpy.props.BoolProperty(name="Tile Labels", description="Export UDIM or UV tile labels when tiled export is enabled. / タイル書き出し時にUDIMまたはUVタイル名を含めます。", default=True, update=_suv_workspace_settings_update)

    smart_quality_profile: bpy.props.EnumProperty(
        name="Quality Profile",
        description='Saved UV Suite Cockpit quality profile. It controls density, padding, tolerance and precision defaults / UV Suiteコックピットの品質プロファイルです。密度、余白、許容差、精度既定値をまとめて制御します',
        items=[
            ('PRODUCTION', "Production", "Balanced production default / 制作標準"),
            ('HERO', "Hero", "High density close-up asset / 高密度の主役アセット"),
            ('HARD_SURFACE', "Hard Surface", "Orthogonal hard-surface and trim workflow / ハードサーフェスとトリム向け"),
            ('ORGANIC', "Organic", "Relax-heavy organic unwrap workflow / リラックス重視の有機形状向け"),
            ('LIGHTMAP', "Lightmap", "Wide-padding no-overlap lightmap workflow / 広い余白のライトマップ向け"),
            ('UDIM', "UDIM", "Multi-tile grouped workflow / 複数タイルのグループ配置向け"),
            ('TRIM', "Trim", "Trim sheet and hotspot reuse workflow / トリムシートとホットスポット再利用向け"),
        ],
        default='HERO',
        update=_suv_workspace_settings_update,
    )
    smart_precision_level: bpy.props.EnumProperty(
        name="Precision Level",
        description='How aggressively UV Suite Cockpit invests extra passes in unwrap, relax, density and pack / UV Suiteコックピットが展開、リラックス、密度、パックへ追加パスをどれだけ投入するか',
        items=[
            ('SAFE', "Safe", "Preserve existing layout as much as possible / 既存レイアウトをなるべく保持"),
            ('ULTRA', "Ultra", "Balanced high precision / 高精度標準"),
            ('EXTREME', "Extreme", "Maximum local precision passes / ローカル最高精度パス"),
        ],
        default='EXTREME',
        update=_suv_workspace_settings_update,
    )
    smart_relax_iterations: bpy.props.IntProperty(
        name="Relax Iterations",
        description="Iteration budget for precision relax and minimize-stretch fallback passes / 精密リラックスと歪み最小化フォールバックの反復回数",
        default=96, min=0, max=512,
        update=_suv_workspace_settings_update,
    )
    smart_pack_candidates: bpy.props.IntProperty(
        name="Pack Candidates",
        description="Number of deterministic pack candidates attempted by precision routes where supported / 対応ルートで試行する決定論的パック候補数",
        default=4, min=1, max=12,
        update=_suv_workspace_settings_update,
    )
    smart_margin_strategy: bpy.props.EnumProperty(
        name="Margin Strategy",
        description="How cockpit profiles interpret padding during final layout / コックピットプロファイルが最終配置の余白をどう扱うか",
        items=[
            ('BALANCED', "Balanced", "Use the saved padding directly / 保存余白をそのまま使います"),
            ('BAKE_SAFE', "Bake Safe", "Use a wider safe padding / ベイク向けに広めの安全余白"),
            ('DENSE', "Dense", "Use tighter spacing for texture efficiency / テクスチャ効率優先で詰めます"),
        ],
        default='BALANCED',
        update=_suv_workspace_settings_update,
    )
    smart_lock_overlaps: bpy.props.BoolProperty(
        name="Lock Reuse/Overlap",
        description="Preserve intentional overlap or reuse groups when possible / 意図した重なりや再利用グループを可能な範囲で保持します",
        default=False,
        update=_suv_workspace_settings_update,
    )
    smart_sliver_protection: bpy.props.BoolProperty(
        name="Sliver Protection",
        description="Prefer safer repair and inspection paths for tiny or thin UV islands / 極小・細長いUVアイランドに対して安全な修復・検査ルートを優先します",
        default=True,
        update=_suv_workspace_settings_update,
    )
    smart_ui_density: bpy.props.EnumProperty(
        name="Cockpit UI Density",
        description='Choose how compact the UV Suite Cockpit button board is / UV Suiteコックピットのボタン密度を選びます',
        items=[('COMPACT', "Compact", "Compact board / コンパクト"), ('COMFORT', "Comfort", "Larger click targets / 押しやすい大きめ")],
        default='COMFORT',
        update=_suv_workspace_settings_update,
    )
    smart_last_score: bpy.props.FloatProperty(name="Last UV Score", description='Last UV Suite Cockpit quality score / 直近のUV Suite品質スコア', default=0.0, min=0.0, max=100.0, update=_suv_workspace_settings_update)
    smart_last_grade: bpy.props.StringProperty(name="Last UV Grade", description='Last UV Suite Cockpit quality grade / 直近のUV Suite品質グレード', default="N/A", update=_suv_workspace_settings_update)
    smart_last_action: bpy.props.StringProperty(name="Last Cockpit Action", description='Last UV Suite Cockpit route / 直近のUV Suiteコックピットルート', default="", update=_suv_workspace_settings_update)
    smart_last_report_time: bpy.props.StringProperty(name="Last Cockpit Report", description='Last UV Suite Cockpit report time / 直近のUV Suiteコックピットレポート時刻', default="", update=_suv_workspace_settings_update)

    pack_group_mode: bpy.props.EnumProperty(
        name="Pack Group Mode",
        description="Choose how group-based layout tools cluster islands before moving them into tiles / グループ配置ツールがアイランドをどうまとめるかを選びます",
        items=[
            ('MATERIAL', "Material", "Group by dominant material slot / 主マテリアルスロットごとにまとめます"),
            ('SIMILAR', "Similar", "Group by approximate area/aspect similarity / 面積と縦横比の近さでまとめます"),
            ('IDENTICAL', "Identical", "Group only near-identical island shapes / ほぼ同一形状だけをまとめます"),
        ],
        default='SIMILAR',
    update=_suv_workspace_settings_update,)
    pack_group_layout: bpy.props.EnumProperty(
        name="グループ配置",
        description="グループパック時に、グループ同士を1タイル内へまとめるか、行・列・別タイルに分けて配置するかを選びます。",
        items=[
            ('SINGLE_TILE', "単一タイル", "全グループを現在のタイル内にまとめて配置します。通常のグループ整理に使います。"),
            ('ROWS', "行で分ける", "グループごとに横長の行を割り当て、1タイル内で見分けやすく配置します。"),
            ('COLUMNS', "列で分ける", "グループごとに縦長の列を割り当て、1タイル内で見分けやすく配置します。"),
            ('TILES', "グループ別タイル", "グループごとに別UDIMタイルへ送ります。素材別・用途別に島を分けたい場合に使います。"),
        ],
        default='SINGLE_TILE',
    update=_suv_workspace_settings_update,)
    stack_group_mode: bpy.props.EnumProperty(
        name="Stack Group Mode",
        description="Choose how grouped stack tools find compatible islands / グループスタックが互換アイランドをどう見つけるかを選びます",
        items=[
            ('SIMILAR', "Similar", "Stack approximate matches / おおよそ近い形を重ねます"),
            ('IDENTICAL', "Identical", "Stack only near-identical matches / ほぼ同一形状のみ重ねます"),
        ],
        default='SIMILAR',
    update=_suv_workspace_settings_update,)
    similarity_area_tol: bpy.props.FloatProperty(
        name="Area Tolerance",
        description="How much island area can differ and still be treated as a match / どの程度の面積差を同系統とみなすか",
        default=0.05,
        min=0.0,
        max=1.0,
        subtype='FACTOR',
    update=_suv_workspace_settings_update,)
    similarity_aspect_tol: bpy.props.FloatProperty(
        name="Aspect Tolerance",
        description="How much island aspect ratio can differ and still be treated as a match / どの程度の縦横比差を同系統とみなすか",
        default=0.15,
        min=0.0,
        max=1.0,
        subtype='FACTOR',
    update=_suv_workspace_settings_update,)
    stretch_threshold: bpy.props.FloatProperty(
        name="Stretch Threshold",
        description="Warn when an island's internal density spread exceeds this ratio / アイランド内の密度ばらつき比率がこの値を超えたら警告します",
        default=1.8,
        min=1.01,
        max=100.0,
    update=_suv_workspace_settings_update,)
    scan_report_name: bpy.props.StringProperty(
        name="Report Text",
        description="Text datablock name used when writing inspector reports / 検査レポート出力時に使うテキストデータ名",
        default="SUV_Scan_Report",
    update=_suv_workspace_settings_update,)
    heatmap_max: bpy.props.FloatProperty(
        name="Heatmap Max",
        description="Maximum stretch value mapped to the red end of the heatmap / ヒートマップで赤へ割り当てる最大ストレッチ値",
        default=4.0,
        min=1.1,
        max=100.0,
    update=_suv_workspace_settings_update,)
    heatmap_attr_name: bpy.props.StringProperty(
        name="Heatmap Attribute",
        description="Color attribute name used for the stretch heatmap / ストレッチヒートマップ用のカラー属性名",
        default="SUV_StretchHeat",
    update=_suv_workspace_settings_update,)
    heatmap_material_name: bpy.props.StringProperty(
        name="Heatmap Material",
        description="Material name used to preview the stretch heatmap / ストレッチヒートマップ表示に使うマテリアル名",
        default="SUV_StretchHeat",
    update=_suv_workspace_settings_update,)
    hotspot_cols: bpy.props.IntProperty(
        name="Columns",
        description="Number of columns for hotspot cell layout / ホットスポット配置の列数",
        default=4,
        min=1,
        max=64,
    update=_suv_workspace_settings_update,)
    hotspot_rows: bpy.props.IntProperty(
        name="Rows",
        description="Number of rows for hotspot cell layout / ホットスポット配置の行数",
        default=4,
        min=1,
        max=64,
    update=_suv_workspace_settings_update,)
    hotspot_keep_aspect: bpy.props.BoolProperty(
        name="Keep Aspect",
        description="Preserve each island's aspect ratio inside the hotspot cell / 各アイランドの縦横比を保ったままセルへ収めます",
        default=True,
    update=_suv_workspace_settings_update,)
    hotspot_sort: bpy.props.EnumProperty(
        name="Sort",
        description="Choose how islands are ordered before filling hotspot cells / ホットスポットセルへ配置する前の並び順を選びます",
        items=[
            ('AREA', "Area", "Fill cells from largest to smallest island / 大きいアイランドから順に配置します"),
            ('WIDTH', "Width", "Fill cells from wider islands first / 横長のアイランドから順に配置します"),
            ('HEIGHT', "Height", "Fill cells from taller islands first / 縦長のアイランドから順に配置します"),
        ],
        default='AREA',
    update=_suv_workspace_settings_update,)
    hotspot_fill_order: bpy.props.EnumProperty(
        name="Fill Order",
        description="Choose whether hotspot cells fill row by row or column by column / ホットスポットセルを行方向で埋めるか列方向で埋めるかを選びます",
        items=[
            ('ROW', "Row Major", "Fill left to right, then continue on the next row / 左から右へ並べ、次の行へ進みます"),
            ('COLUMN', "Column Major", "Fill top to bottom, then continue on the next column / 上から下へ並べ、次の列へ進みます"),
        ],
        default='ROW',
    update=_suv_workspace_settings_update,)

    uv_chain_group_mode: bpy.props.EnumProperty(
        name="Align Scope",
        description="Treat disconnected UV selections separately or as one combined set / 分断されたUV選択を個別に扱うか、まとめて扱うかを切り替えます",
        items=[
            ('SEPARATE', "Per Connected Group", "Align each disconnected UV chain / 分断されたUVチェーンごとに整列します"),
            ('COMBINED', "Combine All", "Treat all selected UVs as one set / 選択UV全体を1つの集合として整列します"),
        ],
        default='SEPARATE',
    update=_suv_workspace_settings_update,)
    uv_chain_axis_mode: bpy.props.EnumProperty(
        name="Axis Basis",
        description="Choose how line and flow tools determine their main axis / ライン系・フロー系ツールの基準軸を選択します",
        items=[
            ('AUTO', "Auto", "Use the current end-to-end direction / 現在の端点方向を優先します"),
            ('BEST_FIT', "Best Fit", "Use a best-fit direction from the selected UVs / 選択UV全体から近似直線の向きを求めます"),
            ('LONGEST', "Longest Axis", "Use the longest U/V span / U/Vの長い方の軸を使います"),
            ('U', "U Axis", "Force a horizontal basis / U軸基準で揃えます"),
            ('V', "V Axis", "Force a vertical basis / V軸基準で揃えます"),
        ],
        default='AUTO',
    update=_suv_workspace_settings_update,)
    uv_chain_endpoint_mode: bpy.props.EnumProperty(
        name="Endpoints",
        description="Keep the first and last UV points in place or let every point move / 最初と最後のUV点を固定するか、全点を動かすかを切り替えます",
        items=[
            ('FIXED', "Keep Ends", "Keep the first and last points in place / 端点を固定して中間を整えます"),
            ('FREE', "Move All", "Allow every point to be repositioned / 全ての点を再配置します"),
        ],
        default='FIXED',
    update=_suv_workspace_settings_update,)
    uv_flow_strength: bpy.props.FloatProperty(
        name="Flow Strength",
        description="How strongly Set Flow bends the selected UV chain / フロー設定でどれだけ曲率を強く反映するか",
        default=1.0,
        min=0.0,
        max=2.0,
        subtype='FACTOR',
    update=_suv_workspace_settings_update,)
    scan_has_result: bpy.props.BoolProperty(name="Has Scan Result", default=False, options={'SKIP_SAVE'})
    scan_time: bpy.props.StringProperty(name="Scan Time", default="", options={'SKIP_SAVE'})
    scan_scope: bpy.props.StringProperty(name="Scan Scope", default="SELECTED", options={'SKIP_SAVE'})
    scan_eps_zero: bpy.props.FloatProperty(name="Scan Zero Epsilon", default=1e-12, min=0.0, options={'SKIP_SAVE'})
    scan_check_out: bpy.props.BoolProperty(name="Scan Out Of Tile", default=True, options={'SKIP_SAVE'})
    scan_check_overlap: bpy.props.BoolProperty(name="Scan Overlap", default=True, options={'SKIP_SAVE'})
    scan_precise_overlap: bpy.props.BoolProperty(name="Scan Precise Overlap", default=True, options={'SKIP_SAVE'})
    scan_uv_name: bpy.props.StringProperty(name="Scan UV Name", default="", options={'SKIP_SAVE'})
    scan_mesh_count: bpy.props.IntProperty(name="Scan Mesh Count", default=0, min=0, options={'SKIP_SAVE'})
    scan_flipped: bpy.props.IntProperty(name="Flipped Count", default=0, min=0, options={'SKIP_SAVE'})
    scan_zero: bpy.props.IntProperty(name="Zero Count", default=0, min=0, options={'SKIP_SAVE'})
    scan_out: bpy.props.IntProperty(name="Out Count", default=0, min=0, options={'SKIP_SAVE'})
    scan_overlap: bpy.props.IntProperty(name="Overlap Count", default=0, min=0, options={'SKIP_SAVE'})
    scan_stretch: bpy.props.IntProperty(name="Stretch Count", default=0, min=0, options={'SKIP_SAVE'})
    scan_stretch_worst: bpy.props.FloatProperty(name="Worst Stretch", default=1.0, min=1.0, options={'SKIP_SAVE'})
    scan_stretch_avg: bpy.props.FloatProperty(name="Average Stretch", default=1.0, min=1.0, options={'SKIP_SAVE'})
    health_status: bpy.props.StringProperty(name="Health Status", default="Unknown", options={'SKIP_SAVE'})
    health_message: bpy.props.StringProperty(name="Health Message", default="Not checked yet", options={'SKIP_SAVE'})
    health_checked_time: bpy.props.StringProperty(name="Health Checked", default="", options={'SKIP_SAVE'})
    health_issue_count: bpy.props.IntProperty(name="Health Issues", default=0, min=0, options={'SKIP_SAVE'})
    health_missing_uv_count: bpy.props.IntProperty(name="Missing UV Meshes", default=0, min=0, options={'SKIP_SAVE'})
    health_missing_active_uv_count: bpy.props.IntProperty(name="Missing Active UV Meshes", default=0, min=0, options={'SKIP_SAVE'})
    health_icon_count: bpy.props.IntProperty(name="Loaded Icons", default=0, min=0, options={'SKIP_SAVE'})
    health_cache_entries: bpy.props.IntProperty(name="Cache Entries", default=0, min=0, options={'SKIP_SAVE'})
    tool_runtime_log_name: bpy.props.StringProperty(name="Runtime Log", description='Text datablock used to append UV Suite tool_runtime logs / UV Suite の実行ログを書き足すテキストデータ名', default="SUV_Runtime_Log", update=_suv_workspace_settings_update)
    batch_report_name: bpy.props.StringProperty(name="Batch Report", description="Text datablock used to append multi-step workflow summaries / 複数ステップ処理の要約を追記するテキストデータ名", default="SUV_Batch_Report", update=_suv_workspace_settings_update)
    support_bundle_name: bpy.props.StringProperty(name="Support Bundle", description="Text datablock used for one-file support bundles that collect the latest diagnostics summary / 最新の診断要約を1つにまとめるサポートバンドル用テキストデータ名", default="SUV_Support_Bundle", update=_suv_workspace_settings_update)
    validation_report_name: bpy.props.StringProperty(name="Validation Report", description="Text datablock used for workspace validation reports / ワークスペース検証レポート用のテキストデータ名", default="SUV_Validation_Report", update=_suv_workspace_settings_update)
    last_snapshot_name: bpy.props.StringProperty(name="Last Snapshot Name", default="", options={'SKIP_SAVE'})
    batch_error_policy: bpy.props.EnumProperty(
        name="Batch Error Policy",
        description="Choose whether multi-step tools stop at the first error or continue while recording partial completion / 複数ステップツールで最初のエラーで停止するか、部分完了として継続するかを選びます",
        items=[
            ('CONTINUE', "Continue", "Keep going and record partial completion / 続行しつつ部分完了を記録します"),
            ('STOP_ON_ERROR', "Stop on Error", "Stop remaining steps after the first error / 最初のエラー以降の工程を停止します"),
        ],
        default='CONTINUE',
    update=_suv_workspace_settings_update,)
    batch_snapshot_policy: bpy.props.EnumProperty(
        name="Batch Snapshot Policy",
        description="Choose when automatic workspace snapshots are written for batch workflows / バッチ処理で自動スナップショットを書き出すタイミングを選びます",
        items=[
            ('ERROR', "On Error", "Write a snapshot when a step errors / エラー時にスナップショットを書き出します"),
            ('WARN_ERROR', "Warn + Error", "Write a snapshot for warnings and errors / 警告とエラーの両方で書き出します"),
            ('OFF', "Off", "Do not write automatic snapshots / 自動スナップショットを書き出しません"),
        ],
        default='ERROR',
    update=_suv_workspace_settings_update,)
    batch_last_summary: bpy.props.StringProperty(name="Last Batch Summary", default="", options={'SKIP_SAVE'})
    health_last_operator: bpy.props.StringProperty(name="Last Operator", default="", options={'SKIP_SAVE'})
    health_last_error: bpy.props.StringProperty(name="Last Error", default="", options={'SKIP_SAVE'})

def _suv_ws(context):
    scene = getattr(context, 'scene', None) if context is not None else None
    return _suv_ensure_workspace_settings(scene)


def _tab_matches(ws, tab_name: str):
    if not ws:
        return True
    current = getattr(ws, 'main_tab', 'ALL')
    return current in {'ALL', tab_name}


def _suv_now_str():
    try:
        return time.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return ""


def _suv_text_block(name: str, clear=False):
    txt = bpy.data.texts.get(name)
    if txt is None:
        txt = bpy.data.texts.new(name)
    elif clear:
        txt.clear()
    return txt


def _suv_tool_runtime_log_name(context):
    ws = _suv_ws(context)
    name = getattr(ws, 'tool_runtime_log_name', '') if ws else ''
    return str(name).strip() or 'SUV_Runtime_Log'

def _suv_batch_report_name(context):
    ws = _suv_ws(context)
    name = getattr(ws, 'batch_report_name', '') if ws else ''
    return str(name).strip() or 'SUV_Batch_Report'


def _suv_support_bundle_name(context):
    ws = _suv_ws(context)
    name = getattr(ws, 'support_bundle_name', '') if ws else ''
    return str(name).strip() or 'SUV_Support_Bundle'


def _suv_validation_report_name(context):
    ws = _suv_ws(context)
    name = getattr(ws, 'validation_report_name', '') if ws else ''
    return str(name).strip() or 'SUV_Validation_Report'


def _suv_scan_report_name(context):
    ws = _suv_ws(context)
    name = getattr(ws, 'scan_report_name', '') if ws else ''
    return str(name).strip() or 'SUV_Scan_Report'


def _suv_text_tail(txt, max_lines=120, max_chars=30000):
    if txt is None:
        return ''
    try:
        data = txt.as_string()
    except Exception:
        return ''
    if not data:
        return ''
    lines = data.splitlines()
    if max_lines and len(lines) > max_lines:
        lines = lines[-max_lines:]
    joined = '\n'.join(lines)
    if max_chars and len(joined) > max_chars:
        joined = joined[-max_chars:]
    return joined


def _suv_open_text_in_editor(context, txt):
    if txt is None:
        return False, 'No text datablock'
    wm = context.window_manager
    # A background run has no window, so there is no editor to show the text in.
    if not bpy.app.background and not any(area.type == 'TEXT_EDITOR' for win in wm.windows for area in win.screen.areas):
        known = set(wm.windows[:])
        with context.temp_override(window=context.window or wm.windows[0]):
            bpy.ops.wm.window_new()
        win = next((w for w in wm.windows if w not in known), None)
        if win is None:
            return False, 'Could not open a new window'
        area = max(win.screen.areas, key=lambda a: a.width * a.height)
        area.type = 'TEXT_EDITOR'
        area.spaces.active.text = txt
        return True, None
    with _TextEditorOverride(context) as ov:
        if not ov.kwargs:
            return False, 'No Text Editor context available'
        try:
            with context.temp_override(**ov.kwargs):
                area = ov.kwargs.get('area')
                space = getattr(area, 'spaces', None).active if area else None
                if space is not None and hasattr(space, 'text'):
                    space.text = txt
                try:
                    bpy.ops.text.jump(line=1)
                except Exception:
                    pass
            return True, None
        except Exception as exc:
            _suv_log_exception(context, 'Open Diagnostics Text', exc, {
                'text': getattr(txt, 'name', '-'),
                'area_source': ov.area_source or '-',
                'used_temp_area': ov.used_temp_area,
            })
            return False, str(exc)


def _suv_write_validation_report(context, data=None):
    data = data or _suv_validate_workspace_state(context)
    ws = _suv_ws(context)
    name = _suv_validation_report_name(context)
    txt = _suv_text_block(name, clear=True)
    selected = _selected_mesh_objects(context)
    missing_uv = _suv_meshes_without_uv(context)
    missing_active = []
    for obj in selected:
        try:
            if len(obj.data.uv_layers) > 0 and obj.data.uv_layers.active is None:
                missing_active.append(obj)
        except Exception:
            pass
    caps = _suv_area_capabilities(context)
    lines = [
        'UV Suite Validation Report',
        f"Version: {'.'.join(map(str, bl_info.get('version', (0, 0, 0))))}",
        f"Time: {_suv_now_str()}",
        '',
        '[Result]',
        f"Status: {data.get('status', 'Unknown')}",
        f"Summary: {data.get('message', '-')}",
        f"Issue Count: {data.get('issue_count', 0)}",
        '',
        '[Mesh Readiness]',
        f"Selected Mesh Count: {len(selected)}",
        f"Missing UV Count: {len(missing_uv)}",
        f"Missing Active UV Count: {len(missing_active)}",
        f"Missing UV Meshes: {', '.join(getattr(o, 'name', '?') for o in missing_uv) if missing_uv else '-'}",
        f"Missing Active UV Meshes: {', '.join(getattr(o, 'name', '?') for o in missing_active) if missing_active else '-'}",
        '',
        '[Context / Override Capabilities]',
        f"Current Area: {caps.get('current_area_type', '-')}",
        f"Image Editors: {caps.get('image_editor_count', 0)}",
        f"View3D Areas: {caps.get('view3d_count', 0)}",
        f"UV Override Possible: {caps.get('repurpose_possible', False)}",
        f"Mode Switch Possible: {caps.get('mode_switch_possible', False)}",
        f"Active Mesh Selectable: {caps.get('active_mesh_selectable', False)}",
        f"Active Mesh Name: {caps.get('active_mesh_name', '-')}",
        '',
        '[Diagnostics Names]',
        f"Runtime Log: {_suv_tool_runtime_log_name(context)}",
        f"Batch Report: {_suv_batch_report_name(context)}",
        f"Scan Report: {_suv_scan_report_name(context)}",
        f"Support Bundle: {_suv_support_bundle_name(context)}",
        f"Validation Report: {name}",
    ]
    if ws is not None:
        lines.extend([
            '',
            '[Workspace State]',
            f"Last Operator: {getattr(ws, 'health_last_operator', '')}",
            f"Last Error: {getattr(ws, 'health_last_error', '')}",
            f"Last Batch Summary: {getattr(ws, 'batch_last_summary', '')}",
            f"Last Snapshot Name: {getattr(ws, 'last_snapshot_name', '')}",
        ])
    txt.write('\n'.join(lines) + '\n')
    return txt


def _suv_create_support_bundle(context):
    ws = _suv_ws(context)
    name = _suv_support_bundle_name(context)
    txt = _suv_text_block(name, clear=True)
    health = _suv_validate_workspace_state(context)
    snap = _suv_context_snapshot(context)
    tool_runtime_name = _suv_tool_runtime_log_name(context)
    batch_name = _suv_batch_report_name(context)
    scan_name = _suv_scan_report_name(context)
    tool_runtime_txt = bpy.data.texts.get(tool_runtime_name)
    batch_txt = bpy.data.texts.get(batch_name)
    scan_txt = bpy.data.texts.get(scan_name)
    last_snapshot = getattr(ws, 'last_snapshot_name', '') if ws else ''
    snapshot_txt = bpy.data.texts.get(last_snapshot) if last_snapshot else None
    validation_name = _suv_validation_report_name(context)
    validation_txt = bpy.data.texts.get(validation_name)
    lines = [
        'UV Suite Support Bundle',
        f"Version: {'.'.join(map(str, bl_info.get('version', (0, 0, 0))))}",
        f"Time: {_suv_now_str()}",
        '',
        '[Workspace Health]',
        f"Status: {health.get('status', 'Unknown')}",
        f"Summary: {health.get('message', '-')}",
        f"Issue Count: {health.get('issue_count', 0)}",
        f"Current Area: {snap.get('area', '-')}",
        f"Mode: {snap.get('mode', '-')}",
        f"Active Object: {snap.get('object', '-')}",
        f"Active UV: {snap.get('active_uv', '-')}",
        '',
        '[Diagnostics Text Names]',
        f"Runtime Log: {tool_runtime_name}",
        f"Batch Report: {batch_name}",
        f"Scan Report: {scan_name}",
        f"Last Snapshot: {last_snapshot or '-'}",
        f"Validation Report: {validation_name}",
        '',
    ]
    if ws is not None:
        lines.extend([
            '[Workspace State]',
            f"Last Operator: {getattr(ws, 'health_last_operator', '')}",
            f"Last Error: {getattr(ws, 'health_last_error', '')}",
            f"Last Batch Summary: {getattr(ws, 'batch_last_summary', '')}",
            f"Batch Error Policy: {getattr(ws, 'batch_error_policy', 'CONTINUE')}",
            f"Batch Snapshot Policy: {getattr(ws, 'batch_snapshot_policy', 'ERROR')}",
            '',
        ])
    tool_runtime_tail = _suv_text_tail(tool_runtime_txt, max_lines=80, max_chars=20000)
    batch_tail = _suv_text_tail(batch_txt, max_lines=80, max_chars=20000)
    scan_tail = _suv_text_tail(scan_txt, max_lines=80, max_chars=16000)
    snap_tail = _suv_text_tail(snapshot_txt, max_lines=80, max_chars=16000)
    validation_tail = _suv_text_tail(validation_txt, max_lines=80, max_chars=16000)
    if tool_runtime_tail:
        lines.extend(['[Runtime Log Tail]', tool_runtime_tail, ''])
    if batch_tail:
        lines.extend(['[Batch Report Tail]', batch_tail, ''])
    if scan_tail:
        lines.extend(['[Scan Report Tail]', scan_tail, ''])
    if snap_tail:
        lines.extend(['[Last Snapshot Tail]', snap_tail, ''])
    if validation_tail:
        lines.extend(['[Validation Report Tail]', validation_tail, ''])
    txt.write('\n'.join(lines).strip() + '\n')
    return txt


def _suv_batch_error_policy(context):
    ws = _suv_ws(context)
    return getattr(ws, 'batch_error_policy', 'CONTINUE') if ws else 'CONTINUE'


def _suv_batch_snapshot_policy(context):
    ws = _suv_ws(context)
    return getattr(ws, 'batch_snapshot_policy', 'ERROR') if ws else 'ERROR'


def _suv_batch_safe_name(value: str, fallback='step'):
    text = re.sub(r'[^A-Za-z0-9._-]+', '_', str(value or '').strip())
    return text.strip('_.') or fallback


def _suv_batch_capture_snapshot(context, report, step: str, status: str):
    mode = _suv_batch_snapshot_policy(context)
    status_key = str(status or '').upper()
    if mode == 'OFF':
        return ''
    if status_key == 'WARN' and mode != 'WARN_ERROR':
        return ''
    if status_key not in {'WARN', 'ERROR'}:
        return ''
    try:
        stamp = time.strftime('%Y%m%d_%H%M%S')
    except Exception:
        stamp = 'snapshot'
    base = _suv_tool_runtime_log_name(context)
    source = _suv_batch_safe_name((report or {}).get('source', 'Batch'), 'Batch')
    step_name = _suv_batch_safe_name(step, 'step')
    snap_name = f"{base}_{source}_{step_name}_{status_key}_{stamp}"
    txt = _suv_write_workspace_snapshot(context, name=snap_name)
    return getattr(txt, 'name', snap_name)


def _suv_batch_should_stop(context, report):
    return bool(report and report.get('stop_requested'))


def _suv_batch_begin(context, source: str, title: str = None, details=None):
    name = _suv_batch_report_name(context)
    txt = _suv_text_block(name, clear=False)
    try:
        if txt.as_string().strip():
            txt.write("\n\n")
    except Exception:
        pass
    started = _suv_now_str()
    header = title or source
    txt.write(f"[{started}] {header}\n")
    if details:
        if isinstance(details, dict):
            for k, v in details.items():
                txt.write(f"- {k}: {v}\n")
        else:
            txt.write(f"- {details}\n")
    state = {
        'name': name,
        'txt': txt,
        'source': source,
        'started': started,
        'steps': 0,
        'ok': 0,
        'warn': 0,
        'error': 0,
        'entries': [],
    }
    ws = _suv_ws(context)
    if ws is not None:
        ws.batch_last_summary = f"{source}: started {started}"
    return state


def _suv_batch_note(context, report, status: str, step: str, message: str, details=None):
    if report is None:
        return
    report['steps'] += 1
    key = str(status or 'WARN').lower()
    if key in report:
        report[key] += 1
    entry = {'status': status, 'step': step, 'message': message, 'details': details}
    report['entries'].append(entry)
    txt = report.get('txt')
    if txt is not None:
        txt.write(f"[{status}] {step}: {message}\n")
        if details:
            if isinstance(details, dict):
                for k, v in details.items():
                    txt.write(f"  - {k}: {v}\n")
            else:
                txt.write(f"  - {details}\n")


def _suv_batch_step(context, report, step: str, callback, *, fatal=False, details=None):
    txt = report.get('txt') if report else None
    if txt is not None:
        txt.write(f"--> {step}\n")
    _suv_log_event(context, 'INFO', report.get('source', 'Batch') if report else 'Batch', f"Step start: {step}", {
        'fatal': fatal,
        'details': details or {},
    })
    try:
        result = callback()
    except Exception as exc:
        payload = dict(details or {})
        payload['fatal'] = fatal
        snapshot_name = _suv_batch_capture_snapshot(context, report, step, 'ERROR')
        if snapshot_name:
            payload['snapshot'] = snapshot_name
        _suv_log_exception(context, f"{report.get('source', 'Batch')} | {step}", exc, payload)
        _suv_batch_note(context, report, 'ERROR', step, f"{type(exc).__name__}: {exc}", payload)
        if report is not None and (fatal or _suv_batch_error_policy(context) == 'STOP_ON_ERROR'):
            report['stop_requested'] = True
        return False, {'CANCELLED'}
    payload = dict(details or {})
    if isinstance(result, set):
        payload['result'] = sorted(list(result))
    elif result is not None:
        payload['result'] = result
    if _suv_result_has(result, 'CANCELLED') or result is False or result is None:
        status = 'ERROR' if fatal else 'WARN'
        snapshot_name = _suv_batch_capture_snapshot(context, report, step, status)
        if snapshot_name:
            payload['snapshot'] = snapshot_name
        _suv_batch_note(context, report, status, step, 'Step cancelled or returned no result', payload or None)
        if report is not None and (fatal or (status == 'ERROR' and _suv_batch_error_policy(context) == 'STOP_ON_ERROR')):
            report['stop_requested'] = True
        return False, result
    _suv_batch_note(context, report, 'OK', step, 'Finished', payload or None)
    return True, result


def _suv_batch_finish(context, report, *, operator=None):
    if report is None:
        return {'CANCELLED'}
    summary = f"steps={report.get('steps', 0)} ok={report.get('ok', 0)} warn={report.get('warn', 0)} error={report.get('error', 0)}"
    txt = report.get('txt')
    if txt is not None:
        txt.write(f"Summary: {summary}\n")
    ws = _suv_ws(context)
    if ws is not None:
        ws.batch_last_summary = summary[:1024]
    level = 'INFO'
    if report.get('error', 0) > 0:
        level = 'ERROR'
    elif report.get('warn', 0) > 0:
        level = 'WARN'
    _suv_log_event(context, level, report.get('source', 'Batch'), 'Batch summary', {
        'summary': summary,
        'batch_report': report.get('name', ''),
    })
    if operator is not None:
        if report.get('error', 0) > 0:
            operator.report({'WARNING'}, f"Partial completion ({summary})")
        elif report.get('warn', 0) > 0:
            operator.report({'INFO'}, f"Completed with warnings ({summary})")
        else:
            operator.report({'INFO'}, f"Completed ({summary})")
    if report.get('error', 0) > 0 and report.get('ok', 0) == 0:
        return {'CANCELLED'}
    return {'FINISHED'}


def _suv_area_capabilities(context):
    image_editor_count = 0
    view3d_count = 0
    repurpose_possible = False
    current_area = getattr(context, 'area', None)
    current_area_type = getattr(current_area, 'type', '') or 'UNKNOWN'
    active_mesh_name = '-'
    active_mesh_selectable = False
    mode_switch_possible = False
    try:
        wm = context.window_manager
        for win in wm.windows:
            scr = win.screen
            for area in scr.areas:
                if area.type == 'IMAGE_EDITOR':
                    image_editor_count += 1
                elif area.type == 'VIEW_3D':
                    view3d_count += 1
        repurpose_possible = bool(current_area) or view3d_count > 0
    except Exception:
        pass
    obj = _active_mesh_obj(context)
    if obj is not None:
        active_mesh_name = getattr(obj, 'name', '-') or '-'
        active_mesh_selectable = _suv_object_is_selectable(obj)
        mode_switch_possible = active_mesh_selectable and getattr(obj, 'type', None) == 'MESH'
    return {
        'image_editor_count': image_editor_count,
        'view3d_count': view3d_count,
        'repurpose_possible': repurpose_possible,
        'current_area_type': current_area_type,
        'active_mesh_name': active_mesh_name,
        'active_mesh_selectable': active_mesh_selectable,
        'mode_switch_possible': mode_switch_possible,
    }


def _suv_context_snapshot(context):
    area = getattr(getattr(context, 'area', None), 'type', '') or 'UNKNOWN'
    region = getattr(getattr(context, 'region', None), 'type', '') or 'UNKNOWN'
    obj_name = '-'
    mode = 'UNKNOWN'
    uv_name = '-'
    selected_meshes = 0
    total_uv_maps = 0
    obj = _active_mesh_obj(context)
    if obj is not None:
        obj_name = obj.name
        mode = getattr(obj, 'mode', '') or 'UNKNOWN'
        try:
            if obj.data.uv_layers.active is not None:
                uv_name = obj.data.uv_layers.active.name
        except Exception:
            pass
    try:
        meshes = _selected_mesh_objects(context)
        selected_meshes = len(meshes)
        total_uv_maps = sum(len(getattr(m.data, 'uv_layers', [])) for m in meshes)
    except Exception:
        pass
    caps = _suv_area_capabilities(context)
    return {
        'time': _suv_now_str(),
        'area': area,
        'region': region,
        'object': obj_name,
        'mode': mode,
        'active_uv': uv_name,
        'selected_meshes': selected_meshes,
        'total_uv_maps': total_uv_maps,
        'image_editor_count': caps['image_editor_count'],
        'view3d_count': caps['view3d_count'],
        'current_area_type': caps['current_area_type'],
        'uv_override_possible': caps['repurpose_possible'],
        'active_mesh_name': caps['active_mesh_name'],
        'active_mesh_selectable': caps['active_mesh_selectable'],
        'mode_switch_possible': caps['mode_switch_possible'],
    }


def _suv_log_event(context, level: str, source: str, message: str, details=None):
    ws = _suv_ws(context)
    snap = _suv_context_snapshot(context)
    txt = _suv_text_block(_suv_tool_runtime_log_name(context), clear=False)
    try:
        if txt.as_string().strip():
            txt.write("\n\n")
    except Exception:
        pass
    lines = [
        f"[{snap['time']}] {level} | {source}",
        f"Message: {message}",
        f"Area: {snap['area']} / Region: {snap['region']}",
        f"Mode: {snap['mode']}",
        f"Active Object: {snap['object']}",
        f"Active UV: {snap['active_uv']}",
        f"Selected Meshes: {snap['selected_meshes']}",
        f"Total UV Maps: {snap['total_uv_maps']}",
        f"Image Editors: {snap['image_editor_count']} / View3D: {snap['view3d_count']}",
        f"UV Override Possible: {snap['uv_override_possible']} (Current Area: {snap['current_area_type']})",
        f"Mode Switch Possible: {snap['mode_switch_possible']} / Active Mesh Selectable: {snap['active_mesh_selectable']} ({snap['active_mesh_name']})",
    ]
    if details:
        lines.append('Details:')
        if isinstance(details, dict):
            for k, v in details.items():
                lines.append(f"- {k}: {v}")
        elif isinstance(details, (list, tuple, set)):
            for item in details:
                lines.append(f"- {item}")
        else:
            lines.append(f"- {details}")
    txt.write("\n".join(lines))
    if ws is not None:
        ws.health_last_operator = str(source)[:256]
        if level in {'WARN', 'ERROR'}:
            ws.health_last_error = str(message)[:1024]


def _suv_log_exception(context, source: str, exc: Exception, details=None):
    payload = {}
    if isinstance(details, dict):
        payload.update(details)
    elif details is not None:
        payload['details'] = details
    payload['exception_type'] = type(exc).__name__
    payload['traceback'] = traceback.format_exc()
    _suv_log_event(context, 'ERROR', source, f"{type(exc).__name__}: {exc}", payload)
    try:
        _suv_write_workspace_snapshot(context, name=_suv_tool_runtime_log_name(context) + '_ErrorSnapshot')
    except Exception:
        pass


def _suv_write_workspace_snapshot(context, name=None):
    ws = _suv_ws(context)
    data = _suv_validate_workspace_state(context)
    snap = _suv_context_snapshot(context)
    block_name = str(name or (_suv_tool_runtime_log_name(context) + '_Snapshot')).strip()
    txt = _suv_text_block(block_name, clear=True)
    lines = [
        'UV Suite Workspace Snapshot',
        f"Version: {'.'.join(map(str, bl_info.get('version', (0, 0, 0))))}",
        f"Time: {snap['time']}",
        f"Status: {data.get('status', 'Unknown')}",
        f"Summary: {data.get('message', '-')}",
        f"Issue Count: {data.get('issue_count', 0)}",
        '',
        '[Context]',
        f"Area: {snap['area']}",
        f"Region: {snap['region']}",
        f"Mode: {snap['mode']}",
        f"Active Object: {snap['object']}",
        f"Active UV: {snap['active_uv']}",
        f"Selected Meshes: {snap['selected_meshes']}",
        f"Total UV Maps: {snap['total_uv_maps']}",
        f"Image Editors: {snap['image_editor_count']}",
        f"View3D Areas: {snap['view3d_count']}",
        f"UV Override Possible: {snap['uv_override_possible']}",
        f"Current Area Type: {snap['current_area_type']}",
        f"Mode Switch Possible: {snap['mode_switch_possible']}",
        f"Active Mesh Selectable: {snap['active_mesh_selectable']}",
        f"Active Mesh (Capability): {snap['active_mesh_name']}",
        '',
        '[Health]',
        f"Icons: {data.get('icon_count', 0)}",
        f"Cache Entries: {data.get('cache_entries', 0)}",
        f"Missing UV Meshes: {data.get('missing_uv_count', 0)}",
        f"Missing Active UV Meshes: {data.get('missing_active_uv_count', 0)}",
    ]
    if ws is not None:
        lines.extend([
            '',
            '[Workspace]',
            f"Main Tab: {getattr(ws, 'main_tab', 'UNKNOWN')}",
            f"Canvas Size: {getattr(ws, 'canvas_size', 0)}",
            f"Runtime Log: {getattr(ws, 'tool_runtime_log_name', '')}",
            f"Batch Report: {getattr(ws, 'batch_report_name', '')}",
            f"Last Operator: {getattr(ws, 'health_last_operator', '')}",
            f"Last Error: {getattr(ws, 'health_last_error', '')}",
        ])
    txt.write("\n".join(lines))
    if ws is not None:
        ws.last_snapshot_name = block_name
    return txt


def _suv_has_annotation_strokes(context):
    try:
        return len(_annotation_points_raw(context)) >= 2
    except Exception:
        return False


def _suv_total_uv_map_count(context):
    total = 0
    for obj in _selected_mesh_objects(context):
        try:
            total += len(obj.data.uv_layers)
        except Exception:
            pass
    return total


def _suv_meshes_without_uv(context):
    out = []
    for obj in _selected_mesh_objects(context):
        try:
            if len(obj.data.uv_layers) == 0:
                out.append(obj)
        except Exception:
            pass
    return out


def _suv_scan_issue_count(ws):
    if not ws:
        return 0
    return (
        int(getattr(ws, 'scan_flipped', 0) or 0)
        + int(getattr(ws, 'scan_zero', 0) or 0)
        + int(getattr(ws, 'scan_out', 0) or 0)
        + int(getattr(ws, 'scan_overlap', 0) or 0)
        + int(getattr(ws, 'scan_stretch', 0) or 0)
    )


def _suv_safe_bool(value):
    try:
        return bool(value)
    except Exception:
        return False


def _suv_safe_enum(current, allowed, fallback):
    try:
        if current in allowed:
            return current
    except Exception:
        pass
    return fallback


def _suv_repair_workspace_settings(ws):
    if not ws:
        return
    ws.ui_mode = 'SIMPLE'
    ws.main_tab = _suv_safe_enum(getattr(ws, 'main_tab', 'WORKFLOW'), {'WORKFLOW', 'TRANSFORM', 'LAYOUT', 'ANALYZE', 'MAPS', 'SYMMETRY', 'ATLAS'}, 'WORKFLOW')
    ws.pack_group_mode = _suv_safe_enum(getattr(ws, 'pack_group_mode', 'SIMILAR'), {'MATERIAL', 'SIMILAR', 'IDENTICAL'}, 'SIMILAR')
    ws.pack_group_layout = _suv_safe_enum(getattr(ws, 'pack_group_layout', 'SINGLE_TILE'), {'SINGLE_TILE', 'TILES', 'ROWS', 'COLUMNS'}, 'SINGLE_TILE')
    ws.stack_group_mode = _suv_safe_enum(getattr(ws, 'stack_group_mode', 'SIMILAR'), {'SIMILAR', 'IDENTICAL'}, 'SIMILAR')
    ws.hotspot_sort = _suv_safe_enum(getattr(ws, 'hotspot_sort', 'AREA'), {'AREA', 'WIDTH', 'HEIGHT'}, 'AREA')
    ws.hotspot_fill_order = _suv_safe_enum(getattr(ws, 'hotspot_fill_order', 'ROW'), {'ROW', 'COLUMN'}, 'ROW')
    ws.uv_chain_group_mode = _suv_safe_enum(getattr(ws, 'uv_chain_group_mode', 'SEPARATE'), {'SEPARATE', 'COMBINED'}, 'SEPARATE')
    ws.uv_chain_axis_mode = _suv_safe_enum(getattr(ws, 'uv_chain_axis_mode', 'AUTO'), {'AUTO', 'BEST_FIT', 'LONGEST', 'U', 'V'}, 'AUTO')
    ws.uv_chain_endpoint_mode = _suv_safe_enum(getattr(ws, 'uv_chain_endpoint_mode', 'FIXED'), {'FIXED', 'FREE'}, 'FIXED')
    ws.show_help_text = _suv_safe_bool(getattr(ws, 'show_help_text', False))
    ws.show_reference_gallery = _suv_safe_bool(getattr(ws, 'show_reference_gallery', False))
    ws.workflow_pack_after = True
    ws.workflow_relax_after = True
    try:
        ws.auto_unwrap_mode = _suv_safe_enum(str(getattr(ws, 'auto_unwrap_mode', 'BLENDER_ANGLE_BASED') or 'BLENDER_ANGLE_BASED'), {'SMART', 'SMART_SQUARE', 'SMART_CIRCLE', 'FLAT_MAPPING', 'BLENDER_ANGLE_BASED', 'BLENDER_CONFORMAL', 'BLENDER_MIN_STRETCH', 'BLENDER_SMART_PROJECT', 'BLENDER_LIGHTMAP_PACK', 'BLENDER_FOLLOW_ACTIVE_QUADS', 'QUICK_PLANAR', 'BOX_PROJECT', 'CYLINDRICAL', 'SPHERICAL', 'VIEW_PROJECT', 'UNITIZE_FACES'}, 'BLENDER_ANGLE_BASED')
        if hasattr(ws, 'unwrap_map_channel'):
            try:
                raw_value = ws.get('unwrap_map_channel')
            except Exception:
                raw_value = None
            raw_text = str(raw_value).strip() if raw_value is not None else ''
            if raw_text.isdigit():
                canonical = f'CHANNEL_{max(0, int(raw_text))}'
                try:
                    from . import uv_map_channels as _uvc
                    valid_identifiers = {
                        str(item[0])
                        for item in _uvc.map_channel_enum_items(bpy.context)
                        if item
                    }
                except Exception:
                    valid_identifiers = set()
                if canonical in valid_identifiers:
                    # Assign through RNA so the legacy INT IDProperty is
                    # replaced by the canonical enum value.  (A raw string
                    # IDProperty write is type-mismatched for an enum and is
                    # ignored by RNA, leaving the stale int in place.)
                    try:
                        ws.unwrap_map_channel = canonical
                    except Exception:
                        pass
                    raw_text = canonical
            value = raw_text or str(getattr(ws, 'unwrap_map_channel', 'ACTIVE') or 'ACTIVE')
            if (
                value != 'ACTIVE'
                and not value.startswith('CHANNEL_')
                and not value.startswith('INDEX_')
            ):
                ws.unwrap_map_channel = 'ACTIVE'
    except Exception:
        pass
    try:
        if hasattr(ws, 'smart_standard_core_unwrap_mode'):
            ws.smart_standard_core_unwrap_mode = _suv_safe_enum(str(getattr(ws, 'smart_standard_core_unwrap_mode', 'SMART_STANDARD_HARD') or 'SMART_STANDARD_HARD').upper(), {'CUSTOM', 'SMART_STANDARD_HARD', 'SMART_STANDARD_ORGANIC', 'SMART', 'NORMAL', 'STANDARD_KEEP', 'BALANCED', 'LOW_STRETCH', 'LOOP_SAFE', 'AREA_ACCURATE', 'QUALITY_OPTIMIZE', 'CLEAN_MERGE', 'PACK_STABLE', 'HARD_CHART_PRECISION', 'ORGANIC_LOW_DISTORTION_PRECISION', 'SELECTED_SCOPE_LOW_DISTORTION', 'SINGLE_ISLAND'}, 'SMART_STANDARD_HARD')
        for _prop_name, _default in (
            ('smart_standard_core_quality_strength', 0.0),
            ('smart_standard_core_area_preserve_strength', 0.0),
            ('smart_standard_core_shape_preserve_strength', 0.0),
            ('smart_standard_core_native_result_preserve', 100.0),
            ('smart_standard_core_seam_merge_strength', 0.0),
            ('smart_standard_core_single_angle_weight', 72.0),
            ('smart_standard_core_single_stretch_weight', 72.0),
            ('smart_standard_core_single_loop_weight', 62.0),
            ('smart_standard_core_single_planarity_weight', 55.0),
            ('smart_standard_core_single_density_weight', 55.0),
            ('smart_standard_core_single_user_seam_weight', 80.0),
            ('smart_standard_core_single_boundary_weight', 46.0),
            ('smart_standard_core_single_small_island_merge', 42.0),
            ('smart_standard_core_single_seam_angle_weight', 85.0),
            ('smart_standard_core_single_seam_stretch_weight', 70.0),
            ('smart_standard_core_single_seam_loop_weight', 60.0),
            ('smart_standard_core_single_seam_area_weight', 50.0),
            ('smart_standard_core_single_seam_shared_boundary_weight', 55.0),
            ('smart_standard_core_single_seam_jagged_cleanup_weight', 35.0),
        ):
            if hasattr(ws, _prop_name):
                try:
                    setattr(ws, _prop_name, max(0.0, min(100.0, float(getattr(ws, _prop_name, _default)))))
                except Exception:
                    setattr(ws, _prop_name, _default)
        if hasattr(ws, 'smart_standard_core_single_seam_profile'):
            try:
                ws.smart_standard_core_single_seam_profile = _suv_safe_enum(str(getattr(ws, 'smart_standard_core_single_seam_profile', 'STANDARD_KEEP') or 'STANDARD_KEEP').upper(), {'CUSTOM', 'STANDARD_KEEP', 'BALANCED', 'HARD_SURFACE', 'ORGANIC', 'STANDARD_SMART', 'NORMAL_UNWRAP', 'LOW_STRETCH', 'LOOP_SAFE', 'AREA_ACCURATE', 'QUALITY_OPTIMIZE', 'CLEAN_MERGE', 'PACK_STABLE', 'SINGLE_ISLAND'}, 'STANDARD_KEEP')
            except Exception:
                pass
        if hasattr(ws, 'smart_standard_core_quality_iterations'):
            try:
                ws.smart_standard_core_quality_iterations = max(0, min(240, int(getattr(ws, 'smart_standard_core_quality_iterations', 0))))
            except Exception:
                ws.smart_standard_core_quality_iterations = 0
    except Exception:
        pass
    
    try:
        ws.smart_quality_profile = 'HERO'
    except Exception:
        pass
    try:
        ws.smart_precision_level = 'EXTREME'
    except Exception:
        pass
    try:
        if str(getattr(ws, 'smart_unwrap_preset', 'STANDARD') or 'STANDARD').upper() not in {'STANDARD', 'SQUARE', 'CIRCLE'}:
            ws.smart_unwrap_preset = 'STANDARD'
        if hasattr(ws, 'smart_unwrap_orientation_angle'):
            try:
                ws.smart_unwrap_orientation_angle = max(0.0, min(360.0, float(getattr(ws, 'smart_unwrap_orientation_angle', 0.0) or 0.0)))
            except Exception:
                ws.smart_unwrap_orientation_angle = 0.0
    except Exception:
        pass
    ws.hotspot_keep_aspect = _suv_safe_bool(getattr(ws, 'hotspot_keep_aspect', True))
    ws.canvas_size = _suv_clamped_int(getattr(ws, 'canvas_size', 2048), 2048, 128, 16384)
    ws.checker_size = _suv_clamped_int(getattr(ws, 'checker_size', 2048), 2048, 256, 8192)
    ws.fit_padding_px = _suv_clamped_int(getattr(ws, 'fit_padding_px', 8), 8, 0, 256)
    ws.workflow_density = max(1.0, float(getattr(ws, 'workflow_density', 1024.0) or 1024.0))
    ws.similarity_area_tol = max(0.0, min(float(getattr(ws, 'similarity_area_tol', 0.08) or 0.08), 1.0))
    ws.similarity_aspect_tol = max(0.0, min(float(getattr(ws, 'similarity_aspect_tol', 0.15) or 0.15), 1.0))
    ws.stretch_threshold = max(1.01, min(float(getattr(ws, 'stretch_threshold', 1.8) or 1.8), 100.0))
    ws.heatmap_max = max(1.1, min(float(getattr(ws, 'heatmap_max', 4.0) or 4.0), 100.0))
    ws.hotspot_cols = _suv_clamped_int(getattr(ws, 'hotspot_cols', 4), 4, 1, 64)
    ws.hotspot_rows = _suv_clamped_int(getattr(ws, 'hotspot_rows', 4), 4, 1, 64)
    if not getattr(ws, 'scan_report_name', ''):
        ws.scan_report_name = 'SUV_Scan_Report'
    if not getattr(ws, 'heatmap_attr_name', ''):
        ws.heatmap_attr_name = 'SUV_StretchHeat'
    if not getattr(ws, 'heatmap_material_name', ''):
        ws.heatmap_material_name = 'SUV_StretchHeat'
    if not getattr(ws, 'checker_image_name', ''):
        ws.checker_image_name = 'SUV_Checker'
    if not getattr(ws, 'checker_material_name', ''):
        ws.checker_material_name = 'SUV_Checker'
    if not getattr(ws, 'uv_new_name', ''):
        ws.uv_new_name = 'UVMap_SUV'
    if not getattr(ws, 'tool_runtime_log_name', ''):
        ws.tool_runtime_log_name = 'SUV_Runtime_Log'
    if not getattr(ws, 'batch_report_name', ''):
        ws.batch_report_name = 'SUV_Batch_Report'
    if not getattr(ws, 'batch_error_policy', ''):
        ws.batch_error_policy = 'CONTINUE'
    if not getattr(ws, 'batch_snapshot_policy', ''):
        ws.batch_snapshot_policy = 'ERROR'


def _suv_cache_entry_count(scene):
    data = _cache_get(scene, None, None)
    if isinstance(data, dict):
        return len(data.keys())
    try:
        raw = scene.get('SUV_CACHE', None)
        if isinstance(raw, dict):
            return len(raw.keys())
    except Exception:
        pass
    return 0


def _suv_loaded_icon_count():
    if _SUV_ICON_COLLECTION is None:
        _suv_ensure_custom_icons_loaded()
    try:
        return len(_SUV_ICON_COLLECTION.keys()) if _SUV_ICON_COLLECTION else 0
    except Exception:
        return 0


def _suv_validate_workspace_state(context):
    ws = _suv_ws(context)
    selected = _selected_mesh_objects(context)
    missing_uv = _suv_meshes_without_uv(context)
    missing_active = []
    for obj in selected:
        try:
            if len(obj.data.uv_layers) > 0 and obj.data.uv_layers.active is None:
                missing_active.append(obj)
        except Exception:
            pass
    caps = _suv_area_capabilities(context)
    issues = []
    if ws is None:
        issues.append('workspace pointer missing')
    if missing_uv:
        issues.append(f'missing UV: {len(missing_uv)}')
    if missing_active:
        issues.append(f'missing active UV: {len(missing_active)}')
    if _suv_loaded_icon_count() == 0:
        issues.append('icons not loaded')
    if caps['image_editor_count'] == 0:
        if caps['repurpose_possible']:
            issues.append('no image editor open (temporary fallback will be used)')
        else:
            issues.append('no image editor or override candidate available')
    if selected and not caps['mode_switch_possible']:
        issues.append('active mesh is not ready for guarded mode switching')
    status = 'OK'
    if ws is None:
        status = 'ERROR'
    elif issues:
        status = 'WARN'
    message = 'Ready'
    if issues:
        message = '; '.join(issues)
    data = {
        'status': status,
        'message': message,
        'issue_count': len(issues),
        'missing_uv_count': len(missing_uv),
        'missing_active_uv_count': len(missing_active),
        'icon_count': _suv_loaded_icon_count(),
        'cache_entries': _suv_cache_entry_count(context.scene),
        'checked_time': _suv_now_str(),
        'image_editor_count': caps['image_editor_count'],
        'view3d_count': caps['view3d_count'],
        'uv_override_possible': caps['repurpose_possible'],
        'current_area_type': caps['current_area_type'],
        'mode_switch_possible': caps['mode_switch_possible'],
        'active_mesh_selectable': caps['active_mesh_selectable'],
        'active_mesh_name': caps['active_mesh_name'],
    }
    if ws:
        ws.health_status = status
        ws.health_message = message
        ws.health_checked_time = data['checked_time']
        ws.health_issue_count = data['issue_count']
        ws.health_missing_uv_count = data['missing_uv_count']
        ws.health_missing_active_uv_count = data['missing_active_uv_count']
        ws.health_icon_count = data['icon_count']
        ws.health_cache_entries = data['cache_entries']
    return data


def _suv_ensure_uv_maps_selected(context, uv_name='UVMap_SUV'):
    objs = _selected_mesh_objects(context)
    if not objs:
        return []
    # Inspect first without changing mode.  Blender 5.1 stores UV selection in
    # live edit-mesh flags; an unnecessary OBJECT/EDIT round trip can discard
    # those flags, especially during multi-object editing.  Mode switching is
    # only required when a UV layer actually has to be created or activated.
    needs_object_mode = False
    for obj in objs:
        if obj is None or not _suv_object_is_selectable(obj):
            continue
        try:
            layers = obj.data.uv_layers
            if len(layers) == 0 or layers.active is None:
                needs_object_mode = True
                break
        except Exception:
            needs_object_mode = True
            break
    if not needs_object_mode:
        return []
    created = []
    skipped = []
    with _PreserveContextState(context, restore_mode=True, restore_render_engine=False):
        active = getattr(context.view_layer.objects, 'active', None)
        prev_mode = _suv_normalize_mode_name(getattr(active, 'mode', 'OBJECT')) if active else 'OBJECT'
        if active and prev_mode != 'OBJECT':
            ok, err = _suv_safe_mode_set(context, active, 'OBJECT', source='UV Preflight')
            if not ok:
                _suv_log_event(context, 'WARN', 'UV Preflight', 'Could not switch active mesh to OBJECT before UV creation.', {
                    'active_object': getattr(active, 'name', '-'),
                    'previous_mode': prev_mode,
                    'error': err or '-',
                })
        for obj in objs:
            if obj is None:
                continue
            if not _suv_object_is_selectable(obj):
                skipped.append(getattr(obj, 'name', '<unselectable>'))
                continue
            try:
                layers = obj.data.uv_layers
                if len(layers) == 0:
                    layers.new(name=uv_name or 'UVMap_SUV')
                    created.append(obj.name)
                if layers and layers.active is None:
                    layers.active_index = 0
            except Exception as exc:
                skipped.append(f"{getattr(obj, 'name', '<error>')}: {exc}")
        if skipped:
            _suv_log_event(context, 'WARN', 'UV Preflight', 'Some meshes could not prepare UV maps.', {
                'created_uv_count': len(created),
                'created_uv': ', '.join(created[:8]) if created else '-',
                'skipped': skipped,
            })
    return created


def _suv_reload_icons():
    _unload_custom_icons()
    _load_custom_icons()
    return _suv_loaded_icon_count()


def _suv_post_register_init():
    try:
        _SUV_REPAIRED_SCENE_IDS.clear()
    except Exception:
        pass


def _suv_scan_counts_dict(ws):
    if not ws:
        return {"flipped": 0, "zero": 0, "out": 0, "overlap": 0, "stretch": 0, "total": 0, "worst_stretch": 1.0, "avg_stretch": 1.0}
    counts = {
        "flipped": int(getattr(ws, 'scan_flipped', 0) or 0),
        "zero": int(getattr(ws, 'scan_zero', 0) or 0),
        "out": int(getattr(ws, 'scan_out', 0) or 0),
        "overlap": int(getattr(ws, 'scan_overlap', 0) or 0),
        "stretch": int(getattr(ws, 'scan_stretch', 0) or 0),
        "worst_stretch": float(getattr(ws, 'scan_stretch_worst', 1.0) or 1.0),
        "avg_stretch": float(getattr(ws, 'scan_stretch_avg', 1.0) or 1.0),
    }
    counts["total"] = counts["flipped"] + counts["zero"] + counts["out"] + counts["overlap"] + counts["stretch"]
    return counts


def _select_islands_from_face_sigs(context, obj, sigs, apply_mode='REPLACE'):
    sigs = set(tuple(s) if isinstance(s, list) else s for s in sigs or [])
    if not sigs:
        return 0
    count = 0
    with _TempMode(context, obj, 'EDIT'):
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        islands = build_islands(bm, uv_layer, faces_subset=list(bm.faces))
        if apply_mode == 'REPLACE':
            for f in bm.faces:
                _suv_face_select(context, f, False)
        for isl in islands:
            if isl.face_sig in sigs:
                count += 1
                for f in isl.faces:
                    if apply_mode == 'SUB':
                        _suv_face_select(context, f, False)
                    else:
                        _suv_face_select(context, f, True)
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    return count


def _quantile_sorted(values, q: float):
    vals = list(values or [])
    if not vals:
        return 0.0
    if len(vals) == 1:
        return float(vals[0])
    q = max(0.0, min(1.0, float(q)))
    pos = (len(vals) - 1) * q
    lo = int(math.floor(pos))
    hi = int(math.ceil(pos))
    if lo == hi:
        return float(vals[lo])
    t = pos - lo
    return float(vals[lo]) * (1.0 - t) + float(vals[hi]) * t


def _unique_uv_points(isl: _Island, ndigits: int = 5):
    seen = set()
    pts = []
    for p in getattr(isl, 'uv_points', []) or []:
        v = Vector(p)
        key = (round(float(v.x), ndigits), round(float(v.y), ndigits))
        if key in seen:
            continue
        seen.add(key)
        pts.append(v)
    return pts


def _radial_signature(isl: _Island):
    pts = _unique_uv_points(isl)
    if not pts:
        return (1.0, 1.0, 1.0, 1.0, 1.0)
    center = Vector((sum(p.x for p in pts) / len(pts), sum(p.y for p in pts) / len(pts)))
    scale = max(1.0e-12, math.sqrt(max(1.0e-12, float(getattr(isl, 'abs_area', 0.0) or 0.0))))
    radii = sorted((p - center).length / scale for p in pts)
    qs = (0.05, 0.25, 0.5, 0.75, 0.95)
    return tuple(_quantile_sorted(radii, q) for q in qs)


def _island_metrics(isl: _Island):
    w = max(1e-12, float(isl.bbox_max.x - isl.bbox_min.x))
    h = max(1e-12, float(isl.bbox_max.y - isl.bbox_min.y))
    bbox_area = max(1.0e-12, w * h)
    area = max(1e-12, float(isl.abs_area))
    return {
        "area": area,
        "aspect": w / h,
        "fill": area / bbox_area,
        "bbox_area": bbox_area,
        "loops": len(getattr(isl, 'loops', []) or []),
        "faces": len(isl.faces),
        "verts": len(isl.vert_ids),
        "tiles": len(isl.udim_tiles),
        "radial_sig": _radial_signature(isl),
        "dist_sig": _pairwise_distance_signature_core(isl),
    }


def _islands_match(ref: _Island, isl: _Island, area_tol: float, aspect_tol: float, strict: bool = False) -> bool:
    rm = _island_metrics(ref)
    im = _island_metrics(isl)
    if strict:
        if im["faces"] != rm["faces"]:
            return False
        if im["verts"] != rm["verts"]:
            return False
        if im["tiles"] != rm["tiles"]:
            return False
        if im["loops"] != rm["loops"]:
            return False
    if abs(im["area"] / rm["area"] - 1.0) > max(0.0, area_tol):
        return False
    if abs(im["aspect"] / rm["aspect"] - 1.0) > max(0.0, aspect_tol):
        return False
    fill_tol = max(0.02 if strict else 0.04, min(0.12 if strict else 0.35, max(area_tol, aspect_tol) * 0.75))
    if abs(im["fill"] / rm["fill"] - 1.0) > fill_tol:
        return False
    sig_tol = 0.06 if strict else max(0.08, min(0.25, max(area_tol, aspect_tol) * 0.9 + 0.04))
    dist_tol = 0.05 if strict else max(0.06, min(0.20, max(area_tol, aspect_tol) * 0.75 + 0.03))
    if not _signature_ratio_ok(rm["radial_sig"], im["radial_sig"], sig_tol):
        return False
    if not _signature_ratio_ok(rm["dist_sig"], im["dist_sig"], dist_tol):
        return False
    return True


def _dominant_material_index(isl: _Island) -> int:
    counts = {}
    for f in isl.faces:
        idx = int(getattr(f, 'material_index', 0) or 0)
        counts[idx] = counts.get(idx, 0) + 1
    if not counts:
        return 0
    return sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))[0][0]


def _group_islands_by_mode(islands, mode='SIMILAR', area_tol=0.08, aspect_tol=0.15):
    islands = list(islands or [])
    if not islands:
        return []
    mode = str(mode or 'SIMILAR').upper()
    if mode == 'MATERIAL':
        buckets = {}
        for isl in islands:
            buckets.setdefault(_dominant_material_index(isl), []).append(isl)
        return [{"label": f"MAT_{k}", "ref": v[0], "islands": v} for k, v in sorted(buckets.items(), key=lambda kv: kv[0])]

    strict = (mode == 'IDENTICAL')
    ordered = sorted(islands, key=lambda i: (len(i.faces), i.abs_area), reverse=True)
    groups = []
    for isl in ordered:
        placed = False
        for grp in groups:
            if _islands_match(grp["ref"], isl, area_tol, aspect_tol, strict=strict):
                grp["islands"].append(isl)
                placed = True
                break
        if not placed:
            groups.append({"label": f"{mode}_{len(groups)+1}", "ref": isl, "islands": [isl]})
    return groups




def _face_world_area(face, obj):
    area = 0.0
    try:
        mw = obj.matrix_world
        loops = list(face.loops)
        if len(loops) < 3:
            return 0.0
        p0 = mw @ loops[0].vert.co
        for i in range(1, len(loops) - 1):
            p1 = mw @ loops[i].vert.co
            p2 = mw @ loops[i + 1].vert.co
            area += ((p1 - p0).cross(p2 - p0)).length * 0.5
    except Exception:
        return 0.0
    return area


def _safe_ratio_median(values):
    vals = sorted(float(v) for v in (values or []) if float(v) > 0.0)
    if not vals:
        return 1.0
    mid = len(vals) // 2
    if len(vals) % 2:
        return vals[mid]
    return 0.5 * (vals[mid - 1] + vals[mid])


def _island_stretch_score(isl: _Island, obj, uv_layer):
    ratios = []
    for f in isl.faces:
        wa = _face_world_area(f, obj)
        ua = abs(_signed_uv_area(f, uv_layer))
        if wa > 1e-12 and ua > 1e-12:
            ratios.append(ua / wa)
    if len(ratios) < 2:
        return 1.0, ratios
    med = max(1e-12, _safe_ratio_median(ratios))
    normalized = [max(r / med, med / r) for r in ratios]
    worst = max(normalized) if normalized else 1.0
    return max(1.0, float(worst)), ratios


def _make_rect_proxy(id_, width, height):
    proxy = _Island(id_)
    w = max(1e-6, float(width))
    h = max(1e-6, float(height))
    proxy.uv_points = [Vector((0.0, 0.0)), Vector((w, 0.0)), Vector((w, h)), Vector((0.0, h))]
    proxy.uv_centroid = Vector((w * 0.5, h * 0.5))
    proxy.axis = Vector((1.0, 0.0))
    proxy.bbox_min = Vector((0.0, 0.0))
    proxy.bbox_max = Vector((w, h))
    proxy.abs_area = w * h
    proxy.signed_area = proxy.abs_area
    return proxy


def _build_group_pack_records(groups, margin_uv, rot_step):
    records = []
    for gi, grp in enumerate(groups):
        islands = list(grp.get('islands', []))
        if not islands:
            continue
        gmin, _ = _group_bbox(islands)
        origin = Vector(gmin)
        proxies = []
        members = []
        for ii, isl in enumerate(islands):
            proxy = _Island(ii)
            proxy.uv_points = [Vector(p) - origin for p in isl.uv_points]
            proxy.uv_centroid = Vector(isl.uv_centroid) - origin
            proxy.axis = Vector(isl.axis)
            proxy.bbox_min = Vector(isl.bbox_min) - origin
            proxy.bbox_max = Vector(isl.bbox_max) - origin
            proxy.has_pin = bool(isl.has_pin)
            proxies.append(proxy)
            members.append({"island": isl, "proxy": proxy})
        placements, ok = _pack_shelf(proxies, margin_uv, rot_step, allow_rotate=(rot_step != 0))
        if not ok:
            placements = {}
            for ii, item in enumerate(members):
                proxy = item["proxy"]
                placements[ii] = {
                    "angle": 0.0,
                    "bmin": Vector(proxy.bbox_min),
                    "bmax": Vector(proxy.bbox_max),
                    "dx": margin_uv * 2.0 - proxy.bbox_min.x,
                    "dy": margin_uv * 2.0 - proxy.bbox_min.y,
                }
        group_min = Vector((1e18, 1e18))
        group_max = Vector((-1e18, -1e18))
        for ii, item in enumerate(members):
            pl = placements.get(ii)
            if not pl:
                continue
            bmin = Vector(pl.get("bmin", item["proxy"].bbox_min)) + Vector((pl.get("dx", 0.0), pl.get("dy", 0.0)))
            bmax = Vector(pl.get("bmax", item["proxy"].bbox_max)) + Vector((pl.get("dx", 0.0), pl.get("dy", 0.0)))
            group_min.x = min(group_min.x, bmin.x)
            group_min.y = min(group_min.y, bmin.y)
            group_max.x = max(group_max.x, bmax.x)
            group_max.y = max(group_max.y, bmax.y)
            item["angle"] = float(pl.get("angle", 0.0))
            item["delta"] = Vector((float(pl.get("dx", 0.0)), float(pl.get("dy", 0.0))))
            item["pivot_local"] = Vector(item["proxy"].uv_centroid)
        if group_min.x > group_max.x:
            group_min = Vector((0.0, 0.0))
            group_max = Vector((1e-4, 1e-4))
        for item in members:
            item["delta"] = Vector(item["delta"]) - group_min
        size = group_max - group_min
        records.append({
            "label": grp.get("label", f"GROUP_{gi+1}"),
            "origin": origin,
            "members": members,
            "proxy": _make_rect_proxy(gi, size.x, size.y),
        })
    return records


def _apply_group_pack_records(records, group_placements, uv_layer, start_off=None):
    start_off = Vector(start_off) if start_off is not None else Vector((0.0, 0.0))
    groups_done = 0
    packed_islands = 0
    max_tile_index = 0
    for rec in records:
        pl = group_placements.get(rec["proxy"].id)
        if not pl:
            continue
        group_delta = Vector((float(pl.get("dx", 0.0)), float(pl.get("dy", 0.0))))
        tile_index = int(pl.get("tile_index", 0) or 0)
        max_tile_index = max(max_tile_index, tile_index)
        tile_off = start_off + Vector((tile_index % 10, tile_index // 10))
        origin = Vector(rec["origin"])
        for item in rec["members"]:
            isl = item["island"]
            pivot_local = Vector(item["pivot_local"])
            ang = float(item["angle"])
            delta = tile_off + group_delta + Vector(item["delta"])
            def tf(uuv, origin=origin, pivot_local=pivot_local, ang=ang, delta=delta):
                uu = Vector(uuv) - origin
                uu = pivot_local + _rotate2(uu - pivot_local, ang) + delta
                return uu
            _island_apply_transform(isl, uv_layer, tf)
            packed_islands += 1
        groups_done += 1
    return groups_done, packed_islands, (max_tile_index + 1 if records else 0)


def _suv_store_scan_cache(context, scope, eps_zero, check_out, check_overlap, precise_overlap, flipped, zero, out, overlap, stretch_count=0, stretch_worst=1.0, stretch_avg=1.0):
    ws = _suv_ws(context)
    if not ws:
        return
    ws.scan_has_result = True
    ws.scan_time = _suv_now_str()
    ws.scan_scope = str(scope)
    ws.scan_eps_zero = float(eps_zero)
    ws.scan_check_out = bool(check_out)
    ws.scan_check_overlap = bool(check_overlap)
    ws.scan_precise_overlap = bool(precise_overlap)
    obj = _active_mesh_obj(context)
    ws.scan_uv_name = obj.data.uv_layers.active.name if obj and obj.data and obj.data.uv_layers.active else ""
    ws.scan_mesh_count = len(_selected_mesh_objects(context))
    ws.scan_flipped = int(flipped)
    ws.scan_zero = int(zero)
    ws.scan_out = int(out)
    ws.scan_overlap = int(overlap)
    ws.scan_stretch = int(stretch_count)
    ws.scan_stretch_worst = max(1.0, float(stretch_worst or 1.0))
    ws.scan_stretch_avg = max(1.0, float(stretch_avg or 1.0))


def _suv_clear_scan_cache(context):
    ws = _suv_ws(context)
    if not ws:
        return
    ws.scan_has_result = False
    ws.scan_time = ""
    ws.scan_scope = 'SELECTED'
    ws.scan_eps_zero = 1e-12
    ws.scan_check_out = True
    ws.scan_check_overlap = True
    ws.scan_precise_overlap = True
    ws.scan_uv_name = ""
    ws.scan_mesh_count = 0
    ws.scan_flipped = 0
    ws.scan_zero = 0
    ws.scan_out = 0
    ws.scan_overlap = 0
    ws.scan_stretch = 0
    ws.scan_stretch_worst = 1.0
    ws.scan_stretch_avg = 1.0


def _suv_reset_workspace(context):
    ws = _suv_ws(context)
    if not ws:
        return
    ws.show_help_text = False
    ws.show_properties = True
    ws.show_workflow = True
    ws.show_unwrap = True
    ws.show_transform = True
    ws.show_layout = True
    ws.show_selection = True
    ws.show_density = True
    ws.show_preview = True
    ws.show_symmetry = True
    ws.show_atlas = False
    ws.show_dashboard = False
    ws.show_reference_gallery = False
    ws.ui_mode = 'SIMPLE'
    ws.uv_chain_group_mode = 'SEPARATE'
    ws.uv_chain_axis_mode = 'AUTO'
    ws.uv_chain_endpoint_mode = 'FIXED'
    ws.uv_flow_strength = 1.0
    ws.fit_padding_px = 8
    ws.pack_group_mode = 'SIMILAR'
    ws.stack_group_mode = 'SIMILAR'
    ws.similarity_area_tol = 0.08
    ws.similarity_aspect_tol = 0.15
    ws.scan_report_name = 'SUV_Scan_Report'
    ws.tool_runtime_log_name = 'SUV_Runtime_Log'
    ws.pack_group_layout = 'SINGLE_TILE'
    ws.unified_pack_merge_overlap = False
    ws.stretch_threshold = 1.8
    ws.heatmap_max = 4.0
    ws.heatmap_attr_name = 'SUV_StretchHeat'
    ws.heatmap_material_name = 'SUV_StretchHeat'
    ws.hotspot_cols = 4
    ws.hotspot_rows = 4
    ws.hotspot_keep_aspect = True
    ws.hotspot_sort = 'AREA'
    ws.hotspot_fill_order = 'ROW'
    _suv_clear_scan_cache(context)


def _suv_apply_workflow_preset(context, preset):
    ws = _suv_ws(context)
    if not ws:
        return
    ws.show_properties = True
    ws.show_dashboard = True
    ws.show_help_text = True
    if preset == 'UNWRAP':
        ws.main_tab = 'WORKFLOW'
        ws.show_workflow = True
        ws.show_unwrap = True
        ws.show_transform = False
        ws.show_layout = False
        ws.show_selection = False
        ws.show_density = False
        ws.show_preview = False
        ws.show_symmetry = False
        ws.show_atlas = False
    elif preset == 'ALIGN':
        ws.main_tab = 'TRANSFORM'
        ws.show_workflow = False
        ws.show_unwrap = False
        ws.show_transform = True
        ws.show_layout = False
        ws.show_selection = False
        ws.show_density = False
        ws.show_preview = False
        ws.show_symmetry = False
        ws.show_atlas = False
    elif preset == 'LAYOUT':
        ws.main_tab = 'LAYOUT'
        ws.show_workflow = False
        ws.show_unwrap = False
        ws.show_transform = False
        ws.show_layout = True
        ws.show_selection = False
        ws.show_density = False
        ws.show_preview = False
        ws.show_symmetry = False
        ws.show_atlas = False
    elif preset == 'REPAIR':
        ws.main_tab = 'ANALYZE'
        ws.show_workflow = False
        ws.show_unwrap = False
        ws.show_transform = True
        ws.show_layout = True
        ws.show_selection = False
        ws.show_density = True
        ws.show_preview = False
        ws.show_symmetry = False
        ws.show_atlas = False


def _suv_apply_display_preset(context, preset):
    ws = _suv_ws(context)
    if not ws:
        return
    ws.show_dashboard = True
    ws.show_help_text = True
    if preset == 'BASIC':
        ws.main_tab = 'WORKFLOW'
        ws.show_properties = True; ws.show_workflow = True; ws.show_unwrap = True; ws.show_transform = True; ws.show_layout = False; ws.show_selection = False; ws.show_density = False; ws.show_preview = False; ws.show_symmetry = False; ws.show_atlas = False
    elif preset == 'ALIGN':
        ws.main_tab = 'TRANSFORM'
        ws.show_properties = True; ws.show_workflow = False; ws.show_unwrap = False; ws.show_transform = True; ws.show_layout = False; ws.show_selection = False; ws.show_density = False; ws.show_preview = False; ws.show_symmetry = False; ws.show_atlas = False
    elif preset == 'LAYOUT':
        ws.main_tab = 'LAYOUT'
        ws.show_properties = True; ws.show_workflow = False; ws.show_unwrap = False; ws.show_transform = False; ws.show_layout = True; ws.show_selection = False; ws.show_density = False; ws.show_preview = False; ws.show_symmetry = False; ws.show_atlas = False
    elif preset == 'INSPECT':
        ws.main_tab = 'ANALYZE'
        ws.show_properties = True; ws.show_workflow = False; ws.show_unwrap = False; ws.show_transform = False; ws.show_layout = False; ws.show_selection = False; ws.show_density = True; ws.show_preview = False; ws.show_symmetry = False; ws.show_atlas = False
    elif preset == 'ALL':
        ws.main_tab = 'ALL'
        ws.show_properties = True; ws.show_workflow = True; ws.show_unwrap = True; ws.show_transform = True; ws.show_layout = True; ws.show_selection = True; ws.show_density = True; ws.show_preview = True; ws.show_symmetry = True; ws.show_atlas = True


def _suv_apply_line_flow_preset(context, preset):
    ws = _suv_ws(context)
    if not ws:
        return
    if preset == 'STRAIGHT':
        ws.uv_chain_group_mode = 'SEPARATE'
        ws.uv_chain_axis_mode = 'AUTO'
        ws.uv_chain_endpoint_mode = 'FIXED'
        ws.uv_flow_strength = 0.0
    elif preset == 'SAFE_FLOW':
        ws.uv_chain_group_mode = 'SEPARATE'
        ws.uv_chain_axis_mode = 'AUTO'
        ws.uv_chain_endpoint_mode = 'FIXED'
        ws.uv_flow_strength = 0.35
    elif preset == 'FLOW':
        ws.uv_chain_group_mode = 'SEPARATE'
        ws.uv_chain_axis_mode = 'BEST_FIT'
        ws.uv_chain_endpoint_mode = 'FREE'
        ws.uv_flow_strength = 1.0
    elif preset == 'ANNOTATE':
        ws.uv_chain_group_mode = 'SEPARATE'
        ws.uv_chain_axis_mode = 'AUTO'
        ws.uv_chain_endpoint_mode = 'FIXED'


def _suv_apply_layout_preset(context, preset):
    ws = _suv_ws(context)
    if not ws:
        return
    if preset == 'PACK':
        ws.fit_padding_px = 8
    elif preset == 'ROW':
        ws.fit_padding_px = 12
    elif preset == 'BLOCK':
        ws.fit_padding_px = 16
    elif preset == 'TIDY':
        ws.fit_padding_px = 10


def _faces_for_scope(context, obj, bm, uv_layer, scope='SELECTED'):
    if scope == 'ALL':
        return list(bm.faces)
    sel_faces, _sel_loops, _active_face, _src = _selection_from_context(context, obj, bm, uv_layer)
    return list(sel_faces)


def _islands_for_scope(context, obj, bm, uv_layer, scope='SELECTED'):
    if scope == 'ALL':
        return build_islands(bm, uv_layer, faces_subset=list(bm.faces))
    sel_faces, _sel_loops, active_face, _src = _selection_from_context(context, obj, bm, uv_layer)
    if not sel_faces:
        return []
    seed = set(sel_faces)
    islands = [isl for isl in build_islands(bm, uv_layer, faces_subset=list(bm.faces)) if any(face in seed for face in isl.faces)]
    if active_face is not None:
        islands.sort(key=lambda isl: (0 if active_face in isl.faces else 1, isl.id))
    return islands


def _group_bbox(islands):
    if not islands:
        return Vector((0.0, 0.0)), Vector((0.0, 0.0))
    minx = min(i.bbox_min.x for i in islands)
    miny = min(i.bbox_min.y for i in islands)
    maxx = max(i.bbox_max.x for i in islands)
    maxy = max(i.bbox_max.y for i in islands)
    return Vector((minx, miny)), Vector((maxx, maxy))


def _translate_island(isl, uv_layer, delta: Vector):
    _island_apply_transform(isl, uv_layer, lambda u: Vector(u) + delta)


def _rotate_island(isl, uv_layer, angle_rad: float, pivot=None):
    pivot = Vector(pivot) if pivot is not None else isl.uv_centroid
    _island_apply_transform(isl, uv_layer, lambda u: pivot + _rotate2(Vector(u) - pivot, angle_rad))


def _mirror_island(isl, uv_layer, axis='U', pivot=None):
    pivot = Vector(pivot) if pivot is not None else isl.uv_centroid
    if axis == 'U':
        _island_apply_transform(isl, uv_layer, lambda u: _mirror_x(Vector(u), pivot))
    else:
        _island_apply_transform(isl, uv_layer, lambda u: _mirror_y(Vector(u), pivot))


def _anchor_from_bbox(bmin: Vector, bmax: Vector, axis='U', mode='MIN'):
    if axis == 'U':
        if mode == 'MIN':
            return bmin.x
        if mode == 'MAX':
            return bmax.x
        return (bmin.x + bmax.x) * 0.5
    if mode == 'MIN':
        return bmin.y
    if mode == 'MAX':
        return bmax.y
    return (bmin.y + bmax.y) * 0.5


def _island_anchor_from_mode(isl, axis='U', mode='CENTER'):
    return _anchor_from_bbox(isl.bbox_min, isl.bbox_max, axis=axis, mode=mode)


def _orientation_edge_selected(context, obj, loop):
    if _is_uv_sync(context):
        return _uv_loop_edge_selected(context, obj, loop)
    return bool(loop.face.select and not loop.face.hide and loop.uv_select_edge)


def _dominant_selected_uv_edge_direction(context, obj, bm, uv_layer):
    weighted = []
    for f in bm.faces:
        for l in f.loops:
            if not _orientation_edge_selected(context, obj, l):
                continue
            uv0 = Vector(l[uv_layer].uv)
            uv1 = Vector(l.link_loop_next[uv_layer].uv)
            d = uv1 - uv0
            length = float(d.length)
            if length <= 1.0e-12:
                continue
            weighted.append((d.normalized(), length))
    if not weighted:
        return None
    weighted.sort(key=lambda item: item[1], reverse=True)
    base = Vector(weighted[0][0]).normalized()
    acc = Vector((0.0, 0.0))
    total = 0.0
    for vec, weight in weighted:
        vv = Vector(vec)
        if base.dot(vv) < 0.0:
            vv.negate()
        acc += vv * weight
        total += weight
    if acc.length <= 1.0e-12:
        return base
    if total > 1.0e-12:
        acc /= total
    return acc.normalized() if acc.length > 1.0e-12 else base


def _dominant_selected_uv_edge_direction_for_island(context, obj, uv_layer, isl: _Island):
    weighted = []
    for loop_obj in getattr(isl, 'loops', []) or []:
        if not _orientation_edge_selected(context, obj, loop_obj):
            continue
        uv0 = Vector(loop_obj[uv_layer].uv)
        uv1 = Vector(loop_obj.link_loop_next[uv_layer].uv)
        d = uv1 - uv0
        length = float(d.length)
        if length <= 1.0e-12:
            continue
        weighted.append((d.normalized(), length))
    if not weighted:
        return None
    weighted.sort(key=lambda item: item[1], reverse=True)
    base = Vector(weighted[0][0]).normalized()
    acc = Vector((0.0, 0.0))
    total = 0.0
    for vec, weight in weighted:
        vv = Vector(vec)
        if base.dot(vv) < 0.0:
            vv.negate()
        acc += vv * weight
        total += weight
    if acc.length <= 1.0e-12:
        return base
    if total > 1.0e-12:
        acc /= total
    return acc.normalized() if acc.length > 1.0e-12 else base


def _nearest_world_axis_2d(vec: Vector):
    if vec.length <= 1.0e-12:
        return Vector((1.0, 0.0))
    xdot = abs(vec.dot(Vector((1.0, 0.0))))
    ydot = abs(vec.dot(Vector((0.0, 1.0))))
    if xdot >= ydot:
        return Vector((1.0, 0.0)) if vec.x >= 0.0 else Vector((-1.0, 0.0))
    return Vector((0.0, 1.0)) if vec.y >= 0.0 else Vector((0.0, -1.0))


def _signed_angle_2d(a: Vector, b: Vector) -> float:
    aa = a.normalized() if a.length > 1e-12 else Vector((1.0, 0.0))
    bb = b.normalized() if b.length > 1e-12 else Vector((1.0, 0.0))
    dot = max(-1.0, min(1.0, aa.dot(bb)))
    ang = math.acos(dot)
    cross = aa.x * bb.y - aa.y * bb.x
    if cross < 0.0:
        ang = -ang
    return ang


def _best_bbox_angle(isl: _Island, step_deg: int = 15) -> float:
    step_deg = max(1, int(step_deg))
    coarse_step = math.radians(step_deg)

    def _norm_pi(angle: float) -> float:
        angle = float(angle) % math.pi
        return angle

    def _score(angle: float):
        bmin, bmax = _island_bbox_after_rotation(isl, angle)
        sx, sy = _bbox_size(bmin, bmax)
        area = sx * sy
        aspect_bias = abs(sx - sy)
        return (area, aspect_bias)

    samples = max(2, int(round(math.pi / coarse_step)))
    best_ang = 0.0
    best_score = None
    for i in range(samples):
        ang = _norm_pi(i * coarse_step)
        score = _score(ang)
        if best_score is None or score < best_score:
            best_score = score
            best_ang = ang

    refine = coarse_step * 0.5
    for _ in range(5):
        candidates = [_norm_pi(best_ang + refine * offset) for offset in (-3, -2, -1, 0, 1, 2, 3)]
        for ang in candidates:
            score = _score(ang)
            if best_score is None or score < best_score:
                best_score = score
                best_ang = ang
        refine *= 0.5
    return _norm_pi(best_ang)



def _refresh_island_metrics(isl: _Island, uv_layer):
    return _refresh_island_tool_runtime_metrics(isl, uv_layer)


def _scale_island(isl: _Island, uv_layer, scale_u=1.0, scale_v=1.0, pivot=None):
    pivot = Vector(pivot) if pivot is not None else isl.uv_centroid
    _island_apply_transform(isl, uv_layer, lambda u: Vector((pivot.x + (Vector(u).x - pivot.x) * scale_u, pivot.y + (Vector(u).y - pivot.y) * scale_v)))


def _cluster_sorted_values(values, tolerance):
    vals = sorted(float(v) for v in values)
    if not vals:
        return []
    clusters = [[vals[0]]]
    for v in vals[1:]:
        center = sum(clusters[-1]) / len(clusters[-1])
        if abs(v - center) <= tolerance:
            clusters[-1].append(v)
        else:
            clusters.append([v])
    return [sum(c) / len(c) for c in clusters]


def _nearest_cluster_index(value, centers):
    if not centers:
        return 0
    best_i = 0
    best_d = None
    for i, c in enumerate(centers):
        d = abs(value - c)
        if best_d is None or d < best_d:
            best_d = d
            best_i = i
    return best_i


def _gridify_island_even(isl: _Island, uv_layer, merge_factor=0.02, keep_tile=True):
    _refresh_island_metrics(isl, uv_layer)
    original_tile = Vector((math.floor(isl.uv_centroid.x), math.floor(isl.uv_centroid.y)))
    ang = _best_bbox_angle(isl, step_deg=5)
    _rotate_island(isl, uv_layer, ang)
    _refresh_island_metrics(isl, uv_layer)

    span = isl.bbox_max - isl.bbox_min
    tol = max(1.0e-5, max(span.x, span.y) * max(0.0005, float(merge_factor)))
    xs = [l[uv_layer].uv.x for l in isl.loops]
    ys = [l[uv_layer].uv.y for l in isl.loops]
    x_centers = _cluster_sorted_values(xs, tol)
    y_centers = _cluster_sorted_values(ys, tol)

    if len(x_centers) < 2 or len(y_centers) < 2:
        return False

    minx, miny = isl.bbox_min.x, isl.bbox_min.y
    maxx, maxy = isl.bbox_max.x, isl.bbox_max.y

    for l in isl.loops:
        uv = Vector(l[uv_layer].uv)
        xi = _nearest_cluster_index(uv.x, x_centers)
        yi = _nearest_cluster_index(uv.y, y_centers)
        nx = minx if len(x_centers) <= 1 else (minx + (maxx - minx) * (xi / max(1, len(x_centers) - 1)))
        ny = miny if len(y_centers) <= 1 else (miny + (maxy - miny) * (yi / max(1, len(y_centers) - 1)))
        l[uv_layer].uv = Vector((nx, ny))

    _refresh_island_metrics(isl, uv_layer)
    if keep_tile:
        new_tile = Vector((math.floor(isl.uv_centroid.x), math.floor(isl.uv_centroid.y)))
        _translate_island(isl, uv_layer, original_tile - new_tile)
        _refresh_island_metrics(isl, uv_layer)
    return True


def _rectify_fit_island(isl: _Island, uv_layer, padding_uv=0.0, keep_tile=True, square=False):
    _refresh_island_metrics(isl, uv_layer)
    original_tile = Vector((math.floor(isl.uv_centroid.x), math.floor(isl.uv_centroid.y)))
    ang = _best_bbox_angle(isl, step_deg=5)
    _rotate_island(isl, uv_layer, ang)
    _refresh_island_metrics(isl, uv_layer)

    bmin = Vector(isl.bbox_min)
    bmax = Vector(isl.bbox_max)
    size = bmax - bmin
    if size.x <= 1.0e-12 or size.y <= 1.0e-12:
        return False

    target_min = Vector((padding_uv, padding_uv))
    target_max = Vector((1.0 - padding_uv, 1.0 - padding_uv))
    target_size = target_max - target_min

    if square:
        side = min(target_size.x, target_size.y)
        off = Vector(((target_size.x - side) * 0.5, (target_size.y - side) * 0.5))
        target_min += off
        target_max = target_min + Vector((side, side))
        target_size = target_max - target_min

    sx = target_size.x / max(size.x, 1.0e-12)
    sy = target_size.y / max(size.y, 1.0e-12)

    for l in isl.loops:
        uv = Vector(l[uv_layer].uv)
        nx = target_min.x + (uv.x - bmin.x) * sx
        ny = target_min.y + (uv.y - bmin.y) * sy
        l[uv_layer].uv = Vector((nx, ny))

    _refresh_island_metrics(isl, uv_layer)
    if keep_tile:
        new_tile = Vector((math.floor(isl.uv_centroid.x), math.floor(isl.uv_centroid.y)))
        _translate_island(isl, uv_layer, original_tile - new_tile)
        _refresh_island_metrics(isl, uv_layer)
    return True




_TEXT.update({
    "ui.label.coverage_bridge": ("Coverage Bridge", "機能統合ブリッジ"),
    "ui.label.coverage_cleanup": ("Cleanup / Heal / Optimize", "クリーンアップ／修復／最適化"),
    "ui.label.coverage_match": ("Smart Similarity", "スマート類似判定"),
    "op.bridge_camera": ("Camera Planar", "カメラ平面投影"),
    "op.bridge_normal": ("Normal Auto", "法線ベース自動投影"),
    "op.bridge_peel": ("Peel", "Peel"),
    "op.bridge_pelt": ("Pelt", "Pelt"),
    "op.bridge_spline": ("Spline Tube", "スプライン・チューブ"),
    "op.bridge_scan": ("Scan Safe", "スキャン安全"),
    "op.cleanup_heal": ("Heal UV", "UV修復"),
    "op.cleanup_overlap": ("Remove Overlap", "重なり解消"),
    "op.cleanup_relax": ("Relax Knead", "リラックス強化"),
    "op.cleanup_optimize": ("Realtime Optimize", "リアルタイム最適化"),
    "op.cleanup_weld": ("Weld Align", "ウェルド整列"),
    "op.similarity_similar": ("Smart Similar", "類似選択"),
    "op.similarity_identical": ("Smart Identical", "同一選択"),
    "op.similarity_stack": ("Smart Stack", "類似スタック"),
    "msg.bridge_projection_done": ("Coverage projection finished: {mode}", "統合投影が完了しました: {mode}"),
    "msg.bridge_cleanup_done": ("Coverage cleanup finished: {mode}", "統合クリーンアップが完了しました: {mode}"),
    "msg.bridge_magic_done": ("Coverage selection finished: {mode}", "統合選択が完了しました: {mode}"),
})
