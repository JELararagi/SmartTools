# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

'UV Suite Cockpit.\n\nA compact production-control layer for UV Suite.  This module does not\ncopy third-party tools.  It raises local precision by combining existing UV Suite operators, Blender native UV operators, and the UV Suite Precision\nEngine into short, intent-based routes with saved N-panel settings.\n'
from . import resource_api_18168 as _suv_resource

import json
import os
import math
import time
from pathlib import Path

import bpy

_PROFILE_ITEMS = (
    ('PRODUCTION', 'Production Balanced', 'Balanced high-quality settings for most assets.'),
    ('HERO', 'Hero / Close-up', 'High texel density, wider padding, strict matching and inspection.'),
    ('HARD_SURFACE', 'Hard Surface', 'Rectify, grid, trim and orthogonal layout oriented settings.'),
    ('ORGANIC', 'Organic / Character', 'More relax iterations and lower seam aggression.'),
    ('LIGHTMAP', 'Lightmap Safe', 'Conservative no-overlap layout with wide padding.'),
    ('UDIM', 'UDIM / Multi Tile', 'Group-to-tile and keep-tile oriented packing.'),
    ('TRIM', 'Trim / Hotspot', 'Reuse-oriented trim, hotspot and identical stack settings.'),
)

_INTENT_ITEMS = (
    ('PRODUCTION_FINISH', 'Production Finish', 'Analyze, repair, density, pack and write a report.'),
    ('HERO_ASSET', 'Hero Asset', 'High-density close-up quality route.'),
    ('HARD_SURFACE', 'Hard Surface', 'Rectify, gridify, density and dense pack route.'),
    ('ORGANIC', 'Organic', 'Unwrap, relax and inspect route.'),
    ('LIGHTMAP', 'Lightmap', 'Safe non-overlap lightmap-style route.'),
    ('UDIM_MASTER', 'UDIM Master', 'Group, keep tiles, pack and inspect.'),
    ('REPAIR_PACK', 'Repair + Pack', 'Repair common problems then normalize and pack.'),
    ('ONLY_ANALYZE', 'Only Analyze', 'Write score and metrics without changing UVs.'),
)

_PROFILE_DATA = {
    'PRODUCTION': dict(canvas_size=2048, workflow_density=1024.0, fit_padding_px=8, stretch_threshold=1.55,
                       similarity_area_tol=0.06, similarity_aspect_tol=0.10, pack_group_mode='SIMILAR', pack_group_layout='SINGLE_TILE',
                       smart_precision_level='ULTRA', smart_relax_iterations=96, smart_pack_candidates=4, smart_lock_overlaps=False, smart_sliver_protection=True),
    'HERO': dict(canvas_size=4096, workflow_density=2048.0, fit_padding_px=16, stretch_threshold=1.35,
                 similarity_area_tol=0.035, similarity_aspect_tol=0.06, pack_group_mode='SIMILAR', pack_group_layout='SINGLE_TILE',
                 smart_precision_level='EXTREME', smart_relax_iterations=160, smart_pack_candidates=6, smart_lock_overlaps=False, smart_sliver_protection=True),
    'HARD_SURFACE': dict(canvas_size=4096, workflow_density=1536.0, fit_padding_px=10, stretch_threshold=1.45,
                         similarity_area_tol=0.025, similarity_aspect_tol=0.045, pack_group_mode='IDENTICAL', pack_group_layout='SINGLE_TILE',
                         smart_precision_level='EXTREME', smart_relax_iterations=64, smart_pack_candidates=5, smart_lock_overlaps=True, smart_sliver_protection=True),
    'ORGANIC': dict(canvas_size=2048, workflow_density=1024.0, fit_padding_px=12, stretch_threshold=1.30,
                    similarity_area_tol=0.08, similarity_aspect_tol=0.14, pack_group_mode='SIMILAR', pack_group_layout='SINGLE_TILE',
                    smart_precision_level='EXTREME', smart_relax_iterations=192, smart_pack_candidates=3, smart_lock_overlaps=False, smart_sliver_protection=True),
    'LIGHTMAP': dict(canvas_size=2048, workflow_density=256.0, fit_padding_px=24, stretch_threshold=1.20,
                     similarity_area_tol=0.02, similarity_aspect_tol=0.04, pack_group_mode='MATERIAL', pack_group_layout='SINGLE_TILE',
                     smart_precision_level='SAFE', smart_relax_iterations=64, smart_pack_candidates=2, smart_lock_overlaps=False, smart_sliver_protection=True),
    'UDIM': dict(canvas_size=4096, workflow_density=1024.0, fit_padding_px=14, stretch_threshold=1.50,
                 similarity_area_tol=0.06, similarity_aspect_tol=0.10, pack_group_mode='SIMILAR', pack_group_layout='TILES',
                 smart_precision_level='ULTRA', smart_relax_iterations=96, smart_pack_candidates=5, smart_lock_overlaps=True, smart_sliver_protection=True),
    'TRIM': dict(canvas_size=2048, workflow_density=1024.0, fit_padding_px=8, stretch_threshold=1.40,
                 similarity_area_tol=0.02, similarity_aspect_tol=0.04, pack_group_mode='IDENTICAL', pack_group_layout='ROWS',
                 smart_precision_level='ULTRA', smart_relax_iterations=48, smart_pack_candidates=4, smart_lock_overlaps=True, smart_sliver_protection=True),
}


def _is_ja(context=None):
    try:
        lang = str(getattr(getattr(context, 'preferences', None).view, 'language', '') or '')
    except Exception:
        lang = ''
    return lang.startswith('ja') or lang.startswith('jp') or lang == 'DEFAULT_JAPANESE'


def _tr(context, en, ja):
    return str(ja if _is_ja(context) else en)


def _ws(context=None):
    try:
        return getattr(getattr(context or bpy.context, 'scene', None), 'suv_workspace', None)
    except Exception:
        return None


def _operator_proxy(op_id):
    try:
        group, name = str(op_id or '').split('.', 1)
        ops_group = getattr(bpy.ops, group, None)
        return getattr(ops_group, name, None) if ops_group is not None else None
    except Exception:
        return None


def _is_real_rna(rna):
    try:
        ident = str(getattr(rna, 'identifier', '') or '')
    except Exception:
        ident = ''
    return bool(ident) and ident not in {'Operator', 'OperatorProperties', 'UnknownType', 'bpy_struct'}


def _operator_exists(op_id):
    op = _operator_proxy(op_id)
    if op is None:
        return False
    try:
        return _is_real_rna(op.get_rna_type())
    except Exception:
        return False


def _operator_property_names(op_id):
    op = _operator_proxy(op_id)
    names = set()
    try:
        rna = op.get_rna_type()
        if not _is_real_rna(rna):
            return names
        props = getattr(rna, 'properties', None)
        try:
            names.update(str(k) for k in props.keys())
        except Exception:
            pass
        try:
            for prop in props:
                ident = str(getattr(prop, 'identifier', '') or '')
                if ident:
                    names.add(ident)
        except Exception:
            pass
    except Exception:
        pass
    return names


def _call(op_id, **kwargs):
    if not _operator_exists(op_id):
        return False
    op = _operator_proxy(op_id)
    names = _operator_property_names(op_id)
    safe = {str(k): v for k, v in dict(kwargs or {}).items() if str(k) in names}
    for args, call_kwargs in ((("EXEC_DEFAULT",), safe), (tuple(), safe), (("EXEC_DEFAULT",), {}), (tuple(), {})):
        try:
            result = op(*args, **call_kwargs)
            try:
                return 'CANCELLED' not in set(result or set())
            except Exception:
                return True
        except TypeError:
            continue
        except Exception:
            continue
    return False


def _storage_report_path(name):
    try:
        from . import storage
        return Path(storage.runtime_file(str(name), 'reports', create=True))
    except Exception:
        path = (Path(os.environ.get('APPDATA')) / 'Blender Foundation' / 'Blender' / '5.1' / 'config' / 'Smart_UV_Suite' / 'user_data' / 'runtime' / 'reports' / str(name)) if os.environ.get('APPDATA') else (Path.home() / '.config' / 'blender' / '5.1' / 'config' / 'Smart_UV_Suite' / 'user_data' / 'runtime' / 'reports' / str(name))
        path.parent.mkdir(parents=True, exist_ok=True)
        return path


def _set_attr_if_present(obj, name, value):
    if obj is None:
        return False
    try:
        getattr(obj, str(name))
    except Exception:
        return False
    try:
        setattr(obj, str(name), value)
        return True
    except Exception:
        return False


def apply_profile(profile, context=None):
    ws = _ws(context)
    key = str(profile or '').strip().upper() or 'PRODUCTION'
    data = dict(_PROFILE_DATA.get(key) or _PROFILE_DATA['PRODUCTION'])
    if ws is None:
        return False
    for name, value in data.items():
        _set_attr_if_present(ws, name, value)
    _set_attr_if_present(ws, 'smart_quality_profile', key)
    try:
        from . import npanel_persistence
        npanel_persistence.save_workspace(context or bpy.context, ws)
    except Exception:
        pass
    return True


def _update_score_fields(context=None, payload=None):
    ws = _ws(context)
    if ws is None:
        return
    payload = dict(payload or {})
    metrics = dict(payload.get('metrics') or {})
    score = metrics.get('quality_score', payload.get('score', 0.0))
    grade = str(metrics.get('quality_grade', payload.get('grade', 'N/A')) or 'N/A')
    try:
        _set_attr_if_present(ws, 'smart_last_score', float(score or 0.0))
    except Exception:
        pass
    _set_attr_if_present(ws, 'smart_last_grade', grade)
    _set_attr_if_present(ws, 'smart_last_action', str(payload.get('action') or ''))
    _set_attr_if_present(ws, 'smart_last_report_time', time.strftime('%Y-%m-%d %H:%M:%S'))
    try:
        from . import npanel_persistence
        npanel_persistence.save_workspace(context or bpy.context, ws)
    except Exception:
        pass


def analyze(context=None):
    try:
        from . import smart_uv_precision as precision
        metrics = precision.collect_metrics(context or bpy.context, selected_only=False)
    except Exception as exc:
        metrics = {'ok': False, 'error': str(exc).splitlines()[0], 'quality_score': 0.0, 'quality_grade': 'ERROR'}
    data = {
        'schema': 'smart_uv_cockpit_report_v1',
        'action': 'ANALYZE',
        'timestamp': time.strftime('%Y-%m-%dT%H:%M:%S'),
        'metrics': metrics,
    }
    try:
        path = _storage_report_path('smart_uv_cockpit_report.json')
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
        try:
            text = bpy.data.texts.get('Smart_UV_Suite_Cockpit_Report') or bpy.data.texts.new('Smart_UV_Suite_Cockpit_Report')
            text.clear(); text.write(json.dumps(data, ensure_ascii=False, indent=2))
        except Exception:
            pass
    except Exception:
        pass
    _update_score_fields(context, data)
    return bool(metrics.get('ok', False) or 'quality_score' in metrics)


def _precision(action, context=None):
    try:
        from . import smart_uv_precision as precision
        return bool(precision.run_precision_action(action, context or bpy.context))
    except Exception:
        return False


def _smart(action, context=None):
    try:
        from . import uv_router as smart
        return bool(smart.run_action(action, context or bpy.context))
    except Exception:
        return False


def _run_sequence(sequence, context=None):
    ok_any = False
    for kind, value in sequence:
        if kind == 'precision':
            ok_any = _precision(value, context) or ok_any
        elif kind == 'smart':
            ok_any = _smart(value, context) or ok_any
        elif kind == 'op':
            if isinstance(value, (tuple, list)):
                ok_any = _call(value[0], **(value[1] if len(value) > 1 and isinstance(value[1], dict) else {})) or ok_any
            else:
                ok_any = _call(value) or ok_any
    analyze(context)
    return ok_any


_INTENT_SEQUENCES = {
    'PRODUCTION_FINISH': [('precision', 'SUPER_REPAIR'), ('precision', 'SUPER_DENSITY'), ('precision', 'SUPER_PACK')],
    'HERO_ASSET': [('op', ('uv.suv_stack_topology_groups', {'scope': 'ALL', 'rotation_step': '15', 'allow_mirror': True, 'preserve_tile': True})), ('precision', 'SUPER_AUTO'), ('precision', 'SUPER_PACK')],
    'HARD_SURFACE': [('smart', 'RECTIFY'), ('smart', 'GRIDIFY'), ('smart', 'QUADRIFY'), ('precision', 'SUPER_DENSITY'), ('precision', 'SUPER_PACK')],
    'ORGANIC': [('precision', 'SUPER_UNWRAP'), ('precision', 'SUPER_DENSITY'), ('smart', 'STRETCH_HEATMAP')],
    'LIGHTMAP': [('smart', 'UE_LIGHTMAP'), ('precision', 'SUPER_SAFE_AUTO'), ('op', ('uv.lightmap_pack', {})), ('precision', 'SUPER_PACK')],
    'UDIM_MASTER': [('smart', 'GROUPS_TO_UDIM'), ('precision', 'LOCK_OVERLAP_PACK'), ('precision', 'SUPER_ANALYZE')],
    'REPAIR_PACK': [('precision', 'SUPER_REPAIR'), ('precision', 'SUPER_PACK')],
    'ONLY_ANALYZE': [('precision', 'SUPER_ANALYZE')],
}


def run_intent(intent, context=None):
    key = str(intent or '').strip().upper() or 'PRODUCTION_FINISH'
    return _run_sequence(_INTENT_SEQUENCES.get(key) or _INTENT_SEQUENCES['PRODUCTION_FINISH'], context or bpy.context)


class SMARTUVCOCKPIT_OT_apply_profile(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.cockpit_apply_profile'
    bl_label = 'Apply Quality Profile'
    bl_description = 'Apply a saved production profile to the UV Suite N-panel values: density, padding, similarity tolerance, precision level and layout strategy.'
    bl_options = {'UNDO'}

    def execute(self, context):
        profile = str(getattr(self, 'profile', '') or '')
        if apply_profile(profile, context):
            self.report({'INFO'}, _tr(context, 'UV Suite quality profile applied.', 'UV Suite品質プロファイルを適用しました。'))
            return {'FINISHED'}
        self.report({'WARNING'}, _tr(context, 'UV Suite workspace settings are not available.', 'UV Suiteワークスペース設定が利用できません。'))
        return {'CANCELLED'}


class SMARTUVCOCKPIT_OT_run(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.cockpit_run'
    bl_label = 'Run Cockpit Route'
    bl_description = 'Run a short production intent route that combines analysis, repair, precision unwrap, texel density, packing and reports.'
    bl_options = {'UNDO'}

    def execute(self, context):
        intent = str(getattr(self, 'intent', '') or '')
        if run_intent(intent, context):
            self.report({'INFO'}, _tr(context, 'UV Suite cockpit route completed.', 'UV Suiteコックピットルートが完了しました。'))
            return {'FINISHED'}
        self.report({'WARNING'}, _tr(context, 'The cockpit route could not complete in the current context.', '現在のコンテキストではコックピットルートを完了できませんでした。'))
        return {'CANCELLED'}


class SMARTUVCOCKPIT_OT_analyze(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.cockpit_analyze'
    bl_label = 'Analyze Quality'
    bl_description = 'Measure UV quality, density spread, flipped/zero faces and write a cockpit report under Blender CONFIG/Smart_UV_Suite.'
    bl_options = set()

    def execute(self, context):
        if analyze(context):
            self.report({'INFO'}, _tr(context, 'UV Suite quality report written.', 'UV Suite品質レポートを書き出しました。'))
            return {'FINISHED'}
        self.report({'WARNING'}, _tr(context, 'Could not measure UV quality in the current context.', '現在のコンテキストではUV品質を測定できませんでした。'))
        return {'CANCELLED'}


class SMARTUVCOCKPIT_OT_texel_density_tools(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.cockpit_texel_density_tools'
    bl_label = 'Texel Density Tools'
    bl_description = 'Cockpit-internal texel-density helper. The public N-panel entry is smart_uv_suite.texel_density_tools.'
    bl_options = {'UNDO'}

    def execute(self, context):
        ws = _ws(context)
        mode = str(getattr(self, 'mode', 'SET_WORKFLOW') or 'SET_WORKFLOW')
        try:
            tex = int(getattr(ws, 'canvas_size', 2048) or 2048)
        except Exception:
            tex = 2048
        try:
            density = float(getattr(ws, 'workflow_density', 1024.0) or 1024.0)
        except Exception:
            density = 1024.0
        if mode == 'GET':
            ok = _call('uv.suv_texel_get', scope='SELECTED', texture_size=tex, use_world_scale=True)
        elif mode == 'NORMALIZE':
            ok = _call('uv.suv_texel_normalize', mode='VALUE', value_density=density, texture_size=tex, use_world_scale=True, skip_pinned=True)
        else:
            ok = _call('uv.suv_texel_set', scope='SELECTED', target_density=density, texture_size=tex, use_world_scale=True, skip_pinned=True, keep_tile=True)
        if bool(getattr(self, 'use_checker', False)):
            _call('object.suv_create_checker_material')
        analyze(context)
        if ok:
            return {'FINISHED'}
        self.report({'WARNING'}, _tr(context, 'No compatible texel-density route is registered yet.', '互換テクセル密度ルートがまだ登録されていません。'))
        return {'CANCELLED'}


# Materialize RNA properties explicitly.  This file intentionally avoids relying
# on postponed annotation evaluation so Blender 5.x receives real bpy.props.
SMARTUVCOCKPIT_OT_apply_profile.__annotations__ = {
    'profile': bpy.props.EnumProperty(name='Profile', items=_PROFILE_ITEMS, default='PRODUCTION', options={'SKIP_SAVE'}),
}
SMARTUVCOCKPIT_OT_run.__annotations__ = {
    'intent': bpy.props.EnumProperty(name='Intent', items=_INTENT_ITEMS, default='PRODUCTION_FINISH', options={'SKIP_SAVE'}),
}
SMARTUVCOCKPIT_OT_texel_density_tools.__annotations__ = {
    'mode': bpy.props.EnumProperty(
        name='Mode',
        items=(
            ('SET_WORKFLOW', 'Apply Workflow Density', 'Apply the saved UV Suite workflow density.'),
            ('GET', 'Get Density', 'Measure current density and update reports.'),
            ('NORMALIZE', 'Normalize Density', 'Normalize selected islands to the workflow density.'),
        ),
        default='SET_WORKFLOW',
        options={'SKIP_SAVE'},
    ),
    'use_checker': bpy.props.BoolProperty(name='Create Checker', default=False, options={'SKIP_SAVE'}),
}

_CLASSES = (
    SMARTUVCOCKPIT_OT_apply_profile,
    SMARTUVCOCKPIT_OT_run,
    SMARTUVCOCKPIT_OT_analyze,
    SMARTUVCOCKPIT_OT_texel_density_tools,
)
_REGISTERED = []


def register():
    try:
        from .bootstrap_common import safe_register_class
    except Exception:
        safe_register_class = None
    for cls in _CLASSES:
        ok = False
        if callable(safe_register_class):
            try:
                ok = bool(safe_register_class(cls))
            except Exception:
                ok = False
        if not ok:
            try:
                _suv_resource.register_class(cls)
                ok = True
            except Exception:
                ok = False
        if ok and cls not in _REGISTERED:
            _REGISTERED.append(cls)


def unregister():
    for cls in reversed(_REGISTERED or list(_CLASSES)):
        try:
            _suv_resource.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED.clear()


__all__ = ['register', 'unregister', 'apply_profile', 'run_intent', 'analyze']
