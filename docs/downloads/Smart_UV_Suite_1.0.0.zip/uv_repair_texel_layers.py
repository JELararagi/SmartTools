def build_handlers(api):
    def run(context, op):
        obj = context.active_object
        if obj is None or obj.type != 'MESH' or not op.name:
            return False
        layer = obj.data.uv_layers.get(op.name)
        if layer is None:
            return False
        obj.data.uv_layers.active = layer
        return True

    def invoke(context, op, event):
        if op.name:
            return op.execute(context)
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            return {'CANCELLED'}
        return context.window_manager.invoke_popup(op, width=350)

    def draw(op, context):
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            return
        layout = op.layout
        layout.template_list('MESH_UL_uvmaps', '', obj.data, 'uv_layers',
                             obj.data.uv_layers, 'active_index', rows=4)
        for operation in ('add', 'duplicate', 'rename_active', 'set_render', 'remove', 'reorder'):
            layout.operator('mesh.suv_uvmap_' + operation)

    return {
        'smart_uv_suite.texel_layers_manager': api.Handler(run,
            'Manage the active mesh UV maps and choose the active UV map.',
            'アクティブメッシュのUVマップを管理し、作業用マップを切り替えます。', invoke, draw),
        'smart_uv_suite.texel_stage_uvmap': api.Handler(
            api._run_uv_layout('suv_native_stage_uvmap', namespace='mesh', mode='mode',
                               target_name='name', base_name='name'),
            'Run the chosen UV map management action on the selected meshes.',
            '選択メッシュに指定されたUVマップ管理操作を実行します。'),
    }
