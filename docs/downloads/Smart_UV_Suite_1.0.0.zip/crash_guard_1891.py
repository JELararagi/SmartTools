# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Crash guards for Smart UV Suite 1.8.91.

The guard is deliberately narrow: it only touches Smart UV Suite panel classes and
Smart UV Suite deferred workspace-save timers.  It does not modify theme colors,
Region Overlap, toolbars, keymaps, or any non-Smart-UV panel.
"""
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

import gc
import sys
import types

import bpy

_ROOT_IDNAMES = {
    "SMARTUVSUITE_PT_1881_view3d_body",
    "SMARTUVSUITE_PT_1881_uv_editor_body",
}
_ROOT_CLASSNAMES = {
    "SMARTUVSUITE_PT_1881_VIEW3D_BODY",
    "SMARTUVSUITE_PT_1881_UV_EDITOR_BODY",
}


def _empty_header(self, context):
    del self, context
    return None


def _text(value: object) -> str:
    try:
        return str(value or "")
    except Exception:
        return ""


def _is_smart_uv_root_panel(cls: object) -> bool:
    if not isinstance(cls, type):
        return False
    try:
        if _text(getattr(cls, "bl_idname", "")) in _ROOT_IDNAMES:
            return True
        if _text(getattr(cls, "__name__", "")) in _ROOT_CLASSNAMES:
            return True
    except Exception:
        pass
    return False


def repair_panel_callbacks() -> int:
    """Ensure Smart UV Suite root panel callbacks exist and remain standard."""
    changed = 0
    try:
        panels = ()
    except Exception:
        panels = ()
    for cls in panels:
        if not _is_smart_uv_root_panel(cls):
            continue
        try:
            cls.bl_options = set()
        except Exception:
            pass
        try:
            cls.draw_header = _empty_header
            cls.draw_header_preset = _empty_header
            changed += 1
        except Exception:
            pass
    try:
        from . import npanel_body_1881
        for cls in getattr(npanel_body_1881, "_ROOTS", ()) or ():
            try:
                cls.bl_options = set()
                cls.draw_header = _empty_header
                cls.draw_header_preset = _empty_header
                changed += 1
            except Exception:
                pass
    except Exception:
        pass
    return changed



def _cancel_known_workspace_timer(module) -> int:
    if module is None:
        return 0
    callback = getattr(module, '_flush_deferred_workspace_save', None)
    removed = int(bool(_suv_resource.timer_unregister(callback))) if callable(callback) else 0
    try:
        module._DEFERRED_SAVE_WS = None
        module._DEFERRED_SAVE_SCENE_NAME = ''
        module._DEFERRED_SAVE_PENDING = False
    except Exception:
        pass
    return removed



def cancel_legacy_deferred_workspace_timers(*, scan_stale_functions: bool = False) -> int:
    """No gc/sys.modules sweep; exact current callback cancellation only."""
    del scan_stale_functions
    try:
        from . import interaction_1871 as module
    except Exception:
        module = None
    return _cancel_known_workspace_timer(module)


def install(package_globals=None, context=None, *, scan_stale_functions: bool = False) -> None:
    del package_globals, context
    cancel_legacy_deferred_workspace_timers(scan_stale_functions=scan_stale_functions)
    repair_panel_callbacks()
    try:
        from . import npanel_persistence as np
        # Reset the source-parsed property name cache after live updates.
        if hasattr(np, "_WORKSPACE_PROP_NAMES_CACHE"):
            np._WORKSPACE_PROP_NAMES_CACHE = None
    except Exception:
        pass


def unregister() -> None:
    cancel_legacy_deferred_workspace_timers(scan_stale_functions=True)
    repair_panel_callbacks()
