# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

'Lazy UV Suite help popup tool_runtime.\n\nThis module is intentionally not imported during add-on startup or normal N-panel\npainting.  The small bridge operator in ``__init__.py`` imports this module only\nwhen the user clicks a Help button.  All heavy help text, operator inspection,\nsettings extraction, and popup drawing is kept here so the standard N-panel stays\nlight and simple.\n'

from __future__ import annotations

from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Any, Iterable
import json
import unicodedata

import bpy

try:
    import blf
except Exception:  # pragma: no cover - available only inside Blender
    blf = None


def _locale_mod():
    try:
        from . import text_translation as _tlr
        return _tlr
    except Exception:
        return None


def _is_ja(context=None) -> bool:
    mod = _locale_mod()
    try:
        if mod is not None:
            return bool(mod.is_japanese(context))
    except Exception:
        pass
    try:
        return str(getattr(getattr(bpy.context, 'preferences', None), 'view', None).language or '').lower().startswith('ja')
    except Exception:
        return False


def _pick(en: str, ja: str, context=None) -> str:
    mod = _locale_mod()
    try:
        if mod is not None:
            return str(mod.pick(str(en or ''), str(ja or ''), context=context))
    except Exception:
        pass
    return str(ja if _is_ja(context) else en)


def _inline(text: Any, context=None) -> str:
    mod = _locale_mod()
    value = '' if text is None else str(text)
    try:
        if mod is not None:
            fn = getattr(mod, 'sanitize_text', None) or getattr(mod, 'inline', None) or getattr(mod, 'translate_text', None)
            if callable(fn):
                try:
                    return str(fn(value, context=context))
                except TypeError:
                    return str(fn(value))
    except Exception:
        pass
    # Minimal fallback for English / Japanese inline pairs.
    if '/' in value:
        left, right = [part.strip() for part in value.split('/', 1)]
        if any('\u3040' <= ch <= '\u30ff' or '\u4e00' <= ch <= '\u9fff' for ch in right):
            return right if _is_ja(context) else left
        if any('\u3040' <= ch <= '\u30ff' or '\u4e00' <= ch <= '\u9fff' for ch in left):
            return left if _is_ja(context) else right
    return value


HELP_POPUP_WIDTH = 920
# ``invoke_props_dialog(width=...)`` receives the popup width in UI pixels.
# Help labels are wrapped against that popup width, not against fixed English or
# Japanese character counts.  The padding values reserve the dialog margins,
# nested box borders, and optional icon space so a Blender ``layout.label`` line
# is split only when its measured text would exceed the popup body width.
_POPUP_CONTENT_PADDING_PX = 72
_POPUP_ICON_RESERVE_PX = 28
_POPUP_NESTED_INDENT_PX = 32
_POPUP_MIN_TEXT_WIDTH_PX = 180
_HELP_FONT_SIZE = 12


def _has_cjk(text: str) -> bool:
    for ch in str(text or ''):
        code = ord(ch)
        if (
            0x3040 <= code <= 0x30FF
            or 0x3400 <= code <= 0x4DBF
            or 0x4E00 <= code <= 0x9FFF
            or 0xF900 <= code <= 0xFAFF
        ):
            return True
    return False


def _visual_width(text: str) -> int:
    total = 0
    for ch in str(text or ''):
        if ch == '\t':
            total += 4
        elif unicodedata.east_asian_width(ch) in {'F', 'W'}:
            total += 2
        else:
            total += 1
    return total


def _ui_scale(context=None) -> float:
    prefs = None
    try:
        prefs = getattr(context, 'preferences', None)
    except Exception:
        prefs = None
    if prefs is None:
        try:
            prefs = bpy.context.preferences
        except Exception:
            prefs = None
    for owner_name in ('view', 'system'):
        try:
            owner = getattr(prefs, owner_name, None)
            value = getattr(owner, 'ui_scale', None)
            if value:
                return max(0.5, float(value))
        except Exception:
            pass
    return 1.0


def _set_help_font_size(context=None) -> None:
    if blf is None:
        return
    size = max(8, int(round(_HELP_FONT_SIZE * _ui_scale(context))))
    try:
        blf.size(0, size)
    except TypeError:
        try:
            blf.size(0, size, 72)
        except Exception:
            pass
    except Exception:
        pass


def _text_width_px(text: str, context=None) -> float:
    value = str(text or '')
    if not value:
        return 0.0
    if blf is not None:
        try:
            _set_help_font_size(context)
            return float(blf.dimensions(0, value)[0])
        except Exception:
            pass
    # Fallback used by static tests and by unusual Blender builds where BLF is
    # unavailable.  It is still derived from glyph display width and UI scale,
    # not from a fixed wrap column count.
    return float(_visual_width(value)) * (_HELP_FONT_SIZE * _ui_scale(context) * 0.55)


def _wrap_width(context=None, requested: int | float | None = None, text: str = '', *, icon: bool = False) -> int:
    """Return the measured pixel width available for one popup label line."""
    width = float(HELP_POPUP_WIDTH) - float(_POPUP_CONTENT_PADDING_PX)
    if requested is not None:
        try:
            req = float(requested)
            if req > 0:
                width = min(width, req)
        except Exception:
            pass
    if icon:
        width -= float(_POPUP_ICON_RESERVE_PX)
    return max(_POPUP_MIN_TEXT_WIDTH_PX, int(width))


def _split_pixel_token(text: str, width_px: int, context=None) -> list[str]:
    width_px = max(_POPUP_MIN_TEXT_WIDTH_PX, int(width_px or _wrap_width(context)))
    lines: list[str] = []
    buf = ''
    for ch in str(text or ''):
        candidate = buf + ch
        if buf and _text_width_px(candidate, context) > width_px:
            lines.append(buf.rstrip())
            buf = ch
        else:
            buf = candidate
    if buf.strip():
        lines.append(buf.rstrip())
    return lines


def _wrap_pixel_line(text: str, width_px: int, context=None) -> list[str]:
    width_px = max(_POPUP_MIN_TEXT_WIDTH_PX, int(width_px or _wrap_width(context)))
    text = str(text or '').strip()
    if not text:
        return []
    if _text_width_px(text, context) <= width_px:
        return [text]

    words = [part.strip() for part in text.split(' ') if part.strip()]
    if len(words) <= 1:
        return _split_pixel_token(text, width_px, context)

    lines: list[str] = []
    current = ''
    for word in words:
        if _text_width_px(word, context) > width_px:
            if current:
                lines.append(current.rstrip())
                current = ''
            pieces = _split_pixel_token(word, width_px, context)
            if pieces:
                lines.extend(pieces[:-1])
                current = pieces[-1]
            continue
        candidate = word if not current else current + ' ' + word
        if _text_width_px(candidate, context) <= width_px:
            current = candidate
        else:
            if current:
                lines.append(current.rstrip())
            current = word
    if current:
        lines.append(current.rstrip())
    return lines


def _textwrap_lines(text: str, context=None, *, width: int | float | None = None, icon: bool = False) -> list[str]:
    width_value = _wrap_width(context, width, text, icon=icon)
    out: list[str] = []
    for para in str(text or '').splitlines():
        para = para.strip()
        if not para:
            continue
        out.extend(_wrap_pixel_line(para, width_value, context) or [para])
    return out


def _label(layout, text: str, *, icon: str = '') -> None:
    value = str(text or '')
    try:
        if icon:
            layout.label(text=value, icon=icon)
        else:
            layout.label(text=value)
    except TypeError:
        layout.label(text=value)


def _wrap(layout, text: str, context=None, *, width: int | None = None, icon: str = '') -> None:
    text = _inline(text, context).strip()
    if not text:
        return
    lines = _textwrap_lines(text, context, width=width, icon=bool(icon)) or [text]
    first = True
    for line in lines:
        _label(layout, line, icon=icon if first else '')
        first = False


def _draw_wrapped_title(layout, text: str, context=None, *, icon: str = 'QUESTION') -> None:
    _wrap(layout, text, context, width=_wrap_width(context), icon=icon)


def _summary_separator(context=None) -> str:
    return ' ・ ' if _is_ja(context) else ' — '


def _draw_setting_summary(layout, context, item: dict[str, str], *, icon: str = 'DOT') -> None:
    name = item.get('name') or item.get('id') or ''
    ident = item.get('id') or ''
    pieces = [f"{name} ({ident})" if ident else str(name)]
    if item.get('type'):
        pieces.append(str(item.get('type')))
    if item.get('default'):
        pieces.append(f"{_pick('Default', '既定値', context)}: {item.get('default')}")
    _wrap(layout, _summary_separator(context).join(piece for piece in pieces if piece), context, width=_wrap_width(context), icon=icon)


def _friendly_setting_tip(item: dict[str, str], context=None) -> str:
    typ = str(item.get('type') or '').lower()
    if 'boolean' in typ or typ == 'bool':
        return _pick('Turn this on when you want the behavior active; turn it off to leave the command unchanged.', 'この動作を使う時はオンにし、不要な時はオフにします。', context)
    if 'enum' in typ:
        return _pick('Choose one mode from the list.  Each choice changes how the command interprets the current selection or output.', '一覧からモードを1つ選びます。選択肢ごとに、現在の選択や出力の扱いが変わります。', context)
    if any(token in typ for token in ('int', 'float', 'number')):
        return _pick('Enter the numeric amount used by the command.  Smaller values usually make a gentler change; larger values make a stronger change.', 'コマンドで使う数値量を入力します。小さい値は弱め、大きい値は強めの変更になります。', context)
    if 'string' in typ or 'text' in typ:
        return _pick('Enter the name, label, file name, or text value used by this command.', 'このコマンドで使う名前、ラベル、ファイル名、または文字列を入力します。', context)
    return _pick('Adjust this before running the related command when you need behavior different from the default.', '既定動作から変えたい場合は、関連コマンドを実行する前に調整します。', context)


def _draw_setting_detail(layout, context, item: dict[str, str], *, icon: str = 'DOT') -> None:
    _draw_setting_summary(layout, context, item, icon=icon)
    desc = str(item.get('description') or '').strip()
    uid = _ui_descriptions_module()
    try:
        if uid is not None:
            specific = str(uid.property_description(item.get('id', ''), item.get('type', ''), item.get('name', ''), context) or '').strip()
            lowered = desc.lower()
            if specific and (not desc or len(desc) < 32 or lowered in {'property', 'option', 'setting'} or 'related tool' in lowered):
                desc = specific
    except Exception:
        pass
    if not desc:
        desc = _pick('No description is provided by the property.', 'このプロパティには説明文がありません。', context)
    _wrap(layout, desc, context)
    usage = ''
    try:
        if uid is not None:
            usage = str(uid.property_usage(item.get('id', ''), item.get('type', ''), item.get('name', ''), context) or '').strip()
    except Exception:
        usage = ''
    _wrap(layout, usage or _friendly_setting_tip(item, context), context, icon='QUESTION')
    if item.get('enum'):
        _draw_enum_choices(layout, context, item.get('enum', ''))

def _draw_enum_choices(layout, context, enum_text: str) -> None:
    enum_text = str(enum_text or '').strip()
    if not enum_text:
        return
    _wrap(layout, _pick('Choices:', '選択肢:', context), context, width=_wrap_width(context), icon='TRIA_RIGHT')
    for choice in [part.strip() for part in enum_text.split(';') if part.strip()]:
        _wrap(layout, choice, context, width=_wrap_width(context, _wrap_width(context) - _POPUP_NESTED_INDENT_PX), icon='DOT')


@dataclass(frozen=True)
class HelpEntry:
    title_en: str
    title_ja: str
    overview_en: str
    overview_ja: str
    usage_en: str
    usage_ja: str
    operators: tuple[str, ...] = field(default_factory=tuple)
    workspace_keywords: tuple[str, ...] = field(default_factory=tuple)
    extra_settings_en: tuple[str, ...] = field(default_factory=tuple)
    extra_settings_ja: tuple[str, ...] = field(default_factory=tuple)
    related_alias: str = ''
    include_integrated_preferences: bool = False


GROUPS: dict[str, HelpEntry] = {
    'always_on': HelpEntry(
        'Always-on Toggles', '常時機能切り替え',
        'Controls only the UV Suite features that genuinely need continuous state: Blender live UV switches, synchronization handlers, live overlays, modal helpers, and watcher callbacks.  Ordinary one-shot UV commands are not listed here so they stay UI-only until executed.',
        '継続状態が必要なUV Suite機能だけを管理します。対象はBlenderのライブUV切り替え、同期ハンドラー、ライブオーバーレイ、モーダル補助、監視コールバックです。通常の一回実行UVコマンドはここに出さず、実行されるまでUI表示のみの軽量状態にします。',
        'Open the group only when you need to change background behavior.  Turn on the required item before using that live feature, and turn it off after the task to keep Blender light.  The button highlight follows the saved enabled state.',
        '背景動作を変更する時だけグループを開きます。必要なライブ機能だけ有効にし、作業後は無効にしてBlenderを軽く保ちます。ボタンの青い表示は保存済みの有効状態に連動します。',
        operators=('smart_uv_suite.toggle_always_on_feature', 'smart_uv_suite.toggle_persistent_feature'),
        extra_settings_en=(
            'Each row is drawn from a real N-panel BoolProperty, so Blender controls the selected state and enabled rows keep the blue active overlay consistently.',
            'When an item belongs to an integrated add-on, enabling it may lazy-initialize only that add-on; disabling it stores the off state and stops the matching captured tool_runtime where supported.',
        ),
        extra_settings_ja=(
            '各行は実際のNパネルBoolPropertyとして描画されるため、有効行の青い選択表示はBlender側のプロパティ状態に安定して連動します。',
            '統合アドオン由来の項目は、有効化時に対象アドオンだけを遅延初期化する場合があります。無効化時はオフ状態を保存し、対応している捕捉済みランタイムを停止します。',
        ),
    ),
    'uv_layout_board': HelpEntry(
        'UV Layout Board', 'UVレイアウトボード',
        'A compact Smart UV compact board for high-frequency UV layout work.  It groups tile fitting, island sorting, a 3x3 alignment pad, rotate/mirror cleanup, straighten/rectify tools, texel-density buttons, and issue-selection buttons in one place.',
        '高頻度のUVレイアウト作業向けに、Smart UV Suite reference風のコンパクトボードとして整理した項目です。タイル収め、アイランド並べ替え、3x3整列パッド、回転・反転整理、直線化・矩形化、テクセル密度、問題選択を一か所にまとめています。',
        'Use this board immediately after unwrapping and before final packing.  Set Size and Padding first, use Crop/Fill/Fit or the align pad to shape the layout, then check density and select problems such as overlap, flipped islands, zero-area UVs, boundaries, and UDIM crossing.',
        '展開後から最終パック前までに使います。先にサイズと余白を設定し、クロップ・フィル・フィットや整列パッドで配置を整え、その後に密度確認や、重なり・反転・ゼロ面積・境界・UDIM跨ぎなどの問題選択を行います。',
        operators=('smart_uv_suite.uv_layout_action', 'uv.suv_crop_tile', 'uv.suv_fill_tile', 'uv.suv_align_islands', 'uv.suv_sort_islands', 'uv.suv_rotate_islands', 'uv.suv_flip_islands', 'uv.suv_texel_get', 'uv.suv_texel_set', 'uv.suv_inspector_select'),
        workspace_keywords=('canvas_size', 'fit_padding_px', 'pack_group_mode', 'stack_group_mode', 'workflow_density', 'checker_size'),
        extra_settings_en=(
            'The compact action buttons reuse UV Suite core operators, so they keep Undo support and respect the current mesh/UV selection.',
            'The Size and Padding fields are saved from the N-panel and are reused by Crop, Fill, Fit, Sort, and density-related tools.',
        ),
        extra_settings_ja=(
            'コンパクト操作ボタンはUV Suite標準オペレーターを再利用するため、Undoに対応し、現在のメッシュ/UV選択を尊重します。',
            'サイズと余白はNパネルから保存され、クロップ、フィル、フィット、並べ替え、密度系ツールで再利用されます。',
        ),
    ),
    'uv_router': HelpEntry(
        'UV Suite Smart', 'UV Suite Smart',
        'A document-synced upper-compatible UV layer that maps the researched feature lists to local UV Suite workflows.  It covers one-click automatic UV, seam and unwrap variants, packing and UDIM workflows, Smart UV compact precision layout, texel density, inspection, UV-map management, atlas and bake preparation, and external-tool-equivalent bridge routes.',
        '添付の調査リストにある機能を、UV Suite内のローカルワークフローへ割り当てる文書同期型の上位互換UVレイヤーです。ワンクリック自動UV、シームと展開方式、パックとUDIM、Smart UV Suite reference風の精密配置、テクセル密度、検査、UVマップ管理、アトラスとベイク準備、Smart UV Suite相当のブリッジルートを扱います。',
        'Open this section when you want a single entry point for features described in the attached research documents.  Use the top quick buttons for broad automation, open each group for precise actions, or open the document matrix to run a route from an individual documented feature.  External GPU, cloud, and proprietary engines are not copied; UV Suite Smart runs the closest safe Blender/UV Suite route available in the current context.',
        '添付調査文書の機能を一つの入口から使いたい時に開きます。上部のクイックボタンは大まかな自動化、各グループは精密操作、文書機能マトリクスは個別の記載機能に対応するルート実行に使います。外部GPU、クラウド、専有エンジンはコピーせず、現在のコンテキストで使える最も近い安全なBlender/UV Suiteルートを実行します。',
        operators=(
            'smart_uv_suite.uv_router_action',
            'smart_uv_suite.uv_router_feature',
            'smart_uv_suite.uv_router_tool',
            'smart_uv_suite.uv_router_write_matrix',
            'uv.suv_auto_uv_profile',
            'uv.suv_apply_external_compat_target',
            'uv.suv_pack_pro',
            'uv.suv_priority_density_pack',
            'uv.suv_inspector_scan',
        ),
        workspace_keywords=('canvas_size', 'fit_padding_px', 'workflow_density', 'pack_group_mode', 'stack_group_mode', 'udim', 'atlas', 'checker_size'),
        extra_settings_en=(
            'The coverage matrix is written under Blender CONFIG/Smart_UV_Suite/user_data/runtime/reports. The installed Extension package is never modified.',
            'Buttons are hidden automatically if a required operator is not registered, avoiding unknown-operator console spam.',
        ),
        extra_settings_ja=(
            '対応マトリクスは Blender config 内の Smart_UV_Suite/reports へ書き出され、外部へ散らばりません。',
            '必要なオペレーターが未登録の場合、そのボタンは自動的に非表示になり、unknown operatorの連続出力を避けます。',
        ),
    ),
    'workspace_header': HelpEntry(
        'UV Suite Workflow Header', 'UV Suiteワークフローヘッダー',
        'Shows the current UV context and the main workflow tabs.  It is the starting point for validating the scene, repairing missing UV prerequisites, and switching between tool categories.',
        '現在のUV状態とメインの作業カテゴリを表示します。シーン検証、UV前提条件の修復、ツールカテゴリ切り替えの起点です。',
        'Select a mesh, choose the category that matches the current task, then use Validate or Auto Repair before destructive batch operations when the scene state is uncertain.',
        'メッシュを選択し、作業内容に合うカテゴリを選びます。シーン状態に不安がある場合は、破壊的な一括処理の前に検証または自動修復を使います。',
        operators=('uv.suv_workspace_validate', 'uv.suv_workspace_auto_repair', 'uv.suv_write_tool_runtime_snapshot', 'uv.suv_clear_tool_runtime_log'),
        workspace_keywords=('main_tab', 'show_', 'ui_', 'density', 'padding', 'margin'),
    ),
    'category_workflow': HelpEntry(
        'Unfold Trim', '展開',
        'Groups seam creation, projection, unwrapping, relax, peel, pelt, and beginner-friendly unwrap entry points.',
        'シーム作成、投影、展開、リラックス、ピール、ペルト、初心者向け展開導線をまとめます。',
        'Cut or generate seams first, choose a projection or unwrap method, then relax or preserve constraints when the shell shape needs cleanup.  Inspect and pack after the unwrap result is stable.',
        '先にシームを切る、または自動生成し、投影・展開方式を選びます。形状を整える必要がある場合はリラックスや制約保持を使い、結果が安定したら確認と配置へ進みます。',
        operators=('uv.suv_auto_unwrap_pro', 'uv.suv_auto_seam_advanced', 'uv.suv_native_projection', 'uv.suv_projection_bridge', 'suv.constraint_unwrap', 'uv.suv_constraint_relax_preserve', 'uv.suv_guided_unwrap_start'),
        workspace_keywords=('seam', 'unwrap', 'project', 'angle', 'margin', 'padding', 'relax', 'pin'),
    ),
    'category_transform': HelpEntry(
        'Align', '整列',
        'Groups straighten, orient, match, stack, rotate, flip, distribute, and precision edit tools used to make UV islands easier to read and pack.',
        '直線化、向き合わせ、形状一致、スタック、回転、反転、分配、精密編集など、UVアイランドを読みやすく配置しやすい形へ整える機能をまとめます。',
        'Use these tools after the first unwrap, before final packing.  Straighten edge loops, match repeated parts, rotate shells to a consistent direction, then re-check overlap and stretch.',
        '初回展開後、最終パック前に使います。エッジループを直線化し、繰り返しパーツを合わせ、シェル方向を揃えてから、重なりやストレッチを再確認します。',
        operators=('uv.suv_align_islands', 'uv.suv_orient_islands', 'uv.suv_rotate_islands', 'uv.suv_flip_islands', 'uv.suv_stack_similar', 'uv.suv_rectify_islands', 'uv.suv_precision_uv_tools'),
        workspace_keywords=('align', 'axis', 'rotate', 'flip', 'stack', 'rectify', 'snap', 'grid'),
    ),
    'category_layout': HelpEntry(
        'Layout Panel', '配置',
        'Groups packing, fitting, texel density, UDIM, trimsheet, hotspot, and tile-oriented finishing tools.',
        'パッキング、フィット、テクセル密度、UDIM、トリムシート、ホットスポット、タイル前提の仕上げ機能をまとめます。',
        'Set the intended tile and padding, normalize density when needed, pack islands, then use checker or reports to confirm there is no unwanted overlap or tile crossing.',
        '対象タイルと余白を決め、必要なら密度を揃え、アイランドをパックします。その後チェッカーやレポートで不要な重なり・タイル跨ぎがないか確認します。',
        operators=('uv.suv_native_uv_action', 'uv.suv_priority_density_pack', 'uv.suv_pack_pro', 'uv.suv_fit_to_bounds', 'uv.suv_fill_tile', 'smart_uv_suite.texel_density_tools', 'uv.suv_layout_autoheal'),
        workspace_keywords=('pack', 'padding', 'margin', 'density', 'udim', 'tile', 'trim', 'hotspot'),
    ),
    'category_analyze': HelpEntry(
        'Check', '確認',
        'Groups checker preview, overlap and stretch inspection, issue selection, reports, and automatic cleanup helpers.',
        'チェッカープレビュー、重なり・ストレッチ検査、問題選択、レポート、自動クリーンアップ補助をまとめます。',
        'Run a visual checker first, scan for measurable issues, select the problematic islands or faces, then fix manually or use the matching automatic helper.  Export a report when the result must be audited.',
        'まず視覚チェッカーを表示し、測定可能な問題をスキャンします。問題のあるアイランドや面を選択し、手動または対応する自動補助で修正します。監査が必要な場合はレポートを書き出します。',
        operators=('uv.suv_inspector_scan', 'uv.suv_inspector_select', 'uv.suv_select_zero_islands', 'uv.suv_select_udim_crossing', 'uv.suv_inspector_write_report', 'object.suv_create_checker_material', 'object.suv_visualize_stretch_heatmap'),
        workspace_keywords=('inspect', 'checker', 'overlap', 'stretch', 'report', 'threshold', 'select'),
    ),
    'category_maps': HelpEntry(
        'UV Maps', 'UVマップ',
        'Groups creation, duplication, rename, active/render switching, role sorting, copy/sync, and export-preview support for UV layers.',
        'UVレイヤーの作成、複製、改名、アクティブ・レンダー切替、役割順整理、コピー・同期、書き出しプレビュー補助をまとめます。',
        'Create or duplicate a map before risky edits, set the active and render UV deliberately, then synchronize selected meshes when multiple objects must share the same layer roles.',
        'リスクのある編集前にUVマップを作成または複製し、アクティブUVとレンダーUVを明示的に設定します。複数オブジェクトで同じレイヤー役割を使う場合は選択メッシュへ同期します。',
        operators=('mesh.suv_uvmap_add', 'mesh.suv_uvmap_duplicate', 'mesh.suv_uvmap_remove', 'mesh.suv_uvmap_rename_active', 'mesh.suv_uvmap_set_active', 'mesh.suv_uvmap_set_render', 'mesh.suv_native_stage_uvmap'),
        workspace_keywords=('uvmap', 'uv_map', 'map', 'render', 'active', 'role', 'name'),
    ),
    'category_symmetry': HelpEntry(
        'Symmetry', '対称',
        'Groups symmetry detection, UV mirroring, symmetric seam operations, pair-based stacking, and repeated-island relationship tools.',
        '対称検出、UVミラー、対称シーム、ペア単位のスタック、繰り返しアイランド関係の整理をまとめます。',
        'Detect candidate pairs first, review the pairing, then run mirror, seam, or stack operations.  Use the safer detect pass before changing UVs on symmetrical production meshes.',
        'まず候補ペアを検出して対応関係を確認し、その後ミラー、シーム、スタックを実行します。制作用対称メッシュでは、UV変更前に安全な検出パスを使います。',
        operators=('uv.suv_sym_detect_pairs', 'uv.suv_sym_mirror_uv', 'uv.suv_sym_stack', 'uv.suv_symmetry_workflow_hub', 'uv.suv_stack_similar'),
        workspace_keywords=('sym', 'mirror', 'axis', 'pair', 'stack'),
    ),
    'category_atlas': HelpEntry(
        'Atlas', 'アトラス',
        'Groups multi-object atlas UV construction, atlas material setup, bake preparation, trimsheet/hotspot support, and final batch reports.',
        '複数オブジェクト向けアトラスUV作成、アトラス材質設定、ベイク準備、トリムシート・ホットスポット補助、最終一括レポートをまとめます。',
        'Build the atlas UV first, create or apply the atlas material, then run bake preparation or the full atlas sequence after object roles and naming are verified.',
        'まずアトラスUVを作成し、アトラス材質を作成・適用します。オブジェクト役割と命名を確認してから、ベイク準備または一括アトラス処理を実行します。',
        operators=('uv.suv_atlas_build_uv_multi', 'uv.suv_atlas_build_mat_apply_multi', 'uv.suv_atlas_bake_multi', 'uv.suv_atlas_run_all_multi', 'uv.suv_atlas_bake_tools', 'object.suv_native_stage_bake'),
        workspace_keywords=('atlas', 'bake', 'material', 'image', 'size', 'low', 'high', 'cage', 'trim'),
    ),
    'stage_prepare': HelpEntry('Prepare & Cut', '準備＆切り分け', 'Detailed seam, unwrap, projection, and relax commands used at the start of a UV workflow.', 'UV作業の初期段階で使うシーム、展開、投影、リラックス系の詳細コマンドです。', 'Use these lower-level commands when the main Unwrap tab is too compact or when you need a specific projection/seam variant.', 'メインの展開タブだけでは足りない場合や、特定の投影・シーム方式が必要な場合に使います。', operators=('uv.suv_auto_seam_advanced','uv.suv_native_projection','uv.suv_projection_bridge','suv.constraint_unwrap','uv.suv_constraint_relax_preserve')),
    'stage_arrange': HelpEntry('Arrange & Match', '整列＆マッチ', 'Detailed alignment, orientation, stacking, matching, and precision transform commands.', '整列、方向合わせ、スタック、形状一致、精密変形の詳細コマンドです。', 'Use after unwrapping and before final packing to make islands consistent and easier to edit.', '展開後、最終配置前にアイランドを揃え、編集しやすくするために使います。', operators=('uv.suv_align_islands','uv.suv_orient_islands','uv.suv_rotate_islands','uv.suv_flip_islands','uv.suv_stack_similar','uv.suv_precision_uv_tools')),
    'stage_mesh': HelpEntry('Mesh-side Helpers', 'メッシュ側補助', 'Mesh-side UV preparation, seam cleanup, and utility actions that support UV editing.', 'UV編集を支えるメッシュ側の準備、シーム整理、補助処理です。', 'Use these when the mesh state, selections, or seam markings must be prepared before UV operations.', 'UV操作前にメッシュ状態、選択、シームマークを整える必要がある場合に使います。', operators=('mesh.suv_clear_seams','mesh.suv_native_stage_mesh','mesh.suv_bake_uv_prep')),
    'stage_layout': HelpEntry('Layout & Density', '配置＆密度', 'Detailed packing, texel density, UDIM, trimsheet, and tile layout commands.', 'パック、テクセル密度、UDIM、トリムシート、タイル配置の詳細コマンドです。', 'Use when the compact Layout tab does not expose the exact packing, density, or tile workflow you need.', 'コンパクトな配置タブに目的のパック・密度・タイル処理がない場合に使います。', operators=('uv.suv_priority_density_pack','uv.suv_pack_pro','uv.suv_density_guard_normalize','smart_uv_suite.texel_density_tools','uv.suv_native_uv_action')),
    'stage_inspect': HelpEntry('Inspect Helpers', '検査補助', 'Detailed scan, selection, checker, heatmap, report, and repair commands.', 'スキャン、選択、チェッカー、ヒートマップ、レポート、修復の詳細コマンドです。', 'Use before exporting or baking, or whenever a layout needs measurable validation.', '書き出しやベイク前、または配置を数値的に確認したい場合に使います。', operators=('uv.suv_inspector_scan','uv.suv_inspector_select','uv.suv_inspector_write_report','object.suv_create_checker_material','object.suv_visualize_stretch_heatmap')),
    'stage_maps': HelpEntry('Maps / Preview / IDs', 'マップ／プレビュー／ID', 'UV map management, texture preview, color-ID, and export-related helper commands.', 'UVマップ管理、テクスチャプレビュー、カラーID、書き出し補助のコマンドです。', 'Use when managing multiple UV layers, preview textures, or ID-style outputs for later baking and export.', '複数UVレイヤー、プレビューテクスチャ、ベイクや書き出し向けID出力を管理する時に使います。', operators=('mesh.suv_native_stage_uvmap','object.suv_native_stage_preview','object.suv_native_stage_color')),
    'stage_bake': HelpEntry('Bake Helpers', 'ベイク補助', 'Atlas, bake-set, naming, role, duplicate, and material-output support commands.', 'アトラス、ベイクセット、命名、役割、重複、マテリアル出力を支えるコマンドです。', 'Use near the end of production after UVs, object roles, and bake naming conventions are mostly stable.', 'UV、オブジェクト役割、ベイク命名規則がある程度固まった制作終盤で使います。', operators=('object.suv_native_stage_bake','uv.suv_atlas_bake_multi','uv.suv_atlas_run_all_multi')),
    'advanced_tools': HelpEntry('Advanced / Complete Tools', '詳細・全ツール', 'A collapsible access point for lower-level commands and complete code-backed tool groups that are not part of the compact main workflow.', 'コンパクトな通常ワークフローに常時表示しない低レベルコマンドや、コード上に存在する完全なツール群へアクセスする折りたたみ入口です。', 'Open this only when a main category does not expose the specific command you need.  The tools inside are grouped by the currently selected workflow category.', 'メインカテゴリに目的のコマンドがない場合だけ開きます。内部のツールは現在選択中の作業カテゴリに合わせて表示されます。'),
    'native_tools': HelpEntry('UV Suite Tool Catalog', 'UV Suiteツール一覧', 'Lists UV Suite operators that exist in the package and groups them by operator namespace.', 'パッケージ内に存在するUV Suiteオペレーターを、オペレーター名前空間ごとに一覧化します。', 'Use this as a safety catalog when a command is not visible in the compact workflow tabs.', 'コンパクトなワークフロータブに表示されていないコマンドを探す安全用一覧として使います。'),
    'internal_tools': HelpEntry('All UV Suite Internal Tools', 'UV Suite内部ツール全一覧', 'Lists registered internal UV Suite operators that were found from the loaded tool_runtime modules.', '読み込まれたランタイムモジュールから検出したUV Suite内部オペレーターを一覧化します。', 'Use this only for audit and recovery.  Prefer the main category UI for normal production work.', '監査や復旧用途でのみ使います。通常制作ではメインカテゴリUIを優先してください。'),
}


# -----------------------------------------------------------------------------
# Stable N-panel section help
# -----------------------------------------------------------------------------
# This block intentionally lives in this lazy help module rather than in the
# N-panel drawing code.  It is evaluated only after the user clicks a Help icon.

def _entry(title_en: str, title_ja: str, overview_en: str, overview_ja: str, usage_en: str, usage_ja: str, *, operators: tuple[str, ...] = (), workspace_keywords: tuple[str, ...] = (), settings_en: tuple[str, ...] = (), settings_ja: tuple[str, ...] = ()) -> HelpEntry:
    return HelpEntry(
        title_en, title_ja,
        overview_en, overview_ja,
        usage_en, usage_ja,
        operators=operators,
        workspace_keywords=workspace_keywords,
        extra_settings_en=settings_en,
        extra_settings_ja=settings_ja,
    )

_COMMON_WORKSPACE_KEYS = (
    'canvas_size', 'workflow_density', 'workflow_pack_after', 'workflow_relax_after',
    'fit_padding_px', 'uv_new_name', 'checker_size', 'checker_image_name',
    'checker_material_name', 'scan_report_name', 'heatmap_max', 'stretch_threshold',
    'pack_group_mode', 'pack_group_layout', 'stack_group_mode', 'similarity_area_tol',
    'similarity_aspect_tol', 'hotspot_cols', 'hotspot_rows', 'hotspot_keep_aspect',
    'hotspot_sort', 'hotspot_fill_order', 'tool_runtime_log_name', 'batch_report_name',
    'support_bundle_name', 'validation_report_name', 'batch_error_policy', 'batch_snapshot_policy',
    'auto_unwrap_mode', 'smart_quality_profile', 'smart_precision_level', 'smart_relax_iterations', 'smart_pack_candidates',
    'smart_margin_strategy', 'smart_lock_overlaps', 'smart_sliver_protection', 'smart_ui_density',
)

_MORE_GROUPS: dict[str, HelpEntry] = {
    'always_on': _entry(
        'Always-on Toggles', '常時機能切り替え',
        'Central switchboard for UV Suite features that must keep a live state: live unwrap, UV selection synchronization, overlay renderers, modal live helpers, and source-tool watchers.  One-shot layout, unwrap, pack, density, and report commands are intentionally not started here.',
        'ライブ展開、UV選択同期、オーバーレイ描画、モーダル補助、移植元ツール監視など、継続状態が必要なUV Suite機能だけを集約する切り替え盤です。一回実行の配置、展開、パック、密度、レポート系コマンドはここでは起動しません。',
        'Enable only the live helper required for the current task.  Disable it after use to remove handlers, overlays, or modal state where the source tool supports stopping.  The row is a real BoolProperty toggle, so the blue active highlight follows the saved state.',
        '現在の作業で必要なライブ補助だけを有効にします。作業後は無効にし、対応しているハンドラ、オーバーレイ、モーダル状態を解除して軽く保ちます。各行は実体BoolPropertyなので、有効時の青い表示は保存状態に安定して連動します。',
        operators=('smart_uv_suite.toggle_always_on_feature', 'suv.toggle_live_unwrap', 'uv.suv_uv_sync_mode_toggle', 'smart_uv_suite.native_hub_action', 'smart_uv_suite.native_hub_action', 'smart_uv_suite.native_hub_action', 'smart_uv_suite.native_hub_action', 'smart_uv_suite.native_hub_action', 'smart_uv_suite.native_hub_action', 'smart_uv_suite.native_hub_action'),
        workspace_keywords=('always_on', 'show_always_on_toggles'),
        settings_en=(
            'Show Always-on Toggles Group Open: opens or closes this top group without enabling any background helper.',
            'Each feature switch stores an enabled/disabled state in the Blender config file Smart_UV_Suite/Smart_UV_Suite.json and is restored on startup, scene load, and preference save.',
            'Unavailable rows mean the source operator or settings block is not registered in the current Blender session; no background work is started for them.',
        ),
        settings_ja=(
            '常時機能切り替えグループを開く: この最上部グループの開閉だけを行い、背景補助自体は有効化しません。',
            '各機能スイッチはBlender設定フォルダの Smart_UV_Suite/Smart_UV_Suite.json に有効/無効を保存し、起動時、シーン読み込み時、プリファレンス保存時に復元します。',
            '未登録行は、現在のBlenderセッションで元オペレーターまたは設定ブロックが登録されていない状態です。その項目の背景処理は開始されません。',
        ),
    ),
    'workspace_header': _entry(
        'UV Suite Header', 'UV Suiteヘッダー',
        'Shows the active mesh/UV-map state and provides the fastest validation and automatic repair entry points before running heavier UV workflows.',
        'アクティブメッシュとUVマップ状態を確認し、重いUVワークフローを実行する前の検証と自動修復へ素早く入るための項目です。',
        'Select the mesh to edit, confirm that the UV-map count and context are correct, then run Validate or Auto Repair when prerequisites are uncertain.',
        '編集するメッシュを選択し、UVマップ数とコンテキストが正しいことを確認します。前提条件に不安がある場合は検証または自動修復を実行します。',
        operators=('uv.suv_workspace_validate', 'uv.suv_workspace_auto_repair'),
        workspace_keywords=_COMMON_WORKSPACE_KEYS,
        settings_en=('Show Help Text and Show Dashboard are legacy visibility switches; detailed help is now provided by the icon-only Help buttons.',),
        settings_ja=('ヘルプ表示とダッシュボード表示は旧表示用の切り替えです。詳細ヘルプは現在、アイコンのみのヘルプボタンに集約しています。',),
    ),
    'visual_reference_deck': _entry(
        'Visual Workflow Reference', '視覚ワークフローリファレンス',
        'Displays large reference cards that summarize the intended UV production flow: analyze the current layout, repair critical issues, normalize density, pack, then inspect the result.',
        '解析、重大問題修復、密度正規化、パック、結果検査というUV制作フローを大きな参照カードで確認する項目です。',
        'Use it as a visual reminder at the beginning of a session.  The quick buttons below the cards start the Cockpit routes for finish, hero asset, and repair-pack workflows.',
        'セッション開始時の視覚的な確認に使います。カード下のクイックボタンは、仕上げ、ヒーローアセット、修復パックのCockpitルートを開始します。',
        operators=('smart_uv_suite.cockpit_run',),
        workspace_keywords=('auto_unwrap_mode', 'smart_quality_profile', 'smart_precision_level', 'smart_last_score', 'smart_last_grade'),
        settings_en=('The reference cards are static images and do not start background processing.', 'The quick route button uses the Cockpit intent setting internally and writes the latest score/report after execution.'),
        settings_ja=('参照カードは静的画像で、背景処理は開始しません。', 'クイックルートボタンは内部でCockpitの目的設定を使い、実行後に最新スコアとレポートを書き出します。'),
    ),
    'smart_uv_cockpit': _entry(
        'UV Suite Cockpit', 'UV Suiteコックピット',
        'Production control center for choosing quality profiles, running intent-based UV routes, and keeping precision settings in the N-panel instead of Add-on Preferences.',
        '品質プロファイル選択、目的別UVルート実行、精度設定の保存を、アドオンプリファレンスではなくNパネルに集約した制作コントロールセンターです。',
        'Choose a quality profile, adjust precision level, relax iterations, pack candidates, margin strategy, lock-overlap and sliver protection, then run the route that matches the asset type.',
        '品質プロファイルを選び、精度レベル、リラックス反復数、パック候補数、余白戦略、重なり保持、スリバー保護を調整してから、アセット種別に合うルートを実行します。',
        operators=('smart_uv_suite.cockpit_analyze', 'smart_uv_suite.cockpit_run', 'smart_uv_suite.cockpit_apply_profile'),
        workspace_keywords=('auto_unwrap_mode', 'smart_quality_profile', 'smart_precision_level', 'smart_relax_iterations', 'smart_pack_candidates', 'smart_margin_strategy', 'smart_lock_overlaps', 'smart_sliver_protection', 'smart_ui_density', 'smart_last_score', 'smart_last_grade', 'smart_last_action'),
        settings_en=(
            'Quality Profile: applies a stored production preset for hero assets, hard surface, organic meshes, lightmaps, UDIM, trim workflows, or general production finishing.',
            'Precision Level: chooses safe, ultra, or extreme processing paths where available.',
            'Relax Iterations: controls how many relax/minimum-stretch passes are attempted by precision routes.',
            'Pack Candidates: controls how many packing candidates are tried by high-density routes.',
            'Margin Strategy: balances dense packing against bake-safe padding.',
            'Lock Overlaps: preserves intentionally stacked or overlapped UVs during compatible pack routes.',
            'Sliver Protection: treats very thin islands conservatively to avoid accidental collapse or over-scaling.',
            'UI Density: controls how compact this Cockpit presents its N-panel controls.',
        ),
        settings_ja=(
            '品質プロファイル: ヒーローアセット、ハードサーフェス、有機形状、ライトマップ、UDIM、トリム、一般制作仕上げ向けの保存済みプリセットを適用します。',
            '精度レベル: 利用可能な場合に安全、超精度、極限精度の処理経路を選びます。',
            'リラックス反復数: 精度ルートで試行するリラックス/最小ストレッチ処理回数を制御します。',
            'パック候補数: 高密度パックルートで試す候補数を制御します。',
            '余白戦略: 高密度配置とベイク安全余白のバランスを選びます。',
            '重なり保持: 対応パック処理で、意図的なスタックや重なりUVを保持します。',
            'スリバー保護: 非常に細いアイランドを保守的に扱い、潰れや過剰スケールを避けます。',
            'UI密度: Cockpit内のNパネル操作をどれだけコンパクトに表示するかを制御します。',
        ),
    ),
    'cockpit_quality_score': _entry('Quality Score', '品質スコア', 'Shows the latest measured UV Suite quality score, grade, and route name written by Cockpit, Precision, or Excellence routes.', 'Cockpit、Precision、Excellenceルートが記録した最新のUV Suite品質スコア、グレード、ルート名を表示します。', 'Run Analyze or any intent route, then read this score before deciding whether to repack, repair, or adjust density.', '解析または目的別ルートを実行し、再パック、修復、密度調整が必要か判断する前にこのスコアを確認します。', operators=('smart_uv_suite.cockpit_analyze',), workspace_keywords=('smart_last_score', 'smart_last_grade', 'smart_last_action')),
    'cockpit_precision_controls': _entry(
        'Saved Precision Controls', '保存される精度設定',
        'Editable N-panel precision settings shared by Cockpit, UV Suite Smart, Precision Engine, and Excellence routes.',
        'Cockpit、UV Suite Smart、Precision Engine、Excellenceルートで共有されるNパネルの精度設定です。',
        'Edit these before running a route.  They are saved with the N-panel state and restored on startup, scene load, and preference save.',
        'ルート実行前に編集します。これらはNパネル状態として保存され、起動時、シーン読み込み時、プリファレンス保存時に復元されます。',
        workspace_keywords=('auto_unwrap_mode', 'smart_quality_profile', 'smart_precision_level', 'smart_relax_iterations', 'smart_pack_candidates', 'smart_margin_strategy', 'smart_lock_overlaps', 'smart_sliver_protection', 'smart_ui_density'),
        settings_en=(
            'Quality Profile: production preset family used by the next route.',
            'Precision Level: processing strength and fallback aggressiveness.',
            'Relax Iterations: repeated relax/minimum-stretch attempts.',
            'Pack Candidates: number of candidate pack attempts.',
            'Margin Strategy: dense, balanced, or bake-safe padding behavior.',
            'Lock Overlaps: preserve deliberate stacks/overlaps where supported.',
            'Sliver Protection: conservative handling for narrow UV islands.',
            'UI Density: compactness of Cockpit controls.',
        ),
        settings_ja=(
            '品質プロファイル: 次に実行するルートで使う制作プリセット系統です。',
            '精度レベル: 処理強度とフォールバックの積極度です。',
            'リラックス反復数: リラックス/最小ストレッチを繰り返す回数です。',
            'パック候補数: パック候補を試す回数です。',
            '余白戦略: 高密度、バランス、ベイク安全余白の挙動です。',
            '重なり保持: 対応時に意図的なスタック/重なりを保持します。',
            'スリバー保護: 細いUVアイランドを保守的に扱います。',
            'UI密度: Cockpit操作のコンパクトさです。',
        ),
    ),
    'cockpit_intent_routes': _entry('Intent Routes', '目的別ルート', 'Starts asset-oriented routes such as production finish, hero asset, hard surface, organic, lightmap, UDIM, repair-pack, or score-only analysis.', '制作仕上げ、ヒーローアセット、ハードサーフェス、有機形状、ライトマップ、UDIM、修復パック、スコアのみ解析など、アセット目的別ルートを開始します。', 'Choose the route that matches the asset.  For unknown assets, use Production Finish first, then inspect the score and run a more specific route if needed.', 'アセットに合うルートを選びます。不明な場合は先に制作仕上げを使い、スコア確認後に必要なら専用ルートを実行します。', operators=('smart_uv_suite.cockpit_run',), workspace_keywords=('auto_unwrap_mode', 'smart_quality_profile', 'smart_precision_level', 'smart_pack_candidates')),
    'cockpit_quality_profiles': _entry('Quality Profiles', '品質プロファイル', 'Applies stored parameter sets for common UV production targets.', '一般的なUV制作目標に合わせた保存済みパラメータセットを適用します。', 'Click a profile before running Cockpit, Precision, or Excellence actions.  The profile updates N-panel settings rather than Add-on Preferences.', 'Cockpit、Precision、Excellenceアクション実行前にプロファイルをクリックします。プロファイルはアドオンプリファレンスではなくNパネル設定を更新します。', operators=('smart_uv_suite.cockpit_apply_profile',), workspace_keywords=('auto_unwrap_mode', 'smart_quality_profile', 'smart_precision_level', 'smart_margin_strategy', 'smart_pack_candidates')),
    'smart_uv_excellence': _entry(
        'UV Suite Command Deck', 'UV Suiteコマンドデッキ',
        'High-level precision command deck for one-click production routes, asset-specific routes, quality scoring, and dense packing.',
        'ワンクリック制作ルート、アセット別ルート、品質スコア、高密度パックを扱う上位精度コマンドデッキです。',
        'Run Director Auto for a broad cleanup-and-pack pass, Supreme Pack for layout density, Score for measurement only, or an asset route for organic, hard-surface, trim, UDIM, lightmap, scan, density, distortion, or safe-auto needs.',
        '広範囲の整理とパックには統合ディレクター、配置密度重視には最高密度パック、測定のみにはスコア、用途別には有機、ハードサーフェス、トリム、UDIM、ライトマップ、スキャン、密度、歪み、安全自動ルートを使います。',
        operators=('smart_uv_suite.excellence_action',), workspace_keywords=('smart_last_score', 'smart_last_grade', 'workflow_density', 'fit_padding_px', 'pack_group_mode', 'stack_group_mode'),
        settings_en=('Director Auto chains inspection, seam/unwrap candidates, relaxation, density normalization, stacking, packing, and reporting.', 'Asset routes adjust the route order for organic, hard-surface, trim, UDIM, lightmap, scan cleanup, density audit, or distortion audit work.'),
        settings_ja=('統合ディレクターは検査、シーム/展開候補、リラックス、密度正規化、スタック、パック、レポートを連結します。', 'アセット別ルートは、有機、ハードサーフェス、トリム、UDIM、ライトマップ、スキャン修復、密度監査、歪み監査に合わせて処理順を調整します。'),
    ),
    'excellence_one_click': _entry('One-click Production', 'ワンクリック制作', 'Runs the broadest production-grade finishing commands.', '最も広範囲の制作仕上げコマンドを実行します。', 'Use Director Auto for general assets, Supreme Pack when layout density matters, and Score when you only need measurement.', '一般アセットは統合ディレクター、配置密度重視は最高密度パック、測定のみはスコアを使います。', operators=('smart_uv_suite.excellence_action',), workspace_keywords=('workflow_density', 'fit_padding_px', 'smart_last_score')),
    'excellence_asset_routes': _entry('Asset Routes', 'アセット別ルート', 'Specialized routes for organic, hard-surface, trim, UDIM, lightmap, scan cleanup, density, distortion, and safe automation.', '有機、ハードサーフェス、トリム、UDIM、ライトマップ、スキャン修復、密度、歪み、安全自動向けの専用ルートです。', 'Choose the closest route for the asset type to avoid over-processing and to keep the output predictable.', '過剰処理を避け、結果を予測しやすくするため、アセット種別に最も近いルートを選びます。', operators=('smart_uv_suite.excellence_action',), workspace_keywords=('auto_unwrap_mode', 'smart_quality_profile', 'smart_precision_level', 'workflow_density')),
    'uv_router': _entry(
        'UV Suite Smart', 'UV Suite Smart',
        'Document-synced upper-compatible UV layer that maps researched commercial and DCC UV features to local UV Suite routes without copying third-party code.',
        '調査済みの商用ツール/DCC UV機能を、第三者コードをコピーせずUV Suite内のローカルルートへ割り当てる文書同期型の上位互換レイヤーです。',
        'Use the broad buttons for automatic workflows, open feature groups for specific actions, or use the document matrix to run a route corresponding to a listed external feature.',
        '自動ワークフローは上部ボタン、個別操作は機能グループ、外部機能リストに対応する処理は文書機能マトリクスから実行します。',
        operators=('smart_uv_suite.uv_router_action', 'smart_uv_suite.uv_router_feature', 'smart_uv_suite.uv_router_tool', 'smart_uv_suite.uv_router_write_matrix'),
        workspace_keywords=_COMMON_WORKSPACE_KEYS,
        settings_en=('Feature Matrix output is saved inside CONFIG/Smart_UV_Suite/reports.', 'Buttons are hidden if the corresponding route is unavailable, preventing unknown-operator warnings.'),
        settings_ja=('機能対応表の出力は CONFIG/Smart_UV_Suite/reports 内に保存されます。', '対応ルートが利用できないボタンは非表示になり、unknown operator警告を防ぎます。'),
    ),
    'uv_layout_board': _entry(
        'UV Layout Board', 'UVレイアウトボード',
        'Compact Smart UV compact layout board for the most frequent UV layout operations: tile fitting, sorting, alignment, transformation, clean shaping, unwrap shortcuts, density, and problem selection.',
        'タイル収め、並べ替え、整列、変形、形状整理、展開ショートカット、密度、問題選択をまとめたSmart UV Suite独自の高頻度UVレイアウトボードです。',
        'Use it immediately after unwrapping.  Fit or align shells, straighten or relax them, check density, select issues, then run the final pack.',
        '展開直後に使います。シェルをフィットまたは整列し、直線化やリラックスで整え、密度と問題を確認してから最終パックへ進みます。',
        operators=('smart_uv_suite.uv_layout_action', 'uv.suv_pack_pro', 'uv.suv_native_projection', 'uv.suv_texel_get', 'uv.suv_texel_set', 'uv.suv_texel_normalize', 'object.suv_create_checker_material', 'uv.suv_inspector_select', 'uv.suv_inspector_scan'),
        workspace_keywords=('pack_group_mode', 'stack_group_mode'),
        settings_en=('This board is retained as a compact layout aid; current basic grid settings are edited in Canvas / Grid.', 'Checker controls are handled only in Preview / Checker.'),
        settings_ja=('このボードは簡易レイアウト補助として残しています。現在の基本グリッド設定は「キャンパス/グリッド」で編集します。', 'チェッカー操作は「プレビュー/チェッカー」でのみ扱います。'),
    ),
    'basic_canvas_grid': _entry(
        'Canvas / Grid', 'キャンパス/グリッド',
        'Shows the real UV Editor Overlay > Guide controls directly inside Smart UV Suite. It does not create checker textures and no longer includes texture-size, padding or density controls.',
        'Smart UV Suite内に、実際のUVエディター「オーバーレイ > ガイド」の表示項目を直接表示します。チェッカーテクスチャは作成せず、テクスチャサイズ・余白・密度項目はここには含めません。',
        'Use this group for grid-over-image, grid source, tile grid, grid subdivisions, image aspect ratio and pixel-coordinate display. Use the collapsed UV Editor View Display group only when you need detailed UV visibility and opacity settings.',
        '画像上グリッド、グリッド基準、タイルグリッド、グリッド分割、画像アスペクト比、ピクセル座標表示をここで設定します。UVの表示/不透明度など詳細設定が必要な時だけ、折りたたまれた「UVエディター・ビュー表示」を開きます。',
        operators=('smart_uv_suite.export_uv_layout',),
        workspace_keywords=(),
        settings_en=(
            'Grid Over Image: displays the UV guide grid over the active image.',
            'Grid Source and Grid Subdivisions: control how the UV editor guide grid is divided. In Dynamic mode, Grid Subdivisions means the number of light subdivisions inside one major grid cell.',
            'Grid Color edits Preferences > Themes > Image/UV Editor > Grid directly.',
            'Aspect Ratio: edits the active image display aspect when an image is shown in the UV editor.',
            'Export UV Layout: opens the Blender file browser; all export details are configured there.',
        ),
        settings_ja=(
            '画像上にグリッド: アクティブ画像の上にUVガイドグリッドを表示します。',
            'グリッド基準とグリッド分割: UVエディターのガイドグリッド分割方法を制御します。ダイナミック/ピクセル基準ではBlender側が表示グリッドを自動制御するため、グリッド分割項目は表示しません。',
            'グリッドカラー: プリファレンス > テーマ > 画像/UVエディター > グリッドの色を直接変更します。',
            'アスペクト比: UVエディターに画像が表示されている場合、その画像の表示アスペクト比を編集します。',
            'UV配置の書き出し: Blenderファイルビューを開き、書き出し詳細はそこで設定します。',
        ),
    ),
    'basic_uv_display': _entry(
        'UV Editor View Display', 'UVエディター・ビュー表示',
        'Collapsed detailed display group for the UV Editor View > Display controls.',
        'UVエディター「ビュー > 表示」の詳細項目をまとめた折りたたみグループです。',
        'Open it only when you need to change UV/faces display, edge display type, stretch display, opacity, pixel rounding, bounds lock or live unwrap.',
        'UV/面表示、エッジ表示、歪み表示、不透明度、ピクセル丸め、画像範囲固定、ライブ展開を変更する時だけ開きます。',
    ),
    'basic_preview_checker': _entry(
        'Preview / Checker', 'プレビュー/チェッカー',
        'Contains all checker-related settings and commands. It is collapsed by default so checker controls do not dominate the basic settings panel.',
        'チェッカー関連の設定とコマンドを集約します。基本設定パネルを圧迫しないよう、初期状態では閉じています。',
        'Use Create Checker only when you intentionally want a checker preview. Automatic unwrap and canvas/grid display editing do not create a checker.',
        'チェッカー確認を意図して行う場合だけ「チェッカー作成」を使います。自動UV展開やキャンパス/グリッドの表示編集ではチェッカーを作成しません。',
        operators=('smart_uv_suite.view_create_checker_material', 'smart_uv_suite.checker_map', 'smart_uv_suite.view_remove_checker_materials'),
        workspace_keywords=('checker_size_width', 'checker_size_height', 'checker_tile_count_u', 'checker_tile_count_v', 'checker_image_name', 'checker_material_name'),
    ),
    'basic_display': _entry(
        'Analysis Display', '解析表示',
        'Holds optional visual analysis tools such as fit view, focus, histogram, stretch heatmap and issue overlay. It is collapsed by default.',
        '表示合わせ、選択フォーカス、ヒストグラム、歪みヒートマップ、問題オーバーレイなど任意の解析表示をまとめます。初期状態では閉じています。',
        'Open this group only when you need visual analysis feedback after editing or packing UVs.',
        'UV編集またはパッキング後に視覚的な解析結果を確認したい時だけ開きます。',
        operators=('smart_uv_suite.view_fit_to_bounds', 'smart_uv_suite.view_focus', 'smart_uv_suite.view_histogram_tools', 'smart_uv_suite.view_visualize_stretch_heatmap', 'smart_uv_suite.view_clear_stretch_heatmap', 'smart_uv_suite.view_issue_overlay_tools'),
        workspace_keywords=('show_dashboard', 'show_reference_gallery', 'heatmap_max'),
    ),
    'basic_uv_layout_export': _entry(
        'Export UV Layout', 'UV配置の書き出し',
        'Writes the active UV layout as SVG, EPS, PNG, JSON or CSV. The N-panel shows only one launch button; output details are edited in the Blender file browser.',
        'アクティブUV配置をSVG、EPS、PNG、JSON、CSVで書き出します。Nパネルには実行ボタンだけを表示し、出力詳細はBlenderファイルブラウザーで編集します。',
        'Use SVG/EPS/PNG for visual review and paint guides. Use JSON/CSV when another DCC tool, game tool, spreadsheet or pipeline script needs structured UV data.',
        '見た目確認やペイントガイドにはSVG/EPS/PNGを使います。他DCCツール、ゲームツール、表計算、パイプラインスクリプトへ構造化UVデータを渡す場合はJSON/CSVを使います。',
        operators=('smart_uv_suite.export_uv_layout',),
        workspace_keywords=(),
    ),
    'unwrap_auto': _entry(
        'Smart UV Unwrap', 'スマートUV展開',
        'Runs the single Smart unwrap workflow selected by Method. Smart uses Shape, Algorithm, Strength, Flexibility, Tolerance and Orientation; Flat and projection methods use their own projection or flattening rules. Pack, relax, quality and precision are fixed internally to maximum quality and are no longer separate UI controls.',
        '方式で選んだ1つのスマートUV展開ワークフローを実行します。スマートは「形状」「アルゴリズム」「強度」「柔軟」「許容」「向き」で制御します。フラットと投影方式はそれぞれ専用の投影・フラット化ルールを使います。展開後パック、展開後リラックス、品質、精度は内部で最高品質固定になっており、個別UI項目ではありません。',
        'Run Unwrap works on the UVs selected in the UV Editor. With UV Sync Selection off and no UV selected, it works on all the faces shown in the UV Editor. For Smart Standard, use the Smart Standard controls only: selection scope, seam/border use, stretch, groove/ridge/hole cuts, channels, packing, texel density and tiles. Realtime Preview is common to all methods and runs only after Run Smart Unwrap has armed the current selected mesh.',
        '展開実行は UV エディターで選んでいる UV に働きます。UV同期選択がオフで UV を選んでいない時は、UV エディターに出ている面全部に働きます。スマート標準では、選択範囲、シーム/境界、伸び許容、溝/稜線/穴カット、チャンネル、パック、テクセル密度、タイルなどSmart標準系設定だけを使用します。リアルタイム反映は全方式共通で、自動展開実行後に現在の選択メッシュへだけ作動します。',
        operators=('smart_uv_suite.unwrap_auto_run',),
        workspace_keywords=('auto_unwrap_mode', 'smart_unwrap_realtime_preview', 'smart_standard_selection', 'smart_standard_stretch', 'smart_standard_pack_mode', 'smart_standard_padding_px'),
    ),
    'native_unwrap_hub': _entry(
        'Smart Unwrap Hub', 'スマート展開ハブ',
        'Runs the current Smart UV unwrap method from one execution button. Smart uses Shape, Algorithm, Strength, Flexibility, Tolerance and Orientation; Flat and projection methods use their own dedicated rules. Pack, relax, quality and precision are fixed internally to maximum quality.',
        '現在選択しているSmart UV展開方式を、1つの実行ボタンから実行します。スマートは「形状」「アルゴリズム」「強度」「柔軟」「許容」「向き」で制御し、フラットと投影方式は各専用ルールで動作します。展開後パック、展開後リラックス、品質、精度は内部で最高品質固定です。',
        'For Smart Standard, set the Smart Standard unwrap, seam, stretch, packing, density and tile controls, then run the single unwrap button. Realtime Preview updates the UV Editor only after that manual run and only when settings change for the same selected mesh.',
        'スマート標準ではSmart標準系の展開、シーム、伸び、パック、密度、タイル設定を調整し、1つの展開ボタンを実行します。リアルタイム反映は、その手動実行後、同じ選択メッシュの設定変更時だけUVエディターへ反映します。',
        operators=('smart_uv_suite.unwrap_auto_run',),
        workspace_keywords=('auto_unwrap_mode', 'smart_unwrap_realtime_preview', 'smart_standard_selection', 'smart_standard_stretch', 'smart_standard_pack_mode', 'smart_standard_padding_px'),
    ),
    'cut_unwrap_projection': _entry('Unfold Trim', '展開 / 投影', 'Unified Smart unwrap plus explicit projection helpers. Smart Standard has one run button and uses Smart Standard settings only.', '統合スマート展開と明確な投影補助です。スマート標準は実行ボタン1つで、Smart標準系設定だけを使います。', 'Use Smart Unwrap for the main automatic unwrap. Pack, relax, quality and precision are fixed internally; use Orientation to set the facing direction.', '主な自動展開はスマート標準で行います。シーム、伸び、パック、余白、密度、タイルなどのSmart標準系設定を調整します。', operators=('uv.suv_auto_unwrap_pro', 'uv.suv_native_projection', 'uv.suv_projection_bridge', 'suv.constraint_unwrap', 'uv.suv_constraint_relax_preserve'), workspace_keywords=('canvas_size', 'fit_padding_px', 'smart_standard_stretch', 'smart_standard_pack_mode')),
    'transform': _entry('Align / Straighten / Transform', '整列 / 直線化 / 変形', 'Post-unwrap editing tools for alignment, centering, orienting, distributing, straightening, orthogonalizing, gridifying, rotating, flipping, cropping, and filling.', '展開後に使う整列、中央配置、方向補正、分配、直線化、直交化、グリッド化、回転、反転、クロップ、フィルの編集ツールです。', 'Use these after unwrap and before packing to make shells readable and compact.  Hard-surface shells benefit from straighten, grid, square, and rectify operations.', '展開後、パック前に使い、シェルを読みやすくコンパクトにします。ハードサーフェスシェルでは直線化、グリッド、正方形、矩形化が有効です。', operators=('uv.suv_align_islands', 'uv.suv_centralize_islands', 'uv.suv_orient_to_edge', 'uv.suv_distribute_islands', 'uv.suv_straight_line', 'uv.suv_set_flow', 'uv.suv_hs_orthogonalize', 'uv.suv_hs_gridify', 'uv.suv_hs_squareify', 'uv.suv_hs_rectify_fit', 'uv.suv_rotate_islands', 'uv.suv_flip_islands', 'uv.suv_randomize_islands', 'uv.suv_explode_islands', 'uv.suv_crop_tile', 'uv.suv_fill_tile'), workspace_keywords=('uv_chain_group_mode', 'uv_chain_axis_mode', 'uv_chain_endpoint_mode', 'uv_flow_strength', 'fit_padding_px')),
    'transform_line_flow_settings': _entry('Line / Flow Settings', 'ライン / フロー設定', 'Controls how chain and flow tools detect island chains, choose axes, choose endpoints, and apply flow strength.', 'チェーン/フローツールがアイランドチェーンを検出する方法、軸、端点、フロー強度を制御します。', 'Set these before Straight Line or Set Flow.  Use stricter group and endpoint settings when the selection includes multiple unrelated islands.', '直線化またはフロー設定の前に調整します。選択内に無関係なアイランドが複数ある場合は、グループと端点の条件を厳しくします。', workspace_keywords=('uv_chain_group_mode', 'uv_chain_axis_mode', 'uv_chain_endpoint_mode', 'uv_flow_strength')),
    'layout_pack': _entry('Packing / Layout / Stack / UDIM', 'パック / 配置 / スタック / UDIM', 'Packing, density-aware layout, grouped stack, topology stack, symmetry stack, unstack, groups-to-tiles, UDIM movement, hotspot, and trim layout workflows.', 'パック、密度優先配置、グループスタック、トポロジースタック、対称スタック、スタック解除、グループ→タイル、UDIM移動、ホットスポット、トリム配置をまとめます。', 'Normalize density before high-density packing when texture consistency matters.  Use stack tools before packing repeated parts and UDIM tools when layouts span multiple tiles.', 'テクスチャ一貫性が重要な場合は高密度パック前に密度を正規化します。反復パーツはパック前にスタックし、複数タイルにまたがる場合はUDIMツールを使います。', operators=('uv.suv_pack_pro', 'uv.suv_priority_density_pack', 'uv.suv_density_guard_normalize', 'uv.suv_fit_to_bounds', 'uv.suv_layout_autoheal', 'uv.suv_layout_preflight_audit', 'uv.suv_stack_grouped', 'uv.suv_stack_topology_groups', 'uv.suv_stack_symmetry_topology', 'uv.suv_unstack_groups', 'uv.suv_unstack_overlapped', 'uv.suv_groups_to_tiles', 'uv.suv_group_normalize_layout', 'uv.suv_orient_groups_advanced', 'uv.suv_udim_step', 'uv.suv_udim_tile_tools'), workspace_keywords=('pack_group_mode', 'pack_group_layout', 'stack_group_mode', 'fit_padding_px', 'workflow_density', 'similarity_area_tol', 'similarity_aspect_tol')),
    'layout_pack_settings': _entry('Packing Settings', 'パック設定', 'Shared controls for pack grouping, group layout, stack mode, and padding.', 'パックグループ、グループ配置、スタック方式、余白を扱う共通設定です。', 'Set these before Pack Pro, grouped stack, UDIM distribution, or hotspot/trim refills.', 'パックPro、グループスタック、UDIM分配、ホットスポット/トリム再充填の前に設定します。', workspace_keywords=('pack_group_mode', 'pack_group_layout', 'stack_group_mode', 'fit_padding_px')),
    'hotspot_trim': _entry('Hotspot / Trim', 'ホットスポット / トリム', 'Layouts and refills UV islands into hotspot grids, cells, symmetry cells, trim strips, and trim bands.', 'UVアイランドをホットスポットグリッド、セル、対称セル、トリムストリップ、トリム帯へ配置・再充填します。', 'Set grid columns/rows and aspect behavior, run a grid or band layout, then use refill commands when selection or tile assignment changes.', 'グリッド列/行とアスペクト動作を設定し、グリッドまたは帯配置を実行します。選択やタイル割り当てが変わった場合は再充填を使います。', operators=('uv.suv_hotspot_grid_layout', 'uv.suv_hotspot_cell_tools', 'uv.suv_hotspot_cell_refill', 'uv.suv_hotspot_symmetry_refill', 'uv.suv_trim_strip_layout', 'uv.suv_trim_band_layout', 'uv.suv_trim_band_refill'), workspace_keywords=('hotspot_cols', 'hotspot_rows', 'hotspot_keep_aspect', 'hotspot_sort', 'hotspot_fill_order')),
    'select_inspect': _entry('Selection / Inspector / Repair', '選択 / 検査 / 修復', 'Finds and repairs UV problems such as flipped islands, overlaps, zero-area UVs, fragmented islands, boundaries, and UDIM crossings.', '反転、重なり、ゼロ面積UV、断片アイランド、境界、UDIM跨ぎなどのUV問題を検出・修復します。', 'Run Scan first, select the issue type to inspect, fix flipped islands where safe, then rescan and write a report when needed.', 'まず検査を実行し、確認する問題タイプを選択します。安全な場合は反転を修正し、必要に応じて再検査とレポート作成を行います。', operators=('uv.suv_inspector_scan', 'uv.suv_inspector_select', 'uv.suv_inspector_fix_flipped', 'uv.suv_repair_flipped_islands', 'uv.suv_inspector_rescan', 'uv.suv_inspector_clear_cache', 'uv.suv_inspector_select_all', 'uv.suv_inspector_write_report', 'uv.suv_select_island_active', 'uv.suv_select_similar_islands', 'uv.suv_select_identical_islands', 'uv.suv_select_fragmented_islands', 'uv.suv_select_uv_boundary', 'uv.suv_select_zero_islands', 'uv.suv_select_udim_crossing'), workspace_keywords=('scan_report_name', 'stretch_threshold', 'heatmap_max', 'scan_flipped', 'scan_zero', 'scan_overlap')),
    'select_inspect_last_scan': _entry('Last Scan', '直近の検査', 'Displays latest scan counters and settings used by the inspector.', 'インスペクターが使用した直近の検査カウントと設定を表示します。', 'Use this after Scan or Rescan to decide whether to select issues, fix flipped islands, or write a report.', '検査または再検査後、問題選択、反転修正、レポート作成の判断に使います。', workspace_keywords=('scan_report_name', 'stretch_threshold', 'heatmap_max', 'scan_flipped', 'scan_zero', 'scan_overlap')),
    'density_preview_maps': _entry('Density Panel', 'テクセル密度 / プレビュー / UVマップ', 'Texel-density measurement and normalization, checker and stretch previews, histogram/audit tools, and UV-map slot maintenance.', 'テクセル密度の測定と正規化、チェッカーとストレッチ表示、ヒストグラム/監査、UVマップスロット管理をまとめます。', 'Pick density from a correct island, apply or normalize it, create a checker, inspect stretch, then manage UV maps for render or bake targets.', '正しいアイランドから密度を取得し、適用または正規化し、チェッカー作成とストレッチ確認を行い、レンダーまたはベイク用UVマップを管理します。', operators=('uv.suv_texel_get', 'uv.suv_texel_set', 'uv.suv_texel_normalize', 'smart_uv_suite.texel_density_tools', 'object.suv_create_checker_material', 'object.suv_remove_checker_materials', 'object.suv_visualize_stretch_heatmap', 'object.suv_clear_stretch_heatmap', 'uv.suv_histogram_tools', 'uv.suv_issue_audit_tools', 'mesh.suv_uvmap_add', 'mesh.suv_uvmap_duplicate', 'mesh.suv_uvmap_remove', 'mesh.suv_uvmap_rename_active', 'mesh.suv_uvmap_set_active', 'mesh.suv_uvmap_set_render', 'mesh.suv_uvmap_reorder', 'mesh.suv_native_stage_uvmap'), workspace_keywords=('canvas_size', 'workflow_density', 'checker_size', 'checker_image_name', 'checker_material_name', 'uv_new_name', 'heatmap_attr_name', 'heatmap_material_name', 'heatmap_max', 'stretch_threshold')),
    'density_preview_settings': _entry('Preview Settings', 'プレビュー設定', 'Shared settings for checker textures, UV-map naming, and stretch heatmap output.', 'チェッカーテクスチャ、UVマップ命名、ストレッチヒートマップ出力の共通設定です。', 'Set checker size and names before creating preview materials.  Set heatmap attribute/material names before stretch visualization.', 'プレビュー用マテリアル作成前にチェッカーサイズと名前を設定します。ストレッチ表示前にヒートマップ属性名とマテリアル名を設定します。', workspace_keywords=('canvas_size', 'checker_size', 'checker_image_name', 'checker_material_name', 'uv_new_name', 'heatmap_attr_name', 'heatmap_material_name')),
    'density_uv_maps': _entry('UV Maps', 'UVマップ', 'Creates, duplicates, removes, renames, activates, render-flags, and reorders UV map slots.', 'UVマップスロットの作成、複製、削除、名前変更、アクティブ指定、レンダー指定、並べ替えを行います。', 'Use duplicate before destructive UV experiments, rename maps for bake/render clarity, and set active/render maps before export or bake.', '破壊的なUV実験前に複製し、ベイク/レンダー用に名前を整理し、書き出しやベイク前にアクティブ/レンダーUVを指定します。', operators=('mesh.suv_uvmap_add', 'mesh.suv_uvmap_duplicate', 'mesh.suv_uvmap_remove', 'mesh.suv_uvmap_rename_active', 'mesh.suv_uvmap_set_active', 'mesh.suv_uvmap_set_render', 'mesh.suv_uvmap_reorder', 'mesh.suv_native_stage_uvmap'), workspace_keywords=('uv_new_name',)) ,
    'symmetry_atlas': _entry('Symmetry / Transfer / Atlas / Bake', '対称 / 転送 / アトラス / ベイク', 'Symmetry detection and mirroring, match/stitch transfer, smart 3D transfer, multi-object atlas building, and bake preparation.', '対称検出とミラー、一致/ステッチ転送、スマート3D転送、複数オブジェクトアトラス構築、ベイク準備をまとめます。', 'Use symmetry tools for mirrored assets, transfer tools to match active UVs, atlas tools for multi-object texture consolidation, and bake prep before texture baking.', 'ミラーアセットには対称ツール、アクティブUVに合わせる場合は転送、複数オブジェクトのテクスチャ統合にはアトラス、テクスチャベイク前にはベイク準備を使います。', operators=('uv.suv_sym_detect_pairs', 'uv.suv_sym_mirror_uv', 'uv.suv_sym_seams', 'uv.suv_sym_stack', 'uv.suv_match_active_preserve', 'uv.suv_match_stitch_active_preserve', 'uv.suv_batch_match_stitch_active_preserve', 'uv.suv_smart_3d_transfer', 'uv.suv_atlas_build_uv_multi', 'uv.suv_atlas_build_mat_apply_multi', 'uv.suv_atlas_bake_multi', 'uv.suv_atlas_run_all_multi', 'mesh.suv_bake_uv_prep', 'object.suv_native_stage_bake'), workspace_keywords=('atlas', 'bake', 'workflow_density', 'fit_padding_px')),
    'native_bridge': _entry('Standard Integration', '標準連携', 'Standard integration commands for workflow, layout, selection, preview, mesh, UV edit, brush, lattice, cleanup, precision, procedural, and hair-card UV tools.', 'ワークフロー、配置、選択、プレビュー、メッシュ、UV編集、ブラシ、ラティス、クリーンアップ、精密、プロシージャル、ヘアカードUV用の標準連携コマンドです。', 'Use this section when you need lower-level integration commands not exposed in the compact boards.', 'コンパクトボードに出ていない低レベルの標準連携コマンドが必要な場合に使います。', operators=('uv.suv_native_stage_workflow', 'uv.suv_native_stage_layout', 'uv.suv_native_stage_select', 'object.suv_native_stage_preview', 'mesh.suv_native_stage_mesh', 'uv.suv_uv_edit_compat_tools', 'uv.suv_uv_brush_compat', 'uv.suv_uv_lattice_compat', 'uv.suv_cleanup_bridge', 'uv.suv_similarity_bridge', 'uv.suv_precision_uv_tools', 'uv.suv_procedural_uv_tools', 'uv.suv_hair_card_uv_tools'), workspace_keywords=_COMMON_WORKSPACE_KEYS),
    'reports': _entry('Reports / Diagnostics / Maintenance', 'レポート / 診断 / メンテナンス', 'Writes runtime snapshots, diagnostics, support bundles, catalogs, UI maps, and clears generated report data.', '実行状態スナップショット、診断、サポートバンドル、一覧、UIマップを書き出し、生成レポートデータを整理します。', 'Use these when verifying installation health, preparing issue reports, or cleaning generated UV Suite data under CONFIG/Smart_UV_Suite.', 'インストール状態確認、問題報告準備、CONFIG/Smart_UV_Suite 配下の生成データ整理に使います。', operators=('uv.suv_write_tool_runtime_snapshot', 'uv.suv_clear_tool_runtime_log', 'uv.suv_clear_batch_report', 'uv.suv_open_diagnostics_text', 'uv.suv_write_support_bundle', 'uv.suv_collect_support_bundle', 'uv.suv_copy_diagnostics_text', 'uv.suv_clear_all_reports', 'uv.suv_reload_custom_icons', 'uv.suv_quality_audit_suite', 'uv.suv_quality_scan_context_readiness', 'uv.suv_quality_cleanup_generated_data', 'uv.suv_quality_write_operator_catalog', 'uv.suv_quality_write_ui_map'), workspace_keywords=('tool_runtime_log_name', 'batch_report_name', 'support_bundle_name', 'validation_report_name', 'batch_error_policy', 'batch_snapshot_policy')),
    'reports_destinations': _entry('Report Destinations', 'レポート出力先', 'Filename and policy settings for runtime logs, batch reports, support bundles, validation reports, error policy, and snapshot policy.', '実行ログ、バッチレポート、サポートバンドル、検証レポート、エラーポリシー、スナップショットポリシーのファイル名と方針設定です。', 'Edit these before writing diagnostics or support bundles. Output stays inside CONFIG/Smart_UV_Suite unless a manual export command explicitly asks otherwise.', '診断やサポートバンドル作成前に編集します。手動エクスポートが明示的に要求しない限り、出力は CONFIG/Smart_UV_Suite 内に留まります。', workspace_keywords=('tool_runtime_log_name', 'batch_report_name', 'support_bundle_name', 'validation_report_name', 'batch_error_policy', 'batch_snapshot_policy')),
    'all_tools': _entry('All Registered UV Suite Operators', '登録済みUV Suite全オペレーター', 'Generated catalog of registered UV Suite operator classes, grouped by workflow category.', '登録済みUV Suiteオペレータークラスをワークフローカテゴリ別に生成表示する一覧です。', 'Use this for audit, recovery, or to find a command not shown in the simplified production UI.', '監査、復旧、または簡素化された制作UIにないコマンドを探す場合に使います。', operators=(), workspace_keywords=()),
}

GROUPS.update(_MORE_GROUPS)

GROUPS.update({
    'crease_value_seam_settings': _entry(
        'Crease Value Seam', 'クリース値シーム',
        'Marks mesh seams from edges whose Edge Crease value matches the configured number. Existing seams can be preserved or cleared before marking.',
        '指定クリース値に一致する辺をメッシュシームとしてマークします。既存シームを保持して加算するか、先に全クリアして作り直すかを選べます。',
        'Set Crease Value, Tolerance, and Apply Mode, then run Mark Crease Value. This reads the active mesh edge crease data and does not depend on UV selection.',
        'クリース値、許容差、適用方式を設定して「クリース値でシーム化」を実行します。アクティブメッシュの辺クリース値を読み取り、UV選択には依存しません。',
        operators=('smart_uv_suite.seam_settings_action', 'smart_uv_suite.native_seam_action'),
        workspace_keywords=('suv_crease_seam_value', 'suv_crease_seam_tolerance', 'suv_crease_seam_apply_mode'),
    ),
    'operation_immediate_select': _entry(
        'Immediate Select / Drag Move', '即時選択',
        'When enabled, a UV Editor drag that starts on a UV element selects that element at press time and then starts moving it. Background drags pass through to Blender standard box selection.',
        '有効時は、UVエレメント上からのドラッグ開始時に押下時点でそのエレメントを選択し、そのまま移動操作へ入ります。背景ドラッグはBlender標準のボックス選択へ通します。',
        'Use this as a mouse-operation helper for click-select-to-drag workflows. Turning the checkbox on registers and enables the required Smart UV Suite keymap. Check the Keymap Info section to delete, re-register, enable, or disable it.',
        'クリック選択からドラッグ移動へ直結する操作補助として使います。チェックボックスをONにすると必要なSmart UV Suiteキーマップを登録・有効化します。削除、再登録、有効化、無効化は「キーマップ情報」で確認・操作します。',
        operators=('smart_uv_suite.instant_select_drag_move',),
        workspace_keywords=('operation_instant_select_enabled',),
    ),
    'operation_cursor_to_hover_vertex': _entry(
        '2D Cursor to Hover Vertex', 'ホバー頂点へ2Dカーソル',
        'Moves the UV Editor 2D cursor to the UV vertex currently under the mouse pointer, regardless of whether that vertex is selected.',
        'UVエディター上で現在マウスが乗っているUV頂点位置へ、選択/未選択に関係なく2Dカーソルを移動します。',
        'Register smart_uv_suite.cursor_to_hover_uv_vertex in Preferences > Keymap > Image Editor > UV Editor. This tool is intended for keymap execution because the hover position is read from the key event.',
        'プリファレンス > キーマップ > 画像エディター > UVエディター に smart_uv_suite.cursor_to_hover_uv_vertex を登録して使います。ホバー位置をキーイベントから読むため、キーマップ実行前提の機能です。',
        operators=('smart_uv_suite.cursor_to_hover_uv_vertex', 'smart_uv_suite.copy_operator_id'),
        workspace_keywords=(),
    ),
    'operation_uv_vertex_slide': _entry(
        'Vertex Slide', '頂点スライド',
        'Slides selected UV vertices along their connected UV edges. Mesh vertex positions stay unchanged.',
        '選択したUV頂点を、つながっているUVの辺に沿って移動します。3Dメッシュの頂点座標は変わりません。',
        'In UV Edit Mode, select UV vertices, click Vertex Slide, then move the pointer along an edge. The pointer first jumps onto a selected vertex, and the vertices follow the edge in the direction you move. Left-click or press Enter to confirm, or press Esc to cancel. To assign your own shortcut, use transform.vert_slide under Preferences > Keymap > Image > UV Editor.',
        'UV編集モードで頂点を選び、「頂点スライド」を押してマウスを辺に沿って動かします。押すとマウスが選択頂点の上へ移り、動かした向きの辺に沿って頂点が動きます。左クリックまたはEnterで確定し、Escで取り消せます。ショートカットを割り当てる場合は、プリファレンスのキーマップで「画像 > UVエディター」に transform.vert_slide を登録します。',
        operators=('smart_uv_suite.uv_vertex_slide', 'transform.vert_slide', 'smart_uv_suite.copy_operator_id'),
        workspace_keywords=(),
    ),
    'operation_axis_constraint_memory': _entry(
        'Axis Constraint Memory', '軸拘束の記憶',
        'Reuses only the U, V, or free-axis constraint from the previous UV translate operation when Immediate Select starts a drag-move.',
        '即時選択がドラッグ移動を開始する際、直前のUV移動で使用したU軸、V軸、フリー移動の拘束だけを再利用します。',
        'The feature passes a transform constraint to Blender. It does not directly move UV coordinates, change selection, or add extra elements to the transform.',
        'Blenderの移動操作へ軸拘束を渡すだけの機能です。UV座標を直接変更したり、選択状態を増やしたり、別エレメントを変形対象へ追加したりしません。',
        operators=('smart_uv_suite.instant_select_drag_move',),
        workspace_keywords=('operation_axis_constraint_memory_enabled',),
    ),

    'operation_uv_editor_ownership': _entry(
        'UV Editor Ownership', 'UVエディター操作の管理',
        'Controls the UV Editor interaction surfaces owned by Smart UV Suite: exact crossing selection for edges and faces, and the proportional cursor entry.',
        'Smart UV Suiteが担当するUVエディター操作を管理します。辺・面の正確な交差選択と、UVプロポーショナル編集カーソル入力を個別に切り替えます。',
        'Enable only the functions needed for the current UV workflow. These options affect the UV Editor only; SmartTransform retains its 3D View interaction ownership.',
        '現在のUV作業に必要な機能だけをONにします。これらの設定はUVエディターだけに作用し、SmartTransformが担当する3Dビュー操作には影響しません。',
        operators=('smart_uv_suite.uv_crossing_gesture', 'smart_uv_suite.uv_crossing_select_edges', 'smart_uv_suite.uv_crossing_select_faces', 'image.smart_uv_proportional_size_cursor'),
        workspace_keywords=('operation_uv_crossing_select_edges_enabled', 'operation_uv_crossing_select_faces_enabled', 'operation_uv_proportional_cursor_keymap_enabled'),
    ),

    'keymap_info': _entry(
        'Keymap Info', 'キーマップ情報',
        'Lists every Preferences > Keymap entry that Smart UV Suite creates for operation helpers, including function name, registration location, operator id, registration status, and active status.',
        'Smart UV Suiteが操作補助用にプリファレンスのキーマップへ作成する全項目を、機能名、登録場所、登録ID、登録状態、有効状態と一緒に一覧表示します。',
        'Use Delete/Re-register to remove or recreate add-on keymap rows. Use Enable/Disable to switch active state without changing the surrounding UI layout.',
        '「削除/再登録」でアドオン用キーマップ行を削除・再作成します。「有効/無効」で登録済みキーマップの有効状態を切り替えます。',
        operators=('smart_uv_suite.keymap_info_action', 'smart_uv_suite.copy_operator_id'),
        workspace_keywords=('operation_instant_select_enabled', 'operation_uv_gizmo_grip_fix_enabled'),
    ),
    'pack_auto_packing': _entry(
        'Auto Packing', '自動パッキング',
        'Consolidates Pack, UDIM, Atlas, Trim, Hotspot, density, stack, seed-search, and bake-safe automatic layouts into one selectable packing route.',
        'パック、UDIM、アトラス、トリム、ホットスポット、密度、スタック、Seed探索、ベイク安全配置などの自動配置を1つの選択式パッキング経路へ集約します。',
        'Choose one automatic packing method, set margin, shape, rotation, scale, pin-lock, seed, tile, and density options, then run Auto Pack. Only fully face-selected UV Editor faces are affected.',
        '自動パッキング方法を1つ選び、余白、形状、回転、スケール、ピン固定、Seed、タイル、密度関連を設定して自動パックを実行します。対象はUVエディターで完全に面選択されている面だけです。',
        operators=('smart_uv_suite.unified_auto_pack',),
        workspace_keywords=('unified_auto_pack_mode', 'unified_pack_margin_px', 'unified_pack_margin', 'unified_pack_margin_method', 'unified_pack_shape_method', 'unified_pack_rotate', 'unified_pack_scale', 'unified_pack_lock_pinned', 'unified_pack_use_seed', 'unified_pack_seed', 'unified_pack_target_tile', 'unified_pack_udim_u', 'unified_pack_udim_v'),
    ),
    'native_auto_packing': _entry(
        'Auto Packing', '自動パッキング',
        'Uses the same consolidated Smart UV auto-packing route from the compact native panel.',
        'コンパクトな標準連携パネルからも、Smart UVの同じ統合自動パッキング経路を使用します。',
        'The selection scope and protection rules are identical to the main Packing section: only fully face-selected UV Editor faces are packed, and unselected UVs remain unchanged.',
        '選択範囲と保護ルールはメインのパッキング項目と同じです。UVエディターで完全に面選択されている面だけをパックし、未選択UVは変更しません。',
        operators=('smart_uv_suite.unified_auto_pack',),
        workspace_keywords=('unified_auto_pack_mode', 'unified_pack_margin_px', 'unified_pack_margin', 'unified_pack_margin_method', 'unified_pack_shape_method', 'unified_pack_rotate', 'unified_pack_scale'),
    ),
    'basic_map_channels': _entry(
        'Map Channels', 'マップチャンネル',
        'Shows every selected mesh object and the unwrap map channel assigned to each object, then edits the object row selected in that list.',
        '選択中の全メッシュオブジェクトと各オブジェクトの展開使用マップチャンネルを表示し、リストで選択したオブジェクトだけを編集します。',
        'Select an object row, choose its unwrap map channel, rename the selected channel from the popup, add a named channel from the popup, remove the target channel, or move the target channel up and down. Use the row checkboxes and Unify Checked when multiple selected objects should share the same unwrap map-channel index and map-channel name.',
        'オブジェクト行を選択し、そのオブジェクトの展開使用マップチャンネルを選択します。チャンネル名変更はポップアップで新名称を入力し、追加もポップアップで新規名を入力します。展開対象を削除、上へ移動、下へ移動はリスト選択中のオブジェクトだけに実行されます。複数オブジェクトの展開使用マップチャンネルのインデックス番号とマップチャンネル名を揃える場合は、行のチェックボックスと「チェック対象を統一」を使います。',
        operators=('smart_uv_suite.map_channel_object_select', 'smart_uv_suite.map_channel_toggle_unify_check', 'smart_uv_suite.map_channel_unify_checked', 'smart_uv_suite.map_channel_rename', 'smart_uv_suite.map_channel_add', 'smart_uv_suite.map_channel_remove', 'smart_uv_suite.map_channel_move'),
        workspace_keywords=('map_channel_object_name', 'unwrap_map_channel', 'map_channel_new_name'),
    ),
    'native_basic_map_channels': _entry(
        'Map Channels', 'マップチャンネル',
        'Provides the same multi-object map-channel object list and selected-row controls inside the compact native panel.',
        'コンパクトな標準連携パネル内でも、マルチオブジェクト対応のマップチャンネル用オブジェクトリストと、選択行専用の操作を同じように扱います。',
        "Use the object list to pick the mesh object to edit, then choose its unwrap target, rename the selected channel, add a named channel, remove the target channel, move it up and down, or unify checked objects to the selected row's target index and name.",
        'オブジェクトリストで編集するメッシュオブジェクトを選び、そのオブジェクトの展開対象チャンネルの指定、名称変更、名前付きチャンネル追加、展開対象削除、上/下移動、またはチェック済みオブジェクトの対象インデックスと名前の統一を行います。',
        operators=('smart_uv_suite.map_channel_object_select', 'smart_uv_suite.map_channel_toggle_unify_check', 'smart_uv_suite.map_channel_unify_checked', 'smart_uv_suite.map_channel_rename', 'smart_uv_suite.map_channel_add', 'smart_uv_suite.map_channel_remove', 'smart_uv_suite.map_channel_move'),
        workspace_keywords=('map_channel_object_name', 'unwrap_map_channel', 'map_channel_new_name'),
    ),
    'native_io_hub': _entry(
        'Output / Support Hub', '出力/サポートハブ',
        'Collects settings export, report creation, and generated-data cleanup commands.',
        '設定出力、レポート作成、生成データ整理のコマンドをまとめます。',
        'Reports are written as Blender text blocks for quick inspection without adding external files unless an explicit export command is used.',
        'レポートは、明示的な外部出力コマンドを使わない限り、外部ファイルを増やさずBlenderテキストブロックとして作成します。',
        operators=('smart_uv_suite.native_io_action',),
        workspace_keywords=('tool_runtime_log_name', 'batch_report_name', 'support_bundle_name', 'validation_report_name'),
    ),
    'native_io_support_note': _entry(
        'Output Note', '出力メモ',
        'Explains how report output is stored by the support and output commands.',
        'サポート/出力コマンドによるレポート保存先の扱いを説明します。',
        'Use the report commands for quick internal inspection. Use explicit export commands when an external file is required.',
        '素早く確認する場合はレポートコマンドを使います。外部ファイルが必要な場合は明示的な出力コマンドを使ってください。',
        operators=('smart_uv_suite.native_io_action',),
        workspace_keywords=('tool_runtime_log_name', 'batch_report_name'),
    ),
})

STAGE_KEY_TO_HELP = {
    'ui.stage.prepare': 'stage_prepare',
    'ui.stage.arrange': 'stage_arrange',
    'ui.stage.mesh': 'stage_mesh',
    'ui.stage.layout': 'stage_layout',
    'ui.stage.inspect': 'stage_inspect',
    'ui.stage.maps': 'stage_maps',
    'ui.stage.bake': 'stage_bake',
}

CATEGORY_BY_TAB = {
    'WORKFLOW': 'category_workflow',
    'TRANSFORM': 'category_transform',
    'LAYOUT': 'category_layout',
    'ANALYZE': 'category_analyze',
    'MAPS': 'category_maps',
    'SYMMETRY': 'category_symmetry',
    'ATLAS': 'category_atlas',
}


def _op_exists(op_id: str) -> bool:
    if '.' not in str(op_id or ''):
        return False
    head, tail = str(op_id).split('.', 1)
    try:
        group = getattr(bpy.ops, head, None)
        if group is None:
            return False
        op = getattr(group, tail, None)
        rna = op.get_rna_type()
        identifier = str(getattr(rna, 'identifier', '') or '')
        return bool(identifier) and identifier not in {'Operator', 'OperatorProperties', 'UnknownType', 'bpy_struct'}
    except Exception:
        return False


def _operator_rna(op_id: str):
    if '.' not in str(op_id or ''):
        return None
    head, tail = str(op_id).split('.', 1)
    try:
        op = getattr(getattr(bpy.ops, head, None), tail, None)
        if op is None:
            return None
        rna = op.get_rna_type()
        identifier = str(getattr(rna, 'identifier', '') or '')
        if not identifier or identifier in {'Operator', 'OperatorProperties', 'UnknownType', 'bpy_struct'}:
            return None
        return rna
    except Exception:
        return None



def _ui_descriptions_module():
    try:
        from . import ui_descriptions as _uid
        return _uid
    except Exception:
        return None


def _operator_label(op_id: str, context=None) -> str:
    rna = _operator_rna(op_id)
    try:
        if rna is not None:
            name = getattr(rna, 'name', '') or op_id
            return _inline(name, context)
    except Exception:
        pass
    return str(op_id or '')


@lru_cache(maxsize=1)
def _operator_tooltip_map() -> dict[str, Any]:
    path = Path(__file__).resolve().parent / 'data' / 'operator_tooltips.json'
    try:
        raw = json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        return {}
    if isinstance(raw, dict) and isinstance(raw.get('tooltips'), dict):
        raw = raw.get('tooltips')
    return dict(raw or {}) if isinstance(raw, dict) else {}


def _normalize_operator_tooltip_key(op_id: str) -> tuple[str, ...]:
    raw = str(op_id or '').strip()
    keys = [raw]
    if '.' in raw:
        prefix, suffix = raw.split('.', 1)
        keys.append(f'{prefix.upper()}_OT_{suffix}')
        keys.append(f'{prefix}_OT_{suffix}')
        keys.append(suffix)
    return tuple(dict.fromkeys(key for key in keys if key))


def _tooltip_text_from_data(value: Any, context=None) -> str:
    if isinstance(value, str):
        return _inline(value, context)
    if not isinstance(value, dict):
        return ''
    preferred_keys = ('ja', 'description_ja', 'tooltip_ja', 'overview_ja', 'body_ja') if _is_ja(context) else ('en', 'description_en', 'tooltip_en', 'overview_en', 'body_en')
    fallback_keys = ('description', 'tooltip', 'summary', 'overview', 'body')
    for key in preferred_keys + fallback_keys:
        text = str(value.get(key) or '').strip()
        if text:
            return _inline(text, context)
    return ''


def _operator_tooltip_desc(op_id: str, context=None) -> str:
    tooltips = _operator_tooltip_map()
    if not tooltips:
        return ''
    for key in _normalize_operator_tooltip_key(op_id):
        desc = _tooltip_text_from_data(tooltips.get(key), context)
        if desc:
            return desc
    return ''


def _operator_fallback_desc(op_id: str, context=None) -> str:
    ident = str(op_id or '').strip()
    tail = ident.split('.', 1)[-1].replace('_', ' ') if ident else ''
    if not tail:
        return ''
    return _pick(
        f'Runs the UV Suite command for {tail}. Prepare the relevant mesh, UV island, object, or report setting first, then execute the command from the N-panel.',
        f'{tail} に対応するUV Suiteコマンドを実行します。先に関連するメッシュ、UVアイランド、オブジェクト、またはレポート設定を準備してから、Nパネルで実行します。',
        context,
    )


def _operator_desc(op_id: str, context=None, properties=None) -> str:
    uid = _ui_descriptions_module()
    if uid is not None:
        try:
            desc = str(uid.describe_operator(str(op_id or ''), properties or {}, context) or '').strip()
            if desc:
                return _inline(desc, context)
        except Exception:
            pass
    desc = _operator_tooltip_desc(op_id, context)
    if desc:
        return desc
    rna = _operator_rna(op_id)
    try:
        if rna is not None:
            desc = str(getattr(rna, 'description', '') or '').strip()
            if desc:
                return _inline(desc, context)
    except Exception:
        pass
    try:
        from . import native_tool_catalog as _catalog
        for item in tuple(getattr(_catalog, 'ALL_NATIVE_OPERATOR_CATALOG', ()) or ()):  # type: ignore[attr-defined]
            if str(item[0] or '') == str(op_id or ''):
                return _inline(str(item[2] or ''), context)
    except Exception:
        pass
    return _operator_fallback_desc(op_id, context)

def _property_default(prop) -> str:
    for attr in ('default', 'default_array'):
        try:
            value = getattr(prop, attr)
            if value is not None:
                return str(value)
        except Exception:
            pass
    return ''


def _enum_items_text(prop, context=None) -> str:
    try:
        items = []
        for item in getattr(prop, 'enum_items', ()) or ():
            ident = str(getattr(item, 'identifier', '') or '')
            name = _inline(getattr(item, 'name', '') or ident, context)
            desc = _inline(getattr(item, 'description', '') or '', context)
            if desc:
                items.append(f'{ident}: {name} - {desc}')
            else:
                items.append(f'{ident}: {name}')
        return '; '.join(items)
    except Exception:
        return ''


def _iter_rna_properties(rna, context=None, *, skip_tool_runtime: bool = True):
    if rna is None:
        return
    try:
        props = list(getattr(rna, 'properties', ()) or ())
    except Exception:
        props = []
    for prop in props:
        try:
            ident = str(getattr(prop, 'identifier', '') or '')
            if not ident or ident == 'rna_type' or ident.startswith('_'):
                continue
            if skip_tool_runtime and ident in {'bl_idname', 'bl_label', 'bl_description'}:
                continue
            name = _inline(getattr(prop, 'name', '') or ident, context)
            desc = _inline(getattr(prop, 'description', '') or '', context)
            ptype = str(getattr(prop, 'type', '') or '')
            default = _property_default(prop)
            enum_text = _enum_items_text(prop, context) if ptype == 'ENUM' else ''
            yield {
                'id': ident,
                'name': name,
                'description': desc,
                'type': ptype,
                'default': default,
                'enum': enum_text,
            }
        except Exception:
            continue


def _operator_settings(op_id: str, context=None) -> list[dict[str, str]]:
    rna = _operator_rna(op_id)
    if rna is None:
        return []
    return list(_iter_rna_properties(rna, context=context))


_FUNCTION_ENUM_PROPS = (
    'action', 'mode', 'preset', 'profile', 'target', 'target_mode',
    'apply_mode', 'execution_mode', 'prep_mode', 'issue', 'direction', 'axis',
    'library_kind', 'merge_mode', 'tile_mode', 'group_mode', 'sort_mode',
)


def _primary_enum_property(rna, context=None):
    if rna is None:
        return None
    try:
        props = getattr(rna, 'properties', None)
    except Exception:
        props = None
    if props is None:
        return None
    for name in _FUNCTION_ENUM_PROPS:
        try:
            prop = props.get(name)
            if prop is not None and str(getattr(prop, 'type', '') or '') == 'ENUM':
                return prop
        except Exception:
            continue
    try:
        for prop in props:
            try:
                if str(getattr(prop, 'identifier', '') or '') == 'rna_type':
                    continue
                if str(getattr(prop, 'type', '') or '') == 'ENUM':
                    return prop
            except Exception:
                continue
    except Exception:
        pass
    return None


def _enum_item_rows_for_operator(op_id: str, context=None) -> list[dict[str, str]]:
    rna = _operator_rna(op_id)
    prop = _primary_enum_property(rna, context=context)
    if prop is None:
        return []
    prop_id = str(getattr(prop, 'identifier', '') or '')
    prop_name = _inline(getattr(prop, 'name', '') or prop_id, context)
    rows: list[dict[str, str]] = []
    try:
        enum_items = tuple(getattr(prop, 'enum_items', ()) or ())
    except Exception:
        enum_items = tuple()
    for item in enum_items:
        try:
            ident = str(getattr(item, 'identifier', '') or '')
            if not ident:
                continue
            name = _inline(getattr(item, 'name', '') or ident, context)
            desc = _inline(getattr(item, 'description', '') or '', context)
            if not desc:
                desc = _operator_desc(op_id, context)
            rows.append({'prop': prop_id, 'prop_name': prop_name, 'id': ident, 'name': name, 'description': desc})
        except Exception:
            continue
    return rows


def _function_usage_text(op_id: str, row: dict[str, str] | None = None, context=None) -> str:
    row = row or {}
    prop = str(row.get('prop') or '')
    ident = str(row.get('id') or '')
    uid = _ui_descriptions_module()
    if uid is not None:
        try:
            props = {prop: ident} if prop and ident else {}
            usage = str(uid.usage_for_operator(str(op_id or ''), props, context) or '').strip()
            if usage:
                return usage
        except Exception:
            pass
    if prop and ident:
        return _pick(
            f'Prepare the required mesh, UV selection, active UV map, and related settings, then run the button or mode assigned to {prop}={ident}. Only that individual function is executed.',
            f'必要なメッシュ、UV選択、アクティブUVマップ、関連設定を準備してから、{prop}={ident} が割り当てられたボタンまたはモードを実行します。この個別機能だけが実行されます。',
            context,
        )
    return _pick(
        'Prepare the required mesh, UV selection, active UV map, and related settings, then press this button.',
        '必要なメッシュ、UV選択、アクティブUVマップ、関連設定を準備してから、このボタンを押します。',
        context,
    )


def _draw_function_details(layout, context, entry: HelpEntry) -> None:
    operators = tuple(dict.fromkeys(str(op or '') for op in entry.operators if str(op or '').strip()))
    box = layout.box()
    _wrap(box, _pick('1. Functions in This Item', '1. この項目内の機能', context), context, icon='TOOL_SETTINGS')
    if not operators:
        _wrap(
            box,
            _pick(
                'This item is generated from the current Blender context and does not expose a fixed operator list.  The visible buttons in the item are the executable functions; each uses its own tooltip and current setting values.',
                'この項目は現在のBlenderコンテキストから生成されるため、固定のオペレーター一覧を持ちません。項目内に表示されている各ボタンが実行機能で、それぞれ個別ツールチップと現在の設定値に従います。',
                context,
            ),
            context,
            icon='QUESTION',
        )
        return
    for op_id in operators:
        row_box = box.box()
        label = _operator_label(op_id, context) or op_id
        status = _pick('not registered in this session', 'このセッションでは未登録', context) if not _op_exists(op_id) else ''
        heading = label if _op_exists(op_id) else f'{label} - {status}'
        _wrap(row_box, heading, context, icon='CHECKMARK' if _op_exists(op_id) else 'INFO')
        rows = _enum_item_rows_for_operator(op_id, context)
        if rows:
            for item in rows:
                sub = row_box.box()
                heading = f"{item.get('name') or item.get('id')}"
                _wrap(sub, heading, context, icon='DOT')
                desc = str(item.get('description') or '').strip()
                if desc:
                    _wrap(sub, _pick('Function: ', '機能: ', context) + desc, context)
                _wrap(sub, _pick('Usage: ', '使い方: ', context) + _function_usage_text(op_id, item, context), context, icon='PLAY')
        else:
            desc = _operator_desc(op_id, context)
            if desc:
                _wrap(row_box, _pick('Function: ', '機能: ', context) + desc, context)
            _wrap(row_box, _pick('Usage: ', '使い方: ', context) + _function_usage_text(op_id, None, context), context, icon='PLAY')




def _scoped_help_record(help_id: str) -> dict[str, Any]:
    """Return buttons/properties captured while drawing the visible N-panel item."""
    key = str(help_id or '').strip()
    if not key:
        return {}
    try:
        from . import stable_ui as _stable_ui
        snapshot = _stable_ui.help_scope_snapshot()
        record = snapshot.get(key) if isinstance(snapshot, dict) else None
        return dict(record or {}) if isinstance(record, dict) else {}
    except Exception:
        return {}


class _PropsForDescription:
    def __init__(self, values: dict[str, Any]):
        for key, value in dict(values or {}).items():
            try:
                setattr(self, str(key), value)
            except Exception:
                pass


def _operator_description_for_props(op_id: str, props: dict[str, Any], context=None) -> str:
    """Read an operator tooltip for the actual button properties drawn in the UI."""
    op_id = str(op_id or '').strip()
    props = dict(props or {})
    uid = _ui_descriptions_module()
    try:
        if uid is not None:
            desc = str(uid.describe_operator(op_id, props, context) or '').strip()
            if desc:
                return _inline(desc, context)
    except Exception:
        pass
    try:
        package = __package__ or ''
        import sys
        for module in ():# disabled explicit legacy iteration
            if module is None:
                continue
            mod_name = str(getattr(module, '__name__', '') or '')
            if package and not (mod_name == package or mod_name.startswith(package + '.')):
                continue
            for cls in tuple(getattr(module, '__dict__', {}).values()):
                if not isinstance(cls, type):
                    continue
                if str(getattr(cls, 'bl_idname', '') or '') != op_id:
                    continue
                desc_fn = getattr(cls, 'description', None)
                if callable(desc_fn):
                    try:
                        desc = str(desc_fn(context, _PropsForDescription(props)) or '').strip()
                        if desc:
                            return _inline(desc, context)
                    except Exception:
                        pass
                desc = str(getattr(cls, 'bl_description', '') or '').strip()
                if desc:
                    return _inline(desc, context)
    except Exception:
        pass
    return _operator_desc(op_id, context)


def _operation_prop_from_record(record: dict[str, Any]) -> tuple[str, str]:
    props = dict(record.get('props') or {}) if isinstance(record, dict) else {}
    for key in _FUNCTION_ENUM_PROPS:
        value = str(props.get(key) or '').strip()
        if value:
            return key, value
    for key, value in props.items():
        value = str(value or '').strip()
        if value:
            return str(key), value
    return '', ''



def _draw_static_section_controls(layout, context, help_id: str, entry) -> bool:
    uid = _ui_descriptions_module()
    if uid is None:
        return False
    try:
        controls = list(uid.section_controls(help_id, entry, context) or [])
    except Exception:
        controls = []
    if not controls:
        return False
    box = layout.box()
    _wrap(box, _pick('1. Functions and Settings in This Item', '1. この項目内の機能と設定', context), context, icon='TOOL_SETTINGS')
    seen: set[tuple[str, str, tuple[tuple[str, str], ...], str, str]] = set()
    for control in controls:
        if not isinstance(control, dict):
            continue
        ctype = str(control.get('type') or '')
        props = tuple(sorted((str(k), str(v)) for k, v in dict(control.get('props') or {}).items()))
        marker = (ctype, str(control.get('op_id') or control.get('property') or control.get('label_en') or ''), props, str(control.get('label_en') or ''), str(control.get('label_ja') or ''))
        if marker in seen:
            continue
        seen.add(marker)
        sub = box.box()
        label = str(uid.control_label(control, context) or '').strip()
        if ctype == 'operator':
            op_id = str(control.get('op_id') or '').strip()
            status = _pick('not registered in this session', 'このセッションでは未登録', context) if not _op_exists(op_id) else ''
            heading = label if _op_exists(op_id) else f'{label} - {status}'
            _wrap(sub, heading, context, icon='CHECKMARK' if _op_exists(op_id) else 'INFO')
        elif ctype == 'property':
            _wrap(sub, label, context, icon='PREFERENCES')
        else:
            _wrap(sub, label or _pick('Function', '機能', context), context, icon='DOT')
        desc = str(uid.describe_control(control, context) or '').strip()
        if desc:
            _wrap(sub, _pick('Function: ', '機能: ', context) + desc, context)
        usage = str(uid.control_usage(control, context) or '').strip()
        if usage:
            _wrap(sub, _pick('Usage: ', '使い方: ', context) + usage, context, icon='PLAY')
    return True

def _draw_scoped_functions(layout, context, help_id: str, entry) -> bool:
    """Draw exact functions captured from the UI item that owns this Help button."""
    record = _scoped_help_record(help_id)
    operators = [dict(item) for item in list(record.get('operators') or []) if isinstance(item, dict)] if record else []
    properties = [dict(item) for item in list(record.get('properties') or []) if isinstance(item, dict)] if record else []
    if not operators and not properties:
        return _draw_static_section_controls(layout, context, help_id, entry)

    box = layout.box()
    _wrap(box, _pick('1. Functions and Settings in This Item', '1. この項目内の機能と設定', context), context, icon='TOOL_SETTINGS')
    seen_ops: set[tuple[str, tuple[tuple[str, str], ...], str, str]] = set()
    for item in operators:
        op_id = str(item.get('op_id') or '').strip()
        if not op_id:
            continue
        props = {str(k): str(v) for k, v in dict(item.get('props') or {}).items()}
        label = _pick(str(item.get('label_en') or item.get('symbol') or op_id), str(item.get('label_ja') or item.get('label_en') or item.get('symbol') or op_id), context)
        symbol = str(item.get('symbol') or '').strip()
        sig = (op_id, tuple(sorted(props.items())), label, symbol)
        if sig in seen_ops:
            continue
        seen_ops.add(sig)
        sub = box.box()
        title = label
        if symbol and symbol != label:
            title = f'{symbol}  {label}'
        prop_key, prop_val = _operation_prop_from_record(item)
        status = _pick('not registered in this session', 'このセッションでは未登録', context) if not _op_exists(op_id) else ''
        heading = title if _op_exists(op_id) else f'{title} - {status}'
        _wrap(sub, heading, context, icon='CHECKMARK' if _op_exists(op_id) else 'INFO')
        desc = _operator_description_for_props(op_id, props, context)
        if desc:
            _wrap(sub, _pick('Function: ', '機能: ', context) + desc, context)
        usage_text = ''
        uid = _ui_descriptions_module()
        try:
            if uid is not None:
                usage_text = str(uid.usage_for_operator(op_id, props, context) or '').strip()
        except Exception:
            usage_text = ''
        if not usage_text:
            usage_text = _function_usage_text(op_id, {'prop': prop_key, 'id': prop_val} if prop_key and prop_val else None, context)
        _wrap(sub, _pick('Usage: ', '使い方: ', context) + usage_text, context, icon='PLAY')

    if properties:
        sub = box.box()
        _wrap(sub, _pick('Editable controls in this item', 'この項目内の編集可能コントロール', context), context, icon='PREFERENCES')
        for item in properties:
            _draw_setting_detail(sub, context, item, icon='DOT')

    return True

def _workspace_settings(context=None, keywords: Iterable[str] = ()) -> list[dict[str, str]]:
    try:
        ws = getattr(getattr(context, 'scene', None), 'suv_workspace', None)
        rna = getattr(ws, 'bl_rna', None)
    except Exception:
        ws = None
        rna = None
    if ws is None or rna is None:
        return []
    keys = tuple(str(k or '').lower() for k in (keywords or ()) if str(k or '').strip())
    result = []
    for item in _iter_rna_properties(rna, context=context):
        if keys:
            hay = f"{item.get('id','')} {item.get('name','')} {item.get('description','')}".lower()
            if not any(k in hay for k in keys):
                continue
        result.append(item)
    return result


def _catalog_operators_for_namespace(namespace: str) -> tuple[str, ...]:
    namespace = str(namespace or '').strip().lower()
    try:
        from . import native_tool_catalog as _catalog
        ops = []
        for item in tuple(getattr(_catalog, 'ALL_NATIVE_OPERATOR_CATALOG', ()) or ()):  # type: ignore[attr-defined]
            op_id = str(item[0] or '')
            if namespace == 'other':
                if '.' not in op_id or op_id.split('.', 1)[0] not in {'uv', 'suv', 'mesh', 'object'}:
                    ops.append(op_id)
            elif op_id.startswith(namespace + '.'):
                ops.append(op_id)
        return tuple(dict.fromkeys(ops))
    except Exception:
        return tuple()


def _record_for_alias(alias: str) -> dict[str, Any]:
    alias = str(alias or '').strip()
    try:
        from . import ui_runtime as _ui_runtime
        records = getattr(_ui_runtime, '_RECORDS_BY_ALIAS', {})
        if isinstance(records, dict) and isinstance(records.get(alias), dict):
            return records.get(alias) or {}
    except Exception:
        pass
    try:
        from . import loader
        for record in loader.get_records():
            spec = record.get('spec') or {}
            if str(spec.get('alias') or '') == alias:
                return record
    except Exception:
        pass
    return {}


def _integrated_entry(help_id: str, fallback_en: str, fallback_ja: str, context=None) -> tuple[HelpEntry, tuple[str, ...]]:
    prefix, alias = (help_id.split(':', 1) + [''])[:2]
    record = _record_for_alias(alias)
    spec = record.get('spec') if isinstance(record, dict) else {}
    if not isinstance(spec, dict):
        spec = {}
    name = str(spec.get('display_name') or alias or fallback_en or 'Integrated Tool').strip()
    desc = str(spec.get('description') or '').strip()
    operators: list[str] = []
    try:
        for cls in tuple(record.get('operators', ()) or ()):  # type: ignore[union-attr]
            op_id = str(getattr(cls, 'bl_idname', '') or '')
            if op_id and op_id not in operators:
                operators.append(op_id)
    except Exception:
        pass
    overview_en = desc or f'{name} is a migrated integrated tool exposed inside UV Suite.'
    overview_ja = _inline(desc, context) if desc else f'{name} は UV Suite 内に移植表示された統合ツールです。'
    if prefix == 'integrated_menus':
        title_en, title_ja = f'{name} Menus', f'{name} メニュー'
        overview_en = f'Lists callable menus provided by {name}.'
        overview_ja = f'{name} が提供する呼び出し可能なメニューを一覧表示します。'
        usage_en = 'Open this section, then click a menu button.  Pie menus and standard menus are invoked through Blender menu calls.'
        usage_ja = 'このセクションを開き、メニューボタンを押します。パイメニューと通常メニューはBlenderのメニュー呼び出し経由で開きます。'
    elif prefix == 'integrated_operators':
        title_en, title_ja = f'{name} Operators', f'{name} オペレーター'
        usage_en = 'Click an operator button after preparing the required object, selection, UV map, or editor mode.  Some operators may open their own dialog.'
        usage_ja = '必要なオブジェクト、選択、UVマップ、エディターモードを準備してからオペレーターボタンを押します。一部のオペレーターは独自ダイアログを開く場合があります。'
    elif prefix == 'integrated_settings':
        title_en, title_ja = f'{name} Settings', f'{name} 設定'
        usage_en = 'Edit only the settings needed for the current task.  Changes are drawn from the migrated preference or property block when the integrated tool is loaded.'
        usage_ja = '現在の作業に必要な設定だけを編集します。統合ツールが読み込まれている場合、移植済みプリファレンスまたはプロパティブロックから設定を表示します。'
    else:
        title_en, title_ja = name, name
        usage_en = 'Initialize the tool only when needed, then use its quick actions, menus, operators, or settings.  Keep always-on behavior controlled from the top toggle group.'
        usage_ja = '必要な時だけツールを初期化し、クイック操作、メニュー、オペレーター、設定を使います。常時機能は最上部の切り替えグループで管理してください。'
    return HelpEntry(title_en, title_ja, overview_en, overview_ja, usage_en, usage_ja, operators=tuple(operators), related_alias=alias, include_integrated_preferences=True), tuple(operators)


def _native_entry(help_id: str, fallback_en: str, fallback_ja: str) -> HelpEntry:
    namespace = help_id.split(':', 1)[1] if ':' in help_id else 'uv'
    labels = {
        'uv': ('UV Operators', 'UVオペレーター'),
        'suv': ('UV Suite Operators', 'UV Suiteオペレーター'),
        'mesh': ('Mesh Operators', 'メッシュオペレーター'),
        'object': ('Object Operators', 'オブジェクトオペレーター'),
        'other': ('Other Operators', 'その他オペレーター'),
    }
    title_en, title_ja = labels.get(namespace, (fallback_en or namespace, fallback_ja or namespace))
    return HelpEntry(
        title_en, title_ja,
        f'Lists registered or code-backed {title_en.lower()} included in UV Suite.',
        f'UV Suiteに含まれる{title_ja}を、登録済みまたはコード上の存在に基づいて一覧表示します。',
        'Use this catalog when the compact workflow tabs do not show the exact command you need.  Unregistered rows indicate code-backed commands that are not available in the current session.',
        'コンパクトなワークフロータブに目的のコマンドがない場合に使います。未登録表示の行は、コード上には存在するものの現在のセッションでは利用できないコマンドです。',
        operators=_catalog_operators_for_namespace(namespace),
    )


def _resolve_entry(help_id: str, title_en: str = '', title_ja: str = '', context=None) -> HelpEntry:
    raw = str(help_id or '').strip()
    if raw.startswith('stage_key:'):
        raw = STAGE_KEY_TO_HELP.get(raw.split(':', 1)[1], raw)
    if raw.startswith('tab:'):
        raw = CATEGORY_BY_TAB.get(raw.split(':', 1)[1].upper(), raw)
    entry = GROUPS.get(raw)
    if entry is not None:
        return entry
    if raw.startswith('integrated:') or raw.startswith('integrated_menus:') or raw.startswith('integrated_operators:') or raw.startswith('integrated_settings:'):
        entry, _ = _integrated_entry(raw, title_en, title_ja, context=context)
        return entry
    if raw.startswith('native:'):
        return _native_entry(raw, title_en, title_ja)
    if raw.startswith('operator:'):
        op_id = raw.split(':', 1)[1]
        label = _operator_label(op_id, context) or op_id
        desc = _operator_desc(op_id, context)
        return HelpEntry(
            label, label,
            desc or f'Runs the {op_id} command.',
            desc or f'{op_id} コマンドを実行します。',
            'Prepare the required selection and mode, then click the command button.  Review the settings listed below before running destructive operations.',
            '必要な選択状態とモードを準備し、コマンドボタンを押します。破壊的な処理の前に、下の設定項目を確認してください。',
            operators=(op_id,),
        )
    if raw.startswith('command:'):
        title = raw.split(':', 1)[1] or title_en or title_ja or 'Command Group'
        return HelpEntry(
            title_en or title, title_ja or title,
            'This command group exposes related UV Suite operations in a compact fallback or catalog section.',
            'このコマンドグループは、簡易フォールバックまたは一覧セクション内で関連するUV Suite操作をまとめて表示します。',
            'Use the group when the full workflow UI is unavailable or when auditing available commands.',
            'フルワークフローUIが利用できない場合、または利用可能なコマンドを確認する場合に使います。',
        )
    return HelpEntry(
        title_en or 'UV Suite Tool Group', title_ja or 'UV Suiteツールグループ',
        'This group contains related UV Suite tools.',
        'このグループには関連するUV Suiteツールがまとまっています。',
        'Open the group, prepare the required mesh or UV selection, then run the needed command.  Use the settings section below to understand available options.  Detailed explanations stay in this popup so the N-panel itself remains compact.',
        'グループを開き、必要なメッシュまたはUV選択を準備してから目的のコマンドを実行します。利用できるオプションは下の設定項目で確認してください。詳細説明はこのポップアップ側へ集約し、Nパネル本体はコンパクトに保ちます。',
    )


def _draw_operator_list(layout, context, entry: HelpEntry) -> None:
    operators = tuple(dict.fromkeys(str(op or '') for op in entry.operators if str(op or '').strip()))
    box = layout.box()
    _wrap(box, _pick('Included Functions', '含まれる機能', context), context, icon='TOOL_SETTINGS')
    if not operators:
        _wrap(box, _pick('This group does not expose a fixed operator list, or the list is generated dynamically by the current Blender context.', 'このグループには固定のオペレーター一覧がないか、現在のBlenderコンテキストから動的に生成されます。', context), context, icon='QUESTION')
        return
    for op_id in operators:
        row_box = box.box()
        label = _operator_label(op_id, context) or op_id
        status = _pick('registered', '登録済み', context) if _op_exists(op_id) else _pick('not registered in this session', 'このセッションでは未登録', context)
        _wrap(row_box, f'{label}  [{op_id}] - {status}', context, width=_wrap_width(context), icon='CHECKMARK' if _op_exists(op_id) else 'INFO')
        desc = _operator_desc(op_id, context)
        if desc:
            _wrap(row_box, desc, context)



def _integrated_preference_settings(alias: str, context=None) -> list[tuple[str, list[dict[str, str]]]]:
    alias = str(alias or '').strip()
    if not alias:
        return []
    record = _record_for_alias(alias)
    result: list[tuple[str, list[dict[str, str]]]] = []
    try:
        from . import preferences_proxy
    except Exception:
        preferences_proxy = None
    for cls in tuple(record.get('preferences', ()) or ()) if isinstance(record, dict) else ():
        try:
            title = _inline(getattr(cls, 'bl_label', '') or getattr(cls, '__name__', '') or 'Preferences', context)
            owner = None
            if preferences_proxy is not None:
                try:
                    owner = preferences_proxy.get_addon_preferences(context, getattr(cls, 'bl_idname', '') or getattr(cls, '__module__', ''), cls)
                except Exception:
                    owner = None
            rna = getattr(owner, 'bl_rna', None) or getattr(cls, 'bl_rna', None)
            props = list(_iter_rna_properties(rna, context=context))
            if props:
                result.append((title, props))
        except Exception:
            continue
    return result

def _draw_settings(layout, context, entry: HelpEntry) -> None:
    box = layout.box()
    _wrap(box, _pick('3. Settings', '3. 設定項目', context), context, icon='PREFERENCES')
    any_drawn = False

    extra = entry.extra_settings_ja if _is_ja(context) else entry.extra_settings_en
    for line in extra:
        _wrap(box, line, context, icon='DOT')
        any_drawn = True

    workspace = _workspace_settings(context, entry.workspace_keywords)
    if workspace:
        sub = box.box()
        _wrap(sub, _pick('Related workspace settings', '関連ワークスペース設定', context), context, icon='SCENE_DATA')
        for item in workspace:
            _draw_setting_detail(sub, context, item, icon='DOT')
        any_drawn = True

    for op_id in tuple(dict.fromkeys(str(op or '') for op in entry.operators if str(op or '').strip())):
        props = _operator_settings(op_id, context)
        if not props:
            continue
        sub = box.box()
        _wrap(sub, f'{_operator_label(op_id, context) or op_id} [{op_id}]', context, icon='TOOL_SETTINGS')
        for item in props:
            _draw_setting_detail(sub, context, item, icon='DOT')
        any_drawn = True

    if getattr(entry, 'include_integrated_preferences', False) and getattr(entry, 'related_alias', ''):
        for title, props in _integrated_preference_settings(getattr(entry, 'related_alias', ''), context):
            sub = box.box()
            _wrap(sub, f"{_pick('Integrated settings', '統合設定', context)}: {title}", context, icon='PREFERENCES')
            for item in props:
                _draw_setting_detail(sub, context, item, icon='DOT')
                any_drawn = True

    if not any_drawn:
        _wrap(
            box,
            _pick(
                'No extra editable settings were detected for this group in the current session.  Some commands run directly from the current selection, active object, UV editor mode, or saved workspace state.',
                '現在のセッションでは、このグループ専用の追加編集設定は検出されませんでした。一部のコマンドは現在の選択、アクティブオブジェクト、UVエディターモード、保存済みワークスペース状態から直接実行されます。',
                context,
            ),
            context,
            icon='QUESTION',
        )


def popup_title(help_id: str, title_en: str = '', title_ja: str = '', context=None) -> str:
    entry = _resolve_entry(help_id, title_en, title_ja, context=context)
    return _pick(entry.title_en, entry.title_ja, context)


def description(help_id: str, title_en: str = '', title_ja: str = '', context=None) -> str:
    entry = _resolve_entry(help_id, title_en, title_ja, context=context)
    return _pick(
        f'Open per-control help for every button and setting inside {entry.title_en}.',
        f'{entry.title_ja} 内にある各ボタンと各設定項目の説明を開きます。',
        context,
    )


def draw_popup(operator, context, layout) -> None:
    help_id = str(getattr(operator, 'help_id', '') or '')
    title_en = str(getattr(operator, 'title_en', '') or '')
    title_ja = str(getattr(operator, 'title_ja', '') or '')
    entry = _resolve_entry(help_id, title_en, title_ja, context=context)
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass
    title = _pick(entry.title_en, entry.title_ja, context)
    head = layout.box()
    _draw_wrapped_title(head, title, context, icon='QUESTION')

    # Smart UV Suite 1.8.114: prefer the exact per-control scope captured from
    # the current UI draw, then the static item catalog.  This avoids broad
    # section summaries and lists each button/setting independently.
    if _draw_scoped_functions(layout, context, help_id, entry):
        return

    try:
        from . import ui_tooltip_details_18114 as _suv_tooltip_details_18114
        draw_fn = getattr(_suv_tooltip_details_18114, 'draw_help_details', None)
        if callable(draw_fn) and bool(draw_fn(layout, context, help_id, wrap=_wrap, pick=_pick)):
            return
    except Exception:
        pass

    _draw_function_details(layout, context, entry)
    _draw_settings(layout, context, entry)


def invoke_popup(operator, context):
    try:
        title = popup_title(str(getattr(operator, 'help_id', '') or ''), str(getattr(operator, 'title_en', '') or ''), str(getattr(operator, 'title_ja', '') or ''), context)
        operator.bl_label = title
    except Exception:
        pass
    try:
        return context.window_manager.invoke_props_dialog(operator, width=HELP_POPUP_WIDTH)
    except Exception:
        return {'CANCELLED'}
