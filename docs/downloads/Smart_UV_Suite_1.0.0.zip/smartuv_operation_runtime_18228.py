# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Reliable UV Editor interaction and N-panel state persistence for Smart UV Suite.

This module intentionally owns only the seven Operation-section interaction
features and the persistence requested by the N-panel state-save option.
"""
from __future__ import annotations

import json
import math
import os
import sys
import time
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Sequence, Set, Tuple

import bpy
import bmesh
from bpy.app.handlers import persistent
from bpy.props import EnumProperty, FloatProperty, StringProperty
from mathutils import Vector

try:
    import gpu
    from gpu_extras.batch import batch_for_shader
except Exception:  # pragma: no cover - Blender without drawing support
    gpu = None
    batch_for_shader = None

MODULE_VERSION = (1, 8, 232)
_EPS = 1.0e-7

_LEGACY_SCAN_CACHE_KEY = "suv_scan_cache"
_LEGACY_SCAN_CACHE_KEYS = frozenset({
    "has_result", "time", "scope", "eps_zero", "check_out",
    "check_overlap", "precise_overlap", "flipped", "zero", "out",
    "overlap", "stretch_count", "stretch_worst", "stretch_avg",
})
_LEGACY_SCAN_CACHE_BOOL_KEYS = frozenset({
    "has_result", "check_out", "check_overlap", "precise_overlap",
})
_LEGACY_SCAN_CACHE_INT_KEYS = frozenset({
    "flipped", "zero", "out", "overlap", "stretch_count",
})
_LEGACY_SCAN_CACHE_FLOAT_KEYS = frozenset({
    "eps_zero", "stretch_worst", "stretch_avg",
})
_LEGACY_SCAN_CACHE_TEXT_KEYS = frozenset({"time", "scope"})
# -----------------------------------------------------------------------------
# Feature setting discovery
# -----------------------------------------------------------------------------


def _norm(value: Any) -> str:
    return "".join(ch for ch in str(value or "").casefold() if ch.isalnum())


_FEATURE_ALIASES: Dict[str, Dict[str, Tuple[str, ...]]] = {
    "instant_drag": {
        "ids": (
            "instant_select_drag", "immediate_select_drag", "instant_drag_move",
            "uv_instant_select_drag", "suv_instant_select_drag",
            "enable_instant_select_drag", "enable_immediate_select_drag",
        ),
        "labels": (
            "即時選択ドラッグ", "即時選択ドラッグ移動",
            "instant select drag", "immediate select drag", "instant selection drag",
        ),
    },
    "axis_memory": {
        "ids": (
            "remember_axis_constraint", "axis_constraint_memory", "remember_uv_axis",
            "uv_axis_memory", "suv_axis_constraint_memory", "enable_axis_memory",
        ),
        "labels": (
            "軸拘束の記憶", "軸制約の記憶", "remember axis constraint",
            "axis constraint memory", "remember transform axis",
        ),
    },
    "gizmo_assist": {
        "ids": (
            "uv_gizmo_grab_assist", "gizmo_grab_assist", "uv_gizmo_assist",
            "suv_gizmo_grab_assist", "enable_uv_gizmo_grab_assist",
        ),
        "labels": (
            "uvギズモ掴み補助", "uvギズモつかみ補助", "uv gizmo grab assist",
            "uv gizmo grab assistance", "gizmo grab assist",
        ),
    },
    "cross_edges": {
        "ids": (
            "crossing_selection_edges", "crossing_select_edges", "uv_crossing_edges",
            "suv_crossing_selection_edges", "enable_crossing_edges",
        ),
        "labels": (
            "crossing selection edges", "crossing selection: edges",
            "交差選択辺", "交差選択：辺", "交差選択:辺",
        ),
    },
    "cross_faces": {
        "ids": (
            "crossing_selection_faces", "crossing_select_faces", "uv_crossing_faces",
            "suv_crossing_selection_faces", "enable_crossing_faces",
        ),
        "labels": (
            "crossing selection faces", "crossing selection: faces",
            "交差選択面", "交差選択：面", "交差選択:面",
        ),
    },
    "proportional_cursor": {
        "ids": (
            "uv_proportional_cursor_entry", "proportional_cursor_entry",
            "uv_proportional_entry", "suv_proportional_cursor_entry",
            "enable_uv_proportional_cursor_entry",
        ),
        "labels": (
            "uv proportional cursor entry", "uv比例編集カーソル入力",
            "uvプロポーショナルカーソル入力", "比例編集カーソル入力",
            "uvプロポーショナル編集カーソル入力", "プロポーショナル編集カーソル入力",
        ),
    },
    "panel_state_save": {
        "ids": (
            "n_panel_state_save", "n_panel_state_persistence", "save_n_panel_state",
            "save_npanel_state", "remember_n_panel_state", "persist_n_panel_state",
            "suv_n_panel_state_save",
        ),
        "labels": (
            "nパネル状態保存", "n panel state save", "n-panel state save",
            "save n panel state", "remember n panel state",
        ),
    },
}


# Authoritative product identifiers (1.8.228 repair).
#
# The previous build-time "discovered" list bound instant_drag / axis_memory /
# gizmo_assist to the addon-preferences boolean ``npanel_state_save`` (an exact
# id match scores 100 and always beat the correct 95-point workspace label
# match), so those three interaction features followed the N-panel state-save
# checkbox instead of their real Operation toggles.  Every feature now names
# its real ``suv_workspace`` property; only panel_state_save keeps
# ``npanel_state_save``.
_DISCOVERED_FEATURE_IDS_18228 = {
    'instant_drag': ['operation_instant_select_enabled'],
    'axis_memory': ['operation_axis_constraint_memory_enabled'],
    'gizmo_assist': ['operation_uv_gizmo_grip_fix_enabled'],
    'cross_edges': ['operation_uv_crossing_select_edges_enabled'],
    'cross_faces': ['operation_uv_crossing_select_faces_enabled'],
    'proportional_cursor': ['operation_uv_proportional_cursor_keymap_enabled'],
    'panel_state_save': ['npanel_state_save'],
}
for _feature_key_18228, _feature_ids_18228 in _DISCOVERED_FEATURE_IDS_18228.items():
    if _feature_key_18228 in _FEATURE_ALIASES:
        _FEATURE_ALIASES[_feature_key_18228]["ids"] = tuple(dict.fromkeys(_FEATURE_ALIASES[_feature_key_18228]["ids"] + tuple(_feature_ids_18228)))


def _package_root() -> str:
    # __package__ is the complete extension namespace, e.g.
    # bl_ext.user_default.smart_uv_suite.
    return str(__package__ or "smart_uv_suite")


def _safe_pointer(value: Any) -> int:
    try:
        return int(value.as_pointer())
    except Exception:
        return id(value)


def _is_property_group(value: Any) -> bool:
    try:
        return isinstance(value, bpy.types.PropertyGroup)
    except Exception:
        return False


def _looks_addon_owned(identifier: str, value: Any = None) -> bool:
    text = _norm(identifier)
    if any(token in text for token in ("smartuv", "smartuvsuite", "suv")):
        return True
    if value is not None:
        try:
            rna_name = _norm(value.bl_rna.identifier)
            if any(token in rna_name for token in ("smartuv", "smartuvsuite", "suv")):
                return True
        except Exception:
            pass
        try:
            module_name = str(type(value).__module__ or "")
            if _package_root() in module_name or "smart_uv" in module_name.casefold():
                return True
        except Exception:
            pass
    return False


def _addon_preferences(context: Optional[bpy.types.Context]) -> Iterator[Tuple[str, Any]]:
    prefs = getattr(context, "preferences", None) if context is not None else getattr(bpy.context, "preferences", None)
    if prefs is None:
        return
    addons = getattr(prefs, "addons", None)
    if addons is None:
        return
    root = _package_root()
    leaf = root.rsplit(".", 1)[-1]
    seen: Set[int] = set()
    for key in (root, leaf, "smart_uv_suite"):
        try:
            entry = addons.get(key)
        except Exception:
            entry = None
        if entry is None:
            continue
        value = getattr(entry, "preferences", None)
        if value is None:
            continue
        ptr = _safe_pointer(value)
        if ptr not in seen:
            seen.add(ptr)
            yield (f"preferences:{key}", value)
    try:
        items = list(addons.items())
    except Exception:
        items = []
    for key, entry in items:
        if not (str(key).endswith("." + leaf) or "smart_uv" in str(key).casefold()):
            continue
        value = getattr(entry, "preferences", None)
        if value is None:
            continue
        ptr = _safe_pointer(value)
        if ptr not in seen:
            seen.add(ptr)
            yield (f"preferences:{key}", value)


def _host_instances(context: Optional[bpy.types.Context]) -> Iterator[Tuple[str, Any]]:
    ctx = context or bpy.context
    yielded: Set[int] = set()
    candidates: List[Tuple[str, Any]] = []
    for name in ("window_manager", "scene", "workspace", "screen"):
        value = getattr(ctx, name, None)
        if value is not None:
            candidates.append((name, value))
    tool_settings = getattr(getattr(ctx, "scene", None), "tool_settings", None)
    if tool_settings is not None:
        candidates.append(("tool_settings", tool_settings))
    candidates.extend(_addon_preferences(ctx) or [])
    for anchor, value in candidates:
        ptr = _safe_pointer(value)
        if ptr in yielded:
            continue
        yielded.add(ptr)
        yield anchor, value


def _iter_addon_structs(context: Optional[bpy.types.Context], max_depth: int = 3) -> Iterator[Tuple[str, Any]]:
    queue: List[Tuple[str, Any, int, bool]] = []
    for anchor, host in _host_instances(context):
        queue.append((anchor, host, 0, anchor.startswith("preferences:")))
    seen: Set[int] = set()
    while queue:
        path, value, depth, accepted = queue.pop(0)
        ptr = _safe_pointer(value)
        if ptr in seen:
            continue
        seen.add(ptr)
        if accepted or _is_property_group(value):
            yield path, value
        if depth >= max_depth:
            continue
        rna = getattr(value, "bl_rna", None)
        props = getattr(rna, "properties", ()) if rna is not None else ()
        for prop in props:
            identifier = str(getattr(prop, "identifier", ""))
            if not identifier or identifier == "rna_type" or getattr(prop, "type", "") != "POINTER":
                continue
            try:
                child = getattr(value, identifier)
            except Exception:
                continue
            if child is None or not _is_property_group(child):
                continue
            child_accepted = accepted or _looks_addon_owned(identifier, child)
            if child_accepted:
                queue.append((f"{path}.{identifier}", child, depth + 1, True))


def _feature_binding(context: Optional[bpy.types.Context], feature: str) -> Optional[Tuple[str, str, int]]:
    aliases = _FEATURE_ALIASES[feature]
    exact_ids = {_norm(item) for item in aliases["ids"]}
    label_tokens = {_norm(item) for item in aliases["labels"]}
    best: Optional[Tuple[str, str, int]] = None
    for path, struct in _iter_addon_structs(context):
        rna = getattr(struct, "bl_rna", None)
        props = getattr(rna, "properties", ()) if rna is not None else ()
        for prop in props:
            if getattr(prop, "type", "") != "BOOLEAN" or getattr(prop, "is_readonly", False):
                continue
            identifier = str(getattr(prop, "identifier", ""))
            ident_n = _norm(identifier)
            name_n = _norm(getattr(prop, "name", ""))
            desc_n = _norm(getattr(prop, "description", ""))
            score = 0
            if ident_n in exact_ids:
                score = 100
            elif any(token and token == name_n for token in label_tokens):
                score = 95
            elif any(token and token in name_n for token in label_tokens):
                score = 85
            elif any(token and token in desc_n for token in label_tokens):
                score = 70
            elif feature == "cross_edges" and "cross" in ident_n and "edge" in ident_n:
                score = 60
            elif feature == "cross_faces" and "cross" in ident_n and "face" in ident_n:
                score = 60
            elif feature == "proportional_cursor" and "proportional" in ident_n and "cursor" in ident_n:
                score = 60
            elif feature == "instant_drag" and "drag" in ident_n and ("instant" in ident_n or "immediate" in ident_n):
                score = 60
            elif feature == "axis_memory" and "axis" in ident_n and ("memory" in ident_n or "remember" in ident_n):
                score = 60
            elif feature == "gizmo_assist" and "gizmo" in ident_n and ("assist" in ident_n or "grab" in ident_n):
                score = 60
            elif feature == "panel_state_save" and "panel" in ident_n and ("save" in ident_n or "persist" in ident_n or "remember" in ident_n):
                score = 60
            if score > 0 and (best is None or score > best[2]):
                best = (path, identifier, score)
    return best


# Cache only an owner path and property identifier.  A PropertyGroup wrapper can
# outlive its IDProperty storage after undo/load or replacement without its
# scene pointer changing.  Never retain such a wrapper between timer ticks.
_BINDING_CACHE: Dict[str, Tuple[str, str]] = {}
# Settings roots found by the last full walk, made while every add-on was still registered. At exit the walk must not
# run: Blender disables add-ons one by one, and touching a struct whose PropertyGroup class another add-on has already
# unregistered is a native access violation that try/except cannot catch (measured 2026-10-11 with Simply Cloth Studio
# and Smart Tools Manager enabled: every quit crashed in _looks_addon_owned, GUI and background alike).
_PERSIST_ROOT_PATHS: List[str] = []


def _scene_pointer(context: Optional[bpy.types.Context]) -> int:
    try:
        scene = getattr(context or bpy.context, "scene", None)
        return _safe_pointer(scene) if scene is not None else 0
    except Exception:
        return 0


def _invalidate_binding_cache() -> None:
    _BINDING_CACHE.clear()


def _live_binding_owner(context: Optional[bpy.types.Context], path: str) -> Any:
    """Resolve the cached structural path from today's Blender owner."""
    ctx = context or bpy.context
    if path.startswith("preferences:"):
        tail = path[len("preferences:"):]
        addons = getattr(getattr(ctx, "preferences", None), "addons", None)
        if addons is None:
            return None
        root = _package_root()
        for key in dict.fromkeys((root, root.rsplit(".", 1)[-1], "smart_uv_suite")):
            if tail == key or tail.startswith(key + "."):
                entry = addons.get(key)
                owner = getattr(entry, "preferences", None) if entry is not None else None
                suffix = tail[len(key):].lstrip(".")
                break
        else:
            return None
    else:
        anchor, _, suffix = path.partition(".")
        owner = (getattr(getattr(ctx, "scene", None), "tool_settings", None)
                 if anchor == "tool_settings" else getattr(ctx, anchor, None))
    if owner is None:
        return None
    for identifier in suffix.split(".") if suffix else ():
        owner = getattr(owner, identifier, None)
        if owner is None:
            return None
    return owner


def _feature_value(context: Optional[bpy.types.Context], feature: str, default: bool = False,
                   cached_only: bool = False) -> bool:
    """``cached_only``: never walk other add-ons' structs (unregister/exit); an unknown binding gives ``default``."""
    cached = _BINDING_CACHE.get(feature)
    if cached is not None:
        path, identifier = cached
        owner = _live_binding_owner(context, path)
        if owner is not None:
            try:
                return bool(getattr(owner, identifier))
            except Exception:
                pass
        _BINDING_CACHE.pop(feature, None)
    if cached_only:
        return bool(default)
    binding = _feature_binding(context, feature)
    if binding is None:
        return bool(default)
    path, identifier, _score = binding
    owner = _live_binding_owner(context, path)
    if owner is None:
        return bool(default)
    try:
        value = bool(getattr(owner, identifier))
    except Exception:
        return bool(default)
    _BINDING_CACHE[feature] = (path, identifier)
    return value


# -----------------------------------------------------------------------------
# UV editor context resolution
# -----------------------------------------------------------------------------


@dataclass
class UVContext:
    window: Any
    screen: Any
    area: Any
    region: Any
    space: Any

    def override(self) -> Dict[str, Any]:
        return {
            "window": self.window,
            "screen": self.screen,
            "area": self.area,
            "region": self.region,
            "space_data": self.space,
        }


def _active_space(area: Any) -> Any:
    try:
        return area.spaces.active
    except Exception:
        return None


def _space_is_uv(space: Any, context: Optional[bpy.types.Context] = None) -> bool:
    if space is None or getattr(space, "type", "") != "IMAGE_EDITOR":
        return False
    for attr in ("ui_mode", "mode"):
        value = str(getattr(space, attr, "") or "").upper()
        if value == "UV":
            return True
        if value in {"PAINT", "MASK"}:
            return False
    if bool(getattr(space, "show_uvedit", False)):
        return True
    ctx = context or bpy.context
    obj = getattr(ctx, "edit_object", None)
    return bool(obj is not None and getattr(obj, "type", "") == "MESH" and getattr(obj, "mode", "") == "EDIT")


def _window_region(area: Any) -> Any:
    try:
        for region in area.regions:
            if getattr(region, "type", "") == "WINDOW":
                return region
    except Exception:
        pass
    return None


def resolve_uv_context(context: Optional[bpy.types.Context] = None, area_hint: Any = None) -> Optional[UVContext]:
    """Resolve the actual IMAGE_EDITOR/WINDOW region even when called from N-panel UI."""
    ctx = context or bpy.context
    current_window = getattr(ctx, "window", None)
    current_screen = getattr(ctx, "screen", None)
    current_area = area_hint or getattr(ctx, "area", None)

    def make(window: Any, screen: Any, area: Any) -> Optional[UVContext]:
        if area is None or getattr(area, "type", "") != "IMAGE_EDITOR":
            return None
        space = _active_space(area)
        if not _space_is_uv(space, ctx):
            return None
        region = _window_region(area)
        if region is None:
            return None
        return UVContext(window, screen, area, region, space)

    result = make(current_window, current_screen, current_area)
    if result is not None:
        return result
    if current_screen is not None:
        for area in getattr(current_screen, "areas", ()):
            result = make(current_window, current_screen, area)
            if result is not None:
                return result
    wm = getattr(ctx, "window_manager", None) or getattr(bpy.context, "window_manager", None)
    for window in getattr(wm, "windows", ()) if wm is not None else ():
        screen = getattr(window, "screen", None)
        for area in getattr(screen, "areas", ()) if screen is not None else ():
            result = make(window, screen, area)
            if result is not None:
                return result
    return None


def _event_xy(event: Any) -> Tuple[float, float]:
    return float(getattr(event, "mouse_region_x", 0.0)), float(getattr(event, "mouse_region_y", 0.0))


def _ui_scale(context: Optional[bpy.types.Context]) -> float:
    try:
        prefs = (context or bpy.context).preferences.system
        return max(1.0, float(getattr(prefs, "ui_scale", 1.0)) * float(getattr(prefs, "pixel_size", 1.0)))
    except Exception:
        return 1.0


def _view_to_region(uvctx: UVContext, co: Sequence[float]) -> Tuple[float, float]:
    try:
        x, y = uvctx.region.view2d.view_to_region(float(co[0]), float(co[1]), clip=False)
        return float(x), float(y)
    except Exception:
        return 0.0, 0.0


def _region_to_view(uvctx: UVContext, xy: Sequence[float]) -> Vector:
    try:
        x, y = uvctx.region.view2d.region_to_view(float(xy[0]), float(xy[1]))
        return Vector((float(x), float(y)))
    except Exception:
        return Vector((0.0, 0.0))


# -----------------------------------------------------------------------------
# UV data helpers
# -----------------------------------------------------------------------------


@dataclass
class MeshUVData:
    obj: Any
    mesh: Any
    bm: Any
    uv_layer: Any


@dataclass
class UVPrimitive:
    kind: str
    data: MeshUVData
    key: Tuple[Any, ...]
    points: Tuple[Tuple[float, float], ...]
    loops: Tuple[Any, ...]
    face: Any = None
    edge: Any = None
    selected: bool = False


def _edit_mesh_objects(context: Optional[bpy.types.Context]) -> List[Any]:
    ctx = context or bpy.context
    result: List[Any] = []
    seen: Set[int] = set()
    for obj in getattr(ctx, "objects_in_mode_unique_data", ()) or ():
        if obj is not None and getattr(obj, "type", "") == "MESH" and getattr(obj, "mode", "") == "EDIT":
            ptr = _safe_pointer(getattr(obj, "data", obj))
            if ptr not in seen:
                seen.add(ptr)
                result.append(obj)
    obj = getattr(ctx, "edit_object", None)
    if obj is not None and getattr(obj, "type", "") == "MESH" and getattr(obj, "mode", "") == "EDIT":
        ptr = _safe_pointer(getattr(obj, "data", obj))
        if ptr not in seen:
            result.append(obj)
    return result


def _mesh_uv_data(context: Optional[bpy.types.Context]) -> List[MeshUVData]:
    result: List[MeshUVData] = []
    for obj in _edit_mesh_objects(context):
        mesh = obj.data
        try:
            bm = bmesh.from_edit_mesh(mesh)
            bm.faces.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.verts.ensure_lookup_table()
            uv_layer = bm.loops.layers.uv.active
        except Exception:
            continue
        if uv_layer is not None:
            result.append(MeshUVData(obj, mesh, bm, uv_layer))
    return result


def _sync_enabled(context: Optional[bpy.types.Context]) -> bool:
    try:
        return bool((context or bpy.context).scene.tool_settings.use_uv_select_sync)
    except Exception:
        return False


def _uv_select_mode(context: Optional[bpy.types.Context]) -> str:
    try:
        mode = str((context or bpy.context).scene.tool_settings.uv_select_mode)
    except Exception:
        mode = "VERTEX"
    mode = mode.upper()
    return mode if mode in {"VERTEX", "EDGE", "FACE", "ISLAND"} else "VERTEX"


def _loop_uv(loop: Any, uv_layer: Any) -> Vector:
    return Vector((float(loop[uv_layer].uv.x), float(loop[uv_layer].uv.y)))


def _uv_vert_selected(loop: Any, data: MeshUVData) -> bool:
    """Read Blender 5.1 live UV-vertex selection from BMLoop."""
    try:
        return bool(loop.uv_select_vert)
    except Exception:
        pass
    # Compatibility fallback for older Blender versions only.
    try:
        return bool(loop[data.uv_layer].select)
    except Exception:
        return False


def _uv_edge_selected(loop: Any, data: MeshUVData) -> bool:
    try:
        return bool(loop.uv_select_edge)
    except Exception:
        pass
    try:
        luv = loop[data.uv_layer]
        edge_value = getattr(luv, "select_edge", None)
        if edge_value is not None:
            return bool(edge_value)
    except Exception:
        pass
    return _uv_vert_selected(loop, data) and _uv_vert_selected(loop.link_loop_next, data)


def _uv_face_selected(face: Any, data: MeshUVData) -> bool:
    try:
        return bool(face.uv_select)
    except Exception:
        pass
    try:
        return all(_uv_vert_selected(loop, data) for loop in face.loops)
    except Exception:
        return False


def _assign_uv_vert(loop: Any, data: MeshUVData, selected: bool) -> bool:
    value = bool(selected)
    try:
        loop.uv_select_vert = value
        return True
    except Exception:
        pass
    try:
        loop[data.uv_layer].select = value
        return True
    except Exception:
        return False


def _assign_uv_edge(loop: Any, data: MeshUVData, selected: bool) -> bool:
    value = bool(selected)
    try:
        loop.uv_select_edge = value
        return True
    except Exception:
        pass
    try:
        loop[data.uv_layer].select_edge = value
        return True
    except Exception:
        return False


def _assign_uv_face(face: Any, data: MeshUVData, selected: bool) -> bool:
    value = bool(selected)
    try:
        face.uv_select = value
        return True
    except Exception:
        pass
    changed = False
    for loop in getattr(face, "loops", ()):
        changed = _assign_uv_vert(loop, data, value) or changed
        changed = _assign_uv_edge(loop, data, value) or changed
    return changed


def _uv_vertex_group_loops(data: MeshUVData, loop: Any) -> Iterator[Any]:
    """Yield loops representing the same UV vertex without crossing a seam."""
    target = _rounded_uv(_loop_uv(loop, data.uv_layer))
    for linked in loop.vert.link_loops:
        try:
            if _rounded_uv(_loop_uv(linked, data.uv_layer)) == target:
                yield linked
        except Exception:
            continue


def _set_uv_vertex_group(data: MeshUVData, loop: Any, selected: bool) -> None:
    for linked in _uv_vertex_group_loops(data, loop):
        _assign_uv_vert(linked, data, selected)


def _normalize_uv_selection(data: MeshUVData, mode: str) -> None:
    """Keep Blender 5.1 UV vertex/edge/face flags internally consistent."""
    mode = str(mode or "VERTEX").upper()
    faces = tuple(data.bm.faces)
    if mode == "VERTEX":
        for face in faces:
            _assign_uv_face(face, data, False)
            for loop in face.loops:
                _assign_uv_edge(loop, data, False)
        return

    if mode == "EDGE":
        selected_edges = [
            loop
            for face in faces
            for loop in face.loops
            if _uv_edge_selected(loop, data)
        ]
        for face in faces:
            _assign_uv_face(face, data, False)
            for loop in face.loops:
                _assign_uv_vert(loop, data, False)
        for loop in selected_edges:
            _set_uv_vertex_group(data, loop, True)
            _set_uv_vertex_group(data, loop.link_loop_next, True)
        return

    selected_faces = [face for face in faces if _uv_face_selected(face, data)]
    for face in faces:
        for loop in face.loops:
            _assign_uv_vert(loop, data, False)
            _assign_uv_edge(loop, data, False)
    for face in selected_faces:
        _assign_uv_face(face, data, True)
        for loop in face.loops:
            _assign_uv_edge(loop, data, True)
            _set_uv_vertex_group(data, loop, True)


def _visible_faces(data: MeshUVData, sync: bool) -> Iterator[Any]:
    for face in data.bm.faces:
        if face.hide:
            continue
        # With UV sync disabled, Blender normally exposes UVs of selected mesh
        # faces. Keep that rule, but tolerate an existing live UV selection.
        if not sync and not face.select:
            if not (
                _uv_face_selected(face, data)
                or any(
                    _uv_vert_selected(loop, data) or _uv_edge_selected(loop, data)
                    for loop in face.loops
                )
            ):
                continue
        yield face


def _loop_selected(loop: Any, data: MeshUVData, mode: str, sync: bool) -> bool:
    if sync:
        if mode == "VERTEX":
            return bool(loop.vert.select)
        if mode == "EDGE":
            return bool(loop.edge.select)
        if mode in {"FACE", "ISLAND"}:
            return bool(loop.face.select)
    if mode == "EDGE":
        return _uv_edge_selected(loop, data)
    if mode in {"FACE", "ISLAND"}:
        return _uv_face_selected(loop.face, data)
    return _uv_vert_selected(loop, data)


def _face_selected(face: Any, data: MeshUVData, sync: bool) -> bool:
    if sync:
        return bool(face.select)
    return _uv_face_selected(face, data)


def _edge_selected(loop: Any, data: MeshUVData, sync: bool) -> bool:
    if sync:
        return bool(loop.edge.select)
    return _uv_edge_selected(loop, data)


def _rounded_uv(co: Sequence[float]) -> Tuple[int, int]:
    return int(round(float(co[0]) * 10000000.0)), int(round(float(co[1]) * 10000000.0))


def _edge_group_key(data: MeshUVData, loop: Any, sync: bool) -> Tuple[Any, ...]:
    obj_key = _safe_pointer(data.mesh)
    if sync:
        return (obj_key, int(loop.edge.index))
    a = _rounded_uv(_loop_uv(loop, data.uv_layer))
    b = _rounded_uv(_loop_uv(loop.link_loop_next, data.uv_layer))
    if b < a:
        a, b = b, a
    return (obj_key, int(loop.edge.index), a, b)


def _build_primitives(context: Optional[bpy.types.Context], uvctx: UVContext, kinds: Set[str]) -> List[UVPrimitive]:
    sync = _sync_enabled(context)
    result: List[UVPrimitive] = []
    edge_groups: Dict[Tuple[Any, ...], List[Tuple[MeshUVData, Any, Tuple[float, float], Tuple[float, float]]]] = {}
    for data in _mesh_uv_data(context):
        for face in _visible_faces(data, sync):
            loops = tuple(face.loops)
            if "FACE" in kinds or "ISLAND" in kinds:
                points = tuple(_view_to_region(uvctx, _loop_uv(loop, data.uv_layer)) for loop in loops)
                result.append(UVPrimitive(
                    "FACE", data, (_safe_pointer(data.mesh), int(face.index)), points, loops,
                    face=face, selected=_face_selected(face, data, sync),
                ))
            if "VERTEX" in kinds:
                for loop in loops:
                    point = _view_to_region(uvctx, _loop_uv(loop, data.uv_layer))
                    key = (_safe_pointer(data.mesh), int(loop.vert.index), _rounded_uv(_loop_uv(loop, data.uv_layer)))
                    result.append(UVPrimitive(
                        "VERTEX", data, key, (point,), (loop,), face=face,
                        selected=_loop_selected(loop, data, "VERTEX", sync),
                    ))
            if "EDGE" in kinds:
                for loop in loops:
                    a = _view_to_region(uvctx, _loop_uv(loop, data.uv_layer))
                    b = _view_to_region(uvctx, _loop_uv(loop.link_loop_next, data.uv_layer))
                    key = _edge_group_key(data, loop, sync)
                    edge_groups.setdefault(key, []).append((data, loop, a, b))
    if "EDGE" in kinds:
        for key, members in edge_groups.items():
            data = members[0][0]
            loops = tuple(item[1] for item in members)
            points = (members[0][2], members[0][3])
            selected = any(_edge_selected(item[1], item[0], sync) for item in members)
            result.append(UVPrimitive("EDGE", data, key, points, loops, edge=members[0][1].edge, selected=selected))
    return result


def _distance_sq(a: Sequence[float], b: Sequence[float]) -> float:
    dx = float(a[0]) - float(b[0])
    dy = float(a[1]) - float(b[1])
    return dx * dx + dy * dy


def _point_segment_distance_sq(p: Sequence[float], a: Sequence[float], b: Sequence[float]) -> float:
    ax, ay = float(a[0]), float(a[1])
    bx, by = float(b[0]), float(b[1])
    px, py = float(p[0]), float(p[1])
    dx, dy = bx - ax, by - ay
    denom = dx * dx + dy * dy
    if denom <= _EPS:
        return _distance_sq(p, a)
    t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / denom))
    return (px - (ax + t * dx)) ** 2 + (py - (ay + t * dy)) ** 2


def _point_in_polygon(point: Sequence[float], polygon: Sequence[Sequence[float]]) -> bool:
    x, y = float(point[0]), float(point[1])
    inside = False
    if len(polygon) < 3:
        return False
    j = len(polygon) - 1
    for i in range(len(polygon)):
        xi, yi = float(polygon[i][0]), float(polygon[i][1])
        xj, yj = float(polygon[j][0]), float(polygon[j][1])
        if _point_segment_distance_sq((x, y), (xi, yi), (xj, yj)) <= 0.25:
            return True
        if ((yi > y) != (yj > y)):
            x_cross = (xj - xi) * (y - yi) / ((yj - yi) or _EPS) + xi
            if x < x_cross:
                inside = not inside
        j = i
    return inside


def _orientation(a: Sequence[float], b: Sequence[float], c: Sequence[float]) -> float:
    return (float(b[0]) - float(a[0])) * (float(c[1]) - float(a[1])) - (float(b[1]) - float(a[1])) * (float(c[0]) - float(a[0]))


def _segments_intersect(a: Sequence[float], b: Sequence[float], c: Sequence[float], d: Sequence[float]) -> bool:
    o1, o2 = _orientation(a, b, c), _orientation(a, b, d)
    o3, o4 = _orientation(c, d, a), _orientation(c, d, b)
    if ((o1 > _EPS and o2 < -_EPS) or (o1 < -_EPS and o2 > _EPS)) and ((o3 > _EPS and o4 < -_EPS) or (o3 < -_EPS and o4 > _EPS)):
        return True
    if abs(o1) <= _EPS and _point_segment_distance_sq(c, a, b) <= 0.25:
        return True
    if abs(o2) <= _EPS and _point_segment_distance_sq(d, a, b) <= 0.25:
        return True
    if abs(o3) <= _EPS and _point_segment_distance_sq(a, c, d) <= 0.25:
        return True
    if abs(o4) <= _EPS and _point_segment_distance_sq(b, c, d) <= 0.25:
        return True
    return False


def _polygon_edges(poly: Sequence[Sequence[float]]) -> Iterator[Tuple[Sequence[float], Sequence[float]]]:
    if len(poly) < 2:
        return
    for index, point in enumerate(poly):
        yield point, poly[(index + 1) % len(poly)]


def _find_hit(context: Optional[bpy.types.Context], uvctx: UVContext, mouse: Sequence[float]) -> Optional[UVPrimitive]:
    mode = _uv_select_mode(context)
    scale = _ui_scale(context)
    if mode == "VERTEX":
        candidates = _build_primitives(context, uvctx, {"VERTEX"})
        limit = (10.0 * scale) ** 2
        candidates.sort(key=lambda item: _distance_sq(mouse, item.points[0]))
        return candidates[0] if candidates and _distance_sq(mouse, candidates[0].points[0]) <= limit else None
    if mode == "EDGE":
        candidates = _build_primitives(context, uvctx, {"EDGE"})
        limit = (8.0 * scale) ** 2
        candidates.sort(key=lambda item: _point_segment_distance_sq(mouse, item.points[0], item.points[1]))
        return candidates[0] if candidates and _point_segment_distance_sq(mouse, candidates[0].points[0], candidates[0].points[1]) <= limit else None
    faces = _build_primitives(context, uvctx, {"FACE"})
    containing = [item for item in faces if _point_in_polygon(mouse, item.points)]
    if containing:
        containing.sort(key=lambda item: abs(sum(
            item.points[i][0] * item.points[(i + 1) % len(item.points)][1] - item.points[(i + 1) % len(item.points)][0] * item.points[i][1]
            for i in range(len(item.points))
        )))
        return containing[0]
    return None


def _selection_snapshot(context: Optional[bpy.types.Context]) -> List[Dict[str, Any]]:
    snapshot: List[Dict[str, Any]] = []
    for data in _mesh_uv_data(context):
        snapshot.append({
            "data": data,
            "verts": [bool(v.select) for v in data.bm.verts],
            "edges": [bool(e.select) for e in data.bm.edges],
            "faces": [bool(f.select) for f in data.bm.faces],
            "uv_faces": [_uv_face_selected(face, data) for face in data.bm.faces],
            "uv": [
                (_uv_vert_selected(loop, data), _uv_edge_selected(loop, data))
                for face in data.bm.faces for loop in face.loops
            ],
        })
    return snapshot


def _restore_selection(snapshot: Sequence[Dict[str, Any]]) -> None:
    for item in snapshot:
        data: MeshUVData = item["data"]
        try:
            for vert, selected in zip(data.bm.verts, item["verts"]):
                vert.select = bool(selected)
            for edge, selected in zip(data.bm.edges, item["edges"]):
                edge.select = bool(selected)
            for face, selected in zip(data.bm.faces, item["faces"]):
                face.select = bool(selected)

            # Restore the three UV selection domains exactly.  Direct BMLoop /
            # BMFace assignments are intentional here: setter methods propagate
            # to neighbouring domains and would corrupt a precise snapshot.
            for face in data.bm.faces:
                _assign_uv_face(face, data, False)
                for loop in face.loops:
                    _assign_uv_vert(loop, data, False)
                    _assign_uv_edge(loop, data, False)
            index = 0
            for face in data.bm.faces:
                for loop in face.loops:
                    selected, edge_selected = item["uv"][index]
                    _assign_uv_vert(loop, data, selected)
                    _assign_uv_edge(loop, data, edge_selected)
                    index += 1
            for face, selected in zip(data.bm.faces, item.get("uv_faces", ())):
                _assign_uv_face(face, data, selected)
            bmesh.update_edit_mesh(data.mesh, loop_triangles=False, destructive=False)
        except Exception:
            continue


def _clear_selection(context: Optional[bpy.types.Context], mode: str) -> None:
    sync = _sync_enabled(context)
    for data in _mesh_uv_data(context):
        if sync:
            if mode == "VERTEX":
                for vert in data.bm.verts:
                    vert.select = False
            elif mode == "EDGE":
                for edge in data.bm.edges:
                    edge.select = False
            else:
                for face in data.bm.faces:
                    face.select = False
        else:
            for face in data.bm.faces:
                _assign_uv_face(face, data, False)
                for loop in face.loops:
                    _assign_uv_vert(loop, data, False)
                    _assign_uv_edge(loop, data, False)
        bmesh.update_edit_mesh(data.mesh, loop_triangles=False, destructive=False)


def _uv_face_neighbors(data: MeshUVData, face: Any) -> Iterator[Any]:
    uv = data.uv_layer
    for loop in face.loops:
        edge = loop.edge
        a = _rounded_uv(_loop_uv(loop, uv))
        b = _rounded_uv(_loop_uv(loop.link_loop_next, uv))
        for radial in edge.link_loops:
            other = radial.face
            if other == face or other.hide:
                continue
            oa = _rounded_uv(_loop_uv(radial, uv))
            ob = _rounded_uv(_loop_uv(radial.link_loop_next, uv))
            if (a == ob and b == oa) or (a == oa and b == ob):
                yield other


def _select_primitive(context: Optional[bpy.types.Context], primitive: UVPrimitive, selected: bool = True) -> None:
    mode = _uv_select_mode(context)
    sync = _sync_enabled(context)
    data = primitive.data
    if mode == "VERTEX":
        loop = primitive.loops[0]
        if sync:
            loop.vert.select = bool(selected)
        else:
            _set_uv_vertex_group(data, loop, selected)
            _normalize_uv_selection(data, mode)
    elif mode == "EDGE":
        for loop in primitive.loops:
            if sync:
                loop.edge.select = bool(selected)
            else:
                _assign_uv_edge(loop, data, selected)
        if not sync:
            _normalize_uv_selection(data, mode)
    elif mode == "FACE":
        face = primitive.face
        if sync:
            face.select = bool(selected)
        else:
            _assign_uv_face(face, data, selected)
            _normalize_uv_selection(data, mode)
    else:  # ISLAND
        start = primitive.face
        queue = [start]
        seen: Set[int] = set()
        while queue:
            face = queue.pop()
            if int(face.index) in seen:
                continue
            seen.add(int(face.index))
            if sync:
                face.select = bool(selected)
            else:
                _assign_uv_face(face, data, selected)
            queue.extend(_uv_face_neighbors(data, face))
        if not sync:
            _normalize_uv_selection(data, mode)
    bmesh.update_edit_mesh(data.mesh, loop_triangles=False, destructive=False)


def _selected_uv_baseline(context: Optional[bpy.types.Context]) -> List[Tuple[MeshUVData, Any, Vector]]:
    mode = _uv_select_mode(context)
    sync = _sync_enabled(context)
    result: List[Tuple[MeshUVData, Any, Vector]] = []
    for data in _mesh_uv_data(context):
        for face in _visible_faces(data, sync):
            for loop in face.loops:
                if _loop_selected(loop, data, mode, sync):
                    result.append((data, loop, _loop_uv(loop, data.uv_layer)))
    return result


def _update_meshes(entries: Sequence[Tuple[MeshUVData, Any, Vector]]) -> None:
    seen: Set[int] = set()
    for data, _loop, _co in entries:
        ptr = _safe_pointer(data.mesh)
        if ptr in seen:
            continue
        seen.add(ptr)
        try:
            bmesh.update_edit_mesh(data.mesh, loop_triangles=False, destructive=False)
        except Exception:
            pass


# -----------------------------------------------------------------------------
# Axis memory and transform helpers
# -----------------------------------------------------------------------------


_AXIS_BY_WINDOW: Dict[int, str] = {}
_LAST_OPERATOR_TOKEN: Dict[int, Tuple[str, Tuple[bool, bool, bool], int]] = {}


def _window_key(context: Optional[bpy.types.Context]) -> int:
    window = getattr(context or bpy.context, "window", None)
    return _safe_pointer(window) if window is not None else 0


def _normalize_axis(axis: Any) -> str:
    axis = str(axis or "NONE").upper()
    if axis == "FREE":
        axis = "NONE"
    return axis if axis in {"X", "Y", "NONE"} else "NONE"


def _legacy_axis_value(axis: str) -> str:
    return {"X": "U", "Y": "V", "NONE": "FREE"}[_normalize_axis(axis)]


def _sync_legacy_axis(context: Optional[bpy.types.Context], axis: str) -> None:
    """Keep the retained product axis cache consistent with this runtime.

    Smart UV still exposes the original Immediate Select operator through its
    owned tool keymaps when the feature is enabled.  That operator reads the
    package-level U/V/FREE cache, while the generic Image keymap reads this
    module's X/Y/NONE cache.  A free gizmo gesture must update both authorities
    or the next Immediate Select drag can reuse a stale U or V constraint.
    """
    try:
        package = sys.modules.get(_package_root())
        setter = getattr(package, "_sus_1636_set_axis", None) if package is not None else None
        if callable(setter):
            setter(_legacy_axis_value(axis), context or bpy.context)
    except Exception:
        pass


def _get_axis(context: Optional[bpy.types.Context]) -> str:
    key = _window_key(context)
    if key in _AXIS_BY_WINDOW:
        return _normalize_axis(_AXIS_BY_WINDOW[key])
    # Before the generic Image keymap has committed its first gesture, inherit
    # the retained product cache so both active Immediate Select routes agree.
    try:
        package = sys.modules.get(_package_root())
        getter = getattr(package, "_sus_1636_get_axis", None) if package is not None else None
        if callable(getter):
            legacy = str(getter(context or bpy.context) or "FREE").upper()
            return {"U": "X", "V": "Y", "FREE": "NONE"}.get(legacy, "NONE")
    except Exception:
        pass
    return "NONE"


def _set_axis(context: Optional[bpy.types.Context], axis: str) -> None:
    axis = _normalize_axis(axis)
    _AXIS_BY_WINDOW[_window_key(context)] = axis
    _sync_legacy_axis(context, axis)


def _constraint_tuple(axis: str) -> Tuple[bool, bool, bool]:
    return (axis == "X", axis == "Y", False)


def _axis_from_constraint(value: Any) -> str:
    try:
        values = tuple(bool(item) for item in value)
    except Exception:
        return "NONE"
    if len(values) >= 2:
        if values[0] and not values[1]:
            return "X"
        if values[1] and not values[0]:
            return "Y"
    # An unconstrained UV transform is the explicit free-axis state.
    return "NONE"


def _latest_transform_token() -> Optional[Tuple[str, Tuple[bool, bool, bool], int]]:
    try:
        wm = bpy.context.window_manager
        operators = list(getattr(wm, "operators", ()) or ()) if wm is not None else []
        if not operators:
            return None
        # Any later REGISTER-flagged operator hides a transform sitting at
        # operators[-1]; scan the recent history window for the newest
        # native transform instead of trusting only the last entry.
        for operator in reversed(operators[-12:]):
            idname = str(getattr(operator, "bl_idname", ""))
            if idname not in {"TRANSFORM_OT_translate", "TRANSFORM_OT_resize"}:
                continue
            properties = getattr(operator, "properties", None)
            raw = getattr(properties, "constraint_axis", (False, False, False)) if properties else (False, False, False)
            constraint = tuple(bool(v) for v in tuple(raw)[:3])
            while len(constraint) < 3:
                constraint += (False,)
            return (idname, constraint, _safe_pointer(operator))
        return None
    except Exception:
        return None


def _consume_latest_transform_token(context: Optional[bpy.types.Context]) -> None:
    token = _latest_transform_token()
    if token is not None:
        _LAST_OPERATOR_TOKEN[_window_key(context)] = token


def _axis_history_timer() -> Optional[float]:
    # Runs only while "Remember Axis Constraint" is ON; it stops itself as soon as the switch is OFF
    # and note_panel_draw() / the switch's update callback start it again.
    try:
        if not _feature_value(bpy.context, "axis_memory", False):
            return None
        wm = bpy.context.window_manager
        if wm is None:
            return 0.25
        token = _latest_transform_token()
        if token is None:
            return 0.25
        _idname, constraint, _operator_ptr = token
        for window in wm.windows:
            key = _safe_pointer(window)
            if _LAST_OPERATOR_TOKEN.get(key) == token:
                continue
            _LAST_OPERATOR_TOKEN[key] = token
            # FREE/NONE is a first-class remembered state.  Ignoring it leaves
            # the previous U/V constraint active after a free gizmo drag.
            if _feature_value(bpy.context, "axis_memory", False):
                axis = _axis_from_constraint(constraint)
                _AXIS_BY_WINDOW[key] = axis
                if key == _window_key(bpy.context):
                    _sync_legacy_axis(bpy.context, axis)
    except Exception:
        pass
    return 0.25


def _selected_pivot_uv(context: Optional[bpy.types.Context], uvctx: UVContext) -> Optional[Vector]:
    entries = _selected_uv_baseline(context)
    if not entries:
        return None
    points = [co for _data, _loop, co in entries]
    pivot_mode = str(getattr(uvctx.space, "pivot_point", "MEDIAN_POINT") or "MEDIAN_POINT")
    if pivot_mode == "CURSOR":
        try:
            return Vector(uvctx.space.cursor_location)
        except Exception:
            pass
    if pivot_mode == "BOUNDING_BOX_CENTER":
        min_x = min(point.x for point in points)
        max_x = max(point.x for point in points)
        min_y = min(point.y for point in points)
        max_y = max(point.y for point in points)
        return Vector(((min_x + max_x) * 0.5, (min_y + max_y) * 0.5))
    return sum(points, Vector((0.0, 0.0))) / float(len(points))


def _active_tool_id(context: Optional[bpy.types.Context], uvctx: UVContext) -> str:
    workspace = getattr(context or bpy.context, "workspace", None)
    tools = getattr(workspace, "tools", None)
    if tools is None:
        return ""
    mode = str(getattr(uvctx.space, "ui_mode", "UV") or "UV")
    tool_modes = tuple(dict.fromkeys((mode, "UV")))
    for tool_mode in tool_modes:
        try:
            tool = tools.from_space_image_mode(tool_mode, create=False)
            if tool is not None:
                return str(getattr(tool, "idname", "") or "")
        except Exception:
            continue
    return ""


def _gizmo_assist_hit(context: Optional[bpy.types.Context], uvctx: UVContext, mouse: Sequence[float]) -> Optional[Tuple[str, str, Vector]]:
    if not _feature_value(context, "gizmo_assist", False):
        return None
    if not bool(getattr(uvctx.space, "show_gizmo", True)):
        return None
    tool_id = _active_tool_id(context, uvctx).casefold()
    if not any(token in tool_id for token in ("move", "scale", "rotate", "transform")):
        return None
    pivot_uv = _selected_pivot_uv(context, uvctx)
    if pivot_uv is None:
        return None
    pivot_px = _view_to_region(uvctx, pivot_uv)
    scale = _ui_scale(context)
    dx = float(mouse[0]) - pivot_px[0]
    dy = float(mouse[1]) - pivot_px[1]
    center_radius = 13.0 * scale
    axis_half = 8.0 * scale
    axis_start = 12.0 * scale
    axis_end = 58.0 * scale
    ring_radius = 46.0 * scale
    ring_width = 9.0 * scale

    operation = "TRANSLATE"
    if "scale" in tool_id:
        operation = "SCALE"
    elif "rotate" in tool_id:
        operation = "ROTATE"

    if dx * dx + dy * dy <= center_radius * center_radius:
        return operation, "NONE", pivot_uv
    if axis_start <= dx <= axis_end and abs(dy) <= axis_half:
        return operation if operation != "ROTATE" else "TRANSLATE", "X", pivot_uv
    if axis_start <= dy <= axis_end and abs(dx) <= axis_half:
        return operation if operation != "ROTATE" else "TRANSLATE", "Y", pivot_uv
    distance = math.hypot(dx, dy)
    if ("rotate" in tool_id or "transform" in tool_id) and abs(distance - ring_radius) <= ring_width:
        return "ROTATE", "NONE", pivot_uv
    return None


# -----------------------------------------------------------------------------
# 1.8.230: _warp_cursor_for_proportional was removed with the UV Smart G-R-S
# feature (its only caller).  The UV Proportional Cursor Entry feature is the
# owned PAGE_UP/PAGE_DOWN image.smart_uv_proportional_size_cursor rows plus the
# N-panel manual-registration reference.
# 1.8.229 consolidation: the parallel SMARTUV_OT_interaction_drag_18228 and
# SMARTUV_OT_smart_transform_18228 operators were removed.  The manifest-owned
# Immediate Select layer (uv_immediate_drag_stability_18112) and the
# SmartUV-owned UV Editor keymap surface (smartuv_uv_ownership_18224) are the
# single owners of those events; this module keeps only feature discovery,
# axis-constraint memory storage and N-panel state persistence.
# -----------------------------------------------------------------------------


# -----------------------------------------------------------------------------
# Crossing selection geometry and operators
# -----------------------------------------------------------------------------


def _rect_polygon(a: Sequence[float], b: Sequence[float]) -> Tuple[Tuple[float, float], ...]:
    min_x, max_x = sorted((float(a[0]), float(b[0])))
    min_y, max_y = sorted((float(a[1]), float(b[1])))
    return ((min_x, min_y), (max_x, min_y), (max_x, max_y), (min_x, max_y))


def _point_in_circle(point: Sequence[float], center: Sequence[float], radius: float) -> bool:
    return _distance_sq(point, center) <= radius * radius + _EPS


def _primitive_hits_polygon(primitive: UVPrimitive, selection: Sequence[Sequence[float]], crossing: bool) -> bool:
    points = primitive.points
    if primitive.kind == "EDGE":
        if not crossing:
            return all(_point_in_polygon(point, selection) for point in points)
        if any(_point_in_polygon(point, selection) for point in points):
            return True
        return any(_segments_intersect(points[0], points[1], a, b) for a, b in _polygon_edges(selection))
    # FACE
    if not crossing:
        return all(_point_in_polygon(point, selection) for point in points)
    if any(_point_in_polygon(point, selection) for point in points):
        return True
    if any(_point_in_polygon(point, points) for point in selection):
        return True
    return any(_segments_intersect(a, b, c, d) for a, b in _polygon_edges(points) for c, d in _polygon_edges(selection))


def _primitive_hits_circle(primitive: UVPrimitive, center: Sequence[float], radius: float, crossing: bool) -> bool:
    points = primitive.points
    if primitive.kind == "EDGE":
        if not crossing:
            return all(_point_in_circle(point, center, radius) for point in points)
        return _point_segment_distance_sq(center, points[0], points[1]) <= radius * radius + _EPS
    if not crossing:
        return all(_point_in_circle(point, center, radius) for point in points)
    if any(_point_in_circle(point, center, radius) for point in points):
        return True
    if _point_in_polygon(center, points):
        return True
    return any(_point_segment_distance_sq(center, a, b) <= radius * radius + _EPS for a, b in _polygon_edges(points))


def _selection_operation(event: Any, default: str = "SET") -> str:
    shift = bool(getattr(event, "shift", False))
    ctrl = bool(getattr(event, "ctrl", False))
    if shift and ctrl:
        return "XOR"
    if shift:
        return "ADD"
    if ctrl:
        return "SUB"
    return default


def _crossing_enabled_for_mode(context: Optional[bpy.types.Context]) -> bool:
    mode = _uv_select_mode(context)
    if mode == "EDGE":
        return _feature_value(context, "cross_edges", False)
    if mode == "FACE":
        return _feature_value(context, "cross_faces", False)
    return False


def _crossing_primitives(context: Optional[bpy.types.Context], uvctx: UVContext) -> List[UVPrimitive]:
    mode = _uv_select_mode(context)
    if mode == "EDGE":
        return _build_primitives(context, uvctx, {"EDGE"})
    if mode == "FACE":
        return _build_primitives(context, uvctx, {"FACE"})
    return []


def _apply_cross_selection(context: bpy.types.Context, primitives: Sequence[UVPrimitive], hit_keys: Set[Tuple[Any, ...]], operation: str) -> None:
    sync = _sync_enabled(context)
    mode = _uv_select_mode(context)
    if operation == "SET":
        _clear_selection(context, mode)

    changed_data: Dict[int, MeshUVData] = {}
    for primitive in primitives:
        hit = primitive.key in hit_keys
        current = primitive.selected if operation != "SET" else False
        if operation in {"SET", "ADD"}:
            target = current or hit
        elif operation == "SUB":
            target = current and not hit
        else:
            target = (not current) if hit else current
        if target == current and operation != "SET":
            continue
        if mode == "EDGE":
            for loop in primitive.loops:
                if sync:
                    loop.edge.select = bool(target)
                else:
                    _assign_uv_edge(loop, primitive.data, target)
        else:
            face = primitive.face
            if sync:
                face.select = bool(target)
            else:
                _assign_uv_face(face, primitive.data, target)
        changed_data[_safe_pointer(primitive.data.mesh)] = primitive.data

    for data in changed_data.values():
        if not sync:
            _normalize_uv_selection(data, mode)
        bmesh.update_edit_mesh(data.mesh, loop_triangles=False, destructive=False)


def _draw_polyline(points: Sequence[Sequence[float]], closed: bool = False) -> None:
    if gpu is None or batch_for_shader is None or len(points) < 2:
        return
    coords = [(float(p[0]), float(p[1])) for p in points]
    if closed:
        coords.append(coords[0])
    try:
        shader = gpu.shader.from_builtin("UNIFORM_COLOR")
        batch = batch_for_shader(shader, "LINE_STRIP", {"pos": coords})
        gpu.state.blend_set("ALPHA")
        shader.bind()
        shader.uniform_float("color", (1.0, 1.0, 1.0, 0.85))
        batch.draw(shader)
        gpu.state.blend_set("NONE")
    except Exception:
        pass


# 1.8.229 consolidation: SMARTUV_OT_crossing_box/lasso/circle_18228 were
# removed.  They duplicated the verified exact crossing engine in
# smartuv_uv_crossing_18360 with contradicting semantics (crossing only on a
# right-to-left box drag).  smart_uv_suite.uv_crossing_gesture is the single
# crossing-selection implementation.


# -----------------------------------------------------------------------------
# Generic all-setting persistence controlled by N-panel state save
# -----------------------------------------------------------------------------


_STATE_SCHEMA = 2
_STATE_FILENAME = "n_panel_all_settings_v2.json"
_PERSIST_RESTORE_PENDING = True
_PERSIST_RESTORED = False
_PERSIST_LAST_JSON = ""
_PERSIST_LAST_ENABLED: Optional[bool] = None
_PERSIST_BUSY = False


def _state_path() -> Path:
    try:
        base = bpy.utils.user_resource("CONFIG", path="smart_uv_suite", create=False)
    except Exception:
        base = ""
    if not base:
        base = os.path.join(os.path.expanduser("~"), ".config", "smart_uv_suite")
    return Path(base) / _STATE_FILENAME


def _simple_property_value(struct: Any, prop: Any) -> Tuple[bool, Any]:
    identifier = str(getattr(prop, "identifier", ""))
    ptype = str(getattr(prop, "type", ""))
    if not identifier or identifier == "rna_type" or getattr(prop, "is_readonly", False):
        return False, None
    try:
        value = getattr(struct, identifier)
    except Exception:
        return False, None
    if getattr(prop, "is_array", False):
        try:
            return True, list(value)
        except Exception:
            return False, None
    if ptype in {"BOOLEAN", "INT", "FLOAT", "STRING"}:
        return True, value
    if ptype == "ENUM":
        if isinstance(value, set):
            return True, sorted(value)
        return True, value
    return False, None


def _serialize_group(struct: Any, depth: int = 0, seen: Optional[Set[int]] = None) -> Dict[str, Any]:
    if seen is None:
        seen = set()
    if depth > 5:
        return {}
    ptr = _safe_pointer(struct)
    if ptr in seen:
        return {}
    seen.add(ptr)
    result: Dict[str, Any] = {}
    rna = getattr(struct, "bl_rna", None)
    for prop in getattr(rna, "properties", ()) if rna is not None else ():
        identifier = str(getattr(prop, "identifier", ""))
        if not identifier or identifier == "rna_type" or getattr(prop, "is_readonly", False):
            continue
        ptype = str(getattr(prop, "type", ""))
        ok, value = _simple_property_value(struct, prop)
        if ok:
            result[identifier] = {"kind": "VALUE", "value": value}
            continue
        if ptype == "POINTER":
            try:
                child = getattr(struct, identifier)
            except Exception:
                child = None
            if child is not None and _is_property_group(child) and _looks_addon_owned(identifier, child):
                child_data = _serialize_group(child, depth + 1, seen)
                if child_data:
                    result[identifier] = {"kind": "GROUP", "value": child_data}
        elif ptype == "COLLECTION":
            try:
                collection = getattr(struct, identifier)
            except Exception:
                collection = None
            if collection is None or len(collection) > 2048:
                continue
            items = []
            for item in collection:
                if _is_property_group(item):
                    items.append(_serialize_group(item, depth + 1, seen.copy()))
            if items:
                result[identifier] = {"kind": "COLLECTION", "value": items}
    seen.discard(ptr)
    return result


def _persistence_roots(context: Optional[bpy.types.Context], cached_only: bool = False) -> Dict[str, Any]:
    result: Dict[str, Any] = {}
    if cached_only:  # unregister/exit: only the roots found while every add-on was alive, reached by their own path
        for path in list(_PERSIST_ROOT_PATHS):
            struct = _live_binding_owner(context, path)
            if struct is None:
                continue
            data = _serialize_group(struct)
            if data:
                result[path] = data
        return result
    paths: List[str] = []
    for path, struct in _iter_addon_structs(context, max_depth=2):
        paths.append(path)
        # Root paths are deterministic enough for WindowManager/preferences.
        # Store every discovered root; nested duplicates are harmless and make
        # restoration resilient to registration-order changes.
        data = _serialize_group(struct)
        if data:
            result[path] = data
    _PERSIST_ROOT_PATHS[:] = paths
    return result


def _set_simple_value(struct: Any, identifier: str, value: Any) -> bool:
    try:
        current = getattr(struct, identifier)
        if isinstance(current, set):
            value = set(value or ())
        setattr(struct, identifier, value)
        return True
    except Exception:
        return False


def _restore_group(struct: Any, data: Dict[str, Any], depth: int = 0) -> int:
    if depth > 5:
        return 0
    restored = 0
    for identifier, payload in data.items():
        if not isinstance(payload, dict):
            continue
        kind = payload.get("kind")
        value = payload.get("value")
        if kind == "VALUE":
            restored += int(_set_simple_value(struct, identifier, value))
        elif kind == "GROUP":
            try:
                child = getattr(struct, identifier)
            except Exception:
                child = None
            if child is not None and isinstance(value, dict):
                restored += _restore_group(child, value, depth + 1)
        elif kind == "COLLECTION":
            try:
                collection = getattr(struct, identifier)
            except Exception:
                collection = None
            if collection is None or not isinstance(value, list):
                continue
            try:
                collection.clear()
                for item_data in value:
                    item = collection.add()
                    if isinstance(item_data, dict):
                        restored += _restore_group(item, item_data, depth + 1)
            except Exception:
                continue
    return restored


def _find_struct_by_path(context: Optional[bpy.types.Context], target_path: str) -> Any:
    for path, struct in _iter_addon_structs(context, max_depth=3):
        if path == target_path:
            return struct
    # Fallback by final property-group RNA identifier when workspace/scene names
    # changed between files.
    target_leaf = target_path.rsplit(".", 1)[-1]
    for path, struct in _iter_addon_structs(context, max_depth=3):
        if path.rsplit(".", 1)[-1] == target_leaf:
            return struct
    return None


_STORE_NAME = "all_settings_v2"


def _read_state_file() -> Optional[Dict[str, Any]]:
    # The state lives in Smart_UV_Suite.json (store "all_settings_v2").  The old separate file is only
    # read once, to carry its content over, and is never written again.
    from . import npanel_persistence as _store
    data = _store.get_store(_STORE_NAME)
    if data is None:
        try:
            legacy = json.loads(_state_path().read_text(encoding="utf-8"))
        except Exception:
            return None
        if isinstance(legacy, dict) and legacy.get("schema") == _STATE_SCHEMA:
            _store.set_store(_STORE_NAME, legacy)
            data = legacy
    return data if isinstance(data, dict) and data.get("schema") == _STATE_SCHEMA else None


def _atomic_write_state(payload: Dict[str, Any]) -> str:
    from . import npanel_persistence as _store
    text = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    if not _store.set_store(_STORE_NAME, payload):
        raise OSError("Smart_UV_Suite.json could not be written")
    return text


def _save_all_settings(context: Optional[bpy.types.Context], enabled: bool, cached_only: bool = False) -> None:
    global _PERSIST_LAST_JSON, _PERSIST_BUSY
    if _PERSIST_BUSY:
        return
    _PERSIST_BUSY = True
    try:
        payload = {
            "schema": _STATE_SCHEMA,
            "enabled": bool(enabled),
            "addon": _package_root().rsplit(".", 1)[-1],
            "saved_at": time.time(),
            "roots": _persistence_roots(context, cached_only=cached_only) if enabled else {},
            "axis_by_window": dict(_AXIS_BY_WINDOW) if enabled else {},
        }
        comparable = dict(payload)
        comparable.pop("saved_at", None)
        comparable_text = json.dumps(comparable, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        last_comparable = ""
        if _PERSIST_LAST_JSON:
            try:
                previous = json.loads(_PERSIST_LAST_JSON)
                previous.pop("saved_at", None)
                last_comparable = json.dumps(previous, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            except Exception:
                pass
        if comparable_text != last_comparable:
            _PERSIST_LAST_JSON = _atomic_write_state(payload)
    finally:
        _PERSIST_BUSY = False


def _restore_all_settings(context: Optional[bpy.types.Context]) -> bool:
    global _PERSIST_LAST_JSON, _PERSIST_BUSY
    if _PERSIST_BUSY:
        return False
    state = _read_state_file()
    if not state or not bool(state.get("enabled", False)):
        return False
    roots = state.get("roots", {})
    if not isinstance(roots, dict) or not roots:
        return False
    _PERSIST_BUSY = True
    restored = 0
    try:
        for path, data in roots.items():
            struct = _find_struct_by_path(context, path)
            if struct is not None and isinstance(data, dict):
                restored += _restore_group(struct, data)
        axis = state.get("axis_by_window", {})
        if isinstance(axis, dict):
            # Window pointers do not survive restart. Apply the most recently
            # stored U, V, or FREE axis to the current window only.
            remembered = next(
                (value for value in reversed(list(axis.values())) if str(value).upper() in {"X", "Y", "NONE", "FREE"}),
                None,
            )
            if remembered is not None:
                _set_axis(context, remembered)
        _PERSIST_LAST_JSON = json.dumps(state, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    finally:
        _PERSIST_BUSY = False
    return restored > 0


_PERSIST_PENDING_TRIES = 0
_HOOK_LAST_RESOLVE: Dict[str, float] = {"axis_memory": 0.0, "panel_state_save": 0.0}


def _arm_persistence_timer(delay: float = 1.0) -> None:
    """One-shot save/restore pass.  Nothing stays resident: the timer ends after its pass."""
    try:
        if not bpy.app.timers.is_registered(_persistence_timer):
            bpy.app.timers.register(_persistence_timer, first_interval=delay, persistent=True)
    except Exception:
        pass


def _arm_axis_timer() -> None:
    """Start the axis-memory timer (only called while the switch is ON or being resolved)."""
    try:
        if not bpy.app.timers.is_registered(_axis_history_timer):
            # Operators that ran before the switch was turned ON are not remembered.
            token = _latest_transform_token()
            wm = getattr(bpy.context, "window_manager", None)
            if token is not None and wm is not None:
                for window in wm.windows:
                    _LAST_OPERATOR_TOKEN[_safe_pointer(window)] = token
            bpy.app.timers.register(_axis_history_timer, first_interval=0.25, persistent=True)
    except Exception:
        pass


_NOTE_LAST = 0.0


def note_panel_draw(context: Optional[bpy.types.Context] = None) -> None:
    """Called by the root N-panel draw: starts the on-demand timers when their switch is ON.

    No timer is resident by default; a save pass runs about one second after a Smart UV panel redraws
    (every setting change redraws it), and the axis timer exists only while its switch is ON.
    """
    global _NOTE_LAST
    try:
        now = time.monotonic()
        if now - _NOTE_LAST < 0.1:
            return
        _NOTE_LAST = now
        for feature in ("panel_state_save", "axis_memory"):
            if feature in _BINDING_CACHE:
                on = _feature_value(context, feature, False, cached_only=True)
                if feature == "axis_memory":
                    if on:
                        _arm_axis_timer()
                elif on or _PERSIST_LAST_ENABLED is not False:
                    _arm_persistence_timer(1.0)
            elif now - _HOOK_LAST_RESOLVE[feature] > 5.0:
                _HOOK_LAST_RESOLVE[feature] = now
                if feature == "axis_memory":
                    _arm_axis_timer()
                else:
                    _arm_persistence_timer(0.35)
    except Exception:
        pass


def _persistence_timer() -> Optional[float]:
    global _PERSIST_RESTORE_PENDING, _PERSIST_RESTORED, _PERSIST_LAST_ENABLED, _PERSIST_PENDING_TRIES
    try:
        context = bpy.context
        if _PERSIST_RESTORE_PENDING:
            state = _read_state_file()
            if state and bool(state.get("enabled", False)):
                if _restore_all_settings(context):
                    _PERSIST_RESTORE_PENDING = False
                    _PERSIST_RESTORED = True
                    # A restored switch may have turned axis memory ON.
                    if _feature_value(context, "axis_memory", False):
                        _arm_axis_timer()
                else:
                    _PERSIST_PENDING_TRIES += 1
                    if _PERSIST_PENDING_TRIES >= 120:
                        _PERSIST_RESTORE_PENDING = False
                        _PERSIST_RESTORED = True
            else:
                _PERSIST_RESTORE_PENDING = False
                _PERSIST_RESTORED = True
        enabled = _feature_value(context, "panel_state_save", False)
        if _PERSIST_LAST_ENABLED is None or enabled != _PERSIST_LAST_ENABLED:
            _PERSIST_LAST_ENABLED = enabled
            _save_all_settings(context, enabled)
        elif enabled and _PERSIST_RESTORED:
            _save_all_settings(context, True)
    except Exception:
        pass
    return 0.5 if _PERSIST_RESTORE_PENDING else None


def _run_transform_guard() -> None:
    try:
        from . import transform_persistence_guard as _guard
        _guard.run_guard_if_enabled()
    except Exception:
        pass


@persistent
def _load_post(_dummy):
    global _PERSIST_RESTORE_PENDING, _PERSIST_RESTORED
    global _PERSIST_PENDING_TRIES
    _PERSIST_PENDING_TRIES = 0
    _PERSIST_RESTORE_PENDING = True
    _PERSIST_RESTORED = False
    # Loaded files replace every scene/workspace PropertyGroup instance.
    _invalidate_binding_cache()
    _run_transform_guard()
    try:
        from . import ownership_runtime_18168 as _own
        _own._rearm_driver_namespace()
    except Exception:
        pass
    _arm_persistence_timer(0.35)


@persistent
def _save_pre(_dummy):
    _stage_legacy_scan_cache_for_save()
    _run_transform_guard()
    try:
        enabled = _feature_value(bpy.context, "panel_state_save", False)
        _save_all_settings(bpy.context, enabled)
    except Exception:
        pass


def _legacy_scan_cache_payload(value: Any) -> Optional[Dict[str, Any]]:
    """Return an owned legacy payload only when its schema is exact."""
    try:
        payload = dict(value.items())
    except Exception:
        return None
    if frozenset(payload) != _LEGACY_SCAN_CACHE_KEYS:
        return None
    if payload.get("has_result") is not True:
        return None
    if any(type(payload.get(key)) is not bool for key in _LEGACY_SCAN_CACHE_BOOL_KEYS):
        return None
    if any(type(payload.get(key)) is not int for key in _LEGACY_SCAN_CACHE_INT_KEYS):
        return None
    if any(type(payload.get(key)) is not float for key in _LEGACY_SCAN_CACHE_FLOAT_KEYS):
        return None
    if any(type(payload.get(key)) is not str for key in _LEGACY_SCAN_CACHE_TEXT_KEYS):
        return None
    return payload


def _stage_legacy_scan_cache_for_save() -> int:
    """Remove only exact obsolete cache payloads at every save boundary."""
    scenes = list(getattr(getattr(bpy, "data", None), "scenes", ()) or ())
    staged = 0
    for scene in scenes:
        try:
            if getattr(scene, "library", None) is not None:
                continue
            payload = _legacy_scan_cache_payload(scene.get(_LEGACY_SCAN_CACHE_KEY))
            if payload is None:
                continue
            del scene[_LEGACY_SCAN_CACHE_KEY]
            staged += 1
        except Exception:
            continue
    return staged


# -----------------------------------------------------------------------------
# Lifecycle
# -----------------------------------------------------------------------------
#
# 1.8.229 consolidation: this module registers NO operator classes and NO
# keymap rows any more, and it never suppresses other keymap rows.  The old
# _suppress_conflicting_keymaps wrote ``kmi.active = False`` into
# ``keyconfigs.user`` (which Blender persists with preferences) and force
# deactivated SmartUV's own legacy rows on every enable; that ownership
# flip-flop was the root enabler of the dual-implementation instability.

_REGISTERED = False

# SmartUV row ids the retired 1.8.228 suppressor may have force-deactivated in
# ``keyconfigs.user``.  Blender persists that flag with the preferences, so the
# damage outlives the code that caused it. Repair only bindings for supported
# operators. Leave retired bindings in their existing state.
_SUPPRESSOR_DAMAGE_IDNAMES = (
    "smart_uv_suite.instant_select_drag_move",
    "smart_uv_suite.uv_gizmo_grip_fix_grab",
    "smart_uv_suite.uv_crossing_gesture",
)


def _repair_suppressed_user_rows() -> int:
    repaired = 0
    try:
        keyconfigs = getattr(getattr(bpy.context, "window_manager", None), "keyconfigs", None)
        user_kc = getattr(keyconfigs, "user", None)
        if user_kc is None:
            return 0
        for km in getattr(user_kc, "keymaps", ()):
            if getattr(km, "space_type", "") != "IMAGE_EDITOR":
                continue
            for kmi in getattr(km, "keymap_items", ()):
                try:
                    if str(kmi.idname) in _SUPPRESSOR_DAMAGE_IDNAMES and not bool(kmi.active):
                        kmi.active = True
                        repaired += 1
                except Exception:
                    continue
    except Exception:
        return repaired
    return repaired


def _timer_registered(function: Any) -> bool:
    try:
        return bool(bpy.app.timers.is_registered(function))
    except Exception:
        return False


def register() -> None:
    global _REGISTERED, _PERSIST_RESTORE_PENDING, _PERSIST_RESTORED
    if _REGISTERED:
        return
    _invalidate_binding_cache()
    _repair_suppressed_user_rows()
    if _load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_load_post)
    if _save_pre not in bpy.app.handlers.save_pre:
        bpy.app.handlers.save_pre.append(_save_pre)
    _arm_axis_timer()
    _arm_persistence_timer(0.35)
    _PERSIST_RESTORE_PENDING = True
    _PERSIST_RESTORED = False
    _REGISTERED = True


def unregister() -> None:
    global _REGISTERED
    try:
        # No walk here: at quit, other add-ons may already be unregistered (see _PERSIST_ROOT_PATHS). Save only when the
        # setting itself is still reachable, so an unknown value never overwrites the saved state with "disabled".
        enabled = _feature_value(bpy.context, "panel_state_save", False, cached_only=True)
        if "panel_state_save" in _BINDING_CACHE:
            _save_all_settings(bpy.context, enabled, cached_only=True)
    except Exception:
        pass
    for handler_list, function in ((bpy.app.handlers.load_post, _load_post), (bpy.app.handlers.save_pre, _save_pre)):
        while function in handler_list:
            try:
                handler_list.remove(function)
            except Exception:
                break
    for function in (_axis_history_timer, _persistence_timer):
        if _timer_registered(function):
            try:
                bpy.app.timers.unregister(function)
            except Exception:
                pass
    _invalidate_binding_cache()
    _AXIS_BY_WINDOW.clear()
    _LAST_OPERATOR_TOKEN.clear()
    _REGISTERED = False
