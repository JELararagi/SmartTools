from __future__ import annotations
from . import legacy_operators as _prev
_IGNORE_KEYS = {'__name__','__package__','__loader__','__spec__','__file__','__cached__','__builtins__'}
globals().update({k: v for k, v in _prev.__dict__.items() if k not in _IGNORE_KEYS})

import json
import os
from mathutils import geometry as _mu_geometry

# ============================================================
# Pro Operators: Stack Pro, Pack Pro, Texel Density Pro, Inspector, Auto Unwrap Pro
# ============================================================


def _quantile_sorted(values, q: float):
    vals = list(values or [])
    if not vals:
        return 0.0
    vals.sort()
    if len(vals) == 1:
        return float(vals[0])
    q = max(0.0, min(1.0, float(q)))
    pos = (len(vals) - 1) * q
    lo = int(math.floor(pos))
    hi = int(math.ceil(pos))
    if lo == hi:
        return float(vals[lo])
    t = pos - lo
    return float(vals[lo]) * (1.0 - t) + float(vals[hi]) * t


def _unique_uv_points(isl: _Island, ndigits: int = 5):
    seen = set()
    pts = []
    for p in getattr(isl, 'uv_points', []) or []:
        v = Vector(p)
        key = (round(float(v.x), ndigits), round(float(v.y), ndigits))
        if key in seen:
            continue
        seen.add(key)
        pts.append(v)
    return pts


def _radial_signature(isl: _Island):
    pts = _unique_uv_points(isl)
    if not pts:
        return (1.0, 1.0, 1.0, 1.0, 1.0)
    center = Vector(getattr(isl, 'uv_centroid', Vector((sum(p.x for p in pts) / len(pts), sum(p.y for p in pts) / len(pts)))))
    scale = max(1.0e-12, math.sqrt(max(1.0e-12, float(getattr(isl, 'abs_area', 0.0) or 0.0))))
    radii = sorted((p - center).length / scale for p in pts)
    return tuple(_quantile_sorted(radii, q) for q in (0.05, 0.25, 0.5, 0.75, 0.95))


def _edge_length_signature(isl: _Island):
    scale = max(1.0e-12, math.sqrt(max(1.0e-12, float(getattr(isl, 'abs_area', 0.0) or 0.0))))
    lengths = []
    # fallback without relying on ui helpers: sample the current loop UV lengths
    for face in getattr(isl, 'faces', []) or []:
        loops = list(getattr(face, 'loops', []) or [])
        count = len(loops)
        if count < 2:
            continue
        for i in range(count):
            try:
                uv0 = Vector(loops[i][loops[i].layers.uv.active].uv)
                uv1 = Vector(loops[(i + 1) % count][loops[(i + 1) % count].layers.uv.active].uv)
            except Exception:
                continue
            length = (uv1 - uv0).length / scale
            if length > 1.0e-12:
                lengths.append(length)
    if not lengths:
        pts = _unique_uv_points(isl)
        if len(pts) >= 2:
            center = Vector(getattr(isl, 'uv_centroid', Vector((0.0, 0.0))))
            ordered = sorted(pts, key=lambda p: math.atan2((p - center).y, (p - center).x))
            for i in range(len(ordered)):
                length = (ordered[(i + 1) % len(ordered)] - ordered[i]).length / scale
                if length > 1.0e-12:
                    lengths.append(length)
    lengths.sort()
    return tuple(_quantile_sorted(lengths, q) for q in (0.1, 0.3, 0.5, 0.7, 0.9)) if lengths else (1.0, 1.0, 1.0, 1.0, 1.0)


def _corner_angle_signature(isl: _Island):
    angles = []
    for face in getattr(isl, 'faces', []) or []:
        loops = list(getattr(face, 'loops', []) or [])
        count = len(loops)
        if count < 3:
            continue
        for i in range(count):
            prev_loop = loops[i - 1]
            loop = loops[i]
            next_loop = loops[(i + 1) % count]
            try:
                uv_prev = Vector(prev_loop[prev_loop.layers.uv.active].uv)
                uv_cur = Vector(loop[loop.layers.uv.active].uv)
                uv_next = Vector(next_loop[next_loop.layers.uv.active].uv)
            except Exception:
                continue
            a = uv_prev - uv_cur
            b = uv_next - uv_cur
            if a.length <= 1.0e-12 or b.length <= 1.0e-12:
                continue
            ang = a.angle(b)
            angles.append(float(ang) / math.pi)
    angles.sort()
    return tuple(_quantile_sorted(angles, q) for q in (0.1, 0.3, 0.5, 0.7, 0.9)) if angles else (0.5, 0.5, 0.5, 0.5, 0.5)


def _face_degree_signature(isl: _Island):
    counts = sorted(int(len(getattr(face, 'verts', []) or [])) for face in getattr(isl, 'faces', []) or [])
    return tuple(_quantile_sorted(counts, q) for q in (0.0, 0.25, 0.5, 0.75, 1.0)) if counts else (4.0, 4.0, 4.0, 4.0, 4.0)


def _island_metrics(isl: _Island):
    w = max(1.0e-12, float(getattr(isl, 'bbox_max', Vector((0.0, 0.0))).x - getattr(isl, 'bbox_min', Vector((0.0, 0.0))).x))
    h = max(1.0e-12, float(getattr(isl, 'bbox_max', Vector((0.0, 0.0))).y - getattr(isl, 'bbox_min', Vector((0.0, 0.0))).y))
    bbox_area = max(1.0e-12, w * h)
    area = max(1.0e-12, float(getattr(isl, 'abs_area', 0.0) or 0.0))
    return {
        'area': area,
        'aspect': w / h,
        'fill': area / bbox_area,
        'bbox_area': bbox_area,
        'loops': len(getattr(isl, 'loops', []) or []),
        'faces': len(getattr(isl, 'faces', []) or []),
        'verts': len(getattr(isl, 'vert_ids', set()) or set()),
        'tiles': len(getattr(isl, 'udim_tiles', set()) or set()),
        'radial_sig': _radial_signature(isl),
        'edge_sig': _edge_length_signature(isl),
        'angle_sig': _corner_angle_signature(isl),
        'face_sig': _face_degree_signature(isl),
    }


def _signature_ratio_match(sig_a, sig_b, tol: float):
    tol = max(0.0, float(tol))
    if len(sig_a) != len(sig_b):
        return False
    for av, bv in zip(sig_a, sig_b):
        base = max(abs(float(av)), abs(float(bv)), 1.0e-12)
        if abs(float(av) - float(bv)) / base > tol:
            return False
    return True


def _islands_match(ref: _Island, isl: _Island, area_tol: float, aspect_tol: float, strict: bool = False) -> bool:
    rm = _island_metrics(ref)
    im = _island_metrics(isl)
    if strict:
        for key in ('faces', 'verts', 'tiles', 'loops'):
            if im[key] != rm[key]:
                return False
    if abs(im['area'] / rm['area'] - 1.0) > max(0.0, area_tol):
        return False
    if abs(im['aspect'] / rm['aspect'] - 1.0) > max(0.0, aspect_tol):
        return False
    fill_tol = max(0.02 if strict else 0.04, min(0.12 if strict else 0.30, max(area_tol, aspect_tol) * 0.75))
    if abs(im['fill'] / rm['fill'] - 1.0) > fill_tol:
        return False
    radial_tol = 0.05 if strict else max(0.07, min(0.22, max(area_tol, aspect_tol) * 0.9 + 0.03))
    edge_tol = 0.04 if strict else max(0.06, min(0.18, max(area_tol, aspect_tol) * 0.75 + 0.03))
    angle_tol = 0.03 if strict else max(0.05, min(0.15, max(area_tol, aspect_tol) * 0.65 + 0.02))
    face_tol = 0.0 if strict else 0.25
    if not _signature_ratio_match(rm['radial_sig'], im['radial_sig'], radial_tol):
        return False
    if not _signature_ratio_match(rm['edge_sig'], im['edge_sig'], edge_tol):
        return False
    if not _signature_ratio_match(rm['angle_sig'], im['angle_sig'], angle_tol):
        return False
    if not _signature_ratio_match(rm['face_sig'], im['face_sig'], face_tol):
        return False
    return True


def _dominant_material_index(isl: _Island) -> int:
    counts = {}
    for f in getattr(isl, 'faces', []) or []:
        idx = int(getattr(f, 'material_index', 0) or 0)
        counts[idx] = counts.get(idx, 0) + 1
    if not counts:
        return 0
    return sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))[0][0]


def _group_bbox(islands):
    if not islands:
        return Vector((0.0, 0.0)), Vector((0.0, 0.0))
    minx = min(float(i.bbox_min.x) for i in islands)
    miny = min(float(i.bbox_min.y) for i in islands)
    maxx = max(float(i.bbox_max.x) for i in islands)
    maxy = max(float(i.bbox_max.y) for i in islands)
    return Vector((minx, miny)), Vector((maxx, maxy))


def _make_rect_proxy(id_, width, height):
    proxy = _Island(id_)
    w = max(1.0e-6, float(width))
    h = max(1.0e-6, float(height))
    proxy.uv_points = [Vector((0.0, 0.0)), Vector((w, 0.0)), Vector((w, h)), Vector((0.0, h))]
    proxy.uv_centroid = Vector((w * 0.5, h * 0.5))
    proxy.axis = Vector((1.0, 0.0))
    proxy.bbox_min = Vector((0.0, 0.0))
    proxy.bbox_max = Vector((w, h))
    proxy.abs_area = w * h
    proxy.signed_area = proxy.abs_area
    return proxy


def _group_islands_by_mode(islands, mode='SIMILAR', area_tol=0.08, aspect_tol=0.15):
    islands = list(islands or [])
    if not islands:
        return []
    mode = str(mode or 'SIMILAR').upper()
    if mode == 'MATERIAL':
        buckets = {}
        for isl in islands:
            buckets.setdefault(_dominant_material_index(isl), []).append(isl)
        return [{'label': f'MAT_{key}', 'ref': value[0], 'islands': value} for key, value in sorted(buckets.items(), key=lambda kv: kv[0])]
    strict = (mode == 'IDENTICAL')
    ordered = sorted(islands, key=lambda isl: (len(getattr(isl, 'faces', []) or []), float(getattr(isl, 'abs_area', 0.0) or 0.0)), reverse=True)
    groups = []
    for isl in ordered:
        placed = False
        for grp in groups:
            if _islands_match(grp['ref'], isl, area_tol, aspect_tol, strict=strict):
                grp['islands'].append(isl)
                placed = True
                break
        if not placed:
            groups.append({'label': f'{mode}_{len(groups) + 1}', 'ref': isl, 'islands': [isl]})
    return groups


def _build_group_pack_records(groups, margin_uv, rot_step):
    records = []
    for gi, grp in enumerate(groups):
        islands = list(grp.get('islands', []))
        if not islands:
            continue
        gmin, _ = _group_bbox(islands)
        origin = Vector(gmin)
        proxies = []
        members = []
        for ii, isl in enumerate(islands):
            proxy = _Island(ii)
            proxy.uv_points = [Vector(p) - origin for p in isl.uv_points]
            proxy.uv_centroid = Vector(isl.uv_centroid) - origin
            proxy.axis = Vector(isl.axis)
            proxy.bbox_min = Vector(isl.bbox_min) - origin
            proxy.bbox_max = Vector(isl.bbox_max) - origin
            proxy.has_pin = bool(getattr(isl, 'has_pin', False))
            proxies.append(proxy)
            members.append({'island': isl, 'proxy': proxy})
        placements, ok = _pack_shelf(proxies, margin_uv, rot_step, allow_rotate=(int(rot_step or 0) != 0))
        if not ok:
            placements = {}
            for ii, item in enumerate(members):
                proxy = item['proxy']
                placements[ii] = {
                    'angle': 0.0,
                    'bmin': Vector(proxy.bbox_min),
                    'bmax': Vector(proxy.bbox_max),
                    'dx': margin_uv * 2.0 - proxy.bbox_min.x,
                    'dy': margin_uv * 2.0 - proxy.bbox_min.y,
                }
        group_min = Vector((1.0e18, 1.0e18))
        group_max = Vector((-1.0e18, -1.0e18))
        for ii, item in enumerate(members):
            pl = placements.get(ii)
            if not pl:
                continue
            bmin = Vector(pl.get('bmin', item['proxy'].bbox_min)) + Vector((pl.get('dx', 0.0), pl.get('dy', 0.0)))
            bmax = Vector(pl.get('bmax', item['proxy'].bbox_max)) + Vector((pl.get('dx', 0.0), pl.get('dy', 0.0)))
            group_min.x = min(group_min.x, bmin.x)
            group_min.y = min(group_min.y, bmin.y)
            group_max.x = max(group_max.x, bmax.x)
            group_max.y = max(group_max.y, bmax.y)
            item['angle'] = float(pl.get('angle', 0.0))
            item['delta'] = Vector((float(pl.get('dx', 0.0)), float(pl.get('dy', 0.0))))
            item['pivot_local'] = Vector(item['proxy'].uv_centroid)
        if group_min.x > group_max.x:
            group_min = Vector((0.0, 0.0))
            group_max = Vector((1.0e-4, 1.0e-4))
        for item in members:
            item['delta'] = Vector(item['delta']) - group_min
        size = group_max - group_min
        records.append({
            'label': grp.get('label', f'GROUP_{gi + 1}'),
            'proxy': _make_rect_proxy(gi, max(1.0e-6, float(size.x)), max(1.0e-6, float(size.y))),
            'origin': origin,
            'members': members,
        })
    return records


def _face_world_area(face, obj):
    area = 0.0
    try:
        mw = obj.matrix_world
        loops = list(face.loops)
        if len(loops) < 3:
            return 0.0
        p0 = mw @ loops[0].vert.co
        for i in range(1, len(loops) - 1):
            p1 = mw @ loops[i].vert.co
            p2 = mw @ loops[i + 1].vert.co
            area += ((p1 - p0).cross(p2 - p0)).length * 0.5
    except Exception:
        return 0.0
    return area


def _island_stretch_score(isl: _Island, obj, uv_layer):
    area_ratios = []
    tri_scores = []
    mw = getattr(obj, 'matrix_world', None)
    for face in getattr(isl, 'faces', []) or []:
        loops = list(getattr(face, 'loops', []) or [])
        if len(loops) < 3:
            continue
        try:
            wpts = [mw @ loop.vert.co for loop in loops]
        except Exception:
            wpts = [loop.vert.co.copy() for loop in loops]
        upts = [Vector(loop[uv_layer].uv) for loop in loops]
        for i in range(1, len(loops) - 1):
            wa = ((wpts[i] - wpts[0]).cross(wpts[i + 1] - wpts[0])).length * 0.5
            ua = abs((upts[i].x - upts[0].x) * (upts[i + 1].y - upts[0].y) - (upts[i + 1].x - upts[0].x) * (upts[i].y - upts[0].y)) * 0.5
            if wa <= 1.0e-12 or ua <= 1.0e-12:
                continue
            area_ratio = ua / wa
            area_ratios.append(area_ratio)
            edge_ratios = []
            tri_w = (wpts[0], wpts[i], wpts[i + 1])
            tri_u = (upts[0], upts[i], upts[i + 1])
            for ea, eb in ((0, 1), (1, 2), (2, 0)):
                wl = (tri_w[eb] - tri_w[ea]).length
                ul = (tri_u[eb] - tri_u[ea]).length
                if wl > 1.0e-12 and ul > 1.0e-12:
                    edge_ratios.append(ul / wl)
            if len(edge_ratios) >= 2:
                med = _quantile_sorted(sorted(edge_ratios), 0.5)
                med = max(1.0e-12, med)
                anisotropy = max(max(r / med, med / r) for r in edge_ratios)
            else:
                anisotropy = 1.0
            tri_scores.append((area_ratio, anisotropy))
    if not area_ratios:
        return 1.0, []
    area_med = max(1.0e-12, _quantile_sorted(sorted(area_ratios), 0.5))
    details = []
    worst = 1.0
    for area_ratio, anisotropy in tri_scores:
        area_dev = max(area_ratio / area_med, area_med / area_ratio)
        score = max(1.0, float(area_dev), float(anisotropy))
        details.append(score)
        worst = max(worst, score)
    return worst, details


def _suv_pack_tile_offset(tile_index, start_u=0, start_v=0, tile_columns=10, tile_fill='ROW'):
    cols = max(1, int(tile_columns or 10))
    fill = str(tile_fill or 'ROW').upper()
    idx = max(0, int(tile_index or 0))
    if fill == 'COLUMN':
        u = idx // cols
        v = idx % cols
    else:
        u = idx % cols
        v = idx // cols
    return Vector((float(start_u) + float(u), float(start_v) + float(v)))


def _suv_group_record_metrics(rec):
    proxy = rec.get('proxy')
    if proxy is None:
        return 0.0, 0.0, 0
    w = max(1.0e-8, float(proxy.bbox_max.x - proxy.bbox_min.x))
    h = max(1.0e-8, float(proxy.bbox_max.y - proxy.bbox_min.y))
    area = w * h
    count = len(rec.get('members', [])) or (1 if rec.get('leader') is not None else 0)
    return area, max(w, h), int(count)


def _suv_sort_group_pack_records(records, mode='SIZE_DESC'):
    mode = str(mode or 'SIZE_DESC').upper()
    if mode == 'NONE':
        return list(records)

    def _key(rec):
        area, edge, count = _suv_group_record_metrics(rec)
        label = str(rec.get('label', ''))
        if mode == 'SIZE_ASC':
            return (area, edge, label)
        if mode == 'COUNT_DESC':
            return (-count, -area, label)
        if mode == 'COUNT_ASC':
            return (count, area, label)
        if mode == 'LABEL':
            return (label, -area, -count)
        return (-area, -edge, label)

    return sorted(list(records), key=_key)


def _suv_shrink_groups_to_fit_tile(groups, uv_layer, margin_uv, rot_step):
    """Group blocks waste more room than single islands, so shrink until the blocks themselves fit one tile."""
    islands = [isl for grp in groups for isl in grp.get('islands', [])]
    _suv_shrink_islands_to_fit_tile(islands, uv_layer, margin_uv, rot_step, rot_step != 0)
    for _ in range(16):
        records = _build_group_pack_records(groups, margin_uv, rot_step)
        if _pack_shelf([rec['proxy'] for rec in records], margin_uv, 0, allow_rotate=False)[1]:
            return
        for isl in islands:
            pivot = Vector(isl.uv_centroid)
            _island_apply_transform(isl, uv_layer, lambda u, pivot=pivot: pivot + (Vector(u) - pivot) * 0.85)


def _suv_apply_group_pack_records_ext(records, group_placements, uv_layer, start_u=0, start_v=0, tile_columns=10, tile_fill='ROW'):
    groups_done = 0
    packed_islands = 0
    max_tile_index = 0
    for rec in records:
        proxy = rec.get('proxy')
        if proxy is None:
            continue
        pl = group_placements.get(proxy.id)
        if not pl:
            continue
        group_delta = Vector((float(pl.get('dx', 0.0)), float(pl.get('dy', 0.0))))
        tile_index = int(pl.get('tile_index', 0) or 0)
        max_tile_index = max(max_tile_index, tile_index)
        tile_off = _suv_pack_tile_offset(tile_index, start_u=start_u, start_v=start_v, tile_columns=tile_columns, tile_fill=tile_fill)
        origin = Vector(rec['origin'])
        for item in rec.get('members', []):
            isl = item['island']
            pivot_local = Vector(item['pivot_local'])
            ang = float(item['angle'])
            delta = tile_off + group_delta + Vector(item['delta'])
            def tf(uuv, origin=origin, pivot_local=pivot_local, ang=ang, delta=delta):
                uu = Vector(uuv) - origin
                uu = pivot_local + _rotate2(uu - pivot_local, ang) + delta
                return uu
            _island_apply_transform(isl, uv_layer, tf)
            packed_islands += 1
        groups_done += 1
    return groups_done, packed_islands, (max_tile_index + 1 if records else 0)


def _suv_build_group_leader_records(groups):
    records = []
    for gi, grp in enumerate(groups):
        islands = list(grp.get('islands', []))
        if not islands:
            continue
        leader = grp.get('ref') or islands[0]
        w = max(1.0e-6, float(leader.bbox_max.x - leader.bbox_min.x))
        h = max(1.0e-6, float(leader.bbox_max.y - leader.bbox_min.y))
        records.append({
            'label': grp.get('label', f'IDENTICAL_{gi+1}'),
            'leader': leader,
            'followers': [isl for isl in islands if isl is not leader],
            'proxy': _make_rect_proxy(gi, w, h),
        })
    return records


def _suv_apply_leader_pack_records(records, placements, uv_layer, start_u=0, start_v=0, tile_columns=10, tile_fill='ROW', rot_step=90):
    groups_done = 0
    packed_islands = 0
    max_tile_index = 0
    for rec in records:
        leader = rec.get('leader')
        proxy = rec.get('proxy')
        if leader is None or proxy is None:
            continue
        pl = placements.get(proxy.id)
        if not pl:
            continue
        ang = float(pl.get('angle', 0.0))
        dx = float(pl.get('dx', 0.0))
        dy = float(pl.get('dy', 0.0))
        tile_index = int(pl.get('tile_index', 0) or 0)
        max_tile_index = max(max_tile_index, tile_index)
        tile_off = _suv_pack_tile_offset(tile_index, start_u=start_u, start_v=start_v, tile_columns=tile_columns, tile_fill=tile_fill)
        pivot = Vector(leader.uv_centroid)
        def tf(uuv, pivot=pivot, ang=ang, dx=dx, dy=dy, tile_off=tile_off):
            return pivot + _rotate2(Vector(uuv) - pivot, ang) + Vector((dx, dy)) + tile_off
        _island_apply_transform(leader, uv_layer, tf)
        packed_islands += 1
        for follower in rec.get('followers', []):
            SUV_OT_stack_pro._stack_pair(uv_layer, leader, follower, int(rot_step), True)
            packed_islands += 1
        groups_done += 1
    return groups_done, packed_islands, (max_tile_index + 1 if records else 0)


def _suv_record_islands(records):
    islands = []
    seen = set()
    for rec in records or []:
        leader = rec.get('leader')
        if leader is not None and id(leader) not in seen:
            seen.add(id(leader))
            islands.append(leader)
        for follower in rec.get('followers', []) or []:
            if follower is not None and id(follower) not in seen:
                seen.add(id(follower))
                islands.append(follower)
        for item in rec.get('members', []) or []:
            isl = item.get('island') if isinstance(item, dict) else None
            if isl is not None and id(isl) not in seen:
                seen.add(id(isl))
                islands.append(isl)
    return islands


def _suv_fit_islands_to_tile(islands, uv_layer, margin_uv, tile_off):
    dst_min = Vector((float(margin_uv), float(margin_uv)))
    dst_max = Vector((1.0 - float(margin_uv), 1.0 - float(margin_uv)))
    return _fit_islands_to_rect_core(islands, uv_layer, dst_min, dst_max, keep_aspect=True, tile_off=tile_off)

class SUV_OT_stack_pro(bpy.types.Operator):
    bl_idname = "uv.suv_stack_pro"
    bl_label = 'Stack Pro'
    bl_description = "Stack matching islands with the suite's advanced overlap controls for mirroring, reuse and trimsheet work. / 高度な重ね合わせ制御で一致アイランドをスタックし、ミラーや再利用、トリム運用に役立てます。"
    bl_options = {'UNDO'}

    rotation_step: bpy.props.EnumProperty(
        name="Rotation Step",
        items=[('0', "Free", ""), ('90', "90°", ""), ('45', "45°", ""), ('15', "15°", "")],
        default='15'
    )
    allow_mirror: bpy.props.BoolProperty(name="Allow Mirror", default=True)

    @staticmethod
    def _stack_pair(uv_layer, ref: _Island, isl: _Island, rot_step_deg: int, allow_mirror: bool):
        ref_cent = Vector(ref.uv_centroid)
        ref_axis = ref.axis.normalized() if ref.axis.length > 0 else Vector((1.0, 0.0))
        ref_size = ref.bbox_max - ref.bbox_min
        ref_area = max(1.0e-12, float(ref.abs_area))
        step = math.radians(rot_step_deg) if rot_step_deg > 0 else 0.0
        ref_diag = max(1.0e-12, float(ref_size.length))

        def _downsample_points(points, limit=128):
            pts = []
            seen = set()
            for p in points or []:
                v = Vector(p)
                key = (round(float(v.x), 5), round(float(v.y), 5))
                if key in seen:
                    continue
                seen.add(key)
                pts.append(v)
            if len(pts) <= limit:
                return pts
            stride = max(1, int(math.ceil(len(pts) / float(limit))))
            return pts[::stride]

        ref_points_sample = _downsample_points([Vector(p) for p in ref.uv_points])

        def _cloud_match_error(points):
            pts = _downsample_points([Vector(p) for p in (points or [])])
            if not pts or not ref_points_sample:
                return float('inf')
            err = 0.0
            for p in pts:
                err += min((p - r).length for r in ref_points_sample)
            for r in ref_points_sample:
                err += min((r - p).length for p in pts)
            return (err / max(1, len(pts) + len(ref_points_sample))) / ref_diag

        def _base_rotation(axis):
            dot = max(min(axis.dot(ref_axis), 1.0), -1.0)
            ang = math.acos(dot)
            crossz = axis.x * ref_axis.y - axis.y * ref_axis.x
            if crossz < 0:
                ang = -ang
            return ang

        def _candidate_points(mirror_mode, angle, scale):
            pts = []
            pivot = Vector(isl.uv_centroid)
            for uv in isl.uv_points:
                x = Vector(uv)
                if mirror_mode == 'MX':
                    x = _mirror_x(x, pivot)
                elif mirror_mode == 'MY':
                    x = _mirror_y(x, pivot)
                x = pivot + _rotate2(x - pivot, angle)
                x = pivot + (x - pivot) * scale
                pts.append(x)
            if not pts:
                return []
            cur_cent = Vector((sum(p.x for p in pts) / len(pts), sum(p.y for p in pts) / len(pts)))
            delta = ref_cent - cur_cent
            return [p + delta for p in pts]

        def _candidate_score(mirror_mode, angle, scale):
            pts = _candidate_points(mirror_mode, angle, scale)
            if not pts:
                return (float('inf'), float('inf'), float('inf'), float('inf'))
            xs = [p.x for p in pts]
            ys = [p.y for p in pts]
            bmin = Vector((min(xs), min(ys)))
            bmax = Vector((max(xs), max(ys)))
            size = bmax - bmin
            bbox_error = (bmin - ref.bbox_min).length + (bmax - ref.bbox_max).length
            size_error = abs(size.x - ref_size.x) + abs(size.y - ref_size.y)
            cloud_error = _cloud_match_error(pts)
            axis = isl.axis.normalized() if isl.axis.length > 0 else Vector((1.0, 0.0))
            if mirror_mode == 'MX':
                axis = Vector((-axis.x, axis.y))
            elif mirror_mode == 'MY':
                axis = Vector((axis.x, -axis.y))
            axis = _rotate2(axis, angle)
            axis_error = 1.0 - abs(axis.normalized().dot(ref_axis)) if axis.length > 1.0e-12 else 1.0
            return (cloud_error, bbox_error, size_error, axis_error)

        pivot = Vector(isl.uv_centroid)
        axis = isl.axis.normalized() if isl.axis.length > 0 else Vector((1.0, 0.0))
        base_scale = math.sqrt(ref_area / max(1.0e-12, float(isl.abs_area)))
        scale_candidates = [1.0]
        if 0.25 <= base_scale <= 4.0 and abs(base_scale - 1.0) > 0.002:
            scale_candidates.append(base_scale)
        mirror_modes = ['NONE']
        if allow_mirror:
            mirror_modes.extend(['MX', 'MY'])
        candidates = []
        for scale in scale_candidates:
            for mirror_mode in mirror_modes:
                if mirror_mode == 'MX':
                    mode_axis = Vector((-axis.x, axis.y))
                elif mirror_mode == 'MY':
                    mode_axis = Vector((axis.x, -axis.y))
                else:
                    mode_axis = axis
                if step > 0.0:
                    kmax = max(1, int(round((2.0 * math.pi) / step)))
                    angle_iter = [k * step for k in range(kmax)]
                else:
                    base = _base_rotation(mode_axis)
                    angle_iter = [base, base + math.pi, base - math.pi * 0.5, base + math.pi * 0.5, 0.0, math.pi * 0.5, math.pi, math.pi * 1.5]
                seen_angles = set()
                for angle in angle_iter:
                    key = round(float((angle + math.pi * 8.0) % (math.pi * 2.0)), 7)
                    if key in seen_angles:
                        continue
                    seen_angles.add(key)
                    candidates.append((mirror_mode, angle, scale))
        mirror_mode, angle, scale = min(candidates, key=lambda it: _candidate_score(*it))

        def tf(u):
            x = Vector(u)
            if mirror_mode == 'MX':
                x = _mirror_x(x, pivot)
            elif mirror_mode == 'MY':
                x = _mirror_y(x, pivot)
            x = pivot + _rotate2(x - pivot, angle)
            x = pivot + (x - pivot) * scale
            x += (ref_cent - pivot)
            return x

        _island_apply_transform(isl, uv_layer, tf)


    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        n = 0
        with _TempMode(context, obj, 'EDIT'):
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.verify()
            sel_faces = _selection_from_context(context, obj, bm, uv_layer)[0]
            if not sel_faces:
                self.report({'WARNING'}, tr(context, "msg.no_selection"))
                return {'CANCELLED'}
            islands = build_islands(bm, uv_layer, faces_subset=sel_faces)
            if len(islands) < 2:
                self.report({'WARNING'}, tr(context, "msg.need_two_islands"))
                return {'CANCELLED'}
            active_face = getattr(bm.faces, "active", None)
            ref = islands[0]
            if active_face:
                for isl in islands:
                    if active_face in isl.faces:
                        ref = isl
                        break
            for isl in islands:
                if isl is ref:
                    continue
                SUV_OT_stack_pro._stack_pair(uv_layer, ref, isl, int(self.rotation_step), self.allow_mirror)
                n += 1
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        self.report({'INFO'}, tr(context, "msg.stack_pro_done", n=n))
        return {'FINISHED'}


class SUV_OT_pack_pro(bpy.types.Operator):
    bl_idname = "uv.suv_pack_pro"
    bl_label = 'Pack Pro'
    bl_description = "Pack UV islands using the suite's advanced layout options, including grouped layout and UDIM-aware placement. / グループ配置やUDIM対応を含む高度なレイアウト設定でUVアイランドをパックします。"
    bl_options = {'UNDO'}

    engine: bpy.props.EnumProperty(
        name="Engine",
        items=[('NATIVE', "Native", ""), ('DETERMINISTIC', "Deterministic", "")],
        default='NATIVE'
    )
    scope: bpy.props.EnumProperty(
        name="Scope",
        items=[('SELECTED', "Selected", ""), ('ALL', "All", "")],
        default='SELECTED'
    )
    udim_mode: bpy.props.EnumProperty(
        name="UDIM Mode",
        items=[('SINGLE', "Single Tile (0-1)", ""), ('KEEP_TILES', "Keep Current Tiles", ""), ('AUTO_TILES', "Auto Tile Expand", "")],
        default='SINGLE'
    )
    margin_px: bpy.props.IntProperty(name="Margin (px)", default=8, min=0)
    texture_size: bpy.props.IntProperty(name="Texture Size", default=2048, min=128)
    rotation_step: bpy.props.EnumProperty(
        name="Rotation Step",
        items=[('0', "0°", ""), ('90', "90°", ""), ('45', "45°", ""), ('15', "15°", "")],
        default='15'
    )
    lock_pinned: bpy.props.BoolProperty(name="Lock Pinned Islands", default=True)
    group_mode: bpy.props.EnumProperty(
        name="Group Mode",
        items=[('NONE', "None", ""), ('MATERIAL', "Material", ""), ('SIMILAR', "Similar", ""), ('IDENTICAL', "Identical", "")],
        default='NONE'
    )
    group_layout: bpy.props.EnumProperty(
        name="Group Layout",
        items=[('SINGLE_TILE', "Single Tile", ""), ('TILES', "Per Group Tile", ""), ('ROWS', "Tile Rows", ""), ('COLUMNS', "Tile Columns", "")],
        default='SINGLE_TILE'
    )
    area_tol: bpy.props.FloatProperty(name="Area Tolerance", default=0.08, min=0.0, max=1.0)
    aspect_tol: bpy.props.FloatProperty(name="Aspect Tolerance", default=0.15, min=0.0, max=1.0)
    start_tile_u: bpy.props.IntProperty(name="Start Tile U", default=0)
    start_tile_v: bpy.props.IntProperty(name="Start Tile V", default=0)
    tile_columns: bpy.props.IntProperty(name="Tile Columns", default=10, min=1, max=100)
    tile_fill: bpy.props.EnumProperty(
        name="Tile Fill",
        items=[('ROW', "Row", ""), ('COLUMN', "Column", "")],
        default='ROW'
    )
    group_sort: bpy.props.EnumProperty(
        name="Group Sort",
        items=[('SIZE_DESC', "Largest First", ""), ('SIZE_ASC', "Smallest First", ""), ('COUNT_DESC', "Largest Cluster First", ""), ('COUNT_ASC', "Smallest Cluster First", ""), ('LABEL', "Label", ""), ('NONE', "Keep Input", "")],
        default='SIZE_DESC'
    )
    stack_identical_groups: bpy.props.BoolProperty(name="Stack Identical Groups", default=True)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}

        margin_uv = float(self.margin_px) / float(self.texture_size) if self.texture_size > 0 else 0.0
        rot_step = int(self.rotation_step)
        tile_fill = 'COLUMN' if str(self.group_layout or '').upper() == 'COLUMNS' else str(self.tile_fill or 'ROW').upper()
        group_layout_mode = 'TILES' if str(self.group_layout or '').upper() in {'TILES', 'ROWS', 'COLUMNS'} else str(self.group_layout or 'SINGLE_TILE').upper()
        start_u = int(self.start_tile_u)
        start_v = int(self.start_tile_v)

        with _TempMode(context, obj, 'EDIT'):
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.verify()

            faces = list(bm.faces) if self.scope == 'ALL' else _selection_from_context(context, obj, bm, uv_layer)[0]
            if not faces:
                self.report({'WARNING'}, tr(context, "msg.no_selection"))
                return {'CANCELLED'}

            islands = build_islands(bm, uv_layer, faces_subset=faces)
            movable = [isl for isl in islands if not (self.lock_pinned and isl.has_pin)]
            if not movable:
                self.report({'INFO'}, tr(context, "msg.pack_pro_all_locked"))
                return {'FINISHED'}

            use_group_pack = str(self.group_mode or 'NONE').upper() != 'NONE'
            requested_engine = str(self.engine or 'NATIVE').upper()
            native_supported = (requested_engine == 'NATIVE' and not use_group_pack and str(self.udim_mode or 'SINGLE').upper() == 'SINGLE')
            effective_engine = 'NATIVE' if native_supported else ('DETERMINISTIC' if requested_engine == 'NATIVE' else requested_engine)
            tiles_used = 1
            grouped_done = 0
            packed_n = 0

            if effective_engine == 'NATIVE':
                ok, err = _suv_run_pack_islands_native(
                    context,
                    margin_uv=margin_uv,
                    rotation_step_deg=rot_step,
                    lock_pinned=self.lock_pinned,
                    udim_source='CLOSEST_UDIM',
                )
                if ok:
                    bm = bmesh.from_edit_mesh(obj.data)
                    uv_layer = bm.loops.layers.uv.verify()
                    native_faces = list(bm.faces) if self.scope == 'ALL' else _selection_from_context(context, obj, bm, uv_layer)[0]
                    native_islands = build_islands(bm, uv_layer, faces_subset=native_faces)
                    native_movable = [isl for isl in native_islands if not (self.lock_pinned and isl.has_pin)]
                    if native_movable:
                        _suv_fit_islands_to_tile(native_movable, uv_layer, margin_uv, Vector((float(start_u), float(start_v))))
                    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
                    self.report({'INFO'}, tr(context, "msg.pack_pro_done", n=len(native_movable) or len(islands)))
                    return {'FINISHED'}
                self.report({'WARNING'}, tr(context, "msg.op_failed", e=err))
                return {'CANCELLED'}

            if use_group_pack:
                groups = _group_islands_by_mode(movable, self.group_mode, self.area_tol, self.aspect_tol)
                groups = [grp for grp in groups if grp.get('islands')]
                group_layout_tiles = (group_layout_mode != 'SINGLE_TILE' or self.udim_mode == 'AUTO_TILES')

                if self.group_mode == 'IDENTICAL' and self.stack_identical_groups:
                    records = _suv_sort_group_pack_records(_suv_build_group_leader_records(groups), self.group_sort)
                    proxies = [rec['proxy'] for rec in records]
                    if self.udim_mode == 'KEEP_TILES':
                        per_tile = {}
                        for rec in records:
                            leader = rec.get('leader')
                            if not leader:
                                continue
                            c = leader.uv_centroid
                            tile = (int(math.floor(c.x)), int(math.floor(c.y)))
                            per_tile.setdefault(tile, []).append(rec)
                        tiles_used = max(1, len(per_tile))
                        for tile, tile_records in per_tile.items():
                            placements, ok = _pack_shelf([rec['proxy'] for rec in tile_records], margin_uv, rot_step, allow_rotate=(rot_step != 0))
                            dg, dn, _ = _suv_apply_leader_pack_records(tile_records, placements, uv_layer, start_u=tile[0], start_v=tile[1], tile_columns=self.tile_columns, tile_fill=tile_fill, rot_step=rot_step)
                            if not ok:
                                fit_ok, fit_err = _suv_fit_islands_to_tile(_suv_record_islands(tile_records), uv_layer, margin_uv, Vector((tile[0], tile[1])))
                                if not fit_ok:
                                    self.report({'WARNING'}, tr(context, "msg.op_failed", e=fit_err or f"Grouped overflow in tile {tile}"))
                                    return {'CANCELLED'}
                            grouped_done += dg
                            packed_n += dn
                    else:
                        if group_layout_tiles:
                            placements = _pack_multi_tiles(proxies, margin_uv, rot_step, allow_rotate=(rot_step != 0))
                            dg, dn, tiles_used = _suv_apply_leader_pack_records(records, placements, uv_layer, start_u=start_u, start_v=start_v, tile_columns=self.tile_columns, tile_fill=tile_fill, rot_step=rot_step)
                        else:
                            placements, ok = _pack_shelf(proxies, margin_uv, rot_step, allow_rotate=(rot_step != 0))
                            dg, dn, _ = _suv_apply_leader_pack_records(records, placements, uv_layer, start_u=start_u, start_v=start_v, tile_columns=self.tile_columns, tile_fill=tile_fill, rot_step=rot_step)
                            if not ok:
                                fit_ok, fit_err = _suv_fit_islands_to_tile(_suv_record_islands(records), uv_layer, margin_uv, Vector((start_u, start_v)))
                                if not fit_ok:
                                    self.report({'WARNING'}, tr(context, "msg.op_failed", e=fit_err or "Grouped pack overflow"))
                                    return {'CANCELLED'}
                        grouped_done += dg
                        packed_n += dn
                else:
                    if self.udim_mode == 'KEEP_TILES':
                        groups_by_tile = {}
                        for grp in groups:
                            c = grp['islands'][0].uv_centroid
                            groups_by_tile.setdefault((int(math.floor(c.x)), int(math.floor(c.y))), []).append(grp)
                        for tile_groups in groups_by_tile.values():
                            _suv_shrink_groups_to_fit_tile(tile_groups, uv_layer, margin_uv, rot_step)
                    elif not group_layout_tiles:
                        _suv_shrink_groups_to_fit_tile(groups, uv_layer, margin_uv, rot_step)
                    records = _suv_sort_group_pack_records(_build_group_pack_records(groups, margin_uv, rot_step), self.group_sort)
                    group_proxies = [rec["proxy"] for rec in records]
                    if self.udim_mode == 'KEEP_TILES':
                        by_tile = {}
                        for rec in records:
                            members = rec.get('members', [])
                            if not members:
                                continue
                            c = members[0]['island'].uv_centroid
                            tile = (int(math.floor(c.x)), int(math.floor(c.y)))
                            by_tile.setdefault(tile, []).append(rec)
                        tiles_used = max(1, len(by_tile))
                        for tile, tile_records in by_tile.items():
                            placements, ok = _pack_shelf([rec['proxy'] for rec in tile_records], margin_uv, 0, allow_rotate=False)
                            dg, dn, _ = _suv_apply_group_pack_records_ext(tile_records, placements, uv_layer, start_u=tile[0], start_v=tile[1], tile_columns=self.tile_columns, tile_fill=tile_fill)
                            if not ok:
                                fit_ok, fit_err = _suv_fit_islands_to_tile(_suv_record_islands(tile_records), uv_layer, margin_uv, Vector((tile[0], tile[1])))
                                if not fit_ok:
                                    self.report({'WARNING'}, tr(context, "msg.op_failed", e=fit_err or f"Grouped overflow in tile {tile}"))
                                    return {'CANCELLED'}
                            grouped_done += dg
                            packed_n += dn
                    else:
                        if group_layout_tiles:
                            placements = _pack_multi_tiles(group_proxies, margin_uv, 0, allow_rotate=False)
                            dg, dn, tiles_used = _suv_apply_group_pack_records_ext(records, placements, uv_layer, start_u=start_u, start_v=start_v, tile_columns=self.tile_columns, tile_fill=tile_fill)
                        else:
                            placements, ok = _pack_shelf(group_proxies, margin_uv, 0, allow_rotate=False)
                            dg, dn, _ = _suv_apply_group_pack_records_ext(records, placements, uv_layer, start_u=start_u, start_v=start_v, tile_columns=self.tile_columns, tile_fill=tile_fill)
                            if not ok:
                                fit_ok, fit_err = _suv_fit_islands_to_tile(_suv_record_islands(records), uv_layer, margin_uv, Vector((start_u, start_v)))
                                if not fit_ok:
                                    self.report({'WARNING'}, tr(context, "msg.op_failed", e=fit_err or "Grouped pack overflow"))
                                    return {'CANCELLED'}
                        grouped_done += dg
                        packed_n += dn
                bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
                if group_layout_tiles or self.udim_mode == 'AUTO_TILES':
                    self.report({'INFO'}, tr(context, "msg.pack_pro_tiles_done", n=packed_n, t=int(max(1, tiles_used))))
                else:
                    self.report({'INFO'}, tr(context, "msg.pack_groups_done", g=grouped_done, n=packed_n))
                return {'FINISHED'}

            # Default deterministic engine (non-grouped)
            if self.udim_mode == 'SINGLE':
                for i, isl in enumerate(movable):
                    isl.id = i
                placements, ok = _pack_shelf(movable, margin_uv, rot_step, allow_rotate=(rot_step != 0))
                pack_scale = 1.0
                if not ok:
                    # A partial placement followed by bounding-box fitting does
                    # not remove overlaps. Find a complete layout before touching
                    # the UVs, uniformly reducing density only when necessary.
                    def scaled_pack(scale):
                        proxies = []
                        for source in movable:
                            proxy = _Island(source.id)
                            proxy.uv_points = [p * scale for p in source.uv_points]
                            proxy.uv_centroid = source.uv_centroid * scale
                            proxy.bbox_min = source.bbox_min * scale
                            proxy.bbox_max = source.bbox_max * scale
                            proxy.axis = source.axis
                            proxies.append(proxy)
                        return _pack_shelf(proxies, margin_uv, rot_step, allow_rotate=(rot_step != 0))

                    upper = 1.0
                    for _ in range(20):
                        pack_scale *= 0.5
                        placements, ok = scaled_pack(pack_scale)
                        if ok:
                            break
                        upper = pack_scale
                    if not ok:
                        self.report({'WARNING'}, tr(context, "msg.op_failed", e="Islands cannot fit with the requested margin"))
                        return {'CANCELLED'}
                    lower = pack_scale
                    for _ in range(10):
                        trial = (lower + upper) * 0.5
                        trial_placements, trial_ok = scaled_pack(trial)
                        if trial_ok:
                            lower, placements = trial, trial_placements
                        else:
                            upper = trial
                    pack_scale = lower
                for isl in movable:
                    pl = placements.get(isl.id)
                    if not pl:
                        continue
                    ang, dx, dy = pl["angle"], pl["dx"], pl["dy"]
                    pivot = Vector(isl.uv_centroid) * pack_scale
                    base_off = Vector((float(start_u), float(start_v)))
                    def tf(u, base_off=base_off, pivot=pivot, ang=ang, dx=dx, dy=dy, scale=pack_scale):
                        return pivot + _rotate2(Vector(u) * scale - pivot, ang) + Vector((dx, dy)) + base_off
                    _island_apply_transform(isl, uv_layer, tf)
            elif self.udim_mode == 'AUTO_TILES':
                try:
                    start_tile = min((int(math.floor(i.uv_centroid.x)), int(math.floor(i.uv_centroid.y))) for i in movable)
                except Exception:
                    start_tile = (0, 0)
                start_off = Vector((start_u + start_tile[0], start_v + start_tile[1]))
                proxies = []
                proxy_meta = []
                for i, isl in enumerate(movable):
                    orig_tile = (int(math.floor(isl.uv_centroid.x)), int(math.floor(isl.uv_centroid.y)))
                    orig_off = Vector((orig_tile[0], orig_tile[1]))
                    proxy = _Island(i)
                    proxy.uv_points = [p - orig_off for p in isl.uv_points]
                    proxy.uv_centroid = isl.uv_centroid - orig_off
                    proxy.axis = isl.axis
                    proxy.bbox_min = isl.bbox_min - orig_off
                    proxy.bbox_max = isl.bbox_max - orig_off
                    proxy.has_pin = isl.has_pin
                    proxies.append(proxy)
                    proxy_meta.append((isl, orig_off))
                placements = _pack_multi_tiles(proxies, margin_uv, rot_step, allow_rotate=(rot_step != 0))
                max_tile_index = 0
                for i, (isl, orig_off) in enumerate(proxy_meta):
                    pl = placements.get(i)
                    if not pl:
                        continue
                    ang, dx, dy = pl["angle"], pl["dx"], pl["dy"]
                    tile_index = int(pl.get("tile_index", 0))
                    max_tile_index = max(max_tile_index, tile_index)
                    tile_off = _suv_pack_tile_offset(tile_index, start_u=int(start_off.x), start_v=int(start_off.y), tile_columns=self.tile_columns, tile_fill=tile_fill)
                    pivot_local = isl.uv_centroid - orig_off
                    def tf(uuv):
                        uu = Vector(uuv) - orig_off
                        uu = pivot_local + _rotate2(uu - pivot_local, ang) + Vector((dx, dy))
                        return uu + tile_off
                    _island_apply_transform(isl, uv_layer, tf)
                tiles_used = max_tile_index + 1
            else:
                by_tile = {}
                for isl in movable:
                    c = isl.uv_centroid
                    tile = (int(math.floor(c.x)), int(math.floor(c.y)))
                    by_tile.setdefault(tile, []).append(isl)

                for tile, group in by_tile.items():
                    tile_off = Vector((tile[0], tile[1]))
                    _suv_shrink_islands_to_fit_tile(group, uv_layer, margin_uv, rot_step, rot_step != 0)
                    proxies = []
                    for i, isl in enumerate(group):
                        proxy = _Island(i)
                        proxy.uv_points = [p - tile_off for p in isl.uv_points]
                        proxy.uv_centroid = isl.uv_centroid - tile_off
                        proxy.axis = isl.axis
                        proxy.bbox_min = isl.bbox_min - tile_off
                        proxy.bbox_max = isl.bbox_max - tile_off
                        proxy.has_pin = isl.has_pin
                        proxies.append(proxy)
                    placements, ok = _pack_shelf(proxies, margin_uv, rot_step, allow_rotate=(rot_step != 0))
                    for i, isl in enumerate(group):
                        pl = placements.get(i)
                        if not pl:
                            continue
                        ang, dx, dy = pl["angle"], pl["dx"], pl["dy"]
                        pivot = Vector(isl.uv_centroid - tile_off)
                        def tf(u, pivot=pivot, ang=ang, dx=dx, dy=dy, tile_off=tile_off):
                            uu = Vector(u) - tile_off
                            uu = pivot + _rotate2(uu - pivot, ang) + Vector((dx, dy))
                            return uu + tile_off
                        _island_apply_transform(isl, uv_layer, tf)
                    if not ok:
                        fit_ok, fit_err = _suv_fit_islands_to_tile(group, uv_layer, margin_uv, tile_off)
                        if not fit_ok:
                            self.report({'WARNING'}, tr(context, "msg.op_failed", e=fit_err or f"Deterministic overflow in tile {tile}"))
                            return {'CANCELLED'}

            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)

        if self.udim_mode == 'AUTO_TILES':
            self.report({'INFO'}, tr(context, "msg.pack_pro_tiles_done", n=len(movable), t=int(tiles_used)))
        else:
            self.report({'INFO'}, tr(context, "msg.pack_pro_done", n=len(movable)))
        return {'FINISHED'}

class SUV_OT_texel_get(bpy.types.Operator):
    bl_idname = "uv.suv_texel_get"
    bl_label = 'Get Density'
    bl_description = "Measure the current texel density from the selection and store it as a reusable working value. / 現在の選択からテクセル密度を測定し、再利用できる作業値として取得します。"
    bl_options = {'UNDO'}

    scope: bpy.props.EnumProperty(
        name="Scope",
        items=[('ACTIVE', "Active", ""), ('SELECTED', "Selected", ""), ('ALL', "All", "")],
        default='SELECTED'
    )
    texture_size: bpy.props.IntProperty(name="Texture Size", default=2048, min=128)
    use_world_scale: bpy.props.BoolProperty(name="Use World Scale", default=True)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        with _TempMode(context, obj, 'EDIT'):
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.verify()
            if self.scope == 'ALL':
                faces = list(bm.faces)
                active_face = getattr(bm.faces, "active", None)
            else:
                sel_faces, _sl, active_face, _src = _selection_from_context(context, obj, bm, uv_layer)
                faces = sel_faces
            if not faces:
                self.report({'WARNING'}, tr(context, "msg.no_selection"))
                return {'CANCELLED'}
            islands = build_islands(bm, uv_layer, faces_subset=faces)
            if self.scope == 'ACTIVE' and active_face:
                isl = next((i for i in islands if active_face in i.faces), None)
                islands = [isl] if isl else islands
            weighted_sum = 0.0
            weight_total = 0.0
            vals = []
            for isl in islands:
                if not isl:
                    continue
                d = _island_density(obj, isl, uv_layer, self.texture_size, self.use_world_scale)
                if d <= 0.0:
                    continue
                if self.use_world_scale:
                    area_weight = sum(_world_face_area(obj, f) for f in isl.faces)
                else:
                    area_weight = sum(f.calc_area() for f in isl.faces)
                area_weight = max(1.0e-12, float(area_weight))
                weighted_sum += d * area_weight
                weight_total += area_weight
                vals.append(d)
            if not vals or weight_total <= 1.0e-12:
                self.report({'WARNING'}, tr(context, "msg.op_failed", e="Zero area"))
                return {'CANCELLED'}
            dmean = weighted_sum / weight_total
        _cache_set(context.scene, "last_density", float(dmean))
        self.report({'INFO'}, tr(context, "msg.texel_sampled", d=dmean))
        return {'FINISHED'}

class SUV_OT_texel_set(bpy.types.Operator):
    bl_idname = "uv.suv_texel_set"
    bl_label = 'Set Density'
    bl_description = "Apply the stored or specified texel density to the current UV selection. / 保存済みまたは指定したテクセル密度を現在のUV選択へ適用します。"
    bl_options = {'UNDO'}

    scope: bpy.props.EnumProperty(
        name="Scope",
        items=[('SELECTED', "Selected", ""), ('ALL', "All", "")],
        default='SELECTED'
    )
    target_density: bpy.props.FloatProperty(name="Target Density (px/m)", default=1024.0, min=1.0)
    texture_size: bpy.props.IntProperty(name="Texture Size", default=2048, min=128)
    use_world_scale: bpy.props.BoolProperty(name="Use World Scale", default=True)
    skip_pinned: bpy.props.BoolProperty(name="Skip Pinned", default=True)
    keep_tile: bpy.props.BoolProperty(name="Keep Tile", default=True)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        n = 0
        with _TempMode(context, obj, 'EDIT'):
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.verify()
            faces = list(bm.faces) if self.scope == 'ALL' else _selection_from_context(context, obj, bm, uv_layer)[0]
            if not faces:
                self.report({'WARNING'}, tr(context, "msg.no_selection"))
                return {'CANCELLED'}
            islands = build_islands(bm, uv_layer, faces_subset=faces)
            for isl in islands:
                if self.skip_pinned and isl.has_pin:
                    continue
                d = _island_density(obj, isl, uv_layer, self.texture_size, self.use_world_scale)
                if d <= 0.0:
                    continue
                s = float(self.target_density) / float(d)
                pivot = Vector(isl.uv_centroid)
                tile = (int(math.floor(pivot.x)), int(math.floor(pivot.y)))
                tile_off = Vector((tile[0], tile[1]))
                local_pivot = pivot - tile_off
                def tf(u):
                    uu = Vector(u)
                    if self.keep_tile:
                        uu0 = uu - tile_off
                        uu0 = local_pivot + (uu0 - local_pivot) * s
                        return uu0 + tile_off
                    return pivot + (uu - pivot) * s
                _island_apply_transform(isl, uv_layer, tf)
                n += 1
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        self.report({'INFO'}, tr(context, "msg.texel_norm_done", n=n))
        return {'FINISHED'}

class SUV_OT_texel_normalize(bpy.types.Operator):
    bl_idname = "uv.suv_texel_normalize"
    bl_label = 'Normalize Density'
    bl_description = "Normalize texel density across selected islands so different shells share a more even texture scale. / 選択アイランド間のテクセル密度を均一化し、テクスチャの見た目スケールを揃えます。"
    bl_options = {'UNDO'}

    mode: bpy.props.EnumProperty(
        name="Normalize To",
        items=[('ACTIVE', "Active", ""), ('AVERAGE', "Average", ""), ('VALUE', "Value", ""), ('UNSELECTED', "Unselected", "")],
        default='ACTIVE'
    )
    value_density: bpy.props.FloatProperty(name="Density (px/m)", default=1024.0, min=1.0)
    texture_size: bpy.props.IntProperty(name="Texture Size", default=2048, min=128)
    use_world_scale: bpy.props.BoolProperty(name="Use World Scale", default=True)
    skip_pinned: bpy.props.BoolProperty(name="Skip Pinned", default=True)
    keep_tile: bpy.props.BoolProperty(name="Keep Tile", default=True)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        n = 0
        with _TempMode(context, obj, 'EDIT'):
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.verify()
            sel_faces, _sl, active_face, _src = _selection_from_context(context, obj, bm, uv_layer)
            if not sel_faces:
                self.report({'WARNING'}, tr(context, "msg.no_selection"))
                return {'CANCELLED'}
            islands = build_islands(bm, uv_layer, faces_subset=sel_faces)
            target = None
            if self.mode == 'VALUE':
                target = float(self.value_density)
            elif self.mode == 'ACTIVE' and active_face:
                ref = next((i for i in islands if active_face in i.faces), None)
                if ref:
                    target = _island_density(obj, ref, uv_layer, self.texture_size, self.use_world_scale)
            elif self.mode == 'UNSELECTED':
                unselected_faces = [f for f in bm.faces if not f.select]
                unselected_islands = build_islands(bm, uv_layer, faces_subset=unselected_faces) if unselected_faces else []
                weighted_sum = 0.0
                weight_total = 0.0
                for isl in unselected_islands:
                    d = _island_density(obj, isl, uv_layer, self.texture_size, self.use_world_scale)
                    if d <= 0.0:
                        continue
                    if self.use_world_scale:
                        area_weight = sum(_world_face_area(obj, f) for f in isl.faces)
                    else:
                        area_weight = sum(f.calc_area() for f in isl.faces)
                    area_weight = max(1.0e-12, float(area_weight))
                    weighted_sum += d * area_weight
                    weight_total += area_weight
                if weight_total > 1.0e-12:
                    target = weighted_sum / weight_total
            if target is None:
                weighted_sum = 0.0
                weight_total = 0.0
                for isl in islands:
                    if self.skip_pinned and isl.has_pin:
                        continue
                    d = _island_density(obj, isl, uv_layer, self.texture_size, self.use_world_scale)
                    if d <= 0.0:
                        continue
                    if self.use_world_scale:
                        area_weight = sum(_world_face_area(obj, f) for f in isl.faces)
                    else:
                        area_weight = sum(f.calc_area() for f in isl.faces)
                    area_weight = max(1.0e-12, float(area_weight))
                    weighted_sum += d * area_weight
                    weight_total += area_weight
                target = (weighted_sum / weight_total) if weight_total > 1.0e-12 else float(self.value_density)
            for isl in islands:
                if self.skip_pinned and isl.has_pin:
                    continue
                d = _island_density(obj, isl, uv_layer, self.texture_size, self.use_world_scale)
                if d <= 0.0:
                    continue
                s = float(target) / float(d)
                pivot = isl.uv_centroid
                def tf(u):
                    return pivot + (Vector(u) - pivot) * s
                _island_apply_transform(isl, uv_layer, tf)
                n += 1
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        self.report({'INFO'}, tr(context, "msg.texel_norm_done", n=n))
        return {'FINISHED'}


def _orient2(a: Vector, b: Vector, c: Vector) -> float:
    return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x)

def _on_segment(a: Vector, b: Vector, p: Vector, eps=1e-9) -> bool:
    return (min(a.x, b.x) - eps <= p.x <= max(a.x, b.x) + eps) and (min(a.y, b.y) - eps <= p.y <= max(a.y, b.y) + eps)

def _seg_intersect(a1: Vector, a2: Vector, b1: Vector, b2: Vector, eps=1e-9) -> bool:
    o1 = _orient2(a1, a2, b1)
    o2 = _orient2(a1, a2, b2)
    o3 = _orient2(b1, b2, a1)
    o4 = _orient2(b1, b2, a2)

    # general case
    if (o1 * o2 < -eps) and (o3 * o4 < -eps):
        return True

    # collinear/touch cases
    if abs(o1) <= eps and _on_segment(a1, a2, b1, eps): return True
    if abs(o2) <= eps and _on_segment(a1, a2, b2, eps): return True
    if abs(o3) <= eps and _on_segment(b1, b2, a1, eps): return True
    if abs(o4) <= eps and _on_segment(b1, b2, a2, eps): return True
    return False

def _point_in_tri(p: Vector, a: Vector, b: Vector, c: Vector, eps=1e-9) -> bool:
    # Barycentric with orientations, allow boundary
    o1 = _orient2(a, b, p)
    o2 = _orient2(b, c, p)
    o3 = _orient2(c, a, p)
    has_neg = (o1 < -eps) or (o2 < -eps) or (o3 < -eps)
    has_pos = (o1 > eps) or (o2 > eps) or (o3 > eps)
    return not (has_neg and has_pos)

def _tri_bbox(a: Vector, b: Vector, c: Vector):
    return (min(a.x, b.x, c.x), min(a.y, b.y, c.y), max(a.x, b.x, c.x), max(a.y, b.y, c.y))

def _bbox_overlap(b1, b2, eps=0.0) -> bool:
    return (b1[0] <= b2[2] + eps and b1[2] + eps >= b2[0] and b1[1] <= b2[3] + eps and b1[3] + eps >= b2[1])

def _poly_area_2d(poly):
    if len(poly) < 3:
        return 0.0
    area = 0.0
    for i in range(len(poly)):
        p0 = poly[i]
        p1 = poly[(i + 1) % len(poly)]
        area += p0.x * p1.y - p1.x * p0.y
    return 0.5 * area


def _clip_polygon_half_plane(poly, edge_a: Vector, edge_b: Vector, eps=1.0e-12):
    if not poly:
        return []
    out = []
    edge = edge_b - edge_a

    def _inside(p):
        return (edge.x * (p.y - edge_a.y) - edge.y * (p.x - edge_a.x)) >= -eps

    def _intersection(p1, p2):
        d1 = edge.x * (p1.y - edge_a.y) - edge.y * (p1.x - edge_a.x)
        d2 = edge.x * (p2.y - edge_a.y) - edge.y * (p2.x - edge_a.x)
        denom = d1 - d2
        if abs(denom) <= eps:
            return Vector(p2)
        t = d1 / denom
        return p1.lerp(p2, t)

    prev = poly[-1]
    prev_inside = _inside(prev)
    for cur in poly:
        cur_inside = _inside(cur)
        if cur_inside:
            if not prev_inside:
                out.append(_intersection(prev, cur))
            out.append(cur)
        elif prev_inside:
            out.append(_intersection(prev, cur))
        prev = cur
        prev_inside = cur_inside
    return out


def _triangle_intersection_area(a: Vector, b: Vector, c: Vector, d: Vector, e: Vector, f: Vector) -> float:
    poly = [Vector(a), Vector(b), Vector(c)]
    clip = [Vector(d), Vector(e), Vector(f)]
    if _poly_area_2d(clip) < 0.0:
        clip = [clip[0], clip[2], clip[1]]
    for i in range(3):
        poly = _clip_polygon_half_plane(poly, clip[i], clip[(i + 1) % 3])
        if len(poly) < 3:
            return 0.0
    return abs(_poly_area_2d(poly))


def _tri_intersect(a: Vector, b: Vector, c: Vector, d: Vector, e: Vector, f: Vector, eps=1e-9) -> bool:
    return _triangle_intersection_area(a, b, c, d, e, f) > max(float(eps), 1.0e-12)

def _face_uv_tris(face, uv_layer):
    loops = list(face.loops)
    if len(loops) < 3:
        return []
    pts = [Vector(l[uv_layer].uv) for l in loops]
    try:
        tri_idx = _mu_geometry.tessellate_polygon([pts])
        tris = [(pts[i0], pts[i1], pts[i2]) for i0, i1, i2 in tri_idx]
        if tris:
            return tris
    except Exception:
        pass
    tris = []
    p0 = pts[0]
    for i in range(1, len(pts) - 1):
        tris.append((p0, pts[i], pts[i + 1]))
    return tris

def _islands_overlap_precise(isla: _Island, islb: _Island, uv_layer, eps=1e-9) -> bool:
    # First bbox quick reject
    if not (_bbox_overlap((isla.bbox_min.x, isla.bbox_min.y, isla.bbox_max.x, isla.bbox_max.y),
                          (islb.bbox_min.x, islb.bbox_min.y, islb.bbox_max.x, islb.bbox_max.y), eps)):
        return False
    # Build triangle lists with per-tri bbox
    ta = []
    for f in isla.faces:
        for tri in _face_uv_tris(f, uv_layer):
            bb = _tri_bbox(*tri)
            ta.append((tri, bb))
    tb = []
    for f in islb.faces:
        for tri in _face_uv_tris(f, uv_layer):
            bb = _tri_bbox(*tri)
            tb.append((tri, bb))
    for (tri1, bb1) in ta:
        for (tri2, bb2) in tb:
            if not _bbox_overlap(bb1, bb2, eps):
                continue
            if _tri_intersect(tri1[0], tri1[1], tri1[2], tri2[0], tri2[1], tri2[2], eps):
                return True
    return False


class SUV_OT_inspector_scan(bpy.types.Operator):
    bl_idname = "uv.suv_inspector_scan"
    bl_label = 'Inspector Scan'
    bl_description = "Scan selected UVs for flipped faces, zero-area faces, out-of-tile islands, overlap and stretch issues. / 選択UVを走査し、反転面、ゼロ面積、タイル外、重なり、ストレッチ問題を検出します。"
    bl_options = {'UNDO'}

    scope: bpy.props.EnumProperty(
        name="Scope",
        items=[('SELECTED', "Selected", ""), ('ALL', "All", "")],
        default='SELECTED'
    )
    eps_zero: bpy.props.FloatProperty(name="Zero UV Epsilon", default=1e-12, min=1e-16, max=1e-6)
    check_out_of_tile: bpy.props.BoolProperty(name="Check Out of Tile", default=True)
    check_overlap: bpy.props.BoolProperty(name="Check Overlap", default=True)
    precise_overlap: bpy.props.BoolProperty(name="Precise Overlap", default=True)
    check_stretch: bpy.props.BoolProperty(name="Check Stretch", default=True)
    stretch_threshold: bpy.props.FloatProperty(name="Stretch Threshold", default=1.8, min=1.01, max=100.0)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        with _TempMode(context, obj, 'EDIT'):
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.verify()
            faces = list(bm.faces) if self.scope == 'ALL' else _selection_from_context(context, obj, bm, uv_layer)[0]
            if not faces:
                self.report({'WARNING'}, tr(context, "msg.no_selection"))
                return {'CANCELLED'}
            islands = build_islands(bm, uv_layer, faces_subset=faces)
            flipped = []
            zero = []
            out = []
            overlap = []
            stretch = []
            stretch_details = []
            stretch_scores = []
            for isl in islands:
                face_areas = [_signed_uv_area(f, uv_layer) for f in isl.faces]
                neg_area = sum(abs(a) for a in face_areas if a < 0.0)
                pos_area = sum(abs(a) for a in face_areas if a > 0.0)
                mixed_ratio = (min(neg_area, pos_area) / max(1.0e-12, max(neg_area, pos_area))) if (neg_area > self.eps_zero and pos_area > self.eps_zero) else 0.0
                if neg_area > pos_area + self.eps_zero or mixed_ratio >= 0.05:
                    flipped.append(isl.face_sig)
                if any(abs(a) <= self.eps_zero for a in face_areas):
                    zero.append(isl.face_sig)
                if self.check_out_of_tile:
                    tile = (int(math.floor(isl.uv_centroid.x)), int(math.floor(isl.uv_centroid.y)))
                    off = Vector((tile[0], tile[1]))
                    bmin0 = isl.bbox_min - off
                    bmax0 = isl.bbox_max - off
                    if bmin0.x < 0.0 or bmin0.y < 0.0 or bmax0.x > 1.0 or bmax0.y > 1.0:
                        out.append(isl.face_sig)
                if self.check_stretch:
                    score, _ = _island_stretch_score(isl, obj, uv_layer)
                    stretch_scores.append(score)
                    if score >= max(1.01, float(self.stretch_threshold)):
                        stretch.append(isl.face_sig)
                        stretch_details.append(round(float(score), 4))
            if self.check_overlap:
                for i in range(len(islands)):
                    a = islands[i]
                    for j in range(i + 1, len(islands)):
                        b = islands[j]
                        if not (a.bbox_min.x <= b.bbox_max.x and a.bbox_max.x >= b.bbox_min.x and
                                a.bbox_min.y <= b.bbox_max.y and a.bbox_max.y >= b.bbox_min.y):
                            continue
                        if self.precise_overlap:
                            try:
                                if _islands_overlap_precise(a, b, uv_layer):
                                    overlap.append((a.face_sig, b.face_sig))
                            except Exception as e:
                                _debug(context, f"Precise overlap failed: {e}")
                                overlap.append((a.face_sig, b.face_sig))
                        else:
                            overlap.append((a.face_sig, b.face_sig))
            _cache_set(context.scene, "inspect_flipped", flipped)
            _cache_set(context.scene, "inspect_zero", zero)
            _cache_set(context.scene, "inspect_out", out)
            _cache_set(context.scene, "inspect_overlap", overlap)
            _cache_set(context.scene, "inspect_stretch", stretch)
            _cache_set(context.scene, "inspect_stretch_detail", stretch_details)
            worst = max(stretch_scores) if stretch_scores else 1.0
            avg = (sum(stretch_scores) / len(stretch_scores)) if stretch_scores else 1.0
            _suv_store_scan_cache(
                context,
                self.scope,
                self.eps_zero,
                self.check_out_of_tile,
                self.check_overlap,
                self.precise_overlap,
                len(flipped),
                len(zero),
                len(out),
                len(overlap),
                stretch_count=len(stretch),
                stretch_worst=worst,
                stretch_avg=avg,
            )
        self.report({'INFO'}, tr(context, "msg.inspect_summary", f=len(flipped), z=len(zero), o=len(out), p=len(overlap), s=len(stretch)))
        return {'FINISHED'}


class SUV_OT_inspector_select(bpy.types.Operator):
    bl_idname = "uv.suv_inspector_select"
    bl_label = 'Inspector Select'
    bl_description = "Select UV elements that match a specific inspector issue so you can review or repair them quickly. / 指定した問題種別に一致するUV要素を選択し、すばやく確認や修正ができるようにします。"
    bl_options = {'UNDO'}

    issue: bpy.props.EnumProperty(
        name="Issue",
        items=[('FLIPPED', 'Check Flipped', ""), ('ZERO', "Zero UV", ""), ('OUT', "Out of Tile", ""), ('OVERLAP', "Overlap", ""), ('STRETCH', "Stretch", "")],
        default='FLIPPED'
    )
    apply_mode: bpy.props.EnumProperty(
        name="Apply",
        items=[('REPLACE', "Replace", ""), ('ADD', "Add", ""), ('SUB', "Subtract", "")],
        default='REPLACE'
    )
    auto_scan: bpy.props.BoolProperty(
        name="Auto Scan",
        description="Run Inspector Scan automatically when no cached result is available, or always when enabled. / キャッシュが無いとき、または有効時は常にインスペクタスキャンを先に実行します。",
        default=False,
    )
    scan_scope: bpy.props.EnumProperty(
        name="Scan Scope",
        items=[('SELECTED', "Selected", ""), ('ALL', "All", "")],
        default='SELECTED'
    )

    def _issue_cache_empty(self, context):
        if self.issue == 'OVERLAP':
            return len(_cache_get(context.scene, 'inspect_overlap', [])) == 0
        key = f"inspect_{self.issue.lower()}"
        return len(_cache_get(context.scene, key, [])) == 0

    def _run_scan(self, context):
        ws = _suv_ws(context)
        scope = str(self.scan_scope or 'SELECTED')
        if ws and str(getattr(ws, 'scan_scope', '') or '') in {'SELECTED', 'ALL'}:
            scope = str(getattr(ws, 'scan_scope', scope) or scope)
        eps_zero = float(getattr(ws, 'scan_eps_zero', 1.0e-12) if ws else 1.0e-12)
        check_out = bool(getattr(ws, 'scan_check_out', True) if ws else True)
        check_overlap = bool(getattr(ws, 'scan_check_overlap', True) if ws else True)
        precise_overlap = bool(getattr(ws, 'scan_precise_overlap', True) if ws else True)
        stretch_threshold = float(getattr(ws, 'stretch_threshold', 1.8) if ws else 1.8)
        try:
            return bpy.ops.uv.suv_inspector_scan(
                'EXEC_DEFAULT',
                scope=scope,
                eps_zero=eps_zero,
                check_out_of_tile=check_out,
                check_overlap=check_overlap,
                precise_overlap=precise_overlap,
                check_stretch=True,
                stretch_threshold=stretch_threshold,
            )
        except Exception as e:
            _debug(context, f"Inspector auto-scan failed: {e}")
            return {'CANCELLED'}

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}

        if self.auto_scan or self._issue_cache_empty(context):
            result = self._run_scan(context)
            if _suv_result_has(result, 'CANCELLED'):
                return {'CANCELLED'}

        if self.issue == 'OVERLAP':
            pairs = _cache_get(context.scene, 'inspect_overlap', [])
            if not pairs:
                self.report({'INFO'}, tr(context, "msg.no_selection"))
                return {'FINISHED'}
            involved = set()
            for a, b in pairs:
                involved.add(tuple(a) if isinstance(a, list) else a)
                involved.add(tuple(b) if isinstance(b, list) else b)
            sigs = involved
        else:
            key = f"inspect_{self.issue.lower()}"
            sigs = _cache_get(context.scene, key, [])
            if not sigs:
                self.report({'INFO'}, tr(context, "msg.no_selection"))
                return {'FINISHED'}
        from .ui import _select_islands_from_face_sigs
        count = _select_islands_from_face_sigs(context, obj, sigs, self.apply_mode)
        if count == 0:
            self.report({'INFO'}, tr(context, "msg.no_selection"))
        return {'FINISHED'}

class SUV_OT_inspector_fix_flipped(bpy.types.Operator):
    bl_idname = "uv.suv_inspector_fix_flipped"
    bl_label = 'Fix Flipped Islands'
    bl_description = "Attempt to repair flipped UV faces detected by the inspector. / インスペクタで検出された反転UV面の修正を試みます。"
    bl_options = {'UNDO'}

    skip_pinned: bpy.props.BoolProperty(name="Skip Pinned", default=True)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        fixed = 0
        with _TempMode(context, obj, 'EDIT'):
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.verify()
            faces = [f for f in bm.faces if f.select] or list(bm.faces)
            islands = build_islands(bm, uv_layer, faces_subset=faces)
            for isl in islands:
                if self.skip_pinned and isl.has_pin:
                    continue
                if isl.signed_area < 0.0:
                    pivot = isl.uv_centroid
                    for l in isl.loops:
                        l[uv_layer].uv = _mirror_x(Vector(l[uv_layer].uv), pivot)
                    if sum(_signed_uv_area(f, uv_layer) for f in isl.faces) < 0.0:
                        for l in isl.loops:
                            l[uv_layer].uv = _mirror_y(Vector(l[uv_layer].uv), pivot)
                    fixed += 1
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        self.report({'INFO'}, tr(context, "msg.repair_done", n=fixed))
        return {'FINISHED'}

class SUV_OT_inspector_rescan(bpy.types.Operator):
    bl_idname = "uv.suv_inspector_rescan"
    bl_label = 'Rescan'
    bl_description = "Run the UV inspector again with the current options and selection scope. / 現在のオプションと選択範囲でUVインスペクタを再実行します。"
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        ws = _suv_ws(context)
        if not ws or not ws.scan_has_result:
            self.report({'WARNING'}, "No previous scan data")
            return {'CANCELLED'}
        try:
            result = bpy.ops.uv.suv_inspector_scan(
                'INVOKE_DEFAULT',
                scope=ws.scan_scope,
                eps_zero=ws.scan_eps_zero,
                check_out_of_tile=ws.scan_check_out,
                check_overlap=ws.scan_check_overlap,
                precise_overlap=ws.scan_precise_overlap,
                check_stretch=True,
                stretch_threshold=float(getattr(ws, 'stretch_threshold', 1.8) or 1.8),
            )
            _suv_log_event(context, 'INFO', 'Inspector Rescan', 'Inspector rescan invoked', {'scope': ws.scan_scope, 'result': result})
            return result
        except Exception as e:
            _suv_log_exception(context, 'Inspector Rescan', e)
            self.report({'ERROR'}, f"Rescan failed: {e}")
            return {'CANCELLED'}


class SUV_OT_inspector_clear_cache(bpy.types.Operator):
    bl_idname = "uv.suv_inspector_clear_cache"
    bl_label = 'Clear Scan Cache'
    bl_description = "Clear cached inspector results so the summary panel can be rebuilt from a fresh scan. / キャッシュされた検査結果を消去し、要約パネルを新しいスキャン結果で再構築できるようにします。"
    bl_options = {'UNDO'}

    def execute(self, context):
        from .ui import _suv_clear_scan_cache
        _suv_clear_scan_cache(context)
        _cache_set(context.scene, "inspect_flipped", [])
        _cache_set(context.scene, "inspect_zero", [])
        _cache_set(context.scene, "inspect_out", [])
        _cache_set(context.scene, "inspect_overlap", [])
        _cache_set(context.scene, "inspect_stretch", [])
        _cache_set(context.scene, "inspect_stretch_detail", [])
        self.report({'INFO'}, "Inspector cache cleared")
        return {'FINISHED'}

def _suv_json_safe_value(value):
    """Convert RNA property values, including bpy_prop_array, to JSON data."""
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, dict):
        return {str(key): _suv_json_safe_value(item) for key, item in value.items()}
    if isinstance(value, set):
        return [_suv_json_safe_value(item) for item in sorted(value, key=lambda item: str(item))]
    if isinstance(value, (list, tuple)):
        return [_suv_json_safe_value(item) for item in value]
    try:
        return [_suv_json_safe_value(item) for item in value]
    except TypeError as exc:
        raise TypeError(f'Unsupported workspace setting value: {type(value).__name__}') from exc


def _suv_workspace_settings_payload(context, *, include_tool_runtime=False, include_preferences=True):
    ws = _suv_ws(context)
    payload = {
        'format': 'uv_suite_workspace_settings',
        'version': getattr(globals().get('bl_info', {}), 'get', lambda *_: None)('version', None) if isinstance(globals().get('bl_info', None), dict) else None,
        'exported_at': _suv_now_str() if '_suv_now_str' in globals() else '',
        'workspace': {},
    }
    if ws is not None:
        annotations = {}
        try:
            cls = globals().get('SUV_PG_WorkspaceSettings')
            class_dict = type.__getattribute__(cls, '__dict__') if isinstance(cls, type) else {}
            for key, prop_def in dict(class_dict.get('__annotations__', {}) or {}).items():
                annotations.setdefault(str(key or ''), prop_def)
        except Exception:
            pass
        if not annotations:
            try:
                from . import npanel_persistence as _npanel_store
                for key in _npanel_store._iter_workspace_props(None):
                    annotations.setdefault(str(key or ''), None)
            except Exception:
                pass
        for ident, prop_def in annotations.items():
            if not ident or ident == 'rna_type':
                continue
            try:
                keywords = dict(getattr(prop_def, 'keywords', {}) or {})
            except Exception:
                keywords = {}
            try:
                options = set(keywords.get('options', set()) or set())
            except Exception:
                options = set()
            if (not include_tool_runtime) and (
                'SKIP_SAVE' in options
                or ident.startswith('scan_')
                or ident.startswith('health_')
                or ident.startswith('last_')
                or ident.startswith('batch_last_')
            ):
                continue
            try:
                value = getattr(ws, ident)
            except Exception:
                continue
            try:
                payload['workspace'][ident] = _suv_json_safe_value(value)
            except TypeError:
                continue
    if include_preferences:
        prefs = _prefs(context)
        if prefs is not None:
            pref_out = {}
            for key in (
                'ui_language_mode',
                'show_in_uv_editor',
                'show_in_3d_view',
                'enable_pro_tools',
                'enable_sets_tools',
                'enable_symmetry_tools',
                'enable_atlas_tools',
                'debug_log',
            ):
                try:
                    pref_out[key] = _suv_json_safe_value(getattr(prefs, key))
                except Exception:
                    pass
            payload['preferences'] = pref_out
    return payload


def _suv_workspace_value_matches(ws, key, value):
    def same(a, b):
        if isinstance(a, list) and isinstance(b, list):
            return len(a) == len(b) and all(same(x, y) for x, y in zip(a, b))
        if isinstance(a, float) or isinstance(b, float):
            try:
                return abs(float(a) - float(b)) <= 1.0e-5
            except (TypeError, ValueError):
                return False
        return a == b
    try:
        return same(_suv_json_safe_value(getattr(ws, key)), value)
    except Exception:
        return False


def _suv_apply_workspace_settings_payload(context, payload):
    if not isinstance(payload, dict):
        raise ValueError('Settings payload must be a JSON object')
    ws = _suv_ws(context)
    applied_ws = 0
    applied_prefs = 0
    workspace_data = payload.get('workspace', {}) or {}
    if ws is not None and isinstance(workspace_data, dict):
        written = {}
        for key, value in workspace_data.items():
            if not hasattr(ws, key):
                continue
            try:
                setattr(ws, key, value)
                applied_ws += 1
            except Exception:
                continue
            # A property that normalizes its own value cannot be restored literally.
            if _suv_workspace_value_matches(ws, key, value):
                written[key] = value
        # Preset selectors overwrite other settings from their update callbacks, so
        # write back whatever a later key changed.  Matching keys are left alone so
        # a selector does not fire its preset again.
        for _pass in range(4):
            stale = [key for key, value in written.items() if not _suv_workspace_value_matches(ws, key, value)]
            if not stale:
                break
            for key in stale:
                try:
                    setattr(ws, key, written[key])
                except Exception:
                    written.pop(key, None)
        from .ui import _suv_repair_workspace_settings
        try:
            _suv_repair_workspace_settings(ws)
        except Exception:
            pass
    pref_data = payload.get('preferences', {}) or {}
    prefs = _prefs(context)
    if prefs is not None and isinstance(pref_data, dict):
        for key, value in pref_data.items():
            if not hasattr(prefs, key):
                continue
            try:
                setattr(prefs, key, value)
                applied_prefs += 1
            except Exception:
                pass
    return applied_ws, applied_prefs


class SUV_OT_workspace_settings_io(bpy.types.Operator):
    bl_idname = "uv.suv_workspace_settings_io"
    bl_label = 'Workspace Settings I/O'
    bl_description = 'Export or import UV Suite workspace settings as JSON text or JSON files. / UV Suite のワークスペース設定を JSON テキストまたは JSON ファイルとして入出力します。'
    bl_options = {'UNDO'}

    mode: bpy.props.EnumProperty(
        name="Mode",
        items=[
            ('EXPORT_TEXT', "Export to Text", "Write current settings into a Blender Text datablock / 現在の設定を Blender のテキストデータへ書き出します"),
            ('IMPORT_TEXT', "Import from Text", "Read settings from a Blender Text datablock / Blender のテキストデータから設定を読み込みます"),
            ('EXPORT_FILE', "Export to File", "Write current settings into a JSON file / 現在の設定を JSON ファイルへ書き出します"),
            ('IMPORT_FILE', "Import from File", "Read settings from a JSON file / JSON ファイルから設定を読み込みます"),
        ],
        default='EXPORT_TEXT',
    )
    text_name: bpy.props.StringProperty(
        name="Text Name",
        description="Text datablock used for settings import/export / 設定の入出力に使うテキストデータ名",
        default="SUV_Workspace_Settings",
    )
    filepath: bpy.props.StringProperty(
        name="Filepath",
        description="JSON file used for settings import/export / 設定入出力に使う JSON ファイルパス",
        default="",
        subtype='FILE_PATH',
    )
    filter_glob: bpy.props.StringProperty(default="*.json", options={'HIDDEN'})
    include_tool_runtime: bpy.props.BoolProperty(
        name="Include Runtime State",
        description="Also include temporary scan/health state in the export / 一時的なスキャン・健全性状態も書き出しに含めます",
        default=False,
    )
    include_preferences: bpy.props.BoolProperty(
        name="Include Add-on Preferences",
        description="Include panel visibility and major add-on preference toggles / パネル表示や主要アドオン設定も含めます",
        default=True,
    )

    def invoke(self, context, event=None):
        if self.mode in {'EXPORT_FILE', 'IMPORT_FILE'}:
            if not self.filepath:
                base = os.path.splitext(bpy.path.basename(bpy.data.filepath))[0] if getattr(bpy.data, 'filepath', '') else 'uv_suite'
                suffix = 'settings_export' if self.mode == 'EXPORT_FILE' else 'settings_import'
                self.filepath = bpy.path.ensure_ext(f"{base}_{suffix}", '.json')
            context.window_manager.fileselect_add(self)
            return {'RUNNING_MODAL'}
        return self.execute(context)

    def execute(self, context):
        if self.mode.startswith('EXPORT'):
            payload = _suv_workspace_settings_payload(context, include_tool_runtime=self.include_tool_runtime, include_preferences=self.include_preferences)
            data = json.dumps(payload, indent=2, ensure_ascii=False, sort_keys=True)
            if self.mode == 'EXPORT_TEXT':
                txt = _suv_text_block(self.text_name or 'SUV_Workspace_Settings', clear=True)
                txt.write(data)
                _suv_log_event(context, 'INFO', 'Workspace Settings Export', 'Workspace settings exported to text', {'text_name': txt.name, 'include_tool_runtime': self.include_tool_runtime, 'include_preferences': self.include_preferences})
                self.report({'INFO'}, f'Workspace settings exported to text: {txt.name}')
                return {'FINISHED'}
            path = bpy.path.abspath(self.filepath) if self.filepath else ''
            if not path:
                self.report({'WARNING'}, 'No export filepath specified')
                return {'CANCELLED'}
            os.makedirs(os.path.dirname(path), exist_ok=True) if os.path.dirname(path) else None
            with open(path, 'w', encoding='utf-8') as handle:
                handle.write(data)
            _suv_log_event(context, 'INFO', 'Workspace Settings Export', 'Workspace settings exported to file', {'filepath': path, 'include_tool_runtime': self.include_tool_runtime, 'include_preferences': self.include_preferences})
            self.report({'INFO'}, f'Workspace settings exported: {path}')
            return {'FINISHED'}

        if self.mode == 'IMPORT_TEXT':
            txt = bpy.data.texts.get(self.text_name or '')
            if txt is None:
                self.report({'WARNING'}, f'Text not found: {self.text_name}')
                return {'CANCELLED'}
            raw = txt.as_string()
            source_label = txt.name
        else:
            path = bpy.path.abspath(self.filepath) if self.filepath else ''
            if not path or not os.path.isfile(path):
                self.report({'WARNING'}, f'JSON file not found: {path or self.filepath}')
                return {'CANCELLED'}
            with open(path, 'r', encoding='utf-8') as handle:
                raw = handle.read()
            source_label = path
        payload = json.loads(raw)
        applied_ws, applied_prefs = _suv_apply_workspace_settings_payload(context, payload)
        _suv_log_event(context, 'INFO', 'Workspace Settings Import', 'Workspace settings imported', {'source': source_label, 'workspace_values': applied_ws, 'preference_values': applied_prefs})
        self.report({'INFO'}, f'Imported settings from {source_label} (workspace={applied_ws}, prefs={applied_prefs})')
        return {'FINISHED'}


class SUV_OT_uv_sync_mode_toggle(bpy.types.Operator):
    bl_idname = "uv.suv_uv_sync_mode_toggle"
    bl_label = 'UV Sync Selection'
    bl_description = 'Toggle Blender UV Sync Selection without leaving UV Suite. / UV Suite 内から Blender の UV同期選択 を切り替えます。'
    bl_options = {'UNDO'}

    mode: bpy.props.EnumProperty(
        name="Mode",
        items=[
            ('TOGGLE', "Toggle", "Toggle the current UV sync state / 現在の UV 同期状態を反転します"),
            ('ON', "On", "Enable UV sync selection / UV同期選択を有効化します"),
            ('OFF', "Off", "Disable UV sync selection / UV同期選択を無効化します"),
        ],
        default='TOGGLE',
    )

    def execute(self, context):
        tool_settings = getattr(context.scene, 'tool_settings', None)
        if tool_settings is None or not hasattr(tool_settings, 'use_uv_select_sync'):
            self.report({'WARNING'}, 'UV sync selection is unavailable in this context')
            return {'CANCELLED'}
        current = bool(getattr(tool_settings, 'use_uv_select_sync', False))
        if self.mode == 'ON':
            target = True
        elif self.mode == 'OFF':
            target = False
        else:
            target = not current
        tool_settings.use_uv_select_sync = target
        _suv_log_event(context, 'INFO', 'UV Sync Selection', 'UV sync selection changed', {'previous': current, 'current': target, 'mode': self.mode})
        self.report({'INFO'}, f'UV Sync Selection: {"ON" if target else "OFF"}')
        return {'FINISHED'}


class SUV_OT_workspace_reset(bpy.types.Operator):
    bl_idname = "uv.suv_workspace_reset"
    bl_label = 'Reset Workspace'
    bl_description = 'Reset the UV Suite workspace settings back to a safe default starting point. / UV Suite のワークスペース設定を安全な初期状態へ戻します。'
    bl_options = {'UNDO'}

    def execute(self, context):
        from .ui import _suv_reset_workspace
        _suv_reset_workspace(context)
        _cache_set(context.scene, "inspect_flipped", [])
        _cache_set(context.scene, "inspect_zero", [])
        _cache_set(context.scene, "inspect_out", [])
        _cache_set(context.scene, "inspect_overlap", [])
        _suv_log_event(context, 'INFO', 'Reset Workspace', 'Workspace settings reset to safe defaults')
        self.report({'INFO'}, "Workspace reset")
        return {'FINISHED'}



class SUV_OT_workspace_validate(bpy.types.Operator):
    bl_idname = "uv.suv_workspace_validate"
    bl_label = 'Validate Workspace'
    bl_description = 'Run a UV Suite health check for workspace settings, icons and selected mesh UV readiness. / ワークスペース設定、アイコン、選択メッシュのUV準備状態をチェックします。'
    bl_options = {'UNDO'}

    def execute(self, context):
        from .ui import _suv_repair_workspace_settings, _suv_validate_workspace_state, _suv_write_validation_report, _suv_write_workspace_snapshot
        ws = _suv_ws(context)
        if ws:
            _suv_repair_workspace_settings(ws)
        data = _suv_validate_workspace_state(context)
        report_txt = _suv_write_validation_report(context, data)
        snap = _suv_write_workspace_snapshot(context)
        _suv_log_event(context, 'INFO' if data['issue_count'] == 0 else 'WARN', 'Validate Workspace', data['message'], {'status': data['status'], 'issues': data['issue_count'], 'snapshot': snap.name, 'validation_report': report_txt.name})
        self.report({'INFO'}, tr(context, 'msg.workspace_validate', status=data['status'], issues=data['issue_count']))
        return {'FINISHED'}


class SUV_OT_workspace_auto_repair(bpy.types.Operator):
    bl_idname = "uv.suv_workspace_auto_repair"
    bl_label = 'Auto Repair Workspace'
    bl_description = 'Repair common UV Suite setup issues such as missing UV maps, stale cache values and unloaded custom icons. / UV未作成、古いキャッシュ、未読込アイコンなどの代表的なセットアップ問題を自動修復します。'
    bl_options = {'UNDO'}

    create_missing_uv: bpy.props.BoolProperty(name="Create Missing UV", default=True)
    clear_scan_cache: bpy.props.BoolProperty(name="Clear Scan Cache", default=True)
    reload_icons: bpy.props.BoolProperty(name="Reload Icons", default=True)
    repair_settings: bpy.props.BoolProperty(name="Repair Settings", default=True)

    def execute(self, context):
        from .ui import _suv_clear_scan_cache, _suv_loaded_icon_count, _suv_reload_icons, _suv_repair_workspace_settings, _suv_validate_workspace_state
        ws = _suv_ws(context)
        if self.repair_settings and ws:
            _suv_repair_workspace_settings(ws)
        created = _suv_ensure_uv_maps_selected(context, getattr(ws, 'uv_new_name', 'UVMap_SUV') if ws else 'UVMap_SUV') if self.create_missing_uv else []
        if self.clear_scan_cache:
            _suv_clear_scan_cache(context)
            _cache_set(context.scene, 'inspect_flipped', [])
            _cache_set(context.scene, 'inspect_zero', [])
            _cache_set(context.scene, 'inspect_out', [])
            _cache_set(context.scene, 'inspect_overlap', [])
            _cache_set(context.scene, 'inspect_stretch', [])
            _cache_set(context.scene, 'inspect_stretch_detail', [])
        icon_count = _suv_reload_icons() if self.reload_icons else _suv_loaded_icon_count()
        data = _suv_validate_workspace_state(context)
        _suv_log_event(context, 'INFO', 'Auto Repair Workspace', 'Workspace repair completed', {'created_uv_maps': len(created), 'created_objects': ', '.join(created) if created else '-', 'cache_reset': self.clear_scan_cache, 'icons_reloaded': icon_count if self.reload_icons else 0, 'status_after': data.get('status', 'Unknown')})
        self.report({'INFO'}, tr(context, 'msg.workspace_repair', uvs=len(created), cache='Yes' if self.clear_scan_cache else 'No', icons=icon_count if self.reload_icons else 0))
        return {'FINISHED'}


class SUV_OT_reload_custom_icons(bpy.types.Operator):
    bl_idname = "uv.suv_reload_custom_icons"
    bl_label = 'Reload Icons'
    bl_description = 'Reload the UV Suite custom icon set after reinstalling or replacing icon files. / 再インストールや差し替え後に UV Suite のカスタムアイコンを再読込します。'
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        from .ui import _suv_reload_icons, _suv_validate_workspace_state
        count = _suv_reload_icons()
        data = _suv_validate_workspace_state(context)
        _suv_log_event(context, 'INFO', 'Reload Icons', 'Custom icons reloaded', {'count': count, 'status_after': data.get('status', 'Unknown')})
        self.report({'INFO'}, tr(context, 'msg.icons_reloaded', count=count))
        return {'FINISHED'}


class SUV_OT_write_tool_runtime_snapshot(bpy.types.Operator):
    bl_idname = "uv.suv_write_tool_runtime_snapshot"
    bl_label = 'Write Snapshot'
    bl_description = 'Write a detailed UV Suite workspace snapshot into a Blender Text datablock for debugging and support logs. / デバッグやサポート用に、UV Suite の詳細な状態スナップショットを Blender テキストへ書き出します。'
    bl_options = set()

    def execute(self, context):
        from .ui import _suv_write_workspace_snapshot
        txt = _suv_write_workspace_snapshot(context)
        _suv_log_event(context, 'INFO', 'Write Snapshot', f'Workspace snapshot written: {txt.name}')
        self.report({'INFO'}, tr(context, 'msg.snapshot_written', name=txt.name))
        return {'FINISHED'}


class SUV_OT_clear_tool_runtime_log(bpy.types.Operator):
    bl_idname = "uv.suv_clear_tool_runtime_log"
    bl_label = 'Clear Runtime Log'
    bl_description = 'Clear the UV Suite tool_runtime log text datablock so a new debugging session starts cleanly. / UV Suite の実行ログテキストを消去して、新しいデバッグ記録をきれいな状態から始めます。'
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        name = _suv_tool_runtime_log_name(context)
        _suv_text_block(name, clear=True)
        ws = _suv_ws(context)
        if ws is not None:
            ws.health_last_error = ''
        self.report({'INFO'}, tr(context, 'msg.tool_runtime_log_cleared', name=name))
        return {'FINISHED'}


class SUV_OT_clear_batch_report(bpy.types.Operator):
    bl_idname = "uv.suv_clear_batch_report"
    bl_label = 'Clear Batch Report'
    bl_description = "Clear the multi-step batch report text datablock and reset the last batch summary. / 複数ステップ処理のバッチレポートをクリアし、最後の要約もリセットします。"
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        name = _suv_batch_report_name(context)
        _suv_text_block(name, clear=True)
        ws = _suv_ws(context)
        if ws is not None:
            ws.batch_last_summary = ''
        self.report({'INFO'}, tr(context, 'msg.batch_report_cleared', name=name))
        return {'FINISHED'}


class SUV_OT_open_diagnostics_text(bpy.types.Operator):
    bl_idname = "uv.suv_open_diagnostics_text"
    bl_label = 'Open Diagnostics Text'
    bl_description = "Open one of the UV Suite diagnostics text datablocks in Blender's Text Editor. / UV Suite の診断用テキストデータを Blender のテキストエディタで開きます。"
    bl_options = set()

    target: bpy.props.EnumProperty(
        items=[
            ('RUNTIME', "Runtime", "Open the tool_runtime log / 実行ログを開きます"),
            ('BATCH', "Batch", "Open the batch report / バッチレポートを開きます"),
            ('SCAN', "Scan", "Open the scan report / 検査レポートを開きます"),
            ('SNAPSHOT', "Snapshot", "Open the last snapshot / 最後のスナップショットを開きます"),
            ('SUPPORT', "Support", "Open the support bundle / サポートバンドルを開きます"),
            ('VALIDATION', "Validation", "Open the validation report / 検証レポートを開きます"),
        ],
        default='RUNTIME'
    )

    def execute(self, context):
        from .ui import _suv_open_text_in_editor
        ws = _suv_ws(context)
        name = ''
        create_if_missing = False
        if self.target == 'RUNTIME':
            name = _suv_tool_runtime_log_name(context)
            create_if_missing = True
        elif self.target == 'BATCH':
            name = _suv_batch_report_name(context)
            create_if_missing = True
        elif self.target == 'SCAN':
            name = _suv_scan_report_name(context)
        elif self.target == 'SNAPSHOT':
            name = getattr(ws, 'last_snapshot_name', '') if ws else ''
        elif self.target == 'SUPPORT':
            name = _suv_support_bundle_name(context)
        elif self.target == 'VALIDATION':
            name = _suv_validation_report_name(context)
        txt = bpy.data.texts.get(name) if name else None
        if txt is None and create_if_missing and name:
            txt = _suv_text_block(name, clear=False)
        if txt is None:
            self.report({'WARNING'}, tr(context, 'msg.report_missing', name=name or self.target))
            return {'CANCELLED'}
        ok, detail = _suv_open_text_in_editor(context, txt)
        if not ok:
            self.report({'WARNING'}, detail or tr(context, 'msg.report_missing', name=name))
            return {'CANCELLED'}
        _suv_log_event(context, 'INFO', 'Open Diagnostics Text', f'Opened text datablock: {txt.name}', {'target': self.target})
        self.report({'INFO'}, tr(context, 'msg.text_opened', name=txt.name))
        return {'FINISHED'}


class SUV_OT_write_support_bundle(bpy.types.Operator):
    bl_idname = "uv.suv_write_support_bundle"
    bl_label = 'Write Support Bundle'
    bl_description = 'Write a one-file support bundle that summarizes the latest UV Suite diagnostics, log tails, and snapshot tail. / UV Suite の最新診断結果、ログ末尾、スナップショット末尾を1つにまとめたサポートバンドルを出力します。'
    bl_options = set()

    def execute(self, context):
        from .ui import _suv_create_support_bundle
        txt = _suv_create_support_bundle(context)
        _suv_log_event(context, 'INFO', 'Write Support Bundle', f'Support bundle written: {txt.name}')
        self.report({'INFO'}, tr(context, 'msg.support_bundle_written', name=txt.name))
        return {'FINISHED'}


class SUV_OT_copy_diagnostics_text(bpy.types.Operator):
    bl_idname = "uv.suv_copy_diagnostics_text"
    bl_label = 'Copy Diagnostics Text'
    bl_description = 'Copy one of the UV Suite diagnostics text datablocks to the system clipboard. / UV Suite の診断テキストをシステムクリップボードへコピーします。'
    bl_options = set()

    target: bpy.props.EnumProperty(
        items=[
            ('RUNTIME', "Runtime", "Copy the tool_runtime log / 実行ログをコピーします"),
            ('BATCH', "Batch", "Copy the batch report / バッチレポートをコピーします"),
            ('SCAN', "Scan", "Copy the scan report / 検査レポートをコピーします"),
            ('SNAPSHOT', "Snapshot", "Copy the last snapshot / 最後のスナップショットをコピーします"),
            ('SUPPORT', "Support", "Copy the support bundle / サポートバンドルをコピーします"),
            ('VALIDATION', "Validation", "Copy the validation report / 検証レポートをコピーします"),
        ],
        default='SUPPORT'
    )

    def execute(self, context):
        ws = _suv_ws(context)
        name = ''
        if self.target == 'RUNTIME':
            name = _suv_tool_runtime_log_name(context)
        elif self.target == 'BATCH':
            name = _suv_batch_report_name(context)
        elif self.target == 'SCAN':
            name = _suv_scan_report_name(context)
        elif self.target == 'SNAPSHOT':
            name = getattr(ws, 'last_snapshot_name', '') if ws else ''
        elif self.target == 'SUPPORT':
            name = _suv_support_bundle_name(context)
        elif self.target == 'VALIDATION':
            name = _suv_validation_report_name(context)
        txt = bpy.data.texts.get(name) if name else None
        if txt is None:
            self.report({'WARNING'}, tr(context, 'msg.report_missing', name=name or self.target))
            return {'CANCELLED'}
        try:
            context.window_manager.clipboard = txt.as_string()
        except Exception as exc:
            _suv_log_exception(context, 'Copy Diagnostics Text', exc, {'target': self.target, 'text': getattr(txt, 'name', '-')})
            self.report({'ERROR'}, tr(context, 'msg.op_failed', e=exc))
            return {'CANCELLED'}
        _suv_log_event(context, 'INFO', 'Copy Diagnostics Text', f'Copied text datablock: {txt.name}', {'target': self.target})
        self.report({'INFO'}, tr(context, 'msg.text_copied', name=txt.name))
        return {'FINISHED'}


class SUV_OT_collect_support_bundle(bpy.types.Operator):
    bl_idname = "uv.suv_collect_support_bundle"
    bl_label = 'Collect Diagnostics'
    bl_description = "Run validation, write a fresh snapshot, build a support bundle, and open the bundle for quick sharing. / 検証、最新スナップショット出力、サポートバンドル生成を順に実行し、共有しやすい状態へまとめます。"
    bl_options = set()

    open_after: bpy.props.BoolProperty(name="Open After", default=True)
    copy_bundle: bpy.props.BoolProperty(name="Copy Bundle", default=False)

    def execute(self, context):
        from .flow import _suv_write_scan_report
        from .ui import _suv_validate_workspace_state, _suv_write_validation_report, _suv_write_workspace_snapshot, _suv_create_support_bundle, _suv_open_text_in_editor
        data = _suv_validate_workspace_state(context)
        validation_txt = _suv_write_validation_report(context, data)
        scan_txt = _suv_write_scan_report(context)
        snapshot_txt = _suv_write_workspace_snapshot(context)
        bundle_txt = _suv_create_support_bundle(context)
        details = {
            'status': data.get('status', 'Unknown'),
            'issues': data.get('issue_count', 0),
            'validation_report': getattr(validation_txt, 'name', '-'),
            'scan_report': getattr(scan_txt, 'name', '-'),
            'snapshot': getattr(snapshot_txt, 'name', '-'),
            'bundle': getattr(bundle_txt, 'name', '-'),
        }
        if self.copy_bundle:
            try:
                context.window_manager.clipboard = bundle_txt.as_string()
                details['copied'] = True
            except Exception as exc:
                details['copied'] = False
                details['copy_error'] = str(exc)
        if self.open_after:
            _suv_open_text_in_editor(context, bundle_txt)
        _suv_log_event(context, 'INFO' if data.get('issue_count', 0) == 0 else 'WARN', 'Collect Diagnostics', 'Collected diagnostics bundle', details)
        self.report({'INFO'}, tr(context, 'msg.collect_bundle_done', bundle=getattr(bundle_txt, 'name', '-')))
        return {'FINISHED'}


class SUV_OT_clear_all_reports(bpy.types.Operator):
    bl_idname = "uv.suv_clear_all_reports"
    bl_label = 'Clear All Reports'
    bl_description = "Clear the tool_runtime, batch, scan, validation, and support texts together so the next test starts cleanly. / 実行ログ、バッチ、検査、検証、サポートの各レポートをまとめてクリアして、次の検証をきれいな状態から始めます。"
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        names = [_suv_tool_runtime_log_name(context), _suv_batch_report_name(context), _suv_scan_report_name(context), _suv_support_bundle_name(context), _suv_validation_report_name(context)]
        ws = _suv_ws(context)
        if ws is not None and getattr(ws, 'last_snapshot_name', ''):
            names.append(ws.last_snapshot_name)
        for name in dict.fromkeys([n for n in names if n]):
            _suv_text_block(name, clear=True)
        if ws is not None:
            ws.batch_last_summary = ''
            ws.health_last_error = ''
            ws.last_snapshot_name = ''
        _suv_log_event(context, 'INFO', 'Clear All Reports', 'Cleared diagnostics reports', {'count': len(names)})
        self.report({'INFO'}, tr(context, 'msg.all_reports_cleared'))
        return {'FINISHED'}


class SUV_OT_apply_workflow_preset(bpy.types.Operator):
    bl_idname = "uv.suv_apply_workflow_preset"
    bl_label = 'Apply Workflow Preset'
    bl_description = 'Apply a ready-made workflow preset that adjusts multiple UV Suite settings at once. / 複数の設定をまとめて切り替えるワークフロープリセットを適用します。'
    bl_options = {'UNDO'}

    preset: bpy.props.EnumProperty(items=[('UNWRAP', 'Unfold Trim', ""), ('ALIGN', "Align", ""), ('LAYOUT', 'Layout Panel', ""), ('REPAIR', "Repair", "")], default='UNWRAP')

    def execute(self, context):
        from .ui import _suv_apply_workflow_preset
        _suv_apply_workflow_preset(context, self.preset)
        self.report({'INFO'}, f"Workflow preset: {self.preset}")
        return {'FINISHED'}


class SUV_OT_apply_display_preset(bpy.types.Operator):
    bl_idname = "uv.suv_apply_display_preset"
    bl_label = 'Apply Display Preset'
    bl_description = "Apply a display preset that changes how the workspace exposes controls and UI density. / ワークスペースの表示方法やUI密度をまとめて切り替える表示プリセットを適用します。"
    bl_options = {'UNDO'}

    preset: bpy.props.EnumProperty(items=[('BASIC', "Basic", ""), ('ALIGN', "Align", ""), ('LAYOUT', 'Layout Panel', ""), ('INSPECT', 'Batch Inspect', ""), ('ALL', "All", "")], default='BASIC')

    def execute(self, context):
        from .ui import _suv_apply_display_preset
        _suv_apply_display_preset(context, self.preset)
        self.report({'INFO'}, f"Display preset: {self.preset}")
        return {'FINISHED'}


class SUV_OT_apply_line_flow_preset(bpy.types.Operator):
    bl_idname = "uv.suv_apply_line_flow_preset"
    bl_label = 'Apply Line / Flow Preset'
    bl_description = "Load a line or flow preset for straightening and edge-flow oriented UV cleanup. / 直線化やエッジフロー重視のUV整形に向けたライン／フロープリセットを読み込みます。"
    bl_options = {'UNDO'}

    preset: bpy.props.EnumProperty(items=[('STRAIGHT', "Straight", ""), ('SAFE_FLOW', "Safe Flow", ""), ('FLOW', "Flow", ""), ('ANNOTATE', "Annotate", "")], default='STRAIGHT')

    def execute(self, context):
        from .ui import _suv_apply_line_flow_preset
        _suv_apply_line_flow_preset(context, self.preset)
        self.report({'INFO'}, f"Line/Flow preset: {self.preset}")
        return {'FINISHED'}


class SUV_OT_apply_layout_preset(bpy.types.Operator):
    bl_idname = "uv.suv_apply_layout_preset"
    bl_label = 'Apply Layout Preset'
    bl_description = "Apply a layout preset that prepares pack, padding and arrangement settings for common tasks. / よく使う用途向けに、パックや余白、配置の設定をまとめて整えるレイアウトプリセットを適用します。"
    bl_options = {'UNDO'}

    preset: bpy.props.EnumProperty(items=[('PACK', "Pack", ""), ('ROW', "Row", ""), ('BLOCK', "Block", ""), ('TIDY', "Tidy", "")], default='PACK')

    def execute(self, context):
        from .ui import _suv_apply_layout_preset
        _suv_apply_layout_preset(context, self.preset)
        self.report({'INFO'}, f"Layout preset: {self.preset}")
        return {'FINISHED'}


class SUV_OT_fix_all_issues(bpy.types.Operator):
    bl_idname = "uv.suv_fix_all_issues"
    bl_label = 'Fix All Issues'
    bl_description = "Run the suite's common automatic repairs in sequence to clean the current UV selection. / ツールセットの代表的な自動修正を順番に実行し、現在のUV選択をまとめて整えます。"
    bl_options = {'UNDO'}

    def execute(self, context):
        report = _suv_batch_begin(context, 'Fix All Issues', details={'scope': 'CURRENT_SELECTION'})
        _suv_batch_step(context, report, 'Inspector Fix Flipped', lambda: bpy.ops.uv.suv_inspector_fix_flipped('EXEC_DEFAULT'))
        if _suv_batch_should_stop(context, report):
            _suv_batch_note(context, report, 'WARN', 'Batch Policy', 'Stopped remaining steps because batch policy requested an early stop', {'policy': _suv_batch_error_policy(context)})
            return _suv_batch_finish(context, report, operator=self)
        _suv_batch_step(context, report, 'Inspector Rescan', lambda: bpy.ops.uv.suv_inspector_rescan('EXEC_DEFAULT'))
        return _suv_batch_finish(context, report, operator=self)


class SUV_OT_auto_unwrap_pro(bpy.types.Operator):
    bl_idname = "uv.suv_auto_unwrap_pro"
    bl_label = 'Auto Unwrap Pro'
    bl_description = "Unwrap the current mesh with the suite's higher-level automatic unwrap workflow. / ツールセットの上位ワークフローを使って現在のメッシュを自動展開します。"
    bl_options = {'UNDO'}

    angle_threshold: bpy.props.FloatProperty(
        name="Angle Threshold",
        default=math.radians(60.0),
        min=0.0,
        max=math.pi,
        subtype='ANGLE',
    )
    do_seams: bpy.props.BoolProperty(name="Seam Suggest", default=True)
    do_unwrap: bpy.props.BoolProperty(name='Unfold Trim', default=True)
    do_relax: bpy.props.BoolProperty(name="Relax", default=True)
    do_pack: bpy.props.BoolProperty(name="Pack Pro", default=False)
    do_qa: bpy.props.BoolProperty(name="Inspector Scan", default=True)

    pack_engine: bpy.props.EnumProperty(
        name="Pack Engine",
        items=[('DETERMINISTIC', "Deterministic", ""), ('NATIVE', "Native", "")],
        default='NATIVE'
    )
    pack_udim_mode: bpy.props.EnumProperty(
        name="UDIM Mode",
        items=[('SINGLE', "Single", ""), ('KEEP_TILES', "Keep Tiles", "")],
        default='SINGLE'
    )
    pack_margin_px: bpy.props.IntProperty(name="Pack Margin (px)", default=8, min=0)
    texture_size: bpy.props.IntProperty(name="Texture Size", default=2048, min=128)
    pack_rotation_step: bpy.props.EnumProperty(
        name="Rotation Step",
        items=[('0', "0°", ""), ('90', "90°", ""), ('45', "45°", ""), ('15', "15°", "")],
        default='15'
    )

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}

        report = _suv_batch_begin(context, 'Auto Unwrap Pro', details={
            'object': getattr(obj, 'name', '-'),
            'do_seams': self.do_seams,
            'do_unwrap': self.do_unwrap,
            'do_relax': self.do_relax,
            'do_pack': self.do_pack,
            'do_qa': self.do_qa,
        })

        with _TempMode(context, obj, 'EDIT'):
            bm = bmesh.from_edit_mesh(obj.data)
            sel_faces = [f for f in bm.faces if f.select]
            if not sel_faces:
                _suv_batch_note(context, report, 'ERROR', 'Selection Check', 'No selected faces available for unwrap', {'object': getattr(obj, 'name', '-')})
                self.report({'WARNING'}, tr(context, "msg.no_selection"))
                return _suv_batch_finish(context, report, operator=self)

        if self.do_seams:
            def _step_seams():
                with _TempMode(context, obj, 'EDIT'):
                    bm = bmesh.from_edit_mesh(obj.data)
                    uv_layer = bm.loops.layers.uv.verify()
                    sel_faces, _sel_loops, _active_face, _src = _selection_from_context(context, obj, bm, uv_layer)
                    changed = _suv_mark_smart_seams(bm, self.angle_threshold, faces_subset=sel_faces or None)
                    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
                    return {'FINISHED'} if changed >= 0 else {'CANCELLED'}
            _suv_batch_step(context, report, 'Seam Suggest', _step_seams, details={'angle_threshold': self.angle_threshold})
            if _suv_batch_should_stop(context, report):
                return _suv_batch_finish(context, report, operator=self)

        if self.do_unwrap:
            _suv_batch_step(
                context,
                report,
                'Unfold Trim',
                lambda: _suv_run_unwrap_native(context, method='MINIMUM_STRETCH', margin=0.001, fill_holes=True, correct_aspect=True, use_subsurf_data=True, margin_method='SCALED'),
                fatal=False,
                details={'method': 'MINIMUM_STRETCH', 'margin': 0.001, 'fill_holes': True, 'correct_aspect': True, 'use_subsurf_data': True},
            )
            if _suv_batch_should_stop(context, report):
                return _suv_batch_finish(context, report, operator=self)

        if self.do_relax:
            def _step_relax():
                with _TempMode(context, obj, 'EDIT'):
                    bm = bmesh.from_edit_mesh(obj.data)
                    uv_layer = bm.loops.layers.uv.verify()
                    relax_faces, _sel_loops, _active_face, _src = _selection_from_context(context, obj, bm, uv_layer)
                    relax_faces = relax_faces or [f for f in bm.faces if f.select]
                    if not relax_faces:
                        return {'CANCELLED'}
                ok, err = _suv_relax_selection_preserve(context, obj, relax_faces, iterations=160, preserve_area=True, preserve_position=True)
                return {'FINISHED'} if ok else {'CANCELLED'}
            _suv_batch_step(
                context,
                report,
                'Relax',
                _step_relax,
                details={'iterations': 160, 'fill_holes': True, 'preserve_area': True, 'preserve_position': True},
            )
            if _suv_batch_should_stop(context, report):
                return _suv_batch_finish(context, report, operator=self)

        if self.do_unwrap:
            _suv_batch_step(
                context,
                report,
                'Final Auto Pack',
                lambda: bpy.ops.smart_uv_suite.unified_auto_pack(
                    'EXEC_DEFAULT',
                    use_panel_settings=False,
                    mode='PACK_STANDARD',
                ),
                fatal=False,
                details={'mode': 'PACK_STANDARD', 'scope': 'STRICT_UV_FACE_SELECTION'},
            )
            if _suv_batch_should_stop(context, report):
                return _suv_batch_finish(context, report, operator=self)

        if self.do_pack:
            _suv_batch_step(
                context,
                report,
                'Pack Pro',
                lambda: bpy.ops.uv.suv_pack_pro(
                    'EXEC_DEFAULT',
                    engine=self.pack_engine,
                    scope='SELECTED',
                    udim_mode=self.pack_udim_mode,
                    margin_px=self.pack_margin_px,
                    texture_size=self.texture_size,
                    rotation_step=self.pack_rotation_step,
                    lock_pinned=True,
                ),
                details={
                    'engine': self.pack_engine,
                    'udim_mode': self.pack_udim_mode,
                    'margin_px': self.pack_margin_px,
                    'texture_size': self.texture_size,
                    'rotation_step': self.pack_rotation_step,
                },
            )
            if _suv_batch_should_stop(context, report):
                return _suv_batch_finish(context, report, operator=self)

        if self.do_qa:
            _suv_batch_step(
                context,
                report,
                'Inspector Scan',
                lambda: bpy.ops.uv.suv_inspector_scan('EXEC_DEFAULT', scope='SELECTED'),
                details={'scope': 'SELECTED'},
            )
            if _suv_batch_should_stop(context, report):
                return _suv_batch_finish(context, report, operator=self)

        if report.get('error', 0) == 0 and report.get('warn', 0) == 0:
            self.report({'INFO'}, tr(context, "msg.auto_done"))
        return _suv_batch_finish(context, report, operator=self)
