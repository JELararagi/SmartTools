# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (c) 2026 JELararagi
"""Strict selected-edge/selected-face grouping for vertex direction align.

This late patch fixes the grouped vertex align buttons (G—, G|, G↔, G↕).
In UV edge or face selection modes, groups are built only from actually selected
UV edges/faces, never from merely adjacent selected vertices or unrelated visible
UV edges. 3D mesh topology is not used for connectivity.
"""

from __future__ import annotations

from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

_EPS_DIGITS = 7
_PREVIOUS_EXECUTE_ATTR = "_suv_1873_previous_execute"


def _uv_mode(g: Dict[str, Any], context: Any) -> str:
    fn = g.get("_sus_1655_uv_mode") or g.get("_sus_uv_select_mode")
    if callable(fn):
        try:
            mode = str(fn(context) or "VERTEX").upper()
            if mode:
                return mode
        except Exception:
            pass
    try:
        mode = str(context.tool_settings.uv_select_mode or "VERTEX").upper()
        return mode
    except Exception:
        return "VERTEX"


def _sticky_mode(g: Dict[str, Any], context: Any) -> str:
    fn = g.get("_sus_uv_sticky_select_mode")
    if callable(fn):
        try:
            return str(fn(context) or "DISABLED").upper()
        except Exception:
            pass
    try:
        return str(getattr(context.scene.suv_workspace, "uv_sticky_select_mode", "DISABLED") or "DISABLED").upper()
    except Exception:
        return "DISABLED"


def _edit_objects(context: Any) -> List[Any]:
    objs: List[Any] = []
    try:
        objs = [o for o in (getattr(context, "objects_in_mode_unique_data", None) or []) if getattr(o, "type", None) == "MESH" and getattr(o, "mode", None) == "EDIT"]
    except Exception:
        objs = []
    if not objs:
        try:
            obj = getattr(context, "edit_object", None) or getattr(context, "active_object", None)
            if obj is not None and getattr(obj, "type", None) == "MESH" and getattr(obj, "mode", None) == "EDIT":
                objs = [obj]
        except Exception:
            pass
    seen = set(); out = []
    for obj in objs:
        try:
            key = id(getattr(obj, "data", obj))
        except Exception:
            key = id(obj)
        if key in seen:
            continue
        seen.add(key); out.append(obj)
    return out


def _obj_key(g: Dict[str, Any], obj: Any) -> str:
    fn = g.get("_sus_1655_obj_key")
    if callable(fn):
        try:
            return str(fn(obj))
        except Exception:
            pass
    return str(id(obj))


def _attr_values(g: Dict[str, Any], mesh: Any, name: str) -> List[Any]:
    fn = g.get("_sus_1655_attr_values")
    if callable(fn):
        try:
            return list(fn(mesh, name) or [])
        except Exception:
            pass
    try:
        attr = mesh.attributes.get(name)
        if attr is None:
            return []
        vals = []
        for item in attr.data:
            vals.append(getattr(item, "value", False))
        return vals
    except Exception:
        return []


def _uv_key(loop: Any, uv_layer: Any) -> Optional[Tuple[float, float]]:
    try:
        uv = loop[uv_layer].uv
        return (round(float(uv.x), _EPS_DIGITS), round(float(uv.y), _EPS_DIGITS))
    except Exception:
        return None


def _edge_pair_key(loop: Any, uv_layer: Any) -> Optional[Tuple[Tuple[float, float], Tuple[float, float]]]:
    try:
        a = _uv_key(loop, uv_layer)
        b = _uv_key(loop.link_loop_next, uv_layer)
        if a is None or b is None:
            return None
        return tuple(sorted((a, b)))  # type: ignore[return-value]
    except Exception:
        return None


def _uv_xy(loop: Any, uv_layer: Any) -> Tuple[float, float]:
    try:
        uv = loop[uv_layer].uv
        return float(uv.x), float(uv.y)
    except Exception:
        return 0.0, 0.0


def _is_edge_selected(g: Dict[str, Any], loop: Any, uv_layer: Any, edge_attr: Sequence[Any], mesh_edge_attr: Sequence[Any], allow_mesh_fallback: bool) -> bool:
    try:
        if bool(getattr(loop, "uv_select_edge", False)):
            return True
    except Exception:
        pass
    try:
        if bool(getattr(loop[uv_layer], "select_edge", False)):
            return True
    except Exception:
        pass
    try:
        li = int(getattr(loop, "index", -1))
        if 0 <= li < len(edge_attr) and bool(edge_attr[li]):
            return True
    except Exception:
        pass
    if allow_mesh_fallback:
        try:
            ei = int(getattr(loop.edge, "index", -1))
            if 0 <= ei < len(mesh_edge_attr) and bool(mesh_edge_attr[ei]):
                return True
        except Exception:
            pass
    return False


def _is_face_selected(face: Any, face_attr: Sequence[Any], mesh_face_attr: Sequence[Any], allow_mesh_fallback: bool) -> bool:
    try:
        if bool(getattr(face, "uv_select", False)):
            return True
    except Exception:
        pass
    try:
        fi = int(getattr(face, "index", -1))
        if 0 <= fi < len(face_attr) and bool(face_attr[fi]):
            return True
    except Exception:
        pass
    if allow_mesh_fallback:
        try:
            fi = int(getattr(face, "index", -1))
            if 0 <= fi < len(mesh_face_attr) and bool(mesh_face_attr[fi]):
                return True
        except Exception:
            pass
    return False


def _dedupe_records(records: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    seen = set(); out = []
    for rec in records:
        key = (rec.get("obj_key"), int(rec.get("face_index", -1)), int(rec.get("face_loop_index", -1)))
        if key in seen:
            continue
        seen.add(key); out.append(rec)
    return out


def _make_record(obj: Any, obj_key: str, mesh: Any, bm: Any, uv_layer: Any, face: Any, loop: Any, local_i: int) -> Optional[Dict[str, Any]]:
    try:
        u, v = _uv_xy(loop, uv_layer)
        return {
            "obj": obj, "obj_key": obj_key, "mesh": mesh, "bm": bm, "uv_layer": uv_layer,
            "face": face, "loop": loop, "luv": loop[uv_layer],
            "face_index": int(getattr(face, "index", -1)),
            "face_loop_index": int(local_i),
            "loop_index": int(getattr(loop, "index", -1)),
            "vertex_index": int(getattr(loop.vert, "index", -1)),
            "edge_index": int(getattr(loop.edge, "index", -1)),
            "uv_key": _uv_key(loop, uv_layer),
            "u": u, "v": v,
        }
    except Exception:
        return None


def _find(parent: List[int], i: int) -> int:
    while parent[i] != i:
        parent[i] = parent[parent[i]]
        i = parent[i]
    return i


def _union(parent: List[int], a: int, b: int) -> None:
    try:
        if a < 0 or b < 0 or a >= len(parent) or b >= len(parent):
            return
        ra = _find(parent, a); rb = _find(parent, b)
        if ra != rb:
            parent[rb] = ra
    except Exception:
        pass


def _collect_strict_components(g: Dict[str, Any], context: Any, mode: str) -> Tuple[List[List[Dict[str, Any]]], List[Any]]:
    """Return raw record components for EDGE/FACE mode.

    EDGE mode: selected UV edge components. Connectivity is selected-edge endpoint
    sharing only. FACE/ISLAND mode: selected UV face components. Connectivity is
    selected-face shared UV edge only. No visible-unselected edges and no 3D
    topology are used.
    """
    import bmesh

    objs = _edit_objects(context)
    components: List[List[Dict[str, Any]]] = []
    meshes: List[Any] = []
    mode = str(mode or "VERTEX").upper()
    try:
        sync = bool((g.get("_sus_1655_sync") or (lambda c: False))(context))
    except Exception:
        sync = False
    for obj in objs:
        mesh = getattr(obj, "data", None)
        if mesh is None:
            continue
        try:
            bm = bmesh.from_edit_mesh(mesh)
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
            try:
                bm.edges.index_update(); bm.verts.index_update()
            except Exception:
                pass
            uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        except Exception:
            continue
        meshes.append(mesh)
        obj_key = _obj_key(g, obj)
        edge_attr = _attr_values(g, mesh, ".uv_select_edge")
        face_attr = _attr_values(g, mesh, ".uv_select_face")
        mesh_edge_attr = _attr_values(g, mesh, ".select_edge")
        mesh_face_attr = _attr_values(g, mesh, ".select_poly")
        explicit_uv = bool(any(edge_attr) or any(face_attr))
        allow_mesh_fallback = bool(sync or not explicit_uv)

        raw: List[Dict[str, Any]] = []
        parent: List[int] = []
        endpoint_to_indices: Dict[Tuple[float, float], List[int]] = {}
        edgepair_to_indices: Dict[Tuple[Tuple[float, float], Tuple[float, float]], List[int]] = {}

        def add(loop: Any, face: Any, local_i: int) -> int:
            rec = _make_record(obj, obj_key, mesh, bm, uv_layer, face, loop, local_i)
            if rec is None:
                return -1
            idx = len(raw)
            raw.append(rec); parent.append(idx)
            return idx

        for face in bm.faces:
            try:
                if getattr(face, "hide", False):
                    continue
                loops = list(face.loops)
            except Exception:
                continue
            if not loops:
                continue
            if mode == "EDGE":
                for local_i, loop in enumerate(loops):
                    if not _is_edge_selected(g, loop, uv_layer, edge_attr, mesh_edge_attr, allow_mesh_fallback):
                        continue
                    a_idx = add(loop, face, local_i)
                    b_idx = add(loop.link_loop_next, face, (local_i + 1) % len(loops))
                    if a_idx >= 0 and b_idx >= 0:
                        _union(parent, a_idx, b_idx)
                        a_key = raw[a_idx].get("uv_key"); b_key = raw[b_idx].get("uv_key")
                        if a_key is not None:
                            endpoint_to_indices.setdefault(a_key, []).append(a_idx)
                        if b_key is not None:
                            endpoint_to_indices.setdefault(b_key, []).append(b_idx)
            elif mode in {"FACE", "ISLAND"}:
                if not _is_face_selected(face, face_attr, mesh_face_attr, allow_mesh_fallback):
                    continue
                face_indices: List[int] = []
                for local_i, loop in enumerate(loops):
                    idx = add(loop, face, local_i)
                    if idx >= 0:
                        face_indices.append(idx)
                if face_indices:
                    root = face_indices[0]
                    for idx in face_indices[1:]:
                        _union(parent, root, idx)
                    # Selected faces are connected only through the selected-face
                    # shared UV edge. Vertex-only contact must remain separate.
                    for local_i, loop in enumerate(loops):
                        pair = _edge_pair_key(loop, uv_layer)
                        if pair is not None:
                            edgepair_to_indices.setdefault(pair, []).append(face_indices[local_i])
        if not raw:
            continue
        if mode == "EDGE":
            for idxs in endpoint_to_indices.values():
                if len(idxs) > 1:
                    base = idxs[0]
                    for idx in idxs[1:]:
                        _union(parent, base, idx)
        elif mode in {"FACE", "ISLAND"}:
            for idxs in edgepair_to_indices.values():
                if len(idxs) > 1:
                    base = idxs[0]
                    for idx in idxs[1:]:
                        _union(parent, base, idx)
        # Object-local components. Cross-object connectivity is intentionally not
        # created here because selected edge/face connectivity does not cross
        # Blender object data; this also prevents stacked UVs in different objects
        # from merging as a group accidentally.
        comp_map: Dict[int, List[Dict[str, Any]]] = {}
        order: List[int] = []
        for i, rec in enumerate(raw):
            root = _find(parent, i)
            if root not in comp_map:
                comp_map[root] = []; order.append(root)
            comp_map[root].append(rec)
        for root in order:
            comp = _dedupe_records(comp_map.get(root) or [])
            if comp:
                components.append(comp)
    return components, meshes


def _point_key(rec: Dict[str, Any], sticky: str, fallback: int) -> Any:
    sticky = str(sticky or "DISABLED").upper()
    if sticky == "SHARED_LOCATION":
        return ("uv", rec.get("uv_key"))
    if sticky == "SHARED_VERTEX":
        return ("vert", rec.get("obj_key"), rec.get("vertex_index"))
    return ("loop", rec.get("obj_key"), rec.get("face_index"), rec.get("face_loop_index", fallback))


def _records_to_points(records: Sequence[Dict[str, Any]], sticky: str) -> List[Dict[str, Any]]:
    buckets: Dict[Any, List[Dict[str, Any]]] = {}
    order: List[Any] = []
    for i, rec in enumerate(records or []):
        key = _point_key(rec, sticky, i)
        if key not in buckets:
            buckets[key] = []; order.append(key)
        buckets[key].append(rec)
    points: List[Dict[str, Any]] = []
    for key in order:
        group = buckets.get(key) or []
        if not group:
            continue
        us = [float(r.get("u", 0.0)) for r in group]
        vs = [float(r.get("v", 0.0)) for r in group]
        points.append({"key": key, "records": group, "u": sum(us) / len(us), "v": sum(vs) / len(vs)})
    return points


def _apply_action(g: Dict[str, Any], points: Sequence[Dict[str, Any]], action: str) -> int:
    fn = g.get("_sus_1676a_apply_action") or g.get("_sus_1655_vertex_align_apply")
    if callable(fn):
        try:
            return int(fn(list(points), action))
        except TypeError:
            try:
                return int(fn(list(points), action, context=None))
            except Exception:
                pass
        except Exception:
            pass
    return 0


def _update_meshes(meshes: Sequence[Any]) -> None:
    try:
        import bmesh
        seen = set()
        for mesh in meshes or []:
            if mesh is None or id(mesh) in seen:
                continue
            seen.add(id(mesh))
            try:
                bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
            except TypeError:
                bmesh.update_edit_mesh(mesh)
            except Exception:
                pass
    except Exception:
        pass


def _strict_group_execute(g: Dict[str, Any], self: Any, context: Any, previous: Any) -> set:
    raw = str(getattr(self, "action", "") or "").upper()
    if raw not in {"ALIGN_H_GROUP", "ALIGN_V_GROUP", "DISTRIBUTE_H_GROUP", "DISTRIBUTE_V_GROUP"}:
        if callable(previous):
            return previous(self, context)
        return {"CANCELLED"}
    mode = _uv_mode(g, context)
    if mode not in {"EDGE", "FACE", "ISLAND"}:
        if callable(previous):
            return previous(self, context)
        return {"CANCELLED"}
    action = raw[:-6]
    try:
        components, meshes = _collect_strict_components(g, context, mode)
        if not components:
            try:
                self.report({"WARNING"}, "選択されたUV辺またはUV面がありません。")
            except Exception:
                pass
            return {"CANCELLED"}
        sticky = _sticky_mode(g, context)
        changed = 0
        for comp in components:
            pts = _records_to_points(comp, sticky)
            if pts:
                changed += _apply_action(g, pts, action)
        if changed <= 0:
            try:
                self.report({"WARNING"}, "頂点方向整列で変更される選択がありませんでした。")
            except Exception:
                pass
            return {"CANCELLED"}
        _update_meshes(meshes)
        return {"FINISHED"}
    except Exception as exc:
        try:
            self.report({"WARNING"}, f"頂点方向整列に失敗しました。 {exc}")
        except Exception:
            pass
        return {"CANCELLED"}


def install(g: Dict[str, Any]) -> None:
    cls = g.get("SMARTUVSUITE_OT_vertex_align_action")
    if not isinstance(cls, type):
        return
    previous = getattr(cls, _PREVIOUS_EXECUTE_ATTR, None)
    current = getattr(cls, "execute", None)
    if previous is None and callable(current):
        setattr(cls, _PREVIOUS_EXECUTE_ATTR, current)
        previous = current
    elif previous is None:
        previous = current

    def execute(self, context):
        return _strict_group_execute(g, self, context, previous)

    execute.__name__ = "_suv_1873_vertex_align_execute"
    cls.execute = execute


def apply_all(g: Dict[str, Any], context: Any = None) -> None:
    install(g)


def unregister() -> None:
    pass
