# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Strict grouped Direction Align backend for Smart UV Suite 1.8.97.

This final backend owns the grouped vertex-direction buttons (G— / G| / G↔ /
G↕).  It does not expand or rewrite the live UV selection before computing
components.  Instead it builds selected-edge/selected-face groups from the live
BMesh selection, then adds sticky-equivalent endpoints as follower records inside
that already computed group.  That keeps disconnected selected edges/faces in
separate groups while still moving Shared Location / Shared Vertex endpoints
with their selected endpoint.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

import bpy

_VERSION = (1, 8, 97)
_GROUP_ACTIONS = {"ALIGN_H_GROUP", "ALIGN_V_GROUP", "DISTRIBUTE_H_GROUP", "DISTRIBUTE_V_GROUP"}
_PREV_ATTR = "_suv_1897_previous_group_direction_execute"
_STICKY_PREV_ATTR = "_suv1897_sticky_post_previous_execute"
_STICKY_TARGET_CLASSES = (
    "SMARTUVSUITE_OT_vertex_align_action",
    "SMARTUVSUITE_OT_vertex_straighten_selected",
    "SMARTUVSUITE_OT_vertex_even_straighten_selected",
    "SMARTUVSUITE_OT_vertex_set_flow_selected",
)
_STICKY_TARGET_IDS = {
    "SMARTUVSUITE_OT_vertex_align_action": "smart_uv_suite.vertex_align_action",
    "SMARTUVSUITE_OT_vertex_straighten_selected": "smart_uv_suite.vertex_straighten_selected",
    "SMARTUVSUITE_OT_vertex_even_straighten_selected": "smart_uv_suite.vertex_even_straighten_selected",
    "SMARTUVSUITE_OT_vertex_set_flow_selected": "smart_uv_suite.vertex_set_flow_selected",
}
_DIGITS = 7
_NS: Dict[str, Any] = {}


def _txt(context: Any, en: str, ja: str) -> str:
    fn = _NS.get("_sus_text")
    if callable(fn):
        try:
            return str(fn(en, ja, context))
        except Exception:
            pass
    try:
        lang = str(getattr(getattr(context, "preferences", None), "view", None).language or "")
        if lang.startswith("ja"):
            return ja
    except Exception:
        pass
    return ja or en


def _normalize_uv_mode(raw: Any) -> str:
    try:
        if isinstance(raw, (set, list, tuple)):
            values = {str(v).upper() for v in raw}
            if "FACE" in values or "ISLAND" in values:
                return "FACE"
            if "EDGE" in values:
                return "EDGE"
            return "VERTEX"
        value = str(raw or "VERTEX").upper()
        if "FACE" in value or "ISLAND" in value:
            return "FACE"
        if "EDGE" in value:
            return "EDGE"
    except Exception:
        pass
    return "VERTEX"


def _uv_mode(context: Any) -> str:
    fn = _NS.get("_sus_1655_uv_mode") or _NS.get("_sus_uv_select_mode")
    if callable(fn):
        try:
            return _normalize_uv_mode(fn(context))
        except Exception:
            pass
    try:
        return _normalize_uv_mode(getattr(getattr(context, "tool_settings", None), "uv_select_mode", "VERTEX"))
    except Exception:
        return "VERTEX"


def _raw_sticky(context: Any) -> Optional[str]:
    try:
        ts = getattr(context, "tool_settings", None) or getattr(getattr(context, "scene", None), "tool_settings", None)
        if ts is None:
            return None
        return str(getattr(ts, "uv_sticky_select_mode", "DISABLED") or "DISABLED")
    except Exception:
        return None


def _set_raw_sticky(context: Any, value: Optional[str]) -> None:
    if value is None:
        return
    try:
        ts = getattr(context, "tool_settings", None) or getattr(getattr(context, "scene", None), "tool_settings", None)
        if ts is not None and str(getattr(ts, "uv_sticky_select_mode", "DISABLED") or "DISABLED") != str(value):
            setattr(ts, "uv_sticky_select_mode", value)
    except Exception:
        pass


def _normalize_sticky(raw: Any) -> str:
    mode = str(raw or "DISABLED").upper()
    aliases = {
        "SAME_LOCATION": "SHARED_LOCATION",
        "SAME_POSITION": "SHARED_LOCATION",
        "LOCATION": "SHARED_LOCATION",
        "SHARED_POSITION": "SHARED_LOCATION",
        "VERTEX": "SHARED_VERTEX",
        "SHARED_VERT": "SHARED_VERTEX",
        "COMMON_VERTEX": "SHARED_VERTEX",
    }
    return aliases.get(mode, mode)


def _sticky(context: Any) -> str:
    # Read Blender's ToolSettings directly.  Do not use workspace fallback here:
    # grouped direction align must never toggle or emulate the UV Sticky setting.
    return _normalize_sticky(_raw_sticky(context))


def _sync(context: Any) -> bool:
    try:
        return bool(getattr(getattr(context, "tool_settings", None), "use_uv_select_sync", False))
    except Exception:
        return False


def _obj_key(obj: Any) -> str:
    for name in ("_sus_1655_obj_key", "_sus_1653_obj_key"):
        fn = _NS.get(name)
        if callable(fn):
            try:
                return str(fn(obj))
            except Exception:
                pass
    try:
        return str(getattr(obj, "name_full", None) or getattr(obj, "name", None) or id(obj))
    except Exception:
        return str(id(obj))


def _edit_objects(context: Any) -> List[Any]:
    out: List[Any] = []
    try:
        out = [o for o in (getattr(context, "objects_in_mode_unique_data", None) or []) if getattr(o, "type", "") == "MESH" and getattr(o, "mode", "") == "EDIT"]
    except Exception:
        out = []
    if not out:
        try:
            obj = getattr(context, "edit_object", None) or getattr(context, "active_object", None)
            if obj is not None and getattr(obj, "type", "") == "MESH" and getattr(obj, "mode", "") == "EDIT":
                out = [obj]
        except Exception:
            pass
    seen: Set[int] = set()
    clean: List[Any] = []
    for obj in out:
        try:
            data = getattr(obj, "data", obj)
            key = int(data.as_pointer()) if hasattr(data, "as_pointer") else id(data)
        except Exception:
            key = id(obj)
        if key in seen:
            continue
        seen.add(key)
        clean.append(obj)
    return clean


def _enter_edit_context(context: Any) -> Tuple[Any, str, List[Any], bool]:
    old_active = None
    old_mode = "OBJECT"
    changed = False
    try:
        old_active = getattr(getattr(context, "view_layer", None), "objects", None).active
    except Exception:
        old_active = None
    objs = _edit_objects(context)
    if objs:
        return old_active, "EDIT", objs, False
    obj = getattr(context, "active_object", None)
    if obj is None or getattr(obj, "type", "") != "MESH":
        return old_active, old_mode, [], False
    try:
        old_mode = str(getattr(obj, "mode", "OBJECT") or "OBJECT")
    except Exception:
        old_mode = "OBJECT"
    try:
        context.view_layer.objects.active = obj
        obj.select_set(True)
    except Exception:
        pass
    if old_mode != "EDIT":
        try:
            bpy.ops.object.mode_set(mode="EDIT")
            changed = True
        except Exception:
            pass
    return old_active, old_mode, _edit_objects(context), changed


def _restore_edit_context(context: Any, old_active: Any, old_mode: str, changed: bool) -> None:
    if changed and old_mode and old_mode != "EDIT":
        try:
            bpy.ops.object.mode_set(mode=old_mode)
        except Exception:
            pass
    try:
        if old_active is not None:
            context.view_layer.objects.active = old_active
    except Exception:
        pass


def _ensure_target(context: Any, obj: Any) -> None:
    try:
        from . import uv_map_channels as _uvc
        ws = getattr(getattr(context, "scene", None), "suv_workspace", None)
        _uvc.ensure_unwrap_map_channel(context, ws, obj)
    except Exception:
        pass


def _uv_layer_for_bmesh(bm: Any):
    try:
        layer = bm.loops.layers.uv.active
        if layer is not None:
            return layer
    except Exception:
        pass
    try:
        return bm.loops.layers.uv.verify()
    except Exception:
        return None


def _loop_index(loop: Any) -> int:
    try:
        return int(getattr(loop, "index", -1))
    except Exception:
        return -1


def _face_index(face: Any) -> int:
    try:
        return int(getattr(face, "index", -1))
    except Exception:
        return -1


def _uv_xy(loop: Any, uv_layer: Any) -> Tuple[float, float]:
    try:
        uv = loop[uv_layer].uv
        return float(uv.x), float(uv.y)
    except Exception:
        return 0.0, 0.0


def _uv_key(loop: Any, uv_layer: Any) -> Optional[Tuple[float, float]]:
    try:
        u, v = _uv_xy(loop, uv_layer)
        return (round(u, _DIGITS), round(v, _DIGITS))
    except Exception:
        return None


def _actual_endpoint_key(obj_key: str, loop: Any, uv_layer: Any) -> Optional[Tuple[Any, ...]]:
    key = _uv_key(loop, uv_layer)
    if key is None:
        return None
    try:
        vi = int(getattr(loop.vert, "index", -1))
    except Exception:
        vi = -1
    return (obj_key, vi, key)


def _sticky_key(obj_key: str, loop: Any, uv_layer: Any, sticky: str) -> Optional[Tuple[Any, ...]]:
    sticky = str(sticky or "DISABLED").upper()
    if sticky == "SHARED_LOCATION":
        key = _uv_key(loop, uv_layer)
        if key is None:
            return None
        # Same-location sticky is UV-space based.  Keep object in the key so
        # simultaneous multi-object editing never drags unrelated objects together.
        return ("uv", obj_key, key[0], key[1])
    if sticky == "SHARED_VERTEX":
        try:
            return ("vert", obj_key, int(getattr(loop.vert, "index", -1)))
        except Exception:
            return None
    return None


def _edge_sig(obj_key: str, loop: Any, uv_layer: Any) -> Optional[Tuple[Any, ...]]:
    try:
        a = _uv_key(loop, uv_layer)
        b = _uv_key(loop.link_loop_next, uv_layer)
        if a is None or b is None:
            return None
        return (obj_key, int(getattr(loop.edge, "index", -1)), tuple(sorted((a, b))))
    except Exception:
        return None


def _luv(loop: Any, uv_layer: Any):
    try:
        return loop[uv_layer]
    except Exception:
        return None


def _get_v(loop: Any, uv_layer: Any, sync: bool = False) -> bool:
    for getter in (
        lambda: getattr(loop, "uv_select_vert", False),
        lambda: getattr(loop[uv_layer], "select_vert", False),
        lambda: getattr(loop[uv_layer], "select", False),
    ):
        try:
            if bool(getter()):
                return True
        except Exception:
            pass
    if sync:
        try:
            return bool(getattr(loop.vert, "select", False))
        except Exception:
            pass
    return False


def _get_e(loop: Any, uv_layer: Any, sync: bool = False) -> bool:
    for getter in (
        lambda: getattr(loop, "uv_select_edge", False),
        lambda: getattr(loop[uv_layer], "select_edge", False),
    ):
        try:
            if bool(getter()):
                return True
        except Exception:
            pass
    if sync:
        try:
            return bool(getattr(loop.edge, "select", False))
        except Exception:
            pass
    return False


def _get_f(face: Any, sync: bool = False) -> bool:
    try:
        if bool(getattr(face, "uv_select", False)):
            return True
    except Exception:
        pass
    if sync:
        try:
            return bool(getattr(face, "select", False))
        except Exception:
            pass
    return False


def _read_attr(mesh: Any, name: str) -> List[bool]:
    try:
        attr = getattr(mesh, "attributes", None).get(name)
        if attr is None:
            return []
        return [bool(getattr(item, "value", False)) for item in getattr(attr, "data", []) or []]
    except Exception:
        return []



def _reject_full_flags(flags):
    try:
        if flags and all(bool(v) for v in flags):
            return [False] * len(flags)
    except Exception:
        pass
    return flags

def _has_live_selection(bm: Any, uv_layer: Any, mode: str, sync: bool) -> bool:
    try:
        for face in bm.faces:
            if mode == "FACE" and _get_f(face, sync):
                return True
            for loop in face.loops:
                if mode == "EDGE" and _get_e(loop, uv_layer, sync):
                    return True
                if mode == "VERTEX" and _get_v(loop, uv_layer, sync):
                    return True
                if mode == "FACE" and (_get_v(loop, uv_layer, sync) or _get_e(loop, uv_layer, sync)):
                    return True
    except Exception:
        pass
    return False


def _record(obj: Any, obj_key: str, mesh: Any, bm: Any, uv_layer: Any, face: Any, loop: Any, local_i: int, *, source: bool) -> Dict[str, Any]:
    u, v = _uv_xy(loop, uv_layer)
    fi = _face_index(face)
    li = _loop_index(loop)
    try:
        vi = int(getattr(loop.vert, "index", -1))
    except Exception:
        vi = -1
    return {
        "obj": obj, "obj_key": obj_key, "mesh": mesh, "bm": bm,
        "uv_layer": uv_layer, "face": face, "loop": loop,
        "face_index": fi, "face_loop_index": int(local_i), "loop_index": li,
        "vertex_index": vi, "edge_index": int(getattr(getattr(loop, "edge", None), "index", -1)),
        "record_id": (obj_key, fi, int(local_i), li),
        "endpoint_key": _actual_endpoint_key(obj_key, loop, uv_layer),
        "u": u, "v": v,
        "selected_source": bool(source),
    }


def _collect_group_components(context: Any, mode: str, sticky: str) -> Tuple[List[List[Dict[str, Any]]], List[Any]]:
    import bmesh

    mode = _normalize_uv_mode(mode)
    sync = _sync(context)
    components: List[List[Dict[str, Any]]] = []
    meshes: List[Any] = []
    objects: List[Any] = []

    for obj in _edit_objects(context):
        try:
            _ensure_target(context, obj)
            mesh = getattr(obj, "data", None)
            if mesh is None:
                continue
            bm = bmesh.from_edit_mesh(mesh)
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
            uv_layer = _uv_layer_for_bmesh(bm)
            if uv_layer is None:
                continue
        except Exception:
            continue

        meshes.append(mesh)
        objects.append(obj)
        obj_key = _obj_key(obj)
        live_any = _has_live_selection(bm, uv_layer, mode, sync)
        try:
            if mode == "FACE":
                mesh_total = sum(1 for _f in bm.faces if not getattr(_f, "hide", False))
                mesh_sel = sum(1 for _f in bm.faces if (not getattr(_f, "hide", False)) and bool(getattr(_f, "select", False)))
            elif mode == "EDGE":
                mesh_total = sum(1 for _e in bm.edges if not getattr(_e, "hide", False))
                mesh_sel = sum(1 for _e in bm.edges if (not getattr(_e, "hide", False)) and bool(getattr(_e, "select", False)))
            else:
                mesh_total = sum(1 for _v in bm.verts if not getattr(_v, "hide", False))
                mesh_sel = sum(1 for _v in bm.verts if (not getattr(_v, "hide", False)) and bool(getattr(_v, "select", False)))
        except Exception:
            mesh_total = mesh_sel = 0
        allow_mesh_fallback = bool(sync and mesh_sel > 0 and (mesh_total <= 0 or mesh_sel < mesh_total))
        if sync and mesh_total > 0 and mesh_sel >= mesh_total:
            live_any = False
        v_attr = [] if live_any else _read_attr(mesh, ".uv_select_vert")
        e_attr = [] if live_any else _read_attr(mesh, ".uv_select_edge")
        f_attr = [] if live_any else _read_attr(mesh, ".uv_select_face")
        if sync and mesh_total > 0 and mesh_sel >= mesh_total:
            v_attr = _reject_full_flags(v_attr)
            e_attr = _reject_full_flags(e_attr)
            f_attr = _reject_full_flags(f_attr)

        records: List[Dict[str, Any]] = []
        rec_by_id: Dict[Any, int] = {}
        source_indices: Set[int] = set()
        pairs: List[Tuple[int, int]] = []
        endpoint_source: Dict[Any, List[int]] = {}
        face_edge_source: Dict[Any, List[int]] = {}
        all_loop_records: List[Dict[str, Any]] = []

        def loop_attr(flags: Sequence[bool], loop: Any) -> bool:
            li = _loop_index(loop)
            return 0 <= li < len(flags) and bool(flags[li])

        def face_attr(face: Any) -> bool:
            fi = _face_index(face)
            return 0 <= fi < len(f_attr) and bool(f_attr[fi])

        def add(face: Any, loop: Any, local_i: int, *, source: bool) -> Optional[int]:
            try:
                rid = (obj_key, _face_index(face), int(local_i), _loop_index(loop))
                if rid in rec_by_id:
                    idx = rec_by_id[rid]
                    if source:
                        records[idx]["selected_source"] = True
                        source_indices.add(idx)
                    return idx
                rec = _record(obj, obj_key, mesh, bm, uv_layer, face, loop, local_i, source=source)
                idx = len(records)
                records.append(rec)
                rec_by_id[rid] = idx
                if source:
                    source_indices.add(idx)
                return idx
            except Exception:
                return None

        # Cache every visible UV loop as a potential sticky follower.  This does
        # not change selection and does not participate in component connectivity.
        for face in bm.faces:
            try:
                if getattr(face, "hide", False):
                    continue
                loops = list(face.loops)
            except Exception:
                continue
            for i, loop in enumerate(loops):
                try:
                    all_loop_records.append(_record(obj, obj_key, mesh, bm, uv_layer, face, loop, i, source=False))
                except Exception:
                    pass

        for face in bm.faces:
            try:
                if getattr(face, "hide", False):
                    continue
                loops = list(face.loops)
            except Exception:
                continue
            if not loops:
                continue
            if mode == "EDGE":
                for i, loop in enumerate(loops):
                    selected = _get_e(loop, uv_layer, allow_mesh_fallback) or (not live_any and loop_attr(e_attr, loop))
                    if not selected:
                        continue
                    a = add(face, loop, i, source=True)
                    b = add(face, loop.link_loop_next, (i + 1) % len(loops), source=True)
                    if a is not None and b is not None and a != b:
                        pairs.append((a, b))
                    for idx in (a, b):
                        if idx is None:
                            continue
                        key = records[idx].get("endpoint_key")
                        if key is not None:
                            endpoint_source.setdefault(key, []).append(idx)
            elif mode == "FACE":
                face_selected = _get_f(face, allow_mesh_fallback) or (not live_any and face_attr(face))
                if not face_selected:
                    # Blender can leave live vertex/edge flags in face mode for
                    # partial selections.  They are not whole selected faces, so
                    # treat them as vertex endpoints, not face groups.
                    continue
                first: Optional[int] = None
                prev: Optional[int] = None
                for i, loop in enumerate(loops):
                    idx = add(face, loop, i, source=True)
                    if idx is None:
                        continue
                    if first is None:
                        first = idx
                    if prev is not None and prev != idx:
                        pairs.append((prev, idx))
                    prev = idx
                    sig = _edge_sig(obj_key, loop, uv_layer)
                    if sig is not None:
                        face_edge_source.setdefault(sig, []).append(idx)
                if first is not None and prev is not None and first != prev:
                    pairs.append((prev, first))
            else:
                # Vertex mode: components are selected vertices connected by
                # selected adjacency in the current UV face.  This is unchanged
                # from the normal G group intent, but uses live selection first.
                selected_flags: Dict[int, bool] = {}
                for i, loop in enumerate(loops):
                    sel = _get_v(loop, uv_layer, allow_mesh_fallback) or (not live_any and loop_attr(v_attr, loop))
                    selected_flags[_loop_index(loop)] = bool(sel)
                    if sel:
                        idx = add(face, loop, i, source=True)
                        if idx is not None:
                            key = records[idx].get("endpoint_key")
                            if key is not None:
                                endpoint_source.setdefault(key, []).append(idx)
                for i, loop in enumerate(loops):
                    if not selected_flags.get(_loop_index(loop)):
                        continue
                    nloop = loop.link_loop_next
                    if not selected_flags.get(_loop_index(nloop)):
                        continue
                    a = add(face, loop, i, source=True)
                    b = add(face, nloop, (i + 1) % len(loops), source=True)
                    if a is not None and b is not None and a != b:
                        pairs.append((a, b))

        # Selected EDGE and VERTEX groups connect only through the same actual UV
        # endpoint: same object, same mesh vertex, same UV coordinate.  Same UV
        # location alone never connects selected groups.
        if mode in {"EDGE", "VERTEX"}:
            for idxs in endpoint_source.values():
                if len(idxs) > 1:
                    base = idxs[0]
                    for other in idxs[1:]:
                        if base != other:
                            pairs.append((base, other))
        elif mode == "FACE":
            for idxs in face_edge_source.values():
                if len(idxs) > 1:
                    base = idxs[0]
                    for other in idxs[1:]:
                        if base != other:
                            pairs.append((base, other))

        if not source_indices:
            continue

        parent = list(range(len(records)))
        for a, b in pairs:
            if a in source_indices and b in source_indices:
                _union(parent, a, b)
        comp_sources: Dict[int, List[int]] = {}
        order: List[int] = []
        for idx in sorted(source_indices):
            root = _find(parent, idx)
            if root not in comp_sources:
                comp_sources[root] = []
                order.append(root)
            comp_sources[root].append(idx)

        # For each already-separated selected component, add sticky-equivalent
        # follower loops to that component's points only.  Followers never form
        # inter-component unions, so G—/G| stay strict.  Source records from
        # another selected component are never borrowed as followers; otherwise
        # two intentionally separate selected edges that merely overlap in UV
        # space would move each other.
        all_source_record_ids: Set[Any] = {records[i].get("record_id") for i in source_indices}
        all_source_loop_ids: Set[int] = set()
        for i in source_indices:
            try:
                all_source_loop_ids.add(id(records[i].get("loop")))
            except Exception:
                pass
        for root in order:
            src_idxs = comp_sources.get(root) or []
            if not src_idxs:
                continue
            src_records = [records[i] for i in src_idxs]
            group_records: List[Dict[str, Any]] = list(src_records)
            seen_record_ids: Set[Any] = {rec.get("record_id") for rec in group_records}
            sticky_keys: Set[Any] = set()
            if sticky in {"SHARED_LOCATION", "SHARED_VERTEX"}:
                for rec in src_records:
                    try:
                        key = _sticky_key(str(rec.get("obj_key")), rec.get("loop"), rec.get("uv_layer"), sticky)
                        if key is not None:
                            sticky_keys.add(key)
                    except Exception:
                        pass
            if sticky_keys:
                for rec in all_loop_records:
                    rid = rec.get("record_id")
                    if rid in seen_record_ids:
                        continue
                    if rid in all_source_record_ids:
                        continue
                    try:
                        if id(rec.get("loop")) in all_source_loop_ids:
                            continue
                    except Exception:
                        pass
                    try:
                        key = _sticky_key(str(rec.get("obj_key")), rec.get("loop"), rec.get("uv_layer"), sticky)
                    except Exception:
                        key = None
                    if key is None or key not in sticky_keys:
                        continue
                    group_records.append(rec)
                    seen_record_ids.add(rid)
            components.append(_records_to_points(group_records, sticky))

    return components, meshes


def _records_to_points(records: Sequence[Dict[str, Any]], sticky: str) -> List[Dict[str, Any]]:
    buckets: Dict[Any, List[Dict[str, Any]]] = {}
    order: List[Any] = []
    for i, rec in enumerate(records or []):
        key: Any = None
        if sticky == "SHARED_LOCATION":
            try:
                key = _sticky_key(str(rec.get("obj_key")), rec.get("loop"), rec.get("uv_layer"), sticky)
            except Exception:
                key = None
        elif sticky == "SHARED_VERTEX":
            # Shared Vertex must preserve intentional seam offsets.  Treat each
            # loop as its own transform point; the postcondition below applies a
            # single deterministic delta to same-vertex followers after the
            # public operation finishes.
            key = ("record", rec.get("record_id", i))
        if key is None:
            key = ("record", rec.get("record_id", i))
        if key not in buckets:
            buckets[key] = []
            order.append(key)
        buckets[key].append(rec)
    points: List[Dict[str, Any]] = []
    for key in order:
        recs = buckets.get(key) or []
        if not recs:
            continue
        us = [float(r.get("u", 0.0)) for r in recs]
        vs = [float(r.get("v", 0.0)) for r in recs]
        points.append({"key": key, "records": recs, "u": sum(us) / len(us), "v": sum(vs) / len(vs)})
    return points


def _find(parent: List[int], i: int) -> int:
    while parent[i] != i:
        parent[i] = parent[parent[i]]
        i = parent[i]
    return i


def _union(parent: List[int], a: int, b: int) -> None:
    try:
        if a < 0 or b < 0 or a >= len(parent) or b >= len(parent):
            return
        ra = _find(parent, a)
        rb = _find(parent, b)
        if ra != rb:
            parent[rb] = ra
    except Exception:
        pass


def _apply(points: Sequence[Dict[str, Any]], action: str) -> int:
    try:
        from . import uv_direction_align_1892 as d
        fn = getattr(d, "_apply_vertex_action", None)
        if callable(fn):
            return int(fn(list(points), action))
    except Exception:
        pass
    # Minimal fallback for the four grouped actions.
    pts = [p for p in (points or []) if p]
    if not pts:
        return 0
    action = str(action or "").upper()
    changed = 0
    if action in {"DISTRIBUTE_H", "DISTRIBUTE_V"}:
        axis_u = action == "DISTRIBUTE_H"
        key = (lambda p: float(p.get("u", 0.0))) if axis_u else (lambda p: float(p.get("v", 0.0)))
        ordered = sorted(pts, key=key)
        if len(ordered) < 2:
            return 0
        start, end = key(ordered[0]), key(ordered[-1])
        if abs(end - start) <= 1.0e-12:
            return 0
        step = (end - start) / float(max(1, len(ordered) - 1))
        for i, pt in enumerate(ordered):
            value = start + step * i
            changed += _write_point(pt, u=value) if axis_u else _write_point(pt, v=value)
        return changed
    us = [float(p.get("u", 0.0)) for p in pts]
    vs = [float(p.get("v", 0.0)) for p in pts]
    if action == "ALIGN_H":
        v = (min(vs) + max(vs)) * 0.5
        for pt in pts:
            changed += _write_point(pt, v=v)
    elif action == "ALIGN_V":
        u = (min(us) + max(us)) * 0.5
        for pt in pts:
            changed += _write_point(pt, u=u)
    return changed


def _write_point(point: Dict[str, Any], u: Optional[float] = None, v: Optional[float] = None) -> int:
    changed = 0
    for rec in list(point.get("records") or []):
        try:
            loop = rec.get("loop")
            uv_layer = rec.get("uv_layer")
            uv = loop[uv_layer].uv
            if u is not None:
                uv.x = float(u)
                rec["u"] = float(u)
            if v is not None:
                uv.y = float(v)
                rec["v"] = float(v)
            changed += 1
        except Exception:
            pass
    if u is not None:
        point["u"] = float(u)
    if v is not None:
        point["v"] = float(v)
    return changed


def _update(meshes: Iterable[Any]) -> None:
    try:
        import bmesh
    except Exception:
        return
    seen: Set[int] = set()
    for mesh in meshes or []:
        try:
            key = int(mesh.as_pointer()) if hasattr(mesh, "as_pointer") else id(mesh)
            if key in seen:
                continue
            seen.add(key)
            try:
                bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
            except TypeError:
                bmesh.update_edit_mesh(mesh)
            except Exception:
                pass
        except Exception:
            pass


def _capture_sticky_postcondition(context: Any) -> Optional[Dict[str, Any]]:
    """Capture pre-transform equivalence without changing live selection."""
    sticky = _sticky(context)
    if sticky not in {"SHARED_LOCATION", "SHARED_VERTEX"}:
        return None
    try:
        import bmesh
    except Exception:
        return None
    mode = _normalize_uv_mode(_uv_mode(context))
    sync = _sync(context)
    classes: Dict[Any, List[Dict[str, Any]]] = {}
    meshes: List[Any] = []
    objects: List[Any] = []
    for obj in _edit_objects(context):
        try:
            mesh = getattr(obj, "data", None)
            if mesh is None:
                continue
            bm = bmesh.from_edit_mesh(mesh)
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
            uv_layer = _uv_layer_for_bmesh(bm)
            if uv_layer is None:
                continue
        except Exception:
            continue
        meshes.append(mesh)
        objects.append(obj)
        obj_key = _obj_key(obj)
        live_any = _has_live_selection(bm, uv_layer, mode, sync)
        # Blender 5.1 stores UV selection in CORNER bool attributes for
        # several edit paths while other paths expose live BMLoop/BMFace flags.
        # The sticky postcondition is a read-only pre-transform snapshot, so
        # source detection must accept either authority instead of suppressing
        # attributes when a partial live flag exists.
        v_attr = _read_attr(mesh, ".uv_select_vert")
        e_attr = _read_attr(mesh, ".uv_select_edge")
        f_attr = _read_attr(mesh, ".uv_select_face")

        def attr_selected(flags: Sequence[bool], loop: Any) -> bool:
            li = _loop_index(loop)
            return 0 <= li < len(flags) and bool(flags[li])

        for face in bm.faces:
            try:
                loops = list(face.loops)
            except Exception:
                continue
            for local_i, loop in enumerate(loops):
                try:
                    key = _sticky_key(obj_key, loop, uv_layer, sticky)
                    if key is None:
                        continue
                    own_edge = _get_e(loop, uv_layer, sync) or attr_selected(e_attr, loop)
                    prev_loop = getattr(loop, "link_loop_prev", None)
                    prev_edge = bool(prev_loop is not None and (
                        _get_e(prev_loop, uv_layer, sync)
                        or attr_selected(e_attr, prev_loop)
                    ))
                    visible = not bool(getattr(face, "hide", False))
                    if mode == "EDGE":
                        source = bool(own_edge or prev_edge) and visible
                        source_priority = 0 if own_edge else (1 if prev_edge else 2)
                    elif mode == "FACE":
                        fi = _face_index(face)
                        attr_face = 0 <= fi < len(f_attr) and bool(f_attr[fi])
                        source = bool(_get_f(face, sync) or attr_face) and visible
                        source_priority = 0
                    else:
                        source = bool(_get_v(loop, uv_layer, sync) or attr_selected(v_attr, loop)) and visible
                        source_priority = 0
                    initial = _uv_xy(loop, uv_layer)
                    stable = (obj_key, _face_index(face), int(local_i), _loop_index(loop))
                    classes.setdefault(key, []).append({
                        "object": obj,
                        "mesh": mesh,
                        "uv_layer_name": _mesh_active_uv_layer_name(mesh) or str(getattr(uv_layer, "name", "") or ""),
                        "loop": loop,
                        "uv_layer": uv_layer,
                        "initial": initial,
                        "source": bool(source),
                        "source_priority": int(source_priority),
                        "stable": stable,
                    })
                except Exception:
                    continue
    classes = {key: records for key, records in classes.items() if len(records) > 1}
    if not classes:
        return None
    return {"sticky": sticky, "classes": classes, "meshes": meshes, "objects": objects}


def _resolve_sticky_record_loop_18194(rec: Dict[str, Any]) -> Tuple[Any, Any]:
    try:
        import bmesh
        mesh = rec.get("mesh")
        if mesh is None:
            return rec.get("loop"), rec.get("uv_layer")
        bm = bmesh.from_edit_mesh(mesh)
        bm.faces.ensure_lookup_table()
        try:
            bm.faces.index_update()
        except Exception:
            pass
        uv_name = str(rec.get("uv_layer_name") or getattr(rec.get("uv_layer"), "name", "") or "")
        uv_layer = bm.loops.layers.uv.get(uv_name) if uv_name else None
        if uv_layer is None:
            uv_layer = _uv_layer_for_bmesh(bm)
        stable = tuple(rec.get("stable") or ())
        if len(stable) >= 3 and uv_layer is not None:
            face_index = int(stable[1])
            local_index = int(stable[2])
            if 0 <= face_index < len(bm.faces):
                loops = tuple(bm.faces[face_index].loops)
                if loops:
                    return loops[max(0, min(local_index, len(loops) - 1))], uv_layer
    except Exception:
        if rec.get("mesh") is not None:
            return None, None
    return rec.get("loop"), rec.get("uv_layer")


def _mesh_active_uv_layer_name(mesh: Any) -> str:
    try:
        layers = getattr(mesh, "uv_layers", None)
        active = getattr(layers, "active", None) if layers is not None else None
        return str(getattr(active, "name", "") or "")
    except Exception:
        return ""


def _ensure_snapshot_edit_context(snapshot: Dict[str, Any], context: Any) -> None:
    """Best-effort edit-mode restoration before resolving stored BMesh keys.

    Several public line/flow operators restore object mode before returning.
    The sticky postcondition runs after that public execute returns, so live
    BMesh lookups must re-enter edit mode for the captured objects rather than
    falling back to stale loop references.
    """
    try:
        import bpy  # type: ignore
    except Exception:
        return
    objects = []
    seen = set()
    for obj in snapshot.get("objects") or ():
        try:
            if obj is None or getattr(obj, "type", "") != "MESH":
                continue
            key = id(getattr(obj, "data", obj))
            if key in seen:
                continue
            seen.add(key)
            objects.append(obj)
        except Exception:
            continue
    if not objects:
        return
    try:
        view_layer = getattr(getattr(context, "view_layer", None), "objects", None)
        if view_layer is None:
            view_layer = getattr(getattr(bpy.context, "view_layer", None), "objects", None)
        needs_mode_switch = not all(str(getattr(obj, "mode", "") or "") == "EDIT" for obj in objects)
        if needs_mode_switch:
            try:
                bpy.ops.object.mode_set(mode="OBJECT")
            except Exception:
                pass
        for obj in objects:
            try:
                obj.select_set(True)
            except Exception:
                pass
        try:
            view_layer.active = objects[0]
        except Exception:
            pass
        if needs_mode_switch or not all(str(getattr(obj, "mode", "") or "") == "EDIT" for obj in objects):
            try:
                bpy.ops.object.mode_set(mode="EDIT")
            except Exception:
                pass
    except Exception:
        return


def _mesh_uv_layer_for_record(rec: Dict[str, Any]) -> Any:
    try:
        mesh = rec.get("mesh")
        if mesh is None:
            return None
        layers = getattr(mesh, "uv_layers", None)
        if layers is None:
            return None
        name = str(rec.get("uv_layer_name") or "")
        if name:
            try:
                layer = layers.get(name)
                if layer is not None:
                    return layer
            except Exception:
                pass
        try:
            return layers.active
        except Exception:
            return None
    except Exception:
        return None


def _mesh_loop_index_for_record(rec: Dict[str, Any]) -> int:
    stable_loop = -1
    stable_face = -1
    stable_local = -1
    try:
        stable = tuple(rec.get("stable") or ())
        if len(stable) > 2:
            stable_face = int(stable[1])
            stable_local = int(stable[2])
        if len(stable) > 3:
            stable_loop = int(stable[3])
    except Exception:
        stable_loop = -1
    # Blender 5.1 BMLoop.index can be positive but not the stable Mesh loop
    # index.  Face/local topology is the only authoritative mapping between a
    # captured edit-loop record and Mesh UV data, so prefer polygon.loop_indices
    # before any stored BMesh loop index.
    try:
        mesh = rec.get("mesh")
        polygons = getattr(mesh, "polygons", None)
        if polygons is not None and stable_face >= 0 and stable_local >= 0 and stable_face < len(polygons):
            loop_indices = list(getattr(polygons[stable_face], "loop_indices", ()) or ())
            if stable_local < len(loop_indices):
                index = int(loop_indices[stable_local])
                if index >= 0:
                    return index
    except Exception:
        pass
    for value in (
        rec.get("loop_index"),
        stable_loop,
    ):
        try:
            index = int(value)
            if index >= 0:
                return index
        except Exception:
            continue
    return -1


def _write_sticky_record_mesh_target(rec: Dict[str, Any], target: Tuple[float, float], eps2: float) -> int:
    try:
        layer = _mesh_uv_layer_for_record(rec)
        index = _mesh_loop_index_for_record(rec)
        data = getattr(layer, "data", None) if layer is not None else None
        if data is not None and index >= 0 and index < len(data):
            uv = data[index].uv
            current = (float(uv.x), float(uv.y))
            if (current[0] - target[0]) ** 2 + (current[1] - target[1]) ** 2 > eps2:
                uv.x = target[0]
                uv.y = target[1]
                wrote_mesh = 1
                try:
                    mesh = rec.get("mesh")
                    if mesh is not None:
                        mesh.update()
                except Exception:
                    pass
                return 1
    except Exception:
        pass
    return 0


def _write_sticky_record_target(rec: Dict[str, Any], target: Tuple[float, float], eps2: float) -> int:
    """Write one captured record through live BMesh and Mesh UV data.

    Blender edit mode can flush BMesh back to Mesh data after this function
    returns.  The caller therefore reapplies Mesh writes after
    ``bmesh.update_edit_mesh`` as the final authority.
    """
    wrote_bmesh = 0
    try:
        loop, uv_layer = _resolve_sticky_record_loop_18194(rec)
        if loop is not None and uv_layer is not None:
            current = _uv_xy(loop, uv_layer)
            if (float(current[0]) - target[0]) ** 2 + (float(current[1]) - target[1]) ** 2 > eps2:
                uv = loop[uv_layer].uv
                uv.x = target[0]
                uv.y = target[1]
                wrote_bmesh = 1
    except Exception:
        wrote_bmesh = 0
    wrote_mesh = _write_sticky_record_mesh_target(rec, target, eps2)
    return 1 if (wrote_mesh or wrote_bmesh) else 0


def _read_sticky_record_current(rec: Dict[str, Any]) -> Optional[Tuple[float, float]]:
    """Read current UV from both Mesh UV data and live BMesh.

    Different public align/flow paths commit to different authorities before
    returning.  The public Straighten/Flow operators write Mesh UV data; use
    the captured Mesh UV layer name as the first authority, then fall back to
    live BMesh for operators that have not flushed to Mesh yet.
    """
    initial = None
    try:
        raw = rec.get("initial")
        initial = (float(raw[0]), float(raw[1]))
    except Exception:
        initial = None
    candidates: List[Tuple[float, float]] = []
    try:
        layer = _mesh_uv_layer_for_record(rec)
        index = _mesh_loop_index_for_record(rec)
        data = getattr(layer, "data", None) if layer is not None else None
        if data is None or index < 0 or index >= len(data):
            raise LookupError("mesh uv record unavailable")
        uv = data[index].uv
        candidates.append((float(uv.x), float(uv.y)))
    except Exception:
        pass
    try:
        loop, uv_layer = _resolve_sticky_record_loop_18194(rec)
        if loop is not None and uv_layer is not None:
            candidates.append(_uv_xy(loop, uv_layer))
    except Exception:
        pass
    if not candidates:
        return None
    if initial is not None:
        eps2 = 1.0e-16
        for current in candidates:
            try:
                du = float(current[0]) - initial[0]
                dv = float(current[1]) - initial[1]
                if du * du + dv * dv > eps2:
                    return current
            except Exception:
                continue
    return candidates[0]


def _restore_sticky_postcondition(snapshot: Optional[Dict[str, Any]], context: Any = None) -> int:
    if not isinstance(snapshot, dict):
        return 0
    _ensure_snapshot_edit_context(snapshot, context)
    restore_edit_mode = False
    try:
        import bpy  # type: ignore
        objects = [obj for obj in (snapshot.get("objects") or ()) if obj is not None]
        restore_edit_mode = any(str(getattr(obj, "mode", "") or "") == "EDIT" for obj in objects)
        if restore_edit_mode:
            try:
                bpy.ops.object.mode_set(mode="OBJECT")
            except Exception:
                restore_edit_mode = False
    except Exception:
        restore_edit_mode = False
    sticky = str(snapshot.get("sticky") or "DISABLED").upper()
    try:
        changed = 0
        eps2 = 1.0e-16
        final_targets: List[Tuple[Dict[str, Any], Tuple[float, float]]] = []
        for records in (snapshot.get("classes") or {}).values():
            moved_sources: List[Tuple[Any, Dict[str, Any], Tuple[float, float]]] = []
            moved_any: List[Tuple[Any, Dict[str, Any], Tuple[float, float]]] = []
            for rec in records or []:
                try:
                    current = _read_sticky_record_current(rec)
                    if current is None:
                        continue
                    initial = rec["initial"]
                    du = float(current[0]) - float(initial[0])
                    dv = float(current[1]) - float(initial[1])
                    if du * du + dv * dv > eps2:
                        rank = (int(rec.get("source_priority", 2)), tuple(rec.get("stable") or ()))
                        if rec.get("source"):
                            moved_sources.append((rank, rec, current))
                        moved_any.append((rank, rec, current))
                except Exception:
                    continue
            if not moved_sources and not moved_any:
                continue
            anchor_pool = moved_sources if moved_sources else moved_any
            _rank, anchor, anchor_final = min(anchor_pool, key=lambda item: item[0])
            anchor_initial = anchor["initial"]
            delta = (
                float(anchor_final[0]) - float(anchor_initial[0]),
                float(anchor_final[1]) - float(anchor_initial[1]),
            )
            for rec in records or []:
                try:
                    if sticky == "SHARED_VERTEX":
                        # Preserve intentional seam offsets.  Coincident members
                        # remain coincident because every member receives one delta.
                        target = (
                            float(rec["initial"][0]) + delta[0],
                            float(rec["initial"][1]) + delta[1],
                        )
                    else:
                        target = (float(anchor_final[0]), float(anchor_final[1]))
                    final_targets.append((rec, target))
                    changed += _write_sticky_record_target(rec, target, eps2)
                except Exception:
                    continue
        if changed or final_targets:
            _update(snapshot.get("meshes") or ())
            for rec, target in final_targets:
                try:
                    changed += _write_sticky_record_mesh_target(rec, target, eps2)
                except Exception:
                    continue
        return changed
    finally:
        if restore_edit_mode:
            try:
                import bpy  # type: ignore
                for obj in (snapshot.get("objects") or ()):
                    try:
                        obj.select_set(True)
                    except Exception:
                        pass
                bpy.ops.object.mode_set(mode="EDIT")
            except Exception:
                pass


def _execute_with_sticky_postcondition(self: Any, context: Any) -> set:
    previous = _backend_attr(self, _STICKY_PREV_ATTR)
    if not callable(previous):
        return {"CANCELLED"}
    old_active = old_mode = None
    changed_mode = False
    restored_context = False
    try:
        old_active, old_mode, _objs, changed_mode = _enter_edit_context(context)
        snapshot = _capture_sticky_postcondition(context)
        result = previous(self, context)
        if isinstance(result, set) and "FINISHED" in result:
            # Some line/flow paths publish their edit result only when the
            # operator restores mode/context.  Restore once before reading the
            # moved anchors, then the postcondition re-enters edit mode and
            # applies the final sticky authority.
            try:
                _restore_edit_context(context, old_active, str(old_mode or "OBJECT"), changed_mode)
                restored_context = True
            except Exception:
                pass
            _restore_sticky_postcondition(snapshot, context)
            try:
                _restore_edit_context(context, old_active, str(old_mode or "OBJECT"), changed_mode)
                restored_context = True
            except Exception:
                pass
        return result
    finally:
        if not restored_context:
            try:
                _restore_edit_context(context, old_active, str(old_mode or "OBJECT"), changed_mode)
            except Exception:
                pass


def _wrap_sticky_postconditions(ns: Dict[str, Any]) -> None:
    for name, cls in _iter_sticky_target_classes(ns):
        current = getattr(cls, "execute", None)
        if current is _execute_with_sticky_postcondition or not callable(current):
            continue
        setattr(cls, _STICKY_PREV_ATTR, current)
        cls.execute = _execute_with_sticky_postcondition


def _unwrap_sticky_postconditions(ns: Dict[str, Any]) -> None:
    for name, cls in reversed(tuple(_iter_sticky_target_classes(ns))):
        previous = getattr(cls, _STICKY_PREV_ATTR, None)
        if callable(previous) and getattr(cls, "execute", None) is _execute_with_sticky_postcondition:
            cls.execute = previous
        try:
            delattr(cls, _STICKY_PREV_ATTR)
        except Exception:
            pass


def _backend_class_for_instance(self: Any) -> type | None:
    cls = type(self)
    proxy_cls = getattr(self, "_smart_uv_1897_backend_class", None)
    if isinstance(proxy_cls, type):
        try:
            name = str(getattr(proxy_cls, "__name__", "") or "")
            op_id = str(getattr(proxy_cls, "bl_idname", "") or "")
        except Exception:
            name = ""
            op_id = ""
        try:
            if name and _NS.get(name) is proxy_cls:
                return proxy_cls
        except Exception:
            pass
        try:
            for _label, target_cls in _iter_sticky_target_classes(_NS):
                if target_cls is proxy_cls:
                    return proxy_cls
        except Exception:
            pass
        if op_id in set(_STICKY_TARGET_IDS.values()):
            try:
                registered = getattr(getattr(bpy.ops, op_id.split(".", 1)[0]), op_id.split(".", 1)[1]).get_rna_type()
                if getattr(registered, "bl_rna", registered) is proxy_cls:
                    return proxy_cls
            except Exception:
                pass
        return None
    return cls


def _backend_attr(self: Any, attr_name: str) -> Any:
    cls = _backend_class_for_instance(self)
    if not isinstance(cls, type):
        return None
    try:
        return getattr(cls, str(attr_name), None)
    except Exception:
        return None


def _iter_sticky_target_classes(ns: Dict[str, Any]) -> List[Tuple[str, type]]:
    """Resolve both module aliases and the actually registered RNA classes.

    The line/flow operators are late dynamic classes.  In reload/package-upgrade
    paths Blender can keep the registered RNA class object distinct from the
    public alias stored in ``__init__.py``.  The UI and final manifest may inspect
    the alias while ``bpy.ops`` executes the registered class, so the sticky
    postcondition has to patch the exact public operator id as well as the alias.
    """
    found: List[Tuple[str, type]] = []
    seen: Set[int] = set()

    def add(name: str, cls: Any) -> None:
        if not isinstance(cls, type):
            return
        key = id(cls)
        if key in seen:
            return
        seen.add(key)
        found.append((name, cls))

    for name in _STICKY_TARGET_CLASSES:
        add(name, ns.get(name))

    try:
        from . import ownership_runtime_18168 as _ownership
        for cls in _ownership.registered_classes():
            try:
                op_id = str(getattr(cls, "bl_idname", "") or "")
            except Exception:
                op_id = ""
            if op_id in _STICKY_TARGET_IDS.values():
                add(str(getattr(cls, "__name__", "") or op_id), cls)
    except Exception:
        pass

    try:
        operator_base = getattr(getattr(bpy, "types", None), "Operator", None)
        lookup = getattr(operator_base, "bl_rna_get_subclass_py", None)
        if callable(lookup):
            for name in _STICKY_TARGET_CLASSES:
                add(name, lookup(name))
    except Exception:
        pass

    return found


def _execute_group(self: Any, context: Any) -> set:
    raw = str(getattr(self, "action", "") or "").upper()
    prev = _backend_attr(self, _PREV_ATTR)
    if raw not in _GROUP_ACTIONS:
        if callable(prev):
            return prev(self, context)
        return {"CANCELLED"}
    saved_sticky = _raw_sticky(context)
    old_active, old_mode, objs, changed_mode = _enter_edit_context(context)
    if not objs:
        try:
            self.report({"WARNING"}, _txt(context, "No mesh object is active.", "アクティブなメッシュオブジェクトがありません。"))
        except Exception:
            pass
        return {"CANCELLED"}
    try:
        sticky = _sticky(context)
        mode = _uv_mode(context)
        components, meshes = _collect_group_components(context, mode, sticky)
        if not components:
            try:
                self.report({"WARNING"}, _txt(context, "No current UV edges, faces, or vertices are selected.", "現在選択されているUV頂点・辺・面がありません。"))
            except Exception:
                pass
            return {"CANCELLED"}
        action = raw[:-6]
        changed = 0
        for points in components:
            if points:
                changed += _apply(points, action)
        if changed > 0:
            _update(meshes)
        return {"FINISHED"}
    except Exception as exc:
        try:
            self.report({"WARNING"}, _txt(context, "Grouped vertex direction align failed.", "グループ方向整列に失敗しました。") + f" {exc}")
        except Exception:
            pass
        return {"CANCELLED"}
    finally:
        # The grouped align backend only reads sticky selection mode.  Restore it
        # defensively so older wrappers or Blender-native side effects cannot leave
        # the dropdown changed from Shared Location / Shared Vertex to Disabled.
        _set_raw_sticky(context, saved_sticky)
        _restore_edit_context(context, old_active, old_mode, changed_mode)
        _set_raw_sticky(context, saved_sticky)


def install(ns: Dict[str, Any], context: Any = None) -> None:
    global _NS
    _NS = ns
    cls = ns.get("SMARTUVSUITE_OT_vertex_align_action")
    if not isinstance(cls, type):
        return
    current = getattr(cls, "execute", None)
    if getattr(cls, _PREV_ATTR, None) is None and callable(current) and current is not _execute_group:
        try:
            setattr(cls, _PREV_ATTR, current)
        except Exception:
            pass
    try:
        cls.execute = _execute_group
    except Exception:
        pass
    _wrap_sticky_postconditions(ns)
    try:
        ns["_sus_1897_group_direction_align_installed"] = True
    except Exception:
        pass


def apply_all(ns: Dict[str, Any], context: Any = None) -> None:
    install(ns, context)


def unregister() -> None:
    try:
        import sys
        pkg = __package__ or "smart_uv_suite"
        mod = sys.modules.get(pkg)
        ns = getattr(mod, "__dict__", {}) if mod is not None else {}
        _unwrap_sticky_postconditions(ns)
        cls = ns.get("SMARTUVSUITE_OT_vertex_align_action")
        if isinstance(cls, type):
            prev = getattr(cls, _PREV_ATTR, None)
            if callable(prev):
                cls.execute = prev
            try:
                delattr(cls, _PREV_ATTR)
            except Exception:
                pass
    except Exception:
        pass
