"""Implement the inspect sync public UV operations."""

import bpy


def inspect_sync_mode_toggle(context, op):
    return 'FINISHED' in bpy.ops.uv.suv_uv_sync_mode_toggle(mode=op.mode or 'TOGGLE')


def build_handlers(api):
    return {

        "smart_uv_suite.inspect_sync_mode_toggle": api.Handler(inspect_sync_mode_toggle, 'Toggle UV sync selection or explicitly set it on or off.', 'UV同期選択を切り替えるか、オン・オフを指定します。'),

    }
