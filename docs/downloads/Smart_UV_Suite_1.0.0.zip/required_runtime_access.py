# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Deterministic required Smart UV operator registration.

The canonical package classes are preferred.  Compatibility classes remain as
explicit aliases for old Python imports but are registered only when the
canonical implementation is unavailable.  No broad bpy.types/sys.modules
search, collision eviction, or foreign unregister is performed.
"""
from __future__ import annotations

from typing import Any

import bpy
from bpy.props import StringProperty

from . import ownership_runtime_18168 as _ownership

_PACKAGE_GLOBALS: dict[str, Any] | None = None
_REGISTERED: list[type] = []

REQUIRED_OPERATOR_IDS = (
    "smart_uv_suite.scale_tool_background_select",
    "smart_uv_suite.uv_gizmo_grip_fix_grab",
    "smart_uv_suite.instant_select_drag_move",
)
REQUIRED_CLASS_NAMES = (
    "SMARTUVSUITE_OT_scale_tool_background_select",
    "JELARARAGI_OT_uv_gizmo_grip_fix_grab",
    "SMARTUVSUITE_OT_instant_select_drag_move",
)


class SMARTUVSUITE_OT_scale_tool_background_select(bpy.types.Operator):
    """Compatibility alias used only if the canonical interaction class is absent."""
    bl_idname = "smart_uv_suite.scale_tool_background_select"
    bl_label = "Scale Tool Background Select"
    bl_description = "Start native UV box selection without changing the active UV tool. / 現在のUVツールを変更せず標準UVボックス選択を開始します。"
    bl_options = {'UNDO'}

    mode: StringProperty(default="SET")

    @classmethod
    def poll(cls, context):
        return bool(
            getattr(getattr(context, "area", None), "type", "") == "IMAGE_EDITOR"
            and getattr(context, "edit_object", None) is not None
        )

    def invoke(self, context, event):
        try:
            from . import interaction_1872 as _interaction
            return _interaction._invoke_native_uv_select_box(context, event)
        except Exception:
            return {"CANCELLED"}


class JELARARAGI_OT_uv_gizmo_grip_fix_grab(bpy.types.Operator):
    """Compatibility alias used only if the canonical gizmo class is absent."""
    bl_idname = "smart_uv_suite.uv_gizmo_grip_fix_grab"
    bl_label = "UV Gizmo Grip Fix"
    bl_description = "Invoke the canonical Smart UV gizmo grip operator. / Smart UVの正規ギズモつかみ補助を実行します。"
    bl_options = {'UNDO', 'BLOCKING'}

    @classmethod
    def poll(cls, context):
        return bool(getattr(getattr(context, "area", None), "type", "") == "IMAGE_EDITOR")

    def invoke(self, context, event):
        del context, event
        return {"CANCELLED"}


def _literal_id(cls: Any) -> str:
    try:
        return str(getattr(cls, "bl_idname", "") or "")
    except Exception:
        return ""


def _canonical_classes(package_globals: dict[str, Any] | None) -> tuple[type, ...]:
    package_globals = package_globals if isinstance(package_globals, dict) else {}
    live_by_id = {}
    for registered_cls in tuple(_REGISTERED):
        try:
            registered_id = _literal_id(registered_cls)
            if registered_id and bool(getattr(registered_cls, "is_registered", False)):
                live_by_id[registered_id] = registered_cls
        except Exception:
            continue
    try:
        from . import interaction_1872 as _interaction
    except Exception:
        _interaction = None
    try:
        from . import uv_gizmo_grip_fix as _gizmo
    except Exception:
        _gizmo = None

    # The legacy public register chain installs the interaction/gizmo classes
    # before this required-surface check.  Prefer those exact canonical module
    # identities so a same-id package-global compatibility alias cannot collide
    # with the class that is already registered and owned by this generation.
    candidates = (
        getattr(_interaction, "SMARTUVSUITE_OT_scale_tool_background_select", None)
        or package_globals.get("SMARTUVSUITE_OT_scale_tool_background_select")
        or SMARTUVSUITE_OT_scale_tool_background_select,
        getattr(_gizmo, "JELARARAGI_OT_uv_gizmo_grip_fix_grab", None)
        or package_globals.get("JELARARAGI_OT_uv_gizmo_grip_fix_grab")
        or JELARARAGI_OT_uv_gizmo_grip_fix_grab,
        package_globals.get("SMARTUVSUITE_OT_instant_select_drag_move"),
    )
    out = []
    seen = set()
    for expected_id, cls in zip(REQUIRED_OPERATOR_IDS, candidates):
        cls = live_by_id.get(expected_id) or cls
        if not isinstance(cls, type) or _literal_id(cls) != expected_id:
            raise RuntimeError(f"Required Smart UV class unresolved: {expected_id}")
        if id(cls) in seen:
            raise RuntimeError(f"Required Smart UV class identity duplicated: {expected_id}")
        seen.add(id(cls)); out.append(cls)
    return tuple(out)


def install(package_globals: dict[str, Any] | None = None) -> tuple[type, ...]:
    global _PACKAGE_GLOBALS
    if isinstance(package_globals, dict):
        _PACKAGE_GLOBALS = package_globals
    classes = _canonical_classes(_PACKAGE_GLOBALS)
    registered_now: list[type] = []
    listed_now: list[type] = []
    try:
        for cls in classes:
            try:
                already_registered = bool(getattr(cls, "is_registered", False))
            except Exception:
                already_registered = False
            # The legacy public surface owns these exact implementation class
            # objects and normally registers them immediately before this
            # required-surface verifier runs.  Re-registering the same class is
            # an error in Blender; accept the exact live identity and register
            # only a class that is genuinely absent.
            if not already_registered:
                if not _ownership.register_class(cls):
                    raise RuntimeError(f"Required Smart UV operator registration failed: {_literal_id(cls)}")
                registered_now.append(cls)
            if cls not in _REGISTERED:
                _REGISTERED.append(cls)
                listed_now.append(cls)
        verify_registered(classes)
        return classes
    except Exception:
        for cls in reversed(registered_now):
            _ownership.unregister_class(cls)
        for cls in reversed(listed_now):
            try:
                _REGISTERED.remove(cls)
            except ValueError:
                pass
        raise


def verify_registered(classes: tuple[type, ...] | None = None) -> dict[str, bool]:
    classes = classes or _canonical_classes(_PACKAGE_GLOBALS)
    result = {}
    for expected_id, cls in zip(REQUIRED_OPERATOR_IDS, classes):
        try:
            result[expected_id] = bool(getattr(cls, "is_registered", False))
        except Exception:
            result[expected_id] = False
    missing = [key for key, value in result.items() if not value]
    if missing:
        raise RuntimeError("Required Smart UV operators unavailable: " + ", ".join(missing))
    return result


def uninstall(package_globals: dict[str, Any] | None = None) -> None:
    del package_globals
    for cls in reversed(tuple(_REGISTERED)):
        _ownership.unregister_class(cls)
    _REGISTERED.clear()


def register() -> None:
    install(_PACKAGE_GLOBALS)


def unregister() -> None:
    uninstall(_PACKAGE_GLOBALS)
