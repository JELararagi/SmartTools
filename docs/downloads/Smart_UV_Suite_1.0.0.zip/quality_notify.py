
from __future__ import annotations

_NOTICE_CACHE_KEY = '_suv_quality_notice_cache'


def _cache(namespace: dict) -> dict:
    data = namespace.get(_NOTICE_CACHE_KEY)
    if not isinstance(data, dict):
        data = {}
        namespace[_NOTICE_CACHE_KEY] = data
    return data


def clear_notice_cache(namespace: dict):
    cache = _cache(namespace)
    cache.clear()
    namespace['_suv_quality_notice_cache_total'] = 0
    return 0


def remember_notice(namespace: dict, key: str, value=True):
    cache = _cache(namespace)
    cache[str(key)] = value
    namespace['_suv_quality_notice_cache_total'] = len(cache)
    return len(cache)


def has_notice(namespace: dict, key: str) -> bool:
    cache = _cache(namespace)
    return str(key) in cache


def report_once(namespace: dict, self, context, level: set[str], cache_key: str, message: str):
    if has_notice(namespace, cache_key):
        return False
    fn = getattr(self, 'report', None)
    if callable(fn):
        try:
            fn(level, message)
        except Exception:
            return False
    remember_notice(namespace, cache_key, True)
    return True
