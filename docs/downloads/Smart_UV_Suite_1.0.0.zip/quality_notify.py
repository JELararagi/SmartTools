# SPDX-License-Identifier: GPL-3.0-or-later
"""Remember which setup notices were shown during this UV session."""

_CACHE = "_suv_quality_notice_cache"
_COUNT = "_suv_quality_notice_cache_total"


def _notices(namespace):
    existing = namespace.get(_CACHE)
    if not isinstance(existing, dict):
        existing = {}
        namespace[_CACHE] = existing
    return existing


def clear_notice_cache(namespace):
    _notices(namespace).clear()
    namespace[_COUNT] = 0
    return 0


def remember_notice(namespace, key, value=True):
    notices = _notices(namespace)
    notices[str(key)] = value
    namespace[_COUNT] = len(notices)
    return namespace[_COUNT]


def has_notice(namespace, key):
    return str(key) in _notices(namespace)


def report_once(namespace, self, context, level, cache_key, message):
    if has_notice(namespace, cache_key):
        return False
    report = getattr(self, "report", None)
    if callable(report):
        try:
            report(level, message)
        except Exception:
            return False
    remember_notice(namespace, cache_key)
    return True

