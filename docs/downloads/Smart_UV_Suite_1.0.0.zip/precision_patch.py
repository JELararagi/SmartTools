import math

from . import core as _core
from . import legacy_operators as _legacy
from . import pro_operators as _pro
from . import symmetry_atlas_operators as _sym
from . import ui as _ui
from . import flow as _flow
from . import addon_runtime as _tool_runtime

import bpy
import bmesh
from mathutils import Vector

try:
    from mathutils.kdtree import KDTree
except Exception:
    KDTree = None

_PATCH_MODULES = (_core, _legacy, _pro, _sym, _ui, _flow, _tool_runtime)


def _patch_name(name, value):
    for mod in _PATCH_MODULES:
        try:
            if hasattr(mod, name):
                setattr(mod, name, value)
        except Exception:
            pass


def _wrap_angle_pi(angle: float) -> float:
    while angle < 0.0:
        angle += math.pi
    while angle >= math.pi:
        angle -= math.pi
    return angle


def _wrap_angle_tau(angle: float) -> float:
    while angle < 0.0:
        angle += math.tau
    while angle >= math.tau:
        angle -= math.tau
    return angle


def _quant2(v: Vector, digits: int = 8):
    return (round(float(v.x), digits), round(float(v.y), digits))


# -----------------------------------------------------------------------------
# Precise oriented bounding box angle
# -----------------------------------------------------------------------------

def _convex_hull_2d(points):
    pts = sorted({(float(p.x), float(p.y)) for p in points})
    if len(pts) <= 1:
        return [Vector(pts[0])] if pts else []

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

    lower = []
    for p in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 1.0e-12:
            lower.pop()
        lower.append(p)

    upper = []
    for p in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 1.0e-12:
            upper.pop()
        upper.append(p)

    hull = lower[:-1] + upper[:-1]
    return [Vector(p) for p in hull]


def _precise_best_bbox_angle(isl, step_deg: int = 15) -> float:
    pts = [Vector(p) for p in getattr(isl, 'uv_points', [])]
    if len(pts) < 2:
        return 0.0

    hull = _convex_hull_2d(pts)
    if len(hull) < 2:
        return 0.0

    base_angles = {0.0}
    for i in range(len(hull)):
        edge = hull[(i + 1) % len(hull)] - hull[i]
        if edge.length_squared <= 1.0e-18:
            continue
        ang = -math.atan2(edge.y, edge.x)
        base_angles.add(_wrap_angle_pi(ang))
        base_angles.add(_wrap_angle_pi(ang + math.pi * 0.5))

    if step_deg <= 1:
        candidates = sorted(base_angles)
    else:
        q = math.radians(max(1, int(step_deg)))
        quantized = set()
        for ang in base_angles:
            unit = ang / q
            for offset in (-1, 0, 1):
                quantized.add(_wrap_angle_pi(round(unit + offset) * q))
        candidates = sorted(quantized)

    best = None
    for ang in candidates:
        bmin, bmax = _core._island_bbox_after_rotation(isl, ang)
        sx, sy = _core._bbox_size(bmin, bmax)
        area = sx * sy
        score = (
            float(area),
            float(max(sx, sy)),
            float(min(sx, sy)),
            float(abs(ang)),
        )
        if best is None or score < best[0]:
            best = (score, ang)
    return best[1] if best else 0.0


# -----------------------------------------------------------------------------
# Better deterministic packer (MaxRects style)
# -----------------------------------------------------------------------------

def _pack_rotation_candidates(isl, rot_step_deg: int, allow_rotate: bool):
    if not allow_rotate:
        angles = [0.0]
    elif rot_step_deg <= 0:
        ideal = _precise_best_bbox_angle(isl, step_deg=1)
        angles = [ideal, _wrap_angle_pi(ideal + math.pi * 0.5)]
    else:
        step = math.radians(max(1, int(rot_step_deg)))
        count = max(1, int(round(math.pi / step)))
        angles = [_wrap_angle_pi(i * step) for i in range(count)]

    seen = set()
    out = []
    for ang in angles:
        ang = _wrap_angle_pi(float(ang))
        bmin, bmax = _core._island_bbox_after_rotation(isl, ang)
        w, h = _core._bbox_size(bmin, bmax)
        key = (round(float(w), 8), round(float(h), 8), round(float(ang), 8))
        if key in seen:
            continue
        seen.add(key)
        out.append({
            'angle': ang,
            'bmin': Vector(bmin),
            'bmax': Vector(bmax),
            'w': float(max(0.0, w)),
            'h': float(max(0.0, h)),
            'area': float(max(0.0, w * h)),
        })
    out.sort(key=lambda item: (item['area'], max(item['w'], item['h']), min(item['w'], item['h'])))
    return out or [{'angle': 0.0, 'bmin': Vector((0.0, 0.0)), 'bmax': Vector((0.0, 0.0)), 'w': 0.0, 'h': 0.0, 'area': 0.0}]


def _rect_contains(a, b, eps=1.0e-12):
    return (
        b[0] >= a[0] - eps and
        b[1] >= a[1] - eps and
        b[0] + b[2] <= a[0] + a[2] + eps and
        b[1] + b[3] <= a[1] + a[3] + eps
    )


def _rect_intersects(a, b, eps=1.0e-12):
    return not (
        a[0] + a[2] <= b[0] + eps or
        b[0] + b[2] <= a[0] + eps or
        a[1] + a[3] <= b[1] + eps or
        b[1] + b[3] <= a[1] + eps
    )


def _maxrects_prune(rects):
    filtered = []
    for i, rect in enumerate(rects):
        if rect[2] <= 1.0e-12 or rect[3] <= 1.0e-12:
            continue
        contained = False
        for j, other in enumerate(rects):
            if i == j:
                continue
            if _rect_contains(other, rect):
                contained = True
                break
        if not contained:
            filtered.append(rect)
    return filtered


def _maxrects_split(free_rect, used_rect):
    if not _rect_intersects(free_rect, used_rect):
        return [free_rect]

    fx, fy, fw, fh = free_rect
    ux, uy, uw, uh = used_rect

    # This packer always places the used rect at the free-rect origin.
    # Use a guillotine-style non-overlapping split so free space never double-counts.
    rem_w = max(0.0, fw - uw)
    rem_h = max(0.0, fh - uh)
    out = []
    if rem_w >= rem_h:
        if rem_w > 1.0e-12:
            out.append((fx + uw, fy, rem_w, fh))
        if rem_h > 1.0e-12:
            out.append((fx, fy + uh, uw, rem_h))
    else:
        if rem_h > 1.0e-12:
            out.append((fx, fy + uh, fw, rem_h))
        if rem_w > 1.0e-12:
            out.append((fx + uw, fy, rem_w, uh))
    return [r for r in out if r[2] > 1.0e-12 and r[3] > 1.0e-12]


def _maxrects_update(free_rects, used_rect):
    new_rects = []
    for rect in free_rects:
        new_rects.extend(_maxrects_split(rect, used_rect))
    return _maxrects_prune(new_rects)


def _find_best_rect_placement(free_rects, candidates, margin_uv: float):
    best = None
    for rect in free_rects:
        rx, ry, rw, rh = rect
        for cand in candidates:
            bw = cand['w'] + margin_uv * 2.0
            bh = cand['h'] + margin_uv * 2.0
            if bw > rw + 1.0e-12 or bh > rh + 1.0e-12:
                continue
            short_fit = min(rw - bw, rh - bh)
            long_fit = max(rw - bw, rh - bh)
            area_fit = rw * rh - bw * bh
            score = (
                float(short_fit),
                float(long_fit),
                float(area_fit),
                float(abs((rw - bw) - (rh - bh))),
            )
            if best is None or score < best['score']:
                best = {
                    'score': score,
                    'rect': rect,
                    'cand': cand,
                    'used': (rx, ry, bw, bh),
                }
    return best


def _pack_shelf_maxrects(islands, margin_uv: float, rot_step_deg: int, allow_rotate: bool):
    records = []
    for isl in islands:
        candidates = _pack_rotation_candidates(isl, rot_step_deg, allow_rotate)
        primary = min(candidates, key=lambda c: (c['area'], max(c['w'], c['h']), min(c['w'], c['h'])))
        records.append((-(primary['area']), -max(primary['w'], primary['h']), -min(primary['w'], primary['h']), isl, candidates))
    records.sort()

    placements = {}
    free_rects = [(0.0, 0.0, 1.0, 1.0)]

    for _neg_area, _neg_w, _neg_h, isl, candidates in records:
        placement = _find_best_rect_placement(free_rects, candidates, margin_uv)
        if placement is None:
            return placements, False
        cand = placement['cand']
        rx, ry, _rw, _rh = placement['rect']
        target_min = Vector((rx + margin_uv, ry + margin_uv))
        delta = target_min - cand['bmin']
        placements[isl.id] = {
            'angle': cand['angle'],
            'bmin': Vector(cand['bmin']),
            'bmax': Vector(cand['bmax']),
            'dx': float(delta.x),
            'dy': float(delta.y),
        }
        free_rects = _maxrects_update(free_rects, placement['used'])

    return placements, True


def _pack_multi_tiles_maxrects(islands, margin_uv: float, rot_step_deg: int, allow_rotate: bool):
    records = []
    for isl in islands:
        candidates = _pack_rotation_candidates(isl, rot_step_deg, allow_rotate)
        primary = min(candidates, key=lambda c: (c['area'], max(c['w'], c['h']), min(c['w'], c['h'])))
        records.append((-(primary['area']), -max(primary['w'], primary['h']), -min(primary['w'], primary['h']), isl, candidates))
    records.sort()

    placements = {}
    tile_free_rects = [[(0.0, 0.0, 1.0, 1.0)]]

    for _neg_area, _neg_w, _neg_h, isl, candidates in records:
        best = None
        best_tile = None
        for tile_index, free_rects in enumerate(tile_free_rects):
            placement = _find_best_rect_placement(free_rects, candidates, margin_uv)
            if placement is None:
                continue
            score = placement['score'] + (tile_index,)
            if best is None or score < best['score']:
                best = {'score': score, 'tile_index': tile_index, 'placement': placement}
                best_tile = tile_index

        if best is None:
            tile_free_rects.append([(0.0, 0.0, 1.0, 1.0)])
            best_tile = len(tile_free_rects) - 1
            placement = _find_best_rect_placement(tile_free_rects[best_tile], candidates, margin_uv)
            if placement is None:
                cand = min(candidates, key=lambda c: (c['area'], max(c['w'], c['h']), min(c['w'], c['h'])))
                placements[isl.id] = {
                    'angle': cand['angle'],
                    'bmin': Vector(cand['bmin']),
                    'bmax': Vector(cand['bmax']),
                    'dx': float(margin_uv - cand['bmin'].x),
                    'dy': float(margin_uv - cand['bmin'].y),
                    'tile_index': int(best_tile),
                }
                continue
            best = {'tile_index': best_tile, 'placement': placement}

        placement = best['placement']
        cand = placement['cand']
        rx, ry, _rw, _rh = placement['rect']
        target_min = Vector((rx + margin_uv, ry + margin_uv))
        delta = target_min - cand['bmin']
        placements[isl.id] = {
            'angle': cand['angle'],
            'bmin': Vector(cand['bmin']),
            'bmax': Vector(cand['bmax']),
            'dx': float(delta.x),
            'dy': float(delta.y),
            'tile_index': int(best['tile_index']),
        }
        tile_free_rects[best['tile_index']] = _maxrects_update(tile_free_rects[best['tile_index']], placement['used'])

    return placements


# -----------------------------------------------------------------------------
# More robust symmetry map / pair detection
# -----------------------------------------------------------------------------

def _axis_signature(v):
    edge_lengths = []
    boundary_edges = 0
    for e in getattr(v, 'link_edges', []):
        try:
            edge_lengths.append(float(e.calc_length()))
        except Exception:
            pass
        if len(getattr(e, 'link_faces', [])) < 2:
            boundary_edges += 1
    edge_lengths.sort()
    sample = tuple(round(val, 6) for val in edge_lengths[:4])
    return (
        int(len(getattr(v, 'link_edges', []))),
        int(len(getattr(v, 'link_faces', []))),
        int(boundary_edges),
        sample,
    )


def _precise_build_mirror_map(obj, bm, axis='X', space='LOCAL', offset=0.0, tol=1.0e-4):
    idx = _core._axis_index(axis)
    coords = []
    signatures = []
    buckets = {}

    mins = Vector((1.0e18, 1.0e18, 1.0e18))
    maxs = Vector((-1.0e18, -1.0e18, -1.0e18))

    for v in bm.verts:
        co = v.co.copy()
        if space == 'WORLD':
            co = obj.matrix_world @ co
        coords.append(co)
        signatures.append(_axis_signature(v))
        mins.x = min(mins.x, co.x); mins.y = min(mins.y, co.y); mins.z = min(mins.z, co.z)
        maxs.x = max(maxs.x, co.x); maxs.y = max(maxs.y, co.y); maxs.z = max(maxs.z, co.z)

    diag = (maxs - mins).length if (maxs - mins).length > 0.0 else 1.0
    tol_eff = max(float(tol), diag * 1.0e-6, 1.0e-7)
    cell = max(tol_eff * 1.5, 1.0e-6)

    def q3(v):
        return (int(round(v.x / cell)), int(round(v.y / cell)), int(round(v.z / cell)))

    for i, co in enumerate(coords):
        key = q3(co)
        buckets.setdefault(key, []).append(i)

    def neighbors(key):
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for dz in (-1, 0, 1):
                    yield (key[0] + dx, key[1] + dy, key[2] + dz)

    candidate_lists = {}
    for i, co in enumerate(coords):
        mirrored = co.copy()
        mirrored[idx] = (2.0 * float(offset)) - co[idx]
        cand_items = []

        if abs(co[idx] - float(offset)) <= tol_eff * 1.5:
            cand_items.append((0.0, i))

        target_key = q3(mirrored)
        for nk in neighbors(target_key):
            for j in buckets.get(nk, []):
                if signatures[j] != signatures[i]:
                    continue
                dist = (coords[j] - mirrored).length
                if dist <= tol_eff * 2.5:
                    penalty = 0.0 if i == j else 0.000001
                    cand_items.append((dist + penalty, j))

        cand_items.sort(key=lambda item: item[0])
        dedup = []
        seen = set()
        for score, j in cand_items:
            if j in seen:
                continue
            seen.add(j)
            dedup.append((score, j))
        candidate_lists[i] = dedup

    best_choice = {i: (lst[0][1] if lst else None) for i, lst in candidate_lists.items()}
    assigned = {}
    used = set()

    for i, j in best_choice.items():
        if j is None:
            continue
        if i == j and abs(coords[i][idx] - float(offset)) <= tol_eff * 1.5:
            assigned[i] = j
            used.add(i)

    for i, j in best_choice.items():
        if i in assigned or j is None or j in used:
            continue
        if best_choice.get(j, None) == i:
            assigned[i] = j
            assigned[j] = i
            used.add(i)
            used.add(j)

    for i, cand_items in candidate_lists.items():
        if i in assigned:
            continue
        for _score, j in cand_items:
            if j in used and j != i:
                continue
            assigned[i] = j
            used.add(i)
            if j is not None:
                used.add(j)
            break

    vmap = {}
    rev = {}
    for i, j in assigned.items():
        if j is None:
            continue
        vmap[int(bm.verts[i].index)] = int(bm.verts[j].index)
        rev[int(bm.verts[j].index)] = int(bm.verts[i].index)
    return vmap, rev


def _bbox_dims(isl):
    size = Vector(getattr(isl, 'bbox_max', Vector((0.0, 0.0))) - getattr(isl, 'bbox_min', Vector((0.0, 0.0))))
    return max(size.x, 1.0e-12), max(size.y, 1.0e-12)


def _precise_detect_sym_pairs(islands, vmap):
    id_by_vert = {}
    island_by_id = {}
    for isl in islands:
        island_by_id[isl.id] = isl
        for vid in getattr(isl, 'vert_ids', set()):
            id_by_vert[vid] = isl.id

    scores = {}
    for isl in islands:
        hits = {}
        mapped = 0
        for vid in getattr(isl, 'vert_ids', set()):
            other_vid = vmap.get(vid, None)
            if other_vid is None:
                continue
            mapped += 1
            other_id = id_by_vert.get(other_vid, None)
            if other_id is None or other_id == isl.id:
                continue
            hits[other_id] = hits.get(other_id, 0) + 1
        if not hits:
            continue

        for other_id, count in hits.items():
            other = island_by_id.get(other_id)
            if other is None:
                continue
            coverage = count / max(1, len(getattr(isl, 'vert_ids', set())))
            vert_ratio = min(len(getattr(isl, 'vert_ids', set())), len(getattr(other, 'vert_ids', set()))) / max(1, max(len(getattr(isl, 'vert_ids', set())), len(getattr(other, 'vert_ids', set()))))
            face_ratio = min(len(getattr(isl, 'faces', [])), len(getattr(other, 'faces', []))) / max(1, max(len(getattr(isl, 'faces', [])), len(getattr(other, 'faces', []))))
            area_ratio = min(max(float(getattr(isl, 'abs_area', 0.0)), 1.0e-12), max(float(getattr(other, 'abs_area', 0.0)), 1.0e-12)) / max(max(float(getattr(isl, 'abs_area', 0.0)), 1.0e-12), max(float(getattr(other, 'abs_area', 0.0)), 1.0e-12))
            aw, ah = _bbox_dims(isl)
            bw, bh = _bbox_dims(other)
            aspect_a = aw / max(ah, 1.0e-12)
            aspect_b = bw / max(bh, 1.0e-12)
            aspect_ratio = min(aspect_a, aspect_b) / max(aspect_a, aspect_b)
            score = (coverage * 0.55) + (vert_ratio * 0.15) + (face_ratio * 0.10) + (area_ratio * 0.10) + (aspect_ratio * 0.10)
            scores[(isl.id, other_id)] = score

    mutual = []
    for a in islands:
        candidates = [(b, s) for (ia, b), s in scores.items() if ia == a.id]
        if not candidates:
            continue
        best_b, best_score = max(candidates, key=lambda item: item[1])
        reverse = [(ia, s) for (ia, ib), s in scores.items() if ib == a.id]
        if reverse:
            best_rev_a, best_rev_score = max(reverse, key=lambda item: item[1])
            if best_rev_a == best_b:
                pass
        mutual.append((a.id, best_b, best_score))

    mutual.sort(key=lambda item: (-item[2], item[0], item[1]))
    pairs = {}
    used = set()
    for a, b, score in mutual:
        if a in used or b in used or a == b:
            continue
        sa = scores.get((a, b), 0.0)
        sb = scores.get((b, a), 0.0)
        if min(sa, sb) < 0.45:
            continue
        pairs[a] = b
        pairs[b] = a
        used.add(a)
        used.add(b)
    return pairs


# -----------------------------------------------------------------------------
# Better stretch metric
# -----------------------------------------------------------------------------

def _tri_area_2d(a: Vector, b: Vector, c: Vector) -> float:
    return abs((b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x)) * 0.5


def _precise_island_stretch_score(isl, obj, uv_layer):
    tri_scale = []
    tri_shape = []
    mw = getattr(obj, 'matrix_world', None)

    for face in getattr(isl, 'faces', []):
        loops = list(getattr(face, 'loops', []))
        if len(loops) < 3:
            continue
        uv_points = [Vector(l[uv_layer].uv) for l in loops]
        world_points = [(mw @ l.vert.co) if mw is not None else l.vert.co.copy() for l in loops]
        for i in range(1, len(loops) - 1):
            ua, ub, uc = uv_points[0], uv_points[i], uv_points[i + 1]
            wa, wb, wc = world_points[0], world_points[i], world_points[i + 1]
            uv_area = _tri_area_2d(ua, ub, uc)
            world_area = (wb - wa).cross(wc - wa).length * 0.5
            if uv_area <= 1.0e-14 or world_area <= 1.0e-14:
                continue
            lens_3d = [
                (wb - wa).length,
                (wc - wb).length,
                (wa - wc).length,
            ]
            lens_uv = [
                (ub - ua).length,
                (uc - ub).length,
                (ua - uc).length,
            ]
            ratios = [l2 / l3 for l2, l3 in zip(lens_uv, lens_3d) if l3 > 1.0e-12 and l2 > 1.0e-12]
            if len(ratios) < 2:
                continue
            try:
                g = math.exp(sum(math.log(r) for r in ratios) / len(ratios))
            except Exception:
                g = max(sum(ratios) / max(1, len(ratios)), 1.0e-12)
            anis = max(max(r / g, g / r) for r in ratios)
            tri_scale.append(max(g, 1.0e-12))
            tri_shape.append(max(1.0, anis))

    if not tri_scale:
        return 1.0, []

    tri_scale_sorted = sorted(tri_scale)
    mid = len(tri_scale_sorted) // 2
    if len(tri_scale_sorted) % 2:
        med = tri_scale_sorted[mid]
    else:
        med = 0.5 * (tri_scale_sorted[mid - 1] + tri_scale_sorted[mid])
    med = max(med, 1.0e-12)

    scores = []
    for scale, anis in zip(tri_scale, tri_shape):
        scale_dev = max(scale / med, med / scale)
        scores.append(max(1.0, anis, scale_dev))
    return max(scores) if scores else 1.0, scores


# -----------------------------------------------------------------------------
# Smarter seam generation helper
# -----------------------------------------------------------------------------

def _mark_auto_seams(obj, bm, angle_threshold, mode='ALL', scope='SELECTED', clear_existing=False):
    bm.edges.ensure_lookup_table()
    face_scope = [f for f in bm.faces if f.select] if scope == 'SELECTED' else list(bm.faces)
    if scope == 'SELECTED' and not face_scope:
        return 0, False
    face_set = set(face_scope)

    candidate_edges = []
    seen = set()
    for f in face_scope:
        for e in getattr(f, 'edges', []):
            if e.index in seen:
                continue
            seen.add(e.index)
            candidate_edges.append(e)
    if scope == 'ALL' and not candidate_edges:
        candidate_edges = list(bm.edges)

    if clear_existing:
        for e in candidate_edges:
            e.seam = False

    marked = 0
    mode = str(mode or 'ALL').upper()
    thresh = max(0.0, float(angle_threshold))

    for e in candidate_edges:
        if scope == 'SELECTED' and not any(f in face_set for f in getattr(e, 'link_faces', [])):
            continue

        is_boundary = len(getattr(e, 'link_faces', [])) < 2
        is_angle = False
        is_material = False
        is_sharp = False
        angle_value = 0.0
        if len(getattr(e, 'link_faces', [])) == 2:
            try:
                angle_value = float(e.calc_face_angle())
                is_angle = angle_value >= thresh
            except Exception:
                is_angle = False
                angle_value = 0.0
            try:
                f0, f1 = e.link_faces[0], e.link_faces[1]
                is_material = int(f0.material_index) != int(f1.material_index)
            except Exception:
                is_material = False
        try:
            is_sharp = not bool(getattr(e, 'smooth', True))
        except Exception:
            is_sharp = False

        combined = is_boundary or is_angle or is_material or is_sharp
        if not combined and thresh > 1.0e-9 and angle_value > 0.0:
            if angle_value >= thresh * 0.85 and (is_material or is_sharp):
                combined = True
            elif angle_value >= thresh * 0.70 and is_material and is_sharp:
                combined = True

        should_mark = False
        if mode == 'ANGLE':
            should_mark = is_angle
        elif mode == 'SHARP':
            should_mark = is_sharp
        elif mode == 'MATERIAL':
            should_mark = is_material
        elif mode == 'BOUNDARY':
            should_mark = is_boundary
        else:
            should_mark = combined

        if should_mark and not e.seam:
            e.seam = True
            marked += 1

    return marked, True


# -----------------------------------------------------------------------------
# Stack alignment improvement
# -----------------------------------------------------------------------------

def _unique_uv_points(isl):
    pts = []
    seen = set()
    for p in getattr(isl, 'uv_points', []):
        key = _quant2(Vector(p), 8)
        if key in seen:
            continue
        seen.add(key)
        pts.append(Vector(p))
    return pts or [Vector(getattr(isl, 'uv_centroid', Vector((0.0, 0.0))))]


def _cloud_error(points, ref_tree, ref_dims):
    if not points or ref_tree is None:
        return float('inf')
    total = 0.0
    max_d = 0.0
    xs = [p.x for p in points]
    ys = [p.y for p in points]
    dims = (max(xs) - min(xs), max(ys) - min(ys)) if points else (0.0, 0.0)
    for p in points:
        _loc, _idx, dist = ref_tree.find(p)
        total += dist
        max_d = max(max_d, dist)
    avg = total / max(1, len(points))
    dim_penalty = abs(dims[0] - ref_dims[0]) + abs(dims[1] - ref_dims[1])
    return avg + max_d * 0.25 + dim_penalty * 0.1


def _precise_stack_pair(uv_layer, ref, isl, rot_step_deg: int, allow_mirror: bool):
    ref_points = _unique_uv_points(ref)
    mov_points = _unique_uv_points(isl)
    if not ref_points or not mov_points:
        return

    ref_cent = Vector(getattr(ref, 'uv_centroid', Vector((0.0, 0.0))))
    mov_cent = Vector(getattr(isl, 'uv_centroid', Vector((0.0, 0.0))))
    ref_tree = None
    if KDTree is not None:
        ref_tree = KDTree(len(ref_points))
        for i, p in enumerate(ref_points):
            ref_tree.insert(Vector(p), i)
        ref_tree.balance()
    ref_dims = (
        max(p.x for p in ref_points) - min(p.x for p in ref_points),
        max(p.y for p in ref_points) - min(p.y for p in ref_points),
    )

    mirror_modes = ['NONE']
    if allow_mirror:
        mirror_modes.extend(['MX', 'MY'])

    def apply_mode(point, mode):
        if mode == 'MX':
            return _core._mirror_x(point, mov_cent)
        if mode == 'MY':
            return _core._mirror_y(point, mov_cent)
        return Vector(point)

    def candidate_angles():
        if rot_step_deg > 0:
            step = max(1, int(rot_step_deg))
            return [math.radians(deg) for deg in range(0, 360, step)]
        coarse = [math.radians(deg) for deg in range(0, 360, 15)]
        return coarse

    best = None
    for mode in mirror_modes:
        mirrored = [apply_mode(p, mode) for p in mov_points]
        coarse_best = None
        for ang in candidate_angles():
            transformed = [mov_cent + _core._rotate2(p - mov_cent, ang) for p in mirrored]
            delta = ref_cent - Vector((sum(p.x for p in transformed) / len(transformed), sum(p.y for p in transformed) / len(transformed)))
            shifted = [p + delta for p in transformed]
            score = _cloud_error(shifted, ref_tree, ref_dims)
            if coarse_best is None or score < coarse_best[0]:
                coarse_best = (score, ang)

        if coarse_best is None:
            continue

        if rot_step_deg <= 0:
            base_deg = int(round(math.degrees(coarse_best[1])))
            refine_angles = [math.radians(deg % 360) for deg in range(base_deg - 15, base_deg + 16)]
        else:
            refine_angles = [coarse_best[1]]

        for ang in refine_angles:
            transformed = [mov_cent + _core._rotate2(p - mov_cent, ang) for p in mirrored]
            centroid = Vector((sum(p.x for p in transformed) / len(transformed), sum(p.y for p in transformed) / len(transformed)))
            delta = ref_cent - centroid
            shifted = [p + delta for p in transformed]
            score = _cloud_error(shifted, ref_tree, ref_dims)
            candidate = (score, mode, ang, delta)
            if best is None or candidate < best:
                best = candidate

    if best is None:
        return

    _score, mode, angle, delta = best

    def tf(u):
        x = Vector(u)
        if mode == 'MX':
            x = _core._mirror_x(x, mov_cent)
        elif mode == 'MY':
            x = _core._mirror_y(x, mov_cent)
        x = mov_cent + _core._rotate2(x - mov_cent, angle)
        x += delta
        return x

    _core._island_apply_transform(isl, uv_layer, tf)


# -----------------------------------------------------------------------------
# Patched operator execute methods
# -----------------------------------------------------------------------------

def _patched_auto_seam_execute(self, context):
    try:
        from . import seam_pin_tools as _spt
        result = _spt.run_advanced_auto_seams(context, self)
        if bool(result.get('ok')):
            marked = int(result.get('marked', 0) or 0)
            self.report({'INFO'}, _core.tr(context, 'msg.auto_seam_done', n=marked, mode=str(getattr(self, 'mode', 'ADVANCED')).title()))
            return {'FINISHED'}
    except Exception:
        pass
    obj = _core._active_mesh_obj(context)
    if not obj:
        self.report({'WARNING'}, _core.tr(context, 'msg.no_active_mesh'))
        return {'CANCELLED'}

    with _core._TempMode(context, obj, 'EDIT'):
        bm = bmesh.from_edit_mesh(obj.data)
        marked, ok = _mark_auto_seams(
            obj,
            bm,
            angle_threshold=float(getattr(self, 'angle_threshold', math.radians(60.0))),
            mode=getattr(self, 'mode', 'ALL'),
            scope=getattr(self, 'scope', 'SELECTED'),
            clear_existing=bool(getattr(self, 'clear_existing', False)),
        )
        if not ok:
            self.report({'WARNING'}, _core.tr(context, 'msg.no_selection'))
            return {'CANCELLED'}
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)

    self.report({'INFO'}, _core.tr(context, 'msg.auto_seam_done', n=marked, mode=str(getattr(self, 'mode', 'ALL')).title()))
    return {'FINISHED'}


def _patched_smart_seams_execute(self, context):
    obj = _core._active_mesh_obj(context)
    if not obj:
        self.report({'WARNING'}, _core.tr(context, 'msg.no_active_mesh'))
        return {'CANCELLED'}
    with _core._TempMode(context, obj, 'EDIT'):
        bm = bmesh.from_edit_mesh(obj.data)
        scope = 'SELECTED' if any(f.select for f in bm.faces) else 'ALL'
        marked, ok = _mark_auto_seams(
            obj,
            bm,
            angle_threshold=float(getattr(self, 'angle_threshold', math.radians(60.0))),
            mode='ALL',
            scope=scope,
            clear_existing=False,
        )
        if not ok:
            self.report({'WARNING'}, _core.tr(context, 'msg.no_selection'))
            return {'CANCELLED'}
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    self.report({'INFO'}, _core.tr(context, 'msg.seams_marked', n=marked))
    return {'FINISHED'}


def _patched_smart_relax_execute(self, context):
    iterations = max(24, int(getattr(self, 'iterations', 100)))
    passes = max(2, min(8, int(math.ceil(iterations / 48.0))))
    try:
        result = bpy.ops.uv.suv_constraint_relax_preserve(
            'EXEC_DEFAULT',
            scope='SELECTED',
            mode='RELAX_KNEAD',
            anchor_mode='EXISTING_PLUS_BORDER_CORNERS',
            temporary_anchors=True,
            preserve_position=False,
            preserve_area=True,
            preserve_rotation=False,
            keep_tile=True,
            average_scale_each_pass=True,
            iterations=max(48, iterations),
            passes=passes,
            pack_after=False,
        )
        if 'FINISHED' in set(result):
            self.report({'INFO'}, _core.tr(context, 'msg.relax_done'))
            return {'FINISHED'}
    except Exception as exc:
        try:
            _core._debug(context, f'Smart Relax precision path failed: {exc}')
        except Exception:
            pass

    ok, err = _core._run_uv_op(context, bpy.ops.uv.minimize_stretch, iterations=iterations, fill_holes=True, blend=0.0)
    if ok:
        self.report({'INFO'}, _core.tr(context, 'msg.relax_done'))
        return {'FINISHED'}
    self.report({'WARNING'}, _core.tr(context, 'msg.op_failed', e=err))
    return {'CANCELLED'}


def _patched_auto_unwrap_execute(self, context):
    obj = _core._active_mesh_obj(context)
    if not obj:
        self.report({'WARNING'}, _core.tr(context, 'msg.no_active_mesh'))
        return {'CANCELLED'}

    report = _pro._suv_batch_begin(context, 'Auto Unwrap Pro', details={
        'object': getattr(obj, 'name', '-'),
        'do_seams': bool(getattr(self, 'do_seams', True)),
        'do_unwrap': bool(getattr(self, 'do_unwrap', True)),
        'do_relax': bool(getattr(self, 'do_relax', True)),
        'do_pack': bool(getattr(self, 'do_pack', False)),
        'do_qa': bool(getattr(self, 'do_qa', True)),
    })

    with _core._TempMode(context, obj, 'EDIT'):
        bm = bmesh.from_edit_mesh(obj.data)
        sel_faces = [f for f in bm.faces if f.select]
        if not sel_faces:
            _pro._suv_batch_note(context, report, 'ERROR', 'Selection Check', 'No selected faces available for unwrap', {'object': getattr(obj, 'name', '-')})
            self.report({'WARNING'}, _core.tr(context, 'msg.no_selection'))
            return _pro._suv_batch_finish(context, report, operator=self)

    if getattr(self, 'do_seams', True):
        _pro._suv_batch_step(
            context,
            report,
            'Seam Suggest',
            lambda: bpy.ops.uv.suv_auto_seam_advanced(
                'EXEC_DEFAULT',
                mode='ALL',
                angle_threshold=float(getattr(self, 'angle_threshold', math.radians(60.0))),
                clear_existing=False,
                scope='SELECTED',
            ),
            details={'angle_threshold': float(getattr(self, 'angle_threshold', math.radians(60.0))), 'mode': 'ALL'},
        )
        if _pro._suv_batch_should_stop(context, report):
            return _pro._suv_batch_finish(context, report, operator=self)

    if getattr(self, 'do_unwrap', True):
        def _unwrap_step():
            try:
                result = bpy.ops.suv.constraint_unwrap(
                    'EXEC_DEFAULT',
                    mode='MIN_STRETCH',
                    anchor_mode='EXISTING_PLUS_BORDER_CORNERS',
                    preserve_position=False,
                    preserve_scale=True,
                    preserve_rotation=False,
                    temporary_anchors=True,
                    iterations=24,
                    pack_after=False,
                )
                if 'FINISHED' in set(result):
                    return result
            except Exception as exc:
                try:
                    _core._debug(context, f'Constraint unwrap precision path failed: {exc}')
                except Exception:
                    pass
            return bpy.ops.uv.unwrap('EXEC_DEFAULT', method='ANGLE_BASED', margin=0.001)

        _pro._suv_batch_step(
            context,
            report,
            'Unfold Trim',
            _unwrap_step,
            fatal=False,
            details={'method': 'CONSTRAINT_MIN_STRETCH', 'anchors': 'EXISTING_PLUS_BORDER_CORNERS'},
        )
        if _pro._suv_batch_should_stop(context, report):
            return _pro._suv_batch_finish(context, report, operator=self)

    if getattr(self, 'do_relax', True):
        def _relax_step():
            try:
                result = bpy.ops.uv.suv_constraint_relax_preserve(
                    'EXEC_DEFAULT',
                    scope='SELECTED',
                    mode='RELAX_KNEAD',
                    anchor_mode='EXISTING_PLUS_BORDER_CORNERS',
                    temporary_anchors=True,
                    preserve_position=False,
                    preserve_area=True,
                    preserve_rotation=False,
                    keep_tile=True,
                    average_scale_each_pass=True,
                    iterations=96,
                    passes=4,
                    pack_after=False,
                )
                if 'FINISHED' in set(result):
                    return result
            except Exception as exc:
                try:
                    _core._debug(context, f'Constraint relax precision path failed: {exc}')
                except Exception:
                    pass
            return bpy.ops.uv.minimize_stretch('EXEC_DEFAULT', iterations=96, fill_holes=True, blend=0.0)

        _pro._suv_batch_step(
            context,
            report,
            'Relax',
            _relax_step,
            details={'mode': 'RELAX_KNEAD', 'iterations': 96, 'passes': 4},
        )
        if _pro._suv_batch_should_stop(context, report):
            return _pro._suv_batch_finish(context, report, operator=self)

    if getattr(self, 'do_pack', False):
        _pro._suv_batch_step(
            context,
            report,
            'Pack Pro',
            lambda: bpy.ops.uv.suv_pack_pro(
                'EXEC_DEFAULT',
                engine=getattr(self, 'pack_engine', 'DETERMINISTIC'),
                scope='SELECTED',
                udim_mode=getattr(self, 'pack_udim_mode', 'SINGLE'),
                margin_px=int(getattr(self, 'pack_margin_px', 8)),
                texture_size=int(getattr(self, 'texture_size', 2048)),
                rotation_step=getattr(self, 'pack_rotation_step', '45'),
                lock_pinned=True,
            ),
            details={
                'engine': getattr(self, 'pack_engine', 'DETERMINISTIC'),
                'udim_mode': getattr(self, 'pack_udim_mode', 'SINGLE'),
                'margin_px': int(getattr(self, 'pack_margin_px', 8)),
                'texture_size': int(getattr(self, 'texture_size', 2048)),
                'rotation_step': getattr(self, 'pack_rotation_step', '45'),
            },
        )
        if _pro._suv_batch_should_stop(context, report):
            return _pro._suv_batch_finish(context, report, operator=self)

    if getattr(self, 'do_qa', True):
        _pro._suv_batch_step(
            context,
            report,
            'Inspector Scan',
            lambda: bpy.ops.uv.suv_inspector_scan(
                'EXEC_DEFAULT',
                scope='SELECTED',
                eps_zero=1.0e-12,
                check_out_of_tile=True,
                check_overlap=True,
                precise_overlap=True,
                check_stretch=True,
                stretch_threshold=1.35,
            ),
            details={'scope': 'SELECTED', 'precise_overlap': True, 'stretch_threshold': 1.35},
        )
        if _pro._suv_batch_should_stop(context, report):
            return _pro._suv_batch_finish(context, report, operator=self)

    if report.get('error', 0) == 0 and report.get('warn', 0) == 0:
        self.report({'INFO'}, _core.tr(context, 'msg.auto_done'))
    return _pro._suv_batch_finish(context, report, operator=self)


def _patched_inspector_execute(self, context):
    obj = _core._active_mesh_obj(context)
    if not obj:
        self.report({'WARNING'}, _core.tr(context, 'msg.no_active_mesh'))
        return {'CANCELLED'}

    with _core._TempMode(context, obj, 'EDIT'):
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        faces = list(bm.faces) if getattr(self, 'scope', 'SELECTED') == 'ALL' else [f for f in bm.faces if f.select]
        if not faces:
            self.report({'WARNING'}, _core.tr(context, 'msg.no_selection'))
            return {'CANCELLED'}

        islands = _core.build_islands(bm, uv_layer, faces_subset=faces)
        flipped = []
        zero = []
        out = []
        overlap = []
        stretch = []
        stretch_details = []
        stretch_scores = []

        for face in faces:
            try:
                area = float(_core._signed_uv_area(face, uv_layer))
            except Exception:
                area = 0.0
            if area < -abs(float(getattr(self, 'eps_zero', 1.0e-12))):
                flipped.append((int(face.index),))
            if abs(area) <= abs(float(getattr(self, 'eps_zero', 1.0e-12))):
                zero.append((int(face.index),))

        if getattr(self, 'check_out_of_tile', True):
            for isl in islands:
                tile = (int(math.floor(isl.uv_centroid.x)), int(math.floor(isl.uv_centroid.y)))
                off = Vector((tile[0], tile[1]))
                for uv in getattr(isl, 'uv_points', []):
                    p = Vector(uv) - off
                    if p.x < -1.0e-9 or p.y < -1.0e-9 or p.x > 1.0 + 1.0e-9 or p.y > 1.0 + 1.0e-9:
                        out.append(isl.face_sig)
                        break

        if getattr(self, 'check_stretch', True):
            threshold = max(1.01, float(getattr(self, 'stretch_threshold', 1.8)))
            for isl in islands:
                score, score_detail = _precise_island_stretch_score(isl, obj, uv_layer)
                stretch_scores.append(score)
                if score >= threshold:
                    stretch.append(isl.face_sig)
                    stretch_details.append(round(float(score), 4))

        if getattr(self, 'check_overlap', True):
            for i in range(len(islands)):
                a = islands[i]
                abb = (a.bbox_min.x, a.bbox_min.y, a.bbox_max.x, a.bbox_max.y)
                for j in range(i + 1, len(islands)):
                    b = islands[j]
                    bbb = (b.bbox_min.x, b.bbox_min.y, b.bbox_max.x, b.bbox_max.y)
                    if not _pro._bbox_overlap(abb, bbb, 1.0e-12):
                        continue
                    try:
                        if _pro._islands_overlap_precise(a, b, uv_layer, eps=1.0e-12):
                            overlap.append((a.face_sig, b.face_sig))
                    except Exception as exc:
                        try:
                            _core._debug(context, f'Precise overlap failed: {exc}')
                        except Exception:
                            pass
                        overlap.append((a.face_sig, b.face_sig))

        _core._cache_set(context.scene, 'inspect_flipped', flipped)
        _core._cache_set(context.scene, 'inspect_zero', zero)
        _core._cache_set(context.scene, 'inspect_out', out)
        _core._cache_set(context.scene, 'inspect_overlap', overlap)
        _core._cache_set(context.scene, 'inspect_stretch', stretch)
        _core._cache_set(context.scene, 'inspect_stretch_detail', stretch_details)
        worst = max(stretch_scores) if stretch_scores else 1.0
        avg = (sum(stretch_scores) / len(stretch_scores)) if stretch_scores else 1.0
        _pro._suv_store_scan_cache(
            context,
            getattr(self, 'scope', 'SELECTED'),
            float(getattr(self, 'eps_zero', 1.0e-12)),
            bool(getattr(self, 'check_out_of_tile', True)),
            bool(getattr(self, 'check_overlap', True)),
            True,
            len(flipped),
            len(zero),
            len(out),
            len(overlap),
            stretch_count=len(stretch),
            stretch_worst=worst,
            stretch_avg=avg,
        )

    self.report({'INFO'}, _core.tr(context, 'msg.inspect_summary', f=len(flipped), z=len(zero), o=len(out), p=len(overlap), s=len(stretch)))
    return {'FINISHED'}


def _patched_sym_mirror_execute(self, context):
    obj = _core._active_mesh_obj(context)
    if not obj:
        self.report({'WARNING'}, _core.tr(context, 'msg.no_active_mesh'))
        return {'CANCELLED'}

    with _core._TempMode(context, obj, 'EDIT'):
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        islands = _core.build_islands(bm, uv_layer, faces_subset=list(bm.faces))
        active_face = getattr(bm.faces, 'active', None)
        if not active_face:
            self.report({'WARNING'}, _core.tr(context, 'msg.no_selection'))
            return {'CANCELLED'}
        ref = next((i for i in islands if active_face in i.faces), None)
        if not ref:
            self.report({'WARNING'}, _core.tr(context, 'msg.no_selection'))
            return {'CANCELLED'}

        vmap, rev = _precise_build_mirror_map(
            obj,
            bm,
            axis=getattr(self, 'axis', 'X'),
            space=getattr(self, 'space', 'LOCAL'),
            offset=float(getattr(self, 'offset', 0.0)),
            tol=float(getattr(self, 'tolerance', 1.0e-4)),
        )
        pairs = _precise_detect_sym_pairs(islands, vmap)
        _core._cache_set(context.scene, 'sym_pairs', pairs)
        pid = pairs.get(ref.id)
        if pid is None:
            self.report({'WARNING'}, _core.tr(context, 'msg.sym_no_pair'))
            return {'CANCELLED'}
        pair = next((i for i in islands if i.id == pid), None)
        if pair is None:
            self.report({'WARNING'}, _core.tr(context, 'msg.sym_no_pair'))
            return {'CANCELLED'}

        src_uv_by_vid = {}
        src_count = {}
        for l in ref.loops:
            vid = int(l.vert.index)
            src_uv_by_vid[vid] = src_uv_by_vid.get(vid, Vector((0.0, 0.0))) + Vector(l[uv_layer].uv)
            src_count[vid] = src_count.get(vid, 0) + 1
        for vid in list(src_uv_by_vid.keys()):
            src_uv_by_vid[vid] /= float(max(1, src_count.get(vid, 1)))

        tgt_current_by_vid = {}
        tgt_count = {}
        for l in pair.loops:
            vid = int(l.vert.index)
            tgt_current_by_vid[vid] = tgt_current_by_vid.get(vid, Vector((0.0, 0.0))) + Vector(l[uv_layer].uv)
            tgt_count[vid] = tgt_count.get(vid, 0) + 1
        for vid in list(tgt_current_by_vid.keys()):
            tgt_current_by_vid[vid] /= float(max(1, tgt_count.get(vid, 1)))

        pivot = Vector(getattr(ref, 'uv_centroid', Vector((0.0, 0.0))))

        def mirror_uv(uv):
            u = Vector(uv)
            if getattr(self, 'mirror_uv_axis', 'U') == 'U':
                u.x = pivot.x - (u.x - pivot.x)
            else:
                u.y = pivot.y - (u.y - pivot.y)
            return u

        mirrored_samples = []
        target_samples = []
        for tgt_vid, tgt_uv in tgt_current_by_vid.items():
            src_vid = rev.get(int(tgt_vid), None)
            if src_vid is None:
                continue
            src_uv = src_uv_by_vid.get(int(src_vid), None)
            if src_uv is None:
                continue
            mirrored_samples.append(mirror_uv(src_uv))
            target_samples.append(Vector(tgt_uv))

        if len(mirrored_samples) < 2 or len(target_samples) < 2:
            self.report({'WARNING'}, _core.tr(context, 'msg.sym_no_pair'))
            return {'CANCELLED'}

        mirrored_centroid = Vector((
            sum(p.x for p in mirrored_samples) / len(mirrored_samples),
            sum(p.y for p in mirrored_samples) / len(mirrored_samples),
        ))
        target_centroid = Vector((
            sum(p.x for p in target_samples) / len(target_samples),
            sum(p.y for p in target_samples) / len(target_samples),
        ))
        delta = target_centroid - mirrored_centroid

        assigned = 0
        for l in pair.loops:
            tgt_vid = int(l.vert.index)
            src_vid = rev.get(tgt_vid, None)
            if src_vid is None:
                continue
            src_uv = src_uv_by_vid.get(int(src_vid), None)
            if src_uv is None:
                continue
            l[uv_layer].uv = mirror_uv(src_uv) + delta
            assigned += 1

        if assigned <= 0:
            self.report({'WARNING'}, _core.tr(context, 'msg.sym_no_pair'))
            return {'CANCELLED'}

        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)

    self.report({'INFO'}, _core.tr(context, 'msg.sym_mirrored'))
    return {'FINISHED'}


_ORIG_GRIDIFY_EXEC = getattr(_flow.SUV_OT_hs_gridify, 'execute', None)
_ORIG_RECTIFY_FIT_EXEC = getattr(_flow.SUV_OT_hs_rectify_fit, 'execute', None)


def _patched_gridify_execute(self, context):
    try:
        result = bpy.ops.uv.suv_hs_rectify_constrained(
            'EXEC_DEFAULT',
            scope=getattr(self, 'scope', 'SELECTED'),
            mode='GRID_ONLY',
            step_deg=2,
            merge_factor=float(getattr(self, 'merge_factor', 0.02)),
            padding_px=0,
            texture_size=2048,
            keep_tile=bool(getattr(self, 'keep_tile', True)),
            preserve_center=True,
            preserve_area=True,
        )
        if 'FINISHED' in set(result):
            return {'FINISHED'}
    except Exception as exc:
        try:
            _core._debug(context, f'Gridify precision path failed: {exc}')
        except Exception:
            pass
    if _ORIG_GRIDIFY_EXEC is not None:
        return _ORIG_GRIDIFY_EXEC(self, context)
    return {'CANCELLED'}


def _patched_rectify_fit_execute(self, context):
    try:
        result = bpy.ops.uv.suv_hs_rectify_constrained(
            'EXEC_DEFAULT',
            scope=getattr(self, 'scope', 'SELECTED'),
            mode='GRID_RECTIFY',
            step_deg=2,
            merge_factor=0.01,
            padding_px=int(getattr(self, 'padding_px', 8)),
            texture_size=int(getattr(self, 'texture_size', 2048)),
            keep_tile=bool(getattr(self, 'keep_tile', True)),
            preserve_center=True,
            preserve_area=True,
        )
        if 'FINISHED' in set(result):
            return {'FINISHED'}
    except Exception as exc:
        try:
            _core._debug(context, f'Rectify precision path failed: {exc}')
        except Exception:
            pass
    if _ORIG_RECTIFY_FIT_EXEC is not None:
        return _ORIG_RECTIFY_FIT_EXEC(self, context)
    return {'CANCELLED'}


# -----------------------------------------------------------------------------
# Apply monkey patches in-place
# -----------------------------------------------------------------------------

def _apply_precision_patch():
    _patch_name('_best_bbox_angle', _precise_best_bbox_angle)
    _patch_name('_pack_shelf', _pack_shelf_maxrects)
    _patch_name('_pack_multi_tiles', _pack_multi_tiles_maxrects)
    _patch_name('_build_mirror_map', _precise_build_mirror_map)
    _patch_name('_detect_sym_pairs', _precise_detect_sym_pairs)
    _patch_name('_island_stretch_score', _precise_island_stretch_score)

    _pro.SUV_OT_stack_pro._stack_pair = staticmethod(_precise_stack_pair)
    _legacy.SUV_OT_smart_seams.execute = _patched_smart_seams_execute
    _legacy.SUV_OT_smart_relax.execute = _patched_smart_relax_execute
    _flow.SUV_OT_auto_seam_advanced.execute = _patched_auto_seam_execute
    _pro.SUV_OT_auto_unwrap_pro.execute = _patched_auto_unwrap_execute
    _pro.SUV_OT_inspector_scan.execute = _patched_inspector_execute
    _sym.SUV_OT_sym_mirror_uv.execute = _patched_sym_mirror_execute
    _flow.SUV_OT_hs_gridify.execute = _patched_gridify_execute
    _flow.SUV_OT_hs_rectify_fit.execute = _patched_rectify_fit_execute


_apply_precision_patch()
