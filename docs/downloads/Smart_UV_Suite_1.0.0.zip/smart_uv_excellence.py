# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

'UV Suite Excellence Engine.\n\nA high-precision, UX-oriented execution layer for UV Suite.  It does not\ncopy third-party UV tools.  Instead it composes local UV Suite operators,\nBlender-native UV operators, and measurable preflight/postflight reports into\nasset-specific routes inspired by the feature requirements in the supplied UV\nresearch documents.\n'
from . import resource_api_18168 as _suv_resource

import json
import os
import math
from pathlib import Path

import bpy


def _tr(context, en: str, ja: str) -> str:
    try:
        lang = str(getattr(getattr(context, 'preferences', None).view, 'language', '') or '')
    except Exception:
        lang = ''
    return str(ja if (lang.startswith('ja') or lang.startswith('jp') or lang == 'DEFAULT_JAPANESE') else en)


def _operator_proxy(op_idname: str):
    text = str(op_idname or '').strip()
    if '.' not in text:
        return None
    group, name = text.split('.', 1)
    try:
        ops_group = getattr(getattr(bpy, 'ops', None), group, None)
        return getattr(ops_group, name, None) if ops_group is not None else None
    except Exception:
        return None


def _is_real_operator_rna(rna) -> bool:
    try:
        ident = str(getattr(rna, 'identifier', '') or '').strip()
    except Exception:
        ident = ''
    return bool(ident) and ident not in {'Operator', 'OperatorProperties', 'UnknownType', 'bpy_struct'}


def _operator_rna(op_idname: str):
    op = _operator_proxy(op_idname)
    if op is None:
        return None
    try:
        get_rna_type = getattr(op, 'get_rna_type', None)
        if not callable(get_rna_type):
            return None
        rna = get_rna_type()
        return rna if _is_real_operator_rna(rna) else None
    except Exception:
        return None


def operator_exists(op_idname: str) -> bool:
    return _operator_rna(op_idname) is not None


def _property_names(op_idname: str) -> set:
    rna = _operator_rna(op_idname)
    names = set()
    if rna is None:
        return names
    try:
        props = getattr(rna, 'properties', None)
        try:
            names.update(str(k) for k in props.keys())
        except Exception:
            pass
        for prop in props:
            ident = str(getattr(prop, 'identifier', '') or '')
            if ident:
                names.add(ident)
    except Exception:
        pass
    return names


def _filter_kwargs(op_idname: str, props: dict | None) -> dict:
    if not props:
        return {}
    names = _property_names(op_idname)
    if not names:
        return {}
    return {str(k): v for k, v in dict(props).items() if str(k) in names}


def _call(op_idname: str, **props) -> bool:
    text = str(op_idname or '').strip()
    if '.' not in text or not operator_exists(text):
        return False
    group, name = text.split('.', 1)
    try:
        op = getattr(getattr(bpy.ops, group), name)
    except Exception:
        return False
    safe = _filter_kwargs(text, props)
    attempts = (
        (('EXEC_DEFAULT',), safe),
        (tuple(), safe),
        (('EXEC_DEFAULT',), {}),
        (tuple(), {}),
    )
    for args, kwargs in attempts:
        try:
            result = op(*args, **kwargs)
            try:
                return 'CANCELLED' not in set(result or set())
            except Exception:
                return True
        except TypeError:
            continue
        except Exception:
            continue
    return False


def _workspace(context=None):
    try:
        return getattr(getattr(context or bpy.context, 'scene', None), 'suv_workspace', None)
    except Exception:
        return None


def _values(context=None):
    ws = _workspace(context)
    def _get(name, default):
        try:
            return getattr(ws, name, default) if ws is not None else default
        except Exception:
            return default
    try:
        texture_size = max(128, int(_get('canvas_size', 2048) or 2048))
    except Exception:
        texture_size = 2048
    try:
        margin_px = max(0, int(_get('fit_padding_px', 8) or 8))
    except Exception:
        margin_px = 8
    try:
        density = max(1.0, float(_get('workflow_density', 1024.0) or 1024.0))
    except Exception:
        density = 1024.0
    return texture_size, margin_px, density


def _ensure_mesh_context(context=None) -> bool:
    ctx = context or getattr(bpy, 'context', None)
    obj = getattr(ctx, 'active_object', None) if ctx is not None else None
    if obj is None or getattr(obj, 'type', '') != 'MESH':
        return False
    try:
        if getattr(obj, 'mode', '') != 'EDIT':
            bpy.ops.object.mode_set(mode='EDIT')
    except Exception:
        pass
    return True


def _metrics(context=None) -> dict:
    try:
        from . import smart_uv_precision as _precision
        collect = getattr(_precision, 'collect_metrics', None)
        if callable(collect):
            data = collect(context)
            if isinstance(data, dict):
                return data
    except Exception:
        pass
    return {'ok': False, 'faces': 0, 'error': 'metrics unavailable'}


def _grade(metrics: dict) -> dict:
    data = dict(metrics or {})
    faces = max(0, int(data.get('faces') or 0))
    uv_area = max(0.0, float(data.get('uv_area') or 0.0))
    zero = max(0, int(data.get('zero_area_faces') or 0))
    flipped = max(0, int(data.get('flipped_triangles') or 0))
    spread = max(0.0, float(data.get('density_spread_percent') or 0.0))
    usage = max(0.0, min(100.0, uv_area * 100.0))
    score = 100.0
    if faces <= 0:
        score -= 45.0
    score -= min(28.0, zero * 2.5)
    score -= min(25.0, flipped * 1.2)
    score -= min(22.0, spread / 4.0)
    if usage < 35.0:
        score -= min(14.0, (35.0 - usage) * 0.4)
    score = max(0.0, min(100.0, score))
    if score >= 92:
        letter = 'S'
    elif score >= 82:
        letter = 'A'
    elif score >= 70:
        letter = 'B'
    elif score >= 55:
        letter = 'C'
    else:
        letter = 'D'
    recommendations = []
    if zero:
        recommendations.append('zero_area_repair')
    if flipped:
        recommendations.append('flipped_island_repair')
    if spread > 35:
        recommendations.append('density_normalize')
    if usage < 35:
        recommendations.append('pack_density')
    return {
        'score': round(score, 2),
        'grade': letter,
        'usage_percent_estimate': round(usage, 2),
        'recommendations': recommendations,
    }


def _record_stage(log: list, name: str, op_idname: str, props: dict, ok: bool) -> None:
    try:
        log.append({'stage': str(name), 'operator': str(op_idname), 'properties': dict(props or {}), 'ok': bool(ok)})
    except Exception:
        pass


def _run_stage(log: list, name: str, candidates: list, *, require_one: bool = True) -> bool:
    any_ok = False
    for op_idname, props in candidates:
        ok = _call(op_idname, **dict(props or {}))
        _record_stage(log, name, op_idname, props or {}, ok)
        any_ok = any_ok or ok
        if ok and require_one:
            return True
    return bool(any_ok or not require_one)


def _write_report(context=None, action: str = '', before: dict | None = None, after: dict | None = None, log: list | None = None, extra: dict | None = None) -> bool:
    payload = {
        'schema': 'smart_uv_excellence_report_v1',
        'action': str(action or ''),
        'before': before or {},
        'after': after or {},
        'before_grade': _grade(before or {}),
        'after_grade': _grade(after or {}),
        'stages': list(log or []),
        'extra': dict(extra or {}),
    }
    try:
        from . import storage
        path = Path(storage.runtime_file('smart_uv_excellence_report.json', 'reports', create=True))
    except Exception:
        path = (Path(os.environ.get('APPDATA')) / 'Blender Foundation' / 'Blender' / '5.1' / 'config' / 'Smart_UV_Suite' / 'user_data' / 'runtime' / 'reports' / 'smart_uv_excellence_report.json') if os.environ.get('APPDATA') else (Path.home() / '.config' / 'blender' / '5.1' / 'config' / 'Smart_UV_Suite' / 'user_data' / 'runtime' / 'reports' / 'smart_uv_excellence_report.json')
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
        try:
            text = bpy.data.texts.get('Smart_UV_Suite_Excellence_Report') or bpy.data.texts.new('Smart_UV_Suite_Excellence_Report')
            text.clear()
            text.write(json.dumps({
                'schema': payload['schema'],
                'action': payload['action'],
                'before_grade': payload['before_grade'],
                'after_grade': payload['after_grade'],
                'stage_count': len(payload['stages']),
            }, ensure_ascii=False, indent=2))
        except Exception:
            pass
        return True
    except Exception:
        return False


def last_report() -> dict:
    try:
        from . import storage
        path = Path(storage.runtime_file('smart_uv_excellence_report.json', 'reports', create=False))
        if path.exists():
            return json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        pass
    return {}


def _preflight(log, tex, margin, density):
    return _run_stage(log, 'preflight', [
        ('uv.suv_layout_preflight_audit', {'scope': 'ALL', 'texture_size': tex, 'margin_px': margin}),
        ('uv.suv_inspector_scan', {'scope': 'ALL', 'check_overlap': True, 'check_stretch': True, 'check_out_of_tile': True}),
    ], require_one=False)


def _seam(log, *, aggressive=False):
    threshold = 50.0 if aggressive else 60.0
    return _run_stage(log, 'adaptive_seam', [
        ('uv.suv_auto_seam_advanced', {'mode': 'ANGLE', 'angle_threshold': math.radians(threshold), 'scope': 'ALL'}),
        ('uv.suv_auto_seam_advanced', {'mode': 'SHARP', 'scope': 'ALL'}),
        ('uv.suv_auto_seam_advanced', {'mode': 'MATERIAL', 'scope': 'ALL'}),
        ('uv.suv_smart_seams', {}),
        ('uv.mark_seam', {'clear': False}),
    ], require_one=False)


def _unwrap(log, tex, margin, *, preserve=False):
    uv_margin = max(0.001, float(margin) / max(1.0, float(tex)))
    candidates = [
        ('uv.suv_native_projection', {'mode': 'MIN_STRETCH', 'relax_after': False, 'pack_after': False, 'apply_density': False}),
        ('uv.suv_native_projection', {'mode': 'UNWRAP_ABF', 'relax_after': False, 'pack_after': False, 'apply_density': False}),
        ('uv.unwrap', {'method': 'ANGLE_BASED', 'margin': uv_margin}),
        ('uv.unwrap', {'method': 'CONFORMAL', 'margin': uv_margin}),
    ]
    if preserve:
        candidates.insert(0, ('uv.suv_constraint_relax_preserve', {'iterations': 32, 'preserve_boundary': True}))
    return _run_stage(log, 'unwrap_min_distortion', candidates, require_one=True)


def _relax(log, *, iterations=96):
    return _run_stage(log, 'multi_relax', [
        ('uv.suv_constraint_relax_preserve', {'iterations': iterations, 'preserve_boundary': True}),
        ('uv.suv_cleanup_bridge', {'mode': 'OPTIMIZE_REALTIME', 'iterations': iterations}),
        ('uv.minimize_stretch', {'iterations': iterations}),
        ('smart_uv_suite.native_hub_action', {}),
    ], require_one=False)


def _density(log, tex, margin, density):
    return _run_stage(log, 'density_normalize', [
        ('uv.suv_texel_normalize', {'mode': 'AVERAGE', 'value_density': density, 'texture_size': tex, 'use_world_scale': True, 'skip_pinned': True}),
        ('uv.suv_texel_set', {'scope': 'SELECTED', 'target_density': density, 'texture_size': tex, 'use_world_scale': True, 'skip_pinned': True, 'keep_tile': True}),
    ], require_one=False)


def _pack(log, tex, margin, density, *, udim=False, exact=True, stack=True):
    uv_margin = max(0.001, float(margin) / max(1.0, float(tex)))
    candidates = []
    if udim:
        _run_stage(log, 'candidate_tiles', [
            ('uv.suv_groups_to_tiles', {'mode': 'MATERIAL', 'texture_size': tex, 'margin_px': margin}),
        ], require_one=True)
        candidates += [
            ('uv.suv_pack_pro', {'udim_mode': 'KEEP_TILES', 'texture_size': tex, 'margin_px': margin}),
        ]
    candidates += [
        ('uv.suv_priority_density_pack', {'texture_size': tex, 'margin_px': margin, 'scope': 'SELECTED'}),
        ('uv.suv_groups_to_tiles', {'mode': 'SIMILAR', 'texture_size': tex, 'margin_px': margin}),
        ('uv.suv_pack_pro', {'texture_size': tex, 'margin_px': margin, 'rotation_step': '90'}),
        ('uv.pack_islands', {'margin': uv_margin, 'rotate': True}),
        ('smart_uv_suite.native_hub_action', {}),
    ]
    packed = _run_stage(log, 'candidate_pack', candidates, require_one=True)
    # Stacking is a step after packing, not an alternative to it: a stack that succeeds
    # on two identical islands must not leave every other island unpacked.
    if stack:
        _run_stage(log, 'candidate_stack', [
            ('uv.suv_stack_grouped', {'mode': 'IDENTICAL', 'area_tol': 0.001, 'aspect_tol': 0.001}),
            ('uv.suv_stack_grouped', {'mode': 'SIMILAR', 'area_tol': 0.01, 'aspect_tol': 0.02}),
        ], require_one=True)
    return packed


def _postflight(log, tex, margin, density):
    return _run_stage(log, 'postflight', [
        ('uv.suv_layout_candidate_audit', {'texture_size': tex, 'margin_px': margin, 'target_density': density}),
        ('uv.suv_inspector_scan', {'scope': 'ALL', 'check_overlap': True, 'check_stretch': True, 'check_out_of_tile': True}),
        ('uv.suv_inspector_write_report', {}),
    ], require_one=False)


def _repair(log, tex, margin, density):
    return _run_stage(log, 'repair', [
        ('uv.suv_inspector_fix_flipped', {}),
        ('uv.suv_repair_flipped_islands', {}),
        ('uv.suv_layout_autoheal', {}),
        ('uv.suv_fix_all_issues', {}),
        ('uv.suv_unstack_overlapped', {'offset_px': margin, 'texture_size': tex}),
    ], require_one=False)


def _shape(log):
    return _run_stage(log, 'shape_refine', [
        ('uv.suv_orient_islands', {'mode': 'MIN_BBOX', 'step_deg': 5, 'scope': 'ALL'}),
        ('uv.suv_hs_rectify_fit', {}),
        ('uv.suv_hs_gridify', {}),
        ('uv.suv_hs_squareify', {}),
        ('uv.suv_orient_to_edge', {'scope': 'SELECTED'}),
    ], require_one=False)


def run_excellence_action(action, context=None) -> bool:
    action = str(action or '').strip().upper()
    context = context or getattr(bpy, 'context', None)
    if action in {'REPORT_SCORE', 'SCORE_ONLY'}:
        before = _metrics(context)
        return _write_report(context, action=action, before=before, after=before, log=[], extra={'read_only': True})
    if not _ensure_mesh_context(context):
        before = _metrics(context)
        return _write_report(context, action=action, before=before, after=before, log=[], extra={'error': 'no active mesh'}) and False
    tex, margin, density = _values(context)
    log = []
    before = _metrics(context)
    aggressive = action in {'DIRECTOR_AUTO', 'ADAPTIVE_AUTO', 'SCAN_CLEANUP'}
    udim = action in {'UDIM_PRODUCTION', 'RIZOM_STYLE', 'PACK_SUPREME'}
    if action in {'DIRECTOR_AUTO', 'ADAPTIVE_AUTO', 'SUPREME_DIRECTOR'}:
        _preflight(log, tex, margin, density)
        _seam(log, aggressive=aggressive)
        _unwrap(log, tex, margin)
        _relax(log, iterations=128)
        _density(log, tex, margin, density)
        _pack(log, tex, margin, density, exact=True, stack=True)
        _postflight(log, tex, margin, density)
    elif action in {'ORGANIC_UNWRAP', 'ZEN_RELAX_PLUS', 'HEADUS_KNEAD'}:
        _preflight(log, tex, margin, density)
        _seam(log, aggressive=False)
        _unwrap(log, tex, margin, preserve=True)
        _relax(log, iterations=160)
        _density(log, tex, margin, density)
        _postflight(log, tex, margin, density)
    elif action in {'HARD_SURFACE', 'SMART_TEXTURE_PLUS', 'TRIM_PREP'}:
        _preflight(log, tex, margin, density)
        _shape(log)
        _density(log, tex, margin, density)
        _pack(log, tex, margin, density, exact=True, stack=True)
        _postflight(log, tex, margin, density)
    elif action in {'PACK_SUPREME', 'DENSITY_PACK_V2', 'UVPACKMASTER_STYLE'}:
        _preflight(log, tex, margin, density)
        _density(log, tex, margin, density)
        _pack(log, tex, margin, density, udim=udim, exact=True, stack=True)
        _postflight(log, tex, margin, density)
    elif action in {'UDIM_PRODUCTION', 'RIZOM_STYLE'}:
        _preflight(log, tex, margin, density)
        _density(log, tex, margin, density)
        _pack(log, tex, margin, density, udim=True, exact=True, stack=True)
        _postflight(log, tex, margin, density)
    elif action in {'GAME_LIGHTMAP', 'UNREAL_LIGHTMAP'}:
        _preflight(log, tex, margin, density)
        _run_stage(log, 'lightmap_unique_uv', [
            ('uv.suv_native_projection', {'mode': 'LIGHTMAP_PACK', 'relax_after': False, 'pack_after': False, 'apply_density': False}),
            ('uv.lightmap_pack', {'PREF_MARGIN_DIV': max(1, int(tex / max(1, margin or 8)))}),
            ('uv.suv_pack_pro', {'texture_size': tex, 'margin_px': margin, 'rotation_step': '90'}),
        ], require_one=True)
        _postflight(log, tex, margin, density)
    elif action in {'SCAN_CLEANUP', 'PHOTO_CLEANUP'}:
        _preflight(log, tex, margin, density)
        _repair(log, tex, margin, density)
        _unwrap(log, tex, margin)
        _relax(log, iterations=96)
        _density(log, tex, margin, density)
        _pack(log, tex, margin, density, exact=True, stack=False)
        _postflight(log, tex, margin, density)
    elif action in {'DENSITY_AUDIT', 'AUTO_TD'}:
        _preflight(log, tex, margin, density)
        _density(log, tex, margin, density)
        _run_stage(log, 'checker_visual', [('object.suv_create_checker_material', {})], require_one=False)
        _postflight(log, tex, margin, density)
    elif action in {'DISTORTION_AUDIT', 'HISTOGRAM_PLUS'}:
        _preflight(log, tex, margin, density)
        _run_stage(log, 'visualize_distortion', [
            ('object.suv_visualize_stretch_heatmap', {}),
            ('uv.suv_histogram_tools', {}),
            ('uv.suv_issue_audit_tools', {}),
        ], require_one=False)
        _postflight(log, tex, margin, density)
    else:
        try:
            from . import smart_uv_precision as _precision
            runner = getattr(_precision, 'run_precision_action', None)
            if callable(runner) and runner(action, context):
                after = _metrics(context)
                _write_report(context, action=action, before=before, after=after, log=log, extra={'fallback': 'smart_uv_precision'})
                return True
        except Exception:
            pass
        _preflight(log, tex, margin, density)
        _density(log, tex, margin, density)
        _pack(log, tex, margin, density, exact=True, stack=True)
        _postflight(log, tex, margin, density)
    after = _metrics(context)
    _write_report(context, action=action, before=before, after=after, log=log)
    return any(bool(item.get('ok')) for item in log)


def enhance_action(action, context=None) -> bool:
    action = str(action or '').strip().upper()
    mapped = {
        'SUPER_AUTO': 'DIRECTOR_AUTO',
        'FULL_AUTO': 'DIRECTOR_AUTO',
        'AUTO_UV_SAFE': 'ADAPTIVE_AUTO',
        'PACK_HEURISTIC': 'PACK_SUPREME',
        'PACK_EXACT': 'PACK_SUPREME',
        'PRIORITY_DENSITY_PACK': 'DENSITY_PACK_V2',
        'TD_GET': 'DENSITY_AUDIT',
        'TD_SET': 'AUTO_TD',
        'TD_NORMALIZE': 'AUTO_TD',
        'FIX_ALL': 'SCAN_CLEANUP',
        'INSPECT_SCAN': 'DISTORTION_AUDIT',
        'STRETCH_HEATMAP': 'DISTORTION_AUDIT',
        'DISTORTION_SHADER': 'DISTORTION_AUDIT',
        'UVPACKMASTER_BRIDGE': 'UVPACKMASTER_STYLE',
        'RIZOM_BRIDGE': 'RIZOM_STYLE',
        'HEADUS_BRIDGE': 'HEADUS_KNEAD',
        'SMART_TEXTURE_BRIDGE': 'SMART_TEXTURE_PLUS',
    }.get(action, action)
    return run_excellence_action(mapped, context)


def enhance_feature(entry, context=None) -> bool:
    if not isinstance(entry, dict):
        return False
    text = ' '.join(str(entry.get(k) or '') for k in ('tool', 'feature', 'category', 'detail', 'detail_en')).lower()
    if any(word in text for word in ('texel', 'density', 'autotd', 'world scale')):
        return run_excellence_action('AUTO_TD', context)
    if any(word in text for word in ('histogram', 'distortion', 'heatmap', 'stretch', 'inspect')):
        return run_excellence_action('DISTORTION_AUDIT', context)
    if any(word in text for word in ('pack', 'packing', 'uvpackmaster', 'gpu', 'udim', 'tile', 'rizom')):
        return run_excellence_action('PACK_SUPREME', context)
    if any(word in text for word in ('rectify', 'gridify', 'iron', 'te xtools', 'smart_uv_reference', 'align')):
        return run_excellence_action('SMART_TEXTURE_PLUS', context)
    if any(word in text for word in ('headus', 'organic', 'relax', 'knead', 'unwrap', 'unfold', 'slim', 'lscm', 'abf')):
        return run_excellence_action('ORGANIC_UNWRAP', context)
    if any(word in text for word in ('lightmap', 'unreal', 'unity', 'game')):
        return run_excellence_action('GAME_LIGHTMAP', context)
    if any(word in text for word in ('scan', 'photogrammetry', 'repair', 'fix', 'overlap', 'flipped')):
        return run_excellence_action('SCAN_CLEANUP', context)
    return run_excellence_action('DIRECTOR_AUTO', context)


_EXCELLENCE_ACTION_ITEMS = (
    ('DIRECTOR_AUTO', 'Director Auto', 'Adaptive highest-quality route for general production assets.'),
    ('ADAPTIVE_AUTO', 'Safe Director', 'Safer adaptive route with less aggressive seam changes.'),
    ('ORGANIC_UNWRAP', 'Organic Unwrap', 'Unwrap and relax route for characters, cloth and organic forms.'),
    ('HARD_SURFACE', 'Hard Surface', 'Smart UV compact shape cleanup plus density-aware packing.'),
    ('PACK_SUPREME', 'Supreme Pack', 'Density-aware stack, UDIM-capable candidate packing.'),
    ('DENSITY_PACK_V2', 'Density Pack', 'Normalize texel density before high-density packing.'),
    ('UDIM_PRODUCTION', 'UDIM Production', 'Group/tile-aware production UDIM route.'),
    ('GAME_LIGHTMAP', 'Game Lightmap', 'Unique non-overlap lightmap-oriented UV route.'),
    ('SCAN_CLEANUP', 'Scan Cleanup', 'Repair, unwrap and pack route for scan/noisy mesh UVs.'),
    ('DENSITY_AUDIT', 'Density Audit', 'Measure, normalize and visualize texel density.'),
    ('DISTORTION_AUDIT', 'Distortion Audit', 'Show heatmap/histogram and write a quality report.'),
    ('TRIM_PREP', 'Trim Prep', 'Prepare hard-surface islands for trim-sheet style layout.'),
    ('SMART_TEXTURE_PLUS', 'Smart UV Suite reference Plus', 'Run hard-surface rectify/grid/square cleanup and density pack.'),
    ('UVPACKMASTER_STYLE', 'Packmaster Style', 'Local high-density stack and candidate-pack approximation.'),
    ('RIZOM_STYLE', 'Reference Layout Style', 'UDIM-capable density and exact-shape pack route.'),
    ('HEADUS_KNEAD', 'Smart UV展開参照 Knead', 'Organic unwrap and high-iteration relax route.'),
    ('AUTO_TD', 'AutoTD', 'Automatic texel-density normalize and visual check route.'),
    ('REPORT_SCORE', 'Score Report', 'Write UV quality score without changing the layout.'),
)
_LABELS_JA = {
    'DIRECTOR_AUTO': '統合ディレクター',
    'ADAPTIVE_AUTO': '安全ディレクター',
    'ORGANIC_UNWRAP': '有機展開',
    'HARD_SURFACE': 'ハードサーフェス',
    'PACK_SUPREME': '最高密度パック',
    'DENSITY_PACK_V2': '密度優先パック',
    'UDIM_PRODUCTION': 'UDIM制作',
    'GAME_LIGHTMAP': 'ゲームライトマップ',
    'SCAN_CLEANUP': 'スキャン修復',
    'DENSITY_AUDIT': '密度監査',
    'DISTORTION_AUDIT': '歪み監査',
    'TRIM_PREP': 'トリム準備',
    'SMART_TEXTURE_PLUS': 'Smart UV Suite reference強化',
    'UVPACKMASTER_STYLE': 'Packmaster風',
    'RIZOM_STYLE': 'Reference Layout風',
    'HEADUS_KNEAD': 'Smart UV展開参照風リラックス',
    'AUTO_TD': '自動TD',
    'REPORT_SCORE': 'スコアレポート',
}
_DESC_JA = {
    'DIRECTOR_AUTO': '一般制作アセット向けに、検査・シーム・展開・リラックス・密度・パックを一括で最適化します。',
    'ADAPTIVE_AUTO': '既存UVやシームをなるべく壊さず、安全寄りに高精度化します。',
    'ORGANIC_UNWRAP': 'キャラクター、布、有機形状向けに歪み低減とリラックスを優先します。',
    'HARD_SURFACE': 'Smart UV Suite reference風の矩形化・グリッド化・方向補正を優先してから密度とパックを整えます。',
    'PACK_SUPREME': 'スタック、密度、余白、UDIM候補を考慮して高密度パックします。',
    'DENSITY_PACK_V2': 'テクセル密度を揃えた後に、候補パックと検査を実行します。',
    'UDIM_PRODUCTION': 'マテリアル/グループ単位でUDIM制作向けにタイル配置します。',
    'GAME_LIGHTMAP': 'ゲームエンジン向けに重なりのないライトマップUVを作成します。',
    'SCAN_CLEANUP': 'スキャンや破損気味のメッシュ向けに反転・重なりを修復して展開し直します。',
    'DENSITY_AUDIT': '密度測定、正規化、チェッカー表示、検査レポートを実行します。',
    'DISTORTION_AUDIT': '歪みヒートマップ、ヒストグラム、問題監査を実行します。',
    'TRIM_PREP': 'トリムシート向けにハードサーフェスUVを矩形・方向・密度優先で整えます。',
    'SMART_TEXTURE_PLUS': 'Smart UV Suite reference風の整形を強化し、矩形化、グリッド化、密度、パックまで実行します。',
    'UVPACKMASTER_STYLE': 'ローカル機能で、類似スタックと候補パックを使った高密度配置を狙います。',
    'RIZOM_STYLE': 'UDIM、密度、Exact形状寄りの候補パックを重視する制作向けルートです。',
    'HEADUS_KNEAD': '有機形状向けに展開と高反復リラックスを重視します。',
    'AUTO_TD': '自動でテクセル密度を測定・正規化し、視覚確認まで行います。',
    'REPORT_SCORE': 'UVを変更せず、品質スコアと推奨修正をレポートします。',
}


def action_label(action, context=None) -> str:
    action = str(action or '').strip().upper()
    en = {k: v for k, v, _ in _EXCELLENCE_ACTION_ITEMS}.get(action, action)
    return _tr(context, en, _LABELS_JA.get(action, en))


class SMARTUVEXCELLENCE_OT_action(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.excellence_action'
    bl_label = 'Excellence Action'
    bl_description = 'Run an asset-specific, high-precision UV Suite Excellence route with measurable preflight and postflight reports.'
    bl_options = {'UNDO'}

    action: bpy.props.EnumProperty(name='Action', items=_EXCELLENCE_ACTION_ITEMS, default='DIRECTOR_AUTO', options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        action = str(getattr(properties, 'action', '') or 'DIRECTOR_AUTO').upper()
        desc_en = {k: d for k, _l, d in [(key, label, desc) for key, label, desc in _EXCELLENCE_ACTION_ITEMS]}.get(action, '')
        return _tr(context, desc_en or 'Run a UV Suite Excellence route.', _DESC_JA.get(action, 'UV Suite Excellenceルートを実行します。'))

    def execute(self, context):
        action = str(getattr(self, 'action', '') or 'DIRECTOR_AUTO').upper()
        if run_excellence_action(action, context):
            self.report({'INFO'}, _tr(context, f'UV Suite Excellence completed: {action}', f'UV Suite Excellence完了: {_LABELS_JA.get(action, action)}'))
            return {'FINISHED'}
        self.report({'WARNING'}, _tr(context, 'UV Suite Excellence route could not complete. Check active mesh, edit mode, UV layer, and selection.', 'UV Suite Excellenceルートを完了できませんでした。アクティブメッシュ、編集モード、UVレイヤー、選択状態を確認してください。'))
        return {'CANCELLED'}


_CLASSES = (SMARTUVEXCELLENCE_OT_action,)
_REGISTERED = []


def _rebuild_annotations():
    try:
        SMARTUVEXCELLENCE_OT_action.__annotations__ = {
            'action': bpy.props.EnumProperty(name='Action', items=_EXCELLENCE_ACTION_ITEMS, default='DIRECTOR_AUTO', options={'SKIP_SAVE'}),
        }
    except Exception:
        pass


def register():
    _rebuild_annotations()
    try:
        from .bootstrap_common import safe_register_class
    except Exception:
        safe_register_class = None
    for cls in _CLASSES:
        try:
            if bool(getattr(cls, 'is_registered', False)) or getattr(cls, '__dict__', {}).get('bl_rna') is not None:
                if cls not in _REGISTERED:
                    _REGISTERED.append(cls)
                continue
        except Exception:
            pass
        ok = False
        if callable(safe_register_class):
            try:
                ok = bool(safe_register_class(cls))
            except Exception:
                ok = False
        if not ok:
            try:
                _suv_resource.register_class(cls)
                ok = True
            except Exception:
                ok = False
        if ok and cls not in _REGISTERED:
            _REGISTERED.append(cls)


def unregister():
    for cls in reversed(_REGISTERED or list(_CLASSES)):
        try:
            _suv_resource.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED.clear()


__all__ = [
    'register', 'unregister', 'run_excellence_action', 'enhance_action', 'enhance_feature',
    'last_report', 'action_label', 'operator_exists',
]
