# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Unified automatic packing bridge for Smart UV Suite.

This module consolidates packing behaviours found in the attached UV tools into
one Smart UV controlled route without copying third-party source code:
- Blender native Pack Islands shape modes, margin methods, scale/rotate/pin lock.
- UV Toolkit style cursor/UDIM-tile packing and optional random seeded pre-shuffle.
- TexTools style unwrap-finish padding/no-rotation pack behaviour.
- Smart UV Suite Pack Pro deterministic/group/material/similar/identical/UDIM modes.
- Smart UV Suite density-priority, lightmap, hotspot grid and trim-layout routes.

Every execution is wrapped by StrictUVFaceScope, so only UV Editor faces that are
fully face-selected are modified.  Non-selected UVs and 3D View mesh selection
are restored by the scope guard.
"""
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

import math
import random
from typing import Any, Iterable

import bpy
import bmesh
from mathutils import Vector

_REGISTERED: list[type] = []
_IN_UNIFIED_AUTO_PACK = 0


def _tr(context, en: str, ja: str) -> str:
    """Return one message in the add-on's active Blender language."""
    try:
        from . import text_translation
        return text_translation.pick(en, ja, context=context)
    except Exception:
        try:
            language = str(getattr(bpy.context.preferences.view, 'language', '') or '').upper()
        except Exception:
            language = ''
        return ja if language.startswith('JA') else en



def _ws(context):
    try:
        return getattr(getattr(context, 'scene', None), 'suv_workspace', None)
    except Exception:
        return None


def _int_attr(obj: Any, name: str, default: int, min_v: int | None = None, max_v: int | None = None) -> int:
    try:
        value = int(getattr(obj, name, default))
    except Exception:
        value = int(default)
    if min_v is not None:
        value = max(int(min_v), value)
    if max_v is not None:
        value = min(int(max_v), value)
    return value


def _float_attr(obj: Any, name: str, default: float, min_v: float | None = None, max_v: float | None = None) -> float:
    try:
        value = float(getattr(obj, name, default))
    except Exception:
        value = float(default)
    if min_v is not None:
        value = max(float(min_v), value)
    if max_v is not None:
        value = min(float(max_v), value)
    return value


def _bool_attr(obj: Any, name: str, default: bool = False) -> bool:
    try:
        return bool(getattr(obj, name, default))
    except Exception:
        return bool(default)


def _str_attr(obj: Any, name: str, default: str = '') -> str:
    try:
        value = str(getattr(obj, name, default) or default)
    except Exception:
        value = str(default)
    return value


def _operator_exists(op_id: str) -> bool:
    try:
        prefix, name = str(op_id).split('.', 1)
        op = getattr(getattr(bpy.ops, prefix), name)
        rna = op.get_rna_type()
        ident = str(getattr(rna, 'identifier', '') or '')
        return bool(ident) and ident not in {'Operator', 'OperatorProperties', 'UnknownType', 'bpy_struct'}
    except Exception:
        return False


def _operator_property_names(op_id: str) -> set[str]:
    try:
        prefix, name = str(op_id).split('.', 1)
        op = getattr(getattr(bpy.ops, prefix), name)
        props = getattr(op.get_rna_type(), 'properties', None)
        return {str(getattr(p, 'identifier', '') or '') for p in props if str(getattr(p, 'identifier', '') or '') not in {'rna_type'}}
    except Exception:
        return set()


def _call_op(op_id: str, *, invoke: bool = False, **kwargs):
    if not _operator_exists(op_id):
        return {'CANCELLED'}
    prefix, name = str(op_id).split('.', 1)
    op = getattr(getattr(bpy.ops, prefix), name)
    allowed = _operator_property_names(op_id)
    if allowed:
        kwargs = {k: v for k, v in dict(kwargs).items() if str(k) in allowed}
    try:
        return op('INVOKE_DEFAULT' if invoke else 'EXEC_DEFAULT', **kwargs)
    except TypeError:
        # Blender native operators differ slightly between 5.1 builds.  Strip the
        # least-portable arguments cumulatively and retry before failing.
        reduced = dict(kwargs)
        for key in ('shape_method', 'pin', 'scale', 'margin_method', 'rotate_method'):
            reduced.pop(key, None)
            try:
                return op('INVOKE_DEFAULT' if invoke else 'EXEC_DEFAULT', **reduced)
            except TypeError:
                continue
            except Exception:
                continue
        try:
            return op('EXEC_DEFAULT')
        except Exception:
            return {'CANCELLED'}
    except Exception:
        return {'CANCELLED'}


def _ok(result) -> bool:
    try:
        return 'FINISHED' in set(result or [])
    except Exception:
        return False


def _active_mesh_obj(context):
    obj = getattr(context, 'edit_object', None) or getattr(context, 'active_object', None)
    if obj is not None and getattr(obj, 'type', None) == 'MESH':
        return obj
    return None


def _selected_faces(bm) -> list:
    return [f for f in bm.faces if bool(getattr(f, 'select', False))]

def _strict_selected_faces_from_uv_attrs(obj, bm) -> list:
    """Return fully UV-face-selected faces from Blender 5.1 hidden UV attrs."""
    try:
        me = getattr(obj, 'data', None)
        attrs = getattr(me, 'attributes', None)
        face_attr = attrs.get('.uv_select_face') if attrs is not None else None
        vert_attr = attrs.get('.uv_select_vert') if attrs is not None else None
        if face_attr is None or vert_attr is None:
            return []
        face_flags = [bool(getattr(x, 'value', False)) for x in getattr(face_attr, 'data', [])]
        vert_flags = [bool(getattr(x, 'value', False)) for x in getattr(vert_attr, 'data', [])]
        if not any(face_flags):
            return []
        out = []
        try:
            bm.faces.ensure_lookup_table(); bm.faces.index_update()
        except Exception:
            pass
        for face in bm.faces:
            try:
                fi = int(face.index)
                if fi < 0 or fi >= len(face_flags) or not face_flags[fi]:
                    continue
                ok = True
                for loop in face.loops:
                    li = int(getattr(loop, 'index', -1))
                    if li < 0 or li >= len(vert_flags) or not vert_flags[li]:
                        ok = False
                        break
                if ok:
                    out.append(face)
            except Exception:
                pass
        return out
    except Exception:
        return []


def _selected_bbox(obj) -> tuple[Vector, Vector] | None:
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        pts = []
        for face in _selected_faces(bm):
            for loop in face.loops:
                pts.append(Vector(loop[uv_layer].uv))
        if not pts:
            return None
        mn = Vector((min(p.x for p in pts), min(p.y for p in pts)))
        mx = Vector((max(p.x for p in pts), max(p.y for p in pts)))
        return mn, mx
    except Exception:
        return None


def _translate_selected_uvs_to_tile(context, tile_u: int, tile_v: int) -> bool:
    obj = _active_mesh_obj(context)
    if obj is None:
        return False
    try:
        if str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT') != 'EDIT':
            bpy.ops.object.mode_set(mode='EDIT')
    except Exception:
        pass
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        faces = _selected_faces(bm)
        pts = [Vector(loop[uv_layer].uv) for face in faces for loop in face.loops]
        if not pts:
            return False
        mn = Vector((min(p.x for p in pts), min(p.y for p in pts)))
        current_tile = Vector((math.floor(mn.x), math.floor(mn.y)))
        delta = Vector((float(tile_u), float(tile_v))) - current_tile
        if delta.length <= 1.0e-12:
            return True
        for face in faces:
            for loop in face.loops:
                loop[uv_layer].uv = Vector(loop[uv_layer].uv) + delta
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return True
    except Exception:
        return False


def _cursor_tile(context) -> tuple[int, int]:
    try:
        loc = getattr(getattr(context, 'space_data', None), 'cursor_location', None)
        if loc is not None:
            return int(math.floor(float(loc[0]))), int(math.floor(float(loc[1])))
    except Exception:
        pass
    return 0, 0


def _build_islands(obj):
    try:
        from . import pro_operators as _pro
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        faces = _strict_selected_faces_from_uv_attrs(obj, bm) or _selected_faces(bm)
        if not faces:
            return bm, uv_layer, []
        islands = list(_pro.build_islands(bm, uv_layer, faces_subset=faces))
        return bm, uv_layer, islands
    except Exception:
        return None, None, []


def _rotate2(vec: Vector, angle: float) -> Vector:
    c = math.cos(angle); s = math.sin(angle)
    return Vector((vec.x * c - vec.y * s, vec.x * s + vec.y * c))


def _randomize_selected_islands(context, seed: int, *, rotate: bool = True) -> bool:
    obj = _active_mesh_obj(context)
    if obj is None:
        return False
    bm, uv_layer, islands = _build_islands(obj)
    if bm is None or uv_layer is None or not islands:
        return False
    rng = random.Random(int(seed))
    try:
        for isl in islands:
            center = Vector(getattr(isl, 'uv_centroid', Vector((0.0, 0.0))))
            angle = math.radians(rng.uniform(-180.0, 180.0)) if rotate else 0.0
            offset = Vector((rng.uniform(-3.0, 3.0), rng.uniform(-3.0, 3.0)))
            seen = set()
            for face in getattr(isl, 'faces', []) or []:
                for loop in face.loops:
                    key = (int(getattr(face, 'index', -1)), int(list(face.loops).index(loop)) if loop in face.loops else id(loop))
                    if key in seen:
                        continue
                    seen.add(key)
                    uv = Vector(loop[uv_layer].uv)
                    loop[uv_layer].uv = center + _rotate2(uv - center, angle) + offset
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return True
    except Exception:
        return False


def _run_native_pack(context, ws, *, force_no_rotate: bool = False, force_pin: bool | None = None, force_mode: str | None = None) -> bool:
    margin = _float_attr(ws, 'unified_pack_margin', 0.001, 0.0, 1.0)
    method = _str_attr(ws, 'unified_pack_margin_method', 'SCALED').upper()
    shape = _str_attr(ws, 'unified_pack_shape_method', 'CONCAVE').upper()
    if force_mode == 'AABB':
        shape = 'AABB'
    elif force_mode == 'CONVEX':
        shape = 'CONVEX'
    elif force_mode == 'CONCAVE':
        shape = 'CONCAVE'
    rotate = _bool_attr(ws, 'unified_pack_rotate', True) and not force_no_rotate
    scale = _bool_attr(ws, 'unified_pack_scale', True)
    pin = _bool_attr(ws, 'unified_pack_lock_pinned', True) if force_pin is None else bool(force_pin)
    kwargs = dict(rotate=rotate, scale=scale, margin_method=method, margin=margin, pin=pin, shape_method=shape)
    return _ok(_call_op('uv.pack_islands', **kwargs))


def _selected_island_loop_keys(island, uv_layer) -> list:
    """Return stable loop references for a selected UV island without touching unselected UVs."""
    loops = []
    seen = set()
    for face in getattr(island, 'faces', []) or []:
        for loop_index, loop in enumerate(face.loops):
            key = (int(getattr(face, 'index', -1)), int(loop_index))
            if key in seen:
                continue
            seen.add(key)
            loops.append(loop)
    return loops


def _island_bbox_from_loops(loops, uv_layer):
    pts = [Vector(loop[uv_layer].uv) for loop in loops]
    if not pts:
        return None
    mn = Vector((min(p.x for p in pts), min(p.y for p in pts)))
    mx = Vector((max(p.x for p in pts), max(p.y for p in pts)))
    return mn, mx


# -----------------------------------------------------------------------------
# Smart UV Suite 1.8.119 - overlap-aware automatic packing units
# -----------------------------------------------------------------------------

def _suv41_bbox_overlap(mn_a: Vector, mx_a: Vector, mn_b: Vector, mx_b: Vector, eps: float = 1.0e-8) -> bool:
    """Return True only when two UV boxes have positive overlapping area."""
    try:
        return (min(float(mx_a.x), float(mx_b.x)) - max(float(mn_a.x), float(mn_b.x)) > eps and
                min(float(mx_a.y), float(mx_b.y)) - max(float(mn_a.y), float(mn_b.y)) > eps)
    except Exception:
        return False


def _suv41_poly_bbox(points):
    pts = [Vector(p) for p in points or []]
    if not pts:
        z = Vector((0.0, 0.0))
        return z, z
    return Vector((min(p.x for p in pts), min(p.y for p in pts))), Vector((max(p.x for p in pts), max(p.y for p in pts)))


def _suv41_signed2(a: Vector, b: Vector, c: Vector) -> float:
    return float((b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x))


def _suv41_point_on_segment(p: Vector, a: Vector, b: Vector, eps: float = 1.0e-8) -> bool:
    try:
        if abs(_suv41_signed2(a, b, p)) > eps:
            return False
        return (min(a.x, b.x) - eps <= p.x <= max(a.x, b.x) + eps and
                min(a.y, b.y) - eps <= p.y <= max(a.y, b.y) + eps)
    except Exception:
        return False


def _suv41_point_in_poly_strict(point: Vector, poly, eps: float = 1.0e-8) -> bool:
    """Ray-cast point-in-polygon. Boundary-only contact is not treated as overlap."""
    pts = [Vector(p) for p in poly or []]
    n = len(pts)
    if n < 3:
        return False
    try:
        for i in range(n):
            if _suv41_point_on_segment(point, pts[i], pts[(i + 1) % n], eps):
                return False
        inside = False
        x = float(point.x); y = float(point.y)
        j = n - 1
        for i in range(n):
            yi = float(pts[i].y); yj = float(pts[j].y)
            xi = float(pts[i].x); xj = float(pts[j].x)
            if (yi > y) != (yj > y):
                x_cross = (xj - xi) * (y - yi) / (yj - yi) + xi
                if x < x_cross - eps:
                    inside = not inside
            j = i
        return bool(inside)
    except Exception:
        return False


def _suv41_segments_cross_area(a: Vector, b: Vector, c: Vector, d: Vector, eps: float = 1.0e-8) -> bool:
    """Strict segment crossing. Colinear/boundary-only touch is ignored."""
    try:
        o1 = _suv41_signed2(a, b, c)
        o2 = _suv41_signed2(a, b, d)
        o3 = _suv41_signed2(c, d, a)
        o4 = _suv41_signed2(c, d, b)
        return (o1 * o2 < -eps * eps) and (o3 * o4 < -eps * eps)
    except Exception:
        return False


def _suv41_poly_centroid(points) -> Vector:
    pts = [Vector(p) for p in points or []]
    if not pts:
        return Vector((0.0, 0.0))
    return Vector((sum(p.x for p in pts) / len(pts), sum(p.y for p in pts) / len(pts)))


def _suv41_polygons_overlap_area(poly_a, poly_b, eps: float = 1.0e-8) -> bool:
    """True when two UV face polygons share visible area, including stacked copies."""
    a = [Vector(p) for p in poly_a or []]
    b = [Vector(p) for p in poly_b or []]
    if len(a) < 3 or len(b) < 3:
        return False
    mn_a, mx_a = _suv41_poly_bbox(a)
    mn_b, mx_b = _suv41_poly_bbox(b)
    if not _suv41_bbox_overlap(mn_a, mx_a, mn_b, mx_b, eps):
        return False
    try:
        # Proper edge crossing indicates positive area intersection for normal UV faces.
        for i in range(len(a)):
            a0 = a[i]; a1 = a[(i + 1) % len(a)]
            for j in range(len(b)):
                if _suv41_segments_cross_area(a0, a1, b[j], b[(j + 1) % len(b)], eps):
                    return True
        # Containment / partial overlap tests.  Strict vertex inclusion avoids
        # grouping islands that merely touch along a seam or a single point.
        for p in a:
            if _suv41_point_in_poly_strict(p, b, eps):
                return True
        for p in b:
            if _suv41_point_in_poly_strict(p, a, eps):
                return True
        # Stacked identical polygons have all vertices on the boundary, so use an
        # interior representative point as the final positive-area test.
        ca = _suv41_poly_centroid(a)
        cb = _suv41_poly_centroid(b)
        if _suv41_point_in_poly_strict(ca, b, eps) or _suv41_point_in_poly_strict(cb, a, eps):
            return True
    except Exception:
        return False
    return False


def _suv41_island_polygons(isl, uv_layer, eps: float = 1.0e-10):
    polys = []
    for face in getattr(isl, 'faces', []) or []:
        try:
            pts = [Vector(loop[uv_layer].uv) for loop in face.loops]
            if len(pts) < 3:
                continue
            # Ignore zero-area face loops; they cannot create a visible overlap area.
            area2 = 0.0
            for i in range(len(pts)):
                p0 = pts[i]; p1 = pts[(i + 1) % len(pts)]
                area2 += float(p0.x * p1.y - p1.x * p0.y)
            if abs(area2) <= eps:
                continue
            mn, mx = _suv41_poly_bbox(pts)
            polys.append({'pts': pts, 'min': mn, 'max': mx})
        except Exception:
            pass
    return polys


def _suv41_pack_records_overlap(rec_a, rec_b, eps: float = 1.0e-8) -> bool:
    if not _suv41_bbox_overlap(rec_a.get('min'), rec_a.get('max'), rec_b.get('min'), rec_b.get('max'), eps):
        return False
    polys_a = list(rec_a.get('polys') or [])
    polys_b = list(rec_b.get('polys') or [])
    if not polys_a or not polys_b:
        # If exact polygons are unavailable, prefer preserving visible stacks over
        # accidentally separating them.
        return True
    checks = 0
    max_checks = 4096
    # Iterate smaller list outside to keep heavy UV islands responsive.
    if len(polys_b) < len(polys_a):
        polys_a, polys_b = polys_b, polys_a
    for pa in polys_a:
        pa_min = pa.get('min'); pa_max = pa.get('max')
        for pb in polys_b:
            if not _suv41_bbox_overlap(pa_min, pa_max, pb.get('min'), pb.get('max'), eps):
                continue
            checks += 1
            if checks > max_checks:
                # Heavy stacked/near-stacked data: group conservatively to avoid a
                # slow exact-polygon stall during auto packing.
                return True
            if _suv41_polygons_overlap_area(pa.get('pts'), pb.get('pts'), eps):
                return True
    return False


def _suv41_merge_overlapping_pack_records(records, eps: float = 1.0e-8):
    """Merge all transitive UV-overlapping islands into one pack record.

    Each returned record is placed as one rectangle while all loops inside the
    record keep their relative UV offsets.  This is the requested behaviour for
    stacked or partially overlapping UV islands in automatic packing.
    """
    records = [r for r in list(records or []) if r is not None]
    n = len(records)
    if n <= 1:
        for r in records:
            r['overlap_group_size'] = 1
        return records

    parent = list(range(n))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    def union(a, b):
        ra = find(a); rb = find(b)
        if ra != rb:
            parent[rb] = ra

    order = sorted(range(n), key=lambda idx: (float(records[idx]['min'].x), float(records[idx]['min'].y), idx))
    active = []
    for idx in order:
        mn = records[idx]['min']
        active = [j for j in active if float(records[j]['max'].x) >= float(mn.x) - eps]
        for j in active:
            if _suv41_pack_records_overlap(records[idx], records[j], eps):
                union(idx, j)
        active.append(idx)

    buckets = {}
    order_key = {}
    for i in range(n):
        root = find(i)
        buckets.setdefault(root, []).append(i)
        order_key[root] = min(order_key.get(root, i), i)

    merged = []
    for root in sorted(buckets, key=lambda r: order_key.get(r, r)):
        inds = buckets[root]
        if len(inds) == 1:
            rec = dict(records[inds[0]])
            rec['overlap_group_size'] = 1
            merged.append(rec)
            continue
        parts = [records[i] for i in inds]
        mn = Vector((min(float(p['min'].x) for p in parts), min(float(p['min'].y) for p in parts)))
        mx = Vector((max(float(p['max'].x) for p in parts), max(float(p['max'].y) for p in parts)))
        out = {
            'min': mn,
            'max': mx,
            'w': max(float(mx.x - mn.x), 1.0e-8),
            'h': max(float(mx.y - mn.y), 1.0e-8),
            'polys': [],
            'loop_refs': [],
            'loop_keys': [],
            'overlap_group_size': len(inds),
        }
        for p in parts:
            out['polys'].extend(list(p.get('polys') or []))
            out['loop_refs'].extend(list(p.get('loop_refs') or []))
            out['loop_keys'].extend(list(p.get('loop_keys') or []))
        merged.append(out)
    return merged


def _suv41_selected_records_have_overlap(context) -> bool:
    obj = _active_mesh_obj(context)
    if obj is None:
        return False
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        faces = _strict_selected_faces_from_uv_attrs(obj, bm) or _selected_faces(bm)
        if not faces:
            return False
        try:
            from . import core as _core
            islands = list(_core.build_islands(bm, uv_layer, faces_subset=faces))
        except Exception:
            islands = []
        if len(islands) <= 1:
            return False
        records = []
        for isl in islands:
            loops = _selected_island_loop_keys(isl, uv_layer)
            bbox = _island_bbox_from_loops(loops, uv_layer)
            if bbox is None:
                continue
            mn, mx = bbox
            records.append({'min': mn, 'max': mx, 'polys': _suv41_island_polygons(isl, uv_layer)})
        if len(records) <= 1:
            return False
        merged = _suv41_merge_overlapping_pack_records(records)
        return len(merged) < len(records)
    except Exception:
        return False


def _pack_shelf_rects(rects, target_w: float, target_h: float, margin: float):
    """Simple deterministic shelf pack used as a safe non-recursive fallback."""
    if not rects:
        return []
    # Initial placement in normalized source units.
    ordered = sorted(rects, key=lambda r: (-(r['h'] * r['w']), -max(r['w'], r['h']), r['index']))
    x = margin
    y = margin
    shelf_h = 0.0
    max_x = margin
    placements = {}
    for rect in ordered:
        w = max(rect['w'], 1.0e-9)
        h = max(rect['h'], 1.0e-9)
        if x > margin and x + w + margin > target_w:
            x = margin
            y += shelf_h + margin
            shelf_h = 0.0
        placements[rect['index']] = (x, y)
        x += w + margin
        shelf_h = max(shelf_h, h)
        max_x = max(max_x, x)
    used_w = max(max_x + margin, margin * 2.0 + 1.0e-9)
    used_h = max(y + shelf_h + margin, margin * 2.0 + 1.0e-9)
    scale = min(target_w / used_w, target_h / used_h, 1.0)
    out = []
    for rect in rects:
        px, py = placements[rect['index']]
        out.append((rect['index'], px * scale, py * scale, scale))
    return out


def _run_bmesh_aabb_pack(context, ws, *, target_tile: tuple[int, int] | None = None, force_no_rotate: bool = False, fit_to_bounds: bool = True) -> bool:
    """Pack selected UV islands without calling bpy.ops.uv.pack_islands.

    This avoids recursive operator wrappers and preserves the strict Smart UV rule:
    only UV faces fully selected in the UV editor are modified.  The caller may
    wrap this with StrictUVFaceScope; unselected loops are never written here.
    """
    obj = _active_mesh_obj(context)
    if obj is None:
        return False
    try:
        if str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT') != 'EDIT':
            bpy.ops.object.mode_set(mode='EDIT')
    except Exception:
        pass
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        faces = _strict_selected_faces_from_uv_attrs(obj, bm) or _selected_faces(bm)
        if not faces:
            return False
        try:
            from . import core as _core
            islands = list(_core.build_islands(bm, uv_layer, faces_subset=faces))
        except Exception:
            islands = []
        if not islands:
            # Fallback: each selected face becomes one island.  This is still
            # selected-face safe and preferable to a failed/recursive pack.
            class _FaceIsland:
                pass
            islands = []
            for i, face in enumerate(faces):
                isl = _FaceIsland()
                isl.id = i
                isl.faces = [face]
                islands.append(isl)
        tile_u, tile_v = target_tile if target_tile is not None else (_int_attr(ws, 'unified_pack_tile_u', 0), _int_attr(ws, 'unified_pack_tile_v', 0))
        tile_u = int(tile_u); tile_v = int(tile_v)
        tex = max(1, _int_attr(ws, 'canvas_size', 2048, 1, 65536))
        margin_uv = _float_attr(ws, 'unified_pack_margin', 0.001, 0.0, 0.5)
        margin_px = _int_attr(ws, 'unified_pack_margin_px', _int_attr(ws, 'fit_padding_px', 8, 0, 512), 0, 4096)
        margin = max(margin_uv, float(margin_px) / float(tex))
        margin = min(max(margin, 0.0), 0.45)
        usable_min = Vector((tile_u + margin, tile_v + margin))
        usable_max = Vector((tile_u + 1.0 - margin, tile_v + 1.0 - margin))
        usable_w = max(1.0e-9, usable_max.x - usable_min.x)
        usable_h = max(1.0e-9, usable_max.y - usable_min.y)
        island_data = []
        for idx, isl in enumerate(islands):
            loops = _selected_island_loop_keys(isl, uv_layer)
            bbox = _island_bbox_from_loops(loops, uv_layer)
            if bbox is None:
                continue
            mn, mx = bbox
            size = mx - mn
            w = max(float(size.x), 1.0e-8)
            h = max(float(size.y), 1.0e-8)
            loop_refs = []
            seen_loop_keys = set()
            for loop in loops:
                try:
                    key = (int(getattr(loop.face, 'index', -1)), int(list(loop.face.loops).index(loop)))
                except Exception:
                    key = id(loop)
                if key in seen_loop_keys:
                    continue
                seen_loop_keys.add(key)
                loop_refs.append((loop, Vector(loop[uv_layer].uv)))
            if not loop_refs:
                continue
            island_data.append({
                'island': isl,
                'loop_refs': loop_refs,
                'min': mn,
                'max': mx,
                'w': w,
                'h': h,
                'polys': _suv41_island_polygons(isl, uv_layer),
            })
        island_data = _suv41_merge_overlapping_pack_records(island_data)
        if not island_data:
            return False
        rects = [{'index': i, 'w': d['w'], 'h': d['h']} for i, d in enumerate(island_data)]
        # Normalize source rects before packing so very large UV coordinates do not
        # produce numerical overflow or excessive shelf dimensions.
        total_area = sum(max(d['w'], 1e-8) * max(d['h'], 1e-8) for d in island_data)
        if total_area <= 1.0e-12:
            base_scale = 1.0
        else:
            base_scale = math.sqrt((usable_w * usable_h * 0.82) / total_area)
        # Avoid enlarging tiny UVs too aggressively; panel scale behaviour is handled by fit below.
        base_scale = max(1.0e-8, min(base_scale, 1000000.0))
        scaled_rects = []
        for r in rects:
            scaled_rects.append({'index': r['index'], 'w': r['w'] * base_scale, 'h': r['h'] * base_scale})
        placements = _pack_shelf_rects(scaled_rects, usable_w, usable_h, margin)
        placement_map = {idx: (x, y, sc) for idx, x, y, sc in placements}
        for idx, data in enumerate(island_data):
            px, py, shelf_scale = placement_map.get(idx, (margin, margin, 1.0))
            scale = base_scale * shelf_scale
            dst_min = usable_min + Vector((px, py))
            src_min = data['min']
            for loop, original_uv in data.get('loop_refs', []) or []:
                uv = Vector(original_uv)
                loop[uv_layer].uv = dst_min + (uv - src_min) * scale
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return True
    except Exception:
        return False


def _run_pack_pro(context, ws, **override) -> bool:
    tex = _int_attr(ws, 'canvas_size', 2048, 128, 16384)
    margin_px = _int_attr(ws, 'unified_pack_margin_px', _int_attr(ws, 'fit_padding_px', 8, 0, 512), 0, 1024)
    rot = _str_attr(ws, 'unified_pack_rotation_step', '15')
    group_mode = _str_attr(ws, 'pack_group_mode', 'SIMILAR')
    group_layout = _str_attr(ws, 'pack_group_layout', 'SINGLE_TILE')
    kwargs = dict(
        engine='DETERMINISTIC', scope='SELECTED', udim_mode='SINGLE', margin_px=margin_px,
        texture_size=tex, rotation_step=rot, lock_pinned=_bool_attr(ws, 'unified_pack_lock_pinned', True),
        group_mode='NONE', group_layout=group_layout,
        area_tol=_float_attr(ws, 'similarity_area_tol', 0.08, 0.0, 1.0),
        aspect_tol=_float_attr(ws, 'similarity_aspect_tol', 0.15, 0.0, 1.0),
        start_tile_u=_int_attr(ws, 'unified_pack_tile_u', 0),
        start_tile_v=_int_attr(ws, 'unified_pack_tile_v', 0),
        tile_columns=_int_attr(ws, 'unified_pack_tile_columns', 10, 1, 100),
        tile_fill=_str_attr(ws, 'unified_pack_tile_fill', 'ROW'),
        stack_identical_groups=_bool_attr(ws, 'unified_pack_stack_identical', True),
    )
    kwargs.update(override)
    return _ok(_call_op('uv.suv_pack_pro', **kwargs))


def _run_density_priority(context, ws) -> bool:
    tex = _int_attr(ws, 'canvas_size', 2048, 128, 16384)
    margin_px = _int_attr(ws, 'unified_pack_margin_px', _int_attr(ws, 'fit_padding_px', 8, 0, 512), 0, 1024)
    density = _float_attr(ws, 'workflow_density', 1024.0, 1.0, None)
    result = _call_op('uv.suv_priority_density_pack', texture_size=tex, margin_px=margin_px, base_density=density, scope='SELECTED')
    if _ok(result):
        return True
    return _run_pack_pro(context, ws)


def _run_lightmap(context, ws) -> bool:
    kwargs = dict(
        PREF_CONTEXT=_str_attr(ws, 'native_lightmap_context', 'SEL_FACES'),
        PREF_PACK_IN_ONE=_bool_attr(ws, 'native_lightmap_pack_in_one', True),
        PREF_NEW_UVLAYER=_bool_attr(ws, 'native_lightmap_new_uvlayer', False),
        PREF_BOX_DIV=_int_attr(ws, 'native_lightmap_box_div', 12, 1, 48),
        PREF_MARGIN_DIV=_float_attr(ws, 'native_lightmap_margin_div', 0.1, 0.001, 1.0),
    )
    if _ok(_call_op('uv.lightmap_pack', **kwargs)):
        return True
    return _run_native_pack(context, ws)


def _run_hotspot(context, ws) -> bool:
    tex = _int_attr(ws, 'canvas_size', 2048, 128, 16384)
    pad = _int_attr(ws, 'unified_pack_margin_px', _int_attr(ws, 'fit_padding_px', 8, 0, 512), 0, 1024)
    kwargs = dict(
        mode='GROUPS_TO_CELLS',
        group_mode=_str_attr(ws, 'pack_group_mode', 'SIMILAR'),
        cols=_int_attr(ws, 'hotspot_cols', 4, 1, 64),
        rows=_int_attr(ws, 'hotspot_rows', 4, 1, 64),
        texture_size=tex,
        padding_px=pad,
        keep_aspect=_bool_attr(ws, 'hotspot_keep_aspect', True),
        sort_mode=_str_attr(ws, 'hotspot_sort', 'AREA'),
        fill_order=_str_attr(ws, 'hotspot_fill_order', 'ROW'),
    )
    return _ok(_call_op('uv.suv_hotspot_cell_tools', **kwargs)) or _run_pack_pro(context, ws, group_mode=_str_attr(ws, 'pack_group_mode', 'SIMILAR'))


def _run_trim(context, ws) -> bool:
    tex = _int_attr(ws, 'canvas_size', 2048, 128, 16384)
    pad = _int_attr(ws, 'unified_pack_margin_px', _int_attr(ws, 'fit_padding_px', 8, 0, 512), 0, 1024)
    if _ok(_call_op('uv.suv_trim_strip_layout', texture_size=tex, padding_px=pad, scope='SELECTED')):
        return True
    if _ok(_call_op('uv.suv_trim_band_layout', texture_size=tex, padding_px=pad, scope='SELECTED')):
        return True
    return _run_pack_pro(context, ws, group_mode='IDENTICAL', group_layout='ROWS')


def _run_atlas_cell(context, ws) -> bool:
    """Run the atlas-cell layout formerly exposed by Pack / Atlas / Trim."""
    try:
        from . import native_unified_tools as _nut
        fn = getattr(_nut, '_atlas_cell', None)
        if callable(fn) and int(fn(context) or 0) > 0:
            return True
    except Exception:
        pass
    return _run_hotspot(context, ws)



def _selected_uv_island_density_rescale(context, ws, strength: float = 1.0) -> bool:
    """Normalize selected islands to source mesh area before reference-style packs."""
    if not _bool_attr(ws, 'unified_pack_chart_rescale', True):
        return False
    obj = _active_mesh_obj(context)
    if obj is None:
        return False
    try:
        # Reuse Smart Standard's tested area-ratio pass when available.
        from . import smart_uv_standard as _std
        me = obj.data
        return bool(_std._apply_mesh_area_preserving_uv_layout(
            me,
            iterations=24,
            quality_strength=max(0.0, min(1.0, float(strength))),
            area_strength=max(0.0, min(1.0, float(strength))),
            shape_strength=0.35 * max(0.0, min(1.0, float(strength))),
            original_preserve=0.25,
            scope=None,
        ))
    except Exception:
        return False


def _fit_selected_uvs_to_aspect(context, ws) -> bool:
    """Fit selected UVs to the requested atlas aspect ratio without touching unselected UVs."""
    obj = _active_mesh_obj(context)
    if obj is None:
        return False
    width = max(1, _int_attr(ws, 'unified_pack_target_width', _int_attr(ws, 'canvas_size', 2048, 1, 32768), 1, 32768))
    height = max(1, _int_attr(ws, 'unified_pack_target_height', _int_attr(ws, 'canvas_size', 2048, 1, 32768), 1, 32768))
    aspect = float(width) / float(height)
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        faces = _selected_faces(bm)
        loops = []
        for f in faces:
            loops.extend(list(getattr(f, 'loops', []) or []))
        if not loops:
            return False
        us = [float(l[uv_layer].uv.x) for l in loops]
        vs = [float(l[uv_layer].uv.y) for l in loops]
        min_u, max_u = min(us), max(us)
        min_v, max_v = min(vs), max(vs)
        w = max(max_u - min_u, 1.0e-9)
        h = max(max_v - min_v, 1.0e-9)
        margin = max(0.0, min(0.25, _float_attr(ws, 'unified_pack_margin', 0.001, 0.0, 1.0)))
        target_w = max(1.0e-6, 1.0 - margin * 2.0)
        target_h = max(1.0e-6, (1.0 / max(1.0e-6, aspect)) - margin * 2.0)
        # Preserve shape: uniform scale then center in the aspect-adjusted space.
        scale = min(target_w / w, target_h / h)
        cx = (min_u + max_u) * 0.5
        cy = (min_v + max_v) * 0.5
        dst_cx = 0.5
        dst_cy = (0.5 / max(1.0e-6, aspect))
        for loop in loops:
            uv = loop[uv_layer].uv
            uv.x = (float(uv.x) - cx) * scale + dst_cx
            uv.y = (float(uv.y) - cy) * scale + dst_cy
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return True
    except Exception:
        return False


def _run_chart_distribution_pack(context, ws, *, bake_safe: bool = False, existing_chart: bool = False) -> bool:
    """High-precision chart distribution pack.

    Uses local Smart UV/Blender operators only: density rescale, exact-shape native
    pack, optional bake-safe padding, and final aspect fitting.
    """
    tex = max(64, _int_attr(ws, 'canvas_size', 2048, 64, 32768))
    margin_px = _int_attr(ws, 'unified_pack_margin_px', _int_attr(ws, 'fit_padding_px', 8, 0, 1024), 0, 4096)
    if bake_safe:
        margin_px = max(margin_px, 2 * _int_attr(ws, 'unified_pack_bake_padding_px', 4, 0, 2048))
    margin = max(_float_attr(ws, 'unified_pack_margin', 0.001, 0.0, 1.0), float(margin_px) / float(max(tex, 1)))
    _selected_uv_island_density_rescale(context, ws, strength=0.92 if not existing_chart else 0.55)
    kwargs = dict(
        rotate=_bool_attr(ws, 'unified_pack_rotate', True),
        scale=_bool_attr(ws, 'unified_pack_scale', True),
        margin_method='ADD' if bake_safe else _str_attr(ws, 'unified_pack_margin_method', 'SCALED').upper(),
        margin=margin,
        pin=_bool_attr(ws, 'unified_pack_lock_pinned', True),
        shape_method='CONCAVE',
    )
    ok = _ok(_call_op('uv.pack_islands', **kwargs))
    if not ok:
        ok = _run_pack_pro(context, ws, margin_px=margin_px, lock_pinned=_bool_attr(ws, 'unified_pack_lock_pinned', True), rotation_step=_str_attr(ws, 'unified_pack_rotation_step', '15'))
    _fit_selected_uvs_to_aspect(context, ws)
    return bool(ok)


def _run_low_distortion_pack(context, ws) -> bool:
    """Low-distortion finishing pack."""
    try:
        _call_op('uv.minimize_stretch', iterations=96, blend=0.75)
    except Exception:
        pass
    _selected_uv_island_density_rescale(context, ws, strength=0.88)
    ok = _run_density_priority(context, ws)
    if not ok:
        ok = _run_chart_distribution_pack(context, ws, bake_safe=False, existing_chart=False)
    return bool(ok)


def _run_selected_scope_fast_pack(context, ws) -> bool:
    """Fast visible/selected-scope pack: strict selected UV faces only."""
    ok = _run_native_pack(context, ws, force_mode='CONVEX')
    if not ok:
        ok = _run_pack_pro(context, ws, rotation_step='90')
    return bool(ok)

def _run_native_pack_menu_action(context, action: str) -> bool:
    """Run former Pack/UDIM/Atlas implementations without re-entering this unified operator."""
    action = str(action or 'PACK').upper()
    try:
        from . import native_unified_tools as _native_tools
        if action in {'PACK', 'PACK_PRECISION'}:
            fn = getattr(_native_tools, '_pack', None)
            if callable(fn):
                return bool(fn(context, udim=False))
        if action == 'PACK_UDIM':
            fn = getattr(_native_tools, '_pack', None)
            if callable(fn):
                return bool(fn(context, udim=True))
        if action == 'ATLAS_CELL':
            fn = getattr(_native_tools, '_atlas_cell', None)
            if callable(fn):
                return bool(fn(context) > 0)
        if action == 'TRIM_STRIP':
            fn = getattr(_native_tools, '_trim_strip', None)
            if callable(fn):
                return bool(fn(context) > 0)
    except Exception:
        pass
    return False

def _apply_target_tile(context, ws, mode: str) -> None:
    target = _str_attr(ws, 'unified_pack_target_tile', 'ZERO').upper()
    if mode == 'UDIM_CURSOR' or target == 'CURSOR':
        u, v = _cursor_tile(context)
        _translate_selected_uvs_to_tile(context, u, v)
    elif target == 'EXPLICIT':
        _translate_selected_uvs_to_tile(context, _int_attr(ws, 'unified_pack_tile_u', 0), _int_attr(ws, 'unified_pack_tile_v', 0))
    elif target == 'ZERO':
        _translate_selected_uvs_to_tile(context, 0, 0)


_PACK_MODE_ITEMS = (
    ('PACK_STANDARD', 'パック', '選択UV面だけを現在のタイルへ整理する基本パックです。旧「アトラス」「標準パック: 正確形状/凸包/矩形」「選択面スコープパック」と同じ結果になる経路は、この1項目へ集約しています。'),
    ('SMART_DENSE', '高密度パック', 'Smart UV Pack Pro系の決定論的パックです。通常より高密度な配置を狙う場合に使います。'),
    ('FAST_NO_ROTATE', '方向維持パック', 'アイランドの向きを維持し、回転させずに選択UV面だけをパックします。'),
    ('DENSITY_PRIORITY', '密度優先パック', 'テクセル密度を揃えてから選択範囲をパックします。'),
    ('MESH_AREA_SCALE_PACK', '3D面積基準パック', '元の3Dメッシュ面積を基準に、各アイランドの形状を崩さず再スケールしてから選択範囲をパックします。'),
    ('GROUP_SIMILAR', '類似島グループパック', '面積・比率が近い島をグループ化してパックします。'),
    ('GROUP_MATERIAL', 'マテリアル別パック', 'マテリアル境界をグループとして扱い、グループごとに整理してパックします。'),
    ('GROUP_IDENTICAL', '同一島スタック+パック', 'ほぼ同一形状の島をスタックしながらパックします。'),
    ('UDIM_STANDARD', 'UDIMタイルパック', '配置タイル設定（ゼロ/カーソル/明示指定）に従い、選択UV面だけをUDIMタイルへパックします。'),
    ('UDIM_KEEP_TILES', 'UDIM維持パック', '現在所属しているUDIMタイルを維持して各タイル内でパックします。'),
    ('UDIM_AUTO_TILES', 'UDIM自動拡張パック', '必要に応じてUDIMタイルを増やしながら選択島をパックします。'),
    ('CHART_DISTRIBUTION', '高密度チャート分布パック', 'チャート分布、幅高さ、パディングを考慮し、選択島を密度正規化してから正確形状でパックします。'),
    ('BAKE_SAFE_CHART', 'ベイク安全チャートパック', 'ベイクパディングの2倍以上を意識した安全余白で、重なりやにじみを避けるパックです。'),
    ('EXISTING_CHART_REPACK', '既存チャート再パック', '既存チャート境界を保ち、ゼロ面積や崩れた島を避けながら再パックします。'),
    ('LOW_DISTORTION_PACK', '低歪み補正パック', '最小ストレッチと密度補正を行い、伸びを抑えてからパックします。'),
    ('LIGHTMAP', 'ライトマップパック', 'Blender標準Lightmap PackをSmart UVの選択面スコープで実行します。'),
    ('HOTSPOT_GRID', 'ホットスポットセル配置', 'グリッドセルへ選択島を自動配置します。トリム/ホットスポット用途です。'),
    ('TRIM_STRIP', 'トリム帯配置', '帯状・トリムシート向けに選択島を整理配置します。'),
)


_PACK_MODE_ALIASES = {
    # 旧UIで別項目だったが現実装では同じAABB安全パックに到達していた項目。
    'ATLAS_STANDARD': 'PACK_STANDARD',
    'NATIVE_CONCAVE': 'PACK_STANDARD',
    'NATIVE_CONVEX': 'PACK_STANDARD',
    'NATIVE_AABB': 'PACK_STANDARD',
    'SELECTED_SCOPE_PACK': 'PACK_STANDARD',
    'PIN_LOCKED': 'PACK_STANDARD',
    'RANDOM_SEARCH': 'PACK_STANDARD',
    # 旧パック/アトラス/トリムメニューの互換ID。
    'PACK': 'PACK_STANDARD',
    'PACK_PRECISION': 'SMART_DENSE',
    'PACK_UDIM': 'UDIM_STANDARD',
    'UDIM': 'UDIM_STANDARD',
    'UDIM_CURSOR': 'UDIM_STANDARD',
    'ATLAS': 'HOTSPOT_GRID',
    'ATLAS_CELL': 'HOTSPOT_GRID',
    'HOTSPOT_FIT': 'HOTSPOT_GRID',
}


def _canonical_pack_mode(mode: str | None) -> str:
    value = str(mode or 'PACK_STANDARD').upper()
    return _PACK_MODE_ALIASES.get(value, value)

def _mode_items(self=None, context=None):
    return _PACK_MODE_ITEMS


class SMARTUVSUITE_OT_unified_auto_pack(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.unified_auto_pack'
    bl_label = '自動パッキング'
    bl_description = 'Smart UVの全自動パッキング方式を1つの選択式ツールとして実行します。対象はUVエディターで完全に面選択されている面だけです。'
    bl_options = {'UNDO'}

    mode: bpy.props.EnumProperty(
        name='パッキング方法',
        description='一時的に実行する自動パッキング方法です。空の場合はパネルの「自動パッキング方法」を使います。',
        items=_PACK_MODE_ITEMS,
        default='PACK_STANDARD',
        options={'SKIP_SAVE'},
    )
    use_panel_settings: bpy.props.BoolProperty(name='パネル設定を使用', default=True, options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        obj = _active_mesh_obj(context)
        return obj is not None

    def execute(self, context):
        ws = _ws(context)
        if ws is None:
            self.report({'WARNING'}, _tr(context, 'Smart UV workspace settings were not found.', 'Smart UVのワークスペース設定が見つかりません。'))
            return {'CANCELLED'}
        mode = _canonical_pack_mode(_str_attr(ws, 'unified_auto_pack_mode', 'PACK_STANDARD') if self.use_panel_settings else self.mode)
        obj = _active_mesh_obj(context)
        if obj is None:
            self.report({'WARNING'}, _tr(context, 'No editable mesh was found.', '編集可能なメッシュがありません。'))
            return {'CANCELLED'}
        global _IN_UNIFIED_AUTO_PACK
        if _IN_UNIFIED_AUTO_PACK > 0:
            return {'CANCELLED'}
        _IN_UNIFIED_AUTO_PACK += 1
        try:
            from .uv_face_scope import StrictUVFaceScope
        except Exception:
            StrictUVFaceScope = None

        def _do() -> bool:
            if _bool_attr(ws, 'unified_pack_use_seed', False) or mode == 'RANDOM_SEARCH':
                _randomize_selected_islands(context, _int_attr(ws, 'unified_pack_seed', 0), rotate=_bool_attr(ws, 'unified_pack_rotate', True))
            if _suv41_selected_records_have_overlap(context):
                if mode == 'MESH_AREA_SCALE_PACK':
                    _selected_uv_island_density_rescale(context, ws, strength=1.0)
                elif mode in {'CHART_DISTRIBUTION', 'BAKE_SAFE_CHART', 'EXISTING_CHART_REPACK', 'LOW_DISTORTION_PACK'}:
                    _selected_uv_island_density_rescale(context, ws, strength=0.72)
                target_tile = (_int_attr(ws, 'unified_pack_tile_u', 0), _int_attr(ws, 'unified_pack_tile_v', 0)) if mode == 'UDIM_STANDARD' else None
                ok = _run_bmesh_aabb_pack(context, ws, target_tile=target_tile, force_no_rotate=(mode == 'FAST_NO_ROTATE'))
                if ok:
                    _apply_target_tile(context, ws, mode)
                return bool(ok)
            if mode == 'PACK_STANDARD':
                ok = _run_bmesh_aabb_pack(context, ws)
            elif mode == 'UDIM_STANDARD':
                ok = _run_bmesh_aabb_pack(context, ws, target_tile=(_int_attr(ws, 'unified_pack_tile_u', 0), _int_attr(ws, 'unified_pack_tile_v', 0)))
            elif mode == 'ATLAS_STANDARD':
                ok = _run_bmesh_aabb_pack(context, ws)
            elif mode == 'NATIVE_CONCAVE':
                ok = _run_bmesh_aabb_pack(context, ws) or _run_native_pack(context, ws, force_mode='CONCAVE')
            elif mode == 'NATIVE_CONVEX':
                ok = _run_bmesh_aabb_pack(context, ws) or _run_native_pack(context, ws, force_mode='CONVEX')
            elif mode == 'NATIVE_AABB':
                ok = _run_bmesh_aabb_pack(context, ws) or _run_native_pack(context, ws, force_mode='AABB')
            elif mode == 'FAST_NO_ROTATE':
                ok = _run_bmesh_aabb_pack(context, ws, force_no_rotate=True) or _run_native_pack(context, ws, force_no_rotate=True)
            elif mode == 'RANDOM_SEARCH':
                ok = _run_bmesh_aabb_pack(context, ws) or _run_native_pack(context, ws)
            elif mode == 'PIN_LOCKED':
                ok = _run_bmesh_aabb_pack(context, ws) or _run_native_pack(context, ws, force_pin=True)
            elif mode == 'DENSITY_PRIORITY':
                ok = _run_density_priority(context, ws)
            elif mode == 'MESH_AREA_SCALE_PACK':
                _selected_uv_island_density_rescale(context, ws, strength=1.0)
                ok = _run_bmesh_aabb_pack(context, ws) or _run_native_pack(context, ws)
            elif mode == 'GROUP_SIMILAR':
                ok = _run_pack_pro(context, ws, group_mode='SIMILAR', group_layout=_str_attr(ws, 'pack_group_layout', 'SINGLE_TILE'))
            elif mode == 'GROUP_MATERIAL':
                ok = _run_pack_pro(context, ws, group_mode='MATERIAL', group_layout=_str_attr(ws, 'pack_group_layout', 'SINGLE_TILE'))
            elif mode == 'GROUP_IDENTICAL':
                ok = _run_pack_pro(context, ws, group_mode='IDENTICAL', group_layout=_str_attr(ws, 'pack_group_layout', 'SINGLE_TILE'), stack_identical_groups=True)
            elif mode == 'UDIM_CURSOR':
                ok = _run_native_pack(context, ws) or _run_pack_pro(context, ws)
            elif mode == 'UDIM_KEEP_TILES':
                ok = _run_pack_pro(context, ws, udim_mode='KEEP_TILES')
            elif mode == 'UDIM_AUTO_TILES':
                ok = _run_pack_pro(context, ws, udim_mode='AUTO_TILES')
            elif mode == 'CHART_DISTRIBUTION':
                ok = _run_chart_distribution_pack(context, ws, bake_safe=False, existing_chart=False)
            elif mode == 'BAKE_SAFE_CHART':
                ok = _run_chart_distribution_pack(context, ws, bake_safe=True, existing_chart=False)
            elif mode == 'EXISTING_CHART_REPACK':
                ok = _run_chart_distribution_pack(context, ws, bake_safe=False, existing_chart=True)
            elif mode == 'LOW_DISTORTION_PACK':
                ok = _run_low_distortion_pack(context, ws)
            elif mode == 'SELECTED_SCOPE_PACK':
                ok = _run_selected_scope_fast_pack(context, ws)
            elif mode == 'LIGHTMAP':
                ok = _run_lightmap(context, ws)
            elif mode == 'HOTSPOT_GRID':
                ok = _run_hotspot(context, ws)
            elif mode == 'TRIM_STRIP':
                ok = _run_trim(context, ws)
            else:
                ok = _run_pack_pro(context, ws)
            if ok:
                _apply_target_tile(context, ws, mode)
            return bool(ok)

        try:
            if StrictUVFaceScope is not None:
                with StrictUVFaceScope(context, report=self.report) as scope:
                    if not getattr(scope, 'valid', False):
                        return {'CANCELLED'}
                    ok = _do()
            else:
                ok = _do()
            if not ok:
                self.report({'WARNING'}, _tr(context, f'Automatic packing failed: {mode}', f'自動パッキングが失敗しました: {mode}'))
                return {'CANCELLED'}
            self.report({'INFO'}, _tr(context, f'Automatic packing finished: {mode}', f'自動パッキング完了: {mode}'))
            return {'FINISHED'}
        finally:
            _IN_UNIFIED_AUTO_PACK = max(0, _IN_UNIFIED_AUTO_PACK - 1)


def run_auto_pack(context, mode: str | None = None, *, use_panel_settings: bool = True) -> bool:
    """Run the single Smart UV automatic-packing route from other modules."""
    if _IN_UNIFIED_AUTO_PACK > 0:
        return False
    try:
        op = getattr(getattr(bpy.ops, 'smart_uv_suite', None), 'unified_auto_pack', None)
        if op is None:
            return False
        kwargs = {'use_panel_settings': bool(use_panel_settings)}
        if mode:
            kwargs['mode'] = _canonical_pack_mode(mode)
            kwargs['use_panel_settings'] = False
        result = op('EXEC_DEFAULT', **kwargs)
        return _ok(result)
    except Exception:
        return False


def run_auto_pack_for_action(context, action: str) -> bool:
    """Map old Pack / UDIM / Atlas / Trim actions to unified auto-packing modes."""
    action_u = str(action or 'PACK').upper()
    mapping = {
        'PACK': 'PACK_STANDARD',
        'PACK_PRECISION': 'SMART_DENSE',
        'PACK_UDIM': 'UDIM_STANDARD',
        'UDIM': 'UDIM_STANDARD',
        'UDIM_CURSOR': 'UDIM_STANDARD',
        'ATLAS_CELL': 'HOTSPOT_GRID',
        'ATLAS': 'HOTSPOT_GRID',
        'TRIM_STRIP': 'TRIM_STRIP',
        'HOTSPOT_FIT': 'HOTSPOT_GRID',
    }
    return run_auto_pack(context, _canonical_pack_mode(mapping.get(action_u, action_u)), use_panel_settings=False)


def register() -> None:
    unregister()
    for cls in (SMARTUVSUITE_OT_unified_auto_pack,):
        try:
            _suv_resource.register_class(cls)
            _REGISTERED.append(cls)
        except Exception:
            pass


def unregister() -> None:
    while _REGISTERED:
        cls = _REGISTERED.pop()
        try:
            _suv_resource.unregister_class(cls)
        except Exception:
            pass

# -----------------------------------------------------------------------------
# Smart UV Suite 1.6.43 multi-object packing support
# -----------------------------------------------------------------------------
# Pack all selected edit-mode mesh objects as one UV Editor domain.  This layer
# does not alter the external Smart_Tools_Manager and does not register keymaps.

_MULTI_ORIGINAL_ACTIVE_MESH_OBJ = _active_mesh_obj
_MULTI_ORIGINAL_BMESH_AABB_PACK = _run_bmesh_aabb_pack
_MULTI_ORIGINAL_EXECUTE = getattr(SMARTUVSUITE_OT_unified_auto_pack, 'execute', None)
_MULTI_PATCHED = False


def _multi_unique(seq):
    out = []
    seen = set()
    for obj in seq or []:
        try:
            if obj is None or getattr(obj, 'type', None) != 'MESH':
                continue
            key = getattr(obj, 'name_full', None) or getattr(obj, 'name', None) or str(id(obj))
            if key in seen:
                continue
            seen.add(key)
            out.append(obj)
        except Exception:
            pass
    return out


def _multi_edit_mesh_objects(context):
    objs = []
    try:
        objs.extend(list(getattr(context, 'objects_in_mode_unique_data', None) or []))
    except Exception:
        pass
    try:
        if not objs:
            objs.extend(list(getattr(context, 'objects_in_mode', None) or []))
    except Exception:
        pass
    objs = [o for o in _multi_unique(objs) if str(getattr(o, 'mode', 'OBJECT') or 'OBJECT') == 'EDIT']
    if not objs:
        try:
            objs = [o for o in getattr(context, 'selected_objects', []) or [] if getattr(o, 'type', None) == 'MESH']
        except Exception:
            objs = []
    active = None
    try:
        active = getattr(context, 'edit_object', None) or getattr(context, 'active_object', None) or getattr(context.view_layer.objects, 'active', None)
    except Exception:
        active = None
    result = []
    if active is not None and active in objs:
        result.append(active)
    for obj in objs:
        if obj not in result:
            result.append(obj)
    return _multi_unique(result)


def _multi_restore_mesh_selection(context, snapshots):
    for obj, snap in list(snapshots.items()):
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            vsel, esel, fsel = snap
            try:
                bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
            except Exception:
                pass
            for i, flag in enumerate(vsel):
                if i < len(bm.verts):
                    try: bm.verts[i].select_set(bool(flag))
                    except Exception: bm.verts[i].select = bool(flag)
            for i, flag in enumerate(esel):
                if i < len(bm.edges):
                    try: bm.edges[i].select_set(bool(flag))
                    except Exception: bm.edges[i].select = bool(flag)
            for i, flag in enumerate(fsel):
                if i < len(bm.faces):
                    try: bm.faces[i].select_set(bool(flag))
                    except Exception: bm.faces[i].select = bool(flag)
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        except Exception:
            pass


def _multi_selection_snapshot(obj):
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        try:
            bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
            bm.verts.index_update(); bm.edges.index_update(); bm.faces.index_update()
        except Exception:
            pass
        return ([bool(v.select) for v in bm.verts], [bool(e.select) for e in bm.edges], [bool(f.select) for f in bm.faces])
    except Exception:
        return ([], [], [])



def _multi_strict_face_indices_from_object_attrs(obj) -> set[int]:
    try:
        me = getattr(obj, 'data', None)
        attrs = getattr(me, 'attributes', None)
        if attrs is None:
            return set()
        face_attr = attrs.get('.uv_select_face')
        vert_attr = attrs.get('.uv_select_vert')
        if face_attr is None or vert_attr is None:
            return set()
        face_flags = [bool(getattr(x, 'value', False)) for x in getattr(face_attr, 'data', [])]
        vert_flags = [bool(getattr(x, 'value', False)) for x in getattr(vert_attr, 'data', [])]
        if not any(face_flags):
            return set()
        out = set()
        for poly in getattr(me, 'polygons', []) or []:
            try:
                fi = int(poly.index)
                if fi < 0 or fi >= len(face_flags) or not face_flags[fi]:
                    continue
                ok = True
                for li in list(getattr(poly, 'loop_indices', []) or []):
                    if int(li) < 0 or int(li) >= len(vert_flags) or not bool(vert_flags[int(li)]):
                        ok = False
                        break
                if ok:
                    out.add(fi)
            except Exception:
                pass
        return out
    except Exception:
        return set()

def _multi_run_bmesh_aabb_pack(context, ws, *, target_tile: tuple[int, int] | None = None, force_no_rotate: bool = False, fit_to_bounds: bool = True) -> bool:
    objs = _multi_edit_mesh_objects(context)
    if len(objs) <= 1:
        return _MULTI_ORIGINAL_BMESH_AABB_PACK(context, ws, target_tile=target_tile, force_no_rotate=force_no_rotate, fit_to_bounds=fit_to_bounds)
    old_active = None
    try:
        old_active = context.view_layer.objects.active
    except Exception:
        old_active = None
    snapshots = {obj: _multi_selection_snapshot(obj) for obj in objs}
    attr_selected_faces = {}
    mode_before_attr = None
    try:
        mode_before_attr = str(getattr(old_active, 'mode', 'OBJECT') or 'OBJECT') if old_active is not None else None
        if mode_before_attr == 'EDIT':
            bpy.ops.object.mode_set(mode='OBJECT')
        for _obj in objs:
            attr_selected_faces[_obj] = _multi_strict_face_indices_from_object_attrs(_obj)
    except Exception:
        attr_selected_faces = {}
    finally:
        if mode_before_attr == 'EDIT':
            try:
                if old_active is not None:
                    context.view_layer.objects.active = old_active
            except Exception:
                pass
            try:
                bpy.ops.object.mode_set(mode='EDIT')
            except Exception:
                pass
    try:
        tile_u, tile_v = target_tile if target_tile is not None else (_int_attr(ws, 'unified_pack_tile_u', 0), _int_attr(ws, 'unified_pack_tile_v', 0))
        tex = max(1, _int_attr(ws, 'canvas_size', 2048, 1, 65536))
        margin_uv = _float_attr(ws, 'unified_pack_margin', 0.001, 0.0, 0.5)
        margin_px = _int_attr(ws, 'unified_pack_margin_px', _int_attr(ws, 'fit_padding_px', 8, 0, 512), 0, 4096)
        margin = min(max(max(margin_uv, float(margin_px) / float(tex)), 0.0), 0.45)
        usable_min = Vector((int(tile_u) + margin, int(tile_v) + margin))
        usable_max = Vector((int(tile_u) + 1.0 - margin, int(tile_v) + 1.0 - margin))
        usable_w = max(1.0e-9, usable_max.x - usable_min.x)
        usable_h = max(1.0e-9, usable_max.y - usable_min.y)
        island_data = []
        for obj in objs:
            try:
                context.view_layer.objects.active = obj
            except Exception:
                pass
            try:
                if str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT') != 'EDIT':
                    bpy.ops.object.mode_set(mode='EDIT')
            except Exception:
                pass
            try:
                bm = bmesh.from_edit_mesh(obj.data)
                uv_layer = bm.loops.layers.uv.verify()
                selected_indices = set(attr_selected_faces.get(obj) or set())
                if selected_indices:
                    try:
                        bm.faces.ensure_lookup_table(); bm.faces.index_update()
                    except Exception:
                        pass
                    faces = [f for f in bm.faces if int(getattr(f, 'index', -1)) in selected_indices]
                else:
                    faces = _strict_selected_faces_from_uv_attrs(obj, bm) or _selected_faces(bm)
                if not faces:
                    continue
                try:
                    from . import core as _core
                    islands = list(_core.build_islands(bm, uv_layer, faces_subset=faces))
                except Exception:
                    islands = []
                if not islands:
                    class _FaceIsland: pass
                    islands = []
                    for face in faces:
                        isl = _FaceIsland(); isl.faces = [face]; islands.append(isl)
                for isl in islands:
                    loops = _selected_island_loop_keys(isl, uv_layer)
                    bbox = _island_bbox_from_loops(loops, uv_layer)
                    if bbox is None:
                        continue
                    mn, mx = bbox
                    w = max(float((mx - mn).x), 1.0e-8)
                    h = max(float((mx - mn).y), 1.0e-8)
                    loop_keys = []
                    seen_loop_keys = set()
                    for loop in loops:
                        try:
                            face = loop.face
                        except Exception:
                            face = None
                        try:
                            face_i = int(getattr(face, 'index', -1))
                            pos = list(face.loops).index(loop)
                            key = (obj, face_i, int(pos))
                            if key in seen_loop_keys:
                                continue
                            seen_loop_keys.add(key)
                            uvv = Vector(loop[uv_layer].uv)
                            loop_keys.append((obj, face_i, int(pos), (float(uvv.x), float(uvv.y))))
                        except Exception:
                            pass
                    if not loop_keys:
                        continue
                    island_data.append({'obj': obj, 'loop_keys': loop_keys, 'min': mn, 'max': mx, 'w': w, 'h': h, 'polys': _suv41_island_polygons(isl, uv_layer)})
            except Exception:
                pass
        island_data = _suv41_merge_overlapping_pack_records(island_data)
        if not island_data:
            return False
        total_area = sum(max(d['w'], 1e-8) * max(d['h'], 1e-8) for d in island_data)
        base_scale = math.sqrt((usable_w * usable_h * 0.82) / total_area) if total_area > 1.0e-12 else 1.0
        base_scale = max(1.0e-8, min(base_scale, 1000000.0))
        rects = [{'index': i, 'w': d['w'] * base_scale, 'h': d['h'] * base_scale} for i, d in enumerate(island_data)]
        placements = _pack_shelf_rects(rects, usable_w, usable_h, margin)
        placement_map = {idx: (x, y, sc) for idx, x, y, sc in placements}
        changed_objects = set()
        bm_cache = {}
        for idx, data in enumerate(island_data):
            px, py, shelf_scale = placement_map.get(idx, (margin, margin, 1.0))
            scale = base_scale * shelf_scale
            dst_min = usable_min + Vector((px, py))
            src_min = data['min']
            for key_item in data.get('loop_keys', []) or []:
                try:
                    key_obj, face_i, pos, uv_tuple = key_item
                except Exception:
                    continue
                obj = key_obj
                try:
                    cache = bm_cache.get(obj)
                    if cache is None:
                        bm_apply = bmesh.from_edit_mesh(obj.data)
                        uv_apply = bm_apply.loops.layers.uv.verify()
                        try:
                            bm_apply.faces.ensure_lookup_table(); bm_apply.faces.index_update()
                        except Exception:
                            pass
                        face_map = {int(getattr(f, 'index', -1)): f for f in bm_apply.faces}
                        cache = (bm_apply, uv_apply, face_map)
                        bm_cache[obj] = cache
                    bm_apply, uv_apply, face_map = cache
                    face = face_map.get(int(face_i))
                    if face is None:
                        continue
                    loops = list(face.loops)
                    if int(pos) < 0 or int(pos) >= len(loops):
                        continue
                    uv = Vector((float(uv_tuple[0]), float(uv_tuple[1])))
                    loops[int(pos)][uv_apply].uv = dst_min + (uv - src_min) * scale
                    changed_objects.add(obj)
                except Exception:
                    pass
        for obj in changed_objects:
            try:
                bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
            except Exception:
                pass
        return True
    finally:
        _multi_restore_mesh_selection(context, snapshots)
        try:
            if old_active is not None:
                context.view_layer.objects.active = old_active
        except Exception:
            pass


def _multi_execute_unified_auto_pack(self, context):
    objs = _multi_edit_mesh_objects(context)
    if len(objs) <= 1 or not callable(_MULTI_ORIGINAL_EXECUTE):
        return _MULTI_ORIGINAL_EXECUTE(self, context) if callable(_MULTI_ORIGINAL_EXECUTE) else {'CANCELLED'}
    ws = _ws(context)
    if ws is None:
        self.report({'WARNING'}, _tr(context, 'Smart UV workspace settings were not found.', 'Smart UVのワークスペース設定が見つかりません。'))
        return {'CANCELLED'}
    mode = _canonical_pack_mode(_str_attr(ws, 'unified_auto_pack_mode', 'PACK_STANDARD') if self.use_panel_settings else self.mode)
    # Multi-object path keeps one combined packing domain for modes whose result
    # is a deterministic placement.  Modes that rely on external Pack Pro groups
    # still use the combined AABB pack as the safest shared selected-face result.
    if mode in {'UDIM_STANDARD'}:
        ok = _multi_run_bmesh_aabb_pack(context, ws, target_tile=(_int_attr(ws, 'unified_pack_tile_u', 0), _int_attr(ws, 'unified_pack_tile_v', 0)))
    else:
        ok = _multi_run_bmesh_aabb_pack(context, ws)
    if not ok:
        self.report({'WARNING'}, _tr(context, f'Automatic packing failed: {mode}', f'自動パッキングが失敗しました: {mode}'))
        return {'CANCELLED'}
    self.report({'INFO'}, _tr(context, f'Automatic packing finished: {mode}', f'自動パッキング完了: {mode}'))
    return {'FINISHED'}


def patch_multi_object_support() -> None:
    global _MULTI_PATCHED, _run_bmesh_aabb_pack
    if _MULTI_PATCHED:
        return
    _MULTI_PATCHED = True
    try:
        _run_bmesh_aabb_pack = _multi_run_bmesh_aabb_pack
    except Exception:
        pass
    try:
        SMARTUVSUITE_OT_unified_auto_pack.execute = _multi_execute_unified_auto_pack
    except Exception:
        pass


def restore_multi_object_support() -> None:
    global _MULTI_PATCHED, _run_bmesh_aabb_pack
    if not _MULTI_PATCHED:
        return
    _MULTI_PATCHED = False
    try:
        _run_bmesh_aabb_pack = _MULTI_ORIGINAL_BMESH_AABB_PACK
    except Exception:
        pass
    try:
        if callable(_MULTI_ORIGINAL_EXECUTE):
            SMARTUVSUITE_OT_unified_auto_pack.execute = _MULTI_ORIGINAL_EXECUTE
    except Exception:
        pass
