from . import core as _prev
_IGNORE_KEYS = {'__name__','__package__','__loader__','__spec__','__file__','__cached__','__builtins__'}
globals().update({k: v for k, v in _prev.__dict__.items() if k not in _IGNORE_KEYS})

# ============================================================
# Operators - Legacy tools
# ============================================================

class SUV_OT_smart_seams(bpy.types.Operator):
    bl_idname = "uv.suv_smart_seams"
    bl_label = 'Smart Seams'
    bl_description = "Create seams automatically from the suite's quick seam rules so you can unwrap faster with fewer manual cuts. / ツールセットのクイックシーム規則から自動でシームを作成し、手作業の切れ目を減らして素早く展開できるようにします。"
    bl_options = {'UNDO'}

    angle_threshold: bpy.props.FloatProperty(
        name="Angle Threshold",
        default=math.radians(60.0),
        min=0.0,
        max=math.pi,
        subtype='ANGLE',
    )

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        with _TempMode(context, obj, 'EDIT'):
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.verify()
            sel_faces, _sel_loops, _active_face, _src = _selection_from_context(context, obj, bm, uv_layer)
            seam_count = _suv_mark_smart_seams(bm, self.angle_threshold, faces_subset=sel_faces or None)
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        self.report({'INFO'}, tr(context, "msg.seams_marked", n=seam_count))
        return {'FINISHED'}

class SUV_OT_smart_tube(bpy.types.Operator):
    bl_idname = "uv.suv_smart_tube"
    bl_label = 'Smart Tube'
    bl_description = "Unwrap cylindrical or tube-like selections with a streamlined helper aimed at pipes, cables and similar shapes. / 円筒やチューブ状の選択を、パイプやケーブル向けの簡易補助で展開します。"
    bl_options = {'UNDO'}

    def execute(self, context):
        ok, err = _run_uv_op(context, bpy.ops.uv.cylinder_project, direction='VIEW_ON_EQUATOR')
        if ok:
            self.report({'INFO'}, tr(context, "msg.tube_done"))
            return {'FINISHED'}
        self.report({'WARNING'}, tr(context, "msg.op_failed", e=err))
        return {'CANCELLED'}

class SUV_OT_smart_relax(bpy.types.Operator):
    bl_idname = "uv.suv_smart_relax"
    bl_label = 'Smart Relax'
    bl_description = "Relax the current UV selection to reduce visible stretching while keeping the overall shell layout stable. / 現在のUV選択をリラックスして、全体レイアウトを大きく崩さずに伸び歪みを減らします。"
    bl_options = {'UNDO'}

    iterations: bpy.props.IntProperty(name="Iterations", default=100, min=1, max=1000)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        with _TempMode(context, obj, 'EDIT'):
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.verify()
            sel_faces, _sel_loops, _active_face, _src = _selection_from_context(context, obj, bm, uv_layer)
            faces = sel_faces or [f for f in bm.faces if f.select]
            if not faces:
                self.report({'WARNING'}, tr(context, "msg.no_selection"))
                return {'CANCELLED'}
            ok, err = _suv_relax_selection_preserve(context, obj, faces, iterations=self.iterations, preserve_area=True, preserve_position=True)
        if ok:
            self.report({'INFO'}, tr(context, "msg.relax_done"))
            return {'FINISHED'}
        self.report({'WARNING'}, tr(context, "msg.op_failed", e=err))
        return {'CANCELLED'}

class SUV_OT_smart_edge_straighten(bpy.types.Operator):
    bl_idname = "uv.suv_smart_edge_straighten"
    bl_label = 'Smart Edge Straighten'
    bl_description = "Straighten selected UV edges or chains for cleaner trims, strips and hard-surface borders. / 選択したUVエッジやチェーンを直線化し、トリムやハードサーフェス境界を整えます。"
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        ok_native, _native_err = _suv_run_align_native(context, axis_mode='ALIGN_S')
        if ok_native:
            self.report({'INFO'}, tr(context, "msg.straighten_done"))
            return {'FINISHED'}
        with _TempMode(context, obj, 'EDIT'):
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.verify()
            sel_faces, sel_loops, _active_face, _src = _selection_from_context(context, obj, bm, uv_layer)
            if not sel_faces and not sel_loops:
                self.report({'WARNING'}, tr(context, "msg.no_selection"))
                return {'CANCELLED'}
            target_loops = list(sel_loops) if sel_loops else [l for f in sel_faces for l in f.loops]
            unique_loops = []
            seen = set()
            for l in target_loops:
                key = int(getattr(l, 'index', id(l)))
                if key in seen:
                    continue
                seen.add(key)
                unique_loops.append(l)
            if len(unique_loops) < 2:
                self.report({'WARNING'}, tr(context, "msg.no_selection"))
                return {'CANCELLED'}
            islands = build_islands(bm, uv_layer, faces_subset=sel_faces or list(bm.faces))
            island_map = {}
            for isl in islands:
                loop_ids = {int(getattr(l, 'index', id(l))) for l in getattr(isl, 'loops', []) or []}
                island_map[isl.id] = [l for l in unique_loops if int(getattr(l, 'index', id(l))) in loop_ids]
            moved_any = False
            for loops in island_map.values():
                if len(loops) < 2:
                    continue
                pts = []
                pseen = set()
                for l in loops:
                    uv = Vector(l[uv_layer].uv)
                    key = (round(float(uv.x), 6), round(float(uv.y), 6))
                    if key in pseen:
                        continue
                    pseen.add(key)
                    pts.append(uv)
                if len(pts) < 2:
                    continue
                origin = Vector((sum(p.x for p in pts) / len(pts), sum(p.y for p in pts) / len(pts)))
                axis = None
                best_d = -1.0
                for i in range(len(pts)):
                    for j in range(i + 1, len(pts)):
                        d = (pts[j] - pts[i]).length_squared
                        if d > best_d:
                            best_d = d
                            axis = (pts[j] - pts[i]) if d > 1.0e-16 else axis
                if axis is None or axis.length <= 1.0e-12:
                    _centroid, axis = _pca_axis_2d(pts)
                if axis is None or axis.length <= 1.0e-12:
                    continue
                axis = axis.normalized()
                for l in loops:
                    p = Vector(l[uv_layer].uv) - origin
                    t = p.dot(axis)
                    l[uv_layer].uv = origin + axis * t
                    moved_any = True
            if not moved_any:
                self.report({'WARNING'}, tr(context, "msg.op_failed", e="Line solve failed"))
                return {'CANCELLED'}
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        self.report({'INFO'}, tr(context, "msg.straighten_done"))
        return {'FINISHED'}

class SUV_OT_smart_rectify(bpy.types.Operator):
    bl_idname = "uv.suv_smart_rectify"
    bl_label = 'Smart Rectify'
    bl_description = "Rectify selected UV shells into cleaner rectangular shapes for hard-surface and atlas workflows. / 選択したUVシェルをより矩形に整え、ハードサーフェスやアトラス作業に向けて整理します。"
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}

        with _TempMode(context, obj, 'EDIT'):
            bm = bmesh.from_edit_mesh(obj.data)
            active_face = getattr(bm.faces, "active", None)
            sel_faces = [f for f in bm.faces if f.select]
            if not sel_faces:
                self.report({'WARNING'}, tr(context, "msg.no_selection"))
                return {'CANCELLED'}
            quad = None
            if active_face and active_face in sel_faces and len(active_face.verts) == 4:
                quad = active_face
            else:
                for f in sel_faces:
                    if len(f.verts) == 4:
                        quad = f
                        break
            if quad:
                try:
                    bm.faces.active = quad
                except Exception:
                    pass
                bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)

        ok, err = _run_uv_op(context, bpy.ops.uv.follow_active_quads, mode='LENGTH_AVERAGE')
        if ok:
            self.report({'INFO'}, tr(context, "msg.rectify_done"))
            return {'FINISHED'}
        try:
            ok2, err2 = _run_uv_op(context, bpy.ops.uv.suv_hs_rectify_fit, scope='SELECTED')
        except Exception:
            ok2, err2 = False, err
        if ok2:
            self.report({'INFO'}, tr(context, "msg.rectify_done"))
            return {'FINISHED'}
        self.report({'WARNING'}, tr(context, "msg.need_active_quad"))
        return {'CANCELLED'}

class SUV_OT_smart_3d_transfer(bpy.types.Operator):
    bl_idname = "uv.suv_smart_3d_transfer"
    bl_label = '3D Smart Transfer'
    bl_description = "Transfer UV orientation or layout hints from the 3D model state to the current UV selection. / 3Dモデル側の向きや状態を手掛かりに、現在のUV選択へ配置のヒントを転送します。"
    bl_options = {'UNDO'}

    def execute(self, context):
        active = _active_mesh_obj(context)
        sel = _selected_mesh_objects(context)
        if not active or len(sel) < 2:
            self.report({'WARNING'}, tr(context, "msg.no_selection"))
            return {'CANCELLED'}
        prev_mode = getattr(active, 'mode', 'OBJECT')
        restore_mode = bool(prev_mode)
        try:
            ok_mode, mode_err = _suv_safe_mode_set(context, active, 'OBJECT', source='3D Smart Transfer preflight')
            if not ok_mode:
                self.report({'WARNING'}, tr(context, "msg.op_failed", e=mode_err or 'Object mode switch failed'))
                return {'CANCELLED'}
            bpy.ops.object.data_transfer(data_type='UV', use_create=True)
            self.report({'INFO'}, tr(context, "msg.transfer_done"))
            return {'FINISHED'}
        except Exception as e:
            self.report({'WARNING'}, tr(context, "msg.op_failed", e=str(e)))
            return {'CANCELLED'}
        finally:
            if active and restore_mode:
                try:
                    _suv_safe_mode_set(context, active, prev_mode, source='3D Smart Transfer restore')
                except Exception:
                    pass

class SUV_OT_repair_flipped_islands(bpy.types.Operator):
    bl_idname = "uv.suv_repair_flipped_islands"
    bl_label = 'Repair Flipped Islands'
    bl_description = "Detect and fix flipped UV islands so their winding direction becomes consistent again. / 反転したUVアイランドを検出して修正し、向きを再び揃えます。"
    bl_options = {'UNDO'}

    eps: bpy.props.FloatProperty(name="UV Epsilon", default=1e-5, min=1e-8, max=1e-2)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        fixed = 0
        with _TempMode(context, obj, 'EDIT'):
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.verify()
            faces = [f for f in bm.faces if f.select] or list(bm.faces)
            islands = build_islands(bm, uv_layer, faces_subset=faces, eps=self.eps)
            for isl in islands:
                if isl.signed_area < 0.0:
                    pivot = isl.uv_centroid
                    for l in isl.loops:
                        l[uv_layer].uv = _mirror_x(Vector(l[uv_layer].uv), pivot)
                    if sum(_signed_uv_area(f, uv_layer) for f in isl.faces) < 0.0:
                        for l in isl.loops:
                            l[uv_layer].uv = _mirror_y(Vector(l[uv_layer].uv), pivot)
                    fixed += 1
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        self.report({'INFO'}, tr(context, "msg.repair_done", n=fixed))
        return {'FINISHED'}

