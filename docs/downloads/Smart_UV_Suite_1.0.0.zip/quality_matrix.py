from __future__ import annotations
from . import resource_api_18168 as _suv_resource
from .quality_class_inventory import iter_suite_classes

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None

_NAMESPACE = {}
_REGISTERED = []

_FEATURE_GROUPS = [
    {
        'key': 'unwrap_relax',
        'title_en': 'Unwrap & Relax',
        'title_ja': '展開とリラックス',
        'references': 'Smart UV標準DCC / Blender / DCC Reference / Smart UV高精度参照 / Smart UVレイアウト参照',
        'keywords': ('unwrap', 'unfold', 'relax', 'minimum stretch', 'slim', 'peel', 'straighten', 'gridify', 'quadrify', 'rectify', 'iron'),
        'needed': 3,
    },
    {
        'key': 'projection_mapping',
        'title_en': 'Projection & Mapping',
        'title_ja': '投影とマッピング',
        'references': 'Smart UV標準DCC / Blender / DCC Reference / Smart UVテクスチャ参照',
        'keywords': ('project', 'projection', 'planar', 'camera', 'cyl', 'cylinder', 'sphere', 'view', 'normal', 'mapping'),
        'needed': 2,
    },
    {
        'key': 'seams_stitch',
        'title_en': 'Seams & Stitch',
        'title_ja': 'シームと接続',
        'references': 'Smart UV標準DCC / Blender / DCC Reference / Smart UV Suite reference',
        'keywords': ('seam', 'cut', 'sew', 'stitch', 'weld', 'peel', 'border seam', 'mirror seam'),
        'needed': 3,
    },
    {
        'key': 'layout_packing',
        'title_en': 'Layout & Packing',
        'title_ja': 'レイアウトとパッキング',
        'references': 'Smart UV高精度参照 / Smart UV高密度パック / Smart UV Suite編集支援 / Blender',
        'keywords': ('pack', 'layout', 'fit', 'bounds', 'udim', 'tile', 'orient', 'distribute', 'randomize', 'arrange', 'stack', 'unstack'),
        'needed': 4,
    },
    {
        'key': 'selection_analysis',
        'title_en': 'Selection & Analysis',
        'title_ja': '選択と解析',
        'references': 'Smart UV Suite reference / Smart UVレイアウト参照 / Smart UV Suite編集支援',
        'keywords': ('select', 'similar', 'inspect', 'scan', 'audit', 'overlap', 'flipped', 'degenerate', 'issue', 'diagnostic'),
        'needed': 4,
    },
    {
        'key': 'density_qa',
        'title_en': 'Texel Density & QA',
        'title_ja': 'テクセル密度とQA',
        'references': 'Smart UV Suite reference / Smart UV Suite編集支援 / Smart UVモデリング参照 / Smart UVレイアウト参照',
        'keywords': ('density', 'texel', 'normalize', 'checker', 'histogram', 'quality', 'qa'),
        'needed': 3,
    },
    {
        'key': 'maps_preview',
        'title_en': 'UV Maps & Preview',
        'title_ja': 'UVマップとプレビュー',
        'references': 'Blender / Smart UVテクスチャ参照 / Smart UV Suite reference / Smart UV Suite編集支援',
        'keywords': ('uvmap', 'uv map', 'layer', 'checker', 'preview', 'material', 'channel', 'set active', 'rename'),
        'needed': 3,
    },
    {
        'key': 'symmetry_transfer',
        'title_en': 'Symmetry & Transfer',
        'title_ja': '対称と転送',
        'references': 'Smart UV展開参照 / Smart UVレイアウト参照 / UV Suite',
        'keywords': ('sym', 'symmetry', 'mirror', 'transfer', 'pair', 'stack'),
        'needed': 3,
    },
    {
        'key': 'atlas_bake',
        'title_en': 'Atlas & Bake',
        'title_ja': 'アトラスとベイク',
        'references': 'Reference Bake Layout / Smart UV Suite reference / Game Engine / UV Suite',
        'keywords': ('atlas', 'bake', 'lightmap', 'material', 'output', 'render'),
        'needed': 2,
    },
    {
        'key': 'maintenance_guidance',
        'title_en': 'Maintenance & Guidance',
        'title_ja': '保守とガイド',
        'references': 'Production support / internal quality layer',
        'keywords': ('repair', 'workspace', 'snapshot', 'support', 'cleanup', 'recovery', 'readiness', 'guide', 'context', 'report', 'audit'),
        'needed': 4,
    },
]


def _tr(context, key: str, fallback_en: str, fallback_ja: str, **fmt):
    fn = _NAMESPACE.get('tr')
    text = None
    if callable(fn):
        try:
            text = fn(context, key, **fmt)
        except Exception:
            text = None
    if not text:
        text = fallback_en
    try:
        return text.format(**fmt)
    except Exception:
        return text


def _text_name(context) -> str:
    ws_fn = _NAMESPACE.get('_suv_ws')
    ws = ws_fn(context) if callable(ws_fn) else None
    name = getattr(ws, 'support_bundle_name', '') if ws else ''
    return (str(name).strip() or 'SUV_Support_Bundle') + '_Feature_Matrix'


def _text_block(name: str, clear=False):
    textio = _NAMESPACE.get('_quality_textio_module')
    if textio is not None and hasattr(textio, 'ensure_report_text'):
        try:
            return textio.ensure_report_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if textio is not None and hasattr(textio, 'ensure_namespace_text'):
        try:
            return textio.ensure_namespace_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if bpy is None:
        return None
    txt = bpy.data.texts.get(name)
    if txt is None:
        if not clear:
            return None
        txt = bpy.data.texts.new(name)
    elif clear:
        txt.clear()
    return txt


def _class_haystacks(namespace: dict) -> list[str]:
    hay = []
    for name, value in iter_suite_classes(namespace):
        if not isinstance(value, type):
            continue
        if not (name.startswith('SUV_OT_') or name.startswith('SUV_PT_') or name.startswith('SUV_MT_')):
            continue
        try:
            parts = [name.replace('_', ' '), getattr(value, 'bl_idname', ''), getattr(value, 'bl_label', ''), getattr(value, 'bl_description', '')]
            text = ' '.join(str(p or '') for p in parts).lower()
            if text.strip():
                hay.append(text)
        except Exception:
            continue
    return hay


def scan_feature_matrix(namespace: dict, context=None) -> dict:
    hay = _class_haystacks(namespace)
    groups = []
    supported = partial = missing = 0
    for spec in _FEATURE_GROUPS:
        hits = []
        for kw in spec['keywords']:
            low = kw.lower()
            if any(low in entry for entry in hay):
                hits.append(kw)
        hit_count = len(hits)
        needed = int(spec.get('needed', 2) or 2)
        if hit_count >= needed:
            status = 'supported'
            supported += 1
        elif hit_count > 0:
            status = 'partial'
            partial += 1
        else:
            status = 'missing'
            missing += 1
        groups.append({
            'key': spec['key'],
            'title_en': spec['title_en'],
            'title_ja': spec['title_ja'],
            'references': spec['references'],
            'status': status,
            'hits': hits,
            'hit_count': hit_count,
            'needed': needed,
        })
    result = {
        'total': len(groups),
        'supported': supported,
        'partial': partial,
        'missing': missing,
        'groups': groups,
    }
    namespace['_suv_feature_matrix_last'] = result
    return result


class SUV_OT_quality_scan_feature_matrix(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_scan_feature_matrix'
    bl_label = 'Build Feature Matrix'
    bl_description = 'Build a compact feature-matrix report that compares the current add-on surface against common UV tool groups such as unwrap, packing, QA, symmetry, atlas, and maintenance support. / 展開、パッキング、QA、対称、アトラス、保守支援など、代表的なUV機能群に対する現在のアドオン対応状況を簡易マトリクスとして作成します。'
    bl_options = set()

    open_after_write: bpy.props.BoolProperty(
        name='Open After Write',
        description='Open the written feature matrix in Blender Text Editor when possible / 可能なら書き出した機能マトリクスを Blender テキストエディタで開きます',
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        data = scan_feature_matrix(_NAMESPACE, context)
        txt = None
        lines = [
            'UV Suite Feature Matrix',
            f"Supported groups: {data['supported']}/{data['total']}",
            f"Partial groups: {data['partial']}",
            f"Missing groups: {data['missing']}",
            '',
            '[Legend]',
            'supported = multiple matching tool surfaces are present in the current add-on namespace',
            'partial = at least one matching surface exists but the group still looks thin',
            'missing = no obvious matching surface was detected by the current keyword scan',
            '',
            '[Groups]',
        ]
        for row in data['groups']:
            lines.append(f"- {row['title_en']} [{row['status']}]")
            lines.append(f"  References: {row['references']}")
            lines.append(f"  Matches: {', '.join(row['hits']) if row['hits'] else '-'}")
            lines.append(f"  Detection score: {row['hit_count']}/{row['needed']}")
        lines.extend(['', '[Next focus]'])
        missing_titles = [g['title_en'] for g in data['groups'] if g['status'] == 'missing']
        partial_titles = [g['title_en'] for g in data['groups'] if g['status'] == 'partial']
        if missing_titles:
            lines.append('- Missing groups to design or wire next: ' + ', '.join(missing_titles))
        if partial_titles:
            lines.append('- Partial groups to deepen next: ' + ', '.join(partial_titles))
        if not missing_titles and not partial_titles:
            lines.append('- The current matrix scan looks broad. Next step should focus on operator-level correctness and UI polish.')
        textio = _NAMESPACE.get('_quality_textio_module')
        writer = getattr(textio, 'write_report_lines_consistent', None) if textio is not None else None
        if callable(writer):
            txt = writer(
                _NAMESPACE, context, _text_name, lines, _text_block, self,
                open_after_write=self.open_after_write,
                failed_key='msg.quality_matrix_open_failed',
                failed_en='Could not open feature matrix: {name}',
                failed_ja='機能マトリクスを開けませんでした: {name}',
            )
            if txt is None:
                return {'CANCELLED'}
        else:
            txt = _text_block(_text_name(context), clear=True)
            if txt is None:
                return {'CANCELLED'}
            txt.write('\n'.join(lines))
            if self.open_after_write:
                opener = _NAMESPACE.get('_suv_open_text_in_editor')
                if callable(opener):
                    try:
                        opener(context, txt)
                    except Exception:
                        pass
        msg = _tr(context, 'msg.quality_matrix_written', 'Feature matrix written: {name} (supported {supported}/{total})', '機能マトリクスを書き出しました: {name}（対応 {supported}/{total}）', name=txt.name, supported=data['supported'], total=data['total'])
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class SUV_OT_quality_open_feature_matrix(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_open_feature_matrix'
    bl_label = 'Open Feature Matrix'
    bl_description = 'Open the latest UV Suite feature-matrix text block in Blender Text Editor. / 最新の UV Suite 機能マトリクステキストを Blender のテキストエディタで開きます。'
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        textio = _NAMESPACE.get('_quality_textio_module')
        if textio is not None and hasattr(textio, 'open_named_report_text_or_fallback'):
            return textio.open_named_report_text_or_fallback(
                _NAMESPACE, context, _text_name, self, _text_block,
                missing_key='msg.quality_matrix_missing',
                missing_en='No feature matrix exists yet.',
                missing_ja='機能マトリクスはまだ作成されていません。',
                opened_key='msg.quality_matrix_opened',
                opened_en='Opened feature matrix: {name}',
                opened_ja='機能マトリクスを開きました: {name}',
            )
        txt = _text_block(_text_name(context), clear=False)
        if txt is None:
            self.report({'WARNING'}, _tr(context, 'msg.quality_matrix_missing', 'No feature matrix exists yet.', '機能マトリクスはまだ作成されていません。'))
            return {'CANCELLED'}
        opener = _NAMESPACE.get('_suv_open_text_in_editor')
        ok = False
        if callable(opener):
            try:
                ok, _err = opener(context, txt)
            except Exception:
                ok = False
        if not ok:
            self.report({'WARNING'}, _tr(context, 'msg.quality_matrix_open_failed', 'Could not open feature matrix: {name}', '機能マトリクスを開けませんでした: {name}', name=txt.name))
            return {'CANCELLED'}
        msg = _tr(context, 'msg.quality_matrix_opened', 'Opened feature matrix: {name}', '機能マトリクスを開きました: {name}', name=txt.name)
        self.report({'INFO'}, msg)
        return {'FINISHED'}



def register(namespace: dict):
    global _NAMESPACE
    _NAMESPACE = namespace if isinstance(namespace, dict) else {}
    if bpy is None:
        return []
    classes = [SUV_OT_quality_scan_feature_matrix, SUV_OT_quality_open_feature_matrix]
    reg = []
    for cls in classes:
        try:
            _suv_resource.register_class(cls)
            reg.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = reg
    return reg


def unregister(namespace: dict | None = None):
    if bpy is None:
        return []
    removed = []
    for cls in reversed(list(_REGISTERED)):
        try:
            _suv_resource.unregister_class(cls)
            removed.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = []
    return removed
