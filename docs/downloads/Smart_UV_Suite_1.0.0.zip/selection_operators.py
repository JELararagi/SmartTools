from . import pro_operators as _prev
_IGNORE_KEYS = {'__name__','__package__','__loader__','__spec__','__file__','__cached__','__builtins__'}
globals().update({k: v for k, v in _prev.__dict__.items() if k not in _IGNORE_KEYS})

# ============================================================
# Selection & Sets Operators
# ============================================================

class SUV_OT_select_island_active(bpy.types.Operator):
    bl_idname = "uv.suv_select_island_active"
    bl_label = 'Select Island (Active)'
    bl_description = "Select the full UV island that belongs to the current active or picked element. / 現在アクティブな要素に属するUVアイランド全体を選択します。"
    bl_options = {'UNDO'}

    extend: bpy.props.BoolProperty(name="Extend", default=False)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        with _TempMode(context, obj, 'EDIT'):
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.verify()
            active_face = getattr(bm.faces, "active", None)
            if not active_face:
                self.report({'WARNING'}, tr(context, "msg.no_selection"))
                return {'CANCELLED'}
            islands = build_islands(bm, uv_layer, faces_subset=list(bm.faces))
            isl = next((i for i in islands if active_face in i.faces), None)
            if not isl:
                self.report({'WARNING'}, tr(context, "msg.no_selection"))
                return {'CANCELLED'}
            if not self.extend:
                for f in bm.faces:
                    _suv_face_select(context, f, False)
            for f in isl.faces:
                _suv_face_select(context, f, True)
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return {'FINISHED'}

class SUV_OT_select_similar_islands(bpy.types.Operator):
    bl_idname = "uv.suv_select_similar_islands"
    bl_label = 'Select Similar Islands'
    bl_description = "Find islands that are similar in size and proportions to the current reference island. / 現在の基準アイランドに近いサイズと比率を持つアイランドを探して選択します。"
    bl_options = {'UNDO'}

    area_tol: bpy.props.FloatProperty(name="Area Tolerance", default=0.08, min=0.0, max=1.0)
    aspect_tol: bpy.props.FloatProperty(name="Aspect Tolerance", default=0.15, min=0.0, max=1.0)
    extend: bpy.props.BoolProperty(name="Extend", default=True)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        with _TempMode(context, obj, 'EDIT'):
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.verify()
            active_face = getattr(bm.faces, "active", None)
            if not active_face:
                self.report({'WARNING'}, tr(context, "msg.no_selection"))
                return {'CANCELLED'}
            islands = build_islands(bm, uv_layer, faces_subset=list(bm.faces))
            ref = next((i for i in islands if active_face in i.faces), None)
            if not ref:
                self.report({'WARNING'}, tr(context, "msg.no_selection"))
                return {'CANCELLED'}
            if not self.extend:
                for f in bm.faces:
                    _suv_face_select(context, f, False)
            for isl in islands:
                if _islands_match(ref, isl, self.area_tol, self.aspect_tol, strict=False):
                    for f in isl.faces:
                        _suv_face_select(context, f, True)
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return {'FINISHED'}

class SUV_OT_select_identical_islands(bpy.types.Operator):
    bl_idname = "uv.suv_select_identical_islands"
    bl_label = 'Select Identical Islands'
    bl_description = "Find islands that are nearly identical to the reference island for stacking or reuse workflows. / 基準アイランドとほぼ同一のアイランドを探し、スタックや再利用作業に使いやすくします。"
    bl_options = {'UNDO'}

    area_tol: bpy.props.FloatProperty(name="Area Tolerance", default=0.02, min=0.0, max=1.0)
    aspect_tol: bpy.props.FloatProperty(name="Aspect Tolerance", default=0.03, min=0.0, max=1.0)
    extend: bpy.props.BoolProperty(name="Extend", default=True)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        with _TempMode(context, obj, 'EDIT'):
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.verify()
            active_face = getattr(bm.faces, "active", None)
            if not active_face:
                self.report({'WARNING'}, tr(context, "msg.no_selection"))
                return {'CANCELLED'}
            islands = build_islands(bm, uv_layer, faces_subset=list(bm.faces))
            ref = next((i for i in islands if active_face in i.faces), None)
            if not ref:
                self.report({'WARNING'}, tr(context, "msg.no_selection"))
                return {'CANCELLED'}
            if not self.extend:
                for f in bm.faces:
                    _suv_face_select(context, f, False)
            count = 0
            for isl in islands:
                if not _islands_match(ref, isl, self.area_tol, self.aspect_tol, strict=True):
                    continue
                for f in isl.faces:
                    _suv_face_select(context, f, True)
                count += 1
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        self.report({'INFO'}, tr(context, "msg.sel_identical_done", n=count))
        return {'FINISHED'}


class SUV_OT_select_fragmented_islands(bpy.types.Operator):
    bl_idname = "uv.suv_select_fragmented_islands"
    bl_label = 'Select Shattered Islands'
    bl_description = "Select shattered, tiny or sliver-like UV islands so fragmented shells are easier to review and repair. / 細切れ、極小、または細長いUVアイランドを選択し、分断されたシェルの確認と修正をしやすくします。"
    bl_options = {'UNDO'}

    mode: bpy.props.EnumProperty(
        name="Mode",
        items=[
            ('SHATTERED', "Shattered", "Select fragmented islands using single-face, tiny-area and sliver heuristics / 単面・極小・細長い条件で細切れ島を選択"),
            ('TINY', "Tiny", "Select tiny islands only / 極小アイランドのみを選択"),
            ('SLIVER', "Sliver", "Select thin sliver-like islands only / 細長いアイランドのみを選択"),
        ],
        default='SHATTERED',
    )
    extend: bpy.props.BoolProperty(name="Extend", default=True)
    tiny_area_factor: bpy.props.FloatProperty(name="Tiny Area Factor", default=0.10, min=0.001, max=1.0)
    sliver_aspect: bpy.props.FloatProperty(name="Sliver Aspect", default=18.0, min=2.0, max=200.0)
    sliver_area_factor: bpy.props.FloatProperty(name="Sliver Area Factor", default=0.35, min=0.001, max=2.0)
    fallback_abs_area: bpy.props.FloatProperty(name="Fallback Absolute Area", default=1.0e-6, min=1.0e-10, max=1.0)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        with _TempMode(context, obj, 'EDIT'):
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.verify()
            islands = build_islands(bm, uv_layer, faces_subset=list(bm.faces))
            if not islands:
                self.report({'WARNING'}, tr(context, "msg.no_selection"))
                return {'CANCELLED'}
            positive_areas = sorted(float(getattr(isl, 'abs_area', 0.0) or 0.0) for isl in islands if float(getattr(isl, 'abs_area', 0.0) or 0.0) > 0.0)
            median_area = positive_areas[len(positive_areas) // 2] if positive_areas else 0.0
            tiny_limit = max(1.0e-8, median_area * float(self.tiny_area_factor)) if median_area > 0.0 else max(1.0e-10, float(self.fallback_abs_area))
            sliver_area_limit = max(1.0e-7, median_area * float(self.sliver_area_factor)) if median_area > 0.0 else max(1.0e-10, float(self.fallback_abs_area))
            if not self.extend:
                for f in bm.faces:
                    _suv_face_select(context, f, False)
            count = 0
            for isl in islands:
                area = float(getattr(isl, 'abs_area', 0.0) or 0.0)
                width = max(1.0e-12, float(getattr(isl, 'bbox_max', Vector((0.0, 0.0))).x - getattr(isl, 'bbox_min', Vector((0.0, 0.0))).x))
                height = max(1.0e-12, float(getattr(isl, 'bbox_max', Vector((0.0, 0.0))).y - getattr(isl, 'bbox_min', Vector((0.0, 0.0))).y))
                aspect = max(width, height) / max(1.0e-12, min(width, height))
                face_count = int(len(getattr(isl, 'faces', []) or []))
                is_tiny = bool(area <= tiny_limit)
                is_sliver = bool(aspect >= float(self.sliver_aspect) and area <= sliver_area_limit)
                is_shattered = bool(face_count <= 1 or is_tiny or is_sliver)
                match = is_shattered if self.mode == 'SHATTERED' else is_tiny if self.mode == 'TINY' else is_sliver
                if not match:
                    continue
                for f in getattr(isl, 'faces', []) or []:
                    _suv_face_select(context, f, True)
                count += 1
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        label = {'SHATTERED': 'shattered', 'TINY': 'tiny', 'SLIVER': 'sliver'}[self.mode]
        self.report({'INFO'}, f'Selected {count} {label} island(s)')
        return {'FINISHED'}


class SUV_OT_select_uv_boundary(bpy.types.Operator):
    bl_idname = "uv.suv_select_uv_boundary"
    bl_label = 'Select UV Boundary'
    bl_description = "Select boundary edges or border elements of the current UV selection. / 現在のUV選択の境界エッジや外周要素を選択します。"
    bl_options = {'UNDO'}

    include_seams: bpy.props.BoolProperty(name="Include Seams", default=True)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        with _TempMode(context, obj, 'EDIT'):
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.verify()
            sel_faces = [f for f in bm.faces if _suv_face_selected(context, f) or (f.select and any(l.uv_select_edge or l.uv_select_vert for l in f.loops))]
            if not sel_faces:
                self.report({'WARNING'}, tr(context, "msg.no_selection"))
                return {'CANCELLED'}
            islands = build_islands(bm, uv_layer, faces_subset=sel_faces)
            sel_face_set = set(sel_faces)
            if _is_uv_sync(context):
                for e in bm.edges:
                    e.select = False
            else:
                for f in bm.faces:
                    _suv_face_select(context, f, False)
            eps = 1e-5
            for isl in islands:
                for f in isl.faces:
                    for l in f.loops:
                        e = l.edge
                        if len(e.link_faces) != 2:
                            _suv_uv_edge_select(context, l, True)
                            continue
                        other = e.link_faces[0] if e.link_faces[1] == f else e.link_faces[1]
                        if other not in sel_face_set:
                            _suv_uv_edge_select(context, l, True)
                            continue
                        if self.include_seams and getattr(e, "seam", False):
                            _suv_uv_edge_select(context, l, True)
                            continue
                        a0, a1 = _edge_uvs_in_face(f, e, uv_layer)
                        b0, b1 = _edge_uvs_in_face(other, e, uv_layer)
                        if a0 and b0:
                            if not (_uv_close(a0, b0, eps) and _uv_close(a1, b1, eps)):
                                _suv_uv_edge_select(context, l, True)
            try:
                if _is_uv_sync(context):
                    bpy.ops.mesh.select_mode(type='EDGE')
            except Exception:
                pass
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return {'FINISHED'}



def _suv_selection_sets_payload(objects):
    payload_objects = []
    for obj in objects or []:
        if not obj or getattr(obj, 'type', None) != 'MESH':
            continue
        sets_dict = _get_sets(obj)
        if not isinstance(sets_dict, dict) or not sets_dict:
            continue
        clean_sets = {}
        for key, rec in sets_dict.items():
            if not isinstance(rec, dict):
                continue
            faces = rec.get('faces', [])
            if not isinstance(faces, (list, tuple, set)):
                continue
            face_ids = []
            seen = set()
            for value in faces:
                try:
                    idx = int(value)
                except Exception:
                    continue
                if idx < 0 or idx in seen:
                    continue
                seen.add(idx)
                face_ids.append(idx)
            clean_sets[str(key)] = {'faces': sorted(face_ids)}
        if not clean_sets:
            continue
        face_count = 0
        try:
            face_count = len(getattr(getattr(obj, 'data', None), 'polygons', []) or [])
        except Exception:
            face_count = 0
        payload_objects.append({
            'name': getattr(obj, 'name', 'Object'),
            'face_count': int(face_count),
            'sets': clean_sets,
        })
    return {
        'format': 'uv_suite_selection_sets',
        'version': 1,
        'objects': payload_objects,
    }


def _suv_apply_selection_sets_payload(context, payload, *, target_mode='ACTIVE', merge=True, apply_selection=False):
    objects_payload = list((payload or {}).get('objects') or [])
    if not objects_payload:
        return {'targets': 0, 'sets': 0, 'applied': 0, 'skipped': 0}

    selected_meshes = [obj for obj in _selected_mesh_objects(context) if getattr(obj, 'type', None) == 'MESH']
    active = _active_mesh_obj(context)
    target_mode = str(target_mode or 'ACTIVE').upper()
    targets = []
    if target_mode == 'SELECTED':
        targets = selected_meshes[:] if selected_meshes else ([active] if active else [])
    else:
        targets = [active] if active else []
    targets = [obj for obj in targets if obj is not None]
    if not targets:
        return {'targets': 0, 'sets': 0, 'applied': 0, 'skipped': len(objects_payload)}

    payload_by_name = {}
    for rec in objects_payload:
        name = str((rec or {}).get('name') or '').strip()
        if name:
            payload_by_name[name] = rec

    applied = 0
    skipped = 0
    sets_written = 0
    for obj in targets:
        source = payload_by_name.get(getattr(obj, 'name', ''))
        if source is None:
            if len(objects_payload) == 1:
                source = objects_payload[0]
            elif target_mode == 'ACTIVE':
                source = objects_payload[0]
        if source is None:
            skipped += 1
            continue
        incoming = {}
        for key, data in dict((source or {}).get('sets') or {}).items():
            if not isinstance(data, dict):
                continue
            face_ids = []
            seen = set()
            for value in data.get('faces', []) or []:
                try:
                    idx = int(value)
                except Exception:
                    continue
                if idx < 0 or idx in seen:
                    continue
                seen.add(idx)
                face_ids.append(idx)
            incoming[str(key)] = {'faces': sorted(face_ids)}
        if not incoming:
            skipped += 1
            continue
        current = _get_sets(obj) if merge else {}
        if not isinstance(current, dict):
            current = {}
        current.update(incoming)
        _set_sets(obj, current)
        sets_written += len(incoming)
        applied += 1
        if apply_selection:
            first_name = next(iter(incoming.keys()), None)
            face_ids = set((incoming.get(first_name) or {}).get('faces') or []) if first_name else set()
            if face_ids:
                try:
                    with _TempMode(context, obj, 'EDIT'):
                        bm = bmesh.from_edit_mesh(obj.data)
                        for f in bm.faces:
                            f.select = (f.index in face_ids)
                        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
                except Exception:
                    pass
    return {'targets': len(targets), 'sets': sets_written, 'applied': applied, 'skipped': skipped}


class SUV_OT_set_library_io(bpy.types.Operator):
    bl_idname = "uv.suv_set_library_io"
    bl_label = 'Selection Set Library I/O'
    bl_description = "Export or import saved selection sets as Blender Text or JSON files so they can be reused across scenes and assets. / 保存した選択セットを Blender Text や JSON ファイルへ入出力し、シーンやアセットをまたいで再利用できるようにします。"
    bl_options = {'UNDO'}

    mode: bpy.props.EnumProperty(
        name="Mode",
        items=[
            ('EXPORT_TEXT', "Export to Text", "Write saved sets into a Blender Text datablock / 保存セットを Blender Text に書き出します"),
            ('IMPORT_TEXT', "Import from Text", "Read saved sets from a Blender Text datablock / Blender Text から保存セットを読み込みます"),
            ('EXPORT_FILE', "Export to File", "Write saved sets into a JSON file / 保存セットを JSON ファイルへ書き出します"),
            ('IMPORT_FILE', "Import from File", "Read saved sets from a JSON file / JSON ファイルから保存セットを読み込みます"),
        ],
        default='EXPORT_TEXT',
    )
    scope: bpy.props.EnumProperty(
        name="Scope",
        items=[
            ('ACTIVE', "Active", "Use the active mesh object / アクティブメッシュのみを対象にします"),
            ('SELECTED', "Selected", "Use all selected mesh objects / 選択メッシュ全体を対象にします"),
        ],
        default='ACTIVE',
    )
    text_name: bpy.props.StringProperty(name="Text Name", default="SUV_Selection_Sets")
    filepath: bpy.props.StringProperty(name="Filepath", default="", subtype='FILE_PATH')
    filter_glob: bpy.props.StringProperty(default="*.json", options={'HIDDEN'})
    merge: bpy.props.BoolProperty(name="Merge", default=True, description="Keep existing saved sets and add imported ones on top / 既存セットを残したまま読み込みセットを追加します")
    apply_selection: bpy.props.BoolProperty(name="Apply First Imported Set", default=False, description="Also select the first imported set on each target object / 読み込んだ先頭セットを各対象オブジェクトでそのまま選択します")

    def invoke(self, context, event):
        if self.mode in {'EXPORT_FILE', 'IMPORT_FILE'}:
            if not self.filepath:
                base = os.path.splitext(bpy.path.basename(bpy.data.filepath))[0] if getattr(bpy.data, 'filepath', '') else 'uv_suite'
                suffix = 'selection_sets_export' if self.mode == 'EXPORT_FILE' else 'selection_sets_import'
                self.filepath = bpy.path.ensure_ext(f"{base}_{suffix}", '.json')
            context.window_manager.fileselect_add(self)
            return {'RUNNING_MODAL'}
        return self.execute(context)

    def execute(self, context):
        if self.mode.startswith('EXPORT'):
            if self.scope == 'SELECTED':
                objects = _selected_mesh_objects(context)
            else:
                active = _active_mesh_obj(context)
                objects = [active] if active else []
            payload = _suv_selection_sets_payload(objects)
            if not payload.get('objects'):
                self.report({'WARNING'}, 'No saved sets found to export')
                return {'CANCELLED'}
            data = json.dumps(payload, indent=2, ensure_ascii=False, sort_keys=True)
            if self.mode == 'EXPORT_TEXT':
                txt = _suv_text_block(self.text_name or 'SUV_Selection_Sets', clear=True)
                txt.write(data)
                self.report({'INFO'}, f'Selection sets exported to text: {txt.name}')
                return {'FINISHED'}
            path = bpy.path.abspath(self.filepath) if self.filepath else ''
            if not path:
                self.report({'WARNING'}, 'No export filepath specified')
                return {'CANCELLED'}
            os.makedirs(os.path.dirname(path), exist_ok=True) if os.path.dirname(path) else None
            with open(path, 'w', encoding='utf-8') as handle:
                handle.write(data)
            self.report({'INFO'}, f'Selection sets exported: {path}')
            return {'FINISHED'}

        if self.mode == 'IMPORT_TEXT':
            txt = bpy.data.texts.get(self.text_name or '')
            if txt is None:
                self.report({'WARNING'}, f'Text not found: {self.text_name}')
                return {'CANCELLED'}
            raw = txt.as_string()
            source_label = txt.name
        else:
            path = bpy.path.abspath(self.filepath) if self.filepath else ''
            if not path or not os.path.isfile(path):
                self.report({'WARNING'}, f'JSON file not found: {path or self.filepath}')
                return {'CANCELLED'}
            with open(path, 'r', encoding='utf-8') as handle:
                raw = handle.read()
            source_label = path
        try:
            payload = json.loads(raw)
        except Exception as exc:
            self.report({'WARNING'}, f'Invalid selection set JSON: {exc}')
            return {'CANCELLED'}
        if str(payload.get('format', '')) != 'uv_suite_selection_sets':
            self.report({'WARNING'}, 'Unsupported selection set format')
            return {'CANCELLED'}
        stats = _suv_apply_selection_sets_payload(context, payload, target_mode=self.scope, merge=self.merge, apply_selection=self.apply_selection)
        self.report({'INFO'}, f"Imported selection sets from {source_label} (targets={stats['applied']}, sets={stats['sets']}, skipped={stats['skipped']})")
        return {'FINISHED'}


class SUV_OT_set_transfer(bpy.types.Operator):
    bl_idname = "uv.suv_set_transfer"
    bl_label = 'Transfer Set'
    bl_description = "Copy a saved selection set from the active mesh to the other selected meshes so repeated assets can reuse the same selection slot. / アクティブメッシュの保存セットを他の選択メッシュへコピーし、繰り返しアセットでも同じ選択スロットを再利用できるようにします。"
    bl_options = {'UNDO'}

    set_name: bpy.props.EnumProperty(name="Set", items=_sets_enum_items, default=0)
    overwrite: bpy.props.BoolProperty(name="Overwrite", default=True)
    apply_to_targets: bpy.props.BoolProperty(name="Apply on Targets", default=False)

    def execute(self, context):
        src = _active_mesh_obj(context)
        if not src:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        if self.set_name == '__NONE__':
            self.report({'WARNING'}, tr(context, "msg.no_selection"))
            return {'CANCELLED'}
        source_sets = _get_sets(src)
        if self.set_name not in source_sets:
            self.report({'WARNING'}, tr(context, "msg.set_missing", name=self.set_name))
            return {'CANCELLED'}
        record = source_sets.get(self.set_name) or {}
        face_ids = sorted({int(v) for v in (record.get('faces') or []) if isinstance(v, int) or (isinstance(v, str) and str(v).isdigit())})
        if not face_ids:
            self.report({'WARNING'}, tr(context, "msg.no_selection"))
            return {'CANCELLED'}
        targets = [obj for obj in _selected_mesh_objects(context) if obj != src]
        if not targets:
            self.report({'WARNING'}, 'No target meshes selected')
            return {'CANCELLED'}
        copied = 0
        skipped = 0
        for obj in targets:
            face_count = len(getattr(getattr(obj, 'data', None), 'polygons', []) or [])
            if face_count <= max(face_ids):
                skipped += 1
                continue
            d = _get_sets(obj)
            if (self.set_name in d) and (not self.overwrite):
                skipped += 1
                continue
            d[self.set_name] = {'faces': list(face_ids)}
            _set_sets(obj, d)
            copied += 1
            if self.apply_to_targets:
                try:
                    with _TempMode(context, obj, 'EDIT'):
                        bm = bmesh.from_edit_mesh(obj.data)
                        for f in bm.faces:
                            f.select = (f.index in set(face_ids))
                        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
                except Exception:
                    pass
        self.report({'INFO'}, f'Transferred set {self.set_name} to {copied} target(s), skipped {skipped}')
        return {'FINISHED'}


def _suv_current_seam_edges(context, obj, *, selected_only=False):
    if not obj or getattr(obj, 'type', None) != 'MESH':
        return []
    edge_ids = []
    with _TempMode(context, obj, 'EDIT'):
        bm = bmesh.from_edit_mesh(obj.data)
        for edge in bm.edges:
            if not bool(getattr(edge, 'seam', False)):
                continue
            if selected_only and not bool(getattr(edge, 'select', False)):
                continue
            edge_ids.append(int(edge.index))
    return sorted(set(edge_ids))


def _suv_seam_sets_payload(objects):
    payload_objects = []
    for obj in objects or []:
        if not obj or getattr(obj, 'type', None) != 'MESH':
            continue
        sets_dict = _get_seam_sets(obj)
        if not isinstance(sets_dict, dict) or not sets_dict:
            continue
        clean_sets = {}
        for key, rec in sets_dict.items():
            if not isinstance(rec, dict):
                continue
            edges = rec.get('edges', [])
            if not isinstance(edges, (list, tuple, set)):
                continue
            edge_ids = []
            seen = set()
            for value in edges:
                try:
                    idx = int(value)
                except Exception:
                    continue
                if idx < 0 or idx in seen:
                    continue
                seen.add(idx)
                edge_ids.append(idx)
            clean_sets[str(key)] = {
                'edges': sorted(edge_ids),
                'selected_only': bool(rec.get('selected_only', False)),
            }
        if not clean_sets:
            continue
        edge_count = 0
        try:
            edge_count = len(getattr(getattr(obj, 'data', None), 'edges', []) or [])
        except Exception:
            edge_count = 0
        payload_objects.append({
            'name': getattr(obj, 'name', 'Object'),
            'edge_count': int(edge_count),
            'sets': clean_sets,
        })
    return {
        'format': 'uv_suite_seam_sets',
        'version': 1,
        'objects': payload_objects,
    }


def _suv_apply_seam_set_to_object(context, obj, edge_ids, *, apply_mode='REPLACE', clear_existing=True, select_applied=False):
    if not obj or getattr(obj, 'type', None) != 'MESH':
        return {'status': 'INVALID', 'applied': 0, 'missing': 0}
    edge_ids = sorted({int(v) for v in (edge_ids or []) if int(v) >= 0}) if edge_ids else []
    if not edge_ids and apply_mode != 'REPLACE':
        return {'status': 'EMPTY', 'applied': 0, 'missing': 0}
    target_ids = set(edge_ids)
    with _TempMode(context, obj, 'EDIT'):
        bm = bmesh.from_edit_mesh(obj.data)
        all_indices = {int(edge.index) for edge in bm.edges}
        missing = len([idx for idx in target_ids if idx not in all_indices])
        applied = 0
        if apply_mode == 'REPLACE':
            if clear_existing:
                for edge in bm.edges:
                    edge.seam = False
            for edge in bm.edges:
                if edge.index in target_ids:
                    edge.seam = True
                    applied += 1
                if select_applied:
                    edge.select = (edge.index in target_ids)
        elif apply_mode == 'ADD':
            for edge in bm.edges:
                if edge.index in target_ids:
                    edge.seam = True
                    applied += 1
                    if select_applied:
                        edge.select = True
        elif apply_mode == 'SUB':
            for edge in bm.edges:
                if edge.index in target_ids:
                    if bool(getattr(edge, 'seam', False)):
                        applied += 1
                    edge.seam = False
                    if select_applied:
                        edge.select = True
        else:
            return {'status': 'INVALID_MODE', 'applied': 0, 'missing': 0}
        try:
            bpy.ops.mesh.select_mode(type='EDGE')
        except Exception:
            pass
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    return {'status': 'OK', 'applied': int(applied), 'missing': int(missing)}


def _suv_apply_seam_sets_payload(context, payload, *, target_mode='ACTIVE', merge=True, apply_seams=False, apply_mode='REPLACE', clear_existing=True):
    objects_payload = list((payload or {}).get('objects') or [])
    if not objects_payload:
        return {'targets': 0, 'sets': 0, 'applied': 0, 'skipped': 0, 'edges': 0}

    selected_meshes = [obj for obj in _selected_mesh_objects(context) if getattr(obj, 'type', None) == 'MESH']
    active = _active_mesh_obj(context)
    target_mode = str(target_mode or 'ACTIVE').upper()
    if target_mode == 'SELECTED':
        targets = selected_meshes[:] if selected_meshes else ([active] if active else [])
    else:
        targets = [active] if active else []
    targets = [obj for obj in targets if obj is not None]
    if not targets:
        return {'targets': 0, 'sets': 0, 'applied': 0, 'skipped': len(objects_payload), 'edges': 0}

    payload_by_name = {}
    for rec in objects_payload:
        name = str((rec or {}).get('name') or '').strip()
        if name:
            payload_by_name[name] = rec

    applied = 0
    skipped = 0
    sets_written = 0
    edges_applied = 0
    for obj in targets:
        source = payload_by_name.get(getattr(obj, 'name', ''))
        if source is None:
            if len(objects_payload) == 1:
                source = objects_payload[0]
            elif target_mode == 'ACTIVE':
                source = objects_payload[0]
        if source is None:
            skipped += 1
            continue
        incoming = {}
        for key, data in dict((source or {}).get('sets') or {}).items():
            if not isinstance(data, dict):
                continue
            edge_ids = []
            seen = set()
            for value in data.get('edges', []) or []:
                try:
                    idx = int(value)
                except Exception:
                    continue
                if idx < 0 or idx in seen:
                    continue
                seen.add(idx)
                edge_ids.append(idx)
            incoming[str(key)] = {
                'edges': sorted(edge_ids),
                'selected_only': bool(data.get('selected_only', False)),
            }
        if not incoming:
            skipped += 1
            continue
        current = _get_seam_sets(obj) if merge else {}
        if not isinstance(current, dict):
            current = {}
        current.update(incoming)
        _set_seam_sets(obj, current)
        sets_written += len(incoming)
        applied += 1
        if apply_seams:
            first_name = next(iter(incoming.keys()), None)
            edge_ids = list((incoming.get(first_name) or {}).get('edges') or []) if first_name else []
            result = _suv_apply_seam_set_to_object(context, obj, edge_ids, apply_mode=apply_mode, clear_existing=clear_existing, select_applied=False)
            if str(result.get('status')) == 'OK':
                edges_applied += int(result.get('applied', 0) or 0)
    return {'targets': len(targets), 'sets': sets_written, 'applied': applied, 'skipped': skipped, 'edges': edges_applied}


class SUV_OT_seam_set_library_io(bpy.types.Operator):
    bl_idname = "uv.suv_seam_set_library_io"
    bl_label = 'Seam Set Library I/O'
    bl_description = "Export or import saved seam sets as Blender Text or JSON files so seam designs can be reused across scenes and repeated assets. / 保存したシームセットを Blender Text や JSON ファイルへ入出力し、シーンや繰り返しアセットをまたいで再利用できるようにします。"
    bl_options = {'UNDO'}

    mode: bpy.props.EnumProperty(
        name="Mode",
        items=[
            ('EXPORT_TEXT', "Export to Text", "Write saved seam sets into a Blender Text datablock / 保存したシームセットを Blender Text に書き出します"),
            ('IMPORT_TEXT', "Import from Text", "Read saved seam sets from a Blender Text datablock / Blender Text から保存したシームセットを読み込みます"),
            ('EXPORT_FILE', "Export to File", "Write saved seam sets into a JSON file / 保存したシームセットを JSON ファイルへ書き出します"),
            ('IMPORT_FILE', "Import from File", "Read saved seam sets from a JSON file / JSON ファイルから保存したシームセットを読み込みます"),
        ],
        default='EXPORT_TEXT',
    )
    scope: bpy.props.EnumProperty(
        name="Scope",
        items=[
            ('ACTIVE', "Active", "Use the active mesh object / アクティブメッシュのみを対象にします"),
            ('SELECTED', "Selected", "Use all selected mesh objects / 選択メッシュ全体を対象にします"),
        ],
        default='ACTIVE',
    )
    text_name: bpy.props.StringProperty(name="Text Name", default="SUV_Seam_Sets")
    filepath: bpy.props.StringProperty(name="Filepath", default="", subtype='FILE_PATH')
    filter_glob: bpy.props.StringProperty(default="*.json", options={'HIDDEN'})
    merge: bpy.props.BoolProperty(name="Merge", default=True, description="Keep existing seam sets and add imported ones on top / 既存シームセットを残したまま読み込みセットを追加します")
    apply_seams: bpy.props.BoolProperty(name="Apply First Imported Set", default=False, description="Also apply the first imported seam set on each target / 読み込んだ先頭シームセットを各対象にそのまま適用します")
    apply_mode: bpy.props.EnumProperty(name="Apply Mode", items=[('REPLACE', "Replace", "Replace seam state with the imported set / 読み込みセットで現在のシーム状態を置き換えます"), ('ADD', "Add", "Add imported seams on top of the current seam state / 現在のシーム状態へ追加します"), ('SUB', "Subtract", "Clear imported edges from the current seam state / 読み込みエッジ分だけシーム解除します")], default='REPLACE')
    clear_existing: bpy.props.BoolProperty(name="Clear Existing on Replace", default=True)

    def invoke(self, context, event):
        if self.mode in {'EXPORT_FILE', 'IMPORT_FILE'}:
            if not self.filepath:
                base = os.path.splitext(bpy.path.basename(bpy.data.filepath))[0] if getattr(bpy.data, 'filepath', '') else 'uv_suite'
                suffix = 'seam_sets_export' if self.mode == 'EXPORT_FILE' else 'seam_sets_import'
                self.filepath = bpy.path.ensure_ext(f"{base}_{suffix}", '.json')
            context.window_manager.fileselect_add(self)
            return {'RUNNING_MODAL'}
        return self.execute(context)

    def execute(self, context):
        if self.mode.startswith('EXPORT'):
            if self.scope == 'SELECTED':
                objects = _selected_mesh_objects(context)
            else:
                active = _active_mesh_obj(context)
                objects = [active] if active else []
            payload = _suv_seam_sets_payload(objects)
            if not payload.get('objects'):
                self.report({'WARNING'}, 'No saved seam sets found to export')
                return {'CANCELLED'}
            data = json.dumps(payload, indent=2, ensure_ascii=False, sort_keys=True)
            if self.mode == 'EXPORT_TEXT':
                txt = _suv_text_block(self.text_name or 'SUV_Seam_Sets', clear=True)
                txt.write(data)
                self.report({'INFO'}, f'Seam sets exported to text: {txt.name}')
                return {'FINISHED'}
            path = bpy.path.abspath(self.filepath) if self.filepath else ''
            if not path:
                self.report({'WARNING'}, 'No export filepath specified')
                return {'CANCELLED'}
            os.makedirs(os.path.dirname(path), exist_ok=True) if os.path.dirname(path) else None
            with open(path, 'w', encoding='utf-8') as handle:
                handle.write(data)
            self.report({'INFO'}, f'Seam sets exported: {path}')
            return {'FINISHED'}

        if self.mode == 'IMPORT_TEXT':
            txt = bpy.data.texts.get(self.text_name or '')
            if txt is None:
                self.report({'WARNING'}, f'Text not found: {self.text_name}')
                return {'CANCELLED'}
            raw = txt.as_string()
            source_label = txt.name
        else:
            path = bpy.path.abspath(self.filepath) if self.filepath else ''
            if not path or not os.path.isfile(path):
                self.report({'WARNING'}, f'JSON file not found: {path or self.filepath}')
                return {'CANCELLED'}
            with open(path, 'r', encoding='utf-8') as handle:
                raw = handle.read()
            source_label = path
        try:
            payload = json.loads(raw)
        except Exception as exc:
            self.report({'WARNING'}, f'Invalid seam set JSON: {exc}')
            return {'CANCELLED'}
        if str(payload.get('format', '')) != 'uv_suite_seam_sets':
            self.report({'WARNING'}, 'Unsupported seam set format')
            return {'CANCELLED'}
        stats = _suv_apply_seam_sets_payload(context, payload, target_mode=self.scope, merge=self.merge, apply_seams=self.apply_seams, apply_mode=self.apply_mode, clear_existing=self.clear_existing)
        self.report({'INFO'}, f"Imported seam sets from {source_label} (targets={stats['applied']}, sets={stats['sets']}, applied_edges={stats['edges']}, skipped={stats['skipped']})")
        return {'FINISHED'}


class SUV_OT_seam_set_transfer(bpy.types.Operator):
    bl_idname = "uv.suv_seam_set_transfer"
    bl_label = 'Transfer Seam Set'
    bl_description = "Copy a saved seam set from the active mesh to the other selected meshes so repeated assets can reuse the same seam design slot. / アクティブメッシュの保存済みシームセットを他の選択メッシュへコピーし、繰り返しアセットでも同じシーム設計スロットを再利用できるようにします。"
    bl_options = {'UNDO'}

    set_name: bpy.props.EnumProperty(name="Set", items=_seam_sets_enum_items, default=0)
    overwrite: bpy.props.BoolProperty(name="Overwrite", default=True)
    apply_to_targets: bpy.props.BoolProperty(name="Apply on Targets", default=False)
    apply_mode: bpy.props.EnumProperty(name="Apply Mode", items=[('REPLACE', "Replace", "Replace current seams with the transferred set / 現在のシームを転送セットで置き換えます"), ('ADD', "Add", "Add transferred seams on top of current seams / 現在のシームへ追加します")], default='REPLACE')

    def execute(self, context):
        src = _active_mesh_obj(context)
        if not src:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        if self.set_name == '__NONE__':
            self.report({'WARNING'}, tr(context, "msg.no_selection"))
            return {'CANCELLED'}
        source_sets = _get_seam_sets(src)
        if self.set_name not in source_sets:
            self.report({'WARNING'}, tr(context, "msg.set_missing", name=self.set_name))
            return {'CANCELLED'}
        record = source_sets.get(self.set_name) or {}
        edge_ids = sorted({int(v) for v in (record.get('edges') or []) if isinstance(v, int) or (isinstance(v, str) and str(v).isdigit())})
        targets = [obj for obj in _selected_mesh_objects(context) if obj != src]
        if not targets:
            self.report({'WARNING'}, 'No target meshes selected')
            return {'CANCELLED'}
        copied = 0
        skipped = 0
        applied_edges = 0
        for obj in targets:
            edge_count = len(getattr(getattr(obj, 'data', None), 'edges', []) or [])
            if edge_ids and edge_count <= max(edge_ids):
                skipped += 1
                continue
            d = _get_seam_sets(obj)
            if (self.set_name in d) and (not self.overwrite):
                skipped += 1
                continue
            d[self.set_name] = {'edges': list(edge_ids), 'selected_only': bool(record.get('selected_only', False))}
            _set_seam_sets(obj, d)
            copied += 1
            if self.apply_to_targets:
                result = _suv_apply_seam_set_to_object(context, obj, edge_ids, apply_mode=self.apply_mode, clear_existing=(self.apply_mode == 'REPLACE'), select_applied=False)
                if str(result.get('status')) == 'OK':
                    applied_edges += int(result.get('applied', 0) or 0)
        self.report({'INFO'}, f'Transferred seam set {self.set_name} to {copied} target(s), applied_edges={applied_edges}, skipped={skipped}')
        return {'FINISHED'}


class SUV_OT_seam_set_save(bpy.types.Operator):
    bl_idname = "uv.suv_seam_set_save"
    bl_label = 'Save Seam Set'
    bl_description = "Save the current seam design into a reusable slot so the same seam state can be recalled later. / 現在のシーム設計を再利用できるスロットへ保存し、あとで同じシーム状態を呼び出せるようにします。"
    bl_options = {'UNDO'}

    set_name: bpy.props.StringProperty(name="Set Name", default="MySeams")
    overwrite: bpy.props.BoolProperty(name="Overwrite", default=True)
    selected_only: bpy.props.BoolProperty(name="Selected Seam Edges Only", default=False, description="Store only seam edges that are currently selected / 現在選択中のシームエッジだけ保存します")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        edge_ids = _suv_current_seam_edges(context, obj, selected_only=self.selected_only)
        if not edge_ids:
            self.report({'WARNING'}, tr(context, "msg.no_selection"))
            return {'CANCELLED'}
        d = _get_seam_sets(obj)
        if (self.set_name in d) and (not self.overwrite):
            self.report({'WARNING'}, tr(context, "msg.op_failed", e="Seam set exists"))
            return {'CANCELLED'}
        d[self.set_name] = {"edges": edge_ids, "selected_only": bool(self.selected_only)}
        _set_seam_sets(obj, d)
        self.report({'INFO'}, f'Seam set saved: {self.set_name} ({len(edge_ids)} edges)')
        return {'FINISHED'}


class SUV_OT_seam_set_recall(bpy.types.Operator):
    bl_idname = "uv.suv_seam_set_recall"
    bl_label = 'Recall Seam Set'
    bl_description = "Recall a previously saved seam set and apply it back onto the active mesh. / 以前保存したシームセットを呼び出し、アクティブメッシュへ再適用します。"
    bl_options = {'UNDO'}

    set_name: bpy.props.EnumProperty(name="Set", items=_seam_sets_enum_items, default=0)
    apply_mode: bpy.props.EnumProperty(name="Apply Mode", items=[('REPLACE', "Replace", "Replace current seams with the saved set / 現在のシームを保存セットで置き換えます"), ('ADD', "Add", "Add the saved set on top of current seams / 現在のシームへ追加します"), ('SUB', "Subtract", "Clear the saved edges from current seams / 保存セットのエッジ分だけシーム解除します")], default='REPLACE')
    select_applied: bpy.props.BoolProperty(name="Select Applied Edges", default=False)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        if self.set_name == '__NONE__':
            self.report({'WARNING'}, tr(context, "msg.no_selection"))
            return {'CANCELLED'}
        d = _get_seam_sets(obj)
        if self.set_name not in d:
            self.report({'WARNING'}, tr(context, "msg.set_missing", name=self.set_name))
            return {'CANCELLED'}
        result = _suv_apply_seam_set_to_object(context, obj, (d[self.set_name] or {}).get('edges', []), apply_mode=self.apply_mode, clear_existing=(self.apply_mode == 'REPLACE'), select_applied=self.select_applied)
        if str(result.get('status')) != 'OK':
            self.report({'WARNING'}, tr(context, "msg.op_failed", e=result.get('status', 'Unknown')))
            return {'CANCELLED'}
        self.report({'INFO'}, f'Seam set applied: {self.set_name} ({int(result.get("applied", 0))} edges)')
        return {'FINISHED'}


class SUV_OT_seam_set_update(bpy.types.Operator):
    bl_idname = "uv.suv_seam_set_update"
    bl_label = 'Update Seam Set'
    bl_description = "Update an existing saved seam set with the current seam state. / 既存の保存シームセットを現在のシーム状態で更新します。"
    bl_options = {'UNDO'}

    set_name: bpy.props.EnumProperty(name="Set", items=_seam_sets_enum_items, default=0)
    selected_only: bpy.props.BoolProperty(name="Selected Seam Edges Only", default=False)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        if self.set_name == '__NONE__':
            self.report({'WARNING'}, tr(context, "msg.no_selection"))
            return {'CANCELLED'}
        d = _get_seam_sets(obj)
        if self.set_name not in d:
            self.report({'WARNING'}, tr(context, "msg.set_missing", name=self.set_name))
            return {'CANCELLED'}
        edge_ids = _suv_current_seam_edges(context, obj, selected_only=self.selected_only)
        if not edge_ids:
            self.report({'WARNING'}, tr(context, "msg.no_selection"))
            return {'CANCELLED'}
        d[self.set_name] = {"edges": edge_ids, "selected_only": bool(self.selected_only)}
        _set_seam_sets(obj, d)
        self.report({'INFO'}, f'Seam set updated: {self.set_name} ({len(edge_ids)} edges)')
        return {'FINISHED'}


class SUV_OT_seam_set_delete(bpy.types.Operator):
    bl_idname = "uv.suv_seam_set_delete"
    bl_label = 'Delete Seam Set'
    bl_description = "Delete a saved seam set you no longer need. / 不要になった保存シームセットを削除します。"
    bl_options = {'UNDO'}

    set_name: bpy.props.EnumProperty(name="Set", items=_seam_sets_enum_items, default=0)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        if self.set_name == '__NONE__':
            self.report({'WARNING'}, tr(context, "msg.no_selection"))
            return {'CANCELLED'}
        d = _get_seam_sets(obj)
        set_name = self.set_name
        if set_name in d:
            d.pop(set_name, None)
            _set_seam_sets(obj, d)
            self.report({'INFO'}, f'Seam set deleted: {set_name}')
            return {'FINISHED'}
        self.report({'WARNING'}, tr(context, "msg.set_missing", name=self.set_name))
        return {'CANCELLED'}


def _suv_current_layout_snapshot(context, obj, *, source_layer_mode='ACTIVE', source_layer_name=''):
    me = getattr(obj, 'data', None)
    layers = getattr(me, 'uv_layers', None) if me is not None else None
    if me is None or layers is None:
        return None
    with _TempMode(context, obj, 'OBJECT') as tm:
        if not getattr(tm, 'enter_ok', True):
            return None
        try:
            layer = layers.active if len(layers) else None
        except Exception:
            layer = None
        mode = str(source_layer_mode or 'ACTIVE').upper()
        if mode == 'NAMED' and source_layer_name:
            layer = layers.get(source_layer_name)
        elif mode == 'RENDER':
            try:
                layer = next((uv for uv in layers if bool(getattr(uv, 'active_render', False))), layer)
            except Exception:
                pass
        if layer is None and len(layers):
            try:
                layer = layers[0]
            except Exception:
                layer = None
        if layer is None:
            return None
        data_rows = []
        try:
            seq = layer.data
        except Exception:
            seq = []
        for elem in seq:
            item = {'uv': (float(elem.uv.x), float(elem.uv.y))}
            for attr in ('pin_uv', 'select', 'select_edge'):
                if hasattr(elem, attr):
                    try:
                        item[attr] = bool(getattr(elem, attr))
                    except Exception:
                        pass
            data_rows.append(item)
        return {
            'layer_name': str(getattr(layer, 'name', '') or ''),
            'vertex_count': int(len(getattr(me, 'vertices', []) or [])),
            'polygon_count': int(len(getattr(me, 'polygons', []) or [])),
            'loop_count': int(len(data_rows)),
            'data': data_rows,
        }


def _suv_resolve_layout_target_layer(obj, snapshot, *, target_layer_mode='ACTIVE', target_layer_name=''):
    me = getattr(obj, 'data', None)
    layers = getattr(me, 'uv_layers', None) if me is not None else None
    if me is None or layers is None:
        return None
    mode = str(target_layer_mode or 'ACTIVE').upper()
    desired_name = str(target_layer_name or '').strip()
    source_name = str((snapshot or {}).get('layer_name', '') or '').strip()
    if len(layers) == 0:
        try:
            return layers.new(name=(desired_name or source_name or 'UVMap'))
        except Exception:
            return None
    if mode == 'NAMED':
        name = desired_name or source_name or 'UVMap'
        layer = layers.get(name)
        if layer is None:
            try:
                layer = layers.new(name=name)
            except Exception:
                layer = None
        return layer
    if mode == 'SOURCE':
        if source_name:
            layer = layers.get(source_name)
            if layer is not None:
                return layer
            try:
                return layers.new(name=source_name)
            except Exception:
                pass
    try:
        return layers.active or layers[0]
    except Exception:
        return None


def _suv_apply_layout_set_to_object(context, obj, snapshot, *, target_layer_mode='ACTIVE', target_layer_name='', set_active=True):
    if not isinstance(snapshot, dict):
        return {'status': 'INVALID_SNAPSHOT', 'applied': 0, 'missing': 0}
    data_rows = list(snapshot.get('data') or [])
    if not data_rows:
        return {'status': 'EMPTY_SNAPSHOT', 'applied': 0, 'missing': 0}
    me = getattr(obj, 'data', None)
    if me is None:
        return {'status': 'NO_MESH', 'applied': 0, 'missing': 0}
    with _TempMode(context, obj, 'OBJECT') as tm:
        if not getattr(tm, 'enter_ok', True):
            return {'status': str(getattr(tm, 'last_error', '') or 'MODE_FAIL'), 'applied': 0, 'missing': 0}
        layer = _suv_resolve_layout_target_layer(obj, snapshot, target_layer_mode=target_layer_mode, target_layer_name=target_layer_name)
        if layer is None:
            return {'status': 'NO_TARGET_LAYER', 'applied': 0, 'missing': 0}
        try:
            dst_data = layer.data
        except Exception:
            return {'status': 'NO_LAYER_DATA', 'applied': 0, 'missing': 0}
        expected = int(snapshot.get('loop_count', len(data_rows)) or len(data_rows))
        if len(dst_data) != expected or len(dst_data) != len(data_rows):
            return {'status': 'TOPOLOGY_MISMATCH', 'applied': 0, 'missing': abs(len(dst_data) - len(data_rows))}
        applied = 0
        for i, src in enumerate(data_rows):
            dst = dst_data[i]
            try:
                dst.uv = Vector(tuple(src.get('uv', (0.0, 0.0))))
            except Exception:
                pass
            for attr in ('pin_uv', 'select', 'select_edge'):
                if attr in src and hasattr(dst, attr):
                    try:
                        setattr(dst, attr, bool(src.get(attr, False)))

                    except Exception:
                        pass
            applied += 1
        if set_active:
            try:
                me.uv_layers.active = layer
            except Exception:
                pass
        return {'status': 'OK', 'applied': int(applied), 'missing': 0, 'layer_name': str(getattr(layer, 'name', '') or '')}


def _suv_layout_sets_payload(objects):
    payload_objects = []
    for obj in objects or []:
        if not obj or getattr(obj, 'type', None) != 'MESH':
            continue
        sets_dict = _get_layout_sets(obj)
        if not isinstance(sets_dict, dict) or not sets_dict:
            continue
        clean_sets = {}
        for key, rec in sets_dict.items():
            if not isinstance(rec, dict):
                continue
            snap = rec.get('snapshot') if isinstance(rec.get('snapshot'), dict) else rec
            data_rows = []
            for row in list((snap or {}).get('data') or []):
                if not isinstance(row, dict):
                    continue
                uv = row.get('uv', (0.0, 0.0))
                try:
                    uv_pair = (float(uv[0]), float(uv[1]))
                except Exception:
                    uv_pair = (0.0, 0.0)
                item = {'uv': uv_pair}
                for attr in ('pin_uv', 'select', 'select_edge'):
                    if attr in row:
                        item[attr] = bool(row.get(attr, False))
                data_rows.append(item)
            if not data_rows:
                continue
            clean_sets[str(key)] = {
                'snapshot': {
                    'layer_name': str((snap or {}).get('layer_name', '') or ''),
                    'vertex_count': int((snap or {}).get('vertex_count', 0) or 0),
                    'polygon_count': int((snap or {}).get('polygon_count', 0) or 0),
                    'loop_count': int((snap or {}).get('loop_count', len(data_rows)) or len(data_rows)),
                    'data': data_rows,
                }
            }
        if not clean_sets:
            continue
        payload_objects.append({
            'name': getattr(obj, 'name', 'Object'),
            'layout_sets': clean_sets,
        })
    return {
        'format': 'uv_suite_layout_sets',
        'version': 1,
        'objects': payload_objects,
    }


def _suv_apply_layout_sets_payload(context, payload, *, target_mode='ACTIVE', merge=True, apply_layout=False, target_layer_mode='ACTIVE', target_layer_name=''):
    objects_payload = list((payload or {}).get('objects') or [])
    if not objects_payload:
        return {'targets': 0, 'sets': 0, 'applied': 0, 'skipped': 0, 'loops': 0}

    selected_meshes = [obj for obj in _selected_mesh_objects(context) if getattr(obj, 'type', None) == 'MESH']
    active = _active_mesh_obj(context)
    target_mode = str(target_mode or 'ACTIVE').upper()
    if target_mode == 'SELECTED':
        targets = selected_meshes[:] if selected_meshes else ([active] if active else [])
    else:
        targets = [active] if active else []
    targets = [obj for obj in targets if obj is not None]
    if not targets:
        return {'targets': 0, 'sets': 0, 'applied': 0, 'skipped': len(objects_payload), 'loops': 0}

    payload_by_name = {}
    for rec in objects_payload:
        name = str((rec or {}).get('name') or '').strip()
        if name:
            payload_by_name[name] = rec

    applied = 0
    skipped = 0
    sets_written = 0
    loops_applied = 0
    for obj in targets:
        source = payload_by_name.get(getattr(obj, 'name', ''))
        if source is None:
            if len(objects_payload) == 1:
                source = objects_payload[0]
            elif target_mode == 'ACTIVE':
                source = objects_payload[0]
        if source is None:
            skipped += 1
            continue
        incoming = {}
        for key, rec in dict((source or {}).get('layout_sets') or {}).items():
            snap = rec.get('snapshot') if isinstance(rec, dict) else None
            if not isinstance(snap, dict):
                continue
            data_rows = []
            for row in list(snap.get('data') or []):
                if not isinstance(row, dict):
                    continue
                uv = row.get('uv', (0.0, 0.0))
                try:
                    uv_pair = (float(uv[0]), float(uv[1]))
                except Exception:
                    uv_pair = (0.0, 0.0)
                item = {'uv': uv_pair}
                for attr in ('pin_uv', 'select', 'select_edge'):
                    if attr in row:
                        item[attr] = bool(row.get(attr, False))
                data_rows.append(item)
            if not data_rows:
                continue
            incoming[str(key)] = {
                'snapshot': {
                    'layer_name': str(snap.get('layer_name', '') or ''),
                    'vertex_count': int(snap.get('vertex_count', 0) or 0),
                    'polygon_count': int(snap.get('polygon_count', 0) or 0),
                    'loop_count': int(snap.get('loop_count', len(data_rows)) or len(data_rows)),
                    'data': data_rows,
                }
            }
        if not incoming:
            skipped += 1
            continue
        current = _get_layout_sets(obj) if merge else {}
        if not isinstance(current, dict):
            current = {}
        current.update(incoming)
        _set_layout_sets(obj, current)
        sets_written += len(incoming)
        applied += 1
        if apply_layout:
            first_name = next(iter(incoming.keys()), None)
            snap = ((incoming.get(first_name) or {}).get('snapshot') or {}) if first_name else {}
            result = _suv_apply_layout_set_to_object(context, obj, snap, target_layer_mode=target_layer_mode, target_layer_name=target_layer_name, set_active=True)
            if str(result.get('status')) == 'OK':
                loops_applied += int(result.get('applied', 0) or 0)
    return {'targets': len(targets), 'sets': sets_written, 'applied': applied, 'skipped': skipped, 'loops': loops_applied}


class SUV_OT_layout_set_library_io(bpy.types.Operator):
    bl_idname = "uv.suv_layout_set_library_io"
    bl_label = 'Layout Set Library I/O'
    bl_description = "Export or import saved UV layout sets as Blender Text or JSON files so full UV placements can be reused across scenes and repeated assets. / 保存した UV レイアウトセットを Blender Text や JSON ファイルへ入出力し、シーンや繰り返しアセットをまたいで再利用できるようにします。"
    bl_options = {'UNDO'}

    mode: bpy.props.EnumProperty(
        name="Mode",
        items=[
            ('EXPORT_TEXT', "Export to Text", "Write saved layout sets into a Blender Text datablock / 保存したレイアウトセットを Blender Text に書き出します"),
            ('IMPORT_TEXT', "Import from Text", "Read saved layout sets from a Blender Text datablock / Blender Text から保存したレイアウトセットを読み込みます"),
            ('EXPORT_FILE', "Export to File", "Write saved layout sets into a JSON file / 保存したレイアウトセットを JSON ファイルへ書き出します"),
            ('IMPORT_FILE', "Import from File", "Read saved layout sets from a JSON file / JSON ファイルから保存したレイアウトセットを読み込みます"),
        ],
        default='EXPORT_TEXT',
    )
    scope: bpy.props.EnumProperty(
        name="Scope",
        items=[
            ('ACTIVE', "Active", "Use the active mesh object / アクティブメッシュのみを対象にします"),
            ('SELECTED', "Selected", "Use all selected mesh objects / 選択メッシュ全体を対象にします"),
        ],
        default='ACTIVE',
    )
    text_name: bpy.props.StringProperty(name="Text Name", default="SUV_Layout_Sets")
    filepath: bpy.props.StringProperty(name="Filepath", default="", subtype='FILE_PATH')
    filter_glob: bpy.props.StringProperty(default="*.json", options={'HIDDEN'})
    merge: bpy.props.BoolProperty(name="Merge", default=True, description="Keep existing layout sets and add imported ones on top / 既存レイアウトセットを残したまま読み込みセットを追加します")
    apply_layout: bpy.props.BoolProperty(name="Apply First Imported Layout", default=False, description="Also apply the first imported layout set on each target / 読み込んだ先頭レイアウトセットを各対象にそのまま適用します")
    target_layer_mode: bpy.props.EnumProperty(name="Target UV", items=[('ACTIVE', "Active UV", "Apply onto the current active UV layer / 現在のアクティブUVへ適用します"), ('SOURCE', "Source Layer Name", "Use the saved source UV layer name when possible / 保存時のUVレイヤー名を優先して適用します"), ('NAMED', "Named UV", "Apply onto a named UV layer, creating it when needed / 指定名のUVへ適用し、必要なら作成します")], default='ACTIVE')
    target_layer_name: bpy.props.StringProperty(name="Target UV Name", default="")

    def invoke(self, context, event):
        if self.mode in {'EXPORT_FILE', 'IMPORT_FILE'}:
            if not self.filepath:
                base = os.path.splitext(bpy.path.basename(bpy.data.filepath))[0] if getattr(bpy.data, 'filepath', '') else 'uv_suite'
                suffix = 'layout_sets_export' if self.mode == 'EXPORT_FILE' else 'layout_sets_import'
                self.filepath = bpy.path.ensure_ext(f"{base}_{suffix}", '.json')
            context.window_manager.fileselect_add(self)
            return {'RUNNING_MODAL'}
        return self.execute(context)

    def execute(self, context):
        if self.mode.startswith('EXPORT'):
            if self.scope == 'SELECTED':
                objects = _selected_mesh_objects(context)
            else:
                active = _active_mesh_obj(context)
                objects = [active] if active else []
            payload = _suv_layout_sets_payload(objects)
            if not payload.get('objects'):
                self.report({'WARNING'}, 'No saved layout sets found to export')
                return {'CANCELLED'}
            data = json.dumps(payload, indent=2, ensure_ascii=False, sort_keys=True)
            if self.mode == 'EXPORT_TEXT':
                txt = _suv_text_block(self.text_name or 'SUV_Layout_Sets', clear=True)
                txt.write(data)
                self.report({'INFO'}, f'Layout sets exported to text: {txt.name}')
                return {'FINISHED'}
            path = bpy.path.abspath(self.filepath) if self.filepath else ''
            if not path:
                self.report({'WARNING'}, 'No export filepath specified')
                return {'CANCELLED'}
            os.makedirs(os.path.dirname(path), exist_ok=True) if os.path.dirname(path) else None
            with open(path, 'w', encoding='utf-8') as handle:
                handle.write(data)
            self.report({'INFO'}, f'Layout sets exported: {path}')
            return {'FINISHED'}

        if self.mode == 'IMPORT_TEXT':
            txt = bpy.data.texts.get(self.text_name or '')
            if txt is None:
                self.report({'WARNING'}, f'Text not found: {self.text_name}')
                return {'CANCELLED'}
            raw = txt.as_string()
            source_label = txt.name
        else:
            path = bpy.path.abspath(self.filepath) if self.filepath else ''
            if not path or not os.path.isfile(path):
                self.report({'WARNING'}, f'JSON file not found: {path or self.filepath}')
                return {'CANCELLED'}
            with open(path, 'r', encoding='utf-8') as handle:
                raw = handle.read()
            source_label = path
        try:
            payload = json.loads(raw)
        except Exception as exc:
            self.report({'WARNING'}, f'Invalid layout set JSON: {exc}')
            return {'CANCELLED'}
        if str(payload.get('format', '')) != 'uv_suite_layout_sets':
            self.report({'WARNING'}, 'Unsupported layout set format')
            return {'CANCELLED'}
        stats = _suv_apply_layout_sets_payload(context, payload, target_mode=self.scope, merge=self.merge, apply_layout=self.apply_layout, target_layer_mode=self.target_layer_mode, target_layer_name=self.target_layer_name)
        self.report({'INFO'}, f"Imported layout sets from {source_label} (targets={stats['applied']}, sets={stats['sets']}, applied_loops={stats['loops']}, skipped={stats['skipped']})")
        return {'FINISHED'}


class SUV_OT_layout_set_transfer(bpy.types.Operator):
    bl_idname = "uv.suv_layout_set_transfer"
    bl_label = 'Transfer Layout Set'
    bl_description = "Copy a saved UV layout set from the active mesh to the other selected meshes so repeated assets can reuse the same placement slot. / アクティブメッシュの保存済み UV レイアウトセットを他の選択メッシュへコピーし、繰り返しアセットでも同じ配置スロットを再利用できるようにします。"
    bl_options = {'UNDO'}

    set_name: bpy.props.EnumProperty(name="Set", items=_layout_sets_enum_items, default=0)
    overwrite: bpy.props.BoolProperty(name="Overwrite", default=True)
    apply_to_targets: bpy.props.BoolProperty(name="Apply on Targets", default=False)
    target_layer_mode: bpy.props.EnumProperty(name="Target UV", items=[('ACTIVE', "Active UV", "Apply onto the current active UV layer / 現在のアクティブUVへ適用します"), ('SOURCE', "Source Layer Name", "Use the saved source UV layer name when possible / 保存時のUVレイヤー名を優先して適用します"), ('NAMED', "Named UV", "Apply onto a named UV layer, creating it when needed / 指定名のUVへ適用し、必要なら作成します")], default='ACTIVE')
    target_layer_name: bpy.props.StringProperty(name="Target UV Name", default="")

    def execute(self, context):
        src = _active_mesh_obj(context)
        if not src:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        if self.set_name == '__NONE__':
            self.report({'WARNING'}, tr(context, "msg.no_selection"))
            return {'CANCELLED'}
        source_sets = _get_layout_sets(src)
        if self.set_name not in source_sets:
            self.report({'WARNING'}, tr(context, "msg.set_missing", name=self.set_name))
            return {'CANCELLED'}
        record = source_sets.get(self.set_name) or {}
        snapshot = (record.get('snapshot') if isinstance(record, dict) else None) or {}
        loop_count = int(snapshot.get('loop_count', len(snapshot.get('data') or [])) or 0)
        targets = [obj for obj in _selected_mesh_objects(context) if obj != src]
        if not targets:
            self.report({'WARNING'}, 'No target meshes selected')
            return {'CANCELLED'}
        copied = 0
        skipped = 0
        applied_loops = 0
        for obj in targets:
            me = getattr(obj, 'data', None)
            if me is None or int(len(getattr(me, 'loops', []) or [])) != loop_count:
                skipped += 1
                continue
            d = _get_layout_sets(obj)
            if (self.set_name in d) and (not self.overwrite):
                skipped += 1
                continue
            d[self.set_name] = {'snapshot': snapshot}
            _set_layout_sets(obj, d)
            copied += 1
            if self.apply_to_targets:
                result = _suv_apply_layout_set_to_object(context, obj, snapshot, target_layer_mode=self.target_layer_mode, target_layer_name=self.target_layer_name, set_active=True)
                if str(result.get('status')) == 'OK':
                    applied_loops += int(result.get('applied', 0) or 0)
        self.report({'INFO'}, f'Transferred layout set {self.set_name} to {copied} target(s), applied_loops={applied_loops}, skipped={skipped}')
        return {'FINISHED'}


class SUV_OT_layout_set_save(bpy.types.Operator):
    bl_idname = "uv.suv_layout_set_save"
    bl_label = 'Save Layout Set'
    bl_description = "Save the current active UV layout into a reusable slot so the same UV placement can be recalled later. / 現在のアクティブUVレイアウトを再利用できるスロットへ保存し、あとで同じUV配置を呼び出せるようにします。"
    bl_options = {'UNDO'}

    set_name: bpy.props.StringProperty(name="Set Name", default="MyLayout")
    overwrite: bpy.props.BoolProperty(name="Overwrite", default=True)
    source_layer_mode: bpy.props.EnumProperty(name="Source UV", items=[('ACTIVE', "Active UV", "Capture the current active UV layer / 現在のアクティブUVを保存します"), ('RENDER', "Render UV", "Capture the current render UV layer / 現在のレンダーUVを保存します"), ('NAMED', "Named UV", "Capture a named UV layer / 指定名のUVレイヤーを保存します")], default='ACTIVE')
    source_layer_name: bpy.props.StringProperty(name="Source UV Name", default="")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        snapshot = _suv_current_layout_snapshot(context, obj, source_layer_mode=self.source_layer_mode, source_layer_name=self.source_layer_name)
        if not snapshot or not snapshot.get('data'):
            self.report({'WARNING'}, 'No UV layout data could be captured')
            return {'CANCELLED'}
        d = _get_layout_sets(obj)
        if (self.set_name in d) and (not self.overwrite):
            self.report({'WARNING'}, tr(context, "msg.op_failed", e="Layout set exists"))
            return {'CANCELLED'}
        d[self.set_name] = {'snapshot': snapshot}
        _set_layout_sets(obj, d)
        self.report({'INFO'}, f'Layout set saved: {self.set_name} ({int(snapshot.get("loop_count", 0))} loops)')
        return {'FINISHED'}


class SUV_OT_layout_set_recall(bpy.types.Operator):
    bl_idname = "uv.suv_layout_set_recall"
    bl_label = 'Recall Layout Set'
    bl_description = "Recall a previously saved UV layout set and apply it back onto the active mesh. / 以前保存した UV レイアウトセットを呼び出し、アクティブメッシュへ再適用します。"
    bl_options = {'UNDO'}

    set_name: bpy.props.EnumProperty(name="Set", items=_layout_sets_enum_items, default=0)
    target_layer_mode: bpy.props.EnumProperty(name="Target UV", items=[('ACTIVE', "Active UV", "Apply onto the current active UV layer / 現在のアクティブUVへ適用します"), ('SOURCE', "Source Layer Name", "Use the saved source UV layer name when possible / 保存時のUVレイヤー名を優先して適用します"), ('NAMED', "Named UV", "Apply onto a named UV layer, creating it when needed / 指定名のUVへ適用し、必要なら作成します")], default='ACTIVE')
    target_layer_name: bpy.props.StringProperty(name="Target UV Name", default="")

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        if self.set_name == '__NONE__':
            self.report({'WARNING'}, tr(context, "msg.no_selection"))
            return {'CANCELLED'}
        d = _get_layout_sets(obj)
        if self.set_name not in d:
            self.report({'WARNING'}, tr(context, "msg.set_missing", name=self.set_name))
            return {'CANCELLED'}
        result = _suv_apply_layout_set_to_object(context, obj, (d[self.set_name] or {}).get('snapshot', {}), target_layer_mode=self.target_layer_mode, target_layer_name=self.target_layer_name, set_active=True)
        if str(result.get('status')) != 'OK':
            self.report({'WARNING'}, tr(context, "msg.op_failed", e=result.get('status', 'Unknown')))
            return {'CANCELLED'}
        self.report({'INFO'}, f'Layout set applied: {self.set_name} ({int(result.get("applied", 0))} loops)')
        return {'FINISHED'}


class SUV_OT_layout_set_update(bpy.types.Operator):
    bl_idname = "uv.suv_layout_set_update"
    bl_label = 'Update Layout Set'
    bl_description = "Update an existing saved UV layout set with the current active UV state. / 既存の保存 UV レイアウトセットを現在のアクティブUV状態で更新します。"
    bl_options = {'UNDO'}

    set_name: bpy.props.EnumProperty(name="Set", items=_layout_sets_enum_items, default=0)
    source_layer_mode: bpy.props.EnumProperty(name="Source UV", items=[('ACTIVE', "Active UV", "Capture the current active UV layer / 現在のアクティブUVを保存します"), ('RENDER', "Render UV", "Capture the current render UV layer / 現在のレンダーUVを保存します"), ('NAMED', "Named UV", "Capture a named UV layer / 指定名のUVレイヤーを保存します")], default='ACTIVE')
    source_layer_name: bpy.props.StringProperty(name="Source UV Name", default="")

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        if self.set_name == '__NONE__':
            self.report({'WARNING'}, tr(context, "msg.no_selection"))
            return {'CANCELLED'}
        d = _get_layout_sets(obj)
        if self.set_name not in d:
            self.report({'WARNING'}, tr(context, "msg.set_missing", name=self.set_name))
            return {'CANCELLED'}
        snapshot = _suv_current_layout_snapshot(context, obj, source_layer_mode=self.source_layer_mode, source_layer_name=self.source_layer_name)
        if not snapshot or not snapshot.get('data'):
            self.report({'WARNING'}, 'No UV layout data could be captured')
            return {'CANCELLED'}
        d[self.set_name] = {'snapshot': snapshot}
        _set_layout_sets(obj, d)
        self.report({'INFO'}, f'Layout set updated: {self.set_name} ({int(snapshot.get("loop_count", 0))} loops)')
        return {'FINISHED'}


class SUV_OT_layout_set_delete(bpy.types.Operator):
    bl_idname = "uv.suv_layout_set_delete"
    bl_label = 'Delete Layout Set'
    bl_description = "Delete a saved UV layout set you no longer need. / 不要になった保存 UV レイアウトセットを削除します。"
    bl_options = {'UNDO'}

    set_name: bpy.props.EnumProperty(name="Set", items=_layout_sets_enum_items, default=0)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        if self.set_name == '__NONE__':
            self.report({'WARNING'}, tr(context, "msg.no_selection"))
            return {'CANCELLED'}
        d = _get_layout_sets(obj)
        set_name = self.set_name
        if set_name in d:
            d.pop(set_name, None)
            _set_layout_sets(obj, d)
            self.report({'INFO'}, f'Layout set deleted: {set_name}')
            return {'FINISHED'}
        self.report({'WARNING'}, tr(context, "msg.set_missing", name=self.set_name))
        return {'CANCELLED'}


class SUV_OT_set_save(bpy.types.Operator):
    bl_idname = "uv.suv_set_save"
    bl_label = 'Save Set'
    bl_description = "Save the current workspace or tool settings into a reusable slot. / 現在のワークスペースやツール設定を再利用できるスロットへ保存します。"
    bl_options = {'UNDO'}

    set_name: bpy.props.StringProperty(name="Set Name", default="MySet")
    overwrite: bpy.props.BoolProperty(name="Overwrite", default=True)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        with _TempMode(context, obj, 'EDIT'):
            bm = bmesh.from_edit_mesh(obj.data)
            face_ids = [f.index for f in bm.faces if _suv_face_selected(context, f)]
            if not face_ids:
                self.report({'WARNING'}, tr(context, "msg.no_selection"))
                return {'CANCELLED'}
        d = _get_sets(obj)
        if (self.set_name in d) and (not self.overwrite):
            self.report({'WARNING'}, tr(context, "msg.op_failed", e="Set exists"))
            return {'CANCELLED'}
        d[self.set_name] = {"faces": face_ids}
        _set_sets(obj, d)
        self.report({'INFO'}, tr(context, "msg.set_saved", name=self.set_name))
        return {'FINISHED'}

class SUV_OT_set_recall(bpy.types.Operator):
    bl_idname = "uv.suv_set_recall"
    bl_label = 'Recall Set'
    bl_description = "Recall a previously saved workspace or tool settings slot. / 以前保存したワークスペースやツール設定スロットを呼び出します。"
    bl_options = {'UNDO'}

    set_name: bpy.props.EnumProperty(name="Set", items=_sets_enum_items, default=0)
    apply_mode: bpy.props.EnumProperty(
        name="Apply Mode",
        items=[('REPLACE', "Replace", ""), ('ADD', "Add", ""), ('SUB', "Subtract", "")],
        default='REPLACE'
    )

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        if self.set_name == '__NONE__':
            self.report({'WARNING'}, tr(context, "msg.no_selection"))
            return {'CANCELLED'}
        d = _get_sets(obj)
        if self.set_name not in d:
            self.report({'WARNING'}, tr(context, "msg.set_missing", name=self.set_name))
            return {'CANCELLED'}
        face_ids = set(d[self.set_name].get("faces", []))
        with _TempMode(context, obj, 'EDIT'):
            bm = bmesh.from_edit_mesh(obj.data)
            if self.apply_mode == 'REPLACE':
                for f in bm.faces:
                    _suv_face_select(context, f, False)
            if self.apply_mode == 'SUB':
                for f in bm.faces:
                    if f.index in face_ids:
                        _suv_face_select(context, f, False)
            else:
                for f in bm.faces:
                    if f.index in face_ids:
                        _suv_face_select(context, f, True)
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        self.report({'INFO'}, tr(context, "msg.set_recalled", name=self.set_name))
        return {'FINISHED'}

class SUV_OT_set_update(bpy.types.Operator):
    bl_idname = "uv.suv_set_update"
    bl_label = 'Update Set'
    bl_description = "Update an existing saved settings slot with the current workspace state. / 既存の保存設定スロットを現在のワークスペース状態で更新します。"
    bl_options = {'UNDO'}

    set_name: bpy.props.EnumProperty(name="Set", items=_sets_enum_items, default=0)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        if self.set_name == '__NONE__':
            self.report({'WARNING'}, tr(context, "msg.no_selection"))
            return {'CANCELLED'}
        d = _get_sets(obj)
        if self.set_name not in d:
            self.report({'WARNING'}, tr(context, "msg.set_missing", name=self.set_name))
            return {'CANCELLED'}
        with _TempMode(context, obj, 'EDIT'):
            bm = bmesh.from_edit_mesh(obj.data)
            face_ids = [f.index for f in bm.faces if _suv_face_selected(context, f)]
            if not face_ids:
                self.report({'WARNING'}, tr(context, "msg.no_selection"))
                return {'CANCELLED'}
        d[self.set_name] = {"faces": face_ids}
        _set_sets(obj, d)
        self.report({'INFO'}, tr(context, "msg.set_saved", name=self.set_name))
        return {'FINISHED'}

class SUV_OT_set_delete(bpy.types.Operator):
    bl_idname = "uv.suv_set_delete"
    bl_label = 'Delete Set'
    bl_description = "Delete a saved settings slot you no longer need. / 不要になった保存設定スロットを削除します。"
    bl_options = {'UNDO'}

    set_name: bpy.props.EnumProperty(name="Set", items=_sets_enum_items, default=0)

    def execute(self, context):
        obj = _active_mesh_obj(context)
        if not obj:
            self.report({'WARNING'}, tr(context, "msg.no_active_mesh"))
            return {'CANCELLED'}
        if self.set_name == '__NONE__':
            self.report({'WARNING'}, tr(context, "msg.no_selection"))
            return {'CANCELLED'}
        d = _get_sets(obj)
        set_name = self.set_name
        if set_name in d:
            d.pop(set_name, None)
            _set_sets(obj, d)
            self.report({'INFO'}, tr(context, "msg.set_deleted", name=set_name))
            return {'FINISHED'}
        self.report({'WARNING'}, tr(context, "msg.set_missing", name=self.set_name))
        return {'CANCELLED'}

