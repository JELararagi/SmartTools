"""Implement the island stretch public UV operations."""


def island_stretch_uv_toggle(context, op):
    space = context.space_data
    if context.area is None or context.area.ui_type != 'UV' or space is None:
        return False
    editor = space.uv_editor
    editor.show_stretch = not editor.show_stretch
    context.area.tag_redraw()
    return True


def build_handlers(api):
    return {

        "smart_uv_suite.island_stretch_uv_toggle": api.Handler(island_stretch_uv_toggle, 'Toggle the UV stretch overlay.', 'UVの歪み表示を切り替えます。'),

    }
