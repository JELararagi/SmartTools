from . import status_hub as _prev

_IGNORE_KEYS = {
    '__name__', '__package__', '__loader__', '__spec__', '__file__', '__cached__', '__builtins__'
}
globals().update({k: v for k, v in _prev.__dict__.items() if k not in _IGNORE_KEYS})

try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
except Exception:
    pass

_TEXT.update({
    "ui.section.tooltip_help": ("Action Details", "操作詳細"),
    "ui.tooltip_help.hint": (
        "Major management and repair operators now include richer bilingual guidance directly in their tooltips.",
        "主要な管理・修復オペレーターには、より詳しい日英ツールチップ案内を追加しています。",
    ),
})

for _cls_name, _desc_pair in {

    'SUV_OT_apply_layout_preset': (
        "Apply a layout preset that switches multiple placement, packing or review-oriented options together for a repeatable finishing pass.",
        "複数の配置、パック、確認向け設定をまとめて切り替えるレイアウトプリセットを適用し、再現性の高い仕上げ工程を作ります。",
    ),
    'SUV_OT_apply_named_layout_library': (
        "Apply a saved named layout library entry so a known arrangement style can be recalled without rebuilding the layout rules by hand.",
        "保存済みの名前付きレイアウトライブラリエントリを適用し、既知の配置スタイルを手作業で組み直さずに呼び出せるようにします。",
    ),
    'SUV_OT_auto_unwrap_pro': (
        "Run the guided automatic unwrap pipeline so seam creation, unwrap, relax and packing can start from one bundled action.",
        "ガイド付き自動展開パイプラインを実行し、シーム作成、展開、リラックス、パックを1つの流れから始められるようにします。",
    ),
    'SUV_OT_smart_seams': (
        "Mark seams with the suite's smart seam strategy so a quicker first cut can be made before manual refinement.",
        "ツールセットのスマートシーム方針でシームを付け、手動調整前の初回切り分けを素早く行えるようにします。",
    ),
    'SUV_OT_clear_pins': (
        "Clear pinned UV points from the current working target when a fresh unwrap or relax pass should ignore older pin constraints.",
        "古いピン制約を無視して新しく展開やリラックスを行いたいときに、現在の作業対象からピン止めを解除します。",
    ),
    'SUV_OT_clear_seams': (
        "Clear seam marks from the current mesh when you want to restart the cut plan from a cleaner state.",
        "切り分け計画をよりクリーンな状態からやり直したいときに、現在メッシュのシームマークを解除します。",
    ),
    'SUV_OT_create_checker_material': (
        "Assign a checker material so distortion, scale consistency and island coverage can be reviewed more visually.",
        "歪み、スケール一貫性、アイランドの範囲をより視覚的に確認できるよう、チェッカーマテリアルを割り当てます。",
    ),
    'SUV_OT_remove_checker_materials': (
        "Remove helper checker materials after review so the working scene returns to its normal shading state.",
        "確認後に補助チェッカーマテリアルを取り除き、作業シーンを通常の表示状態へ戻します。",
    ),
    'SUV_OT_visualize_stretch_heatmap': (
        "Show a stretch heatmap overlay so areas with stronger UV distortion become easier to spot before repair or repack work.",
        "歪みの強い領域を修復や再パック前に見つけやすくするため、ストレッチヒートマップ表示を有効にします。",
    ),
    'SUV_OT_clear_stretch_heatmap': (
        "Clear the helper stretch heatmap view when you want to return to the regular review display.",
        "通常の確認表示へ戻したいときに、補助ストレッチヒートマップ表示を解除します。",
    ),
    'SUV_OT_toggle_live_unwrap': (
        "Toggle live unwrap so edits reactively update the UV result while you move seams, pins or vertices.",
        "シーム、ピン、頂点の編集に応じてUV結果を反応的に更新できるよう、ライブ展開を切り替えます。",
    ),
    'SUV_OT_open_diagnostics_text': (
        "Open the diagnostics text block so the current validation and troubleshooting notes can be inspected inside Blender.",
        "現在の検証内容やトラブルシュート記録をBlender内で確認できるよう、診断テキストを開きます。",
    ),
    'SUV_OT_collect_support_bundle': (
        "Collect a support bundle that gathers relevant tool_runtime details for troubleshooting or reporting persistent workflow problems.",
        "継続的なワークフロー問題の調査や報告に必要な実行情報をまとめたサポートバンドルを収集します。",
    ),
    'SUV_OT_write_support_bundle': (
        "Write the gathered support bundle to a readable output so the environment and workflow state can be reviewed outside the panel.",
        "収集したサポートバンドルを読みやすい出力へ書き出し、環境とワークフロー状態をパネル外でも確認できるようにします。",
    ),
    'SUV_OT_apply_workflow_bundle': (
        "Apply a bundled workflow profile that changes several related settings together so a known production pattern can be recalled with fewer manual steps.",
        "複数の関連設定をまとめて切り替えるワークフローバンドルを適用し、既知の制作パターンを少ない手数で呼び出せるようにします。",
    ),
    'SUV_OT_apply_workflow_recipe': (
        "Apply a guided workflow recipe intended as a safer starting route for a specific task such as organic unwrap, hard-surface cleanup or atlas preparation.",
        "有機展開、ハードサーフェス整理、アトラス準備など特定作業向けの安全寄り開始ルートとして、ガイド付きワークフローレシピを適用します。",
    ),
    'SUV_OT_validate_workflow_assets': (
        "Validate the current helper assets, presets and references used by the workflow layer so missing support files are easier to catch before work starts.",
        "ワークフロー層で使う補助アセット、プリセット、参照の状態を検証し、作業開始前に不足ファイルや欠損を見つけやすくします。",
    ),
    'SUV_OT_apply_external_compat_target': (
        "Apply an external-tool compatibility target so names, layout helpers or role preparation can better match a chosen workflow style without changing everything manually.",
        "Smart UV Suite互換ターゲットを適用し、命名、レイアウト補助、役割準備を選んだワークフロースタイルへ近づけ、手動調整を減らします。",
    ),
    'SUV_OT_external_compat_report': (
        "Generate a readable report that summarizes how the current working state aligns with the selected external compatibility target.",
        "現在の作業状態が選択した外部互換ターゲットとどの程度揃っているかを、読みやすいレポートとしてまとめます。",
    ),
    'SUV_OT_preset_library_io': (
        "Import or export preset-library data so workflow, layout and helper presets can be shared or backed up without digging into raw files.",
        "プリセットライブラリの入出力を行い、ワークフロー、レイアウト、補助プリセットを生ファイルを追わずに共有・バックアップできるようにします。",
    ),
    'SUV_OT_apply_seam_profile': (
        "Apply a seam profile that reuses saved seam rules or thresholds so the current model can follow a more repeatable cut strategy.",
        "保存済みのシーム規則やしきい値を持つシームプロファイルを適用し、現在モデルをより再現性の高い切り分け方針へ寄せます。",
    ),
    'SUV_OT_batch_apply_seam_profile': (
        "Apply the selected seam profile across multiple compatible objects so a repeated asset group follows the same cutting rules.",
        "選択したシームプロファイルを複数の互換オブジェクトへ一括適用し、反復アセット群が同じ切り分け規則に従うようにします。",
    ),
    'SUV_OT_density_guard_normalize': (
        "Normalize texel density while protecting the current layout intent as much as possible, making late-stage density fixes less disruptive.",
        "現在のレイアウト意図をできるだけ守りながらテクセル密度を正規化し、後工程での密度修正を崩しにくくします。",
    ),
    'SUV_OT_priority_density_pack': (
        "Pack shells while respecting relative density priorities so more important islands keep resolution where possible during final space optimization.",
        "相対的な密度優先度を尊重しながらシェルをパックし、最終的な空間最適化でも重要なアイランドの解像度を保ちやすくします。",
    ),
    'SUV_OT_layout_autoheal': (
        "Attempt a broader layout repair pass that targets common packing and placement issues before another review or export step.",
        "再確認や書き出し前に、よくあるパック・配置問題を対象に、より広いレイアウト修復を試みます。",
    ),
    'SUV_OT_layout_audit_relayout': (
        "Rebuild layout from the current audit view so the next arrangement starts from the detected shell state rather than older assumptions.",
        "現在の監査結果を基にレイアウトを組み直し、古い前提ではなく検出済みシェル状態から次の配置を始められるようにします。",
    ),
    'SUV_OT_uvmap_set_active': (
        "Make the chosen UV layer the current active working target so later unwrap, repair, bake or export helpers operate on the intended role.",
        "選択したUV層を現在の作業対象としてアクティブ化し、後続の展開、修復、ベイク、書き出しヘルパーが意図した役割へ作用するようにします。",
    ),
    'SUV_OT_uvmap_set_render': (
        "Set the chosen UV layer as the render/export target when downstream tools should treat that layer as the primary output role.",
        "下流ツールでそのUV層を主出力役割として扱いたいときに、選択層をレンダー・書き出し対象として設定します。",
    ),
    'SUV_OT_write_tool_runtime_snapshot': (
        "Write a readable tool_runtime snapshot so the current mode, state and cached issue context can be reviewed later.",
        "現在モード、状態、問題キャッシュ文脈を後で確認できるよう、読みやすい実行時スナップショットを書き出します。",
    ),
    'SUV_OT_clear_tool_runtime_log': (
        "Clear the tool_runtime log when you want to start the next validation or troubleshooting pass from a cleaner note history.",
        "次の検証やトラブルシュートをより見やすい履歴から始めたいときに、実行時ログを消去します。",
    ),
    'SUV_OT_clear_batch_report': (
        "Clear the accumulated batch report so the next multi-object pass is easier to read without older results mixed in.",
        "一括処理レポートを消去し、次の複数オブジェクト処理結果を古い内容と混ぜずに読みやすくします。",
    ),
    'SUV_OT_reload_custom_icons': (
        "Reload custom icon resources used by the dashboard and guidance layer when visual aids look missing or stale.",
        "ダッシュボードや案内層で使うカスタムアイコンを再読込し、視覚補助が欠落または古く見えるときに復旧しやすくします。",
    ),
    'SUV_OT_texel_get': (
        "Read the current texel density from the active selection so later normalization or matching work can start from measured values.",
        "アクティブ選択から現在のテクセル密度を取得し、後続の正規化や一致調整を実測値から始められるようにします。",
    ),
    'SUV_OT_texel_set': (
        "Set the selection to a target texel density so assets can be aligned to a shared resolution standard before final packing.",
        "選択を目標テクセル密度へ設定し、最終パック前にアセット群を共通解像度基準へ揃えられるようにします。",
    ),
    'SUV_OT_texel_normalize': (
        "Normalize texel density across the working shells so repeated parts and neighboring islands are easier to keep visually consistent.",
        "作業シェル間のテクセル密度を正規化し、反復パーツや隣接アイランドの見た目一貫性を保ちやすくします。",
    ),

    'SUV_OT_set_save': (
        "Save the current selection set so repeated object or island groups can be recalled without rebuilding the same manual selection.",
        "現在の選択セットを保存し、同じ手動選択を作り直さずに反復するオブジェクト群やアイランド群を呼び出せるようにします。",
    ),
    'SUV_OT_set_recall': (
        "Recall a saved selection set so a known asset group can be restored quickly for batch edits or review.",
        "保存済みの選択セットを呼び出し、既知のアセット群を一括編集や確認のために素早く復元できるようにします。",
    ),
    'SUV_OT_layout_set_save': (
        "Save the current layout state as a reusable set so a preferred arrangement can be recalled on similar assets later.",
        "現在のレイアウト状態を再利用可能なセットとして保存し、好みの配置を後で類似アセットへ呼び出せるようにします。",
    ),
    'SUV_OT_layout_set_recall': (
        "Recall a saved layout set so a known arrangement structure can be restored before polishing or export.",
        "保存済みのレイアウトセットを呼び出し、既知の配置構造を仕上げや書き出し前に復元できるようにします。",
    ),
    'SUV_OT_seam_set_save': (
        "Save the current seam state as a reusable seam set so consistent cutting decisions can be shared across related assets.",
        "現在のシーム状態を再利用可能なシームセットとして保存し、関連アセット間で一貫した切り分け判断を共有できるようにします。",
    ),
    'SUV_OT_seam_set_recall': (
        "Recall a saved seam set so an established cut plan can be restored instead of remarking seams by hand.",
        "保存済みのシームセットを呼び出し、手作業でシームを付け直さずに確立済みの切り分け計画を復元します。",
    ),
    'SUV_OT_uv_histogram_tools': (
        "Open histogram-based UV review tools so shell area distribution and density balance are easier to inspect visually.",
        "ヒストグラムベースのUV確認ツールを開き、シェル面積分布や密度バランスを視覚的に確認しやすくします。",
    ),
    'SUV_OT_uv_issue_audit_tools': (
        "Run issue-audit helpers that summarize common UV problems into a more readable review layer before repair work begins.",
        "一般的なUV問題をより読みやすい確認レイヤーへ要約する問題監査ヘルパーを実行し、修復開始前の把握を助けます。",
    ),
    'SUV_OT_uv_issue_overlay_tools': (
        "Toggle issue overlay helpers so flipped, overlapping or otherwise suspicious areas are easier to spot in context.",
        "問題オーバーレイ補助を切り替え、反転、重なり、その他疑わしい領域を文脈の中で見つけやすくします。",
    ),
    'SUV_OT_uv_stack_compare_overlay_tools': (
        "Show stack-comparison overlays so repeated islands that should match can be compared more directly before final packing.",
        "スタック比較オーバーレイを表示し、一致させたい反復アイランドを最終パック前により直接比較できるようにします。",
    ),
    'SUV_OT_uv_seam_candidate_overlay_tools': (
        "Show seam-candidate overlays so possible cut routes can be reviewed visually before committing a new seam profile or batch action.",
        "シーム候補オーバーレイを表示し、新しいシームプロファイルや一括処理を確定する前に候補経路を視覚的に確認できるようにします。",
    ),
}.items():
    _cls = globals().get(_cls_name)
    if _cls is not None:
        try:
            _cls.bl_description = _suv_bilingual_desc(_desc_pair[0], _desc_pair[1])
        except Exception:
            pass


for _cls_name, _desc_pair in {
    'SUV_OT_set_library_io': (
        "Import or export saved selection-set data so recurring object groups can be backed up, shared or restored more safely.",
        "保存済み選択セットデータを入出力し、反復するオブジェクト群をより安全にバックアップ、共有、復元できるようにします。",
    ),
    'SUV_OT_set_transfer': (
        "Transfer saved selection-set style information between compatible targets so repeated object groups can keep a consistent working scope.",
        "保存済み選択セットの構成情報を互換対象へ転送し、反復するオブジェクト群の作業範囲を一貫させます。",
    ),
    'SUV_OT_set_update': (
        "Update the selected saved selection set from the current scene state when the reusable group definition has changed.",
        "再利用するグループ定義が変わったときに、現在のシーン状態から保存済み選択セットを更新します。",
    ),
    'SUV_OT_set_delete': (
        "Delete the selected saved selection set when the grouping is no longer needed or should be replaced by a cleaner version.",
        "そのグループ化が不要になった、またはより整理された版に置き換えたいときに、保存済み選択セットを削除します。",
    ),
    'SUV_OT_layout_set_library_io': (
        "Import or export saved layout-set data so preferred shell arrangements can be reused across scenes or team members.",
        "保存済みレイアウトセットデータを入出力し、好みのシェル配置をシーン間やチーム内で再利用できるようにします。",
    ),
    'SUV_OT_layout_set_transfer': (
        "Transfer a saved layout-set style to compatible targets so similar assets can start from a shared arrangement structure.",
        "保存済みレイアウトセット構成を互換対象へ転送し、類似アセットが共通の配置構造から始められるようにします。",
    ),
    'SUV_OT_layout_set_update': (
        "Update the selected saved layout set from the current arrangement when the reusable packing style has been refined.",
        "再利用するパック配置スタイルを調整した後、現在の配置から保存済みレイアウトセットを更新します。",
    ),
    'SUV_OT_layout_set_delete': (
        "Delete the selected saved layout set when the arrangement preset is outdated or should be replaced.",
        "配置プリセットが古くなった、または置き換えるべきときに、保存済みレイアウトセットを削除します。",
    ),
    'SUV_OT_seam_set_library_io': (
        "Import or export seam-set data so reusable cut plans can be shared, archived or restored without manual remarking.",
        "シームセットデータを入出力し、再利用する切り分け計画を手動で付け直さずに共有、保管、復元できるようにします。",
    ),
    'SUV_OT_seam_set_transfer': (
        "Transfer a saved seam-set style to compatible targets so related meshes can follow the same cut logic.",
        "保存済みシームセット構成を互換対象へ転送し、関連メッシュが同じ切り分けロジックに従うようにします。",
    ),
    'SUV_OT_seam_set_update': (
        "Update the selected saved seam set from the current mesh when the reusable cut plan has been improved.",
        "再利用する切り分け計画を改善した後、現在メッシュから保存済みシームセットを更新します。",
    ),
    'SUV_OT_seam_set_delete': (
        "Delete the selected saved seam set when the stored cut plan is no longer useful or should be rebuilt.",
        "保存済み切り分け計画が不要になった、または作り直すべきときに、シームセットを削除します。",
    ),
}.items():
    _cls = globals().get(_cls_name)
    if _cls is not None:
        try:
            _cls.bl_description = _suv_bilingual_desc(_desc_pair[0], _desc_pair[1])
        except Exception:
            pass




for _cls_name, _desc_pair in {
    'SUV_OT_pack_pro': (
        "Pack islands with the suite's more advanced packing workflow so spacing, density intent and tile-aware finishing can be handled from one operator.",
        "高度なパック処理フローでアイランドを配置し、余白、密度意図、タイルを意識した仕上げを1つのオペレーターから扱えるようにします。",
    ),
    'SUV_OT_stack_pro': (
        "Stack compatible islands with a more controlled workflow so repeated parts can share layout space before final review or export.",
        "より制御しやすい手順で互換アイランドをスタックし、反復パーツが最終確認や書き出し前にレイアウト空間を共有できるようにします。",
    ),
    'SUV_OT_align_islands': (
        "Align selected islands so shell direction, edge flow or layout rhythm becomes easier to read before packing.",
        "選択アイランドを整列し、シェル方向、エッジ流れ、レイアウトのリズムをパック前に読みやすくします。",
    ),
    'SUV_OT_fit_to_bounds': (
        "Fit selected UVs to the current bounds target when the shell should quickly match a tile, box or known destination area.",
        "選択UVを現在の境界目標へフィットし、シェルをタイル、枠、既知の配置先に素早く合わせられるようにします。",
    ),
    'SUV_OT_smart_relax': (
        "Relax the current selection with the suite's smoothing workflow so stretch can be reduced without losing the layout direction too aggressively.",
        "ツールセットの平滑化フローで現在選択をリラックスし、レイアウト方向を崩しすぎずに歪みを減らしやすくします。",
    ),
    'SUV_OT_stack_symmetry_topology': (
        "Use topology-aware symmetry stacking when mirrored parts should share space and stay structurally consistent before packing.",
        "ミラー部品が空間を共有しつつ構造的一貫性を保てるよう、トポロジーを意識した対称スタックを行います。",
    ),
    'SUV_OT_hotspot_symmetry_refill': (
        "Refill hotspot symmetry cells so mirrored layout targets regain balanced occupancy after edits or partial repairs.",
        "編集や部分修復の後に、左右対称のホットスポットセルへ再配置し、バランスのよい占有状態を取り戻しやすくします。",
    ),
    'SUV_OT_atlas_run_all_multi': (
        "Run the multi-object atlas workflow so several compatible objects can be consolidated into a broader shared layout in one pass.",
        "複数互換オブジェクトを一括でより大きな共通レイアウトへ統合できるよう、複数オブジェクト向けアトラス処理を実行します。",
    ),
    'SUV_OT_batch_object_to_udim_tiles': (
        "Send multiple objects to UDIM tiles in one batch so atlas or export preparation can start from a more organized tile allocation.",
        "複数オブジェクトを一括でUDIMタイルへ送り、アトラスや書き出し準備をより整理されたタイル割り当てから始められるようにします。",
    ),
    'SUV_OT_inspector_scan': (
        "Inspect the current working state and cache visible UV issues so later repair, layout and export decisions can be based on a fresh report.",
        "現在の作業状態を検査して見えているUV問題をキャッシュし、後続の修復、配置、書き出し判断を最新レポートに基づいて行えるようにします。",
    ),
    'SUV_OT_workspace_auto_repair': (
        "Run a broader automatic repair pass that targets common setup and UV-state problems before another manual review.",
        "次の手動確認前に、よくあるセットアップ不足やUV状態問題を対象とした、より広い自動修復を実行します。",
    ),
}.items():
    _cls = globals().get(_cls_name)
    if _cls is not None:
        try:
            _cls.bl_description = _suv_bilingual_desc(_desc_pair[0], _desc_pair[1])
        except Exception:
            pass


__all__ = [k for k in globals().keys() if not k.startswith('_')]


try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
except Exception:
    pass

for _cls_name, _desc_pair in {
    'SUV_OT_select_identical_islands': (
        "Select islands that appear structurally identical to the current one so repeated parts can be aligned, stacked or reviewed together.",
        "現在のアイランドと構造的に同一と思われるものを選択し、反復パーツをまとめて整列、スタック、確認できるようにします。",
    ),
    'SUV_OT_select_udim_crossing': (
        "Select islands that cross UDIM or tile boundaries so layout cleanup can focus on shells that are likely to break export assumptions.",
        "UDIM やタイル境界をまたぐアイランドを選択し、書き出し前提を崩しやすいシェルへ重点的にレイアウト修正を行えるようにします。",
    ),
    'SUV_OT_stack_grouped': (
        "Stack grouped islands while preserving their grouping intent so repeated parts can be compacted without losing the current organization.",
        "現在のグループ意図を保ちながらグループ化アイランドをスタックし、整理状態を崩さずに反復パーツを詰めやすくします。",
    ),
    'SUV_OT_unstack_groups': (
        "Separate grouped stacked islands back into readable placement so review, editing or rebaking can happen with less overlap ambiguity.",
        "グループ化されたスタックアイランドを再び読みやすい配置へ分離し、確認、編集、再ベイクを重なりの曖昧さを減らして行えるようにします。",
    ),
    'SUV_OT_sym_detect_pairs': (
        "Detect likely symmetry pairs so mirror-aware stacking, seam decisions or repair work can start from an informed pairing guess.",
        "対称と思われるペアを検出し、ミラー前提のスタック、シーム判断、修復を、より根拠のある対応関係から始められるようにします。",
    ),
    'SUV_OT_sym_mirror_uv': (
        "Mirror UV data across detected or chosen symmetry sides so matching halves can share a cleaner, more consistent layout state.",
        "検出または選択した対称側へ UV データをミラーし、左右対応パーツがより整った一貫レイアウトを共有できるようにします。",
    ),
    'SUV_OT_udim_tile_tools': (
        "Open tile-focused UDIM helpers so shells can be moved, filled or normalized with clearer awareness of tile boundaries.",
        "タイル重視の UDIM 補助を開き、シェルの移動、充填、正規化をタイル境界を意識しながら行いやすくします。",
    ),
    'SUV_OT_uv_sync_mode_toggle': (
        "Toggle UV sync behavior so selection and editing can follow either image-editor context or mesh-editor context more predictably.",
        "UV 同期挙動を切り替え、選択や編集が画像エディター基準かメッシュエディター基準かを、より予測しやすくします。",
    ),
    'SUV_OT_atlas_build_uv_multi': (
        "Build atlas UVs across multiple targets so a batch atlas workflow can start from a more consistent shared layout foundation.",
        "複数対象にまたがってアトラス UV を構築し、一括アトラス工程をより一貫した共有配置基盤から始められるようにします。",
    ),
    'SUV_OT_atlas_bake_multi': (
        "Run atlas bake preparation across multiple targets so downstream atlas outputs are easier to generate from a single coordinated pass.",
        "複数対象に対してアトラス用ベイク準備を行い、下流のアトラス出力を1回の連携した工程から作りやすくします。",
    ),
    'SUV_OT_workspace_settings_io': (
        "Import or export workspace settings so a preferred panel, display and guidance setup can be restored without rebuilding it by hand.",
        "ワークスペース設定を入出力し、好みのパネル、表示、ガイド構成を手作業で再構築せずに復元できるようにします。",
    ),
    'SUV_OT_workspace_reset': (
        "Reset workspace guidance and helper settings back toward a cleaner default state when the panel setup has become confusing or noisy.",
        "パネル構成が複雑になったときに、ワークスペースのガイドや補助設定をよりクリーンな既定状態へ戻しやすくします。",
    ),
}.items():
    _cls = globals().get(_cls_name)
    if _cls is not None:
        try:
            _cls.bl_description = _suv_bilingual_desc(_desc_pair[0], _desc_pair[1])
        except Exception:
            pass


try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
except Exception:
    pass

for _cls_name, _desc_pair in {
    'SUV_OT_select_similar_islands': (
        "Select islands that are structurally similar to the current one so repeated edits, packing checks or role decisions can be applied as a group.",
        "現在のアイランドと構造的に近いものを選択し、反復編集、パック確認、役割判断をグループとして適用しやすくします。",
    ),
    'SUV_OT_select_fragmented_islands': (
        "Select fragmented or suspiciously broken islands so cleanup can focus on shells that may hide unwrap or packing problems.",
        "分断された、または不自然に壊れて見えるアイランドを選択し、展開やパック問題を隠しやすいシェルへ重点的に修正を行えるようにします。",
    ),
    'SUV_OT_uv_seam_candidate_tools': (
        "Open seam-candidate helpers so likely cut routes can be reviewed before committing a new seam pattern across the model.",
        "シーム候補補助を開き、新しいシームパターンをモデル全体へ適用する前に、有力な切り分け経路を確認できるようにします。",
    ),
    'SUV_OT_uv_seam_candidate_profile_tools': (
        "Open profile-aware seam-candidate helpers so saved seam styles can be compared against newly suggested cut routes.",
        "プロファイル対応のシーム候補補助を開き、保存済みシームスタイルと新しい候補経路を比較できるようにします。",
    ),
    'SUV_OT_uv_seam_candidate_profile_batch_tools': (
        "Run batch seam-candidate profile helpers so multiple compatible assets can be reviewed against the same saved seam strategy.",
        "一括シーム候補プロファイル補助を実行し、複数の互換アセットを同じ保存済みシーム戦略で確認できるようにします。",
    ),
    'SUV_OT_uv_seam_candidate_profile_audit_tools': (
        "Audit candidate seam profiles so the current scene can be checked against saved cutting strategies before large batch actions.",
        "候補シームプロファイルを監査し、大きな一括処理の前に現在シーンを保存済み切り分け戦略と照合できるようにします。",
    ),
    'SUV_OT_uv_seam_state_overlay_tools': (
        "Show seam-state overlays so current seams, seam gaps or candidate changes can be compared directly in context.",
        "シーム状態オーバーレイを表示し、現在シーム、シームギャップ、候補変更をその場で直接比較できるようにします。",
    ),
    'SUV_OT_uv_seam_gap_tools': (
        "Open seam-gap helpers so missing or inconsistent seam breaks are easier to find before unwrap or atlas work continues.",
        "シームギャップ補助を開き、展開やアトラス作業を続ける前に、不足または不一致な切れ目を見つけやすくします。",
    ),
    'SUV_OT_uv_similarity_cluster_tools': (
        "Open similarity-cluster helpers so islands with matching proportions or structure can be grouped for review, stacking or profiling.",
        "類似クラスタ補助を開き、比率や構造が似たアイランドを確認、スタック、プロファイル適用のためにまとめられるようにします。",
    ),
    'SUV_OT_uv_similarity_cluster_overlay_tools': (
        "Show similarity-cluster overlays so repeated island families are easier to spot before group packing or mirrored edits.",
        "類似クラスタオーバーレイを表示し、グループパックやミラー編集の前に反復アイランド群を見つけやすくします。",
    ),
    'SUV_OT_native_stage_workflow': (
        "Open native-stage workflow helpers that keep Blender-native tools close to the suite's guided pipeline for safer step-by-step work.",
        "Blender 標準ツールをツールセットのガイド付きパイプラインに近づけ、より安全な段階作業をしやすくする標準段階ワークフロー補助を開きます。",
    ),
    'SUV_OT_native_stage_layout': (
        "Open native-stage layout helpers so packing, spacing and final arrangement can be reviewed with Blender-native controls nearby.",
        "Blender 標準寄りの制御を近くに置いたまま、パック、余白、最終配置を確認しやすくする標準段階レイアウト補助を開きます。",
    ),
    'SUV_OT_native_stage_select': (
        "Open native-stage selection helpers so island, seam and boundary selections can be built up more deliberately before edits.",
        "編集前にアイランド、シーム、境界選択をより計画的に組み立てやすくする標準段階選択補助を開きます。",
    ),
    'SUV_OT_native_stage_preview': (
        "Open native-stage preview helpers so checker, overlays and related visual verification can be reviewed without leaving the guided flow.",
        "ガイド付きフローを離れずにチェッカーやオーバーレイなどの視覚確認を行いやすくする標準段階プレビュー補助を開きます。",
    ),
    'SUV_OT_native_stage_bake': (
        "Open native-stage bake helpers so bake-role UV preparation and output checks can stay close to the current working context.",
        "Bake 役割UVの準備や出力確認を現在の作業文脈の近くで行いやすくする標準段階ベイク補助を開きます。",
    ),
    'SUV_OT_copy_diagnostics_text': (
        "Copy the current diagnostics text so the visible state summary can be pasted into notes, bug reports or support messages.",
        "現在の診断テキストをコピーし、表示中の状態要約をメモ、バグ報告、サポート連絡へ貼り付けやすくします。",
    ),
    'SUV_OT_write_support_bundle': (
        "Write a support bundle snapshot so the current state can be archived before riskier recovery or batch actions continue.",
        "よりリスクの高い復旧や一括処理を続ける前に、現在状態を保管できるサポートバンドルスナップショットを書き出します。",
    ),
    'SUV_OT_collect_support_bundle': (
        "Collect the current logs, diagnostics and helper state into a support bundle for later review or issue reporting.",
        "現在のログ、診断、補助状態をサポートバンドルへ集約し、後からの確認や問題報告に使いやすくします。",
    ),
    'SUV_OT_clear_all_reports': (
        "Clear cached reports and transient review text so the next validation pass starts from a cleaner diagnostic surface.",
        "キャッシュ済みレポートや一時的な確認テキストを消去し、次の検証をよりクリーンな診断状態から始められるようにします。",
    ),
}.items():
    _cls = globals().get(_cls_name)
    if _cls is not None:
        try:
            _cls.bl_description = _suv_bilingual_desc(_desc_pair[0], _desc_pair[1])
        except Exception:
            pass


# --- tooltip extension -----------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
except Exception:
    pass

for _cls_name, _desc_pair in {
    'SUV_OT_uv_sync_mode_toggle': (
        "Enable, disable or toggle Blender UV Sync Selection from inside the suite so mesh and UV selections can be coordinated without leaving the current workflow panel.",
        "現在のワークフローパネルを離れずに Blender の UV同期選択を有効化、無効化、反転し、メッシュ選択とUV選択を連携しやすくします。",
    ),
    'SUV_OT_workspace_settings_io': (
        "Export or import workspace settings so dashboard preferences, safety toggles and panel behavior can be backed up or restored without editing raw configuration by hand.",
        "ダッシュボード設定、安全系トグル、パネル挙動を手作業で設定ファイル編集せずにバックアップ・復元できるよう、ワークスペース設定を入出力します。",
    ),
    'SUV_OT_workspace_reset': (
        'Reset the UV Suite workspace to a safer baseline when the current panel state, cached choices or helper settings feel too tangled to trust.',
        '現在のパネル状態、キャッシュ済み選択、補助設定が複雑になりすぎて信頼しづらいときに、UV Suite のワークスペースを安全寄りの基準状態へ戻します。',
    ),
    'SUV_OT_set_library_io': (
        "Import or export saved selection-set libraries so recurring asset groups can be shared, archived or restored more safely across projects.",
        "保存済み選択セットのライブラリを入出力し、反復するアセット群をプロジェクト間でより安全に共有、保管、復元できるようにします。",
    ),
    'SUV_OT_layout_set_library_io': (
        "Import or export saved layout-set libraries so preferred arrangement patterns can be transferred without recreating shell placement by hand.",
        "保存済みレイアウトセットのライブラリを入出力し、シェル配置を手作業で作り直さずに好みの配置パターンを移行できるようにします。",
    ),
    'SUV_OT_seam_set_library_io': (
        "Import or export seam-set libraries so consistent cut plans can be reused across compatible assets and later recovered if a seam pass must be redone.",
        "シームセットのライブラリを入出力し、一貫した切り分け計画を互換アセット間で再利用したり、シーム作業をやり直す際に後から復元できるようにします。",
    ),
    'SUV_OT_workspace_validate': (
        'Validate the current UV Suite workspace and helper context so missing panels, stale caches or unsupported assumptions are easier to catch before a larger action runs.',
        '現在の UV Suite ワークスペースと補助文脈を検証し、大きな処理の前に不足パネル、古いキャッシュ、未対応の前提を見つけやすくします。',
    ),
    'SUV_OT_inspector_fix_flipped': (
        "Try to resolve flipped UVs that were found by the inspector so mirrored or inverted shells stop hiding inside later pack, bake or checker review steps.",
        "Inspector で見つかった反転UVの解消を試み、後続のパック、ベイク、チェッカー確認の中でミラーや反転シェルが紛れ込まないようにします。",
    ),
}.items():
    _cls = globals().get(_cls_name)
    if _cls is not None:
        try:
            _cls.bl_description = _suv_bilingual_desc(_desc_pair[0], _desc_pair[1])
        except Exception:
            pass


for _cls_name, _desc_pair in {
    'SUV_OT_batch_layout_profile': (
        "Apply a batch layout profile so repeated objects can share the same arrangement, packing and review-oriented finishing rules in one pass.",
        "一括レイアウトプロファイルを適用し、反復するオブジェクト群が同じ配置、パック、確認向け仕上げ規則を1回で共有できるようにします。",
    ),
    'SUV_OT_batch_export_texel_report': (
        "Export a combined texel-density report for the current batch so scale consistency can be reviewed before atlas, bake or delivery work.",
        "現在の一括対象について結合テクセル密度レポートを書き出し、アトラス、Bake、納品前にスケール一貫性を確認できるようにします。",
    ),
    'SUV_OT_workspace_settings_io': (
        "Import or export workspace settings so shared dashboard, role and helper defaults can be backed up or moved between scenes more safely.",
        "ワークスペース設定を入出力し、共有するダッシュボード、役割、補助設定の既定値を、シーン間でより安全にバックアップや移行できるようにします。",
    ),
    'SUV_OT_set_save': (
        "Save the current face-selection scope into a reusable set slot so recurring review or batch targets can be recalled without rebuilding the same selection by hand.",
        "現在の面選択範囲を再利用可能なセットスロットへ保存し、反復する確認対象や一括対象を手で選び直さずに呼び出せるようにします。",
    ),
    'SUV_OT_layout_set_save': (
        "Save the current active UV arrangement as a reusable layout slot so similar assets can inherit the same shell placement and finishing direction later.",
        "現在のアクティブUV配置を再利用可能なレイアウトスロットとして保存し、類似アセットが後で同じシェル配置と仕上げ方針を継承できるようにします。",
    ),
    'SUV_OT_seam_set_save': (
        "Save the current seam state into a reusable seam slot so a proven cut plan can be replayed on similar meshes instead of being reauthored every time.",
        "現在のシーム状態を再利用可能なシームスロットへ保存し、実績のある切り分け計画を毎回作り直さず類似メッシュへ再利用できるようにします。",
    ),
}.items():
    _cls = globals().get(_cls_name)
    if _cls is not None:
        try:
            _cls.bl_description = _suv_bilingual_desc(_desc_pair[0], _desc_pair[1])
        except Exception:
            pass


# --- tooltip extension -----------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
except Exception:
    pass

for _cls_name, _desc_pair in {
    'SUV_OT_bake_uv_prep': (
        "Prepare a dedicated Bake or Lightmap UV role across the current mesh selection by creating, copying, activating and optionally setting the render target in one guided step.",
        "現在のメッシュ選択に対して、Bake または Lightmap 用の専用UV役割を、作成、複製、アクティブ化、必要ならレンダー設定まで含めて1つのガイド付き手順で準備します。",
    ),
    'SUV_OT_uvmap_reorder': (
        "Reorder UV layers so working, Bake, Lightmap and Atlas roles are easier to scan and manage in a repeatable order across similar assets.",
        "作業用、Bake、Lightmap、Atlas の各UV役割を、類似アセット間で同じ順番に見やすく管理しやすいようにUV層順を並べ替えます。",
    ),
    'SUV_OT_batch_export_texel_report': (
        "Export a shared texel-density report for the current multi-object scope so final density consistency can be reviewed before atlas, bake or delivery work.",
        "現在の複数オブジェクト範囲について共有テクセル密度レポートを書き出し、アトラス、Bake、納品前に最終的な密度一貫性を確認できるようにします。",
    ),
    'SUV_OT_batch_match_stitch_active_preserve': (
        "Match and stitch the active reference while preserving more of the current shape so repeated assets can be aligned with less destructive layout drift.",
        "現在形状をより保ちながらアクティブ参照へ一致・縫合し、反復アセットをレイアウト崩れを抑えて揃えやすくします。",
    ),
    'SUV_OT_uvmap_set_active': (
        "Set a UV layer as the active working role so edits, unwraps and repair steps clearly target the intended channel before you branch into bake or export-specific paths.",
        "Bake や書き出し専用ルートへ分岐する前に、編集、展開、修復が意図したチャンネルへ明確に作用するよう、UV層をアクティブな作業役割として設定します。",
    ),
    'SUV_OT_uvmap_set_render': (
        "Set a UV layer as the render or export role so downstream baking, engine checks or delivery helpers use the intended output channel instead of the current working slot.",
        "後続のベイク、エンジン確認、納品補助が現在の作業スロットではなく意図した出力チャンネルを使うよう、UV層をレンダーまたは書き出し役割として設定します。",
    ),
    'SUV_OT_atlas_build_uv_multi': (
        "Build shared atlas UV placement across the selected meshes so repeated assets can move into a denser common space before baking or material consolidation.",
        "選択メッシュ全体に共有アトラスUV配置を構築し、反復アセットをベイクやマテリアル統合前により高密度な共通空間へ移せるようにします。",
    ),
    'SUV_OT_atlas_bake_multi': (
        "Bake the current atlas setup for the selected meshes so texture outputs can be reviewed from the packed shared-space result.",
        "選択メッシュ向けに現在のアトラス構成をベイクし、パック済み共有空間の結果からテクスチャ出力を確認できるようにします。",
    ),
    'SUV_OT_atlas_build_mat_apply_multi': (
        "Build and apply a shared material for the atlas result so selected meshes can be previewed or exported with the packed texture set more quickly.",
        "アトラス結果用の共有マテリアルを生成して適用し、選択メッシュをパック済みテクスチャセット付きでより素早く確認・書き出しできるようにします。",
    ),
    'SUV_OT_atlas_run_all_multi': (
        "Run the combined atlas workflow so UV build, bake and shared material setup can be executed together for a batch-oriented publish pass.",
        "UV構築、ベイク、共有マテリアル設定をまとめて実行し、一括公開向けのアトラスワークフローを通しで進めます。",
    ),
}.items():
    _cls = globals().get(_cls_name)
    if _cls is not None:
        try:
            _cls.bl_description = _suv_bilingual_desc(_desc_pair[0], _desc_pair[1])
        except Exception:
            pass


# --- tooltip extension -----------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
except Exception:
    pass

for _cls_name, _desc_pair in {
    'SUV_OT_uvmap_add': (
        "Add a new UV layer so the current mesh can branch into a fresh working, bake, lightmap or experimental role without overwriting the existing layout.",
        "既存レイアウトを上書きせずに、現在メッシュを新しい作業用、Bake、Lightmap、試作用の役割へ分岐できるよう、新規UV層を追加します。",
    ),
    'SUV_OT_uvmap_duplicate': (
        "Duplicate the current active UV so a proven working layout can be preserved before role switching, repacking or destructive cleanup steps.",
        "役割切替、再パック、破壊的な整理の前に、実績のある作業レイアウトを保全できるよう、現在のアクティブUVを複製します。",
    ),
    'SUV_OT_uvmap_remove': (
        "Remove the active UV layer when a temporary or mistaken branch should be discarded, keeping the layer stack easier to read before delivery.",
        "一時的または誤って作成した分岐を破棄し、納品前に層構成を読みやすく保つため、アクティブUV層を削除します。",
    ),
    'SUV_OT_uvmap_rename_active': (
        "Rename the active UV layer so Working, Bake, Lightmap or Atlas roles stay easier to identify across repeated assets and batch-oriented workflows.",
        "Working、Bake、Lightmap、Atlas などの役割を反復アセットや一括ワークフローでも識別しやすくするため、アクティブUV層名を変更します。",
    ),
    'SUV_OT_uvmap_reorder': (
        "Reorder UV layers so Working, Bake, Lightmap and Atlas roles appear in a consistent stack order that is easier to scan before export or handoff.",
        "Working、Bake、Lightmap、Atlas の各役割が書き出しや引き渡し前に見やすい一定順で並ぶよう、UV層順を並べ替えます。",
    ),
    'SUV_OT_batch_export_texel_report': (
        "Export a batch texel-density report so multiple assets can be reviewed together before a shared atlas, tile layout or final delivery pass.",
        "共有アトラス、タイル配置、最終納品前に、複数アセットのテクセル密度をまとめて確認できるよう、一括テクセル密度レポートを書き出します。",
    ),
}.items():
    _cls = globals().get(_cls_name)
    if _cls is not None:
        try:
            _cls.bl_description = _suv_bilingual_desc(_desc_pair[0], _desc_pair[1])
        except Exception:
            pass


# --- tooltip extension -----------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
except Exception:
    pass

for _cls_name, _desc_pair in {
    'SUV_OT_apply_workflow_preset': (
        "Apply a higher-level workflow preset that moves several related workspace options together, giving you a more predictable starting mode for unwrap, align, layout or repair work.",
        "複数の関連ワークスペース設定をまとめて切り替える上位ワークフロープリセットを適用し、展開、整列、配置、修復へ向けたより予測しやすい開始モードを作ります。",
    ),
    'SUV_OT_apply_display_preset': (
        "Apply a display preset that changes which controls and helper sections stay visible, helping beginners simplify the panel or advanced users focus on inspection and layout tasks.",
        "どのコントロールや補助セクションを見せるかを切り替える表示プリセットを適用し、初心者にはパネルを簡潔に、上級者には検査や配置に集中しやすくします。",
    ),
    'SUV_OT_apply_line_flow_preset': (
        "Apply a line or flow preset before straightening, edge-flow cleanup or annotation passes so the suite starts from defaults better matched to strip-like shells.",
        "直線化、エッジフロー整理、注記工程の前にライン/フロープリセットを適用し、ストリップ状シェルに合った既定値から作業を始められるようにします。",
    ),
    'SUV_OT_apply_layout_preset': (
        "Apply a layout preset that prepares packing, spacing and arrangement defaults in one step so finishing passes begin from a known placement strategy.",
        "パック、余白、配置の既定値を1手で整えるレイアウトプリセットを適用し、仕上げ工程を既知の配置方針から始められるようにします。",
    ),
    'SUV_OT_validate_workflow_assets': (
        "Validate workflow-side helper assets, preset files and reference resources so missing support data is easier to catch before preset-driven work begins.",
        "プリセット駆動の作業開始前に、ワークフロー側の補助アセット、プリセットファイル、参照リソースを検証し、不足データを見つけやすくします。",
    ),
    'SUV_OT_preset_library_io': (
        "Import or export shared preset-library content so workflow, display, line-flow and layout presets can be backed up or reused without digging through raw configuration files.",
        "ワークフロー、表示、ライン/フロー、レイアウトの各プリセットを、生の設定ファイルを追わずにバックアップ・再利用できるよう、共有プリセットライブラリ内容を入出力します。",
    ),
}.items():
    _cls = globals().get(_cls_name)
    if _cls is not None:
        try:
            _cls.bl_description = _suv_bilingual_desc(_desc_pair[0], _desc_pair[1])
        except Exception:
            pass


# --- tooltip extension -----------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
except Exception:
    pass

for _cls_name, _desc_pair in {
    'SUV_OT_auto_uv_profile': (
        "Apply a bundled Auto UV profile tuned for a particular workflow style so the suite can start from more suitable seam, unwrap, relax and layout defaults in one step.",
        "特定のワークフロースタイル向けに調整された Auto UV プロファイルを適用し、シーム、展開、リラックス、配置の既定値を1手でより適切な状態から始められるようにします。",
    ),
    'SUV_OT_native_projection': (
        "Run Core-native projection and unwrap helpers inside the suite so you can start from smart, view-based or lightmap-style projections before refinement and packing.",
        "Blender標準の投影・展開補助をツールセット内から実行し、スマート投影、ビュー基準投影、Lightmap系投影から整形やパックへ進めるようにします。",
    ),
    'SUV_OT_native_uv_action': (
        "Call Blender-native seam, stitch and pin style actions from the suite when you want to mix familiar native UV editing behaviors with the guided workflow panels.",
        "ガイド付きワークフローパネルを使いながら、使い慣れた Blender 標準のシーム、ステッチ、ピン系操作をツールセット内から呼び出します。",
    ),
    'SUV_OT_pack_pro': (
        "Pack the current shells with the suite's higher-level packing rules so density, grouping, tile layout and late-stage organization are handled together more predictably.",
        "ツールセットの上位パック規則で現在のシェルを配置し、密度、グループ化、タイル構成、後工程の整理をより予測しやすくまとめて扱います。",
    ),
    'SUV_OT_inspector_fix_flipped': (
        "Repair shells detected as flipped so later checker review, bake helpers and export steps start from a cleaner orientation state.",
        "反転として検出されたシェルを修復し、後続のチェッカー確認、Bake 補助、書き出し工程をよりクリーンな向き状態から始められるようにします。",
    ),
}.items():
    _cls = globals().get(_cls_name)
    if _cls is not None:
        try:
            _cls.bl_description = _suv_bilingual_desc(_desc_pair[0], _desc_pair[1])
        except Exception:
            pass


# --- tooltip extension -----------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
except Exception:
    pass

for _cls_name, _desc_pair in {
    'SUV_OT_workspace_validate': (
        "Validate the current workspace state before heavier UV tools run so missing mesh selection, missing UV layers, stale scans or context mismatches are easier to catch early.",
        "重いUVツールを動かす前に現在のワークスペース状態を検証し、メッシュ未選択、UV層不足、古い検査結果、文脈不一致を早めに見つけやすくします。",
    ),
    'SUV_OT_workspace_auto_repair': (
        "Apply the suite's safer workspace repair pass to restore missing setup, refresh helper state and reduce obvious blockers before you continue with layout, atlas or export steps.",
        "ツールセットの安全寄りワークスペース修復を適用し、不足設定の復旧、補助状態の更新、明らかな阻害要因の軽減を行ってから配置、アトラス、書き出しへ進めます。",
    ),
    'SUV_OT_uvmap_set_active': (
        "Switch the active working UV target so later unwrap, checker, pack and manual edits are applied to the intended layer instead of a leftover slot.",
        "後続の展開、チェッカー、パック、手動編集が残っていた別スロットではなく、意図したUV層へ適用されるよう作業対象を切り替えます。",
    ),
    'SUV_OT_uvmap_set_render': (
        "Mark the chosen UV as the render/export target when Bake, Lightmap or downstream material pipelines need a different layer than the current editing slot.",
        "現在の編集スロットとは別の層を Bake、Lightmap、下流マテリアル工程で使いたいとき、そのUVをレンダー/書き出し対象として設定します。",
    ),
    'SUV_OT_uvmap_reorder': (
        "Reorder UV layers so working, Bake and Lightmap roles are easier to audit, especially when several saved slots must be kept readable for later handoff.",
        "作業用、Bake、Lightmap の役割順を見直しやすいようUV層を並べ替え、複数保存スロットを後工程へ引き渡すときの可読性を上げます。",
    ),
    'SUV_OT_set_save': (
        "Save the current reusable selection group so repeated island, seam or repair work can be recalled later without rebuilding the same manual selection again.",
        "再利用したい現在の選択グループを保存し、同じ島、シーム、修復対象を後で再び手作業で選び直さずに呼び出せるようにします。",
    ),
    'SUV_OT_layout_set_save': (
        "Save the current layout-oriented selection or shell grouping so later packing and tidy passes can restart from a known organization state.",
        "現在のレイアウト向け選択やシェルグループを保存し、後のパックや整頓工程を既知の構成状態から再開できるようにします。",
    ),
    'SUV_OT_seam_set_save': (
        "Save the present seam-related selection so seam candidate reviews, cut decisions and reuse patterns can be restored without searching the same edges again.",
        "現在のシーム関連選択を保存し、シーム候補確認、切り分け判断、再利用パターンを同じエッジを探し直さず復元できるようにします。",
    ),
}.items():
    _cls = globals().get(_cls_name)
    if _cls is not None:
        try:
            _cls.bl_description = _suv_bilingual_desc(_desc_pair[0], _desc_pair[1])
        except Exception:
            pass


# --- tooltip extension -----------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
except Exception:
    pass

for _cls_name, _desc_pair in {
    'SUV_OT_select_similar_islands': (
        "Select islands whose overall shape and proportions are close to the current target so repeated cleanup, alignment or density work can be expanded without manual re-picking.",
        "現在の対象に近い形状や比率を持つアイランドを選択し、反復整理、整列、密度調整を手で選び直さずに広げられるようにします。",
    ),
    'SUV_OT_select_identical_islands': (
        "Select islands that are nearly identical to the active target when mirrored or repeated parts should be processed together before stack, atlas or bake-role preparation.",
        "ミラー部品や反復部品を、スタック、アトラス、Bake役割準備の前にまとめて扱いたいとき、アクティブ対象とほぼ同一のアイランドを選択します。",
    ),
    'SUV_OT_select_fragmented_islands': (
        "Select fragmented islands that look overly split so you can inspect stitch, seam or cleanup opportunities before final packing and checker review.",
        "過度に分断されて見える断片化アイランドを選択し、最終パックやチェッカー確認前にステッチ、シーム、整理の見直し候補を確認できるようにします。",
    ),
    'SUV_OT_select_udim_crossing': (
        "Select islands that cross UDIM borders so tile assignment, atlas layout or export-role cleanup can be fixed before downstream tools rely on clean tile boundaries.",
        "UDIM境界をまたぐアイランドを選択し、下流ツールがきれいなタイル境界を前提とする前に、タイル割当、アトラス配置、書き出し役割の整理を修正できるようにします。",
    ),
    'SUV_OT_select_uv_boundary': (
        "Select UV boundary edges so seam review, shell cleanup and strip-oriented straightening can start from the shell border instead of interior elements.",
        "シェル境界からシーム確認、シェル整理、ストリップ系直線化を始められるよう、内部要素ではなくUV境界エッジを選択します。",
    ),
}.items():
    _cls = globals().get(_cls_name)
    if _cls is not None:
        try:
            _cls.bl_description = _suv_bilingual_desc(_desc_pair[0], _desc_pair[1])
        except Exception:
            pass


try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
except Exception:
    pass

for _cls_name, _desc_pair in {
    'SUV_OT_batch_ensure_active_uv': (
        "Ensure every selected mesh has a valid active UV target before batch layout, bake or atlas helpers begin changing map-dependent state.",
        "一括レイアウト、Bake、Atlas 補助がマップ依存状態を変更し始める前に、選択メッシュすべてに有効なアクティブUV対象があることを保証します。",
    ),
    'SUV_OT_batch_sync_active_uv': (
        "Sync the active UV target across the selected meshes so follow-up batch tools operate on a more consistent working role.",
        "後続の一括ツールがより一貫した作業役割へ作用するよう、選択メッシュ間でアクティブUV対象を同期します。",
    ),
    'SUV_OT_batch_export_texel_report': (
        "Export a texel-density report for the current batch so cross-asset consistency can be reviewed before delivery or atlas work.",
        "現在の一括対象に対するテクセル密度レポートを書き出し、納品やアトラス作業前にアセット間の一貫性を確認できるようにします。",
    ),
    'SUV_OT_uvmap_add': (
        "Add a new UV layer when a separate working, Bake, Lightmap or export role should be created instead of reusing the current map.",
        "現在マップを使い回さずに、作業用、Bake、Lightmap、書き出し用など別の役割UVを作りたいときに、新しいUV層を追加します。",
    ),
    'SUV_OT_uvmap_duplicate': (
        "Duplicate the current UV layer so a safe branch can be made before packing, baking or role-specific cleanup changes the layout.",
        "パック、Bake、役割別整理でレイアウトが変わる前に安全な分岐を作れるよう、現在のUV層を複製します。",
    ),
    'SUV_OT_uvmap_rename_active': (
        "Rename the active UV layer so its role stays readable in larger assets that use several working, bake or export maps.",
        "複数の作業、Bake、書き出し用マップを使う大きなアセットでも役割を読みやすく保てるよう、アクティブUV層に名前を付け直します。",
    ),
    'SUV_OT_bake_uv_prep': (
        "Prepare a Bake or Lightmap oriented UV target so downstream helpers work on a role-specific map instead of the current generic working layer.",
        "下流補助が汎用の作業層ではなく役割専用マップへ作用するよう、Bake または Lightmap 向けUV対象を準備します。",
    ),
}.items():
    _cls = globals().get(_cls_name)
    if _cls is not None:
        try:
            _cls.bl_description = _suv_bilingual_desc(_desc_pair[0], _desc_pair[1])
        except Exception:
            pass


# --- tooltip extension -----------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
except Exception:
    pass

for _cls_name, _desc_pair in {
    'SUV_OT_set_recall': (
        "Recall a saved selection scope so repeated object or island groups can be restored quickly before batch cleanup, consistency checks or export preparation.",
        "保存済みの選択範囲を呼び出し、一括整理、整合確認、書き出し準備の前に反復するオブジェクトやアイランド群を素早く復元できるようにします。",
    ),
    'SUV_OT_set_update': (
        "Update the selected saved selection scope from the current scene state when the reusable group has changed and should replace the older definition.",
        "再利用グループが変わり古い定義を置き換えたいときに、現在のシーン状態から選択済み保存範囲を更新します。",
    ),
    'SUV_OT_set_delete': (
        "Delete the selected saved selection scope when it is obsolete, duplicated or no longer matches the production grouping you want to reuse.",
        "古くなった、重複している、または再利用したい制作グループと一致しなくなった保存済み選択範囲を削除します。",
    ),
    'SUV_OT_layout_set_recall': (
        "Recall a saved layout arrangement so similar assets can start from a trusted shell placement instead of rebuilding the finish layout manually.",
        "類似アセットが信頼できるシェル配置から始められるよう、仕上げレイアウトを手で組み直さずに保存済みレイアウト配置を呼び出します。",
    ),
    'SUV_OT_layout_set_update': (
        "Update the stored layout set from the current shell arrangement when the reusable finish layout has improved and should become the new reference.",
        "再利用する仕上げレイアウトが改善され新しい基準にしたいときに、現在のシェル配置から保存済みレイアウトセットを更新します。",
    ),
    'SUV_OT_layout_set_delete': (
        "Delete the selected saved layout set when it no longer represents the arrangement standard you want to keep in the library.",
        "その配置基準をライブラリに残したくなくなったときに、選択中の保存済みレイアウトセットを削除します。",
    ),
    'SUV_OT_seam_set_recall': (
        "Recall a saved seam plan so repeated or mirrored assets can reuse the same cut logic before unwrap, straighten or batch profile work begins.",
        "反復アセットやミラーアセットが、展開、直線化、一括プロファイル作業の前に同じ切り分け方針を再利用できるよう、保存済みシーム計画を呼び出します。",
    ),
    'SUV_OT_seam_set_update': (
        "Update the selected seam set from the current cut state when the reusable seam strategy has been refined and should replace the previous version.",
        "再利用するシーム戦略を洗練して以前の版と置き換えたいときに、現在の切り分け状態から選択中シームセットを更新します。",
    ),
    'SUV_OT_seam_set_delete': (
        "Delete the selected saved seam set when the cut plan is obsolete or should be removed from the reusable library.",
        "その切り分け計画が古くなった、または再利用ライブラリから外したいときに、選択中の保存済みシームセットを削除します。",
    ),
    'SUV_OT_preset_library_io': (
        "Import or export the preset library so workflow, display, flow and layout presets can be backed up, restored or shared without editing raw files.",
        "ワークフロー、表示、フロー、レイアウトのプリセットを生ファイル編集なしでバックアップ、復元、共有できるよう、プリセットライブラリを入出力します。",
    ),
    'SUV_OT_workspace_settings_io': (
        "Import or export broader workspace settings so dashboard, helper and review behavior can move together between files or machines.",
        "ダッシュボード、補助、確認の挙動をファイル間やマシン間でまとめて移せるよう、より広いワークスペース設定を入出力します。",
    ),
    'SUV_OT_workspace_reset': (
        "Reset workspace-facing helper settings when the current panel behavior should return to a cleaner default before building a new workflow setup.",
        "新しいワークフロー設定を組み直す前に、現在のパネル挙動をよりクリーンな既定状態へ戻したいとき、ワークスペース向け補助設定をリセットします。",
    ),
}.items():
    _cls = globals().get(_cls_name)
    if _cls is not None:
        try:
            _cls.bl_description = _suv_bilingual_desc(_desc_pair[0], _desc_pair[1])
        except Exception:
            pass


# --- tooltip extension -----------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
except Exception:
    pass

for _cls_name, _desc_pair in {
    'SUV_OT_batch_layout_profile': (
        "Run a shared layout profile across the selected meshes so repeated assets follow the same arrangement rules before review or export.",
        "選択メッシュ全体に共通レイアウトプロファイルを実行し、反復アセットが確認や書き出し前に同じ配置規則へ従うようにします。",
    ),
    'SUV_OT_batch_match_stitch_active_preserve': (
        "Match and stitch batch targets while preserving the active target intent, helping repeated assets keep closer shell relationships without losing the working role.",
        "アクティブ対象の意図を保ちながら一括対象を一致・縫合し、作業役割を崩さずに反復アセットのシェル関係を近づけます。",
    ),
    'SUV_OT_uvmap_remove': (
        "Remove the current UV layer when an obsolete working, bake or export role should be cleaned out of the asset before further synchronization.",
        "古くなった作業用、Bake用、書き出し用の役割UVを以後の同期前に整理したいとき、現在のUV層を削除します。",
    ),
    'SUV_OT_uvmap_reorder': (
        "Reorder UV layers so working, render and bake roles stay readable and easier to switch in larger multi-map assets.",
        "作業用、Render用、Bake用の役割が大きな複数UVアセットでも読みやすく切り替えやすいよう、UV層の順序を整理します。",
    ),
    'SUV_OT_batch_export_texel_report': (
        "Write a texel-density report for the current selection batch so cross-object consistency can be reviewed before atlas, bake or export decisions.",
        "現在の選択一括対象に対するテクセル密度レポートを書き出し、アトラス、Bake、書き出し判断前にオブジェクト間一貫性を確認できるようにします。",
    ),
    'SUV_OT_workspace_validate': (
        "Validate the current workspace-facing state so missing UV slots, sync issues, icon resources or helper context can be caught before the next operation.",
        "次の操作前に、現在のワークスペース状態を検証し、UV不足、同期問題、アイコン資源不足、補助文脈不足を見つけやすくします。",
    ),
    'SUV_OT_workspace_auto_repair': (
        "Run a broader automatic repair pass for workspace-facing helper issues when the dashboard or validation layer reports missing or stale state.",
        "ダッシュボードや検証層が不足または古い状態を示したときに、ワークスペース向け補助問題を広めに自動修復します。",
    ),
    'SUV_OT_preset_library_io': (
        "Import or export preset-library data so workflow, display, flow and layout presets can be shared or restored without hunting through raw files.",
        "ワークフロー、表示、フロー、レイアウトのプリセットを生ファイルを追わずに共有・復元できるよう、プリセットライブラリデータを入出力します。",
    ),
    'SUV_OT_workspace_settings_io': (
        "Import or export broader workspace settings so helper layout, dashboard guidance and reusable routes can move together between scenes or machines.",
        "補助レイアウト、ダッシュボード案内、再利用ルートをシーン間やマシン間でまとめて移せるよう、より広いワークスペース設定を入出力します。",
    ),
}.items():
    _cls = globals().get(_cls_name)
    if _cls is not None:
        try:
            _cls.bl_description = _suv_bilingual_desc(_desc_pair[0], _desc_pair[1])
        except Exception:
            pass


# --- tooltip extension -----------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
except Exception:
    pass

for _cls_name, _desc_pair in {
    'SUV_OT_batch_ensure_active_uv': (
        "Create or align missing active UV targets across the current selection so later batch layout, bake or export steps all point to a consistent working layer.",
        "現在の選択全体で不足しているアクティブUV対象を作成または整列し、後続の一括レイアウト、Bake、書き出し工程が同じ作業レイヤーを参照できるようにします。",
    ),
    'SUV_OT_batch_sync_active_uv': (
        "Synchronize the active UV target across selected meshes when repeated assets should share the same working layer before reports, atlas work or export.",
        "反復アセットがレポート、アトラス作業、書き出し前に同じ作業レイヤーを共有できるよう、選択メッシュ間でアクティブUV対象を同期します。",
    ),
    'SUV_OT_uv_sync_mode_toggle': (
        "Toggle UV Sync when you need mesh-side and UV-side selections to stay linked during inspection, boundary picking or island-based repair work.",
        "検査、境界選択、アイランド単位の修復中にメッシュ側とUV側の選択を連動させたいとき、UV Sync を切り替えます。",
    ),
    'SUV_OT_set_transfer': (
        "Transfer a saved selection-set definition so repeated assets can inherit the same named mesh or island grouping without rebuilding the set by hand.",
        "反復アセットが同じ名前付きメッシュまたはアイランド群を手作業で作り直さず継承できるよう、保存済み選択セット定義を転送します。",
    ),
    'SUV_OT_layout_set_transfer': (
        "Transfer a saved layout-set definition so another asset can reuse the same arrangement intent before packing, auditing or atlas preparation.",
        "別のアセットがパック、監査、アトラス準備の前に同じ配置意図を再利用できるよう、保存済みレイアウトセット定義を転送します。",
    ),
    'SUV_OT_seam_set_transfer': (
        "Transfer a saved seam-set definition so another asset can inherit the same cut plan before unwrap, straighten or batch seam-profile work.",
        "別のアセットが展開、直線化、一括シームプロファイル作業の前に同じ切り分け計画を継承できるよう、保存済みシームセット定義を転送します。",
    ),
    'SUV_OT_select_uv_boundary': (
        "Select UV boundaries when you want to inspect open borders, isolate stitch candidates or verify where shells still break apart across the layout.",
        "開いた境界を確認したい、縫合候補を抽出したい、またはレイアウト上でシェルがどこで分断されているかを確かめたいとき、UV境界を選択します。",
    ),
    'SUV_OT_workspace_reset': (
        "Reset helper-facing workspace settings when dashboard behavior, routes or temporary UI state should return to a cleaner baseline before further work.",
        "ダッシュボード挙動、導線、一時UI状態を以後の作業前によりクリーンな基準へ戻したいとき、補助系ワークスペース設定をリセットします。",
    ),
}.items():
    _cls = globals().get(_cls_name)
    if _cls is not None:
        try:
            _cls.bl_description = _suv_bilingual_desc(_desc_pair[0], _desc_pair[1])
        except Exception:
            pass


# --- tooltip extension ------------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
except Exception:
    pass

for _cls_name, _desc_pair in {
    'SUV_OT_smart_3d_transfer': (
        "Transfer UV intent from a related source mesh in 3D space when repeated assets should inherit shell placement or seam logic without rebuilding everything by hand.",
        "反復アセットがシェル配置やシーム方針を手作業で組み直さず継承できるよう、関連するソースメッシュから3D空間基準でUVの意図を転送します。",
    ),
    'SUV_OT_set_transfer': (
        "Transfer a saved selection-set definition to another mesh so repeated assets can share the same named island or face grouping before later layout and repair work.",
        "別のメッシュへ保存済み選択セット定義を転送し、反復アセットが後続の配置や修復前に同じ名前付きアイランド群や面グループを共有できるようにします。",
    ),
    'SUV_OT_layout_set_transfer': (
        "Transfer a saved layout-set definition so another asset can inherit the same arrangement intent before packing, tidy passes or atlas preparation.",
        "保存済みレイアウトセット定義を転送し、別のアセットがパック、整列仕上げ、アトラス準備前に同じ配置意図を継承できるようにします。",
    ),
    'SUV_OT_seam_set_transfer': (
        "Transfer a saved seam-set definition so another mesh can inherit a known cut plan before unwrap, straighten or smart relax work.",
        "保存済みシームセット定義を転送し、別のメッシュが展開、直線化、Smart Relax の前に既知の切り分け計画を継承できるようにします。",
    ),
    'SUV_OT_smart_edge_straighten': (
        "Straighten selected UV edge flow when strip-like shells should read cleaner before packing, hotspot placement or texture painting.",
        "帯状シェルをパック、ホットスポット配置、テクスチャ作業前により読みやすくしたいとき、選択UVのエッジ流れを直線寄りに整えます。",
    ),
    'SUV_OT_smart_rectify': (
        "Rectify shell corners toward cleaner right-angle structure when hard-surface strips or panels should become easier to align and review.",
        "ハードサーフェスの帯やパネルを整列・確認しやすくしたいとき、シェルの角をより直角寄りに補正します。",
    ),
    'SUV_OT_sym_stack': (
        "Stack mirrored symmetry partners so repeated mirrored shells can share texel space more efficiently after pair detection is complete.",
        "対称ペア検出後に、ミラー対称シェル同士を重ねてテクセル空間をより効率よく共有できるようにします。",
    ),
    'SUV_OT_atlas_build_mat_apply_multi': (
        "Build and apply a shared atlas material across multiple targets so the prepared atlas UV result can be previewed and handed off with fewer manual steps.",
        "複数対象に共有アトラスマテリアルを作成・適用し、準備済みアトラスUV結果を少ない手順で確認・引き渡しできるようにします。",
    ),
}.items():
    _cls = globals().get(_cls_name)
    if _cls is not None:
        try:
            _cls.bl_description = _suv_bilingual_desc(_desc_pair[0], _desc_pair[1])
        except Exception:
            pass


# --- tooltip extension ------------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
except Exception:
    pass

for _cls_name, _desc_pair in {
    'SUV_OT_match_stitch_active_preserve': (
        "Match selected or similar islands to the active island, then keep the result ready for core stitch, weld or reuse-friendly cleanup without rebuilding each shell by hand.",
        "選択または類似アイランドをアクティブ島へ合わせ、各シェルを手で組み直さずに、その後のコアステッチ、ウェルド、再利用向け整形へ進みやすくします。",
    ),
    'SUV_OT_smart_edge_straighten': (
        "Straighten strip-like UV flow before trim placement, shared packing or panel cleanup so long shells become easier to align and read.",
        "トリム配置、共有パック、パネル整形の前に帯状UVの流れを直線寄りに整え、長いシェルをそろえやすく見やすくします。",
    ),
    'SUV_OT_smart_rectify': (
        "Rectify shell corners toward cleaner hard-surface panels when you want boxes, trims or machine parts to look less skewed before the final pack.",
        "箱状、トリム、機械パーツの見た目を最終パック前により歪み少なくしたいとき、シェルの角をハードサーフェス向けに整えます。",
    ),
    'SUV_OT_pack_pro': (
        "Pack the current UV state with the suite's higher-level packing options so cleaned, stacked or role-prepared shells can move into a tighter final layout.",
        "整形済み、スタック済み、役割準備済みのシェルを、ツールセットの上位パック設定でより詰まった最終レイアウトへ移動させます。",
    ),
}.items():
    _cls = globals().get(_cls_name)
    if _cls is not None:
        try:
            _cls.bl_description = _suv_bilingual_desc(_desc_pair[0], _desc_pair[1])
        except Exception:
            pass


# --- tooltip extension ------------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
except Exception:
    pass

for _cls_name, _desc_pair in {
    'SUV_OT_projection_bridge': (
        "Open a merged projection route that quickly switches between camera, normal, peel, pelt, spline-tube and scan-safe starting strategies before later cleanup or packing.",
        "カメラ、法線、Peel、Pelt、スプライン・チューブ、スキャン安全系の開始戦略を素早く切り替え、後続の補正やパックへ繋げる統合投影ルートを開きます。",
    ),
    'SUV_OT_cleanup_bridge': (
        "Run a merged cleanup route when the current shells need heal, overlap removal, heavier relax, weld alignment or live-style optimize help without switching tools manually.",
        "現在のシェルに修復、重なり解消、強いリラックス、ウェルド整列、ライブ最適化補助が必要なときに、手動でツールを切り替えず使える統合補正ルートを実行します。",
    ),
    'SUV_OT_similarity_bridge': (
        "Use a merged similarity route to find, compare or stack similar islands before layout cleanup, transfer, or repeated-asset optimization work.",
        "レイアウト整理、転送、反復アセット最適化の前に、類似アイランドを見つける・比較する・重ねるための統合類似判定ルートを使います。",
    ),
    'SUV_OT_smart_3d_transfer': (
        "Transfer UV intent from a related source mesh in 3D space when repeated assets should inherit shell flow or seam direction before fine cleanup and final packing.",
        "反復アセットが細部調整や最終パック前にシェルの流れやシーム方向を継承したいとき、関連ソースメッシュから3D空間基準でUV意図を転送します。",
    ),
    'SUV_OT_atlas_build_mat_apply_multi': (
        "Build and assign a shared atlas material after atlas UV preparation so grouped targets can be previewed and handed off with fewer manual material steps.",
        "アトラスUV準備後に共有アトラスマテリアルを作成・割り当てし、対象群を少ない手動設定で確認・引き渡ししやすくします。",
    ),
}.items():
    _cls = globals().get(_cls_name)
    if _cls is not None:
        try:
            _cls.bl_description = _suv_bilingual_desc(_desc_pair[0], _desc_pair[1])
        except Exception:
            pass


# --- tooltip extension ------------------------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
except Exception:
    pass

for _cls_name, _desc_pair in {
    'SUV_OT_uv_histogram_tools': (
        "Analyze island size, aspect, density and angle distributions so outlier shells can be reported or selected before layout cleanup and export review.",
        "アイランドの大きさ、縦横比、密度、角度分布を解析し、レイアウト整理や書き出し確認の前に外れ値シェルをレポート化または選択できるようにします。",
    ),
    'SUV_OT_uv_issue_audit_tools': (
        "Audit overlap, flipped shells, UDIM crossing, fragmentation and stretch severity into a readable report so repair decisions start from measured UV issues.",
        "重なり、反転、UDIM跨ぎ、断片化、ストレッチ重大度を読みやすいレポートへ監査し、実測のUV問題に基づいて修復判断を始められるようにします。",
    ),
    'SUV_OT_uv_issue_overlay_tools': (
        "Build or clear per-island issue overlays so severity, stretch or overlap signals can be seen directly on the mesh before repair or handoff.",
        "アイランド単位の問題オーバーレイを作成または解除し、重大度、ストレッチ、重なりの兆候を修復や引き渡し前にメッシュ上で直接確認できるようにします。",
    ),
    'SUV_OT_visualize_stretch_heatmap': (
        "Create a stretch heatmap preview so distortion-heavy islands become easier to spot before relax, rectify, repack or export review work.",
        "ストレッチヒートマップ確認を作成し、歪みの大きいアイランドをリラックス、矩形化、再パック、書き出し確認の前に見つけやすくします。",
    ),
    'SUV_OT_clear_stretch_heatmap': (
        "Remove the helper heatmap preview when you want to return the scene to normal display after distortion inspection.",
        "歪み確認後にシーン表示を通常状態へ戻したいときに、補助ヒートマップ表示を解除します。",
    ),
    'SUV_OT_create_checker_material': (
        "Create and assign a checker preview material so texel consistency, seam readability and visible shell distortion can be judged more quickly.",
        "チェッカープレビュー材質を作成・適用し、テクセル一貫性、シームの見やすさ、目視できるシェル歪みをより素早く判断できるようにします。",
    ),
    'SUV_OT_remove_checker_materials': (
        "Remove generated checker materials after inspection so the objects return to their normal material presentation.",
        "確認後に生成チェッカーマテリアルを解除し、オブジェクトを通常のマテリアル表示へ戻します。",
    ),
}.items():
    _cls = globals().get(_cls_name)
    if _cls is not None:
        try:
            _cls.bl_description = _suv_bilingual_desc(_desc_pair[0], _desc_pair[1])
        except Exception:
            pass


_TEXT.update({
    "ui.section.export_help": ("Export Help", "書き出し補助"),
    "ui.export_help.hint": (
        "Export-facing helpers now carry richer bilingual guidance so working UV, render UV and report steps are easier to distinguish.",
        "書き出し向け補助には、作業UV、レンダーUV、レポート工程を区別しやすい、より詳しい日英案内を追加しています。",
    ),
})

for _cls_name, _desc_pair in {
    'SUV_OT_bake_uv_prep': (
        "Prepare Bake or Lightmap-oriented UV slots so downstream baking and export tools can use a dedicated role instead of overwriting the current working layer.",
        "Bake や Lightmap 向けの UV スロットを準備し、現在の作業層を上書きせずに、下流のベイク・書き出しツールが役割専用 UV を使えるようにします。",
    ),
    'SUV_OT_pack_pro': (
        "Run the suite's finishing pack pass so repaired or role-specific shells can be arranged into a cleaner final export layout.",
        "修復済みまたは役割専用シェルを、より整った最終書き出しレイアウトへ配置できるよう、ツールセットの仕上げパック処理を実行します。",
    ),
    'SUV_OT_create_checker_material': (
        "Assign a checker preview material so shell scale, distortion and spacing can be checked visually before export, bake or review handoff.",
        "書き出し、ベイク、確認引き渡し前に、シェルのスケール、歪み、間隔を視覚的に確認できるよう、チェッカープレビュー用マテリアルを割り当てます。",
    ),
    'SUV_OT_batch_export_texel_report': (
        "Write a multi-object texel report so density consistency can be reviewed before export or shared asset handoff.",
        "複数オブジェクトのテクセルレポートを書き出し、書き出しや共有アセット引き渡し前に密度の一貫性を確認できるようにします。",
    ),
    'SUV_OT_uvmap_set_render': (
        "Mark the chosen UV layer as the render or export role when downstream tools should treat that layer as the primary output target.",
        "下流ツールでその UV 層を主出力対象として扱いたいときに、選択層をレンダー・書き出し役割として指定します。",
    ),
}.items():
    try:
        _apply_desc_override(_cls_name, *_desc_pair)
    except Exception:
        pass


for _cls_name, _desc_pair in {
    'SUV_OT_inspector_scan': (
        "Run the inspector scan again to rebuild the current issue cache from the latest UV state before deeper repair or export decisions.",
        "より深い修復や書き出し判断の前に、最新のUV状態から問題キャッシュを再構築するため、検査を再実行します。",
    ),
    'SUV_OT_workspace_auto_repair': (
        "Apply the suite's safer automatic repair pass so common cached UV issues are corrected before you move on to packing or export.",
        "パックや書き出しへ進む前に、一般的なキャッシュ済みUV問題を修正するため、ツールセットの安全寄り自動修復を適用します。",
    ),
    'SUV_OT_inspector_fix_flipped': (
        "Repair flipped UV islands that remained reversed after unwrap, transfer, symmetry or packing steps.",
        "展開、転送、対称処理、パック後に反転したまま残っているUVアイランドを修正します。",
    ),
    'SUV_OT_inspector_rescan': (
        "Rescan using the existing inspector workflow so the cached issue list matches the UV state after manual edits or automatic fixes.",
        "手動編集や自動修復後のUV状態に問題一覧を合わせるため、既存の検査ワークフローで再スキャンします。",
    ),
    'SUV_OT_inspector_clear_cache': (
        "Clear cached inspector results when you want to discard older issue memory before a fresh validation pass.",
        "新しい検証を行う前に、古い問題記録を破棄したいときに検査キャッシュをクリアします。",
    ),
    'SUV_OT_cleanup_bridge': (
        "Open bridge-style cleanup helpers so healing, straighten, normalize and other cleanup-oriented actions are easier to reach from one entry point.",
        "Heal、直線化、正規化などのクリーンアップ寄り操作へ1つの入口から進みやすくするため、ブリッジ型クリーンアップ補助を開きます。",
    ),
    'SUV_OT_repair_flipped_islands': (
        "Run a dedicated flipped-island repair step when mirrored or reversed UV faces still remain after the main inspector flow.",
        "メインの検査フロー後もミラー反転や裏返りが残る場合に、専用の反転アイランド修復を実行します。",
    ),
}.items():
    try:
        cls = globals().get(_cls_name)
        if cls is not None:
            cls.bl_description = _desc_pair[0]
            _register_dynamic_tooltip(cls, _desc_pair)
    except Exception:
        pass


for _cls_name, _desc_pair in {
    'SUV_OT_stack_pro': (
        "Stack compatible UV islands to reuse space more aggressively when mirrored or repeated shells should share one footprint.",
        "互換性のあるUVアイランドを重ね、ミラーや反復シェルが1つの占有領域を共有できるようにして、スペースをより強く再利用します。",
    ),
    'SUV_OT_stack_grouped': (
        "Stack grouped islands so repeated shell families can align to the same footprint before the final pack pass.",
        "グループ化されたアイランドを重ね、反復シェル群が最終パック前に同じ占有領域へ揃うようにします。",
    ),
    'SUV_OT_unstack_groups': (
        "Unstack grouped islands when shared shells need to be separated again for custom edits, baking or role-specific output.",
        "共有配置されたシェルをカスタム編集、ベイク、役割別出力のために再び分離したいときに、グループスタックを解除します。",
    ),
    'SUV_OT_priority_density_pack': (
        "Pack while respecting density priority so important shells keep more texel emphasis during layout optimization.",
        "密度優先度を尊重しながらパックし、レイアウト最適化中も重要シェルがより多くのテクセル比重を保てるようにします。",
    ),
    'SUV_OT_layout_audit_relayout': (
        "Rebuild the arrangement from current audit context so the next layout pass starts from detected shell conditions instead of older placement assumptions.",
        "現在の監査文脈から配置を組み直し、古い配置前提ではなく検出済みシェル状態を基に次のレイアウト調整を始められるようにします。",
    ),
}.items():
    _cls = globals().get(_cls_name)
    if _cls is not None:
        try:
            _cls.bl_description = _suv_bilingual_desc(_desc_pair[0], _desc_pair[1])
        except Exception:
            pass


# --- symmetry deck tooltip extension -----------------------------
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _suv_current_build_version_tuple()
except Exception:
    pass

for _cls_name, _desc_pair in {
    'SUV_OT_sym_detect_pairs': (
        "Detect likely mirrored shell pairs so later mirror, stack or repair steps can start from relationship-aware matches instead of manual guesswork.",
        "後続のミラー、スタック、修復を手作業の推測ではなく関係性に基づく一致から始められるよう、対になりそうなミラーシェルを検出します。",
    ),
    'SUV_OT_sym_mirror_uv': (
        "Mirror UVs from the approved side to its detected partner when one half of the asset already represents the cleaner or intended shell state.",
        "アセットの片側がすでにより整った、または意図したシェル状態を表しているときに、その承認側から対応側へUVをミラーします。",
    ),
    'SUV_OT_stack_symmetry_topology': (
        "Stack mirrored shells by topology so symmetrical parts can share the same footprint before the final density and packing pass.",
        "トポロジー基準でミラーシェルをスタックし、最終的な密度調整やパックの前に対称パーツが同じ配置を共有できるようにします。",
    ),
    'SUV_OT_hotspot_symmetry_refill': (
        "Refill mirrored hotspot cells so trimsheet or hotspot layouts recover balanced reusable spacing after symmetry edits.",
        "トリムシートやホットスポット配置が対称編集後にも再利用しやすい間隔バランスへ戻るよう、ミラーされたホットスポットセルを再充填します。",
    ),
    'SUV_OT_sym_stack': (
        "Stack shells using stored symmetry relationships when repeated left-right islands should be collapsed into a shared layout intentionally.",
        "左右の反復アイランドを意図的に共有配置へ重ねたいときに、保存された対称関係を使ってシェルをスタックします。",
    ),
    'SUV_OT_sym_seams': (
        "Mirror or build seam decisions across a detected symmetry relationship so both sides follow a more consistent cut plan.",
        "検出済みの対称関係に沿ってシーム判断をミラーまたは生成し、両側がより一貫した切り分け計画に従うようにします。",
    ),
}.items():
    _cls = globals().get(_cls_name)
    if _cls is not None:
        try:
            _cls.bl_description = _suv_bilingual_desc(_desc_pair[0], _desc_pair[1])
        except Exception:
            pass
