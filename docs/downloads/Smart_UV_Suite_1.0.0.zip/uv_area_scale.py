# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Mesh-area based UV island scale matching for Smart UV Suite.

This module runs after an unwrap/projection solve and before final packing.  It
keeps each selected UV island's shape and position center, but uniformly scales
that island so its UV area ratio matches the corresponding original mesh surface
area ratio.  Only the strict UV Editor fully-face-selected scope is modified.
"""
from __future__ import annotations

import math
from typing import Iterable, Any

import bpy
import bmesh
from mathutils import Vector

_EPS = 1.0e-10


def _active_uv_layer(bm):
    try:
        layer = bm.loops.layers.uv.active
        if layer is not None:
            return layer
    except Exception:
        pass
    return bm.loops.layers.uv.verify()


def _face_index(face) -> int:
    try:
        return int(getattr(face, 'index', -1))
    except Exception:
        return -1


def _loop_index(loop) -> int:
    try:
        return int(getattr(loop, 'index', -1))
    except Exception:
        return -1


def _vec2(value) -> Vector:
    try:
        return Vector((float(value[0]), float(value[1])))
    except Exception:
        return Vector((0.0, 0.0))


def _uv_polygon_area(face, uv_layer) -> float:
    loops = list(getattr(face, 'loops', ()) or ())
    if len(loops) < 3:
        return 0.0
    area = 0.0
    pts = [_vec2(loop[uv_layer].uv) for loop in loops]
    for i, p in enumerate(pts):
        q = pts[(i + 1) % len(pts)]
        area += p.x * q.y - q.x * p.y
    return abs(area) * 0.5


def _world_mesh_face_area(obj, face) -> float:
    loops = list(getattr(face, 'loops', ()) or ())
    if len(loops) < 3:
        return 0.0
    try:
        mw = getattr(obj, 'matrix_world', None)
    except Exception:
        mw = None
    pts = []
    for loop in loops:
        try:
            co = loop.vert.co.copy()
            if mw is not None:
                co = mw @ co
            pts.append(co)
        except Exception:
            return 0.0
    origin = pts[0]
    area = 0.0
    for i in range(1, len(pts) - 1):
        try:
            area += (pts[i] - origin).cross(pts[i + 1] - origin).length * 0.5
        except Exception:
            pass
    return float(max(0.0, area))


def _loop_uv_by_vert(face, edge, uv_layer) -> dict[int, Vector]:
    out: dict[int, Vector] = {}
    try:
        verts = {int(v.index) for v in edge.verts}
    except Exception:
        verts = set()
    for loop in getattr(face, 'loops', ()) or ():
        try:
            vi = int(loop.vert.index)
            if vi in verts:
                out[vi] = _vec2(loop[uv_layer].uv)
        except Exception:
            pass
    return out


def _same_uv_edge(face_a, face_b, edge, uv_layer, eps: float = 1.0e-6) -> bool:
    a = _loop_uv_by_vert(face_a, edge, uv_layer)
    b = _loop_uv_by_vert(face_b, edge, uv_layer)
    if len(a) < 2 or len(b) < 2:
        return False
    try:
        for vert in edge.verts:
            vi = int(vert.index)
            if vi not in a or vi not in b:
                return False
            if (a[vi] - b[vi]).length > eps:
                return False
        return True
    except Exception:
        return False


def _selected_faces_from_attrs(obj, bm, uv_layer) -> set[int]:
    try:
        me = obj.data
        attrs = getattr(me, 'attributes', None)
        face_attr = attrs.get('.uv_select_face') if attrs is not None else None
        vert_attr = attrs.get('.uv_select_vert') if attrs is not None else None
        if face_attr is not None and vert_attr is not None:
            face_flags = [bool(getattr(x, 'value', False)) for x in getattr(face_attr, 'data', [])]
            vert_flags = [bool(getattr(x, 'value', False)) for x in getattr(vert_attr, 'data', [])]
            out = set()
            for f in bm.faces:
                fi = _face_index(f)
                if fi < 0 or fi >= len(face_flags) or not face_flags[fi]:
                    continue
                ok = True
                for loop in f.loops:
                    li = _loop_index(loop)
                    if li < 0 or li >= len(vert_flags) or not vert_flags[li]:
                        ok = False
                        break
                if ok:
                    out.add(fi)
            if out:
                return out
    except Exception:
        pass
    out = set()
    try:
        for f in bm.faces:
            if all(bool(loop[uv_layer].select) for loop in f.loops):
                out.add(_face_index(f))
    except Exception:
        pass
    return {i for i in out if i >= 0}


def _uv_islands_from_selected_faces(bm, uv_layer, selected_faces: set[int]) -> list[list[Any]]:
    face_by_index = {int(f.index): f for f in bm.faces if int(f.index) in selected_faces}
    if not face_by_index:
        return []
    adjacency: dict[int, set[int]] = {fi: set() for fi in face_by_index}
    try:
        bm.edges.ensure_lookup_table()
    except Exception:
        pass
    for edge in bm.edges:
        linked = []
        for loop in getattr(edge, 'link_loops', ()) or ():
            try:
                fi = int(loop.face.index)
                if fi in face_by_index and loop.face not in linked:
                    linked.append(loop.face)
            except Exception:
                pass
        if len(linked) < 2:
            continue
        for i in range(len(linked)):
            for j in range(i + 1, len(linked)):
                fa, fb = linked[i], linked[j]
                if _same_uv_edge(fa, fb, edge, uv_layer):
                    ia = int(fa.index); ib = int(fb.index)
                    adjacency.setdefault(ia, set()).add(ib)
                    adjacency.setdefault(ib, set()).add(ia)
    islands = []
    remaining = set(face_by_index)
    while remaining:
        root = remaining.pop()
        stack = [root]
        comp = {root}
        while stack:
            cur = stack.pop()
            for nb in adjacency.get(cur, ()):  # UV-contiguous selected faces only
                if nb in remaining:
                    remaining.remove(nb)
                    comp.add(nb)
                    stack.append(nb)
        islands.append([face_by_index[i] for i in sorted(comp) if i in face_by_index])
    return islands


def _island_center(loops, uv_layer) -> Vector:
    if not loops:
        return Vector((0.0, 0.0))
    acc = Vector((0.0, 0.0))
    for loop in loops:
        acc += _vec2(loop[uv_layer].uv)
    return acc / float(max(1, len(loops)))


def match_selected_island_scale_to_mesh_area(context, obj=None, *, selected_faces: Iterable[int] | None = None) -> bool:
    """Scale selected UV islands by original mesh surface-area ratio.

    The total selected UV area is preserved.  Only the relative scale between
    islands changes, so the following final pack decides placement.  This mirrors
    Blender's average-islands-scale intent, but it is strict-scope safe, works
    on the selected UV face set only, and uses world-space mesh face area.
    """
    if obj is None:
        obj = getattr(context, 'edit_object', None) or getattr(context, 'active_object', None)
    if obj is None or getattr(obj, 'type', '') != 'MESH':
        return False
    old_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
    changed = False
    try:
        if old_mode != 'EDIT':
            try:
                context.view_layer.objects.active = obj
            except Exception:
                pass
            bpy.ops.object.mode_set(mode='EDIT')
            changed = True
    except Exception:
        return False
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = _active_uv_layer(bm)
        bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
        bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
        sel = {int(i) for i in (selected_faces or []) if int(i) >= 0}
        if not sel:
            sel = _selected_faces_from_attrs(obj, bm, uv_layer)
        if not sel:
            return False
        islands = _uv_islands_from_selected_faces(bm, uv_layer, sel)
        if not islands:
            return False
        data = []
        total_mesh = 0.0
        total_uv = 0.0
        for faces in islands:
            mesh_area = sum(_world_mesh_face_area(obj, f) for f in faces)
            uv_area = sum(_uv_polygon_area(f, uv_layer) for f in faces)
            if mesh_area <= _EPS or uv_area <= _EPS:
                continue
            loops = [loop for f in faces for loop in f.loops]
            data.append((faces, loops, mesh_area, uv_area))
            total_mesh += mesh_area
            total_uv += uv_area
        if len(data) <= 1 or total_mesh <= _EPS or total_uv <= _EPS:
            return False
        density = total_uv / total_mesh
        changed_any = False
        for _faces, loops, mesh_area, uv_area in data:
            target_uv_area = max(_EPS, mesh_area * density)
            scale = math.sqrt(max(_EPS, target_uv_area) / max(_EPS, uv_area))
            if abs(scale - 1.0) <= 1.0e-5:
                continue
            # Keep pathological cases bounded.  Extremely distorted source UVs
            # still become usable without exploding outside the final pack input.
            scale = max(1.0e-5, min(1.0e5, float(scale)))
            center = _island_center(loops, uv_layer)
            for loop in loops:
                uv = _vec2(loop[uv_layer].uv)
                loop[uv_layer].uv = center + (uv - center) * scale
            changed_any = True
        if changed_any:
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return bool(changed_any)
    except Exception:
        return False
    finally:
        if changed and old_mode != 'EDIT':
            try:
                bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                pass
