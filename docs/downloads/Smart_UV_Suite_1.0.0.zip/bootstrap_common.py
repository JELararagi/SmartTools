# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

from typing import Iterable, Sequence

import sys

import bpy

# The former Window-menu bootstrap is intentionally disabled because
# UV Suite is now shown by standard 3D View N-panel registration.

_STALE_EXTERNAL_ADDONS = (
    'bl_ext.user_default.smart_tools_window_prototype',
    'bl_ext.user_default.smart_tools_independent_window_shell',
    'bl_ext.user_default.view_plane_generator',
    'bl_ext.user_default.smart_tools_browser_prototype',
    'bl_ext.user_default.smart_tools_window',
    'smart_tools_window_prototype',
    'smart_tools_independent_window_shell',
    'view_plane_generator',
    'smart_tools_browser_prototype',
    'smart_tools_window',
)


def _schedule_userpref_save() -> None:
    # 1.8.169: no lifecycle timer; preferences are saved only by explicit UI operations.
    return None


def cleanup_stale_external_addons(*, save_preferences: bool = False) -> bool:
    # 1.8.169: never remove foreign add-ons or sys.modules entries.
    return False



def cleanup_empty_user_interface_keymaps() -> bool:
    # Startup-safe Blender 5.1 behavior: do not inspect or remove keymaps from
    # add-on registration.  Empty/stale keymaps are harmless compared with the
    # native RNA crash observed when keymap_items/properties are traversed.
    return False


def ensure_user_interface_keymap() -> bool:
    return False

def _is_addon_preferences_class(cls: type) -> bool:
    try:
        return isinstance(cls, type) and issubclass(cls, bpy.types.AddonPreferences)
    except Exception:
        return False


def _capture_addon_preferences_proxy(cls: type) -> bool:
    if not _is_addon_preferences_class(cls):
        return False
    try:
        package = str(getattr(cls, '__module__', '') or '').split('.')[0]
        if __package__:
            proxy = __import__(f'{__package__}.preferences_proxy', fromlist=['register_preferences_class'])
        else:
            proxy = __import__(f'{package}.preferences_proxy', fromlist=['register_preferences_class'])
        register = getattr(proxy, 'register_preferences_class', None)
        if callable(register):
            register(cls)
    except Exception:
        pass
    return True


def _registered_bl_idname(cls: type) -> str:
    try:
        return str(getattr(cls, 'bl_idname', '') or '')
    except Exception:
        return ''


def _rna_class_ready(cls: type) -> bool:
    try:
        rna = getattr(cls, 'bl_rna', None)
        identifier = str(getattr(rna, 'identifier', '') or '')
        return bool(identifier) and identifier not in {'Operator', 'OperatorProperties', 'UnknownType', 'bpy_struct'}
    except Exception:
        return False


def _rna_property_names(prop_defs) -> set[str]:
    names: set[str] = set()
    if prop_defs is None:
        return names
    try:
        names.update(str(k) for k in prop_defs.keys())
    except Exception:
        pass
    try:
        for prop in prop_defs:
            ident = str(getattr(prop, 'identifier', '') or '')
            if ident:
                names.add(ident)
    except Exception:
        pass
    return names


def _operator_rna_property_names_from_idname(bl_idname: str) -> set[str]:
    names: set[str] = set()
    text = str(bl_idname or '').strip()
    if not text or '.' not in text:
        return names
    group, name = text.split('.', 1)
    try:
        op_group = getattr(getattr(bpy, 'ops', None), group, None)
        op = getattr(op_group, name, None) if op_group is not None else None
        rna = op.get_rna_type() if op is not None else None
        names.update(_rna_property_names(getattr(rna, 'properties', None)))
    except Exception:
        pass
    return names


def _operator_exists_from_idname(bl_idname: str) -> bool:
    text = str(bl_idname or '').strip()
    if not text or '.' not in text:
        return False
    group, name = text.split('.', 1)
    try:
        op_group = getattr(getattr(bpy, 'ops', None), group, None)
        op = getattr(op_group, name, None) if op_group is not None else None
        if op is None:
            return False
        get_rna = getattr(op, 'get_rna_type', None)
        return callable(get_rna) and get_rna() is not None
    except Exception:
        return False


def _already_registered_subclass_error(exc: BaseException) -> bool:
    try:
        return 'already registered as a subclass' in str(exc)
    except Exception:
        return False


def _retry_register_after_subclass_collision(cls: type) -> bool:
    """Never evict a same-name or same-id class outside the exact ownership ledger."""
    del cls
    return False


def _class_annotation_property_names(cls: type) -> set[str]:
    names: set[str] = set()
    try:
        annotations = getattr(cls, '__annotations__', {}) or {}
        names.update(str(k) for k in annotations.keys())
    except Exception:
        pass
    return names


def _registered_class_has_required_props(cls: type) -> bool:
    required = {str(v) for v in (getattr(cls, '_smart_uv_required_rna_props', set()) or set()) if str(v)}
    if not required:
        return True

    # Blender 5.x can expose custom operator RNA properties through bpy.ops
    # earlier/more reliably than through cls.bl_rna during extension hot-reload.
    # Validate against every available source before treating the registration as
    # failed; otherwise valid operators may be immediately unregistered during
    # install and the add-on becomes impossible to enable.
    props: set[str] = set()
    try:
        props.update(_rna_property_names(getattr(getattr(cls, 'bl_rna', None), 'properties', None)))
    except Exception:
        pass
    try:
        props.update(_operator_rna_property_names_from_idname(getattr(cls, 'bl_idname', '')))
    except Exception:
        pass
    if required.issubset(props):
        return True

    # Final fallback: if the class is registered but Blender has not exposed the
    # operator-property RNA yet, trust materialized bpy.props annotations. This is
    # safer than aborting installation; later UI drawing still checks bpy.ops RNA
    # before assigning operator properties.
    try:
        annotation_props = _class_annotation_property_names(cls)
    except Exception:
        annotation_props = set()
    return required.issubset(annotation_props)


def _unregister_same_operator_id(cls: type) -> None:
    # 1.8.169: stale/foreign class teardown is handled only by explicit ownership ledger.
    return None


def safe_register_class(cls: type) -> bool:
    if not isinstance(cls, type):
        return False
    try:
        from . import ownership_runtime_18168 as _ownership
        return bool(_ownership.register_class(cls))
    except Exception:
        return False

def safe_unregister_class(cls: type) -> None:
    if not isinstance(cls, type):
        return
    try:
        from . import ownership_runtime_18168 as _ownership
        _ownership.unregister_class(cls)
    except Exception:
        pass


def install_register_class_guard(_context=None):
    """Return the legacy scope release hook without patching Blender globals."""
    del _context
    released = False

    def release() -> None:
        nonlocal released
        if released:
            return
        released = True

    return release


def safe_register_classes(classes: Iterable[type], *, registered: list[type] | None = None) -> tuple[type, ...]:
    out: list[type] = []
    for cls in classes:
        if safe_register_class(cls):
            out.append(cls)
            if isinstance(registered, list):
                registered.append(cls)
    return tuple(out)


def safe_unregister_classes(classes: Iterable[type]) -> None:
    for cls in reversed(tuple(classes)):
        safe_unregister_class(cls)


def iter_window_menu_classes(menu_names: Sequence[str] | None = None):
    del menu_names
    return iter(())


def iter_window_menu_draw_functions(menu_cls) -> tuple[object, ...]:
    del menu_cls
    return ()


def purge_window_menu_callbacks(menu_cls, matcher, *, keep=None) -> int:
    del menu_cls, matcher, keep
    return 0


def install_window_menu_entry(draw_fn, *, matcher=None, menu_names=None, install_all=False, redraw_area_types=None) -> tuple[str, ...]:
    del draw_fn, matcher, menu_names, install_all, redraw_area_types
    return ()


def remove_window_menu_entry(draw_fn=None, *, matcher=None, menu_names=None, redraw_area_types=None) -> None:
    del draw_fn, matcher, menu_names, redraw_area_types
    return None


def remove_window_menu_entry_if_unused(*args, **kwargs) -> None:
    del args, kwargs
    return None


def schedule_shared_window_menu_button_refresh(*args, **kwargs) -> None:
    del args, kwargs
    return None


def schedule_window_menu_refresh(*args, **kwargs) -> None:
    del args, kwargs
    return None


def tag_redraw_window_menu_areas(area_types: Sequence[str] | None = None) -> None:
    del area_types
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    except Exception:
        wm = None
    for window in getattr(wm, 'windows', ()) if wm is not None else ():
        screen = getattr(window, 'screen', None)
        for area in getattr(screen, 'areas', ()) if screen is not None else ():
            try:
                if str(getattr(area, 'type', '') or '') == 'VIEW_3D':
                    area.tag_redraw()
            except Exception:
                pass
