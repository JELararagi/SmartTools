from . import core as _core
from . import ui as _ui
from . import flow as _flow
from . import legacy_operators as _legacy
from . import pro_operators as _pro
from . import selection_operators as _select
from . import symmetry_atlas_operators as _sym
from . import native_stage as _stage
from . import addon_runtime as _tool_runtime

bpy = _core.bpy
bmesh = _core.bmesh
math = _core.math
Vector = _core.Vector

_PATCH_MODULES = (_core, _ui, _flow, _legacy, _pro, _select, _sym, _stage, _tool_runtime)


def _patch_name(name, value):
    for mod in _PATCH_MODULES:
        try:
            if hasattr(mod, name):
                setattr(mod, name, value)
        except Exception:
            pass


_ORIG_BUILD_ISLANDS = _core.build_islands
_ORIG_PACK_NATIVE = getattr(_core, '_suv_run_pack_islands_native', None)
_ORIG_UNWRAP_NATIVE = getattr(_core, '_suv_run_unwrap_native', None)
_ORIG_MIN_STRETCH_NATIVE = getattr(_core, '_suv_run_minimize_stretch_native', None)


def _face_uv_centroid_safe(face, uv_layer):
    try:
        return Vector(_core._face_uv_centroid(face, uv_layer))
    except Exception:
        pts = [Vector(l[uv_layer].uv) for l in getattr(face, 'loops', [])]
        if not pts:
            return Vector((0.0, 0.0))
        return Vector((sum(p.x for p in pts) / len(pts), sum(p.y for p in pts) / len(pts)))



def _compute_island_tool_runtime_metrics_max(isl, uv_layer):
    loops = list(getattr(isl, 'loops', []) or [])
    faces = list(getattr(isl, 'faces', []) or [])
    pts = []
    tiles = set()
    has_pin = False
    vert_ids = set()
    for l in loops:
        try:
            uv = Vector(l[uv_layer].uv)
        except Exception:
            continue
        pts.append(uv)
        tiles.add((int(math.floor(float(uv.x))), int(math.floor(float(uv.y)))))
        try:
            if bool(getattr(l[uv_layer], 'pin_uv', False)):
                has_pin = True
        except Exception:
            pass
        try:
            vert_ids.add(int(l.vert.index))
        except Exception:
            pass
    isl.uv_points = pts
    isl.udim_tiles = tiles
    isl.has_pin = has_pin
    isl.vert_ids = vert_ids
    try:
        isl.face_sig = tuple(sorted(int(f.index) for f in faces))
    except Exception:
        pass
    if not pts:
        isl.bbox_min = Vector((0.0, 0.0))
        isl.bbox_max = Vector((0.0, 0.0))
        isl.uv_centroid = Vector((0.0, 0.0))
        isl.axis = Vector((1.0, 0.0))
        isl.signed_area = 0.0
        isl.abs_area = 0.0
        return isl
    xs = [float(p.x) for p in pts]
    ys = [float(p.y) for p in pts]
    isl.bbox_min = Vector((min(xs), min(ys)))
    isl.bbox_max = Vector((max(xs), max(ys)))
    signed_area = 0.0
    abs_area = 0.0
    centroid_acc = Vector((0.0, 0.0))
    weight_total = 0.0
    for face in faces:
        try:
            fa = float(_core._signed_uv_area(face, uv_layer))
        except Exception:
            fa = 0.0
        aa = abs(fa)
        signed_area += fa
        abs_area += aa
        if aa > 1.0e-12:
            centroid_acc += _face_uv_centroid_safe(face, uv_layer) * aa
            weight_total += aa
    isl.signed_area = float(signed_area)
    isl.abs_area = float(abs_area)
    if weight_total > 1.0e-12:
        isl.uv_centroid = centroid_acc / weight_total
    else:
        isl.uv_centroid = Vector((sum(xs) / len(xs), sum(ys) / len(ys)))
    try:
        unique = _core._unique_points_2d(pts)
    except Exception:
        seen = set(); unique = []
        for p in pts:
            key = (round(float(p.x), 6), round(float(p.y), 6))
            if key in seen:
                continue
            seen.add(key)
            unique.append(Vector(p))
    try:
        _center, axis = _core._pca_axis_2d(unique if len(unique) >= 2 else pts)
    except Exception:
        axis = None
    isl.axis = Vector(axis) if axis is not None else Vector((1.0, 0.0))
    return isl



def _build_islands_max(bm, uv_layer, faces_subset=None, eps=1.0e-5):
    islands = list(_ORIG_BUILD_ISLANDS(bm, uv_layer, faces_subset=faces_subset, eps=eps) or [])
    for isl in islands:
        try:
            _compute_island_tool_runtime_metrics_max(isl, uv_layer)
        except Exception:
            pass
    return islands



def _selection_from_context_max(context, obj, bm, uv_layer):
    try:
        uv_sync = bool(_core._is_uv_sync(context))
    except Exception:
        uv_sync = False
    sel_faces = set()
    sel_loops = []
    active_face = getattr(bm.faces, 'active', None)
    if uv_sync:
        for f in bm.faces:
            if bool(getattr(f, 'select', False)):
                sel_faces.add(f)
                sel_loops.extend(list(getattr(f, 'loops', [])))
        return list(sel_faces), sel_loops, active_face, 'MESH_SYNC'
    seen_loop_ids = set()
    try:
        # The UV selection lives on the BMesh loops.  The mesh selection only
        # stands in when no UV element is selected at all (batch flows).
        # Blender keeps the flags on faces the mesh selection hides from the UV editor.
        any_uv_selected = any(l.uv_select_vert or l.uv_select_edge for f in bm.faces if f.select and not f.hide for l in f.loops)
        for f in bm.faces:
            for l in f.loops:
                selected = bool(f.select and (l.uv_select_vert or l.uv_select_edge))
                if not selected and not any_uv_selected:
                    try:
                        selected = bool(getattr(l.vert, 'select', False)) and bool(getattr(l.edge, 'select', False))
                    except Exception:
                        selected = False
                if not selected:
                    continue
                sel_faces.add(f)
                lid = int(getattr(l, 'index', id(l)))
                if lid in seen_loop_ids:
                    continue
                seen_loop_ids.add(lid)
                sel_loops.append(l)
        if sel_loops:
            if active_face is not None and active_face not in sel_faces:
                active_face = next(iter(sel_faces), None)
            return list(sel_faces), sel_loops, active_face, 'UV_BM_LOOP'
    except Exception:
        pass
    try:
        m = obj.data
        uv = getattr(getattr(m, 'uv_layers', None), 'active', None)
        data = getattr(uv, 'data', None)
        if data is not None:
            selected_indices = set()
            for i, d in enumerate(data):
                try:
                    if bool(getattr(d, 'select', False)) or bool(getattr(d, 'select_edge', False)):
                        selected_indices.add(i)
                except Exception:
                    pass
            if selected_indices:
                for f in bm.faces:
                    for l in f.loops:
                        idx = int(getattr(l, 'index', -1))
                        if idx not in selected_indices:
                            continue
                        sel_faces.add(f)
                        if idx in seen_loop_ids:
                            continue
                        seen_loop_ids.add(idx)
                        sel_loops.append(l)
                if sel_loops:
                    if active_face is not None and active_face not in sel_faces:
                        active_face = next(iter(sel_faces), None)
                    return list(sel_faces), sel_loops, active_face, 'UV_LOOP'
    except Exception:
        pass
    for f in bm.faces:
        if bool(getattr(f, 'select', False)):
            sel_faces.add(f)
            sel_loops.extend(list(getattr(f, 'loops', [])))
    if active_face is not None and active_face not in sel_faces:
        active_face = next(iter(sel_faces), None)
    return list(sel_faces), sel_loops, active_face, 'FALLBACK_FACE'



def _enum_preference(op, prop_name, choices):
    try:
        items = list(_core._suv_operator_enum_items(op, prop_name) or [])
    except Exception:
        items = []
    for choice in choices:
        if choice in items:
            return choice
    return items[0] if items else None



def _run_pack_native_max(context, margin_uv=0.0, rotation_step_deg=15, lock_pinned=True, **_ignored_kwargs):
    op = bpy.ops.uv.pack_islands
    try:
        keys = set(_core._suv_operator_property_keys(op) or [])
    except Exception:
        keys = set()
    kwargs = {}
    if 'margin' in keys:
        kwargs['margin'] = max(0.0, float(margin_uv))
    if 'margin_method' in keys:
        value = _enum_preference(op, 'margin_method', ('FRACTION', 'ADD', 'SCALED'))
        if value is not None:
            kwargs['margin_method'] = value
    if 'rotate' in keys:
        kwargs['rotate'] = (int(rotation_step_deg) != 0)
    if 'rotate_method' in keys:
        value = _enum_preference(op, 'rotate_method', ('ANY', 'AXIS_ALIGNED', 'AXIS_ALIGNED_X', 'AXIS_ALIGNED_Y'))
        if value is not None:
            kwargs['rotate_method'] = value
    if 'scale' in keys:
        kwargs['scale'] = True
    if 'merge_overlap' in keys:
        kwargs['merge_overlap'] = False
    if 'shape_method' in keys:
        value = _enum_preference(op, 'shape_method', ('CONCAVE', 'AABB'))
        if value is not None:
            kwargs['shape_method'] = value
    if 'pin' in keys:
        if lock_pinned:
            value = _enum_preference(op, 'pin', ('LOCKED', 'LOCKED_PINS', 'PINNED'))
        else:
            value = _enum_preference(op, 'pin', ('DISABLED', 'OFF', 'UNLOCKED'))
        if value is not None:
            kwargs['pin'] = value
    ok, err = _core._run_uv_op(context, op, **kwargs)
    if ok:
        return ok, err
    if callable(_ORIG_PACK_NATIVE):
        try:
            return _ORIG_PACK_NATIVE(context, margin_uv=margin_uv, rotation_step_deg=rotation_step_deg, lock_pinned=lock_pinned, **_ignored_kwargs)
        except Exception:
            pass
    return ok, err



def _run_unwrap_native_max(context, method='ANGLE_BASED', margin=0.001, fill_holes=True, correct_aspect=True, use_subsurf_data=False):
    op = bpy.ops.uv.unwrap
    try:
        keys = set(_core._suv_operator_property_keys(op) or [])
    except Exception:
        keys = set()
    kwargs = {}
    if 'method' in keys:
        value = _enum_preference(op, 'method', (str(method or 'ANGLE_BASED').upper(), 'ANGLE_BASED', 'MINIMUM_STRETCH', 'CONFORMAL'))
        if value is not None:
            kwargs['method'] = value
    if 'margin_method' in keys:
        value = _enum_preference(op, 'margin_method', ('FRACTION', 'ADD', 'SCALED'))
        if value is not None:
            kwargs['margin_method'] = value
    if 'margin' in keys:
        kwargs['margin'] = max(0.0, float(margin))
    if 'fill_holes' in keys:
        kwargs['fill_holes'] = bool(fill_holes)
    if 'correct_aspect' in keys:
        kwargs['correct_aspect'] = bool(correct_aspect)
    if 'use_subsurf_data' in keys:
        kwargs['use_subsurf_data'] = bool(use_subsurf_data)
    if 'iterations' in keys and str(kwargs.get('method', '')).upper() == 'MINIMUM_STRETCH':
        kwargs['iterations'] = 32
    if 'no_flip' in keys and str(kwargs.get('method', '')).upper() == 'MINIMUM_STRETCH':
        kwargs['no_flip'] = True
    ok, err = _core._run_uv_op(context, op, **kwargs)
    if ok:
        return ok, err
    if callable(_ORIG_UNWRAP_NATIVE):
        try:
            return _ORIG_UNWRAP_NATIVE(context, method=method, margin=margin, fill_holes=fill_holes, correct_aspect=correct_aspect, use_subsurf_data=use_subsurf_data)
        except Exception:
            pass
    return ok, err



def _run_minimize_stretch_native_max(context, iterations=100, fill_holes=True):
    op = bpy.ops.uv.minimize_stretch
    try:
        keys = set(_core._suv_operator_property_keys(op) or [])
    except Exception:
        keys = set()
    kwargs = {}
    if 'iterations' in keys:
        kwargs['iterations'] = max(1, int(iterations))
    if 'fill_holes' in keys:
        kwargs['fill_holes'] = bool(fill_holes)
    if 'blend' in keys:
        kwargs['blend'] = 0.0
    ok, err = _core._run_uv_op(context, op, **kwargs)
    if ok:
        return ok, err
    if callable(_ORIG_MIN_STRETCH_NATIVE):
        try:
            return _ORIG_MIN_STRETCH_NATIVE(context, iterations=iterations, fill_holes=fill_holes)
        except Exception:
            pass
    return ok, err



def _suv_mark_smart_seams_max(bm, angle_threshold, faces_subset=None, include_boundary=True, include_sharp=True, include_material=True):
    face_set = set(faces_subset) if faces_subset is not None else None
    try:
        bm.edges.ensure_lookup_table()
    except Exception:
        pass
    try:
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
    except Exception:
        uv_layer = None
    seam_count = 0
    for edge in getattr(bm, 'edges', []):
        linked = list(getattr(edge, 'link_faces', []) or [])
        if face_set is not None:
            selected_linked = [f for f in linked if f in face_set]
            if not selected_linked:
                continue
        mark = False
        if len(linked) != 2:
            mark = bool(include_boundary)
        else:
            fa, fb = linked[0], linked[1]
            a_in = (face_set is None or fa in face_set)
            b_in = (face_set is None or fb in face_set)
            if face_set is not None and (a_in ^ b_in):
                mark = True
            elif a_in and b_in:
                angle_ok = False
                sharp_ok = False
                material_ok = False
                uv_break = False
                try:
                    angle_ok = float(edge.calc_face_angle()) >= float(angle_threshold)
                except Exception:
                    angle_ok = False
                try:
                    sharp_ok = bool(include_sharp) and (bool(getattr(edge, 'sharp', False)) or not bool(getattr(edge, 'smooth', True)))
                except Exception:
                    sharp_ok = False
                try:
                    material_ok = bool(include_material) and int(getattr(fa, 'material_index', 0)) != int(getattr(fb, 'material_index', 0))
                except Exception:
                    material_ok = False
                try:
                    if uv_layer is not None:
                        a0, a1 = _core._edge_uvs_in_face(fa, edge, uv_layer)
                        b0, b1 = _core._edge_uvs_in_face(fb, edge, uv_layer)
                        if a0 is not None and b0 is not None:
                            uv_break = not (_core._uv_close(a0, b0, 1.0e-5) and _core._uv_close(a1, b1, 1.0e-5))
                except Exception:
                    uv_break = False
                mark = angle_ok or sharp_ok or material_ok or uv_break
        if mark:
            try:
                if not bool(getattr(edge, 'seam', False)):
                    seam_count += 1
                edge.seam = True
            except Exception:
                pass
    return seam_count


_patch_name('_compute_island_tool_runtime_metrics', _compute_island_tool_runtime_metrics_max)
_patch_name('_refresh_island_tool_runtime_metrics', _compute_island_tool_runtime_metrics_max)
_patch_name('build_islands', _build_islands_max)
_patch_name('_selection_from_context', _selection_from_context_max)
_patch_name('_suv_run_pack_islands_native', _run_pack_native_max)
_patch_name('_suv_run_unwrap_native', _run_unwrap_native_max)
_patch_name('_suv_run_minimize_stretch_native', _run_minimize_stretch_native_max)
_patch_name('_suv_mark_smart_seams', _suv_mark_smart_seams_max)
