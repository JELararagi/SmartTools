"""Public routes for the core layout and support tool modes."""

import bpy


def run_layout(context, op):
    options = {"mode": op.mode.upper()} if op.mode else {}
    return "FINISHED" in bpy.ops.uv.suv_native_stage_layout(**options)


def _frame_tile(context, op):
    area = context.area
    if area is None or area.ui_type != "UV":
        area = next((item for item in context.screen.areas if item.ui_type == "UV"), None) if context.screen else None
    if area is None:
        return False
    region = next((item for item in area.regions if item.type == "WINDOW"), None)
    if region is None:
        return False
    with context.temp_override(area=area, region=region):
        native = bpy.ops.image.view_all
        return native.poll() and "FINISHED" in native(fit_view=True)


def build_handlers(api):
    def sort_by_geometry(context, op):
        axis = (op.axis or 'H').upper()
        if axis not in {'H', 'V'}:
            api._warn(context, op, 'Choose a horizontal or vertical layout axis.',
                      '水平または垂直の配置軸を選択してください。')
            return False
        rows = api._edit_targets(context)
        islands = api._seed_islands(context, rows)
        if len(islands) < 2:
            api._warn(context, op, 'Select at least two UV islands to sort.',
                      '並べ替える UV アイランドを 2 つ以上選択してください。')
            return False
        along = 0 if axis == 'H' else 1
        across = 1 - along

        def world_order(row):
            obj, _, _, island = row
            vertices = {vert for face in island.faces for vert in face.verts}
            points = [obj.matrix_world @ vert.co for vert in sorted(vertices, key=lambda item: item.index)]
            return tuple(sum(point[index] for point in points) / len(points)
                         for index in (along, across, 2))

        islands.sort(key=world_order)
        offset = min(row[3].box[along] for row in islands)
        line = min(row[3].box[across] for row in islands)
        gap = op.margin_px / op.texture_size
        for _, _, uv, island in islands:
            box = island.box
            delta = [0.0, 0.0]
            delta[along] = offset - box[along]
            delta[across] = line - box[across]
            api._move_island(island.faces, uv, *delta)
            offset += box[along + 2] - box[along] + gap
        api._flush(rows)
        return True

    return {
        "smart_uv_suite.pack_sort": api.Handler(
            sort_by_geometry, "Sort selected islands by world X along a UV row or world Y along a UV column.",
            "選択アイランドをワールド X 座標順に UV の横列へ、または Y 座標順に縦列へ並べます。"),
        "smart_uv_suite.pack_home": api.Handler(
            _frame_tile, "Frame the UV tile in the UV editor.",
            "UVエディターにUVタイル全体を表示します。"),
        "smart_uv_suite.pack_stage_layout": api.Handler(
            run_layout, "Apply the selected core layout operation to the UVs.",
            "指定した標準レイアウト処理をUVに適用します。"),
        "smart_uv_suite.pack_layout_action": api.Handler(
            api._run_uv_layout("uv_layout_action", namespace="smart_uv_suite", action="action", scope="scope"),
            "Apply the chosen layout action to the selected scope.",
            "指定した範囲にレイアウト操作を適用します。"),
        "smart_uv_suite.pack_stage_tools": api.Handler(
            api._run_uv_layout("suv_native_stage_compat_tools", mode="mode"),
            "Run the chosen core support tool.",
            "指定した標準 UV 補助ツールを実行します。"),
        "smart_uv_suite.udim_step": api.Handler(
            api._run_uv_layout("suv_udim_step", scope="scope"),
            "Move UV islands by one UDIM tile along U.",
            "UV アイランドを U 方向に UDIM 1 タイル分移動します。"),
        "smart_uv_suite.udim_tile_tools": api.Handler(
            api._run_uv_layout("suv_udim_tile_tools", mode="mode", scope="scope",
                               padding="padding", texture_size="texture_size"),
            "Select, move, and audit UV islands by UDIM tile.",
            "UDIM タイル単位で UV アイランドを選択・移動・監査します。"),
        "smart_uv_suite.pack_hotspot_cell_refill": api.Handler(
            api._run_uv_layout("suv_hotspot_cell_refill", defaults={"write_json": False},
                               cols="columns", rows="rows", padding_px="margin_px",
                               texture_size="texture_size", scope="scope"),
            "Fill available hotspot cells before opening new tiles.",
            "既存タイルの空きホットスポットセルを優先して埋めます。"),
        "smart_uv_suite.pack_hotspot_symmetry_refill": api.Handler(
            api._run_uv_layout("suv_hotspot_symmetry_refill", defaults={"write_json": False},
                               axis="axis", cols="columns", rows="rows", padding_px="margin_px",
                               texture_size="texture_size", scope="scope"),
            "Place symmetric UV islands in neighboring hotspot cells.",
            "対称な UV アイランドを隣接するホットスポットセルに配置します。"),
        "smart_uv_suite.pack_trim_band_refill": api.Handler(
            api._run_uv_layout("suv_trim_band_refill", defaults={"write_json": False},
                               axis="axis", band_count="band_count", padding_px="margin_px",
                               texture_size="texture_size", scope="scope"),
            "Fill available trim bands before opening new tiles.",
            "既存タイルの空きトリム帯を優先して埋めます。"),
        "smart_uv_suite.pack_smart_relax": api.Handler(
            api._run_uv_layout("suv_smart_relax"),
            "Relax selected UVs while preserving shell layout.",
            "アイランドの配置を維持しながら選択 UV をリラックスします。"),
        "smart_uv_suite.pack_smart_rectify": api.Handler(
            api._run_uv_layout("suv_smart_rectify"),
            "Rectify selected UV shells from the active quad.",
            "アクティブ四角面を基準に選択した UV シェルを矩形化します。"),
        "smart_uv_suite.pack_smart_3d_transfer": api.Handler(
            api._run_uv_layout("suv_smart_3d_transfer"),
            "Transfer UVs from the active mesh to selected meshes.",
            "アクティブメッシュの UV を選択メッシュへ転送します。"),
        "smart_uv_suite.atlas_run_all_multi": api.Handler(
            api._run_uv_layout("suv_atlas_run_all_multi", atlas_uv_name="name"),
            "Build, bake, and apply an atlas to the selected meshes.",
            "選択メッシュのアトラスを作成、ベイク、適用します。"),
        "smart_uv_suite.pack_sym_detect_pairs": api.Handler(
            api._run_uv_layout("suv_sym_detect_pairs", axis="axis"),
            "Detect pairs of mirrored UV islands.", "ミラー対称な UV アイランドのペアを検出します。"),
        "smart_uv_suite.pack_sym_mirror_uv": api.Handler(
            api._run_uv_layout("suv_sym_mirror_uv", axis="axis"),
            "Mirror the active island's UVs to its paired island.", "アクティブなアイランドの UV を対称ペアにミラー転送します。"),
        "smart_uv_suite.pack_sym_seams": api.Handler(
            api._run_uv_layout("suv_sym_seams", axis="axis", mode="mode"),
            "Mark or clear seams along the chosen symmetry plane.", "指定した対称面に沿ってシームをマークまたは解除します。"),
        "smart_uv_suite.pack_sym_stack": api.Handler(
            api._run_uv_layout("suv_sym_stack", axis="axis"),
            "Stack mirrored UV island pairs.", "対称な UV アイランドのペアを重ねます。"),
    }
