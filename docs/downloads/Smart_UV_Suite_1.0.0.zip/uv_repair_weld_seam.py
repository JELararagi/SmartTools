import bpy


def _stitch(context, op):
    if context.mode != 'EDIT_MESH':
        return False
    return 'FINISHED' in bpy.ops.smart_uv_suite.stitch_action(mode='ISLAND_CONNECTED_TO_SELECTED')


def build_handlers(api):
    return {
        'smart_uv_suite.weld_seam': api.Handler(_stitch, 'Stitch selected UV seam edges to their matching island boundaries.', '選択した UV シームの辺を対応するアイランド境界へ縫い合わせます。'),
    }
