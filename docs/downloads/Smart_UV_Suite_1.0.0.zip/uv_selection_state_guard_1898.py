# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (c) 2026 JELararagi
"""Smart UV Suite 1.8.98 selection-state guard for UV loop/ring tools.

Loop/Ring selection is a selection-editing command.  It must not silently change
Blender's UV Sync Selection, UV selection mode, mesh selection mode, or Sticky
Selection mode.  Older compatibility layers disabled UV sync and forced EDGE
mode to keep UV-only results visible.  This layer keeps the user's modes intact
and, when UV Sync Selection is already enabled, writes the equivalent mesh edge
selection instead of turning sync off.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, Optional, Set, Tuple

_NS: Dict[str, Any] = {}
_ORIGINALS: Dict[str, Any] = {}
_PREV_EXEC_ATTR = "_suv_1898_previous_execute"
_INSTALLED = False


def _ts(context: Any = None) -> Any:
    try:
        import bpy  # type: ignore
        ctx = context or bpy.context
    except Exception:
        ctx = context
    try:
        ts = getattr(ctx, "tool_settings", None)
        if ts is not None:
            return ts
    except Exception:
        pass
    try:
        return getattr(getattr(ctx, "scene", None), "tool_settings", None)
    except Exception:
        return None


def _workspace(context: Any = None) -> Any:
    try:
        import bpy  # type: ignore
        ctx = context or bpy.context
        return getattr(getattr(ctx, "scene", None), "suv_workspace", None)
    except Exception:
        try:
            return getattr(getattr(context, "scene", None), "suv_workspace", None)
        except Exception:
            return None


def _capture_state(context: Any = None) -> Dict[str, Any]:
    ts = _ts(context)
    ws = _workspace(context)
    state: Dict[str, Any] = {}
    if ts is not None:
        for name in ("use_uv_select_sync", "uv_select_mode", "uv_sticky_select_mode"):
            try:
                state[name] = getattr(ts, name)
            except Exception:
                pass
        try:
            state["mesh_select_mode"] = tuple(bool(v) for v in getattr(ts, "mesh_select_mode"))
        except Exception:
            pass
    if ws is not None:
        try:
            state["workspace_uv_sticky_select_mode"] = getattr(ws, "uv_sticky_select_mode")
        except Exception:
            pass
    return state


def _restore_state(context: Any = None, state: Optional[Dict[str, Any]] = None) -> None:
    if not state:
        return
    ts = _ts(context)
    if ts is not None:
        # Restore Blender's official ToolSettings first.  Each assignment is
        # guarded separately because some fields can be unavailable depending on
        # editor context or Blender build.
        try:
            if (
                "use_uv_select_sync" in state
                and hasattr(ts, "use_uv_select_sync")
                and bool(ts.use_uv_select_sync) != bool(state["use_uv_select_sync"])
            ):
                # Writing the same value still re-selects every UV in Blender 5.1.
                setattr(ts, "use_uv_select_sync", bool(state["use_uv_select_sync"]))
        except Exception:
            pass
        try:
            if "uv_select_mode" in state and hasattr(ts, "uv_select_mode"):
                setattr(ts, "uv_select_mode", state["uv_select_mode"])
        except Exception:
            pass
        try:
            if "mesh_select_mode" in state and hasattr(ts, "mesh_select_mode"):
                mode = tuple(bool(v) for v in state["mesh_select_mode"])
                if len(mode) >= 3:
                    setattr(ts, "mesh_select_mode", (mode[0], mode[1], mode[2]))
        except Exception:
            pass
        try:
            if "uv_sticky_select_mode" in state and hasattr(ts, "uv_sticky_select_mode"):
                setattr(ts, "uv_sticky_select_mode", state["uv_sticky_select_mode"])
        except Exception:
            pass
    ws = _workspace(context)
    if ws is not None:
        try:
            if "workspace_uv_sticky_select_mode" in state and hasattr(ws, "uv_sticky_select_mode"):
                setattr(ws, "uv_sticky_select_mode", state["workspace_uv_sticky_select_mode"])
        except Exception:
            pass


def _disable_sync_noop(context: Any = None) -> None:
    # Deliberately do nothing.  Used to replace old compatibility helpers that
    # forced ToolSettings.use_uv_select_sync=False for UV-only operations.
    return None


def _edge_loop_sets(graph: Dict[str, Any], keys: Iterable[Any]) -> Tuple[Dict[Any, Set[int]], Dict[Any, Set[int]]]:
    selected_loop_ids_by_obj: Dict[Any, Set[int]] = {}
    selected_edge_loop_ids_by_obj: Dict[Any, Set[int]] = {}
    by_key = graph.get("by_key") or {}
    selected_ref_ids: Set[int] = set()
    for key in set(keys or set()):
        for ref in list(by_key.get(key, []) or []):
            rid = id(ref)
            if rid in selected_ref_ids:
                continue
            selected_ref_ids.add(rid)
            ok = ref.get("obj_key")
            if ok is None:
                continue
            try:
                li = int(ref.get("loop_index", -1))
            except Exception:
                li = -1
            try:
                nli = int(ref.get("next_loop_index", -1))
            except Exception:
                nli = -1
            if li >= 0:
                selected_edge_loop_ids_by_obj.setdefault(ok, set()).add(li)
                selected_loop_ids_by_obj.setdefault(ok, set()).add(li)
            if nli >= 0:
                selected_loop_ids_by_obj.setdefault(ok, set()).add(nli)
    return selected_loop_ids_by_obj, selected_edge_loop_ids_by_obj


def _restore_mesh_selection_from_snapshot(mesh: Any, snapshot: Any) -> None:
    fn = _NS.get("_sus_1655_restore_mesh_selection")
    if callable(fn):
        try:
            fn(mesh, snapshot)
            return
        except Exception:
            pass


def _clear_mesh_selection(bm: Any) -> None:
    try:
        for face in bm.faces:
            try:
                face.select_set(False)
            except Exception:
                pass
    except Exception:
        pass
    try:
        for edge in bm.edges:
            try:
                edge.select_set(False)
            except Exception:
                pass
    except Exception:
        pass
    try:
        for vert in bm.verts:
            try:
                vert.select_set(False)
            except Exception:
                pass
    except Exception:
        pass


def _select_mesh_edges_from_loop_ids(bm: Any, edge_loop_ids: Set[int]) -> None:
    ids = set(int(i) for i in (edge_loop_ids or set()) if int(i) >= 0)
    if not ids:
        return
    try:
        for face in bm.faces:
            for loop in face.loops:
                try:
                    if int(getattr(loop, "index", -1)) not in ids:
                        continue
                    try:
                        loop.vert.select_set(True)
                    except Exception:
                        pass
                    try:
                        loop.link_loop_next.vert.select_set(True)
                    except Exception:
                        pass
                    try:
                        loop.edge.select_set(True)
                    except Exception:
                        pass
                except Exception:
                    pass
    except Exception:
        pass


def _call_update_edit_meshes(meshes: Iterable[Any]) -> None:
    fn = _NS.get("_sus_1671_update_edit_meshes")
    if callable(fn):
        try:
            fn(list(meshes or []))
            return
        except Exception:
            pass
    try:
        import bmesh  # type: ignore
        for mesh in list(meshes or []):
            try:
                bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
            except Exception:
                pass
    except Exception:
        pass


def _set_uv_flag(loop: Any, mode: str, value: bool) -> None:
    fn = _NS.get("_sus_1671_live_uv_select_set")
    if callable(fn):
        try:
            fn(loop, mode, value)
            return
        except Exception:
            pass
    try:
        if mode == "EDGE":
            setattr(loop, "uv_select_edge", bool(value))
        else:
            setattr(loop, "uv_select_vert", bool(value))
    except Exception:
        pass


def _set_face_uv_selected(face: Any, value: bool) -> None:
    fn = _NS.get("_sus_1671_face_uv_select_set")
    if callable(fn):
        try:
            fn(face, value)
            return
        except Exception:
            pass
    try:
        setattr(face, "uv_select", bool(value))
    except Exception:
        pass


def _write_graph_selection_preserve_modes(context: Any, graph: Dict[str, Any], keys: Iterable[Any]) -> int:
    """Write LOOP/RING result without changing UV Sync, UV mode or sticky mode."""
    state = _capture_state(context)
    sync_on = bool(state.get("use_uv_select_sync", False))
    selected_loop_ids_by_obj, selected_edge_loop_ids_by_obj = _edge_loop_sets(graph, keys)
    count = 0
    changed_meshes = []
    try:
        for ok, data in list((graph.get("objects") or {}).items()):
            mesh = data.get("mesh")
            bm = data.get("bm")
            uv_layer = data.get("uv_layer")
            if mesh is None or bm is None or uv_layer is None:
                continue
            loop_ids = selected_loop_ids_by_obj.get(ok, set())
            edge_loop_ids = selected_edge_loop_ids_by_obj.get(ok, set())
            try:
                for face in bm.faces:
                    if bool(getattr(face, "hide", False)):
                        continue
                    _set_face_uv_selected(face, False)
                    for loop in face.loops:
                        li = int(getattr(loop, "index", -1))
                        _set_uv_flag(loop, "VERTEX", li in loop_ids)
                        _set_uv_flag(loop, "EDGE", li in edge_loop_ids)
                if sync_on:
                    # With sync ON Blender derives UV selection from mesh
                    # selection.  Write the equivalent mesh edges instead of
                    # turning sync off or changing the user's mesh select mode.
                    _clear_mesh_selection(bm)
                    _select_mesh_edges_from_loop_ids(bm, edge_loop_ids)
                else:
                    # UV-only operation: keep 3D mesh selection exactly as it
                    # was before this selection helper ran.
                    _restore_mesh_selection_from_snapshot(mesh, data.get("mesh_state"))
                count += len(edge_loop_ids)
                changed_meshes.append(mesh)
            except Exception:
                pass
        _call_update_edit_meshes(changed_meshes)
        return int(count)
    finally:
        _restore_state(context, state)


def _loop_or_ring_execute_preserve_modes(self: Any, context: Any, action: str) -> set:
    state = _capture_state(context)
    old_fn = _ORIGINALS.get("loop_or_ring_execute")
    # Prefer the current 1.6.72+ graph backend, because it reads the live BMesh
    # UV selection and avoids the old Object-mode UV attribute flush path.
    try:
        mode_enter = _NS.get("_sus_1655_mode_enter_object")
        restore_mode = _NS.get("_sus_1655_restore_mode")
        build_graph = _NS.get("_sus_1655_build_graph")
        loop_keys = _NS.get("_sus_1655_loop_keys")
        ring_keys = _NS.get("_sus_1655_ring_keys")
        if not all(callable(x) for x in (mode_enter, restore_mode, build_graph, loop_keys, ring_keys)):
            raise RuntimeError("live loop/ring backend is unavailable")
        old_active, old_mode, objs = mode_enter(context)
        try:
            graph = build_graph(context, objs)
            seed_keys = set(graph.get("seed_keys") or set())
            if not seed_keys:
                try:
                    self.report({"WARNING"}, _txt(context, "Select at least one UV edge in the UV Editor.", "UVエディター上で少なくとも1本のUV辺を選択してください。"))
                except Exception:
                    pass
                return {"CANCELLED"}
            selected_keys = ring_keys(graph, seed_keys) if str(action).upper() == "RING" else loop_keys(graph, seed_keys)
            count = _write_graph_selection_preserve_modes(context, graph, selected_keys)
            if count <= 0:
                try:
                    self.report({"WARNING"}, _txt(context, "UV loop/ring selection did not select any edge.", "UVループ/リング選択で辺を選択できませんでした。"))
                except Exception:
                    pass
                return {"CANCELLED"}
            return {"FINISHED"}
        finally:
            try:
                restore_mode(context, old_active, old_mode, objs)
            except Exception:
                pass
    except Exception as exc:
        # Fall back to the previously installed operator, but restore every mode
        # it might change.  This prevents regressions if another compatibility
        # layer replaces the live backend.
        if callable(old_fn):
            try:
                return old_fn(self, context, action)
            finally:
                _restore_state(context, state)
        try:
            self.report({"WARNING"}, _txt(context, "UV loop/ring selection failed.", "UVループ/リング選択に失敗しました。") + f" {exc}")
        except Exception:
            pass
        return {"CANCELLED"}
    finally:
        _restore_state(context, state)


def _execute_preserve_modes(self: Any, context: Any) -> set:
    state = _capture_state(context)
    action = str(getattr(self, "action", "GROW") or "GROW").upper()
    try:
        if action in {"LOOP", "RING"}:
            return _loop_or_ring_execute_preserve_modes(self, context, action)
        prev = getattr(type(self), _PREV_EXEC_ATTR, None) or _ORIGINALS.get("execute")
        if callable(prev) and prev is not _execute_preserve_modes:
            return prev(self, context)
        return {"CANCELLED"}
    finally:
        _restore_state(context, state)


def _txt(context: Any, en: str, ja: str) -> str:
    fn = _NS.get("_sus_text")
    if callable(fn):
        try:
            return str(fn(en, ja, context))
        except Exception:
            pass
    return ja


def _patch_global_helpers() -> None:
    # No-op every old helper that forcibly disabled UV Sync Selection.
    for name in ("_sus_1655_disable_sync", "_sus_1654_disable_uv_sync_for_uv_only_ops"):
        try:
            old = _NS.get(name)
            if callable(old) and old is not _disable_sync_noop:
                _ORIGINALS.setdefault(name, old)
                _NS[name] = _disable_sync_noop
        except Exception:
            pass
    try:
        old = _NS.get("_sus_1655_write_graph_selection")
        if callable(old) and old is not _write_graph_selection_preserve_modes:
            _ORIGINALS.setdefault("_sus_1655_write_graph_selection", old)
            _NS["_sus_1655_write_graph_selection"] = _write_graph_selection_preserve_modes
    except Exception:
        pass
    try:
        old = _NS.get("_sus_1655_loop_or_ring_execute")
        if callable(old) and old is not _loop_or_ring_execute_preserve_modes:
            _ORIGINALS.setdefault("loop_or_ring_execute", old)
            _NS["_sus_1655_loop_or_ring_execute"] = _loop_or_ring_execute_preserve_modes
    except Exception:
        pass


def _patch_operator() -> None:
    cls = _NS.get("SMARTUVSUITE_OT_uv_element_select_action")
    if not isinstance(cls, type):
        return
    current = getattr(cls, "execute", None)
    if current is _execute_preserve_modes:
        return
    if callable(current):
        _ORIGINALS.setdefault("execute", current)
        if getattr(cls, _PREV_EXEC_ATTR, None) is None:
            try:
                setattr(cls, _PREV_EXEC_ATTR, current)
            except Exception:
                pass
    try:
        setattr(cls, "execute", _execute_preserve_modes)
    except Exception:
        pass


def install(ns: Dict[str, Any], context: Any = None) -> None:
    global _NS, _INSTALLED
    _NS = ns
    _patch_global_helpers()
    _patch_operator()
    _INSTALLED = True


def unregister() -> None:
    global _INSTALLED
    cls = _NS.get("SMARTUVSUITE_OT_uv_element_select_action") if isinstance(_NS, dict) else None
    try:
        if isinstance(cls, type):
            prev = getattr(cls, _PREV_EXEC_ATTR, None) or _ORIGINALS.get("execute")
            if callable(prev):
                setattr(cls, "execute", prev)
            try:
                if hasattr(cls, _PREV_EXEC_ATTR):
                    delattr(cls, _PREV_EXEC_ATTR)
            except Exception:
                pass
    except Exception:
        pass
    for name in ("_sus_1655_disable_sync", "_sus_1654_disable_uv_sync_for_uv_only_ops", "_sus_1655_write_graph_selection", "_sus_1655_loop_or_ring_execute"):
        try:
            old = _ORIGINALS.get(name if name != "_sus_1655_loop_or_ring_execute" else "loop_or_ring_execute") or _ORIGINALS.get(name)
            if old is not None:
                _NS[name] = old
        except Exception:
            pass
    _INSTALLED = False
