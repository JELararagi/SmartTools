# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy

from . import text_translation as _text_translation

NATIVE_OPERATOR_CATALOG = (
    ('mesh.suv_bake_uv_prep', 'Bake UV Prep', 'Bake UV Prep. Creates or activates a named bake or lightmap UV layer across the selected meshes in one pass so downstream baking starts from a consistent target map. / Bake UV Prep。選択メッシュに対して、名前付きのベイクまたはライトマップ用UVレイヤーを一括で作成または有効化し、後工程のベイク対象を統一します。', 'native_stage.py'),
    ('mesh.suv_clear_seams', 'Clear Seams', 'Clear seam marks from the affected mesh edges. / 対象メッシュエッジのシームマークを解除します。', 'flow.py'),
    ('mesh.suv_native_stage_mesh', 'Mesh Support', 'Mesh Support. Groups mesh-side helper actions that support setup, reports, and guided execution around the main UV tools. / Mesh Support。主要UVツールの周辺で、設定、レポート、ガイド実行を支えるメッシュ側補助機能をまとめます。', 'native_stage.py'),
    ('mesh.suv_native_stage_uvmap', 'UV Map Manager', 'UV Map Manager. Manages UV layers for bake, trim, lightmap, or export roles by creating, duplicating, renaming, and switching target maps. / UV Map Manager。ベイク、トリム、ライトマップ、書き出し用など役割別のUVレイヤーを作成、複製、改名、切替して管理します。', 'native_stage.py'),
    ('mesh.suv_uvmap_add', 'Add UV Map', 'Add a new UV map to the active mesh. / アクティブメッシュへ新しいUVマップを追加します。', 'flow.py'),
    ('mesh.suv_uvmap_duplicate', 'Duplicate UV Map', 'Duplicate the active UV map so you can branch or preserve a layout version. / アクティブUVマップを複製し、別バージョンの作業や保管に使えるようにします。', 'flow.py'),
    ('mesh.suv_uvmap_remove', 'Remove Active UV', 'Remove the active UV map from the mesh. / メッシュからアクティブUVマップを削除します。', 'flow.py'),
    ('mesh.suv_uvmap_rename_active', 'Rename Active UV', 'Rename the active UV map on the selected meshes. / 選択メッシュのアクティブUVマップ名を変更します。', 'flow.py'),
    ('mesh.suv_uvmap_reorder', 'Reorder UV Map', 'Move the active UV map earlier or later in the UV list. / アクティブUVマップをUV一覧の上または下へ移動します。', 'flow.py'),
    ('mesh.suv_uvmap_set_active', 'Set Active UV', 'Set a named UV layer as active on the selected meshes. / 指定した名前のUVレイヤーを選択メッシュのアクティブUVに設定します。', 'flow.py'),
    ('mesh.suv_uvmap_set_render', 'Set Render UV', 'Set a named UV layer as the render/export UV on the selected meshes. / 指定した名前のUVレイヤーを選択メッシュのレンダー・書き出しUVに設定します。', 'flow.py'),
    ('object.suv_clear_stretch_heatmap', 'Clear Stretch Heatmap', 'Remove the generated stretch heatmap color attribute from the selected meshes. / 生成したストレッチヒートマップ用カラー属性を選択メッシュから削除します。', 'flow.py'),
    ('object.suv_create_checker_material', 'Create Checker Material', 'Create and apply a checker material for visual UV scale and distortion checking. / UVの密度や歪み確認に使えるチェッカー材質を作成して適用します。', 'flow.py'),
    ('object.suv_native_stage_bake', 'Bake Support', 'Bake Support. Groups atlas, bake, trimsheet, hotspot, and material-output helpers used near the end of production. / Bake Support。制作終盤で使うアトラス、ベイク、トリムシート、ホットスポット、マテリアル出力補助をまとめます。', 'native_stage.py'),
    ('object.suv_native_stage_color', 'Color ID Manager', 'Color ID Manager. Prepares color-ID style helper output for mask baking, material separation, and region planning. / Color ID Manager。マスク用ベイク、マテリアル分離、領域計画に使うカラー ID 系の補助出力を準備します。', 'native_stage.py'),
    ('object.suv_native_stage_preview', 'Preview Manager', 'Preview Manager. Opens checker, material, and distortion-oriented preview helpers so you can visually verify UV quality before final output. / Preview Manager。チェッカー、マテリアル、歪み確認などのプレビュー補助を開き、最終出力前にUV品質を視覚確認します。', 'native_stage.py'),
    ('object.suv_remove_checker_materials', 'Remove Checker', 'Remove generated checker materials from the selected meshes. / 選択メッシュから生成チェッカーマテリアルを解除します。', 'flow.py'),
    ('object.suv_visualize_stretch_heatmap', 'Build Stretch Heatmap', 'Create a color attribute and preview material that visualizes island stretch directly on the mesh. / アイランドのストレッチをメッシュ上で確認できるカラー属性とプレビュー材質を作成します。', 'flow.py'),
    ('suv.boundary_to_shape', 'Convert Boundary to Shape', 'Boundary to Shape. Pushes the selected UV border toward a circle or quad so the silhouette becomes easier to stitch, trim, and align. / Boundary to Shape。選択したUV境界を円または四角形へ近づけ、輪郭をスティッチ、トリム、整列に使いやすい形へ整えます。', 'flow.py'),
    ('suv.constraint_unwrap', 'Constraint Unwrap', 'Constraint Unwrap. Unwraps while respecting pins, optional anchors, and transform-preservation rules so shell flow stays stable during constrained edits. Use it after seams or projection when a plain unwrap is too destructive. / Constraint Unwrap。ピン留め、任意のアンカー、変形保持ルールを尊重しながら展開し、制約付き編集でもシェルの流れを安定させます。シーム設定や投影の後で、通常の展開では崩れすぎる時に使います。', 'flow.py'),
    ('suv.face_unitize', 'Unitize Faces', 'Face Unitize. Resets the selected faces into a per-face UV layout so each face becomes isolated and easy to inspect, bake, or repack. / Face Unitize。選択面を面ごとのUVレイアウトへ戻し、各面を独立させて確認、ベイク、再配置しやすくします。', 'flow.py'),
    ('uv.suv_align_islands', 'Align Islands', 'Align selected islands by their minimum, maximum or center positions on the chosen axis. / 選択した軸で、最小・最大・中央の位置を基準にアイランドを整列します。', 'flow.py'),
    ('uv.suv_annotate_align', 'Align to Annotation', 'Use annotation or guide strokes as alignment hints for UV cleanup. / 注釈やガイド線を整列の手掛かりとして使い、UVを整理します。', 'flow.py'),
    ('uv.suv_apply_density_profile', 'Apply Density Profile', 'Apply a reusable texel-density workflow profile and optionally run batch density or guarded normalization. / 再利用可能なテクセル密度プロファイルを適用し、必要なら一括密度処理やガード均一化まで実行します。', 'flow.py'),
    ('uv.suv_apply_display_preset', 'Apply Display Preset', 'Apply a display preset that changes how the workspace exposes controls and UI density. / ワークスペースの表示方法やUI密度をまとめて切り替える表示プリセットを適用します。', 'pro_operators.py'),
    ('uv.suv_apply_external_compat_target', 'Apply External Compatibility Target', 'Run the closest UV Suite bridge for a reference external tool or add-on target. / 参照するSmart UV Suiteやアドオンに最も近い UV Suite 互換ブリッジを実行します。', 'flow.py'),
    ('uv.suv_apply_feature_bridge', 'Apply Feature Bridge', 'Run the mapped UV Suite bridge for one reference feature row. This lets you launch a direct internal operator when available, or fall back to the nearest compatibility target for that tool family. / 参照機能1行に対応付けた UV Suite ブリッジを実行します。直接オペレーターがある場合はそれを、無い場合は近い互換ターゲットへフォールバックします。', 'quality_parity.py'),
    ('uv.suv_apply_hotspot_preset', 'Apply Hotspot Preset', 'Load a ready-made hotspot or trimsheet cell preset into the workspace settings. / すぐ使えるホットスポット／トリムシート用セル設定をワークスペースへ読み込みます。', 'flow.py'),
    ('uv.suv_apply_inspector_profile', 'Apply Inspector Profile', 'Apply a reusable inspector/heal profile and optionally run Inspector Scan or Layout Auto Heal. / 再利用可能な監査・自動補正プロファイルを適用し、必要ならインスペクタ走査や自動補正まで実行します。', 'flow.py'),
    ('uv.suv_apply_layout_preset', 'Apply Layout Preset', 'Apply a layout preset that prepares pack, padding and arrangement settings for common tasks. / よく使う用途向けに、パックや余白、配置の設定をまとめて整えるレイアウトプリセットを適用します。', 'pro_operators.py'),
    ('uv.suv_apply_line_flow_preset', 'Apply Line / Flow Preset', 'Load a line or flow preset for straightening and edge-flow oriented UV cleanup. / 直線化やエッジフロー重視のUV整形に向けたライン／フロープリセットを読み込みます。', 'pro_operators.py'),
    ('uv.suv_apply_named_layout_library', 'Apply Named Layout Library', 'Apply a named trimsheet, hotspot or atlas profile tuned for a common production use case. / よくある制作用途向けに調整した名前付きトリムシート、ホットスポット、アトラス設定を適用します。', 'flow.py'),
    ('uv.suv_apply_pack_profile', 'Apply Pack Profile', 'Apply a named pack profile to the workspace and optionally run Pack Pro with the same packing rules. / 名前付きパックプロファイルをワークスペースへ適用し、必要なら同じルールで Pack Pro も実行します。', 'flow.py'),
    ('uv.suv_apply_seam_profile', 'Apply Seam Profile', 'Apply a named seam profile that combines multiple seam rules for a production use case. / 用途別の複数ルールをまとめた名前付きシームプロファイルを適用します。', 'flow.py'),
    ('uv.suv_apply_workflow_bundle', 'Apply Workflow Bundle', 'Apply a reusable workflow bundle that can combine layout, pack, density, inspector, and optional auto-UV execution in one step. / レイアウト、パック、密度、監査、必要なら自動UV実行までまとめて適用できる再利用ワークフローバンドルです。', 'flow.py'),
    ('uv.suv_apply_workflow_preset', 'Apply Workflow Preset', 'Apply a ready-made workflow preset that adjusts multiple UV Suite settings at once. / 複数の設定をまとめて切り替えるワークフロープリセットを適用します。', 'pro_operators.py'),
    ('uv.suv_apply_workflow_recipe', 'Apply Workflow Recipe', 'Run a reusable workflow recipe that sequences multiple workflow bundles as one job. / 複数のワークフローバンドルを順番に流す再利用ワークフローレシピです。', 'flow.py'),
    ('uv.suv_atlas_bake_multi', 'Bake Atlas (Multi)', 'Run the atlas bake preparation step for multiple selected objects. / 選択した複数オブジェクト向けにアトラスベイク準備を実行します。', 'symmetry_atlas_operators.py'),
    ('uv.suv_atlas_build_mat_apply_multi', 'Build Material & Apply (Multi)', 'Create and apply atlas materials for the current multi-object atlas workflow. / 現在の複数オブジェクト向けアトラス作業に必要な材質を作成して適用します。', 'symmetry_atlas_operators.py'),
    ('uv.suv_atlas_build_uv_multi', 'Build Atlas UV (Multi)', 'Build UV layout data for multi-object atlas workflows. / 複数オブジェクトをまとめるアトラス作業向けのUV配置データを作成します。', 'symmetry_atlas_operators.py'),
    ('uv.suv_atlas_run_all_multi', 'Run All (Multi)', 'Run the suite', 'symmetry_atlas_operators.py'),
    ('uv.suv_audit_chain_preset', 'Audit Chain Preset', 'Save the current audit-driven relayout directives and replay them later as a locked chain. / 現在の監査ベース再配置ディレクティブを保存し、あとでロック付きチェーンとして再実行します。', 'flow.py'),
    ('uv.suv_auto_seam_advanced', 'Auto Mark Advanced Seams', 'Mark seams from angle, sharp edges, material borders or open boundaries. / 角度、シャープ、マテリアル境界、開放境界からシームを自動設定します。', 'flow.py'),
    ('uv.suv_auto_unwrap_pro', 'Auto Unwrap Pro', 'Unwrap the current mesh with the suite', 'pro_operators.py'),
    ('uv.suv_auto_uv_profile', 'Auto UV Profile', 'Run a merged one-click UV workflow profile that combines the strongest overlapping features into compact presets. / 重複する機能群を統合した1クリックUVワークフロープリセットを実行します。', 'symmetry_atlas_operators.py'),
    ('uv.suv_batch_apply_seam_profile', 'Batch Apply Seam Profile', 'Apply a named seam profile across the selected mesh objects in one pass. / 名前付きシームプロファイルを選択メッシュ全体へ一括適用します。', 'flow.py'),
    ('uv.suv_batch_layout_profile', 'Batch Layout Profile', 'Run a UV Suite layout/packing profile across the active mesh or all selected meshes in one pass. / UV Suite のレイアウト・パックプロファイルをアクティブまたは選択メッシュ全体へ一括適用します。', 'flow.py'),
    ('uv.suv_batch_match_stitch_active_preserve', 'Batch Match + Stitch Active', 'Run Match + Stitch Active across selected mesh objects one object at a time. / Match + Stitch Active を選択メッシュ全体へ1オブジェクトずつ実行します。', 'native_stage.py'),
    ('uv.suv_batch_object_to_udim_tiles', 'Move Objects to UDIM Tiles', 'Route the active mesh or every selected mesh into its own UDIM tile, with optional fit-to-tile normalization and a reusable batch report. / アクティブまたは選択メッシュごとに専用UDIMタイルへ振り分け、必要ならタイル内へ自動で収めて一括レポートも残します。', 'flow.py'),
    ('uv.suv_centralize_islands', 'Center Islands', 'Move selected islands toward a central placement inside the active tile or workspace area. / 選択アイランドを現在タイルや作業領域の中心寄りへ移動します。', 'flow.py'),
    ('uv.suv_cleanup_bridge', 'Cleanup Bridge', 'Merged cleanup bridge for heal-uv, overlap removal, relax-knead, weld-align and realtime optimize style tasks. / Heal UV、重なり解消、強化リラックス、ウェルド整列、リアルタイム最適化系をまとめた統合クリーンアップです。', 'flow.py'),
    ('uv.suv_clear_all_reports', 'Clear All Reports', 'Clear the tool_runtime, batch, scan, validation, and support texts together so the next test starts cleanly. / 実行ログ、バッチ、検査、検証、サポートの各レポートをまとめてクリアして、次の検証をきれいな状態から始めます。', 'pro_operators.py'),
    ('uv.suv_clear_batch_report', 'Clear Batch Report', 'Clear the multi-step batch report text datablock and reset the last batch summary. / 複数ステップ処理のバッチレポートをクリアし、最後の要約もリセットします。', 'pro_operators.py'),
    ('uv.suv_clear_pins', 'Clear Pins', 'Remove pin flags from the current UV selection so it can move freely again. / 現在のUV選択からピン固定を解除し、再び自由に動かせるようにします。', 'flow.py'),
    ('uv.suv_clear_tool_runtime_log', 'Clear Runtime Log', 'Clear the UV Suite tool_runtime log text datablock so a new debugging session starts cleanly. / UV Suite の実行ログテキストを消去して、新しいデバッグ記録をきれいな状態から始めます。', 'pro_operators.py'),
    ('uv.suv_collect_support_bundle', 'Collect Diagnostics', 'Run validation, write a fresh snapshot, build a support bundle, and open the bundle for quick sharing. / 検証、最新スナップショット出力、サポートバンドル生成を順に実行し、共有しやすい状態へまとめます。', 'pro_operators.py'),
    ('uv.suv_constraint_relax_preserve', 'Relax with Constraints', 'Run stronger relax / pelt-style cleanup while respecting pins or temporary anchors, then restore tile placement, area and optional orientation for a safer external-tool style constrained relax workflow. / ピンや一時アンカーを尊重して強めのリラックスやPelt風調整を実行し、その後にタイル位置や面積感、必要に応じて向きを戻す制約付きリラックスです。', 'flow.py'),
    ('uv.suv_copy_diagnostics_text', 'Copy Diagnostics Text', 'Copy one of the UV Suite diagnostics text datablocks to the system clipboard. / UV Suite の診断テキストをシステムクリップボードへコピーします。', 'pro_operators.py'),
    ('uv.suv_crop_tile', 'Crop to Tile', 'Frame the selected UVs inside the current tile without stretching them. / 選択UVを縦横比を保ったまま現在タイル内へ収めます。', 'flow.py'),
    ('uv.suv_density_guard_normalize', 'Normalize with Density Guard', 'Equalize texel density across groups but clamp scale changes so the correction stays stable, closer to guarded density workflows in external UV tools. / グループ間のテクセル密度を均一化しつつ拡大縮小倍率を制限し、Smart UV Suiteの安全な密度補正に近い挙動へ寄せます。', 'flow.py'),
    ('uv.suv_distribute_islands', 'Distribute Islands', 'Distribute selected islands with more even spacing across the current layout area. / 現在のレイアウト領域内で、選択アイランドをより均等な間隔で配置します。', 'flow.py'),
    ('uv.suv_explode_islands', 'Explode Islands', 'Spread selected UV islands apart for inspection, stitch prep, or manual cleanup. / 選択UVアイランドを見やすく分離し、確認・縫合前準備・手動調整をしやすくします。', 'flow.py'),
    ('uv.suv_external_compat_report', 'Write External Compatibility Report', 'Write a report covering mapped external tool targets, their bridge paths and validation status. / Smart UV Suite互換ターゲット、そのブリッジ経路、検証状態をまとめたレポートを書き出します。', 'flow.py'),
    ('uv.suv_external_layout_profile', 'External Layout Profile', 'Run layout and packing presets inspired by external UV tool workflows using the suite', 'flow.py'),
    ('uv.suv_fill_tile', 'Fill Tile', 'Fill the current tile with the selected UVs. You can keep the aspect ratio or stretch to both axes. / 選択UVを現在タイルいっぱいに拡大します。縦横比維持または両軸ストレッチを選べます。', 'flow.py'),
    ('uv.suv_fit_to_bounds', 'Fit to Bounds', 'Fit selected islands into the target UV bounds while respecting padding settings. / 余白設定を考慮しながら、選択アイランドを目標UV範囲へ収めます。', 'flow.py'),
    ('uv.suv_fix_all_issues', 'Fix All Issues', 'Run the suite', 'pro_operators.py'),
    ('uv.suv_flip_islands', 'Flip Islands', 'Flip selected islands horizontally or vertically for symmetry and reuse tasks. / 対称処理や再利用向けに、選択アイランドを水平または垂直に反転します。', 'flow.py'),
    ('uv.suv_group_normalize_layout', 'Normalize Groups', 'Equalize grouped island clusters so similar/material groups keep a more consistent footprint before hotspot, trimsheet or UDIM packing. / 類似・マテリアル単位の島グループを均一化し、ホットスポット、トリム、UDIM配置前のフットプリント差を整えます。', 'flow.py'),
    ('uv.suv_groups_to_tiles', 'Move Groups to Tiles', 'Cluster islands by material or similarity, then send each cluster to its own UDIM-like tile. / マテリアルや類似性でアイランドをまとめ、各グループを別タイルへ配置します。', 'flow.py'),
    ('uv.suv_histogram_tools', 'UV Gradient / Histogram', 'Analyze UV island size, aspect, density and angle distributions, then write reports or select the largest/smallest quartile. / UVアイランドの大きさ・縦横比・密度・角度分布を解析し、レポート書き出しや最大/最小四分位の選択を行います。', 'native_stage.py'),
    ('uv.suv_hotspot_cell_refill', 'Refill Hotspot Cells', 'Reuse already-open hotspot cells on current tiles first, then spill remaining groups to new tiles. / 現在のタイル上で空いているホットスポットセルを優先再利用し、残りだけを新しいタイルへ流します。', 'flow.py'),
    ('uv.suv_hotspot_cell_tools', 'Hotspot Cell Tools', 'Select hotspot cells, place groups into trim/hotspot cells, or export cell usage manifests. / ホットスポットセルの選択、グループのセル配置、セル使用状況の書き出しを行います。', 'flow.py'),
    ('uv.suv_hotspot_grid_layout', 'Layout Hotspot Grid', 'Place selected islands into an evenly spaced cell grid for hotspot, trimsheet and atlas-style layouts. / 選択アイランドを均等セルグリッドへ配置し、ホットスポット、トリムシート、アトラス向けの並びを作ります。', 'flow.py'),
    ('uv.suv_hotspot_symmetry_refill', 'Refill Symmetric Hotspots', 'Detect symmetry pairs, place them into adjacent hotspot cell pairs, then refill remaining groups into open cells before overflowing to new tiles. / 対称ペアを隣接ホットスポットセルへ配置し、残りのグループを空きセルへ再充填してから新タイルへ流します。', 'flow.py'),
    ('uv.suv_hs_gridify', 'Gridify', 'Rotate islands to a clean orthogonal basis and snap UV rows/columns onto an even grid. / アイランドを直交基準へ回転し、UVの行列を均等グリッドへ整えます。', 'flow.py'),
    ('uv.suv_hs_orthogonalize', 'Orthogonalize UVs', 'Rotate selected islands to their best-fitting orthogonal angle for hard-surface cleanup. / 選択アイランドを最適な直交角度へ回転し、ハードサーフェス向けに整えます。', 'flow.py'),
    ('uv.suv_hs_quad_flow', 'Quad Flow', 'Run Follow Active Quads and then auto-orient the result for a hard-surface friendly shell. / Follow Active Quads の後に自動整向を行い、ハードサーフェス向けに整えます。', 'flow.py'),
    ('uv.suv_hs_rectify_constrained', 'Constraint Rectify', 'Orthogonalize, gridify, and rectify islands while optionally preserving center, area, and tile placement. This pushes hard-surface quadrify/rectify workflows closer to stronger external UV tools. / アイランドを直交整列・グリッド化・矩形化しつつ、必要に応じて中心、面積、タイル位置を保ちます。外部強ツール寄りの整形ワークフローへ近づける強化です。', 'flow.py'),
    ('uv.suv_hs_rectify_fit', 'Fit Rectified Shape', 'Rotate islands to an orthogonal basis and fit them into a clean rectangular tile space. / アイランドを直交基準へ回転し、綺麗な矩形タイル空間へフィットします。', 'flow.py'),
    ('uv.suv_hs_squareify', 'Square Fit', 'Scale each selected island into a square footprint while keeping it in its current tile. / 各選択アイランドを現在タイル内で正方形フットプリントに合わせて拡縮します。', 'flow.py'),
    ('uv.suv_inspector_clear_cache', 'Clear Scan Cache', 'Clear cached inspector results so the summary panel can be rebuilt from a fresh scan. / キャッシュされた検査結果を消去し、要約パネルを新しいスキャン結果で再構築できるようにします。', 'pro_operators.py'),
    ('uv.suv_inspector_fix_flipped', 'Fix Flipped Islands', 'Attempt to repair flipped UV faces detected by the inspector. / インスペクタで検出された反転UV面の修正を試みます。', 'pro_operators.py'),
    ('uv.suv_inspector_rescan', 'Rescan', 'Run the UV inspector again with the current options and selection scope. / 現在のオプションと選択範囲でUVインスペクタを再実行します。', 'pro_operators.py'),
    ('uv.suv_inspector_scan', 'Inspector Scan', 'Scan selected UVs for flipped faces, zero-area faces, out-of-tile islands, overlap and stretch issues. / 選択UVを走査し、反転面、ゼロ面積、タイル外、重なり、ストレッチ問題を検出します。', 'pro_operators.py'),
    ('uv.suv_inspector_select', 'Inspector Select', 'Select UV elements that match a specific inspector issue so you can review or repair them quickly. / 指定した問題種別に一致するUV要素を選択し、すばやく確認や修正ができるようにします。', 'pro_operators.py'),
    ('uv.suv_inspector_select_all', 'Select All Issues', 'Select every issue type found in the latest inspector scan at once. / 最新のインスペクタスキャンで見つかった全問題種別を一括選択します。', 'flow.py'),
    ('uv.suv_inspector_write_report', 'Write Inspector Report', 'Write the latest inspector scan summary into a Blender Text datablock for review and handoff. / 最新の検査結果をBlenderテキストへ書き出し、確認や引き継ぎに使えるようにします。', 'flow.py'),
    ('uv.suv_issue_audit_tools', 'UV Issue Audit', 'Audit per-island UV issues such as overlap, flipped, UDIM crossing, shattered fragments and stretch, then write reports or select the worst offenders. / 重なり・反転・UDIM跨ぎ・細切れ・ストレッチなどのUV問題をアイランド単位で監査し、レポート化や問題島の選択を行います。', 'native_stage.py'),
    ('uv.suv_issue_overlay_tools', 'UV Issue Overlay', 'Build or clear a mesh preview overlay derived from the UV issue audit so you can see problem islands directly on the model. / UV問題監査の結果をメッシュ上の色プレビューにして、問題アイランドを直接確認できるようにします。', 'native_stage.py'),
    ('uv.suv_layout_audit_relayout', 'Audit Guided Relayout', 'Read the latest preflight audit and layout traces, rank relayout candidates, optionally run the top profile or a reason-aware relayout chain, and write a before/after compare report. / 最新の事前監査と配置トレースを読み、再配置候補を順位付けし、最上位または理由分岐チェーンを実行し、実行前後比較レポートも書き出します。', 'flow.py'),
    ('uv.suv_layout_autoheal', 'Auto Heal Layout', 'Audit overlap, cross-tile spans and stretch, then run automatic corrective steps before a quality repack. / 重なり、タイルまたぎ、ストレッチを監査し、高品質パック前に自動補正を行います。', 'flow.py'),
    ('uv.suv_layout_candidate_audit', 'Adaptive Layout Audit', 'Analyze the current islands, recommend hotspot/trim/reuse layouts, and optionally run the best-fit layout route. / 現在のアイランドを分析し、ホットスポット、トリム、再利用向けの推奨レイアウトを出し、必要なら最適ルートを実行します。', 'flow.py'),
    ('uv.suv_layout_preflight_audit', 'Layout Preflight', 'Write a preflight report covering overlap, stack reuse, topology duplicates, symmetry reuse, stretch watchlists and tile spans before final packing. / 最終パック前に、重なり、再利用候補、トポロジー重複、対称再利用、ストレッチ監視、タイルまたぎをまとめて監査します。', 'flow.py'),
    ('uv.suv_layout_recipe_materialize', 'Adaptive Layout Materializer', 'Convert hotspot/trim/reuse recommendations into an explicit slot or trim plan, export it, and optionally apply the concrete layout template. / ホットスポット、トリム、再利用の推奨結果を、具体的なセルやトリム帯の計画へ変換し、書き出しや実配置まで行います。', 'flow.py'),
    ('uv.suv_layout_set_delete', 'Delete Layout Set', 'Delete a saved UV layout set you no longer need. / 不要になった保存 UV レイアウトセットを削除します。', 'selection_operators.py'),
    ('uv.suv_layout_set_library_io', 'Layout Set Library I/O', 'Export or import saved UV layout sets as Blender Text or JSON files so full UV placements can be reused across scenes and repeated assets. / 保存した UV レイアウトセットを Blender Text や JSON ファイルへ入出力し、シーンや繰り返しアセットをまたいで再利用できるようにします。', 'selection_operators.py'),
    ('uv.suv_layout_set_recall', 'Recall Layout Set', 'Recall a previously saved UV layout set and apply it back onto the active mesh. / 以前保存した UV レイアウトセットを呼び出し、アクティブメッシュへ再適用します。', 'selection_operators.py'),
    ('uv.suv_layout_set_save', 'Save Layout Set', 'Save the current active UV layout into a reusable slot so the same UV placement can be recalled later. / 現在のアクティブUVレイアウトを再利用できるスロットへ保存し、あとで同じUV配置を呼び出せるようにします。', 'selection_operators.py'),
    ('uv.suv_layout_set_transfer', 'Transfer Layout Set', 'Copy a saved UV layout set from the active mesh to the other selected meshes so repeated assets can reuse the same placement slot. / アクティブメッシュの保存済み UV レイアウトセットを他の選択メッシュへコピーし、繰り返しアセットでも同じ配置スロットを再利用できるようにします。', 'selection_operators.py'),
    ('uv.suv_layout_set_update', 'Update Layout Set', 'Update an existing saved UV layout set with the current active UV state. / 既存の保存 UV レイアウトセットを現在のアクティブUV状態で更新します。', 'selection_operators.py'),
    ('uv.suv_similarity_bridge', 'Smart Similarity Bridge', 'Merged similarity bridge for smart-similarity, similar-feature and identical-island workflows. / 類似判定、類似特徴、同一アイランド系ワークフローをまとめた統合選択です。', 'flow.py'),
    ('uv.suv_match_active_preserve', 'Match Active Preserve', 'Match selected or similar UV islands to the active island while preserving layout feel such as center, lower-left anchor, tile and original area. / 選択または類似UVアイランドをアクティブ島へ合わせつつ、中心・左下アンカー・タイル・元面積感を保ちます。', 'native_stage.py'),
    ('uv.suv_match_stitch_active_preserve', 'Match + Stitch Active', 'Match selected or similar UV islands to the active island, then optionally run Blender core stitch or weld while keeping the workflow reuse-friendly. / 選択または類似UVアイランドをアクティブ島へ合わせ、その後必要に応じてBlender標準のステッチやウェルドを実行して再利用しやすく整えます。', 'native_stage.py'),
    ('uv.suv_native_projection', 'Run Core Projection', 'Run Core', 'flow.py'),
    ('uv.suv_native_stage_compat_tools', 'Core Support Tools', 'One-tap wrappers for advanced pack, stack, smart-utility and diagnostics helpers from the suite', 'native_stage.py'),
    ('uv.suv_native_stage_layout', 'Core Layout', 'Core Layout. Groups layout-oriented tools for packing, sorting, tiling, and boundary cleanup after shell shape is settled. / Core Layout。シェル形状が固まった後のパック、整列、タイル移動、境界整理に使うレイアウト系ツールをまとめます。', 'native_stage.py'),
    ('uv.suv_native_stage_select', 'Core Select', 'Core Select. Collects scan and selection helpers used to find overlaps, bad shells, and other issues before repair or export. / Core Select。重なり、不良シェル、その他の問題を修復や書き出しの前に見つけるための検査・選択補助をまとめます。', 'native_stage.py'),
    ('uv.suv_native_stage_workflow', 'Core Workflow', 'Core Workflow. Collects workflow-oriented helper actions that stage unwrap, relax, repair, and finish steps in a repeatable order. / Core Workflow。展開、リラックス、修復、仕上げを再現しやすい順序で進めるためのワークフロー補助を集約します。', 'native_stage.py'),
    ('uv.suv_native_uv_action', 'Core UV Action', 'Expose Core UV', 'flow.py'),
    ('uv.suv_open_diagnostics_text', 'Open Diagnostics Text', 'Open one of the UV Suite diagnostics text datablocks in Blender', 'pro_operators.py'),
    ('uv.suv_orient_groups_advanced', 'Orient Groups Advanced', 'Normalize island or group orientation with snap locks, world-axis targets, and group-aware pivots for external-tool-style layout cleanup. / スナップ角、世界軸ターゲット、グループ単位ピボットで、Smart UV Suite風の向き正規化を行います。', 'flow.py'),
    ('uv.suv_orient_islands', 'Orient Islands', 'Orient selected islands to a more consistent rotation for easier reading and packing. / 選択アイランドの回転をより一貫した向きへ揃え、把握やパックをしやすくします。', 'flow.py'),
    ('uv.suv_orient_to_edge', 'Orient to Edge', 'Rotate islands so a chosen edge direction becomes the main orientation reference. / 指定したエッジ方向を主方向として、アイランドの向きを揃えます。', 'flow.py'),
    ('uv.suv_pack_pro', 'Pack Pro', 'Pack UV islands using the suite', 'pro_operators.py'),
    ('uv.suv_preset_library_io', 'Preset Library I/O', 'Export, import, and capture UV Suite hotspot/layout/seam/pack/density/inspector/workflow preset libraries. / UV Suite のホットスポット・レイアウト・シーム・パック・密度・監査/補正・ワークフローバンドル用プリセットライブラリを入出力し、現在設定から登録できます。', 'flow.py'),
    ('uv.suv_priority_density_pack', 'Priority Density Pack', 'Apply tiered texel-density priorities to hero, secondary and filler groups before packing, similar to hero-weighted workflows in external UV tools. / ヒーロー、準主役、埋め要素に段階的なテクセル密度を与えてからパックし、Smart UV Suiteのヒーロー優先ワークフローに近い結果を作ります。', 'flow.py'),
    ('uv.suv_projection_bridge', 'Projection Bridge', 'Merged projection bridge that consolidates camera-planar, normal-auto, peel, pelt, spline-tube and scan-safe workflows into a single operator family. / カメラ平面、法線ベース自動、Peel、Pelt、チューブ投影、スキャン安全系を1つにまとめた統合投影オペレーターです。', 'flow.py'),
    ('uv.suv_quality_apply_dashboard_preset', 'Apply Dashboard Preset', 'Apply a compact dashboard preset that adjusts focus, density, and visible sections together. / フォーカス、表示密度、表示セクションをまとめて切り替えるダッシュボードプリセットを適用します。', 'quality_presets.py'),
    ('uv.suv_quality_audit_suite', 'Quality Audit', 'Write a compact quality audit report that summarizes guards, preparation layers, translations, tool_runtime log health, readiness, and cleanup candidates. / ガード層、事前準備層、翻訳、実行ログ状態、準備状況、クリーンアップ候補をまとめた品質監査レポートを作成します。', 'quality_audit.py'),
    ('uv.suv_quality_cleanup_generated_data', 'Cleanup Generated Data', 'Remove stale UV Suite text reports and orphan helper images or materials that are no longer referenced. / 参照されていない UV Suite の古いテキストレポートや不要な補助画像・マテリアルを削除します。', 'quality_housekeeping.py'),
    ('uv.suv_quality_clear_notice_cache', 'Clear Quality Notice Cache', 'Clear the deduplicated quality notice cache so setup and recovery hints can be shown again. / 重複抑制している品質通知キャッシュを消去し、準備や復旧のヒントを再表示できるようにします。', 'quality_audit.py'),
    ('uv.suv_quality_clear_status_cache', 'Clear Status Cache', 'Clear the cached visual status snapshot so the dashboard recomputes state immediately. / 視覚ステータスのキャッシュ済みスナップショットを消去し、ダッシュボード状態をすぐ再計算できるようにします。', 'quality_state.py'),
    ('uv.suv_quality_cycle_focus_mode', 'Cycle Focus Mode', 'Cycle through the quick visual guide focus modes. / クイック視覚ガイドのフォーカス表示を順番に切り替えます。', 'quality_focus.py'),
    ('uv.suv_quality_open_audit_text', 'Open Quality Audit', 'Open the latest UV Suite quality audit text block in Blender Text Editor. / 最新の UV Suite 品質監査テキストを Blender のテキストエディタで開きます。', 'quality_audit.py'),
    ('uv.suv_quality_open_controls_report', 'Open Visual Controls Report', 'Open the latest visual controls report in Blender Text Editor. / 最新の視覚コントロールレポートを Blender のテキストエディタで開きます。', 'quality_controls_report.py'),
    ('uv.suv_quality_open_doctor_report', 'Open Quality Doctor', 'Open the latest UV Suite quality doctor report in Blender Text Editor. / 最新の UV Suite 品質ドクターレポートを Blender のテキストエディタで開きます。', 'quality_doctor.py'),
    ('uv.suv_quality_open_execution_profiles', 'Open Execution Profiles', 'Open the latest UV Suite execution profile report in Blender Text Editor. / 最新の UV Suite 実行プロファイルレポートを Blender のテキストエディタで開きます。', 'quality_profiles.py'),
    ('uv.suv_quality_open_external_feature_parity', 'Open External Feature Parity', 'Open the latest external feature parity report in Blender Text Editor. / 最新の外部対応レポートを Blender のテキストエディタで開きます。', 'quality_parity.py'),
    ('uv.suv_quality_open_feature_matrix', 'Open Feature Matrix', 'Open the latest UV Suite feature-matrix text block in Blender Text Editor. / 最新の UV Suite 機能マトリクステキストを Blender のテキストエディタで開きます。', 'quality_matrix.py'),
    ('uv.suv_quality_open_guided_help', 'Open Guided Help', 'Open the latest UV Suite guided-help text block in Blender Text Editor. / 最新の UV Suite ガイドヘルプテキストを Blender のテキストエディタで開きます。', 'quality_help.py'),
    ('uv.suv_quality_open_language_coverage', 'Open Language Coverage', 'Open the latest UV Suite language and tooltip coverage report in Blender Text Editor. / 最新の UV Suite 言語対応・ツールチップ対応レポートを Blender のテキストエディタで開きます。', 'quality_language.py'),
    ('uv.suv_quality_open_operator_catalog', 'Open Operator Catalog', 'Open the latest UV Suite operator catalog text block in Blender Text Editor. / 最新の UV Suite オペレーターカタログを Blender のテキストエディタで開きます。', 'quality_catalog.py'),
    ('uv.suv_quality_open_report_hub', 'Open Report Hub', 'Open the latest UV Suite report hub in Blender Text Editor. / 最新の UV Suite レポートハブを Blender のテキストエディタで開きます。', 'quality_reports.py'),
    ('uv.suv_quality_open_report_registry', 'Open Report Registry', 'Open the latest UV Suite report registry in Blender Text Editor. / 最新の UV Suite レポートレジストリを Blender のテキストエディタで開きます。', 'quality_registry.py'),
    ('uv.suv_quality_open_task_playbook', 'Open Task Playbook', 'Open the latest UV Suite task playbook in Blender Text Editor. / 最新の UV Suite タスク別プレイブックを Blender のテキストエディタで開きます。', 'quality_playbook.py'),
    ('uv.suv_quality_open_ui_map', 'Open Visual UI Map', 'Open the latest UV Suite visual UI map in Blender Text Editor. / 最新の UV Suite 視覚UIマップを Blender のテキストエディタで開きます。', 'quality_ui_map.py'),
    ('uv.suv_quality_prepare_context_basics', 'Prepare Basic Context', 'Promote a selected mesh to active, enter Edit Mode, and create a UV map when needed so common UV tools can start from a safer baseline. / 選択メッシュをアクティブ化し、必要に応じて編集モードへ入り、UVマップを作成して、一般的なUVツールをより安全な初期状態から始められるようにします。', 'quality_context.py'),
    ('uv.suv_quality_reset_section_visibility', 'Reset Section Visibility', 'Show every dashboard section again. / 非表示にしたダッシュボードセクションをすべて再表示します。', 'quality_sections.py'),
    ('uv.suv_quality_reset_visual_controls', 'Reset Visual Controls', 'Reset focus, density, preset, and section visibility back to the adaptive defaults. / フォーカス、表示密度、プリセット、セクション表示を自動の初期状態へ戻します。', 'quality_sync.py'),
    ('uv.suv_quality_scan_context_readiness', 'Scan Context Readiness', 'Check whether the current active object, mode, editors, and UV map state are ready for common UV Suite actions. / 現在のアクティブ対象、モード、エディター、UVマップ状態が UV Suite の一般的な作業に適しているか確認します。', 'quality_context.py'),
    ('uv.suv_quality_scan_feature_matrix', 'Build Feature Matrix', 'Build a compact feature-matrix report that compares the current add-on surface against common UV tool groups such as unwrap, packing, QA, symmetry, atlas, and maintenance support. / 展開、パッキング、QA、対称、アトラス、保守支援など、代表的なUV機能群に対する現在のアドオン対応状況を簡易マトリクスとして作成します。', 'quality_matrix.py'),
    ('uv.suv_quality_scan_generated_data', 'Scan Generated Data', 'Count stale UV Suite helper data so you can see how much generated cleanup is available before deleting anything. / 生成済みの UV Suite 補助データを数え、削除前にどれだけクリーンアップ対象があるか確認します。', 'quality_housekeeping.py'),
    ('uv.suv_quality_set_density_mode', 'Set Dashboard Density', 'Switch how compact the dashboard status chips should be. / ダッシュボードの状態表示をどの程度コンパクトにするか切り替えます。', 'quality_density.py'),
    ('uv.suv_quality_set_focus_mode', 'Set Focus Mode', 'Switch the quick visual guide focus mode so only the most relevant card groups stay visible. / クイック視覚ガイドのフォーカス表示を切り替え、今必要なカード群だけを見やすくします。', 'quality_focus.py'),
    ('uv.suv_quality_set_section_visibility', 'Set Section Visibility', 'Show or hide a dashboard section to keep the quick guide compact. / ダッシュボードのセクション表示を切り替えて、クイックガイドをコンパクトに保ちます。', 'quality_sections.py'),
    ('uv.suv_quality_write_controls_report', 'Write Visual Controls Report', 'Write a compact report that explains the current dashboard focus, density, section visibility, preset state, and manual visual-control overrides. / 現在のダッシュボードのフォーカス、表示密度、セクション表示、プリセット状態、手動の視覚コントロール上書きをまとめたレポートを書き出します。', 'quality_controls_report.py'),
    ('uv.suv_quality_write_doctor_report', 'Write Quality Doctor', 'Write a prioritized action plan that tells you what to fix next based on readiness, tool_runtime errors, blocked operator contexts, translation gaps, and missing feature groups. / 準備状況、実行時エラー、停止中オペレーター、翻訳不足、不足機能グループをもとに、次に何を直すべきか優先順で示すアクションプランを作成します。', 'quality_doctor.py'),
    ('uv.suv_quality_write_execution_profiles', 'Write Execution Profiles', 'Write a category-based execution profile report that shows which operator groups require UV Editor, Edit Mode, selection, or 3D View context before they run. / UVエディター、編集モード、選択状態、3Dビューなどの前提が必要なオペレーター群をカテゴリ別にまとめた実行プロファイルレポートを書き出します。', 'quality_profiles.py'),
    ('uv.suv_quality_write_external_feature_parity', 'Write External Feature Parity', 'Write a coverage-style report for industry tools and the attached reference add-ons, including direct bridges, compatibility bridges, and still-partial rows. / 業界ツールと添付参照アドオンの対応状況を、直接ブリッジ・互換ブリッジ・部分対応を含めてレポート化します。', 'quality_parity.py'),
    ('uv.suv_quality_write_guided_help', 'Write Guided Help', 'Write a beginner-friendly guided help text with setup order, recommended workflows, and troubleshooting steps for the current UV Suite build. / 現在の UV Suite 用に、準備順、推奨ワークフロー、トラブルシュートをまとめた初心者向けガイドヘルプを書き出します。', 'quality_help.py'),
    ('uv.suv_quality_write_language_coverage', 'Write Language Coverage', 'Write a translation and tooltip coverage report so you can see which labels already translate well and which items still need stronger bilingual help text. / 翻訳とツールチップ対応のレポートを書き出し、どのラベルが十分に翻訳されているか、どの項目に英日説明の強化が必要かを確認できるようにします。', 'quality_language.py'),
    ('uv.suv_quality_write_operator_catalog', 'Write Operator Catalog', 'Write a categorized UV Suite operator and UI catalog so you can review the current tool surface by workflow group. / 現在のツール群をワークフロー別に見直せるよう、UV Suite のオペレーターと UI をカテゴリ別カタログとして書き出します。', 'quality_catalog.py'),
    ('uv.suv_quality_write_report_hub', 'Write Report Hub', 'Write a compact hub text that lists the main generated UV Suite reports so you can open audits, matrices, help, and language reports from a single place. / 主要な UV Suite 生成レポートを一覧化したハブテキストを書き出し、監査、マトリクス、ヘルプ、言語対応レポートを一か所から確認しやすくします。', 'quality_reports.py'),
    ('uv.suv_quality_write_report_registry', 'Write Report Registry', 'Write a compact registry that lists generated report texts and registered quality helpers so you can manage report-side assets from one place. / 生成済みレポートテキストと登録済み品質ヘルパーを一覧化したレジストリを書き出し、レポート系資産を一か所から管理しやすくします。', 'quality_registry.py'),
    ('uv.suv_quality_write_task_playbook', 'Write Task Playbook', 'Write a task-based playbook that groups the current UV Suite tool surface into beginner-friendly workflows such as setup, unwrap, packing, symmetry, and inspection. / 現在の UV Suite の機能面を、準備、展開、パッキング、対称、検査などの初心者向けワークフロー単位でまとめたタスク別プレイブックを書き出します。', 'quality_playbook.py'),
    ('uv.suv_quality_write_ui_map', 'Write Visual UI Map', 'Write a compact map of the current visual dashboard sections, cards, and actions so beginners can see where each quick entry lives. / 現在の視覚ダッシュボードのセクション、カード、アクションをまとめたマップを書き出し、初心者でも各クイック入口の場所を把握しやすくします。', 'quality_ui_map.py'),
    ('uv.suv_randomize_islands', 'Randomize Islands', 'Add controlled random offsets, rotation or scale changes to selected islands. / 選択アイランドへ制御されたランダム移動・回転・拡縮を加えます。', 'flow.py'),
    ('uv.suv_reload_custom_icons', 'Reload Icons', 'Reload the UV Suite custom icon set after reinstalling or replacing icon files. / 再インストールや差し替え後に UV Suite のカスタムアイコンを再読込します。', 'pro_operators.py'),
    ('uv.suv_repair_flipped_islands', 'Repair Flipped Islands', 'Detect and fix flipped UV islands so their winding direction becomes consistent again. / 反転したUVアイランドを検出して修正し、向きを再び揃えます。', 'legacy_operators.py'),
    ('uv.suv_rotate_islands', 'Rotate Islands', 'Rotate selected islands by a controlled amount for orientation and packing cleanup. / 選択アイランドを指定角度で回転し、向きやパッキングを整えます。', 'flow.py'),
    ('uv.suv_seam_set_delete', 'Delete Seam Set', 'Delete a saved seam set you no longer need. / 不要になった保存シームセットを削除します。', 'selection_operators.py'),
    ('uv.suv_seam_set_library_io', 'Seam Set Library I/O', 'Export or import saved seam sets as Blender Text or JSON files so seam designs can be reused across scenes and repeated assets. / 保存したシームセットを Blender Text や JSON ファイルへ入出力し、シーンや繰り返しアセットをまたいで再利用できるようにします。', 'selection_operators.py'),
    ('uv.suv_seam_set_recall', 'Recall Seam Set', 'Recall a previously saved seam set and apply it back onto the active mesh. / 以前保存したシームセットを呼び出し、アクティブメッシュへ再適用します。', 'selection_operators.py'),
    ('uv.suv_seam_set_save', 'Save Seam Set', 'Save the current seam design into a reusable slot so the same seam state can be recalled later. / 現在のシーム設計を再利用できるスロットへ保存し、あとで同じシーム状態を呼び出せるようにします。', 'selection_operators.py'),
    ('uv.suv_seam_set_transfer', 'Transfer Seam Set', 'Copy a saved seam set from the active mesh to the other selected meshes so repeated assets can reuse the same seam design slot. / アクティブメッシュの保存済みシームセットを他の選択メッシュへコピーし、繰り返しアセットでも同じシーム設計スロットを再利用できるようにします。', 'selection_operators.py'),
    ('uv.suv_seam_set_update', 'Update Seam Set', 'Update an existing saved seam set with the current seam state. / 既存の保存シームセットを現在のシーム状態で更新します。', 'selection_operators.py'),
    ('uv.suv_select_fragmented_islands', 'Select Shattered Islands', 'Select shattered, tiny or sliver-like UV islands so fragmented shells are easier to review and repair. / 細切れ、極小、または細長いUVアイランドを選択し、分断されたシェルの確認と修正をしやすくします。', 'selection_operators.py'),
    ('uv.suv_select_identical_islands', 'Select Identical Islands', 'Find islands that are nearly identical to the reference island for stacking or reuse workflows. / 基準アイランドとほぼ同一のアイランドを探し、スタックや再利用作業に使いやすくします。', 'selection_operators.py'),
    ('uv.suv_select_island_active', 'Select Island (Active)', 'Select the full UV island that belongs to the current active or picked element. / 現在アクティブな要素に属するUVアイランド全体を選択します。', 'selection_operators.py'),
    ('uv.suv_select_similar_islands', 'Select Similar Islands', 'Find islands that are similar in size and proportions to the current reference island. / 現在の基準アイランドに近いサイズと比率を持つアイランドを探して選択します。', 'selection_operators.py'),
    ('uv.suv_select_udim_crossing', 'Select UDIM Crossing', 'Select islands that cross tile boundaries so they can be corrected for UDIM workflows. / タイル境界をまたいでいるアイランドを選択し、UDIM作業向けに修正しやすくします。', 'flow.py'),
    ('uv.suv_select_uv_boundary', 'Select UV Boundary', 'Select boundary edges or border elements of the current UV selection. / 現在のUV選択の境界エッジや外周要素を選択します。', 'selection_operators.py'),
    ('uv.suv_select_zero_islands', 'Select Zero Area', 'Select islands whose UV area collapses to almost zero. / UV面積がほぼゼロになっているアイランドを選択します。', 'flow.py'),
    ('uv.suv_set_delete', 'Delete Set', 'Delete a saved settings slot you no longer need. / 不要になった保存設定スロットを削除します。', 'selection_operators.py'),
    ('uv.suv_set_flow', 'Set Flow', 'Redistribute UV points along a smoother flow to better follow the intended strip direction. / UV点をより滑らかな流れに再配置し、意図したストリップ方向へ沿わせます。', 'flow.py'),
    ('uv.suv_set_library_io', 'Selection Set Library I/O', 'Export or import saved selection sets as Blender Text or JSON files so they can be reused across scenes and assets. / 保存した選択セットを Blender Text や JSON ファイルへ入出力し、シーンやアセットをまたいで再利用できるようにします。', 'selection_operators.py'),
    ('uv.suv_set_recall', 'Recall Set', 'Recall a previously saved workspace or tool settings slot. / 以前保存したワークスペースやツール設定スロットを呼び出します。', 'selection_operators.py'),
    ('uv.suv_set_save', 'Save Set', 'Save the current workspace or tool settings into a reusable slot. / 現在のワークスペースやツール設定を再利用できるスロットへ保存します。', 'selection_operators.py'),
    ('uv.suv_set_transfer', 'Transfer Set', 'Copy a saved selection set from the active mesh to the other selected meshes so repeated assets can reuse the same selection slot. / アクティブメッシュの保存セットを他の選択メッシュへコピーし、繰り返しアセットでも同じ選択スロットを再利用できるようにします。', 'selection_operators.py'),
    ('uv.suv_set_update', 'Update Set', 'Update an existing saved settings slot with the current workspace state. / 既存の保存設定スロットを現在のワークスペース状態で更新します。', 'selection_operators.py'),
    ('uv.suv_similarity_cluster_tools', 'UV Similarity Clusters', 'Cluster similar UV islands, write similarity reports and exports, then select reuse candidates or unique islands. / 類似するUVアイランドをクラスタ化し、レポート・書き出し・再利用候補や単独島の選択を行います。', 'native_stage.py'),
    ('uv.suv_smart_3d_transfer', '3D Smart Transfer', 'Transfer UV orientation or layout hints from the 3D model state to the current UV selection. / 3Dモデル側の向きや状態を手掛かりに、現在のUV選択へ配置のヒントを転送します。', 'legacy_operators.py'),
    ('uv.suv_smart_edge_straighten', 'Smart Edge Straighten', 'Straighten selected UV edges or chains for cleaner trims, strips and hard-surface borders. / 選択したUVエッジやチェーンを直線化し、トリムやハードサーフェス境界を整えます。', 'legacy_operators.py'),
    ('uv.suv_smart_rectify', 'Smart Rectify', 'Rectify selected UV shells into cleaner rectangular shapes for hard-surface and atlas workflows. / 選択したUVシェルをより矩形に整え、ハードサーフェスやアトラス作業に向けて整理します。', 'legacy_operators.py'),
    ('uv.suv_smart_relax', 'Smart Relax', 'Relax the current UV selection to reduce visible stretching while keeping the overall shell layout stable. / 現在のUV選択をリラックスして、全体レイアウトを大きく崩さずに伸び歪みを減らします。', 'legacy_operators.py'),
    ('uv.suv_smart_seams', 'Smart Seams', 'Create seams automatically from the suite', 'legacy_operators.py'),
    ('uv.suv_smart_tube', 'Smart Tube', 'Unwrap cylindrical or tube-like selections with a streamlined helper aimed at pipes, cables and similar shapes. / 円筒やチューブ状の選択を、パイプやケーブル向けの簡易補助で展開します。', 'legacy_operators.py'),
    ('uv.suv_sort_islands', 'Sort Islands', 'Sort islands by size and place them in a tidy row or column. / アイランドを大きさ順に並べ、行または列へ見やすく整理します。', 'flow.py'),
    ('uv.suv_stack_grouped', 'Stack Grouped Islands', 'Find similar or nearly identical islands and stack them onto shared UV space. / 類似またはほぼ同一のアイランドを見つけて同じUV空間へ重ねます。', 'flow.py'),
    ('uv.suv_stack_pro', 'Stack Pro', 'Stack matching islands with the suite', 'pro_operators.py'),
    ('uv.suv_stack_symmetry_topology', 'Stack Symmetric Topology', 'Stack symmetry-detected island pairs with optional topology validation, similar to mirror-aware reuse workflows in external UV tools. / 対称検出したアイランドペアを、必要ならトポロジー一致も確認しつつ重ねます。Smart UV Suiteのミラー再利用フロー寄りです。', 'flow.py'),
    ('uv.suv_stack_topology_groups', 'Stack Topology Groups', 'Stack islands that share the same face/vertex topology signature, similar to topology-aware reuse tools in external UV add-ons. / 面数・頂点数・境界構成が一致するアイランドを、Smart UV Suite風にトポロジー単位でスタックします。', 'flow.py'),
    ('uv.suv_straight_line', 'Straighten Line', 'Straighten a UV chain into a clean line, optionally redistributing points evenly. / UVチェーンを綺麗な直線へ整え、必要に応じて点間隔も均等化します。', 'flow.py'),
    ('uv.suv_sym_detect_pairs', 'Detect Symmetry Pairs', 'Detect symmetric UV pairs that can be mirrored, stacked or edited together. / ミラーやスタック、同時編集に使える対称UVペアを検出します。', 'symmetry_atlas_operators.py'),
    ('uv.suv_sym_mirror_uv', 'Mirror UV (Ref -> Pair)', 'Mirror UVs from one side of a detected pair to the opposite side. / 検出されたペアの片側から反対側へUVをミラー転送します。', 'symmetry_atlas_operators.py'),
    ('uv.suv_sym_seams', 'Symmetry Seams', 'Create seam suggestions that respect detected symmetry relationships. / 検出した対称関係を保ちながら使いやすいシーム候補を作成します。', 'symmetry_atlas_operators.py'),
    ('uv.suv_sym_stack', 'Symmetry Stack', 'Stack symmetric UV islands together to maximize reuse and alignment. / 対称UVアイランドを重ねて再利用性と整列性を高めます。', 'symmetry_atlas_operators.py'),
    ('uv.suv_texel_get', 'Get Density', 'Measure the current texel density from the selection and store it as a reusable working value. / 現在の選択からテクセル密度を測定し、再利用できる作業値として取得します。', 'pro_operators.py'),
    ('uv.suv_texel_group_tools', 'Texel Group Tools', 'Normalize and audit texel density by material or UDIM tile groups. / マテリアル別またはUDIMタイル別にテクセル密度を整えたり監査します。', 'native_stage.py'),
    ('uv.suv_texel_normalize', 'Normalize Density', 'Normalize texel density across selected islands so different shells share a more even texture scale. / 選択アイランド間のテクセル密度を均一化し、テクスチャの見た目スケールを揃えます。', 'pro_operators.py'),
    ('uv.suv_texel_set', 'Set Density', 'Apply the stored or specified texel density to the current UV selection. / 保存済みまたは指定したテクセル密度を現在のUV選択へ適用します。', 'pro_operators.py'),
    ('uv.suv_trim_band_layout', 'Layout Trim Band', 'Arrange islands into multiple trimsheet bands while preserving relative scale as much as possible. / 選択アイランドを複数のトリム帯へ整理し、できるだけ相対スケールを保って配置します。', 'flow.py'),
    ('uv.suv_trim_band_refill', 'Refill Trim Band', 'Reuse already-open trim bands on current tiles first, then spill remaining groups to new trim bands. / 現在のタイル上で空いているトリム帯を優先再利用し、残りだけを新しいトリム帯へ流します。', 'flow.py'),
    ('uv.suv_trim_strip_layout', 'Layout Trim Strip', 'Arrange selected islands as a clean row or column for trimsheet-style workflows. / 選択アイランドをトリムシート向けの行・列レイアウトに整えます。', 'flow.py'),
    ('uv.suv_udim_step', 'Move by Tile', 'Move selected islands by exact UDIM tile offsets. / 選択アイランドをUDIMタイル単位で正確に移動します。', 'flow.py'),
    ('uv.suv_udim_tile_tools', 'UDIM Tile Tools', 'Select, move and audit UV islands by UDIM tile. / UDIMタイル単位でUVアイランドを選択・移動・監査します。', 'native_stage.py'),
    ('uv.suv_unstack_groups', 'Unstack Groups', 'Separate similar, identical or topology-matched island groups into nearby tiles or offsets, closer to dedicated unstack tools in external UV add-ons. / 類似・同一・トポロジー一致のアイランド群を近隣タイルやオフセットへ分離し、外部UVアドオンの専用Unstack系に近い運用を行います。', 'flow.py'),
    ('uv.suv_unstack_overlapped', 'Unstack Overlapped', 'Separate stacked or heavily overlapping islands by offsetting them into nearby tiles. / 重なっている、または強くスタックしているアイランドを近隣タイルへずらして分離します。', 'flow.py'),
    ('uv.suv_uv_brush_compat', 'UV Brush Compatibility', 'Brush-style UV deformation helpers with twirl, center, and falloff controls that approximate grab, pinch, puff, smear, and smooth workflows from other UV tools. / 他UVツールのグラブ・ピンチ・パフ・スメア・スムーズに加え、ツイール・中心基準・フォールオフ制御を備えた近似UVブラシ補助ツールです。', 'flow.py'),
    ('uv.suv_uv_edit_compat_tools', 'UV Edit Compatibility Tools', 'Compatibility helpers for missing UV editing actions such as invert selection, island-border select, seams-from-islands, sharp-from-islands and split-move. / 選択反転、アイランド境界選択、アイランド境界からのシーム・シャープ生成、分離移動などを補う互換UV編集ツールです。', 'flow.py'),
    ('uv.suv_uv_lattice_compat', 'UV Lattice', 'Approximate UV lattice / cage deformation helpers such as shear and taper on the current UV selection. / 現在のUV選択に対して、シアーやテーパーなどのUVラティス／ケージ変形を近似適用します。', 'native_stage.py'),
    ('uv.suv_uv_seam_candidate_overlay_tools', 'UV Seam Candidate Overlay', 'Build or clear a mesh preview overlay derived from seam-candidate scoring, so seam strength and reasons can be judged directly on the model. / シーム候補の採点結果をメッシュ上の色プレビューにし、候補の強さや理由をモデル上で直接判断できるようにします。', 'native_stage.py'),
    ('uv.suv_uv_seam_candidate_profile_audit_tools', 'UV Seam Candidate Profile Audit', 'Compare built-in, stored, and current seam-candidate profiles against the active mesh, so the best profile can be chosen before overlay, selection, or seam marking. / 組み込み・保存済み・現在設定のシーム候補プロファイルをアクティブメッシュで比較し、オーバーレイ・選択・シーム化の前に最適なプロファイルを選べるようにします。', 'native_stage.py'),
    ('uv.suv_uv_seam_candidate_profile_batch_tools', 'Batch UV Seam Candidate Profiles', 'Apply a saved or built-in seam-candidate profile across all selected mesh objects, so the same seam rules can be reused for batch reports, overlays, selection, and seam marking. / 保存済みまたは組み込みのシーム候補プロファイルを選択メッシュ全体へ一括適用し、同じシーム規則をバッチのレポート・オーバーレイ・選択・シーム化に再利用できるようにします。', 'native_stage.py'),
    ('uv.suv_uv_seam_candidate_profile_tools', 'UV Seam Candidate Profiles', 'Save, reuse, preview, select, and mark seam-candidate profiles so the same scoring rules can be applied across audit, overlay, and seam passes. / シーム候補プロファイルを保存・再利用し、同じ採点ルールを検査・オーバーレイ・シーム化に一貫して使えるようにします。', 'native_stage.py'),
    ('uv.suv_uv_seam_candidate_tools', 'UVシーム候補', 'Score seam candidates from UV borders, sharp edges, material boundaries and face angles, then report, filter, select or mark them as seams. / UV境界・シャープ・マテリアル境界・面角度からシーム候補を採点し、レポート・フィルタ・選択・シーム化を行います。', 'native_stage.py'),
    ('uv.suv_uv_seam_gap_tools', 'UV Seam Gap Tools', 'Select seam gaps from UV-border edges or mark them as seams directly, so seam-state overlays can flow into real fixes. / UV境界のシーム抜けをそのまま選択したり、直接シーム化して、シーム状態オーバーレイから実際の修正へつなげます。', 'native_stage.py'),
    ('uv.suv_uv_seam_state_overlay_tools', 'UV Seam State Overlay', 'Build or clear a mesh preview overlay derived from UV border seam state, so seam gaps and coverage can be inspected directly on the model. / UV境界のシーム状態をメッシュ上の色プレビューにし、シームの抜けやカバー率をモデル上で直接確認できるようにします。', 'native_stage.py'),
    ('uv.suv_uv_similarity_cluster_overlay_tools', 'UV Similarity Cluster Overlay', 'Build or clear a mesh preview overlay derived from UV similarity clusters so identical, similar and unique islands can be reviewed directly on the model. / UV類似クラスタの結果をメッシュ上の色プレビューにし、同一・類似・単独アイランドをモデル上で直接確認できるようにします。', 'native_stage.py'),
    ('uv.suv_uv_stack_compare_overlay_tools', 'UV Stack Compare Overlay', 'Build or clear a mesh preview overlay derived from the latest UV stack snapshot compare, so changed loops can be inspected directly on the model. / 最新のUVスタックスナップショットとの差分をメッシュ上の色プレビューにし、変更ループを直接確認できるようにします。', 'native_stage.py'),
    ('uv.suv_validate_workflow_assets', 'Validate Workflow Assets', 'Validate workflow bundles, recipes, and their referenced preset libraries to catch missing links before running a large job. / ワークフローバンドル、レシピ、その参照ライブラリを検証し、大きなジョブを走らせる前に欠落リンクを検出します。', 'flow.py'),
    ('uv.suv_workspace_auto_repair', 'Auto Repair Workspace', 'Repair common UV Suite setup issues such as missing UV maps, stale cache values and unloaded custom icons. / UV未作成、古いキャッシュ、未読込アイコンなどの代表的なセットアップ問題を自動修復します。', 'pro_operators.py'),
    ('uv.suv_workspace_reset', 'Reset Workspace', 'Reset the UV Suite workspace settings back to a safe default starting point. / UV Suite のワークスペース設定を安全な初期状態へ戻します。', 'pro_operators.py'),
    ('uv.suv_workspace_settings_io', 'Workspace Settings I/O', 'Export or import UV Suite workspace settings as JSON text or JSON files. / UV Suite のワークスペース設定を JSON テキストまたは JSON ファイルとして入出力します。', 'pro_operators.py'),
    ('uv.suv_workspace_validate', 'Validate Workspace', 'Run a UV Suite health check for workspace settings, icons and selected mesh UV readiness. / ワークスペース設定、アイコン、選択メッシュのUV準備状態をチェックします。', 'pro_operators.py'),
    ('uv.suv_write_tool_runtime_snapshot', 'Write Snapshot', 'Write a detailed UV Suite workspace snapshot into a Blender Text datablock for debugging and support logs. / デバッグやサポート用に、UV Suite の詳細な状態スナップショットを Blender テキストへ書き出します。', 'pro_operators.py'),
    ('uv.suv_write_support_bundle', 'Write Support Bundle', 'Write a one-file support bundle that summarizes the latest UV Suite diagnostics, log tails, and snapshot tail. / UV Suite の最新診断結果、ログ末尾、スナップショット末尾を1つにまとめたサポートバンドルを出力します。', 'pro_operators.py'),
)




EXTRA_NATIVE_OPERATOR_CATALOG = (
    ('smart_uv_suite.integrated_addon_info', 'smart_uv_suite.integrated_addon_info', 'smart_uv_suite.integrated_addon_info', 'ui_tool_tool_tool_runtime.py'),
    ('smart_uv_suite.integrated_invoke', 'smart_uv_suite.integrated_invoke', 'smart_uv_suite.integrated_invoke', 'ui_tool_tool_tool_runtime.py'),
    ('smart_uv_suite.preferences_core_activation', 'Activate Core', 'Activate Core', 'preferences.py'),
    ('suv.toggle_live_unwrap', 'Toggle Live Unwrap', 'Toggle Live Unwrap. Turns Blender', 'flow.py'),
    ('uv.suv_uv_sync_mode_toggle', 'UV Sync Selection', 'Toggle Blender UV Sync Selection without leaving UV Suite. / UV Suite 内から Blender の UV同期選択 を切り替えます。', 'pro_operators.py'),
)


EXTRA_NATIVE_OPERATOR_CATALOG_2 = (
    ('smart_uv_suite.texel_density_tools', 'Texel Density Tools', 'Run a beginner-friendly texel-density entry point that applies a reusable density profile, optionally adds a checker, and falls back to guarded normalization when needed. Typical use: prepare UVs -> run this tool -> inspect the checker -> fine tune only if necessary. / 再利用可能な密度プロファイル適用、必要ならチェッカー追加、必要時は安全寄り均一化へフォールバックする初心者向けの密度入口です。使い方の目安: UV を準備 -> このツールを実行 -> チェッカー確認 -> 必要な時だけ微調整します。', 'smart_uv_cockpit.py'),
)

ALL_NATIVE_OPERATOR_CATALOG = NATIVE_OPERATOR_CATALOG + EXTRA_NATIVE_OPERATOR_CATALOG + EXTRA_NATIVE_OPERATOR_CATALOG_2

def _t(context, en: str, ja: str) -> str:
    try:
        return str(_text_translation.pick(str(en or ''), str(ja or ''), context=context))
    except Exception:
        return str(ja if _text_translation.is_japanese(context) else en)


def _ui_text(text: str, context=None) -> str:
    try:
        return str(_text_translation.inline(str(text or ''), context=context))
    except Exception:
        try:
            return str(_text_translation.translate_text(str(text or ''), context=context))
        except Exception:
            return str(text or '')


def _op_exists(op_idname: str) -> bool:
    op_idname = str(op_idname or '').strip()
    if '.' not in op_idname:
        return False
    head, tail = op_idname.split('.', 1)
    try:
        ops_group = getattr(bpy.ops, head, None)
        if ops_group is None:
            return False
        op = getattr(ops_group, tail, None)
        if op is None:
            return False
        get_rna_type = getattr(op, 'get_rna_type', None)
        if not callable(get_rna_type):
            return False
        rna = get_rna_type()
        identifier = str(getattr(rna, 'identifier', '') or '')
        return bool(identifier) and identifier not in {'Operator', 'OperatorProperties', 'UnknownType', 'bpy_struct'}
    except Exception:
        return False


def _operator_prop_names(op) -> set[str]:
    names: set[str] = set()
    try:
        props = getattr(getattr(op, 'bl_rna', None), 'properties', None)
        try:
            names.update(str(k) for k in props.keys())
        except Exception:
            pass
        try:
            for prop in props:
                ident = str(getattr(prop, 'identifier', '') or '')
                if ident:
                    names.add(ident)
        except Exception:
            pass
    except Exception:
        pass
    return names


def _safe_set_props(op, props: dict | None) -> None:
    if op is None or not props:
        return
    available = _operator_prop_names(op)
    if not available:
        return
    for key, value in dict(props).items():
        key = str(key)
        if key not in available:
            continue
        try:
            setattr(op, key, value)
        except Exception:
            pass



def _operator_has_props(op_idname: str, names) -> bool:
    if not _op_exists(op_idname):
        return False
    wanted = {str(name) for name in (names or []) if str(name)}
    if not wanted:
        return True
    try:
        head, tail = str(op_idname or '').split('.', 1)
        op = getattr(getattr(bpy.ops, head, None), tail, None)
        rna = op.get_rna_type()
        available: set[str] = set()
        props = getattr(rna, 'properties', None)
        try:
            available.update(str(k) for k in props.keys())
        except Exception:
            pass
        try:
            for prop in props:
                ident = str(getattr(prop, 'identifier', '') or '')
                if ident:
                    available.add(ident)
        except Exception:
            pass
        return wanted.issubset(available)
    except Exception:
        return False

def _draw_help_button(row, context, help_id: str, title_en: str, title_ja: str):
    try:
        if not _operator_has_props('smart_uv_suite.show_help', {'help_id', 'title_en', 'title_ja'}):
            return None
        try:
            help_row = row.row(align=True)
            help_row.scale_x = 0.82
            help_row.scale_y = 1.0
        except Exception:
            help_row = row
        op = help_row.operator('smart_uv_suite.show_help', text='', icon='QUESTION')
        _safe_set_props(op, {'help_id': str(help_id or ''), 'title_en': str(title_en or ''), 'title_ja': str(title_ja or '')})
        return op
    except Exception:
        return None



_DEFAULT_MOVED_ALWAYS_ON_IDS = frozenset({
    'suv.toggle_live_unwrap',
    'uv.suv_uv_sync_mode_toggle',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
})


def _is_moved_always_on_operator(op_id: str) -> bool:
    op_id = str(op_id or '').strip()
    if op_id in _DEFAULT_MOVED_ALWAYS_ON_IDS:
        return True
    try:
        from . import controls as _controls
        fn = getattr(_controls, 'is_moved_always_on_operator', None)
        if callable(fn):
            return bool(fn(op_id, {}))
    except Exception:
        pass
    return False

def _button(layout, op_id: str, label: str, context) -> bool:
    if str(op_id or '').startswith('smart_uv_suite.'):
        return False
    if _is_moved_always_on_operator(op_id):
        return False
    if not _op_exists(op_id):
        try:
            row = layout.row(align=True)
            row.enabled = False
            pass  # INFO-note moved to Help; no in-section info-icon explanation.
            return True
        except Exception:
            return False
    try:
        layout.operator(op_id, text=_ui_text(label or op_id, context), icon='TOOL_SETTINGS')
        return True
    except Exception:
        try:
            pass  # INFO-note moved to Help; no in-section info-icon explanation.
        except Exception:
            pass
        return False




_FOLDOUT_PREFIX = 'uv_suite_ui_foldout_'


def _foldout_prop(key: str) -> str:
    raw = str(key or '').strip().lower()
    safe = ''.join(ch if ch.isalnum() or ch == '_' else '_' for ch in raw).strip('_')
    return _FOLDOUT_PREFIX + (safe or 'section')


def _operator_rna_exists(op_idname: str) -> bool:
    try:
        head, tail = str(op_idname or '').split('.', 1)
        group = getattr(bpy.ops, head, None)
        if group is None:
            return False
        op = getattr(group, tail, None)
        rna = op.get_rna_type()
        identifier = str(getattr(rna, 'identifier', '') or '')
        return bool(identifier) and identifier not in {'Operator', 'OperatorProperties', 'UnknownType', 'bpy_struct'}
    except Exception:
        return False


def _foldout_state(context, key: str, default: bool = False) -> bool:
    try:
        from . import npanel_persistence as _npanel_store
        return bool(_npanel_store.peek_foldout(str(key or ''), bool(default)))
    except Exception:
        return bool(default)


def _draw_foldout_header(layout, context, key: str, label: str, *, icon: str = 'UV', default_open: bool = False, help_id: str = '', help_title_en: str = '', help_title_ja: str = ''):
    expanded = _foldout_state(context, key, default_open)
    box = layout.box()
    row = box.row(align=True)
    try:
        from .foldout_header import draw_foldout_header
        has_op = _operator_has_props('smart_uv_suite.toggle_ui_foldout', {'key', 'default_open'})
        draw_foldout_header(
            row, expanded, title=_ui_text(label, context), icon=icon or 'DOT', single=True,
            op='smart_uv_suite.toggle_ui_foldout' if has_op else None,
            op_props={'key': key, 'default_open': bool(default_open)}, set_props=_safe_set_props,
            draw_help=(lambda r: _draw_help_button(r, context, help_id, help_title_en or _ui_text(label, context), help_title_ja or _ui_text(label, context))) if help_id else None)
    except Exception:
        row.label(text=_ui_text(label, context), icon=icon)
    return box, expanded

def draw_native_tool_catalog(layout, context) -> int:
    'Draw native UV Suite operators that exist in code so hidden commands remain reachable.'
    if layout is None:
        return 0
    try:
        root = layout.box()
        head = root.row(align=True)
        head.label(text=_t(context, 'Smart UV Suite Tool Catalog', 'Smart UV Suite ツール一覧'), icon='UV')
        _draw_help_button(head, context, 'native_tools', 'Smart UV Suite Tool Catalog', 'Smart UV Suiteツール一覧')
    except Exception:
        return 0
    groups: dict[str, list[tuple[str, str, str, str]]] = {}
    for item in ALL_NATIVE_OPERATOR_CATALOG:
        op_id = str(item[0] or '')
        namespace = op_id.split('.', 1)[0] if '.' in op_id else 'other'
        groups.setdefault(namespace, []).append(item)
    drawn = 0
    for namespace in ('uv', 'suv', 'mesh', 'object', 'other'):
        items = [item for item in (groups.get(namespace) or []) if not _is_moved_always_on_operator(str(item[0] or ''))]
        if not items:
            continue
        title = {
            'uv': _t(context, 'UV Operators', 'UVオペレーター'),
            'suv': _t(context, 'UV Suite Operators', 'UV Suiteオペレーター'),
            'mesh': _t(context, 'Mesh Operators', 'メッシュオペレーター'),
            'object': _t(context, 'Object Operators', 'オブジェクトオペレーター'),
            'other': _t(context, 'Other Operators', 'その他オペレーター'),
        }.get(namespace, namespace)
        box, expanded = _draw_foldout_header(root, context, f'native_catalog_{namespace}', f'{title} ({len(items)})', icon='UV', default_open=False, help_id=f'native:{namespace}', help_title_en=str(title), help_title_ja=str(title))
        if not expanded:
            continue
        col = box.column(align=True)
        for op_id, label, _desc, _source in items:
            if _button(col, op_id, label, context):
                drawn += 1
    return drawn
