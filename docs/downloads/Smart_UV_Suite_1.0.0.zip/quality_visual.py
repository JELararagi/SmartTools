from __future__ import annotations


def _text(namespace: dict, context, key: str, default_en: str, default_ja: str):
    tr = namespace.get('tr')
    if callable(tr):
        try:
            return tr(context, key)
        except Exception:
            pass
    prefs = None
    try:
        prefs = namespace.get('_prefs')(context)
    except Exception:
        prefs = None
    lang = getattr(prefs, 'ui_language_mode', 'AUTO') if prefs else 'AUTO'
    if lang == 'FORCE_JA':
        return default_ja
    return default_en


def _bool_text(namespace: dict, context, value: bool) -> str:
    return _text(namespace, context, 'ui.bool.on', 'On', 'オン') if value else _text(namespace, context, 'ui.bool.off', 'Off', 'オフ')


def _density_data(namespace: dict, context, status: dict) -> dict:
    density_mod = namespace.get('_quality_density_module')
    if density_mod is not None and hasattr(density_mod, 'scan_density_control'):
        try:
            data = density_mod.scan_density_control(namespace, context) or {}
            if isinstance(data, dict):
                return data
        except Exception:
            pass
    return {
        'override': str(status.get('density_override', 'AUTO') or 'AUTO'),
        'manual': bool(status.get('density_manual', False)),
        'effective': str(status.get('density_mode', 'FULL') or 'FULL'),
    }


def _essential_chip_keys() -> set[str]:
    return {
        'ui.visual.target',
        'ui.visual.sync',
        'ui.visual.readiness_score',
        'ui.visual.tool_runtime_errors',
        'ui.visual.doctor_actions',
        'ui.visual.recommended_actions',
        'ui.visual.focus_mode',
        'ui.visual.dashboard_density',
    }


def _suv_ui_operator_prop_names(op) -> set[str]:
    names: set[str] = set()
    try:
        prop_defs = getattr(getattr(op, 'bl_rna', None), 'properties', None)
    except Exception:
        prop_defs = None
    try:
        names.update(str(k) for k in prop_defs.keys())
    except Exception:
        pass
    try:
        for prop in prop_defs or ():
            ident = str(getattr(prop, 'identifier', '') or '')
            if ident:
                names.add(ident)
    except Exception:
        pass
    return names


def _suv_safe_set_ui_operator_prop(op, prop_name: str, value) -> bool:
    prop_name = str(prop_name or '')
    if not op or not prop_name:
        return False
    try:
        if prop_name not in _suv_ui_operator_prop_names(op):
            return False
        setattr(op, prop_name, value)
        return True
    except Exception:
        return False


def _safe_op(layout, cls, text: str | None = None, icon: str = 'NONE', props: dict | None = None):
    if cls is None:
        return None
    bl_idname = getattr(cls, 'bl_idname', '')
    if not bl_idname:
        return None
    label = text or getattr(cls, 'bl_label', '') or bl_idname
    op = layout.operator(bl_idname, text=label, icon=icon)
    if props:
        for key, value in props.items():
            try:
                _suv_safe_set_ui_operator_prop(op, key, value)
            except Exception:
                pass
    return op


def _status_dict(namespace: dict, context):
    state_mod = namespace.get('_quality_state_module')
    if state_mod is not None and hasattr(state_mod, 'collect_status'):
        try:
            cached = state_mod.collect_status(namespace, context)
            if isinstance(cached, dict):
                return dict(cached)
        except Exception:
            pass
    obj = getattr(context, 'active_object', None)
    obj_name = getattr(obj, 'name', '') if obj else 'None'
    try:
        uv_sync = bool(getattr(getattr(context, 'tool_settings', None), 'use_uv_select_sync', False))
    except Exception:
        uv_sync = False
    return {'target_name': obj_name or 'None', 'uv_sync': uv_sync, 'issue_total': 0, 'workspace': None, 'guard_total': 0, 'preflight_total': 0, 'restore_total': 0, 'cleanup_total': 0, 'readiness_score': 0, 'readiness_missing': 0, 'tool_runtime_errors': 0, 'coverage_supported': 0, 'coverage_total': 0, 'coverage_missing': 0, 'translated_labels': 0, 'tooltip_rich': 0, 'language_total': 0, 'report_existing': 0, 'report_total': 0, 'playbook_ready': 0, 'playbook_total': 0, 'profiled_total': 0, 'profile_blocked': 0, 'registry_existing': 0, 'registry_total': 0, 'doctor_actions': 0, 'visible_sections': 0, 'hidden_sections': 0, 'visible_cards': 0, 'hidden_cards': 0, 'visible_actions': 0, 'recommended_actions': 0, 'recommended_reasons': [], 'recommended_payload': {'count': 0, 'buttons': [], 'reasons': []}, 'manual_controls': 0, 'manual_item_labels': [], 'controls_custom': False, 'controls_summary': '', 'focus_mode': 'all', 'focus_override': 'AUTO', 'focus_manual': False, 'total_card_sections': 0, 'total_visual_cards': 0, 'section_visibility': {'workflow': True, 'learning': True, 'maintenance': True}, 'density_override': 'AUTO', 'density_manual': False, 'density_mode': 'FULL'}


def _next_step(namespace: dict, context, issue_total: int, ws) -> str:
    mode = getattr(ws, 'tab', '') if ws else ''
    if issue_total > 0:
        return _text(namespace, context, 'ui.visual.repair_quick', 'Quick Repair', 'クイック修復')
    mapping = {'WORKFLOW': 'Auto Unwrap', 'TRANSFORM': 'Align / Stack', 'LAYOUT': 'Pack / UDIM', 'ANALYZE': 'Inspector Scan', 'MAPS': 'UV Maps / Checker', 'SYMMETRY': 'Select Mirrored 3D', 'ATLAS': 'Atlas / Bake'}
    return mapping.get(mode, 'Auto Unwrap')


def _status_chip(grid, label: str, value: str, icon: str):
    box = grid.box()
    col = box.column(align=True)
    col.label(text=label, icon=icon)
    col.label(text=value)


def _layout_mod(namespace: dict):
    return namespace.get('_quality_layout_module')


def _dashboard_columns(namespace: dict, context, compact=False):
    mod = _layout_mod(namespace)
    if mod is not None and hasattr(mod, 'dashboard_columns'):
        try:
            return max(1, int(mod.dashboard_columns(context, compact=compact)))
        except Exception:
            pass
    return 1 if compact else 2


def _status_columns(namespace: dict, context):
    mod = _layout_mod(namespace)
    if mod is not None and hasattr(mod, 'status_columns'):
        try:
            return max(1, int(mod.status_columns(context)))
        except Exception:
            pass
    return 2


def _button_columns(namespace: dict, context):
    mod = _layout_mod(namespace)
    if mod is not None and hasattr(mod, 'button_columns'):
        try:
            return max(1, int(mod.button_columns(context)))
        except Exception:
            pass
    return 2


def _recommended_actions(namespace: dict, context, status: dict | None = None):
    if isinstance(status, dict):
        cached = status.get('recommended_payload')
        if isinstance(cached, dict):
            return dict(cached)
    fn = namespace.get('scan_recommended_actions')
    if callable(fn):
        try:
            data = fn(namespace, context, status=status) or {}
            if isinstance(data, dict):
                return data
        except TypeError:
            try:
                data = fn(namespace, context) or {}
                if isinstance(data, dict):
                    return data
            except Exception:
                pass
        except Exception:
            pass
    return {'count': 0, 'buttons': [], 'reasons': []}


def draw_visual_guide(namespace: dict, layout, context):
    title = _text(namespace, context, 'ui.section.visual_guide', 'Quick Visual Guide', 'クイック視覚ガイド')
    hint = _text(namespace, context, 'ui.visual_guide.hint', 'Visual entry cards for the most common UV tasks. Use this area as a compact starting point, then open the full decks below when you need more control.', 'よく使うUV作業への視覚的な入口です。まずここから素早く始め、より細かい調整が必要なときは下の詳細デッキを開いてください。')
    translate = lambda ctx, key, en, ja: _text(namespace, ctx, key, en, ja)
    namespace['_quality_visual_translate'] = translate

    box = layout.box()
    col = box.column(align=True)
    head = col.row(align=True)
    head.label(text=title, icon='MENU_PANEL')

    status = _status_dict(namespace, context)
    target_name = str(status.get('target_name', 'None') or 'None')
    uv_sync = bool(status.get('uv_sync', False))
    issue_total = int(status.get('issue_total', 0) or 0)
    ws = status.get('workspace')
    guard_total = int(status.get('guard_total', 0) or 0)
    preflight_total = int(status.get('preflight_total', 0) or 0)
    restore_total = int(status.get('restore_total', 0) or 0)
    cleanup_total = int(status.get('cleanup_total', 0) or 0)
    readiness_score = int(status.get('readiness_score', 0) or 0)
    readiness_missing = int(status.get('readiness_missing', 0) or 0)
    tool_runtime_errors = int(status.get('tool_runtime_errors', 0) or 0)
    coverage_supported = int(status.get('coverage_supported', 0) or 0)
    coverage_total = int(status.get('coverage_total', 0) or 0)
    coverage_missing = int(status.get('coverage_missing', 0) or 0)
    translated_labels = int(status.get('translated_labels', 0) or 0)
    tooltip_rich = int(status.get('tooltip_rich', 0) or 0)
    language_total = int(status.get('language_total', 0) or 0)
    report_existing = int(status.get('report_existing', 0) or 0)
    report_total = int(status.get('report_total', 0) or 0)
    playbook_ready = int(status.get('playbook_ready', 0) or 0)
    playbook_total = int(status.get('playbook_total', 0) or 0)
    profiled_total = int(status.get('profiled_total', 0) or 0)
    profile_blocked = int(status.get('profile_blocked', 0) or 0)
    registry_existing = int(status.get('registry_existing', 0) or 0)
    registry_total = int(status.get('registry_total', 0) or 0)
    doctor_actions = int(status.get('doctor_actions', 0) or 0)
    visible_sections = int(status.get('visible_sections', 0) or 0)
    visible_cards = int(status.get('visible_cards', 0) or 0)
    hidden_sections = int(status.get('hidden_sections', 0) or 0)
    hidden_cards = int(status.get('hidden_cards', 0) or 0)
    visible_actions = int(status.get('visible_actions', 0) or 0)
    recommended_actions = int(status.get('recommended_actions', 0) or 0)
    manual_controls = int(status.get('manual_controls', 0) or 0)
    controls_custom = bool(status.get('controls_custom', False))
    controls_summary = str(status.get('controls_summary', '') or '')
    manual_item_labels = list(status.get('manual_item_labels', []) or [])
    focus_mode = str(status.get('focus_mode', 'all') or 'all')
    focus_override = str(status.get('focus_override', 'AUTO') or 'AUTO')
    focus_manual = bool(status.get('focus_manual', False))
    focus_effective = focus_override if focus_manual else focus_mode.upper()
    focus_override_label = str(status.get('focus_override_label', focus_override) or focus_override)
    focus_effective_label = str(status.get('focus_effective_label', focus_effective) or focus_effective)
    density = _density_data(namespace, context, status)
    density_override = str(density.get('override', 'AUTO') or 'AUTO')
    density_manual = bool(density.get('manual', False))
    density_effective = str(density.get('effective', 'FULL') or 'FULL')
    density_override_label = str(status.get('density_override_label', density_override) or density_override)
    density_effective_label = str(status.get('density_effective_label', density_effective) or density_effective)
    dashboard_preset = str(status.get('preset_display_label', status.get('dashboard_preset_label', status.get('dashboard_preset_effective', status.get('dashboard_preset', 'AUTO')))) or 'AUTO')
    preset_override = str(status.get('dashboard_preset', 'AUTO') or 'AUTO')
    preset_effective = str(status.get('dashboard_preset_effective', preset_override) or preset_override)
    preset_matched = bool(status.get('dashboard_preset_matched', True))
    controls_last_reason = str(status.get('controls_last_reason', '') or '')

    chip_data = [
        (_text(namespace, context, 'ui.visual.target', 'Current target', '現在の対象'), target_name, 'MESH_DATA'),
        (_text(namespace, context, 'ui.visual.sync', 'UV Sync', 'UV同期'), _bool_text(namespace, context, uv_sync), 'UV_SYNC_SELECT'),
        (_text(namespace, context, 'ui.visual.issues', 'Cached issues', 'キャッシュ済み問題'), str(issue_total), 'INFO'),
        (_text(namespace, context, 'ui.visual.guard_count', 'Guarded methods', '保護メソッド数'), str(guard_total), 'CHECKMARK'),
        (_text(namespace, context, 'ui.visual.preflight_count', 'Prepared steps', '事前準備数'), str(preflight_total), 'AUTO'),
        (_text(namespace, context, 'ui.visual.restore_count', 'Rollback guards', 'ロールバック保護数'), str(restore_total), 'LOOP_BACK'),
        (_text(namespace, context, 'ui.visual.readiness_score', 'Readiness', '準備スコア'), f'{readiness_score}/5', 'TOOL_SETTINGS'),
        (_text(namespace, context, 'ui.visual.cleanup_candidates', 'Cleanup candidates', 'クリーンアップ候補'), str(cleanup_total), 'TRASH'),
        (_text(namespace, context, 'ui.visual.tool_runtime_errors', 'Runtime errors', '実行時エラー数'), str(tool_runtime_errors), 'ERROR'),
        (_text(namespace, context, 'ui.visual.covered_groups', 'Covered groups', '対応済みグループ'), f'{coverage_supported}/{coverage_total}' if coverage_total else '-', 'PRESET'),
        (_text(namespace, context, 'ui.visual.missing_groups', 'Missing groups', '不足グループ'), str(coverage_missing), 'INFO'),
        (_text(namespace, context, 'ui.visual.translated_labels', 'Translated labels', '翻訳済みラベル'), f'{translated_labels}/{language_total}' if language_total else '-', 'WORLD'),
        (_text(namespace, context, 'ui.visual.rich_tooltips', 'Rich tooltips', '詳しいツールチップ'), f'{tooltip_rich}/{language_total}' if language_total else '-', 'HELP'),
        (_text(namespace, context, 'ui.visual.report_hub_count', 'Reports', 'レポート数'), f'{report_existing}/{report_total}' if report_total else '-', 'TEXT'),
        (_text(namespace, context, 'ui.visual.registry_count', 'Registry texts', 'レジストリ数'), f'{registry_existing}/{registry_total}' if registry_total else '-', 'FILE_TEXT'),
        (_text(namespace, context, 'ui.visual.ready_workflows', 'Ready workflows', '準備完了ワークフロー'), f'{playbook_ready}/{playbook_total}' if playbook_total else '-', 'SEQ_SEQUENCER'),
        (_text(namespace, context, 'ui.visual.profiled_ops', 'Profiled ops', 'プロファイル対象数'), str(profiled_total), 'LOCKVIEW_ON'),
        (_text(namespace, context, 'ui.visual.profile_blocked', 'Blocked now', '現在停止候補'), str(profile_blocked), 'UNLINKED'),
        (_text(namespace, context, 'ui.visual.doctor_actions', 'Action items', 'アクション項目'), str(doctor_actions), 'LIGHT'),
        (_text(namespace, context, 'ui.visual.manual_controls', 'Manual controls', '手動コントロール数'), str(manual_controls), 'OPTIONS'),
        (_text(namespace, context, 'ui.visual.card_sections', 'Card sections', 'カードセクション数'), str(visible_sections), 'BOOKMARKS'),
        (_text(namespace, context, 'ui.visual.hidden_sections', 'Hidden sections', '非表示セクション数'), str(hidden_sections), 'HIDE_OFF'),
        (_text(namespace, context, 'ui.visual.visible_cards', 'Visible cards', '表示カード数'), str(visible_cards), 'MENU_PANEL'),
        (_text(namespace, context, 'ui.visual.hidden_cards', 'Hidden cards', '非表示カード数'), str(hidden_cards), 'HIDE_OFF'),
        (_text(namespace, context, 'ui.visual.visible_actions', 'Visible actions', '表示アクション数'), str(visible_actions), 'PLAY'),
        (_text(namespace, context, 'ui.visual.recommended_actions', 'Recommended actions', 'おすすめアクション'), str(recommended_actions), 'LIGHT_SUN'),
        (_text(namespace, context, 'ui.visual.focus_mode', 'Focus mode', 'フォーカス表示'), focus_effective_label, 'VIEWZOOM'),
        (_text(namespace, context, 'ui.visual.focus_override', 'Focus override', '手動フォーカス'), focus_override_label if focus_manual else _text(namespace, context, 'ui.visual.focus_auto', 'AUTO', '自動'), 'PINNED'),
        (_text(namespace, context, 'ui.visual.dashboard_density', 'Dashboard density', 'ダッシュボード密度'), density_effective_label if density_manual else _text(namespace, context, 'ui.visual.density_auto', 'AUTO', '自動'), 'ALIGN_JUSTIFY'),
        (_text(namespace, context, 'ui.visual.dashboard_preset', 'Dashboard preset', 'ダッシュボードプリセット'), dashboard_preset, 'PRESET'),
    ]
    density_key = density_effective.upper()
    if density_key == 'ESSENTIAL':
        essential_labels = {
            _text(namespace, context, 'ui.visual.target', 'Current target', '現在の対象'),
            _text(namespace, context, 'ui.visual.sync', 'UV Sync', 'UV同期'),
            _text(namespace, context, 'ui.visual.readiness_score', 'Readiness', '準備スコア'),
            _text(namespace, context, 'ui.visual.tool_runtime_errors', 'Runtime errors', '実行時エラー数'),
            _text(namespace, context, 'ui.visual.doctor_actions', 'Action items', 'アクション項目'),
            _text(namespace, context, 'ui.visual.manual_controls', 'Manual controls', '手動コントロール数'),
            _text(namespace, context, 'ui.visual.recommended_actions', 'Recommended actions', 'おすすめアクション'),
            _text(namespace, context, 'ui.visual.focus_mode', 'Focus mode', 'フォーカス表示'),
            _text(namespace, context, 'ui.visual.dashboard_density', 'Dashboard density', 'ダッシュボード密度'),
            _text(namespace, context, 'ui.visual.dashboard_preset', 'Dashboard preset', 'ダッシュボードプリセット'),
        }
        chip_data = [entry for entry in chip_data if entry[0] in essential_labels]
    stats = col.grid_flow(row_major=True, columns=_status_columns(namespace, context), even_columns=True, even_rows=False, align=True)
    for label, value, icon in chip_data:
        _status_chip(stats, label, value, icon)

    col.separator(factor=0.15)
    extra = col.row(align=True)
    mode_label = getattr(ws, 'tab', '-') if ws else '-'
    extra.label(text=f"{_text(namespace, context, 'ui.visual.workspace_mode', 'Workspace mode', 'ワークスペースモード')}: {mode_label}", icon='WINDOW')
    extra.label(text=f"{_text(namespace, context, 'ui.visual.next_step', 'Recommended next step', '次のおすすめ')}: {_next_step(namespace, context, issue_total, ws)}", icon='LIGHT')
    if readiness_missing > 0:
        extra = col.row(align=True)
        extra.label(text=f"{_text(namespace, context, 'ui.visual.readiness_missing', 'Missing readiness checks', '不足している準備項目')}: {readiness_missing}", icon='ERROR')
    meta = col.row(align=True)
    meta.label(text=f"{_text(namespace, context, 'ui.visual.layout_columns', 'Layout columns', 'レイアウト列数')}: {_dashboard_columns(namespace, context)}", icon='COLLAPSEMENU')
    meta.label(text=f"{_text(namespace, context, 'ui.visual.button_columns', 'Button columns', 'ボタン列数')}: {_button_columns(namespace, context)}", icon='GRID')
    meta.label(text=f"{_text(namespace, context, 'ui.visual.compact_layout', 'Compact layout', 'コンパクト配置')}: {_bool_text(namespace, context, _dashboard_columns(namespace, context, compact=True) < _dashboard_columns(namespace, context))}", icon='ALIGN_JUSTIFY')
    if controls_summary:
        summary = col.row(align=True)
        summary.scale_y = 0.92
        summary.label(text=f"{_text(namespace, context, 'ui.visual.controls_summary_label', 'Visual controls', '視覚コントロール')}: {controls_summary}", icon='OPTIONS')
    if controls_last_reason:
        sync_row = col.row(align=True)
        sync_row.scale_y = 0.88
        sync_row.label(text=f"{_text(namespace, context, 'ui.visual.controls_last_reason', 'Last visual change', '直近の視覚変更')}: {controls_last_reason}", icon='SORTTIME')
    if controls_custom:
        custom_row = col.row(align=True)
        custom_row.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
    info = col.row()
    info.scale_y = 0.9
    pass  # INFO-note moved to Help; no in-section info-icon explanation.

    focus_cls = namespace.get('SUV_OT_quality_set_focus_mode')
    density_cls = namespace.get('SUV_OT_quality_set_density_mode')
    preset_cls = namespace.get('SUV_OT_quality_apply_dashboard_preset')
    if preset_cls is not None:
        col.separator(factor=0.12)
        preset_box = col.box()
        preset_col = preset_box.column(align=True)
        preset_col.label(text=_text(namespace, context, 'ui.visual.preset_controls', 'Preset controls', 'プリセット切替'), icon='PRESET')
        preset_info = preset_col.row()
        preset_info.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        preset_grid = preset_col.grid_flow(row_major=True, columns=_button_columns(namespace, context), even_columns=True, even_rows=False, align=True)
        preset_modes = [
            ('AUTO', _text(namespace, context, 'ui.visual.preset.auto', 'Auto', '自動')),
            ('START', _text(namespace, context, 'ui.visual.preset.start', 'Starter', '入門')),
            ('REPAIR', _text(namespace, context, 'ui.visual.preset.repair', 'Repair', '修復')),
            ('ANALYZE', _text(namespace, context, 'ui.visual.preset.analyze', 'Analyze', '分析')),
            ('FULL', _text(namespace, context, 'ui.visual.preset.full', 'Full', '全体')),
        ]
        current_preset = preset_override
        effective_preset = preset_effective
        for preset_id, label in preset_modes:
            op = preset_grid.operator(preset_cls.bl_idname, text=label, icon='NONE', depress=(effective_preset == preset_id and preset_matched))
            _suv_safe_set_ui_operator_prop(op, 'preset', preset_id)
        if not preset_matched:
            note = preset_col.row()
            note.scale_y = 0.9
            pass  # INFO-note moved to Help; no in-section info-icon explanation.
        reset_visual_cls = namespace.get('SUV_OT_quality_reset_visual_controls')
        if reset_visual_cls is not None:
            row = preset_col.row(align=True)
            row.scale_y = 0.95
            row.operator(reset_visual_cls.bl_idname, text=_text(namespace, context, 'ui.visual.reset_visual_controls', 'Reset visual controls', '視覚コントロール初期化'), icon='FILE_REFRESH')
    if density_cls is not None:
        col.separator(factor=0.12)
        density_box = col.box()
        density_col = density_box.column(align=True)
        density_col.label(text=_text(namespace, context, 'ui.visual.density_controls', 'Density controls', '表示密度切替'), icon='ALIGN_JUSTIFY')
        density_info = density_col.row()
        density_info.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        density_modes = [
            ('AUTO', _text(namespace, context, 'ui.visual.density_auto', 'AUTO', '自動')),
            ('ESSENTIAL', _text(namespace, context, 'ui.visual.density_essential', 'Essential', '要点')),
            ('FULL', _text(namespace, context, 'ui.visual.density_full', 'Full', '全表示')),
        ]
        density_grid = density_col.grid_flow(row_major=True, columns=_button_columns(namespace, context), even_columns=True, even_rows=False, align=True)
        for mode_id, label in density_modes:
            op = density_grid.operator(density_cls.bl_idname, text=label, icon='NONE', depress=(density_override == mode_id))
            _suv_safe_set_ui_operator_prop(op, 'mode', mode_id)

    if focus_cls is not None:
        col.separator(factor=0.12)
        focus_box = col.box()
        focus_col = focus_box.column(align=True)
        focus_col.label(text=_text(namespace, context, 'ui.visual.focus_controls', 'Focus controls', 'フォーカス切替'), icon='VIEWZOOM')
        focus_info = focus_col.row()
        focus_info.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        modes = [
            ('AUTO', _text(namespace, context, 'ui.visual.focus_auto', 'AUTO', '自動')),
            ('SETUP', _text(namespace, context, 'ui.visual.focus_setup', 'Setup', '準備')),
            ('REPAIR', _text(namespace, context, 'ui.visual.focus_repair', 'Repair', '修復')),
            ('COVERAGE', _text(namespace, context, 'ui.visual.focus_coverage', 'Calc Coverage', '対応範囲')),
            ('ANALYZE', _text(namespace, context, 'ui.visual.focus_analyze', 'Analyze', '分析')),
            ('ALL', _text(namespace, context, 'ui.visual.focus_all', 'All', '全表示')),
        ]
        focus_grid = focus_col.grid_flow(row_major=True, columns=_button_columns(namespace, context), even_columns=True, even_rows=False, align=True)
        for mode_id, label in modes:
            op = focus_grid.operator(focus_cls.bl_idname, text=label, icon='NONE', depress=(focus_override == mode_id))
            _suv_safe_set_ui_operator_prop(op, 'mode', mode_id)

    section_cls = namespace.get('SUV_OT_quality_set_section_visibility')
    section_reset_cls = namespace.get('SUV_OT_quality_reset_section_visibility')
    if section_cls is not None:
        section_vis = dict(status.get('section_visibility', {}) or {})
        col.separator(factor=0.12)
        sec_box = col.box()
        sec_col = sec_box.column(align=True)
        sec_col.label(text=_text(namespace, context, 'ui.visual.section_controls', 'Section controls', 'セクション切替'), icon='COLLAPSEMENU')
        sec_info = sec_col.row()
        sec_info.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        sec_grid = sec_col.grid_flow(row_major=True, columns=_button_columns(namespace, context), even_columns=True, even_rows=False, align=True)
        section_modes = [
            ('workflow', _text(namespace, context, 'ui.visual.section_toggle.workflow', 'Workflow', 'ワークフロー')),
            ('learning', _text(namespace, context, 'ui.visual.section_toggle.learning', 'Guides', 'ガイド')),
            ('maintenance', _text(namespace, context, 'ui.visual.section_toggle.maintenance', 'Reports', 'レポート')),
        ]
        for sid, label in section_modes:
            shown = bool(section_vis.get(sid, True))
            op = sec_grid.operator(section_cls.bl_idname, text=label, icon='CHECKBOX_HLT' if shown else 'CHECKBOX_DEHLT', depress=shown)
            _suv_safe_set_ui_operator_prop(op, 'section_id', sid)
            _suv_safe_set_ui_operator_prop(op, 'visible', not shown)
        if section_reset_cls is not None:
            row = sec_col.row(align=True)
            row.scale_y = 0.95
            row.operator(section_reset_cls.bl_idname, text=_text(namespace, context, 'ui.visual.section_reset', 'Reset sections', 'セクション再表示'), icon='FILE_REFRESH')

    rec_data = _recommended_actions(namespace, context, status=status)
    buttons = list(rec_data.get('buttons', []) or [])
    reasons = list(rec_data.get('reasons', []) or [])
    if buttons:
        col.separator(factor=0.15)
        rec_box = col.box()
        rec_col = rec_box.column(align=True)
        rec_col.label(text=_text(namespace, context, 'ui.visual.recommended_actions', 'Recommended actions', 'おすすめアクション'), icon='LIGHT_SUN')
        rec_info = rec_col.row()
        rec_info.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        if reasons:
            why = rec_col.row(align=True)
            why.scale_y = 0.9
            why.label(text=_text(namespace, context, 'ui.visual.recommended_why', 'Why these now', '今これを勧める理由'), icon='QUESTION')
            for reason in reasons[:3]:
                why.label(text=str(reason))
        rec_grid = rec_col.grid_flow(row_major=True, columns=_button_columns(namespace, context), even_columns=True, even_rows=False, align=True)
        for button in buttons:
            btn_box = rec_grid.box()
            btn_col = btn_box.column(align=True)
            reason = str(button.get('reason', '') or '').strip()
            if reason:
                hint = btn_col.row()
                hint.scale_y = 0.85
                pass  # INFO-note moved to Help; no in-section info-icon explanation.
            _safe_op(btn_col, button.get('cls'), text=button.get('text'), icon=button.get('icon', 'NONE'), props=button.get('props'))

    col.separator(factor=0.2)
    grid = col.grid_flow(row_major=True, columns=_dashboard_columns(namespace, context), even_columns=True, even_rows=False, align=True)
    cards_mod = namespace.get('_quality_cards_module')
    sections = []
    if cards_mod is not None and hasattr(cards_mod, 'build_card_sections'):
        try:
            sections = cards_mod.build_card_sections(namespace, context, translate)
        except Exception:
            sections = []

    for section in sections:
        section_box = grid.box()
        section_col = section_box.column(align=True)
        section_col.label(text=section.get('title', ''), icon=section.get('icon', 'BOOKMARKS'))
        section_grid = section_col.grid_flow(row_major=True, columns=_dashboard_columns(namespace, context, compact=True), even_columns=True, even_rows=False, align=True)
        for card in section.get('cards', []):
            cbox = section_grid.box()
            ccol = cbox.column(align=True)
            ccol.label(text=card.get('title', ''), icon='BOOKMARKS')
            inner = ccol.grid_flow(row_major=True, columns=_button_columns(namespace, context), even_columns=True, even_rows=False, align=True)
            for button in card.get('buttons', []):
                _safe_op(inner, button.get('cls'), text=button.get('text'), icon=button.get('icon', 'NONE'), props=button.get('props'))

    try:
        opener = namespace.get('SUV_OT_apply_display_preset')
        if opener is not None:
            row = col.row(align=True)
            row.scale_y = 1.05
            op = row.operator(opener.bl_idname, text=_text(namespace, context, 'ui.visual.open_full', 'Open Full Tools Below', '下の全ツールを開く'), icon='WINDOW')
            _suv_safe_set_ui_operator_prop(op, 'preset', 'FULL')
    except Exception:
        pass


def install_visual_wrapper(namespace: dict) -> bool:
    original = namespace.get('_draw_suite')
    if not callable(original) or getattr(original, '_suv_quality_visual_wrapped', False):
        return False

    def wrapped(layout, context):
        try:
            draw_visual_guide(namespace, layout, context)
            layout.separator(factor=0.2)
        except Exception:
            pass
        return original(layout, context)

    wrapped._suv_quality_visual_wrapped = True
    namespace['_draw_suite'] = wrapped
    return True
