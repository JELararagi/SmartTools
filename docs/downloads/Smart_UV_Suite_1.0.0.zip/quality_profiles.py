from __future__ import annotations
from . import resource_api_18168 as _suv_resource
from .quality_class_inventory import iter_suite_classes

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None

_NAMESPACE = {}
_REGISTERED = []


def _tr(context, key: str, en: str, ja: str, **fmt) -> str:
    fn = _NAMESPACE.get('tr')
    text = None
    if callable(fn):
        try:
            text = fn(context, key, **fmt)
        except Exception:
            text = None
    if not text:
        text = en
    try:
        return text.format(**fmt)
    except Exception:
        return text


def _text_name(context) -> str:
    ws_fn = _NAMESPACE.get('_suv_ws')
    ws = ws_fn(context) if callable(ws_fn) else None
    name = getattr(ws, 'support_bundle_name', '') if ws else ''
    return (str(name).strip() or 'SUV_Support_Bundle') + '_Execution_Profiles'


def _suv_profile_report_name(context):
    return _text_name(context)


def _text_block(name: str, clear=False):
    textio = _NAMESPACE.get('_quality_textio_module')
    if textio is not None and hasattr(textio, 'ensure_report_text'):
        try:
            return textio.ensure_report_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if textio is not None and hasattr(textio, 'ensure_namespace_text'):
        try:
            return textio.ensure_namespace_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if bpy is None:
        return None
    txt = bpy.data.texts.get(name)
    if txt is None:
        if not clear:
            return None
        txt = bpy.data.texts.new(name)
    elif clear:
        txt.clear()
    return txt


def _iter_operator_classes(namespace: dict):
    for name, value in iter_suite_classes(namespace):
        if not name.startswith('SUV_OT_'):
            continue
        try:
            if isinstance(value, type):
                yield name, value
        except Exception:
            continue


def _classify_operator(name: str, cls) -> dict:
    label = str(getattr(cls, 'bl_label', '') or name)
    idname = str(getattr(cls, 'bl_idname', '') or '')
    desc = str(getattr(cls, 'bl_description', '') or '')
    hay = ' '.join([name, label, idname, desc]).lower()
    req = set()
    category = 'general'
    if any(k in hay for k in ('report', 'audit', 'catalog', 'help', 'language', 'matrix', 'playbook', 'cleanup', 'diagnostic', 'snapshot', 'support bundle', 'hub')):
        category = 'reports'
    elif any(k in hay for k in ('pack', 'layout', 'udim', 'tile')):
        category = 'pack_layout'
        req.update({'mesh', 'edit', 'uv_map', 'uv_editor'})
    elif any(k in hay for k in ('align', 'rectify', 'straighten', 'stack', 'texel', 'overlap', 'similar', 'island', 'checker', 'relax', 'unwrap', 'stitch', 'peel')):
        category = 'uv_edit'
        req.update({'mesh', 'edit', 'uv_map', 'uv_editor'})
    elif any(k in hay for k in ('mirror', 'sym', 'atlas', 'bake', 'seam', 'projection', 'project', 'camera', 'planar', 'sphere')):
        category = 'mesh_side'
        req.update({'mesh', 'edit', 'view3d'})
    elif any(k in hay for k in ('select', 'inspect', 'scan', 'validate')):
        category = 'inspection'
        req.update({'mesh'})
    elif any(k in hay for k in ('uvmap', 'map', 'channel')) and 'report' not in hay:
        category = 'uv_maps'
        req.update({'mesh'})
    if category in {'pack_layout', 'uv_edit', 'mesh_side', 'inspection'} or any(k in hay for k in ('select', 'stack', 'align', 'rectify', 'pack', 'mirror', 'sym', 'seam', 'unwrap', 'relax')):
        req.add('selection')
    return {
        'name': name,
        'label': label,
        'idname': idname,
        'category': category,
        'requirements': tuple(sorted(req)),
    }


def _scan_readiness(context):
    fn = _NAMESPACE.get('scan_context_readiness')
    if callable(fn):
        try:
            return fn(_NAMESPACE, context) or {}
        except Exception:
            return {}
    return {}


def _has_selection(context) -> bool:
    try:
        obj = getattr(context, 'active_object', None)
        if obj is None or getattr(obj, 'type', '') != 'MESH':
            return False
        data = getattr(obj, 'data', None)
        if data is None:
            return False
        for attr in ('total_face_sel', 'total_edge_sel', 'total_vert_sel'):
            value = getattr(data, attr, None)
            if value is not None:
                try:
                    if int(value) > 0:
                        return True
                except Exception:
                    pass
        selected = getattr(context, 'selected_objects', None) or []
        return len(selected) > 0
    except Exception:
        return False


def _evaluate_requirements(context, profile: dict) -> list[str]:
    readiness = _scan_readiness(context)
    missing = []
    req = set(profile.get('requirements') or ())
    if 'mesh' in req and not bool(readiness.get('active_mesh')):
        missing.append('active mesh')
    if 'edit' in req and not bool(readiness.get('edit_mode')):
        missing.append('edit mode')
    if 'uv_map' in req and not bool(readiness.get('active_uv_map')):
        missing.append('active UV map')
    if 'uv_editor' in req and not bool(readiness.get('uv_editor')):
        missing.append('UV Editor')
    if 'view3d' in req and not bool(readiness.get('view3d')):
        missing.append('3D View')
    if 'selection' in req and not _has_selection(context):
        missing.append('selection')
    return missing


def _profile_hint(category: str, missing: list[str]) -> str:
    base = ', '.join(missing) if missing else 'context'
    if category == 'uv_edit':
        return f'Prepare UV Editor, Edit Mode, and a usable UV selection before running this UV-edit tool. Missing: {base}.'
    if category == 'pack_layout':
        return f'Prepare UV Editor, Edit Mode, UV map, and the shells you want to pack or lay out. Missing: {base}.'
    if category == 'mesh_side':
        return f'Prepare a mesh in Edit Mode and a visible 3D View before mesh-side UV tools run. Missing: {base}.'
    if category == 'inspection':
        return f'Prepare the target mesh and selection before running this inspection step. Missing: {base}.'
    return f'Review the working context before running this tool. Missing: {base}.'


def scan_operator_profiles(namespace: dict, context=None) -> dict:
    rows = []
    category_counts = {}
    missing_now = 0
    for name, cls in _iter_operator_classes(namespace):
        row = _classify_operator(name, cls)
        if context is not None:
            row['missing_now'] = _evaluate_requirements(context, row)
            if row['missing_now']:
                missing_now += 1
        rows.append(row)
        category_counts[row['category']] = int(category_counts.get(row['category'], 0) or 0) + 1
    data = {
        'total': len(rows),
        'profiled': len([r for r in rows if r.get('requirements')]),
        'blocked_now': int(missing_now),
        'categories': category_counts,
        'rows': rows,
    }
    namespace['_suv_quality_profile_scan'] = data
    return data


def wrap_operator_profile_guard(namespace: dict, cls, method_name: str) -> bool:
    original = getattr(cls, method_name, None)
    if original is None or getattr(original, '_suv_profile_guard_wrapped', False):
        return False
    profile = _classify_operator(cls.__name__, cls)
    if not profile.get('requirements'):
        return False

    def wrapped(self, context, *args, **kwargs):
        missing = _evaluate_requirements(context, profile)
        if missing:
            namespace['_suv_quality_profile_blocked_total'] = int(namespace.get('_suv_quality_profile_blocked_total', 0) or 0) + 1
            namespace['_suv_quality_profile_last_block'] = {
                'operator': getattr(cls, 'bl_idname', cls.__name__),
                'label': getattr(cls, 'bl_label', cls.__name__),
                'category': profile.get('category'),
                'missing': list(missing),
            }
            hint = _profile_hint(profile.get('category', 'general'), missing)
            report = getattr(self, 'report', None)
            if callable(report):
                try:
                    report({'WARNING'}, _tr(context, 'msg.quality_profile_blocked', 'Blocked by execution profile: {label}. Missing: {missing}', '実行プロファイルにより停止しました: {label}。不足: {missing}', label=getattr(cls, 'bl_label', cls.__name__), missing=', '.join(missing)))
                    report({'INFO'}, hint)
                except Exception:
                    pass
            log_fn = namespace.get('_suv_log_exception')
            if callable(log_fn):
                try:
                    log_fn(context, getattr(cls, 'bl_label', cls.__name__), RuntimeError('Execution profile blocked'), {'method': method_name, 'class': cls.__name__, 'category': profile.get('category'), 'missing': list(missing), 'recovery_hint': hint})
                except Exception:
                    pass
            return {'CANCELLED'}
        return original(self, context, *args, **kwargs)

    wrapped._suv_profile_guard_wrapped = True
    setattr(cls, method_name, wrapped)
    return True


def patch_profiles(namespace: dict) -> dict:
    counts = {'operator_methods': 0}
    for _name, cls in _iter_operator_classes(namespace):
        for method_name in ('execute', 'invoke'):
            try:
                if wrap_operator_profile_guard(namespace, cls, method_name):
                    counts['operator_methods'] += 1
            except Exception:
                pass
    namespace['_suv_quality_profile_counts'] = counts
    return counts


class SUV_OT_quality_write_execution_profiles(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_write_execution_profiles'
    bl_label = 'Write Execution Profiles'
    bl_description = 'Write a category-based execution profile report that shows which operator groups require UV Editor, Edit Mode, selection, or 3D View context before they run. / UVエディター、編集モード、選択状態、3Dビューなどの前提が必要なオペレーター群をカテゴリ別にまとめた実行プロファイルレポートを書き出します。'
    bl_options = set()

    open_after_write: bpy.props.BoolProperty(
        name='Open After Write',
        description='Open the written execution-profile report in Blender Text Editor when possible / 可能なら書き出した実行プロファイルレポートを Blender テキストエディタで開きます',
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        data = scan_operator_profiles(_NAMESPACE, context)
        txt = None
        lines = [
            'UV Suite Execution Profiles',
            '',
            '[Summary]',
            f"Total operators: {data['total']}",
            f"Profiled operators: {data['profiled']}",
            f"Blocked in current context: {data['blocked_now']}",
            '',
            '[Category counts]',
        ]
        for key in sorted(data.get('categories', {}).keys()):
            lines.append(f"- {key}: {data['categories'][key]}")
        lines.extend(['', '[Profiled operators]'])
        for row in data['rows'][:160]:
            req = ', '.join(row.get('requirements') or ()) or '-'
            missing = ', '.join(row.get('missing_now') or ()) or '-'
            lines.append(f"- {row['label']} [{row['category']}] :: req={req} :: missing-now={missing}")
        lines.extend([
            '',
            '[日本語メモ]',
            f"プロファイル対象オペレーター: {data['profiled']}/{data['total']}",
            f"現在のコンテキストで不足があるオペレーター: {data['blocked_now']}",
            'まず Context Scan / Prepare Basics を行い、その後で UV 編集系・パック系・対称系を使うと失敗を減らしやすくなります。',
        ])
        textio = _NAMESPACE.get('_quality_textio_module')
        writer = getattr(textio, 'write_report_lines_consistent', None) if textio is not None else None
        if callable(writer):
            txt = writer(
                _NAMESPACE, context, _text_name, lines, _text_block, self,
                open_after_write=self.open_after_write,
                failed_key='msg.quality_profiles_open_failed',
                failed_en='Could not open execution profiles: {name}',
                failed_ja='実行プロファイルを開けませんでした: {name}',
            )
            if txt is None:
                return {'CANCELLED'}
        else:
            txt = _text_block(_text_name(context), clear=True)
            if txt is None:
                return {'CANCELLED'}
            if textio is not None and hasattr(textio, 'write_text_lines'):
                if textio.write_text_lines(txt, lines) is None:
                    return {'CANCELLED'}
            else:
                txt.write('\n'.join(lines))
            if self.open_after_write and textio is not None and hasattr(textio, 'open_written_text'):
                textio.open_written_text(
                    _NAMESPACE, context, txt, self,
                    failed_key='msg.quality_profiles_open_failed',
                    failed_en='Could not open execution profiles: {name}',
                    failed_ja='実行プロファイルを開けませんでした: {name}',
                )
        self.report({'INFO'}, _tr(context, 'msg.quality_profiles_written', 'Execution profiles written: {name} ({profiled}/{total} profiled)', '実行プロファイルを書き出しました: {name}（対象 {profiled}/{total}）', name=txt.name, profiled=data['profiled'], total=data['total']))
        return {'FINISHED'}


class SUV_OT_quality_open_execution_profiles(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_open_execution_profiles'
    bl_label = 'Open Execution Profiles'
    bl_description = 'Open the latest UV Suite execution profile report in Blender Text Editor. / 最新の UV Suite 実行プロファイルレポートを Blender のテキストエディタで開きます。'
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        textio = _NAMESPACE.get('_quality_textio_module')
        if textio is not None and hasattr(textio, 'open_named_report_text_or_fallback'):
            return textio.open_named_report_text_or_fallback(
                _NAMESPACE, context, _text_name, self, _text_block,
                missing_key='msg.quality_profiles_missing',
                missing_en='No execution profiles report exists yet.',
                missing_ja='実行プロファイルレポートはまだ作成されていません。',
                opened_key='msg.quality_profiles_opened',
                opened_en='Opened execution profiles: {name}',
                opened_ja='実行プロファイルを開きました: {name}',
            )
        txt = _text_block(_text_name(context), clear=False)
        if txt is None:
            self.report({'WARNING'}, _tr(context, 'msg.quality_profiles_missing', 'No execution profiles report exists yet.', '実行プロファイルレポートはまだ作成されていません。'))
            return {'CANCELLED'}
        opener = _NAMESPACE.get('_suv_open_text_in_editor')
        ok = False
        if callable(opener):
            try:
                ok, _err = opener(context, txt)
            except Exception:
                ok = False
        if not ok:
            self.report({'WARNING'}, _tr(context, 'msg.quality_profiles_open_failed', 'Could not open execution profiles: {name}', '実行プロファイルを開けませんでした: {name}', name=txt.name))
            return {'CANCELLED'}
        self.report({'INFO'}, _tr(context, 'msg.quality_profiles_opened', 'Opened execution profiles: {name}', '実行プロファイルを開きました: {name}', name=txt.name))
        return {'FINISHED'}


def register(namespace: dict):
    global _NAMESPACE
    _NAMESPACE = namespace if isinstance(namespace, dict) else {}
    if bpy is None:
        return []
    classes = [SUV_OT_quality_write_execution_profiles, SUV_OT_quality_open_execution_profiles]
    reg = []
    for cls in classes:
        try:
            _suv_resource.register_class(cls)
            reg.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = reg
    return reg


def unregister(namespace: dict | None = None):
    if bpy is None:
        return []
    removed = []
    for cls in reversed(list(_REGISTERED)):
        try:
            _suv_resource.unregister_class(cls)
            removed.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = []
    return removed
