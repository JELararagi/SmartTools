"""Implement the island distribute public UV operations."""

import bpy


def island_distribute(context, op):
    return 'FINISHED' in bpy.ops.uv.suv_distribute_islands(axis={'U': 'H', 'V': 'V'}.get(op.axis, op.axis or ('V' if op.is_vertical else 'H')), scope=op.scope or 'SELECTED', texture_size=op.texture_size)


def build_handlers(api):
    handler = api.Handler(
        island_distribute,
        'Distribute UV islands evenly along the selected axis.',
        '指定した軸に沿ってUVアイランドを等間隔に配置します。')
    return {
        "smart_uv_suite.island_distribute": handler,
        "smart_uv_suite.pack_distribute": handler,
    }
