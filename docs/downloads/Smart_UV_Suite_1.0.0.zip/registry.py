# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

SUITE_META = {
    'uv_suite': ('Smart UV', 'navigation_properties'),
}

SUITE_ORDER: tuple[str, ...] = tuple(SUITE_META.keys())

_REPORT_LINE_RE = re.compile(
    r'^- \*\*(?P<display>.+?)\*\* \(`(?P<outer>.+?)`\) → `(?P<suite>.+?)` / (?P<status>load|skip)\s*$'
)

_CACHE: list[dict[str, Any]] | None = None

TOOL_FOLDERS: tuple[str, ...] = ()
def package_root() -> Path:
    return Path(__file__).resolve().parent



def integrated_root() -> Path:
    return package_root()



def report_path() -> Path:
    return package_root() / 'INTEGRATED_ADDONS_REPORT.md'



def clear_cache() -> None:
    global _CACHE
    _CACHE = None



def sanitize_alias(filename: str) -> str:
    text = str(filename or '').strip()
    if text.lower().endswith('.zip'):
        text = text[:-4]
    text = text.replace(' ', '_')
    text = re.sub(r'[^0-9A-Za-z_]+', '_', text)
    text = re.sub(r'_+', '_', text).strip('_').lower()
    if not text:
        text = 'integrated_addon'
    if not re.match(r'[A-Za-z_]', text):
        text = '_' + text
    return text



def _suite_name_to_key(label: str) -> str:
    normalized = str(label or '').strip().lower()
    if normalized in {'smart uv suite', 'uv_suite', 'smart_uv'}:
        return 'uv_suite'
    fallback = normalized.replace(' ', '_').replace('-', '_')
    return fallback or 'uv_suite'



def _parse_report() -> dict[str, dict[str, Any]]:
    path = report_path()
    if not path.exists():
        return {}

    specs: dict[str, dict[str, Any]] = {}
    current: dict[str, Any] | None = None
    for raw_line in path.read_text(encoding='utf-8', errors='ignore').splitlines():
        line = raw_line.rstrip('\n')
        match = _REPORT_LINE_RE.match(line.strip())
        if match:
            alias = sanitize_alias(match.group('outer'))
            current = {
                'alias': alias,
                'outer_zip': match.group('outer').strip(),
                'display_name': match.group('display').strip(),
                'suite': _suite_name_to_key(match.group('suite').strip()),
                'suite_name': match.group('suite').strip(),
                'load': match.group('status').strip() == 'load',
                'note': '',
                'duplicate_of': '',
                'superseded_by': '',
                'spaces': [],
            }
            specs[alias] = current
            continue
        if current is None:
            continue
        stripped = line.strip()
        if stripped.startswith('- note:'):
            current['note'] = stripped.split(':', 1)[1].strip()
        elif stripped.startswith('- duplicate_of:'):
            current['duplicate_of'] = stripped.split(':', 1)[1].strip()
        elif stripped.startswith('- superseded_by:'):
            current['superseded_by'] = stripped.split(':', 1)[1].strip()
        elif stripped.startswith('- ui_strategy:'):
            _, _, rest = stripped.partition('spaces:')
            text = rest.strip()
            current['spaces'] = [] if not text or text == '-' else [item.strip() for item in text.split(',') if item.strip()]
    return specs



def _read_bl_info_name_and_description(py_path: Path) -> tuple[str, str]:
    try:
        text = py_path.read_text(encoding='utf-8', errors='ignore')
    except Exception:
        return '', ''
    name_match = re.search(r"[\"']name[\"']\s*:\s*[\"']([^\"']+)[\"']", text)
    desc_match = re.search(r"[\"']description[\"']\s*:\s*[\"']([^\"']+)[\"']", text)
    return (name_match.group(1).strip() if name_match else '', desc_match.group(1).strip() if desc_match else '')



def _find_init_file(src_dir: Path) -> tuple[str, str, str, str]:
    init_files = list(src_dir.rglob('__init__.py'))
    if not init_files:
        return '', '', '', ''

    scored: list[tuple[tuple[int, int, int, str], Path]] = []
    for path in init_files:
        rel = path.relative_to(src_dir).as_posix()
        depth = len(path.relative_to(src_dir).parts)
        try:
            text = path.read_text(encoding='utf-8', errors='ignore')
        except Exception:
            text = ''
        has_bl_info = 'bl_info' in text
        has_register = 'def register' in text
        score = (
            0 if has_bl_info else 1,
            0 if has_register else 1,
            depth,
            rel,
        )
        scored.append((score, path))
    scored.sort(key=lambda item: item[0])
    chosen = scored[0][1]
    init_relpath = chosen.relative_to(src_dir).as_posix()
    parts = init_relpath.split('/')
    if len(parts) == 1:
        source_root = ''
        original_module_name = ''
        import_mode = 'root_package'
    else:
        source_root = '/'.join(parts[:-1])
        original_module_name = parts[0]
        import_mode = 'package'
    return init_relpath, source_root, original_module_name, import_mode





def build_specs(force: bool = False) -> list[dict[str, Any]]:
    global _CACHE
    if _CACHE is not None and not force:
        return list(_CACHE)

    report_specs = _parse_report()
    root = integrated_root()
    results: list[dict[str, Any]] = []
    if not root.exists():
        _CACHE = []
        return []

    for alias in TOOL_FOLDERS:
        addon_dir = root / alias
        if not addon_dir.is_dir():
            continue
        spec = dict(report_specs.get(alias) or {
            'alias': alias,
            'outer_zip': alias + '.zip',
            'display_name': alias,
            'suite': 'uv_suite',
            'suite_name': 'Smart UV',
            'load': True,
            'note': '',
            'duplicate_of': '',
            'superseded_by': '',
            'spaces': [],
        })
        src_dir = addon_dir
        root_init = src_dir / '__init__.py'
        if root_init.exists():
            init_relpath, source_root, original_module_name, import_mode = '__init__.py', '', '', 'root_package'
        else:
            init_relpath, source_root, original_module_name, import_mode = _find_init_file(src_dir)
        if not init_relpath:
            continue
        spec['src_dir'] = str(src_dir)
        spec['source_root'] = source_root
        spec['original_module_name'] = original_module_name
        spec['import_mode'] = import_mode
        spec['init_relpath'] = init_relpath
        spec['search_root'] = source_root
        spec['vendor_dir'] = str(addon_dir)
        spec['suite_name'] = spec.get('suite_name') or SUITE_META.get(spec['suite'], ('Smart UV', 'navigation_properties'))[0]
        init_path = src_dir / init_relpath
        name, description = _read_bl_info_name_and_description(init_path)
        if name and not spec.get('display_name'):
            spec['display_name'] = name
        spec['description'] = description or str(spec.get('display_name') or alias)
        results.append(spec)

    _CACHE = list(results)
    return list(results)
