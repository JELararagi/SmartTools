# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations
from . import resource_api_18168 as _suv_resource

import hashlib
import importlib
import textwrap
from typing import Any

import bpy

from . import loader, preferences_proxy, registry, text_translation as _text_translation

_REGISTERED_CLASSES: list[type] = []
_RECORDS_BY_ALIAS: dict[str, dict[str, Any]] = {}
_SUITE_RECORDS: dict[str, list[dict[str, Any]]] = {}
_NAV_MODULE_CACHE: dict[str, object] = {}
_SUITE_ROOT_PANEL_IDS: dict[str, str] = {}
_ADDON_PANEL_IDS: dict[str, str] = {}

MOVED_ALWAYS_ON_OPERATOR_IDS: frozenset[str] = frozenset({
    'suv.toggle_live_unwrap',
    'uv.suv_uv_sync_mode_toggle',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
    'smart_uv_suite.native_hub_action',
})


class _IdFactory:
    @staticmethod
    def token(*parts: object, size: int = 10) -> str:
        source = '||'.join(str(part or '') for part in parts)
        return hashlib.md5(source.encode('utf-8')).hexdigest()[: max(6, int(size))].upper()

    @staticmethod
    def panel(prefix: str, *parts: object) -> tuple[str, str]:
        token = _IdFactory.token(prefix, *parts)
        class_name = f'SMARTTOOLS_PT_{prefix}_{token}'
        return class_name, class_name


ID_FACTORY = _IdFactory()


def _safe_register_class(cls: type) -> None:
    try:
        from . import text_translation as _text_translation
        sanitize_class = getattr(_text_translation, 'sanitize_class', None)
        if callable(sanitize_class):
            cls = sanitize_class(cls, context=getattr(bpy, 'context', None))
    except Exception:
        pass
    _suv_resource.register_class(cls)
    _REGISTERED_CLASSES.append(cls)


def _safe_unregister_registered_classes() -> None:
    for cls in reversed(_REGISTERED_CLASSES):
        try:
            _suv_resource.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED_CLASSES.clear()
    _SUITE_ROOT_PANEL_IDS.clear()
    _ADDON_PANEL_IDS.clear()
    _RECORDS_BY_ALIAS.clear()
    _SUITE_RECORDS.clear()


def _import_nav_module(module_name: str):
    cached = _NAV_MODULE_CACHE.get(module_name)
    if cached is not None:
        return cached
    mod = importlib.import_module(f'.{module_name}', __package__)
    _NAV_MODULE_CACHE[module_name] = mod
    return mod


def suite_is_active(context, suite_key: str) -> bool:
    suite_key = str(suite_key or '').strip()
    module_name = registry.SUITE_META.get(suite_key, ('', ''))[1]
    if not module_name:
        return False
    try:
        nav = _import_nav_module(module_name)
        fn = getattr(nav, 'is_active', None)
        if callable(fn):
            return bool(fn(context, suite_key))
    except Exception:
        pass
    return False


def suite_panel_context(suite_key: str) -> str:
    suite_key = str(suite_key or '').strip()
    module_name = registry.SUITE_META.get(suite_key, ('', ''))[1]
    if not module_name:
        return 'render'
    try:
        nav = _import_nav_module(module_name)
        value = getattr(nav, '_SMART_TOOLS_CONTEXT', 'RENDER')
        return str(value or 'RENDER').lower()
    except Exception:
        return 'render'


def refresh_all_suites(context=None) -> None:
    if context is None:
        context = getattr(bpy, 'context', None)
    for suite_key, (_suite_name, module_name) in registry.SUITE_META.items():
        try:
            nav = _import_nav_module(module_name)
            force_fn = getattr(nav, 'force_tool_runtime_refresh', None)
            if callable(force_fn):
                force_fn()
        except Exception:
            pass
        try:
            nav = _import_nav_module(module_name)
            refresh_fn = getattr(nav, 'refresh_ui_runtime', None)
            if callable(refresh_fn):
                refresh_fn(context=context, addon_key=suite_key, activate_if_properties=False)
        except Exception:
            pass


def _tag_redraw_all() -> None:
    wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    if wm is None:
        return
    for window in getattr(wm, 'windows', ()) or ():
        screen = getattr(window, 'screen', None)
        if screen is None:
            continue
        for area in getattr(screen, 'areas', ()) or ():
            try:
                area.tag_redraw()
            except Exception:
                pass


def _wrap_lines(layout, text: str, width: int = 78, icon: str = 'NONE') -> None:
    text = str(text or '').strip()
    if not text:
        return
    lines = textwrap.wrap(text, width=max(24, int(width))) or [text]
    first = True
    for line in lines:
        if first:
            layout.label(text=line, icon=icon)
            first = False
        else:
            layout.label(text=line)


def _is_ja(context=None) -> bool:
    return bool(_text_translation.is_japanese(context))


def _tr(en: str, ja: str, context=None) -> str:
    return str(_text_translation.pick(str(en or ''), str(ja or ''), context=context))


def _ui_text(text: str, context=None) -> str:
    try:
        return str(_text_translation.inline(str(text or ''), context=context))
    except Exception:
        return str(text or '')

def _status_text(record: dict, context=None) -> str:
    status = str(record.get('status') or '')
    if status == 'loaded':
        return _tr('Loaded', '読み込み済み', context)
    if status == 'loading':
        return _tr('Loading', '読み込み中', context)
    if status == 'ready':
        return _tr('Standby', '待機中', context)
    if status == 'unsupported_platform':
        return _tr('Unsupported platform', '現在の OS・CPU では無効', context)
    if status == 'failed':
        return _tr('Load failed', '読み込み失敗', context)
    if status == 'disabled':
        return _tr('Disabled', '無効', context)
    return str(status or _tr('Unknown', '不明', context))


def _operator_rna_exists(op_idname: str) -> bool:
    try:
        head, tail = str(op_idname or '').split('.', 1)
        group = getattr(bpy.ops, head, None)
        if group is None:
            return False
        op = getattr(group, tail, None)
        rna = op.get_rna_type()
        identifier = str(getattr(rna, 'identifier', '') or '')
        return bool(identifier) and identifier not in {'Operator', 'OperatorProperties', 'UnknownType', 'bpy_struct'}
    except Exception:
        return False


def _operator_prop_names(op) -> set[str]:
    names: set[str] = set()
    try:
        props = getattr(getattr(op, 'bl_rna', None), 'properties', None)
        try:
            names.update(str(k) for k in props.keys())
        except Exception:
            pass
        try:
            for prop in props:
                ident = str(getattr(prop, 'identifier', '') or '')
                if ident:
                    names.add(ident)
        except Exception:
            pass
    except Exception:
        pass
    return names


def _operator_has_props(op_idname: str, names) -> bool:
    if not _operator_rna_exists(op_idname):
        return False
    wanted = {str(name) for name in (names or []) if str(name)}
    if not wanted:
        return True
    try:
        head, tail = str(op_idname or '').split('.', 1)
        op = getattr(getattr(bpy.ops, head, None), tail, None)
        rna = op.get_rna_type()
        available: set[str] = set()
        props = getattr(rna, 'properties', None)
        try:
            available.update(str(k) for k in props.keys())
        except Exception:
            pass
        try:
            for prop in props:
                ident = str(getattr(prop, 'identifier', '') or '')
                if ident:
                    available.add(ident)
        except Exception:
            pass
        return wanted.issubset(available)
    except Exception:
        return False

def _safe_set_props(op, props: dict | None) -> None:
    if op is None or not props:
        return
    available = _operator_prop_names(op)
    if not available:
        return
    for key, value in dict(props).items():
        key = str(key)
        if key not in available:
            continue
        try:
            setattr(op, key, value)
        except Exception:
            pass


def _help_op_exists() -> bool:
    return _operator_rna_exists('smart_uv_suite.show_help')


def _draw_help_button(row, context, help_id: str, title_en: str, title_ja: str):
    try:
        if not _operator_has_props('smart_uv_suite.show_help', {'help_id'}):
            return None
        try:
            help_row = row.row(align=True)
            help_row.scale_x = 0.82
            help_row.scale_y = 1.0
        except Exception:
            help_row = row
        op = help_row.operator('smart_uv_suite.show_help', text='', icon='QUESTION')
        _safe_set_props(op, {'help_id': str(help_id or ''), 'title_en': str(title_en or ''), 'title_ja': str(title_ja or '')})
        return op
    except Exception:
        return None


def _addon_help_en(spec: dict, status: str = '') -> str:
    context = getattr(bpy, 'context', None)
    desc = _ui_text(str(spec.get('description') or spec.get('display_name') or '').strip(), context)
    if status == 'loaded':
        if desc:
            return (
                f'Function: {desc}. How to use: use the migrated controls below inside the UV Suite N-panel. '
                f'When you finish working, disable this tool to stop background handlers and reduce overhead.'
            )
        return (
            'Function: This add-on has been loaded inside the UV Suite N-panel. How to use: use the migrated controls below. '
            'Disable it after use to stop background handlers and reduce overhead.'
        )
    if desc:
        return (
            f'Function: {desc}. How to use: this add-on is now load-on-demand to keep Blender startup lighter. '
            f'This tool is initialized automatically while UV Suite is enabled.'
        )
    return (
        'Function: This add-on has been migrated into Smart Tools. How to use: it is always active while UV Suite is enabled, '
        'then turn it off again after use to keep Blender responsive.'
    )


def _addon_help_ja(spec: dict, status: str = '') -> str:
    context = getattr(bpy, 'context', None)
    name = _ui_text(str(spec.get('display_name') or 'Integrated Add-on').strip(), context)
    desc = _ui_text(str(spec.get('description') or '').strip(), context)
    if status == 'loaded':
        if desc:
            return (
                f'機能: {name} の元機能を UV Suite Nパネル内へ統合しています。内容: {desc}。使い方: 下の移植済みUIを使ってください。'
                f'作業が終わったら不要な常時起動項目を無効にすると、常駐ハンドラやコールバックを停止して負荷を下げられます。'
            )
        return (
            f'機能: {name} の元機能を UV Suite Nパネル内へ統合しています。使い方: 下の移植済みUIを使ってください。'
            f'作業後に不要な常時起動項目を無効にすると、常駐ハンドラやコールバックを停止して負荷を下げられます。'
        )
    if desc:
        return (
            f'機能: {name} の元機能を UV Suite Nパネル内へ統合しています。内容: {desc}。使い方: Blender 起動負荷を下げるため、'
            f'このアドオンは必要時のみ初期化する方式です。使う時だけ下の初期化ボタンを押し、不要な常時起動項目は無効にしてください。'
        )
    return (
        f'機能: {name} の元機能を UV Suite Nパネル内へ統合しています。使い方: Blender 起動負荷を下げるため、'
        f'このアドオンは必要時のみ初期化する方式です。使う時だけ下の初期化ボタンを押し、不要な常時起動項目は無効にしてください。'
    )


def _target_help_en(kind: str, label: str, desc: str, *, is_pie: bool = False) -> str:
    context = getattr(bpy, 'context', None)
    label = _ui_text(str(label or '').strip() or 'Integrated Tool', context)
    desc = _ui_text(str(desc or '').strip(), context)
    if kind == 'load':
        return f'Function: initializes {label}. How to use: click this only when you need this integrated tool so startup stays light.'
    if kind == 'menu':
        menu_kind = 'pie menu' if is_pie else 'menu'
        return (
            f'Function: opens the migrated {label} {menu_kind} inside the UV Suite N-panel. '
            f'How to use: click this button, then choose a command from the opened menu.'
        )
    body = desc or label
    return (
        f'Function: {body}. How to use: click this button to run the migrated command inside the UV Suite N-panel. '
        f'Some tools may open additional dialogs or require a valid selection or mode.'
    )


def _target_help_ja(kind: str, label: str, desc: str, *, is_pie: bool = False) -> str:
    context = getattr(bpy, 'context', None)
    label = _ui_text(str(label or '').strip() or '統合ツール', context)
    desc = _ui_text(str(desc or '').strip(), context)
    if kind == 'load':
        return f'機能: {label} を初期化します。使い方: 起動負荷を軽く保つため、この統合ツールが必要な時だけ押してください。'
    if kind == 'menu':
        menu_kind = 'パイメニュー' if is_pie else 'メニュー'
        return (
            f'機能: UV Suite Nパネル内で移植済みの {label} {menu_kind} を開きます。'
            f'使い方: このボタンを押して、表示されたメニューから目的の機能を選んでください。'
        )
    body = desc or label
    return (
        f'機能: {body}。使い方: このボタンを押すと UV Suite Nパネル内の移植コマンドを実行します。'
        f'機能によっては追加ダイアログが開く場合や、選択状態・モードが必要な場合があります。'
    )


def _addon_help(spec: dict, status: str = '', context=None) -> str:
    return _addon_help_ja(spec, status) if _is_ja(context) else _addon_help_en(spec, status)


def _target_help(kind: str, label: str, desc: str, *, is_pie: bool = False, context=None) -> str:
    return _target_help_ja(kind, label, desc, is_pie=is_pie) if _is_ja(context) else _target_help_en(kind, label, desc, is_pie=is_pie)


def _activation_help(spec: dict, enable: bool, context=None) -> str:
    return _activation_help_ja(spec, enable) if _is_ja(context) else _activation_help_en(spec, enable)


def _activation_help_en(spec: dict, enable: bool) -> str:
    context = getattr(bpy, 'context', None)
    name = _ui_text(str(spec.get('display_name') or spec.get('alias') or 'Integrated Add-on').strip(), context)
    if enable:
        return (
            f'Function: loads {name} only when needed. How to use: press this before using the tool. '
            f'This keeps Blender startup faster by leaving heavy handlers, previews, and callbacks inactive until required. Shortcut registration stays manual-only in this build.'
        )
    return (
        f'Function: unloads {name} after use. How to use: press this when you finish working to stop its background handlers, '
        f'callbacks, previews, and other tool_runtime overhead. Shortcut registration stays manual-only in this build.'
    )


def _activation_help_ja(spec: dict, enable: bool) -> str:
    context = getattr(bpy, 'context', None)
    name = _ui_text(str(spec.get('display_name') or spec.get('alias') or '統合アドオン').strip(), context)
    if enable:
        return (
            f'機能: {name} を必要な時だけ読み込みます。使い方: このツールを使う直前に押してください。'
            f'重いハンドラ、プレビュー、キーマップ、コールバックを未使用時は停止したままにして、Blender 起動を軽く保ちます。'
        )
    return (
        f'機能: {name} を使い終わった後にアンロードします。使い方: 作業終了時に押してください。'
        f'背景で動くハンドラ、コールバック、キーマップ、プレビューなどの常駐負荷を停止します。'
    )


def _trace_excerpt(text: str) -> str:
    for line in reversed(str(text or '').splitlines()):
        line = line.strip()
        if line:
            return line[:240]
    return ''


def _call_draw(draw_fn, panel_cls, layout, context) -> None:
    shim_name = f'_SMARTTOOLS_INT_PANEL_SHIM_{ID_FACTORY.token(getattr(panel_cls, "__name__", ""), size=12)}'
    attrs = {}
    for name, value in getattr(panel_cls, '__dict__', {}).items():
        if name.startswith('__'):
            continue
        attrs[name] = value
    shim_cls = type(shim_name, (), attrs)
    shim = shim_cls()
    try:
        shim.layout = layout
    except Exception:
        pass
    for name in ('bl_idname', 'bl_label', 'bl_space_type', 'bl_region_type', 'bl_context', 'bl_parent_id', 'bl_options'):
        try:
            setattr(shim, name, getattr(panel_cls, name))
        except Exception:
            pass
    try:
        shim.is_popover = False
    except Exception:
        pass
    draw_fn(shim, context)


def _menu_entries(record: dict) -> list[tuple[str, str, bool]]:
    items = []
    seen = set()
    for cls in record.get('menus', ()) or ():
        menu_id = str(getattr(cls, 'bl_idname', '') or '').strip()
        if not menu_id or menu_id in seen:
            continue
        seen.add(menu_id)
        label = str(getattr(cls, 'bl_label', '') or getattr(cls, '__name__', '') or menu_id).strip()
        upper = f'{menu_id} {label} {getattr(cls, "__name__", "")}'.upper()
        is_pie = 'PIE' in upper
        items.append((menu_id, label or menu_id, is_pie))
    items.sort(key=lambda item: item[1].lower())
    return items


def _operator_entries(record: dict) -> list[tuple[str, str, str]]:
    items = []
    seen = set()
    for cls in record.get('operators', ()) or ():
        op_id = str(getattr(cls, 'bl_idname', '') or '').strip()
        if not op_id or op_id in seen or op_id in MOVED_ALWAYS_ON_OPERATOR_IDS:
            continue
        seen.add(op_id)
        label = str(getattr(cls, 'bl_label', '') or '').strip() or op_id
        desc = str(getattr(cls, 'bl_description', '') or '').strip()
        items.append((op_id, label, desc))
    items.sort(key=lambda item: (item[1].lower(), item[0].lower()))
    return items


def _panel_entries(record: dict) -> list[tuple[str, type]]:
    items: list[tuple[str, type]] = []
    for cls in record.get('panels', ()) or ():
        label = str(getattr(cls, 'bl_label', '') or getattr(cls, '__name__', '') or 'Panel').strip()
        items.append((label or 'Panel', cls))
    items.sort(key=lambda item: item[0].lower())
    return items


def _preference_entries(record: dict) -> list[tuple[str, type]]:
    items: list[tuple[str, type]] = []
    seen = set()
    for cls in record.get('preferences', ()) or ():
        key = (str(getattr(cls, 'bl_idname', '') or ''), str(getattr(cls, '__name__', '') or ''))
        if key in seen:
            continue
        seen.add(key)
        label = str(getattr(cls, 'bl_label', '') or getattr(cls, '__name__', '') or 'Preferences').strip()
        items.append((label or 'Preferences', cls))
    items.sort(key=lambda item: item[0].lower())
    return items


class _UILayoutProxyShim:
    def __init__(self, data_obj, layout):
        object.__setattr__(self, '_smarttools_data_obj', data_obj)
        object.__setattr__(self, 'layout', layout)

    def __getattr__(self, name):
        return getattr(object.__getattribute__(self, '_smarttools_data_obj'), name)

    def __setattr__(self, name, value):
        if name in {'_smarttools_data_obj', 'layout'} or str(name).startswith('bl_') or str(name).startswith('_smarttools_shim_'):
            object.__setattr__(self, name, value)
            return
        try:
            setattr(object.__getattribute__(self, '_smarttools_data_obj'), name, value)
        except Exception:
            object.__setattr__(self, name, value)

    def __dir__(self):
        return sorted(set(list(self.__dict__.keys()) + dir(object.__getattribute__(self, '_smarttools_data_obj'))))


def _call_data_draw(draw_fn, owner_cls, data_obj, layout, context) -> None:
    shim = _UILayoutProxyShim(data_obj, layout)
    if owner_cls is not None:
        for name in ('bl_idname', 'bl_label', 'bl_space_type', 'bl_region_type', 'bl_context', 'bl_parent_id', 'bl_options'):
            try:
                setattr(shim, name, getattr(owner_cls, name))
            except Exception:
                pass
    draw_fn(shim, context)


def _iter_property_names(data_obj, owner_cls=None) -> list[str]:
    names: list[str] = []
    seen: set[str] = set()

    def _append(name: object) -> None:
        text = str(name or '').strip()
        if not text or text in seen:
            return
        if text.startswith('_') or text in {'rna_type', 'bl_idname', 'layout'}:
            return
        seen.add(text)
        names.append(text)

    for source in (getattr(owner_cls, '__annotations__', {}) if owner_cls is not None else {}, getattr(type(data_obj), '__annotations__', {})):
        for name in dict(source or {}).keys():
            _append(name)

    try:
        props = getattr(getattr(data_obj, 'bl_rna', None), 'properties', None)
        if props is not None:
            for name in getattr(props, 'keys', lambda: [])():
                _append(name)
    except Exception:
        pass

    return names


def _draw_property_fallback(layout, data_obj, owner_cls=None) -> int:
    names = _iter_property_names(data_obj, owner_cls)
    if not names:
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        return 0

    drawn = 0
    col = layout.column(align=False)
    for name in names:
        try:
            col.prop(data_obj, name)
            drawn += 1
        except Exception:
            continue

    if not drawn:
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
    return drawn


def _preference_object(context, pref_cls):
    addon_id = str(getattr(pref_cls, 'bl_idname', '') or getattr(pref_cls, '__module__', '') or '').strip()
    return preferences_proxy.get_addon_preferences(context, addon_id, pref_cls)


def _live_record(alias: str, fallback: dict) -> dict:
    return _RECORDS_BY_ALIAS.get(alias, fallback)


def _common_properties_poll(context, suite_key: str) -> bool:
    area = getattr(context, 'area', None)
    if area is None or getattr(area, 'type', None) != 'VIEW_3D':
        return False
    return suite_is_active(context, suite_key)


def _draw_feature_surface_note(layout, context=None) -> None:
    box = layout.box()
    pass  # INFO-note moved to Help; no in-section info-icon explanation.


def _draw_quick_access_block(layout, live_record: dict, alias: str, *, limit: int = 6, context=None) -> int:
    quick = _quick_entries(live_record, limit=limit)
    if not quick:
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        return 0

    quick_box = layout.box()
    quick_box.label(text=_tr('Quick Access', 'クイックアクセス', context), icon='TOOL_SETTINGS')
    col = quick_box.column(align=True)
    for kind, item_id, label, desc, is_pie in quick:
        _invoke_operator(
            col,
            addon_alias=alias,
            target_kind=kind,
            target_id=item_id,
            label=label,
            desc=desc,
            is_pie=is_pie,
        )
    return len(quick)


def _draw_migrated_panels_block(layout, live_record: dict, context) -> int:
    panels = _panel_entries(live_record)
    if not panels:
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        return 0

    _wrap_lines(
        layout,
        _tr(
            'These are the original source panels, redrawn inside the UV Suite N-panel so their embedded controls remain usable after the legacy sidebars were removed.',
            '旧サイドバーを廃止した後も、元アドオンの埋め込み操作を使えるように、ここへ元パネルを再描画しています。',
            context,
        ),
        width=76,
        icon='PREFERENCES',
    )

    drawn = 0
    for panel_label, panel_cls in panels:
        draw_fn = getattr(panel_cls, 'draw', None)
        section = layout.box()
        section.label(text=panel_label, icon='DOT')
        if not callable(draw_fn):
            pass  # INFO-note moved to Help; no in-section info-icon explanation.
            continue
        try:
            _call_draw(draw_fn, panel_cls, section, context)
            drawn += 1
        except Exception as exc:
            section.label(text=_tr(f'Proxy draw failed: {exc}', f'プロキシ描画に失敗しました: {exc}', context), icon='ERROR')
    return drawn


def _draw_preferences_block(layout, live_record: dict, context) -> int:
    pref_entries = _preference_entries(live_record)
    if not pref_entries:
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        return 0

    _wrap_lines(
        layout,
        _tr(
            'These are the original add-on preference controls brought into Smart Tools so settings-only features do not stay hidden in the background.',
            '元アドオンの設定専用機能が裏側に隠れたままにならないよう、設定画面の操作系も UVスイートNパネル内へ持ってきています。',
            context,
        ),
        width=76,
        icon='SETTINGS',
    )

    drawn = 0
    for pref_label, pref_cls in pref_entries:
        section = layout.box()
        section.label(text=pref_label, icon='PREFERENCES')
        pref_obj = _preference_object(context, pref_cls)
        if pref_obj is None:
            section.label(text=_tr('Settings proxy could not be prepared.', '設定プロキシを準備できませんでした。', context), icon='ERROR')
            continue

        draw_fn = getattr(pref_cls, 'draw', None)
        if callable(draw_fn):
            try:
                _call_data_draw(draw_fn, pref_cls, pref_obj, section, context)
                drawn += 1
                continue
            except Exception as exc:
                section.label(text=_tr(f'Original settings draw failed: {exc}', f'元設定UIの描画に失敗しました: {exc}', context), icon='ERROR')

        if _draw_property_fallback(section, pref_obj, pref_cls):
            drawn += 1
    return drawn


def _draw_all_menus_block(layout, live_record: dict, alias: str, context=None) -> int:
    menu_entries = _menu_entries(live_record)
    if not menu_entries:
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        return 0

    _wrap_lines(
        layout,
        _tr(
            'This list exposes every registered menu from the integrated tool, including menus that are not linked from the migrated source panels.',
            '移植元パネルから直接つながっていないものも含め、この統合ツールで登録された全メニューをここから開けます。',
            context,
        ),
        width=76,
        icon='MENU_PANEL',
    )

    col = layout.column(align=True)
    for menu_id, label, is_pie in menu_entries:
        _invoke_operator(
            col,
            addon_alias=alias,
            target_kind='menu',
            target_id=menu_id,
            label=label,
            desc=menu_id,
            is_pie=is_pie,
        )
    return len(menu_entries)


def _draw_all_operators_block(layout, live_record: dict, alias: str, context=None) -> int:
    operator_entries = _operator_entries(live_record)
    if not operator_entries:
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        return 0

    _wrap_lines(
        layout,
        _tr(
            'This list exposes every registered operator from the integrated tool, including commands that were implemented internally but not surfaced by the original visible panels.',
            '元の見えるパネルには出ていなかった内部実装コマンドも含め、この統合ツールで登録された全オペレーターをここから実行できます。',
            context,
        ),
        width=76,
        icon='TOOL_SETTINGS',
    )

    col = layout.column(align=True)
    for op_id, label, desc in operator_entries:
        _invoke_operator(
            col,
            addon_alias=alias,
            target_kind='operator',
            target_id=op_id,
            label=label,
            desc=desc or op_id,
            is_pie=False,
        )
    return len(operator_entries)


def _quick_feature_total(live_record: dict) -> int:
    return (
        len(_panel_entries(live_record))
        + len(_preference_entries(live_record))
        + len(_menu_entries(live_record))
        + len(_operator_entries(live_record))
    )


def _quick_entries(record: dict, limit: int = 6) -> list[tuple[str, str, str, str, bool]]:
    quick: list[tuple[str, str, str, str, bool]] = []
    menu_limit = max(1, int(limit) // 2) if limit else 0
    for menu_id, label, is_pie in _menu_entries(record)[:menu_limit]:
        quick.append(('menu', menu_id, label, '', is_pie))
    remaining = max(0, int(limit) - len(quick))
    for op_id, label, desc in _operator_entries(record)[:remaining]:
        quick.append(('operator', op_id, label, desc, False))
    return quick


def _invoke_operator(layout, *, addon_alias: str, target_kind: str, target_id: str, label: str, desc: str = '', is_pie: bool = False) -> None:
    icon = 'PRESET' if target_kind == 'menu' and is_pie else ('DOWNARROW_HLT' if target_kind == 'menu' else 'TOOL_SETTINGS')
    try:
        op = layout.operator(SMART_UV_SUITE_30F9D7_SMARTTOOLS_OT_integrated_invoke.bl_idname, text=label, icon=icon)
        _safe_set_props(op, {'addon_alias': addon_alias, 'target_kind': target_kind, 'target_id': target_id, 'target_label': label, 'target_desc': desc, 'is_pie_menu': bool(is_pie)})
    except Exception:
        layout.label(text=label)


def _resolve_operator_callable(op_id: str):
    op_id = str(op_id or '').strip()
    if '.' not in op_id:
        return None
    head, tail = op_id.split('.', 1)
    group = getattr(bpy.ops, head, None)
    if group is None:
        return None
    return getattr(group, tail, None)


def _package_root_module():
    return importlib.import_module(__package__)


def _native_core_status() -> str:
    try:
        module = _package_root_module()
        fn = getattr(module, 'core_status', None)
        if callable(fn):
            return str(fn() or 'loaded')
    except Exception:
        pass
    return 'loaded'


def _native_core_last_error() -> str:
    try:
        module = _package_root_module()
        fn = getattr(module, 'core_last_error', None)
        if callable(fn):
            return str(fn() or '')
    except Exception:
        pass
    return ''


class SMART_UV_SUITE_30F9D7_SMARTTOOLS_OT_integrated_addon_info(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.integrated_addon_info'
    bl_label = 'Integrated Add-on Info'
    bl_options = {'INTERNAL'}

    addon_alias: bpy.props.StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def description(cls, _context, properties):
        alias = str(getattr(properties, 'addon_alias', '') or '')
        record = _RECORDS_BY_ALIAS.get(alias, {})
        spec = record.get('spec', {}) if isinstance(record, dict) else {}
        status = _status_text(record, _context) if isinstance(record, dict) else _tr('Unknown', '不明', _context)
        note = str(spec.get('note') or '').strip()
        lines = [
            f"{spec.get('display_name', alias)}",
            _addon_help(spec, str(record.get('status') or ''), _context),
            _tr('Status', '状態', _context) + f': {status}',
        ]
        if note:
            lines.append(_tr('Note', 'メモ', _context) + f': {note}')
        return ' '.join(str(line) for line in lines if line)

    def execute(self, context):
        alias = str(self.addon_alias or '')
        record = _RECORDS_BY_ALIAS.get(alias, {})
        spec = record.get('spec', {}) if isinstance(record, dict) else {}
        status = _status_text(record, context) if isinstance(record, dict) else _tr('Unknown', '不明', context)
        self.report({'INFO'}, _tr(f"{spec.get('display_name', alias)} - {status}", f"{spec.get('display_name', alias)} - {status}", context))
        return {'FINISHED'}


class SMART_UV_SUITE_30F9D7_SMARTTOOLS_OT_integrated_invoke(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.integrated_invoke'
    bl_label = 'Integrated Tool'
    bl_options = {'INTERNAL'}

    addon_alias: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_kind: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_id: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_label: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_desc: bpy.props.StringProperty(options={'SKIP_SAVE'})
    is_pie_menu: bpy.props.BoolProperty(default=False, options={'SKIP_SAVE'})

    @classmethod
    def description(cls, _context, properties):
        kind = str(getattr(properties, 'target_kind', '') or '')
        label = str(getattr(properties, 'target_label', '') or '')
        desc = str(getattr(properties, 'target_desc', '') or '')
        is_pie = bool(getattr(properties, 'is_pie_menu', False))
        return _target_help(kind, label, desc, is_pie=is_pie, context=_context)

    def execute(self, context):
        alias = str(self.addon_alias or '').strip()
        kind = str(self.target_kind or '').strip()
        target_id = str(self.target_id or '').strip()

        if not kind and not target_id:
            self.report({'WARNING'}, _tr(
                'No integrated tool target was specified.',
                '統合ツールの呼び出し先が指定されていません。',
                context,
            ))
            return {'CANCELLED'}

        record = _RECORDS_BY_ALIAS.get(alias)
        if isinstance(record, dict) and str(record.get('status') or '') != 'loaded':
            record = loader.load_record(alias)
            _collect_records()
            try:
                refresh_all_suites(context)
            except Exception:
                pass
            _tag_redraw_all()
            if not isinstance(record, dict) or str(record.get('status') or '') != 'loaded':
                self.report({'ERROR'}, _tr(f'Integrated add-on is not loaded: {alias}', f'統合アドオンが読み込まれていません: {alias}', context))
                return {'CANCELLED'}

        if kind == 'load':
            self.report({'INFO'}, _tr(f'Initialized: {alias}', f'初期化しました: {alias}', context))
            return {'FINISHED'}

        if kind == 'menu':
            try:
                if self.is_pie_menu:
                    return bpy.ops.wm.call_menu_pie(name=target_id)
                return bpy.ops.wm.call_menu(name=target_id)
            except Exception as exc:
                self.report({'ERROR'}, _tr(f'Menu invoke failed: {target_id} ({exc})', f'メニュー呼び出しに失敗しました: {target_id} ({exc})', context))
                return {'CANCELLED'}

        op_callable = _resolve_operator_callable(target_id)
        if not callable(op_callable):
            self.report({'ERROR'}, _tr(f'Operator not found: {target_id}', f'オペレーターが見つかりません: {target_id}', context))
            return {'CANCELLED'}

        last_error = None
        for args in (('INVOKE_DEFAULT',), tuple()):
            try:
                result = op_callable(*args)
                if isinstance(result, set):
                    return result
                return {'FINISHED'}
            except Exception as exc:
                last_error = exc
        self.report({'ERROR'}, _tr(f'Operator invoke failed: {target_id} ({last_error})', f'オペレーター実行に失敗しました: {target_id} ({last_error})', context))
        return {'CANCELLED'}


def _collect_records() -> None:
    _RECORDS_BY_ALIAS.clear()
    _SUITE_RECORDS.clear()
    for record in loader.get_records():
        spec = record.get('spec') or {}
        alias = str(spec.get('alias') or '')
        suite_key = str(spec.get('suite') or '')
        if alias:
            _RECORDS_BY_ALIAS[alias] = record
        if suite_key:
            _SUITE_RECORDS.setdefault(suite_key, []).append(record)


_FOLDOUT_PREFIX = 'uv_suite_ui_foldout_'


def _foldout_prop(key: str) -> str:
    raw = str(key or '').strip().lower()
    safe = ''.join(ch if ch.isalnum() or ch == '_' else '_' for ch in raw).strip('_')
    return _FOLDOUT_PREFIX + (safe or 'section')


def _foldout_state(context, key: str, default: bool = False) -> bool:
    try:
        from . import npanel_persistence as _npanel_store
        return bool(_npanel_store.peek_foldout(str(key or ''), bool(default)))
    except Exception:
        return bool(default)


def _draw_foldout_header(layout, context, key: str, label: str, *, icon: str = 'PACKAGE', default_open: bool = False, help_id: str = '', help_title_en: str = '', help_title_ja: str = ''):
    expanded = _foldout_state(context, key, default_open)
    section = layout.column(align=True)
    box = section.box()
    row = box.row(align=True)
    try:
        if _operator_has_props('smart_uv_suite.toggle_ui_foldout', {'key', 'default_open'}):
            op = row.operator('smart_uv_suite.toggle_ui_foldout', text=_ui_text(label, context), icon='TRIA_DOWN' if expanded else 'TRIA_RIGHT', emboss=False)
            _safe_set_props(op, {'key': key, 'default_open': bool(default_open)})
        else:
            row.label(text=_ui_text(label, context), icon='TRIA_DOWN' if expanded else 'TRIA_RIGHT')
        row.label(text='', icon=icon)
        if help_id:
            _draw_help_button(row, context, help_id, help_title_en or _ui_text(label, context), help_title_ja or _ui_text(label, context))
    except Exception:
        row.label(text=_ui_text(label, context), icon=icon)
    return section, expanded


def register() -> None:
    _safe_unregister_registered_classes()
    _collect_records()
    # Register only the dispatcher operators.  All integrated menus/operators are
    # drawn inline from the single UV Suite N-panel to avoid many Panel draw
    # callbacks in Blender 5.x.
    _safe_register_class(SMART_UV_SUITE_30F9D7_SMARTTOOLS_OT_integrated_addon_info)
    _safe_register_class(SMART_UV_SUITE_30F9D7_SMARTTOOLS_OT_integrated_invoke)
    _tag_redraw_all()


def unregister() -> None:
    _safe_unregister_registered_classes()
