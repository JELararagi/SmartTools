import bpy


def _box(context, op):
    if context.mode != 'EDIT_MESH':
        return False
    native = bpy.ops.uv.cube_project
    size = op.value if op.value > 0 else 1.0
    return native.poll() and 'FINISHED' in native(cube_size=size)


def _best_planar(context, op):
    return context.mode == 'EDIT_MESH' and 'FINISHED' in bpy.ops.smart_uv_suite.unwrap_auto_action(
        mode='QUICK_PLANAR')


def build_handlers(api):
    return {
        'smart_uv_suite.workflow_uvw_box_map': api.Handler(_box, 'Box-project the selected faces into the active UV map.', '選択面をボックス投影してアクティブ UV マップに書き込みます。'),
        'smart_uv_suite.workflow_uvw_best_planer_map': api.Handler(
            _best_planar, 'Project selected seam charts onto their best-fit planes, preserving their proportions.',
            '選択したシームチャートを、形状の比率を保ってそれぞれの最適平面へ投影します。'),
    }
