"""Directional alignment of selected UV elements."""

import bpy

_DIRECTIONS = {
    "TOP": "TOP", "TOP_LEFT": "TL", "TL": "TL", "TOP_RIGHT": "TR", "TR": "TR",
    "BOTTOM": "BOTTOM", "BOTTOM_LEFT": "BL", "BL": "BL", "BOTTOM_RIGHT": "BR", "BR": "BR",
    "LEFT": "LEFT", "RIGHT": "RIGHT", "CENTER": "CENTER",
    "H": "H", "V": "V", "H_GROUP": "H_GROUP", "V_GROUP": "V_GROUP",
}


def run(context, op):
    direction = (op.direction or op.action or "CENTER").upper().removeprefix("ALIGN_")
    if direction not in _DIRECTIONS:
        op.report({"WARNING"}, "Choose a supported UV alignment direction.")
        return False
    return "FINISHED" in bpy.ops.smart_uv_suite.direction_align(action="ALIGN_" + _DIRECTIONS[direction])


def build_handlers(api):
    orient = api.Handler(
        api._run_uv_layout("suv_orient_islands", defaults={"mode": "MIN_BBOX", "step_deg": 1}, scope="scope"),
        "Rotate each selected UV island so its minimum bounds align with the UV axes.",
        "選択した各 UV アイランドを回転し、最小外接矩形を UV 軸に揃えます。",
    )
    return {
        "smart_uv_suite.align": api.Handler(
            run, "Align selected UVs to the chosen edge or center of their bounds.",
            "選択UVを指定した方向の端または中心へ整列します。"),
        "smart_uv_suite.align_uv_axis": orient,
        "smart_uv_suite.inspect_orient": orient,
        "smart_uv_suite.align_smooth_uv": api.Handler(
            api._run_uv_layout("suv_uv_brush_compat", defaults={"mode": "SMOOTH"},
                               factor="amount", scope="scope"),
            "Smooth selected UVs while preserving pins and boundaries.",
            "ピンと境界を保ちながら選択 UV をスムーズにします。",
        ),
    }
