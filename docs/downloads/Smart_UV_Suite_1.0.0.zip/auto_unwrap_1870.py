# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Final automatic unwrap reliability patch for Smart UV Suite.

This patch fixes the automatic unwrap executor after the late interaction/keymap
patches.  The failure case observed in Blender 5.1.1 is that the UV Editor full
face selection may not be present in the hidden `.uv_select_*` attributes even
though the mesh faces are selected through UV Sync Selection or scripted test
setup.  The previous strict scope code then cancelled every unwrap method.

The patch keeps the strict rule: partial vertex/edge UV selection is still not a
face scope.  It only falls back to mesh face selection when no UV selection data
exists at all.  It also adds a degenerate-result guard for native unwrap methods
such as Minimum Stretch, which can report success while leaving all UVs at one
point on closed test meshes.
"""
from __future__ import annotations

import math
import bpy

try:
    import bmesh
except Exception:  # pragma: no cover
    bmesh = None

_PATCH_VERSION = "1.8.70"
_PATCHED = False


def _as_bool(value) -> bool:
    try:
        return bool(value)
    except Exception:
        return False


def _uv_attr_has_any(state: dict | None) -> bool:
    try:
        if bool((state or {}).get("has_any")):
            return True
        for key in ("face", "vert", "edge"):
            vals = list((state or {}).get(key) or [])
            if any(bool(v) for v in vals):
                return True
    except Exception:
        pass
    return False


def _bmesh_has_live_uv_selection(bm, uv_layer) -> bool:
    if bm is None or uv_layer is None:
        return False
    try:
        for face in bm.faces:
            for loop in face.loops:
                try:
                    luv = loop[uv_layer]
                    if bool(getattr(luv, "select", False)) or bool(getattr(luv, "select_edge", False)):
                        return True
                except Exception:
                    pass
    except Exception:
        pass
    return False


def _no_explicit_uv_selection(bm, uv_layer, state: dict | None) -> bool:
    return (not _uv_attr_has_any(state)) and (not _bmesh_has_live_uv_selection(bm, uv_layer))


def _mesh_selected_face_indices(bm) -> set[int]:
    out: set[int] = set()
    if bm is None:
        return out
    try:
        bm.faces.ensure_lookup_table(); bm.faces.index_update()
    except Exception:
        pass
    try:
        for face in bm.faces:
            try:
                if bool(getattr(face, "select", False)):
                    fi = int(getattr(face, "index", -1))
                    if fi >= 0:
                        out.add(fi)
            except Exception:
                pass
    except Exception:
        pass
    return out


def _install_main_scope_fallback(ns: dict) -> None:
    prev = ns.get("_sus_selected_face_indices_for_uv_context")
    if not callable(prev) or getattr(prev, "_sus_1870_mesh_fallback", False):
        return

    def _selected_face_indices_for_uv_context(bm, uv_layer, uv_attr_state=None):
        try:
            result = set(prev(bm, uv_layer, uv_attr_state) or set())
        except Exception:
            result = set()
        if result:
            return result
        # If there is any explicit UV selection data, an empty face scope means
        # the user selected only vertices/edges or an incomplete face.  Do not
        # expand that into a face operation.
        if not _no_explicit_uv_selection(bm, uv_layer, uv_attr_state):
            return set()
        # In UV Sync Selection or background/scripted execution Blender may only
        # expose selected faces through BMesh face.select.  Treat those complete
        # mesh faces as the UV face scope; this is the only fallback.
        return _mesh_selected_face_indices(bm)

    _selected_face_indices_for_uv_context.__name__ = getattr(prev, "__name__", "_sus_selected_face_indices_for_uv_context")
    _selected_face_indices_for_uv_context._sus_1870_mesh_fallback = True
    ns["_sus_selected_face_indices_for_uv_context"] = _selected_face_indices_for_uv_context


def _install_uv_face_scope_fallback() -> None:
    try:
        from . import uv_face_scope as mod
    except Exception:
        return
    prev = getattr(mod, "strict_selected_face_indices", None)
    if not callable(prev) or getattr(prev, "_sus_1870_mesh_fallback", False):
        return

    def strict_selected_face_indices(context, obj, bm, uv_layer, attr_state=None):
        try:
            selected, has_any = prev(context, obj, bm, uv_layer, attr_state)
            selected = set(selected or set())
        except Exception:
            selected, has_any = set(), False
        if selected:
            return selected, True
        if has_any or not _no_explicit_uv_selection(bm, uv_layer, attr_state):
            return set(), bool(has_any)
        fallback = _mesh_selected_face_indices(bm)
        return fallback, bool(fallback)

    strict_selected_face_indices.__name__ = getattr(prev, "__name__", "strict_selected_face_indices")
    strict_selected_face_indices._sus_1870_mesh_fallback = True
    mod.strict_selected_face_indices = strict_selected_face_indices


def _install_smart_standard_scope_fallback() -> None:
    try:
        from . import smart_uv_standard as mod
    except Exception:
        return

    prev_face = getattr(mod, "_face_uv_selected_for_scope", None)
    if callable(prev_face) and not getattr(prev_face, "_sus_1870_mesh_fallback", False):
        def _face_uv_selected_for_scope(face, uv_layer, uv_attr_state=None):
            try:
                if bool(prev_face(face, uv_layer, uv_attr_state)):
                    return True
            except Exception:
                pass
            # Only if the entire UV selection state is absent, use BMesh face
            # selection as the synchronized UV face selection fallback.
            try:
                bm = face.id_data
            except Exception:
                bm = None
            if not _no_explicit_uv_selection(bm, uv_layer, uv_attr_state):
                return False
            try:
                return bool(getattr(face, "select", False))
            except Exception:
                return False
        _face_uv_selected_for_scope.__name__ = getattr(prev_face, "__name__", "_face_uv_selected_for_scope")
        _face_uv_selected_for_scope._sus_1870_mesh_fallback = True
        mod._face_uv_selected_for_scope = _face_uv_selected_for_scope

    prev_any = getattr(mod, "_has_any_uv_element_selection_for_scope", None)
    if callable(prev_any) and not getattr(prev_any, "_sus_1870_mesh_fallback", False):
        def _has_any_uv_element_selection_for_scope(bm, uv_layer, uv_attr_state=None):
            try:
                if bool(prev_any(bm, uv_layer, uv_attr_state)):
                    return True
            except Exception:
                pass
            if not _no_explicit_uv_selection(bm, uv_layer, uv_attr_state):
                return False
            return bool(_mesh_selected_face_indices(bm))
        _has_any_uv_element_selection_for_scope.__name__ = getattr(prev_any, "__name__", "_has_any_uv_element_selection_for_scope")
        _has_any_uv_element_selection_for_scope._sus_1870_mesh_fallback = True
        mod._has_any_uv_element_selection_for_scope = _has_any_uv_element_selection_for_scope


def _active_mesh(context):
    try:
        obj = getattr(context, "edit_object", None) or getattr(context, "active_object", None) or getattr(context.view_layer.objects, "active", None)
        if obj is not None and getattr(obj, "type", None) == "MESH":
            return obj
    except Exception:
        pass
    return None


def _selected_or_mesh_faces(context, obj, state=None) -> set[int]:
    selected = set()
    try:
        selected.update(int(i) for i in (dict(state or {}).get("selected_faces") or set()))
    except Exception:
        pass
    if selected:
        return selected
    if bmesh is None or obj is None:
        return selected
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        # Build a lightweight explicit-UV selection snapshot from Blender 5.1
        # hidden attributes.  If any partial UV selection exists, do not fall
        # back to mesh face selection.
        attr_state = {}
        # In Edit Mode Blender 5.1 hides/remaps .uv_select_* mesh attributes.
        # Use the add-on's snapshot helper, which safely flushes object data and
        # returns to Edit Mode, so explicit partial UV selections are not lost.
        mod = __import__(__package__, fromlist=["dummy"])
        try:
            snap_fn = getattr(mod, "_sus_uv_attribute_snapshot_for_active", None)
            if callable(snap_fn):
                attr_state = dict(snap_fn(bpy.context, obj) or {})
        except Exception:
            attr_state = {}
        if not attr_state:
            try:
                attrs = getattr(getattr(obj, 'data', None), 'attributes', None)
                if attrs is not None:
                    for aname, key in (('.uv_select_face', 'face'), ('.uv_select_vert', 'vert'), ('.uv_select_edge', 'edge')):
                        attr = attrs.get(aname)
                        if attr is not None:
                            attr_state[key] = [bool(getattr(item, 'value', False)) for item in getattr(attr, 'data', []) or []]
                    attr_state['has_any'] = any(any(attr_state.get(k) or []) for k in ('face', 'vert', 'edge'))
            except Exception:
                attr_state = {}
        # The snapshot helper may briefly leave/re-enter Edit Mode, so recreate
        # BMesh/UV references before the strict selector runs.
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        except Exception:
            pass
        # Prefer the central strict selector if it is available.
        fn = getattr(mod, "_sus_selected_face_indices_for_uv_context", None)
        if callable(fn):
            selected.update(int(i) for i in (fn(bm, uv_layer, attr_state) or set()))
        if selected:
            return selected
        if not _no_explicit_uv_selection(bm, uv_layer, attr_state):
            return set()
        return _mesh_selected_face_indices(bm)
    except Exception:
        return set()


def _uv_area_for_faces(obj, selected_faces: set[int] | None = None) -> float:
    if bmesh is None or obj is None:
        return 0.0
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        bm.faces.ensure_lookup_table(); bm.faces.index_update()
        selected = set(int(i) for i in (selected_faces or []))
        area = 0.0
        for face in bm.faces:
            fi = int(getattr(face, "index", -1))
            if selected and fi not in selected:
                continue
            pts = []
            for loop in face.loops:
                try:
                    uv = loop[uv_layer].uv
                    pts.append((float(uv.x), float(uv.y)))
                except Exception:
                    pass
            if len(pts) < 3:
                continue
            acc = 0.0
            for i, p in enumerate(pts):
                q = pts[(i + 1) % len(pts)]
                acc += p[0] * q[1] - q[0] * p[1]
            area += abs(acc) * 0.5
        return float(area)
    except Exception:
        return 0.0


def _select_faces_for_ops(obj, selected_faces: set[int]) -> bool:
    if bmesh is None or obj is None:
        return False
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        bm.faces.ensure_lookup_table(); bm.faces.index_update()
        for face in bm.faces:
            flag = int(getattr(face, "index", -1)) in selected_faces
            try:
                face.select_set(flag)
            except Exception:
                face.select = flag
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    except Exception:
        return False
    try:
        mod = __import__(__package__, fromlist=["dummy"])
        writer = getattr(mod, "_sus_write_final_uv_face_selection_attrs", None)
        if callable(writer):
            writer(bpy.context, obj, selected_faces)
    except Exception:
        pass
    return True


def _call_uvop(ns: dict, op_id: str, **props) -> bool:
    fn = ns.get("_sus_call_uv_layout_operator")
    if callable(fn):
        try:
            return bool(fn(op_id, **props))
        except Exception:
            pass
    try:
        parts = op_id.split(".")
        op = getattr(getattr(bpy.ops, parts[0]), parts[1])
        result = op("EXEC_DEFAULT", **props)
        return "CANCELLED" not in set(result or set())
    except Exception:
        return False


def _fallback_native_unwrap(ns: dict, context, mode: str, obj, state=None) -> bool:
    selected = _selected_or_mesh_faces(context, obj, state)
    if selected:
        _select_faces_for_ops(obj, selected)
    mode_u = str(mode or "").upper()
    cfg = {}
    try:
        settings = ns.get("_sus_1625_native_settings")
        if callable(settings):
            cfg = dict(settings(context) or {})
    except Exception:
        cfg = {}
    margin = float(cfg.get("unwrap_margin", cfg.get("smart_island_margin", 0.001)) or 0.001)
    margin_method = str(cfg.get("unwrap_margin_method", "SCALED") or "SCALED")
    # The fallback intentionally does not change mesh seams.  It only re-selects
    # the already strict face scope and asks Blender's native solvers again.
    if mode_u == "BLENDER_MIN_STRETCH":
        ok = _call_uvop(ns, "uv.unwrap", method="ANGLE_BASED", margin=margin, margin_method=margin_method, fill_holes=True, correct_aspect=True, no_flip=True)
        if ok:
            _call_uvop(ns, "uv.minimize_stretch", iterations=max(1, int(cfg.get("minimize_iterations", cfg.get("unwrap_iterations", 20)) or 20)), blend=max(0.0, min(1.0, float(cfg.get("minimize_blend", 1.0) or 1.0))))
        return bool(ok)
    if mode_u == "BLENDER_CONFORMAL":
        return _call_uvop(ns, "uv.unwrap", method="CONFORMAL", margin=margin, margin_method=margin_method, fill_holes=True, correct_aspect=True, no_flip=True)
    if mode_u == "BLENDER_SMART_PROJECT":
        return _call_uvop(ns, "uv.smart_project", angle_limit=float(cfg.get("smart_angle_limit", math.radians(66.0)) or math.radians(66.0)), island_margin=float(cfg.get("smart_island_margin", margin) or margin), area_weight=float(cfg.get("smart_area_weight", 0.0) or 0.0), correct_aspect=True)
    return _call_uvop(ns, "uv.unwrap", method="ANGLE_BASED", margin=margin, margin_method=margin_method, fill_holes=True, correct_aspect=True, no_flip=True)


def _install_degenerate_native_guard(ns: dict) -> None:
    prev = ns.get("_sus_1624_call_blender_standard_once")
    if not callable(prev) or getattr(prev, "_sus_1870_degenerate_guard", False):
        return

    def _call_blender_standard_once(context, mode: str, obj=None, state=None):
        mode_u = str(mode or "").upper()
        active = obj or _active_mesh(context)
        selected = _selected_or_mesh_faces(context, active, state) if active is not None else set()
        ok = False
        try:
            ok = bool(prev(context, mode, obj, state))
        except Exception:
            ok = False
        # Some native operators (especially Minimum Stretch on closed components)
        # can report success while leaving the selected UV area collapsed.  Retry
        # with a safe native route so every UI method produces editable UVs.
        try:
            area = _uv_area_for_faces(active, selected) if active is not None else 0.0
        except Exception:
            area = 0.0
        if (not ok) or (mode_u in {"BLENDER_MIN_STRETCH", "BLENDER_FOLLOW_ACTIVE_QUADS"} and area <= 1.0e-12):
            ok = _fallback_native_unwrap(ns, context, mode_u, active, state)
        return bool(ok)

    _call_blender_standard_once.__name__ = getattr(prev, "__name__", "_sus_1624_call_blender_standard_once")
    _call_blender_standard_once._sus_1870_degenerate_guard = True
    ns["_sus_1624_call_blender_standard_once"] = _call_blender_standard_once


def _install_run_guard(ns: dict) -> None:
    prev = ns.get("_sus_run_auto_unwrap_mode")
    if not callable(prev) or getattr(prev, "_sus_1870_run_guard", False):
        return

    def _run_auto_unwrap_mode(context, mode: str):
        obj = _active_mesh(context)
        # Resolve the strict face scope before any old wrapper can fall back to
        # mesh-wide behaviour.  This is the decisive gate for all auto unwrap
        # modes.
        selected_scope = set()
        try:
            if obj is not None and bmesh is not None:
                selected_scope = _selected_or_mesh_faces(context, obj, {})
        except Exception:
            selected_scope = set()
        if obj is None or not selected_scope:
            return False
        # When the selection comes from UV Sync / mesh face selection only, write
        # it into Blender 5.1 hidden UV attributes before calling older solver
        # layers.  Explicit partial UV selections do not reach this branch because
        # _selected_or_mesh_faces returns an empty set for them.
        try:
            writer = ns.get("_sus_write_final_uv_face_selection_attrs")
            if callable(writer):
                writer(context, obj, selected_scope)
        except Exception:
            pass
        before = None
        try:
            from . import seam_guard_1862 as _sg
            before = _sg._snapshot(context, obj)
        except Exception:
            before = None
        ok = False
        try:
            ok = bool(prev(context, mode))
        except Exception:
            ok = False
        # If an old route still returns success with collapsed UVs, retry the
        # native safe route for the current mode.
        try:
            if ok and _uv_area_for_faces(obj, selected_scope) <= 1.0e-12:
                ok = bool(_fallback_native_unwrap(ns, context, str(mode or '').upper(), obj, {'selected_faces': set(selected_scope)}))
        except Exception:
            pass
        # Seam protection is strict even on fallback/exception paths.
        try:
            if before is not None:
                from . import seam_guard_1862 as _sg
                _sg._restore(before)
        except Exception:
            pass
        return bool(ok)

    _run_auto_unwrap_mode.__name__ = getattr(prev, "__name__", "_sus_run_auto_unwrap_mode")
    _run_auto_unwrap_mode._sus_1870_run_guard = True
    ns["_sus_run_auto_unwrap_mode"] = _run_auto_unwrap_mode
    try:
        cls = ns.get("SMARTUVSUITE_OT_unwrap_auto_action")
        if cls is not None:
            cls._run_mode = lambda self, context, mode: ns["_sus_run_auto_unwrap_mode"](context, mode)
    except Exception:
        pass


def apply_all(ns: dict, context=None) -> None:
    ns["_SUS_1870_AUTO_UNWRAP_FIX_VERSION"] = _PATCH_VERSION
    _install_main_scope_fallback(ns)
    _install_uv_face_scope_fallback()
    _install_smart_standard_scope_fallback()
    _install_degenerate_native_guard(ns)
    _install_run_guard(ns)


def install(ns: dict) -> None:
    apply_all(ns, bpy.context)
