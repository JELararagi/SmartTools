# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Register the complete Smart UV quality and reporting feature surface.

The source tree has always shipped these operators and the explicit native tool
catalog references them, but older bootstrap chains never imported their
modules.  This module provides one deterministic, reversible registration
transaction so every catalog entry is a real RNA operator instead of a dead
button.  It adds no timers, handlers, draw callbacks, threads, or polling.
"""
from __future__ import annotations

from importlib import import_module
from types import ModuleType
from typing import Iterable

try:
    import bpy
except Exception:  # pragma: no cover - Blender-only module
    bpy = None

_MODULE_SPECS: tuple[tuple[str, str], ...] = (
    ("textio", "quality_textio"),
    ("state", "quality_state"),
    ("focus", "quality_focus"),
    ("density", "quality_density"),
    ("sections", "quality_sections"),
    ("presets", "quality_presets"),
    ("sync", "quality_sync"),
    ("controls", "quality_controls"),
    ("housekeeping", "quality_housekeeping"),
    ("context", "quality_context"),
    ("audit", "quality_audit"),
    ("matrix", "quality_matrix"),
    ("catalog", "quality_catalog"),
    ("help", "quality_help"),
    ("language", "quality_language"),
    ("reports", "quality_reports"),
    ("playbook", "quality_playbook"),
    ("profiles", "quality_profiles"),
    ("registry", "quality_registry"),
    ("doctor", "quality_doctor"),
    ("ui_map", "quality_ui_map"),
    ("controls_report", "quality_controls_report"),
    ("parity", "quality_parity"),
)

_MODULES: list[ModuleType] = []
_REGISTERED_CLASSES: list[type] = []
_REGISTERED = False
_TEXT_TRANSLATION: ModuleType | None = None


def _package_name() -> str:
    return str(__package__ or "smart_uv_suite")


def _import_modules(namespace: dict) -> list[ModuleType]:
    modules: list[ModuleType] = []
    package = _package_name()
    for key, module_name in _MODULE_SPECS:
        module = import_module(f"{package}.{module_name}")
        namespace[f"_quality_{key}_module"] = module
        modules.append(module)
    return modules


def _rna_bases() -> tuple[type, ...]:
    if bpy is None:
        return ()
    names = (
        "Operator",
        "Panel",
        "PropertyGroup",
        "Menu",
        "UIList",
        "Header",
        "Gizmo",
        "GizmoGroup",
        "AddonPreferences",
    )
    return tuple(
        base
        for name in names
        for base in (getattr(bpy.types, name, None),)
        if isinstance(base, type)
    )


def _sanitize_module_classes(module: ModuleType) -> None:
    """Localize module-owned RNA classes before their register transaction."""
    global _TEXT_TRANSLATION
    bases = _rna_bases()
    if not bases:
        return
    try:
        if _TEXT_TRANSLATION is None:
            _TEXT_TRANSLATION = import_module(f"{_package_name()}.text_translation")
        sanitize = getattr(_TEXT_TRANSLATION, "sanitize_class", None)
    except Exception:
        sanitize = None
    if not callable(sanitize):
        return
    for value in tuple(vars(module).values()):
        if not isinstance(value, type) or getattr(value, "__module__", "") != module.__name__:
            continue
        try:
            if issubclass(value, bases):
                sanitize(value, context=getattr(bpy, "context", None))
        except Exception:
            continue


def _call_register(module: ModuleType, namespace: dict) -> list[type]:
    _sanitize_module_classes(module)
    register_fn = getattr(module, "register", None)
    if not callable(register_fn):
        return []
    result = register_fn(namespace)
    if not result:
        return []
    return [cls for cls in result if isinstance(cls, type)]


def _call_unregister(module: ModuleType, namespace: dict | None) -> None:
    unregister_fn = getattr(module, "unregister", None)
    if not callable(unregister_fn):
        return
    try:
        unregister_fn(namespace)
    except TypeError:
        unregister_fn()


def _report_namespace(namespace: dict, modules: list[ModuleType]) -> dict:
    # Reporting modules used to share a monolithic namespace.  Bind their
    # dependencies explicitly after the runtime was split into modules.
    result = dict(namespace)
    for module in modules:
        for name, value in vars(module).items():
            if callable(value) and getattr(value, '__module__', '') == module.__name__:
                if name.startswith('scan_') or (name.startswith('_suv_') and name.endswith('_name')):
                    result[name] = value
    package = _package_name()
    for module_name, names in (
        ('ui', ('_suv_ws', '_suv_open_text_in_editor')),
        ('base', ('_suv_load_json_data',)),
        ('flow', ('_suv_external_compat_target_data',)),
    ):
        module = import_module(f'{package}.{module_name}')
        for name in names:
            result[name] = getattr(module, name)
    result['_quality_cards_module'] = import_module(f'{package}.quality_cards')
    return result


def register(namespace: dict) -> tuple[type, ...]:
    """Register every shipped quality/report operator exactly once."""
    global _MODULES, _REGISTERED_CLASSES, _REGISTERED
    if _REGISTERED:
        return tuple(_REGISTERED_CLASSES)
    if bpy is None:
        return ()
    if not isinstance(namespace, dict):
        namespace = {}

    modules = _import_modules(namespace)
    report_namespace = _report_namespace(namespace, modules)
    registered: list[type] = []
    try:
        for (helper_key, _module_name), module in zip(_MODULE_SPECS, modules):
            module_classes = _call_register(module, report_namespace)
            registered.extend(module_classes)
            # Report modules read these per-helper counts from their namespace.
            report_namespace[f"_suv_quality_{helper_key}_registered"] = len(module_classes)
    except Exception:
        # Roll back only the modules that were entered by this transaction.
        for module in reversed(modules):
            try:
                _call_unregister(module, namespace)
            except Exception:
                pass
        raise

    _MODULES = modules
    _REGISTERED_CLASSES = registered
    _REGISTERED = True
    namespace["_suv_quality_runtime_access_registered"] = len(registered)
    namespace["_suv_quality_runtime_access_modules"] = tuple(
        module.__name__ for module in modules
    )
    return tuple(registered)


def unregister(namespace: dict | None = None) -> None:
    """Undo the complete quality/report registration transaction."""
    global _MODULES, _REGISTERED_CLASSES, _REGISTERED, _TEXT_TRANSLATION
    for module in reversed(list(_MODULES)):
        try:
            _call_unregister(module, namespace)
        except Exception:
            pass
    if isinstance(namespace, dict):
        namespace.pop("_suv_quality_runtime_access_registered", None)
        namespace.pop("_suv_quality_runtime_access_modules", None)
        for key, _module_name in _MODULE_SPECS:
            namespace.pop(f"_quality_{key}_module", None)
    _REGISTERED_CLASSES.clear()
    _MODULES.clear()
    _TEXT_TRANSLATION = None
    _REGISTERED = False


def registered_operator_ids() -> tuple[str, ...]:
    ids = []
    for cls in _REGISTERED_CLASSES:
        try:
            op_id = str(getattr(cls, "bl_idname", "") or "")
        except Exception:
            op_id = ""
        if op_id:
            ids.append(op_id)
    return tuple(sorted(set(ids)))
