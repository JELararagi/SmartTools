from . import resource_api_18168 as _suv_resource
import sys

from . import native_stage as _prev
_IGNORE_KEYS = {'__name__','__package__','__loader__','__spec__','__file__','__cached__','__builtins__'}
globals().update({k: v for k, v in _prev.__dict__.items() if k not in _IGNORE_KEYS})
_suv_full_native_stage_draw_suite = getattr(_prev, '_draw_suite', None)
from .context_guard import smart_uv_context_is_draw_ready, smart_uv_safe_draw_fallback, smart_uv_root_panel_poll, smart_uv_panel_poll

_SUV_KEYMAP_ITEMS = []
_SUV_REGISTER_CLASS_FAILURES = []
_SUV_KEYMAP_BINDINGS = (
    ('Image Generic', 'IMAGE_EDITOR'),
    ('3D View Generic', 'VIEW_3D'),
)
_SUV_AUTOREGISTER_KEYMAPS = False
_SUV_EMPTY_KEYMAP_CANDIDATES = {
    'Image Generic',
    '3D View Generic',
    'Window',
    'UV Editor',
    'Object Mode',
    'Mesh',
}

# ============================================================
# Runtime guard patch layer (v5.1.0)
# ============================================================

def _suv_result_has(result, token: str) -> bool:
    try:
        if '_suv_result_status_set' in globals():
            status = _suv_result_status_set(result)
            if token in status:
                return True
        if isinstance(result, dict):
            status = result.get('status', None)
            if isinstance(status, set):
                return token in status
            if isinstance(status, (list, tuple)):
                return token in {str(v) for v in status if v is not None}
            if isinstance(status, str):
                return token == status
        try:
            return token in set(result)
        except Exception:
            try:
                return token in result
            except Exception:
                return False
    except Exception:
        return False


def _suv_mesh_name_list(objs):
    out = []
    for obj in objs or []:
        try:
            out.append(obj.name)
        except Exception:
            pass
    return out


def _suv_issue_cache_total(context):
    total = 0
    for key in ('inspect_flipped', 'inspect_zero', 'inspect_out', 'inspect_stretch'):
        try:
            total += len(_cache_get(context.scene, key, []))
        except Exception:
            pass
    try:
        total += len(_cache_get(context.scene, 'inspect_overlap', []))
    except Exception:
        pass
    return total


def _suv_precheck_active_mesh(context):
    obj = _active_mesh_obj(context)
    if obj is None:
        return False, tr(context, 'msg.no_active_mesh'), {'active_mesh': '-'}
    return True, '', {'active_mesh': obj.name}


def _suv_precheck_mesh_targets(context):
    objs = _selected_mesh_objects(context)
    if not objs:
        obj = _active_mesh_obj(context)
        objs = [obj] if obj else []
    objs = [obj for obj in objs if obj is not None and getattr(obj, 'type', None) == 'MESH']
    if not objs:
        return False, tr(context, 'msg.no_active_mesh'), {'target_meshes': []}
    return True, '', {'target_meshes': _suv_mesh_name_list(objs)}


def _suv_precheck_scan_results(context):
    ws = _suv_ws(context)
    total = _suv_issue_cache_total(context)
    has_result = bool(ws and getattr(ws, 'scan_has_result', False))
    if not has_result and total == 0:
        msg = 'No previous scan data'
        return False, msg, {'scan_has_result': False, 'issue_cache_total': total}
    return True, '', {'scan_has_result': has_result, 'issue_cache_total': total}


def _suv_guard_wrap_execute(cls, source: str, *, preserve=False, restore_render=False, precheck=None, detail_getter=None, guard_mode='explicit', log_success=True):
    if cls is None or not callable(getattr(cls, 'execute', None)):
        return False
    if bool(getattr(cls, '_suv_guard_wrapped', False)):
        return False
    original = cls.execute
    def wrapped(self, context):
        details = {}
        try:
            if detail_getter:
                extra = detail_getter(self, context) or {}
                if isinstance(extra, dict):
                    details.update(extra)
        except Exception:
            pass
        if log_success:
            _suv_log_event(context, 'INFO', source, 'Started', details or None)
        if precheck is not None:
            ok, message, extra = precheck(context)
            if isinstance(extra, dict):
                payload = dict(details)
                payload.update(extra)
            else:
                payload = details or None
            if not ok:
                _suv_log_event(context, 'WARN', source, message, payload)
                self.report({'WARNING'}, message)
                return {'CANCELLED'}
            if isinstance(extra, dict):
                details.update(extra)
        try:
            if preserve:
                with _PreserveContextState(context, restore_mode=True, restore_render_engine=restore_render):
                    result = original(self, context)
            else:
                result = original(self, context)
        except Exception as exc:
            _suv_log_exception(context, source, exc, details)
            self.report({'ERROR'}, tr(context, 'msg.op_failed', e=exc))
            return {'CANCELLED'}
        payload = dict(details)
        payload['result'] = sorted(list(result)) if isinstance(result, set) else str(result)
        if _suv_result_has(result, 'CANCELLED'):
            _suv_log_event(context, 'WARN', source, 'Cancelled', payload)
        elif log_success:
            _suv_log_event(context, 'INFO', source, 'Finished', payload)
        return result
    wrapped._suv_guard_wrapped = True
    wrapped._suv_guard_mode = str(guard_mode or 'explicit')
    wrapped._suv_guard_source = str(source or getattr(cls, 'bl_label', cls.__name__))
    cls.execute = wrapped
    cls._suv_guard_wrapped = True
    cls._suv_guard_mode = str(guard_mode or 'explicit')
    cls._suv_guard_source = str(source or getattr(cls, 'bl_label', cls.__name__))
    cls._suv_guard_precheck = getattr(precheck, '__name__', '') if callable(precheck) else ''
    cls._suv_guard_preserve = bool(preserve)
    return True


def _suv_guess_guard_precheck(cls):
    text = ' '.join([
        str(getattr(cls, 'bl_idname', '') or ''),
        str(getattr(cls, 'bl_label', '') or ''),
        str(getattr(cls, 'bl_description', '') or ''),
        str(getattr(cls, '__name__', '') or ''),
    ]).lower()
    if any(token in text for token in (
        'write ', ' open ', 'open_', 'write_', 'report', 'catalog', 'registry', 'notebook',
        'validation', 'glossary', 'advisor', 'readiness', 'stability', 'session', 'circuit',
        'confidence', 'admission', 'copy', 'collect', 'clear', 'reset', 'language', 'ui map',
        'report hub', 'playbook', 'controls', 'doctor', 'parity', 'summary', 'help',
    )):
        return None
    if any(token in text for token in (
        'batch', 'multi', 'transfer', 'atlas', 'bake', 'checker', 'uvmap', 'hair', 'workflow_hub',
    )):
        return _suv_precheck_mesh_targets
    if any(token in text for token in (
        'uv', 'pack', 'unwrap', 'unfold', 'relax', 'seam', 'stitch', 'stack', 'layout', 'align',
        'orient', 'symmetry', 'trim', 'hotspot', 'density', 'texel', 'projection', 'inspect',
        'issue', 'audit', 'overlay', 'candidate', 'similarity', 'grid', 'rectify', 'straight',
        'flow', 'brush', 'lattice', 'planar', 'peel', 'flatten', 'tile', 'native stage',
    )):
        return _suv_precheck_active_mesh
    return None


def _suv_auto_guard_namespace_operators(namespace=None):
    ns = namespace if isinstance(namespace, dict) else globals()
    summary = {
        'total_execute_classes': 0,
        'guarded': 0,
        'explicit': 0,
        'auto': 0,
        'missing': 0,
        'auto_wrapped': 0,
        'missing_classes': [],
    }
    for name in sorted(ns.keys()):
        value = ns.get(name)
        if not (name.startswith('SUV_OT_') and isinstance(value, type)):
            continue
        execute = getattr(value, 'execute', None)
        if not callable(execute):
            continue
        summary['total_execute_classes'] += 1
        if bool(getattr(value, '_suv_guard_wrapped', False)):
            summary['guarded'] += 1
            if str(getattr(value, '_suv_guard_mode', '') or '').lower() == 'auto':
                summary['auto'] += 1
            else:
                summary['explicit'] += 1
            continue
        precheck = _suv_guess_guard_precheck(value)
        preserve = precheck is not None
        source = str(getattr(value, 'bl_label', '') or name)
        if _suv_guard_wrap_execute(value, source, preserve=preserve, precheck=precheck, guard_mode='auto'):
            summary['guarded'] += 1
            summary['auto'] += 1
            summary['auto_wrapped'] += 1
        else:
            summary['missing'] += 1
            summary['missing_classes'].append(name)
    summary['missing'] = len(summary['missing_classes'])
    return summary


def _suv_tool_runtime_guard_summary(namespace=None):
    ns = namespace if isinstance(namespace, dict) else globals()
    summary = {
        'total_execute_classes': 0,
        'guarded': 0,
        'explicit': 0,
        'auto': 0,
        'missing': 0,
        'missing_classes': [],
    }
    for name in sorted(ns.keys()):
        value = ns.get(name)
        if not (name.startswith('SUV_OT_') and isinstance(value, type)):
            continue
        execute = getattr(value, 'execute', None)
        if not callable(execute):
            continue
        summary['total_execute_classes'] += 1
        guarded = bool(getattr(value, '_suv_guard_wrapped', False) or getattr(execute, '_suv_guard_wrapped', False) or getattr(value, '_suv_safe_execute', False))
        if guarded:
            summary['guarded'] += 1
            mode = str(getattr(value, '_suv_guard_mode', getattr(execute, '_suv_guard_mode', '')) or '').lower()
            if mode == 'auto':
                summary['auto'] += 1
            else:
                summary['explicit'] += 1
        else:
            summary['missing_classes'].append(name)
    summary['missing'] = len(summary['missing_classes'])
    return summary


def _suv_poll_active_mesh(cls, context):
    return _active_mesh_obj(context) is not None


def _suv_poll_any_mesh(cls, context):
    return _active_mesh_obj(context) is not None or bool(_selected_mesh_objects(context))



def _suv_precheck_active_uv(context):
    obj = _active_mesh_obj(context)
    if obj is None:
        return False, tr(context, 'msg.no_active_mesh'), {'active_mesh': '-'}
    uv = None
    try:
        uv = obj.data.uv_layers.active if getattr(obj, 'data', None) and hasattr(obj.data, 'uv_layers') else None
    except Exception:
        uv = None
    if uv is None:
        return False, 'No active UV map', {'active_mesh': obj.name, 'active_uv': '-'}
    return True, '', {'active_mesh': obj.name, 'active_uv': getattr(uv, 'name', '')}


def _suv_detail_selection(self, context):
    return {
        'extend': getattr(self, 'extend', None),
        'include_seams': getattr(self, 'include_seams', None),
        'area_tol': getattr(self, 'area_tol', None),
        'aspect_tol': getattr(self, 'aspect_tol', None),
    }


def _suv_detail_uvmap(self, context):
    ws = _suv_ws(context)
    return {
        'active_mesh': getattr(_active_mesh_obj(context), 'name', '-'),
        'target_meshes': _suv_mesh_name_list(_selected_mesh_objects(context)),
        'uv_new_name': getattr(ws, 'uv_new_name', 'UVMap_SUV') if ws else 'UVMap_SUV',
    }


def _suv_detail_transform(self, context):
    return {
        'axis': getattr(self, 'axis', ''),
        'mode': getattr(self, 'mode', ''),
        'scope': getattr(self, 'scope', ''),
        'group_mode': getattr(self, 'group_mode', ''),
        'layout_mode': getattr(self, 'layout_mode', ''),
        'angle_rad': getattr(self, 'angle_rad', None),
        'direction': getattr(self, 'direction', ''),
        'amount': getattr(self, 'amount', None),
        'even_distribution': getattr(self, 'even_distribution', None),
        'pin_selected': getattr(self, 'pin_selected', None),
        'clear_all': getattr(self, 'clear_all', None),
    }


def _suv_detail_auto_unwrap(self, context):
    return {
        'angle_threshold': getattr(self, 'angle_threshold', None),
        'do_seams': getattr(self, 'do_seams', None),
        'do_unwrap': getattr(self, 'do_unwrap', None),
        'do_relax': getattr(self, 'do_relax', None),
        'do_pack': getattr(self, 'do_pack', None),
        'do_qa': getattr(self, 'do_qa', None),
        'pack_engine': getattr(self, 'pack_engine', ''),
        'pack_udim_mode': getattr(self, 'pack_udim_mode', ''),
        'pack_margin_px': getattr(self, 'pack_margin_px', None),
        'texture_size': getattr(self, 'texture_size', None),
        'pack_rotation_step': getattr(self, 'pack_rotation_step', ''),
    }


def _suv_detail_seam(self, context):
    return {
        'angle_threshold': getattr(self, 'angle_threshold', None),
        'mode': getattr(self, 'mode', ''),
        'scope': getattr(self, 'scope', ''),
        'iterations': getattr(self, 'iterations', None),
        'include_cross': getattr(self, 'include_cross', None),
        'anchor_mode': getattr(self, 'anchor_mode', ''),
        'preserve_position': getattr(self, 'preserve_position', None),
        'preserve_scale': getattr(self, 'preserve_scale', None),
        'preserve_rotation': getattr(self, 'preserve_rotation', None),
        'temporary_anchors': getattr(self, 'temporary_anchors', None),
    }


def _suv_detail_native_projection(self, context):
    return {
        'mode': getattr(self, 'mode', ''),
        'angle_limit': getattr(self, 'angle_limit', None),
        'island_margin': getattr(self, 'island_margin', None),
        'follow_mode': getattr(self, 'follow_mode', ''),
        'relax_after': getattr(self, 'relax_after', None),
        'pack_after': getattr(self, 'pack_after', None),
        'normalize_td_after': getattr(self, 'normalize_td_after', None),
    }


def _suv_detail_native_action(self, context):
    return {
        'mode': getattr(self, 'mode', ''),
        'use_limit': getattr(self, 'use_limit', None),
        'snap_islands': getattr(self, 'snap_islands', None),
        'limit': getattr(self, 'limit', None),
    }

def _suv_detail_match_active_preserve(self, context):
    return {
        'mode': getattr(self, 'mode', ''),
        'preserve_anchor': getattr(self, 'preserve_anchor', ''),
        'keep_tile': getattr(self, 'keep_tile', None),
        'preserve_area': getattr(self, 'preserve_area', None),
        'allow_mirror': getattr(self, 'allow_mirror', None),
        'uniform_scale': getattr(self, 'uniform_scale', None),
        'max_matches': getattr(self, 'max_matches', None),
        'score_threshold': getattr(self, 'score_threshold', None),
    }


def _suv_detail_match_stitch_active_preserve(self, context):
    return {
        'mode': getattr(self, 'mode', ''),
        'preserve_anchor': getattr(self, 'preserve_anchor', ''),
        'keep_tile': getattr(self, 'keep_tile', None),
        'preserve_area': getattr(self, 'preserve_area', None),
        'allow_mirror': getattr(self, 'allow_mirror', None),
        'uniform_scale': getattr(self, 'uniform_scale', None),
        'native_stitch': getattr(self, 'native_stitch', None),
        'native_weld': getattr(self, 'native_weld', None),
        'stitch_use_limit': getattr(self, 'stitch_use_limit', None),
        'stitch_snap_islands': getattr(self, 'stitch_snap_islands', None),
        'max_matches': getattr(self, 'max_matches', None),
        'score_threshold': getattr(self, 'score_threshold', None),
    }


def _suv_detail_symmetry(self, context):
    return {
        'axis': getattr(self, 'axis', ''),
        'space': getattr(self, 'space', ''),
        'offset': getattr(self, 'offset', None),
        'tolerance': getattr(self, 'tolerance', None),
        'mode': getattr(self, 'mode', ''),
        'mirror_uv_axis': getattr(self, 'mirror_uv_axis', ''),
        'rotation_step': getattr(self, 'rotation_step', ''),
        'allow_mirror': getattr(self, 'allow_mirror', None),
        'include_cross': getattr(self, 'include_cross', None),
    }


def _suv_detail_pack(self, context):
    return {
        'engine': getattr(self, 'engine', ''),
        'scope': getattr(self, 'scope', ''),
        'udim_mode': getattr(self, 'udim_mode', ''),
        'group_mode': getattr(self, 'group_mode', ''),
        'group_layout': getattr(self, 'group_layout', ''),
        'group_sort': getattr(self, 'group_sort', ''),
        'start_tile_u': getattr(self, 'start_tile_u', None),
        'start_tile_v': getattr(self, 'start_tile_v', None),
        'tile_columns': getattr(self, 'tile_columns', None),
        'tile_fill': getattr(self, 'tile_fill', ''),
        'stack_identical_groups': getattr(self, 'stack_identical_groups', None),
    }


def _suv_detail_hotspot(self, context):
    return {
        'cols': getattr(self, 'cols', 0),
        'rows': getattr(self, 'rows', 0),
        'keep_aspect': getattr(self, 'keep_aspect', False),
        'sort_mode': getattr(self, 'sort_mode', ''),
        'fill_order': getattr(self, 'fill_order', ''),
    }


def _suv_detail_group(self, context):
    return {
        'mode': getattr(self, 'mode', ''),
        'scope': getattr(self, 'scope', ''),
        'rotation_step': getattr(self, 'rotation_step', ''),
    }


def _suv_detail_heatmap(self, context):
    return {
        'attr_name': getattr(self, 'attr_name', ''),
        'material_name': getattr(self, 'material_name', ''),
        'max_score': getattr(self, 'max_score', ''),
    }


def _suv_detail_report(self, context):
    ws = _suv_ws(context)
    return {
        'report_name': getattr(ws, 'scan_report_name', 'SUV_Scan_Report') if ws else 'SUV_Scan_Report',
        'issue_cache_total': _suv_issue_cache_total(context),
    }

def _suv_detail_texel(self, context):
    return {
        'scope': getattr(self, 'scope', ''),
        'mode': getattr(self, 'mode', ''),
        'texture_size': getattr(self, 'texture_size', None),
        'use_world_scale': getattr(self, 'use_world_scale', None),
        'target_density': getattr(self, 'target_density', None),
        'value_density': getattr(self, 'value_density', None),
        'skip_pinned': getattr(self, 'skip_pinned', None),
        'keep_tile': getattr(self, 'keep_tile', None),
        'last_density': _cache_get(context.scene, 'last_density', None),
    }


def _suv_detail_repair(self, context):
    return {
        'eps': getattr(self, 'eps', None),
        'active_mesh': getattr(_active_mesh_obj(context), 'name', '-'),
    }


def _suv_detail_sets(self, context):
    obj = _active_mesh_obj(context)
    d = _get_sets(obj) if obj else {}
    return {
        'set_name': getattr(self, 'set_name', ''),
        'apply_mode': getattr(self, 'apply_mode', ''),
        'overwrite': getattr(self, 'overwrite', None),
        'set_count': len(d) if isinstance(d, dict) else 0,
        'active_mesh': getattr(obj, 'name', '-'),
    }


def _suv_detail_seam_sets(self, context):
    obj = _active_mesh_obj(context)
    d = _get_seam_sets(obj) if obj else {}
    return {
        'set_name': getattr(self, 'set_name', ''),
        'apply_mode': getattr(self, 'apply_mode', ''),
        'overwrite': getattr(self, 'overwrite', None),
        'set_count': len(d) if isinstance(d, dict) else 0,
        'active_mesh': getattr(obj, 'name', '-'),
        'selected_only': getattr(self, 'selected_only', None),
        'apply_seams': getattr(self, 'apply_seams', None),
    }


def _suv_detail_layout_sets(self, context):
    obj = _active_mesh_obj(context)
    d = _get_layout_sets(obj) if obj else {}
    return {
        'set_name': getattr(self, 'set_name', ''),
        'overwrite': getattr(self, 'overwrite', None),
        'set_count': len(d) if isinstance(d, dict) else 0,
        'active_mesh': getattr(obj, 'name', '-'),
        'source_layer_mode': getattr(self, 'source_layer_mode', ''),
        'source_layer_name': getattr(self, 'source_layer_name', ''),
        'target_layer_mode': getattr(self, 'target_layer_mode', ''),
        'target_layer_name': getattr(self, 'target_layer_name', ''),
        'apply_layout': getattr(self, 'apply_layout', None),
    }


def _suv_detail_layout_preset(self, context):
    return {
        'preset': getattr(self, 'preset', ''),
        'library': getattr(self, 'library', ''),
        'axis': getattr(self, 'axis', ''),
        'scope': getattr(self, 'scope', ''),
        'padding_px': getattr(self, 'padding_px', None),
        'texture_size': getattr(self, 'texture_size', None),
        'keep_tile': getattr(self, 'keep_tile', None),
    }


def _suv_detail_stack_basic(self, context):
    return {
        'rotation_step': getattr(self, 'rotation_step', ''),
        'allow_mirror': getattr(self, 'allow_mirror', None),
    }


def _suv_detail_hardsurface(self, context):
    return {
        'scope': getattr(self, 'scope', ''),
        'step_deg': getattr(self, 'step_deg', None),
        'merge_factor': getattr(self, 'merge_factor', None),
        'keep_tile': getattr(self, 'keep_tile', None),
        'padding_px': getattr(self, 'padding_px', None),
        'texture_size': getattr(self, 'texture_size', None),
        'follow_mode': getattr(self, 'follow_mode', ''),
        'fit_after': getattr(self, 'fit_after', None),
    }


def _suv_detail_udim(self, context):
    return {
        'direction': getattr(self, 'direction', ''),
        'step': getattr(self, 'step', None),
        'scope': getattr(self, 'scope', ''),
    }


def _suv_detail_workspace_maintenance(self, context):
    ws = _suv_ws(context)
    return {
        'workspace_mode': getattr(ws, 'workspace_mode', '') if ws else '',
        'tool_tab': getattr(ws, 'tool_tab', '') if ws else '',
        'tool_runtime_log_name': _suv_tool_runtime_log_name(context),
        'snapshot_name': getattr(ws, 'snapshot_text_name', 'SUV_Runtime_Snapshot') if ws else 'SUV_Runtime_Snapshot',
        'icon_count': _suv_loaded_icon_count(),
        'scan_has_result': getattr(ws, 'scan_has_result', False) if ws else False,
    }


def _suv_detail_workspace_repair(self, context):
    data = _suv_detail_workspace_maintenance(self, context)
    data.update({
        'create_missing_uv': getattr(self, 'create_missing_uv', None),
        'clear_scan_cache': getattr(self, 'clear_scan_cache', None),
        'reload_icons': getattr(self, 'reload_icons', None),
        'repair_settings': getattr(self, 'repair_settings', None),
    })
    return data


def _suv_detail_workspace_preset(self, context):
    ws = _suv_ws(context)
    return {
        'preset': getattr(self, 'preset', ''),
        'workspace_mode_before': getattr(ws, 'workspace_mode', '') if ws else '',
        'tool_tab_before': getattr(ws, 'tool_tab', '') if ws else '',
        'line_mode': getattr(ws, 'line_mode', '') if ws else '',
        'layout_mode': getattr(ws, 'layout_mode', '') if ws else '',
    }


SUV_OT_pack_pro.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_unstack_groups.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_stack_grouped.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_groups_to_tiles.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_group_normalize_layout.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_priority_density_pack.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_layout_autoheal.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_density_guard_normalize.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_hotspot_grid_layout.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_hotspot_cell_tools.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_hotspot_cell_refill.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_trim_band_refill.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_layout_audit_relayout.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_visualize_stretch_heatmap.poll = classmethod(_suv_poll_any_mesh)
SUV_OT_clear_stretch_heatmap.poll = classmethod(_suv_poll_any_mesh)
SUV_OT_inspector_select_all.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_inspector_write_report.poll = classmethod(_suv_poll_any_mesh)
SUV_OT_create_checker_material.poll = classmethod(_suv_poll_any_mesh)

_suv_guard_wrap_execute(SUV_OT_pack_pro, 'Pack Pro', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_pack)
_suv_guard_wrap_execute(SUV_OT_stack_grouped, 'Stack Grouped Islands', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_group)
_suv_guard_wrap_execute(SUV_OT_groups_to_tiles, 'Move Groups to Tiles', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_group)
_suv_guard_wrap_execute(SUV_OT_group_normalize_layout, 'Normalize Groups', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'mode': getattr(self, 'mode', ''), 'measure': getattr(self, 'measure', ''), 'target_mode': getattr(self, 'target_mode', ''), 'scope': getattr(self, 'scope', '')})
_suv_guard_wrap_execute(SUV_OT_priority_density_pack, 'Priority Density Pack', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'scope': getattr(self, 'scope', ''), 'group_mode': getattr(self, 'group_mode', ''), 'tier_mode': getattr(self, 'tier_mode', ''), 'hero_count': getattr(self, 'hero_count', 0), 'secondary_count': getattr(self, 'secondary_count', 0)})
_suv_guard_wrap_execute(SUV_OT_layout_autoheal, 'Auto Heal Layout', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'scope': getattr(self, 'scope', ''), 'group_mode': getattr(self, 'group_mode', ''), 'fix_overlap': getattr(self, 'fix_overlap', False), 'fix_cross_tile': getattr(self, 'fix_cross_tile', False), 'repack_profile': getattr(self, 'repack_profile', ''), 'reuse_first': getattr(self, 'reuse_first', False), 'density_guard': getattr(self, 'density_guard', False)})
_suv_guard_wrap_execute(SUV_OT_density_guard_normalize, 'Normalize with Density Guard', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'scope': getattr(self, 'scope', ''), 'group_mode': getattr(self, 'group_mode', ''), 'target_mode': getattr(self, 'target_mode', ''), 'protect_top_n': getattr(self, 'protect_top_n', 0)})
_suv_guard_wrap_execute(SUV_OT_hotspot_grid_layout, 'Layout Hotspot Grid', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_hotspot)
_suv_guard_wrap_execute(SUV_OT_hotspot_cell_tools, 'Hotspot Cell Tools', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_hotspot)
_suv_guard_wrap_execute(SUV_OT_hotspot_cell_refill, 'Refill Hotspot Cells', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_hotspot)
_suv_guard_wrap_execute(SUV_OT_trim_band_refill, 'Refill Trim Band', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'scope': getattr(self, 'scope', ''), 'group_mode': getattr(self, 'group_mode', ''), 'axis': getattr(self, 'axis', ''), 'band_count': getattr(self, 'band_count', None), 'priority_mode': getattr(self, 'priority_mode', ''), 'reserve_top_n': getattr(self, 'reserve_top_n', 0)})
_suv_guard_wrap_execute(SUV_OT_visualize_stretch_heatmap, 'Build Stretch Heatmap', preserve=True, precheck=_suv_precheck_mesh_targets, detail_getter=_suv_detail_heatmap)
_suv_guard_wrap_execute(SUV_OT_clear_stretch_heatmap, 'Clear Stretch Heatmap', preserve=True, precheck=_suv_precheck_mesh_targets, detail_getter=lambda self, context: {'attr_name': getattr(self, 'attr_name', '')})
_suv_guard_wrap_execute(SUV_OT_create_checker_material, 'Create Checker Material', preserve=True, precheck=_suv_precheck_mesh_targets, detail_getter=lambda self, context: {'canvas_size': getattr(_suv_ws(context), 'canvas_size', 2048) if _suv_ws(context) else 2048})
_suv_guard_wrap_execute(SUV_OT_inspector_select_all, 'Inspector Select All', preserve=True, precheck=_suv_precheck_scan_results, detail_getter=lambda self, context: {'apply_mode': getattr(self, 'apply_mode', ''), 'issue_cache_total': _suv_issue_cache_total(context)})
_suv_guard_wrap_execute(SUV_OT_inspector_write_report, 'Inspector Write Report', preserve=False, precheck=_suv_precheck_scan_results, detail_getter=_suv_detail_report)

SUV_OT_select_island_active.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_select_similar_islands.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_select_identical_islands.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_select_uv_boundary.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_select_fragmented_islands.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_select_zero_islands.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_sort_islands.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_uvmap_set_active.poll = classmethod(_suv_poll_any_mesh)
SUV_OT_bake_uv_prep.poll = classmethod(_suv_poll_any_mesh)
SUV_OT_uvmap_rename_active.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_remove_checker_materials.poll = classmethod(_suv_poll_any_mesh)
SUV_OT_uv_issue_overlay_tools.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_uvmap_add.poll = classmethod(_suv_poll_any_mesh)
SUV_OT_uvmap_duplicate.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_uvmap_remove.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_uv_straight_line.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_uv_annotate_align.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_uv_set_flow.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_align_islands.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_centralize_islands.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_orient_to_edge.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_distribute_islands.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_fit_to_bounds.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_rotate_islands.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_flip_islands.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_orient_islands.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_randomize_islands.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_clear_pins.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_clear_seams.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_uv_edit_compat_tools.poll = classmethod(_suv_poll_active_mesh)

_suv_guard_wrap_execute(SUV_OT_select_island_active, 'Select Island Active', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_selection)
_suv_guard_wrap_execute(SUV_OT_select_similar_islands, 'Select Similar Islands', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_selection)
_suv_guard_wrap_execute(SUV_OT_select_identical_islands, 'Select Identical Islands', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_selection)
_suv_guard_wrap_execute(SUV_OT_select_uv_boundary, 'Select UV Boundary', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_selection)
_suv_guard_wrap_execute(SUV_OT_select_fragmented_islands, 'Select Fragmented Islands', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_selection)
_suv_guard_wrap_execute(SUV_OT_select_zero_islands, 'Select Zero Islands', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_selection)
_suv_guard_wrap_execute(SUV_OT_sort_islands, 'Sort Islands', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_uv_crop_tile, 'Crop to Tile', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_uv_fill_tile, 'Fill Tile', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_uvmap_set_active, 'UV Map Set Active', preserve=True, precheck=_suv_precheck_mesh_targets, detail_getter=_suv_detail_uvmap)
_suv_guard_wrap_execute(SUV_OT_bake_uv_prep, 'Bake UV Prep', preserve=True, precheck=_suv_precheck_mesh_targets, detail_getter=lambda self, context: {'prep_mode': getattr(self, 'prep_mode', ''), 'target_name': getattr(self, 'target_name', ''), 'source_mode': getattr(self, 'source_mode', ''), 'source_name': getattr(self, 'source_name', ''), 'replace_existing_payload': getattr(self, 'replace_existing_payload', None), 'set_active_target': getattr(self, 'set_active_target', None), 'set_render_target': getattr(self, 'set_render_target', None)})
_suv_guard_wrap_execute(SUV_OT_uvmap_set_render, 'UV Map Set Render', preserve=True, precheck=_suv_precheck_mesh_targets, detail_getter=_suv_detail_uvmap)
_suv_guard_wrap_execute(SUV_OT_uvmap_rename_active, 'UV Map Rename Active', preserve=True, precheck=_suv_precheck_active_uv, detail_getter=_suv_detail_uvmap)
_suv_guard_wrap_execute(SUV_OT_uvmap_reorder, 'UV Map Reorder', preserve=True, precheck=_suv_precheck_mesh_targets, detail_getter=_suv_detail_uvmap)
_suv_guard_wrap_execute(SUV_OT_remove_checker_materials, 'Remove Checker Materials', preserve=True, precheck=_suv_precheck_mesh_targets, detail_getter=lambda self, context: {'purge_data': getattr(self, 'purge_data', False)})
_suv_guard_wrap_execute(SUV_OT_uvmap_add, 'UV Map Add', preserve=True, precheck=_suv_precheck_mesh_targets, detail_getter=_suv_detail_uvmap)
_suv_guard_wrap_execute(SUV_OT_uvmap_duplicate, 'UV Map Duplicate', preserve=True, precheck=_suv_precheck_mesh_targets, detail_getter=_suv_detail_uvmap)
_suv_guard_wrap_execute(SUV_OT_uvmap_remove, 'UV Map Remove', preserve=True, precheck=_suv_precheck_active_uv, detail_getter=_suv_detail_uvmap)
_suv_guard_wrap_execute(SUV_OT_uv_straight_line, 'Straighten Line', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_uv_annotate_align, 'Annotate Align', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_uv_set_flow, 'Set UV Flow', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_align_islands, 'Align Islands', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_centralize_islands, 'Centralize Islands', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_orient_to_edge, 'Orient To Edge', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_distribute_islands, 'Distribute Islands', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_fit_to_bounds, 'Fit To Bounds', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_rotate_islands, 'Rotate Islands', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_flip_islands, 'Flip Islands', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_orient_islands, 'Orient Islands', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_randomize_islands, 'Randomize Islands', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_clear_pins, 'Clear Pins', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_clear_seams, 'Clear Seams', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_uv_edit_compat_tools, 'UV Edit Compatibility Tools', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'mode': getattr(self, 'mode', ''), 'scope': getattr(self, 'scope', ''), 'offset_u': getattr(self, 'offset_u', None), 'offset_v': getattr(self, 'offset_v', None)})

SUV_OT_smart_seams.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_smart_tube.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_smart_relax.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_smart_edge_straighten.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_smart_rectify.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_auto_uv_profile.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_auto_unwrap_pro.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_auto_seam_advanced.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_native_projection.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_native_uv_action.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_sym_detect_pairs.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_sym_mirror_uv.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_sym_seams.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_sym_stack.poll = classmethod(_suv_poll_active_mesh)

_suv_guard_wrap_execute(SUV_OT_smart_seams, 'Smart Seams', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_seam)
_suv_guard_wrap_execute(SUV_OT_smart_tube, 'Smart Tube', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'projection': 'CYLINDER_VIEW_EQUATOR'})
_suv_guard_wrap_execute(SUV_OT_smart_relax, 'Smart Relax', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_seam)
_suv_guard_wrap_execute(SUV_OT_smart_edge_straighten, 'Smart Edge Straighten', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_smart_rectify, 'Smart Rectify', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_auto_uv_profile, 'Auto UV Profile', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'profile': getattr(self, 'profile', '')})
_suv_guard_wrap_execute(SUV_OT_auto_unwrap_pro, 'Auto Unwrap Pro', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_auto_unwrap)
_suv_guard_wrap_execute(SUV_OT_auto_seam_advanced, 'Auto Mark Advanced Seams', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_seam)
_suv_guard_wrap_execute(SUV_OT_batch_apply_seam_profile, 'Batch Apply Seam Profile', preserve=False, precheck=_suv_precheck_mesh_targets, detail_getter=lambda self, context: {'profile': getattr(self, 'profile', ''), 'target_mode': getattr(self, 'target_mode', ''), 'scope_override': getattr(self, 'scope_override', ''), 'clear_override': getattr(self, 'clear_override', ''), 'select_processed': getattr(self, 'select_processed', False)})
_suv_guard_wrap_execute(SUV_OT_native_projection, 'Run Core Projection', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_native_projection)
_suv_guard_wrap_execute(SUV_OT_native_uv_action, 'Core UV Action', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_native_action)
_suv_guard_wrap_execute(SUV_OT_sym_detect_pairs, 'Detect Symmetry Pairs', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_symmetry)
_suv_guard_wrap_execute(SUV_OT_sym_mirror_uv, 'Mirror UV (Ref -> Pair)', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_symmetry)
_suv_guard_wrap_execute(SUV_OT_sym_seams, 'Symmetry Seams', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_symmetry)
_suv_guard_wrap_execute(SUV_OT_sym_stack, 'Symmetry Stack', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_symmetry)

SUV_OT_smart_3d_transfer.poll = classmethod(_suv_poll_any_mesh)
SUV_OT_repair_flipped_islands.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_stack_pro.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_texel_get.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_texel_set.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_texel_normalize.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_inspector_select.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_inspector_fix_flipped.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_inspector_rescan.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_inspector_clear_cache.poll = classmethod(_suv_poll_any_mesh)
SUV_OT_fix_all_issues.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_set_save.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_set_recall.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_set_update.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_set_delete.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_set_transfer.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_set_library_io.poll = classmethod(lambda cls, context: True)
SUV_OT_seam_set_save.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_seam_set_recall.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_seam_set_update.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_seam_set_delete.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_seam_set_transfer.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_seam_set_library_io.poll = classmethod(lambda cls, context: True)
SUV_OT_layout_set_save.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_layout_set_recall.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_layout_set_update.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_layout_set_delete.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_layout_set_transfer.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_layout_set_library_io.poll = classmethod(lambda cls, context: True)
SUV_OT_select_udim_crossing.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_apply_hotspot_preset.poll = classmethod(_suv_poll_any_mesh)
SUV_OT_apply_named_layout_library.poll = classmethod(_suv_poll_any_mesh)
SUV_OT_hs_orthogonalize.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_hs_gridify.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_hs_squareify.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_hs_rectify_fit.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_hs_rectify_constrained.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_hs_quad_flow.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_trim_strip_layout.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_trim_band_layout.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_external_layout_profile.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_group_normalize_layout.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_udim_step.poll = classmethod(_suv_poll_active_mesh)

_suv_guard_wrap_execute(SUV_OT_smart_3d_transfer, '3D Smart Transfer', preserve=True, precheck=_suv_precheck_mesh_targets, detail_getter=lambda self, context: {'target_meshes': _suv_mesh_name_list(_selected_mesh_objects(context))})
_suv_guard_wrap_execute(SUV_OT_repair_flipped_islands, 'Repair Flipped Islands', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_repair)
_suv_guard_wrap_execute(SUV_OT_stack_pro, 'Stack Pro', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_stack_basic)
_suv_guard_wrap_execute(SUV_OT_texel_get, 'Texel Get', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_texel)
_suv_guard_wrap_execute(SUV_OT_texel_set, 'Texel Set', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_texel)
_suv_guard_wrap_execute(SUV_OT_texel_normalize, 'Texel Normalize', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_texel)
_suv_guard_wrap_execute(SUV_OT_inspector_select, 'Inspector Select', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'issue': getattr(self, 'issue', ''), 'auto_scan': getattr(self, 'auto_scan', False), 'scan_scope': getattr(self, 'scan_scope', ''), 'issue_cache_total': _suv_issue_cache_total(context)})
_suv_guard_wrap_execute(SUV_OT_inspector_fix_flipped, 'Inspector Fix Flipped', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'eps': getattr(self, 'eps', None)})
_suv_guard_wrap_execute(SUV_OT_inspector_rescan, 'Inspector Rescan', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'precise_overlap': getattr(_suv_ws(context), 'scan_precise_overlap', None) if _suv_ws(context) else None})
_suv_guard_wrap_execute(SUV_OT_inspector_clear_cache, 'Inspector Clear Cache', preserve=False, precheck=_suv_precheck_mesh_targets, detail_getter=lambda self, context: {'issue_cache_total': _suv_issue_cache_total(context)})
_suv_guard_wrap_execute(SUV_OT_fix_all_issues, 'Fix All Issues', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'scan_has_result': getattr(_suv_ws(context), 'scan_has_result', False) if _suv_ws(context) else False})
_suv_guard_wrap_execute(SUV_OT_set_save, 'Set Save', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_sets)
_suv_guard_wrap_execute(SUV_OT_set_recall, 'Set Recall', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_sets)
_suv_guard_wrap_execute(SUV_OT_set_update, 'Set Update', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_sets)
_suv_guard_wrap_execute(SUV_OT_set_delete, 'Set Delete', preserve=False, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_sets)
_suv_guard_wrap_execute(SUV_OT_set_transfer, 'Set Transfer', preserve=False, precheck=_suv_precheck_mesh_targets, detail_getter=_suv_detail_sets)
_suv_guard_wrap_execute(SUV_OT_set_library_io, 'Set Library IO', preserve=False, precheck=None, detail_getter=_suv_detail_sets)
_suv_guard_wrap_execute(SUV_OT_seam_set_save, 'Seam Set Save', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_seam_sets)
_suv_guard_wrap_execute(SUV_OT_seam_set_recall, 'Seam Set Recall', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_seam_sets)
_suv_guard_wrap_execute(SUV_OT_seam_set_update, 'Seam Set Update', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_seam_sets)
_suv_guard_wrap_execute(SUV_OT_seam_set_delete, 'Seam Set Delete', preserve=False, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_seam_sets)
_suv_guard_wrap_execute(SUV_OT_seam_set_transfer, 'Seam Set Transfer', preserve=False, precheck=_suv_precheck_mesh_targets, detail_getter=_suv_detail_seam_sets)
_suv_guard_wrap_execute(SUV_OT_seam_set_library_io, 'Seam Set Library IO', preserve=False, precheck=None, detail_getter=_suv_detail_seam_sets)
_suv_guard_wrap_execute(SUV_OT_layout_set_save, 'Layout Set Save', preserve=True, precheck=_suv_precheck_active_uv, detail_getter=_suv_detail_layout_sets)
_suv_guard_wrap_execute(SUV_OT_layout_set_recall, 'Layout Set Recall', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_layout_sets)
_suv_guard_wrap_execute(SUV_OT_layout_set_update, 'Layout Set Update', preserve=True, precheck=_suv_precheck_active_uv, detail_getter=_suv_detail_layout_sets)
_suv_guard_wrap_execute(SUV_OT_layout_set_delete, 'Layout Set Delete', preserve=False, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_layout_sets)
_suv_guard_wrap_execute(SUV_OT_layout_set_transfer, 'Layout Set Transfer', preserve=False, precheck=_suv_precheck_mesh_targets, detail_getter=_suv_detail_layout_sets)
_suv_guard_wrap_execute(SUV_OT_layout_set_library_io, 'Layout Set Library IO', preserve=False, precheck=None, detail_getter=_suv_detail_layout_sets)
_suv_guard_wrap_execute(SUV_OT_select_udim_crossing, 'Select UDIM Crossing', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'scope': getattr(self, 'scope', '')})
_suv_guard_wrap_execute(SUV_OT_apply_hotspot_preset, 'Apply Hotspot Preset', preserve=False, precheck=_suv_precheck_mesh_targets, detail_getter=_suv_detail_layout_preset)
_suv_guard_wrap_execute(SUV_OT_apply_named_layout_library, 'Apply Named Layout Library', preserve=False, precheck=_suv_precheck_mesh_targets, detail_getter=_suv_detail_layout_preset)
_suv_guard_wrap_execute(SUV_OT_hs_orthogonalize, 'Orthogonalize UVs', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_hardsurface)
_suv_guard_wrap_execute(SUV_OT_hs_gridify, 'Gridify', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_hardsurface)
_suv_guard_wrap_execute(SUV_OT_hs_squareify, 'Square Fit', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_hardsurface)
_suv_guard_wrap_execute(SUV_OT_hs_rectify_fit, 'Fit Rectified Shape', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_hardsurface)
_suv_guard_wrap_execute(SUV_OT_hs_rectify_constrained, 'Constraint Rectify', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_hardsurface)
_suv_guard_wrap_execute(SUV_OT_hs_quad_flow, 'Quad Flow', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_hardsurface)
_suv_guard_wrap_execute(SUV_OT_trim_strip_layout, 'Layout Trim Strip', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_layout_preset)
_suv_guard_wrap_execute(SUV_OT_trim_band_layout, 'Layout Trim Band', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_layout_preset)
_suv_guard_wrap_execute(SUV_OT_external_layout_profile, 'External Layout Profile', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'profile': getattr(self, 'profile', ''), 'scope': getattr(self, 'scope', ''), 'texture_size': getattr(self, 'texture_size', None), 'margin_px': getattr(self, 'margin_px', None), 'band_count': getattr(self, 'band_count', None)})
_suv_guard_wrap_execute(SUV_OT_udim_step, 'UDIM Step', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_udim)
_suv_guard_wrap_execute(SUV_OT_uv_brush_compat, 'UV Brush Compatibility', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
SUV_OT_workspace_validate.poll = classmethod(lambda cls, context: True)
SUV_OT_workspace_auto_repair.poll = classmethod(lambda cls, context: True)
SUV_OT_workspace_reset.poll = classmethod(lambda cls, context: True)
SUV_OT_workspace_settings_io.poll = classmethod(lambda cls, context: True)
SUV_OT_preset_library_io.poll = classmethod(lambda cls, context: True)
SUV_OT_uv_sync_mode_toggle.poll = classmethod(lambda cls, context: getattr(getattr(context, 'scene', None), 'tool_settings', None) is not None)
SUV_OT_reload_custom_icons.poll = classmethod(lambda cls, context: True)
SUV_OT_write_tool_runtime_snapshot.poll = classmethod(lambda cls, context: True)
SUV_OT_clear_batch_report.poll = classmethod(lambda cls, context: True)
SUV_OT_clear_tool_runtime_log.poll = classmethod(lambda cls, context: True)
SUV_OT_apply_workflow_preset.poll = classmethod(lambda cls, context: True)
SUV_OT_apply_display_preset.poll = classmethod(lambda cls, context: True)
SUV_OT_apply_line_flow_preset.poll = classmethod(lambda cls, context: True)
SUV_OT_apply_layout_preset.poll = classmethod(lambda cls, context: True)

_suv_guard_wrap_execute(SUV_OT_workspace_validate, 'Validate Workspace', preserve=False, detail_getter=_suv_detail_workspace_maintenance)
_suv_guard_wrap_execute(SUV_OT_workspace_auto_repair, 'Auto Repair Workspace', preserve=False, detail_getter=_suv_detail_workspace_repair)
_suv_guard_wrap_execute(SUV_OT_workspace_reset, 'Reset Workspace', preserve=False, detail_getter=_suv_detail_workspace_maintenance)
_suv_guard_wrap_execute(SUV_OT_workspace_settings_io, 'Workspace Settings I/O', preserve=False, detail_getter=lambda self, context: {'mode': getattr(self, 'mode', ''), 'text_name': getattr(self, 'text_name', ''), 'filepath': getattr(self, 'filepath', ''), 'include_tool_runtime': getattr(self, 'include_tool_runtime', None), 'include_preferences': getattr(self, 'include_preferences', None)})
_suv_guard_wrap_execute(SUV_OT_preset_library_io, 'Preset Library I/O', preserve=False, detail_getter=lambda self, context: {'mode': getattr(self, 'mode', ''), 'library_kind': getattr(self, 'library_kind', ''), 'text_name': getattr(self, 'text_name', ''), 'filepath': getattr(self, 'filepath', ''), 'merge_mode': getattr(self, 'merge_mode', ''), 'entry_key': getattr(self, 'entry_key', '')})
_suv_guard_wrap_execute(SUV_OT_uv_sync_mode_toggle, 'UV Sync Selection', preserve=False, detail_getter=lambda self, context: {'mode': getattr(self, 'mode', ''), 'current': getattr(getattr(getattr(context, 'scene', None), 'tool_settings', None), 'use_uv_select_sync', None)})
_suv_guard_wrap_execute(SUV_OT_reload_custom_icons, 'Reload Icons', preserve=False, detail_getter=_suv_detail_workspace_maintenance)
_suv_guard_wrap_execute(SUV_OT_write_tool_runtime_snapshot, 'Write Snapshot', preserve=False, detail_getter=_suv_detail_workspace_maintenance)
_suv_guard_wrap_execute(SUV_OT_clear_batch_report, 'Clear Batch Report', preserve=False, detail_getter=_suv_detail_workspace_maintenance)
_suv_guard_wrap_execute(SUV_OT_clear_tool_runtime_log, 'Clear Runtime Log', preserve=False, detail_getter=_suv_detail_workspace_maintenance, log_success=False)
_suv_guard_wrap_execute(SUV_OT_apply_workflow_preset, 'Apply Workflow Preset', preserve=False, detail_getter=_suv_detail_workspace_preset)
_suv_guard_wrap_execute(SUV_OT_apply_display_preset, 'Apply Display Preset', preserve=False, detail_getter=_suv_detail_workspace_preset)
_suv_guard_wrap_execute(SUV_OT_apply_line_flow_preset, 'Apply Line / Flow Preset', preserve=False, detail_getter=_suv_detail_workspace_preset)
_suv_guard_wrap_execute(SUV_OT_apply_layout_preset, 'Apply Layout Preset', preserve=False, detail_getter=_suv_detail_workspace_preset)
_suv_guard_wrap_execute(SUV_OT_apply_pack_profile, 'Apply Pack Profile', preserve=False, detail_getter=_suv_detail_workspace_preset)



_suv_guard_wrap_execute(SUV_OT_constraint_unwrap, 'Constraint Unwrap', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_native_projection)
_suv_guard_wrap_execute(SUV_OT_constraint_relax_preserve, 'Relax with Constraints', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_native_projection)
_suv_guard_wrap_execute(SUV_OT_boundary_to_shape, 'Convert Boundary to Shape', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_face_unitize, 'Unitize Faces', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_toggle_live_unwrap, 'Toggle Live Unwrap', preserve=False, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_uv_lattice_compat, 'UV Lattice Compat', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)


_suv_guard_wrap_execute(SUV_OT_projection_bridge, 'Projection Bridge', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_native_projection)
_suv_guard_wrap_execute(SUV_OT_cleanup_bridge, 'Cleanup Bridge', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_native_action)
_suv_guard_wrap_execute(SUV_OT_similarity_bridge, 'Smart Similarity Bridge', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_selection)
_suv_guard_wrap_execute(SUV_OT_unstack_overlapped, 'Unstack Overlapped', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_unstack_groups, 'Unstack Groups', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_udim_tile_tools, 'UDIM Tile Tools', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_texel_group_tools, 'Texel Group Tools', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_native_stage_compat_tools, 'Core Support Tools', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_transform)
_suv_guard_wrap_execute(SUV_OT_match_active_preserve, 'Match Active Preserve', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_match_active_preserve)
_suv_guard_wrap_execute(SUV_OT_match_stitch_active_preserve, 'Match + Stitch Active', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=_suv_detail_match_stitch_active_preserve)
_suv_guard_wrap_execute(SUV_OT_batch_match_stitch_active_preserve, 'Batch Match + Stitch Active', preserve=True, precheck=_suv_precheck_mesh_targets, detail_getter=_suv_detail_match_stitch_active_preserve)
_suv_guard_wrap_execute(SUV_OT_uv_issue_audit_tools, 'UV Issue Audit Tools', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'mode': getattr(self, 'mode', ''), 'stretch_threshold': getattr(_suv_ws(context), 'stretch_threshold', None) if _suv_ws(context) else None})
_suv_guard_wrap_execute(SUV_OT_uv_issue_overlay_tools, 'UV Issue Overlay Tools', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'mode': getattr(self, 'mode', ''), 'overlay_mode': getattr(self, 'overlay_mode', ''), 'attr_name': getattr(self, 'attr_name', '')})
_suv_guard_wrap_execute(SUV_OT_uv_stack_compare_overlay_tools, 'UV Stack Compare Overlay Tools', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'mode': getattr(self, 'mode', ''), 'overlay_mode': getattr(self, 'overlay_mode', ''), 'attr_name': getattr(self, 'attr_name', '')})
_suv_guard_wrap_execute(SUV_OT_uv_seam_state_overlay_tools, 'UV Seam State Overlay Tools', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'mode': getattr(self, 'mode', ''), 'overlay_mode': getattr(self, 'overlay_mode', ''), 'attr_name': getattr(self, 'attr_name', '')})
_suv_guard_wrap_execute(SUV_OT_uv_seam_gap_tools, 'UV Seam Gap Tools', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'mode': getattr(self, 'mode', ''), 'scope': getattr(self, 'scope', ''), 'clear_edge_selection': getattr(self, 'clear_edge_selection', False)})
_suv_guard_wrap_execute(SUV_OT_uv_seam_candidate_tools, 'UV Seam Candidate Tools', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'mode': getattr(self, 'mode', ''), 'scope': getattr(self, 'scope', ''), 'min_score': getattr(self, 'min_score', 0.0), 'strong_score': getattr(self, 'strong_score', 0.0), 'filter_min_score': getattr(self, 'filter_min_score', 0.0), 'filter_max_score': getattr(self, 'filter_max_score', 0.0), 'min_reason_count': getattr(self, 'min_reason_count', 0), 'require_sharp': getattr(self, 'require_sharp', False), 'require_material': getattr(self, 'require_material', False), 'require_angle_boundary': getattr(self, 'require_angle_boundary', False)})
_suv_guard_wrap_execute(SUV_OT_uv_seam_candidate_overlay_tools, 'UV Seam Candidate Overlay Tools', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'mode': getattr(self, 'mode', ''), 'overlay_mode': getattr(self, 'overlay_mode', ''), 'attr_name': getattr(self, 'attr_name', ''), 'min_score': getattr(self, 'min_score', 0.0), 'strong_score': getattr(self, 'strong_score', 0.0), 'filter_min_score': getattr(self, 'filter_min_score', 0.0), 'filter_max_score': getattr(self, 'filter_max_score', 0.0), 'min_reason_count': getattr(self, 'min_reason_count', 0), 'require_uv_border': getattr(self, 'require_uv_border', False), 'require_seam_gap': getattr(self, 'require_seam_gap', False), 'require_sharp': getattr(self, 'require_sharp', False), 'require_material': getattr(self, 'require_material', False), 'require_angle_boundary': getattr(self, 'require_angle_boundary', False)})
_suv_guard_wrap_execute(SUV_OT_uv_seam_candidate_profile_tools, 'UV Seam Candidate Profile Tools', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'mode': getattr(self, 'mode', ''), 'profile_source': getattr(self, 'profile_source', ''), 'builtin_profile': getattr(self, 'builtin_profile', ''), 'scope': getattr(self, 'scope', ''), 'overlay_mode': getattr(self, 'overlay_mode', ''), 'strong_only': getattr(self, 'strong_only', False), 'profile_name': getattr(self, 'profile_name', '')})
_suv_guard_wrap_execute(SUV_OT_uv_seam_candidate_profile_batch_tools, 'UV Seam Candidate Profile Batch Tools', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'mode': getattr(self, 'mode', ''), 'profile_source': getattr(self, 'profile_source', ''), 'builtin_profile': getattr(self, 'builtin_profile', ''), 'overlay_mode': getattr(self, 'overlay_mode', ''), 'strong_only': getattr(self, 'strong_only', False), 'profile_name': getattr(self, 'profile_name', ''), 'write_external_json': getattr(self, 'write_external_json', False), 'write_external_csv': getattr(self, 'write_external_csv', False)})
_suv_guard_wrap_execute(SUV_OT_uv_seam_candidate_profile_audit_tools, 'UV Seam Candidate Profile Audit Tools', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'mode': getattr(self, 'mode', ''), 'scope': getattr(self, 'scope', ''), 'include_builtin_profiles': getattr(self, 'include_builtin_profiles', False), 'include_stored_profile': getattr(self, 'include_stored_profile', False), 'include_current_settings': getattr(self, 'include_current_settings', False), 'sort_mode': getattr(self, 'sort_mode', ''), 'profile_name': getattr(self, 'profile_name', '')})
_suv_guard_wrap_execute(SUV_OT_uv_similarity_cluster_tools, 'UV Similarity Cluster Tools', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'mode': getattr(self, 'mode', ''), 'identical_threshold': getattr(self, 'identical_threshold', None), 'similar_threshold': getattr(self, 'similar_threshold', None)})
_suv_guard_wrap_execute(SUV_OT_uv_similarity_cluster_overlay_tools, 'UV Similarity Cluster Overlay Tools', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'mode': getattr(self, 'mode', ''), 'overlay_mode': getattr(self, 'overlay_mode', ''), 'attr_name': getattr(self, 'attr_name', '')})
_suv_guard_wrap_execute(SUV_OT_layout_candidate_audit, 'Adaptive Layout Audit', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'mode': getattr(self, 'mode', ''), 'scope': getattr(self, 'scope', ''), 'prefer_family': getattr(self, 'prefer_family', '')})
_suv_guard_wrap_execute(SUV_OT_layout_recipe_materialize, 'Adaptive Layout Materializer', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'mode': getattr(self, 'mode', ''), 'scope': getattr(self, 'scope', ''), 'prefer_family': getattr(self, 'prefer_family', ''), 'template_source': getattr(self, 'template_source', '')})
_suv_guard_wrap_execute(SUV_OT_layout_audit_relayout, 'Audit Guided Relayout', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'mode': getattr(self, 'mode', ''), 'scope': getattr(self, 'scope', ''), 'band_count': getattr(self, 'band_count', None), 'max_steps': getattr(self, 'max_steps', None), 'run_stage_reports': getattr(self, 'run_stage_reports', None), 'stop_on_regression': getattr(self, 'stop_on_regression', None), 'step_min_improvement': getattr(self, 'step_min_improvement', None)})
_suv_guard_wrap_execute(SUV_OT_hotspot_symmetry_refill, 'Refill Symmetric Hotspots', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'scope': getattr(self, 'scope', ''), 'pair_axis': getattr(self, 'pair_axis', ''), 'symmetry_axis': getattr(self, 'axis', ''), 'require_topology': getattr(self, 'require_topology', False)})
_suv_guard_wrap_execute(SUV_OT_batch_layout_profile, 'Batch Layout Profile', preserve=True, precheck=_suv_precheck_mesh_targets, detail_getter=lambda self, context: {'profile': getattr(self, 'profile', ''), 'target_mode': getattr(self, 'target_mode', ''), 'scope': getattr(self, 'scope', ''), 'texture_size': getattr(self, 'texture_size', None), 'margin_px': getattr(self, 'margin_px', None), 'band_count': getattr(self, 'band_count', None), 'apply_density': getattr(self, 'apply_density', None), 'select_processed': getattr(self, 'select_processed', None)})
_suv_guard_wrap_execute(SUV_OT_apply_density_profile, 'Apply Density Profile', preserve=False, detail_getter=lambda self, context: {'profile': getattr(self, 'profile', ''), 'run_batch': getattr(self, 'run_batch', False), 'run_guard': getattr(self, 'run_guard', False), 'scope': getattr(self, 'scope', '')})
_suv_guard_wrap_execute(SUV_OT_apply_inspector_profile, 'Apply Inspector Profile', preserve=False, detail_getter=lambda self, context: {'profile': getattr(self, 'profile', ''), 'run_scan': getattr(self, 'run_scan', False), 'run_heal': getattr(self, 'run_heal', False), 'scope': getattr(self, 'scope', '')})
_suv_guard_wrap_execute(SUV_OT_apply_workflow_bundle, 'Apply Workflow Bundle', preserve=False, detail_getter=lambda self, context: {'profile': getattr(self, 'profile', ''), 'use_bundle_actions': getattr(self, 'use_bundle_actions', False), 'run_auto_uv': getattr(self, 'run_auto_uv', False), 'run_pack': getattr(self, 'run_pack', False), 'run_density_batch': getattr(self, 'run_density_batch', False), 'run_density_guard': getattr(self, 'run_density_guard', False), 'run_inspector_scan': getattr(self, 'run_inspector_scan', False), 'run_inspector_heal': getattr(self, 'run_inspector_heal', False), 'scope': getattr(self, 'scope', ''), 'validate_before_run': getattr(self, 'validate_before_run', False), 'restore_workspace_on_failure': getattr(self, 'restore_workspace_on_failure', False), 'restore_selection_on_finish': getattr(self, 'restore_selection_on_finish', False), 'write_report': getattr(self, 'write_report', False)})
_suv_guard_wrap_execute(SUV_OT_apply_workflow_recipe, 'Apply Workflow Recipe', preserve=False, detail_getter=lambda self, context: {'profile': getattr(self, 'profile', ''), 'stop_on_error': getattr(self, 'stop_on_error', False), 'scope': getattr(self, 'scope', ''), 'write_report': getattr(self, 'write_report', False), 'select_processed': getattr(self, 'select_processed', False), 'validate_before_run': getattr(self, 'validate_before_run', False), 'restore_workspace_on_error': getattr(self, 'restore_workspace_on_error', False), 'restore_selection_on_error': getattr(self, 'restore_selection_on_error', False), 'restore_selection_between_steps': getattr(self, 'restore_selection_between_steps', False), 'restore_selection_on_finish': getattr(self, 'restore_selection_on_finish', False)})
_suv_guard_wrap_execute(SUV_OT_validate_workflow_assets, 'Validate Workflow Assets', preserve=False, detail_getter=lambda self, context: {'write_json': getattr(self, 'write_json', False)})


SUV_OT_layout_preflight_audit.poll = classmethod(_suv_poll_active_mesh)
SUV_OT_apply_external_compat_target.poll = classmethod(_suv_poll_any_mesh)

_suv_guard_wrap_execute(SUV_OT_layout_preflight_audit, 'Layout Preflight Audit', preserve=True, precheck=_suv_precheck_active_mesh, detail_getter=lambda self, context: {'scope': getattr(self, 'scope', ''), 'prefer_family': getattr(self, 'prefer_family', ''), 'write_json': getattr(self, 'write_json', False), 'write_report': getattr(self, 'write_report', False)})
_suv_guard_wrap_execute(SUV_OT_apply_external_compat_target, 'Apply External Compatibility Target', preserve=False, precheck=_suv_precheck_mesh_targets, detail_getter=lambda self, context: {'target': getattr(self, 'target', ''), 'scope': getattr(self, 'scope', ''), 'execution_mode': getattr(self, 'execution_mode', ''), 'allow_fallback_paths': getattr(self, 'allow_fallback_paths', False), 'isolate_shared_mesh_scope': getattr(self, 'isolate_shared_mesh_scope', False)})
_suv_guard_wrap_execute(SUV_OT_external_compat_report, 'External Compatibility Report', preserve=False, detail_getter=lambda self, context: {'text_name': getattr(self, 'text_name', 'SUV_External_Compatibility_Report')})


# ============================================================
# Standard UV Suite N-panel host
# ============================================================

_SUV_PROPERTIES_TAB_AREA_KEYS = set()
_SUV_PATCHED_PROPERTIES_PANEL_POLLS = {}
_SUV_MISSING_POLL = object()

# --- Standard 3D View Sidebar N-panel host ---
# The old shared host bridge has
# been removed.  UV Suite is now registered the same way as a normal Blender
# sidebar tool: bl_space_type='VIEW_3D', bl_region_type='UI', bl_category='Smart UV'.
_SUV_PROPERTIES_TAB_AREA_KEYS = set()
_SUV_PATCHED_PROPERTIES_PANEL_POLLS = {}
_SUV_MISSING_POLL = object()
_SUV_ORIGINAL_PROPERTIES_NAV_DRAW = None
_SUV_PROPERTIES_HOST_PREPARED = False


def _suv_properties_area_key(context):
    del context
    return None


def _suv_properties_pseudo_tab_active(context):
    del context
    return True


def _suv_tag_redraw_area(area):
    if area is None:
        return
    try:
        area.tag_redraw()
    except Exception:
        pass


def _suv_set_properties_pseudo_tab_active(context, active: bool):
    del active
    _suv_tag_redraw_area(getattr(context, 'area', None))


def _suv_toggle_properties_pseudo_tab(context):
    _suv_tag_redraw_area(getattr(context, 'area', None))


def _suv_iter_foreign_properties_window_panels():
    return iter(())


def _suv_install_properties_panel_hider():
    return None


def _suv_restore_properties_panel_hider():
    _SUV_PATCHED_PROPERTIES_PANEL_POLLS.clear()
    return None


def _suv_draw_properties_nav_with_pseudo_tab(self, context):
    del self, context
    return None


def _suv_install_properties_pseudo_tab_hack():
    # Normal N-panel implementation: no navigation patches, no
    # hidden panel polls, and no shared-host behavior.
    _suv_prepare_properties_pseudo_tab_host()
    try:
        area = getattr(getattr(bpy, 'context', None), 'area', None)
        if area is not None and str(getattr(area, 'type', '') or '') == 'VIEW_3D':
            area.tag_redraw()
    except Exception:
        pass
    return None


def _suv_uninstall_properties_pseudo_tab_hack():
    _suv_restore_properties_panel_hider()
    _SUV_PROPERTIES_TAB_AREA_KEYS.clear()
    return None


def _suv_prepare_properties_pseudo_tab_host():
    global _SUV_PROPERTIES_HOST_PREPARED
    _SUV_PROPERTIES_HOST_PREPARED = True
    return None


class SUV_OT_toggle_properties_pseudo_tab(bpy.types.Operator):
    bl_idname = 'wm.suv_toggle_properties_pseudo_tab'
    bl_label = 'Refresh N-panel'
    bl_description = 'Refresh the UV Suite controls in the 3D View Sidebar N-panel. This compatibility command only redraws the standard UV Suite N-panel. / UVスイートNパネル更新。3DビューのサイドバーNパネル内にある UV Suite 操作を再描画します。標準の UVスイートNパネルだけを再描画します。'
    bl_options = {'INTERNAL'}

    def execute(self, context):
        _suv_toggle_properties_pseudo_tab(context)
        return {'FINISHED'}


class UVSUITE_PT_UV_MAIN_SUV_PT_PROPERTIES_ROOT(bpy.types.Panel):
    bl_label = 'Smart UV'
    bl_idname = 'UVSUITE_PT_UV_MAIN_SUV_PT_PROPERTIES_ROOT'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart UV'
    bl_description = 'UV Suite N-panel root. Shows the UV Suite workflow tools in Blender’s standard 3D View Sidebar. Open the Sidebar with N, choose the Smart UV tab, then run the grouped UV tools from this panel. / UVスイートNパネルルート。Blender標準の3Dビューサイドバー内に UV Suite のワークフローツールを表示します。Nキーでサイドバーを開き、UV Suite タブを選び、このパネルからジャンル別のUVツールを実行します。'
    bl_order = 0

    @classmethod
    def poll(cls, context):
        del cls, context
        # Hidden compatibility root.  SMARTUVSUITE_PT_npanel_bootstrap is the
        # single visible Smart UV 3D View N-panel root.
        return False

    def draw(self, context):
        layout = self.layout
        if not smart_uv_context_is_draw_ready(context):
            smart_uv_safe_draw_fallback(layout, context, 'Select a mesh object, or switch to Object/Edit mode, to show UV Suite controls.')
            return
        try:
            _draw_suite(layout, context)
        except Exception as exc:
            col = layout.column(align=True)
            col.label(text=_suv_ui_text('UV Suite UI draw fallback'), icon='ERROR')
            col.label(text=str(exc))


_suv_guard_wrap_execute(SUV_OT_toggle_properties_pseudo_tab, 'Refresh N-panel', preserve=False, precheck=None)

def _suv_repair_chained_module_namespaces():
    """Expose final-stage helpers to classes defined in earlier patch modules.

    Smart UV Suite is assembled from a chain of compatibility modules.  Copying
    the module dictionaries forward makes the classes visible here, but Python
    methods still resolve globals in the module where each class was originally
    defined.  Helpers added by later stages therefore have to be made visible to
    those defining modules as well.  Existing definitions are intentionally kept
    so module-specific implementations continue to take precedence.
    """
    source = {
        name: value
        for name, value in globals().items()
        if name.startswith('_suv_') or name.startswith('_SUV_')
    }
    package_name = str(__package__ or '').strip()
    repaired = 0
    for module_name, module in ():
        if module is None or module_name == __name__:
            continue
        if package_name and not (
            module_name == package_name or module_name.startswith(package_name + '.')
        ):
            continue
        namespace = getattr(module, '__dict__', None)
        if not isinstance(namespace, dict):
            continue
        for name, value in source.items():
            if name not in namespace:
                namespace[name] = value
                repaired += 1
    return repaired


_suv_chained_namespace_repairs = _suv_repair_chained_module_namespaces()
_suv_tool_runtime_guard_bootstrap = _suv_auto_guard_namespace_operators(globals())

classes = (
    SUV_PG_WorkspaceSettings,

    # Legacy
    SUV_OT_smart_seams,
    SUV_OT_smart_tube,
    SUV_OT_smart_relax,
    SUV_OT_smart_edge_straighten,
    SUV_OT_smart_rectify,
    SUV_OT_smart_3d_transfer,
    SUV_OT_repair_flipped_islands,

    # Pro
    SUV_OT_stack_pro,
    SUV_OT_pack_pro,
    SUV_OT_texel_get,
    SUV_OT_texel_set,
    SUV_OT_texel_normalize,
    SUV_OT_inspector_scan,
    SUV_OT_inspector_select,
    SUV_OT_inspector_fix_flipped,
    SUV_OT_inspector_rescan,
    SUV_OT_inspector_clear_cache,
    SUV_OT_workspace_validate,
    SUV_OT_workspace_auto_repair,
    SUV_OT_workspace_settings_io,
    SUV_OT_preset_library_io,
    SUV_OT_uv_sync_mode_toggle,
    SUV_OT_reload_custom_icons,
    SUV_OT_write_tool_runtime_snapshot,
    SUV_OT_clear_tool_runtime_log,
    SUV_OT_clear_batch_report,
    SUV_OT_open_diagnostics_text,
    SUV_OT_write_support_bundle,
    SUV_OT_copy_diagnostics_text,
    SUV_OT_collect_support_bundle,
    SUV_OT_clear_all_reports,
    SUV_OT_workspace_reset,
    SUV_OT_apply_workflow_preset,
    SUV_OT_apply_display_preset,
    SUV_OT_apply_line_flow_preset,
    SUV_OT_apply_layout_preset,
    SUV_OT_fix_all_issues,
    SUV_OT_auto_uv_profile,
    SUV_OT_auto_unwrap_pro,

    # Additional workflow tools
    SUV_OT_uv_straight_line,
    SUV_OT_uv_annotate_align,
    SUV_OT_uv_set_flow,
    SUV_OT_uv_brush_compat,
    SUV_OT_centralize_islands,
    SUV_OT_align_islands,
    SUV_OT_distribute_islands,
    SUV_OT_fit_to_bounds,
    SUV_OT_rotate_islands,
    SUV_OT_orient_to_edge,
    SUV_OT_flip_islands,
    SUV_OT_orient_islands,
    SUV_OT_randomize_islands,
    SUV_OT_explode_islands,
    SUV_OT_clear_pins,
    SUV_OT_clear_seams,
    SUV_OT_uv_edit_compat_tools,
    SUV_OT_select_udim_crossing,
    SUV_OT_visualize_stretch_heatmap,
    SUV_OT_clear_stretch_heatmap,
    SUV_OT_create_checker_material,
    SUV_OT_auto_seam_advanced,
    SUV_OT_apply_seam_profile,
    SUV_OT_batch_apply_seam_profile,
    SUV_OT_apply_hotspot_preset,
    SUV_OT_apply_named_layout_library,
    SUV_OT_apply_pack_profile,
    SUV_OT_apply_density_profile,
    SUV_OT_apply_inspector_profile,
    SUV_OT_apply_workflow_bundle,
    SUV_OT_apply_workflow_recipe,
    SUV_OT_validate_workflow_assets,
    SUV_OT_hotspot_grid_layout,
    SUV_OT_hotspot_symmetry_refill,
    SUV_OT_hotspot_cell_tools,
    SUV_OT_hotspot_cell_refill,
    SUV_OT_trim_strip_layout,
    SUV_OT_trim_band_layout,
    SUV_OT_trim_band_refill,
    SUV_OT_external_layout_profile,
    SUV_OT_batch_layout_profile,
    SUV_OT_batch_object_to_udim_tiles,
    SUV_OT_constraint_unwrap,
    SUV_OT_constraint_relax_preserve,
    SUV_OT_boundary_to_shape,
    SUV_OT_face_unitize,
    SUV_OT_toggle_live_unwrap,
    SUV_OT_uv_lattice_compat,
    SUV_OT_projection_bridge,
    SUV_OT_cleanup_bridge,
    SUV_OT_similarity_bridge,
    SUV_OT_unstack_overlapped,
    SUV_OT_unstack_groups,
    SUV_OT_stack_grouped,
    SUV_OT_stack_topology_groups,
    SUV_OT_stack_symmetry_topology,
    SUV_OT_layout_preflight_audit,
    SUV_OT_groups_to_tiles,
    SUV_OT_group_normalize_layout,
    SUV_OT_density_guard_normalize,
    SUV_OT_priority_density_pack,
    SUV_OT_layout_autoheal,
    SUV_OT_orient_groups_advanced,
    SUV_OT_layout_candidate_audit,
    SUV_OT_layout_audit_relayout,
    SUV_OT_audit_chain_preset,
    SUV_OT_layout_recipe_materialize,
    SUV_OT_inspector_select_all,
    SUV_OT_inspector_write_report,
    SUV_OT_sort_islands,
    SUV_OT_select_zero_islands,
    SUV_OT_uv_crop_tile,
    SUV_OT_uv_fill_tile,
    SUV_OT_uvmap_set_active,
    SUV_OT_bake_uv_prep,
    SUV_OT_uvmap_set_render,
    SUV_OT_uvmap_rename_active,
    SUV_OT_uvmap_reorder,
    SUV_OT_remove_checker_materials,
    SUV_OT_uvmap_add,
    SUV_OT_uvmap_duplicate,
    SUV_OT_uvmap_remove,
    SUV_OT_native_projection,
    SUV_OT_native_uv_action,
    SUV_OT_udim_step,
    SUV_OT_hs_orthogonalize,
    SUV_OT_hs_gridify,
    SUV_OT_hs_squareify,
    SUV_OT_hs_rectify_fit,
    SUV_OT_hs_rectify_constrained,
    SUV_OT_hs_quad_flow,
    SUV_OT_udim_tile_tools,
    SUV_OT_texel_group_tools,
    SUV_OT_native_stage_compat_tools,
    SUV_OT_match_active_preserve,
    SUV_OT_match_stitch_active_preserve,
    SUV_OT_batch_match_stitch_active_preserve,

    SUV_OT_native_stage_workflow,
    SUV_OT_uv_histogram_tools,
    SUV_OT_uv_issue_audit_tools,
    SUV_OT_uv_issue_overlay_tools,
    SUV_OT_uv_stack_compare_overlay_tools,
    SUV_OT_uv_seam_state_overlay_tools,
    SUV_OT_uv_seam_gap_tools,
    SUV_OT_uv_seam_candidate_tools,
    SUV_OT_uv_seam_candidate_overlay_tools,
    SUV_OT_uv_seam_candidate_profile_tools,
    SUV_OT_uv_seam_candidate_profile_batch_tools,
    SUV_OT_uv_seam_candidate_profile_audit_tools,
    SUV_OT_uv_similarity_cluster_tools,
    SUV_OT_uv_similarity_cluster_overlay_tools,
    SUV_OT_native_stage_layout,
    SUV_OT_native_stage_select,
    SUV_OT_native_stage_uvmap,
    SUV_OT_native_stage_preview,
    SUV_OT_native_stage_color,
    SUV_OT_native_stage_mesh,
    SUV_OT_native_stage_bake,

    # Sets
    SUV_OT_select_island_active,
    SUV_OT_select_similar_islands,
    SUV_OT_select_identical_islands,
    SUV_OT_select_fragmented_islands,
    SUV_OT_select_uv_boundary,
    SUV_OT_set_save,
    SUV_OT_set_recall,
    SUV_OT_set_update,
    SUV_OT_set_delete,
    SUV_OT_set_transfer,
    SUV_OT_set_library_io,
    SUV_OT_seam_set_save,
    SUV_OT_seam_set_recall,
    SUV_OT_seam_set_update,
    SUV_OT_seam_set_delete,
    SUV_OT_seam_set_transfer,
    SUV_OT_seam_set_library_io,
    SUV_OT_layout_set_save,
    SUV_OT_layout_set_recall,
    SUV_OT_layout_set_update,
    SUV_OT_layout_set_delete,
    SUV_OT_layout_set_transfer,
    SUV_OT_layout_set_library_io,

    # Symmetry
    SUV_OT_sym_detect_pairs,
    SUV_OT_sym_mirror_uv,
    SUV_OT_sym_seams,
    SUV_OT_sym_stack,

    # Atlas
    SUV_OT_atlas_build_uv_multi,
    SUV_OT_atlas_bake_multi,
    SUV_OT_atlas_build_mat_apply_multi,
    SUV_OT_atlas_run_all_multi,

    # Panels / Menus
    UVSUITE_MT_PROJECTION_TOOLS,
    UVSUITE_MT_WORKFLOW_MORE,
    UVSUITE_MT_TRANSFORM_MORE,
    UVSUITE_MT_HARD_SURFACE_MORE,
    UVSUITE_MT_LAYOUT_MORE,
    UVSUITE_MT_SELECTION_MORE,
    UVSUITE_MT_SELECTION_SETS,
    UVSUITE_MT_LAYOUT_SETS,
    UVSUITE_MT_SEAM_SETS,
    UVSUITE_MT_PACK_PROFILES,
    UVSUITE_MT_DENSITY_PROFILES,
    UVSUITE_MT_INSPECTOR_PROFILES,
    UVSUITE_MT_WORKFLOW_BUNDLES,
    UVSUITE_MT_WORKFLOW_RECIPES,
    SUV_OT_apply_external_compat_target,
    SUV_OT_external_compat_report,
    UVSUITE_MT_EXTERNAL_COMPATIBILITY,
    UVSUITE_MT_DENSITY_MORE,
    UVSUITE_MT_BATCH_DENSITY_TOOLS,
    UVSUITE_MT_BATCH_UDIM_TOOLS,
    UVSUITE_MT_UV_STACK_TOOLS,
    UVSUITE_MT_BATCH_UV_LAYER_TOOLS,
    UVSUITE_MT_PREVIEW_MORE,
    UVSUITE_MT_SYMMETRY_MORE,
    UVSUITE_MT_ATLAS_MORE,
    UVSUITE_MT_UV_QUICK_PIE,
    UVSUITE_MT_WORKSPACE_MAINTENANCE,
    SUV_OT_toggle_properties_pseudo_tab,
    UVSUITE_PT_UV_MAIN_SUV_PT_PROPERTIES_ROOT,
)



def _suv_locale_sanitize_class(cls):
    try:
        from . import text_translation as _text_translation
        sanitize_class = getattr(_text_translation, 'sanitize_class', None)
        if callable(sanitize_class):
            return sanitize_class(cls, context=getattr(bpy, 'context', None))
    except Exception:
        pass
    return cls


def _suv_is_registered_draw_class(cls):
    if not isinstance(cls, type):
        return False
    try:
        bases = []
        # Menus are safe to register and are needed by the original full
        # N-panel UI.  Only old Panel/Header/UIList callbacks are skipped here
        # so Blender never enters legacy SmartTools panel_draw handlers.
        for base_name in ('Panel', 'Header', 'UIList'):
            base = getattr(getattr(bpy, 'types', None), base_name, None)
            if isinstance(base, type):
                bases.append(base)
        return bool(bases) and any(issubclass(cls, base) for base in bases)
    except Exception:
        return False

def _suv_registered_bl_idname(cls) -> str:
    """Return only Python-owned operator identifiers.

    Never inspect ``bl_idname`` on arbitrary registered RNA subclasses here.
    Blender 5.1 may expose stale proxy types while several Extensions are being
    restored, and reading their RNA descriptor can enter freed C data.  The old
    implementation scanned every Operator subclass for every Smart UV class;
    this was quadratic and could crash Blender before the startup UI appeared.
    """
    try:
        value = vars(cls).get('bl_idname', '') if isinstance(cls, type) else ''
        return str(value or '')
    except Exception:
        return ''


def _suv_is_owned_class(cls) -> bool:
    """Return True only for a live Python class owned by this Extension."""
    if not isinstance(cls, type):
        return False
    try:
        module_name = str(vars(cls).get('__module__', '') or '')
    except Exception:
        return False
    package_name = str(__package__ or '')
    return bool(package_name) and (module_name == package_name or module_name.startswith(package_name + '.'))


def _suv_unregister_same_bl_idname(cls) -> None:
    """Do not unregister arbitrary operators from other add-ons.

    Duplicate identifiers are handled by Blender's normal register error path.
    A previous Smart UV class can be removed safely by Python class name in the
    local fallback below; global Operator-subclass scans are intentionally
    prohibited because they caused startup crashes with multiple SmartTools.
    """
    return None


def _suv_register_classes_safe():
    _SUV_REGISTER_CLASS_FAILURES.clear()
    for cls in classes:
        if _suv_is_registered_draw_class(cls):
            continue
        try:
            _suv_unregister_same_bl_idname(cls)
            cls = _suv_locale_sanitize_class(cls)
            if not _suv_resource.register_class(cls):
                raise RuntimeError(f"Smart UV class registration failed: {getattr(cls, '__name__', cls)!s}")
            continue
        except Exception:
            existing = getattr(bpy.types, getattr(cls, '__name__', ''), None)
            if _suv_is_owned_class(existing):
                try:
                    _suv_resource.unregister_class(existing)
                except Exception:
                    pass
            try:
                _suv_unregister_same_bl_idname(cls)
                cls = _suv_locale_sanitize_class(cls)
                if not _suv_resource.register_class(cls):
                    raise RuntimeError(f"Smart UV class registration failed: {getattr(cls, '__name__', cls)!s}")
                continue
            except Exception as exc:
                _SUV_REGISTER_CLASS_FAILURES.append({
                    'class_name': str(getattr(cls, '__name__', cls)),
                    'error_type': type(exc).__name__,
                    'error': str(exc),
                })
    globals()['_suv_register_class_failures'] = list(_SUV_REGISTER_CLASS_FAILURES)
    if _SUV_REGISTER_CLASS_FAILURES:
        try:
            preview = '; '.join(
                f"{item.get('class_name')}: {item.get('error_type')}: {item.get('error')}"
                for item in _SUV_REGISTER_CLASS_FAILURES[:8]
            )
            more = len(_SUV_REGISTER_CLASS_FAILURES) - 8
            if more > 0:
                preview += f'; ... (+{more} more)'
            print(f"[UV Suite Quality] register_class skipped summary: {preview}")
        except Exception:
            pass
    return list(_SUV_REGISTER_CLASS_FAILURES)


def _suv_unregister_classes_safe():
    for cls in reversed(classes):
        try:
            _suv_resource.unregister_class(cls)
        except Exception:
            pass
    _SUV_REGISTER_CLASS_FAILURES.clear()
    globals()['_suv_register_class_failures'] = []


def _suv_addon_keyconfig():
    try:
        wm = bpy.context.window_manager
    except Exception:
        wm = None
    keyconfigs = getattr(wm, 'keyconfigs', None) if wm is not None else None
    addon = getattr(keyconfigs, 'addon', None) if keyconfigs else None
    return addon


def _suv_keymap_items_tuple(km):
    del km
    return ()


def _suv_remove_addon_keymap(addon, km):
    del addon, km
    return False


def _suv_remove_empty_addon_keymaps(addon=None, names=None):
    del addon, names
    return 0


def _suv_register_keymaps():
    # Standard N-panel build: no shortcut or workspace-tool keymaps are created.
    return None


def _suv_unregister_keymaps():
    # Startup/shutdown safe: do not traverse keymap RNA.
    try:
        _SUV_KEYMAP_ITEMS.clear()
    except Exception:
        pass
    return None


def _suv_rna_class_ready(cls) -> bool:
    try:
        rna = getattr(cls, 'bl_rna', None)
        identifier = str(getattr(rna, 'identifier', '') or '')
        return bool(identifier) and identifier not in {'Operator', 'OperatorProperties', 'UnknownType', 'bpy_struct'}
    except Exception:
        return False


def register():
    _suv_repair_chained_module_namespaces()
    try:
        _suv_unregister_keymaps()
    except Exception:
        pass
    # Standard N-panel build: no shared SmartTools host uninstall/install is
    # needed.  The panel is registered directly as VIEW_3D / UI / UV Suite.
    try:
        _suv_apply_tooltip_overrides()
    except Exception:
        pass
    _suv_prepare_properties_pseudo_tab_host()
    failures = _suv_register_classes_safe()
    if failures:
        first = failures[0]
        raise RuntimeError(
            "Smart UV public class registration incomplete: "
            f"{first.get('class_name', '<unknown>')}: "
            f"{first.get('error_type', 'Error')}: {first.get('error', '')}"
        )
    try:
        if hasattr(bpy.types.Scene, 'suv_workspace'):
            _suv_resource.unregister_property(bpy.types.Scene, 'suv_workspace')
    except Exception:
        pass
    if not _suv_rna_class_ready(SUV_PG_WorkspaceSettings):
        try:
            _suv_resource.register_class(SUV_PG_WorkspaceSettings)
        except Exception:
            pass
    if _suv_rna_class_ready(SUV_PG_WorkspaceSettings):
        try:
            _suv_resource.register_property(bpy.types.Scene, 'suv_workspace', bpy.props.PointerProperty(type=SUV_PG_WorkspaceSettings))
        except Exception as exc:
            try:
                print(f"[UV Suite] Workspace pointer registration skipped: {exc}")
            except Exception:
                pass
    _suv_post_register_init()
    _suv_register_keymaps()
    _suv_install_properties_pseudo_tab_hack()


def unregister():
    _suv_unregister_keymaps()
    try:
        _suv_uninstall_properties_pseudo_tab_hack()
    except Exception:
        pass
    _suv_unregister_classes_safe()
    try:
        if hasattr(bpy.types.Scene, 'suv_workspace'):
            _suv_resource.unregister_property(bpy.types.Scene, 'suv_workspace')
    except Exception:
        pass
    _unload_custom_icons()


if __name__ == "__main__":
    register()




# --- standard N-panel compatibility patch ---
_SUV_ADDON_KEY = 'smart_uv_suite'
_SUV_TAB_LABEL = 'Smart UV'
_SUV_TAB_TOOLTIP = 'Refresh the UV Suite controls in the standard 3D View Sidebar N-panel.'


def _suv_properties_pseudo_tab_active(context):
    del context
    return True


def _suv_set_properties_pseudo_tab_active(context, active: bool):
    del active
    try:
        area = getattr(context, 'area', None)
        if area is not None and str(getattr(area, 'type', '') or '') == 'VIEW_3D':
            area.tag_redraw()
    except Exception:
        pass


def _suv_toggle_properties_pseudo_tab(context):
    _suv_set_properties_pseudo_tab_active(context, True)


def _suv_prepare_properties_pseudo_tab_host():
    global _SUV_PROPERTIES_HOST_PREPARED
    _SUV_PROPERTIES_HOST_PREPARED = True
    return None


def _suv_draw_smart_tools_window_contents(layout, context):
    # Backward-compatible function name only.  Drawing is handled by the
    # standard UVSUITE_PT_UV_MAIN_SUV_PT_PROPERTIES_ROOT N-panel class.
    try:
        _draw_suite(layout, context)
        return 1
    except Exception as exc:
        try:
            col = layout.column(align=True)
            col.label(text=_suv_ui_text('UV Suite UI draw fallback'), icon='ERROR')
            col.label(text=str(exc))
        except Exception:
            pass
        return 0


def _suv_install_properties_pseudo_tab_hack():
    # Standard N-panel build: no navigation_properties host, no pseudo tab, no
    # Properties editor navigation changes, and no appearance-setting changes.
    _suv_prepare_properties_pseudo_tab_host()
    try:
        area = getattr(getattr(bpy, 'context', None), 'area', None)
        if area is not None and str(getattr(area, 'type', '') or '') == 'VIEW_3D':
            area.tag_redraw()
    except Exception:
        pass
    return None


def _suv_uninstall_properties_pseudo_tab_hack():
    try:
        _suv_restore_properties_panel_hider()
    except Exception:
        pass
    try:
        _SUV_PROPERTIES_TAB_AREA_KEYS.clear()
    except Exception:
        pass
    return None


try:
    SUV_OT_toggle_properties_pseudo_tab.bl_label = _SUV_TAB_LABEL
    SUV_OT_toggle_properties_pseudo_tab.bl_description = _SUV_TAB_TOOLTIP
except Exception:
    pass


# --- UV Suite crash-safe standard N-panel draw START ---
# Blender 5.1 crash hardening:
# - Do not write RNA properties from Panel.draw.
# - Do not call WorkspaceTool APIs from Panel.draw.
# - Do not touch themes, panel colors, header, toolbar, or keymaps.
# - Do not use post-registration draw wrappers.
# - Do not draw the old SmartTools/Properties host.

_SUV_SAFE_NPANEL_GROUPS = (
    ('Workflow', '展開', (
        ('uv.suv_smart_seams', 'Smart Seams', 'スマートシーム', None),
        ('uv.suv_auto_unwrap_pro', 'Auto Unwrap', '自動展開', None),
        ('uv.suv_smart_relax', 'Relax', 'リラックス', None),
        ('uv.suv_clear_pins', 'Clear Pins', 'ピンを解除', None),
        ('mesh.suv_clear_seams', 'Clear Seams', 'シームを解除', None),
    )),
    ('Align', '整列', (
        ('uv.suv_align_islands', 'Align Islands', 'アイランド整列', None),
        ('uv.suv_centralize_islands', 'Center Islands', 'アイランド中央配置', None),
        ('uv.suv_distribute_islands', 'Distribute Islands', 'アイランド分布', None),
        ('uv.suv_orient_to_edge', 'Orient to Edge', '辺に合わせて向き調整', None),
        ('uv.suv_straight_line', 'Straighten Line', '直線化', None),
    )),
    ('Layout Panel', '配置', (
        ('uv.suv_pack_pro', 'Pack', 'パック', None),
        ('uv.suv_fit_to_bounds', 'Fit to Bounds', '範囲に合わせる', None),
        ('uv.suv_rotate_islands', 'Rotate Islands', 'アイランド回転', None),
        ('uv.suv_flip_islands', 'Flip Islands', 'アイランド反転', None),
        ('uv.suv_priority_density_pack', 'Density Pack', '密度優先パック', None),
    )),
    ('Check', '確認', (
        ('uv.suv_inspector_scan', 'Scan Issues', '問題をスキャン', None),
        ('uv.suv_inspector_select', 'Select Issues', '問題を選択', None),
        ('uv.suv_inspector_fix_flipped', 'Fix Flipped', '反転を修正', None),
        ('object.suv_create_checker_material', 'Checker Material', 'チェッカー材質', None),
        ('object.suv_clear_stretch_heatmap', 'Clear Heatmap', 'ヒートマップ解除', None),
    )),
    ('UV Maps', 'UVマップ', (
        ('mesh.suv_uvmap_add', 'Add UV Map', 'UVマップ追加', None),
        ('mesh.suv_uvmap_duplicate', 'Duplicate UV Map', 'UVマップ複製', None),
        ('mesh.suv_uvmap_remove', 'Remove UV Map', 'UVマップ削除', None),
        ('mesh.suv_uvmap_set_render', 'Set Render UV', 'レンダーUVに設定', None),
        ('mesh.suv_uvmap_rename_active', 'Rename Active UV', 'アクティブUV名変更', None),
    )),
    ('Symmetry', '対称', (
        ('uv.suv_sym_detect_pairs', 'Detect Pairs', 'ペア検出', None),
        ('uv.suv_sym_mirror_uv', 'Mirror UV', 'UVミラー', None),
        ('uv.suv_sym_seams', 'Mirror Seams', 'シーム対称', None),
        ('uv.suv_sym_stack', 'Stack Symmetry', '対称スタック', None),
        ('uv.suv_stack_symmetry_topology', 'Topology Symmetry Stack', 'トポロジー対称スタック', None),
    )),
    ('Atlas', 'アトラス', (
        ('uv.suv_atlas_build_uv_multi', 'Build Atlas UV', 'アトラスUV作成', None),
        ('uv.suv_atlas_bake_multi', 'Bake Atlas', 'アトラスベイク', None),
        ('uv.suv_atlas_build_mat_apply_multi', 'Apply Atlas Material', 'アトラス材質適用', None),
        ('uv.suv_atlas_run_all_multi', 'Run Atlas All', 'アトラス一括実行', None),
        ('object.suv_native_stage_bake', 'Bake Utilities', 'ベイク補助', {'mode': 'BAKE_DIFFUSE'}),
    )),
)


def _suv_safe_is_japanese(context=None) -> bool:
    ctx = context or getattr(bpy, 'context', None)
    try:
        wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
        settings = getattr(wm, 'uv_suite_tool_runtime_settings_v520', None) if wm is not None else None
        mode = str(getattr(settings, 'ui_language_mode', '') or '').upper()
        if mode in {'FORCE_JA', 'JA', 'JAPANESE'}:
            return True
        if mode in {'FORCE_EN', 'EN', 'ENGLISH'}:
            return False
    except Exception:
        pass
    try:
        view = getattr(getattr(ctx, 'preferences', None), 'view', None) if ctx is not None else None
        if bool(getattr(view, 'use_translate_interface', False)):
            return str(getattr(view, 'language', '') or '').lower().startswith('ja')
    except Exception:
        pass
    return False


def _suv_safe_text(context, en: str, ja: str) -> str:
    return str(ja if _suv_safe_is_japanese(context) else en)


def _suv_safe_operator_exists(op_idname: str) -> bool:
    try:
        left, dot, right = str(op_idname or '').partition('.')
        if not left or not dot or not right:
            return False
        group = getattr(bpy.ops, left, None)
        if group is None:
            return False
        op = getattr(group, right, None)
        rna = op.get_rna_type()
        identifier = str(getattr(rna, 'identifier', '') or '')
        return bool(identifier) and identifier not in {'Operator', 'OperatorProperties', 'UnknownType', 'bpy_struct'}
    except Exception:
        return False


def _suv_safe_draw_operator(parent, context, op_idname: str, en: str, ja: str, props=None) -> None:
    text = _suv_safe_text(context, en, ja)
    try:
        if not _suv_safe_operator_exists(op_idname):
            return
        op = parent.operator(op_idname, text=text)
        if isinstance(props, dict):
            prop_names = set()
            try:
                prop_defs = getattr(getattr(op, 'bl_rna', None), 'properties', None)
                prop_names.update(str(k) for k in prop_defs.keys())
                for prop in prop_defs:
                    ident = str(getattr(prop, 'identifier', '') or '')
                    if ident:
                        prop_names.add(ident)
            except Exception:
                pass
            for key, value in props.items():
                key = str(key)
                if key not in prop_names:
                    continue
                try:
                    setattr(op, key, value)
                except Exception:
                    pass
    except Exception:
        try:
            parent.label(text=text)
        except Exception:
            pass


def _suv_safe_draw_mesh_summary(parent, context) -> None:
    try:
        obj = getattr(context, 'object', None)
        is_mesh = obj is not None and str(getattr(obj, 'type', '') or '') == 'MESH'
        if not is_mesh:
            parent.label(text=_suv_safe_text(context, 'Select a mesh object to run UV tools.', 'UVツールを実行するにはメッシュオブジェクトを選択してください。'))
            return
        mesh = getattr(obj, 'data', None)
        layers = getattr(mesh, 'uv_layers', None) if mesh is not None else None
        active = getattr(layers, 'active', None) if layers is not None else None
        uv_name = str(getattr(active, 'name', '') or '-')
        count = len(layers) if layers is not None else 0
        parent.label(text=_suv_safe_text(context, f'Active UV: {uv_name}', f'アクティブUV: {uv_name}'))
        parent.label(text=_suv_safe_text(context, f'UV Maps: {count}', f'UVマップ数: {count}'))
    except Exception:
        try:
            parent.label(text='Smart UV')
        except Exception:
            pass


def _suv_safe_draw_suite(layout, context) -> None:
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass
    try:
        root = layout.column(align=True)
    except Exception:
        return

    try:
        header = root.box().column(align=True)
        header.label(text='Smart UV')
        header.label(text=_suv_safe_text(context, 'Crash-safe standard N-panel mode.', 'クラッシュ回避用の標準Nパネルモードです。'))
        _suv_safe_draw_mesh_summary(header, context)
    except Exception:
        pass

    try:
        sys_box = root.box().column(align=True)
        sys_box.label(text=_suv_safe_text(context, 'System', 'システム'))
        _suv_safe_draw_operator(sys_box, context, 'uv.suv_workspace_validate', 'Validate Workspace', 'ワークスペース検証')
        _suv_safe_draw_operator(sys_box, context, 'uv.suv_workspace_auto_repair', 'Repair Workspace', 'ワークスペース修復')
        _suv_safe_draw_operator(sys_box, context, 'uv.suv_open_diagnostics_text', 'Open Diagnostics', '診断を開く')
    except Exception:
        pass

    for en_group, ja_group, entries in _SUV_SAFE_NPANEL_GROUPS:
        try:
            box = root.box()
            col = box.column(align=True)
            col.label(text=_suv_safe_text(context, en_group, ja_group))
            for entry in entries:
                op_idname, en, ja, props = entry
                _suv_safe_draw_operator(col, context, op_idname, en, ja, props)
        except Exception:
            continue


def _draw_suite(layout, context):
    _suv_safe_draw_suite(layout, context)


def _suv_draw_smart_tools_window_contents(layout, context):
    try:
        _suv_safe_draw_suite(layout, context)
        return 1
    except Exception:
        return 0


def _suv_properties_root_safe_draw(self, context):
    try:
        _suv_safe_draw_suite(self.layout, context)
    except Exception:
        try:
            self.layout.label(text='Smart UV')
        except Exception:
            pass


try:
    UVSUITE_PT_UV_MAIN_SUV_PT_PROPERTIES_ROOT.draw = _suv_properties_root_safe_draw
except Exception:
    pass
# --- UV Suite crash-safe standard N-panel draw END ---
