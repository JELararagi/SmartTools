# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Final lightweight UV interaction layer for Smart UV Suite.

Goals:
- Keep Immediate Select / UV Gizmo Grip behavior unchanged from the working build.
- Remove global/Generic immediate-select keymap interception that makes large
  multi-mesh scenes slow and can steal U/V gizmo-axis drags.
- Make axis-memory purely event-based: U/V/free is recorded from the UV gizmo
  grip mode and reused by the next Immediate Select drag.  No polling timer.
- Cache PRESS-time hit/target data and move cached loop references only.
"""

from __future__ import annotations
from . import resource_api_18168 as _suv_resource

from collections import defaultdict
from math import floor
from typing import Any

import bpy
from mathutils import Vector

_PG: dict[str, Any] | None = None
_INSTALLED = False
_PREV_SYNC = None
_HIT_CACHE: dict[str, Any] = {}
_DIRTY_MESH_IDS: set[int] = set()
_LAST_CACHE_TOL = 0.0

# Immediate Select must not live in Window/Generic Gizmo keymaps.  Those paths
# fire for too many editor-level events and make large edit-mode scenes slow.
# UV-specific keymaps are enough for LEFTMOUSE/PRESS in the UV editor and do not
# steal gizmo axis handles before the gizmo keymaps evaluate.
_INSTANT_KEYMAP_DEFS: tuple[tuple[str, str], ...] = (
    ("UV Editor", "EMPTY"),
    ("Image", "IMAGE_EDITOR"),
    ("Image Generic", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Tweak", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Move", "IMAGE_EDITOR"),
)
_FORBIDDEN_INSTANT_KEYMAPS: tuple[str, ...] = (
    "Window",
    "Generic Gizmo",
    "Generic Gizmo Drag",
    "Generic Gizmo Click Drag",
    "Generic Gizmo Maybe Drag",
    "Generic Gizmo Select",
)
_INSTANT_ID = "smart_uv_suite.instant_select_drag_move"
_GIZMO_ID = "smart_uv_suite.uv_gizmo_grip_fix_grab"
_NATIVE_GIZMO_ID = ""


def _pg(name: str, default=None):
    try:
        return _PG.get(name, default) if isinstance(_PG, dict) else default
    except Exception:
        return default


def _addon_keyconfig():
    try:
        return bpy.context.window_manager.keyconfigs.addon
    except Exception:
        return None


def _find_items(km, idname: str):
    try:
        from . import ownership_runtime_18168 as _ownership
        return [kmi for keymap, kmi in _ownership.owned_keymap_items(idname) if keymap is km]
    except Exception:
        return []


def _configure_left_press(kmi, *, allow_modifiers: bool = False) -> None:
    for attr, value in (("type", "LEFTMOUSE"), ("value", "PRESS")):
        try:
            _suv_resource.keymap_item_set(kmi, attr, value)
        except Exception:
            pass
    try:
        _suv_resource.keymap_item_set(kmi, 'any', bool(allow_modifiers))
    except Exception:
        pass
    if not allow_modifiers:
        for name in ("shift", "ctrl", "alt", "oskey", "hyper"):
            if hasattr(kmi, name):
                try:
                    _suv_resource.keymap_item_set(kmi, name, False)
                except Exception:
                    pass


def _new_kmi(km, idname: str):
    try:
        return __import__(__package__ + '.ownership_runtime_18168', fromlist=['new_keymap_item']).new_keymap_item(km, idname, type="LEFTMOUSE", value="PRESS", head=True)
    except TypeError:
        return __import__(__package__ + '.ownership_runtime_18168', fromlist=['new_keymap_item']).new_keymap_item(km, idname, type="LEFTMOUSE", value="PRESS")


def _delete_forbidden_instant_keymaps() -> None:
    kc = _addon_keyconfig()
    if kc is None:
        return
    for name in _FORBIDDEN_INSTANT_KEYMAPS:
        try:
            km = kc.keymaps.get(name)
            if km is None:
                continue
            for kmi in list(_find_items(km, _INSTANT_ID)):
                try:
                    __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(km, kmi)
                except Exception:
                    try:
                        __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, False)
                    except Exception:
                        pass
        except Exception:
            continue


def _ensure_instant_keymaps(*, active: bool = True, promote: bool = False) -> tuple[int, int]:
    kc = _addon_keyconfig()
    if kc is None:
        return 0, 0
    _delete_forbidden_instant_keymaps()
    created = 0
    touched = 0
    for name, space_type in _INSTANT_KEYMAP_DEFS:
        try:
            km = kc.keymaps.get(name)
            if km is None:
                km = kc.keymaps.new(name=name, space_type=space_type, region_type="WINDOW")
            if promote:
                for old in list(_find_items(km, _INSTANT_ID)):
                    try:
                        __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(km, old)
                    except Exception:
                        try:
                            __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(old, False)
                        except Exception:
                            pass
                kmi = _new_kmi(km, _INSTANT_ID)
                created += 1
                items = [kmi]
            else:
                items = _find_items(km, _INSTANT_ID)
                if not items:
                    kmi = _new_kmi(km, _INSTANT_ID)
                    items = [kmi]
                    created += 1
            for kmi in items:
                _configure_left_press(kmi, allow_modifiers=False)
                try:
                    __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, bool(active))
                except Exception:
                    pass
                touched += 1
        except Exception:
            continue
    return created, touched


def _set_instant_keymaps_active(active: bool) -> tuple[int, int]:
    if active:
        return _ensure_instant_keymaps(active=True, promote=False)
    kc = _addon_keyconfig()
    if kc is None:
        return 0, 0
    touched = 0
    for name, _space_type in _INSTANT_KEYMAP_DEFS:
        try:
            km = kc.keymaps.get(name)
            if km is None:
                continue
            for kmi in _find_items(km, _INSTANT_ID):
                try:
                    __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, False)
                    touched += 1
                except Exception:
                    pass
        except Exception:
            continue
    _delete_forbidden_instant_keymaps()
    return 0, touched


def _delete_instant_keymaps() -> int:
    kc = _addon_keyconfig()
    if kc is None:
        return 0
    removed = 0
    for name, _space_type in _INSTANT_KEYMAP_DEFS:
        try:
            km = kc.keymaps.get(name)
            if km is None:
                continue
            for kmi in list(_find_items(km, _INSTANT_ID)):
                try:
                    __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(km, kmi)
                    removed += 1
                except Exception:
                    try:
                        __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, False)
                    except Exception:
                        pass
        except Exception:
            continue
    _delete_forbidden_instant_keymaps()
    return removed


def _instant_status() -> dict[str, int]:
    kc = _addon_keyconfig()
    expected = len(_INSTANT_KEYMAP_DEFS)
    registered = active = 0
    if kc is not None:
        for name, _space_type in _INSTANT_KEYMAP_DEFS:
            try:
                km = kc.keymaps.get(name)
                if km is None:
                    continue
                items = _find_items(km, _INSTANT_ID)
                if items:
                    registered += 1
                    if any(bool(getattr(kmi, "active", False)) for kmi in items):
                        active += 1
            except Exception:
                continue
    return {"registered": registered, "active": active, "expected": expected}


def _remove_addon_native_gizmo_tweak_rows() -> None:
    # gizmogroup.gizmo_tweak is Blender/user-owned; never inspect or modify it.
    return None


def _axis_enabled(context=None) -> bool:
    try:
        fn = _pg("_sus_1636_axis_memory_enabled")
        return bool(fn(context or bpy.context)) if callable(fn) else False
    except Exception:
        return False


def _get_axis(context=None) -> str:
    try:
        fn = _pg("_sus_1636_get_axis")
        axis = str(fn(context or bpy.context) if callable(fn) else "FREE").upper()
    except Exception:
        axis = "FREE"
    return axis if axis in {"U", "V", "FREE"} else "FREE"


def _set_axis(axis: str, context=None) -> None:
    axis = str(axis or "FREE").upper()
    if axis not in {"U", "V", "FREE"}:
        axis = "FREE"
    try:
        fn = _pg("_sus_1636_set_axis")
        if callable(fn):
            fn(axis, context or bpy.context)
            return
    except Exception:
        pass
    try:
        _PG["_SUS_1636_MEMORY_AXIS"] = axis
    except Exception:
        pass


def _record_axis_from_mode(context, mode: str) -> None:
    if not _axis_enabled(context):
        return
    mode = str(mode or "").upper()
    if mode == "MOVE_X":
        _set_axis("U", context)
    elif mode == "MOVE_Y":
        _set_axis("V", context)
    elif mode in {"MOVE", "MOVE_XY", "FREE"}:
        _set_axis("FREE", context)


def _axis_delta(context, delta: Vector, axis: str | None = None) -> Vector:
    try:
        a = str(axis or (_get_axis(context) if _axis_enabled(context) else "FREE")).upper()
        if a == "U":
            delta.y = 0.0
        elif a == "V":
            delta.x = 0.0
    except Exception:
        pass
    return delta



def _stop_axis_timer() -> None:
    try:
        timer = _pg("_sus_1636_axis_memory_timer")
        if callable(timer):
            _suv_resource.timer_unregister(timer)
    except Exception:
        pass


def _disable_axis_timer_public(context=None) -> None:
    _stop_axis_timer()


def _uv_context(context) -> bool:
    try:
        fn = _pg("_sus_1835_uv_context")
        if callable(fn):
            return bool(fn(context))
    except Exception:
        pass
    try:
        return getattr(context.area, "type", "") == "IMAGE_EDITOR" and getattr(context.region, "type", "") == "WINDOW"
    except Exception:
        return False


def _uv_mode(context) -> str:
    try:
        fn = _pg("_sus_1835_uv_mode")
        if callable(fn):
            return str(fn(context)).upper()
    except Exception:
        pass
    return "VERTEX"


def _region_to_uv(context, event):
    try:
        fn = _pg("_sus_1835_region_to_uv")
        if callable(fn):
            return fn(context, event)
    except Exception:
        pass
    try:
        x, y = context.region.view2d.region_to_view(float(event.mouse_region_x), float(event.mouse_region_y))
        return Vector((float(x), float(y)))
    except Exception:
        return None


def _uv_tolerance(context, px=10.0) -> float:
    try:
        fn = _pg("_sus_1835_uv_tolerance")
        if callable(fn):
            return float(fn(context, px))
    except Exception:
        pass
    return 1.0e-3


def _iter_edit_mesh_objects(context):
    try:
        fn = _pg("_sus_1835_iter_edit_mesh_objects")
        if callable(fn):
            yield from fn(context)
            return
    except Exception:
        pass
    try:
        objects = getattr(context, "objects_in_mode_unique_data", None)
        if objects:
            for obj in objects:
                if getattr(obj, "type", None) == "MESH" and getattr(obj, "mode", None) == "EDIT":
                    yield obj
            return
    except Exception:
        pass
    obj = getattr(context, "object", None)
    if obj is not None and getattr(obj, "type", None) == "MESH" and getattr(obj, "mode", None) == "EDIT":
        yield obj


def _cell_key(uv: Vector, cell: float):
    return (int(floor(float(uv.x) / cell)), int(floor(float(uv.y) / cell)))


def _cells_for_bbox(minx, miny, maxx, maxy, cell, max_cells=96):
    try:
        ix0 = int(floor(float(minx) / cell)); ix1 = int(floor(float(maxx) / cell))
        iy0 = int(floor(float(miny) / cell)); iy1 = int(floor(float(maxy) / cell))
        count = (ix1 - ix0 + 1) * (iy1 - iy0 + 1)
        if count > max_cells:
            return None
        for ix in range(ix0, ix1 + 1):
            for iy in range(iy0, iy1 + 1):
                yield (ix, iy)
    except Exception:
        return None


def _point_segment_distance(p, a, b):
    try:
        ab = b - a
        denom = float(ab.length_squared)
        if denom <= 1.0e-20:
            return float((p - a).length), 0.0
        t = max(0.0, min(1.0, float((p - a).dot(ab)) / denom))
        q = a + ab * t
        return float((p - q).length), t
    except Exception:
        return float("inf"), 0.0


def _point_in_poly(pt, coords) -> bool:
    fn = _pg("_sus_1835_point_in_poly")
    if callable(fn):
        try:
            return bool(fn(pt, coords))
        except Exception:
            pass
    try:
        inside = False
        n = len(coords)
        x = float(pt.x); y = float(pt.y)
        j = n - 1
        for i in range(n):
            xi = float(coords[i].x); yi = float(coords[i].y)
            xj = float(coords[j].x); yj = float(coords[j].y)
            if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / ((yj - yi) or 1.0e-20) + xi):
                inside = not inside
            j = i
        return inside
    except Exception:
        return False


def _cache_signature(context, cell: float):
    sig = []
    try:
        active = getattr(context, "object", None)
        active_name = getattr(active, "name", "")
    except Exception:
        active_name = ""
    sig.append(("cell", round(float(cell), 8), active_name))
    for obj in _iter_edit_mesh_objects(context):
        mesh = getattr(obj, "data", None)
        if mesh is None:
            continue
        try:
            sig.append((id(mesh), getattr(mesh, "name", ""), len(getattr(mesh, "polygons", []) or []), len(getattr(mesh, "loops", []) or []), len(getattr(mesh, "uv_layers", []) or [])))
        except Exception:
            sig.append((id(mesh), getattr(mesh, "name", "")))
    return tuple(sig)


def _build_hit_cache(context, cell: float):
    import bmesh
    objects = []
    for obj in _iter_edit_mesh_objects(context):
        mesh = getattr(obj, "data", None)
        if mesh is None:
            continue
        try:
            bm = bmesh.from_edit_mesh(mesh)
            bm.faces.ensure_lookup_table(); bm.faces.index_update()
            bm.edges.ensure_lookup_table(); bm.edges.index_update()
            bm.verts.ensure_lookup_table(); bm.verts.index_update()
            uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        except Exception:
            continue
        if uv_layer is None:
            continue
        uv_name = str(getattr(uv_layer, "name", "") or "")
        vgrid = defaultdict(list); egrid = defaultdict(list); fgrid = defaultdict(list)
        long_edges = []; long_faces = []
        obj_minx = obj_miny = float("inf")
        obj_maxx = obj_maxy = float("-inf")
        for f in bm.faces:
            try:
                if getattr(f, "hide", False):
                    continue
                loops = tuple(f.loops)
                coords = []
                fi = int(getattr(f, "index", -1))
                for li, l in enumerate(loops):
                    if getattr(l.vert, "hide", False) or getattr(l.edge, "hide", False):
                        continue
                    uv = l[uv_layer].uv.copy()
                    coords.append(uv)
                    obj_minx = min(obj_minx, uv.x); obj_miny = min(obj_miny, uv.y)
                    obj_maxx = max(obj_maxx, uv.x); obj_maxy = max(obj_maxy, uv.y)
                    vgrid[_cell_key(uv, cell)].append({"mode": "VERTEX", "mesh": mesh, "uv_layer_name": uv_name, "uv": uv, "face": fi, "local": li, "vert_index": int(getattr(l.vert, "index", -1))})
                    try:
                        b = l.link_loop_next[uv_layer].uv.copy()
                        minx = min(uv.x, b.x); miny = min(uv.y, b.y); maxx = max(uv.x, b.x); maxy = max(uv.y, b.y)
                        rec = {"mode": "EDGE", "mesh": mesh, "uv_layer_name": uv_name, "uv": (uv + b) * 0.5, "face": fi, "local": li, "edge_index": int(getattr(l.edge, "index", -1)), "a": uv, "b": b}
                        cells = _cells_for_bbox(minx - cell, miny - cell, maxx + cell, maxy + cell, cell)
                        if cells is None:
                            long_edges.append(rec)
                        else:
                            for ck in cells:
                                egrid[ck].append(rec)
                    except Exception:
                        pass
                if len(coords) >= 3:
                    minx = min(c.x for c in coords); miny = min(c.y for c in coords)
                    maxx = max(c.x for c in coords); maxy = max(c.y for c in coords)
                    frec = {"mode": "FACE", "mesh": mesh, "uv_layer_name": uv_name, "uv": sum(coords, Vector((0.0, 0.0))) / len(coords), "face": fi, "local": 0, "coords": coords, "bbox": (minx, miny, maxx, maxy)}
                    cells = _cells_for_bbox(minx, miny, maxx, maxy, cell, max_cells=256)
                    if cells is None:
                        long_faces.append(frec)
                    else:
                        for ck in cells:
                            fgrid[ck].append(frec)
            except Exception:
                continue
        if obj_minx == float("inf"):
            continue
        objects.append({"mesh": mesh, "uv_layer_name": uv_name, "bbox": (obj_minx, obj_miny, obj_maxx, obj_maxy), "vgrid": vgrid, "egrid": egrid, "fgrid": fgrid, "long_edges": long_edges, "long_faces": long_faces})
    return {"cell": cell, "sig": _cache_signature(context, cell), "objects": objects}


def _get_hit_cache(context, tol: float):
    global _HIT_CACHE, _LAST_CACHE_TOL
    cell = max(float(tol) * 4.0, 1.0e-5)
    sig = _cache_signature(context, cell)
    try:
        if _HIT_CACHE and _HIT_CACHE.get("sig") == sig and not _DIRTY_MESH_IDS:
            return _HIT_CACHE
    except Exception:
        pass
    try:
        _HIT_CACHE = _build_hit_cache(context, cell)
        _LAST_CACHE_TOL = tol
    except Exception:
        _HIT_CACHE = {"cell": cell, "sig": sig, "objects": []}
    _DIRTY_MESH_IDS.clear()
    return _HIT_CACHE


def _neighbor_cells(ck):
    ix, iy = ck
    for dx in (-1, 0, 1):
        for dy in (-1, 0, 1):
            yield (ix + dx, iy + dy)


def _find_uv_hit_fast(context, event):
    if not _uv_context(context):
        return None
    mouse_uv = _region_to_uv(context, event)
    if mouse_uv is None:
        return None
    mode = _uv_mode(context)
    tol = _uv_tolerance(context, 10.0)
    cache = _get_hit_cache(context, tol)
    cell = float(cache.get("cell", max(tol * 4.0, 1.0e-5)))
    ck = _cell_key(mouse_uv, cell)
    best = None
    best_d = float("inf")
    if mode == "VERTEX":
        seen = set()
        for obj in cache.get("objects", []):
            for nck in _neighbor_cells(ck):
                for rec in obj.get("vgrid", {}).get(nck, []):
                    key = (id(rec.get("mesh")), rec.get("face"), rec.get("local"))
                    if key in seen:
                        continue
                    seen.add(key)
                    try:
                        d = float((rec["uv"] - mouse_uv).length)
                        if d <= tol and d < best_d:
                            best_d = d; best = dict(rec)
                    except Exception:
                        pass
        return best
    if mode == "EDGE":
        seen = set()
        for obj in cache.get("objects", []):
            candidates = []
            for nck in _neighbor_cells(ck):
                candidates.extend(obj.get("egrid", {}).get(nck, []))
            candidates.extend(obj.get("long_edges", []))
            for rec in candidates:
                key = (id(rec.get("mesh")), rec.get("face"), rec.get("local"))
                if key in seen:
                    continue
                seen.add(key)
                try:
                    d, t = _point_segment_distance(mouse_uv, rec["a"], rec["b"])
                    if d <= tol and d < best_d:
                        best_d = d
                        hit = dict(rec)
                        hit["uv"] = rec["a"].lerp(rec["b"], t)
                        best = hit
                except Exception:
                    pass
        return best
    # FACE / ISLAND
    for obj in cache.get("objects", []):
        candidates = list(obj.get("fgrid", {}).get(ck, [])) + list(obj.get("long_faces", []))
        for rec in candidates:
            try:
                minx, miny, maxx, maxy = rec.get("bbox", (0, 0, 0, 0))
                if mouse_uv.x < minx or mouse_uv.x > maxx or mouse_uv.y < miny or mouse_uv.y > maxy:
                    continue
                if _point_in_poly(mouse_uv, rec.get("coords", [])):
                    coords = rec.get("coords", [])
                    area = abs(sum(coords[i].x * coords[(i + 1) % len(coords)].y - coords[(i + 1) % len(coords)].x * coords[i].y for i in range(len(coords)))) if coords else 0.0
                    if best is None or area < best_d:
                        best_d = area
                        hit = dict(rec)
                        hit["mode"] = mode
                        hit["uv"] = mouse_uv.copy()
                        hit.pop("coords", None); hit.pop("bbox", None)
                        best = hit
            except Exception:
                pass
    return best


def _collect_batches_from_hit(context, hit):
    if not hit:
        return []
    try:
        import bmesh
    except Exception:
        return []
    mesh = hit.get("mesh")
    if mesh is None:
        return []
    try:
        bm = bmesh.from_edit_mesh(mesh)
        bm.faces.ensure_lookup_table()
        uv_name = str(hit.get("uv_layer_name", "") or "")
        uv_layer = bm.loops.layers.uv.get(uv_name) if uv_name else None
        if uv_layer is None:
            uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
    except Exception:
        return []
    recs = []
    seen = set()
    def add_loop(l):
        try:
            f = l.face
            fi = int(getattr(f, "index", -1))
            loops = tuple(f.loops)
            li = loops.index(l)
            key = (fi, li)
            if key in seen:
                return
            seen.add(key)
            recs.append((fi, li, l[uv_layer].uv.copy()))
        except Exception:
            pass
    try:
        mode = str(hit.get("mode") or _uv_mode(context)).upper()
        fi = int(hit.get("face", -1)); li = int(hit.get("local", -1))
        face = bm.faces[fi]
        loops = tuple(face.loops)
        loop = loops[li]
        if mode == "EDGE":
            add_loop(loop); add_loop(loop.link_loop_next)
        elif mode in {"FACE", "ISLAND"}:
            if mode == "ISLAND":
                island_fn = _pg("_sus_1674_uv_island_faces")
                faces = island_fn(face, uv_layer) if callable(island_fn) else {face}
            else:
                faces = {face}
            for f in faces:
                for l in f.loops:
                    add_loop(l)
        else:
            # Same visual UV vertex: same 3D vertex + same UV coordinate only.
            target_uv = loop[uv_layer].uv.copy()
            for other in loop.vert.link_loops:
                try:
                    if (other[uv_layer].uv - target_uv).length <= 1.0e-7:
                        add_loop(other)
                except Exception:
                    pass
    except Exception:
        pass
    if not recs:
        return []
    return [{"mesh": mesh, "uv_layer_name": str(getattr(uv_layer, "name", uv_name) or uv_name), "loops": recs}]


def _cache_batches(context, batches):
    try:
        import bmesh
    except Exception:
        return list(batches or [])
    cached = []
    for batch in list(batches or []):
        mesh = batch.get("mesh") if isinstance(batch, dict) else None
        if mesh is None:
            continue
        try:
            bm = bmesh.from_edit_mesh(mesh)
            bm.faces.ensure_lookup_table()
            uv_name = str(batch.get("uv_layer_name", "") or "")
            uv_layer = bm.loops.layers.uv.get(uv_name) if uv_name else None
            if uv_layer is None:
                uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        except Exception:
            continue
        refs = []
        seen = set()
        for rec in list(batch.get("loops", []) or []):
            try:
                fi, li, original = rec
                face = bm.faces[int(fi)]
                loops = tuple(face.loops)
                li = int(li)
                if li < 0 or li >= len(loops):
                    continue
                loop = loops[li]
                key = (int(fi), li, str(getattr(uv_layer, "name", "") or ""))
                if key in seen:
                    continue
                seen.add(key)
                refs.append((loop, uv_layer, original.copy()))
            except Exception:
                continue
        if refs:
            cached.append({"mesh": mesh, "uv_layer_name": str(getattr(uv_layer, "name", "") or ""), "refs": refs, "loops": batch.get("loops", ())})
    return cached


def _resolved_batch_refs(batch):
    """Resolve stable face/loop records from the public grip invoke path.

    Older cached callers also retain ``refs``; only use those when stable
    records are unavailable. Resolve edit BMesh data afresh on each event.
    """
    records = batch.get("loops")
    if records is None:
        return list(batch.get("refs", []) or [])
    import bmesh
    bm = bmesh.from_edit_mesh(batch["mesh"])
    bm.faces.ensure_lookup_table()
    name = batch.get("uv_layer_name", "")
    layer = bm.loops.layers.uv.get(name) if name else bm.loops.layers.uv.active
    if layer is None:
        raise RuntimeError("UV ギズモのドラッグ中に UV レイヤーが変更されました")
    return [(bm.faces[int(fi)].loops[int(li)], layer, original)
            for fi, li, original in records]


def _apply_cached_delta(context, batches, delta: Vector) -> bool:
    try:
        import bmesh
    except Exception:
        return False
    try:
        dx = float(delta.x); dy = float(delta.y)
    except Exception:
        dx = dy = 0.0
    changed_meshes = []
    seen_meshes = set()
    for batch in list(batches or []):
        mesh = batch.get("mesh") if isinstance(batch, dict) else None
        if mesh is None:
            continue
        wrote = False
        for loop, uv_layer, original in _resolved_batch_refs(batch):
            try:
                uv = loop[uv_layer].uv
                uv.x = float(original.x) + dx
                uv.y = float(original.y) + dy
                wrote = True
            except (ReferenceError, RuntimeError):
                continue
            except Exception:
                continue
        if wrote and id(mesh) not in seen_meshes:
            seen_meshes.add(id(mesh))
            changed_meshes.append(mesh)
            _DIRTY_MESH_IDS.add(id(mesh))
    for mesh in changed_meshes:
        try:
            bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        except TypeError:
            try: bmesh.update_edit_mesh(mesh)
            except Exception: pass
        except Exception:
            pass
    try:
        area = getattr(context, "area", None)
        if area is not None:
            area.tag_redraw()
    except Exception:
        pass
    return bool(changed_meshes)


def _apply_cached_transform(context, batches, transform_func) -> bool:
    try:
        import bmesh
    except Exception:
        return False
    changed_meshes = []
    seen_meshes = set()
    for batch in list(batches or []):
        mesh = batch.get("mesh") if isinstance(batch, dict) else None
        if mesh is None:
            continue
        wrote = False
        for loop, uv_layer, original in _resolved_batch_refs(batch):
            try:
                loop[uv_layer].uv = transform_func(original)
                wrote = True
            except (ReferenceError, RuntimeError):
                continue
            except Exception:
                continue
        if wrote and id(mesh) not in seen_meshes:
            seen_meshes.add(id(mesh))
            changed_meshes.append(mesh)
            _DIRTY_MESH_IDS.add(id(mesh))
    for mesh in changed_meshes:
        try:
            bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        except TypeError:
            try: bmesh.update_edit_mesh(mesh)
            except Exception: pass
        except Exception:
            pass
    try:
        area = getattr(context, "area", None)
        if area is not None:
            area.tag_redraw()
    except Exception:
        pass
    return bool(changed_meshes)


def _delta_key(delta: Vector):
    try:
        return (round(float(delta.x), 10), round(float(delta.y), 10))
    except Exception:
        return None


def _instant_invoke(self, context, event):
    try:
        enabled_fn = _pg("_sus_1635_immediate_enabled")
        if callable(enabled_fn) and not enabled_fn(context):
            return {"PASS_THROUGH"}
    except Exception:
        return {"PASS_THROUGH"}
    if str(getattr(event, "type", "") or "") != "LEFTMOUSE" or str(getattr(event, "value", "") or "") != "PRESS":
        return {"PASS_THROUGH"}
    if not _uv_context(context):
        return {"PASS_THROUGH"}
    # Do not run on real gizmo handles.  This preserves U/V axis constrained drags.
    try:
        if _gizmo_handle_hit_fast(context, event):
            return {"PASS_THROUGH"}
    except Exception:
        pass
    hit = _find_uv_hit_fast(context, event)
    if not hit:
        return {"PASS_THROUGH"}
    hit_selected_fn = _pg("_sus_1835_hit_selected")
    selected = False
    if callable(hit_selected_fn):
        try: selected = bool(hit_selected_fn(context, hit))
        except Exception: selected = False
    shift_ctrl = bool(getattr(event, "shift", False) or getattr(event, "ctrl", False))
    just_selected = False
    if (not selected) or shift_ctrl:
        select_hit = _pg("_sus_1835_select_hit")
        if not callable(select_hit):
            return {"PASS_THROUGH"}
        try:
            if not select_hit(context, hit, event):
                return {"PASS_THROUGH"}
            just_selected = not shift_ctrl
        except Exception:
            return {"PASS_THROUGH"}
    try:
        if just_selected:
            batches = _collect_batches_from_hit(context, hit)
        else:
            collect = _pg("_sus_1835_collect_batches")
            batches = collect(context, hit) if callable(collect) else []
        batches = _cache_batches(context, batches)
    except Exception:
        batches = []
    if not batches:
        return {"PASS_THROUGH"}
    try:
        self._suv1844_batches = batches
        self._suv1844_start_uv = _region_to_uv(context, event)
        self._suv1844_start_xy = (int(getattr(event, "mouse_region_x", 0) or 0), int(getattr(event, "mouse_region_y", 0) or 0))
        self._suv1844_dragging = False
        self._suv1844_last_delta_key = None
        self._suv1844_axis = _get_axis(context) if _axis_enabled(context) else "FREE"
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}
    except Exception:
        return {"FINISHED"}


def _instant_modal(self, context, event):
    etype = str(getattr(event, "type", "") or "")
    evalue = str(getattr(event, "value", "") or "")
    if etype in {"ESC", "RIGHTMOUSE"}:
        return {"CANCELLED"}
    if etype == "LEFTMOUSE" and evalue == "RELEASE":
        return {"FINISHED"}
    if etype in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
        try:
            cur = _region_to_uv(context, event)
            start = getattr(self, "_suv1844_start_uv", None)
            if cur is None or start is None:
                return {"RUNNING_MODAL"}
            sx, sy = getattr(self, "_suv1844_start_xy", (0, 0))
            dx = int(getattr(event, "mouse_region_x", 0) or 0) - int(sx)
            dy = int(getattr(event, "mouse_region_y", 0) or 0) - int(sy)
            if not bool(getattr(self, "_suv1844_dragging", False)):
                if (dx * dx + dy * dy) ** 0.5 < 3.0:
                    return {"RUNNING_MODAL"}
                self._suv1844_dragging = True
            delta = Vector((float(cur.x - start.x), float(cur.y - start.y)))
            delta = _axis_delta(context, delta, getattr(self, "_suv1844_axis", "FREE"))
            snap = _pg("_sus_1674_snap_delta")
            if callable(snap):
                try: delta = snap(context, delta)
                except Exception: pass
            key = _delta_key(delta)
            if key is not None and key == getattr(self, "_suv1844_last_delta_key", None):
                return {"RUNNING_MODAL"}
            self._suv1844_last_delta_key = key
            _apply_cached_delta(context, getattr(self, "_suv1844_batches", []) or [], delta)
            return {"RUNNING_MODAL"}
        except Exception:
            return {"FINISHED"}
    return {"RUNNING_MODAL"}


def _patch_instant_class() -> None:
    try:
        cls = _pg("SMARTUVSUITE_OT_instant_select_drag_move")
        if not isinstance(cls, type):
            return
        cls.bl_options = {'UNDO', 'BLOCKING'}
        cls.invoke = _instant_invoke
        cls.modal = _instant_modal
        cls._find_uv_hit = lambda self, context, event: _find_uv_hit_fast(context, event)
        cls._integrated_uv_gizmo_grip_should_own_press = lambda self, context, event: _gizmo_handle_hit_fast(context, event)
    except Exception:
        pass


def _gizmo_handle_hit_fast(context, event) -> bool:
    try:
        from . import uv_gizmo_grip_fix as g
        if not getattr(g, "is_enabled", lambda: False)():
            return False
        if not _uv_context(context):
            return False
        if bool(getattr(event, "shift", False) or getattr(event, "ctrl", False) or getattr(event, "alt", False) or getattr(event, "oskey", False)):
            return False
        press_uv = g._region_to_view(context.region, event.mouse_region_x, event.mouse_region_y)
        batches, stats = g._collect_selected_uv_state(context, anchor_uv=press_uv)
        if not batches or not stats:
            return False
        pivot_uv = g._selected_uv_pivot(context, stats)
        if pivot_uv is None:
            return False
        pivot_region = g._view_to_region(context.region, pivot_uv)
        return g._hit_test_fallback_area(context, event, pivot_region) is not None
    except Exception:
        return False


def _gizmo_collect_selected_uv_state(context, anchor_uv=None):
    # First use the precise previous collector.  It is already mode-aware.
    try:
        fn = _pg("_sus_1834_collect_selected_uv_state") or _pg("_sus_1835_collect_batches")
    except Exception:
        fn = None
    if callable(fn) and getattr(fn, "__name__", "") == "_sus_1834_collect_selected_uv_state":
        try:
            return fn(context, anchor_uv=anchor_uv)
        except Exception:
            pass
    try:
        from . import uv_gizmo_grip_fix as g
        return g._sus_1835_collect_selected_uv_state(context, anchor_uv=anchor_uv)
    except Exception:
        return [], None


def _patch_gizmo_module() -> None:
    try:
        from . import uv_gizmo_grip_fix as g
    except Exception:
        return
    try:
        g._sus_1835_apply_patch()
    except Exception:
        pass
    try:
        g._NATIVE_GIZMO_KEYMAP_NAMES = ("Generic Gizmo", "Generic Gizmo Maybe Drag")
    except Exception:
        pass

    def _gizmo_apply_cached(self, context, transform_func):
        return _apply_cached_transform(context, getattr(self, "_suv1844_batches", []) or getattr(self, "_batches", []) or [], transform_func)

    def _gizmo_restore_cached(self, context):
        return _apply_cached_transform(context, getattr(self, "_suv1844_batches", []) or getattr(self, "_batches", []) or [], lambda original: original.copy())

    def _gizmo_invoke_cached(self, context, event):
        if str(getattr(event, "type", "") or "") != "LEFTMOUSE" or str(getattr(event, "value", "") or "") != "PRESS":
            return {"PASS_THROUGH"}
        try:
            if g._event_has_selection_modifier(event) or not g.is_enabled():
                return {"PASS_THROUGH"}
            if not g._is_uv_editor_context(context) or not hasattr(context.region, "view2d"):
                return {"PASS_THROUGH"}
        except Exception:
            return {"PASS_THROUGH"}
        try:
            press_uv = g._region_to_view(context.region, event.mouse_region_x, event.mouse_region_y)
        except Exception:
            press_uv = None
        try:
            batches, stats = g._collect_selected_uv_state(context, anchor_uv=press_uv)
        except Exception:
            batches, stats = [], None
        if not batches or not stats:
            return {"PASS_THROUGH"}
        try:
            pivot_uv = g._selected_uv_pivot(context, stats)
            pivot_region = g._view_to_region(context.region, pivot_uv) if pivot_uv is not None else None
            mode = g._hit_test_fallback_area(context, event, pivot_region) if pivot_region is not None else None
        except Exception:
            mode = None
        if mode is None:
            return {"PASS_THROUGH"}
        _record_axis_from_mode(context, mode)
        try:
            self._area = context.area
            self._region = context.region
            self._suv1844_batches = _cache_batches(context, batches)
            self._batches = self._suv1844_batches
            self._pivot_uv = pivot_uv
            self._mode = mode
            self._start_mouse_view = g._region_to_view(self._region, event.mouse_region_x, event.mouse_region_y)
            self._start_vector = self._start_mouse_view - self._pivot_uv
            self._suv1844_last_delta_key = None
            context.window_manager.modal_handler_add(self)
            return {"RUNNING_MODAL"}
        except Exception:
            return {"PASS_THROUGH"}

    def _gizmo_apply_mode_cached(self, context, current_view):
        mode = str(getattr(self, "_mode", "") or "")
        if mode.startswith("MOVE"):
            delta = current_view - self._start_mouse_view
            if mode == "MOVE_X":
                delta.y = 0.0
            elif mode == "MOVE_Y":
                delta.x = 0.0
            try:
                delta = g._snap_uv_delta_relative_to_cursor(context, delta)
            except Exception:
                snap = _pg("_sus_1674_snap_delta")
                if callable(snap):
                    try: delta = snap(context, delta)
                    except Exception: pass
            key = _delta_key(delta)
            if key is not None and key == getattr(self, "_suv1844_last_delta_key", None):
                return None
            self._suv1844_last_delta_key = key
            _apply_cached_delta(context, getattr(self, "_suv1844_batches", []) or getattr(self, "_batches", []) or [], delta)
            return None
        try:
            old = getattr(type(self), "_suv1844_original_apply_mode", None)
            if callable(old):
                return old(self, context, current_view)
        except Exception:
            return None

    try:
        op = g.JELARARAGI_OT_uv_gizmo_grip_fix_grab
        if not hasattr(op, "_suv1844_original_apply_mode"):
            op._suv1844_original_apply_mode = getattr(op, "_apply_mode", None)
        op.invoke = _gizmo_invoke_cached
        op._apply_to_uvs = _gizmo_apply_cached
        op._restore_original_uvs = _gizmo_restore_cached
        op._apply_mode = _gizmo_apply_mode_cached
    except Exception:
        pass
    try:
        g._collect_selected_uv_state = _gizmo_collect_selected_uv_state
    except Exception:
        pass
    try:
        snap = _pg("_sus_1674_snap_delta")
        if callable(snap):
            g._snap_uv_delta_relative_to_cursor = lambda context, delta: snap(context, delta)
    except Exception:
        pass


def _apply_axis_memory_public(context, delta):
    try:
        return _axis_delta(context, delta)
    except Exception:
        return delta


def _patch_keymap_helpers() -> None:
    if not isinstance(_PG, dict):
        return
    _PG["_SUS_1635_INSTANT_SELECT_KEYMAP_NAMES"] = tuple(name for name, _space in _INSTANT_KEYMAP_DEFS)
    _PG["_sus_1652_instant_keymap_names"] = lambda: tuple(name for name, _space in _INSTANT_KEYMAP_DEFS)
    _PG["_sus_1831_instant_keymap_names"] = lambda: tuple(name for name, _space in _INSTANT_KEYMAP_DEFS)
    _PG["_sus_1652_ensure_instant_keymaps"] = _ensure_instant_keymaps
    _PG["_sus_1652_promote_instant_keymaps_to_head"] = lambda active=True: _ensure_instant_keymaps(active=bool(active), promote=True)
    _PG["_sus_1652_set_instant_keymaps_active"] = _set_instant_keymaps_active
    _PG["_sus_1652_delete_instant_keymaps"] = _delete_instant_keymaps
    _PG["_sus_1652_instant_status"] = _instant_status
    _PG["_sus_update_axis_constraint_memory_timer"] = _disable_axis_timer_public
    _PG["_sus_1674_apply_axis_memory"] = _apply_axis_memory_public
    _PG["_sus_1835_find_uv_hit"] = _find_uv_hit_fast


def apply_all(pkg_globals=None, context=None) -> None:
    global _PG
    if pkg_globals is not None:
        _PG = pkg_globals
    try:
        bi = _PG.get("bl_info") if isinstance(_PG, dict) else None
        if isinstance(bi, dict):
            bi["version"] = (1, 0, 0)
    except Exception:
        pass
    _patch_keymap_helpers()
    _stop_axis_timer()
    _remove_addon_native_gizmo_tweak_rows()
    _patch_gizmo_module()
    _patch_instant_class()


def _sync_keymaps(context=None):
    ctx = context or bpy.context
    _patch_keymap_helpers()
    try:
        ws_fn = _PG.get("_sus_1652_ws") if isinstance(_PG, dict) else None
        ws = ws_fn(ctx) if callable(ws_fn) else None
    except Exception:
        ws = None
    instant = bool(getattr(ws, "operation_instant_select_enabled", False)) if ws is not None else False
    gizmo = bool(getattr(ws, "operation_uv_gizmo_grip_fix_enabled", False)) if ws is not None else False
    if instant:
        _ensure_instant_keymaps(active=True, promote=True)
    else:
        _set_instant_keymaps_active(False)
    try:
        from . import uv_gizmo_grip_fix as g
        if gizmo:
            # Use the module to ensure fallback rows, then remove the add-on native
            # transform rows.  The Smart UV fallback handles U/V/free directly.
            g.set_enabled(True)
            try:
                set_active = _PG.get("_sus_1652_set_gizmo_keymaps_active") if isinstance(_PG, dict) else None
                if callable(set_active): set_active(True)
            except Exception:
                pass
        else:
            try:
                disable = _PG.get("_sus_1652_gizmo_disable") if isinstance(_PG, dict) else None
                if callable(disable): disable(delete=False)
                else: g._ENABLED = False
            except Exception:
                pass
    except Exception:
        pass
    _remove_addon_native_gizmo_tweak_rows()
    apply_all(_PG, ctx)


def install(pkg_globals):
    global _PG, _INSTALLED, _PREV_SYNC
    _PG = pkg_globals
    if not _INSTALLED:
        _PREV_SYNC = pkg_globals.get("_sus_1652_sync_keymaps_from_workspace")
        pkg_globals["_sus_1652_sync_keymaps_from_workspace"] = _sync_keymaps
        _INSTALLED = True
    apply_all(pkg_globals, bpy.context)

# 1.8.44b: no timer/no native-gizmo-keymap lightweight UV Gizmo enable path.
_GIZMO_KEYMAP_DEFS: tuple[tuple[str, str], ...] = (
    ("Image", "IMAGE_EDITOR"),
    ("Generic Gizmo", "EMPTY"),
    ("Generic Gizmo Maybe Drag", "EMPTY"),
)


def _ensure_gizmo_keymaps(*, active: bool = True, promote: bool = True) -> tuple[int, int]:
    del promote
    try:
        from . import uv_gizmo_grip_fix as _gizmo
        _gizmo.set_enabled(bool(active))
        return (0, len(_gizmo.owned_keymap_items()))
    except Exception:
        return (0, 0)


def _set_gizmo_keymaps_active(active: bool) -> None:
    try:
        from . import uv_gizmo_grip_fix as _gizmo
        _gizmo.set_enabled(bool(active))
    except Exception:
        pass
    return None


def _delete_gizmo_keymaps() -> None:
    try:
        from . import uv_gizmo_grip_fix as _gizmo
        _gizmo.set_enabled(False)
    except Exception:
        pass
    try:
        from . import ownership_runtime_18168 as _ownership
        return _ownership.remove_owned_keymaps(_GIZMO_ID)
    except Exception:
        return 0


def _gizmo_status() -> dict[str, int]:
    kc = _addon_keyconfig()
    expected = len(_GIZMO_KEYMAP_DEFS)
    registered = active = 0
    if kc is not None:
        for name, _space_type in _GIZMO_KEYMAP_DEFS:
            try:
                km = kc.keymaps.get(name)
                if km is None: continue
                items = _find_items(km, _GIZMO_ID)
                if items:
                    registered += 1
                    if any(bool(getattr(kmi, "active", False)) for kmi in items): active += 1
            except Exception:
                continue
    return {"registered": registered, "active": active, "expected": expected}


def _gizmo_enable_light() -> None:
    try:
        from . import uv_gizmo_grip_fix as g
        g._ENABLED = True
        # Kill background repair from the bundled source add-on.  Smart UV Suite
        # owns the keymaps now and only while the checkbox is on.
        try:
            if getattr(g, '_load_post_reapply', None) in bpy.app.handlers.load_post:
                _suv_resource.handler_remove(bpy.app.handlers.load_post, g._load_post_reapply)
        except Exception: pass
        try:
            timer = getattr(g, '_deferred_reapply_timer', None)
            if callable(timer) and _suv_resource.timer_is_registered(timer):
                _suv_resource.timer_unregister(timer)
        except Exception: pass
    except Exception:
        pass
    _ensure_gizmo_keymaps(active=True, promote=True)


def _gizmo_disable_light(*, delete: bool = False) -> None:
    try:
        from . import uv_gizmo_grip_fix as g
        g._ENABLED = False
        try:
            if getattr(g, '_load_post_reapply', None) in bpy.app.handlers.load_post:
                _suv_resource.handler_remove(bpy.app.handlers.load_post, g._load_post_reapply)
        except Exception: pass
        try:
            timer = getattr(g, '_deferred_reapply_timer', None)
            if callable(timer) and _suv_resource.timer_is_registered(timer):
                _suv_resource.timer_unregister(timer)
        except Exception: pass
    except Exception:
        pass
    if delete:
        _delete_gizmo_keymaps()
    else:
        _set_gizmo_keymaps_active(False)


def _patch_keymap_helpers() -> None:  # type: ignore[no-redef]
    if not isinstance(_PG, dict):
        return
    _PG["_SUS_1635_INSTANT_SELECT_KEYMAP_NAMES"] = tuple(name for name, _space in _INSTANT_KEYMAP_DEFS)
    _PG["_sus_1652_instant_keymap_names"] = lambda: tuple(name for name, _space in _INSTANT_KEYMAP_DEFS)
    _PG["_sus_1831_instant_keymap_names"] = lambda: tuple(name for name, _space in _INSTANT_KEYMAP_DEFS)
    _PG["_sus_1652_ensure_instant_keymaps"] = _ensure_instant_keymaps
    _PG["_sus_1652_promote_instant_keymaps_to_head"] = lambda active=True: _ensure_instant_keymaps(active=bool(active), promote=True)
    _PG["_sus_1652_set_instant_keymaps_active"] = _set_instant_keymaps_active
    _PG["_sus_1652_delete_instant_keymaps"] = _delete_instant_keymaps
    _PG["_sus_1652_instant_status"] = _instant_status
    _PG["_sus_1652_gizmo_status"] = _gizmo_status
    _PG["_sus_1652_set_gizmo_keymaps_active"] = _set_gizmo_keymaps_active
    _PG["_sus_1652_gizmo_enable"] = _gizmo_enable_light
    _PG["_sus_1652_gizmo_disable"] = _gizmo_disable_light
    _PG["_sus_1652_delete_gizmo_keymaps"] = _delete_gizmo_keymaps
    _PG["_sus_update_axis_constraint_memory_timer"] = _disable_axis_timer_public
    _PG["_sus_1674_apply_axis_memory"] = _apply_axis_memory_public
    _PG["_sus_1835_find_uv_hit"] = _find_uv_hit_fast


def _sync_keymaps(context=None):  # type: ignore[no-redef]
    ctx = context or bpy.context
    _patch_keymap_helpers()
    try:
        ws_fn = _PG.get("_sus_1652_ws") if isinstance(_PG, dict) else None
        ws = ws_fn(ctx) if callable(ws_fn) else None
    except Exception:
        ws = None
    instant = bool(getattr(ws, "operation_instant_select_enabled", False)) if ws is not None else False
    gizmo = bool(getattr(ws, "operation_uv_gizmo_grip_fix_enabled", False)) if ws is not None else False
    if instant:
        _ensure_instant_keymaps(active=True, promote=True)
    else:
        _set_instant_keymaps_active(False)
    if gizmo:
        _gizmo_enable_light()
    else:
        _gizmo_disable_light(delete=False)
    _stop_axis_timer()
    apply_all(_PG, ctx)

# Reinstall the final sync if this module was imported before the 1.8.44b
# definitions above were evaluated.
def install(pkg_globals):  # type: ignore[no-redef]
    global _PG, _INSTALLED, _PREV_SYNC
    _PG = pkg_globals
    if not _INSTALLED:
        _PREV_SYNC = pkg_globals.get("_sus_1652_sync_keymaps_from_workspace")
        _INSTALLED = True
    pkg_globals["_sus_1652_sync_keymaps_from_workspace"] = _sync_keymaps
    apply_all(pkg_globals, bpy.context)
