"""Machine-readable SmartTools N-panel and persistence contract."""

CONTRACT_VERSION = 1
EXTENSION_ID = 'smart_uv_suite'
CONFIG_FOLDER = 'Smart_UV_Suite'
CONFIG_FILE = 'Smart_UV_Suite.json'
STATE_SAVE_PATH = 'window_manager.uv_suite_tool_runtime_settings_v520.npanel_state_save'
SECTION_OPEN_PATH = 'window_manager.uv_suite_tool_runtime_settings_v520.show_always_on_toggles'
RUNTIME_TOGGLE_PATHS = (
    'window_manager.uv_suite_tool_runtime_settings_v520.always_on_blender_live_unwrap',
    'window_manager.uv_suite_tool_runtime_settings_v520.always_on_blender_uv_sync',
    'window_manager.uv_suite_tool_runtime_settings_v520.always_on_smart_auto_uv_sync',
    'window_manager.uv_suite_tool_runtime_settings_v520.always_on_smart_realtime_unwrap',
    'window_manager.uv_suite_tool_runtime_settings_v520.always_on_npanel_repair',
    'window_manager.uv_suite_tool_runtime_settings_v520.always_on_image_editor_ui_mode_repair',
    'window_manager.uv_suite_tool_runtime_settings_v520.always_on_smart_tools_manager_patch',
    'window_manager.uv_suite_tool_runtime_settings_v520.always_on_legacy_panel_cleanup',
    'window_manager.uv_suite_tool_runtime_settings_v520.always_on_transform_persistence_guard',
    'window_manager.uv_suite_tool_runtime_settings_v520.always_on_blender_510_guard',
    'scene.suv_workspace.operation_instant_select_enabled',
    'scene.suv_workspace.operation_axis_constraint_memory_enabled',
    'scene.suv_workspace.operation_uv_gizmo_grip_fix_enabled',
)
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = ()
ROOT_PANEL_IDS = (
    'SMARTUVSUITE_PT_1881_view3d_body',
    'SMARTUVSUITE_PT_1881_uv_editor_body',
)
PERSISTENCE_ROOTS = (
    'window_manager.uv_suite_tool_runtime_settings_v520',
    'scene.suv_workspace',
)
EXCLUDED_TRANSIENT_PATHS = (
    'window_manager.uv_suite_tool_runtime_settings_v520.name',
    'scene.suv_workspace.name',
    'scene.suv_workspace.ui_mode',
    'scene.suv_workspace.smart_standard_core_resolved_unwrap_mode',
    'scene.suv_workspace.smart_standard_core_last_actual_unwrap_mode',
    'scene.suv_workspace.scan_has_result',
    'scene.suv_workspace.scan_time',
    'scene.suv_workspace.scan_scope',
    'scene.suv_workspace.scan_eps_zero',
    'scene.suv_workspace.scan_check_out',
    'scene.suv_workspace.scan_check_overlap',
    'scene.suv_workspace.scan_precise_overlap',
    'scene.suv_workspace.scan_uv_name',
    'scene.suv_workspace.scan_mesh_count',
    'scene.suv_workspace.scan_flipped_count',
    'scene.suv_workspace.scan_zero_count',
    'scene.suv_workspace.scan_out_count',
    'scene.suv_workspace.scan_overlap_count',
    'scene.suv_workspace.scan_stretch_count',
    'scene.suv_workspace.scan_stretch_worst',
    'scene.suv_workspace.scan_stretch_avg',
    'scene.suv_workspace.health_status',
    'scene.suv_workspace.health_message',
    'scene.suv_workspace.health_checked_time',
    'scene.suv_workspace.health_issue_count',
    'scene.suv_workspace.health_missing_uv_count',
    'scene.suv_workspace.health_missing_active_uv_count',
    'scene.suv_workspace.health_icon_count',
    'scene.suv_workspace.health_cache_entries',
    'scene.suv_workspace.health_last_operator',
    'scene.suv_workspace.health_last_error',
    'scene.suv_workspace.last_snapshot_name',
    'scene.suv_workspace.batch_last_summary',
    # Operation results and context selectors are rebuilt from the active mesh.
    'scene.suv_workspace.unwrap_map_channel_name',
    'scene.suv_workspace.map_channel_object_name',
    'scene.suv_workspace.scan_flipped',
    'scene.suv_workspace.scan_zero',
    'scene.suv_workspace.scan_out',
    'scene.suv_workspace.scan_overlap',
    'scene.suv_workspace.scan_stretch',
)
PERSISTED_DYNAMIC_RNA_PATTERNS = ()
