# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
from . import addon_runtime as _prev

_IGNORE_KEYS = {
    '__name__', '__package__', '__loader__', '__spec__', '__file__', '__cached__', '__builtins__'
}
globals().update({k: v for k, v in _prev.__dict__.items() if k not in _IGNORE_KEYS})

# Keep metadata aligned with the packaged build.
_SUITE_PUBLIC_VERSION = (1, 0, 0)
try:
    if isinstance(globals().get('bl_info', None), dict):
        bl_info['version'] = _SUITE_PUBLIC_VERSION
        bl_info['description'] = (
            'Integrated UV workflow suite with a standard UV Suite N-panel workspace, control center, '
            'guided actions, bilingual help, QA, packing, trim, atlas, and compatibility bridges.'
        )
except Exception:
    pass

_TEXT.update({
    "ui.section.control_center": ("Control Center", "コントロールセンター"),
    "ui.control_center.hint": (
        "Read the current phase, UV readiness and safest next actions in one compact hub before jumping into a tab.",
        "タブへ入る前に、現在フェーズ、UV準備状態、安全寄りの次操作を1か所で把握できる統合ハブです。",
    ),
    "ui.control.phase": ("Phase: {name}", "フェーズ: {name}"),
    "ui.control.tab": ("Tab: {name}", "タブ: {name}"),
    "ui.control.meshes": ("Meshes: {n}", "メッシュ数: {n}"),
    "ui.control.uv_layers": ("UV Layers: {n}", "UV層数: {n}"),
    "ui.control.issues": ("Issues: {n}", "問題数: {n}"),
    "ui.control.scan": ("Scan: {state}", "検査: {state}"),
    "ui.control.scan.ready": ("Ready", "準備済み"),
    "ui.control.scan.none": ("Not Yet", "未実行"),
    "ui.control.status.title": ("Current Status", "現在の状態"),
    "ui.control.status.empty.1": ("No mesh is selected yet.", "まだメッシュが選択されていません。"),
    "ui.control.status.empty.2": (
        "Start with workspace validation or select the target object first.",
        "まずワークスペース検証を行うか、対象オブジェクトを選択してください。",
    ),
    "ui.control.status.prep.1": (
        "The current selection still needs UV slots or a shared active UV target.",
        "現在の選択には、まだUVスロットや共通アクティブUVの準備が必要です。",
    ),
    "ui.control.status.prep.2": (
        "Prepare the working UV role before unwrap, layout or repair tools.",
        "展開、配置、修復へ進む前に、作業用UV役割を整えてください。",
    ),
    "ui.control.status.inspect.1": (
        "A fresh scan has not been run on the current working state yet.",
        "現在の作業状態に対する最新スキャンがまだ実行されていません。",
    ),
    "ui.control.status.inspect.2": (
        "Inspect first so the next repair or finishing step is based on visible issues.",
        "次の修復や仕上げを見える問題に基づいて行えるよう、先に検査してください。",
    ),
    "ui.control.status.repair.1": (
        "Known UV issues are still present in the latest scan cache.",
        "最新スキャンのキャッシュには、まだ既知のUV問題が残っています。",
    ),
    "ui.control.status.repair.2": (
        "Repair or rescan before committing to final layout, density or export work.",
        "最終配置、密度調整、書き出しへ進む前に、修復または再スキャンを行ってください。",
    ),
    "ui.control.status.role.1": (
        "The current state looks ready for role-specific UV tasks such as Bake, Lightmap, Atlas or stack management.",
        "現在の状態は Bake、Lightmap、Atlas、スタック管理などの役割別UV作業へ進みやすい状態です。",
    ),
    "ui.control.status.role.2": (
        "Check the correct active UV target before running role-specific helpers.",
        "役割別ヘルパーを実行する前に、正しいアクティブUVを確認してください。",
    ),
    "ui.control.status.finish.1": (
        "The current state looks ready for layout finishing, checker review and export prep.",
        "現在の状態は、配置の仕上げ、チェッカー確認、書き出し準備へ進みやすい状態です。",
    ),
    "ui.control.status.finish.2": (
        "Pack, review and verify the final working UV before handoff.",
        "引き渡し前に、最終作業UVをパック、確認、検証してください。",
    ),
    "ui.control.actions.title": ("Safe Next Actions", "安全寄りの次操作"),
    "ui.control.actions.1": (
        "Open the most relevant tab and start from a safe validation or review step.",
        "最も関連するタブを開き、安全寄りの検証または確認ステップから始めます。",
    ),
    "ui.control.actions.2": (
        "The suggested actions below favor visibility and recovery over hidden state changes.",
        "下の推奨操作は、見えない状態変更よりも可視性と復旧性を優先しています。",
    ),
})


def _suv_control_center_payload(context):
    ws = _suv_ws(context)
    obj = _active_mesh_obj(context)
    phase_payload = _suv_phase_coach_payload(context) if '_suv_phase_coach_payload' in globals() else {'phase': 'select'}
    phase = str((phase_payload or {}).get('phase', 'select') or 'select')
    current_tab = str(getattr(ws, 'main_tab', 'WORKFLOW') if ws else 'WORKFLOW').upper()

    try:
        selected = list(_selected_mesh_objects(context))
    except Exception:
        selected = []
    mesh_count = len(selected)
    if mesh_count == 0 and obj is not None:
        mesh_count = 1

    uv_layer_count = 0
    active_uv_name = '-'
    try:
        if obj is not None and getattr(obj.data, 'uv_layers', None) is not None:
            uv_layer_count = len(obj.data.uv_layers)
            active = obj.data.uv_layers.active
            active_uv_name = active.name if active else '-'
    except Exception:
        pass

    try:
        active_missing = len(_suv_objects_missing_active_uv(context))
    except Exception:
        active_missing = 0

    issue_total = _suv_cached_issue_total(ws) if '_suv_cached_issue_total' in globals() else 0
    has_scan = bool(getattr(ws, 'scan_has_result', False)) if ws else False

    lines_key_map = {
        'select': ('ui.control.status.empty.1', 'ui.control.status.empty.2'),
        'prep': ('ui.control.status.prep.1', 'ui.control.status.prep.2'),
        'inspect': ('ui.control.status.inspect.1', 'ui.control.status.inspect.2'),
        'repair': ('ui.control.status.repair.1', 'ui.control.status.repair.2'),
        'role': ('ui.control.status.role.1', 'ui.control.status.role.2'),
        'finish': ('ui.control.status.finish.1', 'ui.control.status.finish.2'),
    }
    status_keys = lines_key_map.get(phase, lines_key_map['inspect'])

    if obj is None:
        actions = [
            (SUV_OT_workspace_validate.bl_idname, tr(context, 'op.workspace_validate'), 'CHECKMARK', 'suv_workspace', {}),
            ('wm.context_set_enum', tr(context, 'ui.tab.workflow'), 'UV', 'suv_workflow', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'WORKFLOW'}),
            ('wm.context_set_enum', tr(context, 'ui.tab.analyze'), 'VIEWZOOM', 'suv_ref_inspect', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
        ]
    elif uv_layer_count <= 0 or active_missing > 0:
        actions = [
            ('uv.suv_native_stage_compat_tools', tr(context, 'ui.menu.batch_ensure_active_uv'), 'ADD', 'suv_uvmap', {'mode': 'BATCH_ENSURE_ACTIVE_UV'}),
            ('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
            (SUV_OT_workspace_validate.bl_idname, tr(context, 'op.workspace_validate'), 'CHECKMARK', 'suv_workspace', {}),
        ]
    elif not has_scan:
        actions = [
            (SUV_OT_inspector_scan.bl_idname, tr(context, 'ui.quick_scan'), 'VIEWZOOM', 'suv_ref_inspect', {}),
            ('wm.context_set_enum', tr(context, 'ui.tab.analyze'), 'VIEWZOOM', 'suv_ref_inspect', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
            ('object.suv_visualize_stretch_heatmap', tr(context, 'ui.menu.show_stretch_heatmap'), 'SHADING_RENDERED', 'suv_ref_inspect', {}),
        ]
    elif issue_total > 0:
        actions = [
            (SUV_OT_workspace_auto_repair.bl_idname, tr(context, 'op.workspace_repair'), 'TOOL_SETTINGS', 'suv_workspace', {}),
            (SUV_OT_inspector_fix_flipped.bl_idname, tr(context, 'ui.menu.fix_flipped'), 'MOD_MIRROR', 'suv_ref_inspect', {}),
            (SUV_OT_inspector_scan.bl_idname, tr(context, 'ui.quick_scan'), 'VIEWZOOM', 'suv_ref_inspect', {}),
        ]
    elif current_tab in {'MAPS', 'ATLAS'} or uv_layer_count >= 2 or any(k in str(active_uv_name).lower() for k in ('bake', 'light', 'atlas', 'lm')):
        actions = [
            ('wm.context_set_enum', tr(context, 'ui.tab.maps'), 'GROUP_UVS', 'suv_uvmap', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'ANALYZE'}),
            (SUV_OT_bake_uv_prep.bl_idname, tr(context, 'ui.menu.bake_uv_prep'), 'RENDER_STILL', 'suv_ref_bake', {'prep_mode': 'BAKE'}),
            ('uv.suv_native_stage_compat_tools', tr(context, 'ui.menu.batch_ensure_active_uv'), 'ADD', 'suv_uvmap', {'mode': 'BATCH_ENSURE_ACTIVE_UV'}),
        ]
    else:
        actions = [
            ('wm.context_set_enum', tr(context, 'ui.tab.layout'), 'PACKAGE', 'suv_ref_pack', {'data_path': 'scene.suv_workspace.main_tab', 'value': 'LAYOUT'}),
            (SUV_OT_pack_pro.bl_idname, tr(context, 'ui.quick_pack'), 'PACKAGE', 'suv_ref_pack', {'engine': 'DETERMINISTIC'}),
            ('object.suv_create_checker_material', tr(context, 'ui.quick_checker'), 'MATERIAL', 'suv_ref_checker', {}),
        ]

    chips = [
        ('suv_workspace', tr(context, 'ui.control.phase', name=tr(context, f'ui.phase.{phase}.short'))),
        ('suv_workflow', tr(context, 'ui.control.tab', name=_suv_tab_title(context, ws))),
        ('suv_uvmap', tr(context, 'ui.control.uv_layers', n=uv_layer_count)),
        ('suv_ref_inspect', tr(context, 'ui.control.issues', n=issue_total)),
    ]

    status_lines = [
        tr(context, status_keys[0]),
        tr(context, status_keys[1]),
        tr(context, 'ui.control.meshes', n=mesh_count),
        tr(context, 'ui.guide.active_uv', name=active_uv_name),
    ]
    actions_lines = [
        tr(context, 'ui.control.actions.1'),
        tr(context, 'ui.control.actions.2'),
        tr(context, 'ui.control.scan', state=tr(context, 'ui.control.scan.ready' if has_scan else 'ui.control.scan.none')),
    ]
    return {
        'chips': chips,
        'status_title': tr(context, 'ui.control.status.title'),
        'status_lines': status_lines,
        'actions_title': tr(context, 'ui.control.actions.title'),
        'actions_lines': actions_lines,
        'actions': actions,
    }


def _draw_control_center(layout, context):
    box, col = _create_box(layout, tr(context, 'ui.section.control_center'), 'NODETREE', 'suv_workspace')
    _draw_info_line(col, tr(context, 'ui.control_center.hint'), 'INFO', 'suv_workspace')
    payload = _suv_control_center_payload(context)
    _draw_dashboard_chip_row(col, payload['chips'], scale=4.2)
    col.separator(factor=0.12)
    _draw_dashboard_card(col, payload['status_title'], payload['status_lines'], 'suv_workspace', [])
    _draw_dashboard_card(col, payload['actions_title'], payload['actions_lines'], 'suv_workflow', payload['actions'])
    return box


_old_draw_dashboard_v221148 = _draw_dashboard

def _draw_dashboard(layout, context):
    ws = _suv_ws(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    head = col.row(align=True)
    expanded = bool(getattr(ws, 'show_dashboard', False)) if ws else False
    if ws:
        head.prop(ws, 'show_dashboard', text="", icon='TRIA_DOWN' if expanded else 'TRIA_RIGHT', emboss=True)
    else:
        head.label(text="", icon='TRIA_RIGHT')
    _label_with_icon(head, tr(context, 'ui.toggle.dashboard'), 'IMAGE_DATA', 'suv_workspace')
    if not expanded:
        hint = col.row(align=True)
        hint.scale_y = 0.9
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        col.separator(factor=0.2)
        return

    draw_order = [
        _draw_visual_guide,
        _draw_control_center,
        _draw_state_snapshot,
        _draw_phase_coach,
        _draw_readiness_radar,
        _draw_next_step_advisor,
        _draw_tab_mission_brief,
        _draw_goal_paths,
        _draw_issue_solver,
        _draw_production_checkpoints,
        _draw_preset_cockpit,
        _draw_focus_lanes,
        _draw_outcome_compass,
        _draw_action_guide,
        _draw_recipe_cards,
        _draw_task_navigator,
        _draw_workspace_map,
        _draw_beginner_legend,
    ]
    for draw_fn in draw_order:
        box = draw_fn(col, context)
        if box is not None:
            col.separator(factor=0.15)

    recipes = [
        ("Auto UV Pro", 'suv_ref_auto', SUV_OT_auto_uv_profile.bl_idname, "Organic", 'MOD_SMOOTH', 'suv_ref_auto', {'profile': 'ORGANIC'}, ["有機形状向けの開始プリセット", "シーム→展開→調整の起点"]),
        ("Projection Lab", 'suv_ref_projection', SUV_OT_native_projection.bl_idname, "Smart Project", 'MOD_UVPROJECT', 'suv_ref_projection', {'mode': 'SMART_PROJECT', 'pack_after': True}, ["投影系ワークフローの入口", "ビュー・法線ベース系を整理"]),
        ("Pack + UDIM", 'suv_ref_pack', SUV_OT_pack_pro.bl_idname, "Pack Pro", 'PACKAGE', 'suv_ref_pack', {'engine': 'DETERMINISTIC', 'udim_mode': 'AUTO_TILES'}, ["密度とタイル整理の仕上げ", "必要時のみ詳細設定へ"]),
        ("Inspect + Density", 'suv_ref_inspect', SUV_OT_inspector_scan.bl_idname, 'Batch Inspect', 'VIEWZOOM', 'suv_ref_inspect', {}, ["チェッカーと検査の確認用", "トラブル時の確認に使用"]),
    ]
    use_gallery = bool(getattr(ws, 'show_reference_gallery', False)) if ws else False
    if use_gallery:
        grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_visual_recipe_card(grid, title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines)
    else:
        for title, preview_icon, op_id, op_label, fallback_icon, custom_icon, props, note_lines in recipes:
            _draw_dashboard_card(col, title, note_lines, preview_icon, [(op_id, op_label, fallback_icon, custom_icon, props)])
    col.separator(factor=0.2)


for _cls_name, _desc_pair in {
    'SUV_OT_uvmap_add': (
        "Create a fresh UV layer on the working meshes so a new role such as Main, Bake or Lightmap can be introduced without overwriting the current layout.",
        "作業メッシュへ新しいUV層を作成し、現在のレイアウトを壊さずに Main、Bake、Lightmap などの新しい役割を追加できるようにします。",
    ),
    'SUV_OT_uvmap_duplicate': (
        "Duplicate the active UV layer so you can branch into a bake, atlas or repair path while keeping the original working layout intact.",
        "アクティブUV層を複製し、元の作業レイアウトを残したまま bake、atlas、repair 用の分岐を作れるようにします。",
    ),
    'SUV_OT_uvmap_remove': (
        "Remove an unneeded UV layer from the current role stack after confirming it is no longer required by bake, export or engine tasks.",
        "現在の役割スタックで不要になったUV層を削除し、ベイク、書き出し、エンジン用途でも不要であることを確認した後に整理できます。",
    ),
    'SUV_OT_uvmap_rename_active': (
        "Rename the active UV layer to a clearer role-based name so later bake, atlas, lightmap or export steps are easier to understand.",
        "アクティブUV層を役割ベースの分かりやすい名前へ変更し、後続の bake、atlas、lightmap、書き出し工程を理解しやすくします。",
    ),
    'SUV_OT_inspector_scan': (
        "Run a guarded inspector pass to detect overlap, flipped shells, out-of-range UVs, zero-area shells and stretch issues before repair or export.",
        "重なり、反転シェル、範囲外UV、ゼロ面積シェル、ストレッチ問題を検出する安全寄りの検査を実行し、修復や書き出し前に問題を見える化します。",
    ),
    'SUV_OT_inspector_fix_flipped': (
        "Try to repair flipped UV shells from the last detected issues so mirrored or inverted faces are less likely to slip into final bake or export.",
        "最後に検出した問題を元に反転UVシェルの修復を試み、ミラー反転や裏返り面が最終ベイクや書き出しへ混入しにくいようにします。",
    ),
    'SUV_OT_pack_pro': (
        "Run the suite's production-oriented packer with safer defaults so density, tile usage and final shell arrangement are easier to review and reuse.",
        "ツールセットの制作向けパッカーを安全寄り初期値で実行し、密度、タイル使用、最終シェル配置を確認・再利用しやすくします。",
    ),
    'SUV_OT_stack_pro': (
        "Stack compatible shells with extra validation so mirrored or repeated parts can share space more safely before bake or atlas work.",
        "追加検証付きで互換シェルをスタックし、左右対称や反復パーツが bake や atlas 作業前により安全に領域共有できるようにします。",
    ),
    'SUV_OT_groups_to_tiles': (
        "Group shells by similarity or role and move each group into its own tile so repeated parts, materials or bake roles become easier to separate and review.",
        "類似性や役割でシェルをまとめ、各グループを専用タイルへ移動して、反復パーツ、材質、ベイク役割を分離・確認しやすくします。",
    ),
    'SUV_OT_bake_uv_prep': (
        "Prepare a role-specific UV layer for Bake or Lightmap work so the current main UV can stay untouched while the target role is created and normalized.",
        "Bake または Lightmap 用の役割別UV層を準備し、現在のメインUVを保持したまま対象役割を作成・正規化できるようにします。",
    ),
    'SUV_OT_workspace_validate': (
        "Check workspace readiness, UV availability, icon loading and cached diagnostics before you start a larger unwrap, repair or batch step.",
        "大きな展開、修復、一括処理へ入る前に、ワークスペース準備状態、UV有無、アイコン読込、診断キャッシュを確認します。",
    ),
    'SUV_OT_workspace_auto_repair': (
        "Repair common readiness issues such as missing UV layers, stale cache state or helper resources before you continue with the next workflow stage.",
        "次のワークフロー段階へ進む前に、UV層不足、古いキャッシュ状態、補助リソース不足などの代表的な準備問題を修復します。",
    ),
    'SUV_OT_open_diagnostics_text': (
        "Open the latest human-readable diagnostics note so validation, repair and workflow decisions can be checked without digging through code or logs.",
        "最新の読みやすい診断ノートを開き、コードやログを追わなくても検証、修復、ワークフロー判断を確認できるようにします。",
    ),
    'SUV_OT_collect_support_bundle': (
        "Collect diagnostics, logs and snapshots into a support bundle so a later review or bug report can reconstruct what happened more reliably.",
        "診断、ログ、スナップショットをサポートバンドルへまとめ、後の確認や不具合報告で状況をより確実に再構成できるようにします。",
    ),
}.items():
    _cls = globals().get(_cls_name)
    if _cls is not None:
        try:
            _cls.bl_description = _suv_bilingual_desc(_desc_pair[0], _desc_pair[1])
        except Exception:
            pass


__all__ = [k for k in globals().keys() if not k.startswith('_')]
