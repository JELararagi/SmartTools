# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Smart UV Suite 1.8.111: unified Direction Align backend.

The visible UV Align panel has one Direction Align board.  The target switch
routes the same buttons to the existing vertex alignment backend or the existing
island alignment backend without duplicating UI sections.
"""
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

from typing import Any

import bpy

_REGISTERED: list[type] = []
_NS: dict[str, Any] | None = None

_MODE_ITEMS = (
    ("VERTEX", "頂点", "UVエディターで選択中のUV頂点・辺・面だけを直接整列します。"),
    ("ISLAND", "アイランド", "UVエディターで選択中のUVアイランドを形状を保ったまま整列します。"),
)

_ACTION_ITEMS = (
    ("ALIGN_TL", "↖", "Align the selected UV elements to the upper-left corner of their current selection bounds."),
    ("ALIGN_TOP", "↑", "Align the selected UV elements to the top edge of their current selection bounds."),
    ("ALIGN_TR", "↗", "Align the selected UV elements to the upper-right corner of their current selection bounds."),
    ("ALIGN_LEFT", "←", "Align the selected UV elements to the left edge of their current selection bounds."),
    ("ALIGN_CENTER", "+", "Move the selected UV elements to the center of their current selection bounds."),
    ("ALIGN_RIGHT", "→", "Align the selected UV elements to the right edge of their current selection bounds."),
    ("ALIGN_BL", "↙", "Align the selected UV elements to the lower-left corner of their current selection bounds."),
    ("ALIGN_BOTTOM", "↓", "Align the selected UV elements to the bottom edge of their current selection bounds."),
    ("ALIGN_BR", "↘", "Align the selected UV elements to the lower-right corner of their current selection bounds."),
    ("ALIGN_H", "—", "Align the selected UV elements to the horizontal center line of the selection."),
    ("ALIGN_V", "|", "Align the selected UV elements to the vertical center line of the selection."),
    ("ALIGN_H_GROUP", "G—", "Align each selected connected UV group to its own horizontal center line.  When several islands are selected, each island is processed independently."),
    ("ALIGN_V_GROUP", "G|", "Align each selected connected UV group to its own vertical center line.  When several islands are selected, each island is processed independently."),
    ("DISTRIBUTE_H", "┉", "Distribute selected UV elements evenly from left to right across the selection bounds."),
    ("DISTRIBUTE_V", "┋", "Distribute selected UV elements evenly from bottom to top across the selection bounds."),
    ("DISTRIBUTE_H_GROUP", "G┉", "Distribute connected UV groups evenly from left to right using each group midpoint.  When several islands are selected, each island is processed independently."),
    ("DISTRIBUTE_V_GROUP", "G┋", "Distribute connected UV groups evenly from bottom to top using each group midpoint.  When several islands are selected, each island is processed independently."),
    ("FLIP_H", "↔", "Mirror the selected UV elements horizontally around the selection center."),
    ("FLIP_V", "↕", "Mirror the selected UV elements vertically around the selection center."),
    ("ROTATE_CCW", "90L", "Rotate the selected UV elements 90 degrees counter-clockwise around the selection center."),
    ("ROTATE_CW", "90R", "Rotate the selected UV elements 90 degrees clockwise around the selection center."),
)

_ACTION_DESC = {
    "ALIGN_TL": ("Align the selected UV elements to the upper-left corner of their current selection bounds.", "選択中のUVエレメントを、現在の選択範囲の左上へ整列します。"),
    "ALIGN_TOP": ("Align the selected UV elements to the top edge of their current selection bounds.", "選択中のUVエレメントを、現在の選択範囲の上端へ整列します。"),
    "ALIGN_TR": ("Align the selected UV elements to the upper-right corner of their current selection bounds.", "選択中のUVエレメントを、現在の選択範囲の右上へ整列します。"),
    "ALIGN_LEFT": ("Align the selected UV elements to the left edge of their current selection bounds.", "選択中のUVエレメントを、現在の選択範囲の左端へ整列します。"),
    "ALIGN_CENTER": ("Move the selected UV elements to the center of their current selection bounds.", "選択中のUVエレメントを、現在の選択範囲の中央へ移動します。"),
    "ALIGN_RIGHT": ("Align the selected UV elements to the right edge of their current selection bounds.", "選択中のUVエレメントを、現在の選択範囲の右端へ整列します。"),
    "ALIGN_BL": ("Align the selected UV elements to the lower-left corner of their current selection bounds.", "選択中のUVエレメントを、現在の選択範囲の左下へ整列します。"),
    "ALIGN_BOTTOM": ("Align the selected UV elements to the bottom edge of their current selection bounds.", "選択中のUVエレメントを、現在の選択範囲の下端へ整列します。"),
    "ALIGN_BR": ("Align the selected UV elements to the lower-right corner of their current selection bounds.", "選択中のUVエレメントを、現在の選択範囲の右下へ整列します。"),
    "ALIGN_H": ("Align the selected UV elements to the horizontal center line of the selection.", "選択中のUVエレメントを、選択範囲の水平中心線へ整列します。"),
    "ALIGN_V": ("Align the selected UV elements to the vertical center line of the selection.", "選択中のUVエレメントを、選択範囲の垂直中心線へ整列します。"),
    "ALIGN_H_GROUP": ("Align each selected connected UV group to its own horizontal center line.  When several islands are selected, each island is processed independently.", "選択中の連結UVグループごとに、そのグループ内の水平中心線へ整列します。複数アイランドをまたぐ選択では、各アイランドを独立して処理します。"),
    "ALIGN_V_GROUP": ("Align each selected connected UV group to its own vertical center line.  When several islands are selected, each island is processed independently.", "選択中の連結UVグループごとに、そのグループ内の垂直中心線へ整列します。複数アイランドをまたぐ選択では、各アイランドを独立して処理します。"),
    "DISTRIBUTE_H": ("Distribute selected UV elements evenly from left to right across the selection bounds.", "選択中のUVエレメントを、選択範囲の左から右へ均等配置します。"),
    "DISTRIBUTE_V": ("Distribute selected UV elements evenly from bottom to top across the selection bounds.", "選択中のUVエレメントを、選択範囲の下から上へ均等配置します。"),
    "DISTRIBUTE_H_GROUP": ("Distribute connected UV groups evenly from left to right using each group midpoint.  When several islands are selected, each island is processed independently.", "連結UVグループごとの中点を基準に、左から右へ均等配置します。複数アイランドをまたぐ選択では、各アイランドを独立して処理します。"),
    "DISTRIBUTE_V_GROUP": ("Distribute connected UV groups evenly from bottom to top using each group midpoint.  When several islands are selected, each island is processed independently.", "連結UVグループごとの中点を基準に、下から上へ均等配置します。複数アイランドをまたぐ選択では、各アイランドを独立して処理します。"),
    "FLIP_H": ("Mirror the selected UV elements horizontally around the selection center.", "選択中のUVエレメントを、選択範囲の中心を基準に左右反転します。"),
    "FLIP_V": ("Mirror the selected UV elements vertically around the selection center.", "選択中のUVエレメントを、選択範囲の中心を基準に上下反転します。"),
    "ROTATE_CCW": ("Rotate the selected UV elements 90 degrees counter-clockwise around the selection center.", "選択中のUVエレメントを、選択範囲の中心を基準に反時計回りへ90度回転します。"),
    "ROTATE_CW": ("Rotate the selected UV elements 90 degrees clockwise around the selection center.", "選択中のUVエレメントを、選択範囲の中心を基準に時計回りへ90度回転します。"),
    "MIRROR_H": ("Mirror selected UV islands horizontally while preserving each island shape.", "選択UVアイランドを、各アイランド形状を保ったまま左右反転します。"),
    "MIRROR_V": ("Mirror selected UV islands vertically while preserving each island shape.", "選択UVアイランドを、各アイランド形状を保ったまま上下反転します。"),
}
_ISLAND_ACTION_MAP = {
    "ALIGN_H_GROUP": "ALIGN_H",
    "ALIGN_V_GROUP": "ALIGN_V",
    "DISTRIBUTE_H_GROUP": "DISTRIBUTE_H",
    "DISTRIBUTE_V_GROUP": "DISTRIBUTE_V",
    "FLIP_H": "MIRROR_H",
    "FLIP_V": "MIRROR_V",
    "MIRROR_H": "MIRROR_H",
    "MIRROR_V": "MIRROR_V",
}


def _tr(context, en: str, ja: str) -> str:
    ns = _NS or {}
    for fn_name in ("_sus_text", "_tr"):
        fn = ns.get(fn_name)
        if callable(fn):
            for args in ((en, ja, context), (context, en, ja)):
                try:
                    return str(fn(*args))
                except Exception:
                    pass
    try:
        lang = str(getattr(getattr(bpy.context, "preferences", None).view, "language", "") or "")
        if lang.startswith("ja"):
            return ja
    except Exception:
        pass
    return en


def _workspace(context):
    try:
        return getattr(getattr(context, "scene", None), "suv_workspace", None)
    except Exception:
        return None


def _get_mode(context) -> str:
    ws = _workspace(context)
    try:
        mode = str(getattr(ws, "uv_direction_align_target", "VERTEX") or "VERTEX").upper()
        if mode in {"VERTEX", "ISLAND"}:
            return mode
    except Exception:
        pass
    return "VERTEX"


def _set_mode(context, mode: str) -> None:
    ws = _workspace(context)
    if ws is None:
        return
    mode = "ISLAND" if str(mode or "").upper() == "ISLAND" else "VERTEX"
    try:
        setattr(ws, "uv_direction_align_target", mode)
    except Exception:
        pass


def _resolve_op(op_id: str):
    op = bpy.ops
    for part in str(op_id or "").split("."):
        op = getattr(op, part)
    return op


def _normalize_operator_result(result):
    try:
        value = set(result or {"FINISHED"})
        return value or {"FINISHED"}
    except Exception:
        return {"FINISHED"}


def _call_op(op_id: str, action: str):
    op = _resolve_op(op_id)
    try:
        result = op('EXEC_DEFAULT', action=str(action))
    except TypeError:
        result = op(action=str(action))
    return _normalize_operator_result(result)


class _BackendProxy:
    def __init__(self, owner: Any, *, backend_class: type | None = None, **props: Any) -> None:
        self._owner = owner
        self._smart_uv_1897_backend_class = backend_class
        for key, value in props.items():
            try:
                setattr(self, str(key), value)
            except Exception:
                pass

    def report(self, levels, message) -> None:
        try:
            self._owner.report(levels, message)
        except Exception:
            pass


def _call_backend_class(owner: Any, context: Any, class_name: str, action: str, *, scope: str | None = None):
    """Execute the registered backend class without a nested bpy.ops dispatch.

    Blender 5.1 can flush the live UV-editor selection when a dispatcher calls
    another UV operator through bpy.ops from inside execute().  Directly using
    the existing backend execute() preserves the backend's original selection
    behavior while keeping bpy.ops as a hot-reload fallback.
    """
    ns = _NS or {}
    cls = ns.get(class_name)
    execute = getattr(cls, "execute", None) if isinstance(cls, type) else None
    if callable(execute):
        proxy = _BackendProxy(owner, backend_class=cls, action=str(action))
        if scope is not None:
            try:
                proxy.scope = str(scope)
            except Exception:
                pass
        return _normalize_operator_result(execute(proxy, context))
    fallback = {
        "SMARTUVSUITE_OT_vertex_align_action": "smart_uv_suite.vertex_align_action",
        "SMARTUVSUITE_OT_island_direction_align": "smart_uv_suite.island_direction_align",
    }.get(class_name)
    if fallback:
        return _call_op(fallback, action)
    return {"CANCELLED"}


def _execute_direction_align_backend(owner: Any, context: Any, action: str):
    action = str(action or "ALIGN_CENTER").upper()
    if _get_mode(context) == "ISLAND":
        mapped_action = _ISLAND_ACTION_MAP.get(action, action)
        return _call_backend_class(owner, context, "SMARTUVSUITE_OT_island_direction_align", mapped_action)
    if action == "MIRROR_H":
        action = "FLIP_H"
    elif action == "MIRROR_V":
        action = "FLIP_V"
    return _call_backend_class(owner, context, "SMARTUVSUITE_OT_vertex_align_action", action, scope="SELECTED")


class SMARTUVSUITE_OT_direction_align_mode(bpy.types.Operator):
    bl_idname = "smart_uv_suite.direction_align_mode"
    bl_label = "Direction Align Target"
    bl_description = "Switch the Direction Align target between selected UV elements and selected UV islands."
    bl_options = {'UNDO'}

    target: bpy.props.EnumProperty(
        name="対象",
        description="Choose whether Direction Align edits selected UV elements directly or moves selected UV islands while preserving island shapes.",
        items=_MODE_ITEMS,
        default="VERTEX",
        options={"SKIP_SAVE"},
    )

    def execute(self, context):
        _set_mode(context, str(getattr(self, "target", "VERTEX") or "VERTEX"))
        return {"FINISHED"}


class SMARTUVSUITE_OT_direction_align(bpy.types.Operator):
    bl_idname = "smart_uv_suite.direction_align"
    bl_label = "Direction Align"
    bl_description = "Run the selected Direction Align button on the current UV target."
    bl_options = {'UNDO'}
    _smart_uv_required_rna_props = {"action"}

    action: bpy.props.EnumProperty(
        name="操作",
        description="Choose the exact Direction Align operation assigned to this button.",
        items=_ACTION_ITEMS,
        default="ALIGN_CENTER",
        options={"SKIP_SAVE"},
    )

    @classmethod
    def description(cls, context, properties):
        action = str(getattr(properties, "action", "ALIGN_CENTER") or "ALIGN_CENTER").upper()
        mode = _get_mode(context)
        key = _ISLAND_ACTION_MAP.get(action, action) if mode == "ISLAND" else action
        en, ja = _ACTION_DESC.get(key, _ACTION_DESC.get(action, _ACTION_DESC["ALIGN_CENTER"]))
        if mode == "ISLAND":
            return _tr(
                context,
                en + " The current target is Island, so the command moves selected islands as rigid shells instead of editing vertices inside each island.",
                ja + " 現在の対象はアイランドのため、各アイランド内部の頂点を崩さず、選択アイランドを形状維持のシェルとして移動します。",
            )
        return _tr(context, en, ja)

    def execute(self, context):
        action = str(getattr(self, "action", "ALIGN_CENTER") or "ALIGN_CENTER").upper()
        try:
            return _execute_direction_align_backend(self, context, action)
        except Exception as exc:
                self.report({"WARNING"}, _tr(context, "Direction alignment failed.", "方向整列に失敗しました。") + f" {exc}")
                return {"CANCELLED"}


# Backward-compatible alias for experimental 1.8.111 builds that briefly used
# smart_uv_suite.direction_align_action.  The visible UI uses direction_align.
class SMARTUVSUITE_OT_direction_align_action(bpy.types.Operator):
    bl_idname = "smart_uv_suite.direction_align_action"
    bl_label = "Direction Align"
    bl_description = "Compatibility entry point for the selected Direction Align button."
    bl_options = {'UNDO'}
    _smart_uv_required_rna_props = {"action"}

    action: bpy.props.EnumProperty(
        name="操作",
        description="Choose the exact Direction Align operation assigned to this compatibility button.",
        items=_ACTION_ITEMS,
        default="ALIGN_CENTER",
        options={"SKIP_SAVE"},
    )

    @classmethod
    def description(cls, context, properties):
        return SMARTUVSUITE_OT_direction_align.description(context, properties)

    def execute(self, context):
        action = str(getattr(self, "action", "ALIGN_CENTER") or "ALIGN_CENTER").upper()
        try:
            return _execute_direction_align_backend(self, context, action)
        except Exception as exc:
            self.report({"WARNING"}, f"方向整列に失敗しました。 {exc}")
            return {"CANCELLED"}


_CLASSES = (
    SMARTUVSUITE_OT_direction_align_mode,
    SMARTUVSUITE_OT_direction_align,
    SMARTUVSUITE_OT_direction_align_action,
)


def _operator_exists(op_id: str) -> bool:
    try:
        op = _resolve_op(op_id)
        rna = op.get_rna_type()
        ident = str(getattr(rna, "identifier", "") or "")
        return bool(ident) and ident not in {"Operator", "UnknownType", "bpy_struct"}
    except Exception:
        return False


def _ensure_workspace_property(ns: dict[str, Any] | None = None) -> None:
    """Ensure the canonical workspace switch exists on old hot-reload classes.

    The main 1.8.111 package defines uv_direction_align_target in ui.py before
    the PropertyGroup class is registered.  This fallback only covers rare
    same-session hot reloads where Blender still holds an older class object.
    It deliberately does not add a second public RNA property because assigning
    new EnumProperties to an already-registered PropertyGroup can leave a
    _PropertyDeferred object on the Python class in GUI sessions.
    """
    source = ns or _NS or {}
    cls = source.get("SUV_PG_WorkspaceSettings")
    if cls is None:
        try:
            from . import ui as _ui
            cls = getattr(_ui, "SUV_PG_WorkspaceSettings", None)
        except Exception:
            cls = None
    if cls is None:
        return
    try:
        if hasattr(cls, "uv_direction_align_target"):
            return
    except Exception:
        pass
    try:
        cls.uv_direction_align_target = bpy.props.EnumProperty(
            name="方向整列対象",
            description="方向整列ボタンの対象です。頂点はUVエディターで選択中のUVエレメントだけを直接整列し、アイランドは選択UVアイランドを形状維持で整列します。",
            items=_MODE_ITEMS,
            default="VERTEX",
            update=source.get("_suv_workspace_settings_update"),
        )
    except Exception:
        pass


def install(ns: dict[str, Any] | None = None, context=None) -> None:
    global _NS
    if isinstance(ns, dict):
        _NS = ns
    _ensure_workspace_property(ns)
    for cls in _CLASSES:
        if cls in _REGISTERED:
            continue
        try:
            _suv_resource.register_class(cls)
            _REGISTERED.append(cls)
        except ValueError:
            if _operator_exists(getattr(cls, "bl_idname", "")):
                _REGISTERED.append(cls)
        except Exception:
            pass
    try:
        if isinstance(ns, dict):
            ns["SMARTUVSUITE_OT_direction_align"] = SMARTUVSUITE_OT_direction_align
            ns["SMARTUVSUITE_OT_direction_align_mode"] = SMARTUVSUITE_OT_direction_align_mode
    except Exception:
        pass
    try:
        from . import uv_direction_align_selection_guard_18111 as _selection_guard
        guard_install = getattr(_selection_guard, "install", None) or getattr(_selection_guard, "apply_all", None)
        if callable(guard_install):
            guard_install(ns or _NS or {}, context or bpy.context)
    except Exception:
        pass
    try:
        if isinstance(ns, dict):
            ns["SMARTUVSUITE_OT_direction_align"] = SMARTUVSUITE_OT_direction_align
            ns["SMARTUVSUITE_OT_direction_align_mode"] = SMARTUVSUITE_OT_direction_align_mode
            ns["__version__"] = '1.0.0'
            ns["bl_info"]["version"] = (1, 0, 0)
            ns["bl_info"]["author"] = "JELararagi"
            ns["_SUS_BL_INFO_FALLBACK"] = dict(ns.get("bl_info") or {})
    except Exception:
        pass


apply_all = install


def register() -> None:
    install(_NS, bpy.context)


def unregister() -> None:
    for cls in reversed(list(_REGISTERED)):
        try:
            _suv_resource.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED.clear()


def diagnostics(context=None) -> dict[str, Any]:
    return {
        "registered": [getattr(cls, "bl_idname", cls.__name__) for cls in _REGISTERED],
        "mode": _get_mode(context or bpy.context),
        "has_direction_align": _operator_exists("smart_uv_suite.direction_align"),
        "has_direction_align_mode": _operator_exists("smart_uv_suite.direction_align_mode"),
    }
