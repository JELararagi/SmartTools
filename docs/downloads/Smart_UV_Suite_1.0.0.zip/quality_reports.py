from __future__ import annotations
from . import resource_api_18168 as _suv_resource

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None

_NAMESPACE = {}
_REGISTERED = []


def _tr(context, key: str, en: str, ja: str, **fmt) -> str:
    fn = _NAMESPACE.get('tr')
    text = None
    if callable(fn):
        try:
            text = fn(context, key, **fmt)
        except Exception:
            text = None
    if not text:
        text = en
    try:
        return text.format(**fmt)
    except Exception:
        return text


def _text_name(context) -> str:
    ws_fn = _NAMESPACE.get('_suv_ws')
    ws = ws_fn(context) if callable(ws_fn) else None
    name = getattr(ws, 'support_bundle_name', '') if ws else ''
    return (str(name).strip() or 'SUV_Support_Bundle') + '_Report_Hub'


def _suv_report_hub_name(context):
    return _text_name(context)


def _text_block(name: str, clear=False):
    textio = _NAMESPACE.get('_quality_textio_module')
    if textio is not None and hasattr(textio, 'ensure_report_text'):
        try:
            return textio.ensure_report_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if textio is not None and hasattr(textio, 'ensure_namespace_text'):
        try:
            return textio.ensure_namespace_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if bpy is None:
        return None
    txt = bpy.data.texts.get(name)
    if txt is None:
        if not clear:
            return None
        txt = bpy.data.texts.new(name)
    elif clear:
        txt.clear()
    return txt


def _helper_text_name(helper_name: str, context):
    fn = _NAMESPACE.get(helper_name)
    if callable(fn):
        try:
            name = fn(context)
            if name:
                return str(name)
        except Exception:
            return ''
    return ''


def scan_report_hub(context) -> dict:
    report_specs = [
        ('audit', 'Quality Audit', '品質監査', '_text_name', 'quality_audit'),
        ('matrix', 'Feature Matrix', '機能マトリクス', '_text_name', 'quality_matrix'),
        ('language', 'Language Coverage', '言語対応レポート', '_text_name', 'quality_language'),
        ('guided_help', 'Guided Help', 'ガイドヘルプ', '_text_name', 'quality_help'),
        ('ui_map', 'Visual UI Map', '視覚UIマップ', '_text_name', 'quality_ui_map'),
        ('catalog', 'Operator Catalog', 'オペレーターカタログ', '_text_name', 'quality_catalog'),
        ('playbook', 'Task Playbook', 'タスク別プレイブック', '_text_name', 'quality_playbook'),
        ('profiles', 'Execution Profiles', '実行プロファイル', '_text_name', 'quality_profiles'),
        ('registry', 'Report Registry', 'レポートレジストリ', '_text_name', 'quality_registry'),
        ('doctor', 'Quality Doctor', '品質ドクター', '_text_name', 'quality_doctor'),
        ('controls', 'Visual Controls Report', '視覚コントロールレポート', '_text_name', 'quality_controls_report'),
        ('hub', 'Report Hub', 'レポートハブ', None, None),
    ]
    rows = []
    existing = 0
    if bpy is None:
        return {'total': len(report_specs), 'existing': 0, 'missing': len(report_specs), 'rows': []}
    module_map = {
        'quality_audit': _NAMESPACE.get('_quality_audit_module'),
        'quality_matrix': _NAMESPACE.get('_quality_matrix_module'),
        'quality_language': _NAMESPACE.get('_quality_language_module'),
        'quality_help': _NAMESPACE.get('_quality_help_module'),
        'quality_ui_map': _NAMESPACE.get('_quality_ui_map_module'),
        'quality_catalog': _NAMESPACE.get('_quality_catalog_module'),
        'quality_playbook': _NAMESPACE.get('_quality_playbook_module'),
        'quality_profiles': _NAMESPACE.get('_quality_profiles_module'),
        'quality_registry': _NAMESPACE.get('_quality_registry_module'),
        'quality_doctor': _NAMESPACE.get('_quality_doctor_module'),
        'quality_controls_report': _NAMESPACE.get('_quality_controls_report_module'),
    }
    for key, title_en, title_ja, helper_attr, module_key in report_specs:
        if key == 'hub':
            name = _text_name(context)
        else:
            name = ''
            mod = module_map.get(module_key)
            if mod is not None and helper_attr and hasattr(mod, helper_attr):
                try:
                    name = str(getattr(mod, helper_attr)(context) or '')
                except Exception:
                    name = ''
        exists = bool(name and bpy.data.texts.get(name) is not None)
        if exists:
            existing += 1
        rows.append({
            'key': key,
            'title_en': title_en,
            'title_ja': title_ja,
            'name': name,
            'exists': exists,
        })
    data = {
        'total': len(rows),
        'existing': existing,
        'missing': max(0, len(rows) - existing),
        'rows': rows,
    }
    _NAMESPACE['_suv_report_hub_last'] = data
    return data


class SUV_OT_quality_write_report_hub(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_write_report_hub'
    bl_label = 'Write Report Hub'
    bl_description = 'Write a compact hub text that lists the main generated UV Suite reports so you can open audits, matrices, help, and language reports from a single place. / 主要な UV Suite 生成レポートを一覧化したハブテキストを書き出し、監査、マトリクス、ヘルプ、言語対応レポートを一か所から確認しやすくします。'
    bl_options = set()

    open_after_write: bpy.props.BoolProperty(
        name='Open After Write',
        description='Open the written report hub in Blender Text Editor when possible / 可能なら書き出したレポートハブを Blender テキストエディタで開きます',
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        data = scan_report_hub(context)
        txt = None
        lines = [
            'UV Suite Report Hub',
            '',
            '[Summary]',
            f"Available reports: {data['existing']}/{data['total']}",
            f"Missing reports: {data['missing']}",
            '',
            '[Reports]',
        ]
        for row in data['rows']:
            state = 'ready' if row['exists'] else 'missing'
            lines.append(f"- {row['title_en']} [{state}]")
            lines.append(f"  name: {row['name'] or '-'}")
        lines.extend([
            '',
            '[Recommended order]',
            '1. Run context readiness if the working state looks incomplete.',
            '2. Run quality audit to check guards, tool_runtime health, and readiness.',
            '3. Run feature matrix to review broader UV tool-group surface coverage.',
            '4. Run language coverage when labels or help text still look thin.',
            '5. Write the task playbook when you want a goal-based beginner flow view.',
            '6. Write execution profiles when operators are still blocked by missing context.',
            '7. Write the quality doctor report when you want a prioritized next-fix list.',
            '8. Write the visual controls report when manual dashboard overrides need explanation.',
            '9. Open guided help or operator catalog when you need user-facing guidance.',
            '',
            '[日本語メモ]',
            f"利用可能レポート: {data['existing']}/{data['total']}",
            '最初に準備確認、その後に品質監査、機能マトリクス、言語対応レポート、必要ならタスク別プレイブック、最後にガイドヘルプやカタログを見る流れが分かりやすいです。',
        ])
        textio = _NAMESPACE.get('_quality_textio_module')
        writer = getattr(textio, 'write_report_lines_consistent', None) if textio is not None else None
        if callable(writer):
            txt = writer(
                _NAMESPACE, context, _text_name, lines, _text_block, self,
                open_after_write=self.open_after_write,
                failed_key='msg.quality_report_hub_open_failed',
                failed_en='Could not open report hub: {name}',
                failed_ja='レポートハブを開けませんでした: {name}',
            )
            if txt is None:
                return {'CANCELLED'}
        else:
            txt = _text_block(_text_name(context), clear=True)
            if txt is None:
                return {'CANCELLED'}
            txt.write('\n'.join(lines))
            if self.open_after_write:
                opener = _NAMESPACE.get('_suv_open_text_in_editor')
                if callable(opener):
                    try:
                        opener(context, txt)
                    except Exception:
                        pass
        msg = _tr(context, 'msg.quality_report_hub_written', 'Report hub written: {name} ({existing}/{total} ready)', 'レポートハブを書き出しました: {name}（利用可能 {existing}/{total}）', name=txt.name, existing=data['existing'], total=data['total'])
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class SUV_OT_quality_open_report_hub(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_open_report_hub'
    bl_label = 'Open Report Hub'
    bl_description = 'Open the latest UV Suite report hub in Blender Text Editor. / 最新の UV Suite レポートハブを Blender のテキストエディタで開きます。'
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        textio = _NAMESPACE.get('_quality_textio_module')
        if textio is not None and hasattr(textio, 'open_named_report_text_or_fallback'):
            return textio.open_named_report_text_or_fallback(
                _NAMESPACE, context, _text_name, self, _text_block,
                missing_key='msg.quality_report_hub_missing',
                missing_en='No report hub exists yet.',
                missing_ja='レポートハブはまだ作成されていません。',
                opened_key='msg.quality_report_hub_opened',
                opened_en='Opened report hub: {name}',
                opened_ja='レポートハブを開きました: {name}',
            )
        txt = _text_block(_text_name(context), clear=False)
        if txt is None:
            self.report({'WARNING'}, _tr(context, 'msg.quality_report_hub_missing', 'No report hub exists yet.', 'レポートハブはまだ作成されていません。'))
            return {'CANCELLED'}
        opener = _NAMESPACE.get('_suv_open_text_in_editor')
        ok = False
        if callable(opener):
            try:
                ok, _err = opener(context, txt)
            except Exception:
                ok = False
        if not ok:
            self.report({'WARNING'}, _tr(context, 'msg.quality_report_hub_open_failed', 'Could not open report hub: {name}', 'レポートハブを開けませんでした: {name}', name=txt.name))
            return {'CANCELLED'}
        msg = _tr(context, 'msg.quality_report_hub_opened', 'Opened report hub: {name}', 'レポートハブを開きました: {name}', name=txt.name)
        self.report({'INFO'}, msg)
        return {'FINISHED'}


def register(namespace: dict):
    global _NAMESPACE
    _NAMESPACE = namespace if isinstance(namespace, dict) else {}
    if bpy is None:
        return []
    classes = [SUV_OT_quality_write_report_hub, SUV_OT_quality_open_report_hub]
    reg = []
    for cls in classes:
        try:
            _suv_resource.register_class(cls)
            reg.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = reg
    return reg


def unregister(namespace: dict | None = None):
    if bpy is None:
        return []
    removed = []
    for cls in reversed(list(_REGISTERED)):
        try:
            _suv_resource.unregister_class(cls)
            removed.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = []
    return removed
