# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations
from . import resource_api_18168 as _suv_resource

import copy
import hashlib
import json
import os
import inspect
from pathlib import Path
from typing import Any

import bpy
from bpy.app.handlers import persistent

_PROXY_RECORDS: dict[str, dict[str, Any]] = {}
_PROXY_STORE_CACHE: dict[str, Any] | None = None
_APPLYING_PROXY_VALUES = False
_HANDLERS_INSTALLED = False
_PERSISTENCE_FILE_NAME = 'uv_suite_integrated_preferences.json'
_SKIP_PROXY_ATTR_NAMES = {
    '__annotations__',
    '__dict__',
    '__doc__',
    '__module__',
    '__weakref__',
    'bl_idname',
    'bl_rna',
    'rna_type',
}


def _normalize_addon_id(value: object) -> str:
    return str(value or '').strip()


def _proxy_token(addon_id: str, prefs_cls: type | None = None) -> str:
    source = f"{_normalize_addon_id(addon_id)}::{getattr(prefs_cls, '__module__', '')}::{getattr(prefs_cls, '__name__', '')}"
    return hashlib.md5(source.encode('utf-8')).hexdigest()[:12].upper()


def _record_key(addon_id: str, prefs_cls: type | None = None) -> str:
    return f"{_normalize_addon_id(addon_id)}::{getattr(prefs_cls, '__module__', '')}::{getattr(prefs_cls, '__name__', '')}"


def _proxy_class_name(addon_id: str, prefs_cls: type | None = None) -> str:
    return f"SMARTUV_PG_INTEGRATED_PREFS_{_proxy_token(addon_id, prefs_cls)}"


def _proxy_attr_name(addon_id: str, prefs_cls: type | None = None) -> str:
    return f"uv_suite_integrated_prefs_{_proxy_token(addon_id, prefs_cls).lower()}"


def _wrap_update_callback_for_blender(callback):
    """Return a Blender-compatible two-argument property update callback.

    Blender 5.1 validates the update callback signature during RNA registration.
    Some bundled source add-ons use zero/one-argument callbacks or callables whose
    Python signature cannot be inspected. Always return a wrapper with
    ``(self, context)`` and dispatch to the original callback with the safest
    compatible arity at runtime.
    """
    if not callable(callback):
        return callback

    cb = callback

    def _update(self, context):
        for args in ((self, context), (self,), tuple()):
            try:
                return cb(*args)
            except TypeError:
                continue
            except Exception:
                return None
        return None

    try:
        _update.__name__ = getattr(cb, '__name__', '_smart_uv_update_callback')
    except Exception:
        pass
    return _update

def _sanitize_property_deferred_update(value):
    try:
        keywords = getattr(value, 'keywords', None)
    except Exception:
        keywords = None
    if isinstance(keywords, dict) and 'update' in keywords:
        callback = keywords.get('update')
        wrapped = _wrap_update_callback_for_blender(callback)
        if wrapped is not callback:
            try:
                keywords['update'] = wrapped
            except Exception:
                try:
                    new_keywords = dict(keywords)
                    new_keywords['update'] = wrapped
                    setattr(value, 'keywords', new_keywords)
                except Exception:
                    pass
    return value


def _copy_annotation_value(value):
    try:
        copied = copy.copy(value)
    except Exception:
        copied = value
    return _sanitize_property_deferred_update(copied)


def _persistence_path(create: bool = False) -> Path:
    try:
        from . import storage as _storage
        return Path(_storage.runtime_file(_PERSISTENCE_FILE_NAME, 'state', create=create))
    except Exception:
        version = '5.1'
        try:
            app_version = getattr(getattr(bpy, 'app', None), 'version', (5, 1, 0)) or (5, 1, 0)
            version = f"{int(app_version[0])}.{int(app_version[1])}"
        except Exception:
            pass
        appdata = os.environ.get('APPDATA')
        if appdata:
            base = Path(appdata) / 'Blender Foundation' / 'Blender' / version / 'config' / 'Smart_UV_Suite' / 'user_data' / 'runtime' / 'state'
        else:
            base = Path.home() / '.config' / 'blender' / version / 'config' / 'Smart_UV_Suite' / 'user_data' / 'runtime' / 'state'
        if create:
            try:
                base.mkdir(parents=True, exist_ok=True)
            except Exception:
                pass
        return base / _PERSISTENCE_FILE_NAME


def _load_store() -> dict[str, Any]:
    global _PROXY_STORE_CACHE
    if isinstance(_PROXY_STORE_CACHE, dict):
        return _PROXY_STORE_CACHE
    path = _persistence_path(create=False)
    data: dict[str, Any] = {}
    try:
        raw = json.loads(path.read_text(encoding='utf-8'))
        if isinstance(raw, dict) and isinstance(raw.get('preferences'), dict):
            data = dict(raw.get('preferences') or {})
        elif isinstance(raw, dict):
            data = dict(raw)
    except Exception:
        data = {}
    _PROXY_STORE_CACHE = data
    return _PROXY_STORE_CACHE


def _write_store(data: dict[str, Any]) -> None:
    global _PROXY_STORE_CACHE
    _PROXY_STORE_CACHE = dict(data or {})
    path = _persistence_path(create=True)
    temp_path = path.with_suffix(path.suffix + '.tmp')
    payload = {'version': 1, 'preferences': _PROXY_STORE_CACHE}
    try:
        temp_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True), encoding='utf-8')
        os.replace(str(temp_path), str(path))
    finally:
        try:
            if temp_path.exists():
                temp_path.unlink()
        except Exception:
            pass


def _json_safe_value(value: Any):
    if isinstance(value, (bool, int, float, str)) or value is None:
        return value
    try:
        if isinstance(value, (list, tuple)) and all(isinstance(item, (bool, int, float, str)) or item is None for item in value):
            return list(value)
    except Exception:
        pass
    return None


def _iter_proxy_property_names(obj, owner_cls: type | None = None) -> list[str]:
    names: list[str] = []
    seen: set[str] = set()

    def _append(name: object) -> None:
        text = str(name or '').strip()
        if not text or text in seen:
            return
        if text.startswith('_') or text in {'rna_type', 'bl_idname', 'layout'}:
            return
        seen.add(text)
        names.append(text)

    for source in (getattr(owner_cls, '__annotations__', {}) if owner_cls is not None else {}, getattr(type(obj), '__annotations__', {})):
        try:
            for name in dict(source or {}).keys():
                _append(name)
        except Exception:
            pass
    try:
        props = getattr(getattr(obj, 'bl_rna', None), 'properties', None)
        for name in getattr(props, 'keys', lambda: [])():
            _append(name)
    except Exception:
        pass
    return names


def _capture_values(obj, owner_cls: type | None = None) -> dict[str, Any]:
    values: dict[str, Any] = {}
    if obj is None:
        return values
    for name in _iter_proxy_property_names(obj, owner_cls):
        try:
            value = getattr(obj, name)
        except Exception:
            continue
        safe_value = _json_safe_value(value)
        if safe_value is None and value is not None:
            continue
        values[name] = safe_value
    return values


def _apply_values(addon_id: str, prefs_cls: type | None, obj) -> int:
    global _APPLYING_PROXY_VALUES
    if obj is None:
        return 0
    values = dict(_load_store().get(_record_key(addon_id, prefs_cls), {}) or {})
    if not values:
        return 0
    applied = 0
    _APPLYING_PROXY_VALUES = True
    try:
        for name, value in values.items():
            try:
                current = getattr(obj, name)
                if current == value:
                    continue
            except Exception:
                pass
            try:
                setattr(obj, name, value)
                applied += 1
            except Exception:
                continue
    finally:
        _APPLYING_PROXY_VALUES = False
    return applied


def _save_values(addon_id: str, prefs_cls: type | None, obj) -> dict[str, Any]:
    values = _capture_values(obj, getattr(type(obj), '_uv_suite_proxy_source_class', prefs_cls))
    if not values:
        return {}
    data = dict(_load_store() or {})
    data[_record_key(addon_id, prefs_cls)] = values
    _write_store(data)
    return values


def _proxy_setattr(self, name: str, value: Any):
    try:
        bpy.types.PropertyGroup.__setattr__(self, name, value)
    except Exception:
        object.__setattr__(self, name, value)
    if _APPLYING_PROXY_VALUES or str(name or '').startswith('_'):
        return None
    try:
        prefs_cls = getattr(type(self), '_uv_suite_proxy_source_class', None)
        addon_id = getattr(type(self), '_uv_suite_proxy_addon_id', '')
        _save_values(str(addon_id or ''), prefs_cls, self)
    except Exception:
        pass
    return None


def _rna_class_ready(cls: type) -> bool:
    try:
        rna = getattr(cls, 'bl_rna', None)
        identifier = str(getattr(rna, 'identifier', '') or '')
        return bool(identifier) and identifier not in {'Operator', 'OperatorProperties', 'UnknownType', 'bpy_struct'}
    except Exception:
        return False


def _safe_register_class(cls: type) -> bool:
    try:
        return bool(_suv_resource.register_class(cls))
    except Exception:
        return False


def _safe_unregister_class(cls: type) -> None:
    try:
        _suv_resource.unregister_class(cls)
    except Exception:
        pass

def _build_proxy_class(addon_id: str, prefs_cls: type):
    try:
        from . import text_translation as _text_translation
        materialize = getattr(_text_translation, 'materialize_class_property_annotations', None)
        if callable(materialize):
            prefs_cls = materialize(prefs_cls, context=getattr(bpy, 'context', None))
        sanitize_class = getattr(_text_translation, 'sanitize_class', None)
        if callable(sanitize_class):
            prefs_cls = sanitize_class(prefs_cls, context=getattr(bpy, 'context', None))
    except Exception:
        pass
    annotations = {}
    for name, value in dict(getattr(prefs_cls, '__annotations__', {}) or {}).items():
        annotations[name] = _copy_annotation_value(value)

    attrs: dict[str, Any] = {
        '__module__': __name__,
        '__annotations__': annotations,
        '__doc__': getattr(prefs_cls, '__doc__', ''),
        '__setattr__': _proxy_setattr,
        '_uv_suite_proxy_source_class': prefs_cls,
        '_uv_suite_proxy_addon_id': addon_id,
    }
    for name, value in getattr(prefs_cls, '__dict__', {}).items():
        if name in _SKIP_PROXY_ATTR_NAMES:
            continue
        if name in annotations:
            continue
        if name.startswith('__'):
            continue
        if name.startswith('bl_'):
            continue
        attrs[name] = value
    return type(_proxy_class_name(addon_id, prefs_cls), (bpy.types.PropertyGroup,), attrs)


def ensure_proxy_for_class(prefs_cls: type | None, addon_id: str | None = None):
    if prefs_cls is None or not isinstance(prefs_cls, type):
        return None
    addon_id = _normalize_addon_id(addon_id or getattr(prefs_cls, 'bl_idname', '') or getattr(prefs_cls, '__module__', ''))
    if not addon_id:
        return None
    key = _record_key(addon_id, prefs_cls)
    record = _PROXY_RECORDS.get(key)
    if isinstance(record, dict):
        return record

    proxy_cls = _build_proxy_class(addon_id, prefs_cls)
    attr_name = _proxy_attr_name(addon_id, prefs_cls)
    if not _safe_register_class(proxy_cls) or not _rna_class_ready(proxy_cls):
        return None

    try:
        if not _suv_resource.register_property(
            bpy.types.WindowManager,
            attr_name,
            bpy.props.PointerProperty(type=proxy_cls),
        ):
            _safe_unregister_class(proxy_cls)
            return None
    except Exception:
        _safe_unregister_class(proxy_cls)
        return None

    record = {
        'addon_id': addon_id,
        'prefs_cls': prefs_cls,
        'proxy_cls': proxy_cls,
        'attr_name': attr_name,
        'record_key': key,
    }
    _PROXY_RECORDS[key] = record
    _install_handlers_once()
    return record


def ensure_proxies_for_classes(pref_classes) -> None:
    for cls in tuple(pref_classes or ()):
        try:
            ensure_proxy_for_class(cls, getattr(cls, 'bl_idname', ''))
        except Exception:
            pass


def _context_window_manager(context=None):
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    if wm is None:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    return wm


def _existing_proxy_record(addon_id: str = '', prefs_cls: type | None = None):
    normalized = _normalize_addon_id(addon_id or getattr(prefs_cls, 'bl_idname', '') or getattr(prefs_cls, '__module__', ''))
    if prefs_cls is not None and isinstance(prefs_cls, type):
        return _PROXY_RECORDS.get(_record_key(normalized, prefs_cls))
    for record in tuple(_PROXY_RECORDS.values()):
        if str(record.get('addon_id') or '') == normalized:
            return record
    return None


def get_addon_preferences(context=None, addon_id: str = '', prefs_cls: type | None = None):
    """Read an already-created proxy; never register or apply values from draw."""
    context = context or getattr(bpy, 'context', None)
    if context is None:
        return None
    record = _existing_proxy_record(addon_id, prefs_cls)
    if not isinstance(record, dict):
        return None
    wm = _context_window_manager(context)
    return getattr(wm, record.get('attr_name', ''), None) if wm is not None else None

def save_proxy_values(context=None, addon_id: str = '', prefs_obj=None, prefs_cls: type | None = None) -> dict[str, Any]:
    obj = prefs_obj
    if obj is None:
        record = ensure_proxy_for_class(prefs_cls, addon_id)
        wm = _context_window_manager(context)
        if isinstance(record, dict) and wm is not None:
            obj = getattr(wm, record['attr_name'], None)
            addon_id = str(record.get('addon_id') or addon_id)
            prefs_cls = record.get('prefs_cls')
    if obj is None:
        return {}
    return _save_values(addon_id or getattr(type(obj), '_uv_suite_proxy_addon_id', ''), prefs_cls or getattr(type(obj), '_uv_suite_proxy_source_class', None), obj)


def save_all_proxy_values(context=None) -> None:
    wm = _context_window_manager(context)
    if wm is None:
        return
    for record in tuple(_PROXY_RECORDS.values()):
        try:
            obj = getattr(wm, record.get('attr_name', ''), None)
            if obj is not None:
                _save_values(str(record.get('addon_id') or ''), record.get('prefs_cls'), obj)
        except Exception:
            pass


def apply_all_proxy_values(context=None) -> None:
    wm = _context_window_manager(context)
    if wm is None:
        return
    for record in tuple(_PROXY_RECORDS.values()):
        try:
            obj = getattr(wm, record.get('attr_name', ''), None)
            _apply_values(str(record.get('addon_id') or ''), record.get('prefs_cls'), obj)
        except Exception:
            pass


@persistent
def _uv_suite_proxy_load_post(_dummy=None):
    try:
        apply_all_proxy_values(getattr(bpy, 'context', None))
    except Exception:
        pass


@persistent
def _uv_suite_proxy_save_pre(_dummy=None):
    try:
        save_all_proxy_values(getattr(bpy, 'context', None))
    except Exception:
        pass



def _append_unique_handler(collection, handler) -> None:
    _suv_resource.handler_append(collection, handler)



def _remove_handler(collection, handler) -> None:
    _suv_resource.handler_remove(collection, handler)



def _install_handlers_once() -> None:
    global _HANDLERS_INSTALLED
    # Proxy values are synchronized by explicit lifecycle/property events.
    _HANDLERS_INSTALLED = False
    return None


def _remove_handlers() -> None:
    global _HANDLERS_INSTALLED
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    if handlers is not None:
        _remove_handler(getattr(handlers, 'load_post', []), _uv_suite_proxy_load_post)
        _remove_handler(getattr(handlers, 'save_pre', []), _uv_suite_proxy_save_pre)
    _HANDLERS_INSTALLED = False


def unregister_all() -> None:
    try:
        save_all_proxy_values(getattr(bpy, 'context', None))
    except Exception:
        pass
    _remove_handlers()
    for record in reversed(list(_PROXY_RECORDS.values())):
        attr_name = str(record.get('attr_name') or '')
        proxy_cls = record.get('proxy_cls')
        if attr_name:
            try:
                _suv_resource.unregister_property(bpy.types.WindowManager, attr_name)
            except Exception:
                pass
        if isinstance(proxy_cls, type):
            try:
                _safe_unregister_class(proxy_cls)
            except Exception:
                pass
    _PROXY_RECORDS.clear()


__all__ = [
    'apply_all_proxy_values',
    'ensure_proxy_for_class',
    'ensure_proxies_for_classes',
    'get_addon_preferences',
    'save_all_proxy_values',
    'save_proxy_values',
    'unregister_all',
]
