# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Auto Packing preset UI and overlap-toggle bridge for Smart UV Suite 1.8.126."""
from __future__ import annotations

import bpy

_ORIGINALS = {}


def _ws(context):
    try:
        return getattr(getattr(context, 'scene', None), 'suv_workspace', None)
    except Exception:
        return None


def _overlap_merge_enabled(context) -> bool:
    ws = _ws(context)
    if ws is None:
        return True
    for name in ('unified_pack_merge_overlap', 'unified_pack_overlap_as_group', 'unified_pack_merge_overlaps', 'unified_pack_merge_overlapping'):
        try:
            if hasattr(ws, name):
                return bool(getattr(ws, name))
        except Exception:
            pass
    return True


def _patch_legacy_unified_guard(context=None) -> None:
    try:
        from . import unified_packing as up
    except Exception:
        return
    fn = getattr(up, '_suv41_selected_records_have_overlap', None)
    if callable(fn) and '_unified_overlap_guard' not in _ORIGINALS:
        _ORIGINALS['_unified_overlap_guard'] = fn

        def _guard(records, ctx=None, *, _orig=fn):
            if not _overlap_merge_enabled(ctx or getattr(bpy, 'context', None)):
                return False
            return bool(_orig(records, ctx))

        up._suv41_selected_records_have_overlap = _guard


def install(package_globals: dict | None = None, context=None) -> None:
    ctx = context or getattr(bpy, 'context', None)
    try:
        from . import uv_packing_methods_18110 as uvpack
        try:
            from . import unified_packing as up
            cls = getattr(up, 'SMARTUVSUITE_OT_unified_auto_pack', None)
            if cls is not None:
                _ORIGINALS.setdefault('unified_execute', getattr(cls, 'execute', None))
                cls.execute = getattr(uvpack, '_execute_18110', getattr(uvpack, '_execute_18121', None))
            up._multi_execute_unified_auto_pack = getattr(uvpack, '_execute_18110', getattr(uvpack, '_execute_18121', None))
            try:
                uvpack._ensure_unified_auto_pack_operator_properties(up)
            except Exception:
                pass
        except Exception:
            pass
    except Exception:
        pass
    _patch_legacy_unified_guard(ctx)
    if package_globals is not None:
        try:
            package_globals['__version__'] = '1.0.0'
            package_globals['bl_info']['version'] = (1, 0, 0)
            package_globals['bl_info']['author'] = 'JELararagi'
            package_globals['_SUS_BL_INFO_FALLBACK'] = dict(package_globals.get('bl_info') or {})
        except Exception:
            pass


def unregister() -> None:
    try:
        from . import unified_packing as up
        cls = getattr(up, 'SMARTUVSUITE_OT_unified_auto_pack', None)
        original = _ORIGINALS.get('unified_execute')
        if cls is not None and original is not None:
            cls.execute = original
        original_guard = _ORIGINALS.get('_unified_overlap_guard')
        if callable(original_guard):
            up._suv41_selected_records_have_overlap = original_guard
    except Exception:
        pass


def apply_all(package_globals: dict | None = None, context=None) -> None:
    install(package_globals, context)
