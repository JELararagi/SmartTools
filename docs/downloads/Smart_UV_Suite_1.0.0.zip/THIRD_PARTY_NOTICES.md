# Third-party notices / 第三者のソフトウェアの表示

This add-on is licensed under GPL-3.0-or-later. Parts of it are derived from the software listed below; their copyright holders and licenses are kept here.
このアドオンは GPL-3.0-or-later です。一部は次のソフトウェアに由来します。元の著作権者とライセンスをここに残します。

## bl_ui
- Origin / 出どころ: Blender 5.1 bundled startup scripts (scripts/startup/bl_ui)
- Copyright / 著作権者: Blender Foundation / Blender Authors
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - uv_repair_inspect_show.py
  - uv_repair_workflow_toggle.py
