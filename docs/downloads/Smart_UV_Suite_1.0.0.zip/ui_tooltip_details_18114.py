# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Per-button tooltip and scoped Help details for Smart UV Suite.

This module deliberately does not change panel layout, labels, or operator
execution.  It only supplies localized, item-specific explanations for buttons
that share one operator class through action/mode/target properties, and adds
scoped Help popup content for the item that opened the popup.
"""
from __future__ import annotations

from dataclasses import dataclass
import sys
from typing import Any, Iterable

try:  # Blender is available during add-on registration and popup drawing.
    import bpy  # type: ignore
except Exception:  # pragma: no cover - keeps syntax checks outside Blender safe.
    bpy = None  # type: ignore


@dataclass(frozen=True)
class Detail:
    title_en: str
    title_ja: str
    function_en: str
    function_ja: str
    usage_en: str
    usage_ja: str


_DETAILS: dict[tuple[str, str, str], Detail] = {}
_STATIC_DETAILS: dict[str, Detail] = {}
_SETTING_DETAILS: dict[str, Detail] = {}
_HELP_GROUPS: dict[str, list[dict[str, Any]]] = {}
_SECTION_ALIASES: dict[str, tuple[str, ...]] = {}
_PATCHED_CLASSES: dict[type, Any] = {}
_SCANNED_CLASS_IDS: set[int] = set()
_INSTALLED = False

_INTERESTING_PROPS = (
    "action",
    "mode",
    "target",
    "issue",
    "profile",
    "preset",
    "intent",
    "direction",
    "text",
    "help_id",
)


def _is_ja(context=None) -> bool:
    try:
        from . import text_translation as _text_translation  # type: ignore
        return bool(_text_translation.is_ja(context))
    except Exception:
        pass
    try:
        lang = str(getattr(getattr(getattr(context, "preferences", None), "view", None), "language", "") or "")
        if lang.lower().startswith("ja"):
            return True
    except Exception:
        pass
    try:
        if bpy is not None:
            lang = str(getattr(getattr(getattr(bpy.context, "preferences", None), "view", None), "language", "") or "")
            return lang.lower().startswith("ja")
    except Exception:
        pass
    return False


def _pick(en: str, ja: str, context=None) -> str:
    try:
        from . import text_translation as _text_translation  # type: ignore
        return str(_text_translation.pick(str(en or ""), str(ja or ""), context))
    except Exception:
        return str(ja if _is_ja(context) else en)


def _norm(value: Any) -> str:
    return str(value or "").strip().upper()


def _read_prop(properties: Any, name: str, default: str = "") -> str:
    try:
        if properties is None:
            return default
        if hasattr(properties, name):
            return str(getattr(properties, name) or default)
    except Exception:
        pass
    try:
        if isinstance(properties, dict):
            return str(properties.get(name, default) or default)
    except Exception:
        pass
    return default


def _detail(title_en: str, title_ja: str, function_en: str, function_ja: str, usage_en: str, usage_ja: str) -> Detail:
    return Detail(
        str(title_en or ""),
        str(title_ja or title_en or ""),
        str(function_en or ""),
        str(function_ja or function_en or ""),
        str(usage_en or ""),
        str(usage_ja or usage_en or ""),
    )


def _add(op_ids: str | Iterable[str], prop: str, value: str, title_en: str, title_ja: str, function_en: str, function_ja: str, usage_en: str, usage_ja: str) -> None:
    ids = (op_ids,) if isinstance(op_ids, str) else tuple(op_ids)
    d = _detail(title_en, title_ja, function_en, function_ja, usage_en, usage_ja)
    for op_id in ids:
        if op_id:
            _DETAILS[(str(op_id), str(prop or "action"), _norm(value))] = d


_add(
    "smart_uv_suite.seam_settings_action", "action", "CLEAR_SELECTED",
    "Clear Seams", "シーム解除",
    "Clears seams from selected mesh edges.", "選択したメッシュ辺のシームを解除します。",
    "Select mesh edges in Edit Mode, then run Clear Seams.",
    "編集モードでメッシュ辺を選択してから「シーム解除」を実行します。",
)


def _static(op_id: str, title_en: str, title_ja: str, function_en: str, function_ja: str, usage_en: str, usage_ja: str) -> None:
    if op_id:
        _STATIC_DETAILS[str(op_id)] = _detail(title_en, title_ja, function_en, function_ja, usage_en, usage_ja)


def _setting(prop: str, title_en: str, title_ja: str, function_en: str, function_ja: str, usage_en: str, usage_ja: str) -> None:
    if prop:
        _SETTING_DETAILS[str(prop)] = _detail(title_en, title_ja, function_en, function_ja, usage_en, usage_ja)


_DIRECTION_OPS = (
    "smart_uv_suite.direction_align",
    "smart_uv_suite.direction_align_action",
    "smart_uv_suite.vertex_align_action",
    "smart_uv_suite.island_direction_align",
    "smart_uv_suite.uv_layout_action",
)
_LAYOUT_OPS = (
    "smart_uv_suite.uv_layout_action",
    "smart_uv_suite.pack_layout_action",
    "smart_uv_suite.native_align_action",
    "smart_uv_suite.native_pack_action",
    "smart_uv_suite.native_hub_action",
)

# Direction align buttons.  Each action receives its own explanation because the
# same operator class is reused by many UI buttons.
for _value, _title_en, _title_ja, _axis_en, _axis_ja in (
    ("ALIGN_TL", "Align Top Left", "左上へ整列", "top-left corner", "左上角"),
    ("ALIGN_TOP", "Align Top", "上へ整列", "top edge", "上端"),
    ("ALIGN_TR", "Align Top Right", "右上へ整列", "top-right corner", "右上角"),
    ("ALIGN_LEFT", "Align Left", "左へ整列", "left edge", "左端"),
    ("ALIGN_CENTER", "Align Center", "中央へ整列", "center point", "中央点"),
    ("ALIGN_RIGHT", "Align Right", "右へ整列", "right edge", "右端"),
    ("ALIGN_BL", "Align Bottom Left", "左下へ整列", "bottom-left corner", "左下角"),
    ("ALIGN_BOTTOM", "Align Bottom", "下へ整列", "bottom edge", "下端"),
    ("ALIGN_BR", "Align Bottom Right", "右下へ整列", "bottom-right corner", "右下角"),
):
    _add(
        _DIRECTION_OPS,
        "action",
        _value,
        _title_en,
        _title_ja,
        f"Moves the selected UV elements or selected islands so their bounding-box {_axis_en} matches the reference position for the current Direction Align target.",
        f"方向整列の現在の対象に従い、選択中のUV要素またはアイランドの外接矩形の{_axis_ja}を基準位置へ揃えます。",
        "Select UV vertices, edges, faces, or islands, choose Vertex or Island as the target, then press this button.  Only the requested direction is changed; the internal shape is preserved.",
        "UV頂点、辺、面、またはアイランドを選択し、対象を「頂点」または「アイランド」に切り替えてから押します。指定方向だけを移動し、内部形状は保持します。",
    )

for _value, _title_en, _title_ja, _function_en, _function_ja, _usage_en, _usage_ja in (
    (
        "ALIGN_H",
        "Horizontal Center",
        "横中央",
        "Aligns the horizontal centers of the selected UV elements or islands to one shared vertical center line.",
        "選択中のUV要素またはアイランドの横方向中心を、共通の縦中心線へ揃えます。",
        "Use when a row of vertices or islands should share the same U-coordinate center without changing their vertical placement.",
        "頂点列やアイランド群のU方向中心だけを揃え、V方向の位置は変えたくないときに使います。",
    ),
    (
        "ALIGN_V",
        "Vertical Center",
        "縦中央",
        "Aligns the vertical centers of the selected UV elements or islands to one shared horizontal center line.",
        "選択中のUV要素またはアイランドの縦方向中心を、共通の横中心線へ揃えます。",
        "Use when a column of vertices or islands should share the same V-coordinate center without changing their horizontal placement.",
        "頂点列やアイランド群のV方向中心だけを揃え、U方向の位置は変えたくないときに使います。",
    ),
    (
        "ALIGN_H_GROUP",
        "Horizontal Center by Group",
        "横中央 グループ",
        "Separates the current UV selection into connected groups inside each island, then aligns only the horizontal center of each group within its own island.",
        "現在のUV選択を各アイランド内の連結グループに分け、各グループの横方向中心だけをそのアイランド内の基準へ揃えます。",
        "Use this after selecting several vertex groups across multiple islands.  Each island is processed independently, so another island does not become the reference.",
        "複数アイランドにまたがる頂点グループを選択した後に使います。アイランドごとに別処理されるため、別アイランドが基準になりません。",
    ),
    (
        "ALIGN_V_GROUP",
        "Vertical Center by Group",
        "縦中央 グループ",
        "Separates the current UV selection into connected groups inside each island, then aligns only the vertical center of each group within its own island.",
        "現在のUV選択を各アイランド内の連結グループに分け、各グループの縦方向中心だけをそのアイランド内の基準へ揃えます。",
        "Use this for columns or stacked vertex groups across several islands.  The grouping and reference are resolved per island.",
        "複数アイランド上の縦列や重なった頂点グループに使います。グループ分けと基準はアイランドごとに解決されます。",
    ),
    (
        "DISTRIBUTE_H",
        "Distribute Horizontally",
        "横均等",
        "Places the selected UV elements or islands at even horizontal intervals between the leftmost and rightmost selected bounds.",
        "選択中のUV要素またはアイランドを、選択範囲の左端と右端の間に横方向へ等間隔配置します。",
        "Select three or more targets that should be spaced evenly, then press this button.  Vertical positions are preserved as much as possible.",
        "3つ以上の対象を選択して押します。横方向の間隔を均等にし、縦方向の位置は可能な限り保持します。",
    ),
    (
        "DISTRIBUTE_V",
        "Distribute Vertically",
        "縦均等",
        "Places the selected UV elements or islands at even vertical intervals between the bottommost and topmost selected bounds.",
        "選択中のUV要素またはアイランドを、選択範囲の下端と上端の間に縦方向へ等間隔配置します。",
        "Select three or more targets that should be spaced evenly, then press this button.  Horizontal positions are preserved as much as possible.",
        "3つ以上の対象を選択して押します。縦方向の間隔を均等にし、横方向の位置は可能な限り保持します。",
    ),
    (
        "DISTRIBUTE_H_GROUP",
        "Distribute Groups Horizontally",
        "横均等 グループ",
        "Splits selected UVs into connected groups per island and distributes those groups horizontally using only groups from the same island as references.",
        "選択UVをアイランドごとの連結グループに分け、同じアイランド内のグループだけを基準として横方向へ均等配置します。",
        "Use for multiple selected groups across several islands.  Each island keeps its own spacing calculation.",
        "複数アイランドにまたがって選択した複数グループに使います。各アイランドは独立した間隔計算を行います。",
    ),
    (
        "DISTRIBUTE_V_GROUP",
        "Distribute Groups Vertically",
        "縦均等 グループ",
        "Splits selected UVs into connected groups per island and distributes those groups vertically using only groups from the same island as references.",
        "選択UVをアイランドごとの連結グループに分け、同じアイランド内のグループだけを基準として縦方向へ均等配置します。",
        "Use for multiple selected groups across several islands.  Other islands do not affect the spacing of the current island.",
        "複数アイランドにまたがって選択した複数グループに使います。別アイランドの位置は現在のアイランドの間隔に影響しません。",
    ),
    (
        "FLIP_H",
        "Flip Horizontal",
        "左右反転",
        "Flips the selected UV vertices or selected islands horizontally around their selection center.",
        "選択中のUV頂点またはアイランドを、選択範囲の中心を基準に左右反転します。",
        "Use when the UV shape should face the opposite U direction while staying in the same general location.",
        "UV形状のU方向を反転し、全体位置はおおむね維持したいときに使います。",
    ),
    (
        "FLIP_V",
        "Flip Vertical",
        "上下反転",
        "Flips the selected UV vertices or selected islands vertically around their selection center.",
        "選択中のUV頂点またはアイランドを、選択範囲の中心を基準に上下反転します。",
        "Use when the UV shape should face the opposite V direction while staying in the same general location.",
        "UV形状のV方向を反転し、全体位置はおおむね維持したいときに使います。",
    ),
    (
        "MIRROR_H",
        "Mirror Horizontal",
        "水平ミラー",
        "Mirrors selected islands horizontally while preserving each island shell shape.",
        "選択アイランドのシェル形状を保ったまま水平方向にミラーします。",
        "Use for island-level layout mirroring when the target is Island.",
        "対象がアイランドのとき、アイランド単位で左右を反転する用途に使います。",
    ),
    (
        "MIRROR_V",
        "Mirror Vertical",
        "垂直ミラー",
        "Mirrors selected islands vertically while preserving each island shell shape.",
        "選択アイランドのシェル形状を保ったまま垂直方向にミラーします。",
        "Use for island-level layout mirroring when the target is Island.",
        "対象がアイランドのとき、アイランド単位で上下を反転する用途に使います。",
    ),
    (
        "ROTATE_CCW",
        "Rotate 90° Counterclockwise",
        "90°左回転",
        "Rotates the selected UV elements or islands 90 degrees counterclockwise around the selection center.",
        "選択中のUV要素またはアイランドを、選択範囲の中心を基準に90度左回転します。",
        "Use after selection when the UV orientation needs a quarter-turn counterclockwise.",
        "選択後、UVの向きを反時計回りに90度変えたいときに使います。",
    ),
    (
        "ROTATE_CW",
        "Rotate 90° Clockwise",
        "90°右回転",
        "Rotates the selected UV elements or islands 90 degrees clockwise around the selection center.",
        "選択中のUV要素またはアイランドを、選択範囲の中心を基準に90度右回転します。",
        "Use after selection when the UV orientation needs a quarter-turn clockwise.",
        "選択後、UVの向きを時計回りに90度変えたいときに使います。",
    ),
):
    _add(_DIRECTION_OPS, "action", _value, _title_en, _title_ja, _function_en, _function_ja, _usage_en, _usage_ja)

_add(
    "smart_uv_suite.direction_align_mode",
    "target",
    "VERTEX",
    "Target: Vertex",
    "対象: 頂点",
    "Sets Direction Align to operate on the selected UV vertices, edges, or faces instead of moving whole islands.",
    "方向整列の処理対象を、アイランド全体ではなく選択中のUV頂点、辺、面に切り替えます。",
    "Press this before using the direction pad when you want to adjust only selected elements inside an island.",
    "アイランド内の選択要素だけを整列したい場合、方向パッドを押す前に選択します。",
)
_add(
    "smart_uv_suite.direction_align_mode",
    "target",
    "ISLAND",
    "Target: Island",
    "対象: アイランド",
    "Sets Direction Align to move selected UV islands as shells while preserving each island's internal shape.",
    "方向整列の処理対象をUVアイランドに切り替え、各アイランド内部の形状を保ったまま移動します。",
    "Press this before using the direction pad when you want to align or distribute island shells.",
    "アイランド単位で整列、均等配置、回転、反転したい場合、方向パッドを押す前に選択します。",
)

# General layout-board and native action aliases.
for _value, _title_en, _title_ja, _function_en, _function_ja, _usage_en, _usage_ja in (
    ("CROP", "Crop to Tile", "タイルへクロップ", "Normalizes selected UV bounds to the target tile while applying configured padding.", "選択UVの外接矩形を対象タイルへ正規化し、設定された余白を適用します。", "Select islands or UVs that should occupy the tile area, then run Crop.", "タイル範囲を使わせたいアイランドまたはUVを選択して実行します。"),
    ("FILL", "Fill Tile", "タイルを埋める", "Scales the selected UV bounds until the tile area is filled while respecting padding.", "選択UVの外接矩形がタイルを埋めるようにスケールし、余白設定を反映します。", "Use when the selection should maximize texture use inside the current tile.", "現在のタイル内でテクスチャ領域をできるだけ使いたいときに使います。"),
    ("FIT", "Fit to Tile", "タイルにフィット", "Fits the selected UV bounds inside the target tile without cropping outside the tile.", "選択UVの外接矩形を対象タイル内へ収めます。タイル外へはみ出さないようにします。", "Use for safe placement before packing, baking, or export.", "パッキング、ベイク、書き出し前に安全にタイル内へ収めたいときに使います。"),
    ("SORT_H", "Sort Horizontally", "横方向に並べ替え", "Orders selected islands or groups from left to right based on their bounds.", "選択アイランドまたはグループを外接矩形に基づいて左から右へ並べ替えます。", "Select multiple targets and run this when layout order should follow U direction.", "複数対象を選択し、U方向に沿って順番を整えたいときに使います。"),
    ("SORT_V", "Sort Vertically", "縦方向に並べ替え", "Orders selected islands or groups from bottom to top based on their bounds.", "選択アイランドまたはグループを外接矩形に基づいて下から上へ並べ替えます。", "Select multiple targets and run this when layout order should follow V direction.", "複数対象を選択し、V方向に沿って順番を整えたいときに使います。"),
    ("STRAIGHT", "Straighten", "直線化", "Straightens selected UV vertices along their dominant axis.", "選択UV頂点を主要軸に沿って直線化します。", "Select a UV edge chain or vertex row, then run Straighten.", "UVの辺ループや頂点列を選択して実行します。"),
    ("STRAIGHTEN", "Straighten", "直線化", "Straightens selected UV vertices along their dominant axis.", "選択UV頂点を主要軸に沿って直線化します。", "Select a UV edge chain or vertex row, then run Straighten.", "UVの辺ループや頂点列を選択して実行します。"),
    ("RECTIFY", "Rectify", "矩形補正", "Reshapes a selected UV quad region toward a rectangular grid while preserving the selected area as much as possible.", "選択したUV四角形領域を、可能な限り面積を保ちながら矩形グリッド状へ補正します。", "Select a quad-like UV region and run Rectify.", "四角形状のUV領域を選択して実行します。"),
    ("GRIDIFY", "Gridify", "グリッド化", "Moves selected UV vertices toward a grid-like arrangement.", "選択UV頂点をグリッド状の配置へ近づけます。", "Use on rows and columns that should become a cleaner lattice.", "行列状に整えたいUV頂点群に使います。"),
    ("SQUAREIFY", "Squareify", "正方形化", "Adjusts selected UV quads toward square proportions.", "選択UV四角形を正方形に近い比率へ整えます。", "Use after selecting a quad grid where checker distortion should be reduced.", "チェッカー歪みを減らしたい四角形グリッドを選択して使います。"),
    ("RELAX", "Relax", "リラックス", "Reduces UV stretch by relaxing selected UV coordinates while preserving boundaries where possible.", "境界を可能な限り保ちながら選択UV座標をリラックスし、UVの伸びを軽減します。", "Select the UV region, set the iteration count if available, then run Relax.", "UV領域を選択し、必要なら反復回数を設定して実行します。"),
    ("STITCH", "Stitch", "スティッチ", "Connects matching selected UV edges using Blender-compatible stitch behavior.", "一致する選択UV辺をBlender互換のスティッチ処理で接続します。", "Select corresponding UV edges on adjacent islands and run Stitch.", "隣接アイランドの対応するUV辺を選択して実行します。"),
    ("WELD", "Weld", "ウェルド", "Merges selected UV vertices that can share one UV coordinate.", "同じUV座標へまとめられる選択UV頂点を結合します。", "Select overlapping or near-overlapping UV vertices, then run Weld.", "重なった、または近いUV頂点を選択して実行します。"),
    ("PIN", "Pin", "ピン", "Pins selected UV vertices so unwrap and relax operations can keep them fixed.", "選択UV頂点をピン留めし、展開やリラックス時に固定できるようにします。", "Select UV vertices that must stay in place, then run Pin.", "位置を維持したいUV頂点を選択して実行します。"),
    ("UNPIN", "Unpin", "ピン解除", "Clears pin state from selected UV vertices.", "選択UV頂点のピン状態を解除します。", "Select pinned UV vertices, then run Unpin.", "ピン留め済みのUV頂点を選択して実行します。"),
    ("ORIENT_BBOX", "Orient by Bounds", "外接矩形で向き調整", "Rotates the selected UV region to match its bounding-box orientation.", "選択UV領域を外接矩形の向きに合わせて回転します。", "Use when an island should be made more horizontal or vertical before packing.", "パッキング前にアイランドを水平または垂直寄りにしたいときに使います。"),
    ("ORIENT_EDGE", "Orient by Edge", "辺で向き調整", "Uses a selected UV edge or edge chain as the orientation reference.", "選択したUV辺または辺列を向きの基準として使います。", "Select the reference edge and the UV region, then run this command.", "基準にしたい辺とUV領域を選択して実行します。"),
    ("ROTATE_90", "Rotate 90°", "90°回転", "Rotates the selected UV region by 90 degrees.", "選択UV領域を90度回転します。", "Use when the current orientation needs a quarter-turn before layout or packing.", "レイアウトやパック前に向きを90度変えたいときに使います。"),
    ("FLIP_U", "Flip U", "U反転", "Mirrors the selected UV region along the U direction.", "選択UV領域をU方向で反転します。", "Use for horizontal UV mirroring.", "UVを左右方向に反転したいときに使います。"),
    ("FLIP_V", "Flip V", "V反転", "Mirrors the selected UV region along the V direction.", "選択UV領域をV方向で反転します。", "Use for vertical UV mirroring.", "UVを上下方向に反転したいときに使います。"),
    ("SNAP_PIXEL", "Snap Pixel", "ピクセル吸着", "Moves selected UVs to texture-pixel aligned positions using the current texture size.", "現在のテクスチャサイズに基づき、選択UVをピクセル境界に合う位置へ移動します。", "Set the texture size, select UVs, then run Pixel snap.", "テクスチャサイズを設定し、UVを選択してからピクセル吸着を実行します。"),
):
    _add(_LAYOUT_OPS, "action", _value, _title_en, _title_ja, _function_en, _function_ja, _usage_en, _usage_ja)

# Native unified section actions.
_NATIVE_ACTIONS = {
    "smart_uv_suite.native_basic_action": {
        "CHECKER_CREATE": ("Checker", "チェッカー", "Creates and assigns the managed checker material for UV distortion preview.", "UV歪み確認用の管理チェッカーマテリアルを作成して割り当てます。", "Set image size and tile count, then press Checker.", "画像解像度とチェック数を設定してから「チェッカー」を押します。"),
        "FOCUS_VIEW": ("Focus View", "表示調整", "Centers the UV Editor on the current selection, or the 3D Viewport when no UV Editor is open.", "UV エディターの表示を今の選択へ寄せます。UV エディターを開いていない時は 3D ビューを寄せます。", "Select the target element and press Focus.", "対象要素を選択して「表示調整」を押します。"),
        "SNAP_GRID": ("Snap Grid", "グリッド吸着", "Snaps selected UV coordinates to the nearest visible UV editor grid line, including fine sub-grid lines that appear while zoomed in.", "選択UV座標を最寄りのUVエディター表示グリッドへ吸着します。ズーム時に表示される薄い細分化グリッドも対象に含めます。", "Zoom the UV editor to the grid density you want, select UVs, then press Snap Grid.", "UVエディターを目的のグリッド密度までズームし、UVを選択してから「グリッド吸着」を押します。"),
        "SNAP_VERTEX": ("Snap Vertex", "頂点吸着", "Finds selected UV vertices within the distance setting and moves each close group to its shared midpoint.", "距離設定内にある選択UV頂点同士を検出し、近接グループごとの中点へ揃えます。", "Set Distance, select vertices that should share one position, then press Snap Vertex.", "距離を設定し、同じ位置へ揃えたい頂点を選択してから「頂点吸着」を押します。"),
    },
    "smart_uv_suite.native_seam_action": {
        "MARK_SEAM": ("Mark Seam", "シームをマーク", "Marks selected mesh edges as seams.", "選択メッシュ辺にシームを設定します。", "Select edges in Edit Mode, then press Mark Seam.", "編集モードで辺を選択してから「シームをマーク」を押します。"),
        "CLEAR_SEAM": ("Clear Seam", "シームをクリア", "Clears seam marks from selected mesh edges.", "選択メッシュ辺のシーム設定を解除します。", "Select seam edges, then press Clear Seam.", "シーム辺を選択してから「シームをクリア」を押します。"),
        "SEAMS_FROM_ISLANDS": ("Seams from Islands", "島からシーム", "Converts current UV island borders into mesh seams.", "現在のUVアイランド境界をメッシュシームへ変換します。", "Use after arranging UV islands when mesh seams should match the island borders.", "UVアイランド整理後、メッシュシームを島境界に合わせたいときに使います。"),
        "CREASE_VALUE": ("Mark Crease Value", "クリース値でシーム化", "Marks edges as seams when their crease value matches the configured value within tolerance.", "辺のクリース値が設定値に許容差内で一致した場合、その辺をシーム化します。", "Set Crease Value, Tolerance, and Apply Mode, then run this command.", "クリース値、許容差、適用方式を設定してから実行します。"),
        "PIN": ("Pin", "ピン", "Pins selected UV vertices.", "選択UV頂点をピン留めします。", "Select UVs that must remain fixed during unwrap or relax, then press Pin.", "展開やリラックスで固定したいUVを選択して「ピン」を押します。"),
        "UNPIN": ("Unpin", "ピン解除", "Clears pins from selected UV vertices.", "選択UV頂点のピンを解除します。", "Select pinned UVs, then press Unpin.", "ピン留めされたUVを選択して「ピン解除」を押します。"),
        "PIN_INVERT": ("Invert Pins", "ピン反転", "Inverts pin state for selected UV vertices.", "選択UV頂点のピン状態を反転します。", "Select UVs and press Invert Pins to swap pinned and unpinned states.", "UVを選択し、ピン留め状態と解除状態を入れ替えたいときに押します。"),
        "AUTO_SEAM": ("Auto Seam", "自動シーム", "Analyzes angle, boundary, stretch, loop continuity, and tube cut candidates, then marks seams.", "角度、境界、伸び予測、ループ継続性、筒状カット候補を解析してシームを設定します。", "Adjust the advanced seam weights, then run Auto Seam on the selected mesh.", "詳細なシーム重みを設定し、選択メッシュに対して自動シームを実行します。"),
    },
    "smart_uv_suite.native_align_action": {
        "FIT": ("Fit", "フィット", "Fits selected UVs into the current tile with padding.", "選択UVを余白付きで現在のタイル内に収めます。", "Select UVs or islands and press Fit.", "UVまたはアイランドを選択して「フィット」を押します。"),
        "STRAIGHTEN": ("Straighten", "直線化", "Straightens selected UV vertices along the dominant axis.", "選択UV頂点を主要軸に沿って直線化します。", "Select a UV edge chain or vertex row, then press Straight.", "UV辺列または頂点列を選択して「直線化」を押します。"),
        "GRIDIFY": ("Gridify", "グリッド化", "Rearranges selected UVs toward a grid-like structure.", "選択UVをグリッド状の構造へ整えます。", "Use on quad-like UV selections that should form rows and columns.", "行列状にしたい四角形系UV選択に使います。"),
        "RELAX": ("Relax", "リラックス", "Reduces stretch by relaxing selected UV coordinates.", "選択UV座標をリラックスして伸びを軽減します。", "Set Relax iterations if shown, select UVs, then press Relax.", "反復回数を設定し、UVを選択してから「リラックス」を押します。"),
        "ROTATE_90": ("Rotate", "回転", "Rotates selected UVs by 90 degrees.", "選択UVを90度回転します。", "Use before packing when island orientation should change.", "パッキング前など、アイランドの向きを変えたいときに使います。"),
        "FLIP_U": ("Flip U", "U反転", "Mirrors selected UVs horizontally in U direction.", "選択UVをU方向に左右反転します。", "Select the UV region and press Flip U.", "UV領域を選択して「U反転」を押します。"),
        "FLIP_V": ("Flip V", "V反転", "Mirrors selected UVs vertically in V direction.", "選択UVをV方向に上下反転します。", "Select the UV region and press Flip V.", "UV領域を選択して「V反転」を押します。"),
        "SNAP_PIXEL": ("Snap Pixel", "ピクセル吸着", "Moves selected UV coordinates to the existing pixel-aligned positions and keeps the current pixel snap behavior unchanged.", "選択UV座標を既存のピクセル基準位置へ移動します。現行のピクセル吸着の挙動は変更しません。", "Set texture size, select UVs, then press Pixel snap.", "テクスチャサイズを設定し、UVを選択してから「ピクセル吸着」を押します。"),
        "SNAP_GRID": ("Snap Grid", "グリッド吸着", "Snaps selected UV coordinates to the nearest visible UV editor grid line, including fine sub-grid lines that appear while zoomed in.", "選択UV座標を最寄りのUVエディター表示グリッドへ吸着します。ズーム時に表示される薄い細分化グリッドも対象に含めます。", "Zoom the UV editor to the grid density you want, select UVs, then press Grid snap.", "UVエディターを目的のグリッド密度までズームし、UVを選択してから「グリッド吸着」を押します。"),
        "SNAP_VERTEX": ("Snap Vertex", "頂点吸着", "Finds selected UV vertices within the distance setting and moves each close group to its shared midpoint.", "距離設定内にある選択UV頂点同士を検出し、近接グループごとの中点へ揃えます。", "Set Distance, select vertices that should share one position, then press Vertex snap.", "距離を設定し、同じ位置へ揃えたい頂点を選択してから「頂点吸着」を押します。"),
        "STITCH_WELD": ("Stitch/Weld", "結合", "Connects or merges compatible selected UV edges and vertices.", "互換性のある選択UV辺または頂点を接続または結合します。", "Select matching UV edges or overlapping vertices, then press Stitch/Weld.", "対応するUV辺または重なった頂点を選択してから「結合」を押します。"),
    },
    "smart_uv_suite.native_pack_action": {
        "PACK": ("Pack", "パック", "Packs selected UV islands into the current tile using configured margins.", "選択UVアイランドを設定余白で現在のタイルへパックします。", "Set margin and rotation options, select islands, then run Pack.", "余白や回転設定を行い、アイランドを選択してパックします。"),
        "PACK_PRECISION": ("Precision Pack", "高精度パック", "Runs a more precise packing route with exact-margin spacing and rotation candidates.", "正確な余白間隔と回転候補を使う高精度パックを実行します。", "Use when final layout density and margin accuracy matter.", "最終配置で密度と余白精度を重視するときに使います。"),
        "PACK_UDIM": ("UDIM Pack", "UDIMパック", "Packs UVs with UDIM-aware placement where available.", "対応環境でUDIMを考慮した配置を行います。", "Set target tile or UDIM settings, then run UDIM Pack.", "対象タイルやUDIM設定を行ってから実行します。"),
        "HOTSPOT_FIT": ("Hotspot Fit", "ホットスポットフィット", "Fits selected UVs to a configured hotspot or atlas cell while preserving aspect ratio when enabled.", "設定済みホットスポットまたはアトラスセルへ、必要に応じて縦横比を保持しながらフィットします。", "Configure hotspot options, select UVs, then run Hotspot Fit.", "ホットスポット設定を行い、UVを選択して実行します。"),
    },
    "smart_uv_suite.native_bake_action": {
        "BAKE_PREP": ("Bake Prep", "ベイク準備", "Prepares UV layer, checker material, bake canvas, and Cycles-related setup for texture baking.", "テクスチャベイク用にUVレイヤー、チェッカーマテリアル、ベイクキャンバス、Cycles関連設定を準備します。", "Set texture size and padding, select the target mesh, then press Bake Prep.", "テクスチャサイズと余白を設定し、対象メッシュを選択して「ベイク準備」を押します。"),
        "DENSITY_GET": ("Get Density", "密度取得", "Measures texel density from the active UV and mesh area.", "アクティブUVとメッシュ面積からテクセル密度を測定します。", "Select a reference face or island and press Density.", "基準にしたい面またはアイランドを選択して「密度取得」を押します。"),
        "DENSITY_NORMALIZE": ("Normalize Density", "密度正規化", "Scales selected UVs toward the configured target texel density.", "選択UVを設定された目標テクセル密度へ近づけるようにスケールします。", "Set Target Density, select UVs, then press Normalize.", "目標密度を設定し、UVを選択して「密度正規化」を押します。"),
        "CHECKER_CREATE": ("Checker", "チェッカー", "Creates and assigns a checker material for previewing distortion and density.", "歪みと密度確認用のチェッカーマテリアルを作成して割り当てます。", "Set checker resolution and tile count, then press Checker.", "チェッカー解像度とチェック数を設定してから押します。"),
        "COLOR_ID_OBJECTS": ("Object IDs", "オブジェクトID", "Assigns distinct color ID materials to selected objects.", "選択オブジェクトごとに異なるカラーIDマテリアルを割り当てます。", "Select target objects, then press Object IDs.", "対象オブジェクトを選択して「オブジェクトID」を押します。"),
        "COLOR_ID_FACES": ("Face IDs", "面ID", "Assigns distinct color ID materials to selected faces.", "選択面に異なるカラーIDマテリアルを割り当てます。", "Select faces in Edit Mode, then press Face IDs.", "編集モードで面を選択して「面ID」を押します。"),
    },
    "smart_uv_suite.native_id_action": {
        "UVMAP_ADD": ("Add UV Map", "UVマップ追加", "Adds a UV map to selected mesh objects.", "選択メッシュオブジェクトにUVマップを追加します。", "Enter a UV name if needed, then press Add.", "必要に応じてUV名を入力してから「追加」を押します。"),
        "UVMAP_DUPLICATE": ("Duplicate UV Map", "UVマップ複製", "Duplicates the active UV map on the selected meshes.", "選択メッシュのアクティブUVマップを複製します。", "Activate the source UV map and press Duplicate.", "コピー元UVマップをアクティブにして「複製」を押します。"),
        "UVMAP_REMOVE": ("Remove UV Map", "UVマップ削除", "Removes the active or selected UV map from target meshes.", "対象メッシュからアクティブまたは指定UVマップを削除します。", "Confirm the target map, then press Remove.", "対象マップを確認してから「削除」を押します。"),
        "UVMAP_TRANSFER": ("Transfer UV", "UV転送", "Copies UV coordinates from the active object to selected meshes when topology is compatible.", "トポロジーが互換の場合、アクティブオブジェクトから選択メッシュへUV座標をコピーします。", "Select the source as active, select targets, then press Transfer.", "コピー元をアクティブにし、転送先も選択して「転送」を押します。"),
        "UV_COPY": ("Copy UV", "UVコピー", "Copies selected UV coordinates into the Smart UV clipboard.", "選択UV座標をSmart UVのクリップボードへコピーします。", "Select UVs and press Copy UV.", "UVを選択して「UVコピー」を押します。"),
        "UV_PASTE": ("Paste UV", "UV貼付", "Pastes Smart UV clipboard coordinates into the current selection.", "Smart UVクリップボードの座標を現在の選択へ貼り付けます。", "Select the destination UVs and press Paste UV.", "貼り付け先UVを選択して「UV貼付」を押します。"),
    },
    "smart_uv_suite.native_cleanup_action": {
        "SELECT_ZERO": ("Zero Area", "ゼロ", "Selects UV faces with degenerate or zero-area UV geometry.", "面積がない、または極端に小さいUV面を選択します。", "Run after opening the target UV map to locate collapsed UVs.", "対象UVマップを開き、潰れたUVを見つけるために実行します。"),
        "SELECT_FLIPPED": ("Flipped", "反転", "Selects UV faces whose winding is flipped.", "UVの巻き方向が反転している面を選択します。", "Run before baking or export to find mirrored winding problems.", "ベイクや書き出し前に、反転したUV面を検出するために使います。"),
        "SELECT_OVERLAP": ("Overlap", "重なり", "Selects probable overlapping UV faces.", "重なっている可能性のあるUV面を選択します。", "Use when checking unique UV layouts or lightmap layouts.", "ユニークUVやライトマップ用UVの確認に使います。"),
        "SELECT_UDIM": ("UDIM", "UDIM", "Selects UV faces outside the expected tile or crossing UDIM boundaries.", "想定タイル外、またはUDIM境界をまたぐUV面を選択します。", "Run when preparing tile-safe layouts.", "タイル安全なレイアウトを準備するときに使います。"),
        "AUTO_REPAIR": ("Auto Repair", "自動修復", "Runs a conservative repair route for common UV layout issues.", "一般的なUVレイアウト問題に対して保守的な修復処理を実行します。", "Use after issue selection confirms cleanup is needed.", "問題選択で修復が必要だと確認した後に使います。"),
        "SELECT_INVERT": ("Invert Selection", "反転選択", "Inverts the current mesh or UV issue selection.", "現在のメッシュまたはUV問題選択を反転します。", "Run after selecting issues when you need the complementary set.", "問題を選択した後、反対側の選択集合が必要なときに使います。"),
        "CLEAN_GENERATED": ("Clean Data", "データ整理", "Removes generated helper data such as temporary checker or report objects where safe.", "一時チェッカーやレポート用データなど、生成済み補助データを安全な範囲で削除します。", "Run when generated support data is no longer needed.", "生成済み補助データが不要になったときに実行します。"),
    },
    "smart_uv_suite.native_io_action": {
        "EXPORT_SETTINGS": ("Export Settings", "設定出力", "Writes current Smart UV settings to a Blender text block.", "現在のSmart UV設定をBlenderテキストブロックへ書き出します。", "Run before sharing settings or making a support report.", "設定共有やサポート報告前に実行します。"),
        "WRITE_REPORT": ("Write Report", "レポート", "Writes a concise Smart UV Suite report into a Blender text block.", "Smart UV Suiteの簡易レポートをBlenderテキストブロックへ書き出します。", "Run after a UV operation or inspection when a record is needed.", "UV処理や検査後、記録が必要なときに実行します。"),
        "CLEAN_GENERATED": ("Clean", "整理", "Removes generated Smart UV helper data where safe.", "Smart UVが生成した補助データを安全な範囲で削除します。", "Run when checker, report, or temporary helper data is no longer needed.", "チェッカー、レポート、一時補助データが不要になったときに使います。"),
    },
}
for _op_id, _actions in _NATIVE_ACTIONS.items():
    for _value, (_title_en, _title_ja, _function_en, _function_ja, _usage_en, _usage_ja) in _actions.items():
        _add(_op_id, "action", _value, _title_en, _title_ja, _function_en, _function_ja, _usage_en, _usage_ja)
        _add("smart_uv_suite.native_hub_action", "action", _value, _title_en, _title_ja, _function_en, _function_ja, _usage_en, _usage_ja)

# Unwrap method and seam snapshot buttons.
for _value, _title_en, _title_ja, _function_en, _function_ja, _usage_en, _usage_ja in (
    ("SMART_UNWRAP", "Smart Unwrap", "スマート展開", "Runs Smart UV Suite's integrated unwrap route using the selected method and current workspace settings.", "選択中の方式と現在のワークスペース設定を使って、Smart UV Suiteの統合展開ルートを実行します。", "Choose the method, set method-specific options, select a mesh or faces, then run unwrap.", "方式を選び、方式別設定を調整し、メッシュまたは面を選択してから展開を実行します。"),
    ("AUTO_UNWRAP", "Auto Unwrap", "自動展開", "Runs a high-quality automatic unwrap using temporary cuts, relax, normalization, and optional packing.", "一時カット、リラックス、正規化、任意のパッキングを使う高品質な自動展開を実行します。", "Use for general meshes when manually marking every seam is not practical.", "すべてのシームを手動指定するのが現実的でない一般メッシュに使います。"),
    ("PROJECT_WORLD", "World Planar", "ワールド平面投影", "Projects UVs from object or world axes for flat panels and mechanical shapes.", "平面パネルや機械形状向けに、オブジェクトまたはワールド軸からUVを投影します。", "Select faces with a clear planar direction, then run this projection.", "明確な平面方向を持つ面を選択して実行します。"),
    ("PROJECT_BOX", "Box Project", "ボックス投影", "Creates box-style projection for hard-surface forms.", "ハードサーフェス形状向けのボックス投影を作成します。", "Use for cubic or panel-like meshes that need fast projection unwrap.", "立方体やパネル状メッシュを素早く投影展開したいときに使います。"),
    ("PROJECT_CYLINDER", "Cylinder Project", "円柱投影", "Creates cylindrical projection for pipes and rounded parts.", "パイプや丸い部品向けに円柱投影を作成します。", "Select cylindrical faces, set seam direction if needed, then run.", "円柱状の面を選択し、必要に応じてシーム方向を決めて実行します。"),
    ("PROJECT_SPHERE", "Sphere Project", "球投影", "Creates spherical projection for dome-like forms.", "ドーム状や球状の形状向けに球投影を作成します。", "Use on round selections where spherical projection gives a cleaner unwrap.", "球投影が適した丸い選択領域に使います。"),
    ("PROJECT_VIEW", "View Project", "ビュー投影", "Projects UVs from the current view direction.", "現在のビュー方向からUVを投影します。", "Set the viewport to the desired projection direction, select faces, then run.", "投影したい方向にビューを合わせ、面を選択してから実行します。"),
):
    _add(("smart_uv_suite.native_unwrap_action", "smart_uv_suite.native_hub_action"), "action", _value, _title_en, _title_ja, _function_en, _function_ja, _usage_en, _usage_ja)

for _value, _title_en, _title_ja, _function_en, _function_ja, _usage_en, _usage_ja in (
    ("SAVE_SCENE", "Save Scene Seam Snapshot", "シーン保存", "Stores the current seam state inside the Blender scene using the configured snapshot name.", "現在のシーム状態を、設定されたスナップショット名でBlenderシーン内に保存します。", "Enter the scene save name, then run Save Scene before trying alternate seams.", "シーン内保存名を入力し、別のシームを試す前に「シーン保存」を実行します。"),
    ("LOAD_SCENE", "Load Scene Seam Snapshot", "シーン読込", "Restores a seam state previously saved inside the Blender scene.", "Blenderシーン内に保存したシーム状態を復元します。", "Choose the same snapshot name, then run Load Scene.", "同じスナップショット名を指定して「シーン読込」を実行します。"),
    ("SAVE_FILE", "Save Seam JSON", "外部保存", "Writes the current seam state to an external JSON file.", "現在のシーム状態を外部JSONファイルへ書き出します。", "Set the JSON path, then run Save JSON.", "JSONパスを設定してから「外部保存」を実行します。"),
    ("LOAD_FILE", "Load Seam JSON", "外部読込", "Loads seam state from an external JSON file.", "外部JSONファイルからシーム状態を読み込みます。", "Set the JSON path, then run Load JSON.", "JSONパスを設定してから「外部読込」を実行します。"),
):
    _add("smart_uv_suite.seam_snapshot_action", "action", _value, _title_en, _title_ja, _function_en, _function_ja, _usage_en, _usage_ja)

# Snap modes requested in the previous revision.
for _value, _title_en, _title_ja, _function_en, _function_ja, _usage_en, _usage_ja in (
    ("GRID", "Snap to Grid", "グリッド吸着", "Snaps selected UVs to the nearest visible UV editor grid line, including finer sub-grid lines that appear while zoomed in.", "選択UVを最寄りのUVエディター表示グリッドへ吸着します。ズーム時に表示される薄い細分化グリッドも対象に含めます。", "Zoom the UV editor to the grid density you want, select UVs, then press Grid.", "UVエディターを目的のグリッド密度までズームし、UVを選択して「グリッド」を押します。"),
    ("PIXEL", "Snap to Pixel", "ピクセル吸着", "Snaps selected UVs to texture pixel positions using the current texture-size settings.  This preserves the existing pixel snap behavior.", "現在のテクスチャサイズ設定を使い、選択UVをテクスチャピクセル位置へ吸着します。従来のピクセル吸着挙動を維持します。", "Set texture width and height, select UVs, then press Pixel.", "テクスチャの横幅と高さを設定し、UVを選択して「ピクセル」を押します。"),
    ("VERTEX", "Snap to Vertex Midpoint", "頂点吸着", "Finds selected UV vertices within the distance setting and moves each close group to its shared midpoint.", "距離設定内にある選択UV頂点同士を検出し、近接グループごとの中点へ揃えます。", "Set Distance, select vertices that should share one position, then press Vertex.", "距離を設定し、同じ位置へ揃えたい頂点を選択して「頂点」を押します。"),
):
    _add("smart_uv_suite.consolidated_snap_uv", "mode", _value, _title_en, _title_ja, _function_en, _function_ja, _usage_en, _usage_ja)

# Stitch action modes.
for _value, _title_en, _title_ja, _function_en, _function_ja, _usage_en, _usage_ja in (
    ("ISLAND_CONNECTED_TO_SELECTED", "Stitch Island: Connected to Selected", "島スティッチ 接続側を選択側へ", "Moves connected island edges to the selected island edges before stitching.", "接続側アイランドの辺を選択側アイランドの辺へ移動してからスティッチします。", "Select the reference island edge first, then run this mode.", "基準にしたいアイランド辺を選択してからこのモードを実行します。"),
    ("ISLAND_SELECTED_TO_CONNECTED", "Stitch Island: Selected to Connected", "島スティッチ 選択側を接続側へ", "Moves selected island edges to their connected counterpart before stitching.", "選択側アイランドの辺を接続先の辺へ移動してからスティッチします。", "Use when the connected island should stay in place.", "接続先アイランドを動かさず、選択側を寄せたいときに使います。"),
    ("ISLAND_AVERAGE", "Stitch Island: Average", "島スティッチ 平均", "Moves both island edges toward their average position before stitching.", "両側のアイランド辺を平均位置へ寄せてからスティッチします。", "Use when neither side should be the fixed reference.", "どちらか一方を固定基準にしたくないときに使います。"),
    ("EDGE_CONNECTED_TO_SELECTED", "Stitch Edge: Connected to Selected", "辺スティッチ 接続側を選択側へ", "Moves connected UV edge vertices to the selected edge position.", "接続側のUV辺頂点を選択辺の位置へ移動します。", "Select the edge that should stay fixed, then execute.", "固定したい辺を選択してから実行します。"),
    ("EDGE_SELECTED_TO_CONNECTED", "Stitch Edge: Selected to Connected", "辺スティッチ 選択側を接続側へ", "Moves selected UV edge vertices to their connected edge position.", "選択UV辺頂点を接続先の辺位置へ移動します。", "Use when the connected edge is already correctly placed.", "接続先の辺がすでに正しい位置にあるときに使います。"),
    ("EDGE_AVERAGE", "Stitch Edge: Average", "辺スティッチ 平均", "Moves both UV edge sides to the average of their positions.", "両側のUV辺を互いの平均位置へ移動します。", "Use when both sides should meet halfway.", "両側を中間位置で合わせたいときに使います。"),
):
    _add("smart_uv_suite.stitch_action", "mode", _value, _title_en, _title_ja, _function_en, _function_ja, _usage_en, _usage_ja)

# Static operators used directly by the active UI.
for _op_id, _title_en, _title_ja, _function_en, _function_ja, _usage_en, _usage_ja in (
    ("smart_uv_suite.export_uv_layout", "Export UV Layout", "UV配置の書き出し", "Exports the current UV layout image using Blender's UV layout export path.", "現在のUV配置をBlenderのUVレイアウト書き出し経路で画像として出力します。", "Set the target UV map and texture size, then run Export UV Layout.", "対象UVマップとテクスチャサイズを設定してから実行します。"),
    ("smart_uv_suite.checker_create", "Create Checker", "チェッカー作成", "Creates a checker image and material for UV preview.", "UV確認用のチェッカー画像とマテリアルを作成します。", "Set image resolution, tile count, colors, and names, then press Create Checker.", "画像解像度、チェック数、色、名前を設定してから「チェッカー作成」を押します。"),
    ("smart_uv_suite.checker_delete", "Delete Checker", "チェッカー削除", "Removes generated checker resources created by Smart UV Suite where safe.", "Smart UV Suiteが生成したチェッカー関連リソースを安全な範囲で削除します。", "Run when the checker preview is no longer needed.", "チェッカープレビューが不要になったときに実行します。"),
    ("smart_uv_suite.checker_material_toggle", "Apply or Restore Checker Material", "チェッカーマテリアル切替", "Applies the generated checker material to selected mesh objects or restores their previous materials.", "選択メッシュへ生成チェッカーマテリアルを反映、または以前のマテリアルへ戻します。", "Create the checker first, then press this button to toggle material preview.", "先にチェッカーを作成し、このボタンでマテリアルプレビューを切り替えます。"),
    ("smart_uv_suite.map_channel_object_select", "Object Row", "オブジェクト行", "Selects the mesh object row whose map channels are edited by the controls below the object list.", "リスト下の操作でマップチャンネルを編集するメッシュオブジェクト行を選択します。", "Click the object row first, then choose its unwrap map channel, rename, add, remove, or move channels.", "先にオブジェクト行をクリックし、そのオブジェクトの展開使用マップチャンネル選択、名称変更、追加、削除、移動を実行します。"),
    ("smart_uv_suite.map_channel_toggle_unify_check", "Unify Check", "統一チェック", "Toggles whether this object is included when map-channel index and name are unified.", "このオブジェクトを、マップチャンネルのインデックス番号と名前を統一する対象に含めるか切り替えます。", "Check every object that should match the list-selected source object, then run Unify Checked.", "リスト選択中の基準オブジェクトに揃えたいオブジェクトへチェックを入れてから、「チェック対象を統一」を実行します。"),
    ("smart_uv_suite.map_channel_unify_checked", "Unify Checked", "チェック対象を統一", "Uses the object selected in the map-channel list as the source and sets checked objects to the same unwrap map-channel index and UV map name.", "マップチャンネルリストで選択中のオブジェクトを基準にし、チェック済みオブジェクトの展開使用マップチャンネルを同じインデックス番号とUVマップ名へ揃えます。", "Select the source object row, check target objects, then run this command. UV coordinates are not copied; each object keeps its own UV data on the unified channel.", "基準にするオブジェクト行を選択し、対象オブジェクトにチェックを入れてから実行します。UV座標はコピーせず、各オブジェクト自身のUVデータを統一後のチャンネルに保持します。"),
    ("smart_uv_suite.map_channel_rename", "Rename Map Channel", "チャンネル名変更", "Renames the unwrap map channel selected on the object selected in the map-channel object list.", "マップチャンネルのオブジェクトリストで選択中のオブジェクトにある展開使用マップチャンネルの名前を変更します。", "Press Rename Channel, enter the new name in the popup, then confirm. Other selected objects are not changed.", "「チャンネル名変更」を押し、ポップアップで新しい名前を入力して確定します。他の選択オブジェクトは変更しません。"),
    ("smart_uv_suite.map_channel_add", "Add Map Channel", "マップチャンネル追加", "Adds a UV map channel to the object selected in the map-channel object list and makes it that object's unwrap/edit target.", "マップチャンネルのオブジェクトリストで選択中のオブジェクトへUVマップチャンネルを追加し、そのオブジェクトの展開/編集対象にします。", "Press Add, enter the new map name in the popup, then confirm. Other selected objects are not changed.", "「追加」を押し、ポップアップで新しいマップ名を入力して確定します。他の選択オブジェクトは変更しません。"),
    ("smart_uv_suite.map_channel_remove", "Remove Target Map Channel", "展開対象を削除", "Removes the unwrap target UV map channel from the object selected in the map-channel object list.", "マップチャンネルのオブジェクトリストで選択中のオブジェクトから、展開対象UVマップチャンネルを削除します。", "Select the object row and target channel, then press Remove Target.", "オブジェクト行と対象チャンネルを選択してから「展開対象を削除」を押します。"),
    ("smart_uv_suite.map_channel_move", "Move Map Channel", "マップチャンネル移動", "Moves the unwrap target UV map channel up or down on the object selected in the map-channel object list.", "マップチャンネルのオブジェクトリストで選択中のオブジェクト上で、展開対象UVマップチャンネルを上または下へ移動します。", "Select the object row and target channel, then press Move Up or Move Down.", "オブジェクト行と対象チャンネルを選択してから「上へ移動」または「下へ移動」を押します。"),
    ("smart_uv_suite.map_channel_copy", "Copy UV Layout to Target Channel", "UV展開情報を展開使用マップチャンネルへコピー", "Copies UV coordinates from the source UV channel to the unwrap target channel on the object selected in the map-channel object list.", "マップチャンネルのオブジェクトリストで選択中のオブジェクト上で、コピー元UVチャンネルから展開対象チャンネルへUV座標をコピーします。", "Set source and target channels for the selected object row, then press Copy.", "選択中のオブジェクト行でコピー元と展開対象を設定してからコピーを押します。"),
    ("smart_uv_suite.unwrap_auto_run", "Run Unwrap", "展開実行", "Runs the selected unwrap method with its visible settings.", "選択した展開方式を、表示中の設定で実行します。", "Choose Method, adjust Method Settings, select the mesh or faces, then press Run Unwrap.", "方式を選び、方式別設定を調整し、メッシュまたは面を選択して「展開実行」を押します。"),
    ("smart_uv_suite.align_edges", "Align Edge", "辺を整列", "Aligns selected UV edge vertices to a clean straight edge.", "選択UV辺の頂点をきれいな直線状に揃えます。", "Select a chain of UV edges or vertices, then press Align Edge. Whole faces are not lined up.", "UV の辺か頂点を線状に選択して「辺を整列」を押します。面全体を選んでも一直線にはしません。"),
    ("smart_uv_suite.inspect_orient_world", "World Align", "ワールド軸整列", "Turns selected UV regions as one piece so they line up with the world axes. A selected chain lies flat along its long side.", "選んだ UV 領域を形を変えずに回して、ワールド軸の向きにそろえます。線状に選んだ時は、長い方向へまっすぐ寝かせます。", "Use on UVs that should match object or world orientation.", "オブジェクトまたはワールド方向に合わせたいUVに使います。"),
    ("smart_uv_suite.vertex_straighten_selected", "Straighten", "直線化", "Straightens the selected UV vertex chain.", "選択UV頂点列を直線化します。", "Select a chain of UV vertices, then press Straighten.", "UV頂点列を選択してから「直線化」を押します。"),
    ("smart_uv_suite.vertex_even_straighten_selected", "Even Straighten", "均等直線化", "Straightens selected UV vertices and distributes them evenly along the line.", "選択UV頂点を直線化し、その直線上で等間隔に配置します。", "Select a vertex chain that should become a straight, evenly spaced row.", "直線かつ等間隔にしたい頂点列を選択して使います。"),
    ("smart_uv_suite.seam_rectify", "Rectify", "矩形補正", "Squares up each selected UV region. A quad grid gets straight rows and columns and keeps its outline, so an L stays an L; other shapes get a rectangular outline. Faces stay connected, and UVs joined to the region move with it.", "選んだ UV 領域ごとに四角く整えます。四角ポリゴンの格子は行と列がまっすぐにそろい、選んだ形のまま（L 字は L 字のまま）です。それ以外は外周が四角形になります。面どうしはつながったままで、つながっている周りの UV も一緒に動きます。", "Select the faces of a region, then press Rectify.", "領域の面を選択して「矩形補正」を押します。"),
    ("smart_uv_suite.align_uv_circle", "Circularize", "円形化", "Places selected UV vertices around a circle. A selected region gets a round outline with the inside fitted to it.", "選択UV頂点を円形状に配置します。面を選んだ時は、領域の外周を円にして内側を合わせます。", "Select a ring or loop of UV vertices, then press Circularize.", "リングまたはループ状のUV頂点を選択して「円形化」を押します。"),
    ("smart_uv_suite.align_normalize", "Normalize", "正規化", "Normalizes selected UV bounds and scale for a cleaner layout.", "選択UVの外接矩形とスケールを正規化して整えます。", "Select UVs that need consistent size or bounds, then press Normalize.", "サイズや外接範囲を整えたいUVを選択して「正規化」を押します。"),
    ("smart_uv_suite.align_relax", "Relax", "リラックス", "Evens out selected UVs to reduce stretch. The outline of a selected region stays in place.", "選択UVの内側をならして伸びを軽減します。選んだ領域の外周は動きません。", "Set Relax Iterations if shown, select UVs, then press Relax.", "リラックス反復を設定し、UVを選択してから押します。"),
    ("smart_uv_suite.vertex_set_flow_selected", "Set Flow", "フロー設定", "Adjusts selected UV vertices toward a smoother flow according to the strength setting.", "強度設定に従い、選択UV頂点をより滑らかな流れへ整えます。", "Set Flow Strength, select a row or loop, then press Set Flow.", "フロー強度を設定し、行またはループを選択してから実行します。"),
    ("smart_uv_suite.seam_mirror_uv", "Mirror UV", "UVミラー", "Copy the UVs of the selected faces to the faces on the opposite 3D side, mirrored in U.", "選んだ面の UV を、3D で反対側の面へ左右反転して写します。", "Select the UV region to mirror, then press Mirror UV.", "ミラーしたいUV領域を選択して「UVミラー」を押します。"),
    ("smart_uv_suite.seam_symmetry_snap", "Symmetry Snap", "対称スナップ", "Make the selected UVs symmetric for faces that are symmetric in 3D.", "3D で左右対称な面の UV を、左右対称にそろえます。", "Use on symmetric UV layouts after selecting vertices that should match across the axis.", "左右対称などのUVで、軸をまたいで一致させたい頂点を選択して使います。"),
    ("smart_uv_suite.seam_stack_pro", "Smart Stack", "スマートスタック", "Find islands that have the same shape, turn them to the same direction and stack them.", "同じ形のアイランドを探し、向きをそろえて 1 か所に重ねます。", "Select the islands, then press Smart Stack.", "アイランドを選んで「スマートスタック」を押します。"),
    ("smart_uv_suite.weld", "Weld", "ウェルド", "Move the selected UVs to one point.", "選んだ UV を 1 点にまとめます。", "Select overlapping or matching vertices, then press Weld.", "重なった、または一致させたい頂点を選択して「ウェルド」を押します。"),
    ("smart_uv_suite.seam_merge", "Merge Vertices", "頂点マージ", "Merge selected UV vertices that are within the Distance value.", "「距離」の中にある選んだ UV の頂点をまとめます。", "Select vertices that should become one UV position, then press Merge Vertices.", "同じUV位置にしたい頂点を選択して「頂点マージ」を押します。"),
    ("smart_uv_suite.unified_auto_pack", "Run Auto Pack", "自動パック実行", "Runs the configured automatic packing pipeline with margins, grouping, UDIM, hotspot, and density options.", "余白、グループ、UDIM、ホットスポット、密度オプションを使って設定済みの自動パッキング処理を実行します。", "Set the Auto Packing options, select UV islands or meshes, then press Run Auto Pack.", "自動パッキング設定を調整し、UVアイランドまたはメッシュを選択して「自動パック実行」を押します。"),
    ("smart_uv_suite.cursor_to_hover_uv_vertex", "2D Cursor to Hover Vertex", "ホバー頂点へ2Dカーソル", "Moves the UV editor 2D cursor to the UV vertex under the mouse cursor when the keymap is assigned.", "キーマップ割り当て時、マウス下のUV頂点へUVエディターの2Dカーソルを移動します。", "Register the keymap manually as shown in the panel, hover a UV vertex, then press the assigned key.", "パネル表示の通り手動でキーマップ登録し、UV頂点にマウスを重ねて割り当てキーを押します。"),
    ("smart_uv_suite.copy_operator_id", "Copy Operator ID", "オペレーターIDコピー", "Copies the displayed operator identifier for manual keymap registration or troubleshooting.", "手動キーマップ登録や確認用に、表示されているオペレーターIDをコピーします。", "Press Copy ID next to the entry you want to register.", "登録したい項目の横にある「IDコピー」を押します。"),
    ("smart_uv_suite.keymap_info_action", "Keymap Info Action", "キーマップ情報操作", "Runs a small keymap-information utility such as copying an operator ID.", "オペレーターIDコピーなどの小さなキーマップ情報操作を実行します。", "Use inside Keymap Info when manual registration is needed.", "手動登録が必要なとき、キーマップ情報内で使います。"),
):
    _static(_op_id, _title_en, _title_ja, _function_en, _function_ja, _usage_en, _usage_ja)

# Workspace and UV editor settings shown in the active UI.
for _prop, _title_en, _title_ja, _function_en, _function_ja, _usage_en, _usage_ja in (
    ("unwrap_map_channel", "Unwrap Map Channel", "展開使用マップチャンネル", "Chooses which UV map channel Smart UV Suite uses as the unwrap target.", "Smart UV Suiteが展開対象として使うUVマップチャンネルを指定します。", "Select the UV map that should receive unwrap, align, and pack results.", "展開、整列、パックの結果を書き込みたいUVマップを選択します。"),
    ("map_channel_new_name", "New Map Name", "新規マップ名", "Sets the name used when adding a new UV map channel.", "新規UVマップチャンネル追加時の名前を設定します。", "Enter the name before pressing Add.", "「追加」を押す前に名前を入力します。"),
    ("map_channel_copy_source", "Copy Source", "コピー元", "Chooses the UV map channel used as the source for copying UV coordinates.", "UV座標コピーのコピー元になるUVマップチャンネルを指定します。", "Set this before running Copy UV Layout to Unwrap Map Channel.", "「UV展開情報を展開使用マップチャンネルへコピー」を実行する前に設定します。"),
    ("canvas_size", "Texture Size", "テクスチャサイズ", "Defines the texture resolution used by padding, pixel snapping, checker, baking, and density-related calculations.", "余白、ピクセル吸着、チェッカー、ベイク、密度関連計算に使うテクスチャ解像度を指定します。", "Set this to the intended output texture size before fitting, packing, snapping, or baking.", "フィット、パック、吸着、ベイク前に、最終出力予定のテクスチャサイズへ設定します。"),
    ("fit_padding_px", "Fit Padding", "フィット余白", "Sets the pixel padding used by fit, fill, crop, bake preparation, and layout-safe placement.", "フィット、フィル、クロップ、ベイク準備、安全配置で使うピクセル余白を設定します。", "Increase it when islands need more bleed space for baking or mipmaps.", "ベイクやミップマップ用のにじみ領域が必要な場合は大きくします。"),
    ("checker_size_width", "Image Resolution Width", "画像解像度 横", "Sets the width of generated checker or preview images.", "生成チェッカーまたはプレビュー画像の横解像度を設定します。", "Use the same width as the target texture when checking density.", "密度確認時は目標テクスチャと同じ横解像度にします。"),
    ("checker_size_height", "Image Resolution Height", "画像解像度 縦", "Sets the height of generated checker or preview images.", "生成チェッカーまたはプレビュー画像の縦解像度を設定します。", "Use the same height as the target texture when checking density.", "密度確認時は目標テクスチャと同じ縦解像度にします。"),
    ("checker_tile_count_u", "Checker Tiles U", "チェックサイズ 横", "Sets the number of checker tiles along the U direction.", "U方向のチェッカータイル数を設定します。", "Raise it to inspect small distortions; lower it for broad density review.", "細かい歪みを見るときは増やし、広い密度確認では減らします。"),
    ("checker_tile_count_v", "Checker Tiles V", "チェックサイズ 縦", "Sets the number of checker tiles along the V direction.", "V方向のチェッカータイル数を設定します。", "Match U and V tile counts for square checker preview unless a non-square texture is intended.", "非正方形テクスチャでない限り、UとVのチェック数を合わせます。"),
    ("checker_color_a", "Checker Color 1", "チェックカラー1", "Sets the first color of the generated checker pattern.", "生成チェッカーパターンの1色目を設定します。", "Choose a color that contrasts with Checker Color 2.", "チェックカラー2と見分けやすい色を指定します。"),
    ("checker_color_b", "Checker Color 2", "チェックカラー2", "Sets the second color of the generated checker pattern.", "生成チェッカーパターンの2色目を設定します。", "Choose a contrasting color to make distortion visible.", "歪みが見えやすいよう、対比の強い色を指定します。"),
    ("checker_image_name", "Image Name", "画像名", "Sets the generated checker image name.", "生成チェッカー画像の名前を設定します。", "Use a unique name when several checker previews are needed.", "複数のチェッカープレビューを使い分ける場合は固有名にします。"),
    ("checker_material_name", "Material Name", "マテリアル名", "Sets the generated checker material name.", "生成チェッカーマテリアルの名前を設定します。", "Use a recognizable name so the preview material can be found later.", "後で見つけやすい名前を設定します。"),
    ("show_grid_over_image", "Grid Over Image", "画像上にグリッド", "Controls whether the UV editor grid is drawn over the image.", "UVエディターのグリッドを画像の上に表示するかを切り替えます。", "Enable it when the image hides grid guides.", "画像でグリッドが見えにくい場合に有効にします。"),
    ("grid_shape_source", "Grid Source", "グリッド基準", "Chooses how the UV editor determines grid shape and spacing.", "UVエディターがグリッド形状と間隔を決める基準を選びます。", "Use dynamic or pixel modes for texture-related layout, and custom modes for fixed guide spacing.", "テクスチャ基準の作業では動的またはピクセル系、固定ガイドが必要な場合はカスタム系を使います。"),
    ("tile_grid_shape", "Tile Grid", "タイルグリッド", "Defines the grid shape used for tiled or UDIM-style display.", "タイルまたはUDIM風表示に使うグリッド形状を指定します。", "Adjust this when using non-standard tile arrangements.", "標準的でないタイル配置を使う場合に調整します。"),
    ("custom_grid_subdivisions", "Grid Subdivisions", "グリッド分割", "Sets fixed custom grid subdivisions when the UV editor grid source supports it.", "UVエディターのグリッド基準が対応している場合、固定カスタムグリッド分割を設定します。", "Use this for repeatable guide spacing independent of zoom.", "ズームに依存しない一定のガイド間隔が必要な場合に使います。"),
    ("show_pixel_coords", "Pixel Coordinates", "ピクセル座標", "Shows UV position using pixel coordinates where the UV editor supports it.", "UVエディターが対応する場合、UV位置をピクセル座標で表示します。", "Enable it when editing pixel-accurate UV positions.", "ピクセル単位で正確にUV位置を編集したいときに有効にします。"),
    ("show_uv", "Display UVs", "UVを表示", "Toggles visibility of UV vertices and edges in the UV editor.", "UVエディター内のUV頂点と辺の表示を切り替えます。", "Keep it enabled for normal UV editing.", "通常のUV編集では有効にしておきます。"),
    ("show_faces", "Display Faces", "面を表示", "Toggles UV face overlay visibility.", "UV面オーバーレイの表示を切り替えます。", "Enable it when selecting or inspecting UV faces.", "UV面を選択または確認するときに有効にします。"),
    ("edge_display_type", "Edge Display", "エッジ表示", "Chooses how UV edges are displayed.", "UVエッジの表示方式を選びます。", "Change it when edge visibility is too dense or too faint for the current task.", "エッジ表示が密すぎる、または見えにくい場合に変更します。"),
    ("show_modified_edges", "Modified Edges", "変更後エッジ", "Shows edges after mesh modifiers when supported.", "対応している場合、モディファイア適用後の辺を表示します。", "Enable it when UV editing must match the evaluated mesh.", "評価後メッシュに合わせてUV編集したい場合に有効にします。"),
    ("show_stretch", "Stretch Display", "歪み表示", "Displays UV stretch visualization.", "UVの伸びや歪みを可視化します。", "Enable it to locate distortion before relax or density normalization.", "リラックスや密度正規化前に歪みを探す場合に有効にします。"),
    ("display_stretch_type", "Stretch Type", "歪み種類", "Chooses the metric used for UV stretch display.", "UV歪み表示に使う測定方式を選びます。", "Switch the metric depending on whether angle or area distortion matters more.", "角度歪みと面積歪みのどちらを重視するかで切り替えます。"),
    ("uv_opacity", "UV Opacity", "UV不透明度", "Controls opacity of UV vertices and edges.", "UV頂点と辺の不透明度を調整します。", "Lower it when the image needs to remain visible; raise it when editing edges.", "画像を見たいときは下げ、辺編集を重視するときは上げます。"),
    ("uv_face_opacity", "Face Opacity", "面不透明度", "Controls opacity of UV faces.", "UV面の不透明度を調整します。", "Raise it to inspect selected faces; lower it to see the image underneath.", "面確認時は上げ、下の画像を見たいときは下げます。"),
    ("uv_edge_opacity", "Edge Opacity", "エッジ不透明度", "Controls opacity of UV edges.", "UVエッジの不透明度を調整します。", "Increase it when precise edge placement is needed.", "エッジ位置を精密に確認したいときに上げます。"),
    ("stretch_opacity", "Stretch Opacity", "歪み不透明度", "Controls opacity of the stretch visualization overlay.", "歪み可視化オーバーレイの不透明度を調整します。", "Adjust until the distortion colors are readable without hiding the UVs.", "UVが隠れすぎず歪み色が読める濃さに調整します。"),
    ("pixel_round_mode", "Pixel Rounding", "ピクセル丸め", "Chooses how UV coordinates are rounded for pixel-oriented workflows.", "ピクセル基準の作業でUV座標をどのように丸めるかを選びます。", "Use when preparing pixel-art or exact texel-aligned UVs.", "ピクセルアートや正確なテクセル合わせのUVを作る場合に使います。"),
    ("lock_bounds", "Lock Bounds", "画像範囲固定", "Prevents UV editing from leaving the image bounds where the UV editor supports it.", "UVエディターが対応する場合、UV編集が画像範囲外へ出ないようにします。", "Enable for strict 0-1 tile editing.", "0-1タイル内に厳密に収めたい場合に有効にします。"),
    ("show_repeat", "Repeat Image", "画像を反復表示", "Repeats the image display outside the base tile.", "基準タイル外にも画像を反復表示します。", "Enable it for UDIM-like or tiled layout review.", "UDIM風またはタイル配置の確認に有効にします。"),
    ("auto_unwrap_mode", "Method", "方式", "Chooses the unwrap algorithm or Smart UV route used by Run Unwrap.", "「展開実行」で使う展開アルゴリズムまたはSmart UVルートを選びます。", "Pick the method that matches the mesh type before running unwrap.", "展開前に、メッシュ種類に合う方式を選びます。"),
    ("smart_unwrap_realtime_preview", "Live Unwrap", "ライブ展開", "Enables live preview or immediate update behavior where supported by the unwrap route.", "展開ルートが対応している場合、ライブプレビューまたは即時更新動作を有効にします。", "Enable while tuning settings; disable on heavy meshes if interaction becomes too slow.", "設定調整中は有効にし、重いメッシュで操作が遅い場合は無効にします。"),
    ("suv_crease_seam_value", "Crease Value", "クリース値", "Target crease value used when marking seams from edge crease.", "辺クリースからシーム化するときに参照する目標クリース値です。", "Set the crease value you want to convert into seams.", "シーム化したいクリース値を指定します。"),
    ("suv_crease_seam_tolerance", "Tolerance", "許容差", "Allowed difference around the target crease value.", "目標クリース値から許容する差です。", "Increase it when crease values are close but not exactly identical.", "クリース値が完全一致しない場合は大きくします。"),
    ("suv_crease_seam_apply_mode", "Apply Mode", "適用方式", "Chooses whether crease-value seam marking applies to selected edges or a broader mesh scope.", "クリース値シーム化を選択辺に適用するか、より広いメッシュ範囲へ適用するかを選びます。", "Use selected mode for controlled edits and broader modes for batch cleanup.", "細かく制御する場合は選択範囲、まとめて整理する場合は広い範囲を使います。"),
    ("seam_snapshot_name", "Scene Save Name", "シーン内保存名", "Name used for storing seam snapshots inside the Blender scene.", "Blenderシーン内にシームスナップショットを保存する名前です。", "Use different names for alternative seam versions.", "複数のシーム案を保存する場合は別名にします。"),
    ("seam_snapshot_filepath", "External JSON", "外部JSON", "File path used for saving or loading seam snapshots as JSON.", "シームスナップショットをJSONとして保存または読込するファイルパスです。", "Set a valid path before using Save JSON or Load JSON.", "「外部保存」または「外部読込」の前に有効なパスを設定します。"),
    ("suv_seam_mark_compliance", "Use Mark Seam Before Unwrap", "展開前シーム準拠", "Controls whether the unwrap route respects or prepares mesh seam marks before unwrapping.", "展開前にメッシュシームを尊重または準備するかを制御します。", "Enable when your marked seams should guide the unwrap result.", "設定済みシームで展開結果を制御したい場合に有効にします。"),
    ("suv_auto_seam_profile", "Preset", "プリセット", "Chooses a preset for automatic seam weights and thresholds.", "自動シームの重みとしきい値のプリセットを選びます。", "Start with a preset close to the asset type, then tune individual weights.", "アセット種類に近いプリセットから始め、必要に応じて個別の重みを調整します。"),
    ("suv_auto_seam_angle_threshold", "Angle Limit", "角度しきい値", "Mesh edge angle threshold used as a seam candidate criterion.", "シーム候補判定に使うメッシュ辺角度しきい値です。", "Lower it for more cuts; raise it for fewer angle-based cuts.", "カットを増やす場合は下げ、角度シームを減らす場合は上げます。"),
    ("suv_auto_seam_min_score", "Score Threshold", "採用スコア", "Minimum score required for an automatic seam candidate to be accepted.", "自動シーム候補を採用するために必要な最小スコアです。", "Raise it for conservative seams; lower it when more cuts are needed.", "控えめにシームを入れる場合は上げ、カットを増やす場合は下げます。"),
    ("suv_consolidated_snap_vertex_distance", "Distance", "距離", "Maximum UV distance used to group vertices for Vertex snap.", "頂点吸着で同一グループとみなす最大UV距離です。", "Set this slightly larger than the gap you want to collapse, then press Vertex.", "潰したい隙間より少し大きく設定してから「頂点」を押します。"),
    ("uv_chain_axis_mode", "Axis Basis", "軸基準", "Chooses the axis reference used by chain, flow, and alignment helpers.", "チェーン、フロー、整列補助で使う軸基準を選びます。", "Use UV basis for layout edits and world/object basis when matching model orientation.", "レイアウト編集ではUV基準、モデル方向へ合わせる場合はワールドまたはオブジェクト基準を使います。"),
    ("uv_chain_group_mode", "Scope", "対象範囲", "Defines whether chain and alignment helpers operate on the selection, island, or related group.", "チェーンや整列補助が、選択範囲、アイランド、関連グループのどれを処理するかを指定します。", "Set the scope before running line, flow, or alignment commands.", "ライン、フロー、整列コマンドの実行前に対象範囲を設定します。"),
    ("uv_flow_strength", "Flow", "フロー", "Controls how strongly Set Flow moves selected UVs toward the detected flow.", "フロー設定が選択UVを検出フローへ寄せる強さを制御します。", "Use lower values for subtle correction and higher values for stronger reshaping.", "軽い補正は低く、強く整える場合は高くします。"),
    ("smart_relax_iterations", "Relax", "リラックス回数", "Number of relax iterations used by relax commands.", "リラックス系コマンドで使う反復回数です。", "Increase for stronger smoothing, but avoid excessive values on heavy meshes.", "より滑らかにしたい場合は増やしますが、重いメッシュでは過剰値を避けます。"),
    ("unified_auto_pack_mode", "Packing Preset", "パッキングプリセット", "Chooses the packing algorithm route used by Run Auto Pack.", "自動パック実行で使うパッキングアルゴリズムの経路を選びます。", "Select the method that matches the asset goal before running Auto Pack.", "自動パック前に、アセットの目的に合う方式を選びます。"),
    ("unified_pack_merge_overlap", "Treat Overlaps as One Island", "重なり島を複合島にする", "Treats UV islands that overlap by visible area as one compound unit for Auto Pack.", "UVエディター上で面積が重なる島を、自動パック時に1つの複合単位として扱います。", "Enable it for stacked/overlapping UVs; disable it when every island should be laid out separately.", "重なりを保つ場合はON、重なっていても個別に並べる場合はOFFにします。"),
    ("unified_pack_margin_px", "Margin px", "余白px", "Pixel margin used by Smart UV exact-margin packing.", "Smart UVの正確な余白パックで使うピクセル余白です。", "Set this to the bleed or padding requirement of the target texture.", "目標テクスチャのブリードまたは余白要件に合わせます。"),
    ("unified_pack_margin", "Native Margin", "標準余白", "Normalized margin value used by Blender-native packing paths.", "Blender標準パック経路で使う正規化余白値です。", "Use when the selected method forwards to Blender's native packer.", "選択方式がBlender標準パッカーへ渡る場合に使います。"),
    ("unified_pack_margin_method", "Margin Method", "余白方式", "Chooses how pack margin is interpreted by the packing route.", "パッキング経路が余白をどの基準で解釈するかを選びます。", "Use pixel-based margin for texture-safe output and native margin for Blender-compatible behavior.", "テクスチャ安全性を重視する場合はピクセル基準、Blender互換を重視する場合は標準余白を使います。"),
    ("unified_pack_shape_method", "Shape Method", "形状方式", "Chooses how island shapes are approximated during packing.", "パッキング時にアイランド形状をどのように近似するかを選びます。", "Use accurate shape methods for final packing and simpler methods for speed.", "最終パックでは高精度、速度重視では単純な方式を使います。"),
    ("unified_pack_rotation_step", "Rotation Step", "回転刻み", "Sets allowed rotation increments for packing candidates.", "パッキング候補で許可する回転角度の刻みを設定します。", "Use smaller steps for denser packing and larger steps for predictable orientation.", "密度重視では小さく、向きの予測しやすさ重視では大きくします。"),
    ("unified_pack_rotate", "Allow Rotation", "回転を許可", "Allows the packer to rotate islands.", "パッカーがアイランドを回転することを許可します。", "Enable for better space usage; disable when orientation must stay fixed.", "面積効率を上げたい場合は有効、向きを固定したい場合は無効にします。"),
    ("unified_pack_scale", "Allow Scale", "スケールを許可", "Allows the packer to scale islands during packing.", "パック時にアイランドのスケール変更を許可します。", "Disable it when texel density must remain unchanged.", "テクセル密度を変えたくない場合は無効にします。"),
    ("unified_pack_lock_pinned", "Lock Pinned", "ピン固定", "Keeps pinned UVs fixed during packing when supported.", "対応している場合、ピン留めUVを固定してパッキングします。", "Enable when pinned layout anchors must not move.", "固定したいレイアウト基準点がある場合に有効にします。"),
    ("unified_pack_use_seed", "Seed Search", "Seed探索", "Enables seed-based search for alternative packing results.", "別配置候補を探すためのSeed探索を有効にします。", "Enable when searching for a denser or more stable arrangement.", "より高密度または安定した配置を探す場合に有効にします。"),
    ("unified_pack_seed", "Seed", "Seed", "Seed value used by search-based packing.", "探索型パッキングで使うSeed値です。", "Change it to try a different packing arrangement.", "別のパッキング結果を試したい場合に変更します。"),
    ("unified_pack_stack_identical", "Stack Identical", "同一島を重ねる", "Stacks identical or highly similar islands during packing when allowed.", "許可されている場合、同一または非常に類似したアイランドを重ねます。", "Enable for mirrored or repeated parts that can share texture space.", "ミラー部品や反復部品でテクスチャ領域を共有したい場合に有効にします。"),
    ("unified_pack_chart_rescale", "Chart Rescale", "チャート密度再正規化", "Rescales charts to normalize density during packing.", "パック中にチャートを再スケールして密度を正規化します。", "Enable when islands should share consistent texel density after pack.", "パック後にアイランド間のテクセル密度を揃えたい場合に有効にします。"),
    ("pack_group_mode", "Group Mode", "グループ方式", "Chooses how selected islands are grouped for packing.", "パッキング時に選択アイランドをどのようにグループ化するかを選びます。", "Use grouping when related islands must stay together.", "関連アイランドをまとめて配置したい場合に使います。"),
    ("pack_group_layout", "Group Layout", "グループ配置", "Chooses the layout rule used between packing groups.", "パッキンググループ同士の配置ルールを選びます。", "Set before packing when groups need rows, columns, or ordered placement.", "グループを行、列、順序付きで配置したい場合、パック前に設定します。"),
    ("similarity_area_tol", "Area Tolerance", "面積許容差", "Area tolerance used when detecting similar islands.", "類似アイランド検出で使う面積許容差です。", "Increase it when repeated islands differ slightly in area.", "反復アイランドの面積が少し違う場合は大きくします。"),
    ("similarity_aspect_tol", "Aspect Tolerance", "比率許容差", "Aspect-ratio tolerance used when detecting similar islands.", "類似アイランド検出で使う縦横比許容差です。", "Increase it when similar islands have small proportion differences.", "類似アイランドの比率が少し違う場合は大きくします。"),
    ("unified_pack_target_tile", "Target Tile", "配置タイル", "Chooses the target UV tile for packing.", "パッキング先のUVタイルを指定します。", "Set this before packing to place islands into a specific tile.", "特定タイルへ配置したい場合、パック前に指定します。"),
    ("unified_pack_tile_u", "Tile U", "タイルU", "U index of the target tile.", "対象タイルのUインデックスです。", "Set together with Tile V for manual tile placement.", "手動タイル配置ではタイルVと合わせて設定します。"),
    ("unified_pack_tile_v", "Tile V", "タイルV", "V index of the target tile.", "対象タイルのVインデックスです。", "Set together with Tile U for manual tile placement.", "手動タイル配置ではタイルUと合わせて設定します。"),
    ("unified_pack_tile_columns", "UDIM Columns", "UDIM列数", "Number of columns used when distributing across UDIM tiles.", "UDIMタイルへ分配するときの列数です。", "Set according to the UDIM layout expected by the target pipeline.", "出力先パイプラインのUDIM配置に合わせて設定します。"),
    ("unified_pack_tile_fill", "UDIM Fill", "UDIM埋め順", "Order used when filling UDIM tiles.", "UDIMタイルを埋める順番です。", "Choose row-major or column-like behavior according to the required tile order.", "必要なタイル順に合わせて行優先などを選びます。"),
    ("unified_pack_target_width", "Pack Width", "パック幅", "Width of the target packing area.", "パッキング対象領域の幅です。", "Use non-default values for custom atlas rectangles.", "カスタムアトラス矩形に配置する場合に変更します。"),
    ("unified_pack_target_height", "Pack Height", "パック高さ", "Height of the target packing area.", "パッキング対象領域の高さです。", "Use non-default values for custom atlas rectangles.", "カスタムアトラス矩形に配置する場合に変更します。"),
    ("unified_pack_bake_padding_px", "Bake Padding", "ベイク安全余白", "Additional pixel padding used for bake-safe layouts.", "ベイク安全性のために使う追加ピクセル余白です。", "Increase when texture bleeding or mipmap artifacts are likely.", "テクスチャにじみやミップマップの問題が出そうな場合に増やします。"),
    ("hotspot_keep_aspect", "Keep Aspect", "縦横比を保持", "Keeps island aspect ratio during hotspot or atlas fitting.", "ホットスポットまたはアトラスフィット時にアイランドの縦横比を保持します。", "Enable when texture proportions must not be distorted.", "テクスチャ比率を歪めたくない場合に有効にします。"),
    ("hotspot_sort", "Sort Rule", "ソート規則", "Sort rule used when assigning islands to hotspots or atlas cells.", "アイランドをホットスポットまたはアトラスセルへ割り当てるときのソート規則です。", "Choose area or shape-based sorting depending on the target atlas.", "対象アトラスに合わせ、面積や形状基準のソートを選びます。"),
    ("hotspot_fill_order", "Fill Order", "埋め順", "Order used when filling hotspot or atlas slots.", "ホットスポットまたはアトラススロットを埋める順序です。", "Set when a predictable assignment order is required.", "割り当て順を予測可能にしたい場合に設定します。"),
    ("workflow_density", "Target Density", "目標密度", "Target texel density used by density normalization and bake preparation.", "密度正規化とベイク準備で使う目標テクセル密度です。", "Set the project target density before using Normalize Density.", "密度正規化前にプロジェクト目標密度を設定します。"),
    ("suv_native_target_density", "Native Density", "統合密度", "Native-unified target density value used by compact bake and density commands.", "コンパクトなベイクおよび密度コマンドで使う統合目標密度です。", "Set this before using Density or Normalize in the Bake hub.", "ベイクハブの密度取得や正規化前に設定します。"),
    ("uv_new_name", "UV Name", "UV名", "Name used when creating or renaming UV maps.", "UVマップ作成またはリネーム時に使う名前です。", "Enter the desired UV map name before adding or renaming.", "追加またはリネーム前に希望するUVマップ名を入力します。"),
    ("suv_native_uv_name", "Native UV Name", "統合UV名", "UV map name used by native unified UV map tools.", "統合UVマップツールが使うUVマップ名です。", "Set before running native Add or related UV map operations.", "統合追加や関連UVマップ操作の前に設定します。"),
    ("stretch_threshold", "Stretch Limit", "歪み許容値", "Stretch threshold used by inspection and repair tools.", "検査と修復ツールで使う歪みしきい値です。", "Lower it to catch more distortion, raise it to reduce false positives.", "より多くの歪みを検出する場合は下げ、誤検出を減らす場合は上げます。"),
    ("scan_report_name", "Report Name", "レポート名", "Name used for generated scan or inspection reports.", "検査レポート生成時に使う名前です。", "Set a recognizable name before writing a report.", "レポート出力前に識別しやすい名前を設定します。"),
    ("smart_sliver_protection", "Sliver Protection", "細片保護", "Protects thin sliver faces from aggressive cleanup where possible.", "細長い面を過度な整理から可能な限り保護します。", "Enable when the asset has intentional thin UV strips.", "意図的な細いUV帯があるアセットでは有効にします。"),
    ("smart_lock_overlaps", "Preserve Overlap", "重なり保持", "Preserves intended overlapping UVs during repair or cleanup where possible.", "意図的なUV重なりを修復または整理時に可能な限り保持します。", "Enable for mirrored or stacked UV workflows.", "ミラーやスタックUVを使うワークフローで有効にします。"),
    ("operation_instant_select_enabled", "Enable Instant Select Drag Move", "即時選択ドラッグ移動", "Allows clicking another UV element and immediately dragging it in the same gesture.", "別のUVエレメントをクリックし、そのまま同じ操作でドラッグ移動できるようにします。", "Enable it, then click a vertex, edge, face, or island and drag without starting a separate move command.", "有効にしてから、頂点、辺、面、アイランドをクリックし、別の移動コマンドを開始せずそのままドラッグします。"),
    ("operation_axis_constraint_memory_enabled", "Remember Axis Constraint", "軸拘束の記憶", "Remembers the last axis constraint used for UV transform helpers.", "UV変形補助で最後に使った軸拘束を記憶します。", "Enable when repeating constrained moves along the same axis.", "同じ軸に沿った移動を繰り返す場合に有効にします。"),
    ("operation_uv_gizmo_grip_fix_enabled", "Enable UV Gizmo Grip Fix", "UVギズモつかみ補助", "Improves UV gizmo grabbing behavior so the gizmo is easier to start reliably.", "UVギズモのつかみ開始を補助し、安定して操作しやすくします。", "Enable if gizmo drag starts inconsistently in the UV editor.", "UVエディターでギズモドラッグ開始が不安定な場合に有効にします。"),
    ("operation_uv_crossing_select_edges_enabled", "Crossing Selection: Edges", "交差選択：辺", "Includes UV edges that cross a box, circle, or lasso selection boundary even when both endpoints are outside.", "ボックス・円・投げ縄の選択領域を横切るUV辺を、両端点が領域外でも選択対象に含めます。", "Enable it, use UV edge mode, and run a crossing selection gesture.", "有効にしてUV辺選択モードで交差選択ジェスチャーを実行します。"),
    ("operation_uv_crossing_select_faces_enabled", "Crossing Selection: Faces", "交差選択：面", "Includes UV face polygons that overlap, cross, contain, or are contained by the selection region.", "選択領域と交差、重なり、包含関係になるUV面ポリゴンを選択対象に含めます。", "Enable it, use UV face mode, and run a crossing selection gesture.", "有効にしてUV面選択モードで交差選択ジェスチャーを実行します。"),
    ("operation_uv_proportional_cursor_keymap_enabled", "UV Proportional Cursor Entry", "UVプロポーショナル編集カーソル入力", "Registers the Smart UV Suite entry for proportional-editing influence-size cursor adjustment.", "UVプロポーショナル編集の影響範囲サイズを調整するSmart UV Suite入力経路を登録します。", "Enable it and adjust the proportional radius from the UV Editor.", "有効にしてUVエディターからプロポーショナル編集の影響半径を調整します。"),
):
    _setting(_prop, _title_en, _title_ja, _function_en, _function_ja, _usage_en, _usage_ja)


def _format_detail(d: Detail, context=None) -> str:
    title = _pick(d.title_en, d.title_ja, context)
    function = _pick(d.function_en, d.function_ja, context)
    usage = _pick(d.usage_en, d.usage_ja, context)
    if _is_ja(context):
        return f"{title}。機能: {function} 使い方: {usage}"
    return f"{title}. Function: {function} How to use: {usage}"


def _generic_operator_detail(op_id: str, label: str, properties: Any, context=None) -> Detail:
    label = str(label or op_id or "Operator")
    parts = []
    for name in _INTERESTING_PROPS:
        value = _read_prop(properties, name, "")
        if value:
            parts.append(f"{name}={value}")
    prop_note = ", ".join(parts)
    title_en = label
    title_ja = label
    if prop_note:
        function_en = f"Runs this Smart UV Suite command with {prop_note}."
        function_ja = f"このSmart UV Suiteコマンドを {prop_note} の設定で実行します。"
    else:
        function_en = "Runs this Smart UV Suite command for the current selection and context."
        function_ja = "現在の選択とコンテキストに対して、このSmart UV Suiteコマンドを実行します。"
    usage_en = "Check the current selection, active UV map, and visible settings, then press the button."
    usage_ja = "現在の選択、アクティブUVマップ、表示中の設定を確認してからボタンを押します。"
    return _detail(title_en, title_ja, function_en, function_ja, usage_en, usage_ja)


def _operator_rna_type(op_id: str):
    if bpy is None:
        return None
    try:
        namespace, name = str(op_id or '').split('.', 1)
        op = getattr(getattr(bpy.ops, namespace), name)
        return op.get_rna_type()
    except Exception:
        return None


def _localized_name(text: str, context=None) -> str:
    try:
        from . import text_translation as _text_translation  # type: ignore
        return str(_text_translation.sanitize_text(str(text or ''), context=context) or text or '')
    except Exception:
        return str(text or '')


def _localized_desc(text: str, label: str = '', context=None) -> str:
    try:
        from . import text_translation as _text_translation  # type: ignore
        return str(_text_translation.localized_description_text(str(text or ''), str(label or ''), context=context) or text or '')
    except Exception:
        return str(text or '')


def _enum_detail_from_registered_rna(op_id: str, prop: str, value: str, label: str = '', context=None) -> Detail | None:
    prop = str(prop or '')
    value = str(value or '')
    if not prop or not value:
        return None
    rna = _operator_rna_type(op_id)
    if rna is None:
        return None
    try:
        rna_prop = rna.properties.get(prop)
        enum_items = getattr(rna_prop, 'enum_items', None) if rna_prop is not None else None
    except Exception:
        enum_items = None
    if enum_items is None:
        return None
    item = None
    try:
        item = enum_items.get(value)
    except Exception:
        item = None
    if item is None:
        try:
            for candidate in enum_items:
                if str(getattr(candidate, 'identifier', '') or '') == value:
                    item = candidate
                    break
        except Exception:
            item = None
    if item is None:
        return None
    raw_title = str(getattr(item, 'name', '') or label or value)
    raw_desc = str(getattr(item, 'description', '') or '')
    title = _localized_name(raw_title, context)
    desc = _localized_desc(raw_desc, raw_title, context).strip() if raw_desc else ''
    if not desc:
        return None
    usage_en = f'Prepare the required mesh, UV selection, active UV map, and related settings, then run the button assigned to {prop}={value}. Only this individual function is executed.'
    usage_ja = f'必要なメッシュ、UV選択、アクティブUVマップ、関連設定を準備し、{prop}={value} が割り当てられたボタンを実行します。この個別機能だけが実行されます。'
    return _detail(title, title, desc, desc, usage_en, usage_ja)


def detail_for_operator(op_id: str, properties: Any = None, context=None, label: str = "") -> Detail:
    op_id = str(op_id or "")
    for prop in _INTERESTING_PROPS:
        value = _read_prop(properties, prop, "")
        if value:
            hit = _DETAILS.get((op_id, prop, _norm(value)))
            if hit is not None:
                return hit
            enum_hit = _enum_detail_from_registered_rna(op_id, prop, value, label, context)
            if enum_hit is not None:
                return enum_hit
    hit = _STATIC_DETAILS.get(op_id)
    if hit is not None:
        return hit
    return _generic_operator_detail(op_id, label, properties, context)


def describe_operator_properties(op_id: str, label: str = "", properties: Any = None, context=None) -> str:
    return _format_detail(detail_for_operator(op_id, properties, context, label), context)


def detail_for_setting(prop: str, label_en: str = "", label_ja: str = "", context=None) -> Detail:
    prop = str(prop or "")
    hit = _SETTING_DETAILS.get(prop)
    if hit is not None:
        return hit
    title_en = label_en or prop
    title_ja = label_ja or label_en or prop
    return _detail(
        title_en,
        title_ja,
        f"Changes the {title_en} setting used by the tools in this item.",
        f"この項目内のツールが使用する「{title_ja}」設定を変更します。",
        "Adjust the value before running the related button so the operation uses the intended setting.",
        "関連ボタンを実行する前に値を調整し、意図した設定で処理されるようにします。",
    )


def _make_description(op_id: str, label: str):
    @classmethod
    def _description(cls, context, properties):  # noqa: ANN001 - Blender callback signature.
        try:
            return describe_operator_properties(op_id, label or getattr(cls, "bl_label", ""), properties, context)
        except Exception:
            base = str(getattr(cls, "bl_description", "") or getattr(cls, "bl_label", "") or op_id)
            return base
    return _description


def _class_has_interesting_property(cls: type) -> bool:
    try:
        annotations = getattr(cls, "__annotations__", {}) or {}
        for name in _INTERESTING_PROPS:
            if name in annotations:
                return True
    except Exception:
        pass
    return False


def _iter_operator_classes(namespace: dict[str, Any] | None = None):
    seen: set[int] = set()
    package = "smart_uv_suite"
    if namespace:
        try:
            package = str(namespace.get("__name__", package)).split(".")[0]
        except Exception:
            package = "smart_uv_suite"
    sources: list[Any] = []
    if namespace:
        sources.append(namespace)
    try:
        for mod_name, mod in ():
            if not mod_name or mod is None:
                continue
            if mod_name == package or mod_name.startswith(package + "."):
                sources.append(getattr(mod, "__dict__", {}))
    except Exception:
        pass
    for source in sources:
        try:
            values = source.values() if isinstance(source, dict) else vars(source).values()
        except Exception:
            continue
        for obj in values:
            try:
                if not isinstance(obj, type):
                    continue
                obj_id = id(obj)
                if obj_id in seen or obj_id in _SCANNED_CLASS_IDS:
                    continue
                seen.add(obj_id)
                _SCANNED_CLASS_IDS.add(obj_id)
                op_id = str(getattr(obj, "bl_idname", "") or "")
                if not op_id or op_id == "smart_uv_suite.show_help":
                    continue
                if bpy is not None:
                    try:
                        if not issubclass(obj, bpy.types.Operator):
                            continue
                    except Exception:
                        pass
                yield obj, op_id
            except Exception:
                continue


def install(namespace: dict[str, Any] | None = None, context=None) -> int:
    """Install dynamic descriptions on registered Smart UV Suite operators."""
    global _INSTALLED
    count = 0
    for cls, op_id in _iter_operator_classes(namespace):
        try:
            needs_dynamic = (
                op_id in _STATIC_DETAILS
                or any(key[0] == op_id for key in _DETAILS)
                or _class_has_interesting_property(cls)
            )
            if not needs_dynamic:
                continue
            label = str(getattr(cls, "bl_label", "") or op_id)
            if cls not in _PATCHED_CLASSES:
                _PATCHED_CLASSES[cls] = getattr(cls, "description", None)
            setattr(cls, "description", _make_description(op_id, label))
            try:
                if op_id in _STATIC_DETAILS:
                    setattr(cls, "bl_description", _format_detail(_STATIC_DETAILS[op_id], context))
            except Exception:
                pass
            count += 1
        except Exception:
            continue
    _INSTALLED = True
    return count


def uninstall() -> None:
    for cls, original in list(_PATCHED_CLASSES.items()):
        try:
            if original is None:
                try:
                    delattr(cls, "description")
                except Exception:
                    pass
            else:
                setattr(cls, "description", original)
        except Exception:
            pass
    _PATCHED_CLASSES.clear()
    _SCANNED_CLASS_IDS.clear()


def _op(op_id: str, label_en: str, label_ja: str, prop: str = "", value: str = "") -> dict[str, Any]:
    return {"type": "operator", "op_id": op_id, "label_en": label_en, "label_ja": label_ja, "prop": prop or "", "value": value or ""}


def _set(prop: str, label_en: str, label_ja: str) -> dict[str, Any]:
    return {"type": "setting", "prop": prop, "label_en": label_en, "label_ja": label_ja}


def _note(title_en: str, title_ja: str, function_en: str, function_ja: str, usage_en: str, usage_ja: str) -> dict[str, Any]:
    return {"type": "note", "detail": _detail(title_en, title_ja, function_en, function_ja, usage_en, usage_ja)}


# Help-group entries mirror active UI items.  Groups are intentionally scoped to
# the help_id used by each section header so a popup does not describe unrelated
# panels.
_DIR_ENTRIES = [
    _op("smart_uv_suite.direction_align_mode", "Vertex", "頂点", "target", "VERTEX"),
    _op("smart_uv_suite.direction_align_mode", "Island", "アイランド", "target", "ISLAND"),
]
for _value, _en, _ja in (
    ("ALIGN_TL", "Align Top Left", "左上へ整列"), ("ALIGN_TOP", "Align Top", "上へ整列"), ("ALIGN_TR", "Align Top Right", "右上へ整列"),
    ("ALIGN_LEFT", "Align Left", "左へ整列"), ("ALIGN_CENTER", "Align Center", "中央へ整列"), ("ALIGN_RIGHT", "Align Right", "右へ整列"),
    ("ALIGN_BL", "Align Bottom Left", "左下へ整列"), ("ALIGN_BOTTOM", "Align Bottom", "下へ整列"), ("ALIGN_BR", "Align Bottom Right", "右下へ整列"),
    ("ALIGN_H", "Horizontal Center", "横中央"), ("ALIGN_V", "Vertical Center", "縦中央"),
    ("ALIGN_H_GROUP", "Horizontal Center by Group", "横中央 グループ"), ("ALIGN_V_GROUP", "Vertical Center by Group", "縦中央 グループ"),
    ("DISTRIBUTE_H", "Distribute Horizontally", "横均等"), ("DISTRIBUTE_V", "Distribute Vertically", "縦均等"),
    ("DISTRIBUTE_H_GROUP", "Distribute Groups Horizontally", "横均等 グループ"), ("DISTRIBUTE_V_GROUP", "Distribute Groups Vertically", "縦均等 グループ"),
    ("FLIP_H", "Flip Horizontal", "左右反転"), ("FLIP_V", "Flip Vertical", "上下反転"),
    ("ROTATE_CCW", "Rotate 90° Counterclockwise", "90°左回転"), ("ROTATE_CW", "Rotate 90° Clockwise", "90°右回転"),
):
    _DIR_ENTRIES.append(_op("smart_uv_suite.direction_align", _en, _ja, "action", _value))

_HELP_GROUPS.update({
    "basic_map_channels": [
        _op("smart_uv_suite.map_channel_object_select", "Object Row", "オブジェクト行"),
        _op("smart_uv_suite.map_channel_toggle_unify_check", "Unify Check", "統一チェック"),
        _op("smart_uv_suite.map_channel_unify_checked", "Unify Checked", "チェック対象を統一"),
        _set("unwrap_map_channel", "Unwrap Map Channel", "展開使用マップチャンネル"),
        _set("map_channel_new_name", "New Map Name", "新規マップ名"),
        _op("smart_uv_suite.map_channel_add", "Add", "追加"),
        _op("smart_uv_suite.map_channel_remove", "Remove Target", "展開対象を削除"),
        _op("smart_uv_suite.map_channel_move", "Move Up", "上へ移動", "direction", "-1"),
        _op("smart_uv_suite.map_channel_move", "Move Down", "下へ移動", "direction", "1"),
        _set("map_channel_copy_source", "Copy Source", "コピー元"),
        _op("smart_uv_suite.map_channel_copy", "Copy UV Layout to Unwrap Map Channel", "UV展開情報を展開使用マップチャンネルへコピー"),
    ],
    "basic_canvas_grid": [
        _set("show_grid_over_image", "Grid Over Image", "画像上にグリッド"), _set("grid_shape_source", "Grid Source", "グリッド基準"),
        _set("tile_grid_shape", "Tile Grid", "タイルグリッド"), _set("custom_grid_subdivisions", "Grid Subdivisions", "グリッド分割"),
        _set("show_pixel_coords", "Pixel Coordinates", "ピクセル座標"), _op("smart_uv_suite.export_uv_layout", "Export UV Layout", "UV配置の書き出し"),
    ],
    "basic_uv_display": [
        _set("show_uv", "Display UVs", "UVを表示"), _set("show_faces", "Display Faces", "面を表示"),
        _set("edge_display_type", "Edge Display", "エッジ表示"), _set("show_modified_edges", "Modified Edges", "変更後エッジ"),
        _set("show_stretch", "Stretch Display", "歪み表示"), _set("display_stretch_type", "Stretch Type", "歪み種類"),
        _set("uv_opacity", "UV Opacity", "UV不透明度"), _set("uv_face_opacity", "Face Opacity", "面不透明度"),
        _set("uv_edge_opacity", "Edge Opacity", "エッジ不透明度"), _set("stretch_opacity", "Stretch Opacity", "歪み不透明度"),
        _set("pixel_round_mode", "Pixel Rounding", "ピクセル丸め"), _set("lock_bounds", "Lock Bounds", "画像範囲固定"),
        _set("show_repeat", "Repeat Image", "画像を反復表示"),
    ],
    "basic_preview_checker": [
        _set("checker_size_width", "Image Resolution Width", "画像解像度 横"), _set("checker_size_height", "Image Resolution Height", "画像解像度 縦"),
        _set("checker_tile_count_u", "Checker Tiles U", "チェックサイズ 横"), _set("checker_tile_count_v", "Checker Tiles V", "チェックサイズ 縦"),
        _set("checker_color_a", "Checker Color 1", "チェックカラー1"), _set("checker_color_b", "Checker Color 2", "チェックカラー2"),
        _set("checker_image_name", "Image Name", "画像名"), _set("checker_material_name", "Material Name", "マテリアル名"),
        _op("smart_uv_suite.checker_create", "Create Checker", "チェッカー作成"), _op("smart_uv_suite.checker_delete", "Delete Checker", "チェッカー削除"),
        _op("smart_uv_suite.checker_material_toggle", "Apply to Materials", "マテリアルに反映"),
    ],
    "native_unwrap_hub": [
        _set("auto_unwrap_mode", "Method", "方式"), _set("smart_unwrap_realtime_preview", "Live Unwrap", "ライブ展開"),
        _op("smart_uv_suite.unwrap_auto_run", "Run Unwrap", "展開実行"),
        _op("smart_uv_suite.native_unwrap_action", "Smart Unwrap", "スマート展開", "action", "SMART_UNWRAP"),
        _op("smart_uv_suite.native_unwrap_action", "Auto Unwrap", "自動展開", "action", "AUTO_UNWRAP"),
        _op("smart_uv_suite.native_unwrap_action", "World Planar", "ワールド平面投影", "action", "PROJECT_WORLD"),
        _op("smart_uv_suite.native_unwrap_action", "Box Project", "ボックス投影", "action", "PROJECT_BOX"),
        _op("smart_uv_suite.native_unwrap_action", "Cylinder Project", "円柱投影", "action", "PROJECT_CYLINDER"),
        _op("smart_uv_suite.native_unwrap_action", "Sphere Project", "球投影", "action", "PROJECT_SPHERE"),
        _op("smart_uv_suite.native_unwrap_action", "View Project", "ビュー投影", "action", "PROJECT_VIEW"),
    ],
    "native_unwrap_quick": [
        _op("smart_uv_suite.native_seam_action", "Mark Seam", "シームをマーク", "action", "MARK_SEAM"),
        _op("smart_uv_suite.native_seam_action", "Clear Seam", "シームをクリア", "action", "CLEAR_SEAM"),
        _op("smart_uv_suite.native_seam_action", "Seams from Islands", "島からシーム", "action", "SEAMS_FROM_ISLANDS"),
        _set("suv_crease_seam_value", "Crease Value", "クリース値"), _set("suv_crease_seam_tolerance", "Tolerance", "許容差"),
        _set("suv_crease_seam_apply_mode", "Apply Mode", "適用方式"), _op("smart_uv_suite.native_seam_action", "Mark Crease Value", "クリース値でシーム化", "action", "CREASE_VALUE"),
        _op("smart_uv_suite.native_seam_action", "Pin", "ピン", "action", "PIN"), _op("smart_uv_suite.native_seam_action", "Unpin", "ピン解除", "action", "UNPIN"),
        _op("smart_uv_suite.native_seam_action", "Invert Pins", "ピン反転", "action", "PIN_INVERT"),
        _set("suv_seam_mark_compliance", "Use Mark Seam Before Unwrap", "展開前シーム準拠"), _set("seam_snapshot_name", "Scene Save Name", "シーン内保存名"),
        _set("seam_snapshot_filepath", "External JSON", "外部JSON"), _op("smart_uv_suite.seam_snapshot_action", "Save Scene", "シーン保存", "action", "SAVE_SCENE"),
        _op("smart_uv_suite.seam_snapshot_action", "Load Scene", "シーン読込", "action", "LOAD_SCENE"), _op("smart_uv_suite.seam_snapshot_action", "Save JSON", "外部保存", "action", "SAVE_FILE"),
        _op("smart_uv_suite.seam_snapshot_action", "Load JSON", "外部読込", "action", "LOAD_FILE"),
        _set("suv_auto_seam_profile", "Preset", "プリセット"), _set("suv_auto_seam_angle_threshold", "Angle Limit", "角度しきい値"),
        _set("suv_auto_seam_min_score", "Score Threshold", "採用スコア"), _op("smart_uv_suite.native_seam_action", "Auto Seam", "自動シーム", "action", "AUTO_SEAM"),
    ],
    "uv_direction_align_unified_pad": _DIR_ENTRIES,
    "align_selection": [
        _op("smart_uv_suite.uv_element_select_action", "Grow", "拡大", "action", "GROW"), _op("smart_uv_suite.uv_element_select_action", "Shrink", "縮小", "action", "SHRINK"),
        _op("smart_uv_suite.uv_element_select_action", "Loop", "ループ", "action", "LOOP"), _op("smart_uv_suite.uv_element_select_action", "Ring", "リング", "action", "RING"),
        _op("smart_uv_suite.uv_element_select_action", "Linked", "リンク", "action", "LINKED"), _op("smart_uv_suite.uv_element_select_action", "Border", "境界", "action", "BORDER"),
    ],
    "uv_vertex_line_flow": [
        _op("smart_uv_suite.align_edges", "Align Edge", "辺を整列"), _op("smart_uv_suite.inspect_orient_world", "World Align", "ワールド軸整列"),
        _op("smart_uv_suite.vertex_straighten_selected", "Straighten", "直線化"), _op("smart_uv_suite.vertex_even_straighten_selected", "Even Straighten", "均等直線化"),
        _op("smart_uv_suite.seam_rectify", "Rectify", "矩形補正"), _op("smart_uv_suite.align_uv_circle", "Circularize", "円形化"),
        _op("smart_uv_suite.align_normalize", "Normalize", "正規化"), _op("smart_uv_suite.align_relax", "Relax", "リラックス"), _set("smart_relax_iterations", "Relax Iterations", "リラックス反復"),
        _op("smart_uv_suite.vertex_set_flow_selected", "Set Flow", "フロー設定"), _set("uv_flow_strength", "Flow Strength", "フロー強度"),
    ],
    "bake_prepare": [_set("canvas_size", "Texture Size", "テクスチャサイズ"), _set("fit_padding_px", "Bake Padding", "ベイク余白"), _set("workflow_density", "Target Density", "目標密度"), _set("smart_margin_strategy", "Margin Strategy", "余白方針"), _op("smart_uv_suite.texel_bake_uv_prep", "Prepare Bake UV", "ベイクUV準備"), _op("smart_uv_suite.texel_stage_bake", "Create Bake Image", "ベイク画像作成"), _op("smart_uv_suite.atlas_bake_multi", "Bake Atlas", "アトラスベイク"), _op("smart_uv_suite.atlas_build_mat_apply_multi", "Build Material", "マテリアル作成")],
    "bake_texel": [_op("smart_uv_suite.texel_density_coverage", "Coverage", "カバー率"), _op("smart_uv_suite.texel_calc_uv_area", "UV Area", "UV面積"), _op("smart_uv_suite.texel_density_from_texture", "Density from Texture", "テクスチャから密度")],
    "bake_maps": [_op("smart_uv_suite.texel_bake_trim_id_map", "Bake ID Map", "IDマップベイク"), _op("smart_uv_suite.view_stage_preview", "Preview Texture", "テクスチャ確認")],
    "id_uvmaps": [_set("uv_new_name", "New UV Name", "新規UV名"), _op("smart_uv_suite.texel_uvmap_set_active", "Set Work UV", "作業UVに設定")],
    "id_materials": [_op("smart_uv_suite.inspect_set_save", "Save Selection Set", "セット保存"), _op("smart_uv_suite.inspect_set_recall", "Recall Selection Set", "セット読込"), _op("smart_uv_suite.inspect_set_update", "Update Selection Set", "セット更新")],
    "cleanup_status": [_set("stretch_threshold", "Stretch Limit", "歪み許容値"), _set("scan_report_name", "Report Name", "レポート名"), _set("smart_lock_overlaps", "Preserve Overlap", "重なり保持"), _op("smart_uv_suite.inspect_workspace_validate", "Validate", "検証"), _op("smart_uv_suite.inspect_fix_all_issues", "Fix Issues", "問題修復"), _op("smart_uv_suite.inspect_inspector_select_all", "Select Issues", "問題を選択")],
    "cleanup_select": [_op("smart_uv_suite.select_fragmented_islands", "Shattered", "断片化"), _op("smart_uv_suite.inspect_unstack_overlapped", "Unstack Overlap", "重なり分離")],
    "cleanup_data": [_op("smart_uv_suite.inspect_quality_cleanup_generated_data", "Clean Generated Data", "生成データ整理"), _op("smart_uv_suite.inspect_clear_all_reports", "Clear Reports", "レポート削除")],
    "io_settings": [_op("smart_uv_suite.settings_save", "Save Settings", "設定書き出し"), _op("smart_uv_suite.settings_load", "Load Settings", "設定読み込み"), _op("smart_uv_suite.workflow_workspace_reset", "Reset Settings", "設定リセット")],
    "io_sets": [_op("smart_uv_suite.seams_save", "Save Seams", "シーム書き出し"), _op("smart_uv_suite.seams_load", "Load Seams", "シーム読み込み"), _op("smart_uv_suite.layout_save", "Save Layout", "配置書き出し"), _op("smart_uv_suite.layout_load", "Load Layout", "配置読み込み"), _op("smart_uv_suite.selection_save", "Save Selection", "選択書き出し"), _op("smart_uv_suite.selection_load", "Load Selection", "選択読み込み")],
    "io_reports": [_op("smart_uv_suite.workflow_open_diagnostics_text", "Open Diagnostics", "診断を開く"), _op("smart_uv_suite.diagnostics_save", "Save Diagnostics", "診断を保存"), _op("smart_uv_suite.inspect_inspector_write_report", "Write Inspection", "検査レポート")],
    "uv_vertex_mirror_ops": [_op("smart_uv_suite.seam_mirror_uv", "Mirror UV", "UVミラー"), _op("smart_uv_suite.seam_symmetry_snap", "Symmetry Snap", "対称スナップ")],
    "uv_vertex_combine_ops": [_op("smart_uv_suite.seam_stack_pro", "Smart Stack", "スマートスタック"), _op("smart_uv_suite.weld", "Weld", "ウェルド"), _op("smart_uv_suite.seam_merge", "Merge Vertices", "頂点マージ")],
    "uv_vertex_snap_ops": [_set("suv_consolidated_snap_vertex_distance", "Distance", "距離"), _op("smart_uv_suite.consolidated_snap_uv", "Grid", "グリッド", "mode", "GRID"), _op("smart_uv_suite.consolidated_snap_uv", "Pixel", "ピクセル", "mode", "PIXEL"), _op("smart_uv_suite.consolidated_snap_uv", "Vertex", "頂点", "mode", "VERTEX")],
    "native_align_hub": [_set("uv_chain_axis_mode", "Axis Basis", "軸基準"), _set("uv_chain_group_mode", "Scope", "対象範囲"), _set("uv_flow_strength", "Flow", "フロー"), _set("smart_relax_iterations", "Relax", "リラックス回数"), _op("smart_uv_suite.native_align_action", "Fit", "フィット", "action", "FIT"), _op("smart_uv_suite.native_align_action", "Straight", "直線化", "action", "STRAIGHTEN"), _op("smart_uv_suite.native_align_action", "Grid", "グリッド化", "action", "GRIDIFY"), _op("smart_uv_suite.native_align_action", "Relax", "リラックス", "action", "RELAX"), _op("smart_uv_suite.native_align_action", "Rotate", "回転", "action", "ROTATE_90"), _op("smart_uv_suite.native_align_action", "Flip U", "U反転", "action", "FLIP_U"), _op("smart_uv_suite.native_align_action", "Flip V", "V反転", "action", "FLIP_V"), _op("smart_uv_suite.native_align_action", "Snap", "吸着", "action", "SNAP_PIXEL")],
    "native_align_stitch": [_op("smart_uv_suite.native_align_action", "Stitch/Weld", "結合", "action", "STITCH_WELD"), _op("smart_uv_suite.native_seam_action", "Pin", "ピン", "action", "PIN"), _op("smart_uv_suite.native_seam_action", "Unpin", "ピン解除", "action", "UNPIN")],
    "native_auto_packing": [_set("unified_auto_pack_mode", "Packing Preset", "パッキングプリセット"), _set("unified_pack_margin_px", "Margin px", "余白px"), _set("unified_pack_margin", "Native Margin", "標準余白"), _set("unified_pack_margin_method", "Margin Method", "余白方式"), _set("unified_pack_shape_method", "Shape Method", "形状方式"), _set("unified_pack_rotation_step", "Rotation Step", "回転刻み"), _set("unified_pack_rotate", "Allow Rotation", "回転を許可"), _set("unified_pack_scale", "Allow Scale", "スケールを許可"), _set("unified_pack_lock_pinned", "Lock Pinned", "ピン固定"), _set("unified_pack_use_seed", "Seed Search", "Seed探索"), _set("unified_pack_seed", "Seed", "Seed"), _set("unified_pack_stack_identical", "Stack Identical", "同一島を重ねる"), _set("unified_pack_merge_overlap", "Treat Overlaps as One Island", "重なり島を複合島にする"), _set("unified_pack_chart_rescale", "Chart Rescale", "チャート密度再正規化"), _set("pack_group_mode", "Group Mode", "グループ方式"), _set("pack_group_layout", "Group Layout", "グループ配置"), _set("similarity_area_tol", "Area Tolerance", "面積許容差"), _set("similarity_aspect_tol", "Aspect Tolerance", "比率許容差"), _set("unified_pack_target_tile", "Target Tile", "配置タイル"), _set("unified_pack_tile_u", "Tile U", "タイルU"), _set("unified_pack_tile_v", "Tile V", "タイルV"), _set("unified_pack_tile_columns", "UDIM Columns", "UDIM列数"), _set("unified_pack_tile_fill", "UDIM Fill", "UDIM埋め順"), _set("unified_pack_target_width", "Pack Width", "パック幅"), _set("unified_pack_target_height", "Pack Height", "パック高さ"), _set("unified_pack_bake_padding_px", "Bake Padding", "ベイク安全余白"), _set("hotspot_keep_aspect", "Keep Aspect", "縦横比を保持"), _set("hotspot_sort", "Sort Rule", "ソート規則"), _set("hotspot_fill_order", "Fill Order", "埋め順"), _op("smart_uv_suite.unified_auto_pack", "Run Auto Pack", "自動パック実行")],
    "native_bake_hub": [_set("canvas_size", "Texture Size", "テクスチャサイズ"), _set("fit_padding_px", "Padding", "余白"), _set("workflow_density", "Target Density", "目標密度"), _set("suv_native_target_density", "Native Density", "統合密度"), _op("smart_uv_suite.native_bake_action", "Bake Prep", "ベイク準備", "action", "BAKE_PREP"), _op("smart_uv_suite.native_bake_action", "Density", "密度取得", "action", "DENSITY_GET"), _op("smart_uv_suite.native_bake_action", "Normalize", "密度正規化", "action", "DENSITY_NORMALIZE"), _op("smart_uv_suite.native_bake_action", "Checker", "チェッカー", "action", "CHECKER_CREATE"), _op("smart_uv_suite.native_bake_action", "Object IDs", "オブジェクトID", "action", "COLOR_ID_OBJECTS"), _op("smart_uv_suite.native_bake_action", "Face IDs", "面ID", "action", "COLOR_ID_FACES")],
    "native_id_hub": [_set("uv_new_name", "UV Name", "UV名"), _set("suv_native_uv_name", "Native UV Name", "統合UV名"), _op("smart_uv_suite.native_id_action", "Add", "追加", "action", "UVMAP_ADD"), _op("smart_uv_suite.native_id_action", "Duplicate", "複製", "action", "UVMAP_DUPLICATE"), _op("smart_uv_suite.native_id_action", "Remove", "削除", "action", "UVMAP_REMOVE"), _op("smart_uv_suite.native_id_action", "Transfer", "転送", "action", "UVMAP_TRANSFER"), _op("smart_uv_suite.native_id_action", "Copy UV", "UVコピー", "action", "UV_COPY"), _op("smart_uv_suite.native_id_action", "Paste UV", "UV貼付", "action", "UV_PASTE")],
    "native_cleanup_hub": [_set("stretch_threshold", "Stretch Limit", "歪み許容値"), _set("scan_report_name", "Report Name", "レポート名"), _set("smart_sliver_protection", "Sliver Protection", "細片保護"), _set("smart_lock_overlaps", "Preserve Overlap", "重なり保持"), _op("smart_uv_suite.native_cleanup_action", "Zero", "ゼロ", "action", "SELECT_ZERO"), _op("smart_uv_suite.native_cleanup_action", "Flipped", "反転", "action", "SELECT_FLIPPED"), _op("smart_uv_suite.native_cleanup_action", "Overlap", "重なり", "action", "SELECT_OVERLAP"), _op("smart_uv_suite.native_cleanup_action", "UDIM", "UDIM", "action", "SELECT_UDIM"), _op("smart_uv_suite.native_cleanup_action", "Auto Repair", "自動修復", "action", "AUTO_REPAIR"), _op("smart_uv_suite.native_cleanup_action", "Invert", "反転選択", "action", "SELECT_INVERT"), _op("smart_uv_suite.native_cleanup_action", "Clean Data", "データ整理", "action", "CLEAN_GENERATED")],
    "native_io_hub": [_op("smart_uv_suite.native_io_action", "Settings", "設定出力", "action", "EXPORT_SETTINGS"), _op("smart_uv_suite.native_io_action", "Report", "レポート", "action", "WRITE_REPORT"), _op("smart_uv_suite.native_io_action", "Clean", "整理", "action", "CLEAN_GENERATED")],
    "operation_immediate_select": [_set("operation_instant_select_enabled", "Enable Instant Select Drag Move", "即時選択ドラッグ移動")],
    "operation_axis_constraint_memory": [_set("operation_axis_constraint_memory_enabled", "Remember Axis Constraint", "軸拘束の記憶")],
    "operation_cursor_to_hover_vertex": [_op("smart_uv_suite.cursor_to_hover_uv_vertex", "2D Cursor to Hover Vertex", "ホバー頂点へ2Dカーソル"), _op("smart_uv_suite.copy_operator_id", "Copy ID", "IDコピー")],
    "operation_uv_gizmo_grip_fix": [_set("operation_uv_gizmo_grip_fix_enabled", "Enable UV Gizmo Grip Fix", "UVギズモつかみ補助")],
    "operation_uv_vertex_slide": [_op("smart_uv_suite.uv_vertex_slide", "Vertex Slide", "頂点スライド"), _op("transform.vert_slide", "Vertex Slide (Keymap)", "頂点スライド（キーマップ）"), _op("smart_uv_suite.copy_operator_id", "Copy ID", "IDコピー")],
    "operation_uv_editor_ownership": [_set("operation_uv_crossing_select_edges_enabled", "Crossing Selection: Edges", "交差選択：辺"), _set("operation_uv_crossing_select_faces_enabled", "Crossing Selection: Faces", "交差選択：面"), _set("operation_uv_proportional_cursor_keymap_enabled", "UV Proportional Cursor Entry", "UVプロポーショナル編集カーソル入力")],
})

_SECTION_ALIASES.update({
    "category_workflow": ("basic_map_channels", "basic_canvas_grid", "basic_uv_display", "basic_preview_checker", "native_id_hub", "native_cleanup_hub", "native_io_hub"),
    "category_unwrap": ("native_unwrap_hub", "native_unwrap_quick"),
    "category_align": ("align_selection", "uv_direction_align_unified_pad", "uv_vertex_line_flow", "uv_vertex_mirror_ops", "uv_vertex_combine_ops", "uv_vertex_snap_ops", "native_align_hub", "native_align_stitch"),
    "category_pack": ("native_auto_packing",),
    "category_texel": ("native_bake_hub",),
    "category_operation": ("operation_immediate_select", "operation_axis_constraint_memory", "operation_cursor_to_hover_vertex", "operation_uv_vertex_slide", "operation_uv_gizmo_grip_fix", "operation_uv_editor_ownership"),
    "native_basic_settings": ("basic_map_channels", "basic_canvas_grid", "basic_uv_display", "basic_preview_checker"),
    "native_unwrap_method_execute": ("native_unwrap_hub",),
    "native_unwrap_method_settings": ("native_unwrap_hub",),
    "native_seam_pin_ops": ("native_unwrap_quick",),
    "native_seam_pin_pin_ops": ("native_unwrap_quick",),
    "native_seam_pin_storage": ("native_unwrap_quick",),
    "native_seam_pin_advanced_settings": ("native_unwrap_quick",),
    "native_bake_settings": ("native_bake_hub",),
    "native_bake_density_ops": ("native_bake_hub",),
    "native_bake_checker_id_ops": ("native_bake_hub",),
    "native_id_channel_settings": ("native_id_hub",),
    "native_id_map_ops": ("native_id_hub",),
    "native_id_transfer_ops": ("native_id_hub",),
    "native_cleanup_scan_settings": ("native_cleanup_hub",),
    "native_cleanup_select_ops": ("native_cleanup_hub",),
    "native_cleanup_repair_ops": ("native_cleanup_hub",),
    "native_io_output_ops": ("native_io_hub",),
    "native_io_support_note": ("native_io_hub",),
    "manage_id": ("native_id_hub",),
    "manage_cleanup": ("native_cleanup_hub",),
    "manage_io": ("native_io_hub",),
    "keymap_info": ("keymap_info_entries",),
    "keymap_info_entries": ("operation_cursor_to_hover_vertex",),
})


def _entries_for_help(help_id: str) -> list[dict[str, Any]]:
    help_id = str(help_id or "")
    result: list[dict[str, Any]] = []
    groups = _SECTION_ALIASES.get(help_id, (help_id,))
    seen: set[tuple[str, str, str, str]] = set()
    for group in groups:
        for item in _HELP_GROUPS.get(group, []):
            key = (str(item.get("type", "")), str(item.get("op_id", item.get("prop", ""))), str(item.get("prop", "")), str(item.get("value", "")))
            if key in seen:
                continue
            seen.add(key)
            result.append(item)
    return result


def draw_help_details(layout, context, help_id: str, **helpers) -> bool:
    entries = _entries_for_help(help_id)
    if not entries:
        return False
    wrap = helpers.get("wrap")
    if not callable(wrap):
        return False
    try:
        box = layout.box()
    except Exception:
        box = layout
    wrap(box, _pick("Functions and settings in this item", "この項目内の機能と設定", context), context, icon="TOOL_SETTINGS")
    index = 0
    for item in entries:
        try:
            sub = box.box()
        except Exception:
            sub = box
        kind = str(item.get("type", ""))
        if kind == "operator":
            props = {}
            if item.get("prop") and item.get("value"):
                props[str(item.get("prop"))] = str(item.get("value"))
            detail = detail_for_operator(str(item.get("op_id", "")), props, context, _pick(str(item.get("label_en", "")), str(item.get("label_ja", "")), context))
        elif kind == "setting":
            detail = detail_for_setting(str(item.get("prop", "")), str(item.get("label_en", "")), str(item.get("label_ja", "")), context)
        elif kind == "note":
            detail = item.get("detail")
        else:
            continue
        if not isinstance(detail, Detail):
            continue
        index += 1
        title = _pick(detail.title_en, detail.title_ja, context)
        function = _pick(detail.function_en, detail.function_ja, context)
        usage = _pick(detail.usage_en, detail.usage_ja, context)
        wrap(sub, f"{index}. {title}", context, icon="DOT")
        wrap(sub, _pick("Function: ", "機能: ", context) + function, context)
        wrap(sub, _pick("How to use: ", "使い方: ", context) + usage, context)
    return True


__all__ = [
    "install",
    "uninstall",
    "describe_operator_properties",
    "detail_for_operator",
    "detail_for_setting",
    "draw_help_details",
]

# Additional selection and small action details are appended last so they remain
# available to dynamic tooltips and Help after all groups are built.
for _value, _title_en, _title_ja, _function_en, _function_ja, _usage_en, _usage_ja in (
    ("GROW", "Grow Selection", "選択拡大", "Expands the current UV selection to adjacent connected elements.", "現在のUV選択を隣接する接続要素へ拡大します。", "Select a starting UV element, then run Grow to include neighboring UVs.", "開始するUV要素を選択し、隣接UVを含めたいときに実行します。"),
    ("SHRINK", "Shrink Selection", "選択縮小", "Removes boundary elements from the current UV selection.", "現在のUV選択から境界側の要素を外します。", "Run after a broad selection when only the inner area should remain selected.", "広めに選択した後、内側だけを残したいときに使います。"),
    ("LOOP", "Loop Selection", "ループ選択", "Extends the UV selection along a continuous loop direction.", "UV選択を連続したループ方向へ拡張します。", "Select an edge or vertex in the loop, then run Loop.  UV Select Sync on and off are handled through the same UV selection path.", "ループ上の辺または頂点を選択して実行します。「UVの選択を同期」の有効時も無効時と同じUV選択経路で処理します。"),
    ("RING", "Ring Selection", "リング選択", "Extends the UV selection along a ring direction across adjacent quads.", "隣接四角形をまたぐリング方向へUV選択を拡張します。", "Select an edge in the ring, then run Ring.  The UV overlay selection is restored after synchronized selection updates.", "リング上の辺を選択して実行します。同期選択更新後もUVオーバーレイ選択を復元します。"),
    ("LINKED", "Linked Selection", "リンク選択", "Selects UV elements connected to the current UV selection.", "現在のUV選択に接続しているUV要素を選択します。", "Select one element inside the island or connected region, then run Linked.", "アイランドまたは接続領域内の要素を1つ選択して実行します。"),
    ("BORDER", "Border Selection", "境界選択", "Selects border elements around the current UV island or selected region.", "現在のUVアイランドまたは選択領域の境界要素を選択します。", "Use to isolate UV island outlines before seam, stitch, or inspection work.", "シーム、スティッチ、検査作業前にUVアイランド外周を取り出したいときに使います。"),
    ("ALL", "Select All", "全選択", "Selects all visible UV elements in the current context.", "現在のコンテキストで表示されているUV要素をすべて選択します。", "Use before operations that should affect the whole UV map or visible island set.", "UVマップ全体または表示アイランド全体に処理をかけたいときに使います。"),
    ("NONE", "Deselect All", "選択解除", "Clears the current UV selection.", "現在のUV選択を解除します。", "Use before making a new precise selection.", "新しく正確な選択を作り直す前に使います。"),
    ("INVERT", "Invert Selection", "選択反転", "Inverts the current UV selection.", "現在のUV選択を反転します。", "Use after selecting exclusions when the remaining UVs should become selected.", "除外したい部分を選択した後、残りを選択対象にしたいときに使います。"),
):
    _add("smart_uv_suite.uv_element_select_action", "action", _value, _title_en, _title_ja, _function_en, _function_ja, _usage_en, _usage_ja)

_add("smart_uv_suite.map_channel_move", "direction", "-1", "Move Map Channel Up", "マップチャンネルを上へ移動", "Moves the target UV map channel one slot upward in the object's UV map list.", "対象UVマップチャンネルをオブジェクトのUVマップ一覧で1つ上へ移動します。", "Use when the target channel should appear earlier in the UV map order.", "対象チャンネルをUVマップ順の前側に置きたい場合に使います。")
_add("smart_uv_suite.map_channel_move", "direction", "1", "Move Map Channel Down", "マップチャンネルを下へ移動", "Moves the target UV map channel one slot downward in the object's UV map list.", "対象UVマップチャンネルをオブジェクトのUVマップ一覧で1つ下へ移動します。", "Use when the target channel should appear later in the UV map order.", "対象チャンネルをUVマップ順の後ろ側に置きたい場合に使います。")
