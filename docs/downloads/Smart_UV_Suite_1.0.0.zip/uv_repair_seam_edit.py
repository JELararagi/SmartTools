import bmesh
from mathutils import Vector


def _copy_seams_to_layer(context, op):
    from .panel_tools import _warn

    obj = context.edit_object
    if obj is None or obj.type != 'MESH':
        return False
    name = op.name.strip() or 'SUV_Seams'
    mesh = obj.data
    bm = bmesh.from_edit_mesh(mesh)
    layer = bm.edges.layers.int.get(name)
    if layer is None:
        if (name.startswith('.') or len(name.encode('utf-8')) > 63
                or mesh.attributes.get(name) is not None):
            _warn(context, op, 'Choose an available name for the integer edge layer.',
                  '整数辺レイヤーに使用できる名前を指定してください。')
            return False
        layer = bm.edges.layers.int.new(name)
    for edge in bm.edges:
        edge[layer] = int(edge.seam)
    bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
    return True


def _mark_selected_face_boundaries(obj):
    from .flow import _suv_boundary_edges_for_faces

    mesh = obj.data
    bm = bmesh.from_edit_mesh(mesh)
    faces = [face for face in bm.faces if face.select and not face.hide]
    if not faces:
        return False
    uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
    for edge in _suv_boundary_edges_for_faces(bm, uv_layer, faces):
        edge.seam = True
    bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
    return True


def _split_uv_changes(bm, uv, sync, visible, offset):
    """Plan selected edge changes before touching either side of a shared edge."""
    bm.faces.index_update()
    active_face = bm.faces.active
    changes, anchors = {}, set()
    for edge in bm.edges:
        if edge.hide or not edge.is_manifold or (sync and not edge.select):
            continue
        sides = [loop for loop in edge.link_loops if visible(loop.face, sync)]
        if len(sides) != 2:
            continue
        selected = sides if sync else [loop for loop in sides if loop.uv_select_edge]
        if not selected:
            continue
        moving = min(selected, key=lambda loop: (loop.face != active_face, loop.face.index))
        fixed = sides[1] if sides[0] == moving else sides[0]
        fixed_by_vertex = {fixed.vert: fixed, fixed.link_loop_next.vert: fixed.link_loop_next}
        pairs = [(loop, fixed_by_vertex[loop.vert]) for loop in (moving, moving.link_loop_next)]
        separated = any((loop[uv].uv - anchor[uv].uv).length_squared > 1.0e-12 for loop, anchor in pairs)
        for loop, anchor in pairs:
            destination = anchor[uv].uv.copy() if separated else anchor[uv].uv + offset
            if loop in changes and (changes[loop] - destination).length_squared > 1.0e-12:
                return None
            changes[loop] = destination
            anchors.add(anchor)
    return changes if anchors.isdisjoint(changes) else None


def build_handlers(api):
    backend = api._run_uv_layout(
            'suv_uv_edit_compat_tools', mode='mode', scope='scope', offset_u='value', offset_v='amount'
        )

    def run(context, op):
        settings = context.tool_settings
        obj = context.edit_object
        if (op.mode == 'SEAMS_FROM_ISLANDS' and op.scope in {'', 'SELECTED'}
                and obj is not None and obj.type == 'MESH'
                and settings.use_uv_select_sync and settings.mesh_select_mode[2]):
            return _mark_selected_face_boundaries(obj)
        return backend(context, op)

    def split_uv_toggle(context, op):
        if context.mode != 'EDIT_MESH':
            return False
        sync = api._sync(context)
        settings = context.tool_settings
        if not (settings.mesh_select_mode[1] if sync else settings.uv_select_mode == 'EDGE'):
            return False
        amount = op.amount if op.properties.is_property_set('amount') else 1.0 / op.texture_size
        if amount <= 1.0e-6:
            return False
        offset = Vector((amount, 0.0))
        plans = []
        for row in api._edit_targets(context):
            _obj, bm, uv = row
            changes = _split_uv_changes(bm, uv, sync, api._visible, offset)
            if changes is None:
                return False
            if changes:
                plans.append((row, changes))
        for (_obj, _bm, uv), changes in plans:
            for loop, destination in changes.items():
                loop[uv].uv = destination
        api._flush(row for row, _changes in plans)
        return bool(plans)

    return {
        'smart_uv_suite.seam_stack': api.Handler(
            api._smart_stack,
            'Stack selected UV islands with the same shape.',
            '同じ形状の選択 UV アイランドを重ねます。'),
        'smart_uv_suite.seam_brush_compat': api.Handler(
            api._run_uv_layout('suv_uv_brush_compat', mode='mode', factor='amount', scope='scope'),
            'Apply the selected UV brush deformation.',
            '指定した UV ブラシ変形を適用します。'),
        'smart_uv_suite.seam_copy_diagnostics_text': api.Handler(
            api._run_uv_layout('suv_copy_diagnostics_text', target='mode'),
            'Copy the selected diagnostics report to the clipboard.',
            '指定した診断レポートをクリップボードにコピーします。'),
        'smart_uv_suite.seam_copy_to_layer': api.Handler(
            _copy_seams_to_layer,
            'Copy all seam flags from the active mesh to an integer edge layer (default: SUV_Seams).',
            'アクティブメッシュの全シームの印を整数辺レイヤー（既定: SUV_Seams）に保存します。'),
        'smart_uv_suite.seam_edit_tools': api.Handler(run, 'Run the selected UV edit tool, including seam creation from island borders.', 'アイランド境界からのシーム生成など、指定したUV編集ツールを実行します。'),
        'smart_uv_suite.seam_split_uv_toggle': api.Handler(
            split_uv_toggle,
            'Split the selected shared UV edges by a horizontal offset, or join them back to the opposite side.',
            '選択した共有UV辺を水平方向にずらして分割するか、反対側のUV辺に戻して結合します。'),
    }
