# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Capture UV snap targets and apply them to the subsequent selection."""

from math import fsum, isfinite


_TARGET_KEYS = {
    'point': '_smart_uv_suite_point_snap_target',
    'edge': '_smart_uv_suite_edge_snap_target',
}


def build_handlers(api):
    def store(context, op, kind, point):
        if not all(isfinite(value) for value in point):
            api._warn(context, op, 'The UV target has invalid coordinates.', 'UV ターゲットの座標が無効です。')
            return False
        context.scene[_TARGET_KEYS[kind]] = tuple(point)
        api._info(context, op, 'UV snap target set.', 'UV スナップのターゲットを設定しました。')
        return True

    def uv_editor_space(context):
        space = context.space_data
        if getattr(space, 'type', None) != 'IMAGE_EDITOR' or space.mode != 'UV':
            uv_editors = [area.spaces.active for area in context.screen.areas
                          if area.type == 'IMAGE_EDITOR' and area.spaces.active.mode == 'UV'] if context.screen else []
            return uv_editors[0] if len(uv_editors) == 1 else None
        return space

    def cursor_target(context, op):
        space = uv_editor_space(context)
        if space is None:
            api._warn(context, op, 'Open a UV Editor to use its cursor as a point target.',
                      'ポイントターゲットに使うカーソルがある UV エディターを開いてください。')
            return False
        return store(context, op, 'point', space.cursor_location)

    def set_uv_cursor(context, op):
        space = uv_editor_space(context)
        if space is None:
            api._warn(context, op, 'Open a UV Editor to set its cursor.',
                      'カーソルのある UV エディターを開いてください。')
            return False
        sync = api._sync(context)
        rows = api._edit_targets(context) if context.mode == 'EDIT_MESH' else []
        positions = [
            point for _obj, mesh, uv in rows
            for _, point in {
                (loop.vert, tuple(loop[uv].uv))
                for face in mesh.faces if api._visible(face, sync)
                for loop in face.loops if (loop.vert.select if sync else loop.uv_select_vert)
            }
        ]
        if not positions:
            api._warn(context, op, 'Select UV points to place the 2D cursor.',
                      '2D カーソルを配置するための UV 点を選んでください。')
            return False
        space.cursor_location = tuple(fsum(point[axis] for point in positions) / len(positions)
                                      for axis in range(2))
        return True

    def group_target(context, op):
        obj = context.active_object
        group = obj.vertex_groups.active if context.mode == 'EDIT_MESH' and obj else None
        if group is None:
            api._warn(context, op, 'Choose an active vertex group on the edit mesh.',
                      '編集メッシュでアクティブな頂点グループを選んでください。')
            return False
        samples = []
        for target, mesh, uv in api._edit_targets(context):
            if target != obj:
                continue
            layer = mesh.verts.layers.deform.active
            if layer is None:
                continue
            positions = {
                (loop.vert, tuple(loop[uv].uv))
                for face in mesh.faces if not face.hide for loop in face.loops
                if loop.vert[layer].get(group.index, 0.0) > 0.0
            }
            samples = [(position, vertex[layer][group.index]) for vertex, position in positions]
        weight = fsum(value for _, value in samples)
        if not weight:
            api._warn(context, op, 'The active vertex group has no UV points with a positive weight.',
                      'アクティブな頂点グループに正のウェイトを持つ UV 点がありません。')
            return False
        return store(context, op, 'point', tuple(
            fsum(position[axis] * value for position, value in samples) / weight for axis in range(2)
        ))

    def edge_target(context, op):
        rows = api._edit_targets(context) if context.mode == 'EDIT_MESH' else []
        edges = {
            tuple(sorted((tuple(loop[uv].uv), tuple(loop.link_loop_next[uv].uv))))
            for _obj, bm, uv in rows for loop in api._selected_edge_loops(context, bm)
        }
        if len(edges) != 1:
            api._warn(context, op, 'Select one UV edge to set its center as the edge target.',
                      '中央をターゲットにする UV 辺を 1 本選んでください。')
            return False
        first, second = next(iter(edges))
        return store(context, op, 'edge', tuple((a + b) * 0.5 for a, b in zip(first, second)))

    def apply_target(context, op, kind):
        point = context.scene.get(_TARGET_KEYS[kind])
        if point is None:
            api._warn(context, op, 'Set the corresponding UV snap target first.',
                      '先に対応する UV スナップのターゲットを設定してください。')
            return False
        sync = api._sync(context)
        rows = api._edit_targets(context) if context.mode == 'EDIT_MESH' else []
        changed = []
        for row in rows:
            _obj, mesh, uv = row
            loops = [
                loop for face in mesh.faces if api._visible(face, sync) for loop in face.loops
                if (loop.vert.select if sync else loop.uv_select_vert)
            ]
            if not loops:
                continue
            for loop in loops:
                loop[uv].uv = point
            changed.append(row)
        if not changed:
            api._warn(context, op, 'Select the UV points to snap.', 'スナップする UV 点を選んでください。')
            return False
        api._flush(changed)
        api._info(context, op, 'Selected UV points snapped to the target.',
                  '選択 UV 点をターゲットにスナップしました。')
        return True

    def snap_point(context, op):
        return apply_target(context, op, 'point')

    def snap_edge(context, op):
        return apply_target(context, op, 'edge')

    cursor_handler = api.Handler(
        set_uv_cursor, 'Move the 2D cursor to the center of the selected UV points.',
        '2D カーソルを選択した UV 点の中心に移動します。')
    return {
        'smart_uv_suite.view_set_cursor_2d': cursor_handler,
        'smart_uv_suite.align_uv_cursor': cursor_handler,
        'smart_uv_suite.align_snap_point_to_vgroup': api.Handler(
            group_target, 'Set the point target to the weighted UV center of the active vertex group.',
            'アクティブな頂点グループのウェイト付き UV 中心をポイントターゲットにします。'),
        'smart_uv_suite.align_uv_snap_set_edge_target_to_edge_center': api.Handler(
            edge_target, 'Set the edge target to the center of the selected UV edge.',
            '選択した UV 辺の中央をエッジターゲットにします。'),
        'smart_uv_suite.align_uv_snap_set_point_target_to_cursor': api.Handler(
            cursor_target, 'Set the point target to the UV Editor cursor.',
            'UV エディターのカーソルをポイントターゲットにします。'),
        'smart_uv_suite.align_uv_snap_to_edge': api.Handler(
            snap_edge, 'Move selected UV points to the stored UV edge center.',
            '選択 UV 点を保存した UV 辺の中央へ移動します。'),
        'smart_uv_suite.align_uv_snap_to_point': api.Handler(
            snap_point, 'Move selected UV points to the stored point target.',
            '選択 UV 点を保存したポイントターゲットへ移動します。'),
    }
