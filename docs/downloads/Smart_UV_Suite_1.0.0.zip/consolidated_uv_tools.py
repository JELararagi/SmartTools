# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Original consolidated UV tools for Smart UV Suite.

This module implements Smart UV Suite native operators that cover common UV
workflows represented by several reference add-ons.  It intentionally does not
import, wrap, copy, or relicense third-party add-on source code or assets.
"""

from __future__ import annotations
from . import resource_api_18168 as _suv_resource

import math
import traceback
from contextlib import contextmanager
from typing import Iterable, Sequence

import bpy
import bmesh
from mathutils import Vector

_REGISTERED = False
_TRANSLATIONS_REGISTERED = False
_SCENE_PROPS: tuple[str, ...] = (
    "suv_consolidated_last_density",
    "suv_consolidated_checker_size",
    "suv_consolidated_checker_name",
    "suv_consolidated_snap_grid",
    "suv_consolidated_snap_vertex_distance",
    "suv_consolidated_flatten_scale",
)


def _is_ja(context=None) -> bool:
    try:
        from . import text_translation as _text_translation
        return bool(_text_translation.is_japanese(context))
    except Exception:
        pass
    try:
        language = str(getattr(getattr(getattr(context or bpy.context, "preferences", None), "view", None), "language", "") or "").upper()
        locale = str(getattr(getattr(bpy.app, "translations", None), "locale", "") or "").upper()
        return "JA" in language or "JA" in locale or "JP" in language or "JP" in locale
    except Exception:
        return False


def _tr(context, en: str, ja: str) -> str:
    try:
        from . import text_translation as _text_translation
        return str(_text_translation.pick(str(en or ""), str(ja or ""), context=context))
    except Exception:
        return str(ja if _is_ja(context) else en)


def _report(operator, level: str, context, en: str, ja: str) -> None:
    try:
        operator.report({level}, _tr(context, en, ja))
    except Exception:
        pass


def _active_mesh(context):
    obj = getattr(context, "active_object", None)
    if obj is not None and getattr(obj, "type", "") == "MESH":
        return obj
    for obj in getattr(context, "selected_objects", ()) or ():
        if getattr(obj, "type", "") == "MESH":
            return obj
    return None


def _selected_meshes(context) -> list:
    result = []
    for obj in getattr(context, "selected_objects", ()) or ():
        if getattr(obj, "type", "") == "MESH":
            result.append(obj)
    obj = _active_mesh(context)
    if obj is not None and obj not in result:
        result.insert(0, obj)
    return result


@contextmanager
def _active_object_mode(context, obj, mode: str):
    previous_active = getattr(context.view_layer.objects, "active", None)
    previous_mode = getattr(obj, "mode", "OBJECT") if obj is not None else "OBJECT"
    try:
        try:
            context.view_layer.objects.active = obj
        except Exception:
            pass
        if obj is not None and getattr(obj, "mode", "OBJECT") != mode:
            try:
                bpy.ops.object.mode_set(mode=mode)
            except Exception:
                pass
        yield
    finally:
        try:
            if obj is not None and getattr(obj, "mode", "OBJECT") != previous_mode:
                bpy.ops.object.mode_set(mode=previous_mode)
        except Exception:
            pass
        try:
            context.view_layer.objects.active = previous_active
        except Exception:
            pass


def _ensure_uv_layer_object(mesh, name: str = "UVMap"):
    try:
        if len(mesh.uv_layers) == 0:
            return mesh.uv_layers.new(name=name or "UVMap")
        return mesh.uv_layers.active or mesh.uv_layers[0]
    except Exception:
        return None


def _bm_and_uv(context, obj):
    if obj is None or getattr(obj, "mode", "") != "EDIT":
        return None, None
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        return bm, uv_layer
    except Exception:
        return None, None


def _uv_sync_on(context) -> bool:
    return bool(getattr(context.tool_settings, "use_uv_select_sync", False))


def _loop_uv_selected(context, loop, uv_layer) -> bool:
    if _uv_sync_on(context):
        return bool(loop.vert.select or loop.face.select)
    return bool(loop.face.select and (loop.uv_select_vert or loop.uv_select_edge))


def _selected_uv_loops(context, bm, uv_layer) -> list:
    loops = []
    for face in bm.faces:
        for loop in face.loops:
            if _loop_uv_selected(context, loop, uv_layer):
                loops.append(loop)
    if loops:
        return loops
    for face in bm.faces:
        if getattr(face, "select", False):
            loops.extend(face.loops)
    return loops


def _set_face_uv_selected(context, face, state: bool) -> None:
    """Select a face in the UV editor: the mesh selection with UV Sync, the UV flags without it."""
    if _uv_sync_on(context):
        face.select_set(bool(state))
        return
    face.uv_select_set(bool(state))
    for loop in face.loops:
        loop.uv_select_vert = bool(state)
        loop.uv_select_edge = bool(state)


def _face_uv_area(face, uv_layer) -> float:
    pts = [Vector(loop[uv_layer].uv) for loop in face.loops]
    if len(pts) < 3:
        return 0.0
    area = 0.0
    for i, p in enumerate(pts):
        q = pts[(i + 1) % len(pts)]
        area += p.x * q.y - q.x * p.y
    return 0.5 * area


def _poly_uv_area(poly, uv_data) -> float:
    pts = [Vector(uv_data[i].uv) for i in poly.loop_indices]
    if len(pts) < 3:
        return 0.0
    area = 0.0
    for i, p in enumerate(pts):
        q = pts[(i + 1) % len(pts)]
        area += p.x * q.y - q.x * p.y
    return 0.5 * area


def _tile_of_vec(uv: Vector) -> tuple[int, int]:
    return int(math.floor(float(uv.x))), int(math.floor(float(uv.y)))


def _face_centroid_tile(face, uv_layer) -> tuple[int, int]:
    loops = list(face.loops)
    if not loops:
        return (0, 0)
    acc = Vector((0.0, 0.0))
    for loop in loops:
        acc += Vector(loop[uv_layer].uv)
    acc /= max(1, len(loops))
    return _tile_of_vec(acc)


def _uv_edge_pair(loop, uv_layer):
    a = Vector(loop[uv_layer].uv)
    b = Vector(loop.link_loop_next[uv_layer].uv)
    return a, b


def _same_uv_edge(loop_a, loop_b, uv_layer, tolerance: float) -> bool:
    a0, a1 = _uv_edge_pair(loop_a, uv_layer)
    b0, b1 = _uv_edge_pair(loop_b, uv_layer)
    if loop_a.vert != loop_b.vert:
        b0, b1 = b1, b0
    return (a0 - b0).length <= tolerance and (a1 - b1).length <= tolerance


def _build_uv_islands(bm, uv_layer, tolerance: float = 1.0e-6) -> list[list]:
    faces = [face for face in bm.faces if not getattr(face, "hide", False)]
    face_set = set(faces)
    adjacency = {face: set() for face in faces}
    for face in faces:
        for loop in face.loops:
            edge = loop.edge
            try:
                linked = tuple(edge.link_faces)
            except Exception:
                linked = ()
            if len(linked) <= 1:
                continue
            for other in linked:
                if other is face or other not in face_set:
                    continue
                for other_loop in other.loops:
                    if other_loop.edge is edge and _same_uv_edge(loop, other_loop, uv_layer, tolerance):
                        adjacency[face].add(other)
                        adjacency[other].add(face)
                        break
    islands = []
    remaining = set(faces)
    while remaining:
        start = remaining.pop()
        stack = [start]
        island = [start]
        while stack:
            face = stack.pop()
            for other in adjacency.get(face, ()):
                if other in remaining:
                    remaining.remove(other)
                    stack.append(other)
                    island.append(other)
        islands.append(island)
    return islands


def _uv_editor_cursor(context) -> Vector:
    try:
        area = getattr(context, "area", None)
        spaces = getattr(area, "spaces", ()) if area is not None else ()
        for space in spaces:
            if getattr(space, "type", "") == "IMAGE_EDITOR" and hasattr(space, "cursor_location"):
                return Vector(space.cursor_location)
    except Exception:
        pass
    try:
        wm = getattr(context, "window_manager", None)
        for window in getattr(wm, "windows", ()) or ():
            screen = getattr(window, "screen", None)
            for area in getattr(screen, "areas", ()) or ():
                if getattr(area, "type", "") != "IMAGE_EDITOR":
                    continue
                for space in getattr(area, "spaces", ()) or ():
                    if hasattr(space, "cursor_location"):
                        return Vector(space.cursor_location)
    except Exception:
        pass
    return Vector((0.0, 0.0))


def _call_uv_operator(op, *args, **kwargs):
    try:
        return op(*args, **kwargs)
    except TypeError:
        try:
            return op(*args)
        except Exception:
            raise


def _checker_image(name: str, size: int):
    name = str(name or "Smart UV Checker").strip() or "Smart UV Checker"
    size = max(8, min(4096, int(size or 512)))
    image = bpy.data.images.get(name)
    if image is None or int(getattr(image, "size", (0, 0))[0] or 0) != size:
        if image is not None:
            try:
                bpy.data.images.remove(image)
            except Exception:
                pass
        image = bpy.data.images.new(name, size, size, alpha=True, float_buffer=False)
        pixels = [0.0] * (size * size * 4)
        block = max(4, size // 16)
        for y in range(size):
            for x in range(size):
                idx = (y * size + x) * 4
                even = ((x // block) + (y // block)) % 2 == 0
                value = 0.88 if even else 0.22
                pixels[idx:idx + 4] = (value, value, value, 1.0)
        image.pixels.foreach_set(pixels)
        image.update()
        try:
            image.pack()
        except Exception:
            pass
    return image


def _checker_material(name: str, size: int):
    mat_name = str(name or "Smart UV Checker").strip() or "Smart UV Checker"
    mat = bpy.data.materials.get(mat_name)
    if mat is None:
        mat = bpy.data.materials.new(mat_name)
    mat.use_nodes = True
    image = _checker_image(mat_name + " Image", size)
    try:
        nodes = mat.node_tree.nodes
        bsdf = nodes.get("Principled BSDF")
        tex = nodes.get("Smart UV Checker Texture")
        if tex is None:
            tex = nodes.new(type="ShaderNodeTexImage")
            tex.name = "Smart UV Checker Texture"
            tex.label = "Smart UV Checker Texture"
        tex.image = image
        if bsdf is not None:
            mat.node_tree.links.new(tex.outputs.get("Color"), bsdf.inputs.get("Base Color"))
    except Exception:
        pass
    return mat


_LABEL_JA_TEXT = {
    "Consolidated UV Map Action": "統合UVマップ操作",
    "Consolidated UV Snap": "統合UVスナップ",
    "Select UDIM Islands": "UDIMアイランド選択",
    "Checker Preview Action": "チェッカープレビュー操作",
    "Flatten UV to Shape Key": "UV平面化シェイプキー作成",
    "UV Built-in Assist": "UV標準補助",
    "Texel Density Report": "テクセル密度レポート",
    "Select UV Issue": "UV問題面選択",
}


def _translation_dictionary() -> dict:
    """bpy.app.translations payload for this module's operator labels.

    Reports and descriptions here are already bilingual via _tr/_report, so
    only the bl_label strings need catalog entries.
    """
    ja = {}
    for en, text in _LABEL_JA_TEXT.items():
        ja[('*', en)] = text
        ja[('Operator', en)] = text
    return {'ja_JP': ja}


def _register_translation() -> None:
    try:
        from . import ownership_runtime_18168 as _ownership
        dictionary = _translation_dictionary()
        _ownership.register_translation(__name__, dictionary)
    except Exception:
        pass



def _unregister_translation() -> None:
    try:
        from . import ownership_runtime_18168 as _ownership
        _ownership.unregister_translation(__name__)
    except Exception:
        pass



class SMARTUVSUITE_OT_consolidated_uv_map_action(bpy.types.Operator):
    bl_idname = "smart_uv_suite.consolidated_uv_map_action"
    bl_label = "Consolidated UV Map Action"
    bl_options = {'UNDO'}

    action: bpy.props.EnumProperty(
        name="Action",
        description="Choose the UV map operation to apply to the active or selected mesh objects.",
        items=(
            ("ADD", "Add", "Create a new UV map on selected mesh objects."),
            ("DUPLICATE", "Duplicate", "Duplicate the active UV map on selected mesh objects."),
            ("REMOVE", "Remove", "Remove the active UV map when another UV map remains."),
            ("MOVE_UP", "Move Up", "Move the active UV map upward in the list when Blender exposes the reorder operator."),
            ("MOVE_DOWN", "Move Down", "Move the active UV map downward in the list when Blender exposes the reorder operator."),
            ("RENAME", "Rename", "Rename the active UV map."),
            ("SET_RENDER", "Set Render", "Use the active UV map as the render UV layer when supported."),
            ("COPY_TO_SELECTED", "Copy to Selected", "Copy the active object's active UV map to selected mesh objects with matching loop counts."),
        ),
        default="ADD",
    )
    name: bpy.props.StringProperty(
        name="Name",
        description="Name used when adding, duplicating, copying, or renaming a UV map.",
        default="SmartUV",
    )

    @classmethod
    def description(cls, context, properties):
        return _tr(
            context,
            "Function: manages UV map channels in one consolidated operator. How to use: choose an action from the button preset; Add and Duplicate create UV layers, Rename uses the Name value, Copy to Selected transfers the active object's UV data to compatible selected meshes.",
            "機能: UVマップチャンネルを一つの統合オペレーターで管理します。使い方: ボタンごとの操作を選びます。追加と複製はUVレイヤーを作成し、名前変更はName値を使い、選択へコピーはアクティブオブジェクトのUVデータを互換性のある選択メッシュへ転送します。",
        )

    @classmethod
    def poll(cls, context):
        return _active_mesh(context) is not None

    def _copy_layer_data(self, src_layer, dst_layer) -> int:
        copied = 0
        try:
            if len(src_layer.data) != len(dst_layer.data):
                return 0
            for src, dst in zip(src_layer.data, dst_layer.data):
                dst.uv = src.uv
                copied += 1
        except Exception:
            return copied
        return copied

    def _move_active_layer(self, context, obj, direction: str) -> bool:
        """Blender has no reorder operator for UV maps, so swap the two neighbouring maps' contents."""
        with _active_object_mode(context, obj, "OBJECT"):
            uv_layers = obj.data.uv_layers
            index = int(uv_layers.active_index)
            other = index + (-1 if direction == "UP" else 1)
            if index < 0 or not 0 <= other < len(uv_layers):
                return False
            first, second = uv_layers[index], uv_layers[other]
            count = len(first.uv)
            first_uv = [0.0] * (count * 2)
            second_uv = [0.0] * (count * 2)
            first.uv.foreach_get("vector", first_uv)
            second.uv.foreach_get("vector", second_uv)
            first.uv.foreach_set("vector", second_uv)
            second.uv.foreach_set("vector", first_uv)
            if len(first.pin) or len(second.pin):
                first.pin_ensure()
                second.pin_ensure()
                first_pin = [False] * count
                second_pin = [False] * count
                first.pin.foreach_get("value", first_pin)
                second.pin.foreach_get("value", second_pin)
                first.pin.foreach_set("value", second_pin)
                second.pin.foreach_set("value", first_pin)
            first_name, second_name = first.name, second.name
            first.name = "__suv_uv_swap__"
            second.name = first_name
            first.name = second_name
            render_first, render_second = first.active_render, second.active_render
            clone_first, clone_second = first.active_clone, second.active_clone
            if render_first:
                second.active_render = True
            elif render_second:
                first.active_render = True
            if clone_first:
                second.active_clone = True
            elif clone_second:
                first.active_clone = True
            uv_layers.active_index = other
            obj.data.update()
        return True

    def execute(self, context):
        action = str(self.action or "ADD")
        meshes = _selected_meshes(context)
        if not meshes:
            _report(self, "WARNING", context, "No mesh object is selected.", "メッシュオブジェクトが選択されていません。")
            return {"CANCELLED"}

        changed = 0
        skipped = 0
        active_obj = _active_mesh(context)
        src_layer = None
        if active_obj is not None:
            src_layer = active_obj.data.uv_layers.active

        for obj in meshes:
            mesh = obj.data
            try:
                with _active_object_mode(context, obj, "OBJECT"):
                    uv_layers = mesh.uv_layers
                    active = uv_layers.active
                    if action == "ADD":
                        uv_layers.new(name=str(self.name or "SmartUV"))
                        changed += 1
                    elif action == "DUPLICATE":
                        if active is None:
                            skipped += 1
                            continue
                        new_layer = uv_layers.new(name=str(self.name or active.name + " Copy"))
                        changed += self._copy_layer_data(active, new_layer) > 0
                    elif action == "REMOVE":
                        if active is not None and len(uv_layers) > 1:
                            uv_layers.remove(active)
                            changed += 1
                        else:
                            skipped += 1
                    elif action == "RENAME":
                        if active is not None:
                            active.name = str(self.name or active.name)
                            changed += 1
                    elif action == "SET_RENDER":
                        if active is not None and hasattr(active, "active_render"):
                            active.active_render = True
                            changed += 1
                        else:
                            skipped += 1
                    elif action == "MOVE_UP":
                        changed += 1 if self._move_active_layer(context, obj, "UP") else 0
                    elif action == "MOVE_DOWN":
                        changed += 1 if self._move_active_layer(context, obj, "DOWN") else 0
                    elif action == "COPY_TO_SELECTED":
                        if obj is active_obj or src_layer is None:
                            continue
                        dst_name = str(self.name) if self.properties.is_property_set("name") and self.name else str(src_layer.name)
                        dst = uv_layers.get(dst_name) or uv_layers.new(name=dst_name)
                        if len(src_layer.data) != len(dst.data):
                            skipped += 1
                            continue
                        self._copy_layer_data(src_layer, dst)
                        uv_layers.active = dst
                        obj.data.update()
                        changed += 1
            except Exception:
                skipped += 1
                continue
        _report(self, "INFO", context, f"UV map action finished. Changed: {changed}, skipped: {skipped}.", f"UVマップ操作が完了しました。変更: {changed}、スキップ: {skipped}。")
        return {"FINISHED"} if changed or action in {"MOVE_UP", "MOVE_DOWN"} else {"CANCELLED"}


# -----------------------------------------------------------------------------
# Smart UV Suite 1.8.113 snap helpers
# -----------------------------------------------------------------------------
def _uv_nice_grid_step_18113(value: float) -> float:
    try:
        value = max(float(value), 1.0e-12)
        exp = math.floor(math.log10(value))
        base = 10.0 ** exp
        frac = value / base
        if frac <= 1.5:
            nice = 1.0
        elif frac <= 3.5:
            nice = 2.0
        elif frac <= 7.5:
            nice = 5.0
        else:
            nice = 10.0
        return max(float(nice * base), 1.0e-12)
    except Exception:
        return 1.0


def _uv_grid_subdivisions_18113(context) -> tuple[int, int]:
    try:
        space = getattr(context, "space_data", None)
        uv_editor = getattr(space, "uv_editor", None) if space is not None else None
        raw = None
        for owner in (uv_editor, space):
            if owner is None:
                continue
            try:
                raw = getattr(owner, "custom_grid_subdivisions", None)
            except Exception:
                raw = None
            if raw is not None:
                break
        if raw is None:
            return 10, 10
        if isinstance(raw, (tuple, list)) and len(raw) >= 2:
            return max(int(raw[0]), 1), max(int(raw[1]), 1)
        v = max(int(raw), 1)
        return v, v
    except Exception:
        return 10, 10


def _visible_uv_grid_step_18113(context, fallback: float | Vector = 0.125) -> Vector:
    """Return the visible UV editor grid step, including thin subdivisions.

    Grid snap intentionally follows the guide grid the user sees in the UV
    Editor.  When the view is zoomed in and Blender draws subdivided thin grid
    lines, those subdivisions are treated as valid snap targets.
    """
    try:
        if isinstance(fallback, Vector):
            fb = Vector((max(float(fallback.x), 1.0e-12), max(float(fallback.y), 1.0e-12)))
        else:
            f = max(float(fallback), 1.0e-12)
            fb = Vector((f, f))
    except Exception:
        fb = Vector((0.125, 0.125))
    try:
        space = getattr(context, "space_data", None)
        area = getattr(context, "area", None)
        if getattr(space, "type", "") != "IMAGE_EDITOR":
            area = next((a for a in getattr(context.screen, "areas", []) if a.type == "IMAGE_EDITOR"), None)
            space = area.spaces.active if area is not None else None
        uv_editor = getattr(space, "uv_editor", None) if space is not None else None
        source = str(getattr(uv_editor, "grid_shape_source", "") or "").upper() if uv_editor is not None else ""
        if source == "PIXEL":
            image = getattr(space, "image", None) if space is not None else None
            size = getattr(image, "size", None) if image is not None else None
            if size and int(size[0]) > 0 and int(size[1]) > 0:
                return Vector((1.0 / float(size[0]), 1.0 / float(size[1])))
        if source == "FIXED":
            raw = tuple(uv_editor.custom_grid_subdivisions)
            return Vector((1.0 / float(max(int(raw[0]), 1)), 1.0 / float(max(int(raw[1]), 1))))
        region = next((r for r in area.regions if r.type == "WINDOW"), None) if area is not None else None
        v2d = getattr(region, "view2d", None)
        if v2d is not None:
            # The dynamic grid draws lines at powers of eight, and a finer level
            # stays faint until its lines are about 96 pixels apart.
            a = v2d.region_to_view(0.0, 0.0)
            b = v2d.region_to_view(1.0, 1.0)
            per_pixel = max(abs(float(b[0] - a[0])), abs(float(b[1] - a[1])), 1.0e-12)
            step = 0.125 if 0.125 / per_pixel >= 16.0 else 1.0
            while step / 8.0 / per_pixel >= 96.0 and step > 1.0e-6:
                step /= 8.0
            return Vector((step, step))
    except Exception:
        pass
    return fb


def _selected_uv_loops_strict_18113(context, obj, bm, uv_layer) -> list:
    """Use the final UV-selection backend when available.

    This keeps snapping consistent with UV Select Sync ON/OFF and avoids reading
    stale all-selected mesh/UV attribute caches.
    """
    try:
        from . import uv_room_integrity_18103 as _ri
        mode = _ri._uv_mode(context)
        loops, edge_loops, faces = _ri._selected_sets(context, obj, bm, uv_layer, mode)
        out = []
        seen = set()
        def add(loop):
            try:
                if loop is None or getattr(loop, 'hide', False) or getattr(loop.face, 'hide', False):
                    return
                key = id(loop)
                if key in seen:
                    return
                seen.add(key); out.append(loop)
            except Exception:
                pass
        if mode == 'FACE' and faces:
            for face in faces:
                for loop in face.loops:
                    add(loop)
        elif mode == 'EDGE' and edge_loops:
            for loop in edge_loops:
                add(loop)
                try: add(loop.link_loop_next)
                except Exception: pass
        for loop in loops:
            add(loop)
        if out:
            return out
    except Exception:
        pass
    return _selected_uv_loops(context, bm, uv_layer)


def _snap_selected_vertices_to_midpoints_18113(context, loops: Sequence, uv_layer, distance: float) -> int:
    try:
        threshold = max(float(distance), 0.0)
    except Exception:
        threshold = 0.0
    if threshold <= 0.0:
        return 0
    # Bucket identical UV positions first.  This keeps welded visual vertices
    # together while reducing the number of distance checks on dense selections.
    buckets: dict[tuple[int, int], list] = {}
    precision = 1000000000.0
    for loop in list(loops or []):
        try:
            uv = loop[uv_layer].uv
            key = (int(round(float(uv.x) * precision)), int(round(float(uv.y) * precision)))
            buckets.setdefault(key, []).append(loop)
        except Exception:
            pass
    points = []
    for recs in buckets.values():
        if not recs:
            continue
        try:
            uv = recs[0][uv_layer].uv.copy()
        except Exception:
            continue
        points.append({"uv": Vector((float(uv.x), float(uv.y))), "loops": recs})
    n = len(points)
    if n <= 1:
        return 0
    parent = list(range(n))
    def find(i: int) -> int:
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    def union(a: int, b: int) -> None:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra
    used_kd = False
    try:
        from mathutils import kdtree
        kd = kdtree.KDTree(n)
        for i, item in enumerate(points):
            uv = item["uv"]
            kd.insert((float(uv.x), float(uv.y), 0.0), i)
        kd.balance()
        for i, item in enumerate(points):
            uv = item["uv"]
            for _co, j, dist in kd.find_range((float(uv.x), float(uv.y), 0.0), threshold + 1.0e-12):
                if j > i and float(dist) <= threshold + 1.0e-12:
                    union(i, int(j))
        used_kd = True
    except Exception:
        used_kd = False
    if not used_kd:
        cell = max(threshold, 1.0e-12)
        grid: dict[tuple[int, int], list[int]] = {}
        for i, item in enumerate(points):
            uv = item["uv"]
            cx = int(math.floor(float(uv.x) / cell)); cy = int(math.floor(float(uv.y) / cell))
            for ox in (-1, 0, 1):
                for oy in (-1, 0, 1):
                    for j in grid.get((cx + ox, cy + oy), []) or []:
                        other = points[j]["uv"]
                        if (uv - other).length <= threshold + 1.0e-12:
                            union(i, j)
            grid.setdefault((cx, cy), []).append(i)
    groups: dict[int, list[int]] = {}
    for i in range(n):
        groups.setdefault(find(i), []).append(i)
    changed = 0
    for ids in groups.values():
        if len(ids) <= 1:
            continue
        center = Vector((0.0, 0.0))
        count = 0
        for i in ids:
            recs = points[i]["loops"]
            weight = max(1, len(recs))
            center += points[i]["uv"] * float(weight)
            count += weight
        center /= float(max(1, count))
        for i in ids:
            for loop in points[i]["loops"]:
                try:
                    uv = loop[uv_layer].uv
                    if abs(float(uv.x) - float(center.x)) > 1.0e-12 or abs(float(uv.y) - float(center.y)) > 1.0e-12:
                        uv.x = float(center.x); uv.y = float(center.y)
                        changed += 1
                except Exception:
                    pass
    return changed


class SMARTUVSUITE_OT_consolidated_snap_uv(bpy.types.Operator):
    bl_idname = "smart_uv_suite.consolidated_snap_uv"
    bl_label = "Consolidated UV Snap"
    bl_options = {'UNDO'}

    mode: bpy.props.EnumProperty(
        name="Mode",
        description="Target used when snapping selected UV coordinates. Grid uses the visible UV Editor grid including subdivisions; Vertex merges nearby selected UV vertices to their midpoint.",
        items=(
            ("GRID", "Grid", "Round selected UVs to the nearest visible UV Editor grid line."),
            ("PIXEL", "Pixel", "Round selected UVs to one Texture Size pixel."),
            ("VERTEX", "Vertex", "Move selected UV vertices within the distance setting to their shared midpoint."),
        ),
        default="GRID",
    )
    axis: bpy.props.EnumProperty(
        name="Axis",
        description="Coordinate axis affected by the snap operation.",
        items=(("BOTH", "U and V", "Snap both axes."), ("U", "U", "Snap only U."), ("V", "V", "Snap only V.")),
        default="BOTH",
    )
    grid_size: bpy.props.FloatProperty(
        name="Grid Size",
        description="UV grid interval used by Grid mode. For example 0.125 snaps to eighths of a tile.",
        default=0.125,
        min=0.000001,
        max=10.0,
    )
    texture_size: bpy.props.IntProperty(
        name="Texture Size",
        description="Texture resolution used by Pixel mode to compute one-pixel UV increments.",
        default=1024,
        min=1,
        max=65536,
    )
    vertex_distance: bpy.props.FloatProperty(
        name="Vertex Distance",
        description="Maximum UV distance for Vertex snap. Selected UV vertices within this distance are moved to their shared midpoint.",
        default=0.001,
        min=0.0,
        max=10.0,
        precision=6,
    )

    @classmethod
    def description(cls, context, properties):
        return _tr(
            context,
            "Function: snaps selected UV vertices to the visible UV grid, texture-pixel interval, or nearby selected vertex midpoint. How to use: select UVs in Edit Mode, choose Grid, Pixel, or Vertex, then run it. Axis limits allow U-only or V-only snapping for grid and pixel snapping.",
            "機能: 選択UV頂点を表示中のUVグリッド、テクスチャの1ピクセル間隔、または近接する選択頂点同士の中点へスナップします。使い方: 編集モードでUVを選択し、グリッド・ピクセル・頂点を実行します。グリッドとピクセルでは軸指定によりUのみ、Vのみのスナップも可能です。",
        )

    @classmethod
    def poll(cls, context):
        obj = _active_mesh(context)
        return obj is not None

    def _snap_vec(self, uv: Vector, cursor: Vector, grid_step: Vector | None = None) -> Vector:
        mode = str(self.mode or "GRID")
        result = Vector(uv)
        if mode == "GRID":
            step_vec = grid_step if grid_step is not None else Vector((max(1.0e-9, float(self.grid_size)), max(1.0e-9, float(self.grid_size))))
            sx = max(1.0e-12, float(step_vec.x))
            sy = max(1.0e-12, float(step_vec.y))
            target = Vector((round(result.x / sx) * sx, round(result.y / sy) * sy))
        elif mode == "PIXEL":
            step = 1.0 / max(1, int(self.texture_size))
            target = Vector((round(result.x / step) * step, round(result.y / step) * step))
        else:
            target = result
        if self.axis in {"BOTH", "U"}:
            result.x = target.x
        if self.axis in {"BOTH", "V"}:
            result.y = target.y
        return result

    def execute(self, context):
        obj = _active_mesh(context)
        if obj is None:
            return {"CANCELLED"}
        count = 0
        with _active_object_mode(context, obj, "EDIT"):
            bm, uv_layer = _bm_and_uv(context, obj)
            if bm is None or uv_layer is None:
                return {"CANCELLED"}
            loops = _selected_uv_loops_strict_18113(context, obj, bm, uv_layer)
            mode = str(getattr(self, "mode", "GRID") or "GRID").upper()
            if mode == "VERTEX":
                distance = float(getattr(self, "vertex_distance", 0.001) or 0.0)
                try:
                    scene_distance = getattr(getattr(context, "scene", None), "suv_consolidated_snap_vertex_distance", None)
                    if scene_distance is not None and not self.properties.is_property_set("vertex_distance"):
                        distance = float(scene_distance)
                except Exception:
                    pass
                count = _snap_selected_vertices_to_midpoints_18113(context, loops, uv_layer, distance)
            else:
                cursor = _uv_editor_cursor(context)
                grid_step = _visible_uv_grid_step_18113(context, max(1.0e-9, float(self.grid_size))) if mode == "GRID" else None
                for loop in loops:
                    loop[uv_layer].uv = self._snap_vec(Vector(loop[uv_layer].uv), cursor, grid_step)
                    count += 1
            try:
                if hasattr(bm, "select_flush_mode"):
                    bm.select_flush_mode()
            except Exception:
                pass
            bmesh.update_edit_mesh(obj.data)
        _report(self, "INFO", context, f"Snapped {count} UV loop(s).", f"{count} 個のUVループをスナップしました。")
        return {"FINISHED"} if count else {"CANCELLED"}


class SMARTUVSUITE_OT_consolidated_select_udim_islands(bpy.types.Operator):
    bl_idname = "smart_uv_suite.consolidated_select_udim_islands"
    bl_label = "Select UDIM Islands"
    bl_options = {'UNDO'}

    mode: bpy.props.EnumProperty(
        name="Mode",
        description="Choose the tile used to select UV islands.",
        items=(
            ("ACTIVE", "Active Tile", "Use the tile of the selected or active face."),
            ("MANUAL", "Manual Tile", "Use the Tile U and Tile V values."),
        ),
        default="ACTIVE",
    )
    tile_u: bpy.props.IntProperty(name="Tile U", description="UDIM tile U index. U 0 and V 0 correspond to UDIM 1001.", default=0, min=-100, max=100)
    tile_v: bpy.props.IntProperty(name="Tile V", description="UDIM tile V index. U 0 and V 0 correspond to UDIM 1001.", default=0, min=-100, max=100)
    full_islands: bpy.props.BoolProperty(name="Full Islands", description="Select every face in a matching island instead of only the matching faces.", default=True)

    @classmethod
    def description(cls, context, properties):
        return _tr(
            context,
            "Function: selects all UV faces or full islands on a target UDIM tile. How to use: select a face on the desired tile and run Active Tile, or set Tile U and Tile V and run Manual Tile.",
            "機能: 対象UDIMタイル上のUV面またはアイランド全体を選択します。使い方: 目的タイル上の面を選んでアクティブタイルで実行するか、Tile UとTile Vを指定して手動タイルで実行します。",
        )

    @classmethod
    def poll(cls, context):
        return _active_mesh(context) is not None

    def execute(self, context):
        obj = _active_mesh(context)
        if obj is None:
            return {"CANCELLED"}
        selected = 0
        with _active_object_mode(context, obj, "EDIT"):
            bm, uv_layer = _bm_and_uv(context, obj)
            if bm is None or uv_layer is None:
                return {"CANCELLED"}
            target = (int(self.tile_u), int(self.tile_v))
            if self.mode == "ACTIVE":
                candidate = None
                for face in bm.faces:
                    if face.select:
                        candidate = face
                        break
                if candidate is None:
                    try:
                        candidate = bm.faces.active
                    except Exception:
                        candidate = None
                if candidate is not None:
                    target = _face_centroid_tile(candidate, uv_layer)
            islands = _build_uv_islands(bm, uv_layer)
            for face in bm.faces:
                _set_face_uv_selected(context, face, False)
            for island in islands:
                if self.full_islands:
                    hit = any(_face_centroid_tile(face, uv_layer) == target for face in island)
                    faces = island if hit else ()
                else:
                    faces = [face for face in island if _face_centroid_tile(face, uv_layer) == target]
                for face in faces:
                    _set_face_uv_selected(context, face, True)
                    selected += 1
            bmesh.update_edit_mesh(obj.data)
        udim = 1001 + target[0] + target[1] * 10
        _report(self, "INFO", context, f"Selected {selected} face(s) on UDIM {udim}.", f"UDIM {udim} の {selected} 面を選択しました。")
        return {"FINISHED"} if selected else {"CANCELLED"}


class SMARTUVSUITE_OT_consolidated_checker_action(bpy.types.Operator):
    bl_idname = "smart_uv_suite.consolidated_checker_action"
    bl_label = "Checker Preview Action"
    bl_options = {'UNDO'}

    action: bpy.props.EnumProperty(
        name="Action",
        description="Checker preview action to run.",
        items=(
            ("CREATE", "Create", "Create or update the generated checker image and material."),
            ("APPLY", "Apply", "Apply the generated checker material to selected meshes."),
            ("CLEAR", "Clear", "Remove Smart UV checker materials from selected meshes."),
        ),
        default="APPLY",
    )
    size: bpy.props.IntProperty(name="Size", description="Generated checker texture size in pixels.", default=512, min=8, max=4096)
    name: bpy.props.StringProperty(name="Name", description="Base name for the generated checker image and material.", default="Smart UV Checker")

    @classmethod
    def description(cls, context, properties):
        return _tr(
            context,
            "Function: creates, applies, or clears a procedural UV checker preview. How to use: apply it to selected mesh objects to verify UV scale, stretching, and orientation without importing external texture files.",
            "機能: 手続き型UVチェッカープレビューを作成、適用、解除します。使い方: 選択メッシュへ適用し、外部テクスチャを読み込まずにUVスケール、歪み、向きを確認します。",
        )

    @classmethod
    def poll(cls, context):
        return bool(_selected_meshes(context)) or str(getattr(context, "mode", "")) == "OBJECT"

    def execute(self, context):
        action = str(self.action or "APPLY")
        mat = _checker_material(self.name, self.size)
        if action == "CREATE":
            _report(self, "INFO", context, "Checker material was created or updated.", "チェッカーマテリアルを作成または更新しました。")
            return {"FINISHED"}
        meshes = _selected_meshes(context)
        if not meshes:
            return {"CANCELLED"}
        changed = 0
        for obj in meshes:
            try:
                mesh = obj.data
                if action == "APPLY":
                    from . import native_stage as _native_stage
                    _native_stage._suv_show_preview_material(obj, mat, '_suv_checker_restore')
                    changed += 1
                elif action == "CLEAR":
                    with _active_object_mode(context, obj, "OBJECT"):
                        from . import native_stage as _native_stage
                        if _native_stage._suv_restore_material_state(obj, '_suv_checker_restore'):
                            changed += 1
                        for idx in reversed(range(len(mesh.materials))):
                            slot_mat = mesh.materials[idx]
                            if slot_mat and str(slot_mat.name).startswith(str(self.name or "Smart UV Checker")):
                                mesh.materials.pop(index=idx)
                                changed += 1
            except Exception:
                continue
        _report(self, "INFO", context, f"Checker action finished. Changed: {changed}.", f"チェッカー操作が完了しました。変更: {changed}。")
        return {"FINISHED"} if changed else {"CANCELLED"}


class SMARTUVSUITE_OT_consolidated_flatten_to_uv_shape_key(bpy.types.Operator):
    bl_idname = "smart_uv_suite.consolidated_flatten_to_uv_shape_key"
    bl_label = "Flatten UV to Shape Key"
    bl_options = {'UNDO'}

    name: bpy.props.StringProperty(name="Shape Key Name", description="Name of the generated UV-flattened shape key.", default="Smart UV Flatten")
    scale: bpy.props.FloatProperty(name="Scale", description="Scale multiplier applied to UV coordinates in the generated shape key.", default=1.0, min=0.0001, max=100000.0)
    center: bpy.props.BoolProperty(name="Center", description="Center the flattened UV result around the origin.", default=True)
    z: bpy.props.FloatProperty(name="Z", description="Z coordinate assigned to every flattened vertex.", default=0.0)

    @classmethod
    def description(cls, context, properties):
        return _tr(
            context,
            "Function: creates a shape key that flattens mesh vertices to their active UV coordinates. How to use: select mesh objects with UVs, run the operator, then use the generated shape key for UV-to-mesh inspection, baking setup, or 2D layout reference.",
            "機能: メッシュ頂点をアクティブUV座標へ平面化するシェイプキーを作成します。使い方: UVを持つメッシュを選択して実行し、生成されたシェイプキーをUV確認、ベイク準備、2D配置参照に使います。",
        )

    @classmethod
    def poll(cls, context):
        return bool(_selected_meshes(context))

    def execute(self, context):
        changed = 0
        for obj in _selected_meshes(context):
            try:
                with _active_object_mode(context, obj, "OBJECT"):
                    mesh = obj.data
                    uv_layer = _ensure_uv_layer_object(mesh)
                    if uv_layer is None:
                        continue
                    sums = [Vector((0.0, 0.0)) for _ in mesh.vertices]
                    counts = [0 for _ in mesh.vertices]
                    uv_data = uv_layer.data
                    for poly in mesh.polygons:
                        for li in poly.loop_indices:
                            vi = mesh.loops[li].vertex_index
                            sums[vi] += Vector(uv_data[li].uv)
                            counts[vi] += 1
                    coords = []
                    for i, vertex in enumerate(mesh.vertices):
                        if counts[i]:
                            uv = sums[i] / counts[i]
                        else:
                            co = vertex.co
                            uv = Vector((co.x, co.y))
                        coords.append(Vector((uv.x, uv.y, 0.0)))
                    if self.center and coords:
                        min_x = min(v.x for v in coords); max_x = max(v.x for v in coords)
                        min_y = min(v.y for v in coords); max_y = max(v.y for v in coords)
                        offset = Vector(((min_x + max_x) * 0.5, (min_y + max_y) * 0.5, 0.0))
                    else:
                        offset = Vector((0.0, 0.0, 0.0))
                    if obj.data.shape_keys is None:
                        obj.shape_key_add(name="Basis", from_mix=False)
                    key = obj.shape_key_add(name=str(self.name or "Smart UV Flatten"), from_mix=False)
                    for i, point in enumerate(coords):
                        key.data[i].co = Vector(((point.x - offset.x) * float(self.scale), (point.y - offset.y) * float(self.scale), float(self.z)))
                    changed += 1
            except Exception:
                continue
        _report(self, "INFO", context, f"Created UV flatten shape key on {changed} object(s).", f"{changed} 個のオブジェクトにUV平面化シェイプキーを作成しました。")
        return {"FINISHED"} if changed else {"CANCELLED"}


class SMARTUVSUITE_OT_consolidated_builtin_uv_action(bpy.types.Operator):
    bl_idname = "smart_uv_suite.consolidated_builtin_uv_action"
    bl_label = "UV Built-in Assist"
    bl_options = {'UNDO'}

    action: bpy.props.EnumProperty(
        name="Action",
        description="Blender native UV operation to run from the consolidated tool surface.",
        items=(
            ("PACK", "Pack", "Pack selected UV islands."),
            ("AVERAGE_SCALE", "Average Scale", "Average selected UV island scale."),
            ("MINIMIZE_STRETCH", "Minimize Stretch", "Run Blender's minimize-stretch UV relaxation."),
            ("FOLLOW_ACTIVE_QUADS", "Follow Quads", "Run Follow Active Quads with even spacing."),
            ("PIN", "Pin", "Pin selected UVs."),
            ("UNPIN", "Unpin", "Unpin selected UVs."),
            ("PIN_INVERT", "Invert Pins", "Invert selected UV pin states."),
            ("STITCH", "Stitch", "Run Smart UV Suite UV Editor based stitch."),
            ("SEAMS_FROM_ISLANDS", "Seams From Islands", "Mark mesh seams from current UV islands."),
        ),
        default="PACK",
    )

    @classmethod
    def description(cls, context, properties):
        return _tr(
            context,
            "Function: exposes Blender native UV operations through the Smart UV Suite consolidated UI. How to use: select UV or mesh elements in Edit Mode and run the desired assist command.",
            "機能: Blender標準UV操作をSmart UV Suiteの統合UIから呼び出します。使い方: 編集モードでUVまたはメッシュ要素を選択し、目的の補助コマンドを実行します。",
        )

    @classmethod
    def poll(cls, context):
        return _active_mesh(context) is not None

    def execute(self, context):
        obj = _active_mesh(context)
        if obj is None:
            return {"CANCELLED"}
        action = str(self.action or "PACK")
        try:
            with _active_object_mode(context, obj, "EDIT"):
                if action == "PACK":
                    try:
                        bpy.ops.uv.pack_islands(rotate=True, margin=0.001)
                    except TypeError:
                        bpy.ops.uv.pack_islands()
                elif action == "AVERAGE_SCALE":
                    bpy.ops.uv.average_islands_scale()
                elif action == "MINIMIZE_STRETCH":
                    bpy.ops.uv.minimize_stretch(iterations=50)
                elif action == "FOLLOW_ACTIVE_QUADS":
                    try:
                        bpy.ops.uv.follow_active_quads(mode="EVEN")
                    except TypeError:
                        bpy.ops.uv.follow_active_quads()
                elif action == "PIN":
                    try:
                        from . import seam_pin_tools as _spt
                        _spt.pin_uv_selection(context, action='PIN')
                    except Exception:
                        try:
                            bpy.ops.uv.pin(clear=False)
                        except TypeError:
                            bpy.ops.uv.pin()
                elif action == "UNPIN":
                    try:
                        from . import seam_pin_tools as _spt
                        _spt.pin_uv_selection(context, action='CLEAR_PINS')
                    except Exception:
                        try:
                            bpy.ops.uv.pin(clear=True)
                        except TypeError:
                            bpy.ops.uv.pin()
                elif action == "PIN_INVERT":
                    from . import seam_pin_tools as _spt
                    _spt.pin_uv_selection(context, action='INVERT_PINS')
                elif action == "STITCH":
                    bpy.ops.smart_uv_suite.stitch_action(mode="ISLAND_CONNECTED_TO_SELECTED")
                elif action == "SEAMS_FROM_ISLANDS":
                    bpy.ops.uv.seams_from_islands()
        except Exception as exc:
            _report(self, "ERROR", context, f"Built-in UV action failed: {exc}", f"UV標準補助に失敗しました: {exc}")
            return {"CANCELLED"}
        _report(self, "INFO", context, "Built-in UV action finished.", "UV標準補助が完了しました。")
        return {"FINISHED"}


class SMARTUVSUITE_OT_consolidated_texel_density_report(bpy.types.Operator):
    bl_idname = "smart_uv_suite.consolidated_texel_density_report"
    bl_label = "Texel Density Report"
    bl_options = set()
    _sms_no_undo = True

    texture_size: bpy.props.IntProperty(name="Texture Size", description="Texture resolution used for density reporting.", default=1024, min=1, max=65536)
    selected_only: bpy.props.BoolProperty(name="Selected Only", description="Use selected faces only when the object is in Edit Mode.", default=True)

    @classmethod
    def description(cls, context, properties):
        return _tr(
            context,
            "Function: estimates texel density from mesh surface area and active UV area. How to use: select mesh faces or objects, run the report, and read the resulting pixels-per-unit value in the status message and scene property.",
            "機能: メッシュ表面積とアクティブUV面積からテクセル密度を推定します。使い方: メッシュ面またはオブジェクトを選択して実行し、ステータスメッセージとシーンプロパティのpx/unit値を確認します。",
        )

    @classmethod
    def poll(cls, context):
        return bool(_selected_meshes(context))

    def execute(self, context):
        mesh_area = 0.0
        uv_area = 0.0
        used_faces = 0
        selected_faces_only = self.selected_only and context.mode == "EDIT_MESH"
        for obj in _selected_meshes(context):
            if selected_faces_only and obj.mode != "EDIT":
                continue
            try:
                with _active_object_mode(context, obj, "OBJECT"):
                    mesh = obj.data
                    uv_layer = _ensure_uv_layer_object(mesh)
                    if uv_layer is None:
                        continue
                    uv_data = uv_layer.data
                    scale = abs(float(obj.matrix_world.to_3x3().determinant())) ** (1.0 / 3.0)
                    area_scale = scale * scale
                    for poly in mesh.polygons:
                        if selected_faces_only and not poly.select:
                            continue
                        mesh_area += float(poly.area) * area_scale
                        uv_area += abs(_poly_uv_area(poly, uv_data))
                        used_faces += 1
            except Exception:
                continue
        if mesh_area <= 1.0e-12 or uv_area <= 1.0e-12:
            _report(self, "WARNING", context, "Texel density could not be computed from the current selection.", "現在の選択からテクセル密度を計算できません。")
            return {"CANCELLED"}
        density = (math.sqrt(uv_area) * int(self.texture_size)) / math.sqrt(mesh_area)
        try:
            context.scene.suv_consolidated_last_density = float(density)
        except Exception:
            pass
        _report(self, "INFO", context, f"Texel density: {density:.3f} px/unit from {used_faces} face(s).", f"テクセル密度: {density:.3f} px/unit、対象面数: {used_faces}。")
        return {"FINISHED"}


class SMARTUVSUITE_OT_consolidated_select_uv_issue(bpy.types.Operator):
    bl_idname = "smart_uv_suite.consolidated_select_uv_issue"
    bl_label = "Select UV Issue"
    bl_options = {'UNDO'}

    action: bpy.props.EnumProperty(
        name="Issue",
        description="UV issue type to select.",
        items=(
            ("ZERO_AREA", "Zero Area", "Select faces with near-zero UV area."),
            ("FLIPPED", "Flipped", "Select faces with negative signed UV area."),
            ("OUTSIDE_TILE", "Outside Tile", "Select faces with any UV outside the chosen tile."),
            ("UDIM_CROSSING", "UDIM Crossing", "Select faces whose loops cross multiple UDIM tiles."),
        ),
        default="ZERO_AREA",
    )
    tile_u: bpy.props.IntProperty(name="Tile U", description="Tile U used by Outside Tile mode.", default=0, min=-100, max=100)
    tile_v: bpy.props.IntProperty(name="Tile V", description="Tile V used by Outside Tile mode.", default=0, min=-100, max=100)
    tolerance: bpy.props.FloatProperty(name="Tolerance", description="Numerical threshold used by zero-area checks.", default=1.0e-8, min=0.0, max=1.0)

    @classmethod
    def description(cls, context, properties):
        return _tr(
            context,
            "Function: selects UV faces with common layout problems such as zero area, flipped winding, outside-tile coordinates, or UDIM crossing. How to use: run after unwrapping or packing to isolate faces that need cleanup.",
            "機能: ゼロ面積、反転、タイル外座標、UDIM跨ぎなどの一般的なUV配置問題を持つ面を選択します。使い方: 展開後やパック後に実行し、修正が必要な面を切り分けます。",
        )

    @classmethod
    def poll(cls, context):
        return _active_mesh(context) is not None

    def execute(self, context):
        obj = _active_mesh(context)
        if obj is None:
            return {"CANCELLED"}
        selected = 0
        action = str(self.action or "ZERO_AREA")
        target = (int(self.tile_u), int(self.tile_v))
        with _active_object_mode(context, obj, "EDIT"):
            bm, uv_layer = _bm_and_uv(context, obj)
            if bm is None or uv_layer is None:
                return {"CANCELLED"}
            for face in bm.faces:
                area = _face_uv_area(face, uv_layer)
                uvs = [Vector(loop[uv_layer].uv) for loop in face.loops]
                tiles = {_tile_of_vec(uv) for uv in uvs}
                hit = False
                if action == "ZERO_AREA":
                    hit = abs(area) <= float(self.tolerance)
                elif action == "FLIPPED":
                    hit = area < -float(self.tolerance)
                elif action == "OUTSIDE_TILE":
                    hit = any(not (target[0] <= uv.x <= target[0] + 1.0 and target[1] <= uv.y <= target[1] + 1.0) for uv in uvs)
                elif action == "UDIM_CROSSING":
                    hit = len(tiles) > 1
                _set_face_uv_selected(context, face, hit)
                if hit:
                    selected += 1
            bmesh.update_edit_mesh(obj.data)
        _report(self, "INFO", context, f"Selected {selected} issue face(s).", f"問題面を {selected} 個選択しました。")
        return {"FINISHED"} if selected else {"CANCELLED"}


classes = (
    SMARTUVSUITE_OT_consolidated_uv_map_action,
    SMARTUVSUITE_OT_consolidated_snap_uv,
    SMARTUVSUITE_OT_consolidated_select_udim_islands,
    SMARTUVSUITE_OT_consolidated_checker_action,
    SMARTUVSUITE_OT_consolidated_flatten_to_uv_shape_key,
    SMARTUVSUITE_OT_consolidated_builtin_uv_action,
    SMARTUVSUITE_OT_consolidated_texel_density_report,
    SMARTUVSUITE_OT_consolidated_select_uv_issue,
)


def _safe_register_class(cls):
    # Register only the explicitly supplied Smart UV class identity.  A foreign
    # name collision is left untouched and causes this local step to fail.
    try:
        return bool(_suv_resource.register_class(cls))
    except Exception:
        return False


def _safe_unregister_class(cls):
    try:
        _suv_resource.unregister_class(cls)
    except Exception:
        pass


def _install_scene_props() -> None:
    try:
        if not hasattr(bpy.types.Scene, "suv_consolidated_last_density"):
            _suv_resource.register_property(bpy.types.Scene, 'suv_consolidated_last_density', bpy.props.FloatProperty(name='Last Texel Density', description='Last px/unit texel density measured by Smart UV Suite consolidated tools.', default=0.0, min=0.0))
        if not hasattr(bpy.types.Scene, "suv_consolidated_checker_size"):
            _suv_resource.register_property(bpy.types.Scene, 'suv_consolidated_checker_size', bpy.props.IntProperty(name='Checker Size', description='Default checker texture size for Smart UV Suite consolidated checker tools.', default=512, min=8, max=4096))
        if not hasattr(bpy.types.Scene, "suv_consolidated_checker_name"):
            _suv_resource.register_property(bpy.types.Scene, 'suv_consolidated_checker_name', bpy.props.StringProperty(name='Checker Name', description='Default generated checker material name.', default='Smart UV Checker'))
        if not hasattr(bpy.types.Scene, "suv_consolidated_snap_grid"):
            _suv_resource.register_property(bpy.types.Scene, 'suv_consolidated_snap_grid', bpy.props.FloatProperty(name='Snap Grid', description='Default UV snap grid interval used by consolidated snapping tools.', default=0.125, min=1e-06, max=10.0))
        if not hasattr(bpy.types.Scene, "suv_consolidated_snap_vertex_distance"):
            _suv_resource.register_property(bpy.types.Scene, 'suv_consolidated_snap_vertex_distance', bpy.props.FloatProperty(name='Vertex Distance', description='Maximum UV distance for Vertex snap. Selected UV vertices inside this distance are moved to their shared midpoint.', default=0.001, min=0.0, max=10.0, precision=6))
        if not hasattr(bpy.types.Scene, "suv_consolidated_flatten_scale"):
            _suv_resource.register_property(bpy.types.Scene, 'suv_consolidated_flatten_scale', bpy.props.FloatProperty(name='Flatten Scale', description='Default UV-to-shape-key scale for consolidated flattening tools.', default=1.0, min=0.0001, max=100000.0))
    except Exception:
        pass


def _remove_scene_props() -> None:
    for name in _SCENE_PROPS:
        try:
            _suv_resource.unregister_property(bpy.types.Scene, name)
        except Exception:
            pass


def register() -> None:
    global _REGISTERED
    if _REGISTERED:
        return
    _register_translation()
    _install_scene_props()
    for cls in classes:
        try:
            from . import text_translation as _text_translation
            sanitize = getattr(_text_translation, "sanitize_class", None)
            if callable(sanitize):
                sanitize(cls, context=getattr(bpy, "context", None))
        except Exception:
            pass
        _safe_register_class(cls)
    _REGISTERED = True


def unregister() -> None:
    global _REGISTERED
    for cls in reversed(classes):
        _safe_unregister_class(cls)
    _remove_scene_props()
    _unregister_translation()
    _REGISTERED = False
