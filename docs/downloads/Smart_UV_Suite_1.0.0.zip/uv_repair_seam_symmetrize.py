import bpy


def build_handlers(api):
    def symmetrize_mesh(context, op):
        if context.mode != 'EDIT_MESH' or not bpy.ops.mesh.symmetrize.poll():
            return False
        options = {}
        if op.direction:
            options['direction'] = op.direction
        if op.properties.is_property_set('amount'):
            options['threshold'] = op.amount
        return 'FINISHED' in bpy.ops.mesh.symmetrize(**options)

    def mirror_seams(context, op):
        if context.mode != 'EDIT_MESH' or op.axis not in {'', 'X'}:
            return False
        rows = api._edit_targets(context)
        changed = []
        for row in rows:
            _, bm, _ = row
            bm.verts.index_update()
            mirror, _ = api._mirror_maps(bm)
            edges = {frozenset(edge.verts): edge for edge in bm.edges if not edge.hide}
            pending = set()
            for edge in edges.values():
                if not edge.seam or not edge.select:
                    continue
                counterpart = edges.get(frozenset(mirror.get(vert) for vert in edge.verts))
                if counterpart is not None and not counterpart.seam:
                    pending.add(counterpart)
            for edge in pending:
                edge.seam = True
            if pending:
                changed.append(row)
        api._flush(changed)
        return bool(changed)

    mirror_handler = api.Handler(mirror_seams,
        'Copy selected seams to corresponding edges across the mesh X axis.',
        '選択したシームをメッシュのX軸反対側の対応辺にコピーします。')
    return {
        'smart_uv_suite.seam_symmetrize': api.Handler(symmetrize_mesh,
            'Mirror selected mesh geometry across the chosen axis.',
            '選択したメッシュ形状を指定軸で対称化します。'),
        'smart_uv_suite.seam_symmetrize_symmetrize': mirror_handler,
        'smart_uv_suite.seam_mirror': mirror_handler,
    }
