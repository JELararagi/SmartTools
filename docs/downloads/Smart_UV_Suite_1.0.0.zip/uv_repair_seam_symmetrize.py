"""Geometry symmetry and X-mirrored seam editing."""
import bpy


def _symmetrize(context, operator):
    native = bpy.ops.mesh.symmetrize
    if context.mode != "EDIT_MESH" or not native.poll():
        return False
    parameters = {"direction": operator.direction} if operator.direction else {}
    if operator.properties.is_property_set("amount"):
        parameters["threshold"] = operator.amount
    return native(**parameters) == {"FINISHED"}


def build_handlers(api):
    def copy_marked_edges(context, operator):
        if context.mode != "EDIT_MESH" or operator.axis not in ("", "X"):
            return False

        edited_meshes = []
        for target in api._edit_targets(context):
            _, mesh, _ = target
            mesh.verts.index_update()
            mirrored_vertex, _ = api._mirror_maps(mesh)
            seeds = [edge for edge in mesh.edges if edge.select and edge.seam and not edge.hide]
            mirror_pairs = set()
            for edge in seeds:
                pair = tuple(mirrored_vertex.get(vert) for vert in edge.verts)
                if None not in pair:
                    mirror_pairs.add(frozenset(pair))
            destinations = [
                edge for edge in mesh.edges
                if not edge.hide and not edge.seam and frozenset(edge.verts) in mirror_pairs
            ]
            for edge in destinations:
                edge.seam = True
            if destinations:
                edited_meshes.append(target)
        api._flush(edited_meshes)
        return bool(edited_meshes)

    mirror = api.Handler(
        copy_marked_edges,
        "Copy selected seams to corresponding edges across the mesh X axis.",
        "選択したシームをメッシュのX軸反対側の対応辺にコピーします。",
    )
    return {
        "smart_uv_suite.seam_mirror": mirror,
        "smart_uv_suite.seam_symmetrize_symmetrize": mirror,
        "smart_uv_suite.seam_symmetrize": api.Handler(
            _symmetrize,
            "Mirror selected mesh geometry across the chosen axis.",
            "選択したメッシュ形状を指定軸で対称化します。",
        ),
    }
