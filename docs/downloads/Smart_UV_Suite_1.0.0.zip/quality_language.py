from __future__ import annotations
from . import resource_api_18168 as _suv_resource
from .quality_class_inventory import iter_suite_classes

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None

from . import quality_translation as _quality_i18n

_NAMESPACE = {}
_REGISTERED = []


def _tr(context, key: str, en: str, ja: str, **fmt) -> str:
    fn = _NAMESPACE.get('tr')
    text = None
    if callable(fn):
        try:
            text = fn(context, key, **fmt)
        except Exception:
            text = None
    if not text:
        text = en
    try:
        return text.format(**fmt)
    except Exception:
        return text


def _text_name(context) -> str:
    ws_fn = _NAMESPACE.get('_suv_ws')
    ws = ws_fn(context) if callable(ws_fn) else None
    name = getattr(ws, 'support_bundle_name', '') if ws else ''
    return (str(name).strip() or 'SUV_Support_Bundle') + '_Language_Coverage'


def _text_block(name: str, clear=False):
    textio = _NAMESPACE.get('_quality_textio_module')
    if textio is not None and hasattr(textio, 'ensure_report_text'):
        try:
            return textio.ensure_report_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if textio is not None and hasattr(textio, 'ensure_namespace_text'):
        try:
            return textio.ensure_namespace_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if bpy is None:
        return None
    txt = bpy.data.texts.get(name)
    if txt is None:
        if not clear:
            return None
        txt = bpy.data.texts.new(name)
    elif clear:
        txt.clear()
    return txt


def _iter_targets(namespace: dict):
    for name, value in iter_suite_classes(namespace):
        if not isinstance(value, type):
            continue
        if name.startswith('SUV_OT_') or name.startswith('SUV_PT_') or name.startswith('SUV_MT_') or name.startswith('SUV_PG_') or name.startswith('SUV_AddonPreferences'):
            yield name, value


def _is_weak_description(label: str, desc: str) -> bool:
    label = str(label or '').strip()
    desc = str(desc or '').strip()
    if not desc:
        return True
    if desc == label:
        return True
    if len(desc) < 18:
        return True
    generic_bits = (
        'Run this tool on the current UV selection',
        'Uses the current UV selection',
        'Open the latest UV Suite',
    )
    return any(bit in desc for bit in generic_bits)


def scan_language_coverage(namespace: dict) -> dict:
    translations = _quality_i18n.build_translation_entries(namespace) or {}
    rows = []
    translated_labels = 0
    bilingual_descriptions = 0
    weak_descriptions = 0
    total = 0
    for name, cls in _iter_targets(namespace):
        total += 1
        label = str(getattr(cls, 'bl_label', '') or name).strip()
        desc = str(getattr(cls, 'bl_description', '') or '').strip()
        kind = 'operator' if name.startswith('SUV_OT_') else ('panel' if name.startswith('SUV_PT_') else ('menu' if name.startswith('SUV_MT_') else ('property_group' if name.startswith('SUV_PG_') else 'preferences')))
        label_translated = bool(label) and (('*', label) in translations)
        desc_bilingual = ' / ' in desc and len(desc.split(' / ', 1)[0].strip()) > 0 and len(desc.split(' / ', 1)[1].strip()) > 0
        weak_desc = _is_weak_description(label, desc)
        if label_translated:
            translated_labels += 1
        if desc_bilingual:
            bilingual_descriptions += 1
        if weak_desc:
            weak_descriptions += 1
        rows.append({
            'name': name,
            'kind': kind,
            'label': label,
            'translated_label': label_translated,
            'bilingual_description': desc_bilingual,
            'weak_description': weak_desc,
            'description': desc,
            'idname': str(getattr(cls, 'bl_idname', '') or ''),
        })
    untranslated = [r for r in rows if not r['translated_label']]
    weak = [r for r in rows if r['weak_description']]
    result = {
        'total': total,
        'translated_labels': int(translated_labels),
        'untranslated_labels': int(max(0, total - translated_labels)),
        'bilingual_descriptions': int(bilingual_descriptions),
        'weak_descriptions': int(weak_descriptions),
        'tooltip_rich': int(max(0, total - weak_descriptions)),
        'translation_ratio': f"{translated_labels}/{total}" if total else '0/0',
        'tooltip_ratio': f"{max(0, total - weak_descriptions)}/{total}" if total else '0/0',
        'rows': rows,
        'missing_label_rows': untranslated[:50],
        'weak_description_rows': weak[:50],
    }
    namespace['_suv_language_coverage_last'] = result
    return result


class SUV_OT_quality_write_language_coverage(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_write_language_coverage'
    bl_label = 'Write Language Coverage'
    bl_description = 'Write a translation and tooltip coverage report so you can see which labels already translate well and which items still need stronger bilingual help text. / 翻訳とツールチップ対応のレポートを書き出し、どのラベルが十分に翻訳されているか、どの項目に英日説明の強化が必要かを確認できるようにします。'
    bl_options = set()

    open_after_write: bpy.props.BoolProperty(
        name='Open After Write',
        description='Open the written language coverage report in Blender Text Editor when possible / 可能なら書き出した言語対応レポートを Blender テキストエディタで開きます',
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        data = scan_language_coverage(_NAMESPACE)
        txt = None
        lines = [
            'UV Suite Language & Tooltip Coverage',
            '',
            '[Summary]',
            f"Total UI targets: {data['total']}",
            f"Translated labels: {data['translated_labels']}/{data['total']}",
            f"Bilingual descriptions: {data['bilingual_descriptions']}/{data['total']}",
            f"Rich tooltips: {data['tooltip_rich']}/{data['total']}",
            f"Weak descriptions: {data['weak_descriptions']}",
            '',
            '[Priority follow-up]',
            '- Strengthen labels first when an action is visible in the main visual cards or common decks.',
            '- Strengthen descriptions first when a tool appears in repair, setup, maintenance, or export flows.',
            '- Keep descriptions action-oriented: when to use the tool, what it changes, and what to verify after it runs.',
            '',
            '[Missing label translations]',
        ]
        missing = data.get('missing_label_rows', []) or []
        if missing:
            for row in missing[:30]:
                lines.append(f"- {row['label']} :: {row['idname'] or row['name']}")
        else:
            lines.append('- None detected in the current scan.')
        lines.extend(['', '[Weak descriptions]'])
        weak = data.get('weak_description_rows', []) or []
        if weak:
            for row in weak[:30]:
                lines.append(f"- {row['label']} :: {row['idname'] or row['name']}")
                lines.append(f"  {row['description'] or '-'}")
        else:
            lines.append('- None detected in the current scan.')
        lines.extend([
            '',
            '[日本語メモ]',
            f"翻訳済みラベル: {data['translated_labels']}/{data['total']}",
            f"英日説明付き項目: {data['bilingual_descriptions']}/{data['total']}",
            f"詳しいツールチップ候補: {data['tooltip_rich']}/{data['total']}",
            '優先順位は、まずメインカードやよく使う項目のラベル翻訳、その次に修復・準備・保守・出力系の説明強化です。',
        ])
        textio = _NAMESPACE.get('_quality_textio_module')
        writer = getattr(textio, 'write_report_lines_consistent', None) if textio is not None else None
        if callable(writer):
            txt = writer(
                _NAMESPACE, context, _text_name, lines, _text_block, self,
                open_after_write=self.open_after_write,
                failed_key='msg.quality_language_open_failed',
                failed_en='Could not open language coverage: {name}',
                failed_ja='言語対応レポートを開けませんでした: {name}',
            )
            if txt is None:
                return {'CANCELLED'}
        else:
            txt = _text_block(_text_name(context), clear=True)
            if txt is None:
                return {'CANCELLED'}
            txt.write('\n'.join(lines))
            if self.open_after_write:
                opener = _NAMESPACE.get('_suv_open_text_in_editor')
                if callable(opener):
                    try:
                        opener(context, txt)
                    except Exception:
                        pass
        msg = _tr(context, 'msg.quality_language_written', 'Language coverage written: {name} ({translated}/{total} labels translated)', '言語対応レポートを書き出しました: {name}（翻訳済み {translated}/{total}）', name=txt.name, translated=data['translated_labels'], total=data['total'])
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class SUV_OT_quality_open_language_coverage(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_open_language_coverage'
    bl_label = 'Open Language Coverage'
    bl_description = 'Open the latest UV Suite language and tooltip coverage report in Blender Text Editor. / 最新の UV Suite 言語対応・ツールチップ対応レポートを Blender のテキストエディタで開きます。'
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        textio = _NAMESPACE.get('_quality_textio_module')
        if textio is not None and hasattr(textio, 'open_named_report_text_or_fallback'):
            return textio.open_named_report_text_or_fallback(
                _NAMESPACE, context, _text_name, self, _text_block,
                missing_key='msg.quality_language_missing',
                missing_en='No language coverage report exists yet.',
                missing_ja='言語対応レポートはまだ作成されていません。',
                opened_key='msg.quality_language_opened',
                opened_en='Opened language coverage: {name}',
                opened_ja='言語対応レポートを開きました: {name}',
            )
        txt = _text_block(_text_name(context), clear=False)
        if txt is None:
            self.report({'WARNING'}, _tr(context, 'msg.quality_language_missing', 'No language coverage report exists yet.', '言語対応レポートはまだ作成されていません。'))
            return {'CANCELLED'}
        opener = _NAMESPACE.get('_suv_open_text_in_editor')
        ok = False
        if callable(opener):
            try:
                ok, _err = opener(context, txt)
            except Exception:
                ok = False
        if not ok:
            self.report({'WARNING'}, _tr(context, 'msg.quality_language_open_failed', 'Could not open language coverage: {name}', '言語対応レポートを開けませんでした: {name}', name=txt.name))
            return {'CANCELLED'}
        msg = _tr(context, 'msg.quality_language_opened', 'Opened language coverage: {name}', '言語対応レポートを開きました: {name}', name=txt.name)
        self.report({'INFO'}, msg)
        return {'FINISHED'}



def register(namespace: dict):
    global _NAMESPACE
    _NAMESPACE = namespace if isinstance(namespace, dict) else {}
    if bpy is None:
        return []
    classes = [SUV_OT_quality_write_language_coverage, SUV_OT_quality_open_language_coverage]
    reg = []
    for cls in classes:
        try:
            _suv_resource.register_class(cls)
            reg.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = reg
    return reg


def unregister(namespace: dict | None = None):
    if bpy is None:
        return []
    removed = []
    for cls in reversed(list(_REGISTERED)):
        try:
            _suv_resource.unregister_class(cls)
            removed.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = []
    return removed
