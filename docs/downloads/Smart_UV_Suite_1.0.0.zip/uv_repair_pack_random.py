"""Fit selected UV islands into randomly chosen trim divisions."""

import json
import math
import random


def build_handlers(api):
    def run(context, op):
        payload = context.scene.get("SUV_PACK_DIVISIONS", "")
        divisions = json.loads(payload)["divisions"] if payload else []
        padding = op.padding
        trims = []
        for division in divisions:
            u0, v0, u1, v1 = division["bounds"]
            if all(math.isfinite(point) for point in (u0, v0, u1, v1)):
                if u1 - u0 > 2 * padding and v1 - v0 > 2 * padding:
                    trims.append((u0 + padding, v0 + padding, u1 - padding, v1 - padding))
        rows = api._edit_targets(context)
        sync = api._sync(context)
        islands = [(uv, info) for _, _, uv, info in api._all_islands(context, rows)
                   if info.width > 0 and info.height > 0
                   and any(api._face_selected(face, sync) for face in info.faces)]
        if not trims or not islands:
            api._warn(context, op, "Select UV islands and define valid trim divisions.",
                      "UVアイランドを選択し、有効なトリム区画を定義してください。")
            return False
        rng = random.Random(op.index if op.properties.is_property_set("index") else None)
        for uv, info in islands:
            u0, v0, u1, v1 = rng.choice(trims)
            scale = min((u1 - u0) / info.width, (v1 - v0) / info.height)
            center_u = (info.box[0] + info.box[2]) * 0.5
            center_v = (info.box[1] + info.box[3]) * 0.5
            for face in info.faces:
                for loop in face.loops:
                    point = loop[uv].uv
                    point.x = (u0 + u1) * 0.5 + (point.x - center_u) * scale
                    point.y = (v0 + v1) * 0.5 + (point.y - center_v) * scale
        api._flush(rows)
        return True

    return {"smart_uv_suite.pack_random_fit": api.Handler(
        run, "Fit each selected island into a randomly chosen trim division.",
        "選択した各アイランドをランダムに選んだトリム区画へ収めます。")}
