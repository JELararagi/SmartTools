# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Final seam-preservation guard for Smart UV Suite auto unwrap.

Automatic unwrap may need temporary internal cuts for Blender's unwrap solver,
but it must never leave user mesh seam settings changed.  This module is loaded
last and wraps every Smart UV auto-unwrap entry point with an exact seam
snapshot/restore guard.  It also removes the old selection-boundary seam write
from the strict UV face-scope preparation path.
"""
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

import bpy

try:
    import bmesh
except Exception:  # pragma: no cover - Blender runtime only
    bmesh = None

_PATCH_VERSION = "1.8.62"


def _context_from_args(args, fallback=None):
    for value in args or ():
        try:
            if hasattr(value, "scene") and hasattr(value, "window_manager"):
                return value
        except Exception:
            pass
    return fallback or bpy.context


def _mesh_objects_for_context(context=None, explicit=None):
    objs = []
    def add(obj):
        try:
            if obj is not None and getattr(obj, "type", "") == "MESH" and obj not in objs:
                objs.append(obj)
        except Exception:
            pass
    if explicit is not None:
        if isinstance(explicit, (list, tuple, set)):
            for obj in explicit:
                add(obj)
        else:
            add(explicit)
    ctx = context or bpy.context
    try:
        for obj in list(getattr(ctx, "objects_in_mode", []) or []):
            add(obj)
    except Exception:
        pass
    try:
        for obj in list(getattr(ctx, "selected_objects", []) or []):
            add(obj)
    except Exception:
        pass
    try:
        add(getattr(ctx, "active_object", None))
    except Exception:
        pass
    return objs


def _edge_seams_from_edit_mesh(obj):
    if bmesh is None:
        return None
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        bm.edges.ensure_lookup_table(); bm.edges.index_update()
        return {int(e.index): bool(getattr(e, "seam", False)) for e in bm.edges if int(e.index) >= 0}
    except Exception:
        return None


def _edge_seams_from_mesh(obj):
    try:
        return {int(e.index): bool(getattr(e, "use_seam", False)) for e in obj.data.edges}
    except Exception:
        try:
            return {int(e.index): bool(getattr(e, "seam", False)) for e in obj.data.edges}
        except Exception:
            return {}


def _snapshot(context=None, explicit=None):
    state = []
    for obj in _mesh_objects_for_context(context, explicit):
        seams = None
        try:
            if str(getattr(obj, "mode", "")) == "EDIT":
                seams = _edge_seams_from_edit_mesh(obj)
        except Exception:
            seams = None
        if seams is None:
            seams = _edge_seams_from_mesh(obj)
        try:
            state.append((obj, dict(seams or {})))
        except Exception:
            pass
    return state


def _restore(snapshot):
    changed = False
    for obj, seams in list(snapshot or []):
        try:
            if obj is None or getattr(obj, "type", "") != "MESH":
                continue
            if str(getattr(obj, "mode", "")) == "EDIT" and bmesh is not None:
                try:
                    bm = bmesh.from_edit_mesh(obj.data)
                    bm.edges.ensure_lookup_table(); bm.edges.index_update()
                    for e in bm.edges:
                        idx = int(e.index)
                        if idx in seams:
                            e.seam = bool(seams[idx])
                    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
                    changed = True
                    continue
                except Exception:
                    pass
            try:
                for e in obj.data.edges:
                    idx = int(e.index)
                    if idx in seams:
                        # Mesh edge uses use_seam in Object mode.
                        if hasattr(e, "use_seam"):
                            e.use_seam = bool(seams[idx])
                        else:
                            e.seam = bool(seams[idx])
                changed = True
            except Exception:
                pass
        except Exception:
            pass
    return changed


def _restore_later(snapshot):
    # One-shot timer only.  This catches deferred redraw/operator updates without
    # adding persistent background load.
    try:
        def _once():
            try:
                _restore(snapshot)
            except Exception:
                pass
            return None
        _suv_resource.timer_register(_once, first_interval=0.01)
    except Exception:
        pass


def _make_guarded(fn):
    if not callable(fn) or getattr(fn, "_sus_1862_seam_guarded", False):
        return fn
    def _wrapped(*args, **kwargs):
        ctx = _context_from_args(args, bpy.context)
        snap = _snapshot(ctx)
        g = globals()
        old_depth = int(g.get("_SUS_1862_AUTO_UNWRAP_DEPTH", 0) or 0)
        g["_SUS_1862_AUTO_UNWRAP_DEPTH"] = old_depth + 1
        try:
            return fn(*args, **kwargs)
        finally:
            try:
                _restore(snap)
                _restore_later(snap)
            finally:
                g["_SUS_1862_AUTO_UNWRAP_DEPTH"] = old_depth
    _wrapped.__name__ = getattr(fn, "__name__", "_sus_1862_wrapped")
    _wrapped.__doc__ = getattr(fn, "__doc__", None)
    _wrapped._sus_1862_seam_guarded = True
    return _wrapped


def _patch_prepare(ns):
    prev = ns.get("_sus_auto_unwrap_prepare_selection")
    if not callable(prev) or getattr(prev, "_sus_1862_no_boundary_seams", False):
        return
    def _prepare_no_boundary_seams(context, obj):
        snap = _snapshot(context, obj)
        state = prev(context, obj)
        try:
            _restore(snap)
        except Exception:
            pass
        try:
            if isinstance(state, dict):
                # Keep original seam state authoritative and prevent later code
                # from considering selection-boundary seams user-visible data.
                original = {}
                for saved_obj, seams in snap:
                    if saved_obj is obj:
                        original = dict(seams or {})
                        break
                if original:
                    state["seam_state"] = original
                state["boundary_edges"] = set()
                state["selection_boundary_seams_disabled"] = True
        except Exception:
            pass
        return state
    _prepare_no_boundary_seams.__name__ = getattr(prev, "__name__", "_sus_auto_unwrap_prepare_selection")
    _prepare_no_boundary_seams._sus_1862_no_boundary_seams = True
    ns["_sus_auto_unwrap_prepare_selection"] = _prepare_no_boundary_seams


def _patch_uv_layout_operator(ns):
    prev = ns.get("_sus_call_uv_layout_operator")
    if not callable(prev) or getattr(prev, "_sus_1862_uvop_guarded", False):
        return
    def _uvop_guarded(op_idname: str, **props):
        active = int(globals().get("_SUS_1862_AUTO_UNWRAP_DEPTH", 0) or 0) > 0
        snap = _snapshot(bpy.context) if active else None
        try:
            return prev(op_idname, **props)
        finally:
            if active and snap is not None:
                try:
                    _restore(snap)
                except Exception:
                    pass
    _uvop_guarded.__name__ = getattr(prev, "__name__", "_sus_call_uv_layout_operator")
    _uvop_guarded._sus_1862_uvop_guarded = True
    ns["_sus_call_uv_layout_operator"] = _uvop_guarded


def _patch_class_execute(ns, class_name: str):
    cls = ns.get(class_name)
    if cls is None:
        return
    try:
        prev = getattr(cls, "execute", None)
        if not callable(prev) or getattr(prev, "_sus_1862_seam_guarded", False):
            return
        def _exec(self, context):
            snap = _snapshot(context)
            try:
                return prev(self, context)
            finally:
                _restore(snap); _restore_later(snap)
        _exec._sus_1862_seam_guarded = True
        setattr(cls, "execute", _exec)
    except Exception:
        pass


def apply_all(ns: dict, context=None):
    ns["_SUS_1862_SEAM_GUARD_VERSION"] = _PATCH_VERSION
    _patch_prepare(ns)
    _patch_uv_layout_operator(ns)
    # Public auto-unwrap routing and all lower-level routes used by the UV Unwrap UI.
    for name in (
        "_sus_run_auto_unwrap_mode",
        "_sus_call_native_unwrap_for_mode",
        "_sus_call_smart_unwrap",
        "_sus_call_flat_mapping",
        "_sus_call_projection_mode",
        "_sus_direct_planar_projection",
        "_sus_direct_unitize_faces",
        "_sus_direct_connected_unwrap_projection",
    ):
        if callable(ns.get(name)):
            ns[name] = _make_guarded(ns.get(name))
    for class_name in (
        "SMARTUVSUITE_OT_unwrap_auto_action",
        "SMARTUVSUITE_OT_unwrap_auto_run",
        "SMARTUVSUITE_OT_smart_standard_core_unwrap",
    ):
        _patch_class_execute(ns, class_name)


def install(ns: dict):
    apply_all(ns, bpy.context)
