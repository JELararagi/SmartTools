"""Build the text reports requested by the Smart UV inspection tools."""

from collections import deque
from dataclasses import dataclass
import json
import re

import bpy

from .base import _suv_context_snapshot, _suv_load_json_data, _suv_tool_runtime_log_name


@dataclass(frozen=True)
class Report:
    label: str
    japanese: str
    reference: str | None = None
    event_topic: str | None = None


REPORTS = {
    "admission_gate_report": Report("Admission Gate Report", "実行ゲートレポート", "admission_gate_profiles", "admission"),
    "advisor_report": Report("Advisor Report", "アドバイザーレポート"),
    "benchmark_catalog": Report("Benchmark Catalog", "ベンチマークカタログ", "excellence_profiles"),
    "bridge_ledger": Report("Bridge Ledger", "ブリッジ台帳", event_topic="bridge"),
    "circuit_breaker_report": Report("Circuit Breaker Report", "サーキットブレーカーレポート", "circuit_breaker_profiles", "circuit"),
    "confidence_report": Report("Confidence Report", "信頼度レポート", "confidence_guard_profiles", "confidence"),
    "delta_report": Report("Delta Report", "差分レポート", "delta_contracts", "delta"),
    "execution_plan": Report("Execution Plan", "実行計画"),
    "failure_notebook": Report("Failure Notebook", "失敗ノート", event_topic="failure"),
    "glossary_report": Report("Glossary Report", "用語集レポート", "glossary_terms"),
    "integrity_guard_report": Report("Integrity Guard Report", "整合性ガードレポート", "integrity_guard_profiles", "integrity"),
    "postflight_report": Report("Postflight Report", "事後検証レポート", "postflight_contracts", "postflight"),
    "reference_inventory": Report("Reference Inventory", "参照インベントリ", "document_sync_matrix"),
    "repair_playbook_report": Report("Repair Playbook Report", "修復手順レポート", "repair_playbooks"),
    "stability_report": Report("Stability Report", "安定性レポート", "session_guard_profiles", ""),
}

_HEADER = re.compile(r"^\[[^\r\n]+\] (?P<severity>\w+) \| (?P<event>[^\r\n]*)")


def _events(text):
    header = None
    lines = []
    for line in text.splitlines(keepends=True):
        match = _HEADER.match(line)
        if match:
            if header:
                yield header, "".join(lines).strip()
            header = match
            lines = [line]
        elif header:
            lines.append(line)
    if header:
        yield header, "".join(lines).strip()


def _matches(header, topic):
    if topic == "failure":
        return header["severity"] in {"WARN", "ERROR"}
    return topic in header["event"].lower()


def _recent_events(context, topic):
    log = bpy.data.texts.get(_suv_tool_runtime_log_name(context))
    if log is None:
        return "No recorded events. / 記録されたイベントはありません。"
    recent = deque((body for header, body in _events(log.as_string()) if _matches(header, topic)), maxlen=50)
    return "\n\n".join(recent) or "No recorded events. / 記録されたイベントはありません。"


def _details(context):
    snapshot = _suv_context_snapshot(context)
    instruction = "Run the UV Inspector to check the active map. / UV インスペクターでアクティブなマップを確認してください。"
    if snapshot["object"] == "-":
        instruction = "Select a mesh. / メッシュを選択してください。"
    elif not snapshot["total_uv_maps"]:
        instruction = "Create a UV map. / UV マップを作成してください。"
    return (
        "Active object / アクティブオブジェクト: " + snapshot["object"],
        "Active UV map / アクティブ UV マップ: " + snapshot["active_uv"],
        instruction,
    )


def _serialized(value):
    return json.dumps(value, ensure_ascii=False, indent=2)


def _plan(operator):
    chosen = (operator.preset or "AUTO_UNWRAP_START").upper()
    catalog = _suv_load_json_data("plan_presets.json")
    return next((item for item in catalog.get("presets", ()) if item.get("key") == chosen), None)


def write_report(context, op, key):
    spec = REPORTS[key]
    sections = [f"{spec.label} / {spec.japanese}"]
    if spec.reference:
        data = _suv_load_json_data(spec.reference + ".json")
        if data:
            sections += ["", "Reference data / 同梱参照データ", _serialized(data)]
        else:
            sections.append("Reference data unavailable. / 同梱参照データを取得できません。")
    if spec.event_topic is not None:
        sections += ["", "Recorded runtime events / 記録された実行イベント", _recent_events(context, spec.event_topic)]
    if key == "advisor_report":
        sections.extend(_details(context))
    elif key == "benchmark_catalog":
        sections.append("Measured benchmark results unavailable. / 実測ベンチマーク結果はありません。")
    elif key == "execution_plan":
        chosen = _plan(op)
        if chosen is None:
            op.report({"WARNING"}, "Unknown execution plan preset. / 不明な実行計画プリセットです。")
            return False
        sections.append(_serialized(chosen))

    body = "\n".join(sections)
    for text in bpy.data.texts:
        if text.get("smart_uv_upgrade_report") == key:
            text.from_string(body)
            return True
    text = bpy.data.texts.new("Smart UV " + spec.label)
    text.from_string(body)
    text["smart_uv_upgrade_report"] = key
    text["smart_uv_report"] = True
    return True
