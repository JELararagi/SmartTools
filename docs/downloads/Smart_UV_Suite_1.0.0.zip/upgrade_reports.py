"""Read-only reports for the public upgrade commands."""

import json
import re

import bpy

from .base import _suv_context_snapshot, _suv_load_json_data, _suv_tool_runtime_log_name
from .quality_textio import write_text_lines


def _data(name):
    return _suv_load_json_data(name + '.json')


def _runtime_entries(context):
    text = bpy.data.texts.get(_suv_tool_runtime_log_name(context))
    body = text.as_string() if text else ''
    return [entry.strip() for entry in re.split(r'(?m)(?=^\[[^\r\n]+\] \w+ \| )', body)
            if re.match(r'^\[[^\r\n]+\] \w+ \| ', entry)]


def _event_header(entry):
    match = re.match(r'^\[[^\r\n]+\] (\w+) \| ([^\r\n]+)', entry)
    return match.group(1), match.group(2)


def _history(context, topic):
    entries = _runtime_entries(context)
    if topic == 'failure':
        entries = [entry for entry in entries if _event_header(entry)[0] in {'WARN', 'ERROR'}]
    elif topic:
        entries = [entry for entry in entries if topic in _event_header(entry)[1].lower()]
    return entries[-50:]


def _execution_plan(op):
    presets = _data('plan_presets').get('presets', [])
    key = (op.preset or 'AUTO_UNWRAP_START').upper()
    return next((preset for preset in presets if preset['key'] == key), None)


REPORTS = {
    'admission_gate_report': ('Admission Gate Report', '実行ゲートレポート', 'admission_gate_profiles', 'admission'),
    'advisor_report': ('Advisor Report', 'アドバイザーレポート', None, None),
    'benchmark_catalog': ('Benchmark Catalog', 'ベンチマークカタログ', 'excellence_profiles', None),
    'bridge_ledger': ('Bridge Ledger', 'ブリッジ台帳', None, 'bridge'),
    'circuit_breaker_report': ('Circuit Breaker Report', 'サーキットブレーカーレポート', 'circuit_breaker_profiles', 'circuit'),
    'confidence_report': ('Confidence Report', '信頼度レポート', 'confidence_guard_profiles', 'confidence'),
    'delta_report': ('Delta Report', '差分レポート', 'delta_contracts', 'delta'),
    'execution_plan': ('Execution Plan', '実行計画', None, None),
    'failure_notebook': ('Failure Notebook', '失敗ノート', None, 'failure'),
    'glossary_report': ('Glossary Report', '用語集レポート', 'glossary_terms', None),
    'integrity_guard_report': ('Integrity Guard Report', '整合性ガードレポート', 'integrity_guard_profiles', 'integrity'),
    'postflight_report': ('Postflight Report', '事後検証レポート', 'postflight_contracts', 'postflight'),
    'reference_inventory': ('Reference Inventory', '参照インベントリ', 'document_sync_matrix', None),
    'repair_playbook_report': ('Repair Playbook Report', '修復手順レポート', 'repair_playbooks', None),
    'stability_report': ('Stability Report', '安定性レポート', 'session_guard_profiles', ''),
}


def write_report(context, op, key):
    title, title_ja, resource, history = REPORTS[key]
    lines = [f'{title} / {title_ja}']
    if resource:
        data = _data(resource)
        if data:
            lines.extend(('', 'Reference data / 同梱参照データ', json.dumps(data, ensure_ascii=False, indent=2)))
        else:
            lines.append('Reference data unavailable. / 同梱参照データを取得できません。')
    if history is not None:
        lines.extend(('', 'Recorded runtime events / 記録された実行イベント'))
        entries = _history(context, history)
        lines.append('\n\n'.join(entries) if entries else 'No recorded events. / 記録されたイベントはありません。')
    if key == 'benchmark_catalog':
        lines.append('Measured benchmark results unavailable. / 実測ベンチマーク結果はありません。')
    elif key == 'advisor_report':
        state = _suv_context_snapshot(context)
        if state['object'] == '-':
            advice = 'Select a mesh. / メッシュを選択してください。'
        elif not state['total_uv_maps']:
            advice = 'Create a UV map. / UV マップを作成してください。'
        else:
            advice = 'Run the UV Inspector to check the active map. / UV インスペクターでアクティブなマップを確認してください。'
        lines.extend((f"Active object / アクティブオブジェクト: {state['object']}",
                      f"Active UV map / アクティブ UV マップ: {state['active_uv']}", advice))
    elif key == 'execution_plan':
        preset = _execution_plan(op)
        if preset is None:
            op.report({'WARNING'}, 'Unknown execution plan preset. / 不明な実行計画プリセットです。')
            return False
        lines.append(json.dumps(preset, ensure_ascii=False, indent=2))
    name = 'Smart UV ' + title
    text = next((item for item in bpy.data.texts if item.get('smart_uv_upgrade_report') == key), None)
    if text is None:
        text = bpy.data.texts.new(name)
        text['smart_uv_upgrade_report'] = key
        text['smart_uv_report'] = True
    text.clear()
    return write_text_lines(text, lines) is not None
