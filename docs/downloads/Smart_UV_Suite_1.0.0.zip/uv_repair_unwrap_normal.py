# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Run Blender's angle-based unwrap from the Smart UV command."""

import bpy

from .base import _UVOverride


def build_handlers(api):
    def unwrap(context, options):
        if context.mode != "EDIT_MESH":
            return False
        margin = options.padding if options.properties.is_property_set("padding") else 0.001
        with _UVOverride(context) as target:
            if target.kwargs:
                with context.temp_override(**target.kwargs):
                    command = bpy.ops.uv.unwrap
                    if command.poll():
                        result = command(margin=margin, method="ANGLE_BASED")
                        return "FINISHED" in result
        return False

    return {
        "smart_uv_suite.unwrap_normal": api.Handler(
            unwrap,
            "Unwrap the selected faces along seams using Blender's angle-based method.",
            "選択面をシームに沿って角度ベースで展開します。",
        ),
    }
