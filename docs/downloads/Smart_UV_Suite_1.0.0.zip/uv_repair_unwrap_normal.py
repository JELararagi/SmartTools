import bpy
from .base import _UVOverride


def _unwrap(context, op):
    if context.mode != 'EDIT_MESH':
        return False
    with _UVOverride(context) as override:
        if not override.kwargs:
            return False
        with context.temp_override(**override.kwargs):
            native = bpy.ops.uv.unwrap
            margin = op.padding if op.properties.is_property_set('padding') else .001
            return native.poll() and 'FINISHED' in native(method='ANGLE_BASED', margin=margin)


def build_handlers(api):
    return {
        'smart_uv_suite.unwrap_normal': api.Handler(_unwrap, "Run Blender's angle-based seam unwrap on selected faces.", '選択面をシームに沿って角度ベースで展開します。'),
    }
