# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Smart UV Suite 1.8.105 loop-selection and grouped-distribution fixes.

Final runtime layer for two behaviours reported after 1.8.104:

* UV Align > basic Loop Select must not fail on connected edge loops just
  because the loop bends.  The old fallback used a hard direction-dot threshold
  and could stop at curved topology.  This layer replaces that with a topology
  traversal that follows connected edges through vertices and only uses edge
  direction as a tie-breaker.
* UV Align > vertex grouped distribution (G↔ / G↕) must distribute each group
  by its group midpoint while moving the whole group rigidly.  It must not run
  point-by-point distribution inside each group, because that collapses or
  distorts the shape of the group.
"""
from __future__ import annotations

from collections import deque
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

import bpy

from . import uv_room_integrity_18103 as ri
from . import uv_multi_object_18104 as mo

_VERSION = (1, 8, 105)
_NS: Dict[str, Any] = {}
_PREV: Dict[str, Any] = {}
_GROUP_DISTRIBUTE_ACTIONS = {"DISTRIBUTE_H_GROUP", "DISTRIBUTE_V_GROUP"}
_GROUP_ACTIONS = {"ALIGN_H_GROUP", "ALIGN_V_GROUP", "DISTRIBUTE_H_GROUP", "DISTRIBUTE_V_GROUP"}
_EPS = 1.0e-12


def _s(value: Any) -> str:
    try:
        return str(value or "")
    except Exception:
        return ""


def _report(op: Any, level: str, message: str) -> None:
    try:
        op.report({level}, message)
    except Exception:
        pass


def _tr(context: Any, en: str, ja: str) -> str:
    return ri._tr(context, en, ja)


def _hidden(elem: Any) -> bool:
    try:
        return bool(getattr(elem, "hide", False))
    except Exception:
        return False


def _edge_faces(edge: Any) -> Set[Any]:
    try:
        return {f for f in (getattr(edge, "link_faces", None) or []) if not _hidden(f)}
    except Exception:
        return set()


def _edge_other(edge: Any, vert: Any) -> Optional[Any]:
    try:
        return edge.other_vert(vert)
    except Exception:
        try:
            verts = list(edge.verts)
            if verts and verts[0] is vert and len(verts) > 1:
                return verts[1]
            if len(verts) > 1 and verts[1] is vert:
                return verts[0]
        except Exception:
            pass
    return None


def _unit_vec_from_to(a: Any, b: Any) -> Optional[Tuple[float, float, float]]:
    try:
        co = b.co - a.co
        length = float(co.length)
        if length <= _EPS:
            return None
        return (float(co.x) / length, float(co.y) / length, float(co.z) / length)
    except Exception:
        return None


def _dot(a: Optional[Tuple[float, float, float]], b: Optional[Tuple[float, float, float]]) -> float:
    if a is None or b is None:
        return -2.0
    try:
        return float(a[0] * b[0] + a[1] * b[1] + a[2] * b[2])
    except Exception:
        return -2.0


def _candidate_next_edge(current: Any, at_vert: Any, visited: Set[Any]) -> Optional[Any]:
    """Return the next edge in a loop walk at ``at_vert``.

    Blender's edge-loop intent should not be blocked by a bent/curved chain.
    Candidate choice therefore prefers topological continuity first and only
    uses direction as a tie-breaker.  Edges that do not share a face with the
    current edge are preferred because they are the usual continuation through
    a quad vertex.  When that is unavailable, the straightest remaining edge is
    used so boundary and wire-like chains still work instead of failing.
    """
    try:
        linked = list(getattr(at_vert, "link_edges", None) or [])
    except Exception:
        linked = []
    candidates: List[Any] = []
    for cand in linked:
        if cand is current or cand in visited or _hidden(cand):
            continue
        candidates.append(cand)
    if not candidates:
        return None

    current_faces = _edge_faces(current)
    non_shared = [e for e in candidates if not (current_faces & _edge_faces(e))]
    pool = non_shared or candidates
    incoming_other = _edge_other(current, at_vert)
    incoming = _unit_vec_from_to(incoming_other, at_vert) if incoming_other is not None else None

    def score(edge: Any) -> Tuple[int, int, float, float, int]:
        # Higher is better.  non_shared is already preferred by pool, but keep a
        # stable component for direct use and audit readability.
        shared = bool(current_faces & _edge_faces(edge))
        other = _edge_other(edge, at_vert)
        outgoing = _unit_vec_from_to(at_vert, other) if other is not None else None
        straight = _dot(incoming, outgoing)
        try:
            face_count = len(_edge_faces(edge))
        except Exception:
            face_count = 0
        try:
            length = float(getattr(edge, "calc_length", lambda: 0.0)())
        except Exception:
            try:
                a, b = edge.verts
                length = float((b.co - a.co).length)
            except Exception:
                length = 0.0
        # prefer not sharing a face, prefer manifold-ish edges, prefer straight
        # continuation, then longer edges and lower index for deterministic ties.
        try:
            idx = -int(getattr(edge, "index", 0))
        except Exception:
            idx = 0
        return (0 if shared else 1, 1 if face_count <= 2 else 0, straight, length, idx)

    try:
        return max(pool, key=score)
    except Exception:
        return pool[0] if pool else None


def _walk_loop_from(seed: Any, start_vert: Any, out: Set[Any], limit: int = 100000) -> None:
    current = seed
    vert = start_vert
    steps = 0
    while current is not None and vert is not None and steps < limit:
        steps += 1
        nxt = _candidate_next_edge(current, vert, out)
        if nxt is None:
            break
        out.add(nxt)
        vert = _edge_other(nxt, vert)
        current = nxt


def _fallback_loop_18105(seed_edges: Set[Any]) -> Set[Any]:
    """Topology-first loop fallback without the old 0.90 direction threshold."""
    out: Set[Any] = set(e for e in (seed_edges or set()) if e is not None and not _hidden(e))
    limit = max(32, len(out) + sum(1 for e in list(out) for _ in getattr(e, "verts", []) or []) + 100000)
    for edge in list(out):
        try:
            verts = list(edge.verts)
        except Exception:
            verts = []
        for vert in verts[:2]:
            _walk_loop_from(edge, vert, out, limit=limit)
    return out


def _fallback_ring_18105(seed_edges: Set[Any]) -> Set[Any]:
    # Keep the established quad-opposite ring behaviour, but make it defensive.
    out: Set[Any] = set(e for e in (seed_edges or set()) if e is not None and not _hidden(e))
    q = deque(out)
    while q:
        edge = q.popleft()
        for face in _edge_faces(edge):
            try:
                edges = list(face.edges)
            except Exception:
                continue
            if len(edges) != 4:
                continue
            try:
                idx = edges.index(edge)
            except Exception:
                continue
            opp = edges[(idx + 2) % 4]
            if opp is not None and not _hidden(opp) and opp not in out:
                out.add(opp)
                q.append(opp)
    return out


def _seed_edges_from_selection(bm: Any, loops: Set[Any], edge_loops: Set[Any]) -> Set[Any]:
    seed_edges = {getattr(l, "edge", None) for l in (edge_loops or set())}
    seed_edges = {e for e in seed_edges if e is not None and not _hidden(e)}
    if seed_edges:
        return seed_edges
    # In UV sync or vertex-selection fallback states, an intended edge seed can
    # arrive as two selected endpoint loops instead of selected edge loops.  Use
    # edges whose both endpoint vertices are represented in the seed first;
    # otherwise fall back to edges touched by any selected loop.
    selected_verts = {getattr(l, "vert", None) for l in (loops or set()) if getattr(l, "vert", None) is not None}
    if selected_verts:
        both = set()
        try:
            for edge in bm.edges:
                if _hidden(edge):
                    continue
                verts = list(edge.verts)
                if len(verts) >= 2 and verts[0] in selected_verts and verts[1] in selected_verts:
                    both.add(edge)
        except Exception:
            both = set()
        if both:
            return both
    touched = {getattr(l, "edge", None) for l in (loops or set())}
    return {e for e in touched if e is not None and not _hidden(e)}


def _edge_loops_for_edges(bm: Any, selected_edges: Set[Any]) -> Set[Any]:
    out: Set[Any] = set()
    if not selected_edges:
        return out
    try:
        for face in bm.faces:
            if _hidden(face):
                continue
            for loop in face.loops:
                try:
                    if loop.edge in selected_edges:
                        out.add(loop)
                except Exception:
                    pass
    except Exception:
        pass
    return out


def _selection_loop_ring_18105(context: Any, obj: Any, bm: Any, uv_layer: Any, action: str, loops: Set[Any], edge_loops: Set[Any]):
    seed_edges = _seed_edges_from_selection(bm, loops, edge_loops)
    if not seed_edges:
        return set(), set(), set()
    action = _s(action).upper()
    selected_edges = _fallback_ring_18105(seed_edges) if action == "RING" else _fallback_loop_18105(seed_edges)
    out_edges = _edge_loops_for_edges(bm, selected_edges)
    mode = ri._uv_mode(context)
    if mode == "VERTEX":
        out_loops: Set[Any] = set(out_edges)
        for loop in list(out_edges):
            try:
                out_loops.add(loop.link_loop_next)
            except Exception:
                pass
        return out_loops, set(), set()
    if mode == "FACE":
        return set(), set(), {loop.face for loop in out_edges}
    return set(), out_edges, set()


def _point_axis_values(points: Sequence[Dict[str, Any]], axis_u: bool) -> List[float]:
    key = "u" if axis_u else "v"
    vals: List[float] = []
    for point in points or []:
        try:
            vals.append(float(point.get(key, 0.0)))
        except Exception:
            pass
    return vals


def _group_center(points: Sequence[Dict[str, Any]], axis_u: bool) -> float:
    vals = _point_axis_values(points, axis_u)
    if not vals:
        return 0.0
    return (min(vals) + max(vals)) * 0.5


def _shift_group(points: Sequence[Dict[str, Any]], axis_u: bool, delta: float) -> int:
    changed = 0
    if abs(float(delta)) <= _EPS:
        return 0
    for point in points or []:
        for rec in list(point.get("records") or []):
            try:
                uv = rec["loop"][rec["uv_layer"]].uv
                if axis_u:
                    uv.x = float(uv.x) + float(delta)
                    rec["u"] = float(rec.get("u", uv.x)) + float(delta)
                else:
                    uv.y = float(uv.y) + float(delta)
                    rec["v"] = float(rec.get("v", uv.y)) + float(delta)
                changed += 1
            except Exception:
                pass
        try:
            if axis_u:
                point["u"] = float(point.get("u", 0.0)) + float(delta)
            else:
                point["v"] = float(point.get("v", 0.0)) + float(delta)
        except Exception:
            pass
    return changed



def _trusted_selected_anchor_records(context: Any, obj: Any, bm: Any, uv_layer: Any, mode: str):
    """Return selected anchor records, falling back to raw live UV state.

    1.8.103 deliberately rejects suspicious all-selected caches.  That remains
    the default for ordinary basic selection.  Group distribution, however, must
    also work when the user intentionally selected every UV element in a group or
    in a small island.  If the guarded path returns no seed, this fallback reads
    only the current live BMesh flags and mesh flags; it still does not read or
    create hidden .uv_select_* mesh attributes.
    """
    try:
        recs, loops, edge_loops, faces = ri._selected_anchor_records(context, obj, bm, uv_layer, mode)
        if recs:
            return recs, loops, edge_loops, faces
    except Exception:
        pass
    loops: Set[Any] = set(); edge_loops: Set[Any] = set(); faces: Set[Any] = set()
    records: List[Dict[str, Any]] = []
    seen: Set[int] = set()

    def add_loop(loop: Any) -> None:
        try:
            key = id(loop)
            if key in seen:
                return
            seen.add(key)
            records.append(mo._make_record(obj, loop, uv_layer, True))
        except Exception:
            pass

    try:
        face_iter = [f for f in bm.faces if not _hidden(f)]
    except Exception:
        face_iter = []
    if mode == "FACE":
        for face in face_iter:
            selected = False
            try:
                selected = bool(getattr(face, "select", False))
            except Exception:
                selected = False
            try:
                selected = selected or bool(getattr(face, "uv_select", False))
            except Exception:
                pass
            try:
                selected = selected or all(ri._live_v(loop, uv_layer) for loop in face.loops)
            except Exception:
                pass
            if selected:
                faces.add(face)
                for loop in face.loops:
                    loops.add(loop); edge_loops.add(loop); add_loop(loop)
    elif mode == "EDGE":
        for face in face_iter:
            for loop in face.loops:
                selected = False
                try:
                    selected = bool(getattr(loop.edge, "select", False))
                except Exception:
                    selected = False
                try:
                    selected = selected or ri._live_e(loop, uv_layer)
                except Exception:
                    pass
                if selected:
                    edge_loops.add(loop); loops.add(loop); add_loop(loop)
                    try:
                        loops.add(loop.link_loop_next); add_loop(loop.link_loop_next)
                    except Exception:
                        pass
    else:
        for face in face_iter:
            for loop in face.loops:
                selected = False
                try:
                    selected = bool(getattr(loop.vert, "select", False))
                except Exception:
                    selected = False
                try:
                    selected = selected or ri._live_v(loop, uv_layer)
                except Exception:
                    pass
                if selected:
                    loops.add(loop); add_loop(loop)
    return records, loops, edge_loops, faces

def _execute_group_distribute_multi(self: Any, context: Any):
    raw = _s(getattr(self, "action", "ALIGN_CENTER")).upper() or "ALIGN_CENTER"
    # Only replace G↔ / G↕.  Other grouped align operations intentionally keep
    # their existing per-group shape-editing behaviour.
    if raw not in _GROUP_DISTRIBUTE_ACTIONS:
        prev = _PREV.get("vertex_execute")
        if callable(prev) and prev is not _execute_group_distribute_multi:
            return prev(self, context)
        return {"CANCELLED"}

    snap = ri._snapshot_modes(context)
    objs, state = mo._ensure_multi_edit(context)
    if not objs:
        _report(self, "WARNING", _tr(context, "No mesh object is active.", "アクティブなメッシュオブジェクトがありません。"))
        return {"CANCELLED"}
    try:
        mo._prepare_unwrap_channel(context)
        targets = mo._target_data(context)
        if not targets:
            _report(self, "WARNING", _tr(context, "No editable UV map is available.", "編集可能なUVマップがありません。"))
            return {"CANCELLED"}
        mode = ri._uv_mode(context)
        group_sources: List[List[Dict[str, Any]]] = []
        all_source_records: List[Dict[str, Any]] = []
        for obj, bm, uv_layer in targets:
            source_records, _loops, edge_loops, faces = _trusted_selected_anchor_records(context, obj, bm, uv_layer, mode)
            if not source_records:
                continue
            all_source_records.extend(source_records)
            try:
                groups = ri._source_groups_from_selection(context, obj, bm, uv_layer, mode, source_records, edge_loops, faces)
            except Exception:
                groups = []
            if groups:
                group_sources.extend(groups)
            else:
                group_sources.append(source_records)

        if len(group_sources) <= 1:
            _report(self, "WARNING", _tr(context, "At least two selected UV groups are required for grouped distribution.", "グループごとの等間隔には2つ以上の選択UVグループが必要です。"))
            return {"CANCELLED"}

        sticky = ri._sticky_mode(context)
        followers = mo._all_followers_multi(targets, sticky)
        all_selected_ids = {id(r.get("loop")) for r in all_source_records}
        axis_u = raw == "DISTRIBUTE_H_GROUP"
        prepared: List[Dict[str, Any]] = []
        for source_group in group_sources:
            points = mo._pointify_multi(source_group, sticky, followers, all_selected_ids)
            if not points:
                continue
            prepared.append({"points": points, "center": _group_center(points, axis_u)})
        if len(prepared) <= 1:
            _report(self, "WARNING", _tr(context, "At least two selected UV groups are required for grouped distribution.", "グループごとの等間隔には2つ以上の選択UVグループが必要です。"))
            return {"CANCELLED"}

        ordered = sorted(prepared, key=lambda item: float(item.get("center", 0.0)))
        start = float(ordered[0]["center"]); end = float(ordered[-1]["center"])
        if abs(end - start) <= _EPS:
            _report(self, "WARNING", _tr(context, "Grouped distribution needs a non-zero span between group centers.", "グループごとの等間隔にはグループ中点間の幅が必要です。"))
            return {"CANCELLED"}
        step = (end - start) / float(max(1, len(ordered) - 1))
        changed = 0
        for index, item in enumerate(ordered):
            target = start + step * index
            current = float(item.get("center", 0.0))
            changed += _shift_group(item.get("points") or [], axis_u, target - current)
        if changed <= 0:
            _report(self, "WARNING", _tr(context, "Grouped distribution did not change the selection.", "グループごとの等間隔で変更される選択がありませんでした。"))
            return {"CANCELLED"}
        mo._update_meshes(targets)
        try:
            if getattr(context, "area", None) is not None:
                context.area.tag_redraw()
        except Exception:
            pass
        return {"FINISHED"}
    except Exception as exc:
        _report(self, "WARNING", _tr(context, "Grouped distribution failed.", "グループごとの等間隔に失敗しました。") + f" {exc}")
        return {"CANCELLED"}
    finally:
        ri._restore_modes(snap)
        mo._restore_multi_edit(context, state)
        ri._restore_modes(snap)


def _patch_selection_loop_ring() -> None:
    try:
        ri._fallback_loop = _fallback_loop_18105  # type: ignore[attr-defined]
        ri._fallback_ring = _fallback_ring_18105  # type: ignore[attr-defined]
        ri._selection_loop_ring = _selection_loop_ring_18105  # type: ignore[attr-defined]
    except Exception:
        pass


def _patch_vertex_operator(ns: Dict[str, Any]) -> None:
    cls = ns.get("SMARTUVSUITE_OT_vertex_align_action") if isinstance(ns, dict) else None
    if not isinstance(cls, type):
        return
    current = getattr(cls, "execute", None)
    if getattr(current, "_sus_18105_group_distribute", False):
        return
    if "vertex_execute" not in _PREV and callable(current):
        _PREV["vertex_execute"] = current
    try:
        _execute_group_distribute_multi._sus_18105_group_distribute = True  # type: ignore[attr-defined]
        _execute_group_distribute_multi._sus_18104_multi = True  # type: ignore[attr-defined]
    except Exception:
        pass
    try:
        cls.execute = _execute_group_distribute_multi
    except Exception:
        pass


def _mark_version(ns: Dict[str, Any]) -> None:
    try:
        info = ns.get("bl_info")
        if not isinstance(info, dict):
            info = {}
            ns["bl_info"] = info
        info.update({
            "name": "Smart UV Suite",
            "author": "JELararagi",
            "version": (1, 0, 0),
            "blender": (5, 1, 0),
            "location": "View3D / UV Editor > Sidebar > Smart UV",
            "description": "Smart UV Suite exposes UV editing tools in the Smart UV sidebar.",
            "category": "Smart UV",
        })
        ns["_SUS_BL_INFO_FALLBACK"] = dict(info)
        ns["__version__"] = '1.0.0'
    except Exception:
        pass


def _wrap_sync(ns: Dict[str, Any]) -> None:
    if not isinstance(ns, dict):
        return
    base = ns.get("_sus_1652_sync_keymaps_from_workspace")
    if getattr(base, "_sus_18105_sync", False):
        return
    if "sync" not in _PREV and callable(base):
        _PREV["sync"] = base
    base = _PREV.get("sync")

    def _sync_18105(context=None):
        ctx = context or getattr(bpy, "context", None)
        if callable(base) and base is not _sync_18105:
            try:
                base(ctx)
            except TypeError:
                try:
                    base()
                except Exception:
                    pass
            except RecursionError:
                pass
            except Exception:
                pass
        try:
            apply_all(ns, ctx)
        except RecursionError:
            pass
        except Exception:
            pass

    try:
        _sync_18105._sus_18105_sync = True  # type: ignore[attr-defined]
    except Exception:
        pass
    try:
        ns["_sus_1652_sync_keymaps_from_workspace"] = _sync_18105
    except Exception:
        pass


def apply_all(ns: Optional[Dict[str, Any]] = None, context: Any = None) -> None:
    global _NS
    if isinstance(ns, dict):
        _NS = ns
    elif not _NS:
        import sys
        mod = sys.modules.get(__package__)
        if mod is not None:
            _NS = getattr(mod, "__dict__", {})
    target = _NS if isinstance(_NS, dict) else {}
    if not target:
        return
    try:
        mo.apply_all(target, context or getattr(bpy, "context", None))
    except Exception:
        pass
    _patch_selection_loop_ring()
    _patch_vertex_operator(target)
    _wrap_sync(target)
    _mark_version(target)


def install(ns: Optional[Dict[str, Any]] = None, context: Any = None) -> None:
    apply_all(ns, context or getattr(bpy, "context", None))


def unregister() -> None:
    try:
        prev = _PREV.get("vertex_execute")
        cls = _NS.get("SMARTUVSUITE_OT_vertex_align_action") if isinstance(_NS, dict) else None
        if isinstance(cls, type) and callable(prev):
            cls.execute = prev
    except Exception:
        pass


def audit(context: Any = None) -> Dict[str, Any]:
    checks: Dict[str, Any] = {}
    try:
        checks.update(mo.audit(context or getattr(bpy, "context", None)))
    except Exception:
        pass
    checks["version"] = (1, 0, 0)
    checks["loop_selection_18105"] = bool(getattr(ri._selection_loop_ring, "__name__", "") == "_selection_loop_ring_18105")
    try:
        cls = _NS.get("SMARTUVSUITE_OT_vertex_align_action") if isinstance(_NS, dict) else None
        checks["group_distribute_execute_18105"] = bool(getattr(getattr(cls, "execute", None), "_sus_18105_group_distribute", False))
    except Exception:
        checks["group_distribute_execute_18105"] = False
    return checks
