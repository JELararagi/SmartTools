# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Ultra-light final interaction layer for Immediate Select / UV Gizmo Grip.

This layer is intentionally loaded last.  It keeps the 1.8.43 behavior but
removes the broad Window/Generic instant keymap path and avoids full selected-UV
BMesh scans unless a real gizmo handle has to be gripped.  It also records U/V
axis grip modes immediately so Axis Constraint Memory works with direct
Immediate Select drags.
"""
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

from math import cos, sin, atan2
import time
import bpy
from mathutils import Vector

_PG = None
_INSTALLED = False
_PREV_SYNC = None
_ORIG_AXIS_TIMER_UPDATE = None
_GIZMO_CACHE = {"key": None, "stats": None, "batches": None, "pivot_uv": None, "pivot_region": None, "stamp": 0.0}
_DIRECT_AXIS_STAMP = 0.0
_DIRECT_AXIS_TTL = 4.0

# Keep Immediate Select out of Window and Generic Gizmo maps.  It should own UV
# element PRESS events, not native gizmo U/V axis handles.
_INSTANT_KEYMAP_DEFS = (
    ("UV Editor", "EMPTY"),
    ("Image", "IMAGE_EDITOR"),
)
_GIZMO_KEYMAP_NAMES = (
    ("Generic Gizmo", "EMPTY"),
    ("Generic Gizmo Maybe Drag", "EMPTY"),
)


def _pg(name, default=None):
    try:
        return _PG.get(name, default) if isinstance(_PG, dict) else default
    except Exception:
        return default


def _is_uv_context(context) -> bool:
    try:
        area = getattr(context, "area", None)
        region = getattr(context, "region", None)
        space = getattr(context, "space_data", None)
        if area is None or str(getattr(area, "type", "")) != "IMAGE_EDITOR":
            return False
        if region is None or str(getattr(region, "type", "")) != "WINDOW":
            return False
        if space is None:
            return False
        return str(getattr(space, "ui_type", "") or getattr(space, "mode", "")).upper() in {"UV", "UV_EDITOR"} or str(getattr(space, "mode", "")).upper() == "UV"
    except Exception:
        return False


def _iter_edit_mesh_objects(context):
    try:
        objs = getattr(context, "objects_in_mode_unique_data", None)
        if objs:
            for obj in objs:
                if getattr(obj, "type", None) == "MESH" and getattr(obj, "mode", None) == "EDIT":
                    yield obj
            return
    except Exception:
        pass
    try:
        obj = getattr(context, "edit_object", None) or getattr(context, "object", None)
        if obj is not None and getattr(obj, "type", None) == "MESH" and getattr(obj, "mode", None) == "EDIT":
            yield obj
    except Exception:
        return


def _uv_mode(context) -> str:
    try:
        raw = getattr(getattr(context, "tool_settings", None), "uv_select_mode", "VERTEX")
        if isinstance(raw, (set, list, tuple)):
            raw = " ".join(str(v) for v in raw)
        raw = str(raw or "VERTEX").upper()
    except Exception:
        raw = "VERTEX"
    if "ISLAND" in raw:
        return "ISLAND"
    if "FACE" in raw:
        return "FACE"
    if "EDGE" in raw:
        return "EDGE"
    return "VERTEX"


def _region_to_uv(context, event):
    try:
        v2d = context.region.view2d
        x, y = v2d.region_to_view(float(event.mouse_region_x), float(event.mouse_region_y))
        return Vector((float(x), float(y)))
    except Exception:
        fn = _pg("_sus_1835_region_to_uv")
        try:
            return fn(context, event) if callable(fn) else None
        except Exception:
            return None


def _uv_to_region(context, uv):
    try:
        x, y = context.region.view2d.view_to_region(float(uv.x), float(uv.y), clip=False)
        return Vector((float(x), float(y)))
    except Exception:
        return None


def _uv_tolerance(context, pixels=10.0) -> float:
    try:
        v2d = context.region.view2d
        x = float(getattr(context.region, "width", 1024) or 1024) * 0.5
        y = float(getattr(context.region, "height", 768) or 768) * 0.5
        a = Vector(v2d.region_to_view(x, y))
        b = Vector(v2d.region_to_view(x + float(pixels), y))
        c = Vector(v2d.region_to_view(x, y + float(pixels)))
        return max((b - a).length, (c - a).length, 1.0e-9)
    except Exception:
        fn = _pg("_sus_1835_uv_tolerance")
        try:
            return float(fn(context, pixels)) if callable(fn) else 1.0e-3
        except Exception:
            return 1.0e-3


def _point_segment_distance(pt, a, b):
    ab = b - a
    denom = float(ab.length_squared)
    if denom <= 1.0e-20:
        return float((pt - a).length), 0.0
    t = max(0.0, min(1.0, float((pt - a).dot(ab) / denom)))
    closest = a + ab * t
    return float((pt - closest).length), t


def _point_in_poly(pt, coords) -> bool:
    try:
        inside = False
        n = len(coords)
        if n < 3:
            return False
        x = float(pt.x); y = float(pt.y)
        j = n - 1
        for i in range(n):
            xi = float(coords[i].x); yi = float(coords[i].y)
            xj = float(coords[j].x); yj = float(coords[j].y)
            if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / ((yj - yi) or 1.0e-20) + xi):
                inside = not inside
            j = i
        return inside
    except Exception:
        return False


def _luv(loop, uv_layer):
    try:
        return loop[uv_layer]
    except Exception:
        return None


def _get_v(loop, uv_layer) -> bool:
    try:
        if bool(getattr(loop, "uv_select_vert", False)):
            return True
    except Exception:
        pass
    luv = _luv(loop, uv_layer)
    if luv is not None:
        for name in ("select_vert", "select"):
            try:
                if bool(getattr(luv, name, False)):
                    return True
            except Exception:
                pass
    return False


def _get_e(loop, uv_layer) -> bool:
    try:
        if bool(getattr(loop, "uv_select_edge", False)):
            return True
    except Exception:
        pass
    luv = _luv(loop, uv_layer)
    if luv is not None:
        try:
            return bool(getattr(luv, "select_edge", False))
        except Exception:
            pass
    return False


def _get_f(face) -> bool:
    try:
        if bool(getattr(face, "uv_select", False)):
            return True
    except Exception:
        pass
    return False


def _set_v(loop, uv_layer, value: bool) -> None:
    try:
        setter = getattr(loop, "uv_select_vert_set", None)
        if callable(setter):
            setter(bool(value))
    except Exception:
        pass
    luv = _luv(loop, uv_layer)
    if luv is not None:
        for name in ("select_vert", "select"):
            try:
                setattr(luv, name, bool(value))
            except Exception:
                pass


def _set_e(loop, uv_layer, value: bool) -> None:
    try:
        setter = getattr(loop, "uv_select_edge_set", None)
        if callable(setter):
            setter(bool(value))
    except Exception:
        pass
    luv = _luv(loop, uv_layer)
    if luv is not None:
        try:
            setattr(luv, "select_edge", bool(value))
        except Exception:
            pass


def _set_f(face, value: bool) -> None:
    try:
        setter = getattr(face, "uv_select_set", None)
        if callable(setter):
            setter(bool(value)); return
    except Exception:
        pass
    try:
        setattr(face, "uv_select", bool(value))
    except Exception:
        pass


def _uv_close(a, b, eps=1.0e-7) -> bool:
    try:
        return abs(float(a.x) - float(b.x)) <= eps and abs(float(a.y) - float(b.y)) <= eps
    except Exception:
        return False


def _segment_close(a0, a1, b0, b1, eps=1.0e-7) -> bool:
    return (_uv_close(a0, b0, eps) and _uv_close(a1, b1, eps)) or (_uv_close(a0, b1, eps) and _uv_close(a1, b0, eps))


def _face_index(face, fallback: int) -> int:
    try:
        i = int(getattr(face, "index", -1))
        return i if i >= 0 else int(fallback)
    except Exception:
        return int(fallback)


def _loop_local(face, loop, fallback: int = 0) -> int:
    try:
        return tuple(face.loops).index(loop)
    except Exception:
        return int(fallback)


def _add_record(records, seen, mesh, uv_name, face, loop, uv_layer, face_fallback=0, local_fallback=0):
    try:
        fi = _face_index(face, face_fallback)
        li = _loop_local(face, loop, local_fallback)
        key = (id(mesh), fi, li)
        if key in seen:
            return
        seen.add(key)
        records.append((fi, li, loop[uv_layer].uv.copy()))
    except Exception:
        pass


def _build_batches_from_records(record_map):
    batches = []
    total = 0
    sum_uv = Vector((0.0, 0.0))
    min_uv = Vector((float("inf"), float("inf")))
    max_uv = Vector((float("-inf"), float("-inf")))
    for (mesh, uv_name), loops in record_map.items():
        if not loops:
            continue
        batches.append({"mesh": mesh, "uv_layer_name": uv_name, "loops": loops})
        for _fi, _li, uv in loops:
            sum_uv += uv
            min_uv.x = min(min_uv.x, uv.x); min_uv.y = min(min_uv.y, uv.y)
            max_uv.x = max(max_uv.x, uv.x); max_uv.y = max(max_uv.y, uv.y)
            total += 1
    if total <= 0:
        return [], None
    stats = {"median": sum_uv / float(total), "bbox_center": Vector(((min_uv.x + max_uv.x) * 0.5, (min_uv.y + max_uv.y) * 0.5)), "count": total}
    return batches, stats


def _clear_uv_selection_fast(context):
    # Prefer Blender's native C operator for global deselect.  It is much faster
    # than Python-clearing every loop on heavy multi-object edits.  If it fails,
    # fall back to BMesh only for visible edit objects.
    try:
        bpy.ops.uv.select_all(action='DESELECT')
        return True
    except Exception:
        pass
    try:
        import bmesh
    except Exception:
        return False
    meshes = []
    for obj in _iter_edit_mesh_objects(context):
        mesh = getattr(obj, "data", None)
        if mesh is None:
            continue
        try:
            bm = bmesh.from_edit_mesh(mesh)
            uv_layer = bm.loops.layers.uv.active
            if uv_layer is None:
                continue
            for f in bm.faces:
                _set_f(f, False)
                for l in f.loops:
                    _set_v(l, uv_layer, False)
                    _set_e(l, uv_layer, False)
            meshes.append(mesh)
        except Exception:
            continue
    for mesh in meshes:
        try:
            bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        except TypeError:
            try: bmesh.update_edit_mesh(mesh)
            except Exception: pass
        except Exception:
            pass
    return bool(meshes)


def _read_bool_attr(mesh, name: str, length_hint: int):
    try:
        attrs = getattr(mesh, "attributes", None)
        attr = attrs.get(name) if attrs is not None else None
        if attr is None:
            return None
        data = getattr(attr, "data", None)
        n = min(int(length_hint), len(data))
        if n <= 0:
            return None
        vals = [False] * n
        try:
            data.foreach_get("value", vals)
            return vals
        except Exception:
            return [bool(getattr(data[i], "value", False)) for i in range(n)]
    except Exception:
        return None


def _fast_collect_selected_uv_state(context, anchor_uv=None):
    """Collect selected UV loops with attribute-first fast path.

    This is still exact for the current UV selection domain, but avoids mode
    toggles, index updates and full BMesh traversal when Blender exposes the
    5.1 UV selection attributes.
    """
    try:
        import bmesh
    except Exception:
        return [], None
    mode = _uv_mode(context)
    record_map = {}
    seen = set()

    # Attribute-fast path: selected loop indices can be read from Mesh data.
    any_attr = False
    for obj in _iter_edit_mesh_objects(context):
        mesh = getattr(obj, "data", None)
        if mesh is None:
            continue
        loops_len = len(getattr(mesh, "loops", []) or [])
        polys = list(getattr(mesh, "polygons", []) or [])
        if loops_len <= 0 or not polys:
            continue
        try:
            bm = bmesh.from_edit_mesh(mesh)
            bm.faces.ensure_lookup_table()
            uv_layer = bm.loops.layers.uv.active
            if uv_layer is None:
                continue
            uv_name = str(getattr(uv_layer, "name", "") or "")
        except Exception:
            continue
        selected_loop_indices = set()
        if mode in {"FACE", "ISLAND"}:
            fflags = _read_bool_attr(mesh, ".uv_select_face", len(polys))
            if fflags is not None:
                for pi, selected in enumerate(fflags):
                    if not selected or pi >= len(polys):
                        continue
                    p = polys[pi]
                    for li in range(int(p.loop_start), int(p.loop_start) + int(p.loop_total)):
                        selected_loop_indices.add(li)
        elif mode == "EDGE":
            eflags = _read_bool_attr(mesh, ".uv_select_edge", loops_len)
            if eflags is not None:
                selected_loop_indices.update(i for i, v in enumerate(eflags) if v)
        else:
            vflags = _read_bool_attr(mesh, ".uv_select_vert", loops_len)
            if vflags is not None:
                selected_loop_indices.update(i for i, v in enumerate(vflags) if v)
        if not selected_loop_indices:
            continue
        any_attr = True
        # Map Mesh loop indices to BMesh face/local loops.  This is linear in face
        # count, not loop count, and only executed for meshes with any selected
        # loops in the active UV domain.
        by_loop_index = set(selected_loop_indices)
        recs = record_map.setdefault((mesh, uv_name), [])
        for fi, f in enumerate(bm.faces):
            if getattr(f, "hide", False):
                continue
            face_loops = tuple(f.loops)
            for local, l in enumerate(face_loops):
                try:
                    li = int(getattr(l, "index", -1))
                except Exception:
                    li = -1
                if li in by_loop_index:
                    _add_record(recs, seen, mesh, uv_name, f, l, uv_layer, fi, local)
                    if mode == "EDGE":
                        # Add the next endpoint of each selected UV edge.
                        try:
                            _add_record(recs, seen, mesh, uv_name, f, l.link_loop_next, uv_layer, fi, (local + 1) % len(face_loops))
                        except Exception:
                            pass
    if any_attr:
        batches, stats = _build_batches_from_records(record_map)
        if batches:
            return batches, stats

    # Fallback: live BMesh selection.  This is exact but intentionally avoids
    # expensive index_update calls.
    record_map = {}
    seen = set()
    for obj in _iter_edit_mesh_objects(context):
        mesh = getattr(obj, "data", None)
        if mesh is None:
            continue
        try:
            bm = bmesh.from_edit_mesh(mesh)
            bm.faces.ensure_lookup_table()
            uv_layer = bm.loops.layers.uv.active
            if uv_layer is None:
                continue
            uv_name = str(getattr(uv_layer, "name", "") or "")
        except Exception:
            continue
        recs = record_map.setdefault((mesh, uv_name), [])
        for fi, f in enumerate(bm.faces):
            if getattr(f, "hide", False):
                continue
            face_selected = _get_f(f)
            for local, l in enumerate(tuple(f.loops)):
                if mode in {"FACE", "ISLAND"}:
                    selected = face_selected
                elif mode == "EDGE":
                    selected = _get_e(l, uv_layer)
                else:
                    selected = _get_v(l, uv_layer)
                if not selected:
                    continue
                _add_record(recs, seen, mesh, uv_name, f, l, uv_layer, fi, local)
                if mode == "EDGE":
                    try:
                        _add_record(recs, seen, mesh, uv_name, f, l.link_loop_next, uv_layer, fi, (local + 1) % len(tuple(f.loops)))
                    except Exception:
                        pass
    return _build_batches_from_records(record_map)


def _find_hit_fast(context, event):
    if not _is_uv_context(context):
        return None
    mouse_uv = _region_to_uv(context, event)
    if mouse_uv is None:
        return None
    mode = _uv_mode(context)
    tol = _uv_tolerance(context, 10.0)
    tol2 = tol * tol
    best = None
    best_d = float("inf")
    try:
        import bmesh
    except Exception:
        return None
    for obj in _iter_edit_mesh_objects(context):
        mesh = getattr(obj, "data", None)
        if mesh is None:
            continue
        try:
            bm = bmesh.from_edit_mesh(mesh)
            bm.faces.ensure_lookup_table()
            uv_layer = bm.loops.layers.uv.active
            if uv_layer is None:
                continue
            uv_name = str(getattr(uv_layer, "name", "") or "")
        except Exception:
            continue
        if mode == "VERTEX":
            for fi, f in enumerate(bm.faces):
                if getattr(f, "hide", False):
                    continue
                for local, l in enumerate(tuple(f.loops)):
                    try:
                        if getattr(l.vert, "hide", False) or getattr(l.edge, "hide", False):
                            continue
                        uv = l[uv_layer].uv
                        dx = float(uv.x - mouse_uv.x); dy = float(uv.y - mouse_uv.y)
                        if abs(dx) > tol or abs(dy) > tol:
                            continue
                        d2 = dx * dx + dy * dy
                        if d2 <= tol2 and d2 < best_d:
                            best_d = d2
                            best = {"mode": "VERTEX", "mesh": mesh, "uv_layer_name": uv_name, "uv": uv.copy(), "face": _face_index(f, fi), "local": local, "vert": l.vert}
                    except Exception:
                        continue
        elif mode == "EDGE":
            for fi, f in enumerate(bm.faces):
                if getattr(f, "hide", False):
                    continue
                loops = tuple(f.loops)
                for local, l in enumerate(loops):
                    try:
                        a = l[uv_layer].uv; b = l.link_loop_next[uv_layer].uv
                        if (mouse_uv.x < min(a.x, b.x) - tol or mouse_uv.x > max(a.x, b.x) + tol or
                                mouse_uv.y < min(a.y, b.y) - tol or mouse_uv.y > max(a.y, b.y) + tol):
                            continue
                        d, t = _point_segment_distance(mouse_uv, a, b)
                        if d <= tol and d < best_d:
                            best_d = d
                            best = {"mode": "EDGE", "mesh": mesh, "uv_layer_name": uv_name, "uv": a.lerp(b, t), "face": _face_index(f, fi), "local": local, "edge": l.edge, "a": a.copy(), "b": b.copy()}
                    except Exception:
                        continue
        else:
            for fi, f in enumerate(bm.faces):
                if getattr(f, "hide", False):
                    continue
                try:
                    coords = [l[uv_layer].uv.copy() for l in f.loops]
                    minx = min(p.x for p in coords); maxx = max(p.x for p in coords)
                    miny = min(p.y for p in coords); maxy = max(p.y for p in coords)
                    if mouse_uv.x < minx or mouse_uv.x > maxx or mouse_uv.y < miny or mouse_uv.y > maxy:
                        continue
                    if not _point_in_poly(mouse_uv, coords):
                        continue
                    area = abs(sum(coords[i].x * coords[(i + 1) % len(coords)].y - coords[(i + 1) % len(coords)].x * coords[i].y for i in range(len(coords))))
                    d = area if area > 0.0 else 0.0
                    if best is None or d < best_d:
                        best_d = d
                        best = {"mode": mode, "mesh": mesh, "uv_layer_name": uv_name, "uv": mouse_uv.copy(), "face": _face_index(f, fi), "local": 0}
                except Exception:
                    continue
    return best


def _hit_selected_fast(context, hit) -> bool:
    if not hit:
        return False
    try:
        import bmesh
        mesh = hit.get("mesh")
        bm = bmesh.from_edit_mesh(mesh)
        bm.faces.ensure_lookup_table()
        uv_layer = bm.loops.layers.uv.active
        if uv_layer is None:
            return False
        f = bm.faces[int(hit.get("face", -1))]
        l = tuple(f.loops)[int(hit.get("local", 0))]
        mode = str(hit.get("mode") or _uv_mode(context)).upper()
        if mode == "VERTEX":
            return _get_v(l, uv_layer)
        if mode == "EDGE":
            return _get_e(l, uv_layer)
        return _get_f(f)
    except Exception:
        return False


def _target_records_from_hit(context, hit, *, select: bool):
    try:
        import bmesh
    except Exception:
        return []
    if not hit:
        return []
    mesh = hit.get("mesh")
    if mesh is None:
        return []
    try:
        bm = bmesh.from_edit_mesh(mesh)
        bm.faces.ensure_lookup_table()
        uv_layer = bm.loops.layers.uv.get(hit.get("uv_layer_name", "")) or bm.loops.layers.uv.active
        if uv_layer is None:
            return []
    except Exception:
        return []
    uv_name = str(getattr(uv_layer, "name", "") or "")
    mode = str(hit.get("mode") or _uv_mode(context)).upper()
    recs = []
    seen = set()
    changed = False
    try:
        face = bm.faces[int(hit.get("face", -1))]
        loop = tuple(face.loops)[int(hit.get("local", 0))]
    except Exception:
        return []

    def add(face2, loop2):
        nonlocal changed
        _add_record(recs, seen, mesh, uv_name, face2, loop2, uv_layer, _face_index(face2, 0), _loop_local(face2, loop2, 0))
        if select:
            if mode == "EDGE":
                _set_e(loop2, uv_layer, True)
                _set_v(loop2, uv_layer, True)
                try: _set_v(loop2.link_loop_next, uv_layer, True)
                except Exception: pass
            elif mode in {"FACE", "ISLAND"}:
                _set_f(face2, True)
                for lx in face2.loops:
                    _set_v(lx, uv_layer, True); _set_e(lx, uv_layer, True)
            else:
                _set_v(loop2, uv_layer, True)
            changed = True

    if mode == "VERTEX":
        target_vert = loop.vert
        target_uv = loop[uv_layer].uv.copy()
        for fi, f in enumerate(bm.faces):
            if getattr(f, "hide", False):
                continue
            for local, l in enumerate(tuple(f.loops)):
                try:
                    if l.vert == target_vert and _uv_close(l[uv_layer].uv, target_uv):
                        add(f, l)
                except Exception:
                    continue
    elif mode == "EDGE":
        target_edge = loop.edge
        a = hit.get("a"); b = hit.get("b")
        for fi, f in enumerate(bm.faces):
            if getattr(f, "hide", False):
                continue
            for local, l in enumerate(tuple(f.loops)):
                try:
                    if l.edge == target_edge and _segment_close(l[uv_layer].uv, l.link_loop_next[uv_layer].uv, a, b):
                        add(f, l)
                        try: add(f, l.link_loop_next)
                        except Exception: pass
                except Exception:
                    continue
    else:
        # Face selection.  Island mode intentionally starts from the visible UV
        # face under the cursor only here; island expansion is Blender-native when
        # the user uses native island selection, and avoiding expansion prevents
        # accidental whole-island transforms during partial-element workflows.
        for l in face.loops:
            add(face, l)
    if changed:
        try:
            bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        except TypeError:
            try: bmesh.update_edit_mesh(mesh)
            except Exception: pass
        except Exception:
            pass
        try:
            if getattr(context, "area", None): context.area.tag_redraw()
        except Exception:
            pass
    return [{"mesh": mesh, "uv_layer_name": uv_name, "loops": recs}] if recs else []


def _select_hit_fast(context, hit, event=None) -> bool:
    if not hit:
        return False
    additive = bool(getattr(event, "shift", False) or getattr(event, "ctrl", False)) if event is not None else False
    if not additive:
        _clear_uv_selection_fast(context)
    batches = _target_records_from_hit(context, hit, select=True)
    return bool(batches)


def _snap_delta(context, delta):
    fn = _pg("_sus_1674_snap_delta")
    if callable(fn):
        try:
            return fn(context, delta)
        except Exception:
            return delta
    return delta


def _axis_enabled(context=None) -> bool:
    try:
        fn = _pg("_sus_1636_axis_memory_enabled")
        return bool(fn(context or bpy.context)) if callable(fn) else False
    except Exception:
        return False


def _capture_last_native_axis(context=None):
    try:
        fn = _pg("_sus_1636_capture_axis_from_last_transform_operator")
        if callable(fn):
            fn(context or bpy.context)
    except Exception:
        pass


def _get_axis(context=None) -> str:
    # Direct UV-gizmo helper writes the axis explicitly.  Do not immediately
    # overwrite that value by re-reading stale native transform history; this
    # was the main reason Axis Constraint Memory failed when all three operation
    # helpers were enabled together.
    if _axis_enabled(context):
        try:
            if time.monotonic() - float(_DIRECT_AXIS_STAMP) > _DIRECT_AXIS_TTL:
                _capture_last_native_axis(context)
        except Exception:
            _capture_last_native_axis(context)
    try:
        fn = _pg("_sus_1636_get_axis")
        axis = str(fn(context or bpy.context) if callable(fn) else "FREE").upper()
    except Exception:
        axis = "FREE"
    return axis if axis in {"U", "V", "FREE"} else "FREE"


def _set_axis(axis: str, context=None) -> None:
    global _DIRECT_AXIS_STAMP
    axis = str(axis or "FREE").upper()
    if axis not in {"U", "V", "FREE"}:
        axis = "FREE"
    _DIRECT_AXIS_STAMP = time.monotonic()
    try:
        fn = _pg("_sus_1636_set_axis")
        if callable(fn):
            fn(axis, context or bpy.context)
            return
    except Exception:
        pass
    try:
        _PG["_SUS_1636_MEMORY_AXIS"] = axis
    except Exception:
        pass


def _axis_delta(context, delta: Vector, axis: str | None = None) -> Vector:
    try:
        a = str(axis or (_get_axis(context) if _axis_enabled(context) else "FREE")).upper()
        if a == "U":
            delta.y = 0.0
        elif a == "V":
            delta.x = 0.0
    except Exception:
        pass
    return delta


def _record_axis_from_mode(context, mode: str) -> None:
    if not _axis_enabled(context):
        return
    m = str(mode or "").upper()
    if m == "MOVE_X":
        _set_axis("U", context)
    elif m == "MOVE_Y":
        _set_axis("V", context)
    elif m in {"MOVE", "MOVE_XY", "FREE"}:
        _set_axis("FREE", context)


def _loop_ref_key(loop, uv_layer):
    try:
        return (int(loop.face.index), int(tuple(loop.face.loops).index(loop)), str(getattr(uv_layer, "name", "") or ""))
    except Exception:
        return (id(loop), id(uv_layer))


def _cache_batches(context, batches):
    try:
        import bmesh
    except Exception:
        return list(batches or [])
    cached = []
    for batch in list(batches or []):
        mesh = batch.get("mesh") if isinstance(batch, dict) else None
        if mesh is None:
            continue
        try:
            bm = bmesh.from_edit_mesh(mesh)
            bm.faces.ensure_lookup_table()
        except Exception:
            cached.append(batch); continue
        try:
            uv_name = str(batch.get("uv_layer_name", "") or "")
            uv_layer = bm.loops.layers.uv.get(uv_name) if uv_name else None
            if uv_layer is None:
                uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        except Exception:
            uv_layer = None
        if uv_layer is None:
            cached.append(batch); continue
        refs = []
        seen = set()
        for rec in list(batch.get("loops", []) or []):
            try:
                fi, li, original = rec
                face = bm.faces[int(fi)]
                loops = tuple(face.loops)
                li = int(li)
                if not (0 <= li < len(loops)):
                    continue
                loop = loops[li]
                key = _loop_ref_key(loop, uv_layer)
                if key in seen:
                    continue
                seen.add(key)
                refs.append((loop, uv_layer, original.copy()))
            except Exception:
                continue
        if refs:
            cached.append({"mesh": mesh, "uv_layer_name": str(getattr(uv_layer, "name", batch.get("uv_layer_name", "")) or ""), "refs": refs, "loops": batch.get("loops", ())})
    return cached


def _apply_cached_delta(context, batches, delta: Vector) -> bool:
    try:
        import bmesh
    except Exception:
        return False
    try:
        dx = float(delta.x); dy = float(delta.y)
    except Exception:
        dx = dy = 0.0
    changed = []
    seen_mesh = set()
    for batch in list(batches or []):
        mesh = batch.get("mesh") if isinstance(batch, dict) else None
        if mesh is None:
            continue
        wrote = False
        refs = list(batch.get("refs") or []) if isinstance(batch, dict) else []
        if refs:
            for loop, uv_layer, original in refs:
                try:
                    uv = loop[uv_layer].uv
                    nx = float(original.x) + dx; ny = float(original.y) + dy
                    if uv.x != nx or uv.y != ny:
                        uv.x = nx; uv.y = ny
                    wrote = True
                except (ReferenceError, RuntimeError):
                    continue
                except Exception:
                    continue
        else:
            try:
                bm = bmesh.from_edit_mesh(mesh)
                bm.faces.ensure_lookup_table()
                uv_layer = bm.loops.layers.uv.get(batch.get("uv_layer_name", "")) or bm.loops.layers.uv.active
            except Exception:
                uv_layer = None
            if uv_layer is None:
                continue
            for fi, li, original in list(batch.get("loops", []) or []):
                try:
                    face = bm.faces[int(fi)]
                    loops = tuple(face.loops)
                    li = int(li)
                    if 0 <= li < len(loops):
                        uv = loops[li][uv_layer].uv
                        uv.x = float(original.x) + dx; uv.y = float(original.y) + dy
                        wrote = True
                except Exception:
                    continue
        if wrote and id(mesh) not in seen_mesh:
            seen_mesh.add(id(mesh)); changed.append(mesh)
    for mesh in changed:
        try:
            bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        except TypeError:
            try: bmesh.update_edit_mesh(mesh)
            except Exception: pass
        except Exception:
            pass
    try:
        if getattr(context, "area", None): context.area.tag_redraw()
    except Exception:
        pass
    return bool(changed)


def _apply_cached_transform(context, batches, transform_func) -> bool:
    try:
        import bmesh
    except Exception:
        return False
    changed = []
    seen_mesh = set()
    for batch in list(batches or []):
        mesh = batch.get("mesh") if isinstance(batch, dict) else None
        if mesh is None:
            continue
        wrote = False
        for loop, uv_layer, original in list(batch.get("refs") or []):
            try:
                loop[uv_layer].uv = transform_func(original)
                wrote = True
            except (ReferenceError, RuntimeError):
                continue
            except Exception:
                continue
        if wrote and id(mesh) not in seen_mesh:
            seen_mesh.add(id(mesh)); changed.append(mesh)
    for mesh in changed:
        try:
            bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        except TypeError:
            try: bmesh.update_edit_mesh(mesh)
            except Exception: pass
        except Exception:
            pass
    try:
        if getattr(context, "area", None): context.area.tag_redraw()
    except Exception:
        pass
    return bool(changed)


def _delta_key(delta):
    try:
        return (round(float(delta.x), 10), round(float(delta.y), 10))
    except Exception:
        return None


def _cache_key(context):
    try:
        objs = tuple((int(obj.as_pointer()), int(obj.data.as_pointer())) for obj in _iter_edit_mesh_objects(context))
    except Exception:
        objs = ()
    try:
        area_ptr = int(context.area.as_pointer())
    except Exception:
        area_ptr = 0
    return (area_ptr, _uv_mode(context), objs)


def _update_gizmo_cache(context, batches, stats):
    try:
        from . import uv_gizmo_grip_fix as g
        pivot = g._selected_uv_pivot(context, stats)
        preg = g._view_to_region(context.region, pivot) if pivot is not None else None
    except Exception:
        pivot = preg = None
    _GIZMO_CACHE.update({"key": _cache_key(context), "stats": stats, "batches": batches, "pivot_uv": pivot, "pivot_region": preg, "stamp": time.monotonic()})


def _cache_handle_hit(context, event) -> bool | None:
    """Return whether the mouse is on a real UV-gizmo handle.

    The previous version only answered from an already existing cache.  On the
    first U/V handle press after a selection change the cache was often empty, so
    Immediate Select performed a full UV-element hit scan first and could steal
    the event.  This version builds the selected-pivot cache once, using the
    attribute-first collector, and then returns the exact handle mode.  That is
    cheaper than a full UV hit scan on many meshes and keeps U/V axis drags
    constrained.
    """
    try:
        if not _is_uv_context(context):
            return None
        from . import uv_gizmo_grip_fix as g
        if not g.is_enabled():
            return None
        key = _cache_key(context)
        preg = None
        if _GIZMO_CACHE.get("key") == key:
            preg = _GIZMO_CACHE.get("pivot_region")
            # A positive handle cache is safe for a short time.  A stale cache is
            # rebuilt below; this avoids stale pivots after standard Blender
            # transforms or manual selection changes.
            try:
                if time.monotonic() - float(_GIZMO_CACHE.get("stamp", 0.0)) > 0.25:
                    preg = None
            except Exception:
                preg = None
        if preg is None:
            batches, stats = _fast_collect_selected_uv_state(context)
            if not batches or not stats:
                return None
            _update_gizmo_cache(context, batches, stats)
            preg = _GIZMO_CACHE.get("pivot_region")
        if preg is None:
            return None
        return g._hit_test_fallback_area(context, event, preg) is not None
    except Exception:
        return None


def _instant_invoke(self, context, event):
    enabled = _pg("_sus_1635_immediate_enabled")
    try:
        if callable(enabled) and not enabled(context):
            return {"PASS_THROUGH"}
    except Exception:
        return {"PASS_THROUGH"}
    if str(getattr(event, "type", "")) != "LEFTMOUSE" or str(getattr(event, "value", "")) != "PRESS":
        return {"PASS_THROUGH"}
    if not _is_uv_context(context):
        return {"PASS_THROUGH"}
    if bool(getattr(event, "alt", False) or getattr(event, "oskey", False)):
        return {"PASS_THROUGH"}

    # If cached selected-pivot data says this is a real gizmo handle, never own
    # the event.  This keeps U/V handles constrained even when Immediate Select is
    # registered before some image-editor selection maps.
    cache_hit = _cache_handle_hit(context, event)
    if cache_hit is True:
        return {"PASS_THROUGH"}

    hit = _find_hit_fast(context, event)
    if not hit:
        return {"PASS_THROUGH"}

    selected = _hit_selected_fast(context, hit)
    # Already-selected elements should use Blender/native gizmo or the gizmo grip
    # path.  Immediate Select is for switching to the hovered element at PRESS.
    if selected and not bool(getattr(event, "shift", False) or getattr(event, "ctrl", False)):
        return {"PASS_THROUGH"}

    if not _select_hit_fast(context, hit, event):
        return {"PASS_THROUGH"}
    batches = _target_records_from_hit(context, hit, select=False)
    batches = _cache_batches(context, batches)
    if not batches:
        return {"PASS_THROUGH"}
    try:
        self._suv1845_batches = batches
        self._suv1845_start_uv = _region_to_uv(context, event)
        self._suv1845_start_xy = (int(getattr(event, "mouse_region_x", 0) or 0), int(getattr(event, "mouse_region_y", 0) or 0))
        self._suv1845_dragging = False
        self._suv1845_last_delta_key = None
        self._suv1845_axis = _get_axis(context) if _axis_enabled(context) else "FREE"
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}
    except Exception:
        return {"FINISHED"}


def _instant_modal(self, context, event):
    etype = str(getattr(event, "type", "") or "")
    evalue = str(getattr(event, "value", "") or "")
    if etype in {"ESC", "RIGHTMOUSE"}:
        return {"CANCELLED"}
    if etype == "LEFTMOUSE" and evalue == "RELEASE":
        return {"FINISHED"}
    if etype in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
        try:
            cur = _region_to_uv(context, event)
            start = getattr(self, "_suv1845_start_uv", None)
            if cur is None or start is None:
                return {"RUNNING_MODAL"}
            sx, sy = getattr(self, "_suv1845_start_xy", (0, 0))
            dx = int(getattr(event, "mouse_region_x", 0) or 0) - int(sx)
            dy = int(getattr(event, "mouse_region_y", 0) or 0) - int(sy)
            if not bool(getattr(self, "_suv1845_dragging", False)):
                if dx * dx + dy * dy < 9:
                    return {"RUNNING_MODAL"}
                self._suv1845_dragging = True
            delta = Vector((float(cur.x - start.x), float(cur.y - start.y)))
            delta = _axis_delta(context, delta, getattr(self, "_suv1845_axis", "FREE"))
            delta = _snap_delta(context, delta)
            key = _delta_key(delta)
            if key is not None and key == getattr(self, "_suv1845_last_delta_key", None):
                return {"RUNNING_MODAL"}
            self._suv1845_last_delta_key = key
            _apply_cached_delta(context, getattr(self, "_suv1845_batches", []), delta)
            return {"RUNNING_MODAL"}
        except Exception:
            return {"FINISHED"}
    return {"RUNNING_MODAL"}


def _patch_instant_class():
    try:
        cls = _pg("SMARTUVSUITE_OT_instant_select_drag_move")
        if not isinstance(cls, type):
            return
        cls.bl_options = {'UNDO', 'BLOCKING'}
        cls.invoke = _instant_invoke
        cls.modal = _instant_modal
        cls._find_uv_hit = lambda self, context, event: _find_hit_fast(context, event)
        cls._select_uv_hit_immediate = lambda self, context, event, hit=None: _select_hit_fast(context, hit or _find_hit_fast(context, event), event)
        cls._hit_is_current_selection = lambda self, context, hit: _hit_selected_fast(context, hit)
        cls._integrated_uv_gizmo_grip_should_own_press = lambda self, context, event: bool(_cache_handle_hit(context, event))
    except Exception:
        pass


def _patch_gizmo_module():
    try:
        from . import uv_gizmo_grip_fix as g
    except Exception:
        return
    try:
        g._sus_1835_apply_patch()
    except Exception:
        pass
    try:
        g._SUS_1835_KEYMAP_NAMES = tuple(_GIZMO_KEYMAP_NAMES)
        g._NATIVE_GIZMO_KEYMAP_NAMES = tuple(name for name, _sp in _GIZMO_KEYMAP_NAMES)
        g._log = lambda message: None
    except Exception:
        pass

    def _gizmo_register_keymaps_minimal():
        # Register only in real gizmo keymaps.  Never add this fallback to Image or
        # UV Editor maps, because that makes every element click perform selected-
        # UV scans on dense scenes.
        return _ensure_keymaps_for_defs("smart_uv_suite.uv_gizmo_grip_fix_grab", _GIZMO_KEYMAP_NAMES, active=True, head=True)

    try:
        g._register_keymaps = _gizmo_register_keymaps_minimal
        g._sus_1835_register_keymaps = _gizmo_register_keymaps_minimal
    except Exception:
        pass

    def _gizmo_invoke(self, context, event):
        if str(getattr(event, "type", "")) != "LEFTMOUSE" or str(getattr(event, "value", "")) != "PRESS":
            return {"PASS_THROUGH"}
        try:
            if g._event_has_selection_modifier(event) or not g.is_enabled():
                return {"PASS_THROUGH"}
            if not g._is_uv_editor_context(context) or not hasattr(context.region, "view2d"):
                return {"PASS_THROUGH"}
        except Exception:
            return {"PASS_THROUGH"}

        # Fast handle ownership.  Build/reuse selected-pivot data before any
        # Immediate Select UV hit scan can steal U/V axis handles.
        cached = _cache_handle_hit(context, event)
        if cached is False:
            return {"PASS_THROUGH"}
        if cached is True and _GIZMO_CACHE.get("key") == _cache_key(context):
            batches = _GIZMO_CACHE.get("batches") or []
            stats = _GIZMO_CACHE.get("stats")
        else:
            try:
                press_uv = g._region_to_view(context.region, event.mouse_region_x, event.mouse_region_y)
            except Exception:
                press_uv = None
            try:
                batches, stats = _fast_collect_selected_uv_state(context, anchor_uv=press_uv)
            except Exception:
                batches, stats = [], None
            if not batches or not stats:
                return {"PASS_THROUGH"}
            _update_gizmo_cache(context, batches, stats)
        try:
            pivot_uv = g._selected_uv_pivot(context, stats)
            if pivot_uv is None:
                return {"PASS_THROUGH"}
            pivot_region = g._view_to_region(context.region, pivot_uv)
            mode = g._hit_test_fallback_area(context, event, pivot_region)
        except Exception:
            mode = None
        if mode is None:
            return {"PASS_THROUGH"}
        _record_axis_from_mode(context, mode)
        try:
            self._area = context.area
            self._region = context.region
            self._batches = _cache_batches(context, batches)
            self._pivot_uv = pivot_uv
            self._mode = mode
            self._start_mouse_view = g._region_to_view(self._region, event.mouse_region_x, event.mouse_region_y)
            self._start_vector = self._start_mouse_view - self._pivot_uv
            self._suv1845_last_delta_key = None
            context.window_manager.modal_handler_add(self)
            return {"RUNNING_MODAL"}
        except Exception:
            return {"PASS_THROUGH"}

    def _gizmo_apply_to_uvs(self, context, transform_func):
        return _apply_cached_transform(context, getattr(self, "_batches", []) or [], transform_func)

    def _gizmo_restore(self, context):
        return _apply_cached_transform(context, getattr(self, "_batches", []) or [], lambda original: original.copy())

    def _gizmo_apply_mode(self, context, current_view):
        mode = str(getattr(self, "_mode", "") or "")
        if mode.startswith("MOVE"):
            delta = current_view - self._start_mouse_view
            if mode == "MOVE_X":
                delta.y = 0.0
            elif mode == "MOVE_Y":
                delta.x = 0.0
            try:
                delta = g._snap_uv_delta_relative_to_cursor(context, delta)
            except Exception:
                delta = _snap_delta(context, delta)
            key = _delta_key(delta)
            if key is not None and key == getattr(self, "_suv1845_last_delta_key", None):
                return None
            self._suv1845_last_delta_key = key
            _apply_cached_delta(context, getattr(self, "_batches", []) or [], delta)
            return None
        # Scale/rotate keep the existing behavior but use cached loop refs.
        try:
            pivot = self._pivot_uv
            current_vector = current_view - pivot
            if mode == "SCALE_UNIFORM":
                start_len = max(float(self._start_vector.length), 1.0e-8)
                current_len = max(float(current_vector.length), 1.0e-8)
                scale = max(1.0e-5, min(100000.0, current_len / start_len))
                return _apply_cached_transform(context, getattr(self, "_batches", []) or [], lambda original: pivot + (original - pivot) * scale)
            if mode == "ROTATE":
                if float(self._start_vector.length) <= 1.0e-8 or float(current_vector.length) <= 1.0e-8:
                    return None
                angle = atan2(float(current_vector.y), float(current_vector.x)) - atan2(float(self._start_vector.y), float(self._start_vector.x))
                c = cos(angle); s = sin(angle)
                def rotated(original):
                    rel = original - pivot
                    return Vector((pivot.x + rel.x * c - rel.y * s, pivot.y + rel.x * s + rel.y * c))
                return _apply_cached_transform(context, getattr(self, "_batches", []) or [], rotated)
        except Exception:
            return None

    try:
        op = g.JELARARAGI_OT_uv_gizmo_grip_fix_grab
        op.invoke = _gizmo_invoke
        op._apply_to_uvs = _gizmo_apply_to_uvs
        op._restore_original_uvs = _gizmo_restore
        op._apply_mode = _gizmo_apply_mode
        g._collect_selected_uv_state = _fast_collect_selected_uv_state
    except Exception:
        pass
    try:
        g._snap_uv_delta_relative_to_cursor = lambda context, delta: _snap_delta(context, delta)
    except Exception:
        pass



def _addon_keyconfig():
    try:
        return bpy.context.window_manager.keyconfigs.addon
    except Exception:
        return None


def _find_kmis(km, idname: str):
    try:
        from . import ownership_runtime_18168 as _ownership
        return [kmi for keymap, kmi in _ownership.owned_keymap_items(idname) if keymap is km]
    except Exception:
        return []


def _configure_kmi(kmi, *, active: bool):
    for name, value in (("type", "LEFTMOUSE"), ("value", "PRESS"), ("shift", False), ("ctrl", False), ("alt", False), ("oskey", False), ("any", False)):
        try:
            _suv_resource.keymap_item_set(kmi, name, value)
        except Exception:
            pass
    try:
        from . import ownership_runtime_18168 as _ownership
        _ownership.set_keymap_item_active(kmi, bool(active))
    except Exception:
        pass


def _get_keymap(kc, name: str, space_type: str):
    try:
        km = kc.keymaps.get(name)
        if km is None:
            km = kc.keymaps.new(name=name, space_type=space_type, region_type="WINDOW")
        return km
    except Exception:
        return None


def _ensure_keymaps_for_defs(idname: str, defs, *, active: bool, head: bool = True):
    kc = _addon_keyconfig()
    if kc is None:
        return 0, 0
    created = 0; touched = 0
    keep = {name for name, _sp in defs}
    # Remove same-operator rows from non-owned maps first.  This makes older
    # compatibility sync layers harmless even if they ran earlier in the same
    # property update.
    try:
        for km in list(kc.keymaps):
            if str(getattr(km, "name", "") or "") in keep:
                continue
            for kmi in list(_find_kmis(km, idname)):
                try:
                    __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(km, kmi)
                except Exception:
                    try: __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, False)
                    except Exception: pass
    except Exception:
        pass
    for name, space in defs:
        km = _get_keymap(kc, name, space)
        if km is None:
            continue
        items = list(_find_kmis(km, idname))
        if not items:
            try:
                kmi = __import__(__package__ + '.ownership_runtime_18168', fromlist=['new_keymap_item']).new_keymap_item(km, idname, type="LEFTMOUSE", value="PRESS", head=bool(head))
            except TypeError:
                kmi = __import__(__package__ + '.ownership_runtime_18168', fromlist=['new_keymap_item']).new_keymap_item(km, idname, type="LEFTMOUSE", value="PRESS")
            items = [kmi]; created += 1
        # If multiple stale rows exist in an owned map, keep one row only.
        for extra in items[1:]:
            try: __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(km, extra)
            except Exception:
                try: __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(extra, False)
                except Exception: pass
        for kmi in items[:1]:
            _configure_kmi(kmi, active=active)
            touched += 1
    return created, touched


def _set_keymaps_for_defs_active(idname: str, defs, active: bool):
    if active:
        return _ensure_keymaps_for_defs(idname, defs, active=True, head=True)
    kc = _addon_keyconfig()
    if kc is None:
        return 0, 0
    touched = 0
    for name, _sp in defs:
        try:
            km = kc.keymaps.get(name)
            if km is None:
                continue
            for kmi in _find_kmis(km, idname):
                __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, False); touched += 1
        except Exception:
            pass
    return 0, touched


def _delete_keymaps_for_defs(idname: str, defs):
    kc = _addon_keyconfig()
    if kc is None:
        return 0
    removed = 0
    names = {name for name, _sp in defs}
    try:
        for km in list(kc.keymaps):
            # Delete all rows for this idname, including obsolete old-map rows.
            for kmi in list(_find_kmis(km, idname)):
                try:
                    __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(km, kmi); removed += 1
                except Exception:
                    try: __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, False)
                    except Exception: pass
    except Exception:
        pass
    return removed


def _ensure_minimal_instant_keymaps(*, active: bool = True):
    return _ensure_keymaps_for_defs("smart_uv_suite.instant_select_drag_move", _INSTANT_KEYMAP_DEFS, active=active, head=True)


def _set_minimal_instant_keymaps_active(active: bool):
    return _set_keymaps_for_defs_active("smart_uv_suite.instant_select_drag_move", _INSTANT_KEYMAP_DEFS, bool(active))


def _delete_minimal_instant_keymaps():
    return _delete_keymaps_for_defs("smart_uv_suite.instant_select_drag_move", _INSTANT_KEYMAP_DEFS)


def _remove_obsolete_keymap_rows():
    """Remove only exact Smart UV-owned rows outside the current manifest."""
    try:
        from . import ownership_runtime_18168 as _ownership
        instant_defs = tuple(globals().get('_INSTANT_KEYMAP_DEFS', ()))
        gizmo_defs = tuple(globals().get('_GIZMO_KEYMAP_DEFS_1850', globals().get('_GIZMO_KEYMAP_NAMES', ())))
        keep_instant = {str(item[0]) for item in instant_defs if item}
        keep_gizmo = {str(item[0]) for item in gizmo_defs if item}
        for op_id, allowed in (
            ('smart_uv_suite.instant_select_drag_move', keep_instant),
            ('smart_uv_suite.uv_gizmo_grip_fix_grab', keep_gizmo),
        ):
            for km, kmi in tuple(_ownership.owned_keymap_items(op_id)):
                if str(getattr(km, 'name', '') or '') not in allowed:
                    _ownership.remove_keymap_item(km, kmi)
    except Exception:
        pass




def _gizmo_enable_minimal():
    try:
        from . import uv_gizmo_grip_fix as g
        try:
            g._ENABLED = True
        except Exception:
            pass
        try:
            g._SUS_1835_KEYMAP_NAMES = tuple(_GIZMO_KEYMAP_NAMES)
            g._NATIVE_GIZMO_KEYMAP_NAMES = tuple(name for name, _sp in _GIZMO_KEYMAP_NAMES)
        except Exception:
            pass
        _ensure_keymaps_for_defs("smart_uv_suite.uv_gizmo_grip_fix_grab", _GIZMO_KEYMAP_NAMES, active=True, head=True)
    except Exception:
        pass
    _remove_obsolete_keymap_rows()


def _gizmo_disable_minimal(*, delete: bool = False):
    try:
        from . import uv_gizmo_grip_fix as g
        try:
            g._ENABLED = False
        except Exception:
            pass
    except Exception:
        pass
    if delete:
        _delete_keymaps_for_defs("smart_uv_suite.uv_gizmo_grip_fix_grab", _GIZMO_KEYMAP_NAMES)
    else:
        _set_keymaps_for_defs_active("smart_uv_suite.uv_gizmo_grip_fix_grab", _GIZMO_KEYMAP_NAMES, False)
    _remove_obsolete_keymap_rows()


def _apply_keymap_defs():
    try:
        if isinstance(_PG, dict):
            _PG["_SUS_1830_INSTANT_KEYMAP_DEFS"] = tuple(_INSTANT_KEYMAP_DEFS)
            _PG["_SUS_1832_INSTANT_KEYMAP_DEFS"] = tuple(_INSTANT_KEYMAP_DEFS)
            _PG["_SUS_1834_INSTANT_KEYMAP_DEFS"] = tuple(_INSTANT_KEYMAP_DEFS)
            _PG["_SUS_1635_INSTANT_SELECT_KEYMAP_NAMES"] = tuple(name for name, _sp in _INSTANT_KEYMAP_DEFS)
            _PG["_sus_1830_keymap_defs"] = lambda: tuple(_INSTANT_KEYMAP_DEFS)
            _PG["_sus_1652_instant_keymap_names"] = lambda: tuple(name for name, _sp in _INSTANT_KEYMAP_DEFS)
            _PG["_sus_1831_instant_keymap_names"] = lambda: tuple(name for name, _sp in _INSTANT_KEYMAP_DEFS)
            _PG["_sus_1834_keymap_defs"] = lambda: tuple(_INSTANT_KEYMAP_DEFS)
            _PG["_sus_1835_find_uv_hit"] = _find_hit_fast
            _PG["_sus_1835_select_hit"] = _select_hit_fast
            _PG["_sus_1835_hit_selected"] = _hit_selected_fast
            _PG["_sus_1835_collect_batches"] = lambda context, hit=None: (_target_records_from_hit(context, hit, select=False) if hit else _fast_collect_selected_uv_state(context)[0])
            _PG["_sus_1652_ensure_instant_keymaps"] = _ensure_minimal_instant_keymaps
            _PG["_sus_1652_promote_instant_keymaps_to_head"] = _ensure_minimal_instant_keymaps
            _PG["_sus_1652_set_instant_keymaps_active"] = _set_minimal_instant_keymaps_active
            _PG["_sus_1652_delete_instant_keymaps"] = _delete_minimal_instant_keymaps
            _PG["_sus_1652_gizmo_enable"] = _gizmo_enable_minimal
            _PG["_sus_1652_gizmo_disable"] = _gizmo_disable_minimal
    except Exception:
        pass


def _apply_axis_memory_public(context, delta):
    return _axis_delta(context, delta)


def apply_all(pkg_globals=None, context=None):
    global _PG
    if pkg_globals is not None:
        _PG = pkg_globals
    try:
        if isinstance(_PG, dict):
            bi = _PG.get("bl_info")
            if isinstance(bi, dict):
                bi["version"] = (1, 0, 0)
            _PG["_sus_1674_apply_axis_memory"] = _apply_axis_memory_public
    except Exception:
        pass
    _apply_keymap_defs()
    _remove_obsolete_keymap_rows()
    _patch_gizmo_module()
    _patch_instant_class()
    try:
        ws = _PG.get("_sus_1652_ws")(context or bpy.context) if isinstance(_PG, dict) and callable(_PG.get("_sus_1652_ws")) else None
        if ws is not None:
            if bool(getattr(ws, "operation_instant_select_enabled", False)):
                fn = _PG.get("_sus_1652_promote_instant_keymaps_to_head")
                if callable(fn):
                    fn(active=True)
            if bool(getattr(ws, "operation_uv_gizmo_grip_fix_enabled", False)):
                try:
                    from . import uv_gizmo_grip_fix as g
                    g.set_enabled(True)
                except Exception:
                    pass
    except Exception:
        pass
    _remove_obsolete_keymap_rows()


def install(pkg_globals):
    global _PG, _INSTALLED, _PREV_SYNC
    _PG = pkg_globals
    if not _INSTALLED:
        _PREV_SYNC = pkg_globals.get("_sus_1652_sync_keymaps_from_workspace")
        def _sync(context=None):
            ctx = context or bpy.context
            try:
                _apply_keymap_defs()
                _patch_gizmo_module()
            except Exception:
                pass
            try:
                if callable(_PREV_SYNC):
                    _PREV_SYNC(ctx)
            except RecursionError:
                pass
            except Exception:
                pass
            apply_all(pkg_globals, ctx)
            try:
                timer = pkg_globals.get("_sus_update_axis_constraint_memory_timer")
                if callable(timer):
                    timer(ctx)
            except Exception:
                pass
        pkg_globals["_sus_1652_sync_keymaps_from_workspace"] = _sync
        _INSTALLED = True
    apply_all(pkg_globals, bpy.context)

# -----------------------------------------------------------------------------
# 1.8.46b final correction: no pre-hit selected-state scans, no g.set_enabled(),
# no axis polling timer.  This keeps U/V gizmo axis drags constrained and removes
# the heavy full-scene scan on every Immediate Select press in dense scenes.
# -----------------------------------------------------------------------------

def _remove_native_gizmo_tweak_rows_final():
    # Never alter Blender/user gizmogroup.gizmo_tweak keymaps.
    return None


def _stop_axis_timer_final():
    try:
        timer = _PG.get('_sus_1636_axis_memory_timer') if isinstance(_PG, dict) else None
        if callable(timer) and _suv_resource.timer_is_registered(timer):
            _suv_resource.timer_unregister(timer)
    except Exception:
        pass


def _disable_axis_timer_final(context=None):
    _stop_axis_timer_final()


def _gizmo_enable_minimal():  # type: ignore[no-redef]
    try:
        from . import uv_gizmo_grip_fix as g
        g._ENABLED = True
        try:
            if getattr(g, '_load_post_reapply', None) in bpy.app.handlers.load_post:
                _suv_resource.handler_remove(bpy.app.handlers.load_post, g._load_post_reapply)
        except Exception: pass
        try:
            timer = getattr(g, '_deferred_reapply_timer', None)
            if callable(timer) and _suv_resource.timer_is_registered(timer):
                _suv_resource.timer_unregister(timer)
        except Exception: pass
        try:
            g._SUS_1835_KEYMAP_NAMES = tuple(_GIZMO_KEYMAP_NAMES)
            g._NATIVE_GIZMO_KEYMAP_NAMES = tuple(name for name, _sp in _GIZMO_KEYMAP_NAMES)
        except Exception:
            pass
    except Exception:
        pass
    _ensure_keymaps_for_defs('smart_uv_suite.uv_gizmo_grip_fix_grab', _GIZMO_KEYMAP_NAMES, active=True, head=True)
    _remove_native_gizmo_tweak_rows_final()
    _remove_obsolete_keymap_rows()


def _gizmo_disable_minimal(*, delete: bool = False):  # type: ignore[no-redef]
    try:
        from . import uv_gizmo_grip_fix as g
        g._ENABLED = False
        try:
            if getattr(g, '_load_post_reapply', None) in bpy.app.handlers.load_post:
                _suv_resource.handler_remove(bpy.app.handlers.load_post, g._load_post_reapply)
        except Exception: pass
        try:
            timer = getattr(g, '_deferred_reapply_timer', None)
            if callable(timer) and _suv_resource.timer_is_registered(timer):
                _suv_resource.timer_unregister(timer)
        except Exception: pass
    except Exception:
        pass
    if delete:
        _delete_keymaps_for_defs('smart_uv_suite.uv_gizmo_grip_fix_grab', _GIZMO_KEYMAP_NAMES)
    else:
        _set_keymaps_for_defs_active('smart_uv_suite.uv_gizmo_grip_fix_grab', _GIZMO_KEYMAP_NAMES, False)
    _remove_native_gizmo_tweak_rows_final()
    _remove_obsolete_keymap_rows()


def _instant_invoke_light(self, context, event):
    enabled = _pg('_sus_1635_immediate_enabled')
    try:
        if callable(enabled) and not enabled(context):
            return {'PASS_THROUGH'}
    except Exception:
        return {'PASS_THROUGH'}
    if str(getattr(event, 'type', '')) != 'LEFTMOUSE' or str(getattr(event, 'value', '')) != 'PRESS':
        return {'PASS_THROUGH'}
    if not _is_uv_context(context):
        return {'PASS_THROUGH'}
    if bool(getattr(event, 'alt', False) or getattr(event, 'oskey', False)):
        return {'PASS_THROUGH'}

    # Do the cheap UV-element hit first.  Building selected-pivot/gizmo state on
    # every press is the expensive path in high object-count scenes.  If the press
    # is empty background, pass through to the gizmo/native tools; the gizmo path
    # can then build selected state only when it actually needs to own the handle.
    hit = _find_hit_fast(context, event)
    if not hit:
        return {'PASS_THROUGH'}

    selected = _hit_selected_fast(context, hit)
    if selected and not bool(getattr(event, 'shift', False) or getattr(event, 'ctrl', False)):
        # If this selected-element press is actually on the U/V/free gizmo handle,
        # give it to the gizmo helper.  This scan only happens for selected hits,
        # not for every click in the UV editor.
        try:
            cache_hit = _cache_handle_hit(context, event)
            if cache_hit is True:
                return {'PASS_THROUGH'}
        except Exception:
            pass
        # Selected element drag should be handled by Blender/gizmo paths; Immediate
        # Select only switches selection at PRESS for new hovered elements.
        return {'PASS_THROUGH'}

    if not _select_hit_fast(context, hit, event):
        return {'PASS_THROUGH'}
    batches = _target_records_from_hit(context, hit, select=False)
    batches = _cache_batches(context, batches)
    if not batches:
        return {'PASS_THROUGH'}
    try:
        self._suv1845_batches = batches
        self._suv1845_start_uv = _region_to_uv(context, event)
        self._suv1845_start_xy = (int(getattr(event, 'mouse_region_x', 0) or 0), int(getattr(event, 'mouse_region_y', 0) or 0))
        self._suv1845_dragging = False
        self._suv1845_last_delta_key = None
        self._suv1845_axis = _get_axis(context) if _axis_enabled(context) else 'FREE'
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    except Exception:
        return {'FINISHED'}


def _patch_instant_class():  # type: ignore[no-redef]
    try:
        cls = _pg('SMARTUVSUITE_OT_instant_select_drag_move')
        if not isinstance(cls, type):
            return
        cls.bl_options = {'UNDO', 'BLOCKING'}
        cls.invoke = _instant_invoke_light
        cls.modal = _instant_modal
        cls._find_uv_hit = lambda self, context, event: _find_hit_fast(context, event)
        cls._select_uv_hit_immediate = lambda self, context, event, hit=None: _select_hit_fast(context, hit or _find_hit_fast(context, event), event)
        cls._hit_is_current_selection = lambda self, context, hit: _hit_selected_fast(context, hit)
        cls._integrated_uv_gizmo_grip_should_own_press = lambda self, context, event: bool(_cache_handle_hit(context, event))
    except Exception:
        pass


def _apply_keymap_defs():  # type: ignore[no-redef]
    try:
        if isinstance(_PG, dict):
            _PG['_SUS_1830_INSTANT_KEYMAP_DEFS'] = tuple(_INSTANT_KEYMAP_DEFS)
            _PG['_SUS_1832_INSTANT_KEYMAP_DEFS'] = tuple(_INSTANT_KEYMAP_DEFS)
            _PG['_SUS_1834_INSTANT_KEYMAP_DEFS'] = tuple(_INSTANT_KEYMAP_DEFS)
            _PG['_SUS_1635_INSTANT_SELECT_KEYMAP_NAMES'] = tuple(name for name, _sp in _INSTANT_KEYMAP_DEFS)
            _PG['_sus_1830_keymap_defs'] = lambda: tuple(_INSTANT_KEYMAP_DEFS)
            _PG['_sus_1652_instant_keymap_names'] = lambda: tuple(name for name, _sp in _INSTANT_KEYMAP_DEFS)
            _PG['_sus_1831_instant_keymap_names'] = lambda: tuple(name for name, _sp in _INSTANT_KEYMAP_DEFS)
            _PG['_sus_1834_keymap_defs'] = lambda: tuple(_INSTANT_KEYMAP_DEFS)
            _PG['_sus_1835_find_uv_hit'] = _find_hit_fast
            _PG['_sus_1835_select_hit'] = _select_hit_fast
            _PG['_sus_1835_hit_selected'] = _hit_selected_fast
            _PG['_sus_1835_collect_batches'] = lambda context, hit=None: (_target_records_from_hit(context, hit, select=False) if hit else _fast_collect_selected_uv_state(context)[0])
            _PG['_sus_1652_ensure_instant_keymaps'] = _ensure_minimal_instant_keymaps
            _PG['_sus_1652_promote_instant_keymaps_to_head'] = _ensure_minimal_instant_keymaps
            _PG['_sus_1652_set_instant_keymaps_active'] = _set_minimal_instant_keymaps_active
            _PG['_sus_1652_delete_instant_keymaps'] = _delete_minimal_instant_keymaps
            _PG['_sus_1652_gizmo_enable'] = _gizmo_enable_minimal
            _PG['_sus_1652_gizmo_disable'] = _gizmo_disable_minimal
            if _ORIG_AXIS_TIMER_UPDATE is not None:
                _PG['_sus_update_axis_constraint_memory_timer'] = _ORIG_AXIS_TIMER_UPDATE
            _PG['_sus_1674_apply_axis_memory'] = _apply_axis_memory_public
    except Exception:
        pass


def apply_all(pkg_globals=None, context=None):  # type: ignore[no-redef]
    global _PG
    if pkg_globals is not None:
        _PG = pkg_globals
    try:
        if isinstance(_PG, dict):
            bi = _PG.get('bl_info')
            if isinstance(bi, dict):
                bi['version'] = (1, 0, 0)
            _PG['_sus_1674_apply_axis_memory'] = _apply_axis_memory_public
    except Exception:
        pass
    _apply_keymap_defs()
    _remove_obsolete_keymap_rows()
    _remove_native_gizmo_tweak_rows_final()
    _patch_gizmo_module()
    _patch_instant_class()
    try:
        ws = _PG.get('_sus_1652_ws')(context or bpy.context) if isinstance(_PG, dict) and callable(_PG.get('_sus_1652_ws')) else None
        if ws is not None:
            if bool(getattr(ws, 'operation_instant_select_enabled', False)):
                _ensure_minimal_instant_keymaps(active=True)
            else:
                _set_minimal_instant_keymaps_active(False)
            if bool(getattr(ws, 'operation_uv_gizmo_grip_fix_enabled', False)):
                _gizmo_enable_minimal()
            else:
                _gizmo_disable_minimal(delete=False)
    except Exception:
        pass
    _remove_obsolete_keymap_rows()
    _remove_native_gizmo_tweak_rows_final()
    try:
        if callable(_ORIG_AXIS_TIMER_UPDATE):
            _ORIG_AXIS_TIMER_UPDATE(context or bpy.context)
    except Exception:
        pass


def install(pkg_globals):  # type: ignore[no-redef]
    global _PG, _INSTALLED, _PREV_SYNC, _ORIG_AXIS_TIMER_UPDATE
    _PG = pkg_globals
    if _ORIG_AXIS_TIMER_UPDATE is None:
        cand = pkg_globals.get('_sus_update_axis_constraint_memory_timer')
        if callable(cand) and cand is not _disable_axis_timer_final:
            _ORIG_AXIS_TIMER_UPDATE = cand
    if not _INSTALLED:
        _PREV_SYNC = pkg_globals.get('_sus_1652_sync_keymaps_from_workspace')
        _INSTALLED = True
    pkg_globals['_sus_1652_sync_keymaps_from_workspace'] = lambda context=None: apply_all(pkg_globals, context or bpy.context)
    apply_all(pkg_globals, bpy.context)

# 1.8.47b status/keymap-info correction for the ultra-light keymap set.
def _instant_status_minimal():
    kc = _addon_keyconfig()
    expected = len(_INSTANT_KEYMAP_DEFS)
    registered = active = 0
    if kc is not None:
        for name, _sp in _INSTANT_KEYMAP_DEFS:
            try:
                km = kc.keymaps.get(name)
                if km is None: continue
                items = _find_kmis(km, 'smart_uv_suite.instant_select_drag_move')
                if items:
                    registered += 1
                    if any(bool(getattr(kmi, 'active', False)) for kmi in items): active += 1
            except Exception: pass
    return {'registered': registered, 'active': active, 'expected': expected}


def _gizmo_status_minimal():
    kc = _addon_keyconfig()
    expected = len(_GIZMO_KEYMAP_NAMES)
    registered = active = 0
    if kc is not None:
        for name, _sp in _GIZMO_KEYMAP_NAMES:
            try:
                km = kc.keymaps.get(name)
                if km is None: continue
                items = _find_kmis(km, 'smart_uv_suite.uv_gizmo_grip_fix_grab')
                if items:
                    registered += 1
                    if any(bool(getattr(kmi, 'active', False)) for kmi in items): active += 1
            except Exception: pass
    return {'registered': registered, 'active': active, 'expected': expected}

_prev_apply_keymap_defs_1847b = _apply_keymap_defs

def _apply_keymap_defs():  # type: ignore[no-redef]
    try: _prev_apply_keymap_defs_1847b()
    except Exception: pass
    if isinstance(_PG, dict):
        _PG['_sus_1652_instant_status'] = _instant_status_minimal
        _PG['_sus_1652_gizmo_status'] = _gizmo_status_minimal

# 1.8.47c: use the spatial UV hit cache from interaction_1844 for Immediate
# Select.  This keeps the same hit result but avoids scanning every face of every
# edit mesh on every LEFTMOUSE/PRESS in dense multi-object scenes.
_find_hit_fast_linear_1847c = _find_hit_fast

def _find_hit_fast(context, event):  # type: ignore[no-redef]
    try:
        from . import interaction_1844 as _i44
        try:
            _i44._PG = _PG
        except Exception:
            pass
        hit = _i44._find_uv_hit_fast(context, event)
        if hit is not None:
            return hit
    except Exception:
        pass
    return _find_hit_fast_linear_1847c(context, event)

# -----------------------------------------------------------------------------
# 1.8.49 final: faster stable modal writes + axis-first UV gizmo handles.
# -----------------------------------------------------------------------------
# The 1.8.48 layer had the correct press-select and direct-gizmo behavior, but
# live BMLoop references could become stale during redraw/update on dense meshes,
# which made some selected UVs appear to lock mid-transform.  This final block
# keeps the same behavior while adding a cheap face/local fallback that refreshes
# the cached refs only when needed.  It also prioritizes visible U/V handle zones
# over the center hit zone so axis drags remain constrained while Immediate Select
# is enabled.

_SUS1849_ORIG_PATCH_GIZMO = _patch_gizmo_module
_SUS1849_ORIG_APPLY_ALL = apply_all


def _resolve_batch_refs(batch):
    """Refresh live BMLoop references from the stable face/local records."""
    try:
        import bmesh
        mesh = batch.get('mesh') if isinstance(batch, dict) else None
        if mesh is None:
            return []
        bm = bmesh.from_edit_mesh(mesh)
        bm.faces.ensure_lookup_table()
        uv_name = str(batch.get('uv_layer_name', '') or '')
        uv_layer = bm.loops.layers.uv.get(uv_name) if uv_name else None
        if uv_layer is None:
            uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        refs = []
        seen = set()
        for fi, li, original in list(batch.get('loops', []) or []):
            try:
                face = bm.faces[int(fi)]
                loops = tuple(face.loops)
                li = int(li)
                if 0 <= li < len(loops):
                    key = (int(fi), li)
                    if key in seen:
                        continue
                    seen.add(key)
                    refs.append((loops[li], uv_layer, original.copy()))
            except Exception:
                continue
        if refs:
            batch['refs'] = refs
        return refs
    except Exception:
        return []


def _apply_cached_delta(context, batches, delta: Vector) -> bool:  # type: ignore[no-redef]
    try:
        import bmesh
        dx = float(delta.x); dy = float(delta.y)
    except Exception:
        return False
    changed = []
    seen_mesh = set()
    for batch in list(batches or []):
        mesh = batch.get('mesh') if isinstance(batch, dict) else None
        if mesh is None:
            continue
        wrote = False
        refs = list(batch.get('refs') or []) if isinstance(batch, dict) else []
        ref_failed = False
        if refs:
            for loop, uv_layer, original in refs:
                try:
                    uv = loop[uv_layer].uv
                    nx = float(original.x) + dx; ny = float(original.y) + dy
                    if uv.x != nx or uv.y != ny:
                        uv.x = nx; uv.y = ny
                    wrote = True
                except (ReferenceError, RuntimeError):
                    ref_failed = True
                    break
                except Exception:
                    continue
        if ref_failed or not refs:
            refs = _resolve_batch_refs(batch)
            for loop, uv_layer, original in refs:
                try:
                    uv = loop[uv_layer].uv
                    nx = float(original.x) + dx; ny = float(original.y) + dy
                    if uv.x != nx or uv.y != ny:
                        uv.x = nx; uv.y = ny
                    wrote = True
                except Exception:
                    continue
        if wrote and id(mesh) not in seen_mesh:
            seen_mesh.add(id(mesh)); changed.append(mesh)
    for mesh in changed:
        try:
            bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        except TypeError:
            try: bmesh.update_edit_mesh(mesh)
            except Exception: pass
        except Exception:
            pass
    try:
        if getattr(context, 'area', None): context.area.tag_redraw()
    except Exception:
        pass
    return bool(changed)


def _apply_cached_transform(context, batches, transform_func) -> bool:  # type: ignore[no-redef]
    try:
        import bmesh
    except Exception:
        return False
    changed = []
    seen_mesh = set()
    for batch in list(batches or []):
        mesh = batch.get('mesh') if isinstance(batch, dict) else None
        if mesh is None:
            continue
        wrote = False
        refs = list(batch.get('refs') or []) if isinstance(batch, dict) else []
        ref_failed = False
        if refs:
            for loop, uv_layer, original in refs:
                try:
                    loop[uv_layer].uv = transform_func(original)
                    wrote = True
                except (ReferenceError, RuntimeError):
                    ref_failed = True
                    break
                except Exception:
                    continue
        if ref_failed or not refs:
            refs = _resolve_batch_refs(batch)
            for loop, uv_layer, original in refs:
                try:
                    loop[uv_layer].uv = transform_func(original)
                    wrote = True
                except Exception:
                    continue
        if wrote and id(mesh) not in seen_mesh:
            seen_mesh.add(id(mesh)); changed.append(mesh)
    for mesh in changed:
        try:
            bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        except TypeError:
            try: bmesh.update_edit_mesh(mesh)
            except Exception: pass
        except Exception:
            pass
    try:
        if getattr(context, 'area', None): context.area.tag_redraw()
    except Exception:
        pass
    return bool(changed)


def _build_stats_from_batches(batches):
    uvs = []
    for batch in batches or []:
        for _fi, _li, uv in batch.get('loops', []) or []:
            try:
                uvs.append(uv.copy())
            except Exception:
                pass
    if not uvs:
        return None
    minx = min(v.x for v in uvs); maxx = max(v.x for v in uvs)
    miny = min(v.y for v in uvs); maxy = max(v.y for v in uvs)
    med = Vector((sum(v.x for v in uvs) / len(uvs), sum(v.y for v in uvs) / len(uvs)))
    return {'median': med, 'bbox_center': Vector(((minx + maxx) * 0.5, (miny + maxy) * 0.5)), 'count': len(uvs)}


def _instant_invoke_light(self, context, event):  # type: ignore[no-redef]
    enabled = _pg('_sus_1635_immediate_enabled')
    try:
        if callable(enabled) and not enabled(context):
            return {'PASS_THROUGH'}
    except Exception:
        return {'PASS_THROUGH'}
    if str(getattr(event, 'type', '')) != 'LEFTMOUSE' or str(getattr(event, 'value', '')) != 'PRESS':
        return {'PASS_THROUGH'}
    if not _is_uv_context(context):
        return {'PASS_THROUGH'}
    if bool(getattr(event, 'alt', False) or getattr(event, 'oskey', False)):
        return {'PASS_THROUGH'}

    # If selected-pivot data is already known and this is a gizmo handle, pass
    # immediately.  This is cheap and prevents U/V handle drags from becoming
    # Immediate Select drags.
    try:
        if _cache_handle_hit(context, event) is True:
            return {'PASS_THROUGH'}
    except Exception:
        pass

    hit = _find_hit_fast(context, event)
    if not hit:
        return {'PASS_THROUGH'}

    selected = _hit_selected_fast(context, hit)
    if selected and not bool(getattr(event, 'shift', False) or getattr(event, 'ctrl', False)):
        return {'PASS_THROUGH'}

    if not _select_hit_fast(context, hit, event):
        return {'PASS_THROUGH'}
    batches = _target_records_from_hit(context, hit, select=False)
    stats = _build_stats_from_batches(batches)
    if stats is not None:
        try:
            _update_gizmo_cache(context, batches, stats)
        except Exception:
            pass
    batches = _cache_batches(context, batches)
    if not batches:
        return {'PASS_THROUGH'}
    try:
        self._suv1845_batches = batches
        self._suv1845_start_uv = _region_to_uv(context, event)
        self._suv1845_start_xy = (int(getattr(event, 'mouse_region_x', 0) or 0), int(getattr(event, 'mouse_region_y', 0) or 0))
        self._suv1845_dragging = False
        self._suv1845_last_delta_key = None
        self._suv1845_axis = _get_axis(context) if _axis_enabled(context) else 'FREE'
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    except Exception:
        return {'FINISHED'}


def _patch_gizmo_module():  # type: ignore[no-redef]
    try:
        _SUS1849_ORIG_PATCH_GIZMO()
    except Exception:
        pass
    try:
        from . import uv_gizmo_grip_fix as g
    except Exception:
        return
    try:
        old_hit = getattr(g, '_suv1849_original_hit_test', None)
        if old_hit is None:
            old_hit = g._hit_test_fallback_area
            g._suv1849_original_hit_test = old_hit
        def _axis_first_hit_test(context, event, pivot_region):
            try:
                scale = g._hit_scale(context)
                dx = float(event.mouse_region_x) - float(pivot_region.x)
                dy = float(event.mouse_region_y) - float(pivot_region.y)
                # Give visible U/V handles priority over the center zone when the
                # pointer is clearly on an axis.  The small 8px dead zone keeps
                # exact center drags free, while near-axis handle drags remain
                # constrained.
                axis_min = 8.0 * scale
                axis_max = 118.0 * scale
                axis_radius = 12.0 * scale
                if axis_min <= dx <= axis_max and abs(dy) <= axis_radius:
                    return 'MOVE_X'
                if axis_min <= dy <= axis_max and abs(dx) <= axis_radius:
                    return 'MOVE_Y'
            except Exception:
                pass
            return old_hit(context, event, pivot_region)
        g._hit_test_fallback_area = _axis_first_hit_test
    except Exception:
        pass


def _patch_instant_class():  # type: ignore[no-redef]
    try:
        cls = _pg('SMARTUVSUITE_OT_instant_select_drag_move')
        if not isinstance(cls, type):
            return
        cls.bl_options = {'UNDO', 'BLOCKING'}
        cls.invoke = _instant_invoke_light
        cls.modal = _instant_modal
        cls._find_uv_hit = lambda self, context, event: _find_hit_fast(context, event)
        cls._select_uv_hit_immediate = lambda self, context, event, hit=None: _select_hit_fast(context, hit or _find_hit_fast(context, event), event)
        cls._hit_is_current_selection = lambda self, context, hit: _hit_selected_fast(context, hit)
        cls._integrated_uv_gizmo_grip_should_own_press = lambda self, context, event: bool(_cache_handle_hit(context, event))
    except Exception:
        pass


def apply_all(pkg_globals=None, context=None):  # type: ignore[no-redef]
    global _PG
    if pkg_globals is not None:
        _PG = pkg_globals
    try:
        if isinstance(_PG, dict):
            bi = _PG.get('bl_info')
            if isinstance(bi, dict):
                bi['version'] = (1, 0, 0)
            _PG['_sus_1674_apply_axis_memory'] = _apply_axis_memory_public
    except Exception:
        pass
    _apply_keymap_defs()
    _remove_obsolete_keymap_rows()
    _remove_native_gizmo_tweak_rows_final()
    _patch_gizmo_module()
    _patch_instant_class()
    try:
        ws = _PG.get('_sus_1652_ws')(context or bpy.context) if isinstance(_PG, dict) and callable(_PG.get('_sus_1652_ws')) else None
        if ws is not None:
            if bool(getattr(ws, 'operation_instant_select_enabled', False)):
                _ensure_minimal_instant_keymaps(active=True)
            else:
                _set_minimal_instant_keymaps_active(False)
            if bool(getattr(ws, 'operation_uv_gizmo_grip_fix_enabled', False)):
                _gizmo_enable_minimal()
            else:
                _gizmo_disable_minimal(delete=False)
    except Exception:
        pass
    _remove_obsolete_keymap_rows()
    _remove_native_gizmo_tweak_rows_final()
    try:
        if callable(_ORIG_AXIS_TIMER_UPDATE):
            _ORIG_AXIS_TIMER_UPDATE(context or bpy.context)
    except Exception:
        pass

# -----------------------------------------------------------------------------
# 1.8.50b: deterministic UV gizmo grab priority under heavy scenes.
# -----------------------------------------------------------------------------
_GIZMO_KEYMAP_DEFS_1850 = (
    ("Image", "IMAGE_EDITOR"),
    ("Generic Gizmo", "EMPTY"),
    ("Generic Gizmo Drag", "EMPTY"),
    ("Generic Gizmo Click Drag", "EMPTY"),
    ("Generic Gizmo Maybe Drag", "EMPTY"),
    ("Generic Gizmo Select", "EMPTY"),
)


def _ensure_ordered_keymaps_1850(idname, defs, active=True, head=True):
    kc = _addon_keyconfig()
    if kc is None:
        return 0, 0
    created = touched = 0
    try:
        for km in list(kc.keymaps):
            for kmi in list(_find_kmis(km, idname)):
                try: __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(km, kmi)
                except Exception:
                    try: __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, False)
                    except Exception: pass
    except Exception:
        pass
    for name, space in defs:
        km = _get_keymap(kc, name, space)
        if km is None:
            continue
        try:
            kmi = __import__(__package__ + '.ownership_runtime_18168', fromlist=['new_keymap_item']).new_keymap_item(km, idname, type='LEFTMOUSE', value='PRESS', head=bool(head))
        except TypeError:
            kmi = __import__(__package__ + '.ownership_runtime_18168', fromlist=['new_keymap_item']).new_keymap_item(km, idname, type='LEFTMOUSE', value='PRESS')
        _configure_kmi(kmi, active=active)
        created += 1; touched += 1
    return created, touched


def _delete_rows_for_id_1850(idname):
    kc = _addon_keyconfig(); n = 0
    if kc is None:
        return 0
    try:
        for km in list(kc.keymaps):
            for kmi in list(_find_kmis(km, idname)):
                try: __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(km, kmi); n += 1
                except Exception:
                    try: __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, False)
                    except Exception: pass
    except Exception:
        pass
    return n


def _ensure_minimal_instant_keymaps(*, active: bool = True):  # type: ignore[no-redef]
    return _ensure_ordered_keymaps_1850('smart_uv_suite.instant_select_drag_move', _INSTANT_KEYMAP_DEFS, active=active, head=True)


def _set_minimal_instant_keymaps_active(active: bool):  # type: ignore[no-redef]
    if active:
        return _ensure_minimal_instant_keymaps(active=True)
    return _set_keymaps_for_defs_active('smart_uv_suite.instant_select_drag_move', _INSTANT_KEYMAP_DEFS, False)


def _delete_minimal_instant_keymaps():  # type: ignore[no-redef]
    return _delete_rows_for_id_1850('smart_uv_suite.instant_select_drag_move')


def _ensure_gizmo_keymaps_1850(active=True):
    # Recreated after Immediate Select, so the Image guard is evaluated before it.
    return _ensure_ordered_keymaps_1850('smart_uv_suite.uv_gizmo_grip_fix_grab', _GIZMO_KEYMAP_DEFS_1850, active=active, head=True)


def _set_gizmo_keymaps_1850_active(active: bool):
    if active:
        return _ensure_gizmo_keymaps_1850(True)
    return _set_keymaps_for_defs_active('smart_uv_suite.uv_gizmo_grip_fix_grab', _GIZMO_KEYMAP_DEFS_1850, False)


def _remove_obsolete_keymap_rows():
    """Remove only exact Smart UV-owned rows outside the current manifest."""
    try:
        from . import ownership_runtime_18168 as _ownership
        instant_defs = tuple(globals().get('_INSTANT_KEYMAP_DEFS', ()))
        gizmo_defs = tuple(globals().get('_GIZMO_KEYMAP_DEFS_1850', globals().get('_GIZMO_KEYMAP_NAMES', ())))
        keep_instant = {str(item[0]) for item in instant_defs if item}
        keep_gizmo = {str(item[0]) for item in gizmo_defs if item}
        for op_id, allowed in (
            ('smart_uv_suite.instant_select_drag_move', keep_instant),
            ('smart_uv_suite.uv_gizmo_grip_fix_grab', keep_gizmo),
        ):
            for km, kmi in tuple(_ownership.owned_keymap_items(op_id)):
                if str(getattr(km, 'name', '') or '') not in allowed:
                    _ownership.remove_keymap_item(km, kmi)
    except Exception:
        pass



def _remove_native_gizmo_tweak_rows_final():  # type: ignore[no-redef]
    # Never alter Blender/user gizmogroup.gizmo_tweak keymaps.
    return None


def _gizmo_mode_from_region_1850(context, event, pivot_region):
    try:
        from . import uv_gizmo_grip_fix as g
        scale = g._hit_scale(context)
    except Exception:
        scale = 1.0
    try:
        dx = float(event.mouse_region_x) - float(pivot_region.x)
        dy = float(event.mouse_region_y) - float(pivot_region.y)
        r = (dx * dx + dy * dy) ** 0.5
        amin = 6.0 * scale; amax = 140.0 * scale; ar = 18.0 * scale
        if amin <= dx <= amax and abs(dy) <= ar:
            return 'MOVE_X'
        if amin <= dy <= amax and abs(dx) <= ar:
            return 'MOVE_Y'
        if r <= 20.0 * scale:
            return 'MOVE'
        if 28.0 * scale <= r <= 122.0 * scale and abs(abs(dx) - abs(dy)) <= 20.0 * scale and dx * dy > 0:
            return 'SCALE_UNIFORM'
        if 58.0 * scale <= r <= 130.0 * scale:
            return 'ROTATE'
    except Exception:
        pass
    try:
        from . import uv_gizmo_grip_fix as g
        return g._hit_test_fallback_area(context, event, pivot_region)
    except Exception:
        return None


def _gizmo_press_state_1850(context, event, allow_collect=True):
    if not _is_uv_context(context):
        return None
    try:
        from . import uv_gizmo_grip_fix as g
        if not g.is_enabled(): return None
    except Exception:
        return None
    key = _cache_key(context)
    batches = _GIZMO_CACHE.get('batches') if _GIZMO_CACHE.get('key') == key else None
    stats = _GIZMO_CACHE.get('stats') if _GIZMO_CACHE.get('key') == key else None
    pivot_uv = _GIZMO_CACHE.get('pivot_uv') if _GIZMO_CACHE.get('key') == key else None
    pivot_region = _GIZMO_CACHE.get('pivot_region') if _GIZMO_CACHE.get('key') == key else None
    try:
        if pivot_region is not None and time.monotonic() - float(_GIZMO_CACHE.get('stamp', 0.0)) > 8.0:
            pivot_region = None
    except Exception:
        pivot_region = None
    if not pivot_region or not batches or not stats:
        if not allow_collect:
            return None
        try:
            batches, stats = _fast_collect_selected_uv_state(context)
        except Exception:
            batches, stats = [], None
        if not batches or not stats:
            return None
        try:
            pivot_uv = g._selected_uv_pivot(context, stats)
            pivot_region = g._view_to_region(context.region, pivot_uv) if pivot_uv is not None else None
        except Exception:
            return None
        if pivot_region is None or pivot_uv is None:
            return None
        _GIZMO_CACHE.update({'key': key, 'stats': stats, 'batches': batches, 'pivot_uv': pivot_uv, 'pivot_region': pivot_region, 'stamp': time.monotonic()})
    mode = _gizmo_mode_from_region_1850(context, event, pivot_region)
    if mode is None:
        return None
    return {'mode': mode, 'batches': batches, 'stats': stats, 'pivot_uv': pivot_uv, 'pivot_region': pivot_region}


def _start_gizmo_modal_1850(self, context, event, state):
    try:
        from . import uv_gizmo_grip_fix as g
        mode = str(state.get('mode') or '')
        batches = state.get('batches') or []
        pivot_uv = state.get('pivot_uv')
        if not mode or pivot_uv is None or not batches:
            return {'PASS_THROUGH'}
        _record_axis_from_mode(context, mode)
        self._area = context.area; self._region = context.region
        self._suv1850_kind = 'GIZMO'
        self._batches = _cache_batches(context, batches)
        self._pivot_uv = pivot_uv
        self._mode = mode
        self._start_mouse_view = g._region_to_view(self._region, event.mouse_region_x, event.mouse_region_y)
        self._start_vector = self._start_mouse_view - self._pivot_uv
        self._suv1845_last_delta_key = None
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    except Exception:
        return {'PASS_THROUGH'}


def _modal_apply_gizmo_1850(self, context, event):
    try:
        cur = _region_to_uv(context, event)
        if cur is None: return {'RUNNING_MODAL'}
        mode = str(getattr(self, '_mode', '') or '')
        if mode.startswith('MOVE'):
            delta = cur - self._start_mouse_view
            if mode == 'MOVE_X': delta.y = 0.0
            elif mode == 'MOVE_Y': delta.x = 0.0
            delta = _snap_delta(context, delta)
            key = _delta_key(delta)
            if key is not None and key == getattr(self, '_suv1845_last_delta_key', None):
                return {'RUNNING_MODAL'}
            self._suv1845_last_delta_key = key
            _apply_cached_delta(context, getattr(self, '_batches', []) or [], delta)
            return {'RUNNING_MODAL'}
        pivot = getattr(self, '_pivot_uv', None)
        if pivot is None: return {'RUNNING_MODAL'}
        v = cur - pivot
        if mode == 'SCALE_UNIFORM':
            sv = getattr(self, '_start_vector', Vector((0,0)))
            scale = max(1.0e-5, min(100000.0, max(float(v.length), 1.0e-8) / max(float(sv.length), 1.0e-8)))
            _apply_cached_transform(context, getattr(self, '_batches', []) or [], lambda original: pivot + (original - pivot) * scale)
        elif mode == 'ROTATE':
            sv = getattr(self, '_start_vector', Vector((0,0)))
            if float(sv.length) > 1.0e-8 and float(v.length) > 1.0e-8:
                ang = atan2(float(v.y), float(v.x)) - atan2(float(sv.y), float(sv.x))
                c = cos(ang); s = sin(ang)
                def rot(original):
                    r = original - pivot
                    return Vector((pivot.x + r.x * c - r.y * s, pivot.y + r.x * s + r.y * c))
                _apply_cached_transform(context, getattr(self, '_batches', []) or [], rot)
        return {'RUNNING_MODAL'}
    except Exception:
        return {'FINISHED'}


def _instant_modal_1850(self, context, event):
    etype = str(getattr(event, 'type', '') or ''); evalue = str(getattr(event, 'value', '') or '')
    if etype in {'ESC', 'RIGHTMOUSE'}:
        if str(getattr(self, '_suv1850_kind', '')) == 'GIZMO':
            try: _apply_cached_transform(context, getattr(self, '_batches', []) or [], lambda original: original.copy())
            except Exception: pass
        return {'CANCELLED'}
    if etype == 'LEFTMOUSE' and evalue == 'RELEASE':
        return {'FINISHED'}
    if etype in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
        if str(getattr(self, '_suv1850_kind', '')) == 'GIZMO':
            return _modal_apply_gizmo_1850(self, context, event)
        return _instant_modal(self, context, event)
    return {'RUNNING_MODAL'}


def _instant_invoke_1850(self, context, event):
    enabled = _pg('_sus_1635_immediate_enabled')
    try:
        if callable(enabled) and not enabled(context): return {'PASS_THROUGH'}
    except Exception:
        return {'PASS_THROUGH'}
    if str(getattr(event, 'type', '')) != 'LEFTMOUSE' or str(getattr(event, 'value', '')) != 'PRESS': return {'PASS_THROUGH'}
    if not _is_uv_context(context): return {'PASS_THROUGH'}
    if bool(getattr(event, 'alt', False) or getattr(event, 'oskey', False)): return {'PASS_THROUGH'}
    # If a fresh gizmo cache says the pointer is on a handle, own it here too.
    state = _gizmo_press_state_1850(context, event, allow_collect=False)
    if state is not None:
        return _start_gizmo_modal_1850(self, context, event, state)
    hit = _find_hit_fast(context, event)
    if not hit: return {'PASS_THROUGH'}
    selected = _hit_selected_fast(context, hit)
    if selected and not bool(getattr(event, 'shift', False) or getattr(event, 'ctrl', False)):
        return {'PASS_THROUGH'}
    if not _select_hit_fast(context, hit, event): return {'PASS_THROUGH'}
    batches = _target_records_from_hit(context, hit, select=False)
    stats = _build_stats_from_batches(batches)
    if stats is not None:
        try: _update_gizmo_cache(context, batches, stats)
        except Exception: pass
    batches = _cache_batches(context, batches)
    if not batches: return {'PASS_THROUGH'}
    try:
        self._suv1850_kind = 'INSTANT'
        self._suv1845_batches = batches
        self._suv1845_start_uv = _region_to_uv(context, event)
        self._suv1845_start_xy = (int(getattr(event, 'mouse_region_x', 0) or 0), int(getattr(event, 'mouse_region_y', 0) or 0))
        self._suv1845_dragging = False
        self._suv1845_last_delta_key = None
        self._suv1845_axis = _get_axis(context) if _axis_enabled(context) else 'FREE'
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    except Exception:
        return {'FINISHED'}


def _patch_gizmo_module():  # type: ignore[no-redef]
    try:
        from . import uv_gizmo_grip_fix as g
    except Exception:
        return
    try:
        g._SUS_1835_KEYMAP_NAMES = tuple(_GIZMO_KEYMAP_DEFS_1850)
        g._NATIVE_GIZMO_KEYMAP_NAMES = tuple(n for n, _s in _GIZMO_KEYMAP_DEFS_1850 if n != 'Image')
        g._log = lambda message: None
        g._collect_selected_uv_state = _fast_collect_selected_uv_state
        g._hit_test_fallback_area = _gizmo_mode_from_region_1850
        g._snap_uv_delta_relative_to_cursor = lambda context, delta: _snap_delta(context, delta)
        op = g.JELARARAGI_OT_uv_gizmo_grip_fix_grab
        op.invoke = lambda self, context, event: (_start_gizmo_modal_1850(self, context, event, _gizmo_press_state_1850(context, event, allow_collect=True)) if _gizmo_press_state_1850(context, event, allow_collect=True) is not None else {'PASS_THROUGH'})
        op.modal = lambda self, context, event: _instant_modal_1850(self, context, event)
        op._apply_to_uvs = lambda self, context, func: _apply_cached_transform(context, getattr(self, '_batches', []) or [], func)
        op._restore_original_uvs = lambda self, context: _apply_cached_transform(context, getattr(self, '_batches', []) or [], lambda original: original.copy())
    except Exception:
        pass


def _patch_instant_class():  # type: ignore[no-redef]
    try:
        cls = _pg('SMARTUVSUITE_OT_instant_select_drag_move')
        if not isinstance(cls, type): return
        cls.bl_options = {'UNDO', 'BLOCKING'}
        cls.invoke = _instant_invoke_1850
        cls.modal = _instant_modal_1850
        cls._find_uv_hit = lambda self, context, event: _find_hit_fast(context, event)
        cls._select_uv_hit_immediate = lambda self, context, event, hit=None: _select_hit_fast(context, hit or _find_hit_fast(context, event), event)
        cls._hit_is_current_selection = lambda self, context, hit: _hit_selected_fast(context, hit)
        cls._integrated_uv_gizmo_grip_should_own_press = lambda self, context, event: bool(_gizmo_press_state_1850(context, event, allow_collect=False))
    except Exception:
        pass


def _gizmo_enable_minimal():  # type: ignore[no-redef]
    try:
        from . import uv_gizmo_grip_fix as g
        g._ENABLED = True
        for handler_name in ('_load_post_reapply',):
            try:
                h = getattr(g, handler_name, None)
                if h in bpy.app.handlers.load_post: _suv_resource.handler_remove(bpy.app.handlers.load_post, h)
            except Exception: pass
        try:
            t = getattr(g, '_deferred_reapply_timer', None)
            if callable(t) and _suv_resource.timer_is_registered(t): _suv_resource.timer_unregister(t)
        except Exception: pass
    except Exception: pass
    _ensure_gizmo_keymaps_1850(True)
    _remove_obsolete_keymap_rows()


def _gizmo_disable_minimal(*, delete: bool = False):  # type: ignore[no-redef]
    try:
        from . import uv_gizmo_grip_fix as g
        g._ENABLED = False
    except Exception: pass
    if delete: _delete_rows_for_id_1850('smart_uv_suite.uv_gizmo_grip_fix_grab')
    else: _set_gizmo_keymaps_1850_active(False)
    _remove_obsolete_keymap_rows()


def _apply_keymap_defs():  # type: ignore[no-redef]
    try:
        if isinstance(_PG, dict):
            _PG['_SUS_1830_INSTANT_KEYMAP_DEFS'] = tuple(_INSTANT_KEYMAP_DEFS)
            _PG['_SUS_1832_INSTANT_KEYMAP_DEFS'] = tuple(_INSTANT_KEYMAP_DEFS)
            _PG['_SUS_1834_INSTANT_KEYMAP_DEFS'] = tuple(_INSTANT_KEYMAP_DEFS)
            _PG['_SUS_1635_INSTANT_SELECT_KEYMAP_NAMES'] = tuple(name for name, _sp in _INSTANT_KEYMAP_DEFS)
            _PG['_sus_1652_ensure_instant_keymaps'] = _ensure_minimal_instant_keymaps
            _PG['_sus_1652_promote_instant_keymaps_to_head'] = _ensure_minimal_instant_keymaps
            _PG['_sus_1652_set_instant_keymaps_active'] = _set_minimal_instant_keymaps_active
            _PG['_sus_1652_delete_instant_keymaps'] = _delete_minimal_instant_keymaps
            _PG['_sus_1652_gizmo_enable'] = _gizmo_enable_minimal
            _PG['_sus_1652_gizmo_disable'] = _gizmo_disable_minimal
            _PG['_sus_1835_find_uv_hit'] = _find_hit_fast
            _PG['_sus_1835_select_hit'] = _select_hit_fast
            _PG['_sus_1835_hit_selected'] = _hit_selected_fast
            _PG['_SUS_1850_GIZMO_KEYMAP_DEFS'] = tuple(_GIZMO_KEYMAP_DEFS_1850)
    except Exception: pass


def apply_all(pkg_globals=None, context=None):  # type: ignore[no-redef]
    global _PG
    if pkg_globals is not None: _PG = pkg_globals
    try:
        if isinstance(_PG, dict):
            bi = _PG.get('bl_info')
            if isinstance(bi, dict): bi['version'] = (1, 0, 0)
            _PG['_sus_1674_apply_axis_memory'] = _apply_axis_memory_public
    except Exception: pass
    _apply_keymap_defs(); _patch_gizmo_module(); _patch_instant_class()
    try:
        ws = _PG.get('_sus_1652_ws')(context or bpy.context) if isinstance(_PG, dict) and callable(_PG.get('_sus_1652_ws')) else None
        if ws is not None:
            if bool(getattr(ws, 'operation_instant_select_enabled', False)): _ensure_minimal_instant_keymaps(active=True)
            else: _set_minimal_instant_keymaps_active(False)
            if bool(getattr(ws, 'operation_uv_gizmo_grip_fix_enabled', False)): _gizmo_enable_minimal()
            else: _gizmo_disable_minimal(delete=False)
    except Exception: pass
    _remove_obsolete_keymap_rows()
    try:
        if callable(_ORIG_AXIS_TIMER_UPDATE): _ORIG_AXIS_TIMER_UPDATE(context or bpy.context)
    except Exception: pass


def install(pkg_globals):  # type: ignore[no-redef]
    global _PG, _INSTALLED, _PREV_SYNC
    _PG = pkg_globals
    if not _INSTALLED:
        _PREV_SYNC = pkg_globals.get('_sus_1652_sync_keymaps_from_workspace')
        def _sync(context=None):
            ctx = context or bpy.context
            try:
                if callable(_PREV_SYNC): _PREV_SYNC(ctx)
            except RecursionError: pass
            except Exception: pass
            apply_all(pkg_globals, ctx)
        pkg_globals['_sus_1652_sync_keymaps_from_workspace'] = _sync
        _INSTALLED = True
    apply_all(pkg_globals, bpy.context)

# 1.8.50c: if Image keymap evaluates Immediate Select before the Image gizmo
# guard, Immediate Select must still detect and start the gizmo helper.  This is
# a correctness-first path for dense scenes; the selected-state scan is cached
# and only performed on press, never during drag.

def _instant_invoke_1850(self, context, event):  # type: ignore[no-redef]
    enabled = _pg('_sus_1635_immediate_enabled')
    try:
        if callable(enabled) and not enabled(context): return {'PASS_THROUGH'}
    except Exception:
        return {'PASS_THROUGH'}
    if str(getattr(event, 'type', '')) != 'LEFTMOUSE' or str(getattr(event, 'value', '')) != 'PRESS': return {'PASS_THROUGH'}
    if not _is_uv_context(context): return {'PASS_THROUGH'}
    if bool(getattr(event, 'alt', False) or getattr(event, 'oskey', False)): return {'PASS_THROUGH'}
    # Full handle test before UV hit testing.  This prevents Immediate Select
    # from stealing U/V axis handles even if its Image keymap is evaluated first.
    state = _gizmo_press_state_1850(context, event, allow_collect=True)
    if state is not None:
        return _start_gizmo_modal_1850(self, context, event, state)
    hit = _find_hit_fast(context, event)
    if not hit: return {'PASS_THROUGH'}
    selected = _hit_selected_fast(context, hit)
    if selected and not bool(getattr(event, 'shift', False) or getattr(event, 'ctrl', False)):
        return {'PASS_THROUGH'}
    if not _select_hit_fast(context, hit, event): return {'PASS_THROUGH'}
    batches = _target_records_from_hit(context, hit, select=False)
    stats = _build_stats_from_batches(batches)
    if stats is not None:
        try: _update_gizmo_cache(context, batches, stats)
        except Exception: pass
    batches = _cache_batches(context, batches)
    if not batches: return {'PASS_THROUGH'}
    try:
        self._suv1850_kind = 'INSTANT'
        self._suv1845_batches = batches
        self._suv1845_start_uv = _region_to_uv(context, event)
        self._suv1845_start_xy = (int(getattr(event, 'mouse_region_x', 0) or 0), int(getattr(event, 'mouse_region_y', 0) or 0))
        self._suv1845_dragging = False
        self._suv1845_last_delta_key = None
        self._suv1845_axis = _get_axis(context) if _axis_enabled(context) else 'FREE'
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    except Exception:
        return {'FINISHED'}

# Re-patch class once more so the 1.8.50c invoke wins over every previous layer.

def _patch_gizmo_module():  # type: ignore[no-redef]
    try:
        from . import uv_gizmo_grip_fix as g
    except Exception:
        return
    try:
        g._SUS_1835_KEYMAP_NAMES = tuple(_GIZMO_KEYMAP_DEFS_1850)
        g._NATIVE_GIZMO_KEYMAP_NAMES = tuple(n for n, _s in _GIZMO_KEYMAP_DEFS_1850 if n != 'Image')
        g._log = lambda message: None
        g._collect_selected_uv_state = _fast_collect_selected_uv_state
        g._hit_test_fallback_area = _gizmo_mode_from_region_1850
        g._snap_uv_delta_relative_to_cursor = lambda context, delta: _snap_delta(context, delta)
        def _invoke_1850(self, context, event):
            if str(getattr(event, 'type', '')) != 'LEFTMOUSE' or str(getattr(event, 'value', '')) != 'PRESS':
                return {'PASS_THROUGH'}
            try:
                if g._event_has_selection_modifier(event) or not g.is_enabled():
                    return {'PASS_THROUGH'}
                if not g._is_uv_editor_context(context) or not hasattr(context.region, 'view2d'):
                    return {'PASS_THROUGH'}
            except Exception:
                return {'PASS_THROUGH'}
            state = _gizmo_press_state_1850(context, event, allow_collect=True)
            if state is None:
                return {'PASS_THROUGH'}
            return _start_gizmo_modal_1850(self, context, event, state)
        op = g.JELARARAGI_OT_uv_gizmo_grip_fix_grab
        op.invoke = _invoke_1850
        op.modal = lambda self, context, event: _instant_modal_1850(self, context, event)
        op._apply_to_uvs = lambda self, context, func: _apply_cached_transform(context, getattr(self, '_batches', []) or [], func)
        op._restore_original_uvs = lambda self, context: _apply_cached_transform(context, getattr(self, '_batches', []) or [], lambda original: original.copy())
    except Exception:
        pass

# -----------------------------------------------------------------------------
# 1.8.51: definitive gizmo-grab priority and dense-scene stability.
# -----------------------------------------------------------------------------
# The 1.8.50 layer made Immediate Select detect gizmo handles, but the fallback
# hit-test could recurse after uv_gizmo_grip_fix._hit_test_fallback_area was
# patched to the same function.  This layer removes that recursion, keeps the
# visible U/V/center/scale/rotate handles grabbable even when Immediate Select is
# evaluated first, and preserves direct cached UV transforms so no nested native
# transform.translate call is started from this add-on.

_SUS1851_VERSION = (1, 8, 51)
_GIZMO_ORIG_HIT_TEST_1851 = None


def _gizmo_mode_from_region_1851(context, event, pivot_region):
    try:
        from . import uv_gizmo_grip_fix as g
        scale = g._hit_scale(context)
    except Exception:
        scale = 1.0
    try:
        dx = float(event.mouse_region_x) - float(pivot_region.x)
        dy = float(event.mouse_region_y) - float(pivot_region.y)
        r = (dx * dx + dy * dy) ** 0.5
        # Axis handles must win over the center hit.  The bands are intentionally
        # broad enough for high-DPI / tablet input and dense scenes where the
        # native handle can be visually hard to grab.
        axis_min = 5.0 * scale
        axis_max = 180.0 * scale
        axis_radius = 22.0 * scale
        if axis_min <= dx <= axis_max and abs(dy) <= axis_radius:
            return 'MOVE_X'
        if axis_min <= dy <= axis_max and abs(dx) <= axis_radius:
            return 'MOVE_Y'
        if r <= 24.0 * scale:
            return 'MOVE'
        if 30.0 * scale <= r <= 140.0 * scale and abs(abs(dx) - abs(dy)) <= 24.0 * scale and dx * dy > 0:
            return 'SCALE_UNIFORM'
        if 56.0 * scale <= r <= 150.0 * scale:
            return 'ROTATE'
    except Exception:
        pass
    # Safe fallback to the original helper if it was saved before patching.  Do
    # not call uv_gizmo_grip_fix._hit_test_fallback_area here because that name
    # is patched to this wrapper and would recurse.
    try:
        fn = globals().get('_GIZMO_ORIG_HIT_TEST_1851')
        if callable(fn) and fn not in {_gizmo_mode_from_region_1851, _gizmo_mode_from_region_1850}:
            return fn(context, event, pivot_region)
    except Exception:
        pass
    return None

# Make all existing references use the non-recursive version.
_gizmo_mode_from_region_1850 = _gizmo_mode_from_region_1851  # type: ignore[assignment]


def _gizmo_press_state_1851(context, event, allow_collect=True):
    if not _is_uv_context(context):
        return None
    try:
        from . import uv_gizmo_grip_fix as g
        if not g.is_enabled():
            return None
    except Exception:
        return None
    key = _cache_key(context)
    batches = _GIZMO_CACHE.get('batches') if _GIZMO_CACHE.get('key') == key else None
    stats = _GIZMO_CACHE.get('stats') if _GIZMO_CACHE.get('key') == key else None
    pivot_uv = _GIZMO_CACHE.get('pivot_uv') if _GIZMO_CACHE.get('key') == key else None
    pivot_region = _GIZMO_CACHE.get('pivot_region') if _GIZMO_CACHE.get('key') == key else None
    try:
        if pivot_region is not None and time.monotonic() - float(_GIZMO_CACHE.get('stamp', 0.0)) > 8.0:
            pivot_region = None
    except Exception:
        pivot_region = None
    if pivot_region is None or not batches or stats is None:
        if not allow_collect:
            return None
        try:
            batches, stats = _fast_collect_selected_uv_state(context)
        except Exception:
            batches, stats = [], None
        if not batches or stats is None:
            return None
        try:
            pivot_uv = g._selected_uv_pivot(context, stats)
            pivot_region = g._view_to_region(context.region, pivot_uv) if pivot_uv is not None else None
        except Exception:
            return None
        if pivot_uv is None or pivot_region is None:
            return None
        _GIZMO_CACHE.update({'key': key, 'stats': stats, 'batches': batches, 'pivot_uv': pivot_uv, 'pivot_region': pivot_region, 'stamp': time.monotonic()})
    mode = _gizmo_mode_from_region_1851(context, event, pivot_region)
    if mode is None:
        return None
    return {'mode': mode, 'batches': batches, 'stats': stats, 'pivot_uv': pivot_uv, 'pivot_region': pivot_region}


def _start_gizmo_modal_1851(self, context, event, state):
    # Same behavior as 1.8.50, but always caches refs at press and records the
    # remembered axis before any immediate-select path can consume the event.
    try:
        from . import uv_gizmo_grip_fix as g
        mode = str((state or {}).get('mode') or '')
        batches = (state or {}).get('batches') or []
        pivot_uv = (state or {}).get('pivot_uv')
        if not mode or pivot_uv is None or not batches:
            return {'PASS_THROUGH'}
        _record_axis_from_mode(context, mode)
        self._area = context.area
        self._region = context.region
        self._suv1850_kind = 'GIZMO'
        self._batches = _cache_batches(context, batches)
        self._pivot_uv = pivot_uv
        self._mode = mode
        self._start_mouse_view = g._region_to_view(self._region, event.mouse_region_x, event.mouse_region_y)
        self._start_vector = self._start_mouse_view - self._pivot_uv
        self._suv1845_last_delta_key = None
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    except Exception:
        return {'PASS_THROUGH'}


def _instant_invoke_1851(self, context, event):
    enabled = _pg('_sus_1635_immediate_enabled')
    try:
        if callable(enabled) and not enabled(context):
            return {'PASS_THROUGH'}
    except Exception:
        return {'PASS_THROUGH'}
    if str(getattr(event, 'type', '')) != 'LEFTMOUSE' or str(getattr(event, 'value', '')) != 'PRESS':
        return {'PASS_THROUGH'}
    if not _is_uv_context(context):
        return {'PASS_THROUGH'}
    if bool(getattr(event, 'alt', False) or getattr(event, 'oskey', False)):
        return {'PASS_THROUGH'}
    # 1) Gizmo handle test first.  This is the critical fix when Immediate Select
    # and Gizmo Grip are both enabled: U/V/center/scale/rotate handles are never
    # consumed as UV hit-selection events.
    state = _gizmo_press_state_1851(context, event, allow_collect=True)
    if state is not None:
        return _start_gizmo_modal_1851(self, context, event, state)
    # 2) Otherwise perform press-select + direct move exactly as before.
    hit = _find_hit_fast(context, event)
    if not hit:
        return {'PASS_THROUGH'}
    selected = _hit_selected_fast(context, hit)
    if selected and not bool(getattr(event, 'shift', False) or getattr(event, 'ctrl', False)):
        # Do not steal existing selection or native gizmo/tweak operations.
        return {'PASS_THROUGH'}
    if not _select_hit_fast(context, hit, event):
        return {'PASS_THROUGH'}
    batches = _target_records_from_hit(context, hit, select=False)
    stats = _build_stats_from_batches(batches)
    if stats is not None:
        try:
            _update_gizmo_cache(context, batches, stats)
        except Exception:
            pass
    batches = _cache_batches(context, batches)
    if not batches:
        return {'PASS_THROUGH'}
    try:
        self._suv1850_kind = 'INSTANT'
        self._suv1845_batches = batches
        self._suv1845_start_uv = _region_to_uv(context, event)
        self._suv1845_start_xy = (int(getattr(event, 'mouse_region_x', 0) or 0), int(getattr(event, 'mouse_region_y', 0) or 0))
        self._suv1845_dragging = False
        self._suv1845_last_delta_key = None
        self._suv1845_axis = _get_axis(context) if _axis_enabled(context) else 'FREE'
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    except Exception:
        return {'FINISHED'}


def _patch_gizmo_module_1851():
    global _GIZMO_ORIG_HIT_TEST_1851
    try:
        from . import uv_gizmo_grip_fix as g
    except Exception:
        return
    try:
        current_hit = getattr(g, '_hit_test_fallback_area', None)
        if callable(current_hit) and current_hit not in {_gizmo_mode_from_region_1851, _gizmo_mode_from_region_1850}:
            _GIZMO_ORIG_HIT_TEST_1851 = current_hit
        g._SUS_1835_KEYMAP_NAMES = tuple(_GIZMO_KEYMAP_DEFS_1850)
        g._NATIVE_GIZMO_KEYMAP_NAMES = tuple(n for n, _s in _GIZMO_KEYMAP_DEFS_1850 if n != 'Image')
        g._log = lambda message: None
        g._collect_selected_uv_state = _fast_collect_selected_uv_state
        g._hit_test_fallback_area = _gizmo_mode_from_region_1851
        g._snap_uv_delta_relative_to_cursor = lambda context, delta: _snap_delta(context, delta)
        def _invoke_1851(self, context, event):
            if str(getattr(event, 'type', '')) != 'LEFTMOUSE' or str(getattr(event, 'value', '')) != 'PRESS':
                return {'PASS_THROUGH'}
            try:
                if g._event_has_selection_modifier(event) or not g.is_enabled():
                    return {'PASS_THROUGH'}
                if not g._is_uv_editor_context(context) or not hasattr(context.region, 'view2d'):
                    return {'PASS_THROUGH'}
            except Exception:
                return {'PASS_THROUGH'}
            state = _gizmo_press_state_1851(context, event, allow_collect=True)
            if state is None:
                return {'PASS_THROUGH'}
            return _start_gizmo_modal_1851(self, context, event, state)
        op = g.JELARARAGI_OT_uv_gizmo_grip_fix_grab
        op.invoke = _invoke_1851
        op.modal = lambda self, context, event: _instant_modal_1850(self, context, event)
        op._apply_to_uvs = lambda self, context, func: _apply_cached_transform(context, getattr(self, '_batches', []) or [], func)
        op._restore_original_uvs = lambda self, context: _apply_cached_transform(context, getattr(self, '_batches', []) or [], lambda original: original.copy())
    except Exception:
        pass


def _patch_instant_class_1851():
    try:
        cls = _pg('SMARTUVSUITE_OT_instant_select_drag_move')
        if not isinstance(cls, type):
            return
        cls.bl_options = {'UNDO', 'BLOCKING'}
        cls.invoke = _instant_invoke_1851
        cls.modal = _instant_modal_1850
        cls._integrated_uv_gizmo_grip_should_own_press = lambda self, context, event: bool(_gizmo_press_state_1851(context, event, allow_collect=False))
        cls._sus1851_final = True
    except Exception:
        pass


def apply_all(pkg_globals=None, context=None):  # type: ignore[no-redef]
    global _PG
    if pkg_globals is not None:
        _PG = pkg_globals
    try:
        if isinstance(_PG, dict):
            bi = _PG.get('bl_info')
            if isinstance(bi, dict):
                bi['version'] = (1, 0, 0)
            _PG['_sus_1674_apply_axis_memory'] = _apply_axis_memory_public
    except Exception:
        pass
    _apply_keymap_defs()
    _patch_gizmo_module_1851()
    _patch_instant_class_1851()
    try:
        ws = _PG.get('_sus_1652_ws')(context or bpy.context) if isinstance(_PG, dict) and callable(_PG.get('_sus_1652_ws')) else None
        if ws is not None:
            if bool(getattr(ws, 'operation_instant_select_enabled', False)):
                _ensure_minimal_instant_keymaps(active=True)
            else:
                _set_minimal_instant_keymaps_active(False)
            if bool(getattr(ws, 'operation_uv_gizmo_grip_fix_enabled', False)):
                _gizmo_enable_minimal()
            else:
                _gizmo_disable_minimal(delete=False)
    except Exception:
        pass
    _remove_obsolete_keymap_rows()
    try:
        if callable(_ORIG_AXIS_TIMER_UPDATE):
            _ORIG_AXIS_TIMER_UPDATE(context or bpy.context)
    except Exception:
        pass
    _patch_gizmo_module_1851()
    _patch_instant_class_1851()


def install(pkg_globals):  # type: ignore[no-redef]
    global _PG, _INSTALLED, _PREV_SYNC
    _PG = pkg_globals
    if not _INSTALLED:
        _PREV_SYNC = pkg_globals.get('_sus_1652_sync_keymaps_from_workspace')
        def _sync(context=None):
            ctx = context or bpy.context
            try:
                if callable(_PREV_SYNC):
                    _PREV_SYNC(ctx)
            except RecursionError:
                pass
            except Exception:
                pass
            apply_all(pkg_globals, ctx)
        pkg_globals['_sus_1652_sync_keymaps_from_workspace'] = _sync
        _INSTALLED = True
    apply_all(pkg_globals, bpy.context)

# -----------------------------------------------------------------------------
# 1.8.52: native-gizmo-hover-safe interaction final layer.
# -----------------------------------------------------------------------------
# The previous layer still installed the custom fallback operator into Generic
# Gizmo maps.  In Blender 5.1 this can prevent the native gizmo group from
# entering its own hover/press path in dense UV scenes.  This final layer restores
# native gizmo precedence: Generic Gizmo maps are reserved for Blender's native
# gizmo_tweak entries, while Smart UV's fallback grab exists only in Image/UV
# editor maps and runs after a handle test.  Immediate Select also tests the
# handle first and passes through, so it cannot steal U/V axis handles.

_SUS1852_VERSION = (1, 8, 52)
_INSTANT_KEYMAP_DEFS_1852 = (
    ("UV Editor", "EMPTY"),
    ("Image", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Tweak", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Move", "IMAGE_EDITOR"),
)
_GIZMO_FALLBACK_KEYMAP_DEFS_1852 = (
    ("Image", "IMAGE_EDITOR"),
)
_NATIVE_GIZMO_KEYMAP_NAMES_1852 = (
    "Generic Gizmo",
    "Generic Gizmo Drag",
    "Generic Gizmo Click Drag",
    "Generic Gizmo Maybe Drag",
    "Generic Gizmo Select",
)


def _iter_keyconfigs_1852():
    # Native/default/user keyconfigs are foreign resources.
    return ()


def _configure_native_gizmo_press_1852(kmi) -> None:
    # Match the original standalone helper's safe setting: native gizmo handles
    # must activate on PRESS and accept modifier states.  This does not create a
    # Smart UV transform op; it only restores Blender's native hover/press path.
    try:
        if getattr(kmi, "type", None) == "LEFTMOUSE":
            _suv_resource.keymap_item_set(kmi, 'value', 'PRESS')
    except Exception:
        pass
    try:
        _suv_resource.keymap_item_set(kmi, 'any', True)
    except Exception:
        pass
    for mod in ("shift", "ctrl", "alt", "oskey", "hyper"):
        try:
            _suv_resource.keymap_item_set(kmi, mod, -1)
        except Exception:
            pass
    try:
        __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, True)
    except Exception:
        pass


def _patch_native_gizmo_keymaps_1852() -> int:
    # Native keymaps are foreign resources.
    return (0, 0)


def _remove_conflicting_gizmo_fallback_rows_1852() -> None:
    # Remove only Smart UV's custom fallback op from Generic Gizmo maps.  Leave
    # Blender's native  rows intact so hover highlighting and
    # native U/V handles work normally.
    # Remove no rows by ID. Exact owned teardown is handled by the ownership ledger.
    return 0


def _read_mesh_select_loop_indices_1852(mesh, mode: str):
    selected = set()
    try:
        polys = list(getattr(mesh, "polygons", []) or [])
        if mode in {"FACE", "ISLAND"}:
            for p in polys:
                try:
                    if bool(getattr(p, "select", False)):
                        selected.update(range(int(p.loop_start), int(p.loop_start) + int(p.loop_total)))
                except Exception:
                    pass
        elif mode == "EDGE":
            edges = getattr(mesh, "edges", []) or []
            sel_edges = {i for i, e in enumerate(edges) if bool(getattr(e, "select", False))}
            if sel_edges:
                for p in polys:
                    try:
                        edge_keys = list(getattr(p, "edge_keys", []) or [])
                        loop_start = int(p.loop_start)
                        for local, ekey in enumerate(edge_keys):
                            # Mesh polygon does not expose edge index directly in
                            # every build; use edge_keys as fallback.
                            pass
                    except Exception:
                        pass
                # More reliable BMesh fallback below will handle edge selection.
        else:
            verts = getattr(mesh, "vertices", []) or []
            sel_verts = {i for i, v in enumerate(verts) if bool(getattr(v, "select", False))}
            if sel_verts:
                for p in polys:
                    try:
                        verts_idx = list(getattr(p, "vertices", []) or [])
                        for local, vi in enumerate(verts_idx):
                            if int(vi) in sel_verts:
                                selected.add(int(p.loop_start) + int(local))
                    except Exception:
                        pass
    except Exception:
        pass
    return selected


def _collect_selected_uv_state_1852(context, anchor_uv=None):
    # First use the existing exact UV-selection collector.  It is fastest when
    # Blender exposes .uv_select_* attributes and preserves all previous behavior.
    try:
        batches, stats = _fast_collect_selected_uv_state(context, anchor_uv=anchor_uv)
        if batches and stats is not None:
            return batches, stats
    except TypeError:
        try:
            batches, stats = _fast_collect_selected_uv_state(context)
            if batches and stats is not None:
                return batches, stats
        except Exception:
            pass
    except Exception:
        pass

    # Fallback for UV Select Sync ON or builds where .uv_select_* are not written
    # until release: read live mesh selection but emit UV loop records only.  This
    # fallback is used mainly for gizmo pivot/handle ownership, so it must not
    # expand a partial UV element to a whole island.
    try:
        import bmesh
    except Exception:
        return [], None
    mode = _uv_mode(context)
    record_map = {}
    seen = set()
    for obj in _iter_edit_mesh_objects(context):
        mesh = getattr(obj, "data", None)
        if mesh is None:
            continue
        try:
            bm = bmesh.from_edit_mesh(mesh)
            bm.faces.ensure_lookup_table()
            uv_layer = bm.loops.layers.uv.active
            if uv_layer is None:
                continue
            uv_name = str(getattr(uv_layer, "name", "") or "")
        except Exception:
            continue
        recs = record_map.setdefault((mesh, uv_name), [])
        for fi, f in enumerate(bm.faces):
            if getattr(f, "hide", False):
                continue
            loops = tuple(f.loops)
            face_sel = bool(getattr(f, "select", False))
            for local, l in enumerate(loops):
                try:
                    if mode in {"FACE", "ISLAND"}:
                        sel = face_sel
                    elif mode == "EDGE":
                        sel = bool(getattr(l.edge, "select", False))
                    else:
                        sel = bool(getattr(l.vert, "select", False))
                    if not sel:
                        continue
                    _add_record(recs, seen, mesh, uv_name, f, l, uv_layer, fi, local)
                    if mode == "EDGE":
                        try:
                            _add_record(recs, seen, mesh, uv_name, f, l.link_loop_next, uv_layer, fi, (local + 1) % len(loops))
                        except Exception:
                            pass
                except Exception:
                    continue
    return _build_batches_from_records(record_map)


def _gizmo_press_state_1852(context, event, allow_collect=True):
    if not _is_uv_context(context):
        return None
    try:
        from . import uv_gizmo_grip_fix as g
        if not g.is_enabled():
            return None
    except Exception:
        return None
    key = _cache_key(context)
    batches = _GIZMO_CACHE.get("batches") if _GIZMO_CACHE.get("key") == key else None
    stats = _GIZMO_CACHE.get("stats") if _GIZMO_CACHE.get("key") == key else None
    pivot_uv = _GIZMO_CACHE.get("pivot_uv") if _GIZMO_CACHE.get("key") == key else None
    pivot_region = _GIZMO_CACHE.get("pivot_region") if _GIZMO_CACHE.get("key") == key else None
    try:
        if pivot_region is not None and time.monotonic() - float(_GIZMO_CACHE.get("stamp", 0.0)) > 2.0:
            pivot_region = None
    except Exception:
        pivot_region = None
    if pivot_region is None or not batches or stats is None:
        if not allow_collect:
            return None
        try:
            mouse_uv = _region_to_uv(context, event)
        except Exception:
            mouse_uv = None
        batches, stats = _collect_selected_uv_state_1852(context, anchor_uv=mouse_uv)
        if not batches or stats is None:
            return None
        try:
            pivot_uv = g._selected_uv_pivot(context, stats)
            pivot_region = g._view_to_region(context.region, pivot_uv) if pivot_uv is not None else None
        except Exception:
            return None
        if pivot_uv is None or pivot_region is None:
            return None
        _GIZMO_CACHE.update({"key": key, "stats": stats, "batches": batches, "pivot_uv": pivot_uv, "pivot_region": pivot_region, "stamp": time.monotonic()})
    mode = _gizmo_mode_from_region_1851(context, event, pivot_region)
    if mode is None:
        return None
    return {"mode": mode, "batches": batches, "stats": stats, "pivot_uv": pivot_uv, "pivot_region": pivot_region}


def _start_gizmo_modal_1852(self, context, event, state):
    try:
        from . import uv_gizmo_grip_fix as g
        mode = str((state or {}).get("mode") or "")
        batches = (state or {}).get("batches") or []
        pivot_uv = (state or {}).get("pivot_uv")
        if not mode or pivot_uv is None or not batches:
            return {"PASS_THROUGH"}
        _record_axis_from_mode(context, mode)
        self._area = context.area
        self._region = context.region
        self._suv1850_kind = "GIZMO"
        self._batches = _cache_batches(context, batches)
        self._pivot_uv = pivot_uv
        self._mode = mode
        self._start_mouse_view = g._region_to_view(self._region, event.mouse_region_x, event.mouse_region_y)
        self._start_vector = self._start_mouse_view - self._pivot_uv
        self._suv1845_last_delta_key = None
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}
    except Exception:
        return {"PASS_THROUGH"}


def _instant_invoke_1852(self, context, event):
    enabled = _pg("_sus_1635_immediate_enabled")
    try:
        if callable(enabled) and not enabled(context):
            return {"PASS_THROUGH"}
    except Exception:
        return {"PASS_THROUGH"}
    if str(getattr(event, "type", "")) != "LEFTMOUSE" or str(getattr(event, "value", "")) != "PRESS":
        return {"PASS_THROUGH"}
    if not _is_uv_context(context):
        return {"PASS_THROUGH"}
    if bool(getattr(event, "alt", False) or getattr(event, "oskey", False)):
        return {"PASS_THROUGH"}

    # Native gizmo hover/press must win.  When the cursor is on a real handle,
    # Immediate Select only passes through.  The Image-map fallback gizmo operator
    # can still run later if Blender's native gizmo did not consume the event.
    if _gizmo_press_state_1852(context, event, allow_collect=True) is not None:
        return {"PASS_THROUGH"}

    hit = _find_hit_fast(context, event)
    if not hit:
        return {"PASS_THROUGH"}
    selected = _hit_selected_fast(context, hit)
    if selected and not bool(getattr(event, "shift", False) or getattr(event, "ctrl", False)):
        return {"PASS_THROUGH"}
    if not _select_hit_fast(context, hit, event):
        return {"PASS_THROUGH"}
    batches = _target_records_from_hit(context, hit, select=False)
    stats = _build_stats_from_batches(batches)
    if stats is not None:
        try:
            _update_gizmo_cache(context, batches, stats)
        except Exception:
            pass
    batches = _cache_batches(context, batches)
    if not batches:
        return {"PASS_THROUGH"}
    try:
        self._suv1850_kind = "INSTANT"
        self._suv1845_batches = batches
        self._suv1845_start_uv = _region_to_uv(context, event)
        self._suv1845_start_xy = (int(getattr(event, "mouse_region_x", 0) or 0), int(getattr(event, "mouse_region_y", 0) or 0))
        self._suv1845_dragging = False
        self._suv1845_last_delta_key = None
        self._suv1845_axis = _get_axis(context) if _axis_enabled(context) else "FREE"
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}
    except Exception:
        return {"FINISHED"}


def _patch_gizmo_module_1852():
    try:
        from . import uv_gizmo_grip_fix as g
    except Exception:
        return
    try:
        g._SUS_1835_KEYMAP_NAMES = tuple(_GIZMO_FALLBACK_KEYMAP_DEFS_1852)
        g._NATIVE_GIZMO_KEYMAP_NAMES = tuple(_NATIVE_GIZMO_KEYMAP_NAMES_1852)
        g._log = lambda message: None
        g._collect_selected_uv_state = _collect_selected_uv_state_1852
        g._hit_test_fallback_area = _gizmo_mode_from_region_1851
        g._snap_uv_delta_relative_to_cursor = lambda context, delta: _snap_delta(context, delta)
        def _register_keymaps_1852():
            # Only custom fallback in Image.  Generic Gizmo remains native.
            _patch_native_gizmo_keymaps_1852()
            return _ensure_keymaps_for_defs("smart_uv_suite.uv_gizmo_grip_fix_grab", _GIZMO_FALLBACK_KEYMAP_DEFS_1852, active=True, head=True)
        g._register_keymaps = _register_keymaps_1852
        g._sus_1835_register_keymaps = _register_keymaps_1852
        def _invoke_1852(self, context, event):
            if str(getattr(event, "type", "")) != "LEFTMOUSE" or str(getattr(event, "value", "")) != "PRESS":
                return {"PASS_THROUGH"}
            try:
                if g._event_has_selection_modifier(event) or not g.is_enabled():
                    return {"PASS_THROUGH"}
                if not g._is_uv_editor_context(context) or not hasattr(context.region, "view2d"):
                    return {"PASS_THROUGH"}
            except Exception:
                return {"PASS_THROUGH"}
            state = _gizmo_press_state_1852(context, event, allow_collect=True)
            if state is None:
                return {"PASS_THROUGH"}
            return _start_gizmo_modal_1852(self, context, event, state)
        op = g.JELARARAGI_OT_uv_gizmo_grip_fix_grab
        op.invoke = _invoke_1852
        op.modal = lambda self, context, event: _instant_modal_1850(self, context, event)
        op._apply_to_uvs = lambda self, context, func: _apply_cached_transform(context, getattr(self, "_batches", []) or [], func)
        op._restore_original_uvs = lambda self, context: _apply_cached_transform(context, getattr(self, "_batches", []) or [], lambda original: original.copy())
    except Exception:
        pass


def _patch_instant_class_1852():
    try:
        cls = _pg("SMARTUVSUITE_OT_instant_select_drag_move")
        if not isinstance(cls, type):
            return
        cls.bl_options = {'UNDO', 'BLOCKING'}
        cls.invoke = _instant_invoke_1852
        cls.modal = _instant_modal_1850
        cls._integrated_uv_gizmo_grip_should_own_press = lambda self, context, event: bool(_gizmo_press_state_1852(context, event, allow_collect=False))
        cls._sus1852_final = True
    except Exception:
        pass


def _ensure_instant_keymaps_1852(*, active: bool = True):
    return _ensure_ordered_keymaps_1850("smart_uv_suite.instant_select_drag_move", _INSTANT_KEYMAP_DEFS_1852, active=active, head=True)


def _set_instant_keymaps_1852_active(active: bool):
    if active:
        return _ensure_instant_keymaps_1852(active=True)
    return _set_keymaps_for_defs_active("smart_uv_suite.instant_select_drag_move", _INSTANT_KEYMAP_DEFS_1852, False)


def _gizmo_enable_1852():
    try:
        from . import uv_gizmo_grip_fix as g
        try:
            g._ENABLED = True
        except Exception:
            pass
    except Exception:
        pass
    _patch_native_gizmo_keymaps_1852()
    _ensure_keymaps_for_defs("smart_uv_suite.uv_gizmo_grip_fix_grab", _GIZMO_FALLBACK_KEYMAP_DEFS_1852, active=True, head=True)
    _remove_conflicting_gizmo_fallback_rows_1852()


def _gizmo_disable_1852(*, delete: bool = False):
    try:
        from . import uv_gizmo_grip_fix as g
        try:
            g._ENABLED = False
        except Exception:
            pass
    except Exception:
        pass
    if delete:
        _delete_keymaps_for_defs("smart_uv_suite.uv_gizmo_grip_fix_grab", _GIZMO_FALLBACK_KEYMAP_DEFS_1852)
    else:
        _set_keymaps_for_defs_active("smart_uv_suite.uv_gizmo_grip_fix_grab", _GIZMO_FALLBACK_KEYMAP_DEFS_1852, False)
    _remove_conflicting_gizmo_fallback_rows_1852()


def _apply_keymap_defs_1852():
    try:
        if isinstance(_PG, dict):
            _PG["_SUS_1830_INSTANT_KEYMAP_DEFS"] = tuple(_INSTANT_KEYMAP_DEFS_1852)
            _PG["_SUS_1832_INSTANT_KEYMAP_DEFS"] = tuple(_INSTANT_KEYMAP_DEFS_1852)
            _PG["_SUS_1834_INSTANT_KEYMAP_DEFS"] = tuple(_INSTANT_KEYMAP_DEFS_1852)
            _PG["_SUS_1850_GIZMO_KEYMAP_DEFS"] = tuple(_GIZMO_FALLBACK_KEYMAP_DEFS_1852)
            _PG["_sus_1830_keymap_defs"] = lambda: tuple(_INSTANT_KEYMAP_DEFS_1852)
            _PG["_sus_1834_keymap_defs"] = lambda: tuple(_INSTANT_KEYMAP_DEFS_1852)
            _PG["_sus_1835_collect_batches"] = lambda context, hit=None: (_target_records_from_hit(context, hit, select=False) if hit else _collect_selected_uv_state_1852(context)[0])
            _PG["_sus_1652_ensure_instant_keymaps"] = _ensure_instant_keymaps_1852
            _PG["_sus_1652_promote_instant_keymaps_to_head"] = _ensure_instant_keymaps_1852
            _PG["_sus_1652_set_instant_keymaps_active"] = _set_instant_keymaps_1852_active
            _PG["_sus_1652_gizmo_enable"] = _gizmo_enable_1852
            _PG["_sus_1652_gizmo_disable"] = _gizmo_disable_1852
    except Exception:
        pass


def apply_all(pkg_globals=None, context=None):  # type: ignore[no-redef]
    global _PG
    if pkg_globals is not None:
        _PG = pkg_globals
    try:
        if isinstance(_PG, dict):
            bi = _PG.get("bl_info")
            if isinstance(bi, dict):
                bi["version"] = (1, 0, 0)
            _PG["_sus_1674_apply_axis_memory"] = _apply_axis_memory_public
    except Exception:
        pass
    _apply_keymap_defs_1852()
    _patch_native_gizmo_keymaps_1852()
    _patch_gizmo_module_1852()
    _patch_instant_class_1852()
    try:
        ws = _PG.get("_sus_1652_ws")(context or bpy.context) if isinstance(_PG, dict) and callable(_PG.get("_sus_1652_ws")) else None
        if ws is not None:
            if bool(getattr(ws, "operation_instant_select_enabled", False)):
                _ensure_instant_keymaps_1852(active=True)
            else:
                _set_instant_keymaps_1852_active(False)
            if bool(getattr(ws, "operation_uv_gizmo_grip_fix_enabled", False)):
                _gizmo_enable_1852()
            else:
                _gizmo_disable_1852(delete=False)
    except Exception:
        pass
    _remove_conflicting_gizmo_fallback_rows_1852()
    _patch_gizmo_module_1852()
    _patch_instant_class_1852()


def install(pkg_globals):  # type: ignore[no-redef]
    global _PG, _INSTALLED, _PREV_SYNC
    _PG = pkg_globals
    if not _INSTALLED:
        _PREV_SYNC = pkg_globals.get("_sus_1652_sync_keymaps_from_workspace")
        def _sync(context=None):
            ctx = context or bpy.context
            try:
                if callable(_PREV_SYNC):
                    _PREV_SYNC(ctx)
            except RecursionError:
                pass
            except Exception:
                pass
            apply_all(pkg_globals, ctx)
        pkg_globals["_sus_1652_sync_keymaps_from_workspace"] = _sync
        _INSTALLED = True
    apply_all(pkg_globals, bpy.context)

# -----------------------------------------------------------------------------
# 1.8.53: restore native gizmo_tweak rows for actual Blender gizmo hover.
# -----------------------------------------------------------------------------
# In headless tests Blender's keyconfigs may not contain Generic Gizmo native
# rows by default.  The standalone JELararagi UV Gizmo Grip Fix created addon
#  rows for Generic Gizmo maps.  Removing those rows made
# the Smart UV fallback responsible for handle detection, which cannot reproduce
# Blender's native hover highlight.  This layer restores native rows while still
# keeping Smart UV's custom fallback out of Generic Gizmo maps.

_SUS1853_VERSION = (1, 8, 53)


def _ensure_native_gizmo_rows_1853(active=True) -> tuple[int, int]:
    del active
    return (0, 0)


def _set_native_gizmo_rows_1853_active(active: bool) -> tuple[int, int]:
    del active
    return None


def _remove_conflicting_gizmo_fallback_rows_1852():  # type: ignore[no-redef]
    # Remove no rows by ID. Exact owned teardown is handled by the ownership ledger.
    return 0


def _gizmo_enable_1852():  # type: ignore[no-redef]
    try:
        from . import uv_gizmo_grip_fix as g
        try: g._ENABLED = True
        except Exception: pass
    except Exception:
        pass
    _patch_native_gizmo_keymaps_1852()
    _ensure_native_gizmo_rows_1853(active=True)
    _ensure_keymaps_for_defs("smart_uv_suite.uv_gizmo_grip_fix_grab", _GIZMO_FALLBACK_KEYMAP_DEFS_1852, active=True, head=True)
    _remove_conflicting_gizmo_fallback_rows_1852()


def _gizmo_disable_1852(*, delete: bool = False):  # type: ignore[no-redef]
    try:
        from . import uv_gizmo_grip_fix as g
        try: g._ENABLED = False
        except Exception: pass
    except Exception:
        pass
    if delete:
        _delete_keymaps_for_defs("smart_uv_suite.uv_gizmo_grip_fix_grab", _GIZMO_FALLBACK_KEYMAP_DEFS_1852)
    else:
        _set_keymaps_for_defs_active("smart_uv_suite.uv_gizmo_grip_fix_grab", _GIZMO_FALLBACK_KEYMAP_DEFS_1852, False)
    _set_native_gizmo_rows_1853_active(False)
    _remove_conflicting_gizmo_fallback_rows_1852()


def _apply_keymap_defs_1852():  # type: ignore[no-redef]
    try:
        if isinstance(_PG, dict):
            _PG["_SUS_1830_INSTANT_KEYMAP_DEFS"] = tuple(_INSTANT_KEYMAP_DEFS_1852)
            _PG["_SUS_1832_INSTANT_KEYMAP_DEFS"] = tuple(_INSTANT_KEYMAP_DEFS_1852)
            _PG["_SUS_1834_INSTANT_KEYMAP_DEFS"] = tuple(_INSTANT_KEYMAP_DEFS_1852)
            _PG["_SUS_1850_GIZMO_KEYMAP_DEFS"] = tuple(_GIZMO_FALLBACK_KEYMAP_DEFS_1852)
            _PG["_SUS_1853_NATIVE_GIZMO_KEYMAP_NAMES"] = tuple(_NATIVE_GIZMO_KEYMAP_NAMES_1852)
            _PG["_sus_1830_keymap_defs"] = lambda: tuple(_INSTANT_KEYMAP_DEFS_1852)
            _PG["_sus_1834_keymap_defs"] = lambda: tuple(_INSTANT_KEYMAP_DEFS_1852)
            _PG["_sus_1835_collect_batches"] = lambda context, hit=None: (_target_records_from_hit(context, hit, select=False) if hit else _collect_selected_uv_state_1852(context)[0])
            _PG["_sus_1652_ensure_instant_keymaps"] = _ensure_instant_keymaps_1852
            _PG["_sus_1652_promote_instant_keymaps_to_head"] = _ensure_instant_keymaps_1852
            _PG["_sus_1652_set_instant_keymaps_active"] = _set_instant_keymaps_1852_active
            _PG["_sus_1652_gizmo_enable"] = _gizmo_enable_1852
            _PG["_sus_1652_gizmo_disable"] = _gizmo_disable_1852
    except Exception:
        pass


def apply_all(pkg_globals=None, context=None):  # type: ignore[no-redef]
    global _PG
    if pkg_globals is not None: _PG = pkg_globals
    try:
        if isinstance(_PG, dict):
            bi = _PG.get("bl_info")
            if isinstance(bi, dict): bi["version"] = (1, 0, 0)
            _PG["_sus_1674_apply_axis_memory"] = _apply_axis_memory_public
    except Exception: pass
    _apply_keymap_defs_1852()
    _patch_native_gizmo_keymaps_1852()
    _patch_gizmo_module_1852()
    _patch_instant_class_1852()
    try:
        ws = _PG.get("_sus_1652_ws")(context or bpy.context) if isinstance(_PG, dict) and callable(_PG.get("_sus_1652_ws")) else None
        if ws is not None:
            if bool(getattr(ws, "operation_instant_select_enabled", False)):
                _ensure_instant_keymaps_1852(active=True)
            else:
                _set_instant_keymaps_1852_active(False)
            if bool(getattr(ws, "operation_uv_gizmo_grip_fix_enabled", False)):
                _gizmo_enable_1852()
            else:
                _gizmo_disable_1852(delete=False)
    except Exception: pass
    _remove_conflicting_gizmo_fallback_rows_1852()
    _patch_gizmo_module_1852(); _patch_instant_class_1852()


def install(pkg_globals):  # type: ignore[no-redef]
    global _PG, _INSTALLED, _PREV_SYNC
    _PG = pkg_globals
    if not _INSTALLED:
        _PREV_SYNC = pkg_globals.get("_sus_1652_sync_keymaps_from_workspace")
        def _sync(context=None):
            ctx = context or bpy.context
            try:
                if callable(_PREV_SYNC): _PREV_SYNC(ctx)
            except RecursionError: pass
            except Exception: pass
            apply_all(pkg_globals, ctx)
        pkg_globals["_sus_1652_sync_keymaps_from_workspace"] = _sync
        _INSTALLED = True
    apply_all(pkg_globals, bpy.context)

# -----------------------------------------------------------------------------
# 1.8.54: zero-lag background pass-through + press-select drag transform fix.
# -----------------------------------------------------------------------------
# Background LMB drags must be returned to Blender immediately so the native box
# selection dashed rectangle appears on the first drag frame.  Therefore this
# final layer never builds selected-gizmo state from Immediate Select before the
# UV hit test, and the custom gizmo fallback no longer scans selected UVs from
# the Image keymap on empty/background presses.  Immediate Select still performs
# PRESS-time selection and owns the modal drag only when a real UV element is hit.

_SUS1854_VERSION = (1, 8, 54)
_INSTANT_KEYMAP_DEFS_1854 = (
    ("UV Editor", "EMPTY"),
    ("Image", "IMAGE_EDITOR"),
    ("Image Generic", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Tweak", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Tweak (fallback)", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Move", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Move (fallback)", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Select Box", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Select Box (fallback)", "IMAGE_EDITOR"),
)
_GIZMO_FALLBACK_KEYMAP_DEFS_1854 = (
    # Fallback exists only as a post-native guard.  It refuses to collect selected
    # UVs unless a valid pivot cache already exists, so it cannot delay native
    # background box-select drawing.
    ("Image", "IMAGE_EDITOR"),
)


def _find_hit_fast_1854(context, event):
    """Fast UV hit with interaction_1844 spatial cache when available."""
    try:
        from . import interaction_1844 as _i44
        try:
            _i44._PG = _PG
        except Exception:
            pass
        hit = _i44._find_uv_hit_fast(context, event)
        if hit is not None:
            return hit
        # If the cache is already valid, a miss is a reliable background miss and
        # should return immediately.  Do not fall back to linear scanning here;
        # that is the source of the visible box-select lag on dense scenes.
        try:
            if getattr(_i44, "_HIT_CACHE", None):
                return None
        except Exception:
            pass
    except Exception:
        pass
    # First hit after enabling may have no cache yet.  Use the existing precise
    # fallback for correctness, but later misses are served by the spatial cache.
    try:
        return _find_hit_fast_linear_1847c(context, event)
    except Exception:
        try:
            return _find_hit_fast(context, event)
        except Exception:
            return None


def _refresh_hit_cache_after_write_1854(context) -> None:
    # Mark interaction_1844's hit cache dirty after Smart UV direct transforms.
    # This keeps immediate-select hit tests correct without rebuilding during
    # every background press.
    try:
        from . import interaction_1844 as _i44
        for batch in list(getattr(context, '_suv_dummy', []) or []):
            pass
        for obj in _iter_edit_mesh_objects(context):
            try:
                mesh = getattr(obj, 'data', None)
                if mesh is not None:
                    _i44._DIRTY_MESH_IDS.add(id(mesh))
            except Exception:
                pass
    except Exception:
        pass


_SUS1854_PREV_APPLY_DELTA = _apply_cached_delta
_SUS1854_PREV_APPLY_TRANSFORM = _apply_cached_transform


def _apply_cached_delta(context, batches, delta: Vector) -> bool:  # type: ignore[no-redef]
    ok = False
    try:
        ok = bool(_SUS1854_PREV_APPLY_DELTA(context, batches, delta))
    except Exception:
        ok = False
    if ok:
        try:
            from . import interaction_1844 as _i44
            for batch in list(batches or []):
                mesh = batch.get('mesh') if isinstance(batch, dict) else None
                if mesh is not None:
                    _i44._DIRTY_MESH_IDS.add(id(mesh))
        except Exception:
            pass
    return ok


def _apply_cached_transform(context, batches, transform_func) -> bool:  # type: ignore[no-redef]
    ok = False
    try:
        ok = bool(_SUS1854_PREV_APPLY_TRANSFORM(context, batches, transform_func))
    except Exception:
        ok = False
    if ok:
        try:
            from . import interaction_1844 as _i44
            for batch in list(batches or []):
                mesh = batch.get('mesh') if isinstance(batch, dict) else None
                if mesh is not None:
                    _i44._DIRTY_MESH_IDS.add(id(mesh))
        except Exception:
            pass
    return ok


def _gizmo_press_state_cached_only_1854(context, event):
    """Return a gizmo state only from an already available selected-pivot cache.

    This is used by Immediate Select and the Image fallback operator.  It never
    collects selected UVs.  Native gizmo handling remains responsible for normal
    hover/press behavior, while this cached fallback can still preserve the
    add-on's U/V/free direct transform when the cache was prepared by a recent
    selection or transform.
    """
    if not _is_uv_context(context):
        return None
    try:
        from . import uv_gizmo_grip_fix as g
        if not g.is_enabled():
            return None
    except Exception:
        return None
    try:
        key = _cache_key(context)
        if _GIZMO_CACHE.get('key') != key:
            return None
        pivot_region = _GIZMO_CACHE.get('pivot_region')
        pivot_uv = _GIZMO_CACHE.get('pivot_uv')
        batches = _GIZMO_CACHE.get('batches') or []
        stats = _GIZMO_CACHE.get('stats')
        if pivot_region is None or pivot_uv is None or not batches or stats is None:
            return None
        # Short, but long enough for selecting then immediately dragging a gizmo.
        if time.monotonic() - float(_GIZMO_CACHE.get('stamp', 0.0)) > 5.0:
            return None
        mode = _gizmo_mode_from_region_1851(context, event, pivot_region)
        if mode is None:
            return None
        return {'mode': mode, 'batches': batches, 'stats': stats, 'pivot_uv': pivot_uv, 'pivot_region': pivot_region}
    except Exception:
        return None


def _instant_invoke_1854(self, context, event):
    enabled = _pg('_sus_1635_immediate_enabled')
    try:
        if callable(enabled) and not enabled(context):
            return {'PASS_THROUGH'}
    except Exception:
        return {'PASS_THROUGH'}
    if str(getattr(event, 'type', '')) != 'LEFTMOUSE' or str(getattr(event, 'value', '')) != 'PRESS':
        return {'PASS_THROUGH'}
    if not _is_uv_context(context):
        return {'PASS_THROUGH'}
    if bool(getattr(event, 'alt', False) or getattr(event, 'oskey', False)):
        return {'PASS_THROUGH'}

    # Do not build selected-gizmo state here.  If native Blender is hovering a
    # gizmo handle it gets the event first/next.  Only a warm cache is allowed to
    # start the add-on fallback.  This removes the background box-select lag.
    state = _gizmo_press_state_cached_only_1854(context, event)
    if state is not None:
        return _start_gizmo_modal_1852(self, context, event, state)

    hit = _find_hit_fast_1854(context, event)
    if not hit:
        return {'PASS_THROUGH'}

    selected = _hit_selected_fast(context, hit)
    if selected and not bool(getattr(event, 'shift', False) or getattr(event, 'ctrl', False)):
        # Existing selected elements should go to native move/gizmo.  We never do
        # selected-state scans here, preserving native hover and box-select speed.
        return {'PASS_THROUGH'}

    if not _select_hit_fast(context, hit, event):
        return {'PASS_THROUGH'}
    batches = _target_records_from_hit(context, hit, select=False)
    stats = _build_stats_from_batches(batches)
    if stats is not None:
        try:
            _update_gizmo_cache(context, batches, stats)
        except Exception:
            pass
    batches = _cache_batches(context, batches)
    if not batches:
        return {'PASS_THROUGH'}
    try:
        self._suv1850_kind = 'INSTANT'
        self._suv1845_batches = batches
        self._suv1845_start_uv = _region_to_uv(context, event)
        self._suv1845_start_xy = (int(getattr(event, 'mouse_region_x', 0) or 0), int(getattr(event, 'mouse_region_y', 0) or 0))
        self._suv1845_dragging = False
        self._suv1845_last_delta_key = None
        self._suv1845_axis = _get_axis(context) if _axis_enabled(context) else 'FREE'
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    except Exception:
        return {'FINISHED'}


def _gizmo_invoke_1854(self, context, event):
    # The Image-map fallback must not collect selected UVs on background press;
    # otherwise box-select starts late.  It starts only from an already warm cache
    # or it passes through immediately to Blender.
    if str(getattr(event, 'type', '')) != 'LEFTMOUSE' or str(getattr(event, 'value', '')) != 'PRESS':
        return {'PASS_THROUGH'}
    try:
        from . import uv_gizmo_grip_fix as g
        if g._event_has_selection_modifier(event) or not g.is_enabled():
            return {'PASS_THROUGH'}
        if not g._is_uv_editor_context(context) or not hasattr(context.region, 'view2d'):
            return {'PASS_THROUGH'}
    except Exception:
        return {'PASS_THROUGH'}
    state = _gizmo_press_state_cached_only_1854(context, event)
    if state is None:
        return {'PASS_THROUGH'}
    return _start_gizmo_modal_1852(self, context, event, state)


def _patch_gizmo_module_1854():
    try:
        _patch_gizmo_module_1852()
    except Exception:
        pass
    try:
        from . import uv_gizmo_grip_fix as g
        g._SUS_1835_KEYMAP_NAMES = tuple(_GIZMO_FALLBACK_KEYMAP_DEFS_1854)
        g._NATIVE_GIZMO_KEYMAP_NAMES = tuple(_NATIVE_GIZMO_KEYMAP_NAMES_1852)
        g._collect_selected_uv_state = _collect_selected_uv_state_1852
        g._hit_test_fallback_area = _gizmo_mode_from_region_1851
        g._snap_uv_delta_relative_to_cursor = lambda context, delta: _snap_delta(context, delta)
        op = g.JELARARAGI_OT_uv_gizmo_grip_fix_grab
        op.invoke = _gizmo_invoke_1854
        op.modal = lambda self, context, event: _instant_modal_1850(self, context, event)
        op._apply_to_uvs = lambda self, context, func: _apply_cached_transform(context, getattr(self, '_batches', []) or [], func)
        op._restore_original_uvs = lambda self, context: _apply_cached_transform(context, getattr(self, '_batches', []) or [], lambda original: original.copy())
    except Exception:
        pass


def _patch_instant_class_1854():
    try:
        cls = _pg('SMARTUVSUITE_OT_instant_select_drag_move')
        if not isinstance(cls, type):
            return
        cls.bl_options = {'UNDO', 'BLOCKING'}
        cls.invoke = _instant_invoke_1854
        cls.modal = _instant_modal_1850
        cls._find_uv_hit = lambda self, context, event: _find_hit_fast_1854(context, event)
        cls._select_uv_hit_immediate = lambda self, context, event, hit=None: _select_hit_fast(context, hit or _find_hit_fast_1854(context, event), event)
        cls._hit_is_current_selection = lambda self, context, hit: _hit_selected_fast(context, hit)
        cls._integrated_uv_gizmo_grip_should_own_press = lambda self, context, event: bool(_gizmo_press_state_cached_only_1854(context, event))
        cls._sus1854_final = True
    except Exception:
        pass


def _ensure_instant_keymaps_1854(*, active: bool = True):
    return _ensure_ordered_keymaps_1850('smart_uv_suite.instant_select_drag_move', _INSTANT_KEYMAP_DEFS_1854, active=active, head=True)


def _set_instant_keymaps_1854_active(active: bool):
    if active:
        return _ensure_instant_keymaps_1854(active=True)
    return _set_keymaps_for_defs_active('smart_uv_suite.instant_select_drag_move', _INSTANT_KEYMAP_DEFS_1854, False)


def _gizmo_enable_1854():
    try:
        from . import uv_gizmo_grip_fix as g
        try: g._ENABLED = True
        except Exception: pass
    except Exception:
        pass
    _patch_native_gizmo_keymaps_1852()
    _ensure_native_gizmo_rows_1853(active=True)
    _ensure_keymaps_for_defs('smart_uv_suite.uv_gizmo_grip_fix_grab', _GIZMO_FALLBACK_KEYMAP_DEFS_1854, active=True, head=False)
    _remove_conflicting_gizmo_fallback_rows_1852()


def _gizmo_disable_1854(*, delete: bool = False):
    try:
        from . import uv_gizmo_grip_fix as g
        try: g._ENABLED = False
        except Exception: pass
    except Exception:
        pass
    if delete:
        _delete_keymaps_for_defs('smart_uv_suite.uv_gizmo_grip_fix_grab', _GIZMO_FALLBACK_KEYMAP_DEFS_1854)
    else:
        _set_keymaps_for_defs_active('smart_uv_suite.uv_gizmo_grip_fix_grab', _GIZMO_FALLBACK_KEYMAP_DEFS_1854, False)
    _set_native_gizmo_rows_1853_active(False)
    _remove_conflicting_gizmo_fallback_rows_1852()


def _apply_keymap_defs_1854():
    try:
        if isinstance(_PG, dict):
            _PG['_SUS_1830_INSTANT_KEYMAP_DEFS'] = tuple(_INSTANT_KEYMAP_DEFS_1854)
            _PG['_SUS_1832_INSTANT_KEYMAP_DEFS'] = tuple(_INSTANT_KEYMAP_DEFS_1854)
            _PG['_SUS_1834_INSTANT_KEYMAP_DEFS'] = tuple(_INSTANT_KEYMAP_DEFS_1854)
            _PG['_SUS_1850_GIZMO_KEYMAP_DEFS'] = tuple(_GIZMO_FALLBACK_KEYMAP_DEFS_1854)
            _PG['_sus_1830_keymap_defs'] = lambda: tuple(_INSTANT_KEYMAP_DEFS_1854)
            _PG['_sus_1834_keymap_defs'] = lambda: tuple(_INSTANT_KEYMAP_DEFS_1854)
            _PG['_sus_1835_find_uv_hit'] = _find_hit_fast_1854
            _PG['_sus_1835_select_hit'] = _select_hit_fast
            _PG['_sus_1835_hit_selected'] = _hit_selected_fast
            _PG['_sus_1835_collect_batches'] = lambda context, hit=None: (_target_records_from_hit(context, hit, select=False) if hit else _collect_selected_uv_state_1852(context)[0])
            _PG['_sus_1652_ensure_instant_keymaps'] = _ensure_instant_keymaps_1854
            _PG['_sus_1652_promote_instant_keymaps_to_head'] = _ensure_instant_keymaps_1854
            _PG['_sus_1652_set_instant_keymaps_active'] = _set_instant_keymaps_1854_active
            _PG['_sus_1652_gizmo_enable'] = _gizmo_enable_1854
            _PG['_sus_1652_gizmo_disable'] = _gizmo_disable_1854
    except Exception:
        pass


def apply_all(pkg_globals=None, context=None):  # type: ignore[no-redef]
    global _PG
    if pkg_globals is not None:
        _PG = pkg_globals
    try:
        if isinstance(_PG, dict):
            bi = _PG.get('bl_info')
            if isinstance(bi, dict):
                bi['version'] = (1, 0, 0)
            _PG['_sus_1674_apply_axis_memory'] = _apply_axis_memory_public
    except Exception:
        pass
    _apply_keymap_defs_1854()
    _patch_native_gizmo_keymaps_1852()
    _patch_gizmo_module_1854()
    _patch_instant_class_1854()
    try:
        ws = _PG.get('_sus_1652_ws')(context or bpy.context) if isinstance(_PG, dict) and callable(_PG.get('_sus_1652_ws')) else None
        if ws is not None:
            if bool(getattr(ws, 'operation_instant_select_enabled', False)):
                _ensure_instant_keymaps_1854(active=True)
            else:
                _set_instant_keymaps_1854_active(False)
            if bool(getattr(ws, 'operation_uv_gizmo_grip_fix_enabled', False)):
                _gizmo_enable_1854()
            else:
                _gizmo_disable_1854(delete=False)
    except Exception:
        pass
    _remove_conflicting_gizmo_fallback_rows_1852()
    _patch_gizmo_module_1854()
    _patch_instant_class_1854()


def install(pkg_globals):  # type: ignore[no-redef]
    global _PG, _INSTALLED, _PREV_SYNC
    _PG = pkg_globals
    if not _INSTALLED:
        _PREV_SYNC = pkg_globals.get('_sus_1652_sync_keymaps_from_workspace')
        def _sync(context=None):
            ctx = context or bpy.context
            try:
                if callable(_PREV_SYNC):
                    _PREV_SYNC(ctx)
            except RecursionError:
                pass
            except Exception:
                pass
            apply_all(pkg_globals, ctx)
        pkg_globals['_sus_1652_sync_keymaps_from_workspace'] = _sync
        _INSTALLED = True
    apply_all(pkg_globals, bpy.context)

# -----------------------------------------------------------------------------
# 1.8.55: stable-record transform cache.
# -----------------------------------------------------------------------------
# BMLoop objects can become invalid as soon as edit-mesh selection is updated or
# Blender redraws.  The previous cached-ref path could therefore stop moving UVs
# after PRESS, or move only part of the selection.  This layer caches only stable
# face/local loop records and resolves them per edited mesh during modal updates.
# It is still O(selected loops), not O(all scene loops), and preserves 1.8.54's
# background pass-through behavior.

_SUS1855_VERSION = (1, 8, 55)


def _cache_batches(context, batches):  # type: ignore[no-redef]
    stable = []
    for batch in list(batches or []):
        if not isinstance(batch, dict):
            continue
        mesh = batch.get('mesh')
        if mesh is None:
            continue
        loops = []
        seen = set()
        for rec in list(batch.get('loops', []) or []):
            try:
                fi, li, original = rec
                key = (int(fi), int(li))
                if key in seen:
                    continue
                seen.add(key)
                loops.append((int(fi), int(li), original.copy()))
            except Exception:
                continue
        if loops:
            stable.append({'mesh': mesh, 'uv_layer_name': str(batch.get('uv_layer_name', '') or ''), 'loops': loops})
    return stable


def _apply_cached_delta(context, batches, delta: Vector) -> bool:  # type: ignore[no-redef]
    try:
        import bmesh
        dx = float(delta.x); dy = float(delta.y)
    except Exception:
        return False
    changed = []
    seen_mesh = set()
    for batch in list(batches or []):
        mesh = batch.get('mesh') if isinstance(batch, dict) else None
        if mesh is None:
            continue
        try:
            bm = bmesh.from_edit_mesh(mesh)
            bm.faces.ensure_lookup_table()
            uv_name = str(batch.get('uv_layer_name', '') or '')
            uv_layer = bm.loops.layers.uv.get(uv_name) if uv_name else None
            if uv_layer is None:
                uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        except Exception:
            continue
        wrote = False
        for fi, li, original in list(batch.get('loops', []) or []):
            try:
                face = bm.faces[int(fi)]
                loops = tuple(face.loops)
                li = int(li)
                if 0 <= li < len(loops):
                    uv = loops[li][uv_layer].uv
                    nx = float(original.x) + dx
                    ny = float(original.y) + dy
                    if uv.x != nx or uv.y != ny:
                        uv.x = nx; uv.y = ny
                    wrote = True
            except Exception:
                continue
        if wrote and id(mesh) not in seen_mesh:
            seen_mesh.add(id(mesh)); changed.append(mesh)
    for mesh in changed:
        try:
            bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        except TypeError:
            try: bmesh.update_edit_mesh(mesh)
            except Exception: pass
        except Exception:
            pass
    if changed:
        try:
            from . import interaction_1844 as _i44
            for mesh in changed:
                _i44._DIRTY_MESH_IDS.add(id(mesh))
        except Exception:
            pass
    try:
        area = getattr(context, 'area', None)
        if area is not None:
            area.tag_redraw()
    except Exception:
        pass
    return bool(changed)


def _apply_cached_transform(context, batches, transform_func) -> bool:  # type: ignore[no-redef]
    try:
        import bmesh
    except Exception:
        return False
    changed = []
    seen_mesh = set()
    for batch in list(batches or []):
        mesh = batch.get('mesh') if isinstance(batch, dict) else None
        if mesh is None:
            continue
        try:
            bm = bmesh.from_edit_mesh(mesh)
            bm.faces.ensure_lookup_table()
            uv_name = str(batch.get('uv_layer_name', '') or '')
            uv_layer = bm.loops.layers.uv.get(uv_name) if uv_name else None
            if uv_layer is None:
                uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        except Exception:
            continue
        wrote = False
        for fi, li, original in list(batch.get('loops', []) or []):
            try:
                face = bm.faces[int(fi)]
                loops = tuple(face.loops)
                li = int(li)
                if 0 <= li < len(loops):
                    loops[li][uv_layer].uv = transform_func(original)
                    wrote = True
            except Exception:
                continue
        if wrote and id(mesh) not in seen_mesh:
            seen_mesh.add(id(mesh)); changed.append(mesh)
    for mesh in changed:
        try:
            bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        except TypeError:
            try: bmesh.update_edit_mesh(mesh)
            except Exception: pass
        except Exception:
            pass
    if changed:
        try:
            from . import interaction_1844 as _i44
            for mesh in changed:
                _i44._DIRTY_MESH_IDS.add(id(mesh))
        except Exception:
            pass
    try:
        area = getattr(context, 'area', None)
        if area is not None:
            area.tag_redraw()
    except Exception:
        pass
    return bool(changed)


def apply_all(pkg_globals=None, context=None):  # type: ignore[no-redef]
    global _PG
    if pkg_globals is not None:
        _PG = pkg_globals
    try:
        if isinstance(_PG, dict):
            bi = _PG.get('bl_info')
            if isinstance(bi, dict):
                bi['version'] = (1, 0, 0)
            _PG['_sus_1674_apply_axis_memory'] = _apply_axis_memory_public
    except Exception:
        pass
    _apply_keymap_defs_1854()
    _patch_native_gizmo_keymaps_1852()
    _patch_gizmo_module_1854()
    _patch_instant_class_1854()
    try:
        ws = _PG.get('_sus_1652_ws')(context or bpy.context) if isinstance(_PG, dict) and callable(_PG.get('_sus_1652_ws')) else None
        if ws is not None:
            if bool(getattr(ws, 'operation_instant_select_enabled', False)):
                _ensure_instant_keymaps_1854(active=True)
            else:
                _set_instant_keymaps_1854_active(False)
            if bool(getattr(ws, 'operation_uv_gizmo_grip_fix_enabled', False)):
                _gizmo_enable_1854()
            else:
                _gizmo_disable_1854(delete=False)
    except Exception:
        pass
    _remove_conflicting_gizmo_fallback_rows_1852()
    _patch_gizmo_module_1854()
    _patch_instant_class_1854()


def install(pkg_globals):  # type: ignore[no-redef]
    global _PG, _INSTALLED, _PREV_SYNC
    _PG = pkg_globals
    if not _INSTALLED:
        _PREV_SYNC = pkg_globals.get('_sus_1652_sync_keymaps_from_workspace')
        def _sync(context=None):
            ctx = context or bpy.context
            try:
                if callable(_PREV_SYNC):
                    _PREV_SYNC(ctx)
            except RecursionError:
                pass
            except Exception:
                pass
            apply_all(pkg_globals, ctx)
        pkg_globals['_sus_1652_sync_keymaps_from_workspace'] = _sync
        _INSTALLED = True
    apply_all(pkg_globals, bpy.context)

# -----------------------------------------------------------------------------
# 1.8.56: exact visible-UV transform target expansion + robust direct snap.
# -----------------------------------------------------------------------------
# This final layer keeps the 1.8.54/1.8.55 behavior, but fixes two production
# issues:
# - UV Gizmo Grip Assist could move only one BMLoop of a visually welded UV
#   vertex, which made part of the selected element appear locked or pull a
#   neighboring corner.  Vertex/edge mode records are now expanded only to the
#   same 3D vertex at the same UV coordinate.  It never expands by UV coordinate
#   alone, so stacked islands and unrelated vertices are not pulled in.
# - Direct Immediate Select drag now uses a local snap implementation that does
#   not depend on use_snap_translate and therefore works in the UV Editor for
#   both UV Select Sync ON and OFF.

_SUS1856_VERSION = (1, 8, 56)
_SUS1856_PREV_FAST_COLLECT = _fast_collect_selected_uv_state
_SUS1856_PREV_COLLECT_1852 = globals().get('_collect_selected_uv_state_1852')


def _uv_grid_step_1856(context):
    """Return a UV movement snap step matching Blender UV editor intent."""
    try:
        fn = _pg('_sus_1674_uv_grid_step')
        if callable(fn):
            step = fn(context)
            if getattr(step, 'x', 0.0) and getattr(step, 'y', 0.0):
                return Vector((max(float(step.x), 1.0e-12), max(float(step.y), 1.0e-12)))
    except Exception:
        pass
    try:
        # Pixel snap if an image is available and the UV snap element requests it.
        elems = _snap_elements_1856(context)
        if 'PIXEL' in elems:
            image = getattr(getattr(context, 'space_data', None), 'image', None)
            size = getattr(image, 'size', None) if image is not None else None
            if size and int(size[0]) > 0 and int(size[1]) > 0:
                return Vector((1.0 / float(size[0]), 1.0 / float(size[1])))
    except Exception:
        pass
    try:
        # Blender stores custom UV subdivisions on the UV editor space.  Use it
        # when available; otherwise derive a visible-grid step from View2D zoom.
        space = getattr(context, 'space_data', None)
        raw = getattr(space, 'custom_grid_subdivisions', None)
        if raw:
            if isinstance(raw, (tuple, list)):
                su = max(int(raw[0]), 1); sv = max(int(raw[1] if len(raw) > 1 else raw[0]), 1)
            else:
                su = sv = max(int(raw), 1)
            return Vector((1.0 / float(su), 1.0 / float(sv)))
    except Exception:
        pass
    try:
        region = getattr(context, 'region', None)
        v2d = getattr(region, 'view2d', None)
        if v2d is not None:
            cx = max(int(getattr(region, 'width', 1024) or 1024) // 2, 1)
            cy = max(int(getattr(region, 'height', 768) or 768) // 2, 1)
            a = Vector(v2d.region_to_view(float(cx), float(cy)))
            b = Vector(v2d.region_to_view(float(cx + 64), float(cy + 64)))
            span_u = abs(float(b.x - a.x)); span_v = abs(float(b.y - a.y))
            def nice(v):
                import math
                v = max(float(v), 1.0e-12)
                p = 10.0 ** math.floor(math.log10(v))
                f = v / p
                if f <= 1.0: n = 1.0
                elif f <= 2.0: n = 2.0
                elif f <= 5.0: n = 5.0
                else: n = 10.0
                return max(n * p, 1.0e-12)
            return Vector((nice(span_u), nice(span_v)))
    except Exception:
        pass
    return Vector((1.0, 1.0))


def _snap_elements_1856(context):
    elems = set()
    try:
        ts = getattr(getattr(context, 'scene', None), 'tool_settings', None)
        if ts is not None:
            for name in ('snap_uv_element', 'snap_elements', 'snap_elements_base'):
                try:
                    raw = getattr(ts, name, None)
                    if isinstance(raw, (set, list, tuple)):
                        elems.update(str(x).upper() for x in raw)
                    elif raw:
                        elems.add(str(raw).upper())
                except Exception:
                    pass
    except Exception:
        pass
    return elems or {'INCREMENT'}


def _snap_enabled_1856(context) -> bool:
    try:
        ts = getattr(getattr(context, 'scene', None), 'tool_settings', None)
        if ts is None:
            return False
        # Blender's UV editor snap does not consistently use use_snap_translate.
        # Do not gate on it here; the direct UV drag is a translate-only path.
        return bool(getattr(ts, 'use_snap_uv', False) or getattr(ts, 'use_snap', False))
    except Exception:
        return False


def _snap_delta_1856(context, delta):
    try:
        if not _snap_enabled_1856(context):
            return delta
        elems = _snap_elements_1856(context)
        if elems and not any(e in elems for e in {'INCREMENT', 'GRID', 'GRID_INCREMENT', 'PIXEL'}):
            return delta
        step = _uv_grid_step_1856(context)
        sx = max(float(step.x), 1.0e-12); sy = max(float(step.y), 1.0e-12)
        return Vector((round(float(delta.x) / sx) * sx, round(float(delta.y) / sy) * sy))
    except Exception:
        return delta


def _snap_delta(context, delta):  # type: ignore[no-redef]
    return _snap_delta_1856(context, delta)


def _expand_batches_same_visible_vertex_1856(context, batches):
    mode = _uv_mode(context)
    if mode not in {'VERTEX', 'EDGE'}:
        return batches
    try:
        import bmesh
    except Exception:
        return batches
    expanded = []
    for batch in list(batches or []):
        if not isinstance(batch, dict):
            continue
        mesh = batch.get('mesh')
        if mesh is None:
            expanded.append(batch); continue
        try:
            bm = bmesh.from_edit_mesh(mesh)
            bm.faces.ensure_lookup_table()
            uv_name = str(batch.get('uv_layer_name', '') or '')
            uv_layer = bm.loops.layers.uv.get(uv_name) if uv_name else None
            if uv_layer is None:
                uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        except Exception:
            expanded.append(batch); continue
        recs = []
        seen = set()
        def add_loop(face, loop):
            try:
                fi = _face_index(face, 0)
                li = _loop_local(face, loop, 0)
                key = (id(mesh), int(fi), int(li))
                if key in seen:
                    return
                seen.add(key)
                recs.append((int(fi), int(li), loop[uv_layer].uv.copy()))
            except Exception:
                pass
        def expand_loop(loop):
            try:
                target_vert = loop.vert
                target_uv = loop[uv_layer].uv.copy()
                for other in list(getattr(target_vert, 'link_loops', []) or []):
                    try:
                        f = other.face
                        if getattr(f, 'hide', False) or getattr(other.vert, 'hide', False) or getattr(other.edge, 'hide', False):
                            continue
                        if _uv_close(other[uv_layer].uv, target_uv):
                            add_loop(f, other)
                    except Exception:
                        continue
            except Exception:
                pass
        for fi, li, original in list(batch.get('loops', []) or []):
            try:
                f = bm.faces[int(fi)]
                loops = tuple(f.loops)
                li = int(li)
                if 0 <= li < len(loops):
                    expand_loop(loops[li])
            except Exception:
                continue
        if recs:
            expanded.append({'mesh': mesh, 'uv_layer_name': str(getattr(uv_layer, 'name', batch.get('uv_layer_name', '')) or ''), 'loops': recs})
        else:
            expanded.append(batch)
    return expanded


def _fast_collect_selected_uv_state(context, anchor_uv=None):  # type: ignore[no-redef]
    try:
        batches, stats = _SUS1856_PREV_FAST_COLLECT(context, anchor_uv=anchor_uv)
    except TypeError:
        batches, stats = _SUS1856_PREV_FAST_COLLECT(context)
    except Exception:
        batches, stats = [], None
    if batches:
        batches = _expand_batches_same_visible_vertex_1856(context, batches)
        try:
            stats = _build_stats_from_batches(batches)
        except Exception:
            pass
    return batches, stats


def _collect_selected_uv_state_1852(context, anchor_uv=None):  # type: ignore[no-redef]
    try:
        batches, stats = _fast_collect_selected_uv_state(context, anchor_uv=anchor_uv)
        if batches and stats is not None:
            return batches, stats
    except Exception:
        pass
    if callable(_SUS1856_PREV_COLLECT_1852):
        try:
            batches, stats = _SUS1856_PREV_COLLECT_1852(context, anchor_uv=anchor_uv)
            if batches:
                batches = _expand_batches_same_visible_vertex_1856(context, batches)
                try: stats = _build_stats_from_batches(batches)
                except Exception: pass
            return batches, stats
        except TypeError:
            try:
                batches, stats = _SUS1856_PREV_COLLECT_1852(context)
                if batches:
                    batches = _expand_batches_same_visible_vertex_1856(context, batches)
                    try: stats = _build_stats_from_batches(batches)
                    except Exception: pass
                return batches, stats
            except Exception:
                pass
        except Exception:
            pass
    return [], None


# Re-wrap the direct apply functions so all direct transforms use the 1.8.56 snap
# path and expanded stable target records.  The actual motion result is unchanged
# except that visually welded selected UV vertices now move as one vertex.
def _modal_apply_gizmo_1850(self, context, event):  # type: ignore[no-redef]
    try:
        cur = _region_to_uv(context, event)
        if cur is None: return {'RUNNING_MODAL'}
        mode = str(getattr(self, '_mode', '') or '')
        if mode.startswith('MOVE'):
            delta = cur - self._start_mouse_view
            if mode == 'MOVE_X': delta.y = 0.0
            elif mode == 'MOVE_Y': delta.x = 0.0
            delta = _snap_delta_1856(context, delta)
            key = _delta_key(delta)
            if key is not None and key == getattr(self, '_suv1845_last_delta_key', None):
                return {'RUNNING_MODAL'}
            self._suv1845_last_delta_key = key
            _apply_cached_delta(context, getattr(self, '_batches', []) or [], delta)
            return {'RUNNING_MODAL'}
        pivot = getattr(self, '_pivot_uv', None)
        if pivot is None: return {'RUNNING_MODAL'}
        v = cur - pivot
        if mode == 'SCALE_UNIFORM':
            sv = getattr(self, '_start_vector', Vector((0,0)))
            scale = max(1.0e-5, min(100000.0, max(float(v.length), 1.0e-8) / max(float(sv.length), 1.0e-8)))
            _apply_cached_transform(context, getattr(self, '_batches', []) or [], lambda original: pivot + (original - pivot) * scale)
        elif mode == 'ROTATE':
            sv = getattr(self, '_start_vector', Vector((0,0)))
            if float(sv.length) > 1.0e-8 and float(v.length) > 1.0e-8:
                ang = atan2(float(v.y), float(v.x)) - atan2(float(sv.y), float(sv.x))
                c = cos(ang); s = sin(ang)
                def rot(original):
                    r = original - pivot
                    return Vector((pivot.x + r.x * c - r.y * s, pivot.y + r.x * s + r.y * c))
                _apply_cached_transform(context, getattr(self, '_batches', []) or [], rot)
        return {'RUNNING_MODAL'}
    except Exception:
        return {'FINISHED'}


def _instant_modal_1850(self, context, event):  # type: ignore[no-redef]
    etype = str(getattr(event, 'type', '') or ''); evalue = str(getattr(event, 'value', '') or '')
    if etype in {'ESC', 'RIGHTMOUSE'}:
        if str(getattr(self, '_suv1850_kind', '')) == 'GIZMO':
            try: _apply_cached_transform(context, getattr(self, '_batches', []) or [], lambda original: original.copy())
            except Exception: pass
        return {'CANCELLED'}
    if etype == 'LEFTMOUSE' and evalue == 'RELEASE':
        return {'FINISHED'}
    if etype in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
        if str(getattr(self, '_suv1850_kind', '')) == 'GIZMO':
            return _modal_apply_gizmo_1850(self, context, event)
        return _instant_modal(self, context, event)
    return {'RUNNING_MODAL'}


def _instant_modal(self, context, event):  # type: ignore[no-redef]
    etype = str(getattr(event, 'type', '') or '')
    evalue = str(getattr(event, 'value', '') or '')
    if etype in {'ESC', 'RIGHTMOUSE'}:
        return {'CANCELLED'}
    if etype == 'LEFTMOUSE' and evalue == 'RELEASE':
        return {'FINISHED'}
    if etype in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
        try:
            cur = _region_to_uv(context, event)
            start = getattr(self, '_suv1845_start_uv', None)
            if cur is None or start is None:
                return {'RUNNING_MODAL'}
            sx, sy = getattr(self, '_suv1845_start_xy', (0, 0))
            dx = int(getattr(event, 'mouse_region_x', 0) or 0) - int(sx)
            dy = int(getattr(event, 'mouse_region_y', 0) or 0) - int(sy)
            if not bool(getattr(self, '_suv1845_dragging', False)):
                if dx * dx + dy * dy < 9:
                    return {'RUNNING_MODAL'}
                self._suv1845_dragging = True
            delta = Vector((float(cur.x - start.x), float(cur.y - start.y)))
            delta = _axis_delta(context, delta, getattr(self, '_suv1845_axis', 'FREE'))
            delta = _snap_delta_1856(context, delta)
            key = _delta_key(delta)
            if key is not None and key == getattr(self, '_suv1845_last_delta_key', None):
                return {'RUNNING_MODAL'}
            self._suv1845_last_delta_key = key
            _apply_cached_delta(context, getattr(self, '_suv1845_batches', []), delta)
            return {'RUNNING_MODAL'}
        except Exception:
            return {'FINISHED'}
    return {'RUNNING_MODAL'}


def _patch_gizmo_module_1854():  # type: ignore[no-redef]
    try:
        _patch_gizmo_module_1852()
    except Exception:
        pass
    try:
        from . import uv_gizmo_grip_fix as g
        g._SUS_1835_KEYMAP_NAMES = tuple(_GIZMO_FALLBACK_KEYMAP_DEFS_1854)
        g._NATIVE_GIZMO_KEYMAP_NAMES = tuple(_NATIVE_GIZMO_KEYMAP_NAMES_1852)
        g._collect_selected_uv_state = _collect_selected_uv_state_1852
        g._hit_test_fallback_area = _gizmo_mode_from_region_1851
        g._snap_uv_delta_relative_to_cursor = lambda context, delta: _snap_delta_1856(context, delta)
        op = g.JELARARAGI_OT_uv_gizmo_grip_fix_grab
        op.invoke = _gizmo_invoke_1854
        op.modal = lambda self, context, event: _instant_modal_1850(self, context, event)
        op._apply_to_uvs = lambda self, context, func: _apply_cached_transform(context, getattr(self, '_batches', []) or [], func)
        op._restore_original_uvs = lambda self, context: _apply_cached_transform(context, getattr(self, '_batches', []) or [], lambda original: original.copy())
    except Exception:
        pass


def _patch_gizmo_module_1852():  # type: ignore[no-redef]
    try:
        from . import uv_gizmo_grip_fix as g
    except Exception:
        return
    try:
        g._SUS_1835_KEYMAP_NAMES = tuple(_GIZMO_FALLBACK_KEYMAP_DEFS_1852)
        g._NATIVE_GIZMO_KEYMAP_NAMES = tuple(_NATIVE_GIZMO_KEYMAP_NAMES_1852)
        g._log = lambda message: None
        g._collect_selected_uv_state = _collect_selected_uv_state_1852
        g._hit_test_fallback_area = _gizmo_mode_from_region_1851
        g._snap_uv_delta_relative_to_cursor = lambda context, delta: _snap_delta_1856(context, delta)
        def _register_keymaps_1852():
            _patch_native_gizmo_keymaps_1852()
            return _ensure_keymaps_for_defs('smart_uv_suite.uv_gizmo_grip_fix_grab', _GIZMO_FALLBACK_KEYMAP_DEFS_1852, active=True, head=True)
        g._register_keymaps = _register_keymaps_1852
        g._sus_1835_register_keymaps = _register_keymaps_1852
        def _invoke_1852(self, context, event):
            if str(getattr(event, 'type', '')) != 'LEFTMOUSE' or str(getattr(event, 'value', '')) != 'PRESS':
                return {'PASS_THROUGH'}
            try:
                if g._event_has_selection_modifier(event) or not g.is_enabled():
                    return {'PASS_THROUGH'}
                if not g._is_uv_editor_context(context) or not hasattr(context.region, 'view2d'):
                    return {'PASS_THROUGH'}
            except Exception:
                return {'PASS_THROUGH'}
            state = _gizmo_press_state_1852(context, event, allow_collect=True)
            if state is None:
                return {'PASS_THROUGH'}
            return _start_gizmo_modal_1852(self, context, event, state)
        op = g.JELARARAGI_OT_uv_gizmo_grip_fix_grab
        op.invoke = _invoke_1852
        op.modal = lambda self, context, event: _instant_modal_1850(self, context, event)
        op._apply_to_uvs = lambda self, context, func: _apply_cached_transform(context, getattr(self, '_batches', []) or [], func)
        op._restore_original_uvs = lambda self, context: _apply_cached_transform(context, getattr(self, '_batches', []) or [], lambda original: original.copy())
    except Exception:
        pass


def _apply_keymap_defs_1852():  # type: ignore[no-redef]
    try:
        if isinstance(_PG, dict):
            _PG['_SUS_1830_INSTANT_KEYMAP_DEFS'] = tuple(_INSTANT_KEYMAP_DEFS_1854)
            _PG['_SUS_1832_INSTANT_KEYMAP_DEFS'] = tuple(_INSTANT_KEYMAP_DEFS_1854)
            _PG['_SUS_1834_INSTANT_KEYMAP_DEFS'] = tuple(_INSTANT_KEYMAP_DEFS_1854)
            _PG['_SUS_1850_GIZMO_KEYMAP_DEFS'] = tuple(_GIZMO_FALLBACK_KEYMAP_DEFS_1854)
            _PG['_SUS_1853_NATIVE_GIZMO_KEYMAP_NAMES'] = tuple(_NATIVE_GIZMO_KEYMAP_NAMES_1852)
            _PG['_sus_1830_keymap_defs'] = lambda: tuple(_INSTANT_KEYMAP_DEFS_1854)
            _PG['_sus_1834_keymap_defs'] = lambda: tuple(_INSTANT_KEYMAP_DEFS_1854)
            _PG['_sus_1835_collect_batches'] = lambda context, hit=None: (_target_records_from_hit(context, hit, select=False) if hit else _collect_selected_uv_state_1852(context)[0])
            _PG['_sus_1652_ensure_instant_keymaps'] = _ensure_instant_keymaps_1854
            _PG['_sus_1652_promote_instant_keymaps_to_head'] = _ensure_instant_keymaps_1854
            _PG['_sus_1652_set_instant_keymaps_active'] = _set_instant_keymaps_1854_active
            _PG['_sus_1652_gizmo_enable'] = _gizmo_enable_1852
            _PG['_sus_1652_gizmo_disable'] = _gizmo_disable_1852
            _PG['_sus_1674_snap_delta'] = _snap_delta_1856
    except Exception:
        pass


def apply_all(pkg_globals=None, context=None):  # type: ignore[no-redef]
    global _PG
    if pkg_globals is not None:
        _PG = pkg_globals
    try:
        if isinstance(_PG, dict):
            bi = _PG.get('bl_info')
            if isinstance(bi, dict):
                bi['version'] = (1, 0, 0)
            _PG['_sus_1674_apply_axis_memory'] = _apply_axis_memory_public
            _PG['_sus_1674_snap_delta'] = _snap_delta_1856
    except Exception:
        pass
    _apply_keymap_defs_1852()
    _patch_native_gizmo_keymaps_1852()
    _patch_gizmo_module_1854()
    _patch_instant_class_1854()
    try:
        ws = _PG.get('_sus_1652_ws')(context or bpy.context) if isinstance(_PG, dict) and callable(_PG.get('_sus_1652_ws')) else None
        if ws is not None:
            if bool(getattr(ws, 'operation_instant_select_enabled', False)):
                _ensure_instant_keymaps_1854(active=True)
            else:
                _set_instant_keymaps_1854_active(False)
            if bool(getattr(ws, 'operation_uv_gizmo_grip_fix_enabled', False)):
                _gizmo_enable_1852()
            else:
                _gizmo_disable_1852(delete=False)
    except Exception:
        pass
    _remove_conflicting_gizmo_fallback_rows_1852()
    _patch_gizmo_module_1854()
    _patch_instant_class_1854()


def install(pkg_globals):  # type: ignore[no-redef]
    global _PG, _INSTALLED, _PREV_SYNC
    _PG = pkg_globals
    if not _INSTALLED:
        _PREV_SYNC = pkg_globals.get('_sus_1652_sync_keymaps_from_workspace')
        def _sync(context=None):
            ctx = context or bpy.context
            try:
                if callable(_PREV_SYNC):
                    _PREV_SYNC(ctx)
            except RecursionError:
                pass
            except Exception:
                pass
            apply_all(pkg_globals, ctx)
        pkg_globals['_sus_1652_sync_keymaps_from_workspace'] = _sync
        _INSTALLED = True
    apply_all(pkg_globals, bpy.context)

# -----------------------------------------------------------------------------
# 1.8.56b: final sync-lock so older compatibility sync callbacks cannot restore
# interaction_1840/1841 methods after checkbox changes.
# -----------------------------------------------------------------------------
_SUS1856B_PREV_APPLY_ALL = apply_all

def _sus1856b_sync(context=None):
    try:
        _SUS1856B_PREV_APPLY_ALL(_PG, context or bpy.context)
    except Exception:
        pass


def _sus1856b_install_sync_hooks() -> None:
    try:
        if isinstance(_PG, dict):
            _PG['_sus_1652_sync_keymaps_from_workspace'] = _sus1856b_sync
            # Older sync functions call these apply hooks after running their own
            # compatibility paths.  Redirect them to the final 1.8.56 layer so a
            # property-toggle cannot restore interaction_1840/1841 behavior.
            _PG['_sus_1841_final_apply'] = lambda context=None: _sus1856b_sync(context)
            _PG['_sus_1842_apply'] = lambda context=None: _sus1856b_sync(context)
            _PG['_sus_1845_apply'] = lambda context=None: _sus1856b_sync(context)
    except Exception:
        pass


def apply_all(pkg_globals=None, context=None):  # type: ignore[no-redef]
    global _PG
    if pkg_globals is not None:
        _PG = pkg_globals
    try:
        _SUS1856B_PREV_APPLY_ALL(_PG, context or bpy.context)
    except Exception:
        pass
    try:
        if isinstance(_PG, dict):
            bi = _PG.get('bl_info')
            if isinstance(bi, dict):
                bi['version'] = (1, 0, 0)
            _PG['_sus_1674_snap_delta'] = _snap_delta_1856
    except Exception:
        pass
    _sus1856b_install_sync_hooks()


def install(pkg_globals):  # type: ignore[no-redef]
    global _PG, _INSTALLED, _PREV_SYNC
    _PG = pkg_globals
    if not _INSTALLED:
        _PREV_SYNC = pkg_globals.get('_sus_1652_sync_keymaps_from_workspace')
        _INSTALLED = True
    apply_all(pkg_globals, bpy.context)

# 1.8.56c: strict UV-selection-only gizmo target collector.
# Do not fall back to mesh vertex/edge/face selection for the custom gizmo helper.
# UV Select Sync can select one 3D vertex that owns several separated UV loops;
# using mesh selection as fallback is the path that pulls remote split UVs.  If
# explicit UV selection cannot be read, the helper passes through to Blender's
# native gizmo instead of guessing.
def _collect_selected_uv_state_1852(context, anchor_uv=None):  # type: ignore[no-redef]
    try:
        batches, stats = _fast_collect_selected_uv_state(context, anchor_uv=anchor_uv)
        if batches:
            return batches, stats
    except Exception:
        pass
    return [], None


def apply_all(pkg_globals=None, context=None):  # type: ignore[no-redef]
    global _PG
    if pkg_globals is not None:
        _PG = pkg_globals
    try:
        _SUS1856B_PREV_APPLY_ALL(_PG, context or bpy.context)
    except Exception:
        pass
    try:
        if isinstance(_PG, dict):
            bi = _PG.get('bl_info')
            if isinstance(bi, dict):
                bi['version'] = (1, 0, 0)
            _PG['_sus_1674_snap_delta'] = _snap_delta_1856
            _PG['_sus_1835_collect_batches'] = lambda context, hit=None: (_target_records_from_hit(context, hit, select=False) if hit else _collect_selected_uv_state_1852(context)[0])
    except Exception:
        pass
    _sus1856b_install_sync_hooks()
    try:
        _patch_gizmo_module_1854()
        _patch_instant_class_1854()
    except Exception:
        pass


def install(pkg_globals):  # type: ignore[no-redef]
    global _PG, _INSTALLED, _PREV_SYNC
    _PG = pkg_globals
    if not _INSTALLED:
        _PREV_SYNC = pkg_globals.get('_sus_1652_sync_keymaps_from_workspace')
        _INSTALLED = True
    apply_all(pkg_globals, bpy.context)


# -----------------------------------------------------------------------------
# 1.8.57: strict selected-loop gizmo targets + anchor-based UV snap.
# -----------------------------------------------------------------------------
# This layer intentionally runs after all previous interaction compatibility
# layers.  It fixes the two production issues reported after 1.8.56:
# 1) UV Gizmo Grip Assist could still transform loops that were not explicitly
#    selected because earlier collectors expanded by visible vertex or fell back to
#    mesh selection.  The custom helper now uses explicit UV selection only and
#    never expands to an island or to mesh-selected split UVs.
# 2) Immediate Select direct-drag used delta rounding.  That preserves an
#    off-grid offset and therefore does not feel like Blender UV snapping.  Direct
#    moves now snap the active anchor point itself to the UV grid/pixel step while
#    preserving axis constraints and 2D-cursor pivot offset.

_SUS1857_VERSION = (1, 8, 57)
_SUS1857_PREV_APPLY_ALL = apply_all


def _collect_selected_uv_state_1857(context, anchor_uv=None):
    """Collect only the UV Editor's explicit selected elements.

    No mesh-selection fallback is used here.  In UV Sync mode a mesh vertex can own
    several separated UV loops; using mesh selection is exactly what pulls remote
    split UV vertices.  If Blender has not exposed explicit UV selection for the
    current mode, the custom gizmo fallback passes through to Blender instead of
    guessing.
    """
    try:
        import bmesh
    except Exception:
        return [], None
    mode = _uv_mode(context)
    record_map = {}
    seen = set()
    for obj in _iter_edit_mesh_objects(context):
        mesh = getattr(obj, 'data', None)
        if mesh is None:
            continue
        try:
            bm = bmesh.from_edit_mesh(mesh)
            bm.faces.ensure_lookup_table()
            uv_layer = bm.loops.layers.uv.active
            if uv_layer is None:
                continue
            uv_name = str(getattr(uv_layer, 'name', '') or '')
        except Exception:
            continue
        recs = record_map.setdefault((mesh, uv_name), [])
        for fi, f in enumerate(bm.faces):
            try:
                if getattr(f, 'hide', False):
                    continue
            except Exception:
                pass
            loops = tuple(f.loops)
            face_selected = _get_f(f)
            for local, l in enumerate(loops):
                try:
                    selected = False
                    if mode in {'FACE', 'ISLAND'}:
                        selected = bool(face_selected)
                    elif mode == 'EDGE':
                        selected = bool(_get_e(l, uv_layer))
                    else:
                        selected = bool(_get_v(l, uv_layer))
                    if not selected:
                        continue
                    _add_record(recs, seen, mesh, uv_name, f, l, uv_layer, fi, local)
                    if mode == 'EDGE':
                        try:
                            _add_record(recs, seen, mesh, uv_name, f, l.link_loop_next, uv_layer, fi, (local + 1) % len(loops))
                        except Exception:
                            pass
                except Exception:
                    continue
    return _build_batches_from_records(record_map)


def _target_records_from_hit_1857(context, hit, *, select: bool):
    """Return direct transform target records for the hovered element."""
    try:
        import bmesh
    except Exception:
        return []
    if not hit:
        return []
    mesh = hit.get('mesh')
    if mesh is None:
        return []
    try:
        bm = bmesh.from_edit_mesh(mesh)
        bm.faces.ensure_lookup_table()
        uv_layer = bm.loops.layers.uv.get(hit.get('uv_layer_name', '')) or bm.loops.layers.uv.active
        if uv_layer is None:
            return []
    except Exception:
        return []
    uv_name = str(getattr(uv_layer, 'name', '') or '')
    mode = str(hit.get('mode') or _uv_mode(context)).upper()
    recs = []
    seen = set()
    changed = False
    try:
        face = bm.faces[int(hit.get('face', -1))]
        loops = tuple(face.loops)
        loop = loops[int(hit.get('local', 0))]
    except Exception:
        return []

    def add(face2, loop2, select_vertex=True, select_edge=False, select_face=False):
        nonlocal changed
        try:
            _add_record(recs, seen, mesh, uv_name, face2, loop2, uv_layer, _face_index(face2, 0), _loop_local(face2, loop2, 0))
            if select:
                if select_face:
                    _set_f(face2, True)
                if select_vertex:
                    _set_v(loop2, uv_layer, True)
                if select_edge:
                    _set_e(loop2, uv_layer, True)
                changed = True
        except Exception:
            pass

    if mode == 'VERTEX':
        target_vert = loop.vert
        target_uv = loop[uv_layer].uv.copy()
        for f in bm.faces:
            try:
                if getattr(f, 'hide', False):
                    continue
            except Exception:
                pass
            for l in tuple(f.loops):
                try:
                    if l.vert == target_vert and _uv_close(l[uv_layer].uv, target_uv):
                        add(f, l, True, False, False)
                except Exception:
                    continue
    elif mode == 'EDGE':
        target_edge = loop.edge
        a = hit.get('a'); b = hit.get('b')
        for f in bm.faces:
            try:
                if getattr(f, 'hide', False):
                    continue
            except Exception:
                pass
            for l in tuple(f.loops):
                try:
                    if l.edge == target_edge and _segment_close(l[uv_layer].uv, l.link_loop_next[uv_layer].uv, a, b):
                        add(f, l, True, True, False)
                        add(f, l.link_loop_next, True, False, False)
                except Exception:
                    continue
    else:
        for l in loops:
            add(face, l, True, True, True)

    if changed:
        try:
            bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        except TypeError:
            try: bmesh.update_edit_mesh(mesh)
            except Exception: pass
        except Exception:
            pass
        try:
            if getattr(context, 'area', None):
                context.area.tag_redraw()
        except Exception:
            pass
    return [{'mesh': mesh, 'uv_layer_name': uv_name, 'loops': recs}] if recs else []


def _select_hit_fast_1857(context, hit, event=None) -> bool:
    if not hit:
        return False
    additive = bool(getattr(event, 'shift', False) or getattr(event, 'ctrl', False)) if event is not None else False
    if not additive:
        _clear_uv_selection_fast(context)
    return bool(_target_records_from_hit_1857(context, hit, select=True))


def _snap_point_to_grid_1857(context, point, axis='FREE'):
    try:
        if not _snap_enabled_1856(context):
            return point.copy()
        elems = _snap_elements_1856(context)
        if elems and not any(e in elems for e in {'INCREMENT', 'GRID', 'GRID_INCREMENT', 'PIXEL', 'VERTEX'}):
            return point.copy()
        step = _uv_grid_step_1856(context)
        sx = max(float(step.x), 1.0e-12)
        sy = max(float(step.y), 1.0e-12)
        axis = str(axis or 'FREE').upper()
        x = float(point.x); y = float(point.y)
        if axis != 'V':
            x = round(x / sx) * sx
        if axis != 'U':
            y = round(y / sy) * sy
        return Vector((x, y))
    except Exception:
        try: return point.copy()
        except Exception: return point


def _snap_delta_from_anchor_1857(context, raw_delta, anchor_uv=None, axis='FREE'):
    try:
        if anchor_uv is None or not _snap_enabled_1856(context):
            return _snap_delta_1856(context, raw_delta)
        target = Vector((float(anchor_uv.x) + float(raw_delta.x), float(anchor_uv.y) + float(raw_delta.y)))
        snapped = _snap_point_to_grid_1857(context, target, axis)
        return Vector((float(snapped.x) - float(anchor_uv.x), float(snapped.y) - float(anchor_uv.y)))
    except Exception:
        return raw_delta


def _collect_selected_uv_state_1852(context, anchor_uv=None):  # type: ignore[no-redef]
    return _collect_selected_uv_state_1857(context, anchor_uv=anchor_uv)


def _fast_collect_selected_uv_state(context, anchor_uv=None):  # type: ignore[no-redef]
    return _collect_selected_uv_state_1857(context, anchor_uv=anchor_uv)


def _target_records_from_hit(context, hit, *, select: bool):  # type: ignore[no-redef]
    return _target_records_from_hit_1857(context, hit, select=select)


def _select_hit_fast(context, hit, event=None):  # type: ignore[no-redef]
    return _select_hit_fast_1857(context, hit, event)


def _instant_invoke_1857(self, context, event):
    enabled = _pg('_sus_1635_immediate_enabled')
    try:
        if callable(enabled) and not enabled(context): return {'PASS_THROUGH'}
    except Exception: return {'PASS_THROUGH'}
    if str(getattr(event, 'type', '')) != 'LEFTMOUSE' or str(getattr(event, 'value', '')) != 'PRESS': return {'PASS_THROUGH'}
    if not _is_uv_context(context): return {'PASS_THROUGH'}
    if bool(getattr(event, 'alt', False) or getattr(event, 'oskey', False)): return {'PASS_THROUGH'}
    try:
        state = _gizmo_press_state_cached_only_1854(context, event)
        if state is not None:
            return _start_gizmo_modal_1857(self, context, event, state)
    except Exception:
        pass
    hit = _find_hit_fast_1854(context, event)
    if not hit: return {'PASS_THROUGH'}
    selected = _hit_selected_fast(context, hit)
    if selected and not bool(getattr(event, 'shift', False) or getattr(event, 'ctrl', False)):
        return {'PASS_THROUGH'}
    if not _select_hit_fast_1857(context, hit, event): return {'PASS_THROUGH'}
    batches = _target_records_from_hit_1857(context, hit, select=False)
    stats = _build_stats_from_batches(batches)
    if stats is not None:
        try: _update_gizmo_cache(context, batches, stats)
        except Exception: pass
    batches = _cache_batches(context, batches)
    if not batches: return {'PASS_THROUGH'}
    try:
        self._suv1850_kind = 'INSTANT'
        self._suv1845_batches = batches
        self._suv1845_start_uv = _region_to_uv(context, event)
        self._suv1845_start_xy = (int(getattr(event, 'mouse_region_x', 0) or 0), int(getattr(event, 'mouse_region_y', 0) or 0))
        self._suv1845_dragging = False
        self._suv1845_last_delta_key = None
        self._suv1845_axis = _get_axis(context) if _axis_enabled(context) else 'FREE'
        self._suv1857_snap_anchor_uv = (hit.get('uv').copy() if hasattr(hit.get('uv'), 'copy') else (self._suv1845_start_uv.copy() if self._suv1845_start_uv is not None else None))
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    except Exception:
        return {'FINISHED'}


def _start_gizmo_modal_1857(self, context, event, state):
    try:
        from . import uv_gizmo_grip_fix as g
        mode = str((state or {}).get('mode') or '')
        batches = (state or {}).get('batches') or []
        pivot_uv = (state or {}).get('pivot_uv')
        if not mode or pivot_uv is None or not batches: return {'PASS_THROUGH'}
        _record_axis_from_mode(context, mode)
        self._area = context.area; self._region = context.region
        self._suv1850_kind = 'GIZMO'
        self._batches = _cache_batches(context, batches)
        self._pivot_uv = pivot_uv
        self._mode = mode
        self._start_mouse_view = g._region_to_view(self._region, event.mouse_region_x, event.mouse_region_y)
        self._start_vector = self._start_mouse_view - self._pivot_uv
        self._suv1845_last_delta_key = None
        self._suv1857_snap_anchor_uv = pivot_uv.copy()
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    except Exception:
        return {'PASS_THROUGH'}


def _modal_apply_gizmo_1857(self, context, event):
    try:
        cur = _region_to_uv(context, event)
        if cur is None: return {'RUNNING_MODAL'}
        mode = str(getattr(self, '_mode', '') or '')
        if mode.startswith('MOVE'):
            raw_delta = cur - self._start_mouse_view
            axis = 'FREE'
            if mode == 'MOVE_X':
                raw_delta.y = 0.0; axis = 'U'
            elif mode == 'MOVE_Y':
                raw_delta.x = 0.0; axis = 'V'
            delta = _snap_delta_from_anchor_1857(context, raw_delta, getattr(self, '_suv1857_snap_anchor_uv', None), axis)
            key = _delta_key(delta)
            if key is not None and key == getattr(self, '_suv1845_last_delta_key', None): return {'RUNNING_MODAL'}
            self._suv1845_last_delta_key = key
            _apply_cached_delta(context, getattr(self, '_batches', []) or [], delta)
            return {'RUNNING_MODAL'}
        pivot = getattr(self, '_pivot_uv', None)
        if pivot is None: return {'RUNNING_MODAL'}
        v = cur - pivot
        if mode == 'SCALE_UNIFORM':
            sv = getattr(self, '_start_vector', Vector((0, 0)))
            scale = max(1.0e-5, min(100000.0, max(float(v.length), 1.0e-8) / max(float(sv.length), 1.0e-8)))
            _apply_cached_transform(context, getattr(self, '_batches', []) or [], lambda original: pivot + (original - pivot) * scale)
        elif mode == 'ROTATE':
            sv = getattr(self, '_start_vector', Vector((0, 0)))
            if float(sv.length) > 1.0e-8 and float(v.length) > 1.0e-8:
                ang = atan2(float(v.y), float(v.x)) - atan2(float(sv.y), float(sv.x))
                c = cos(ang); s = sin(ang)
                def rot(original):
                    r = original - pivot
                    return Vector((pivot.x + r.x * c - r.y * s, pivot.y + r.x * s + r.y * c))
                _apply_cached_transform(context, getattr(self, '_batches', []) or [], rot)
        return {'RUNNING_MODAL'}
    except Exception:
        return {'FINISHED'}


def _instant_modal_1857(self, context, event):
    etype = str(getattr(event, 'type', '') or ''); evalue = str(getattr(event, 'value', '') or '')
    if etype in {'ESC', 'RIGHTMOUSE'}:
        if str(getattr(self, '_suv1850_kind', '')) == 'GIZMO':
            try: _apply_cached_transform(context, getattr(self, '_batches', []) or [], lambda original: original.copy())
            except Exception: pass
        return {'CANCELLED'}
    if etype == 'LEFTMOUSE' and evalue == 'RELEASE': return {'FINISHED'}
    if etype in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
        if str(getattr(self, '_suv1850_kind', '')) == 'GIZMO': return _modal_apply_gizmo_1857(self, context, event)
        try:
            cur = _region_to_uv(context, event); start = getattr(self, '_suv1845_start_uv', None)
            if cur is None or start is None: return {'RUNNING_MODAL'}
            sx, sy = getattr(self, '_suv1845_start_xy', (0, 0))
            dx = int(getattr(event, 'mouse_region_x', 0) or 0) - int(sx)
            dy = int(getattr(event, 'mouse_region_y', 0) or 0) - int(sy)
            if not bool(getattr(self, '_suv1845_dragging', False)):
                if dx * dx + dy * dy < 9: return {'RUNNING_MODAL'}
                self._suv1845_dragging = True
            axis = getattr(self, '_suv1845_axis', 'FREE')
            raw_delta = Vector((float(cur.x - start.x), float(cur.y - start.y)))
            raw_delta = _axis_delta(context, raw_delta, axis)
            delta = _snap_delta_from_anchor_1857(context, raw_delta, getattr(self, '_suv1857_snap_anchor_uv', None), axis)
            key = _delta_key(delta)
            if key is not None and key == getattr(self, '_suv1845_last_delta_key', None): return {'RUNNING_MODAL'}
            self._suv1845_last_delta_key = key
            _apply_cached_delta(context, getattr(self, '_suv1845_batches', []), delta)
            return {'RUNNING_MODAL'}
        except Exception:
            return {'FINISHED'}
    return {'RUNNING_MODAL'}


def _patch_gizmo_module_1857():
    try: _patch_gizmo_module_1854()
    except Exception: pass
    try:
        from . import uv_gizmo_grip_fix as g
        g._collect_selected_uv_state = _collect_selected_uv_state_1857
        g._snap_uv_delta_relative_to_cursor = lambda context, delta: _snap_delta_from_anchor_1857(context, delta, None, 'FREE')
        op = g.JELARARAGI_OT_uv_gizmo_grip_fix_grab
        def _invoke_1857(self, context, event):
            if str(getattr(event, 'type', '')) != 'LEFTMOUSE' or str(getattr(event, 'value', '')) != 'PRESS': return {'PASS_THROUGH'}
            try:
                if g._event_has_selection_modifier(event) or not g.is_enabled(): return {'PASS_THROUGH'}
                if not g._is_uv_editor_context(context) or not hasattr(context.region, 'view2d'): return {'PASS_THROUGH'}
            except Exception: return {'PASS_THROUGH'}
            state = _gizmo_press_state_cached_only_1854(context, event)
            if state is None:
                state = _gizmo_press_state_1852(context, event, allow_collect=True)
            if state is None: return {'PASS_THROUGH'}
            return _start_gizmo_modal_1857(self, context, event, state)
        op.invoke = _invoke_1857
        op.modal = lambda self, context, event: _instant_modal_1857(self, context, event)
        op._apply_to_uvs = lambda self, context, func: _apply_cached_transform(context, getattr(self, '_batches', []) or [], func)
        op._restore_original_uvs = lambda self, context: _apply_cached_transform(context, getattr(self, '_batches', []) or [], lambda original: original.copy())
    except Exception: pass


def _patch_instant_class_1857():
    try:
        cls = _pg('SMARTUVSUITE_OT_instant_select_drag_move')
        if not isinstance(cls, type): return
        cls.bl_options = {'UNDO', 'BLOCKING'}
        cls.invoke = _instant_invoke_1857
        cls.modal = _instant_modal_1857
        cls._find_uv_hit = lambda self, context, event: _find_hit_fast_1854(context, event)
        cls._select_uv_hit_immediate = lambda self, context, event, hit=None: _select_hit_fast_1857(context, hit or _find_hit_fast_1854(context, event), event)
        cls._hit_is_current_selection = lambda self, context, hit: _hit_selected_fast(context, hit)
        cls._integrated_uv_gizmo_grip_should_own_press = lambda self, context, event: bool(_gizmo_press_state_cached_only_1854(context, event))
        cls._sus1857_final = True
    except Exception: pass


_SUS1857B_PREV_APPLY_ALL = apply_all


def _sus1857b_sync(context=None):
    try: _SUS1857B_PREV_APPLY_ALL(_PG, context or bpy.context)
    except Exception: pass


def _sus1857b_install_sync_hooks():
    try:
        if isinstance(_PG, dict):
            _PG['_sus_1652_sync_keymaps_from_workspace'] = _sus1857b_sync
            _PG['_sus_1841_final_apply'] = lambda context=None: _sus1857b_sync(context)
            _PG['_sus_1842_apply'] = lambda context=None: _sus1857b_sync(context)
            _PG['_sus_1845_apply'] = lambda context=None: _sus1857b_sync(context)
    except Exception: pass


def apply_all(pkg_globals=None, context=None):  # type: ignore[no-redef]
    global _PG
    if pkg_globals is not None: _PG = pkg_globals
    try: _SUS1857B_PREV_APPLY_ALL(_PG, context or bpy.context)
    except Exception: pass
    try:
        if isinstance(_PG, dict):
            bi = _PG.get('bl_info')
            if isinstance(bi, dict): bi['version'] = (1, 0, 0)
            _PG['_sus_1674_snap_delta'] = _snap_delta_1856
            _PG['_sus_1835_collect_batches'] = lambda context, hit=None: (_target_records_from_hit_1857(context, hit, select=False) if hit else _collect_selected_uv_state_1857(context)[0])
            _PG['_sus_1835_select_hit'] = _select_hit_fast_1857
    except Exception: pass
    try:
        _patch_gizmo_module_1857()
        _patch_instant_class_1857()
    except Exception: pass
    _sus1857b_install_sync_hooks()


def install(pkg_globals):  # type: ignore[no-redef]
    global _PG, _INSTALLED, _PREV_SYNC
    _PG = pkg_globals
    if not _INSTALLED:
        _PREV_SYNC = pkg_globals.get('_sus_1652_sync_keymaps_from_workspace')
        _INSTALLED = True
    apply_all(pkg_globals, bpy.context)

# -----------------------------------------------------------------------------
# Smart UV Suite 1.8.58 definitive activation guard
# -----------------------------------------------------------------------------
# The 1.8.57 interaction algorithms are the intended final behaviour, but the
# package-level keymap synchronizer could still be replaced by older 1.8.56 sync
# hooks after register/update callbacks.  That made Blender run the old collector
# and delta-snap code even though the fixed code was present in this file.  This
# final guard makes the 1.8.57 interaction layer the only post-sync state.

_SUS1858_VERSION = (1, 8, 58)
_SUS1858_PREV_APPLY_ALL = apply_all


def _sus1858_sync(context=None):
    try:
        apply_all(_PG, context or bpy.context)
    except RecursionError:
        pass
    except Exception:
        pass


def _sus1858_install_sync_hooks():
    try:
        if isinstance(_PG, dict):
            _PG['_sus_1652_sync_keymaps_from_workspace'] = _sus1858_sync
            _PG['_sus_1841_final_apply'] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG['_sus_1842_apply'] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG['_sus_1845_apply'] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG['_sus1858_interaction_final'] = True
    except Exception:
        pass


def _sus1858_force_final_patch(pkg_globals=None, context=None):
    try:
        _patch_gizmo_module_1857()
    except Exception:
        pass
    try:
        _patch_instant_class_1857()
    except Exception:
        pass
    try:
        if isinstance(_PG, dict):
            cls = _PG.get('SMARTUVSUITE_OT_instant_select_drag_move')
            if isinstance(cls, type):
                cls.invoke = _instant_invoke_1857
                cls.modal = _instant_modal_1857
                cls._sus1857_final = True
                cls._sus1858_final = True
    except Exception:
        pass
    try:
        if isinstance(_PG, dict):
            bi = _PG.get('bl_info')
            if isinstance(bi, dict):
                bi['version'] = (1, 0, 0)
            _PG['__version__'] = '1.0.0'
            # Expose final helpers for tests and for any late compatibility layer.
            _PG['_sus_1835_collect_batches'] = lambda context, hit=None: (_target_records_from_hit_1857(context, hit, select=False) if hit else _collect_selected_uv_state_1857(context)[0])
            _PG['_sus_1835_select_hit'] = _select_hit_fast_1857
            _PG['_sus_1858_snap_delta_from_anchor'] = _snap_delta_from_anchor_1857
            _PG['_sus_1858_collect_selected_uv_state'] = _collect_selected_uv_state_1857
    except Exception:
        pass
    _sus1858_install_sync_hooks()


def apply_all(pkg_globals=None, context=None):  # type: ignore[no-redef]
    global _PG
    if pkg_globals is not None:
        _PG = pkg_globals
    try:
        _SUS1858_PREV_APPLY_ALL(_PG, context or bpy.context)
    except RecursionError:
        pass
    except Exception:
        pass
    _sus1858_force_final_patch(_PG, context or bpy.context)


def install(pkg_globals):  # type: ignore[no-redef]
    global _PG, _INSTALLED, _PREV_SYNC
    _PG = pkg_globals
    if not _INSTALLED:
        _PREV_SYNC = pkg_globals.get('_sus_1652_sync_keymaps_from_workspace')
        _INSTALLED = True
    apply_all(pkg_globals, bpy.context)


# -----------------------------------------------------------------------------
# 1.8.59: native-gizmo-safe assist + committed immediate drag snap.
# -----------------------------------------------------------------------------
# Production fix after repeated reports:
# - UV Gizmo Grip Assist must not perform a competing BMesh transform while
#   Blender's native gizmo is also active.  The previous custom fallback could
#   fight the native transform, lock part of the selected UVs, pull split loops,
#   or leave a later click restoring the original cached coordinates.  From this
#   layer onward the assist is a native-gizmo enabler only: it restores/enables
#   Blender's  rows and removes Smart UV's custom gizmo
#   transform keymaps.  Actual gizmo movement is handled by Blender, so selected
#   elements, axis handles, snapping and final release commit use Blender's own
#   stable code path.
# - Immediate Select still owns only the special case requested by the user:
#   PRESS on an unselected UV element selects it immediately and a continuous drag
#   moves exactly that newly-selected element.  Snap and Axis Constraint Memory
#   are applied in the direct drag path, and the result is committed on release.

_SUS1859_VERSION = (1, 8, 59)
_SUS1859_PREV_APPLY_ALL = apply_all
_GIZMO_CUSTOM_ID_1859 = 'smart_uv_suite.uv_gizmo_grip_fix_grab'
_NATIVE_GIZMO_ID_1859 = ''
_NATIVE_GIZMO_KEYMAP_NAMES_1859 = (
    'Generic Gizmo',
    'Generic Gizmo Drag',
    'Generic Gizmo Click Drag',
    'Generic Gizmo Maybe Drag',
    'Generic Gizmo Select',
)
# Keep Immediate Select in UV/Image tool maps only.  It does not run on Generic
# Gizmo maps, so it cannot steal native gizmo hover/axis handles.
_INSTANT_KEYMAP_DEFS_1859 = (
    ('UV Editor', 'EMPTY'),
    ('Image', 'IMAGE_EDITOR'),
    ('Image Generic', 'IMAGE_EDITOR'),
    ('Image Editor Tool: Uv, Tweak', 'IMAGE_EDITOR'),
    ('Image Editor Tool: Uv, Tweak (fallback)', 'IMAGE_EDITOR'),
    ('Image Editor Tool: Uv, Move', 'IMAGE_EDITOR'),
    ('Image Editor Tool: Uv, Move (fallback)', 'IMAGE_EDITOR'),
    ('Image Editor Tool: Uv, Select Box', 'IMAGE_EDITOR'),
    ('Image Editor Tool: Uv, Select Box (fallback)', 'IMAGE_EDITOR'),
)


def _remove_custom_gizmo_keymaps_1859() -> int:
    # The current Smart UV custom gizmo row is a required owned resource.
    # It is removed only by uv_gizmo_grip_fix/ownership exact teardown.
    return 0


def _ensure_native_gizmo_rows_1859(active=True) -> tuple[int, int]:
    del active
    return (0, 0)


def _set_native_gizmo_rows_1859_active(active: bool) -> None:
    del active
    return None


def _gizmo_enable_1859():
    try:
        from . import uv_gizmo_grip_fix as _gizmo
        _gizmo.set_enabled(True)
    except Exception:
        pass
    return None


def _gizmo_disable_1859(*, delete: bool = False):
    del delete
    try:
        from . import uv_gizmo_grip_fix as _gizmo
        _gizmo.set_enabled(False)
    except Exception:
        pass
    return None


def _ensure_instant_keymaps_1859(*, active: bool = True):
    return _ensure_ordered_keymaps_1850('smart_uv_suite.instant_select_drag_move', _INSTANT_KEYMAP_DEFS_1859, active=active, head=True)


def _set_instant_keymaps_1859_active(active: bool):
    if active:
        return _ensure_instant_keymaps_1859(active=True)
    return _set_keymaps_for_defs_active('smart_uv_suite.instant_select_drag_move', _INSTANT_KEYMAP_DEFS_1859, False)


def _delete_instant_keymaps_1859():
    return _delete_rows_for_id_1850('smart_uv_suite.instant_select_drag_move')


def _flush_edit_meshes_1859(context, batches=None) -> None:
    try:
        import bmesh
    except Exception:
        return
    meshes = []
    seen = set()
    if batches:
        for batch in list(batches or []):
            mesh = batch.get('mesh') if isinstance(batch, dict) else None
            if mesh is not None and id(mesh) not in seen:
                seen.add(id(mesh)); meshes.append(mesh)
    else:
        for obj in _iter_edit_mesh_objects(context):
            mesh = getattr(obj, 'data', None)
            if mesh is not None and id(mesh) not in seen:
                seen.add(id(mesh)); meshes.append(mesh)
    for mesh in meshes:
        try:
            bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        except TypeError:
            try: bmesh.update_edit_mesh(mesh)
            except Exception: pass
        except Exception:
            pass
        try: mesh.update()
        except Exception: pass
    try:
        if getattr(context, 'area', None): context.area.tag_redraw()
    except Exception:
        pass


def _instant_invoke_1859(self, context, event):
    enabled = _pg('_sus_1635_immediate_enabled')
    try:
        if callable(enabled) and not enabled(context): return {'PASS_THROUGH'}
    except Exception: return {'PASS_THROUGH'}
    if str(getattr(event, 'type', '')) != 'LEFTMOUSE' or str(getattr(event, 'value', '')) != 'PRESS': return {'PASS_THROUGH'}
    if not _is_uv_context(context): return {'PASS_THROUGH'}
    if bool(getattr(event, 'alt', False) or getattr(event, 'oskey', False)): return {'PASS_THROUGH'}

    # Do not do any selected-pivot/gizmo collection here.  Native gizmo hover and
    # U/V axis handles must remain Blender-owned.  Immediate Select only handles
    # PRESS on an unselected UV element.
    hit = _find_hit_fast_1854(context, event)
    if not hit: return {'PASS_THROUGH'}
    selected = _hit_selected_fast(context, hit)
    if selected and not bool(getattr(event, 'shift', False) or getattr(event, 'ctrl', False)):
        return {'PASS_THROUGH'}
    if not _select_hit_fast_1857(context, hit, event): return {'PASS_THROUGH'}
    batches = _target_records_from_hit_1857(context, hit, select=False)
    batches = _cache_batches(context, batches)
    if not batches: return {'PASS_THROUGH'}
    try:
        # Refresh axis from the last native transform now.  This is the 3ds Max
        # style axis-memory bridge after a native U/V gizmo drag.
        if _axis_enabled(context):
            try: _capture_last_native_axis(context)
            except Exception: pass
        self._suv1850_kind = 'INSTANT'
        self._suv1845_batches = batches
        self._suv1845_start_uv = _region_to_uv(context, event)
        self._suv1845_start_xy = (int(getattr(event, 'mouse_region_x', 0) or 0), int(getattr(event, 'mouse_region_y', 0) or 0))
        self._suv1845_dragging = False
        self._suv1845_last_delta_key = None
        self._suv1845_axis = _get_axis(context) if _axis_enabled(context) else 'FREE'
        uv = hit.get('uv')
        self._suv1857_snap_anchor_uv = uv.copy() if hasattr(uv, 'copy') else (self._suv1845_start_uv.copy() if self._suv1845_start_uv is not None else None)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    except Exception:
        return {'FINISHED'}


def _instant_modal_1859(self, context, event):
    etype = str(getattr(event, 'type', '') or '')
    evalue = str(getattr(event, 'value', '') or '')
    if etype in {'ESC', 'RIGHTMOUSE'}:
        # Immediate Select direct drags should cancel by restoring only if a drag
        # has actually begun.  If no drag happened, keep the press selection.
        if bool(getattr(self, '_suv1845_dragging', False)):
            try: _apply_cached_transform(context, getattr(self, '_suv1845_batches', []) or [], lambda original: original.copy())
            except Exception: pass
        return {'CANCELLED'}
    if etype == 'LEFTMOUSE' and evalue == 'RELEASE':
        # Commit direct BMesh coordinates; never restore on a later click.
        _flush_edit_meshes_1859(context, getattr(self, '_suv1845_batches', []) or [])
        return {'FINISHED'}
    if etype in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
        try:
            cur = _region_to_uv(context, event); start = getattr(self, '_suv1845_start_uv', None)
            if cur is None or start is None: return {'RUNNING_MODAL'}
            sx, sy = getattr(self, '_suv1845_start_xy', (0, 0))
            dx = int(getattr(event, 'mouse_region_x', 0) or 0) - int(sx)
            dy = int(getattr(event, 'mouse_region_y', 0) or 0) - int(sy)
            if not bool(getattr(self, '_suv1845_dragging', False)):
                if dx * dx + dy * dy < 9: return {'RUNNING_MODAL'}
                self._suv1845_dragging = True
            axis = getattr(self, '_suv1845_axis', 'FREE')
            raw_delta = Vector((float(cur.x - start.x), float(cur.y - start.y)))
            raw_delta = _axis_delta(context, raw_delta, axis)
            delta = _snap_delta_from_anchor_1857(context, raw_delta, getattr(self, '_suv1857_snap_anchor_uv', None), axis)
            key = _delta_key(delta)
            if key is not None and key == getattr(self, '_suv1845_last_delta_key', None): return {'RUNNING_MODAL'}
            self._suv1845_last_delta_key = key
            _apply_cached_delta(context, getattr(self, '_suv1845_batches', []) or [], delta)
            return {'RUNNING_MODAL'}
        except Exception:
            return {'FINISHED'}
    return {'RUNNING_MODAL'}


def _patch_gizmo_module_1859():
    # Public gizmo operator implementation is authoritative; do not replace methods.
    return None


def _patch_instant_class_1859():
    # The authoritative modal_state_18168 wrapper is installed before and after
    # legacy registration. Do not instrument a registered Operator here.
    return None


def _apply_keymap_defs_1859():
    try:
        if isinstance(_PG, dict):
            _PG['_SUS_1830_INSTANT_KEYMAP_DEFS'] = tuple(_INSTANT_KEYMAP_DEFS_1859)
            _PG['_SUS_1832_INSTANT_KEYMAP_DEFS'] = tuple(_INSTANT_KEYMAP_DEFS_1859)
            _PG['_SUS_1834_INSTANT_KEYMAP_DEFS'] = tuple(_INSTANT_KEYMAP_DEFS_1859)
            _PG['_SUS_1850_GIZMO_KEYMAP_DEFS'] = tuple()
            _PG['_SUS_1853_NATIVE_GIZMO_KEYMAP_NAMES'] = tuple(_NATIVE_GIZMO_KEYMAP_NAMES_1859)
            _PG['_sus_1830_keymap_defs'] = lambda: tuple(_INSTANT_KEYMAP_DEFS_1859)
            _PG['_sus_1834_keymap_defs'] = lambda: tuple(_INSTANT_KEYMAP_DEFS_1859)
            _PG['_sus_1835_find_uv_hit'] = _find_hit_fast_1854
            _PG['_sus_1835_select_hit'] = _select_hit_fast_1857
            _PG['_sus_1835_collect_batches'] = lambda context, hit=None: (_target_records_from_hit_1857(context, hit, select=False) if hit else _collect_selected_uv_state_1857(context)[0])
            _PG['_sus_1652_ensure_instant_keymaps'] = _ensure_instant_keymaps_1859
            _PG['_sus_1652_promote_instant_keymaps_to_head'] = _ensure_instant_keymaps_1859
            _PG['_sus_1652_set_instant_keymaps_active'] = _set_instant_keymaps_1859_active
            _PG['_sus_1652_delete_instant_keymaps'] = _delete_instant_keymaps_1859
            _PG['_sus_1652_gizmo_enable'] = _gizmo_enable_1859
            _PG['_sus_1652_gizmo_disable'] = _gizmo_disable_1859
            _PG['_sus_1674_snap_delta'] = _snap_delta_1856
            _PG['_sus_1859_native_gizmo_only'] = True
    except Exception:
        pass


_SUS1859_PREV_SYNC = None

def _sus1859_sync(context=None):
    try: apply_all(_PG, context or bpy.context)
    except RecursionError: pass
    except Exception: pass


def _sus1859_install_sync_hooks():
    try:
        if isinstance(_PG, dict):
            _PG['_sus_1652_sync_keymaps_from_workspace'] = _sus1859_sync
            _PG['_sus_1841_final_apply'] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG['_sus_1842_apply'] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG['_sus_1845_apply'] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG['_sus1859_interaction_final'] = True
    except Exception: pass


def apply_all(pkg_globals=None, context=None):  # type: ignore[no-redef]
    global _PG
    if pkg_globals is not None:
        _PG = pkg_globals
    try:
        if isinstance(_PG, dict):
            bi = _PG.get("bl_info")
            if isinstance(bi, dict):
                bi["version"] = (1, 0, 0)
            _PG["__version__"] = "1.0.0"
    except Exception:
        pass
    _apply_keymap_defs_1859()
    # Never replace public operator methods or Blender native gizmo keymaps here.
    try:
        ws = _PG.get("_sus_1652_ws")(context or bpy.context) if isinstance(_PG, dict) and callable(_PG.get("_sus_1652_ws")) else None
    except Exception:
        ws = None
    try:
        if ws is not None and bool(getattr(ws, "operation_instant_select_enabled", False)):
            _ensure_instant_keymaps_1859(active=True)
        else:
            _delete_instant_keymaps_1859()
    except Exception:
        pass
    try:
        if ws is not None and bool(getattr(ws, "operation_uv_gizmo_grip_fix_enabled", False)):
            _gizmo_enable_1859()
        else:
            _gizmo_disable_1859(delete=True)
    except Exception:
        pass
    _sus1859_install_sync_hooks()
    return None


def install(pkg_globals):  # type: ignore[no-redef]
    global _PG, _INSTALLED, _PREV_SYNC
    _PG = pkg_globals
    if not _INSTALLED:
        _PREV_SYNC = pkg_globals.get('_sus_1652_sync_keymaps_from_workspace')
        _INSTALLED = True
    apply_all(pkg_globals, bpy.context)
