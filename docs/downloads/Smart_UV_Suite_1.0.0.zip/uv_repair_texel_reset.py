import bpy

from .base import _UVOverride

def build_handlers(api):
    def run(context, op):
        if context.mode != 'EDIT_MESH':
            return False
        with _UVOverride(context) as override:
            if not override.kwargs:
                return False
            with context.temp_override(**override.kwargs):
                average = bpy.ops.uv.average_islands_scale
                return average.poll() and 'FINISHED' in average()

    return {
        'smart_uv_suite.texel_reset_scale': api.Handler(run, 'Reset the relative scale of selected islands to a common texel density.', '選択アイランドの相対スケールを共通のテクセル密度にそろえます。'),
    }
