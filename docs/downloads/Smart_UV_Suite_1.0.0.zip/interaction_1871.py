# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""1.8.71 final Immediate Select drag and target/material freeze guard.

Latest required behavior:
- Immediate Select Drag Move affects only an unselected UV element press.
- Background, already-selected elements, modifier clicks and native gizmo handles
  are handed to Blender unchanged.
- On an unselected UV element: PRESS selects immediately, and if the same held
  click becomes a drag, Blender native Transform is invoked once.  Native snap,
  release confirm and undo stay Blender-owned.
- Target/Material and object-target dropdown changes must not freeze the UI.
  The generic workspace JSON save is deferred out of the property-update call.
"""
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

import time
import bpy

_PG = None
_VERSION = (1, 8, 86)
_INSTANT_ID = "smart_uv_suite.instant_select_drag_move"
_GIZMO_ID = "smart_uv_suite.uv_gizmo_grip_fix_grab"
_NATIVE_GIZMO_ID = ""

_INSTANT_KEYMAP_DEFS = (
    ("UV Editor", "EMPTY"),
    ("Image Editor Tool: Uv, Tweak", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Tweak (fallback)", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Move", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Move (fallback)", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Select Box", "IMAGE_EDITOR"),
    ("Image Editor Tool: Uv, Select Box (fallback)", "IMAGE_EDITOR"),
)
_PURGE_INSTANT_MAP_NAMES = (
    "Window",
    "Image",
    "Image Generic",
    "Generic Gizmo",
    "Generic Gizmo Drag",
    "Generic Gizmo Click Drag",
    "Generic Gizmo Maybe Drag",
    "Generic Gizmo Select",
)
_NATIVE_GIZMO_KEYMAP_NAMES = (
    "Generic Gizmo",
    "Generic Gizmo Drag",
    "Generic Gizmo Click Drag",
    "Generic Gizmo Maybe Drag",
    "Generic Gizmo Select",
)
_LAST_PRESS = {"area": None, "region": None, "x": None, "y": None, "t": 0.0}
_ORIGINAL_SAVE_WORKSPACE = None
_DEFERRED_SAVE_PENDING = False
_LEGACY_TIMER_SWEEP_DONE = False
_STATIC_PATCHES_INSTALLED = False
_DEFERRED_SAVE_WS = None  # Compatibility placeholder; never stores RNA pointers.
_DEFERRED_SAVE_SCENE_NAME = ""
_DEFERRED_SAVE_CONTEXT_ID = 0
_DEFERRED_SAVE_LAST = 0.0


def _pg(name, default=None):
    try:
        return _PG.get(name, default) if isinstance(_PG, dict) else default
    except Exception:
        return default


def _base():
    # 1.8.65 contains the proven fast UV hit/selection helpers.  We keep those
    # helpers and replace only the modal/direct-drag policy here.
    try:
        from . import interaction_1865 as b
        return b
    except Exception:
        return None


def _is_uv_context(context) -> bool:
    try:
        b = _base()
        fn = getattr(b, "_is_uv_context", None) if b is not None else None
        if callable(fn):
            return bool(fn(context))
    except Exception:
        pass
    try:
        return (getattr(getattr(context, "area", None), "type", None) == "IMAGE_EDITOR" and
                getattr(getattr(context, "region", None), "type", None) == "WINDOW")
    except Exception:
        return False


def _instant_enabled(context) -> bool:
    try:
        b = _base()
        fn = getattr(b, "_instant_enabled", None) if b is not None else None
        if callable(fn):
            return bool(fn(context))
    except Exception:
        pass
    try:
        ws_fn = _pg("_sus_1652_ws")
        ws = ws_fn(context) if callable(ws_fn) else getattr(getattr(context, "scene", None), "suv_workspace", None)
        return bool(getattr(ws, "operation_instant_select_enabled", False))
    except Exception:
        return False


def _axis_tuple(context):
    # Use the existing axis-memory implementation only as a native Transform
    # argument.  No custom UV transform math is performed here.
    for modname in ("interaction_1866", "interaction_1865"):
        try:
            mod = __import__(f"{__package__}.{modname}", fromlist=["dummy"])
            fn = getattr(mod, "_axis_tuple", None)
            if callable(fn):
                axis = fn(context)
                if axis is not None:
                    return axis
        except Exception:
            pass
    return None


def _event_duplicate(context, event) -> bool:
    try:
        now = time.monotonic()
        area = id(getattr(context, "area", None))
        region = id(getattr(context, "region", None))
        x = int(getattr(event, "mouse_region_x", 0) or 0)
        y = int(getattr(event, "mouse_region_y", 0) or 0)
        if (_LAST_PRESS.get("area") == area and _LAST_PRESS.get("region") == region and
                _LAST_PRESS.get("x") == x and _LAST_PRESS.get("y") == y and
                now - float(_LAST_PRESS.get("t") or 0.0) < 0.020):
            return True
        _LAST_PRESS.update({"area": area, "region": region, "x": x, "y": y, "t": now})
    except Exception:
        pass
    return False


def _find_hit(context, event):
    try:
        b = _base()
        fn = getattr(b, "_find_hit", None) if b is not None else None
        if callable(fn):
            return fn(context, event)
    except Exception:
        return None
    return None


def _hit_selected(context, hit) -> bool:
    try:
        b = _base()
        fn = getattr(b, "_hit_selected", None) if b is not None else None
        if callable(fn):
            return bool(fn(context, hit))
    except Exception:
        pass
    return False


def _select_hit(context, hit, event) -> bool:
    try:
        b = _base()
        fn = getattr(b, "_select_hit", None) if b is not None else None
        if callable(fn):
            return bool(fn(context, hit, event))
    except Exception:
        pass
    return False


def _invoke_native_translate_once(context, axis=None) -> set:
    # Delegate snap, release confirmation, undo and most transform behavior to
    # Blender.  Only the remembered U/V axis is optionally supplied.
    kwargs = {"release_confirm": True}
    if axis is not None:
        kwargs["constraint_axis"] = axis
    try:
        res = bpy.ops.transform.translate("INVOKE_DEFAULT", **kwargs)
        return set(res) if res is not None else {"RUNNING_MODAL"}
    except TypeError:
        try:
            if axis is not None:
                res = bpy.ops.transform.translate("INVOKE_DEFAULT", constraint_axis=axis)
            else:
                res = bpy.ops.transform.translate("INVOKE_DEFAULT")
            return set(res) if res is not None else {"RUNNING_MODAL"}
        except Exception:
            return {"CANCELLED"}
    except Exception:
        return {"CANCELLED"}


def _instant_invoke_1871(self, context, event):
    try:
        self._suv1871_active = False
        self._suv1871_transform_started = False
        if not _instant_enabled(context):
            return {"PASS_THROUGH"}
        if str(getattr(event, "type", "")) != "LEFTMOUSE" or str(getattr(event, "value", "")) != "PRESS":
            return {"PASS_THROUGH"}
        if not _is_uv_context(context):
            return {"PASS_THROUGH"}
        # Preserve all Blender-native modified click behavior.
        if bool(getattr(event, "shift", False) or getattr(event, "ctrl", False) or getattr(event, "alt", False) or getattr(event, "oskey", False)):
            return {"PASS_THROUGH"}
        if _event_duplicate(context, event):
            return {"PASS_THROUGH"}

        # Fast miss: background box/lasso/tweak drawing must see the original
        # event immediately.  No transform setup happens on a miss.
        hit = _find_hit(context, event)
        if not hit:
            return {"PASS_THROUGH"}

        # Selected elements and native gizmo handles stay entirely native.
        try:
            if _hit_selected(context, hit):
                return {"PASS_THROUGH"}
        except Exception:
            pass

        # The only owned case: unselected UV element press.
        if not _select_hit(context, hit, event):
            return {"PASS_THROUGH"}
        try:
            if getattr(context, "area", None) is not None:
                context.area.tag_redraw()
        except Exception:
            pass

        self._suv1871_start_xy = (
            int(getattr(event, "mouse_region_x", getattr(event, "mouse_x", 0)) or 0),
            int(getattr(event, "mouse_region_y", getattr(event, "mouse_y", 0)) or 0),
        )
        self._suv1871_active = True
        self._suv1871_transform_started = False
        try:
            context.window_manager.modal_handler_add(self)
            return {"RUNNING_MODAL"}
        except Exception:
            return {"FINISHED"}
    except Exception:
        return {"PASS_THROUGH"}


def _instant_modal_1871(self, context, event):
    try:
        etype = str(getattr(event, "type", "") or "")
        evalue = str(getattr(event, "value", "") or "")
        if etype in {"ESC", "RIGHTMOUSE"}:
            return {"CANCELLED"}
        if etype == "LEFTMOUSE" and evalue == "RELEASE":
            # Click-only: the element has already been selected on PRESS.
            return {"FINISHED"}
        if etype in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
            sx, sy = getattr(self, "_suv1871_start_xy", (0, 0))
            mx = int(getattr(event, "mouse_region_x", getattr(event, "mouse_x", 0)) or 0)
            my = int(getattr(event, "mouse_region_y", getattr(event, "mouse_y", 0)) or 0)
            dx, dy = mx - int(sx), my - int(sy)
            # Match Blender-like tweak threshold and do not let this real UV hit
            # fall through to background box select while the button is held.
            if dx * dx + dy * dy < 4:
                return {"RUNNING_MODAL"}
            if not bool(getattr(self, "_suv1871_transform_started", False)):
                self._suv1871_transform_started = True
                axis = _axis_tuple(context)
                _invoke_native_translate_once(context, axis=axis)
                return {"FINISHED"}
        return {"RUNNING_MODAL"}
    except Exception:
        return {"FINISHED"}


def _patch_instant_class():
    try:
        cls = _pg("SMARTUVSUITE_OT_instant_select_drag_move")
        if not isinstance(cls, type):
            return
        cls.bl_options = {'UNDO', 'BLOCKING'}
        cls.invoke = _instant_invoke_1871
        cls.modal = _instant_modal_1871
        cls._sus1871_press_select_drag_native_transform = True
    except Exception:
        pass


def _addon_keyconfig():
    try:
        return bpy.context.window_manager.keyconfigs.addon
    except Exception:
        return None


def _find_kmis(km, idname: str):
    try:
        from . import ownership_runtime_18168 as _ownership
        return [kmi for keymap, kmi in _ownership.owned_keymap_items(idname) if keymap is km]
    except Exception:
        return []


def _get_keymap(kc, name: str, space_type: str):
    try:
        km = kc.keymaps.get(name)
        if km is None:
            km = kc.keymaps.new(name=name, space_type=space_type, region_type="WINDOW")
        return km
    except Exception:
        return None


def _configure_left_press(kmi, active=True):
    try:
        _suv_resource.keymap_item_set(kmi, 'type', 'LEFTMOUSE'); _suv_resource.keymap_item_set(kmi, 'value', 'PRESS')
    except Exception:
        pass
    for name in ("shift", "ctrl", "alt", "oskey", "hyper"):
        try:
            _suv_resource.keymap_item_set(kmi, name, False)
        except Exception:
            pass
    try:
        _suv_resource.keymap_item_set(kmi, 'any', False)
    except Exception:
        pass
    try:
        __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, bool(active))
    except Exception:
        pass


def _delete_rows_for_id(idname: str) -> int:
    kc = _addon_keyconfig()
    if kc is None:
        return 0
    removed = 0
    try:
        for km in list(kc.keymaps):
            for kmi in list(_find_kmis(km, idname)):
                try:
                    __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(km, kmi); removed += 1
                except Exception:
                    try: __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, False)
                    except Exception: pass
    except Exception:
        pass
    return removed


def _ensure_instant_keymaps(active=True):
    kc = _addon_keyconfig()
    if kc is None:
        return (0, 0)
    try:
        for name in _PURGE_INSTANT_MAP_NAMES:
            km = kc.keymaps.get(name)
            if km is None:
                continue
            for kmi in list(_find_kmis(km, _INSTANT_ID)):
                try: __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(km, kmi)
                except Exception:
                    try: __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, False)
                    except Exception: pass
    except Exception:
        pass
    created = touched = 0
    for name, space in _INSTANT_KEYMAP_DEFS:
        km = _get_keymap(kc, name, space)
        if km is None:
            continue
        items = list(_find_kmis(km, _INSTANT_ID))
        if not items:
            try:
                kmi = __import__(__package__ + '.ownership_runtime_18168', fromlist=['new_keymap_item']).new_keymap_item(km, _INSTANT_ID, type="LEFTMOUSE", value="PRESS", head=True)
            except TypeError:
                kmi = __import__(__package__ + '.ownership_runtime_18168', fromlist=['new_keymap_item']).new_keymap_item(km, _INSTANT_ID, type="LEFTMOUSE", value="PRESS")
            items = [kmi]; created += 1
        for extra in items[1:]:
            try: __import__(__package__ + '.ownership_runtime_18168', fromlist=['remove_keymap_item']).remove_keymap_item(km, extra)
            except Exception:
                try: __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(extra, False)
                except Exception: pass
        for kmi in items[:1]:
            _configure_left_press(kmi, active=active)
            touched += 1
    return (created, touched)


def _set_instant_keymaps_active(active: bool):
    if active:
        return _ensure_instant_keymaps(True)
    kc = _addon_keyconfig()
    if kc is None:
        return (0, 0)
    touched = 0
    for name, _space in _INSTANT_KEYMAP_DEFS:
        try:
            km = kc.keymaps.get(name)
            if km is None:
                continue
            for kmi in _find_kmis(km, _INSTANT_ID):
                __import__(__package__ + '.ownership_runtime_18168', fromlist=['set_keymap_item_active']).set_keymap_item_active(kmi, False); touched += 1
        except Exception:
            pass
    return (0, touched)


def _delete_instant_keymaps():
    return _delete_rows_for_id(_INSTANT_ID)


def _ensure_native_gizmo_rows(active=True):
    # Native Blender/user gizmo keymaps are foreign resources and remain untouched.
    del active
    return (0, 0)


def _gizmo_enable_native_only():
    try:
        from . import uv_gizmo_grip_fix as _gizmo
        _gizmo.set_enabled(True)
    except Exception:
        pass
    return None


def _gizmo_disable_native_only(delete=False):
    del delete
    try:
        from . import uv_gizmo_grip_fix as _gizmo
        _gizmo.set_enabled(False)
    except Exception:
        pass
    return None



def _cancel_deferred_workspace_timer(func=None) -> None:
    if callable(func):
        try:
            _suv_resource.timer_unregister(func)
        except Exception:
            pass



def _cancel_all_deferred_workspace_timers() -> int:
    """Cancel only the exact current callback recorded by Smart UV."""
    global _LEGACY_TIMER_SWEEP_DONE
    _LEGACY_TIMER_SWEEP_DONE = True
    removed = int(bool(_suv_resource.timer_unregister(_flush_deferred_workspace_save)))
    globals()['_DEFERRED_SAVE_WS'] = None
    globals()['_DEFERRED_SAVE_SCENE_NAME'] = ''
    globals()['_DEFERRED_SAVE_PENDING'] = False
    return removed


def _flush_deferred_workspace_save():
    global _DEFERRED_SAVE_PENDING, _DEFERRED_SAVE_WS, _DEFERRED_SAVE_SCENE_NAME
    _DEFERRED_SAVE_PENDING = False
    _DEFERRED_SAVE_WS = None
    _DEFERRED_SAVE_SCENE_NAME = ""
    try:
        if callable(_ORIGINAL_SAVE_WORKSPACE):
            # Never pass a cached PropertyGroup through the timer.  The
            # persistence module resolves Scene.suv_workspace again from the
            # current context, avoiding Blender 5.1.x RNA access violations after
            # extension install, reload or scene/workspace changes.
            _ORIGINAL_SAVE_WORKSPACE(getattr(bpy, "context", None), None)
    except Exception:
        pass
    return None


def _deferred_save_workspace(context=None, ws=None):
    """Compatibility wrapper that now performs the required synchronous save."""
    global _DEFERRED_SAVE_PENDING, _DEFERRED_SAVE_WS, _DEFERRED_SAVE_SCENE_NAME, _DEFERRED_SAVE_CONTEXT_ID, _DEFERRED_SAVE_LAST
    try:
        del ws
        _DEFERRED_SAVE_WS = None
        _DEFERRED_SAVE_SCENE_NAME = ""
        try:
            ctx = context or getattr(bpy, "context", None)
            _DEFERRED_SAVE_CONTEXT_ID = id(ctx) if ctx is not None else 0
        except Exception:
            _DEFERRED_SAVE_CONTEXT_ID = 0
        _DEFERRED_SAVE_LAST = time.monotonic()
        _DEFERRED_SAVE_PENDING = False
        if callable(_ORIGINAL_SAVE_WORKSPACE):
            _ORIGINAL_SAVE_WORKSPACE(context or getattr(bpy, 'context', None), None)
    except Exception:
        pass


def _install_target_material_freeze_guard():
    global _ORIGINAL_SAVE_WORKSPACE, _DEFERRED_SAVE_WS, _DEFERRED_SAVE_SCENE_NAME, _DEFERRED_SAVE_PENDING
    try:
        _cancel_all_deferred_workspace_timers()
        from . import npanel_persistence as np
        current = getattr(np, "save_workspace", None)
        if getattr(current, "_sus1871_deferred", False):
            legacy_globals = getattr(current, "__globals__", {}) or {}
            _cancel_deferred_workspace_timer(legacy_globals.get("_flush_deferred_workspace_save"))
            try:
                legacy_globals["_DEFERRED_SAVE_WS"] = None
                legacy_globals["_DEFERRED_SAVE_SCENE_NAME"] = ""
                legacy_globals["_DEFERRED_SAVE_PENDING"] = False
            except Exception:
                pass
            original = getattr(current, "_sus1871_original", None) or legacy_globals.get("_ORIGINAL_SAVE_WORKSPACE")
            if _ORIGINAL_SAVE_WORKSPACE is None and callable(original):
                _ORIGINAL_SAVE_WORKSPACE = original
        elif _ORIGINAL_SAVE_WORKSPACE is None and callable(current):
            _ORIGINAL_SAVE_WORKSPACE = current
        if callable(_ORIGINAL_SAVE_WORKSPACE):
            _cancel_deferred_workspace_timer(_flush_deferred_workspace_save)
            _DEFERRED_SAVE_PENDING = False
            _DEFERRED_SAVE_WS = None
            _DEFERRED_SAVE_SCENE_NAME = ""
            # Do not replace the canonical synchronous property-update save with
            # a timer.  The compatibility wrapper remains for old callers only.
            np.save_workspace = _ORIGINAL_SAVE_WORKSPACE
    except Exception:
        pass


def _apply_keymap_exports():
    if not isinstance(_PG, dict):
        return
    try:
        bi = _PG.get("bl_info")
        if isinstance(bi, dict):
            bi["version"] = (1, 0, 0)
        _PG["__version__"] = '1.0.0'
    except Exception:
        pass
    _PG["_SUS_1830_INSTANT_KEYMAP_DEFS"] = tuple(_INSTANT_KEYMAP_DEFS)
    _PG["_SUS_1832_INSTANT_KEYMAP_DEFS"] = tuple(_INSTANT_KEYMAP_DEFS)
    _PG["_SUS_1834_INSTANT_KEYMAP_DEFS"] = tuple(_INSTANT_KEYMAP_DEFS)
    _PG["_SUS_1850_GIZMO_KEYMAP_DEFS"] = tuple()
    _PG["_SUS_1853_NATIVE_GIZMO_KEYMAP_NAMES"] = tuple(_NATIVE_GIZMO_KEYMAP_NAMES)
    _PG["_sus_1830_keymap_defs"] = lambda: tuple(_INSTANT_KEYMAP_DEFS)
    _PG["_sus_1834_keymap_defs"] = lambda: tuple(_INSTANT_KEYMAP_DEFS)
    _PG["_sus_1652_ensure_instant_keymaps"] = _ensure_instant_keymaps
    _PG["_sus_1652_promote_instant_keymaps_to_head"] = _ensure_instant_keymaps
    _PG["_sus_1652_set_instant_keymaps_active"] = _set_instant_keymaps_active
    _PG["_sus_1652_delete_instant_keymaps"] = _delete_instant_keymaps
    _PG["_sus_1652_gizmo_enable"] = _gizmo_enable_native_only
    _PG["_sus_1652_gizmo_disable"] = _gizmo_disable_native_only
    _PG["_sus_1871_press_select_drag_native_transform"] = True
    _PG["_sus_1871_target_material_freeze_guard"] = True


def apply_all(pkg_globals=None, context=None):
    global _PG, _STATIC_PATCHES_INSTALLED
    if pkg_globals is not None:
        _PG = pkg_globals
    ctx = context or bpy.context
    if not _STATIC_PATCHES_INSTALLED:
        _apply_keymap_exports()
        _install_target_material_freeze_guard()
        _patch_instant_class()
        _STATIC_PATCHES_INSTALLED = True
    try:
        ws_fn = _PG.get("_sus_1652_ws") if isinstance(_PG, dict) else None
        ws = ws_fn(ctx) if callable(ws_fn) else getattr(getattr(ctx, "scene", None), "suv_workspace", None)
        if ws is not None:
            if bool(getattr(ws, "operation_instant_select_enabled", False)):
                _ensure_instant_keymaps(True)
            else:
                _set_instant_keymaps_active(False)
            if bool(getattr(ws, "operation_uv_gizmo_grip_fix_enabled", False)):
                _gizmo_enable_native_only()
            else:
                _gizmo_disable_native_only(delete=False)
    except Exception:
        pass
    try:
        if isinstance(_PG, dict):
            _PG["_sus_1652_sync_keymaps_from_workspace"] = _sync
            _PG["_sus_1841_final_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1842_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1845_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1860_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1867_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1868_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1869_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
            _PG["_sus_1871_apply"] = lambda context=None: apply_all(_PG, context or bpy.context)
    except Exception:
        pass


def _sync(context=None):
    apply_all(_PG, context or bpy.context)


def install(pkg_globals):
    global _PG
    _PG = pkg_globals
    apply_all(pkg_globals, bpy.context)
