from __future__ import annotations

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None


def _tr(namespace: dict, context, key: str, en: str, ja: str, **fmt) -> str:
    fn = namespace.get('tr')
    text = None
    if callable(fn):
        try:
            text = fn(context, key, **fmt)
        except Exception:
            text = None
    if not text:
        text = en
    try:
        return text.format(**fmt)
    except Exception:
        return text




def _focus_mode_label(namespace: dict, context, mode: str) -> str:
    mode_id = str(mode or 'AUTO').upper()
    mapping = {
        'AUTO': ('ui.visual.focus_auto', 'AUTO', '自動'),
        'SETUP': ('ui.visual.focus_setup', 'Setup', '準備'),
        'REPAIR': ('ui.visual.focus_repair', 'Repair', '修復'),
        'COVERAGE': ('ui.visual.focus_coverage', 'Calc Coverage', '対応範囲'),
        'ANALYZE': ('ui.visual.focus_analyze', 'Analyze', '分析'),
        'ALL': ('ui.visual.focus_all', 'All', '全表示'),
    }
    key, en, ja = mapping.get(mode_id, ('ui.visual.focus_auto', mode_id, mode_id))
    return _tr(namespace, context, key, en, ja)


def _density_mode_label(namespace: dict, context, mode: str) -> str:
    mode_id = str(mode or 'AUTO').upper()
    mapping = {
        'AUTO': ('ui.visual.density_auto', 'AUTO', '自動'),
        'ESSENTIAL': ('ui.visual.density_essential', 'Essential', '要点'),
        'FULL': ('ui.visual.density_full', 'Full', '全表示'),
    }
    key, en, ja = mapping.get(mode_id, ('ui.visual.density_auto', mode_id, mode_id))
    return _tr(namespace, context, key, en, ja)


def _preset_mode_label(namespace: dict, context, mode: str) -> str:
    mode_id = str(mode or 'AUTO').upper()
    mapping = {
        'AUTO': ('ui.visual.preset.auto', 'Auto', '自動'),
        'START': ('ui.visual.preset.start', 'Starter', '入門'),
        'STARTER': ('ui.visual.preset.start', 'Starter', '入門'),
        'REPAIR': ('ui.visual.preset.repair', 'Repair', '修復'),
        'ANALYZE': ('ui.visual.preset.analyze', 'Analyze', '分析'),
        'FULL': ('ui.visual.preset.full', 'Full', '全体'),
        'CUSTOM': ('ui.visual.preset.custom', 'Custom', 'カスタム'),
    }
    key, en, ja = mapping.get(mode_id, ('ui.visual.preset.auto', mode_id, mode_id))
    return _tr(namespace, context, key, en, ja)


def _section_label(namespace: dict, context, section_id: str) -> str:
    sid = str(section_id or '')
    mapping = {
        'workflow': ('ui.visual.section_toggle.workflow', 'Workflow', 'ワークフロー'),
        'learning': ('ui.visual.section_toggle.learning', 'Guides', 'ガイド'),
        'maintenance': ('ui.visual.section_toggle.maintenance', 'Reports', 'レポート'),
        'all': ('ui.visual.section_toggle.all', 'All', '全体'),
    }
    key, en, ja = mapping.get(sid, ('ui.visual.section_toggle.all', sid, sid))
    return _tr(namespace, context, key, en, ja)


def _section_state_label(namespace: dict, context, shown: bool) -> str:
    return _tr(namespace, context, 'ui.visual.section_state.shown', 'shown', '表示') if bool(shown) else _tr(namespace, context, 'ui.visual.section_state.hidden', 'hidden', '非表示')

def _clear_state(namespace: dict):
    clear = namespace.get('clear_quality_state_cache')
    if callable(clear):
        try:
            clear(namespace)
        except Exception:
            pass


def notify_controls_changed(namespace: dict, context, reason: str = '') -> dict:
    sync_mod = namespace.get('_quality_sync_module')
    if sync_mod is not None and hasattr(sync_mod, 'effective_preset'):
        try:
            sync_mod.effective_preset(namespace, context)
        except Exception:
            pass
    revision = int(namespace.get('_suv_visual_controls_revision', 0) or 0) + 1
    namespace['_suv_visual_controls_revision'] = revision
    namespace['_suv_visual_controls_reason'] = str(reason or '')
    _clear_state(namespace)
    return scan_visual_controls(namespace, context)


def scan_visual_controls(namespace: dict, context) -> dict:
    focus_override = 'AUTO'
    focus_manual = False
    focus_effective = 'AUTO'
    density_override = 'AUTO'
    density_manual = False
    density_effective = 'FULL'
    preset_override = 'AUTO'
    preset_effective = 'AUTO'
    preset_manual = False
    preset_matched = True
    preset_label = 'AUTO'
    section_visibility = {'workflow': True, 'learning': True, 'maintenance': True}
    hidden_sections = 0
    visible_sections = 0

    focus_mod = namespace.get('_quality_focus_module')
    if focus_mod is not None and hasattr(focus_mod, 'scan_focus_control'):
        try:
            data = focus_mod.scan_focus_control(namespace, context) or {}
            focus_override = str(data.get('override', 'AUTO') or 'AUTO').upper()
            focus_manual = bool(data.get('manual', False))
            focus_effective = str(data.get('effective', 'auto') or 'auto').upper()
        except Exception:
            pass

    density_mod = namespace.get('_quality_density_module')
    if density_mod is not None and hasattr(density_mod, 'scan_density_control'):
        try:
            data = density_mod.scan_density_control(namespace, context) or {}
            density_override = str(data.get('override', 'AUTO') or 'AUTO').upper()
            density_manual = bool(data.get('manual', False))
            density_effective = str(data.get('effective', 'FULL') or 'FULL').upper()
        except Exception:
            pass

    section_mod = namespace.get('_quality_sections_module')
    if section_mod is not None and hasattr(section_mod, 'scan_section_controls'):
        try:
            data = section_mod.scan_section_controls(namespace, context) or {}
            section_visibility = dict(data.get('visibility', {}) or section_visibility)
            hidden_sections = int(data.get('hidden_sections', 0) or 0)
            visible_sections = int(data.get('visible_sections', 0) or 0)
        except Exception:
            pass

    preset_mod = namespace.get('_quality_presets_module')
    if preset_mod is not None and hasattr(preset_mod, 'scan_dashboard_preset'):
        try:
            data = preset_mod.scan_dashboard_preset(namespace, context) or {}
            preset_override = str(data.get('override', 'AUTO') or 'AUTO').upper()
            preset_effective = str(data.get('effective', preset_override) or preset_override).upper()
            preset_manual = bool(data.get('manual', False))
            preset_matched = bool(data.get('matched', True))
            preset_label = str(data.get('label', preset_effective) or preset_effective)
        except Exception:
            pass

    section_labels = {sid: _section_label(namespace, context, sid) for sid in ('workflow', 'learning', 'maintenance')}
    manual_items = []
    manual_item_labels = []
    if focus_manual:
        manual_items.append('focus')
        manual_item_labels.append(_tr(namespace, context, 'ui.visual.manual_item.focus', 'Manual focus override', '手動フォーカス上書き'))
    if density_manual:
        manual_items.append('density')
        manual_item_labels.append(_tr(namespace, context, 'ui.visual.manual_item.density', 'Manual dashboard density', '手動ダッシュボード密度'))
    for sid, shown in dict(section_visibility).items():
        if not bool(shown):
            manual_items.append(f'section:{sid}')
            manual_item_labels.append(_tr(namespace, context, 'ui.visual.manual_item.section', 'Hidden section: {section}', '非表示セクション: {section}', section=section_labels.get(str(sid), str(sid))))
    if preset_manual and not preset_matched:
        manual_items.append('preset:custom')
        manual_item_labels.append(_tr(namespace, context, 'ui.visual.manual_item.preset_custom', 'Custom preset state', 'カスタムプリセット状態'))
    manual_controls = len(manual_items)
    custom_active = bool(manual_controls > 0 or (preset_manual and not preset_matched))
    focus_override_label = _focus_mode_label(namespace, context, focus_override)
    focus_effective_label = _focus_mode_label(namespace, context, focus_effective)
    density_override_label = _density_mode_label(namespace, context, density_override)
    density_effective_label = _density_mode_label(namespace, context, density_effective)
    preset_override_label = _preset_mode_label(namespace, context, preset_override)
    preset_effective_label = _preset_mode_label(namespace, context, preset_effective)
    preset_display_label = str(preset_label or '') or preset_effective_label
    summary = _tr(
        namespace, context,
        'ui.visual.controls_summary',
        'Preset {preset} | Focus {focus} | Density {density} | Hidden sections {hidden}',
        'プリセット {preset} | フォーカス {focus} | 密度 {density} | 非表示セクション {hidden}',
        preset=preset_display_label,
        focus=(focus_override_label if focus_manual else focus_effective_label),
        density=(density_override_label if density_manual else density_effective_label),
        hidden=str(hidden_sections),
    )

    data = {
        'focus_override': focus_override,
        'focus_manual': focus_manual,
        'focus_effective': focus_effective,
        'density_override': density_override,
        'density_manual': density_manual,
        'density_effective': density_effective,
        'preset_override': preset_override,
        'preset_effective': preset_effective,
        'preset_manual': preset_manual,
        'preset_matched': preset_matched,
        'preset_label': preset_label,
        'focus_override_label': focus_override_label,
        'focus_effective_label': focus_effective_label,
        'density_override_label': density_override_label,
        'density_effective_label': density_effective_label,
        'preset_override_label': preset_override_label,
        'preset_effective_label': preset_effective_label,
        'preset_display_label': preset_display_label,
        'section_visibility': dict(section_visibility),
        'section_labels': dict(section_labels),
        'section_state_labels': {sid: _section_state_label(namespace, context, shown) for sid, shown in dict(section_visibility).items()},
        'hidden_sections': hidden_sections,
        'visible_sections': visible_sections,
        'manual_controls': manual_controls,
        'manual_items': list(manual_items),
        'manual_item_labels': list(manual_item_labels),
        'custom_active': custom_active,
        'summary': summary,
        'revision': int(namespace.get('_suv_visual_controls_revision', 0) or 0),
        'last_reason': str(namespace.get('_suv_visual_controls_reason', '') or ''),
    }
    namespace['_suv_visual_controls_last'] = dict(data)
    return data


def register(namespace: dict):
    namespace['_suv_visual_controls_last'] = {}
    namespace['_suv_visual_controls_revision'] = 0
    namespace['_suv_visual_controls_reason'] = ''
    return []


def unregister(namespace: dict | None = None):
    ns = namespace if isinstance(namespace, dict) else {}
    if isinstance(ns, dict):
        ns['_suv_visual_controls_last'] = {}
        ns['_suv_visual_controls_revision'] = 0
        ns['_suv_visual_controls_reason'] = ''
    return []
