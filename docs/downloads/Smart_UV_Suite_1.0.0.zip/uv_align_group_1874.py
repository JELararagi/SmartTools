# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Final strict grouping for Direction Align (Vertex) grouped actions.

Fixes G— / G| / G↔ / G↕ so that in UV EDGE/FACE modes only connected
selected edges/faces become one group. Vertex adjacency, visible unselected UV
edges, 3D mesh topology, and stale selection flags cannot merge groups.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence, Tuple

_NS: Dict[str, Any] = {}
_PREV_ATTR = "_suv_1874_previous_execute"
_DIGITS = 7
_GROUP_ACTIONS = {"ALIGN_H_GROUP", "ALIGN_V_GROUP", "DISTRIBUTE_H_GROUP", "DISTRIBUTE_V_GROUP"}


def _mode(context: Any) -> str:
    fn = _NS.get("_sus_1655_uv_mode")
    if callable(fn):
        try:
            return str(fn(context) or "VERTEX").upper()
        except Exception:
            pass
    try:
        return str(context.tool_settings.uv_select_mode or "VERTEX").upper()
    except Exception:
        return "VERTEX"


def _sticky(context: Any) -> str:
    fn = _NS.get("_sus_uv_sticky_select_mode")
    if callable(fn):
        try:
            return str(fn(context) or "DISABLED").upper()
        except Exception:
            pass
    return "DISABLED"


def _sync(context: Any) -> bool:
    try:
        return bool(getattr(getattr(context, "tool_settings", None), "use_uv_select_sync", False))
    except Exception:
        return False


def _edit_objects(context: Any) -> List[Any]:
    for name in ("_sus_1676a_edit_objects", "_sus_1674_edit_mesh_objects", "_sus_1658_edit_mesh_objects", "_sus_1660_edit_mesh_objects"):
        fn = _NS.get(name)
        if callable(fn):
            try:
                objs = [o for o in (fn(context) or []) if getattr(o, "type", "") == "MESH" and getattr(o, "mode", "") == "EDIT"]
                if objs:
                    return objs
            except Exception:
                pass
    try:
        objs = [o for o in (getattr(context, "objects_in_mode_unique_data", None) or []) if getattr(o, "type", "") == "MESH" and getattr(o, "mode", "") == "EDIT"]
        if objs:
            return objs
    except Exception:
        pass
    obj = getattr(context, "edit_object", None) or getattr(context, "active_object", None)
    if obj is not None and getattr(obj, "type", "") == "MESH" and getattr(obj, "mode", "") == "EDIT":
        return [obj]
    return []


def _obj_key(obj: Any) -> str:
    fn = _NS.get("_sus_1655_obj_key") or _NS.get("_sus_1653_obj_key")
    if callable(fn):
        try:
            return str(fn(obj))
        except Exception:
            pass
    try:
        return str(getattr(obj, "name_full", None) or getattr(obj, "name", None) or id(obj))
    except Exception:
        return str(id(obj))


def _attr_values(mesh: Any, name: str) -> List[Any]:
    fn = _NS.get("_sus_1655_attr_values")
    if callable(fn):
        try:
            return list(fn(mesh, name) or [])
        except Exception:
            pass
    try:
        attr = mesh.attributes.get(name)
        if attr is None:
            return []
        return [getattr(x, "value", False) for x in attr.data]
    except Exception:
        return []


def _uv_key(loop: Any, uv_layer: Any) -> Optional[Tuple[float, float]]:
    try:
        uv = loop[uv_layer].uv
        return (round(float(uv.x), _DIGITS), round(float(uv.y), _DIGITS))
    except Exception:
        return None


def _edge_sig(loop: Any, uv_layer: Any, obj_key: str, sticky: str) -> Optional[Any]:
    try:
        a = _uv_key(loop, uv_layer); b = _uv_key(loop.link_loop_next, uv_layer)
        if a is None or b is None:
            return None
        sticky = str(sticky or "DISABLED").upper()
        if sticky == "SHARED_LOCATION":
            return tuple(sorted((("uv", a), ("uv", b)), key=repr))
        if sticky == "SHARED_VERTEX":
            va = int(getattr(loop.vert, "index", -1)); vb = int(getattr(loop.link_loop_next.vert, "index", -1))
            return tuple(sorted((("vert", obj_key, va), ("vert", obj_key, vb)), key=repr))
        try:
            edge_index = int(getattr(loop.edge, "index", -1))
        except Exception:
            edge_index = -1
        return (obj_key, edge_index, tuple(sorted((a, b))))
    except Exception:
        return None


def _loop_uv_xy(loop: Any, uv_layer: Any) -> Tuple[float, float]:
    try:
        uv = loop[uv_layer].uv
        return float(uv.x), float(uv.y)
    except Exception:
        return 0.0, 0.0


def _edge_selected(loop: Any, uv_layer: Any, edge_attr: Sequence[Any], mesh_edge_attr: Sequence[Any], sync: bool) -> bool:
    for getter in (
        lambda: getattr(loop, "uv_select_edge", False),
        lambda: getattr(loop[uv_layer], "select_edge", False),
    ):
        try:
            if bool(getter()):
                return True
        except Exception:
            pass
    try:
        li = int(getattr(loop, "index", -1))
        if 0 <= li < len(edge_attr) and bool(edge_attr[li]):
            return True
    except Exception:
        pass
    if sync:
        try:
            ei = int(getattr(loop.edge, "index", -1))
            if 0 <= ei < len(mesh_edge_attr) and bool(mesh_edge_attr[ei]):
                return True
        except Exception:
            pass
        try:
            if bool(getattr(loop.edge, "select", False)):
                return True
        except Exception:
            pass
    return False


def _face_selected(face: Any, face_attr: Sequence[Any], mesh_face_attr: Sequence[Any], sync: bool) -> bool:
    for getter in (
        lambda: getattr(face, "uv_select", False),
    ):
        try:
            if bool(getter()):
                return True
        except Exception:
            pass
    try:
        fi = int(getattr(face, "index", -1))
        if 0 <= fi < len(face_attr) and bool(face_attr[fi]):
            return True
    except Exception:
        pass
    if sync:
        try:
            fi = int(getattr(face, "index", -1))
            if 0 <= fi < len(mesh_face_attr) and bool(mesh_face_attr[fi]):
                return True
        except Exception:
            pass
        try:
            if bool(getattr(face, "select", False)):
                return True
        except Exception:
            pass
    return False


def _find(parent: List[int], i: int) -> int:
    while parent[i] != i:
        parent[i] = parent[parent[i]]
        i = parent[i]
    return i


def _union(parent: List[int], a: int, b: int) -> None:
    try:
        if a < 0 or b < 0 or a >= len(parent) or b >= len(parent):
            return
        ra = _find(parent, a); rb = _find(parent, b)
        if ra != rb:
            parent[rb] = ra
    except Exception:
        pass


def _record(obj: Any, obj_key: str, mesh: Any, bm: Any, uv_layer: Any, face: Any, loop: Any, local_i: int) -> Dict[str, Any]:
    u, v = _loop_uv_xy(loop, uv_layer)
    fi = int(getattr(face, "index", -1))
    vi = int(getattr(loop.vert, "index", -1))
    li = int(getattr(loop, "index", -1))
    return {
        "obj": obj, "obj_key": obj_key, "mesh": mesh, "bm": bm,
        "uv_layer": uv_layer, "loop": loop, "face": face,
        "face_index": fi, "face_loop_index": int(local_i), "loop_index": li,
        "record_id": (obj_key, fi, int(local_i)),
        "vertex_index": vi, "uv_key": _uv_key(loop, uv_layer), "u": u, "v": v,
    }


def _collect_components(context: Any, mode: str) -> Tuple[List[List[Dict[str, Any]]], List[Any]]:
    import bmesh
    mode = str(mode or "VERTEX").upper()
    sticky = _sticky(context)
    sync = _sync(context)
    all_components: List[List[Dict[str, Any]]] = []
    meshes: List[Any] = []
    for obj in _edit_objects(context):
        mesh = getattr(obj, "data", None)
        if mesh is None:
            continue
        try:
            bm = bmesh.from_edit_mesh(mesh)
            bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
            bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update()
            uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        except Exception:
            continue
        meshes.append(mesh)
        obj_key = _obj_key(obj)
        edge_attr = _attr_values(mesh, ".uv_select_edge")
        face_attr = _attr_values(mesh, ".uv_select_face")
        mesh_edge_attr = _attr_values(mesh, ".select_edge")
        mesh_face_attr = _attr_values(mesh, ".select_poly")
        raw: List[Dict[str, Any]] = []
        parent: List[int] = []
        rec_by_id: Dict[Any, int] = {}
        endpoint_to_indices: Dict[Any, List[int]] = {}
        face_edge_sig_to_indices: Dict[Any, List[int]] = {}

        def add(face: Any, loop: Any, local_i: int) -> int:
            rid = (obj_key, int(getattr(face, "index", -1)), int(local_i))
            if rid in rec_by_id:
                return rec_by_id[rid]
            idx = len(raw)
            raw.append(_record(obj, obj_key, mesh, bm, uv_layer, face, loop, local_i))
            parent.append(idx); rec_by_id[rid] = idx
            return idx

        for face in bm.faces:
            try:
                if getattr(face, "hide", False):
                    continue
                loops = list(face.loops)
            except Exception:
                continue
            if not loops:
                continue
            if mode == "EDGE":
                for i, loop in enumerate(loops):
                    if not _edge_selected(loop, uv_layer, edge_attr, mesh_edge_attr, sync):
                        continue
                    a = add(face, loop, i)
                    b = add(face, loop.link_loop_next, (i + 1) % len(loops))
                    _union(parent, a, b)
                    ka = raw[a].get("uv_key"); kb = raw[b].get("uv_key")
                    if ka is not None:
                        endpoint_to_indices.setdefault(ka, []).append(a)
                    if kb is not None:
                        endpoint_to_indices.setdefault(kb, []).append(b)
            elif mode in {"FACE", "ISLAND"}:
                if not _face_selected(face, face_attr, mesh_face_attr, sync):
                    continue
                face_indices: List[int] = []
                for i, loop in enumerate(loops):
                    face_indices.append(add(face, loop, i))
                if face_indices:
                    root = face_indices[0]
                    for idx in face_indices[1:]:
                        _union(parent, root, idx)
                    for i, loop in enumerate(loops):
                        sig = _edge_sig(loop, uv_layer, obj_key, sticky)
                        if sig is not None:
                            face_edge_sig_to_indices.setdefault(sig, []).append(face_indices[i])
        if not raw:
            continue
        if mode == "EDGE":
            # Only selected UV-edge endpoint sharing connects selected edges.
            for idxs in endpoint_to_indices.values():
                if len(idxs) > 1:
                    base = idxs[0]
                    for idx in idxs[1:]:
                        _union(parent, base, idx)
        elif mode in {"FACE", "ISLAND"}:
            # Only selected faces sharing a complete UV edge connect.  Corner-only
            # contact and unselected-face adjacency remain separate components.
            for idxs in face_edge_sig_to_indices.values():
                if len(idxs) > 1:
                    base = idxs[0]
                    for idx in idxs[1:]:
                        _union(parent, base, idx)
        comps: Dict[int, List[Dict[str, Any]]] = {}
        order: List[int] = []
        for i, rec in enumerate(raw):
            root = _find(parent, i)
            if root not in comps:
                comps[root] = []; order.append(root)
            comps[root].append(rec)
        for root in order:
            comp = comps.get(root) or []
            if comp:
                all_components.append(comp)
    return all_components, meshes


def _point_key(rec: Dict[str, Any], sticky: str, i: int) -> Any:
    # Sticky is applied inside the already established selected-edge/face
    # component only.  It never merges two disconnected selected elements.
    sticky = str(sticky or "DISABLED").upper()
    if sticky == "SHARED_LOCATION":
        return ("uv", rec.get("uv_key"))
    if sticky == "SHARED_VERTEX":
        return ("vert", rec.get("obj_key"), rec.get("vertex_index"))
    return ("record", rec.get("record_id", i))


def _points_from_component(comp: Sequence[Dict[str, Any]], sticky: str) -> List[Dict[str, Any]]:
    buckets: Dict[Any, List[Dict[str, Any]]] = {}
    order: List[Any] = []
    for i, rec in enumerate(comp or []):
        key = _point_key(rec, sticky, i)
        if key not in buckets:
            buckets[key] = []; order.append(key)
        buckets[key].append(rec)
    points: List[Dict[str, Any]] = []
    for key in order:
        recs = buckets.get(key) or []
        if not recs:
            continue
        us = [float(r.get("u", 0.0)) for r in recs]
        vs = [float(r.get("v", 0.0)) for r in recs]
        points.append({"key": key, "records": recs, "u": sum(us) / len(us), "v": sum(vs) / len(vs)})
    return points


def _apply(points: Sequence[Dict[str, Any]], action: str) -> int:
    fn = _NS.get("_sus_1676a_apply_action") or _NS.get("_sus_1655_vertex_align_apply")
    if callable(fn):
        try:
            return int(fn(list(points), action))
        except TypeError:
            try:
                return int(fn(list(points), action, context=None))
            except Exception:
                pass
        except Exception:
            pass
    return 0


def _update(meshes: Sequence[Any]) -> None:
    try:
        import bmesh
        seen = set()
        for mesh in meshes or []:
            if mesh is None or id(mesh) in seen:
                continue
            seen.add(id(mesh))
            try:
                bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
            except TypeError:
                bmesh.update_edit_mesh(mesh)
            except Exception:
                pass
    except Exception:
        pass


def _execute(self: Any, context: Any) -> set:
    raw = str(getattr(self, "action", "") or "").upper()
    prev = getattr(type(self), _PREV_ATTR, None)
    if raw not in _GROUP_ACTIONS:
        if callable(prev):
            return prev(self, context)
        return {"CANCELLED"}
    mode = _mode(context)
    if mode not in {"EDGE", "FACE", "ISLAND"}:
        if callable(prev):
            return prev(self, context)
        return {"CANCELLED"}
    action = raw[:-6]
    try:
        comps, meshes = _collect_components(context, mode)
        if not comps:
            try:
                self.report({"WARNING"}, "選択されたUV辺またはUV面がありません。")
            except Exception:
                pass
            return {"CANCELLED"}
        sticky = _sticky(context)
        changed = 0
        for comp in comps:
            pts = _points_from_component(comp, sticky)
            if pts:
                changed += _apply(pts, action)
        if changed <= 0:
            # Some valid grouped operations are no-ops (already centered/even).
            return {"FINISHED"}
        _update(meshes)
        return {"FINISHED"}
    except Exception as exc:
        try:
            self.report({"WARNING"}, f"頂点方向整列に失敗しました。 {exc}")
        except Exception:
            pass
        return {"CANCELLED"}


def install(ns: Dict[str, Any]) -> None:
    global _NS
    _NS = ns
    cls = ns.get("SMARTUVSUITE_OT_vertex_align_action")
    if not isinstance(cls, type):
        return
    if getattr(cls, _PREV_ATTR, None) is None:
        current = getattr(cls, "execute", None)
        if callable(current) and current is not _execute:
            setattr(cls, _PREV_ATTR, current)
    cls.execute = _execute


def apply_all(ns: Dict[str, Any], context: Any = None) -> None:
    install(ns)


def unregister() -> None:
    pass
