# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Smart UV Suite direction-align selection preservation layer.

Direction alignment changes coordinates only. It must not broaden the active UV
selection when legacy alignment backends temporarily switch mesh/UV selection
modes or use Blender selection helpers internally. This layer snapshots the UV
and mesh edit selection immediately before vertex/island/unified direction
alignment and restores the exact UV-domain selection flags after the backend has
finished.
"""
from __future__ import annotations

from functools import wraps
from typing import Any, Dict, Iterable, List, Optional

import bpy

_NS: Dict[str, Any] = {}
_VERTEX_PREV_ATTR = "_sus_18111_selection_guard_prev_vertex_execute"
_ISLAND_PREV_ATTR = "_sus_18111_selection_guard_prev_island_execute"
_DIRECTION_PREV_ATTR = "_sus_18111_selection_guard_prev_direction_execute"
_GUARD_MARK = "_sus_18111_direction_align_selection_guard"

SelectionState = Dict[str, Any]


def _object_key(obj: Any) -> int:
    try:
        data = getattr(obj, "data", None)
        if data is not None:
            return int(data.as_pointer())
    except Exception:
        pass
    try:
        return int(obj.as_pointer())
    except Exception:
        return id(obj)


def _edit_objects(context: Any) -> List[Any]:
    objs: List[Any] = []
    seen = set()

    def _append(obj: Any) -> None:
        if obj is None or getattr(obj, "type", None) != "MESH":
            return
        key = _object_key(obj)
        if key in seen:
            return
        seen.add(key)
        objs.append(obj)

    try:
        for obj in getattr(context, "objects_in_mode_unique_data", ()) or ():
            _append(obj)
    except Exception:
        pass
    for attr in ("edit_object", "active_object", "object"):
        try:
            _append(getattr(context, attr, None))
        except Exception:
            pass
    return objs


def _ensure_tables(bm: Any) -> None:
    for seq_name in ("verts", "edges", "faces"):
        try:
            seq = getattr(bm, seq_name)
            seq.ensure_lookup_table()
            seq.index_update()
        except Exception:
            pass


def _safe_bool_get(obj: Any, attr: str, default: bool = False) -> bool:
    try:
        return bool(getattr(obj, attr))
    except Exception:
        return bool(default)


def _safe_set(obj: Any, attr: str, value: bool) -> None:
    try:
        setattr(obj, attr, bool(value))
    except Exception:
        pass


def _call_setter(obj: Any, name: str, value: bool) -> bool:
    try:
        fn = getattr(obj, name, None)
        if callable(fn):
            fn(bool(value))
            return True
    except Exception:
        pass
    return False


def _snapshot_object(obj: Any) -> Optional[SelectionState]:
    try:
        import bmesh
    except Exception:
        return None
    try:
        mesh = getattr(obj, "data", None)
        if mesh is None or getattr(obj, "mode", "") != "EDIT":
            return None
        bm = bmesh.from_edit_mesh(mesh)
        _ensure_tables(bm)
        uv_layer = bm.loops.layers.uv.active
        if uv_layer is None:
            try:
                uv_layer = bm.loops.layers.uv.verify()
            except Exception:
                uv_layer = None
        try:
            tool_settings = getattr(bpy.context, "tool_settings", None)
            uv_select_mode = str(getattr(tool_settings, "uv_select_mode", "VERTEX") or "VERTEX")
            use_uv_select_sync = bool(getattr(tool_settings, "use_uv_select_sync", False))
        except Exception:
            uv_select_mode = "VERTEX"
            use_uv_select_sync = False
        state: SelectionState = {
            "object": obj,
            "mesh": mesh,
            "verts": {},
            "edges": {},
            "faces": {},
            "loops": {},
            "has_uv_layer": uv_layer is not None,
            "uv_select_mode": uv_select_mode,
            "use_uv_select_sync": use_uv_select_sync,
        }
        for vert in bm.verts:
            try:
                state["verts"][int(vert.index)] = bool(vert.select)
            except Exception:
                pass
        for edge in bm.edges:
            try:
                state["edges"][int(edge.index)] = bool(edge.select)
            except Exception:
                pass
        for face in bm.faces:
            try:
                face_index = int(face.index)
            except Exception:
                continue
            state["faces"][face_index] = {
                "select": bool(getattr(face, "select", False)),
                "uv_select": _safe_bool_get(face, "uv_select", False),
            }
            if uv_layer is None:
                continue
            try:
                loops = list(face.loops)
            except Exception:
                loops = []
            for local_index, loop in enumerate(loops):
                try:
                    luv = loop[uv_layer]
                except Exception:
                    luv = None
                loop_key = (face_index, int(local_index))
                state["loops"][loop_key] = {
                    "loop_index": int(getattr(loop, "index", -1)),
                    "uv_select_vert": _safe_bool_get(loop, "uv_select_vert", False),
                    "uv_select_edge": _safe_bool_get(loop, "uv_select_edge", False),
                    "luv_select": _safe_bool_get(luv, "select", False) if luv is not None else False,
                    "luv_select_edge": _safe_bool_get(luv, "select_edge", False) if luv is not None else False,
                }
        return state
    except Exception:
        return None


def _snapshot_selection(context: Any) -> List[SelectionState]:
    states: List[SelectionState] = []
    for obj in _edit_objects(context):
        state = _snapshot_object(obj)
        if state is not None:
            states.append(state)
    return states


def _restore_mesh_element_selection(bm: Any, state: SelectionState) -> None:
    try:
        for index, selected in (state.get("verts") or {}).items():
            try:
                bm.verts[int(index)].select_set(bool(selected))
            except Exception:
                pass
    except Exception:
        pass
    try:
        for index, selected in (state.get("edges") or {}).items():
            try:
                bm.edges[int(index)].select_set(bool(selected))
            except Exception:
                pass
    except Exception:
        pass
    try:
        for index, face_state in (state.get("faces") or {}).items():
            try:
                face = bm.faces[int(index)]
            except Exception:
                continue
            try:
                face.select_set(bool((face_state or {}).get("select", False)))
            except Exception:
                _safe_set(face, "select", bool((face_state or {}).get("select", False)))
            uv_selected = bool((face_state or {}).get("uv_select", False))
            if not _call_setter(face, "uv_select_set", uv_selected):
                _safe_set(face, "uv_select", uv_selected)
    except Exception:
        pass


def _iter_state_loops(bm: Any, state: SelectionState):
    for key, loop_state in (state.get("loops") or {}).items():
        try:
            face_index, local_index = key
            face = bm.faces[int(face_index)]
            loop = list(face.loops)[int(local_index)]
        except Exception:
            continue
        yield loop, loop_state


def _clear_uv_selection(bm: Any, uv_layer: Any) -> None:
    if uv_layer is None:
        return
    try:
        for face in bm.faces:
            if not _call_setter(face, "uv_select_set", False):
                _safe_set(face, "uv_select", False)
            for loop in face.loops:
                if not _call_setter(loop, "uv_select_vert_set", False):
                    _safe_set(loop, "uv_select_vert", False)
                if not _call_setter(loop, "uv_select_edge_set", False):
                    _safe_set(loop, "uv_select_edge", False)
                try:
                    luv = loop[uv_layer]
                except Exception:
                    luv = None
                if luv is not None:
                    _safe_set(luv, "select", False)
                    _safe_set(luv, "select_edge", False)
    except Exception:
        pass


def _restore_loop_selection(bm: Any, uv_layer: Any, state: SelectionState) -> None:
    if uv_layer is None:
        return
    mode = str(state.get("uv_select_mode", "VERTEX") or "VERTEX").upper()
    _clear_uv_selection(bm, uv_layer)

    if mode in {"FACE", "ISLAND"}:
        use_sync = bool(state.get("use_uv_select_sync", False))
        loop_face_selected: Dict[int, bool] = {}
        for key, loop_state in (state.get("loops") or {}).items():
            try:
                face_index = int(key[0])
            except Exception:
                continue
            if bool((loop_state or {}).get("uv_select_vert", False) or (loop_state or {}).get("uv_select_edge", False) or (loop_state or {}).get("luv_select", False) or (loop_state or {}).get("luv_select_edge", False)):
                loop_face_selected[face_index] = True
        for index, face_state in (state.get("faces") or {}).items():
            try:
                face_index = int(index)
            except Exception:
                continue
            selected = bool((face_state or {}).get("uv_select", False) or loop_face_selected.get(face_index, False))
            if use_sync:
                selected = bool(selected or (face_state or {}).get("select", False))
            if not selected:
                continue
            try:
                face = bm.faces[face_index]
            except Exception:
                continue
            if not _call_setter(face, "uv_select_set", True):
                _safe_set(face, "uv_select", True)
            for loop in list(getattr(face, "loops", ()) or ()):
                if not _call_setter(loop, "uv_select_vert_set", True):
                    _safe_set(loop, "uv_select_vert", True)
                if not _call_setter(loop, "uv_select_edge_set", True):
                    _safe_set(loop, "uv_select_edge", True)
        return

    if mode == "EDGE":
        for loop, loop_state in _iter_state_loops(bm, state):
            if bool((loop_state or {}).get("uv_select_edge", False)):
                if not _call_setter(loop, "uv_select_edge_set", True):
                    _safe_set(loop, "uv_select_edge", True)
            try:
                luv = loop[uv_layer]
            except Exception:
                luv = None
            if luv is not None and bool((loop_state or {}).get("luv_select_edge", False)):
                _safe_set(luv, "select_edge", True)
        return

    for loop, loop_state in _iter_state_loops(bm, state):
        if bool((loop_state or {}).get("uv_select_vert", False)):
            if not _call_setter(loop, "uv_select_vert_set", True):
                _safe_set(loop, "uv_select_vert", True)
        try:
            luv = loop[uv_layer]
        except Exception:
            luv = None
        if luv is not None and bool((loop_state or {}).get("luv_select", False)):
            _safe_set(luv, "select", True)


def _restore_selection(context: Any, states: Iterable[SelectionState]) -> None:
    try:
        import bmesh
    except Exception:
        return
    for state in states or ():
        try:
            obj = state.get("object")
            mesh = state.get("mesh")
            if obj is None or mesh is None or getattr(obj, "mode", "") != "EDIT":
                continue
            bm = bmesh.from_edit_mesh(mesh)
            _ensure_tables(bm)
            uv_layer = bm.loops.layers.uv.active
            if uv_layer is None and bool(state.get("has_uv_layer", False)):
                try:
                    uv_layer = bm.loops.layers.uv.verify()
                except Exception:
                    uv_layer = None
            _restore_mesh_element_selection(bm, state)
            _restore_loop_selection(bm, uv_layer, state)
            try:
                bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
            except TypeError:
                try:
                    bmesh.update_edit_mesh(mesh, False, False)
                except Exception:
                    pass
            except Exception:
                pass
            try:
                _restore_loop_selection(bm, uv_layer, state)
            except Exception:
                pass
        except Exception:
            continue


def _make_guarded_execute(previous_execute: Any):
    @wraps(previous_execute)
    def _execute(self, context):
        selection_state = _snapshot_selection(context)
        try:
            return previous_execute(self, context)
        finally:
            _restore_selection(context, selection_state)

    setattr(_execute, _GUARD_MARK, True)
    setattr(_execute, "_sus_18111_previous_execute", previous_execute)
    return _execute


def _wrap_execute(cls: Any, prev_attr: str) -> None:
    if cls is None:
        return
    try:
        current = getattr(cls, "execute", None)
    except Exception:
        current = None
    if current is None:
        return
    try:
        if bool(getattr(current, _GUARD_MARK, False)):
            return
    except Exception:
        pass
    try:
        setattr(cls, prev_attr, current)
        setattr(cls, "execute", _make_guarded_execute(current))
    except Exception:
        pass


def install(ns: Optional[Dict[str, Any]] = None, context=None) -> None:
    global _NS
    if isinstance(ns, dict):
        _NS = ns
    source = ns if isinstance(ns, dict) else _NS
    vertex_cls = source.get("SMARTUVSUITE_OT_vertex_align_action")
    island_cls = source.get("SMARTUVSUITE_OT_island_direction_align")
    direction_cls = source.get("SMARTUVSUITE_OT_direction_align")
    if vertex_cls is None or island_cls is None or direction_cls is None:
        try:
            import smart_uv_suite as _pkg  # type: ignore
            vertex_cls = vertex_cls or getattr(_pkg, "SMARTUVSUITE_OT_vertex_align_action", None)
            island_cls = island_cls or getattr(_pkg, "SMARTUVSUITE_OT_island_direction_align", None)
            direction_cls = direction_cls or getattr(_pkg, "SMARTUVSUITE_OT_direction_align", None)
        except Exception:
            pass
    if direction_cls is None:
        try:
            from . import uv_direction_align_unified_18111 as _unified
            direction_cls = getattr(_unified, "SMARTUVSUITE_OT_direction_align", None)
        except Exception:
            direction_cls = None
    _wrap_execute(vertex_cls, _VERTEX_PREV_ATTR)
    _wrap_execute(island_cls, _ISLAND_PREV_ATTR)
    _wrap_execute(direction_cls, _DIRECTION_PREV_ATTR)


apply_all = install


def register() -> None:
    install(_NS, bpy.context)


def unregister() -> None:
    source = _NS or {}
    for class_name, prev_attr in (
        ("SMARTUVSUITE_OT_vertex_align_action", _VERTEX_PREV_ATTR),
        ("SMARTUVSUITE_OT_island_direction_align", _ISLAND_PREV_ATTR),
        ("SMARTUVSUITE_OT_direction_align", _DIRECTION_PREV_ATTR),
    ):
        try:
            cls = source.get(class_name)
        except Exception:
            cls = None
        if cls is None:
            try:
                import smart_uv_suite as _pkg  # type: ignore
                cls = getattr(_pkg, class_name, None)
            except Exception:
                cls = None
        if cls is None:
            continue
        try:
            current = getattr(cls, "execute", None)
            previous = getattr(cls, prev_attr, None)
            if previous is not None and bool(getattr(current, _GUARD_MARK, False)):
                setattr(cls, "execute", previous)
                try:
                    delattr(cls, prev_attr)
                except Exception:
                    pass
        except Exception:
            pass


def diagnostics(context=None) -> Dict[str, Any]:
    source = _NS or {}
    result: Dict[str, Any] = {}
    for class_name in ("SMARTUVSUITE_OT_vertex_align_action", "SMARTUVSUITE_OT_island_direction_align", "SMARTUVSUITE_OT_direction_align"):
        cls = source.get(class_name)
        if cls is None and class_name == "SMARTUVSUITE_OT_direction_align":
            try:
                from . import uv_direction_align_unified_18111 as _unified
                cls = getattr(_unified, class_name, None)
            except Exception:
                cls = None
        execute = getattr(cls, "execute", None) if cls is not None else None
        result[class_name] = bool(getattr(execute, _GUARD_MARK, False))
    return result

# -----------------------------------------------------------------------------
# 1.8.117 sync-on UV-only restoration supplement.
# Direction Align must not re-promote 3D View-only mesh selections into the UV
# Editor while UV Select Sync is enabled.
# -----------------------------------------------------------------------------
_SUS_18117_PREV_RESTORE_MESH_ELEMENT_SELECTION = _restore_mesh_element_selection
_SUS_18117_PREV_RESTORE_LOOP_SELECTION = _restore_loop_selection


def _state_mode(state: SelectionState) -> str:
    try:
        text = str(state.get("uv_select_mode", "VERTEX") or "VERTEX").upper()
    except Exception:
        text = "VERTEX"
    if "FACE" in text or "ISLAND" in text:
        return "FACE"
    if "EDGE" in text:
        return "EDGE"
    return "VERTEX"


def _state_loop_is_uv_selected(loop_state: Dict[str, Any], mode: str) -> bool:
    if mode == "EDGE":
        return bool((loop_state or {}).get("uv_select_edge", False) or (loop_state or {}).get("luv_select_edge", False))
    if mode == "FACE":
        return bool(
            (loop_state or {}).get("uv_select_vert", False)
            or (loop_state or {}).get("uv_select_edge", False)
            or (loop_state or {}).get("luv_select", False)
            or (loop_state or {}).get("luv_select_edge", False)
        )
    return bool((loop_state or {}).get("uv_select_vert", False) or (loop_state or {}).get("luv_select", False))


def _clear_mesh_selection_domain(bm: Any) -> None:
    try:
        for face in bm.faces:
            try:
                face.select_set(False)
            except Exception:
                _safe_set(face, "select", False)
        for edge in bm.edges:
            try:
                edge.select_set(False)
            except Exception:
                _safe_set(edge, "select", False)
        for vert in bm.verts:
            try:
                vert.select_set(False)
            except Exception:
                _safe_set(vert, "select", False)
    except Exception:
        pass


def _restore_mesh_element_selection(bm: Any, state: SelectionState) -> None:  # type: ignore[override]
    if not bool(state.get("use_uv_select_sync", False)):
        return _SUS_18117_PREV_RESTORE_MESH_ELEMENT_SELECTION(bm, state)
    mode = _state_mode(state)
    _clear_mesh_selection_domain(bm)
    try:
        if mode == "FACE":
            selected_faces = set()
            for index, face_state in (state.get("faces") or {}).items():
                try:
                    if bool((face_state or {}).get("uv_select", False)):
                        selected_faces.add(int(index))
                except Exception:
                    pass
            for key, loop_state in (state.get("loops") or {}).items():
                try:
                    face_index = int(key[0])
                except Exception:
                    continue
                if _state_loop_is_uv_selected(loop_state or {}, mode):
                    selected_faces.add(face_index)
            for face_index in selected_faces:
                try:
                    face = bm.faces[int(face_index)]
                except Exception:
                    continue
                try:
                    face.select_set(True)
                except Exception:
                    _safe_set(face, "select", True)
                try:
                    for loop in list(face.loops):
                        try:
                            loop.vert.select_set(True)
                            loop.edge.select_set(True)
                        except Exception:
                            pass
                except Exception:
                    pass
            return
        if mode == "EDGE":
            for loop, loop_state in _iter_state_loops(bm, state):
                if not _state_loop_is_uv_selected(loop_state or {}, mode):
                    continue
                try:
                    loop.edge.select_set(True)
                except Exception:
                    pass
                try:
                    loop.vert.select_set(True)
                    loop.link_loop_next.vert.select_set(True)
                except Exception:
                    pass
            return
        for loop, loop_state in _iter_state_loops(bm, state):
            if not _state_loop_is_uv_selected(loop_state or {}, mode):
                continue
            try:
                loop.vert.select_set(True)
            except Exception:
                pass
    except Exception:
        pass


def _restore_loop_selection(bm: Any, uv_layer: Any, state: SelectionState) -> None:  # type: ignore[override]
    if uv_layer is None:
        return
    mode = _state_mode(state)
    _clear_uv_selection(bm, uv_layer)
    if mode == "FACE":
        selected_faces = set()
        for index, face_state in (state.get("faces") or {}).items():
            try:
                if bool((face_state or {}).get("uv_select", False)):
                    selected_faces.add(int(index))
            except Exception:
                pass
        for key, loop_state in (state.get("loops") or {}).items():
            try:
                face_index = int(key[0])
            except Exception:
                continue
            if _state_loop_is_uv_selected(loop_state or {}, mode):
                selected_faces.add(face_index)
        for face_index in selected_faces:
            try:
                face = bm.faces[int(face_index)]
            except Exception:
                continue
            if not _call_setter(face, "uv_select_set", True):
                _safe_set(face, "uv_select", True)
            try:
                for loop in list(face.loops):
                    if not _call_setter(loop, "uv_select_edge_set", True):
                        _safe_set(loop, "uv_select_edge", True)
                for loop in list(face.loops):
                    if not _call_setter(loop, "uv_select_vert_set", True):
                        _safe_set(loop, "uv_select_vert", True)
                    try:
                        luv = loop[uv_layer]
                        _safe_set(luv, "select", True)
                        _safe_set(luv, "select_edge", True)
                    except Exception:
                        pass
            except Exception:
                pass
        return
    if mode == "EDGE":
        for loop, loop_state in _iter_state_loops(bm, state):
            if bool((loop_state or {}).get("uv_select_vert", False) or (loop_state or {}).get("luv_select", False)):
                if not _call_setter(loop, "uv_select_vert_set", True):
                    _safe_set(loop, "uv_select_vert", True)
                try:
                    _safe_set(loop[uv_layer], "select", True)
                except Exception:
                    pass
        for loop, loop_state in _iter_state_loops(bm, state):
            if bool((loop_state or {}).get("uv_select_edge", False) or (loop_state or {}).get("luv_select_edge", False)):
                if not _call_setter(loop, "uv_select_edge_set", True):
                    _safe_set(loop, "uv_select_edge", True)
                try:
                    _safe_set(loop[uv_layer], "select_edge", True)
                except Exception:
                    pass
        return
    for loop, loop_state in _iter_state_loops(bm, state):
        if bool((loop_state or {}).get("uv_select_edge", False) or (loop_state or {}).get("luv_select_edge", False)):
            if not _call_setter(loop, "uv_select_edge_set", True):
                _safe_set(loop, "uv_select_edge", True)
            try:
                _safe_set(loop[uv_layer], "select_edge", True)
            except Exception:
                pass
    for loop, loop_state in _iter_state_loops(bm, state):
        if bool((loop_state or {}).get("uv_select_vert", False) or (loop_state or {}).get("luv_select", False)):
            if not _call_setter(loop, "uv_select_vert_set", True):
                _safe_set(loop, "uv_select_vert", True)
            try:
                _safe_set(loop[uv_layer], "select", True)
            except Exception:
                pass
