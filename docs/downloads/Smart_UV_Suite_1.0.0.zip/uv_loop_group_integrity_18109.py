# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Smart UV Suite 1.8.109 UV-wire loop and strict grouped-align layer.

This module is the final runtime authority for the A/B image issues:

* Loop Select follows the UV wire graph, not an angle heuristic.  At each UV
  vertex it continues only through the single topologically valid continuation
  edge that does not share a quad/face corner with the incoming edge.  If the UV
  wire reaches a square corner, pole, branch, or ambiguous junction, the loop
  stops.  This matches the UV Unwrap-style loop selection expectation.
* Direction Align (Vertex) grouped actions G— / G| / G↔ / G↕ use only the live
  UV Editor selection.  3D View mesh selection, common mesh-edge identity, common
  mesh-vertex identity, and sticky modes never merge UV-separated groups and can
  never move unselected UV elements.
"""
from __future__ import annotations

from collections import defaultdict
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

import bpy

from . import uv_room_integrity_18103 as ri
from . import uv_multi_object_18104 as mo
from . import uv_selection_corrector_18106 as sc

_VERSION = (1, 8, 109)
_GROUP_ACTIONS = {"ALIGN_H_GROUP", "ALIGN_V_GROUP", "DISTRIBUTE_H_GROUP", "DISTRIBUTE_V_GROUP"}
_DISTRIBUTE_GROUP_ACTIONS = {"DISTRIBUTE_H_GROUP", "DISTRIBUTE_V_GROUP"}
_NS: Dict[str, Any] = {}
_PREV: Dict[str, Any] = {}
_EPS = 1.0e-12
_DIGITS = 7


def _s(value: Any) -> str:
    try:
        return str(value or "")
    except Exception:
        return ""


def _tr(context: Any, en: str, ja: str) -> str:
    return ri._tr(context, en, ja)


def _report(op: Any, level: str, message: str) -> None:
    try:
        op.report({level}, message)
    except Exception:
        pass


def _hidden(elem: Any) -> bool:
    try:
        return bool(getattr(elem, "hide", False))
    except Exception:
        return False


def _mesh_key(obj: Any) -> int:
    try:
        data = getattr(obj, "data", None)
        if data is not None and hasattr(data, "as_pointer"):
            return int(data.as_pointer())
    except Exception:
        pass
    try:
        return id(getattr(obj, "data", obj))
    except Exception:
        return id(obj)


def _face_index(face: Any) -> int:
    try:
        return int(getattr(face, "index", -1))
    except Exception:
        return -1


def _loop_index(loop: Any) -> int:
    try:
        return int(getattr(loop, "index", -1))
    except Exception:
        return -1


def _loop_record_key(obj: Any, loop: Any) -> Tuple[int, int, int]:
    try:
        return (_mesh_key(obj), _face_index(loop.face), _loop_index(loop))
    except Exception:
        return (_mesh_key(obj), -1, id(loop))


def _uv_xy(loop: Any, uv_layer: Any) -> Tuple[float, float]:
    try:
        uv = loop[uv_layer].uv
        return float(uv.x), float(uv.y)
    except Exception:
        return 0.0, 0.0


def _uv_key(loop: Any, uv_layer: Any) -> Tuple[float, float]:
    u, v = _uv_xy(loop, uv_layer)
    return (round(u, _DIGITS), round(v, _DIGITS))


def _endpoint_key(obj: Any, loop: Any, uv_layer: Any) -> Tuple[int, int, Tuple[float, float]]:
    try:
        vi = int(getattr(loop.vert, "index", -1))
    except Exception:
        vi = -1
    return (_mesh_key(obj), vi, _uv_key(loop, uv_layer))


def _visual_edge_key(obj: Any, loop: Any, uv_layer: Any) -> Tuple[Any, Any]:
    a = _endpoint_key(obj, loop, uv_layer)
    try:
        b = _endpoint_key(obj, loop.link_loop_next, uv_layer)
    except Exception:
        b = a
    return tuple(sorted((a, b), key=lambda item: (item[0], item[1], item[2][0], item[2][1])))  # type: ignore[return-value]


def _live_v(loop: Any, uv_layer: Any) -> bool:
    try:
        return bool(ri._live_v(loop, uv_layer))
    except Exception:
        try:
            return bool(getattr(loop[uv_layer], "select", False))
        except Exception:
            return False


def _live_e(loop: Any, uv_layer: Any) -> bool:
    try:
        return bool(ri._live_e(loop, uv_layer))
    except Exception:
        try:
            return bool(getattr(loop[uv_layer], "select_edge", False))
        except Exception:
            return False


def _face_loop_count(face: Any) -> int:
    try:
        return len(list(face.loops))
    except Exception:
        return 0


# -----------------------------------------------------------------------------
# Loop selection: UV-wire topology, no angle heuristic
# -----------------------------------------------------------------------------

def _single_wire_continuation(current: Any, endpoint: Any, by_endpoint: Dict[Any, List[Any]], visited: Set[Tuple[Any, Any]]) -> Optional[Any]:
    """Return the unique UV-wire continuation edge, or stop.

    3ds Max Unwrap-style UV loop selection is topology driven.  From the current
    visual edge and endpoint, the loop continues only if exactly one adjacent
    visual edge is topologically a continuation: it must not share a face with
    the incoming edge.  Adjacent edges around the same quad corner share a face,
    so the loop stops there.  Branches/poles with multiple continuations also
    stop instead of using an angle to guess.
    """
    candidates: List[Any] = []
    try:
        items = list(by_endpoint.get(endpoint, []) or [])
    except Exception:
        items = []
    for cand in items:
        try:
            if cand.key == current.key or cand.key in visited:
                continue
            if getattr(cand, "length", 0.0) <= getattr(sc, "_EPS", 1.0e-7):
                continue
            candidates.append(cand)
        except Exception:
            pass
    if not candidates:
        return None
    try:
        non_shared = [cand for cand in candidates if not sc._edge_shares_face(current, cand)]
    except Exception:
        non_shared = []
    if len(non_shared) != 1:
        return None
    return non_shared[0]


def _walk_loop_visual_18109(seed: Any, endpoint: Any, by_endpoint: Dict[Any, List[Any]], out: Set[Tuple[Any, Any]], limit: int) -> None:
    current = seed
    at = endpoint
    steps = 0
    while steps < limit:
        steps += 1
        nxt = _single_wire_continuation(current, at, by_endpoint, out)
        if nxt is None:
            break
        try:
            out.add(nxt.key)
            at = sc._edge_other_endpoint(nxt, at)
            current = nxt
        except Exception:
            break


def _visual_loop_keys_18109(seed_keys: Set[Tuple[Any, Any]], visual_edges: Dict[Tuple[Any, Any], Any], by_endpoint: Dict[Any, List[Any]]) -> Set[Tuple[Any, Any]]:
    out: Set[Tuple[Any, Any]] = {key for key in (seed_keys or set()) if key in visual_edges}
    limit = max(32, len(visual_edges) + 8)
    for key in list(out):
        rec = visual_edges.get(key)
        if rec is None:
            continue
        try:
            endpoints = list(rec.endpoints)
        except Exception:
            endpoints = []
        for endpoint in endpoints:
            _walk_loop_visual_18109(rec, endpoint, by_endpoint, out, limit)
    return out


def _live_edge_loops(bm: Any, uv_layer: Any) -> Set[Any]:
    out: Set[Any] = set()
    try:
        faces = [f for f in bm.faces if not _hidden(f)]
    except Exception:
        faces = []
    for face in faces:
        try:
            loops = list(face.loops)
        except Exception:
            loops = []
        for loop in loops:
            try:
                if _live_e(loop, uv_layer):
                    out.add(loop)
            except Exception:
                pass
    return out


def _selection_loop_ring_18109(context: Any, obj: Any, bm: Any, uv_layer: Any, action: str, edge_loops: Set[Any]):
    action = _s(action).upper()
    mode = ri._uv_mode(context)
    seed_keys = sc._selected_visual_edge_keys(edge_loops, uv_layer)
    if not seed_keys:
        return set(), set(), set()
    visual_edges, by_endpoint = sc._collect_visual_edges(bm, uv_layer)
    if not visual_edges:
        return set(), set(), set()
    if action == "RING":
        selected_keys = sc._visual_ring_keys(seed_keys, visual_edges, uv_layer)
    else:
        selected_keys = _visual_loop_keys_18109(seed_keys, visual_edges, by_endpoint)
    out_edges = sc._edge_loops_from_visual_keys(selected_keys, visual_edges)
    if mode == "FACE":
        return set(), set(), {loop.face for loop in out_edges if getattr(loop, "face", None) is not None}
    if mode == "VERTEX":
        out_loops: Set[Any] = set()
        for loop in out_edges:
            out_loops.add(loop)
            try:
                out_loops.add(loop.link_loop_next)
            except Exception:
                pass
        return out_loops, set(), set()
    return set(), out_edges, set()


def _execute_select_multi_18109(self: Any, context: Any):
    action = _s(getattr(self, "action", "GROW")).upper() or "GROW"
    if action not in {"LOOP", "RING"}:
        prev = _PREV.get("select_execute")
        if callable(prev) and prev is not _execute_select_multi_18109:
            return prev(self, context)
        return {"CANCELLED"}
    snap = ri._snapshot_modes(context)
    objs, state = mo._ensure_multi_edit(context)
    if not objs:
        _report(self, "WARNING", _tr(context, "No mesh object is active.", "アクティブなメッシュオブジェクトがありません。"))
        return {"CANCELLED"}
    try:
        mo._prepare_unwrap_channel(context)
        targets = mo._target_data(context)
        if not targets:
            _report(self, "WARNING", _tr(context, "No editable UV map is available.", "編集可能なUVマップがありません。"))
            return {"CANCELLED"}
        mode = ri._uv_mode(context)
        touched = 0
        for obj, bm, uv_layer in targets:
            ri._sync_uv_flags_from_mesh(context, bm)
            edge_loops = _live_edge_loops(bm, uv_layer)
            if not edge_loops:
                continue
            out = _selection_loop_ring_18109(context, obj, bm, uv_layer, action, edge_loops)
            ri._apply_selection(context, obj, bm, uv_layer, mode, out[0], out[1], out[2])
            touched += 1
        if touched <= 0:
            _report(self, "WARNING", _tr(context, "No UV editor edge is selected.", "UVエディターで選択された辺がありません。"))
            return {"CANCELLED"}
        mo._update_meshes(targets)
        try:
            area = getattr(context, "area", None)
            if area is not None:
                area.tag_redraw()
        except Exception:
            pass
        return {"FINISHED"}
    except Exception as exc:
        _report(self, "WARNING", _tr(context, "UV loop/ring selection failed.", "UVループ/リング選択に失敗しました。") + f" {exc}")
        return {"CANCELLED"}
    finally:
        ri._restore_modes(snap)
        mo._restore_multi_edit(context, state)
        ri._restore_modes(snap)


# -----------------------------------------------------------------------------
# Grouped Direction Align: live UV selection only / selected records only
# -----------------------------------------------------------------------------

def _make_record(obj: Any, loop: Any, uv_layer: Any) -> Dict[str, Any]:
    u, v = _uv_xy(loop, uv_layer)
    return {
        "obj": obj,
        "mesh": getattr(obj, "data", None),
        "loop": loop,
        "uv_layer": uv_layer,
        "u": u,
        "v": v,
        "source": True,
        "record_id": _loop_record_key(obj, loop),
        "endpoint_key": _endpoint_key(obj, loop, uv_layer),
    }


def _unique_records(records: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    seen: Set[Tuple[int, int, int]] = set()
    for rec in list(records or []):
        try:
            loop = rec.get("loop")
            obj = rec.get("obj")
            if loop is None or obj is None or _hidden(loop) or _hidden(getattr(loop, "face", None)):
                continue
            key = _loop_record_key(obj, loop)
            if key in seen:
                continue
            seen.add(key)
            out.append(rec)
        except Exception:
            pass
    return out


def _collect_uv_editor_selection(obj: Any, bm: Any, uv_layer: Any, mode: str) -> Tuple[List[Dict[str, Any]], Set[Any], Set[Any]]:
    records: List[Dict[str, Any]] = []
    edge_loops: Set[Any] = set()
    faces: Set[Any] = set()
    seen: Set[Tuple[int, int, int]] = set()

    def add(loop: Any) -> None:
        try:
            if loop is None or _hidden(loop) or _hidden(getattr(loop, "face", None)):
                return
            key = _loop_record_key(obj, loop)
            if key in seen:
                return
            seen.add(key)
            records.append(_make_record(obj, loop, uv_layer))
        except Exception:
            pass

    try:
        face_list = [f for f in bm.faces if not _hidden(f)]
    except Exception:
        face_list = []
    mode = _s(mode).upper()

    if mode == "EDGE":
        for face in face_list:
            try:
                loops = list(face.loops)
            except Exception:
                loops = []
            for loop in loops:
                if _live_e(loop, uv_layer):
                    edge_loops.add(loop)
                    add(loop)
                    try:
                        add(loop.link_loop_next)
                    except Exception:
                        pass
        return _unique_records(records), edge_loops, faces

    if mode == "FACE":
        for face in face_list:
            try:
                loops = list(face.loops)
            except Exception:
                loops = []
            if not loops:
                continue
            selected = all(_live_v(loop, uv_layer) for loop in loops) or all(_live_e(loop, uv_layer) for loop in loops)
            if selected:
                faces.add(face)
                for loop in loops:
                    add(loop)
                    edge_loops.add(loop)
        return _unique_records(records), edge_loops, faces

    for face in face_list:
        try:
            loops = list(face.loops)
        except Exception:
            loops = []
        for loop in loops:
            if _live_v(loop, uv_layer):
                add(loop)
    return _unique_records(records), edge_loops, faces


def _records_by_key(records: Sequence[Dict[str, Any]]) -> Dict[Tuple[int, int, int], Dict[str, Any]]:
    out: Dict[Tuple[int, int, int], Dict[str, Any]] = {}
    for rec in _unique_records(records):
        try:
            out[_loop_record_key(rec["obj"], rec["loop"])] = rec
        except Exception:
            pass
    return out


def _find(parent: List[int], i: int) -> int:
    while parent[i] != i:
        parent[i] = parent[parent[i]]
        i = parent[i]
    return i


def _union(parent: List[int], a: int, b: int) -> None:
    if a < 0 or b < 0 or a >= len(parent) or b >= len(parent):
        return
    ra, rb = _find(parent, a), _find(parent, b)
    if ra != rb:
        parent[rb] = ra


def _strict_edge_groups(obj: Any, uv_layer: Any, records: List[Dict[str, Any]], edge_loops: Set[Any]) -> List[List[Dict[str, Any]]]:
    rec_by_key = _records_by_key(records)
    units: List[Dict[str, Any]] = []
    unit_pos: Dict[Any, int] = {}
    for loop in list(edge_loops or set()):
        try:
            if loop is None or not _live_e(loop, uv_layer):
                continue
            vkey = _visual_edge_key(obj, loop, uv_layer)
            idx = unit_pos.get(vkey)
            if idx is None:
                idx = len(units)
                unit_pos[vkey] = idx
                units.append({"key": vkey, "endpoints": list(vkey), "records": []})
            unit = units[idx]
            for endpoint_loop in (loop, loop.link_loop_next):
                rec = rec_by_key.get(_loop_record_key(obj, endpoint_loop))
                if rec is not None and rec not in unit["records"]:
                    unit["records"].append(rec)
        except Exception:
            pass
    if not units:
        return []
    parent = list(range(len(units)))
    by_endpoint: Dict[Any, List[int]] = defaultdict(list)
    for i, unit in enumerate(units):
        for endpoint in unit.get("endpoints") or []:
            by_endpoint[endpoint].append(i)
    for idxs in by_endpoint.values():
        if len(idxs) <= 1:
            continue
        base = idxs[0]
        for idx in idxs[1:]:
            _union(parent, base, idx)
    groups_by_root: Dict[int, List[Dict[str, Any]]] = defaultdict(list)
    order: List[int] = []
    seen_by_root: Dict[int, Set[Tuple[int, int, int]]] = defaultdict(set)
    for i, unit in enumerate(units):
        root = _find(parent, i)
        if root not in groups_by_root:
            order.append(root)
        for rec in unit.get("records") or []:
            key = _loop_record_key(rec["obj"], rec["loop"])
            if key in seen_by_root[root]:
                continue
            seen_by_root[root].add(key)
            groups_by_root[root].append(rec)
    return [groups_by_root[root] for root in order if groups_by_root.get(root)]


def _strict_vertex_groups(obj: Any, bm: Any, uv_layer: Any, records: List[Dict[str, Any]]) -> List[List[Dict[str, Any]]]:
    records = _unique_records(records)
    if not records:
        return []
    parent = list(range(len(records)))
    index: Dict[Tuple[int, int, int], int] = {_loop_record_key(rec["obj"], rec["loop"]): i for i, rec in enumerate(records)}
    by_endpoint: Dict[Any, List[int]] = defaultdict(list)
    for i, rec in enumerate(records):
        by_endpoint[_endpoint_key(obj, rec["loop"], uv_layer)].append(i)
    for idxs in by_endpoint.values():
        base = idxs[0]
        for idx in idxs[1:]:
            _union(parent, base, idx)
    try:
        for face in bm.faces:
            if _hidden(face):
                continue
            for loop in face.loops:
                a = index.get(_loop_record_key(obj, loop))
                try:
                    nloop = loop.link_loop_next
                    b = index.get(_loop_record_key(obj, nloop))
                except Exception:
                    b = None
                if a is not None and b is not None:
                    _union(parent, a, b)
    except Exception:
        pass
    groups: Dict[int, List[Dict[str, Any]]] = defaultdict(list)
    order: List[int] = []
    for i, rec in enumerate(records):
        root = _find(parent, i)
        if root not in groups:
            order.append(root)
        groups[root].append(rec)
    return [groups[root] for root in order if groups.get(root)]


def _strict_face_groups(obj: Any, uv_layer: Any, records: List[Dict[str, Any]], faces: Set[Any]) -> List[List[Dict[str, Any]]]:
    face_list = list(faces or [])
    if not face_list:
        face_list = list({rec["loop"].face for rec in records if rec.get("loop") is not None})
    if not face_list:
        return []
    fpos = {f: i for i, f in enumerate(face_list)}
    parent = list(range(len(face_list)))
    by_edge: Dict[Any, List[Any]] = defaultdict(list)
    for face in face_list:
        try:
            for loop in face.loops:
                by_edge[_visual_edge_key(obj, loop, uv_layer)].append(face)
        except Exception:
            pass
    for fs in by_edge.values():
        valid = [f for f in fs if f in fpos]
        if len(valid) <= 1:
            continue
        base = fpos[valid[0]]
        for f in valid[1:]:
            _union(parent, base, fpos[f])
    rec_by_face: Dict[Any, List[Dict[str, Any]]] = defaultdict(list)
    for rec in _unique_records(records):
        try:
            rec_by_face[rec["loop"].face].append(rec)
        except Exception:
            pass
    groups: Dict[int, List[Dict[str, Any]]] = defaultdict(list)
    order: List[int] = []
    for face in face_list:
        root = _find(parent, fpos[face])
        if root not in groups:
            order.append(root)
        groups[root].extend(rec_by_face.get(face) or [])
    return [_unique_records(groups[root]) for root in order if groups.get(root)]


def _strict_uv_groups(obj: Any, bm: Any, uv_layer: Any, mode: str, records: List[Dict[str, Any]], edge_loops: Set[Any], faces: Set[Any]) -> List[List[Dict[str, Any]]]:
    mode = _s(mode).upper()
    if mode == "EDGE":
        return _strict_edge_groups(obj, uv_layer, records, edge_loops)
    if mode == "FACE":
        return _strict_face_groups(obj, uv_layer, records, faces)
    return _strict_vertex_groups(obj, bm, uv_layer, records)


def _all_active_coords(targets: Sequence[Tuple[Any, Any, Any]]) -> Dict[Tuple[int, int, int], Tuple[float, float]]:
    before: Dict[Tuple[int, int, int], Tuple[float, float]] = {}
    for obj, bm, uv_layer in list(targets or []):
        try:
            for face in bm.faces:
                if _hidden(face):
                    continue
                for loop in face.loops:
                    before[_loop_record_key(obj, loop)] = _uv_xy(loop, uv_layer)
        except Exception:
            pass
    return before


def _restore_unselected(targets: Sequence[Tuple[Any, Any, Any]], before: Dict[Tuple[int, int, int], Tuple[float, float]], selected: Set[Tuple[int, int, int]]) -> None:
    for obj, bm, uv_layer in list(targets or []):
        try:
            for face in bm.faces:
                if _hidden(face):
                    continue
                for loop in face.loops:
                    key = _loop_record_key(obj, loop)
                    if key in selected:
                        continue
                    old = before.get(key)
                    if old is None:
                        continue
                    uv = loop[uv_layer].uv
                    uv.x = float(old[0])
                    uv.y = float(old[1])
        except Exception:
            pass


def _selected_keys(groups: Sequence[Sequence[Dict[str, Any]]]) -> Set[Tuple[int, int, int]]:
    out: Set[Tuple[int, int, int]] = set()
    for group in list(groups or []):
        for rec in list(group or []):
            try:
                out.add(_loop_record_key(rec["obj"], rec["loop"]))
            except Exception:
                pass
    return out


def _record_value(rec: Dict[str, Any], axis_u: bool) -> float:
    try:
        uv = rec["loop"][rec["uv_layer"]].uv
        return float(uv.x if axis_u else uv.y)
    except Exception:
        return float(rec.get("u" if axis_u else "v", 0.0) or 0.0)


def _group_center(records: Sequence[Dict[str, Any]], axis_u: bool) -> Optional[float]:
    vals = [_record_value(rec, axis_u) for rec in _unique_records(records)]
    if not vals:
        return None
    return (min(vals) + max(vals)) * 0.5


def _shift_group(records: Sequence[Dict[str, Any]], axis_u: bool, delta: float) -> int:
    changed = 0
    if abs(float(delta)) <= _EPS:
        return 0
    for rec in _unique_records(records):
        try:
            uv = rec["loop"][rec["uv_layer"]].uv
            if axis_u:
                uv.x = float(uv.x) + float(delta)
                rec["u"] = float(uv.x)
            else:
                uv.y = float(uv.y) + float(delta)
                rec["v"] = float(uv.y)
            changed += 1
        except Exception:
            pass
    return changed


def _points_from_records(records: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    buckets: Dict[Any, List[Dict[str, Any]]] = defaultdict(list)
    order: List[Any] = []
    for rec in _unique_records(records):
        key = rec.get("endpoint_key")
        if key is None:
            key = _loop_record_key(rec["obj"], rec["loop"])
        if key not in buckets:
            order.append(key)
        buckets[key].append(rec)
    points: List[Dict[str, Any]] = []
    for key in order:
        recs = buckets.get(key) or []
        if not recs:
            continue
        us = [_record_value(r, True) for r in recs]
        vs = [_record_value(r, False) for r in recs]
        points.append({"key": key, "records": recs, "u": sum(us) / len(us), "v": sum(vs) / len(vs)})
    return points


def _write_point(point: Dict[str, Any], u: Optional[float] = None, v: Optional[float] = None) -> int:
    changed = 0
    for rec in _unique_records(point.get("records") or []):
        try:
            uv = rec["loop"][rec["uv_layer"]].uv
            if u is not None:
                uv.x = float(u)
                rec["u"] = float(u)
            if v is not None:
                uv.y = float(v)
                rec["v"] = float(v)
            changed += 1
        except Exception:
            pass
    return changed


def _apply_group_axis(records: Sequence[Dict[str, Any]], action: str) -> int:
    points = _points_from_records(records)
    if not points:
        return 0
    us = [float(p.get("u", 0.0)) for p in points]
    vs = [float(p.get("v", 0.0)) for p in points]
    action = _s(action).upper()
    changed = 0
    if action == "ALIGN_H":
        v = (min(vs) + max(vs)) * 0.5
        for p in points:
            changed += _write_point(p, v=v)
    elif action == "ALIGN_V":
        u = (min(us) + max(us)) * 0.5
        for p in points:
            changed += _write_point(p, u=u)
    return changed


def _execute_grouped_vertex_align_18109(self: Any, context: Any):
    raw = _s(getattr(self, "action", "ALIGN_CENTER")).upper() or "ALIGN_CENTER"
    if raw not in _GROUP_ACTIONS:
        prev = _PREV.get("vertex_execute")
        if callable(prev) and prev is not _execute_grouped_vertex_align_18109:
            return prev(self, context)
        return {"CANCELLED"}

    snap = ri._snapshot_modes(context)
    objs, state = mo._ensure_multi_edit(context)
    if not objs:
        _report(self, "WARNING", _tr(context, "No mesh object is active.", "アクティブなメッシュオブジェクトがありません。"))
        return {"CANCELLED"}
    try:
        mo._prepare_unwrap_channel(context)
        targets = mo._target_data(context)
        if not targets:
            _report(self, "WARNING", _tr(context, "No editable UV map is available.", "編集可能なUVマップがありません。"))
            return {"CANCELLED"}
        mode = ri._uv_mode(context)
        all_groups: List[List[Dict[str, Any]]] = []
        for obj, bm, uv_layer in targets:
            records, edge_loops, faces = _collect_uv_editor_selection(obj, bm, uv_layer, mode)
            if not records:
                continue
            groups = _strict_uv_groups(obj, bm, uv_layer, mode, records, edge_loops, faces)
            for group in groups:
                clean = _unique_records(group)
                if clean:
                    all_groups.append(clean)
        if not all_groups:
            _report(self, "WARNING", _tr(context, "No UV editor element group is selected.", "UVエディターで選択されたエレメントグループがありません。"))
            return {"CANCELLED"}

        before = _all_active_coords(targets)
        selected = _selected_keys(all_groups)
        changed = 0
        if raw in _DISTRIBUTE_GROUP_ACTIONS:
            axis_u = raw == "DISTRIBUTE_H_GROUP"
            prepared: List[Dict[str, Any]] = []
            for group in all_groups:
                center = _group_center(group, axis_u)
                if center is not None:
                    prepared.append({"records": group, "center": float(center)})
            if len(prepared) > 1:
                ordered = sorted(prepared, key=lambda item: float(item.get("center", 0.0)))
                start = float(ordered[0]["center"])
                end = float(ordered[-1]["center"])
                if abs(end - start) > _EPS:
                    step = (end - start) / float(max(1, len(ordered) - 1))
                    for i, item in enumerate(ordered):
                        target_value = start + step * i
                        changed += _shift_group(item.get("records") or [], axis_u, target_value - float(item.get("center", 0.0)))
        else:
            action = "ALIGN_H" if raw == "ALIGN_H_GROUP" else "ALIGN_V"
            for group in all_groups:
                changed += _apply_group_axis(group, action)

        _restore_unselected(targets, before, selected)
        mo._update_meshes(targets)
        try:
            area = getattr(context, "area", None)
            if area is not None:
                area.tag_redraw()
        except Exception:
            pass
        return {"FINISHED"}
    except Exception as exc:
        _report(self, "WARNING", _tr(context, "Grouped vertex alignment failed.", "グループ整列に失敗しました。") + f" {exc}")
        return {"CANCELLED"}
    finally:
        ri._restore_modes(snap)
        mo._restore_multi_edit(context, state)
        ri._restore_modes(snap)


def _patch_selection(ns: Dict[str, Any]) -> None:
    try:
        sc._loop_next_visual_edge = _single_wire_continuation  # type: ignore[attr-defined]
        sc._visual_loop_keys = _visual_loop_keys_18109  # type: ignore[attr-defined]
        sc.strict_selection_loop_ring = _selection_loop_ring_18109  # type: ignore[attr-defined]
        ri._selection_loop_ring = lambda context, obj, bm, uv_layer, action, loops, edge_loops: _selection_loop_ring_18109(context, obj, bm, uv_layer, action, set(edge_loops or set()))  # type: ignore[attr-defined]
    except Exception:
        pass
    cls = ns.get("SMARTUVSUITE_OT_uv_element_select_action") if isinstance(ns, dict) else None
    if isinstance(cls, type):
        cur = getattr(cls, "execute", None)
        if callable(cur) and cur is not _execute_select_multi_18109:
            _PREV["select_execute"] = cur
        try:
            _execute_select_multi_18109._sus_18109_uv_wire_loop = True  # type: ignore[attr-defined]
        except Exception:
            pass
        cls.execute = _execute_select_multi_18109


def _patch_vertex(ns: Dict[str, Any]) -> None:
    cls = ns.get("SMARTUVSUITE_OT_vertex_align_action") if isinstance(ns, dict) else None
    if not isinstance(cls, type):
        return
    cur = getattr(cls, "execute", None)
    if callable(cur) and cur is not _execute_grouped_vertex_align_18109:
        _PREV["vertex_execute"] = cur
    try:
        _execute_grouped_vertex_align_18109._sus_18109_group_uv_only = True  # type: ignore[attr-defined]
        _execute_grouped_vertex_align_18109._sus_18107_group_selected_only = True  # type: ignore[attr-defined]
        _execute_grouped_vertex_align_18109._sus_18104_multi = True  # type: ignore[attr-defined]
    except Exception:
        pass
    cls.execute = _execute_grouped_vertex_align_18109


def _mark_version(ns: Dict[str, Any]) -> None:
    try:
        info = ns.get("bl_info")
        if not isinstance(info, dict):
            info = {}
            ns["bl_info"] = info
        info.update({
            "name": "Smart UV Suite",
            "author": "JELararagi",
            "version": (1, 0, 0),
            "blender": (5, 1, 0),
            "location": "View3D / UV Editor > Sidebar > Smart UV",
            "description": "Smart UV Suite exposes UV editing tools in the Smart UV sidebar.",
            "category": "Smart UV",
        })
        ns["_SUS_BL_INFO_FALLBACK"] = dict(info)
        ns["__version__"] = '1.0.0'
    except Exception:
        pass


def _wrap_sync(ns: Dict[str, Any]) -> None:
    base = ns.get("_sus_1652_sync_keymaps_from_workspace") if isinstance(ns, dict) else None
    if callable(base) and not getattr(base, "_sus_18109_sync", False):
        _PREV["sync"] = base
    base_sync = _PREV.get("sync")

    def _sync_18109(context=None):
        ctx = context or getattr(bpy, "context", None)
        if callable(base_sync) and base_sync is not _sync_18109:
            try:
                base_sync(ctx)
            except TypeError:
                try:
                    base_sync()
                except Exception:
                    pass
            except Exception:
                pass
        try:
            apply_all(ns, ctx)
        except Exception:
            pass

    try:
        _sync_18109._sus_18109_sync = True  # type: ignore[attr-defined]
    except Exception:
        pass
    ns["_sus_1652_sync_keymaps_from_workspace"] = _sync_18109


def apply_all(ns: Optional[Dict[str, Any]] = None, context: Any = None) -> None:
    global _NS
    if isinstance(ns, dict):
        _NS = ns
    elif not _NS:
        import sys
        mod = sys.modules.get(__package__)
        if mod is not None:
            _NS = getattr(mod, "__dict__", {})
    target = _NS if isinstance(_NS, dict) else {}
    if not target:
        return
    _patch_selection(target)
    _patch_vertex(target)
    _wrap_sync(target)
    _mark_version(target)


def install(ns: Optional[Dict[str, Any]] = None, context: Any = None) -> None:
    apply_all(ns, context or getattr(bpy, "context", None))


def unregister() -> None:
    return None


def audit(context: Any = None) -> Dict[str, Any]:
    cls_s = _NS.get("SMARTUVSUITE_OT_uv_element_select_action") if isinstance(_NS, dict) else None
    cls_v = _NS.get("SMARTUVSUITE_OT_vertex_align_action") if isinstance(_NS, dict) else None
    return {
        "version": _VERSION,
        "uv_wire_loop_execute": bool(getattr(getattr(cls_s, "execute", None), "_sus_18109_uv_wire_loop", False)) if isinstance(cls_s, type) else False,
        "grouped_vertex_align_uv_editor_only": bool(getattr(getattr(cls_v, "execute", None), "_sus_18109_group_uv_only", False)) if isinstance(cls_v, type) else False,
        "angle_heuristic_used_for_loop": False,
        "moves_unselected_uv_elements": False,
    }
