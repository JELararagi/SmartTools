"""Implement the inspect clip public UV operations."""


def inspect_clip_uv(context, op, api):
    lower = op.value if op.properties.is_property_set('value') else 0.0
    upper = op.amount if op.properties.is_property_set('amount') else 1.0
    if upper <= lower:
        return False
    rows = api._edit_targets(context)
    sync = api._sync(context)
    changed = False
    for _, bm, uv in rows:
        for face in bm.faces:
            if not api._visible(face, sync):
                continue
            for loop in face.loops:
                selected = loop.vert.select if sync else loop.uv_select_vert
                if not selected or loop[uv].pin_uv:
                    continue
                point = loop[uv].uv
                bounded = tuple(min(upper, max(lower, coordinate)) for coordinate in point)
                if tuple(point) != bounded:
                    loop[uv].uv = bounded
                    changed = True
    if changed:
        api._flush(rows)
    return changed



def build_handlers(api):
    return {

        "smart_uv_suite.inspect_clip_uv": api.Handler(lambda context, op: inspect_clip_uv(context, op, api), 'Clip selected UV coordinates to the requested range.', '選択したUV座標を指定範囲内に収めます。'),

    }
