"""Division storage and operations for the Smart UV public pack tools."""

import colorsys
import json
import math
import random


_KEY = 'SUV_PACK_DIVISIONS'
_COLOR = [.35, .65, .9, 1.0]
_DIRECTIONS = {'RIGHT': (1, 0), 'LEFT': (-1, 0), 'UP': (0, 1), 'DOWN': (0, -1)}


def _load(scene):
    raw = scene.get(_KEY)
    return json.loads(raw) if raw is not None else {'active': -1, 'divisions': []}


def _store(context, state):
    context.scene[_KEY] = json.dumps(state, allow_nan=False)
    for area in getattr(context.screen, 'areas', ()):
        if area.type == 'IMAGE_EDITOR':
            area.tag_redraw()
    return True


def _index(state, op):
    index = op.index if op.properties.is_property_set('index') else state['active']
    return index if 0 <= index < len(state['divisions']) else None


def _bounds(points):
    u, v = zip(*points)
    return [min(u), min(v), max(u), max(v)]


def _valid(bounds):
    u0, v0, u1, v1 = bounds
    return all(math.isfinite(x) for x in bounds) and u1 > u0 and v1 > v0


def _record(name, bounds):
    return {'name': name, 'bounds': bounds, 'color': _COLOR.copy()}


def _center(bounds):
    u0, v0, u1, v1 = bounds
    return (u0 + u1) * .5, (v0 + v1) * .5


def _remove(context, state, index):
    divisions = state['divisions']
    del divisions[index]
    active = state['active']
    if index < active:
        active -= 1
    state['active'] = min(active, len(divisions) - 1)
    return _store(context, state)


def build_handlers(api):
    def targets(context):
        return api._edit_targets(context) if context.mode == 'EDIT_MESH' else []

    def no_division(context, op):
        api._warn(context, op, 'Choose an existing division.', '既存の区画を選択してください。')
        return False

    def selected_points(context, rows):
        sync = api._sync(context)
        return [tuple(loop[uv].uv) for _, bm, uv in rows for face in bm.faces
                if api._visible(face, sync) for loop in face.loops
                if (loop.vert.select if sync else loop.uv_select_vert or face.uv_select)]

    def add(context, op):
        points = selected_points(context, targets(context))
        if not points or not _valid(bounds := _bounds(points)):
            api._warn(context, op, 'Select UVs spanning a rectangle.', '区画の範囲となる UV を選択してください。')
            return False
        state = _load(context.scene)
        divisions = state['divisions']
        divisions.append(_record(op.name.strip() or f'Division {len(divisions) + 1}', bounds))
        state['active'] = len(divisions) - 1
        return _store(context, state)

    def center(context, op):
        state = _load(context.scene)
        index = _index(state, op)
        if index is None:
            return no_division(context, op)
        rows = targets(context)
        islands = api._seed_islands(context, rows)
        if not islands:
            return api._pick_seed_first(context, op)
        destination = _center(state['divisions'][index]['bounds'])
        origin = _center(_bounds([(u, v) for _, _, _, island in islands
                                 for u, v in (island.box[:2], island.box[2:])]))
        du, dv = (end - start for end, start in zip(destination, origin))
        for _, _, uv, island in islands:
            api._move_island(island.faces, uv, du, dv)
        api._flush(rows)
        return True

    def clear(context, op):
        state = _load(context.scene)
        if not state['divisions']:
            return no_division(context, op)
        state.update(active=-1, divisions=[])
        return _store(context, state)

    def from_plane(context, op):
        # Read the selected faces of the active plane's UV map. Preserve the
        # plane's UV positions, including an intentional offset into a UDIM.
        active = context.active_object
        rows = [row for row in targets(context) if row[0].data == active.data]
        rectangles = []
        sync = api._sync(context)
        for _, bm, uv in rows:
            faces = [face for face in bm.faces if api._face_selected(face, sync)]
            if not faces:
                continue
            normal = faces[0].normal
            origin = faces[0].verts[0].co
            vertices = {vert for face in faces for vert in face.verts}
            extent = max((vert.co - origin).length for vert in vertices)
            if not normal.length or any(abs(normal.dot(vert.co - origin)) > 1e-6 * extent for vert in vertices):
                break
            rectangles = [_bounds([tuple(loop[uv].uv) for loop in face.loops]) for face in faces]
        if not rectangles or not all(map(_valid, rectangles)):
            api._warn(context, op, 'Select coplanar faces with valid UV bounds.', '有効な UV 範囲を持つ同一平面上の面を選択してください。')
            return False
        name = op.name.strip() or 'Division'
        divisions = [_record(name if i == 1 and op.name.strip() else f'{name} {i}', bounds)
                     for i, bounds in enumerate(rectangles, 1)]
        state = _load(context.scene)
        state.update(active=0, divisions=divisions)
        return _store(context, state)

    def move(context, op):
        state = _load(context.scene)
        index = _index(state, op)
        if index is None:
            return no_division(context, op)
        direction = _DIRECTIONS.get((op.direction or 'RIGHT').upper())
        if direction is None or not op.amount:
            api._warn(context, op, 'Set a direction and a positive UV offset.', '移動方向と正の UV オフセットを指定してください。')
            return False
        du, dv = (value * op.amount for value in direction)
        item = state['divisions'][index]
        u0, v0, u1, v1 = item['bounds']
        item['bounds'] = [u0 + du, v0 + dv, u1 + du, v1 + dv]
        return _store(context, state)

    def randomize(context, op):
        state = _load(context.scene)
        if not state['divisions']:
            return no_division(context, op)
        for item in state['divisions']:
            rgb = colorsys.hsv_to_rgb(random.random(), .65, .9)
            item['color'] = [*rgb, item['color'][3]]
        return _store(context, state)

    def remove_active(context, op):
        state = _load(context.scene)
        index = _index(state, op)
        return _remove(context, state, index) if index is not None else no_division(context, op)

    def remove_single(context, op):
        state = _load(context.scene)
        if not 0 <= op.index < len(state['divisions']):
            return no_division(context, op)
        return _remove(context, state, op.index)

    def select(context, op):
        state = _load(context.scene)
        index = _index(state, op)
        if index is None:
            return no_division(context, op)
        u0, v0, u1, v1 = state['divisions'][index]['bounds']
        sync = api._sync(context)
        changed = []
        for obj, bm, uv in targets(context):
            faces = [face for face in bm.faces if api._visible(face, sync)
                     and not api._face_selected(face, sync)
                     and all(u0 - 1e-6 <= loop[uv].uv.x <= u1 + 1e-6
                             and v0 - 1e-6 <= loop[uv].uv.y <= v1 + 1e-6 for loop in face.loops)]
            if faces:
                api._select_faces(context, bm, faces, extend=True)
                changed.append((obj, bm, uv))
        if not changed:
            api._warn(context, op, 'The division contains no additional visible faces.', '区画内に追加選択できる表示面がありません。')
            return False
        api._flush(changed)
        return True

    return {
        'smart_uv_suite.pack_add_division': api.Handler(add, 'Save the selected UV bounds as a new division.', '選択した UV の範囲を新しい区画として保存します。'),
        'smart_uv_suite.pack_center_in_division': api.Handler(center, 'Translate the selected UV islands together to the center of the active division.', '選択した UV アイランドをまとめてアクティブ区画の中央へ移動します。'),
        'smart_uv_suite.pack_clear_divisions': api.Handler(clear, 'Clear the saved divisions in this scene.', 'このシーンに保存された区画をすべて削除します。'),
        'smart_uv_suite.pack_get_divisions_from_plane': api.Handler(from_plane, 'Replace divisions with the UV bounds of the selected faces on the active plane.', 'アクティブな平面の選択面の UV 範囲で区画を置き換えます。'),
        'smart_uv_suite.pack_move_selected_division': api.Handler(move, 'Offset the active division in the specified direction by the UV distance.', 'アクティブ区画を指定した方向へ UV 距離の分だけ移動します。'),
        'smart_uv_suite.pack_randomize_division_colors': api.Handler(randomize, 'Randomize each division color while preserving its opacity.', '透明度を保ちながら各区画の色をランダムに変更します。'),
        'smart_uv_suite.pack_remove_division': api.Handler(remove_active, 'Remove the active division.', 'アクティブな区画を削除します。'),
        'smart_uv_suite.pack_remove_division_single': api.Handler(remove_single, 'Remove only the division at the specified list index.', '指定したリスト位置の区画だけを削除します。'),
        'smart_uv_suite.select_division': api.Handler(select, 'Add visible UV faces contained in the active division to the selection.', 'アクティブ区画に収まる表示 UV 面を選択に追加します。'),
    }
