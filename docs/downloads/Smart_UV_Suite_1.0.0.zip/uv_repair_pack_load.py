"""Load a color ID map into the current UV Editor."""

import bpy


def run(context, op):
    space = context.space_data
    if space is None or space.type != "IMAGE_EDITOR":
        op.report({"WARNING"}, "Run Load ID Map from the UV Editor.")
        return False
    if not op.filepath:
        op.report({"WARNING"}, "Choose an ID map image.")
        return False
    space.image = bpy.data.images.load(bpy.path.abspath(op.filepath), check_existing=True)
    return True


def invoke(context, op, event):
    if op.filepath:
        return op.execute(context)
    op.filter_glob = "*.png;*.jpg;*.jpeg;*.tga;*.tif;*.tiff;*.exr;*.bmp;*.webp"
    context.window_manager.fileselect_add(op)
    return {"RUNNING_MODAL"}


def build_handlers(api):
    return {"smart_uv_suite.pack_load_id_map": api.Handler(
        run, "Load a color ID map into the UV Editor.", "カラーIDマップをUVエディターに読み込みます。", invoke)}
