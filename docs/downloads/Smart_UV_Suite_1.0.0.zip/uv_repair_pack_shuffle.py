"""Shuffle island positions without resizing them."""

import random


def build_handlers(api):
    def run(context, op):
        rows = api._edit_targets(context)
        sync = api._sync(context)
        islands = [(uv, info) for _, _, uv, info in api._all_islands(context, rows)
                   if any(api._face_selected(face, sync) for face in info.faces)]
        if len(islands) < 2:
            api._warn(context, op, "Select at least two islands.", "アイランドを2つ以上選択してください。")
            return False
        centers = [(0.5 * (info.box[0] + info.box[2]), 0.5 * (info.box[1] + info.box[3]))
                   for _, info in islands]
        order = list(range(len(islands)))
        random.Random(op.index if op.properties.is_property_set("index") else None).shuffle(order)
        targets = dict(zip(order, order[1:] + order[:1]))
        for index, (uv, info) in enumerate(islands):
            u, v = centers[index]
            target_u, target_v = centers[targets[index]]
            api._move_island(info.faces, uv, target_u - u, target_v - v)
        api._flush(rows)
        return True

    return {"smart_uv_suite.pack_shuffle_island": api.Handler(
        run, "Shuffle the centers of selected islands.", "選択アイランドの中心位置を入れ替えます。")}
