# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Smart UV Suite 1.8.101 stable UV selection and immediate-select recovery.

This layer replaces the older stacked UV basic-selection implementation with a
single live-BMesh backend.  The older stack mixed hidden UV-selection
attributes, mesh selection fallback and mode changes; after several compatibility
patches it could interpret stale full-mesh selection as the current UV selection,
so Grow/Shrink/Border/etc. appeared to become Select All.

The backend below reads the current live UV selection first, writes only the
intended UV domain, and restores UV Sync / UV select mode / mesh select mode /
Sticky Selection mode after every basic-selection action.  It also relaxes the
1.8.100 Immediate Select wrapper so the base operator can perform the actual hit
selection on selection tools without installing any Generic Gizmo interceptors.
"""
from __future__ import annotations

from collections import defaultdict, deque
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

import bpy

_VERSION = (1, 8, 101)
_NS: Optional[Dict[str, Any]] = None
_ORIGINAL_SELECT_EXECUTE = None
_ORIGINAL_INSTANT_INVOKE = None
_INSTALLED = False


def _txt(value: Any) -> str:
    try:
        return str(value or "")
    except Exception:
        return ""


def _norm_result(value: Any) -> set:
    try:
        return set(value or set())
    except Exception:
        return set()


def _mesh_obj(context: Any):
    try:
        obj = getattr(context, "edit_object", None)
        if obj is not None and getattr(obj, "type", None) == "MESH":
            return obj
    except Exception:
        pass
    try:
        obj = getattr(context, "active_object", None)
        if obj is not None and getattr(obj, "type", None) == "MESH":
            return obj
    except Exception:
        pass
    return None


def _tool_settings(context: Any):
    try:
        ts = getattr(context, "tool_settings", None)
        if ts is not None:
            return ts
    except Exception:
        pass
    try:
        return getattr(getattr(context, "scene", None), "tool_settings", None)
    except Exception:
        return None


def _snapshot_modes(context: Any) -> dict:
    ts = _tool_settings(context)
    snap = {"ts": ts, "sync": None, "uv_mode": None, "mesh_mode": None, "sticky": None}
    if ts is None:
        return snap
    for key, attr in (("sync", "use_uv_select_sync"), ("uv_mode", "uv_select_mode"), ("sticky", "uv_sticky_select_mode")):
        try:
            snap[key] = getattr(ts, attr)
        except Exception:
            pass
    try:
        snap["mesh_mode"] = tuple(bool(x) for x in getattr(ts, "mesh_select_mode", (False, False, False)))
    except Exception:
        pass
    return snap


def _restore_modes(snap: dict) -> None:
    ts = snap.get("ts") if isinstance(snap, dict) else None
    if ts is None:
        return
    for key, attr in (("sync", "use_uv_select_sync"), ("uv_mode", "uv_select_mode"), ("sticky", "uv_sticky_select_mode")):
        val = snap.get(key)
        if val is None:
            continue
        try:
            if getattr(ts, attr) != val:
                setattr(ts, attr, val)
        except Exception:
            pass
    mode = snap.get("mesh_mode")
    if mode is not None:
        try:
            current = tuple(bool(x) for x in getattr(ts, "mesh_select_mode", (False, False, False)))
            if tuple(mode) != current:
                ts.mesh_select_mode = mode
        except Exception:
            pass


def _uv_mode(context: Any) -> str:
    ts = _tool_settings(context)
    mode = "VERTEX"
    try:
        mode = getattr(ts, "uv_select_mode", "VERTEX")
        if isinstance(mode, (set, list, tuple)):
            mode = " ".join(str(m) for m in mode)
        mode = str(mode or "VERTEX").upper()
    except Exception:
        mode = "VERTEX"
    if "ISLAND" in mode:
        return "FACE"
    if "FACE" in mode:
        return "FACE"
    if "EDGE" in mode:
        return "EDGE"
    return "VERTEX"


def _ensure_lookup(bm: Any) -> None:
    try:
        bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
        bm.verts.index_update(); bm.edges.index_update(); bm.faces.index_update()
    except Exception:
        pass


def _loop_index(loop: Any) -> int:
    try:
        return int(getattr(loop, "index", -1))
    except Exception:
        return -1


def _face_index(face: Any) -> int:
    try:
        return int(getattr(face, "index", -1))
    except Exception:
        return -1


def _get_live_v(loop: Any, uv_layer: Any = None) -> bool:
    try:
        return bool(getattr(loop, "uv_select_vert", False))
    except Exception:
        pass
    try:
        return bool(getattr(loop[uv_layer], "select", False)) if uv_layer is not None else False
    except Exception:
        return False


def _get_live_e(loop: Any, uv_layer: Any = None) -> bool:
    try:
        return bool(getattr(loop, "uv_select_edge", False))
    except Exception:
        pass
    try:
        return bool(getattr(loop[uv_layer], "select_edge", False)) if uv_layer is not None else False
    except Exception:
        return False


def _set_live_v(loop: Any, value: bool, uv_layer: Any = None) -> None:
    v = bool(value)
    try:
        setter = getattr(loop, "uv_select_vert_set", None)
        if callable(setter):
            setter(v); return
    except Exception:
        pass
    try:
        setattr(loop, "uv_select_vert", v); return
    except Exception:
        pass
    try:
        if uv_layer is not None:
            setattr(loop[uv_layer], "select", v)
    except Exception:
        pass


def _set_live_e(loop: Any, value: bool, uv_layer: Any = None) -> None:
    v = bool(value)
    try:
        setter = getattr(loop, "uv_select_edge_set", None)
        if callable(setter):
            setter(v); return
    except Exception:
        pass
    try:
        setattr(loop, "uv_select_edge", v); return
    except Exception:
        pass
    try:
        if uv_layer is not None:
            setattr(loop[uv_layer], "select_edge", v)
    except Exception:
        pass


def _edge_key(loop: Any) -> Tuple[int, int]:
    try:
        return (_face_index(loop.face), _loop_index(loop))
    except Exception:
        return (-1, -1)


def _loop_uv(loop: Any, uv_layer: Any) -> Tuple[float, float]:
    try:
        uv = loop[uv_layer].uv
        return (float(uv.x), float(uv.y))
    except Exception:
        return (0.0, 0.0)


def _same_uv_edge(a: Any, b: Any, uv_layer: Any, eps: float = 1.0e-6) -> bool:
    try:
        a0 = _loop_uv(a, uv_layer); a1 = _loop_uv(a.link_loop_next, uv_layer)
        b0 = _loop_uv(b, uv_layer); b1 = _loop_uv(b.link_loop_next, uv_layer)
        def close(p, q):
            return abs(p[0] - q[0]) <= eps and abs(p[1] - q[1]) <= eps
        return (close(a0, b0) and close(a1, b1)) if a.vert == b.vert else (close(a0, b1) and close(a1, b0))
    except Exception:
        return False


def _read_hidden_attrs(obj: Any) -> Tuple[List[bool], List[bool], List[bool]]:
    mesh = getattr(obj, "data", None)
    try:
        loop_len = len(getattr(mesh, "loops", []) or [])
        face_len = len(getattr(mesh, "polygons", []) or [])
    except Exception:
        loop_len = face_len = 0
    v = [False] * loop_len; e = [False] * loop_len; f = [False] * face_len
    try:
        attrs = getattr(mesh, "attributes", None)
        if attrs is None:
            return v, e, f
        for name, target in ((".uv_select_vert", v), (".uv_select_edge", e), (".uv_select_face", f)):
            attr = attrs.get(name)
            if attr is None:
                continue
            for i, item in enumerate(getattr(attr, "data", []) or []):
                if i >= len(target):
                    break
                try:
                    target[i] = bool(getattr(item, "value", False))
                except Exception:
                    pass
    except Exception:
        pass
    return v, e, f


def _has_live_selection(bm: Any, uv_layer: Any) -> bool:
    try:
        for face in bm.faces:
            if bool(getattr(face, "select", False)):
                # Face selection is live only when all its loops also show UV selection.
                if all(_get_live_v(loop, uv_layer) for loop in face.loops):
                    return True
            for loop in face.loops:
                if _get_live_v(loop, uv_layer) or _get_live_e(loop, uv_layer):
                    return True
    except Exception:
        pass
    return False



def _reject_full_flags(flags):
    try:
        if flags and all(bool(v) for v in flags):
            return [False] * len(flags)
    except Exception:
        pass
    return flags

def _selected_sets(context: Any, obj: Any, bm: Any, uv_layer: Any, mode: str):
    v_attr, e_attr, f_attr = _read_hidden_attrs(obj)
    live_any = _has_live_selection(bm, uv_layer)
    ts = _tool_settings(context)
    try:
        sync = bool(getattr(ts, "use_uv_select_sync", False))
    except Exception:
        sync = False
    try:
        if mode == "FACE":
            mesh_total = sum(1 for _f in bm.faces if not getattr(_f, "hide", False))
            mesh_sel = sum(1 for _f in bm.faces if (not getattr(_f, "hide", False)) and bool(getattr(_f, "select", False)))
        elif mode == "EDGE":
            mesh_total = sum(1 for _e in bm.edges if not getattr(_e, "hide", False))
            mesh_sel = sum(1 for _e in bm.edges if (not getattr(_e, "hide", False)) and bool(getattr(_e, "select", False)))
        else:
            mesh_total = sum(1 for _v in bm.verts if not getattr(_v, "hide", False))
            mesh_sel = sum(1 for _v in bm.verts if (not getattr(_v, "hide", False)) and bool(getattr(_v, "select", False)))
    except Exception:
        mesh_total = 0
        mesh_sel = 0
    allow_mesh_fallback = bool(sync and mesh_sel > 0 and (mesh_total <= 0 or mesh_sel < mesh_total))
    if sync and mesh_total > 0 and mesh_sel >= mesh_total:
        # Avoid treating Blender's default/full edit-mesh selection as a UV seed.
        live_any = False
        v_attr = _reject_full_flags(v_attr)
        e_attr = _reject_full_flags(e_attr)
        f_attr = _reject_full_flags(f_attr)
    attr_any = any(v_attr) or any(e_attr) or any(f_attr)

    loops: Set[Any] = set()
    edge_loops: Set[Any] = set()
    faces: Set[Any] = set()

    for face in bm.faces:
        fi = _face_index(face)
        face_attr = 0 <= fi < len(f_attr) and bool(f_attr[fi])
        face_live = bool(getattr(face, "select", False)) and all(_get_live_v(loop, uv_layer) for loop in face.loops)
        if mode == "FACE" and ((live_any and face_live) or (not live_any and face_attr) or (allow_mesh_fallback and bool(getattr(face, "select", False)) and not live_any and not attr_any)):
            faces.add(face)
            for loop in face.loops:
                loops.add(loop)
                edge_loops.add(loop)
            continue
        for loop in face.loops:
            li = _loop_index(loop)
            lv = _get_live_v(loop, uv_layer)
            le = _get_live_e(loop, uv_layer)
            av = (0 <= li < len(v_attr) and v_attr[li])
            ae = (0 <= li < len(e_attr) and e_attr[li])
            if live_any:
                vsel = lv
                esel = le
            elif attr_any:
                vsel = av
                esel = ae
            else:
                vsel = bool(getattr(loop.vert, "select", False)) if allow_mesh_fallback else False
                esel = bool(getattr(loop.edge, "select", False)) if allow_mesh_fallback else False
            if mode == "EDGE":
                if esel:
                    edge_loops.add(loop)
                    loops.add(loop); loops.add(loop.link_loop_next)
                elif vsel:
                    loops.add(loop)
            elif mode == "FACE":
                if vsel or esel:
                    loops.add(loop)
                    if esel:
                        edge_loops.add(loop)
            else:
                if vsel:
                    loops.add(loop)
                if esel:
                    edge_loops.add(loop)
                    loops.add(loop); loops.add(loop.link_loop_next)
    return loops, edge_loops, faces


def _clear_all(bm: Any, uv_layer: Any) -> None:
    try:
        for face in bm.faces:
            try: face.select_set(False)
            except Exception: pass
            for loop in face.loops:
                _set_live_v(loop, False, uv_layer)
                _set_live_e(loop, False, uv_layer)
        for edge in bm.edges:
            try: edge.select_set(False)
            except Exception: pass
        for vert in bm.verts:
            try: vert.select_set(False)
            except Exception: pass
    except Exception:
        pass


def _apply_selection(bm: Any, uv_layer: Any, mode: str, loops: Iterable[Any] = (), edge_loops: Iterable[Any] = (), faces: Iterable[Any] = ()) -> None:
    loop_set: Set[Any] = set(loops or [])
    edge_set: Set[Any] = set(edge_loops or [])
    face_set: Set[Any] = set(faces or [])
    if mode == "FACE":
        for face in face_set:
            try:
                for loop in face.loops:
                    loop_set.add(loop)
                    edge_set.add(loop)
            except Exception:
                pass
    elif mode == "EDGE":
        for loop in list(edge_set):
            try:
                loop_set.add(loop); loop_set.add(loop.link_loop_next)
            except Exception:
                pass
    _clear_all(bm, uv_layer)
    if mode == "FACE":
        for face in face_set:
            try: face.select_set(True)
            except Exception: pass
            for loop in face.loops:
                _set_live_v(loop, True, uv_layer)
                _set_live_e(loop, True, uv_layer)
                try: loop.vert.select_set(True)
                except Exception: pass
                try: loop.edge.select_set(True)
                except Exception: pass
    elif mode == "EDGE":
        for loop in edge_set:
            try:
                _set_live_e(loop, True, uv_layer)
                _set_live_v(loop, True, uv_layer)
                _set_live_v(loop.link_loop_next, True, uv_layer)
                loop.edge.select_set(True)
                loop.vert.select_set(True)
                loop.link_loop_next.vert.select_set(True)
            except Exception:
                pass
        for loop in loop_set:
            try:
                _set_live_v(loop, True, uv_layer)
                loop.vert.select_set(True)
            except Exception:
                pass
    else:
        for loop in loop_set:
            try:
                _set_live_v(loop, True, uv_layer)
                loop.vert.select_set(True)
            except Exception:
                pass
    # Keep mesh flags minimal and synchronized to the chosen UV domain.  This is
    # important for UV Sync ON and for standard transform/gizmo operators, but it
    # must not expand the selection back to the full mesh.
    try:
        for edge in bm.edges:
            if mode == "EDGE":
                edge.select_set(edge.select or False)
            else:
                edge.select_set(False if mode == "VERTEX" else bool(edge.select))
    except Exception:
        pass


def _all_loops_faces_edges(bm: Any):
    loops = set(); edge_loops = set(); faces = set()
    for face in bm.faces:
        faces.add(face)
        for loop in face.loops:
            loops.add(loop); edge_loops.add(loop)
    return loops, edge_loops, faces


def _grow(mode: str, bm: Any, uv_layer: Any, loops: Set[Any], edge_loops: Set[Any], faces: Set[Any]):
    if mode == "FACE":
        out = set(faces)
        if not out:
            out = {loop.face for loop in loops}
        for face in list(out):
            for edge in face.edges:
                for nf in edge.link_faces:
                    out.add(nf)
        return set(), set(), out
    if mode == "EDGE":
        out = set(edge_loops)
        if not out:
            for loop in loops:
                out.add(loop)
        selected_edges = {loop.edge for loop in out}
        for edge in list(selected_edges):
            for vert in edge.verts:
                for cand in vert.link_edges:
                    for face in cand.link_faces:
                        for loop in face.loops:
                            if loop.edge is cand:
                                out.add(loop)
                                break
        return set(), out, set()
    out_loops = set(loops)
    selected_verts = {loop.vert for loop in loops}
    for vert in list(selected_verts):
        for edge in vert.link_edges:
            try:
                other = edge.other_vert(vert)
            except Exception:
                continue
            for face in other.link_faces:
                for loop in face.loops:
                    if loop.vert is other:
                        out_loops.add(loop)
    return out_loops, set(), set()


def _shrink(mode: str, bm: Any, uv_layer: Any, loops: Set[Any], edge_loops: Set[Any], faces: Set[Any]):
    if mode == "FACE":
        selected = set(faces) or {loop.face for loop in loops}
        keep = set()
        for face in selected:
            ok = True
            for edge in face.edges:
                linked = [f for f in edge.link_faces if f is not face]
                if linked and not any(f in selected for f in linked):
                    ok = False; break
            if ok:
                keep.add(face)
        return set(), set(), keep
    if mode == "EDGE":
        selected_edges = {loop.edge for loop in edge_loops}
        keep_edges = set()
        for edge in selected_edges:
            ok = True
            for vert in edge.verts:
                count = sum(1 for e in vert.link_edges if e in selected_edges)
                if count < 2:
                    ok = False; break
            if ok:
                keep_edges.add(edge)
        out = set()
        for face in bm.faces:
            for loop in face.loops:
                if loop.edge in keep_edges:
                    out.add(loop)
        return set(), out, set()
    selected_verts = {loop.vert for loop in loops}
    keep_verts = set()
    for vert in selected_verts:
        linked = list(getattr(vert, "link_edges", []) or [])
        if linked and all(edge.other_vert(vert) in selected_verts for edge in linked):
            keep_verts.add(vert)
    out = set()
    for face in bm.faces:
        for loop in face.loops:
            if loop.vert in keep_verts:
                out.add(loop)
    return out, set(), set()


def _linked_island(mode: str, bm: Any, uv_layer: Any, loops: Set[Any], edge_loops: Set[Any], faces: Set[Any]):
    seed_faces = set(faces) or {loop.face for loop in loops} or {loop.face for loop in edge_loops}
    if not seed_faces:
        return set(), set(), set()
    seen_faces = set(seed_faces)
    q = deque(seed_faces)
    while q:
        face = q.popleft()
        for edge in face.edges:
            for nf in edge.link_faces:
                if nf in seen_faces:
                    continue
                # For UV islands, only traverse welded UV edges.
                la = next((l for l in face.loops if l.edge is edge), None)
                lb = next((l for l in nf.loops if l.edge is edge), None)
                if la is not None and lb is not None and _same_uv_edge(la, lb, uv_layer):
                    seen_faces.add(nf); q.append(nf)
    loops_out = set(); edge_out = set()
    for face in seen_faces:
        for loop in face.loops:
            loops_out.add(loop); edge_out.add(loop)
    if mode == "FACE":
        return set(), set(), seen_faces
    if mode == "EDGE":
        return set(), edge_out, set()
    return loops_out, set(), set()


def _border(mode: str, bm: Any, uv_layer: Any, loops: Set[Any], edge_loops: Set[Any], faces: Set[Any]):
    region_faces = set(faces)
    if not region_faces:
        if loops or edge_loops:
            # Use the island containing the current selection and return its open
            # UV boundary.  This is useful from vertex/edge mode and avoids the old
            # full-mesh fallback.
            _l, _e, f = _linked_island("FACE", bm, uv_layer, loops, edge_loops, set())
            region_faces = set(f)
    border = set()
    for face in region_faces:
        for loop in face.loops:
            edge = loop.edge
            selected_neighbors = [f for f in edge.link_faces if f in region_faces and f is not face]
            if not selected_neighbors:
                border.add(loop); continue
            welded_to_selected = False
            for nf in selected_neighbors:
                nl = next((l for l in nf.loops if l.edge is edge), None)
                if nl is not None and _same_uv_edge(loop, nl, uv_layer):
                    welded_to_selected = True
                    break
            if not welded_to_selected:
                border.add(loop)
    if mode == "VERTEX":
        out = set()
        for loop in border:
            out.add(loop); out.add(loop.link_loop_next)
        return out, set(), set()
    return set(), border, set()


def _invert(mode: str, bm: Any, uv_layer: Any, loops: Set[Any], edge_loops: Set[Any], faces: Set[Any]):
    all_loops, all_edges, all_faces = _all_loops_faces_edges(bm)
    if mode == "FACE":
        return set(), set(), all_faces - set(faces)
    if mode == "EDGE":
        return set(), all_edges - set(edge_loops), set()
    return all_loops - set(loops), set(), set()


def _loop_or_ring(self: Any, context: Any, obj: Any, bm: Any, uv_layer: Any, mode: str, action: str, loops: Set[Any], edge_loops: Set[Any]):
    seed_edges = {loop.edge for loop in edge_loops}
    if not seed_edges and loops:
        for loop in loops:
            seed_edges.add(loop.edge)
    if not seed_edges:
        return set(), set(), set()
    # Use Blender's tested mesh loop/ring operator, but sandbox all mode changes
    # and convert the resulting mesh edges back into the current UV selection.
    try:
        for v in bm.verts: v.select_set(False)
        for e in bm.edges: e.select_set(e in seed_edges)
        for f in bm.faces: f.select_set(False)
        import bmesh
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        bpy.ops.mesh.select_mode(type="EDGE")
        (bpy.ops.mesh.select_edge_ring_multi() if action == "RING" else bpy.ops.mesh.select_edge_loop_multi())
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        _ensure_lookup(bm)
        selected_edges = {e for e in bm.edges if bool(getattr(e, "select", False))}
    except Exception:
        selected_edges = set(seed_edges)
        if action == "RING":
            q = deque(seed_edges); seen = set(seed_edges)
            while q:
                edge = q.popleft()
                for face in edge.link_faces:
                    if len(face.edges) != 4:
                        continue
                    edges = list(face.edges)
                    try: idx = edges.index(edge)
                    except ValueError: continue
                    opp = edges[(idx + 2) % 4]
                    if opp not in seen:
                        seen.add(opp); q.append(opp)
            selected_edges = seen
    out_edges = set()
    for face in bm.faces:
        for loop in face.loops:
            if loop.edge in selected_edges:
                out_edges.add(loop)
    return set(), out_edges, set()


def _execute_select(self: Any, context: Any):
    action = _txt(getattr(self, "action", "GROW")).upper() or "GROW"
    snap = _snapshot_modes(context)
    obj = _mesh_obj(context)
    if obj is None:
        try: self.report({"WARNING"}, "アクティブなメッシュオブジェクトがありません。")
        except Exception: pass
        return {"CANCELLED"}
    old_mode = _txt(getattr(obj, "mode", "OBJECT")) or "OBJECT"
    changed = False
    try:
        if old_mode != "EDIT":
            try:
                context.view_layer.objects.active = obj; obj.select_set(True)
            except Exception:
                pass
            try:
                bpy.ops.object.mode_set(mode="EDIT")
                changed = True
            except Exception:
                pass
        import bmesh
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
        _ensure_lookup(bm)
        mode = _uv_mode(context)
        loops, edge_loops, faces = _selected_sets(context, obj, bm, uv_layer, mode)
        if action == "NONE":
            _clear_all(bm, uv_layer)
        elif action == "ALL":
            all_loops, all_edges, all_faces = _all_loops_faces_edges(bm)
            _apply_selection(bm, uv_layer, mode, all_loops, all_edges, all_faces)
        else:
            if not (loops or edge_loops or faces):
                try: self.report({"WARNING"}, "選択されたUVエレメントがありません。")
                except Exception: pass
                return {"CANCELLED"}
            if action == "GROW":
                out = _grow(mode, bm, uv_layer, loops, edge_loops, faces)
            elif action == "SHRINK":
                out = _shrink(mode, bm, uv_layer, loops, edge_loops, faces)
            elif action == "LINKED":
                out = _linked_island(mode, bm, uv_layer, loops, edge_loops, faces)
            elif action == "BORDER":
                out = _border(mode, bm, uv_layer, loops, edge_loops, faces)
            elif action == "INVERT":
                out = _invert(mode, bm, uv_layer, loops, edge_loops, faces)
            elif action in {"LOOP", "RING"}:
                out = _loop_or_ring(self, context, obj, bm, uv_layer, mode, action, loops, edge_loops)
                # bmesh may have been rebuilt by native loop_multi_select.
                bm = bmesh.from_edit_mesh(obj.data)
                uv_layer = bm.loops.layers.uv.active or bm.loops.layers.uv.verify()
                _ensure_lookup(bm)
            else:
                try: self.report({"WARNING"}, f"Unsupported selection action: {action}")
                except Exception: pass
                return {"CANCELLED"}
            _apply_selection(bm, uv_layer, mode, out[0], out[1], out[2])
        try:
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        except TypeError:
            bmesh.update_edit_mesh(obj.data)
        try:
            if getattr(context, "area", None) is not None:
                context.area.tag_redraw()
        except Exception:
            pass
        return {"FINISHED"}
    except Exception as exc:
        try: self.report({"WARNING"}, f"UV element selection failed: {exc}")
        except Exception: pass
        return {"CANCELLED"}
    finally:
        _restore_modes(snap)
        if changed and old_mode != "EDIT":
            try: bpy.ops.object.mode_set(mode=old_mode)
            except Exception: pass


def _patch_basic_selection(package_globals: Optional[Dict[str, Any]] = None) -> None:
    global _ORIGINAL_SELECT_EXECUTE
    cls = None
    if isinstance(package_globals, dict):
        cls = package_globals.get("SMARTUVSUITE_OT_uv_element_select_action")
    if not isinstance(cls, type):
        try:
            import sys
            pkg = sys.modules.get(__package__)
            cls = getattr(pkg, "SMARTUVSUITE_OT_uv_element_select_action", None)
        except Exception:
            cls = None
    if not isinstance(cls, type):
        return
    current = getattr(cls, "execute", None)
    if getattr(current, "_sus_18101_stable_select", False):
        return
    if _ORIGINAL_SELECT_EXECUTE is None and callable(current):
        _ORIGINAL_SELECT_EXECUTE = current
    try:
        _execute_select._sus_18101_stable_select = True  # type: ignore[attr-defined]
        cls.execute = _execute_select
    except Exception:
        pass


def _active_tool_native_transform(context: Any) -> bool:
    tid = ""
    try:
        tools = getattr(getattr(context, "workspace", None), "tools", None)
        if tools is not None:
            for args in (("UV",), ("IMAGE_EDITOR",), tuple()):
                try:
                    tool = tools.from_space_image_mode(*args, create=False)
                except TypeError:
                    try: tool = tools.from_space_image_mode(*args)
                    except Exception: tool = None
                except Exception:
                    tool = None
                tid = _txt(getattr(tool, "idname", "")).lower() if tool is not None else ""
                if tid:
                    break
    except Exception:
        pass
    return any(tok in tid for tok in ("move", "rotate", "scale", "transform", "cursor", "annotate", "lasso", "circle"))


def _base_invoke(fn: Any) -> Any:
    seen = set()
    cur = fn
    for attr in ("_sus_1900_original", "_sus_1894_original", "_sus_1871_original", "_sus_1869_original"):
        try:
            nxt = getattr(cur, attr, None)
            if callable(nxt) and id(nxt) not in seen:
                seen.add(id(cur)); cur = nxt
        except Exception:
            pass
    return cur


def _patch_immediate(package_globals: Optional[Dict[str, Any]] = None) -> None:
    global _ORIGINAL_INSTANT_INVOKE
    cls = None
    if isinstance(package_globals, dict):
        cls = package_globals.get("SMARTUVSUITE_OT_instant_select_drag_move")
    if not isinstance(cls, type):
        try:
            import sys
            pkg = sys.modules.get(__package__)
            cls = getattr(pkg, "SMARTUVSUITE_OT_instant_select_drag_move", None)
        except Exception:
            cls = None
    if not isinstance(cls, type):
        return
    current = getattr(cls, "invoke", None)
    if getattr(current, "_sus_18101_immediate", False):
        return
    base = _base_invoke(current)
    if _ORIGINAL_INSTANT_INVOKE is None and callable(base):
        _ORIGINAL_INSTANT_INVOKE = base

    def _invoke_18101(self, context, event, _base=base):
        try:
            if _txt(getattr(event, "type", "")) != "LEFTMOUSE" or _txt(getattr(event, "value", "")) != "PRESS":
                return _base(self, context, event)
            # Do not steal native transform/gizmo tools.  Select/Tweak/Select Box
            # still go through the original Immediate Select code so unselected
            # element drags can start immediately.
            if _active_tool_native_transform(context):
                return {"PASS_THROUGH"}
            return _base(self, context, event)
        except Exception:
            return {"PASS_THROUGH"}

    try:
        _invoke_18101._sus_18101_immediate = True  # type: ignore[attr-defined]
        _invoke_18101._sus_18101_original = base  # type: ignore[attr-defined]
        cls.invoke = _invoke_18101
        # Restore the class' own hit finder if 1.8.100 replaced it with
        # cache-only lookup.  The original invoke already passes background and
        # selected-gizmo hits through; limited keymap rows prevent broad lag.
        old_find = getattr(cls, "_find_uv_hit", None)
        if callable(old_find) and getattr(old_find, "__name__", "") == "<lambda>":
            # Cannot reconstruct here; the base invoke closes over the original
            # method lookup.  Leave it unless 1.8.100 set the cache-only marker.
            pass
    except Exception:
        pass


def _ensure_immediate_keymaps(context: Any = None) -> None:
    try:
        from . import uv_immediate_select_restore_18100 as m
        fn = getattr(m, "ensure_keymaps", None)
        if callable(fn):
            fn(True, context or bpy.context)
    except Exception:
        pass


def _patch_selection_guard(package_globals: Optional[Dict[str, Any]] = None) -> None:
    # Keep the 1.8.98 state guard active, but make sure it wraps our stable
    # backend rather than an older execute function.
    try:
        from . import uv_selection_state_guard_1898 as sg
        apply_fn = getattr(sg, "apply_all", None) or getattr(sg, "install", None)
        if callable(apply_fn):
            apply_fn(package_globals or globals(), bpy.context)
    except Exception:
        pass


def _mark_version(package_globals: Optional[Dict[str, Any]] = None) -> None:
    target = package_globals if isinstance(package_globals, dict) else globals()
    try:
        info = target.get("bl_info")
        if isinstance(info, dict):
            info.update({
                "name": "Smart UV Suite",
                "author": "JELararagi",
                "version": (1, 0, 0),
                "blender": (5, 1, 0),
                "location": "View3D / UV Editor > Sidebar > Smart UV",
                "description": "Smart UV Suite exposes UV editing tools in the Smart UV sidebar.",
                "category": "Smart UV",
            })
            target["_SUS_BL_INFO_FALLBACK"] = dict(info)
        target["__version__"] = '1.0.0'
    except Exception:
        pass


def apply_all(package_globals: Optional[Dict[str, Any]] = None, context: Any = None) -> None:
    global _NS
    if isinstance(package_globals, dict):
        _NS = package_globals
    _patch_basic_selection(package_globals)
    _patch_immediate(package_globals)
    _ensure_immediate_keymaps(context or getattr(bpy, "context", None))
    _mark_version(package_globals)


def install(package_globals: Optional[Dict[str, Any]] = None, context: Any = None) -> None:
    global _INSTALLED, _NS
    if isinstance(package_globals, dict):
        _NS = package_globals
    apply_all(package_globals, context or getattr(bpy, "context", None))
    _INSTALLED = True


def unregister() -> None:
    # Do not remove the normal Immediate Select keymap rows here.  They are add-on
    # keymap rows and Blender will dispose of them with the extension keyconfig.
    pass


def audit(context: Any = None) -> dict:
    del context
    rows = []
    try:
        from . import ownership_runtime_18168 as _ownership
        for km, kmi in _ownership.owned_keymap_items('smart_uv_suite.instant_select_drag_move'):
            rows.append((getattr(km, 'name', ''), bool(getattr(kmi, 'active', False)), getattr(kmi, 'type', ''), getattr(kmi, 'value', '')))
    except Exception:
        pass
    return {'version': _VERSION, 'instant_rows': rows, 'foreign_keymaps_scanned': False}

