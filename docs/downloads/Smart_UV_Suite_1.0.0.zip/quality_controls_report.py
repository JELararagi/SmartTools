from __future__ import annotations
from . import resource_api_18168 as _suv_resource

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None

_NAMESPACE = {}
_REGISTERED = []


def _tr(context, key: str, en: str, ja: str, **fmt) -> str:
    fn = _NAMESPACE.get('tr')
    text = None
    if callable(fn):
        try:
            text = fn(context, key, **fmt)
        except Exception:
            text = None
    if not text:
        text = en
    try:
        return text.format(**fmt)
    except Exception:
        return text


def _text_name(context) -> str:
    ws_fn = _NAMESPACE.get('_suv_ws')
    ws = ws_fn(context) if callable(ws_fn) else None
    name = getattr(ws, 'support_bundle_name', '') if ws else ''
    return (str(name).strip() or 'SUV_Support_Bundle') + '_Visual_Controls_Report'


def _suv_controls_report_name(context):
    return _text_name(context)


def _ensure_text_block(name: str, clear=False):
    textio = _NAMESPACE.get('_quality_textio_module')
    if textio is not None and hasattr(textio, 'ensure_report_text'):
        try:
            return textio.ensure_report_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if textio is not None and hasattr(textio, 'ensure_namespace_text'):
        try:
            return textio.ensure_namespace_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if textio is not None and hasattr(textio, 'ensure_text_block'):
        try:
            return textio.ensure_text_block(name, clear=clear)
        except Exception:
            pass
    if bpy is None:
        return None
    txt = bpy.data.texts.get(name)
    if txt is None:
        if not clear:
            return None
        txt = bpy.data.texts.new(name)
    elif clear:
        txt.clear()
    return txt


def _text_block(name: str, clear=False):
    return _ensure_text_block(name, clear=clear)


def _find_text_block(name: str):
    if bpy is None:
        return None
    return bpy.data.texts.get(name)


def scan_controls_report(namespace: dict, context) -> dict:
    controls_mod = namespace.get('_quality_controls_module')
    state_mod = namespace.get('_quality_state_module')
    controls = {}
    if controls_mod is not None and hasattr(controls_mod, 'scan_visual_controls'):
        try:
            controls = controls_mod.scan_visual_controls(namespace, context) or {}
        except Exception:
            controls = {}
    status = {}
    if state_mod is not None and hasattr(state_mod, 'collect_status'):
        try:
            status = state_mod.collect_status(namespace, context) or {}
        except Exception:
            status = {}
    data = {
        'focus_override': str((controls or {}).get('focus_override', 'AUTO') or 'AUTO'),
        'focus_effective': str((controls or {}).get('focus_effective', 'AUTO') or 'AUTO'),
        'focus_manual': bool((controls or {}).get('focus_manual', False)),
        'density_override': str((controls or {}).get('density_override', 'AUTO') or 'AUTO'),
        'density_effective': str((controls or {}).get('density_effective', 'FULL') or 'FULL'),
        'density_manual': bool((controls or {}).get('density_manual', False)),
        'preset_override': str((controls or {}).get('preset_override', 'AUTO') or 'AUTO'),
        'preset_effective': str((controls or {}).get('preset_effective', 'AUTO') or 'AUTO'),
        'preset_label': str((controls or {}).get('preset_label', 'AUTO') or 'AUTO'),
        'preset_manual': bool((controls or {}).get('preset_manual', False)),
        'preset_matched': bool((controls or {}).get('preset_matched', True)),
        'manual_controls': int((controls or {}).get('manual_controls', 0) or 0),
        'manual_items': list((controls or {}).get('manual_items', []) or []),
        'manual_item_labels': list((controls or {}).get('manual_item_labels', []) or []),
        'hidden_sections': int((controls or {}).get('hidden_sections', 0) or 0),
        'visible_sections': int((controls or {}).get('visible_sections', 0) or 0),
        'controls_summary': str((controls or {}).get('summary', '') or ''),
        'section_visibility': dict((controls or {}).get('section_visibility', {}) or {}),
        'section_labels': dict((controls or {}).get('section_labels', {}) or {}),
        'controls_last_reason': str((controls or {}).get('last_reason', '') or ''),
        'controls_revision': int((controls or {}).get('revision', 0) or 0),
        'recommended_actions': int((status or {}).get('recommended_actions', 0) or 0),
        'recommended_reasons': list((status or {}).get('recommended_reasons', []) or []),
    }
    namespace['_suv_controls_report_last'] = dict(data)
    return data


class SUV_OT_quality_write_controls_report(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_write_controls_report'
    bl_label = 'Write Visual Controls Report'
    bl_description = 'Write a compact report that explains the current dashboard focus, density, section visibility, preset state, and manual visual-control overrides. / 現在のダッシュボードのフォーカス、表示密度、セクション表示、プリセット状態、手動の視覚コントロール上書きをまとめたレポートを書き出します。'
    bl_options = set()

    open_after_write: bpy.props.BoolProperty(
        name='Open After Write',
        description='Open the written controls report in Blender Text Editor when possible / 可能なら書き出した視覚コントロールレポートを Blender テキストエディタで開きます',
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        data = scan_controls_report(_NAMESPACE, context)
        txt = None
        labels = list(data.get('manual_item_labels', []) or [])
        reasons = list(data.get('recommended_reasons', []) or [])
        section_visibility = dict(data.get('section_visibility', {}) or {})
        section_labels = dict(data.get('section_labels', {}) or {})
        section_state_labels = dict(data.get('section_state_labels', {}) or {})
        shown_label = _tr(context, 'ui.visual.section_state.shown', 'shown', '表示')
        hidden_label = _tr(context, 'ui.visual.section_state.hidden', 'hidden', '非表示')
        yes_label = _tr(context, 'ui.bool.on', 'On', 'オン')
        no_label = _tr(context, 'ui.bool.off', 'Off', 'オフ')
        match_label = yes_label if bool(data.get('preset_matched', True)) else no_label
        section_lines = []
        for sid, shown in section_visibility.items():
            label = section_labels.get(str(sid), str(sid))
            state_label = section_state_labels.get(str(sid), shown_label if shown else hidden_label)
            section_lines.append(f"- {label}: {state_label}")
        lines = [
            'UV Suite Visual Controls Report',
            '',
            '[Summary]',
            f"Preset: {data.get('preset_display_label', data['preset_label'])} (override={data.get('preset_override_label', data['preset_override'])}, effective={data.get('preset_effective_label', data['preset_effective'])}, matched={match_label})",
            f"Focus: override={data.get('focus_override_label', data['focus_override'])} effective={data.get('focus_effective_label', data['focus_effective'])} manual={(yes_label if data['focus_manual'] else no_label)}",
            f"Density: override={data.get('density_override_label', data['density_override'])} effective={data.get('density_effective_label', data['density_effective'])} manual={(yes_label if data['density_manual'] else no_label)}",
            f"Visible sections: {data['visible_sections']} | Hidden sections: {data['hidden_sections']}",
            f"Manual controls: {data['manual_controls']}",
            f"Last change reason: {data['controls_last_reason'] or '-'}",
            f"Controls revision: {data['controls_revision']}",
            f"Recommended actions: {data['recommended_actions']}",
            '',
            '[Visual controls]',
            f"{data['controls_summary'] or '-'}",
            '',
            '[Manual items]',
        ]
        if labels:
            lines.extend([f"- {label}" for label in labels])
        else:
            lines.append('- none')
        lines.extend(['', '[Section visibility]'])
        if section_lines:
            lines.extend(section_lines)
        else:
            lines.append('- none')
        lines.extend(['', '[Recommended reasons]'])
        if reasons:
            lines.extend([f"- {reason}" for reason in reasons])
        else:
            lines.append('- none')
        lines.extend([
            '',
            '[日本語メモ]',
            f"現在の視覚コントロール要約: {data['controls_summary'] or '-'}",
            f"手動コントロール数: {data['manual_controls']}",
            '手動変更が多いときは、このレポートを見ると今どの上書きが入っているか確認しやすいです。',
        ])
        textio = _NAMESPACE.get('_quality_textio_module')
        writer = getattr(textio, 'write_report_lines_consistent', None) if textio is not None else None
        if callable(writer):
            txt = writer(
                _NAMESPACE, context, _text_name, lines, _text_block, self,
                open_after_write=self.open_after_write,
                failed_key='msg.quality_controls_report_open_failed',
                failed_en='Could not open visual controls report: {name}',
                failed_ja='視覚コントロールレポートを開けませんでした: {name}',
            )
            if txt is None:
                return {'CANCELLED'}
        else:
            txt = _text_block(_text_name(context), clear=True)
            if txt is None:
                return {'CANCELLED'}
            if textio is not None and hasattr(textio, 'write_text_lines'):
                if textio.write_text_lines(txt, lines) is None:
                    return {'CANCELLED'}
            else:
                txt.write('\n'.join(lines))
            if self.open_after_write and textio is not None and hasattr(textio, 'open_written_text'):
                textio.open_written_text(
                    _NAMESPACE, context, txt, self,
                    failed_key='msg.quality_controls_report_open_failed',
                    failed_en='Could not open visual controls report: {name}',
                    failed_ja='視覚コントロールレポートを開けませんでした: {name}',
                )
        self.report({'INFO'}, _tr(context, 'msg.quality_controls_report_written', 'Visual controls report written: {name}', '視覚コントロールレポートを書き出しました: {name}', name=txt.name))
        return {'FINISHED'}


class SUV_OT_quality_open_controls_report(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_open_controls_report'
    bl_label = 'Open Visual Controls Report'
    bl_description = 'Open the latest visual controls report in Blender Text Editor. / 最新の視覚コントロールレポートを Blender のテキストエディタで開きます。'
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        textio = _NAMESPACE.get('_quality_textio_module')
        if textio is not None and hasattr(textio, 'open_named_report_text_or_fallback'):
            return textio.open_named_report_text_or_fallback(
                _NAMESPACE, context, _text_name, self, _text_block,
                missing_key='msg.quality_controls_report_missing',
                missing_en='No visual controls report exists yet.',
                missing_ja='視覚コントロールレポートはまだ作成されていません。',
                opened_key='msg.quality_controls_report_opened',
                opened_en='Opened visual controls report: {name}',
                opened_ja='視覚コントロールレポートを開きました: {name}',
                failed_key='msg.quality_controls_report_open_failed',
                failed_en='Could not open visual controls report: {name}',
                failed_ja='視覚コントロールレポートを開けませんでした: {name}',
            )
        txt = _find_text_block(_text_name(context))
        if txt is None:
            self.report({'WARNING'}, _tr(context, 'msg.quality_controls_report_missing', 'No visual controls report exists yet.', '視覚コントロールレポートはまだ作成されていません。'))
            return {'CANCELLED'}
        opener = _NAMESPACE.get('_suv_open_text_in_editor')
        ok = False
        if callable(opener):
            try:
                ok, _err = opener(context, txt)
            except Exception:
                ok = False
        if not ok:
            self.report({'WARNING'}, _tr(context, 'msg.quality_controls_report_open_failed', 'Could not open visual controls report: {name}', '視覚コントロールレポートを開けませんでした: {name}', name=txt.name))
            return {'CANCELLED'}
        self.report({'INFO'}, _tr(context, 'msg.quality_controls_report_opened', 'Opened visual controls report: {name}', '視覚コントロールレポートを開きました: {name}', name=txt.name))
        return {'FINISHED'}


def register(namespace: dict):
    global _NAMESPACE
    _NAMESPACE = namespace if isinstance(namespace, dict) else {}
    if bpy is None:
        return []
    classes = [SUV_OT_quality_write_controls_report, SUV_OT_quality_open_controls_report]
    reg = []
    for cls in classes:
        try:
            _suv_resource.register_class(cls)
            reg.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = reg
    return reg


def unregister(namespace: dict | None = None):
    if bpy is None:
        return []
    removed = []
    for cls in reversed(list(_REGISTERED)):
        try:
            _suv_resource.unregister_class(cls)
            removed.append(cls)
        except Exception:
            pass
    _REGISTERED[:] = []
    return removed
