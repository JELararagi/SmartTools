# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Smart UV Suite clean-room automatic unwrap and packing helpers.

This module deliberately does not load or copy third-party binaries.  It
implements same-purpose UV workflows from public feature behavior: one-click
automatic unwrapping, hard/organic/mosaic modes, exact-margin deterministic
packing, and multi-tile placement.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass
from typing import Iterable

import bpy
import bmesh
from mathutils import Vector


# ---------------------------------------------------------------------------
# Generic context helpers
# ---------------------------------------------------------------------------

def _active_mesh(context):
    obj = getattr(context, "object", None) or getattr(context.view_layer.objects, "active", None)
    return obj if obj is not None and getattr(obj, "type", "") == "MESH" else None


def _mode_to_edit(obj):
    old = getattr(obj, "mode", "OBJECT")
    try:
        if old != "EDIT":
            bpy.ops.object.mode_set(mode="EDIT")
    except Exception:
        pass
    return old


def _restore_mode(obj, old):
    try:
        if old and old != getattr(obj, "mode", ""):
            bpy.ops.object.mode_set(mode=old)
    except Exception:
        pass


def _bm_state(obj):
    bm = bmesh.from_edit_mesh(obj.data)
    uv_layer = bm.loops.layers.uv.verify()
    try:
        bm.faces.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.verts.ensure_lookup_table()
        bm.faces.index_update(); bm.edges.index_update(); bm.verts.index_update(); bm.normal_update()
    except Exception:
        pass
    return bm, uv_layer


def _selected_faces_or_all(bm):
    faces = [f for f in bm.faces if bool(getattr(f, "select", False)) and not getattr(f, "hide", False)]
    try:
        uv_sync = bool(bpy.context.scene.tool_settings.use_uv_select_sync)
    except Exception:
        uv_sync = True
    if not uv_sync:
        uv_faces = [f for f in faces if any(l.uv_select_vert or l.uv_select_edge for l in f.loops)]
        if uv_faces:
            return uv_faces
    if not faces:
        faces = [f for f in bm.faces if not getattr(f, "hide", False)]
        for f in faces:
            try:
                f.select_set(True)
            except Exception:
                f.select = True
    return faces


def _safe_uv_op(op_name: str, **kwargs) -> bool:
    try:
        op = bpy.ops
        for part in op_name.split('.'):
            op = getattr(op, part)
        keys = set()
        try:
            rna = op.get_rna_type()
            keys = {p.identifier for p in getattr(rna, "properties", []) if p.identifier != "rna_type"}
        except Exception:
            keys = set(kwargs)
        filtered = {k: v for k, v in kwargs.items() if not keys or k in keys}
        result = op(**filtered)
        return "FINISHED" in set(result or [])
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Geometry / UV issue checks
# ---------------------------------------------------------------------------

def _poly_area(points):
    if len(points) < 3:
        return 0.0
    a = 0.0
    for i, p in enumerate(points):
        q = points[(i + 1) % len(points)]
        a += p.x * q.y - q.x * p.y
    return 0.5 * a


def _seg_intersect(a, b, c, d, eps=1e-9):
    def orient(p, q, r):
        return (q.x - p.x) * (r.y - p.y) - (q.y - p.y) * (r.x - p.x)
    def on_seg(p, q, r):
        return (min(p.x, r.x) - eps <= q.x <= max(p.x, r.x) + eps and
                min(p.y, r.y) - eps <= q.y <= max(p.y, r.y) + eps and
                abs(orient(p, q, r)) <= eps)
    o1 = orient(a, b, c); o2 = orient(a, b, d); o3 = orient(c, d, a); o4 = orient(c, d, b)
    if (o1 * o2 < -eps) and (o3 * o4 < -eps):
        return True
    return on_seg(a, c, b) or on_seg(a, d, b) or on_seg(c, a, d) or on_seg(c, b, d)


def count_face_edge_issues(obj, limit=200000):
    """Return a small deterministic overlap/crossing issue count for validation."""
    old = _mode_to_edit(obj)
    try:
        bm, uv_layer = _bm_state(obj)
        faces = _selected_faces_or_all(bm)
        polys = []
        edges = []
        for f in faces:
            pts = [l[uv_layer].uv.copy() for l in f.loops]
            if len(pts) < 3:
                continue
            if abs(_poly_area(pts)) <= 1e-12:
                polys.append((f.index, pts, True))
            else:
                polys.append((f.index, pts, False))
            loops = list(f.loops)
            for i, l in enumerate(loops):
                edges.append((int(f.index), int(l.vert.index), int(loops[(i+1)%len(loops)].vert.index), pts[i], pts[(i+1)%len(pts)]))
        issues = sum(1 for _, _, zero in polys if zero)
        # conservative edge crossing pass.  Shared mesh edges are ignored.
        n = len(edges)
        checked = 0
        for i in range(n):
            fi, a0, a1, p0, p1 = edges[i]
            for j in range(i + 1, n):
                fj, b0, b1, q0, q1 = edges[j]
                if fi == fj:
                    continue
                if {a0, a1} & {b0, b1}:
                    continue
                if max(p0.x, p1.x) < min(q0.x, q1.x) or max(q0.x, q1.x) < min(p0.x, p1.x):
                    continue
                if max(p0.y, p1.y) < min(q0.y, q1.y) or max(q0.y, q1.y) < min(p0.y, p1.y):
                    continue
                checked += 1
                if checked > limit:
                    return issues
                if _seg_intersect(p0, p1, q0, q1):
                    issues += 1
                    if issues > 64:
                        return issues
        return issues
    except Exception:
        return 999999
    finally:
        try:
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        except Exception:
            pass
        _restore_mode(obj, old)


# ---------------------------------------------------------------------------
# Deterministic exact-margin bbox packer
# ---------------------------------------------------------------------------

@dataclass
class _Island:
    faces: list
    loops: list
    has_pin: bool = False


def _edge_uv_pair(face, edge, uv_layer):
    for l in face.loops:
        if l.edge == edge:
            return {
                int(l.vert.index): l[uv_layer].uv.copy(),
                int(l.link_loop_next.vert.index): l.link_loop_next[uv_layer].uv.copy(),
            }
    return {}


def _build_islands(bm, uv_layer, faces):
    face_set = {int(f.index): f for f in faces}
    if not face_set:
        return []
    parent = {fi: fi for fi in face_set}
    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]; a = parent[a]
        return a
    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra
    for e in bm.edges:
        linked = [f for f in getattr(e, "link_faces", []) if int(f.index) in face_set]
        if len(linked) != 2:
            continue
        p0 = _edge_uv_pair(linked[0], e, uv_layer)
        p1 = _edge_uv_pair(linked[1], e, uv_layer)
        ok = True
        for vi, uv in p0.items():
            if vi not in p1 or (uv - p1[vi]).length > 1e-5:
                ok = False; break
        if ok:
            union(int(linked[0].index), int(linked[1].index))
    groups = {}
    for fi, f in face_set.items():
        groups.setdefault(find(fi), []).append(f)
    islands = []
    for fs in groups.values():
        loops = []
        pinned = False
        for f in fs:
            for l in f.loops:
                loops.append(l)
                try:
                    pinned = pinned or bool(l[uv_layer].pin_uv)
                except Exception:
                    pass
        islands.append(_Island(fs, loops, pinned))
    return islands


def _rotated_points(points, center, angle):
    ca = math.cos(angle); sa = math.sin(angle)
    out = []
    for p in points:
        d = p - center
        out.append(Vector((center.x + d.x * ca - d.y * sa, center.y + d.x * sa + d.y * ca)))
    return out


def _bbox(points):
    if not points:
        return (0.0, 0.0, 1.0, 1.0)
    xs = [p.x for p in points]; ys = [p.y for p in points]
    return (min(xs), min(ys), max(xs), max(ys))


def _island_points(isl, uv_layer):
    return [l[uv_layer].uv.copy() for l in isl.loops]


def _pack_shelves(records, margin, pad, allow_rotate=True, rotation_step=90, tile_u=0, tile_v=0):
    # First-fit decreasing shelves in normalized tile coordinates.
    usable = max(1e-9, 1.0 - margin * 2.0)
    x0 = tile_u + margin
    y0 = tile_v + margin
    cur_x = x0
    cur_y = y0
    row_h = 0.0
    placements = []
    for rec in records:
        choices = rec["choices"] if allow_rotate else [rec["choices"][0]]
        # Prefer the choice that fits current row with the least height increase.
        choice = None
        for ch in choices:
            if cur_x + ch["w"] <= tile_u + 1.0 - margin + 1e-9:
                if choice is None or ch["h"] < choice["h"]:
                    choice = ch
        if choice is None:
            cur_x = x0
            cur_y += row_h + pad
            row_h = 0.0
            for ch in choices:
                if ch["w"] <= usable + 1e-9:
                    if choice is None or ch["h"] < choice["h"]:
                        choice = ch
        if choice is None:
            return None
        if cur_y + choice["h"] > tile_v + 1.0 - margin + 1e-9:
            return None
        placements.append((rec, choice, Vector((cur_x, cur_y))))
        cur_x += choice["w"] + pad
        row_h = max(row_h, choice["h"])
    return placements


def _pack_around_fixed(records, margin, pad, fixed, tile_u, tile_v, deadline):
    left, bottom = tile_u + margin, tile_v + margin
    right, top = tile_u + 1.0 - margin, tile_v + 1.0 - margin
    occupied = [(x1 - pad, y1 - pad, x2 + pad, y2 + pad) for x1, y1, x2, y2 in fixed]
    occupied = [box for box in occupied
                if box[0] < right and box[2] > left and box[1] < top and box[3] > bottom]
    if not occupied:
        return _pack_shelves(records, margin, pad, tile_u=tile_u, tile_v=tile_v)
    placements = []
    for record in records:
        xs = sorted({left} | {box[2] for box in occupied if left < box[2] < right})
        ys = sorted({bottom} | {box[3] for box in occupied if bottom < box[3] < top})
        choices = sorted(record["choices"], key=lambda choice: choice["h"])
        placement = None
        for y in ys:
            for x in xs:
                if time.monotonic() > deadline:
                    return None
                for choice in choices:
                    x2, y2 = x + choice["w"], y + choice["h"]
                    if x2 > right + 1e-9 or y2 > top + 1e-9:
                        continue
                    if any(x < b[2] and x2 > b[0] and y < b[3] and y2 > b[1] for b in occupied):
                        continue
                    placement = (record, choice, Vector((x, y)))
                    occupied.append((x, y, x2, y2))
                    break
                if placement is not None:
                    break
            if placement is not None:
                break
        if placement is None:
            return None
        placements.append(placement)
    return placements


def quality_pack(context, *, margin_px=8, texture_size=2048, rotate=True, rotation_step=15, udim=False,
                 tile_columns=10, lock_pinned=True, max_seconds=9.5):
    """Pack selected UV islands with deterministic exact bbox spacing.

    The packer is intentionally conservative: bbox spacing is exact and therefore
    it avoids overlaps even when polygon-shape packing would be tighter.
    """
    obj = _active_mesh(context)
    if obj is None:
        return False
    old = _mode_to_edit(obj)
    start = time.monotonic()
    try:
        bm, uv_layer = _bm_state(obj)
        faces = _selected_faces_or_all(bm)
        islands = _build_islands(bm, uv_layer, faces)
        movable = [isl for isl in islands if not (lock_pinned and isl.has_pin)]
        if not movable:
            return False
        fixed = [_bbox(_island_points(isl, uv_layer)) for isl in islands if lock_pinned and isl.has_pin]
        margin = max(0.0, min(0.25, float(margin_px) / max(1.0, float(texture_size))))
        # Use a second inter-island padding equal to the margin; this mirrors the
        # visible pixel padding and prevents bake bleeding.
        pad = margin
        rot_step = max(1, int(rotation_step or 90))
        if rot_step <= 15:
            angles = [math.radians(a) for a in range(0, 180, 15)]
        elif rot_step <= 45:
            angles = [0.0, math.radians(45), math.radians(90), math.radians(135)]
        elif rot_step <= 90:
            angles = [0.0, math.radians(90)]
        else:
            angles = [0.0]
        if not rotate:
            angles = [0.0]
        raw = []
        total_area = 0.0
        for idx, isl in enumerate(movable):
            pts = _island_points(isl, uv_layer)
            if not pts:
                continue
            center = sum(pts, Vector((0, 0))) / float(len(pts))
            choices = []
            for ang in angles:
                rpts = _rotated_points(pts, center, ang)
                minx, miny, maxx, maxy = _bbox(rpts)
                w = max(1e-8, maxx - minx)
                h = max(1e-8, maxy - miny)
                choices.append({"angle": ang, "center": center, "min": Vector((minx, miny)), "w0": w, "h0": h})
            area = max(c["w0"] * c["h0"] for c in choices)
            total_area += area
            raw.append({"idx": idx, "island": isl, "choices0": choices, "area": area})
        if not raw:
            return False
        raw.sort(key=lambda r: (max(c["h0"] for c in r["choices0"]), r["area"]), reverse=True)
        if udim:
            scale = min(1.0, math.sqrt(max(1e-9, 1.0 - margin * 2.0) ** 2 / max(1e-9, total_area)) * 0.98)
            tile = 0
            placements_all = []
            remaining = raw[:]
            while remaining:
                if time.monotonic() - start > max_seconds:
                    return False
                records = []
                for rec in remaining:
                    choices=[]
                    for c in rec["choices0"]:
                        choices.append({**c, "w": c["w0"] * scale + pad, "h": c["h0"] * scale + pad})
                    records.append({**rec, "choices": choices})
                tu = tile % max(1, int(tile_columns)); tv = tile // max(1, int(tile_columns))
                if fixed:
                    placed = _pack_around_fixed(records, margin, pad, fixed, tu, tv, start + max_seconds)
                    if placed is None and _pack_shelves(records, margin, pad, rotate, rotation_step, tu, tv) is not None:
                        tile += 1
                        if tile > 1000:
                            return False
                        continue
                else:
                    placed = _pack_shelves(records, margin, pad, rotate, rotation_step, tu, tv)
                if placed is None:
                    scale *= 0.86
                    if scale < 1e-5:
                        return False
                    continue
                placed_ids = {id(p[0]["island"]) for p in placed}
                placements_all.extend(placed)
                remaining = [r for r in remaining if id(r["island"]) not in placed_ids]
                tile += 1
                if tile > 1000:
                    return False
            placements = placements_all
            final_scale = scale
        else:
            # Binary search maximum uniform scale that fits into the 1001 tile.
            area_guess = math.sqrt(max(1e-9, (1.0 - margin * 2.0) ** 2) / max(1e-9, total_area))
            lo, hi = 1e-5, min(64.0, max(0.01, area_guess * 1.45))
            best = None; final_scale = lo
            for _ in range(32):
                if time.monotonic() - start > max_seconds:
                    break
                mid = (lo + hi) * 0.5
                records=[]
                for rec in raw:
                    choices=[]
                    for c in rec["choices0"]:
                        choices.append({**c, "w": c["w0"] * mid + pad, "h": c["h0"] * mid + pad})
                    records.append({**rec, "choices": choices})
                if fixed:
                    placed = _pack_around_fixed(records, margin, pad, fixed, 0, 0, start + max_seconds)
                else:
                    placed = _pack_shelves(records, margin, pad, rotate, rotation_step, 0, 0)
                if placed is None:
                    hi = mid
                else:
                    best = placed; final_scale = mid; lo = mid
            if best is None:
                return False
            placements = best
        for rec, choice, dst in placements:
            isl = rec["island"]
            center = choice["center"]
            angle = choice["angle"]
            ca = math.cos(angle); sa = math.sin(angle)
            mn = choice["min"]
            for l in isl.loops:
                uv = l[uv_layer].uv.copy()
                d = uv - center
                r = Vector((center.x + d.x * ca - d.y * sa, center.y + d.x * sa + d.y * ca))
                l[uv_layer].uv = Vector((dst.x + (r.x - mn.x) * final_scale, dst.y + (r.y - mn.y) * final_scale))
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return True
    except Exception:
        return False
    finally:
        _restore_mode(obj, old)


# ---------------------------------------------------------------------------
# Clean-room one-click Standard unwrap
# ---------------------------------------------------------------------------

def _save_seams(bm):
    return {int(e.index): bool(getattr(e, "seam", False)) for e in bm.edges}


def _restore_seams(obj, seams):
    try:
        bm, _ = _bm_state(obj)
        for e in bm.edges:
            try:
                e.seam = bool(seams.get(int(e.index), False))
            except Exception:
                pass
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    except Exception:
        pass


def _mesh_stats(bm, faces):
    angles = []
    lengths = []
    selected = {int(f.index) for f in faces}
    for e in bm.edges:
        linked = [f for f in getattr(e, "link_faces", []) if int(f.index) in selected]
        try:
            lengths.append(max(1e-9, float(e.calc_length())))
        except Exception:
            pass
        if len(linked) == 2:
            try:
                angles.append(math.degrees(linked[0].normal.angle(linked[1].normal, 0.0)))
            except Exception:
                pass
    angles.sort(); lengths.sort()
    def med(v, d=0.0): return v[len(v)//2] if v else d
    return {"median_angle": med(angles, 0.0), "max_angle": max(angles) if angles else 0.0,
            "median_len": med(lengths, 1.0), "max_len": max(lengths) if lengths else 1.0}


def _classify_unwrap_mode(raw_algorithm: str, stats: dict) -> str:
    a = str(raw_algorithm or "AUTO_ONE_CLICK").upper()
    aliases = {
        "HYBRID": "AUTO_ONE_CLICK", "CONFORMAL_SAFE": "AUTO_ONE_CLICK", "LSCM_PEEL": "AUTO_ONE_CLICK",
        "ANGLE_AWARE": "HARD_SURFACE", "EDGE_LENGTH": "HARD_SURFACE", "AREA_BALANCED": "HARD_SURFACE",
        "COTAN_RELAX": "ORGANIC", "MASS_SPRING": "ORGANIC", "SPRING_RELAXED": "ORGANIC", "FLOW_RELAXED": "ORGANIC",
        "GEODESIC_GRID": "MOSAIC", "TUTTE": "MOSAIC", "TUTTE_CONVEX": "MOSAIC", "HARMONIC": "ORGANIC",
        "INTRINSIC_FLOW": "ORGANIC", "CENTER_OUT": "MOSAIC", "MDS_STRESS": "ORGANIC",
    }
    a = aliases.get(a, a)
    if a == "AUTO_ONE_CLICK":
        if stats.get("max_angle", 0.0) > 72.0 or stats.get("median_angle", 0.0) > 18.0:
            return "HARD_SURFACE"
        if stats.get("max_len", 1.0) / max(1e-9, stats.get("median_len", 1.0)) > 5.0:
            return "MOSAIC"
        return "ORGANIC"
    if a in {"HARD_SURFACE", "ORGANIC", "MOSAIC", "PROJECTION"}:
        return a
    return "ORGANIC"


def _mark_temp_seams(bm, faces, mode, tolerance, flexibility, *, keep_seams=False,
                     cut_grooves=True, groove_angle=55.0,
                     cut_ridges=True, ridge_angle=65.0,
                     cut_holes=True, stretch_allowed=0.35, cfg=None):
    cfg = dict(cfg or {})
    selected = {int(f.index) for f in faces}
    stats = _mesh_stats(bm, faces)
    med_len = max(1e-9, stats["median_len"])
    stretch_allowed = max(0.0, min(1.0, float(stretch_allowed)))
    # Low tolerance and low stretch create seams earlier; high stretch/strength keeps larger charts.
    if mode == "HARD_SURFACE":
        angle_cut = 28.0 + tolerance * 65.0
        length_cut = 1.6 + tolerance * 5.5
    elif mode == "MOSAIC":
        angle_cut = 18.0 + tolerance * 50.0
        length_cut = 1.3 + tolerance * 4.0
    else:  # ORGANIC / PROJECTION
        angle_cut = 74.0 + tolerance * 70.0
        length_cut = 2.6 + tolerance * 6.0
    # More strict stretch setting means earlier cuts.
    angle_cut *= (0.72 + 0.48 * stretch_allowed)
    length_cut *= (0.70 + 0.50 * stretch_allowed)
    groove_angle = max(1.0, min(179.0, float(groove_angle)))
    ridge_angle = max(1.0, min(179.0, float(ridge_angle)))
    cut_grooves = bool(cfg.get('smart_standard_cut_grooves', True))
    cut_ridges = bool(cfg.get('smart_standard_cut_ridges', True))
    use_marks = bool(cfg.get('smart_standard_use_marks', True))
    try:
        hs_angle = float(cfg.get('smart_standard_hard_surface_angle', 0.0) or 0.0)
        if hs_angle > 0.0 and mode == 'HARD_SURFACE':
            angle_cut = max(1.0, min(179.0, hs_angle))
    except Exception:
        pass
    seams = 0
    for e in bm.edges:
        linked = [f for f in getattr(e, "link_faces", []) if int(f.index) in selected]
        if not linked:
            continue
        # Cut Holes: open borders and holes are useful chart starts.
        if len(linked) <= 1:
            if cut_holes:
                try:
                    e.seam = True; seams += 1
                except Exception:
                    pass
            continue
        angle = 0.0
        if len(linked) == 2:
            try:
                angle = math.degrees(linked[0].normal.angle(linked[1].normal, 0.0))
            except Exception:
                angle = 0.0
        try:
            ratio = float(e.calc_length()) / med_len
        except Exception:
            ratio = 1.0
        should = bool(getattr(e, "seam", False)) if keep_seams else False
        # Blender exposes only unsigned dihedral information here, so Groove and
        # Ridge act as independent thresholds for concave/convex-like hard folds.
        if cut_grooves and angle >= min(angle_cut, groove_angle):
            should = True
        if cut_ridges and angle >= min(angle_cut, ridge_angle):
            should = True
        if tolerance < 0.65 and ratio >= length_cut and angle > 6.0 and (cut_grooves or cut_ridges):
            should = True
        if mode == "MOSAIC" and ratio >= length_cut * 0.85:
            should = True
        if should:
            try:
                e.seam = True; seams += 1
            except Exception:
                pass
    return seams

def _enforce_shared_vertex_uv(obj):
    try:
        bm, uv_layer = _bm_state(obj)
        faces = _selected_faces_or_all(bm)
        table = {}
        for f in faces:
            for l in f.loops:
                table.setdefault(int(l.vert.index), []).append(l)
        for loops in table.values():
            avg = sum((l[uv_layer].uv.copy() for l in loops), Vector((0, 0))) / float(len(loops))
            for l in loops:
                l[uv_layer].uv = avg.copy()
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return True
    except Exception:
        return False


def _fit_canvas(context, margin=0.018):
    obj = _active_mesh(context)
    if obj is None:
        return False
    old = _mode_to_edit(obj)
    try:
        bm, uv_layer = _bm_state(obj)
        faces = _selected_faces_or_all(bm)
        pts = [l[uv_layer].uv.copy() for f in faces for l in f.loops]
        if not pts:
            return False
        minx, miny, maxx, maxy = _bbox(pts)
        sx = max(1e-9, maxx - minx); sy = max(1e-9, maxy - miny)
        usable = max(1e-6, 1.0 - margin * 2.0)
        sc = usable / max(sx, sy)
        ox = margin + (usable - sx * sc) * 0.5
        oy = margin + (usable - sy * sc) * 0.5
        for f in faces:
            for l in f.loops:
                uv = l[uv_layer].uv
                uv.x = ox + (uv.x - minx) * sc
                uv.y = oy + (uv.y - miny) * sc
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return True
    except Exception:
        return False
    finally:
        _restore_mode(obj, old)


def standard_unwrap(context, cfg: dict | None = None) -> bool:
    """Clean-room automatic Standard unwrap.

    It approximates the public behavior expected from a one-click professional
    unwrap tool: mode classification, temporary seam planning, unwrap/relax, and
    high-quality packing.  No third-party plugin code or assets are used.
    """
    cfg = dict(cfg or {})
    obj = _active_mesh(context)
    if obj is None:
        return False
    old = _mode_to_edit(obj)
    saved = None
    try:
        # Target UV channel support.  Blender is 0-based internally while the UI
        # uses the production-friendly 1-based channel numbering.
        try:
            target_index = max(0, int(cfg.get('smart_standard_target_channel', 1) or 1) - 1)
            while len(obj.data.uv_layers) <= target_index:
                obj.data.uv_layers.new(name=f"UVMap_{len(obj.data.uv_layers) + 1}")
            obj.data.uv_layers.active_index = target_index
        except Exception:
            pass
        bm, uv_layer = _bm_state(obj)
        try:
            if not bool(cfg.get('smart_standard_selection', True)):
                for f in bm.faces:
                    if not getattr(f, 'hide', False):
                        f.select_set(True)
        except Exception:
            pass
        faces = _selected_faces_or_all(bm)
        stats = _mesh_stats(bm, faces)
        raw_alg = str(cfg.get("algorithm", "AUTO_ONE_CLICK") or "AUTO_ONE_CLICK").upper()
        mode = _classify_unwrap_mode(raw_alg, stats)
        strength = max(0.0, min(1.0, float(cfg.get("pull_distance", 0.75) or 0.75)))
        flexibility = max(0.0, min(1.0, float(cfg.get("flexibility", 0.5) or 0.5)))
        tolerance = max(0.0, min(1.0, float(cfg.get("split_tolerance", 0.72) or 0.72)))
        if 'smart_standard_stretch' in cfg and mode in {'ORGANIC', 'MOSAIC'}:
            tolerance = max(0.0, min(1.0, float(cfg.get('smart_standard_stretch', tolerance) or tolerance)))
            flexibility = max(flexibility, tolerance)
        if 'smart_standard_padding_px' in cfg:
            try:
                margin = max(0.0, min(0.08, float(cfg.get('smart_standard_padding_px', 8) or 8) / 2048.0))
            except Exception:
                margin = max(0.0, min(0.08, float(cfg.get("margin", 0.018) or 0.018)))
        else:
            margin = max(0.0, min(0.08, float(cfg.get("margin", 0.018) or 0.018)))
        keep_seams = bool(cfg.get("smart_standard_keep_seams", True))
        stretch_allowed = max(0.0, min(1.0, float(cfg.get("smart_standard_stretch", 0.35) or 0.35)))
        cut_grooves = bool(cfg.get("smart_standard_cut_grooves", True))
        groove_angle = max(1.0, min(179.0, float(cfg.get("smart_standard_groove_angle", 55.0) or 55.0)))
        cut_ridges = bool(cfg.get("smart_standard_cut_ridges", True))
        ridge_angle = max(1.0, min(179.0, float(cfg.get("smart_standard_ridge_angle", 65.0) or 65.0)))
        cut_holes = bool(cfg.get("smart_standard_cut_holes", True))
        pack_mode = str(cfg.get("smart_standard_pack_mode", "PACK") or "PACK").upper()
        pack_quality = str(cfg.get("smart_standard_pack_quality", "HIGH") or "HIGH").upper()
        texture_size = max(128, min(16384, int(cfg.get("smart_standard_texture_size", 2048) or 2048)))
        padding_px = max(0.0, min(512.0, float(cfg.get("smart_standard_padding", margin * texture_size) or margin * texture_size)))
        pre_rotate = bool(cfg.get("smart_standard_pre_rotate", True))
        full_rotation = bool(cfg.get("smart_standard_full_rotation", True))
        rescale_charts = bool(cfg.get("smart_standard_rescale_charts", True))
        tile_uvs = bool(cfg.get("smart_standard_tile_uvs", False))
        tile_columns = max(1, min(32, int(cfg.get("smart_standard_tile_columns", 10) or 10)))
        # Only the extreme all-1 request keeps absolutely every seamless vertex
        # shared.  Otherwise the automatic mode may split temporarily to remove
        # overlap, then restores mesh seam flags.
        no_user_seams = not any(bool(getattr(e, "seam", False)) for e in bm.edges)
        connected_lock = bool(no_user_seams and strength >= 0.999 and flexibility >= 0.999 and tolerance >= 0.999)
        saved = _save_seams(bm)
        if not keep_seams:
            for _e in bm.edges:
                try:
                    _e.seam = False
                except Exception:
                    pass
        if connected_lock:
            # Use an unwrap basis then force shared 3D vertices back to a single UV.
            _safe_uv_op("uv.unwrap", method="ANGLE_BASED", margin=margin, fill_holes=True, correct_aspect=True, no_flip=True, iterations=64)
            _safe_uv_op("uv.minimize_stretch", iterations=32)
            _enforce_shared_vertex_uv(obj)
            _fit_canvas(context, margin)
            return True
        _mark_temp_seams(bm, faces, mode, tolerance, flexibility, keep_seams=keep_seams, cut_grooves=cut_grooves, groove_angle=groove_angle, cut_ridges=cut_ridges, ridge_angle=ridge_angle, cut_holes=cut_holes, stretch_allowed=stretch_allowed, cfg=cfg)
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        ok = False
        if mode in {"HARD_SURFACE", "MOSAIC", "PROJECTION"}:
            if mode == "HARD_SURFACE":
                angle_limit = math.radians(max(1.0, min(179.0, float(cfg.get('smart_standard_hard_surface_angle', 44.0 + tolerance * 36.0) or (44.0 + tolerance * 36.0)))))
                area_weight = 0.25 + flexibility * 0.35
            elif mode == "MOSAIC":
                angle_limit = math.radians(max(10.0, min(55.0, 18.0 + tolerance * 28.0)))
                area_weight = 0.65
            else:
                angle_limit = math.radians(88.0)
                area_weight = 0.10
            ok = _safe_uv_op("uv.smart_project", angle_limit=angle_limit, island_margin=margin, area_weight=area_weight, correct_aspect=True)
        if not ok:
            method = "CONFORMAL" if mode == "ORGANIC" else "ANGLE_BASED"
            ok = _safe_uv_op("uv.unwrap", method=method, margin=margin, fill_holes=True, correct_aspect=True, no_flip=True, iterations=96)
        if ok:
            # Strength/flexibility both increase cleanup aggressiveness here.  This
            # keeps the public sliders meaningful without exposing internal options.
            relax = int(16 + 96 * max(strength, flexibility) * (1.0 + (1.0 - stretch_allowed) * 0.5))
            _safe_uv_op("uv.minimize_stretch", iterations=max(8, min(128, relax)))
            if rescale_charts:
                _safe_uv_op("uv.average_islands_scale")
            if pack_mode == "PACK":
                if pack_quality == "TURBO":
                    rotation_step = 90
                elif pack_quality == "EFFICIENT":
                    rotation_step = 45
                else:
                    rotation_step = 15 if full_rotation else 90
                quality_pack(context, margin_px=max(0, int(round(padding_px))), texture_size=texture_size,
                             rotate=bool(pre_rotate or full_rotation), rotation_step=rotation_step,
                             udim=tile_uvs, tile_columns=tile_columns, lock_pinned=True)
            # A second fit is useful for single-island organic results where packing
            # only normalizes scale.  In Keep mode this preserves the generated
            # chart relation while ensuring it remains visible in 1001.
            _fit_canvas(context, margin)
        return bool(ok)
    except Exception:
        return False
    finally:
        if saved is not None:
            _restore_seams(obj, saved)
        _restore_mode(obj, old)


# Immutable handles used by later compatibility layers to restore the 1.6.8 CleanroomAutoPack Standard path.
try:
    ORIGINAL_SAFE_UV_OP_168 = _safe_uv_op
except Exception:
    ORIGINAL_SAFE_UV_OP_168 = None
try:
    ORIGINAL_STANDARD_UNWRAP_168 = standard_unwrap
except Exception:
    ORIGINAL_STANDARD_UNWRAP_168 = None

# ---------------------------------------------------------------------------
# 1.6.15 Standard Smart: Smart Standard exposed options on top of the restored
# CleanroomAutoPack route. This is a clean-room implementation; it does not load
# or copy any third-party plugin binaries.
# ---------------------------------------------------------------------------
_BASE_STANDARD_UNWRAP_168_FOR_1615 = ORIGINAL_STANDARD_UNWRAP_168 if 'ORIGINAL_STANDARD_UNWRAP_168' in globals() else standard_unwrap


def _cfg_bool_1615(cfg, key, default=False):
    try:
        return bool(cfg.get(key, default))
    except Exception:
        return bool(default)


def _cfg_float_1615(cfg, key, default=0.0, lo=None, hi=None):
    try:
        val = float(cfg.get(key, default))
    except Exception:
        val = float(default)
    if val != val:
        val = float(default)
    if lo is not None:
        val = max(float(lo), val)
    if hi is not None:
        val = min(float(hi), val)
    return val


def _cfg_int_1615(cfg, key, default=0, lo=None, hi=None):
    try:
        val = int(round(float(cfg.get(key, default))))
    except Exception:
        val = int(default)
    if lo is not None:
        val = max(int(lo), val)
    if hi is not None:
        val = min(int(hi), val)
    return val


def _try_set_uv_channel_1615(obj, target_index: int) -> bool:
    """Best-effort target channel selection. Creating layers is avoided in edit mode."""
    try:
        mesh = getattr(obj, 'data', None)
        layers = getattr(mesh, 'uv_layers', None)
        if layers is None or len(layers) <= 0:
            return False
        idx = max(0, min(int(target_index), len(layers) - 1))
        layers.active_index = idx
        return True
    except Exception:
        return False


def _mark_temp_seams_smart_standard_1615(bm, faces, mode, tolerance, flexibility, cfg):
    selected = {int(f.index) for f in faces}
    stats = _mesh_stats(bm, faces)
    med_len = max(1e-9, stats['median_len'])
    keep_seams = _cfg_bool_1615(cfg, 'smart_standard_keep_seams', True)
    cut_grooves = _cfg_bool_1615(cfg, 'smart_standard_cut_grooves', True)
    cut_ridges = _cfg_bool_1615(cfg, 'smart_standard_cut_ridges', True)
    cut_holes = _cfg_bool_1615(cfg, 'smart_standard_cut_holes', True)
    groove_angle = _cfg_float_1615(cfg, 'smart_standard_groove_angle', 55.0, 1.0, 179.0)
    ridge_angle = _cfg_float_1615(cfg, 'smart_standard_ridge_angle', 65.0, 1.0, 179.0)
    stretch = _cfg_float_1615(cfg, 'smart_standard_stretch', flexibility, 0.0, 1.0)
    # Stretch 0 -> more cuts / low distortion. Stretch 1 -> fewer cuts / larger charts.
    stretch_offset = stretch * 42.0
    if mode == 'HARD_SURFACE':
        length_cut = 1.45 + tolerance * 5.0
    elif mode == 'MOSAIC':
        length_cut = 1.20 + tolerance * 3.8
    else:
        length_cut = 2.20 + tolerance * 6.0
    seams = 0
    for e in bm.edges:
        linked = [f for f in getattr(e, 'link_faces', []) if int(f.index) in selected]
        if not linked:
            continue
        should = bool(getattr(e, 'seam', False)) and keep_seams
        if len(linked) <= 1:
            # Open holes/borders are used as chart starts when requested.
            should = should or cut_holes
        else:
            angle = 0.0
            if len(linked) == 2:
                try:
                    angle = math.degrees(linked[0].normal.angle(linked[1].normal, 0.0))
                except Exception:
                    angle = 0.0
            # BMesh does not expose signed concavity reliably here; use angle with
            # separate user thresholds for groove/ridge sensitivity.
            if cut_grooves and angle >= max(1.0, groove_angle + stretch_offset * 0.35):
                should = True
            if cut_ridges and angle >= max(1.0, ridge_angle + stretch_offset * 0.45):
                should = True
            try:
                ratio = float(e.calc_length()) / med_len
            except Exception:
                ratio = 1.0
            if tolerance < 0.65 and ratio >= length_cut and angle > 6.0:
                should = True
            if mode == 'MOSAIC' and ratio >= length_cut * max(0.75, 1.05 - stretch * 0.35):
                should = True
        if should:
            try:
                e.seam = True
                seams += 1
            except Exception:
                pass
    return seams


def _pack_after_smart_standard_1615(context, cfg, margin):
    quality = str(cfg.get('smart_standard_pack_quality', 'EFFICIENT') or 'EFFICIENT').upper()
    texture_size = _cfg_int_1615(cfg, 'smart_standard_texture_size', 2048, 128, 16384)
    padding = _cfg_float_1615(cfg, 'smart_standard_padding', margin * texture_size, 0.0, 512.0)
    pre_rotate = _cfg_bool_1615(cfg, 'smart_standard_pre_rotate', True)
    full_rotation = _cfg_bool_1615(cfg, 'smart_standard_full_rotation', False)
    tile_uvs = _cfg_bool_1615(cfg, 'smart_standard_tile_uvs', False)
    tile_cols = _cfg_int_1615(cfg, 'smart_standard_tile_columns', 10, 1, 32)
    if not pre_rotate:
        step = 999
    elif quality in {'HIGH', 'QUALITY'} or full_rotation:
        step = 15
    elif quality == 'TURBO':
        step = 90
    else:
        step = 45
    return quality_pack(
        context,
        margin_px=padding,
        texture_size=texture_size,
        rotate=pre_rotate,
        rotation_step=step,
        udim=tile_uvs,
        tile_columns=tile_cols,
        lock_pinned=True,
        max_seconds=9.5,
    )


def standard_unwrap(context, cfg: dict | None = None) -> bool:
    """Clean-room Standard Smart unwrap with Smart Standard settings exposed.

    The core execution remains the 1.6.8 CleanroomAutoPack sequence: classify,
    plan temporary seams, unwrap/relax, average scale, and deterministic pack.
    This wrapper maps the exposed Smart Standard options into that sequence.
    """
    cfg = dict(cfg or {})
    obj = _active_mesh(context)
    if obj is None:
        return False
    try:
        _try_set_uv_channel_1615(obj, _cfg_int_1615(cfg, 'smart_standard_target_channel', 0, 0, 7))
    except Exception:
        pass
    if str(cfg.get('smart_standard_pack_mode', cfg.get('smart_standard_pack_action', 'PACK')) or 'PACK').upper() == 'KEEP':
        # Keep mode: keep current chart placement; only canvas normalization is done.
        margin = _cfg_float_1615(cfg, 'margin', 0.018, 0.0, 0.25)
        _fit_canvas(context, margin)
        return True
    old = _mode_to_edit(obj)
    saved = None
    try:
        bm, uv_layer = _bm_state(obj)
        faces = _selected_faces_or_all(bm)
        stats = _mesh_stats(bm, faces)
        raw_alg = str(cfg.get('algorithm', 'ORGANIC') or 'ORGANIC').upper()
        mode = _classify_unwrap_mode(raw_alg, stats)
        strength = max(0.0, min(1.0, float(cfg.get('pull_distance', 0.75) or 0.75)))
        stretch = _cfg_float_1615(cfg, 'smart_standard_stretch', cfg.get('flexibility', 0.5), 0.0, 1.0)
        flexibility = stretch
        tolerance = max(0.0, min(1.0, float(cfg.get('split_tolerance', 0.72) or 0.72)))
        texture_size = _cfg_int_1615(cfg, 'smart_standard_texture_size', 2048, 128, 16384)
        padding = _cfg_float_1615(cfg, 'smart_standard_padding', 8.0, 0.0, 512.0)
        margin = max(0.0, min(0.08, padding / max(1.0, float(texture_size))))
        if margin <= 0.0:
            margin = max(0.0, min(0.08, float(cfg.get('margin', 0.018) or 0.018)))
        saved = _save_seams(bm)
        _mark_temp_seams_smart_standard_1615(bm, faces, mode, tolerance, flexibility, cfg)
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        ok = False
        if mode in {'HARD_SURFACE', 'MOSAIC', 'PROJECTION'}:
            if mode == 'HARD_SURFACE':
                angle_limit = math.radians(max(1.0, min(179.0, _cfg_float_1615(cfg, 'smart_standard_hard_surface_angle', _cfg_float_1615(cfg, 'smart_standard_ridge_angle', 65.0, 1.0, 179.0), 1.0, 179.0))))
                area_weight = 0.25 + stretch * 0.35
            elif mode == 'MOSAIC':
                angle_limit = math.radians(max(8.0, min(60.0, _cfg_float_1615(cfg, 'smart_standard_groove_angle', 55.0, 1.0, 179.0) * 0.35 + tolerance * 24.0)))
                area_weight = 0.65
            else:
                angle_limit = math.radians(88.0)
                area_weight = 0.10
            ok = _safe_uv_op('uv.smart_project', angle_limit=angle_limit, island_margin=margin, area_weight=area_weight, correct_aspect=True)
        if not ok:
            method = 'CONFORMAL' if mode == 'ORGANIC' else 'ANGLE_BASED'
            iters = 64 if mode == 'MOSAIC' else 96
            ok = _safe_uv_op('uv.unwrap', method=method, margin=margin, fill_holes=True, correct_aspect=True, no_flip=True, iterations=iters)
        if ok:
            relax = int(12 + 96 * max(strength, 1.0 - stretch))
            _safe_uv_op('uv.minimize_stretch', iterations=max(8, min(128, relax)))
            if _cfg_bool_1615(cfg, 'smart_standard_rescale_charts', True):
                _safe_uv_op('uv.average_islands_scale')
            _pack_after_smart_standard_1615(context, cfg, margin)
            _fit_canvas(context, margin)
        return bool(ok)
    except Exception:
        return False
    finally:
        if saved is not None:
            _restore_seams(obj, saved)
        _restore_mode(obj, old)

# Update immutable handle so later restore layers restore the option-aware route.
ORIGINAL_STANDARD_UNWRAP_168 = standard_unwrap
